#!/usr/bin/env python3
"""Frozen-dump accounting and relocation inspection, without executing code."""
import hashlib
import json
import re
import subprocess
import tarfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
summary = json.loads((HERE / 'inspection.json').read_text())
commands = json.loads((HERE / 'commands.json').read_text())
tool = Path('/opt/homebrew/opt/llvm/bin/llvm-objdump').resolve()
functions = {}
for key, arm in summary['arms'].items():
    directory = RAW / ('prepared-' + key)
    text = (directory / 'kernel.ll').read_text()
    found = {}
    for match in re.finditer(r'^define [^\n]*@([^ (]+)[^\n]*\{\n(.*?)^\}', text, re.M | re.S):
        body = match.group(2)
        instructions = [line for line in body.splitlines() if line.startswith('  ') and not line.lstrip().startswith(';')]
        # This fixture has no multi-line switch/instruction continuation.
        assert all(re.match(r'^  (?:%[^ ]+ = |(?:br|ret|store|call|unreachable)\b)', line) for line in instructions)
        found[match.group(1)] = {
            'instructions': len(instructions),
            'basic_blocks': sum(bool(re.match(r'^[A-Za-z0-9_.]+:', line)) for line in body.splitlines()),
            'vector_loads': len(re.findall(r' = load <4 x i32>', body)),
            'scalar_loads': len(re.findall(r' = load i32,', body)),
            'copy_loop_limits': re.findall(r'icmp ult i64 %copy.index\w*, (\d+)', body),
            'copy_calls': len(re.findall(r'call void @llm_attention.contiguous_copy', body)),
        }
    functions[key] = found
    observed_clone = arm['fields']['full_packet_cloned_instructions']
    if observed_clone:
        assert found['llm_attention']['instructions'] == observed_clone
    for mode, args in [('relocations', ['--reloc', directory / 'kernel.o']),
                       ('linked-disassembly', ['--disassemble', '--no-show-raw-insn', directory / 'kernel.dylib'])]:
        argv = [str(tool), *map(str, args)]
        result = subprocess.run(argv, capture_output=True, timeout=30)
        output = HERE / key
        (output / (mode + '.stdout.txt')).write_bytes(result.stdout)
        (output / (mode + '.stderr.txt')).write_bytes(result.stderr)
        commands.append({'argv': argv, 'returncode': result.returncode,
                         'stdout': str((output / (mode + '.stdout.txt')).relative_to(HERE)),
                         'stderr': str((output / (mode + '.stderr.txt')).relative_to(HERE))})
        assert result.returncode == 0

with tarfile.open(RAW / 'sources.tar.gz') as archive:
    name = 'src/backends/simd/llvm/llvm_schedule_codegen.cpp'
    matches = [member for member in archive.getmembers() if member.name.endswith(name)]
    assert len(matches) == 1
    content = archive.extractfile(matches[0]).read()
    (HERE / 'frozen-llvm_schedule_codegen.cpp').write_bytes(content)
    source_identity = {'archive_member': matches[0].name,
                       'sha256': hashlib.sha256(content).hexdigest(),
                       'archive_sha256': hashlib.sha256((RAW / 'sources.tar.gz').read_bytes()).hexdigest()}

(HERE / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
(HERE / 'llvm-accounting.json').write_text(json.dumps({'functions': functions, 'source_identity': source_identity}, indent=2) + '\n')
print(json.dumps({key: {'body': value['llm_attention'],
                        'clone': summary['arms'][key]['fields']['full_packet_cloned_instructions']}
                  for key, value in functions.items()}, indent=2))

# Native copy 成对实验：执行前独立审查

范围：只读检查本目录 `run.py`、`gate.py`、现有 `native_tile.py` / `native_tile_replay.cpp`，以及实际 attention 源和 copy admission。未执行 capture、native replay、构建或测试；本文不提供性能结果。

## 结论

当前六个预声明 case 的实验协议没有发现阻止执行的硬伤。两臂均固定 native MMA width=4，切换 native copy width=0/4；copy 开关可能同时改变 private-array interleaving、helper code 和 full-packet clone admission，因此结果只能归因于**整个 copy lowering 候选**，不能直接拆成 vector load 本身的收益。

## 为什么静态 `native_copies=3` 合理

`src/tests/common/tile_llm_test_utils.h:124–167` 的 attention 恰有三个 `VIEW_LOAD`：外层 Q，以及 pipeline 内的 K、V。P、row state 和 acc 均为算术结果，不是额外的 buffer load。

- Q 直接用于 native QK。MHA 的 Q64 虽没有超过默认 Tile threshold=64，仍由 native MMA consumer 强制取得 indexable snapshot。
- K、V 的 view 形状分别是 `[1,1,16,D]`、`[1,1,16,Dv]`；末轴完全覆盖物理行，均连续且大于四个 FP32 元素。
- 六组的 BQ 均不大于 Q，BK=16 均不大于 KV 长度。Q/K/V 的非单位轴都符合 `src/tile/bridge/xir/native_copy.h` 的 source/snapshot stride 相等规则。
- 管线只静态生成一份 K/V load body。KV 尾块或 query 尾块走 whole-view guard 的 fallback，不改变静态 `native_copies` 数。

所以三是三个**静态 transfer sites**，不是每个 program 只调用三次，也不是三次 DRAM transaction。单个完整 program 的潜在 sites 执行次数是 Q 的 1 次加 K/V 各 `ceil_div(KV,16)` 次；其中部分实例可能选择逐元素 fallback。该预期只适用于本次固定源码与六组参数，不应推广成 attention 的永久规则。若 capture 不符合预期，脚本保留 Error，不自动改成接受实测计数。

## 配对与正确性

| 检查 | 当前实现 |
|---|---|
| 固定实现和几何 | `execution_controls()` 检查 W8、block32、local1、global threshold64 / region4096、R4、各 case cap/2D、native MMA [2,1,1]、copy0/3 sites |
| Runtime 入口 | `pair_oracle()` 要求 ABI、symbol、packet、block、dispatch、root order、task grain 成对相等；不猜 `.blocks` 是否存在 |
| 输入和 oracle 身份 | 三个 input、FP64 oracle、replay helper、ABI header 和 runner 的文件哈希成对相等；完整 prepared inventory 再核验 |
| 数值 | 独立 FP64 `einsum(optimize=False)`、FP32 scale、bottom-right causal mask、GQA head mapping；oracle 文件另以 1e-12 检查，两臂完整 FP32 输出以 5e-5 abs/rel 检查 |
| 精确拷贝合同 | 两臂 captured FP32 文件 SHA 必须相等；每次 replay visit 的最终输出 SHA 必须等于本臂已验证 capture |
| 容量 | static snapshot bytes/worker 与 allocations 成对相等；workspace bytes、interleaving、clone count 允许变化并分别记录，不声称实际 workspace 相等 |
| 不覆写失败 | 每次 capture/prepare/replay 的目录和命令/输出采用唯一新路径；aggregate 保留 NotRun / Error；任一 case 不完整则禁止启动整体 replay |

`frozen_identities()` 检查完整 selected build 的命令、成功码、source 未变、十一项 CTest 的命令/成功日志、build-before-tests，以及 main/selected owned files 一致。之后的 `freeze()` 重查原生产程序、有关库、工具、runner/helper、ABI 及 owned source hashes。

这里是选定文件与二进制的身份检查，不是动态 loader 闭包证明，也不是整个仓库 HEAD 均被冻结。后续 source archive 应继续保存实际 selected export、attention producer 源及所有失败门禁尝试，并单独证明 archive 在首个 capture 之前完成。

## 计时与验证检查点

两臂使用同一份 C++ timer helper，每个 case 为 3 个 ABBA cycle，共 12 visits、84 samples；六组完整时应为 72 visits、504 samples。每 visit 的 30 ms warmup 与约 15 ms calibration/sample target 相同；两臂可有不同 repetitions，时间为 batch wall duration / repetitions。

native-entry 口径包含 launch reset、entry/block traversal 和 compiler-emitted helper/libc；不含调用方 allocation、Python、Runtime dispatch、JIT 或校验。没有 affinity/host quiescence 的保证，ABBA 也不能消除所有频率/后台任务影响。

`native_tile_replay.cpp:207–225` 的完整 oracle/guards 校验点是：preflight 后、warmup 后、calibration 后、每个 timed sample batch 后。它**不在每次 timed `invoke` 后都校验**。own-capture bitwise 对比是每个 visit 的最终输出；正式报告应沿用这个精确口径。

汇总时分别重算：每臂 42 个 samples 的 median、每臂 6 个 visit medians 的 median，以及 6 对相邻 AB / BA visit medians 的 on/off 比率 median。不要把不同统计量的比值混称为同一指标；所有负结果保留。

## 小修建议与离线复查边界

- 审查时 `pair_oracle()` 的 root/task-grain 拒绝文本仍写 “solely to native MMA”，应为 native copy；不影响判定逻辑。
- `per-call guards` 容易被误读成每次内部 native invoke；应描述为上述 preflight/batch 检查点。
- 离线审计不能调用 `run.freeze()`：该函数读取 live main/build。应只读归档证据，验证 source archive / prepared object / 命令和日志哈希、实际门禁集合、chronology，再重算所有 oracle、输出哈希与 ABBA 统计。
- 不应导入或执行归档 LLVM / object / dylib；可离线读取元数据和文件字节。异常或未完成 case 仍应保留其 Error / NotRun 状态，而非补造通过记录。

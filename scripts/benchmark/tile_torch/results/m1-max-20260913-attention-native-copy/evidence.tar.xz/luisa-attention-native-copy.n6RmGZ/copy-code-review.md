# 连续 snapshot copy：实际 LLVM / ORC 对象审查

本审查只读取本轮冻结的 `prepared-*/prepared.json`、`kernel.ll`、实际 ORC 生成的 `kernel.o` 及由它链接的 `kernel.dylib`；没有重新编译 kernel，没有执行 native entry，也没有增加性能采样。范围为 `decode-mha-d64`、`decode-long-kv`、`prefill-q8` 的 copy off/on 六臂。数值与 ABBA 性能验收由本轮独立审计负责，本文件不重复作性能判决。

## 结论

1. 连续复制确实落成了 AArch64 NEON 的 128-bit `ldr q` / `str q`，不是仅在 Tile/Schedule 元数据中计数。LLVM dump 中的私有 copy helper 在实际对象里已经内联，不存在 copy runtime callback/import。
2. `K=8193` 的最后一个不完整 KV tile 仍走原有逐元素读取/越界置零路径；完整 tile 才进入向量复制路径。这里的逻辑 tile 边界与 `element_count % vector_width` 是两个问题：所查实际 copy 长度都能被 4 整除，没有用这些 benchmark 冒称覆盖 scalar vector-remainder。
3. `prefill-q8` 同时丢失了 full-packet specialization：原始 entry 的 LLVM 指令数由 3786 增至 4146，超过冻结实现的 4096 门槛。因此该组是 copy candidate 与 clone admission 的联合变化，不能把时间差全归因于单一复制指令。

## 相同项与结构变化

下表为 off → on。LLVM 指令/基本块只统计 clone 前原始 `llm_attention` entry，不含独立 helper、wrapper 或克隆副本；对象大小是完整 `kernel.o` 文件字节数，不能解释为执行指令数或耗时。

| Case | Entry LLVM 指令 / blocks | Full-packet clone | Snapshot bytes/worker；allocations | Workspace bytes | Object bytes | 未解析外部符号 |
|---|---:|---:|---:|---:|---:|---|
| decode-mha-d64 | 5536 / 61 → 4460 / 99 | 0 → 0 | 9216；9 → 相同 | 73728 → 相同 | 143624 → 101064 | 无 → 无 |
| decode-long-kv | 2369 / 99 → 2608 / 150 | 1 → 1 | 19200；11 → 相同 | 153600 → 相同 | 60608 → 61904 | `_bzero`, `_memcpy` → 相同 |
| prefill-q8 | 3786 / 189 → 4146 / 240 | 1 → 0 | 14768；18 → 相同 | 118144 → 相同 | 61736 → 35976 | `_bzero`, `_memcpy` → 无 |

六臂均保持 ABI 0、packet width 8、block `[32,1,1]`、入口 `llm_attention.packet_batch.blocks`。各对 dispatch 相同：MHA `[8,1,1]`，long `[16,1,1]`，q8 `[32,1,1]`；每对 root order 保持不变，`local_lanes=1`，`blocks_per_task=0`，`fast_math=false`。每对 native MMA 仍为 2 个（output 1、contraction 1），copy width 0 → 4，`native_copies` 0 → 3。Snapshot 容量相同不代表生成代码/控制流相同，表中的 clone 差异需单独保留。

`kernel.ll` 是捕获的 lowering dump，不能当作最终 O2 后 LLVM。它保留了 private copy 定义与调用；是否内联以下面的真实对象符号、调用、重定位和反汇编共同确认。`llvm-nm --print-size` 在此 Mach-O 上返回的零 size 不是函数真实大小，本报告未使用它推导大小。

## MHA：完整 Q/K/V copy 已向量化

形状 `[B,H,KH,Q,K,D,Dv]=[1,8,8,1,2048,64,64]`，attention tile `[1,16]`。LLVM private helpers 对应 Q 64、K 1024、V 1024 个 FP32 元素，分别为 16、256、256 组 `<4 x i32>` load/store（`align 4`）。使用整数向量搬运原始位，不添加浮点运算；copy helper 形参未新增 `noalias` / `readonly` 承诺。原 entry 的 24 个 helper 调用对应 8 个 program lanes × 3 个资源，保留 `copy.active` / `copy.continue` 分支。

所有下列地址都是 **`kernel.o` 的 `__text` 地址**，不是 loaded PC、dylib image offset 或前一轮 profiler 地址，不能混用。

- Q 的数据指针来自 argument buffer 的第 0 个 buffer view；第一 program 的 64 元素被完全展开为 16 对 `ldr q3` / `str q3`，对象地址 `0xb0` 至 `0x12c`，偏移 0 至 `0xf0`。
- K 指针从 argument buffer `+0x10` 取得（对象 `0x27d8`），保存到 `[sp,#0x3df0]`；V 从 `+0x20` 取得（`0x27e8`），保存到 `[sp,#0x3de0]`。据此识别 K/V，而非仅凭相邻地址猜测阶段。
- 第一 program 的 K 向量循环为半开区间 `[0x36cc,0x36e0)`；V 为 `[0x38d4,0x38e8)`。其他 program 保留同类循环及 active-lane guard。

K 循环实际指令：

```text
36cc: ldr q1, [x16, x15]
36d0: str q1, [x4, x15]
36d4: add x15, x15, #0x10
36d8: cmp x15, #0x1, lsl #12   // 4096 bytes = 1024 FP32
36dc: b.ne 0x36cc
```

Q/K/V 三个 `.contiguous_copy` helper 都不出现在对象函数符号或外部 imports 中；linked disassembly 的调用仅为 packet wrapper → 内部 attention body。因此这是实际内联向量复制。MHA 的 K=2048 能整除 BK=16，没有末尾不完整 KV tile；不能以它单独证明逻辑尾部处理。

## Long KV：向量路径与逻辑尾部同时保留

形状 `[1,16,4,1,8193,128,128]`，attention tile `[1,16]`。完整 packet clone 仍然存在。对象 entry 的 K/V 数据指针分别从 argument buffer `+0x10` / `+0x20` 读取（`0x44` / `0x54`），保存到 `[sp,#0xd18]` / `[sp,#0xd10]`，后续复制读取这些指针。

- Q 128 元素：第一向量循环 `[0xb4,0xc8)`，16-byte 步长、512-byte 终止。
- K 2048 元素：第一 program 循环 `[0x10f0,0x1104)`，16-byte 步长、8192-byte 终止；V 第一循环 `[0x11fc,0x1210)` 同样处理 8192 bytes。其余 7 个 program 有各自的复制循环。
- `0xf48` 比较 KV tile index 与 `0x200`（512），`0xf58` 的 `b.ne 0x109c` 通向完整 tile 向量路径。tile 512 即覆盖 key 8192 的最后一块，走 scalar/zero fallback：`0x100c/0x1010` 初始化零，`0x1014` 比较元素偏移与 `0x7f`，`0x1018` 对后续元素跳到零存储路径。仅前 128 个有效元素从最后一条 key 读取，循环仍覆盖完整 2048 元素 snapshot。
- V 的对应最后 tile 路径位于 `0x4f40` 一带：`0x4fac/0x4fb0` 置零，`0x4fb4` 比较 `0x7f`，`0x4fb8` 跳往零存储路径；`0x4fa4` 的 `0x800` 是完整 snapshot 循环边界。

因此所见实际代码没有以完整向量块读取最后一块逻辑越界区域；但这不承诺非法 host buffer physical interval 自动安全，运行时有效 buffer interval 仍是合同前提。

long 两臂仍有已有 `_bzero` / `_memcpy` imports。on 对象重定位将 `0x1b4` 绑定 `_bzero`、`0x4ec8` 绑定 `_memcpy`，均不在上述 K/V 向量循环内；没有 copy-helper callback。linked disassembly 对 stub 的最近符号显示可能误导（例如显示成 `_memcpy+offset`），外部调用目标以上述 relocation 为准。

## q8 clone 消失：冻结源与计数对应

冻结源 `src/backends/simd/llvm/llvm_schedule_codegen.cpp:839–868` 中，`max_full_packet_clone_instructions=4096`；只遍历 `*result.entry` 的基本块并累计 `block.size()`，不将 private helper 的函数体计入门槛。超过门槛时不创建 clone。

独立文本计数得到 off 3786、on 4146：off 与 metadata 的 `full_packet_cloned_instructions=3786` 一致；on 增长 360 条原始 entry 指令和 51 个基本块，`full_packet_specializations=0` / cloned count 0，与阈值拒绝相符。向量 copy 的逐 program call/guard、原始边界 fallback 等共同改变 CFG，不能把全部增长描述成 helper 本体增长。

对象符号也对应：off 有 `_llm_attention.full_packet`，on 则为 `_llm_attention`。on 的对象和总 LLVM dump 反而更小，是缺少 clone 副本及后续优化路径改变后的总体结果，不与原始 entry 增长矛盾。MHA 两臂原始 entry 均超过门槛，long 两臂均低于门槛，也与其 clone 状态吻合。

## 证据与复查范围

全部审查产物在 `copy-code-review.H0ZHTW/`：

- `inspection.json`：六个 prepared 清单的 SHA、每臂 `kernel.o/.ll/.dylib` SHA 与字节数、原始 realization、ABI、imports、对象指令行计数；三个编译产物的 SHA 均与各自 prepared 清单匹配。
- `llvm-accounting.json`：逐函数指令/basic-block/helper-loop 计数，以及冻结 compiler 源来源。
- `commands.json`：30 条 objdump/nm 的精确 argv、输出文件路径和 return code（全部 0）。文件刻意不叫 `*.command.json`，不混入 benchmark 的 command inventory。每个 arm 子目录保留完整 object/linked disassembly、symbols、imports、relocations 及 stderr。
- `inspect.py`、`summarize.py`：产生以上只读分析结果的脚本；没有重编译 LLVM，没有加载或调用被测 dylib。交互式 `rg` / `sed` 仅用于阅读这些产物，不纳入 objdump/nm command inventory。
- `frozen-llvm_schedule_codegen.cpp`：从本轮 `sources.tar.gz` 提取的完整源，SHA256 `3f93e1d5a5377dbc061cce995834175a5d9611faeb7eb495a17417b493338ab5`；源归档 SHA256 `90581800bc76f80aad6b841e609db91605c0c4b209d86dd6c92f3e474ea85885`。

本文件仅确认编译器选项的实际实现形态与连带结构变化，不提供新的纯 kernel 时间、copy 阶段耗时占比或性能因果分解，也不说明所有有限 FP32 输入等价，更不构成战胜 Torch/MPS 的证据。性能结论应引用同轮完整 ABBA 审计并保留所有有利及不利 case。

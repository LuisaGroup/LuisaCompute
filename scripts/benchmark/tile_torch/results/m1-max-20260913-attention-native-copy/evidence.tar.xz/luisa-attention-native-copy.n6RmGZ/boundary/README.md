# Post-capture backend boundary hardening

This is a separate, untimed follow-up to the frozen native-copy experiment.
The original 42 measured compiler/test files and all captured SIMD objects,
inputs, outputs and samples remain unchanged. These five additional files
close unsupported consumers of required XIR call metadata:

- Metal4 preflight rejects StridedMmaMD and ContiguousCopyMD even when a
  matching ordinary external/native_include symbol could otherwise exist.
- HIP external declaration and CUDA XIR metadata emission fail explicitly.
- A new host-only Metal4 test checks 16 valid-XIR combinations of ordinary
  versus required copy/MMA, with/without native_include and live/unused externs.
  This calls supported(), not LLVM codegen, linking or GPU execution.

full-build-2 passed before regression-2 (one exact CTest, two test cases).
Final syntax-2 covers the Metal4 production TU and new host test TU. The
47-file identity is the earlier 42 plus these five, identical in main and
the selected export. CUDA/HIP are disabled on this macOS build: their small
fail-closed guards are source-reviewed, not claimed built or device-tested.
The linker retains warnings about Homebrew LLVM/system libraries built for
macOS26 versus the project's macOS13 deployment target; this build passing
on macOS26 does not establish macOS13 binary portability.

Earlier attempts remain: driver-bootstrap.log records wrapper syntax errors
before any work; full-build-1 passed; regression-1 aborts in the fixture's
invalid XIR block size 1 (the contract requires a multiple of32). The fixture
was fixed to (32,1,1), fully rebuilt and rerun; the old failure is not relabeled.

sources.tar.gz contains the exact five selected-source follow-up files,
not a replacement for the original pre-capture source archive. Their hashes
are included in the successful gate's 47-file source_sha256. These results
are not part of the performance auditor's 11-test/pre-capture chronology;
all follow-up files are separately sealed by the enclosing evidence inventory.

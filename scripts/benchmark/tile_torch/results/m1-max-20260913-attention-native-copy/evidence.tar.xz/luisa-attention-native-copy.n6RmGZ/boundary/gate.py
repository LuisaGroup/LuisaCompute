"""Post-capture backend rejection hardening. Does not recapture or retime SIMD evidence."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/mike/CLionProjects/luisa')
SOURCE = Path('/tmp/luisa-next-integration.roZbN8/source')
BUILD = Path('/tmp/luisa-next-integration.roZbN8/build')
OWNED = (OUT / 'owned.txt').read_text().splitlines()


def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')


def identity():
    main = {name: sha(ROOT / name) for name in OWNED}
    selected = {name: sha(SOURCE / name) for name in OWNED}
    if main != selected:
        raise RuntimeError('owned source copy differs from working source')
    return main


def run(label, command, frozen):
    record = {'command': command, 'started': time.time(), 'source_sha256': frozen,
              'selected_source': str(SOURCE), 'build': str(BUILD)}
    target = OUT / (label + '.json')
    if target.exists():
        raise RuntimeError('attempt exists; choose a new label')
    save(target, record)
    with (OUT / (label + '.log')).open('wb') as log:
        completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record.update(finished=time.time(), returncode=completed.returncode,
                  log_sha256=sha(OUT / (label + '.log')))
    try:
        record['source_unchanged'] = identity() == frozen
    except Exception as error:
        record.update(source_unchanged=False, source_error=str(error))
    save(target, record)
    print(label, record['returncode'], 'source_unchanged', record['source_unchanged'], flush=True)
    if completed.returncode or not record['source_unchanged']:
        raise SystemExit(completed.returncode or 1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=('build', 'tests', 'syntax'))
    parser.add_argument('label')
    args = parser.parse_args()
    frozen = identity()
    if args.phase == 'build':
        run(args.label, ['cmake', '--build', str(BUILD), '-j', '6'], frozen)
    elif args.phase == 'tests':
        run(args.label, ['ctest', '--test-dir', str(BUILD), '--output-on-failure', '-R',
                        '^test_metal4_xir_preflight$'], frozen)
    else:
        for index, name in enumerate(OWNED):
            if name in ('src/backends/metal4/llvm_codegen/metal_codegen_llvm_preflight.cpp', 'src/tests/unit/ext/test_metal4_xir_preflight.cpp'):
                run(args.label + '-' + str(index), [sys.executable, str(ROOT / 'scripts/check_cpp_syntax.py'),
                    str(SOURCE / name), '--project-root', str(SOURCE), '--compile-commands-dir', str(BUILD),
                    '--clangd', '/opt/homebrew/opt/llvm/bin/clangd'], frozen)

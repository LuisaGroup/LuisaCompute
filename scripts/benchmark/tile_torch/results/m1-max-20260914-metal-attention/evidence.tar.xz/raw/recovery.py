"""Bounded, correctness-checked GPU recovery diagnostics; not a performance ranking."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent
BUILD = Path('/tmp/luisa-next-integration.roZbN8/build')
sys.path.insert(0, str(ROOT / 'scripts/benchmark/tile_torch'))
from compare_llm import capture_benchmark


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def worker():
    import torch
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    assert torch.backends.mps.is_available()
    for index in range(3):
        start = time.perf_counter()
        torch.mps.synchronize()
        print(json.dumps(dict(repeat=index, phase='empty_sync', seconds=time.perf_counter()-start)), flush=True)
        source = torch.arange(37, dtype=torch.float32) / 8
        start = time.perf_counter()
        x = source.to('mps')
        actual = x.cpu()
        torch.mps.synchronize()
        assert torch.equal(actual, source)
        print(json.dumps(dict(repeat=index, phase='copy', seconds=time.perf_counter()-start, elements=37)), flush=True)
        start = time.perf_counter()
        y = x * 2 + 1
        torch.mps.synchronize()
        assert torch.equal(y.cpu(), source * 2 + 1)
        print(json.dumps(dict(repeat=index, phase='tiny', seconds=time.perf_counter()-start, elements=37)), flush=True)
    print(json.dumps(dict(status='passed', torch=torch.__version__, torch_git=torch.version.git_version)), flush=True)


def run(name, command, timeout, overrides=None):
    folder = OUT / name
    folder.mkdir()
    env = {k: v for k, v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_', 'DYLD_'))}
    env.update(PYTORCH_ENABLE_MPS_FALLBACK='0', OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
    env.update(overrides or {})
    sources = [Path(__file__), ROOT / 'scripts/benchmark/tile_torch/compare_llm.py', ROOT / 'scripts/benchmark/tile_torch/run.py']
    row = dict(command=command, timeout_seconds=timeout, started=time.time(),
               source_sha256={str(p): sha(p) for p in sources},
               environment={k: v for k, v in env.items() if k.startswith(('LUISA_', 'MTL_', 'PYTORCH_', 'OMP_', 'VECLIB_'))})
    save(folder / 'command.json', row)
    try:
        result = capture_benchmark(command, env, timeout, folder, 'process', row)
        row.update(status='passed', finished=time.time())
        assert row['source_sha256'] == {str(p): sha(p) for p in sources}
        save(folder / 'result.json', row)
        print(name, 'passed', flush=True)
        return result.stdout
    except BaseException as error:
        row.update(status='failed', finished=time.time(), error=str(error))
        save(folder / 'result.json', row)
        raise


def main():
    if sys.argv[1] == 'build':
        run('build', ['cmake', '--build', str(BUILD), '-j', '6'], 300)
    elif sys.argv[1] == 'health':
        run('power-assertions', ['pmset', '-g', 'assertions'], 5)
        for i in range(3):
            output = run(f'mps-health-{i}', [sys.executable, str(Path(__file__)), 'worker'], 30)
            rows = [json.loads(line) for line in output.splitlines()]
            assert len(rows) == 10 and rows[-1]['status'] == 'passed'
            assert [(r['repeat'], r['phase']) for r in rows[:-1]] == [(j, p) for j in range(3) for p in ('empty_sync', 'copy', 'tiny')]
            print(json.dumps(rows), flush=True)
    else:
        raise ValueError('unknown mode')


if __name__ == '__main__':
    (worker if sys.argv[1:] == ['worker'] else main)()

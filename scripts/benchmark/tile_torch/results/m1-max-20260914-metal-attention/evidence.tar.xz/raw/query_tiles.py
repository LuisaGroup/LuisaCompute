"""Predeclared fixed query-tile ABBA pilot. No timing-based winner selection."""
import json
from pathlib import Path
import sys
import time
from recovery import ROOT, OUT, BUILD, run, save, sha

CASES = [('small', (1, 4, 2, 16, 33, 32, 32)), ('prefill', (1, 4, 2, 64, 128, 64, 64))]
ORDER = [4, 1, 1, 4] * 2
HELPERS = [ROOT / 'scripts/benchmark/tile_torch' / p for p in ('metal4_timing.py', 'compare_llm.py', 'run.py', 'repeat.py')]
ARTIFACTS = [p for p in (BUILD / 'bin').iterdir() if p.is_file() and (p.suffix == '.dylib' or p.name == 'benchmark_tile_xir')]
frozen = {str(p): sha(p) for p in [Path(__file__), *HELPERS, *ARTIFACTS]}
plan = dict(started=time.time(), cases=CASES, query_tile_order=ORDER, key_tile=16, local_lanes=1,
            samples_per_visit=3, repetitions=8, warmup_ms=10, math='FP32, fast_math=false, QK/PV=MMA, bottom-right causal GQA',
            frozen_sha256=frozen, purpose='Compare query tile granularity at fixed local distribution; no per-case winner selection or fitted cost model',
            limits='Two ABBA cycles only. Precise counters are instrumented. GPU feedback controls and host wall measured separately. No simultaneous cross-framework timing.')
save(OUT / 'query-tiles-plan.json', plan)
rows = []
for name, dims in CASES:
    for i, bq in enumerate(ORDER):
        tag = f'query-{name}-{i}-bq{bq}'
        output = OUT / tag / 'cohort'
        command = [sys.executable, str(HELPERS[0]), '--binary', str(BUILD / 'bin/benchmark_tile_xir'),
                   '--case', 'attention:' + ','.join(map(str, dims)), '--attention-block', str(bq), '16',
                   '--local-lanes', '1', '--rounds', '1', '--samples', '3', '--repetitions', '8',
                   '--timeout', '60', '--output', str(output)]
        try:
            assert frozen == {str(p): sha(p) for p in [Path(__file__), *HELPERS, *ARTIFACTS]}
            run(tag, command, 75)
            report = json.loads((output / 'results.json').read_text())
            assert report['cohort_valid'] and report['artifacts_unchanged']
            assert len(report['results']) == 1 and report['results'][0]['valid']
            row = report['results'][0]
            rows.append(dict(case=name, position=i, query_tile=bq, result=tag+'/cohort/results.json',
                             metrics=row['metrics'], actual_local_lanes=row['actual_local_lanes'], realization=row['realization']))
            print(json.dumps({key: value for key, value in rows[-1].items() if key != 'metrics'}), flush=True)
        except BaseException as error:
            save(OUT / 'query-tiles-failure.json', dict(case=name, position=i, error=str(error),
                 completed=rows, status='incomplete; no accepted performance cohort'))
            raise
assert frozen == {str(p): sha(p) for p in [Path(__file__), *HELPERS, *ARTIFACTS]}
save(OUT / 'query-tiles-results.json', dict(status='complete', finished=time.time(), rows=rows, artifacts_unchanged=True))

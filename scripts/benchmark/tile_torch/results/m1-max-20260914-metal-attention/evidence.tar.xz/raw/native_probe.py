"""Small Metal4 dispatch/control checks after bounded MPS completion checks."""
import json
import os
from pathlib import Path
import subprocess
import time
import numpy as np
from recovery import ROOT, OUT, BUILD, run, save, sha
from compare_llm import reference, shapes_for, validate_output

SOURCE = BUILD.parent / 'source'
source_files = [p for base in ('src/backends/metal4', 'src/tile/bridge/xir', 'include/luisa/tile', 'include/luisa/backends/ext')
                for p in (SOURCE / base).rglob('*') if p.is_file() and p.suffix in ('.h', '.cpp', '.mm')]
source_files += [SOURCE / name for name in ('src/tests/common/tile_llm_benchmark.h', 'src/tests/common/tile_llm_test_utils.h',
                                            'src/tests/common/metal4_benchmark.h', 'src/tests/benchmark/benchmark_tile_xir.cpp')]
artifacts = [p for p in (BUILD / 'bin').iterdir() if p.is_file() and
             (p.suffix == '.dylib' or p.name == 'benchmark_tile_xir')]
before = {str(p): sha(p) for p in [*source_files, *artifacts, Path(__file__)]}
save(OUT / 'native-provenance.json', dict(started=time.time(), head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
     selected_source=str(SOURCE), files_sha256=before,
     boundary='Selected build sources/binary fingerprints, not a whole-HEAD build or complete loader closure; protected TIRx WIP excluded.'))
for op, shape, block in [('gelu_residual', (2, 17), (1, 1)), ('attention', (1, 2, 2, 5, 5, 5, 3), (2, 3))]:
    name = 'metal4-' + op
    prefix = OUT / name / 'output.f32'
    command = [str(BUILD / 'bin/benchmark_tile_xir'), 'llm', op, ','.join(map(str, shape)), *map(str, block), '3', '1', '1', str(prefix)]
    overrides = dict(LUISA_TILE_BENCH_XIR_BACKEND='metal4', LUISA_TILE_BENCH_METAL4_TIMING='1',
                     LUISA_TILE_BENCH_FIXED_REPETITIONS='2', LUISA_TILE_BENCH_DUMP_SOURCE=str(prefix)+'.source.txt')
    stdout = run(name, command, 45, overrides)
    result = json.loads(stdout)
    inputs, output_shape = shapes_for(op, shape)
    arrays = [np.fromfile(str(prefix)+f'.input{i}.f32', dtype=np.float32).reshape(s) for i, s in enumerate(inputs)]
    actual = np.fromfile(prefix, dtype=np.float32).reshape(output_shape)
    checked = validate_output(actual, reference(op, shape, arrays))
    assert result['implementation'] == 'tile_xir_metal4' and result['device_timing']['method'] == 'metal4_precise_dispatch_timestamps_v1'
    assert result['correctness']['elements_per_check'] == actual.size and result['correctness']['checks'] == 2
    assert before == {str(p): sha(p) for p in [*source_files, *artifacts, Path(__file__)]}
    save(OUT / name / 'oracle.json', dict(status='passed', correctness=checked, output_shape=output_shape,
         files_sha256={str(p): sha(p) for p in prefix.parent.iterdir() if p.is_file()}, artifacts_unchanged=True))
    print(json.dumps(dict(case=name, host_throughput_us=result['throughput_us'], host_latency_us=result['latency_us'],
                         correctness=checked)), flush=True)

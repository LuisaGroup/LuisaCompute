	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	96                              ; 0x60
	.quad	112                             ; 0x70
lCPI0_4:
	.quad	64                              ; 0x40
	.quad	80                              ; 0x50
lCPI0_5:
	.quad	32                              ; 0x20
	.quad	48                              ; 0x30
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	16                              ; 0x10
lCPI0_7:
	.quad	97                              ; 0x61
	.quad	113                             ; 0x71
lCPI0_8:
	.quad	65                              ; 0x41
	.quad	81                              ; 0x51
lCPI0_9:
	.quad	33                              ; 0x21
	.quad	49                              ; 0x31
lCPI0_10:
	.quad	1                               ; 0x1
	.quad	17                              ; 0x11
lCPI0_11:
	.quad	98                              ; 0x62
	.quad	114                             ; 0x72
lCPI0_12:
	.quad	66                              ; 0x42
	.quad	82                              ; 0x52
lCPI0_13:
	.quad	34                              ; 0x22
	.quad	50                              ; 0x32
lCPI0_14:
	.quad	2                               ; 0x2
	.quad	18                              ; 0x12
lCPI0_15:
	.quad	99                              ; 0x63
	.quad	115                             ; 0x73
lCPI0_16:
	.quad	67                              ; 0x43
	.quad	83                              ; 0x53
lCPI0_17:
	.quad	35                              ; 0x23
	.quad	51                              ; 0x33
lCPI0_18:
	.quad	3                               ; 0x3
	.quad	19                              ; 0x13
lCPI0_19:
	.quad	100                             ; 0x64
	.quad	116                             ; 0x74
lCPI0_20:
	.quad	68                              ; 0x44
	.quad	84                              ; 0x54
lCPI0_21:
	.quad	36                              ; 0x24
	.quad	52                              ; 0x34
lCPI0_22:
	.quad	4                               ; 0x4
	.quad	20                              ; 0x14
lCPI0_23:
	.quad	101                             ; 0x65
	.quad	117                             ; 0x75
lCPI0_24:
	.quad	69                              ; 0x45
	.quad	85                              ; 0x55
lCPI0_25:
	.quad	37                              ; 0x25
	.quad	53                              ; 0x35
lCPI0_26:
	.quad	5                               ; 0x5
	.quad	21                              ; 0x15
lCPI0_27:
	.quad	102                             ; 0x66
	.quad	118                             ; 0x76
lCPI0_28:
	.quad	70                              ; 0x46
	.quad	86                              ; 0x56
lCPI0_29:
	.quad	38                              ; 0x26
	.quad	54                              ; 0x36
lCPI0_30:
	.quad	6                               ; 0x6
	.quad	22                              ; 0x16
lCPI0_31:
	.quad	103                             ; 0x67
	.quad	119                             ; 0x77
lCPI0_32:
	.quad	71                              ; 0x47
	.quad	87                              ; 0x57
lCPI0_33:
	.quad	39                              ; 0x27
	.quad	55                              ; 0x37
lCPI0_34:
	.quad	7                               ; 0x7
	.quad	23                              ; 0x17
lCPI0_35:
	.quad	104                             ; 0x68
	.quad	120                             ; 0x78
lCPI0_36:
	.quad	72                              ; 0x48
	.quad	88                              ; 0x58
lCPI0_37:
	.quad	40                              ; 0x28
	.quad	56                              ; 0x38
lCPI0_38:
	.quad	8                               ; 0x8
	.quad	24                              ; 0x18
lCPI0_39:
	.quad	105                             ; 0x69
	.quad	121                             ; 0x79
lCPI0_40:
	.quad	73                              ; 0x49
	.quad	89                              ; 0x59
lCPI0_41:
	.quad	41                              ; 0x29
	.quad	57                              ; 0x39
lCPI0_42:
	.quad	9                               ; 0x9
	.quad	25                              ; 0x19
lCPI0_43:
	.quad	106                             ; 0x6a
	.quad	122                             ; 0x7a
lCPI0_44:
	.quad	74                              ; 0x4a
	.quad	90                              ; 0x5a
lCPI0_45:
	.quad	42                              ; 0x2a
	.quad	58                              ; 0x3a
lCPI0_46:
	.quad	10                              ; 0xa
	.quad	26                              ; 0x1a
lCPI0_47:
	.quad	107                             ; 0x6b
	.quad	123                             ; 0x7b
lCPI0_48:
	.quad	75                              ; 0x4b
	.quad	91                              ; 0x5b
lCPI0_49:
	.quad	43                              ; 0x2b
	.quad	59                              ; 0x3b
lCPI0_50:
	.quad	11                              ; 0xb
	.quad	27                              ; 0x1b
lCPI0_51:
	.quad	108                             ; 0x6c
	.quad	124                             ; 0x7c
lCPI0_52:
	.quad	76                              ; 0x4c
	.quad	92                              ; 0x5c
lCPI0_53:
	.quad	44                              ; 0x2c
	.quad	60                              ; 0x3c
lCPI0_54:
	.quad	12                              ; 0xc
	.quad	28                              ; 0x1c
lCPI0_55:
	.quad	109                             ; 0x6d
	.quad	125                             ; 0x7d
lCPI0_56:
	.quad	77                              ; 0x4d
	.quad	93                              ; 0x5d
lCPI0_57:
	.quad	45                              ; 0x2d
	.quad	61                              ; 0x3d
lCPI0_58:
	.quad	13                              ; 0xd
	.quad	29                              ; 0x1d
lCPI0_59:
	.quad	110                             ; 0x6e
	.quad	126                             ; 0x7e
lCPI0_60:
	.quad	78                              ; 0x4e
	.quad	94                              ; 0x5e
lCPI0_61:
	.quad	46                              ; 0x2e
	.quad	62                              ; 0x3e
lCPI0_62:
	.quad	14                              ; 0xe
	.quad	30                              ; 0x1e
lCPI0_63:
	.quad	111                             ; 0x6f
	.quad	127                             ; 0x7f
lCPI0_64:
	.quad	79                              ; 0x4f
	.quad	95                              ; 0x5f
lCPI0_65:
	.quad	47                              ; 0x2f
	.quad	63                              ; 0x3f
lCPI0_66:
	.quad	15                              ; 0xf
	.quad	31                              ; 0x1f
lCPI0_67:
	.quad	768                             ; 0x300
	.quad	896                             ; 0x380
lCPI0_68:
	.quad	256                             ; 0x100
	.quad	384                             ; 0x180
lCPI0_69:
	.quad	512                             ; 0x200
	.quad	640                             ; 0x280
lCPI0_70:
	.quad	0                               ; 0x0
	.quad	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	dup.4s	v19, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q20, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q18, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v19, v18
	cmhi.4s	v1, v19, v20
	uzp1.8h	v21, v1, v0
	umaxv.8h	h2, v21
	fmov	w8, s2
	tbz	w8, #0, LBB0_404
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #1600
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	ldr	x11, [x1, #136]
	add	x8, x11, #2, lsl #12            ; =8192
	add	x3, x11, #8, lsl #12            ; =32768
	add	x13, x11, #12, lsl #12          ; =49152
	add	x12, x11, #19, lsl #12          ; =77824
	dup.2d	v2, x12
	str	q2, [sp, #3584]                 ; 16-byte Spill
	add	x12, x11, #19, lsl #12          ; =77824
	add	x21, x12, #128
	add	x12, x11, #19, lsl #12          ; =77824
	add	x22, x12, #1152
	add	x12, x11, #19, lsl #12          ; =77824
	add	x12, x12, #1664
	dup.2d	v2, x12
	str	q2, [sp, #3552]                 ; 16-byte Spill
	add	x12, x11, #19, lsl #12          ; =77824
	add	x12, x12, #2688
	str	x12, [sp, #3544]                ; 8-byte Spill
	add	x12, x11, #20, lsl #12          ; =81920
	add	x12, x12, #2688
	str	x12, [sp, #3536]                ; 8-byte Spill
	add	x12, x11, #20, lsl #12          ; =81920
	add	x2, x12, #2944
	sshll.2d	v23, v1, #0
	sshll.2d	v4, v0, #0
	sshll2.2d	v10, v1, #0
	ldr	w12, [x1]
	ldr	w14, [x1, #36]
	add	w12, w14, w12, lsl #5
	dup.4s	v2, w12
	sshll2.2d	v11, v0, #0
	add.4s	v3, v2, v18
	add.4s	v2, v2, v20
	and.16b	v2, v1, v2
	and.16b	v3, v0, v3
	ushll2.2d	v6, v3, #0
	ushll2.2d	v7, v2, #0
	ushll.2d	v16, v3, #0
	ushll.2d	v17, v2, #0
	mov	w12, #56                        ; =0x38
	dup.2d	v24, x12
	add	x12, x11, #20, lsl #12          ; =81920
	add	x1, x12, #3200
	add	x12, x11, #21, lsl #12          ; =86016
	add	x12, x12, #3200
	str	x12, [sp, #3528]                ; 8-byte Spill
	add	x12, x11, #24, lsl #12          ; =98304
	add	x12, x12, #3200
	str	x12, [sp, #88]                  ; 8-byte Spill
	ldr	x12, [x0]
	ldr	x4, [x0, #16]
Lloh4:
	adrp	x14, lCPI0_2@PAGE
Lloh5:
	ldr	q22, [x14, lCPI0_2@PAGEOFF]
	ldr	x5, [x0, #32]
	ushll.2d	v25, v2, #3
	ushll.2d	v5, v3, #3
	ushll2.2d	v26, v2, #3
	ushll2.2d	v27, v3, #3
	and.16b	v2, v27, v24
	and.16b	v3, v26, v24
	ldr	x14, [x0, #48]
	str	x14, [sp, #80]                  ; 8-byte Spill
	and.16b	v29, v4, v5
	and.16b	v5, v5, v24
	and.16b	v4, v25, v24
	and.16b	v30, v11, v27
	and.16b	v31, v10, v26
	and.16b	v8, v23, v25
	b	LBB0_3
LBB0_2:                                 ; %else432
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x14, x11, x10, lsl #5
	ldp	q25, q26, [x14]
	bif.16b	v24, v26, v0
	bif.16b	v23, v25, v1
	stp	q23, q24, [x14]
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x9, #1024
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	and.16b	v23, v21, v22
	addv.8h	h9, v23
	lsr	x14, x10, #5
	dup.2d	v25, x14
	fmov	w14, s9
	add.2d	v23, v25, v8
	shl.2d	v23, v23, #7
	and	x15, x9, #0x7c
	dup.2d	v26, x15
	orr.16b	v23, v23, v26
	dup.2d	v27, x12
	add.2d	v28, v27, v23
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbz	w14, #0, LBB0_11
; %bb.4:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x15, d28
	ldr	s23, [x15]
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_12
LBB0_5:                                 ; %else414
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v28, v25, v31
	shl.2d	v28, v28, #7
	orr.16b	v28, v28, v26
	add.2d	v28, v27, v28
	tbz	w14, #2, LBB0_13
LBB0_6:                                 ; %cond.load416
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x15, d28
	ld1.s	{ v23 }[2], [x15]
	tbnz	w14, #3, LBB0_14
LBB0_7:                                 ; %else420
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v28, v25, v29
	shl.2d	v28, v28, #7
	orr.16b	v28, v28, v26
	add.2d	v28, v27, v28
	tbz	w14, #4, LBB0_15
LBB0_8:                                 ; %cond.load422
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x15, d28
	ld1.s	{ v24 }[0], [x15]
	tbnz	w14, #5, LBB0_16
LBB0_9:                                 ; %else426
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v25, v25, v30
	shl.2d	v25, v25, #7
	orr.16b	v25, v25, v26
	add.2d	v25, v27, v25
	tbz	w14, #6, LBB0_17
LBB0_10:                                ; %cond.load428
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x15, d25
	ld1.s	{ v24 }[2], [x15]
	tbz	w14, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_5
LBB0_12:                                ; %cond.load413
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x15, v28[1]
	ld1.s	{ v23 }[1], [x15]
	add.2d	v28, v25, v31
	shl.2d	v28, v28, #7
	orr.16b	v28, v28, v26
	add.2d	v28, v27, v28
	tbnz	w14, #2, LBB0_6
LBB0_13:                                ; %else417
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w14, #3, LBB0_7
LBB0_14:                                ; %cond.load419
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x15, v28[1]
	ld1.s	{ v23 }[3], [x15]
	add.2d	v28, v25, v29
	shl.2d	v28, v28, #7
	orr.16b	v28, v28, v26
	add.2d	v28, v27, v28
	tbnz	w14, #4, LBB0_8
LBB0_15:                                ; %else423
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w14, #5, LBB0_9
LBB0_16:                                ; %cond.load425
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x15, v28[1]
	ld1.s	{ v24 }[1], [x15]
	add.2d	v25, v25, v30
	shl.2d	v25, v25, #7
	orr.16b	v25, v25, v26
	add.2d	v25, v27, v25
	tbnz	w14, #6, LBB0_10
LBB0_17:                                ; %else429
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w14, #7, LBB0_2
LBB0_18:                                ; %cond.load431
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x14, v25[1]
	ld1.s	{ v24 }[3], [x14]
	b	LBB0_2
LBB0_19:                                ; %direct.true201.preheader
	str	q9, [sp, #9488]                 ; 16-byte Spill
	stp	q8, q31, [sp, #16]              ; 32-byte Folded Spill
	stp	q30, q29, [sp, #48]             ; 32-byte Folded Spill
	mov	x9, #0                          ; =0x0
	cmhs.4s	v18, v18, v19
	cmhs.4s	v19, v20, v19
LBB0_20:                                ; %direct.true201
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x8, x9
	ldp	q20, q21, [x10]
	and.16b	v21, v18, v21
	and.16b	v20, v19, v20
	stp	q20, q21, [x10]
	add	x9, x9, #32
	cmp	x9, #3, lsl #12                 ; =12288
	b.ne	LBB0_20
; %bb.21:                               ; %direct.false202
	sshll.2d	v20, v0, #0
	mov	x0, #0                          ; =0x0
	sshll.2d	v21, v1, #0
	ushr.2d	v17, v17, #4
	ushr.2d	v7, v7, #4
	ushr.2d	v16, v16, #4
	ushr.2d	v6, v6, #4
	mov.d	x9, v6[1]
	mov.d	x10, v16[1]
	fmov	x12, d16
	add	x12, x12, x12, lsl #7
	fmov	d16, x12
	add	x10, x10, x10, lsl #7
	mov.d	v16[1], x10
	fmov	x12, d6
	mov.d	x10, v7[1]
	fmov	x14, d7
	mov.d	x15, v17[1]
	fmov	x16, d17
	add	x16, x16, x16, lsl #7
	fmov	d6, x16
	add	x15, x15, x15, lsl #7
	mov.d	v6[1], x15
	and.16b	v22, v21, v6
	and.16b	v30, v20, v16
	mov	w15, #65                        ; =0x41
	dup.2d	v6, x15
	orr.16b	v7, v5, v6
	str	q7, [sp, #3456]                 ; 16-byte Spill
	orr.16b	v7, v3, v6
	str	q7, [sp, #3440]                 ; 16-byte Spill
	orr.16b	v7, v4, v6
	str	q7, [sp, #3424]                 ; 16-byte Spill
	orr.16b	v6, v2, v6
	str	q6, [sp, #3408]                 ; 16-byte Spill
	mov	w15, #66                        ; =0x42
	dup.2d	v6, x15
	orr.16b	v7, v5, v6
	str	q7, [sp, #3392]                 ; 16-byte Spill
	orr.16b	v7, v3, v6
	str	q7, [sp, #3376]                 ; 16-byte Spill
	orr.16b	v7, v4, v6
	str	q7, [sp, #3360]                 ; 16-byte Spill
	mov	w15, #67                        ; =0x43
	dup.2d	v7, x15
	orr.16b	v6, v2, v6
	str	q6, [sp, #3344]                 ; 16-byte Spill
	orr.16b	v6, v5, v7
	str	q6, [sp, #3328]                 ; 16-byte Spill
	orr.16b	v6, v3, v7
	str	q6, [sp, #3312]                 ; 16-byte Spill
	orr.16b	v6, v4, v7
	str	q6, [sp, #3296]                 ; 16-byte Spill
	orr.16b	v6, v2, v7
	str	q6, [sp, #3280]                 ; 16-byte Spill
	mov	w15, #68                        ; =0x44
	dup.2d	v6, x15
	orr.16b	v7, v5, v6
	str	q7, [sp, #3264]                 ; 16-byte Spill
	orr.16b	v7, v3, v6
	str	q7, [sp, #3248]                 ; 16-byte Spill
	orr.16b	v7, v4, v6
	str	q7, [sp, #3232]                 ; 16-byte Spill
	orr.16b	v6, v2, v6
	str	q6, [sp, #3216]                 ; 16-byte Spill
	mov	w15, #69                        ; =0x45
	dup.2d	v6, x15
	orr.16b	v7, v5, v6
	str	q7, [sp, #3200]                 ; 16-byte Spill
	orr.16b	v7, v3, v6
	str	q7, [sp, #3184]                 ; 16-byte Spill
	orr.16b	v7, v4, v6
	str	q7, [sp, #3168]                 ; 16-byte Spill
	orr.16b	v6, v2, v6
	str	q6, [sp, #3152]                 ; 16-byte Spill
	mov	w15, #70                        ; =0x46
	dup.2d	v6, x15
	orr.16b	v7, v5, v6
	str	q7, [sp, #3136]                 ; 16-byte Spill
	orr.16b	v7, v3, v6
	str	q7, [sp, #3120]                 ; 16-byte Spill
	orr.16b	v7, v4, v6
	str	q7, [sp, #3104]                 ; 16-byte Spill
	orr.16b	v6, v2, v6
	str	q6, [sp, #3088]                 ; 16-byte Spill
	mov	w15, #71                        ; =0x47
	mov	w16, #72                        ; =0x48
	dup.2d	v6, x15
	orr.16b	v7, v5, v6
	str	q7, [sp, #3072]                 ; 16-byte Spill
	orr.16b	v7, v3, v6
	str	q7, [sp, #3056]                 ; 16-byte Spill
	orr.16b	v7, v4, v6
	str	q7, [sp, #3040]                 ; 16-byte Spill
	orr.16b	v6, v2, v6
	str	q6, [sp, #3024]                 ; 16-byte Spill
	dup.2d	v6, x16
	add.2d	v5, v5, v6
	str	q5, [sp, #3008]                 ; 16-byte Spill
	add.2d	v3, v3, v6
	str	q3, [sp, #2992]                 ; 16-byte Spill
	add.2d	v3, v4, v6
	str	q3, [sp, #2976]                 ; 16-byte Spill
	add.2d	v2, v2, v6
	str	q2, [sp, #2960]                 ; 16-byte Spill
	uzp1.8h	v2, v19, v18
	add	x12, x12, x12, lsl #7
	add	x9, x9, x9, lsl #7
	add	x14, x14, x14, lsl #7
	add	x10, x10, x10, lsl #7
	mov	w15, #32800                     ; =0x8020
	add	x6, x11, x15
	add	x15, x11, #19, lsl #12          ; =77824
	add	x15, x15, #3200
	str	x15, [sp, #2952]                ; 8-byte Spill
	add	x15, x11, #19, lsl #12          ; =77824
	add	x15, x15, #3712
	str	x15, [sp, #2944]                ; 8-byte Spill
	add	x15, x11, #20, lsl #12          ; =81920
	add	x15, x15, #128
	str	x15, [sp, #2936]                ; 8-byte Spill
	fmov	d3, x12
	mov.d	v3[1], x9
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #640
	str	x9, [sp, #2928]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	fmov	d4, x14
	mov.d	v4[1], x10
	add	x9, x9, #1152
	str	x9, [sp, #2920]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x23, x9, #1664
	add	x9, x11, #20, lsl #12           ; =81920
	and.16b	v31, v10, v4
	and.16b	v8, v11, v3
	add	x24, x9, #2176
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #3232
	str	x9, [sp, #2872]                 ; 8-byte Spill
Lloh6:
	adrp	x9, lCPI0_7@PAGE
Lloh7:
	ldr	q3, [x9, lCPI0_7@PAGEOFF]
	ldr	q6, [sp, #3584]                 ; 16-byte Reload
	add.2d	v3, v6, v3
	str	q3, [sp, #2848]                 ; 16-byte Spill
	add	x9, x11, #22, lsl #12           ; =90112
	add	x9, x9, #672
	str	x9, [sp, #2840]                 ; 8-byte Spill
	mov	w9, #49184                      ; =0xc020
Lloh8:
	adrp	x10, lCPI0_8@PAGE
Lloh9:
	ldr	q3, [x10, lCPI0_8@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2816]                 ; 16-byte Spill
	add	x9, x11, x9
	str	x9, [sp, #2808]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #128
	str	x9, [sp, #2800]                 ; 8-byte Spill
Lloh10:
	adrp	x9, lCPI0_9@PAGE
Lloh11:
	ldr	q3, [x9, lCPI0_9@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2784]                 ; 16-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #192
	str	x9, [sp, #2776]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
Lloh12:
	adrp	x10, lCPI0_10@PAGE
Lloh13:
	ldr	q3, [x10, lCPI0_10@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2752]                 ; 16-byte Spill
	add	x9, x9, #256
	str	x9, [sp, #2744]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #320
	str	x9, [sp, #2736]                 ; 8-byte Spill
Lloh14:
	adrp	x9, lCPI0_11@PAGE
Lloh15:
	ldr	q3, [x9, lCPI0_11@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2720]                 ; 16-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #384
	str	x9, [sp, #2712]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
Lloh16:
	adrp	x10, lCPI0_12@PAGE
Lloh17:
	ldr	q3, [x10, lCPI0_12@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2688]                 ; 16-byte Spill
	add	x9, x9, #448
	str	x9, [sp, #2680]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #512
	str	x9, [sp, #2672]                 ; 8-byte Spill
Lloh18:
	adrp	x9, lCPI0_13@PAGE
Lloh19:
	ldr	q3, [x9, lCPI0_13@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2656]                 ; 16-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #576
	str	x9, [sp, #2648]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
Lloh20:
	adrp	x10, lCPI0_14@PAGE
Lloh21:
	ldr	q3, [x10, lCPI0_14@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2624]                 ; 16-byte Spill
	add	x9, x9, #640
	str	x9, [sp, #2616]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #704
	str	x9, [sp, #2608]                 ; 8-byte Spill
Lloh22:
	adrp	x9, lCPI0_15@PAGE
Lloh23:
	ldr	q3, [x9, lCPI0_15@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2592]                 ; 16-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #768
	str	x9, [sp, #2584]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
Lloh24:
	adrp	x10, lCPI0_16@PAGE
Lloh25:
	ldr	q3, [x10, lCPI0_16@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2560]                 ; 16-byte Spill
	add	x9, x9, #832
	str	x9, [sp, #2552]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #896
	str	x9, [sp, #2544]                 ; 8-byte Spill
Lloh26:
	adrp	x9, lCPI0_17@PAGE
Lloh27:
	ldr	q3, [x9, lCPI0_17@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2528]                 ; 16-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #960
	str	x9, [sp, #2520]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
Lloh28:
	adrp	x10, lCPI0_18@PAGE
Lloh29:
	ldr	q3, [x10, lCPI0_18@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2496]                 ; 16-byte Spill
	add	x9, x9, #1024
	str	x9, [sp, #2488]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #1088
	str	x9, [sp, #2480]                 ; 8-byte Spill
Lloh30:
	adrp	x9, lCPI0_19@PAGE
Lloh31:
	ldr	q3, [x9, lCPI0_19@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2464]                 ; 16-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #1152
	str	x9, [sp, #2456]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
Lloh32:
	adrp	x10, lCPI0_20@PAGE
Lloh33:
	ldr	q3, [x10, lCPI0_20@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2432]                 ; 16-byte Spill
	add	x9, x9, #1216
	str	x9, [sp, #2424]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #1280
	str	x9, [sp, #2416]                 ; 8-byte Spill
Lloh34:
	adrp	x9, lCPI0_21@PAGE
Lloh35:
	ldr	q3, [x9, lCPI0_21@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2400]                 ; 16-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #1344
	str	x9, [sp, #2392]                 ; 8-byte Spill
Lloh36:
	adrp	x9, lCPI0_22@PAGE
Lloh37:
	ldr	q3, [x9, lCPI0_22@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2368]                 ; 16-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #1408
	str	x9, [sp, #2360]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #1472
	str	x9, [sp, #2352]                 ; 8-byte Spill
Lloh38:
	adrp	x9, lCPI0_23@PAGE
Lloh39:
	ldr	q3, [x9, lCPI0_23@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2336]                 ; 16-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #1536
	str	x9, [sp, #2328]                 ; 8-byte Spill
Lloh40:
	adrp	x9, lCPI0_24@PAGE
Lloh41:
	ldr	q3, [x9, lCPI0_24@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2304]                 ; 16-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #1600
	str	x9, [sp, #2296]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2688
	str	x9, [sp, #2288]                 ; 8-byte Spill
Lloh42:
	adrp	x9, lCPI0_25@PAGE
Lloh43:
	ldr	q3, [x9, lCPI0_25@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2272]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2720
	str	x9, [sp, #2264]                 ; 8-byte Spill
Lloh44:
	adrp	x9, lCPI0_26@PAGE
Lloh45:
	ldr	q3, [x9, lCPI0_26@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2240]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2752
	str	x9, [sp, #2232]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2784
	str	x9, [sp, #2224]                 ; 8-byte Spill
Lloh46:
	adrp	x9, lCPI0_27@PAGE
Lloh47:
	ldr	q3, [x9, lCPI0_27@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2208]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2816
	str	x9, [sp, #2200]                 ; 8-byte Spill
Lloh48:
	adrp	x9, lCPI0_28@PAGE
Lloh49:
	ldr	q3, [x9, lCPI0_28@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2176]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2848
	str	x9, [sp, #2168]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2880
	str	x9, [sp, #2160]                 ; 8-byte Spill
Lloh50:
	adrp	x9, lCPI0_29@PAGE
Lloh51:
	ldr	q3, [x9, lCPI0_29@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2144]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2912
	str	x9, [sp, #2136]                 ; 8-byte Spill
Lloh52:
	adrp	x9, lCPI0_30@PAGE
Lloh53:
	ldr	q3, [x9, lCPI0_30@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2112]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2944
	str	x9, [sp, #2104]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2976
	str	x9, [sp, #2096]                 ; 8-byte Spill
Lloh54:
	adrp	x9, lCPI0_31@PAGE
Lloh55:
	ldr	q3, [x9, lCPI0_31@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2080]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3008
	str	x9, [sp, #2072]                 ; 8-byte Spill
Lloh56:
	adrp	x9, lCPI0_32@PAGE
Lloh57:
	ldr	q3, [x9, lCPI0_32@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2048]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3040
	str	x9, [sp, #2040]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3072
	str	x9, [sp, #2032]                 ; 8-byte Spill
Lloh58:
	adrp	x9, lCPI0_33@PAGE
Lloh59:
	ldr	q3, [x9, lCPI0_33@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #2016]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3104
	str	x9, [sp, #2008]                 ; 8-byte Spill
Lloh60:
	adrp	x9, lCPI0_34@PAGE
Lloh61:
	ldr	q3, [x9, lCPI0_34@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1984]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3136
	str	x9, [sp, #1976]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3168
	str	x9, [sp, #1968]                 ; 8-byte Spill
Lloh62:
	adrp	x9, lCPI0_35@PAGE
Lloh63:
	ldr	q3, [x9, lCPI0_35@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1952]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3200
	str	x9, [sp, #1944]                 ; 8-byte Spill
Lloh64:
	adrp	x9, lCPI0_36@PAGE
Lloh65:
	ldr	q3, [x9, lCPI0_36@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1920]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3232
	str	x9, [sp, #1912]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3264
	str	x9, [sp, #1904]                 ; 8-byte Spill
Lloh66:
	adrp	x9, lCPI0_37@PAGE
Lloh67:
	ldr	q3, [x9, lCPI0_37@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1888]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3296
	str	x9, [sp, #1880]                 ; 8-byte Spill
Lloh68:
	adrp	x9, lCPI0_38@PAGE
Lloh69:
	ldr	q3, [x9, lCPI0_38@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1856]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3328
	str	x9, [sp, #1848]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3360
	str	x9, [sp, #1840]                 ; 8-byte Spill
Lloh70:
	adrp	x9, lCPI0_39@PAGE
Lloh71:
	ldr	q3, [x9, lCPI0_39@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1824]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3392
	str	x9, [sp, #1816]                 ; 8-byte Spill
Lloh72:
	adrp	x9, lCPI0_40@PAGE
Lloh73:
	ldr	q3, [x9, lCPI0_40@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1792]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3424
	str	x9, [sp, #1784]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3456
	str	x9, [sp, #1776]                 ; 8-byte Spill
Lloh74:
	adrp	x9, lCPI0_41@PAGE
Lloh75:
	ldr	q3, [x9, lCPI0_41@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1760]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3488
	str	x9, [sp, #1752]                 ; 8-byte Spill
Lloh76:
	adrp	x9, lCPI0_42@PAGE
Lloh77:
	ldr	q3, [x9, lCPI0_42@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1728]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3520
	str	x9, [sp, #1720]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3552
	str	x9, [sp, #1712]                 ; 8-byte Spill
Lloh78:
	adrp	x9, lCPI0_43@PAGE
Lloh79:
	ldr	q3, [x9, lCPI0_43@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1696]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3584
	str	x9, [sp, #1688]                 ; 8-byte Spill
Lloh80:
	adrp	x9, lCPI0_44@PAGE
Lloh81:
	ldr	q3, [x9, lCPI0_44@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1664]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3616
	str	x9, [sp, #1656]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3648
	str	x9, [sp, #1648]                 ; 8-byte Spill
Lloh82:
	adrp	x9, lCPI0_45@PAGE
Lloh83:
	ldr	q3, [x9, lCPI0_45@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1632]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3680
	str	x9, [sp, #1624]                 ; 8-byte Spill
Lloh84:
	adrp	x9, lCPI0_46@PAGE
Lloh85:
	ldr	q3, [x9, lCPI0_46@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1600]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3712
	str	x9, [sp, #1592]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3744
	str	x9, [sp, #1584]                 ; 8-byte Spill
Lloh86:
	adrp	x9, lCPI0_47@PAGE
Lloh87:
	ldr	q3, [x9, lCPI0_47@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1568]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3776
	str	x9, [sp, #1560]                 ; 8-byte Spill
Lloh88:
	adrp	x9, lCPI0_48@PAGE
Lloh89:
	ldr	q3, [x9, lCPI0_48@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1536]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3808
	str	x9, [sp, #1528]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3840
	str	x9, [sp, #1520]                 ; 8-byte Spill
Lloh90:
	adrp	x9, lCPI0_49@PAGE
Lloh91:
	ldr	q3, [x9, lCPI0_49@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1504]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3872
	str	x9, [sp, #1496]                 ; 8-byte Spill
Lloh92:
	adrp	x9, lCPI0_50@PAGE
Lloh93:
	ldr	q3, [x9, lCPI0_50@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1472]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3904
	str	x9, [sp, #1464]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3936
	str	x9, [sp, #1456]                 ; 8-byte Spill
Lloh94:
	adrp	x9, lCPI0_51@PAGE
Lloh95:
	ldr	q3, [x9, lCPI0_51@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1440]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3968
	str	x9, [sp, #1432]                 ; 8-byte Spill
Lloh96:
	adrp	x9, lCPI0_52@PAGE
Lloh97:
	ldr	q3, [x9, lCPI0_52@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1408]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #4000
	str	x9, [sp, #1400]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #4032
	str	x9, [sp, #1392]                 ; 8-byte Spill
Lloh98:
	adrp	x9, lCPI0_53@PAGE
Lloh99:
	ldr	q3, [x9, lCPI0_53@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1376]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #4064
	str	x9, [sp, #1368]                 ; 8-byte Spill
Lloh100:
	adrp	x9, lCPI0_54@PAGE
Lloh101:
	ldr	q3, [x9, lCPI0_54@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1344]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #32
	str	x9, [sp, #1336]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #64
	str	x9, [sp, #1328]                 ; 8-byte Spill
Lloh102:
	adrp	x9, lCPI0_55@PAGE
Lloh103:
	ldr	q3, [x9, lCPI0_55@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1312]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #96
	str	x9, [sp, #1304]                 ; 8-byte Spill
Lloh104:
	adrp	x9, lCPI0_56@PAGE
Lloh105:
	ldr	q3, [x9, lCPI0_56@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1280]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #128
	str	x9, [sp, #1272]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #160
	str	x9, [sp, #1264]                 ; 8-byte Spill
Lloh106:
	adrp	x9, lCPI0_57@PAGE
Lloh107:
	ldr	q3, [x9, lCPI0_57@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1248]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #192
	str	x9, [sp, #1240]                 ; 8-byte Spill
Lloh108:
	adrp	x9, lCPI0_58@PAGE
Lloh109:
	ldr	q3, [x9, lCPI0_58@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1216]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #224
	str	x9, [sp, #1208]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #256
	str	x9, [sp, #1200]                 ; 8-byte Spill
Lloh110:
	adrp	x9, lCPI0_59@PAGE
Lloh111:
	ldr	q3, [x9, lCPI0_59@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1184]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #288
	str	x9, [sp, #1176]                 ; 8-byte Spill
Lloh112:
	adrp	x9, lCPI0_60@PAGE
Lloh113:
	ldr	q3, [x9, lCPI0_60@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1152]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #320
	str	x9, [sp, #1144]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #352
	str	x9, [sp, #1136]                 ; 8-byte Spill
Lloh114:
	adrp	x9, lCPI0_61@PAGE
Lloh115:
	ldr	q3, [x9, lCPI0_61@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1120]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #384
	str	x9, [sp, #1112]                 ; 8-byte Spill
Lloh116:
	adrp	x9, lCPI0_62@PAGE
Lloh117:
	ldr	q3, [x9, lCPI0_62@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1088]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #416
	str	x9, [sp, #1080]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #448
	str	x9, [sp, #1072]                 ; 8-byte Spill
Lloh118:
	adrp	x9, lCPI0_63@PAGE
Lloh119:
	ldr	q3, [x9, lCPI0_63@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1056]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #480
	str	x9, [sp, #1048]                 ; 8-byte Spill
Lloh120:
	adrp	x9, lCPI0_64@PAGE
Lloh121:
	ldr	q3, [x9, lCPI0_64@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #1024]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #512
	str	x9, [sp, #1016]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #544
	str	x9, [sp, #1008]                 ; 8-byte Spill
Lloh122:
	adrp	x9, lCPI0_65@PAGE
Lloh123:
	ldr	q3, [x9, lCPI0_65@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #992]                  ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #576
	str	x9, [sp, #984]                  ; 8-byte Spill
Lloh124:
	adrp	x9, lCPI0_66@PAGE
Lloh125:
	ldr	q3, [x9, lCPI0_66@PAGEOFF]
	add.2d	v3, v6, v3
	str	q3, [sp, #960]                  ; 16-byte Spill
	xtn.8b	v2, v2
	str	d2, [sp, #952]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #608
	str	x9, [sp, #944]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #640
	str	x9, [sp, #936]                  ; 8-byte Spill
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	str	q2, [sp, #9744]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #672
	str	x9, [sp, #928]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #704
	str	x9, [sp, #920]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #736
	str	x9, [sp, #912]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #768
	str	x9, [sp, #904]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #800
	str	x9, [sp, #896]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #832
	str	x9, [sp, #888]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #864
	str	x9, [sp, #880]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #896
	str	x9, [sp, #872]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #928
	str	x9, [sp, #864]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #960
	str	x9, [sp, #856]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #992
	str	x9, [sp, #848]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1024
	str	x9, [sp, #840]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1056
	str	x9, [sp, #832]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1088
	str	x9, [sp, #824]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1120
	str	x9, [sp, #816]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1152
	str	x9, [sp, #808]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1184
	str	x9, [sp, #800]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1216
	str	x9, [sp, #792]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1248
	str	x9, [sp, #784]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1280
	str	x9, [sp, #776]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1312
	str	x9, [sp, #768]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1344
	str	x9, [sp, #760]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1376
	str	x9, [sp, #752]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1408
	str	x9, [sp, #744]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1440
	str	x9, [sp, #736]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1472
	str	x9, [sp, #728]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1504
	str	x9, [sp, #720]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1536
	str	x9, [sp, #712]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1568
	str	x9, [sp, #704]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1600
	str	x9, [sp, #696]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1632
	str	x9, [sp, #688]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1664
	str	x9, [sp, #680]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1696
	str	x9, [sp, #672]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1728
	str	x9, [sp, #664]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1760
	str	x9, [sp, #656]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1792
	str	x9, [sp, #648]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1824
	str	x9, [sp, #640]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1856
	str	x9, [sp, #632]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1888
	str	x9, [sp, #624]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1920
	str	x9, [sp, #616]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1952
	str	x9, [sp, #608]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1984
	str	x9, [sp, #600]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2016
	str	x9, [sp, #592]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2048
	str	x9, [sp, #584]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2080
	str	x9, [sp, #576]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2112
	str	x9, [sp, #568]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2144
	str	x9, [sp, #560]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2176
	str	x9, [sp, #552]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2208
	str	x9, [sp, #544]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2240
	str	x9, [sp, #536]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2272
	str	x9, [sp, #528]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2304
	str	x9, [sp, #520]                  ; 8-byte Spill
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #9728]                 ; 16-byte Spill
	str	q2, [sp, #9712]                 ; 16-byte Spill
	str	q2, [sp, #8576]                 ; 16-byte Spill
	str	q2, [sp, #8560]                 ; 16-byte Spill
	str	q2, [sp, #8544]                 ; 16-byte Spill
	str	q2, [sp, #8528]                 ; 16-byte Spill
	str	q2, [sp, #9696]                 ; 16-byte Spill
	str	q2, [sp, #9680]                 ; 16-byte Spill
	str	q2, [sp, #8512]                 ; 16-byte Spill
	str	q2, [sp, #8496]                 ; 16-byte Spill
	str	q2, [sp, #8480]                 ; 16-byte Spill
	str	q2, [sp, #8464]                 ; 16-byte Spill
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	str	q2, [sp, #8384]                 ; 16-byte Spill
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v7, #0000000000000000
	str	q7, [sp, #9248]                 ; 16-byte Spill
	str	q7, [sp, #9232]                 ; 16-byte Spill
	str	q7, [sp, #8448]                 ; 16-byte Spill
	str	q7, [sp, #8432]                 ; 16-byte Spill
	str	q7, [sp, #8416]                 ; 16-byte Spill
	str	q7, [sp, #8400]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	str	q7, [sp, #9216]                 ; 16-byte Spill
	str	q7, [sp, #9200]                 ; 16-byte Spill
	str	q7, [sp, #9184]                 ; 16-byte Spill
	str	q7, [sp, #9168]                 ; 16-byte Spill
	str	q7, [sp, #9152]                 ; 16-byte Spill
	add	x10, x9, #2336
	str	q7, [sp, #9136]                 ; 16-byte Spill
	str	q7, [sp, #9120]                 ; 16-byte Spill
	str	q7, [sp, #9104]                 ; 16-byte Spill
	str	q7, [sp, #9088]                 ; 16-byte Spill
	str	q7, [sp, #9072]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2368
	stp	x9, x10, [sp, #504]             ; 16-byte Folded Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2400
	str	x9, [sp, #496]                  ; 8-byte Spill
Lloh126:
	adrp	x9, lCPI0_68@PAGE
Lloh127:
	adrp	x10, lCPI0_69@PAGE
Lloh128:
	adrp	x12, lCPI0_70@PAGE
Lloh129:
	adrp	x14, lCPI0_67@PAGE
Lloh130:
	ldr	q7, [x14, lCPI0_67@PAGEOFF]
	str	q7, [sp, #480]                  ; 16-byte Spill
Lloh131:
	ldr	q7, [x9, lCPI0_68@PAGEOFF]
	str	q7, [sp, #464]                  ; 16-byte Spill
Lloh132:
	ldr	q7, [x10, lCPI0_69@PAGEOFF]
	str	q7, [sp, #448]                  ; 16-byte Spill
Lloh133:
	ldr	q7, [x12, lCPI0_70@PAGEOFF]
	str	q7, [sp, #432]                  ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x10, x9, #2432
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2464
	stp	x9, x10, [sp, #416]             ; 16-byte Folded Spill
	add	x9, x11, #21, lsl #12           ; =86016
	movi.2d	v7, #0000000000000000
	add	x10, x9, #2496
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2528
	stp	x9, x10, [sp, #400]             ; 16-byte Folded Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x10, x9, #2560
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2592
	stp	x9, x10, [sp, #384]             ; 16-byte Folded Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x10, x9, #2624
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2656
	stp	x9, x10, [sp, #368]             ; 16-byte Folded Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x10, x9, #2688
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2720
	stp	x9, x10, [sp, #352]             ; 16-byte Folded Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x10, x9, #2752
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2784
	stp	x9, x10, [sp, #336]             ; 16-byte Folded Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x10, x9, #2816
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2848
	stp	x9, x10, [sp, #320]             ; 16-byte Folded Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x10, x9, #2880
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2912
	stp	x9, x10, [sp, #304]             ; 16-byte Folded Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x10, x9, #2944
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2976
	stp	x9, x10, [sp, #288]             ; 16-byte Folded Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x10, x9, #3008
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #3040
	stp	x9, x10, [sp, #272]             ; 16-byte Folded Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x10, x9, #3072
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #3104
	stp	x9, x10, [sp, #256]             ; 16-byte Folded Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x10, x9, #3136
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #3168
	stp	x9, x10, [sp, #240]             ; 16-byte Folded Spill
	mov	w12, #62154                     ; =0xf2ca
	movk	w12, #61769, lsl #16
Lloh134:
	adrp	x14, lCPI0_3@PAGE
Lloh135:
	adrp	x15, lCPI0_4@PAGE
Lloh136:
	adrp	x16, lCPI0_5@PAGE
Lloh137:
	adrp	x17, lCPI0_6@PAGE
	mov	w7, #43691                      ; =0xaaab
	mov	w27, #48                        ; =0x30
	mov	x9, #-6148914691236517206       ; =0xaaaaaaaaaaaaaaaa
	movk	x9, #43691
	mov	x10, #-1536                     ; =0xfffffffffffffa00
	dup.4s	v17, w12
Lloh138:
	ldr	q18, [x14, lCPI0_3@PAGEOFF]
Lloh139:
	ldr	q19, [x15, lCPI0_4@PAGEOFF]
Lloh140:
	ldr	q20, [x16, lCPI0_5@PAGEOFF]
Lloh141:
	ldr	q21, [x17, lCPI0_6@PAGEOFF]
	and.16b	v26, v0, v17
	stp	q18, q17, [sp, #208]            ; 32-byte Folded Spill
	and.16b	v17, v1, v17
	add.2d	v27, v6, v18
	stp	q20, q19, [sp, #176]            ; 32-byte Folded Spill
	add.2d	v18, v6, v19
	stp	q18, q27, [sp, #128]            ; 32-byte Folded Spill
	add.2d	v18, v6, v20
	str	q21, [sp, #160]                 ; 16-byte Spill
	add.2d	v6, v6, v21
	stp	q6, q18, [sp, #96]              ; 32-byte Folded Spill
	movi.2d	v6, #0000000000000000
	str	q6, [sp, #9664]                 ; 16-byte Spill
	str	q6, [sp, #9648]                 ; 16-byte Spill
	str	q6, [sp, #9632]                 ; 16-byte Spill
	str	q6, [sp, #9616]                 ; 16-byte Spill
	str	q6, [sp, #8368]                 ; 16-byte Spill
	str	q6, [sp, #9600]                 ; 16-byte Spill
	str	q6, [sp, #9584]                 ; 16-byte Spill
	str	q6, [sp, #9568]                 ; 16-byte Spill
	str	q6, [sp, #9552]                 ; 16-byte Spill
	str	q6, [sp, #9536]                 ; 16-byte Spill
	str	q6, [sp, #9520]                 ; 16-byte Spill
	str	q6, [sp, #9504]                 ; 16-byte Spill
	movi.2d	v9, #0000000000000000
	movi.2d	v14, #0000000000000000
	str	q6, [sp, #8352]                 ; 16-byte Spill
	str	q6, [sp, #8336]                 ; 16-byte Spill
	str	q6, [sp, #8320]                 ; 16-byte Spill
	str	q6, [sp, #8304]                 ; 16-byte Spill
	movi.2d	v21, #0000000000000000
	str	q6, [sp, #8288]                 ; 16-byte Spill
	str	q6, [sp, #8272]                 ; 16-byte Spill
	str	q6, [sp, #8256]                 ; 16-byte Spill
	str	q6, [sp, #8240]                 ; 16-byte Spill
	str	q6, [sp, #8224]                 ; 16-byte Spill
	str	q6, [sp, #8208]                 ; 16-byte Spill
	str	q2, [sp, #8192]                 ; 16-byte Spill
	str	q2, [sp, #8176]                 ; 16-byte Spill
	str	q2, [sp, #8160]                 ; 16-byte Spill
	str	q2, [sp, #8144]                 ; 16-byte Spill
	str	q2, [sp, #8128]                 ; 16-byte Spill
	str	q2, [sp, #8112]                 ; 16-byte Spill
	str	q2, [sp, #8096]                 ; 16-byte Spill
	str	q2, [sp, #8080]                 ; 16-byte Spill
	str	q2, [sp, #8064]                 ; 16-byte Spill
	str	q17, [sp, #9440]                ; 16-byte Spill
	str	q26, [sp, #9424]                ; 16-byte Spill
	str	q2, [sp, #8048]                 ; 16-byte Spill
	str	q2, [sp, #8032]                 ; 16-byte Spill
	str	q17, [sp, #9408]                ; 16-byte Spill
	str	q26, [sp, #9392]                ; 16-byte Spill
	str	q17, [sp, #9376]                ; 16-byte Spill
	str	q26, [sp, #9360]                ; 16-byte Spill
	str	q2, [sp, #8016]                 ; 16-byte Spill
	str	q2, [sp, #8000]                 ; 16-byte Spill
	str	q2, [sp, #7984]                 ; 16-byte Spill
	str	q17, [sp, #9344]                ; 16-byte Spill
	str	q26, [sp, #9328]                ; 16-byte Spill
	str	q17, [sp, #9312]                ; 16-byte Spill
	str	q26, [sp, #9296]                ; 16-byte Spill
	str	q2, [sp, #7968]                 ; 16-byte Spill
	str	q17, [sp, #9280]                ; 16-byte Spill
	str	q26, [sp, #9264]                ; 16-byte Spill
	str	q17, [sp, #9456]                ; 16-byte Spill
	str	q17, [sp, #9056]                ; 16-byte Spill
	str	q26, [sp, #9472]                ; 16-byte Spill
	str	q26, [sp, #9040]                ; 16-byte Spill
	str	x21, [sp, #3576]                ; 8-byte Spill
	str	x22, [sp, #3568]                ; 8-byte Spill
	str	q10, [sp, #8608]                ; 16-byte Spill
	str	q11, [sp, #8592]                ; 16-byte Spill
	str	x4, [sp, #3520]                 ; 8-byte Spill
	str	x5, [sp, #3512]                 ; 8-byte Spill
	str	q22, [sp, #3488]                ; 16-byte Spill
	str	q30, [sp, #3472]                ; 16-byte Spill
	str	q31, [sp, #2896]                ; 16-byte Spill
	str	q8, [sp, #2880]                 ; 16-byte Spill
LBB0_22:                                ; %direct.true211
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_28 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;       Child Loop BB0_32 Depth 3
                                        ;     Child Loop BB0_292 Depth 2
                                        ;     Child Loop BB0_326 Depth 2
                                        ;     Child Loop BB0_343 Depth 2
                                        ;     Child Loop BB0_345 Depth 2
                                        ;     Child Loop BB0_347 Depth 2
                                        ;     Child Loop BB0_349 Depth 2
                                        ;     Child Loop BB0_351 Depth 2
                                        ;     Child Loop BB0_353 Depth 2
                                        ;     Child Loop BB0_355 Depth 2
                                        ;     Child Loop BB0_357 Depth 2
                                        ;     Child Loop BB0_360 Depth 2
                                        ;     Child Loop BB0_377 Depth 2
                                        ;       Child Loop BB0_378 Depth 3
                                        ;     Child Loop BB0_381 Depth 2
                                        ;     Child Loop BB0_383 Depth 2
	mov	x12, #0                         ; =0x0
	lsl	x25, x0, #4
	ldr	q27, [sp, #8288]                ; 16-byte Reload
	ldr	q28, [sp, #8272]                ; 16-byte Reload
	ldr	q29, [sp, #8256]                ; 16-byte Reload
	ldr	q12, [sp, #8240]                ; 16-byte Reload
	ldr	q13, [sp, #8224]                ; 16-byte Reload
	b	LBB0_24
LBB0_23:                                ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_24 Depth=2
	sshll.2d	v19, v0, #0
	add.2d	v20, v18, v8
	add.2d	v26, v18, v31
	add.2d	v18, v18, v30
	shl.2d	v18, v18, #5
	shl.2d	v26, v26, #5
	shl.2d	v20, v20, #5
	orr.16b	v20, v20, v17
	orr.16b	v26, v26, v17
	orr.16b	v17, v18, v17
	bit.16b	v12, v17, v19
	bit.16b	v29, v26, v10
	bit.16b	v13, v20, v11
	bit.16b	v27, v6, v0
	bit.16b	v21, v6, v1
	add	x14, x3, x12, lsl #5
	ldp	q17, q18, [x14]
	bit.16b	v18, v6, v0
	bif.16b	v6, v17, v1
	stp	q6, q18, [x14]
	add	x12, x12, #1
	cmp	x12, #512
	b.eq	LBB0_26
LBB0_24:                                ; %direct.true215
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v6, v1, #0
	and	x14, x12, #0x1f
	orr	x15, x25, x12, lsr #5
	dup.2d	v18, x15
	add.2d	v17, v18, v22
	shl.2d	v19, v17, #5
	dup.2d	v17, x14
	orr.16b	v19, v19, v17
	bit.16b	v28, v19, v6
	movi.2d	v6, #0000000000000000
	cmp	x15, #128
	b.hi	LBB0_23
; %bb.25:                               ; %direct.true225
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x14, d28
	add	x14, x4, x14, lsl #2
	ld1r.4s	{ v6 }, [x14]
	b	LBB0_23
LBB0_26:                                ; %direct.true239.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q12, [sp, #8240]                ; 16-byte Spill
	str	q29, [sp, #8256]                ; 16-byte Spill
	str	q28, [sp, #8272]                ; 16-byte Spill
	str	q27, [sp, #8288]                ; 16-byte Spill
	str	q21, [sp, #7856]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q21, [sp, #9488]                ; 16-byte Reload
	ldr	q27, [sp, #8352]                ; 16-byte Reload
	ldr	q28, [sp, #8336]                ; 16-byte Reload
	ldr	q29, [sp, #8320]                ; 16-byte Reload
	ldr	q12, [sp, #8304]                ; 16-byte Reload
	movi.8b	v2, #1
	b	LBB0_28
LBB0_27:                                ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_28 Depth=2
	add.2d	v19, v18, v31
	add.2d	v20, v18, v30
	add.2d	v18, v18, v8
	mov.d	x14, v18[1]
	fmov	x15, d18
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d18, x15
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	mov.d	v18[1], x14
	mov.d	x14, v20[1]
	fmov	x15, d20
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d20, x15
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	mov.d	v20[1], x14
	mov.d	x14, v19[1]
	fmov	x15, d19
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d19, x15
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	mov.d	v19[1], x14
	sshll.2d	v26, v0, #0
	add.2d	v19, v19, v17
	add.2d	v20, v20, v17
	add.2d	v17, v18, v17
	bit.16b	v12, v17, v11
	bit.16b	v29, v20, v26
	bit.16b	v28, v19, v10
	bit.16b	v14, v6, v0
	bit.16b	v9, v6, v1
	add	x14, x13, x12, lsl #5
	ldp	q17, q18, [x14]
	bit.16b	v18, v6, v0
	bif.16b	v6, v17, v1
	stp	q6, q18, [x14]
	add	x12, x12, #1
	cmp	x12, #768
	b.eq	LBB0_30
LBB0_28:                                ; %direct.true239
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w14, w12, #0xffff
	mul	w14, w14, w7
	lsr	w14, w14, #21
	add	x15, x25, x14
	dup.2d	v18, x15
	add.2d	v6, v18, v22
	mov.d	x16, v6[1]
	fmov	x17, d6
	add	x17, x17, x17, lsl #1
	lsl	x17, x17, #4
	fmov	d6, x17
	sshll.2d	v19, v1, #0
	msub	w14, w14, w27, w12
	and	x14, x14, #0xffff
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #4
	mov.d	v6[1], x16
	dup.2d	v17, x14
	add.2d	v6, v6, v17
	bit.16b	v27, v6, v19
	movi.2d	v6, #0000000000000000
	cmp	x15, #128
	b.hi	LBB0_27
; %bb.29:                               ; %direct.true249
                                        ;   in Loop: Header=BB0_28 Depth=2
	fmov	x14, d27
	add	x14, x5, x14, lsl #2
	ld1r.4s	{ v6 }, [x14]
	b	LBB0_27
LBB0_30:                                ; %direct.schedule.21.preheader.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q13, [sp, #8224]                ; 16-byte Spill
	str	q12, [sp, #8304]                ; 16-byte Spill
	str	q29, [sp, #8320]                ; 16-byte Spill
	str	q28, [sp, #8336]                ; 16-byte Spill
	str	q27, [sp, #8352]                ; 16-byte Spill
	str	q14, [sp, #7872]                ; 16-byte Spill
	str	q9, [sp, #7888]                 ; 16-byte Spill
	str	x0, [sp, #7960]                 ; 8-byte Spill
	mov	x12, #0                         ; =0x0
	mov	w0, #1024                       ; =0x400
	mov	w28, #8192                      ; =0x2000
	movk	w28, #1, lsl #16
LBB0_31:                                ; %direct.schedule.21.preheader
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_32 Depth 3
	mov	x26, #-16384                    ; =0xffffffffffffc000
	mov	x4, x0
	mov	x5, x28
	add	x30, x11, x12, lsl #11
LBB0_32:                                ; %direct.true267
                                        ;   Parent Loop BB0_22 Depth=1
                                        ;     Parent Loop BB0_31 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q6, q17, [x30]
	and.16b	v17, v0, v17
	and.16b	v6, v1, v6
	and	x14, x4, #0x1c00
	add	x14, x11, x14
	ldp	q19, q18, [x14]
	and.16b	v19, v1, v19
	and.16b	v18, v0, v18
	add	x15, x6, x26
	add	x3, x11, x26
	prfm	pldl1keep, [x15, #18400]
	ldr	q20, [x3, #49168]
	and.16b	v20, v0, v20
	ldr	q26, [x3, #49152]
	and.16b	v26, v1, v26
	prfm	pldl1keep, [x15, #19424]
	ldr	q27, [x3, #50176]
	and.16b	v27, v1, v27
	ldr	q28, [x3, #50192]
	and.16b	v28, v0, v28
	fmul.4s	v29, v6, v26
	fmul.4s	v10, v17, v20
	fadd.4s	v10, v10, v7
	fadd.4s	v29, v29, v7
	fmul.4s	v17, v17, v28
	fmul.4s	v6, v6, v27
	fadd.4s	v6, v6, v7
	fadd.4s	v17, v17, v7
	fmul.4s	v20, v18, v20
	fmul.4s	v26, v19, v26
	fadd.4s	v26, v26, v7
	fadd.4s	v20, v20, v7
	fmul.4s	v18, v18, v28
	fmul.4s	v19, v19, v27
	fadd.4s	v19, v19, v7
	fadd.4s	v18, v18, v7
	ldp	q28, q27, [x30, #32]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q11, q12, [x14, #32]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	ldr	q13, [x3, #49200]
	ldr	q30, [x3, #49184]
	and.16b	v30, v1, v30
	and.16b	v13, v0, v13
	ldr	q31, [x3, #50208]
	ldr	q8, [x3, #50224]
	and.16b	v8, v0, v8
	and.16b	v31, v1, v31
	fmul.4s	v9, v27, v13
	fmul.4s	v14, v28, v30
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v10, v9
	fmul.4s	v28, v28, v31
	fmul.4s	v27, v27, v8
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v11, v30
	fmul.4s	v28, v12, v13
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v11, v31
	fmul.4s	v28, v12, v8
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #64]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #64]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #18464]
	ldr	q8, [x3, #49216]
	ldr	q10, [x3, #49232]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #19488]
	ldr	q11, [x3, #50256]
	ldr	q12, [x3, #50240]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #96]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #96]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #49264]
	ldr	q10, [x3, #49248]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #50272]
	ldr	q12, [x3, #50288]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #128]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #128]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #18528]
	ldr	q8, [x3, #49280]
	ldr	q10, [x3, #49296]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #19552]
	ldr	q11, [x3, #50320]
	ldr	q12, [x3, #50304]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #160]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #160]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #49328]
	ldr	q10, [x3, #49312]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #50336]
	ldr	q12, [x3, #50352]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #192]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #192]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #18592]
	ldr	q8, [x3, #49344]
	ldr	q10, [x3, #49360]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #19616]
	ldr	q11, [x3, #50384]
	ldr	q12, [x3, #50368]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #224]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #224]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #49392]
	ldr	q10, [x3, #49376]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #50400]
	ldr	q12, [x3, #50416]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #256]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #256]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #18656]
	ldr	q8, [x3, #49408]
	ldr	q10, [x3, #49424]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #19680]
	ldr	q11, [x3, #50448]
	ldr	q12, [x3, #50432]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #288]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #288]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #49456]
	ldr	q10, [x3, #49440]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #50464]
	ldr	q12, [x3, #50480]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #320]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #320]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #18720]
	ldr	q8, [x3, #49472]
	ldr	q10, [x3, #49488]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #19744]
	ldr	q11, [x3, #50512]
	ldr	q12, [x3, #50496]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #352]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #352]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #49520]
	ldr	q10, [x3, #49504]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #50528]
	ldr	q12, [x3, #50544]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #384]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #384]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #18784]
	ldr	q8, [x3, #49536]
	ldr	q10, [x3, #49552]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #19808]
	ldr	q11, [x3, #50576]
	ldr	q12, [x3, #50560]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #416]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #416]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #49584]
	ldr	q10, [x3, #49568]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #50592]
	ldr	q12, [x3, #50608]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #448]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #448]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #18848]
	ldr	q8, [x3, #49600]
	ldr	q10, [x3, #49616]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #19872]
	ldr	q11, [x3, #50640]
	ldr	q12, [x3, #50624]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #480]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #480]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #49648]
	ldr	q10, [x3, #49632]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #50656]
	ldr	q12, [x3, #50672]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #512]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #512]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #18912]
	ldr	q8, [x3, #49664]
	ldr	q10, [x3, #49680]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #19936]
	ldr	q11, [x3, #50704]
	ldr	q12, [x3, #50688]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #544]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #544]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #49712]
	ldr	q10, [x3, #49696]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #50720]
	ldr	q12, [x3, #50736]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #576]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #576]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #18976]
	ldr	q8, [x3, #49728]
	ldr	q10, [x3, #49744]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #20000]
	ldr	q11, [x3, #50768]
	ldr	q12, [x3, #50752]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #608]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #608]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #49776]
	ldr	q10, [x3, #49760]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #50784]
	ldr	q12, [x3, #50800]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #640]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #640]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #19040]
	ldr	q8, [x3, #49792]
	ldr	q10, [x3, #49808]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #20064]
	ldr	q11, [x3, #50832]
	ldr	q12, [x3, #50816]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #672]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #672]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #49840]
	ldr	q10, [x3, #49824]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #50848]
	ldr	q12, [x3, #50864]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #704]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #704]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #19104]
	ldr	q8, [x3, #49856]
	ldr	q10, [x3, #49872]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #20128]
	ldr	q11, [x3, #50896]
	ldr	q12, [x3, #50880]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #736]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #736]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #49904]
	ldr	q10, [x3, #49888]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #50912]
	ldr	q12, [x3, #50928]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #768]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #768]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #19168]
	ldr	q8, [x3, #49920]
	ldr	q10, [x3, #49936]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #20192]
	ldr	q11, [x3, #50960]
	ldr	q12, [x3, #50944]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #800]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #800]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #49968]
	ldr	q10, [x3, #49952]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #50976]
	ldr	q12, [x3, #50992]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #832]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #832]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #19232]
	ldr	q8, [x3, #49984]
	ldr	q10, [x3, #50000]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #20256]
	ldr	q11, [x3, #51024]
	ldr	q12, [x3, #51008]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #864]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #864]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #50032]
	ldr	q10, [x3, #50016]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #51040]
	ldr	q12, [x3, #51056]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v6, v6, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v27
	ldp	q27, q28, [x30, #896]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q31, q30, [x14, #896]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #19296]
	ldr	q8, [x3, #50048]
	ldr	q10, [x3, #50064]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #20320]
	ldr	q11, [x3, #51088]
	ldr	q12, [x3, #51072]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v6, v6, v27
	fadd.4s	v17, v17, v28
	fmul.4s	v27, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v26, v26, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v30, v11
	fmul.4s	v28, v31, v12
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v27
	ldp	q28, q27, [x30, #928]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q30, q31, [x14, #928]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q8, [x3, #50096]
	ldr	q10, [x3, #50080]
	and.16b	v10, v1, v10
	and.16b	v8, v0, v8
	ldr	q11, [x3, #51104]
	ldr	q12, [x3, #51120]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmul.4s	v13, v27, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v27, v27, v12
	fadd.4s	v17, v17, v27
	fadd.4s	v27, v6, v28
	fmul.4s	v6, v30, v10
	fmul.4s	v28, v31, v8
	fadd.4s	v20, v20, v28
	fadd.4s	v26, v26, v6
	fmul.4s	v28, v30, v11
	fmul.4s	v6, v31, v12
	fadd.4s	v6, v18, v6
	fadd.4s	v18, v19, v28
	ldp	q19, q28, [x30, #960]
	and.16b	v28, v0, v28
	and.16b	v19, v1, v19
	ldp	q31, q30, [x14, #960]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	prfm	pldl1keep, [x15, #19360]
	ldr	q8, [x3, #50112]
	ldr	q10, [x3, #50128]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	prfm	pldl1keep, [x15, #20384]
	ldr	q11, [x3, #51152]
	ldr	q12, [x3, #51136]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v13, v19, v8
	fmul.4s	v14, v28, v10
	fadd.4s	v9, v9, v14
	fadd.4s	v29, v29, v13
	fmul.4s	v28, v28, v11
	fmul.4s	v19, v19, v12
	fadd.4s	v27, v27, v19
	fadd.4s	v28, v17, v28
	fmul.4s	v17, v30, v10
	fmul.4s	v19, v31, v8
	fadd.4s	v19, v26, v19
	fadd.4s	v20, v20, v17
	fmul.4s	v17, v30, v11
	fmul.4s	v26, v31, v12
	ldp	q31, q30, [x30, #992]
	fadd.4s	v18, v18, v26
	and.16b	v26, v1, v31
	and.16b	v30, v0, v30
	ldp	q31, q8, [x14, #992]
	and.16b	v8, v0, v8
	and.16b	v31, v1, v31
	ldr	q10, [x3, #50160]
	ldr	q11, [x3, #50144]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x3, #51168]
	fmul.4s	v13, v30, v10
	add	x14, x11, x5
	fmul.4s	v14, v26, v11
	fadd.4s	v29, v29, v14
	fadd.4s	v9, v9, v13
	ldp	q13, q14, [x14]
	bif.16b	v9, v14, v0
	ldr	q14, [x3, #51184]
	and.16b	v14, v0, v14
	and.16b	v12, v1, v12
	bif.16b	v29, v13, v1
	stp	q29, q9, [x14]
	fmul.4s	v26, v26, v12
	fmul.4s	v29, v30, v14
	fadd.4s	v28, v28, v29
	ldp	q30, q29, [x14, #32]
	fadd.4s	v26, v27, v26
	bif.16b	v26, v30, v1
	mov.16b	v27, v0
	bsl.16b	v27, v28, v29
	stp	q26, q27, [x14, #32]
	fmul.4s	v26, v31, v11
	fmul.4s	v27, v8, v10
	fadd.4s	v20, v20, v27
	ldp	q28, q27, [x14, #512]
	fadd.4s	v19, v19, v26
	bif.16b	v19, v28, v1
	bif.16b	v20, v27, v0
	stp	q19, q20, [x14, #512]
	fadd.4s	v6, v6, v17
	fmul.4s	v17, v31, v12
	fmul.4s	v19, v8, v14
	ldp	q26, q20, [x14, #544]
	fadd.4s	v6, v6, v19
	fadd.4s	v17, v18, v17
	bif.16b	v17, v26, v1
	bif.16b	v6, v20, v0
	stp	q17, q6, [x14, #544]
	add	x5, x5, #64
	add	x4, x4, #128
	adds	x26, x26, #2048
	b.ne	LBB0_32
; %bb.33:                               ; %direct.false268
                                        ;   in Loop: Header=BB0_31 Depth=2
	add	x12, x12, #1
	add	x28, x28, #1024
	add	x0, x0, #2048
	cmp	x12, #4
	b.ne	LBB0_31
; %bb.34:                               ; %direct.false264
                                        ;   in Loop: Header=BB0_22 Depth=1
	fmov	w12, s21
	mov	w15, #1                         ; =0x1
	tbz	w12, #0, LBB0_36
; %bb.35:                               ; %cond.store
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q6, [sp, #96]                   ; 16-byte Reload
	fmov	x14, d6
	strb	w15, [x14]
LBB0_36:                                ; %else436
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	ldr	q28, [sp, #8608]                ; 16-byte Reload
	ldr	q29, [sp, #8592]                ; 16-byte Reload
	ldr	d30, [sp, #952]                 ; 8-byte Reload
	ldr	q31, [sp, #9696]                ; 16-byte Reload
	ldr	q8, [sp, #9680]                 ; 16-byte Reload
	ldr	q9, [sp, #9664]                 ; 16-byte Reload
	ldr	q10, [sp, #9648]                ; 16-byte Reload
	ldr	q11, [sp, #9632]                ; 16-byte Reload
	ldr	q12, [sp, #9616]                ; 16-byte Reload
	ldr	q13, [sp, #8368]                ; 16-byte Reload
	ldr	q14, [sp, #9728]                ; 16-byte Reload
	tbz	w12, #1, LBB0_52
; %bb.37:                               ; %cond.store437
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q6, [sp, #96]                   ; 16-byte Reload
	mov.d	x14, v6[1]
	strb	w15, [x14]
	tbnz	w12, #2, LBB0_53
LBB0_38:                                ; %else442
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_54
LBB0_39:                                ; %cond.store443
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q6, [sp, #112]                  ; 16-byte Reload
	mov.d	x14, v6[1]
	strb	w15, [x14]
	tbnz	w12, #4, LBB0_55
LBB0_40:                                ; %else448
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_56
LBB0_41:                                ; %cond.store449
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q6, [sp, #128]                  ; 16-byte Reload
	mov.d	x14, v6[1]
	strb	w15, [x14]
	tbnz	w12, #6, LBB0_57
LBB0_42:                                ; %else454
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_44
LBB0_43:                                ; %cond.store455
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q6, [sp, #144]                  ; 16-byte Reload
	mov.d	x12, v6[1]
	strb	w15, [x12]
LBB0_44:                                ; %else457
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x14, x25, #0x1
	orr	x12, x25, #0x1
	str	x12, [sp, #9024]                ; 8-byte Spill
	cmp	x14, #129
	cset	w14, lo
	fmov	w12, s21
	dup.8b	v6, w14
	tbz	w12, #0, LBB0_58
; %bb.45:                               ; %cond.store459
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2752]                ; 16-byte Reload
	fmov	x14, d17
	str	b6, [x14]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_59
LBB0_46:                                ; %else464
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_60
LBB0_47:                                ; %cond.store465
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2784]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[2], [x14]
	tbnz	w12, #3, LBB0_61
LBB0_48:                                ; %else470
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_62
LBB0_49:                                ; %cond.store471
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2816]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[4], [x14]
	tbnz	w12, #5, LBB0_63
LBB0_50:                                ; %else476
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_64
LBB0_51:                                ; %cond.store477
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2848]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[6], [x14]
	tbnz	w12, #7, LBB0_65
	b	LBB0_66
LBB0_52:                                ; %else439
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_38
LBB0_53:                                ; %cond.store440
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q6, [sp, #112]                  ; 16-byte Reload
	fmov	x14, d6
	strb	w15, [x14]
	tbnz	w12, #3, LBB0_39
LBB0_54:                                ; %else445
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_40
LBB0_55:                                ; %cond.store446
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q6, [sp, #128]                  ; 16-byte Reload
	fmov	x14, d6
	strb	w15, [x14]
	tbnz	w12, #5, LBB0_41
LBB0_56:                                ; %else451
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_42
LBB0_57:                                ; %cond.store452
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q6, [sp, #144]                  ; 16-byte Reload
	fmov	x14, d6
	strb	w15, [x14]
	tbnz	w12, #7, LBB0_43
	b	LBB0_44
LBB0_58:                                ; %else461
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_46
LBB0_59:                                ; %cond.store462
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2752]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[1], [x14]
	tbnz	w12, #2, LBB0_47
LBB0_60:                                ; %else467
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_48
LBB0_61:                                ; %cond.store468
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2784]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[3], [x14]
	tbnz	w12, #4, LBB0_49
LBB0_62:                                ; %else473
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_50
LBB0_63:                                ; %cond.store474
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2816]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[5], [x14]
	tbnz	w12, #6, LBB0_51
LBB0_64:                                ; %else479
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_66
LBB0_65:                                ; %cond.store480
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2848]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
LBB0_66:                                ; %else482
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x14, x25, #0x2
	orr	x12, x25, #0x2
	str	x12, [sp, #9008]                ; 8-byte Spill
	cmp	x14, #129
	cset	w14, lo
	fmov	w12, s21
	dup.8b	v6, w14
	tbz	w12, #0, LBB0_74
; %bb.67:                               ; %cond.store484
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2624]                ; 16-byte Reload
	fmov	x14, d17
	str	b6, [x14]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_75
LBB0_68:                                ; %else491
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_76
LBB0_69:                                ; %cond.store492
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2656]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[2], [x14]
	tbnz	w12, #3, LBB0_77
LBB0_70:                                ; %else499
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_78
LBB0_71:                                ; %cond.store500
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2688]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[4], [x14]
	tbnz	w12, #5, LBB0_79
LBB0_72:                                ; %else507
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_80
LBB0_73:                                ; %cond.store508
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2720]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[6], [x14]
	tbnz	w12, #7, LBB0_81
	b	LBB0_82
LBB0_74:                                ; %else487
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_68
LBB0_75:                                ; %cond.store488
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2624]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[1], [x14]
	tbnz	w12, #2, LBB0_69
LBB0_76:                                ; %else495
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_70
LBB0_77:                                ; %cond.store496
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2656]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[3], [x14]
	tbnz	w12, #4, LBB0_71
LBB0_78:                                ; %else503
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_72
LBB0_79:                                ; %cond.store504
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2688]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[5], [x14]
	tbnz	w12, #6, LBB0_73
LBB0_80:                                ; %else511
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_82
LBB0_81:                                ; %cond.store512
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2720]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
LBB0_82:                                ; %else515
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x14, x25, #0x3
	orr	x12, x25, #0x3
	str	x12, [sp, #8992]                ; 8-byte Spill
	cmp	x14, #129
	cset	w14, lo
	fmov	w12, s21
	dup.8b	v6, w14
	tbz	w12, #0, LBB0_90
; %bb.83:                               ; %cond.store517
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2496]                ; 16-byte Reload
	fmov	x14, d17
	str	b6, [x14]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_91
LBB0_84:                                ; %else524
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_92
LBB0_85:                                ; %cond.store525
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2528]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[2], [x14]
	tbnz	w12, #3, LBB0_93
LBB0_86:                                ; %else532
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_94
LBB0_87:                                ; %cond.store533
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2560]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[4], [x14]
	tbnz	w12, #5, LBB0_95
LBB0_88:                                ; %else540
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_96
LBB0_89:                                ; %cond.store541
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2592]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[6], [x14]
	tbnz	w12, #7, LBB0_97
	b	LBB0_98
LBB0_90:                                ; %else520
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_84
LBB0_91:                                ; %cond.store521
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2496]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[1], [x14]
	tbnz	w12, #2, LBB0_85
LBB0_92:                                ; %else528
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_86
LBB0_93:                                ; %cond.store529
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2528]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[3], [x14]
	tbnz	w12, #4, LBB0_87
LBB0_94:                                ; %else536
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_88
LBB0_95:                                ; %cond.store537
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2560]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[5], [x14]
	tbnz	w12, #6, LBB0_89
LBB0_96:                                ; %else544
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_98
LBB0_97:                                ; %cond.store545
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2592]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
LBB0_98:                                ; %else548
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x14, x25, #0x4
	orr	x12, x25, #0x4
	str	x12, [sp, #8976]                ; 8-byte Spill
	cmp	x14, #129
	cset	w14, lo
	fmov	w12, s21
	dup.8b	v6, w14
	tbz	w12, #0, LBB0_106
; %bb.99:                               ; %cond.store550
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2368]                ; 16-byte Reload
	fmov	x14, d17
	str	b6, [x14]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_107
LBB0_100:                               ; %else557
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_108
LBB0_101:                               ; %cond.store558
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2400]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[2], [x14]
	tbnz	w12, #3, LBB0_109
LBB0_102:                               ; %else565
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_110
LBB0_103:                               ; %cond.store566
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2432]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[4], [x14]
	tbnz	w12, #5, LBB0_111
LBB0_104:                               ; %else573
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_112
LBB0_105:                               ; %cond.store574
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2464]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[6], [x14]
	tbnz	w12, #7, LBB0_113
	b	LBB0_114
LBB0_106:                               ; %else553
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_100
LBB0_107:                               ; %cond.store554
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2368]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[1], [x14]
	tbnz	w12, #2, LBB0_101
LBB0_108:                               ; %else561
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_102
LBB0_109:                               ; %cond.store562
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2400]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[3], [x14]
	tbnz	w12, #4, LBB0_103
LBB0_110:                               ; %else569
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_104
LBB0_111:                               ; %cond.store570
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2432]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[5], [x14]
	tbnz	w12, #6, LBB0_105
LBB0_112:                               ; %else577
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_114
LBB0_113:                               ; %cond.store578
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2464]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
LBB0_114:                               ; %else581
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	w12, #5                         ; =0x5
	orr	x3, x25, x12
	cmp	x3, #129
	cset	w14, lo
	fmov	w12, s21
	dup.8b	v6, w14
	tbz	w12, #0, LBB0_146
; %bb.115:                              ; %cond.store583
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2240]                ; 16-byte Reload
	fmov	x14, d17
	str	b6, [x14]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_147
LBB0_116:                               ; %else590
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_148
LBB0_117:                               ; %cond.store591
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2272]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[2], [x14]
	tbnz	w12, #3, LBB0_149
LBB0_118:                               ; %else598
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_150
LBB0_119:                               ; %cond.store599
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2304]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[4], [x14]
	tbnz	w12, #5, LBB0_151
LBB0_120:                               ; %else606
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_152
LBB0_121:                               ; %cond.store607
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2336]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[6], [x14]
	tbnz	w12, #7, LBB0_153
LBB0_122:                               ; %else614
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x4, x25, #0x6
	cmp	x4, #129
	cset	w14, lo
	fmov	w12, s21
	dup.8b	v6, w14
	tbz	w12, #0, LBB0_154
LBB0_123:                               ; %cond.store616
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2112]                ; 16-byte Reload
	fmov	x14, d17
	str	b6, [x14]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_155
LBB0_124:                               ; %else623
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_156
LBB0_125:                               ; %cond.store624
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2144]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[2], [x14]
	tbnz	w12, #3, LBB0_157
LBB0_126:                               ; %else631
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_158
LBB0_127:                               ; %cond.store632
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2176]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[4], [x14]
	tbnz	w12, #5, LBB0_159
LBB0_128:                               ; %else639
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_160
LBB0_129:                               ; %cond.store640
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2208]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[6], [x14]
	tbnz	w12, #7, LBB0_161
LBB0_130:                               ; %else647
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x5, x25, #0x7
	cmp	x5, #129
	cset	w14, lo
	fmov	w12, s21
	dup.8b	v6, w14
	tbz	w12, #0, LBB0_162
LBB0_131:                               ; %cond.store649
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1984]                ; 16-byte Reload
	fmov	x14, d17
	str	b6, [x14]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_163
LBB0_132:                               ; %else656
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_164
LBB0_133:                               ; %cond.store657
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2016]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[2], [x14]
	tbnz	w12, #3, LBB0_165
LBB0_134:                               ; %else664
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_166
LBB0_135:                               ; %cond.store665
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2048]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[4], [x14]
	tbnz	w12, #5, LBB0_167
LBB0_136:                               ; %else672
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_168
LBB0_137:                               ; %cond.store673
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2080]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[6], [x14]
	tbnz	w12, #7, LBB0_169
LBB0_138:                               ; %else680
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x26, x25, #0x8
	cmp	x26, #129
	cset	w14, lo
	fmov	w12, s21
	dup.8b	v6, w14
	tbz	w12, #0, LBB0_170
LBB0_139:                               ; %cond.store682
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1856]                ; 16-byte Reload
	fmov	x14, d17
	str	b6, [x14]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_171
LBB0_140:                               ; %else689
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_172
LBB0_141:                               ; %cond.store690
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1888]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[2], [x14]
	tbnz	w12, #3, LBB0_173
LBB0_142:                               ; %else697
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_174
LBB0_143:                               ; %cond.store698
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1920]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[4], [x14]
	tbnz	w12, #5, LBB0_175
LBB0_144:                               ; %else705
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_176
LBB0_145:                               ; %cond.store706
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1952]                ; 16-byte Reload
	fmov	x14, d17
	st1.b	{ v6 }[6], [x14]
	tbnz	w12, #7, LBB0_177
	b	LBB0_178
LBB0_146:                               ; %else586
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_116
LBB0_147:                               ; %cond.store587
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2240]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[1], [x14]
	tbnz	w12, #2, LBB0_117
LBB0_148:                               ; %else594
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_118
LBB0_149:                               ; %cond.store595
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2272]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[3], [x14]
	tbnz	w12, #4, LBB0_119
LBB0_150:                               ; %else602
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_120
LBB0_151:                               ; %cond.store603
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2304]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[5], [x14]
	tbnz	w12, #6, LBB0_121
LBB0_152:                               ; %else610
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_122
LBB0_153:                               ; %cond.store611
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2336]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
	orr	x4, x25, #0x6
	cmp	x4, #129
	cset	w14, lo
	fmov	w12, s21
	dup.8b	v6, w14
	tbnz	w12, #0, LBB0_123
LBB0_154:                               ; %else619
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_124
LBB0_155:                               ; %cond.store620
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2112]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[1], [x14]
	tbnz	w12, #2, LBB0_125
LBB0_156:                               ; %else627
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_126
LBB0_157:                               ; %cond.store628
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2144]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[3], [x14]
	tbnz	w12, #4, LBB0_127
LBB0_158:                               ; %else635
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_128
LBB0_159:                               ; %cond.store636
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2176]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[5], [x14]
	tbnz	w12, #6, LBB0_129
LBB0_160:                               ; %else643
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_130
LBB0_161:                               ; %cond.store644
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2208]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
	orr	x5, x25, #0x7
	cmp	x5, #129
	cset	w14, lo
	fmov	w12, s21
	dup.8b	v6, w14
	tbnz	w12, #0, LBB0_131
LBB0_162:                               ; %else652
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_132
LBB0_163:                               ; %cond.store653
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1984]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[1], [x14]
	tbnz	w12, #2, LBB0_133
LBB0_164:                               ; %else660
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_134
LBB0_165:                               ; %cond.store661
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2016]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[3], [x14]
	tbnz	w12, #4, LBB0_135
LBB0_166:                               ; %else668
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_136
LBB0_167:                               ; %cond.store669
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2048]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[5], [x14]
	tbnz	w12, #6, LBB0_137
LBB0_168:                               ; %else676
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_138
LBB0_169:                               ; %cond.store677
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #2080]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
	orr	x26, x25, #0x8
	cmp	x26, #129
	cset	w14, lo
	fmov	w12, s21
	dup.8b	v6, w14
	tbnz	w12, #0, LBB0_139
LBB0_170:                               ; %else685
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_140
LBB0_171:                               ; %cond.store686
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1856]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[1], [x14]
	tbnz	w12, #2, LBB0_141
LBB0_172:                               ; %else693
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_142
LBB0_173:                               ; %cond.store694
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1888]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[3], [x14]
	tbnz	w12, #4, LBB0_143
LBB0_174:                               ; %else701
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_144
LBB0_175:                               ; %cond.store702
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1920]                ; 16-byte Reload
	mov.d	x14, v17[1]
	st1.b	{ v6 }[5], [x14]
	tbnz	w12, #6, LBB0_145
LBB0_176:                               ; %else709
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_178
LBB0_177:                               ; %cond.store710
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1952]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
LBB0_178:                               ; %else713
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	w12, #9                         ; =0x9
	orr	x14, x25, x12
	cmp	x14, #129
	cset	w15, lo
	fmov	w12, s21
	dup.8b	v6, w15
	tbz	w12, #0, LBB0_186
; %bb.179:                              ; %cond.store715
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1728]                ; 16-byte Reload
	fmov	x15, d17
	str	b6, [x15]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_187
LBB0_180:                               ; %else722
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_188
LBB0_181:                               ; %cond.store723
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1760]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[2], [x15]
	tbnz	w12, #3, LBB0_189
LBB0_182:                               ; %else730
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_190
LBB0_183:                               ; %cond.store731
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1792]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[4], [x15]
	tbnz	w12, #5, LBB0_191
LBB0_184:                               ; %else738
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_192
LBB0_185:                               ; %cond.store739
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1824]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[6], [x15]
	tbnz	w12, #7, LBB0_193
	b	LBB0_194
LBB0_186:                               ; %else718
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_180
LBB0_187:                               ; %cond.store719
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1728]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[1], [x15]
	tbnz	w12, #2, LBB0_181
LBB0_188:                               ; %else726
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_182
LBB0_189:                               ; %cond.store727
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1760]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[3], [x15]
	tbnz	w12, #4, LBB0_183
LBB0_190:                               ; %else734
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_184
LBB0_191:                               ; %cond.store735
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1792]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[5], [x15]
	tbnz	w12, #6, LBB0_185
LBB0_192:                               ; %else742
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_194
LBB0_193:                               ; %cond.store743
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1824]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
LBB0_194:                               ; %else746
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	w12, #10                        ; =0xa
	orr	x16, x25, x12
	cmp	x16, #129
	cset	w15, lo
	fmov	w12, s21
	dup.8b	v6, w15
	tbz	w12, #0, LBB0_202
; %bb.195:                              ; %cond.store748
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1600]                ; 16-byte Reload
	fmov	x15, d17
	str	b6, [x15]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_203
LBB0_196:                               ; %else755
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_204
LBB0_197:                               ; %cond.store756
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1632]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[2], [x15]
	tbnz	w12, #3, LBB0_205
LBB0_198:                               ; %else763
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_206
LBB0_199:                               ; %cond.store764
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1664]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[4], [x15]
	tbnz	w12, #5, LBB0_207
LBB0_200:                               ; %else771
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_208
LBB0_201:                               ; %cond.store772
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1696]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[6], [x15]
	tbnz	w12, #7, LBB0_209
	b	LBB0_210
LBB0_202:                               ; %else751
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_196
LBB0_203:                               ; %cond.store752
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1600]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[1], [x15]
	tbnz	w12, #2, LBB0_197
LBB0_204:                               ; %else759
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_198
LBB0_205:                               ; %cond.store760
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1632]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[3], [x15]
	tbnz	w12, #4, LBB0_199
LBB0_206:                               ; %else767
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_200
LBB0_207:                               ; %cond.store768
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1664]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[5], [x15]
	tbnz	w12, #6, LBB0_201
LBB0_208:                               ; %else775
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_210
LBB0_209:                               ; %cond.store776
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1696]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
LBB0_210:                               ; %else779
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	w12, #11                        ; =0xb
	orr	x17, x25, x12
	cmp	x17, #129
	cset	w15, lo
	fmov	w12, s21
	dup.8b	v6, w15
	tbz	w12, #0, LBB0_226
; %bb.211:                              ; %cond.store781
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1472]                ; 16-byte Reload
	fmov	x15, d17
	str	b6, [x15]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_227
LBB0_212:                               ; %else788
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_228
LBB0_213:                               ; %cond.store789
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1504]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[2], [x15]
	tbnz	w12, #3, LBB0_229
LBB0_214:                               ; %else796
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_230
LBB0_215:                               ; %cond.store797
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1536]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[4], [x15]
	tbnz	w12, #5, LBB0_231
LBB0_216:                               ; %else804
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_232
LBB0_217:                               ; %cond.store805
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1568]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[6], [x15]
	tbnz	w12, #7, LBB0_233
LBB0_218:                               ; %else812
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x7, x25, #0xc
	cmp	x7, #129
	cset	w15, lo
	fmov	w12, s21
	dup.8b	v6, w15
	tbz	w12, #0, LBB0_234
LBB0_219:                               ; %cond.store814
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1344]                ; 16-byte Reload
	fmov	x15, d17
	str	b6, [x15]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_235
LBB0_220:                               ; %else821
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_236
LBB0_221:                               ; %cond.store822
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1376]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[2], [x15]
	tbnz	w12, #3, LBB0_237
LBB0_222:                               ; %else829
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_238
LBB0_223:                               ; %cond.store830
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1408]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[4], [x15]
	tbnz	w12, #5, LBB0_239
LBB0_224:                               ; %else837
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_240
LBB0_225:                               ; %cond.store838
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1440]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[6], [x15]
	tbnz	w12, #7, LBB0_241
	b	LBB0_242
LBB0_226:                               ; %else784
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_212
LBB0_227:                               ; %cond.store785
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1472]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[1], [x15]
	tbnz	w12, #2, LBB0_213
LBB0_228:                               ; %else792
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_214
LBB0_229:                               ; %cond.store793
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1504]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[3], [x15]
	tbnz	w12, #4, LBB0_215
LBB0_230:                               ; %else800
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_216
LBB0_231:                               ; %cond.store801
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1536]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[5], [x15]
	tbnz	w12, #6, LBB0_217
LBB0_232:                               ; %else808
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_218
LBB0_233:                               ; %cond.store809
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1568]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
	orr	x7, x25, #0xc
	cmp	x7, #129
	cset	w15, lo
	fmov	w12, s21
	dup.8b	v6, w15
	tbnz	w12, #0, LBB0_219
LBB0_234:                               ; %else817
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_220
LBB0_235:                               ; %cond.store818
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1344]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[1], [x15]
	tbnz	w12, #2, LBB0_221
LBB0_236:                               ; %else825
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_222
LBB0_237:                               ; %cond.store826
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1376]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[3], [x15]
	tbnz	w12, #4, LBB0_223
LBB0_238:                               ; %else833
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_224
LBB0_239:                               ; %cond.store834
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1408]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[5], [x15]
	tbnz	w12, #6, LBB0_225
LBB0_240:                               ; %else841
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_242
LBB0_241:                               ; %cond.store842
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1440]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
LBB0_242:                               ; %else845
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	w12, #13                        ; =0xd
	orr	x19, x25, x12
	cmp	x19, #129
	cset	w15, lo
	fmov	w12, s21
	dup.8b	v6, w15
	tbz	w12, #0, LBB0_266
; %bb.243:                              ; %cond.store847
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1216]                ; 16-byte Reload
	fmov	x15, d17
	str	b6, [x15]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_267
LBB0_244:                               ; %else854
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_268
LBB0_245:                               ; %cond.store855
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1248]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[2], [x15]
	tbnz	w12, #3, LBB0_269
LBB0_246:                               ; %else862
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_270
LBB0_247:                               ; %cond.store863
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1280]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[4], [x15]
	tbnz	w12, #5, LBB0_271
LBB0_248:                               ; %else870
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_272
LBB0_249:                               ; %cond.store871
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1312]                ; 16-byte Reload
	fmov	x15, d17
	st1.b	{ v6 }[6], [x15]
	tbnz	w12, #7, LBB0_273
LBB0_250:                               ; %else878
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x15, x25, #0xe
	cmp	x15, #129
	cset	w0, lo
	fmov	w12, s21
	dup.8b	v6, w0
	tbz	w12, #0, LBB0_274
LBB0_251:                               ; %cond.store880
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1088]                ; 16-byte Reload
	fmov	x0, d17
	str	b6, [x0]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_275
LBB0_252:                               ; %else887
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_276
LBB0_253:                               ; %cond.store888
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1120]                ; 16-byte Reload
	fmov	x0, d17
	st1.b	{ v6 }[2], [x0]
	tbnz	w12, #3, LBB0_277
LBB0_254:                               ; %else895
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_278
LBB0_255:                               ; %cond.store896
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1152]                ; 16-byte Reload
	fmov	x0, d17
	st1.b	{ v6 }[4], [x0]
	tbnz	w12, #5, LBB0_279
LBB0_256:                               ; %else903
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_280
LBB0_257:                               ; %cond.store904
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1184]                ; 16-byte Reload
	fmov	x0, d17
	st1.b	{ v6 }[6], [x0]
	tbnz	w12, #7, LBB0_281
LBB0_258:                               ; %else911
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x0, x25, #0xf
	cmp	x0, #129
	cset	w20, lo
	fmov	w12, s21
	dup.8b	v6, w20
	tbz	w12, #0, LBB0_282
LBB0_259:                               ; %cond.store913
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #960]                 ; 16-byte Reload
	fmov	x20, d17
	str	b6, [x20]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_283
LBB0_260:                               ; %else920
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #2, LBB0_284
LBB0_261:                               ; %cond.store921
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #992]                 ; 16-byte Reload
	fmov	x20, d17
	st1.b	{ v6 }[2], [x20]
	tbnz	w12, #3, LBB0_285
LBB0_262:                               ; %else928
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #4, LBB0_286
LBB0_263:                               ; %cond.store929
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1024]                ; 16-byte Reload
	fmov	x20, d17
	st1.b	{ v6 }[4], [x20]
	tbnz	w12, #5, LBB0_287
LBB0_264:                               ; %else936
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #6, LBB0_288
LBB0_265:                               ; %cond.store937
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1056]                ; 16-byte Reload
	fmov	x20, d17
	st1.b	{ v6 }[6], [x20]
	sshll.2d	v17, v1, #0
	sshll.2d	v18, v0, #0
	tbnz	w12, #7, LBB0_289
	b	LBB0_290
LBB0_266:                               ; %else850
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_244
LBB0_267:                               ; %cond.store851
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1216]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[1], [x15]
	tbnz	w12, #2, LBB0_245
LBB0_268:                               ; %else858
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_246
LBB0_269:                               ; %cond.store859
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1248]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[3], [x15]
	tbnz	w12, #4, LBB0_247
LBB0_270:                               ; %else866
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_248
LBB0_271:                               ; %cond.store867
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1280]                ; 16-byte Reload
	mov.d	x15, v17[1]
	st1.b	{ v6 }[5], [x15]
	tbnz	w12, #6, LBB0_249
LBB0_272:                               ; %else874
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_250
LBB0_273:                               ; %cond.store875
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1312]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
	orr	x15, x25, #0xe
	cmp	x15, #129
	cset	w0, lo
	fmov	w12, s21
	dup.8b	v6, w0
	tbnz	w12, #0, LBB0_251
LBB0_274:                               ; %else883
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_252
LBB0_275:                               ; %cond.store884
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1088]                ; 16-byte Reload
	mov.d	x0, v17[1]
	st1.b	{ v6 }[1], [x0]
	tbnz	w12, #2, LBB0_253
LBB0_276:                               ; %else891
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_254
LBB0_277:                               ; %cond.store892
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1120]                ; 16-byte Reload
	mov.d	x0, v17[1]
	st1.b	{ v6 }[3], [x0]
	tbnz	w12, #4, LBB0_255
LBB0_278:                               ; %else899
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_256
LBB0_279:                               ; %cond.store900
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1152]                ; 16-byte Reload
	mov.d	x0, v17[1]
	st1.b	{ v6 }[5], [x0]
	tbnz	w12, #6, LBB0_257
LBB0_280:                               ; %else907
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #7, LBB0_258
LBB0_281:                               ; %cond.store908
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1184]                ; 16-byte Reload
	mov.d	x12, v17[1]
	st1.b	{ v6 }[7], [x12]
	orr	x0, x25, #0xf
	cmp	x0, #129
	cset	w20, lo
	fmov	w12, s21
	dup.8b	v6, w20
	tbnz	w12, #0, LBB0_259
LBB0_282:                               ; %else916
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_260
LBB0_283:                               ; %cond.store917
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #960]                 ; 16-byte Reload
	mov.d	x20, v17[1]
	st1.b	{ v6 }[1], [x20]
	tbnz	w12, #2, LBB0_261
LBB0_284:                               ; %else924
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #3, LBB0_262
LBB0_285:                               ; %cond.store925
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #992]                 ; 16-byte Reload
	mov.d	x20, v17[1]
	st1.b	{ v6 }[3], [x20]
	tbnz	w12, #4, LBB0_263
LBB0_286:                               ; %else932
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w12, #5, LBB0_264
LBB0_287:                               ; %cond.store933
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q17, [sp, #1024]                ; 16-byte Reload
	mov.d	x20, v17[1]
	st1.b	{ v6 }[5], [x20]
	tbnz	w12, #6, LBB0_265
LBB0_288:                               ; %else940
                                        ;   in Loop: Header=BB0_22 Depth=1
	sshll.2d	v17, v1, #0
	sshll.2d	v18, v0, #0
	tbz	w12, #7, LBB0_290
LBB0_289:                               ; %cond.store941
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q19, [sp, #1056]                ; 16-byte Reload
	mov.d	x12, v19[1]
	st1.b	{ v6 }[7], [x12]
LBB0_290:                               ; %else944
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x28, #0                         ; =0x0
	mov	x30, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	dup.2d	v19, x25
	ldr	q22, [sp, #3584]                ; 16-byte Reload
	ldr	q6, [sp, #9584]                 ; 16-byte Reload
	bit.16b	v6, v22, v18
	str	q6, [sp, #9584]                 ; 16-byte Spill
	ldr	x20, [sp, #2800]                ; 8-byte Reload
	ldp	q26, q20, [x20, #32]
	bit.16b	v13, v22, v17
	ldr	q6, [sp, #192]                  ; 16-byte Reload
	ldr	q27, [sp, #9520]                ; 16-byte Reload
	bit.16b	v27, v6, v18
	str	q27, [sp, #9520]                ; 16-byte Spill
	ldr	q6, [sp, #160]                  ; 16-byte Reload
	ldr	q18, [sp, #9552]                ; 16-byte Reload
	bit.16b	v18, v6, v17
	str	q18, [sp, #9552]                ; 16-byte Spill
	sshll.2d	v17, v0, #0
	ldp	q27, q18, [x20]
	sshll.2d	v6, v1, #0
	bit.16b	v27, v19, v6
	bit.16b	v26, v19, v17
	bit.16b	v18, v19, v28
	bif.16b	v19, v20, v29
	ldr	x25, [sp, #9024]                ; 8-byte Reload
	dup.2d	v20, x25
	stp	q26, q19, [x20, #32]
	stp	q27, q18, [x20]
	ldr	x20, [sp, #2776]                ; 8-byte Reload
	ldp	q19, q18, [x20, #32]
	ldp	q27, q26, [x20]
	bit.16b	v27, v20, v6
	bit.16b	v19, v20, v17
	bit.16b	v26, v20, v28
	bit.16b	v18, v20, v29
	ldr	x25, [sp, #9008]                ; 8-byte Reload
	dup.2d	v20, x25
	stp	q19, q18, [x20, #32]
	stp	q27, q26, [x20]
	ldr	x20, [sp, #2744]                ; 8-byte Reload
	ldp	q19, q18, [x20, #32]
	ldp	q27, q26, [x20]
	bit.16b	v27, v20, v6
	bit.16b	v19, v20, v17
	bit.16b	v26, v20, v28
	bit.16b	v18, v20, v29
	stp	q19, q18, [x20, #32]
	stp	q27, q26, [x20]
	ldr	x20, [sp, #8992]                ; 8-byte Reload
	dup.2d	v18, x20
	ldr	x20, [sp, #2736]                ; 8-byte Reload
	ldp	q20, q19, [x20, #32]
	ldp	q27, q26, [x20]
	bit.16b	v27, v18, v6
	bit.16b	v20, v18, v17
	bit.16b	v26, v18, v28
	bif.16b	v18, v19, v29
	stp	q20, q18, [x20, #32]
	stp	q27, q26, [x20]
	ldr	x20, [sp, #8976]                ; 8-byte Reload
	dup.2d	v18, x20
	ldr	x20, [sp, #2712]                ; 8-byte Reload
	ldp	q20, q19, [x20, #32]
	ldp	q27, q26, [x20]
	bit.16b	v27, v18, v6
	bit.16b	v20, v18, v17
	bit.16b	v26, v18, v28
	bif.16b	v18, v19, v29
	stp	q20, q18, [x20, #32]
	stp	q27, q26, [x20]
	dup.2d	v18, x3
	ldr	x3, [sp, #2680]                 ; 8-byte Reload
	ldp	q20, q19, [x3, #32]
	ldp	q27, q26, [x3]
	bit.16b	v27, v18, v6
	bit.16b	v20, v18, v17
	bit.16b	v26, v18, v28
	bif.16b	v18, v19, v29
	stp	q20, q18, [x3, #32]
	stp	q27, q26, [x3]
	dup.2d	v18, x4
	ldr	x3, [sp, #2672]                 ; 8-byte Reload
	ldp	q20, q19, [x3, #32]
	ldp	q27, q26, [x3]
	bit.16b	v27, v18, v6
	bit.16b	v20, v18, v17
	bit.16b	v26, v18, v28
	bif.16b	v18, v19, v29
	stp	q20, q18, [x3, #32]
	stp	q27, q26, [x3]
	dup.2d	v18, x5
	ldr	x3, [sp, #2648]                 ; 8-byte Reload
	ldp	q20, q19, [x3, #32]
	ldp	q27, q26, [x3]
	bit.16b	v27, v18, v6
	bit.16b	v20, v18, v17
	bit.16b	v26, v18, v28
	bif.16b	v18, v19, v29
	stp	q20, q18, [x3, #32]
	stp	q27, q26, [x3]
	dup.2d	v18, x26
	ldr	x3, [sp, #2616]                 ; 8-byte Reload
	ldp	q20, q19, [x3, #32]
	ldp	q27, q26, [x3]
	bit.16b	v27, v18, v6
	bit.16b	v20, v18, v17
	bit.16b	v26, v18, v28
	bif.16b	v18, v19, v29
	stp	q20, q18, [x3, #32]
	stp	q27, q26, [x3]
	dup.2d	v18, x14
	ldr	x14, [sp, #2608]                ; 8-byte Reload
	ldp	q20, q19, [x14, #32]
	ldp	q27, q26, [x14]
	bit.16b	v27, v18, v6
	bit.16b	v26, v18, v28
	bit.16b	v20, v18, v17
	bif.16b	v18, v19, v29
	stp	q20, q18, [x14, #32]
	stp	q27, q26, [x14]
	dup.2d	v18, x16
	ldr	x14, [sp, #2584]                ; 8-byte Reload
	ldp	q19, q20, [x14, #32]
	ldp	q26, q27, [x14]
	bit.16b	v27, v18, v28
	bit.16b	v26, v18, v6
	bit.16b	v20, v18, v29
	bif.16b	v18, v19, v17
	stp	q18, q20, [x14, #32]
	stp	q26, q27, [x14]
	dup.2d	v18, x17
	ldr	x14, [sp, #2552]                ; 8-byte Reload
	ldp	q19, q20, [x14, #32]
	ldp	q26, q27, [x14]
	bit.16b	v27, v18, v28
	bit.16b	v26, v18, v6
	bit.16b	v20, v18, v29
	bif.16b	v18, v19, v17
	stp	q18, q20, [x14, #32]
	stp	q26, q27, [x14]
	dup.2d	v18, x7
	ldr	x14, [sp, #2544]                ; 8-byte Reload
	ldp	q20, q19, [x14, #32]
	ldp	q27, q26, [x14]
	bit.16b	v27, v18, v6
	bit.16b	v26, v18, v28
	bit.16b	v20, v18, v17
	bif.16b	v18, v19, v29
	stp	q20, q18, [x14, #32]
	stp	q27, q26, [x14]
	dup.2d	v18, x19
	ldr	x14, [sp, #2520]                ; 8-byte Reload
	ldp	q20, q19, [x14, #32]
	ldp	q27, q26, [x14]
	bit.16b	v27, v18, v6
	bit.16b	v26, v18, v28
	bit.16b	v20, v18, v17
	bif.16b	v18, v19, v29
	stp	q20, q18, [x14, #32]
	stp	q27, q26, [x14]
	dup.2d	v18, x15
	ldr	x14, [sp, #2488]                ; 8-byte Reload
	ldp	q20, q19, [x14, #32]
	ldp	q27, q26, [x14]
	bit.16b	v27, v18, v6
	bit.16b	v26, v18, v28
	bit.16b	v20, v18, v17
	bif.16b	v18, v19, v29
	stp	q20, q18, [x14, #32]
	stp	q27, q26, [x14]
	dup.2d	v18, x0
	ldr	x14, [sp, #2480]                ; 8-byte Reload
	ldp	q20, q19, [x14, #32]
	ldp	q27, q26, [x14]
	bit.16b	v27, v18, v6
	bit.16b	v26, v18, v28
	bit.16b	v20, v18, v17
	bif.16b	v18, v19, v29
	stp	q20, q18, [x14, #32]
	stp	q27, q26, [x14]
	ldr	x14, [sp, #2456]                ; 8-byte Reload
	ldp	q19, q18, [x14, #32]
	ldr	q20, [sp, #3456]                ; 16-byte Reload
	bit.16b	v19, v20, v17
	ldr	q20, [sp, #3408]                ; 16-byte Reload
	bit.16b	v18, v20, v29
	stp	q19, q18, [x14, #32]
	ldp	q19, q18, [x14]
	ldr	q20, [sp, #3424]                ; 16-byte Reload
	bit.16b	v19, v20, v6
	ldr	q20, [sp, #3440]                ; 16-byte Reload
	bit.16b	v18, v20, v28
	stp	q19, q18, [x14]
	ldr	x14, [sp, #2424]                ; 8-byte Reload
	ldp	q19, q18, [x14, #32]
	ldr	q20, [sp, #3392]                ; 16-byte Reload
	bit.16b	v19, v20, v17
	ldr	q20, [sp, #3344]                ; 16-byte Reload
	bit.16b	v18, v20, v29
	stp	q19, q18, [x14, #32]
	ldp	q19, q18, [x14]
	ldr	q20, [sp, #3360]                ; 16-byte Reload
	bit.16b	v19, v20, v6
	ldr	q20, [sp, #3376]                ; 16-byte Reload
	bit.16b	v18, v20, v28
	stp	q19, q18, [x14]
	ldr	x14, [sp, #2416]                ; 8-byte Reload
	ldp	q19, q18, [x14, #32]
	ldr	q20, [sp, #3328]                ; 16-byte Reload
	bit.16b	v19, v20, v17
	ldr	q20, [sp, #3280]                ; 16-byte Reload
	bit.16b	v18, v20, v29
	stp	q19, q18, [x14, #32]
	ldp	q19, q18, [x14]
	ldr	q20, [sp, #3296]                ; 16-byte Reload
	bit.16b	v19, v20, v6
	ldr	q20, [sp, #3312]                ; 16-byte Reload
	bit.16b	v18, v20, v28
	stp	q19, q18, [x14]
	ldr	x14, [sp, #2392]                ; 8-byte Reload
	ldp	q19, q18, [x14, #32]
	ldr	q20, [sp, #3264]                ; 16-byte Reload
	bit.16b	v19, v20, v17
	ldr	q20, [sp, #3216]                ; 16-byte Reload
	bit.16b	v18, v20, v29
	stp	q19, q18, [x14, #32]
	ldp	q19, q18, [x14]
	ldr	q20, [sp, #3232]                ; 16-byte Reload
	bit.16b	v19, v20, v6
	ldr	q20, [sp, #3248]                ; 16-byte Reload
	bit.16b	v18, v20, v28
	stp	q19, q18, [x14]
	ldr	x14, [sp, #2360]                ; 8-byte Reload
	ldp	q19, q18, [x14, #32]
	ldr	q20, [sp, #3200]                ; 16-byte Reload
	bit.16b	v19, v20, v17
	ldr	q20, [sp, #3152]                ; 16-byte Reload
	bit.16b	v18, v20, v29
	stp	q19, q18, [x14, #32]
	ldp	q19, q18, [x14]
	ldr	q20, [sp, #3168]                ; 16-byte Reload
	bit.16b	v19, v20, v6
	ldr	q20, [sp, #3184]                ; 16-byte Reload
	bit.16b	v18, v20, v28
	stp	q19, q18, [x14]
	ldr	x14, [sp, #2352]                ; 8-byte Reload
	ldp	q19, q18, [x14, #32]
	ldr	q20, [sp, #3136]                ; 16-byte Reload
	bit.16b	v19, v20, v17
	ldr	q20, [sp, #3088]                ; 16-byte Reload
	bit.16b	v18, v20, v29
	stp	q19, q18, [x14, #32]
	ldp	q19, q18, [x14]
	ldr	q20, [sp, #3104]                ; 16-byte Reload
	bit.16b	v19, v20, v6
	ldr	q20, [sp, #3120]                ; 16-byte Reload
	bit.16b	v18, v20, v28
	stp	q19, q18, [x14]
	ldr	x14, [sp, #2328]                ; 8-byte Reload
	ldp	q19, q18, [x14, #32]
	ldr	q20, [sp, #3072]                ; 16-byte Reload
	bit.16b	v19, v20, v17
	ldr	q20, [sp, #3024]                ; 16-byte Reload
	bit.16b	v18, v20, v29
	stp	q19, q18, [x14, #32]
	ldr	q18, [x14]
	ldr	q20, [sp, #3040]                ; 16-byte Reload
	bit.16b	v18, v20, v6
	ldr	x15, [sp, #2296]                ; 8-byte Reload
	ldr	q19, [x15, #32]
	ldr	q20, [sp, #3008]                ; 16-byte Reload
	bit.16b	v19, v20, v17
	ldr	q20, [sp, #3552]                ; 16-byte Reload
	bit.16b	v14, v20, v17
	ldr	q26, [sp, #448]                 ; 16-byte Reload
	bit.16b	v11, v26, v17
	ldr	q17, [x15]
	ldr	q26, [sp, #2976]                ; 16-byte Reload
	bit.16b	v17, v26, v6
	bit.16b	v31, v20, v6
	ldr	q26, [sp, #432]                 ; 16-byte Reload
	bit.16b	v9, v26, v6
	ldr	q6, [x14, #16]
	ldr	q26, [sp, #3056]                ; 16-byte Reload
	bit.16b	v6, v26, v28
	stp	q18, q6, [x14]
	ldr	q6, [x15, #48]
	ldr	q18, [sp, #2960]                ; 16-byte Reload
	bit.16b	v6, v18, v29
	stp	q19, q6, [x15, #32]
	ldr	q6, [x15, #16]
	ldr	q18, [sp, #2992]                ; 16-byte Reload
	bit.16b	v6, v18, v28
	stp	q17, q6, [x15]
	ldr	q6, [sp, #9568]                 ; 16-byte Reload
	bit.16b	v6, v22, v29
	str	q6, [sp, #9568]                 ; 16-byte Spill
	ldr	q6, [sp, #9600]                 ; 16-byte Reload
	bit.16b	v6, v22, v28
	str	q6, [sp, #9600]                 ; 16-byte Spill
	ldr	q6, [sp, #208]                  ; 16-byte Reload
	ldr	q17, [sp, #9504]                ; 16-byte Reload
	bit.16b	v17, v6, v29
	str	q17, [sp, #9504]                ; 16-byte Spill
	ldr	q6, [sp, #176]                  ; 16-byte Reload
	ldr	q17, [sp, #9536]                ; 16-byte Reload
	bit.16b	v17, v6, v28
	str	q17, [sp, #9536]                ; 16-byte Spill
	ldr	q22, [sp, #9712]                ; 16-byte Reload
	bit.16b	v22, v20, v29
	bit.16b	v8, v20, v28
	ldr	q6, [sp, #480]                  ; 16-byte Reload
	bit.16b	v12, v6, v29
	ldr	q6, [sp, #464]                  ; 16-byte Reload
	bit.16b	v10, v6, v28
	ldr	x3, [sp, #3544]                 ; 8-byte Reload
	mov	w4, #1267                       ; =0x4f3
	movk	w4, #15925, lsl #16
	mov	w5, #48782                      ; =0xbe8e
	movk	w5, #46527, lsl #16
	b	LBB0_292
LBB0_291:                               ; %else1026
                                        ;   in Loop: Header=BB0_292 Depth=2
	add	x12, x12, #1
	add	x30, x30, #8
	add	x28, x28, #64
	cmp	x12, #128
	b.eq	LBB0_324
LBB0_292:                               ; %direct.true1069
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w14, s21
	lsr	x15, x12, #3
	dup.2d	v17, x15
	ldr	q6, [sp, #9552]                 ; 16-byte Reload
	orr.16b	v6, v17, v6
	add.2d	v18, v13, v6
	tbz	w14, #0, LBB0_294
; %bb.293:                              ; %cond.load946
                                        ;   in Loop: Header=BB0_292 Depth=2
	fmov	x15, d18
	ldr	b6, [x15]
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_295
	b	LBB0_296
LBB0_294:                               ;   in Loop: Header=BB0_292 Depth=2
	movi.2d	v6, #0000000000000000
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_296
LBB0_295:                               ; %cond.load952
                                        ;   in Loop: Header=BB0_292 Depth=2
	mov.d	x15, v18[1]
	ld1.b	{ v6 }[1], [x15]
LBB0_296:                               ; %else956
                                        ;   in Loop: Header=BB0_292 Depth=2
	ldr	q18, [sp, #9536]                ; 16-byte Reload
	orr.16b	v18, v17, v18
	ldr	q19, [sp, #9600]                ; 16-byte Reload
	add.2d	v18, v19, v18
	tbz	w14, #2, LBB0_302
; %bb.297:                              ; %cond.load958
                                        ;   in Loop: Header=BB0_292 Depth=2
	fmov	x15, d18
	ld1.b	{ v6 }[2], [x15]
	tbnz	w14, #3, LBB0_303
LBB0_298:                               ; %else968
                                        ;   in Loop: Header=BB0_292 Depth=2
	ldr	q18, [sp, #9520]                ; 16-byte Reload
	orr.16b	v18, v17, v18
	ldr	q19, [sp, #9584]                ; 16-byte Reload
	add.2d	v18, v19, v18
	tbz	w14, #4, LBB0_304
LBB0_299:                               ; %cond.load970
                                        ;   in Loop: Header=BB0_292 Depth=2
	fmov	x15, d18
	ld1.b	{ v6 }[4], [x15]
	tbnz	w14, #5, LBB0_305
LBB0_300:                               ; %else980
                                        ;   in Loop: Header=BB0_292 Depth=2
	ldr	q18, [sp, #9504]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #9568]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w14, #6, LBB0_306
LBB0_301:                               ; %cond.load982
                                        ;   in Loop: Header=BB0_292 Depth=2
	fmov	x15, d17
	ld1.b	{ v6 }[6], [x15]
	tbnz	w14, #7, LBB0_307
	b	LBB0_308
LBB0_302:                               ; %else962
                                        ;   in Loop: Header=BB0_292 Depth=2
	tbz	w14, #3, LBB0_298
LBB0_303:                               ; %cond.load964
                                        ;   in Loop: Header=BB0_292 Depth=2
	mov.d	x15, v18[1]
	ld1.b	{ v6 }[3], [x15]
	ldr	q18, [sp, #9520]                ; 16-byte Reload
	orr.16b	v18, v17, v18
	ldr	q19, [sp, #9584]                ; 16-byte Reload
	add.2d	v18, v19, v18
	tbnz	w14, #4, LBB0_299
LBB0_304:                               ; %else974
                                        ;   in Loop: Header=BB0_292 Depth=2
	tbz	w14, #5, LBB0_300
LBB0_305:                               ; %cond.load976
                                        ;   in Loop: Header=BB0_292 Depth=2
	mov.d	x15, v18[1]
	ld1.b	{ v6 }[5], [x15]
	ldr	q18, [sp, #9504]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #9568]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbnz	w14, #6, LBB0_301
LBB0_306:                               ; %else986
                                        ;   in Loop: Header=BB0_292 Depth=2
	tbz	w14, #7, LBB0_308
LBB0_307:                               ; %cond.load988
                                        ;   in Loop: Header=BB0_292 Depth=2
	mov.d	x14, v17[1]
	ld1.b	{ v6 }[7], [x14]
LBB0_308:                               ; %else992
                                        ;   in Loop: Header=BB0_292 Depth=2
	fmov	w14, s21
	cmeq.8b	v6, v6, #0
	and	x15, x30, #0x3c0
	add	x15, x21, x15
	ldp	q17, q18, [x15]
	ldp	q19, q20, [x15, #32]
	and	x15, x28, #0x1c0
	add	x15, x22, x15
	ldp	q26, q27, [x15]
	ldp	q28, q29, [x15, #32]
	cmge.2d	v20, v29, v20
	cmge.2d	v19, v28, v19
	uzp1.4s	v19, v19, v20
	cmge.2d	v18, v27, v18
	cmge.2d	v17, v26, v17
	uzp1.4s	v17, v17, v18
	uzp1.8h	v17, v17, v19
	xtn.8b	v17, v17
	orr.8b	v17, v30, v17
	bic.8b	v6, v17, v6
	dup.2d	v17, x12
	orr.16b	v18, v17, v9
	add.2d	v18, v31, v18
	and.8b	v6, v6, v2
	tbz	w14, #0, LBB0_316
; %bb.309:                              ; %cond.store995
                                        ;   in Loop: Header=BB0_292 Depth=2
	fmov	x15, d18
	str	b6, [x15]
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_317
LBB0_310:                               ; %else1002
                                        ;   in Loop: Header=BB0_292 Depth=2
	orr.16b	v18, v17, v10
	add.2d	v18, v8, v18
	tbz	w14, #2, LBB0_318
LBB0_311:                               ; %cond.store1003
                                        ;   in Loop: Header=BB0_292 Depth=2
	fmov	x15, d18
	st1.b	{ v6 }[2], [x15]
	tbnz	w14, #3, LBB0_319
LBB0_312:                               ; %else1010
                                        ;   in Loop: Header=BB0_292 Depth=2
	orr.16b	v18, v17, v11
	add.2d	v18, v14, v18
	tbz	w14, #4, LBB0_320
LBB0_313:                               ; %cond.store1011
                                        ;   in Loop: Header=BB0_292 Depth=2
	fmov	x15, d18
	st1.b	{ v6 }[4], [x15]
	tbnz	w14, #5, LBB0_321
LBB0_314:                               ; %else1018
                                        ;   in Loop: Header=BB0_292 Depth=2
	orr.16b	v17, v17, v12
	add.2d	v17, v22, v17
	tbz	w14, #6, LBB0_322
LBB0_315:                               ; %cond.store1019
                                        ;   in Loop: Header=BB0_292 Depth=2
	fmov	x15, d17
	st1.b	{ v6 }[6], [x15]
	tbz	w14, #7, LBB0_291
	b	LBB0_323
LBB0_316:                               ; %else998
                                        ;   in Loop: Header=BB0_292 Depth=2
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_310
LBB0_317:                               ; %cond.store999
                                        ;   in Loop: Header=BB0_292 Depth=2
	mov.d	x15, v18[1]
	st1.b	{ v6 }[1], [x15]
	orr.16b	v18, v17, v10
	add.2d	v18, v8, v18
	tbnz	w14, #2, LBB0_311
LBB0_318:                               ; %else1006
                                        ;   in Loop: Header=BB0_292 Depth=2
	tbz	w14, #3, LBB0_312
LBB0_319:                               ; %cond.store1007
                                        ;   in Loop: Header=BB0_292 Depth=2
	mov.d	x15, v18[1]
	st1.b	{ v6 }[3], [x15]
	orr.16b	v18, v17, v11
	add.2d	v18, v14, v18
	tbnz	w14, #4, LBB0_313
LBB0_320:                               ; %else1014
                                        ;   in Loop: Header=BB0_292 Depth=2
	tbz	w14, #5, LBB0_314
LBB0_321:                               ; %cond.store1015
                                        ;   in Loop: Header=BB0_292 Depth=2
	mov.d	x15, v18[1]
	st1.b	{ v6 }[5], [x15]
	orr.16b	v17, v17, v12
	add.2d	v17, v22, v17
	tbnz	w14, #6, LBB0_315
LBB0_322:                               ; %else1022
                                        ;   in Loop: Header=BB0_292 Depth=2
	tbz	w14, #7, LBB0_291
LBB0_323:                               ; %cond.store1023
                                        ;   in Loop: Header=BB0_292 Depth=2
	mov.d	x14, v17[1]
	st1.b	{ v6 }[7], [x14]
	b	LBB0_291
LBB0_324:                               ; %direct.true1092.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x12, #0                         ; =0x0
	mov	x14, #-128                      ; =0xffffffffffffff80
	add	x15, x11, #18, lsl #12          ; =73728
	ldr	q26, [sp, #8560]                ; 16-byte Reload
	ldr	q27, [sp, #8544]                ; 16-byte Reload
	ldr	q28, [sp, #8528]                ; 16-byte Reload
	ldr	q29, [sp, #8512]                ; 16-byte Reload
	ldr	q30, [sp, #8496]                ; 16-byte Reload
	ldr	q2, [sp, #224]                  ; 16-byte Reload
	b	LBB0_326
LBB0_325:                               ; %else1074
                                        ;   in Loop: Header=BB0_326 Depth=2
	cmeq.8b	v6, v6, #0
	sshll.8h	v6, v6, #0
	sshll2.4s	v17, v6, #0
	sshll.4s	v6, v6, #0
	ldp	q19, q18, [x15]
	dup.4s	v20, w4
	fmul.4s	v19, v19, v20
	fmul.4s	v18, v18, v20
	and.16b	v18, v0, v18
	and.16b	v19, v1, v19
	bsl.16b	v6, v2, v19
	bsl.16b	v17, v2, v18
	ldr	q18, [x15, #6784]
	ldr	q19, [x15, #6800]
	bif.16b	v17, v19, v0
	bif.16b	v6, v18, v1
	str	q6, [x15, #6784]
	str	q17, [x15, #6800]
	add	x12, x12, #8
	add	x15, x15, #32
	adds	x14, x14, #1
	b.hs	LBB0_342
LBB0_326:                               ; %direct.true1092
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s21
	add	x17, x14, #128
	and	x0, x12, #0x78
	orr	x17, x0, x17, lsr #4
	dup.2d	v17, x17
	orr.16b	v6, v17, v9
	add.2d	v18, v31, v6
	tbz	w16, #0, LBB0_328
; %bb.327:                              ; %cond.load1028
                                        ;   in Loop: Header=BB0_326 Depth=2
	fmov	x17, d18
	ldr	b6, [x17]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_329
	b	LBB0_330
LBB0_328:                               ;   in Loop: Header=BB0_326 Depth=2
	movi.2d	v6, #0000000000000000
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_330
LBB0_329:                               ; %cond.load1034
                                        ;   in Loop: Header=BB0_326 Depth=2
	mov.d	x17, v18[1]
	ld1.b	{ v6 }[1], [x17]
LBB0_330:                               ; %else1038
                                        ;   in Loop: Header=BB0_326 Depth=2
	orr.16b	v18, v17, v10
	add.2d	v18, v8, v18
	tbz	w16, #2, LBB0_336
; %bb.331:                              ; %cond.load1040
                                        ;   in Loop: Header=BB0_326 Depth=2
	fmov	x17, d18
	ld1.b	{ v6 }[2], [x17]
	tbnz	w16, #3, LBB0_337
LBB0_332:                               ; %else1050
                                        ;   in Loop: Header=BB0_326 Depth=2
	orr.16b	v18, v17, v11
	add.2d	v18, v14, v18
	tbz	w16, #4, LBB0_338
LBB0_333:                               ; %cond.load1052
                                        ;   in Loop: Header=BB0_326 Depth=2
	fmov	x17, d18
	ld1.b	{ v6 }[4], [x17]
	tbnz	w16, #5, LBB0_339
LBB0_334:                               ; %else1062
                                        ;   in Loop: Header=BB0_326 Depth=2
	orr.16b	v17, v17, v12
	add.2d	v17, v22, v17
	tbz	w16, #6, LBB0_340
LBB0_335:                               ; %cond.load1064
                                        ;   in Loop: Header=BB0_326 Depth=2
	fmov	x17, d17
	ld1.b	{ v6 }[6], [x17]
	tbz	w16, #7, LBB0_325
	b	LBB0_341
LBB0_336:                               ; %else1044
                                        ;   in Loop: Header=BB0_326 Depth=2
	tbz	w16, #3, LBB0_332
LBB0_337:                               ; %cond.load1046
                                        ;   in Loop: Header=BB0_326 Depth=2
	mov.d	x17, v18[1]
	ld1.b	{ v6 }[3], [x17]
	orr.16b	v18, v17, v11
	add.2d	v18, v14, v18
	tbnz	w16, #4, LBB0_333
LBB0_338:                               ; %else1056
                                        ;   in Loop: Header=BB0_326 Depth=2
	tbz	w16, #5, LBB0_334
LBB0_339:                               ; %cond.load1058
                                        ;   in Loop: Header=BB0_326 Depth=2
	mov.d	x17, v18[1]
	ld1.b	{ v6 }[5], [x17]
	orr.16b	v17, v17, v12
	add.2d	v17, v22, v17
	tbnz	w16, #6, LBB0_335
LBB0_340:                               ; %else1068
                                        ;   in Loop: Header=BB0_326 Depth=2
	tbz	w16, #7, LBB0_325
LBB0_341:                               ; %cond.load1070
                                        ;   in Loop: Header=BB0_326 Depth=2
	mov.d	x16, v17[1]
	ld1.b	{ v6 }[7], [x16]
	b	LBB0_325
LBB0_342:                               ; %direct.false1093
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x12, #0                         ; =0x0
	mvni.4s	v21, #127, msl #16
	bit.16b	v28, v21, v0
	bit.16b	v27, v21, v1
LBB0_343:                               ; %direct.true1112
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x3, x12
	ldp	q6, q17, [x14]
	and.16b	v17, v0, v17
	and.16b	v6, v1, v6
	fmaxnm.4s	v6, v27, v6
	fmaxnm.4s	v17, v28, v17
	bit.16b	v28, v17, v0
	bit.16b	v27, v6, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB0_343
; %bb.344:                              ; %direct.false1113
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x12, #0                         ; =0x0
	bit.16b	v26, v21, v0
	ldr	q18, [sp, #8576]                ; 16-byte Reload
	bit.16b	v18, v21, v1
	ldr	x15, [sp, #2952]                ; 8-byte Reload
	ldr	q19, [sp, #8480]                ; 16-byte Reload
	ldr	q20, [sp, #8464]                ; 16-byte Reload
LBB0_345:                               ; %direct.true1123
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x15, x12
	ldp	q6, q17, [x14]
	and.16b	v17, v0, v17
	and.16b	v6, v1, v6
	fmaxnm.4s	v6, v18, v6
	fmaxnm.4s	v17, v26, v17
	bit.16b	v26, v17, v0
	bit.16b	v18, v6, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB0_345
; %bb.346:                              ; %direct.false1124
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x12, #0                         ; =0x0
	bit.16b	v24, v21, v0
	bit.16b	v23, v21, v1
	ldr	x15, [sp, #2944]                ; 8-byte Reload
LBB0_347:                               ; %direct.true1134
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x15, x12
	ldp	q6, q17, [x14]
	and.16b	v17, v0, v17
	and.16b	v6, v1, v6
	fmaxnm.4s	v6, v23, v6
	fmaxnm.4s	v17, v24, v17
	bit.16b	v24, v17, v0
	bit.16b	v23, v6, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB0_347
; %bb.348:                              ; %direct.false1135
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x12, #0                         ; =0x0
	bit.16b	v20, v21, v0
	bit.16b	v19, v21, v1
	ldr	x15, [sp, #2936]                ; 8-byte Reload
LBB0_349:                               ; %direct.true1145
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x15, x12
	ldp	q6, q17, [x14]
	and.16b	v17, v0, v17
	and.16b	v6, v1, v6
	fmaxnm.4s	v6, v19, v6
	fmaxnm.4s	v17, v20, v17
	bit.16b	v20, v17, v0
	bit.16b	v19, v6, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB0_349
; %bb.350:                              ; %direct.false1146
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x12, #0                         ; =0x0
	bit.16b	v30, v21, v0
	bit.16b	v29, v21, v1
	ldr	x15, [sp, #2928]                ; 8-byte Reload
LBB0_351:                               ; %direct.true1156
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x15, x12
	ldp	q6, q17, [x14]
	and.16b	v17, v0, v17
	and.16b	v6, v1, v6
	fmaxnm.4s	v6, v29, v6
	fmaxnm.4s	v17, v30, v17
	bit.16b	v30, v17, v0
	bit.16b	v29, v6, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB0_351
; %bb.352:                              ; %direct.false1157
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x12, #0                         ; =0x0
	bit.16b	v16, v21, v0
	bit.16b	v5, v21, v1
	ldr	x15, [sp, #2920]                ; 8-byte Reload
LBB0_353:                               ; %direct.true1167
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x15, x12
	ldp	q6, q17, [x14]
	and.16b	v17, v0, v17
	and.16b	v6, v1, v6
	fmaxnm.4s	v6, v5, v6
	fmaxnm.4s	v17, v16, v17
	bit.16b	v16, v17, v0
	bit.16b	v5, v6, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB0_353
; %bb.354:                              ; %direct.false1168
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x12, #0                         ; =0x0
	bit.16b	v4, v21, v0
	bit.16b	v3, v21, v1
LBB0_355:                               ; %direct.true1178
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x23, x12
	ldp	q6, q17, [x14]
	and.16b	v17, v0, v17
	and.16b	v6, v1, v6
	fmaxnm.4s	v6, v3, v6
	fmaxnm.4s	v17, v4, v17
	bit.16b	v4, v17, v0
	bit.16b	v3, v6, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB0_355
; %bb.356:                              ; %direct.false1179
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q13, [sp, #8368]                ; 16-byte Spill
	str	q12, [sp, #9616]                ; 16-byte Spill
	str	q11, [sp, #9632]                ; 16-byte Spill
	str	q10, [sp, #9648]                ; 16-byte Spill
	str	q9, [sp, #9664]                 ; 16-byte Spill
	str	q8, [sp, #9680]                 ; 16-byte Spill
	str	q31, [sp, #9696]                ; 16-byte Spill
	str	q22, [sp, #9712]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q2, [sp, #8384]                 ; 16-byte Reload
	bit.16b	v2, v21, v0
	bit.16b	v25, v21, v1
LBB0_357:                               ; %direct.true1189
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x24, x12
	ldp	q6, q17, [x14]
	and.16b	v17, v0, v17
	and.16b	v6, v1, v6
	fmaxnm.4s	v6, v25, v6
	fmaxnm.4s	v17, v2, v17
	bit.16b	v2, v17, v0
	bit.16b	v25, v6, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB0_357
; %bb.358:                              ; %direct.false1190
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q14, [sp, #9728]                ; 16-byte Spill
	mov	x25, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	str	q27, [sp, #8544]                ; 16-byte Spill
	ldr	q21, [sp, #9056]                ; 16-byte Reload
	fmaxnm.4s	v12, v21, v27
	str	q28, [sp, #8528]                ; 16-byte Spill
	ldr	q11, [sp, #9040]                ; 16-byte Reload
	fmaxnm.4s	v13, v11, v28
	str	q18, [sp, #8576]                ; 16-byte Spill
	ldr	q6, [sp, #9280]                 ; 16-byte Reload
	fmaxnm.4s	v15, v6, v18
	str	q15, [sp, #8992]                ; 16-byte Spill
	str	q26, [sp, #8560]                ; 16-byte Spill
	ldr	q6, [sp, #9264]                 ; 16-byte Reload
	fmaxnm.4s	v14, v6, v26
	ldr	q6, [sp, #9312]                 ; 16-byte Reload
	fmaxnm.4s	v18, v6, v23
	str	q18, [sp, #8976]                ; 16-byte Spill
	ldr	q6, [sp, #9296]                 ; 16-byte Reload
	fmaxnm.4s	v10, v6, v24
	str	q10, [sp, #8880]                ; 16-byte Spill
	str	q19, [sp, #8480]                ; 16-byte Spill
	ldr	q6, [sp, #9344]                 ; 16-byte Reload
	fmaxnm.4s	v28, v6, v19
	str	q28, [sp, #8960]                ; 16-byte Spill
	str	q20, [sp, #8464]                ; 16-byte Spill
	ldr	q6, [sp, #9328]                 ; 16-byte Reload
	fmaxnm.4s	v20, v6, v20
	str	q20, [sp, #8864]                ; 16-byte Spill
	str	q29, [sp, #8512]                ; 16-byte Spill
	ldr	q6, [sp, #9376]                 ; 16-byte Reload
	fmaxnm.4s	v8, v6, v29
	str	q8, [sp, #8944]                 ; 16-byte Spill
	str	q30, [sp, #8496]                ; 16-byte Spill
	ldr	q6, [sp, #9360]                 ; 16-byte Reload
	fmaxnm.4s	v27, v6, v30
	str	q27, [sp, #8848]                ; 16-byte Spill
	ldr	q6, [sp, #9408]                 ; 16-byte Reload
	fmaxnm.4s	v30, v6, v5
	str	q30, [sp, #8928]                ; 16-byte Spill
	ldr	q6, [sp, #9392]                 ; 16-byte Reload
	fmaxnm.4s	v29, v6, v16
	str	q29, [sp, #8832]                ; 16-byte Spill
	ldr	q6, [sp, #9440]                 ; 16-byte Reload
	fmaxnm.4s	v22, v6, v3
	str	q22, [sp, #8912]                ; 16-byte Spill
	ldr	q6, [sp, #9424]                 ; 16-byte Reload
	fmaxnm.4s	v31, v6, v4
	str	q31, [sp, #8816]                ; 16-byte Spill
	ldr	q6, [sp, #9456]                 ; 16-byte Reload
	fmaxnm.4s	v26, v6, v25
	str	q26, [sp, #8896]                ; 16-byte Spill
	str	q2, [sp, #8384]                 ; 16-byte Spill
	ldr	q6, [sp, #9472]                 ; 16-byte Reload
	fmaxnm.4s	v9, v6, v2
	str	q9, [sp, #8800]                 ; 16-byte Spill
	ldr	x14, [sp, #2288]                ; 8-byte Reload
	ldp	q6, q17, [x14]
	bit.16b	v17, v13, v0
	bit.16b	v6, v12, v1
	stp	q6, q17, [x14]
	ldr	x14, [sp, #2264]                ; 8-byte Reload
	ldp	q6, q17, [x14]
	bit.16b	v17, v14, v0
	bit.16b	v6, v15, v1
	stp	q6, q17, [x14]
	ldr	x14, [sp, #2232]                ; 8-byte Reload
	ldp	q6, q17, [x14]
	bit.16b	v17, v10, v0
	bit.16b	v6, v18, v1
	ldr	x15, [sp, #2224]                ; 8-byte Reload
	ldp	q18, q19, [x15]
	mov.16b	v2, v0
	bsl.16b	v2, v20, v19
	bit.16b	v18, v28, v1
	ldr	x16, [sp, #2200]                ; 8-byte Reload
	ldp	q19, q20, [x16]
	bif.16b	v27, v20, v0
	mov.16b	v28, v1
	bsl.16b	v28, v8, v19
	ldr	x17, [sp, #2168]                ; 8-byte Reload
	ldp	q19, q20, [x17]
	bif.16b	v29, v20, v0
	bif.16b	v30, v19, v1
	ldr	x0, [sp, #2160]                 ; 8-byte Reload
	ldp	q19, q20, [x0]
	bif.16b	v31, v20, v0
	mov.16b	v8, v1
	bsl.16b	v8, v22, v19
	ldr	x4, [sp, #2136]                 ; 8-byte Reload
	ldp	q19, q20, [x4]
	bif.16b	v9, v20, v0
	mov.16b	v10, v1
	bsl.16b	v10, v26, v19
	str	q13, [sp, #7760]                ; 16-byte Spill
	fsub.4s	v11, v11, v13
	stp	q6, q17, [x14]
	str	q12, [sp, #7776]                ; 16-byte Spill
	fsub.4s	v6, v21, v12
	and.16b	v20, v1, v6
	mov	w14, #-1026555904               ; =0xc2d00000
	dup.4s	v19, w14
	and.16b	v13, v0, v11
	fcmge.4s	v17, v13, v19
	mov	w14, #1120403456                ; =0x42c80000
	dup.4s	v6, w14
	stp	q18, q2, [x15]
	fcmge.4s	v18, v20, v19
	fcmge.4s	v26, v6, v13
	fcmge.4s	v11, v6, v20
	stp	q28, q27, [x16]
	and.16b	v18, v18, v11
	and.16b	v17, v17, v26
	and.16b	v17, v17, v13
	mov	w14, #43579                     ; =0xaa3b
	movk	w14, #16312, lsl #16
	dup.4s	v26, w14
	stp	q30, q29, [x17]
	and.16b	v18, v18, v20
	fmul.4s	v27, v18, v26
	fmul.4s	v28, v17, v26
	stp	q8, q31, [x0]
	movi.4s	v2, #75, lsl #24
	mvni.4s	v21, #128, lsl #24
	mov.16b	v29, v21
	bsl.16b	v29, v2, v28
	mov.16b	v30, v21
	bsl.16b	v30, v2, v27
	fadd.4s	v27, v27, v30
	stp	q10, q9, [x4]
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	fsub.4s	v27, v27, v30
	fcvtzs.4s	v10, v27
	fcvtzs.4s	v11, v28
	scvtf.4s	v27, v11
	mov	w14, #29184                     ; =0x7200
	movk	w14, #16177, lsl #16
	dup.4s	v15, w14
	scvtf.4s	v28, v10
	fmul.4s	v29, v28, v15
	fmul.4s	v30, v27, v15
	fsub.4s	v30, v17, v30
	mov	w14, #48782                     ; =0xbe8e
	movk	w14, #13759, lsl #16
	dup.4s	v22, w14
	fsub.4s	v17, v18, v29
	fmul.4s	v18, v27, v22
	fmul.4s	v27, v28, v22
	fsub.4s	v31, v17, v27
	mov	w14, #11226                     ; =0x2bda
	movk	w14, #14672, lsl #16
	dup.4s	v17, w14
	fsub.4s	v30, v30, v18
	fmul.4s	v27, v30, v17
	mov	w14, #38601                     ; =0x96c9
	movk	w14, #15030, lsl #16
	dup.4s	v18, w14
	fadd.4s	v27, v27, v18
	fmul.4s	v28, v30, v27
	mov	w14, #34982                     ; =0x88a6
	movk	w14, #15368, lsl #16
	dup.4s	v27, w14
	fadd.4s	v28, v28, v27
	fmul.4s	v29, v30, v28
	mov	w14, #43642                     ; =0xaa7a
	movk	w14, #15658, lsl #16
	dup.4s	v28, w14
	fadd.4s	v29, v29, v28
	fmul.4s	v8, v30, v29
	mov	w14, #43691                     ; =0xaaab
	movk	w14, #15914, lsl #16
	dup.4s	v29, w14
	fadd.4s	v8, v8, v29
	fmul.4s	v8, v30, v8
	movi.4s	v2, #63, lsl #24
	fadd.4s	v8, v8, v2
	fmul.4s	v9, v30, v30
	fmul.4s	v8, v9, v8
	fmul.4s	v9, v31, v17
	fadd.4s	v9, v9, v18
	fmul.4s	v9, v31, v9
	fadd.4s	v9, v9, v27
	fmul.4s	v9, v31, v9
	fadd.4s	v9, v9, v28
	fmul.4s	v9, v31, v9
	fadd.4s	v9, v9, v29
	fmul.4s	v9, v31, v9
	fadd.4s	v9, v9, v2
	fmul.4s	v12, v31, v31
	fmul.4s	v9, v12, v9
	fadd.4s	v31, v31, v9
	fadd.4s	v30, v30, v8
	fmov.4s	v21, #1.00000000
	fadd.4s	v31, v31, v21
	sshr.4s	v8, v10, #1
	shl.4s	v9, v8, #23
	add.4s	v9, v9, v21
	fmul.4s	v31, v31, v9
	fadd.4s	v30, v30, v21
	sshr.4s	v9, v11, #1
	shl.4s	v12, v9, #23
	add.4s	v12, v12, v21
	fmul.4s	v30, v30, v12
	sub.4s	v8, v10, v8
	sub.4s	v9, v11, v9
	shl.4s	v9, v9, #23
	shl.4s	v8, v8, #23
	add.4s	v8, v8, v21
	add.4s	v9, v9, v21
	fmul.4s	v30, v30, v9
	fmul.4s	v31, v31, v8
	fcmgt.4s	v8, v19, v20
	bic.16b	v31, v31, v8
	fcmgt.4s	v8, v19, v13
	bic.16b	v30, v30, v8
	fcmgt.4s	v8, v13, v6
	mvni.4s	v9, #127, msl #16
	fneg.4s	v12, v9
	bit.16b	v30, v12, v8
	fcmgt.4s	v8, v20, v6
	bit.16b	v31, v12, v8
	str	q14, [sp, #7744]                ; 16-byte Spill
	ldr	q2, [sp, #9264]                 ; 16-byte Reload
	fsub.4s	v8, v2, v14
	fcmeq.4s	v9, v13, v13
	fcmeq.4s	v20, v20, v20
	ldr	q2, [sp, #9744]                 ; 16-byte Reload
	bsl.16b	v20, v31, v2
	str	q20, [sp, #9024]                ; 16-byte Spill
	mov.16b	v20, v9
	bsl.16b	v20, v30, v2
	str	q20, [sp, #9008]                ; 16-byte Spill
	and.16b	v20, v0, v8
	fcmge.4s	v30, v20, v19
	fcmge.4s	v31, v6, v20
	and.16b	v30, v30, v31
	ldr	q8, [sp, #9280]                 ; 16-byte Reload
	ldr	q31, [sp, #8992]                ; 16-byte Reload
	fsub.4s	v31, v8, v31
	and.16b	v10, v1, v31
	fcmge.4s	v31, v10, v19
	fcmge.4s	v8, v6, v10
	and.16b	v31, v31, v8
	and.16b	v31, v31, v10
	fmul.4s	v8, v31, v26
	mvni.4s	v11, #128, lsl #24
	movi.4s	v13, #75, lsl #24
	mov.16b	v9, v11
	bsl.16b	v9, v13, v8
	fadd.4s	v8, v8, v9
	fsub.4s	v8, v8, v9
	and.16b	v30, v30, v20
	fmul.4s	v9, v30, v26
	bsl.16b	v11, v13, v9
	fadd.4s	v9, v9, v11
	fsub.4s	v9, v9, v11
	fcvtzs.4s	v11, v8
	scvtf.4s	v8, v11
	fmul.4s	v13, v8, v15
	fsub.4s	v31, v31, v13
	fcvtzs.4s	v9, v9
	scvtf.4s	v13, v9
	fmul.4s	v14, v13, v15
	fsub.4s	v30, v30, v14
	fmul.4s	v13, v13, v22
	fsub.4s	v30, v30, v13
	fmul.4s	v8, v8, v22
	fsub.4s	v31, v31, v8
	fmul.4s	v8, v31, v17
	fadd.4s	v8, v8, v18
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v27
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v28
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v29
	fmul.4s	v8, v31, v8
	movi.4s	v14, #63, lsl #24
	fadd.4s	v8, v8, v14
	fmul.4s	v13, v31, v31
	fmul.4s	v8, v13, v8
	fmul.4s	v13, v30, v17
	fadd.4s	v13, v13, v18
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v28
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v29
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v14
	fmul.4s	v14, v30, v30
	fmul.4s	v13, v14, v13
	fadd.4s	v30, v30, v13
	fadd.4s	v31, v31, v8
	fadd.4s	v30, v30, v21
	sshr.4s	v8, v9, #1
	shl.4s	v13, v8, #23
	add.4s	v13, v13, v21
	fmul.4s	v30, v30, v13
	fadd.4s	v31, v31, v21
	sshr.4s	v13, v11, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v21
	fmul.4s	v31, v31, v14
	sub.4s	v8, v9, v8
	sub.4s	v9, v11, v13
	shl.4s	v9, v9, #23
	add.4s	v9, v9, v21
	fmul.4s	v31, v31, v9
	shl.4s	v8, v8, #23
	add.4s	v8, v8, v21
	fmul.4s	v30, v30, v8
	fcmgt.4s	v8, v19, v20
	bic.16b	v30, v30, v8
	fcmgt.4s	v8, v19, v10
	bic.16b	v31, v31, v8
	fcmgt.4s	v8, v10, v6
	bit.16b	v31, v12, v8
	fcmgt.4s	v8, v20, v6
	bit.16b	v30, v12, v8
	fcmeq.4s	v20, v20, v20
	bsl.16b	v20, v30, v2
	str	q20, [sp, #8784]                ; 16-byte Spill
	fcmeq.4s	v20, v10, v10
	bsl.16b	v20, v31, v2
	str	q20, [sp, #8768]                ; 16-byte Spill
	ldr	q20, [sp, #9296]                ; 16-byte Reload
	ldr	q30, [sp, #8880]                ; 16-byte Reload
	fsub.4s	v20, v20, v30
	and.16b	v20, v0, v20
	fcmge.4s	v30, v20, v19
	fcmge.4s	v31, v6, v20
	and.16b	v30, v30, v31
	ldr	q8, [sp, #9312]                 ; 16-byte Reload
	ldr	q31, [sp, #8976]                ; 16-byte Reload
	fsub.4s	v31, v8, v31
	and.16b	v10, v1, v31
	fcmge.4s	v31, v10, v19
	fcmge.4s	v8, v6, v10
	and.16b	v31, v31, v8
	and.16b	v31, v31, v10
	fmul.4s	v8, v31, v26
	mvni.4s	v11, #128, lsl #24
	movi.4s	v13, #75, lsl #24
	mov.16b	v9, v11
	bsl.16b	v9, v13, v8
	fadd.4s	v8, v8, v9
	fsub.4s	v8, v8, v9
	and.16b	v30, v30, v20
	fmul.4s	v9, v30, v26
	bsl.16b	v11, v13, v9
	fadd.4s	v9, v9, v11
	fsub.4s	v9, v9, v11
	fcvtzs.4s	v11, v8
	scvtf.4s	v8, v11
	fmul.4s	v13, v8, v15
	fsub.4s	v31, v31, v13
	fcvtzs.4s	v9, v9
	scvtf.4s	v13, v9
	fmul.4s	v14, v13, v15
	fsub.4s	v30, v30, v14
	fmul.4s	v13, v13, v22
	fsub.4s	v30, v30, v13
	fmul.4s	v8, v8, v22
	fsub.4s	v31, v31, v8
	fmul.4s	v8, v31, v17
	fadd.4s	v8, v8, v18
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v27
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v28
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v29
	fmul.4s	v8, v31, v8
	movi.4s	v14, #63, lsl #24
	fadd.4s	v8, v8, v14
	fmul.4s	v13, v31, v31
	fmul.4s	v8, v13, v8
	fmul.4s	v13, v30, v17
	fadd.4s	v13, v13, v18
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v28
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v29
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v14
	fmul.4s	v14, v30, v30
	fmul.4s	v13, v14, v13
	fadd.4s	v30, v30, v13
	fadd.4s	v31, v31, v8
	fadd.4s	v30, v30, v21
	sshr.4s	v8, v9, #1
	shl.4s	v13, v8, #23
	add.4s	v13, v13, v21
	fmul.4s	v30, v30, v13
	fadd.4s	v31, v31, v21
	sshr.4s	v13, v11, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v21
	fmul.4s	v31, v31, v14
	sub.4s	v8, v9, v8
	sub.4s	v9, v11, v13
	shl.4s	v9, v9, #23
	add.4s	v9, v9, v21
	fmul.4s	v31, v31, v9
	shl.4s	v8, v8, #23
	add.4s	v8, v8, v21
	fmul.4s	v30, v30, v8
	fcmgt.4s	v8, v19, v20
	bic.16b	v30, v30, v8
	fcmgt.4s	v8, v19, v10
	bic.16b	v31, v31, v8
	fcmgt.4s	v8, v10, v6
	bit.16b	v31, v12, v8
	fcmgt.4s	v8, v20, v6
	bit.16b	v30, v12, v8
	fcmeq.4s	v20, v20, v20
	bsl.16b	v20, v30, v2
	str	q20, [sp, #8752]                ; 16-byte Spill
	fcmeq.4s	v20, v10, v10
	bsl.16b	v20, v31, v2
	str	q20, [sp, #8736]                ; 16-byte Spill
	ldr	q30, [sp, #9328]                ; 16-byte Reload
	ldr	q20, [sp, #8864]                ; 16-byte Reload
	fsub.4s	v20, v30, v20
	and.16b	v20, v0, v20
	fcmge.4s	v30, v20, v19
	fcmge.4s	v31, v6, v20
	and.16b	v30, v30, v31
	ldr	q8, [sp, #9344]                 ; 16-byte Reload
	ldr	q31, [sp, #8960]                ; 16-byte Reload
	fsub.4s	v31, v8, v31
	and.16b	v10, v1, v31
	fcmge.4s	v31, v10, v19
	fcmge.4s	v8, v6, v10
	and.16b	v31, v31, v8
	and.16b	v31, v31, v10
	fmul.4s	v8, v31, v26
	movi.4s	v11, #75, lsl #24
	mvni.4s	v13, #128, lsl #24
	mov.16b	v9, v13
	bsl.16b	v9, v11, v8
	fadd.4s	v8, v8, v9
	fsub.4s	v8, v8, v9
	and.16b	v30, v30, v20
	fmul.4s	v9, v30, v26
	bif.16b	v11, v9, v13
	fadd.4s	v9, v9, v11
	fsub.4s	v9, v9, v11
	fcvtzs.4s	v11, v8
	scvtf.4s	v8, v11
	fmul.4s	v13, v8, v15
	fsub.4s	v31, v31, v13
	fcvtzs.4s	v9, v9
	scvtf.4s	v13, v9
	fmul.4s	v14, v13, v15
	fsub.4s	v30, v30, v14
	fmul.4s	v13, v13, v22
	fsub.4s	v30, v30, v13
	fmul.4s	v8, v8, v22
	fsub.4s	v31, v31, v8
	fmul.4s	v8, v31, v17
	fadd.4s	v8, v8, v18
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v27
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v28
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v29
	fmul.4s	v8, v31, v8
	movi.4s	v14, #63, lsl #24
	fadd.4s	v8, v8, v14
	fmul.4s	v13, v31, v31
	fmul.4s	v8, v13, v8
	fmul.4s	v13, v30, v17
	fadd.4s	v13, v13, v18
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v28
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v29
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v14
	fmul.4s	v14, v30, v30
	fmul.4s	v13, v14, v13
	fadd.4s	v30, v30, v13
	fadd.4s	v31, v31, v8
	fadd.4s	v30, v30, v21
	sshr.4s	v8, v9, #1
	shl.4s	v13, v8, #23
	add.4s	v13, v13, v21
	fmul.4s	v30, v30, v13
	fadd.4s	v31, v31, v21
	sshr.4s	v13, v11, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v21
	fmul.4s	v31, v31, v14
	sub.4s	v8, v9, v8
	sub.4s	v9, v11, v13
	shl.4s	v9, v9, #23
	add.4s	v9, v9, v21
	fmul.4s	v31, v31, v9
	shl.4s	v8, v8, #23
	add.4s	v8, v8, v21
	fmul.4s	v30, v30, v8
	fcmgt.4s	v8, v19, v20
	bic.16b	v30, v30, v8
	fcmgt.4s	v8, v19, v10
	bic.16b	v31, v31, v8
	fcmgt.4s	v8, v10, v6
	bit.16b	v31, v12, v8
	fcmgt.4s	v8, v20, v6
	bit.16b	v30, v12, v8
	fcmeq.4s	v20, v20, v20
	bsl.16b	v20, v30, v2
	str	q20, [sp, #8720]                ; 16-byte Spill
	fcmeq.4s	v20, v10, v10
	bsl.16b	v20, v31, v2
	str	q20, [sp, #8704]                ; 16-byte Spill
	ldr	q30, [sp, #9360]                ; 16-byte Reload
	ldr	q20, [sp, #8848]                ; 16-byte Reload
	fsub.4s	v20, v30, v20
	and.16b	v20, v0, v20
	fcmge.4s	v30, v20, v19
	fcmge.4s	v31, v6, v20
	and.16b	v30, v30, v31
	ldr	q8, [sp, #9376]                 ; 16-byte Reload
	ldr	q31, [sp, #8944]                ; 16-byte Reload
	fsub.4s	v31, v8, v31
	and.16b	v10, v1, v31
	fcmge.4s	v31, v10, v19
	fcmge.4s	v8, v6, v10
	and.16b	v31, v31, v8
	and.16b	v31, v31, v10
	fmul.4s	v8, v31, v26
	mvni.4s	v11, #128, lsl #24
	movi.4s	v13, #75, lsl #24
	mov.16b	v9, v11
	bsl.16b	v9, v13, v8
	fadd.4s	v8, v8, v9
	fsub.4s	v8, v8, v9
	and.16b	v30, v30, v20
	fmul.4s	v9, v30, v26
	bsl.16b	v11, v13, v9
	fadd.4s	v9, v9, v11
	fsub.4s	v9, v9, v11
	fcvtzs.4s	v11, v8
	scvtf.4s	v8, v11
	fmul.4s	v13, v8, v15
	fsub.4s	v31, v31, v13
	fcvtzs.4s	v9, v9
	scvtf.4s	v13, v9
	fmul.4s	v14, v13, v15
	fsub.4s	v30, v30, v14
	fmul.4s	v13, v13, v22
	fsub.4s	v30, v30, v13
	fmul.4s	v8, v8, v22
	fsub.4s	v31, v31, v8
	fmul.4s	v8, v31, v17
	fadd.4s	v8, v8, v18
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v27
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v28
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v29
	fmul.4s	v8, v31, v8
	movi.4s	v14, #63, lsl #24
	fadd.4s	v8, v8, v14
	fmul.4s	v13, v31, v31
	fmul.4s	v8, v13, v8
	fmul.4s	v13, v30, v17
	fadd.4s	v13, v13, v18
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v28
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v29
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v14
	fmul.4s	v14, v30, v30
	fmul.4s	v13, v14, v13
	fadd.4s	v30, v30, v13
	fadd.4s	v31, v31, v8
	fadd.4s	v30, v30, v21
	sshr.4s	v8, v9, #1
	shl.4s	v13, v8, #23
	add.4s	v13, v13, v21
	fmul.4s	v30, v30, v13
	fadd.4s	v31, v31, v21
	sshr.4s	v13, v11, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v21
	fmul.4s	v31, v31, v14
	sub.4s	v8, v9, v8
	sub.4s	v9, v11, v13
	shl.4s	v9, v9, #23
	add.4s	v9, v9, v21
	fmul.4s	v31, v31, v9
	shl.4s	v8, v8, #23
	add.4s	v8, v8, v21
	fmul.4s	v30, v30, v8
	fcmgt.4s	v8, v19, v20
	bic.16b	v30, v30, v8
	fcmgt.4s	v8, v19, v10
	bic.16b	v31, v31, v8
	fcmgt.4s	v8, v10, v6
	bit.16b	v31, v12, v8
	fcmgt.4s	v8, v20, v6
	bit.16b	v30, v12, v8
	fcmeq.4s	v20, v20, v20
	bsl.16b	v20, v30, v2
	str	q20, [sp, #8688]                ; 16-byte Spill
	fcmeq.4s	v20, v10, v10
	bsl.16b	v20, v31, v2
	str	q20, [sp, #8672]                ; 16-byte Spill
	ldr	q30, [sp, #9408]                ; 16-byte Reload
	ldr	q20, [sp, #8928]                ; 16-byte Reload
	fsub.4s	v20, v30, v20
	and.16b	v20, v1, v20
	fcmge.4s	v30, v20, v19
	fcmge.4s	v31, v6, v20
	and.16b	v30, v30, v31
	ldr	q8, [sp, #9392]                 ; 16-byte Reload
	ldr	q31, [sp, #8832]                ; 16-byte Reload
	fsub.4s	v31, v8, v31
	and.16b	v10, v0, v31
	fcmge.4s	v31, v10, v19
	fcmge.4s	v8, v6, v10
	and.16b	v31, v31, v8
	and.16b	v31, v31, v10
	fmul.4s	v8, v31, v26
	movi.4s	v11, #75, lsl #24
	mvni.4s	v13, #128, lsl #24
	mov.16b	v9, v13
	bsl.16b	v9, v11, v8
	fadd.4s	v8, v8, v9
	fsub.4s	v8, v8, v9
	and.16b	v30, v30, v20
	fmul.4s	v9, v30, v26
	bif.16b	v11, v9, v13
	fadd.4s	v9, v9, v11
	fsub.4s	v9, v9, v11
	fcvtzs.4s	v11, v8
	scvtf.4s	v8, v11
	fmul.4s	v13, v8, v15
	fsub.4s	v31, v31, v13
	fcvtzs.4s	v9, v9
	scvtf.4s	v13, v9
	fmul.4s	v14, v13, v15
	fsub.4s	v30, v30, v14
	fmul.4s	v13, v13, v22
	fsub.4s	v30, v30, v13
	fmul.4s	v8, v8, v22
	fsub.4s	v31, v31, v8
	fmul.4s	v8, v31, v17
	fadd.4s	v8, v8, v18
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v27
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v28
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v29
	fmul.4s	v8, v31, v8
	movi.4s	v14, #63, lsl #24
	fadd.4s	v8, v8, v14
	fmul.4s	v13, v31, v31
	fmul.4s	v8, v13, v8
	fmul.4s	v13, v30, v17
	fadd.4s	v13, v13, v18
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v28
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v29
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v14
	fmul.4s	v14, v30, v30
	fmul.4s	v13, v14, v13
	fadd.4s	v30, v30, v13
	fadd.4s	v31, v31, v8
	fadd.4s	v30, v30, v21
	sshr.4s	v8, v9, #1
	shl.4s	v13, v8, #23
	add.4s	v13, v13, v21
	fmul.4s	v30, v30, v13
	fadd.4s	v31, v31, v21
	sshr.4s	v13, v11, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v21
	fmul.4s	v31, v31, v14
	sub.4s	v8, v9, v8
	sub.4s	v9, v11, v13
	shl.4s	v9, v9, #23
	add.4s	v9, v9, v21
	fmul.4s	v31, v31, v9
	shl.4s	v8, v8, #23
	add.4s	v8, v8, v21
	fmul.4s	v30, v30, v8
	fcmgt.4s	v8, v19, v20
	bic.16b	v30, v30, v8
	fcmgt.4s	v8, v19, v10
	bic.16b	v31, v31, v8
	fcmgt.4s	v8, v10, v6
	bit.16b	v31, v12, v8
	fcmgt.4s	v8, v20, v6
	bit.16b	v30, v12, v8
	fcmeq.4s	v20, v20, v20
	bsl.16b	v20, v30, v2
	str	q20, [sp, #8656]                ; 16-byte Spill
	fcmeq.4s	v20, v10, v10
	bsl.16b	v20, v31, v2
	str	q20, [sp, #8640]                ; 16-byte Spill
	ldr	q20, [sp, #9424]                ; 16-byte Reload
	ldr	q2, [sp, #8816]                 ; 16-byte Reload
	fsub.4s	v20, v20, v2
	and.16b	v20, v0, v20
	fcmge.4s	v30, v20, v19
	fcmge.4s	v31, v6, v20
	and.16b	v30, v30, v31
	ldr	q31, [sp, #9440]                ; 16-byte Reload
	ldr	q2, [sp, #8912]                 ; 16-byte Reload
	fsub.4s	v31, v31, v2
	and.16b	v10, v1, v31
	fcmge.4s	v31, v10, v19
	fcmge.4s	v8, v6, v10
	and.16b	v31, v31, v8
	and.16b	v31, v31, v10
	fmul.4s	v8, v31, v26
	mvni.4s	v2, #128, lsl #24
	movi.4s	v11, #75, lsl #24
	mov.16b	v9, v2
	bsl.16b	v9, v11, v8
	fadd.4s	v8, v8, v9
	fsub.4s	v8, v8, v9
	and.16b	v30, v30, v20
	fmul.4s	v9, v30, v26
	bif.16b	v11, v9, v2
	fadd.4s	v9, v9, v11
	fsub.4s	v9, v9, v11
	fcvtzs.4s	v11, v8
	scvtf.4s	v8, v11
	fmul.4s	v13, v8, v15
	fsub.4s	v31, v31, v13
	fcvtzs.4s	v9, v9
	scvtf.4s	v13, v9
	fmul.4s	v14, v13, v15
	fsub.4s	v30, v30, v14
	fmul.4s	v13, v13, v22
	fsub.4s	v30, v30, v13
	fmul.4s	v8, v8, v22
	fsub.4s	v31, v31, v8
	fmul.4s	v8, v31, v17
	fadd.4s	v8, v8, v18
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v27
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v28
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v29
	fmul.4s	v8, v31, v8
	movi.4s	v2, #63, lsl #24
	fadd.4s	v8, v8, v2
	fmul.4s	v13, v31, v31
	fmul.4s	v8, v13, v8
	fmul.4s	v13, v30, v17
	fadd.4s	v13, v13, v18
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v28
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v29
	fmul.4s	v13, v30, v13
	fadd.4s	v13, v13, v2
	fmul.4s	v14, v30, v30
	fmul.4s	v13, v14, v13
	fadd.4s	v30, v30, v13
	fadd.4s	v31, v31, v8
	fadd.4s	v30, v30, v21
	sshr.4s	v8, v9, #1
	shl.4s	v13, v8, #23
	add.4s	v13, v13, v21
	fmul.4s	v30, v30, v13
	fadd.4s	v31, v31, v21
	sshr.4s	v13, v11, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v21
	fmul.4s	v31, v31, v14
	sub.4s	v8, v9, v8
	sub.4s	v9, v11, v13
	shl.4s	v9, v9, #23
	add.4s	v9, v9, v21
	fmul.4s	v31, v31, v9
	shl.4s	v8, v8, #23
	add.4s	v8, v8, v21
	fmul.4s	v30, v30, v8
	fcmgt.4s	v8, v19, v20
	bic.16b	v30, v30, v8
	fcmgt.4s	v8, v19, v10
	bic.16b	v31, v31, v8
	fcmgt.4s	v8, v10, v6
	bit.16b	v31, v12, v8
	fcmgt.4s	v8, v20, v6
	bit.16b	v30, v12, v8
	fcmeq.4s	v20, v20, v20
	ldr	q2, [sp, #9744]                 ; 16-byte Reload
	bsl.16b	v20, v30, v2
	str	q20, [sp, #8624]                ; 16-byte Spill
	fcmeq.4s	v20, v10, v10
	bit.16b	v2, v31, v20
	ldr	q30, [sp, #9472]                ; 16-byte Reload
	ldr	q20, [sp, #8800]                ; 16-byte Reload
	fsub.4s	v20, v30, v20
	and.16b	v13, v0, v20
	fcmge.4s	v20, v13, v19
	fcmge.4s	v30, v6, v13
	and.16b	v30, v20, v30
	ldr	q31, [sp, #9456]                ; 16-byte Reload
	ldr	q20, [sp, #8896]                ; 16-byte Reload
	fsub.4s	v20, v31, v20
	and.16b	v20, v1, v20
	fcmge.4s	v31, v20, v19
	fcmge.4s	v8, v6, v20
	and.16b	v31, v31, v8
	and.16b	v31, v31, v20
	fmul.4s	v8, v31, v26
	movi.4s	v10, #75, lsl #24
	mvni.4s	v11, #128, lsl #24
	mov.16b	v9, v11
	bsl.16b	v9, v10, v8
	fadd.4s	v8, v8, v9
	fsub.4s	v8, v8, v9
	and.16b	v30, v30, v13
	fmul.4s	v9, v30, v26
	bif.16b	v10, v9, v11
	fadd.4s	v9, v9, v10
	fsub.4s	v9, v9, v10
	fcvtzs.4s	v10, v8
	scvtf.4s	v8, v10
	fmul.4s	v11, v8, v15
	fsub.4s	v31, v31, v11
	fcvtzs.4s	v11, v9
	scvtf.4s	v9, v11
	fmul.4s	v14, v9, v15
	fsub.4s	v30, v30, v14
	fmul.4s	v8, v8, v22
	fmul.4s	v9, v9, v22
	fsub.4s	v30, v30, v9
	fsub.4s	v31, v31, v8
	fmul.4s	v8, v31, v17
	fadd.4s	v8, v8, v18
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v27
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v28
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v29
	fmul.4s	v8, v31, v8
	movi.4s	v22, #63, lsl #24
	fadd.4s	v8, v8, v22
	fmul.4s	v9, v31, v31
	fmul.4s	v8, v9, v8
	fmul.4s	v9, v30, v17
	fadd.4s	v9, v9, v18
	fmul.4s	v9, v30, v9
	fadd.4s	v9, v9, v27
	fmul.4s	v9, v30, v9
	fadd.4s	v9, v9, v28
	fmul.4s	v9, v30, v9
	fadd.4s	v9, v9, v29
	fmul.4s	v9, v30, v9
	fadd.4s	v9, v9, v22
	fmul.4s	v14, v30, v30
	fmul.4s	v9, v14, v9
	fadd.4s	v30, v30, v9
	fadd.4s	v31, v31, v8
	ldr	x14, [sp, #2104]                ; 8-byte Reload
	ldp	q9, q8, [x14]
	ldr	q22, [sp, #9008]                ; 16-byte Reload
	bit.16b	v8, v22, v0
	ldr	q22, [sp, #9024]                ; 16-byte Reload
	bit.16b	v9, v22, v1
	stp	q9, q8, [x14]
	fadd.4s	v30, v30, v21
	sshr.4s	v8, v11, #1
	shl.4s	v9, v8, #23
	add.4s	v9, v9, v21
	fmul.4s	v30, v30, v9
	ldr	x14, [sp, #2096]                ; 8-byte Reload
	ldp	q9, q14, [x14]
	ldr	q22, [sp, #8768]                ; 16-byte Reload
	bit.16b	v9, v22, v1
	ldr	q22, [sp, #8784]                ; 16-byte Reload
	bit.16b	v14, v22, v0
	stp	q9, q14, [x14]
	ldr	x14, [sp, #2072]                ; 8-byte Reload
	ldp	q9, q14, [x14]
	ldr	q22, [sp, #8736]                ; 16-byte Reload
	bit.16b	v9, v22, v1
	ldr	q22, [sp, #8752]                ; 16-byte Reload
	bit.16b	v14, v22, v0
	stp	q9, q14, [x14]
	fadd.4s	v31, v31, v21
	sshr.4s	v9, v10, #1
	shl.4s	v14, v9, #23
	add.4s	v14, v14, v21
	fmul.4s	v31, v31, v14
	sub.4s	v8, v11, v8
	sub.4s	v9, v10, v9
	ldr	x14, [sp, #2040]                ; 8-byte Reload
	ldp	q10, q11, [x14]
	ldr	q22, [sp, #8704]                ; 16-byte Reload
	bit.16b	v10, v22, v1
	ldr	q22, [sp, #8720]                ; 16-byte Reload
	bit.16b	v11, v22, v0
	stp	q10, q11, [x14]
	shl.4s	v9, v9, #23
	add.4s	v9, v9, v21
	fmul.4s	v31, v31, v9
	ldr	x14, [sp, #2032]                ; 8-byte Reload
	ldp	q9, q10, [x14]
	ldr	q22, [sp, #8672]                ; 16-byte Reload
	bit.16b	v9, v22, v1
	ldr	q22, [sp, #8688]                ; 16-byte Reload
	bit.16b	v10, v22, v0
	stp	q9, q10, [x14]
	shl.4s	v8, v8, #23
	add.4s	v8, v8, v21
	fmul.4s	v30, v30, v8
	fcmgt.4s	v8, v19, v13
	bic.16b	v30, v30, v8
	ldr	x14, [sp, #2008]                ; 8-byte Reload
	ldp	q9, q8, [x14]
	ldr	q21, [sp, #8640]                ; 16-byte Reload
	bit.16b	v8, v21, v0
	ldr	q21, [sp, #8656]                ; 16-byte Reload
	bit.16b	v9, v21, v1
	stp	q9, q8, [x14]
	fcmgt.4s	v8, v19, v20
	bic.16b	v31, v31, v8
	fcmgt.4s	v8, v20, v6
	bit.16b	v31, v12, v8
	ldr	x14, [sp, #1976]                ; 8-byte Reload
	ldp	q8, q9, [x14]
	str	q2, [sp, #7728]                 ; 16-byte Spill
	bit.16b	v8, v2, v1
	ldr	q2, [sp, #8624]                 ; 16-byte Reload
	bit.16b	v9, v2, v0
	stp	q8, q9, [x14]
	fcmgt.4s	v8, v13, v6
	bit.16b	v30, v12, v8
	fcmeq.4s	v8, v13, v13
	ldr	q21, [sp, #9744]                ; 16-byte Reload
	mov.16b	v2, v8
	bsl.16b	v2, v30, v21
	fcmeq.4s	v20, v20, v20
	bit.16b	v21, v31, v20
	ldr	x14, [sp, #1968]                ; 8-byte Reload
	ldp	q20, q30, [x14]
	str	q21, [sp, #7696]                ; 16-byte Spill
	bit.16b	v20, v21, v1
	str	q2, [sp, #7712]                 ; 16-byte Spill
	bit.16b	v30, v2, v0
	stp	q20, q30, [x14]
	mov	x14, #-128                      ; =0xffffffffffffff80
	mov	x15, x3
	ldr	x3, [sp, #3536]                 ; 8-byte Reload
	mov	w4, #29184                      ; =0x7200
	movk	w4, #48945, lsl #16
	b	LBB0_360
LBB0_359:                               ; %else1123
                                        ;   in Loop: Header=BB0_360 Depth=2
	cmeq.8b	v20, v20, #0
	sshll.8h	v30, v20, #0
	sshll2.4s	v20, v30, #0
	sshll.4s	v10, v30, #0
	ldp	q31, q30, [x15]
	and	x16, x12, #0xe0
	add	x16, x3, x16
	ldp	q9, q8, [x16]
	fsub.4s	v31, v31, v9
	fsub.4s	v30, v30, v8
	and.16b	v11, v0, v30
	and.16b	v13, v1, v31
	fcmge.4s	v30, v13, v19
	fcmge.4s	v31, v11, v19
	fcmge.4s	v8, v6, v13
	fcmge.4s	v9, v6, v11
	and.16b	v31, v31, v9
	and.16b	v30, v30, v8
	and.16b	v30, v30, v13
	and.16b	v31, v31, v11
	fmul.4s	v8, v31, v26
	fmul.4s	v9, v30, v26
	movi.4s	v21, #75, lsl #24
	mvni.4s	v22, #128, lsl #24
	mov.16b	v14, v22
	bsl.16b	v14, v21, v9
	mov.16b	v15, v22
	bsl.16b	v15, v21, v8
	fadd.4s	v8, v8, v15
	fadd.4s	v9, v9, v14
	fsub.4s	v9, v9, v14
	fsub.4s	v8, v8, v15
	fcvtzs.4s	v8, v8
	fcvtzs.4s	v9, v9
	scvtf.4s	v14, v9
	scvtf.4s	v15, v8
	dup.4s	v21, w4
	fmul.4s	v22, v15, v21
	fmul.4s	v21, v14, v21
	fadd.4s	v21, v30, v21
	fadd.4s	v22, v31, v22
	dup.4s	v30, w5
	fmul.4s	v31, v14, v30
	fmul.4s	v30, v15, v30
	fadd.4s	v22, v22, v30
	fadd.4s	v21, v21, v31
	fmul.4s	v30, v21, v17
	fmul.4s	v31, v22, v17
	fadd.4s	v31, v31, v18
	fadd.4s	v30, v30, v18
	fmul.4s	v30, v21, v30
	fmul.4s	v31, v22, v31
	fadd.4s	v31, v31, v27
	fadd.4s	v30, v30, v27
	fmul.4s	v30, v21, v30
	fmul.4s	v31, v22, v31
	fadd.4s	v31, v31, v28
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v21, v30
	fmul.4s	v31, v22, v31
	fadd.4s	v31, v31, v29
	fadd.4s	v30, v30, v29
	fmul.4s	v30, v21, v30
	fmul.4s	v31, v22, v31
	movi.4s	v14, #63, lsl #24
	fadd.4s	v31, v31, v14
	fadd.4s	v30, v30, v14
	fmul.4s	v14, v22, v22
	fmul.4s	v15, v21, v21
	fmul.4s	v30, v15, v30
	fmul.4s	v31, v14, v31
	fadd.4s	v22, v22, v31
	fadd.4s	v21, v21, v30
	fmov.4s	v2, #1.00000000
	fadd.4s	v21, v21, v2
	fadd.4s	v22, v22, v2
	sshr.4s	v30, v9, #1
	sshr.4s	v31, v8, #1
	shl.4s	v14, v31, #23
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v2
	add.4s	v14, v14, v2
	fmul.4s	v22, v22, v14
	fmul.4s	v21, v21, v15
	sub.4s	v31, v8, v31
	sub.4s	v30, v9, v30
	shl.4s	v30, v30, #23
	shl.4s	v31, v31, #23
	add.4s	v31, v31, v2
	add.4s	v30, v30, v2
	fmul.4s	v21, v21, v30
	fmul.4s	v22, v22, v31
	fcmgt.4s	v30, v19, v11
	bic.16b	v22, v22, v30
	fcmgt.4s	v30, v19, v13
	bic.16b	v21, v21, v30
	fcmgt.4s	v30, v11, v6
	fcmgt.4s	v31, v13, v6
	bit.16b	v21, v12, v31
	bit.16b	v22, v12, v30
	fcmeq.4s	v30, v13, v13
	fcmeq.4s	v31, v11, v11
	ldr	q8, [sp, #9744]                 ; 16-byte Reload
	bif.16b	v22, v8, v31
	bif.16b	v21, v8, v30
	bic.16b	v21, v21, v10
	bic.16b	v20, v22, v20
	ldr	q22, [x15, #4608]
	ldr	q30, [x15, #4624]
	bif.16b	v20, v30, v0
	bif.16b	v21, v22, v1
	add	x12, x12, #2
	str	q21, [x15, #4608]
	str	q20, [x15, #4624]
	add	x14, x14, #1
	add	x25, x25, #8
	add	x15, x15, #32
	cmp	x12, #256
	b.eq	LBB0_376
LBB0_360:                               ; %direct.true1263
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q20, [sp, #9488]                ; 16-byte Reload
	fmov	w16, s20
	add	x17, x14, #128
	and	x0, x25, #0x78
	orr	x17, x0, x17, lsr #4
	dup.2d	v10, x17
	ldr	q2, [sp, #9664]                 ; 16-byte Reload
	orr.16b	v20, v10, v2
	ldr	q21, [sp, #9696]                ; 16-byte Reload
	add.2d	v11, v21, v20
	ldr	q21, [sp, #9728]                ; 16-byte Reload
	ldr	q31, [sp, #9680]                ; 16-byte Reload
	tbz	w16, #0, LBB0_362
; %bb.361:                              ; %cond.load1077
                                        ;   in Loop: Header=BB0_360 Depth=2
	fmov	x17, d11
	ldr	b20, [x17]
	ldr	q22, [sp, #9712]                ; 16-byte Reload
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_363
	b	LBB0_364
LBB0_362:                               ;   in Loop: Header=BB0_360 Depth=2
	movi.2d	v20, #0000000000000000
	ldr	q22, [sp, #9712]                ; 16-byte Reload
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_364
LBB0_363:                               ; %cond.load1083
                                        ;   in Loop: Header=BB0_360 Depth=2
	mov.d	x17, v11[1]
	ld1.b	{ v20 }[1], [x17]
LBB0_364:                               ; %else1087
                                        ;   in Loop: Header=BB0_360 Depth=2
	ldr	q2, [sp, #9648]                 ; 16-byte Reload
	orr.16b	v30, v10, v2
	add.2d	v11, v31, v30
	tbz	w16, #2, LBB0_370
; %bb.365:                              ; %cond.load1089
                                        ;   in Loop: Header=BB0_360 Depth=2
	fmov	x17, d11
	ld1.b	{ v20 }[2], [x17]
	tbnz	w16, #3, LBB0_371
LBB0_366:                               ; %else1099
                                        ;   in Loop: Header=BB0_360 Depth=2
	ldr	q2, [sp, #9632]                 ; 16-byte Reload
	orr.16b	v30, v10, v2
	add.2d	v11, v21, v30
	tbz	w16, #4, LBB0_372
LBB0_367:                               ; %cond.load1101
                                        ;   in Loop: Header=BB0_360 Depth=2
	fmov	x17, d11
	ld1.b	{ v20 }[4], [x17]
	tbnz	w16, #5, LBB0_373
LBB0_368:                               ; %else1111
                                        ;   in Loop: Header=BB0_360 Depth=2
	ldr	q2, [sp, #9616]                 ; 16-byte Reload
	orr.16b	v30, v10, v2
	add.2d	v10, v22, v30
	tbz	w16, #6, LBB0_374
LBB0_369:                               ; %cond.load1113
                                        ;   in Loop: Header=BB0_360 Depth=2
	fmov	x17, d10
	ld1.b	{ v20 }[6], [x17]
	tbz	w16, #7, LBB0_359
	b	LBB0_375
LBB0_370:                               ; %else1093
                                        ;   in Loop: Header=BB0_360 Depth=2
	tbz	w16, #3, LBB0_366
LBB0_371:                               ; %cond.load1095
                                        ;   in Loop: Header=BB0_360 Depth=2
	mov.d	x17, v11[1]
	ld1.b	{ v20 }[3], [x17]
	ldr	q2, [sp, #9632]                 ; 16-byte Reload
	orr.16b	v30, v10, v2
	add.2d	v11, v21, v30
	tbnz	w16, #4, LBB0_367
LBB0_372:                               ; %else1105
                                        ;   in Loop: Header=BB0_360 Depth=2
	tbz	w16, #5, LBB0_368
LBB0_373:                               ; %cond.load1107
                                        ;   in Loop: Header=BB0_360 Depth=2
	mov.d	x17, v11[1]
	ld1.b	{ v20 }[5], [x17]
	ldr	q2, [sp, #9616]                 ; 16-byte Reload
	orr.16b	v30, v10, v2
	add.2d	v10, v22, v30
	tbnz	w16, #6, LBB0_369
LBB0_374:                               ; %else1117
                                        ;   in Loop: Header=BB0_360 Depth=2
	tbz	w16, #7, LBB0_359
LBB0_375:                               ; %cond.load1119
                                        ;   in Loop: Header=BB0_360 Depth=2
	mov.d	x16, v10[1]
	ld1.b	{ v20 }[7], [x16]
	b	LBB0_359
LBB0_376:                               ; %direct.false1264
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	x14, [sp, #1944]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7680]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	str	q2, [sp, #7664]                 ; 16-byte Spill
	ldr	x14, [sp, #1912]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7328]                 ; 16-byte Spill
	str	q2, [sp, #7536]                 ; 16-byte Spill
	ldr	x14, [sp, #1904]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7648]                 ; 16-byte Spill
	str	q2, [sp, #7312]                 ; 16-byte Spill
	ldr	x14, [sp, #1880]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7504]                 ; 16-byte Spill
	str	q2, [sp, #7520]                 ; 16-byte Spill
	ldr	x14, [sp, #1848]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7632]                 ; 16-byte Spill
	str	q2, [sp, #7296]                 ; 16-byte Spill
	ldr	x14, [sp, #1840]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7472]                 ; 16-byte Spill
	str	q2, [sp, #7488]                 ; 16-byte Spill
	ldr	x14, [sp, #1816]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7616]                 ; 16-byte Spill
	str	q2, [sp, #7280]                 ; 16-byte Spill
	ldr	x14, [sp, #1784]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7440]                 ; 16-byte Spill
	str	q2, [sp, #7456]                 ; 16-byte Spill
	ldr	x14, [sp, #1776]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7600]                 ; 16-byte Spill
	str	q2, [sp, #7264]                 ; 16-byte Spill
	ldr	x14, [sp, #1752]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7408]                 ; 16-byte Spill
	str	q2, [sp, #7424]                 ; 16-byte Spill
	ldr	x14, [sp, #1720]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7584]                 ; 16-byte Spill
	str	q2, [sp, #7248]                 ; 16-byte Spill
	ldr	x14, [sp, #1712]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7376]                 ; 16-byte Spill
	str	q2, [sp, #7392]                 ; 16-byte Spill
	ldr	x14, [sp, #1688]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7568]                 ; 16-byte Spill
	str	q2, [sp, #7232]                 ; 16-byte Spill
	ldr	x14, [sp, #1656]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7344]                 ; 16-byte Spill
	str	q2, [sp, #7360]                 ; 16-byte Spill
	ldr	x14, [sp, #1648]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7552]                 ; 16-byte Spill
	str	q2, [sp, #7216]                 ; 16-byte Spill
	add	x14, x11, #21, lsl #12          ; =86016
	ldp	q2, q6, [x14]
	str	q6, [sp, #7168]                 ; 16-byte Spill
	str	q2, [sp, #7152]                 ; 16-byte Spill
	ldr	x3, [sp, #2808]                 ; 8-byte Reload
	ldr	x4, [sp, #2840]                 ; 8-byte Reload
	mov	w5, #48                         ; =0x30
	ldr	x25, [sp, #2872]                ; 8-byte Reload
	ldr	x26, [sp, #3528]                ; 8-byte Reload
	ldr	x14, [sp, #1624]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7184]                 ; 16-byte Spill
	str	q2, [sp, #7200]                 ; 16-byte Spill
	ldr	x14, [sp, #1592]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6944]                 ; 16-byte Spill
	str	q2, [sp, #7056]                 ; 16-byte Spill
	ldr	x14, [sp, #1584]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6752]                 ; 16-byte Spill
	str	q2, [sp, #6928]                 ; 16-byte Spill
	ldr	x14, [sp, #1560]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7040]                 ; 16-byte Spill
	str	q2, [sp, #6736]                 ; 16-byte Spill
	ldr	x14, [sp, #1528]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6896]                 ; 16-byte Spill
	str	q2, [sp, #6912]                 ; 16-byte Spill
	ldr	x14, [sp, #1520]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7024]                 ; 16-byte Spill
	str	q2, [sp, #6720]                 ; 16-byte Spill
	ldr	x14, [sp, #1496]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6864]                 ; 16-byte Spill
	str	q2, [sp, #6880]                 ; 16-byte Spill
	ldr	x14, [sp, #1464]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7008]                 ; 16-byte Spill
	str	q2, [sp, #6704]                 ; 16-byte Spill
	ldr	x14, [sp, #1456]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6832]                 ; 16-byte Spill
	str	q2, [sp, #6848]                 ; 16-byte Spill
	ldr	x14, [sp, #1432]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6992]                 ; 16-byte Spill
	str	q2, [sp, #6688]                 ; 16-byte Spill
	ldr	x14, [sp, #1400]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6800]                 ; 16-byte Spill
	str	q2, [sp, #6816]                 ; 16-byte Spill
	ldr	x14, [sp, #1392]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6976]                 ; 16-byte Spill
	str	q2, [sp, #6672]                 ; 16-byte Spill
	ldr	x14, [sp, #1368]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6768]                 ; 16-byte Spill
	str	q2, [sp, #6784]                 ; 16-byte Spill
	ldr	x14, [sp, #1336]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7104]                 ; 16-byte Spill
	str	q2, [sp, #7120]                 ; 16-byte Spill
	ldr	x14, [sp, #1328]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7136]                 ; 16-byte Spill
	str	q2, [sp, #6960]                 ; 16-byte Spill
	ldr	x14, [sp, #1304]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #7072]                 ; 16-byte Spill
	str	q2, [sp, #7088]                 ; 16-byte Spill
	ldr	x14, [sp, #1272]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6528]                 ; 16-byte Spill
	str	q2, [sp, #6656]                 ; 16-byte Spill
	ldr	x14, [sp, #1264]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6272]                 ; 16-byte Spill
	str	q2, [sp, #6512]                 ; 16-byte Spill
	ldr	x14, [sp, #1240]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6640]                 ; 16-byte Spill
	str	q2, [sp, #6256]                 ; 16-byte Spill
	ldr	x14, [sp, #1208]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6480]                 ; 16-byte Spill
	str	q2, [sp, #6496]                 ; 16-byte Spill
	ldr	x14, [sp, #1200]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6624]                 ; 16-byte Spill
	str	q2, [sp, #6240]                 ; 16-byte Spill
	ldr	x14, [sp, #1176]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6448]                 ; 16-byte Spill
	str	q2, [sp, #6464]                 ; 16-byte Spill
	ldr	x14, [sp, #1144]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6608]                 ; 16-byte Spill
	str	q2, [sp, #6224]                 ; 16-byte Spill
	ldr	x14, [sp, #1136]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6416]                 ; 16-byte Spill
	str	q2, [sp, #6432]                 ; 16-byte Spill
	ldr	x14, [sp, #1112]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6592]                 ; 16-byte Spill
	str	q2, [sp, #6208]                 ; 16-byte Spill
	ldr	x14, [sp, #1080]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6384]                 ; 16-byte Spill
	str	q2, [sp, #6400]                 ; 16-byte Spill
	ldr	x14, [sp, #1072]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6576]                 ; 16-byte Spill
	str	q2, [sp, #6192]                 ; 16-byte Spill
	ldr	x14, [sp, #1048]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6352]                 ; 16-byte Spill
	str	q2, [sp, #6368]                 ; 16-byte Spill
	ldr	x14, [sp, #1016]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6560]                 ; 16-byte Spill
	str	q2, [sp, #6176]                 ; 16-byte Spill
	ldr	x14, [sp, #1008]                ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6320]                 ; 16-byte Spill
	str	q2, [sp, #6336]                 ; 16-byte Spill
	ldr	x14, [sp, #984]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6544]                 ; 16-byte Spill
	str	q2, [sp, #6160]                 ; 16-byte Spill
	ldr	x14, [sp, #944]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6288]                 ; 16-byte Spill
	str	q2, [sp, #6304]                 ; 16-byte Spill
	ldr	x14, [sp, #936]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6016]                 ; 16-byte Spill
	str	q2, [sp, #6144]                 ; 16-byte Spill
	ldr	x14, [sp, #928]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5760]                 ; 16-byte Spill
	str	q2, [sp, #6000]                 ; 16-byte Spill
	ldr	x14, [sp, #920]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6128]                 ; 16-byte Spill
	str	q2, [sp, #5744]                 ; 16-byte Spill
	ldr	x14, [sp, #912]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5968]                 ; 16-byte Spill
	str	q2, [sp, #5984]                 ; 16-byte Spill
	ldr	x14, [sp, #904]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6112]                 ; 16-byte Spill
	str	q2, [sp, #5728]                 ; 16-byte Spill
	ldr	x14, [sp, #896]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5936]                 ; 16-byte Spill
	str	q2, [sp, #5952]                 ; 16-byte Spill
	ldr	x14, [sp, #888]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6096]                 ; 16-byte Spill
	str	q2, [sp, #5712]                 ; 16-byte Spill
	ldr	x14, [sp, #880]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5904]                 ; 16-byte Spill
	str	q2, [sp, #5920]                 ; 16-byte Spill
	ldr	x14, [sp, #872]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6080]                 ; 16-byte Spill
	str	q2, [sp, #5696]                 ; 16-byte Spill
	ldr	x14, [sp, #864]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5872]                 ; 16-byte Spill
	str	q2, [sp, #5888]                 ; 16-byte Spill
	ldr	x14, [sp, #856]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6064]                 ; 16-byte Spill
	str	q2, [sp, #5680]                 ; 16-byte Spill
	ldr	x14, [sp, #848]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5840]                 ; 16-byte Spill
	str	q2, [sp, #5856]                 ; 16-byte Spill
	ldr	x14, [sp, #840]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6048]                 ; 16-byte Spill
	str	q2, [sp, #5664]                 ; 16-byte Spill
	ldr	x14, [sp, #832]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5808]                 ; 16-byte Spill
	str	q2, [sp, #5824]                 ; 16-byte Spill
	ldr	x14, [sp, #824]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #6032]                 ; 16-byte Spill
	str	q2, [sp, #5648]                 ; 16-byte Spill
	ldr	x14, [sp, #816]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5776]                 ; 16-byte Spill
	str	q2, [sp, #5792]                 ; 16-byte Spill
	ldr	x14, [sp, #808]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5504]                 ; 16-byte Spill
	str	q2, [sp, #5632]                 ; 16-byte Spill
	ldr	x14, [sp, #800]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5248]                 ; 16-byte Spill
	str	q2, [sp, #5488]                 ; 16-byte Spill
	ldr	x14, [sp, #792]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5616]                 ; 16-byte Spill
	str	q2, [sp, #5232]                 ; 16-byte Spill
	ldr	x14, [sp, #784]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5456]                 ; 16-byte Spill
	str	q2, [sp, #5472]                 ; 16-byte Spill
	ldr	x14, [sp, #776]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5600]                 ; 16-byte Spill
	str	q2, [sp, #5216]                 ; 16-byte Spill
	ldr	x14, [sp, #768]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5424]                 ; 16-byte Spill
	str	q2, [sp, #5440]                 ; 16-byte Spill
	ldr	x14, [sp, #760]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5584]                 ; 16-byte Spill
	str	q2, [sp, #5200]                 ; 16-byte Spill
	ldr	x14, [sp, #752]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5392]                 ; 16-byte Spill
	str	q2, [sp, #5408]                 ; 16-byte Spill
	ldr	x14, [sp, #744]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5568]                 ; 16-byte Spill
	str	q2, [sp, #5184]                 ; 16-byte Spill
	ldr	x14, [sp, #736]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5360]                 ; 16-byte Spill
	str	q2, [sp, #5376]                 ; 16-byte Spill
	ldr	x14, [sp, #728]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5552]                 ; 16-byte Spill
	str	q2, [sp, #5168]                 ; 16-byte Spill
	ldr	x14, [sp, #720]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5328]                 ; 16-byte Spill
	str	q2, [sp, #5344]                 ; 16-byte Spill
	ldr	x14, [sp, #712]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5536]                 ; 16-byte Spill
	str	q2, [sp, #5152]                 ; 16-byte Spill
	ldr	x14, [sp, #704]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5296]                 ; 16-byte Spill
	str	q2, [sp, #5312]                 ; 16-byte Spill
	ldr	x14, [sp, #696]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5520]                 ; 16-byte Spill
	str	q2, [sp, #5136]                 ; 16-byte Spill
	ldr	x14, [sp, #688]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5264]                 ; 16-byte Spill
	str	q2, [sp, #5280]                 ; 16-byte Spill
	ldr	x14, [sp, #680]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4992]                 ; 16-byte Spill
	str	q2, [sp, #5120]                 ; 16-byte Spill
	ldr	x14, [sp, #672]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4736]                 ; 16-byte Spill
	str	q2, [sp, #4976]                 ; 16-byte Spill
	ldr	x14, [sp, #664]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5104]                 ; 16-byte Spill
	str	q2, [sp, #4720]                 ; 16-byte Spill
	ldr	x14, [sp, #656]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4944]                 ; 16-byte Spill
	str	q2, [sp, #4960]                 ; 16-byte Spill
	ldr	x14, [sp, #648]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5088]                 ; 16-byte Spill
	str	q2, [sp, #4704]                 ; 16-byte Spill
	ldr	x14, [sp, #640]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4912]                 ; 16-byte Spill
	str	q2, [sp, #4928]                 ; 16-byte Spill
	ldr	x14, [sp, #632]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5072]                 ; 16-byte Spill
	str	q2, [sp, #4688]                 ; 16-byte Spill
	ldr	x14, [sp, #624]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4880]                 ; 16-byte Spill
	str	q2, [sp, #4896]                 ; 16-byte Spill
	ldr	x14, [sp, #616]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5056]                 ; 16-byte Spill
	str	q2, [sp, #4672]                 ; 16-byte Spill
	ldr	x14, [sp, #608]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4848]                 ; 16-byte Spill
	str	q2, [sp, #4864]                 ; 16-byte Spill
	ldr	x14, [sp, #600]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5040]                 ; 16-byte Spill
	str	q2, [sp, #4656]                 ; 16-byte Spill
	ldr	x14, [sp, #592]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4816]                 ; 16-byte Spill
	str	q2, [sp, #4832]                 ; 16-byte Spill
	ldr	x14, [sp, #584]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5024]                 ; 16-byte Spill
	str	q2, [sp, #4640]                 ; 16-byte Spill
	ldr	x14, [sp, #576]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4784]                 ; 16-byte Spill
	str	q2, [sp, #4800]                 ; 16-byte Spill
	ldr	x14, [sp, #568]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #5008]                 ; 16-byte Spill
	str	q2, [sp, #4624]                 ; 16-byte Spill
	ldr	x14, [sp, #560]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4752]                 ; 16-byte Spill
	str	q2, [sp, #4768]                 ; 16-byte Spill
	ldr	x14, [sp, #552]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4480]                 ; 16-byte Spill
	str	q2, [sp, #4608]                 ; 16-byte Spill
	ldr	x14, [sp, #544]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4224]                 ; 16-byte Spill
	str	q2, [sp, #4464]                 ; 16-byte Spill
	ldr	x14, [sp, #536]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4592]                 ; 16-byte Spill
	str	q2, [sp, #4208]                 ; 16-byte Spill
	ldr	x14, [sp, #528]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4432]                 ; 16-byte Spill
	str	q2, [sp, #4448]                 ; 16-byte Spill
	ldr	x14, [sp, #520]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4576]                 ; 16-byte Spill
	str	q2, [sp, #4192]                 ; 16-byte Spill
	ldp	x14, x15, [sp, #504]            ; 16-byte Folded Reload
	ldp	q2, q6, [x15]
	str	q6, [sp, #4400]                 ; 16-byte Spill
	str	q2, [sp, #4416]                 ; 16-byte Spill
	ldp	q2, q6, [x14]
	str	q6, [sp, #4560]                 ; 16-byte Spill
	str	q2, [sp, #4176]                 ; 16-byte Spill
	ldr	x14, [sp, #496]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4368]                 ; 16-byte Spill
	str	q2, [sp, #4384]                 ; 16-byte Spill
	ldr	x14, [sp, #424]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4544]                 ; 16-byte Spill
	str	q2, [sp, #4160]                 ; 16-byte Spill
	ldr	x14, [sp, #416]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4336]                 ; 16-byte Spill
	str	q2, [sp, #4352]                 ; 16-byte Spill
	ldr	x14, [sp, #408]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4528]                 ; 16-byte Spill
	str	q2, [sp, #4144]                 ; 16-byte Spill
	ldr	x14, [sp, #400]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4304]                 ; 16-byte Spill
	str	q2, [sp, #4320]                 ; 16-byte Spill
	ldr	x14, [sp, #392]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4512]                 ; 16-byte Spill
	str	q2, [sp, #4128]                 ; 16-byte Spill
	ldr	x14, [sp, #384]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4272]                 ; 16-byte Spill
	str	q2, [sp, #4288]                 ; 16-byte Spill
	ldr	x14, [sp, #376]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4496]                 ; 16-byte Spill
	str	q2, [sp, #4112]                 ; 16-byte Spill
	ldr	x14, [sp, #368]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4240]                 ; 16-byte Spill
	str	q2, [sp, #4256]                 ; 16-byte Spill
	ldr	x14, [sp, #360]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #3968]                 ; 16-byte Spill
	str	q2, [sp, #4096]                 ; 16-byte Spill
	ldr	x14, [sp, #352]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #3712]                 ; 16-byte Spill
	str	q2, [sp, #3952]                 ; 16-byte Spill
	ldr	x14, [sp, #344]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4080]                 ; 16-byte Spill
	str	q2, [sp, #3696]                 ; 16-byte Spill
	ldr	x14, [sp, #336]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #3920]                 ; 16-byte Spill
	str	q2, [sp, #3936]                 ; 16-byte Spill
	ldr	x14, [sp, #328]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4064]                 ; 16-byte Spill
	str	q2, [sp, #3680]                 ; 16-byte Spill
	ldr	x14, [sp, #320]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #3888]                 ; 16-byte Spill
	str	q2, [sp, #3904]                 ; 16-byte Spill
	ldr	x14, [sp, #312]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4048]                 ; 16-byte Spill
	str	q2, [sp, #3664]                 ; 16-byte Spill
	ldr	x14, [sp, #304]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #3856]                 ; 16-byte Spill
	str	q2, [sp, #3872]                 ; 16-byte Spill
	ldr	x14, [sp, #296]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4032]                 ; 16-byte Spill
	str	q2, [sp, #3648]                 ; 16-byte Spill
	ldr	x14, [sp, #288]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #3824]                 ; 16-byte Spill
	str	q2, [sp, #3840]                 ; 16-byte Spill
	ldr	x14, [sp, #280]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4016]                 ; 16-byte Spill
	str	q2, [sp, #3632]                 ; 16-byte Spill
	ldr	x14, [sp, #272]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #3792]                 ; 16-byte Spill
	str	q2, [sp, #3808]                 ; 16-byte Spill
	ldr	x14, [sp, #264]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #4000]                 ; 16-byte Spill
	str	q2, [sp, #3616]                 ; 16-byte Spill
	ldr	x14, [sp, #256]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #3760]                 ; 16-byte Spill
	str	q2, [sp, #3776]                 ; 16-byte Spill
	ldr	x14, [sp, #248]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #3984]                 ; 16-byte Spill
	str	q2, [sp, #3600]                 ; 16-byte Spill
	ldr	x14, [sp, #240]                 ; 8-byte Reload
	ldp	q2, q6, [x14]
	str	q6, [sp, #3728]                 ; 16-byte Spill
	str	q2, [sp, #3744]                 ; 16-byte Spill
LBB0_377:                               ; %direct.schedule.84.preheader
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_378 Depth 3
	mov	x14, #0                         ; =0x0
	mov	x15, x3
	mov	x28, x12
	mov	x30, x4
LBB0_378:                               ; %direct.true1413
                                        ;   Parent Loop BB0_22 Depth=1
                                        ;     Parent Loop BB0_377 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x16, x5, x14
	umulh	x17, x16, x9
	lsr	x7, x17, #5
	add	x16, x8, x16, lsl #5
	ldp	q20, q21, [x16]
	add	x16, x2, x7, lsl #5
	ldp	q22, q30, [x16]
	fmul.4s	v21, v21, v30
	add	x20, x12, x14
	umulh	x16, x20, x9
	fmul.4s	v20, v20, v22
	lsr	x16, x16, #5
	add	x17, x1, x16, lsl #9
	ldp	q30, q22, [x17]
	and.16b	v30, v1, v30
	and.16b	v20, v1, v20
	and.16b	v22, v0, v22
	add	x19, x16, x16, lsl #1
	lsl	x21, x19, #4
	sub	x19, x20, x21
	add	x22, x8, x20, lsl #5
	and.16b	v21, v0, v21
	ldp	q8, q31, [x22]
	add	x16, x2, x16, lsl #5
	ldp	q10, q9, [x16]
	fmul.4s	v8, v8, v10
	add	x16, x1, x7, lsl #9
	ldp	q11, q13, [x16]
	and.16b	v13, v0, v13
	and.16b	v11, v1, v11
	fmul.4s	v31, v31, v9
	add	x7, x13, x19, lsl #5
	ldp	q15, q14, [x7]
	and.16b	v15, v1, v15
	and.16b	v14, v0, v14
	and.16b	v31, v0, v31
	umulh	x19, x28, x9
	lsr	x22, x19, #5
	madd	x19, x22, x10, x15
	add	x21, x20, x21
	msub	x21, x22, x27, x21
	and.16b	v8, v1, v8
	add	x21, x8, x21, lsl #5
	ldp	q6, q12, [x21, #32]
	ldp	q18, q17, [x19]
	fmul.4s	v6, v10, v6
	and.16b	v18, v1, v18
	add	x20, x20, #49
	umulh	x21, x20, x9
	add	x20, x8, x20, lsl #5
	fmul.4s	v9, v9, v12
	ldp	q10, q12, [x20]
	and	x20, x21, #0xffffffffffffffe0
	add	x20, x2, x20
	ldp	q19, q26, [x20]
	fmul.4s	v26, v12, v26
	and.16b	v17, v0, v17
	fmul.4s	v12, v22, v14
	fmul.4s	v27, v30, v15
	fadd.4s	v27, v8, v27
	fadd.4s	v31, v31, v12
	fmul.4s	v19, v10, v19
	fmul.4s	v22, v22, v17
	fmul.4s	v30, v30, v18
	fmul.4s	v8, v11, v15
	fmul.4s	v10, v13, v14
	fadd.4s	v21, v21, v10
	and.16b	v9, v0, v9
	fadd.4s	v20, v20, v8
	fmul.4s	v18, v11, v18
	fmul.4s	v17, v13, v17
	ldp	q8, q10, [x17, #32]
	and.16b	v6, v1, v6
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	ldp	q12, q11, [x16, #32]
	and.16b	v12, v1, v12
	and.16b	v19, v1, v19
	and.16b	v11, v0, v11
	ldr	q13, [x7, #1552]
	and.16b	v13, v0, v13
	ldr	q14, [x7, #1536]
	and.16b	v14, v1, v14
	and.16b	v26, v0, v26
	ldr	q15, [x19, #1552]
	and.16b	v15, v0, v15
	ldr	q28, [x19, #1536]
	and.16b	v28, v1, v28
	fmul.4s	v29, v10, v13
	fadd.4s	v29, v31, v29
	fmul.4s	v31, v8, v14
	fmul.4s	v8, v8, v28
	fmul.4s	v10, v10, v15
	fmul.4s	v13, v11, v13
	fmul.4s	v14, v12, v14
	fadd.4s	v27, v27, v31
	fadd.4s	v20, v20, v14
	fadd.4s	v21, v21, v13
	fmul.4s	v31, v11, v15
	fmul.4s	v28, v12, v28
	fadd.4s	v6, v6, v30
	ldp	q30, q11, [x17, #64]
	and.16b	v30, v1, v30
	and.16b	v11, v0, v11
	ldp	q12, q13, [x16, #64]
	fadd.4s	v22, v9, v22
	and.16b	v9, v0, v13
	and.16b	v12, v1, v12
	ldr	q13, [x7, #3072]
	and.16b	v13, v1, v13
	ldr	q14, [x7, #3088]
	fadd.4s	v17, v26, v17
	and.16b	v26, v0, v14
	ldr	q14, [x19, #3088]
	ldr	q15, [x19, #3072]
	and.16b	v15, v1, v15
	and.16b	v14, v0, v14
	fadd.4s	v18, v19, v18
	fmul.4s	v19, v30, v13
	fadd.4s	v19, v27, v19
	fmul.4s	v27, v11, v26
	fmul.4s	v11, v11, v14
	fmul.4s	v30, v30, v15
	fadd.4s	v27, v29, v27
	fmul.4s	v29, v12, v13
	fmul.4s	v26, v9, v26
	fadd.4s	v21, v21, v26
	fadd.4s	v20, v20, v29
	fmul.4s	v26, v12, v15
	fadd.4s	v22, v22, v10
	fmul.4s	v29, v9, v14
	ldp	q9, q10, [x17, #96]
	and.16b	v10, v0, v10
	and.16b	v9, v1, v9
	fadd.4s	v6, v6, v8
	ldp	q12, q8, [x16, #96]
	and.16b	v12, v1, v12
	and.16b	v8, v0, v8
	ldr	q13, [x7, #4608]
	fadd.4s	v18, v18, v28
	ldr	q28, [x7, #4624]
	and.16b	v28, v0, v28
	and.16b	v13, v1, v13
	ldr	q14, [x19, #4608]
	ldr	q15, [x19, #4624]
	fadd.4s	v17, v17, v31
	and.16b	v31, v0, v15
	and.16b	v14, v1, v14
	fmul.4s	v15, v10, v28
	fadd.4s	v27, v27, v15
	fmul.4s	v15, v9, v13
	fadd.4s	v19, v19, v15
	fmul.4s	v9, v9, v14
	fmul.4s	v10, v10, v31
	fmul.4s	v28, v8, v28
	fmul.4s	v13, v12, v13
	fadd.4s	v20, v20, v13
	fadd.4s	v6, v6, v30
	fadd.4s	v21, v21, v28
	fmul.4s	v28, v8, v31
	fmul.4s	v30, v12, v14
	ldp	q8, q31, [x17, #128]
	fadd.4s	v22, v22, v11
	and.16b	v8, v1, v8
	and.16b	v31, v0, v31
	ldp	q11, q12, [x16, #128]
	and.16b	v12, v0, v12
	fadd.4s	v17, v17, v29
	and.16b	v29, v1, v11
	ldr	q11, [x7, #6160]
	ldr	q13, [x7, #6144]
	and.16b	v13, v1, v13
	and.16b	v11, v0, v11
	fadd.4s	v18, v18, v26
	ldr	q26, [x19, #6160]
	ldr	q14, [x19, #6144]
	and.16b	v14, v1, v14
	and.16b	v26, v0, v26
	fmul.4s	v15, v8, v13
	fadd.4s	v19, v19, v15
	fmul.4s	v15, v31, v11
	fmul.4s	v31, v31, v26
	fmul.4s	v8, v8, v14
	fmul.4s	v13, v29, v13
	fmul.4s	v11, v12, v11
	fadd.4s	v27, v27, v15
	fadd.4s	v21, v21, v11
	fadd.4s	v20, v20, v13
	fmul.4s	v29, v29, v14
	fmul.4s	v26, v12, v26
	fadd.4s	v22, v22, v10
	ldp	q11, q10, [x17, #160]
	and.16b	v10, v0, v10
	and.16b	v11, v1, v11
	ldp	q13, q12, [x16, #160]
	fadd.4s	v6, v6, v9
	and.16b	v9, v1, v13
	and.16b	v12, v0, v12
	ldr	q13, [x7, #7680]
	ldr	q14, [x7, #7696]
	and.16b	v14, v0, v14
	fadd.4s	v18, v18, v30
	and.16b	v30, v1, v13
	ldr	q13, [x19, #7680]
	ldr	q15, [x19, #7696]
	and.16b	v15, v0, v15
	and.16b	v13, v1, v13
	fadd.4s	v17, v17, v28
	fmul.4s	v28, v10, v14
	fadd.4s	v27, v27, v28
	fmul.4s	v28, v11, v30
	fmul.4s	v11, v11, v13
	fmul.4s	v10, v10, v15
	fadd.4s	v19, v19, v28
	fmul.4s	v28, v12, v14
	fmul.4s	v30, v9, v30
	fadd.4s	v20, v20, v30
	fadd.4s	v21, v21, v28
	fmul.4s	v28, v12, v15
	fadd.4s	v6, v6, v8
	fmul.4s	v30, v9, v13
	ldp	q9, q8, [x17, #192]
	and.16b	v9, v1, v9
	and.16b	v8, v0, v8
	fadd.4s	v22, v22, v31
	ldp	q31, q12, [x16, #192]
	and.16b	v12, v0, v12
	and.16b	v31, v1, v31
	ldr	q13, [x7, #9232]
	fadd.4s	v17, v17, v26
	ldr	q26, [x7, #9216]
	and.16b	v26, v1, v26
	and.16b	v13, v0, v13
	ldr	q14, [x19, #9232]
	ldr	q15, [x19, #9216]
	fadd.4s	v18, v18, v29
	and.16b	v29, v1, v15
	and.16b	v14, v0, v14
	fmul.4s	v15, v9, v26
	fadd.4s	v19, v19, v15
	fmul.4s	v15, v8, v13
	fadd.4s	v27, v27, v15
	fmul.4s	v8, v8, v14
	fmul.4s	v9, v9, v29
	fmul.4s	v26, v31, v26
	fmul.4s	v13, v12, v13
	fadd.4s	v21, v21, v13
	fadd.4s	v22, v22, v10
	fadd.4s	v20, v20, v26
	fmul.4s	v26, v31, v29
	fmul.4s	v29, v12, v14
	ldp	q31, q10, [x17, #224]
	fadd.4s	v6, v6, v11
	and.16b	v10, v0, v10
	and.16b	v31, v1, v31
	ldp	q12, q11, [x16, #224]
	and.16b	v12, v1, v12
	fadd.4s	v18, v18, v30
	and.16b	v30, v0, v11
	ldr	q11, [x7, #10752]
	ldr	q13, [x7, #10768]
	and.16b	v13, v0, v13
	and.16b	v11, v1, v11
	fadd.4s	v17, v17, v28
	ldr	q28, [x19, #10752]
	ldr	q14, [x19, #10768]
	and.16b	v14, v0, v14
	and.16b	v28, v1, v28
	fmul.4s	v15, v10, v13
	fadd.4s	v27, v27, v15
	fmul.4s	v15, v31, v11
	fmul.4s	v31, v31, v28
	fmul.4s	v10, v10, v14
	fmul.4s	v13, v30, v13
	fmul.4s	v11, v12, v11
	fadd.4s	v19, v19, v15
	fadd.4s	v20, v20, v11
	fadd.4s	v21, v21, v13
	fmul.4s	v30, v30, v14
	fmul.4s	v28, v12, v28
	fadd.4s	v6, v6, v9
	ldp	q9, q11, [x17, #256]
	and.16b	v9, v1, v9
	and.16b	v11, v0, v11
	ldp	q12, q13, [x16, #256]
	fadd.4s	v22, v22, v8
	and.16b	v8, v0, v13
	and.16b	v12, v1, v12
	ldr	q13, [x7, #12304]
	ldr	q14, [x7, #12288]
	and.16b	v14, v1, v14
	fadd.4s	v17, v17, v29
	and.16b	v29, v0, v13
	ldr	q13, [x19, #12304]
	ldr	q15, [x19, #12288]
	and.16b	v15, v1, v15
	and.16b	v13, v0, v13
	fadd.4s	v18, v18, v26
	fmul.4s	v26, v9, v14
	fadd.4s	v19, v19, v26
	fmul.4s	v26, v11, v29
	fmul.4s	v11, v11, v13
	fmul.4s	v9, v9, v15
	fadd.4s	v26, v27, v26
	fmul.4s	v27, v12, v14
	fmul.4s	v29, v8, v29
	fadd.4s	v21, v21, v29
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v12, v15
	fadd.4s	v22, v22, v10
	fmul.4s	v29, v8, v13
	ldp	q8, q10, [x17, #288]
	and.16b	v10, v0, v10
	and.16b	v8, v1, v8
	fadd.4s	v6, v6, v31
	ldp	q12, q31, [x16, #288]
	and.16b	v12, v1, v12
	and.16b	v31, v0, v31
	ldr	q13, [x7, #13824]
	fadd.4s	v18, v18, v28
	ldr	q28, [x7, #13840]
	and.16b	v28, v0, v28
	and.16b	v13, v1, v13
	ldr	q14, [x19, #13824]
	ldr	q15, [x19, #13840]
	fadd.4s	v17, v17, v30
	and.16b	v30, v0, v15
	and.16b	v14, v1, v14
	fmul.4s	v15, v10, v28
	fadd.4s	v26, v26, v15
	fmul.4s	v15, v8, v13
	fadd.4s	v19, v19, v15
	fmul.4s	v8, v8, v14
	fmul.4s	v10, v10, v30
	fmul.4s	v28, v31, v28
	fmul.4s	v13, v12, v13
	fadd.4s	v20, v20, v13
	fadd.4s	v6, v6, v9
	fadd.4s	v21, v21, v28
	fmul.4s	v28, v31, v30
	fmul.4s	v30, v12, v14
	ldp	q9, q31, [x17, #320]
	fadd.4s	v22, v22, v11
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	ldp	q11, q12, [x16, #320]
	and.16b	v12, v0, v12
	fadd.4s	v17, v17, v29
	and.16b	v29, v1, v11
	ldr	q11, [x7, #15376]
	ldr	q13, [x7, #15360]
	and.16b	v13, v1, v13
	and.16b	v11, v0, v11
	fadd.4s	v18, v18, v27
	ldr	q27, [x19, #15376]
	ldr	q14, [x19, #15360]
	and.16b	v14, v1, v14
	and.16b	v27, v0, v27
	fmul.4s	v15, v9, v13
	fadd.4s	v19, v19, v15
	fmul.4s	v15, v31, v11
	fmul.4s	v31, v31, v27
	fmul.4s	v9, v9, v14
	fmul.4s	v13, v29, v13
	fmul.4s	v11, v12, v11
	fadd.4s	v26, v26, v15
	fadd.4s	v21, v21, v11
	fadd.4s	v20, v20, v13
	fmul.4s	v29, v29, v14
	fmul.4s	v27, v12, v27
	fadd.4s	v22, v22, v10
	ldp	q11, q10, [x17, #352]
	and.16b	v10, v0, v10
	and.16b	v11, v1, v11
	ldp	q13, q12, [x16, #352]
	fadd.4s	v6, v6, v8
	and.16b	v8, v1, v13
	and.16b	v12, v0, v12
	ldr	q13, [x7, #16896]
	ldr	q14, [x7, #16912]
	and.16b	v14, v0, v14
	fadd.4s	v18, v18, v30
	and.16b	v30, v1, v13
	ldr	q13, [x19, #16896]
	ldr	q15, [x19, #16912]
	and.16b	v15, v0, v15
	and.16b	v13, v1, v13
	fadd.4s	v17, v17, v28
	fmul.4s	v28, v10, v14
	fadd.4s	v26, v26, v28
	fmul.4s	v28, v11, v30
	fmul.4s	v11, v11, v13
	fmul.4s	v10, v10, v15
	fadd.4s	v19, v19, v28
	fmul.4s	v28, v12, v14
	fmul.4s	v30, v8, v30
	fadd.4s	v20, v20, v30
	fadd.4s	v21, v21, v28
	fmul.4s	v28, v12, v15
	fadd.4s	v6, v6, v9
	fmul.4s	v30, v8, v13
	ldp	q9, q8, [x17, #384]
	and.16b	v9, v1, v9
	and.16b	v8, v0, v8
	fadd.4s	v22, v22, v31
	ldp	q31, q12, [x16, #384]
	and.16b	v12, v0, v12
	and.16b	v31, v1, v31
	ldr	q13, [x7, #18448]
	fadd.4s	v17, v17, v27
	ldr	q27, [x7, #18432]
	and.16b	v27, v1, v27
	and.16b	v13, v0, v13
	ldr	q14, [x19, #18448]
	ldr	q15, [x19, #18432]
	fadd.4s	v18, v18, v29
	and.16b	v29, v1, v15
	and.16b	v14, v0, v14
	fmul.4s	v15, v9, v27
	fadd.4s	v19, v19, v15
	fmul.4s	v15, v8, v13
	fadd.4s	v26, v26, v15
	fmul.4s	v8, v8, v14
	fmul.4s	v9, v9, v29
	fmul.4s	v27, v31, v27
	fmul.4s	v13, v12, v13
	fadd.4s	v21, v21, v13
	fadd.4s	v22, v22, v10
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v29
	fmul.4s	v29, v12, v14
	ldp	q31, q10, [x17, #416]
	fadd.4s	v6, v6, v11
	and.16b	v10, v0, v10
	and.16b	v31, v1, v31
	ldp	q12, q11, [x16, #416]
	and.16b	v12, v1, v12
	fadd.4s	v18, v18, v30
	and.16b	v30, v0, v11
	ldr	q11, [x7, #19968]
	ldr	q13, [x7, #19984]
	and.16b	v13, v0, v13
	and.16b	v11, v1, v11
	fadd.4s	v17, v17, v28
	ldr	q28, [x19, #19968]
	ldr	q14, [x19, #19984]
	fmul.4s	v15, v10, v13
	fadd.4s	v26, v26, v15
	fmul.4s	v15, v31, v11
	fadd.4s	v19, v19, v15
	and.16b	v14, v0, v14
	and.16b	v28, v1, v28
	fmul.4s	v31, v31, v28
	fmul.4s	v10, v10, v14
	fmul.4s	v13, v30, v13
	fadd.4s	v6, v6, v9
	fmul.4s	v9, v12, v11
	fadd.4s	v9, v20, v9
	fadd.4s	v20, v21, v13
	fmul.4s	v21, v30, v14
	fmul.4s	v28, v12, v28
	fadd.4s	v22, v22, v8
	ldp	q8, q30, [x17, #448]
	and.16b	v8, v1, v8
	and.16b	v30, v0, v30
	fadd.4s	v17, v17, v29
	ldp	q11, q29, [x16, #448]
	and.16b	v29, v0, v29
	and.16b	v11, v1, v11
	ldr	q12, [x7, #21520]
	ldr	q13, [x7, #21504]
	fadd.4s	v18, v18, v27
	and.16b	v27, v1, v13
	and.16b	v12, v0, v12
	ldr	q13, [x19, #21520]
	ldr	q14, [x19, #21504]
	and.16b	v14, v1, v14
	fadd.4s	v22, v22, v10
	and.16b	v13, v0, v13
	fmul.4s	v10, v8, v27
	fadd.4s	v19, v19, v10
	fmul.4s	v10, v30, v12
	fadd.4s	v26, v26, v10
	fadd.4s	v6, v6, v31
	fmul.4s	v30, v30, v13
	fmul.4s	v31, v8, v14
	fmul.4s	v27, v11, v27
	fmul.4s	v8, v29, v12
	fadd.4s	v20, v20, v8
	fadd.4s	v18, v18, v28
	fadd.4s	v10, v9, v27
	fmul.4s	v27, v11, v14
	fmul.4s	v28, v29, v13
	ldp	q29, q8, [x17, #480]
	fadd.4s	v17, v17, v21
	and.16b	v21, v0, v8
	and.16b	v29, v1, v29
	ldp	q9, q8, [x16, #480]
	and.16b	v11, v1, v9
	fadd.4s	v6, v6, v31
	ldr	q31, [x7, #23040]
	ldr	q9, [x7, #23056]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q12, [x19, #23040]
	fadd.4s	v22, v22, v30
	ldr	q30, [x19, #23056]
	and.16b	v30, v0, v30
	fmul.4s	v13, v29, v31
	fmul.4s	v14, v21, v9
	lsl	x16, x14, #5
	fadd.4s	v17, v17, v28
	add	x17, x26, x16
	fadd.4s	v26, v26, v14
	fadd.4s	v19, v19, v13
	ldp	q13, q28, [x17]
	fadd.4s	v18, v18, v27
	add	x16, x25, x16
	fmul.4s	v21, v21, v30
	bif.16b	v19, v13, v1
	ldp	q13, q27, [x16]
	fadd.4s	v21, v22, v21
	and.16b	v22, v0, v8
	and.16b	v8, v1, v12
	fmul.4s	v29, v29, v8
	bif.16b	v26, v28, v0
	stp	q19, q26, [x17]
	fadd.4s	v6, v6, v29
	fmul.4s	v19, v22, v9
	bif.16b	v6, v13, v1
	bif.16b	v21, v27, v0
	stp	q6, q21, [x16]
	fmul.4s	v6, v11, v31
	fadd.4s	v6, v10, v6
	fadd.4s	v19, v20, v19
	fmul.4s	v20, v22, v30
	ldp	q21, q22, [x30, #-32]
	ldp	q26, q27, [x30]
	fmul.4s	v28, v11, v8
	fadd.4s	v18, v18, v28
	fadd.4s	v17, v17, v20
	add	x14, x14, #2
	bif.16b	v19, v22, v0
	bif.16b	v6, v21, v1
	bif.16b	v17, v27, v0
	bif.16b	v18, v26, v1
	stp	q6, q19, [x30, #-32]
	stp	q18, q17, [x30], #64
	add	x28, x28, #2
	add	x15, x15, #64
	cmp	x14, #48
	b.ne	LBB0_378
; %bb.379:                              ; %direct.false1414
                                        ;   in Loop: Header=BB0_377 Depth=2
	add	x0, x0, #1
	add	x12, x12, #96
	add	x26, x26, #3072
	add	x25, x25, #3072
	add	x5, x5, #96
	add	x4, x4, #3072
	add	x3, x3, #3072
	cmp	x0, #4
	b.ne	LBB0_377
; %bb.380:                              ; %direct.true1800.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	w12, #384                       ; =0x180
	mov	x14, x11
	mov	w16, #23680                     ; =0x5c80
	movk	w16, #1, lsl #16
LBB0_381:                               ; %direct.true1800
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x14, x16
	ldp	q6, q17, [x15]
	ldr	q18, [x14, #20480]
	ldr	q19, [x14, #20496]
	bif.16b	v17, v19, v0
	bif.16b	v6, v18, v1
	str	q6, [x14, #20480]
	str	q17, [x14, #20496]
	add	x14, x14, #32
	subs	x12, x12, #1
	b.ne	LBB0_381
; %bb.382:                              ; %direct.true1816.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q16, [sp, #7792]                ; 16-byte Spill
	str	q5, [sp, #7808]                 ; 16-byte Spill
	str	q4, [sp, #7824]                 ; 16-byte Spill
	str	q3, [sp, #7840]                 ; 16-byte Spill
	str	q25, [sp, #7904]                ; 16-byte Spill
	str	q24, [sp, #7920]                ; 16-byte Spill
	str	q23, [sp, #7936]                ; 16-byte Spill
	mov	x12, x11
	mov	w14, #384                       ; =0x180
	add	x3, x11, #8, lsl #12            ; =32768
	ldr	x21, [sp, #3576]                ; 8-byte Reload
	ldr	x22, [sp, #3568]                ; 8-byte Reload
	ldr	x4, [sp, #3520]                 ; 8-byte Reload
	ldr	x5, [sp, #3512]                 ; 8-byte Reload
	ldr	x0, [sp, #7960]                 ; 8-byte Reload
	mov	w7, #43691                      ; =0xaaab
LBB0_383:                               ; %direct.true1816
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q6, [x12, #20480]
	ldr	q17, [x12, #20496]
	ldr	q18, [x12, #8192]
	ldr	q19, [x12, #8208]
	bif.16b	v17, v19, v0
	bif.16b	v6, v18, v1
	str	q6, [x12, #8192]
	str	q17, [x12, #8208]
	add	x12, x12, #32
	subs	x14, x14, #1
	b.ne	LBB0_383
; %bb.384:                              ; %direct.false1817
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q2, [sp, #9040]                 ; 16-byte Reload
	ldr	q3, [sp, #7760]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9040]                 ; 16-byte Spill
	ldr	q2, [sp, #9056]                 ; 16-byte Reload
	ldr	q3, [sp, #7776]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9056]                 ; 16-byte Spill
	ldr	q2, [sp, #9264]                 ; 16-byte Reload
	ldr	q3, [sp, #7744]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9264]                 ; 16-byte Spill
	ldr	q2, [sp, #9280]                 ; 16-byte Reload
	ldr	q3, [sp, #8992]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9280]                 ; 16-byte Spill
	ldr	q2, [sp, #9296]                 ; 16-byte Reload
	ldr	q3, [sp, #8880]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9296]                 ; 16-byte Spill
	ldr	q2, [sp, #9312]                 ; 16-byte Reload
	ldr	q3, [sp, #8976]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9312]                 ; 16-byte Spill
	ldr	q2, [sp, #9328]                 ; 16-byte Reload
	ldr	q3, [sp, #8864]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9328]                 ; 16-byte Spill
	ldr	q2, [sp, #9344]                 ; 16-byte Reload
	ldr	q3, [sp, #8960]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9344]                 ; 16-byte Spill
	ldr	q2, [sp, #9360]                 ; 16-byte Reload
	ldr	q3, [sp, #8848]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9360]                 ; 16-byte Spill
	ldr	q2, [sp, #9376]                 ; 16-byte Reload
	ldr	q3, [sp, #8944]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9376]                 ; 16-byte Spill
	ldr	q2, [sp, #9392]                 ; 16-byte Reload
	ldr	q3, [sp, #8832]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9392]                 ; 16-byte Spill
	ldr	q2, [sp, #9408]                 ; 16-byte Reload
	ldr	q3, [sp, #8928]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9408]                 ; 16-byte Spill
	ldr	q2, [sp, #9424]                 ; 16-byte Reload
	ldr	q3, [sp, #8816]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9424]                 ; 16-byte Spill
	ldr	q2, [sp, #9440]                 ; 16-byte Reload
	ldr	q3, [sp, #8912]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9440]                 ; 16-byte Spill
	ldr	q6, [sp, #9472]                 ; 16-byte Reload
	ldr	q2, [sp, #8800]                 ; 16-byte Reload
	bit.16b	v6, v2, v0
	str	q6, [sp, #9472]                 ; 16-byte Spill
	ldr	q6, [sp, #9456]                 ; 16-byte Reload
	ldr	q2, [sp, #8896]                 ; 16-byte Reload
	bit.16b	v6, v2, v1
	str	q6, [sp, #9456]                 ; 16-byte Spill
	ldr	q2, [sp, #3968]                 ; 16-byte Reload
	fadd.4s	v6, v2, v7
	ldr	q2, [sp, #3712]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4096]                 ; 16-byte Reload
	fadd.4s	v17, v2, v7
	ldr	q2, [sp, #3952]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #3696]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4080]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3920]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3936]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #3680]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4064]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3888]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3904]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #3664]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4048]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3856]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3872]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #3648]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4032]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3824]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3840]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #3632]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4016]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3792]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3808]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #3616]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4000]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3760]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3776]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #3600]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #3984]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3728]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #3744]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #9136]                 ; 16-byte Reload
	bit.16b	v2, v17, v1
	str	q2, [sp, #9136]                 ; 16-byte Spill
	ldr	q2, [sp, #9120]                 ; 16-byte Reload
	bit.16b	v2, v6, v0
	str	q2, [sp, #9120]                 ; 16-byte Spill
	ldr	q2, [sp, #4480]                 ; 16-byte Reload
	fadd.4s	v6, v2, v7
	ldr	q2, [sp, #4224]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4608]                 ; 16-byte Reload
	fadd.4s	v17, v2, v7
	ldr	q2, [sp, #4464]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4208]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4432]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4448]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4192]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4400]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4416]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4176]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4368]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4384]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4160]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4336]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4352]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4144]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4304]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4320]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4128]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4512]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4272]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4288]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4112]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4496]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4240]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4256]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #9104]                 ; 16-byte Reload
	bit.16b	v2, v17, v1
	str	q2, [sp, #9104]                 ; 16-byte Spill
	ldr	q2, [sp, #9088]                 ; 16-byte Reload
	bit.16b	v2, v6, v0
	str	q2, [sp, #9088]                 ; 16-byte Spill
	ldr	q2, [sp, #4992]                 ; 16-byte Reload
	fadd.4s	v6, v2, v7
	ldr	q2, [sp, #4736]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5120]                 ; 16-byte Reload
	fadd.4s	v17, v2, v7
	ldr	q2, [sp, #4976]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4720]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5104]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4944]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4960]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4704]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5088]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4912]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4928]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4688]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5072]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4880]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4896]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4672]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5056]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4848]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4864]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4656]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5040]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4816]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4832]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4640]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5024]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4784]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4800]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #4624]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5008]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4752]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4768]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #9072]                 ; 16-byte Reload
	bit.16b	v2, v17, v1
	str	q2, [sp, #9072]                 ; 16-byte Spill
	ldr	q2, [sp, #9216]                 ; 16-byte Reload
	bit.16b	v2, v6, v0
	str	q2, [sp, #9216]                 ; 16-byte Spill
	ldr	q2, [sp, #5504]                 ; 16-byte Reload
	fadd.4s	v6, v2, v7
	ldr	q2, [sp, #5248]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5632]                 ; 16-byte Reload
	fadd.4s	v17, v2, v7
	ldr	q2, [sp, #5488]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5232]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5616]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5456]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5472]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5216]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5600]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5424]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5440]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5200]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5584]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5392]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5408]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5184]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5568]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5360]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5376]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5168]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5552]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5328]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5344]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5152]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5536]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5296]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5312]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5136]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5520]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5264]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5280]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #9200]                 ; 16-byte Reload
	bit.16b	v2, v17, v1
	str	q2, [sp, #9200]                 ; 16-byte Spill
	ldr	q2, [sp, #9184]                 ; 16-byte Reload
	bit.16b	v2, v6, v0
	str	q2, [sp, #9184]                 ; 16-byte Spill
	ldr	q2, [sp, #6016]                 ; 16-byte Reload
	fadd.4s	v6, v2, v7
	ldr	q2, [sp, #5760]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6144]                 ; 16-byte Reload
	fadd.4s	v17, v2, v7
	ldr	q2, [sp, #6000]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5744]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6128]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5968]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5984]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6112]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5936]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5952]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6096]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5904]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5920]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6080]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5872]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5888]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6064]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5840]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5856]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5664]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6048]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5808]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5824]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #5648]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6032]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5776]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #5792]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #9168]                 ; 16-byte Reload
	bit.16b	v2, v17, v1
	str	q2, [sp, #9168]                 ; 16-byte Spill
	ldr	q2, [sp, #9152]                 ; 16-byte Reload
	bit.16b	v2, v6, v0
	str	q2, [sp, #9152]                 ; 16-byte Spill
	ldr	q2, [sp, #6528]                 ; 16-byte Reload
	fadd.4s	v6, v2, v7
	ldr	q2, [sp, #6272]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6656]                 ; 16-byte Reload
	fadd.4s	v17, v2, v7
	ldr	q2, [sp, #6512]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6256]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6640]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6480]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6496]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6240]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6624]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6448]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6464]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6224]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6608]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6416]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6432]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6208]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6592]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6384]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6400]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6192]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6576]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6352]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6368]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6176]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6560]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6320]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6336]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6160]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6544]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6288]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6304]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #9248]                 ; 16-byte Reload
	bit.16b	v2, v17, v1
	str	q2, [sp, #9248]                 ; 16-byte Spill
	ldr	q2, [sp, #9232]                 ; 16-byte Reload
	bit.16b	v2, v6, v0
	str	q2, [sp, #9232]                 ; 16-byte Spill
	ldr	q2, [sp, #6944]                 ; 16-byte Reload
	fadd.4s	v6, v2, v7
	ldr	q2, [sp, #6752]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7056]                 ; 16-byte Reload
	fadd.4s	v17, v2, v7
	ldr	q2, [sp, #6928]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6736]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7040]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6896]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6912]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6720]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7024]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6864]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6880]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6704]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7008]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6832]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6848]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6688]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6992]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6800]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6816]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6672]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6976]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6768]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #6784]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7152]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7168]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7104]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7120]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #6960]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7136]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7072]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7088]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q13, [sp, #8448]                ; 16-byte Reload
	bit.16b	v13, v17, v1
	ldr	q29, [sp, #8432]                ; 16-byte Reload
	bit.16b	v29, v6, v0
	ldr	q2, [sp, #7680]                 ; 16-byte Reload
	fadd.4s	v6, v2, v7
	ldr	q2, [sp, #7328]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7664]                 ; 16-byte Reload
	fadd.4s	v17, v2, v7
	ldr	q2, [sp, #7536]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7312]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7648]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7504]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7520]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7296]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7632]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7472]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7488]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7280]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7616]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7440]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7456]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7264]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7600]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7408]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7424]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7248]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7584]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7376]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7392]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7232]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7568]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7344]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7360]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7216]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q2, [sp, #7552]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7184]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #7200]                 ; 16-byte Reload
	fadd.4s	v17, v17, v2
	ldr	q26, [sp, #8416]                ; 16-byte Reload
	bit.16b	v26, v17, v1
	ldr	q23, [sp, #8400]                ; 16-byte Reload
	bit.16b	v23, v6, v0
	ldr	q27, [sp, #7984]                ; 16-byte Reload
	ldr	q2, [sp, #9024]                 ; 16-byte Reload
	fmul.4s	v2, v27, v2
	str	q2, [sp, #9024]                 ; 16-byte Spill
	ldr	q28, [sp, #7968]                ; 16-byte Reload
	ldr	q2, [sp, #9008]                 ; 16-byte Reload
	fmul.4s	v12, v28, v2
	ldr	q24, [sp, #8016]                ; 16-byte Reload
	ldr	q2, [sp, #8768]                 ; 16-byte Reload
	fmul.4s	v2, v24, v2
	str	q2, [sp, #9008]                 ; 16-byte Spill
	ldr	q25, [sp, #8000]                ; 16-byte Reload
	ldr	q2, [sp, #8784]                 ; 16-byte Reload
	fmul.4s	v14, v25, v2
	ldr	q21, [sp, #8048]                ; 16-byte Reload
	ldr	q2, [sp, #8736]                 ; 16-byte Reload
	fmul.4s	v2, v21, v2
	str	q2, [sp, #8976]                 ; 16-byte Spill
	ldr	q22, [sp, #8032]                ; 16-byte Reload
	ldr	q2, [sp, #8752]                 ; 16-byte Reload
	fmul.4s	v8, v22, v2
	ldr	q19, [sp, #8080]                ; 16-byte Reload
	ldr	q2, [sp, #8704]                 ; 16-byte Reload
	fmul.4s	v2, v19, v2
	str	q2, [sp, #8944]                 ; 16-byte Spill
	ldr	q20, [sp, #8064]                ; 16-byte Reload
	ldr	q2, [sp, #8720]                 ; 16-byte Reload
	fmul.4s	v10, v20, v2
	ldr	q17, [sp, #8112]                ; 16-byte Reload
	ldr	q2, [sp, #8672]                 ; 16-byte Reload
	fmul.4s	v2, v17, v2
	str	q2, [sp, #8928]                 ; 16-byte Spill
	ldr	q18, [sp, #8096]                ; 16-byte Reload
	ldr	q2, [sp, #8688]                 ; 16-byte Reload
	fmul.4s	v31, v18, v2
	ldr	q16, [sp, #8144]                ; 16-byte Reload
	ldr	q2, [sp, #8656]                 ; 16-byte Reload
	fmul.4s	v2, v16, v2
	str	q2, [sp, #8912]                 ; 16-byte Spill
	ldr	q6, [sp, #8128]                 ; 16-byte Reload
	ldr	q2, [sp, #8640]                 ; 16-byte Reload
	fmul.4s	v9, v6, v2
	ldr	q4, [sp, #8176]                 ; 16-byte Reload
	ldr	q2, [sp, #7728]                 ; 16-byte Reload
	fmul.4s	v2, v4, v2
	str	q2, [sp, #8896]                 ; 16-byte Spill
	ldr	q5, [sp, #8160]                 ; 16-byte Reload
	ldr	q2, [sp, #8624]                 ; 16-byte Reload
	fmul.4s	v11, v5, v2
	ldr	q2, [sp, #8208]                 ; 16-byte Reload
	ldr	q3, [sp, #7696]                 ; 16-byte Reload
	fmul.4s	v3, v2, v3
	str	q3, [sp, #8960]                 ; 16-byte Spill
	ldr	q3, [sp, #8192]                 ; 16-byte Reload
	ldr	q15, [sp, #7712]                ; 16-byte Reload
	fmul.4s	v15, v3, v15
	str	q23, [sp, #8400]                ; 16-byte Spill
	fadd.4s	v30, v12, v23
	str	q26, [sp, #8416]                ; 16-byte Spill
	ldr	q23, [sp, #9024]                ; 16-byte Reload
	fadd.4s	v26, v23, v26
	str	q29, [sp, #8432]                ; 16-byte Spill
	fadd.4s	v23, v14, v29
	str	q23, [sp, #8992]                ; 16-byte Spill
	str	q13, [sp, #8448]                ; 16-byte Spill
	ldr	q23, [sp, #9008]                ; 16-byte Reload
	fadd.4s	v14, v23, v13
	ldr	q23, [sp, #9232]                ; 16-byte Reload
	fadd.4s	v23, v8, v23
	str	q23, [sp, #9024]                ; 16-byte Spill
	ldr	q23, [sp, #9248]                ; 16-byte Reload
	ldr	q29, [sp, #8976]                ; 16-byte Reload
	fadd.4s	v29, v29, v23
	ldr	q23, [sp, #9152]                ; 16-byte Reload
	fadd.4s	v23, v10, v23
	str	q23, [sp, #8976]                ; 16-byte Spill
	ldr	q23, [sp, #9168]                ; 16-byte Reload
	ldr	q8, [sp, #8944]                 ; 16-byte Reload
	fadd.4s	v12, v8, v23
	ldr	q23, [sp, #9184]                ; 16-byte Reload
	fadd.4s	v13, v31, v23
	ldr	q23, [sp, #9200]                ; 16-byte Reload
	ldr	q31, [sp, #8928]                ; 16-byte Reload
	fadd.4s	v31, v31, v23
	ldr	q23, [sp, #9216]                ; 16-byte Reload
	fadd.4s	v23, v9, v23
	str	q23, [sp, #9008]                ; 16-byte Spill
	ldr	q23, [sp, #9072]                ; 16-byte Reload
	ldr	q8, [sp, #8912]                 ; 16-byte Reload
	fadd.4s	v10, v8, v23
	ldr	q23, [sp, #9088]                ; 16-byte Reload
	fadd.4s	v8, v11, v23
	ldr	q23, [sp, #9104]                ; 16-byte Reload
	ldr	q9, [sp, #8896]                 ; 16-byte Reload
	fadd.4s	v9, v9, v23
	ldr	q23, [sp, #9120]                ; 16-byte Reload
	fadd.4s	v11, v15, v23
	ldr	q23, [sp, #9136]                ; 16-byte Reload
	ldr	q15, [sp, #8960]                ; 16-byte Reload
	fadd.4s	v23, v15, v23
	add	x0, x0, #1
	str	q26, [sp, #8912]                ; 16-byte Spill
	bit.16b	v27, v26, v1
	str	q27, [sp, #7984]                ; 16-byte Spill
	str	q30, [sp, #8896]                ; 16-byte Spill
	bit.16b	v28, v30, v0
	str	q28, [sp, #7968]                ; 16-byte Spill
	mov.16b	v28, v31
	mov.16b	v27, v13
	mov.16b	v13, v12
	ldr	q12, [sp, #8976]                ; 16-byte Reload
	ldr	q15, [sp, #8992]                ; 16-byte Reload
	str	q14, [sp, #8928]                ; 16-byte Spill
	bit.16b	v24, v14, v1
	str	q24, [sp, #8016]                ; 16-byte Spill
	bit.16b	v25, v15, v0
	str	q25, [sp, #8000]                ; 16-byte Spill
	str	q29, [sp, #8960]                ; 16-byte Spill
	bit.16b	v21, v29, v1
	ldr	q26, [sp, #9024]                ; 16-byte Reload
	str	q21, [sp, #8048]                ; 16-byte Spill
	bit.16b	v22, v26, v0
	str	q22, [sp, #8032]                ; 16-byte Spill
	bit.16b	v19, v13, v1
	str	q19, [sp, #8080]                ; 16-byte Spill
	mov.16b	v19, v8
	bit.16b	v20, v12, v0
	str	q20, [sp, #8064]                ; 16-byte Spill
	ldr	q20, [sp, #9008]                ; 16-byte Reload
	bit.16b	v17, v31, v1
	str	q17, [sp, #8112]                ; 16-byte Spill
	mov.16b	v17, v11
	bit.16b	v18, v27, v0
	str	q18, [sp, #8096]                ; 16-byte Spill
	mov.16b	v18, v9
	str	q10, [sp, #8944]                ; 16-byte Spill
	bit.16b	v16, v10, v1
	str	q16, [sp, #8144]                ; 16-byte Spill
	bit.16b	v6, v20, v0
	str	q6, [sp, #8128]                 ; 16-byte Spill
	mov.16b	v6, v23
	bit.16b	v4, v9, v1
	str	q4, [sp, #8176]                 ; 16-byte Spill
	bit.16b	v5, v8, v0
	str	q5, [sp, #8160]                 ; 16-byte Spill
	bit.16b	v2, v23, v1
	str	q2, [sp, #8208]                 ; 16-byte Spill
	bit.16b	v3, v11, v0
	str	q3, [sp, #8192]                 ; 16-byte Spill
	cmp	x0, #9
	ldr	q10, [sp, #8608]                ; 16-byte Reload
	ldr	q11, [sp, #8592]                ; 16-byte Reload
	ldr	q22, [sp, #3488]                ; 16-byte Reload
	ldr	q30, [sp, #3472]                ; 16-byte Reload
	ldr	q31, [sp, #2896]                ; 16-byte Reload
	ldr	q8, [sp, #2880]                 ; 16-byte Reload
	ldr	q23, [sp, #7936]                ; 16-byte Reload
	ldr	q24, [sp, #7920]                ; 16-byte Reload
	ldr	q25, [sp, #7904]                ; 16-byte Reload
	ldr	q9, [sp, #7888]                 ; 16-byte Reload
	ldr	q14, [sp, #7872]                ; 16-byte Reload
	ldr	q21, [sp, #7856]                ; 16-byte Reload
	ldr	q3, [sp, #7840]                 ; 16-byte Reload
	ldr	q4, [sp, #7824]                 ; 16-byte Reload
	ldr	q5, [sp, #7808]                 ; 16-byte Reload
	ldr	q16, [sp, #7792]                ; 16-byte Reload
	b.ne	LBB0_22
; %bb.385:                              ; %direct.false212
	mov	x9, #0                          ; =0x0
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3200
	ldp	q2, q3, [x10]
	ldr	q4, [sp, #8896]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	ldr	q4, [sp, #8912]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	stp	q2, q3, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3232
	ldp	q2, q3, [x10]
	bit.16b	v3, v15, v0
	ldr	q4, [sp, #8928]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	stp	q2, q3, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3264
	ldp	q2, q3, [x10]
	bit.16b	v3, v26, v0
	ldr	q4, [sp, #8960]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	stp	q2, q3, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3296
	ldp	q2, q3, [x10]
	bit.16b	v3, v12, v0
	bit.16b	v2, v13, v1
	stp	q2, q3, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3328
	ldp	q2, q3, [x10]
	bit.16b	v3, v27, v0
	bit.16b	v2, v28, v1
	stp	q2, q3, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3360
	ldp	q2, q3, [x10]
	bit.16b	v3, v20, v0
	ldr	q4, [sp, #8944]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	stp	q2, q3, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3392
	ldp	q2, q3, [x10]
	bit.16b	v3, v19, v0
	bit.16b	v2, v18, v1
	stp	q2, q3, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x11, x10, #3424
	ldp	q2, q3, [x11]
	bit.16b	v3, v17, v0
	bit.16b	v2, v6, v1
	mov	w10, #43691                     ; =0xaaab
	stp	q2, q3, [x11]
	mov	w11, #48                        ; =0x30
	ldp	x17, x16, [sp, #80]             ; 16-byte Folded Reload
	ldp	q18, q17, [sp, #48]             ; 32-byte Folded Reload
	ldp	q20, q19, [sp, #16]             ; 32-byte Folded Reload
	ldr	q21, [sp, #9488]                ; 16-byte Reload
	b	LBB0_387
LBB0_386:                               ; %else1157
                                        ;   in Loop: Header=BB0_387 Depth=1
	add	x9, x9, #1
	cmp	x9, #384
	b.eq	LBB0_403
LBB0_387:                               ; %direct.true1873
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w12, s21
	and	w13, w9, #0xffff
	mul	w13, w13, w10
	lsr	w13, w13, #21
	dup.2d	v2, x13
	add.2d	v3, v20, v2
	mov.d	x14, v3[1]
	fmov	x15, d3
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d4, x15
	msub	w15, w13, w11, w9
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	mov.d	v4[1], x14
	and	x14, x15, #0xffff
	dup.2d	v3, x14
	add.2d	v4, v4, v3
	umaddl	x14, w13, w11, x14
	add	x14, x8, x14, lsl #5
	ldp	q6, q5, [x14]
	and.16b	v7, v1, v6
	add	x13, x16, x13, lsl #5
	ldp	q16, q6, [x13]
	and.16b	v16, v1, v16
	fdiv.4s	v7, v7, v16
	shl.2d	v16, v4, #2
	dup.2d	v4, x17
	add.2d	v16, v4, v16
	tbz	w12, #0, LBB0_389
; %bb.388:                              ; %cond.store1126
                                        ;   in Loop: Header=BB0_387 Depth=1
	fmov	x13, d16
	str	s7, [x13]
LBB0_389:                               ; %else1129
                                        ;   in Loop: Header=BB0_387 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_391
; %bb.390:                              ; %cond.store1130
                                        ;   in Loop: Header=BB0_387 Depth=1
	mov.d	x13, v16[1]
	st1.s	{ v7 }[1], [x13]
LBB0_391:                               ; %else1133
                                        ;   in Loop: Header=BB0_387 Depth=1
	add.2d	v16, v19, v2
	mov.d	x13, v16[1]
	fmov	x14, d16
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d16, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	mov.d	v16[1], x13
	add.2d	v16, v16, v3
	shl.2d	v16, v16, #2
	add.2d	v16, v4, v16
	tbz	w12, #2, LBB0_393
; %bb.392:                              ; %cond.store1134
                                        ;   in Loop: Header=BB0_387 Depth=1
	fmov	x13, d16
	st1.s	{ v7 }[2], [x13]
LBB0_393:                               ; %else1137
                                        ;   in Loop: Header=BB0_387 Depth=1
	tbz	w12, #3, LBB0_395
; %bb.394:                              ; %cond.store1138
                                        ;   in Loop: Header=BB0_387 Depth=1
	mov.d	x13, v16[1]
	st1.s	{ v7 }[3], [x13]
LBB0_395:                               ; %else1141
                                        ;   in Loop: Header=BB0_387 Depth=1
	add.2d	v7, v17, v2
	mov.d	x13, v7[1]
	fmov	x14, d7
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d7, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	mov.d	v7[1], x13
	add.2d	v7, v7, v3
	and.16b	v5, v0, v5
	and.16b	v6, v0, v6
	fdiv.4s	v5, v5, v6
	shl.2d	v6, v7, #2
	add.2d	v6, v4, v6
	tbz	w12, #4, LBB0_397
; %bb.396:                              ; %cond.store1142
                                        ;   in Loop: Header=BB0_387 Depth=1
	fmov	x13, d6
	str	s5, [x13]
LBB0_397:                               ; %else1145
                                        ;   in Loop: Header=BB0_387 Depth=1
	tbz	w12, #5, LBB0_399
; %bb.398:                              ; %cond.store1146
                                        ;   in Loop: Header=BB0_387 Depth=1
	mov.d	x13, v6[1]
	st1.s	{ v5 }[1], [x13]
LBB0_399:                               ; %else1149
                                        ;   in Loop: Header=BB0_387 Depth=1
	add.2d	v2, v18, v2
	mov.d	x13, v2[1]
	fmov	x14, d2
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d2, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	mov.d	v2[1], x13
	add.2d	v2, v2, v3
	shl.2d	v2, v2, #2
	add.2d	v2, v4, v2
	tbz	w12, #6, LBB0_401
; %bb.400:                              ; %cond.store1150
                                        ;   in Loop: Header=BB0_387 Depth=1
	fmov	x13, d2
	st1.s	{ v5 }[2], [x13]
	tbz	w12, #7, LBB0_386
	b	LBB0_402
LBB0_401:                               ; %else1153
                                        ;   in Loop: Header=BB0_387 Depth=1
	tbz	w12, #7, LBB0_386
LBB0_402:                               ; %cond.store1154
                                        ;   in Loop: Header=BB0_387 Depth=1
	mov.d	x12, v2[1]
	st1.s	{ v5 }[3], [x12]
	b	LBB0_386
LBB0_403:
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #1600
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_404:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh137, Lloh141
	.loh AdrpLdr	Lloh136, Lloh140
	.loh AdrpLdr	Lloh135, Lloh139
	.loh AdrpLdr	Lloh134, Lloh138
	.loh AdrpAdrp	Lloh129, Lloh134
	.loh AdrpLdr	Lloh129, Lloh130
	.loh AdrpLdr	Lloh128, Lloh133
	.loh AdrpLdr	Lloh127, Lloh132
	.loh AdrpLdr	Lloh126, Lloh131
	.loh AdrpLdr	Lloh124, Lloh125
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpLdr	Lloh120, Lloh121
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpLdr	Lloh108, Lloh109
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh32
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh28
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh24
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh20
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh16
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh12
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [39 x i32] [i32 5, i32 4, i32 8, i32 108, i32 15, i32 14, i32 20, i32 19, i32 23, i32 26, i32 29, i32 32, i32 35, i32 38, i32 41, i32 44, i32 47, i32 50, i32 53, i32 56, i32 59, i32 62, i32 65, i32 68, i32 71, i32 74, i32 77, i32 80, i32 83, i32 86, i32 89, i32 92, i32 101, i32 100, i32 99, i32 104, i32 107, i32 113, i32 112], align 4

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 5120
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 11264
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 17408
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 37888
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 62464
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 64512
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 64640
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 66688
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 72832
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill37 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill37, align 64
  %.spill38 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill38, align 64
  %.spill39 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill39, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %tile_snapshot.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill42, align 64
  %tile_snapshot.spill43 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill43, align 64
  %.slot44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot44, align 64
  %.slot45 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot45, align 64
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.spill54 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill54, align 64
  %tile_snapshot.spill55 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill55, align 64
  %.slot56 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot56, align 64
  %.spill57 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill57, align 64
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %tile_snapshot.spill59 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill59, align 64
  %.slot60 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot60, align 64
  %.spill61 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill61, align 64
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %.slot63 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot63, align 64
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.slot66 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot66, align 32
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.slot68 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot68, align 64
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot72, align 32
  %.slot73 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot73, align 64
  %.slot74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot74, align 32
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.slot78 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot78, align 64
  %.slot79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot79, align 32
  %.slot80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot80, align 32
  %.slot81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot81, align 32
  %.slot82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot82, align 32
  %.slot83 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot83, align 64
  %.slot84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot84, align 32
  %.slot85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot85, align 32
  %.slot86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot86, align 32
  %.slot87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot87, align 32
  %.slot88 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot88, align 64
  %.slot89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot89, align 32
  %.slot90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot90, align 32
  %.slot91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot91, align 32
  %.slot92 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot92, align 32
  %.slot93 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot93, align 64
  %.slot94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot94, align 32
  %.slot95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot95, align 32
  %.slot96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot96, align 32
  %.slot97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot97, align 32
  %.slot98 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot98, align 64
  %.slot99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot99, align 32
  %.slot100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot100, align 32
  %.slot101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot101, align 32
  %.slot102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot102, align 32
  %.slot103 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot103, align 64
  %.slot104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot104, align 32
  %.slot105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot105, align 32
  %.slot106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot106, align 32
  %.slot107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot107, align 32
  %.slot108 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot108, align 64
  %.slot109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot109, align 32
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %.slot111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot111, align 32
  %.slot112 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot112, align 32
  %.slot113 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot113, align 64
  %.slot114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot114, align 32
  %.slot115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot115, align 32
  %.slot116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot116, align 32
  %.slot117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot117, align 32
  %.slot118 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot118, align 64
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.slot120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot120, align 32
  %.slot121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot121, align 32
  %.slot122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot122, align 32
  %.slot123 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot123, align 64
  %.slot124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot124, align 32
  %.slot125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot125, align 32
  %.slot126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot126, align 32
  %.slot127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot127, align 32
  %.slot128 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot128, align 64
  %.slot129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot129, align 32
  %.slot130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot130, align 32
  %.slot131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot131, align 32
  %.slot132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot132, align 32
  %.slot133 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot133, align 64
  %.slot134 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot134, align 32
  %.slot135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot135, align 32
  %.slot136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot136, align 32
  %.slot137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot137, align 32
  %.slot138 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot138, align 64
  %.slot139 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot139, align 32
  %.slot140 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot140, align 32
  %.slot141 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot141, align 32
  %.slot142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot142, align 32
  %.spill143 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill143, align 1
  %.spill144 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill144, align 1
  %.spill145 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill145, align 1
  %.spill146 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill146, align 1
  %.spill147 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill147, align 1
  %.spill148 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill148, align 1
  %.spill149 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill149, align 1
  %.spill150 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill150, align 1
  %.spill151 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill151, align 1
  %.spill152 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill152, align 1
  %.spill153 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill153, align 1
  %.spill154 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill154, align 1
  %.spill155 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill155, align 1
  %.spill156 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill156, align 1
  %.spill157 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill157, align 1
  %.spill158 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill158, align 1
  %.spill159 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill159, align 1
  %.spill160 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill160, align 1
  %.spill161 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill161, align 1
  %.spill162 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill162, align 1
  %.spill163 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill163, align 1
  %.spill164 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill164, align 1
  %.spill165 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill165, align 1
  %.spill166 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill166, align 1
  %.spill167 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill167, align 1
  %.spill168 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill168, align 1
  %.spill169 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill169, align 1
  %.spill170 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill170, align 1
  %.spill171 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill171, align 1
  %.spill172 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill172, align 1
  %.spill173 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill173, align 1
  %.spill174 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill174, align 1
  %.spill175 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill175, align 1
  %.spill176 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill176, align 1
  %.spill177 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill177, align 1
  %.spill178 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill178, align 1
  %.spill179 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill179, align 1
  %.spill180 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill180, align 1
  %.spill181 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill181, align 1
  %.spill182 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill182, align 1
  %.spill183 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill183, align 1
  %.spill184 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill184, align 1
  %.spill185 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill185, align 1
  %.spill186 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill186, align 1
  %.spill187 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill187, align 1
  %.spill188 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill188, align 1
  %.spill189 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill189, align 1
  %.spill190 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill190, align 1
  %.spill191 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill191, align 1
  %.spill192 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill192, align 1
  %.spill193 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill193, align 1
  %.spill194 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill194, align 1
  %.spill195 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill195, align 1
  %.spill196 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill196, align 1
  %.spill197 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill197, align 1
  %.spill198 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill198, align 1
  %.spill199 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill199, align 1
  %.spill200 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill200, align 1
  %.spill201 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill201, align 1
  %.spill202 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill202, align 1
  %.spill203 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill203, align 1
  %.spill204 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill204, align 1
  %.spill205 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill205, align 1
  %.spill206 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill206, align 1
  %.spill207 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill207, align 32
  %.spill208 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill208, align 32
  %.spill209 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill209, align 32
  %.spill210 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill210, align 32
  %.spill211 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill211, align 32
  %.spill212 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill212, align 32
  %.spill213 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill213, align 32
  %.spill214 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill214, align 32
  %.spill215 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill215, align 32
  %.spill216 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill216, align 32
  %.spill217 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill217, align 32
  %.spill218 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill218, align 32
  %.spill219 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill219, align 32
  %.spill220 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill220, align 32
  %.spill221 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill221, align 32
  %.spill222 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill222, align 32
  %.spill223 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill223, align 32
  %.spill224 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill224, align 32
  %.spill225 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill225, align 32
  %.spill226 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill226, align 32
  %.spill227 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill227, align 32
  %.spill228 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill228, align 32
  %.spill229 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill229, align 32
  %.spill230 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill230, align 32
  %.spill231 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill231, align 32
  %.spill232 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill232, align 32
  %.spill233 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill233, align 32
  %.spill234 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill234, align 32
  %.spill235 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill235, align 32
  %.spill236 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill236, align 32
  %.spill237 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill237, align 32
  %.spill238 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill238, align 32
  %.spill239 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill239, align 32
  %.spill240 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill240, align 32
  %.spill241 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill241, align 32
  %.spill242 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill242, align 32
  %.spill243 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill243, align 32
  %.spill244 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill244, align 32
  %.spill245 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill245, align 32
  %.spill246 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill246, align 32
  %.spill247 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill247, align 32
  %.spill248 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill248, align 32
  %.spill249 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill249, align 32
  %.spill250 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill250, align 32
  %.spill251 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill251, align 32
  %.spill252 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill252, align 32
  %.spill253 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill253, align 32
  %.spill254 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill254, align 32
  %.spill255 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill255, align 32
  %.spill256 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill256, align 32
  %.spill257 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill257, align 32
  %.spill258 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill258, align 32
  %.spill259 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill259, align 32
  %.spill260 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill260, align 32
  %.spill261 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill261, align 32
  %.spill262 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill262, align 32
  %.spill263 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill263, align 32
  %.spill264 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill264, align 32
  %.spill265 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill265, align 32
  %.spill266 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill266, align 32
  %.spill267 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill267, align 32
  %.spill268 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill268, align 32
  %.spill269 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill269, align 32
  %.spill270 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill270, align 32
  %tile_snapshot.spill271 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill271, align 64
  %.slot272 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot272, align 64
  %.slot273 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot273, align 32
  %.slot274 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot274, align 64
  %.slot275 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot275, align 32
  %.slot276 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot276, align 64
  %.slot277 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot277, align 32
  %.slot278 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot278, align 64
  %.slot279 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot279, align 32
  %.spill280 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill280, align 32
  %.spill281 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill281, align 32
  %.spill282 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill282, align 32
  %.spill283 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill283, align 32
  %tile_snapshot.spill284 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill284, align 64
  %tile_snapshot.spill285 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill285, align 64
  %.spill286 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill286, align 32
  %.spill287 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill287, align 32
  %.spill288 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill288, align 32
  %.spill289 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill289, align 32
  %.slot290 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot290, align 64
  %.slot291 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot291, align 32
  %.slot292 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot292, align 64
  %.slot293 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot293, align 32
  %.slot294 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot294, align 64
  %.slot295 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot295, align 32
  %.slot296 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot296, align 64
  %.slot297 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot297, align 32
  %.spill298 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill298, align 32
  %.spill299 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill299, align 32
  %.spill300 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill300, align 32
  %.spill301 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill301, align 32
  %tile_snapshot.spill302 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill302, align 64
  %.slot303 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot303, align 64
  %.slot304 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot304, align 64
  %.spill305 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill305, align 64
  %.spill306 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill306, align 64
  %.spill307 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill307, align 64
  %.spill308 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill308, align 64
  %.spill309 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill309, align 64
  %.spill310 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill310, align 64
  %.spill311 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill311, align 64
  %.spill312 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill312, align 64
  %.spill313 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill313, align 64
  %.slot314 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot314, align 64
  %.slot315 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot315, align 32
  %.slot316 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot316, align 32
  %.slot317 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot317, align 32
  %.slot318 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot318, align 32
  %.slot319 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot319, align 64
  %.slot320 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot320, align 64
  %tile_snapshot.spill321 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill321, align 64
  %.slot322 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot322, align 64
  %.spill323 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill323, align 64
  %.spill324 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill324, align 32
  %30 = getelementptr i8, ptr %argument_buffer, i64 0
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 16
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 32
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = getelementptr i8, ptr %argument_buffer, i64 48
  %49 = load ptr, ptr %48, align 16
  %50 = getelementptr i8, ptr %48, i64 8
  %51 = load i64, ptr %50, align 8
  %52 = insertvalue { ptr, i64 } poison, ptr %49, 0
  %53 = insertvalue { ptr, i64 } %52, i64 %51, 1
  %54 = load i32, ptr %launch_config, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 12
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 4
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 16
  %60 = load i32, ptr %59, align 4
  %61 = getelementptr i8, ptr %launch_config, i64 8
  %62 = load i32, ptr %61, align 4
  %63 = getelementptr i8, ptr %launch_config, i64 20
  %64 = load i32, ptr %63, align 4
  %65 = getelementptr i8, ptr %launch_config, i64 36
  %66 = load i32, ptr %65, align 4
  %.splatinsert325 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat326 = shufflevector <8 x i32> %.splatinsert325, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat326, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %68 = mul i32 %54, 32
  %.splatinsert327 = insertelement <8 x i32> poison, i32 %68, i64 0
  %.splat328 = shufflevector <8 x i32> %.splatinsert327, <8 x i32> poison, <8 x i32> zeroinitializer
  %69 = add <8 x i32> %.splat328, %67
  %70 = mul i32 %58, 1
  %.splatinsert329 = insertelement <8 x i32> poison, i32 %70, i64 0
  %.splat330 = shufflevector <8 x i32> %.splatinsert329, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = add <8 x i32> %.splat330, zeroinitializer
  %72 = mul i32 %62, 1
  %.splatinsert331 = insertelement <8 x i32> poison, i32 %72, i64 0
  %.splat332 = shufflevector <8 x i32> %.splatinsert331, <8 x i32> poison, <8 x i32> zeroinitializer
  %73 = add <8 x i32> %.splat332, zeroinitializer
  %74 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %69, 0
  %75 = insertvalue [3 x <8 x i32>] %74, <8 x i32> %71, 1
  %76 = insertvalue [3 x <8 x i32>] %75, <8 x i32> %73, 2
  %.splatinsert333 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat334 = shufflevector <8 x i32> %.splatinsert333, <8 x i32> poison, <8 x i32> zeroinitializer
  %77 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat334
  store <8 x i1> %77, ptr %live.mask, align 1
  %78 = load i32, ptr %current.token, align 4
  %79 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %77)
  %80 = load i32, ptr %ready.count, align 4
  %81 = icmp uge i32 %80, 8
  %82 = and i1 %79, %81
  br i1 %82, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %83 = select i1 %79, i32 %80, i32 0
  %84 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %83
  %85 = load <8 x i1>, ptr %84, align 1
  %86 = select i1 %79, <8 x i1> %77, <8 x i1> %85
  store <8 x i1> %86, ptr %84, align 1
  %87 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %83
  %88 = load i32, ptr %87, align 4
  %89 = select i1 %79, i32 0, i32 %88
  store i32 %89, ptr %87, align 4
  %90 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %83
  %91 = load i32, ptr %90, align 4
  %92 = select i1 %79, i32 %78, i32 %91
  store i32 %92, ptr %90, align 4
  %93 = add i32 %80, 1
  %94 = select i1 %79, i32 %93, i32 %80
  store i32 %94, ptr %ready.count, align 4
  %95 = load <8 x i1>, ptr %runnable.mask, align 1
  %96 = or <8 x i1> %95, %77
  store <8 x i1> %96, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit2258, %convergence.target.112.ready, %convergence.cascade.exit2240, %schedule.111, %varying.coherent.false2236, %varying.coherent.true2235, %varying.coherent.false2221, %varying.coherent.true2220, %convergence.target.108.ready, %convergence.cascade.exit2185, %convergence.target.107.ready, %convergence.cascade.exit2159, %schedule.106, %varying.coherent.false2152, %varying.coherent.true2151, %convergence.target.104.ready, %convergence.cascade.exit2128, %schedule.103, %varying.coherent.false2121, %varying.coherent.true2120, %convergence.target.101.ready, %convergence.cascade.exit2097, %convergence.target.100.ready, %convergence.cascade.exit2079, %convergence.target.99.ready, %convergence.cascade.exit2049, %schedule.98, %varying.coherent.false2030, %varying.coherent.true2029, %schedule.96, %varying.coherent.false2011, %varying.coherent.true2010, %schedule.94, %varying.coherent.false2002, %varying.coherent.true2001, %convergence.target.92.ready, %convergence.cascade.exit1970, %schedule.91, %varying.coherent.false1964, %varying.coherent.true1963, %convergence.target.89.ready, %convergence.cascade.exit1940, %schedule.88, %varying.coherent.false1934, %varying.coherent.true1933, %convergence.target.86.ready, %convergence.cascade.exit1910, %schedule.85, %varying.coherent.false1904, %varying.coherent.true1903, %convergence.target.83.ready, %convergence.cascade.exit1880, %schedule.82, %varying.coherent.false1874, %varying.coherent.true1873, %convergence.target.80.ready, %convergence.cascade.exit1503, %schedule.79, %varying.coherent.false1497, %varying.coherent.true1496, %convergence.target.77.ready, %convergence.cascade.exit1473, %schedule.76, %varying.coherent.false1467, %varying.coherent.true1466, %convergence.target.74.ready, %convergence.cascade.exit1443, %schedule.73, %varying.coherent.false1437, %varying.coherent.true1436, %convergence.target.71.ready, %convergence.cascade.exit1413, %schedule.70, %varying.coherent.false1407, %varying.coherent.true1406, %convergence.target.68.ready, %convergence.cascade.exit1173, %schedule.67, %varying.coherent.false1156, %varying.coherent.true1155, %convergence.target.65.ready, %convergence.cascade.exit1132, %schedule.64, %varying.coherent.false1115, %varying.coherent.true1114, %convergence.target.62.ready, %convergence.cascade.exit1091, %schedule.61, %varying.coherent.false1074, %varying.coherent.true1073, %convergence.target.59.ready, %convergence.cascade.exit1050, %schedule.58, %varying.coherent.false1034, %varying.coherent.true1033, %convergence.target.56.ready, %convergence.cascade.exit1010, %schedule.55, %varying.coherent.false993, %varying.coherent.true992, %convergence.target.53.ready, %convergence.cascade.exit969, %schedule.52, %varying.coherent.false952, %varying.coherent.true951, %convergence.target.50.ready, %convergence.cascade.exit928, %schedule.49, %varying.coherent.false911, %varying.coherent.true910, %convergence.target.47.ready, %convergence.cascade.exit887, %schedule.46, %varying.coherent.false871, %varying.coherent.true870, %convergence.target.44.ready, %convergence.cascade.exit847, %schedule.43, %varying.coherent.false830, %varying.coherent.true829, %convergence.target.41.ready, %convergence.cascade.exit806, %schedule.40, %varying.coherent.false789, %varying.coherent.true788, %convergence.target.38.ready, %convergence.cascade.exit765, %schedule.37, %varying.coherent.false748, %varying.coherent.true747, %convergence.target.35.ready, %convergence.cascade.exit724, %schedule.34, %varying.coherent.false708, %varying.coherent.true707, %convergence.target.32.ready, %convergence.cascade.exit684, %schedule.31, %varying.coherent.false667, %varying.coherent.true666, %convergence.target.29.ready, %convergence.cascade.exit643, %schedule.28, %varying.coherent.false626, %varying.coherent.true625, %convergence.target.26.ready, %convergence.cascade.exit602, %schedule.25, %varying.coherent.false585, %varying.coherent.true584, %convergence.target.23.ready, %convergence.cascade.exit561, %schedule.22, %varying.coherent.false545, %varying.coherent.true544, %convergence.target.20.ready, %convergence.cascade.exit521, %convergence.target.19.ready, %convergence.cascade.exit500, %schedule.18, %varying.coherent.false497, %varying.coherent.true496, %varying.coherent.false484, %varying.coherent.true483, %convergence.target.15.ready, %convergence.cascade.exit460, %convergence.target.14.ready, %convergence.cascade.exit439, %schedule.13, %varying.coherent.false436, %varying.coherent.true435, %varying.coherent.false423, %varying.coherent.true422, %schedule.10, %varying.coherent.false413, %varying.coherent.true412, %convergence.target.8.ready, %convergence.cascade.exit389, %schedule.7, %varying.coherent.false384, %varying.coherent.true383, %convergence.target.5.ready, %convergence.cascade.exit360, %convergence.target.4.ready, %convergence.cascade.exit, %schedule.3, %varying.coherent.false348, %varying.coherent.true347, %varying.coherent.false, %varying.coherent.true, %schedule.0, %ready.overflow.resume
  %97 = load i32, ptr %ready.count, align 4
  %98 = icmp ne i32 %97, 0
  br i1 %98, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %99 = sub i32 %97, 1
  store i32 %99, ptr %ready.count, align 4
  %100 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %99
  %101 = load <8 x i1>, ptr %100, align 1
  store <8 x i1> %101, ptr %current.mask, align 1
  %102 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %99
  %103 = load i32, ptr %102, align 4
  %104 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %99
  %105 = load i32, ptr %104, align 4
  store i32 %105, ptr %current.token, align 4
  %106 = load <8 x i1>, ptr %runnable.mask, align 1
  %107 = xor <8 x i1> %101, splat (i1 true)
  %108 = and <8 x i1> %106, %107
  store <8 x i1> %108, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume2234, %ready.overflow.resume2219, %ready.overflow.resume2150, %ready.overflow.resume2119, %ready.overflow.resume2028, %ready.overflow.resume2009, %ready.overflow.resume2000, %ready.overflow.resume1962, %ready.overflow.resume1932, %ready.overflow.resume1902, %ready.overflow.resume1872, %ready.overflow.resume1495, %ready.overflow.resume1465, %ready.overflow.resume1435, %ready.overflow.resume1405, %ready.overflow.resume1154, %ready.overflow.resume1113, %ready.overflow.resume1072, %ready.overflow.resume1032, %ready.overflow.resume991, %ready.overflow.resume950, %ready.overflow.resume909, %ready.overflow.resume869, %ready.overflow.resume828, %ready.overflow.resume787, %ready.overflow.resume746, %ready.overflow.resume706, %ready.overflow.resume665, %ready.overflow.resume624, %ready.overflow.resume583, %ready.overflow.resume543, %ready.overflow.resume495, %ready.overflow.resume482, %ready.overflow.resume434, %ready.overflow.resume421, %ready.overflow.resume411, %ready.overflow.resume382, %ready.overflow.resume346, %ready.overflow.resume336, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %103, %scheduler.dispatch ], [ 5, %ready.overflow.resume336 ], [ 4, %ready.overflow.resume346 ], [ 8, %ready.overflow.resume382 ], [ 108, %ready.overflow.resume411 ], [ 15, %ready.overflow.resume421 ], [ 14, %ready.overflow.resume434 ], [ 20, %ready.overflow.resume482 ], [ 19, %ready.overflow.resume495 ], [ 23, %ready.overflow.resume543 ], [ 26, %ready.overflow.resume583 ], [ 29, %ready.overflow.resume624 ], [ 32, %ready.overflow.resume665 ], [ 35, %ready.overflow.resume706 ], [ 38, %ready.overflow.resume746 ], [ 41, %ready.overflow.resume787 ], [ 44, %ready.overflow.resume828 ], [ 47, %ready.overflow.resume869 ], [ 50, %ready.overflow.resume909 ], [ 53, %ready.overflow.resume950 ], [ 56, %ready.overflow.resume991 ], [ 59, %ready.overflow.resume1032 ], [ 62, %ready.overflow.resume1072 ], [ 65, %ready.overflow.resume1113 ], [ 68, %ready.overflow.resume1154 ], [ 71, %ready.overflow.resume1405 ], [ 74, %ready.overflow.resume1435 ], [ 77, %ready.overflow.resume1465 ], [ 80, %ready.overflow.resume1495 ], [ 83, %ready.overflow.resume1872 ], [ 86, %ready.overflow.resume1902 ], [ 89, %ready.overflow.resume1932 ], [ 92, %ready.overflow.resume1962 ], [ 101, %ready.overflow.resume2000 ], [ 100, %ready.overflow.resume2009 ], [ 99, %ready.overflow.resume2028 ], [ 104, %ready.overflow.resume2119 ], [ 107, %ready.overflow.resume2150 ], [ 113, %ready.overflow.resume2219 ], [ 112, %ready.overflow.resume2234 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
    i32 41, label %schedule.41
    i32 42, label %schedule.42
    i32 43, label %schedule.43
    i32 44, label %schedule.44
    i32 45, label %schedule.45
    i32 46, label %schedule.46
    i32 47, label %schedule.47
    i32 48, label %schedule.48
    i32 49, label %schedule.49
    i32 50, label %schedule.50
    i32 51, label %schedule.51
    i32 52, label %schedule.52
    i32 53, label %schedule.53
    i32 54, label %schedule.54
    i32 55, label %schedule.55
    i32 56, label %schedule.56
    i32 57, label %schedule.57
    i32 58, label %schedule.58
    i32 59, label %schedule.59
    i32 60, label %schedule.60
    i32 61, label %schedule.61
    i32 62, label %schedule.62
    i32 63, label %schedule.63
    i32 64, label %schedule.64
    i32 65, label %schedule.65
    i32 66, label %schedule.66
    i32 67, label %schedule.67
    i32 68, label %schedule.68
    i32 69, label %schedule.69
    i32 70, label %schedule.70
    i32 71, label %schedule.71
    i32 72, label %schedule.72
    i32 73, label %schedule.73
    i32 74, label %schedule.74
    i32 75, label %schedule.75
    i32 76, label %schedule.76
    i32 77, label %schedule.77
    i32 78, label %schedule.78
    i32 79, label %schedule.79
    i32 80, label %schedule.80
    i32 81, label %schedule.81
    i32 82, label %schedule.82
    i32 83, label %schedule.83
    i32 84, label %schedule.84
    i32 85, label %schedule.85
    i32 86, label %schedule.86
    i32 87, label %schedule.87
    i32 88, label %schedule.88
    i32 89, label %schedule.89
    i32 90, label %schedule.90
    i32 91, label %schedule.91
    i32 92, label %schedule.92
    i32 93, label %schedule.93
    i32 94, label %schedule.94
    i32 95, label %schedule.95
    i32 96, label %schedule.96
    i32 97, label %schedule.97
    i32 98, label %schedule.98
    i32 99, label %schedule.99
    i32 100, label %schedule.100
    i32 101, label %schedule.101
    i32 102, label %schedule.102
    i32 103, label %schedule.103
    i32 104, label %schedule.104
    i32 105, label %schedule.105
    i32 106, label %schedule.106
    i32 107, label %schedule.107
    i32 108, label %schedule.108
    i32 109, label %schedule.109
    i32 110, label %schedule.110
    i32 111, label %schedule.111
    i32 112, label %schedule.112
    i32 113, label %schedule.113
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %109 = load <8 x i1>, ptr %live.mask, align 1
  %110 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %109)
  br i1 %110, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %111 = load <8 x i1>, ptr %current.mask, align 1
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  %113 = bitcast <8 x i1> %111 to i8
  %114 = call i8 @llvm.cttz.i8(i8 %113, i1 false)
  %115 = zext i8 %114 to i32
  %116 = select i1 %112, i32 %115, i32 0
  %117 = extractvalue [3 x <8 x i32>] %76, 0
  %118 = zext <8 x i32> %117 to <8 x i64>
  %119 = select <8 x i1> %111, <8 x i64> %118, <8 x i64> zeroinitializer
  %120 = select <8 x i1> %111, <8 x i64> splat (i64 30), <8 x i64> splat (i64 1)
  %121 = sdiv <8 x i64> %119, %120
  %122 = load <8 x i64>, ptr %.spill, align 64
  %123 = select <8 x i1> %111, <8 x i64> %121, <8 x i64> %122
  store <8 x i64> %123, ptr %.spill, align 64
  %124 = select <8 x i1> %111, <8 x i64> %118, <8 x i64> zeroinitializer
  %125 = select <8 x i1> %111, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %126 = sdiv <8 x i64> %124, %125
  %127 = select <8 x i1> %111, <8 x i64> %126, <8 x i64> zeroinitializer
  %128 = select <8 x i1> %111, <8 x i64> splat (i64 6), <8 x i64> splat (i64 1)
  %129 = srem <8 x i64> %127, %128
  %130 = load <8 x i64>, ptr %.spill37, align 64
  %131 = select <8 x i1> %111, <8 x i64> %129, <8 x i64> %130
  store <8 x i64> %131, ptr %.spill37, align 64
  %132 = select <8 x i1> %111, <8 x i64> %118, <8 x i64> zeroinitializer
  %133 = select <8 x i1> %111, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %134 = sdiv <8 x i64> %132, %133
  %135 = select <8 x i1> %111, <8 x i64> %134, <8 x i64> zeroinitializer
  %136 = select <8 x i1> %111, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %137 = srem <8 x i64> %135, %136
  %138 = mul <8 x i64> %137, splat (i64 4)
  %139 = load <8 x i64>, ptr %.spill38, align 64
  %140 = select <8 x i1> %111, <8 x i64> %138, <8 x i64> %139
  store <8 x i64> %140, ptr %.spill38, align 64
  %141 = select <8 x i1> %111, <8 x i64> %129, <8 x i64> zeroinitializer
  %142 = select <8 x i1> %111, <8 x i64> splat (i64 3), <8 x i64> splat (i64 1)
  %143 = sdiv <8 x i64> %141, %142
  %144 = load <8 x i64>, ptr %.spill39, align 64
  %145 = select <8 x i1> %111, <8 x i64> %143, <8 x i64> %144
  store <8 x i64> %145, ptr %.spill39, align 64
  %146 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %146, 0
  %149 = select <8 x i1> %111, <8 x ptr> %147, <8 x ptr> %148
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %146, 1
  %152 = select <8 x i1> %111, <8 x i64> %150, <8 x i64> %151
  %153 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %149, 0
  %154 = insertvalue { <8 x ptr>, <8 x i64> } %153, <8 x i64> %152, 1
  store { <8 x ptr>, <8 x i64> } %154, ptr %tile_snapshot.spill, align 64
  %155 = load <8 x i64>, ptr %.slot, align 64
  %156 = select <8 x i1> %111, <8 x i64> zeroinitializer, <8 x i64> %155
  store <8 x i64> %156, ptr %.slot, align 64
  store <8 x i1> %111, ptr %current.mask, align 1
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  br i1 %157, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %convergence.target.4.ready, %schedule.0, %scheduler.dispatch.route
  %158 = load <8 x i1>, ptr %current.mask, align 1
  %159 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %158)
  %160 = bitcast <8 x i1> %158 to i8
  %161 = call i8 @llvm.cttz.i8(i8 %160, i1 false)
  %162 = zext i8 %161 to i32
  %163 = select i1 %159, i32 %162, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %164 = icmp slt <8 x i64> %.state, splat (i64 160)
  %165 = and <8 x i1> %158, %164
  %166 = xor <8 x i1> %164, splat (i1 true)
  %167 = and <8 x i1> %158, %166
  %168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %165)
  %169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %167)
  %170 = and i1 %168, %169
  br i1 %170, label %varying.divergent, label %varying.coherent

schedule.2:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %171 = load <8 x i1>, ptr %current.mask, align 1
  %172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %171)
  %173 = bitcast <8 x i1> %171 to i8
  %174 = call i8 @llvm.cttz.i8(i8 %173, i1 false)
  %175 = zext i8 %174 to i32
  %176 = select i1 %172, i32 %175, i32 0
  %.state337 = load <8 x i64>, ptr %.slot, align 64
  %177 = select <8 x i1> %171, <8 x i64> %.state337, <8 x i64> zeroinitializer
  %178 = select <8 x i1> %171, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %179 = srem <8 x i64> %177, %178
  %.state338 = load <8 x i64>, ptr %.slot, align 64
  %180 = select <8 x i1> %171, <8 x i64> %.state338, <8 x i64> zeroinitializer
  %181 = select <8 x i1> %171, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %182 = sdiv <8 x i64> %180, %181
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %183 = add <8 x i64> %.spill.load, zeroinitializer
  %184 = add <8 x i64> zeroinitializer, %183
  %.spill.load339 = load <8 x i64>, ptr %.spill37, align 64
  %185 = add <8 x i64> %.spill.load339, zeroinitializer
  %186 = mul <8 x i64> %184, splat (i64 6)
  %187 = add <8 x i64> %186, %185
  %.spill.load340 = load <8 x i64>, ptr %.spill38, align 64
  %188 = add <8 x i64> %.spill.load340, %182
  %189 = mul <8 x i64> %187, splat (i64 17)
  %190 = add <8 x i64> %189, %188
  %191 = icmp sge <8 x i64> %188, zeroinitializer
  %192 = and <8 x i1> splat (i1 true), %191
  %193 = icmp slt <8 x i64> %188, splat (i64 17)
  %194 = and <8 x i1> %192, %193
  %195 = add <8 x i64> zeroinitializer, %179
  %196 = mul <8 x i64> %190, splat (i64 40)
  %197 = add <8 x i64> %196, %195
  %198 = load <8 x i64>, ptr %.spill40, align 64
  %199 = select <8 x i1> %171, <8 x i64> %197, <8 x i64> %198
  store <8 x i64> %199, ptr %.spill40, align 64
  %200 = and <8 x i1> %171, %194
  %201 = xor <8 x i1> %194, splat (i1 true)
  %202 = and <8 x i1> %171, %201
  %203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %202)
  %205 = and i1 %203, %204
  br i1 %205, label %varying.divergent341, label %varying.coherent342

schedule.3:                                       ; preds = %varying.coherent.true347, %scheduler.dispatch.route
  %206 = load <8 x i1>, ptr %current.mask, align 1
  %207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %206)
  %208 = bitcast <8 x i1> %206 to i8
  %209 = call i8 @llvm.cttz.i8(i8 %208, i1 false)
  %210 = zext i8 %209 to i32
  %211 = select i1 %207, i32 %210, i32 0
  %.spill.load349 = load <8 x i64>, ptr %.spill40, align 64
  %212 = extractvalue { ptr, i64 } %35, 0
  %213 = mul <8 x i64> %.spill.load349, splat (i64 4)
  %214 = getelementptr i8, ptr %212, <8 x i64> %213
  %215 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %214, <8 x i1> %206, <8 x float> zeroinitializer)
  %216 = load <8 x float>, ptr %.slot41, align 32
  %217 = select <8 x i1> %206, <8 x float> %215, <8 x float> %216
  store <8 x float> %217, ptr %.slot41, align 32
  store <8 x i1> %206, ptr %current.mask, align 1
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %206)
  br i1 %218, label %schedule.4, label %scheduler.loop

schedule.4:                                       ; preds = %schedule.3, %varying.coherent.false348, %scheduler.dispatch.route
  %219 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.5:                                       ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %220 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token361 = load i32, ptr %current.token, align 4
  %convergence.token.present362 = icmp ne i32 %convergence.current.token361, 0
  br i1 %convergence.token.present362, label %convergence.cascade359, label %convergence.cascade.exit360

schedule.6:                                       ; preds = %schedule.7, %convergence.target.5.ready, %scheduler.dispatch.route
  %221 = load <8 x i1>, ptr %current.mask, align 1
  %222 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  %223 = bitcast <8 x i1> %221 to i8
  %224 = call i8 @llvm.cttz.i8(i8 %223, i1 false)
  %225 = zext i8 %224 to i32
  %226 = select i1 %222, i32 %225, i32 0
  %.state376 = load <8 x i64>, ptr %.slot, align 64
  %227 = icmp slt <8 x i64> %.state376, splat (i64 192)
  %228 = and <8 x i1> %221, %227
  %229 = xor <8 x i1> %227, splat (i1 true)
  %230 = and <8 x i1> %221, %229
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %230)
  %233 = and i1 %231, %232
  br i1 %233, label %varying.divergent377, label %varying.coherent378

schedule.7:                                       ; preds = %varying.coherent.true383, %scheduler.dispatch.route
  %234 = load <8 x i1>, ptr %current.mask, align 1
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  %236 = bitcast <8 x i1> %234 to i8
  %237 = call i8 @llvm.cttz.i8(i8 %236, i1 false)
  %238 = zext i8 %237 to i32
  %239 = select i1 %235, i32 %238, i32 0
  %tile_snapshot.spill.load385 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load385, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load385, 1
  %.state386 = load <8 x i64>, ptr %.slot, align 64
  %242 = mul <8 x i64> %.state386, splat (i64 32)
  %243 = add <8 x i64> %241, %242
  %244 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %240, 0
  %245 = insertvalue { <8 x ptr>, <8 x i64> } %244, <8 x i64> %243, 1
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %245, 0
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %245, 1
  %248 = getelementptr i8, <8 x ptr> %246, <8 x i64> %247
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %248, <8 x i1> %234)
  %.state387 = load <8 x i64>, ptr %.slot, align 64
  %249 = add <8 x i64> %.state387, splat (i64 1)
  %250 = load <8 x i64>, ptr %.slot, align 64
  %251 = select <8 x i1> %234, <8 x i64> %249, <8 x i64> %250
  store <8 x i64> %251, ptr %.slot, align 64
  store <8 x i1> %234, ptr %current.mask, align 1
  %252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %252, label %schedule.6, label %scheduler.loop

schedule.8:                                       ; preds = %varying.coherent.false384, %scheduler.dispatch.route
  %253 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token390 = load i32, ptr %current.token, align 4
  %convergence.token.present391 = icmp ne i32 %convergence.current.token390, 0
  br i1 %convergence.token.present391, label %convergence.cascade388, label %convergence.cascade.exit389

schedule.9:                                       ; preds = %convergence.target.107.ready, %convergence.target.8.ready, %scheduler.dispatch.route
  %254 = load <8 x i1>, ptr %current.mask, align 1
  %255 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %254)
  %256 = bitcast <8 x i1> %254 to i8
  %257 = call i8 @llvm.cttz.i8(i8 %256, i1 false)
  %258 = zext i8 %257 to i32
  %259 = select i1 %255, i32 %258, i32 0
  %.state405 = load <8 x i64>, ptr %.slot, align 64
  %260 = icmp slt <8 x i64> %.state405, splat (i64 5)
  %261 = and <8 x i1> %254, %260
  %262 = xor <8 x i1> %260, splat (i1 true)
  %263 = and <8 x i1> %254, %262
  %264 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %261)
  %265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %263)
  %266 = and i1 %264, %265
  br i1 %266, label %varying.divergent406, label %varying.coherent407

schedule.10:                                      ; preds = %varying.coherent.true412, %scheduler.dispatch.route
  %267 = load <8 x i1>, ptr %current.mask, align 1
  %268 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %267)
  %269 = bitcast <8 x i1> %267 to i8
  %270 = call i8 @llvm.cttz.i8(i8 %269, i1 false)
  %271 = zext i8 %270 to i32
  %272 = select i1 %268, i32 %271, i32 0
  %.state414 = load <8 x i64>, ptr %.slot, align 64
  %273 = select <8 x i1> %267, <8 x i64> %.state414, <8 x i64> zeroinitializer
  %274 = select <8 x i1> %267, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %275 = sdiv <8 x i64> %273, %274
  %276 = mul <8 x i64> %275, splat (i64 16)
  %277 = load <8 x i64>, ptr %.spill54, align 64
  %278 = select <8 x i1> %267, <8 x i64> %276, <8 x i64> %277
  store <8 x i64> %278, ptr %.spill54, align 64
  %279 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %279, 0
  %282 = select <8 x i1> %267, <8 x ptr> %280, <8 x ptr> %281
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %279, 1
  %285 = select <8 x i1> %267, <8 x i64> %283, <8 x i64> %284
  %286 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %282, 0
  %287 = insertvalue { <8 x ptr>, <8 x i64> } %286, <8 x i64> %285, 1
  store { <8 x ptr>, <8 x i64> } %287, ptr %tile_snapshot.spill55, align 64
  %288 = load <8 x i64>, ptr %.slot56, align 64
  %289 = select <8 x i1> %267, <8 x i64> zeroinitializer, <8 x i64> %288
  store <8 x i64> %289, ptr %.slot56, align 64
  store <8 x i1> %267, ptr %current.mask, align 1
  %290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %267)
  br i1 %290, label %schedule.11, label %scheduler.loop

schedule.11:                                      ; preds = %convergence.target.14.ready, %schedule.10, %scheduler.dispatch.route
  %291 = load <8 x i1>, ptr %current.mask, align 1
  %292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %291)
  %293 = bitcast <8 x i1> %291 to i8
  %294 = call i8 @llvm.cttz.i8(i8 %293, i1 false)
  %295 = zext i8 %294 to i32
  %296 = select i1 %292, i32 %295, i32 0
  %.state415 = load <8 x i64>, ptr %.slot56, align 64
  %297 = icmp slt <8 x i64> %.state415, splat (i64 640)
  %298 = and <8 x i1> %291, %297
  %299 = xor <8 x i1> %297, splat (i1 true)
  %300 = and <8 x i1> %291, %299
  %301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %298)
  %302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %300)
  %303 = and i1 %301, %302
  br i1 %303, label %varying.divergent416, label %varying.coherent417

schedule.12:                                      ; preds = %varying.coherent.true422, %scheduler.dispatch.route
  %304 = load <8 x i1>, ptr %current.mask, align 1
  %305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %304)
  %306 = bitcast <8 x i1> %304 to i8
  %307 = call i8 @llvm.cttz.i8(i8 %306, i1 false)
  %308 = zext i8 %307 to i32
  %309 = select i1 %305, i32 %308, i32 0
  %.state424 = load <8 x i64>, ptr %.slot56, align 64
  %310 = select <8 x i1> %304, <8 x i64> %.state424, <8 x i64> zeroinitializer
  %311 = select <8 x i1> %304, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %312 = srem <8 x i64> %310, %311
  %.state425 = load <8 x i64>, ptr %.slot56, align 64
  %313 = select <8 x i1> %304, <8 x i64> %.state425, <8 x i64> zeroinitializer
  %314 = select <8 x i1> %304, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %315 = sdiv <8 x i64> %313, %314
  %.spill.load426 = load <8 x i64>, ptr %.spill, align 64
  %316 = add <8 x i64> %.spill.load426, zeroinitializer
  %317 = add <8 x i64> zeroinitializer, %316
  %.spill.load427 = load <8 x i64>, ptr %.spill39, align 64
  %318 = add <8 x i64> %.spill.load427, zeroinitializer
  %319 = mul <8 x i64> %317, splat (i64 2)
  %320 = add <8 x i64> %319, %318
  %.spill.load428 = load <8 x i64>, ptr %.spill54, align 64
  %321 = add <8 x i64> %.spill.load428, %315
  %322 = mul <8 x i64> %320, splat (i64 67)
  %323 = add <8 x i64> %322, %321
  %324 = icmp sge <8 x i64> %321, zeroinitializer
  %325 = and <8 x i1> splat (i1 true), %324
  %326 = icmp slt <8 x i64> %321, splat (i64 67)
  %327 = and <8 x i1> %325, %326
  %328 = add <8 x i64> zeroinitializer, %312
  %329 = mul <8 x i64> %323, splat (i64 40)
  %330 = add <8 x i64> %329, %328
  %331 = load <8 x i64>, ptr %.spill57, align 64
  %332 = select <8 x i1> %304, <8 x i64> %330, <8 x i64> %331
  store <8 x i64> %332, ptr %.spill57, align 64
  %333 = and <8 x i1> %304, %327
  %334 = xor <8 x i1> %327, splat (i1 true)
  %335 = and <8 x i1> %304, %334
  %336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %333)
  %337 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %335)
  %338 = and i1 %336, %337
  br i1 %338, label %varying.divergent429, label %varying.coherent430

schedule.13:                                      ; preds = %varying.coherent.true435, %scheduler.dispatch.route
  %339 = load <8 x i1>, ptr %current.mask, align 1
  %340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %339)
  %341 = bitcast <8 x i1> %339 to i8
  %342 = call i8 @llvm.cttz.i8(i8 %341, i1 false)
  %343 = zext i8 %342 to i32
  %344 = select i1 %340, i32 %343, i32 0
  %.spill.load437 = load <8 x i64>, ptr %.spill57, align 64
  %345 = extractvalue { ptr, i64 } %41, 0
  %346 = mul <8 x i64> %.spill.load437, splat (i64 4)
  %347 = getelementptr i8, ptr %345, <8 x i64> %346
  %348 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %347, <8 x i1> %339, <8 x float> zeroinitializer)
  %349 = load <8 x float>, ptr %.slot58, align 32
  %350 = select <8 x i1> %339, <8 x float> %348, <8 x float> %349
  store <8 x float> %350, ptr %.slot58, align 32
  store <8 x i1> %339, ptr %current.mask, align 1
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %339)
  br i1 %351, label %schedule.14, label %scheduler.loop

schedule.14:                                      ; preds = %schedule.13, %varying.coherent.false436, %scheduler.dispatch.route
  %352 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token440 = load i32, ptr %current.token, align 4
  %convergence.token.present441 = icmp ne i32 %convergence.current.token440, 0
  br i1 %convergence.token.present441, label %convergence.cascade438, label %convergence.cascade.exit439

schedule.15:                                      ; preds = %varying.coherent.false423, %scheduler.dispatch.route
  %353 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token461 = load i32, ptr %current.token, align 4
  %convergence.token.present462 = icmp ne i32 %convergence.current.token461, 0
  br i1 %convergence.token.present462, label %convergence.cascade459, label %convergence.cascade.exit460

schedule.16:                                      ; preds = %convergence.target.19.ready, %convergence.target.15.ready, %scheduler.dispatch.route
  %354 = load <8 x i1>, ptr %current.mask, align 1
  %355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %354)
  %356 = bitcast <8 x i1> %354 to i8
  %357 = call i8 @llvm.cttz.i8(i8 %356, i1 false)
  %358 = zext i8 %357 to i32
  %359 = select i1 %355, i32 %358, i32 0
  %.state476 = load <8 x i64>, ptr %.slot56, align 64
  %360 = icmp slt <8 x i64> %.state476, splat (i64 768)
  %361 = and <8 x i1> %354, %360
  %362 = xor <8 x i1> %360, splat (i1 true)
  %363 = and <8 x i1> %354, %362
  %364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %361)
  %365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %363)
  %366 = and i1 %364, %365
  br i1 %366, label %varying.divergent477, label %varying.coherent478

schedule.17:                                      ; preds = %varying.coherent.true483, %scheduler.dispatch.route
  %367 = load <8 x i1>, ptr %current.mask, align 1
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %367)
  %369 = bitcast <8 x i1> %367 to i8
  %370 = call i8 @llvm.cttz.i8(i8 %369, i1 false)
  %371 = zext i8 %370 to i32
  %372 = select i1 %368, i32 %371, i32 0
  %.state485 = load <8 x i64>, ptr %.slot56, align 64
  %373 = select <8 x i1> %367, <8 x i64> %.state485, <8 x i64> zeroinitializer
  %374 = select <8 x i1> %367, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %375 = srem <8 x i64> %373, %374
  %.state486 = load <8 x i64>, ptr %.slot56, align 64
  %376 = select <8 x i1> %367, <8 x i64> %.state486, <8 x i64> zeroinitializer
  %377 = select <8 x i1> %367, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %378 = sdiv <8 x i64> %376, %377
  %.spill.load487 = load <8 x i64>, ptr %.spill, align 64
  %379 = add <8 x i64> %.spill.load487, zeroinitializer
  %380 = add <8 x i64> zeroinitializer, %379
  %.spill.load488 = load <8 x i64>, ptr %.spill39, align 64
  %381 = add <8 x i64> %.spill.load488, zeroinitializer
  %382 = mul <8 x i64> %380, splat (i64 2)
  %383 = add <8 x i64> %382, %381
  %.spill.load489 = load <8 x i64>, ptr %.spill54, align 64
  %384 = add <8 x i64> %.spill.load489, %378
  %385 = mul <8 x i64> %383, splat (i64 67)
  %386 = add <8 x i64> %385, %384
  %387 = icmp sge <8 x i64> %384, zeroinitializer
  %388 = and <8 x i1> splat (i1 true), %387
  %389 = icmp slt <8 x i64> %384, splat (i64 67)
  %390 = and <8 x i1> %388, %389
  %391 = add <8 x i64> zeroinitializer, %375
  %392 = mul <8 x i64> %386, splat (i64 48)
  %393 = add <8 x i64> %392, %391
  %394 = load <8 x i64>, ptr %.spill61, align 64
  %395 = select <8 x i1> %367, <8 x i64> %393, <8 x i64> %394
  store <8 x i64> %395, ptr %.spill61, align 64
  %396 = and <8 x i1> %367, %390
  %397 = xor <8 x i1> %390, splat (i1 true)
  %398 = and <8 x i1> %367, %397
  %399 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %396)
  %400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %398)
  %401 = and i1 %399, %400
  br i1 %401, label %varying.divergent490, label %varying.coherent491

schedule.18:                                      ; preds = %varying.coherent.true496, %scheduler.dispatch.route
  %402 = load <8 x i1>, ptr %current.mask, align 1
  %403 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %402)
  %404 = bitcast <8 x i1> %402 to i8
  %405 = call i8 @llvm.cttz.i8(i8 %404, i1 false)
  %406 = zext i8 %405 to i32
  %407 = select i1 %403, i32 %406, i32 0
  %.spill.load498 = load <8 x i64>, ptr %.spill61, align 64
  %408 = extractvalue { ptr, i64 } %47, 0
  %409 = mul <8 x i64> %.spill.load498, splat (i64 4)
  %410 = getelementptr i8, ptr %408, <8 x i64> %409
  %411 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %410, <8 x i1> %402, <8 x float> zeroinitializer)
  %412 = load <8 x float>, ptr %.slot58, align 32
  %413 = select <8 x i1> %402, <8 x float> %411, <8 x float> %412
  store <8 x float> %413, ptr %.slot58, align 32
  store <8 x i1> %402, ptr %current.mask, align 1
  %414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %402)
  br i1 %414, label %schedule.19, label %scheduler.loop

schedule.19:                                      ; preds = %schedule.18, %varying.coherent.false497, %scheduler.dispatch.route
  %415 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token501 = load i32, ptr %current.token, align 4
  %convergence.token.present502 = icmp ne i32 %convergence.current.token501, 0
  br i1 %convergence.token.present502, label %convergence.cascade499, label %convergence.cascade.exit500

schedule.20:                                      ; preds = %varying.coherent.false484, %scheduler.dispatch.route
  %416 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token522 = load i32, ptr %current.token, align 4
  %convergence.token.present523 = icmp ne i32 %convergence.current.token522, 0
  br i1 %convergence.token.present523, label %convergence.cascade520, label %convergence.cascade.exit521

schedule.21:                                      ; preds = %schedule.22, %convergence.target.20.ready, %scheduler.dispatch.route
  %417 = load <8 x i1>, ptr %current.mask, align 1
  %418 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %417)
  %419 = bitcast <8 x i1> %417 to i8
  %420 = call i8 @llvm.cttz.i8(i8 %419, i1 false)
  %421 = zext i8 %420 to i32
  %422 = select i1 %418, i32 %421, i32 0
  %.state537 = load <8 x i64>, ptr %.slot56, align 64
  %423 = icmp slt <8 x i64> %.state537, splat (i64 40)
  %424 = and <8 x i1> %417, %423
  %425 = xor <8 x i1> %423, splat (i1 true)
  %426 = and <8 x i1> %417, %425
  %427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %424)
  %428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %426)
  %429 = and i1 %427, %428
  br i1 %429, label %varying.divergent538, label %varying.coherent539

schedule.22:                                      ; preds = %varying.coherent.true544, %scheduler.dispatch.route
  %430 = load <8 x i1>, ptr %current.mask, align 1
  %431 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %430)
  %432 = bitcast <8 x i1> %430 to i8
  %433 = call i8 @llvm.cttz.i8(i8 %432, i1 false)
  %434 = zext i8 %433 to i32
  %435 = select i1 %431, i32 %434, i32 0
  %.state546 = load <8 x i64>, ptr %.slot56, align 64
  %436 = add <8 x i64> zeroinitializer, %.state546
  %tile_snapshot.spill.load547 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load547, 0
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load547, 1
  %439 = mul <8 x i64> %436, splat (i64 32)
  %440 = add <8 x i64> %438, %439
  %441 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %437, 0
  %442 = insertvalue { <8 x ptr>, <8 x i64> } %441, <8 x i64> %440, 1
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %442, 0
  %444 = extractvalue { <8 x ptr>, <8 x i64> } %442, 1
  %445 = getelementptr i8, <8 x ptr> %443, <8 x i64> %444
  %446 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %445, <8 x i1> %430, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load548 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load548, 0
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load548, 1
  %449 = mul <8 x i64> %436, splat (i64 32)
  %450 = add <8 x i64> %448, %449
  %451 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %447, 0
  %452 = insertvalue { <8 x ptr>, <8 x i64> } %451, <8 x i64> %450, 1
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %452, 0
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %452, 1
  %455 = getelementptr i8, <8 x ptr> %453, <8 x i64> %454
  %456 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %455, <8 x i1> %430, <8 x float> zeroinitializer)
  %457 = fmul <8 x float> %446, %456
  %.state549 = load <8 x float>, ptr %.slot58, align 32
  %458 = fadd <8 x float> %.state549, %457
  %.state550 = load <8 x i64>, ptr %.slot56, align 64
  %459 = add <8 x i64> splat (i64 40), %.state550
  %tile_snapshot.spill.load551 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load551, 0
  %461 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load551, 1
  %462 = mul <8 x i64> %459, splat (i64 32)
  %463 = add <8 x i64> %461, %462
  %464 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %460, 0
  %465 = insertvalue { <8 x ptr>, <8 x i64> } %464, <8 x i64> %463, 1
  %466 = extractvalue { <8 x ptr>, <8 x i64> } %465, 0
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %465, 1
  %468 = getelementptr i8, <8 x ptr> %466, <8 x i64> %467
  %469 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %468, <8 x i1> %430, <8 x float> zeroinitializer)
  %470 = fmul <8 x float> %446, %469
  %.state552 = load <8 x float>, ptr %.slot65, align 32
  %471 = fadd <8 x float> %.state552, %470
  %.state553 = load <8 x i64>, ptr %.slot56, align 64
  %472 = add <8 x i64> splat (i64 80), %.state553
  %tile_snapshot.spill.load554 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %473 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load554, 0
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load554, 1
  %475 = mul <8 x i64> %472, splat (i64 32)
  %476 = add <8 x i64> %474, %475
  %477 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %473, 0
  %478 = insertvalue { <8 x ptr>, <8 x i64> } %477, <8 x i64> %476, 1
  %479 = extractvalue { <8 x ptr>, <8 x i64> } %478, 0
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %478, 1
  %481 = getelementptr i8, <8 x ptr> %479, <8 x i64> %480
  %482 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %481, <8 x i1> %430, <8 x float> zeroinitializer)
  %483 = fmul <8 x float> %446, %482
  %.state555 = load <8 x float>, ptr %.slot66, align 32
  %484 = fadd <8 x float> %.state555, %483
  %.state556 = load <8 x i64>, ptr %.slot56, align 64
  %485 = add <8 x i64> splat (i64 120), %.state556
  %tile_snapshot.spill.load557 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load557, 0
  %487 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load557, 1
  %488 = mul <8 x i64> %485, splat (i64 32)
  %489 = add <8 x i64> %487, %488
  %490 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %486, 0
  %491 = insertvalue { <8 x ptr>, <8 x i64> } %490, <8 x i64> %489, 1
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %491, 0
  %493 = extractvalue { <8 x ptr>, <8 x i64> } %491, 1
  %494 = getelementptr i8, <8 x ptr> %492, <8 x i64> %493
  %495 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %494, <8 x i1> %430, <8 x float> zeroinitializer)
  %496 = fmul <8 x float> %446, %495
  %.state558 = load <8 x float>, ptr %.slot67, align 32
  %497 = fadd <8 x float> %.state558, %496
  %.state559 = load <8 x i64>, ptr %.slot56, align 64
  %498 = add <8 x i64> %.state559, splat (i64 1)
  %499 = load <8 x i64>, ptr %.slot56, align 64
  %500 = select <8 x i1> %430, <8 x i64> %498, <8 x i64> %499
  store <8 x i64> %500, ptr %.slot56, align 64
  %501 = load <8 x float>, ptr %.slot58, align 32
  %502 = select <8 x i1> %430, <8 x float> %458, <8 x float> %501
  store <8 x float> %502, ptr %.slot58, align 32
  %503 = load <8 x float>, ptr %.slot65, align 32
  %504 = select <8 x i1> %430, <8 x float> %471, <8 x float> %503
  store <8 x float> %504, ptr %.slot65, align 32
  %505 = load <8 x float>, ptr %.slot66, align 32
  %506 = select <8 x i1> %430, <8 x float> %484, <8 x float> %505
  store <8 x float> %506, ptr %.slot66, align 32
  %507 = load <8 x float>, ptr %.slot67, align 32
  %508 = select <8 x i1> %430, <8 x float> %497, <8 x float> %507
  store <8 x float> %508, ptr %.slot67, align 32
  store <8 x i1> %430, ptr %current.mask, align 1
  %509 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %430)
  br i1 %509, label %schedule.21, label %scheduler.loop

schedule.23:                                      ; preds = %varying.coherent.false545, %scheduler.dispatch.route
  %510 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token562 = load i32, ptr %current.token, align 4
  %convergence.token.present563 = icmp ne i32 %convergence.current.token562, 0
  br i1 %convergence.token.present563, label %convergence.cascade560, label %convergence.cascade.exit561

schedule.24:                                      ; preds = %schedule.25, %convergence.target.23.ready, %scheduler.dispatch.route
  %511 = load <8 x i1>, ptr %current.mask, align 1
  %512 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %511)
  %513 = bitcast <8 x i1> %511 to i8
  %514 = call i8 @llvm.cttz.i8(i8 %513, i1 false)
  %515 = zext i8 %514 to i32
  %516 = select i1 %512, i32 %515, i32 0
  %.state577 = load <8 x i64>, ptr %.slot56, align 64
  %517 = icmp slt <8 x i64> %.state577, splat (i64 40)
  %518 = and <8 x i1> %511, %517
  %519 = xor <8 x i1> %517, splat (i1 true)
  %520 = and <8 x i1> %511, %519
  %521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %518)
  %522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %520)
  %523 = and i1 %521, %522
  br i1 %523, label %varying.divergent578, label %varying.coherent579

schedule.25:                                      ; preds = %varying.coherent.true584, %scheduler.dispatch.route
  %524 = load <8 x i1>, ptr %current.mask, align 1
  %525 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %524)
  %526 = bitcast <8 x i1> %524 to i8
  %527 = call i8 @llvm.cttz.i8(i8 %526, i1 false)
  %528 = zext i8 %527 to i32
  %529 = select i1 %525, i32 %528, i32 0
  %.state586 = load <8 x i64>, ptr %.slot56, align 64
  %530 = add <8 x i64> zeroinitializer, %.state586
  %tile_snapshot.spill.load587 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load587, 0
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load587, 1
  %533 = mul <8 x i64> %530, splat (i64 32)
  %534 = add <8 x i64> %532, %533
  %535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %531, 0
  %536 = insertvalue { <8 x ptr>, <8 x i64> } %535, <8 x i64> %534, 1
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %536, 0
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %536, 1
  %539 = getelementptr i8, <8 x ptr> %537, <8 x i64> %538
  %540 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %539, <8 x i1> %524, <8 x float> zeroinitializer)
  %.state588 = load <8 x i64>, ptr %.slot56, align 64
  %541 = add <8 x i64> splat (i64 160), %.state588
  %tile_snapshot.spill.load589 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %542 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load589, 0
  %543 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load589, 1
  %544 = mul <8 x i64> %541, splat (i64 32)
  %545 = add <8 x i64> %543, %544
  %546 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %542, 0
  %547 = insertvalue { <8 x ptr>, <8 x i64> } %546, <8 x i64> %545, 1
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %547, 0
  %549 = extractvalue { <8 x ptr>, <8 x i64> } %547, 1
  %550 = getelementptr i8, <8 x ptr> %548, <8 x i64> %549
  %551 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %550, <8 x i1> %524, <8 x float> zeroinitializer)
  %552 = fmul <8 x float> %540, %551
  %.state590 = load <8 x float>, ptr %.slot69, align 32
  %553 = fadd <8 x float> %.state590, %552
  %.state591 = load <8 x i64>, ptr %.slot56, align 64
  %554 = add <8 x i64> splat (i64 200), %.state591
  %tile_snapshot.spill.load592 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %555 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load592, 0
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load592, 1
  %557 = mul <8 x i64> %554, splat (i64 32)
  %558 = add <8 x i64> %556, %557
  %559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %555, 0
  %560 = insertvalue { <8 x ptr>, <8 x i64> } %559, <8 x i64> %558, 1
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %560, 0
  %562 = extractvalue { <8 x ptr>, <8 x i64> } %560, 1
  %563 = getelementptr i8, <8 x ptr> %561, <8 x i64> %562
  %564 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %563, <8 x i1> %524, <8 x float> zeroinitializer)
  %565 = fmul <8 x float> %540, %564
  %.state593 = load <8 x float>, ptr %.slot70, align 32
  %566 = fadd <8 x float> %.state593, %565
  %.state594 = load <8 x i64>, ptr %.slot56, align 64
  %567 = add <8 x i64> splat (i64 240), %.state594
  %tile_snapshot.spill.load595 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %568 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load595, 0
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load595, 1
  %570 = mul <8 x i64> %567, splat (i64 32)
  %571 = add <8 x i64> %569, %570
  %572 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %568, 0
  %573 = insertvalue { <8 x ptr>, <8 x i64> } %572, <8 x i64> %571, 1
  %574 = extractvalue { <8 x ptr>, <8 x i64> } %573, 0
  %575 = extractvalue { <8 x ptr>, <8 x i64> } %573, 1
  %576 = getelementptr i8, <8 x ptr> %574, <8 x i64> %575
  %577 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %576, <8 x i1> %524, <8 x float> zeroinitializer)
  %578 = fmul <8 x float> %540, %577
  %.state596 = load <8 x float>, ptr %.slot71, align 32
  %579 = fadd <8 x float> %.state596, %578
  %.state597 = load <8 x i64>, ptr %.slot56, align 64
  %580 = add <8 x i64> splat (i64 280), %.state597
  %tile_snapshot.spill.load598 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load598, 0
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load598, 1
  %583 = mul <8 x i64> %580, splat (i64 32)
  %584 = add <8 x i64> %582, %583
  %585 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %581, 0
  %586 = insertvalue { <8 x ptr>, <8 x i64> } %585, <8 x i64> %584, 1
  %587 = extractvalue { <8 x ptr>, <8 x i64> } %586, 0
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %586, 1
  %589 = getelementptr i8, <8 x ptr> %587, <8 x i64> %588
  %590 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %589, <8 x i1> %524, <8 x float> zeroinitializer)
  %591 = fmul <8 x float> %540, %590
  %.state599 = load <8 x float>, ptr %.slot72, align 32
  %592 = fadd <8 x float> %.state599, %591
  %.state600 = load <8 x i64>, ptr %.slot56, align 64
  %593 = add <8 x i64> %.state600, splat (i64 1)
  %594 = load <8 x i64>, ptr %.slot56, align 64
  %595 = select <8 x i1> %524, <8 x i64> %593, <8 x i64> %594
  store <8 x i64> %595, ptr %.slot56, align 64
  %596 = load <8 x float>, ptr %.slot69, align 32
  %597 = select <8 x i1> %524, <8 x float> %553, <8 x float> %596
  store <8 x float> %597, ptr %.slot69, align 32
  %598 = load <8 x float>, ptr %.slot70, align 32
  %599 = select <8 x i1> %524, <8 x float> %566, <8 x float> %598
  store <8 x float> %599, ptr %.slot70, align 32
  %600 = load <8 x float>, ptr %.slot71, align 32
  %601 = select <8 x i1> %524, <8 x float> %579, <8 x float> %600
  store <8 x float> %601, ptr %.slot71, align 32
  %602 = load <8 x float>, ptr %.slot72, align 32
  %603 = select <8 x i1> %524, <8 x float> %592, <8 x float> %602
  store <8 x float> %603, ptr %.slot72, align 32
  store <8 x i1> %524, ptr %current.mask, align 1
  %604 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %524)
  br i1 %604, label %schedule.24, label %scheduler.loop

schedule.26:                                      ; preds = %varying.coherent.false585, %scheduler.dispatch.route
  %605 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token603 = load i32, ptr %current.token, align 4
  %convergence.token.present604 = icmp ne i32 %convergence.current.token603, 0
  br i1 %convergence.token.present604, label %convergence.cascade601, label %convergence.cascade.exit602

schedule.27:                                      ; preds = %schedule.28, %convergence.target.26.ready, %scheduler.dispatch.route
  %606 = load <8 x i1>, ptr %current.mask, align 1
  %607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %606)
  %608 = bitcast <8 x i1> %606 to i8
  %609 = call i8 @llvm.cttz.i8(i8 %608, i1 false)
  %610 = zext i8 %609 to i32
  %611 = select i1 %607, i32 %610, i32 0
  %.state618 = load <8 x i64>, ptr %.slot56, align 64
  %612 = icmp slt <8 x i64> %.state618, splat (i64 40)
  %613 = and <8 x i1> %606, %612
  %614 = xor <8 x i1> %612, splat (i1 true)
  %615 = and <8 x i1> %606, %614
  %616 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %613)
  %617 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %615)
  %618 = and i1 %616, %617
  br i1 %618, label %varying.divergent619, label %varying.coherent620

schedule.28:                                      ; preds = %varying.coherent.true625, %scheduler.dispatch.route
  %619 = load <8 x i1>, ptr %current.mask, align 1
  %620 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %619)
  %621 = bitcast <8 x i1> %619 to i8
  %622 = call i8 @llvm.cttz.i8(i8 %621, i1 false)
  %623 = zext i8 %622 to i32
  %624 = select i1 %620, i32 %623, i32 0
  %.state627 = load <8 x i64>, ptr %.slot56, align 64
  %625 = add <8 x i64> zeroinitializer, %.state627
  %tile_snapshot.spill.load628 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %626 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 0
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 1
  %628 = mul <8 x i64> %625, splat (i64 32)
  %629 = add <8 x i64> %627, %628
  %630 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %626, 0
  %631 = insertvalue { <8 x ptr>, <8 x i64> } %630, <8 x i64> %629, 1
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %631, 0
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %631, 1
  %634 = getelementptr i8, <8 x ptr> %632, <8 x i64> %633
  %635 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %634, <8 x i1> %619, <8 x float> zeroinitializer)
  %.state629 = load <8 x i64>, ptr %.slot56, align 64
  %636 = add <8 x i64> splat (i64 320), %.state629
  %tile_snapshot.spill.load630 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load630, 0
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load630, 1
  %639 = mul <8 x i64> %636, splat (i64 32)
  %640 = add <8 x i64> %638, %639
  %641 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %637, 0
  %642 = insertvalue { <8 x ptr>, <8 x i64> } %641, <8 x i64> %640, 1
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %642, 0
  %644 = extractvalue { <8 x ptr>, <8 x i64> } %642, 1
  %645 = getelementptr i8, <8 x ptr> %643, <8 x i64> %644
  %646 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %645, <8 x i1> %619, <8 x float> zeroinitializer)
  %647 = fmul <8 x float> %635, %646
  %.state631 = load <8 x float>, ptr %.slot74, align 32
  %648 = fadd <8 x float> %.state631, %647
  %.state632 = load <8 x i64>, ptr %.slot56, align 64
  %649 = add <8 x i64> splat (i64 360), %.state632
  %tile_snapshot.spill.load633 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %650 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load633, 0
  %651 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load633, 1
  %652 = mul <8 x i64> %649, splat (i64 32)
  %653 = add <8 x i64> %651, %652
  %654 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %650, 0
  %655 = insertvalue { <8 x ptr>, <8 x i64> } %654, <8 x i64> %653, 1
  %656 = extractvalue { <8 x ptr>, <8 x i64> } %655, 0
  %657 = extractvalue { <8 x ptr>, <8 x i64> } %655, 1
  %658 = getelementptr i8, <8 x ptr> %656, <8 x i64> %657
  %659 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %658, <8 x i1> %619, <8 x float> zeroinitializer)
  %660 = fmul <8 x float> %635, %659
  %.state634 = load <8 x float>, ptr %.slot75, align 32
  %661 = fadd <8 x float> %.state634, %660
  %.state635 = load <8 x i64>, ptr %.slot56, align 64
  %662 = add <8 x i64> splat (i64 400), %.state635
  %tile_snapshot.spill.load636 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load636, 0
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load636, 1
  %665 = mul <8 x i64> %662, splat (i64 32)
  %666 = add <8 x i64> %664, %665
  %667 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %663, 0
  %668 = insertvalue { <8 x ptr>, <8 x i64> } %667, <8 x i64> %666, 1
  %669 = extractvalue { <8 x ptr>, <8 x i64> } %668, 0
  %670 = extractvalue { <8 x ptr>, <8 x i64> } %668, 1
  %671 = getelementptr i8, <8 x ptr> %669, <8 x i64> %670
  %672 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %671, <8 x i1> %619, <8 x float> zeroinitializer)
  %673 = fmul <8 x float> %635, %672
  %.state637 = load <8 x float>, ptr %.slot76, align 32
  %674 = fadd <8 x float> %.state637, %673
  %.state638 = load <8 x i64>, ptr %.slot56, align 64
  %675 = add <8 x i64> splat (i64 440), %.state638
  %tile_snapshot.spill.load639 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %676 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load639, 0
  %677 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load639, 1
  %678 = mul <8 x i64> %675, splat (i64 32)
  %679 = add <8 x i64> %677, %678
  %680 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %676, 0
  %681 = insertvalue { <8 x ptr>, <8 x i64> } %680, <8 x i64> %679, 1
  %682 = extractvalue { <8 x ptr>, <8 x i64> } %681, 0
  %683 = extractvalue { <8 x ptr>, <8 x i64> } %681, 1
  %684 = getelementptr i8, <8 x ptr> %682, <8 x i64> %683
  %685 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %684, <8 x i1> %619, <8 x float> zeroinitializer)
  %686 = fmul <8 x float> %635, %685
  %.state640 = load <8 x float>, ptr %.slot77, align 32
  %687 = fadd <8 x float> %.state640, %686
  %.state641 = load <8 x i64>, ptr %.slot56, align 64
  %688 = add <8 x i64> %.state641, splat (i64 1)
  %689 = load <8 x i64>, ptr %.slot56, align 64
  %690 = select <8 x i1> %619, <8 x i64> %688, <8 x i64> %689
  store <8 x i64> %690, ptr %.slot56, align 64
  %691 = load <8 x float>, ptr %.slot74, align 32
  %692 = select <8 x i1> %619, <8 x float> %648, <8 x float> %691
  store <8 x float> %692, ptr %.slot74, align 32
  %693 = load <8 x float>, ptr %.slot75, align 32
  %694 = select <8 x i1> %619, <8 x float> %661, <8 x float> %693
  store <8 x float> %694, ptr %.slot75, align 32
  %695 = load <8 x float>, ptr %.slot76, align 32
  %696 = select <8 x i1> %619, <8 x float> %674, <8 x float> %695
  store <8 x float> %696, ptr %.slot76, align 32
  %697 = load <8 x float>, ptr %.slot77, align 32
  %698 = select <8 x i1> %619, <8 x float> %687, <8 x float> %697
  store <8 x float> %698, ptr %.slot77, align 32
  store <8 x i1> %619, ptr %current.mask, align 1
  %699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %619)
  br i1 %699, label %schedule.27, label %scheduler.loop

schedule.29:                                      ; preds = %varying.coherent.false626, %scheduler.dispatch.route
  %700 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token644 = load i32, ptr %current.token, align 4
  %convergence.token.present645 = icmp ne i32 %convergence.current.token644, 0
  br i1 %convergence.token.present645, label %convergence.cascade642, label %convergence.cascade.exit643

schedule.30:                                      ; preds = %schedule.31, %convergence.target.29.ready, %scheduler.dispatch.route
  %701 = load <8 x i1>, ptr %current.mask, align 1
  %702 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %701)
  %703 = bitcast <8 x i1> %701 to i8
  %704 = call i8 @llvm.cttz.i8(i8 %703, i1 false)
  %705 = zext i8 %704 to i32
  %706 = select i1 %702, i32 %705, i32 0
  %.state659 = load <8 x i64>, ptr %.slot56, align 64
  %707 = icmp slt <8 x i64> %.state659, splat (i64 40)
  %708 = and <8 x i1> %701, %707
  %709 = xor <8 x i1> %707, splat (i1 true)
  %710 = and <8 x i1> %701, %709
  %711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %708)
  %712 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %710)
  %713 = and i1 %711, %712
  br i1 %713, label %varying.divergent660, label %varying.coherent661

schedule.31:                                      ; preds = %varying.coherent.true666, %scheduler.dispatch.route
  %714 = load <8 x i1>, ptr %current.mask, align 1
  %715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %714)
  %716 = bitcast <8 x i1> %714 to i8
  %717 = call i8 @llvm.cttz.i8(i8 %716, i1 false)
  %718 = zext i8 %717 to i32
  %719 = select i1 %715, i32 %718, i32 0
  %.state668 = load <8 x i64>, ptr %.slot56, align 64
  %720 = add <8 x i64> zeroinitializer, %.state668
  %tile_snapshot.spill.load669 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %721 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load669, 0
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load669, 1
  %723 = mul <8 x i64> %720, splat (i64 32)
  %724 = add <8 x i64> %722, %723
  %725 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %721, 0
  %726 = insertvalue { <8 x ptr>, <8 x i64> } %725, <8 x i64> %724, 1
  %727 = extractvalue { <8 x ptr>, <8 x i64> } %726, 0
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %726, 1
  %729 = getelementptr i8, <8 x ptr> %727, <8 x i64> %728
  %730 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %729, <8 x i1> %714, <8 x float> zeroinitializer)
  %.state670 = load <8 x i64>, ptr %.slot56, align 64
  %731 = add <8 x i64> splat (i64 480), %.state670
  %tile_snapshot.spill.load671 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %732 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load671, 0
  %733 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load671, 1
  %734 = mul <8 x i64> %731, splat (i64 32)
  %735 = add <8 x i64> %733, %734
  %736 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %732, 0
  %737 = insertvalue { <8 x ptr>, <8 x i64> } %736, <8 x i64> %735, 1
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %737, 0
  %739 = extractvalue { <8 x ptr>, <8 x i64> } %737, 1
  %740 = getelementptr i8, <8 x ptr> %738, <8 x i64> %739
  %741 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %740, <8 x i1> %714, <8 x float> zeroinitializer)
  %742 = fmul <8 x float> %730, %741
  %.state672 = load <8 x float>, ptr %.slot79, align 32
  %743 = fadd <8 x float> %.state672, %742
  %.state673 = load <8 x i64>, ptr %.slot56, align 64
  %744 = add <8 x i64> splat (i64 520), %.state673
  %tile_snapshot.spill.load674 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %745 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load674, 0
  %746 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load674, 1
  %747 = mul <8 x i64> %744, splat (i64 32)
  %748 = add <8 x i64> %746, %747
  %749 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %745, 0
  %750 = insertvalue { <8 x ptr>, <8 x i64> } %749, <8 x i64> %748, 1
  %751 = extractvalue { <8 x ptr>, <8 x i64> } %750, 0
  %752 = extractvalue { <8 x ptr>, <8 x i64> } %750, 1
  %753 = getelementptr i8, <8 x ptr> %751, <8 x i64> %752
  %754 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %753, <8 x i1> %714, <8 x float> zeroinitializer)
  %755 = fmul <8 x float> %730, %754
  %.state675 = load <8 x float>, ptr %.slot80, align 32
  %756 = fadd <8 x float> %.state675, %755
  %.state676 = load <8 x i64>, ptr %.slot56, align 64
  %757 = add <8 x i64> splat (i64 560), %.state676
  %tile_snapshot.spill.load677 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %758 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load677, 0
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load677, 1
  %760 = mul <8 x i64> %757, splat (i64 32)
  %761 = add <8 x i64> %759, %760
  %762 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %758, 0
  %763 = insertvalue { <8 x ptr>, <8 x i64> } %762, <8 x i64> %761, 1
  %764 = extractvalue { <8 x ptr>, <8 x i64> } %763, 0
  %765 = extractvalue { <8 x ptr>, <8 x i64> } %763, 1
  %766 = getelementptr i8, <8 x ptr> %764, <8 x i64> %765
  %767 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %766, <8 x i1> %714, <8 x float> zeroinitializer)
  %768 = fmul <8 x float> %730, %767
  %.state678 = load <8 x float>, ptr %.slot81, align 32
  %769 = fadd <8 x float> %.state678, %768
  %.state679 = load <8 x i64>, ptr %.slot56, align 64
  %770 = add <8 x i64> splat (i64 600), %.state679
  %tile_snapshot.spill.load680 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %771 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load680, 0
  %772 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load680, 1
  %773 = mul <8 x i64> %770, splat (i64 32)
  %774 = add <8 x i64> %772, %773
  %775 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %771, 0
  %776 = insertvalue { <8 x ptr>, <8 x i64> } %775, <8 x i64> %774, 1
  %777 = extractvalue { <8 x ptr>, <8 x i64> } %776, 0
  %778 = extractvalue { <8 x ptr>, <8 x i64> } %776, 1
  %779 = getelementptr i8, <8 x ptr> %777, <8 x i64> %778
  %780 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %779, <8 x i1> %714, <8 x float> zeroinitializer)
  %781 = fmul <8 x float> %730, %780
  %.state681 = load <8 x float>, ptr %.slot82, align 32
  %782 = fadd <8 x float> %.state681, %781
  %.state682 = load <8 x i64>, ptr %.slot56, align 64
  %783 = add <8 x i64> %.state682, splat (i64 1)
  %784 = load <8 x i64>, ptr %.slot56, align 64
  %785 = select <8 x i1> %714, <8 x i64> %783, <8 x i64> %784
  store <8 x i64> %785, ptr %.slot56, align 64
  %786 = load <8 x float>, ptr %.slot79, align 32
  %787 = select <8 x i1> %714, <8 x float> %743, <8 x float> %786
  store <8 x float> %787, ptr %.slot79, align 32
  %788 = load <8 x float>, ptr %.slot80, align 32
  %789 = select <8 x i1> %714, <8 x float> %756, <8 x float> %788
  store <8 x float> %789, ptr %.slot80, align 32
  %790 = load <8 x float>, ptr %.slot81, align 32
  %791 = select <8 x i1> %714, <8 x float> %769, <8 x float> %790
  store <8 x float> %791, ptr %.slot81, align 32
  %792 = load <8 x float>, ptr %.slot82, align 32
  %793 = select <8 x i1> %714, <8 x float> %782, <8 x float> %792
  store <8 x float> %793, ptr %.slot82, align 32
  store <8 x i1> %714, ptr %current.mask, align 1
  %794 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %714)
  br i1 %794, label %schedule.30, label %scheduler.loop

schedule.32:                                      ; preds = %varying.coherent.false667, %scheduler.dispatch.route
  %795 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token685 = load i32, ptr %current.token, align 4
  %convergence.token.present686 = icmp ne i32 %convergence.current.token685, 0
  br i1 %convergence.token.present686, label %convergence.cascade683, label %convergence.cascade.exit684

schedule.33:                                      ; preds = %schedule.34, %convergence.target.32.ready, %scheduler.dispatch.route
  %796 = load <8 x i1>, ptr %current.mask, align 1
  %797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %796)
  %798 = bitcast <8 x i1> %796 to i8
  %799 = call i8 @llvm.cttz.i8(i8 %798, i1 false)
  %800 = zext i8 %799 to i32
  %801 = select i1 %797, i32 %800, i32 0
  %.state700 = load <8 x i64>, ptr %.slot56, align 64
  %802 = icmp slt <8 x i64> %.state700, splat (i64 40)
  %803 = and <8 x i1> %796, %802
  %804 = xor <8 x i1> %802, splat (i1 true)
  %805 = and <8 x i1> %796, %804
  %806 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %803)
  %807 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %805)
  %808 = and i1 %806, %807
  br i1 %808, label %varying.divergent701, label %varying.coherent702

schedule.34:                                      ; preds = %varying.coherent.true707, %scheduler.dispatch.route
  %809 = load <8 x i1>, ptr %current.mask, align 1
  %810 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %809)
  %811 = bitcast <8 x i1> %809 to i8
  %812 = call i8 @llvm.cttz.i8(i8 %811, i1 false)
  %813 = zext i8 %812 to i32
  %814 = select i1 %810, i32 %813, i32 0
  %.state709 = load <8 x i64>, ptr %.slot56, align 64
  %815 = add <8 x i64> splat (i64 40), %.state709
  %tile_snapshot.spill.load710 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %816 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load710, 0
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load710, 1
  %818 = mul <8 x i64> %815, splat (i64 32)
  %819 = add <8 x i64> %817, %818
  %820 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %816, 0
  %821 = insertvalue { <8 x ptr>, <8 x i64> } %820, <8 x i64> %819, 1
  %822 = extractvalue { <8 x ptr>, <8 x i64> } %821, 0
  %823 = extractvalue { <8 x ptr>, <8 x i64> } %821, 1
  %824 = getelementptr i8, <8 x ptr> %822, <8 x i64> %823
  %825 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %824, <8 x i1> %809, <8 x float> zeroinitializer)
  %.state711 = load <8 x i64>, ptr %.slot56, align 64
  %826 = add <8 x i64> zeroinitializer, %.state711
  %tile_snapshot.spill.load712 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load712, 0
  %828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load712, 1
  %829 = mul <8 x i64> %826, splat (i64 32)
  %830 = add <8 x i64> %828, %829
  %831 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %827, 0
  %832 = insertvalue { <8 x ptr>, <8 x i64> } %831, <8 x i64> %830, 1
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %832, 0
  %834 = extractvalue { <8 x ptr>, <8 x i64> } %832, 1
  %835 = getelementptr i8, <8 x ptr> %833, <8 x i64> %834
  %836 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %835, <8 x i1> %809, <8 x float> zeroinitializer)
  %837 = fmul <8 x float> %825, %836
  %.state713 = load <8 x float>, ptr %.slot84, align 32
  %838 = fadd <8 x float> %.state713, %837
  %tile_snapshot.spill.load714 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load714, 0
  %840 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load714, 1
  %841 = mul <8 x i64> %815, splat (i64 32)
  %842 = add <8 x i64> %840, %841
  %843 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %839, 0
  %844 = insertvalue { <8 x ptr>, <8 x i64> } %843, <8 x i64> %842, 1
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %844, 0
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %844, 1
  %847 = getelementptr i8, <8 x ptr> %845, <8 x i64> %846
  %848 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %847, <8 x i1> %809, <8 x float> zeroinitializer)
  %849 = fmul <8 x float> %825, %848
  %.state715 = load <8 x float>, ptr %.slot85, align 32
  %850 = fadd <8 x float> %.state715, %849
  %.state716 = load <8 x i64>, ptr %.slot56, align 64
  %851 = add <8 x i64> splat (i64 80), %.state716
  %tile_snapshot.spill.load717 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load717, 0
  %853 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load717, 1
  %854 = mul <8 x i64> %851, splat (i64 32)
  %855 = add <8 x i64> %853, %854
  %856 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %852, 0
  %857 = insertvalue { <8 x ptr>, <8 x i64> } %856, <8 x i64> %855, 1
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %857, 0
  %859 = extractvalue { <8 x ptr>, <8 x i64> } %857, 1
  %860 = getelementptr i8, <8 x ptr> %858, <8 x i64> %859
  %861 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %860, <8 x i1> %809, <8 x float> zeroinitializer)
  %862 = fmul <8 x float> %825, %861
  %.state718 = load <8 x float>, ptr %.slot86, align 32
  %863 = fadd <8 x float> %.state718, %862
  %.state719 = load <8 x i64>, ptr %.slot56, align 64
  %864 = add <8 x i64> splat (i64 120), %.state719
  %tile_snapshot.spill.load720 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load720, 0
  %866 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load720, 1
  %867 = mul <8 x i64> %864, splat (i64 32)
  %868 = add <8 x i64> %866, %867
  %869 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %865, 0
  %870 = insertvalue { <8 x ptr>, <8 x i64> } %869, <8 x i64> %868, 1
  %871 = extractvalue { <8 x ptr>, <8 x i64> } %870, 0
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %870, 1
  %873 = getelementptr i8, <8 x ptr> %871, <8 x i64> %872
  %874 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %873, <8 x i1> %809, <8 x float> zeroinitializer)
  %875 = fmul <8 x float> %825, %874
  %.state721 = load <8 x float>, ptr %.slot87, align 32
  %876 = fadd <8 x float> %.state721, %875
  %.state722 = load <8 x i64>, ptr %.slot56, align 64
  %877 = add <8 x i64> %.state722, splat (i64 1)
  %878 = load <8 x i64>, ptr %.slot56, align 64
  %879 = select <8 x i1> %809, <8 x i64> %877, <8 x i64> %878
  store <8 x i64> %879, ptr %.slot56, align 64
  %880 = load <8 x float>, ptr %.slot84, align 32
  %881 = select <8 x i1> %809, <8 x float> %838, <8 x float> %880
  store <8 x float> %881, ptr %.slot84, align 32
  %882 = load <8 x float>, ptr %.slot85, align 32
  %883 = select <8 x i1> %809, <8 x float> %850, <8 x float> %882
  store <8 x float> %883, ptr %.slot85, align 32
  %884 = load <8 x float>, ptr %.slot86, align 32
  %885 = select <8 x i1> %809, <8 x float> %863, <8 x float> %884
  store <8 x float> %885, ptr %.slot86, align 32
  %886 = load <8 x float>, ptr %.slot87, align 32
  %887 = select <8 x i1> %809, <8 x float> %876, <8 x float> %886
  store <8 x float> %887, ptr %.slot87, align 32
  store <8 x i1> %809, ptr %current.mask, align 1
  %888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %809)
  br i1 %888, label %schedule.33, label %scheduler.loop

schedule.35:                                      ; preds = %varying.coherent.false708, %scheduler.dispatch.route
  %889 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token725 = load i32, ptr %current.token, align 4
  %convergence.token.present726 = icmp ne i32 %convergence.current.token725, 0
  br i1 %convergence.token.present726, label %convergence.cascade723, label %convergence.cascade.exit724

schedule.36:                                      ; preds = %schedule.37, %convergence.target.35.ready, %scheduler.dispatch.route
  %890 = load <8 x i1>, ptr %current.mask, align 1
  %891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %890)
  %892 = bitcast <8 x i1> %890 to i8
  %893 = call i8 @llvm.cttz.i8(i8 %892, i1 false)
  %894 = zext i8 %893 to i32
  %895 = select i1 %891, i32 %894, i32 0
  %.state740 = load <8 x i64>, ptr %.slot56, align 64
  %896 = icmp slt <8 x i64> %.state740, splat (i64 40)
  %897 = and <8 x i1> %890, %896
  %898 = xor <8 x i1> %896, splat (i1 true)
  %899 = and <8 x i1> %890, %898
  %900 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %897)
  %901 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %899)
  %902 = and i1 %900, %901
  br i1 %902, label %varying.divergent741, label %varying.coherent742

schedule.37:                                      ; preds = %varying.coherent.true747, %scheduler.dispatch.route
  %903 = load <8 x i1>, ptr %current.mask, align 1
  %904 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %903)
  %905 = bitcast <8 x i1> %903 to i8
  %906 = call i8 @llvm.cttz.i8(i8 %905, i1 false)
  %907 = zext i8 %906 to i32
  %908 = select i1 %904, i32 %907, i32 0
  %.state749 = load <8 x i64>, ptr %.slot56, align 64
  %909 = add <8 x i64> splat (i64 40), %.state749
  %tile_snapshot.spill.load750 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %910 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load750, 0
  %911 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load750, 1
  %912 = mul <8 x i64> %909, splat (i64 32)
  %913 = add <8 x i64> %911, %912
  %914 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %910, 0
  %915 = insertvalue { <8 x ptr>, <8 x i64> } %914, <8 x i64> %913, 1
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %915, 0
  %917 = extractvalue { <8 x ptr>, <8 x i64> } %915, 1
  %918 = getelementptr i8, <8 x ptr> %916, <8 x i64> %917
  %919 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %918, <8 x i1> %903, <8 x float> zeroinitializer)
  %.state751 = load <8 x i64>, ptr %.slot56, align 64
  %920 = add <8 x i64> splat (i64 160), %.state751
  %tile_snapshot.spill.load752 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load752, 0
  %922 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load752, 1
  %923 = mul <8 x i64> %920, splat (i64 32)
  %924 = add <8 x i64> %922, %923
  %925 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %921, 0
  %926 = insertvalue { <8 x ptr>, <8 x i64> } %925, <8 x i64> %924, 1
  %927 = extractvalue { <8 x ptr>, <8 x i64> } %926, 0
  %928 = extractvalue { <8 x ptr>, <8 x i64> } %926, 1
  %929 = getelementptr i8, <8 x ptr> %927, <8 x i64> %928
  %930 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %929, <8 x i1> %903, <8 x float> zeroinitializer)
  %931 = fmul <8 x float> %919, %930
  %.state753 = load <8 x float>, ptr %.slot89, align 32
  %932 = fadd <8 x float> %.state753, %931
  %.state754 = load <8 x i64>, ptr %.slot56, align 64
  %933 = add <8 x i64> splat (i64 200), %.state754
  %tile_snapshot.spill.load755 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %934 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load755, 0
  %935 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load755, 1
  %936 = mul <8 x i64> %933, splat (i64 32)
  %937 = add <8 x i64> %935, %936
  %938 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %934, 0
  %939 = insertvalue { <8 x ptr>, <8 x i64> } %938, <8 x i64> %937, 1
  %940 = extractvalue { <8 x ptr>, <8 x i64> } %939, 0
  %941 = extractvalue { <8 x ptr>, <8 x i64> } %939, 1
  %942 = getelementptr i8, <8 x ptr> %940, <8 x i64> %941
  %943 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %942, <8 x i1> %903, <8 x float> zeroinitializer)
  %944 = fmul <8 x float> %919, %943
  %.state756 = load <8 x float>, ptr %.slot90, align 32
  %945 = fadd <8 x float> %.state756, %944
  %.state757 = load <8 x i64>, ptr %.slot56, align 64
  %946 = add <8 x i64> splat (i64 240), %.state757
  %tile_snapshot.spill.load758 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %947 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load758, 0
  %948 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load758, 1
  %949 = mul <8 x i64> %946, splat (i64 32)
  %950 = add <8 x i64> %948, %949
  %951 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %947, 0
  %952 = insertvalue { <8 x ptr>, <8 x i64> } %951, <8 x i64> %950, 1
  %953 = extractvalue { <8 x ptr>, <8 x i64> } %952, 0
  %954 = extractvalue { <8 x ptr>, <8 x i64> } %952, 1
  %955 = getelementptr i8, <8 x ptr> %953, <8 x i64> %954
  %956 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %955, <8 x i1> %903, <8 x float> zeroinitializer)
  %957 = fmul <8 x float> %919, %956
  %.state759 = load <8 x float>, ptr %.slot91, align 32
  %958 = fadd <8 x float> %.state759, %957
  %.state760 = load <8 x i64>, ptr %.slot56, align 64
  %959 = add <8 x i64> splat (i64 280), %.state760
  %tile_snapshot.spill.load761 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %960 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load761, 0
  %961 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load761, 1
  %962 = mul <8 x i64> %959, splat (i64 32)
  %963 = add <8 x i64> %961, %962
  %964 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %960, 0
  %965 = insertvalue { <8 x ptr>, <8 x i64> } %964, <8 x i64> %963, 1
  %966 = extractvalue { <8 x ptr>, <8 x i64> } %965, 0
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %965, 1
  %968 = getelementptr i8, <8 x ptr> %966, <8 x i64> %967
  %969 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %968, <8 x i1> %903, <8 x float> zeroinitializer)
  %970 = fmul <8 x float> %919, %969
  %.state762 = load <8 x float>, ptr %.slot92, align 32
  %971 = fadd <8 x float> %.state762, %970
  %.state763 = load <8 x i64>, ptr %.slot56, align 64
  %972 = add <8 x i64> %.state763, splat (i64 1)
  %973 = load <8 x i64>, ptr %.slot56, align 64
  %974 = select <8 x i1> %903, <8 x i64> %972, <8 x i64> %973
  store <8 x i64> %974, ptr %.slot56, align 64
  %975 = load <8 x float>, ptr %.slot89, align 32
  %976 = select <8 x i1> %903, <8 x float> %932, <8 x float> %975
  store <8 x float> %976, ptr %.slot89, align 32
  %977 = load <8 x float>, ptr %.slot90, align 32
  %978 = select <8 x i1> %903, <8 x float> %945, <8 x float> %977
  store <8 x float> %978, ptr %.slot90, align 32
  %979 = load <8 x float>, ptr %.slot91, align 32
  %980 = select <8 x i1> %903, <8 x float> %958, <8 x float> %979
  store <8 x float> %980, ptr %.slot91, align 32
  %981 = load <8 x float>, ptr %.slot92, align 32
  %982 = select <8 x i1> %903, <8 x float> %971, <8 x float> %981
  store <8 x float> %982, ptr %.slot92, align 32
  store <8 x i1> %903, ptr %current.mask, align 1
  %983 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %903)
  br i1 %983, label %schedule.36, label %scheduler.loop

schedule.38:                                      ; preds = %varying.coherent.false748, %scheduler.dispatch.route
  %984 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token766 = load i32, ptr %current.token, align 4
  %convergence.token.present767 = icmp ne i32 %convergence.current.token766, 0
  br i1 %convergence.token.present767, label %convergence.cascade764, label %convergence.cascade.exit765

schedule.39:                                      ; preds = %schedule.40, %convergence.target.38.ready, %scheduler.dispatch.route
  %985 = load <8 x i1>, ptr %current.mask, align 1
  %986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %985)
  %987 = bitcast <8 x i1> %985 to i8
  %988 = call i8 @llvm.cttz.i8(i8 %987, i1 false)
  %989 = zext i8 %988 to i32
  %990 = select i1 %986, i32 %989, i32 0
  %.state781 = load <8 x i64>, ptr %.slot56, align 64
  %991 = icmp slt <8 x i64> %.state781, splat (i64 40)
  %992 = and <8 x i1> %985, %991
  %993 = xor <8 x i1> %991, splat (i1 true)
  %994 = and <8 x i1> %985, %993
  %995 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %992)
  %996 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %994)
  %997 = and i1 %995, %996
  br i1 %997, label %varying.divergent782, label %varying.coherent783

schedule.40:                                      ; preds = %varying.coherent.true788, %scheduler.dispatch.route
  %998 = load <8 x i1>, ptr %current.mask, align 1
  %999 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %998)
  %1000 = bitcast <8 x i1> %998 to i8
  %1001 = call i8 @llvm.cttz.i8(i8 %1000, i1 false)
  %1002 = zext i8 %1001 to i32
  %1003 = select i1 %999, i32 %1002, i32 0
  %.state790 = load <8 x i64>, ptr %.slot56, align 64
  %1004 = add <8 x i64> splat (i64 40), %.state790
  %tile_snapshot.spill.load791 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load791, 0
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load791, 1
  %1007 = mul <8 x i64> %1004, splat (i64 32)
  %1008 = add <8 x i64> %1006, %1007
  %1009 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1005, 0
  %1010 = insertvalue { <8 x ptr>, <8 x i64> } %1009, <8 x i64> %1008, 1
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %1010, 0
  %1012 = extractvalue { <8 x ptr>, <8 x i64> } %1010, 1
  %1013 = getelementptr i8, <8 x ptr> %1011, <8 x i64> %1012
  %1014 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1013, <8 x i1> %998, <8 x float> zeroinitializer)
  %.state792 = load <8 x i64>, ptr %.slot56, align 64
  %1015 = add <8 x i64> splat (i64 320), %.state792
  %tile_snapshot.spill.load793 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load793, 0
  %1017 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load793, 1
  %1018 = mul <8 x i64> %1015, splat (i64 32)
  %1019 = add <8 x i64> %1017, %1018
  %1020 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1016, 0
  %1021 = insertvalue { <8 x ptr>, <8 x i64> } %1020, <8 x i64> %1019, 1
  %1022 = extractvalue { <8 x ptr>, <8 x i64> } %1021, 0
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %1021, 1
  %1024 = getelementptr i8, <8 x ptr> %1022, <8 x i64> %1023
  %1025 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1024, <8 x i1> %998, <8 x float> zeroinitializer)
  %1026 = fmul <8 x float> %1014, %1025
  %.state794 = load <8 x float>, ptr %.slot94, align 32
  %1027 = fadd <8 x float> %.state794, %1026
  %.state795 = load <8 x i64>, ptr %.slot56, align 64
  %1028 = add <8 x i64> splat (i64 360), %.state795
  %tile_snapshot.spill.load796 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load796, 0
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load796, 1
  %1031 = mul <8 x i64> %1028, splat (i64 32)
  %1032 = add <8 x i64> %1030, %1031
  %1033 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1029, 0
  %1034 = insertvalue { <8 x ptr>, <8 x i64> } %1033, <8 x i64> %1032, 1
  %1035 = extractvalue { <8 x ptr>, <8 x i64> } %1034, 0
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %1034, 1
  %1037 = getelementptr i8, <8 x ptr> %1035, <8 x i64> %1036
  %1038 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1037, <8 x i1> %998, <8 x float> zeroinitializer)
  %1039 = fmul <8 x float> %1014, %1038
  %.state797 = load <8 x float>, ptr %.slot95, align 32
  %1040 = fadd <8 x float> %.state797, %1039
  %.state798 = load <8 x i64>, ptr %.slot56, align 64
  %1041 = add <8 x i64> splat (i64 400), %.state798
  %tile_snapshot.spill.load799 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load799, 0
  %1043 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load799, 1
  %1044 = mul <8 x i64> %1041, splat (i64 32)
  %1045 = add <8 x i64> %1043, %1044
  %1046 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1042, 0
  %1047 = insertvalue { <8 x ptr>, <8 x i64> } %1046, <8 x i64> %1045, 1
  %1048 = extractvalue { <8 x ptr>, <8 x i64> } %1047, 0
  %1049 = extractvalue { <8 x ptr>, <8 x i64> } %1047, 1
  %1050 = getelementptr i8, <8 x ptr> %1048, <8 x i64> %1049
  %1051 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1050, <8 x i1> %998, <8 x float> zeroinitializer)
  %1052 = fmul <8 x float> %1014, %1051
  %.state800 = load <8 x float>, ptr %.slot96, align 32
  %1053 = fadd <8 x float> %.state800, %1052
  %.state801 = load <8 x i64>, ptr %.slot56, align 64
  %1054 = add <8 x i64> splat (i64 440), %.state801
  %tile_snapshot.spill.load802 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load802, 0
  %1056 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load802, 1
  %1057 = mul <8 x i64> %1054, splat (i64 32)
  %1058 = add <8 x i64> %1056, %1057
  %1059 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1055, 0
  %1060 = insertvalue { <8 x ptr>, <8 x i64> } %1059, <8 x i64> %1058, 1
  %1061 = extractvalue { <8 x ptr>, <8 x i64> } %1060, 0
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %1060, 1
  %1063 = getelementptr i8, <8 x ptr> %1061, <8 x i64> %1062
  %1064 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1063, <8 x i1> %998, <8 x float> zeroinitializer)
  %1065 = fmul <8 x float> %1014, %1064
  %.state803 = load <8 x float>, ptr %.slot97, align 32
  %1066 = fadd <8 x float> %.state803, %1065
  %.state804 = load <8 x i64>, ptr %.slot56, align 64
  %1067 = add <8 x i64> %.state804, splat (i64 1)
  %1068 = load <8 x i64>, ptr %.slot56, align 64
  %1069 = select <8 x i1> %998, <8 x i64> %1067, <8 x i64> %1068
  store <8 x i64> %1069, ptr %.slot56, align 64
  %1070 = load <8 x float>, ptr %.slot94, align 32
  %1071 = select <8 x i1> %998, <8 x float> %1027, <8 x float> %1070
  store <8 x float> %1071, ptr %.slot94, align 32
  %1072 = load <8 x float>, ptr %.slot95, align 32
  %1073 = select <8 x i1> %998, <8 x float> %1040, <8 x float> %1072
  store <8 x float> %1073, ptr %.slot95, align 32
  %1074 = load <8 x float>, ptr %.slot96, align 32
  %1075 = select <8 x i1> %998, <8 x float> %1053, <8 x float> %1074
  store <8 x float> %1075, ptr %.slot96, align 32
  %1076 = load <8 x float>, ptr %.slot97, align 32
  %1077 = select <8 x i1> %998, <8 x float> %1066, <8 x float> %1076
  store <8 x float> %1077, ptr %.slot97, align 32
  store <8 x i1> %998, ptr %current.mask, align 1
  %1078 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %998)
  br i1 %1078, label %schedule.39, label %scheduler.loop

schedule.41:                                      ; preds = %varying.coherent.false789, %scheduler.dispatch.route
  %1079 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token807 = load i32, ptr %current.token, align 4
  %convergence.token.present808 = icmp ne i32 %convergence.current.token807, 0
  br i1 %convergence.token.present808, label %convergence.cascade805, label %convergence.cascade.exit806

schedule.42:                                      ; preds = %schedule.43, %convergence.target.41.ready, %scheduler.dispatch.route
  %1080 = load <8 x i1>, ptr %current.mask, align 1
  %1081 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1080)
  %1082 = bitcast <8 x i1> %1080 to i8
  %1083 = call i8 @llvm.cttz.i8(i8 %1082, i1 false)
  %1084 = zext i8 %1083 to i32
  %1085 = select i1 %1081, i32 %1084, i32 0
  %.state822 = load <8 x i64>, ptr %.slot56, align 64
  %1086 = icmp slt <8 x i64> %.state822, splat (i64 40)
  %1087 = and <8 x i1> %1080, %1086
  %1088 = xor <8 x i1> %1086, splat (i1 true)
  %1089 = and <8 x i1> %1080, %1088
  %1090 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1087)
  %1091 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1089)
  %1092 = and i1 %1090, %1091
  br i1 %1092, label %varying.divergent823, label %varying.coherent824

schedule.43:                                      ; preds = %varying.coherent.true829, %scheduler.dispatch.route
  %1093 = load <8 x i1>, ptr %current.mask, align 1
  %1094 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1093)
  %1095 = bitcast <8 x i1> %1093 to i8
  %1096 = call i8 @llvm.cttz.i8(i8 %1095, i1 false)
  %1097 = zext i8 %1096 to i32
  %1098 = select i1 %1094, i32 %1097, i32 0
  %.state831 = load <8 x i64>, ptr %.slot56, align 64
  %1099 = add <8 x i64> splat (i64 40), %.state831
  %tile_snapshot.spill.load832 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1100 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load832, 0
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load832, 1
  %1102 = mul <8 x i64> %1099, splat (i64 32)
  %1103 = add <8 x i64> %1101, %1102
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1100, 0
  %1105 = insertvalue { <8 x ptr>, <8 x i64> } %1104, <8 x i64> %1103, 1
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %1105, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %1105, 1
  %1108 = getelementptr i8, <8 x ptr> %1106, <8 x i64> %1107
  %1109 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1108, <8 x i1> %1093, <8 x float> zeroinitializer)
  %.state833 = load <8 x i64>, ptr %.slot56, align 64
  %1110 = add <8 x i64> splat (i64 480), %.state833
  %tile_snapshot.spill.load834 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load834, 0
  %1112 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load834, 1
  %1113 = mul <8 x i64> %1110, splat (i64 32)
  %1114 = add <8 x i64> %1112, %1113
  %1115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1111, 0
  %1116 = insertvalue { <8 x ptr>, <8 x i64> } %1115, <8 x i64> %1114, 1
  %1117 = extractvalue { <8 x ptr>, <8 x i64> } %1116, 0
  %1118 = extractvalue { <8 x ptr>, <8 x i64> } %1116, 1
  %1119 = getelementptr i8, <8 x ptr> %1117, <8 x i64> %1118
  %1120 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1119, <8 x i1> %1093, <8 x float> zeroinitializer)
  %1121 = fmul <8 x float> %1109, %1120
  %.state835 = load <8 x float>, ptr %.slot99, align 32
  %1122 = fadd <8 x float> %.state835, %1121
  %.state836 = load <8 x i64>, ptr %.slot56, align 64
  %1123 = add <8 x i64> splat (i64 520), %.state836
  %tile_snapshot.spill.load837 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1124 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load837, 0
  %1125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load837, 1
  %1126 = mul <8 x i64> %1123, splat (i64 32)
  %1127 = add <8 x i64> %1125, %1126
  %1128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1124, 0
  %1129 = insertvalue { <8 x ptr>, <8 x i64> } %1128, <8 x i64> %1127, 1
  %1130 = extractvalue { <8 x ptr>, <8 x i64> } %1129, 0
  %1131 = extractvalue { <8 x ptr>, <8 x i64> } %1129, 1
  %1132 = getelementptr i8, <8 x ptr> %1130, <8 x i64> %1131
  %1133 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1132, <8 x i1> %1093, <8 x float> zeroinitializer)
  %1134 = fmul <8 x float> %1109, %1133
  %.state838 = load <8 x float>, ptr %.slot100, align 32
  %1135 = fadd <8 x float> %.state838, %1134
  %.state839 = load <8 x i64>, ptr %.slot56, align 64
  %1136 = add <8 x i64> splat (i64 560), %.state839
  %tile_snapshot.spill.load840 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load840, 0
  %1138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load840, 1
  %1139 = mul <8 x i64> %1136, splat (i64 32)
  %1140 = add <8 x i64> %1138, %1139
  %1141 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1137, 0
  %1142 = insertvalue { <8 x ptr>, <8 x i64> } %1141, <8 x i64> %1140, 1
  %1143 = extractvalue { <8 x ptr>, <8 x i64> } %1142, 0
  %1144 = extractvalue { <8 x ptr>, <8 x i64> } %1142, 1
  %1145 = getelementptr i8, <8 x ptr> %1143, <8 x i64> %1144
  %1146 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1145, <8 x i1> %1093, <8 x float> zeroinitializer)
  %1147 = fmul <8 x float> %1109, %1146
  %.state841 = load <8 x float>, ptr %.slot101, align 32
  %1148 = fadd <8 x float> %.state841, %1147
  %.state842 = load <8 x i64>, ptr %.slot56, align 64
  %1149 = add <8 x i64> splat (i64 600), %.state842
  %tile_snapshot.spill.load843 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load843, 0
  %1151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load843, 1
  %1152 = mul <8 x i64> %1149, splat (i64 32)
  %1153 = add <8 x i64> %1151, %1152
  %1154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1150, 0
  %1155 = insertvalue { <8 x ptr>, <8 x i64> } %1154, <8 x i64> %1153, 1
  %1156 = extractvalue { <8 x ptr>, <8 x i64> } %1155, 0
  %1157 = extractvalue { <8 x ptr>, <8 x i64> } %1155, 1
  %1158 = getelementptr i8, <8 x ptr> %1156, <8 x i64> %1157
  %1159 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1158, <8 x i1> %1093, <8 x float> zeroinitializer)
  %1160 = fmul <8 x float> %1109, %1159
  %.state844 = load <8 x float>, ptr %.slot102, align 32
  %1161 = fadd <8 x float> %.state844, %1160
  %.state845 = load <8 x i64>, ptr %.slot56, align 64
  %1162 = add <8 x i64> %.state845, splat (i64 1)
  %1163 = load <8 x i64>, ptr %.slot56, align 64
  %1164 = select <8 x i1> %1093, <8 x i64> %1162, <8 x i64> %1163
  store <8 x i64> %1164, ptr %.slot56, align 64
  %1165 = load <8 x float>, ptr %.slot99, align 32
  %1166 = select <8 x i1> %1093, <8 x float> %1122, <8 x float> %1165
  store <8 x float> %1166, ptr %.slot99, align 32
  %1167 = load <8 x float>, ptr %.slot100, align 32
  %1168 = select <8 x i1> %1093, <8 x float> %1135, <8 x float> %1167
  store <8 x float> %1168, ptr %.slot100, align 32
  %1169 = load <8 x float>, ptr %.slot101, align 32
  %1170 = select <8 x i1> %1093, <8 x float> %1148, <8 x float> %1169
  store <8 x float> %1170, ptr %.slot101, align 32
  %1171 = load <8 x float>, ptr %.slot102, align 32
  %1172 = select <8 x i1> %1093, <8 x float> %1161, <8 x float> %1171
  store <8 x float> %1172, ptr %.slot102, align 32
  store <8 x i1> %1093, ptr %current.mask, align 1
  %1173 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1093)
  br i1 %1173, label %schedule.42, label %scheduler.loop

schedule.44:                                      ; preds = %varying.coherent.false830, %scheduler.dispatch.route
  %1174 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token848 = load i32, ptr %current.token, align 4
  %convergence.token.present849 = icmp ne i32 %convergence.current.token848, 0
  br i1 %convergence.token.present849, label %convergence.cascade846, label %convergence.cascade.exit847

schedule.45:                                      ; preds = %schedule.46, %convergence.target.44.ready, %scheduler.dispatch.route
  %1175 = load <8 x i1>, ptr %current.mask, align 1
  %1176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1175)
  %1177 = bitcast <8 x i1> %1175 to i8
  %1178 = call i8 @llvm.cttz.i8(i8 %1177, i1 false)
  %1179 = zext i8 %1178 to i32
  %1180 = select i1 %1176, i32 %1179, i32 0
  %.state863 = load <8 x i64>, ptr %.slot56, align 64
  %1181 = icmp slt <8 x i64> %.state863, splat (i64 40)
  %1182 = and <8 x i1> %1175, %1181
  %1183 = xor <8 x i1> %1181, splat (i1 true)
  %1184 = and <8 x i1> %1175, %1183
  %1185 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1182)
  %1186 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1184)
  %1187 = and i1 %1185, %1186
  br i1 %1187, label %varying.divergent864, label %varying.coherent865

schedule.46:                                      ; preds = %varying.coherent.true870, %scheduler.dispatch.route
  %1188 = load <8 x i1>, ptr %current.mask, align 1
  %1189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1188)
  %1190 = bitcast <8 x i1> %1188 to i8
  %1191 = call i8 @llvm.cttz.i8(i8 %1190, i1 false)
  %1192 = zext i8 %1191 to i32
  %1193 = select i1 %1189, i32 %1192, i32 0
  %.state872 = load <8 x i64>, ptr %.slot56, align 64
  %1194 = add <8 x i64> splat (i64 80), %.state872
  %tile_snapshot.spill.load873 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1195 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load873, 0
  %1196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load873, 1
  %1197 = mul <8 x i64> %1194, splat (i64 32)
  %1198 = add <8 x i64> %1196, %1197
  %1199 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1195, 0
  %1200 = insertvalue { <8 x ptr>, <8 x i64> } %1199, <8 x i64> %1198, 1
  %1201 = extractvalue { <8 x ptr>, <8 x i64> } %1200, 0
  %1202 = extractvalue { <8 x ptr>, <8 x i64> } %1200, 1
  %1203 = getelementptr i8, <8 x ptr> %1201, <8 x i64> %1202
  %1204 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1203, <8 x i1> %1188, <8 x float> zeroinitializer)
  %.state874 = load <8 x i64>, ptr %.slot56, align 64
  %1205 = add <8 x i64> zeroinitializer, %.state874
  %tile_snapshot.spill.load875 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load875, 0
  %1207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load875, 1
  %1208 = mul <8 x i64> %1205, splat (i64 32)
  %1209 = add <8 x i64> %1207, %1208
  %1210 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1206, 0
  %1211 = insertvalue { <8 x ptr>, <8 x i64> } %1210, <8 x i64> %1209, 1
  %1212 = extractvalue { <8 x ptr>, <8 x i64> } %1211, 0
  %1213 = extractvalue { <8 x ptr>, <8 x i64> } %1211, 1
  %1214 = getelementptr i8, <8 x ptr> %1212, <8 x i64> %1213
  %1215 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1214, <8 x i1> %1188, <8 x float> zeroinitializer)
  %1216 = fmul <8 x float> %1204, %1215
  %.state876 = load <8 x float>, ptr %.slot104, align 32
  %1217 = fadd <8 x float> %.state876, %1216
  %.state877 = load <8 x i64>, ptr %.slot56, align 64
  %1218 = add <8 x i64> splat (i64 40), %.state877
  %tile_snapshot.spill.load878 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1219 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load878, 0
  %1220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load878, 1
  %1221 = mul <8 x i64> %1218, splat (i64 32)
  %1222 = add <8 x i64> %1220, %1221
  %1223 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1219, 0
  %1224 = insertvalue { <8 x ptr>, <8 x i64> } %1223, <8 x i64> %1222, 1
  %1225 = extractvalue { <8 x ptr>, <8 x i64> } %1224, 0
  %1226 = extractvalue { <8 x ptr>, <8 x i64> } %1224, 1
  %1227 = getelementptr i8, <8 x ptr> %1225, <8 x i64> %1226
  %1228 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1227, <8 x i1> %1188, <8 x float> zeroinitializer)
  %1229 = fmul <8 x float> %1204, %1228
  %.state879 = load <8 x float>, ptr %.slot105, align 32
  %1230 = fadd <8 x float> %.state879, %1229
  %tile_snapshot.spill.load880 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load880, 0
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load880, 1
  %1233 = mul <8 x i64> %1194, splat (i64 32)
  %1234 = add <8 x i64> %1232, %1233
  %1235 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1231, 0
  %1236 = insertvalue { <8 x ptr>, <8 x i64> } %1235, <8 x i64> %1234, 1
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %1236, 0
  %1238 = extractvalue { <8 x ptr>, <8 x i64> } %1236, 1
  %1239 = getelementptr i8, <8 x ptr> %1237, <8 x i64> %1238
  %1240 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1239, <8 x i1> %1188, <8 x float> zeroinitializer)
  %1241 = fmul <8 x float> %1204, %1240
  %.state881 = load <8 x float>, ptr %.slot106, align 32
  %1242 = fadd <8 x float> %.state881, %1241
  %.state882 = load <8 x i64>, ptr %.slot56, align 64
  %1243 = add <8 x i64> splat (i64 120), %.state882
  %tile_snapshot.spill.load883 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1244 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load883, 0
  %1245 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load883, 1
  %1246 = mul <8 x i64> %1243, splat (i64 32)
  %1247 = add <8 x i64> %1245, %1246
  %1248 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1244, 0
  %1249 = insertvalue { <8 x ptr>, <8 x i64> } %1248, <8 x i64> %1247, 1
  %1250 = extractvalue { <8 x ptr>, <8 x i64> } %1249, 0
  %1251 = extractvalue { <8 x ptr>, <8 x i64> } %1249, 1
  %1252 = getelementptr i8, <8 x ptr> %1250, <8 x i64> %1251
  %1253 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1252, <8 x i1> %1188, <8 x float> zeroinitializer)
  %1254 = fmul <8 x float> %1204, %1253
  %.state884 = load <8 x float>, ptr %.slot107, align 32
  %1255 = fadd <8 x float> %.state884, %1254
  %.state885 = load <8 x i64>, ptr %.slot56, align 64
  %1256 = add <8 x i64> %.state885, splat (i64 1)
  %1257 = load <8 x i64>, ptr %.slot56, align 64
  %1258 = select <8 x i1> %1188, <8 x i64> %1256, <8 x i64> %1257
  store <8 x i64> %1258, ptr %.slot56, align 64
  %1259 = load <8 x float>, ptr %.slot104, align 32
  %1260 = select <8 x i1> %1188, <8 x float> %1217, <8 x float> %1259
  store <8 x float> %1260, ptr %.slot104, align 32
  %1261 = load <8 x float>, ptr %.slot105, align 32
  %1262 = select <8 x i1> %1188, <8 x float> %1230, <8 x float> %1261
  store <8 x float> %1262, ptr %.slot105, align 32
  %1263 = load <8 x float>, ptr %.slot106, align 32
  %1264 = select <8 x i1> %1188, <8 x float> %1242, <8 x float> %1263
  store <8 x float> %1264, ptr %.slot106, align 32
  %1265 = load <8 x float>, ptr %.slot107, align 32
  %1266 = select <8 x i1> %1188, <8 x float> %1255, <8 x float> %1265
  store <8 x float> %1266, ptr %.slot107, align 32
  store <8 x i1> %1188, ptr %current.mask, align 1
  %1267 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1188)
  br i1 %1267, label %schedule.45, label %scheduler.loop

schedule.47:                                      ; preds = %varying.coherent.false871, %scheduler.dispatch.route
  %1268 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token888 = load i32, ptr %current.token, align 4
  %convergence.token.present889 = icmp ne i32 %convergence.current.token888, 0
  br i1 %convergence.token.present889, label %convergence.cascade886, label %convergence.cascade.exit887

schedule.48:                                      ; preds = %schedule.49, %convergence.target.47.ready, %scheduler.dispatch.route
  %1269 = load <8 x i1>, ptr %current.mask, align 1
  %1270 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1269)
  %1271 = bitcast <8 x i1> %1269 to i8
  %1272 = call i8 @llvm.cttz.i8(i8 %1271, i1 false)
  %1273 = zext i8 %1272 to i32
  %1274 = select i1 %1270, i32 %1273, i32 0
  %.state903 = load <8 x i64>, ptr %.slot56, align 64
  %1275 = icmp slt <8 x i64> %.state903, splat (i64 40)
  %1276 = and <8 x i1> %1269, %1275
  %1277 = xor <8 x i1> %1275, splat (i1 true)
  %1278 = and <8 x i1> %1269, %1277
  %1279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1276)
  %1280 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1278)
  %1281 = and i1 %1279, %1280
  br i1 %1281, label %varying.divergent904, label %varying.coherent905

schedule.49:                                      ; preds = %varying.coherent.true910, %scheduler.dispatch.route
  %1282 = load <8 x i1>, ptr %current.mask, align 1
  %1283 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1282)
  %1284 = bitcast <8 x i1> %1282 to i8
  %1285 = call i8 @llvm.cttz.i8(i8 %1284, i1 false)
  %1286 = zext i8 %1285 to i32
  %1287 = select i1 %1283, i32 %1286, i32 0
  %.state912 = load <8 x i64>, ptr %.slot56, align 64
  %1288 = add <8 x i64> splat (i64 80), %.state912
  %tile_snapshot.spill.load913 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1289 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load913, 0
  %1290 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load913, 1
  %1291 = mul <8 x i64> %1288, splat (i64 32)
  %1292 = add <8 x i64> %1290, %1291
  %1293 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1289, 0
  %1294 = insertvalue { <8 x ptr>, <8 x i64> } %1293, <8 x i64> %1292, 1
  %1295 = extractvalue { <8 x ptr>, <8 x i64> } %1294, 0
  %1296 = extractvalue { <8 x ptr>, <8 x i64> } %1294, 1
  %1297 = getelementptr i8, <8 x ptr> %1295, <8 x i64> %1296
  %1298 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1297, <8 x i1> %1282, <8 x float> zeroinitializer)
  %.state914 = load <8 x i64>, ptr %.slot56, align 64
  %1299 = add <8 x i64> splat (i64 160), %.state914
  %tile_snapshot.spill.load915 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1300 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load915, 0
  %1301 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load915, 1
  %1302 = mul <8 x i64> %1299, splat (i64 32)
  %1303 = add <8 x i64> %1301, %1302
  %1304 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1300, 0
  %1305 = insertvalue { <8 x ptr>, <8 x i64> } %1304, <8 x i64> %1303, 1
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %1305, 0
  %1307 = extractvalue { <8 x ptr>, <8 x i64> } %1305, 1
  %1308 = getelementptr i8, <8 x ptr> %1306, <8 x i64> %1307
  %1309 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1308, <8 x i1> %1282, <8 x float> zeroinitializer)
  %1310 = fmul <8 x float> %1298, %1309
  %.state916 = load <8 x float>, ptr %.slot109, align 32
  %1311 = fadd <8 x float> %.state916, %1310
  %.state917 = load <8 x i64>, ptr %.slot56, align 64
  %1312 = add <8 x i64> splat (i64 200), %.state917
  %tile_snapshot.spill.load918 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1313 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load918, 0
  %1314 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load918, 1
  %1315 = mul <8 x i64> %1312, splat (i64 32)
  %1316 = add <8 x i64> %1314, %1315
  %1317 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1313, 0
  %1318 = insertvalue { <8 x ptr>, <8 x i64> } %1317, <8 x i64> %1316, 1
  %1319 = extractvalue { <8 x ptr>, <8 x i64> } %1318, 0
  %1320 = extractvalue { <8 x ptr>, <8 x i64> } %1318, 1
  %1321 = getelementptr i8, <8 x ptr> %1319, <8 x i64> %1320
  %1322 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1321, <8 x i1> %1282, <8 x float> zeroinitializer)
  %1323 = fmul <8 x float> %1298, %1322
  %.state919 = load <8 x float>, ptr %.slot110, align 32
  %1324 = fadd <8 x float> %.state919, %1323
  %.state920 = load <8 x i64>, ptr %.slot56, align 64
  %1325 = add <8 x i64> splat (i64 240), %.state920
  %tile_snapshot.spill.load921 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1326 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load921, 0
  %1327 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load921, 1
  %1328 = mul <8 x i64> %1325, splat (i64 32)
  %1329 = add <8 x i64> %1327, %1328
  %1330 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1326, 0
  %1331 = insertvalue { <8 x ptr>, <8 x i64> } %1330, <8 x i64> %1329, 1
  %1332 = extractvalue { <8 x ptr>, <8 x i64> } %1331, 0
  %1333 = extractvalue { <8 x ptr>, <8 x i64> } %1331, 1
  %1334 = getelementptr i8, <8 x ptr> %1332, <8 x i64> %1333
  %1335 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1334, <8 x i1> %1282, <8 x float> zeroinitializer)
  %1336 = fmul <8 x float> %1298, %1335
  %.state922 = load <8 x float>, ptr %.slot111, align 32
  %1337 = fadd <8 x float> %.state922, %1336
  %.state923 = load <8 x i64>, ptr %.slot56, align 64
  %1338 = add <8 x i64> splat (i64 280), %.state923
  %tile_snapshot.spill.load924 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load924, 0
  %1340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load924, 1
  %1341 = mul <8 x i64> %1338, splat (i64 32)
  %1342 = add <8 x i64> %1340, %1341
  %1343 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1339, 0
  %1344 = insertvalue { <8 x ptr>, <8 x i64> } %1343, <8 x i64> %1342, 1
  %1345 = extractvalue { <8 x ptr>, <8 x i64> } %1344, 0
  %1346 = extractvalue { <8 x ptr>, <8 x i64> } %1344, 1
  %1347 = getelementptr i8, <8 x ptr> %1345, <8 x i64> %1346
  %1348 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1347, <8 x i1> %1282, <8 x float> zeroinitializer)
  %1349 = fmul <8 x float> %1298, %1348
  %.state925 = load <8 x float>, ptr %.slot112, align 32
  %1350 = fadd <8 x float> %.state925, %1349
  %.state926 = load <8 x i64>, ptr %.slot56, align 64
  %1351 = add <8 x i64> %.state926, splat (i64 1)
  %1352 = load <8 x i64>, ptr %.slot56, align 64
  %1353 = select <8 x i1> %1282, <8 x i64> %1351, <8 x i64> %1352
  store <8 x i64> %1353, ptr %.slot56, align 64
  %1354 = load <8 x float>, ptr %.slot109, align 32
  %1355 = select <8 x i1> %1282, <8 x float> %1311, <8 x float> %1354
  store <8 x float> %1355, ptr %.slot109, align 32
  %1356 = load <8 x float>, ptr %.slot110, align 32
  %1357 = select <8 x i1> %1282, <8 x float> %1324, <8 x float> %1356
  store <8 x float> %1357, ptr %.slot110, align 32
  %1358 = load <8 x float>, ptr %.slot111, align 32
  %1359 = select <8 x i1> %1282, <8 x float> %1337, <8 x float> %1358
  store <8 x float> %1359, ptr %.slot111, align 32
  %1360 = load <8 x float>, ptr %.slot112, align 32
  %1361 = select <8 x i1> %1282, <8 x float> %1350, <8 x float> %1360
  store <8 x float> %1361, ptr %.slot112, align 32
  store <8 x i1> %1282, ptr %current.mask, align 1
  %1362 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1282)
  br i1 %1362, label %schedule.48, label %scheduler.loop

schedule.50:                                      ; preds = %varying.coherent.false911, %scheduler.dispatch.route
  %1363 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token929 = load i32, ptr %current.token, align 4
  %convergence.token.present930 = icmp ne i32 %convergence.current.token929, 0
  br i1 %convergence.token.present930, label %convergence.cascade927, label %convergence.cascade.exit928

schedule.51:                                      ; preds = %schedule.52, %convergence.target.50.ready, %scheduler.dispatch.route
  %1364 = load <8 x i1>, ptr %current.mask, align 1
  %1365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1364)
  %1366 = bitcast <8 x i1> %1364 to i8
  %1367 = call i8 @llvm.cttz.i8(i8 %1366, i1 false)
  %1368 = zext i8 %1367 to i32
  %1369 = select i1 %1365, i32 %1368, i32 0
  %.state944 = load <8 x i64>, ptr %.slot56, align 64
  %1370 = icmp slt <8 x i64> %.state944, splat (i64 40)
  %1371 = and <8 x i1> %1364, %1370
  %1372 = xor <8 x i1> %1370, splat (i1 true)
  %1373 = and <8 x i1> %1364, %1372
  %1374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1371)
  %1375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1373)
  %1376 = and i1 %1374, %1375
  br i1 %1376, label %varying.divergent945, label %varying.coherent946

schedule.52:                                      ; preds = %varying.coherent.true951, %scheduler.dispatch.route
  %1377 = load <8 x i1>, ptr %current.mask, align 1
  %1378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1377)
  %1379 = bitcast <8 x i1> %1377 to i8
  %1380 = call i8 @llvm.cttz.i8(i8 %1379, i1 false)
  %1381 = zext i8 %1380 to i32
  %1382 = select i1 %1378, i32 %1381, i32 0
  %.state953 = load <8 x i64>, ptr %.slot56, align 64
  %1383 = add <8 x i64> splat (i64 80), %.state953
  %tile_snapshot.spill.load954 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1384 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load954, 0
  %1385 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load954, 1
  %1386 = mul <8 x i64> %1383, splat (i64 32)
  %1387 = add <8 x i64> %1385, %1386
  %1388 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1384, 0
  %1389 = insertvalue { <8 x ptr>, <8 x i64> } %1388, <8 x i64> %1387, 1
  %1390 = extractvalue { <8 x ptr>, <8 x i64> } %1389, 0
  %1391 = extractvalue { <8 x ptr>, <8 x i64> } %1389, 1
  %1392 = getelementptr i8, <8 x ptr> %1390, <8 x i64> %1391
  %1393 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1392, <8 x i1> %1377, <8 x float> zeroinitializer)
  %.state955 = load <8 x i64>, ptr %.slot56, align 64
  %1394 = add <8 x i64> splat (i64 320), %.state955
  %tile_snapshot.spill.load956 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load956, 0
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load956, 1
  %1397 = mul <8 x i64> %1394, splat (i64 32)
  %1398 = add <8 x i64> %1396, %1397
  %1399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1395, 0
  %1400 = insertvalue { <8 x ptr>, <8 x i64> } %1399, <8 x i64> %1398, 1
  %1401 = extractvalue { <8 x ptr>, <8 x i64> } %1400, 0
  %1402 = extractvalue { <8 x ptr>, <8 x i64> } %1400, 1
  %1403 = getelementptr i8, <8 x ptr> %1401, <8 x i64> %1402
  %1404 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1403, <8 x i1> %1377, <8 x float> zeroinitializer)
  %1405 = fmul <8 x float> %1393, %1404
  %.state957 = load <8 x float>, ptr %.slot114, align 32
  %1406 = fadd <8 x float> %.state957, %1405
  %.state958 = load <8 x i64>, ptr %.slot56, align 64
  %1407 = add <8 x i64> splat (i64 360), %.state958
  %tile_snapshot.spill.load959 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1408 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load959, 0
  %1409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load959, 1
  %1410 = mul <8 x i64> %1407, splat (i64 32)
  %1411 = add <8 x i64> %1409, %1410
  %1412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1408, 0
  %1413 = insertvalue { <8 x ptr>, <8 x i64> } %1412, <8 x i64> %1411, 1
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %1413, 0
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %1413, 1
  %1416 = getelementptr i8, <8 x ptr> %1414, <8 x i64> %1415
  %1417 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1416, <8 x i1> %1377, <8 x float> zeroinitializer)
  %1418 = fmul <8 x float> %1393, %1417
  %.state960 = load <8 x float>, ptr %.slot115, align 32
  %1419 = fadd <8 x float> %.state960, %1418
  %.state961 = load <8 x i64>, ptr %.slot56, align 64
  %1420 = add <8 x i64> splat (i64 400), %.state961
  %tile_snapshot.spill.load962 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load962, 0
  %1422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load962, 1
  %1423 = mul <8 x i64> %1420, splat (i64 32)
  %1424 = add <8 x i64> %1422, %1423
  %1425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1421, 0
  %1426 = insertvalue { <8 x ptr>, <8 x i64> } %1425, <8 x i64> %1424, 1
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %1426, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %1426, 1
  %1429 = getelementptr i8, <8 x ptr> %1427, <8 x i64> %1428
  %1430 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1429, <8 x i1> %1377, <8 x float> zeroinitializer)
  %1431 = fmul <8 x float> %1393, %1430
  %.state963 = load <8 x float>, ptr %.slot116, align 32
  %1432 = fadd <8 x float> %.state963, %1431
  %.state964 = load <8 x i64>, ptr %.slot56, align 64
  %1433 = add <8 x i64> splat (i64 440), %.state964
  %tile_snapshot.spill.load965 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load965, 0
  %1435 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load965, 1
  %1436 = mul <8 x i64> %1433, splat (i64 32)
  %1437 = add <8 x i64> %1435, %1436
  %1438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1434, 0
  %1439 = insertvalue { <8 x ptr>, <8 x i64> } %1438, <8 x i64> %1437, 1
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %1439, 0
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %1439, 1
  %1442 = getelementptr i8, <8 x ptr> %1440, <8 x i64> %1441
  %1443 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1442, <8 x i1> %1377, <8 x float> zeroinitializer)
  %1444 = fmul <8 x float> %1393, %1443
  %.state966 = load <8 x float>, ptr %.slot117, align 32
  %1445 = fadd <8 x float> %.state966, %1444
  %.state967 = load <8 x i64>, ptr %.slot56, align 64
  %1446 = add <8 x i64> %.state967, splat (i64 1)
  %1447 = load <8 x i64>, ptr %.slot56, align 64
  %1448 = select <8 x i1> %1377, <8 x i64> %1446, <8 x i64> %1447
  store <8 x i64> %1448, ptr %.slot56, align 64
  %1449 = load <8 x float>, ptr %.slot114, align 32
  %1450 = select <8 x i1> %1377, <8 x float> %1406, <8 x float> %1449
  store <8 x float> %1450, ptr %.slot114, align 32
  %1451 = load <8 x float>, ptr %.slot115, align 32
  %1452 = select <8 x i1> %1377, <8 x float> %1419, <8 x float> %1451
  store <8 x float> %1452, ptr %.slot115, align 32
  %1453 = load <8 x float>, ptr %.slot116, align 32
  %1454 = select <8 x i1> %1377, <8 x float> %1432, <8 x float> %1453
  store <8 x float> %1454, ptr %.slot116, align 32
  %1455 = load <8 x float>, ptr %.slot117, align 32
  %1456 = select <8 x i1> %1377, <8 x float> %1445, <8 x float> %1455
  store <8 x float> %1456, ptr %.slot117, align 32
  store <8 x i1> %1377, ptr %current.mask, align 1
  %1457 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1377)
  br i1 %1457, label %schedule.51, label %scheduler.loop

schedule.53:                                      ; preds = %varying.coherent.false952, %scheduler.dispatch.route
  %1458 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token970 = load i32, ptr %current.token, align 4
  %convergence.token.present971 = icmp ne i32 %convergence.current.token970, 0
  br i1 %convergence.token.present971, label %convergence.cascade968, label %convergence.cascade.exit969

schedule.54:                                      ; preds = %schedule.55, %convergence.target.53.ready, %scheduler.dispatch.route
  %1459 = load <8 x i1>, ptr %current.mask, align 1
  %1460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1459)
  %1461 = bitcast <8 x i1> %1459 to i8
  %1462 = call i8 @llvm.cttz.i8(i8 %1461, i1 false)
  %1463 = zext i8 %1462 to i32
  %1464 = select i1 %1460, i32 %1463, i32 0
  %.state985 = load <8 x i64>, ptr %.slot56, align 64
  %1465 = icmp slt <8 x i64> %.state985, splat (i64 40)
  %1466 = and <8 x i1> %1459, %1465
  %1467 = xor <8 x i1> %1465, splat (i1 true)
  %1468 = and <8 x i1> %1459, %1467
  %1469 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1466)
  %1470 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1468)
  %1471 = and i1 %1469, %1470
  br i1 %1471, label %varying.divergent986, label %varying.coherent987

schedule.55:                                      ; preds = %varying.coherent.true992, %scheduler.dispatch.route
  %1472 = load <8 x i1>, ptr %current.mask, align 1
  %1473 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1472)
  %1474 = bitcast <8 x i1> %1472 to i8
  %1475 = call i8 @llvm.cttz.i8(i8 %1474, i1 false)
  %1476 = zext i8 %1475 to i32
  %1477 = select i1 %1473, i32 %1476, i32 0
  %.state994 = load <8 x i64>, ptr %.slot56, align 64
  %1478 = add <8 x i64> splat (i64 80), %.state994
  %tile_snapshot.spill.load995 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load995, 0
  %1480 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load995, 1
  %1481 = mul <8 x i64> %1478, splat (i64 32)
  %1482 = add <8 x i64> %1480, %1481
  %1483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1479, 0
  %1484 = insertvalue { <8 x ptr>, <8 x i64> } %1483, <8 x i64> %1482, 1
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %1484, 0
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %1484, 1
  %1487 = getelementptr i8, <8 x ptr> %1485, <8 x i64> %1486
  %1488 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1487, <8 x i1> %1472, <8 x float> zeroinitializer)
  %.state996 = load <8 x i64>, ptr %.slot56, align 64
  %1489 = add <8 x i64> splat (i64 480), %.state996
  %tile_snapshot.spill.load997 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1490 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load997, 0
  %1491 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load997, 1
  %1492 = mul <8 x i64> %1489, splat (i64 32)
  %1493 = add <8 x i64> %1491, %1492
  %1494 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1490, 0
  %1495 = insertvalue { <8 x ptr>, <8 x i64> } %1494, <8 x i64> %1493, 1
  %1496 = extractvalue { <8 x ptr>, <8 x i64> } %1495, 0
  %1497 = extractvalue { <8 x ptr>, <8 x i64> } %1495, 1
  %1498 = getelementptr i8, <8 x ptr> %1496, <8 x i64> %1497
  %1499 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1498, <8 x i1> %1472, <8 x float> zeroinitializer)
  %1500 = fmul <8 x float> %1488, %1499
  %.state998 = load <8 x float>, ptr %.slot119, align 32
  %1501 = fadd <8 x float> %.state998, %1500
  %.state999 = load <8 x i64>, ptr %.slot56, align 64
  %1502 = add <8 x i64> splat (i64 520), %.state999
  %tile_snapshot.spill.load1000 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1503 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1000, 0
  %1504 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1000, 1
  %1505 = mul <8 x i64> %1502, splat (i64 32)
  %1506 = add <8 x i64> %1504, %1505
  %1507 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1503, 0
  %1508 = insertvalue { <8 x ptr>, <8 x i64> } %1507, <8 x i64> %1506, 1
  %1509 = extractvalue { <8 x ptr>, <8 x i64> } %1508, 0
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %1508, 1
  %1511 = getelementptr i8, <8 x ptr> %1509, <8 x i64> %1510
  %1512 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1511, <8 x i1> %1472, <8 x float> zeroinitializer)
  %1513 = fmul <8 x float> %1488, %1512
  %.state1001 = load <8 x float>, ptr %.slot120, align 32
  %1514 = fadd <8 x float> %.state1001, %1513
  %.state1002 = load <8 x i64>, ptr %.slot56, align 64
  %1515 = add <8 x i64> splat (i64 560), %.state1002
  %tile_snapshot.spill.load1003 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1003, 0
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1003, 1
  %1518 = mul <8 x i64> %1515, splat (i64 32)
  %1519 = add <8 x i64> %1517, %1518
  %1520 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1516, 0
  %1521 = insertvalue { <8 x ptr>, <8 x i64> } %1520, <8 x i64> %1519, 1
  %1522 = extractvalue { <8 x ptr>, <8 x i64> } %1521, 0
  %1523 = extractvalue { <8 x ptr>, <8 x i64> } %1521, 1
  %1524 = getelementptr i8, <8 x ptr> %1522, <8 x i64> %1523
  %1525 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1524, <8 x i1> %1472, <8 x float> zeroinitializer)
  %1526 = fmul <8 x float> %1488, %1525
  %.state1004 = load <8 x float>, ptr %.slot121, align 32
  %1527 = fadd <8 x float> %.state1004, %1526
  %.state1005 = load <8 x i64>, ptr %.slot56, align 64
  %1528 = add <8 x i64> splat (i64 600), %.state1005
  %tile_snapshot.spill.load1006 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1006, 0
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1006, 1
  %1531 = mul <8 x i64> %1528, splat (i64 32)
  %1532 = add <8 x i64> %1530, %1531
  %1533 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1529, 0
  %1534 = insertvalue { <8 x ptr>, <8 x i64> } %1533, <8 x i64> %1532, 1
  %1535 = extractvalue { <8 x ptr>, <8 x i64> } %1534, 0
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %1534, 1
  %1537 = getelementptr i8, <8 x ptr> %1535, <8 x i64> %1536
  %1538 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1537, <8 x i1> %1472, <8 x float> zeroinitializer)
  %1539 = fmul <8 x float> %1488, %1538
  %.state1007 = load <8 x float>, ptr %.slot122, align 32
  %1540 = fadd <8 x float> %.state1007, %1539
  %.state1008 = load <8 x i64>, ptr %.slot56, align 64
  %1541 = add <8 x i64> %.state1008, splat (i64 1)
  %1542 = load <8 x i64>, ptr %.slot56, align 64
  %1543 = select <8 x i1> %1472, <8 x i64> %1541, <8 x i64> %1542
  store <8 x i64> %1543, ptr %.slot56, align 64
  %1544 = load <8 x float>, ptr %.slot119, align 32
  %1545 = select <8 x i1> %1472, <8 x float> %1501, <8 x float> %1544
  store <8 x float> %1545, ptr %.slot119, align 32
  %1546 = load <8 x float>, ptr %.slot120, align 32
  %1547 = select <8 x i1> %1472, <8 x float> %1514, <8 x float> %1546
  store <8 x float> %1547, ptr %.slot120, align 32
  %1548 = load <8 x float>, ptr %.slot121, align 32
  %1549 = select <8 x i1> %1472, <8 x float> %1527, <8 x float> %1548
  store <8 x float> %1549, ptr %.slot121, align 32
  %1550 = load <8 x float>, ptr %.slot122, align 32
  %1551 = select <8 x i1> %1472, <8 x float> %1540, <8 x float> %1550
  store <8 x float> %1551, ptr %.slot122, align 32
  store <8 x i1> %1472, ptr %current.mask, align 1
  %1552 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1472)
  br i1 %1552, label %schedule.54, label %scheduler.loop

schedule.56:                                      ; preds = %varying.coherent.false993, %scheduler.dispatch.route
  %1553 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1011 = load i32, ptr %current.token, align 4
  %convergence.token.present1012 = icmp ne i32 %convergence.current.token1011, 0
  br i1 %convergence.token.present1012, label %convergence.cascade1009, label %convergence.cascade.exit1010

schedule.57:                                      ; preds = %schedule.58, %convergence.target.56.ready, %scheduler.dispatch.route
  %1554 = load <8 x i1>, ptr %current.mask, align 1
  %1555 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1554)
  %1556 = bitcast <8 x i1> %1554 to i8
  %1557 = call i8 @llvm.cttz.i8(i8 %1556, i1 false)
  %1558 = zext i8 %1557 to i32
  %1559 = select i1 %1555, i32 %1558, i32 0
  %.state1026 = load <8 x i64>, ptr %.slot56, align 64
  %1560 = icmp slt <8 x i64> %.state1026, splat (i64 40)
  %1561 = and <8 x i1> %1554, %1560
  %1562 = xor <8 x i1> %1560, splat (i1 true)
  %1563 = and <8 x i1> %1554, %1562
  %1564 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1561)
  %1565 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1563)
  %1566 = and i1 %1564, %1565
  br i1 %1566, label %varying.divergent1027, label %varying.coherent1028

schedule.58:                                      ; preds = %varying.coherent.true1033, %scheduler.dispatch.route
  %1567 = load <8 x i1>, ptr %current.mask, align 1
  %1568 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1567)
  %1569 = bitcast <8 x i1> %1567 to i8
  %1570 = call i8 @llvm.cttz.i8(i8 %1569, i1 false)
  %1571 = zext i8 %1570 to i32
  %1572 = select i1 %1568, i32 %1571, i32 0
  %.state1035 = load <8 x i64>, ptr %.slot56, align 64
  %1573 = add <8 x i64> splat (i64 120), %.state1035
  %tile_snapshot.spill.load1036 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1574 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1036, 0
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1036, 1
  %1576 = mul <8 x i64> %1573, splat (i64 32)
  %1577 = add <8 x i64> %1575, %1576
  %1578 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1574, 0
  %1579 = insertvalue { <8 x ptr>, <8 x i64> } %1578, <8 x i64> %1577, 1
  %1580 = extractvalue { <8 x ptr>, <8 x i64> } %1579, 0
  %1581 = extractvalue { <8 x ptr>, <8 x i64> } %1579, 1
  %1582 = getelementptr i8, <8 x ptr> %1580, <8 x i64> %1581
  %1583 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1582, <8 x i1> %1567, <8 x float> zeroinitializer)
  %.state1037 = load <8 x i64>, ptr %.slot56, align 64
  %1584 = add <8 x i64> zeroinitializer, %.state1037
  %tile_snapshot.spill.load1038 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1038, 0
  %1586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1038, 1
  %1587 = mul <8 x i64> %1584, splat (i64 32)
  %1588 = add <8 x i64> %1586, %1587
  %1589 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1585, 0
  %1590 = insertvalue { <8 x ptr>, <8 x i64> } %1589, <8 x i64> %1588, 1
  %1591 = extractvalue { <8 x ptr>, <8 x i64> } %1590, 0
  %1592 = extractvalue { <8 x ptr>, <8 x i64> } %1590, 1
  %1593 = getelementptr i8, <8 x ptr> %1591, <8 x i64> %1592
  %1594 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1593, <8 x i1> %1567, <8 x float> zeroinitializer)
  %1595 = fmul <8 x float> %1583, %1594
  %.state1039 = load <8 x float>, ptr %.slot124, align 32
  %1596 = fadd <8 x float> %.state1039, %1595
  %.state1040 = load <8 x i64>, ptr %.slot56, align 64
  %1597 = add <8 x i64> splat (i64 40), %.state1040
  %tile_snapshot.spill.load1041 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1041, 0
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1041, 1
  %1600 = mul <8 x i64> %1597, splat (i64 32)
  %1601 = add <8 x i64> %1599, %1600
  %1602 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1598, 0
  %1603 = insertvalue { <8 x ptr>, <8 x i64> } %1602, <8 x i64> %1601, 1
  %1604 = extractvalue { <8 x ptr>, <8 x i64> } %1603, 0
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %1603, 1
  %1606 = getelementptr i8, <8 x ptr> %1604, <8 x i64> %1605
  %1607 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1606, <8 x i1> %1567, <8 x float> zeroinitializer)
  %1608 = fmul <8 x float> %1583, %1607
  %.state1042 = load <8 x float>, ptr %.slot125, align 32
  %1609 = fadd <8 x float> %.state1042, %1608
  %.state1043 = load <8 x i64>, ptr %.slot56, align 64
  %1610 = add <8 x i64> splat (i64 80), %.state1043
  %tile_snapshot.spill.load1044 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1044, 0
  %1612 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1044, 1
  %1613 = mul <8 x i64> %1610, splat (i64 32)
  %1614 = add <8 x i64> %1612, %1613
  %1615 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1611, 0
  %1616 = insertvalue { <8 x ptr>, <8 x i64> } %1615, <8 x i64> %1614, 1
  %1617 = extractvalue { <8 x ptr>, <8 x i64> } %1616, 0
  %1618 = extractvalue { <8 x ptr>, <8 x i64> } %1616, 1
  %1619 = getelementptr i8, <8 x ptr> %1617, <8 x i64> %1618
  %1620 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1619, <8 x i1> %1567, <8 x float> zeroinitializer)
  %1621 = fmul <8 x float> %1583, %1620
  %.state1045 = load <8 x float>, ptr %.slot126, align 32
  %1622 = fadd <8 x float> %.state1045, %1621
  %tile_snapshot.spill.load1046 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1046, 0
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1046, 1
  %1625 = mul <8 x i64> %1573, splat (i64 32)
  %1626 = add <8 x i64> %1624, %1625
  %1627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1623, 0
  %1628 = insertvalue { <8 x ptr>, <8 x i64> } %1627, <8 x i64> %1626, 1
  %1629 = extractvalue { <8 x ptr>, <8 x i64> } %1628, 0
  %1630 = extractvalue { <8 x ptr>, <8 x i64> } %1628, 1
  %1631 = getelementptr i8, <8 x ptr> %1629, <8 x i64> %1630
  %1632 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1631, <8 x i1> %1567, <8 x float> zeroinitializer)
  %1633 = fmul <8 x float> %1583, %1632
  %.state1047 = load <8 x float>, ptr %.slot127, align 32
  %1634 = fadd <8 x float> %.state1047, %1633
  %.state1048 = load <8 x i64>, ptr %.slot56, align 64
  %1635 = add <8 x i64> %.state1048, splat (i64 1)
  %1636 = load <8 x i64>, ptr %.slot56, align 64
  %1637 = select <8 x i1> %1567, <8 x i64> %1635, <8 x i64> %1636
  store <8 x i64> %1637, ptr %.slot56, align 64
  %1638 = load <8 x float>, ptr %.slot124, align 32
  %1639 = select <8 x i1> %1567, <8 x float> %1596, <8 x float> %1638
  store <8 x float> %1639, ptr %.slot124, align 32
  %1640 = load <8 x float>, ptr %.slot125, align 32
  %1641 = select <8 x i1> %1567, <8 x float> %1609, <8 x float> %1640
  store <8 x float> %1641, ptr %.slot125, align 32
  %1642 = load <8 x float>, ptr %.slot126, align 32
  %1643 = select <8 x i1> %1567, <8 x float> %1622, <8 x float> %1642
  store <8 x float> %1643, ptr %.slot126, align 32
  %1644 = load <8 x float>, ptr %.slot127, align 32
  %1645 = select <8 x i1> %1567, <8 x float> %1634, <8 x float> %1644
  store <8 x float> %1645, ptr %.slot127, align 32
  store <8 x i1> %1567, ptr %current.mask, align 1
  %1646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1567)
  br i1 %1646, label %schedule.57, label %scheduler.loop

schedule.59:                                      ; preds = %varying.coherent.false1034, %scheduler.dispatch.route
  %1647 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1051 = load i32, ptr %current.token, align 4
  %convergence.token.present1052 = icmp ne i32 %convergence.current.token1051, 0
  br i1 %convergence.token.present1052, label %convergence.cascade1049, label %convergence.cascade.exit1050

schedule.60:                                      ; preds = %schedule.61, %convergence.target.59.ready, %scheduler.dispatch.route
  %1648 = load <8 x i1>, ptr %current.mask, align 1
  %1649 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1648)
  %1650 = bitcast <8 x i1> %1648 to i8
  %1651 = call i8 @llvm.cttz.i8(i8 %1650, i1 false)
  %1652 = zext i8 %1651 to i32
  %1653 = select i1 %1649, i32 %1652, i32 0
  %.state1066 = load <8 x i64>, ptr %.slot56, align 64
  %1654 = icmp slt <8 x i64> %.state1066, splat (i64 40)
  %1655 = and <8 x i1> %1648, %1654
  %1656 = xor <8 x i1> %1654, splat (i1 true)
  %1657 = and <8 x i1> %1648, %1656
  %1658 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1655)
  %1659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1657)
  %1660 = and i1 %1658, %1659
  br i1 %1660, label %varying.divergent1067, label %varying.coherent1068

schedule.61:                                      ; preds = %varying.coherent.true1073, %scheduler.dispatch.route
  %1661 = load <8 x i1>, ptr %current.mask, align 1
  %1662 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1661)
  %1663 = bitcast <8 x i1> %1661 to i8
  %1664 = call i8 @llvm.cttz.i8(i8 %1663, i1 false)
  %1665 = zext i8 %1664 to i32
  %1666 = select i1 %1662, i32 %1665, i32 0
  %.state1075 = load <8 x i64>, ptr %.slot56, align 64
  %1667 = add <8 x i64> splat (i64 120), %.state1075
  %tile_snapshot.spill.load1076 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1668 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1076, 0
  %1669 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1076, 1
  %1670 = mul <8 x i64> %1667, splat (i64 32)
  %1671 = add <8 x i64> %1669, %1670
  %1672 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1668, 0
  %1673 = insertvalue { <8 x ptr>, <8 x i64> } %1672, <8 x i64> %1671, 1
  %1674 = extractvalue { <8 x ptr>, <8 x i64> } %1673, 0
  %1675 = extractvalue { <8 x ptr>, <8 x i64> } %1673, 1
  %1676 = getelementptr i8, <8 x ptr> %1674, <8 x i64> %1675
  %1677 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1676, <8 x i1> %1661, <8 x float> zeroinitializer)
  %.state1077 = load <8 x i64>, ptr %.slot56, align 64
  %1678 = add <8 x i64> splat (i64 160), %.state1077
  %tile_snapshot.spill.load1078 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1679 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1078, 0
  %1680 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1078, 1
  %1681 = mul <8 x i64> %1678, splat (i64 32)
  %1682 = add <8 x i64> %1680, %1681
  %1683 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1679, 0
  %1684 = insertvalue { <8 x ptr>, <8 x i64> } %1683, <8 x i64> %1682, 1
  %1685 = extractvalue { <8 x ptr>, <8 x i64> } %1684, 0
  %1686 = extractvalue { <8 x ptr>, <8 x i64> } %1684, 1
  %1687 = getelementptr i8, <8 x ptr> %1685, <8 x i64> %1686
  %1688 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1687, <8 x i1> %1661, <8 x float> zeroinitializer)
  %1689 = fmul <8 x float> %1677, %1688
  %.state1079 = load <8 x float>, ptr %.slot129, align 32
  %1690 = fadd <8 x float> %.state1079, %1689
  %.state1080 = load <8 x i64>, ptr %.slot56, align 64
  %1691 = add <8 x i64> splat (i64 200), %.state1080
  %tile_snapshot.spill.load1081 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1081, 0
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1081, 1
  %1694 = mul <8 x i64> %1691, splat (i64 32)
  %1695 = add <8 x i64> %1693, %1694
  %1696 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1692, 0
  %1697 = insertvalue { <8 x ptr>, <8 x i64> } %1696, <8 x i64> %1695, 1
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %1697, 0
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %1697, 1
  %1700 = getelementptr i8, <8 x ptr> %1698, <8 x i64> %1699
  %1701 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1700, <8 x i1> %1661, <8 x float> zeroinitializer)
  %1702 = fmul <8 x float> %1677, %1701
  %.state1082 = load <8 x float>, ptr %.slot130, align 32
  %1703 = fadd <8 x float> %.state1082, %1702
  %.state1083 = load <8 x i64>, ptr %.slot56, align 64
  %1704 = add <8 x i64> splat (i64 240), %.state1083
  %tile_snapshot.spill.load1084 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1705 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1084, 0
  %1706 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1084, 1
  %1707 = mul <8 x i64> %1704, splat (i64 32)
  %1708 = add <8 x i64> %1706, %1707
  %1709 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1705, 0
  %1710 = insertvalue { <8 x ptr>, <8 x i64> } %1709, <8 x i64> %1708, 1
  %1711 = extractvalue { <8 x ptr>, <8 x i64> } %1710, 0
  %1712 = extractvalue { <8 x ptr>, <8 x i64> } %1710, 1
  %1713 = getelementptr i8, <8 x ptr> %1711, <8 x i64> %1712
  %1714 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1713, <8 x i1> %1661, <8 x float> zeroinitializer)
  %1715 = fmul <8 x float> %1677, %1714
  %.state1085 = load <8 x float>, ptr %.slot131, align 32
  %1716 = fadd <8 x float> %.state1085, %1715
  %.state1086 = load <8 x i64>, ptr %.slot56, align 64
  %1717 = add <8 x i64> splat (i64 280), %.state1086
  %tile_snapshot.spill.load1087 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1718 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1087, 0
  %1719 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1087, 1
  %1720 = mul <8 x i64> %1717, splat (i64 32)
  %1721 = add <8 x i64> %1719, %1720
  %1722 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1718, 0
  %1723 = insertvalue { <8 x ptr>, <8 x i64> } %1722, <8 x i64> %1721, 1
  %1724 = extractvalue { <8 x ptr>, <8 x i64> } %1723, 0
  %1725 = extractvalue { <8 x ptr>, <8 x i64> } %1723, 1
  %1726 = getelementptr i8, <8 x ptr> %1724, <8 x i64> %1725
  %1727 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1726, <8 x i1> %1661, <8 x float> zeroinitializer)
  %1728 = fmul <8 x float> %1677, %1727
  %.state1088 = load <8 x float>, ptr %.slot132, align 32
  %1729 = fadd <8 x float> %.state1088, %1728
  %.state1089 = load <8 x i64>, ptr %.slot56, align 64
  %1730 = add <8 x i64> %.state1089, splat (i64 1)
  %1731 = load <8 x i64>, ptr %.slot56, align 64
  %1732 = select <8 x i1> %1661, <8 x i64> %1730, <8 x i64> %1731
  store <8 x i64> %1732, ptr %.slot56, align 64
  %1733 = load <8 x float>, ptr %.slot129, align 32
  %1734 = select <8 x i1> %1661, <8 x float> %1690, <8 x float> %1733
  store <8 x float> %1734, ptr %.slot129, align 32
  %1735 = load <8 x float>, ptr %.slot130, align 32
  %1736 = select <8 x i1> %1661, <8 x float> %1703, <8 x float> %1735
  store <8 x float> %1736, ptr %.slot130, align 32
  %1737 = load <8 x float>, ptr %.slot131, align 32
  %1738 = select <8 x i1> %1661, <8 x float> %1716, <8 x float> %1737
  store <8 x float> %1738, ptr %.slot131, align 32
  %1739 = load <8 x float>, ptr %.slot132, align 32
  %1740 = select <8 x i1> %1661, <8 x float> %1729, <8 x float> %1739
  store <8 x float> %1740, ptr %.slot132, align 32
  store <8 x i1> %1661, ptr %current.mask, align 1
  %1741 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1661)
  br i1 %1741, label %schedule.60, label %scheduler.loop

schedule.62:                                      ; preds = %varying.coherent.false1074, %scheduler.dispatch.route
  %1742 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1092 = load i32, ptr %current.token, align 4
  %convergence.token.present1093 = icmp ne i32 %convergence.current.token1092, 0
  br i1 %convergence.token.present1093, label %convergence.cascade1090, label %convergence.cascade.exit1091

schedule.63:                                      ; preds = %schedule.64, %convergence.target.62.ready, %scheduler.dispatch.route
  %1743 = load <8 x i1>, ptr %current.mask, align 1
  %1744 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1743)
  %1745 = bitcast <8 x i1> %1743 to i8
  %1746 = call i8 @llvm.cttz.i8(i8 %1745, i1 false)
  %1747 = zext i8 %1746 to i32
  %1748 = select i1 %1744, i32 %1747, i32 0
  %.state1107 = load <8 x i64>, ptr %.slot56, align 64
  %1749 = icmp slt <8 x i64> %.state1107, splat (i64 40)
  %1750 = and <8 x i1> %1743, %1749
  %1751 = xor <8 x i1> %1749, splat (i1 true)
  %1752 = and <8 x i1> %1743, %1751
  %1753 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1750)
  %1754 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1752)
  %1755 = and i1 %1753, %1754
  br i1 %1755, label %varying.divergent1108, label %varying.coherent1109

schedule.64:                                      ; preds = %varying.coherent.true1114, %scheduler.dispatch.route
  %1756 = load <8 x i1>, ptr %current.mask, align 1
  %1757 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1756)
  %1758 = bitcast <8 x i1> %1756 to i8
  %1759 = call i8 @llvm.cttz.i8(i8 %1758, i1 false)
  %1760 = zext i8 %1759 to i32
  %1761 = select i1 %1757, i32 %1760, i32 0
  %.state1116 = load <8 x i64>, ptr %.slot56, align 64
  %1762 = add <8 x i64> splat (i64 120), %.state1116
  %tile_snapshot.spill.load1117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 0
  %1764 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 1
  %1765 = mul <8 x i64> %1762, splat (i64 32)
  %1766 = add <8 x i64> %1764, %1765
  %1767 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1763, 0
  %1768 = insertvalue { <8 x ptr>, <8 x i64> } %1767, <8 x i64> %1766, 1
  %1769 = extractvalue { <8 x ptr>, <8 x i64> } %1768, 0
  %1770 = extractvalue { <8 x ptr>, <8 x i64> } %1768, 1
  %1771 = getelementptr i8, <8 x ptr> %1769, <8 x i64> %1770
  %1772 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1771, <8 x i1> %1756, <8 x float> zeroinitializer)
  %.state1118 = load <8 x i64>, ptr %.slot56, align 64
  %1773 = add <8 x i64> splat (i64 320), %.state1118
  %tile_snapshot.spill.load1119 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1774 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 0
  %1775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 1
  %1776 = mul <8 x i64> %1773, splat (i64 32)
  %1777 = add <8 x i64> %1775, %1776
  %1778 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1774, 0
  %1779 = insertvalue { <8 x ptr>, <8 x i64> } %1778, <8 x i64> %1777, 1
  %1780 = extractvalue { <8 x ptr>, <8 x i64> } %1779, 0
  %1781 = extractvalue { <8 x ptr>, <8 x i64> } %1779, 1
  %1782 = getelementptr i8, <8 x ptr> %1780, <8 x i64> %1781
  %1783 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1782, <8 x i1> %1756, <8 x float> zeroinitializer)
  %1784 = fmul <8 x float> %1772, %1783
  %.state1120 = load <8 x float>, ptr %.slot134, align 32
  %1785 = fadd <8 x float> %.state1120, %1784
  %.state1121 = load <8 x i64>, ptr %.slot56, align 64
  %1786 = add <8 x i64> splat (i64 360), %.state1121
  %tile_snapshot.spill.load1122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1787 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1122, 0
  %1788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1122, 1
  %1789 = mul <8 x i64> %1786, splat (i64 32)
  %1790 = add <8 x i64> %1788, %1789
  %1791 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1787, 0
  %1792 = insertvalue { <8 x ptr>, <8 x i64> } %1791, <8 x i64> %1790, 1
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %1792, 0
  %1794 = extractvalue { <8 x ptr>, <8 x i64> } %1792, 1
  %1795 = getelementptr i8, <8 x ptr> %1793, <8 x i64> %1794
  %1796 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1795, <8 x i1> %1756, <8 x float> zeroinitializer)
  %1797 = fmul <8 x float> %1772, %1796
  %.state1123 = load <8 x float>, ptr %.slot135, align 32
  %1798 = fadd <8 x float> %.state1123, %1797
  %.state1124 = load <8 x i64>, ptr %.slot56, align 64
  %1799 = add <8 x i64> splat (i64 400), %.state1124
  %tile_snapshot.spill.load1125 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1800 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1125, 0
  %1801 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1125, 1
  %1802 = mul <8 x i64> %1799, splat (i64 32)
  %1803 = add <8 x i64> %1801, %1802
  %1804 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1800, 0
  %1805 = insertvalue { <8 x ptr>, <8 x i64> } %1804, <8 x i64> %1803, 1
  %1806 = extractvalue { <8 x ptr>, <8 x i64> } %1805, 0
  %1807 = extractvalue { <8 x ptr>, <8 x i64> } %1805, 1
  %1808 = getelementptr i8, <8 x ptr> %1806, <8 x i64> %1807
  %1809 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1808, <8 x i1> %1756, <8 x float> zeroinitializer)
  %1810 = fmul <8 x float> %1772, %1809
  %.state1126 = load <8 x float>, ptr %.slot136, align 32
  %1811 = fadd <8 x float> %.state1126, %1810
  %.state1127 = load <8 x i64>, ptr %.slot56, align 64
  %1812 = add <8 x i64> splat (i64 440), %.state1127
  %tile_snapshot.spill.load1128 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1128, 0
  %1814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1128, 1
  %1815 = mul <8 x i64> %1812, splat (i64 32)
  %1816 = add <8 x i64> %1814, %1815
  %1817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1813, 0
  %1818 = insertvalue { <8 x ptr>, <8 x i64> } %1817, <8 x i64> %1816, 1
  %1819 = extractvalue { <8 x ptr>, <8 x i64> } %1818, 0
  %1820 = extractvalue { <8 x ptr>, <8 x i64> } %1818, 1
  %1821 = getelementptr i8, <8 x ptr> %1819, <8 x i64> %1820
  %1822 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1821, <8 x i1> %1756, <8 x float> zeroinitializer)
  %1823 = fmul <8 x float> %1772, %1822
  %.state1129 = load <8 x float>, ptr %.slot137, align 32
  %1824 = fadd <8 x float> %.state1129, %1823
  %.state1130 = load <8 x i64>, ptr %.slot56, align 64
  %1825 = add <8 x i64> %.state1130, splat (i64 1)
  %1826 = load <8 x i64>, ptr %.slot56, align 64
  %1827 = select <8 x i1> %1756, <8 x i64> %1825, <8 x i64> %1826
  store <8 x i64> %1827, ptr %.slot56, align 64
  %1828 = load <8 x float>, ptr %.slot134, align 32
  %1829 = select <8 x i1> %1756, <8 x float> %1785, <8 x float> %1828
  store <8 x float> %1829, ptr %.slot134, align 32
  %1830 = load <8 x float>, ptr %.slot135, align 32
  %1831 = select <8 x i1> %1756, <8 x float> %1798, <8 x float> %1830
  store <8 x float> %1831, ptr %.slot135, align 32
  %1832 = load <8 x float>, ptr %.slot136, align 32
  %1833 = select <8 x i1> %1756, <8 x float> %1811, <8 x float> %1832
  store <8 x float> %1833, ptr %.slot136, align 32
  %1834 = load <8 x float>, ptr %.slot137, align 32
  %1835 = select <8 x i1> %1756, <8 x float> %1824, <8 x float> %1834
  store <8 x float> %1835, ptr %.slot137, align 32
  store <8 x i1> %1756, ptr %current.mask, align 1
  %1836 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1756)
  br i1 %1836, label %schedule.63, label %scheduler.loop

schedule.65:                                      ; preds = %varying.coherent.false1115, %scheduler.dispatch.route
  %1837 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1133 = load i32, ptr %current.token, align 4
  %convergence.token.present1134 = icmp ne i32 %convergence.current.token1133, 0
  br i1 %convergence.token.present1134, label %convergence.cascade1131, label %convergence.cascade.exit1132

schedule.66:                                      ; preds = %schedule.67, %convergence.target.65.ready, %scheduler.dispatch.route
  %1838 = load <8 x i1>, ptr %current.mask, align 1
  %1839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1838)
  %1840 = bitcast <8 x i1> %1838 to i8
  %1841 = call i8 @llvm.cttz.i8(i8 %1840, i1 false)
  %1842 = zext i8 %1841 to i32
  %1843 = select i1 %1839, i32 %1842, i32 0
  %.state1148 = load <8 x i64>, ptr %.slot56, align 64
  %1844 = icmp slt <8 x i64> %.state1148, splat (i64 40)
  %1845 = and <8 x i1> %1838, %1844
  %1846 = xor <8 x i1> %1844, splat (i1 true)
  %1847 = and <8 x i1> %1838, %1846
  %1848 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1845)
  %1849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1847)
  %1850 = and i1 %1848, %1849
  br i1 %1850, label %varying.divergent1149, label %varying.coherent1150

schedule.67:                                      ; preds = %varying.coherent.true1155, %scheduler.dispatch.route
  %1851 = load <8 x i1>, ptr %current.mask, align 1
  %1852 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1851)
  %1853 = bitcast <8 x i1> %1851 to i8
  %1854 = call i8 @llvm.cttz.i8(i8 %1853, i1 false)
  %1855 = zext i8 %1854 to i32
  %1856 = select i1 %1852, i32 %1855, i32 0
  %.state1157 = load <8 x i64>, ptr %.slot56, align 64
  %1857 = add <8 x i64> splat (i64 120), %.state1157
  %tile_snapshot.spill.load1158 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1858 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1158, 0
  %1859 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1158, 1
  %1860 = mul <8 x i64> %1857, splat (i64 32)
  %1861 = add <8 x i64> %1859, %1860
  %1862 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1858, 0
  %1863 = insertvalue { <8 x ptr>, <8 x i64> } %1862, <8 x i64> %1861, 1
  %1864 = extractvalue { <8 x ptr>, <8 x i64> } %1863, 0
  %1865 = extractvalue { <8 x ptr>, <8 x i64> } %1863, 1
  %1866 = getelementptr i8, <8 x ptr> %1864, <8 x i64> %1865
  %1867 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1866, <8 x i1> %1851, <8 x float> zeroinitializer)
  %.state1159 = load <8 x i64>, ptr %.slot56, align 64
  %1868 = add <8 x i64> splat (i64 480), %.state1159
  %tile_snapshot.spill.load1160 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1869 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1160, 0
  %1870 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1160, 1
  %1871 = mul <8 x i64> %1868, splat (i64 32)
  %1872 = add <8 x i64> %1870, %1871
  %1873 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1869, 0
  %1874 = insertvalue { <8 x ptr>, <8 x i64> } %1873, <8 x i64> %1872, 1
  %1875 = extractvalue { <8 x ptr>, <8 x i64> } %1874, 0
  %1876 = extractvalue { <8 x ptr>, <8 x i64> } %1874, 1
  %1877 = getelementptr i8, <8 x ptr> %1875, <8 x i64> %1876
  %1878 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1877, <8 x i1> %1851, <8 x float> zeroinitializer)
  %1879 = fmul <8 x float> %1867, %1878
  %.state1161 = load <8 x float>, ptr %.slot139, align 32
  %1880 = fadd <8 x float> %.state1161, %1879
  %.state1162 = load <8 x i64>, ptr %.slot56, align 64
  %1881 = add <8 x i64> splat (i64 520), %.state1162
  %tile_snapshot.spill.load1163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1882 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1163, 0
  %1883 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1163, 1
  %1884 = mul <8 x i64> %1881, splat (i64 32)
  %1885 = add <8 x i64> %1883, %1884
  %1886 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1882, 0
  %1887 = insertvalue { <8 x ptr>, <8 x i64> } %1886, <8 x i64> %1885, 1
  %1888 = extractvalue { <8 x ptr>, <8 x i64> } %1887, 0
  %1889 = extractvalue { <8 x ptr>, <8 x i64> } %1887, 1
  %1890 = getelementptr i8, <8 x ptr> %1888, <8 x i64> %1889
  %1891 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1890, <8 x i1> %1851, <8 x float> zeroinitializer)
  %1892 = fmul <8 x float> %1867, %1891
  %.state1164 = load <8 x float>, ptr %.slot140, align 32
  %1893 = fadd <8 x float> %.state1164, %1892
  %.state1165 = load <8 x i64>, ptr %.slot56, align 64
  %1894 = add <8 x i64> splat (i64 560), %.state1165
  %tile_snapshot.spill.load1166 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1895 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1166, 0
  %1896 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1166, 1
  %1897 = mul <8 x i64> %1894, splat (i64 32)
  %1898 = add <8 x i64> %1896, %1897
  %1899 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1895, 0
  %1900 = insertvalue { <8 x ptr>, <8 x i64> } %1899, <8 x i64> %1898, 1
  %1901 = extractvalue { <8 x ptr>, <8 x i64> } %1900, 0
  %1902 = extractvalue { <8 x ptr>, <8 x i64> } %1900, 1
  %1903 = getelementptr i8, <8 x ptr> %1901, <8 x i64> %1902
  %1904 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1903, <8 x i1> %1851, <8 x float> zeroinitializer)
  %1905 = fmul <8 x float> %1867, %1904
  %.state1167 = load <8 x float>, ptr %.slot141, align 32
  %1906 = fadd <8 x float> %.state1167, %1905
  %.state1168 = load <8 x i64>, ptr %.slot56, align 64
  %1907 = add <8 x i64> splat (i64 600), %.state1168
  %tile_snapshot.spill.load1169 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1908 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1169, 0
  %1909 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1169, 1
  %1910 = mul <8 x i64> %1907, splat (i64 32)
  %1911 = add <8 x i64> %1909, %1910
  %1912 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1908, 0
  %1913 = insertvalue { <8 x ptr>, <8 x i64> } %1912, <8 x i64> %1911, 1
  %1914 = extractvalue { <8 x ptr>, <8 x i64> } %1913, 0
  %1915 = extractvalue { <8 x ptr>, <8 x i64> } %1913, 1
  %1916 = getelementptr i8, <8 x ptr> %1914, <8 x i64> %1915
  %1917 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1916, <8 x i1> %1851, <8 x float> zeroinitializer)
  %1918 = fmul <8 x float> %1867, %1917
  %.state1170 = load <8 x float>, ptr %.slot142, align 32
  %1919 = fadd <8 x float> %.state1170, %1918
  %.state1171 = load <8 x i64>, ptr %.slot56, align 64
  %1920 = add <8 x i64> %.state1171, splat (i64 1)
  %1921 = load <8 x i64>, ptr %.slot56, align 64
  %1922 = select <8 x i1> %1851, <8 x i64> %1920, <8 x i64> %1921
  store <8 x i64> %1922, ptr %.slot56, align 64
  %1923 = load <8 x float>, ptr %.slot139, align 32
  %1924 = select <8 x i1> %1851, <8 x float> %1880, <8 x float> %1923
  store <8 x float> %1924, ptr %.slot139, align 32
  %1925 = load <8 x float>, ptr %.slot140, align 32
  %1926 = select <8 x i1> %1851, <8 x float> %1893, <8 x float> %1925
  store <8 x float> %1926, ptr %.slot140, align 32
  %1927 = load <8 x float>, ptr %.slot141, align 32
  %1928 = select <8 x i1> %1851, <8 x float> %1906, <8 x float> %1927
  store <8 x float> %1928, ptr %.slot141, align 32
  %1929 = load <8 x float>, ptr %.slot142, align 32
  %1930 = select <8 x i1> %1851, <8 x float> %1919, <8 x float> %1929
  store <8 x float> %1930, ptr %.slot142, align 32
  store <8 x i1> %1851, ptr %current.mask, align 1
  %1931 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1851)
  br i1 %1931, label %schedule.66, label %scheduler.loop

schedule.68:                                      ; preds = %varying.coherent.false1156, %scheduler.dispatch.route
  %1932 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1174 = load i32, ptr %current.token, align 4
  %convergence.token.present1175 = icmp ne i32 %convergence.current.token1174, 0
  br i1 %convergence.token.present1175, label %convergence.cascade1172, label %convergence.cascade.exit1173

schedule.69:                                      ; preds = %schedule.70, %convergence.target.68.ready, %scheduler.dispatch.route
  %1933 = load <8 x i1>, ptr %current.mask, align 1
  %1934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1933)
  %1935 = bitcast <8 x i1> %1933 to i8
  %1936 = call i8 @llvm.cttz.i8(i8 %1935, i1 false)
  %1937 = zext i8 %1936 to i32
  %1938 = select i1 %1934, i32 %1937, i32 0
  %.state1399 = load <8 x i64>, ptr %.slot56, align 64
  %1939 = icmp slt <8 x i64> %.state1399, splat (i64 16)
  %1940 = and <8 x i1> %1933, %1939
  %1941 = xor <8 x i1> %1939, splat (i1 true)
  %1942 = and <8 x i1> %1933, %1941
  %1943 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1940)
  %1944 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1942)
  %1945 = and i1 %1943, %1944
  br i1 %1945, label %varying.divergent1400, label %varying.coherent1401

schedule.70:                                      ; preds = %varying.coherent.true1406, %scheduler.dispatch.route
  %1946 = load <8 x i1>, ptr %current.mask, align 1
  %1947 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1946)
  %1948 = bitcast <8 x i1> %1946 to i8
  %1949 = call i8 @llvm.cttz.i8(i8 %1948, i1 false)
  %1950 = zext i8 %1949 to i32
  %1951 = select i1 %1947, i32 %1950, i32 0
  %.state1408 = load <8 x i64>, ptr %.slot56, align 64
  %1952 = select <8 x i1> %1946, <8 x i64> %.state1408, <8 x i64> zeroinitializer
  %1953 = select <8 x i1> %1946, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1954 = sdiv <8 x i64> %1952, %1953
  %1955 = add <8 x i64> zeroinitializer, %1954
  %tile_snapshot.spill.load1409 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %1956 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1409, 0
  %1957 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1409, 1
  %1958 = mul <8 x i64> %1955, splat (i64 32)
  %1959 = add <8 x i64> %1957, %1958
  %1960 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1956, 0
  %1961 = insertvalue { <8 x ptr>, <8 x i64> } %1960, <8 x i64> %1959, 1
  %1962 = extractvalue { <8 x ptr>, <8 x i64> } %1961, 0
  %1963 = extractvalue { <8 x ptr>, <8 x i64> } %1961, 1
  %1964 = getelementptr i8, <8 x ptr> %1962, <8 x i64> %1963
  %1965 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1964, <8 x i1> %1946, <8 x float> zeroinitializer)
  %.state1410 = load <8 x float>, ptr %.slot58, align 32
  %1966 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1410, <8 x float> %1965)
  %.state1411 = load <8 x i64>, ptr %.slot56, align 64
  %1967 = add <8 x i64> %.state1411, splat (i64 1)
  %1968 = load <8 x i64>, ptr %.slot56, align 64
  %1969 = select <8 x i1> %1946, <8 x i64> %1967, <8 x i64> %1968
  store <8 x i64> %1969, ptr %.slot56, align 64
  %1970 = load <8 x float>, ptr %.slot58, align 32
  %1971 = select <8 x i1> %1946, <8 x float> %1966, <8 x float> %1970
  store <8 x float> %1971, ptr %.slot58, align 32
  store <8 x i1> %1946, ptr %current.mask, align 1
  %1972 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1946)
  br i1 %1972, label %schedule.69, label %scheduler.loop

schedule.71:                                      ; preds = %varying.coherent.false1407, %scheduler.dispatch.route
  %1973 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1414 = load i32, ptr %current.token, align 4
  %convergence.token.present1415 = icmp ne i32 %convergence.current.token1414, 0
  br i1 %convergence.token.present1415, label %convergence.cascade1412, label %convergence.cascade.exit1413

schedule.72:                                      ; preds = %schedule.73, %convergence.target.71.ready, %scheduler.dispatch.route
  %1974 = load <8 x i1>, ptr %current.mask, align 1
  %1975 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1974)
  %1976 = bitcast <8 x i1> %1974 to i8
  %1977 = call i8 @llvm.cttz.i8(i8 %1976, i1 false)
  %1978 = zext i8 %1977 to i32
  %1979 = select i1 %1975, i32 %1978, i32 0
  %.state1429 = load <8 x i64>, ptr %.slot56, align 64
  %1980 = icmp slt <8 x i64> %.state1429, splat (i64 16)
  %1981 = and <8 x i1> %1974, %1980
  %1982 = xor <8 x i1> %1980, splat (i1 true)
  %1983 = and <8 x i1> %1974, %1982
  %1984 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1981)
  %1985 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1983)
  %1986 = and i1 %1984, %1985
  br i1 %1986, label %varying.divergent1430, label %varying.coherent1431

schedule.73:                                      ; preds = %varying.coherent.true1436, %scheduler.dispatch.route
  %1987 = load <8 x i1>, ptr %current.mask, align 1
  %1988 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1987)
  %1989 = bitcast <8 x i1> %1987 to i8
  %1990 = call i8 @llvm.cttz.i8(i8 %1989, i1 false)
  %1991 = zext i8 %1990 to i32
  %1992 = select i1 %1988, i32 %1991, i32 0
  %.state1438 = load <8 x i64>, ptr %.slot56, align 64
  %1993 = select <8 x i1> %1987, <8 x i64> %.state1438, <8 x i64> zeroinitializer
  %1994 = select <8 x i1> %1987, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1995 = sdiv <8 x i64> %1993, %1994
  %1996 = add <8 x i64> splat (i64 16), %1995
  %tile_snapshot.spill.load1439 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %1997 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1439, 0
  %1998 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1439, 1
  %1999 = mul <8 x i64> %1996, splat (i64 32)
  %2000 = add <8 x i64> %1998, %1999
  %2001 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1997, 0
  %2002 = insertvalue { <8 x ptr>, <8 x i64> } %2001, <8 x i64> %2000, 1
  %2003 = extractvalue { <8 x ptr>, <8 x i64> } %2002, 0
  %2004 = extractvalue { <8 x ptr>, <8 x i64> } %2002, 1
  %2005 = getelementptr i8, <8 x ptr> %2003, <8 x i64> %2004
  %2006 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2005, <8 x i1> %1987, <8 x float> zeroinitializer)
  %.state1440 = load <8 x float>, ptr %.slot65, align 32
  %2007 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1440, <8 x float> %2006)
  %.state1441 = load <8 x i64>, ptr %.slot56, align 64
  %2008 = add <8 x i64> %.state1441, splat (i64 1)
  %2009 = load <8 x i64>, ptr %.slot56, align 64
  %2010 = select <8 x i1> %1987, <8 x i64> %2008, <8 x i64> %2009
  store <8 x i64> %2010, ptr %.slot56, align 64
  %2011 = load <8 x float>, ptr %.slot65, align 32
  %2012 = select <8 x i1> %1987, <8 x float> %2007, <8 x float> %2011
  store <8 x float> %2012, ptr %.slot65, align 32
  store <8 x i1> %1987, ptr %current.mask, align 1
  %2013 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1987)
  br i1 %2013, label %schedule.72, label %scheduler.loop

schedule.74:                                      ; preds = %varying.coherent.false1437, %scheduler.dispatch.route
  %2014 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1444 = load i32, ptr %current.token, align 4
  %convergence.token.present1445 = icmp ne i32 %convergence.current.token1444, 0
  br i1 %convergence.token.present1445, label %convergence.cascade1442, label %convergence.cascade.exit1443

schedule.75:                                      ; preds = %schedule.76, %convergence.target.74.ready, %scheduler.dispatch.route
  %2015 = load <8 x i1>, ptr %current.mask, align 1
  %2016 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2015)
  %2017 = bitcast <8 x i1> %2015 to i8
  %2018 = call i8 @llvm.cttz.i8(i8 %2017, i1 false)
  %2019 = zext i8 %2018 to i32
  %2020 = select i1 %2016, i32 %2019, i32 0
  %.state1459 = load <8 x i64>, ptr %.slot56, align 64
  %2021 = icmp slt <8 x i64> %.state1459, splat (i64 16)
  %2022 = and <8 x i1> %2015, %2021
  %2023 = xor <8 x i1> %2021, splat (i1 true)
  %2024 = and <8 x i1> %2015, %2023
  %2025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2022)
  %2026 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2024)
  %2027 = and i1 %2025, %2026
  br i1 %2027, label %varying.divergent1460, label %varying.coherent1461

schedule.76:                                      ; preds = %varying.coherent.true1466, %scheduler.dispatch.route
  %2028 = load <8 x i1>, ptr %current.mask, align 1
  %2029 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2028)
  %2030 = bitcast <8 x i1> %2028 to i8
  %2031 = call i8 @llvm.cttz.i8(i8 %2030, i1 false)
  %2032 = zext i8 %2031 to i32
  %2033 = select i1 %2029, i32 %2032, i32 0
  %.state1468 = load <8 x i64>, ptr %.slot56, align 64
  %2034 = select <8 x i1> %2028, <8 x i64> %.state1468, <8 x i64> zeroinitializer
  %2035 = select <8 x i1> %2028, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2036 = sdiv <8 x i64> %2034, %2035
  %2037 = add <8 x i64> splat (i64 32), %2036
  %tile_snapshot.spill.load1469 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %2038 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1469, 0
  %2039 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1469, 1
  %2040 = mul <8 x i64> %2037, splat (i64 32)
  %2041 = add <8 x i64> %2039, %2040
  %2042 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2038, 0
  %2043 = insertvalue { <8 x ptr>, <8 x i64> } %2042, <8 x i64> %2041, 1
  %2044 = extractvalue { <8 x ptr>, <8 x i64> } %2043, 0
  %2045 = extractvalue { <8 x ptr>, <8 x i64> } %2043, 1
  %2046 = getelementptr i8, <8 x ptr> %2044, <8 x i64> %2045
  %2047 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2046, <8 x i1> %2028, <8 x float> zeroinitializer)
  %.state1470 = load <8 x float>, ptr %.slot66, align 32
  %2048 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1470, <8 x float> %2047)
  %.state1471 = load <8 x i64>, ptr %.slot56, align 64
  %2049 = add <8 x i64> %.state1471, splat (i64 1)
  %2050 = load <8 x i64>, ptr %.slot56, align 64
  %2051 = select <8 x i1> %2028, <8 x i64> %2049, <8 x i64> %2050
  store <8 x i64> %2051, ptr %.slot56, align 64
  %2052 = load <8 x float>, ptr %.slot66, align 32
  %2053 = select <8 x i1> %2028, <8 x float> %2048, <8 x float> %2052
  store <8 x float> %2053, ptr %.slot66, align 32
  store <8 x i1> %2028, ptr %current.mask, align 1
  %2054 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2028)
  br i1 %2054, label %schedule.75, label %scheduler.loop

schedule.77:                                      ; preds = %varying.coherent.false1467, %scheduler.dispatch.route
  %2055 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1474 = load i32, ptr %current.token, align 4
  %convergence.token.present1475 = icmp ne i32 %convergence.current.token1474, 0
  br i1 %convergence.token.present1475, label %convergence.cascade1472, label %convergence.cascade.exit1473

schedule.78:                                      ; preds = %schedule.79, %convergence.target.77.ready, %scheduler.dispatch.route
  %2056 = load <8 x i1>, ptr %current.mask, align 1
  %2057 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2056)
  %2058 = bitcast <8 x i1> %2056 to i8
  %2059 = call i8 @llvm.cttz.i8(i8 %2058, i1 false)
  %2060 = zext i8 %2059 to i32
  %2061 = select i1 %2057, i32 %2060, i32 0
  %.state1489 = load <8 x i64>, ptr %.slot56, align 64
  %2062 = icmp slt <8 x i64> %.state1489, splat (i64 16)
  %2063 = and <8 x i1> %2056, %2062
  %2064 = xor <8 x i1> %2062, splat (i1 true)
  %2065 = and <8 x i1> %2056, %2064
  %2066 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2063)
  %2067 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2065)
  %2068 = and i1 %2066, %2067
  br i1 %2068, label %varying.divergent1490, label %varying.coherent1491

schedule.79:                                      ; preds = %varying.coherent.true1496, %scheduler.dispatch.route
  %2069 = load <8 x i1>, ptr %current.mask, align 1
  %2070 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2069)
  %2071 = bitcast <8 x i1> %2069 to i8
  %2072 = call i8 @llvm.cttz.i8(i8 %2071, i1 false)
  %2073 = zext i8 %2072 to i32
  %2074 = select i1 %2070, i32 %2073, i32 0
  %.state1498 = load <8 x i64>, ptr %.slot56, align 64
  %2075 = select <8 x i1> %2069, <8 x i64> %.state1498, <8 x i64> zeroinitializer
  %2076 = select <8 x i1> %2069, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2077 = sdiv <8 x i64> %2075, %2076
  %2078 = add <8 x i64> splat (i64 48), %2077
  %tile_snapshot.spill.load1499 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %2079 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1499, 0
  %2080 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1499, 1
  %2081 = mul <8 x i64> %2078, splat (i64 32)
  %2082 = add <8 x i64> %2080, %2081
  %2083 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2079, 0
  %2084 = insertvalue { <8 x ptr>, <8 x i64> } %2083, <8 x i64> %2082, 1
  %2085 = extractvalue { <8 x ptr>, <8 x i64> } %2084, 0
  %2086 = extractvalue { <8 x ptr>, <8 x i64> } %2084, 1
  %2087 = getelementptr i8, <8 x ptr> %2085, <8 x i64> %2086
  %2088 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2087, <8 x i1> %2069, <8 x float> zeroinitializer)
  %.state1500 = load <8 x float>, ptr %.slot67, align 32
  %2089 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1500, <8 x float> %2088)
  %.state1501 = load <8 x i64>, ptr %.slot56, align 64
  %2090 = add <8 x i64> %.state1501, splat (i64 1)
  %2091 = load <8 x i64>, ptr %.slot56, align 64
  %2092 = select <8 x i1> %2069, <8 x i64> %2090, <8 x i64> %2091
  store <8 x i64> %2092, ptr %.slot56, align 64
  %2093 = load <8 x float>, ptr %.slot67, align 32
  %2094 = select <8 x i1> %2069, <8 x float> %2089, <8 x float> %2093
  store <8 x float> %2094, ptr %.slot67, align 32
  store <8 x i1> %2069, ptr %current.mask, align 1
  %2095 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2069)
  br i1 %2095, label %schedule.78, label %scheduler.loop

schedule.80:                                      ; preds = %varying.coherent.false1497, %scheduler.dispatch.route
  %2096 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1504 = load i32, ptr %current.token, align 4
  %convergence.token.present1505 = icmp ne i32 %convergence.current.token1504, 0
  br i1 %convergence.token.present1505, label %convergence.cascade1502, label %convergence.cascade.exit1503

schedule.81:                                      ; preds = %schedule.82, %convergence.target.80.ready, %scheduler.dispatch.route
  %2097 = load <8 x i1>, ptr %current.mask, align 1
  %2098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2097)
  %2099 = bitcast <8 x i1> %2097 to i8
  %2100 = call i8 @llvm.cttz.i8(i8 %2099, i1 false)
  %2101 = zext i8 %2100 to i32
  %2102 = select i1 %2098, i32 %2101, i32 0
  %.state1866 = load <8 x i64>, ptr %.slot56, align 64
  %2103 = icmp slt <8 x i64> %.state1866, splat (i64 16)
  %2104 = and <8 x i1> %2097, %2103
  %2105 = xor <8 x i1> %2103, splat (i1 true)
  %2106 = and <8 x i1> %2097, %2105
  %2107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2104)
  %2108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2106)
  %2109 = and i1 %2107, %2108
  br i1 %2109, label %varying.divergent1867, label %varying.coherent1868

schedule.82:                                      ; preds = %varying.coherent.true1873, %scheduler.dispatch.route
  %2110 = load <8 x i1>, ptr %current.mask, align 1
  %2111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2110)
  %2112 = bitcast <8 x i1> %2110 to i8
  %2113 = call i8 @llvm.cttz.i8(i8 %2112, i1 false)
  %2114 = zext i8 %2113 to i32
  %2115 = select i1 %2111, i32 %2114, i32 0
  %.state1875 = load <8 x i64>, ptr %.slot56, align 64
  %2116 = select <8 x i1> %2110, <8 x i64> %.state1875, <8 x i64> zeroinitializer
  %2117 = select <8 x i1> %2110, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2118 = sdiv <8 x i64> %2116, %2117
  %2119 = add <8 x i64> zeroinitializer, %2118
  %tile_snapshot.spill.load1876 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %2120 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1876, 0
  %2121 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1876, 1
  %2122 = mul <8 x i64> %2119, splat (i64 32)
  %2123 = add <8 x i64> %2121, %2122
  %2124 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2120, 0
  %2125 = insertvalue { <8 x ptr>, <8 x i64> } %2124, <8 x i64> %2123, 1
  %2126 = extractvalue { <8 x ptr>, <8 x i64> } %2125, 0
  %2127 = extractvalue { <8 x ptr>, <8 x i64> } %2125, 1
  %2128 = getelementptr i8, <8 x ptr> %2126, <8 x i64> %2127
  %2129 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2128, <8 x i1> %2110, <8 x float> zeroinitializer)
  %.state1877 = load <8 x float>, ptr %.slot41, align 32
  %2130 = fadd <8 x float> %.state1877, %2129
  %.state1878 = load <8 x i64>, ptr %.slot56, align 64
  %2131 = add <8 x i64> %.state1878, splat (i64 1)
  %2132 = load <8 x i64>, ptr %.slot56, align 64
  %2133 = select <8 x i1> %2110, <8 x i64> %2131, <8 x i64> %2132
  store <8 x i64> %2133, ptr %.slot56, align 64
  %2134 = load <8 x float>, ptr %.slot41, align 32
  %2135 = select <8 x i1> %2110, <8 x float> %2130, <8 x float> %2134
  store <8 x float> %2135, ptr %.slot41, align 32
  store <8 x i1> %2110, ptr %current.mask, align 1
  %2136 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2110)
  br i1 %2136, label %schedule.81, label %scheduler.loop

schedule.83:                                      ; preds = %varying.coherent.false1874, %scheduler.dispatch.route
  %2137 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1881 = load i32, ptr %current.token, align 4
  %convergence.token.present1882 = icmp ne i32 %convergence.current.token1881, 0
  br i1 %convergence.token.present1882, label %convergence.cascade1879, label %convergence.cascade.exit1880

schedule.84:                                      ; preds = %schedule.85, %convergence.target.83.ready, %scheduler.dispatch.route
  %2138 = load <8 x i1>, ptr %current.mask, align 1
  %2139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2138)
  %2140 = bitcast <8 x i1> %2138 to i8
  %2141 = call i8 @llvm.cttz.i8(i8 %2140, i1 false)
  %2142 = zext i8 %2141 to i32
  %2143 = select i1 %2139, i32 %2142, i32 0
  %.state1896 = load <8 x i64>, ptr %.slot56, align 64
  %2144 = icmp slt <8 x i64> %.state1896, splat (i64 16)
  %2145 = and <8 x i1> %2138, %2144
  %2146 = xor <8 x i1> %2144, splat (i1 true)
  %2147 = and <8 x i1> %2138, %2146
  %2148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2145)
  %2149 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2147)
  %2150 = and i1 %2148, %2149
  br i1 %2150, label %varying.divergent1897, label %varying.coherent1898

schedule.85:                                      ; preds = %varying.coherent.true1903, %scheduler.dispatch.route
  %2151 = load <8 x i1>, ptr %current.mask, align 1
  %2152 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2151)
  %2153 = bitcast <8 x i1> %2151 to i8
  %2154 = call i8 @llvm.cttz.i8(i8 %2153, i1 false)
  %2155 = zext i8 %2154 to i32
  %2156 = select i1 %2152, i32 %2155, i32 0
  %.state1905 = load <8 x i64>, ptr %.slot56, align 64
  %2157 = select <8 x i1> %2151, <8 x i64> %.state1905, <8 x i64> zeroinitializer
  %2158 = select <8 x i1> %2151, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2159 = sdiv <8 x i64> %2157, %2158
  %2160 = add <8 x i64> splat (i64 16), %2159
  %tile_snapshot.spill.load1906 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %2161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1906, 0
  %2162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1906, 1
  %2163 = mul <8 x i64> %2160, splat (i64 32)
  %2164 = add <8 x i64> %2162, %2163
  %2165 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2161, 0
  %2166 = insertvalue { <8 x ptr>, <8 x i64> } %2165, <8 x i64> %2164, 1
  %2167 = extractvalue { <8 x ptr>, <8 x i64> } %2166, 0
  %2168 = extractvalue { <8 x ptr>, <8 x i64> } %2166, 1
  %2169 = getelementptr i8, <8 x ptr> %2167, <8 x i64> %2168
  %2170 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2169, <8 x i1> %2151, <8 x float> zeroinitializer)
  %.state1907 = load <8 x float>, ptr %.slot47, align 32
  %2171 = fadd <8 x float> %.state1907, %2170
  %.state1908 = load <8 x i64>, ptr %.slot56, align 64
  %2172 = add <8 x i64> %.state1908, splat (i64 1)
  %2173 = load <8 x i64>, ptr %.slot56, align 64
  %2174 = select <8 x i1> %2151, <8 x i64> %2172, <8 x i64> %2173
  store <8 x i64> %2174, ptr %.slot56, align 64
  %2175 = load <8 x float>, ptr %.slot47, align 32
  %2176 = select <8 x i1> %2151, <8 x float> %2171, <8 x float> %2175
  store <8 x float> %2176, ptr %.slot47, align 32
  store <8 x i1> %2151, ptr %current.mask, align 1
  %2177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2151)
  br i1 %2177, label %schedule.84, label %scheduler.loop

schedule.86:                                      ; preds = %varying.coherent.false1904, %scheduler.dispatch.route
  %2178 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1911 = load i32, ptr %current.token, align 4
  %convergence.token.present1912 = icmp ne i32 %convergence.current.token1911, 0
  br i1 %convergence.token.present1912, label %convergence.cascade1909, label %convergence.cascade.exit1910

schedule.87:                                      ; preds = %schedule.88, %convergence.target.86.ready, %scheduler.dispatch.route
  %2179 = load <8 x i1>, ptr %current.mask, align 1
  %2180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2179)
  %2181 = bitcast <8 x i1> %2179 to i8
  %2182 = call i8 @llvm.cttz.i8(i8 %2181, i1 false)
  %2183 = zext i8 %2182 to i32
  %2184 = select i1 %2180, i32 %2183, i32 0
  %.state1926 = load <8 x i64>, ptr %.slot56, align 64
  %2185 = icmp slt <8 x i64> %.state1926, splat (i64 16)
  %2186 = and <8 x i1> %2179, %2185
  %2187 = xor <8 x i1> %2185, splat (i1 true)
  %2188 = and <8 x i1> %2179, %2187
  %2189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2186)
  %2190 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2188)
  %2191 = and i1 %2189, %2190
  br i1 %2191, label %varying.divergent1927, label %varying.coherent1928

schedule.88:                                      ; preds = %varying.coherent.true1933, %scheduler.dispatch.route
  %2192 = load <8 x i1>, ptr %current.mask, align 1
  %2193 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2192)
  %2194 = bitcast <8 x i1> %2192 to i8
  %2195 = call i8 @llvm.cttz.i8(i8 %2194, i1 false)
  %2196 = zext i8 %2195 to i32
  %2197 = select i1 %2193, i32 %2196, i32 0
  %.state1935 = load <8 x i64>, ptr %.slot56, align 64
  %2198 = select <8 x i1> %2192, <8 x i64> %.state1935, <8 x i64> zeroinitializer
  %2199 = select <8 x i1> %2192, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2200 = sdiv <8 x i64> %2198, %2199
  %2201 = add <8 x i64> splat (i64 32), %2200
  %tile_snapshot.spill.load1936 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %2202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1936, 0
  %2203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1936, 1
  %2204 = mul <8 x i64> %2201, splat (i64 32)
  %2205 = add <8 x i64> %2203, %2204
  %2206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2202, 0
  %2207 = insertvalue { <8 x ptr>, <8 x i64> } %2206, <8 x i64> %2205, 1
  %2208 = extractvalue { <8 x ptr>, <8 x i64> } %2207, 0
  %2209 = extractvalue { <8 x ptr>, <8 x i64> } %2207, 1
  %2210 = getelementptr i8, <8 x ptr> %2208, <8 x i64> %2209
  %2211 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2210, <8 x i1> %2192, <8 x float> zeroinitializer)
  %.state1937 = load <8 x float>, ptr %.slot48, align 32
  %2212 = fadd <8 x float> %.state1937, %2211
  %.state1938 = load <8 x i64>, ptr %.slot56, align 64
  %2213 = add <8 x i64> %.state1938, splat (i64 1)
  %2214 = load <8 x i64>, ptr %.slot56, align 64
  %2215 = select <8 x i1> %2192, <8 x i64> %2213, <8 x i64> %2214
  store <8 x i64> %2215, ptr %.slot56, align 64
  %2216 = load <8 x float>, ptr %.slot48, align 32
  %2217 = select <8 x i1> %2192, <8 x float> %2212, <8 x float> %2216
  store <8 x float> %2217, ptr %.slot48, align 32
  store <8 x i1> %2192, ptr %current.mask, align 1
  %2218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2192)
  br i1 %2218, label %schedule.87, label %scheduler.loop

schedule.89:                                      ; preds = %varying.coherent.false1934, %scheduler.dispatch.route
  %2219 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1941 = load i32, ptr %current.token, align 4
  %convergence.token.present1942 = icmp ne i32 %convergence.current.token1941, 0
  br i1 %convergence.token.present1942, label %convergence.cascade1939, label %convergence.cascade.exit1940

schedule.90:                                      ; preds = %schedule.91, %convergence.target.89.ready, %scheduler.dispatch.route
  %2220 = load <8 x i1>, ptr %current.mask, align 1
  %2221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2220)
  %2222 = bitcast <8 x i1> %2220 to i8
  %2223 = call i8 @llvm.cttz.i8(i8 %2222, i1 false)
  %2224 = zext i8 %2223 to i32
  %2225 = select i1 %2221, i32 %2224, i32 0
  %.state1956 = load <8 x i64>, ptr %.slot56, align 64
  %2226 = icmp slt <8 x i64> %.state1956, splat (i64 16)
  %2227 = and <8 x i1> %2220, %2226
  %2228 = xor <8 x i1> %2226, splat (i1 true)
  %2229 = and <8 x i1> %2220, %2228
  %2230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2227)
  %2231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2229)
  %2232 = and i1 %2230, %2231
  br i1 %2232, label %varying.divergent1957, label %varying.coherent1958

schedule.91:                                      ; preds = %varying.coherent.true1963, %scheduler.dispatch.route
  %2233 = load <8 x i1>, ptr %current.mask, align 1
  %2234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2233)
  %2235 = bitcast <8 x i1> %2233 to i8
  %2236 = call i8 @llvm.cttz.i8(i8 %2235, i1 false)
  %2237 = zext i8 %2236 to i32
  %2238 = select i1 %2234, i32 %2237, i32 0
  %.state1965 = load <8 x i64>, ptr %.slot56, align 64
  %2239 = select <8 x i1> %2233, <8 x i64> %.state1965, <8 x i64> zeroinitializer
  %2240 = select <8 x i1> %2233, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2241 = sdiv <8 x i64> %2239, %2240
  %2242 = add <8 x i64> splat (i64 48), %2241
  %tile_snapshot.spill.load1966 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %2243 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1966, 0
  %2244 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1966, 1
  %2245 = mul <8 x i64> %2242, splat (i64 32)
  %2246 = add <8 x i64> %2244, %2245
  %2247 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2243, 0
  %2248 = insertvalue { <8 x ptr>, <8 x i64> } %2247, <8 x i64> %2246, 1
  %2249 = extractvalue { <8 x ptr>, <8 x i64> } %2248, 0
  %2250 = extractvalue { <8 x ptr>, <8 x i64> } %2248, 1
  %2251 = getelementptr i8, <8 x ptr> %2249, <8 x i64> %2250
  %2252 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2251, <8 x i1> %2233, <8 x float> zeroinitializer)
  %.state1967 = load <8 x float>, ptr %.slot49, align 32
  %2253 = fadd <8 x float> %.state1967, %2252
  %.state1968 = load <8 x i64>, ptr %.slot56, align 64
  %2254 = add <8 x i64> %.state1968, splat (i64 1)
  %2255 = load <8 x i64>, ptr %.slot56, align 64
  %2256 = select <8 x i1> %2233, <8 x i64> %2254, <8 x i64> %2255
  store <8 x i64> %2256, ptr %.slot56, align 64
  %2257 = load <8 x float>, ptr %.slot49, align 32
  %2258 = select <8 x i1> %2233, <8 x float> %2253, <8 x float> %2257
  store <8 x float> %2258, ptr %.slot49, align 32
  store <8 x i1> %2233, ptr %current.mask, align 1
  %2259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2233)
  br i1 %2259, label %schedule.90, label %scheduler.loop

schedule.92:                                      ; preds = %varying.coherent.false1964, %scheduler.dispatch.route
  %2260 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1971 = load i32, ptr %current.token, align 4
  %convergence.token.present1972 = icmp ne i32 %convergence.current.token1971, 0
  br i1 %convergence.token.present1972, label %convergence.cascade1969, label %convergence.cascade.exit1970

schedule.93:                                      ; preds = %convergence.target.100.ready, %convergence.target.92.ready, %scheduler.dispatch.route
  %2261 = load <8 x i1>, ptr %current.mask, align 1
  %2262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2261)
  %2263 = bitcast <8 x i1> %2261 to i8
  %2264 = call i8 @llvm.cttz.i8(i8 %2263, i1 false)
  %2265 = zext i8 %2264 to i32
  %2266 = select i1 %2262, i32 %2265, i32 0
  %.state1994 = load <8 x i64>, ptr %.slot56, align 64
  %2267 = icmp slt <8 x i64> %.state1994, splat (i64 4)
  %2268 = and <8 x i1> %2261, %2267
  %2269 = xor <8 x i1> %2267, splat (i1 true)
  %2270 = and <8 x i1> %2261, %2269
  %2271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2268)
  %2272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2270)
  %2273 = and i1 %2271, %2272
  br i1 %2273, label %varying.divergent1995, label %varying.coherent1996

schedule.94:                                      ; preds = %varying.coherent.true2001, %scheduler.dispatch.route
  %2274 = load <8 x i1>, ptr %current.mask, align 1
  %2275 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2274)
  %2276 = bitcast <8 x i1> %2274 to i8
  %2277 = call i8 @llvm.cttz.i8(i8 %2276, i1 false)
  %2278 = zext i8 %2277 to i32
  %2279 = select i1 %2275, i32 %2278, i32 0
  %2280 = load <8 x i64>, ptr %.slot304, align 64
  %2281 = select <8 x i1> %2274, <8 x i64> zeroinitializer, <8 x i64> %2280
  store <8 x i64> %2281, ptr %.slot304, align 64
  store <8 x i1> %2274, ptr %current.mask, align 1
  %2282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2274)
  br i1 %2282, label %schedule.95, label %scheduler.loop

schedule.95:                                      ; preds = %convergence.target.99.ready, %schedule.94, %scheduler.dispatch.route
  %2283 = load <8 x i1>, ptr %current.mask, align 1
  %2284 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2283)
  %2285 = bitcast <8 x i1> %2283 to i8
  %2286 = call i8 @llvm.cttz.i8(i8 %2285, i1 false)
  %2287 = zext i8 %2286 to i32
  %2288 = select i1 %2284, i32 %2287, i32 0
  %.state2003 = load <8 x i64>, ptr %.slot304, align 64
  %2289 = icmp slt <8 x i64> %.state2003, splat (i64 12)
  %2290 = and <8 x i1> %2283, %2289
  %2291 = xor <8 x i1> %2289, splat (i1 true)
  %2292 = and <8 x i1> %2283, %2291
  %2293 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2290)
  %2294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2292)
  %2295 = and i1 %2293, %2294
  br i1 %2295, label %varying.divergent2004, label %varying.coherent2005

schedule.96:                                      ; preds = %varying.coherent.true2010, %scheduler.dispatch.route
  %2296 = load <8 x i1>, ptr %current.mask, align 1
  %2297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2296)
  %2298 = bitcast <8 x i1> %2296 to i8
  %2299 = call i8 @llvm.cttz.i8(i8 %2298, i1 false)
  %2300 = zext i8 %2299 to i32
  %2301 = select i1 %2297, i32 %2300, i32 0
  %.state2012 = load <8 x i64>, ptr %.slot56, align 64
  %2302 = mul <8 x i64> %.state2012, splat (i64 48)
  %.state2013 = load <8 x i64>, ptr %.slot304, align 64
  %2303 = mul <8 x i64> %.state2013, splat (i64 4)
  %2304 = add <8 x i64> %2302, %2303
  %2305 = add <8 x i64> %2304, zeroinitializer
  %2306 = load <8 x i64>, ptr %.spill305, align 64
  %2307 = select <8 x i1> %2296, <8 x i64> %2305, <8 x i64> %2306
  store <8 x i64> %2307, ptr %.spill305, align 64
  %2308 = select <8 x i1> %2296, <8 x i64> %2305, <8 x i64> zeroinitializer
  %2309 = select <8 x i1> %2296, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2310 = srem <8 x i64> %2308, %2309
  %2311 = load <8 x i64>, ptr %.spill306, align 64
  %2312 = select <8 x i1> %2296, <8 x i64> %2310, <8 x i64> %2311
  store <8 x i64> %2312, ptr %.spill306, align 64
  %2313 = select <8 x i1> %2296, <8 x i64> %2305, <8 x i64> zeroinitializer
  %2314 = select <8 x i1> %2296, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2315 = sdiv <8 x i64> %2313, %2314
  %2316 = add <8 x i64> zeroinitializer, %2315
  %2317 = load <8 x i64>, ptr %.spill307, align 64
  %2318 = select <8 x i1> %2296, <8 x i64> %2316, <8 x i64> %2317
  store <8 x i64> %2318, ptr %.spill307, align 64
  %2319 = mul <8 x i64> %2316, splat (i64 48)
  %2320 = add <8 x i64> %2319, %2310
  %tile_snapshot.spill.load2014 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2014, 0
  %2322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2014, 1
  %2323 = mul <8 x i64> %2320, splat (i64 32)
  %2324 = add <8 x i64> %2322, %2323
  %2325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2321, 0
  %2326 = insertvalue { <8 x ptr>, <8 x i64> } %2325, <8 x i64> %2324, 1
  %2327 = extractvalue { <8 x ptr>, <8 x i64> } %2326, 0
  %2328 = extractvalue { <8 x ptr>, <8 x i64> } %2326, 1
  %2329 = getelementptr i8, <8 x ptr> %2327, <8 x i64> %2328
  %2330 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2329, <8 x i1> %2296, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2015 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill284, align 64
  %2331 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2015, 0
  %2332 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2015, 1
  %2333 = mul <8 x i64> %2316, splat (i64 32)
  %2334 = add <8 x i64> %2332, %2333
  %2335 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2331, 0
  %2336 = insertvalue { <8 x ptr>, <8 x i64> } %2335, <8 x i64> %2334, 1
  %2337 = extractvalue { <8 x ptr>, <8 x i64> } %2336, 0
  %2338 = extractvalue { <8 x ptr>, <8 x i64> } %2336, 1
  %2339 = getelementptr i8, <8 x ptr> %2337, <8 x i64> %2338
  %2340 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2339, <8 x i1> %2296, <8 x float> zeroinitializer)
  %2341 = fmul <8 x float> %2330, %2340
  %2342 = add <8 x i64> %2304, splat (i64 1)
  %2343 = load <8 x i64>, ptr %.spill308, align 64
  %2344 = select <8 x i1> %2296, <8 x i64> %2342, <8 x i64> %2343
  store <8 x i64> %2344, ptr %.spill308, align 64
  %2345 = select <8 x i1> %2296, <8 x i64> %2342, <8 x i64> zeroinitializer
  %2346 = select <8 x i1> %2296, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2347 = srem <8 x i64> %2345, %2346
  %2348 = load <8 x i64>, ptr %.spill309, align 64
  %2349 = select <8 x i1> %2296, <8 x i64> %2347, <8 x i64> %2348
  store <8 x i64> %2349, ptr %.spill309, align 64
  %2350 = select <8 x i1> %2296, <8 x i64> %2342, <8 x i64> zeroinitializer
  %2351 = select <8 x i1> %2296, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2352 = sdiv <8 x i64> %2350, %2351
  %2353 = add <8 x i64> zeroinitializer, %2352
  %2354 = mul <8 x i64> %2353, splat (i64 48)
  %2355 = add <8 x i64> %2354, %2347
  %tile_snapshot.spill.load2016 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2356 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2016, 0
  %2357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2016, 1
  %2358 = mul <8 x i64> %2355, splat (i64 32)
  %2359 = add <8 x i64> %2357, %2358
  %2360 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2356, 0
  %2361 = insertvalue { <8 x ptr>, <8 x i64> } %2360, <8 x i64> %2359, 1
  %2362 = extractvalue { <8 x ptr>, <8 x i64> } %2361, 0
  %2363 = extractvalue { <8 x ptr>, <8 x i64> } %2361, 1
  %2364 = getelementptr i8, <8 x ptr> %2362, <8 x i64> %2363
  %2365 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2364, <8 x i1> %2296, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2017 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill284, align 64
  %2366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2017, 0
  %2367 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2017, 1
  %2368 = mul <8 x i64> %2353, splat (i64 32)
  %2369 = add <8 x i64> %2367, %2368
  %2370 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2366, 0
  %2371 = insertvalue { <8 x ptr>, <8 x i64> } %2370, <8 x i64> %2369, 1
  %2372 = extractvalue { <8 x ptr>, <8 x i64> } %2371, 0
  %2373 = extractvalue { <8 x ptr>, <8 x i64> } %2371, 1
  %2374 = getelementptr i8, <8 x ptr> %2372, <8 x i64> %2373
  %2375 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2374, <8 x i1> %2296, <8 x float> zeroinitializer)
  %2376 = fmul <8 x float> %2365, %2375
  %2377 = add <8 x i64> %2304, splat (i64 2)
  %2378 = load <8 x i64>, ptr %.spill310, align 64
  %2379 = select <8 x i1> %2296, <8 x i64> %2377, <8 x i64> %2378
  store <8 x i64> %2379, ptr %.spill310, align 64
  %2380 = select <8 x i1> %2296, <8 x i64> %2377, <8 x i64> zeroinitializer
  %2381 = select <8 x i1> %2296, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2382 = srem <8 x i64> %2380, %2381
  %2383 = load <8 x i64>, ptr %.spill311, align 64
  %2384 = select <8 x i1> %2296, <8 x i64> %2382, <8 x i64> %2383
  store <8 x i64> %2384, ptr %.spill311, align 64
  %2385 = select <8 x i1> %2296, <8 x i64> %2377, <8 x i64> zeroinitializer
  %2386 = select <8 x i1> %2296, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2387 = sdiv <8 x i64> %2385, %2386
  %2388 = add <8 x i64> zeroinitializer, %2387
  %2389 = mul <8 x i64> %2388, splat (i64 48)
  %2390 = add <8 x i64> %2389, %2382
  %tile_snapshot.spill.load2018 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2391 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2018, 0
  %2392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2018, 1
  %2393 = mul <8 x i64> %2390, splat (i64 32)
  %2394 = add <8 x i64> %2392, %2393
  %2395 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2391, 0
  %2396 = insertvalue { <8 x ptr>, <8 x i64> } %2395, <8 x i64> %2394, 1
  %2397 = extractvalue { <8 x ptr>, <8 x i64> } %2396, 0
  %2398 = extractvalue { <8 x ptr>, <8 x i64> } %2396, 1
  %2399 = getelementptr i8, <8 x ptr> %2397, <8 x i64> %2398
  %2400 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2399, <8 x i1> %2296, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2019 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill284, align 64
  %2401 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2019, 0
  %2402 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2019, 1
  %2403 = mul <8 x i64> %2388, splat (i64 32)
  %2404 = add <8 x i64> %2402, %2403
  %2405 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2401, 0
  %2406 = insertvalue { <8 x ptr>, <8 x i64> } %2405, <8 x i64> %2404, 1
  %2407 = extractvalue { <8 x ptr>, <8 x i64> } %2406, 0
  %2408 = extractvalue { <8 x ptr>, <8 x i64> } %2406, 1
  %2409 = getelementptr i8, <8 x ptr> %2407, <8 x i64> %2408
  %2410 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2409, <8 x i1> %2296, <8 x float> zeroinitializer)
  %2411 = fmul <8 x float> %2400, %2410
  %2412 = add <8 x i64> %2304, splat (i64 3)
  %2413 = load <8 x i64>, ptr %.spill312, align 64
  %2414 = select <8 x i1> %2296, <8 x i64> %2412, <8 x i64> %2413
  store <8 x i64> %2414, ptr %.spill312, align 64
  %2415 = select <8 x i1> %2296, <8 x i64> %2412, <8 x i64> zeroinitializer
  %2416 = select <8 x i1> %2296, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2417 = srem <8 x i64> %2415, %2416
  %2418 = load <8 x i64>, ptr %.spill313, align 64
  %2419 = select <8 x i1> %2296, <8 x i64> %2417, <8 x i64> %2418
  store <8 x i64> %2419, ptr %.spill313, align 64
  %2420 = select <8 x i1> %2296, <8 x i64> %2412, <8 x i64> zeroinitializer
  %2421 = select <8 x i1> %2296, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2422 = sdiv <8 x i64> %2420, %2421
  %2423 = add <8 x i64> zeroinitializer, %2422
  %2424 = mul <8 x i64> %2423, splat (i64 48)
  %2425 = add <8 x i64> %2424, %2417
  %tile_snapshot.spill.load2020 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2020, 0
  %2427 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2020, 1
  %2428 = mul <8 x i64> %2425, splat (i64 32)
  %2429 = add <8 x i64> %2427, %2428
  %2430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2426, 0
  %2431 = insertvalue { <8 x ptr>, <8 x i64> } %2430, <8 x i64> %2429, 1
  %2432 = extractvalue { <8 x ptr>, <8 x i64> } %2431, 0
  %2433 = extractvalue { <8 x ptr>, <8 x i64> } %2431, 1
  %2434 = getelementptr i8, <8 x ptr> %2432, <8 x i64> %2433
  %2435 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2434, <8 x i1> %2296, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2021 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill284, align 64
  %2436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2021, 0
  %2437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2021, 1
  %2438 = mul <8 x i64> %2423, splat (i64 32)
  %2439 = add <8 x i64> %2437, %2438
  %2440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2436, 0
  %2441 = insertvalue { <8 x ptr>, <8 x i64> } %2440, <8 x i64> %2439, 1
  %2442 = extractvalue { <8 x ptr>, <8 x i64> } %2441, 0
  %2443 = extractvalue { <8 x ptr>, <8 x i64> } %2441, 1
  %2444 = getelementptr i8, <8 x ptr> %2442, <8 x i64> %2443
  %2445 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2444, <8 x i1> %2296, <8 x float> zeroinitializer)
  %2446 = fmul <8 x float> %2435, %2445
  %2447 = load <8 x i64>, ptr %.slot314, align 64
  %2448 = select <8 x i1> %2296, <8 x i64> zeroinitializer, <8 x i64> %2447
  store <8 x i64> %2448, ptr %.slot314, align 64
  %2449 = load <8 x float>, ptr %.slot41, align 32
  %2450 = select <8 x i1> %2296, <8 x float> %2341, <8 x float> %2449
  store <8 x float> %2450, ptr %.slot41, align 32
  %2451 = load <8 x float>, ptr %.slot47, align 32
  %2452 = select <8 x i1> %2296, <8 x float> %2376, <8 x float> %2451
  store <8 x float> %2452, ptr %.slot47, align 32
  %2453 = load <8 x float>, ptr %.slot48, align 32
  %2454 = select <8 x i1> %2296, <8 x float> %2411, <8 x float> %2453
  store <8 x float> %2454, ptr %.slot48, align 32
  %2455 = load <8 x float>, ptr %.slot49, align 32
  %2456 = select <8 x i1> %2296, <8 x float> %2446, <8 x float> %2455
  store <8 x float> %2456, ptr %.slot49, align 32
  store <8 x i1> %2296, ptr %current.mask, align 1
  %2457 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2296)
  br i1 %2457, label %schedule.97, label %scheduler.loop

schedule.97:                                      ; preds = %schedule.98, %schedule.96, %scheduler.dispatch.route
  %2458 = load <8 x i1>, ptr %current.mask, align 1
  %2459 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2458)
  %2460 = bitcast <8 x i1> %2458 to i8
  %2461 = call i8 @llvm.cttz.i8(i8 %2460, i1 false)
  %2462 = zext i8 %2461 to i32
  %2463 = select i1 %2459, i32 %2462, i32 0
  %.state2022 = load <8 x i64>, ptr %.slot314, align 64
  %2464 = icmp slt <8 x i64> %.state2022, splat (i64 16)
  %2465 = and <8 x i1> %2458, %2464
  %2466 = xor <8 x i1> %2464, splat (i1 true)
  %2467 = and <8 x i1> %2458, %2466
  %2468 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2465)
  %2469 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2467)
  %2470 = and i1 %2468, %2469
  br i1 %2470, label %varying.divergent2023, label %varying.coherent2024

schedule.98:                                      ; preds = %varying.coherent.true2029, %scheduler.dispatch.route
  %2471 = load <8 x i1>, ptr %current.mask, align 1
  %2472 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2471)
  %2473 = bitcast <8 x i1> %2471 to i8
  %2474 = call i8 @llvm.cttz.i8(i8 %2473, i1 false)
  %2475 = zext i8 %2474 to i32
  %2476 = select i1 %2472, i32 %2475, i32 0
  %.spill.load2031 = load <8 x i64>, ptr %.spill307, align 64
  %2477 = mul <8 x i64> %.spill.load2031, splat (i64 16)
  %.state2032 = load <8 x i64>, ptr %.slot314, align 64
  %2478 = add <8 x i64> %2477, %.state2032
  %tile_snapshot.spill.load2033 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %2479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2033, 0
  %2480 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2033, 1
  %2481 = mul <8 x i64> %2478, splat (i64 32)
  %2482 = add <8 x i64> %2480, %2481
  %2483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2479, 0
  %2484 = insertvalue { <8 x ptr>, <8 x i64> } %2483, <8 x i64> %2482, 1
  %2485 = extractvalue { <8 x ptr>, <8 x i64> } %2484, 0
  %2486 = extractvalue { <8 x ptr>, <8 x i64> } %2484, 1
  %2487 = getelementptr i8, <8 x ptr> %2485, <8 x i64> %2486
  %2488 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2487, <8 x i1> %2471, <8 x float> zeroinitializer)
  %.state2034 = load <8 x i64>, ptr %.slot314, align 64
  %2489 = add <8 x i64> zeroinitializer, %.state2034
  %2490 = mul <8 x i64> %2489, splat (i64 48)
  %.spill.load2035 = load <8 x i64>, ptr %.spill306, align 64
  %2491 = add <8 x i64> %2490, %.spill.load2035
  %tile_snapshot.spill.load2036 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill59, align 64
  %2492 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2036, 0
  %2493 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2036, 1
  %2494 = mul <8 x i64> %2491, splat (i64 32)
  %2495 = add <8 x i64> %2493, %2494
  %2496 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2492, 0
  %2497 = insertvalue { <8 x ptr>, <8 x i64> } %2496, <8 x i64> %2495, 1
  %2498 = extractvalue { <8 x ptr>, <8 x i64> } %2497, 0
  %2499 = extractvalue { <8 x ptr>, <8 x i64> } %2497, 1
  %2500 = getelementptr i8, <8 x ptr> %2498, <8 x i64> %2499
  %2501 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2500, <8 x i1> %2471, <8 x float> zeroinitializer)
  %2502 = fmul <8 x float> %2488, %2501
  %.state2037 = load <8 x float>, ptr %.slot41, align 32
  %2503 = fadd <8 x float> %.state2037, %2502
  %.spill.load2038 = load <8 x i64>, ptr %.spill309, align 64
  %2504 = add <8 x i64> %2490, %.spill.load2038
  %tile_snapshot.spill.load2039 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill59, align 64
  %2505 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2039, 0
  %2506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2039, 1
  %2507 = mul <8 x i64> %2504, splat (i64 32)
  %2508 = add <8 x i64> %2506, %2507
  %2509 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2505, 0
  %2510 = insertvalue { <8 x ptr>, <8 x i64> } %2509, <8 x i64> %2508, 1
  %2511 = extractvalue { <8 x ptr>, <8 x i64> } %2510, 0
  %2512 = extractvalue { <8 x ptr>, <8 x i64> } %2510, 1
  %2513 = getelementptr i8, <8 x ptr> %2511, <8 x i64> %2512
  %2514 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2513, <8 x i1> %2471, <8 x float> zeroinitializer)
  %2515 = fmul <8 x float> %2488, %2514
  %.state2040 = load <8 x float>, ptr %.slot47, align 32
  %2516 = fadd <8 x float> %.state2040, %2515
  %.spill.load2041 = load <8 x i64>, ptr %.spill311, align 64
  %2517 = add <8 x i64> %2490, %.spill.load2041
  %tile_snapshot.spill.load2042 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill59, align 64
  %2518 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2042, 0
  %2519 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2042, 1
  %2520 = mul <8 x i64> %2517, splat (i64 32)
  %2521 = add <8 x i64> %2519, %2520
  %2522 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2518, 0
  %2523 = insertvalue { <8 x ptr>, <8 x i64> } %2522, <8 x i64> %2521, 1
  %2524 = extractvalue { <8 x ptr>, <8 x i64> } %2523, 0
  %2525 = extractvalue { <8 x ptr>, <8 x i64> } %2523, 1
  %2526 = getelementptr i8, <8 x ptr> %2524, <8 x i64> %2525
  %2527 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2526, <8 x i1> %2471, <8 x float> zeroinitializer)
  %2528 = fmul <8 x float> %2488, %2527
  %.state2043 = load <8 x float>, ptr %.slot48, align 32
  %2529 = fadd <8 x float> %.state2043, %2528
  %.spill.load2044 = load <8 x i64>, ptr %.spill313, align 64
  %2530 = add <8 x i64> %2490, %.spill.load2044
  %tile_snapshot.spill.load2045 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill59, align 64
  %2531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2045, 0
  %2532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2045, 1
  %2533 = mul <8 x i64> %2530, splat (i64 32)
  %2534 = add <8 x i64> %2532, %2533
  %2535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2531, 0
  %2536 = insertvalue { <8 x ptr>, <8 x i64> } %2535, <8 x i64> %2534, 1
  %2537 = extractvalue { <8 x ptr>, <8 x i64> } %2536, 0
  %2538 = extractvalue { <8 x ptr>, <8 x i64> } %2536, 1
  %2539 = getelementptr i8, <8 x ptr> %2537, <8 x i64> %2538
  %2540 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2539, <8 x i1> %2471, <8 x float> zeroinitializer)
  %2541 = fmul <8 x float> %2488, %2540
  %.state2046 = load <8 x float>, ptr %.slot49, align 32
  %2542 = fadd <8 x float> %.state2046, %2541
  %.state2047 = load <8 x i64>, ptr %.slot314, align 64
  %2543 = add <8 x i64> %.state2047, splat (i64 1)
  %2544 = load <8 x i64>, ptr %.slot314, align 64
  %2545 = select <8 x i1> %2471, <8 x i64> %2543, <8 x i64> %2544
  store <8 x i64> %2545, ptr %.slot314, align 64
  %2546 = load <8 x float>, ptr %.slot41, align 32
  %2547 = select <8 x i1> %2471, <8 x float> %2503, <8 x float> %2546
  store <8 x float> %2547, ptr %.slot41, align 32
  %2548 = load <8 x float>, ptr %.slot47, align 32
  %2549 = select <8 x i1> %2471, <8 x float> %2516, <8 x float> %2548
  store <8 x float> %2549, ptr %.slot47, align 32
  %2550 = load <8 x float>, ptr %.slot48, align 32
  %2551 = select <8 x i1> %2471, <8 x float> %2529, <8 x float> %2550
  store <8 x float> %2551, ptr %.slot48, align 32
  %2552 = load <8 x float>, ptr %.slot49, align 32
  %2553 = select <8 x i1> %2471, <8 x float> %2542, <8 x float> %2552
  store <8 x float> %2553, ptr %.slot49, align 32
  store <8 x i1> %2471, ptr %current.mask, align 1
  %2554 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2471)
  br i1 %2554, label %schedule.97, label %scheduler.loop

schedule.99:                                      ; preds = %varying.coherent.false2030, %scheduler.dispatch.route
  %2555 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2050 = load i32, ptr %current.token, align 4
  %convergence.token.present2051 = icmp ne i32 %convergence.current.token2050, 0
  br i1 %convergence.token.present2051, label %convergence.cascade2048, label %convergence.cascade.exit2049

schedule.100:                                     ; preds = %varying.coherent.false2011, %scheduler.dispatch.route
  %2556 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2080 = load i32, ptr %current.token, align 4
  %convergence.token.present2081 = icmp ne i32 %convergence.current.token2080, 0
  br i1 %convergence.token.present2081, label %convergence.cascade2078, label %convergence.cascade.exit2079

schedule.101:                                     ; preds = %varying.coherent.false2002, %scheduler.dispatch.route
  %2557 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2098 = load i32, ptr %current.token, align 4
  %convergence.token.present2099 = icmp ne i32 %convergence.current.token2098, 0
  br i1 %convergence.token.present2099, label %convergence.cascade2096, label %convergence.cascade.exit2097

schedule.102:                                     ; preds = %schedule.103, %convergence.target.101.ready, %scheduler.dispatch.route
  %2558 = load <8 x i1>, ptr %current.mask, align 1
  %2559 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2558)
  %2560 = bitcast <8 x i1> %2558 to i8
  %2561 = call i8 @llvm.cttz.i8(i8 %2560, i1 false)
  %2562 = zext i8 %2561 to i32
  %2563 = select i1 %2559, i32 %2562, i32 0
  %.state2113 = load <8 x i64>, ptr %.slot56, align 64
  %2564 = icmp slt <8 x i64> %.state2113, splat (i64 192)
  %2565 = and <8 x i1> %2558, %2564
  %2566 = xor <8 x i1> %2564, splat (i1 true)
  %2567 = and <8 x i1> %2558, %2566
  %2568 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2565)
  %2569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2567)
  %2570 = and i1 %2568, %2569
  br i1 %2570, label %varying.divergent2114, label %varying.coherent2115

schedule.103:                                     ; preds = %varying.coherent.true2120, %scheduler.dispatch.route
  %2571 = load <8 x i1>, ptr %current.mask, align 1
  %2572 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2571)
  %2573 = bitcast <8 x i1> %2571 to i8
  %2574 = call i8 @llvm.cttz.i8(i8 %2573, i1 false)
  %2575 = zext i8 %2574 to i32
  %2576 = select i1 %2572, i32 %2575, i32 0
  %tile_snapshot.spill.load2122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill302, align 64
  %2577 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2122, 0
  %2578 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2122, 1
  %.state2123 = load <8 x i64>, ptr %.slot56, align 64
  %2579 = mul <8 x i64> %.state2123, splat (i64 32)
  %2580 = add <8 x i64> %2578, %2579
  %2581 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2577, 0
  %2582 = insertvalue { <8 x ptr>, <8 x i64> } %2581, <8 x i64> %2580, 1
  %2583 = extractvalue { <8 x ptr>, <8 x i64> } %2582, 0
  %2584 = extractvalue { <8 x ptr>, <8 x i64> } %2582, 1
  %2585 = getelementptr i8, <8 x ptr> %2583, <8 x i64> %2584
  %2586 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2585, <8 x i1> %2571, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %2587 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2124, 0
  %2588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2124, 1
  %.state2125 = load <8 x i64>, ptr %.slot56, align 64
  %2589 = mul <8 x i64> %.state2125, splat (i64 32)
  %2590 = add <8 x i64> %2588, %2589
  %2591 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2587, 0
  %2592 = insertvalue { <8 x ptr>, <8 x i64> } %2591, <8 x i64> %2590, 1
  %2593 = extractvalue { <8 x ptr>, <8 x i64> } %2592, 0
  %2594 = extractvalue { <8 x ptr>, <8 x i64> } %2592, 1
  %2595 = getelementptr i8, <8 x ptr> %2593, <8 x i64> %2594
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2586, <8 x ptr> align 1 %2595, <8 x i1> %2571)
  %.state2126 = load <8 x i64>, ptr %.slot56, align 64
  %2596 = add <8 x i64> %.state2126, splat (i64 1)
  %2597 = load <8 x i64>, ptr %.slot56, align 64
  %2598 = select <8 x i1> %2571, <8 x i64> %2596, <8 x i64> %2597
  store <8 x i64> %2598, ptr %.slot56, align 64
  store <8 x i1> %2571, ptr %current.mask, align 1
  %2599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2571)
  br i1 %2599, label %schedule.102, label %scheduler.loop

schedule.104:                                     ; preds = %varying.coherent.false2121, %scheduler.dispatch.route
  %2600 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2129 = load i32, ptr %current.token, align 4
  %convergence.token.present2130 = icmp ne i32 %convergence.current.token2129, 0
  br i1 %convergence.token.present2130, label %convergence.cascade2127, label %convergence.cascade.exit2128

schedule.105:                                     ; preds = %schedule.106, %convergence.target.104.ready, %scheduler.dispatch.route
  %2601 = load <8 x i1>, ptr %current.mask, align 1
  %2602 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2601)
  %2603 = bitcast <8 x i1> %2601 to i8
  %2604 = call i8 @llvm.cttz.i8(i8 %2603, i1 false)
  %2605 = zext i8 %2604 to i32
  %2606 = select i1 %2602, i32 %2605, i32 0
  %.state2144 = load <8 x i64>, ptr %.slot56, align 64
  %2607 = icmp slt <8 x i64> %.state2144, splat (i64 192)
  %2608 = and <8 x i1> %2601, %2607
  %2609 = xor <8 x i1> %2607, splat (i1 true)
  %2610 = and <8 x i1> %2601, %2609
  %2611 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2608)
  %2612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2610)
  %2613 = and i1 %2611, %2612
  br i1 %2613, label %varying.divergent2145, label %varying.coherent2146

schedule.106:                                     ; preds = %varying.coherent.true2151, %scheduler.dispatch.route
  %2614 = load <8 x i1>, ptr %current.mask, align 1
  %2615 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2614)
  %2616 = bitcast <8 x i1> %2614 to i8
  %2617 = call i8 @llvm.cttz.i8(i8 %2616, i1 false)
  %2618 = zext i8 %2617 to i32
  %2619 = select i1 %2615, i32 %2618, i32 0
  %tile_snapshot.spill.load2153 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %2620 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2153, 0
  %2621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2153, 1
  %.state2154 = load <8 x i64>, ptr %.slot56, align 64
  %2622 = mul <8 x i64> %.state2154, splat (i64 32)
  %2623 = add <8 x i64> %2621, %2622
  %2624 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2620, 0
  %2625 = insertvalue { <8 x ptr>, <8 x i64> } %2624, <8 x i64> %2623, 1
  %2626 = extractvalue { <8 x ptr>, <8 x i64> } %2625, 0
  %2627 = extractvalue { <8 x ptr>, <8 x i64> } %2625, 1
  %2628 = getelementptr i8, <8 x ptr> %2626, <8 x i64> %2627
  %2629 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2628, <8 x i1> %2614, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2155 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2630 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2155, 0
  %2631 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2155, 1
  %.state2156 = load <8 x i64>, ptr %.slot56, align 64
  %2632 = mul <8 x i64> %.state2156, splat (i64 32)
  %2633 = add <8 x i64> %2631, %2632
  %2634 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2630, 0
  %2635 = insertvalue { <8 x ptr>, <8 x i64> } %2634, <8 x i64> %2633, 1
  %2636 = extractvalue { <8 x ptr>, <8 x i64> } %2635, 0
  %2637 = extractvalue { <8 x ptr>, <8 x i64> } %2635, 1
  %2638 = getelementptr i8, <8 x ptr> %2636, <8 x i64> %2637
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2629, <8 x ptr> align 1 %2638, <8 x i1> %2614)
  %.state2157 = load <8 x i64>, ptr %.slot56, align 64
  %2639 = add <8 x i64> %.state2157, splat (i64 1)
  %2640 = load <8 x i64>, ptr %.slot56, align 64
  %2641 = select <8 x i1> %2614, <8 x i64> %2639, <8 x i64> %2640
  store <8 x i64> %2641, ptr %.slot56, align 64
  store <8 x i1> %2614, ptr %current.mask, align 1
  %2642 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2614)
  br i1 %2642, label %schedule.105, label %scheduler.loop

schedule.107:                                     ; preds = %varying.coherent.false2152, %scheduler.dispatch.route
  %2643 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2160 = load i32, ptr %current.token, align 4
  %convergence.token.present2161 = icmp ne i32 %convergence.current.token2160, 0
  br i1 %convergence.token.present2161, label %convergence.cascade2158, label %convergence.cascade.exit2159

schedule.108:                                     ; preds = %varying.coherent.false413, %scheduler.dispatch.route
  %2644 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2186 = load i32, ptr %current.token, align 4
  %convergence.token.present2187 = icmp ne i32 %convergence.current.token2186, 0
  br i1 %convergence.token.present2187, label %convergence.cascade2184, label %convergence.cascade.exit2185

schedule.109:                                     ; preds = %convergence.target.112.ready, %convergence.target.108.ready, %scheduler.dispatch.route
  %2645 = load <8 x i1>, ptr %current.mask, align 1
  %2646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2645)
  %2647 = bitcast <8 x i1> %2645 to i8
  %2648 = call i8 @llvm.cttz.i8(i8 %2647, i1 false)
  %2649 = zext i8 %2648 to i32
  %2650 = select i1 %2646, i32 %2649, i32 0
  %.state2213 = load <8 x i64>, ptr %.slot, align 64
  %2651 = icmp slt <8 x i64> %.state2213, splat (i64 192)
  %2652 = and <8 x i1> %2645, %2651
  %2653 = xor <8 x i1> %2651, splat (i1 true)
  %2654 = and <8 x i1> %2645, %2653
  %2655 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2652)
  %2656 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2654)
  %2657 = and i1 %2655, %2656
  br i1 %2657, label %varying.divergent2214, label %varying.coherent2215

schedule.110:                                     ; preds = %varying.coherent.true2220, %scheduler.dispatch.route
  %2658 = load <8 x i1>, ptr %current.mask, align 1
  %2659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2658)
  %2660 = bitcast <8 x i1> %2658 to i8
  %2661 = call i8 @llvm.cttz.i8(i8 %2660, i1 false)
  %2662 = zext i8 %2661 to i32
  %2663 = select i1 %2659, i32 %2662, i32 0
  %.state2222 = load <8 x i64>, ptr %.slot, align 64
  %2664 = select <8 x i1> %2658, <8 x i64> %.state2222, <8 x i64> zeroinitializer
  %2665 = select <8 x i1> %2658, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2666 = srem <8 x i64> %2664, %2665
  %.state2223 = load <8 x i64>, ptr %.slot, align 64
  %2667 = select <8 x i1> %2658, <8 x i64> %.state2223, <8 x i64> zeroinitializer
  %2668 = select <8 x i1> %2658, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2669 = sdiv <8 x i64> %2667, %2668
  %.spill.load2224 = load <8 x i64>, ptr %.spill, align 64
  %2670 = add <8 x i64> %.spill.load2224, zeroinitializer
  %2671 = add <8 x i64> zeroinitializer, %2670
  %.spill.load2225 = load <8 x i64>, ptr %.spill37, align 64
  %2672 = add <8 x i64> %.spill.load2225, zeroinitializer
  %2673 = mul <8 x i64> %2671, splat (i64 6)
  %2674 = add <8 x i64> %2673, %2672
  %.spill.load2226 = load <8 x i64>, ptr %.spill38, align 64
  %2675 = add <8 x i64> %.spill.load2226, %2669
  %2676 = mul <8 x i64> %2674, splat (i64 17)
  %2677 = add <8 x i64> %2676, %2675
  %2678 = icmp sge <8 x i64> %2675, zeroinitializer
  %2679 = and <8 x i1> splat (i1 true), %2678
  %2680 = icmp slt <8 x i64> %2675, splat (i64 17)
  %2681 = and <8 x i1> %2679, %2680
  %2682 = add <8 x i64> zeroinitializer, %2666
  %2683 = mul <8 x i64> %2677, splat (i64 48)
  %2684 = add <8 x i64> %2683, %2682
  %2685 = load <8 x i64>, ptr %.spill323, align 64
  %2686 = select <8 x i1> %2658, <8 x i64> %2684, <8 x i64> %2685
  store <8 x i64> %2686, ptr %.spill323, align 64
  %2687 = add <8 x i64> zeroinitializer, %2669
  %2688 = mul <8 x i64> %2687, splat (i64 48)
  %2689 = add <8 x i64> %2688, %2666
  %tile_snapshot.spill.load2227 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2690 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2227, 0
  %2691 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2227, 1
  %2692 = mul <8 x i64> %2689, splat (i64 32)
  %2693 = add <8 x i64> %2691, %2692
  %2694 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2690, 0
  %2695 = insertvalue { <8 x ptr>, <8 x i64> } %2694, <8 x i64> %2693, 1
  %2696 = extractvalue { <8 x ptr>, <8 x i64> } %2695, 0
  %2697 = extractvalue { <8 x ptr>, <8 x i64> } %2695, 1
  %2698 = getelementptr i8, <8 x ptr> %2696, <8 x i64> %2697
  %2699 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2698, <8 x i1> %2658, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2228 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill321, align 64
  %2700 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2228, 0
  %2701 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2228, 1
  %2702 = mul <8 x i64> %2687, splat (i64 32)
  %2703 = add <8 x i64> %2701, %2702
  %2704 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2700, 0
  %2705 = insertvalue { <8 x ptr>, <8 x i64> } %2704, <8 x i64> %2703, 1
  %2706 = extractvalue { <8 x ptr>, <8 x i64> } %2705, 0
  %2707 = extractvalue { <8 x ptr>, <8 x i64> } %2705, 1
  %2708 = getelementptr i8, <8 x ptr> %2706, <8 x i64> %2707
  %2709 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2708, <8 x i1> %2658, <8 x float> zeroinitializer)
  %2710 = fdiv <8 x float> %2699, %2709
  %2711 = load <8 x float>, ptr %.spill324, align 32
  %2712 = select <8 x i1> %2658, <8 x float> %2710, <8 x float> %2711
  store <8 x float> %2712, ptr %.spill324, align 32
  %2713 = and <8 x i1> %2658, %2681
  %2714 = xor <8 x i1> %2681, splat (i1 true)
  %2715 = and <8 x i1> %2658, %2714
  %2716 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2713)
  %2717 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2715)
  %2718 = and i1 %2716, %2717
  br i1 %2718, label %varying.divergent2229, label %varying.coherent2230

schedule.111:                                     ; preds = %varying.coherent.true2235, %scheduler.dispatch.route
  %2719 = load <8 x i1>, ptr %current.mask, align 1
  %2720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2719)
  %2721 = bitcast <8 x i1> %2719 to i8
  %2722 = call i8 @llvm.cttz.i8(i8 %2721, i1 false)
  %2723 = zext i8 %2722 to i32
  %2724 = select i1 %2720, i32 %2723, i32 0
  %.spill.load2237 = load <8 x i64>, ptr %.spill323, align 64
  %.spill.load2238 = load <8 x float>, ptr %.spill324, align 32
  %2725 = extractvalue { ptr, i64 } %53, 0
  %2726 = mul <8 x i64> %.spill.load2237, splat (i64 4)
  %2727 = getelementptr i8, ptr %2725, <8 x i64> %2726
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load2238, <8 x ptr> align 1 %2727, <8 x i1> %2719)
  store <8 x i1> %2719, ptr %current.mask, align 1
  %2728 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2719)
  br i1 %2728, label %schedule.112, label %scheduler.loop

schedule.112:                                     ; preds = %schedule.111, %varying.coherent.false2236, %scheduler.dispatch.route
  %2729 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2241 = load i32, ptr %current.token, align 4
  %convergence.token.present2242 = icmp ne i32 %convergence.current.token2241, 0
  br i1 %convergence.token.present2242, label %convergence.cascade2239, label %convergence.cascade.exit2240

schedule.113:                                     ; preds = %varying.coherent.false2221, %scheduler.dispatch.route
  %2730 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2259 = load i32, ptr %current.token, align 4
  %convergence.token.present2260 = icmp ne i32 %convergence.current.token2259, 0
  br i1 %convergence.token.present2260, label %convergence.cascade2257, label %convergence.cascade.exit2258

varying.divergent:                                ; preds = %schedule.1
  %2731 = load i32, ptr %current.token, align 4
  %2732 = icmp ne i32 %2731, 0
  %2733 = sub i32 %2731, 1
  %2734 = select i1 %2732, i32 %2733, i32 0
  %2735 = load i8, ptr %frame.active, align 1
  %2736 = trunc i32 %2734 to i8
  %2737 = shl i8 1, %2736
  %2738 = and i8 %2735, %2737
  %2739 = icmp ne i8 %2738, 0
  %2740 = load <8 x i32>, ptr %frame.static.id, align 32
  %2741 = extractelement <8 x i32> %2740, i32 %2734
  %2742 = icmp eq i32 %2741, 0
  %2743 = and i1 %2739, %2742
  %2744 = and i1 %2732, %2743
  %2745 = xor i1 %2744, true
  %2746 = and i1 true, %2745
  %2747 = xor i8 %2735, -1
  %2748 = icmp ne i8 %2747, 0
  %2749 = xor i1 %2748, true
  %2750 = and i1 %2746, %2749
  br i1 %2750, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.1
  br i1 %168, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %2751 = call i8 @llvm.cttz.i8(i8 %2747, i1 false)
  %2752 = zext i8 %2751 to i32
  %2753 = select i1 %2748, i32 %2752, i32 0
  %2754 = trunc i32 %2753 to i8
  %2755 = shl i8 1, %2754
  %2756 = or i8 %2735, %2755
  %2757 = select i1 %2746, i8 %2756, i8 %2735
  store i8 %2757, ptr %frame.active, align 1
  %2758 = load <8 x i32>, ptr %frame.static.id, align 32
  %2759 = extractelement <8 x i32> %2758, i32 %2753
  %2760 = select i1 %2746, i32 0, i32 %2759
  %2761 = load <8 x i32>, ptr %frame.static.id, align 32
  %2762 = insertelement <8 x i32> %2761, i32 %2760, i32 %2753
  store <8 x i32> %2762, ptr %frame.static.id, align 32
  %2763 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2764 = extractelement <8 x i32> %2763, i32 %2753
  %2765 = select i1 %2746, i32 %2731, i32 %2764
  %2766 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2767 = insertelement <8 x i32> %2766, i32 %2765, i32 %2753
  store <8 x i32> %2767, ptr %frame.parent.token, align 32
  %2768 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2753
  %2769 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2753
  %2770 = load <8 x i1>, ptr %2768, align 1
  %2771 = load <8 x i1>, ptr %2769, align 1
  %2772 = select i1 %2746, <8 x i1> %158, <8 x i1> %2770
  store <8 x i1> %2772, ptr %2768, align 1
  %2773 = select i1 %2746, <8 x i1> zeroinitializer, <8 x i1> %2771
  store <8 x i1> %2773, ptr %2769, align 1
  %2774 = add i32 %2753, 1
  %2775 = select i1 %2744, i32 %2731, i32 %2774
  %2776 = select i1 true, i32 %2775, i32 %2731
  store i32 %2776, ptr %current.token, align 4
  %2777 = load i32, ptr %current.token, align 4
  %2778 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %165)
  %2779 = load i32, ptr %ready.count, align 4
  %2780 = icmp uge i32 %2779, 8
  %2781 = and i1 %2778, %2780
  br i1 %2781, label %ready.overflow.trap335, label %ready.overflow.resume336

ready.overflow.trap335:                           ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume336:                         ; preds = %convergence.overflow.resume
  %2782 = select i1 %2778, i32 %2779, i32 0
  %2783 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2782
  %2784 = load <8 x i1>, ptr %2783, align 1
  %2785 = select i1 %2778, <8 x i1> %165, <8 x i1> %2784
  store <8 x i1> %2785, ptr %2783, align 1
  %2786 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2782
  %2787 = load i32, ptr %2786, align 4
  %2788 = select i1 %2778, i32 2, i32 %2787
  store i32 %2788, ptr %2786, align 4
  %2789 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2782
  %2790 = load i32, ptr %2789, align 4
  %2791 = select i1 %2778, i32 %2777, i32 %2790
  store i32 %2791, ptr %2789, align 4
  %2792 = add i32 %2779, 1
  %2793 = select i1 %2778, i32 %2792, i32 %2779
  store i32 %2793, ptr %ready.count, align 4
  %2794 = load <8 x i1>, ptr %runnable.mask, align 1
  %2795 = or <8 x i1> %2794, %165
  store <8 x i1> %2795, ptr %runnable.mask, align 1
  store <8 x i1> %167, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %158, ptr %current.mask, align 1
  %2796 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %158)
  br i1 %2796, label %schedule.2, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %158, ptr %current.mask, align 1
  %2797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %158)
  br i1 %2797, label %schedule.5, label %scheduler.loop

varying.divergent341:                             ; preds = %schedule.2
  %2798 = load i32, ptr %current.token, align 4
  %2799 = icmp ne i32 %2798, 0
  %2800 = sub i32 %2798, 1
  %2801 = select i1 %2799, i32 %2800, i32 0
  %2802 = load i8, ptr %frame.active, align 1
  %2803 = trunc i32 %2801 to i8
  %2804 = shl i8 1, %2803
  %2805 = and i8 %2802, %2804
  %2806 = icmp ne i8 %2805, 0
  %2807 = load <8 x i32>, ptr %frame.static.id, align 32
  %2808 = extractelement <8 x i32> %2807, i32 %2801
  %2809 = icmp eq i32 %2808, 1
  %2810 = and i1 %2806, %2809
  %2811 = and i1 %2799, %2810
  %2812 = xor i1 %2811, true
  %2813 = and i1 true, %2812
  %2814 = xor i8 %2802, -1
  %2815 = icmp ne i8 %2814, 0
  %2816 = xor i1 %2815, true
  %2817 = and i1 %2813, %2816
  br i1 %2817, label %convergence.overflow.trap343, label %convergence.overflow.resume344

varying.coherent342:                              ; preds = %schedule.2
  br i1 %203, label %varying.coherent.true347, label %varying.coherent.false348

convergence.overflow.trap343:                     ; preds = %varying.divergent341
  call void @llvm.trap()
  unreachable

convergence.overflow.resume344:                   ; preds = %varying.divergent341
  %2818 = call i8 @llvm.cttz.i8(i8 %2814, i1 false)
  %2819 = zext i8 %2818 to i32
  %2820 = select i1 %2815, i32 %2819, i32 0
  %2821 = trunc i32 %2820 to i8
  %2822 = shl i8 1, %2821
  %2823 = or i8 %2802, %2822
  %2824 = select i1 %2813, i8 %2823, i8 %2802
  store i8 %2824, ptr %frame.active, align 1
  %2825 = load <8 x i32>, ptr %frame.static.id, align 32
  %2826 = extractelement <8 x i32> %2825, i32 %2820
  %2827 = select i1 %2813, i32 1, i32 %2826
  %2828 = load <8 x i32>, ptr %frame.static.id, align 32
  %2829 = insertelement <8 x i32> %2828, i32 %2827, i32 %2820
  store <8 x i32> %2829, ptr %frame.static.id, align 32
  %2830 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2831 = extractelement <8 x i32> %2830, i32 %2820
  %2832 = select i1 %2813, i32 %2798, i32 %2831
  %2833 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2834 = insertelement <8 x i32> %2833, i32 %2832, i32 %2820
  store <8 x i32> %2834, ptr %frame.parent.token, align 32
  %2835 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2820
  %2836 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2820
  %2837 = load <8 x i1>, ptr %2835, align 1
  %2838 = load <8 x i1>, ptr %2836, align 1
  %2839 = select i1 %2813, <8 x i1> %171, <8 x i1> %2837
  store <8 x i1> %2839, ptr %2835, align 1
  %2840 = select i1 %2813, <8 x i1> zeroinitializer, <8 x i1> %2838
  store <8 x i1> %2840, ptr %2836, align 1
  %2841 = add i32 %2820, 1
  %2842 = select i1 %2811, i32 %2798, i32 %2841
  %2843 = select i1 true, i32 %2842, i32 %2798
  store i32 %2843, ptr %current.token, align 4
  %2844 = load <8 x float>, ptr %.slot41, align 32
  %2845 = select <8 x i1> %202, <8 x float> zeroinitializer, <8 x float> %2844
  store <8 x float> %2845, ptr %.slot41, align 32
  %2846 = load i32, ptr %current.token, align 4
  %2847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %2848 = load i32, ptr %ready.count, align 4
  %2849 = icmp uge i32 %2848, 8
  %2850 = and i1 %2847, %2849
  br i1 %2850, label %ready.overflow.trap345, label %ready.overflow.resume346

ready.overflow.trap345:                           ; preds = %convergence.overflow.resume344
  call void @llvm.trap()
  unreachable

ready.overflow.resume346:                         ; preds = %convergence.overflow.resume344
  %2851 = select i1 %2847, i32 %2848, i32 0
  %2852 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2851
  %2853 = load <8 x i1>, ptr %2852, align 1
  %2854 = select i1 %2847, <8 x i1> %200, <8 x i1> %2853
  store <8 x i1> %2854, ptr %2852, align 1
  %2855 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2851
  %2856 = load i32, ptr %2855, align 4
  %2857 = select i1 %2847, i32 3, i32 %2856
  store i32 %2857, ptr %2855, align 4
  %2858 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2851
  %2859 = load i32, ptr %2858, align 4
  %2860 = select i1 %2847, i32 %2846, i32 %2859
  store i32 %2860, ptr %2858, align 4
  %2861 = add i32 %2848, 1
  %2862 = select i1 %2847, i32 %2861, i32 %2848
  store i32 %2862, ptr %ready.count, align 4
  %2863 = load <8 x i1>, ptr %runnable.mask, align 1
  %2864 = or <8 x i1> %2863, %200
  store <8 x i1> %2864, ptr %runnable.mask, align 1
  store <8 x i1> %202, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true347:                         ; preds = %varying.coherent342
  store <8 x i1> %171, ptr %current.mask, align 1
  %2865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %171)
  br i1 %2865, label %schedule.3, label %scheduler.loop

varying.coherent.false348:                        ; preds = %varying.coherent342
  %2866 = load <8 x float>, ptr %.slot41, align 32
  %2867 = select <8 x i1> %171, <8 x float> zeroinitializer, <8 x float> %2866
  store <8 x float> %2867, ptr %.slot41, align 32
  store <8 x i1> %171, ptr %current.mask, align 1
  %2868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %171)
  br i1 %2868, label %schedule.4, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.flow = phi <8 x i1> [ %219, %schedule.4 ], [ %2911, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.4 ], [ %2912, %convergence.cascade ]
  %2869 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %2870 = load i32, ptr %current.token, align 4
  %2871 = icmp ne i32 %2870, 0
  %2872 = and i1 %2869, %2871
  %2873 = sub i32 %2870, 1
  %2874 = select i1 %2872, i32 %2873, i32 0
  %2875 = load i8, ptr %frame.active, align 1
  %2876 = trunc i32 %2874 to i8
  %2877 = shl i8 1, %2876
  %2878 = and i8 %2875, %2877
  %2879 = icmp ne i8 %2878, 0
  %2880 = load <8 x i32>, ptr %frame.static.id, align 32
  %2881 = extractelement <8 x i32> %2880, i32 %2874
  %convergence.target.pointer = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %2881
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %2882 = icmp eq i32 %convergence.dynamic.target, 4
  %2883 = and i1 %2879, %2882
  %2884 = and i1 %2872, %2883
  %2885 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2874
  %2886 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2874
  %2887 = load <8 x i1>, ptr %2885, align 1
  %2888 = load <8 x i1>, ptr %2886, align 1
  %2889 = or <8 x i1> %2888, %convergence.cascade.flow
  %2890 = load <8 x i1>, ptr %live.mask, align 1
  %2891 = and <8 x i1> %2887, %2890
  %2892 = icmp eq <8 x i1> %2889, %2891
  %2893 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2892)
  %2894 = and i1 %2884, %2893
  %2895 = select i1 %2894, <8 x i1> zeroinitializer, <8 x i1> %2889
  %2896 = select i1 %2884, <8 x i1> %2895, <8 x i1> %2888
  store <8 x i1> %2896, ptr %2886, align 1
  %2897 = select i1 %2894, <8 x i1> zeroinitializer, <8 x i1> %2887
  store <8 x i1> %2897, ptr %2885, align 1
  %2898 = trunc i32 %2874 to i8
  %2899 = shl i8 1, %2898
  %2900 = xor i8 %2899, -1
  %2901 = and i8 %2875, %2900
  %2902 = select i1 %2894, i8 %2901, i8 %2875
  store i8 %2902, ptr %frame.active, align 1
  %.splatinsert350 = insertelement <8 x i1> poison, i1 %2884, i64 0
  %.splat351 = shufflevector <8 x i1> %.splatinsert350, <8 x i1> poison, <8 x i32> zeroinitializer
  %2903 = and <8 x i1> %convergence.cascade.flow, %.splat351
  %2904 = load <8 x i1>, ptr %runnable.mask, align 1
  %2905 = xor <8 x i1> %2903, splat (i1 true)
  %2906 = and <8 x i1> %2904, %2905
  store <8 x i1> %2906, ptr %runnable.mask, align 1
  %.splatinsert352 = insertelement <8 x i1> poison, i1 %2894, i64 0
  %.splat353 = shufflevector <8 x i1> %.splatinsert352, <8 x i1> poison, <8 x i32> zeroinitializer
  %2907 = select <8 x i1> %.splat353, <8 x i1> %2889, <8 x i1> zeroinitializer
  %2908 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2909 = extractelement <8 x i32> %2908, i32 %2874
  %2910 = select i1 %2894, i32 %2909, i32 %2870
  store i32 %2910, ptr %current.token, align 4
  %.splatinsert354 = insertelement <8 x i1> poison, i1 %2884, i64 0
  %.splat355 = shufflevector <8 x i1> %.splatinsert354, <8 x i1> poison, <8 x i32> zeroinitializer
  %2911 = select <8 x i1> %.splat355, <8 x i1> %2907, <8 x i1> %convergence.cascade.flow
  %2912 = add i32 %convergence.cascade.depth, 1
  %2913 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2911)
  %2914 = icmp ult i32 %2912, 8
  %2915 = and i1 %2913, %2914
  %2916 = and i1 %2884, %2915
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %2917 = and i1 %2916, %convergence.parent.present
  br i1 %2917, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.result = phi <8 x i1> [ %219, %schedule.4 ], [ %2911, %convergence.cascade ]
  %2918 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %2918, label %convergence.target.4.ready, label %scheduler.loop

convergence.target.4.ready:                       ; preds = %convergence.cascade.exit
  %2919 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %2920 = bitcast <8 x i1> %convergence.cascade.result to i8
  %2921 = call i8 @llvm.cttz.i8(i8 %2920, i1 false)
  %2922 = zext i8 %2921 to i32
  %2923 = select i1 %2919, i32 %2922, i32 0
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2924 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %2925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state356 = load <8 x i64>, ptr %.slot, align 64
  %2926 = mul <8 x i64> %.state356, splat (i64 32)
  %2927 = add <8 x i64> %2925, %2926
  %2928 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2924, 0
  %2929 = insertvalue { <8 x ptr>, <8 x i64> } %2928, <8 x i64> %2927, 1
  %.state357 = load <8 x float>, ptr %.slot41, align 32
  %2930 = extractvalue { <8 x ptr>, <8 x i64> } %2929, 0
  %2931 = extractvalue { <8 x ptr>, <8 x i64> } %2929, 1
  %2932 = getelementptr i8, <8 x ptr> %2930, <8 x i64> %2931
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state357, <8 x ptr> align 1 %2932, <8 x i1> %convergence.cascade.result)
  %.state358 = load <8 x i64>, ptr %.slot, align 64
  %2933 = add <8 x i64> %.state358, splat (i64 1)
  %2934 = load <8 x i64>, ptr %.slot, align 64
  %2935 = select <8 x i1> %convergence.cascade.result, <8 x i64> %2933, <8 x i64> %2934
  store <8 x i64> %2935, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %2936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %2936, label %schedule.1, label %scheduler.loop

convergence.cascade359:                           ; preds = %convergence.cascade359, %schedule.5
  %convergence.cascade.flow363 = phi <8 x i1> [ %220, %schedule.5 ], [ %2979, %convergence.cascade359 ]
  %convergence.cascade.depth364 = phi i32 [ 0, %schedule.5 ], [ %2980, %convergence.cascade359 ]
  %2937 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow363)
  %2938 = load i32, ptr %current.token, align 4
  %2939 = icmp ne i32 %2938, 0
  %2940 = and i1 %2937, %2939
  %2941 = sub i32 %2938, 1
  %2942 = select i1 %2940, i32 %2941, i32 0
  %2943 = load i8, ptr %frame.active, align 1
  %2944 = trunc i32 %2942 to i8
  %2945 = shl i8 1, %2944
  %2946 = and i8 %2943, %2945
  %2947 = icmp ne i8 %2946, 0
  %2948 = load <8 x i32>, ptr %frame.static.id, align 32
  %2949 = extractelement <8 x i32> %2948, i32 %2942
  %convergence.target.pointer365 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %2949
  %convergence.dynamic.target366 = load i32, ptr %convergence.target.pointer365, align 4
  %2950 = icmp eq i32 %convergence.dynamic.target366, 5
  %2951 = and i1 %2947, %2950
  %2952 = and i1 %2940, %2951
  %2953 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2942
  %2954 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2942
  %2955 = load <8 x i1>, ptr %2953, align 1
  %2956 = load <8 x i1>, ptr %2954, align 1
  %2957 = or <8 x i1> %2956, %convergence.cascade.flow363
  %2958 = load <8 x i1>, ptr %live.mask, align 1
  %2959 = and <8 x i1> %2955, %2958
  %2960 = icmp eq <8 x i1> %2957, %2959
  %2961 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2960)
  %2962 = and i1 %2952, %2961
  %2963 = select i1 %2962, <8 x i1> zeroinitializer, <8 x i1> %2957
  %2964 = select i1 %2952, <8 x i1> %2963, <8 x i1> %2956
  store <8 x i1> %2964, ptr %2954, align 1
  %2965 = select i1 %2962, <8 x i1> zeroinitializer, <8 x i1> %2955
  store <8 x i1> %2965, ptr %2953, align 1
  %2966 = trunc i32 %2942 to i8
  %2967 = shl i8 1, %2966
  %2968 = xor i8 %2967, -1
  %2969 = and i8 %2943, %2968
  %2970 = select i1 %2962, i8 %2969, i8 %2943
  store i8 %2970, ptr %frame.active, align 1
  %.splatinsert367 = insertelement <8 x i1> poison, i1 %2952, i64 0
  %.splat368 = shufflevector <8 x i1> %.splatinsert367, <8 x i1> poison, <8 x i32> zeroinitializer
  %2971 = and <8 x i1> %convergence.cascade.flow363, %.splat368
  %2972 = load <8 x i1>, ptr %runnable.mask, align 1
  %2973 = xor <8 x i1> %2971, splat (i1 true)
  %2974 = and <8 x i1> %2972, %2973
  store <8 x i1> %2974, ptr %runnable.mask, align 1
  %.splatinsert369 = insertelement <8 x i1> poison, i1 %2962, i64 0
  %.splat370 = shufflevector <8 x i1> %.splatinsert369, <8 x i1> poison, <8 x i32> zeroinitializer
  %2975 = select <8 x i1> %.splat370, <8 x i1> %2957, <8 x i1> zeroinitializer
  %2976 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2977 = extractelement <8 x i32> %2976, i32 %2942
  %2978 = select i1 %2962, i32 %2977, i32 %2938
  store i32 %2978, ptr %current.token, align 4
  %.splatinsert371 = insertelement <8 x i1> poison, i1 %2952, i64 0
  %.splat372 = shufflevector <8 x i1> %.splatinsert371, <8 x i1> poison, <8 x i32> zeroinitializer
  %2979 = select <8 x i1> %.splat372, <8 x i1> %2975, <8 x i1> %convergence.cascade.flow363
  %2980 = add i32 %convergence.cascade.depth364, 1
  %2981 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2979)
  %2982 = icmp ult i32 %2980, 8
  %2983 = and i1 %2981, %2982
  %2984 = and i1 %2952, %2983
  %convergence.parent.token373 = load i32, ptr %current.token, align 4
  %convergence.parent.present374 = icmp ne i32 %convergence.parent.token373, 0
  %2985 = and i1 %2984, %convergence.parent.present374
  br i1 %2985, label %convergence.cascade359, label %convergence.cascade.exit360

convergence.cascade.exit360:                      ; preds = %convergence.cascade359, %schedule.5
  %convergence.cascade.result375 = phi <8 x i1> [ %220, %schedule.5 ], [ %2979, %convergence.cascade359 ]
  %2986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result375)
  br i1 %2986, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit360
  %2987 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result375)
  %2988 = bitcast <8 x i1> %convergence.cascade.result375 to i8
  %2989 = call i8 @llvm.cttz.i8(i8 %2988, i1 false)
  %2990 = zext i8 %2989 to i32
  %2991 = select i1 %2987, i32 %2990, i32 0
  %2992 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2993 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %2994 = extractvalue { <8 x ptr>, <8 x i64> } %2992, 0
  %2995 = select <8 x i1> %convergence.cascade.result375, <8 x ptr> %2993, <8 x ptr> %2994
  %2996 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %2997 = extractvalue { <8 x ptr>, <8 x i64> } %2992, 1
  %2998 = select <8 x i1> %convergence.cascade.result375, <8 x i64> %2996, <8 x i64> %2997
  %2999 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2995, 0
  %3000 = insertvalue { <8 x ptr>, <8 x i64> } %2999, <8 x i64> %2998, 1
  store { <8 x ptr>, <8 x i64> } %3000, ptr %tile_snapshot.spill42, align 64
  %3001 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %3002 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %3003 = extractvalue { <8 x ptr>, <8 x i64> } %3001, 0
  %3004 = select <8 x i1> %convergence.cascade.result375, <8 x ptr> %3002, <8 x ptr> %3003
  %3005 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %3006 = extractvalue { <8 x ptr>, <8 x i64> } %3001, 1
  %3007 = select <8 x i1> %convergence.cascade.result375, <8 x i64> %3005, <8 x i64> %3006
  %3008 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3004, 0
  %3009 = insertvalue { <8 x ptr>, <8 x i64> } %3008, <8 x i64> %3007, 1
  store { <8 x ptr>, <8 x i64> } %3009, ptr %tile_snapshot.spill43, align 64
  %3010 = load <8 x i64>, ptr %.slot, align 64
  %3011 = select <8 x i1> %convergence.cascade.result375, <8 x i64> zeroinitializer, <8 x i64> %3010
  store <8 x i64> %3011, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result375, ptr %current.mask, align 1
  %3012 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result375)
  br i1 %3012, label %schedule.6, label %scheduler.loop

varying.divergent377:                             ; preds = %schedule.6
  %3013 = load i32, ptr %current.token, align 4
  %3014 = icmp ne i32 %3013, 0
  %3015 = sub i32 %3013, 1
  %3016 = select i1 %3014, i32 %3015, i32 0
  %3017 = load i8, ptr %frame.active, align 1
  %3018 = trunc i32 %3016 to i8
  %3019 = shl i8 1, %3018
  %3020 = and i8 %3017, %3019
  %3021 = icmp ne i8 %3020, 0
  %3022 = load <8 x i32>, ptr %frame.static.id, align 32
  %3023 = extractelement <8 x i32> %3022, i32 %3016
  %3024 = icmp eq i32 %3023, 2
  %3025 = and i1 %3021, %3024
  %3026 = and i1 %3014, %3025
  %3027 = xor i1 %3026, true
  %3028 = and i1 true, %3027
  %3029 = xor i8 %3017, -1
  %3030 = icmp ne i8 %3029, 0
  %3031 = xor i1 %3030, true
  %3032 = and i1 %3028, %3031
  br i1 %3032, label %convergence.overflow.trap379, label %convergence.overflow.resume380

varying.coherent378:                              ; preds = %schedule.6
  br i1 %231, label %varying.coherent.true383, label %varying.coherent.false384

convergence.overflow.trap379:                     ; preds = %varying.divergent377
  call void @llvm.trap()
  unreachable

convergence.overflow.resume380:                   ; preds = %varying.divergent377
  %3033 = call i8 @llvm.cttz.i8(i8 %3029, i1 false)
  %3034 = zext i8 %3033 to i32
  %3035 = select i1 %3030, i32 %3034, i32 0
  %3036 = trunc i32 %3035 to i8
  %3037 = shl i8 1, %3036
  %3038 = or i8 %3017, %3037
  %3039 = select i1 %3028, i8 %3038, i8 %3017
  store i8 %3039, ptr %frame.active, align 1
  %3040 = load <8 x i32>, ptr %frame.static.id, align 32
  %3041 = extractelement <8 x i32> %3040, i32 %3035
  %3042 = select i1 %3028, i32 2, i32 %3041
  %3043 = load <8 x i32>, ptr %frame.static.id, align 32
  %3044 = insertelement <8 x i32> %3043, i32 %3042, i32 %3035
  store <8 x i32> %3044, ptr %frame.static.id, align 32
  %3045 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3046 = extractelement <8 x i32> %3045, i32 %3035
  %3047 = select i1 %3028, i32 %3013, i32 %3046
  %3048 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3049 = insertelement <8 x i32> %3048, i32 %3047, i32 %3035
  store <8 x i32> %3049, ptr %frame.parent.token, align 32
  %3050 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3035
  %3051 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3035
  %3052 = load <8 x i1>, ptr %3050, align 1
  %3053 = load <8 x i1>, ptr %3051, align 1
  %3054 = select i1 %3028, <8 x i1> %221, <8 x i1> %3052
  store <8 x i1> %3054, ptr %3050, align 1
  %3055 = select i1 %3028, <8 x i1> zeroinitializer, <8 x i1> %3053
  store <8 x i1> %3055, ptr %3051, align 1
  %3056 = add i32 %3035, 1
  %3057 = select i1 %3026, i32 %3013, i32 %3056
  %3058 = select i1 true, i32 %3057, i32 %3013
  store i32 %3058, ptr %current.token, align 4
  %3059 = load i32, ptr %current.token, align 4
  %3060 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  %3061 = load i32, ptr %ready.count, align 4
  %3062 = icmp uge i32 %3061, 8
  %3063 = and i1 %3060, %3062
  br i1 %3063, label %ready.overflow.trap381, label %ready.overflow.resume382

ready.overflow.trap381:                           ; preds = %convergence.overflow.resume380
  call void @llvm.trap()
  unreachable

ready.overflow.resume382:                         ; preds = %convergence.overflow.resume380
  %3064 = select i1 %3060, i32 %3061, i32 0
  %3065 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3064
  %3066 = load <8 x i1>, ptr %3065, align 1
  %3067 = select i1 %3060, <8 x i1> %228, <8 x i1> %3066
  store <8 x i1> %3067, ptr %3065, align 1
  %3068 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3064
  %3069 = load i32, ptr %3068, align 4
  %3070 = select i1 %3060, i32 7, i32 %3069
  store i32 %3070, ptr %3068, align 4
  %3071 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3064
  %3072 = load i32, ptr %3071, align 4
  %3073 = select i1 %3060, i32 %3059, i32 %3072
  store i32 %3073, ptr %3071, align 4
  %3074 = add i32 %3061, 1
  %3075 = select i1 %3060, i32 %3074, i32 %3061
  store i32 %3075, ptr %ready.count, align 4
  %3076 = load <8 x i1>, ptr %runnable.mask, align 1
  %3077 = or <8 x i1> %3076, %228
  store <8 x i1> %3077, ptr %runnable.mask, align 1
  store <8 x i1> %230, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true383:                         ; preds = %varying.coherent378
  store <8 x i1> %221, ptr %current.mask, align 1
  %3078 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  br i1 %3078, label %schedule.7, label %scheduler.loop

varying.coherent.false384:                        ; preds = %varying.coherent378
  store <8 x i1> %221, ptr %current.mask, align 1
  %3079 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  br i1 %3079, label %schedule.8, label %scheduler.loop

convergence.cascade388:                           ; preds = %convergence.cascade388, %schedule.8
  %convergence.cascade.flow392 = phi <8 x i1> [ %253, %schedule.8 ], [ %3122, %convergence.cascade388 ]
  %convergence.cascade.depth393 = phi i32 [ 0, %schedule.8 ], [ %3123, %convergence.cascade388 ]
  %3080 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow392)
  %3081 = load i32, ptr %current.token, align 4
  %3082 = icmp ne i32 %3081, 0
  %3083 = and i1 %3080, %3082
  %3084 = sub i32 %3081, 1
  %3085 = select i1 %3083, i32 %3084, i32 0
  %3086 = load i8, ptr %frame.active, align 1
  %3087 = trunc i32 %3085 to i8
  %3088 = shl i8 1, %3087
  %3089 = and i8 %3086, %3088
  %3090 = icmp ne i8 %3089, 0
  %3091 = load <8 x i32>, ptr %frame.static.id, align 32
  %3092 = extractelement <8 x i32> %3091, i32 %3085
  %convergence.target.pointer394 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3092
  %convergence.dynamic.target395 = load i32, ptr %convergence.target.pointer394, align 4
  %3093 = icmp eq i32 %convergence.dynamic.target395, 8
  %3094 = and i1 %3090, %3093
  %3095 = and i1 %3083, %3094
  %3096 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3085
  %3097 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3085
  %3098 = load <8 x i1>, ptr %3096, align 1
  %3099 = load <8 x i1>, ptr %3097, align 1
  %3100 = or <8 x i1> %3099, %convergence.cascade.flow392
  %3101 = load <8 x i1>, ptr %live.mask, align 1
  %3102 = and <8 x i1> %3098, %3101
  %3103 = icmp eq <8 x i1> %3100, %3102
  %3104 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3103)
  %3105 = and i1 %3095, %3104
  %3106 = select i1 %3105, <8 x i1> zeroinitializer, <8 x i1> %3100
  %3107 = select i1 %3095, <8 x i1> %3106, <8 x i1> %3099
  store <8 x i1> %3107, ptr %3097, align 1
  %3108 = select i1 %3105, <8 x i1> zeroinitializer, <8 x i1> %3098
  store <8 x i1> %3108, ptr %3096, align 1
  %3109 = trunc i32 %3085 to i8
  %3110 = shl i8 1, %3109
  %3111 = xor i8 %3110, -1
  %3112 = and i8 %3086, %3111
  %3113 = select i1 %3105, i8 %3112, i8 %3086
  store i8 %3113, ptr %frame.active, align 1
  %.splatinsert396 = insertelement <8 x i1> poison, i1 %3095, i64 0
  %.splat397 = shufflevector <8 x i1> %.splatinsert396, <8 x i1> poison, <8 x i32> zeroinitializer
  %3114 = and <8 x i1> %convergence.cascade.flow392, %.splat397
  %3115 = load <8 x i1>, ptr %runnable.mask, align 1
  %3116 = xor <8 x i1> %3114, splat (i1 true)
  %3117 = and <8 x i1> %3115, %3116
  store <8 x i1> %3117, ptr %runnable.mask, align 1
  %.splatinsert398 = insertelement <8 x i1> poison, i1 %3105, i64 0
  %.splat399 = shufflevector <8 x i1> %.splatinsert398, <8 x i1> poison, <8 x i32> zeroinitializer
  %3118 = select <8 x i1> %.splat399, <8 x i1> %3100, <8 x i1> zeroinitializer
  %3119 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3120 = extractelement <8 x i32> %3119, i32 %3085
  %3121 = select i1 %3105, i32 %3120, i32 %3081
  store i32 %3121, ptr %current.token, align 4
  %.splatinsert400 = insertelement <8 x i1> poison, i1 %3095, i64 0
  %.splat401 = shufflevector <8 x i1> %.splatinsert400, <8 x i1> poison, <8 x i32> zeroinitializer
  %3122 = select <8 x i1> %.splat401, <8 x i1> %3118, <8 x i1> %convergence.cascade.flow392
  %3123 = add i32 %convergence.cascade.depth393, 1
  %3124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3122)
  %3125 = icmp ult i32 %3123, 8
  %3126 = and i1 %3124, %3125
  %3127 = and i1 %3095, %3126
  %convergence.parent.token402 = load i32, ptr %current.token, align 4
  %convergence.parent.present403 = icmp ne i32 %convergence.parent.token402, 0
  %3128 = and i1 %3127, %convergence.parent.present403
  br i1 %3128, label %convergence.cascade388, label %convergence.cascade.exit389

convergence.cascade.exit389:                      ; preds = %convergence.cascade388, %schedule.8
  %convergence.cascade.result404 = phi <8 x i1> [ %253, %schedule.8 ], [ %3122, %convergence.cascade388 ]
  %3129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result404)
  br i1 %3129, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit389
  %3130 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result404)
  %3131 = bitcast <8 x i1> %convergence.cascade.result404 to i8
  %3132 = call i8 @llvm.cttz.i8(i8 %3131, i1 false)
  %3133 = zext i8 %3132 to i32
  %3134 = select i1 %3130, i32 %3133, i32 0
  %3135 = load <8 x i64>, ptr %.slot, align 64
  %3136 = select <8 x i1> %convergence.cascade.result404, <8 x i64> zeroinitializer, <8 x i64> %3135
  store <8 x i64> %3136, ptr %.slot, align 64
  %3137 = load <8 x float>, ptr %.slot41, align 32
  %3138 = select <8 x i1> %convergence.cascade.result404, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %3137
  store <8 x float> %3138, ptr %.slot41, align 32
  %3139 = load <8 x float>, ptr %.slot47, align 32
  %3140 = select <8 x i1> %convergence.cascade.result404, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %3139
  store <8 x float> %3140, ptr %.slot47, align 32
  %3141 = load <8 x float>, ptr %.slot48, align 32
  %3142 = select <8 x i1> %convergence.cascade.result404, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %3141
  store <8 x float> %3142, ptr %.slot48, align 32
  %3143 = load <8 x float>, ptr %.slot49, align 32
  %3144 = select <8 x i1> %convergence.cascade.result404, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %3143
  store <8 x float> %3144, ptr %.slot49, align 32
  %3145 = load <8 x float>, ptr %.slot50, align 32
  %3146 = select <8 x i1> %convergence.cascade.result404, <8 x float> zeroinitializer, <8 x float> %3145
  store <8 x float> %3146, ptr %.slot50, align 32
  %3147 = load <8 x float>, ptr %.slot51, align 32
  %3148 = select <8 x i1> %convergence.cascade.result404, <8 x float> zeroinitializer, <8 x float> %3147
  store <8 x float> %3148, ptr %.slot51, align 32
  %3149 = load <8 x float>, ptr %.slot52, align 32
  %3150 = select <8 x i1> %convergence.cascade.result404, <8 x float> zeroinitializer, <8 x float> %3149
  store <8 x float> %3150, ptr %.slot52, align 32
  %3151 = load <8 x float>, ptr %.slot53, align 32
  %3152 = select <8 x i1> %convergence.cascade.result404, <8 x float> zeroinitializer, <8 x float> %3151
  store <8 x float> %3152, ptr %.slot53, align 32
  store <8 x i1> %convergence.cascade.result404, ptr %current.mask, align 1
  %3153 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result404)
  br i1 %3153, label %schedule.9, label %scheduler.loop

varying.divergent406:                             ; preds = %schedule.9
  %3154 = load i32, ptr %current.token, align 4
  %3155 = icmp ne i32 %3154, 0
  %3156 = sub i32 %3154, 1
  %3157 = select i1 %3155, i32 %3156, i32 0
  %3158 = load i8, ptr %frame.active, align 1
  %3159 = trunc i32 %3157 to i8
  %3160 = shl i8 1, %3159
  %3161 = and i8 %3158, %3160
  %3162 = icmp ne i8 %3161, 0
  %3163 = load <8 x i32>, ptr %frame.static.id, align 32
  %3164 = extractelement <8 x i32> %3163, i32 %3157
  %3165 = icmp eq i32 %3164, 3
  %3166 = and i1 %3162, %3165
  %3167 = and i1 %3155, %3166
  %3168 = xor i1 %3167, true
  %3169 = and i1 true, %3168
  %3170 = xor i8 %3158, -1
  %3171 = icmp ne i8 %3170, 0
  %3172 = xor i1 %3171, true
  %3173 = and i1 %3169, %3172
  br i1 %3173, label %convergence.overflow.trap408, label %convergence.overflow.resume409

varying.coherent407:                              ; preds = %schedule.9
  br i1 %264, label %varying.coherent.true412, label %varying.coherent.false413

convergence.overflow.trap408:                     ; preds = %varying.divergent406
  call void @llvm.trap()
  unreachable

convergence.overflow.resume409:                   ; preds = %varying.divergent406
  %3174 = call i8 @llvm.cttz.i8(i8 %3170, i1 false)
  %3175 = zext i8 %3174 to i32
  %3176 = select i1 %3171, i32 %3175, i32 0
  %3177 = trunc i32 %3176 to i8
  %3178 = shl i8 1, %3177
  %3179 = or i8 %3158, %3178
  %3180 = select i1 %3169, i8 %3179, i8 %3158
  store i8 %3180, ptr %frame.active, align 1
  %3181 = load <8 x i32>, ptr %frame.static.id, align 32
  %3182 = extractelement <8 x i32> %3181, i32 %3176
  %3183 = select i1 %3169, i32 3, i32 %3182
  %3184 = load <8 x i32>, ptr %frame.static.id, align 32
  %3185 = insertelement <8 x i32> %3184, i32 %3183, i32 %3176
  store <8 x i32> %3185, ptr %frame.static.id, align 32
  %3186 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3187 = extractelement <8 x i32> %3186, i32 %3176
  %3188 = select i1 %3169, i32 %3154, i32 %3187
  %3189 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3190 = insertelement <8 x i32> %3189, i32 %3188, i32 %3176
  store <8 x i32> %3190, ptr %frame.parent.token, align 32
  %3191 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3176
  %3192 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3176
  %3193 = load <8 x i1>, ptr %3191, align 1
  %3194 = load <8 x i1>, ptr %3192, align 1
  %3195 = select i1 %3169, <8 x i1> %254, <8 x i1> %3193
  store <8 x i1> %3195, ptr %3191, align 1
  %3196 = select i1 %3169, <8 x i1> zeroinitializer, <8 x i1> %3194
  store <8 x i1> %3196, ptr %3192, align 1
  %3197 = add i32 %3176, 1
  %3198 = select i1 %3167, i32 %3154, i32 %3197
  %3199 = select i1 true, i32 %3198, i32 %3154
  store i32 %3199, ptr %current.token, align 4
  %3200 = load i32, ptr %current.token, align 4
  %3201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %261)
  %3202 = load i32, ptr %ready.count, align 4
  %3203 = icmp uge i32 %3202, 8
  %3204 = and i1 %3201, %3203
  br i1 %3204, label %ready.overflow.trap410, label %ready.overflow.resume411

ready.overflow.trap410:                           ; preds = %convergence.overflow.resume409
  call void @llvm.trap()
  unreachable

ready.overflow.resume411:                         ; preds = %convergence.overflow.resume409
  %3205 = select i1 %3201, i32 %3202, i32 0
  %3206 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3205
  %3207 = load <8 x i1>, ptr %3206, align 1
  %3208 = select i1 %3201, <8 x i1> %261, <8 x i1> %3207
  store <8 x i1> %3208, ptr %3206, align 1
  %3209 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3205
  %3210 = load i32, ptr %3209, align 4
  %3211 = select i1 %3201, i32 10, i32 %3210
  store i32 %3211, ptr %3209, align 4
  %3212 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3205
  %3213 = load i32, ptr %3212, align 4
  %3214 = select i1 %3201, i32 %3200, i32 %3213
  store i32 %3214, ptr %3212, align 4
  %3215 = add i32 %3202, 1
  %3216 = select i1 %3201, i32 %3215, i32 %3202
  store i32 %3216, ptr %ready.count, align 4
  %3217 = load <8 x i1>, ptr %runnable.mask, align 1
  %3218 = or <8 x i1> %3217, %261
  store <8 x i1> %3218, ptr %runnable.mask, align 1
  store <8 x i1> %263, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true412:                         ; preds = %varying.coherent407
  store <8 x i1> %254, ptr %current.mask, align 1
  %3219 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %254)
  br i1 %3219, label %schedule.10, label %scheduler.loop

varying.coherent.false413:                        ; preds = %varying.coherent407
  store <8 x i1> %254, ptr %current.mask, align 1
  %3220 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %254)
  br i1 %3220, label %schedule.108, label %scheduler.loop

varying.divergent416:                             ; preds = %schedule.11
  %3221 = load i32, ptr %current.token, align 4
  %3222 = icmp ne i32 %3221, 0
  %3223 = sub i32 %3221, 1
  %3224 = select i1 %3222, i32 %3223, i32 0
  %3225 = load i8, ptr %frame.active, align 1
  %3226 = trunc i32 %3224 to i8
  %3227 = shl i8 1, %3226
  %3228 = and i8 %3225, %3227
  %3229 = icmp ne i8 %3228, 0
  %3230 = load <8 x i32>, ptr %frame.static.id, align 32
  %3231 = extractelement <8 x i32> %3230, i32 %3224
  %3232 = icmp eq i32 %3231, 4
  %3233 = and i1 %3229, %3232
  %3234 = and i1 %3222, %3233
  %3235 = xor i1 %3234, true
  %3236 = and i1 true, %3235
  %3237 = xor i8 %3225, -1
  %3238 = icmp ne i8 %3237, 0
  %3239 = xor i1 %3238, true
  %3240 = and i1 %3236, %3239
  br i1 %3240, label %convergence.overflow.trap418, label %convergence.overflow.resume419

varying.coherent417:                              ; preds = %schedule.11
  br i1 %301, label %varying.coherent.true422, label %varying.coherent.false423

convergence.overflow.trap418:                     ; preds = %varying.divergent416
  call void @llvm.trap()
  unreachable

convergence.overflow.resume419:                   ; preds = %varying.divergent416
  %3241 = call i8 @llvm.cttz.i8(i8 %3237, i1 false)
  %3242 = zext i8 %3241 to i32
  %3243 = select i1 %3238, i32 %3242, i32 0
  %3244 = trunc i32 %3243 to i8
  %3245 = shl i8 1, %3244
  %3246 = or i8 %3225, %3245
  %3247 = select i1 %3236, i8 %3246, i8 %3225
  store i8 %3247, ptr %frame.active, align 1
  %3248 = load <8 x i32>, ptr %frame.static.id, align 32
  %3249 = extractelement <8 x i32> %3248, i32 %3243
  %3250 = select i1 %3236, i32 4, i32 %3249
  %3251 = load <8 x i32>, ptr %frame.static.id, align 32
  %3252 = insertelement <8 x i32> %3251, i32 %3250, i32 %3243
  store <8 x i32> %3252, ptr %frame.static.id, align 32
  %3253 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3254 = extractelement <8 x i32> %3253, i32 %3243
  %3255 = select i1 %3236, i32 %3221, i32 %3254
  %3256 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3257 = insertelement <8 x i32> %3256, i32 %3255, i32 %3243
  store <8 x i32> %3257, ptr %frame.parent.token, align 32
  %3258 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3243
  %3259 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3243
  %3260 = load <8 x i1>, ptr %3258, align 1
  %3261 = load <8 x i1>, ptr %3259, align 1
  %3262 = select i1 %3236, <8 x i1> %291, <8 x i1> %3260
  store <8 x i1> %3262, ptr %3258, align 1
  %3263 = select i1 %3236, <8 x i1> zeroinitializer, <8 x i1> %3261
  store <8 x i1> %3263, ptr %3259, align 1
  %3264 = add i32 %3243, 1
  %3265 = select i1 %3234, i32 %3221, i32 %3264
  %3266 = select i1 true, i32 %3265, i32 %3221
  store i32 %3266, ptr %current.token, align 4
  %3267 = load i32, ptr %current.token, align 4
  %3268 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %298)
  %3269 = load i32, ptr %ready.count, align 4
  %3270 = icmp uge i32 %3269, 8
  %3271 = and i1 %3268, %3270
  br i1 %3271, label %ready.overflow.trap420, label %ready.overflow.resume421

ready.overflow.trap420:                           ; preds = %convergence.overflow.resume419
  call void @llvm.trap()
  unreachable

ready.overflow.resume421:                         ; preds = %convergence.overflow.resume419
  %3272 = select i1 %3268, i32 %3269, i32 0
  %3273 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3272
  %3274 = load <8 x i1>, ptr %3273, align 1
  %3275 = select i1 %3268, <8 x i1> %298, <8 x i1> %3274
  store <8 x i1> %3275, ptr %3273, align 1
  %3276 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3272
  %3277 = load i32, ptr %3276, align 4
  %3278 = select i1 %3268, i32 12, i32 %3277
  store i32 %3278, ptr %3276, align 4
  %3279 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3272
  %3280 = load i32, ptr %3279, align 4
  %3281 = select i1 %3268, i32 %3267, i32 %3280
  store i32 %3281, ptr %3279, align 4
  %3282 = add i32 %3269, 1
  %3283 = select i1 %3268, i32 %3282, i32 %3269
  store i32 %3283, ptr %ready.count, align 4
  %3284 = load <8 x i1>, ptr %runnable.mask, align 1
  %3285 = or <8 x i1> %3284, %298
  store <8 x i1> %3285, ptr %runnable.mask, align 1
  store <8 x i1> %300, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true422:                         ; preds = %varying.coherent417
  store <8 x i1> %291, ptr %current.mask, align 1
  %3286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %291)
  br i1 %3286, label %schedule.12, label %scheduler.loop

varying.coherent.false423:                        ; preds = %varying.coherent417
  store <8 x i1> %291, ptr %current.mask, align 1
  %3287 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %291)
  br i1 %3287, label %schedule.15, label %scheduler.loop

varying.divergent429:                             ; preds = %schedule.12
  %3288 = load i32, ptr %current.token, align 4
  %3289 = icmp ne i32 %3288, 0
  %3290 = sub i32 %3288, 1
  %3291 = select i1 %3289, i32 %3290, i32 0
  %3292 = load i8, ptr %frame.active, align 1
  %3293 = trunc i32 %3291 to i8
  %3294 = shl i8 1, %3293
  %3295 = and i8 %3292, %3294
  %3296 = icmp ne i8 %3295, 0
  %3297 = load <8 x i32>, ptr %frame.static.id, align 32
  %3298 = extractelement <8 x i32> %3297, i32 %3291
  %3299 = icmp eq i32 %3298, 5
  %3300 = and i1 %3296, %3299
  %3301 = and i1 %3289, %3300
  %3302 = xor i1 %3301, true
  %3303 = and i1 true, %3302
  %3304 = xor i8 %3292, -1
  %3305 = icmp ne i8 %3304, 0
  %3306 = xor i1 %3305, true
  %3307 = and i1 %3303, %3306
  br i1 %3307, label %convergence.overflow.trap431, label %convergence.overflow.resume432

varying.coherent430:                              ; preds = %schedule.12
  br i1 %336, label %varying.coherent.true435, label %varying.coherent.false436

convergence.overflow.trap431:                     ; preds = %varying.divergent429
  call void @llvm.trap()
  unreachable

convergence.overflow.resume432:                   ; preds = %varying.divergent429
  %3308 = call i8 @llvm.cttz.i8(i8 %3304, i1 false)
  %3309 = zext i8 %3308 to i32
  %3310 = select i1 %3305, i32 %3309, i32 0
  %3311 = trunc i32 %3310 to i8
  %3312 = shl i8 1, %3311
  %3313 = or i8 %3292, %3312
  %3314 = select i1 %3303, i8 %3313, i8 %3292
  store i8 %3314, ptr %frame.active, align 1
  %3315 = load <8 x i32>, ptr %frame.static.id, align 32
  %3316 = extractelement <8 x i32> %3315, i32 %3310
  %3317 = select i1 %3303, i32 5, i32 %3316
  %3318 = load <8 x i32>, ptr %frame.static.id, align 32
  %3319 = insertelement <8 x i32> %3318, i32 %3317, i32 %3310
  store <8 x i32> %3319, ptr %frame.static.id, align 32
  %3320 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3321 = extractelement <8 x i32> %3320, i32 %3310
  %3322 = select i1 %3303, i32 %3288, i32 %3321
  %3323 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3324 = insertelement <8 x i32> %3323, i32 %3322, i32 %3310
  store <8 x i32> %3324, ptr %frame.parent.token, align 32
  %3325 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3310
  %3326 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3310
  %3327 = load <8 x i1>, ptr %3325, align 1
  %3328 = load <8 x i1>, ptr %3326, align 1
  %3329 = select i1 %3303, <8 x i1> %304, <8 x i1> %3327
  store <8 x i1> %3329, ptr %3325, align 1
  %3330 = select i1 %3303, <8 x i1> zeroinitializer, <8 x i1> %3328
  store <8 x i1> %3330, ptr %3326, align 1
  %3331 = add i32 %3310, 1
  %3332 = select i1 %3301, i32 %3288, i32 %3331
  %3333 = select i1 true, i32 %3332, i32 %3288
  store i32 %3333, ptr %current.token, align 4
  %3334 = load <8 x float>, ptr %.slot58, align 32
  %3335 = select <8 x i1> %335, <8 x float> zeroinitializer, <8 x float> %3334
  store <8 x float> %3335, ptr %.slot58, align 32
  %3336 = load i32, ptr %current.token, align 4
  %3337 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %333)
  %3338 = load i32, ptr %ready.count, align 4
  %3339 = icmp uge i32 %3338, 8
  %3340 = and i1 %3337, %3339
  br i1 %3340, label %ready.overflow.trap433, label %ready.overflow.resume434

ready.overflow.trap433:                           ; preds = %convergence.overflow.resume432
  call void @llvm.trap()
  unreachable

ready.overflow.resume434:                         ; preds = %convergence.overflow.resume432
  %3341 = select i1 %3337, i32 %3338, i32 0
  %3342 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3341
  %3343 = load <8 x i1>, ptr %3342, align 1
  %3344 = select i1 %3337, <8 x i1> %333, <8 x i1> %3343
  store <8 x i1> %3344, ptr %3342, align 1
  %3345 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3341
  %3346 = load i32, ptr %3345, align 4
  %3347 = select i1 %3337, i32 13, i32 %3346
  store i32 %3347, ptr %3345, align 4
  %3348 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3341
  %3349 = load i32, ptr %3348, align 4
  %3350 = select i1 %3337, i32 %3336, i32 %3349
  store i32 %3350, ptr %3348, align 4
  %3351 = add i32 %3338, 1
  %3352 = select i1 %3337, i32 %3351, i32 %3338
  store i32 %3352, ptr %ready.count, align 4
  %3353 = load <8 x i1>, ptr %runnable.mask, align 1
  %3354 = or <8 x i1> %3353, %333
  store <8 x i1> %3354, ptr %runnable.mask, align 1
  store <8 x i1> %335, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true435:                         ; preds = %varying.coherent430
  store <8 x i1> %304, ptr %current.mask, align 1
  %3355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %304)
  br i1 %3355, label %schedule.13, label %scheduler.loop

varying.coherent.false436:                        ; preds = %varying.coherent430
  %3356 = load <8 x float>, ptr %.slot58, align 32
  %3357 = select <8 x i1> %304, <8 x float> zeroinitializer, <8 x float> %3356
  store <8 x float> %3357, ptr %.slot58, align 32
  store <8 x i1> %304, ptr %current.mask, align 1
  %3358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %304)
  br i1 %3358, label %schedule.14, label %scheduler.loop

convergence.cascade438:                           ; preds = %convergence.cascade438, %schedule.14
  %convergence.cascade.flow442 = phi <8 x i1> [ %352, %schedule.14 ], [ %3401, %convergence.cascade438 ]
  %convergence.cascade.depth443 = phi i32 [ 0, %schedule.14 ], [ %3402, %convergence.cascade438 ]
  %3359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow442)
  %3360 = load i32, ptr %current.token, align 4
  %3361 = icmp ne i32 %3360, 0
  %3362 = and i1 %3359, %3361
  %3363 = sub i32 %3360, 1
  %3364 = select i1 %3362, i32 %3363, i32 0
  %3365 = load i8, ptr %frame.active, align 1
  %3366 = trunc i32 %3364 to i8
  %3367 = shl i8 1, %3366
  %3368 = and i8 %3365, %3367
  %3369 = icmp ne i8 %3368, 0
  %3370 = load <8 x i32>, ptr %frame.static.id, align 32
  %3371 = extractelement <8 x i32> %3370, i32 %3364
  %convergence.target.pointer444 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3371
  %convergence.dynamic.target445 = load i32, ptr %convergence.target.pointer444, align 4
  %3372 = icmp eq i32 %convergence.dynamic.target445, 14
  %3373 = and i1 %3369, %3372
  %3374 = and i1 %3362, %3373
  %3375 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3364
  %3376 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3364
  %3377 = load <8 x i1>, ptr %3375, align 1
  %3378 = load <8 x i1>, ptr %3376, align 1
  %3379 = or <8 x i1> %3378, %convergence.cascade.flow442
  %3380 = load <8 x i1>, ptr %live.mask, align 1
  %3381 = and <8 x i1> %3377, %3380
  %3382 = icmp eq <8 x i1> %3379, %3381
  %3383 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3382)
  %3384 = and i1 %3374, %3383
  %3385 = select i1 %3384, <8 x i1> zeroinitializer, <8 x i1> %3379
  %3386 = select i1 %3374, <8 x i1> %3385, <8 x i1> %3378
  store <8 x i1> %3386, ptr %3376, align 1
  %3387 = select i1 %3384, <8 x i1> zeroinitializer, <8 x i1> %3377
  store <8 x i1> %3387, ptr %3375, align 1
  %3388 = trunc i32 %3364 to i8
  %3389 = shl i8 1, %3388
  %3390 = xor i8 %3389, -1
  %3391 = and i8 %3365, %3390
  %3392 = select i1 %3384, i8 %3391, i8 %3365
  store i8 %3392, ptr %frame.active, align 1
  %.splatinsert446 = insertelement <8 x i1> poison, i1 %3374, i64 0
  %.splat447 = shufflevector <8 x i1> %.splatinsert446, <8 x i1> poison, <8 x i32> zeroinitializer
  %3393 = and <8 x i1> %convergence.cascade.flow442, %.splat447
  %3394 = load <8 x i1>, ptr %runnable.mask, align 1
  %3395 = xor <8 x i1> %3393, splat (i1 true)
  %3396 = and <8 x i1> %3394, %3395
  store <8 x i1> %3396, ptr %runnable.mask, align 1
  %.splatinsert448 = insertelement <8 x i1> poison, i1 %3384, i64 0
  %.splat449 = shufflevector <8 x i1> %.splatinsert448, <8 x i1> poison, <8 x i32> zeroinitializer
  %3397 = select <8 x i1> %.splat449, <8 x i1> %3379, <8 x i1> zeroinitializer
  %3398 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3399 = extractelement <8 x i32> %3398, i32 %3364
  %3400 = select i1 %3384, i32 %3399, i32 %3360
  store i32 %3400, ptr %current.token, align 4
  %.splatinsert450 = insertelement <8 x i1> poison, i1 %3374, i64 0
  %.splat451 = shufflevector <8 x i1> %.splatinsert450, <8 x i1> poison, <8 x i32> zeroinitializer
  %3401 = select <8 x i1> %.splat451, <8 x i1> %3397, <8 x i1> %convergence.cascade.flow442
  %3402 = add i32 %convergence.cascade.depth443, 1
  %3403 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3401)
  %3404 = icmp ult i32 %3402, 8
  %3405 = and i1 %3403, %3404
  %3406 = and i1 %3374, %3405
  %convergence.parent.token452 = load i32, ptr %current.token, align 4
  %convergence.parent.present453 = icmp ne i32 %convergence.parent.token452, 0
  %3407 = and i1 %3406, %convergence.parent.present453
  br i1 %3407, label %convergence.cascade438, label %convergence.cascade.exit439

convergence.cascade.exit439:                      ; preds = %convergence.cascade438, %schedule.14
  %convergence.cascade.result454 = phi <8 x i1> [ %352, %schedule.14 ], [ %3401, %convergence.cascade438 ]
  %3408 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  br i1 %3408, label %convergence.target.14.ready, label %scheduler.loop

convergence.target.14.ready:                      ; preds = %convergence.cascade.exit439
  %3409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3410 = bitcast <8 x i1> %convergence.cascade.result454 to i8
  %3411 = call i8 @llvm.cttz.i8(i8 %3410, i1 false)
  %3412 = zext i8 %3411 to i32
  %3413 = select i1 %3409, i32 %3412, i32 0
  %tile_snapshot.spill.load455 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %3414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %3415 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %.state456 = load <8 x i64>, ptr %.slot56, align 64
  %3416 = mul <8 x i64> %.state456, splat (i64 32)
  %3417 = add <8 x i64> %3415, %3416
  %3418 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3414, 0
  %3419 = insertvalue { <8 x ptr>, <8 x i64> } %3418, <8 x i64> %3417, 1
  %.state457 = load <8 x float>, ptr %.slot58, align 32
  %3420 = extractvalue { <8 x ptr>, <8 x i64> } %3419, 0
  %3421 = extractvalue { <8 x ptr>, <8 x i64> } %3419, 1
  %3422 = getelementptr i8, <8 x ptr> %3420, <8 x i64> %3421
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state457, <8 x ptr> align 1 %3422, <8 x i1> %convergence.cascade.result454)
  %.state458 = load <8 x i64>, ptr %.slot56, align 64
  %3423 = add <8 x i64> %.state458, splat (i64 1)
  %3424 = load <8 x i64>, ptr %.slot56, align 64
  %3425 = select <8 x i1> %convergence.cascade.result454, <8 x i64> %3423, <8 x i64> %3424
  store <8 x i64> %3425, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result454, ptr %current.mask, align 1
  %3426 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  br i1 %3426, label %schedule.11, label %scheduler.loop

convergence.cascade459:                           ; preds = %convergence.cascade459, %schedule.15
  %convergence.cascade.flow463 = phi <8 x i1> [ %353, %schedule.15 ], [ %3469, %convergence.cascade459 ]
  %convergence.cascade.depth464 = phi i32 [ 0, %schedule.15 ], [ %3470, %convergence.cascade459 ]
  %3427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow463)
  %3428 = load i32, ptr %current.token, align 4
  %3429 = icmp ne i32 %3428, 0
  %3430 = and i1 %3427, %3429
  %3431 = sub i32 %3428, 1
  %3432 = select i1 %3430, i32 %3431, i32 0
  %3433 = load i8, ptr %frame.active, align 1
  %3434 = trunc i32 %3432 to i8
  %3435 = shl i8 1, %3434
  %3436 = and i8 %3433, %3435
  %3437 = icmp ne i8 %3436, 0
  %3438 = load <8 x i32>, ptr %frame.static.id, align 32
  %3439 = extractelement <8 x i32> %3438, i32 %3432
  %convergence.target.pointer465 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3439
  %convergence.dynamic.target466 = load i32, ptr %convergence.target.pointer465, align 4
  %3440 = icmp eq i32 %convergence.dynamic.target466, 15
  %3441 = and i1 %3437, %3440
  %3442 = and i1 %3430, %3441
  %3443 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3432
  %3444 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3432
  %3445 = load <8 x i1>, ptr %3443, align 1
  %3446 = load <8 x i1>, ptr %3444, align 1
  %3447 = or <8 x i1> %3446, %convergence.cascade.flow463
  %3448 = load <8 x i1>, ptr %live.mask, align 1
  %3449 = and <8 x i1> %3445, %3448
  %3450 = icmp eq <8 x i1> %3447, %3449
  %3451 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3450)
  %3452 = and i1 %3442, %3451
  %3453 = select i1 %3452, <8 x i1> zeroinitializer, <8 x i1> %3447
  %3454 = select i1 %3442, <8 x i1> %3453, <8 x i1> %3446
  store <8 x i1> %3454, ptr %3444, align 1
  %3455 = select i1 %3452, <8 x i1> zeroinitializer, <8 x i1> %3445
  store <8 x i1> %3455, ptr %3443, align 1
  %3456 = trunc i32 %3432 to i8
  %3457 = shl i8 1, %3456
  %3458 = xor i8 %3457, -1
  %3459 = and i8 %3433, %3458
  %3460 = select i1 %3452, i8 %3459, i8 %3433
  store i8 %3460, ptr %frame.active, align 1
  %.splatinsert467 = insertelement <8 x i1> poison, i1 %3442, i64 0
  %.splat468 = shufflevector <8 x i1> %.splatinsert467, <8 x i1> poison, <8 x i32> zeroinitializer
  %3461 = and <8 x i1> %convergence.cascade.flow463, %.splat468
  %3462 = load <8 x i1>, ptr %runnable.mask, align 1
  %3463 = xor <8 x i1> %3461, splat (i1 true)
  %3464 = and <8 x i1> %3462, %3463
  store <8 x i1> %3464, ptr %runnable.mask, align 1
  %.splatinsert469 = insertelement <8 x i1> poison, i1 %3452, i64 0
  %.splat470 = shufflevector <8 x i1> %.splatinsert469, <8 x i1> poison, <8 x i32> zeroinitializer
  %3465 = select <8 x i1> %.splat470, <8 x i1> %3447, <8 x i1> zeroinitializer
  %3466 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3467 = extractelement <8 x i32> %3466, i32 %3432
  %3468 = select i1 %3452, i32 %3467, i32 %3428
  store i32 %3468, ptr %current.token, align 4
  %.splatinsert471 = insertelement <8 x i1> poison, i1 %3442, i64 0
  %.splat472 = shufflevector <8 x i1> %.splatinsert471, <8 x i1> poison, <8 x i32> zeroinitializer
  %3469 = select <8 x i1> %.splat472, <8 x i1> %3465, <8 x i1> %convergence.cascade.flow463
  %3470 = add i32 %convergence.cascade.depth464, 1
  %3471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3469)
  %3472 = icmp ult i32 %3470, 8
  %3473 = and i1 %3471, %3472
  %3474 = and i1 %3442, %3473
  %convergence.parent.token473 = load i32, ptr %current.token, align 4
  %convergence.parent.present474 = icmp ne i32 %convergence.parent.token473, 0
  %3475 = and i1 %3474, %convergence.parent.present474
  br i1 %3475, label %convergence.cascade459, label %convergence.cascade.exit460

convergence.cascade.exit460:                      ; preds = %convergence.cascade459, %schedule.15
  %convergence.cascade.result475 = phi <8 x i1> [ %353, %schedule.15 ], [ %3469, %convergence.cascade459 ]
  %3476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result475)
  br i1 %3476, label %convergence.target.15.ready, label %scheduler.loop

convergence.target.15.ready:                      ; preds = %convergence.cascade.exit460
  %3477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result475)
  %3478 = bitcast <8 x i1> %convergence.cascade.result475 to i8
  %3479 = call i8 @llvm.cttz.i8(i8 %3478, i1 false)
  %3480 = zext i8 %3479 to i32
  %3481 = select i1 %3477, i32 %3480, i32 0
  %3482 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill59, align 64
  %3483 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %3484 = extractvalue { <8 x ptr>, <8 x i64> } %3482, 0
  %3485 = select <8 x i1> %convergence.cascade.result475, <8 x ptr> %3483, <8 x ptr> %3484
  %3486 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %3487 = extractvalue { <8 x ptr>, <8 x i64> } %3482, 1
  %3488 = select <8 x i1> %convergence.cascade.result475, <8 x i64> %3486, <8 x i64> %3487
  %3489 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3485, 0
  %3490 = insertvalue { <8 x ptr>, <8 x i64> } %3489, <8 x i64> %3488, 1
  store { <8 x ptr>, <8 x i64> } %3490, ptr %tile_snapshot.spill59, align 64
  %3491 = load <8 x i64>, ptr %.slot56, align 64
  %3492 = select <8 x i1> %convergence.cascade.result475, <8 x i64> zeroinitializer, <8 x i64> %3491
  store <8 x i64> %3492, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result475, ptr %current.mask, align 1
  %3493 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result475)
  br i1 %3493, label %schedule.16, label %scheduler.loop

varying.divergent477:                             ; preds = %schedule.16
  %3494 = load i32, ptr %current.token, align 4
  %3495 = icmp ne i32 %3494, 0
  %3496 = sub i32 %3494, 1
  %3497 = select i1 %3495, i32 %3496, i32 0
  %3498 = load i8, ptr %frame.active, align 1
  %3499 = trunc i32 %3497 to i8
  %3500 = shl i8 1, %3499
  %3501 = and i8 %3498, %3500
  %3502 = icmp ne i8 %3501, 0
  %3503 = load <8 x i32>, ptr %frame.static.id, align 32
  %3504 = extractelement <8 x i32> %3503, i32 %3497
  %3505 = icmp eq i32 %3504, 6
  %3506 = and i1 %3502, %3505
  %3507 = and i1 %3495, %3506
  %3508 = xor i1 %3507, true
  %3509 = and i1 true, %3508
  %3510 = xor i8 %3498, -1
  %3511 = icmp ne i8 %3510, 0
  %3512 = xor i1 %3511, true
  %3513 = and i1 %3509, %3512
  br i1 %3513, label %convergence.overflow.trap479, label %convergence.overflow.resume480

varying.coherent478:                              ; preds = %schedule.16
  br i1 %364, label %varying.coherent.true483, label %varying.coherent.false484

convergence.overflow.trap479:                     ; preds = %varying.divergent477
  call void @llvm.trap()
  unreachable

convergence.overflow.resume480:                   ; preds = %varying.divergent477
  %3514 = call i8 @llvm.cttz.i8(i8 %3510, i1 false)
  %3515 = zext i8 %3514 to i32
  %3516 = select i1 %3511, i32 %3515, i32 0
  %3517 = trunc i32 %3516 to i8
  %3518 = shl i8 1, %3517
  %3519 = or i8 %3498, %3518
  %3520 = select i1 %3509, i8 %3519, i8 %3498
  store i8 %3520, ptr %frame.active, align 1
  %3521 = load <8 x i32>, ptr %frame.static.id, align 32
  %3522 = extractelement <8 x i32> %3521, i32 %3516
  %3523 = select i1 %3509, i32 6, i32 %3522
  %3524 = load <8 x i32>, ptr %frame.static.id, align 32
  %3525 = insertelement <8 x i32> %3524, i32 %3523, i32 %3516
  store <8 x i32> %3525, ptr %frame.static.id, align 32
  %3526 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3527 = extractelement <8 x i32> %3526, i32 %3516
  %3528 = select i1 %3509, i32 %3494, i32 %3527
  %3529 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3530 = insertelement <8 x i32> %3529, i32 %3528, i32 %3516
  store <8 x i32> %3530, ptr %frame.parent.token, align 32
  %3531 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3516
  %3532 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3516
  %3533 = load <8 x i1>, ptr %3531, align 1
  %3534 = load <8 x i1>, ptr %3532, align 1
  %3535 = select i1 %3509, <8 x i1> %354, <8 x i1> %3533
  store <8 x i1> %3535, ptr %3531, align 1
  %3536 = select i1 %3509, <8 x i1> zeroinitializer, <8 x i1> %3534
  store <8 x i1> %3536, ptr %3532, align 1
  %3537 = add i32 %3516, 1
  %3538 = select i1 %3507, i32 %3494, i32 %3537
  %3539 = select i1 true, i32 %3538, i32 %3494
  store i32 %3539, ptr %current.token, align 4
  %3540 = load i32, ptr %current.token, align 4
  %3541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %361)
  %3542 = load i32, ptr %ready.count, align 4
  %3543 = icmp uge i32 %3542, 8
  %3544 = and i1 %3541, %3543
  br i1 %3544, label %ready.overflow.trap481, label %ready.overflow.resume482

ready.overflow.trap481:                           ; preds = %convergence.overflow.resume480
  call void @llvm.trap()
  unreachable

ready.overflow.resume482:                         ; preds = %convergence.overflow.resume480
  %3545 = select i1 %3541, i32 %3542, i32 0
  %3546 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3545
  %3547 = load <8 x i1>, ptr %3546, align 1
  %3548 = select i1 %3541, <8 x i1> %361, <8 x i1> %3547
  store <8 x i1> %3548, ptr %3546, align 1
  %3549 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3545
  %3550 = load i32, ptr %3549, align 4
  %3551 = select i1 %3541, i32 17, i32 %3550
  store i32 %3551, ptr %3549, align 4
  %3552 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3545
  %3553 = load i32, ptr %3552, align 4
  %3554 = select i1 %3541, i32 %3540, i32 %3553
  store i32 %3554, ptr %3552, align 4
  %3555 = add i32 %3542, 1
  %3556 = select i1 %3541, i32 %3555, i32 %3542
  store i32 %3556, ptr %ready.count, align 4
  %3557 = load <8 x i1>, ptr %runnable.mask, align 1
  %3558 = or <8 x i1> %3557, %361
  store <8 x i1> %3558, ptr %runnable.mask, align 1
  store <8 x i1> %363, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true483:                         ; preds = %varying.coherent478
  store <8 x i1> %354, ptr %current.mask, align 1
  %3559 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %354)
  br i1 %3559, label %schedule.17, label %scheduler.loop

varying.coherent.false484:                        ; preds = %varying.coherent478
  store <8 x i1> %354, ptr %current.mask, align 1
  %3560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %354)
  br i1 %3560, label %schedule.20, label %scheduler.loop

varying.divergent490:                             ; preds = %schedule.17
  %3561 = load i32, ptr %current.token, align 4
  %3562 = icmp ne i32 %3561, 0
  %3563 = sub i32 %3561, 1
  %3564 = select i1 %3562, i32 %3563, i32 0
  %3565 = load i8, ptr %frame.active, align 1
  %3566 = trunc i32 %3564 to i8
  %3567 = shl i8 1, %3566
  %3568 = and i8 %3565, %3567
  %3569 = icmp ne i8 %3568, 0
  %3570 = load <8 x i32>, ptr %frame.static.id, align 32
  %3571 = extractelement <8 x i32> %3570, i32 %3564
  %3572 = icmp eq i32 %3571, 7
  %3573 = and i1 %3569, %3572
  %3574 = and i1 %3562, %3573
  %3575 = xor i1 %3574, true
  %3576 = and i1 true, %3575
  %3577 = xor i8 %3565, -1
  %3578 = icmp ne i8 %3577, 0
  %3579 = xor i1 %3578, true
  %3580 = and i1 %3576, %3579
  br i1 %3580, label %convergence.overflow.trap492, label %convergence.overflow.resume493

varying.coherent491:                              ; preds = %schedule.17
  br i1 %399, label %varying.coherent.true496, label %varying.coherent.false497

convergence.overflow.trap492:                     ; preds = %varying.divergent490
  call void @llvm.trap()
  unreachable

convergence.overflow.resume493:                   ; preds = %varying.divergent490
  %3581 = call i8 @llvm.cttz.i8(i8 %3577, i1 false)
  %3582 = zext i8 %3581 to i32
  %3583 = select i1 %3578, i32 %3582, i32 0
  %3584 = trunc i32 %3583 to i8
  %3585 = shl i8 1, %3584
  %3586 = or i8 %3565, %3585
  %3587 = select i1 %3576, i8 %3586, i8 %3565
  store i8 %3587, ptr %frame.active, align 1
  %3588 = load <8 x i32>, ptr %frame.static.id, align 32
  %3589 = extractelement <8 x i32> %3588, i32 %3583
  %3590 = select i1 %3576, i32 7, i32 %3589
  %3591 = load <8 x i32>, ptr %frame.static.id, align 32
  %3592 = insertelement <8 x i32> %3591, i32 %3590, i32 %3583
  store <8 x i32> %3592, ptr %frame.static.id, align 32
  %3593 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3594 = extractelement <8 x i32> %3593, i32 %3583
  %3595 = select i1 %3576, i32 %3561, i32 %3594
  %3596 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3597 = insertelement <8 x i32> %3596, i32 %3595, i32 %3583
  store <8 x i32> %3597, ptr %frame.parent.token, align 32
  %3598 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3583
  %3599 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3583
  %3600 = load <8 x i1>, ptr %3598, align 1
  %3601 = load <8 x i1>, ptr %3599, align 1
  %3602 = select i1 %3576, <8 x i1> %367, <8 x i1> %3600
  store <8 x i1> %3602, ptr %3598, align 1
  %3603 = select i1 %3576, <8 x i1> zeroinitializer, <8 x i1> %3601
  store <8 x i1> %3603, ptr %3599, align 1
  %3604 = add i32 %3583, 1
  %3605 = select i1 %3574, i32 %3561, i32 %3604
  %3606 = select i1 true, i32 %3605, i32 %3561
  store i32 %3606, ptr %current.token, align 4
  %3607 = load <8 x float>, ptr %.slot58, align 32
  %3608 = select <8 x i1> %398, <8 x float> zeroinitializer, <8 x float> %3607
  store <8 x float> %3608, ptr %.slot58, align 32
  %3609 = load i32, ptr %current.token, align 4
  %3610 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %396)
  %3611 = load i32, ptr %ready.count, align 4
  %3612 = icmp uge i32 %3611, 8
  %3613 = and i1 %3610, %3612
  br i1 %3613, label %ready.overflow.trap494, label %ready.overflow.resume495

ready.overflow.trap494:                           ; preds = %convergence.overflow.resume493
  call void @llvm.trap()
  unreachable

ready.overflow.resume495:                         ; preds = %convergence.overflow.resume493
  %3614 = select i1 %3610, i32 %3611, i32 0
  %3615 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3614
  %3616 = load <8 x i1>, ptr %3615, align 1
  %3617 = select i1 %3610, <8 x i1> %396, <8 x i1> %3616
  store <8 x i1> %3617, ptr %3615, align 1
  %3618 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3614
  %3619 = load i32, ptr %3618, align 4
  %3620 = select i1 %3610, i32 18, i32 %3619
  store i32 %3620, ptr %3618, align 4
  %3621 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3614
  %3622 = load i32, ptr %3621, align 4
  %3623 = select i1 %3610, i32 %3609, i32 %3622
  store i32 %3623, ptr %3621, align 4
  %3624 = add i32 %3611, 1
  %3625 = select i1 %3610, i32 %3624, i32 %3611
  store i32 %3625, ptr %ready.count, align 4
  %3626 = load <8 x i1>, ptr %runnable.mask, align 1
  %3627 = or <8 x i1> %3626, %396
  store <8 x i1> %3627, ptr %runnable.mask, align 1
  store <8 x i1> %398, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true496:                         ; preds = %varying.coherent491
  store <8 x i1> %367, ptr %current.mask, align 1
  %3628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %367)
  br i1 %3628, label %schedule.18, label %scheduler.loop

varying.coherent.false497:                        ; preds = %varying.coherent491
  %3629 = load <8 x float>, ptr %.slot58, align 32
  %3630 = select <8 x i1> %367, <8 x float> zeroinitializer, <8 x float> %3629
  store <8 x float> %3630, ptr %.slot58, align 32
  store <8 x i1> %367, ptr %current.mask, align 1
  %3631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %367)
  br i1 %3631, label %schedule.19, label %scheduler.loop

convergence.cascade499:                           ; preds = %convergence.cascade499, %schedule.19
  %convergence.cascade.flow503 = phi <8 x i1> [ %415, %schedule.19 ], [ %3674, %convergence.cascade499 ]
  %convergence.cascade.depth504 = phi i32 [ 0, %schedule.19 ], [ %3675, %convergence.cascade499 ]
  %3632 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow503)
  %3633 = load i32, ptr %current.token, align 4
  %3634 = icmp ne i32 %3633, 0
  %3635 = and i1 %3632, %3634
  %3636 = sub i32 %3633, 1
  %3637 = select i1 %3635, i32 %3636, i32 0
  %3638 = load i8, ptr %frame.active, align 1
  %3639 = trunc i32 %3637 to i8
  %3640 = shl i8 1, %3639
  %3641 = and i8 %3638, %3640
  %3642 = icmp ne i8 %3641, 0
  %3643 = load <8 x i32>, ptr %frame.static.id, align 32
  %3644 = extractelement <8 x i32> %3643, i32 %3637
  %convergence.target.pointer505 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3644
  %convergence.dynamic.target506 = load i32, ptr %convergence.target.pointer505, align 4
  %3645 = icmp eq i32 %convergence.dynamic.target506, 19
  %3646 = and i1 %3642, %3645
  %3647 = and i1 %3635, %3646
  %3648 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3637
  %3649 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3637
  %3650 = load <8 x i1>, ptr %3648, align 1
  %3651 = load <8 x i1>, ptr %3649, align 1
  %3652 = or <8 x i1> %3651, %convergence.cascade.flow503
  %3653 = load <8 x i1>, ptr %live.mask, align 1
  %3654 = and <8 x i1> %3650, %3653
  %3655 = icmp eq <8 x i1> %3652, %3654
  %3656 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3655)
  %3657 = and i1 %3647, %3656
  %3658 = select i1 %3657, <8 x i1> zeroinitializer, <8 x i1> %3652
  %3659 = select i1 %3647, <8 x i1> %3658, <8 x i1> %3651
  store <8 x i1> %3659, ptr %3649, align 1
  %3660 = select i1 %3657, <8 x i1> zeroinitializer, <8 x i1> %3650
  store <8 x i1> %3660, ptr %3648, align 1
  %3661 = trunc i32 %3637 to i8
  %3662 = shl i8 1, %3661
  %3663 = xor i8 %3662, -1
  %3664 = and i8 %3638, %3663
  %3665 = select i1 %3657, i8 %3664, i8 %3638
  store i8 %3665, ptr %frame.active, align 1
  %.splatinsert507 = insertelement <8 x i1> poison, i1 %3647, i64 0
  %.splat508 = shufflevector <8 x i1> %.splatinsert507, <8 x i1> poison, <8 x i32> zeroinitializer
  %3666 = and <8 x i1> %convergence.cascade.flow503, %.splat508
  %3667 = load <8 x i1>, ptr %runnable.mask, align 1
  %3668 = xor <8 x i1> %3666, splat (i1 true)
  %3669 = and <8 x i1> %3667, %3668
  store <8 x i1> %3669, ptr %runnable.mask, align 1
  %.splatinsert509 = insertelement <8 x i1> poison, i1 %3657, i64 0
  %.splat510 = shufflevector <8 x i1> %.splatinsert509, <8 x i1> poison, <8 x i32> zeroinitializer
  %3670 = select <8 x i1> %.splat510, <8 x i1> %3652, <8 x i1> zeroinitializer
  %3671 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3672 = extractelement <8 x i32> %3671, i32 %3637
  %3673 = select i1 %3657, i32 %3672, i32 %3633
  store i32 %3673, ptr %current.token, align 4
  %.splatinsert511 = insertelement <8 x i1> poison, i1 %3647, i64 0
  %.splat512 = shufflevector <8 x i1> %.splatinsert511, <8 x i1> poison, <8 x i32> zeroinitializer
  %3674 = select <8 x i1> %.splat512, <8 x i1> %3670, <8 x i1> %convergence.cascade.flow503
  %3675 = add i32 %convergence.cascade.depth504, 1
  %3676 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3674)
  %3677 = icmp ult i32 %3675, 8
  %3678 = and i1 %3676, %3677
  %3679 = and i1 %3647, %3678
  %convergence.parent.token513 = load i32, ptr %current.token, align 4
  %convergence.parent.present514 = icmp ne i32 %convergence.parent.token513, 0
  %3680 = and i1 %3679, %convergence.parent.present514
  br i1 %3680, label %convergence.cascade499, label %convergence.cascade.exit500

convergence.cascade.exit500:                      ; preds = %convergence.cascade499, %schedule.19
  %convergence.cascade.result515 = phi <8 x i1> [ %415, %schedule.19 ], [ %3674, %convergence.cascade499 ]
  %3681 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result515)
  br i1 %3681, label %convergence.target.19.ready, label %scheduler.loop

convergence.target.19.ready:                      ; preds = %convergence.cascade.exit500
  %3682 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result515)
  %3683 = bitcast <8 x i1> %convergence.cascade.result515 to i8
  %3684 = call i8 @llvm.cttz.i8(i8 %3683, i1 false)
  %3685 = zext i8 %3684 to i32
  %3686 = select i1 %3682, i32 %3685, i32 0
  %tile_snapshot.spill.load516 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill59, align 64
  %3687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load516, 0
  %3688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load516, 1
  %.state517 = load <8 x i64>, ptr %.slot56, align 64
  %3689 = mul <8 x i64> %.state517, splat (i64 32)
  %3690 = add <8 x i64> %3688, %3689
  %3691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3687, 0
  %3692 = insertvalue { <8 x ptr>, <8 x i64> } %3691, <8 x i64> %3690, 1
  %.state518 = load <8 x float>, ptr %.slot58, align 32
  %3693 = extractvalue { <8 x ptr>, <8 x i64> } %3692, 0
  %3694 = extractvalue { <8 x ptr>, <8 x i64> } %3692, 1
  %3695 = getelementptr i8, <8 x ptr> %3693, <8 x i64> %3694
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state518, <8 x ptr> align 1 %3695, <8 x i1> %convergence.cascade.result515)
  %.state519 = load <8 x i64>, ptr %.slot56, align 64
  %3696 = add <8 x i64> %.state519, splat (i64 1)
  %3697 = load <8 x i64>, ptr %.slot56, align 64
  %3698 = select <8 x i1> %convergence.cascade.result515, <8 x i64> %3696, <8 x i64> %3697
  store <8 x i64> %3698, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result515, ptr %current.mask, align 1
  %3699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result515)
  br i1 %3699, label %schedule.16, label %scheduler.loop

convergence.cascade520:                           ; preds = %convergence.cascade520, %schedule.20
  %convergence.cascade.flow524 = phi <8 x i1> [ %416, %schedule.20 ], [ %3742, %convergence.cascade520 ]
  %convergence.cascade.depth525 = phi i32 [ 0, %schedule.20 ], [ %3743, %convergence.cascade520 ]
  %3700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow524)
  %3701 = load i32, ptr %current.token, align 4
  %3702 = icmp ne i32 %3701, 0
  %3703 = and i1 %3700, %3702
  %3704 = sub i32 %3701, 1
  %3705 = select i1 %3703, i32 %3704, i32 0
  %3706 = load i8, ptr %frame.active, align 1
  %3707 = trunc i32 %3705 to i8
  %3708 = shl i8 1, %3707
  %3709 = and i8 %3706, %3708
  %3710 = icmp ne i8 %3709, 0
  %3711 = load <8 x i32>, ptr %frame.static.id, align 32
  %3712 = extractelement <8 x i32> %3711, i32 %3705
  %convergence.target.pointer526 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3712
  %convergence.dynamic.target527 = load i32, ptr %convergence.target.pointer526, align 4
  %3713 = icmp eq i32 %convergence.dynamic.target527, 20
  %3714 = and i1 %3710, %3713
  %3715 = and i1 %3703, %3714
  %3716 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3705
  %3717 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3705
  %3718 = load <8 x i1>, ptr %3716, align 1
  %3719 = load <8 x i1>, ptr %3717, align 1
  %3720 = or <8 x i1> %3719, %convergence.cascade.flow524
  %3721 = load <8 x i1>, ptr %live.mask, align 1
  %3722 = and <8 x i1> %3718, %3721
  %3723 = icmp eq <8 x i1> %3720, %3722
  %3724 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3723)
  %3725 = and i1 %3715, %3724
  %3726 = select i1 %3725, <8 x i1> zeroinitializer, <8 x i1> %3720
  %3727 = select i1 %3715, <8 x i1> %3726, <8 x i1> %3719
  store <8 x i1> %3727, ptr %3717, align 1
  %3728 = select i1 %3725, <8 x i1> zeroinitializer, <8 x i1> %3718
  store <8 x i1> %3728, ptr %3716, align 1
  %3729 = trunc i32 %3705 to i8
  %3730 = shl i8 1, %3729
  %3731 = xor i8 %3730, -1
  %3732 = and i8 %3706, %3731
  %3733 = select i1 %3725, i8 %3732, i8 %3706
  store i8 %3733, ptr %frame.active, align 1
  %.splatinsert528 = insertelement <8 x i1> poison, i1 %3715, i64 0
  %.splat529 = shufflevector <8 x i1> %.splatinsert528, <8 x i1> poison, <8 x i32> zeroinitializer
  %3734 = and <8 x i1> %convergence.cascade.flow524, %.splat529
  %3735 = load <8 x i1>, ptr %runnable.mask, align 1
  %3736 = xor <8 x i1> %3734, splat (i1 true)
  %3737 = and <8 x i1> %3735, %3736
  store <8 x i1> %3737, ptr %runnable.mask, align 1
  %.splatinsert530 = insertelement <8 x i1> poison, i1 %3725, i64 0
  %.splat531 = shufflevector <8 x i1> %.splatinsert530, <8 x i1> poison, <8 x i32> zeroinitializer
  %3738 = select <8 x i1> %.splat531, <8 x i1> %3720, <8 x i1> zeroinitializer
  %3739 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3740 = extractelement <8 x i32> %3739, i32 %3705
  %3741 = select i1 %3725, i32 %3740, i32 %3701
  store i32 %3741, ptr %current.token, align 4
  %.splatinsert532 = insertelement <8 x i1> poison, i1 %3715, i64 0
  %.splat533 = shufflevector <8 x i1> %.splatinsert532, <8 x i1> poison, <8 x i32> zeroinitializer
  %3742 = select <8 x i1> %.splat533, <8 x i1> %3738, <8 x i1> %convergence.cascade.flow524
  %3743 = add i32 %convergence.cascade.depth525, 1
  %3744 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3742)
  %3745 = icmp ult i32 %3743, 8
  %3746 = and i1 %3744, %3745
  %3747 = and i1 %3715, %3746
  %convergence.parent.token534 = load i32, ptr %current.token, align 4
  %convergence.parent.present535 = icmp ne i32 %convergence.parent.token534, 0
  %3748 = and i1 %3747, %convergence.parent.present535
  br i1 %3748, label %convergence.cascade520, label %convergence.cascade.exit521

convergence.cascade.exit521:                      ; preds = %convergence.cascade520, %schedule.20
  %convergence.cascade.result536 = phi <8 x i1> [ %416, %schedule.20 ], [ %3742, %convergence.cascade520 ]
  %3749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  br i1 %3749, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit521
  %3750 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3751 = bitcast <8 x i1> %convergence.cascade.result536 to i8
  %3752 = call i8 @llvm.cttz.i8(i8 %3751, i1 false)
  %3753 = zext i8 %3752 to i32
  %3754 = select i1 %3750, i32 %3753, i32 0
  %3755 = load <8 x i64>, ptr %.slot56, align 64
  %3756 = select <8 x i1> %convergence.cascade.result536, <8 x i64> zeroinitializer, <8 x i64> %3755
  store <8 x i64> %3756, ptr %.slot56, align 64
  %3757 = load <8 x float>, ptr %.slot58, align 32
  %3758 = select <8 x i1> %convergence.cascade.result536, <8 x float> zeroinitializer, <8 x float> %3757
  store <8 x float> %3758, ptr %.slot58, align 32
  %3759 = load <8 x float>, ptr %.slot65, align 32
  %3760 = select <8 x i1> %convergence.cascade.result536, <8 x float> zeroinitializer, <8 x float> %3759
  store <8 x float> %3760, ptr %.slot65, align 32
  %3761 = load <8 x float>, ptr %.slot66, align 32
  %3762 = select <8 x i1> %convergence.cascade.result536, <8 x float> zeroinitializer, <8 x float> %3761
  store <8 x float> %3762, ptr %.slot66, align 32
  %3763 = load <8 x float>, ptr %.slot67, align 32
  %3764 = select <8 x i1> %convergence.cascade.result536, <8 x float> zeroinitializer, <8 x float> %3763
  store <8 x float> %3764, ptr %.slot67, align 32
  store <8 x i1> %convergence.cascade.result536, ptr %current.mask, align 1
  %3765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  br i1 %3765, label %schedule.21, label %scheduler.loop

varying.divergent538:                             ; preds = %schedule.21
  %3766 = load i32, ptr %current.token, align 4
  %3767 = icmp ne i32 %3766, 0
  %3768 = sub i32 %3766, 1
  %3769 = select i1 %3767, i32 %3768, i32 0
  %3770 = load i8, ptr %frame.active, align 1
  %3771 = trunc i32 %3769 to i8
  %3772 = shl i8 1, %3771
  %3773 = and i8 %3770, %3772
  %3774 = icmp ne i8 %3773, 0
  %3775 = load <8 x i32>, ptr %frame.static.id, align 32
  %3776 = extractelement <8 x i32> %3775, i32 %3769
  %3777 = icmp eq i32 %3776, 8
  %3778 = and i1 %3774, %3777
  %3779 = and i1 %3767, %3778
  %3780 = xor i1 %3779, true
  %3781 = and i1 true, %3780
  %3782 = xor i8 %3770, -1
  %3783 = icmp ne i8 %3782, 0
  %3784 = xor i1 %3783, true
  %3785 = and i1 %3781, %3784
  br i1 %3785, label %convergence.overflow.trap540, label %convergence.overflow.resume541

varying.coherent539:                              ; preds = %schedule.21
  br i1 %427, label %varying.coherent.true544, label %varying.coherent.false545

convergence.overflow.trap540:                     ; preds = %varying.divergent538
  call void @llvm.trap()
  unreachable

convergence.overflow.resume541:                   ; preds = %varying.divergent538
  %3786 = call i8 @llvm.cttz.i8(i8 %3782, i1 false)
  %3787 = zext i8 %3786 to i32
  %3788 = select i1 %3783, i32 %3787, i32 0
  %3789 = trunc i32 %3788 to i8
  %3790 = shl i8 1, %3789
  %3791 = or i8 %3770, %3790
  %3792 = select i1 %3781, i8 %3791, i8 %3770
  store i8 %3792, ptr %frame.active, align 1
  %3793 = load <8 x i32>, ptr %frame.static.id, align 32
  %3794 = extractelement <8 x i32> %3793, i32 %3788
  %3795 = select i1 %3781, i32 8, i32 %3794
  %3796 = load <8 x i32>, ptr %frame.static.id, align 32
  %3797 = insertelement <8 x i32> %3796, i32 %3795, i32 %3788
  store <8 x i32> %3797, ptr %frame.static.id, align 32
  %3798 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3799 = extractelement <8 x i32> %3798, i32 %3788
  %3800 = select i1 %3781, i32 %3766, i32 %3799
  %3801 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3802 = insertelement <8 x i32> %3801, i32 %3800, i32 %3788
  store <8 x i32> %3802, ptr %frame.parent.token, align 32
  %3803 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3788
  %3804 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3788
  %3805 = load <8 x i1>, ptr %3803, align 1
  %3806 = load <8 x i1>, ptr %3804, align 1
  %3807 = select i1 %3781, <8 x i1> %417, <8 x i1> %3805
  store <8 x i1> %3807, ptr %3803, align 1
  %3808 = select i1 %3781, <8 x i1> zeroinitializer, <8 x i1> %3806
  store <8 x i1> %3808, ptr %3804, align 1
  %3809 = add i32 %3788, 1
  %3810 = select i1 %3779, i32 %3766, i32 %3809
  %3811 = select i1 true, i32 %3810, i32 %3766
  store i32 %3811, ptr %current.token, align 4
  %3812 = load i32, ptr %current.token, align 4
  %3813 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %424)
  %3814 = load i32, ptr %ready.count, align 4
  %3815 = icmp uge i32 %3814, 8
  %3816 = and i1 %3813, %3815
  br i1 %3816, label %ready.overflow.trap542, label %ready.overflow.resume543

ready.overflow.trap542:                           ; preds = %convergence.overflow.resume541
  call void @llvm.trap()
  unreachable

ready.overflow.resume543:                         ; preds = %convergence.overflow.resume541
  %3817 = select i1 %3813, i32 %3814, i32 0
  %3818 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3817
  %3819 = load <8 x i1>, ptr %3818, align 1
  %3820 = select i1 %3813, <8 x i1> %424, <8 x i1> %3819
  store <8 x i1> %3820, ptr %3818, align 1
  %3821 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3817
  %3822 = load i32, ptr %3821, align 4
  %3823 = select i1 %3813, i32 22, i32 %3822
  store i32 %3823, ptr %3821, align 4
  %3824 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3817
  %3825 = load i32, ptr %3824, align 4
  %3826 = select i1 %3813, i32 %3812, i32 %3825
  store i32 %3826, ptr %3824, align 4
  %3827 = add i32 %3814, 1
  %3828 = select i1 %3813, i32 %3827, i32 %3814
  store i32 %3828, ptr %ready.count, align 4
  %3829 = load <8 x i1>, ptr %runnable.mask, align 1
  %3830 = or <8 x i1> %3829, %424
  store <8 x i1> %3830, ptr %runnable.mask, align 1
  store <8 x i1> %426, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true544:                         ; preds = %varying.coherent539
  store <8 x i1> %417, ptr %current.mask, align 1
  %3831 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %417)
  br i1 %3831, label %schedule.22, label %scheduler.loop

varying.coherent.false545:                        ; preds = %varying.coherent539
  store <8 x i1> %417, ptr %current.mask, align 1
  %3832 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %417)
  br i1 %3832, label %schedule.23, label %scheduler.loop

convergence.cascade560:                           ; preds = %convergence.cascade560, %schedule.23
  %convergence.cascade.flow564 = phi <8 x i1> [ %510, %schedule.23 ], [ %3875, %convergence.cascade560 ]
  %convergence.cascade.depth565 = phi i32 [ 0, %schedule.23 ], [ %3876, %convergence.cascade560 ]
  %3833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow564)
  %3834 = load i32, ptr %current.token, align 4
  %3835 = icmp ne i32 %3834, 0
  %3836 = and i1 %3833, %3835
  %3837 = sub i32 %3834, 1
  %3838 = select i1 %3836, i32 %3837, i32 0
  %3839 = load i8, ptr %frame.active, align 1
  %3840 = trunc i32 %3838 to i8
  %3841 = shl i8 1, %3840
  %3842 = and i8 %3839, %3841
  %3843 = icmp ne i8 %3842, 0
  %3844 = load <8 x i32>, ptr %frame.static.id, align 32
  %3845 = extractelement <8 x i32> %3844, i32 %3838
  %convergence.target.pointer566 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3845
  %convergence.dynamic.target567 = load i32, ptr %convergence.target.pointer566, align 4
  %3846 = icmp eq i32 %convergence.dynamic.target567, 23
  %3847 = and i1 %3843, %3846
  %3848 = and i1 %3836, %3847
  %3849 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3838
  %3850 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3838
  %3851 = load <8 x i1>, ptr %3849, align 1
  %3852 = load <8 x i1>, ptr %3850, align 1
  %3853 = or <8 x i1> %3852, %convergence.cascade.flow564
  %3854 = load <8 x i1>, ptr %live.mask, align 1
  %3855 = and <8 x i1> %3851, %3854
  %3856 = icmp eq <8 x i1> %3853, %3855
  %3857 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3856)
  %3858 = and i1 %3848, %3857
  %3859 = select i1 %3858, <8 x i1> zeroinitializer, <8 x i1> %3853
  %3860 = select i1 %3848, <8 x i1> %3859, <8 x i1> %3852
  store <8 x i1> %3860, ptr %3850, align 1
  %3861 = select i1 %3858, <8 x i1> zeroinitializer, <8 x i1> %3851
  store <8 x i1> %3861, ptr %3849, align 1
  %3862 = trunc i32 %3838 to i8
  %3863 = shl i8 1, %3862
  %3864 = xor i8 %3863, -1
  %3865 = and i8 %3839, %3864
  %3866 = select i1 %3858, i8 %3865, i8 %3839
  store i8 %3866, ptr %frame.active, align 1
  %.splatinsert568 = insertelement <8 x i1> poison, i1 %3848, i64 0
  %.splat569 = shufflevector <8 x i1> %.splatinsert568, <8 x i1> poison, <8 x i32> zeroinitializer
  %3867 = and <8 x i1> %convergence.cascade.flow564, %.splat569
  %3868 = load <8 x i1>, ptr %runnable.mask, align 1
  %3869 = xor <8 x i1> %3867, splat (i1 true)
  %3870 = and <8 x i1> %3868, %3869
  store <8 x i1> %3870, ptr %runnable.mask, align 1
  %.splatinsert570 = insertelement <8 x i1> poison, i1 %3858, i64 0
  %.splat571 = shufflevector <8 x i1> %.splatinsert570, <8 x i1> poison, <8 x i32> zeroinitializer
  %3871 = select <8 x i1> %.splat571, <8 x i1> %3853, <8 x i1> zeroinitializer
  %3872 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3873 = extractelement <8 x i32> %3872, i32 %3838
  %3874 = select i1 %3858, i32 %3873, i32 %3834
  store i32 %3874, ptr %current.token, align 4
  %.splatinsert572 = insertelement <8 x i1> poison, i1 %3848, i64 0
  %.splat573 = shufflevector <8 x i1> %.splatinsert572, <8 x i1> poison, <8 x i32> zeroinitializer
  %3875 = select <8 x i1> %.splat573, <8 x i1> %3871, <8 x i1> %convergence.cascade.flow564
  %3876 = add i32 %convergence.cascade.depth565, 1
  %3877 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3875)
  %3878 = icmp ult i32 %3876, 8
  %3879 = and i1 %3877, %3878
  %3880 = and i1 %3848, %3879
  %convergence.parent.token574 = load i32, ptr %current.token, align 4
  %convergence.parent.present575 = icmp ne i32 %convergence.parent.token574, 0
  %3881 = and i1 %3880, %convergence.parent.present575
  br i1 %3881, label %convergence.cascade560, label %convergence.cascade.exit561

convergence.cascade.exit561:                      ; preds = %convergence.cascade560, %schedule.23
  %convergence.cascade.result576 = phi <8 x i1> [ %510, %schedule.23 ], [ %3875, %convergence.cascade560 ]
  %3882 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result576)
  br i1 %3882, label %convergence.target.23.ready, label %scheduler.loop

convergence.target.23.ready:                      ; preds = %convergence.cascade.exit561
  %3883 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result576)
  %3884 = bitcast <8 x i1> %convergence.cascade.result576 to i8
  %3885 = call i8 @llvm.cttz.i8(i8 %3884, i1 false)
  %3886 = zext i8 %3885 to i32
  %3887 = select i1 %3883, i32 %3886, i32 0
  %3888 = load <8 x i64>, ptr %.slot56, align 64
  %3889 = select <8 x i1> %convergence.cascade.result576, <8 x i64> zeroinitializer, <8 x i64> %3888
  store <8 x i64> %3889, ptr %.slot56, align 64
  %3890 = load <8 x float>, ptr %.slot69, align 32
  %3891 = select <8 x i1> %convergence.cascade.result576, <8 x float> zeroinitializer, <8 x float> %3890
  store <8 x float> %3891, ptr %.slot69, align 32
  %3892 = load <8 x float>, ptr %.slot70, align 32
  %3893 = select <8 x i1> %convergence.cascade.result576, <8 x float> zeroinitializer, <8 x float> %3892
  store <8 x float> %3893, ptr %.slot70, align 32
  %3894 = load <8 x float>, ptr %.slot71, align 32
  %3895 = select <8 x i1> %convergence.cascade.result576, <8 x float> zeroinitializer, <8 x float> %3894
  store <8 x float> %3895, ptr %.slot71, align 32
  %3896 = load <8 x float>, ptr %.slot72, align 32
  %3897 = select <8 x i1> %convergence.cascade.result576, <8 x float> zeroinitializer, <8 x float> %3896
  store <8 x float> %3897, ptr %.slot72, align 32
  store <8 x i1> %convergence.cascade.result576, ptr %current.mask, align 1
  %3898 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result576)
  br i1 %3898, label %schedule.24, label %scheduler.loop

varying.divergent578:                             ; preds = %schedule.24
  %3899 = load i32, ptr %current.token, align 4
  %3900 = icmp ne i32 %3899, 0
  %3901 = sub i32 %3899, 1
  %3902 = select i1 %3900, i32 %3901, i32 0
  %3903 = load i8, ptr %frame.active, align 1
  %3904 = trunc i32 %3902 to i8
  %3905 = shl i8 1, %3904
  %3906 = and i8 %3903, %3905
  %3907 = icmp ne i8 %3906, 0
  %3908 = load <8 x i32>, ptr %frame.static.id, align 32
  %3909 = extractelement <8 x i32> %3908, i32 %3902
  %3910 = icmp eq i32 %3909, 9
  %3911 = and i1 %3907, %3910
  %3912 = and i1 %3900, %3911
  %3913 = xor i1 %3912, true
  %3914 = and i1 true, %3913
  %3915 = xor i8 %3903, -1
  %3916 = icmp ne i8 %3915, 0
  %3917 = xor i1 %3916, true
  %3918 = and i1 %3914, %3917
  br i1 %3918, label %convergence.overflow.trap580, label %convergence.overflow.resume581

varying.coherent579:                              ; preds = %schedule.24
  br i1 %521, label %varying.coherent.true584, label %varying.coherent.false585

convergence.overflow.trap580:                     ; preds = %varying.divergent578
  call void @llvm.trap()
  unreachable

convergence.overflow.resume581:                   ; preds = %varying.divergent578
  %3919 = call i8 @llvm.cttz.i8(i8 %3915, i1 false)
  %3920 = zext i8 %3919 to i32
  %3921 = select i1 %3916, i32 %3920, i32 0
  %3922 = trunc i32 %3921 to i8
  %3923 = shl i8 1, %3922
  %3924 = or i8 %3903, %3923
  %3925 = select i1 %3914, i8 %3924, i8 %3903
  store i8 %3925, ptr %frame.active, align 1
  %3926 = load <8 x i32>, ptr %frame.static.id, align 32
  %3927 = extractelement <8 x i32> %3926, i32 %3921
  %3928 = select i1 %3914, i32 9, i32 %3927
  %3929 = load <8 x i32>, ptr %frame.static.id, align 32
  %3930 = insertelement <8 x i32> %3929, i32 %3928, i32 %3921
  store <8 x i32> %3930, ptr %frame.static.id, align 32
  %3931 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3932 = extractelement <8 x i32> %3931, i32 %3921
  %3933 = select i1 %3914, i32 %3899, i32 %3932
  %3934 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3935 = insertelement <8 x i32> %3934, i32 %3933, i32 %3921
  store <8 x i32> %3935, ptr %frame.parent.token, align 32
  %3936 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3921
  %3937 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3921
  %3938 = load <8 x i1>, ptr %3936, align 1
  %3939 = load <8 x i1>, ptr %3937, align 1
  %3940 = select i1 %3914, <8 x i1> %511, <8 x i1> %3938
  store <8 x i1> %3940, ptr %3936, align 1
  %3941 = select i1 %3914, <8 x i1> zeroinitializer, <8 x i1> %3939
  store <8 x i1> %3941, ptr %3937, align 1
  %3942 = add i32 %3921, 1
  %3943 = select i1 %3912, i32 %3899, i32 %3942
  %3944 = select i1 true, i32 %3943, i32 %3899
  store i32 %3944, ptr %current.token, align 4
  %3945 = load i32, ptr %current.token, align 4
  %3946 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %518)
  %3947 = load i32, ptr %ready.count, align 4
  %3948 = icmp uge i32 %3947, 8
  %3949 = and i1 %3946, %3948
  br i1 %3949, label %ready.overflow.trap582, label %ready.overflow.resume583

ready.overflow.trap582:                           ; preds = %convergence.overflow.resume581
  call void @llvm.trap()
  unreachable

ready.overflow.resume583:                         ; preds = %convergence.overflow.resume581
  %3950 = select i1 %3946, i32 %3947, i32 0
  %3951 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3950
  %3952 = load <8 x i1>, ptr %3951, align 1
  %3953 = select i1 %3946, <8 x i1> %518, <8 x i1> %3952
  store <8 x i1> %3953, ptr %3951, align 1
  %3954 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3950
  %3955 = load i32, ptr %3954, align 4
  %3956 = select i1 %3946, i32 25, i32 %3955
  store i32 %3956, ptr %3954, align 4
  %3957 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3950
  %3958 = load i32, ptr %3957, align 4
  %3959 = select i1 %3946, i32 %3945, i32 %3958
  store i32 %3959, ptr %3957, align 4
  %3960 = add i32 %3947, 1
  %3961 = select i1 %3946, i32 %3960, i32 %3947
  store i32 %3961, ptr %ready.count, align 4
  %3962 = load <8 x i1>, ptr %runnable.mask, align 1
  %3963 = or <8 x i1> %3962, %518
  store <8 x i1> %3963, ptr %runnable.mask, align 1
  store <8 x i1> %520, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true584:                         ; preds = %varying.coherent579
  store <8 x i1> %511, ptr %current.mask, align 1
  %3964 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %511)
  br i1 %3964, label %schedule.25, label %scheduler.loop

varying.coherent.false585:                        ; preds = %varying.coherent579
  store <8 x i1> %511, ptr %current.mask, align 1
  %3965 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %511)
  br i1 %3965, label %schedule.26, label %scheduler.loop

convergence.cascade601:                           ; preds = %convergence.cascade601, %schedule.26
  %convergence.cascade.flow605 = phi <8 x i1> [ %605, %schedule.26 ], [ %4008, %convergence.cascade601 ]
  %convergence.cascade.depth606 = phi i32 [ 0, %schedule.26 ], [ %4009, %convergence.cascade601 ]
  %3966 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow605)
  %3967 = load i32, ptr %current.token, align 4
  %3968 = icmp ne i32 %3967, 0
  %3969 = and i1 %3966, %3968
  %3970 = sub i32 %3967, 1
  %3971 = select i1 %3969, i32 %3970, i32 0
  %3972 = load i8, ptr %frame.active, align 1
  %3973 = trunc i32 %3971 to i8
  %3974 = shl i8 1, %3973
  %3975 = and i8 %3972, %3974
  %3976 = icmp ne i8 %3975, 0
  %3977 = load <8 x i32>, ptr %frame.static.id, align 32
  %3978 = extractelement <8 x i32> %3977, i32 %3971
  %convergence.target.pointer607 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3978
  %convergence.dynamic.target608 = load i32, ptr %convergence.target.pointer607, align 4
  %3979 = icmp eq i32 %convergence.dynamic.target608, 26
  %3980 = and i1 %3976, %3979
  %3981 = and i1 %3969, %3980
  %3982 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3971
  %3983 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3971
  %3984 = load <8 x i1>, ptr %3982, align 1
  %3985 = load <8 x i1>, ptr %3983, align 1
  %3986 = or <8 x i1> %3985, %convergence.cascade.flow605
  %3987 = load <8 x i1>, ptr %live.mask, align 1
  %3988 = and <8 x i1> %3984, %3987
  %3989 = icmp eq <8 x i1> %3986, %3988
  %3990 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3989)
  %3991 = and i1 %3981, %3990
  %3992 = select i1 %3991, <8 x i1> zeroinitializer, <8 x i1> %3986
  %3993 = select i1 %3981, <8 x i1> %3992, <8 x i1> %3985
  store <8 x i1> %3993, ptr %3983, align 1
  %3994 = select i1 %3991, <8 x i1> zeroinitializer, <8 x i1> %3984
  store <8 x i1> %3994, ptr %3982, align 1
  %3995 = trunc i32 %3971 to i8
  %3996 = shl i8 1, %3995
  %3997 = xor i8 %3996, -1
  %3998 = and i8 %3972, %3997
  %3999 = select i1 %3991, i8 %3998, i8 %3972
  store i8 %3999, ptr %frame.active, align 1
  %.splatinsert609 = insertelement <8 x i1> poison, i1 %3981, i64 0
  %.splat610 = shufflevector <8 x i1> %.splatinsert609, <8 x i1> poison, <8 x i32> zeroinitializer
  %4000 = and <8 x i1> %convergence.cascade.flow605, %.splat610
  %4001 = load <8 x i1>, ptr %runnable.mask, align 1
  %4002 = xor <8 x i1> %4000, splat (i1 true)
  %4003 = and <8 x i1> %4001, %4002
  store <8 x i1> %4003, ptr %runnable.mask, align 1
  %.splatinsert611 = insertelement <8 x i1> poison, i1 %3991, i64 0
  %.splat612 = shufflevector <8 x i1> %.splatinsert611, <8 x i1> poison, <8 x i32> zeroinitializer
  %4004 = select <8 x i1> %.splat612, <8 x i1> %3986, <8 x i1> zeroinitializer
  %4005 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4006 = extractelement <8 x i32> %4005, i32 %3971
  %4007 = select i1 %3991, i32 %4006, i32 %3967
  store i32 %4007, ptr %current.token, align 4
  %.splatinsert613 = insertelement <8 x i1> poison, i1 %3981, i64 0
  %.splat614 = shufflevector <8 x i1> %.splatinsert613, <8 x i1> poison, <8 x i32> zeroinitializer
  %4008 = select <8 x i1> %.splat614, <8 x i1> %4004, <8 x i1> %convergence.cascade.flow605
  %4009 = add i32 %convergence.cascade.depth606, 1
  %4010 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4008)
  %4011 = icmp ult i32 %4009, 8
  %4012 = and i1 %4010, %4011
  %4013 = and i1 %3981, %4012
  %convergence.parent.token615 = load i32, ptr %current.token, align 4
  %convergence.parent.present616 = icmp ne i32 %convergence.parent.token615, 0
  %4014 = and i1 %4013, %convergence.parent.present616
  br i1 %4014, label %convergence.cascade601, label %convergence.cascade.exit602

convergence.cascade.exit602:                      ; preds = %convergence.cascade601, %schedule.26
  %convergence.cascade.result617 = phi <8 x i1> [ %605, %schedule.26 ], [ %4008, %convergence.cascade601 ]
  %4015 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result617)
  br i1 %4015, label %convergence.target.26.ready, label %scheduler.loop

convergence.target.26.ready:                      ; preds = %convergence.cascade.exit602
  %4016 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result617)
  %4017 = bitcast <8 x i1> %convergence.cascade.result617 to i8
  %4018 = call i8 @llvm.cttz.i8(i8 %4017, i1 false)
  %4019 = zext i8 %4018 to i32
  %4020 = select i1 %4016, i32 %4019, i32 0
  %4021 = load <8 x i64>, ptr %.slot56, align 64
  %4022 = select <8 x i1> %convergence.cascade.result617, <8 x i64> zeroinitializer, <8 x i64> %4021
  store <8 x i64> %4022, ptr %.slot56, align 64
  %4023 = load <8 x float>, ptr %.slot74, align 32
  %4024 = select <8 x i1> %convergence.cascade.result617, <8 x float> zeroinitializer, <8 x float> %4023
  store <8 x float> %4024, ptr %.slot74, align 32
  %4025 = load <8 x float>, ptr %.slot75, align 32
  %4026 = select <8 x i1> %convergence.cascade.result617, <8 x float> zeroinitializer, <8 x float> %4025
  store <8 x float> %4026, ptr %.slot75, align 32
  %4027 = load <8 x float>, ptr %.slot76, align 32
  %4028 = select <8 x i1> %convergence.cascade.result617, <8 x float> zeroinitializer, <8 x float> %4027
  store <8 x float> %4028, ptr %.slot76, align 32
  %4029 = load <8 x float>, ptr %.slot77, align 32
  %4030 = select <8 x i1> %convergence.cascade.result617, <8 x float> zeroinitializer, <8 x float> %4029
  store <8 x float> %4030, ptr %.slot77, align 32
  store <8 x i1> %convergence.cascade.result617, ptr %current.mask, align 1
  %4031 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result617)
  br i1 %4031, label %schedule.27, label %scheduler.loop

varying.divergent619:                             ; preds = %schedule.27
  %4032 = load i32, ptr %current.token, align 4
  %4033 = icmp ne i32 %4032, 0
  %4034 = sub i32 %4032, 1
  %4035 = select i1 %4033, i32 %4034, i32 0
  %4036 = load i8, ptr %frame.active, align 1
  %4037 = trunc i32 %4035 to i8
  %4038 = shl i8 1, %4037
  %4039 = and i8 %4036, %4038
  %4040 = icmp ne i8 %4039, 0
  %4041 = load <8 x i32>, ptr %frame.static.id, align 32
  %4042 = extractelement <8 x i32> %4041, i32 %4035
  %4043 = icmp eq i32 %4042, 10
  %4044 = and i1 %4040, %4043
  %4045 = and i1 %4033, %4044
  %4046 = xor i1 %4045, true
  %4047 = and i1 true, %4046
  %4048 = xor i8 %4036, -1
  %4049 = icmp ne i8 %4048, 0
  %4050 = xor i1 %4049, true
  %4051 = and i1 %4047, %4050
  br i1 %4051, label %convergence.overflow.trap621, label %convergence.overflow.resume622

varying.coherent620:                              ; preds = %schedule.27
  br i1 %616, label %varying.coherent.true625, label %varying.coherent.false626

convergence.overflow.trap621:                     ; preds = %varying.divergent619
  call void @llvm.trap()
  unreachable

convergence.overflow.resume622:                   ; preds = %varying.divergent619
  %4052 = call i8 @llvm.cttz.i8(i8 %4048, i1 false)
  %4053 = zext i8 %4052 to i32
  %4054 = select i1 %4049, i32 %4053, i32 0
  %4055 = trunc i32 %4054 to i8
  %4056 = shl i8 1, %4055
  %4057 = or i8 %4036, %4056
  %4058 = select i1 %4047, i8 %4057, i8 %4036
  store i8 %4058, ptr %frame.active, align 1
  %4059 = load <8 x i32>, ptr %frame.static.id, align 32
  %4060 = extractelement <8 x i32> %4059, i32 %4054
  %4061 = select i1 %4047, i32 10, i32 %4060
  %4062 = load <8 x i32>, ptr %frame.static.id, align 32
  %4063 = insertelement <8 x i32> %4062, i32 %4061, i32 %4054
  store <8 x i32> %4063, ptr %frame.static.id, align 32
  %4064 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4065 = extractelement <8 x i32> %4064, i32 %4054
  %4066 = select i1 %4047, i32 %4032, i32 %4065
  %4067 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4068 = insertelement <8 x i32> %4067, i32 %4066, i32 %4054
  store <8 x i32> %4068, ptr %frame.parent.token, align 32
  %4069 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4054
  %4070 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4054
  %4071 = load <8 x i1>, ptr %4069, align 1
  %4072 = load <8 x i1>, ptr %4070, align 1
  %4073 = select i1 %4047, <8 x i1> %606, <8 x i1> %4071
  store <8 x i1> %4073, ptr %4069, align 1
  %4074 = select i1 %4047, <8 x i1> zeroinitializer, <8 x i1> %4072
  store <8 x i1> %4074, ptr %4070, align 1
  %4075 = add i32 %4054, 1
  %4076 = select i1 %4045, i32 %4032, i32 %4075
  %4077 = select i1 true, i32 %4076, i32 %4032
  store i32 %4077, ptr %current.token, align 4
  %4078 = load i32, ptr %current.token, align 4
  %4079 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %613)
  %4080 = load i32, ptr %ready.count, align 4
  %4081 = icmp uge i32 %4080, 8
  %4082 = and i1 %4079, %4081
  br i1 %4082, label %ready.overflow.trap623, label %ready.overflow.resume624

ready.overflow.trap623:                           ; preds = %convergence.overflow.resume622
  call void @llvm.trap()
  unreachable

ready.overflow.resume624:                         ; preds = %convergence.overflow.resume622
  %4083 = select i1 %4079, i32 %4080, i32 0
  %4084 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4083
  %4085 = load <8 x i1>, ptr %4084, align 1
  %4086 = select i1 %4079, <8 x i1> %613, <8 x i1> %4085
  store <8 x i1> %4086, ptr %4084, align 1
  %4087 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4083
  %4088 = load i32, ptr %4087, align 4
  %4089 = select i1 %4079, i32 28, i32 %4088
  store i32 %4089, ptr %4087, align 4
  %4090 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4083
  %4091 = load i32, ptr %4090, align 4
  %4092 = select i1 %4079, i32 %4078, i32 %4091
  store i32 %4092, ptr %4090, align 4
  %4093 = add i32 %4080, 1
  %4094 = select i1 %4079, i32 %4093, i32 %4080
  store i32 %4094, ptr %ready.count, align 4
  %4095 = load <8 x i1>, ptr %runnable.mask, align 1
  %4096 = or <8 x i1> %4095, %613
  store <8 x i1> %4096, ptr %runnable.mask, align 1
  store <8 x i1> %615, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true625:                         ; preds = %varying.coherent620
  store <8 x i1> %606, ptr %current.mask, align 1
  %4097 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %606)
  br i1 %4097, label %schedule.28, label %scheduler.loop

varying.coherent.false626:                        ; preds = %varying.coherent620
  store <8 x i1> %606, ptr %current.mask, align 1
  %4098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %606)
  br i1 %4098, label %schedule.29, label %scheduler.loop

convergence.cascade642:                           ; preds = %convergence.cascade642, %schedule.29
  %convergence.cascade.flow646 = phi <8 x i1> [ %700, %schedule.29 ], [ %4141, %convergence.cascade642 ]
  %convergence.cascade.depth647 = phi i32 [ 0, %schedule.29 ], [ %4142, %convergence.cascade642 ]
  %4099 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow646)
  %4100 = load i32, ptr %current.token, align 4
  %4101 = icmp ne i32 %4100, 0
  %4102 = and i1 %4099, %4101
  %4103 = sub i32 %4100, 1
  %4104 = select i1 %4102, i32 %4103, i32 0
  %4105 = load i8, ptr %frame.active, align 1
  %4106 = trunc i32 %4104 to i8
  %4107 = shl i8 1, %4106
  %4108 = and i8 %4105, %4107
  %4109 = icmp ne i8 %4108, 0
  %4110 = load <8 x i32>, ptr %frame.static.id, align 32
  %4111 = extractelement <8 x i32> %4110, i32 %4104
  %convergence.target.pointer648 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4111
  %convergence.dynamic.target649 = load i32, ptr %convergence.target.pointer648, align 4
  %4112 = icmp eq i32 %convergence.dynamic.target649, 29
  %4113 = and i1 %4109, %4112
  %4114 = and i1 %4102, %4113
  %4115 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4104
  %4116 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4104
  %4117 = load <8 x i1>, ptr %4115, align 1
  %4118 = load <8 x i1>, ptr %4116, align 1
  %4119 = or <8 x i1> %4118, %convergence.cascade.flow646
  %4120 = load <8 x i1>, ptr %live.mask, align 1
  %4121 = and <8 x i1> %4117, %4120
  %4122 = icmp eq <8 x i1> %4119, %4121
  %4123 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4122)
  %4124 = and i1 %4114, %4123
  %4125 = select i1 %4124, <8 x i1> zeroinitializer, <8 x i1> %4119
  %4126 = select i1 %4114, <8 x i1> %4125, <8 x i1> %4118
  store <8 x i1> %4126, ptr %4116, align 1
  %4127 = select i1 %4124, <8 x i1> zeroinitializer, <8 x i1> %4117
  store <8 x i1> %4127, ptr %4115, align 1
  %4128 = trunc i32 %4104 to i8
  %4129 = shl i8 1, %4128
  %4130 = xor i8 %4129, -1
  %4131 = and i8 %4105, %4130
  %4132 = select i1 %4124, i8 %4131, i8 %4105
  store i8 %4132, ptr %frame.active, align 1
  %.splatinsert650 = insertelement <8 x i1> poison, i1 %4114, i64 0
  %.splat651 = shufflevector <8 x i1> %.splatinsert650, <8 x i1> poison, <8 x i32> zeroinitializer
  %4133 = and <8 x i1> %convergence.cascade.flow646, %.splat651
  %4134 = load <8 x i1>, ptr %runnable.mask, align 1
  %4135 = xor <8 x i1> %4133, splat (i1 true)
  %4136 = and <8 x i1> %4134, %4135
  store <8 x i1> %4136, ptr %runnable.mask, align 1
  %.splatinsert652 = insertelement <8 x i1> poison, i1 %4124, i64 0
  %.splat653 = shufflevector <8 x i1> %.splatinsert652, <8 x i1> poison, <8 x i32> zeroinitializer
  %4137 = select <8 x i1> %.splat653, <8 x i1> %4119, <8 x i1> zeroinitializer
  %4138 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4139 = extractelement <8 x i32> %4138, i32 %4104
  %4140 = select i1 %4124, i32 %4139, i32 %4100
  store i32 %4140, ptr %current.token, align 4
  %.splatinsert654 = insertelement <8 x i1> poison, i1 %4114, i64 0
  %.splat655 = shufflevector <8 x i1> %.splatinsert654, <8 x i1> poison, <8 x i32> zeroinitializer
  %4141 = select <8 x i1> %.splat655, <8 x i1> %4137, <8 x i1> %convergence.cascade.flow646
  %4142 = add i32 %convergence.cascade.depth647, 1
  %4143 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4141)
  %4144 = icmp ult i32 %4142, 8
  %4145 = and i1 %4143, %4144
  %4146 = and i1 %4114, %4145
  %convergence.parent.token656 = load i32, ptr %current.token, align 4
  %convergence.parent.present657 = icmp ne i32 %convergence.parent.token656, 0
  %4147 = and i1 %4146, %convergence.parent.present657
  br i1 %4147, label %convergence.cascade642, label %convergence.cascade.exit643

convergence.cascade.exit643:                      ; preds = %convergence.cascade642, %schedule.29
  %convergence.cascade.result658 = phi <8 x i1> [ %700, %schedule.29 ], [ %4141, %convergence.cascade642 ]
  %4148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result658)
  br i1 %4148, label %convergence.target.29.ready, label %scheduler.loop

convergence.target.29.ready:                      ; preds = %convergence.cascade.exit643
  %4149 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result658)
  %4150 = bitcast <8 x i1> %convergence.cascade.result658 to i8
  %4151 = call i8 @llvm.cttz.i8(i8 %4150, i1 false)
  %4152 = zext i8 %4151 to i32
  %4153 = select i1 %4149, i32 %4152, i32 0
  %4154 = load <8 x i64>, ptr %.slot56, align 64
  %4155 = select <8 x i1> %convergence.cascade.result658, <8 x i64> zeroinitializer, <8 x i64> %4154
  store <8 x i64> %4155, ptr %.slot56, align 64
  %4156 = load <8 x float>, ptr %.slot79, align 32
  %4157 = select <8 x i1> %convergence.cascade.result658, <8 x float> zeroinitializer, <8 x float> %4156
  store <8 x float> %4157, ptr %.slot79, align 32
  %4158 = load <8 x float>, ptr %.slot80, align 32
  %4159 = select <8 x i1> %convergence.cascade.result658, <8 x float> zeroinitializer, <8 x float> %4158
  store <8 x float> %4159, ptr %.slot80, align 32
  %4160 = load <8 x float>, ptr %.slot81, align 32
  %4161 = select <8 x i1> %convergence.cascade.result658, <8 x float> zeroinitializer, <8 x float> %4160
  store <8 x float> %4161, ptr %.slot81, align 32
  %4162 = load <8 x float>, ptr %.slot82, align 32
  %4163 = select <8 x i1> %convergence.cascade.result658, <8 x float> zeroinitializer, <8 x float> %4162
  store <8 x float> %4163, ptr %.slot82, align 32
  store <8 x i1> %convergence.cascade.result658, ptr %current.mask, align 1
  %4164 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result658)
  br i1 %4164, label %schedule.30, label %scheduler.loop

varying.divergent660:                             ; preds = %schedule.30
  %4165 = load i32, ptr %current.token, align 4
  %4166 = icmp ne i32 %4165, 0
  %4167 = sub i32 %4165, 1
  %4168 = select i1 %4166, i32 %4167, i32 0
  %4169 = load i8, ptr %frame.active, align 1
  %4170 = trunc i32 %4168 to i8
  %4171 = shl i8 1, %4170
  %4172 = and i8 %4169, %4171
  %4173 = icmp ne i8 %4172, 0
  %4174 = load <8 x i32>, ptr %frame.static.id, align 32
  %4175 = extractelement <8 x i32> %4174, i32 %4168
  %4176 = icmp eq i32 %4175, 11
  %4177 = and i1 %4173, %4176
  %4178 = and i1 %4166, %4177
  %4179 = xor i1 %4178, true
  %4180 = and i1 true, %4179
  %4181 = xor i8 %4169, -1
  %4182 = icmp ne i8 %4181, 0
  %4183 = xor i1 %4182, true
  %4184 = and i1 %4180, %4183
  br i1 %4184, label %convergence.overflow.trap662, label %convergence.overflow.resume663

varying.coherent661:                              ; preds = %schedule.30
  br i1 %711, label %varying.coherent.true666, label %varying.coherent.false667

convergence.overflow.trap662:                     ; preds = %varying.divergent660
  call void @llvm.trap()
  unreachable

convergence.overflow.resume663:                   ; preds = %varying.divergent660
  %4185 = call i8 @llvm.cttz.i8(i8 %4181, i1 false)
  %4186 = zext i8 %4185 to i32
  %4187 = select i1 %4182, i32 %4186, i32 0
  %4188 = trunc i32 %4187 to i8
  %4189 = shl i8 1, %4188
  %4190 = or i8 %4169, %4189
  %4191 = select i1 %4180, i8 %4190, i8 %4169
  store i8 %4191, ptr %frame.active, align 1
  %4192 = load <8 x i32>, ptr %frame.static.id, align 32
  %4193 = extractelement <8 x i32> %4192, i32 %4187
  %4194 = select i1 %4180, i32 11, i32 %4193
  %4195 = load <8 x i32>, ptr %frame.static.id, align 32
  %4196 = insertelement <8 x i32> %4195, i32 %4194, i32 %4187
  store <8 x i32> %4196, ptr %frame.static.id, align 32
  %4197 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4198 = extractelement <8 x i32> %4197, i32 %4187
  %4199 = select i1 %4180, i32 %4165, i32 %4198
  %4200 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4201 = insertelement <8 x i32> %4200, i32 %4199, i32 %4187
  store <8 x i32> %4201, ptr %frame.parent.token, align 32
  %4202 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4187
  %4203 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4187
  %4204 = load <8 x i1>, ptr %4202, align 1
  %4205 = load <8 x i1>, ptr %4203, align 1
  %4206 = select i1 %4180, <8 x i1> %701, <8 x i1> %4204
  store <8 x i1> %4206, ptr %4202, align 1
  %4207 = select i1 %4180, <8 x i1> zeroinitializer, <8 x i1> %4205
  store <8 x i1> %4207, ptr %4203, align 1
  %4208 = add i32 %4187, 1
  %4209 = select i1 %4178, i32 %4165, i32 %4208
  %4210 = select i1 true, i32 %4209, i32 %4165
  store i32 %4210, ptr %current.token, align 4
  %4211 = load i32, ptr %current.token, align 4
  %4212 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %708)
  %4213 = load i32, ptr %ready.count, align 4
  %4214 = icmp uge i32 %4213, 8
  %4215 = and i1 %4212, %4214
  br i1 %4215, label %ready.overflow.trap664, label %ready.overflow.resume665

ready.overflow.trap664:                           ; preds = %convergence.overflow.resume663
  call void @llvm.trap()
  unreachable

ready.overflow.resume665:                         ; preds = %convergence.overflow.resume663
  %4216 = select i1 %4212, i32 %4213, i32 0
  %4217 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4216
  %4218 = load <8 x i1>, ptr %4217, align 1
  %4219 = select i1 %4212, <8 x i1> %708, <8 x i1> %4218
  store <8 x i1> %4219, ptr %4217, align 1
  %4220 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4216
  %4221 = load i32, ptr %4220, align 4
  %4222 = select i1 %4212, i32 31, i32 %4221
  store i32 %4222, ptr %4220, align 4
  %4223 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4216
  %4224 = load i32, ptr %4223, align 4
  %4225 = select i1 %4212, i32 %4211, i32 %4224
  store i32 %4225, ptr %4223, align 4
  %4226 = add i32 %4213, 1
  %4227 = select i1 %4212, i32 %4226, i32 %4213
  store i32 %4227, ptr %ready.count, align 4
  %4228 = load <8 x i1>, ptr %runnable.mask, align 1
  %4229 = or <8 x i1> %4228, %708
  store <8 x i1> %4229, ptr %runnable.mask, align 1
  store <8 x i1> %710, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true666:                         ; preds = %varying.coherent661
  store <8 x i1> %701, ptr %current.mask, align 1
  %4230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %701)
  br i1 %4230, label %schedule.31, label %scheduler.loop

varying.coherent.false667:                        ; preds = %varying.coherent661
  store <8 x i1> %701, ptr %current.mask, align 1
  %4231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %701)
  br i1 %4231, label %schedule.32, label %scheduler.loop

convergence.cascade683:                           ; preds = %convergence.cascade683, %schedule.32
  %convergence.cascade.flow687 = phi <8 x i1> [ %795, %schedule.32 ], [ %4274, %convergence.cascade683 ]
  %convergence.cascade.depth688 = phi i32 [ 0, %schedule.32 ], [ %4275, %convergence.cascade683 ]
  %4232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow687)
  %4233 = load i32, ptr %current.token, align 4
  %4234 = icmp ne i32 %4233, 0
  %4235 = and i1 %4232, %4234
  %4236 = sub i32 %4233, 1
  %4237 = select i1 %4235, i32 %4236, i32 0
  %4238 = load i8, ptr %frame.active, align 1
  %4239 = trunc i32 %4237 to i8
  %4240 = shl i8 1, %4239
  %4241 = and i8 %4238, %4240
  %4242 = icmp ne i8 %4241, 0
  %4243 = load <8 x i32>, ptr %frame.static.id, align 32
  %4244 = extractelement <8 x i32> %4243, i32 %4237
  %convergence.target.pointer689 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4244
  %convergence.dynamic.target690 = load i32, ptr %convergence.target.pointer689, align 4
  %4245 = icmp eq i32 %convergence.dynamic.target690, 32
  %4246 = and i1 %4242, %4245
  %4247 = and i1 %4235, %4246
  %4248 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4237
  %4249 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4237
  %4250 = load <8 x i1>, ptr %4248, align 1
  %4251 = load <8 x i1>, ptr %4249, align 1
  %4252 = or <8 x i1> %4251, %convergence.cascade.flow687
  %4253 = load <8 x i1>, ptr %live.mask, align 1
  %4254 = and <8 x i1> %4250, %4253
  %4255 = icmp eq <8 x i1> %4252, %4254
  %4256 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4255)
  %4257 = and i1 %4247, %4256
  %4258 = select i1 %4257, <8 x i1> zeroinitializer, <8 x i1> %4252
  %4259 = select i1 %4247, <8 x i1> %4258, <8 x i1> %4251
  store <8 x i1> %4259, ptr %4249, align 1
  %4260 = select i1 %4257, <8 x i1> zeroinitializer, <8 x i1> %4250
  store <8 x i1> %4260, ptr %4248, align 1
  %4261 = trunc i32 %4237 to i8
  %4262 = shl i8 1, %4261
  %4263 = xor i8 %4262, -1
  %4264 = and i8 %4238, %4263
  %4265 = select i1 %4257, i8 %4264, i8 %4238
  store i8 %4265, ptr %frame.active, align 1
  %.splatinsert691 = insertelement <8 x i1> poison, i1 %4247, i64 0
  %.splat692 = shufflevector <8 x i1> %.splatinsert691, <8 x i1> poison, <8 x i32> zeroinitializer
  %4266 = and <8 x i1> %convergence.cascade.flow687, %.splat692
  %4267 = load <8 x i1>, ptr %runnable.mask, align 1
  %4268 = xor <8 x i1> %4266, splat (i1 true)
  %4269 = and <8 x i1> %4267, %4268
  store <8 x i1> %4269, ptr %runnable.mask, align 1
  %.splatinsert693 = insertelement <8 x i1> poison, i1 %4257, i64 0
  %.splat694 = shufflevector <8 x i1> %.splatinsert693, <8 x i1> poison, <8 x i32> zeroinitializer
  %4270 = select <8 x i1> %.splat694, <8 x i1> %4252, <8 x i1> zeroinitializer
  %4271 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4272 = extractelement <8 x i32> %4271, i32 %4237
  %4273 = select i1 %4257, i32 %4272, i32 %4233
  store i32 %4273, ptr %current.token, align 4
  %.splatinsert695 = insertelement <8 x i1> poison, i1 %4247, i64 0
  %.splat696 = shufflevector <8 x i1> %.splatinsert695, <8 x i1> poison, <8 x i32> zeroinitializer
  %4274 = select <8 x i1> %.splat696, <8 x i1> %4270, <8 x i1> %convergence.cascade.flow687
  %4275 = add i32 %convergence.cascade.depth688, 1
  %4276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4274)
  %4277 = icmp ult i32 %4275, 8
  %4278 = and i1 %4276, %4277
  %4279 = and i1 %4247, %4278
  %convergence.parent.token697 = load i32, ptr %current.token, align 4
  %convergence.parent.present698 = icmp ne i32 %convergence.parent.token697, 0
  %4280 = and i1 %4279, %convergence.parent.present698
  br i1 %4280, label %convergence.cascade683, label %convergence.cascade.exit684

convergence.cascade.exit684:                      ; preds = %convergence.cascade683, %schedule.32
  %convergence.cascade.result699 = phi <8 x i1> [ %795, %schedule.32 ], [ %4274, %convergence.cascade683 ]
  %4281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result699)
  br i1 %4281, label %convergence.target.32.ready, label %scheduler.loop

convergence.target.32.ready:                      ; preds = %convergence.cascade.exit684
  %4282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result699)
  %4283 = bitcast <8 x i1> %convergence.cascade.result699 to i8
  %4284 = call i8 @llvm.cttz.i8(i8 %4283, i1 false)
  %4285 = zext i8 %4284 to i32
  %4286 = select i1 %4282, i32 %4285, i32 0
  %4287 = load <8 x i64>, ptr %.slot56, align 64
  %4288 = select <8 x i1> %convergence.cascade.result699, <8 x i64> zeroinitializer, <8 x i64> %4287
  store <8 x i64> %4288, ptr %.slot56, align 64
  %4289 = load <8 x float>, ptr %.slot84, align 32
  %4290 = select <8 x i1> %convergence.cascade.result699, <8 x float> zeroinitializer, <8 x float> %4289
  store <8 x float> %4290, ptr %.slot84, align 32
  %4291 = load <8 x float>, ptr %.slot85, align 32
  %4292 = select <8 x i1> %convergence.cascade.result699, <8 x float> zeroinitializer, <8 x float> %4291
  store <8 x float> %4292, ptr %.slot85, align 32
  %4293 = load <8 x float>, ptr %.slot86, align 32
  %4294 = select <8 x i1> %convergence.cascade.result699, <8 x float> zeroinitializer, <8 x float> %4293
  store <8 x float> %4294, ptr %.slot86, align 32
  %4295 = load <8 x float>, ptr %.slot87, align 32
  %4296 = select <8 x i1> %convergence.cascade.result699, <8 x float> zeroinitializer, <8 x float> %4295
  store <8 x float> %4296, ptr %.slot87, align 32
  store <8 x i1> %convergence.cascade.result699, ptr %current.mask, align 1
  %4297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result699)
  br i1 %4297, label %schedule.33, label %scheduler.loop

varying.divergent701:                             ; preds = %schedule.33
  %4298 = load i32, ptr %current.token, align 4
  %4299 = icmp ne i32 %4298, 0
  %4300 = sub i32 %4298, 1
  %4301 = select i1 %4299, i32 %4300, i32 0
  %4302 = load i8, ptr %frame.active, align 1
  %4303 = trunc i32 %4301 to i8
  %4304 = shl i8 1, %4303
  %4305 = and i8 %4302, %4304
  %4306 = icmp ne i8 %4305, 0
  %4307 = load <8 x i32>, ptr %frame.static.id, align 32
  %4308 = extractelement <8 x i32> %4307, i32 %4301
  %4309 = icmp eq i32 %4308, 12
  %4310 = and i1 %4306, %4309
  %4311 = and i1 %4299, %4310
  %4312 = xor i1 %4311, true
  %4313 = and i1 true, %4312
  %4314 = xor i8 %4302, -1
  %4315 = icmp ne i8 %4314, 0
  %4316 = xor i1 %4315, true
  %4317 = and i1 %4313, %4316
  br i1 %4317, label %convergence.overflow.trap703, label %convergence.overflow.resume704

varying.coherent702:                              ; preds = %schedule.33
  br i1 %806, label %varying.coherent.true707, label %varying.coherent.false708

convergence.overflow.trap703:                     ; preds = %varying.divergent701
  call void @llvm.trap()
  unreachable

convergence.overflow.resume704:                   ; preds = %varying.divergent701
  %4318 = call i8 @llvm.cttz.i8(i8 %4314, i1 false)
  %4319 = zext i8 %4318 to i32
  %4320 = select i1 %4315, i32 %4319, i32 0
  %4321 = trunc i32 %4320 to i8
  %4322 = shl i8 1, %4321
  %4323 = or i8 %4302, %4322
  %4324 = select i1 %4313, i8 %4323, i8 %4302
  store i8 %4324, ptr %frame.active, align 1
  %4325 = load <8 x i32>, ptr %frame.static.id, align 32
  %4326 = extractelement <8 x i32> %4325, i32 %4320
  %4327 = select i1 %4313, i32 12, i32 %4326
  %4328 = load <8 x i32>, ptr %frame.static.id, align 32
  %4329 = insertelement <8 x i32> %4328, i32 %4327, i32 %4320
  store <8 x i32> %4329, ptr %frame.static.id, align 32
  %4330 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4331 = extractelement <8 x i32> %4330, i32 %4320
  %4332 = select i1 %4313, i32 %4298, i32 %4331
  %4333 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4334 = insertelement <8 x i32> %4333, i32 %4332, i32 %4320
  store <8 x i32> %4334, ptr %frame.parent.token, align 32
  %4335 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4320
  %4336 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4320
  %4337 = load <8 x i1>, ptr %4335, align 1
  %4338 = load <8 x i1>, ptr %4336, align 1
  %4339 = select i1 %4313, <8 x i1> %796, <8 x i1> %4337
  store <8 x i1> %4339, ptr %4335, align 1
  %4340 = select i1 %4313, <8 x i1> zeroinitializer, <8 x i1> %4338
  store <8 x i1> %4340, ptr %4336, align 1
  %4341 = add i32 %4320, 1
  %4342 = select i1 %4311, i32 %4298, i32 %4341
  %4343 = select i1 true, i32 %4342, i32 %4298
  store i32 %4343, ptr %current.token, align 4
  %4344 = load i32, ptr %current.token, align 4
  %4345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %803)
  %4346 = load i32, ptr %ready.count, align 4
  %4347 = icmp uge i32 %4346, 8
  %4348 = and i1 %4345, %4347
  br i1 %4348, label %ready.overflow.trap705, label %ready.overflow.resume706

ready.overflow.trap705:                           ; preds = %convergence.overflow.resume704
  call void @llvm.trap()
  unreachable

ready.overflow.resume706:                         ; preds = %convergence.overflow.resume704
  %4349 = select i1 %4345, i32 %4346, i32 0
  %4350 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4349
  %4351 = load <8 x i1>, ptr %4350, align 1
  %4352 = select i1 %4345, <8 x i1> %803, <8 x i1> %4351
  store <8 x i1> %4352, ptr %4350, align 1
  %4353 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4349
  %4354 = load i32, ptr %4353, align 4
  %4355 = select i1 %4345, i32 34, i32 %4354
  store i32 %4355, ptr %4353, align 4
  %4356 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4349
  %4357 = load i32, ptr %4356, align 4
  %4358 = select i1 %4345, i32 %4344, i32 %4357
  store i32 %4358, ptr %4356, align 4
  %4359 = add i32 %4346, 1
  %4360 = select i1 %4345, i32 %4359, i32 %4346
  store i32 %4360, ptr %ready.count, align 4
  %4361 = load <8 x i1>, ptr %runnable.mask, align 1
  %4362 = or <8 x i1> %4361, %803
  store <8 x i1> %4362, ptr %runnable.mask, align 1
  store <8 x i1> %805, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true707:                         ; preds = %varying.coherent702
  store <8 x i1> %796, ptr %current.mask, align 1
  %4363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %796)
  br i1 %4363, label %schedule.34, label %scheduler.loop

varying.coherent.false708:                        ; preds = %varying.coherent702
  store <8 x i1> %796, ptr %current.mask, align 1
  %4364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %796)
  br i1 %4364, label %schedule.35, label %scheduler.loop

convergence.cascade723:                           ; preds = %convergence.cascade723, %schedule.35
  %convergence.cascade.flow727 = phi <8 x i1> [ %889, %schedule.35 ], [ %4407, %convergence.cascade723 ]
  %convergence.cascade.depth728 = phi i32 [ 0, %schedule.35 ], [ %4408, %convergence.cascade723 ]
  %4365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow727)
  %4366 = load i32, ptr %current.token, align 4
  %4367 = icmp ne i32 %4366, 0
  %4368 = and i1 %4365, %4367
  %4369 = sub i32 %4366, 1
  %4370 = select i1 %4368, i32 %4369, i32 0
  %4371 = load i8, ptr %frame.active, align 1
  %4372 = trunc i32 %4370 to i8
  %4373 = shl i8 1, %4372
  %4374 = and i8 %4371, %4373
  %4375 = icmp ne i8 %4374, 0
  %4376 = load <8 x i32>, ptr %frame.static.id, align 32
  %4377 = extractelement <8 x i32> %4376, i32 %4370
  %convergence.target.pointer729 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4377
  %convergence.dynamic.target730 = load i32, ptr %convergence.target.pointer729, align 4
  %4378 = icmp eq i32 %convergence.dynamic.target730, 35
  %4379 = and i1 %4375, %4378
  %4380 = and i1 %4368, %4379
  %4381 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4370
  %4382 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4370
  %4383 = load <8 x i1>, ptr %4381, align 1
  %4384 = load <8 x i1>, ptr %4382, align 1
  %4385 = or <8 x i1> %4384, %convergence.cascade.flow727
  %4386 = load <8 x i1>, ptr %live.mask, align 1
  %4387 = and <8 x i1> %4383, %4386
  %4388 = icmp eq <8 x i1> %4385, %4387
  %4389 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4388)
  %4390 = and i1 %4380, %4389
  %4391 = select i1 %4390, <8 x i1> zeroinitializer, <8 x i1> %4385
  %4392 = select i1 %4380, <8 x i1> %4391, <8 x i1> %4384
  store <8 x i1> %4392, ptr %4382, align 1
  %4393 = select i1 %4390, <8 x i1> zeroinitializer, <8 x i1> %4383
  store <8 x i1> %4393, ptr %4381, align 1
  %4394 = trunc i32 %4370 to i8
  %4395 = shl i8 1, %4394
  %4396 = xor i8 %4395, -1
  %4397 = and i8 %4371, %4396
  %4398 = select i1 %4390, i8 %4397, i8 %4371
  store i8 %4398, ptr %frame.active, align 1
  %.splatinsert731 = insertelement <8 x i1> poison, i1 %4380, i64 0
  %.splat732 = shufflevector <8 x i1> %.splatinsert731, <8 x i1> poison, <8 x i32> zeroinitializer
  %4399 = and <8 x i1> %convergence.cascade.flow727, %.splat732
  %4400 = load <8 x i1>, ptr %runnable.mask, align 1
  %4401 = xor <8 x i1> %4399, splat (i1 true)
  %4402 = and <8 x i1> %4400, %4401
  store <8 x i1> %4402, ptr %runnable.mask, align 1
  %.splatinsert733 = insertelement <8 x i1> poison, i1 %4390, i64 0
  %.splat734 = shufflevector <8 x i1> %.splatinsert733, <8 x i1> poison, <8 x i32> zeroinitializer
  %4403 = select <8 x i1> %.splat734, <8 x i1> %4385, <8 x i1> zeroinitializer
  %4404 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4405 = extractelement <8 x i32> %4404, i32 %4370
  %4406 = select i1 %4390, i32 %4405, i32 %4366
  store i32 %4406, ptr %current.token, align 4
  %.splatinsert735 = insertelement <8 x i1> poison, i1 %4380, i64 0
  %.splat736 = shufflevector <8 x i1> %.splatinsert735, <8 x i1> poison, <8 x i32> zeroinitializer
  %4407 = select <8 x i1> %.splat736, <8 x i1> %4403, <8 x i1> %convergence.cascade.flow727
  %4408 = add i32 %convergence.cascade.depth728, 1
  %4409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4407)
  %4410 = icmp ult i32 %4408, 8
  %4411 = and i1 %4409, %4410
  %4412 = and i1 %4380, %4411
  %convergence.parent.token737 = load i32, ptr %current.token, align 4
  %convergence.parent.present738 = icmp ne i32 %convergence.parent.token737, 0
  %4413 = and i1 %4412, %convergence.parent.present738
  br i1 %4413, label %convergence.cascade723, label %convergence.cascade.exit724

convergence.cascade.exit724:                      ; preds = %convergence.cascade723, %schedule.35
  %convergence.cascade.result739 = phi <8 x i1> [ %889, %schedule.35 ], [ %4407, %convergence.cascade723 ]
  %4414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result739)
  br i1 %4414, label %convergence.target.35.ready, label %scheduler.loop

convergence.target.35.ready:                      ; preds = %convergence.cascade.exit724
  %4415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result739)
  %4416 = bitcast <8 x i1> %convergence.cascade.result739 to i8
  %4417 = call i8 @llvm.cttz.i8(i8 %4416, i1 false)
  %4418 = zext i8 %4417 to i32
  %4419 = select i1 %4415, i32 %4418, i32 0
  %4420 = load <8 x i64>, ptr %.slot56, align 64
  %4421 = select <8 x i1> %convergence.cascade.result739, <8 x i64> zeroinitializer, <8 x i64> %4420
  store <8 x i64> %4421, ptr %.slot56, align 64
  %4422 = load <8 x float>, ptr %.slot89, align 32
  %4423 = select <8 x i1> %convergence.cascade.result739, <8 x float> zeroinitializer, <8 x float> %4422
  store <8 x float> %4423, ptr %.slot89, align 32
  %4424 = load <8 x float>, ptr %.slot90, align 32
  %4425 = select <8 x i1> %convergence.cascade.result739, <8 x float> zeroinitializer, <8 x float> %4424
  store <8 x float> %4425, ptr %.slot90, align 32
  %4426 = load <8 x float>, ptr %.slot91, align 32
  %4427 = select <8 x i1> %convergence.cascade.result739, <8 x float> zeroinitializer, <8 x float> %4426
  store <8 x float> %4427, ptr %.slot91, align 32
  %4428 = load <8 x float>, ptr %.slot92, align 32
  %4429 = select <8 x i1> %convergence.cascade.result739, <8 x float> zeroinitializer, <8 x float> %4428
  store <8 x float> %4429, ptr %.slot92, align 32
  store <8 x i1> %convergence.cascade.result739, ptr %current.mask, align 1
  %4430 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result739)
  br i1 %4430, label %schedule.36, label %scheduler.loop

varying.divergent741:                             ; preds = %schedule.36
  %4431 = load i32, ptr %current.token, align 4
  %4432 = icmp ne i32 %4431, 0
  %4433 = sub i32 %4431, 1
  %4434 = select i1 %4432, i32 %4433, i32 0
  %4435 = load i8, ptr %frame.active, align 1
  %4436 = trunc i32 %4434 to i8
  %4437 = shl i8 1, %4436
  %4438 = and i8 %4435, %4437
  %4439 = icmp ne i8 %4438, 0
  %4440 = load <8 x i32>, ptr %frame.static.id, align 32
  %4441 = extractelement <8 x i32> %4440, i32 %4434
  %4442 = icmp eq i32 %4441, 13
  %4443 = and i1 %4439, %4442
  %4444 = and i1 %4432, %4443
  %4445 = xor i1 %4444, true
  %4446 = and i1 true, %4445
  %4447 = xor i8 %4435, -1
  %4448 = icmp ne i8 %4447, 0
  %4449 = xor i1 %4448, true
  %4450 = and i1 %4446, %4449
  br i1 %4450, label %convergence.overflow.trap743, label %convergence.overflow.resume744

varying.coherent742:                              ; preds = %schedule.36
  br i1 %900, label %varying.coherent.true747, label %varying.coherent.false748

convergence.overflow.trap743:                     ; preds = %varying.divergent741
  call void @llvm.trap()
  unreachable

convergence.overflow.resume744:                   ; preds = %varying.divergent741
  %4451 = call i8 @llvm.cttz.i8(i8 %4447, i1 false)
  %4452 = zext i8 %4451 to i32
  %4453 = select i1 %4448, i32 %4452, i32 0
  %4454 = trunc i32 %4453 to i8
  %4455 = shl i8 1, %4454
  %4456 = or i8 %4435, %4455
  %4457 = select i1 %4446, i8 %4456, i8 %4435
  store i8 %4457, ptr %frame.active, align 1
  %4458 = load <8 x i32>, ptr %frame.static.id, align 32
  %4459 = extractelement <8 x i32> %4458, i32 %4453
  %4460 = select i1 %4446, i32 13, i32 %4459
  %4461 = load <8 x i32>, ptr %frame.static.id, align 32
  %4462 = insertelement <8 x i32> %4461, i32 %4460, i32 %4453
  store <8 x i32> %4462, ptr %frame.static.id, align 32
  %4463 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4464 = extractelement <8 x i32> %4463, i32 %4453
  %4465 = select i1 %4446, i32 %4431, i32 %4464
  %4466 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4467 = insertelement <8 x i32> %4466, i32 %4465, i32 %4453
  store <8 x i32> %4467, ptr %frame.parent.token, align 32
  %4468 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4453
  %4469 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4453
  %4470 = load <8 x i1>, ptr %4468, align 1
  %4471 = load <8 x i1>, ptr %4469, align 1
  %4472 = select i1 %4446, <8 x i1> %890, <8 x i1> %4470
  store <8 x i1> %4472, ptr %4468, align 1
  %4473 = select i1 %4446, <8 x i1> zeroinitializer, <8 x i1> %4471
  store <8 x i1> %4473, ptr %4469, align 1
  %4474 = add i32 %4453, 1
  %4475 = select i1 %4444, i32 %4431, i32 %4474
  %4476 = select i1 true, i32 %4475, i32 %4431
  store i32 %4476, ptr %current.token, align 4
  %4477 = load i32, ptr %current.token, align 4
  %4478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %897)
  %4479 = load i32, ptr %ready.count, align 4
  %4480 = icmp uge i32 %4479, 8
  %4481 = and i1 %4478, %4480
  br i1 %4481, label %ready.overflow.trap745, label %ready.overflow.resume746

ready.overflow.trap745:                           ; preds = %convergence.overflow.resume744
  call void @llvm.trap()
  unreachable

ready.overflow.resume746:                         ; preds = %convergence.overflow.resume744
  %4482 = select i1 %4478, i32 %4479, i32 0
  %4483 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4482
  %4484 = load <8 x i1>, ptr %4483, align 1
  %4485 = select i1 %4478, <8 x i1> %897, <8 x i1> %4484
  store <8 x i1> %4485, ptr %4483, align 1
  %4486 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4482
  %4487 = load i32, ptr %4486, align 4
  %4488 = select i1 %4478, i32 37, i32 %4487
  store i32 %4488, ptr %4486, align 4
  %4489 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4482
  %4490 = load i32, ptr %4489, align 4
  %4491 = select i1 %4478, i32 %4477, i32 %4490
  store i32 %4491, ptr %4489, align 4
  %4492 = add i32 %4479, 1
  %4493 = select i1 %4478, i32 %4492, i32 %4479
  store i32 %4493, ptr %ready.count, align 4
  %4494 = load <8 x i1>, ptr %runnable.mask, align 1
  %4495 = or <8 x i1> %4494, %897
  store <8 x i1> %4495, ptr %runnable.mask, align 1
  store <8 x i1> %899, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true747:                         ; preds = %varying.coherent742
  store <8 x i1> %890, ptr %current.mask, align 1
  %4496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %890)
  br i1 %4496, label %schedule.37, label %scheduler.loop

varying.coherent.false748:                        ; preds = %varying.coherent742
  store <8 x i1> %890, ptr %current.mask, align 1
  %4497 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %890)
  br i1 %4497, label %schedule.38, label %scheduler.loop

convergence.cascade764:                           ; preds = %convergence.cascade764, %schedule.38
  %convergence.cascade.flow768 = phi <8 x i1> [ %984, %schedule.38 ], [ %4540, %convergence.cascade764 ]
  %convergence.cascade.depth769 = phi i32 [ 0, %schedule.38 ], [ %4541, %convergence.cascade764 ]
  %4498 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow768)
  %4499 = load i32, ptr %current.token, align 4
  %4500 = icmp ne i32 %4499, 0
  %4501 = and i1 %4498, %4500
  %4502 = sub i32 %4499, 1
  %4503 = select i1 %4501, i32 %4502, i32 0
  %4504 = load i8, ptr %frame.active, align 1
  %4505 = trunc i32 %4503 to i8
  %4506 = shl i8 1, %4505
  %4507 = and i8 %4504, %4506
  %4508 = icmp ne i8 %4507, 0
  %4509 = load <8 x i32>, ptr %frame.static.id, align 32
  %4510 = extractelement <8 x i32> %4509, i32 %4503
  %convergence.target.pointer770 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4510
  %convergence.dynamic.target771 = load i32, ptr %convergence.target.pointer770, align 4
  %4511 = icmp eq i32 %convergence.dynamic.target771, 38
  %4512 = and i1 %4508, %4511
  %4513 = and i1 %4501, %4512
  %4514 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4503
  %4515 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4503
  %4516 = load <8 x i1>, ptr %4514, align 1
  %4517 = load <8 x i1>, ptr %4515, align 1
  %4518 = or <8 x i1> %4517, %convergence.cascade.flow768
  %4519 = load <8 x i1>, ptr %live.mask, align 1
  %4520 = and <8 x i1> %4516, %4519
  %4521 = icmp eq <8 x i1> %4518, %4520
  %4522 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4521)
  %4523 = and i1 %4513, %4522
  %4524 = select i1 %4523, <8 x i1> zeroinitializer, <8 x i1> %4518
  %4525 = select i1 %4513, <8 x i1> %4524, <8 x i1> %4517
  store <8 x i1> %4525, ptr %4515, align 1
  %4526 = select i1 %4523, <8 x i1> zeroinitializer, <8 x i1> %4516
  store <8 x i1> %4526, ptr %4514, align 1
  %4527 = trunc i32 %4503 to i8
  %4528 = shl i8 1, %4527
  %4529 = xor i8 %4528, -1
  %4530 = and i8 %4504, %4529
  %4531 = select i1 %4523, i8 %4530, i8 %4504
  store i8 %4531, ptr %frame.active, align 1
  %.splatinsert772 = insertelement <8 x i1> poison, i1 %4513, i64 0
  %.splat773 = shufflevector <8 x i1> %.splatinsert772, <8 x i1> poison, <8 x i32> zeroinitializer
  %4532 = and <8 x i1> %convergence.cascade.flow768, %.splat773
  %4533 = load <8 x i1>, ptr %runnable.mask, align 1
  %4534 = xor <8 x i1> %4532, splat (i1 true)
  %4535 = and <8 x i1> %4533, %4534
  store <8 x i1> %4535, ptr %runnable.mask, align 1
  %.splatinsert774 = insertelement <8 x i1> poison, i1 %4523, i64 0
  %.splat775 = shufflevector <8 x i1> %.splatinsert774, <8 x i1> poison, <8 x i32> zeroinitializer
  %4536 = select <8 x i1> %.splat775, <8 x i1> %4518, <8 x i1> zeroinitializer
  %4537 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4538 = extractelement <8 x i32> %4537, i32 %4503
  %4539 = select i1 %4523, i32 %4538, i32 %4499
  store i32 %4539, ptr %current.token, align 4
  %.splatinsert776 = insertelement <8 x i1> poison, i1 %4513, i64 0
  %.splat777 = shufflevector <8 x i1> %.splatinsert776, <8 x i1> poison, <8 x i32> zeroinitializer
  %4540 = select <8 x i1> %.splat777, <8 x i1> %4536, <8 x i1> %convergence.cascade.flow768
  %4541 = add i32 %convergence.cascade.depth769, 1
  %4542 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4540)
  %4543 = icmp ult i32 %4541, 8
  %4544 = and i1 %4542, %4543
  %4545 = and i1 %4513, %4544
  %convergence.parent.token778 = load i32, ptr %current.token, align 4
  %convergence.parent.present779 = icmp ne i32 %convergence.parent.token778, 0
  %4546 = and i1 %4545, %convergence.parent.present779
  br i1 %4546, label %convergence.cascade764, label %convergence.cascade.exit765

convergence.cascade.exit765:                      ; preds = %convergence.cascade764, %schedule.38
  %convergence.cascade.result780 = phi <8 x i1> [ %984, %schedule.38 ], [ %4540, %convergence.cascade764 ]
  %4547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result780)
  br i1 %4547, label %convergence.target.38.ready, label %scheduler.loop

convergence.target.38.ready:                      ; preds = %convergence.cascade.exit765
  %4548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result780)
  %4549 = bitcast <8 x i1> %convergence.cascade.result780 to i8
  %4550 = call i8 @llvm.cttz.i8(i8 %4549, i1 false)
  %4551 = zext i8 %4550 to i32
  %4552 = select i1 %4548, i32 %4551, i32 0
  %4553 = load <8 x i64>, ptr %.slot56, align 64
  %4554 = select <8 x i1> %convergence.cascade.result780, <8 x i64> zeroinitializer, <8 x i64> %4553
  store <8 x i64> %4554, ptr %.slot56, align 64
  %4555 = load <8 x float>, ptr %.slot94, align 32
  %4556 = select <8 x i1> %convergence.cascade.result780, <8 x float> zeroinitializer, <8 x float> %4555
  store <8 x float> %4556, ptr %.slot94, align 32
  %4557 = load <8 x float>, ptr %.slot95, align 32
  %4558 = select <8 x i1> %convergence.cascade.result780, <8 x float> zeroinitializer, <8 x float> %4557
  store <8 x float> %4558, ptr %.slot95, align 32
  %4559 = load <8 x float>, ptr %.slot96, align 32
  %4560 = select <8 x i1> %convergence.cascade.result780, <8 x float> zeroinitializer, <8 x float> %4559
  store <8 x float> %4560, ptr %.slot96, align 32
  %4561 = load <8 x float>, ptr %.slot97, align 32
  %4562 = select <8 x i1> %convergence.cascade.result780, <8 x float> zeroinitializer, <8 x float> %4561
  store <8 x float> %4562, ptr %.slot97, align 32
  store <8 x i1> %convergence.cascade.result780, ptr %current.mask, align 1
  %4563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result780)
  br i1 %4563, label %schedule.39, label %scheduler.loop

varying.divergent782:                             ; preds = %schedule.39
  %4564 = load i32, ptr %current.token, align 4
  %4565 = icmp ne i32 %4564, 0
  %4566 = sub i32 %4564, 1
  %4567 = select i1 %4565, i32 %4566, i32 0
  %4568 = load i8, ptr %frame.active, align 1
  %4569 = trunc i32 %4567 to i8
  %4570 = shl i8 1, %4569
  %4571 = and i8 %4568, %4570
  %4572 = icmp ne i8 %4571, 0
  %4573 = load <8 x i32>, ptr %frame.static.id, align 32
  %4574 = extractelement <8 x i32> %4573, i32 %4567
  %4575 = icmp eq i32 %4574, 14
  %4576 = and i1 %4572, %4575
  %4577 = and i1 %4565, %4576
  %4578 = xor i1 %4577, true
  %4579 = and i1 true, %4578
  %4580 = xor i8 %4568, -1
  %4581 = icmp ne i8 %4580, 0
  %4582 = xor i1 %4581, true
  %4583 = and i1 %4579, %4582
  br i1 %4583, label %convergence.overflow.trap784, label %convergence.overflow.resume785

varying.coherent783:                              ; preds = %schedule.39
  br i1 %995, label %varying.coherent.true788, label %varying.coherent.false789

convergence.overflow.trap784:                     ; preds = %varying.divergent782
  call void @llvm.trap()
  unreachable

convergence.overflow.resume785:                   ; preds = %varying.divergent782
  %4584 = call i8 @llvm.cttz.i8(i8 %4580, i1 false)
  %4585 = zext i8 %4584 to i32
  %4586 = select i1 %4581, i32 %4585, i32 0
  %4587 = trunc i32 %4586 to i8
  %4588 = shl i8 1, %4587
  %4589 = or i8 %4568, %4588
  %4590 = select i1 %4579, i8 %4589, i8 %4568
  store i8 %4590, ptr %frame.active, align 1
  %4591 = load <8 x i32>, ptr %frame.static.id, align 32
  %4592 = extractelement <8 x i32> %4591, i32 %4586
  %4593 = select i1 %4579, i32 14, i32 %4592
  %4594 = load <8 x i32>, ptr %frame.static.id, align 32
  %4595 = insertelement <8 x i32> %4594, i32 %4593, i32 %4586
  store <8 x i32> %4595, ptr %frame.static.id, align 32
  %4596 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4597 = extractelement <8 x i32> %4596, i32 %4586
  %4598 = select i1 %4579, i32 %4564, i32 %4597
  %4599 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4600 = insertelement <8 x i32> %4599, i32 %4598, i32 %4586
  store <8 x i32> %4600, ptr %frame.parent.token, align 32
  %4601 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4586
  %4602 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4586
  %4603 = load <8 x i1>, ptr %4601, align 1
  %4604 = load <8 x i1>, ptr %4602, align 1
  %4605 = select i1 %4579, <8 x i1> %985, <8 x i1> %4603
  store <8 x i1> %4605, ptr %4601, align 1
  %4606 = select i1 %4579, <8 x i1> zeroinitializer, <8 x i1> %4604
  store <8 x i1> %4606, ptr %4602, align 1
  %4607 = add i32 %4586, 1
  %4608 = select i1 %4577, i32 %4564, i32 %4607
  %4609 = select i1 true, i32 %4608, i32 %4564
  store i32 %4609, ptr %current.token, align 4
  %4610 = load i32, ptr %current.token, align 4
  %4611 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %992)
  %4612 = load i32, ptr %ready.count, align 4
  %4613 = icmp uge i32 %4612, 8
  %4614 = and i1 %4611, %4613
  br i1 %4614, label %ready.overflow.trap786, label %ready.overflow.resume787

ready.overflow.trap786:                           ; preds = %convergence.overflow.resume785
  call void @llvm.trap()
  unreachable

ready.overflow.resume787:                         ; preds = %convergence.overflow.resume785
  %4615 = select i1 %4611, i32 %4612, i32 0
  %4616 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4615
  %4617 = load <8 x i1>, ptr %4616, align 1
  %4618 = select i1 %4611, <8 x i1> %992, <8 x i1> %4617
  store <8 x i1> %4618, ptr %4616, align 1
  %4619 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4615
  %4620 = load i32, ptr %4619, align 4
  %4621 = select i1 %4611, i32 40, i32 %4620
  store i32 %4621, ptr %4619, align 4
  %4622 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4615
  %4623 = load i32, ptr %4622, align 4
  %4624 = select i1 %4611, i32 %4610, i32 %4623
  store i32 %4624, ptr %4622, align 4
  %4625 = add i32 %4612, 1
  %4626 = select i1 %4611, i32 %4625, i32 %4612
  store i32 %4626, ptr %ready.count, align 4
  %4627 = load <8 x i1>, ptr %runnable.mask, align 1
  %4628 = or <8 x i1> %4627, %992
  store <8 x i1> %4628, ptr %runnable.mask, align 1
  store <8 x i1> %994, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true788:                         ; preds = %varying.coherent783
  store <8 x i1> %985, ptr %current.mask, align 1
  %4629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %985)
  br i1 %4629, label %schedule.40, label %scheduler.loop

varying.coherent.false789:                        ; preds = %varying.coherent783
  store <8 x i1> %985, ptr %current.mask, align 1
  %4630 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %985)
  br i1 %4630, label %schedule.41, label %scheduler.loop

convergence.cascade805:                           ; preds = %convergence.cascade805, %schedule.41
  %convergence.cascade.flow809 = phi <8 x i1> [ %1079, %schedule.41 ], [ %4673, %convergence.cascade805 ]
  %convergence.cascade.depth810 = phi i32 [ 0, %schedule.41 ], [ %4674, %convergence.cascade805 ]
  %4631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow809)
  %4632 = load i32, ptr %current.token, align 4
  %4633 = icmp ne i32 %4632, 0
  %4634 = and i1 %4631, %4633
  %4635 = sub i32 %4632, 1
  %4636 = select i1 %4634, i32 %4635, i32 0
  %4637 = load i8, ptr %frame.active, align 1
  %4638 = trunc i32 %4636 to i8
  %4639 = shl i8 1, %4638
  %4640 = and i8 %4637, %4639
  %4641 = icmp ne i8 %4640, 0
  %4642 = load <8 x i32>, ptr %frame.static.id, align 32
  %4643 = extractelement <8 x i32> %4642, i32 %4636
  %convergence.target.pointer811 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4643
  %convergence.dynamic.target812 = load i32, ptr %convergence.target.pointer811, align 4
  %4644 = icmp eq i32 %convergence.dynamic.target812, 41
  %4645 = and i1 %4641, %4644
  %4646 = and i1 %4634, %4645
  %4647 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4636
  %4648 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4636
  %4649 = load <8 x i1>, ptr %4647, align 1
  %4650 = load <8 x i1>, ptr %4648, align 1
  %4651 = or <8 x i1> %4650, %convergence.cascade.flow809
  %4652 = load <8 x i1>, ptr %live.mask, align 1
  %4653 = and <8 x i1> %4649, %4652
  %4654 = icmp eq <8 x i1> %4651, %4653
  %4655 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4654)
  %4656 = and i1 %4646, %4655
  %4657 = select i1 %4656, <8 x i1> zeroinitializer, <8 x i1> %4651
  %4658 = select i1 %4646, <8 x i1> %4657, <8 x i1> %4650
  store <8 x i1> %4658, ptr %4648, align 1
  %4659 = select i1 %4656, <8 x i1> zeroinitializer, <8 x i1> %4649
  store <8 x i1> %4659, ptr %4647, align 1
  %4660 = trunc i32 %4636 to i8
  %4661 = shl i8 1, %4660
  %4662 = xor i8 %4661, -1
  %4663 = and i8 %4637, %4662
  %4664 = select i1 %4656, i8 %4663, i8 %4637
  store i8 %4664, ptr %frame.active, align 1
  %.splatinsert813 = insertelement <8 x i1> poison, i1 %4646, i64 0
  %.splat814 = shufflevector <8 x i1> %.splatinsert813, <8 x i1> poison, <8 x i32> zeroinitializer
  %4665 = and <8 x i1> %convergence.cascade.flow809, %.splat814
  %4666 = load <8 x i1>, ptr %runnable.mask, align 1
  %4667 = xor <8 x i1> %4665, splat (i1 true)
  %4668 = and <8 x i1> %4666, %4667
  store <8 x i1> %4668, ptr %runnable.mask, align 1
  %.splatinsert815 = insertelement <8 x i1> poison, i1 %4656, i64 0
  %.splat816 = shufflevector <8 x i1> %.splatinsert815, <8 x i1> poison, <8 x i32> zeroinitializer
  %4669 = select <8 x i1> %.splat816, <8 x i1> %4651, <8 x i1> zeroinitializer
  %4670 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4671 = extractelement <8 x i32> %4670, i32 %4636
  %4672 = select i1 %4656, i32 %4671, i32 %4632
  store i32 %4672, ptr %current.token, align 4
  %.splatinsert817 = insertelement <8 x i1> poison, i1 %4646, i64 0
  %.splat818 = shufflevector <8 x i1> %.splatinsert817, <8 x i1> poison, <8 x i32> zeroinitializer
  %4673 = select <8 x i1> %.splat818, <8 x i1> %4669, <8 x i1> %convergence.cascade.flow809
  %4674 = add i32 %convergence.cascade.depth810, 1
  %4675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4673)
  %4676 = icmp ult i32 %4674, 8
  %4677 = and i1 %4675, %4676
  %4678 = and i1 %4646, %4677
  %convergence.parent.token819 = load i32, ptr %current.token, align 4
  %convergence.parent.present820 = icmp ne i32 %convergence.parent.token819, 0
  %4679 = and i1 %4678, %convergence.parent.present820
  br i1 %4679, label %convergence.cascade805, label %convergence.cascade.exit806

convergence.cascade.exit806:                      ; preds = %convergence.cascade805, %schedule.41
  %convergence.cascade.result821 = phi <8 x i1> [ %1079, %schedule.41 ], [ %4673, %convergence.cascade805 ]
  %4680 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  br i1 %4680, label %convergence.target.41.ready, label %scheduler.loop

convergence.target.41.ready:                      ; preds = %convergence.cascade.exit806
  %4681 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %4682 = bitcast <8 x i1> %convergence.cascade.result821 to i8
  %4683 = call i8 @llvm.cttz.i8(i8 %4682, i1 false)
  %4684 = zext i8 %4683 to i32
  %4685 = select i1 %4681, i32 %4684, i32 0
  %4686 = load <8 x i64>, ptr %.slot56, align 64
  %4687 = select <8 x i1> %convergence.cascade.result821, <8 x i64> zeroinitializer, <8 x i64> %4686
  store <8 x i64> %4687, ptr %.slot56, align 64
  %4688 = load <8 x float>, ptr %.slot99, align 32
  %4689 = select <8 x i1> %convergence.cascade.result821, <8 x float> zeroinitializer, <8 x float> %4688
  store <8 x float> %4689, ptr %.slot99, align 32
  %4690 = load <8 x float>, ptr %.slot100, align 32
  %4691 = select <8 x i1> %convergence.cascade.result821, <8 x float> zeroinitializer, <8 x float> %4690
  store <8 x float> %4691, ptr %.slot100, align 32
  %4692 = load <8 x float>, ptr %.slot101, align 32
  %4693 = select <8 x i1> %convergence.cascade.result821, <8 x float> zeroinitializer, <8 x float> %4692
  store <8 x float> %4693, ptr %.slot101, align 32
  %4694 = load <8 x float>, ptr %.slot102, align 32
  %4695 = select <8 x i1> %convergence.cascade.result821, <8 x float> zeroinitializer, <8 x float> %4694
  store <8 x float> %4695, ptr %.slot102, align 32
  store <8 x i1> %convergence.cascade.result821, ptr %current.mask, align 1
  %4696 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  br i1 %4696, label %schedule.42, label %scheduler.loop

varying.divergent823:                             ; preds = %schedule.42
  %4697 = load i32, ptr %current.token, align 4
  %4698 = icmp ne i32 %4697, 0
  %4699 = sub i32 %4697, 1
  %4700 = select i1 %4698, i32 %4699, i32 0
  %4701 = load i8, ptr %frame.active, align 1
  %4702 = trunc i32 %4700 to i8
  %4703 = shl i8 1, %4702
  %4704 = and i8 %4701, %4703
  %4705 = icmp ne i8 %4704, 0
  %4706 = load <8 x i32>, ptr %frame.static.id, align 32
  %4707 = extractelement <8 x i32> %4706, i32 %4700
  %4708 = icmp eq i32 %4707, 15
  %4709 = and i1 %4705, %4708
  %4710 = and i1 %4698, %4709
  %4711 = xor i1 %4710, true
  %4712 = and i1 true, %4711
  %4713 = xor i8 %4701, -1
  %4714 = icmp ne i8 %4713, 0
  %4715 = xor i1 %4714, true
  %4716 = and i1 %4712, %4715
  br i1 %4716, label %convergence.overflow.trap825, label %convergence.overflow.resume826

varying.coherent824:                              ; preds = %schedule.42
  br i1 %1090, label %varying.coherent.true829, label %varying.coherent.false830

convergence.overflow.trap825:                     ; preds = %varying.divergent823
  call void @llvm.trap()
  unreachable

convergence.overflow.resume826:                   ; preds = %varying.divergent823
  %4717 = call i8 @llvm.cttz.i8(i8 %4713, i1 false)
  %4718 = zext i8 %4717 to i32
  %4719 = select i1 %4714, i32 %4718, i32 0
  %4720 = trunc i32 %4719 to i8
  %4721 = shl i8 1, %4720
  %4722 = or i8 %4701, %4721
  %4723 = select i1 %4712, i8 %4722, i8 %4701
  store i8 %4723, ptr %frame.active, align 1
  %4724 = load <8 x i32>, ptr %frame.static.id, align 32
  %4725 = extractelement <8 x i32> %4724, i32 %4719
  %4726 = select i1 %4712, i32 15, i32 %4725
  %4727 = load <8 x i32>, ptr %frame.static.id, align 32
  %4728 = insertelement <8 x i32> %4727, i32 %4726, i32 %4719
  store <8 x i32> %4728, ptr %frame.static.id, align 32
  %4729 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4730 = extractelement <8 x i32> %4729, i32 %4719
  %4731 = select i1 %4712, i32 %4697, i32 %4730
  %4732 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4733 = insertelement <8 x i32> %4732, i32 %4731, i32 %4719
  store <8 x i32> %4733, ptr %frame.parent.token, align 32
  %4734 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4719
  %4735 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4719
  %4736 = load <8 x i1>, ptr %4734, align 1
  %4737 = load <8 x i1>, ptr %4735, align 1
  %4738 = select i1 %4712, <8 x i1> %1080, <8 x i1> %4736
  store <8 x i1> %4738, ptr %4734, align 1
  %4739 = select i1 %4712, <8 x i1> zeroinitializer, <8 x i1> %4737
  store <8 x i1> %4739, ptr %4735, align 1
  %4740 = add i32 %4719, 1
  %4741 = select i1 %4710, i32 %4697, i32 %4740
  %4742 = select i1 true, i32 %4741, i32 %4697
  store i32 %4742, ptr %current.token, align 4
  %4743 = load i32, ptr %current.token, align 4
  %4744 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1087)
  %4745 = load i32, ptr %ready.count, align 4
  %4746 = icmp uge i32 %4745, 8
  %4747 = and i1 %4744, %4746
  br i1 %4747, label %ready.overflow.trap827, label %ready.overflow.resume828

ready.overflow.trap827:                           ; preds = %convergence.overflow.resume826
  call void @llvm.trap()
  unreachable

ready.overflow.resume828:                         ; preds = %convergence.overflow.resume826
  %4748 = select i1 %4744, i32 %4745, i32 0
  %4749 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4748
  %4750 = load <8 x i1>, ptr %4749, align 1
  %4751 = select i1 %4744, <8 x i1> %1087, <8 x i1> %4750
  store <8 x i1> %4751, ptr %4749, align 1
  %4752 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4748
  %4753 = load i32, ptr %4752, align 4
  %4754 = select i1 %4744, i32 43, i32 %4753
  store i32 %4754, ptr %4752, align 4
  %4755 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4748
  %4756 = load i32, ptr %4755, align 4
  %4757 = select i1 %4744, i32 %4743, i32 %4756
  store i32 %4757, ptr %4755, align 4
  %4758 = add i32 %4745, 1
  %4759 = select i1 %4744, i32 %4758, i32 %4745
  store i32 %4759, ptr %ready.count, align 4
  %4760 = load <8 x i1>, ptr %runnable.mask, align 1
  %4761 = or <8 x i1> %4760, %1087
  store <8 x i1> %4761, ptr %runnable.mask, align 1
  store <8 x i1> %1089, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true829:                         ; preds = %varying.coherent824
  store <8 x i1> %1080, ptr %current.mask, align 1
  %4762 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1080)
  br i1 %4762, label %schedule.43, label %scheduler.loop

varying.coherent.false830:                        ; preds = %varying.coherent824
  store <8 x i1> %1080, ptr %current.mask, align 1
  %4763 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1080)
  br i1 %4763, label %schedule.44, label %scheduler.loop

convergence.cascade846:                           ; preds = %convergence.cascade846, %schedule.44
  %convergence.cascade.flow850 = phi <8 x i1> [ %1174, %schedule.44 ], [ %4806, %convergence.cascade846 ]
  %convergence.cascade.depth851 = phi i32 [ 0, %schedule.44 ], [ %4807, %convergence.cascade846 ]
  %4764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow850)
  %4765 = load i32, ptr %current.token, align 4
  %4766 = icmp ne i32 %4765, 0
  %4767 = and i1 %4764, %4766
  %4768 = sub i32 %4765, 1
  %4769 = select i1 %4767, i32 %4768, i32 0
  %4770 = load i8, ptr %frame.active, align 1
  %4771 = trunc i32 %4769 to i8
  %4772 = shl i8 1, %4771
  %4773 = and i8 %4770, %4772
  %4774 = icmp ne i8 %4773, 0
  %4775 = load <8 x i32>, ptr %frame.static.id, align 32
  %4776 = extractelement <8 x i32> %4775, i32 %4769
  %convergence.target.pointer852 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4776
  %convergence.dynamic.target853 = load i32, ptr %convergence.target.pointer852, align 4
  %4777 = icmp eq i32 %convergence.dynamic.target853, 44
  %4778 = and i1 %4774, %4777
  %4779 = and i1 %4767, %4778
  %4780 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4769
  %4781 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4769
  %4782 = load <8 x i1>, ptr %4780, align 1
  %4783 = load <8 x i1>, ptr %4781, align 1
  %4784 = or <8 x i1> %4783, %convergence.cascade.flow850
  %4785 = load <8 x i1>, ptr %live.mask, align 1
  %4786 = and <8 x i1> %4782, %4785
  %4787 = icmp eq <8 x i1> %4784, %4786
  %4788 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4787)
  %4789 = and i1 %4779, %4788
  %4790 = select i1 %4789, <8 x i1> zeroinitializer, <8 x i1> %4784
  %4791 = select i1 %4779, <8 x i1> %4790, <8 x i1> %4783
  store <8 x i1> %4791, ptr %4781, align 1
  %4792 = select i1 %4789, <8 x i1> zeroinitializer, <8 x i1> %4782
  store <8 x i1> %4792, ptr %4780, align 1
  %4793 = trunc i32 %4769 to i8
  %4794 = shl i8 1, %4793
  %4795 = xor i8 %4794, -1
  %4796 = and i8 %4770, %4795
  %4797 = select i1 %4789, i8 %4796, i8 %4770
  store i8 %4797, ptr %frame.active, align 1
  %.splatinsert854 = insertelement <8 x i1> poison, i1 %4779, i64 0
  %.splat855 = shufflevector <8 x i1> %.splatinsert854, <8 x i1> poison, <8 x i32> zeroinitializer
  %4798 = and <8 x i1> %convergence.cascade.flow850, %.splat855
  %4799 = load <8 x i1>, ptr %runnable.mask, align 1
  %4800 = xor <8 x i1> %4798, splat (i1 true)
  %4801 = and <8 x i1> %4799, %4800
  store <8 x i1> %4801, ptr %runnable.mask, align 1
  %.splatinsert856 = insertelement <8 x i1> poison, i1 %4789, i64 0
  %.splat857 = shufflevector <8 x i1> %.splatinsert856, <8 x i1> poison, <8 x i32> zeroinitializer
  %4802 = select <8 x i1> %.splat857, <8 x i1> %4784, <8 x i1> zeroinitializer
  %4803 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4804 = extractelement <8 x i32> %4803, i32 %4769
  %4805 = select i1 %4789, i32 %4804, i32 %4765
  store i32 %4805, ptr %current.token, align 4
  %.splatinsert858 = insertelement <8 x i1> poison, i1 %4779, i64 0
  %.splat859 = shufflevector <8 x i1> %.splatinsert858, <8 x i1> poison, <8 x i32> zeroinitializer
  %4806 = select <8 x i1> %.splat859, <8 x i1> %4802, <8 x i1> %convergence.cascade.flow850
  %4807 = add i32 %convergence.cascade.depth851, 1
  %4808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4806)
  %4809 = icmp ult i32 %4807, 8
  %4810 = and i1 %4808, %4809
  %4811 = and i1 %4779, %4810
  %convergence.parent.token860 = load i32, ptr %current.token, align 4
  %convergence.parent.present861 = icmp ne i32 %convergence.parent.token860, 0
  %4812 = and i1 %4811, %convergence.parent.present861
  br i1 %4812, label %convergence.cascade846, label %convergence.cascade.exit847

convergence.cascade.exit847:                      ; preds = %convergence.cascade846, %schedule.44
  %convergence.cascade.result862 = phi <8 x i1> [ %1174, %schedule.44 ], [ %4806, %convergence.cascade846 ]
  %4813 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result862)
  br i1 %4813, label %convergence.target.44.ready, label %scheduler.loop

convergence.target.44.ready:                      ; preds = %convergence.cascade.exit847
  %4814 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result862)
  %4815 = bitcast <8 x i1> %convergence.cascade.result862 to i8
  %4816 = call i8 @llvm.cttz.i8(i8 %4815, i1 false)
  %4817 = zext i8 %4816 to i32
  %4818 = select i1 %4814, i32 %4817, i32 0
  %4819 = load <8 x i64>, ptr %.slot56, align 64
  %4820 = select <8 x i1> %convergence.cascade.result862, <8 x i64> zeroinitializer, <8 x i64> %4819
  store <8 x i64> %4820, ptr %.slot56, align 64
  %4821 = load <8 x float>, ptr %.slot104, align 32
  %4822 = select <8 x i1> %convergence.cascade.result862, <8 x float> zeroinitializer, <8 x float> %4821
  store <8 x float> %4822, ptr %.slot104, align 32
  %4823 = load <8 x float>, ptr %.slot105, align 32
  %4824 = select <8 x i1> %convergence.cascade.result862, <8 x float> zeroinitializer, <8 x float> %4823
  store <8 x float> %4824, ptr %.slot105, align 32
  %4825 = load <8 x float>, ptr %.slot106, align 32
  %4826 = select <8 x i1> %convergence.cascade.result862, <8 x float> zeroinitializer, <8 x float> %4825
  store <8 x float> %4826, ptr %.slot106, align 32
  %4827 = load <8 x float>, ptr %.slot107, align 32
  %4828 = select <8 x i1> %convergence.cascade.result862, <8 x float> zeroinitializer, <8 x float> %4827
  store <8 x float> %4828, ptr %.slot107, align 32
  store <8 x i1> %convergence.cascade.result862, ptr %current.mask, align 1
  %4829 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result862)
  br i1 %4829, label %schedule.45, label %scheduler.loop

varying.divergent864:                             ; preds = %schedule.45
  %4830 = load i32, ptr %current.token, align 4
  %4831 = icmp ne i32 %4830, 0
  %4832 = sub i32 %4830, 1
  %4833 = select i1 %4831, i32 %4832, i32 0
  %4834 = load i8, ptr %frame.active, align 1
  %4835 = trunc i32 %4833 to i8
  %4836 = shl i8 1, %4835
  %4837 = and i8 %4834, %4836
  %4838 = icmp ne i8 %4837, 0
  %4839 = load <8 x i32>, ptr %frame.static.id, align 32
  %4840 = extractelement <8 x i32> %4839, i32 %4833
  %4841 = icmp eq i32 %4840, 16
  %4842 = and i1 %4838, %4841
  %4843 = and i1 %4831, %4842
  %4844 = xor i1 %4843, true
  %4845 = and i1 true, %4844
  %4846 = xor i8 %4834, -1
  %4847 = icmp ne i8 %4846, 0
  %4848 = xor i1 %4847, true
  %4849 = and i1 %4845, %4848
  br i1 %4849, label %convergence.overflow.trap866, label %convergence.overflow.resume867

varying.coherent865:                              ; preds = %schedule.45
  br i1 %1185, label %varying.coherent.true870, label %varying.coherent.false871

convergence.overflow.trap866:                     ; preds = %varying.divergent864
  call void @llvm.trap()
  unreachable

convergence.overflow.resume867:                   ; preds = %varying.divergent864
  %4850 = call i8 @llvm.cttz.i8(i8 %4846, i1 false)
  %4851 = zext i8 %4850 to i32
  %4852 = select i1 %4847, i32 %4851, i32 0
  %4853 = trunc i32 %4852 to i8
  %4854 = shl i8 1, %4853
  %4855 = or i8 %4834, %4854
  %4856 = select i1 %4845, i8 %4855, i8 %4834
  store i8 %4856, ptr %frame.active, align 1
  %4857 = load <8 x i32>, ptr %frame.static.id, align 32
  %4858 = extractelement <8 x i32> %4857, i32 %4852
  %4859 = select i1 %4845, i32 16, i32 %4858
  %4860 = load <8 x i32>, ptr %frame.static.id, align 32
  %4861 = insertelement <8 x i32> %4860, i32 %4859, i32 %4852
  store <8 x i32> %4861, ptr %frame.static.id, align 32
  %4862 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4863 = extractelement <8 x i32> %4862, i32 %4852
  %4864 = select i1 %4845, i32 %4830, i32 %4863
  %4865 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4866 = insertelement <8 x i32> %4865, i32 %4864, i32 %4852
  store <8 x i32> %4866, ptr %frame.parent.token, align 32
  %4867 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4852
  %4868 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4852
  %4869 = load <8 x i1>, ptr %4867, align 1
  %4870 = load <8 x i1>, ptr %4868, align 1
  %4871 = select i1 %4845, <8 x i1> %1175, <8 x i1> %4869
  store <8 x i1> %4871, ptr %4867, align 1
  %4872 = select i1 %4845, <8 x i1> zeroinitializer, <8 x i1> %4870
  store <8 x i1> %4872, ptr %4868, align 1
  %4873 = add i32 %4852, 1
  %4874 = select i1 %4843, i32 %4830, i32 %4873
  %4875 = select i1 true, i32 %4874, i32 %4830
  store i32 %4875, ptr %current.token, align 4
  %4876 = load i32, ptr %current.token, align 4
  %4877 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1182)
  %4878 = load i32, ptr %ready.count, align 4
  %4879 = icmp uge i32 %4878, 8
  %4880 = and i1 %4877, %4879
  br i1 %4880, label %ready.overflow.trap868, label %ready.overflow.resume869

ready.overflow.trap868:                           ; preds = %convergence.overflow.resume867
  call void @llvm.trap()
  unreachable

ready.overflow.resume869:                         ; preds = %convergence.overflow.resume867
  %4881 = select i1 %4877, i32 %4878, i32 0
  %4882 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4881
  %4883 = load <8 x i1>, ptr %4882, align 1
  %4884 = select i1 %4877, <8 x i1> %1182, <8 x i1> %4883
  store <8 x i1> %4884, ptr %4882, align 1
  %4885 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4881
  %4886 = load i32, ptr %4885, align 4
  %4887 = select i1 %4877, i32 46, i32 %4886
  store i32 %4887, ptr %4885, align 4
  %4888 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4881
  %4889 = load i32, ptr %4888, align 4
  %4890 = select i1 %4877, i32 %4876, i32 %4889
  store i32 %4890, ptr %4888, align 4
  %4891 = add i32 %4878, 1
  %4892 = select i1 %4877, i32 %4891, i32 %4878
  store i32 %4892, ptr %ready.count, align 4
  %4893 = load <8 x i1>, ptr %runnable.mask, align 1
  %4894 = or <8 x i1> %4893, %1182
  store <8 x i1> %4894, ptr %runnable.mask, align 1
  store <8 x i1> %1184, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true870:                         ; preds = %varying.coherent865
  store <8 x i1> %1175, ptr %current.mask, align 1
  %4895 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1175)
  br i1 %4895, label %schedule.46, label %scheduler.loop

varying.coherent.false871:                        ; preds = %varying.coherent865
  store <8 x i1> %1175, ptr %current.mask, align 1
  %4896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1175)
  br i1 %4896, label %schedule.47, label %scheduler.loop

convergence.cascade886:                           ; preds = %convergence.cascade886, %schedule.47
  %convergence.cascade.flow890 = phi <8 x i1> [ %1268, %schedule.47 ], [ %4939, %convergence.cascade886 ]
  %convergence.cascade.depth891 = phi i32 [ 0, %schedule.47 ], [ %4940, %convergence.cascade886 ]
  %4897 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow890)
  %4898 = load i32, ptr %current.token, align 4
  %4899 = icmp ne i32 %4898, 0
  %4900 = and i1 %4897, %4899
  %4901 = sub i32 %4898, 1
  %4902 = select i1 %4900, i32 %4901, i32 0
  %4903 = load i8, ptr %frame.active, align 1
  %4904 = trunc i32 %4902 to i8
  %4905 = shl i8 1, %4904
  %4906 = and i8 %4903, %4905
  %4907 = icmp ne i8 %4906, 0
  %4908 = load <8 x i32>, ptr %frame.static.id, align 32
  %4909 = extractelement <8 x i32> %4908, i32 %4902
  %convergence.target.pointer892 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4909
  %convergence.dynamic.target893 = load i32, ptr %convergence.target.pointer892, align 4
  %4910 = icmp eq i32 %convergence.dynamic.target893, 47
  %4911 = and i1 %4907, %4910
  %4912 = and i1 %4900, %4911
  %4913 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4902
  %4914 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4902
  %4915 = load <8 x i1>, ptr %4913, align 1
  %4916 = load <8 x i1>, ptr %4914, align 1
  %4917 = or <8 x i1> %4916, %convergence.cascade.flow890
  %4918 = load <8 x i1>, ptr %live.mask, align 1
  %4919 = and <8 x i1> %4915, %4918
  %4920 = icmp eq <8 x i1> %4917, %4919
  %4921 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4920)
  %4922 = and i1 %4912, %4921
  %4923 = select i1 %4922, <8 x i1> zeroinitializer, <8 x i1> %4917
  %4924 = select i1 %4912, <8 x i1> %4923, <8 x i1> %4916
  store <8 x i1> %4924, ptr %4914, align 1
  %4925 = select i1 %4922, <8 x i1> zeroinitializer, <8 x i1> %4915
  store <8 x i1> %4925, ptr %4913, align 1
  %4926 = trunc i32 %4902 to i8
  %4927 = shl i8 1, %4926
  %4928 = xor i8 %4927, -1
  %4929 = and i8 %4903, %4928
  %4930 = select i1 %4922, i8 %4929, i8 %4903
  store i8 %4930, ptr %frame.active, align 1
  %.splatinsert894 = insertelement <8 x i1> poison, i1 %4912, i64 0
  %.splat895 = shufflevector <8 x i1> %.splatinsert894, <8 x i1> poison, <8 x i32> zeroinitializer
  %4931 = and <8 x i1> %convergence.cascade.flow890, %.splat895
  %4932 = load <8 x i1>, ptr %runnable.mask, align 1
  %4933 = xor <8 x i1> %4931, splat (i1 true)
  %4934 = and <8 x i1> %4932, %4933
  store <8 x i1> %4934, ptr %runnable.mask, align 1
  %.splatinsert896 = insertelement <8 x i1> poison, i1 %4922, i64 0
  %.splat897 = shufflevector <8 x i1> %.splatinsert896, <8 x i1> poison, <8 x i32> zeroinitializer
  %4935 = select <8 x i1> %.splat897, <8 x i1> %4917, <8 x i1> zeroinitializer
  %4936 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4937 = extractelement <8 x i32> %4936, i32 %4902
  %4938 = select i1 %4922, i32 %4937, i32 %4898
  store i32 %4938, ptr %current.token, align 4
  %.splatinsert898 = insertelement <8 x i1> poison, i1 %4912, i64 0
  %.splat899 = shufflevector <8 x i1> %.splatinsert898, <8 x i1> poison, <8 x i32> zeroinitializer
  %4939 = select <8 x i1> %.splat899, <8 x i1> %4935, <8 x i1> %convergence.cascade.flow890
  %4940 = add i32 %convergence.cascade.depth891, 1
  %4941 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4939)
  %4942 = icmp ult i32 %4940, 8
  %4943 = and i1 %4941, %4942
  %4944 = and i1 %4912, %4943
  %convergence.parent.token900 = load i32, ptr %current.token, align 4
  %convergence.parent.present901 = icmp ne i32 %convergence.parent.token900, 0
  %4945 = and i1 %4944, %convergence.parent.present901
  br i1 %4945, label %convergence.cascade886, label %convergence.cascade.exit887

convergence.cascade.exit887:                      ; preds = %convergence.cascade886, %schedule.47
  %convergence.cascade.result902 = phi <8 x i1> [ %1268, %schedule.47 ], [ %4939, %convergence.cascade886 ]
  %4946 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result902)
  br i1 %4946, label %convergence.target.47.ready, label %scheduler.loop

convergence.target.47.ready:                      ; preds = %convergence.cascade.exit887
  %4947 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result902)
  %4948 = bitcast <8 x i1> %convergence.cascade.result902 to i8
  %4949 = call i8 @llvm.cttz.i8(i8 %4948, i1 false)
  %4950 = zext i8 %4949 to i32
  %4951 = select i1 %4947, i32 %4950, i32 0
  %4952 = load <8 x i64>, ptr %.slot56, align 64
  %4953 = select <8 x i1> %convergence.cascade.result902, <8 x i64> zeroinitializer, <8 x i64> %4952
  store <8 x i64> %4953, ptr %.slot56, align 64
  %4954 = load <8 x float>, ptr %.slot109, align 32
  %4955 = select <8 x i1> %convergence.cascade.result902, <8 x float> zeroinitializer, <8 x float> %4954
  store <8 x float> %4955, ptr %.slot109, align 32
  %4956 = load <8 x float>, ptr %.slot110, align 32
  %4957 = select <8 x i1> %convergence.cascade.result902, <8 x float> zeroinitializer, <8 x float> %4956
  store <8 x float> %4957, ptr %.slot110, align 32
  %4958 = load <8 x float>, ptr %.slot111, align 32
  %4959 = select <8 x i1> %convergence.cascade.result902, <8 x float> zeroinitializer, <8 x float> %4958
  store <8 x float> %4959, ptr %.slot111, align 32
  %4960 = load <8 x float>, ptr %.slot112, align 32
  %4961 = select <8 x i1> %convergence.cascade.result902, <8 x float> zeroinitializer, <8 x float> %4960
  store <8 x float> %4961, ptr %.slot112, align 32
  store <8 x i1> %convergence.cascade.result902, ptr %current.mask, align 1
  %4962 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result902)
  br i1 %4962, label %schedule.48, label %scheduler.loop

varying.divergent904:                             ; preds = %schedule.48
  %4963 = load i32, ptr %current.token, align 4
  %4964 = icmp ne i32 %4963, 0
  %4965 = sub i32 %4963, 1
  %4966 = select i1 %4964, i32 %4965, i32 0
  %4967 = load i8, ptr %frame.active, align 1
  %4968 = trunc i32 %4966 to i8
  %4969 = shl i8 1, %4968
  %4970 = and i8 %4967, %4969
  %4971 = icmp ne i8 %4970, 0
  %4972 = load <8 x i32>, ptr %frame.static.id, align 32
  %4973 = extractelement <8 x i32> %4972, i32 %4966
  %4974 = icmp eq i32 %4973, 17
  %4975 = and i1 %4971, %4974
  %4976 = and i1 %4964, %4975
  %4977 = xor i1 %4976, true
  %4978 = and i1 true, %4977
  %4979 = xor i8 %4967, -1
  %4980 = icmp ne i8 %4979, 0
  %4981 = xor i1 %4980, true
  %4982 = and i1 %4978, %4981
  br i1 %4982, label %convergence.overflow.trap906, label %convergence.overflow.resume907

varying.coherent905:                              ; preds = %schedule.48
  br i1 %1279, label %varying.coherent.true910, label %varying.coherent.false911

convergence.overflow.trap906:                     ; preds = %varying.divergent904
  call void @llvm.trap()
  unreachable

convergence.overflow.resume907:                   ; preds = %varying.divergent904
  %4983 = call i8 @llvm.cttz.i8(i8 %4979, i1 false)
  %4984 = zext i8 %4983 to i32
  %4985 = select i1 %4980, i32 %4984, i32 0
  %4986 = trunc i32 %4985 to i8
  %4987 = shl i8 1, %4986
  %4988 = or i8 %4967, %4987
  %4989 = select i1 %4978, i8 %4988, i8 %4967
  store i8 %4989, ptr %frame.active, align 1
  %4990 = load <8 x i32>, ptr %frame.static.id, align 32
  %4991 = extractelement <8 x i32> %4990, i32 %4985
  %4992 = select i1 %4978, i32 17, i32 %4991
  %4993 = load <8 x i32>, ptr %frame.static.id, align 32
  %4994 = insertelement <8 x i32> %4993, i32 %4992, i32 %4985
  store <8 x i32> %4994, ptr %frame.static.id, align 32
  %4995 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4996 = extractelement <8 x i32> %4995, i32 %4985
  %4997 = select i1 %4978, i32 %4963, i32 %4996
  %4998 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4999 = insertelement <8 x i32> %4998, i32 %4997, i32 %4985
  store <8 x i32> %4999, ptr %frame.parent.token, align 32
  %5000 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4985
  %5001 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4985
  %5002 = load <8 x i1>, ptr %5000, align 1
  %5003 = load <8 x i1>, ptr %5001, align 1
  %5004 = select i1 %4978, <8 x i1> %1269, <8 x i1> %5002
  store <8 x i1> %5004, ptr %5000, align 1
  %5005 = select i1 %4978, <8 x i1> zeroinitializer, <8 x i1> %5003
  store <8 x i1> %5005, ptr %5001, align 1
  %5006 = add i32 %4985, 1
  %5007 = select i1 %4976, i32 %4963, i32 %5006
  %5008 = select i1 true, i32 %5007, i32 %4963
  store i32 %5008, ptr %current.token, align 4
  %5009 = load i32, ptr %current.token, align 4
  %5010 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1276)
  %5011 = load i32, ptr %ready.count, align 4
  %5012 = icmp uge i32 %5011, 8
  %5013 = and i1 %5010, %5012
  br i1 %5013, label %ready.overflow.trap908, label %ready.overflow.resume909

ready.overflow.trap908:                           ; preds = %convergence.overflow.resume907
  call void @llvm.trap()
  unreachable

ready.overflow.resume909:                         ; preds = %convergence.overflow.resume907
  %5014 = select i1 %5010, i32 %5011, i32 0
  %5015 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5014
  %5016 = load <8 x i1>, ptr %5015, align 1
  %5017 = select i1 %5010, <8 x i1> %1276, <8 x i1> %5016
  store <8 x i1> %5017, ptr %5015, align 1
  %5018 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5014
  %5019 = load i32, ptr %5018, align 4
  %5020 = select i1 %5010, i32 49, i32 %5019
  store i32 %5020, ptr %5018, align 4
  %5021 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5014
  %5022 = load i32, ptr %5021, align 4
  %5023 = select i1 %5010, i32 %5009, i32 %5022
  store i32 %5023, ptr %5021, align 4
  %5024 = add i32 %5011, 1
  %5025 = select i1 %5010, i32 %5024, i32 %5011
  store i32 %5025, ptr %ready.count, align 4
  %5026 = load <8 x i1>, ptr %runnable.mask, align 1
  %5027 = or <8 x i1> %5026, %1276
  store <8 x i1> %5027, ptr %runnable.mask, align 1
  store <8 x i1> %1278, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true910:                         ; preds = %varying.coherent905
  store <8 x i1> %1269, ptr %current.mask, align 1
  %5028 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1269)
  br i1 %5028, label %schedule.49, label %scheduler.loop

varying.coherent.false911:                        ; preds = %varying.coherent905
  store <8 x i1> %1269, ptr %current.mask, align 1
  %5029 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1269)
  br i1 %5029, label %schedule.50, label %scheduler.loop

convergence.cascade927:                           ; preds = %convergence.cascade927, %schedule.50
  %convergence.cascade.flow931 = phi <8 x i1> [ %1363, %schedule.50 ], [ %5072, %convergence.cascade927 ]
  %convergence.cascade.depth932 = phi i32 [ 0, %schedule.50 ], [ %5073, %convergence.cascade927 ]
  %5030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow931)
  %5031 = load i32, ptr %current.token, align 4
  %5032 = icmp ne i32 %5031, 0
  %5033 = and i1 %5030, %5032
  %5034 = sub i32 %5031, 1
  %5035 = select i1 %5033, i32 %5034, i32 0
  %5036 = load i8, ptr %frame.active, align 1
  %5037 = trunc i32 %5035 to i8
  %5038 = shl i8 1, %5037
  %5039 = and i8 %5036, %5038
  %5040 = icmp ne i8 %5039, 0
  %5041 = load <8 x i32>, ptr %frame.static.id, align 32
  %5042 = extractelement <8 x i32> %5041, i32 %5035
  %convergence.target.pointer933 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %5042
  %convergence.dynamic.target934 = load i32, ptr %convergence.target.pointer933, align 4
  %5043 = icmp eq i32 %convergence.dynamic.target934, 50
  %5044 = and i1 %5040, %5043
  %5045 = and i1 %5033, %5044
  %5046 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5035
  %5047 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5035
  %5048 = load <8 x i1>, ptr %5046, align 1
  %5049 = load <8 x i1>, ptr %5047, align 1
  %5050 = or <8 x i1> %5049, %convergence.cascade.flow931
  %5051 = load <8 x i1>, ptr %live.mask, align 1
  %5052 = and <8 x i1> %5048, %5051
  %5053 = icmp eq <8 x i1> %5050, %5052
  %5054 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5053)
  %5055 = and i1 %5045, %5054
  %5056 = select i1 %5055, <8 x i1> zeroinitializer, <8 x i1> %5050
  %5057 = select i1 %5045, <8 x i1> %5056, <8 x i1> %5049
  store <8 x i1> %5057, ptr %5047, align 1
  %5058 = select i1 %5055, <8 x i1> zeroinitializer, <8 x i1> %5048
  store <8 x i1> %5058, ptr %5046, align 1
  %5059 = trunc i32 %5035 to i8
  %5060 = shl i8 1, %5059
  %5061 = xor i8 %5060, -1
  %5062 = and i8 %5036, %5061
  %5063 = select i1 %5055, i8 %5062, i8 %5036
  store i8 %5063, ptr %frame.active, align 1
  %.splatinsert935 = insertelement <8 x i1> poison, i1 %5045, i64 0
  %.splat936 = shufflevector <8 x i1> %.splatinsert935, <8 x i1> poison, <8 x i32> zeroinitializer
  %5064 = and <8 x i1> %convergence.cascade.flow931, %.splat936
  %5065 = load <8 x i1>, ptr %runnable.mask, align 1
  %5066 = xor <8 x i1> %5064, splat (i1 true)
  %5067 = and <8 x i1> %5065, %5066
  store <8 x i1> %5067, ptr %runnable.mask, align 1
  %.splatinsert937 = insertelement <8 x i1> poison, i1 %5055, i64 0
  %.splat938 = shufflevector <8 x i1> %.splatinsert937, <8 x i1> poison, <8 x i32> zeroinitializer
  %5068 = select <8 x i1> %.splat938, <8 x i1> %5050, <8 x i1> zeroinitializer
  %5069 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5070 = extractelement <8 x i32> %5069, i32 %5035
  %5071 = select i1 %5055, i32 %5070, i32 %5031
  store i32 %5071, ptr %current.token, align 4
  %.splatinsert939 = insertelement <8 x i1> poison, i1 %5045, i64 0
  %.splat940 = shufflevector <8 x i1> %.splatinsert939, <8 x i1> poison, <8 x i32> zeroinitializer
  %5072 = select <8 x i1> %.splat940, <8 x i1> %5068, <8 x i1> %convergence.cascade.flow931
  %5073 = add i32 %convergence.cascade.depth932, 1
  %5074 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5072)
  %5075 = icmp ult i32 %5073, 8
  %5076 = and i1 %5074, %5075
  %5077 = and i1 %5045, %5076
  %convergence.parent.token941 = load i32, ptr %current.token, align 4
  %convergence.parent.present942 = icmp ne i32 %convergence.parent.token941, 0
  %5078 = and i1 %5077, %convergence.parent.present942
  br i1 %5078, label %convergence.cascade927, label %convergence.cascade.exit928

convergence.cascade.exit928:                      ; preds = %convergence.cascade927, %schedule.50
  %convergence.cascade.result943 = phi <8 x i1> [ %1363, %schedule.50 ], [ %5072, %convergence.cascade927 ]
  %5079 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result943)
  br i1 %5079, label %convergence.target.50.ready, label %scheduler.loop

convergence.target.50.ready:                      ; preds = %convergence.cascade.exit928
  %5080 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result943)
  %5081 = bitcast <8 x i1> %convergence.cascade.result943 to i8
  %5082 = call i8 @llvm.cttz.i8(i8 %5081, i1 false)
  %5083 = zext i8 %5082 to i32
  %5084 = select i1 %5080, i32 %5083, i32 0
  %5085 = load <8 x i64>, ptr %.slot56, align 64
  %5086 = select <8 x i1> %convergence.cascade.result943, <8 x i64> zeroinitializer, <8 x i64> %5085
  store <8 x i64> %5086, ptr %.slot56, align 64
  %5087 = load <8 x float>, ptr %.slot114, align 32
  %5088 = select <8 x i1> %convergence.cascade.result943, <8 x float> zeroinitializer, <8 x float> %5087
  store <8 x float> %5088, ptr %.slot114, align 32
  %5089 = load <8 x float>, ptr %.slot115, align 32
  %5090 = select <8 x i1> %convergence.cascade.result943, <8 x float> zeroinitializer, <8 x float> %5089
  store <8 x float> %5090, ptr %.slot115, align 32
  %5091 = load <8 x float>, ptr %.slot116, align 32
  %5092 = select <8 x i1> %convergence.cascade.result943, <8 x float> zeroinitializer, <8 x float> %5091
  store <8 x float> %5092, ptr %.slot116, align 32
  %5093 = load <8 x float>, ptr %.slot117, align 32
  %5094 = select <8 x i1> %convergence.cascade.result943, <8 x float> zeroinitializer, <8 x float> %5093
  store <8 x float> %5094, ptr %.slot117, align 32
  store <8 x i1> %convergence.cascade.result943, ptr %current.mask, align 1
  %5095 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result943)
  br i1 %5095, label %schedule.51, label %scheduler.loop

varying.divergent945:                             ; preds = %schedule.51
  %5096 = load i32, ptr %current.token, align 4
  %5097 = icmp ne i32 %5096, 0
  %5098 = sub i32 %5096, 1
  %5099 = select i1 %5097, i32 %5098, i32 0
  %5100 = load i8, ptr %frame.active, align 1
  %5101 = trunc i32 %5099 to i8
  %5102 = shl i8 1, %5101
  %5103 = and i8 %5100, %5102
  %5104 = icmp ne i8 %5103, 0
  %5105 = load <8 x i32>, ptr %frame.static.id, align 32
  %5106 = extractelement <8 x i32> %5105, i32 %5099
  %5107 = icmp eq i32 %5106, 18
  %5108 = and i1 %5104, %5107
  %5109 = and i1 %5097, %5108
  %5110 = xor i1 %5109, true
  %5111 = and i1 true, %5110
  %5112 = xor i8 %5100, -1
  %5113 = icmp ne i8 %5112, 0
  %5114 = xor i1 %5113, true
  %5115 = and i1 %5111, %5114
  br i1 %5115, label %convergence.overflow.trap947, label %convergence.overflow.resume948

varying.coherent946:                              ; preds = %schedule.51
  br i1 %1374, label %varying.coherent.true951, label %varying.coherent.false952

convergence.overflow.trap947:                     ; preds = %varying.divergent945
  call void @llvm.trap()
  unreachable

convergence.overflow.resume948:                   ; preds = %varying.divergent945
  %5116 = call i8 @llvm.cttz.i8(i8 %5112, i1 false)
  %5117 = zext i8 %5116 to i32
  %5118 = select i1 %5113, i32 %5117, i32 0
  %5119 = trunc i32 %5118 to i8
  %5120 = shl i8 1, %5119
  %5121 = or i8 %5100, %5120
  %5122 = select i1 %5111, i8 %5121, i8 %5100
  store i8 %5122, ptr %frame.active, align 1
  %5123 = load <8 x i32>, ptr %frame.static.id, align 32
  %5124 = extractelement <8 x i32> %5123, i32 %5118
  %5125 = select i1 %5111, i32 18, i32 %5124
  %5126 = load <8 x i32>, ptr %frame.static.id, align 32
  %5127 = insertelement <8 x i32> %5126, i32 %5125, i32 %5118
  store <8 x i32> %5127, ptr %frame.static.id, align 32
  %5128 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5129 = extractelement <8 x i32> %5128, i32 %5118
  %5130 = select i1 %5111, i32 %5096, i32 %5129
  %5131 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5132 = insertelement <8 x i32> %5131, i32 %5130, i32 %5118
  store <8 x i32> %5132, ptr %frame.parent.token, align 32
  %5133 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5118
  %5134 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5118
  %5135 = load <8 x i1>, ptr %5133, align 1
  %5136 = load <8 x i1>, ptr %5134, align 1
  %5137 = select i1 %5111, <8 x i1> %1364, <8 x i1> %5135
  store <8 x i1> %5137, ptr %5133, align 1
  %5138 = select i1 %5111, <8 x i1> zeroinitializer, <8 x i1> %5136
  store <8 x i1> %5138, ptr %5134, align 1
  %5139 = add i32 %5118, 1
  %5140 = select i1 %5109, i32 %5096, i32 %5139
  %5141 = select i1 true, i32 %5140, i32 %5096
  store i32 %5141, ptr %current.token, align 4
  %5142 = load i32, ptr %current.token, align 4
  %5143 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1371)
  %5144 = load i32, ptr %ready.count, align 4
  %5145 = icmp uge i32 %5144, 8
  %5146 = and i1 %5143, %5145
  br i1 %5146, label %ready.overflow.trap949, label %ready.overflow.resume950

ready.overflow.trap949:                           ; preds = %convergence.overflow.resume948
  call void @llvm.trap()
  unreachable

ready.overflow.resume950:                         ; preds = %convergence.overflow.resume948
  %5147 = select i1 %5143, i32 %5144, i32 0
  %5148 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5147
  %5149 = load <8 x i1>, ptr %5148, align 1
  %5150 = select i1 %5143, <8 x i1> %1371, <8 x i1> %5149
  store <8 x i1> %5150, ptr %5148, align 1
  %5151 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5147
  %5152 = load i32, ptr %5151, align 4
  %5153 = select i1 %5143, i32 52, i32 %5152
  store i32 %5153, ptr %5151, align 4
  %5154 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5147
  %5155 = load i32, ptr %5154, align 4
  %5156 = select i1 %5143, i32 %5142, i32 %5155
  store i32 %5156, ptr %5154, align 4
  %5157 = add i32 %5144, 1
  %5158 = select i1 %5143, i32 %5157, i32 %5144
  store i32 %5158, ptr %ready.count, align 4
  %5159 = load <8 x i1>, ptr %runnable.mask, align 1
  %5160 = or <8 x i1> %5159, %1371
  store <8 x i1> %5160, ptr %runnable.mask, align 1
  store <8 x i1> %1373, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true951:                         ; preds = %varying.coherent946
  store <8 x i1> %1364, ptr %current.mask, align 1
  %5161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1364)
  br i1 %5161, label %schedule.52, label %scheduler.loop

varying.coherent.false952:                        ; preds = %varying.coherent946
  store <8 x i1> %1364, ptr %current.mask, align 1
  %5162 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1364)
  br i1 %5162, label %schedule.53, label %scheduler.loop

convergence.cascade968:                           ; preds = %convergence.cascade968, %schedule.53
  %convergence.cascade.flow972 = phi <8 x i1> [ %1458, %schedule.53 ], [ %5205, %convergence.cascade968 ]
  %convergence.cascade.depth973 = phi i32 [ 0, %schedule.53 ], [ %5206, %convergence.cascade968 ]
  %5163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow972)
  %5164 = load i32, ptr %current.token, align 4
  %5165 = icmp ne i32 %5164, 0
  %5166 = and i1 %5163, %5165
  %5167 = sub i32 %5164, 1
  %5168 = select i1 %5166, i32 %5167, i32 0
  %5169 = load i8, ptr %frame.active, align 1
  %5170 = trunc i32 %5168 to i8
  %5171 = shl i8 1, %5170
  %5172 = and i8 %5169, %5171
  %5173 = icmp ne i8 %5172, 0
  %5174 = load <8 x i32>, ptr %frame.static.id, align 32
  %5175 = extractelement <8 x i32> %5174, i32 %5168
  %convergence.target.pointer974 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %5175
  %convergence.dynamic.target975 = load i32, ptr %convergence.target.pointer974, align 4
  %5176 = icmp eq i32 %convergence.dynamic.target975, 53
  %5177 = and i1 %5173, %5176
  %5178 = and i1 %5166, %5177
  %5179 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5168
  %5180 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5168
  %5181 = load <8 x i1>, ptr %5179, align 1
  %5182 = load <8 x i1>, ptr %5180, align 1
  %5183 = or <8 x i1> %5182, %convergence.cascade.flow972
  %5184 = load <8 x i1>, ptr %live.mask, align 1
  %5185 = and <8 x i1> %5181, %5184
  %5186 = icmp eq <8 x i1> %5183, %5185
  %5187 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5186)
  %5188 = and i1 %5178, %5187
  %5189 = select i1 %5188, <8 x i1> zeroinitializer, <8 x i1> %5183
  %5190 = select i1 %5178, <8 x i1> %5189, <8 x i1> %5182
  store <8 x i1> %5190, ptr %5180, align 1
  %5191 = select i1 %5188, <8 x i1> zeroinitializer, <8 x i1> %5181
  store <8 x i1> %5191, ptr %5179, align 1
  %5192 = trunc i32 %5168 to i8
  %5193 = shl i8 1, %5192
  %5194 = xor i8 %5193, -1
  %5195 = and i8 %5169, %5194
  %5196 = select i1 %5188, i8 %5195, i8 %5169
  store i8 %5196, ptr %frame.active, align 1
  %.splatinsert976 = insertelement <8 x i1> poison, i1 %5178, i64 0
  %.splat977 = shufflevector <8 x i1> %.splatinsert976, <8 x i1> poison, <8 x i32> zeroinitializer
  %5197 = and <8 x i1> %convergence.cascade.flow972, %.splat977
  %5198 = load <8 x i1>, ptr %runnable.mask, align 1
  %5199 = xor <8 x i1> %5197, splat (i1 true)
  %5200 = and <8 x i1> %5198, %5199
  store <8 x i1> %5200, ptr %runnable.mask, align 1
  %.splatinsert978 = insertelement <8 x i1> poison, i1 %5188, i64 0
  %.splat979 = shufflevector <8 x i1> %.splatinsert978, <8 x i1> poison, <8 x i32> zeroinitializer
  %5201 = select <8 x i1> %.splat979, <8 x i1> %5183, <8 x i1> zeroinitializer
  %5202 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5203 = extractelement <8 x i32> %5202, i32 %5168
  %5204 = select i1 %5188, i32 %5203, i32 %5164
  store i32 %5204, ptr %current.token, align 4
  %.splatinsert980 = insertelement <8 x i1> poison, i1 %5178, i64 0
  %.splat981 = shufflevector <8 x i1> %.splatinsert980, <8 x i1> poison, <8 x i32> zeroinitializer
  %5205 = select <8 x i1> %.splat981, <8 x i1> %5201, <8 x i1> %convergence.cascade.flow972
  %5206 = add i32 %convergence.cascade.depth973, 1
  %5207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5205)
  %5208 = icmp ult i32 %5206, 8
  %5209 = and i1 %5207, %5208
  %5210 = and i1 %5178, %5209
  %convergence.parent.token982 = load i32, ptr %current.token, align 4
  %convergence.parent.present983 = icmp ne i32 %convergence.parent.token982, 0
  %5211 = and i1 %5210, %convergence.parent.present983
  br i1 %5211, label %convergence.cascade968, label %convergence.cascade.exit969

convergence.cascade.exit969:                      ; preds = %convergence.cascade968, %schedule.53
  %convergence.cascade.result984 = phi <8 x i1> [ %1458, %schedule.53 ], [ %5205, %convergence.cascade968 ]
  %5212 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result984)
  br i1 %5212, label %convergence.target.53.ready, label %scheduler.loop

convergence.target.53.ready:                      ; preds = %convergence.cascade.exit969
  %5213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result984)
  %5214 = bitcast <8 x i1> %convergence.cascade.result984 to i8
  %5215 = call i8 @llvm.cttz.i8(i8 %5214, i1 false)
  %5216 = zext i8 %5215 to i32
  %5217 = select i1 %5213, i32 %5216, i32 0
  %5218 = load <8 x i64>, ptr %.slot56, align 64
  %5219 = select <8 x i1> %convergence.cascade.result984, <8 x i64> zeroinitializer, <8 x i64> %5218
  store <8 x i64> %5219, ptr %.slot56, align 64
  %5220 = load <8 x float>, ptr %.slot119, align 32
  %5221 = select <8 x i1> %convergence.cascade.result984, <8 x float> zeroinitializer, <8 x float> %5220
  store <8 x float> %5221, ptr %.slot119, align 32
  %5222 = load <8 x float>, ptr %.slot120, align 32
  %5223 = select <8 x i1> %convergence.cascade.result984, <8 x float> zeroinitializer, <8 x float> %5222
  store <8 x float> %5223, ptr %.slot120, align 32
  %5224 = load <8 x float>, ptr %.slot121, align 32
  %5225 = select <8 x i1> %convergence.cascade.result984, <8 x float> zeroinitializer, <8 x float> %5224
  store <8 x float> %5225, ptr %.slot121, align 32
  %5226 = load <8 x float>, ptr %.slot122, align 32
  %5227 = select <8 x i1> %convergence.cascade.result984, <8 x float> zeroinitializer, <8 x float> %5226
  store <8 x float> %5227, ptr %.slot122, align 32
  store <8 x i1> %convergence.cascade.result984, ptr %current.mask, align 1
  %5228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result984)
  br i1 %5228, label %schedule.54, label %scheduler.loop

varying.divergent986:                             ; preds = %schedule.54
  %5229 = load i32, ptr %current.token, align 4
  %5230 = icmp ne i32 %5229, 0
  %5231 = sub i32 %5229, 1
  %5232 = select i1 %5230, i32 %5231, i32 0
  %5233 = load i8, ptr %frame.active, align 1
  %5234 = trunc i32 %5232 to i8
  %5235 = shl i8 1, %5234
  %5236 = and i8 %5233, %5235
  %5237 = icmp ne i8 %5236, 0
  %5238 = load <8 x i32>, ptr %frame.static.id, align 32
  %5239 = extractelement <8 x i32> %5238, i32 %5232
  %5240 = icmp eq i32 %5239, 19
  %5241 = and i1 %5237, %5240
  %5242 = and i1 %5230, %5241
  %5243 = xor i1 %5242, true
  %5244 = and i1 true, %5243
  %5245 = xor i8 %5233, -1
  %5246 = icmp ne i8 %5245, 0
  %5247 = xor i1 %5246, true
  %5248 = and i1 %5244, %5247
  br i1 %5248, label %convergence.overflow.trap988, label %convergence.overflow.resume989

varying.coherent987:                              ; preds = %schedule.54
  br i1 %1469, label %varying.coherent.true992, label %varying.coherent.false993

convergence.overflow.trap988:                     ; preds = %varying.divergent986
  call void @llvm.trap()
  unreachable

convergence.overflow.resume989:                   ; preds = %varying.divergent986
  %5249 = call i8 @llvm.cttz.i8(i8 %5245, i1 false)
  %5250 = zext i8 %5249 to i32
  %5251 = select i1 %5246, i32 %5250, i32 0
  %5252 = trunc i32 %5251 to i8
  %5253 = shl i8 1, %5252
  %5254 = or i8 %5233, %5253
  %5255 = select i1 %5244, i8 %5254, i8 %5233
  store i8 %5255, ptr %frame.active, align 1
  %5256 = load <8 x i32>, ptr %frame.static.id, align 32
  %5257 = extractelement <8 x i32> %5256, i32 %5251
  %5258 = select i1 %5244, i32 19, i32 %5257
  %5259 = load <8 x i32>, ptr %frame.static.id, align 32
  %5260 = insertelement <8 x i32> %5259, i32 %5258, i32 %5251
  store <8 x i32> %5260, ptr %frame.static.id, align 32
  %5261 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5262 = extractelement <8 x i32> %5261, i32 %5251
  %5263 = select i1 %5244, i32 %5229, i32 %5262
  %5264 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5265 = insertelement <8 x i32> %5264, i32 %5263, i32 %5251
  store <8 x i32> %5265, ptr %frame.parent.token, align 32
  %5266 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5251
  %5267 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5251
  %5268 = load <8 x i1>, ptr %5266, align 1
  %5269 = load <8 x i1>, ptr %5267, align 1
  %5270 = select i1 %5244, <8 x i1> %1459, <8 x i1> %5268
  store <8 x i1> %5270, ptr %5266, align 1
  %5271 = select i1 %5244, <8 x i1> zeroinitializer, <8 x i1> %5269
  store <8 x i1> %5271, ptr %5267, align 1
  %5272 = add i32 %5251, 1
  %5273 = select i1 %5242, i32 %5229, i32 %5272
  %5274 = select i1 true, i32 %5273, i32 %5229
  store i32 %5274, ptr %current.token, align 4
  %5275 = load i32, ptr %current.token, align 4
  %5276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1466)
  %5277 = load i32, ptr %ready.count, align 4
  %5278 = icmp uge i32 %5277, 8
  %5279 = and i1 %5276, %5278
  br i1 %5279, label %ready.overflow.trap990, label %ready.overflow.resume991

ready.overflow.trap990:                           ; preds = %convergence.overflow.resume989
  call void @llvm.trap()
  unreachable

ready.overflow.resume991:                         ; preds = %convergence.overflow.resume989
  %5280 = select i1 %5276, i32 %5277, i32 0
  %5281 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5280
  %5282 = load <8 x i1>, ptr %5281, align 1
  %5283 = select i1 %5276, <8 x i1> %1466, <8 x i1> %5282
  store <8 x i1> %5283, ptr %5281, align 1
  %5284 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5280
  %5285 = load i32, ptr %5284, align 4
  %5286 = select i1 %5276, i32 55, i32 %5285
  store i32 %5286, ptr %5284, align 4
  %5287 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5280
  %5288 = load i32, ptr %5287, align 4
  %5289 = select i1 %5276, i32 %5275, i32 %5288
  store i32 %5289, ptr %5287, align 4
  %5290 = add i32 %5277, 1
  %5291 = select i1 %5276, i32 %5290, i32 %5277
  store i32 %5291, ptr %ready.count, align 4
  %5292 = load <8 x i1>, ptr %runnable.mask, align 1
  %5293 = or <8 x i1> %5292, %1466
  store <8 x i1> %5293, ptr %runnable.mask, align 1
  store <8 x i1> %1468, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true992:                         ; preds = %varying.coherent987
  store <8 x i1> %1459, ptr %current.mask, align 1
  %5294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1459)
  br i1 %5294, label %schedule.55, label %scheduler.loop

varying.coherent.false993:                        ; preds = %varying.coherent987
  store <8 x i1> %1459, ptr %current.mask, align 1
  %5295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1459)
  br i1 %5295, label %schedule.56, label %scheduler.loop

convergence.cascade1009:                          ; preds = %convergence.cascade1009, %schedule.56
  %convergence.cascade.flow1013 = phi <8 x i1> [ %1553, %schedule.56 ], [ %5338, %convergence.cascade1009 ]
  %convergence.cascade.depth1014 = phi i32 [ 0, %schedule.56 ], [ %5339, %convergence.cascade1009 ]
  %5296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1013)
  %5297 = load i32, ptr %current.token, align 4
  %5298 = icmp ne i32 %5297, 0
  %5299 = and i1 %5296, %5298
  %5300 = sub i32 %5297, 1
  %5301 = select i1 %5299, i32 %5300, i32 0
  %5302 = load i8, ptr %frame.active, align 1
  %5303 = trunc i32 %5301 to i8
  %5304 = shl i8 1, %5303
  %5305 = and i8 %5302, %5304
  %5306 = icmp ne i8 %5305, 0
  %5307 = load <8 x i32>, ptr %frame.static.id, align 32
  %5308 = extractelement <8 x i32> %5307, i32 %5301
  %convergence.target.pointer1015 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %5308
  %convergence.dynamic.target1016 = load i32, ptr %convergence.target.pointer1015, align 4
  %5309 = icmp eq i32 %convergence.dynamic.target1016, 56
  %5310 = and i1 %5306, %5309
  %5311 = and i1 %5299, %5310
  %5312 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5301
  %5313 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5301
  %5314 = load <8 x i1>, ptr %5312, align 1
  %5315 = load <8 x i1>, ptr %5313, align 1
  %5316 = or <8 x i1> %5315, %convergence.cascade.flow1013
  %5317 = load <8 x i1>, ptr %live.mask, align 1
  %5318 = and <8 x i1> %5314, %5317
  %5319 = icmp eq <8 x i1> %5316, %5318
  %5320 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5319)
  %5321 = and i1 %5311, %5320
  %5322 = select i1 %5321, <8 x i1> zeroinitializer, <8 x i1> %5316
  %5323 = select i1 %5311, <8 x i1> %5322, <8 x i1> %5315
  store <8 x i1> %5323, ptr %5313, align 1
  %5324 = select i1 %5321, <8 x i1> zeroinitializer, <8 x i1> %5314
  store <8 x i1> %5324, ptr %5312, align 1
  %5325 = trunc i32 %5301 to i8
  %5326 = shl i8 1, %5325
  %5327 = xor i8 %5326, -1
  %5328 = and i8 %5302, %5327
  %5329 = select i1 %5321, i8 %5328, i8 %5302
  store i8 %5329, ptr %frame.active, align 1
  %.splatinsert1017 = insertelement <8 x i1> poison, i1 %5311, i64 0
  %.splat1018 = shufflevector <8 x i1> %.splatinsert1017, <8 x i1> poison, <8 x i32> zeroinitializer
  %5330 = and <8 x i1> %convergence.cascade.flow1013, %.splat1018
  %5331 = load <8 x i1>, ptr %runnable.mask, align 1
  %5332 = xor <8 x i1> %5330, splat (i1 true)
  %5333 = and <8 x i1> %5331, %5332
  store <8 x i1> %5333, ptr %runnable.mask, align 1
  %.splatinsert1019 = insertelement <8 x i1> poison, i1 %5321, i64 0
  %.splat1020 = shufflevector <8 x i1> %.splatinsert1019, <8 x i1> poison, <8 x i32> zeroinitializer
  %5334 = select <8 x i1> %.splat1020, <8 x i1> %5316, <8 x i1> zeroinitializer
  %5335 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5336 = extractelement <8 x i32> %5335, i32 %5301
  %5337 = select i1 %5321, i32 %5336, i32 %5297
  store i32 %5337, ptr %current.token, align 4
  %.splatinsert1021 = insertelement <8 x i1> poison, i1 %5311, i64 0
  %.splat1022 = shufflevector <8 x i1> %.splatinsert1021, <8 x i1> poison, <8 x i32> zeroinitializer
  %5338 = select <8 x i1> %.splat1022, <8 x i1> %5334, <8 x i1> %convergence.cascade.flow1013
  %5339 = add i32 %convergence.cascade.depth1014, 1
  %5340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5338)
  %5341 = icmp ult i32 %5339, 8
  %5342 = and i1 %5340, %5341
  %5343 = and i1 %5311, %5342
  %convergence.parent.token1023 = load i32, ptr %current.token, align 4
  %convergence.parent.present1024 = icmp ne i32 %convergence.parent.token1023, 0
  %5344 = and i1 %5343, %convergence.parent.present1024
  br i1 %5344, label %convergence.cascade1009, label %convergence.cascade.exit1010

convergence.cascade.exit1010:                     ; preds = %convergence.cascade1009, %schedule.56
  %convergence.cascade.result1025 = phi <8 x i1> [ %1553, %schedule.56 ], [ %5338, %convergence.cascade1009 ]
  %5345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1025)
  br i1 %5345, label %convergence.target.56.ready, label %scheduler.loop

convergence.target.56.ready:                      ; preds = %convergence.cascade.exit1010
  %5346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1025)
  %5347 = bitcast <8 x i1> %convergence.cascade.result1025 to i8
  %5348 = call i8 @llvm.cttz.i8(i8 %5347, i1 false)
  %5349 = zext i8 %5348 to i32
  %5350 = select i1 %5346, i32 %5349, i32 0
  %5351 = load <8 x i64>, ptr %.slot56, align 64
  %5352 = select <8 x i1> %convergence.cascade.result1025, <8 x i64> zeroinitializer, <8 x i64> %5351
  store <8 x i64> %5352, ptr %.slot56, align 64
  %5353 = load <8 x float>, ptr %.slot124, align 32
  %5354 = select <8 x i1> %convergence.cascade.result1025, <8 x float> zeroinitializer, <8 x float> %5353
  store <8 x float> %5354, ptr %.slot124, align 32
  %5355 = load <8 x float>, ptr %.slot125, align 32
  %5356 = select <8 x i1> %convergence.cascade.result1025, <8 x float> zeroinitializer, <8 x float> %5355
  store <8 x float> %5356, ptr %.slot125, align 32
  %5357 = load <8 x float>, ptr %.slot126, align 32
  %5358 = select <8 x i1> %convergence.cascade.result1025, <8 x float> zeroinitializer, <8 x float> %5357
  store <8 x float> %5358, ptr %.slot126, align 32
  %5359 = load <8 x float>, ptr %.slot127, align 32
  %5360 = select <8 x i1> %convergence.cascade.result1025, <8 x float> zeroinitializer, <8 x float> %5359
  store <8 x float> %5360, ptr %.slot127, align 32
  store <8 x i1> %convergence.cascade.result1025, ptr %current.mask, align 1
  %5361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1025)
  br i1 %5361, label %schedule.57, label %scheduler.loop

varying.divergent1027:                            ; preds = %schedule.57
  %5362 = load i32, ptr %current.token, align 4
  %5363 = icmp ne i32 %5362, 0
  %5364 = sub i32 %5362, 1
  %5365 = select i1 %5363, i32 %5364, i32 0
  %5366 = load i8, ptr %frame.active, align 1
  %5367 = trunc i32 %5365 to i8
  %5368 = shl i8 1, %5367
  %5369 = and i8 %5366, %5368
  %5370 = icmp ne i8 %5369, 0
  %5371 = load <8 x i32>, ptr %frame.static.id, align 32
  %5372 = extractelement <8 x i32> %5371, i32 %5365
  %5373 = icmp eq i32 %5372, 20
  %5374 = and i1 %5370, %5373
  %5375 = and i1 %5363, %5374
  %5376 = xor i1 %5375, true
  %5377 = and i1 true, %5376
  %5378 = xor i8 %5366, -1
  %5379 = icmp ne i8 %5378, 0
  %5380 = xor i1 %5379, true
  %5381 = and i1 %5377, %5380
  br i1 %5381, label %convergence.overflow.trap1029, label %convergence.overflow.resume1030

varying.coherent1028:                             ; preds = %schedule.57
  br i1 %1564, label %varying.coherent.true1033, label %varying.coherent.false1034

convergence.overflow.trap1029:                    ; preds = %varying.divergent1027
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1030:                  ; preds = %varying.divergent1027
  %5382 = call i8 @llvm.cttz.i8(i8 %5378, i1 false)
  %5383 = zext i8 %5382 to i32
  %5384 = select i1 %5379, i32 %5383, i32 0
  %5385 = trunc i32 %5384 to i8
  %5386 = shl i8 1, %5385
  %5387 = or i8 %5366, %5386
  %5388 = select i1 %5377, i8 %5387, i8 %5366
  store i8 %5388, ptr %frame.active, align 1
  %5389 = load <8 x i32>, ptr %frame.static.id, align 32
  %5390 = extractelement <8 x i32> %5389, i32 %5384
  %5391 = select i1 %5377, i32 20, i32 %5390
  %5392 = load <8 x i32>, ptr %frame.static.id, align 32
  %5393 = insertelement <8 x i32> %5392, i32 %5391, i32 %5384
  store <8 x i32> %5393, ptr %frame.static.id, align 32
  %5394 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5395 = extractelement <8 x i32> %5394, i32 %5384
  %5396 = select i1 %5377, i32 %5362, i32 %5395
  %5397 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5398 = insertelement <8 x i32> %5397, i32 %5396, i32 %5384
  store <8 x i32> %5398, ptr %frame.parent.token, align 32
  %5399 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5384
  %5400 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5384
  %5401 = load <8 x i1>, ptr %5399, align 1
  %5402 = load <8 x i1>, ptr %5400, align 1
  %5403 = select i1 %5377, <8 x i1> %1554, <8 x i1> %5401
  store <8 x i1> %5403, ptr %5399, align 1
  %5404 = select i1 %5377, <8 x i1> zeroinitializer, <8 x i1> %5402
  store <8 x i1> %5404, ptr %5400, align 1
  %5405 = add i32 %5384, 1
  %5406 = select i1 %5375, i32 %5362, i32 %5405
  %5407 = select i1 true, i32 %5406, i32 %5362
  store i32 %5407, ptr %current.token, align 4
  %5408 = load i32, ptr %current.token, align 4
  %5409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1561)
  %5410 = load i32, ptr %ready.count, align 4
  %5411 = icmp uge i32 %5410, 8
  %5412 = and i1 %5409, %5411
  br i1 %5412, label %ready.overflow.trap1031, label %ready.overflow.resume1032

ready.overflow.trap1031:                          ; preds = %convergence.overflow.resume1030
  call void @llvm.trap()
  unreachable

ready.overflow.resume1032:                        ; preds = %convergence.overflow.resume1030
  %5413 = select i1 %5409, i32 %5410, i32 0
  %5414 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5413
  %5415 = load <8 x i1>, ptr %5414, align 1
  %5416 = select i1 %5409, <8 x i1> %1561, <8 x i1> %5415
  store <8 x i1> %5416, ptr %5414, align 1
  %5417 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5413
  %5418 = load i32, ptr %5417, align 4
  %5419 = select i1 %5409, i32 58, i32 %5418
  store i32 %5419, ptr %5417, align 4
  %5420 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5413
  %5421 = load i32, ptr %5420, align 4
  %5422 = select i1 %5409, i32 %5408, i32 %5421
  store i32 %5422, ptr %5420, align 4
  %5423 = add i32 %5410, 1
  %5424 = select i1 %5409, i32 %5423, i32 %5410
  store i32 %5424, ptr %ready.count, align 4
  %5425 = load <8 x i1>, ptr %runnable.mask, align 1
  %5426 = or <8 x i1> %5425, %1561
  store <8 x i1> %5426, ptr %runnable.mask, align 1
  store <8 x i1> %1563, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1033:                        ; preds = %varying.coherent1028
  store <8 x i1> %1554, ptr %current.mask, align 1
  %5427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1554)
  br i1 %5427, label %schedule.58, label %scheduler.loop

varying.coherent.false1034:                       ; preds = %varying.coherent1028
  store <8 x i1> %1554, ptr %current.mask, align 1
  %5428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1554)
  br i1 %5428, label %schedule.59, label %scheduler.loop

convergence.cascade1049:                          ; preds = %convergence.cascade1049, %schedule.59
  %convergence.cascade.flow1053 = phi <8 x i1> [ %1647, %schedule.59 ], [ %5471, %convergence.cascade1049 ]
  %convergence.cascade.depth1054 = phi i32 [ 0, %schedule.59 ], [ %5472, %convergence.cascade1049 ]
  %5429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1053)
  %5430 = load i32, ptr %current.token, align 4
  %5431 = icmp ne i32 %5430, 0
  %5432 = and i1 %5429, %5431
  %5433 = sub i32 %5430, 1
  %5434 = select i1 %5432, i32 %5433, i32 0
  %5435 = load i8, ptr %frame.active, align 1
  %5436 = trunc i32 %5434 to i8
  %5437 = shl i8 1, %5436
  %5438 = and i8 %5435, %5437
  %5439 = icmp ne i8 %5438, 0
  %5440 = load <8 x i32>, ptr %frame.static.id, align 32
  %5441 = extractelement <8 x i32> %5440, i32 %5434
  %convergence.target.pointer1055 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %5441
  %convergence.dynamic.target1056 = load i32, ptr %convergence.target.pointer1055, align 4
  %5442 = icmp eq i32 %convergence.dynamic.target1056, 59
  %5443 = and i1 %5439, %5442
  %5444 = and i1 %5432, %5443
  %5445 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5434
  %5446 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5434
  %5447 = load <8 x i1>, ptr %5445, align 1
  %5448 = load <8 x i1>, ptr %5446, align 1
  %5449 = or <8 x i1> %5448, %convergence.cascade.flow1053
  %5450 = load <8 x i1>, ptr %live.mask, align 1
  %5451 = and <8 x i1> %5447, %5450
  %5452 = icmp eq <8 x i1> %5449, %5451
  %5453 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5452)
  %5454 = and i1 %5444, %5453
  %5455 = select i1 %5454, <8 x i1> zeroinitializer, <8 x i1> %5449
  %5456 = select i1 %5444, <8 x i1> %5455, <8 x i1> %5448
  store <8 x i1> %5456, ptr %5446, align 1
  %5457 = select i1 %5454, <8 x i1> zeroinitializer, <8 x i1> %5447
  store <8 x i1> %5457, ptr %5445, align 1
  %5458 = trunc i32 %5434 to i8
  %5459 = shl i8 1, %5458
  %5460 = xor i8 %5459, -1
  %5461 = and i8 %5435, %5460
  %5462 = select i1 %5454, i8 %5461, i8 %5435
  store i8 %5462, ptr %frame.active, align 1
  %.splatinsert1057 = insertelement <8 x i1> poison, i1 %5444, i64 0
  %.splat1058 = shufflevector <8 x i1> %.splatinsert1057, <8 x i1> poison, <8 x i32> zeroinitializer
  %5463 = and <8 x i1> %convergence.cascade.flow1053, %.splat1058
  %5464 = load <8 x i1>, ptr %runnable.mask, align 1
  %5465 = xor <8 x i1> %5463, splat (i1 true)
  %5466 = and <8 x i1> %5464, %5465
  store <8 x i1> %5466, ptr %runnable.mask, align 1
  %.splatinsert1059 = insertelement <8 x i1> poison, i1 %5454, i64 0
  %.splat1060 = shufflevector <8 x i1> %.splatinsert1059, <8 x i1> poison, <8 x i32> zeroinitializer
  %5467 = select <8 x i1> %.splat1060, <8 x i1> %5449, <8 x i1> zeroinitializer
  %5468 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5469 = extractelement <8 x i32> %5468, i32 %5434
  %5470 = select i1 %5454, i32 %5469, i32 %5430
  store i32 %5470, ptr %current.token, align 4
  %.splatinsert1061 = insertelement <8 x i1> poison, i1 %5444, i64 0
  %.splat1062 = shufflevector <8 x i1> %.splatinsert1061, <8 x i1> poison, <8 x i32> zeroinitializer
  %5471 = select <8 x i1> %.splat1062, <8 x i1> %5467, <8 x i1> %convergence.cascade.flow1053
  %5472 = add i32 %convergence.cascade.depth1054, 1
  %5473 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5471)
  %5474 = icmp ult i32 %5472, 8
  %5475 = and i1 %5473, %5474
  %5476 = and i1 %5444, %5475
  %convergence.parent.token1063 = load i32, ptr %current.token, align 4
  %convergence.parent.present1064 = icmp ne i32 %convergence.parent.token1063, 0
  %5477 = and i1 %5476, %convergence.parent.present1064
  br i1 %5477, label %convergence.cascade1049, label %convergence.cascade.exit1050

convergence.cascade.exit1050:                     ; preds = %convergence.cascade1049, %schedule.59
  %convergence.cascade.result1065 = phi <8 x i1> [ %1647, %schedule.59 ], [ %5471, %convergence.cascade1049 ]
  %5478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1065)
  br i1 %5478, label %convergence.target.59.ready, label %scheduler.loop

convergence.target.59.ready:                      ; preds = %convergence.cascade.exit1050
  %5479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1065)
  %5480 = bitcast <8 x i1> %convergence.cascade.result1065 to i8
  %5481 = call i8 @llvm.cttz.i8(i8 %5480, i1 false)
  %5482 = zext i8 %5481 to i32
  %5483 = select i1 %5479, i32 %5482, i32 0
  %5484 = load <8 x i64>, ptr %.slot56, align 64
  %5485 = select <8 x i1> %convergence.cascade.result1065, <8 x i64> zeroinitializer, <8 x i64> %5484
  store <8 x i64> %5485, ptr %.slot56, align 64
  %5486 = load <8 x float>, ptr %.slot129, align 32
  %5487 = select <8 x i1> %convergence.cascade.result1065, <8 x float> zeroinitializer, <8 x float> %5486
  store <8 x float> %5487, ptr %.slot129, align 32
  %5488 = load <8 x float>, ptr %.slot130, align 32
  %5489 = select <8 x i1> %convergence.cascade.result1065, <8 x float> zeroinitializer, <8 x float> %5488
  store <8 x float> %5489, ptr %.slot130, align 32
  %5490 = load <8 x float>, ptr %.slot131, align 32
  %5491 = select <8 x i1> %convergence.cascade.result1065, <8 x float> zeroinitializer, <8 x float> %5490
  store <8 x float> %5491, ptr %.slot131, align 32
  %5492 = load <8 x float>, ptr %.slot132, align 32
  %5493 = select <8 x i1> %convergence.cascade.result1065, <8 x float> zeroinitializer, <8 x float> %5492
  store <8 x float> %5493, ptr %.slot132, align 32
  store <8 x i1> %convergence.cascade.result1065, ptr %current.mask, align 1
  %5494 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1065)
  br i1 %5494, label %schedule.60, label %scheduler.loop

varying.divergent1067:                            ; preds = %schedule.60
  %5495 = load i32, ptr %current.token, align 4
  %5496 = icmp ne i32 %5495, 0
  %5497 = sub i32 %5495, 1
  %5498 = select i1 %5496, i32 %5497, i32 0
  %5499 = load i8, ptr %frame.active, align 1
  %5500 = trunc i32 %5498 to i8
  %5501 = shl i8 1, %5500
  %5502 = and i8 %5499, %5501
  %5503 = icmp ne i8 %5502, 0
  %5504 = load <8 x i32>, ptr %frame.static.id, align 32
  %5505 = extractelement <8 x i32> %5504, i32 %5498
  %5506 = icmp eq i32 %5505, 21
  %5507 = and i1 %5503, %5506
  %5508 = and i1 %5496, %5507
  %5509 = xor i1 %5508, true
  %5510 = and i1 true, %5509
  %5511 = xor i8 %5499, -1
  %5512 = icmp ne i8 %5511, 0
  %5513 = xor i1 %5512, true
  %5514 = and i1 %5510, %5513
  br i1 %5514, label %convergence.overflow.trap1069, label %convergence.overflow.resume1070

varying.coherent1068:                             ; preds = %schedule.60
  br i1 %1658, label %varying.coherent.true1073, label %varying.coherent.false1074

convergence.overflow.trap1069:                    ; preds = %varying.divergent1067
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1070:                  ; preds = %varying.divergent1067
  %5515 = call i8 @llvm.cttz.i8(i8 %5511, i1 false)
  %5516 = zext i8 %5515 to i32
  %5517 = select i1 %5512, i32 %5516, i32 0
  %5518 = trunc i32 %5517 to i8
  %5519 = shl i8 1, %5518
  %5520 = or i8 %5499, %5519
  %5521 = select i1 %5510, i8 %5520, i8 %5499
  store i8 %5521, ptr %frame.active, align 1
  %5522 = load <8 x i32>, ptr %frame.static.id, align 32
  %5523 = extractelement <8 x i32> %5522, i32 %5517
  %5524 = select i1 %5510, i32 21, i32 %5523
  %5525 = load <8 x i32>, ptr %frame.static.id, align 32
  %5526 = insertelement <8 x i32> %5525, i32 %5524, i32 %5517
  store <8 x i32> %5526, ptr %frame.static.id, align 32
  %5527 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5528 = extractelement <8 x i32> %5527, i32 %5517
  %5529 = select i1 %5510, i32 %5495, i32 %5528
  %5530 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5531 = insertelement <8 x i32> %5530, i32 %5529, i32 %5517
  store <8 x i32> %5531, ptr %frame.parent.token, align 32
  %5532 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5517
  %5533 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5517
  %5534 = load <8 x i1>, ptr %5532, align 1
  %5535 = load <8 x i1>, ptr %5533, align 1
  %5536 = select i1 %5510, <8 x i1> %1648, <8 x i1> %5534
  store <8 x i1> %5536, ptr %5532, align 1
  %5537 = select i1 %5510, <8 x i1> zeroinitializer, <8 x i1> %5535
  store <8 x i1> %5537, ptr %5533, align 1
  %5538 = add i32 %5517, 1
  %5539 = select i1 %5508, i32 %5495, i32 %5538
  %5540 = select i1 true, i32 %5539, i32 %5495
  store i32 %5540, ptr %current.token, align 4
  %5541 = load i32, ptr %current.token, align 4
  %5542 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1655)
  %5543 = load i32, ptr %ready.count, align 4
  %5544 = icmp uge i32 %5543, 8
  %5545 = and i1 %5542, %5544
  br i1 %5545, label %ready.overflow.trap1071, label %ready.overflow.resume1072

ready.overflow.trap1071:                          ; preds = %convergence.overflow.resume1070
  call void @llvm.trap()
  unreachable

ready.overflow.resume1072:                        ; preds = %convergence.overflow.resume1070
  %5546 = select i1 %5542, i32 %5543, i32 0
  %5547 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5546
  %5548 = load <8 x i1>, ptr %5547, align 1
  %5549 = select i1 %5542, <8 x i1> %1655, <8 x i1> %5548
  store <8 x i1> %5549, ptr %5547, align 1
  %5550 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5546
  %5551 = load i32, ptr %5550, align 4
  %5552 = select i1 %5542, i32 61, i32 %5551
  store i32 %5552, ptr %5550, align 4
  %5553 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5546
  %5554 = load i32, ptr %5553, align 4
  %5555 = select i1 %5542, i32 %5541, i32 %5554
  store i32 %5555, ptr %5553, align 4
  %5556 = add i32 %5543, 1
  %5557 = select i1 %5542, i32 %5556, i32 %5543
  store i32 %5557, ptr %ready.count, align 4
  %5558 = load <8 x i1>, ptr %runnable.mask, align 1
  %5559 = or <8 x i1> %5558, %1655
  store <8 x i1> %5559, ptr %runnable.mask, align 1
  store <8 x i1> %1657, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1073:                        ; preds = %varying.coherent1068
  store <8 x i1> %1648, ptr %current.mask, align 1
  %5560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1648)
  br i1 %5560, label %schedule.61, label %scheduler.loop

varying.coherent.false1074:                       ; preds = %varying.coherent1068
  store <8 x i1> %1648, ptr %current.mask, align 1
  %5561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1648)
  br i1 %5561, label %schedule.62, label %scheduler.loop

convergence.cascade1090:                          ; preds = %convergence.cascade1090, %schedule.62
  %convergence.cascade.flow1094 = phi <8 x i1> [ %1742, %schedule.62 ], [ %5604, %convergence.cascade1090 ]
  %convergence.cascade.depth1095 = phi i32 [ 0, %schedule.62 ], [ %5605, %convergence.cascade1090 ]
  %5562 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1094)
  %5563 = load i32, ptr %current.token, align 4
  %5564 = icmp ne i32 %5563, 0
  %5565 = and i1 %5562, %5564
  %5566 = sub i32 %5563, 1
  %5567 = select i1 %5565, i32 %5566, i32 0
  %5568 = load i8, ptr %frame.active, align 1
  %5569 = trunc i32 %5567 to i8
  %5570 = shl i8 1, %5569
  %5571 = and i8 %5568, %5570
  %5572 = icmp ne i8 %5571, 0
  %5573 = load <8 x i32>, ptr %frame.static.id, align 32
  %5574 = extractelement <8 x i32> %5573, i32 %5567
  %convergence.target.pointer1096 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %5574
  %convergence.dynamic.target1097 = load i32, ptr %convergence.target.pointer1096, align 4
  %5575 = icmp eq i32 %convergence.dynamic.target1097, 62
  %5576 = and i1 %5572, %5575
  %5577 = and i1 %5565, %5576
  %5578 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5567
  %5579 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5567
  %5580 = load <8 x i1>, ptr %5578, align 1
  %5581 = load <8 x i1>, ptr %5579, align 1
  %5582 = or <8 x i1> %5581, %convergence.cascade.flow1094
  %5583 = load <8 x i1>, ptr %live.mask, align 1
  %5584 = and <8 x i1> %5580, %5583
  %5585 = icmp eq <8 x i1> %5582, %5584
  %5586 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5585)
  %5587 = and i1 %5577, %5586
  %5588 = select i1 %5587, <8 x i1> zeroinitializer, <8 x i1> %5582
  %5589 = select i1 %5577, <8 x i1> %5588, <8 x i1> %5581
  store <8 x i1> %5589, ptr %5579, align 1
  %5590 = select i1 %5587, <8 x i1> zeroinitializer, <8 x i1> %5580
  store <8 x i1> %5590, ptr %5578, align 1
  %5591 = trunc i32 %5567 to i8
  %5592 = shl i8 1, %5591
  %5593 = xor i8 %5592, -1
  %5594 = and i8 %5568, %5593
  %5595 = select i1 %5587, i8 %5594, i8 %5568
  store i8 %5595, ptr %frame.active, align 1
  %.splatinsert1098 = insertelement <8 x i1> poison, i1 %5577, i64 0
  %.splat1099 = shufflevector <8 x i1> %.splatinsert1098, <8 x i1> poison, <8 x i32> zeroinitializer
  %5596 = and <8 x i1> %convergence.cascade.flow1094, %.splat1099
  %5597 = load <8 x i1>, ptr %runnable.mask, align 1
  %5598 = xor <8 x i1> %5596, splat (i1 true)
  %5599 = and <8 x i1> %5597, %5598
  store <8 x i1> %5599, ptr %runnable.mask, align 1
  %.splatinsert1100 = insertelement <8 x i1> poison, i1 %5587, i64 0
  %.splat1101 = shufflevector <8 x i1> %.splatinsert1100, <8 x i1> poison, <8 x i32> zeroinitializer
  %5600 = select <8 x i1> %.splat1101, <8 x i1> %5582, <8 x i1> zeroinitializer
  %5601 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5602 = extractelement <8 x i32> %5601, i32 %5567
  %5603 = select i1 %5587, i32 %5602, i32 %5563
  store i32 %5603, ptr %current.token, align 4
  %.splatinsert1102 = insertelement <8 x i1> poison, i1 %5577, i64 0
  %.splat1103 = shufflevector <8 x i1> %.splatinsert1102, <8 x i1> poison, <8 x i32> zeroinitializer
  %5604 = select <8 x i1> %.splat1103, <8 x i1> %5600, <8 x i1> %convergence.cascade.flow1094
  %5605 = add i32 %convergence.cascade.depth1095, 1
  %5606 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5604)
  %5607 = icmp ult i32 %5605, 8
  %5608 = and i1 %5606, %5607
  %5609 = and i1 %5577, %5608
  %convergence.parent.token1104 = load i32, ptr %current.token, align 4
  %convergence.parent.present1105 = icmp ne i32 %convergence.parent.token1104, 0
  %5610 = and i1 %5609, %convergence.parent.present1105
  br i1 %5610, label %convergence.cascade1090, label %convergence.cascade.exit1091

convergence.cascade.exit1091:                     ; preds = %convergence.cascade1090, %schedule.62
  %convergence.cascade.result1106 = phi <8 x i1> [ %1742, %schedule.62 ], [ %5604, %convergence.cascade1090 ]
  %5611 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1106)
  br i1 %5611, label %convergence.target.62.ready, label %scheduler.loop

convergence.target.62.ready:                      ; preds = %convergence.cascade.exit1091
  %5612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1106)
  %5613 = bitcast <8 x i1> %convergence.cascade.result1106 to i8
  %5614 = call i8 @llvm.cttz.i8(i8 %5613, i1 false)
  %5615 = zext i8 %5614 to i32
  %5616 = select i1 %5612, i32 %5615, i32 0
  %5617 = load <8 x i64>, ptr %.slot56, align 64
  %5618 = select <8 x i1> %convergence.cascade.result1106, <8 x i64> zeroinitializer, <8 x i64> %5617
  store <8 x i64> %5618, ptr %.slot56, align 64
  %5619 = load <8 x float>, ptr %.slot134, align 32
  %5620 = select <8 x i1> %convergence.cascade.result1106, <8 x float> zeroinitializer, <8 x float> %5619
  store <8 x float> %5620, ptr %.slot134, align 32
  %5621 = load <8 x float>, ptr %.slot135, align 32
  %5622 = select <8 x i1> %convergence.cascade.result1106, <8 x float> zeroinitializer, <8 x float> %5621
  store <8 x float> %5622, ptr %.slot135, align 32
  %5623 = load <8 x float>, ptr %.slot136, align 32
  %5624 = select <8 x i1> %convergence.cascade.result1106, <8 x float> zeroinitializer, <8 x float> %5623
  store <8 x float> %5624, ptr %.slot136, align 32
  %5625 = load <8 x float>, ptr %.slot137, align 32
  %5626 = select <8 x i1> %convergence.cascade.result1106, <8 x float> zeroinitializer, <8 x float> %5625
  store <8 x float> %5626, ptr %.slot137, align 32
  store <8 x i1> %convergence.cascade.result1106, ptr %current.mask, align 1
  %5627 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1106)
  br i1 %5627, label %schedule.63, label %scheduler.loop

varying.divergent1108:                            ; preds = %schedule.63
  %5628 = load i32, ptr %current.token, align 4
  %5629 = icmp ne i32 %5628, 0
  %5630 = sub i32 %5628, 1
  %5631 = select i1 %5629, i32 %5630, i32 0
  %5632 = load i8, ptr %frame.active, align 1
  %5633 = trunc i32 %5631 to i8
  %5634 = shl i8 1, %5633
  %5635 = and i8 %5632, %5634
  %5636 = icmp ne i8 %5635, 0
  %5637 = load <8 x i32>, ptr %frame.static.id, align 32
  %5638 = extractelement <8 x i32> %5637, i32 %5631
  %5639 = icmp eq i32 %5638, 22
  %5640 = and i1 %5636, %5639
  %5641 = and i1 %5629, %5640
  %5642 = xor i1 %5641, true
  %5643 = and i1 true, %5642
  %5644 = xor i8 %5632, -1
  %5645 = icmp ne i8 %5644, 0
  %5646 = xor i1 %5645, true
  %5647 = and i1 %5643, %5646
  br i1 %5647, label %convergence.overflow.trap1110, label %convergence.overflow.resume1111

varying.coherent1109:                             ; preds = %schedule.63
  br i1 %1753, label %varying.coherent.true1114, label %varying.coherent.false1115

convergence.overflow.trap1110:                    ; preds = %varying.divergent1108
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1111:                  ; preds = %varying.divergent1108
  %5648 = call i8 @llvm.cttz.i8(i8 %5644, i1 false)
  %5649 = zext i8 %5648 to i32
  %5650 = select i1 %5645, i32 %5649, i32 0
  %5651 = trunc i32 %5650 to i8
  %5652 = shl i8 1, %5651
  %5653 = or i8 %5632, %5652
  %5654 = select i1 %5643, i8 %5653, i8 %5632
  store i8 %5654, ptr %frame.active, align 1
  %5655 = load <8 x i32>, ptr %frame.static.id, align 32
  %5656 = extractelement <8 x i32> %5655, i32 %5650
  %5657 = select i1 %5643, i32 22, i32 %5656
  %5658 = load <8 x i32>, ptr %frame.static.id, align 32
  %5659 = insertelement <8 x i32> %5658, i32 %5657, i32 %5650
  store <8 x i32> %5659, ptr %frame.static.id, align 32
  %5660 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5661 = extractelement <8 x i32> %5660, i32 %5650
  %5662 = select i1 %5643, i32 %5628, i32 %5661
  %5663 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5664 = insertelement <8 x i32> %5663, i32 %5662, i32 %5650
  store <8 x i32> %5664, ptr %frame.parent.token, align 32
  %5665 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5650
  %5666 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5650
  %5667 = load <8 x i1>, ptr %5665, align 1
  %5668 = load <8 x i1>, ptr %5666, align 1
  %5669 = select i1 %5643, <8 x i1> %1743, <8 x i1> %5667
  store <8 x i1> %5669, ptr %5665, align 1
  %5670 = select i1 %5643, <8 x i1> zeroinitializer, <8 x i1> %5668
  store <8 x i1> %5670, ptr %5666, align 1
  %5671 = add i32 %5650, 1
  %5672 = select i1 %5641, i32 %5628, i32 %5671
  %5673 = select i1 true, i32 %5672, i32 %5628
  store i32 %5673, ptr %current.token, align 4
  %5674 = load i32, ptr %current.token, align 4
  %5675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1750)
  %5676 = load i32, ptr %ready.count, align 4
  %5677 = icmp uge i32 %5676, 8
  %5678 = and i1 %5675, %5677
  br i1 %5678, label %ready.overflow.trap1112, label %ready.overflow.resume1113

ready.overflow.trap1112:                          ; preds = %convergence.overflow.resume1111
  call void @llvm.trap()
  unreachable

ready.overflow.resume1113:                        ; preds = %convergence.overflow.resume1111
  %5679 = select i1 %5675, i32 %5676, i32 0
  %5680 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5679
  %5681 = load <8 x i1>, ptr %5680, align 1
  %5682 = select i1 %5675, <8 x i1> %1750, <8 x i1> %5681
  store <8 x i1> %5682, ptr %5680, align 1
  %5683 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5679
  %5684 = load i32, ptr %5683, align 4
  %5685 = select i1 %5675, i32 64, i32 %5684
  store i32 %5685, ptr %5683, align 4
  %5686 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5679
  %5687 = load i32, ptr %5686, align 4
  %5688 = select i1 %5675, i32 %5674, i32 %5687
  store i32 %5688, ptr %5686, align 4
  %5689 = add i32 %5676, 1
  %5690 = select i1 %5675, i32 %5689, i32 %5676
  store i32 %5690, ptr %ready.count, align 4
  %5691 = load <8 x i1>, ptr %runnable.mask, align 1
  %5692 = or <8 x i1> %5691, %1750
  store <8 x i1> %5692, ptr %runnable.mask, align 1
  store <8 x i1> %1752, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1114:                        ; preds = %varying.coherent1109
  store <8 x i1> %1743, ptr %current.mask, align 1
  %5693 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1743)
  br i1 %5693, label %schedule.64, label %scheduler.loop

varying.coherent.false1115:                       ; preds = %varying.coherent1109
  store <8 x i1> %1743, ptr %current.mask, align 1
  %5694 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1743)
  br i1 %5694, label %schedule.65, label %scheduler.loop

convergence.cascade1131:                          ; preds = %convergence.cascade1131, %schedule.65
  %convergence.cascade.flow1135 = phi <8 x i1> [ %1837, %schedule.65 ], [ %5737, %convergence.cascade1131 ]
  %convergence.cascade.depth1136 = phi i32 [ 0, %schedule.65 ], [ %5738, %convergence.cascade1131 ]
  %5695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1135)
  %5696 = load i32, ptr %current.token, align 4
  %5697 = icmp ne i32 %5696, 0
  %5698 = and i1 %5695, %5697
  %5699 = sub i32 %5696, 1
  %5700 = select i1 %5698, i32 %5699, i32 0
  %5701 = load i8, ptr %frame.active, align 1
  %5702 = trunc i32 %5700 to i8
  %5703 = shl i8 1, %5702
  %5704 = and i8 %5701, %5703
  %5705 = icmp ne i8 %5704, 0
  %5706 = load <8 x i32>, ptr %frame.static.id, align 32
  %5707 = extractelement <8 x i32> %5706, i32 %5700
  %convergence.target.pointer1137 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %5707
  %convergence.dynamic.target1138 = load i32, ptr %convergence.target.pointer1137, align 4
  %5708 = icmp eq i32 %convergence.dynamic.target1138, 65
  %5709 = and i1 %5705, %5708
  %5710 = and i1 %5698, %5709
  %5711 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5700
  %5712 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5700
  %5713 = load <8 x i1>, ptr %5711, align 1
  %5714 = load <8 x i1>, ptr %5712, align 1
  %5715 = or <8 x i1> %5714, %convergence.cascade.flow1135
  %5716 = load <8 x i1>, ptr %live.mask, align 1
  %5717 = and <8 x i1> %5713, %5716
  %5718 = icmp eq <8 x i1> %5715, %5717
  %5719 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5718)
  %5720 = and i1 %5710, %5719
  %5721 = select i1 %5720, <8 x i1> zeroinitializer, <8 x i1> %5715
  %5722 = select i1 %5710, <8 x i1> %5721, <8 x i1> %5714
  store <8 x i1> %5722, ptr %5712, align 1
  %5723 = select i1 %5720, <8 x i1> zeroinitializer, <8 x i1> %5713
  store <8 x i1> %5723, ptr %5711, align 1
  %5724 = trunc i32 %5700 to i8
  %5725 = shl i8 1, %5724
  %5726 = xor i8 %5725, -1
  %5727 = and i8 %5701, %5726
  %5728 = select i1 %5720, i8 %5727, i8 %5701
  store i8 %5728, ptr %frame.active, align 1
  %.splatinsert1139 = insertelement <8 x i1> poison, i1 %5710, i64 0
  %.splat1140 = shufflevector <8 x i1> %.splatinsert1139, <8 x i1> poison, <8 x i32> zeroinitializer
  %5729 = and <8 x i1> %convergence.cascade.flow1135, %.splat1140
  %5730 = load <8 x i1>, ptr %runnable.mask, align 1
  %5731 = xor <8 x i1> %5729, splat (i1 true)
  %5732 = and <8 x i1> %5730, %5731
  store <8 x i1> %5732, ptr %runnable.mask, align 1
  %.splatinsert1141 = insertelement <8 x i1> poison, i1 %5720, i64 0
  %.splat1142 = shufflevector <8 x i1> %.splatinsert1141, <8 x i1> poison, <8 x i32> zeroinitializer
  %5733 = select <8 x i1> %.splat1142, <8 x i1> %5715, <8 x i1> zeroinitializer
  %5734 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5735 = extractelement <8 x i32> %5734, i32 %5700
  %5736 = select i1 %5720, i32 %5735, i32 %5696
  store i32 %5736, ptr %current.token, align 4
  %.splatinsert1143 = insertelement <8 x i1> poison, i1 %5710, i64 0
  %.splat1144 = shufflevector <8 x i1> %.splatinsert1143, <8 x i1> poison, <8 x i32> zeroinitializer
  %5737 = select <8 x i1> %.splat1144, <8 x i1> %5733, <8 x i1> %convergence.cascade.flow1135
  %5738 = add i32 %convergence.cascade.depth1136, 1
  %5739 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5737)
  %5740 = icmp ult i32 %5738, 8
  %5741 = and i1 %5739, %5740
  %5742 = and i1 %5710, %5741
  %convergence.parent.token1145 = load i32, ptr %current.token, align 4
  %convergence.parent.present1146 = icmp ne i32 %convergence.parent.token1145, 0
  %5743 = and i1 %5742, %convergence.parent.present1146
  br i1 %5743, label %convergence.cascade1131, label %convergence.cascade.exit1132

convergence.cascade.exit1132:                     ; preds = %convergence.cascade1131, %schedule.65
  %convergence.cascade.result1147 = phi <8 x i1> [ %1837, %schedule.65 ], [ %5737, %convergence.cascade1131 ]
  %5744 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1147)
  br i1 %5744, label %convergence.target.65.ready, label %scheduler.loop

convergence.target.65.ready:                      ; preds = %convergence.cascade.exit1132
  %5745 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1147)
  %5746 = bitcast <8 x i1> %convergence.cascade.result1147 to i8
  %5747 = call i8 @llvm.cttz.i8(i8 %5746, i1 false)
  %5748 = zext i8 %5747 to i32
  %5749 = select i1 %5745, i32 %5748, i32 0
  %5750 = load <8 x i64>, ptr %.slot56, align 64
  %5751 = select <8 x i1> %convergence.cascade.result1147, <8 x i64> zeroinitializer, <8 x i64> %5750
  store <8 x i64> %5751, ptr %.slot56, align 64
  %5752 = load <8 x float>, ptr %.slot139, align 32
  %5753 = select <8 x i1> %convergence.cascade.result1147, <8 x float> zeroinitializer, <8 x float> %5752
  store <8 x float> %5753, ptr %.slot139, align 32
  %5754 = load <8 x float>, ptr %.slot140, align 32
  %5755 = select <8 x i1> %convergence.cascade.result1147, <8 x float> zeroinitializer, <8 x float> %5754
  store <8 x float> %5755, ptr %.slot140, align 32
  %5756 = load <8 x float>, ptr %.slot141, align 32
  %5757 = select <8 x i1> %convergence.cascade.result1147, <8 x float> zeroinitializer, <8 x float> %5756
  store <8 x float> %5757, ptr %.slot141, align 32
  %5758 = load <8 x float>, ptr %.slot142, align 32
  %5759 = select <8 x i1> %convergence.cascade.result1147, <8 x float> zeroinitializer, <8 x float> %5758
  store <8 x float> %5759, ptr %.slot142, align 32
  store <8 x i1> %convergence.cascade.result1147, ptr %current.mask, align 1
  %5760 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1147)
  br i1 %5760, label %schedule.66, label %scheduler.loop

varying.divergent1149:                            ; preds = %schedule.66
  %5761 = load i32, ptr %current.token, align 4
  %5762 = icmp ne i32 %5761, 0
  %5763 = sub i32 %5761, 1
  %5764 = select i1 %5762, i32 %5763, i32 0
  %5765 = load i8, ptr %frame.active, align 1
  %5766 = trunc i32 %5764 to i8
  %5767 = shl i8 1, %5766
  %5768 = and i8 %5765, %5767
  %5769 = icmp ne i8 %5768, 0
  %5770 = load <8 x i32>, ptr %frame.static.id, align 32
  %5771 = extractelement <8 x i32> %5770, i32 %5764
  %5772 = icmp eq i32 %5771, 23
  %5773 = and i1 %5769, %5772
  %5774 = and i1 %5762, %5773
  %5775 = xor i1 %5774, true
  %5776 = and i1 true, %5775
  %5777 = xor i8 %5765, -1
  %5778 = icmp ne i8 %5777, 0
  %5779 = xor i1 %5778, true
  %5780 = and i1 %5776, %5779
  br i1 %5780, label %convergence.overflow.trap1151, label %convergence.overflow.resume1152

varying.coherent1150:                             ; preds = %schedule.66
  br i1 %1848, label %varying.coherent.true1155, label %varying.coherent.false1156

convergence.overflow.trap1151:                    ; preds = %varying.divergent1149
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1152:                  ; preds = %varying.divergent1149
  %5781 = call i8 @llvm.cttz.i8(i8 %5777, i1 false)
  %5782 = zext i8 %5781 to i32
  %5783 = select i1 %5778, i32 %5782, i32 0
  %5784 = trunc i32 %5783 to i8
  %5785 = shl i8 1, %5784
  %5786 = or i8 %5765, %5785
  %5787 = select i1 %5776, i8 %5786, i8 %5765
  store i8 %5787, ptr %frame.active, align 1
  %5788 = load <8 x i32>, ptr %frame.static.id, align 32
  %5789 = extractelement <8 x i32> %5788, i32 %5783
  %5790 = select i1 %5776, i32 23, i32 %5789
  %5791 = load <8 x i32>, ptr %frame.static.id, align 32
  %5792 = insertelement <8 x i32> %5791, i32 %5790, i32 %5783
  store <8 x i32> %5792, ptr %frame.static.id, align 32
  %5793 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5794 = extractelement <8 x i32> %5793, i32 %5783
  %5795 = select i1 %5776, i32 %5761, i32 %5794
  %5796 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5797 = insertelement <8 x i32> %5796, i32 %5795, i32 %5783
  store <8 x i32> %5797, ptr %frame.parent.token, align 32
  %5798 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5783
  %5799 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5783
  %5800 = load <8 x i1>, ptr %5798, align 1
  %5801 = load <8 x i1>, ptr %5799, align 1
  %5802 = select i1 %5776, <8 x i1> %1838, <8 x i1> %5800
  store <8 x i1> %5802, ptr %5798, align 1
  %5803 = select i1 %5776, <8 x i1> zeroinitializer, <8 x i1> %5801
  store <8 x i1> %5803, ptr %5799, align 1
  %5804 = add i32 %5783, 1
  %5805 = select i1 %5774, i32 %5761, i32 %5804
  %5806 = select i1 true, i32 %5805, i32 %5761
  store i32 %5806, ptr %current.token, align 4
  %5807 = load i32, ptr %current.token, align 4
  %5808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1845)
  %5809 = load i32, ptr %ready.count, align 4
  %5810 = icmp uge i32 %5809, 8
  %5811 = and i1 %5808, %5810
  br i1 %5811, label %ready.overflow.trap1153, label %ready.overflow.resume1154

ready.overflow.trap1153:                          ; preds = %convergence.overflow.resume1152
  call void @llvm.trap()
  unreachable

ready.overflow.resume1154:                        ; preds = %convergence.overflow.resume1152
  %5812 = select i1 %5808, i32 %5809, i32 0
  %5813 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5812
  %5814 = load <8 x i1>, ptr %5813, align 1
  %5815 = select i1 %5808, <8 x i1> %1845, <8 x i1> %5814
  store <8 x i1> %5815, ptr %5813, align 1
  %5816 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5812
  %5817 = load i32, ptr %5816, align 4
  %5818 = select i1 %5808, i32 67, i32 %5817
  store i32 %5818, ptr %5816, align 4
  %5819 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5812
  %5820 = load i32, ptr %5819, align 4
  %5821 = select i1 %5808, i32 %5807, i32 %5820
  store i32 %5821, ptr %5819, align 4
  %5822 = add i32 %5809, 1
  %5823 = select i1 %5808, i32 %5822, i32 %5809
  store i32 %5823, ptr %ready.count, align 4
  %5824 = load <8 x i1>, ptr %runnable.mask, align 1
  %5825 = or <8 x i1> %5824, %1845
  store <8 x i1> %5825, ptr %runnable.mask, align 1
  store <8 x i1> %1847, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1155:                        ; preds = %varying.coherent1150
  store <8 x i1> %1838, ptr %current.mask, align 1
  %5826 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1838)
  br i1 %5826, label %schedule.67, label %scheduler.loop

varying.coherent.false1156:                       ; preds = %varying.coherent1150
  store <8 x i1> %1838, ptr %current.mask, align 1
  %5827 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1838)
  br i1 %5827, label %schedule.68, label %scheduler.loop

convergence.cascade1172:                          ; preds = %convergence.cascade1172, %schedule.68
  %convergence.cascade.flow1176 = phi <8 x i1> [ %1932, %schedule.68 ], [ %5870, %convergence.cascade1172 ]
  %convergence.cascade.depth1177 = phi i32 [ 0, %schedule.68 ], [ %5871, %convergence.cascade1172 ]
  %5828 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1176)
  %5829 = load i32, ptr %current.token, align 4
  %5830 = icmp ne i32 %5829, 0
  %5831 = and i1 %5828, %5830
  %5832 = sub i32 %5829, 1
  %5833 = select i1 %5831, i32 %5832, i32 0
  %5834 = load i8, ptr %frame.active, align 1
  %5835 = trunc i32 %5833 to i8
  %5836 = shl i8 1, %5835
  %5837 = and i8 %5834, %5836
  %5838 = icmp ne i8 %5837, 0
  %5839 = load <8 x i32>, ptr %frame.static.id, align 32
  %5840 = extractelement <8 x i32> %5839, i32 %5833
  %convergence.target.pointer1178 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %5840
  %convergence.dynamic.target1179 = load i32, ptr %convergence.target.pointer1178, align 4
  %5841 = icmp eq i32 %convergence.dynamic.target1179, 68
  %5842 = and i1 %5838, %5841
  %5843 = and i1 %5831, %5842
  %5844 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5833
  %5845 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5833
  %5846 = load <8 x i1>, ptr %5844, align 1
  %5847 = load <8 x i1>, ptr %5845, align 1
  %5848 = or <8 x i1> %5847, %convergence.cascade.flow1176
  %5849 = load <8 x i1>, ptr %live.mask, align 1
  %5850 = and <8 x i1> %5846, %5849
  %5851 = icmp eq <8 x i1> %5848, %5850
  %5852 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5851)
  %5853 = and i1 %5843, %5852
  %5854 = select i1 %5853, <8 x i1> zeroinitializer, <8 x i1> %5848
  %5855 = select i1 %5843, <8 x i1> %5854, <8 x i1> %5847
  store <8 x i1> %5855, ptr %5845, align 1
  %5856 = select i1 %5853, <8 x i1> zeroinitializer, <8 x i1> %5846
  store <8 x i1> %5856, ptr %5844, align 1
  %5857 = trunc i32 %5833 to i8
  %5858 = shl i8 1, %5857
  %5859 = xor i8 %5858, -1
  %5860 = and i8 %5834, %5859
  %5861 = select i1 %5853, i8 %5860, i8 %5834
  store i8 %5861, ptr %frame.active, align 1
  %.splatinsert1180 = insertelement <8 x i1> poison, i1 %5843, i64 0
  %.splat1181 = shufflevector <8 x i1> %.splatinsert1180, <8 x i1> poison, <8 x i32> zeroinitializer
  %5862 = and <8 x i1> %convergence.cascade.flow1176, %.splat1181
  %5863 = load <8 x i1>, ptr %runnable.mask, align 1
  %5864 = xor <8 x i1> %5862, splat (i1 true)
  %5865 = and <8 x i1> %5863, %5864
  store <8 x i1> %5865, ptr %runnable.mask, align 1
  %.splatinsert1182 = insertelement <8 x i1> poison, i1 %5853, i64 0
  %.splat1183 = shufflevector <8 x i1> %.splatinsert1182, <8 x i1> poison, <8 x i32> zeroinitializer
  %5866 = select <8 x i1> %.splat1183, <8 x i1> %5848, <8 x i1> zeroinitializer
  %5867 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5868 = extractelement <8 x i32> %5867, i32 %5833
  %5869 = select i1 %5853, i32 %5868, i32 %5829
  store i32 %5869, ptr %current.token, align 4
  %.splatinsert1184 = insertelement <8 x i1> poison, i1 %5843, i64 0
  %.splat1185 = shufflevector <8 x i1> %.splatinsert1184, <8 x i1> poison, <8 x i32> zeroinitializer
  %5870 = select <8 x i1> %.splat1185, <8 x i1> %5866, <8 x i1> %convergence.cascade.flow1176
  %5871 = add i32 %convergence.cascade.depth1177, 1
  %5872 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5870)
  %5873 = icmp ult i32 %5871, 8
  %5874 = and i1 %5872, %5873
  %5875 = and i1 %5843, %5874
  %convergence.parent.token1186 = load i32, ptr %current.token, align 4
  %convergence.parent.present1187 = icmp ne i32 %convergence.parent.token1186, 0
  %5876 = and i1 %5875, %convergence.parent.present1187
  br i1 %5876, label %convergence.cascade1172, label %convergence.cascade.exit1173

convergence.cascade.exit1173:                     ; preds = %convergence.cascade1172, %schedule.68
  %convergence.cascade.result1188 = phi <8 x i1> [ %1932, %schedule.68 ], [ %5870, %convergence.cascade1172 ]
  %5877 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  br i1 %5877, label %convergence.target.68.ready, label %scheduler.loop

convergence.target.68.ready:                      ; preds = %convergence.cascade.exit1173
  %5878 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %5879 = bitcast <8 x i1> %convergence.cascade.result1188 to i8
  %5880 = call i8 @llvm.cttz.i8(i8 %5879, i1 false)
  %5881 = zext i8 %5880 to i32
  %5882 = select i1 %5878, i32 %5881, i32 0
  %.state1189 = load <8 x float>, ptr %.slot58, align 32
  %5883 = fmul <8 x float> %.state1189, splat (float 0x3FC43D1360000000)
  %.state1190 = load <8 x float>, ptr %.slot65, align 32
  %5884 = fmul <8 x float> %.state1190, splat (float 0x3FC43D1360000000)
  %.state1191 = load <8 x float>, ptr %.slot66, align 32
  %5885 = fmul <8 x float> %.state1191, splat (float 0x3FC43D1360000000)
  %.state1192 = load <8 x float>, ptr %.slot67, align 32
  %5886 = fmul <8 x float> %.state1192, splat (float 0x3FC43D1360000000)
  %.state1193 = load <8 x float>, ptr %.slot69, align 32
  %5887 = fmul <8 x float> %.state1193, splat (float 0x3FC43D1360000000)
  %.state1194 = load <8 x float>, ptr %.slot70, align 32
  %5888 = fmul <8 x float> %.state1194, splat (float 0x3FC43D1360000000)
  %.state1195 = load <8 x float>, ptr %.slot71, align 32
  %5889 = fmul <8 x float> %.state1195, splat (float 0x3FC43D1360000000)
  %.state1196 = load <8 x float>, ptr %.slot72, align 32
  %5890 = fmul <8 x float> %.state1196, splat (float 0x3FC43D1360000000)
  %.state1197 = load <8 x float>, ptr %.slot74, align 32
  %5891 = fmul <8 x float> %.state1197, splat (float 0x3FC43D1360000000)
  %.state1198 = load <8 x float>, ptr %.slot75, align 32
  %5892 = fmul <8 x float> %.state1198, splat (float 0x3FC43D1360000000)
  %.state1199 = load <8 x float>, ptr %.slot76, align 32
  %5893 = fmul <8 x float> %.state1199, splat (float 0x3FC43D1360000000)
  %.state1200 = load <8 x float>, ptr %.slot77, align 32
  %5894 = fmul <8 x float> %.state1200, splat (float 0x3FC43D1360000000)
  %.state1201 = load <8 x float>, ptr %.slot79, align 32
  %5895 = fmul <8 x float> %.state1201, splat (float 0x3FC43D1360000000)
  %.state1202 = load <8 x float>, ptr %.slot80, align 32
  %5896 = fmul <8 x float> %.state1202, splat (float 0x3FC43D1360000000)
  %.state1203 = load <8 x float>, ptr %.slot81, align 32
  %5897 = fmul <8 x float> %.state1203, splat (float 0x3FC43D1360000000)
  %.state1204 = load <8 x float>, ptr %.slot82, align 32
  %5898 = fmul <8 x float> %.state1204, splat (float 0x3FC43D1360000000)
  %.state1205 = load <8 x float>, ptr %.slot84, align 32
  %5899 = fmul <8 x float> %.state1205, splat (float 0x3FC43D1360000000)
  %.state1206 = load <8 x float>, ptr %.slot85, align 32
  %5900 = fmul <8 x float> %.state1206, splat (float 0x3FC43D1360000000)
  %.state1207 = load <8 x float>, ptr %.slot86, align 32
  %5901 = fmul <8 x float> %.state1207, splat (float 0x3FC43D1360000000)
  %.state1208 = load <8 x float>, ptr %.slot87, align 32
  %5902 = fmul <8 x float> %.state1208, splat (float 0x3FC43D1360000000)
  %.state1209 = load <8 x float>, ptr %.slot89, align 32
  %5903 = fmul <8 x float> %.state1209, splat (float 0x3FC43D1360000000)
  %.state1210 = load <8 x float>, ptr %.slot90, align 32
  %5904 = fmul <8 x float> %.state1210, splat (float 0x3FC43D1360000000)
  %.state1211 = load <8 x float>, ptr %.slot91, align 32
  %5905 = fmul <8 x float> %.state1211, splat (float 0x3FC43D1360000000)
  %.state1212 = load <8 x float>, ptr %.slot92, align 32
  %5906 = fmul <8 x float> %.state1212, splat (float 0x3FC43D1360000000)
  %.state1213 = load <8 x float>, ptr %.slot94, align 32
  %5907 = fmul <8 x float> %.state1213, splat (float 0x3FC43D1360000000)
  %.state1214 = load <8 x float>, ptr %.slot95, align 32
  %5908 = fmul <8 x float> %.state1214, splat (float 0x3FC43D1360000000)
  %.state1215 = load <8 x float>, ptr %.slot96, align 32
  %5909 = fmul <8 x float> %.state1215, splat (float 0x3FC43D1360000000)
  %.state1216 = load <8 x float>, ptr %.slot97, align 32
  %5910 = fmul <8 x float> %.state1216, splat (float 0x3FC43D1360000000)
  %.state1217 = load <8 x float>, ptr %.slot99, align 32
  %5911 = fmul <8 x float> %.state1217, splat (float 0x3FC43D1360000000)
  %.state1218 = load <8 x float>, ptr %.slot100, align 32
  %5912 = fmul <8 x float> %.state1218, splat (float 0x3FC43D1360000000)
  %.state1219 = load <8 x float>, ptr %.slot101, align 32
  %5913 = fmul <8 x float> %.state1219, splat (float 0x3FC43D1360000000)
  %.state1220 = load <8 x float>, ptr %.slot102, align 32
  %5914 = fmul <8 x float> %.state1220, splat (float 0x3FC43D1360000000)
  %.state1221 = load <8 x float>, ptr %.slot104, align 32
  %5915 = fmul <8 x float> %.state1221, splat (float 0x3FC43D1360000000)
  %.state1222 = load <8 x float>, ptr %.slot105, align 32
  %5916 = fmul <8 x float> %.state1222, splat (float 0x3FC43D1360000000)
  %.state1223 = load <8 x float>, ptr %.slot106, align 32
  %5917 = fmul <8 x float> %.state1223, splat (float 0x3FC43D1360000000)
  %.state1224 = load <8 x float>, ptr %.slot107, align 32
  %5918 = fmul <8 x float> %.state1224, splat (float 0x3FC43D1360000000)
  %.state1225 = load <8 x float>, ptr %.slot109, align 32
  %5919 = fmul <8 x float> %.state1225, splat (float 0x3FC43D1360000000)
  %.state1226 = load <8 x float>, ptr %.slot110, align 32
  %5920 = fmul <8 x float> %.state1226, splat (float 0x3FC43D1360000000)
  %.state1227 = load <8 x float>, ptr %.slot111, align 32
  %5921 = fmul <8 x float> %.state1227, splat (float 0x3FC43D1360000000)
  %.state1228 = load <8 x float>, ptr %.slot112, align 32
  %5922 = fmul <8 x float> %.state1228, splat (float 0x3FC43D1360000000)
  %.state1229 = load <8 x float>, ptr %.slot114, align 32
  %5923 = fmul <8 x float> %.state1229, splat (float 0x3FC43D1360000000)
  %.state1230 = load <8 x float>, ptr %.slot115, align 32
  %5924 = fmul <8 x float> %.state1230, splat (float 0x3FC43D1360000000)
  %.state1231 = load <8 x float>, ptr %.slot116, align 32
  %5925 = fmul <8 x float> %.state1231, splat (float 0x3FC43D1360000000)
  %.state1232 = load <8 x float>, ptr %.slot117, align 32
  %5926 = fmul <8 x float> %.state1232, splat (float 0x3FC43D1360000000)
  %.state1233 = load <8 x float>, ptr %.slot119, align 32
  %5927 = fmul <8 x float> %.state1233, splat (float 0x3FC43D1360000000)
  %.state1234 = load <8 x float>, ptr %.slot120, align 32
  %5928 = fmul <8 x float> %.state1234, splat (float 0x3FC43D1360000000)
  %.state1235 = load <8 x float>, ptr %.slot121, align 32
  %5929 = fmul <8 x float> %.state1235, splat (float 0x3FC43D1360000000)
  %.state1236 = load <8 x float>, ptr %.slot122, align 32
  %5930 = fmul <8 x float> %.state1236, splat (float 0x3FC43D1360000000)
  %.state1237 = load <8 x float>, ptr %.slot124, align 32
  %5931 = fmul <8 x float> %.state1237, splat (float 0x3FC43D1360000000)
  %.state1238 = load <8 x float>, ptr %.slot125, align 32
  %5932 = fmul <8 x float> %.state1238, splat (float 0x3FC43D1360000000)
  %.state1239 = load <8 x float>, ptr %.slot126, align 32
  %5933 = fmul <8 x float> %.state1239, splat (float 0x3FC43D1360000000)
  %.state1240 = load <8 x float>, ptr %.slot127, align 32
  %5934 = fmul <8 x float> %.state1240, splat (float 0x3FC43D1360000000)
  %.state1241 = load <8 x float>, ptr %.slot129, align 32
  %5935 = fmul <8 x float> %.state1241, splat (float 0x3FC43D1360000000)
  %.state1242 = load <8 x float>, ptr %.slot130, align 32
  %5936 = fmul <8 x float> %.state1242, splat (float 0x3FC43D1360000000)
  %.state1243 = load <8 x float>, ptr %.slot131, align 32
  %5937 = fmul <8 x float> %.state1243, splat (float 0x3FC43D1360000000)
  %.state1244 = load <8 x float>, ptr %.slot132, align 32
  %5938 = fmul <8 x float> %.state1244, splat (float 0x3FC43D1360000000)
  %.state1245 = load <8 x float>, ptr %.slot134, align 32
  %5939 = fmul <8 x float> %.state1245, splat (float 0x3FC43D1360000000)
  %.state1246 = load <8 x float>, ptr %.slot135, align 32
  %5940 = fmul <8 x float> %.state1246, splat (float 0x3FC43D1360000000)
  %.state1247 = load <8 x float>, ptr %.slot136, align 32
  %5941 = fmul <8 x float> %.state1247, splat (float 0x3FC43D1360000000)
  %.state1248 = load <8 x float>, ptr %.slot137, align 32
  %5942 = fmul <8 x float> %.state1248, splat (float 0x3FC43D1360000000)
  %.state1249 = load <8 x float>, ptr %.slot139, align 32
  %5943 = fmul <8 x float> %.state1249, splat (float 0x3FC43D1360000000)
  %.state1250 = load <8 x float>, ptr %.slot140, align 32
  %5944 = fmul <8 x float> %.state1250, splat (float 0x3FC43D1360000000)
  %.state1251 = load <8 x float>, ptr %.slot141, align 32
  %5945 = fmul <8 x float> %.state1251, splat (float 0x3FC43D1360000000)
  %.state1252 = load <8 x float>, ptr %.slot142, align 32
  %5946 = fmul <8 x float> %.state1252, splat (float 0x3FC43D1360000000)
  %.spill.load1253 = load <8 x i64>, ptr %.spill54, align 64
  %5947 = add <8 x i64> zeroinitializer, %.spill.load1253
  %.spill.load1254 = load <8 x i64>, ptr %.spill54, align 64
  %5948 = add <8 x i64> splat (i64 1), %.spill.load1254
  %.spill.load1255 = load <8 x i64>, ptr %.spill54, align 64
  %5949 = add <8 x i64> splat (i64 2), %.spill.load1255
  %.spill.load1256 = load <8 x i64>, ptr %.spill54, align 64
  %5950 = add <8 x i64> splat (i64 3), %.spill.load1256
  %.spill.load1257 = load <8 x i64>, ptr %.spill54, align 64
  %5951 = add <8 x i64> splat (i64 4), %.spill.load1257
  %.spill.load1258 = load <8 x i64>, ptr %.spill54, align 64
  %5952 = add <8 x i64> splat (i64 5), %.spill.load1258
  %.spill.load1259 = load <8 x i64>, ptr %.spill54, align 64
  %5953 = add <8 x i64> splat (i64 6), %.spill.load1259
  %.spill.load1260 = load <8 x i64>, ptr %.spill54, align 64
  %5954 = add <8 x i64> splat (i64 7), %.spill.load1260
  %.spill.load1261 = load <8 x i64>, ptr %.spill54, align 64
  %5955 = add <8 x i64> splat (i64 8), %.spill.load1261
  %.spill.load1262 = load <8 x i64>, ptr %.spill54, align 64
  %5956 = add <8 x i64> splat (i64 9), %.spill.load1262
  %.spill.load1263 = load <8 x i64>, ptr %.spill54, align 64
  %5957 = add <8 x i64> splat (i64 10), %.spill.load1263
  %.spill.load1264 = load <8 x i64>, ptr %.spill54, align 64
  %5958 = add <8 x i64> splat (i64 11), %.spill.load1264
  %.spill.load1265 = load <8 x i64>, ptr %.spill54, align 64
  %5959 = add <8 x i64> splat (i64 12), %.spill.load1265
  %.spill.load1266 = load <8 x i64>, ptr %.spill54, align 64
  %5960 = add <8 x i64> splat (i64 13), %.spill.load1266
  %.spill.load1267 = load <8 x i64>, ptr %.spill54, align 64
  %5961 = add <8 x i64> splat (i64 14), %.spill.load1267
  %.spill.load1268 = load <8 x i64>, ptr %.spill54, align 64
  %5962 = add <8 x i64> splat (i64 15), %.spill.load1268
  %5963 = icmp slt <8 x i64> %5947, splat (i64 67)
  %5964 = icmp slt <8 x i64> %5948, splat (i64 67)
  %5965 = icmp slt <8 x i64> %5949, splat (i64 67)
  %5966 = icmp slt <8 x i64> %5950, splat (i64 67)
  %5967 = icmp slt <8 x i64> %5951, splat (i64 67)
  %5968 = icmp slt <8 x i64> %5952, splat (i64 67)
  %5969 = icmp slt <8 x i64> %5953, splat (i64 67)
  %5970 = icmp slt <8 x i64> %5954, splat (i64 67)
  %5971 = icmp slt <8 x i64> %5955, splat (i64 67)
  %5972 = icmp slt <8 x i64> %5956, splat (i64 67)
  %5973 = icmp slt <8 x i64> %5957, splat (i64 67)
  %5974 = icmp slt <8 x i64> %5958, splat (i64 67)
  %5975 = icmp slt <8 x i64> %5959, splat (i64 67)
  %5976 = icmp slt <8 x i64> %5960, splat (i64 67)
  %5977 = icmp slt <8 x i64> %5961, splat (i64 67)
  %5978 = icmp slt <8 x i64> %5962, splat (i64 67)
  %.spill.load1269 = load <8 x i64>, ptr %.spill38, align 64
  %5979 = add <8 x i64> zeroinitializer, %.spill.load1269
  %.spill.load1270 = load <8 x i64>, ptr %.spill38, align 64
  %5980 = add <8 x i64> splat (i64 1), %.spill.load1270
  %.spill.load1271 = load <8 x i64>, ptr %.spill38, align 64
  %5981 = add <8 x i64> splat (i64 2), %.spill.load1271
  %.spill.load1272 = load <8 x i64>, ptr %.spill38, align 64
  %5982 = add <8 x i64> splat (i64 3), %.spill.load1272
  %5983 = add <8 x i64> %5979, splat (i64 67)
  %5984 = add <8 x i64> %5980, splat (i64 67)
  %5985 = add <8 x i64> %5981, splat (i64 67)
  %5986 = add <8 x i64> %5982, splat (i64 67)
  %5987 = sub <8 x i64> %5983, splat (i64 17)
  %5988 = sub <8 x i64> %5984, splat (i64 17)
  %5989 = sub <8 x i64> %5985, splat (i64 17)
  %5990 = sub <8 x i64> %5986, splat (i64 17)
  %5991 = icmp sle <8 x i64> %5947, %5987
  %5992 = icmp sle <8 x i64> %5947, %5988
  %5993 = icmp sle <8 x i64> %5947, %5989
  %5994 = icmp sle <8 x i64> %5947, %5990
  %5995 = icmp sle <8 x i64> %5948, %5987
  %5996 = icmp sle <8 x i64> %5948, %5988
  %5997 = icmp sle <8 x i64> %5948, %5989
  %5998 = icmp sle <8 x i64> %5948, %5990
  %5999 = icmp sle <8 x i64> %5949, %5987
  %6000 = icmp sle <8 x i64> %5949, %5988
  %6001 = icmp sle <8 x i64> %5949, %5989
  %6002 = icmp sle <8 x i64> %5949, %5990
  %6003 = icmp sle <8 x i64> %5950, %5987
  %6004 = icmp sle <8 x i64> %5950, %5988
  %6005 = icmp sle <8 x i64> %5950, %5989
  %6006 = icmp sle <8 x i64> %5950, %5990
  %6007 = icmp sle <8 x i64> %5951, %5987
  %6008 = icmp sle <8 x i64> %5951, %5988
  %6009 = icmp sle <8 x i64> %5951, %5989
  %6010 = icmp sle <8 x i64> %5951, %5990
  %6011 = icmp sle <8 x i64> %5952, %5987
  %6012 = icmp sle <8 x i64> %5952, %5988
  %6013 = icmp sle <8 x i64> %5952, %5989
  %6014 = icmp sle <8 x i64> %5952, %5990
  %6015 = icmp sle <8 x i64> %5953, %5987
  %6016 = icmp sle <8 x i64> %5953, %5988
  %6017 = icmp sle <8 x i64> %5953, %5989
  %6018 = icmp sle <8 x i64> %5953, %5990
  %6019 = icmp sle <8 x i64> %5954, %5987
  %6020 = icmp sle <8 x i64> %5954, %5988
  %6021 = icmp sle <8 x i64> %5954, %5989
  %6022 = icmp sle <8 x i64> %5954, %5990
  %6023 = icmp sle <8 x i64> %5955, %5987
  %6024 = icmp sle <8 x i64> %5955, %5988
  %6025 = icmp sle <8 x i64> %5955, %5989
  %6026 = icmp sle <8 x i64> %5955, %5990
  %6027 = icmp sle <8 x i64> %5956, %5987
  %6028 = icmp sle <8 x i64> %5956, %5988
  %6029 = icmp sle <8 x i64> %5956, %5989
  %6030 = icmp sle <8 x i64> %5956, %5990
  %6031 = icmp sle <8 x i64> %5957, %5987
  %6032 = icmp sle <8 x i64> %5957, %5988
  %6033 = icmp sle <8 x i64> %5957, %5989
  %6034 = icmp sle <8 x i64> %5957, %5990
  %6035 = icmp sle <8 x i64> %5958, %5987
  %6036 = icmp sle <8 x i64> %5958, %5988
  %6037 = icmp sle <8 x i64> %5958, %5989
  %6038 = icmp sle <8 x i64> %5958, %5990
  %6039 = icmp sle <8 x i64> %5959, %5987
  %6040 = icmp sle <8 x i64> %5959, %5988
  %6041 = icmp sle <8 x i64> %5959, %5989
  %6042 = icmp sle <8 x i64> %5959, %5990
  %6043 = icmp sle <8 x i64> %5960, %5987
  %6044 = icmp sle <8 x i64> %5960, %5988
  %6045 = icmp sle <8 x i64> %5960, %5989
  %6046 = icmp sle <8 x i64> %5960, %5990
  %6047 = icmp sle <8 x i64> %5961, %5987
  %6048 = icmp sle <8 x i64> %5961, %5988
  %6049 = icmp sle <8 x i64> %5961, %5989
  %6050 = icmp sle <8 x i64> %5961, %5990
  %6051 = icmp sle <8 x i64> %5962, %5987
  %6052 = icmp sle <8 x i64> %5962, %5988
  %6053 = icmp sle <8 x i64> %5962, %5989
  %6054 = icmp sle <8 x i64> %5962, %5990
  %6055 = and <8 x i1> %5963, %5991
  %6056 = load <8 x i1>, ptr %.spill143, align 1
  %6057 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6055, <8 x i1> %6056
  store <8 x i1> %6057, ptr %.spill143, align 1
  %6058 = and <8 x i1> %5963, %5992
  %6059 = load <8 x i1>, ptr %.spill144, align 1
  %6060 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6058, <8 x i1> %6059
  store <8 x i1> %6060, ptr %.spill144, align 1
  %6061 = and <8 x i1> %5963, %5993
  %6062 = load <8 x i1>, ptr %.spill145, align 1
  %6063 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6061, <8 x i1> %6062
  store <8 x i1> %6063, ptr %.spill145, align 1
  %6064 = and <8 x i1> %5963, %5994
  %6065 = load <8 x i1>, ptr %.spill146, align 1
  %6066 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6064, <8 x i1> %6065
  store <8 x i1> %6066, ptr %.spill146, align 1
  %6067 = and <8 x i1> %5964, %5995
  %6068 = load <8 x i1>, ptr %.spill147, align 1
  %6069 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6067, <8 x i1> %6068
  store <8 x i1> %6069, ptr %.spill147, align 1
  %6070 = and <8 x i1> %5964, %5996
  %6071 = load <8 x i1>, ptr %.spill148, align 1
  %6072 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6070, <8 x i1> %6071
  store <8 x i1> %6072, ptr %.spill148, align 1
  %6073 = and <8 x i1> %5964, %5997
  %6074 = load <8 x i1>, ptr %.spill149, align 1
  %6075 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6073, <8 x i1> %6074
  store <8 x i1> %6075, ptr %.spill149, align 1
  %6076 = and <8 x i1> %5964, %5998
  %6077 = load <8 x i1>, ptr %.spill150, align 1
  %6078 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6076, <8 x i1> %6077
  store <8 x i1> %6078, ptr %.spill150, align 1
  %6079 = and <8 x i1> %5965, %5999
  %6080 = load <8 x i1>, ptr %.spill151, align 1
  %6081 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6079, <8 x i1> %6080
  store <8 x i1> %6081, ptr %.spill151, align 1
  %6082 = and <8 x i1> %5965, %6000
  %6083 = load <8 x i1>, ptr %.spill152, align 1
  %6084 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6082, <8 x i1> %6083
  store <8 x i1> %6084, ptr %.spill152, align 1
  %6085 = and <8 x i1> %5965, %6001
  %6086 = load <8 x i1>, ptr %.spill153, align 1
  %6087 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6085, <8 x i1> %6086
  store <8 x i1> %6087, ptr %.spill153, align 1
  %6088 = and <8 x i1> %5965, %6002
  %6089 = load <8 x i1>, ptr %.spill154, align 1
  %6090 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6088, <8 x i1> %6089
  store <8 x i1> %6090, ptr %.spill154, align 1
  %6091 = and <8 x i1> %5966, %6003
  %6092 = load <8 x i1>, ptr %.spill155, align 1
  %6093 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6091, <8 x i1> %6092
  store <8 x i1> %6093, ptr %.spill155, align 1
  %6094 = and <8 x i1> %5966, %6004
  %6095 = load <8 x i1>, ptr %.spill156, align 1
  %6096 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6094, <8 x i1> %6095
  store <8 x i1> %6096, ptr %.spill156, align 1
  %6097 = and <8 x i1> %5966, %6005
  %6098 = load <8 x i1>, ptr %.spill157, align 1
  %6099 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6097, <8 x i1> %6098
  store <8 x i1> %6099, ptr %.spill157, align 1
  %6100 = and <8 x i1> %5966, %6006
  %6101 = load <8 x i1>, ptr %.spill158, align 1
  %6102 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6100, <8 x i1> %6101
  store <8 x i1> %6102, ptr %.spill158, align 1
  %6103 = and <8 x i1> %5967, %6007
  %6104 = load <8 x i1>, ptr %.spill159, align 1
  %6105 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6103, <8 x i1> %6104
  store <8 x i1> %6105, ptr %.spill159, align 1
  %6106 = and <8 x i1> %5967, %6008
  %6107 = load <8 x i1>, ptr %.spill160, align 1
  %6108 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6106, <8 x i1> %6107
  store <8 x i1> %6108, ptr %.spill160, align 1
  %6109 = and <8 x i1> %5967, %6009
  %6110 = load <8 x i1>, ptr %.spill161, align 1
  %6111 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6109, <8 x i1> %6110
  store <8 x i1> %6111, ptr %.spill161, align 1
  %6112 = and <8 x i1> %5967, %6010
  %6113 = load <8 x i1>, ptr %.spill162, align 1
  %6114 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6112, <8 x i1> %6113
  store <8 x i1> %6114, ptr %.spill162, align 1
  %6115 = and <8 x i1> %5968, %6011
  %6116 = load <8 x i1>, ptr %.spill163, align 1
  %6117 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6115, <8 x i1> %6116
  store <8 x i1> %6117, ptr %.spill163, align 1
  %6118 = and <8 x i1> %5968, %6012
  %6119 = load <8 x i1>, ptr %.spill164, align 1
  %6120 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6118, <8 x i1> %6119
  store <8 x i1> %6120, ptr %.spill164, align 1
  %6121 = and <8 x i1> %5968, %6013
  %6122 = load <8 x i1>, ptr %.spill165, align 1
  %6123 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6121, <8 x i1> %6122
  store <8 x i1> %6123, ptr %.spill165, align 1
  %6124 = and <8 x i1> %5968, %6014
  %6125 = load <8 x i1>, ptr %.spill166, align 1
  %6126 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6124, <8 x i1> %6125
  store <8 x i1> %6126, ptr %.spill166, align 1
  %6127 = and <8 x i1> %5969, %6015
  %6128 = load <8 x i1>, ptr %.spill167, align 1
  %6129 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6127, <8 x i1> %6128
  store <8 x i1> %6129, ptr %.spill167, align 1
  %6130 = and <8 x i1> %5969, %6016
  %6131 = load <8 x i1>, ptr %.spill168, align 1
  %6132 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6130, <8 x i1> %6131
  store <8 x i1> %6132, ptr %.spill168, align 1
  %6133 = and <8 x i1> %5969, %6017
  %6134 = load <8 x i1>, ptr %.spill169, align 1
  %6135 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6133, <8 x i1> %6134
  store <8 x i1> %6135, ptr %.spill169, align 1
  %6136 = and <8 x i1> %5969, %6018
  %6137 = load <8 x i1>, ptr %.spill170, align 1
  %6138 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6136, <8 x i1> %6137
  store <8 x i1> %6138, ptr %.spill170, align 1
  %6139 = and <8 x i1> %5970, %6019
  %6140 = load <8 x i1>, ptr %.spill171, align 1
  %6141 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6139, <8 x i1> %6140
  store <8 x i1> %6141, ptr %.spill171, align 1
  %6142 = and <8 x i1> %5970, %6020
  %6143 = load <8 x i1>, ptr %.spill172, align 1
  %6144 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6142, <8 x i1> %6143
  store <8 x i1> %6144, ptr %.spill172, align 1
  %6145 = and <8 x i1> %5970, %6021
  %6146 = load <8 x i1>, ptr %.spill173, align 1
  %6147 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6145, <8 x i1> %6146
  store <8 x i1> %6147, ptr %.spill173, align 1
  %6148 = and <8 x i1> %5970, %6022
  %6149 = load <8 x i1>, ptr %.spill174, align 1
  %6150 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6148, <8 x i1> %6149
  store <8 x i1> %6150, ptr %.spill174, align 1
  %6151 = and <8 x i1> %5971, %6023
  %6152 = load <8 x i1>, ptr %.spill175, align 1
  %6153 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6151, <8 x i1> %6152
  store <8 x i1> %6153, ptr %.spill175, align 1
  %6154 = and <8 x i1> %5971, %6024
  %6155 = load <8 x i1>, ptr %.spill176, align 1
  %6156 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6154, <8 x i1> %6155
  store <8 x i1> %6156, ptr %.spill176, align 1
  %6157 = and <8 x i1> %5971, %6025
  %6158 = load <8 x i1>, ptr %.spill177, align 1
  %6159 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6157, <8 x i1> %6158
  store <8 x i1> %6159, ptr %.spill177, align 1
  %6160 = and <8 x i1> %5971, %6026
  %6161 = load <8 x i1>, ptr %.spill178, align 1
  %6162 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6160, <8 x i1> %6161
  store <8 x i1> %6162, ptr %.spill178, align 1
  %6163 = and <8 x i1> %5972, %6027
  %6164 = load <8 x i1>, ptr %.spill179, align 1
  %6165 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6163, <8 x i1> %6164
  store <8 x i1> %6165, ptr %.spill179, align 1
  %6166 = and <8 x i1> %5972, %6028
  %6167 = load <8 x i1>, ptr %.spill180, align 1
  %6168 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6166, <8 x i1> %6167
  store <8 x i1> %6168, ptr %.spill180, align 1
  %6169 = and <8 x i1> %5972, %6029
  %6170 = load <8 x i1>, ptr %.spill181, align 1
  %6171 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6169, <8 x i1> %6170
  store <8 x i1> %6171, ptr %.spill181, align 1
  %6172 = and <8 x i1> %5972, %6030
  %6173 = load <8 x i1>, ptr %.spill182, align 1
  %6174 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6172, <8 x i1> %6173
  store <8 x i1> %6174, ptr %.spill182, align 1
  %6175 = and <8 x i1> %5973, %6031
  %6176 = load <8 x i1>, ptr %.spill183, align 1
  %6177 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6175, <8 x i1> %6176
  store <8 x i1> %6177, ptr %.spill183, align 1
  %6178 = and <8 x i1> %5973, %6032
  %6179 = load <8 x i1>, ptr %.spill184, align 1
  %6180 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6178, <8 x i1> %6179
  store <8 x i1> %6180, ptr %.spill184, align 1
  %6181 = and <8 x i1> %5973, %6033
  %6182 = load <8 x i1>, ptr %.spill185, align 1
  %6183 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6181, <8 x i1> %6182
  store <8 x i1> %6183, ptr %.spill185, align 1
  %6184 = and <8 x i1> %5973, %6034
  %6185 = load <8 x i1>, ptr %.spill186, align 1
  %6186 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6184, <8 x i1> %6185
  store <8 x i1> %6186, ptr %.spill186, align 1
  %6187 = and <8 x i1> %5974, %6035
  %6188 = load <8 x i1>, ptr %.spill187, align 1
  %6189 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6187, <8 x i1> %6188
  store <8 x i1> %6189, ptr %.spill187, align 1
  %6190 = and <8 x i1> %5974, %6036
  %6191 = load <8 x i1>, ptr %.spill188, align 1
  %6192 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6190, <8 x i1> %6191
  store <8 x i1> %6192, ptr %.spill188, align 1
  %6193 = and <8 x i1> %5974, %6037
  %6194 = load <8 x i1>, ptr %.spill189, align 1
  %6195 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6193, <8 x i1> %6194
  store <8 x i1> %6195, ptr %.spill189, align 1
  %6196 = and <8 x i1> %5974, %6038
  %6197 = load <8 x i1>, ptr %.spill190, align 1
  %6198 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6196, <8 x i1> %6197
  store <8 x i1> %6198, ptr %.spill190, align 1
  %6199 = and <8 x i1> %5975, %6039
  %6200 = load <8 x i1>, ptr %.spill191, align 1
  %6201 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6199, <8 x i1> %6200
  store <8 x i1> %6201, ptr %.spill191, align 1
  %6202 = and <8 x i1> %5975, %6040
  %6203 = load <8 x i1>, ptr %.spill192, align 1
  %6204 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6202, <8 x i1> %6203
  store <8 x i1> %6204, ptr %.spill192, align 1
  %6205 = and <8 x i1> %5975, %6041
  %6206 = load <8 x i1>, ptr %.spill193, align 1
  %6207 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6205, <8 x i1> %6206
  store <8 x i1> %6207, ptr %.spill193, align 1
  %6208 = and <8 x i1> %5975, %6042
  %6209 = load <8 x i1>, ptr %.spill194, align 1
  %6210 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6208, <8 x i1> %6209
  store <8 x i1> %6210, ptr %.spill194, align 1
  %6211 = and <8 x i1> %5976, %6043
  %6212 = load <8 x i1>, ptr %.spill195, align 1
  %6213 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6211, <8 x i1> %6212
  store <8 x i1> %6213, ptr %.spill195, align 1
  %6214 = and <8 x i1> %5976, %6044
  %6215 = load <8 x i1>, ptr %.spill196, align 1
  %6216 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6214, <8 x i1> %6215
  store <8 x i1> %6216, ptr %.spill196, align 1
  %6217 = and <8 x i1> %5976, %6045
  %6218 = load <8 x i1>, ptr %.spill197, align 1
  %6219 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6217, <8 x i1> %6218
  store <8 x i1> %6219, ptr %.spill197, align 1
  %6220 = and <8 x i1> %5976, %6046
  %6221 = load <8 x i1>, ptr %.spill198, align 1
  %6222 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6220, <8 x i1> %6221
  store <8 x i1> %6222, ptr %.spill198, align 1
  %6223 = and <8 x i1> %5977, %6047
  %6224 = load <8 x i1>, ptr %.spill199, align 1
  %6225 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6223, <8 x i1> %6224
  store <8 x i1> %6225, ptr %.spill199, align 1
  %6226 = and <8 x i1> %5977, %6048
  %6227 = load <8 x i1>, ptr %.spill200, align 1
  %6228 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6226, <8 x i1> %6227
  store <8 x i1> %6228, ptr %.spill200, align 1
  %6229 = and <8 x i1> %5977, %6049
  %6230 = load <8 x i1>, ptr %.spill201, align 1
  %6231 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6229, <8 x i1> %6230
  store <8 x i1> %6231, ptr %.spill201, align 1
  %6232 = and <8 x i1> %5977, %6050
  %6233 = load <8 x i1>, ptr %.spill202, align 1
  %6234 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6232, <8 x i1> %6233
  store <8 x i1> %6234, ptr %.spill202, align 1
  %6235 = and <8 x i1> %5978, %6051
  %6236 = load <8 x i1>, ptr %.spill203, align 1
  %6237 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6235, <8 x i1> %6236
  store <8 x i1> %6237, ptr %.spill203, align 1
  %6238 = and <8 x i1> %5978, %6052
  %6239 = load <8 x i1>, ptr %.spill204, align 1
  %6240 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6238, <8 x i1> %6239
  store <8 x i1> %6240, ptr %.spill204, align 1
  %6241 = and <8 x i1> %5978, %6053
  %6242 = load <8 x i1>, ptr %.spill205, align 1
  %6243 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6241, <8 x i1> %6242
  store <8 x i1> %6243, ptr %.spill205, align 1
  %6244 = and <8 x i1> %5978, %6054
  %6245 = load <8 x i1>, ptr %.spill206, align 1
  %6246 = select <8 x i1> %convergence.cascade.result1188, <8 x i1> %6244, <8 x i1> %6245
  store <8 x i1> %6246, ptr %.spill206, align 1
  %6247 = select <8 x i1> %6055, <8 x float> %5883, <8 x float> splat (float 0xC6293E5940000000)
  %6248 = load <8 x float>, ptr %.spill207, align 32
  %6249 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6247, <8 x float> %6248
  store <8 x float> %6249, ptr %.spill207, align 32
  %6250 = select <8 x i1> %6067, <8 x float> %5884, <8 x float> splat (float 0xC6293E5940000000)
  %6251 = load <8 x float>, ptr %.spill208, align 32
  %6252 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6250, <8 x float> %6251
  store <8 x float> %6252, ptr %.spill208, align 32
  %6253 = select <8 x i1> %6079, <8 x float> %5885, <8 x float> splat (float 0xC6293E5940000000)
  %6254 = load <8 x float>, ptr %.spill209, align 32
  %6255 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6253, <8 x float> %6254
  store <8 x float> %6255, ptr %.spill209, align 32
  %6256 = select <8 x i1> %6091, <8 x float> %5886, <8 x float> splat (float 0xC6293E5940000000)
  %6257 = load <8 x float>, ptr %.spill210, align 32
  %6258 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6256, <8 x float> %6257
  store <8 x float> %6258, ptr %.spill210, align 32
  %6259 = select <8 x i1> %6103, <8 x float> %5887, <8 x float> splat (float 0xC6293E5940000000)
  %6260 = load <8 x float>, ptr %.spill211, align 32
  %6261 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6259, <8 x float> %6260
  store <8 x float> %6261, ptr %.spill211, align 32
  %6262 = select <8 x i1> %6115, <8 x float> %5888, <8 x float> splat (float 0xC6293E5940000000)
  %6263 = load <8 x float>, ptr %.spill212, align 32
  %6264 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6262, <8 x float> %6263
  store <8 x float> %6264, ptr %.spill212, align 32
  %6265 = select <8 x i1> %6127, <8 x float> %5889, <8 x float> splat (float 0xC6293E5940000000)
  %6266 = load <8 x float>, ptr %.spill213, align 32
  %6267 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6265, <8 x float> %6266
  store <8 x float> %6267, ptr %.spill213, align 32
  %6268 = select <8 x i1> %6139, <8 x float> %5890, <8 x float> splat (float 0xC6293E5940000000)
  %6269 = load <8 x float>, ptr %.spill214, align 32
  %6270 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6268, <8 x float> %6269
  store <8 x float> %6270, ptr %.spill214, align 32
  %6271 = select <8 x i1> %6151, <8 x float> %5891, <8 x float> splat (float 0xC6293E5940000000)
  %6272 = load <8 x float>, ptr %.spill215, align 32
  %6273 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6271, <8 x float> %6272
  store <8 x float> %6273, ptr %.spill215, align 32
  %6274 = select <8 x i1> %6163, <8 x float> %5892, <8 x float> splat (float 0xC6293E5940000000)
  %6275 = load <8 x float>, ptr %.spill216, align 32
  %6276 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6274, <8 x float> %6275
  store <8 x float> %6276, ptr %.spill216, align 32
  %6277 = select <8 x i1> %6175, <8 x float> %5893, <8 x float> splat (float 0xC6293E5940000000)
  %6278 = load <8 x float>, ptr %.spill217, align 32
  %6279 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6277, <8 x float> %6278
  store <8 x float> %6279, ptr %.spill217, align 32
  %6280 = select <8 x i1> %6187, <8 x float> %5894, <8 x float> splat (float 0xC6293E5940000000)
  %6281 = load <8 x float>, ptr %.spill218, align 32
  %6282 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6280, <8 x float> %6281
  store <8 x float> %6282, ptr %.spill218, align 32
  %6283 = select <8 x i1> %6199, <8 x float> %5895, <8 x float> splat (float 0xC6293E5940000000)
  %6284 = load <8 x float>, ptr %.spill219, align 32
  %6285 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6283, <8 x float> %6284
  store <8 x float> %6285, ptr %.spill219, align 32
  %6286 = select <8 x i1> %6211, <8 x float> %5896, <8 x float> splat (float 0xC6293E5940000000)
  %6287 = load <8 x float>, ptr %.spill220, align 32
  %6288 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6286, <8 x float> %6287
  store <8 x float> %6288, ptr %.spill220, align 32
  %6289 = select <8 x i1> %6223, <8 x float> %5897, <8 x float> splat (float 0xC6293E5940000000)
  %6290 = load <8 x float>, ptr %.spill221, align 32
  %6291 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6289, <8 x float> %6290
  store <8 x float> %6291, ptr %.spill221, align 32
  %6292 = select <8 x i1> %6235, <8 x float> %5898, <8 x float> splat (float 0xC6293E5940000000)
  %6293 = load <8 x float>, ptr %.spill222, align 32
  %6294 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6292, <8 x float> %6293
  store <8 x float> %6294, ptr %.spill222, align 32
  %6295 = select <8 x i1> %6058, <8 x float> %5899, <8 x float> splat (float 0xC6293E5940000000)
  %6296 = load <8 x float>, ptr %.spill223, align 32
  %6297 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6295, <8 x float> %6296
  store <8 x float> %6297, ptr %.spill223, align 32
  %6298 = select <8 x i1> %6070, <8 x float> %5900, <8 x float> splat (float 0xC6293E5940000000)
  %6299 = load <8 x float>, ptr %.spill224, align 32
  %6300 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6298, <8 x float> %6299
  store <8 x float> %6300, ptr %.spill224, align 32
  %6301 = select <8 x i1> %6082, <8 x float> %5901, <8 x float> splat (float 0xC6293E5940000000)
  %6302 = load <8 x float>, ptr %.spill225, align 32
  %6303 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6301, <8 x float> %6302
  store <8 x float> %6303, ptr %.spill225, align 32
  %6304 = select <8 x i1> %6094, <8 x float> %5902, <8 x float> splat (float 0xC6293E5940000000)
  %6305 = load <8 x float>, ptr %.spill226, align 32
  %6306 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6304, <8 x float> %6305
  store <8 x float> %6306, ptr %.spill226, align 32
  %6307 = select <8 x i1> %6106, <8 x float> %5903, <8 x float> splat (float 0xC6293E5940000000)
  %6308 = load <8 x float>, ptr %.spill227, align 32
  %6309 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6307, <8 x float> %6308
  store <8 x float> %6309, ptr %.spill227, align 32
  %6310 = select <8 x i1> %6118, <8 x float> %5904, <8 x float> splat (float 0xC6293E5940000000)
  %6311 = load <8 x float>, ptr %.spill228, align 32
  %6312 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6310, <8 x float> %6311
  store <8 x float> %6312, ptr %.spill228, align 32
  %6313 = select <8 x i1> %6130, <8 x float> %5905, <8 x float> splat (float 0xC6293E5940000000)
  %6314 = load <8 x float>, ptr %.spill229, align 32
  %6315 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6313, <8 x float> %6314
  store <8 x float> %6315, ptr %.spill229, align 32
  %6316 = select <8 x i1> %6142, <8 x float> %5906, <8 x float> splat (float 0xC6293E5940000000)
  %6317 = load <8 x float>, ptr %.spill230, align 32
  %6318 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6316, <8 x float> %6317
  store <8 x float> %6318, ptr %.spill230, align 32
  %6319 = select <8 x i1> %6154, <8 x float> %5907, <8 x float> splat (float 0xC6293E5940000000)
  %6320 = load <8 x float>, ptr %.spill231, align 32
  %6321 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6319, <8 x float> %6320
  store <8 x float> %6321, ptr %.spill231, align 32
  %6322 = select <8 x i1> %6166, <8 x float> %5908, <8 x float> splat (float 0xC6293E5940000000)
  %6323 = load <8 x float>, ptr %.spill232, align 32
  %6324 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6322, <8 x float> %6323
  store <8 x float> %6324, ptr %.spill232, align 32
  %6325 = select <8 x i1> %6178, <8 x float> %5909, <8 x float> splat (float 0xC6293E5940000000)
  %6326 = load <8 x float>, ptr %.spill233, align 32
  %6327 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6325, <8 x float> %6326
  store <8 x float> %6327, ptr %.spill233, align 32
  %6328 = select <8 x i1> %6190, <8 x float> %5910, <8 x float> splat (float 0xC6293E5940000000)
  %6329 = load <8 x float>, ptr %.spill234, align 32
  %6330 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6328, <8 x float> %6329
  store <8 x float> %6330, ptr %.spill234, align 32
  %6331 = select <8 x i1> %6202, <8 x float> %5911, <8 x float> splat (float 0xC6293E5940000000)
  %6332 = load <8 x float>, ptr %.spill235, align 32
  %6333 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6331, <8 x float> %6332
  store <8 x float> %6333, ptr %.spill235, align 32
  %6334 = select <8 x i1> %6214, <8 x float> %5912, <8 x float> splat (float 0xC6293E5940000000)
  %6335 = load <8 x float>, ptr %.spill236, align 32
  %6336 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6334, <8 x float> %6335
  store <8 x float> %6336, ptr %.spill236, align 32
  %6337 = select <8 x i1> %6226, <8 x float> %5913, <8 x float> splat (float 0xC6293E5940000000)
  %6338 = load <8 x float>, ptr %.spill237, align 32
  %6339 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6337, <8 x float> %6338
  store <8 x float> %6339, ptr %.spill237, align 32
  %6340 = select <8 x i1> %6238, <8 x float> %5914, <8 x float> splat (float 0xC6293E5940000000)
  %6341 = load <8 x float>, ptr %.spill238, align 32
  %6342 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6340, <8 x float> %6341
  store <8 x float> %6342, ptr %.spill238, align 32
  %6343 = select <8 x i1> %6061, <8 x float> %5915, <8 x float> splat (float 0xC6293E5940000000)
  %6344 = load <8 x float>, ptr %.spill239, align 32
  %6345 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6343, <8 x float> %6344
  store <8 x float> %6345, ptr %.spill239, align 32
  %6346 = select <8 x i1> %6073, <8 x float> %5916, <8 x float> splat (float 0xC6293E5940000000)
  %6347 = load <8 x float>, ptr %.spill240, align 32
  %6348 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6346, <8 x float> %6347
  store <8 x float> %6348, ptr %.spill240, align 32
  %6349 = select <8 x i1> %6085, <8 x float> %5917, <8 x float> splat (float 0xC6293E5940000000)
  %6350 = load <8 x float>, ptr %.spill241, align 32
  %6351 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6349, <8 x float> %6350
  store <8 x float> %6351, ptr %.spill241, align 32
  %6352 = select <8 x i1> %6097, <8 x float> %5918, <8 x float> splat (float 0xC6293E5940000000)
  %6353 = load <8 x float>, ptr %.spill242, align 32
  %6354 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6352, <8 x float> %6353
  store <8 x float> %6354, ptr %.spill242, align 32
  %6355 = select <8 x i1> %6109, <8 x float> %5919, <8 x float> splat (float 0xC6293E5940000000)
  %6356 = load <8 x float>, ptr %.spill243, align 32
  %6357 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6355, <8 x float> %6356
  store <8 x float> %6357, ptr %.spill243, align 32
  %6358 = select <8 x i1> %6121, <8 x float> %5920, <8 x float> splat (float 0xC6293E5940000000)
  %6359 = load <8 x float>, ptr %.spill244, align 32
  %6360 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6358, <8 x float> %6359
  store <8 x float> %6360, ptr %.spill244, align 32
  %6361 = select <8 x i1> %6133, <8 x float> %5921, <8 x float> splat (float 0xC6293E5940000000)
  %6362 = load <8 x float>, ptr %.spill245, align 32
  %6363 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6361, <8 x float> %6362
  store <8 x float> %6363, ptr %.spill245, align 32
  %6364 = select <8 x i1> %6145, <8 x float> %5922, <8 x float> splat (float 0xC6293E5940000000)
  %6365 = load <8 x float>, ptr %.spill246, align 32
  %6366 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6364, <8 x float> %6365
  store <8 x float> %6366, ptr %.spill246, align 32
  %6367 = select <8 x i1> %6157, <8 x float> %5923, <8 x float> splat (float 0xC6293E5940000000)
  %6368 = load <8 x float>, ptr %.spill247, align 32
  %6369 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6367, <8 x float> %6368
  store <8 x float> %6369, ptr %.spill247, align 32
  %6370 = select <8 x i1> %6169, <8 x float> %5924, <8 x float> splat (float 0xC6293E5940000000)
  %6371 = load <8 x float>, ptr %.spill248, align 32
  %6372 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6370, <8 x float> %6371
  store <8 x float> %6372, ptr %.spill248, align 32
  %6373 = select <8 x i1> %6181, <8 x float> %5925, <8 x float> splat (float 0xC6293E5940000000)
  %6374 = load <8 x float>, ptr %.spill249, align 32
  %6375 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6373, <8 x float> %6374
  store <8 x float> %6375, ptr %.spill249, align 32
  %6376 = select <8 x i1> %6193, <8 x float> %5926, <8 x float> splat (float 0xC6293E5940000000)
  %6377 = load <8 x float>, ptr %.spill250, align 32
  %6378 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6376, <8 x float> %6377
  store <8 x float> %6378, ptr %.spill250, align 32
  %6379 = select <8 x i1> %6205, <8 x float> %5927, <8 x float> splat (float 0xC6293E5940000000)
  %6380 = load <8 x float>, ptr %.spill251, align 32
  %6381 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6379, <8 x float> %6380
  store <8 x float> %6381, ptr %.spill251, align 32
  %6382 = select <8 x i1> %6217, <8 x float> %5928, <8 x float> splat (float 0xC6293E5940000000)
  %6383 = load <8 x float>, ptr %.spill252, align 32
  %6384 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6382, <8 x float> %6383
  store <8 x float> %6384, ptr %.spill252, align 32
  %6385 = select <8 x i1> %6229, <8 x float> %5929, <8 x float> splat (float 0xC6293E5940000000)
  %6386 = load <8 x float>, ptr %.spill253, align 32
  %6387 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6385, <8 x float> %6386
  store <8 x float> %6387, ptr %.spill253, align 32
  %6388 = select <8 x i1> %6241, <8 x float> %5930, <8 x float> splat (float 0xC6293E5940000000)
  %6389 = load <8 x float>, ptr %.spill254, align 32
  %6390 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6388, <8 x float> %6389
  store <8 x float> %6390, ptr %.spill254, align 32
  %6391 = select <8 x i1> %6064, <8 x float> %5931, <8 x float> splat (float 0xC6293E5940000000)
  %6392 = load <8 x float>, ptr %.spill255, align 32
  %6393 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6391, <8 x float> %6392
  store <8 x float> %6393, ptr %.spill255, align 32
  %6394 = select <8 x i1> %6076, <8 x float> %5932, <8 x float> splat (float 0xC6293E5940000000)
  %6395 = load <8 x float>, ptr %.spill256, align 32
  %6396 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6394, <8 x float> %6395
  store <8 x float> %6396, ptr %.spill256, align 32
  %6397 = select <8 x i1> %6088, <8 x float> %5933, <8 x float> splat (float 0xC6293E5940000000)
  %6398 = load <8 x float>, ptr %.spill257, align 32
  %6399 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6397, <8 x float> %6398
  store <8 x float> %6399, ptr %.spill257, align 32
  %6400 = select <8 x i1> %6100, <8 x float> %5934, <8 x float> splat (float 0xC6293E5940000000)
  %6401 = load <8 x float>, ptr %.spill258, align 32
  %6402 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6400, <8 x float> %6401
  store <8 x float> %6402, ptr %.spill258, align 32
  %6403 = select <8 x i1> %6112, <8 x float> %5935, <8 x float> splat (float 0xC6293E5940000000)
  %6404 = load <8 x float>, ptr %.spill259, align 32
  %6405 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6403, <8 x float> %6404
  store <8 x float> %6405, ptr %.spill259, align 32
  %6406 = select <8 x i1> %6124, <8 x float> %5936, <8 x float> splat (float 0xC6293E5940000000)
  %6407 = load <8 x float>, ptr %.spill260, align 32
  %6408 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6406, <8 x float> %6407
  store <8 x float> %6408, ptr %.spill260, align 32
  %6409 = select <8 x i1> %6136, <8 x float> %5937, <8 x float> splat (float 0xC6293E5940000000)
  %6410 = load <8 x float>, ptr %.spill261, align 32
  %6411 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6409, <8 x float> %6410
  store <8 x float> %6411, ptr %.spill261, align 32
  %6412 = select <8 x i1> %6148, <8 x float> %5938, <8 x float> splat (float 0xC6293E5940000000)
  %6413 = load <8 x float>, ptr %.spill262, align 32
  %6414 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6412, <8 x float> %6413
  store <8 x float> %6414, ptr %.spill262, align 32
  %6415 = select <8 x i1> %6160, <8 x float> %5939, <8 x float> splat (float 0xC6293E5940000000)
  %6416 = load <8 x float>, ptr %.spill263, align 32
  %6417 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6415, <8 x float> %6416
  store <8 x float> %6417, ptr %.spill263, align 32
  %6418 = select <8 x i1> %6172, <8 x float> %5940, <8 x float> splat (float 0xC6293E5940000000)
  %6419 = load <8 x float>, ptr %.spill264, align 32
  %6420 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6418, <8 x float> %6419
  store <8 x float> %6420, ptr %.spill264, align 32
  %6421 = select <8 x i1> %6184, <8 x float> %5941, <8 x float> splat (float 0xC6293E5940000000)
  %6422 = load <8 x float>, ptr %.spill265, align 32
  %6423 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6421, <8 x float> %6422
  store <8 x float> %6423, ptr %.spill265, align 32
  %6424 = select <8 x i1> %6196, <8 x float> %5942, <8 x float> splat (float 0xC6293E5940000000)
  %6425 = load <8 x float>, ptr %.spill266, align 32
  %6426 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6424, <8 x float> %6425
  store <8 x float> %6426, ptr %.spill266, align 32
  %6427 = select <8 x i1> %6208, <8 x float> %5943, <8 x float> splat (float 0xC6293E5940000000)
  %6428 = load <8 x float>, ptr %.spill267, align 32
  %6429 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6427, <8 x float> %6428
  store <8 x float> %6429, ptr %.spill267, align 32
  %6430 = select <8 x i1> %6220, <8 x float> %5944, <8 x float> splat (float 0xC6293E5940000000)
  %6431 = load <8 x float>, ptr %.spill268, align 32
  %6432 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6430, <8 x float> %6431
  store <8 x float> %6432, ptr %.spill268, align 32
  %6433 = select <8 x i1> %6232, <8 x float> %5945, <8 x float> splat (float 0xC6293E5940000000)
  %6434 = load <8 x float>, ptr %.spill269, align 32
  %6435 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6433, <8 x float> %6434
  store <8 x float> %6435, ptr %.spill269, align 32
  %6436 = select <8 x i1> %6244, <8 x float> %5946, <8 x float> splat (float 0xC6293E5940000000)
  %6437 = load <8 x float>, ptr %.spill270, align 32
  %6438 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6436, <8 x float> %6437
  store <8 x float> %6438, ptr %.spill270, align 32
  %6439 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %6440 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6441 = extractvalue { <8 x ptr>, <8 x i64> } %6439, 0
  %6442 = select <8 x i1> %convergence.cascade.result1188, <8 x ptr> %6440, <8 x ptr> %6441
  %6443 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6444 = extractvalue { <8 x ptr>, <8 x i64> } %6439, 1
  %6445 = select <8 x i1> %convergence.cascade.result1188, <8 x i64> %6443, <8 x i64> %6444
  %6446 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6442, 0
  %6447 = insertvalue { <8 x ptr>, <8 x i64> } %6446, <8 x i64> %6445, 1
  store { <8 x ptr>, <8 x i64> } %6447, ptr %tile_snapshot.spill271, align 64
  %6448 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6449 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6450 = add <8 x i64> %6449, zeroinitializer
  %6451 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6448, 0
  %6452 = insertvalue { <8 x ptr>, <8 x i64> } %6451, <8 x i64> %6450, 1
  %6453 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6454 = extractvalue { <8 x ptr>, <8 x i64> } %6452, 1
  %6455 = extractelement <8 x ptr> %6453, i32 0
  %6456 = extractelement <8 x i64> %6454, i32 %5882
  %6457 = zext i32 %5882 to i64
  %6458 = mul i64 %6457, 4
  %6459 = sub i64 %6456, %6458
  %6460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6461 = select i1 %6460, i64 %6459, i64 0
  %private.contiguous.address = getelementptr i8, ptr %6455, i64 %6461
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %6462 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6247, <8 x float> %private.contiguous.preserve
  store <8 x float> %6462, ptr %private.contiguous.address, align 4
  %6463 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6464 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6465 = add <8 x i64> %6464, splat (i64 32)
  %6466 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6463, 0
  %6467 = insertvalue { <8 x ptr>, <8 x i64> } %6466, <8 x i64> %6465, 1
  %6468 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6469 = extractvalue { <8 x ptr>, <8 x i64> } %6467, 1
  %6470 = extractelement <8 x ptr> %6468, i32 0
  %6471 = extractelement <8 x i64> %6469, i32 %5882
  %6472 = zext i32 %5882 to i64
  %6473 = mul i64 %6472, 4
  %6474 = sub i64 %6471, %6473
  %6475 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6476 = select i1 %6475, i64 %6474, i64 0
  %private.contiguous.address1273 = getelementptr i8, ptr %6470, i64 %6476
  %private.contiguous.preserve1274 = load <8 x float>, ptr %private.contiguous.address1273, align 4
  %6477 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6250, <8 x float> %private.contiguous.preserve1274
  store <8 x float> %6477, ptr %private.contiguous.address1273, align 4
  %6478 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6479 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6480 = add <8 x i64> %6479, splat (i64 64)
  %6481 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6478, 0
  %6482 = insertvalue { <8 x ptr>, <8 x i64> } %6481, <8 x i64> %6480, 1
  %6483 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6484 = extractvalue { <8 x ptr>, <8 x i64> } %6482, 1
  %6485 = extractelement <8 x ptr> %6483, i32 0
  %6486 = extractelement <8 x i64> %6484, i32 %5882
  %6487 = zext i32 %5882 to i64
  %6488 = mul i64 %6487, 4
  %6489 = sub i64 %6486, %6488
  %6490 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6491 = select i1 %6490, i64 %6489, i64 0
  %private.contiguous.address1275 = getelementptr i8, ptr %6485, i64 %6491
  %private.contiguous.preserve1276 = load <8 x float>, ptr %private.contiguous.address1275, align 4
  %6492 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6253, <8 x float> %private.contiguous.preserve1276
  store <8 x float> %6492, ptr %private.contiguous.address1275, align 4
  %6493 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6494 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6495 = add <8 x i64> %6494, splat (i64 96)
  %6496 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6493, 0
  %6497 = insertvalue { <8 x ptr>, <8 x i64> } %6496, <8 x i64> %6495, 1
  %6498 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6499 = extractvalue { <8 x ptr>, <8 x i64> } %6497, 1
  %6500 = extractelement <8 x ptr> %6498, i32 0
  %6501 = extractelement <8 x i64> %6499, i32 %5882
  %6502 = zext i32 %5882 to i64
  %6503 = mul i64 %6502, 4
  %6504 = sub i64 %6501, %6503
  %6505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6506 = select i1 %6505, i64 %6504, i64 0
  %private.contiguous.address1277 = getelementptr i8, ptr %6500, i64 %6506
  %private.contiguous.preserve1278 = load <8 x float>, ptr %private.contiguous.address1277, align 4
  %6507 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6256, <8 x float> %private.contiguous.preserve1278
  store <8 x float> %6507, ptr %private.contiguous.address1277, align 4
  %6508 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6509 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6510 = add <8 x i64> %6509, splat (i64 128)
  %6511 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6508, 0
  %6512 = insertvalue { <8 x ptr>, <8 x i64> } %6511, <8 x i64> %6510, 1
  %6513 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6514 = extractvalue { <8 x ptr>, <8 x i64> } %6512, 1
  %6515 = extractelement <8 x ptr> %6513, i32 0
  %6516 = extractelement <8 x i64> %6514, i32 %5882
  %6517 = zext i32 %5882 to i64
  %6518 = mul i64 %6517, 4
  %6519 = sub i64 %6516, %6518
  %6520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6521 = select i1 %6520, i64 %6519, i64 0
  %private.contiguous.address1279 = getelementptr i8, ptr %6515, i64 %6521
  %private.contiguous.preserve1280 = load <8 x float>, ptr %private.contiguous.address1279, align 4
  %6522 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6259, <8 x float> %private.contiguous.preserve1280
  store <8 x float> %6522, ptr %private.contiguous.address1279, align 4
  %6523 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6524 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6525 = add <8 x i64> %6524, splat (i64 160)
  %6526 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6523, 0
  %6527 = insertvalue { <8 x ptr>, <8 x i64> } %6526, <8 x i64> %6525, 1
  %6528 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6529 = extractvalue { <8 x ptr>, <8 x i64> } %6527, 1
  %6530 = extractelement <8 x ptr> %6528, i32 0
  %6531 = extractelement <8 x i64> %6529, i32 %5882
  %6532 = zext i32 %5882 to i64
  %6533 = mul i64 %6532, 4
  %6534 = sub i64 %6531, %6533
  %6535 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6536 = select i1 %6535, i64 %6534, i64 0
  %private.contiguous.address1281 = getelementptr i8, ptr %6530, i64 %6536
  %private.contiguous.preserve1282 = load <8 x float>, ptr %private.contiguous.address1281, align 4
  %6537 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6262, <8 x float> %private.contiguous.preserve1282
  store <8 x float> %6537, ptr %private.contiguous.address1281, align 4
  %6538 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6539 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6540 = add <8 x i64> %6539, splat (i64 192)
  %6541 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6538, 0
  %6542 = insertvalue { <8 x ptr>, <8 x i64> } %6541, <8 x i64> %6540, 1
  %6543 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6544 = extractvalue { <8 x ptr>, <8 x i64> } %6542, 1
  %6545 = extractelement <8 x ptr> %6543, i32 0
  %6546 = extractelement <8 x i64> %6544, i32 %5882
  %6547 = zext i32 %5882 to i64
  %6548 = mul i64 %6547, 4
  %6549 = sub i64 %6546, %6548
  %6550 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6551 = select i1 %6550, i64 %6549, i64 0
  %private.contiguous.address1283 = getelementptr i8, ptr %6545, i64 %6551
  %private.contiguous.preserve1284 = load <8 x float>, ptr %private.contiguous.address1283, align 4
  %6552 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6265, <8 x float> %private.contiguous.preserve1284
  store <8 x float> %6552, ptr %private.contiguous.address1283, align 4
  %6553 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6554 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6555 = add <8 x i64> %6554, splat (i64 224)
  %6556 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6553, 0
  %6557 = insertvalue { <8 x ptr>, <8 x i64> } %6556, <8 x i64> %6555, 1
  %6558 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6559 = extractvalue { <8 x ptr>, <8 x i64> } %6557, 1
  %6560 = extractelement <8 x ptr> %6558, i32 0
  %6561 = extractelement <8 x i64> %6559, i32 %5882
  %6562 = zext i32 %5882 to i64
  %6563 = mul i64 %6562, 4
  %6564 = sub i64 %6561, %6563
  %6565 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6566 = select i1 %6565, i64 %6564, i64 0
  %private.contiguous.address1285 = getelementptr i8, ptr %6560, i64 %6566
  %private.contiguous.preserve1286 = load <8 x float>, ptr %private.contiguous.address1285, align 4
  %6567 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6268, <8 x float> %private.contiguous.preserve1286
  store <8 x float> %6567, ptr %private.contiguous.address1285, align 4
  %6568 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6569 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6570 = add <8 x i64> %6569, splat (i64 256)
  %6571 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6568, 0
  %6572 = insertvalue { <8 x ptr>, <8 x i64> } %6571, <8 x i64> %6570, 1
  %6573 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6574 = extractvalue { <8 x ptr>, <8 x i64> } %6572, 1
  %6575 = extractelement <8 x ptr> %6573, i32 0
  %6576 = extractelement <8 x i64> %6574, i32 %5882
  %6577 = zext i32 %5882 to i64
  %6578 = mul i64 %6577, 4
  %6579 = sub i64 %6576, %6578
  %6580 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6581 = select i1 %6580, i64 %6579, i64 0
  %private.contiguous.address1287 = getelementptr i8, ptr %6575, i64 %6581
  %private.contiguous.preserve1288 = load <8 x float>, ptr %private.contiguous.address1287, align 4
  %6582 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6271, <8 x float> %private.contiguous.preserve1288
  store <8 x float> %6582, ptr %private.contiguous.address1287, align 4
  %6583 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6584 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6585 = add <8 x i64> %6584, splat (i64 288)
  %6586 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6583, 0
  %6587 = insertvalue { <8 x ptr>, <8 x i64> } %6586, <8 x i64> %6585, 1
  %6588 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6589 = extractvalue { <8 x ptr>, <8 x i64> } %6587, 1
  %6590 = extractelement <8 x ptr> %6588, i32 0
  %6591 = extractelement <8 x i64> %6589, i32 %5882
  %6592 = zext i32 %5882 to i64
  %6593 = mul i64 %6592, 4
  %6594 = sub i64 %6591, %6593
  %6595 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6596 = select i1 %6595, i64 %6594, i64 0
  %private.contiguous.address1289 = getelementptr i8, ptr %6590, i64 %6596
  %private.contiguous.preserve1290 = load <8 x float>, ptr %private.contiguous.address1289, align 4
  %6597 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6274, <8 x float> %private.contiguous.preserve1290
  store <8 x float> %6597, ptr %private.contiguous.address1289, align 4
  %6598 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6599 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6600 = add <8 x i64> %6599, splat (i64 320)
  %6601 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6598, 0
  %6602 = insertvalue { <8 x ptr>, <8 x i64> } %6601, <8 x i64> %6600, 1
  %6603 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6604 = extractvalue { <8 x ptr>, <8 x i64> } %6602, 1
  %6605 = extractelement <8 x ptr> %6603, i32 0
  %6606 = extractelement <8 x i64> %6604, i32 %5882
  %6607 = zext i32 %5882 to i64
  %6608 = mul i64 %6607, 4
  %6609 = sub i64 %6606, %6608
  %6610 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6611 = select i1 %6610, i64 %6609, i64 0
  %private.contiguous.address1291 = getelementptr i8, ptr %6605, i64 %6611
  %private.contiguous.preserve1292 = load <8 x float>, ptr %private.contiguous.address1291, align 4
  %6612 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6277, <8 x float> %private.contiguous.preserve1292
  store <8 x float> %6612, ptr %private.contiguous.address1291, align 4
  %6613 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6614 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6615 = add <8 x i64> %6614, splat (i64 352)
  %6616 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6613, 0
  %6617 = insertvalue { <8 x ptr>, <8 x i64> } %6616, <8 x i64> %6615, 1
  %6618 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6619 = extractvalue { <8 x ptr>, <8 x i64> } %6617, 1
  %6620 = extractelement <8 x ptr> %6618, i32 0
  %6621 = extractelement <8 x i64> %6619, i32 %5882
  %6622 = zext i32 %5882 to i64
  %6623 = mul i64 %6622, 4
  %6624 = sub i64 %6621, %6623
  %6625 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6626 = select i1 %6625, i64 %6624, i64 0
  %private.contiguous.address1293 = getelementptr i8, ptr %6620, i64 %6626
  %private.contiguous.preserve1294 = load <8 x float>, ptr %private.contiguous.address1293, align 4
  %6627 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6280, <8 x float> %private.contiguous.preserve1294
  store <8 x float> %6627, ptr %private.contiguous.address1293, align 4
  %6628 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6629 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6630 = add <8 x i64> %6629, splat (i64 384)
  %6631 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6628, 0
  %6632 = insertvalue { <8 x ptr>, <8 x i64> } %6631, <8 x i64> %6630, 1
  %6633 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6634 = extractvalue { <8 x ptr>, <8 x i64> } %6632, 1
  %6635 = extractelement <8 x ptr> %6633, i32 0
  %6636 = extractelement <8 x i64> %6634, i32 %5882
  %6637 = zext i32 %5882 to i64
  %6638 = mul i64 %6637, 4
  %6639 = sub i64 %6636, %6638
  %6640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6641 = select i1 %6640, i64 %6639, i64 0
  %private.contiguous.address1295 = getelementptr i8, ptr %6635, i64 %6641
  %private.contiguous.preserve1296 = load <8 x float>, ptr %private.contiguous.address1295, align 4
  %6642 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6283, <8 x float> %private.contiguous.preserve1296
  store <8 x float> %6642, ptr %private.contiguous.address1295, align 4
  %6643 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6644 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6645 = add <8 x i64> %6644, splat (i64 416)
  %6646 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6643, 0
  %6647 = insertvalue { <8 x ptr>, <8 x i64> } %6646, <8 x i64> %6645, 1
  %6648 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6649 = extractvalue { <8 x ptr>, <8 x i64> } %6647, 1
  %6650 = extractelement <8 x ptr> %6648, i32 0
  %6651 = extractelement <8 x i64> %6649, i32 %5882
  %6652 = zext i32 %5882 to i64
  %6653 = mul i64 %6652, 4
  %6654 = sub i64 %6651, %6653
  %6655 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6656 = select i1 %6655, i64 %6654, i64 0
  %private.contiguous.address1297 = getelementptr i8, ptr %6650, i64 %6656
  %private.contiguous.preserve1298 = load <8 x float>, ptr %private.contiguous.address1297, align 4
  %6657 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6286, <8 x float> %private.contiguous.preserve1298
  store <8 x float> %6657, ptr %private.contiguous.address1297, align 4
  %6658 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6659 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6660 = add <8 x i64> %6659, splat (i64 448)
  %6661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6658, 0
  %6662 = insertvalue { <8 x ptr>, <8 x i64> } %6661, <8 x i64> %6660, 1
  %6663 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6664 = extractvalue { <8 x ptr>, <8 x i64> } %6662, 1
  %6665 = extractelement <8 x ptr> %6663, i32 0
  %6666 = extractelement <8 x i64> %6664, i32 %5882
  %6667 = zext i32 %5882 to i64
  %6668 = mul i64 %6667, 4
  %6669 = sub i64 %6666, %6668
  %6670 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6671 = select i1 %6670, i64 %6669, i64 0
  %private.contiguous.address1299 = getelementptr i8, ptr %6665, i64 %6671
  %private.contiguous.preserve1300 = load <8 x float>, ptr %private.contiguous.address1299, align 4
  %6672 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6289, <8 x float> %private.contiguous.preserve1300
  store <8 x float> %6672, ptr %private.contiguous.address1299, align 4
  %6673 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6674 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6675 = add <8 x i64> %6674, splat (i64 480)
  %6676 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6673, 0
  %6677 = insertvalue { <8 x ptr>, <8 x i64> } %6676, <8 x i64> %6675, 1
  %6678 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6679 = extractvalue { <8 x ptr>, <8 x i64> } %6677, 1
  %6680 = extractelement <8 x ptr> %6678, i32 0
  %6681 = extractelement <8 x i64> %6679, i32 %5882
  %6682 = zext i32 %5882 to i64
  %6683 = mul i64 %6682, 4
  %6684 = sub i64 %6681, %6683
  %6685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6686 = select i1 %6685, i64 %6684, i64 0
  %private.contiguous.address1301 = getelementptr i8, ptr %6680, i64 %6686
  %private.contiguous.preserve1302 = load <8 x float>, ptr %private.contiguous.address1301, align 4
  %6687 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6292, <8 x float> %private.contiguous.preserve1302
  store <8 x float> %6687, ptr %private.contiguous.address1301, align 4
  %6688 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6689 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6690 = add <8 x i64> %6689, splat (i64 512)
  %6691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6688, 0
  %6692 = insertvalue { <8 x ptr>, <8 x i64> } %6691, <8 x i64> %6690, 1
  %6693 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6694 = extractvalue { <8 x ptr>, <8 x i64> } %6692, 1
  %6695 = extractelement <8 x ptr> %6693, i32 0
  %6696 = extractelement <8 x i64> %6694, i32 %5882
  %6697 = zext i32 %5882 to i64
  %6698 = mul i64 %6697, 4
  %6699 = sub i64 %6696, %6698
  %6700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6701 = select i1 %6700, i64 %6699, i64 0
  %private.contiguous.address1303 = getelementptr i8, ptr %6695, i64 %6701
  %private.contiguous.preserve1304 = load <8 x float>, ptr %private.contiguous.address1303, align 4
  %6702 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6295, <8 x float> %private.contiguous.preserve1304
  store <8 x float> %6702, ptr %private.contiguous.address1303, align 4
  %6703 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6704 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6705 = add <8 x i64> %6704, splat (i64 544)
  %6706 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6703, 0
  %6707 = insertvalue { <8 x ptr>, <8 x i64> } %6706, <8 x i64> %6705, 1
  %6708 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6709 = extractvalue { <8 x ptr>, <8 x i64> } %6707, 1
  %6710 = extractelement <8 x ptr> %6708, i32 0
  %6711 = extractelement <8 x i64> %6709, i32 %5882
  %6712 = zext i32 %5882 to i64
  %6713 = mul i64 %6712, 4
  %6714 = sub i64 %6711, %6713
  %6715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6716 = select i1 %6715, i64 %6714, i64 0
  %private.contiguous.address1305 = getelementptr i8, ptr %6710, i64 %6716
  %private.contiguous.preserve1306 = load <8 x float>, ptr %private.contiguous.address1305, align 4
  %6717 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6298, <8 x float> %private.contiguous.preserve1306
  store <8 x float> %6717, ptr %private.contiguous.address1305, align 4
  %6718 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6719 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6720 = add <8 x i64> %6719, splat (i64 576)
  %6721 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6718, 0
  %6722 = insertvalue { <8 x ptr>, <8 x i64> } %6721, <8 x i64> %6720, 1
  %6723 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6724 = extractvalue { <8 x ptr>, <8 x i64> } %6722, 1
  %6725 = extractelement <8 x ptr> %6723, i32 0
  %6726 = extractelement <8 x i64> %6724, i32 %5882
  %6727 = zext i32 %5882 to i64
  %6728 = mul i64 %6727, 4
  %6729 = sub i64 %6726, %6728
  %6730 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6731 = select i1 %6730, i64 %6729, i64 0
  %private.contiguous.address1307 = getelementptr i8, ptr %6725, i64 %6731
  %private.contiguous.preserve1308 = load <8 x float>, ptr %private.contiguous.address1307, align 4
  %6732 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6301, <8 x float> %private.contiguous.preserve1308
  store <8 x float> %6732, ptr %private.contiguous.address1307, align 4
  %6733 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6734 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6735 = add <8 x i64> %6734, splat (i64 608)
  %6736 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6733, 0
  %6737 = insertvalue { <8 x ptr>, <8 x i64> } %6736, <8 x i64> %6735, 1
  %6738 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6739 = extractvalue { <8 x ptr>, <8 x i64> } %6737, 1
  %6740 = extractelement <8 x ptr> %6738, i32 0
  %6741 = extractelement <8 x i64> %6739, i32 %5882
  %6742 = zext i32 %5882 to i64
  %6743 = mul i64 %6742, 4
  %6744 = sub i64 %6741, %6743
  %6745 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6746 = select i1 %6745, i64 %6744, i64 0
  %private.contiguous.address1309 = getelementptr i8, ptr %6740, i64 %6746
  %private.contiguous.preserve1310 = load <8 x float>, ptr %private.contiguous.address1309, align 4
  %6747 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6304, <8 x float> %private.contiguous.preserve1310
  store <8 x float> %6747, ptr %private.contiguous.address1309, align 4
  %6748 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6749 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6750 = add <8 x i64> %6749, splat (i64 640)
  %6751 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6748, 0
  %6752 = insertvalue { <8 x ptr>, <8 x i64> } %6751, <8 x i64> %6750, 1
  %6753 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6754 = extractvalue { <8 x ptr>, <8 x i64> } %6752, 1
  %6755 = extractelement <8 x ptr> %6753, i32 0
  %6756 = extractelement <8 x i64> %6754, i32 %5882
  %6757 = zext i32 %5882 to i64
  %6758 = mul i64 %6757, 4
  %6759 = sub i64 %6756, %6758
  %6760 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6761 = select i1 %6760, i64 %6759, i64 0
  %private.contiguous.address1311 = getelementptr i8, ptr %6755, i64 %6761
  %private.contiguous.preserve1312 = load <8 x float>, ptr %private.contiguous.address1311, align 4
  %6762 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6307, <8 x float> %private.contiguous.preserve1312
  store <8 x float> %6762, ptr %private.contiguous.address1311, align 4
  %6763 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6764 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6765 = add <8 x i64> %6764, splat (i64 672)
  %6766 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6763, 0
  %6767 = insertvalue { <8 x ptr>, <8 x i64> } %6766, <8 x i64> %6765, 1
  %6768 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6769 = extractvalue { <8 x ptr>, <8 x i64> } %6767, 1
  %6770 = extractelement <8 x ptr> %6768, i32 0
  %6771 = extractelement <8 x i64> %6769, i32 %5882
  %6772 = zext i32 %5882 to i64
  %6773 = mul i64 %6772, 4
  %6774 = sub i64 %6771, %6773
  %6775 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6776 = select i1 %6775, i64 %6774, i64 0
  %private.contiguous.address1313 = getelementptr i8, ptr %6770, i64 %6776
  %private.contiguous.preserve1314 = load <8 x float>, ptr %private.contiguous.address1313, align 4
  %6777 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6310, <8 x float> %private.contiguous.preserve1314
  store <8 x float> %6777, ptr %private.contiguous.address1313, align 4
  %6778 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6779 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6780 = add <8 x i64> %6779, splat (i64 704)
  %6781 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6778, 0
  %6782 = insertvalue { <8 x ptr>, <8 x i64> } %6781, <8 x i64> %6780, 1
  %6783 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6784 = extractvalue { <8 x ptr>, <8 x i64> } %6782, 1
  %6785 = extractelement <8 x ptr> %6783, i32 0
  %6786 = extractelement <8 x i64> %6784, i32 %5882
  %6787 = zext i32 %5882 to i64
  %6788 = mul i64 %6787, 4
  %6789 = sub i64 %6786, %6788
  %6790 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6791 = select i1 %6790, i64 %6789, i64 0
  %private.contiguous.address1315 = getelementptr i8, ptr %6785, i64 %6791
  %private.contiguous.preserve1316 = load <8 x float>, ptr %private.contiguous.address1315, align 4
  %6792 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6313, <8 x float> %private.contiguous.preserve1316
  store <8 x float> %6792, ptr %private.contiguous.address1315, align 4
  %6793 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6794 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6795 = add <8 x i64> %6794, splat (i64 736)
  %6796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6793, 0
  %6797 = insertvalue { <8 x ptr>, <8 x i64> } %6796, <8 x i64> %6795, 1
  %6798 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6799 = extractvalue { <8 x ptr>, <8 x i64> } %6797, 1
  %6800 = extractelement <8 x ptr> %6798, i32 0
  %6801 = extractelement <8 x i64> %6799, i32 %5882
  %6802 = zext i32 %5882 to i64
  %6803 = mul i64 %6802, 4
  %6804 = sub i64 %6801, %6803
  %6805 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6806 = select i1 %6805, i64 %6804, i64 0
  %private.contiguous.address1317 = getelementptr i8, ptr %6800, i64 %6806
  %private.contiguous.preserve1318 = load <8 x float>, ptr %private.contiguous.address1317, align 4
  %6807 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6316, <8 x float> %private.contiguous.preserve1318
  store <8 x float> %6807, ptr %private.contiguous.address1317, align 4
  %6808 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6809 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6810 = add <8 x i64> %6809, splat (i64 768)
  %6811 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6808, 0
  %6812 = insertvalue { <8 x ptr>, <8 x i64> } %6811, <8 x i64> %6810, 1
  %6813 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6814 = extractvalue { <8 x ptr>, <8 x i64> } %6812, 1
  %6815 = extractelement <8 x ptr> %6813, i32 0
  %6816 = extractelement <8 x i64> %6814, i32 %5882
  %6817 = zext i32 %5882 to i64
  %6818 = mul i64 %6817, 4
  %6819 = sub i64 %6816, %6818
  %6820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6821 = select i1 %6820, i64 %6819, i64 0
  %private.contiguous.address1319 = getelementptr i8, ptr %6815, i64 %6821
  %private.contiguous.preserve1320 = load <8 x float>, ptr %private.contiguous.address1319, align 4
  %6822 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6319, <8 x float> %private.contiguous.preserve1320
  store <8 x float> %6822, ptr %private.contiguous.address1319, align 4
  %6823 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6824 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6825 = add <8 x i64> %6824, splat (i64 800)
  %6826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6823, 0
  %6827 = insertvalue { <8 x ptr>, <8 x i64> } %6826, <8 x i64> %6825, 1
  %6828 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6829 = extractvalue { <8 x ptr>, <8 x i64> } %6827, 1
  %6830 = extractelement <8 x ptr> %6828, i32 0
  %6831 = extractelement <8 x i64> %6829, i32 %5882
  %6832 = zext i32 %5882 to i64
  %6833 = mul i64 %6832, 4
  %6834 = sub i64 %6831, %6833
  %6835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6836 = select i1 %6835, i64 %6834, i64 0
  %private.contiguous.address1321 = getelementptr i8, ptr %6830, i64 %6836
  %private.contiguous.preserve1322 = load <8 x float>, ptr %private.contiguous.address1321, align 4
  %6837 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6322, <8 x float> %private.contiguous.preserve1322
  store <8 x float> %6837, ptr %private.contiguous.address1321, align 4
  %6838 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6839 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6840 = add <8 x i64> %6839, splat (i64 832)
  %6841 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6838, 0
  %6842 = insertvalue { <8 x ptr>, <8 x i64> } %6841, <8 x i64> %6840, 1
  %6843 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6844 = extractvalue { <8 x ptr>, <8 x i64> } %6842, 1
  %6845 = extractelement <8 x ptr> %6843, i32 0
  %6846 = extractelement <8 x i64> %6844, i32 %5882
  %6847 = zext i32 %5882 to i64
  %6848 = mul i64 %6847, 4
  %6849 = sub i64 %6846, %6848
  %6850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6851 = select i1 %6850, i64 %6849, i64 0
  %private.contiguous.address1323 = getelementptr i8, ptr %6845, i64 %6851
  %private.contiguous.preserve1324 = load <8 x float>, ptr %private.contiguous.address1323, align 4
  %6852 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6325, <8 x float> %private.contiguous.preserve1324
  store <8 x float> %6852, ptr %private.contiguous.address1323, align 4
  %6853 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6854 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6855 = add <8 x i64> %6854, splat (i64 864)
  %6856 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6853, 0
  %6857 = insertvalue { <8 x ptr>, <8 x i64> } %6856, <8 x i64> %6855, 1
  %6858 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6859 = extractvalue { <8 x ptr>, <8 x i64> } %6857, 1
  %6860 = extractelement <8 x ptr> %6858, i32 0
  %6861 = extractelement <8 x i64> %6859, i32 %5882
  %6862 = zext i32 %5882 to i64
  %6863 = mul i64 %6862, 4
  %6864 = sub i64 %6861, %6863
  %6865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6866 = select i1 %6865, i64 %6864, i64 0
  %private.contiguous.address1325 = getelementptr i8, ptr %6860, i64 %6866
  %private.contiguous.preserve1326 = load <8 x float>, ptr %private.contiguous.address1325, align 4
  %6867 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6328, <8 x float> %private.contiguous.preserve1326
  store <8 x float> %6867, ptr %private.contiguous.address1325, align 4
  %6868 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6869 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6870 = add <8 x i64> %6869, splat (i64 896)
  %6871 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6868, 0
  %6872 = insertvalue { <8 x ptr>, <8 x i64> } %6871, <8 x i64> %6870, 1
  %6873 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6874 = extractvalue { <8 x ptr>, <8 x i64> } %6872, 1
  %6875 = extractelement <8 x ptr> %6873, i32 0
  %6876 = extractelement <8 x i64> %6874, i32 %5882
  %6877 = zext i32 %5882 to i64
  %6878 = mul i64 %6877, 4
  %6879 = sub i64 %6876, %6878
  %6880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6881 = select i1 %6880, i64 %6879, i64 0
  %private.contiguous.address1327 = getelementptr i8, ptr %6875, i64 %6881
  %private.contiguous.preserve1328 = load <8 x float>, ptr %private.contiguous.address1327, align 4
  %6882 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6331, <8 x float> %private.contiguous.preserve1328
  store <8 x float> %6882, ptr %private.contiguous.address1327, align 4
  %6883 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6884 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6885 = add <8 x i64> %6884, splat (i64 928)
  %6886 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6883, 0
  %6887 = insertvalue { <8 x ptr>, <8 x i64> } %6886, <8 x i64> %6885, 1
  %6888 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6889 = extractvalue { <8 x ptr>, <8 x i64> } %6887, 1
  %6890 = extractelement <8 x ptr> %6888, i32 0
  %6891 = extractelement <8 x i64> %6889, i32 %5882
  %6892 = zext i32 %5882 to i64
  %6893 = mul i64 %6892, 4
  %6894 = sub i64 %6891, %6893
  %6895 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6896 = select i1 %6895, i64 %6894, i64 0
  %private.contiguous.address1329 = getelementptr i8, ptr %6890, i64 %6896
  %private.contiguous.preserve1330 = load <8 x float>, ptr %private.contiguous.address1329, align 4
  %6897 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6334, <8 x float> %private.contiguous.preserve1330
  store <8 x float> %6897, ptr %private.contiguous.address1329, align 4
  %6898 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6899 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6900 = add <8 x i64> %6899, splat (i64 960)
  %6901 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6898, 0
  %6902 = insertvalue { <8 x ptr>, <8 x i64> } %6901, <8 x i64> %6900, 1
  %6903 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6904 = extractvalue { <8 x ptr>, <8 x i64> } %6902, 1
  %6905 = extractelement <8 x ptr> %6903, i32 0
  %6906 = extractelement <8 x i64> %6904, i32 %5882
  %6907 = zext i32 %5882 to i64
  %6908 = mul i64 %6907, 4
  %6909 = sub i64 %6906, %6908
  %6910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6911 = select i1 %6910, i64 %6909, i64 0
  %private.contiguous.address1331 = getelementptr i8, ptr %6905, i64 %6911
  %private.contiguous.preserve1332 = load <8 x float>, ptr %private.contiguous.address1331, align 4
  %6912 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6337, <8 x float> %private.contiguous.preserve1332
  store <8 x float> %6912, ptr %private.contiguous.address1331, align 4
  %6913 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6914 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6915 = add <8 x i64> %6914, splat (i64 992)
  %6916 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6913, 0
  %6917 = insertvalue { <8 x ptr>, <8 x i64> } %6916, <8 x i64> %6915, 1
  %6918 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6919 = extractvalue { <8 x ptr>, <8 x i64> } %6917, 1
  %6920 = extractelement <8 x ptr> %6918, i32 0
  %6921 = extractelement <8 x i64> %6919, i32 %5882
  %6922 = zext i32 %5882 to i64
  %6923 = mul i64 %6922, 4
  %6924 = sub i64 %6921, %6923
  %6925 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6926 = select i1 %6925, i64 %6924, i64 0
  %private.contiguous.address1333 = getelementptr i8, ptr %6920, i64 %6926
  %private.contiguous.preserve1334 = load <8 x float>, ptr %private.contiguous.address1333, align 4
  %6927 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6340, <8 x float> %private.contiguous.preserve1334
  store <8 x float> %6927, ptr %private.contiguous.address1333, align 4
  %6928 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6929 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6930 = add <8 x i64> %6929, splat (i64 1024)
  %6931 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6928, 0
  %6932 = insertvalue { <8 x ptr>, <8 x i64> } %6931, <8 x i64> %6930, 1
  %6933 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6934 = extractvalue { <8 x ptr>, <8 x i64> } %6932, 1
  %6935 = extractelement <8 x ptr> %6933, i32 0
  %6936 = extractelement <8 x i64> %6934, i32 %5882
  %6937 = zext i32 %5882 to i64
  %6938 = mul i64 %6937, 4
  %6939 = sub i64 %6936, %6938
  %6940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6941 = select i1 %6940, i64 %6939, i64 0
  %private.contiguous.address1335 = getelementptr i8, ptr %6935, i64 %6941
  %private.contiguous.preserve1336 = load <8 x float>, ptr %private.contiguous.address1335, align 4
  %6942 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6343, <8 x float> %private.contiguous.preserve1336
  store <8 x float> %6942, ptr %private.contiguous.address1335, align 4
  %6943 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6944 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6945 = add <8 x i64> %6944, splat (i64 1056)
  %6946 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6943, 0
  %6947 = insertvalue { <8 x ptr>, <8 x i64> } %6946, <8 x i64> %6945, 1
  %6948 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6949 = extractvalue { <8 x ptr>, <8 x i64> } %6947, 1
  %6950 = extractelement <8 x ptr> %6948, i32 0
  %6951 = extractelement <8 x i64> %6949, i32 %5882
  %6952 = zext i32 %5882 to i64
  %6953 = mul i64 %6952, 4
  %6954 = sub i64 %6951, %6953
  %6955 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6956 = select i1 %6955, i64 %6954, i64 0
  %private.contiguous.address1337 = getelementptr i8, ptr %6950, i64 %6956
  %private.contiguous.preserve1338 = load <8 x float>, ptr %private.contiguous.address1337, align 4
  %6957 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6346, <8 x float> %private.contiguous.preserve1338
  store <8 x float> %6957, ptr %private.contiguous.address1337, align 4
  %6958 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6959 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6960 = add <8 x i64> %6959, splat (i64 1088)
  %6961 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6958, 0
  %6962 = insertvalue { <8 x ptr>, <8 x i64> } %6961, <8 x i64> %6960, 1
  %6963 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6964 = extractvalue { <8 x ptr>, <8 x i64> } %6962, 1
  %6965 = extractelement <8 x ptr> %6963, i32 0
  %6966 = extractelement <8 x i64> %6964, i32 %5882
  %6967 = zext i32 %5882 to i64
  %6968 = mul i64 %6967, 4
  %6969 = sub i64 %6966, %6968
  %6970 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6971 = select i1 %6970, i64 %6969, i64 0
  %private.contiguous.address1339 = getelementptr i8, ptr %6965, i64 %6971
  %private.contiguous.preserve1340 = load <8 x float>, ptr %private.contiguous.address1339, align 4
  %6972 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6349, <8 x float> %private.contiguous.preserve1340
  store <8 x float> %6972, ptr %private.contiguous.address1339, align 4
  %6973 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6974 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6975 = add <8 x i64> %6974, splat (i64 1120)
  %6976 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6973, 0
  %6977 = insertvalue { <8 x ptr>, <8 x i64> } %6976, <8 x i64> %6975, 1
  %6978 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6979 = extractvalue { <8 x ptr>, <8 x i64> } %6977, 1
  %6980 = extractelement <8 x ptr> %6978, i32 0
  %6981 = extractelement <8 x i64> %6979, i32 %5882
  %6982 = zext i32 %5882 to i64
  %6983 = mul i64 %6982, 4
  %6984 = sub i64 %6981, %6983
  %6985 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %6986 = select i1 %6985, i64 %6984, i64 0
  %private.contiguous.address1341 = getelementptr i8, ptr %6980, i64 %6986
  %private.contiguous.preserve1342 = load <8 x float>, ptr %private.contiguous.address1341, align 4
  %6987 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6352, <8 x float> %private.contiguous.preserve1342
  store <8 x float> %6987, ptr %private.contiguous.address1341, align 4
  %6988 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6989 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6990 = add <8 x i64> %6989, splat (i64 1152)
  %6991 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6988, 0
  %6992 = insertvalue { <8 x ptr>, <8 x i64> } %6991, <8 x i64> %6990, 1
  %6993 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6994 = extractvalue { <8 x ptr>, <8 x i64> } %6992, 1
  %6995 = extractelement <8 x ptr> %6993, i32 0
  %6996 = extractelement <8 x i64> %6994, i32 %5882
  %6997 = zext i32 %5882 to i64
  %6998 = mul i64 %6997, 4
  %6999 = sub i64 %6996, %6998
  %7000 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7001 = select i1 %7000, i64 %6999, i64 0
  %private.contiguous.address1343 = getelementptr i8, ptr %6995, i64 %7001
  %private.contiguous.preserve1344 = load <8 x float>, ptr %private.contiguous.address1343, align 4
  %7002 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6355, <8 x float> %private.contiguous.preserve1344
  store <8 x float> %7002, ptr %private.contiguous.address1343, align 4
  %7003 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7004 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7005 = add <8 x i64> %7004, splat (i64 1184)
  %7006 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7003, 0
  %7007 = insertvalue { <8 x ptr>, <8 x i64> } %7006, <8 x i64> %7005, 1
  %7008 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7009 = extractvalue { <8 x ptr>, <8 x i64> } %7007, 1
  %7010 = extractelement <8 x ptr> %7008, i32 0
  %7011 = extractelement <8 x i64> %7009, i32 %5882
  %7012 = zext i32 %5882 to i64
  %7013 = mul i64 %7012, 4
  %7014 = sub i64 %7011, %7013
  %7015 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7016 = select i1 %7015, i64 %7014, i64 0
  %private.contiguous.address1345 = getelementptr i8, ptr %7010, i64 %7016
  %private.contiguous.preserve1346 = load <8 x float>, ptr %private.contiguous.address1345, align 4
  %7017 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6358, <8 x float> %private.contiguous.preserve1346
  store <8 x float> %7017, ptr %private.contiguous.address1345, align 4
  %7018 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7019 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7020 = add <8 x i64> %7019, splat (i64 1216)
  %7021 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7018, 0
  %7022 = insertvalue { <8 x ptr>, <8 x i64> } %7021, <8 x i64> %7020, 1
  %7023 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7024 = extractvalue { <8 x ptr>, <8 x i64> } %7022, 1
  %7025 = extractelement <8 x ptr> %7023, i32 0
  %7026 = extractelement <8 x i64> %7024, i32 %5882
  %7027 = zext i32 %5882 to i64
  %7028 = mul i64 %7027, 4
  %7029 = sub i64 %7026, %7028
  %7030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7031 = select i1 %7030, i64 %7029, i64 0
  %private.contiguous.address1347 = getelementptr i8, ptr %7025, i64 %7031
  %private.contiguous.preserve1348 = load <8 x float>, ptr %private.contiguous.address1347, align 4
  %7032 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6361, <8 x float> %private.contiguous.preserve1348
  store <8 x float> %7032, ptr %private.contiguous.address1347, align 4
  %7033 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7034 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7035 = add <8 x i64> %7034, splat (i64 1248)
  %7036 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7033, 0
  %7037 = insertvalue { <8 x ptr>, <8 x i64> } %7036, <8 x i64> %7035, 1
  %7038 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7039 = extractvalue { <8 x ptr>, <8 x i64> } %7037, 1
  %7040 = extractelement <8 x ptr> %7038, i32 0
  %7041 = extractelement <8 x i64> %7039, i32 %5882
  %7042 = zext i32 %5882 to i64
  %7043 = mul i64 %7042, 4
  %7044 = sub i64 %7041, %7043
  %7045 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7046 = select i1 %7045, i64 %7044, i64 0
  %private.contiguous.address1349 = getelementptr i8, ptr %7040, i64 %7046
  %private.contiguous.preserve1350 = load <8 x float>, ptr %private.contiguous.address1349, align 4
  %7047 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6364, <8 x float> %private.contiguous.preserve1350
  store <8 x float> %7047, ptr %private.contiguous.address1349, align 4
  %7048 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7049 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7050 = add <8 x i64> %7049, splat (i64 1280)
  %7051 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7048, 0
  %7052 = insertvalue { <8 x ptr>, <8 x i64> } %7051, <8 x i64> %7050, 1
  %7053 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7054 = extractvalue { <8 x ptr>, <8 x i64> } %7052, 1
  %7055 = extractelement <8 x ptr> %7053, i32 0
  %7056 = extractelement <8 x i64> %7054, i32 %5882
  %7057 = zext i32 %5882 to i64
  %7058 = mul i64 %7057, 4
  %7059 = sub i64 %7056, %7058
  %7060 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7061 = select i1 %7060, i64 %7059, i64 0
  %private.contiguous.address1351 = getelementptr i8, ptr %7055, i64 %7061
  %private.contiguous.preserve1352 = load <8 x float>, ptr %private.contiguous.address1351, align 4
  %7062 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6367, <8 x float> %private.contiguous.preserve1352
  store <8 x float> %7062, ptr %private.contiguous.address1351, align 4
  %7063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7064 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7065 = add <8 x i64> %7064, splat (i64 1312)
  %7066 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7063, 0
  %7067 = insertvalue { <8 x ptr>, <8 x i64> } %7066, <8 x i64> %7065, 1
  %7068 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7069 = extractvalue { <8 x ptr>, <8 x i64> } %7067, 1
  %7070 = extractelement <8 x ptr> %7068, i32 0
  %7071 = extractelement <8 x i64> %7069, i32 %5882
  %7072 = zext i32 %5882 to i64
  %7073 = mul i64 %7072, 4
  %7074 = sub i64 %7071, %7073
  %7075 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7076 = select i1 %7075, i64 %7074, i64 0
  %private.contiguous.address1353 = getelementptr i8, ptr %7070, i64 %7076
  %private.contiguous.preserve1354 = load <8 x float>, ptr %private.contiguous.address1353, align 4
  %7077 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6370, <8 x float> %private.contiguous.preserve1354
  store <8 x float> %7077, ptr %private.contiguous.address1353, align 4
  %7078 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7079 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7080 = add <8 x i64> %7079, splat (i64 1344)
  %7081 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7078, 0
  %7082 = insertvalue { <8 x ptr>, <8 x i64> } %7081, <8 x i64> %7080, 1
  %7083 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7084 = extractvalue { <8 x ptr>, <8 x i64> } %7082, 1
  %7085 = extractelement <8 x ptr> %7083, i32 0
  %7086 = extractelement <8 x i64> %7084, i32 %5882
  %7087 = zext i32 %5882 to i64
  %7088 = mul i64 %7087, 4
  %7089 = sub i64 %7086, %7088
  %7090 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7091 = select i1 %7090, i64 %7089, i64 0
  %private.contiguous.address1355 = getelementptr i8, ptr %7085, i64 %7091
  %private.contiguous.preserve1356 = load <8 x float>, ptr %private.contiguous.address1355, align 4
  %7092 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6373, <8 x float> %private.contiguous.preserve1356
  store <8 x float> %7092, ptr %private.contiguous.address1355, align 4
  %7093 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7094 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7095 = add <8 x i64> %7094, splat (i64 1376)
  %7096 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7093, 0
  %7097 = insertvalue { <8 x ptr>, <8 x i64> } %7096, <8 x i64> %7095, 1
  %7098 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7099 = extractvalue { <8 x ptr>, <8 x i64> } %7097, 1
  %7100 = extractelement <8 x ptr> %7098, i32 0
  %7101 = extractelement <8 x i64> %7099, i32 %5882
  %7102 = zext i32 %5882 to i64
  %7103 = mul i64 %7102, 4
  %7104 = sub i64 %7101, %7103
  %7105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7106 = select i1 %7105, i64 %7104, i64 0
  %private.contiguous.address1357 = getelementptr i8, ptr %7100, i64 %7106
  %private.contiguous.preserve1358 = load <8 x float>, ptr %private.contiguous.address1357, align 4
  %7107 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6376, <8 x float> %private.contiguous.preserve1358
  store <8 x float> %7107, ptr %private.contiguous.address1357, align 4
  %7108 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7109 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7110 = add <8 x i64> %7109, splat (i64 1408)
  %7111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7108, 0
  %7112 = insertvalue { <8 x ptr>, <8 x i64> } %7111, <8 x i64> %7110, 1
  %7113 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7114 = extractvalue { <8 x ptr>, <8 x i64> } %7112, 1
  %7115 = extractelement <8 x ptr> %7113, i32 0
  %7116 = extractelement <8 x i64> %7114, i32 %5882
  %7117 = zext i32 %5882 to i64
  %7118 = mul i64 %7117, 4
  %7119 = sub i64 %7116, %7118
  %7120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7121 = select i1 %7120, i64 %7119, i64 0
  %private.contiguous.address1359 = getelementptr i8, ptr %7115, i64 %7121
  %private.contiguous.preserve1360 = load <8 x float>, ptr %private.contiguous.address1359, align 4
  %7122 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6379, <8 x float> %private.contiguous.preserve1360
  store <8 x float> %7122, ptr %private.contiguous.address1359, align 4
  %7123 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7124 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7125 = add <8 x i64> %7124, splat (i64 1440)
  %7126 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7123, 0
  %7127 = insertvalue { <8 x ptr>, <8 x i64> } %7126, <8 x i64> %7125, 1
  %7128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7129 = extractvalue { <8 x ptr>, <8 x i64> } %7127, 1
  %7130 = extractelement <8 x ptr> %7128, i32 0
  %7131 = extractelement <8 x i64> %7129, i32 %5882
  %7132 = zext i32 %5882 to i64
  %7133 = mul i64 %7132, 4
  %7134 = sub i64 %7131, %7133
  %7135 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7136 = select i1 %7135, i64 %7134, i64 0
  %private.contiguous.address1361 = getelementptr i8, ptr %7130, i64 %7136
  %private.contiguous.preserve1362 = load <8 x float>, ptr %private.contiguous.address1361, align 4
  %7137 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6382, <8 x float> %private.contiguous.preserve1362
  store <8 x float> %7137, ptr %private.contiguous.address1361, align 4
  %7138 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7139 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7140 = add <8 x i64> %7139, splat (i64 1472)
  %7141 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7138, 0
  %7142 = insertvalue { <8 x ptr>, <8 x i64> } %7141, <8 x i64> %7140, 1
  %7143 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7144 = extractvalue { <8 x ptr>, <8 x i64> } %7142, 1
  %7145 = extractelement <8 x ptr> %7143, i32 0
  %7146 = extractelement <8 x i64> %7144, i32 %5882
  %7147 = zext i32 %5882 to i64
  %7148 = mul i64 %7147, 4
  %7149 = sub i64 %7146, %7148
  %7150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7151 = select i1 %7150, i64 %7149, i64 0
  %private.contiguous.address1363 = getelementptr i8, ptr %7145, i64 %7151
  %private.contiguous.preserve1364 = load <8 x float>, ptr %private.contiguous.address1363, align 4
  %7152 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6385, <8 x float> %private.contiguous.preserve1364
  store <8 x float> %7152, ptr %private.contiguous.address1363, align 4
  %7153 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7154 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7155 = add <8 x i64> %7154, splat (i64 1504)
  %7156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7153, 0
  %7157 = insertvalue { <8 x ptr>, <8 x i64> } %7156, <8 x i64> %7155, 1
  %7158 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7159 = extractvalue { <8 x ptr>, <8 x i64> } %7157, 1
  %7160 = extractelement <8 x ptr> %7158, i32 0
  %7161 = extractelement <8 x i64> %7159, i32 %5882
  %7162 = zext i32 %5882 to i64
  %7163 = mul i64 %7162, 4
  %7164 = sub i64 %7161, %7163
  %7165 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7166 = select i1 %7165, i64 %7164, i64 0
  %private.contiguous.address1365 = getelementptr i8, ptr %7160, i64 %7166
  %private.contiguous.preserve1366 = load <8 x float>, ptr %private.contiguous.address1365, align 4
  %7167 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6388, <8 x float> %private.contiguous.preserve1366
  store <8 x float> %7167, ptr %private.contiguous.address1365, align 4
  %7168 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7169 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7170 = add <8 x i64> %7169, splat (i64 1536)
  %7171 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7168, 0
  %7172 = insertvalue { <8 x ptr>, <8 x i64> } %7171, <8 x i64> %7170, 1
  %7173 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7174 = extractvalue { <8 x ptr>, <8 x i64> } %7172, 1
  %7175 = extractelement <8 x ptr> %7173, i32 0
  %7176 = extractelement <8 x i64> %7174, i32 %5882
  %7177 = zext i32 %5882 to i64
  %7178 = mul i64 %7177, 4
  %7179 = sub i64 %7176, %7178
  %7180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7181 = select i1 %7180, i64 %7179, i64 0
  %private.contiguous.address1367 = getelementptr i8, ptr %7175, i64 %7181
  %private.contiguous.preserve1368 = load <8 x float>, ptr %private.contiguous.address1367, align 4
  %7182 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6391, <8 x float> %private.contiguous.preserve1368
  store <8 x float> %7182, ptr %private.contiguous.address1367, align 4
  %7183 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7184 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7185 = add <8 x i64> %7184, splat (i64 1568)
  %7186 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7183, 0
  %7187 = insertvalue { <8 x ptr>, <8 x i64> } %7186, <8 x i64> %7185, 1
  %7188 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7189 = extractvalue { <8 x ptr>, <8 x i64> } %7187, 1
  %7190 = extractelement <8 x ptr> %7188, i32 0
  %7191 = extractelement <8 x i64> %7189, i32 %5882
  %7192 = zext i32 %5882 to i64
  %7193 = mul i64 %7192, 4
  %7194 = sub i64 %7191, %7193
  %7195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7196 = select i1 %7195, i64 %7194, i64 0
  %private.contiguous.address1369 = getelementptr i8, ptr %7190, i64 %7196
  %private.contiguous.preserve1370 = load <8 x float>, ptr %private.contiguous.address1369, align 4
  %7197 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6394, <8 x float> %private.contiguous.preserve1370
  store <8 x float> %7197, ptr %private.contiguous.address1369, align 4
  %7198 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7199 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7200 = add <8 x i64> %7199, splat (i64 1600)
  %7201 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7198, 0
  %7202 = insertvalue { <8 x ptr>, <8 x i64> } %7201, <8 x i64> %7200, 1
  %7203 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7204 = extractvalue { <8 x ptr>, <8 x i64> } %7202, 1
  %7205 = extractelement <8 x ptr> %7203, i32 0
  %7206 = extractelement <8 x i64> %7204, i32 %5882
  %7207 = zext i32 %5882 to i64
  %7208 = mul i64 %7207, 4
  %7209 = sub i64 %7206, %7208
  %7210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7211 = select i1 %7210, i64 %7209, i64 0
  %private.contiguous.address1371 = getelementptr i8, ptr %7205, i64 %7211
  %private.contiguous.preserve1372 = load <8 x float>, ptr %private.contiguous.address1371, align 4
  %7212 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6397, <8 x float> %private.contiguous.preserve1372
  store <8 x float> %7212, ptr %private.contiguous.address1371, align 4
  %7213 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7214 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7215 = add <8 x i64> %7214, splat (i64 1632)
  %7216 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7213, 0
  %7217 = insertvalue { <8 x ptr>, <8 x i64> } %7216, <8 x i64> %7215, 1
  %7218 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7219 = extractvalue { <8 x ptr>, <8 x i64> } %7217, 1
  %7220 = extractelement <8 x ptr> %7218, i32 0
  %7221 = extractelement <8 x i64> %7219, i32 %5882
  %7222 = zext i32 %5882 to i64
  %7223 = mul i64 %7222, 4
  %7224 = sub i64 %7221, %7223
  %7225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7226 = select i1 %7225, i64 %7224, i64 0
  %private.contiguous.address1373 = getelementptr i8, ptr %7220, i64 %7226
  %private.contiguous.preserve1374 = load <8 x float>, ptr %private.contiguous.address1373, align 4
  %7227 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6400, <8 x float> %private.contiguous.preserve1374
  store <8 x float> %7227, ptr %private.contiguous.address1373, align 4
  %7228 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7229 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7230 = add <8 x i64> %7229, splat (i64 1664)
  %7231 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7228, 0
  %7232 = insertvalue { <8 x ptr>, <8 x i64> } %7231, <8 x i64> %7230, 1
  %7233 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7234 = extractvalue { <8 x ptr>, <8 x i64> } %7232, 1
  %7235 = extractelement <8 x ptr> %7233, i32 0
  %7236 = extractelement <8 x i64> %7234, i32 %5882
  %7237 = zext i32 %5882 to i64
  %7238 = mul i64 %7237, 4
  %7239 = sub i64 %7236, %7238
  %7240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7241 = select i1 %7240, i64 %7239, i64 0
  %private.contiguous.address1375 = getelementptr i8, ptr %7235, i64 %7241
  %private.contiguous.preserve1376 = load <8 x float>, ptr %private.contiguous.address1375, align 4
  %7242 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6403, <8 x float> %private.contiguous.preserve1376
  store <8 x float> %7242, ptr %private.contiguous.address1375, align 4
  %7243 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7244 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7245 = add <8 x i64> %7244, splat (i64 1696)
  %7246 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7243, 0
  %7247 = insertvalue { <8 x ptr>, <8 x i64> } %7246, <8 x i64> %7245, 1
  %7248 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7249 = extractvalue { <8 x ptr>, <8 x i64> } %7247, 1
  %7250 = extractelement <8 x ptr> %7248, i32 0
  %7251 = extractelement <8 x i64> %7249, i32 %5882
  %7252 = zext i32 %5882 to i64
  %7253 = mul i64 %7252, 4
  %7254 = sub i64 %7251, %7253
  %7255 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7256 = select i1 %7255, i64 %7254, i64 0
  %private.contiguous.address1377 = getelementptr i8, ptr %7250, i64 %7256
  %private.contiguous.preserve1378 = load <8 x float>, ptr %private.contiguous.address1377, align 4
  %7257 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6406, <8 x float> %private.contiguous.preserve1378
  store <8 x float> %7257, ptr %private.contiguous.address1377, align 4
  %7258 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7259 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7260 = add <8 x i64> %7259, splat (i64 1728)
  %7261 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7258, 0
  %7262 = insertvalue { <8 x ptr>, <8 x i64> } %7261, <8 x i64> %7260, 1
  %7263 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7264 = extractvalue { <8 x ptr>, <8 x i64> } %7262, 1
  %7265 = extractelement <8 x ptr> %7263, i32 0
  %7266 = extractelement <8 x i64> %7264, i32 %5882
  %7267 = zext i32 %5882 to i64
  %7268 = mul i64 %7267, 4
  %7269 = sub i64 %7266, %7268
  %7270 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7271 = select i1 %7270, i64 %7269, i64 0
  %private.contiguous.address1379 = getelementptr i8, ptr %7265, i64 %7271
  %private.contiguous.preserve1380 = load <8 x float>, ptr %private.contiguous.address1379, align 4
  %7272 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6409, <8 x float> %private.contiguous.preserve1380
  store <8 x float> %7272, ptr %private.contiguous.address1379, align 4
  %7273 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7274 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7275 = add <8 x i64> %7274, splat (i64 1760)
  %7276 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7273, 0
  %7277 = insertvalue { <8 x ptr>, <8 x i64> } %7276, <8 x i64> %7275, 1
  %7278 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7279 = extractvalue { <8 x ptr>, <8 x i64> } %7277, 1
  %7280 = extractelement <8 x ptr> %7278, i32 0
  %7281 = extractelement <8 x i64> %7279, i32 %5882
  %7282 = zext i32 %5882 to i64
  %7283 = mul i64 %7282, 4
  %7284 = sub i64 %7281, %7283
  %7285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7286 = select i1 %7285, i64 %7284, i64 0
  %private.contiguous.address1381 = getelementptr i8, ptr %7280, i64 %7286
  %private.contiguous.preserve1382 = load <8 x float>, ptr %private.contiguous.address1381, align 4
  %7287 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6412, <8 x float> %private.contiguous.preserve1382
  store <8 x float> %7287, ptr %private.contiguous.address1381, align 4
  %7288 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7289 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7290 = add <8 x i64> %7289, splat (i64 1792)
  %7291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7288, 0
  %7292 = insertvalue { <8 x ptr>, <8 x i64> } %7291, <8 x i64> %7290, 1
  %7293 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7294 = extractvalue { <8 x ptr>, <8 x i64> } %7292, 1
  %7295 = extractelement <8 x ptr> %7293, i32 0
  %7296 = extractelement <8 x i64> %7294, i32 %5882
  %7297 = zext i32 %5882 to i64
  %7298 = mul i64 %7297, 4
  %7299 = sub i64 %7296, %7298
  %7300 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7301 = select i1 %7300, i64 %7299, i64 0
  %private.contiguous.address1383 = getelementptr i8, ptr %7295, i64 %7301
  %private.contiguous.preserve1384 = load <8 x float>, ptr %private.contiguous.address1383, align 4
  %7302 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6415, <8 x float> %private.contiguous.preserve1384
  store <8 x float> %7302, ptr %private.contiguous.address1383, align 4
  %7303 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7304 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7305 = add <8 x i64> %7304, splat (i64 1824)
  %7306 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7303, 0
  %7307 = insertvalue { <8 x ptr>, <8 x i64> } %7306, <8 x i64> %7305, 1
  %7308 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7309 = extractvalue { <8 x ptr>, <8 x i64> } %7307, 1
  %7310 = extractelement <8 x ptr> %7308, i32 0
  %7311 = extractelement <8 x i64> %7309, i32 %5882
  %7312 = zext i32 %5882 to i64
  %7313 = mul i64 %7312, 4
  %7314 = sub i64 %7311, %7313
  %7315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7316 = select i1 %7315, i64 %7314, i64 0
  %private.contiguous.address1385 = getelementptr i8, ptr %7310, i64 %7316
  %private.contiguous.preserve1386 = load <8 x float>, ptr %private.contiguous.address1385, align 4
  %7317 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6418, <8 x float> %private.contiguous.preserve1386
  store <8 x float> %7317, ptr %private.contiguous.address1385, align 4
  %7318 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7319 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7320 = add <8 x i64> %7319, splat (i64 1856)
  %7321 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7318, 0
  %7322 = insertvalue { <8 x ptr>, <8 x i64> } %7321, <8 x i64> %7320, 1
  %7323 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7324 = extractvalue { <8 x ptr>, <8 x i64> } %7322, 1
  %7325 = extractelement <8 x ptr> %7323, i32 0
  %7326 = extractelement <8 x i64> %7324, i32 %5882
  %7327 = zext i32 %5882 to i64
  %7328 = mul i64 %7327, 4
  %7329 = sub i64 %7326, %7328
  %7330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7331 = select i1 %7330, i64 %7329, i64 0
  %private.contiguous.address1387 = getelementptr i8, ptr %7325, i64 %7331
  %private.contiguous.preserve1388 = load <8 x float>, ptr %private.contiguous.address1387, align 4
  %7332 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6421, <8 x float> %private.contiguous.preserve1388
  store <8 x float> %7332, ptr %private.contiguous.address1387, align 4
  %7333 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7334 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7335 = add <8 x i64> %7334, splat (i64 1888)
  %7336 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7333, 0
  %7337 = insertvalue { <8 x ptr>, <8 x i64> } %7336, <8 x i64> %7335, 1
  %7338 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7339 = extractvalue { <8 x ptr>, <8 x i64> } %7337, 1
  %7340 = extractelement <8 x ptr> %7338, i32 0
  %7341 = extractelement <8 x i64> %7339, i32 %5882
  %7342 = zext i32 %5882 to i64
  %7343 = mul i64 %7342, 4
  %7344 = sub i64 %7341, %7343
  %7345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7346 = select i1 %7345, i64 %7344, i64 0
  %private.contiguous.address1389 = getelementptr i8, ptr %7340, i64 %7346
  %private.contiguous.preserve1390 = load <8 x float>, ptr %private.contiguous.address1389, align 4
  %7347 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6424, <8 x float> %private.contiguous.preserve1390
  store <8 x float> %7347, ptr %private.contiguous.address1389, align 4
  %7348 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7349 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7350 = add <8 x i64> %7349, splat (i64 1920)
  %7351 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7348, 0
  %7352 = insertvalue { <8 x ptr>, <8 x i64> } %7351, <8 x i64> %7350, 1
  %7353 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7354 = extractvalue { <8 x ptr>, <8 x i64> } %7352, 1
  %7355 = extractelement <8 x ptr> %7353, i32 0
  %7356 = extractelement <8 x i64> %7354, i32 %5882
  %7357 = zext i32 %5882 to i64
  %7358 = mul i64 %7357, 4
  %7359 = sub i64 %7356, %7358
  %7360 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7361 = select i1 %7360, i64 %7359, i64 0
  %private.contiguous.address1391 = getelementptr i8, ptr %7355, i64 %7361
  %private.contiguous.preserve1392 = load <8 x float>, ptr %private.contiguous.address1391, align 4
  %7362 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6427, <8 x float> %private.contiguous.preserve1392
  store <8 x float> %7362, ptr %private.contiguous.address1391, align 4
  %7363 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7364 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7365 = add <8 x i64> %7364, splat (i64 1952)
  %7366 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7363, 0
  %7367 = insertvalue { <8 x ptr>, <8 x i64> } %7366, <8 x i64> %7365, 1
  %7368 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7369 = extractvalue { <8 x ptr>, <8 x i64> } %7367, 1
  %7370 = extractelement <8 x ptr> %7368, i32 0
  %7371 = extractelement <8 x i64> %7369, i32 %5882
  %7372 = zext i32 %5882 to i64
  %7373 = mul i64 %7372, 4
  %7374 = sub i64 %7371, %7373
  %7375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7376 = select i1 %7375, i64 %7374, i64 0
  %private.contiguous.address1393 = getelementptr i8, ptr %7370, i64 %7376
  %private.contiguous.preserve1394 = load <8 x float>, ptr %private.contiguous.address1393, align 4
  %7377 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6430, <8 x float> %private.contiguous.preserve1394
  store <8 x float> %7377, ptr %private.contiguous.address1393, align 4
  %7378 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7379 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7380 = add <8 x i64> %7379, splat (i64 1984)
  %7381 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7378, 0
  %7382 = insertvalue { <8 x ptr>, <8 x i64> } %7381, <8 x i64> %7380, 1
  %7383 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7384 = extractvalue { <8 x ptr>, <8 x i64> } %7382, 1
  %7385 = extractelement <8 x ptr> %7383, i32 0
  %7386 = extractelement <8 x i64> %7384, i32 %5882
  %7387 = zext i32 %5882 to i64
  %7388 = mul i64 %7387, 4
  %7389 = sub i64 %7386, %7388
  %7390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7391 = select i1 %7390, i64 %7389, i64 0
  %private.contiguous.address1395 = getelementptr i8, ptr %7385, i64 %7391
  %private.contiguous.preserve1396 = load <8 x float>, ptr %private.contiguous.address1395, align 4
  %7392 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6433, <8 x float> %private.contiguous.preserve1396
  store <8 x float> %7392, ptr %private.contiguous.address1395, align 4
  %7393 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7394 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7395 = add <8 x i64> %7394, splat (i64 2016)
  %7396 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7393, 0
  %7397 = insertvalue { <8 x ptr>, <8 x i64> } %7396, <8 x i64> %7395, 1
  %7398 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7399 = extractvalue { <8 x ptr>, <8 x i64> } %7397, 1
  %7400 = extractelement <8 x ptr> %7398, i32 0
  %7401 = extractelement <8 x i64> %7399, i32 %5882
  %7402 = zext i32 %5882 to i64
  %7403 = mul i64 %7402, 4
  %7404 = sub i64 %7401, %7403
  %7405 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  %7406 = select i1 %7405, i64 %7404, i64 0
  %private.contiguous.address1397 = getelementptr i8, ptr %7400, i64 %7406
  %private.contiguous.preserve1398 = load <8 x float>, ptr %private.contiguous.address1397, align 4
  %7407 = select <8 x i1> %convergence.cascade.result1188, <8 x float> %6436, <8 x float> %private.contiguous.preserve1398
  store <8 x float> %7407, ptr %private.contiguous.address1397, align 4
  %7408 = load <8 x i64>, ptr %.slot56, align 64
  %7409 = select <8 x i1> %convergence.cascade.result1188, <8 x i64> zeroinitializer, <8 x i64> %7408
  store <8 x i64> %7409, ptr %.slot56, align 64
  %7410 = load <8 x float>, ptr %.slot58, align 32
  %7411 = select <8 x i1> %convergence.cascade.result1188, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %7410
  store <8 x float> %7411, ptr %.slot58, align 32
  store <8 x i1> %convergence.cascade.result1188, ptr %current.mask, align 1
  %7412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1188)
  br i1 %7412, label %schedule.69, label %scheduler.loop

varying.divergent1400:                            ; preds = %schedule.69
  %7413 = load i32, ptr %current.token, align 4
  %7414 = icmp ne i32 %7413, 0
  %7415 = sub i32 %7413, 1
  %7416 = select i1 %7414, i32 %7415, i32 0
  %7417 = load i8, ptr %frame.active, align 1
  %7418 = trunc i32 %7416 to i8
  %7419 = shl i8 1, %7418
  %7420 = and i8 %7417, %7419
  %7421 = icmp ne i8 %7420, 0
  %7422 = load <8 x i32>, ptr %frame.static.id, align 32
  %7423 = extractelement <8 x i32> %7422, i32 %7416
  %7424 = icmp eq i32 %7423, 24
  %7425 = and i1 %7421, %7424
  %7426 = and i1 %7414, %7425
  %7427 = xor i1 %7426, true
  %7428 = and i1 true, %7427
  %7429 = xor i8 %7417, -1
  %7430 = icmp ne i8 %7429, 0
  %7431 = xor i1 %7430, true
  %7432 = and i1 %7428, %7431
  br i1 %7432, label %convergence.overflow.trap1402, label %convergence.overflow.resume1403

varying.coherent1401:                             ; preds = %schedule.69
  br i1 %1943, label %varying.coherent.true1406, label %varying.coherent.false1407

convergence.overflow.trap1402:                    ; preds = %varying.divergent1400
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1403:                  ; preds = %varying.divergent1400
  %7433 = call i8 @llvm.cttz.i8(i8 %7429, i1 false)
  %7434 = zext i8 %7433 to i32
  %7435 = select i1 %7430, i32 %7434, i32 0
  %7436 = trunc i32 %7435 to i8
  %7437 = shl i8 1, %7436
  %7438 = or i8 %7417, %7437
  %7439 = select i1 %7428, i8 %7438, i8 %7417
  store i8 %7439, ptr %frame.active, align 1
  %7440 = load <8 x i32>, ptr %frame.static.id, align 32
  %7441 = extractelement <8 x i32> %7440, i32 %7435
  %7442 = select i1 %7428, i32 24, i32 %7441
  %7443 = load <8 x i32>, ptr %frame.static.id, align 32
  %7444 = insertelement <8 x i32> %7443, i32 %7442, i32 %7435
  store <8 x i32> %7444, ptr %frame.static.id, align 32
  %7445 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7446 = extractelement <8 x i32> %7445, i32 %7435
  %7447 = select i1 %7428, i32 %7413, i32 %7446
  %7448 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7449 = insertelement <8 x i32> %7448, i32 %7447, i32 %7435
  store <8 x i32> %7449, ptr %frame.parent.token, align 32
  %7450 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7435
  %7451 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7435
  %7452 = load <8 x i1>, ptr %7450, align 1
  %7453 = load <8 x i1>, ptr %7451, align 1
  %7454 = select i1 %7428, <8 x i1> %1933, <8 x i1> %7452
  store <8 x i1> %7454, ptr %7450, align 1
  %7455 = select i1 %7428, <8 x i1> zeroinitializer, <8 x i1> %7453
  store <8 x i1> %7455, ptr %7451, align 1
  %7456 = add i32 %7435, 1
  %7457 = select i1 %7426, i32 %7413, i32 %7456
  %7458 = select i1 true, i32 %7457, i32 %7413
  store i32 %7458, ptr %current.token, align 4
  %7459 = load i32, ptr %current.token, align 4
  %7460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1940)
  %7461 = load i32, ptr %ready.count, align 4
  %7462 = icmp uge i32 %7461, 8
  %7463 = and i1 %7460, %7462
  br i1 %7463, label %ready.overflow.trap1404, label %ready.overflow.resume1405

ready.overflow.trap1404:                          ; preds = %convergence.overflow.resume1403
  call void @llvm.trap()
  unreachable

ready.overflow.resume1405:                        ; preds = %convergence.overflow.resume1403
  %7464 = select i1 %7460, i32 %7461, i32 0
  %7465 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7464
  %7466 = load <8 x i1>, ptr %7465, align 1
  %7467 = select i1 %7460, <8 x i1> %1940, <8 x i1> %7466
  store <8 x i1> %7467, ptr %7465, align 1
  %7468 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7464
  %7469 = load i32, ptr %7468, align 4
  %7470 = select i1 %7460, i32 70, i32 %7469
  store i32 %7470, ptr %7468, align 4
  %7471 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7464
  %7472 = load i32, ptr %7471, align 4
  %7473 = select i1 %7460, i32 %7459, i32 %7472
  store i32 %7473, ptr %7471, align 4
  %7474 = add i32 %7461, 1
  %7475 = select i1 %7460, i32 %7474, i32 %7461
  store i32 %7475, ptr %ready.count, align 4
  %7476 = load <8 x i1>, ptr %runnable.mask, align 1
  %7477 = or <8 x i1> %7476, %1940
  store <8 x i1> %7477, ptr %runnable.mask, align 1
  store <8 x i1> %1942, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1406:                        ; preds = %varying.coherent1401
  store <8 x i1> %1933, ptr %current.mask, align 1
  %7478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1933)
  br i1 %7478, label %schedule.70, label %scheduler.loop

varying.coherent.false1407:                       ; preds = %varying.coherent1401
  store <8 x i1> %1933, ptr %current.mask, align 1
  %7479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1933)
  br i1 %7479, label %schedule.71, label %scheduler.loop

convergence.cascade1412:                          ; preds = %convergence.cascade1412, %schedule.71
  %convergence.cascade.flow1416 = phi <8 x i1> [ %1973, %schedule.71 ], [ %7522, %convergence.cascade1412 ]
  %convergence.cascade.depth1417 = phi i32 [ 0, %schedule.71 ], [ %7523, %convergence.cascade1412 ]
  %7480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1416)
  %7481 = load i32, ptr %current.token, align 4
  %7482 = icmp ne i32 %7481, 0
  %7483 = and i1 %7480, %7482
  %7484 = sub i32 %7481, 1
  %7485 = select i1 %7483, i32 %7484, i32 0
  %7486 = load i8, ptr %frame.active, align 1
  %7487 = trunc i32 %7485 to i8
  %7488 = shl i8 1, %7487
  %7489 = and i8 %7486, %7488
  %7490 = icmp ne i8 %7489, 0
  %7491 = load <8 x i32>, ptr %frame.static.id, align 32
  %7492 = extractelement <8 x i32> %7491, i32 %7485
  %convergence.target.pointer1418 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %7492
  %convergence.dynamic.target1419 = load i32, ptr %convergence.target.pointer1418, align 4
  %7493 = icmp eq i32 %convergence.dynamic.target1419, 71
  %7494 = and i1 %7490, %7493
  %7495 = and i1 %7483, %7494
  %7496 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7485
  %7497 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7485
  %7498 = load <8 x i1>, ptr %7496, align 1
  %7499 = load <8 x i1>, ptr %7497, align 1
  %7500 = or <8 x i1> %7499, %convergence.cascade.flow1416
  %7501 = load <8 x i1>, ptr %live.mask, align 1
  %7502 = and <8 x i1> %7498, %7501
  %7503 = icmp eq <8 x i1> %7500, %7502
  %7504 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7503)
  %7505 = and i1 %7495, %7504
  %7506 = select i1 %7505, <8 x i1> zeroinitializer, <8 x i1> %7500
  %7507 = select i1 %7495, <8 x i1> %7506, <8 x i1> %7499
  store <8 x i1> %7507, ptr %7497, align 1
  %7508 = select i1 %7505, <8 x i1> zeroinitializer, <8 x i1> %7498
  store <8 x i1> %7508, ptr %7496, align 1
  %7509 = trunc i32 %7485 to i8
  %7510 = shl i8 1, %7509
  %7511 = xor i8 %7510, -1
  %7512 = and i8 %7486, %7511
  %7513 = select i1 %7505, i8 %7512, i8 %7486
  store i8 %7513, ptr %frame.active, align 1
  %.splatinsert1420 = insertelement <8 x i1> poison, i1 %7495, i64 0
  %.splat1421 = shufflevector <8 x i1> %.splatinsert1420, <8 x i1> poison, <8 x i32> zeroinitializer
  %7514 = and <8 x i1> %convergence.cascade.flow1416, %.splat1421
  %7515 = load <8 x i1>, ptr %runnable.mask, align 1
  %7516 = xor <8 x i1> %7514, splat (i1 true)
  %7517 = and <8 x i1> %7515, %7516
  store <8 x i1> %7517, ptr %runnable.mask, align 1
  %.splatinsert1422 = insertelement <8 x i1> poison, i1 %7505, i64 0
  %.splat1423 = shufflevector <8 x i1> %.splatinsert1422, <8 x i1> poison, <8 x i32> zeroinitializer
  %7518 = select <8 x i1> %.splat1423, <8 x i1> %7500, <8 x i1> zeroinitializer
  %7519 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7520 = extractelement <8 x i32> %7519, i32 %7485
  %7521 = select i1 %7505, i32 %7520, i32 %7481
  store i32 %7521, ptr %current.token, align 4
  %.splatinsert1424 = insertelement <8 x i1> poison, i1 %7495, i64 0
  %.splat1425 = shufflevector <8 x i1> %.splatinsert1424, <8 x i1> poison, <8 x i32> zeroinitializer
  %7522 = select <8 x i1> %.splat1425, <8 x i1> %7518, <8 x i1> %convergence.cascade.flow1416
  %7523 = add i32 %convergence.cascade.depth1417, 1
  %7524 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7522)
  %7525 = icmp ult i32 %7523, 8
  %7526 = and i1 %7524, %7525
  %7527 = and i1 %7495, %7526
  %convergence.parent.token1426 = load i32, ptr %current.token, align 4
  %convergence.parent.present1427 = icmp ne i32 %convergence.parent.token1426, 0
  %7528 = and i1 %7527, %convergence.parent.present1427
  br i1 %7528, label %convergence.cascade1412, label %convergence.cascade.exit1413

convergence.cascade.exit1413:                     ; preds = %convergence.cascade1412, %schedule.71
  %convergence.cascade.result1428 = phi <8 x i1> [ %1973, %schedule.71 ], [ %7522, %convergence.cascade1412 ]
  %7529 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1428)
  br i1 %7529, label %convergence.target.71.ready, label %scheduler.loop

convergence.target.71.ready:                      ; preds = %convergence.cascade.exit1413
  %7530 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1428)
  %7531 = bitcast <8 x i1> %convergence.cascade.result1428 to i8
  %7532 = call i8 @llvm.cttz.i8(i8 %7531, i1 false)
  %7533 = zext i8 %7532 to i32
  %7534 = select i1 %7530, i32 %7533, i32 0
  %7535 = load <8 x i64>, ptr %.slot56, align 64
  %7536 = select <8 x i1> %convergence.cascade.result1428, <8 x i64> zeroinitializer, <8 x i64> %7535
  store <8 x i64> %7536, ptr %.slot56, align 64
  %7537 = load <8 x float>, ptr %.slot65, align 32
  %7538 = select <8 x i1> %convergence.cascade.result1428, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %7537
  store <8 x float> %7538, ptr %.slot65, align 32
  store <8 x i1> %convergence.cascade.result1428, ptr %current.mask, align 1
  %7539 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1428)
  br i1 %7539, label %schedule.72, label %scheduler.loop

varying.divergent1430:                            ; preds = %schedule.72
  %7540 = load i32, ptr %current.token, align 4
  %7541 = icmp ne i32 %7540, 0
  %7542 = sub i32 %7540, 1
  %7543 = select i1 %7541, i32 %7542, i32 0
  %7544 = load i8, ptr %frame.active, align 1
  %7545 = trunc i32 %7543 to i8
  %7546 = shl i8 1, %7545
  %7547 = and i8 %7544, %7546
  %7548 = icmp ne i8 %7547, 0
  %7549 = load <8 x i32>, ptr %frame.static.id, align 32
  %7550 = extractelement <8 x i32> %7549, i32 %7543
  %7551 = icmp eq i32 %7550, 25
  %7552 = and i1 %7548, %7551
  %7553 = and i1 %7541, %7552
  %7554 = xor i1 %7553, true
  %7555 = and i1 true, %7554
  %7556 = xor i8 %7544, -1
  %7557 = icmp ne i8 %7556, 0
  %7558 = xor i1 %7557, true
  %7559 = and i1 %7555, %7558
  br i1 %7559, label %convergence.overflow.trap1432, label %convergence.overflow.resume1433

varying.coherent1431:                             ; preds = %schedule.72
  br i1 %1984, label %varying.coherent.true1436, label %varying.coherent.false1437

convergence.overflow.trap1432:                    ; preds = %varying.divergent1430
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1433:                  ; preds = %varying.divergent1430
  %7560 = call i8 @llvm.cttz.i8(i8 %7556, i1 false)
  %7561 = zext i8 %7560 to i32
  %7562 = select i1 %7557, i32 %7561, i32 0
  %7563 = trunc i32 %7562 to i8
  %7564 = shl i8 1, %7563
  %7565 = or i8 %7544, %7564
  %7566 = select i1 %7555, i8 %7565, i8 %7544
  store i8 %7566, ptr %frame.active, align 1
  %7567 = load <8 x i32>, ptr %frame.static.id, align 32
  %7568 = extractelement <8 x i32> %7567, i32 %7562
  %7569 = select i1 %7555, i32 25, i32 %7568
  %7570 = load <8 x i32>, ptr %frame.static.id, align 32
  %7571 = insertelement <8 x i32> %7570, i32 %7569, i32 %7562
  store <8 x i32> %7571, ptr %frame.static.id, align 32
  %7572 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7573 = extractelement <8 x i32> %7572, i32 %7562
  %7574 = select i1 %7555, i32 %7540, i32 %7573
  %7575 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7576 = insertelement <8 x i32> %7575, i32 %7574, i32 %7562
  store <8 x i32> %7576, ptr %frame.parent.token, align 32
  %7577 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7562
  %7578 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7562
  %7579 = load <8 x i1>, ptr %7577, align 1
  %7580 = load <8 x i1>, ptr %7578, align 1
  %7581 = select i1 %7555, <8 x i1> %1974, <8 x i1> %7579
  store <8 x i1> %7581, ptr %7577, align 1
  %7582 = select i1 %7555, <8 x i1> zeroinitializer, <8 x i1> %7580
  store <8 x i1> %7582, ptr %7578, align 1
  %7583 = add i32 %7562, 1
  %7584 = select i1 %7553, i32 %7540, i32 %7583
  %7585 = select i1 true, i32 %7584, i32 %7540
  store i32 %7585, ptr %current.token, align 4
  %7586 = load i32, ptr %current.token, align 4
  %7587 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1981)
  %7588 = load i32, ptr %ready.count, align 4
  %7589 = icmp uge i32 %7588, 8
  %7590 = and i1 %7587, %7589
  br i1 %7590, label %ready.overflow.trap1434, label %ready.overflow.resume1435

ready.overflow.trap1434:                          ; preds = %convergence.overflow.resume1433
  call void @llvm.trap()
  unreachable

ready.overflow.resume1435:                        ; preds = %convergence.overflow.resume1433
  %7591 = select i1 %7587, i32 %7588, i32 0
  %7592 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7591
  %7593 = load <8 x i1>, ptr %7592, align 1
  %7594 = select i1 %7587, <8 x i1> %1981, <8 x i1> %7593
  store <8 x i1> %7594, ptr %7592, align 1
  %7595 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7591
  %7596 = load i32, ptr %7595, align 4
  %7597 = select i1 %7587, i32 73, i32 %7596
  store i32 %7597, ptr %7595, align 4
  %7598 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7591
  %7599 = load i32, ptr %7598, align 4
  %7600 = select i1 %7587, i32 %7586, i32 %7599
  store i32 %7600, ptr %7598, align 4
  %7601 = add i32 %7588, 1
  %7602 = select i1 %7587, i32 %7601, i32 %7588
  store i32 %7602, ptr %ready.count, align 4
  %7603 = load <8 x i1>, ptr %runnable.mask, align 1
  %7604 = or <8 x i1> %7603, %1981
  store <8 x i1> %7604, ptr %runnable.mask, align 1
  store <8 x i1> %1983, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1436:                        ; preds = %varying.coherent1431
  store <8 x i1> %1974, ptr %current.mask, align 1
  %7605 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1974)
  br i1 %7605, label %schedule.73, label %scheduler.loop

varying.coherent.false1437:                       ; preds = %varying.coherent1431
  store <8 x i1> %1974, ptr %current.mask, align 1
  %7606 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1974)
  br i1 %7606, label %schedule.74, label %scheduler.loop

convergence.cascade1442:                          ; preds = %convergence.cascade1442, %schedule.74
  %convergence.cascade.flow1446 = phi <8 x i1> [ %2014, %schedule.74 ], [ %7649, %convergence.cascade1442 ]
  %convergence.cascade.depth1447 = phi i32 [ 0, %schedule.74 ], [ %7650, %convergence.cascade1442 ]
  %7607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1446)
  %7608 = load i32, ptr %current.token, align 4
  %7609 = icmp ne i32 %7608, 0
  %7610 = and i1 %7607, %7609
  %7611 = sub i32 %7608, 1
  %7612 = select i1 %7610, i32 %7611, i32 0
  %7613 = load i8, ptr %frame.active, align 1
  %7614 = trunc i32 %7612 to i8
  %7615 = shl i8 1, %7614
  %7616 = and i8 %7613, %7615
  %7617 = icmp ne i8 %7616, 0
  %7618 = load <8 x i32>, ptr %frame.static.id, align 32
  %7619 = extractelement <8 x i32> %7618, i32 %7612
  %convergence.target.pointer1448 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %7619
  %convergence.dynamic.target1449 = load i32, ptr %convergence.target.pointer1448, align 4
  %7620 = icmp eq i32 %convergence.dynamic.target1449, 74
  %7621 = and i1 %7617, %7620
  %7622 = and i1 %7610, %7621
  %7623 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7612
  %7624 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7612
  %7625 = load <8 x i1>, ptr %7623, align 1
  %7626 = load <8 x i1>, ptr %7624, align 1
  %7627 = or <8 x i1> %7626, %convergence.cascade.flow1446
  %7628 = load <8 x i1>, ptr %live.mask, align 1
  %7629 = and <8 x i1> %7625, %7628
  %7630 = icmp eq <8 x i1> %7627, %7629
  %7631 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7630)
  %7632 = and i1 %7622, %7631
  %7633 = select i1 %7632, <8 x i1> zeroinitializer, <8 x i1> %7627
  %7634 = select i1 %7622, <8 x i1> %7633, <8 x i1> %7626
  store <8 x i1> %7634, ptr %7624, align 1
  %7635 = select i1 %7632, <8 x i1> zeroinitializer, <8 x i1> %7625
  store <8 x i1> %7635, ptr %7623, align 1
  %7636 = trunc i32 %7612 to i8
  %7637 = shl i8 1, %7636
  %7638 = xor i8 %7637, -1
  %7639 = and i8 %7613, %7638
  %7640 = select i1 %7632, i8 %7639, i8 %7613
  store i8 %7640, ptr %frame.active, align 1
  %.splatinsert1450 = insertelement <8 x i1> poison, i1 %7622, i64 0
  %.splat1451 = shufflevector <8 x i1> %.splatinsert1450, <8 x i1> poison, <8 x i32> zeroinitializer
  %7641 = and <8 x i1> %convergence.cascade.flow1446, %.splat1451
  %7642 = load <8 x i1>, ptr %runnable.mask, align 1
  %7643 = xor <8 x i1> %7641, splat (i1 true)
  %7644 = and <8 x i1> %7642, %7643
  store <8 x i1> %7644, ptr %runnable.mask, align 1
  %.splatinsert1452 = insertelement <8 x i1> poison, i1 %7632, i64 0
  %.splat1453 = shufflevector <8 x i1> %.splatinsert1452, <8 x i1> poison, <8 x i32> zeroinitializer
  %7645 = select <8 x i1> %.splat1453, <8 x i1> %7627, <8 x i1> zeroinitializer
  %7646 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7647 = extractelement <8 x i32> %7646, i32 %7612
  %7648 = select i1 %7632, i32 %7647, i32 %7608
  store i32 %7648, ptr %current.token, align 4
  %.splatinsert1454 = insertelement <8 x i1> poison, i1 %7622, i64 0
  %.splat1455 = shufflevector <8 x i1> %.splatinsert1454, <8 x i1> poison, <8 x i32> zeroinitializer
  %7649 = select <8 x i1> %.splat1455, <8 x i1> %7645, <8 x i1> %convergence.cascade.flow1446
  %7650 = add i32 %convergence.cascade.depth1447, 1
  %7651 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7649)
  %7652 = icmp ult i32 %7650, 8
  %7653 = and i1 %7651, %7652
  %7654 = and i1 %7622, %7653
  %convergence.parent.token1456 = load i32, ptr %current.token, align 4
  %convergence.parent.present1457 = icmp ne i32 %convergence.parent.token1456, 0
  %7655 = and i1 %7654, %convergence.parent.present1457
  br i1 %7655, label %convergence.cascade1442, label %convergence.cascade.exit1443

convergence.cascade.exit1443:                     ; preds = %convergence.cascade1442, %schedule.74
  %convergence.cascade.result1458 = phi <8 x i1> [ %2014, %schedule.74 ], [ %7649, %convergence.cascade1442 ]
  %7656 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1458)
  br i1 %7656, label %convergence.target.74.ready, label %scheduler.loop

convergence.target.74.ready:                      ; preds = %convergence.cascade.exit1443
  %7657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1458)
  %7658 = bitcast <8 x i1> %convergence.cascade.result1458 to i8
  %7659 = call i8 @llvm.cttz.i8(i8 %7658, i1 false)
  %7660 = zext i8 %7659 to i32
  %7661 = select i1 %7657, i32 %7660, i32 0
  %7662 = load <8 x i64>, ptr %.slot56, align 64
  %7663 = select <8 x i1> %convergence.cascade.result1458, <8 x i64> zeroinitializer, <8 x i64> %7662
  store <8 x i64> %7663, ptr %.slot56, align 64
  %7664 = load <8 x float>, ptr %.slot66, align 32
  %7665 = select <8 x i1> %convergence.cascade.result1458, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %7664
  store <8 x float> %7665, ptr %.slot66, align 32
  store <8 x i1> %convergence.cascade.result1458, ptr %current.mask, align 1
  %7666 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1458)
  br i1 %7666, label %schedule.75, label %scheduler.loop

varying.divergent1460:                            ; preds = %schedule.75
  %7667 = load i32, ptr %current.token, align 4
  %7668 = icmp ne i32 %7667, 0
  %7669 = sub i32 %7667, 1
  %7670 = select i1 %7668, i32 %7669, i32 0
  %7671 = load i8, ptr %frame.active, align 1
  %7672 = trunc i32 %7670 to i8
  %7673 = shl i8 1, %7672
  %7674 = and i8 %7671, %7673
  %7675 = icmp ne i8 %7674, 0
  %7676 = load <8 x i32>, ptr %frame.static.id, align 32
  %7677 = extractelement <8 x i32> %7676, i32 %7670
  %7678 = icmp eq i32 %7677, 26
  %7679 = and i1 %7675, %7678
  %7680 = and i1 %7668, %7679
  %7681 = xor i1 %7680, true
  %7682 = and i1 true, %7681
  %7683 = xor i8 %7671, -1
  %7684 = icmp ne i8 %7683, 0
  %7685 = xor i1 %7684, true
  %7686 = and i1 %7682, %7685
  br i1 %7686, label %convergence.overflow.trap1462, label %convergence.overflow.resume1463

varying.coherent1461:                             ; preds = %schedule.75
  br i1 %2025, label %varying.coherent.true1466, label %varying.coherent.false1467

convergence.overflow.trap1462:                    ; preds = %varying.divergent1460
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1463:                  ; preds = %varying.divergent1460
  %7687 = call i8 @llvm.cttz.i8(i8 %7683, i1 false)
  %7688 = zext i8 %7687 to i32
  %7689 = select i1 %7684, i32 %7688, i32 0
  %7690 = trunc i32 %7689 to i8
  %7691 = shl i8 1, %7690
  %7692 = or i8 %7671, %7691
  %7693 = select i1 %7682, i8 %7692, i8 %7671
  store i8 %7693, ptr %frame.active, align 1
  %7694 = load <8 x i32>, ptr %frame.static.id, align 32
  %7695 = extractelement <8 x i32> %7694, i32 %7689
  %7696 = select i1 %7682, i32 26, i32 %7695
  %7697 = load <8 x i32>, ptr %frame.static.id, align 32
  %7698 = insertelement <8 x i32> %7697, i32 %7696, i32 %7689
  store <8 x i32> %7698, ptr %frame.static.id, align 32
  %7699 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7700 = extractelement <8 x i32> %7699, i32 %7689
  %7701 = select i1 %7682, i32 %7667, i32 %7700
  %7702 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7703 = insertelement <8 x i32> %7702, i32 %7701, i32 %7689
  store <8 x i32> %7703, ptr %frame.parent.token, align 32
  %7704 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7689
  %7705 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7689
  %7706 = load <8 x i1>, ptr %7704, align 1
  %7707 = load <8 x i1>, ptr %7705, align 1
  %7708 = select i1 %7682, <8 x i1> %2015, <8 x i1> %7706
  store <8 x i1> %7708, ptr %7704, align 1
  %7709 = select i1 %7682, <8 x i1> zeroinitializer, <8 x i1> %7707
  store <8 x i1> %7709, ptr %7705, align 1
  %7710 = add i32 %7689, 1
  %7711 = select i1 %7680, i32 %7667, i32 %7710
  %7712 = select i1 true, i32 %7711, i32 %7667
  store i32 %7712, ptr %current.token, align 4
  %7713 = load i32, ptr %current.token, align 4
  %7714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2022)
  %7715 = load i32, ptr %ready.count, align 4
  %7716 = icmp uge i32 %7715, 8
  %7717 = and i1 %7714, %7716
  br i1 %7717, label %ready.overflow.trap1464, label %ready.overflow.resume1465

ready.overflow.trap1464:                          ; preds = %convergence.overflow.resume1463
  call void @llvm.trap()
  unreachable

ready.overflow.resume1465:                        ; preds = %convergence.overflow.resume1463
  %7718 = select i1 %7714, i32 %7715, i32 0
  %7719 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7718
  %7720 = load <8 x i1>, ptr %7719, align 1
  %7721 = select i1 %7714, <8 x i1> %2022, <8 x i1> %7720
  store <8 x i1> %7721, ptr %7719, align 1
  %7722 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7718
  %7723 = load i32, ptr %7722, align 4
  %7724 = select i1 %7714, i32 76, i32 %7723
  store i32 %7724, ptr %7722, align 4
  %7725 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7718
  %7726 = load i32, ptr %7725, align 4
  %7727 = select i1 %7714, i32 %7713, i32 %7726
  store i32 %7727, ptr %7725, align 4
  %7728 = add i32 %7715, 1
  %7729 = select i1 %7714, i32 %7728, i32 %7715
  store i32 %7729, ptr %ready.count, align 4
  %7730 = load <8 x i1>, ptr %runnable.mask, align 1
  %7731 = or <8 x i1> %7730, %2022
  store <8 x i1> %7731, ptr %runnable.mask, align 1
  store <8 x i1> %2024, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1466:                        ; preds = %varying.coherent1461
  store <8 x i1> %2015, ptr %current.mask, align 1
  %7732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2015)
  br i1 %7732, label %schedule.76, label %scheduler.loop

varying.coherent.false1467:                       ; preds = %varying.coherent1461
  store <8 x i1> %2015, ptr %current.mask, align 1
  %7733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2015)
  br i1 %7733, label %schedule.77, label %scheduler.loop

convergence.cascade1472:                          ; preds = %convergence.cascade1472, %schedule.77
  %convergence.cascade.flow1476 = phi <8 x i1> [ %2055, %schedule.77 ], [ %7776, %convergence.cascade1472 ]
  %convergence.cascade.depth1477 = phi i32 [ 0, %schedule.77 ], [ %7777, %convergence.cascade1472 ]
  %7734 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1476)
  %7735 = load i32, ptr %current.token, align 4
  %7736 = icmp ne i32 %7735, 0
  %7737 = and i1 %7734, %7736
  %7738 = sub i32 %7735, 1
  %7739 = select i1 %7737, i32 %7738, i32 0
  %7740 = load i8, ptr %frame.active, align 1
  %7741 = trunc i32 %7739 to i8
  %7742 = shl i8 1, %7741
  %7743 = and i8 %7740, %7742
  %7744 = icmp ne i8 %7743, 0
  %7745 = load <8 x i32>, ptr %frame.static.id, align 32
  %7746 = extractelement <8 x i32> %7745, i32 %7739
  %convergence.target.pointer1478 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %7746
  %convergence.dynamic.target1479 = load i32, ptr %convergence.target.pointer1478, align 4
  %7747 = icmp eq i32 %convergence.dynamic.target1479, 77
  %7748 = and i1 %7744, %7747
  %7749 = and i1 %7737, %7748
  %7750 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7739
  %7751 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7739
  %7752 = load <8 x i1>, ptr %7750, align 1
  %7753 = load <8 x i1>, ptr %7751, align 1
  %7754 = or <8 x i1> %7753, %convergence.cascade.flow1476
  %7755 = load <8 x i1>, ptr %live.mask, align 1
  %7756 = and <8 x i1> %7752, %7755
  %7757 = icmp eq <8 x i1> %7754, %7756
  %7758 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7757)
  %7759 = and i1 %7749, %7758
  %7760 = select i1 %7759, <8 x i1> zeroinitializer, <8 x i1> %7754
  %7761 = select i1 %7749, <8 x i1> %7760, <8 x i1> %7753
  store <8 x i1> %7761, ptr %7751, align 1
  %7762 = select i1 %7759, <8 x i1> zeroinitializer, <8 x i1> %7752
  store <8 x i1> %7762, ptr %7750, align 1
  %7763 = trunc i32 %7739 to i8
  %7764 = shl i8 1, %7763
  %7765 = xor i8 %7764, -1
  %7766 = and i8 %7740, %7765
  %7767 = select i1 %7759, i8 %7766, i8 %7740
  store i8 %7767, ptr %frame.active, align 1
  %.splatinsert1480 = insertelement <8 x i1> poison, i1 %7749, i64 0
  %.splat1481 = shufflevector <8 x i1> %.splatinsert1480, <8 x i1> poison, <8 x i32> zeroinitializer
  %7768 = and <8 x i1> %convergence.cascade.flow1476, %.splat1481
  %7769 = load <8 x i1>, ptr %runnable.mask, align 1
  %7770 = xor <8 x i1> %7768, splat (i1 true)
  %7771 = and <8 x i1> %7769, %7770
  store <8 x i1> %7771, ptr %runnable.mask, align 1
  %.splatinsert1482 = insertelement <8 x i1> poison, i1 %7759, i64 0
  %.splat1483 = shufflevector <8 x i1> %.splatinsert1482, <8 x i1> poison, <8 x i32> zeroinitializer
  %7772 = select <8 x i1> %.splat1483, <8 x i1> %7754, <8 x i1> zeroinitializer
  %7773 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7774 = extractelement <8 x i32> %7773, i32 %7739
  %7775 = select i1 %7759, i32 %7774, i32 %7735
  store i32 %7775, ptr %current.token, align 4
  %.splatinsert1484 = insertelement <8 x i1> poison, i1 %7749, i64 0
  %.splat1485 = shufflevector <8 x i1> %.splatinsert1484, <8 x i1> poison, <8 x i32> zeroinitializer
  %7776 = select <8 x i1> %.splat1485, <8 x i1> %7772, <8 x i1> %convergence.cascade.flow1476
  %7777 = add i32 %convergence.cascade.depth1477, 1
  %7778 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7776)
  %7779 = icmp ult i32 %7777, 8
  %7780 = and i1 %7778, %7779
  %7781 = and i1 %7749, %7780
  %convergence.parent.token1486 = load i32, ptr %current.token, align 4
  %convergence.parent.present1487 = icmp ne i32 %convergence.parent.token1486, 0
  %7782 = and i1 %7781, %convergence.parent.present1487
  br i1 %7782, label %convergence.cascade1472, label %convergence.cascade.exit1473

convergence.cascade.exit1473:                     ; preds = %convergence.cascade1472, %schedule.77
  %convergence.cascade.result1488 = phi <8 x i1> [ %2055, %schedule.77 ], [ %7776, %convergence.cascade1472 ]
  %7783 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1488)
  br i1 %7783, label %convergence.target.77.ready, label %scheduler.loop

convergence.target.77.ready:                      ; preds = %convergence.cascade.exit1473
  %7784 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1488)
  %7785 = bitcast <8 x i1> %convergence.cascade.result1488 to i8
  %7786 = call i8 @llvm.cttz.i8(i8 %7785, i1 false)
  %7787 = zext i8 %7786 to i32
  %7788 = select i1 %7784, i32 %7787, i32 0
  %7789 = load <8 x i64>, ptr %.slot56, align 64
  %7790 = select <8 x i1> %convergence.cascade.result1488, <8 x i64> zeroinitializer, <8 x i64> %7789
  store <8 x i64> %7790, ptr %.slot56, align 64
  %7791 = load <8 x float>, ptr %.slot67, align 32
  %7792 = select <8 x i1> %convergence.cascade.result1488, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %7791
  store <8 x float> %7792, ptr %.slot67, align 32
  store <8 x i1> %convergence.cascade.result1488, ptr %current.mask, align 1
  %7793 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1488)
  br i1 %7793, label %schedule.78, label %scheduler.loop

varying.divergent1490:                            ; preds = %schedule.78
  %7794 = load i32, ptr %current.token, align 4
  %7795 = icmp ne i32 %7794, 0
  %7796 = sub i32 %7794, 1
  %7797 = select i1 %7795, i32 %7796, i32 0
  %7798 = load i8, ptr %frame.active, align 1
  %7799 = trunc i32 %7797 to i8
  %7800 = shl i8 1, %7799
  %7801 = and i8 %7798, %7800
  %7802 = icmp ne i8 %7801, 0
  %7803 = load <8 x i32>, ptr %frame.static.id, align 32
  %7804 = extractelement <8 x i32> %7803, i32 %7797
  %7805 = icmp eq i32 %7804, 27
  %7806 = and i1 %7802, %7805
  %7807 = and i1 %7795, %7806
  %7808 = xor i1 %7807, true
  %7809 = and i1 true, %7808
  %7810 = xor i8 %7798, -1
  %7811 = icmp ne i8 %7810, 0
  %7812 = xor i1 %7811, true
  %7813 = and i1 %7809, %7812
  br i1 %7813, label %convergence.overflow.trap1492, label %convergence.overflow.resume1493

varying.coherent1491:                             ; preds = %schedule.78
  br i1 %2066, label %varying.coherent.true1496, label %varying.coherent.false1497

convergence.overflow.trap1492:                    ; preds = %varying.divergent1490
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1493:                  ; preds = %varying.divergent1490
  %7814 = call i8 @llvm.cttz.i8(i8 %7810, i1 false)
  %7815 = zext i8 %7814 to i32
  %7816 = select i1 %7811, i32 %7815, i32 0
  %7817 = trunc i32 %7816 to i8
  %7818 = shl i8 1, %7817
  %7819 = or i8 %7798, %7818
  %7820 = select i1 %7809, i8 %7819, i8 %7798
  store i8 %7820, ptr %frame.active, align 1
  %7821 = load <8 x i32>, ptr %frame.static.id, align 32
  %7822 = extractelement <8 x i32> %7821, i32 %7816
  %7823 = select i1 %7809, i32 27, i32 %7822
  %7824 = load <8 x i32>, ptr %frame.static.id, align 32
  %7825 = insertelement <8 x i32> %7824, i32 %7823, i32 %7816
  store <8 x i32> %7825, ptr %frame.static.id, align 32
  %7826 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7827 = extractelement <8 x i32> %7826, i32 %7816
  %7828 = select i1 %7809, i32 %7794, i32 %7827
  %7829 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7830 = insertelement <8 x i32> %7829, i32 %7828, i32 %7816
  store <8 x i32> %7830, ptr %frame.parent.token, align 32
  %7831 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7816
  %7832 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7816
  %7833 = load <8 x i1>, ptr %7831, align 1
  %7834 = load <8 x i1>, ptr %7832, align 1
  %7835 = select i1 %7809, <8 x i1> %2056, <8 x i1> %7833
  store <8 x i1> %7835, ptr %7831, align 1
  %7836 = select i1 %7809, <8 x i1> zeroinitializer, <8 x i1> %7834
  store <8 x i1> %7836, ptr %7832, align 1
  %7837 = add i32 %7816, 1
  %7838 = select i1 %7807, i32 %7794, i32 %7837
  %7839 = select i1 true, i32 %7838, i32 %7794
  store i32 %7839, ptr %current.token, align 4
  %7840 = load i32, ptr %current.token, align 4
  %7841 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2063)
  %7842 = load i32, ptr %ready.count, align 4
  %7843 = icmp uge i32 %7842, 8
  %7844 = and i1 %7841, %7843
  br i1 %7844, label %ready.overflow.trap1494, label %ready.overflow.resume1495

ready.overflow.trap1494:                          ; preds = %convergence.overflow.resume1493
  call void @llvm.trap()
  unreachable

ready.overflow.resume1495:                        ; preds = %convergence.overflow.resume1493
  %7845 = select i1 %7841, i32 %7842, i32 0
  %7846 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7845
  %7847 = load <8 x i1>, ptr %7846, align 1
  %7848 = select i1 %7841, <8 x i1> %2063, <8 x i1> %7847
  store <8 x i1> %7848, ptr %7846, align 1
  %7849 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7845
  %7850 = load i32, ptr %7849, align 4
  %7851 = select i1 %7841, i32 79, i32 %7850
  store i32 %7851, ptr %7849, align 4
  %7852 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7845
  %7853 = load i32, ptr %7852, align 4
  %7854 = select i1 %7841, i32 %7840, i32 %7853
  store i32 %7854, ptr %7852, align 4
  %7855 = add i32 %7842, 1
  %7856 = select i1 %7841, i32 %7855, i32 %7842
  store i32 %7856, ptr %ready.count, align 4
  %7857 = load <8 x i1>, ptr %runnable.mask, align 1
  %7858 = or <8 x i1> %7857, %2063
  store <8 x i1> %7858, ptr %runnable.mask, align 1
  store <8 x i1> %2065, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1496:                        ; preds = %varying.coherent1491
  store <8 x i1> %2056, ptr %current.mask, align 1
  %7859 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2056)
  br i1 %7859, label %schedule.79, label %scheduler.loop

varying.coherent.false1497:                       ; preds = %varying.coherent1491
  store <8 x i1> %2056, ptr %current.mask, align 1
  %7860 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2056)
  br i1 %7860, label %schedule.80, label %scheduler.loop

convergence.cascade1502:                          ; preds = %convergence.cascade1502, %schedule.80
  %convergence.cascade.flow1506 = phi <8 x i1> [ %2096, %schedule.80 ], [ %7903, %convergence.cascade1502 ]
  %convergence.cascade.depth1507 = phi i32 [ 0, %schedule.80 ], [ %7904, %convergence.cascade1502 ]
  %7861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1506)
  %7862 = load i32, ptr %current.token, align 4
  %7863 = icmp ne i32 %7862, 0
  %7864 = and i1 %7861, %7863
  %7865 = sub i32 %7862, 1
  %7866 = select i1 %7864, i32 %7865, i32 0
  %7867 = load i8, ptr %frame.active, align 1
  %7868 = trunc i32 %7866 to i8
  %7869 = shl i8 1, %7868
  %7870 = and i8 %7867, %7869
  %7871 = icmp ne i8 %7870, 0
  %7872 = load <8 x i32>, ptr %frame.static.id, align 32
  %7873 = extractelement <8 x i32> %7872, i32 %7866
  %convergence.target.pointer1508 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %7873
  %convergence.dynamic.target1509 = load i32, ptr %convergence.target.pointer1508, align 4
  %7874 = icmp eq i32 %convergence.dynamic.target1509, 80
  %7875 = and i1 %7871, %7874
  %7876 = and i1 %7864, %7875
  %7877 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7866
  %7878 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7866
  %7879 = load <8 x i1>, ptr %7877, align 1
  %7880 = load <8 x i1>, ptr %7878, align 1
  %7881 = or <8 x i1> %7880, %convergence.cascade.flow1506
  %7882 = load <8 x i1>, ptr %live.mask, align 1
  %7883 = and <8 x i1> %7879, %7882
  %7884 = icmp eq <8 x i1> %7881, %7883
  %7885 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7884)
  %7886 = and i1 %7876, %7885
  %7887 = select i1 %7886, <8 x i1> zeroinitializer, <8 x i1> %7881
  %7888 = select i1 %7876, <8 x i1> %7887, <8 x i1> %7880
  store <8 x i1> %7888, ptr %7878, align 1
  %7889 = select i1 %7886, <8 x i1> zeroinitializer, <8 x i1> %7879
  store <8 x i1> %7889, ptr %7877, align 1
  %7890 = trunc i32 %7866 to i8
  %7891 = shl i8 1, %7890
  %7892 = xor i8 %7891, -1
  %7893 = and i8 %7867, %7892
  %7894 = select i1 %7886, i8 %7893, i8 %7867
  store i8 %7894, ptr %frame.active, align 1
  %.splatinsert1510 = insertelement <8 x i1> poison, i1 %7876, i64 0
  %.splat1511 = shufflevector <8 x i1> %.splatinsert1510, <8 x i1> poison, <8 x i32> zeroinitializer
  %7895 = and <8 x i1> %convergence.cascade.flow1506, %.splat1511
  %7896 = load <8 x i1>, ptr %runnable.mask, align 1
  %7897 = xor <8 x i1> %7895, splat (i1 true)
  %7898 = and <8 x i1> %7896, %7897
  store <8 x i1> %7898, ptr %runnable.mask, align 1
  %.splatinsert1512 = insertelement <8 x i1> poison, i1 %7886, i64 0
  %.splat1513 = shufflevector <8 x i1> %.splatinsert1512, <8 x i1> poison, <8 x i32> zeroinitializer
  %7899 = select <8 x i1> %.splat1513, <8 x i1> %7881, <8 x i1> zeroinitializer
  %7900 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7901 = extractelement <8 x i32> %7900, i32 %7866
  %7902 = select i1 %7886, i32 %7901, i32 %7862
  store i32 %7902, ptr %current.token, align 4
  %.splatinsert1514 = insertelement <8 x i1> poison, i1 %7876, i64 0
  %.splat1515 = shufflevector <8 x i1> %.splatinsert1514, <8 x i1> poison, <8 x i32> zeroinitializer
  %7903 = select <8 x i1> %.splat1515, <8 x i1> %7899, <8 x i1> %convergence.cascade.flow1506
  %7904 = add i32 %convergence.cascade.depth1507, 1
  %7905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7903)
  %7906 = icmp ult i32 %7904, 8
  %7907 = and i1 %7905, %7906
  %7908 = and i1 %7876, %7907
  %convergence.parent.token1516 = load i32, ptr %current.token, align 4
  %convergence.parent.present1517 = icmp ne i32 %convergence.parent.token1516, 0
  %7909 = and i1 %7908, %convergence.parent.present1517
  br i1 %7909, label %convergence.cascade1502, label %convergence.cascade.exit1503

convergence.cascade.exit1503:                     ; preds = %convergence.cascade1502, %schedule.80
  %convergence.cascade.result1518 = phi <8 x i1> [ %2096, %schedule.80 ], [ %7903, %convergence.cascade1502 ]
  %7910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  br i1 %7910, label %convergence.target.80.ready, label %scheduler.loop

convergence.target.80.ready:                      ; preds = %convergence.cascade.exit1503
  %7911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %7912 = bitcast <8 x i1> %convergence.cascade.result1518 to i8
  %7913 = call i8 @llvm.cttz.i8(i8 %7912, i1 false)
  %7914 = zext i8 %7913 to i32
  %7915 = select i1 %7911, i32 %7914, i32 0
  %.state1519 = load <8 x float>, ptr %.slot41, align 32
  %.state1520 = load <8 x float>, ptr %.slot58, align 32
  %7916 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1519, <8 x float> %.state1520)
  %7917 = load <8 x float>, ptr %.spill280, align 32
  %7918 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %7916, <8 x float> %7917
  store <8 x float> %7918, ptr %.spill280, align 32
  %.state1521 = load <8 x float>, ptr %.slot47, align 32
  %.state1522 = load <8 x float>, ptr %.slot65, align 32
  %7919 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1521, <8 x float> %.state1522)
  %7920 = load <8 x float>, ptr %.spill281, align 32
  %7921 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %7919, <8 x float> %7920
  store <8 x float> %7921, ptr %.spill281, align 32
  %.state1523 = load <8 x float>, ptr %.slot48, align 32
  %.state1524 = load <8 x float>, ptr %.slot66, align 32
  %7922 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1523, <8 x float> %.state1524)
  %7923 = load <8 x float>, ptr %.spill282, align 32
  %7924 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %7922, <8 x float> %7923
  store <8 x float> %7924, ptr %.spill282, align 32
  %.state1525 = load <8 x float>, ptr %.slot49, align 32
  %.state1526 = load <8 x float>, ptr %.slot67, align 32
  %7925 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1525, <8 x float> %.state1526)
  %7926 = load <8 x float>, ptr %.spill283, align 32
  %7927 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %7925, <8 x float> %7926
  store <8 x float> %7927, ptr %.spill283, align 32
  %.state1527 = load <8 x float>, ptr %.slot41, align 32
  %7928 = fsub <8 x float> %.state1527, %7916
  %.state1528 = load <8 x float>, ptr %.slot47, align 32
  %7929 = fsub <8 x float> %.state1528, %7919
  %.state1529 = load <8 x float>, ptr %.slot48, align 32
  %7930 = fsub <8 x float> %.state1529, %7922
  %.state1530 = load <8 x float>, ptr %.slot49, align 32
  %7931 = fsub <8 x float> %.state1530, %7925
  %7932 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %7928, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7932)
  %7933 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %7929, <8 x float> zeroinitializer
  %native.exp1531 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7933)
  %7934 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %7930, <8 x float> zeroinitializer
  %native.exp1532 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7934)
  %7935 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %7931, <8 x float> zeroinitializer
  %native.exp1533 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7935)
  %7936 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill284, align 64
  %7937 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7938 = extractvalue { <8 x ptr>, <8 x i64> } %7936, 0
  %7939 = select <8 x i1> %convergence.cascade.result1518, <8 x ptr> %7937, <8 x ptr> %7938
  %7940 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7941 = extractvalue { <8 x ptr>, <8 x i64> } %7936, 1
  %7942 = select <8 x i1> %convergence.cascade.result1518, <8 x i64> %7940, <8 x i64> %7941
  %7943 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7939, 0
  %7944 = insertvalue { <8 x ptr>, <8 x i64> } %7943, <8 x i64> %7942, 1
  store { <8 x ptr>, <8 x i64> } %7944, ptr %tile_snapshot.spill284, align 64
  %7945 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7946 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7947 = add <8 x i64> %7946, zeroinitializer
  %7948 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7945, 0
  %7949 = insertvalue { <8 x ptr>, <8 x i64> } %7948, <8 x i64> %7947, 1
  %7950 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7951 = extractvalue { <8 x ptr>, <8 x i64> } %7949, 1
  %7952 = extractelement <8 x ptr> %7950, i32 0
  %7953 = extractelement <8 x i64> %7951, i32 %7915
  %7954 = zext i32 %7915 to i64
  %7955 = mul i64 %7954, 4
  %7956 = sub i64 %7953, %7955
  %7957 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %7958 = select i1 %7957, i64 %7956, i64 0
  %private.contiguous.address1534 = getelementptr i8, ptr %7952, i64 %7958
  %private.contiguous.preserve1535 = load <8 x float>, ptr %private.contiguous.address1534, align 4
  %7959 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve1535
  store <8 x float> %7959, ptr %private.contiguous.address1534, align 4
  %7960 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7961 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7962 = add <8 x i64> %7961, splat (i64 32)
  %7963 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7960, 0
  %7964 = insertvalue { <8 x ptr>, <8 x i64> } %7963, <8 x i64> %7962, 1
  %7965 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7966 = extractvalue { <8 x ptr>, <8 x i64> } %7964, 1
  %7967 = extractelement <8 x ptr> %7965, i32 0
  %7968 = extractelement <8 x i64> %7966, i32 %7915
  %7969 = zext i32 %7915 to i64
  %7970 = mul i64 %7969, 4
  %7971 = sub i64 %7968, %7970
  %7972 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %7973 = select i1 %7972, i64 %7971, i64 0
  %private.contiguous.address1536 = getelementptr i8, ptr %7967, i64 %7973
  %private.contiguous.preserve1537 = load <8 x float>, ptr %private.contiguous.address1536, align 4
  %7974 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %native.exp1531, <8 x float> %private.contiguous.preserve1537
  store <8 x float> %7974, ptr %private.contiguous.address1536, align 4
  %7975 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7976 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7977 = add <8 x i64> %7976, splat (i64 64)
  %7978 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7975, 0
  %7979 = insertvalue { <8 x ptr>, <8 x i64> } %7978, <8 x i64> %7977, 1
  %7980 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7981 = extractvalue { <8 x ptr>, <8 x i64> } %7979, 1
  %7982 = extractelement <8 x ptr> %7980, i32 0
  %7983 = extractelement <8 x i64> %7981, i32 %7915
  %7984 = zext i32 %7915 to i64
  %7985 = mul i64 %7984, 4
  %7986 = sub i64 %7983, %7985
  %7987 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %7988 = select i1 %7987, i64 %7986, i64 0
  %private.contiguous.address1538 = getelementptr i8, ptr %7982, i64 %7988
  %private.contiguous.preserve1539 = load <8 x float>, ptr %private.contiguous.address1538, align 4
  %7989 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %native.exp1532, <8 x float> %private.contiguous.preserve1539
  store <8 x float> %7989, ptr %private.contiguous.address1538, align 4
  %7990 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7991 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7992 = add <8 x i64> %7991, splat (i64 96)
  %7993 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7990, 0
  %7994 = insertvalue { <8 x ptr>, <8 x i64> } %7993, <8 x i64> %7992, 1
  %7995 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7996 = extractvalue { <8 x ptr>, <8 x i64> } %7994, 1
  %7997 = extractelement <8 x ptr> %7995, i32 0
  %7998 = extractelement <8 x i64> %7996, i32 %7915
  %7999 = zext i32 %7915 to i64
  %8000 = mul i64 %7999, 4
  %8001 = sub i64 %7998, %8000
  %8002 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8003 = select i1 %8002, i64 %8001, i64 0
  %private.contiguous.address1540 = getelementptr i8, ptr %7997, i64 %8003
  %private.contiguous.preserve1541 = load <8 x float>, ptr %private.contiguous.address1540, align 4
  %8004 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %native.exp1533, <8 x float> %private.contiguous.preserve1541
  store <8 x float> %8004, ptr %private.contiguous.address1540, align 4
  %.spill.load1542 = load <8 x float>, ptr %.spill207, align 32
  %8005 = fsub <8 x float> %.spill.load1542, %7916
  %.spill.load1543 = load <8 x float>, ptr %.spill208, align 32
  %8006 = fsub <8 x float> %.spill.load1543, %7916
  %.spill.load1544 = load <8 x float>, ptr %.spill209, align 32
  %8007 = fsub <8 x float> %.spill.load1544, %7916
  %.spill.load1545 = load <8 x float>, ptr %.spill210, align 32
  %8008 = fsub <8 x float> %.spill.load1545, %7916
  %.spill.load1546 = load <8 x float>, ptr %.spill211, align 32
  %8009 = fsub <8 x float> %.spill.load1546, %7916
  %.spill.load1547 = load <8 x float>, ptr %.spill212, align 32
  %8010 = fsub <8 x float> %.spill.load1547, %7916
  %.spill.load1548 = load <8 x float>, ptr %.spill213, align 32
  %8011 = fsub <8 x float> %.spill.load1548, %7916
  %.spill.load1549 = load <8 x float>, ptr %.spill214, align 32
  %8012 = fsub <8 x float> %.spill.load1549, %7916
  %.spill.load1550 = load <8 x float>, ptr %.spill215, align 32
  %8013 = fsub <8 x float> %.spill.load1550, %7916
  %.spill.load1551 = load <8 x float>, ptr %.spill216, align 32
  %8014 = fsub <8 x float> %.spill.load1551, %7916
  %.spill.load1552 = load <8 x float>, ptr %.spill217, align 32
  %8015 = fsub <8 x float> %.spill.load1552, %7916
  %.spill.load1553 = load <8 x float>, ptr %.spill218, align 32
  %8016 = fsub <8 x float> %.spill.load1553, %7916
  %.spill.load1554 = load <8 x float>, ptr %.spill219, align 32
  %8017 = fsub <8 x float> %.spill.load1554, %7916
  %.spill.load1555 = load <8 x float>, ptr %.spill220, align 32
  %8018 = fsub <8 x float> %.spill.load1555, %7916
  %.spill.load1556 = load <8 x float>, ptr %.spill221, align 32
  %8019 = fsub <8 x float> %.spill.load1556, %7916
  %.spill.load1557 = load <8 x float>, ptr %.spill222, align 32
  %8020 = fsub <8 x float> %.spill.load1557, %7916
  %.spill.load1558 = load <8 x float>, ptr %.spill223, align 32
  %8021 = fsub <8 x float> %.spill.load1558, %7919
  %.spill.load1559 = load <8 x float>, ptr %.spill224, align 32
  %8022 = fsub <8 x float> %.spill.load1559, %7919
  %.spill.load1560 = load <8 x float>, ptr %.spill225, align 32
  %8023 = fsub <8 x float> %.spill.load1560, %7919
  %.spill.load1561 = load <8 x float>, ptr %.spill226, align 32
  %8024 = fsub <8 x float> %.spill.load1561, %7919
  %.spill.load1562 = load <8 x float>, ptr %.spill227, align 32
  %8025 = fsub <8 x float> %.spill.load1562, %7919
  %.spill.load1563 = load <8 x float>, ptr %.spill228, align 32
  %8026 = fsub <8 x float> %.spill.load1563, %7919
  %.spill.load1564 = load <8 x float>, ptr %.spill229, align 32
  %8027 = fsub <8 x float> %.spill.load1564, %7919
  %.spill.load1565 = load <8 x float>, ptr %.spill230, align 32
  %8028 = fsub <8 x float> %.spill.load1565, %7919
  %.spill.load1566 = load <8 x float>, ptr %.spill231, align 32
  %8029 = fsub <8 x float> %.spill.load1566, %7919
  %.spill.load1567 = load <8 x float>, ptr %.spill232, align 32
  %8030 = fsub <8 x float> %.spill.load1567, %7919
  %.spill.load1568 = load <8 x float>, ptr %.spill233, align 32
  %8031 = fsub <8 x float> %.spill.load1568, %7919
  %.spill.load1569 = load <8 x float>, ptr %.spill234, align 32
  %8032 = fsub <8 x float> %.spill.load1569, %7919
  %.spill.load1570 = load <8 x float>, ptr %.spill235, align 32
  %8033 = fsub <8 x float> %.spill.load1570, %7919
  %.spill.load1571 = load <8 x float>, ptr %.spill236, align 32
  %8034 = fsub <8 x float> %.spill.load1571, %7919
  %.spill.load1572 = load <8 x float>, ptr %.spill237, align 32
  %8035 = fsub <8 x float> %.spill.load1572, %7919
  %.spill.load1573 = load <8 x float>, ptr %.spill238, align 32
  %8036 = fsub <8 x float> %.spill.load1573, %7919
  %.spill.load1574 = load <8 x float>, ptr %.spill239, align 32
  %8037 = fsub <8 x float> %.spill.load1574, %7922
  %.spill.load1575 = load <8 x float>, ptr %.spill240, align 32
  %8038 = fsub <8 x float> %.spill.load1575, %7922
  %.spill.load1576 = load <8 x float>, ptr %.spill241, align 32
  %8039 = fsub <8 x float> %.spill.load1576, %7922
  %.spill.load1577 = load <8 x float>, ptr %.spill242, align 32
  %8040 = fsub <8 x float> %.spill.load1577, %7922
  %.spill.load1578 = load <8 x float>, ptr %.spill243, align 32
  %8041 = fsub <8 x float> %.spill.load1578, %7922
  %.spill.load1579 = load <8 x float>, ptr %.spill244, align 32
  %8042 = fsub <8 x float> %.spill.load1579, %7922
  %.spill.load1580 = load <8 x float>, ptr %.spill245, align 32
  %8043 = fsub <8 x float> %.spill.load1580, %7922
  %.spill.load1581 = load <8 x float>, ptr %.spill246, align 32
  %8044 = fsub <8 x float> %.spill.load1581, %7922
  %.spill.load1582 = load <8 x float>, ptr %.spill247, align 32
  %8045 = fsub <8 x float> %.spill.load1582, %7922
  %.spill.load1583 = load <8 x float>, ptr %.spill248, align 32
  %8046 = fsub <8 x float> %.spill.load1583, %7922
  %.spill.load1584 = load <8 x float>, ptr %.spill249, align 32
  %8047 = fsub <8 x float> %.spill.load1584, %7922
  %.spill.load1585 = load <8 x float>, ptr %.spill250, align 32
  %8048 = fsub <8 x float> %.spill.load1585, %7922
  %.spill.load1586 = load <8 x float>, ptr %.spill251, align 32
  %8049 = fsub <8 x float> %.spill.load1586, %7922
  %.spill.load1587 = load <8 x float>, ptr %.spill252, align 32
  %8050 = fsub <8 x float> %.spill.load1587, %7922
  %.spill.load1588 = load <8 x float>, ptr %.spill253, align 32
  %8051 = fsub <8 x float> %.spill.load1588, %7922
  %.spill.load1589 = load <8 x float>, ptr %.spill254, align 32
  %8052 = fsub <8 x float> %.spill.load1589, %7922
  %.spill.load1590 = load <8 x float>, ptr %.spill255, align 32
  %8053 = fsub <8 x float> %.spill.load1590, %7925
  %.spill.load1591 = load <8 x float>, ptr %.spill256, align 32
  %8054 = fsub <8 x float> %.spill.load1591, %7925
  %.spill.load1592 = load <8 x float>, ptr %.spill257, align 32
  %8055 = fsub <8 x float> %.spill.load1592, %7925
  %.spill.load1593 = load <8 x float>, ptr %.spill258, align 32
  %8056 = fsub <8 x float> %.spill.load1593, %7925
  %.spill.load1594 = load <8 x float>, ptr %.spill259, align 32
  %8057 = fsub <8 x float> %.spill.load1594, %7925
  %.spill.load1595 = load <8 x float>, ptr %.spill260, align 32
  %8058 = fsub <8 x float> %.spill.load1595, %7925
  %.spill.load1596 = load <8 x float>, ptr %.spill261, align 32
  %8059 = fsub <8 x float> %.spill.load1596, %7925
  %.spill.load1597 = load <8 x float>, ptr %.spill262, align 32
  %8060 = fsub <8 x float> %.spill.load1597, %7925
  %.spill.load1598 = load <8 x float>, ptr %.spill263, align 32
  %8061 = fsub <8 x float> %.spill.load1598, %7925
  %.spill.load1599 = load <8 x float>, ptr %.spill264, align 32
  %8062 = fsub <8 x float> %.spill.load1599, %7925
  %.spill.load1600 = load <8 x float>, ptr %.spill265, align 32
  %8063 = fsub <8 x float> %.spill.load1600, %7925
  %.spill.load1601 = load <8 x float>, ptr %.spill266, align 32
  %8064 = fsub <8 x float> %.spill.load1601, %7925
  %.spill.load1602 = load <8 x float>, ptr %.spill267, align 32
  %8065 = fsub <8 x float> %.spill.load1602, %7925
  %.spill.load1603 = load <8 x float>, ptr %.spill268, align 32
  %8066 = fsub <8 x float> %.spill.load1603, %7925
  %.spill.load1604 = load <8 x float>, ptr %.spill269, align 32
  %8067 = fsub <8 x float> %.spill.load1604, %7925
  %.spill.load1605 = load <8 x float>, ptr %.spill270, align 32
  %8068 = fsub <8 x float> %.spill.load1605, %7925
  %8069 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8005, <8 x float> zeroinitializer
  %native.exp1606 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8069)
  %8070 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8006, <8 x float> zeroinitializer
  %native.exp1607 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8070)
  %8071 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8007, <8 x float> zeroinitializer
  %native.exp1608 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8071)
  %8072 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8008, <8 x float> zeroinitializer
  %native.exp1609 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8072)
  %8073 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8009, <8 x float> zeroinitializer
  %native.exp1610 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8073)
  %8074 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8010, <8 x float> zeroinitializer
  %native.exp1611 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8074)
  %8075 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8011, <8 x float> zeroinitializer
  %native.exp1612 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8075)
  %8076 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8012, <8 x float> zeroinitializer
  %native.exp1613 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8076)
  %8077 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8013, <8 x float> zeroinitializer
  %native.exp1614 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8077)
  %8078 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8014, <8 x float> zeroinitializer
  %native.exp1615 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8078)
  %8079 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8015, <8 x float> zeroinitializer
  %native.exp1616 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8079)
  %8080 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8016, <8 x float> zeroinitializer
  %native.exp1617 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8080)
  %8081 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8017, <8 x float> zeroinitializer
  %native.exp1618 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8081)
  %8082 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8018, <8 x float> zeroinitializer
  %native.exp1619 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8082)
  %8083 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8019, <8 x float> zeroinitializer
  %native.exp1620 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8083)
  %8084 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8020, <8 x float> zeroinitializer
  %native.exp1621 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8084)
  %8085 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8021, <8 x float> zeroinitializer
  %native.exp1622 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8085)
  %8086 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8022, <8 x float> zeroinitializer
  %native.exp1623 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8086)
  %8087 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8023, <8 x float> zeroinitializer
  %native.exp1624 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8087)
  %8088 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8024, <8 x float> zeroinitializer
  %native.exp1625 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8088)
  %8089 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8025, <8 x float> zeroinitializer
  %native.exp1626 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8089)
  %8090 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8026, <8 x float> zeroinitializer
  %native.exp1627 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8090)
  %8091 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8027, <8 x float> zeroinitializer
  %native.exp1628 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8091)
  %8092 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8028, <8 x float> zeroinitializer
  %native.exp1629 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8092)
  %8093 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8029, <8 x float> zeroinitializer
  %native.exp1630 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8093)
  %8094 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8030, <8 x float> zeroinitializer
  %native.exp1631 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8094)
  %8095 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8031, <8 x float> zeroinitializer
  %native.exp1632 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8095)
  %8096 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8032, <8 x float> zeroinitializer
  %native.exp1633 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8096)
  %8097 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8033, <8 x float> zeroinitializer
  %native.exp1634 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8097)
  %8098 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8034, <8 x float> zeroinitializer
  %native.exp1635 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8098)
  %8099 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8035, <8 x float> zeroinitializer
  %native.exp1636 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8099)
  %8100 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8036, <8 x float> zeroinitializer
  %native.exp1637 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8100)
  %8101 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8037, <8 x float> zeroinitializer
  %native.exp1638 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8101)
  %8102 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8038, <8 x float> zeroinitializer
  %native.exp1639 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8102)
  %8103 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8039, <8 x float> zeroinitializer
  %native.exp1640 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8103)
  %8104 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8040, <8 x float> zeroinitializer
  %native.exp1641 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8104)
  %8105 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8041, <8 x float> zeroinitializer
  %native.exp1642 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8105)
  %8106 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8042, <8 x float> zeroinitializer
  %native.exp1643 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8106)
  %8107 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8043, <8 x float> zeroinitializer
  %native.exp1644 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8107)
  %8108 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8044, <8 x float> zeroinitializer
  %native.exp1645 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8108)
  %8109 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8045, <8 x float> zeroinitializer
  %native.exp1646 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8109)
  %8110 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8046, <8 x float> zeroinitializer
  %native.exp1647 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8110)
  %8111 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8047, <8 x float> zeroinitializer
  %native.exp1648 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8111)
  %8112 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8048, <8 x float> zeroinitializer
  %native.exp1649 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8112)
  %8113 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8049, <8 x float> zeroinitializer
  %native.exp1650 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8113)
  %8114 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8050, <8 x float> zeroinitializer
  %native.exp1651 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8114)
  %8115 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8051, <8 x float> zeroinitializer
  %native.exp1652 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8115)
  %8116 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8052, <8 x float> zeroinitializer
  %native.exp1653 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8116)
  %8117 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8053, <8 x float> zeroinitializer
  %native.exp1654 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8117)
  %8118 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8054, <8 x float> zeroinitializer
  %native.exp1655 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8118)
  %8119 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8055, <8 x float> zeroinitializer
  %native.exp1656 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8119)
  %8120 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8056, <8 x float> zeroinitializer
  %native.exp1657 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8120)
  %8121 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8057, <8 x float> zeroinitializer
  %native.exp1658 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8121)
  %8122 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8058, <8 x float> zeroinitializer
  %native.exp1659 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8122)
  %8123 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8059, <8 x float> zeroinitializer
  %native.exp1660 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8123)
  %8124 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8060, <8 x float> zeroinitializer
  %native.exp1661 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8124)
  %8125 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8061, <8 x float> zeroinitializer
  %native.exp1662 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8125)
  %8126 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8062, <8 x float> zeroinitializer
  %native.exp1663 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8126)
  %8127 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8063, <8 x float> zeroinitializer
  %native.exp1664 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8127)
  %8128 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8064, <8 x float> zeroinitializer
  %native.exp1665 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8128)
  %8129 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8065, <8 x float> zeroinitializer
  %native.exp1666 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8129)
  %8130 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8066, <8 x float> zeroinitializer
  %native.exp1667 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8130)
  %8131 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8067, <8 x float> zeroinitializer
  %native.exp1668 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8131)
  %8132 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8068, <8 x float> zeroinitializer
  %native.exp1669 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %8132)
  %.spill.load1670 = load <8 x i1>, ptr %.spill143, align 1
  %8133 = select <8 x i1> %.spill.load1670, <8 x float> %native.exp1606, <8 x float> zeroinitializer
  %.spill.load1671 = load <8 x i1>, ptr %.spill147, align 1
  %8134 = select <8 x i1> %.spill.load1671, <8 x float> %native.exp1607, <8 x float> zeroinitializer
  %.spill.load1672 = load <8 x i1>, ptr %.spill151, align 1
  %8135 = select <8 x i1> %.spill.load1672, <8 x float> %native.exp1608, <8 x float> zeroinitializer
  %.spill.load1673 = load <8 x i1>, ptr %.spill155, align 1
  %8136 = select <8 x i1> %.spill.load1673, <8 x float> %native.exp1609, <8 x float> zeroinitializer
  %.spill.load1674 = load <8 x i1>, ptr %.spill159, align 1
  %8137 = select <8 x i1> %.spill.load1674, <8 x float> %native.exp1610, <8 x float> zeroinitializer
  %.spill.load1675 = load <8 x i1>, ptr %.spill163, align 1
  %8138 = select <8 x i1> %.spill.load1675, <8 x float> %native.exp1611, <8 x float> zeroinitializer
  %.spill.load1676 = load <8 x i1>, ptr %.spill167, align 1
  %8139 = select <8 x i1> %.spill.load1676, <8 x float> %native.exp1612, <8 x float> zeroinitializer
  %.spill.load1677 = load <8 x i1>, ptr %.spill171, align 1
  %8140 = select <8 x i1> %.spill.load1677, <8 x float> %native.exp1613, <8 x float> zeroinitializer
  %.spill.load1678 = load <8 x i1>, ptr %.spill175, align 1
  %8141 = select <8 x i1> %.spill.load1678, <8 x float> %native.exp1614, <8 x float> zeroinitializer
  %.spill.load1679 = load <8 x i1>, ptr %.spill179, align 1
  %8142 = select <8 x i1> %.spill.load1679, <8 x float> %native.exp1615, <8 x float> zeroinitializer
  %.spill.load1680 = load <8 x i1>, ptr %.spill183, align 1
  %8143 = select <8 x i1> %.spill.load1680, <8 x float> %native.exp1616, <8 x float> zeroinitializer
  %.spill.load1681 = load <8 x i1>, ptr %.spill187, align 1
  %8144 = select <8 x i1> %.spill.load1681, <8 x float> %native.exp1617, <8 x float> zeroinitializer
  %.spill.load1682 = load <8 x i1>, ptr %.spill191, align 1
  %8145 = select <8 x i1> %.spill.load1682, <8 x float> %native.exp1618, <8 x float> zeroinitializer
  %.spill.load1683 = load <8 x i1>, ptr %.spill195, align 1
  %8146 = select <8 x i1> %.spill.load1683, <8 x float> %native.exp1619, <8 x float> zeroinitializer
  %.spill.load1684 = load <8 x i1>, ptr %.spill199, align 1
  %8147 = select <8 x i1> %.spill.load1684, <8 x float> %native.exp1620, <8 x float> zeroinitializer
  %.spill.load1685 = load <8 x i1>, ptr %.spill203, align 1
  %8148 = select <8 x i1> %.spill.load1685, <8 x float> %native.exp1621, <8 x float> zeroinitializer
  %.spill.load1686 = load <8 x i1>, ptr %.spill144, align 1
  %8149 = select <8 x i1> %.spill.load1686, <8 x float> %native.exp1622, <8 x float> zeroinitializer
  %.spill.load1687 = load <8 x i1>, ptr %.spill148, align 1
  %8150 = select <8 x i1> %.spill.load1687, <8 x float> %native.exp1623, <8 x float> zeroinitializer
  %.spill.load1688 = load <8 x i1>, ptr %.spill152, align 1
  %8151 = select <8 x i1> %.spill.load1688, <8 x float> %native.exp1624, <8 x float> zeroinitializer
  %.spill.load1689 = load <8 x i1>, ptr %.spill156, align 1
  %8152 = select <8 x i1> %.spill.load1689, <8 x float> %native.exp1625, <8 x float> zeroinitializer
  %.spill.load1690 = load <8 x i1>, ptr %.spill160, align 1
  %8153 = select <8 x i1> %.spill.load1690, <8 x float> %native.exp1626, <8 x float> zeroinitializer
  %.spill.load1691 = load <8 x i1>, ptr %.spill164, align 1
  %8154 = select <8 x i1> %.spill.load1691, <8 x float> %native.exp1627, <8 x float> zeroinitializer
  %.spill.load1692 = load <8 x i1>, ptr %.spill168, align 1
  %8155 = select <8 x i1> %.spill.load1692, <8 x float> %native.exp1628, <8 x float> zeroinitializer
  %.spill.load1693 = load <8 x i1>, ptr %.spill172, align 1
  %8156 = select <8 x i1> %.spill.load1693, <8 x float> %native.exp1629, <8 x float> zeroinitializer
  %.spill.load1694 = load <8 x i1>, ptr %.spill176, align 1
  %8157 = select <8 x i1> %.spill.load1694, <8 x float> %native.exp1630, <8 x float> zeroinitializer
  %.spill.load1695 = load <8 x i1>, ptr %.spill180, align 1
  %8158 = select <8 x i1> %.spill.load1695, <8 x float> %native.exp1631, <8 x float> zeroinitializer
  %.spill.load1696 = load <8 x i1>, ptr %.spill184, align 1
  %8159 = select <8 x i1> %.spill.load1696, <8 x float> %native.exp1632, <8 x float> zeroinitializer
  %.spill.load1697 = load <8 x i1>, ptr %.spill188, align 1
  %8160 = select <8 x i1> %.spill.load1697, <8 x float> %native.exp1633, <8 x float> zeroinitializer
  %.spill.load1698 = load <8 x i1>, ptr %.spill192, align 1
  %8161 = select <8 x i1> %.spill.load1698, <8 x float> %native.exp1634, <8 x float> zeroinitializer
  %.spill.load1699 = load <8 x i1>, ptr %.spill196, align 1
  %8162 = select <8 x i1> %.spill.load1699, <8 x float> %native.exp1635, <8 x float> zeroinitializer
  %.spill.load1700 = load <8 x i1>, ptr %.spill200, align 1
  %8163 = select <8 x i1> %.spill.load1700, <8 x float> %native.exp1636, <8 x float> zeroinitializer
  %.spill.load1701 = load <8 x i1>, ptr %.spill204, align 1
  %8164 = select <8 x i1> %.spill.load1701, <8 x float> %native.exp1637, <8 x float> zeroinitializer
  %.spill.load1702 = load <8 x i1>, ptr %.spill145, align 1
  %8165 = select <8 x i1> %.spill.load1702, <8 x float> %native.exp1638, <8 x float> zeroinitializer
  %.spill.load1703 = load <8 x i1>, ptr %.spill149, align 1
  %8166 = select <8 x i1> %.spill.load1703, <8 x float> %native.exp1639, <8 x float> zeroinitializer
  %.spill.load1704 = load <8 x i1>, ptr %.spill153, align 1
  %8167 = select <8 x i1> %.spill.load1704, <8 x float> %native.exp1640, <8 x float> zeroinitializer
  %.spill.load1705 = load <8 x i1>, ptr %.spill157, align 1
  %8168 = select <8 x i1> %.spill.load1705, <8 x float> %native.exp1641, <8 x float> zeroinitializer
  %.spill.load1706 = load <8 x i1>, ptr %.spill161, align 1
  %8169 = select <8 x i1> %.spill.load1706, <8 x float> %native.exp1642, <8 x float> zeroinitializer
  %.spill.load1707 = load <8 x i1>, ptr %.spill165, align 1
  %8170 = select <8 x i1> %.spill.load1707, <8 x float> %native.exp1643, <8 x float> zeroinitializer
  %.spill.load1708 = load <8 x i1>, ptr %.spill169, align 1
  %8171 = select <8 x i1> %.spill.load1708, <8 x float> %native.exp1644, <8 x float> zeroinitializer
  %.spill.load1709 = load <8 x i1>, ptr %.spill173, align 1
  %8172 = select <8 x i1> %.spill.load1709, <8 x float> %native.exp1645, <8 x float> zeroinitializer
  %.spill.load1710 = load <8 x i1>, ptr %.spill177, align 1
  %8173 = select <8 x i1> %.spill.load1710, <8 x float> %native.exp1646, <8 x float> zeroinitializer
  %.spill.load1711 = load <8 x i1>, ptr %.spill181, align 1
  %8174 = select <8 x i1> %.spill.load1711, <8 x float> %native.exp1647, <8 x float> zeroinitializer
  %.spill.load1712 = load <8 x i1>, ptr %.spill185, align 1
  %8175 = select <8 x i1> %.spill.load1712, <8 x float> %native.exp1648, <8 x float> zeroinitializer
  %.spill.load1713 = load <8 x i1>, ptr %.spill189, align 1
  %8176 = select <8 x i1> %.spill.load1713, <8 x float> %native.exp1649, <8 x float> zeroinitializer
  %.spill.load1714 = load <8 x i1>, ptr %.spill193, align 1
  %8177 = select <8 x i1> %.spill.load1714, <8 x float> %native.exp1650, <8 x float> zeroinitializer
  %.spill.load1715 = load <8 x i1>, ptr %.spill197, align 1
  %8178 = select <8 x i1> %.spill.load1715, <8 x float> %native.exp1651, <8 x float> zeroinitializer
  %.spill.load1716 = load <8 x i1>, ptr %.spill201, align 1
  %8179 = select <8 x i1> %.spill.load1716, <8 x float> %native.exp1652, <8 x float> zeroinitializer
  %.spill.load1717 = load <8 x i1>, ptr %.spill205, align 1
  %8180 = select <8 x i1> %.spill.load1717, <8 x float> %native.exp1653, <8 x float> zeroinitializer
  %.spill.load1718 = load <8 x i1>, ptr %.spill146, align 1
  %8181 = select <8 x i1> %.spill.load1718, <8 x float> %native.exp1654, <8 x float> zeroinitializer
  %.spill.load1719 = load <8 x i1>, ptr %.spill150, align 1
  %8182 = select <8 x i1> %.spill.load1719, <8 x float> %native.exp1655, <8 x float> zeroinitializer
  %.spill.load1720 = load <8 x i1>, ptr %.spill154, align 1
  %8183 = select <8 x i1> %.spill.load1720, <8 x float> %native.exp1656, <8 x float> zeroinitializer
  %.spill.load1721 = load <8 x i1>, ptr %.spill158, align 1
  %8184 = select <8 x i1> %.spill.load1721, <8 x float> %native.exp1657, <8 x float> zeroinitializer
  %.spill.load1722 = load <8 x i1>, ptr %.spill162, align 1
  %8185 = select <8 x i1> %.spill.load1722, <8 x float> %native.exp1658, <8 x float> zeroinitializer
  %.spill.load1723 = load <8 x i1>, ptr %.spill166, align 1
  %8186 = select <8 x i1> %.spill.load1723, <8 x float> %native.exp1659, <8 x float> zeroinitializer
  %.spill.load1724 = load <8 x i1>, ptr %.spill170, align 1
  %8187 = select <8 x i1> %.spill.load1724, <8 x float> %native.exp1660, <8 x float> zeroinitializer
  %.spill.load1725 = load <8 x i1>, ptr %.spill174, align 1
  %8188 = select <8 x i1> %.spill.load1725, <8 x float> %native.exp1661, <8 x float> zeroinitializer
  %.spill.load1726 = load <8 x i1>, ptr %.spill178, align 1
  %8189 = select <8 x i1> %.spill.load1726, <8 x float> %native.exp1662, <8 x float> zeroinitializer
  %.spill.load1727 = load <8 x i1>, ptr %.spill182, align 1
  %8190 = select <8 x i1> %.spill.load1727, <8 x float> %native.exp1663, <8 x float> zeroinitializer
  %.spill.load1728 = load <8 x i1>, ptr %.spill186, align 1
  %8191 = select <8 x i1> %.spill.load1728, <8 x float> %native.exp1664, <8 x float> zeroinitializer
  %.spill.load1729 = load <8 x i1>, ptr %.spill190, align 1
  %8192 = select <8 x i1> %.spill.load1729, <8 x float> %native.exp1665, <8 x float> zeroinitializer
  %.spill.load1730 = load <8 x i1>, ptr %.spill194, align 1
  %8193 = select <8 x i1> %.spill.load1730, <8 x float> %native.exp1666, <8 x float> zeroinitializer
  %.spill.load1731 = load <8 x i1>, ptr %.spill198, align 1
  %8194 = select <8 x i1> %.spill.load1731, <8 x float> %native.exp1667, <8 x float> zeroinitializer
  %.spill.load1732 = load <8 x i1>, ptr %.spill202, align 1
  %8195 = select <8 x i1> %.spill.load1732, <8 x float> %native.exp1668, <8 x float> zeroinitializer
  %.spill.load1733 = load <8 x i1>, ptr %.spill206, align 1
  %8196 = select <8 x i1> %.spill.load1733, <8 x float> %native.exp1669, <8 x float> zeroinitializer
  %8197 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %8198 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8199 = extractvalue { <8 x ptr>, <8 x i64> } %8197, 0
  %8200 = select <8 x i1> %convergence.cascade.result1518, <8 x ptr> %8198, <8 x ptr> %8199
  %8201 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8202 = extractvalue { <8 x ptr>, <8 x i64> } %8197, 1
  %8203 = select <8 x i1> %convergence.cascade.result1518, <8 x i64> %8201, <8 x i64> %8202
  %8204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8200, 0
  %8205 = insertvalue { <8 x ptr>, <8 x i64> } %8204, <8 x i64> %8203, 1
  store { <8 x ptr>, <8 x i64> } %8205, ptr %tile_snapshot.spill285, align 64
  %8206 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8207 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8208 = add <8 x i64> %8207, zeroinitializer
  %8209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8206, 0
  %8210 = insertvalue { <8 x ptr>, <8 x i64> } %8209, <8 x i64> %8208, 1
  %8211 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8212 = extractvalue { <8 x ptr>, <8 x i64> } %8210, 1
  %8213 = extractelement <8 x ptr> %8211, i32 0
  %8214 = extractelement <8 x i64> %8212, i32 %7915
  %8215 = zext i32 %7915 to i64
  %8216 = mul i64 %8215, 4
  %8217 = sub i64 %8214, %8216
  %8218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8219 = select i1 %8218, i64 %8217, i64 0
  %private.contiguous.address1734 = getelementptr i8, ptr %8213, i64 %8219
  %private.contiguous.preserve1735 = load <8 x float>, ptr %private.contiguous.address1734, align 4
  %8220 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8133, <8 x float> %private.contiguous.preserve1735
  store <8 x float> %8220, ptr %private.contiguous.address1734, align 4
  %8221 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8222 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8223 = add <8 x i64> %8222, splat (i64 32)
  %8224 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8221, 0
  %8225 = insertvalue { <8 x ptr>, <8 x i64> } %8224, <8 x i64> %8223, 1
  %8226 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8227 = extractvalue { <8 x ptr>, <8 x i64> } %8225, 1
  %8228 = extractelement <8 x ptr> %8226, i32 0
  %8229 = extractelement <8 x i64> %8227, i32 %7915
  %8230 = zext i32 %7915 to i64
  %8231 = mul i64 %8230, 4
  %8232 = sub i64 %8229, %8231
  %8233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8234 = select i1 %8233, i64 %8232, i64 0
  %private.contiguous.address1736 = getelementptr i8, ptr %8228, i64 %8234
  %private.contiguous.preserve1737 = load <8 x float>, ptr %private.contiguous.address1736, align 4
  %8235 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8134, <8 x float> %private.contiguous.preserve1737
  store <8 x float> %8235, ptr %private.contiguous.address1736, align 4
  %8236 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8237 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8238 = add <8 x i64> %8237, splat (i64 64)
  %8239 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8236, 0
  %8240 = insertvalue { <8 x ptr>, <8 x i64> } %8239, <8 x i64> %8238, 1
  %8241 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8242 = extractvalue { <8 x ptr>, <8 x i64> } %8240, 1
  %8243 = extractelement <8 x ptr> %8241, i32 0
  %8244 = extractelement <8 x i64> %8242, i32 %7915
  %8245 = zext i32 %7915 to i64
  %8246 = mul i64 %8245, 4
  %8247 = sub i64 %8244, %8246
  %8248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8249 = select i1 %8248, i64 %8247, i64 0
  %private.contiguous.address1738 = getelementptr i8, ptr %8243, i64 %8249
  %private.contiguous.preserve1739 = load <8 x float>, ptr %private.contiguous.address1738, align 4
  %8250 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8135, <8 x float> %private.contiguous.preserve1739
  store <8 x float> %8250, ptr %private.contiguous.address1738, align 4
  %8251 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8252 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8253 = add <8 x i64> %8252, splat (i64 96)
  %8254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8251, 0
  %8255 = insertvalue { <8 x ptr>, <8 x i64> } %8254, <8 x i64> %8253, 1
  %8256 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8257 = extractvalue { <8 x ptr>, <8 x i64> } %8255, 1
  %8258 = extractelement <8 x ptr> %8256, i32 0
  %8259 = extractelement <8 x i64> %8257, i32 %7915
  %8260 = zext i32 %7915 to i64
  %8261 = mul i64 %8260, 4
  %8262 = sub i64 %8259, %8261
  %8263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8264 = select i1 %8263, i64 %8262, i64 0
  %private.contiguous.address1740 = getelementptr i8, ptr %8258, i64 %8264
  %private.contiguous.preserve1741 = load <8 x float>, ptr %private.contiguous.address1740, align 4
  %8265 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8136, <8 x float> %private.contiguous.preserve1741
  store <8 x float> %8265, ptr %private.contiguous.address1740, align 4
  %8266 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8267 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8268 = add <8 x i64> %8267, splat (i64 128)
  %8269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8266, 0
  %8270 = insertvalue { <8 x ptr>, <8 x i64> } %8269, <8 x i64> %8268, 1
  %8271 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8272 = extractvalue { <8 x ptr>, <8 x i64> } %8270, 1
  %8273 = extractelement <8 x ptr> %8271, i32 0
  %8274 = extractelement <8 x i64> %8272, i32 %7915
  %8275 = zext i32 %7915 to i64
  %8276 = mul i64 %8275, 4
  %8277 = sub i64 %8274, %8276
  %8278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8279 = select i1 %8278, i64 %8277, i64 0
  %private.contiguous.address1742 = getelementptr i8, ptr %8273, i64 %8279
  %private.contiguous.preserve1743 = load <8 x float>, ptr %private.contiguous.address1742, align 4
  %8280 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8137, <8 x float> %private.contiguous.preserve1743
  store <8 x float> %8280, ptr %private.contiguous.address1742, align 4
  %8281 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8282 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8283 = add <8 x i64> %8282, splat (i64 160)
  %8284 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8281, 0
  %8285 = insertvalue { <8 x ptr>, <8 x i64> } %8284, <8 x i64> %8283, 1
  %8286 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8287 = extractvalue { <8 x ptr>, <8 x i64> } %8285, 1
  %8288 = extractelement <8 x ptr> %8286, i32 0
  %8289 = extractelement <8 x i64> %8287, i32 %7915
  %8290 = zext i32 %7915 to i64
  %8291 = mul i64 %8290, 4
  %8292 = sub i64 %8289, %8291
  %8293 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8294 = select i1 %8293, i64 %8292, i64 0
  %private.contiguous.address1744 = getelementptr i8, ptr %8288, i64 %8294
  %private.contiguous.preserve1745 = load <8 x float>, ptr %private.contiguous.address1744, align 4
  %8295 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8138, <8 x float> %private.contiguous.preserve1745
  store <8 x float> %8295, ptr %private.contiguous.address1744, align 4
  %8296 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8297 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8298 = add <8 x i64> %8297, splat (i64 192)
  %8299 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8296, 0
  %8300 = insertvalue { <8 x ptr>, <8 x i64> } %8299, <8 x i64> %8298, 1
  %8301 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8302 = extractvalue { <8 x ptr>, <8 x i64> } %8300, 1
  %8303 = extractelement <8 x ptr> %8301, i32 0
  %8304 = extractelement <8 x i64> %8302, i32 %7915
  %8305 = zext i32 %7915 to i64
  %8306 = mul i64 %8305, 4
  %8307 = sub i64 %8304, %8306
  %8308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8309 = select i1 %8308, i64 %8307, i64 0
  %private.contiguous.address1746 = getelementptr i8, ptr %8303, i64 %8309
  %private.contiguous.preserve1747 = load <8 x float>, ptr %private.contiguous.address1746, align 4
  %8310 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8139, <8 x float> %private.contiguous.preserve1747
  store <8 x float> %8310, ptr %private.contiguous.address1746, align 4
  %8311 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8312 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8313 = add <8 x i64> %8312, splat (i64 224)
  %8314 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8311, 0
  %8315 = insertvalue { <8 x ptr>, <8 x i64> } %8314, <8 x i64> %8313, 1
  %8316 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8317 = extractvalue { <8 x ptr>, <8 x i64> } %8315, 1
  %8318 = extractelement <8 x ptr> %8316, i32 0
  %8319 = extractelement <8 x i64> %8317, i32 %7915
  %8320 = zext i32 %7915 to i64
  %8321 = mul i64 %8320, 4
  %8322 = sub i64 %8319, %8321
  %8323 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8324 = select i1 %8323, i64 %8322, i64 0
  %private.contiguous.address1748 = getelementptr i8, ptr %8318, i64 %8324
  %private.contiguous.preserve1749 = load <8 x float>, ptr %private.contiguous.address1748, align 4
  %8325 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8140, <8 x float> %private.contiguous.preserve1749
  store <8 x float> %8325, ptr %private.contiguous.address1748, align 4
  %8326 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8327 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8328 = add <8 x i64> %8327, splat (i64 256)
  %8329 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8326, 0
  %8330 = insertvalue { <8 x ptr>, <8 x i64> } %8329, <8 x i64> %8328, 1
  %8331 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8332 = extractvalue { <8 x ptr>, <8 x i64> } %8330, 1
  %8333 = extractelement <8 x ptr> %8331, i32 0
  %8334 = extractelement <8 x i64> %8332, i32 %7915
  %8335 = zext i32 %7915 to i64
  %8336 = mul i64 %8335, 4
  %8337 = sub i64 %8334, %8336
  %8338 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8339 = select i1 %8338, i64 %8337, i64 0
  %private.contiguous.address1750 = getelementptr i8, ptr %8333, i64 %8339
  %private.contiguous.preserve1751 = load <8 x float>, ptr %private.contiguous.address1750, align 4
  %8340 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8141, <8 x float> %private.contiguous.preserve1751
  store <8 x float> %8340, ptr %private.contiguous.address1750, align 4
  %8341 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8342 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8343 = add <8 x i64> %8342, splat (i64 288)
  %8344 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8341, 0
  %8345 = insertvalue { <8 x ptr>, <8 x i64> } %8344, <8 x i64> %8343, 1
  %8346 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8347 = extractvalue { <8 x ptr>, <8 x i64> } %8345, 1
  %8348 = extractelement <8 x ptr> %8346, i32 0
  %8349 = extractelement <8 x i64> %8347, i32 %7915
  %8350 = zext i32 %7915 to i64
  %8351 = mul i64 %8350, 4
  %8352 = sub i64 %8349, %8351
  %8353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8354 = select i1 %8353, i64 %8352, i64 0
  %private.contiguous.address1752 = getelementptr i8, ptr %8348, i64 %8354
  %private.contiguous.preserve1753 = load <8 x float>, ptr %private.contiguous.address1752, align 4
  %8355 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8142, <8 x float> %private.contiguous.preserve1753
  store <8 x float> %8355, ptr %private.contiguous.address1752, align 4
  %8356 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8357 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8358 = add <8 x i64> %8357, splat (i64 320)
  %8359 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8356, 0
  %8360 = insertvalue { <8 x ptr>, <8 x i64> } %8359, <8 x i64> %8358, 1
  %8361 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8362 = extractvalue { <8 x ptr>, <8 x i64> } %8360, 1
  %8363 = extractelement <8 x ptr> %8361, i32 0
  %8364 = extractelement <8 x i64> %8362, i32 %7915
  %8365 = zext i32 %7915 to i64
  %8366 = mul i64 %8365, 4
  %8367 = sub i64 %8364, %8366
  %8368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8369 = select i1 %8368, i64 %8367, i64 0
  %private.contiguous.address1754 = getelementptr i8, ptr %8363, i64 %8369
  %private.contiguous.preserve1755 = load <8 x float>, ptr %private.contiguous.address1754, align 4
  %8370 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8143, <8 x float> %private.contiguous.preserve1755
  store <8 x float> %8370, ptr %private.contiguous.address1754, align 4
  %8371 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8372 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8373 = add <8 x i64> %8372, splat (i64 352)
  %8374 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8371, 0
  %8375 = insertvalue { <8 x ptr>, <8 x i64> } %8374, <8 x i64> %8373, 1
  %8376 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8377 = extractvalue { <8 x ptr>, <8 x i64> } %8375, 1
  %8378 = extractelement <8 x ptr> %8376, i32 0
  %8379 = extractelement <8 x i64> %8377, i32 %7915
  %8380 = zext i32 %7915 to i64
  %8381 = mul i64 %8380, 4
  %8382 = sub i64 %8379, %8381
  %8383 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8384 = select i1 %8383, i64 %8382, i64 0
  %private.contiguous.address1756 = getelementptr i8, ptr %8378, i64 %8384
  %private.contiguous.preserve1757 = load <8 x float>, ptr %private.contiguous.address1756, align 4
  %8385 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8144, <8 x float> %private.contiguous.preserve1757
  store <8 x float> %8385, ptr %private.contiguous.address1756, align 4
  %8386 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8387 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8388 = add <8 x i64> %8387, splat (i64 384)
  %8389 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8386, 0
  %8390 = insertvalue { <8 x ptr>, <8 x i64> } %8389, <8 x i64> %8388, 1
  %8391 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8392 = extractvalue { <8 x ptr>, <8 x i64> } %8390, 1
  %8393 = extractelement <8 x ptr> %8391, i32 0
  %8394 = extractelement <8 x i64> %8392, i32 %7915
  %8395 = zext i32 %7915 to i64
  %8396 = mul i64 %8395, 4
  %8397 = sub i64 %8394, %8396
  %8398 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8399 = select i1 %8398, i64 %8397, i64 0
  %private.contiguous.address1758 = getelementptr i8, ptr %8393, i64 %8399
  %private.contiguous.preserve1759 = load <8 x float>, ptr %private.contiguous.address1758, align 4
  %8400 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8145, <8 x float> %private.contiguous.preserve1759
  store <8 x float> %8400, ptr %private.contiguous.address1758, align 4
  %8401 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8402 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8403 = add <8 x i64> %8402, splat (i64 416)
  %8404 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8401, 0
  %8405 = insertvalue { <8 x ptr>, <8 x i64> } %8404, <8 x i64> %8403, 1
  %8406 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8407 = extractvalue { <8 x ptr>, <8 x i64> } %8405, 1
  %8408 = extractelement <8 x ptr> %8406, i32 0
  %8409 = extractelement <8 x i64> %8407, i32 %7915
  %8410 = zext i32 %7915 to i64
  %8411 = mul i64 %8410, 4
  %8412 = sub i64 %8409, %8411
  %8413 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8414 = select i1 %8413, i64 %8412, i64 0
  %private.contiguous.address1760 = getelementptr i8, ptr %8408, i64 %8414
  %private.contiguous.preserve1761 = load <8 x float>, ptr %private.contiguous.address1760, align 4
  %8415 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8146, <8 x float> %private.contiguous.preserve1761
  store <8 x float> %8415, ptr %private.contiguous.address1760, align 4
  %8416 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8417 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8418 = add <8 x i64> %8417, splat (i64 448)
  %8419 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8416, 0
  %8420 = insertvalue { <8 x ptr>, <8 x i64> } %8419, <8 x i64> %8418, 1
  %8421 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8422 = extractvalue { <8 x ptr>, <8 x i64> } %8420, 1
  %8423 = extractelement <8 x ptr> %8421, i32 0
  %8424 = extractelement <8 x i64> %8422, i32 %7915
  %8425 = zext i32 %7915 to i64
  %8426 = mul i64 %8425, 4
  %8427 = sub i64 %8424, %8426
  %8428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8429 = select i1 %8428, i64 %8427, i64 0
  %private.contiguous.address1762 = getelementptr i8, ptr %8423, i64 %8429
  %private.contiguous.preserve1763 = load <8 x float>, ptr %private.contiguous.address1762, align 4
  %8430 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8147, <8 x float> %private.contiguous.preserve1763
  store <8 x float> %8430, ptr %private.contiguous.address1762, align 4
  %8431 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8432 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8433 = add <8 x i64> %8432, splat (i64 480)
  %8434 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8431, 0
  %8435 = insertvalue { <8 x ptr>, <8 x i64> } %8434, <8 x i64> %8433, 1
  %8436 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8437 = extractvalue { <8 x ptr>, <8 x i64> } %8435, 1
  %8438 = extractelement <8 x ptr> %8436, i32 0
  %8439 = extractelement <8 x i64> %8437, i32 %7915
  %8440 = zext i32 %7915 to i64
  %8441 = mul i64 %8440, 4
  %8442 = sub i64 %8439, %8441
  %8443 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8444 = select i1 %8443, i64 %8442, i64 0
  %private.contiguous.address1764 = getelementptr i8, ptr %8438, i64 %8444
  %private.contiguous.preserve1765 = load <8 x float>, ptr %private.contiguous.address1764, align 4
  %8445 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8148, <8 x float> %private.contiguous.preserve1765
  store <8 x float> %8445, ptr %private.contiguous.address1764, align 4
  %8446 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8447 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8448 = add <8 x i64> %8447, splat (i64 512)
  %8449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8446, 0
  %8450 = insertvalue { <8 x ptr>, <8 x i64> } %8449, <8 x i64> %8448, 1
  %8451 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8452 = extractvalue { <8 x ptr>, <8 x i64> } %8450, 1
  %8453 = extractelement <8 x ptr> %8451, i32 0
  %8454 = extractelement <8 x i64> %8452, i32 %7915
  %8455 = zext i32 %7915 to i64
  %8456 = mul i64 %8455, 4
  %8457 = sub i64 %8454, %8456
  %8458 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8459 = select i1 %8458, i64 %8457, i64 0
  %private.contiguous.address1766 = getelementptr i8, ptr %8453, i64 %8459
  %private.contiguous.preserve1767 = load <8 x float>, ptr %private.contiguous.address1766, align 4
  %8460 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8149, <8 x float> %private.contiguous.preserve1767
  store <8 x float> %8460, ptr %private.contiguous.address1766, align 4
  %8461 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8462 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8463 = add <8 x i64> %8462, splat (i64 544)
  %8464 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8461, 0
  %8465 = insertvalue { <8 x ptr>, <8 x i64> } %8464, <8 x i64> %8463, 1
  %8466 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8467 = extractvalue { <8 x ptr>, <8 x i64> } %8465, 1
  %8468 = extractelement <8 x ptr> %8466, i32 0
  %8469 = extractelement <8 x i64> %8467, i32 %7915
  %8470 = zext i32 %7915 to i64
  %8471 = mul i64 %8470, 4
  %8472 = sub i64 %8469, %8471
  %8473 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8474 = select i1 %8473, i64 %8472, i64 0
  %private.contiguous.address1768 = getelementptr i8, ptr %8468, i64 %8474
  %private.contiguous.preserve1769 = load <8 x float>, ptr %private.contiguous.address1768, align 4
  %8475 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8150, <8 x float> %private.contiguous.preserve1769
  store <8 x float> %8475, ptr %private.contiguous.address1768, align 4
  %8476 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8477 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8478 = add <8 x i64> %8477, splat (i64 576)
  %8479 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8476, 0
  %8480 = insertvalue { <8 x ptr>, <8 x i64> } %8479, <8 x i64> %8478, 1
  %8481 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8482 = extractvalue { <8 x ptr>, <8 x i64> } %8480, 1
  %8483 = extractelement <8 x ptr> %8481, i32 0
  %8484 = extractelement <8 x i64> %8482, i32 %7915
  %8485 = zext i32 %7915 to i64
  %8486 = mul i64 %8485, 4
  %8487 = sub i64 %8484, %8486
  %8488 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8489 = select i1 %8488, i64 %8487, i64 0
  %private.contiguous.address1770 = getelementptr i8, ptr %8483, i64 %8489
  %private.contiguous.preserve1771 = load <8 x float>, ptr %private.contiguous.address1770, align 4
  %8490 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8151, <8 x float> %private.contiguous.preserve1771
  store <8 x float> %8490, ptr %private.contiguous.address1770, align 4
  %8491 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8492 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8493 = add <8 x i64> %8492, splat (i64 608)
  %8494 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8491, 0
  %8495 = insertvalue { <8 x ptr>, <8 x i64> } %8494, <8 x i64> %8493, 1
  %8496 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8497 = extractvalue { <8 x ptr>, <8 x i64> } %8495, 1
  %8498 = extractelement <8 x ptr> %8496, i32 0
  %8499 = extractelement <8 x i64> %8497, i32 %7915
  %8500 = zext i32 %7915 to i64
  %8501 = mul i64 %8500, 4
  %8502 = sub i64 %8499, %8501
  %8503 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8504 = select i1 %8503, i64 %8502, i64 0
  %private.contiguous.address1772 = getelementptr i8, ptr %8498, i64 %8504
  %private.contiguous.preserve1773 = load <8 x float>, ptr %private.contiguous.address1772, align 4
  %8505 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8152, <8 x float> %private.contiguous.preserve1773
  store <8 x float> %8505, ptr %private.contiguous.address1772, align 4
  %8506 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8507 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8508 = add <8 x i64> %8507, splat (i64 640)
  %8509 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8506, 0
  %8510 = insertvalue { <8 x ptr>, <8 x i64> } %8509, <8 x i64> %8508, 1
  %8511 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8512 = extractvalue { <8 x ptr>, <8 x i64> } %8510, 1
  %8513 = extractelement <8 x ptr> %8511, i32 0
  %8514 = extractelement <8 x i64> %8512, i32 %7915
  %8515 = zext i32 %7915 to i64
  %8516 = mul i64 %8515, 4
  %8517 = sub i64 %8514, %8516
  %8518 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8519 = select i1 %8518, i64 %8517, i64 0
  %private.contiguous.address1774 = getelementptr i8, ptr %8513, i64 %8519
  %private.contiguous.preserve1775 = load <8 x float>, ptr %private.contiguous.address1774, align 4
  %8520 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8153, <8 x float> %private.contiguous.preserve1775
  store <8 x float> %8520, ptr %private.contiguous.address1774, align 4
  %8521 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8522 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8523 = add <8 x i64> %8522, splat (i64 672)
  %8524 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8521, 0
  %8525 = insertvalue { <8 x ptr>, <8 x i64> } %8524, <8 x i64> %8523, 1
  %8526 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8527 = extractvalue { <8 x ptr>, <8 x i64> } %8525, 1
  %8528 = extractelement <8 x ptr> %8526, i32 0
  %8529 = extractelement <8 x i64> %8527, i32 %7915
  %8530 = zext i32 %7915 to i64
  %8531 = mul i64 %8530, 4
  %8532 = sub i64 %8529, %8531
  %8533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8534 = select i1 %8533, i64 %8532, i64 0
  %private.contiguous.address1776 = getelementptr i8, ptr %8528, i64 %8534
  %private.contiguous.preserve1777 = load <8 x float>, ptr %private.contiguous.address1776, align 4
  %8535 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8154, <8 x float> %private.contiguous.preserve1777
  store <8 x float> %8535, ptr %private.contiguous.address1776, align 4
  %8536 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8537 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8538 = add <8 x i64> %8537, splat (i64 704)
  %8539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8536, 0
  %8540 = insertvalue { <8 x ptr>, <8 x i64> } %8539, <8 x i64> %8538, 1
  %8541 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8542 = extractvalue { <8 x ptr>, <8 x i64> } %8540, 1
  %8543 = extractelement <8 x ptr> %8541, i32 0
  %8544 = extractelement <8 x i64> %8542, i32 %7915
  %8545 = zext i32 %7915 to i64
  %8546 = mul i64 %8545, 4
  %8547 = sub i64 %8544, %8546
  %8548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8549 = select i1 %8548, i64 %8547, i64 0
  %private.contiguous.address1778 = getelementptr i8, ptr %8543, i64 %8549
  %private.contiguous.preserve1779 = load <8 x float>, ptr %private.contiguous.address1778, align 4
  %8550 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8155, <8 x float> %private.contiguous.preserve1779
  store <8 x float> %8550, ptr %private.contiguous.address1778, align 4
  %8551 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8552 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8553 = add <8 x i64> %8552, splat (i64 736)
  %8554 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8551, 0
  %8555 = insertvalue { <8 x ptr>, <8 x i64> } %8554, <8 x i64> %8553, 1
  %8556 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8557 = extractvalue { <8 x ptr>, <8 x i64> } %8555, 1
  %8558 = extractelement <8 x ptr> %8556, i32 0
  %8559 = extractelement <8 x i64> %8557, i32 %7915
  %8560 = zext i32 %7915 to i64
  %8561 = mul i64 %8560, 4
  %8562 = sub i64 %8559, %8561
  %8563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8564 = select i1 %8563, i64 %8562, i64 0
  %private.contiguous.address1780 = getelementptr i8, ptr %8558, i64 %8564
  %private.contiguous.preserve1781 = load <8 x float>, ptr %private.contiguous.address1780, align 4
  %8565 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8156, <8 x float> %private.contiguous.preserve1781
  store <8 x float> %8565, ptr %private.contiguous.address1780, align 4
  %8566 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8567 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8568 = add <8 x i64> %8567, splat (i64 768)
  %8569 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8566, 0
  %8570 = insertvalue { <8 x ptr>, <8 x i64> } %8569, <8 x i64> %8568, 1
  %8571 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8572 = extractvalue { <8 x ptr>, <8 x i64> } %8570, 1
  %8573 = extractelement <8 x ptr> %8571, i32 0
  %8574 = extractelement <8 x i64> %8572, i32 %7915
  %8575 = zext i32 %7915 to i64
  %8576 = mul i64 %8575, 4
  %8577 = sub i64 %8574, %8576
  %8578 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8579 = select i1 %8578, i64 %8577, i64 0
  %private.contiguous.address1782 = getelementptr i8, ptr %8573, i64 %8579
  %private.contiguous.preserve1783 = load <8 x float>, ptr %private.contiguous.address1782, align 4
  %8580 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8157, <8 x float> %private.contiguous.preserve1783
  store <8 x float> %8580, ptr %private.contiguous.address1782, align 4
  %8581 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8582 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8583 = add <8 x i64> %8582, splat (i64 800)
  %8584 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8581, 0
  %8585 = insertvalue { <8 x ptr>, <8 x i64> } %8584, <8 x i64> %8583, 1
  %8586 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8587 = extractvalue { <8 x ptr>, <8 x i64> } %8585, 1
  %8588 = extractelement <8 x ptr> %8586, i32 0
  %8589 = extractelement <8 x i64> %8587, i32 %7915
  %8590 = zext i32 %7915 to i64
  %8591 = mul i64 %8590, 4
  %8592 = sub i64 %8589, %8591
  %8593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8594 = select i1 %8593, i64 %8592, i64 0
  %private.contiguous.address1784 = getelementptr i8, ptr %8588, i64 %8594
  %private.contiguous.preserve1785 = load <8 x float>, ptr %private.contiguous.address1784, align 4
  %8595 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8158, <8 x float> %private.contiguous.preserve1785
  store <8 x float> %8595, ptr %private.contiguous.address1784, align 4
  %8596 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8597 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8598 = add <8 x i64> %8597, splat (i64 832)
  %8599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8596, 0
  %8600 = insertvalue { <8 x ptr>, <8 x i64> } %8599, <8 x i64> %8598, 1
  %8601 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8602 = extractvalue { <8 x ptr>, <8 x i64> } %8600, 1
  %8603 = extractelement <8 x ptr> %8601, i32 0
  %8604 = extractelement <8 x i64> %8602, i32 %7915
  %8605 = zext i32 %7915 to i64
  %8606 = mul i64 %8605, 4
  %8607 = sub i64 %8604, %8606
  %8608 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8609 = select i1 %8608, i64 %8607, i64 0
  %private.contiguous.address1786 = getelementptr i8, ptr %8603, i64 %8609
  %private.contiguous.preserve1787 = load <8 x float>, ptr %private.contiguous.address1786, align 4
  %8610 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8159, <8 x float> %private.contiguous.preserve1787
  store <8 x float> %8610, ptr %private.contiguous.address1786, align 4
  %8611 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8612 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8613 = add <8 x i64> %8612, splat (i64 864)
  %8614 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8611, 0
  %8615 = insertvalue { <8 x ptr>, <8 x i64> } %8614, <8 x i64> %8613, 1
  %8616 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8617 = extractvalue { <8 x ptr>, <8 x i64> } %8615, 1
  %8618 = extractelement <8 x ptr> %8616, i32 0
  %8619 = extractelement <8 x i64> %8617, i32 %7915
  %8620 = zext i32 %7915 to i64
  %8621 = mul i64 %8620, 4
  %8622 = sub i64 %8619, %8621
  %8623 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8624 = select i1 %8623, i64 %8622, i64 0
  %private.contiguous.address1788 = getelementptr i8, ptr %8618, i64 %8624
  %private.contiguous.preserve1789 = load <8 x float>, ptr %private.contiguous.address1788, align 4
  %8625 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8160, <8 x float> %private.contiguous.preserve1789
  store <8 x float> %8625, ptr %private.contiguous.address1788, align 4
  %8626 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8627 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8628 = add <8 x i64> %8627, splat (i64 896)
  %8629 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8626, 0
  %8630 = insertvalue { <8 x ptr>, <8 x i64> } %8629, <8 x i64> %8628, 1
  %8631 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8632 = extractvalue { <8 x ptr>, <8 x i64> } %8630, 1
  %8633 = extractelement <8 x ptr> %8631, i32 0
  %8634 = extractelement <8 x i64> %8632, i32 %7915
  %8635 = zext i32 %7915 to i64
  %8636 = mul i64 %8635, 4
  %8637 = sub i64 %8634, %8636
  %8638 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8639 = select i1 %8638, i64 %8637, i64 0
  %private.contiguous.address1790 = getelementptr i8, ptr %8633, i64 %8639
  %private.contiguous.preserve1791 = load <8 x float>, ptr %private.contiguous.address1790, align 4
  %8640 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8161, <8 x float> %private.contiguous.preserve1791
  store <8 x float> %8640, ptr %private.contiguous.address1790, align 4
  %8641 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8642 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8643 = add <8 x i64> %8642, splat (i64 928)
  %8644 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8641, 0
  %8645 = insertvalue { <8 x ptr>, <8 x i64> } %8644, <8 x i64> %8643, 1
  %8646 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8647 = extractvalue { <8 x ptr>, <8 x i64> } %8645, 1
  %8648 = extractelement <8 x ptr> %8646, i32 0
  %8649 = extractelement <8 x i64> %8647, i32 %7915
  %8650 = zext i32 %7915 to i64
  %8651 = mul i64 %8650, 4
  %8652 = sub i64 %8649, %8651
  %8653 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8654 = select i1 %8653, i64 %8652, i64 0
  %private.contiguous.address1792 = getelementptr i8, ptr %8648, i64 %8654
  %private.contiguous.preserve1793 = load <8 x float>, ptr %private.contiguous.address1792, align 4
  %8655 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8162, <8 x float> %private.contiguous.preserve1793
  store <8 x float> %8655, ptr %private.contiguous.address1792, align 4
  %8656 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8657 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8658 = add <8 x i64> %8657, splat (i64 960)
  %8659 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8656, 0
  %8660 = insertvalue { <8 x ptr>, <8 x i64> } %8659, <8 x i64> %8658, 1
  %8661 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8662 = extractvalue { <8 x ptr>, <8 x i64> } %8660, 1
  %8663 = extractelement <8 x ptr> %8661, i32 0
  %8664 = extractelement <8 x i64> %8662, i32 %7915
  %8665 = zext i32 %7915 to i64
  %8666 = mul i64 %8665, 4
  %8667 = sub i64 %8664, %8666
  %8668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8669 = select i1 %8668, i64 %8667, i64 0
  %private.contiguous.address1794 = getelementptr i8, ptr %8663, i64 %8669
  %private.contiguous.preserve1795 = load <8 x float>, ptr %private.contiguous.address1794, align 4
  %8670 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8163, <8 x float> %private.contiguous.preserve1795
  store <8 x float> %8670, ptr %private.contiguous.address1794, align 4
  %8671 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8672 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8673 = add <8 x i64> %8672, splat (i64 992)
  %8674 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8671, 0
  %8675 = insertvalue { <8 x ptr>, <8 x i64> } %8674, <8 x i64> %8673, 1
  %8676 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8677 = extractvalue { <8 x ptr>, <8 x i64> } %8675, 1
  %8678 = extractelement <8 x ptr> %8676, i32 0
  %8679 = extractelement <8 x i64> %8677, i32 %7915
  %8680 = zext i32 %7915 to i64
  %8681 = mul i64 %8680, 4
  %8682 = sub i64 %8679, %8681
  %8683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8684 = select i1 %8683, i64 %8682, i64 0
  %private.contiguous.address1796 = getelementptr i8, ptr %8678, i64 %8684
  %private.contiguous.preserve1797 = load <8 x float>, ptr %private.contiguous.address1796, align 4
  %8685 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8164, <8 x float> %private.contiguous.preserve1797
  store <8 x float> %8685, ptr %private.contiguous.address1796, align 4
  %8686 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8687 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8688 = add <8 x i64> %8687, splat (i64 1024)
  %8689 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8686, 0
  %8690 = insertvalue { <8 x ptr>, <8 x i64> } %8689, <8 x i64> %8688, 1
  %8691 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8692 = extractvalue { <8 x ptr>, <8 x i64> } %8690, 1
  %8693 = extractelement <8 x ptr> %8691, i32 0
  %8694 = extractelement <8 x i64> %8692, i32 %7915
  %8695 = zext i32 %7915 to i64
  %8696 = mul i64 %8695, 4
  %8697 = sub i64 %8694, %8696
  %8698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8699 = select i1 %8698, i64 %8697, i64 0
  %private.contiguous.address1798 = getelementptr i8, ptr %8693, i64 %8699
  %private.contiguous.preserve1799 = load <8 x float>, ptr %private.contiguous.address1798, align 4
  %8700 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8165, <8 x float> %private.contiguous.preserve1799
  store <8 x float> %8700, ptr %private.contiguous.address1798, align 4
  %8701 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8702 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8703 = add <8 x i64> %8702, splat (i64 1056)
  %8704 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8701, 0
  %8705 = insertvalue { <8 x ptr>, <8 x i64> } %8704, <8 x i64> %8703, 1
  %8706 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8707 = extractvalue { <8 x ptr>, <8 x i64> } %8705, 1
  %8708 = extractelement <8 x ptr> %8706, i32 0
  %8709 = extractelement <8 x i64> %8707, i32 %7915
  %8710 = zext i32 %7915 to i64
  %8711 = mul i64 %8710, 4
  %8712 = sub i64 %8709, %8711
  %8713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8714 = select i1 %8713, i64 %8712, i64 0
  %private.contiguous.address1800 = getelementptr i8, ptr %8708, i64 %8714
  %private.contiguous.preserve1801 = load <8 x float>, ptr %private.contiguous.address1800, align 4
  %8715 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8166, <8 x float> %private.contiguous.preserve1801
  store <8 x float> %8715, ptr %private.contiguous.address1800, align 4
  %8716 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8717 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8718 = add <8 x i64> %8717, splat (i64 1088)
  %8719 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8716, 0
  %8720 = insertvalue { <8 x ptr>, <8 x i64> } %8719, <8 x i64> %8718, 1
  %8721 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8722 = extractvalue { <8 x ptr>, <8 x i64> } %8720, 1
  %8723 = extractelement <8 x ptr> %8721, i32 0
  %8724 = extractelement <8 x i64> %8722, i32 %7915
  %8725 = zext i32 %7915 to i64
  %8726 = mul i64 %8725, 4
  %8727 = sub i64 %8724, %8726
  %8728 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8729 = select i1 %8728, i64 %8727, i64 0
  %private.contiguous.address1802 = getelementptr i8, ptr %8723, i64 %8729
  %private.contiguous.preserve1803 = load <8 x float>, ptr %private.contiguous.address1802, align 4
  %8730 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8167, <8 x float> %private.contiguous.preserve1803
  store <8 x float> %8730, ptr %private.contiguous.address1802, align 4
  %8731 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8732 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8733 = add <8 x i64> %8732, splat (i64 1120)
  %8734 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8731, 0
  %8735 = insertvalue { <8 x ptr>, <8 x i64> } %8734, <8 x i64> %8733, 1
  %8736 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8737 = extractvalue { <8 x ptr>, <8 x i64> } %8735, 1
  %8738 = extractelement <8 x ptr> %8736, i32 0
  %8739 = extractelement <8 x i64> %8737, i32 %7915
  %8740 = zext i32 %7915 to i64
  %8741 = mul i64 %8740, 4
  %8742 = sub i64 %8739, %8741
  %8743 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8744 = select i1 %8743, i64 %8742, i64 0
  %private.contiguous.address1804 = getelementptr i8, ptr %8738, i64 %8744
  %private.contiguous.preserve1805 = load <8 x float>, ptr %private.contiguous.address1804, align 4
  %8745 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8168, <8 x float> %private.contiguous.preserve1805
  store <8 x float> %8745, ptr %private.contiguous.address1804, align 4
  %8746 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8747 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8748 = add <8 x i64> %8747, splat (i64 1152)
  %8749 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8746, 0
  %8750 = insertvalue { <8 x ptr>, <8 x i64> } %8749, <8 x i64> %8748, 1
  %8751 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8752 = extractvalue { <8 x ptr>, <8 x i64> } %8750, 1
  %8753 = extractelement <8 x ptr> %8751, i32 0
  %8754 = extractelement <8 x i64> %8752, i32 %7915
  %8755 = zext i32 %7915 to i64
  %8756 = mul i64 %8755, 4
  %8757 = sub i64 %8754, %8756
  %8758 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8759 = select i1 %8758, i64 %8757, i64 0
  %private.contiguous.address1806 = getelementptr i8, ptr %8753, i64 %8759
  %private.contiguous.preserve1807 = load <8 x float>, ptr %private.contiguous.address1806, align 4
  %8760 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8169, <8 x float> %private.contiguous.preserve1807
  store <8 x float> %8760, ptr %private.contiguous.address1806, align 4
  %8761 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8762 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8763 = add <8 x i64> %8762, splat (i64 1184)
  %8764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8761, 0
  %8765 = insertvalue { <8 x ptr>, <8 x i64> } %8764, <8 x i64> %8763, 1
  %8766 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8767 = extractvalue { <8 x ptr>, <8 x i64> } %8765, 1
  %8768 = extractelement <8 x ptr> %8766, i32 0
  %8769 = extractelement <8 x i64> %8767, i32 %7915
  %8770 = zext i32 %7915 to i64
  %8771 = mul i64 %8770, 4
  %8772 = sub i64 %8769, %8771
  %8773 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8774 = select i1 %8773, i64 %8772, i64 0
  %private.contiguous.address1808 = getelementptr i8, ptr %8768, i64 %8774
  %private.contiguous.preserve1809 = load <8 x float>, ptr %private.contiguous.address1808, align 4
  %8775 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8170, <8 x float> %private.contiguous.preserve1809
  store <8 x float> %8775, ptr %private.contiguous.address1808, align 4
  %8776 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8777 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8778 = add <8 x i64> %8777, splat (i64 1216)
  %8779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8776, 0
  %8780 = insertvalue { <8 x ptr>, <8 x i64> } %8779, <8 x i64> %8778, 1
  %8781 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8782 = extractvalue { <8 x ptr>, <8 x i64> } %8780, 1
  %8783 = extractelement <8 x ptr> %8781, i32 0
  %8784 = extractelement <8 x i64> %8782, i32 %7915
  %8785 = zext i32 %7915 to i64
  %8786 = mul i64 %8785, 4
  %8787 = sub i64 %8784, %8786
  %8788 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8789 = select i1 %8788, i64 %8787, i64 0
  %private.contiguous.address1810 = getelementptr i8, ptr %8783, i64 %8789
  %private.contiguous.preserve1811 = load <8 x float>, ptr %private.contiguous.address1810, align 4
  %8790 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8171, <8 x float> %private.contiguous.preserve1811
  store <8 x float> %8790, ptr %private.contiguous.address1810, align 4
  %8791 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8792 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8793 = add <8 x i64> %8792, splat (i64 1248)
  %8794 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8791, 0
  %8795 = insertvalue { <8 x ptr>, <8 x i64> } %8794, <8 x i64> %8793, 1
  %8796 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8797 = extractvalue { <8 x ptr>, <8 x i64> } %8795, 1
  %8798 = extractelement <8 x ptr> %8796, i32 0
  %8799 = extractelement <8 x i64> %8797, i32 %7915
  %8800 = zext i32 %7915 to i64
  %8801 = mul i64 %8800, 4
  %8802 = sub i64 %8799, %8801
  %8803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8804 = select i1 %8803, i64 %8802, i64 0
  %private.contiguous.address1812 = getelementptr i8, ptr %8798, i64 %8804
  %private.contiguous.preserve1813 = load <8 x float>, ptr %private.contiguous.address1812, align 4
  %8805 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8172, <8 x float> %private.contiguous.preserve1813
  store <8 x float> %8805, ptr %private.contiguous.address1812, align 4
  %8806 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8807 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8808 = add <8 x i64> %8807, splat (i64 1280)
  %8809 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8806, 0
  %8810 = insertvalue { <8 x ptr>, <8 x i64> } %8809, <8 x i64> %8808, 1
  %8811 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8812 = extractvalue { <8 x ptr>, <8 x i64> } %8810, 1
  %8813 = extractelement <8 x ptr> %8811, i32 0
  %8814 = extractelement <8 x i64> %8812, i32 %7915
  %8815 = zext i32 %7915 to i64
  %8816 = mul i64 %8815, 4
  %8817 = sub i64 %8814, %8816
  %8818 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8819 = select i1 %8818, i64 %8817, i64 0
  %private.contiguous.address1814 = getelementptr i8, ptr %8813, i64 %8819
  %private.contiguous.preserve1815 = load <8 x float>, ptr %private.contiguous.address1814, align 4
  %8820 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8173, <8 x float> %private.contiguous.preserve1815
  store <8 x float> %8820, ptr %private.contiguous.address1814, align 4
  %8821 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8822 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8823 = add <8 x i64> %8822, splat (i64 1312)
  %8824 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8821, 0
  %8825 = insertvalue { <8 x ptr>, <8 x i64> } %8824, <8 x i64> %8823, 1
  %8826 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8827 = extractvalue { <8 x ptr>, <8 x i64> } %8825, 1
  %8828 = extractelement <8 x ptr> %8826, i32 0
  %8829 = extractelement <8 x i64> %8827, i32 %7915
  %8830 = zext i32 %7915 to i64
  %8831 = mul i64 %8830, 4
  %8832 = sub i64 %8829, %8831
  %8833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8834 = select i1 %8833, i64 %8832, i64 0
  %private.contiguous.address1816 = getelementptr i8, ptr %8828, i64 %8834
  %private.contiguous.preserve1817 = load <8 x float>, ptr %private.contiguous.address1816, align 4
  %8835 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8174, <8 x float> %private.contiguous.preserve1817
  store <8 x float> %8835, ptr %private.contiguous.address1816, align 4
  %8836 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8837 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8838 = add <8 x i64> %8837, splat (i64 1344)
  %8839 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8836, 0
  %8840 = insertvalue { <8 x ptr>, <8 x i64> } %8839, <8 x i64> %8838, 1
  %8841 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8842 = extractvalue { <8 x ptr>, <8 x i64> } %8840, 1
  %8843 = extractelement <8 x ptr> %8841, i32 0
  %8844 = extractelement <8 x i64> %8842, i32 %7915
  %8845 = zext i32 %7915 to i64
  %8846 = mul i64 %8845, 4
  %8847 = sub i64 %8844, %8846
  %8848 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8849 = select i1 %8848, i64 %8847, i64 0
  %private.contiguous.address1818 = getelementptr i8, ptr %8843, i64 %8849
  %private.contiguous.preserve1819 = load <8 x float>, ptr %private.contiguous.address1818, align 4
  %8850 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8175, <8 x float> %private.contiguous.preserve1819
  store <8 x float> %8850, ptr %private.contiguous.address1818, align 4
  %8851 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8852 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8853 = add <8 x i64> %8852, splat (i64 1376)
  %8854 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8851, 0
  %8855 = insertvalue { <8 x ptr>, <8 x i64> } %8854, <8 x i64> %8853, 1
  %8856 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8857 = extractvalue { <8 x ptr>, <8 x i64> } %8855, 1
  %8858 = extractelement <8 x ptr> %8856, i32 0
  %8859 = extractelement <8 x i64> %8857, i32 %7915
  %8860 = zext i32 %7915 to i64
  %8861 = mul i64 %8860, 4
  %8862 = sub i64 %8859, %8861
  %8863 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8864 = select i1 %8863, i64 %8862, i64 0
  %private.contiguous.address1820 = getelementptr i8, ptr %8858, i64 %8864
  %private.contiguous.preserve1821 = load <8 x float>, ptr %private.contiguous.address1820, align 4
  %8865 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8176, <8 x float> %private.contiguous.preserve1821
  store <8 x float> %8865, ptr %private.contiguous.address1820, align 4
  %8866 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8867 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8868 = add <8 x i64> %8867, splat (i64 1408)
  %8869 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8866, 0
  %8870 = insertvalue { <8 x ptr>, <8 x i64> } %8869, <8 x i64> %8868, 1
  %8871 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8872 = extractvalue { <8 x ptr>, <8 x i64> } %8870, 1
  %8873 = extractelement <8 x ptr> %8871, i32 0
  %8874 = extractelement <8 x i64> %8872, i32 %7915
  %8875 = zext i32 %7915 to i64
  %8876 = mul i64 %8875, 4
  %8877 = sub i64 %8874, %8876
  %8878 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8879 = select i1 %8878, i64 %8877, i64 0
  %private.contiguous.address1822 = getelementptr i8, ptr %8873, i64 %8879
  %private.contiguous.preserve1823 = load <8 x float>, ptr %private.contiguous.address1822, align 4
  %8880 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8177, <8 x float> %private.contiguous.preserve1823
  store <8 x float> %8880, ptr %private.contiguous.address1822, align 4
  %8881 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8882 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8883 = add <8 x i64> %8882, splat (i64 1440)
  %8884 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8881, 0
  %8885 = insertvalue { <8 x ptr>, <8 x i64> } %8884, <8 x i64> %8883, 1
  %8886 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8887 = extractvalue { <8 x ptr>, <8 x i64> } %8885, 1
  %8888 = extractelement <8 x ptr> %8886, i32 0
  %8889 = extractelement <8 x i64> %8887, i32 %7915
  %8890 = zext i32 %7915 to i64
  %8891 = mul i64 %8890, 4
  %8892 = sub i64 %8889, %8891
  %8893 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8894 = select i1 %8893, i64 %8892, i64 0
  %private.contiguous.address1824 = getelementptr i8, ptr %8888, i64 %8894
  %private.contiguous.preserve1825 = load <8 x float>, ptr %private.contiguous.address1824, align 4
  %8895 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8178, <8 x float> %private.contiguous.preserve1825
  store <8 x float> %8895, ptr %private.contiguous.address1824, align 4
  %8896 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8897 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8898 = add <8 x i64> %8897, splat (i64 1472)
  %8899 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8896, 0
  %8900 = insertvalue { <8 x ptr>, <8 x i64> } %8899, <8 x i64> %8898, 1
  %8901 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8902 = extractvalue { <8 x ptr>, <8 x i64> } %8900, 1
  %8903 = extractelement <8 x ptr> %8901, i32 0
  %8904 = extractelement <8 x i64> %8902, i32 %7915
  %8905 = zext i32 %7915 to i64
  %8906 = mul i64 %8905, 4
  %8907 = sub i64 %8904, %8906
  %8908 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8909 = select i1 %8908, i64 %8907, i64 0
  %private.contiguous.address1826 = getelementptr i8, ptr %8903, i64 %8909
  %private.contiguous.preserve1827 = load <8 x float>, ptr %private.contiguous.address1826, align 4
  %8910 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8179, <8 x float> %private.contiguous.preserve1827
  store <8 x float> %8910, ptr %private.contiguous.address1826, align 4
  %8911 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8912 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8913 = add <8 x i64> %8912, splat (i64 1504)
  %8914 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8911, 0
  %8915 = insertvalue { <8 x ptr>, <8 x i64> } %8914, <8 x i64> %8913, 1
  %8916 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8917 = extractvalue { <8 x ptr>, <8 x i64> } %8915, 1
  %8918 = extractelement <8 x ptr> %8916, i32 0
  %8919 = extractelement <8 x i64> %8917, i32 %7915
  %8920 = zext i32 %7915 to i64
  %8921 = mul i64 %8920, 4
  %8922 = sub i64 %8919, %8921
  %8923 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8924 = select i1 %8923, i64 %8922, i64 0
  %private.contiguous.address1828 = getelementptr i8, ptr %8918, i64 %8924
  %private.contiguous.preserve1829 = load <8 x float>, ptr %private.contiguous.address1828, align 4
  %8925 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8180, <8 x float> %private.contiguous.preserve1829
  store <8 x float> %8925, ptr %private.contiguous.address1828, align 4
  %8926 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8927 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8928 = add <8 x i64> %8927, splat (i64 1536)
  %8929 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8926, 0
  %8930 = insertvalue { <8 x ptr>, <8 x i64> } %8929, <8 x i64> %8928, 1
  %8931 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8932 = extractvalue { <8 x ptr>, <8 x i64> } %8930, 1
  %8933 = extractelement <8 x ptr> %8931, i32 0
  %8934 = extractelement <8 x i64> %8932, i32 %7915
  %8935 = zext i32 %7915 to i64
  %8936 = mul i64 %8935, 4
  %8937 = sub i64 %8934, %8936
  %8938 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8939 = select i1 %8938, i64 %8937, i64 0
  %private.contiguous.address1830 = getelementptr i8, ptr %8933, i64 %8939
  %private.contiguous.preserve1831 = load <8 x float>, ptr %private.contiguous.address1830, align 4
  %8940 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8181, <8 x float> %private.contiguous.preserve1831
  store <8 x float> %8940, ptr %private.contiguous.address1830, align 4
  %8941 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8942 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8943 = add <8 x i64> %8942, splat (i64 1568)
  %8944 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8941, 0
  %8945 = insertvalue { <8 x ptr>, <8 x i64> } %8944, <8 x i64> %8943, 1
  %8946 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8947 = extractvalue { <8 x ptr>, <8 x i64> } %8945, 1
  %8948 = extractelement <8 x ptr> %8946, i32 0
  %8949 = extractelement <8 x i64> %8947, i32 %7915
  %8950 = zext i32 %7915 to i64
  %8951 = mul i64 %8950, 4
  %8952 = sub i64 %8949, %8951
  %8953 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8954 = select i1 %8953, i64 %8952, i64 0
  %private.contiguous.address1832 = getelementptr i8, ptr %8948, i64 %8954
  %private.contiguous.preserve1833 = load <8 x float>, ptr %private.contiguous.address1832, align 4
  %8955 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8182, <8 x float> %private.contiguous.preserve1833
  store <8 x float> %8955, ptr %private.contiguous.address1832, align 4
  %8956 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8957 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8958 = add <8 x i64> %8957, splat (i64 1600)
  %8959 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8956, 0
  %8960 = insertvalue { <8 x ptr>, <8 x i64> } %8959, <8 x i64> %8958, 1
  %8961 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8962 = extractvalue { <8 x ptr>, <8 x i64> } %8960, 1
  %8963 = extractelement <8 x ptr> %8961, i32 0
  %8964 = extractelement <8 x i64> %8962, i32 %7915
  %8965 = zext i32 %7915 to i64
  %8966 = mul i64 %8965, 4
  %8967 = sub i64 %8964, %8966
  %8968 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8969 = select i1 %8968, i64 %8967, i64 0
  %private.contiguous.address1834 = getelementptr i8, ptr %8963, i64 %8969
  %private.contiguous.preserve1835 = load <8 x float>, ptr %private.contiguous.address1834, align 4
  %8970 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8183, <8 x float> %private.contiguous.preserve1835
  store <8 x float> %8970, ptr %private.contiguous.address1834, align 4
  %8971 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8972 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8973 = add <8 x i64> %8972, splat (i64 1632)
  %8974 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8971, 0
  %8975 = insertvalue { <8 x ptr>, <8 x i64> } %8974, <8 x i64> %8973, 1
  %8976 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8977 = extractvalue { <8 x ptr>, <8 x i64> } %8975, 1
  %8978 = extractelement <8 x ptr> %8976, i32 0
  %8979 = extractelement <8 x i64> %8977, i32 %7915
  %8980 = zext i32 %7915 to i64
  %8981 = mul i64 %8980, 4
  %8982 = sub i64 %8979, %8981
  %8983 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8984 = select i1 %8983, i64 %8982, i64 0
  %private.contiguous.address1836 = getelementptr i8, ptr %8978, i64 %8984
  %private.contiguous.preserve1837 = load <8 x float>, ptr %private.contiguous.address1836, align 4
  %8985 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8184, <8 x float> %private.contiguous.preserve1837
  store <8 x float> %8985, ptr %private.contiguous.address1836, align 4
  %8986 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8987 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8988 = add <8 x i64> %8987, splat (i64 1664)
  %8989 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8986, 0
  %8990 = insertvalue { <8 x ptr>, <8 x i64> } %8989, <8 x i64> %8988, 1
  %8991 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8992 = extractvalue { <8 x ptr>, <8 x i64> } %8990, 1
  %8993 = extractelement <8 x ptr> %8991, i32 0
  %8994 = extractelement <8 x i64> %8992, i32 %7915
  %8995 = zext i32 %7915 to i64
  %8996 = mul i64 %8995, 4
  %8997 = sub i64 %8994, %8996
  %8998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %8999 = select i1 %8998, i64 %8997, i64 0
  %private.contiguous.address1838 = getelementptr i8, ptr %8993, i64 %8999
  %private.contiguous.preserve1839 = load <8 x float>, ptr %private.contiguous.address1838, align 4
  %9000 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8185, <8 x float> %private.contiguous.preserve1839
  store <8 x float> %9000, ptr %private.contiguous.address1838, align 4
  %9001 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9002 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %9003 = add <8 x i64> %9002, splat (i64 1696)
  %9004 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9001, 0
  %9005 = insertvalue { <8 x ptr>, <8 x i64> } %9004, <8 x i64> %9003, 1
  %9006 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9007 = extractvalue { <8 x ptr>, <8 x i64> } %9005, 1
  %9008 = extractelement <8 x ptr> %9006, i32 0
  %9009 = extractelement <8 x i64> %9007, i32 %7915
  %9010 = zext i32 %7915 to i64
  %9011 = mul i64 %9010, 4
  %9012 = sub i64 %9009, %9011
  %9013 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %9014 = select i1 %9013, i64 %9012, i64 0
  %private.contiguous.address1840 = getelementptr i8, ptr %9008, i64 %9014
  %private.contiguous.preserve1841 = load <8 x float>, ptr %private.contiguous.address1840, align 4
  %9015 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8186, <8 x float> %private.contiguous.preserve1841
  store <8 x float> %9015, ptr %private.contiguous.address1840, align 4
  %9016 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9017 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %9018 = add <8 x i64> %9017, splat (i64 1728)
  %9019 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9016, 0
  %9020 = insertvalue { <8 x ptr>, <8 x i64> } %9019, <8 x i64> %9018, 1
  %9021 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9022 = extractvalue { <8 x ptr>, <8 x i64> } %9020, 1
  %9023 = extractelement <8 x ptr> %9021, i32 0
  %9024 = extractelement <8 x i64> %9022, i32 %7915
  %9025 = zext i32 %7915 to i64
  %9026 = mul i64 %9025, 4
  %9027 = sub i64 %9024, %9026
  %9028 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %9029 = select i1 %9028, i64 %9027, i64 0
  %private.contiguous.address1842 = getelementptr i8, ptr %9023, i64 %9029
  %private.contiguous.preserve1843 = load <8 x float>, ptr %private.contiguous.address1842, align 4
  %9030 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8187, <8 x float> %private.contiguous.preserve1843
  store <8 x float> %9030, ptr %private.contiguous.address1842, align 4
  %9031 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9032 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %9033 = add <8 x i64> %9032, splat (i64 1760)
  %9034 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9031, 0
  %9035 = insertvalue { <8 x ptr>, <8 x i64> } %9034, <8 x i64> %9033, 1
  %9036 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9037 = extractvalue { <8 x ptr>, <8 x i64> } %9035, 1
  %9038 = extractelement <8 x ptr> %9036, i32 0
  %9039 = extractelement <8 x i64> %9037, i32 %7915
  %9040 = zext i32 %7915 to i64
  %9041 = mul i64 %9040, 4
  %9042 = sub i64 %9039, %9041
  %9043 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %9044 = select i1 %9043, i64 %9042, i64 0
  %private.contiguous.address1844 = getelementptr i8, ptr %9038, i64 %9044
  %private.contiguous.preserve1845 = load <8 x float>, ptr %private.contiguous.address1844, align 4
  %9045 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8188, <8 x float> %private.contiguous.preserve1845
  store <8 x float> %9045, ptr %private.contiguous.address1844, align 4
  %9046 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9047 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %9048 = add <8 x i64> %9047, splat (i64 1792)
  %9049 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9046, 0
  %9050 = insertvalue { <8 x ptr>, <8 x i64> } %9049, <8 x i64> %9048, 1
  %9051 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9052 = extractvalue { <8 x ptr>, <8 x i64> } %9050, 1
  %9053 = extractelement <8 x ptr> %9051, i32 0
  %9054 = extractelement <8 x i64> %9052, i32 %7915
  %9055 = zext i32 %7915 to i64
  %9056 = mul i64 %9055, 4
  %9057 = sub i64 %9054, %9056
  %9058 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %9059 = select i1 %9058, i64 %9057, i64 0
  %private.contiguous.address1846 = getelementptr i8, ptr %9053, i64 %9059
  %private.contiguous.preserve1847 = load <8 x float>, ptr %private.contiguous.address1846, align 4
  %9060 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8189, <8 x float> %private.contiguous.preserve1847
  store <8 x float> %9060, ptr %private.contiguous.address1846, align 4
  %9061 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9062 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %9063 = add <8 x i64> %9062, splat (i64 1824)
  %9064 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9061, 0
  %9065 = insertvalue { <8 x ptr>, <8 x i64> } %9064, <8 x i64> %9063, 1
  %9066 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9067 = extractvalue { <8 x ptr>, <8 x i64> } %9065, 1
  %9068 = extractelement <8 x ptr> %9066, i32 0
  %9069 = extractelement <8 x i64> %9067, i32 %7915
  %9070 = zext i32 %7915 to i64
  %9071 = mul i64 %9070, 4
  %9072 = sub i64 %9069, %9071
  %9073 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %9074 = select i1 %9073, i64 %9072, i64 0
  %private.contiguous.address1848 = getelementptr i8, ptr %9068, i64 %9074
  %private.contiguous.preserve1849 = load <8 x float>, ptr %private.contiguous.address1848, align 4
  %9075 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8190, <8 x float> %private.contiguous.preserve1849
  store <8 x float> %9075, ptr %private.contiguous.address1848, align 4
  %9076 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9077 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %9078 = add <8 x i64> %9077, splat (i64 1856)
  %9079 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9076, 0
  %9080 = insertvalue { <8 x ptr>, <8 x i64> } %9079, <8 x i64> %9078, 1
  %9081 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9082 = extractvalue { <8 x ptr>, <8 x i64> } %9080, 1
  %9083 = extractelement <8 x ptr> %9081, i32 0
  %9084 = extractelement <8 x i64> %9082, i32 %7915
  %9085 = zext i32 %7915 to i64
  %9086 = mul i64 %9085, 4
  %9087 = sub i64 %9084, %9086
  %9088 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %9089 = select i1 %9088, i64 %9087, i64 0
  %private.contiguous.address1850 = getelementptr i8, ptr %9083, i64 %9089
  %private.contiguous.preserve1851 = load <8 x float>, ptr %private.contiguous.address1850, align 4
  %9090 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8191, <8 x float> %private.contiguous.preserve1851
  store <8 x float> %9090, ptr %private.contiguous.address1850, align 4
  %9091 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9092 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %9093 = add <8 x i64> %9092, splat (i64 1888)
  %9094 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9091, 0
  %9095 = insertvalue { <8 x ptr>, <8 x i64> } %9094, <8 x i64> %9093, 1
  %9096 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9097 = extractvalue { <8 x ptr>, <8 x i64> } %9095, 1
  %9098 = extractelement <8 x ptr> %9096, i32 0
  %9099 = extractelement <8 x i64> %9097, i32 %7915
  %9100 = zext i32 %7915 to i64
  %9101 = mul i64 %9100, 4
  %9102 = sub i64 %9099, %9101
  %9103 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %9104 = select i1 %9103, i64 %9102, i64 0
  %private.contiguous.address1852 = getelementptr i8, ptr %9098, i64 %9104
  %private.contiguous.preserve1853 = load <8 x float>, ptr %private.contiguous.address1852, align 4
  %9105 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8192, <8 x float> %private.contiguous.preserve1853
  store <8 x float> %9105, ptr %private.contiguous.address1852, align 4
  %9106 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9107 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %9108 = add <8 x i64> %9107, splat (i64 1920)
  %9109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9106, 0
  %9110 = insertvalue { <8 x ptr>, <8 x i64> } %9109, <8 x i64> %9108, 1
  %9111 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9112 = extractvalue { <8 x ptr>, <8 x i64> } %9110, 1
  %9113 = extractelement <8 x ptr> %9111, i32 0
  %9114 = extractelement <8 x i64> %9112, i32 %7915
  %9115 = zext i32 %7915 to i64
  %9116 = mul i64 %9115, 4
  %9117 = sub i64 %9114, %9116
  %9118 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %9119 = select i1 %9118, i64 %9117, i64 0
  %private.contiguous.address1854 = getelementptr i8, ptr %9113, i64 %9119
  %private.contiguous.preserve1855 = load <8 x float>, ptr %private.contiguous.address1854, align 4
  %9120 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8193, <8 x float> %private.contiguous.preserve1855
  store <8 x float> %9120, ptr %private.contiguous.address1854, align 4
  %9121 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9122 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %9123 = add <8 x i64> %9122, splat (i64 1952)
  %9124 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9121, 0
  %9125 = insertvalue { <8 x ptr>, <8 x i64> } %9124, <8 x i64> %9123, 1
  %9126 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9127 = extractvalue { <8 x ptr>, <8 x i64> } %9125, 1
  %9128 = extractelement <8 x ptr> %9126, i32 0
  %9129 = extractelement <8 x i64> %9127, i32 %7915
  %9130 = zext i32 %7915 to i64
  %9131 = mul i64 %9130, 4
  %9132 = sub i64 %9129, %9131
  %9133 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %9134 = select i1 %9133, i64 %9132, i64 0
  %private.contiguous.address1856 = getelementptr i8, ptr %9128, i64 %9134
  %private.contiguous.preserve1857 = load <8 x float>, ptr %private.contiguous.address1856, align 4
  %9135 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8194, <8 x float> %private.contiguous.preserve1857
  store <8 x float> %9135, ptr %private.contiguous.address1856, align 4
  %9136 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9137 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %9138 = add <8 x i64> %9137, splat (i64 1984)
  %9139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9136, 0
  %9140 = insertvalue { <8 x ptr>, <8 x i64> } %9139, <8 x i64> %9138, 1
  %9141 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9142 = extractvalue { <8 x ptr>, <8 x i64> } %9140, 1
  %9143 = extractelement <8 x ptr> %9141, i32 0
  %9144 = extractelement <8 x i64> %9142, i32 %7915
  %9145 = zext i32 %7915 to i64
  %9146 = mul i64 %9145, 4
  %9147 = sub i64 %9144, %9146
  %9148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %9149 = select i1 %9148, i64 %9147, i64 0
  %private.contiguous.address1858 = getelementptr i8, ptr %9143, i64 %9149
  %private.contiguous.preserve1859 = load <8 x float>, ptr %private.contiguous.address1858, align 4
  %9150 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8195, <8 x float> %private.contiguous.preserve1859
  store <8 x float> %9150, ptr %private.contiguous.address1858, align 4
  %9151 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9152 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %9153 = add <8 x i64> %9152, splat (i64 2016)
  %9154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9151, 0
  %9155 = insertvalue { <8 x ptr>, <8 x i64> } %9154, <8 x i64> %9153, 1
  %9156 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %9157 = extractvalue { <8 x ptr>, <8 x i64> } %9155, 1
  %9158 = extractelement <8 x ptr> %9156, i32 0
  %9159 = extractelement <8 x i64> %9157, i32 %7915
  %9160 = zext i32 %7915 to i64
  %9161 = mul i64 %9160, 4
  %9162 = sub i64 %9159, %9161
  %9163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  %9164 = select i1 %9163, i64 %9162, i64 0
  %private.contiguous.address1860 = getelementptr i8, ptr %9158, i64 %9164
  %private.contiguous.preserve1861 = load <8 x float>, ptr %private.contiguous.address1860, align 4
  %9165 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %8196, <8 x float> %private.contiguous.preserve1861
  store <8 x float> %9165, ptr %private.contiguous.address1860, align 4
  %.state1862 = load <8 x float>, ptr %.slot50, align 32
  %9166 = fmul <8 x float> %.state1862, %native.exp
  %9167 = load <8 x float>, ptr %.spill286, align 32
  %9168 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %9166, <8 x float> %9167
  store <8 x float> %9168, ptr %.spill286, align 32
  %.state1863 = load <8 x float>, ptr %.slot51, align 32
  %9169 = fmul <8 x float> %.state1863, %native.exp1531
  %9170 = load <8 x float>, ptr %.spill287, align 32
  %9171 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %9169, <8 x float> %9170
  store <8 x float> %9171, ptr %.spill287, align 32
  %.state1864 = load <8 x float>, ptr %.slot52, align 32
  %9172 = fmul <8 x float> %.state1864, %native.exp1532
  %9173 = load <8 x float>, ptr %.spill288, align 32
  %9174 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %9172, <8 x float> %9173
  store <8 x float> %9174, ptr %.spill288, align 32
  %.state1865 = load <8 x float>, ptr %.slot53, align 32
  %9175 = fmul <8 x float> %.state1865, %native.exp1533
  %9176 = load <8 x float>, ptr %.spill289, align 32
  %9177 = select <8 x i1> %convergence.cascade.result1518, <8 x float> %9175, <8 x float> %9176
  store <8 x float> %9177, ptr %.spill289, align 32
  %9178 = load <8 x i64>, ptr %.slot56, align 64
  %9179 = select <8 x i1> %convergence.cascade.result1518, <8 x i64> zeroinitializer, <8 x i64> %9178
  store <8 x i64> %9179, ptr %.slot56, align 64
  %9180 = load <8 x float>, ptr %.slot41, align 32
  %9181 = select <8 x i1> %convergence.cascade.result1518, <8 x float> zeroinitializer, <8 x float> %9180
  store <8 x float> %9181, ptr %.slot41, align 32
  store <8 x i1> %convergence.cascade.result1518, ptr %current.mask, align 1
  %9182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1518)
  br i1 %9182, label %schedule.81, label %scheduler.loop

varying.divergent1867:                            ; preds = %schedule.81
  %9183 = load i32, ptr %current.token, align 4
  %9184 = icmp ne i32 %9183, 0
  %9185 = sub i32 %9183, 1
  %9186 = select i1 %9184, i32 %9185, i32 0
  %9187 = load i8, ptr %frame.active, align 1
  %9188 = trunc i32 %9186 to i8
  %9189 = shl i8 1, %9188
  %9190 = and i8 %9187, %9189
  %9191 = icmp ne i8 %9190, 0
  %9192 = load <8 x i32>, ptr %frame.static.id, align 32
  %9193 = extractelement <8 x i32> %9192, i32 %9186
  %9194 = icmp eq i32 %9193, 28
  %9195 = and i1 %9191, %9194
  %9196 = and i1 %9184, %9195
  %9197 = xor i1 %9196, true
  %9198 = and i1 true, %9197
  %9199 = xor i8 %9187, -1
  %9200 = icmp ne i8 %9199, 0
  %9201 = xor i1 %9200, true
  %9202 = and i1 %9198, %9201
  br i1 %9202, label %convergence.overflow.trap1869, label %convergence.overflow.resume1870

varying.coherent1868:                             ; preds = %schedule.81
  br i1 %2107, label %varying.coherent.true1873, label %varying.coherent.false1874

convergence.overflow.trap1869:                    ; preds = %varying.divergent1867
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1870:                  ; preds = %varying.divergent1867
  %9203 = call i8 @llvm.cttz.i8(i8 %9199, i1 false)
  %9204 = zext i8 %9203 to i32
  %9205 = select i1 %9200, i32 %9204, i32 0
  %9206 = trunc i32 %9205 to i8
  %9207 = shl i8 1, %9206
  %9208 = or i8 %9187, %9207
  %9209 = select i1 %9198, i8 %9208, i8 %9187
  store i8 %9209, ptr %frame.active, align 1
  %9210 = load <8 x i32>, ptr %frame.static.id, align 32
  %9211 = extractelement <8 x i32> %9210, i32 %9205
  %9212 = select i1 %9198, i32 28, i32 %9211
  %9213 = load <8 x i32>, ptr %frame.static.id, align 32
  %9214 = insertelement <8 x i32> %9213, i32 %9212, i32 %9205
  store <8 x i32> %9214, ptr %frame.static.id, align 32
  %9215 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9216 = extractelement <8 x i32> %9215, i32 %9205
  %9217 = select i1 %9198, i32 %9183, i32 %9216
  %9218 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9219 = insertelement <8 x i32> %9218, i32 %9217, i32 %9205
  store <8 x i32> %9219, ptr %frame.parent.token, align 32
  %9220 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9205
  %9221 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9205
  %9222 = load <8 x i1>, ptr %9220, align 1
  %9223 = load <8 x i1>, ptr %9221, align 1
  %9224 = select i1 %9198, <8 x i1> %2097, <8 x i1> %9222
  store <8 x i1> %9224, ptr %9220, align 1
  %9225 = select i1 %9198, <8 x i1> zeroinitializer, <8 x i1> %9223
  store <8 x i1> %9225, ptr %9221, align 1
  %9226 = add i32 %9205, 1
  %9227 = select i1 %9196, i32 %9183, i32 %9226
  %9228 = select i1 true, i32 %9227, i32 %9183
  store i32 %9228, ptr %current.token, align 4
  %9229 = load i32, ptr %current.token, align 4
  %9230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2104)
  %9231 = load i32, ptr %ready.count, align 4
  %9232 = icmp uge i32 %9231, 8
  %9233 = and i1 %9230, %9232
  br i1 %9233, label %ready.overflow.trap1871, label %ready.overflow.resume1872

ready.overflow.trap1871:                          ; preds = %convergence.overflow.resume1870
  call void @llvm.trap()
  unreachable

ready.overflow.resume1872:                        ; preds = %convergence.overflow.resume1870
  %9234 = select i1 %9230, i32 %9231, i32 0
  %9235 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9234
  %9236 = load <8 x i1>, ptr %9235, align 1
  %9237 = select i1 %9230, <8 x i1> %2104, <8 x i1> %9236
  store <8 x i1> %9237, ptr %9235, align 1
  %9238 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9234
  %9239 = load i32, ptr %9238, align 4
  %9240 = select i1 %9230, i32 82, i32 %9239
  store i32 %9240, ptr %9238, align 4
  %9241 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9234
  %9242 = load i32, ptr %9241, align 4
  %9243 = select i1 %9230, i32 %9229, i32 %9242
  store i32 %9243, ptr %9241, align 4
  %9244 = add i32 %9231, 1
  %9245 = select i1 %9230, i32 %9244, i32 %9231
  store i32 %9245, ptr %ready.count, align 4
  %9246 = load <8 x i1>, ptr %runnable.mask, align 1
  %9247 = or <8 x i1> %9246, %2104
  store <8 x i1> %9247, ptr %runnable.mask, align 1
  store <8 x i1> %2106, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1873:                        ; preds = %varying.coherent1868
  store <8 x i1> %2097, ptr %current.mask, align 1
  %9248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2097)
  br i1 %9248, label %schedule.82, label %scheduler.loop

varying.coherent.false1874:                       ; preds = %varying.coherent1868
  store <8 x i1> %2097, ptr %current.mask, align 1
  %9249 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2097)
  br i1 %9249, label %schedule.83, label %scheduler.loop

convergence.cascade1879:                          ; preds = %convergence.cascade1879, %schedule.83
  %convergence.cascade.flow1883 = phi <8 x i1> [ %2137, %schedule.83 ], [ %9292, %convergence.cascade1879 ]
  %convergence.cascade.depth1884 = phi i32 [ 0, %schedule.83 ], [ %9293, %convergence.cascade1879 ]
  %9250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1883)
  %9251 = load i32, ptr %current.token, align 4
  %9252 = icmp ne i32 %9251, 0
  %9253 = and i1 %9250, %9252
  %9254 = sub i32 %9251, 1
  %9255 = select i1 %9253, i32 %9254, i32 0
  %9256 = load i8, ptr %frame.active, align 1
  %9257 = trunc i32 %9255 to i8
  %9258 = shl i8 1, %9257
  %9259 = and i8 %9256, %9258
  %9260 = icmp ne i8 %9259, 0
  %9261 = load <8 x i32>, ptr %frame.static.id, align 32
  %9262 = extractelement <8 x i32> %9261, i32 %9255
  %convergence.target.pointer1885 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %9262
  %convergence.dynamic.target1886 = load i32, ptr %convergence.target.pointer1885, align 4
  %9263 = icmp eq i32 %convergence.dynamic.target1886, 83
  %9264 = and i1 %9260, %9263
  %9265 = and i1 %9253, %9264
  %9266 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9255
  %9267 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9255
  %9268 = load <8 x i1>, ptr %9266, align 1
  %9269 = load <8 x i1>, ptr %9267, align 1
  %9270 = or <8 x i1> %9269, %convergence.cascade.flow1883
  %9271 = load <8 x i1>, ptr %live.mask, align 1
  %9272 = and <8 x i1> %9268, %9271
  %9273 = icmp eq <8 x i1> %9270, %9272
  %9274 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9273)
  %9275 = and i1 %9265, %9274
  %9276 = select i1 %9275, <8 x i1> zeroinitializer, <8 x i1> %9270
  %9277 = select i1 %9265, <8 x i1> %9276, <8 x i1> %9269
  store <8 x i1> %9277, ptr %9267, align 1
  %9278 = select i1 %9275, <8 x i1> zeroinitializer, <8 x i1> %9268
  store <8 x i1> %9278, ptr %9266, align 1
  %9279 = trunc i32 %9255 to i8
  %9280 = shl i8 1, %9279
  %9281 = xor i8 %9280, -1
  %9282 = and i8 %9256, %9281
  %9283 = select i1 %9275, i8 %9282, i8 %9256
  store i8 %9283, ptr %frame.active, align 1
  %.splatinsert1887 = insertelement <8 x i1> poison, i1 %9265, i64 0
  %.splat1888 = shufflevector <8 x i1> %.splatinsert1887, <8 x i1> poison, <8 x i32> zeroinitializer
  %9284 = and <8 x i1> %convergence.cascade.flow1883, %.splat1888
  %9285 = load <8 x i1>, ptr %runnable.mask, align 1
  %9286 = xor <8 x i1> %9284, splat (i1 true)
  %9287 = and <8 x i1> %9285, %9286
  store <8 x i1> %9287, ptr %runnable.mask, align 1
  %.splatinsert1889 = insertelement <8 x i1> poison, i1 %9275, i64 0
  %.splat1890 = shufflevector <8 x i1> %.splatinsert1889, <8 x i1> poison, <8 x i32> zeroinitializer
  %9288 = select <8 x i1> %.splat1890, <8 x i1> %9270, <8 x i1> zeroinitializer
  %9289 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9290 = extractelement <8 x i32> %9289, i32 %9255
  %9291 = select i1 %9275, i32 %9290, i32 %9251
  store i32 %9291, ptr %current.token, align 4
  %.splatinsert1891 = insertelement <8 x i1> poison, i1 %9265, i64 0
  %.splat1892 = shufflevector <8 x i1> %.splatinsert1891, <8 x i1> poison, <8 x i32> zeroinitializer
  %9292 = select <8 x i1> %.splat1892, <8 x i1> %9288, <8 x i1> %convergence.cascade.flow1883
  %9293 = add i32 %convergence.cascade.depth1884, 1
  %9294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9292)
  %9295 = icmp ult i32 %9293, 8
  %9296 = and i1 %9294, %9295
  %9297 = and i1 %9265, %9296
  %convergence.parent.token1893 = load i32, ptr %current.token, align 4
  %convergence.parent.present1894 = icmp ne i32 %convergence.parent.token1893, 0
  %9298 = and i1 %9297, %convergence.parent.present1894
  br i1 %9298, label %convergence.cascade1879, label %convergence.cascade.exit1880

convergence.cascade.exit1880:                     ; preds = %convergence.cascade1879, %schedule.83
  %convergence.cascade.result1895 = phi <8 x i1> [ %2137, %schedule.83 ], [ %9292, %convergence.cascade1879 ]
  %9299 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1895)
  br i1 %9299, label %convergence.target.83.ready, label %scheduler.loop

convergence.target.83.ready:                      ; preds = %convergence.cascade.exit1880
  %9300 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1895)
  %9301 = bitcast <8 x i1> %convergence.cascade.result1895 to i8
  %9302 = call i8 @llvm.cttz.i8(i8 %9301, i1 false)
  %9303 = zext i8 %9302 to i32
  %9304 = select i1 %9300, i32 %9303, i32 0
  %9305 = load <8 x i64>, ptr %.slot56, align 64
  %9306 = select <8 x i1> %convergence.cascade.result1895, <8 x i64> zeroinitializer, <8 x i64> %9305
  store <8 x i64> %9306, ptr %.slot56, align 64
  %9307 = load <8 x float>, ptr %.slot47, align 32
  %9308 = select <8 x i1> %convergence.cascade.result1895, <8 x float> zeroinitializer, <8 x float> %9307
  store <8 x float> %9308, ptr %.slot47, align 32
  store <8 x i1> %convergence.cascade.result1895, ptr %current.mask, align 1
  %9309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1895)
  br i1 %9309, label %schedule.84, label %scheduler.loop

varying.divergent1897:                            ; preds = %schedule.84
  %9310 = load i32, ptr %current.token, align 4
  %9311 = icmp ne i32 %9310, 0
  %9312 = sub i32 %9310, 1
  %9313 = select i1 %9311, i32 %9312, i32 0
  %9314 = load i8, ptr %frame.active, align 1
  %9315 = trunc i32 %9313 to i8
  %9316 = shl i8 1, %9315
  %9317 = and i8 %9314, %9316
  %9318 = icmp ne i8 %9317, 0
  %9319 = load <8 x i32>, ptr %frame.static.id, align 32
  %9320 = extractelement <8 x i32> %9319, i32 %9313
  %9321 = icmp eq i32 %9320, 29
  %9322 = and i1 %9318, %9321
  %9323 = and i1 %9311, %9322
  %9324 = xor i1 %9323, true
  %9325 = and i1 true, %9324
  %9326 = xor i8 %9314, -1
  %9327 = icmp ne i8 %9326, 0
  %9328 = xor i1 %9327, true
  %9329 = and i1 %9325, %9328
  br i1 %9329, label %convergence.overflow.trap1899, label %convergence.overflow.resume1900

varying.coherent1898:                             ; preds = %schedule.84
  br i1 %2148, label %varying.coherent.true1903, label %varying.coherent.false1904

convergence.overflow.trap1899:                    ; preds = %varying.divergent1897
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1900:                  ; preds = %varying.divergent1897
  %9330 = call i8 @llvm.cttz.i8(i8 %9326, i1 false)
  %9331 = zext i8 %9330 to i32
  %9332 = select i1 %9327, i32 %9331, i32 0
  %9333 = trunc i32 %9332 to i8
  %9334 = shl i8 1, %9333
  %9335 = or i8 %9314, %9334
  %9336 = select i1 %9325, i8 %9335, i8 %9314
  store i8 %9336, ptr %frame.active, align 1
  %9337 = load <8 x i32>, ptr %frame.static.id, align 32
  %9338 = extractelement <8 x i32> %9337, i32 %9332
  %9339 = select i1 %9325, i32 29, i32 %9338
  %9340 = load <8 x i32>, ptr %frame.static.id, align 32
  %9341 = insertelement <8 x i32> %9340, i32 %9339, i32 %9332
  store <8 x i32> %9341, ptr %frame.static.id, align 32
  %9342 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9343 = extractelement <8 x i32> %9342, i32 %9332
  %9344 = select i1 %9325, i32 %9310, i32 %9343
  %9345 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9346 = insertelement <8 x i32> %9345, i32 %9344, i32 %9332
  store <8 x i32> %9346, ptr %frame.parent.token, align 32
  %9347 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9332
  %9348 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9332
  %9349 = load <8 x i1>, ptr %9347, align 1
  %9350 = load <8 x i1>, ptr %9348, align 1
  %9351 = select i1 %9325, <8 x i1> %2138, <8 x i1> %9349
  store <8 x i1> %9351, ptr %9347, align 1
  %9352 = select i1 %9325, <8 x i1> zeroinitializer, <8 x i1> %9350
  store <8 x i1> %9352, ptr %9348, align 1
  %9353 = add i32 %9332, 1
  %9354 = select i1 %9323, i32 %9310, i32 %9353
  %9355 = select i1 true, i32 %9354, i32 %9310
  store i32 %9355, ptr %current.token, align 4
  %9356 = load i32, ptr %current.token, align 4
  %9357 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2145)
  %9358 = load i32, ptr %ready.count, align 4
  %9359 = icmp uge i32 %9358, 8
  %9360 = and i1 %9357, %9359
  br i1 %9360, label %ready.overflow.trap1901, label %ready.overflow.resume1902

ready.overflow.trap1901:                          ; preds = %convergence.overflow.resume1900
  call void @llvm.trap()
  unreachable

ready.overflow.resume1902:                        ; preds = %convergence.overflow.resume1900
  %9361 = select i1 %9357, i32 %9358, i32 0
  %9362 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9361
  %9363 = load <8 x i1>, ptr %9362, align 1
  %9364 = select i1 %9357, <8 x i1> %2145, <8 x i1> %9363
  store <8 x i1> %9364, ptr %9362, align 1
  %9365 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9361
  %9366 = load i32, ptr %9365, align 4
  %9367 = select i1 %9357, i32 85, i32 %9366
  store i32 %9367, ptr %9365, align 4
  %9368 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9361
  %9369 = load i32, ptr %9368, align 4
  %9370 = select i1 %9357, i32 %9356, i32 %9369
  store i32 %9370, ptr %9368, align 4
  %9371 = add i32 %9358, 1
  %9372 = select i1 %9357, i32 %9371, i32 %9358
  store i32 %9372, ptr %ready.count, align 4
  %9373 = load <8 x i1>, ptr %runnable.mask, align 1
  %9374 = or <8 x i1> %9373, %2145
  store <8 x i1> %9374, ptr %runnable.mask, align 1
  store <8 x i1> %2147, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1903:                        ; preds = %varying.coherent1898
  store <8 x i1> %2138, ptr %current.mask, align 1
  %9375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2138)
  br i1 %9375, label %schedule.85, label %scheduler.loop

varying.coherent.false1904:                       ; preds = %varying.coherent1898
  store <8 x i1> %2138, ptr %current.mask, align 1
  %9376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2138)
  br i1 %9376, label %schedule.86, label %scheduler.loop

convergence.cascade1909:                          ; preds = %convergence.cascade1909, %schedule.86
  %convergence.cascade.flow1913 = phi <8 x i1> [ %2178, %schedule.86 ], [ %9419, %convergence.cascade1909 ]
  %convergence.cascade.depth1914 = phi i32 [ 0, %schedule.86 ], [ %9420, %convergence.cascade1909 ]
  %9377 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1913)
  %9378 = load i32, ptr %current.token, align 4
  %9379 = icmp ne i32 %9378, 0
  %9380 = and i1 %9377, %9379
  %9381 = sub i32 %9378, 1
  %9382 = select i1 %9380, i32 %9381, i32 0
  %9383 = load i8, ptr %frame.active, align 1
  %9384 = trunc i32 %9382 to i8
  %9385 = shl i8 1, %9384
  %9386 = and i8 %9383, %9385
  %9387 = icmp ne i8 %9386, 0
  %9388 = load <8 x i32>, ptr %frame.static.id, align 32
  %9389 = extractelement <8 x i32> %9388, i32 %9382
  %convergence.target.pointer1915 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %9389
  %convergence.dynamic.target1916 = load i32, ptr %convergence.target.pointer1915, align 4
  %9390 = icmp eq i32 %convergence.dynamic.target1916, 86
  %9391 = and i1 %9387, %9390
  %9392 = and i1 %9380, %9391
  %9393 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9382
  %9394 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9382
  %9395 = load <8 x i1>, ptr %9393, align 1
  %9396 = load <8 x i1>, ptr %9394, align 1
  %9397 = or <8 x i1> %9396, %convergence.cascade.flow1913
  %9398 = load <8 x i1>, ptr %live.mask, align 1
  %9399 = and <8 x i1> %9395, %9398
  %9400 = icmp eq <8 x i1> %9397, %9399
  %9401 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9400)
  %9402 = and i1 %9392, %9401
  %9403 = select i1 %9402, <8 x i1> zeroinitializer, <8 x i1> %9397
  %9404 = select i1 %9392, <8 x i1> %9403, <8 x i1> %9396
  store <8 x i1> %9404, ptr %9394, align 1
  %9405 = select i1 %9402, <8 x i1> zeroinitializer, <8 x i1> %9395
  store <8 x i1> %9405, ptr %9393, align 1
  %9406 = trunc i32 %9382 to i8
  %9407 = shl i8 1, %9406
  %9408 = xor i8 %9407, -1
  %9409 = and i8 %9383, %9408
  %9410 = select i1 %9402, i8 %9409, i8 %9383
  store i8 %9410, ptr %frame.active, align 1
  %.splatinsert1917 = insertelement <8 x i1> poison, i1 %9392, i64 0
  %.splat1918 = shufflevector <8 x i1> %.splatinsert1917, <8 x i1> poison, <8 x i32> zeroinitializer
  %9411 = and <8 x i1> %convergence.cascade.flow1913, %.splat1918
  %9412 = load <8 x i1>, ptr %runnable.mask, align 1
  %9413 = xor <8 x i1> %9411, splat (i1 true)
  %9414 = and <8 x i1> %9412, %9413
  store <8 x i1> %9414, ptr %runnable.mask, align 1
  %.splatinsert1919 = insertelement <8 x i1> poison, i1 %9402, i64 0
  %.splat1920 = shufflevector <8 x i1> %.splatinsert1919, <8 x i1> poison, <8 x i32> zeroinitializer
  %9415 = select <8 x i1> %.splat1920, <8 x i1> %9397, <8 x i1> zeroinitializer
  %9416 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9417 = extractelement <8 x i32> %9416, i32 %9382
  %9418 = select i1 %9402, i32 %9417, i32 %9378
  store i32 %9418, ptr %current.token, align 4
  %.splatinsert1921 = insertelement <8 x i1> poison, i1 %9392, i64 0
  %.splat1922 = shufflevector <8 x i1> %.splatinsert1921, <8 x i1> poison, <8 x i32> zeroinitializer
  %9419 = select <8 x i1> %.splat1922, <8 x i1> %9415, <8 x i1> %convergence.cascade.flow1913
  %9420 = add i32 %convergence.cascade.depth1914, 1
  %9421 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9419)
  %9422 = icmp ult i32 %9420, 8
  %9423 = and i1 %9421, %9422
  %9424 = and i1 %9392, %9423
  %convergence.parent.token1923 = load i32, ptr %current.token, align 4
  %convergence.parent.present1924 = icmp ne i32 %convergence.parent.token1923, 0
  %9425 = and i1 %9424, %convergence.parent.present1924
  br i1 %9425, label %convergence.cascade1909, label %convergence.cascade.exit1910

convergence.cascade.exit1910:                     ; preds = %convergence.cascade1909, %schedule.86
  %convergence.cascade.result1925 = phi <8 x i1> [ %2178, %schedule.86 ], [ %9419, %convergence.cascade1909 ]
  %9426 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1925)
  br i1 %9426, label %convergence.target.86.ready, label %scheduler.loop

convergence.target.86.ready:                      ; preds = %convergence.cascade.exit1910
  %9427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1925)
  %9428 = bitcast <8 x i1> %convergence.cascade.result1925 to i8
  %9429 = call i8 @llvm.cttz.i8(i8 %9428, i1 false)
  %9430 = zext i8 %9429 to i32
  %9431 = select i1 %9427, i32 %9430, i32 0
  %9432 = load <8 x i64>, ptr %.slot56, align 64
  %9433 = select <8 x i1> %convergence.cascade.result1925, <8 x i64> zeroinitializer, <8 x i64> %9432
  store <8 x i64> %9433, ptr %.slot56, align 64
  %9434 = load <8 x float>, ptr %.slot48, align 32
  %9435 = select <8 x i1> %convergence.cascade.result1925, <8 x float> zeroinitializer, <8 x float> %9434
  store <8 x float> %9435, ptr %.slot48, align 32
  store <8 x i1> %convergence.cascade.result1925, ptr %current.mask, align 1
  %9436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1925)
  br i1 %9436, label %schedule.87, label %scheduler.loop

varying.divergent1927:                            ; preds = %schedule.87
  %9437 = load i32, ptr %current.token, align 4
  %9438 = icmp ne i32 %9437, 0
  %9439 = sub i32 %9437, 1
  %9440 = select i1 %9438, i32 %9439, i32 0
  %9441 = load i8, ptr %frame.active, align 1
  %9442 = trunc i32 %9440 to i8
  %9443 = shl i8 1, %9442
  %9444 = and i8 %9441, %9443
  %9445 = icmp ne i8 %9444, 0
  %9446 = load <8 x i32>, ptr %frame.static.id, align 32
  %9447 = extractelement <8 x i32> %9446, i32 %9440
  %9448 = icmp eq i32 %9447, 30
  %9449 = and i1 %9445, %9448
  %9450 = and i1 %9438, %9449
  %9451 = xor i1 %9450, true
  %9452 = and i1 true, %9451
  %9453 = xor i8 %9441, -1
  %9454 = icmp ne i8 %9453, 0
  %9455 = xor i1 %9454, true
  %9456 = and i1 %9452, %9455
  br i1 %9456, label %convergence.overflow.trap1929, label %convergence.overflow.resume1930

varying.coherent1928:                             ; preds = %schedule.87
  br i1 %2189, label %varying.coherent.true1933, label %varying.coherent.false1934

convergence.overflow.trap1929:                    ; preds = %varying.divergent1927
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1930:                  ; preds = %varying.divergent1927
  %9457 = call i8 @llvm.cttz.i8(i8 %9453, i1 false)
  %9458 = zext i8 %9457 to i32
  %9459 = select i1 %9454, i32 %9458, i32 0
  %9460 = trunc i32 %9459 to i8
  %9461 = shl i8 1, %9460
  %9462 = or i8 %9441, %9461
  %9463 = select i1 %9452, i8 %9462, i8 %9441
  store i8 %9463, ptr %frame.active, align 1
  %9464 = load <8 x i32>, ptr %frame.static.id, align 32
  %9465 = extractelement <8 x i32> %9464, i32 %9459
  %9466 = select i1 %9452, i32 30, i32 %9465
  %9467 = load <8 x i32>, ptr %frame.static.id, align 32
  %9468 = insertelement <8 x i32> %9467, i32 %9466, i32 %9459
  store <8 x i32> %9468, ptr %frame.static.id, align 32
  %9469 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9470 = extractelement <8 x i32> %9469, i32 %9459
  %9471 = select i1 %9452, i32 %9437, i32 %9470
  %9472 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9473 = insertelement <8 x i32> %9472, i32 %9471, i32 %9459
  store <8 x i32> %9473, ptr %frame.parent.token, align 32
  %9474 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9459
  %9475 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9459
  %9476 = load <8 x i1>, ptr %9474, align 1
  %9477 = load <8 x i1>, ptr %9475, align 1
  %9478 = select i1 %9452, <8 x i1> %2179, <8 x i1> %9476
  store <8 x i1> %9478, ptr %9474, align 1
  %9479 = select i1 %9452, <8 x i1> zeroinitializer, <8 x i1> %9477
  store <8 x i1> %9479, ptr %9475, align 1
  %9480 = add i32 %9459, 1
  %9481 = select i1 %9450, i32 %9437, i32 %9480
  %9482 = select i1 true, i32 %9481, i32 %9437
  store i32 %9482, ptr %current.token, align 4
  %9483 = load i32, ptr %current.token, align 4
  %9484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2186)
  %9485 = load i32, ptr %ready.count, align 4
  %9486 = icmp uge i32 %9485, 8
  %9487 = and i1 %9484, %9486
  br i1 %9487, label %ready.overflow.trap1931, label %ready.overflow.resume1932

ready.overflow.trap1931:                          ; preds = %convergence.overflow.resume1930
  call void @llvm.trap()
  unreachable

ready.overflow.resume1932:                        ; preds = %convergence.overflow.resume1930
  %9488 = select i1 %9484, i32 %9485, i32 0
  %9489 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9488
  %9490 = load <8 x i1>, ptr %9489, align 1
  %9491 = select i1 %9484, <8 x i1> %2186, <8 x i1> %9490
  store <8 x i1> %9491, ptr %9489, align 1
  %9492 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9488
  %9493 = load i32, ptr %9492, align 4
  %9494 = select i1 %9484, i32 88, i32 %9493
  store i32 %9494, ptr %9492, align 4
  %9495 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9488
  %9496 = load i32, ptr %9495, align 4
  %9497 = select i1 %9484, i32 %9483, i32 %9496
  store i32 %9497, ptr %9495, align 4
  %9498 = add i32 %9485, 1
  %9499 = select i1 %9484, i32 %9498, i32 %9485
  store i32 %9499, ptr %ready.count, align 4
  %9500 = load <8 x i1>, ptr %runnable.mask, align 1
  %9501 = or <8 x i1> %9500, %2186
  store <8 x i1> %9501, ptr %runnable.mask, align 1
  store <8 x i1> %2188, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1933:                        ; preds = %varying.coherent1928
  store <8 x i1> %2179, ptr %current.mask, align 1
  %9502 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2179)
  br i1 %9502, label %schedule.88, label %scheduler.loop

varying.coherent.false1934:                       ; preds = %varying.coherent1928
  store <8 x i1> %2179, ptr %current.mask, align 1
  %9503 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2179)
  br i1 %9503, label %schedule.89, label %scheduler.loop

convergence.cascade1939:                          ; preds = %convergence.cascade1939, %schedule.89
  %convergence.cascade.flow1943 = phi <8 x i1> [ %2219, %schedule.89 ], [ %9546, %convergence.cascade1939 ]
  %convergence.cascade.depth1944 = phi i32 [ 0, %schedule.89 ], [ %9547, %convergence.cascade1939 ]
  %9504 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1943)
  %9505 = load i32, ptr %current.token, align 4
  %9506 = icmp ne i32 %9505, 0
  %9507 = and i1 %9504, %9506
  %9508 = sub i32 %9505, 1
  %9509 = select i1 %9507, i32 %9508, i32 0
  %9510 = load i8, ptr %frame.active, align 1
  %9511 = trunc i32 %9509 to i8
  %9512 = shl i8 1, %9511
  %9513 = and i8 %9510, %9512
  %9514 = icmp ne i8 %9513, 0
  %9515 = load <8 x i32>, ptr %frame.static.id, align 32
  %9516 = extractelement <8 x i32> %9515, i32 %9509
  %convergence.target.pointer1945 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %9516
  %convergence.dynamic.target1946 = load i32, ptr %convergence.target.pointer1945, align 4
  %9517 = icmp eq i32 %convergence.dynamic.target1946, 89
  %9518 = and i1 %9514, %9517
  %9519 = and i1 %9507, %9518
  %9520 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9509
  %9521 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9509
  %9522 = load <8 x i1>, ptr %9520, align 1
  %9523 = load <8 x i1>, ptr %9521, align 1
  %9524 = or <8 x i1> %9523, %convergence.cascade.flow1943
  %9525 = load <8 x i1>, ptr %live.mask, align 1
  %9526 = and <8 x i1> %9522, %9525
  %9527 = icmp eq <8 x i1> %9524, %9526
  %9528 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9527)
  %9529 = and i1 %9519, %9528
  %9530 = select i1 %9529, <8 x i1> zeroinitializer, <8 x i1> %9524
  %9531 = select i1 %9519, <8 x i1> %9530, <8 x i1> %9523
  store <8 x i1> %9531, ptr %9521, align 1
  %9532 = select i1 %9529, <8 x i1> zeroinitializer, <8 x i1> %9522
  store <8 x i1> %9532, ptr %9520, align 1
  %9533 = trunc i32 %9509 to i8
  %9534 = shl i8 1, %9533
  %9535 = xor i8 %9534, -1
  %9536 = and i8 %9510, %9535
  %9537 = select i1 %9529, i8 %9536, i8 %9510
  store i8 %9537, ptr %frame.active, align 1
  %.splatinsert1947 = insertelement <8 x i1> poison, i1 %9519, i64 0
  %.splat1948 = shufflevector <8 x i1> %.splatinsert1947, <8 x i1> poison, <8 x i32> zeroinitializer
  %9538 = and <8 x i1> %convergence.cascade.flow1943, %.splat1948
  %9539 = load <8 x i1>, ptr %runnable.mask, align 1
  %9540 = xor <8 x i1> %9538, splat (i1 true)
  %9541 = and <8 x i1> %9539, %9540
  store <8 x i1> %9541, ptr %runnable.mask, align 1
  %.splatinsert1949 = insertelement <8 x i1> poison, i1 %9529, i64 0
  %.splat1950 = shufflevector <8 x i1> %.splatinsert1949, <8 x i1> poison, <8 x i32> zeroinitializer
  %9542 = select <8 x i1> %.splat1950, <8 x i1> %9524, <8 x i1> zeroinitializer
  %9543 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9544 = extractelement <8 x i32> %9543, i32 %9509
  %9545 = select i1 %9529, i32 %9544, i32 %9505
  store i32 %9545, ptr %current.token, align 4
  %.splatinsert1951 = insertelement <8 x i1> poison, i1 %9519, i64 0
  %.splat1952 = shufflevector <8 x i1> %.splatinsert1951, <8 x i1> poison, <8 x i32> zeroinitializer
  %9546 = select <8 x i1> %.splat1952, <8 x i1> %9542, <8 x i1> %convergence.cascade.flow1943
  %9547 = add i32 %convergence.cascade.depth1944, 1
  %9548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9546)
  %9549 = icmp ult i32 %9547, 8
  %9550 = and i1 %9548, %9549
  %9551 = and i1 %9519, %9550
  %convergence.parent.token1953 = load i32, ptr %current.token, align 4
  %convergence.parent.present1954 = icmp ne i32 %convergence.parent.token1953, 0
  %9552 = and i1 %9551, %convergence.parent.present1954
  br i1 %9552, label %convergence.cascade1939, label %convergence.cascade.exit1940

convergence.cascade.exit1940:                     ; preds = %convergence.cascade1939, %schedule.89
  %convergence.cascade.result1955 = phi <8 x i1> [ %2219, %schedule.89 ], [ %9546, %convergence.cascade1939 ]
  %9553 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1955)
  br i1 %9553, label %convergence.target.89.ready, label %scheduler.loop

convergence.target.89.ready:                      ; preds = %convergence.cascade.exit1940
  %9554 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1955)
  %9555 = bitcast <8 x i1> %convergence.cascade.result1955 to i8
  %9556 = call i8 @llvm.cttz.i8(i8 %9555, i1 false)
  %9557 = zext i8 %9556 to i32
  %9558 = select i1 %9554, i32 %9557, i32 0
  %9559 = load <8 x i64>, ptr %.slot56, align 64
  %9560 = select <8 x i1> %convergence.cascade.result1955, <8 x i64> zeroinitializer, <8 x i64> %9559
  store <8 x i64> %9560, ptr %.slot56, align 64
  %9561 = load <8 x float>, ptr %.slot49, align 32
  %9562 = select <8 x i1> %convergence.cascade.result1955, <8 x float> zeroinitializer, <8 x float> %9561
  store <8 x float> %9562, ptr %.slot49, align 32
  store <8 x i1> %convergence.cascade.result1955, ptr %current.mask, align 1
  %9563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1955)
  br i1 %9563, label %schedule.90, label %scheduler.loop

varying.divergent1957:                            ; preds = %schedule.90
  %9564 = load i32, ptr %current.token, align 4
  %9565 = icmp ne i32 %9564, 0
  %9566 = sub i32 %9564, 1
  %9567 = select i1 %9565, i32 %9566, i32 0
  %9568 = load i8, ptr %frame.active, align 1
  %9569 = trunc i32 %9567 to i8
  %9570 = shl i8 1, %9569
  %9571 = and i8 %9568, %9570
  %9572 = icmp ne i8 %9571, 0
  %9573 = load <8 x i32>, ptr %frame.static.id, align 32
  %9574 = extractelement <8 x i32> %9573, i32 %9567
  %9575 = icmp eq i32 %9574, 31
  %9576 = and i1 %9572, %9575
  %9577 = and i1 %9565, %9576
  %9578 = xor i1 %9577, true
  %9579 = and i1 true, %9578
  %9580 = xor i8 %9568, -1
  %9581 = icmp ne i8 %9580, 0
  %9582 = xor i1 %9581, true
  %9583 = and i1 %9579, %9582
  br i1 %9583, label %convergence.overflow.trap1959, label %convergence.overflow.resume1960

varying.coherent1958:                             ; preds = %schedule.90
  br i1 %2230, label %varying.coherent.true1963, label %varying.coherent.false1964

convergence.overflow.trap1959:                    ; preds = %varying.divergent1957
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1960:                  ; preds = %varying.divergent1957
  %9584 = call i8 @llvm.cttz.i8(i8 %9580, i1 false)
  %9585 = zext i8 %9584 to i32
  %9586 = select i1 %9581, i32 %9585, i32 0
  %9587 = trunc i32 %9586 to i8
  %9588 = shl i8 1, %9587
  %9589 = or i8 %9568, %9588
  %9590 = select i1 %9579, i8 %9589, i8 %9568
  store i8 %9590, ptr %frame.active, align 1
  %9591 = load <8 x i32>, ptr %frame.static.id, align 32
  %9592 = extractelement <8 x i32> %9591, i32 %9586
  %9593 = select i1 %9579, i32 31, i32 %9592
  %9594 = load <8 x i32>, ptr %frame.static.id, align 32
  %9595 = insertelement <8 x i32> %9594, i32 %9593, i32 %9586
  store <8 x i32> %9595, ptr %frame.static.id, align 32
  %9596 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9597 = extractelement <8 x i32> %9596, i32 %9586
  %9598 = select i1 %9579, i32 %9564, i32 %9597
  %9599 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9600 = insertelement <8 x i32> %9599, i32 %9598, i32 %9586
  store <8 x i32> %9600, ptr %frame.parent.token, align 32
  %9601 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9586
  %9602 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9586
  %9603 = load <8 x i1>, ptr %9601, align 1
  %9604 = load <8 x i1>, ptr %9602, align 1
  %9605 = select i1 %9579, <8 x i1> %2220, <8 x i1> %9603
  store <8 x i1> %9605, ptr %9601, align 1
  %9606 = select i1 %9579, <8 x i1> zeroinitializer, <8 x i1> %9604
  store <8 x i1> %9606, ptr %9602, align 1
  %9607 = add i32 %9586, 1
  %9608 = select i1 %9577, i32 %9564, i32 %9607
  %9609 = select i1 true, i32 %9608, i32 %9564
  store i32 %9609, ptr %current.token, align 4
  %9610 = load i32, ptr %current.token, align 4
  %9611 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2227)
  %9612 = load i32, ptr %ready.count, align 4
  %9613 = icmp uge i32 %9612, 8
  %9614 = and i1 %9611, %9613
  br i1 %9614, label %ready.overflow.trap1961, label %ready.overflow.resume1962

ready.overflow.trap1961:                          ; preds = %convergence.overflow.resume1960
  call void @llvm.trap()
  unreachable

ready.overflow.resume1962:                        ; preds = %convergence.overflow.resume1960
  %9615 = select i1 %9611, i32 %9612, i32 0
  %9616 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9615
  %9617 = load <8 x i1>, ptr %9616, align 1
  %9618 = select i1 %9611, <8 x i1> %2227, <8 x i1> %9617
  store <8 x i1> %9618, ptr %9616, align 1
  %9619 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9615
  %9620 = load i32, ptr %9619, align 4
  %9621 = select i1 %9611, i32 91, i32 %9620
  store i32 %9621, ptr %9619, align 4
  %9622 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9615
  %9623 = load i32, ptr %9622, align 4
  %9624 = select i1 %9611, i32 %9610, i32 %9623
  store i32 %9624, ptr %9622, align 4
  %9625 = add i32 %9612, 1
  %9626 = select i1 %9611, i32 %9625, i32 %9612
  store i32 %9626, ptr %ready.count, align 4
  %9627 = load <8 x i1>, ptr %runnable.mask, align 1
  %9628 = or <8 x i1> %9627, %2227
  store <8 x i1> %9628, ptr %runnable.mask, align 1
  store <8 x i1> %2229, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1963:                        ; preds = %varying.coherent1958
  store <8 x i1> %2220, ptr %current.mask, align 1
  %9629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2220)
  br i1 %9629, label %schedule.91, label %scheduler.loop

varying.coherent.false1964:                       ; preds = %varying.coherent1958
  store <8 x i1> %2220, ptr %current.mask, align 1
  %9630 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2220)
  br i1 %9630, label %schedule.92, label %scheduler.loop

convergence.cascade1969:                          ; preds = %convergence.cascade1969, %schedule.92
  %convergence.cascade.flow1973 = phi <8 x i1> [ %2260, %schedule.92 ], [ %9673, %convergence.cascade1969 ]
  %convergence.cascade.depth1974 = phi i32 [ 0, %schedule.92 ], [ %9674, %convergence.cascade1969 ]
  %9631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1973)
  %9632 = load i32, ptr %current.token, align 4
  %9633 = icmp ne i32 %9632, 0
  %9634 = and i1 %9631, %9633
  %9635 = sub i32 %9632, 1
  %9636 = select i1 %9634, i32 %9635, i32 0
  %9637 = load i8, ptr %frame.active, align 1
  %9638 = trunc i32 %9636 to i8
  %9639 = shl i8 1, %9638
  %9640 = and i8 %9637, %9639
  %9641 = icmp ne i8 %9640, 0
  %9642 = load <8 x i32>, ptr %frame.static.id, align 32
  %9643 = extractelement <8 x i32> %9642, i32 %9636
  %convergence.target.pointer1975 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %9643
  %convergence.dynamic.target1976 = load i32, ptr %convergence.target.pointer1975, align 4
  %9644 = icmp eq i32 %convergence.dynamic.target1976, 92
  %9645 = and i1 %9641, %9644
  %9646 = and i1 %9634, %9645
  %9647 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9636
  %9648 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9636
  %9649 = load <8 x i1>, ptr %9647, align 1
  %9650 = load <8 x i1>, ptr %9648, align 1
  %9651 = or <8 x i1> %9650, %convergence.cascade.flow1973
  %9652 = load <8 x i1>, ptr %live.mask, align 1
  %9653 = and <8 x i1> %9649, %9652
  %9654 = icmp eq <8 x i1> %9651, %9653
  %9655 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9654)
  %9656 = and i1 %9646, %9655
  %9657 = select i1 %9656, <8 x i1> zeroinitializer, <8 x i1> %9651
  %9658 = select i1 %9646, <8 x i1> %9657, <8 x i1> %9650
  store <8 x i1> %9658, ptr %9648, align 1
  %9659 = select i1 %9656, <8 x i1> zeroinitializer, <8 x i1> %9649
  store <8 x i1> %9659, ptr %9647, align 1
  %9660 = trunc i32 %9636 to i8
  %9661 = shl i8 1, %9660
  %9662 = xor i8 %9661, -1
  %9663 = and i8 %9637, %9662
  %9664 = select i1 %9656, i8 %9663, i8 %9637
  store i8 %9664, ptr %frame.active, align 1
  %.splatinsert1977 = insertelement <8 x i1> poison, i1 %9646, i64 0
  %.splat1978 = shufflevector <8 x i1> %.splatinsert1977, <8 x i1> poison, <8 x i32> zeroinitializer
  %9665 = and <8 x i1> %convergence.cascade.flow1973, %.splat1978
  %9666 = load <8 x i1>, ptr %runnable.mask, align 1
  %9667 = xor <8 x i1> %9665, splat (i1 true)
  %9668 = and <8 x i1> %9666, %9667
  store <8 x i1> %9668, ptr %runnable.mask, align 1
  %.splatinsert1979 = insertelement <8 x i1> poison, i1 %9656, i64 0
  %.splat1980 = shufflevector <8 x i1> %.splatinsert1979, <8 x i1> poison, <8 x i32> zeroinitializer
  %9669 = select <8 x i1> %.splat1980, <8 x i1> %9651, <8 x i1> zeroinitializer
  %9670 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9671 = extractelement <8 x i32> %9670, i32 %9636
  %9672 = select i1 %9656, i32 %9671, i32 %9632
  store i32 %9672, ptr %current.token, align 4
  %.splatinsert1981 = insertelement <8 x i1> poison, i1 %9646, i64 0
  %.splat1982 = shufflevector <8 x i1> %.splatinsert1981, <8 x i1> poison, <8 x i32> zeroinitializer
  %9673 = select <8 x i1> %.splat1982, <8 x i1> %9669, <8 x i1> %convergence.cascade.flow1973
  %9674 = add i32 %convergence.cascade.depth1974, 1
  %9675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9673)
  %9676 = icmp ult i32 %9674, 8
  %9677 = and i1 %9675, %9676
  %9678 = and i1 %9646, %9677
  %convergence.parent.token1983 = load i32, ptr %current.token, align 4
  %convergence.parent.present1984 = icmp ne i32 %convergence.parent.token1983, 0
  %9679 = and i1 %9678, %convergence.parent.present1984
  br i1 %9679, label %convergence.cascade1969, label %convergence.cascade.exit1970

convergence.cascade.exit1970:                     ; preds = %convergence.cascade1969, %schedule.92
  %convergence.cascade.result1985 = phi <8 x i1> [ %2260, %schedule.92 ], [ %9673, %convergence.cascade1969 ]
  %9680 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1985)
  br i1 %9680, label %convergence.target.92.ready, label %scheduler.loop

convergence.target.92.ready:                      ; preds = %convergence.cascade.exit1970
  %9681 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1985)
  %9682 = bitcast <8 x i1> %convergence.cascade.result1985 to i8
  %9683 = call i8 @llvm.cttz.i8(i8 %9682, i1 false)
  %9684 = zext i8 %9683 to i32
  %9685 = select i1 %9681, i32 %9684, i32 0
  %.spill.load1986 = load <8 x float>, ptr %.spill286, align 32
  %.state1987 = load <8 x float>, ptr %.slot41, align 32
  %9686 = fadd <8 x float> %.spill.load1986, %.state1987
  %9687 = load <8 x float>, ptr %.spill298, align 32
  %9688 = select <8 x i1> %convergence.cascade.result1985, <8 x float> %9686, <8 x float> %9687
  store <8 x float> %9688, ptr %.spill298, align 32
  %.spill.load1988 = load <8 x float>, ptr %.spill287, align 32
  %.state1989 = load <8 x float>, ptr %.slot47, align 32
  %9689 = fadd <8 x float> %.spill.load1988, %.state1989
  %9690 = load <8 x float>, ptr %.spill299, align 32
  %9691 = select <8 x i1> %convergence.cascade.result1985, <8 x float> %9689, <8 x float> %9690
  store <8 x float> %9691, ptr %.spill299, align 32
  %.spill.load1990 = load <8 x float>, ptr %.spill288, align 32
  %.state1991 = load <8 x float>, ptr %.slot48, align 32
  %9692 = fadd <8 x float> %.spill.load1990, %.state1991
  %9693 = load <8 x float>, ptr %.spill300, align 32
  %9694 = select <8 x i1> %convergence.cascade.result1985, <8 x float> %9692, <8 x float> %9693
  store <8 x float> %9694, ptr %.spill300, align 32
  %.spill.load1992 = load <8 x float>, ptr %.spill289, align 32
  %.state1993 = load <8 x float>, ptr %.slot49, align 32
  %9695 = fadd <8 x float> %.spill.load1992, %.state1993
  %9696 = load <8 x float>, ptr %.spill301, align 32
  %9697 = select <8 x i1> %convergence.cascade.result1985, <8 x float> %9695, <8 x float> %9696
  store <8 x float> %9697, ptr %.spill301, align 32
  %9698 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill302, align 64
  %9699 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %9700 = extractvalue { <8 x ptr>, <8 x i64> } %9698, 0
  %9701 = select <8 x i1> %convergence.cascade.result1985, <8 x ptr> %9699, <8 x ptr> %9700
  %9702 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %9703 = extractvalue { <8 x ptr>, <8 x i64> } %9698, 1
  %9704 = select <8 x i1> %convergence.cascade.result1985, <8 x i64> %9702, <8 x i64> %9703
  %9705 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9701, 0
  %9706 = insertvalue { <8 x ptr>, <8 x i64> } %9705, <8 x i64> %9704, 1
  store { <8 x ptr>, <8 x i64> } %9706, ptr %tile_snapshot.spill302, align 64
  %9707 = load <8 x i64>, ptr %.slot56, align 64
  %9708 = select <8 x i1> %convergence.cascade.result1985, <8 x i64> zeroinitializer, <8 x i64> %9707
  store <8 x i64> %9708, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result1985, ptr %current.mask, align 1
  %9709 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1985)
  br i1 %9709, label %schedule.93, label %scheduler.loop

varying.divergent1995:                            ; preds = %schedule.93
  %9710 = load i32, ptr %current.token, align 4
  %9711 = icmp ne i32 %9710, 0
  %9712 = sub i32 %9710, 1
  %9713 = select i1 %9711, i32 %9712, i32 0
  %9714 = load i8, ptr %frame.active, align 1
  %9715 = trunc i32 %9713 to i8
  %9716 = shl i8 1, %9715
  %9717 = and i8 %9714, %9716
  %9718 = icmp ne i8 %9717, 0
  %9719 = load <8 x i32>, ptr %frame.static.id, align 32
  %9720 = extractelement <8 x i32> %9719, i32 %9713
  %9721 = icmp eq i32 %9720, 32
  %9722 = and i1 %9718, %9721
  %9723 = and i1 %9711, %9722
  %9724 = xor i1 %9723, true
  %9725 = and i1 true, %9724
  %9726 = xor i8 %9714, -1
  %9727 = icmp ne i8 %9726, 0
  %9728 = xor i1 %9727, true
  %9729 = and i1 %9725, %9728
  br i1 %9729, label %convergence.overflow.trap1997, label %convergence.overflow.resume1998

varying.coherent1996:                             ; preds = %schedule.93
  br i1 %2271, label %varying.coherent.true2001, label %varying.coherent.false2002

convergence.overflow.trap1997:                    ; preds = %varying.divergent1995
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1998:                  ; preds = %varying.divergent1995
  %9730 = call i8 @llvm.cttz.i8(i8 %9726, i1 false)
  %9731 = zext i8 %9730 to i32
  %9732 = select i1 %9727, i32 %9731, i32 0
  %9733 = trunc i32 %9732 to i8
  %9734 = shl i8 1, %9733
  %9735 = or i8 %9714, %9734
  %9736 = select i1 %9725, i8 %9735, i8 %9714
  store i8 %9736, ptr %frame.active, align 1
  %9737 = load <8 x i32>, ptr %frame.static.id, align 32
  %9738 = extractelement <8 x i32> %9737, i32 %9732
  %9739 = select i1 %9725, i32 32, i32 %9738
  %9740 = load <8 x i32>, ptr %frame.static.id, align 32
  %9741 = insertelement <8 x i32> %9740, i32 %9739, i32 %9732
  store <8 x i32> %9741, ptr %frame.static.id, align 32
  %9742 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9743 = extractelement <8 x i32> %9742, i32 %9732
  %9744 = select i1 %9725, i32 %9710, i32 %9743
  %9745 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9746 = insertelement <8 x i32> %9745, i32 %9744, i32 %9732
  store <8 x i32> %9746, ptr %frame.parent.token, align 32
  %9747 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9732
  %9748 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9732
  %9749 = load <8 x i1>, ptr %9747, align 1
  %9750 = load <8 x i1>, ptr %9748, align 1
  %9751 = select i1 %9725, <8 x i1> %2261, <8 x i1> %9749
  store <8 x i1> %9751, ptr %9747, align 1
  %9752 = select i1 %9725, <8 x i1> zeroinitializer, <8 x i1> %9750
  store <8 x i1> %9752, ptr %9748, align 1
  %9753 = add i32 %9732, 1
  %9754 = select i1 %9723, i32 %9710, i32 %9753
  %9755 = select i1 true, i32 %9754, i32 %9710
  store i32 %9755, ptr %current.token, align 4
  %9756 = load i32, ptr %current.token, align 4
  %9757 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2268)
  %9758 = load i32, ptr %ready.count, align 4
  %9759 = icmp uge i32 %9758, 8
  %9760 = and i1 %9757, %9759
  br i1 %9760, label %ready.overflow.trap1999, label %ready.overflow.resume2000

ready.overflow.trap1999:                          ; preds = %convergence.overflow.resume1998
  call void @llvm.trap()
  unreachable

ready.overflow.resume2000:                        ; preds = %convergence.overflow.resume1998
  %9761 = select i1 %9757, i32 %9758, i32 0
  %9762 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9761
  %9763 = load <8 x i1>, ptr %9762, align 1
  %9764 = select i1 %9757, <8 x i1> %2268, <8 x i1> %9763
  store <8 x i1> %9764, ptr %9762, align 1
  %9765 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9761
  %9766 = load i32, ptr %9765, align 4
  %9767 = select i1 %9757, i32 94, i32 %9766
  store i32 %9767, ptr %9765, align 4
  %9768 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9761
  %9769 = load i32, ptr %9768, align 4
  %9770 = select i1 %9757, i32 %9756, i32 %9769
  store i32 %9770, ptr %9768, align 4
  %9771 = add i32 %9758, 1
  %9772 = select i1 %9757, i32 %9771, i32 %9758
  store i32 %9772, ptr %ready.count, align 4
  %9773 = load <8 x i1>, ptr %runnable.mask, align 1
  %9774 = or <8 x i1> %9773, %2268
  store <8 x i1> %9774, ptr %runnable.mask, align 1
  store <8 x i1> %2270, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2001:                        ; preds = %varying.coherent1996
  store <8 x i1> %2261, ptr %current.mask, align 1
  %9775 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2261)
  br i1 %9775, label %schedule.94, label %scheduler.loop

varying.coherent.false2002:                       ; preds = %varying.coherent1996
  store <8 x i1> %2261, ptr %current.mask, align 1
  %9776 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2261)
  br i1 %9776, label %schedule.101, label %scheduler.loop

varying.divergent2004:                            ; preds = %schedule.95
  %9777 = load i32, ptr %current.token, align 4
  %9778 = icmp ne i32 %9777, 0
  %9779 = sub i32 %9777, 1
  %9780 = select i1 %9778, i32 %9779, i32 0
  %9781 = load i8, ptr %frame.active, align 1
  %9782 = trunc i32 %9780 to i8
  %9783 = shl i8 1, %9782
  %9784 = and i8 %9781, %9783
  %9785 = icmp ne i8 %9784, 0
  %9786 = load <8 x i32>, ptr %frame.static.id, align 32
  %9787 = extractelement <8 x i32> %9786, i32 %9780
  %9788 = icmp eq i32 %9787, 33
  %9789 = and i1 %9785, %9788
  %9790 = and i1 %9778, %9789
  %9791 = xor i1 %9790, true
  %9792 = and i1 true, %9791
  %9793 = xor i8 %9781, -1
  %9794 = icmp ne i8 %9793, 0
  %9795 = xor i1 %9794, true
  %9796 = and i1 %9792, %9795
  br i1 %9796, label %convergence.overflow.trap2006, label %convergence.overflow.resume2007

varying.coherent2005:                             ; preds = %schedule.95
  br i1 %2293, label %varying.coherent.true2010, label %varying.coherent.false2011

convergence.overflow.trap2006:                    ; preds = %varying.divergent2004
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2007:                  ; preds = %varying.divergent2004
  %9797 = call i8 @llvm.cttz.i8(i8 %9793, i1 false)
  %9798 = zext i8 %9797 to i32
  %9799 = select i1 %9794, i32 %9798, i32 0
  %9800 = trunc i32 %9799 to i8
  %9801 = shl i8 1, %9800
  %9802 = or i8 %9781, %9801
  %9803 = select i1 %9792, i8 %9802, i8 %9781
  store i8 %9803, ptr %frame.active, align 1
  %9804 = load <8 x i32>, ptr %frame.static.id, align 32
  %9805 = extractelement <8 x i32> %9804, i32 %9799
  %9806 = select i1 %9792, i32 33, i32 %9805
  %9807 = load <8 x i32>, ptr %frame.static.id, align 32
  %9808 = insertelement <8 x i32> %9807, i32 %9806, i32 %9799
  store <8 x i32> %9808, ptr %frame.static.id, align 32
  %9809 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9810 = extractelement <8 x i32> %9809, i32 %9799
  %9811 = select i1 %9792, i32 %9777, i32 %9810
  %9812 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9813 = insertelement <8 x i32> %9812, i32 %9811, i32 %9799
  store <8 x i32> %9813, ptr %frame.parent.token, align 32
  %9814 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9799
  %9815 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9799
  %9816 = load <8 x i1>, ptr %9814, align 1
  %9817 = load <8 x i1>, ptr %9815, align 1
  %9818 = select i1 %9792, <8 x i1> %2283, <8 x i1> %9816
  store <8 x i1> %9818, ptr %9814, align 1
  %9819 = select i1 %9792, <8 x i1> zeroinitializer, <8 x i1> %9817
  store <8 x i1> %9819, ptr %9815, align 1
  %9820 = add i32 %9799, 1
  %9821 = select i1 %9790, i32 %9777, i32 %9820
  %9822 = select i1 true, i32 %9821, i32 %9777
  store i32 %9822, ptr %current.token, align 4
  %9823 = load i32, ptr %current.token, align 4
  %9824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2290)
  %9825 = load i32, ptr %ready.count, align 4
  %9826 = icmp uge i32 %9825, 8
  %9827 = and i1 %9824, %9826
  br i1 %9827, label %ready.overflow.trap2008, label %ready.overflow.resume2009

ready.overflow.trap2008:                          ; preds = %convergence.overflow.resume2007
  call void @llvm.trap()
  unreachable

ready.overflow.resume2009:                        ; preds = %convergence.overflow.resume2007
  %9828 = select i1 %9824, i32 %9825, i32 0
  %9829 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9828
  %9830 = load <8 x i1>, ptr %9829, align 1
  %9831 = select i1 %9824, <8 x i1> %2290, <8 x i1> %9830
  store <8 x i1> %9831, ptr %9829, align 1
  %9832 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9828
  %9833 = load i32, ptr %9832, align 4
  %9834 = select i1 %9824, i32 96, i32 %9833
  store i32 %9834, ptr %9832, align 4
  %9835 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9828
  %9836 = load i32, ptr %9835, align 4
  %9837 = select i1 %9824, i32 %9823, i32 %9836
  store i32 %9837, ptr %9835, align 4
  %9838 = add i32 %9825, 1
  %9839 = select i1 %9824, i32 %9838, i32 %9825
  store i32 %9839, ptr %ready.count, align 4
  %9840 = load <8 x i1>, ptr %runnable.mask, align 1
  %9841 = or <8 x i1> %9840, %2290
  store <8 x i1> %9841, ptr %runnable.mask, align 1
  store <8 x i1> %2292, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2010:                        ; preds = %varying.coherent2005
  store <8 x i1> %2283, ptr %current.mask, align 1
  %9842 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2283)
  br i1 %9842, label %schedule.96, label %scheduler.loop

varying.coherent.false2011:                       ; preds = %varying.coherent2005
  store <8 x i1> %2283, ptr %current.mask, align 1
  %9843 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2283)
  br i1 %9843, label %schedule.100, label %scheduler.loop

varying.divergent2023:                            ; preds = %schedule.97
  %9844 = load i32, ptr %current.token, align 4
  %9845 = icmp ne i32 %9844, 0
  %9846 = sub i32 %9844, 1
  %9847 = select i1 %9845, i32 %9846, i32 0
  %9848 = load i8, ptr %frame.active, align 1
  %9849 = trunc i32 %9847 to i8
  %9850 = shl i8 1, %9849
  %9851 = and i8 %9848, %9850
  %9852 = icmp ne i8 %9851, 0
  %9853 = load <8 x i32>, ptr %frame.static.id, align 32
  %9854 = extractelement <8 x i32> %9853, i32 %9847
  %9855 = icmp eq i32 %9854, 34
  %9856 = and i1 %9852, %9855
  %9857 = and i1 %9845, %9856
  %9858 = xor i1 %9857, true
  %9859 = and i1 true, %9858
  %9860 = xor i8 %9848, -1
  %9861 = icmp ne i8 %9860, 0
  %9862 = xor i1 %9861, true
  %9863 = and i1 %9859, %9862
  br i1 %9863, label %convergence.overflow.trap2025, label %convergence.overflow.resume2026

varying.coherent2024:                             ; preds = %schedule.97
  br i1 %2468, label %varying.coherent.true2029, label %varying.coherent.false2030

convergence.overflow.trap2025:                    ; preds = %varying.divergent2023
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2026:                  ; preds = %varying.divergent2023
  %9864 = call i8 @llvm.cttz.i8(i8 %9860, i1 false)
  %9865 = zext i8 %9864 to i32
  %9866 = select i1 %9861, i32 %9865, i32 0
  %9867 = trunc i32 %9866 to i8
  %9868 = shl i8 1, %9867
  %9869 = or i8 %9848, %9868
  %9870 = select i1 %9859, i8 %9869, i8 %9848
  store i8 %9870, ptr %frame.active, align 1
  %9871 = load <8 x i32>, ptr %frame.static.id, align 32
  %9872 = extractelement <8 x i32> %9871, i32 %9866
  %9873 = select i1 %9859, i32 34, i32 %9872
  %9874 = load <8 x i32>, ptr %frame.static.id, align 32
  %9875 = insertelement <8 x i32> %9874, i32 %9873, i32 %9866
  store <8 x i32> %9875, ptr %frame.static.id, align 32
  %9876 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9877 = extractelement <8 x i32> %9876, i32 %9866
  %9878 = select i1 %9859, i32 %9844, i32 %9877
  %9879 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9880 = insertelement <8 x i32> %9879, i32 %9878, i32 %9866
  store <8 x i32> %9880, ptr %frame.parent.token, align 32
  %9881 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9866
  %9882 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9866
  %9883 = load <8 x i1>, ptr %9881, align 1
  %9884 = load <8 x i1>, ptr %9882, align 1
  %9885 = select i1 %9859, <8 x i1> %2458, <8 x i1> %9883
  store <8 x i1> %9885, ptr %9881, align 1
  %9886 = select i1 %9859, <8 x i1> zeroinitializer, <8 x i1> %9884
  store <8 x i1> %9886, ptr %9882, align 1
  %9887 = add i32 %9866, 1
  %9888 = select i1 %9857, i32 %9844, i32 %9887
  %9889 = select i1 true, i32 %9888, i32 %9844
  store i32 %9889, ptr %current.token, align 4
  %9890 = load i32, ptr %current.token, align 4
  %9891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2465)
  %9892 = load i32, ptr %ready.count, align 4
  %9893 = icmp uge i32 %9892, 8
  %9894 = and i1 %9891, %9893
  br i1 %9894, label %ready.overflow.trap2027, label %ready.overflow.resume2028

ready.overflow.trap2027:                          ; preds = %convergence.overflow.resume2026
  call void @llvm.trap()
  unreachable

ready.overflow.resume2028:                        ; preds = %convergence.overflow.resume2026
  %9895 = select i1 %9891, i32 %9892, i32 0
  %9896 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9895
  %9897 = load <8 x i1>, ptr %9896, align 1
  %9898 = select i1 %9891, <8 x i1> %2465, <8 x i1> %9897
  store <8 x i1> %9898, ptr %9896, align 1
  %9899 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9895
  %9900 = load i32, ptr %9899, align 4
  %9901 = select i1 %9891, i32 98, i32 %9900
  store i32 %9901, ptr %9899, align 4
  %9902 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9895
  %9903 = load i32, ptr %9902, align 4
  %9904 = select i1 %9891, i32 %9890, i32 %9903
  store i32 %9904, ptr %9902, align 4
  %9905 = add i32 %9892, 1
  %9906 = select i1 %9891, i32 %9905, i32 %9892
  store i32 %9906, ptr %ready.count, align 4
  %9907 = load <8 x i1>, ptr %runnable.mask, align 1
  %9908 = or <8 x i1> %9907, %2465
  store <8 x i1> %9908, ptr %runnable.mask, align 1
  store <8 x i1> %2467, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2029:                        ; preds = %varying.coherent2024
  store <8 x i1> %2458, ptr %current.mask, align 1
  %9909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2458)
  br i1 %9909, label %schedule.98, label %scheduler.loop

varying.coherent.false2030:                       ; preds = %varying.coherent2024
  store <8 x i1> %2458, ptr %current.mask, align 1
  %9910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2458)
  br i1 %9910, label %schedule.99, label %scheduler.loop

convergence.cascade2048:                          ; preds = %convergence.cascade2048, %schedule.99
  %convergence.cascade.flow2052 = phi <8 x i1> [ %2555, %schedule.99 ], [ %9953, %convergence.cascade2048 ]
  %convergence.cascade.depth2053 = phi i32 [ 0, %schedule.99 ], [ %9954, %convergence.cascade2048 ]
  %9911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2052)
  %9912 = load i32, ptr %current.token, align 4
  %9913 = icmp ne i32 %9912, 0
  %9914 = and i1 %9911, %9913
  %9915 = sub i32 %9912, 1
  %9916 = select i1 %9914, i32 %9915, i32 0
  %9917 = load i8, ptr %frame.active, align 1
  %9918 = trunc i32 %9916 to i8
  %9919 = shl i8 1, %9918
  %9920 = and i8 %9917, %9919
  %9921 = icmp ne i8 %9920, 0
  %9922 = load <8 x i32>, ptr %frame.static.id, align 32
  %9923 = extractelement <8 x i32> %9922, i32 %9916
  %convergence.target.pointer2054 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %9923
  %convergence.dynamic.target2055 = load i32, ptr %convergence.target.pointer2054, align 4
  %9924 = icmp eq i32 %convergence.dynamic.target2055, 99
  %9925 = and i1 %9921, %9924
  %9926 = and i1 %9914, %9925
  %9927 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9916
  %9928 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9916
  %9929 = load <8 x i1>, ptr %9927, align 1
  %9930 = load <8 x i1>, ptr %9928, align 1
  %9931 = or <8 x i1> %9930, %convergence.cascade.flow2052
  %9932 = load <8 x i1>, ptr %live.mask, align 1
  %9933 = and <8 x i1> %9929, %9932
  %9934 = icmp eq <8 x i1> %9931, %9933
  %9935 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9934)
  %9936 = and i1 %9926, %9935
  %9937 = select i1 %9936, <8 x i1> zeroinitializer, <8 x i1> %9931
  %9938 = select i1 %9926, <8 x i1> %9937, <8 x i1> %9930
  store <8 x i1> %9938, ptr %9928, align 1
  %9939 = select i1 %9936, <8 x i1> zeroinitializer, <8 x i1> %9929
  store <8 x i1> %9939, ptr %9927, align 1
  %9940 = trunc i32 %9916 to i8
  %9941 = shl i8 1, %9940
  %9942 = xor i8 %9941, -1
  %9943 = and i8 %9917, %9942
  %9944 = select i1 %9936, i8 %9943, i8 %9917
  store i8 %9944, ptr %frame.active, align 1
  %.splatinsert2056 = insertelement <8 x i1> poison, i1 %9926, i64 0
  %.splat2057 = shufflevector <8 x i1> %.splatinsert2056, <8 x i1> poison, <8 x i32> zeroinitializer
  %9945 = and <8 x i1> %convergence.cascade.flow2052, %.splat2057
  %9946 = load <8 x i1>, ptr %runnable.mask, align 1
  %9947 = xor <8 x i1> %9945, splat (i1 true)
  %9948 = and <8 x i1> %9946, %9947
  store <8 x i1> %9948, ptr %runnable.mask, align 1
  %.splatinsert2058 = insertelement <8 x i1> poison, i1 %9936, i64 0
  %.splat2059 = shufflevector <8 x i1> %.splatinsert2058, <8 x i1> poison, <8 x i32> zeroinitializer
  %9949 = select <8 x i1> %.splat2059, <8 x i1> %9931, <8 x i1> zeroinitializer
  %9950 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9951 = extractelement <8 x i32> %9950, i32 %9916
  %9952 = select i1 %9936, i32 %9951, i32 %9912
  store i32 %9952, ptr %current.token, align 4
  %.splatinsert2060 = insertelement <8 x i1> poison, i1 %9926, i64 0
  %.splat2061 = shufflevector <8 x i1> %.splatinsert2060, <8 x i1> poison, <8 x i32> zeroinitializer
  %9953 = select <8 x i1> %.splat2061, <8 x i1> %9949, <8 x i1> %convergence.cascade.flow2052
  %9954 = add i32 %convergence.cascade.depth2053, 1
  %9955 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9953)
  %9956 = icmp ult i32 %9954, 8
  %9957 = and i1 %9955, %9956
  %9958 = and i1 %9926, %9957
  %convergence.parent.token2062 = load i32, ptr %current.token, align 4
  %convergence.parent.present2063 = icmp ne i32 %convergence.parent.token2062, 0
  %9959 = and i1 %9958, %convergence.parent.present2063
  br i1 %9959, label %convergence.cascade2048, label %convergence.cascade.exit2049

convergence.cascade.exit2049:                     ; preds = %convergence.cascade2048, %schedule.99
  %convergence.cascade.result2064 = phi <8 x i1> [ %2555, %schedule.99 ], [ %9953, %convergence.cascade2048 ]
  %9960 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2064)
  br i1 %9960, label %convergence.target.99.ready, label %scheduler.loop

convergence.target.99.ready:                      ; preds = %convergence.cascade.exit2049
  %9961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2064)
  %9962 = bitcast <8 x i1> %convergence.cascade.result2064 to i8
  %9963 = call i8 @llvm.cttz.i8(i8 %9962, i1 false)
  %9964 = zext i8 %9963 to i32
  %9965 = select i1 %9961, i32 %9964, i32 0
  %tile_snapshot.spill.load2065 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill302, align 64
  %9966 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2065, 0
  %9967 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2065, 1
  %.spill.load2066 = load <8 x i64>, ptr %.spill305, align 64
  %9968 = mul <8 x i64> %.spill.load2066, splat (i64 32)
  %9969 = add <8 x i64> %9967, %9968
  %9970 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9966, 0
  %9971 = insertvalue { <8 x ptr>, <8 x i64> } %9970, <8 x i64> %9969, 1
  %.state2067 = load <8 x float>, ptr %.slot41, align 32
  %9972 = extractvalue { <8 x ptr>, <8 x i64> } %9971, 0
  %9973 = extractvalue { <8 x ptr>, <8 x i64> } %9971, 1
  %9974 = getelementptr i8, <8 x ptr> %9972, <8 x i64> %9973
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state2067, <8 x ptr> align 1 %9974, <8 x i1> %convergence.cascade.result2064)
  %tile_snapshot.spill.load2068 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill302, align 64
  %9975 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2068, 0
  %9976 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2068, 1
  %.spill.load2069 = load <8 x i64>, ptr %.spill308, align 64
  %9977 = mul <8 x i64> %.spill.load2069, splat (i64 32)
  %9978 = add <8 x i64> %9976, %9977
  %9979 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9975, 0
  %9980 = insertvalue { <8 x ptr>, <8 x i64> } %9979, <8 x i64> %9978, 1
  %.state2070 = load <8 x float>, ptr %.slot47, align 32
  %9981 = extractvalue { <8 x ptr>, <8 x i64> } %9980, 0
  %9982 = extractvalue { <8 x ptr>, <8 x i64> } %9980, 1
  %9983 = getelementptr i8, <8 x ptr> %9981, <8 x i64> %9982
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state2070, <8 x ptr> align 1 %9983, <8 x i1> %convergence.cascade.result2064)
  %tile_snapshot.spill.load2071 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill302, align 64
  %9984 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2071, 0
  %9985 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2071, 1
  %.spill.load2072 = load <8 x i64>, ptr %.spill310, align 64
  %9986 = mul <8 x i64> %.spill.load2072, splat (i64 32)
  %9987 = add <8 x i64> %9985, %9986
  %9988 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9984, 0
  %9989 = insertvalue { <8 x ptr>, <8 x i64> } %9988, <8 x i64> %9987, 1
  %.state2073 = load <8 x float>, ptr %.slot48, align 32
  %9990 = extractvalue { <8 x ptr>, <8 x i64> } %9989, 0
  %9991 = extractvalue { <8 x ptr>, <8 x i64> } %9989, 1
  %9992 = getelementptr i8, <8 x ptr> %9990, <8 x i64> %9991
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state2073, <8 x ptr> align 1 %9992, <8 x i1> %convergence.cascade.result2064)
  %tile_snapshot.spill.load2074 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill302, align 64
  %9993 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2074, 0
  %9994 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2074, 1
  %.spill.load2075 = load <8 x i64>, ptr %.spill312, align 64
  %9995 = mul <8 x i64> %.spill.load2075, splat (i64 32)
  %9996 = add <8 x i64> %9994, %9995
  %9997 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9993, 0
  %9998 = insertvalue { <8 x ptr>, <8 x i64> } %9997, <8 x i64> %9996, 1
  %.state2076 = load <8 x float>, ptr %.slot49, align 32
  %9999 = extractvalue { <8 x ptr>, <8 x i64> } %9998, 0
  %10000 = extractvalue { <8 x ptr>, <8 x i64> } %9998, 1
  %10001 = getelementptr i8, <8 x ptr> %9999, <8 x i64> %10000
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state2076, <8 x ptr> align 1 %10001, <8 x i1> %convergence.cascade.result2064)
  %.state2077 = load <8 x i64>, ptr %.slot304, align 64
  %10002 = add <8 x i64> %.state2077, splat (i64 1)
  %10003 = load <8 x i64>, ptr %.slot304, align 64
  %10004 = select <8 x i1> %convergence.cascade.result2064, <8 x i64> %10002, <8 x i64> %10003
  store <8 x i64> %10004, ptr %.slot304, align 64
  store <8 x i1> %convergence.cascade.result2064, ptr %current.mask, align 1
  %10005 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2064)
  br i1 %10005, label %schedule.95, label %scheduler.loop

convergence.cascade2078:                          ; preds = %convergence.cascade2078, %schedule.100
  %convergence.cascade.flow2082 = phi <8 x i1> [ %2556, %schedule.100 ], [ %10048, %convergence.cascade2078 ]
  %convergence.cascade.depth2083 = phi i32 [ 0, %schedule.100 ], [ %10049, %convergence.cascade2078 ]
  %10006 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2082)
  %10007 = load i32, ptr %current.token, align 4
  %10008 = icmp ne i32 %10007, 0
  %10009 = and i1 %10006, %10008
  %10010 = sub i32 %10007, 1
  %10011 = select i1 %10009, i32 %10010, i32 0
  %10012 = load i8, ptr %frame.active, align 1
  %10013 = trunc i32 %10011 to i8
  %10014 = shl i8 1, %10013
  %10015 = and i8 %10012, %10014
  %10016 = icmp ne i8 %10015, 0
  %10017 = load <8 x i32>, ptr %frame.static.id, align 32
  %10018 = extractelement <8 x i32> %10017, i32 %10011
  %convergence.target.pointer2084 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10018
  %convergence.dynamic.target2085 = load i32, ptr %convergence.target.pointer2084, align 4
  %10019 = icmp eq i32 %convergence.dynamic.target2085, 100
  %10020 = and i1 %10016, %10019
  %10021 = and i1 %10009, %10020
  %10022 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10011
  %10023 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10011
  %10024 = load <8 x i1>, ptr %10022, align 1
  %10025 = load <8 x i1>, ptr %10023, align 1
  %10026 = or <8 x i1> %10025, %convergence.cascade.flow2082
  %10027 = load <8 x i1>, ptr %live.mask, align 1
  %10028 = and <8 x i1> %10024, %10027
  %10029 = icmp eq <8 x i1> %10026, %10028
  %10030 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10029)
  %10031 = and i1 %10021, %10030
  %10032 = select i1 %10031, <8 x i1> zeroinitializer, <8 x i1> %10026
  %10033 = select i1 %10021, <8 x i1> %10032, <8 x i1> %10025
  store <8 x i1> %10033, ptr %10023, align 1
  %10034 = select i1 %10031, <8 x i1> zeroinitializer, <8 x i1> %10024
  store <8 x i1> %10034, ptr %10022, align 1
  %10035 = trunc i32 %10011 to i8
  %10036 = shl i8 1, %10035
  %10037 = xor i8 %10036, -1
  %10038 = and i8 %10012, %10037
  %10039 = select i1 %10031, i8 %10038, i8 %10012
  store i8 %10039, ptr %frame.active, align 1
  %.splatinsert2086 = insertelement <8 x i1> poison, i1 %10021, i64 0
  %.splat2087 = shufflevector <8 x i1> %.splatinsert2086, <8 x i1> poison, <8 x i32> zeroinitializer
  %10040 = and <8 x i1> %convergence.cascade.flow2082, %.splat2087
  %10041 = load <8 x i1>, ptr %runnable.mask, align 1
  %10042 = xor <8 x i1> %10040, splat (i1 true)
  %10043 = and <8 x i1> %10041, %10042
  store <8 x i1> %10043, ptr %runnable.mask, align 1
  %.splatinsert2088 = insertelement <8 x i1> poison, i1 %10031, i64 0
  %.splat2089 = shufflevector <8 x i1> %.splatinsert2088, <8 x i1> poison, <8 x i32> zeroinitializer
  %10044 = select <8 x i1> %.splat2089, <8 x i1> %10026, <8 x i1> zeroinitializer
  %10045 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10046 = extractelement <8 x i32> %10045, i32 %10011
  %10047 = select i1 %10031, i32 %10046, i32 %10007
  store i32 %10047, ptr %current.token, align 4
  %.splatinsert2090 = insertelement <8 x i1> poison, i1 %10021, i64 0
  %.splat2091 = shufflevector <8 x i1> %.splatinsert2090, <8 x i1> poison, <8 x i32> zeroinitializer
  %10048 = select <8 x i1> %.splat2091, <8 x i1> %10044, <8 x i1> %convergence.cascade.flow2082
  %10049 = add i32 %convergence.cascade.depth2083, 1
  %10050 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10048)
  %10051 = icmp ult i32 %10049, 8
  %10052 = and i1 %10050, %10051
  %10053 = and i1 %10021, %10052
  %convergence.parent.token2092 = load i32, ptr %current.token, align 4
  %convergence.parent.present2093 = icmp ne i32 %convergence.parent.token2092, 0
  %10054 = and i1 %10053, %convergence.parent.present2093
  br i1 %10054, label %convergence.cascade2078, label %convergence.cascade.exit2079

convergence.cascade.exit2079:                     ; preds = %convergence.cascade2078, %schedule.100
  %convergence.cascade.result2094 = phi <8 x i1> [ %2556, %schedule.100 ], [ %10048, %convergence.cascade2078 ]
  %10055 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2094)
  br i1 %10055, label %convergence.target.100.ready, label %scheduler.loop

convergence.target.100.ready:                     ; preds = %convergence.cascade.exit2079
  %10056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2094)
  %10057 = bitcast <8 x i1> %convergence.cascade.result2094 to i8
  %10058 = call i8 @llvm.cttz.i8(i8 %10057, i1 false)
  %10059 = zext i8 %10058 to i32
  %10060 = select i1 %10056, i32 %10059, i32 0
  %.state2095 = load <8 x i64>, ptr %.slot56, align 64
  %10061 = add <8 x i64> %.state2095, splat (i64 1)
  %10062 = load <8 x i64>, ptr %.slot56, align 64
  %10063 = select <8 x i1> %convergence.cascade.result2094, <8 x i64> %10061, <8 x i64> %10062
  store <8 x i64> %10063, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result2094, ptr %current.mask, align 1
  %10064 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2094)
  br i1 %10064, label %schedule.93, label %scheduler.loop

convergence.cascade2096:                          ; preds = %convergence.cascade2096, %schedule.101
  %convergence.cascade.flow2100 = phi <8 x i1> [ %2557, %schedule.101 ], [ %10107, %convergence.cascade2096 ]
  %convergence.cascade.depth2101 = phi i32 [ 0, %schedule.101 ], [ %10108, %convergence.cascade2096 ]
  %10065 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2100)
  %10066 = load i32, ptr %current.token, align 4
  %10067 = icmp ne i32 %10066, 0
  %10068 = and i1 %10065, %10067
  %10069 = sub i32 %10066, 1
  %10070 = select i1 %10068, i32 %10069, i32 0
  %10071 = load i8, ptr %frame.active, align 1
  %10072 = trunc i32 %10070 to i8
  %10073 = shl i8 1, %10072
  %10074 = and i8 %10071, %10073
  %10075 = icmp ne i8 %10074, 0
  %10076 = load <8 x i32>, ptr %frame.static.id, align 32
  %10077 = extractelement <8 x i32> %10076, i32 %10070
  %convergence.target.pointer2102 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10077
  %convergence.dynamic.target2103 = load i32, ptr %convergence.target.pointer2102, align 4
  %10078 = icmp eq i32 %convergence.dynamic.target2103, 101
  %10079 = and i1 %10075, %10078
  %10080 = and i1 %10068, %10079
  %10081 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10070
  %10082 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10070
  %10083 = load <8 x i1>, ptr %10081, align 1
  %10084 = load <8 x i1>, ptr %10082, align 1
  %10085 = or <8 x i1> %10084, %convergence.cascade.flow2100
  %10086 = load <8 x i1>, ptr %live.mask, align 1
  %10087 = and <8 x i1> %10083, %10086
  %10088 = icmp eq <8 x i1> %10085, %10087
  %10089 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10088)
  %10090 = and i1 %10080, %10089
  %10091 = select i1 %10090, <8 x i1> zeroinitializer, <8 x i1> %10085
  %10092 = select i1 %10080, <8 x i1> %10091, <8 x i1> %10084
  store <8 x i1> %10092, ptr %10082, align 1
  %10093 = select i1 %10090, <8 x i1> zeroinitializer, <8 x i1> %10083
  store <8 x i1> %10093, ptr %10081, align 1
  %10094 = trunc i32 %10070 to i8
  %10095 = shl i8 1, %10094
  %10096 = xor i8 %10095, -1
  %10097 = and i8 %10071, %10096
  %10098 = select i1 %10090, i8 %10097, i8 %10071
  store i8 %10098, ptr %frame.active, align 1
  %.splatinsert2104 = insertelement <8 x i1> poison, i1 %10080, i64 0
  %.splat2105 = shufflevector <8 x i1> %.splatinsert2104, <8 x i1> poison, <8 x i32> zeroinitializer
  %10099 = and <8 x i1> %convergence.cascade.flow2100, %.splat2105
  %10100 = load <8 x i1>, ptr %runnable.mask, align 1
  %10101 = xor <8 x i1> %10099, splat (i1 true)
  %10102 = and <8 x i1> %10100, %10101
  store <8 x i1> %10102, ptr %runnable.mask, align 1
  %.splatinsert2106 = insertelement <8 x i1> poison, i1 %10090, i64 0
  %.splat2107 = shufflevector <8 x i1> %.splatinsert2106, <8 x i1> poison, <8 x i32> zeroinitializer
  %10103 = select <8 x i1> %.splat2107, <8 x i1> %10085, <8 x i1> zeroinitializer
  %10104 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10105 = extractelement <8 x i32> %10104, i32 %10070
  %10106 = select i1 %10090, i32 %10105, i32 %10066
  store i32 %10106, ptr %current.token, align 4
  %.splatinsert2108 = insertelement <8 x i1> poison, i1 %10080, i64 0
  %.splat2109 = shufflevector <8 x i1> %.splatinsert2108, <8 x i1> poison, <8 x i32> zeroinitializer
  %10107 = select <8 x i1> %.splat2109, <8 x i1> %10103, <8 x i1> %convergence.cascade.flow2100
  %10108 = add i32 %convergence.cascade.depth2101, 1
  %10109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10107)
  %10110 = icmp ult i32 %10108, 8
  %10111 = and i1 %10109, %10110
  %10112 = and i1 %10080, %10111
  %convergence.parent.token2110 = load i32, ptr %current.token, align 4
  %convergence.parent.present2111 = icmp ne i32 %convergence.parent.token2110, 0
  %10113 = and i1 %10112, %convergence.parent.present2111
  br i1 %10113, label %convergence.cascade2096, label %convergence.cascade.exit2097

convergence.cascade.exit2097:                     ; preds = %convergence.cascade2096, %schedule.101
  %convergence.cascade.result2112 = phi <8 x i1> [ %2557, %schedule.101 ], [ %10107, %convergence.cascade2096 ]
  %10114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2112)
  br i1 %10114, label %convergence.target.101.ready, label %scheduler.loop

convergence.target.101.ready:                     ; preds = %convergence.cascade.exit2097
  %10115 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2112)
  %10116 = bitcast <8 x i1> %convergence.cascade.result2112 to i8
  %10117 = call i8 @llvm.cttz.i8(i8 %10116, i1 false)
  %10118 = zext i8 %10117 to i32
  %10119 = select i1 %10115, i32 %10118, i32 0
  %10120 = load <8 x i64>, ptr %.slot56, align 64
  %10121 = select <8 x i1> %convergence.cascade.result2112, <8 x i64> zeroinitializer, <8 x i64> %10120
  store <8 x i64> %10121, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result2112, ptr %current.mask, align 1
  %10122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2112)
  br i1 %10122, label %schedule.102, label %scheduler.loop

varying.divergent2114:                            ; preds = %schedule.102
  %10123 = load i32, ptr %current.token, align 4
  %10124 = icmp ne i32 %10123, 0
  %10125 = sub i32 %10123, 1
  %10126 = select i1 %10124, i32 %10125, i32 0
  %10127 = load i8, ptr %frame.active, align 1
  %10128 = trunc i32 %10126 to i8
  %10129 = shl i8 1, %10128
  %10130 = and i8 %10127, %10129
  %10131 = icmp ne i8 %10130, 0
  %10132 = load <8 x i32>, ptr %frame.static.id, align 32
  %10133 = extractelement <8 x i32> %10132, i32 %10126
  %10134 = icmp eq i32 %10133, 35
  %10135 = and i1 %10131, %10134
  %10136 = and i1 %10124, %10135
  %10137 = xor i1 %10136, true
  %10138 = and i1 true, %10137
  %10139 = xor i8 %10127, -1
  %10140 = icmp ne i8 %10139, 0
  %10141 = xor i1 %10140, true
  %10142 = and i1 %10138, %10141
  br i1 %10142, label %convergence.overflow.trap2116, label %convergence.overflow.resume2117

varying.coherent2115:                             ; preds = %schedule.102
  br i1 %2568, label %varying.coherent.true2120, label %varying.coherent.false2121

convergence.overflow.trap2116:                    ; preds = %varying.divergent2114
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2117:                  ; preds = %varying.divergent2114
  %10143 = call i8 @llvm.cttz.i8(i8 %10139, i1 false)
  %10144 = zext i8 %10143 to i32
  %10145 = select i1 %10140, i32 %10144, i32 0
  %10146 = trunc i32 %10145 to i8
  %10147 = shl i8 1, %10146
  %10148 = or i8 %10127, %10147
  %10149 = select i1 %10138, i8 %10148, i8 %10127
  store i8 %10149, ptr %frame.active, align 1
  %10150 = load <8 x i32>, ptr %frame.static.id, align 32
  %10151 = extractelement <8 x i32> %10150, i32 %10145
  %10152 = select i1 %10138, i32 35, i32 %10151
  %10153 = load <8 x i32>, ptr %frame.static.id, align 32
  %10154 = insertelement <8 x i32> %10153, i32 %10152, i32 %10145
  store <8 x i32> %10154, ptr %frame.static.id, align 32
  %10155 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10156 = extractelement <8 x i32> %10155, i32 %10145
  %10157 = select i1 %10138, i32 %10123, i32 %10156
  %10158 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10159 = insertelement <8 x i32> %10158, i32 %10157, i32 %10145
  store <8 x i32> %10159, ptr %frame.parent.token, align 32
  %10160 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10145
  %10161 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10145
  %10162 = load <8 x i1>, ptr %10160, align 1
  %10163 = load <8 x i1>, ptr %10161, align 1
  %10164 = select i1 %10138, <8 x i1> %2558, <8 x i1> %10162
  store <8 x i1> %10164, ptr %10160, align 1
  %10165 = select i1 %10138, <8 x i1> zeroinitializer, <8 x i1> %10163
  store <8 x i1> %10165, ptr %10161, align 1
  %10166 = add i32 %10145, 1
  %10167 = select i1 %10136, i32 %10123, i32 %10166
  %10168 = select i1 true, i32 %10167, i32 %10123
  store i32 %10168, ptr %current.token, align 4
  %10169 = load i32, ptr %current.token, align 4
  %10170 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2565)
  %10171 = load i32, ptr %ready.count, align 4
  %10172 = icmp uge i32 %10171, 8
  %10173 = and i1 %10170, %10172
  br i1 %10173, label %ready.overflow.trap2118, label %ready.overflow.resume2119

ready.overflow.trap2118:                          ; preds = %convergence.overflow.resume2117
  call void @llvm.trap()
  unreachable

ready.overflow.resume2119:                        ; preds = %convergence.overflow.resume2117
  %10174 = select i1 %10170, i32 %10171, i32 0
  %10175 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10174
  %10176 = load <8 x i1>, ptr %10175, align 1
  %10177 = select i1 %10170, <8 x i1> %2565, <8 x i1> %10176
  store <8 x i1> %10177, ptr %10175, align 1
  %10178 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10174
  %10179 = load i32, ptr %10178, align 4
  %10180 = select i1 %10170, i32 103, i32 %10179
  store i32 %10180, ptr %10178, align 4
  %10181 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10174
  %10182 = load i32, ptr %10181, align 4
  %10183 = select i1 %10170, i32 %10169, i32 %10182
  store i32 %10183, ptr %10181, align 4
  %10184 = add i32 %10171, 1
  %10185 = select i1 %10170, i32 %10184, i32 %10171
  store i32 %10185, ptr %ready.count, align 4
  %10186 = load <8 x i1>, ptr %runnable.mask, align 1
  %10187 = or <8 x i1> %10186, %2565
  store <8 x i1> %10187, ptr %runnable.mask, align 1
  store <8 x i1> %2567, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2120:                        ; preds = %varying.coherent2115
  store <8 x i1> %2558, ptr %current.mask, align 1
  %10188 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2558)
  br i1 %10188, label %schedule.103, label %scheduler.loop

varying.coherent.false2121:                       ; preds = %varying.coherent2115
  store <8 x i1> %2558, ptr %current.mask, align 1
  %10189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2558)
  br i1 %10189, label %schedule.104, label %scheduler.loop

convergence.cascade2127:                          ; preds = %convergence.cascade2127, %schedule.104
  %convergence.cascade.flow2131 = phi <8 x i1> [ %2600, %schedule.104 ], [ %10232, %convergence.cascade2127 ]
  %convergence.cascade.depth2132 = phi i32 [ 0, %schedule.104 ], [ %10233, %convergence.cascade2127 ]
  %10190 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2131)
  %10191 = load i32, ptr %current.token, align 4
  %10192 = icmp ne i32 %10191, 0
  %10193 = and i1 %10190, %10192
  %10194 = sub i32 %10191, 1
  %10195 = select i1 %10193, i32 %10194, i32 0
  %10196 = load i8, ptr %frame.active, align 1
  %10197 = trunc i32 %10195 to i8
  %10198 = shl i8 1, %10197
  %10199 = and i8 %10196, %10198
  %10200 = icmp ne i8 %10199, 0
  %10201 = load <8 x i32>, ptr %frame.static.id, align 32
  %10202 = extractelement <8 x i32> %10201, i32 %10195
  %convergence.target.pointer2133 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10202
  %convergence.dynamic.target2134 = load i32, ptr %convergence.target.pointer2133, align 4
  %10203 = icmp eq i32 %convergence.dynamic.target2134, 104
  %10204 = and i1 %10200, %10203
  %10205 = and i1 %10193, %10204
  %10206 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10195
  %10207 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10195
  %10208 = load <8 x i1>, ptr %10206, align 1
  %10209 = load <8 x i1>, ptr %10207, align 1
  %10210 = or <8 x i1> %10209, %convergence.cascade.flow2131
  %10211 = load <8 x i1>, ptr %live.mask, align 1
  %10212 = and <8 x i1> %10208, %10211
  %10213 = icmp eq <8 x i1> %10210, %10212
  %10214 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10213)
  %10215 = and i1 %10205, %10214
  %10216 = select i1 %10215, <8 x i1> zeroinitializer, <8 x i1> %10210
  %10217 = select i1 %10205, <8 x i1> %10216, <8 x i1> %10209
  store <8 x i1> %10217, ptr %10207, align 1
  %10218 = select i1 %10215, <8 x i1> zeroinitializer, <8 x i1> %10208
  store <8 x i1> %10218, ptr %10206, align 1
  %10219 = trunc i32 %10195 to i8
  %10220 = shl i8 1, %10219
  %10221 = xor i8 %10220, -1
  %10222 = and i8 %10196, %10221
  %10223 = select i1 %10215, i8 %10222, i8 %10196
  store i8 %10223, ptr %frame.active, align 1
  %.splatinsert2135 = insertelement <8 x i1> poison, i1 %10205, i64 0
  %.splat2136 = shufflevector <8 x i1> %.splatinsert2135, <8 x i1> poison, <8 x i32> zeroinitializer
  %10224 = and <8 x i1> %convergence.cascade.flow2131, %.splat2136
  %10225 = load <8 x i1>, ptr %runnable.mask, align 1
  %10226 = xor <8 x i1> %10224, splat (i1 true)
  %10227 = and <8 x i1> %10225, %10226
  store <8 x i1> %10227, ptr %runnable.mask, align 1
  %.splatinsert2137 = insertelement <8 x i1> poison, i1 %10215, i64 0
  %.splat2138 = shufflevector <8 x i1> %.splatinsert2137, <8 x i1> poison, <8 x i32> zeroinitializer
  %10228 = select <8 x i1> %.splat2138, <8 x i1> %10210, <8 x i1> zeroinitializer
  %10229 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10230 = extractelement <8 x i32> %10229, i32 %10195
  %10231 = select i1 %10215, i32 %10230, i32 %10191
  store i32 %10231, ptr %current.token, align 4
  %.splatinsert2139 = insertelement <8 x i1> poison, i1 %10205, i64 0
  %.splat2140 = shufflevector <8 x i1> %.splatinsert2139, <8 x i1> poison, <8 x i32> zeroinitializer
  %10232 = select <8 x i1> %.splat2140, <8 x i1> %10228, <8 x i1> %convergence.cascade.flow2131
  %10233 = add i32 %convergence.cascade.depth2132, 1
  %10234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10232)
  %10235 = icmp ult i32 %10233, 8
  %10236 = and i1 %10234, %10235
  %10237 = and i1 %10205, %10236
  %convergence.parent.token2141 = load i32, ptr %current.token, align 4
  %convergence.parent.present2142 = icmp ne i32 %convergence.parent.token2141, 0
  %10238 = and i1 %10237, %convergence.parent.present2142
  br i1 %10238, label %convergence.cascade2127, label %convergence.cascade.exit2128

convergence.cascade.exit2128:                     ; preds = %convergence.cascade2127, %schedule.104
  %convergence.cascade.result2143 = phi <8 x i1> [ %2600, %schedule.104 ], [ %10232, %convergence.cascade2127 ]
  %10239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2143)
  br i1 %10239, label %convergence.target.104.ready, label %scheduler.loop

convergence.target.104.ready:                     ; preds = %convergence.cascade.exit2128
  %10240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2143)
  %10241 = bitcast <8 x i1> %convergence.cascade.result2143 to i8
  %10242 = call i8 @llvm.cttz.i8(i8 %10241, i1 false)
  %10243 = zext i8 %10242 to i32
  %10244 = select i1 %10240, i32 %10243, i32 0
  %10245 = load <8 x i64>, ptr %.slot56, align 64
  %10246 = select <8 x i1> %convergence.cascade.result2143, <8 x i64> zeroinitializer, <8 x i64> %10245
  store <8 x i64> %10246, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result2143, ptr %current.mask, align 1
  %10247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2143)
  br i1 %10247, label %schedule.105, label %scheduler.loop

varying.divergent2145:                            ; preds = %schedule.105
  %10248 = load i32, ptr %current.token, align 4
  %10249 = icmp ne i32 %10248, 0
  %10250 = sub i32 %10248, 1
  %10251 = select i1 %10249, i32 %10250, i32 0
  %10252 = load i8, ptr %frame.active, align 1
  %10253 = trunc i32 %10251 to i8
  %10254 = shl i8 1, %10253
  %10255 = and i8 %10252, %10254
  %10256 = icmp ne i8 %10255, 0
  %10257 = load <8 x i32>, ptr %frame.static.id, align 32
  %10258 = extractelement <8 x i32> %10257, i32 %10251
  %10259 = icmp eq i32 %10258, 36
  %10260 = and i1 %10256, %10259
  %10261 = and i1 %10249, %10260
  %10262 = xor i1 %10261, true
  %10263 = and i1 true, %10262
  %10264 = xor i8 %10252, -1
  %10265 = icmp ne i8 %10264, 0
  %10266 = xor i1 %10265, true
  %10267 = and i1 %10263, %10266
  br i1 %10267, label %convergence.overflow.trap2147, label %convergence.overflow.resume2148

varying.coherent2146:                             ; preds = %schedule.105
  br i1 %2611, label %varying.coherent.true2151, label %varying.coherent.false2152

convergence.overflow.trap2147:                    ; preds = %varying.divergent2145
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2148:                  ; preds = %varying.divergent2145
  %10268 = call i8 @llvm.cttz.i8(i8 %10264, i1 false)
  %10269 = zext i8 %10268 to i32
  %10270 = select i1 %10265, i32 %10269, i32 0
  %10271 = trunc i32 %10270 to i8
  %10272 = shl i8 1, %10271
  %10273 = or i8 %10252, %10272
  %10274 = select i1 %10263, i8 %10273, i8 %10252
  store i8 %10274, ptr %frame.active, align 1
  %10275 = load <8 x i32>, ptr %frame.static.id, align 32
  %10276 = extractelement <8 x i32> %10275, i32 %10270
  %10277 = select i1 %10263, i32 36, i32 %10276
  %10278 = load <8 x i32>, ptr %frame.static.id, align 32
  %10279 = insertelement <8 x i32> %10278, i32 %10277, i32 %10270
  store <8 x i32> %10279, ptr %frame.static.id, align 32
  %10280 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10281 = extractelement <8 x i32> %10280, i32 %10270
  %10282 = select i1 %10263, i32 %10248, i32 %10281
  %10283 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10284 = insertelement <8 x i32> %10283, i32 %10282, i32 %10270
  store <8 x i32> %10284, ptr %frame.parent.token, align 32
  %10285 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10270
  %10286 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10270
  %10287 = load <8 x i1>, ptr %10285, align 1
  %10288 = load <8 x i1>, ptr %10286, align 1
  %10289 = select i1 %10263, <8 x i1> %2601, <8 x i1> %10287
  store <8 x i1> %10289, ptr %10285, align 1
  %10290 = select i1 %10263, <8 x i1> zeroinitializer, <8 x i1> %10288
  store <8 x i1> %10290, ptr %10286, align 1
  %10291 = add i32 %10270, 1
  %10292 = select i1 %10261, i32 %10248, i32 %10291
  %10293 = select i1 true, i32 %10292, i32 %10248
  store i32 %10293, ptr %current.token, align 4
  %10294 = load i32, ptr %current.token, align 4
  %10295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2608)
  %10296 = load i32, ptr %ready.count, align 4
  %10297 = icmp uge i32 %10296, 8
  %10298 = and i1 %10295, %10297
  br i1 %10298, label %ready.overflow.trap2149, label %ready.overflow.resume2150

ready.overflow.trap2149:                          ; preds = %convergence.overflow.resume2148
  call void @llvm.trap()
  unreachable

ready.overflow.resume2150:                        ; preds = %convergence.overflow.resume2148
  %10299 = select i1 %10295, i32 %10296, i32 0
  %10300 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10299
  %10301 = load <8 x i1>, ptr %10300, align 1
  %10302 = select i1 %10295, <8 x i1> %2608, <8 x i1> %10301
  store <8 x i1> %10302, ptr %10300, align 1
  %10303 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10299
  %10304 = load i32, ptr %10303, align 4
  %10305 = select i1 %10295, i32 106, i32 %10304
  store i32 %10305, ptr %10303, align 4
  %10306 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10299
  %10307 = load i32, ptr %10306, align 4
  %10308 = select i1 %10295, i32 %10294, i32 %10307
  store i32 %10308, ptr %10306, align 4
  %10309 = add i32 %10296, 1
  %10310 = select i1 %10295, i32 %10309, i32 %10296
  store i32 %10310, ptr %ready.count, align 4
  %10311 = load <8 x i1>, ptr %runnable.mask, align 1
  %10312 = or <8 x i1> %10311, %2608
  store <8 x i1> %10312, ptr %runnable.mask, align 1
  store <8 x i1> %2610, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2151:                        ; preds = %varying.coherent2146
  store <8 x i1> %2601, ptr %current.mask, align 1
  %10313 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2601)
  br i1 %10313, label %schedule.106, label %scheduler.loop

varying.coherent.false2152:                       ; preds = %varying.coherent2146
  store <8 x i1> %2601, ptr %current.mask, align 1
  %10314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2601)
  br i1 %10314, label %schedule.107, label %scheduler.loop

convergence.cascade2158:                          ; preds = %convergence.cascade2158, %schedule.107
  %convergence.cascade.flow2162 = phi <8 x i1> [ %2643, %schedule.107 ], [ %10357, %convergence.cascade2158 ]
  %convergence.cascade.depth2163 = phi i32 [ 0, %schedule.107 ], [ %10358, %convergence.cascade2158 ]
  %10315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2162)
  %10316 = load i32, ptr %current.token, align 4
  %10317 = icmp ne i32 %10316, 0
  %10318 = and i1 %10315, %10317
  %10319 = sub i32 %10316, 1
  %10320 = select i1 %10318, i32 %10319, i32 0
  %10321 = load i8, ptr %frame.active, align 1
  %10322 = trunc i32 %10320 to i8
  %10323 = shl i8 1, %10322
  %10324 = and i8 %10321, %10323
  %10325 = icmp ne i8 %10324, 0
  %10326 = load <8 x i32>, ptr %frame.static.id, align 32
  %10327 = extractelement <8 x i32> %10326, i32 %10320
  %convergence.target.pointer2164 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10327
  %convergence.dynamic.target2165 = load i32, ptr %convergence.target.pointer2164, align 4
  %10328 = icmp eq i32 %convergence.dynamic.target2165, 107
  %10329 = and i1 %10325, %10328
  %10330 = and i1 %10318, %10329
  %10331 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10320
  %10332 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10320
  %10333 = load <8 x i1>, ptr %10331, align 1
  %10334 = load <8 x i1>, ptr %10332, align 1
  %10335 = or <8 x i1> %10334, %convergence.cascade.flow2162
  %10336 = load <8 x i1>, ptr %live.mask, align 1
  %10337 = and <8 x i1> %10333, %10336
  %10338 = icmp eq <8 x i1> %10335, %10337
  %10339 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10338)
  %10340 = and i1 %10330, %10339
  %10341 = select i1 %10340, <8 x i1> zeroinitializer, <8 x i1> %10335
  %10342 = select i1 %10330, <8 x i1> %10341, <8 x i1> %10334
  store <8 x i1> %10342, ptr %10332, align 1
  %10343 = select i1 %10340, <8 x i1> zeroinitializer, <8 x i1> %10333
  store <8 x i1> %10343, ptr %10331, align 1
  %10344 = trunc i32 %10320 to i8
  %10345 = shl i8 1, %10344
  %10346 = xor i8 %10345, -1
  %10347 = and i8 %10321, %10346
  %10348 = select i1 %10340, i8 %10347, i8 %10321
  store i8 %10348, ptr %frame.active, align 1
  %.splatinsert2166 = insertelement <8 x i1> poison, i1 %10330, i64 0
  %.splat2167 = shufflevector <8 x i1> %.splatinsert2166, <8 x i1> poison, <8 x i32> zeroinitializer
  %10349 = and <8 x i1> %convergence.cascade.flow2162, %.splat2167
  %10350 = load <8 x i1>, ptr %runnable.mask, align 1
  %10351 = xor <8 x i1> %10349, splat (i1 true)
  %10352 = and <8 x i1> %10350, %10351
  store <8 x i1> %10352, ptr %runnable.mask, align 1
  %.splatinsert2168 = insertelement <8 x i1> poison, i1 %10340, i64 0
  %.splat2169 = shufflevector <8 x i1> %.splatinsert2168, <8 x i1> poison, <8 x i32> zeroinitializer
  %10353 = select <8 x i1> %.splat2169, <8 x i1> %10335, <8 x i1> zeroinitializer
  %10354 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10355 = extractelement <8 x i32> %10354, i32 %10320
  %10356 = select i1 %10340, i32 %10355, i32 %10316
  store i32 %10356, ptr %current.token, align 4
  %.splatinsert2170 = insertelement <8 x i1> poison, i1 %10330, i64 0
  %.splat2171 = shufflevector <8 x i1> %.splatinsert2170, <8 x i1> poison, <8 x i32> zeroinitializer
  %10357 = select <8 x i1> %.splat2171, <8 x i1> %10353, <8 x i1> %convergence.cascade.flow2162
  %10358 = add i32 %convergence.cascade.depth2163, 1
  %10359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10357)
  %10360 = icmp ult i32 %10358, 8
  %10361 = and i1 %10359, %10360
  %10362 = and i1 %10330, %10361
  %convergence.parent.token2172 = load i32, ptr %current.token, align 4
  %convergence.parent.present2173 = icmp ne i32 %convergence.parent.token2172, 0
  %10363 = and i1 %10362, %convergence.parent.present2173
  br i1 %10363, label %convergence.cascade2158, label %convergence.cascade.exit2159

convergence.cascade.exit2159:                     ; preds = %convergence.cascade2158, %schedule.107
  %convergence.cascade.result2174 = phi <8 x i1> [ %2643, %schedule.107 ], [ %10357, %convergence.cascade2158 ]
  %10364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2174)
  br i1 %10364, label %convergence.target.107.ready, label %scheduler.loop

convergence.target.107.ready:                     ; preds = %convergence.cascade.exit2159
  %10365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2174)
  %10366 = bitcast <8 x i1> %convergence.cascade.result2174 to i8
  %10367 = call i8 @llvm.cttz.i8(i8 %10366, i1 false)
  %10368 = zext i8 %10367 to i32
  %10369 = select i1 %10365, i32 %10368, i32 0
  %.state2175 = load <8 x i64>, ptr %.slot, align 64
  %10370 = add <8 x i64> %.state2175, splat (i64 1)
  %.spill.load2176 = load <8 x float>, ptr %.spill280, align 32
  %.spill.load2177 = load <8 x float>, ptr %.spill281, align 32
  %.spill.load2178 = load <8 x float>, ptr %.spill282, align 32
  %.spill.load2179 = load <8 x float>, ptr %.spill283, align 32
  %.spill.load2180 = load <8 x float>, ptr %.spill298, align 32
  %.spill.load2181 = load <8 x float>, ptr %.spill299, align 32
  %.spill.load2182 = load <8 x float>, ptr %.spill300, align 32
  %.spill.load2183 = load <8 x float>, ptr %.spill301, align 32
  %10371 = load <8 x i64>, ptr %.slot, align 64
  %10372 = select <8 x i1> %convergence.cascade.result2174, <8 x i64> %10370, <8 x i64> %10371
  store <8 x i64> %10372, ptr %.slot, align 64
  %10373 = load <8 x float>, ptr %.slot41, align 32
  %10374 = select <8 x i1> %convergence.cascade.result2174, <8 x float> %.spill.load2176, <8 x float> %10373
  store <8 x float> %10374, ptr %.slot41, align 32
  %10375 = load <8 x float>, ptr %.slot47, align 32
  %10376 = select <8 x i1> %convergence.cascade.result2174, <8 x float> %.spill.load2177, <8 x float> %10375
  store <8 x float> %10376, ptr %.slot47, align 32
  %10377 = load <8 x float>, ptr %.slot48, align 32
  %10378 = select <8 x i1> %convergence.cascade.result2174, <8 x float> %.spill.load2178, <8 x float> %10377
  store <8 x float> %10378, ptr %.slot48, align 32
  %10379 = load <8 x float>, ptr %.slot49, align 32
  %10380 = select <8 x i1> %convergence.cascade.result2174, <8 x float> %.spill.load2179, <8 x float> %10379
  store <8 x float> %10380, ptr %.slot49, align 32
  %10381 = load <8 x float>, ptr %.slot50, align 32
  %10382 = select <8 x i1> %convergence.cascade.result2174, <8 x float> %.spill.load2180, <8 x float> %10381
  store <8 x float> %10382, ptr %.slot50, align 32
  %10383 = load <8 x float>, ptr %.slot51, align 32
  %10384 = select <8 x i1> %convergence.cascade.result2174, <8 x float> %.spill.load2181, <8 x float> %10383
  store <8 x float> %10384, ptr %.slot51, align 32
  %10385 = load <8 x float>, ptr %.slot52, align 32
  %10386 = select <8 x i1> %convergence.cascade.result2174, <8 x float> %.spill.load2182, <8 x float> %10385
  store <8 x float> %10386, ptr %.slot52, align 32
  %10387 = load <8 x float>, ptr %.slot53, align 32
  %10388 = select <8 x i1> %convergence.cascade.result2174, <8 x float> %.spill.load2183, <8 x float> %10387
  store <8 x float> %10388, ptr %.slot53, align 32
  store <8 x i1> %convergence.cascade.result2174, ptr %current.mask, align 1
  %10389 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2174)
  br i1 %10389, label %schedule.9, label %scheduler.loop

convergence.cascade2184:                          ; preds = %convergence.cascade2184, %schedule.108
  %convergence.cascade.flow2188 = phi <8 x i1> [ %2644, %schedule.108 ], [ %10432, %convergence.cascade2184 ]
  %convergence.cascade.depth2189 = phi i32 [ 0, %schedule.108 ], [ %10433, %convergence.cascade2184 ]
  %10390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2188)
  %10391 = load i32, ptr %current.token, align 4
  %10392 = icmp ne i32 %10391, 0
  %10393 = and i1 %10390, %10392
  %10394 = sub i32 %10391, 1
  %10395 = select i1 %10393, i32 %10394, i32 0
  %10396 = load i8, ptr %frame.active, align 1
  %10397 = trunc i32 %10395 to i8
  %10398 = shl i8 1, %10397
  %10399 = and i8 %10396, %10398
  %10400 = icmp ne i8 %10399, 0
  %10401 = load <8 x i32>, ptr %frame.static.id, align 32
  %10402 = extractelement <8 x i32> %10401, i32 %10395
  %convergence.target.pointer2190 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10402
  %convergence.dynamic.target2191 = load i32, ptr %convergence.target.pointer2190, align 4
  %10403 = icmp eq i32 %convergence.dynamic.target2191, 108
  %10404 = and i1 %10400, %10403
  %10405 = and i1 %10393, %10404
  %10406 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10395
  %10407 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10395
  %10408 = load <8 x i1>, ptr %10406, align 1
  %10409 = load <8 x i1>, ptr %10407, align 1
  %10410 = or <8 x i1> %10409, %convergence.cascade.flow2188
  %10411 = load <8 x i1>, ptr %live.mask, align 1
  %10412 = and <8 x i1> %10408, %10411
  %10413 = icmp eq <8 x i1> %10410, %10412
  %10414 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10413)
  %10415 = and i1 %10405, %10414
  %10416 = select i1 %10415, <8 x i1> zeroinitializer, <8 x i1> %10410
  %10417 = select i1 %10405, <8 x i1> %10416, <8 x i1> %10409
  store <8 x i1> %10417, ptr %10407, align 1
  %10418 = select i1 %10415, <8 x i1> zeroinitializer, <8 x i1> %10408
  store <8 x i1> %10418, ptr %10406, align 1
  %10419 = trunc i32 %10395 to i8
  %10420 = shl i8 1, %10419
  %10421 = xor i8 %10420, -1
  %10422 = and i8 %10396, %10421
  %10423 = select i1 %10415, i8 %10422, i8 %10396
  store i8 %10423, ptr %frame.active, align 1
  %.splatinsert2192 = insertelement <8 x i1> poison, i1 %10405, i64 0
  %.splat2193 = shufflevector <8 x i1> %.splatinsert2192, <8 x i1> poison, <8 x i32> zeroinitializer
  %10424 = and <8 x i1> %convergence.cascade.flow2188, %.splat2193
  %10425 = load <8 x i1>, ptr %runnable.mask, align 1
  %10426 = xor <8 x i1> %10424, splat (i1 true)
  %10427 = and <8 x i1> %10425, %10426
  store <8 x i1> %10427, ptr %runnable.mask, align 1
  %.splatinsert2194 = insertelement <8 x i1> poison, i1 %10415, i64 0
  %.splat2195 = shufflevector <8 x i1> %.splatinsert2194, <8 x i1> poison, <8 x i32> zeroinitializer
  %10428 = select <8 x i1> %.splat2195, <8 x i1> %10410, <8 x i1> zeroinitializer
  %10429 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10430 = extractelement <8 x i32> %10429, i32 %10395
  %10431 = select i1 %10415, i32 %10430, i32 %10391
  store i32 %10431, ptr %current.token, align 4
  %.splatinsert2196 = insertelement <8 x i1> poison, i1 %10405, i64 0
  %.splat2197 = shufflevector <8 x i1> %.splatinsert2196, <8 x i1> poison, <8 x i32> zeroinitializer
  %10432 = select <8 x i1> %.splat2197, <8 x i1> %10428, <8 x i1> %convergence.cascade.flow2188
  %10433 = add i32 %convergence.cascade.depth2189, 1
  %10434 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10432)
  %10435 = icmp ult i32 %10433, 8
  %10436 = and i1 %10434, %10435
  %10437 = and i1 %10405, %10436
  %convergence.parent.token2198 = load i32, ptr %current.token, align 4
  %convergence.parent.present2199 = icmp ne i32 %convergence.parent.token2198, 0
  %10438 = and i1 %10437, %convergence.parent.present2199
  br i1 %10438, label %convergence.cascade2184, label %convergence.cascade.exit2185

convergence.cascade.exit2185:                     ; preds = %convergence.cascade2184, %schedule.108
  %convergence.cascade.result2200 = phi <8 x i1> [ %2644, %schedule.108 ], [ %10432, %convergence.cascade2184 ]
  %10439 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2200)
  br i1 %10439, label %convergence.target.108.ready, label %scheduler.loop

convergence.target.108.ready:                     ; preds = %convergence.cascade.exit2185
  %10440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2200)
  %10441 = bitcast <8 x i1> %convergence.cascade.result2200 to i8
  %10442 = call i8 @llvm.cttz.i8(i8 %10441, i1 false)
  %10443 = zext i8 %10442 to i32
  %10444 = select i1 %10440, i32 %10443, i32 0
  %10445 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill321, align 64
  %10446 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10447 = extractvalue { <8 x ptr>, <8 x i64> } %10445, 0
  %10448 = select <8 x i1> %convergence.cascade.result2200, <8 x ptr> %10446, <8 x ptr> %10447
  %10449 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10450 = extractvalue { <8 x ptr>, <8 x i64> } %10445, 1
  %10451 = select <8 x i1> %convergence.cascade.result2200, <8 x i64> %10449, <8 x i64> %10450
  %10452 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10448, 0
  %10453 = insertvalue { <8 x ptr>, <8 x i64> } %10452, <8 x i64> %10451, 1
  store { <8 x ptr>, <8 x i64> } %10453, ptr %tile_snapshot.spill321, align 64
  %10454 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10455 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10456 = add <8 x i64> %10455, zeroinitializer
  %10457 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10454, 0
  %10458 = insertvalue { <8 x ptr>, <8 x i64> } %10457, <8 x i64> %10456, 1
  %.state2201 = load <8 x float>, ptr %.slot50, align 32
  %10459 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10460 = extractvalue { <8 x ptr>, <8 x i64> } %10458, 1
  %10461 = extractelement <8 x ptr> %10459, i32 0
  %10462 = extractelement <8 x i64> %10460, i32 %10444
  %10463 = zext i32 %10444 to i64
  %10464 = mul i64 %10463, 4
  %10465 = sub i64 %10462, %10464
  %10466 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2200)
  %10467 = select i1 %10466, i64 %10465, i64 0
  %private.contiguous.address2202 = getelementptr i8, ptr %10461, i64 %10467
  %private.contiguous.preserve2203 = load <8 x float>, ptr %private.contiguous.address2202, align 4
  %10468 = select <8 x i1> %convergence.cascade.result2200, <8 x float> %.state2201, <8 x float> %private.contiguous.preserve2203
  store <8 x float> %10468, ptr %private.contiguous.address2202, align 4
  %10469 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10470 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10471 = add <8 x i64> %10470, splat (i64 32)
  %10472 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10469, 0
  %10473 = insertvalue { <8 x ptr>, <8 x i64> } %10472, <8 x i64> %10471, 1
  %.state2204 = load <8 x float>, ptr %.slot51, align 32
  %10474 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10475 = extractvalue { <8 x ptr>, <8 x i64> } %10473, 1
  %10476 = extractelement <8 x ptr> %10474, i32 0
  %10477 = extractelement <8 x i64> %10475, i32 %10444
  %10478 = zext i32 %10444 to i64
  %10479 = mul i64 %10478, 4
  %10480 = sub i64 %10477, %10479
  %10481 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2200)
  %10482 = select i1 %10481, i64 %10480, i64 0
  %private.contiguous.address2205 = getelementptr i8, ptr %10476, i64 %10482
  %private.contiguous.preserve2206 = load <8 x float>, ptr %private.contiguous.address2205, align 4
  %10483 = select <8 x i1> %convergence.cascade.result2200, <8 x float> %.state2204, <8 x float> %private.contiguous.preserve2206
  store <8 x float> %10483, ptr %private.contiguous.address2205, align 4
  %10484 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10485 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10486 = add <8 x i64> %10485, splat (i64 64)
  %10487 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10484, 0
  %10488 = insertvalue { <8 x ptr>, <8 x i64> } %10487, <8 x i64> %10486, 1
  %.state2207 = load <8 x float>, ptr %.slot52, align 32
  %10489 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10490 = extractvalue { <8 x ptr>, <8 x i64> } %10488, 1
  %10491 = extractelement <8 x ptr> %10489, i32 0
  %10492 = extractelement <8 x i64> %10490, i32 %10444
  %10493 = zext i32 %10444 to i64
  %10494 = mul i64 %10493, 4
  %10495 = sub i64 %10492, %10494
  %10496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2200)
  %10497 = select i1 %10496, i64 %10495, i64 0
  %private.contiguous.address2208 = getelementptr i8, ptr %10491, i64 %10497
  %private.contiguous.preserve2209 = load <8 x float>, ptr %private.contiguous.address2208, align 4
  %10498 = select <8 x i1> %convergence.cascade.result2200, <8 x float> %.state2207, <8 x float> %private.contiguous.preserve2209
  store <8 x float> %10498, ptr %private.contiguous.address2208, align 4
  %10499 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10500 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10501 = add <8 x i64> %10500, splat (i64 96)
  %10502 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10499, 0
  %10503 = insertvalue { <8 x ptr>, <8 x i64> } %10502, <8 x i64> %10501, 1
  %.state2210 = load <8 x float>, ptr %.slot53, align 32
  %10504 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10505 = extractvalue { <8 x ptr>, <8 x i64> } %10503, 1
  %10506 = extractelement <8 x ptr> %10504, i32 0
  %10507 = extractelement <8 x i64> %10505, i32 %10444
  %10508 = zext i32 %10444 to i64
  %10509 = mul i64 %10508, 4
  %10510 = sub i64 %10507, %10509
  %10511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2200)
  %10512 = select i1 %10511, i64 %10510, i64 0
  %private.contiguous.address2211 = getelementptr i8, ptr %10506, i64 %10512
  %private.contiguous.preserve2212 = load <8 x float>, ptr %private.contiguous.address2211, align 4
  %10513 = select <8 x i1> %convergence.cascade.result2200, <8 x float> %.state2210, <8 x float> %private.contiguous.preserve2212
  store <8 x float> %10513, ptr %private.contiguous.address2211, align 4
  %10514 = load <8 x i64>, ptr %.slot, align 64
  %10515 = select <8 x i1> %convergence.cascade.result2200, <8 x i64> zeroinitializer, <8 x i64> %10514
  store <8 x i64> %10515, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result2200, ptr %current.mask, align 1
  %10516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2200)
  br i1 %10516, label %schedule.109, label %scheduler.loop

varying.divergent2214:                            ; preds = %schedule.109
  %10517 = load i32, ptr %current.token, align 4
  %10518 = icmp ne i32 %10517, 0
  %10519 = sub i32 %10517, 1
  %10520 = select i1 %10518, i32 %10519, i32 0
  %10521 = load i8, ptr %frame.active, align 1
  %10522 = trunc i32 %10520 to i8
  %10523 = shl i8 1, %10522
  %10524 = and i8 %10521, %10523
  %10525 = icmp ne i8 %10524, 0
  %10526 = load <8 x i32>, ptr %frame.static.id, align 32
  %10527 = extractelement <8 x i32> %10526, i32 %10520
  %10528 = icmp eq i32 %10527, 37
  %10529 = and i1 %10525, %10528
  %10530 = and i1 %10518, %10529
  %10531 = xor i1 %10530, true
  %10532 = and i1 true, %10531
  %10533 = xor i8 %10521, -1
  %10534 = icmp ne i8 %10533, 0
  %10535 = xor i1 %10534, true
  %10536 = and i1 %10532, %10535
  br i1 %10536, label %convergence.overflow.trap2216, label %convergence.overflow.resume2217

varying.coherent2215:                             ; preds = %schedule.109
  br i1 %2655, label %varying.coherent.true2220, label %varying.coherent.false2221

convergence.overflow.trap2216:                    ; preds = %varying.divergent2214
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2217:                  ; preds = %varying.divergent2214
  %10537 = call i8 @llvm.cttz.i8(i8 %10533, i1 false)
  %10538 = zext i8 %10537 to i32
  %10539 = select i1 %10534, i32 %10538, i32 0
  %10540 = trunc i32 %10539 to i8
  %10541 = shl i8 1, %10540
  %10542 = or i8 %10521, %10541
  %10543 = select i1 %10532, i8 %10542, i8 %10521
  store i8 %10543, ptr %frame.active, align 1
  %10544 = load <8 x i32>, ptr %frame.static.id, align 32
  %10545 = extractelement <8 x i32> %10544, i32 %10539
  %10546 = select i1 %10532, i32 37, i32 %10545
  %10547 = load <8 x i32>, ptr %frame.static.id, align 32
  %10548 = insertelement <8 x i32> %10547, i32 %10546, i32 %10539
  store <8 x i32> %10548, ptr %frame.static.id, align 32
  %10549 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10550 = extractelement <8 x i32> %10549, i32 %10539
  %10551 = select i1 %10532, i32 %10517, i32 %10550
  %10552 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10553 = insertelement <8 x i32> %10552, i32 %10551, i32 %10539
  store <8 x i32> %10553, ptr %frame.parent.token, align 32
  %10554 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10539
  %10555 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10539
  %10556 = load <8 x i1>, ptr %10554, align 1
  %10557 = load <8 x i1>, ptr %10555, align 1
  %10558 = select i1 %10532, <8 x i1> %2645, <8 x i1> %10556
  store <8 x i1> %10558, ptr %10554, align 1
  %10559 = select i1 %10532, <8 x i1> zeroinitializer, <8 x i1> %10557
  store <8 x i1> %10559, ptr %10555, align 1
  %10560 = add i32 %10539, 1
  %10561 = select i1 %10530, i32 %10517, i32 %10560
  %10562 = select i1 true, i32 %10561, i32 %10517
  store i32 %10562, ptr %current.token, align 4
  %10563 = load i32, ptr %current.token, align 4
  %10564 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2652)
  %10565 = load i32, ptr %ready.count, align 4
  %10566 = icmp uge i32 %10565, 8
  %10567 = and i1 %10564, %10566
  br i1 %10567, label %ready.overflow.trap2218, label %ready.overflow.resume2219

ready.overflow.trap2218:                          ; preds = %convergence.overflow.resume2217
  call void @llvm.trap()
  unreachable

ready.overflow.resume2219:                        ; preds = %convergence.overflow.resume2217
  %10568 = select i1 %10564, i32 %10565, i32 0
  %10569 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10568
  %10570 = load <8 x i1>, ptr %10569, align 1
  %10571 = select i1 %10564, <8 x i1> %2652, <8 x i1> %10570
  store <8 x i1> %10571, ptr %10569, align 1
  %10572 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10568
  %10573 = load i32, ptr %10572, align 4
  %10574 = select i1 %10564, i32 110, i32 %10573
  store i32 %10574, ptr %10572, align 4
  %10575 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10568
  %10576 = load i32, ptr %10575, align 4
  %10577 = select i1 %10564, i32 %10563, i32 %10576
  store i32 %10577, ptr %10575, align 4
  %10578 = add i32 %10565, 1
  %10579 = select i1 %10564, i32 %10578, i32 %10565
  store i32 %10579, ptr %ready.count, align 4
  %10580 = load <8 x i1>, ptr %runnable.mask, align 1
  %10581 = or <8 x i1> %10580, %2652
  store <8 x i1> %10581, ptr %runnable.mask, align 1
  store <8 x i1> %2654, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2220:                        ; preds = %varying.coherent2215
  store <8 x i1> %2645, ptr %current.mask, align 1
  %10582 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2645)
  br i1 %10582, label %schedule.110, label %scheduler.loop

varying.coherent.false2221:                       ; preds = %varying.coherent2215
  store <8 x i1> %2645, ptr %current.mask, align 1
  %10583 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2645)
  br i1 %10583, label %schedule.113, label %scheduler.loop

varying.divergent2229:                            ; preds = %schedule.110
  %10584 = load i32, ptr %current.token, align 4
  %10585 = icmp ne i32 %10584, 0
  %10586 = sub i32 %10584, 1
  %10587 = select i1 %10585, i32 %10586, i32 0
  %10588 = load i8, ptr %frame.active, align 1
  %10589 = trunc i32 %10587 to i8
  %10590 = shl i8 1, %10589
  %10591 = and i8 %10588, %10590
  %10592 = icmp ne i8 %10591, 0
  %10593 = load <8 x i32>, ptr %frame.static.id, align 32
  %10594 = extractelement <8 x i32> %10593, i32 %10587
  %10595 = icmp eq i32 %10594, 38
  %10596 = and i1 %10592, %10595
  %10597 = and i1 %10585, %10596
  %10598 = xor i1 %10597, true
  %10599 = and i1 true, %10598
  %10600 = xor i8 %10588, -1
  %10601 = icmp ne i8 %10600, 0
  %10602 = xor i1 %10601, true
  %10603 = and i1 %10599, %10602
  br i1 %10603, label %convergence.overflow.trap2231, label %convergence.overflow.resume2232

varying.coherent2230:                             ; preds = %schedule.110
  br i1 %2716, label %varying.coherent.true2235, label %varying.coherent.false2236

convergence.overflow.trap2231:                    ; preds = %varying.divergent2229
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2232:                  ; preds = %varying.divergent2229
  %10604 = call i8 @llvm.cttz.i8(i8 %10600, i1 false)
  %10605 = zext i8 %10604 to i32
  %10606 = select i1 %10601, i32 %10605, i32 0
  %10607 = trunc i32 %10606 to i8
  %10608 = shl i8 1, %10607
  %10609 = or i8 %10588, %10608
  %10610 = select i1 %10599, i8 %10609, i8 %10588
  store i8 %10610, ptr %frame.active, align 1
  %10611 = load <8 x i32>, ptr %frame.static.id, align 32
  %10612 = extractelement <8 x i32> %10611, i32 %10606
  %10613 = select i1 %10599, i32 38, i32 %10612
  %10614 = load <8 x i32>, ptr %frame.static.id, align 32
  %10615 = insertelement <8 x i32> %10614, i32 %10613, i32 %10606
  store <8 x i32> %10615, ptr %frame.static.id, align 32
  %10616 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10617 = extractelement <8 x i32> %10616, i32 %10606
  %10618 = select i1 %10599, i32 %10584, i32 %10617
  %10619 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10620 = insertelement <8 x i32> %10619, i32 %10618, i32 %10606
  store <8 x i32> %10620, ptr %frame.parent.token, align 32
  %10621 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10606
  %10622 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10606
  %10623 = load <8 x i1>, ptr %10621, align 1
  %10624 = load <8 x i1>, ptr %10622, align 1
  %10625 = select i1 %10599, <8 x i1> %2658, <8 x i1> %10623
  store <8 x i1> %10625, ptr %10621, align 1
  %10626 = select i1 %10599, <8 x i1> zeroinitializer, <8 x i1> %10624
  store <8 x i1> %10626, ptr %10622, align 1
  %10627 = add i32 %10606, 1
  %10628 = select i1 %10597, i32 %10584, i32 %10627
  %10629 = select i1 true, i32 %10628, i32 %10584
  store i32 %10629, ptr %current.token, align 4
  %10630 = load i32, ptr %current.token, align 4
  %10631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2713)
  %10632 = load i32, ptr %ready.count, align 4
  %10633 = icmp uge i32 %10632, 8
  %10634 = and i1 %10631, %10633
  br i1 %10634, label %ready.overflow.trap2233, label %ready.overflow.resume2234

ready.overflow.trap2233:                          ; preds = %convergence.overflow.resume2232
  call void @llvm.trap()
  unreachable

ready.overflow.resume2234:                        ; preds = %convergence.overflow.resume2232
  %10635 = select i1 %10631, i32 %10632, i32 0
  %10636 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10635
  %10637 = load <8 x i1>, ptr %10636, align 1
  %10638 = select i1 %10631, <8 x i1> %2713, <8 x i1> %10637
  store <8 x i1> %10638, ptr %10636, align 1
  %10639 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10635
  %10640 = load i32, ptr %10639, align 4
  %10641 = select i1 %10631, i32 111, i32 %10640
  store i32 %10641, ptr %10639, align 4
  %10642 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10635
  %10643 = load i32, ptr %10642, align 4
  %10644 = select i1 %10631, i32 %10630, i32 %10643
  store i32 %10644, ptr %10642, align 4
  %10645 = add i32 %10632, 1
  %10646 = select i1 %10631, i32 %10645, i32 %10632
  store i32 %10646, ptr %ready.count, align 4
  %10647 = load <8 x i1>, ptr %runnable.mask, align 1
  %10648 = or <8 x i1> %10647, %2713
  store <8 x i1> %10648, ptr %runnable.mask, align 1
  store <8 x i1> %2715, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2235:                        ; preds = %varying.coherent2230
  store <8 x i1> %2658, ptr %current.mask, align 1
  %10649 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2658)
  br i1 %10649, label %schedule.111, label %scheduler.loop

varying.coherent.false2236:                       ; preds = %varying.coherent2230
  store <8 x i1> %2658, ptr %current.mask, align 1
  %10650 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2658)
  br i1 %10650, label %schedule.112, label %scheduler.loop

convergence.cascade2239:                          ; preds = %convergence.cascade2239, %schedule.112
  %convergence.cascade.flow2243 = phi <8 x i1> [ %2729, %schedule.112 ], [ %10693, %convergence.cascade2239 ]
  %convergence.cascade.depth2244 = phi i32 [ 0, %schedule.112 ], [ %10694, %convergence.cascade2239 ]
  %10651 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2243)
  %10652 = load i32, ptr %current.token, align 4
  %10653 = icmp ne i32 %10652, 0
  %10654 = and i1 %10651, %10653
  %10655 = sub i32 %10652, 1
  %10656 = select i1 %10654, i32 %10655, i32 0
  %10657 = load i8, ptr %frame.active, align 1
  %10658 = trunc i32 %10656 to i8
  %10659 = shl i8 1, %10658
  %10660 = and i8 %10657, %10659
  %10661 = icmp ne i8 %10660, 0
  %10662 = load <8 x i32>, ptr %frame.static.id, align 32
  %10663 = extractelement <8 x i32> %10662, i32 %10656
  %convergence.target.pointer2245 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10663
  %convergence.dynamic.target2246 = load i32, ptr %convergence.target.pointer2245, align 4
  %10664 = icmp eq i32 %convergence.dynamic.target2246, 112
  %10665 = and i1 %10661, %10664
  %10666 = and i1 %10654, %10665
  %10667 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10656
  %10668 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10656
  %10669 = load <8 x i1>, ptr %10667, align 1
  %10670 = load <8 x i1>, ptr %10668, align 1
  %10671 = or <8 x i1> %10670, %convergence.cascade.flow2243
  %10672 = load <8 x i1>, ptr %live.mask, align 1
  %10673 = and <8 x i1> %10669, %10672
  %10674 = icmp eq <8 x i1> %10671, %10673
  %10675 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10674)
  %10676 = and i1 %10666, %10675
  %10677 = select i1 %10676, <8 x i1> zeroinitializer, <8 x i1> %10671
  %10678 = select i1 %10666, <8 x i1> %10677, <8 x i1> %10670
  store <8 x i1> %10678, ptr %10668, align 1
  %10679 = select i1 %10676, <8 x i1> zeroinitializer, <8 x i1> %10669
  store <8 x i1> %10679, ptr %10667, align 1
  %10680 = trunc i32 %10656 to i8
  %10681 = shl i8 1, %10680
  %10682 = xor i8 %10681, -1
  %10683 = and i8 %10657, %10682
  %10684 = select i1 %10676, i8 %10683, i8 %10657
  store i8 %10684, ptr %frame.active, align 1
  %.splatinsert2247 = insertelement <8 x i1> poison, i1 %10666, i64 0
  %.splat2248 = shufflevector <8 x i1> %.splatinsert2247, <8 x i1> poison, <8 x i32> zeroinitializer
  %10685 = and <8 x i1> %convergence.cascade.flow2243, %.splat2248
  %10686 = load <8 x i1>, ptr %runnable.mask, align 1
  %10687 = xor <8 x i1> %10685, splat (i1 true)
  %10688 = and <8 x i1> %10686, %10687
  store <8 x i1> %10688, ptr %runnable.mask, align 1
  %.splatinsert2249 = insertelement <8 x i1> poison, i1 %10676, i64 0
  %.splat2250 = shufflevector <8 x i1> %.splatinsert2249, <8 x i1> poison, <8 x i32> zeroinitializer
  %10689 = select <8 x i1> %.splat2250, <8 x i1> %10671, <8 x i1> zeroinitializer
  %10690 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10691 = extractelement <8 x i32> %10690, i32 %10656
  %10692 = select i1 %10676, i32 %10691, i32 %10652
  store i32 %10692, ptr %current.token, align 4
  %.splatinsert2251 = insertelement <8 x i1> poison, i1 %10666, i64 0
  %.splat2252 = shufflevector <8 x i1> %.splatinsert2251, <8 x i1> poison, <8 x i32> zeroinitializer
  %10693 = select <8 x i1> %.splat2252, <8 x i1> %10689, <8 x i1> %convergence.cascade.flow2243
  %10694 = add i32 %convergence.cascade.depth2244, 1
  %10695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10693)
  %10696 = icmp ult i32 %10694, 8
  %10697 = and i1 %10695, %10696
  %10698 = and i1 %10666, %10697
  %convergence.parent.token2253 = load i32, ptr %current.token, align 4
  %convergence.parent.present2254 = icmp ne i32 %convergence.parent.token2253, 0
  %10699 = and i1 %10698, %convergence.parent.present2254
  br i1 %10699, label %convergence.cascade2239, label %convergence.cascade.exit2240

convergence.cascade.exit2240:                     ; preds = %convergence.cascade2239, %schedule.112
  %convergence.cascade.result2255 = phi <8 x i1> [ %2729, %schedule.112 ], [ %10693, %convergence.cascade2239 ]
  %10700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2255)
  br i1 %10700, label %convergence.target.112.ready, label %scheduler.loop

convergence.target.112.ready:                     ; preds = %convergence.cascade.exit2240
  %10701 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2255)
  %10702 = bitcast <8 x i1> %convergence.cascade.result2255 to i8
  %10703 = call i8 @llvm.cttz.i8(i8 %10702, i1 false)
  %10704 = zext i8 %10703 to i32
  %10705 = select i1 %10701, i32 %10704, i32 0
  %.state2256 = load <8 x i64>, ptr %.slot, align 64
  %10706 = add <8 x i64> %.state2256, splat (i64 1)
  %10707 = load <8 x i64>, ptr %.slot, align 64
  %10708 = select <8 x i1> %convergence.cascade.result2255, <8 x i64> %10706, <8 x i64> %10707
  store <8 x i64> %10708, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result2255, ptr %current.mask, align 1
  %10709 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2255)
  br i1 %10709, label %schedule.109, label %scheduler.loop

convergence.cascade2257:                          ; preds = %convergence.cascade2257, %schedule.113
  %convergence.cascade.flow2261 = phi <8 x i1> [ %2730, %schedule.113 ], [ %10752, %convergence.cascade2257 ]
  %convergence.cascade.depth2262 = phi i32 [ 0, %schedule.113 ], [ %10753, %convergence.cascade2257 ]
  %10710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2261)
  %10711 = load i32, ptr %current.token, align 4
  %10712 = icmp ne i32 %10711, 0
  %10713 = and i1 %10710, %10712
  %10714 = sub i32 %10711, 1
  %10715 = select i1 %10713, i32 %10714, i32 0
  %10716 = load i8, ptr %frame.active, align 1
  %10717 = trunc i32 %10715 to i8
  %10718 = shl i8 1, %10717
  %10719 = and i8 %10716, %10718
  %10720 = icmp ne i8 %10719, 0
  %10721 = load <8 x i32>, ptr %frame.static.id, align 32
  %10722 = extractelement <8 x i32> %10721, i32 %10715
  %convergence.target.pointer2263 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10722
  %convergence.dynamic.target2264 = load i32, ptr %convergence.target.pointer2263, align 4
  %10723 = icmp eq i32 %convergence.dynamic.target2264, 113
  %10724 = and i1 %10720, %10723
  %10725 = and i1 %10713, %10724
  %10726 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10715
  %10727 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10715
  %10728 = load <8 x i1>, ptr %10726, align 1
  %10729 = load <8 x i1>, ptr %10727, align 1
  %10730 = or <8 x i1> %10729, %convergence.cascade.flow2261
  %10731 = load <8 x i1>, ptr %live.mask, align 1
  %10732 = and <8 x i1> %10728, %10731
  %10733 = icmp eq <8 x i1> %10730, %10732
  %10734 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10733)
  %10735 = and i1 %10725, %10734
  %10736 = select i1 %10735, <8 x i1> zeroinitializer, <8 x i1> %10730
  %10737 = select i1 %10725, <8 x i1> %10736, <8 x i1> %10729
  store <8 x i1> %10737, ptr %10727, align 1
  %10738 = select i1 %10735, <8 x i1> zeroinitializer, <8 x i1> %10728
  store <8 x i1> %10738, ptr %10726, align 1
  %10739 = trunc i32 %10715 to i8
  %10740 = shl i8 1, %10739
  %10741 = xor i8 %10740, -1
  %10742 = and i8 %10716, %10741
  %10743 = select i1 %10735, i8 %10742, i8 %10716
  store i8 %10743, ptr %frame.active, align 1
  %.splatinsert2265 = insertelement <8 x i1> poison, i1 %10725, i64 0
  %.splat2266 = shufflevector <8 x i1> %.splatinsert2265, <8 x i1> poison, <8 x i32> zeroinitializer
  %10744 = and <8 x i1> %convergence.cascade.flow2261, %.splat2266
  %10745 = load <8 x i1>, ptr %runnable.mask, align 1
  %10746 = xor <8 x i1> %10744, splat (i1 true)
  %10747 = and <8 x i1> %10745, %10746
  store <8 x i1> %10747, ptr %runnable.mask, align 1
  %.splatinsert2267 = insertelement <8 x i1> poison, i1 %10735, i64 0
  %.splat2268 = shufflevector <8 x i1> %.splatinsert2267, <8 x i1> poison, <8 x i32> zeroinitializer
  %10748 = select <8 x i1> %.splat2268, <8 x i1> %10730, <8 x i1> zeroinitializer
  %10749 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10750 = extractelement <8 x i32> %10749, i32 %10715
  %10751 = select i1 %10735, i32 %10750, i32 %10711
  store i32 %10751, ptr %current.token, align 4
  %.splatinsert2269 = insertelement <8 x i1> poison, i1 %10725, i64 0
  %.splat2270 = shufflevector <8 x i1> %.splatinsert2269, <8 x i1> poison, <8 x i32> zeroinitializer
  %10752 = select <8 x i1> %.splat2270, <8 x i1> %10748, <8 x i1> %convergence.cascade.flow2261
  %10753 = add i32 %convergence.cascade.depth2262, 1
  %10754 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10752)
  %10755 = icmp ult i32 %10753, 8
  %10756 = and i1 %10754, %10755
  %10757 = and i1 %10725, %10756
  %convergence.parent.token2271 = load i32, ptr %current.token, align 4
  %convergence.parent.present2272 = icmp ne i32 %convergence.parent.token2271, 0
  %10758 = and i1 %10757, %convergence.parent.present2272
  br i1 %10758, label %convergence.cascade2257, label %convergence.cascade.exit2258

convergence.cascade.exit2258:                     ; preds = %convergence.cascade2257, %schedule.113
  %convergence.cascade.result2273 = phi <8 x i1> [ %2730, %schedule.113 ], [ %10752, %convergence.cascade2257 ]
  %10759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2273)
  br i1 %10759, label %convergence.target.113.ready, label %scheduler.loop

convergence.target.113.ready:                     ; preds = %convergence.cascade.exit2258
  %10760 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2273)
  %10761 = bitcast <8 x i1> %convergence.cascade.result2273 to i8
  %10762 = call i8 @llvm.cttz.i8(i8 %10761, i1 false)
  %10763 = zext i8 %10762 to i32
  %10764 = select i1 %10760, i32 %10763, i32 0
  %10765 = load <8 x i1>, ptr %live.mask, align 1
  %10766 = xor <8 x i1> %convergence.cascade.result2273, splat (i1 true)
  %10767 = and <8 x i1> %10765, %10766
  store <8 x i1> %10767, ptr %live.mask, align 1
  %10768 = load <8 x i1>, ptr %runnable.mask, align 1
  %10769 = xor <8 x i1> %convergence.cascade.result2273, splat (i1 true)
  %10770 = and <8 x i1> %10768, %10769
  store <8 x i1> %10770, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.113.ready
  %10771 = load i8, ptr %frame.active, align 1
  %10772 = and i8 %10771, 1
  %10773 = icmp ne i8 %10772, 0
  %10774 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %10775 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %10776 = load <8 x i1>, ptr %10774, align 1
  %10777 = load <8 x i1>, ptr %10775, align 1
  %10778 = and <8 x i1> %10776, %10767
  %10779 = icmp eq <8 x i1> %10777, %10778
  %10780 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10779)
  %10781 = and i1 %10773, %10780
  %.splatinsert2274 = insertelement <8 x i1> poison, i1 %10781, i64 0
  %.splat2275 = shufflevector <8 x i1> %.splatinsert2274, <8 x i1> poison, <8 x i32> zeroinitializer
  %10782 = select <8 x i1> %.splat2275, <8 x i1> %10777, <8 x i1> zeroinitializer
  %10783 = select i1 %10781, <8 x i1> zeroinitializer, <8 x i1> %10778
  store <8 x i1> %10783, ptr %10774, align 1
  %10784 = select i1 %10781, <8 x i1> zeroinitializer, <8 x i1> %10777
  store <8 x i1> %10784, ptr %10775, align 1
  %10785 = and i8 %10771, -2
  %10786 = select i1 %10781, i8 %10785, i8 %10771
  store i8 %10786, ptr %frame.active, align 1
  %10787 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10788 = extractelement <8 x i32> %10787, i32 0
  %10789 = load <8 x i32>, ptr %frame.static.id, align 32
  %10790 = extractelement <8 x i32> %10789, i32 0
  %convergence.target.pointer2276 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10790
  %convergence.dynamic.target2277 = load i32, ptr %convergence.target.pointer2276, align 4
  %10791 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10782)
  %10792 = load i32, ptr %ready.count, align 4
  %10793 = icmp uge i32 %10792, 8
  %10794 = and i1 %10791, %10793
  br i1 %10794, label %ready.overflow.trap2278, label %ready.overflow.resume2279

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume2321, %convergence.target.113.ready
  br label %scheduler.loop

ready.overflow.trap2278:                          ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume2279:                        ; preds = %return.frame.cleanup
  %10795 = select i1 %10791, i32 %10792, i32 0
  %10796 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10795
  %10797 = load <8 x i1>, ptr %10796, align 1
  %10798 = select i1 %10791, <8 x i1> %10782, <8 x i1> %10797
  store <8 x i1> %10798, ptr %10796, align 1
  %10799 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10795
  %10800 = load i32, ptr %10799, align 4
  %10801 = select i1 %10791, i32 %convergence.dynamic.target2277, i32 %10800
  store i32 %10801, ptr %10799, align 4
  %10802 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10795
  %10803 = load i32, ptr %10802, align 4
  %10804 = select i1 %10791, i32 %10788, i32 %10803
  store i32 %10804, ptr %10802, align 4
  %10805 = add i32 %10792, 1
  %10806 = select i1 %10791, i32 %10805, i32 %10792
  store i32 %10806, ptr %ready.count, align 4
  %10807 = load <8 x i1>, ptr %runnable.mask, align 1
  %10808 = or <8 x i1> %10807, %10782
  store <8 x i1> %10808, ptr %runnable.mask, align 1
  %10809 = load i8, ptr %frame.active, align 1
  %10810 = and i8 %10809, 2
  %10811 = icmp ne i8 %10810, 0
  %10812 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %10813 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %10814 = load <8 x i1>, ptr %10812, align 1
  %10815 = load <8 x i1>, ptr %10813, align 1
  %10816 = and <8 x i1> %10814, %10767
  %10817 = icmp eq <8 x i1> %10815, %10816
  %10818 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10817)
  %10819 = and i1 %10811, %10818
  %.splatinsert2280 = insertelement <8 x i1> poison, i1 %10819, i64 0
  %.splat2281 = shufflevector <8 x i1> %.splatinsert2280, <8 x i1> poison, <8 x i32> zeroinitializer
  %10820 = select <8 x i1> %.splat2281, <8 x i1> %10815, <8 x i1> zeroinitializer
  %10821 = select i1 %10819, <8 x i1> zeroinitializer, <8 x i1> %10816
  store <8 x i1> %10821, ptr %10812, align 1
  %10822 = select i1 %10819, <8 x i1> zeroinitializer, <8 x i1> %10815
  store <8 x i1> %10822, ptr %10813, align 1
  %10823 = and i8 %10809, -3
  %10824 = select i1 %10819, i8 %10823, i8 %10809
  store i8 %10824, ptr %frame.active, align 1
  %10825 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10826 = extractelement <8 x i32> %10825, i32 1
  %10827 = load <8 x i32>, ptr %frame.static.id, align 32
  %10828 = extractelement <8 x i32> %10827, i32 1
  %convergence.target.pointer2282 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10828
  %convergence.dynamic.target2283 = load i32, ptr %convergence.target.pointer2282, align 4
  %10829 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10820)
  %10830 = load i32, ptr %ready.count, align 4
  %10831 = icmp uge i32 %10830, 8
  %10832 = and i1 %10829, %10831
  br i1 %10832, label %ready.overflow.trap2284, label %ready.overflow.resume2285

ready.overflow.trap2284:                          ; preds = %ready.overflow.resume2279
  call void @llvm.trap()
  unreachable

ready.overflow.resume2285:                        ; preds = %ready.overflow.resume2279
  %10833 = select i1 %10829, i32 %10830, i32 0
  %10834 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10833
  %10835 = load <8 x i1>, ptr %10834, align 1
  %10836 = select i1 %10829, <8 x i1> %10820, <8 x i1> %10835
  store <8 x i1> %10836, ptr %10834, align 1
  %10837 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10833
  %10838 = load i32, ptr %10837, align 4
  %10839 = select i1 %10829, i32 %convergence.dynamic.target2283, i32 %10838
  store i32 %10839, ptr %10837, align 4
  %10840 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10833
  %10841 = load i32, ptr %10840, align 4
  %10842 = select i1 %10829, i32 %10826, i32 %10841
  store i32 %10842, ptr %10840, align 4
  %10843 = add i32 %10830, 1
  %10844 = select i1 %10829, i32 %10843, i32 %10830
  store i32 %10844, ptr %ready.count, align 4
  %10845 = load <8 x i1>, ptr %runnable.mask, align 1
  %10846 = or <8 x i1> %10845, %10820
  store <8 x i1> %10846, ptr %runnable.mask, align 1
  %10847 = load i8, ptr %frame.active, align 1
  %10848 = and i8 %10847, 4
  %10849 = icmp ne i8 %10848, 0
  %10850 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %10851 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %10852 = load <8 x i1>, ptr %10850, align 1
  %10853 = load <8 x i1>, ptr %10851, align 1
  %10854 = and <8 x i1> %10852, %10767
  %10855 = icmp eq <8 x i1> %10853, %10854
  %10856 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10855)
  %10857 = and i1 %10849, %10856
  %.splatinsert2286 = insertelement <8 x i1> poison, i1 %10857, i64 0
  %.splat2287 = shufflevector <8 x i1> %.splatinsert2286, <8 x i1> poison, <8 x i32> zeroinitializer
  %10858 = select <8 x i1> %.splat2287, <8 x i1> %10853, <8 x i1> zeroinitializer
  %10859 = select i1 %10857, <8 x i1> zeroinitializer, <8 x i1> %10854
  store <8 x i1> %10859, ptr %10850, align 1
  %10860 = select i1 %10857, <8 x i1> zeroinitializer, <8 x i1> %10853
  store <8 x i1> %10860, ptr %10851, align 1
  %10861 = and i8 %10847, -5
  %10862 = select i1 %10857, i8 %10861, i8 %10847
  store i8 %10862, ptr %frame.active, align 1
  %10863 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10864 = extractelement <8 x i32> %10863, i32 2
  %10865 = load <8 x i32>, ptr %frame.static.id, align 32
  %10866 = extractelement <8 x i32> %10865, i32 2
  %convergence.target.pointer2288 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10866
  %convergence.dynamic.target2289 = load i32, ptr %convergence.target.pointer2288, align 4
  %10867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10858)
  %10868 = load i32, ptr %ready.count, align 4
  %10869 = icmp uge i32 %10868, 8
  %10870 = and i1 %10867, %10869
  br i1 %10870, label %ready.overflow.trap2290, label %ready.overflow.resume2291

ready.overflow.trap2290:                          ; preds = %ready.overflow.resume2285
  call void @llvm.trap()
  unreachable

ready.overflow.resume2291:                        ; preds = %ready.overflow.resume2285
  %10871 = select i1 %10867, i32 %10868, i32 0
  %10872 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10871
  %10873 = load <8 x i1>, ptr %10872, align 1
  %10874 = select i1 %10867, <8 x i1> %10858, <8 x i1> %10873
  store <8 x i1> %10874, ptr %10872, align 1
  %10875 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10871
  %10876 = load i32, ptr %10875, align 4
  %10877 = select i1 %10867, i32 %convergence.dynamic.target2289, i32 %10876
  store i32 %10877, ptr %10875, align 4
  %10878 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10871
  %10879 = load i32, ptr %10878, align 4
  %10880 = select i1 %10867, i32 %10864, i32 %10879
  store i32 %10880, ptr %10878, align 4
  %10881 = add i32 %10868, 1
  %10882 = select i1 %10867, i32 %10881, i32 %10868
  store i32 %10882, ptr %ready.count, align 4
  %10883 = load <8 x i1>, ptr %runnable.mask, align 1
  %10884 = or <8 x i1> %10883, %10858
  store <8 x i1> %10884, ptr %runnable.mask, align 1
  %10885 = load i8, ptr %frame.active, align 1
  %10886 = and i8 %10885, 8
  %10887 = icmp ne i8 %10886, 0
  %10888 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %10889 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %10890 = load <8 x i1>, ptr %10888, align 1
  %10891 = load <8 x i1>, ptr %10889, align 1
  %10892 = and <8 x i1> %10890, %10767
  %10893 = icmp eq <8 x i1> %10891, %10892
  %10894 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10893)
  %10895 = and i1 %10887, %10894
  %.splatinsert2292 = insertelement <8 x i1> poison, i1 %10895, i64 0
  %.splat2293 = shufflevector <8 x i1> %.splatinsert2292, <8 x i1> poison, <8 x i32> zeroinitializer
  %10896 = select <8 x i1> %.splat2293, <8 x i1> %10891, <8 x i1> zeroinitializer
  %10897 = select i1 %10895, <8 x i1> zeroinitializer, <8 x i1> %10892
  store <8 x i1> %10897, ptr %10888, align 1
  %10898 = select i1 %10895, <8 x i1> zeroinitializer, <8 x i1> %10891
  store <8 x i1> %10898, ptr %10889, align 1
  %10899 = and i8 %10885, -9
  %10900 = select i1 %10895, i8 %10899, i8 %10885
  store i8 %10900, ptr %frame.active, align 1
  %10901 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10902 = extractelement <8 x i32> %10901, i32 3
  %10903 = load <8 x i32>, ptr %frame.static.id, align 32
  %10904 = extractelement <8 x i32> %10903, i32 3
  %convergence.target.pointer2294 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10904
  %convergence.dynamic.target2295 = load i32, ptr %convergence.target.pointer2294, align 4
  %10905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10896)
  %10906 = load i32, ptr %ready.count, align 4
  %10907 = icmp uge i32 %10906, 8
  %10908 = and i1 %10905, %10907
  br i1 %10908, label %ready.overflow.trap2296, label %ready.overflow.resume2297

ready.overflow.trap2296:                          ; preds = %ready.overflow.resume2291
  call void @llvm.trap()
  unreachable

ready.overflow.resume2297:                        ; preds = %ready.overflow.resume2291
  %10909 = select i1 %10905, i32 %10906, i32 0
  %10910 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10909
  %10911 = load <8 x i1>, ptr %10910, align 1
  %10912 = select i1 %10905, <8 x i1> %10896, <8 x i1> %10911
  store <8 x i1> %10912, ptr %10910, align 1
  %10913 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10909
  %10914 = load i32, ptr %10913, align 4
  %10915 = select i1 %10905, i32 %convergence.dynamic.target2295, i32 %10914
  store i32 %10915, ptr %10913, align 4
  %10916 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10909
  %10917 = load i32, ptr %10916, align 4
  %10918 = select i1 %10905, i32 %10902, i32 %10917
  store i32 %10918, ptr %10916, align 4
  %10919 = add i32 %10906, 1
  %10920 = select i1 %10905, i32 %10919, i32 %10906
  store i32 %10920, ptr %ready.count, align 4
  %10921 = load <8 x i1>, ptr %runnable.mask, align 1
  %10922 = or <8 x i1> %10921, %10896
  store <8 x i1> %10922, ptr %runnable.mask, align 1
  %10923 = load i8, ptr %frame.active, align 1
  %10924 = and i8 %10923, 16
  %10925 = icmp ne i8 %10924, 0
  %10926 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %10927 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %10928 = load <8 x i1>, ptr %10926, align 1
  %10929 = load <8 x i1>, ptr %10927, align 1
  %10930 = and <8 x i1> %10928, %10767
  %10931 = icmp eq <8 x i1> %10929, %10930
  %10932 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10931)
  %10933 = and i1 %10925, %10932
  %.splatinsert2298 = insertelement <8 x i1> poison, i1 %10933, i64 0
  %.splat2299 = shufflevector <8 x i1> %.splatinsert2298, <8 x i1> poison, <8 x i32> zeroinitializer
  %10934 = select <8 x i1> %.splat2299, <8 x i1> %10929, <8 x i1> zeroinitializer
  %10935 = select i1 %10933, <8 x i1> zeroinitializer, <8 x i1> %10930
  store <8 x i1> %10935, ptr %10926, align 1
  %10936 = select i1 %10933, <8 x i1> zeroinitializer, <8 x i1> %10929
  store <8 x i1> %10936, ptr %10927, align 1
  %10937 = and i8 %10923, -17
  %10938 = select i1 %10933, i8 %10937, i8 %10923
  store i8 %10938, ptr %frame.active, align 1
  %10939 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10940 = extractelement <8 x i32> %10939, i32 4
  %10941 = load <8 x i32>, ptr %frame.static.id, align 32
  %10942 = extractelement <8 x i32> %10941, i32 4
  %convergence.target.pointer2300 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10942
  %convergence.dynamic.target2301 = load i32, ptr %convergence.target.pointer2300, align 4
  %10943 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10934)
  %10944 = load i32, ptr %ready.count, align 4
  %10945 = icmp uge i32 %10944, 8
  %10946 = and i1 %10943, %10945
  br i1 %10946, label %ready.overflow.trap2302, label %ready.overflow.resume2303

ready.overflow.trap2302:                          ; preds = %ready.overflow.resume2297
  call void @llvm.trap()
  unreachable

ready.overflow.resume2303:                        ; preds = %ready.overflow.resume2297
  %10947 = select i1 %10943, i32 %10944, i32 0
  %10948 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10947
  %10949 = load <8 x i1>, ptr %10948, align 1
  %10950 = select i1 %10943, <8 x i1> %10934, <8 x i1> %10949
  store <8 x i1> %10950, ptr %10948, align 1
  %10951 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10947
  %10952 = load i32, ptr %10951, align 4
  %10953 = select i1 %10943, i32 %convergence.dynamic.target2301, i32 %10952
  store i32 %10953, ptr %10951, align 4
  %10954 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10947
  %10955 = load i32, ptr %10954, align 4
  %10956 = select i1 %10943, i32 %10940, i32 %10955
  store i32 %10956, ptr %10954, align 4
  %10957 = add i32 %10944, 1
  %10958 = select i1 %10943, i32 %10957, i32 %10944
  store i32 %10958, ptr %ready.count, align 4
  %10959 = load <8 x i1>, ptr %runnable.mask, align 1
  %10960 = or <8 x i1> %10959, %10934
  store <8 x i1> %10960, ptr %runnable.mask, align 1
  %10961 = load i8, ptr %frame.active, align 1
  %10962 = and i8 %10961, 32
  %10963 = icmp ne i8 %10962, 0
  %10964 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %10965 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %10966 = load <8 x i1>, ptr %10964, align 1
  %10967 = load <8 x i1>, ptr %10965, align 1
  %10968 = and <8 x i1> %10966, %10767
  %10969 = icmp eq <8 x i1> %10967, %10968
  %10970 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10969)
  %10971 = and i1 %10963, %10970
  %.splatinsert2304 = insertelement <8 x i1> poison, i1 %10971, i64 0
  %.splat2305 = shufflevector <8 x i1> %.splatinsert2304, <8 x i1> poison, <8 x i32> zeroinitializer
  %10972 = select <8 x i1> %.splat2305, <8 x i1> %10967, <8 x i1> zeroinitializer
  %10973 = select i1 %10971, <8 x i1> zeroinitializer, <8 x i1> %10968
  store <8 x i1> %10973, ptr %10964, align 1
  %10974 = select i1 %10971, <8 x i1> zeroinitializer, <8 x i1> %10967
  store <8 x i1> %10974, ptr %10965, align 1
  %10975 = and i8 %10961, -33
  %10976 = select i1 %10971, i8 %10975, i8 %10961
  store i8 %10976, ptr %frame.active, align 1
  %10977 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10978 = extractelement <8 x i32> %10977, i32 5
  %10979 = load <8 x i32>, ptr %frame.static.id, align 32
  %10980 = extractelement <8 x i32> %10979, i32 5
  %convergence.target.pointer2306 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10980
  %convergence.dynamic.target2307 = load i32, ptr %convergence.target.pointer2306, align 4
  %10981 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10972)
  %10982 = load i32, ptr %ready.count, align 4
  %10983 = icmp uge i32 %10982, 8
  %10984 = and i1 %10981, %10983
  br i1 %10984, label %ready.overflow.trap2308, label %ready.overflow.resume2309

ready.overflow.trap2308:                          ; preds = %ready.overflow.resume2303
  call void @llvm.trap()
  unreachable

ready.overflow.resume2309:                        ; preds = %ready.overflow.resume2303
  %10985 = select i1 %10981, i32 %10982, i32 0
  %10986 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10985
  %10987 = load <8 x i1>, ptr %10986, align 1
  %10988 = select i1 %10981, <8 x i1> %10972, <8 x i1> %10987
  store <8 x i1> %10988, ptr %10986, align 1
  %10989 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10985
  %10990 = load i32, ptr %10989, align 4
  %10991 = select i1 %10981, i32 %convergence.dynamic.target2307, i32 %10990
  store i32 %10991, ptr %10989, align 4
  %10992 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10985
  %10993 = load i32, ptr %10992, align 4
  %10994 = select i1 %10981, i32 %10978, i32 %10993
  store i32 %10994, ptr %10992, align 4
  %10995 = add i32 %10982, 1
  %10996 = select i1 %10981, i32 %10995, i32 %10982
  store i32 %10996, ptr %ready.count, align 4
  %10997 = load <8 x i1>, ptr %runnable.mask, align 1
  %10998 = or <8 x i1> %10997, %10972
  store <8 x i1> %10998, ptr %runnable.mask, align 1
  %10999 = load i8, ptr %frame.active, align 1
  %11000 = and i8 %10999, 64
  %11001 = icmp ne i8 %11000, 0
  %11002 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %11003 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %11004 = load <8 x i1>, ptr %11002, align 1
  %11005 = load <8 x i1>, ptr %11003, align 1
  %11006 = and <8 x i1> %11004, %10767
  %11007 = icmp eq <8 x i1> %11005, %11006
  %11008 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %11007)
  %11009 = and i1 %11001, %11008
  %.splatinsert2310 = insertelement <8 x i1> poison, i1 %11009, i64 0
  %.splat2311 = shufflevector <8 x i1> %.splatinsert2310, <8 x i1> poison, <8 x i32> zeroinitializer
  %11010 = select <8 x i1> %.splat2311, <8 x i1> %11005, <8 x i1> zeroinitializer
  %11011 = select i1 %11009, <8 x i1> zeroinitializer, <8 x i1> %11006
  store <8 x i1> %11011, ptr %11002, align 1
  %11012 = select i1 %11009, <8 x i1> zeroinitializer, <8 x i1> %11005
  store <8 x i1> %11012, ptr %11003, align 1
  %11013 = and i8 %10999, -65
  %11014 = select i1 %11009, i8 %11013, i8 %10999
  store i8 %11014, ptr %frame.active, align 1
  %11015 = load <8 x i32>, ptr %frame.parent.token, align 32
  %11016 = extractelement <8 x i32> %11015, i32 6
  %11017 = load <8 x i32>, ptr %frame.static.id, align 32
  %11018 = extractelement <8 x i32> %11017, i32 6
  %convergence.target.pointer2312 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %11018
  %convergence.dynamic.target2313 = load i32, ptr %convergence.target.pointer2312, align 4
  %11019 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %11010)
  %11020 = load i32, ptr %ready.count, align 4
  %11021 = icmp uge i32 %11020, 8
  %11022 = and i1 %11019, %11021
  br i1 %11022, label %ready.overflow.trap2314, label %ready.overflow.resume2315

ready.overflow.trap2314:                          ; preds = %ready.overflow.resume2309
  call void @llvm.trap()
  unreachable

ready.overflow.resume2315:                        ; preds = %ready.overflow.resume2309
  %11023 = select i1 %11019, i32 %11020, i32 0
  %11024 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %11023
  %11025 = load <8 x i1>, ptr %11024, align 1
  %11026 = select i1 %11019, <8 x i1> %11010, <8 x i1> %11025
  store <8 x i1> %11026, ptr %11024, align 1
  %11027 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %11023
  %11028 = load i32, ptr %11027, align 4
  %11029 = select i1 %11019, i32 %convergence.dynamic.target2313, i32 %11028
  store i32 %11029, ptr %11027, align 4
  %11030 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %11023
  %11031 = load i32, ptr %11030, align 4
  %11032 = select i1 %11019, i32 %11016, i32 %11031
  store i32 %11032, ptr %11030, align 4
  %11033 = add i32 %11020, 1
  %11034 = select i1 %11019, i32 %11033, i32 %11020
  store i32 %11034, ptr %ready.count, align 4
  %11035 = load <8 x i1>, ptr %runnable.mask, align 1
  %11036 = or <8 x i1> %11035, %11010
  store <8 x i1> %11036, ptr %runnable.mask, align 1
  %11037 = load i8, ptr %frame.active, align 1
  %11038 = and i8 %11037, -128
  %11039 = icmp ne i8 %11038, 0
  %11040 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %11041 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %11042 = load <8 x i1>, ptr %11040, align 1
  %11043 = load <8 x i1>, ptr %11041, align 1
  %11044 = and <8 x i1> %11042, %10767
  %11045 = icmp eq <8 x i1> %11043, %11044
  %11046 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %11045)
  %11047 = and i1 %11039, %11046
  %.splatinsert2316 = insertelement <8 x i1> poison, i1 %11047, i64 0
  %.splat2317 = shufflevector <8 x i1> %.splatinsert2316, <8 x i1> poison, <8 x i32> zeroinitializer
  %11048 = select <8 x i1> %.splat2317, <8 x i1> %11043, <8 x i1> zeroinitializer
  %11049 = select i1 %11047, <8 x i1> zeroinitializer, <8 x i1> %11044
  store <8 x i1> %11049, ptr %11040, align 1
  %11050 = select i1 %11047, <8 x i1> zeroinitializer, <8 x i1> %11043
  store <8 x i1> %11050, ptr %11041, align 1
  %11051 = and i8 %11037, 127
  %11052 = select i1 %11047, i8 %11051, i8 %11037
  store i8 %11052, ptr %frame.active, align 1
  %11053 = load <8 x i32>, ptr %frame.parent.token, align 32
  %11054 = extractelement <8 x i32> %11053, i32 7
  %11055 = load <8 x i32>, ptr %frame.static.id, align 32
  %11056 = extractelement <8 x i32> %11055, i32 7
  %convergence.target.pointer2318 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %11056
  %convergence.dynamic.target2319 = load i32, ptr %convergence.target.pointer2318, align 4
  %11057 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %11048)
  %11058 = load i32, ptr %ready.count, align 4
  %11059 = icmp uge i32 %11058, 8
  %11060 = and i1 %11057, %11059
  br i1 %11060, label %ready.overflow.trap2320, label %ready.overflow.resume2321

ready.overflow.trap2320:                          ; preds = %ready.overflow.resume2315
  call void @llvm.trap()
  unreachable

ready.overflow.resume2321:                        ; preds = %ready.overflow.resume2315
  %11061 = select i1 %11057, i32 %11058, i32 0
  %11062 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %11061
  %11063 = load <8 x i1>, ptr %11062, align 1
  %11064 = select i1 %11057, <8 x i1> %11048, <8 x i1> %11063
  store <8 x i1> %11064, ptr %11062, align 1
  %11065 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %11061
  %11066 = load i32, ptr %11065, align 4
  %11067 = select i1 %11057, i32 %convergence.dynamic.target2319, i32 %11066
  store i32 %11067, ptr %11065, align 4
  %11068 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %11061
  %11069 = load i32, ptr %11068, align 4
  %11070 = select i1 %11057, i32 %11054, i32 %11069
  store i32 %11070, ptr %11068, align 4
  %11071 = add i32 %11058, 1
  %11072 = select i1 %11057, i32 %11071, i32 %11058
  store i32 %11072, ptr %ready.count, align 4
  %11073 = load <8 x i1>, ptr %runnable.mask, align 1
  %11074 = or <8 x i1> %11073, %11048
  store <8 x i1> %11074, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #4

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

define dso_local void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

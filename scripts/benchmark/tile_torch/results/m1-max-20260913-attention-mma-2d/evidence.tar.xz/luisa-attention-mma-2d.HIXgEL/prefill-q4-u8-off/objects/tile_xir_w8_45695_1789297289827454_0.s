	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	dup.4s	v18, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q19, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q20, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v18, v20
	cmhi.4s	v1, v18, v19
	uzp1.8h	v25, v1, v0
	umaxv.8h	h2, v25
	fmov	w8, s2
	tbnz	w8, #0, LBB0_1
	b	LBB0_100
LBB0_1:                                 ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #16, lsl #12            ; =65536
	sub	sp, sp, #2320
	mov	x8, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #2192
	ldr	x12, [x0]
	ldr	x2, [x0, #16]
	ldr	w11, [x1]
	ldr	w13, [x1, #36]
	add	w11, w13, w11, lsl #5
	ldr	x1, [x0, #32]
	ldr	x15, [x0, #48]
	sshll.2d	v4, v1, #0
	sshll.2d	v5, v0, #0
	sshll2.2d	v28, v1, #0
	sshll2.2d	v26, v0, #0
	dup.4s	v2, w11
	add.4s	v3, v2, v20
	add.4s	v2, v2, v19
	and.16b	v2, v1, v2
	and.16b	v3, v0, v3
	ushll2.2d	v6, v3, #0
	ushll2.2d	v7, v2, #0
	ushll.2d	v16, v3, #0
	ushll.2d	v17, v2, #0
	ushll.2d	v21, v2, #2
	ushll.2d	v22, v3, #2
	ushll2.2d	v23, v2, #2
	ushll2.2d	v2, v3, #2
	mov	w11, #28                        ; =0x1c
	dup.2d	v24, x11
	str	q26, [sp, #14304]               ; 16-byte Spill
	and.16b	v27, v2, v26
	and.16b	v2, v27, v24
	str	q28, [sp, #14320]               ; 16-byte Spill
	and.16b	v28, v23, v28
	and.16b	v3, v28, v24
	and.16b	v29, v22, v5
	and.16b	v5, v29, v24
	and.16b	v30, v21, v4
	and.16b	v4, v30, v24
Lloh4:
	adrp	x11, lCPI0_2@PAGE
Lloh5:
	ldr	q21, [x11, lCPI0_2@PAGEOFF]
	str	q25, [sp, #448]                 ; 16-byte Spill
	and.16b	v21, v25, v21
	addv.8h	h21, v21
	str	q21, [sp, #16]                  ; 16-byte Spill
	fmov	w11, s21
	dup.2d	v21, x12
	add	x12, sp, #15, lsl #12           ; =61440
	add	x12, x12, #2320
	b	LBB0_3
LBB0_2:                                 ; %else419
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x12, x10, lsl #5
	ldp	q24, q25, [x13]
	bif.16b	v23, v25, v0
	bif.16b	v22, v24, v1
	stp	q22, q23, [x13]
	add	x10, x10, #1
	add	x8, x8, #4
	cmp	x8, #512
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	lsr	x13, x10, #5
	dup.2d	v24, x13
	add.2d	v22, v24, v30
	shl.2d	v22, v22, #7
	and	x13, x8, #0x7c
	dup.2d	v25, x13
	orr.16b	v22, v22, v25
	add.2d	v26, v21, v22
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbz	w11, #0, LBB0_11
; %bb.4:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x13, d26
	ldr	s22, [x13]
	and	w13, w11, #0xff
	tbnz	w13, #1, LBB0_12
LBB0_5:                                 ; %else401
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v26, v24, v28
	shl.2d	v26, v26, #7
	orr.16b	v26, v26, v25
	add.2d	v26, v21, v26
	tbz	w13, #2, LBB0_13
LBB0_6:                                 ; %cond.load403
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x14, d26
	ld1.s	{ v22 }[2], [x14]
	tbnz	w13, #3, LBB0_14
LBB0_7:                                 ; %else407
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v26, v24, v29
	shl.2d	v26, v26, #7
	orr.16b	v26, v26, v25
	add.2d	v26, v21, v26
	tbz	w13, #4, LBB0_15
LBB0_8:                                 ; %cond.load409
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x14, d26
	ld1.s	{ v23 }[0], [x14]
	tbnz	w13, #5, LBB0_16
LBB0_9:                                 ; %else413
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v24, v24, v27
	shl.2d	v24, v24, #7
	orr.16b	v24, v24, v25
	add.2d	v24, v21, v24
	tbz	w13, #6, LBB0_17
LBB0_10:                                ; %cond.load415
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x14, d24
	ld1.s	{ v23 }[2], [x14]
	tbz	w13, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w13, w11, #0xff
	tbz	w13, #1, LBB0_5
LBB0_12:                                ; %cond.load400
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x14, v26[1]
	ld1.s	{ v22 }[1], [x14]
	add.2d	v26, v24, v28
	shl.2d	v26, v26, #7
	orr.16b	v26, v26, v25
	add.2d	v26, v21, v26
	tbnz	w13, #2, LBB0_6
LBB0_13:                                ; %else404
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w13, #3, LBB0_7
LBB0_14:                                ; %cond.load406
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x14, v26[1]
	ld1.s	{ v22 }[3], [x14]
	add.2d	v26, v24, v29
	shl.2d	v26, v26, #7
	orr.16b	v26, v26, v25
	add.2d	v26, v21, v26
	tbnz	w13, #4, LBB0_8
LBB0_15:                                ; %else410
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w13, #5, LBB0_9
LBB0_16:                                ; %cond.load412
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x14, v26[1]
	ld1.s	{ v23 }[1], [x14]
	add.2d	v24, v24, v27
	shl.2d	v24, v24, #7
	orr.16b	v24, v24, v25
	add.2d	v24, v21, v24
	tbnz	w13, #6, LBB0_10
LBB0_17:                                ; %else416
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w13, #7, LBB0_2
LBB0_18:                                ; %cond.load418
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x13, v24[1]
	ld1.s	{ v23 }[3], [x13]
	b	LBB0_2
LBB0_19:                                ; %direct.true333.preheader
	stp	q30, q29, [sp, #32]             ; 32-byte Folded Spill
	stp	q28, q27, [sp, #64]             ; 32-byte Folded Spill
	str	x15, [sp, #104]                 ; 8-byte Spill
	mov	x8, #0                          ; =0x0
	add	x10, sp, #14, lsl #12           ; =57344
	add	x10, x10, #2320
	cmhs.4s	v20, v20, v18
	cmhs.4s	v18, v19, v18
LBB0_20:                                ; %direct.true333
                                        ; =>This Inner Loop Header: Depth=1
	add	x11, x10, x8
	ldp	q19, q21, [x11]
	and.16b	v21, v20, v21
	and.16b	v19, v18, v19
	stp	q19, q21, [x11]
	add	x8, x8, #32
	cmp	x8, #1, lsl #12                 ; =4096
	b.ne	LBB0_20
; %bb.21:                               ; %direct.false334
	sshll.2d	v18, v1, #0
	mov	x11, #0                         ; =0x0
	sshll.2d	v19, v0, #0
	ushr.2d	v17, v17, #4
	ushr.2d	v7, v7, #4
	ushr.2d	v16, v16, #4
	ushr.2d	v6, v6, #4
Lloh6:
	adrp	x8, lCPI0_6@PAGE
Lloh7:
	ldr	q20, [x8, lCPI0_6@PAGEOFF]
	str	q20, [sp, #8496]                ; 16-byte Spill
	and.16b	v20, v18, v20
	str	q20, [sp, #13936]               ; 16-byte Spill
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v22, w8
	and.16b	v23, v1, v22
	mov.d	x8, v6[1]
	fmov	x10, d6
	add	x10, x10, x10, lsl #6
	fmov	d6, x10
	add	x8, x8, x8, lsl #6
	mov.d	v6[1], x8
	mov.d	x8, v16[1]
	fmov	x10, d16
	add	x10, x10, x10, lsl #6
	fmov	d16, x10
	add	x8, x8, x8, lsl #6
	mov.d	v16[1], x8
	mov.d	x8, v7[1]
	fmov	x10, d7
	add	x10, x10, x10, lsl #6
	fmov	d7, x10
	add	x8, x8, x8, lsl #6
	mov.d	v7[1], x8
	mov.d	x8, v17[1]
	fmov	x10, d17
	add	x10, x10, x10, lsl #6
	fmov	d17, x10
	add	x8, x8, x8, lsl #6
	mov.d	v17[1], x8
	and.16b	v20, v18, v17
	ldr	q17, [sp, #14320]               ; 16-byte Reload
	and.16b	v7, v17, v7
	str	q7, [sp, #14288]                ; 16-byte Spill
	and.16b	v7, v19, v16
	str	q7, [sp, #14272]                ; 16-byte Spill
	ldr	q7, [sp, #14304]                ; 16-byte Reload
	and.16b	v6, v7, v6
	stp	q6, q20, [sp, #384]             ; 32-byte Folded Spill
	mov	w8, #33                         ; =0x21
	dup.2d	v6, x8
	orr.16b	v7, v5, v6
	orr.16b	v16, v3, v6
	stp	q16, q7, [sp, #352]             ; 32-byte Folded Spill
	orr.16b	v16, v4, v6
	orr.16b	v6, v2, v6
	stp	q6, q16, [sp, #320]             ; 32-byte Folded Spill
	mov	w8, #34                         ; =0x22
	dup.2d	v6, x8
	orr.16b	v7, v5, v6
	orr.16b	v16, v3, v6
	stp	q16, q7, [sp, #288]             ; 32-byte Folded Spill
	orr.16b	v16, v4, v6
	orr.16b	v6, v2, v6
	stp	q6, q16, [sp, #256]             ; 32-byte Folded Spill
	mov	w8, #35                         ; =0x23
	dup.2d	v6, x8
	orr.16b	v7, v5, v6
	str	q7, [sp, #240]                  ; 16-byte Spill
	orr.16b	v7, v3, v6
	str	q7, [sp, #224]                  ; 16-byte Spill
	orr.16b	v7, v4, v6
	orr.16b	v6, v2, v6
	stp	q6, q7, [sp, #192]              ; 32-byte Folded Spill
	mov	w8, #36                         ; =0x24
	dup.2d	v6, x8
	add.2d	v5, v5, v6
	add.2d	v3, v3, v6
	stp	q3, q5, [sp, #160]              ; 32-byte Folded Spill
	add.2d	v3, v4, v6
	add.2d	v2, v2, v6
	stp	q2, q3, [sp, #128]              ; 32-byte Folded Spill
	mvni.4s	v2, #63, msl #16
	add	x13, sp, #9, lsl #12            ; =36864
	add	x13, x13, #2320
	fneg.4s	v2, v2
	str	q2, [sp, #112]                  ; 16-byte Spill
	add	x14, sp, #15, lsl #12           ; =61440
	add	x14, x14, #2320
	add	x15, x14, #1024
	add	x16, x14, #2048
	add	x17, x14, #3072
	add	x0, sp, #5, lsl #12             ; =20480
	add	x0, x0, #272
	add	x4, sp, #5, lsl #12             ; =20480
	add	x4, x4, #2320
Lloh8:
	adrp	x8, lCPI0_3@PAGE
Lloh9:
	ldr	q2, [x8, lCPI0_3@PAGEOFF]
	str	q2, [sp, #8480]                 ; 16-byte Spill
Lloh10:
	adrp	x8, lCPI0_4@PAGE
Lloh11:
	ldr	q2, [x8, lCPI0_4@PAGEOFF]
	str	q2, [sp, #8464]                 ; 16-byte Spill
Lloh12:
	adrp	x8, lCPI0_5@PAGE
Lloh13:
	ldr	q2, [x8, lCPI0_5@PAGEOFF]
	str	q2, [sp, #8448]                 ; 16-byte Spill
	add	x7, sp, #14, lsl #12            ; =57344
	add	x7, x7, #2320
	add	x19, sp, #5, lsl #12            ; =20480
	add	x19, x19, #144
	mov	w20, #29                        ; =0x1d
	add	x21, sp, #3, lsl #12            ; =12288
	add	x21, x21, #2192
	add	x22, sp, #13, lsl #12           ; =53248
	add	x22, x22, #2320
	movi.2d	v21, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #8432]                 ; 16-byte Spill
	str	q2, [sp, #8416]                 ; 16-byte Spill
	str	q2, [sp, #8400]                 ; 16-byte Spill
	str	q2, [sp, #8384]                 ; 16-byte Spill
	str	q2, [sp, #13808]                ; 16-byte Spill
	str	q2, [sp, #13792]                ; 16-byte Spill
	str	q2, [sp, #13776]                ; 16-byte Spill
	str	q2, [sp, #8368]                 ; 16-byte Spill
	str	q2, [sp, #8352]                 ; 16-byte Spill
	str	q2, [sp, #8336]                 ; 16-byte Spill
	str	q2, [sp, #8320]                 ; 16-byte Spill
	str	q2, [sp, #8304]                 ; 16-byte Spill
	str	q2, [sp, #13760]                ; 16-byte Spill
	str	q2, [sp, #13744]                ; 16-byte Spill
	str	q2, [sp, #13728]                ; 16-byte Spill
	str	q2, [sp, #13712]                ; 16-byte Spill
	str	q2, [sp, #13696]                ; 16-byte Spill
	str	q2, [sp, #13680]                ; 16-byte Spill
	str	q2, [sp, #8288]                 ; 16-byte Spill
	str	q2, [sp, #8272]                 ; 16-byte Spill
	str	q2, [sp, #13664]                ; 16-byte Spill
	str	q2, [sp, #13648]                ; 16-byte Spill
	str	q2, [sp, #13632]                ; 16-byte Spill
	str	q2, [sp, #8256]                 ; 16-byte Spill
	str	q2, [sp, #13616]                ; 16-byte Spill
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
                                        ; implicit-def: $q2
                                        ; kill: killed $q2
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #13600]                ; 16-byte Spill
	str	q2, [sp, #13584]                ; 16-byte Spill
	str	q2, [sp, #8240]                 ; 16-byte Spill
	str	q2, [sp, #13568]                ; 16-byte Spill
	str	q2, [sp, #13552]                ; 16-byte Spill
	str	q2, [sp, #13536]                ; 16-byte Spill
	str	q2, [sp, #8224]                 ; 16-byte Spill
	str	q2, [sp, #13520]                ; 16-byte Spill
	str	q2, [sp, #13504]                ; 16-byte Spill
	str	q2, [sp, #13488]                ; 16-byte Spill
	str	q2, [sp, #8208]                 ; 16-byte Spill
	str	q2, [sp, #13472]                ; 16-byte Spill
	str	q2, [sp, #13456]                ; 16-byte Spill
	str	q2, [sp, #13440]                ; 16-byte Spill
	str	q2, [sp, #8192]                 ; 16-byte Spill
	str	q2, [sp, #13424]                ; 16-byte Spill
	str	q2, [sp, #13408]                ; 16-byte Spill
	str	q2, [sp, #13392]                ; 16-byte Spill
	str	q2, [sp, #8176]                 ; 16-byte Spill
	str	q2, [sp, #13376]                ; 16-byte Spill
	str	q2, [sp, #13360]                ; 16-byte Spill
	str	q2, [sp, #13344]                ; 16-byte Spill
	str	q2, [sp, #8160]                 ; 16-byte Spill
	str	q2, [sp, #13328]                ; 16-byte Spill
	str	q2, [sp, #13312]                ; 16-byte Spill
	str	q2, [sp, #13296]                ; 16-byte Spill
	str	q2, [sp, #8144]                 ; 16-byte Spill
	str	q2, [sp, #13280]                ; 16-byte Spill
	str	q2, [sp, #13264]                ; 16-byte Spill
	str	q2, [sp, #13248]                ; 16-byte Spill
	str	q2, [sp, #8128]                 ; 16-byte Spill
	str	q2, [sp, #13232]                ; 16-byte Spill
	str	q2, [sp, #13216]                ; 16-byte Spill
	str	q2, [sp, #13200]                ; 16-byte Spill
	str	q2, [sp, #8112]                 ; 16-byte Spill
	str	q2, [sp, #13184]                ; 16-byte Spill
	str	q2, [sp, #13168]                ; 16-byte Spill
	str	q2, [sp, #13152]                ; 16-byte Spill
	str	q2, [sp, #8096]                 ; 16-byte Spill
	str	q2, [sp, #13136]                ; 16-byte Spill
	str	q2, [sp, #13120]                ; 16-byte Spill
	str	q2, [sp, #13104]                ; 16-byte Spill
	str	q2, [sp, #8080]                 ; 16-byte Spill
	str	q2, [sp, #13088]                ; 16-byte Spill
	str	q2, [sp, #13072]                ; 16-byte Spill
	str	q2, [sp, #8064]                 ; 16-byte Spill
	str	q2, [sp, #8048]                 ; 16-byte Spill
	str	q2, [sp, #13056]                ; 16-byte Spill
	str	q2, [sp, #13040]                ; 16-byte Spill
	str	q2, [sp, #8032]                 ; 16-byte Spill
	str	q2, [sp, #8016]                 ; 16-byte Spill
	str	q2, [sp, #13024]                ; 16-byte Spill
	str	q2, [sp, #13008]                ; 16-byte Spill
	str	q2, [sp, #8000]                 ; 16-byte Spill
	str	q2, [sp, #7984]                 ; 16-byte Spill
	str	q2, [sp, #12976]                ; 16-byte Spill
	str	q2, [sp, #12992]                ; 16-byte Spill
	str	q2, [sp, #12960]                ; 16-byte Spill
	str	q2, [sp, #12944]                ; 16-byte Spill
	str	q2, [sp, #12928]                ; 16-byte Spill
	movi.2d	v18, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v5, #0000000000000000
	str	q2, [sp, #12912]                ; 16-byte Spill
	str	q2, [sp, #12896]                ; 16-byte Spill
	str	q2, [sp, #12880]                ; 16-byte Spill
	str	q2, [sp, #12864]                ; 16-byte Spill
	str	q2, [sp, #12848]                ; 16-byte Spill
	str	q2, [sp, #12832]                ; 16-byte Spill
	str	q2, [sp, #12816]                ; 16-byte Spill
	str	q2, [sp, #12800]                ; 16-byte Spill
	str	q2, [sp, #12784]                ; 16-byte Spill
	str	q2, [sp, #12768]                ; 16-byte Spill
	str	q2, [sp, #12752]                ; 16-byte Spill
	str	q2, [sp, #12736]                ; 16-byte Spill
	str	q2, [sp, #12720]                ; 16-byte Spill
	str	q2, [sp, #12704]                ; 16-byte Spill
	str	q2, [sp, #12688]                ; 16-byte Spill
	str	q2, [sp, #12672]                ; 16-byte Spill
	str	q2, [sp, #12656]                ; 16-byte Spill
	str	q2, [sp, #12640]                ; 16-byte Spill
	str	q2, [sp, #12624]                ; 16-byte Spill
	str	q2, [sp, #12608]                ; 16-byte Spill
	str	q2, [sp, #12592]                ; 16-byte Spill
	str	q2, [sp, #12576]                ; 16-byte Spill
	str	q2, [sp, #12560]                ; 16-byte Spill
	str	q2, [sp, #12544]                ; 16-byte Spill
	str	q2, [sp, #12528]                ; 16-byte Spill
	str	q2, [sp, #12512]                ; 16-byte Spill
	str	q2, [sp, #12496]                ; 16-byte Spill
	str	q2, [sp, #12480]                ; 16-byte Spill
	str	q2, [sp, #12464]                ; 16-byte Spill
	str	q2, [sp, #12448]                ; 16-byte Spill
	str	q2, [sp, #12432]                ; 16-byte Spill
	str	q2, [sp, #12416]                ; 16-byte Spill
	str	q2, [sp, #12400]                ; 16-byte Spill
	str	q2, [sp, #12384]                ; 16-byte Spill
	str	q2, [sp, #12368]                ; 16-byte Spill
	str	q2, [sp, #12352]                ; 16-byte Spill
	str	q2, [sp, #12336]                ; 16-byte Spill
	str	q2, [sp, #12320]                ; 16-byte Spill
	str	q2, [sp, #12304]                ; 16-byte Spill
	str	q2, [sp, #12288]                ; 16-byte Spill
	str	q2, [sp, #12272]                ; 16-byte Spill
	str	q2, [sp, #12256]                ; 16-byte Spill
	str	q2, [sp, #12240]                ; 16-byte Spill
	str	q2, [sp, #12224]                ; 16-byte Spill
	str	q2, [sp, #12208]                ; 16-byte Spill
	str	q2, [sp, #12192]                ; 16-byte Spill
	str	q2, [sp, #12176]                ; 16-byte Spill
	movi.2d	v12, #0000000000000000
	str	q2, [sp, #12160]                ; 16-byte Spill
	str	q2, [sp, #12144]                ; 16-byte Spill
	str	q2, [sp, #12128]                ; 16-byte Spill
	str	q2, [sp, #12112]                ; 16-byte Spill
	str	q2, [sp, #12096]                ; 16-byte Spill
	str	q2, [sp, #12080]                ; 16-byte Spill
	str	q2, [sp, #12064]                ; 16-byte Spill
	str	q2, [sp, #12048]                ; 16-byte Spill
	str	q2, [sp, #12032]                ; 16-byte Spill
	str	q2, [sp, #12016]                ; 16-byte Spill
	str	q2, [sp, #12000]                ; 16-byte Spill
	str	q2, [sp, #11984]                ; 16-byte Spill
	str	q2, [sp, #11968]                ; 16-byte Spill
	str	q2, [sp, #11952]                ; 16-byte Spill
	str	q2, [sp, #11936]                ; 16-byte Spill
	str	q2, [sp, #11920]                ; 16-byte Spill
	str	q2, [sp, #11904]                ; 16-byte Spill
	str	q2, [sp, #11888]                ; 16-byte Spill
	str	q2, [sp, #11872]                ; 16-byte Spill
	str	q2, [sp, #11856]                ; 16-byte Spill
	str	q2, [sp, #11840]                ; 16-byte Spill
	str	q2, [sp, #11824]                ; 16-byte Spill
	str	q2, [sp, #11808]                ; 16-byte Spill
	str	q2, [sp, #11792]                ; 16-byte Spill
	str	q2, [sp, #11776]                ; 16-byte Spill
	str	q2, [sp, #11760]                ; 16-byte Spill
	str	q2, [sp, #11744]                ; 16-byte Spill
	str	q2, [sp, #11728]                ; 16-byte Spill
	str	q2, [sp, #11712]                ; 16-byte Spill
	str	q2, [sp, #11696]                ; 16-byte Spill
	str	q2, [sp, #11680]                ; 16-byte Spill
	str	q2, [sp, #11664]                ; 16-byte Spill
	str	q2, [sp, #11648]                ; 16-byte Spill
	str	q2, [sp, #11632]                ; 16-byte Spill
	str	q2, [sp, #11616]                ; 16-byte Spill
	str	q2, [sp, #11600]                ; 16-byte Spill
	str	q2, [sp, #11584]                ; 16-byte Spill
	str	q2, [sp, #11568]                ; 16-byte Spill
	str	q2, [sp, #11552]                ; 16-byte Spill
	str	q2, [sp, #11536]                ; 16-byte Spill
	str	q2, [sp, #11520]                ; 16-byte Spill
	str	q2, [sp, #11504]                ; 16-byte Spill
	str	q2, [sp, #11488]                ; 16-byte Spill
	str	q2, [sp, #11472]                ; 16-byte Spill
	str	q2, [sp, #11456]                ; 16-byte Spill
	str	q2, [sp, #11440]                ; 16-byte Spill
	str	q2, [sp, #11424]                ; 16-byte Spill
	str	q2, [sp, #11408]                ; 16-byte Spill
	str	q2, [sp, #11392]                ; 16-byte Spill
	str	q2, [sp, #11376]                ; 16-byte Spill
	str	q2, [sp, #11360]                ; 16-byte Spill
	str	q2, [sp, #11344]                ; 16-byte Spill
	str	q2, [sp, #11328]                ; 16-byte Spill
	str	q2, [sp, #11312]                ; 16-byte Spill
	str	q2, [sp, #11296]                ; 16-byte Spill
	str	q2, [sp, #11280]                ; 16-byte Spill
	str	q2, [sp, #11264]                ; 16-byte Spill
	str	q2, [sp, #11248]                ; 16-byte Spill
	str	q2, [sp, #11232]                ; 16-byte Spill
	str	q2, [sp, #11216]                ; 16-byte Spill
	str	q2, [sp, #11200]                ; 16-byte Spill
	str	q2, [sp, #11184]                ; 16-byte Spill
	str	q2, [sp, #11168]                ; 16-byte Spill
	str	q2, [sp, #11152]                ; 16-byte Spill
	str	q2, [sp, #11136]                ; 16-byte Spill
	str	q2, [sp, #11120]                ; 16-byte Spill
	str	q2, [sp, #11104]                ; 16-byte Spill
	str	q2, [sp, #11088]                ; 16-byte Spill
	str	q2, [sp, #11072]                ; 16-byte Spill
	str	q2, [sp, #11056]                ; 16-byte Spill
	movi.2d	v11, #0000000000000000
	str	q2, [sp, #7968]                 ; 16-byte Spill
	str	q2, [sp, #7952]                 ; 16-byte Spill
	str	q2, [sp, #7936]                 ; 16-byte Spill
	str	q2, [sp, #7920]                 ; 16-byte Spill
	str	q2, [sp, #7904]                 ; 16-byte Spill
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	str	q2, [sp, #7888]                 ; 16-byte Spill
	str	q2, [sp, #7872]                 ; 16-byte Spill
	str	q2, [sp, #7856]                 ; 16-byte Spill
	str	q2, [sp, #7840]                 ; 16-byte Spill
	str	q2, [sp, #7824]                 ; 16-byte Spill
	str	q2, [sp, #7808]                 ; 16-byte Spill
	str	q2, [sp, #7792]                 ; 16-byte Spill
	str	q2, [sp, #7776]                 ; 16-byte Spill
	str	q2, [sp, #7760]                 ; 16-byte Spill
	str	q2, [sp, #13920]                ; 16-byte Spill
	movi.2d	v14, #0000000000000000
	str	q2, [sp, #14256]                ; 16-byte Spill
	str	q2, [sp, #14240]                ; 16-byte Spill
	str	q2, [sp, #14224]                ; 16-byte Spill
	str	q2, [sp, #14208]                ; 16-byte Spill
	str	q2, [sp, #14192]                ; 16-byte Spill
	str	q2, [sp, #11040]                ; 16-byte Spill
	str	q2, [sp, #11024]                ; 16-byte Spill
	str	q23, [sp, #11008]               ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	movi.2d	v19, #0000000000000000
	str	q2, [sp, #14176]                ; 16-byte Spill
	str	q22, [sp, #416]                 ; 16-byte Spill
	and.16b	v2, v0, v22
	str	q2, [sp, #10976]                ; 16-byte Spill
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
                                        ; implicit-def: $q3
                                        ; kill: killed $q3
	str	q23, [sp, #10960]               ; 16-byte Spill
	str	q2, [sp, #10944]                ; 16-byte Spill
	str	q23, [sp, #13824]               ; 16-byte Spill
	str	q23, [sp, #10928]               ; 16-byte Spill
	str	q2, [sp, #10992]                ; 16-byte Spill
	str	q2, [sp, #10912]                ; 16-byte Spill
	stp	x1, x2, [sp, #432]              ; 16-byte Folded Spill
LBB0_22:                                ; %direct.true343
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_28 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
                                        ;     Child Loop BB0_37 Depth 2
                                        ;     Child Loop BB0_39 Depth 2
                                        ;     Child Loop BB0_41 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_45 Depth 2
                                        ;     Child Loop BB0_47 Depth 2
                                        ;     Child Loop BB0_49 Depth 2
                                        ;     Child Loop BB0_51 Depth 2
                                        ;     Child Loop BB0_53 Depth 2
                                        ;     Child Loop BB0_55 Depth 2
                                        ;     Child Loop BB0_57 Depth 2
                                        ;     Child Loop BB0_59 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;     Child Loop BB0_65 Depth 2
                                        ;     Child Loop BB0_67 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_71 Depth 2
                                        ;       Child Loop BB0_72 Depth 3
                                        ;         Child Loop BB0_73 Depth 4
                                        ;     Child Loop BB0_77 Depth 2
                                        ;     Child Loop BB0_79 Depth 2
	str	q12, [sp, #13840]               ; 16-byte Spill
	str	q13, [sp, #13872]               ; 16-byte Spill
	str	q18, [sp, #13904]               ; 16-byte Spill
	str	q6, [sp, #13888]                ; 16-byte Spill
	str	q5, [sp, #13856]                ; 16-byte Spill
	mov	x24, #0                         ; =0x0
	lsl	x23, x11, #4
	ldp	q3, q12, [sp, #384]             ; 32-byte Folded Reload
	ldr	q7, [sp, #7824]                 ; 16-byte Reload
	ldr	q20, [sp, #7808]                ; 16-byte Reload
	ldr	q23, [sp, #7792]                ; 16-byte Reload
	ldr	q24, [sp, #7776]                ; 16-byte Reload
	ldr	q25, [sp, #7760]                ; 16-byte Reload
	ldr	q18, [sp, #11984]               ; 16-byte Reload
	b	LBB0_24
LBB0_23:                                ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_24 Depth=2
	sshll.2d	v16, v0, #0
	add.2d	v17, v6, v3
	ldr	q22, [sp, #14288]               ; 16-byte Reload
	add.2d	v22, v6, v22
	ldr	q13, [sp, #14272]               ; 16-byte Reload
	add.2d	v6, v6, v13
	shl.2d	v6, v6, #5
	shl.2d	v22, v22, #5
	shl.2d	v17, v17, #5
	orr.16b	v17, v17, v5
	orr.16b	v22, v22, v5
	orr.16b	v5, v6, v5
	bit.16b	v24, v5, v16
	ldr	q5, [sp, #14320]                ; 16-byte Reload
	bit.16b	v23, v22, v5
	ldr	q5, [sp, #14304]                ; 16-byte Reload
	bit.16b	v25, v17, v5
	bit.16b	v7, v2, v0
	ldr	q5, [sp, #14192]                ; 16-byte Reload
	bit.16b	v5, v2, v1
	str	q5, [sp, #14192]                ; 16-byte Spill
	add	x8, x13, x24, lsl #5
	ldp	q5, q6, [x8]
	bit.16b	v6, v2, v0
	bif.16b	v2, v5, v1
	stp	q2, q6, [x8]
	add	x24, x24, #1
	cmp	x24, #512
	b.eq	LBB0_26
LBB0_24:                                ; %direct.true347
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v1, #0
	and	x8, x24, #0x1f
	orr	x10, x23, x24, lsr #5
	dup.2d	v6, x10
	add.2d	v5, v6, v12
	shl.2d	v16, v5, #5
	dup.2d	v5, x8
	orr.16b	v16, v16, v5
	bit.16b	v20, v16, v2
	movi.2d	v2, #0000000000000000
	cmp	x10, #64
	b.hi	LBB0_23
; %bb.25:                               ; %direct.true357
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x8, d20
	add	x8, x2, x8, lsl #2
	ld1r.4s	{ v2 }, [x8]
	b	LBB0_23
LBB0_26:                                ; %direct.true371.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q25, [sp, #7760]                ; 16-byte Spill
	str	x11, [sp, #7752]                ; 8-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q25, [sp, #11056]               ; 16-byte Reload
	b	LBB0_28
LBB0_27:                                ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_28 Depth=2
	str	q16, [sp, #14256]               ; 16-byte Spill
	sshll.2d	v16, v0, #0
	add.2d	v17, v6, v3
	ldr	q22, [sp, #14288]               ; 16-byte Reload
	add.2d	v22, v6, v22
	ldr	q13, [sp, #14272]               ; 16-byte Reload
	add.2d	v6, v6, v13
	shl.2d	v6, v6, #5
	shl.2d	v22, v22, #5
	shl.2d	v17, v17, #5
	orr.16b	v17, v17, v5
	orr.16b	v22, v22, v5
	orr.16b	v5, v6, v5
	ldr	q6, [sp, #14224]                ; 16-byte Reload
	bit.16b	v6, v5, v16
	str	q6, [sp, #14224]                ; 16-byte Spill
	ldr	q5, [sp, #14240]                ; 16-byte Reload
	ldr	q6, [sp, #14320]                ; 16-byte Reload
	bit.16b	v5, v22, v6
	str	q5, [sp, #14240]                ; 16-byte Spill
	ldr	q5, [sp, #14208]                ; 16-byte Reload
	ldr	q6, [sp, #14304]                ; 16-byte Reload
	bit.16b	v5, v17, v6
	str	q5, [sp, #14208]                ; 16-byte Spill
	ldr	q5, [sp, #14176]                ; 16-byte Reload
	bit.16b	v5, v2, v0
	str	q5, [sp, #14176]                ; 16-byte Spill
	bit.16b	v19, v2, v1
	add	x10, x4, x8, lsl #5
	ldp	q5, q6, [x10]
	bit.16b	v6, v2, v0
	bif.16b	v2, v5, v1
	stp	q2, q6, [x10]
	add	x8, x8, #1
	cmp	x8, #512
	b.eq	LBB0_30
LBB0_28:                                ; %direct.true371
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v1, #0
	and	x10, x8, #0x1f
	orr	x11, x23, x8, lsr #5
	dup.2d	v6, x11
	add.2d	v5, v6, v12
	shl.2d	v16, v5, #5
	dup.2d	v5, x10
	orr.16b	v16, v16, v5
	ldr	q17, [sp, #14256]               ; 16-byte Reload
	bif.16b	v16, v17, v2
	movi.2d	v2, #0000000000000000
	cmp	x11, #65
	b.hs	LBB0_27
; %bb.29:                               ; %direct.true381
                                        ;   in Loop: Header=BB0_28 Depth=2
	fmov	x10, d16
	add	x10, x1, x10, lsl #2
	ld1r.4s	{ v2 }, [x10]
	b	LBB0_27
LBB0_30:                                ; %direct.false372
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #7456]                ; 16-byte Spill
	str	q24, [sp, #7776]                ; 16-byte Spill
	str	q23, [sp, #7792]                ; 16-byte Spill
	str	q20, [sp, #7808]                ; 16-byte Spill
	str	q7, [sp, #7824]                 ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	sshll.2d	v2, v1, #0
	sshll.2d	v5, v0, #0
	ldr	q3, [sp, #7888]                 ; 16-byte Reload
	ldr	q6, [sp, #14304]                ; 16-byte Reload
	ldr	q7, [sp, #8480]                 ; 16-byte Reload
	bit.16b	v3, v7, v6
	str	q3, [sp, #7888]                 ; 16-byte Spill
	ldr	q3, [sp, #8464]                 ; 16-byte Reload
	ldr	q6, [sp, #14320]                ; 16-byte Reload
	bit.16b	v9, v3, v6
	str	q9, [sp, #7488]                 ; 16-byte Spill
	ldr	q3, [sp, #8448]                 ; 16-byte Reload
	bit.16b	v10, v3, v5
	str	q10, [sp, #7472]                ; 16-byte Spill
	ldr	q7, [sp, #13920]                ; 16-byte Reload
	ldr	q3, [sp, #8496]                 ; 16-byte Reload
	bit.16b	v7, v3, v2
	bic.16b	v4, v4, v0
	ldr	q9, [sp, #11024]                ; 16-byte Reload
	bic.16b	v9, v9, v1
	ldr	q20, [sp, #11040]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	bic.16b	v14, v14, v1
	bic.16b	v11, v11, v0
	bic.16b	v25, v25, v1
	ldr	q3, [sp, #11072]                ; 16-byte Reload
	bic.16b	v3, v3, v0
	add	x10, sp, #9, lsl #12            ; =36864
	add	x10, x10, #2320
	ldr	q15, [sp, #11088]               ; 16-byte Reload
	bic.16b	v15, v15, v1
	ldr	q12, [sp, #13936]               ; 16-byte Reload
LBB0_31:                                ; %direct.true395
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d2, x8
	orr.16b	v5, v2, v12
	fmov	x11, d5
	add	x11, x14, x11
	ldp	q6, q5, [x11]
	and.16b	v6, v1, v6
	and.16b	v5, v0, v5
	orr.16b	v2, v2, v7
	fmov	x11, d2
	add	x11, x13, x11
	ldp	q16, q2, [x11]
	and.16b	v16, v1, v16
	and.16b	v2, v0, v2
	fmul.4s	v2, v5, v2
	fmul.4s	v16, v6, v16
	fadd.4s	v16, v9, v16
	fadd.4s	v2, v4, v2
	ldr	q17, [x10, #1040]
	ldr	q22, [x10, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v5, v17
	fmul.4s	v22, v6, v22
	fadd.4s	v22, v14, v22
	fadd.4s	v17, v20, v17
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v5, v23
	fmul.4s	v24, v6, v24
	fadd.4s	v24, v25, v24
	fadd.4s	v23, v11, v23
	mov.16b	v13, v11
	mov.16b	v11, v25
	ldr	q25, [x10, #3088]
	mov.16b	v19, v4
	mov.16b	v4, v9
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v5, v5, v25
	mov.16b	v25, v11
	fmul.4s	v6, v6, v9
	mov.16b	v9, v4
	fadd.4s	v6, v15, v6
	fadd.4s	v5, v3, v5
	mov.16b	v4, v0
	bsl.16b	v4, v2, v19
	bit.16b	v9, v16, v1
	bit.16b	v20, v17, v0
	bit.16b	v14, v22, v1
	mov.16b	v11, v0
	bsl.16b	v11, v23, v13
	bit.16b	v25, v24, v1
	bit.16b	v3, v5, v0
	bit.16b	v15, v6, v1
	add	x10, x10, #32
	add	x8, x8, #32
	cmp	x8, #1024
	b.ne	LBB0_31
; %bb.32:                               ; %direct.false396
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q4, [sp, #10864]                ; 16-byte Spill
	str	q9, [sp, #11024]                ; 16-byte Spill
	str	q20, [sp, #11040]               ; 16-byte Spill
	str	q7, [sp, #13920]                ; 16-byte Spill
	str	q11, [sp, #10896]               ; 16-byte Spill
	str	q25, [sp, #11056]               ; 16-byte Spill
	str	q3, [sp, #11072]                ; 16-byte Spill
	str	q15, [sp, #11088]               ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #11104]               ; 16-byte Reload
	bic.16b	v19, v19, v0
	ldr	q4, [sp, #11120]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q20, [sp, #11136]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q7, [sp, #11152]                ; 16-byte Reload
	bic.16b	v7, v7, v1
	ldr	q13, [sp, #11168]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q12, [sp, #11184]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #11200]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	add	x10, x13, #1, lsl #12           ; =4096
	ldr	q3, [sp, #11216]                ; 16-byte Reload
	bic.16b	v3, v3, v1
	ldr	q15, [sp, #11344]               ; 16-byte Reload
LBB0_33:                                ; %direct.true431
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x14, x8, lsl #5
	ldp	q5, q2, [x11]
	and.16b	v5, v1, v5
	and.16b	v2, v0, v2
	ldp	q16, q6, [x10]
	and.16b	v16, v1, v16
	and.16b	v6, v0, v6
	fmul.4s	v6, v2, v6
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v4, v16
	fadd.4s	v6, v19, v6
	ldr	q17, [x10, #1040]
	ldr	q22, [x10, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v2, v17
	fmul.4s	v22, v5, v22
	fadd.4s	v22, v7, v22
	fadd.4s	v17, v20, v17
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v2, v23
	fmul.4s	v24, v5, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v23, v13, v23
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v5, v5, v9
	fadd.4s	v5, v3, v5
	fadd.4s	v2, v11, v2
	add	x8, x8, #1
	bit.16b	v19, v6, v0
	bit.16b	v4, v16, v1
	bit.16b	v20, v17, v0
	bit.16b	v7, v22, v1
	bit.16b	v13, v23, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v2, v0
	bit.16b	v3, v5, v1
	add	x10, x10, #32
	cmp	x8, #32
	b.ne	LBB0_33
; %bb.34:                               ; %direct.false432
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #11104]               ; 16-byte Spill
	str	q4, [sp, #11120]                ; 16-byte Spill
	str	q20, [sp, #11136]               ; 16-byte Spill
	str	q7, [sp, #11152]                ; 16-byte Spill
	str	q13, [sp, #11168]               ; 16-byte Spill
	str	q12, [sp, #11184]               ; 16-byte Spill
	str	q11, [sp, #11200]               ; 16-byte Spill
	str	q3, [sp, #11216]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #11232]               ; 16-byte Reload
	bic.16b	v19, v19, v0
	ldr	q4, [sp, #11248]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q20, [sp, #11264]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q7, [sp, #11280]                ; 16-byte Reload
	bic.16b	v7, v7, v1
	ldr	q13, [sp, #11296]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q12, [sp, #11312]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #11328]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	add	x10, x13, #2, lsl #12           ; =8192
	bic.16b	v15, v15, v1
	ldr	q3, [sp, #12480]                ; 16-byte Reload
LBB0_35:                                ; %direct.true469
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x14, x8, lsl #5
	ldp	q5, q2, [x11]
	and.16b	v5, v1, v5
	and.16b	v2, v0, v2
	ldp	q16, q6, [x10]
	and.16b	v16, v1, v16
	and.16b	v6, v0, v6
	fmul.4s	v6, v2, v6
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v4, v16
	fadd.4s	v6, v19, v6
	ldr	q17, [x10, #1040]
	ldr	q22, [x10, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v2, v17
	fmul.4s	v22, v5, v22
	fadd.4s	v22, v7, v22
	fadd.4s	v17, v20, v17
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v2, v23
	fmul.4s	v24, v5, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v23, v13, v23
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v5, v5, v9
	fadd.4s	v5, v15, v5
	fadd.4s	v2, v11, v2
	add	x8, x8, #1
	bit.16b	v19, v6, v0
	bit.16b	v4, v16, v1
	bit.16b	v20, v17, v0
	bit.16b	v7, v22, v1
	bit.16b	v13, v23, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v2, v0
	bit.16b	v15, v5, v1
	add	x10, x10, #32
	cmp	x8, #32
	b.ne	LBB0_35
; %bb.36:                               ; %direct.false470
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q14, [sp, #10880]               ; 16-byte Spill
	str	q19, [sp, #11232]               ; 16-byte Spill
	str	q4, [sp, #11248]                ; 16-byte Spill
	str	q20, [sp, #11264]               ; 16-byte Spill
	str	q7, [sp, #11280]                ; 16-byte Spill
	str	q13, [sp, #11296]               ; 16-byte Spill
	str	q12, [sp, #11312]               ; 16-byte Spill
	str	q11, [sp, #11328]               ; 16-byte Spill
	str	q15, [sp, #11344]               ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #11360]               ; 16-byte Reload
	bic.16b	v19, v19, v0
	ldr	q4, [sp, #11376]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q20, [sp, #11392]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q7, [sp, #11408]                ; 16-byte Reload
	bic.16b	v7, v7, v1
	ldr	q13, [sp, #11424]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q12, [sp, #11440]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #11456]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	add	x10, x13, #3, lsl #12           ; =12288
	ldr	q10, [sp, #11472]               ; 16-byte Reload
	bic.16b	v10, v10, v1
LBB0_37:                                ; %direct.true507
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x14, x8, lsl #5
	ldp	q5, q2, [x11]
	and.16b	v5, v1, v5
	and.16b	v2, v0, v2
	ldp	q16, q6, [x10]
	and.16b	v16, v1, v16
	and.16b	v6, v0, v6
	fmul.4s	v6, v2, v6
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v4, v16
	fadd.4s	v6, v19, v6
	ldr	q17, [x10, #1040]
	ldr	q22, [x10, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v2, v17
	fmul.4s	v22, v5, v22
	fadd.4s	v22, v7, v22
	fadd.4s	v17, v20, v17
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v2, v23
	fmul.4s	v24, v5, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v23, v13, v23
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v5, v5, v9
	fadd.4s	v5, v10, v5
	fadd.4s	v2, v11, v2
	add	x8, x8, #1
	bit.16b	v19, v6, v0
	bit.16b	v4, v16, v1
	bit.16b	v20, v17, v0
	bit.16b	v7, v22, v1
	bit.16b	v13, v23, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v2, v0
	bit.16b	v10, v5, v1
	add	x10, x10, #32
	cmp	x8, #32
	b.ne	LBB0_37
; %bb.38:                               ; %direct.false508
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #11360]               ; 16-byte Spill
	str	q4, [sp, #11376]                ; 16-byte Spill
	str	q20, [sp, #11392]               ; 16-byte Spill
	str	q7, [sp, #11408]                ; 16-byte Spill
	str	q13, [sp, #11424]               ; 16-byte Spill
	str	q12, [sp, #11440]               ; 16-byte Spill
	str	q11, [sp, #11456]               ; 16-byte Spill
	str	q10, [sp, #11472]               ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #11488]               ; 16-byte Reload
	bic.16b	v19, v19, v0
	ldr	q4, [sp, #11504]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q20, [sp, #11520]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q7, [sp, #11536]                ; 16-byte Reload
	bic.16b	v7, v7, v1
	ldr	q13, [sp, #11552]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q12, [sp, #11568]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #11584]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	ldr	q10, [sp, #11600]               ; 16-byte Reload
	bic.16b	v10, v10, v1
	ldr	q14, [sp, #13920]               ; 16-byte Reload
	ldr	q15, [sp, #13936]               ; 16-byte Reload
LBB0_39:                                ; %direct.true545
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x10, x8, #0x400
	fmov	d2, x10
	orr.16b	v5, v2, v15
	fmov	x10, d5
	add	x10, x14, x10
	ldp	q6, q5, [x10]
	and.16b	v6, v1, v6
	and.16b	v5, v0, v5
	add	x10, x13, x8
	ldp	q17, q16, [x10]
	and.16b	v17, v1, v17
	and.16b	v16, v0, v16
	fmul.4s	v16, v5, v16
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v4, v17
	fadd.4s	v16, v19, v16
	orr.16b	v2, v2, v14
	fmov	x11, d2
	add	x11, x13, x11
	ldp	q22, q2, [x11]
	and.16b	v22, v1, v22
	and.16b	v2, v0, v2
	fmul.4s	v2, v5, v2
	fmul.4s	v22, v6, v22
	fadd.4s	v22, v7, v22
	fadd.4s	v2, v20, v2
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v5, v23
	fmul.4s	v24, v6, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v23, v13, v23
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v5, v5, v25
	fmul.4s	v6, v6, v9
	fadd.4s	v6, v10, v6
	fadd.4s	v5, v11, v5
	bit.16b	v19, v16, v0
	bit.16b	v4, v17, v1
	bit.16b	v20, v2, v0
	bit.16b	v7, v22, v1
	bit.16b	v13, v23, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v5, v0
	bit.16b	v10, v6, v1
	add	x8, x8, #32
	cmp	x8, #1024
	b.ne	LBB0_39
; %bb.40:                               ; %direct.false546
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #11488]               ; 16-byte Spill
	str	q4, [sp, #11504]                ; 16-byte Spill
	str	q20, [sp, #11520]               ; 16-byte Spill
	str	q7, [sp, #11536]                ; 16-byte Spill
	str	q13, [sp, #11552]               ; 16-byte Spill
	str	q12, [sp, #11568]               ; 16-byte Spill
	str	q11, [sp, #11584]               ; 16-byte Spill
	str	q10, [sp, #11600]               ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #11616]               ; 16-byte Reload
	bic.16b	v19, v19, v0
	ldr	q4, [sp, #11632]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q20, [sp, #11648]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q7, [sp, #11664]                ; 16-byte Reload
	bic.16b	v7, v7, v1
	ldr	q13, [sp, #11680]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q12, [sp, #11696]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #11712]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	add	x10, x13, #1, lsl #12           ; =4096
	ldr	q14, [sp, #11728]               ; 16-byte Reload
	bic.16b	v14, v14, v1
LBB0_41:                                ; %direct.true582
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x15, x8, lsl #5
	ldp	q5, q2, [x11]
	and.16b	v5, v1, v5
	and.16b	v2, v0, v2
	ldp	q16, q6, [x10]
	and.16b	v16, v1, v16
	and.16b	v6, v0, v6
	fmul.4s	v6, v2, v6
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v4, v16
	fadd.4s	v6, v19, v6
	ldr	q17, [x10, #1040]
	ldr	q22, [x10, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v2, v17
	fmul.4s	v22, v5, v22
	fadd.4s	v22, v7, v22
	fadd.4s	v17, v20, v17
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v2, v23
	fmul.4s	v24, v5, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v23, v13, v23
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v5, v5, v9
	fadd.4s	v5, v14, v5
	fadd.4s	v2, v11, v2
	add	x8, x8, #1
	bit.16b	v19, v6, v0
	bit.16b	v4, v16, v1
	bit.16b	v20, v17, v0
	bit.16b	v7, v22, v1
	bit.16b	v13, v23, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v2, v0
	bit.16b	v14, v5, v1
	add	x10, x10, #32
	cmp	x8, #32
	b.ne	LBB0_41
; %bb.42:                               ; %direct.false583
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #11616]               ; 16-byte Spill
	str	q4, [sp, #11632]                ; 16-byte Spill
	str	q20, [sp, #11648]               ; 16-byte Spill
	str	q7, [sp, #11664]                ; 16-byte Spill
	str	q13, [sp, #11680]               ; 16-byte Spill
	str	q12, [sp, #11696]               ; 16-byte Spill
	str	q11, [sp, #11712]               ; 16-byte Spill
	str	q14, [sp, #11728]               ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #11744]               ; 16-byte Reload
	bic.16b	v19, v19, v0
	ldr	q4, [sp, #11760]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q20, [sp, #11776]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q7, [sp, #11792]                ; 16-byte Reload
	bic.16b	v7, v7, v1
	ldr	q13, [sp, #11808]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q12, [sp, #11824]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #11840]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	add	x10, x13, #2, lsl #12           ; =8192
	ldr	q14, [sp, #11856]               ; 16-byte Reload
	bic.16b	v14, v14, v1
	ldr	q10, [sp, #12752]               ; 16-byte Reload
LBB0_43:                                ; %direct.true620
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x15, x8, lsl #5
	ldp	q5, q2, [x11]
	and.16b	v5, v1, v5
	and.16b	v2, v0, v2
	ldp	q16, q6, [x10]
	and.16b	v16, v1, v16
	and.16b	v6, v0, v6
	fmul.4s	v6, v2, v6
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v4, v16
	fadd.4s	v6, v19, v6
	ldr	q17, [x10, #1040]
	ldr	q22, [x10, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v2, v17
	fmul.4s	v22, v5, v22
	fadd.4s	v22, v7, v22
	fadd.4s	v17, v20, v17
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v2, v23
	fmul.4s	v24, v5, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v23, v13, v23
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v5, v5, v9
	fadd.4s	v5, v14, v5
	fadd.4s	v2, v11, v2
	add	x8, x8, #1
	bit.16b	v19, v6, v0
	bit.16b	v4, v16, v1
	bit.16b	v20, v17, v0
	bit.16b	v7, v22, v1
	bit.16b	v13, v23, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v2, v0
	bit.16b	v14, v5, v1
	add	x10, x10, #32
	cmp	x8, #32
	b.ne	LBB0_43
; %bb.44:                               ; %direct.false621
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #11744]               ; 16-byte Spill
	str	q4, [sp, #11760]                ; 16-byte Spill
	str	q20, [sp, #11776]               ; 16-byte Spill
	str	q7, [sp, #11792]                ; 16-byte Spill
	str	q13, [sp, #11808]               ; 16-byte Spill
	str	q12, [sp, #11824]               ; 16-byte Spill
	str	q11, [sp, #11840]               ; 16-byte Spill
	str	q14, [sp, #11856]               ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #11872]               ; 16-byte Reload
	bic.16b	v19, v19, v0
	ldr	q4, [sp, #11888]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q20, [sp, #11904]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q7, [sp, #11920]                ; 16-byte Reload
	bic.16b	v7, v7, v1
	ldr	q13, [sp, #11936]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q12, [sp, #11952]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #11968]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	add	x10, x13, #3, lsl #12           ; =12288
	bic.16b	v18, v18, v1
LBB0_45:                                ; %direct.true658
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x15, x8, lsl #5
	ldp	q5, q2, [x11]
	and.16b	v5, v1, v5
	and.16b	v2, v0, v2
	ldp	q16, q6, [x10]
	and.16b	v16, v1, v16
	and.16b	v6, v0, v6
	fmul.4s	v6, v2, v6
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v4, v16
	fadd.4s	v6, v19, v6
	ldr	q17, [x10, #1040]
	ldr	q22, [x10, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v2, v17
	fmul.4s	v22, v5, v22
	fadd.4s	v22, v7, v22
	fadd.4s	v17, v20, v17
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v2, v23
	fmul.4s	v24, v5, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v23, v13, v23
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v5, v5, v9
	fadd.4s	v5, v18, v5
	fadd.4s	v2, v11, v2
	add	x8, x8, #1
	bit.16b	v19, v6, v0
	bit.16b	v4, v16, v1
	bit.16b	v20, v17, v0
	bit.16b	v7, v22, v1
	bit.16b	v13, v23, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v2, v0
	bit.16b	v18, v5, v1
	add	x10, x10, #32
	cmp	x8, #32
	b.ne	LBB0_45
; %bb.46:                               ; %direct.false659
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #11872]               ; 16-byte Spill
	str	q4, [sp, #11888]                ; 16-byte Spill
	str	q20, [sp, #11904]               ; 16-byte Spill
	str	q7, [sp, #11920]                ; 16-byte Spill
	str	q13, [sp, #11936]               ; 16-byte Spill
	str	q12, [sp, #11952]               ; 16-byte Spill
	str	q11, [sp, #11968]               ; 16-byte Spill
	str	q18, [sp, #11984]               ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #12000]               ; 16-byte Reload
	bic.16b	v19, v19, v0
	ldr	q4, [sp, #12016]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q20, [sp, #12032]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q7, [sp, #12048]                ; 16-byte Reload
	bic.16b	v7, v7, v1
	ldr	q13, [sp, #12064]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q12, [sp, #12080]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #12096]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	ldr	q18, [sp, #12112]               ; 16-byte Reload
	bic.16b	v18, v18, v1
	ldr	q14, [sp, #13920]               ; 16-byte Reload
	ldr	q15, [sp, #13936]               ; 16-byte Reload
LBB0_47:                                ; %direct.true696
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x10, x8, #0x800
	fmov	d2, x10
	orr.16b	v5, v2, v15
	fmov	x10, d5
	add	x10, x14, x10
	ldp	q6, q5, [x10]
	and.16b	v6, v1, v6
	and.16b	v5, v0, v5
	add	x10, x13, x8
	ldp	q17, q16, [x10]
	and.16b	v17, v1, v17
	and.16b	v16, v0, v16
	fmul.4s	v16, v5, v16
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v4, v17
	fadd.4s	v16, v19, v16
	ldr	q22, [x10, #1040]
	ldr	q23, [x10, #1024]
	and.16b	v23, v1, v23
	and.16b	v22, v0, v22
	fmul.4s	v22, v5, v22
	fmul.4s	v23, v6, v23
	fadd.4s	v23, v7, v23
	fadd.4s	v22, v20, v22
	orr.16b	v2, v2, v14
	fmov	x11, d2
	add	x11, x13, x11
	ldp	q24, q2, [x11]
	and.16b	v24, v1, v24
	and.16b	v2, v0, v2
	fmul.4s	v2, v5, v2
	fmul.4s	v24, v6, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v2, v13, v2
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v5, v5, v25
	fmul.4s	v6, v6, v9
	fadd.4s	v6, v18, v6
	fadd.4s	v5, v11, v5
	bit.16b	v19, v16, v0
	bit.16b	v4, v17, v1
	bit.16b	v20, v22, v0
	bit.16b	v7, v23, v1
	bit.16b	v13, v2, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v5, v0
	bit.16b	v18, v6, v1
	add	x8, x8, #32
	cmp	x8, #1024
	b.ne	LBB0_47
; %bb.48:                               ; %direct.false697
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #12000]               ; 16-byte Spill
	str	q4, [sp, #12016]                ; 16-byte Spill
	str	q20, [sp, #12032]               ; 16-byte Spill
	str	q7, [sp, #12048]                ; 16-byte Spill
	str	q13, [sp, #12064]               ; 16-byte Spill
	str	q12, [sp, #12080]               ; 16-byte Spill
	str	q11, [sp, #12096]               ; 16-byte Spill
	str	q18, [sp, #12112]               ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #12128]               ; 16-byte Reload
	bic.16b	v19, v19, v0
	ldr	q4, [sp, #12144]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q20, [sp, #12160]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q7, [sp, #13840]                ; 16-byte Reload
	bic.16b	v7, v7, v1
	ldr	q13, [sp, #12176]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q12, [sp, #12192]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #12208]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	add	x10, x13, #1, lsl #12           ; =4096
	ldr	q14, [sp, #12224]               ; 16-byte Reload
	bic.16b	v14, v14, v1
LBB0_49:                                ; %direct.true733
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x16, x8, lsl #5
	ldp	q5, q2, [x11]
	and.16b	v5, v1, v5
	and.16b	v2, v0, v2
	ldp	q16, q6, [x10]
	and.16b	v16, v1, v16
	and.16b	v6, v0, v6
	fmul.4s	v6, v2, v6
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v4, v16
	fadd.4s	v6, v19, v6
	ldr	q17, [x10, #1040]
	ldr	q22, [x10, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v2, v17
	fmul.4s	v22, v5, v22
	fadd.4s	v22, v7, v22
	fadd.4s	v17, v20, v17
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v2, v23
	fmul.4s	v24, v5, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v23, v13, v23
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v5, v5, v9
	fadd.4s	v5, v14, v5
	fadd.4s	v2, v11, v2
	add	x8, x8, #1
	bit.16b	v19, v6, v0
	bit.16b	v4, v16, v1
	bit.16b	v20, v17, v0
	bit.16b	v7, v22, v1
	bit.16b	v13, v23, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v2, v0
	bit.16b	v14, v5, v1
	add	x10, x10, #32
	cmp	x8, #32
	b.ne	LBB0_49
; %bb.50:                               ; %direct.false734
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #12128]               ; 16-byte Spill
	str	q4, [sp, #12144]                ; 16-byte Spill
	str	q20, [sp, #12160]               ; 16-byte Spill
	str	q7, [sp, #13840]                ; 16-byte Spill
	str	q13, [sp, #12176]               ; 16-byte Spill
	str	q12, [sp, #12192]               ; 16-byte Spill
	str	q11, [sp, #12208]               ; 16-byte Spill
	str	q14, [sp, #12224]               ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #12240]               ; 16-byte Reload
	bic.16b	v19, v19, v0
	ldr	q4, [sp, #12256]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q20, [sp, #12272]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q7, [sp, #12288]                ; 16-byte Reload
	bic.16b	v7, v7, v1
	ldr	q13, [sp, #12304]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q12, [sp, #12320]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #12336]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	add	x10, x13, #2, lsl #12           ; =8192
	ldr	q14, [sp, #12352]               ; 16-byte Reload
	bic.16b	v14, v14, v1
LBB0_51:                                ; %direct.true771
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x16, x8, lsl #5
	ldp	q5, q2, [x11]
	and.16b	v5, v1, v5
	and.16b	v2, v0, v2
	ldp	q16, q6, [x10]
	and.16b	v16, v1, v16
	and.16b	v6, v0, v6
	fmul.4s	v6, v2, v6
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v4, v16
	fadd.4s	v6, v19, v6
	ldr	q17, [x10, #1040]
	ldr	q22, [x10, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v2, v17
	fmul.4s	v22, v5, v22
	fadd.4s	v22, v7, v22
	fadd.4s	v17, v20, v17
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v2, v23
	fmul.4s	v24, v5, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v23, v13, v23
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v5, v5, v9
	fadd.4s	v5, v14, v5
	fadd.4s	v2, v11, v2
	add	x8, x8, #1
	bit.16b	v19, v6, v0
	bit.16b	v4, v16, v1
	bit.16b	v20, v17, v0
	bit.16b	v7, v22, v1
	bit.16b	v13, v23, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v2, v0
	bit.16b	v14, v5, v1
	add	x10, x10, #32
	cmp	x8, #32
	b.ne	LBB0_51
; %bb.52:                               ; %direct.false772
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #12240]               ; 16-byte Spill
	str	q4, [sp, #12256]                ; 16-byte Spill
	str	q20, [sp, #12272]               ; 16-byte Spill
	str	q7, [sp, #12288]                ; 16-byte Spill
	str	q13, [sp, #12304]               ; 16-byte Spill
	str	q12, [sp, #12320]               ; 16-byte Spill
	str	q11, [sp, #12336]               ; 16-byte Spill
	str	q14, [sp, #12352]               ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #12368]               ; 16-byte Reload
	bic.16b	v19, v19, v0
	ldr	q4, [sp, #12384]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q20, [sp, #12400]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q7, [sp, #12416]                ; 16-byte Reload
	bic.16b	v7, v7, v1
	ldr	q13, [sp, #12432]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q12, [sp, #12448]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #12464]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	add	x10, x13, #3, lsl #12           ; =12288
	bic.16b	v3, v3, v1
LBB0_53:                                ; %direct.true809
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x16, x8, lsl #5
	ldp	q5, q2, [x11]
	and.16b	v5, v1, v5
	and.16b	v2, v0, v2
	ldp	q16, q6, [x10]
	and.16b	v16, v1, v16
	and.16b	v6, v0, v6
	fmul.4s	v6, v2, v6
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v4, v16
	fadd.4s	v6, v19, v6
	ldr	q17, [x10, #1040]
	ldr	q22, [x10, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v2, v17
	fmul.4s	v22, v5, v22
	fadd.4s	v22, v7, v22
	fadd.4s	v17, v20, v17
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v2, v23
	fmul.4s	v24, v5, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v23, v13, v23
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v5, v5, v9
	fadd.4s	v5, v3, v5
	fadd.4s	v2, v11, v2
	add	x8, x8, #1
	bit.16b	v19, v6, v0
	bit.16b	v4, v16, v1
	bit.16b	v20, v17, v0
	bit.16b	v7, v22, v1
	bit.16b	v13, v23, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v2, v0
	bit.16b	v3, v5, v1
	add	x10, x10, #32
	cmp	x8, #32
	b.ne	LBB0_53
; %bb.54:                               ; %direct.false810
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #12368]               ; 16-byte Spill
	str	q4, [sp, #12384]                ; 16-byte Spill
	str	q20, [sp, #12400]               ; 16-byte Spill
	str	q7, [sp, #12416]                ; 16-byte Spill
	str	q13, [sp, #12432]               ; 16-byte Spill
	str	q12, [sp, #12448]               ; 16-byte Spill
	str	q11, [sp, #12464]               ; 16-byte Spill
	str	q3, [sp, #12480]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #12496]               ; 16-byte Reload
	bic.16b	v19, v19, v0
	ldr	q4, [sp, #12512]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q20, [sp, #12528]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q7, [sp, #12544]                ; 16-byte Reload
	bic.16b	v7, v7, v1
	ldr	q13, [sp, #12560]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q12, [sp, #12576]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #12592]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	ldr	q3, [sp, #12608]                ; 16-byte Reload
	bic.16b	v3, v3, v1
	ldr	q14, [sp, #13920]               ; 16-byte Reload
	ldr	q15, [sp, #13936]               ; 16-byte Reload
LBB0_55:                                ; %direct.true847
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x10, x8, #0xc00
	fmov	d2, x10
	orr.16b	v5, v2, v15
	fmov	x10, d5
	add	x10, x14, x10
	ldp	q6, q5, [x10]
	and.16b	v6, v1, v6
	and.16b	v5, v0, v5
	add	x10, x13, x8
	ldp	q17, q16, [x10]
	and.16b	v17, v1, v17
	and.16b	v16, v0, v16
	fmul.4s	v16, v5, v16
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v4, v17
	fadd.4s	v16, v19, v16
	ldr	q22, [x10, #1040]
	ldr	q23, [x10, #1024]
	and.16b	v23, v1, v23
	and.16b	v22, v0, v22
	fmul.4s	v22, v5, v22
	fmul.4s	v23, v6, v23
	fadd.4s	v23, v7, v23
	fadd.4s	v22, v20, v22
	ldr	q24, [x10, #2064]
	ldr	q25, [x10, #2048]
	and.16b	v25, v1, v25
	and.16b	v24, v0, v24
	fmul.4s	v24, v5, v24
	fmul.4s	v25, v6, v25
	fadd.4s	v25, v12, v25
	fadd.4s	v24, v13, v24
	orr.16b	v2, v2, v14
	fmov	x10, d2
	add	x10, x13, x10
	ldp	q9, q2, [x10]
	and.16b	v9, v1, v9
	and.16b	v2, v0, v2
	fmul.4s	v2, v5, v2
	fmul.4s	v5, v6, v9
	fadd.4s	v5, v3, v5
	fadd.4s	v2, v11, v2
	bit.16b	v19, v16, v0
	bit.16b	v4, v17, v1
	bit.16b	v20, v22, v0
	bit.16b	v7, v23, v1
	bit.16b	v13, v24, v0
	bit.16b	v12, v25, v1
	bit.16b	v11, v2, v0
	bit.16b	v3, v5, v1
	add	x8, x8, #32
	cmp	x8, #1024
	b.ne	LBB0_55
; %bb.56:                               ; %direct.false848
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #12496]               ; 16-byte Spill
	str	q4, [sp, #12512]                ; 16-byte Spill
	str	q20, [sp, #12528]               ; 16-byte Spill
	str	q7, [sp, #12544]                ; 16-byte Spill
	str	q13, [sp, #12560]               ; 16-byte Spill
	str	q12, [sp, #12576]               ; 16-byte Spill
	str	q11, [sp, #12592]               ; 16-byte Spill
	str	q3, [sp, #12608]                ; 16-byte Spill
	ldr	q13, [sp, #12624]               ; 16-byte Reload
	bic.16b	v13, v13, v0
	ldr	q19, [sp, #12640]               ; 16-byte Reload
	bic.16b	v19, v19, v1
	ldr	q4, [sp, #12656]                ; 16-byte Reload
	bic.16b	v4, v4, v0
	ldr	q20, [sp, #12672]               ; 16-byte Reload
	bic.16b	v20, v20, v1
	ldr	q7, [sp, #12688]                ; 16-byte Reload
	bic.16b	v7, v7, v0
	ldr	q12, [sp, #12704]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #12720]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	add	x8, x13, #1, lsl #12            ; =4096
	mov	w10, #3072                      ; =0xc00
	ldr	q3, [sp, #12736]                ; 16-byte Reload
	bic.16b	v3, v3, v1
LBB0_57:                                ; %direct.true884
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x14, x10
	ldp	q5, q2, [x11]
	and.16b	v5, v1, v5
	and.16b	v2, v0, v2
	ldp	q16, q6, [x8]
	and.16b	v16, v1, v16
	and.16b	v6, v0, v6
	fmul.4s	v6, v2, v6
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v19, v16
	fadd.4s	v6, v13, v6
	ldr	q17, [x8, #1040]
	ldr	q22, [x8, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v2, v17
	fmul.4s	v22, v5, v22
	fadd.4s	v22, v20, v22
	fadd.4s	v17, v4, v17
	ldr	q23, [x8, #2064]
	ldr	q24, [x8, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v2, v23
	fmul.4s	v24, v5, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v23, v7, v23
	ldr	q25, [x8, #3088]
	ldr	q9, [x8, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v5, v5, v9
	fadd.4s	v5, v3, v5
	fadd.4s	v2, v11, v2
	bit.16b	v13, v6, v0
	bit.16b	v19, v16, v1
	bit.16b	v4, v17, v0
	bit.16b	v20, v22, v1
	bit.16b	v7, v23, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v2, v0
	bit.16b	v3, v5, v1
	add	x10, x10, #32
	add	x8, x8, #32
	cmp	x10, #1, lsl #12                ; =4096
	b.ne	LBB0_57
; %bb.58:                               ; %direct.false885
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q13, [sp, #12624]               ; 16-byte Spill
	str	q19, [sp, #12640]               ; 16-byte Spill
	str	q4, [sp, #12656]                ; 16-byte Spill
	str	q20, [sp, #12672]               ; 16-byte Spill
	str	q7, [sp, #12688]                ; 16-byte Spill
	str	q12, [sp, #12704]               ; 16-byte Spill
	str	q11, [sp, #12720]               ; 16-byte Spill
	str	q3, [sp, #12736]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	bic.16b	v10, v10, v0
	ldr	q4, [sp, #12768]                ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q15, [sp, #12784]               ; 16-byte Reload
	bic.16b	v15, v15, v0
	ldr	q18, [sp, #12800]               ; 16-byte Reload
	bic.16b	v18, v18, v1
	ldr	q14, [sp, #12816]               ; 16-byte Reload
	bic.16b	v14, v14, v0
	ldr	q12, [sp, #12832]               ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q11, [sp, #12848]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	add	x10, x13, #2, lsl #12           ; =8192
	ldr	q13, [sp, #12864]               ; 16-byte Reload
	bic.16b	v13, v13, v1
LBB0_59:                                ; %direct.true922
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x17, x8, lsl #5
	ldp	q5, q2, [x11]
	and.16b	v5, v1, v5
	and.16b	v2, v0, v2
	ldp	q16, q6, [x10]
	and.16b	v16, v1, v16
	and.16b	v6, v0, v6
	fmul.4s	v6, v2, v6
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v4, v16
	fadd.4s	v6, v10, v6
	ldr	q17, [x10, #1040]
	ldr	q22, [x10, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v2, v17
	fmul.4s	v22, v5, v22
	fadd.4s	v22, v18, v22
	fadd.4s	v17, v15, v17
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v2, v23
	fmul.4s	v24, v5, v24
	fadd.4s	v24, v12, v24
	fadd.4s	v23, v14, v23
	mov.16b	v19, v10
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v5, v5, v9
	fadd.4s	v5, v13, v5
	fadd.4s	v2, v11, v2
	add	x8, x8, #1
	mov.16b	v10, v0
	bsl.16b	v10, v6, v19
	bit.16b	v4, v16, v1
	bit.16b	v15, v17, v0
	bit.16b	v18, v22, v1
	bit.16b	v14, v23, v0
	bit.16b	v12, v24, v1
	bit.16b	v11, v2, v0
	bit.16b	v13, v5, v1
	add	x10, x10, #32
	cmp	x8, #32
	b.ne	LBB0_59
; %bb.60:                               ; %direct.false923
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q10, [sp, #12752]               ; 16-byte Spill
	str	q4, [sp, #12768]                ; 16-byte Spill
	str	q15, [sp, #12784]               ; 16-byte Spill
	str	q18, [sp, #12800]               ; 16-byte Spill
	str	q14, [sp, #12816]               ; 16-byte Spill
	str	q12, [sp, #12832]               ; 16-byte Spill
	str	q11, [sp, #12848]               ; 16-byte Spill
	str	q13, [sp, #12864]               ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q11, [sp, #12880]               ; 16-byte Reload
	bic.16b	v11, v11, v0
	ldr	q18, [sp, #12896]               ; 16-byte Reload
	bic.16b	v18, v18, v1
	ldr	q14, [sp, #12912]               ; 16-byte Reload
	bic.16b	v14, v14, v0
	ldr	q3, [sp, #13856]                ; 16-byte Reload
	bic.16b	v3, v3, v1
	ldr	q20, [sp, #13872]               ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q19, [sp, #13888]               ; 16-byte Reload
	bic.16b	v19, v19, v1
	ldr	q7, [sp, #13904]                ; 16-byte Reload
	bic.16b	v7, v7, v0
	add	x10, x13, #3, lsl #12           ; =12288
	ldr	q4, [sp, #12928]                ; 16-byte Reload
	bic.16b	v4, v4, v1
LBB0_61:                                ; %direct.true960
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x17, x8, lsl #5
	ldp	q5, q2, [x11]
	and.16b	v5, v1, v5
	and.16b	v2, v0, v2
	ldp	q16, q6, [x10]
	and.16b	v16, v1, v16
	and.16b	v6, v0, v6
	fmul.4s	v6, v2, v6
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v18, v16
	fadd.4s	v6, v11, v6
	ldr	q17, [x10, #1040]
	ldr	q22, [x10, #1024]
	and.16b	v22, v1, v22
	and.16b	v17, v0, v17
	fmul.4s	v17, v2, v17
	fmul.4s	v22, v5, v22
	fadd.4s	v22, v3, v22
	fadd.4s	v17, v14, v17
	ldr	q23, [x10, #2064]
	ldr	q24, [x10, #2048]
	and.16b	v24, v1, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v2, v23
	fmul.4s	v24, v5, v24
	fadd.4s	v24, v19, v24
	fadd.4s	v23, v20, v23
	ldr	q25, [x10, #3088]
	ldr	q9, [x10, #3072]
	and.16b	v9, v1, v9
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v5, v5, v9
	fadd.4s	v5, v4, v5
	fadd.4s	v2, v7, v2
	add	x8, x8, #1
	bit.16b	v11, v6, v0
	bit.16b	v18, v16, v1
	bit.16b	v14, v17, v0
	bit.16b	v3, v22, v1
	bit.16b	v20, v23, v0
	bit.16b	v19, v24, v1
	bit.16b	v7, v2, v0
	bit.16b	v4, v5, v1
	add	x10, x10, #32
	cmp	x8, #32
	b.ne	LBB0_61
; %bb.62:                               ; %direct.false961
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x24, #0                         ; =0x0
	dup.2d	v2, x23
	ldr	q24, [sp, #368]                 ; 16-byte Reload
	cmhs.2d	v5, v24, v2
	str	q18, [sp, #12896]               ; 16-byte Spill
	ldp	q18, q17, [sp, #320]            ; 32-byte Folded Reload
	cmhs.2d	v6, v18, v2
	orr	x5, x23, #0x1
	uzp1.4s	v5, v5, v6
	str	q5, [sp, #14160]                ; 16-byte Spill
	orr	x30, x23, #0x2
	str	q4, [sp, #12928]                ; 16-byte Spill
	ldr	q4, [sp, #352]                  ; 16-byte Reload
	cmhs.2d	v5, v4, v2
	orr	x28, x23, #0x3
	cmhs.2d	v6, v17, v2
	orr	x27, x23, #0x4
	uzp1.4s	v5, v6, v5
	str	q5, [sp, #14144]                ; 16-byte Spill
	mov	w8, #5                          ; =0x5
	orr	x26, x23, x8
	ldr	q15, [sp, #304]                 ; 16-byte Reload
	cmhs.2d	v5, v15, v2
	orr	x25, x23, #0x6
	str	q7, [sp, #13904]                ; 16-byte Spill
	ldp	q7, q22, [sp, #256]             ; 32-byte Folded Reload
	cmhs.2d	v6, v7, v2
	uzp1.4s	v5, v5, v6
	str	q5, [sp, #14128]                ; 16-byte Spill
	str	q20, [sp, #13872]               ; 16-byte Spill
	ldr	q20, [sp, #288]                 ; 16-byte Reload
	cmhs.2d	v5, v20, v2
	cmhs.2d	v6, v22, v2
	uzp1.4s	v5, v6, v5
	str	q5, [sp, #14112]                ; 16-byte Spill
	str	q19, [sp, #13888]               ; 16-byte Spill
	ldp	q10, q19, [sp, #224]            ; 32-byte Folded Reload
	cmhs.2d	v5, v19, v2
	ldp	q23, q12, [sp, #176]            ; 32-byte Folded Reload
	cmhs.2d	v6, v12, v2
	uzp1.4s	v5, v5, v6
	str	q5, [sp, #14096]                ; 16-byte Spill
	str	q3, [sp, #13856]                ; 16-byte Spill
	cmhs.2d	v5, v10, v2
	str	q11, [sp, #12880]               ; 16-byte Spill
	ldr	q11, [sp, #208]                 ; 16-byte Reload
	cmhs.2d	v6, v11, v2
	uzp1.4s	v3, v6, v5
	str	q3, [sp, #14080]                ; 16-byte Spill
	cmhs.2d	v5, v23, v2
	ldr	q25, [sp, #128]                 ; 16-byte Reload
	cmhs.2d	v6, v25, v2
	uzp1.4s	v3, v5, v6
	str	q3, [sp, #14064]                ; 16-byte Spill
	ldp	q3, q13, [sp, #144]             ; 32-byte Folded Reload
	cmhs.2d	v5, v13, v2
	str	q14, [sp, #12912]               ; 16-byte Spill
	cmhs.2d	v2, v3, v2
	uzp1.4s	v2, v2, v5
	str	q2, [sp, #14048]                ; 16-byte Spill
	dup.2d	v2, x5
	cmhs.2d	v5, v4, v2
	cmhs.2d	v6, v17, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v24, v2
	cmhs.2d	v16, v18, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v14, v5, v6
	cmhs.2d	v5, v20, v2
	cmhs.2d	v6, v22, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v15, v2
	cmhs.2d	v16, v7, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #14032]                ; 16-byte Spill
	cmhs.2d	v5, v10, v2
	cmhs.2d	v6, v11, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v19, v2
	cmhs.2d	v16, v12, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #14016]                ; 16-byte Spill
	cmhs.2d	v5, v13, v2
	cmhs.2d	v6, v3, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v23, v2
	cmhs.2d	v2, v25, v2
	uzp1.4s	v2, v6, v2
	uzp1.8h	v2, v5, v2
	str	q2, [sp, #14000]                ; 16-byte Spill
	dup.2d	v2, x30
	cmhs.2d	v5, v4, v2
	cmhs.2d	v6, v17, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v24, v2
	cmhs.2d	v16, v18, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #13984]                ; 16-byte Spill
	cmhs.2d	v5, v20, v2
	cmhs.2d	v6, v22, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v15, v2
	cmhs.2d	v16, v7, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #13968]                ; 16-byte Spill
	cmhs.2d	v5, v10, v2
	cmhs.2d	v6, v11, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v19, v2
	cmhs.2d	v16, v12, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #13952]                ; 16-byte Spill
	cmhs.2d	v5, v13, v2
	cmhs.2d	v6, v3, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v23, v2
	cmhs.2d	v2, v25, v2
	uzp1.4s	v2, v6, v2
	uzp1.8h	v2, v5, v2
	str	q2, [sp, #10800]                ; 16-byte Spill
	dup.2d	v2, x28
	cmhs.2d	v5, v4, v2
	cmhs.2d	v6, v17, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v24, v2
	cmhs.2d	v16, v18, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10752]                ; 16-byte Spill
	cmhs.2d	v5, v20, v2
	cmhs.2d	v6, v22, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v15, v2
	cmhs.2d	v16, v7, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10736]                ; 16-byte Spill
	cmhs.2d	v5, v10, v2
	cmhs.2d	v6, v11, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v19, v2
	cmhs.2d	v16, v12, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10720]                ; 16-byte Spill
	cmhs.2d	v5, v13, v2
	cmhs.2d	v6, v3, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v23, v2
	cmhs.2d	v2, v25, v2
	uzp1.4s	v2, v6, v2
	uzp1.8h	v2, v5, v2
	str	q2, [sp, #10704]                ; 16-byte Spill
	dup.2d	v2, x27
	cmhs.2d	v5, v4, v2
	cmhs.2d	v6, v17, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v24, v2
	cmhs.2d	v16, v18, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10688]                ; 16-byte Spill
	cmhs.2d	v5, v20, v2
	cmhs.2d	v6, v22, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v15, v2
	cmhs.2d	v16, v7, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10672]                ; 16-byte Spill
	cmhs.2d	v5, v10, v2
	cmhs.2d	v6, v11, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v19, v2
	cmhs.2d	v16, v12, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10656]                ; 16-byte Spill
	cmhs.2d	v5, v13, v2
	cmhs.2d	v6, v3, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v23, v2
	cmhs.2d	v2, v25, v2
	uzp1.4s	v2, v6, v2
	uzp1.8h	v2, v5, v2
	str	q2, [sp, #10640]                ; 16-byte Spill
	dup.2d	v2, x26
	cmhs.2d	v5, v18, v2
	cmhs.2d	v6, v24, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v4, v2
	cmhs.2d	v16, v17, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10624]                ; 16-byte Spill
	cmhs.2d	v5, v7, v2
	cmhs.2d	v6, v15, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v20, v2
	cmhs.2d	v16, v22, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10608]                ; 16-byte Spill
	cmhs.2d	v5, v12, v2
	cmhs.2d	v6, v19, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v10, v2
	cmhs.2d	v16, v11, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10592]                ; 16-byte Spill
	cmhs.2d	v5, v25, v2
	cmhs.2d	v6, v23, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v13, v2
	cmhs.2d	v2, v3, v2
	uzp1.4s	v2, v2, v6
	uzp1.8h	v2, v2, v5
	str	q2, [sp, #10576]                ; 16-byte Spill
	dup.2d	v2, x25
	cmhs.2d	v5, v4, v2
	cmhs.2d	v6, v17, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v24, v2
	cmhs.2d	v16, v18, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10560]                ; 16-byte Spill
	cmhs.2d	v5, v20, v2
	cmhs.2d	v6, v22, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v15, v2
	cmhs.2d	v16, v7, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10544]                ; 16-byte Spill
	cmhs.2d	v5, v10, v2
	cmhs.2d	v6, v11, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v19, v2
	cmhs.2d	v16, v12, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10528]                ; 16-byte Spill
	cmhs.2d	v5, v13, v2
	cmhs.2d	v6, v3, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v23, v2
	cmhs.2d	v2, v25, v2
	uzp1.4s	v2, v6, v2
	uzp1.8h	v2, v5, v2
	str	q2, [sp, #10512]                ; 16-byte Spill
	orr	x6, x23, #0x7
	dup.2d	v2, x6
	cmhs.2d	v5, v4, v2
	cmhs.2d	v6, v17, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v24, v2
	cmhs.2d	v16, v18, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10496]                ; 16-byte Spill
	cmhs.2d	v5, v20, v2
	cmhs.2d	v6, v22, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v15, v2
	cmhs.2d	v16, v7, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10480]                ; 16-byte Spill
	cmhs.2d	v5, v10, v2
	cmhs.2d	v6, v11, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v19, v2
	cmhs.2d	v16, v12, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10464]                ; 16-byte Spill
	cmhs.2d	v5, v13, v2
	cmhs.2d	v6, v3, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v23, v2
	cmhs.2d	v2, v25, v2
	uzp1.4s	v2, v6, v2
	orr	x8, x23, #0x8
	dup.2d	v6, x8
	uzp1.8h	v2, v5, v2
	str	q2, [sp, #10432]                ; 16-byte Spill
	cmhs.2d	v2, v4, v6
	cmhs.2d	v5, v17, v6
	uzp1.4s	v2, v5, v2
	cmhs.2d	v5, v24, v6
	cmhs.2d	v16, v18, v6
	uzp1.4s	v5, v5, v16
	uzp1.8h	v2, v2, v5
	str	q2, [sp, #10448]                ; 16-byte Spill
	cmhs.2d	v2, v20, v6
	cmhs.2d	v5, v22, v6
	uzp1.4s	v2, v5, v2
	cmhs.2d	v5, v15, v6
	cmhs.2d	v16, v7, v6
	uzp1.4s	v5, v5, v16
	uzp1.8h	v2, v2, v5
	str	q2, [sp, #10416]                ; 16-byte Spill
	cmhs.2d	v2, v10, v6
	cmhs.2d	v5, v11, v6
	uzp1.4s	v2, v5, v2
	cmhs.2d	v5, v19, v6
	cmhs.2d	v16, v12, v6
	uzp1.4s	v5, v5, v16
	uzp1.8h	v2, v2, v5
	str	q2, [sp, #10400]                ; 16-byte Spill
	cmhs.2d	v2, v13, v6
	cmhs.2d	v5, v3, v6
	uzp1.4s	v2, v5, v2
	cmhs.2d	v5, v23, v6
	cmhs.2d	v6, v25, v6
	uzp1.4s	v5, v5, v6
	uzp1.8h	v2, v2, v5
	str	q2, [sp, #10384]                ; 16-byte Spill
	mov	w10, #9                         ; =0x9
	orr	x12, x23, x10
	dup.2d	v2, x12
	cmhs.2d	v5, v18, v2
	cmhs.2d	v6, v24, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v4, v2
	cmhs.2d	v16, v17, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10368]                ; 16-byte Spill
	cmhs.2d	v5, v7, v2
	cmhs.2d	v6, v15, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v20, v2
	cmhs.2d	v16, v22, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10352]                ; 16-byte Spill
	cmhs.2d	v5, v12, v2
	cmhs.2d	v6, v19, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v10, v2
	cmhs.2d	v16, v11, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10336]                ; 16-byte Spill
	cmhs.2d	v5, v25, v2
	cmhs.2d	v6, v23, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v13, v2
	cmhs.2d	v2, v3, v2
	uzp1.4s	v2, v2, v6
	uzp1.8h	v2, v2, v5
	str	q2, [sp, #10320]                ; 16-byte Spill
	mov	w10, #10                        ; =0xa
	orr	x10, x23, x10
	dup.2d	v2, x10
	cmhs.2d	v5, v18, v2
	cmhs.2d	v6, v24, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v4, v2
	cmhs.2d	v16, v17, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10304]                ; 16-byte Spill
	cmhs.2d	v5, v7, v2
	cmhs.2d	v6, v15, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v20, v2
	cmhs.2d	v16, v22, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10288]                ; 16-byte Spill
	cmhs.2d	v5, v12, v2
	cmhs.2d	v6, v19, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v10, v2
	cmhs.2d	v16, v11, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10272]                ; 16-byte Spill
	cmhs.2d	v5, v25, v2
	cmhs.2d	v6, v23, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v13, v2
	cmhs.2d	v2, v3, v2
	uzp1.4s	v2, v2, v6
	uzp1.8h	v2, v2, v5
	str	q2, [sp, #10256]                ; 16-byte Spill
	mov	w11, #11                        ; =0xb
	orr	x11, x23, x11
	dup.2d	v2, x11
	cmhs.2d	v5, v18, v2
	cmhs.2d	v6, v24, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v4, v2
	cmhs.2d	v16, v17, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10240]                ; 16-byte Spill
	cmhs.2d	v5, v7, v2
	cmhs.2d	v6, v15, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v20, v2
	cmhs.2d	v16, v22, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10224]                ; 16-byte Spill
	cmhs.2d	v5, v12, v2
	cmhs.2d	v6, v19, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v10, v2
	cmhs.2d	v16, v11, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10208]                ; 16-byte Spill
	cmhs.2d	v5, v25, v2
	cmhs.2d	v6, v23, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v13, v2
	cmhs.2d	v2, v3, v2
	uzp1.4s	v2, v2, v6
	uzp1.8h	v2, v2, v5
	str	q2, [sp, #10192]                ; 16-byte Spill
	orr	x1, x23, #0xc
	dup.2d	v2, x1
	cmhs.2d	v5, v4, v2
	cmhs.2d	v6, v17, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v24, v2
	cmhs.2d	v16, v18, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10176]                ; 16-byte Spill
	cmhs.2d	v5, v20, v2
	cmhs.2d	v6, v22, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v15, v2
	cmhs.2d	v16, v7, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10160]                ; 16-byte Spill
	cmhs.2d	v5, v10, v2
	cmhs.2d	v6, v11, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v19, v2
	cmhs.2d	v16, v12, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v5, v5, v6
	str	q5, [sp, #10144]                ; 16-byte Spill
	cmhs.2d	v5, v13, v2
	cmhs.2d	v6, v3, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v23, v2
	cmhs.2d	v2, v25, v2
	uzp1.4s	v2, v6, v2
	uzp1.8h	v2, v5, v2
	str	q2, [sp, #10128]                ; 16-byte Spill
	mov	w2, #13                         ; =0xd
	orr	x2, x23, x2
	dup.2d	v2, x2
	cmhs.2d	v5, v18, v2
	cmhs.2d	v6, v24, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v4, v2
	cmhs.2d	v16, v17, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10112]                ; 16-byte Spill
	cmhs.2d	v5, v7, v2
	cmhs.2d	v6, v15, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v20, v2
	cmhs.2d	v16, v22, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10096]                ; 16-byte Spill
	cmhs.2d	v5, v12, v2
	cmhs.2d	v6, v19, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v10, v2
	cmhs.2d	v16, v11, v2
	uzp1.4s	v6, v16, v6
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #10080]                ; 16-byte Spill
	cmhs.2d	v5, v25, v2
	cmhs.2d	v6, v23, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v13, v2
	cmhs.2d	v2, v3, v2
	uzp1.4s	v2, v2, v6
	orr	x3, x23, #0xe
	dup.2d	v6, x3
	uzp1.8h	v9, v2, v5
	cmhs.2d	v2, v4, v6
	cmhs.2d	v5, v17, v6
	uzp1.4s	v2, v5, v2
	cmhs.2d	v5, v24, v6
	cmhs.2d	v16, v18, v6
	uzp1.4s	v5, v5, v16
	uzp1.8h	v2, v2, v5
	str	q2, [sp, #10064]                ; 16-byte Spill
	cmhs.2d	v2, v20, v6
	cmhs.2d	v5, v22, v6
	uzp1.4s	v2, v5, v2
	cmhs.2d	v5, v15, v6
	cmhs.2d	v16, v7, v6
	uzp1.4s	v5, v5, v16
	uzp1.8h	v2, v2, v5
	str	q2, [sp, #10048]                ; 16-byte Spill
	cmhs.2d	v2, v10, v6
	cmhs.2d	v5, v11, v6
	uzp1.4s	v2, v5, v2
	cmhs.2d	v5, v19, v6
	cmhs.2d	v16, v12, v6
	uzp1.4s	v5, v5, v16
	uzp1.8h	v2, v2, v5
	str	q2, [sp, #10032]                ; 16-byte Spill
	cmhs.2d	v2, v13, v6
	cmhs.2d	v5, v3, v6
	uzp1.4s	v2, v5, v2
	cmhs.2d	v5, v23, v6
	cmhs.2d	v6, v25, v6
	uzp1.4s	v5, v5, v6
	uzp1.8h	v2, v2, v5
	str	q2, [sp, #10016]                ; 16-byte Spill
	orr	x23, x23, #0xf
	dup.2d	v2, x23
	cmhs.2d	v5, v4, v2
	cmhs.2d	v6, v17, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v24, v2
	cmhs.2d	v16, v18, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v4, v5, v6
	str	q4, [sp, #10000]                ; 16-byte Spill
	cmhs.2d	v5, v20, v2
	cmhs.2d	v6, v22, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v15, v2
	cmhs.2d	v16, v7, v2
	uzp1.4s	v6, v6, v16
	uzp1.8h	v4, v5, v6
	str	q4, [sp, #9984]                 ; 16-byte Spill
	cmhs.2d	v5, v10, v2
	cmhs.2d	v6, v11, v2
	uzp1.4s	v5, v6, v5
	cmhs.2d	v6, v19, v2
	cmhs.2d	v15, v12, v2
	uzp1.4s	v6, v6, v15
	uzp1.8h	v16, v5, v6
	cmhs.2d	v5, v13, v2
	cmhs.2d	v15, v3, v2
	uzp1.4s	v5, v15, v5
	cmhs.2d	v15, v23, v2
	cmhs.2d	v2, v25, v2
	uzp1.4s	v2, v15, v2
	uzp1.8h	v6, v5, v2
	cmp	x5, #65
	cset	w5, lo
	xtn.8b	v5, v14
	ldr	q2, [sp, #14032]                ; 16-byte Reload
	xtn.8b	v15, v2
	ldr	q2, [sp, #14016]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #14000]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v4, w5
	and.8b	v7, v4, v5
	and.8b	v3, v4, v15
	str	d3, [sp, #10848]                ; 8-byte Spill
	and.8b	v2, v4, v2
	str	d2, [sp, #10832]                ; 8-byte Spill
	and.8b	v2, v4, v18
	str	d2, [sp, #10816]                ; 8-byte Spill
	cmp	x30, #65
	cset	w5, lo
	ldr	q2, [sp, #13984]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #13968]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #13952]                ; 16-byte Reload
	xtn.8b	v5, v3
	ldr	q3, [sp, #10800]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v15, w5
	and.8b	v25, v15, v2
	and.8b	v2, v15, v4
	str	d2, [sp, #10800]                ; 8-byte Spill
	and.8b	v2, v15, v5
	str	d2, [sp, #10784]                ; 8-byte Spill
	and.8b	v2, v15, v18
	str	d2, [sp, #10768]                ; 8-byte Spill
	cmp	x28, #65
	cset	w5, lo
	ldr	q2, [sp, #10752]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #10736]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #10720]                ; 16-byte Reload
	xtn.8b	v5, v3
	ldr	q3, [sp, #10704]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v15, w5
	and.8b	v13, v15, v2
	and.8b	v2, v15, v4
	str	d2, [sp, #10752]                ; 8-byte Spill
	and.8b	v2, v15, v5
	str	d2, [sp, #10736]                ; 8-byte Spill
	and.8b	v2, v15, v18
	str	d2, [sp, #10720]                ; 8-byte Spill
	cmp	x27, #65
	cset	w5, lo
	ldr	q2, [sp, #10688]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #10672]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #10656]                ; 16-byte Reload
	xtn.8b	v5, v3
	ldr	q3, [sp, #10640]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v15, w5
	and.8b	v17, v15, v2
	and.8b	v2, v15, v4
	str	d2, [sp, #10704]                ; 8-byte Spill
	and.8b	v2, v15, v5
	str	d2, [sp, #10688]                ; 8-byte Spill
	and.8b	v2, v15, v18
	str	d2, [sp, #10672]                ; 8-byte Spill
	cmp	x26, #65
	cset	w5, lo
	ldr	q2, [sp, #10624]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #10608]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #10592]                ; 16-byte Reload
	xtn.8b	v5, v3
	ldr	q3, [sp, #10576]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v15, w5
	and.8b	v19, v15, v2
	and.8b	v2, v15, v4
	str	d2, [sp, #10656]                ; 8-byte Spill
	and.8b	v2, v15, v5
	str	d2, [sp, #10640]                ; 8-byte Spill
	and.8b	v2, v15, v18
	str	d2, [sp, #10624]                ; 8-byte Spill
	cmp	x25, #65
	cset	w5, lo
	ldr	q2, [sp, #10560]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #10544]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #10528]                ; 16-byte Reload
	xtn.8b	v5, v3
	ldr	q3, [sp, #10512]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v15, w5
	and.8b	v20, v15, v2
	and.8b	v2, v15, v4
	str	d2, [sp, #10608]                ; 8-byte Spill
	and.8b	v2, v15, v5
	str	d2, [sp, #10592]                ; 8-byte Spill
	and.8b	v2, v15, v18
	str	d2, [sp, #10576]                ; 8-byte Spill
	cmp	x6, #65
	cset	w5, lo
	ldr	q2, [sp, #10496]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #10480]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #10464]                ; 16-byte Reload
	xtn.8b	v5, v3
	ldr	q3, [sp, #10432]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v15, w5
	and.8b	v22, v15, v2
	and.8b	v2, v15, v4
	str	d2, [sp, #10560]                ; 8-byte Spill
	and.8b	v2, v15, v5
	str	d2, [sp, #10544]                ; 8-byte Spill
	and.8b	v2, v15, v18
	str	d2, [sp, #10528]                ; 8-byte Spill
	cmp	x8, #65
	cset	w8, lo
	ldr	q2, [sp, #10448]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #10416]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #10400]                ; 16-byte Reload
	xtn.8b	v5, v3
	ldr	q3, [sp, #10384]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v15, w8
	and.8b	v24, v15, v2
	and.8b	v2, v15, v4
	str	d2, [sp, #10512]                ; 8-byte Spill
	and.8b	v2, v15, v5
	str	d2, [sp, #10496]                ; 8-byte Spill
	and.8b	v2, v15, v18
	str	d2, [sp, #10480]                ; 8-byte Spill
	cmp	x12, #65
	cset	w8, lo
	ldr	q2, [sp, #10368]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #10352]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #10336]                ; 16-byte Reload
	xtn.8b	v5, v3
	ldr	q3, [sp, #10320]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v15, w8
	and.8b	v10, v15, v2
	and.8b	v2, v15, v4
	str	d2, [sp, #10464]                ; 8-byte Spill
	and.8b	v2, v15, v5
	str	d2, [sp, #10448]                ; 8-byte Spill
	and.8b	v2, v15, v18
	str	d2, [sp, #10432]                ; 8-byte Spill
	cmp	x10, #65
	cset	w8, lo
	ldr	q2, [sp, #10304]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #10288]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #10272]                ; 16-byte Reload
	xtn.8b	v5, v3
	ldr	q3, [sp, #10256]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v15, w8
	and.8b	v11, v15, v2
	and.8b	v2, v15, v4
	str	d2, [sp, #10416]                ; 8-byte Spill
	and.8b	v2, v15, v5
	str	d2, [sp, #10400]                ; 8-byte Spill
	and.8b	v2, v15, v18
	str	d2, [sp, #10384]                ; 8-byte Spill
	cmp	x11, #65
	cset	w8, lo
	ldr	q2, [sp, #10240]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #10224]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #10208]                ; 16-byte Reload
	xtn.8b	v5, v3
	ldr	q3, [sp, #10192]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v15, w8
	and.8b	v12, v15, v2
	and.8b	v2, v15, v4
	str	d2, [sp, #10368]                ; 8-byte Spill
	and.8b	v2, v15, v5
	str	d2, [sp, #10352]                ; 8-byte Spill
	and.8b	v2, v15, v18
	str	d2, [sp, #10336]                ; 8-byte Spill
	cmp	x1, #65
	cset	w8, lo
	ldr	q2, [sp, #10176]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #10160]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #10144]                ; 16-byte Reload
	xtn.8b	v5, v3
	ldr	q3, [sp, #10128]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v15, w8
	and.8b	v14, v15, v2
	and.8b	v2, v15, v4
	str	d2, [sp, #10320]                ; 8-byte Spill
	and.8b	v2, v15, v5
	str	d2, [sp, #10304]                ; 8-byte Spill
	and.8b	v2, v15, v18
	str	d2, [sp, #10288]                ; 8-byte Spill
	cmp	x2, #65
	cset	w8, lo
	ldr	q2, [sp, #10112]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #10096]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #10080]                ; 16-byte Reload
	xtn.8b	v5, v3
	xtn.8b	v18, v9
	dup.8b	v9, w8
	and.8b	v15, v9, v2
	and.8b	v2, v9, v4
	str	d2, [sp, #10272]                ; 8-byte Spill
	and.8b	v2, v9, v5
	str	d2, [sp, #10256]                ; 8-byte Spill
	and.8b	v2, v9, v18
	str	d2, [sp, #10240]                ; 8-byte Spill
	cmp	x3, #65
	cset	w8, lo
	ldr	q2, [sp, #10064]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #10048]                ; 16-byte Reload
	xtn.8b	v4, v3
	ldr	q3, [sp, #10032]                ; 16-byte Reload
	xtn.8b	v5, v3
	ldr	q3, [sp, #10016]                ; 16-byte Reload
	xtn.8b	v18, v3
	dup.8b	v23, w8
	and.8b	v2, v23, v2
	str	d2, [sp, #10224]                ; 8-byte Spill
	and.8b	v2, v23, v4
	str	d2, [sp, #10208]                ; 8-byte Spill
	and.8b	v2, v23, v5
	str	d2, [sp, #10192]                ; 8-byte Spill
	and.8b	v2, v23, v18
	str	d2, [sp, #10176]                ; 8-byte Spill
	cmp	x23, #65
	cset	w8, lo
	ldr	q2, [sp, #10000]                ; 16-byte Reload
	xtn.8b	v2, v2
	ldr	q3, [sp, #9984]                 ; 16-byte Reload
	xtn.8b	v4, v3
	xtn.8b	v5, v16
	xtn.8b	v6, v6
	dup.8b	v16, w8
	and.8b	v23, v16, v2
	and.8b	v18, v16, v4
	and.8b	v5, v16, v5
	and.8b	v6, v16, v6
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	mov	w8, #1267                       ; =0x4f3
	movk	w8, #15925, lsl #16
	dup.4s	v9, w8
	ldr	q3, [sp, #11040]                ; 16-byte Reload
	fmul.4s	v4, v3, v9
	ldr	q3, [sp, #416]                  ; 16-byte Reload
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8544]                 ; 16-byte Spill
	str	d7, [sp, #3456]                 ; 8-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #10880]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8560]                 ; 16-byte Spill
	zip2.8b	v2, v25, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #10896]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8576]                 ; 16-byte Spill
	str	d25, [sp, #3440]                ; 8-byte Spill
	zip1.8b	v2, v25, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11056]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8592]                 ; 16-byte Spill
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11072]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8608]                 ; 16-byte Spill
	str	d13, [sp, #3424]                ; 8-byte Spill
	zip1.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11088]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8624]                 ; 16-byte Spill
	zip2.8b	v2, v17, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11104]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8640]                 ; 16-byte Spill
	str	d17, [sp, #3408]                ; 8-byte Spill
	zip1.8b	v2, v17, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11120]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8656]                 ; 16-byte Spill
	zip2.8b	v2, v19, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11136]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8672]                 ; 16-byte Spill
	str	d19, [sp, #3392]                ; 8-byte Spill
	zip1.8b	v2, v19, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11152]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8688]                 ; 16-byte Spill
	zip2.8b	v2, v20, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11168]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8704]                 ; 16-byte Spill
	str	d20, [sp, #3376]                ; 8-byte Spill
	zip1.8b	v2, v20, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11184]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8720]                 ; 16-byte Spill
	zip2.8b	v2, v22, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11200]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8736]                 ; 16-byte Spill
	str	d22, [sp, #3360]                ; 8-byte Spill
	zip1.8b	v2, v22, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11216]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8752]                 ; 16-byte Spill
	zip2.8b	v2, v24, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11232]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8768]                 ; 16-byte Spill
	str	d24, [sp, #3344]                ; 8-byte Spill
	zip1.8b	v2, v24, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11248]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8784]                 ; 16-byte Spill
	zip2.8b	v2, v10, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11264]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8800]                 ; 16-byte Spill
	str	d10, [sp, #3328]                ; 8-byte Spill
	zip1.8b	v2, v10, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11280]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8816]                 ; 16-byte Spill
	zip2.8b	v2, v11, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8832]                 ; 16-byte Spill
	str	d11, [sp, #3312]                ; 8-byte Spill
	zip1.8b	v2, v11, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8848]                 ; 16-byte Spill
	zip2.8b	v2, v12, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11328]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8864]                 ; 16-byte Spill
	str	d12, [sp, #3304]                ; 8-byte Spill
	zip1.8b	v2, v12, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11344]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8880]                 ; 16-byte Spill
	zip2.8b	v2, v14, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11360]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8896]                 ; 16-byte Spill
	str	d14, [sp, #3296]                ; 8-byte Spill
	zip1.8b	v2, v14, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11376]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8912]                 ; 16-byte Spill
	zip2.8b	v2, v15, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11392]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8928]                 ; 16-byte Spill
	str	d15, [sp, #3288]                ; 8-byte Spill
	zip1.8b	v2, v15, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11408]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v15, v2
	bsl.16b	v15, v4, v3
	ldr	d7, [sp, #10224]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11424]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8944]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11440]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8960]                 ; 16-byte Spill
	zip2.8b	v2, v23, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11456]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8976]                 ; 16-byte Spill
	str	d23, [sp, #3280]                ; 8-byte Spill
	zip1.8b	v2, v23, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11472]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #8992]                 ; 16-byte Spill
	ldr	d7, [sp, #10848]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11520]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9008]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11536]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9024]                 ; 16-byte Spill
	ldr	d7, [sp, #10800]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11552]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9040]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11568]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9056]                 ; 16-byte Spill
	ldr	d7, [sp, #10752]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11584]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9072]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11600]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9088]                 ; 16-byte Spill
	ldr	d7, [sp, #10704]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11616]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9104]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11632]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9120]                 ; 16-byte Spill
	ldr	d7, [sp, #10656]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11648]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9136]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11664]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9152]                 ; 16-byte Spill
	ldr	d7, [sp, #10608]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11680]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9168]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11696]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9184]                 ; 16-byte Spill
	ldr	d7, [sp, #10560]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11712]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9200]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11728]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9216]                 ; 16-byte Spill
	ldr	d7, [sp, #10512]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11744]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9232]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9248]                 ; 16-byte Spill
	ldr	d7, [sp, #10464]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11776]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9264]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11792]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9280]                 ; 16-byte Spill
	ldr	d7, [sp, #10416]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9296]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11824]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9312]                 ; 16-byte Spill
	ldr	d7, [sp, #10368]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11840]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9328]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11856]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9344]                 ; 16-byte Spill
	ldr	d7, [sp, #10320]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11872]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9360]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11888]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9376]                 ; 16-byte Spill
	ldr	d7, [sp, #10272]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11904]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9392]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11920]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9408]                 ; 16-byte Spill
	ldr	d7, [sp, #10208]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11936]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9424]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11952]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9440]                 ; 16-byte Spill
	zip2.8b	v2, v18, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11968]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9456]                 ; 16-byte Spill
	str	d18, [sp, #3272]                ; 8-byte Spill
	zip1.8b	v2, v18, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #11984]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9472]                 ; 16-byte Spill
	ldr	d7, [sp, #10832]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12032]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9488]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12048]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9504]                 ; 16-byte Spill
	ldr	d7, [sp, #10784]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12064]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9520]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12080]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9536]                 ; 16-byte Spill
	ldr	d7, [sp, #10736]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12096]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9552]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12112]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9568]                 ; 16-byte Spill
	ldr	d7, [sp, #10688]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12128]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9584]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12144]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9600]                 ; 16-byte Spill
	ldr	d7, [sp, #10640]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12160]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9616]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #13840]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9632]                 ; 16-byte Spill
	ldr	d7, [sp, #10592]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12176]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9648]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12192]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9664]                 ; 16-byte Spill
	ldr	d7, [sp, #10544]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12208]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9680]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12224]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9696]                 ; 16-byte Spill
	ldr	d7, [sp, #10496]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12240]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9712]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12256]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9728]                 ; 16-byte Spill
	ldr	d7, [sp, #10448]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12272]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9744]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12288]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9760]                 ; 16-byte Spill
	ldr	d7, [sp, #10400]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12304]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9776]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12320]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9792]                 ; 16-byte Spill
	ldr	d7, [sp, #10352]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12336]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9808]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12352]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9824]                 ; 16-byte Spill
	ldr	d7, [sp, #10304]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12368]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9840]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12384]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9856]                 ; 16-byte Spill
	ldr	d7, [sp, #10256]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12400]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9872]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12416]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9888]                 ; 16-byte Spill
	ldr	d7, [sp, #10192]                ; 8-byte Reload
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12432]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9904]                 ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12448]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9920]                 ; 16-byte Spill
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12464]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9936]                 ; 16-byte Spill
	str	d5, [sp, #3264]                 ; 8-byte Spill
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12480]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9952]                 ; 16-byte Spill
	ldr	d5, [sp, #10816]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12528]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9968]                 ; 16-byte Spill
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12544]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #9984]                 ; 16-byte Spill
	ldr	d5, [sp, #10768]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12560]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #10000]                ; 16-byte Spill
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12576]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #10016]                ; 16-byte Spill
	ldr	d5, [sp, #10720]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12592]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #10032]                ; 16-byte Spill
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12608]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #10048]                ; 16-byte Spill
	ldr	d5, [sp, #10672]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12624]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #10064]                ; 16-byte Spill
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12640]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #10080]                ; 16-byte Spill
	ldr	d5, [sp, #10624]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12656]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #10096]                ; 16-byte Spill
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12672]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #10112]                ; 16-byte Spill
	ldr	d5, [sp, #10576]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12688]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #10128]                ; 16-byte Spill
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12704]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #10144]                ; 16-byte Spill
	ldr	d5, [sp, #10528]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12720]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	bsl.16b	v2, v4, v3
	str	q2, [sp, #10160]                ; 16-byte Spill
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12736]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v14, v2
	bsl.16b	v14, v4, v3
	ldr	d5, [sp, #10480]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12752]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v13, v2
	bsl.16b	v13, v4, v3
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12768]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v12, v2
	bsl.16b	v12, v4, v3
	ldr	d5, [sp, #10432]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12784]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v11, v2
	bsl.16b	v11, v4, v3
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12800]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v10, v2
	bsl.16b	v10, v4, v3
	ldr	d5, [sp, #10384]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12816]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v25, v2
	bsl.16b	v25, v4, v3
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12832]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v24, v2
	bsl.16b	v24, v4, v3
	ldr	d5, [sp, #10336]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12848]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v23, v2
	bsl.16b	v23, v4, v3
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12864]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v22, v2
	bsl.16b	v22, v4, v3
	ldr	d5, [sp, #10288]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12880]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v20, v2
	bsl.16b	v20, v4, v3
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12896]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v19, v2
	bsl.16b	v19, v4, v3
	ldr	d5, [sp, #10240]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12912]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v18, v2
	bsl.16b	v18, v4, v3
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #13856]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v17, v2
	bsl.16b	v17, v4, v3
	ldr	d5, [sp, #10176]                ; 8-byte Reload
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #13872]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v16, v2
	bsl.16b	v16, v4, v3
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #13888]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v7, v2
	bsl.16b	v7, v4, v3
	mov.16b	v5, v6
	zip2.8b	v2, v6, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #13904]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v6, v2
	bsl.16b	v6, v4, v3
	str	d5, [sp, #3256]                 ; 8-byte Spill
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #12928]                ; 16-byte Reload
	fmul.4s	v4, v4, v9
	mov.16b	v5, v2
	bsl.16b	v5, v4, v3
	ldr	q2, [sp, #11024]                ; 16-byte Reload
	fmul.4s	v2, v2, v9
	ldr	q4, [sp, #14144]                ; 16-byte Reload
	bsl.16b	v4, v2, v3
	ldr	q2, [sp, #5664]                 ; 16-byte Reload
	str	q4, [sp, #2640]                 ; 16-byte Spill
	bit.16b	v2, v4, v1
	str	q2, [sp, #5664]                 ; 16-byte Spill
	str	q2, [x9, #2176]
	ldr	q2, [sp, #10864]                ; 16-byte Reload
	fmul.4s	v2, v2, v9
	ldr	q4, [sp, #14160]                ; 16-byte Reload
	bsl.16b	v4, v2, v3
	ldr	q2, [sp, #5648]                 ; 16-byte Reload
	str	q4, [sp, #2624]                 ; 16-byte Spill
	bit.16b	v2, v4, v0
	str	q2, [sp, #5648]                 ; 16-byte Spill
	str	q2, [x9, #2192]
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q4, [sp, #8544]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #5680]                 ; 16-byte Spill
	str	q2, [x9, #2224]
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q4, [sp, #8560]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #5696]                 ; 16-byte Spill
	str	q2, [x9, #2208]
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q4, [sp, #8576]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #5712]                 ; 16-byte Spill
	str	q2, [x9, #2256]
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q4, [sp, #8592]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #5728]                 ; 16-byte Spill
	str	q2, [x9, #2240]
	ldr	q2, [sp, #5744]                 ; 16-byte Reload
	ldr	q4, [sp, #8608]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #5744]                 ; 16-byte Spill
	str	q2, [x9, #2288]
	ldr	q2, [sp, #5760]                 ; 16-byte Reload
	ldr	q4, [sp, #8624]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #5760]                 ; 16-byte Spill
	str	q2, [x9, #2272]
	ldr	q2, [sp, #5776]                 ; 16-byte Reload
	ldr	q4, [sp, #8640]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #5776]                 ; 16-byte Spill
	str	q2, [x9, #2320]
	ldr	q2, [sp, #5792]                 ; 16-byte Reload
	ldr	q4, [sp, #8656]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #5792]                 ; 16-byte Spill
	str	q2, [x9, #2304]
	ldr	q2, [sp, #5808]                 ; 16-byte Reload
	ldr	q4, [sp, #8672]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #5808]                 ; 16-byte Spill
	str	q2, [x9, #2352]
	ldr	q2, [sp, #5824]                 ; 16-byte Reload
	ldr	q4, [sp, #8688]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #5824]                 ; 16-byte Spill
	str	q2, [x9, #2336]
	ldr	q2, [sp, #5840]                 ; 16-byte Reload
	ldr	q4, [sp, #8704]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #5840]                 ; 16-byte Spill
	str	q2, [x9, #2384]
	ldr	q2, [sp, #5856]                 ; 16-byte Reload
	ldr	q4, [sp, #8720]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #5856]                 ; 16-byte Spill
	str	q2, [x9, #2368]
	ldr	q2, [sp, #5872]                 ; 16-byte Reload
	ldr	q4, [sp, #8736]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #5872]                 ; 16-byte Spill
	str	q2, [x9, #2416]
	ldr	q2, [sp, #5888]                 ; 16-byte Reload
	ldr	q4, [sp, #8752]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #5888]                 ; 16-byte Spill
	str	q2, [x9, #2400]
	ldr	q2, [sp, #5904]                 ; 16-byte Reload
	ldr	q4, [sp, #8768]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #5904]                 ; 16-byte Spill
	str	q2, [x9, #2448]
	ldr	q2, [sp, #5920]                 ; 16-byte Reload
	ldr	q4, [sp, #8784]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #5920]                 ; 16-byte Spill
	str	q2, [x9, #2432]
	ldr	q2, [sp, #5936]                 ; 16-byte Reload
	ldr	q4, [sp, #8800]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #5936]                 ; 16-byte Spill
	str	q2, [x9, #2480]
	ldr	q2, [sp, #5952]                 ; 16-byte Reload
	ldr	q4, [sp, #8816]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #5952]                 ; 16-byte Spill
	str	q2, [x9, #2464]
	ldr	q2, [sp, #5968]                 ; 16-byte Reload
	ldr	q4, [sp, #8832]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #5968]                 ; 16-byte Spill
	str	q2, [x9, #2512]
	ldr	q2, [sp, #5984]                 ; 16-byte Reload
	ldr	q4, [sp, #8848]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #5984]                 ; 16-byte Spill
	str	q2, [x9, #2496]
	ldr	q2, [sp, #6000]                 ; 16-byte Reload
	ldr	q4, [sp, #8864]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6000]                 ; 16-byte Spill
	str	q2, [x9, #2544]
	ldr	q2, [sp, #6016]                 ; 16-byte Reload
	ldr	q4, [sp, #8880]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6016]                 ; 16-byte Spill
	str	q2, [x9, #2528]
	ldr	q2, [sp, #6032]                 ; 16-byte Reload
	ldr	q4, [sp, #8896]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6032]                 ; 16-byte Spill
	str	q2, [x9, #2576]
	ldr	q2, [sp, #6048]                 ; 16-byte Reload
	ldr	q4, [sp, #8912]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6048]                 ; 16-byte Spill
	str	q2, [x9, #2560]
	ldr	q2, [sp, #6064]                 ; 16-byte Reload
	ldr	q4, [sp, #8928]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6064]                 ; 16-byte Spill
	str	q2, [x9, #2608]
	ldr	q2, [sp, #6080]                 ; 16-byte Reload
	str	q15, [sp, #2160]                ; 16-byte Spill
	bit.16b	v2, v15, v1
	str	q2, [sp, #6080]                 ; 16-byte Spill
	str	q2, [x9, #2592]
	ldr	q2, [sp, #6096]                 ; 16-byte Reload
	ldr	q4, [sp, #8944]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6096]                 ; 16-byte Spill
	str	q2, [x9, #2640]
	ldr	q2, [sp, #6112]                 ; 16-byte Reload
	ldr	q4, [sp, #8960]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6112]                 ; 16-byte Spill
	str	q2, [x9, #2624]
	ldr	q2, [sp, #6128]                 ; 16-byte Reload
	ldr	q4, [sp, #8976]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6128]                 ; 16-byte Spill
	str	q2, [x9, #2672]
	ldr	q2, [sp, #6144]                 ; 16-byte Reload
	ldr	q4, [sp, #8992]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6144]                 ; 16-byte Spill
	str	q2, [x9, #2656]
	ldr	q2, [sp, #11504]                ; 16-byte Reload
	fmul.4s	v2, v2, v9
	ldr	q4, [sp, #14112]                ; 16-byte Reload
	bsl.16b	v4, v2, v3
	ldr	q2, [sp, #6176]                 ; 16-byte Reload
	str	q4, [sp, #2048]                 ; 16-byte Spill
	bit.16b	v2, v4, v1
	str	q2, [sp, #6176]                 ; 16-byte Spill
	str	q2, [x9, #2688]
	ldr	q2, [sp, #11488]                ; 16-byte Reload
	fmul.4s	v2, v2, v9
	ldr	q4, [sp, #14128]                ; 16-byte Reload
	bsl.16b	v4, v2, v3
	ldr	q2, [sp, #6160]                 ; 16-byte Reload
	str	q4, [sp, #2032]                 ; 16-byte Spill
	bit.16b	v2, v4, v0
	str	q2, [sp, #6160]                 ; 16-byte Spill
	str	q2, [x9, #2704]
	ldr	q2, [sp, #6192]                 ; 16-byte Reload
	ldr	q4, [sp, #9008]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6192]                 ; 16-byte Spill
	str	q2, [x9, #2736]
	ldr	q2, [sp, #6208]                 ; 16-byte Reload
	ldr	q4, [sp, #9024]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6208]                 ; 16-byte Spill
	str	q2, [x9, #2720]
	ldr	q2, [sp, #6224]                 ; 16-byte Reload
	ldr	q4, [sp, #9040]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6224]                 ; 16-byte Spill
	str	q2, [x9, #2768]
	ldr	q2, [sp, #6240]                 ; 16-byte Reload
	ldr	q4, [sp, #9056]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6240]                 ; 16-byte Spill
	str	q2, [x9, #2752]
	ldr	q2, [sp, #6256]                 ; 16-byte Reload
	ldr	q4, [sp, #9072]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6256]                 ; 16-byte Spill
	str	q2, [x9, #2800]
	ldr	q2, [sp, #6272]                 ; 16-byte Reload
	ldr	q4, [sp, #9088]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6272]                 ; 16-byte Spill
	str	q2, [x9, #2784]
	ldr	q2, [sp, #6288]                 ; 16-byte Reload
	ldr	q4, [sp, #9104]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6288]                 ; 16-byte Spill
	str	q2, [x9, #2832]
	ldr	q2, [sp, #6304]                 ; 16-byte Reload
	ldr	q4, [sp, #9120]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6304]                 ; 16-byte Spill
	str	q2, [x9, #2816]
	ldr	q2, [sp, #6320]                 ; 16-byte Reload
	ldr	q4, [sp, #9136]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6320]                 ; 16-byte Spill
	str	q2, [x9, #2864]
	ldr	q2, [sp, #6336]                 ; 16-byte Reload
	ldr	q4, [sp, #9152]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6336]                 ; 16-byte Spill
	str	q2, [x9, #2848]
	ldr	q2, [sp, #6352]                 ; 16-byte Reload
	ldr	q4, [sp, #9168]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6352]                 ; 16-byte Spill
	str	q2, [x9, #2896]
	ldr	q2, [sp, #6368]                 ; 16-byte Reload
	ldr	q4, [sp, #9184]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6368]                 ; 16-byte Spill
	str	q2, [x9, #2880]
	ldr	q2, [sp, #6384]                 ; 16-byte Reload
	ldr	q4, [sp, #9200]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6384]                 ; 16-byte Spill
	str	q2, [x9, #2928]
	ldr	q2, [sp, #6400]                 ; 16-byte Reload
	ldr	q4, [sp, #9216]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6400]                 ; 16-byte Spill
	str	q2, [x9, #2912]
	ldr	q2, [sp, #6416]                 ; 16-byte Reload
	ldr	q4, [sp, #9232]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6416]                 ; 16-byte Spill
	str	q2, [x9, #2960]
	ldr	q2, [sp, #6432]                 ; 16-byte Reload
	ldr	q4, [sp, #9248]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6432]                 ; 16-byte Spill
	str	q2, [x9, #2944]
	ldr	q2, [sp, #6448]                 ; 16-byte Reload
	ldr	q4, [sp, #9264]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6448]                 ; 16-byte Spill
	str	q2, [x9, #2992]
	ldr	q2, [sp, #6464]                 ; 16-byte Reload
	ldr	q4, [sp, #9280]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6464]                 ; 16-byte Spill
	str	q2, [x9, #2976]
	ldr	q2, [sp, #6480]                 ; 16-byte Reload
	ldr	q4, [sp, #9296]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6480]                 ; 16-byte Spill
	str	q2, [x9, #3024]
	ldr	q2, [sp, #6496]                 ; 16-byte Reload
	ldr	q4, [sp, #9312]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6496]                 ; 16-byte Spill
	str	q2, [x9, #3008]
	ldr	q2, [sp, #6512]                 ; 16-byte Reload
	ldr	q4, [sp, #9328]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6512]                 ; 16-byte Spill
	str	q2, [x9, #3056]
	ldr	q2, [sp, #6528]                 ; 16-byte Reload
	ldr	q4, [sp, #9344]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6528]                 ; 16-byte Spill
	str	q2, [x9, #3040]
	ldr	q2, [sp, #6544]                 ; 16-byte Reload
	ldr	q4, [sp, #9360]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6544]                 ; 16-byte Spill
	str	q2, [x9, #3088]
	ldr	q2, [sp, #6560]                 ; 16-byte Reload
	ldr	q4, [sp, #9376]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6560]                 ; 16-byte Spill
	str	q2, [x9, #3072]
	ldr	q2, [sp, #6576]                 ; 16-byte Reload
	ldr	q4, [sp, #9392]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6576]                 ; 16-byte Spill
	str	q2, [x9, #3120]
	ldr	q2, [sp, #6592]                 ; 16-byte Reload
	ldr	q4, [sp, #9408]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6592]                 ; 16-byte Spill
	str	q2, [x9, #3104]
	ldr	q2, [sp, #6608]                 ; 16-byte Reload
	ldr	q4, [sp, #9424]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6608]                 ; 16-byte Spill
	str	q2, [x9, #3152]
	ldr	q2, [sp, #6624]                 ; 16-byte Reload
	ldr	q4, [sp, #9440]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6624]                 ; 16-byte Spill
	str	q2, [x9, #3136]
	ldr	q2, [sp, #6640]                 ; 16-byte Reload
	ldr	q4, [sp, #9456]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6640]                 ; 16-byte Spill
	str	q2, [x9, #3184]
	ldr	q2, [sp, #6656]                 ; 16-byte Reload
	ldr	q4, [sp, #9472]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6656]                 ; 16-byte Spill
	str	q2, [x9, #3168]
	ldr	q2, [sp, #12016]                ; 16-byte Reload
	fmul.4s	v2, v2, v9
	ldr	q4, [sp, #14080]                ; 16-byte Reload
	bsl.16b	v4, v2, v3
	ldr	q2, [sp, #6688]                 ; 16-byte Reload
	str	q4, [sp, #1760]                 ; 16-byte Spill
	bit.16b	v2, v4, v1
	str	q2, [sp, #6688]                 ; 16-byte Spill
	str	q2, [x9, #3200]
	ldr	q2, [sp, #12000]                ; 16-byte Reload
	fmul.4s	v2, v2, v9
	ldr	q4, [sp, #14096]                ; 16-byte Reload
	bsl.16b	v4, v2, v3
	ldr	q2, [sp, #6672]                 ; 16-byte Reload
	str	q4, [sp, #1744]                 ; 16-byte Spill
	bit.16b	v2, v4, v0
	str	q2, [sp, #6672]                 ; 16-byte Spill
	str	q2, [x9, #3216]
	ldr	q2, [sp, #6704]                 ; 16-byte Reload
	ldr	q4, [sp, #9488]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6704]                 ; 16-byte Spill
	str	q2, [x9, #3248]
	ldr	q2, [sp, #6720]                 ; 16-byte Reload
	ldr	q4, [sp, #9504]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6720]                 ; 16-byte Spill
	str	q2, [x9, #3232]
	ldr	q2, [sp, #6736]                 ; 16-byte Reload
	ldr	q4, [sp, #9520]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6736]                 ; 16-byte Spill
	str	q2, [x9, #3280]
	ldr	q2, [sp, #6752]                 ; 16-byte Reload
	ldr	q4, [sp, #9536]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6752]                 ; 16-byte Spill
	str	q2, [x9, #3264]
	ldr	q2, [sp, #6768]                 ; 16-byte Reload
	ldr	q4, [sp, #9552]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6768]                 ; 16-byte Spill
	str	q2, [x9, #3312]
	ldr	q2, [sp, #6784]                 ; 16-byte Reload
	ldr	q4, [sp, #9568]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6784]                 ; 16-byte Spill
	str	q2, [x9, #3296]
	ldr	q2, [sp, #6800]                 ; 16-byte Reload
	ldr	q4, [sp, #9584]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6800]                 ; 16-byte Spill
	str	q2, [x9, #3344]
	ldr	q2, [sp, #6816]                 ; 16-byte Reload
	ldr	q4, [sp, #9600]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6816]                 ; 16-byte Spill
	str	q2, [x9, #3328]
	ldr	q2, [sp, #6832]                 ; 16-byte Reload
	ldr	q4, [sp, #9616]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6832]                 ; 16-byte Spill
	str	q2, [x9, #3376]
	ldr	q2, [sp, #6848]                 ; 16-byte Reload
	ldr	q4, [sp, #9632]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6848]                 ; 16-byte Spill
	str	q2, [x9, #3360]
	ldr	q2, [sp, #6864]                 ; 16-byte Reload
	ldr	q4, [sp, #9648]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6864]                 ; 16-byte Spill
	str	q2, [x9, #3408]
	ldr	q2, [sp, #6880]                 ; 16-byte Reload
	ldr	q4, [sp, #9664]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6880]                 ; 16-byte Spill
	str	q2, [x9, #3392]
	ldr	q2, [sp, #6896]                 ; 16-byte Reload
	ldr	q4, [sp, #9680]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6896]                 ; 16-byte Spill
	str	q2, [x9, #3440]
	ldr	q2, [sp, #6912]                 ; 16-byte Reload
	ldr	q4, [sp, #9696]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6912]                 ; 16-byte Spill
	str	q2, [x9, #3424]
	ldr	q2, [sp, #6928]                 ; 16-byte Reload
	ldr	q4, [sp, #9712]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6928]                 ; 16-byte Spill
	str	q2, [x9, #3472]
	ldr	q2, [sp, #6944]                 ; 16-byte Reload
	ldr	q4, [sp, #9728]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6944]                 ; 16-byte Spill
	str	q2, [x9, #3456]
	ldr	q2, [sp, #6960]                 ; 16-byte Reload
	ldr	q4, [sp, #9744]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6960]                 ; 16-byte Spill
	str	q2, [x9, #3504]
	ldr	q2, [sp, #6976]                 ; 16-byte Reload
	ldr	q4, [sp, #9760]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #6976]                 ; 16-byte Spill
	str	q2, [x9, #3488]
	ldr	q2, [sp, #6992]                 ; 16-byte Reload
	ldr	q4, [sp, #9776]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #6992]                 ; 16-byte Spill
	str	q2, [x9, #3536]
	ldr	q2, [sp, #7008]                 ; 16-byte Reload
	ldr	q4, [sp, #9792]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #7008]                 ; 16-byte Spill
	str	q2, [x9, #3520]
	ldr	q2, [sp, #7024]                 ; 16-byte Reload
	ldr	q4, [sp, #9808]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #7024]                 ; 16-byte Spill
	str	q2, [x9, #3568]
	ldr	q2, [sp, #7040]                 ; 16-byte Reload
	ldr	q4, [sp, #9824]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #7040]                 ; 16-byte Spill
	str	q2, [x9, #3552]
	ldr	q2, [sp, #7056]                 ; 16-byte Reload
	ldr	q4, [sp, #9840]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #7056]                 ; 16-byte Spill
	str	q2, [x9, #3600]
	ldr	q2, [sp, #7072]                 ; 16-byte Reload
	ldr	q4, [sp, #9856]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #7072]                 ; 16-byte Spill
	str	q2, [x9, #3584]
	ldr	q2, [sp, #7088]                 ; 16-byte Reload
	ldr	q4, [sp, #9872]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #7088]                 ; 16-byte Spill
	str	q2, [x9, #3632]
	ldr	q2, [sp, #7104]                 ; 16-byte Reload
	ldr	q4, [sp, #9888]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #7104]                 ; 16-byte Spill
	str	q2, [x9, #3616]
	ldr	q2, [sp, #7120]                 ; 16-byte Reload
	ldr	q4, [sp, #9904]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #7120]                 ; 16-byte Spill
	str	q2, [x9, #3664]
	ldr	q2, [sp, #7136]                 ; 16-byte Reload
	ldr	q4, [sp, #9920]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #7136]                 ; 16-byte Spill
	str	q2, [x9, #3648]
	ldr	q2, [sp, #7152]                 ; 16-byte Reload
	ldr	q4, [sp, #9936]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #7152]                 ; 16-byte Spill
	str	q2, [x9, #3696]
	ldr	q2, [sp, #7168]                 ; 16-byte Reload
	ldr	q4, [sp, #9952]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #7168]                 ; 16-byte Spill
	str	q2, [x9, #3680]
	ldr	q2, [sp, #12512]                ; 16-byte Reload
	fmul.4s	v2, v2, v9
	ldr	q4, [sp, #14048]                ; 16-byte Reload
	mov.16b	v15, v4
	bsl.16b	v4, v2, v3
	ldr	q2, [sp, #7200]                 ; 16-byte Reload
	str	q4, [sp, #2352]                 ; 16-byte Spill
	bit.16b	v2, v4, v1
	str	q2, [sp, #7200]                 ; 16-byte Spill
	str	q2, [x9, #3712]
	ldr	q2, [sp, #12496]                ; 16-byte Reload
	fmul.4s	v2, v2, v9
	ldr	q9, [sp, #14064]                ; 16-byte Reload
	bit.16b	v3, v2, v9
	ldr	q2, [sp, #7184]                 ; 16-byte Reload
	str	q3, [sp, #2304]                 ; 16-byte Spill
	bit.16b	v2, v3, v0
	str	q2, [sp, #7184]                 ; 16-byte Spill
	str	q2, [x9, #3728]
	ldr	q2, [sp, #7216]                 ; 16-byte Reload
	ldr	q3, [sp, #9968]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #7216]                 ; 16-byte Spill
	str	q2, [x9, #3760]
	ldr	q2, [sp, #7232]                 ; 16-byte Reload
	ldr	q3, [sp, #9984]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #7232]                 ; 16-byte Spill
	str	q2, [x9, #3744]
	ldr	q2, [sp, #7248]                 ; 16-byte Reload
	ldr	q3, [sp, #10000]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #7248]                 ; 16-byte Spill
	str	q2, [x9, #3792]
	ldr	q2, [sp, #7264]                 ; 16-byte Reload
	ldr	q3, [sp, #10016]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #7264]                 ; 16-byte Spill
	str	q2, [x9, #3776]
	ldr	q2, [sp, #7280]                 ; 16-byte Reload
	ldr	q3, [sp, #10032]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #7280]                 ; 16-byte Spill
	str	q2, [x9, #3824]
	ldr	q2, [sp, #7296]                 ; 16-byte Reload
	ldr	q3, [sp, #10048]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #7296]                 ; 16-byte Spill
	str	q2, [x9, #3808]
	ldr	q2, [sp, #7312]                 ; 16-byte Reload
	ldr	q3, [sp, #10064]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #7312]                 ; 16-byte Spill
	str	q2, [x9, #3856]
	ldr	q2, [sp, #7328]                 ; 16-byte Reload
	ldr	q3, [sp, #10080]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #7328]                 ; 16-byte Spill
	str	q2, [x9, #3840]
	ldr	q2, [sp, #7344]                 ; 16-byte Reload
	ldr	q3, [sp, #10096]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #7344]                 ; 16-byte Spill
	str	q2, [x9, #3888]
	ldr	q2, [sp, #7360]                 ; 16-byte Reload
	ldr	q3, [sp, #10112]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #7360]                 ; 16-byte Spill
	str	q2, [x9, #3872]
	ldr	q2, [sp, #7376]                 ; 16-byte Reload
	ldr	q3, [sp, #10128]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #7376]                 ; 16-byte Spill
	str	q2, [x9, #3920]
	ldr	q2, [sp, #7392]                 ; 16-byte Reload
	ldr	q3, [sp, #10144]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #7392]                 ; 16-byte Spill
	str	q2, [x9, #3904]
	ldr	q2, [sp, #7408]                 ; 16-byte Reload
	ldr	q3, [sp, #10160]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #7408]                 ; 16-byte Spill
	str	q2, [x9, #3952]
	ldr	q2, [sp, #7424]                 ; 16-byte Reload
	str	q14, [sp, #2720]                ; 16-byte Spill
	bit.16b	v2, v14, v1
	str	q2, [sp, #7424]                 ; 16-byte Spill
	str	q2, [x9, #3936]
	ldr	q2, [sp, #7440]                 ; 16-byte Reload
	str	q13, [sp, #2736]                ; 16-byte Spill
	bit.16b	v2, v13, v0
	str	q2, [sp, #7440]                 ; 16-byte Spill
	str	q2, [x9, #3984]
	ldr	q2, [sp, #7504]                 ; 16-byte Reload
	str	q12, [sp, #2752]                ; 16-byte Spill
	bit.16b	v2, v12, v1
	str	q2, [sp, #7504]                 ; 16-byte Spill
	str	q2, [x9, #3968]
	ldr	q2, [sp, #7520]                 ; 16-byte Reload
	str	q11, [sp, #2832]                ; 16-byte Spill
	bit.16b	v2, v11, v0
	str	q2, [sp, #7520]                 ; 16-byte Spill
	str	q2, [x9, #4016]
	ldr	q2, [sp, #7536]                 ; 16-byte Reload
	str	q10, [sp, #2848]                ; 16-byte Spill
	bit.16b	v2, v10, v1
	str	q2, [sp, #7536]                 ; 16-byte Spill
	str	q2, [x9, #4000]
	ldr	q2, [sp, #7552]                 ; 16-byte Reload
	str	q25, [sp, #2928]                ; 16-byte Spill
	bit.16b	v2, v25, v0
	str	q2, [sp, #7552]                 ; 16-byte Spill
	str	q2, [x9, #4048]
	ldr	q2, [sp, #7568]                 ; 16-byte Reload
	str	q24, [sp, #2944]                ; 16-byte Spill
	bit.16b	v2, v24, v1
	str	q2, [sp, #7568]                 ; 16-byte Spill
	str	q2, [x9, #4032]
	ldr	q2, [sp, #7584]                 ; 16-byte Reload
	str	q23, [sp, #3024]                ; 16-byte Spill
	bit.16b	v2, v23, v0
	str	q2, [sp, #7584]                 ; 16-byte Spill
	str	q2, [x9, #4080]
	ldr	q2, [sp, #7600]                 ; 16-byte Reload
	str	q22, [sp, #3040]                ; 16-byte Spill
	bit.16b	v2, v22, v1
	str	q2, [sp, #7600]                 ; 16-byte Spill
	str	q2, [x9, #4064]
	ldr	q2, [sp, #7616]                 ; 16-byte Reload
	str	q20, [sp, #3104]                ; 16-byte Spill
	bit.16b	v2, v20, v0
	str	q2, [sp, #7616]                 ; 16-byte Spill
	str	q2, [x9, #4112]
	ldr	q2, [sp, #7632]                 ; 16-byte Reload
	str	q19, [sp, #3120]                ; 16-byte Spill
	bit.16b	v2, v19, v1
	str	q2, [sp, #7632]                 ; 16-byte Spill
	str	q2, [x9, #4096]
	ldr	q25, [sp, #7648]                ; 16-byte Reload
	str	q18, [sp, #3152]                ; 16-byte Spill
	bit.16b	v25, v18, v0
	str	q25, [x9, #4144]
	ldr	q24, [sp, #7664]                ; 16-byte Reload
	str	q17, [sp, #3168]                ; 16-byte Spill
	bit.16b	v24, v17, v1
	str	q24, [x9, #4128]
	ldr	q23, [sp, #7680]                ; 16-byte Reload
	str	q16, [sp, #3184]                ; 16-byte Spill
	bit.16b	v23, v16, v0
	str	q23, [x9, #4176]
	ldr	q22, [sp, #7696]                ; 16-byte Reload
	str	q7, [sp, #3200]                 ; 16-byte Spill
	bit.16b	v22, v7, v1
	str	q22, [x9, #4160]
	ldr	q19, [sp, #7728]                ; 16-byte Reload
	str	q5, [sp, #3232]                 ; 16-byte Spill
	bit.16b	v19, v5, v1
	ldr	q20, [sp, #7712]                ; 16-byte Reload
	str	q6, [sp, #3216]                 ; 16-byte Spill
	bit.16b	v20, v6, v0
	str	q20, [x9, #4208]
	str	q19, [x9, #4192]
	mvni.4s	v7, #127, msl #16
	ldr	q18, [sp, #8272]                ; 16-byte Reload
	bit.16b	v18, v7, v0
	ldr	q17, [sp, #8288]                ; 16-byte Reload
	bit.16b	v17, v7, v1
LBB0_63:                                ; %direct.true1466
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, x0, x24
	ldp	q2, q4, [x8]
	and.16b	v4, v0, v4
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v17, v2
	fmaxnm.4s	v4, v18, v4
	bit.16b	v18, v4, v0
	bit.16b	v17, v2, v1
	add	x24, x24, #32
	cmp	x24, #512
	b.ne	LBB0_63
; %bb.64:                               ; %direct.false1467
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q16, [sp, #13680]               ; 16-byte Reload
	bit.16b	v16, v7, v0
	ldr	q6, [sp, #13696]                ; 16-byte Reload
	bit.16b	v6, v7, v1
	add	x11, x0, #512
	add	x12, x0, #1024
	add	x1, x0, #1536
	ldr	q10, [sp, #13760]               ; 16-byte Reload
	ldr	q11, [sp, #13744]               ; 16-byte Reload
	ldr	q3, [sp, #13728]                ; 16-byte Reload
	ldr	q5, [sp, #13712]                ; 16-byte Reload
LBB0_65:                                ; %direct.true1477
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x11, x8
	ldp	q2, q4, [x10]
	and.16b	v4, v0, v4
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v6, v2
	fmaxnm.4s	v4, v16, v4
	bit.16b	v16, v4, v0
	bit.16b	v6, v2, v1
	add	x8, x8, #32
	cmp	x8, #512
	b.ne	LBB0_65
; %bb.66:                               ; %direct.false1478
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x8, #0                          ; =0x0
	bit.16b	v5, v7, v0
	bit.16b	v3, v7, v1
LBB0_67:                                ; %direct.true1488
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x12, x8
	ldp	q2, q4, [x10]
	and.16b	v4, v0, v4
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v3, v2
	fmaxnm.4s	v4, v5, v4
	bit.16b	v5, v4, v0
	bit.16b	v3, v2, v1
	add	x8, x8, #32
	cmp	x8, #512
	b.ne	LBB0_67
; %bb.68:                               ; %direct.false1489
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q25, [sp, #7648]                ; 16-byte Spill
	str	q24, [sp, #7664]                ; 16-byte Spill
	str	q23, [sp, #7680]                ; 16-byte Spill
	str	q22, [sp, #7696]                ; 16-byte Spill
	str	q20, [sp, #7712]                ; 16-byte Spill
	str	q19, [sp, #7728]                ; 16-byte Spill
	str	q16, [sp, #13680]               ; 16-byte Spill
	str	q6, [sp, #13696]                ; 16-byte Spill
	str	q5, [sp, #13712]                ; 16-byte Spill
	str	q3, [sp, #13728]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	bit.16b	v11, v7, v0
	bit.16b	v10, v7, v1
LBB0_69:                                ; %direct.true1499
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x1, x8
	ldp	q2, q4, [x10]
	and.16b	v4, v0, v4
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v10, v2
	fmaxnm.4s	v4, v11, v4
	bit.16b	v11, v4, v0
	bit.16b	v10, v2, v1
	add	x8, x8, #32
	cmp	x8, #512
	b.ne	LBB0_69
; %bb.70:                               ; %direct.false1500
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x23, #0                         ; =0x0
	uzp1.8h	v2, v15, v9
	str	q2, [sp, #3136]                 ; 16-byte Spill
	ldr	q2, [sp, #14096]                ; 16-byte Reload
	ldr	q3, [sp, #14080]                ; 16-byte Reload
	uzp1.8h	v2, v3, v2
	str	q2, [sp, #3088]                 ; 16-byte Spill
	ldr	q2, [sp, #14128]                ; 16-byte Reload
	ldr	q3, [sp, #14112]                ; 16-byte Reload
	uzp1.8h	v2, v3, v2
	str	q2, [sp, #3072]                 ; 16-byte Spill
	ldr	q2, [sp, #14160]                ; 16-byte Reload
	ldr	q3, [sp, #14144]                ; 16-byte Reload
	uzp1.8h	v2, v3, v2
	str	q2, [sp, #3056]                 ; 16-byte Spill
	str	q17, [sp, #8288]                ; 16-byte Spill
	ldr	q2, [sp, #10928]                ; 16-byte Reload
	fmaxnm.4s	v3, v2, v17
	str	q3, [sp, #14032]                ; 16-byte Spill
	fsub.4s	v2, v2, v3
	and.16b	v7, v1, v2
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v15, w8
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v14, w8
	fcmge.4s	v2, v7, v15
	fcmge.4s	v4, v14, v7
	and.16b	v2, v2, v4
	str	q18, [sp, #8272]                ; 16-byte Spill
	ldr	q3, [sp, #10912]                ; 16-byte Reload
	fmaxnm.4s	v4, v3, v18
	str	q4, [sp, #14016]                ; 16-byte Spill
	fsub.4s	v4, v3, v4
	and.16b	v12, v0, v4
	fcmge.4s	v4, v12, v15
	fcmge.4s	v5, v14, v12
	and.16b	v4, v4, v5
	and.16b	v4, v4, v12
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v23, w8
	fmul.4s	v5, v4, v23
	movi.4s	v3, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v16, v17
	bsl.16b	v16, v3, v5
	fadd.4s	v5, v5, v16
	fsub.4s	v5, v5, v16
	and.16b	v16, v2, v7
	fmul.4s	v2, v16, v23
	bsl.16b	v17, v3, v2
	fadd.4s	v2, v2, v17
	fsub.4s	v17, v2, v17
	fcvtzs.4s	v5, v5
	mov	w8, #29184                      ; =0x7200
	movk	w8, #16177, lsl #16
	dup.4s	v6, w8
	scvtf.4s	v18, v5
	fmul.4s	v22, v18, v6
	fsub.4s	v4, v4, v22
	fcvtzs.4s	v25, v17
	scvtf.4s	v17, v25
	fmul.4s	v22, v17, v6
	fsub.4s	v16, v16, v22
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #13759, lsl #16
	dup.4s	v2, w8
	fmul.4s	v17, v17, v2
	fsub.4s	v20, v16, v17
	fmul.4s	v16, v18, v2
	fsub.4s	v4, v4, v16
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v17, w8
	fmul.4s	v18, v4, v17
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v22, w8
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v24, w8
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v9, w8
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v19, w8
	fadd.4s	v18, v18, v19
	fmul.4s	v18, v4, v18
	movi.4s	v3, #63, lsl #24
	fadd.4s	v18, v18, v3
	movi.4s	v16, #63, lsl #24
	str	q10, [sp, #13760]               ; 16-byte Spill
	str	q11, [sp, #13744]               ; 16-byte Spill
	fmul.4s	v3, v4, v4
	fmul.4s	v3, v3, v18
	fmul.4s	v18, v20, v17
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v20, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v20, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v20, v18
	fadd.4s	v18, v18, v19
	mov.16b	v10, v19
	fmul.4s	v18, v20, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v20, v20
	fmul.4s	v18, v19, v18
	fadd.4s	v18, v20, v18
	fadd.4s	v3, v4, v3
	fmov.4s	v13, #1.00000000
	fadd.4s	v4, v18, v13
	sshr.4s	v18, v25, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v4, v4, v19
	fadd.4s	v3, v3, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v3, v3, v20
	sub.4s	v18, v25, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	shl.4s	v5, v18, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	str	q7, [sp, #2960]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v7
	bic.16b	v4, v4, v5
	str	q12, [sp, #3008]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v12
	bic.16b	v3, v3, v5
	fcmgt.4s	v5, v12, v14
	mvni.4s	v16, #127, msl #16
	fneg.4s	v25, v16
	bit.16b	v3, v25, v5
	str	q3, [sp, #2992]                 ; 16-byte Spill
	fcmgt.4s	v3, v7, v14
	bsl.16b	v3, v25, v4
	str	q3, [sp, #2976]                 ; 16-byte Spill
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	ldr	q4, [sp, #10960]                ; 16-byte Reload
	fmaxnm.4s	v3, v4, v3
	str	q3, [sp, #14080]                ; 16-byte Spill
	fsub.4s	v3, v4, v3
	and.16b	v12, v1, v3
	fcmge.4s	v3, v12, v15
	fcmge.4s	v4, v14, v12
	and.16b	v3, v3, v4
	ldr	q4, [sp, #13680]                ; 16-byte Reload
	ldr	q5, [sp, #10944]                ; 16-byte Reload
	fmaxnm.4s	v4, v5, v4
	str	q4, [sp, #14000]                ; 16-byte Spill
	fsub.4s	v4, v5, v4
	and.16b	v16, v0, v4
	fcmge.4s	v4, v16, v15
	fcmge.4s	v5, v14, v16
	and.16b	v4, v4, v5
	and.16b	v4, v4, v16
	fmul.4s	v5, v4, v23
	mvni.4s	v7, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v18, v7
	bsl.16b	v18, v19, v5
	fadd.4s	v5, v5, v18
	fsub.4s	v5, v5, v18
	and.16b	v3, v3, v12
	fmul.4s	v18, v3, v23
	bif.16b	v19, v18, v7
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	fcvtzs.4s	v5, v5
	scvtf.4s	v19, v5
	fmul.4s	v20, v19, v6
	fsub.4s	v4, v4, v20
	fcvtzs.4s	v18, v18
	scvtf.4s	v20, v18
	fmul.4s	v7, v20, v6
	fsub.4s	v3, v3, v7
	str	q2, [sp, #14144]                ; 16-byte Spill
	fmul.4s	v7, v20, v2
	fsub.4s	v3, v3, v7
	fmul.4s	v7, v19, v2
	fsub.4s	v4, v4, v7
	mov.16b	v11, v17
	fmul.4s	v7, v4, v17
	fadd.4s	v7, v7, v22
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v7, v24
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v7, v9
	fmul.4s	v7, v4, v7
	mov.16b	v20, v10
	str	q10, [sp, #14112]               ; 16-byte Spill
	fadd.4s	v7, v7, v10
	fmul.4s	v7, v4, v7
	movi.4s	v2, #63, lsl #24
	fadd.4s	v7, v7, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v7, v19, v7
	fmul.4s	v19, v3, v17
	fadd.4s	v19, v19, v22
	mov.16b	v10, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v7
	fadd.4s	v3, v3, v13
	sshr.4s	v7, v18, #1
	shl.4s	v19, v7, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v18, v7
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q12, [sp, #2864]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v12
	bic.16b	v3, v3, v5
	str	q16, [sp, #2896]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v16
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v16, v14
	mov.16b	v2, v5
	bsl.16b	v2, v25, v4
	str	q2, [sp, #2912]                 ; 16-byte Spill
	fcmgt.4s	v4, v12, v14
	mov.16b	v2, v4
	bsl.16b	v2, v25, v3
	str	q2, [sp, #2880]                 ; 16-byte Spill
	ldr	q3, [sp, #13728]                ; 16-byte Reload
	ldr	q4, [sp, #11008]                ; 16-byte Reload
	fmaxnm.4s	v2, v4, v3
	str	q2, [sp, #14064]                ; 16-byte Spill
	fsub.4s	v3, v4, v2
	and.16b	v16, v1, v3
	fcmge.4s	v3, v16, v15
	fcmge.4s	v4, v14, v16
	and.16b	v3, v3, v4
	ldr	q4, [sp, #13712]                ; 16-byte Reload
	ldr	q5, [sp, #10976]                ; 16-byte Reload
	fmaxnm.4s	v2, v5, v4
	str	q2, [sp, #14048]                ; 16-byte Spill
	fsub.4s	v4, v5, v2
	and.16b	v17, v0, v4
	fcmge.4s	v4, v17, v15
	fcmge.4s	v5, v14, v17
	and.16b	v4, v4, v5
	and.16b	v4, v4, v17
	fmul.4s	v5, v4, v23
	mvni.4s	v2, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v2
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v16
	fmul.4s	v7, v3, v23
	bif.16b	v18, v7, v2
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	str	q6, [sp, #14128]                ; 16-byte Spill
	fmul.4s	v19, v18, v6
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v6
	fsub.4s	v3, v3, v20
	ldr	q22, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v22
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v22
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	ldr	q6, [sp, #14112]                ; 16-byte Reload
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q16, [sp, #2768]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v16
	bic.16b	v3, v3, v5
	str	q17, [sp, #2800]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v17
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v17, v14
	mov.16b	v2, v5
	bsl.16b	v2, v25, v4
	str	q2, [sp, #2816]                 ; 16-byte Spill
	fcmgt.4s	v4, v16, v14
	mov.16b	v2, v4
	bsl.16b	v2, v25, v3
	str	q2, [sp, #2784]                 ; 16-byte Spill
	ldr	q3, [sp, #13824]                ; 16-byte Reload
	ldr	q2, [sp, #13760]                ; 16-byte Reload
	fmaxnm.4s	v2, v3, v2
	str	q2, [sp, #13984]                ; 16-byte Spill
	fsub.4s	v3, v3, v2
	and.16b	v2, v1, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #10992]                ; 16-byte Reload
	ldr	q5, [sp, #13744]                ; 16-byte Reload
	fmaxnm.4s	v5, v4, v5
	str	q5, [sp, #13968]                ; 16-byte Spill
	fsub.4s	v4, v4, v5
	and.16b	v16, v0, v4
	fcmge.4s	v4, v16, v15
	fcmge.4s	v5, v14, v16
	and.16b	v4, v4, v5
	and.16b	v4, v4, v16
	fmul.4s	v5, v4, v23
	movi.4s	v6, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v6, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v23
	mov.16b	v18, v17
	bsl.16b	v18, v6, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q6, [sp, #14128]                ; 16-byte Reload
	fmul.4s	v19, v18, v6
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v6
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v22
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v22
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	str	q10, [sp, #8528]                ; 16-byte Spill
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	ldr	q6, [sp, #14112]                ; 16-byte Reload
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	movi.4s	v17, #63, lsl #24
	fadd.4s	v18, v18, v17
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v17
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2656]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q16, [sp, #2688]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v16
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v16, v14
	bit.16b	v4, v25, v5
	str	q4, [sp, #2704]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v25, v3
	mov.16b	v10, v25
	str	q2, [sp, #2672]                 ; 16-byte Spill
	ldr	q2, [sp, #2624]                 ; 16-byte Reload
	ldr	q3, [sp, #14016]                ; 16-byte Reload
	fsub.4s	v5, v2, v3
	and.16b	v2, v0, v5
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q16, [sp, #14032]               ; 16-byte Reload
	ldr	q4, [sp, #2640]                 ; 16-byte Reload
	fsub.4s	v4, v4, v16
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	str	q23, [sp, #14096]               ; 16-byte Spill
	fmul.4s	v5, v4, v23
	mvni.4s	v17, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v23
	bif.16b	v18, v7, v17
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q17, [sp, #14128]               ; 16-byte Reload
	fmul.4s	v19, v18, v17
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v17
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v22
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v22
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	ldr	q25, [sp, #8528]                ; 16-byte Reload
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	mov.16b	v23, v24
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	ldr	q24, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	movi.4s	v17, #63, lsl #24
	fadd.4s	v18, v18, v17
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v17
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2592]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #2624]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	str	q10, [sp, #14160]               ; 16-byte Spill
	bit.16b	v4, v10, v5
	str	q4, [sp, #2640]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v10, v3
	str	q2, [sp, #2608]                 ; 16-byte Spill
	ldr	q2, [sp, #8544]                 ; 16-byte Reload
	ldr	q12, [sp, #14016]               ; 16-byte Reload
	fsub.4s	v3, v2, v12
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8560]                 ; 16-byte Reload
	fsub.4s	v4, v4, v16
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	ldr	q16, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v16
	mvni.4s	v17, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v16
	bif.16b	v18, v7, v17
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q16, [sp, #14128]               ; 16-byte Reload
	fmul.4s	v19, v18, v16
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v16
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v22
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v22
	mov.16b	v16, v22
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	mov.16b	v20, v25
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	movi.4s	v17, #63, lsl #24
	fadd.4s	v18, v18, v17
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	mov.16b	v25, v11
	fadd.4s	v19, v19, v20
	mov.16b	v10, v20
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v17
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2560]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8544]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	bit.16b	v4, v6, v5
	str	q4, [sp, #8560]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	str	q2, [sp, #2576]                 ; 16-byte Spill
	mov.16b	v17, v12
	ldr	q2, [sp, #8576]                 ; 16-byte Reload
	fsub.4s	v3, v2, v12
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8592]                 ; 16-byte Reload
	ldr	q22, [sp, #14032]               ; 16-byte Reload
	fsub.4s	v4, v4, v22
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	ldr	q12, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v12
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	mov.16b	v7, v19
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v12
	bif.16b	v18, v7, v19
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q11, [sp, #14128]               ; 16-byte Reload
	fmul.4s	v19, v18, v11
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v11
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v16
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2528]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8576]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	bit.16b	v4, v6, v5
	str	q4, [sp, #8592]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	str	q2, [sp, #2544]                 ; 16-byte Spill
	ldr	q2, [sp, #8608]                 ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8624]                 ; 16-byte Reload
	fsub.4s	v4, v4, v22
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v12
	mvni.4s	v17, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v12
	bif.16b	v18, v7, v17
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v11
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v11
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v16
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	mov.16b	v16, v10
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	movi.4s	v17, #63, lsl #24
	fadd.4s	v18, v18, v17
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	mov.16b	v10, v24
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v17
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2496]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8608]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q24, [sp, #14160]               ; 16-byte Reload
	bit.16b	v4, v24, v5
	str	q4, [sp, #8624]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v24, v3
	str	q2, [sp, #2512]                 ; 16-byte Spill
	ldr	q2, [sp, #8640]                 ; 16-byte Reload
	ldr	q17, [sp, #14016]               ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8656]                 ; 16-byte Reload
	fsub.4s	v4, v4, v22
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v12
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	mov.16b	v7, v19
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v12
	bif.16b	v18, v7, v19
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v11
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v11
	fsub.4s	v3, v3, v20
	ldr	q20, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v20
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v20
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v4, v18
	mov.16b	v12, v23
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v16
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2464]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8640]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	bit.16b	v4, v24, v5
	str	q4, [sp, #8656]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v24, v3
	str	q2, [sp, #2480]                 ; 16-byte Spill
	ldr	q2, [sp, #8672]                 ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8688]                 ; 16-byte Reload
	ldr	q22, [sp, #14032]               ; 16-byte Reload
	fsub.4s	v4, v4, v22
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	ldr	q23, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v23
	mvni.4s	v18, #128, lsl #24
	movi.4s	v20, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v20, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v23
	bsl.16b	v18, v20, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v11
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v11
	fsub.4s	v3, v3, v20
	ldr	q20, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v20
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v20
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	mov.16b	v11, v16
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v16, #63, lsl #24
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v11
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v16
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2432]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8672]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	bit.16b	v4, v24, v5
	str	q4, [sp, #8688]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v24, v3
	str	q2, [sp, #2448]                 ; 16-byte Spill
	ldr	q2, [sp, #8704]                 ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8720]                 ; 16-byte Reload
	fsub.4s	v4, v4, v22
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v23
	movi.4s	v16, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v16, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v23
	mov.16b	v24, v23
	bsl.16b	v18, v16, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q23, [sp, #14128]               ; 16-byte Reload
	fmul.4s	v19, v18, v23
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v23
	fsub.4s	v3, v3, v20
	ldr	q16, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v16
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v11
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v11
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2400]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8704]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	bit.16b	v4, v6, v5
	str	q4, [sp, #8720]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	str	q2, [sp, #2416]                 ; 16-byte Spill
	ldr	q2, [sp, #8736]                 ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8752]                 ; 16-byte Reload
	ldr	q17, [sp, #14032]               ; 16-byte Reload
	fsub.4s	v4, v4, v17
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v24
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v24
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v23
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v23
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v16
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v11
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v16, #63, lsl #24
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v11
	mov.16b	v22, v11
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v16
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2368]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8736]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q23, [sp, #14160]               ; 16-byte Reload
	bit.16b	v4, v23, v5
	str	q4, [sp, #8752]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v23, v3
	str	q2, [sp, #2384]                 ; 16-byte Spill
	ldr	q2, [sp, #8768]                 ; 16-byte Reload
	ldr	q11, [sp, #14016]               ; 16-byte Reload
	fsub.4s	v3, v2, v11
	and.16b	v16, v0, v3
	fcmge.4s	v3, v16, v15
	fcmge.4s	v4, v14, v16
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8784]                 ; 16-byte Reload
	fsub.4s	v4, v4, v17
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v24
	mvni.4s	v2, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v2
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v16
	fmul.4s	v7, v3, v24
	bif.16b	v18, v7, v2
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q2, [sp, #14128]                ; 16-byte Reload
	fmul.4s	v19, v18, v2
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v2
	fsub.4s	v3, v3, v20
	ldr	q2, [sp, #14144]                ; 16-byte Reload
	fmul.4s	v19, v19, v2
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v2
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q16, [sp, #2320]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v16
	bic.16b	v3, v3, v5
	str	q6, [sp, #8768]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	bit.16b	v4, v23, v5
	str	q4, [sp, #8784]                 ; 16-byte Spill
	fcmgt.4s	v4, v16, v14
	mov.16b	v2, v4
	bsl.16b	v2, v23, v3
	str	q2, [sp, #2336]                 ; 16-byte Spill
	ldr	q2, [sp, #8800]                 ; 16-byte Reload
	fsub.4s	v3, v2, v11
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8816]                 ; 16-byte Reload
	fsub.4s	v4, v4, v17
	mov.16b	v23, v17
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v24
	movi.4s	v16, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v16, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v24
	mov.16b	v18, v17
	bsl.16b	v18, v16, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q16, [sp, #14128]               ; 16-byte Reload
	fmul.4s	v19, v18, v16
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v16
	fsub.4s	v3, v3, v20
	ldr	q16, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v16
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v17, #63, lsl #24
	fadd.4s	v18, v18, v17
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v17
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2272]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8800]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	bit.16b	v4, v6, v5
	str	q4, [sp, #8816]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	str	q2, [sp, #2288]                 ; 16-byte Spill
	ldr	q2, [sp, #8832]                 ; 16-byte Reload
	fsub.4s	v3, v2, v11
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8848]                 ; 16-byte Reload
	fsub.4s	v4, v4, v23
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v24
	mvni.4s	v17, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v24
	bif.16b	v18, v7, v17
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q11, [sp, #14128]               ; 16-byte Reload
	fmul.4s	v19, v18, v11
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v11
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v16
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v17, #63, lsl #24
	fadd.4s	v18, v18, v17
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v17
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2240]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8832]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	bit.16b	v4, v6, v5
	str	q4, [sp, #8848]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	str	q2, [sp, #2256]                 ; 16-byte Spill
	ldr	q2, [sp, #8864]                 ; 16-byte Reload
	ldr	q17, [sp, #14016]               ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8880]                 ; 16-byte Reload
	ldr	q23, [sp, #14032]               ; 16-byte Reload
	fsub.4s	v4, v4, v23
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v24
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	mov.16b	v7, v19
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v24
	bif.16b	v18, v7, v19
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v11
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v11
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v16
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2208]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8864]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	bit.16b	v4, v6, v5
	str	q4, [sp, #8880]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	str	q2, [sp, #2224]                 ; 16-byte Spill
	ldr	q2, [sp, #8896]                 ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8912]                 ; 16-byte Reload
	fsub.4s	v4, v4, v23
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v24
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v17, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v24
	bsl.16b	v18, v17, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v11
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v11
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v16
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v17, #63, lsl #24
	fadd.4s	v18, v18, v17
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v17
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2176]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8896]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q23, [sp, #14160]               ; 16-byte Reload
	bit.16b	v4, v23, v5
	str	q4, [sp, #8912]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v23, v3
	str	q2, [sp, #2192]                 ; 16-byte Spill
	ldr	q2, [sp, #8928]                 ; 16-byte Reload
	ldr	q16, [sp, #14016]               ; 16-byte Reload
	fsub.4s	v3, v2, v16
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	ldr	q17, [sp, #14032]               ; 16-byte Reload
	fsub.4s	v4, v4, v17
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v24
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v24
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v11
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v11
	fsub.4s	v3, v3, v20
	ldr	q20, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v20
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v20
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2128]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #2160]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	bit.16b	v4, v23, v5
	str	q4, [sp, #8928]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v23, v3
	str	q2, [sp, #2144]                 ; 16-byte Spill
	ldr	q2, [sp, #8944]                 ; 16-byte Reload
	fsub.4s	v3, v2, v16
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8960]                 ; 16-byte Reload
	fsub.4s	v4, v4, v17
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v24
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v17, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v24
	bsl.16b	v18, v17, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v11
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v11
	fsub.4s	v3, v3, v20
	ldr	q16, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v16
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v17, #63, lsl #24
	fadd.4s	v18, v18, v17
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v17
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2096]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8944]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	bit.16b	v4, v23, v5
	str	q4, [sp, #8960]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v23, v3
	str	q2, [sp, #2112]                 ; 16-byte Spill
	ldr	q2, [sp, #8976]                 ; 16-byte Reload
	ldr	q3, [sp, #14016]                ; 16-byte Reload
	fsub.4s	v3, v2, v3
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #8992]                 ; 16-byte Reload
	ldr	q5, [sp, #14032]                ; 16-byte Reload
	fsub.4s	v4, v4, v5
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v24
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v24
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v11
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v11
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v16
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v16, #63, lsl #24
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	mov.16b	v11, v25
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	mov.16b	v25, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v16
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2064]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #8976]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	bit.16b	v4, v23, v5
	str	q4, [sp, #8992]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v23, v3
	mov.16b	v12, v23
	str	q2, [sp, #2080]                 ; 16-byte Spill
	ldr	q17, [sp, #14000]               ; 16-byte Reload
	ldr	q2, [sp, #2032]                 ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q23, [sp, #14080]               ; 16-byte Reload
	ldr	q4, [sp, #2048]                 ; 16-byte Reload
	fsub.4s	v4, v4, v23
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v24
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v24
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q20, [sp, #14128]               ; 16-byte Reload
	fmul.4s	v19, v18, v20
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v20
	fsub.4s	v3, v3, v20
	ldr	q20, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v20
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v20
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	str	q25, [sp, #8512]                ; 16-byte Spill
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #2000]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #2032]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	bit.16b	v4, v12, v5
	str	q4, [sp, #2048]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v12, v3
	str	q2, [sp, #2016]                 ; 16-byte Spill
	ldr	q2, [sp, #9008]                 ; 16-byte Reload
	fsub.4s	v3, v2, v17
	mov.16b	v25, v17
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #9024]                 ; 16-byte Reload
	fsub.4s	v4, v4, v23
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v24
	movi.4s	v16, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v16, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v24
	mov.16b	v18, v17
	bsl.16b	v18, v16, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q16, [sp, #14128]               ; 16-byte Reload
	fmul.4s	v19, v18, v16
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v16
	fsub.4s	v3, v3, v20
	ldr	q16, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v16
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	mov.16b	v17, v22
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	ldr	q22, [sp, #8512]                ; 16-byte Reload
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v16, #63, lsl #24
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v16
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #1968]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #9008]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	bit.16b	v4, v12, v5
	str	q4, [sp, #9024]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v12, v3
	str	q2, [sp, #1984]                 ; 16-byte Spill
	ldr	q2, [sp, #9040]                 ; 16-byte Reload
	fsub.4s	v3, v2, v25
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #9056]                 ; 16-byte Reload
	fsub.4s	v4, v4, v23
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v24
	mvni.4s	v16, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v16
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v24
	bif.16b	v18, v7, v16
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q16, [sp, #14128]               ; 16-byte Reload
	fmul.4s	v19, v18, v16
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v16
	fsub.4s	v3, v3, v20
	ldr	q23, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v16, #63, lsl #24
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v16
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #1936]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #9040]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	bit.16b	v4, v12, v5
	str	q4, [sp, #9056]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v12, v3
	str	q2, [sp, #1952]                 ; 16-byte Spill
	ldr	q2, [sp, #9072]                 ; 16-byte Reload
	fsub.4s	v3, v2, v25
	and.16b	v24, v0, v3
	fcmge.4s	v3, v24, v15
	fcmge.4s	v4, v14, v24
	and.16b	v3, v3, v4
	ldr	q4, [sp, #9088]                 ; 16-byte Reload
	ldr	q16, [sp, #14080]               ; 16-byte Reload
	fsub.4s	v4, v4, v16
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	ldr	q12, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v12
	movi.4s	v2, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v24
	fmul.4s	v7, v3, v12
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q2, [sp, #14128]                ; 16-byte Reload
	fmul.4s	v19, v18, v2
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v2
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q24, [sp, #1904]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v24
	bic.16b	v3, v3, v5
	str	q6, [sp, #9072]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	bit.16b	v4, v6, v5
	str	q4, [sp, #9088]                 ; 16-byte Spill
	fcmgt.4s	v4, v24, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	str	q2, [sp, #1920]                 ; 16-byte Spill
	ldr	q2, [sp, #9104]                 ; 16-byte Reload
	fsub.4s	v3, v2, v25
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #9120]                 ; 16-byte Reload
	fsub.4s	v4, v4, v16
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v12
	movi.4s	v16, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v16, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v12
	bsl.16b	v18, v16, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q25, [sp, #14128]               ; 16-byte Reload
	fmul.4s	v19, v18, v25
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v25
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v16, #63, lsl #24
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v16
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #1872]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #9104]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	bit.16b	v4, v6, v5
	str	q4, [sp, #9120]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	str	q2, [sp, #1888]                 ; 16-byte Spill
	ldr	q2, [sp, #9136]                 ; 16-byte Reload
	ldr	q16, [sp, #14000]               ; 16-byte Reload
	fsub.4s	v3, v2, v16
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #9152]                 ; 16-byte Reload
	ldr	q24, [sp, #14080]               ; 16-byte Reload
	fsub.4s	v4, v4, v24
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v12
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v12
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v25
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v25
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #1840]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #9136]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	bit.16b	v4, v6, v5
	str	q4, [sp, #9152]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	str	q2, [sp, #1856]                 ; 16-byte Spill
	ldr	q2, [sp, #9168]                 ; 16-byte Reload
	fsub.4s	v3, v2, v16
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #9184]                 ; 16-byte Reload
	fsub.4s	v4, v4, v24
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v12
	movi.4s	v16, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v16, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v12
	bsl.16b	v18, v16, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v25
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v25
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v16, #63, lsl #24
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v16
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #1808]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #9168]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	bit.16b	v4, v6, v5
	str	q4, [sp, #9184]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	str	q2, [sp, #1824]                 ; 16-byte Spill
	ldr	q2, [sp, #9200]                 ; 16-byte Reload
	ldr	q16, [sp, #14000]               ; 16-byte Reload
	fsub.4s	v3, v2, v16
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #9216]                 ; 16-byte Reload
	ldr	q24, [sp, #14080]               ; 16-byte Reload
	fsub.4s	v4, v4, v24
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v12
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v12
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v25
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v25
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #1776]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #9200]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	bit.16b	v4, v6, v5
	str	q4, [sp, #9216]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	str	q2, [sp, #1792]                 ; 16-byte Spill
	ldr	q2, [sp, #9232]                 ; 16-byte Reload
	fsub.4s	v3, v2, v16
	and.16b	v2, v0, v3
	fcmge.4s	v3, v2, v15
	fcmge.4s	v4, v14, v2
	and.16b	v3, v3, v4
	ldr	q4, [sp, #9248]                 ; 16-byte Reload
	fsub.4s	v4, v4, v24
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v12
	movi.4s	v16, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v16, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v2
	fmul.4s	v7, v3, v12
	bsl.16b	v18, v16, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v25
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v25
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v16, #63, lsl #24
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v16
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q2, [sp, #1712]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v3, v3, v5
	str	q6, [sp, #9232]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	bit.16b	v4, v6, v5
	str	q4, [sp, #9248]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	str	q2, [sp, #1728]                 ; 16-byte Spill
	ldr	q2, [sp, #9264]                 ; 16-byte Reload
	ldr	q16, [sp, #14000]               ; 16-byte Reload
	fsub.4s	v3, v2, v16
	and.16b	v24, v0, v3
	fcmge.4s	v3, v24, v15
	fcmge.4s	v4, v14, v24
	and.16b	v3, v3, v4
	ldr	q4, [sp, #9280]                 ; 16-byte Reload
	ldr	q25, [sp, #14080]               ; 16-byte Reload
	fsub.4s	v4, v4, v25
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v12
	mvni.4s	v2, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v2
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v24
	fmul.4s	v7, v3, v12
	bif.16b	v18, v7, v2
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q2, [sp, #14128]                ; 16-byte Reload
	fmul.4s	v19, v18, v2
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v2
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	mov.16b	v2, v24
	str	q24, [sp, #1680]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v24
	bic.16b	v3, v3, v5
	str	q6, [sp, #9264]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q24, [sp, #14160]               ; 16-byte Reload
	bit.16b	v4, v24, v5
	str	q4, [sp, #9280]                 ; 16-byte Spill
	fcmgt.4s	v4, v2, v14
	mov.16b	v2, v4
	bsl.16b	v2, v24, v3
	str	q2, [sp, #1696]                 ; 16-byte Spill
	ldr	q2, [sp, #9296]                 ; 16-byte Reload
	fsub.4s	v3, v2, v16
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v15
	fcmge.4s	v4, v14, v6
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9312]                 ; 16-byte Reload
	fsub.4s	v4, v2, v25
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v12
	movi.4s	v16, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v16, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v6
	fmul.4s	v7, v3, v12
	bsl.16b	v18, v16, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q16, [sp, #14128]               ; 16-byte Reload
	fmul.4s	v19, v18, v16
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v16
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v16, #63, lsl #24
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v16
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q6, [sp, #1648]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v3, v3, v5
	str	q2, [sp, #9296]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	mov.16b	v2, v5
	bsl.16b	v2, v24, v4
	str	q2, [sp, #9312]                 ; 16-byte Spill
	fcmgt.4s	v4, v6, v14
	mov.16b	v2, v4
	bsl.16b	v2, v24, v3
	str	q2, [sp, #1664]                 ; 16-byte Spill
	ldr	q2, [sp, #9328]                 ; 16-byte Reload
	ldr	q16, [sp, #14000]               ; 16-byte Reload
	fsub.4s	v3, v2, v16
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v15
	fcmge.4s	v4, v14, v6
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9344]                 ; 16-byte Reload
	ldr	q25, [sp, #14080]               ; 16-byte Reload
	fsub.4s	v4, v2, v25
	and.16b	v24, v1, v4
	fcmge.4s	v4, v24, v15
	fcmge.4s	v5, v14, v24
	and.16b	v4, v4, v5
	and.16b	v4, v4, v24
	fmul.4s	v5, v4, v12
	mvni.4s	v2, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v2
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v6
	fmul.4s	v7, v3, v12
	bif.16b	v18, v7, v2
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q2, [sp, #14128]                ; 16-byte Reload
	fmul.4s	v19, v18, v2
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v2
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q6, [sp, #1616]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v3, v3, v5
	str	q24, [sp, #9328]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v24
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v24, v14
	ldr	q24, [sp, #14160]               ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v24, v4
	str	q2, [sp, #9344]                 ; 16-byte Spill
	fcmgt.4s	v4, v6, v14
	mov.16b	v2, v4
	bsl.16b	v2, v24, v3
	str	q2, [sp, #1632]                 ; 16-byte Spill
	ldr	q2, [sp, #9360]                 ; 16-byte Reload
	fsub.4s	v3, v2, v16
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v15
	fcmge.4s	v4, v14, v6
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9376]                 ; 16-byte Reload
	fsub.4s	v4, v2, v25
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v12
	movi.4s	v16, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v16, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v6
	fmul.4s	v7, v3, v12
	bsl.16b	v18, v16, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q25, [sp, #14128]               ; 16-byte Reload
	fmul.4s	v19, v18, v25
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v25
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v11
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v16, #63, lsl #24
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v11
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v16
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q6, [sp, #1584]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v3, v3, v5
	str	q2, [sp, #9360]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	mov.16b	v2, v5
	bsl.16b	v2, v24, v4
	str	q2, [sp, #9376]                 ; 16-byte Spill
	fcmgt.4s	v4, v6, v14
	mov.16b	v2, v4
	bsl.16b	v2, v24, v3
	str	q2, [sp, #1600]                 ; 16-byte Spill
	ldr	q2, [sp, #9392]                 ; 16-byte Reload
	ldr	q17, [sp, #14000]               ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v15
	fcmge.4s	v4, v14, v6
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9408]                 ; 16-byte Reload
	ldr	q24, [sp, #14080]               ; 16-byte Reload
	fsub.4s	v4, v2, v24
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v12
	mvni.4s	v16, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v16
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v6
	fmul.4s	v7, v3, v12
	bif.16b	v18, v7, v16
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v25
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v25
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	mov.16b	v16, v11
	fmul.4s	v18, v4, v11
	ldr	q11, [sp, #8528]                ; 16-byte Reload
	fadd.4s	v18, v18, v11
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v11
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q6, [sp, #1552]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v3, v3, v5
	str	q2, [sp, #9392]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	ldr	q7, [sp, #14160]                ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v7, v4
	str	q2, [sp, #9408]                 ; 16-byte Spill
	fcmgt.4s	v4, v6, v14
	mov.16b	v2, v4
	bsl.16b	v2, v7, v3
	str	q2, [sp, #1568]                 ; 16-byte Spill
	ldr	q2, [sp, #9424]                 ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v17, v0, v3
	fcmge.4s	v3, v17, v15
	fcmge.4s	v4, v14, v17
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9440]                 ; 16-byte Reload
	fsub.4s	v4, v2, v24
	and.16b	v6, v1, v4
	fcmge.4s	v4, v6, v15
	fcmge.4s	v5, v14, v6
	and.16b	v4, v4, v5
	and.16b	v4, v4, v6
	fmul.4s	v5, v4, v12
	movi.4s	v2, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v17
	fmul.4s	v7, v3, v12
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v25
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v25
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v23
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v23
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v11
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v11
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	mov.16b	v23, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q17, [sp, #1520]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v17
	bic.16b	v3, v3, v5
	str	q6, [sp, #9424]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v6, v14
	ldr	q10, [sp, #14160]               ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v10, v4
	str	q2, [sp, #9440]                 ; 16-byte Spill
	fcmgt.4s	v4, v17, v14
	mov.16b	v2, v4
	bsl.16b	v2, v10, v3
	mov.16b	v17, v10
	str	q2, [sp, #1536]                 ; 16-byte Spill
	ldr	q2, [sp, #9456]                 ; 16-byte Reload
	ldr	q3, [sp, #14000]                ; 16-byte Reload
	fsub.4s	v3, v2, v3
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v15
	fcmge.4s	v4, v14, v6
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9472]                 ; 16-byte Reload
	ldr	q4, [sp, #14080]                ; 16-byte Reload
	fsub.4s	v4, v2, v4
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v12
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v6
	fmul.4s	v7, v3, v12
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v25
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v25
	fsub.4s	v3, v3, v20
	ldr	q20, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v20
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v20
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v11
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	mov.16b	v12, v9
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	mov.16b	v10, v23
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v11
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	mov.16b	v9, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q6, [sp, #1488]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v3, v3, v5
	str	q2, [sp, #9456]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	mov.16b	v25, v17
	mov.16b	v2, v5
	bsl.16b	v2, v17, v4
	str	q2, [sp, #9472]                 ; 16-byte Spill
	fcmgt.4s	v4, v6, v14
	mov.16b	v2, v4
	bsl.16b	v2, v17, v3
	str	q2, [sp, #1504]                 ; 16-byte Spill
	ldr	q2, [sp, #14048]                ; 16-byte Reload
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	fsub.4s	v3, v3, v2
	and.16b	v22, v0, v3
	fcmge.4s	v3, v22, v15
	fcmge.4s	v4, v14, v22
	and.16b	v3, v3, v4
	ldr	q17, [sp, #14064]               ; 16-byte Reload
	ldr	q4, [sp, #1760]                 ; 16-byte Reload
	fsub.4s	v4, v4, v17
	and.16b	v23, v1, v4
	fcmge.4s	v4, v23, v15
	fcmge.4s	v5, v14, v23
	and.16b	v4, v4, v5
	and.16b	v4, v4, v23
	ldr	q19, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v19
	movi.4s	v6, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v6, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v22
	fmul.4s	v7, v3, v19
	bsl.16b	v18, v6, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q6, [sp, #14128]                ; 16-byte Reload
	fmul.4s	v19, v18, v6
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v6
	fsub.4s	v3, v3, v20
	ldr	q6, [sp, #14144]                ; 16-byte Reload
	fmul.4s	v19, v19, v6
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v6
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v11
	fmul.4s	v18, v4, v18
	mov.16b	v20, v9
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	mov.16b	v9, v10
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v4, v18
	movi.4s	v6, #63, lsl #24
	fadd.4s	v18, v18, v6
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v11
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v6
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q22, [sp, #1456]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v22
	bic.16b	v3, v3, v5
	str	q23, [sp, #1744]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v23, v14
	bit.16b	v4, v25, v5
	str	q4, [sp, #1760]                 ; 16-byte Spill
	fcmgt.4s	v4, v22, v14
	bit.16b	v3, v25, v4
	str	q3, [sp, #1472]                 ; 16-byte Spill
	ldr	q3, [sp, #9488]                 ; 16-byte Reload
	fsub.4s	v3, v3, v2
	mov.16b	v25, v2
	and.16b	v24, v0, v3
	fcmge.4s	v3, v24, v15
	fcmge.4s	v4, v14, v24
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9504]                 ; 16-byte Reload
	fsub.4s	v4, v2, v17
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	ldr	q10, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v10
	mvni.4s	v6, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v6
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v24
	fmul.4s	v7, v3, v10
	bif.16b	v18, v7, v6
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q6, [sp, #14128]                ; 16-byte Reload
	fmul.4s	v19, v18, v6
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v6
	fsub.4s	v3, v3, v20
	ldr	q6, [sp, #14144]                ; 16-byte Reload
	fmul.4s	v19, v19, v6
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v6
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v11
	fmul.4s	v18, v4, v18
	ldr	q22, [sp, #8512]                ; 16-byte Reload
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v4, v18
	movi.4s	v23, #63, lsl #24
	fadd.4s	v18, v18, v23
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v11
	mov.16b	v6, v11
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q24, [sp, #1424]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v24
	bic.16b	v3, v3, v5
	str	q2, [sp, #9488]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	ldr	q7, [sp, #14160]                ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v7, v4
	str	q2, [sp, #9504]                 ; 16-byte Spill
	fcmgt.4s	v4, v24, v14
	mov.16b	v2, v4
	bsl.16b	v2, v7, v3
	str	q2, [sp, #1440]                 ; 16-byte Spill
	ldr	q2, [sp, #9520]                 ; 16-byte Reload
	fsub.4s	v3, v2, v25
	and.16b	v23, v0, v3
	fcmge.4s	v3, v23, v15
	fcmge.4s	v4, v14, v23
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9536]                 ; 16-byte Reload
	fsub.4s	v4, v2, v17
	and.16b	v11, v1, v4
	fcmge.4s	v4, v11, v15
	fcmge.4s	v5, v14, v11
	and.16b	v4, v4, v5
	and.16b	v4, v4, v11
	fmul.4s	v5, v4, v10
	movi.4s	v2, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v23
	fmul.4s	v7, v3, v10
	mov.16b	v18, v17
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q9, [sp, #14128]                ; 16-byte Reload
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q25, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v25
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v25
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	ldr	q17, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q23, [sp, #1392]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v3, v3, v5
	str	q11, [sp, #9520]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v11
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v11, v14
	ldr	q7, [sp, #14160]                ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v7, v4
	str	q2, [sp, #9536]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v14
	mov.16b	v2, v4
	bsl.16b	v2, v7, v3
	str	q2, [sp, #1408]                 ; 16-byte Spill
	ldr	q2, [sp, #9552]                 ; 16-byte Reload
	ldr	q17, [sp, #14048]               ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v11, v0, v3
	fcmge.4s	v3, v11, v15
	fcmge.4s	v4, v14, v11
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9568]                 ; 16-byte Reload
	ldr	q24, [sp, #14064]               ; 16-byte Reload
	fsub.4s	v4, v2, v24
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v10
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v11
	fmul.4s	v7, v3, v10
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v25
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v25
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	ldr	q25, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q11, [sp, #1360]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v11
	bic.16b	v3, v3, v5
	str	q2, [sp, #9552]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	ldr	q7, [sp, #14160]                ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v7, v4
	str	q2, [sp, #9568]                 ; 16-byte Spill
	fcmgt.4s	v4, v11, v14
	mov.16b	v2, v4
	bsl.16b	v2, v7, v3
	str	q2, [sp, #1376]                 ; 16-byte Spill
	ldr	q2, [sp, #9584]                 ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v23, v0, v3
	fcmge.4s	v3, v23, v15
	fcmge.4s	v4, v14, v23
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9600]                 ; 16-byte Reload
	fsub.4s	v4, v2, v24
	and.16b	v11, v1, v4
	fcmge.4s	v4, v11, v15
	fcmge.4s	v5, v14, v11
	and.16b	v4, v4, v5
	and.16b	v4, v4, v11
	fmul.4s	v5, v4, v10
	movi.4s	v2, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v23
	fmul.4s	v7, v3, v10
	mov.16b	v18, v17
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q2, [sp, #14144]                ; 16-byte Reload
	fmul.4s	v19, v19, v2
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v2
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	mov.16b	v24, v25
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q23, [sp, #1328]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v3, v3, v5
	str	q11, [sp, #9584]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v11
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v11, v14
	ldr	q25, [sp, #14160]               ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v25, v4
	str	q2, [sp, #9600]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v14
	mov.16b	v2, v4
	bsl.16b	v2, v25, v3
	str	q2, [sp, #1344]                 ; 16-byte Spill
	ldr	q2, [sp, #9616]                 ; 16-byte Reload
	ldr	q17, [sp, #14048]               ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v23, v0, v3
	fcmge.4s	v3, v23, v15
	fcmge.4s	v4, v14, v23
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9632]                 ; 16-byte Reload
	ldr	q11, [sp, #14064]               ; 16-byte Reload
	fsub.4s	v4, v2, v11
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v10
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v23
	fmul.4s	v7, v3, v10
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q20, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v20
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v20
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	mov.16b	v20, v24
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	movi.4s	v24, #63, lsl #24
	fadd.4s	v18, v18, v24
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q23, [sp, #1296]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v3, v3, v5
	str	q2, [sp, #9616]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	mov.16b	v2, v5
	bsl.16b	v2, v25, v4
	str	q2, [sp, #9632]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v14
	mov.16b	v2, v4
	bsl.16b	v2, v25, v3
	str	q2, [sp, #1312]                 ; 16-byte Spill
	ldr	q2, [sp, #9648]                 ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v23, v0, v3
	fcmge.4s	v3, v23, v15
	fcmge.4s	v4, v14, v23
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9664]                 ; 16-byte Reload
	fsub.4s	v4, v2, v11
	and.16b	v11, v1, v4
	fcmge.4s	v4, v11, v15
	fcmge.4s	v5, v14, v11
	and.16b	v4, v4, v5
	and.16b	v4, v4, v11
	fmul.4s	v5, v4, v10
	movi.4s	v2, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v23
	fmul.4s	v7, v3, v10
	mov.16b	v18, v17
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q24, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v24
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v24
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	ldr	q17, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q23, [sp, #1264]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v3, v3, v5
	str	q11, [sp, #9648]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v11
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v11, v14
	mov.16b	v2, v5
	bsl.16b	v2, v25, v4
	str	q2, [sp, #9664]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v14
	mov.16b	v2, v4
	bsl.16b	v2, v25, v3
	str	q2, [sp, #1280]                 ; 16-byte Spill
	ldr	q2, [sp, #9680]                 ; 16-byte Reload
	ldr	q17, [sp, #14048]               ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v11, v0, v3
	fcmge.4s	v3, v11, v15
	fcmge.4s	v4, v14, v11
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9696]                 ; 16-byte Reload
	ldr	q25, [sp, #14064]               ; 16-byte Reload
	fsub.4s	v4, v2, v25
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v10
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v11
	fmul.4s	v7, v3, v10
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v24
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v24
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	ldr	q23, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q11, [sp, #1232]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v11
	bic.16b	v3, v3, v5
	str	q2, [sp, #9680]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	ldr	q7, [sp, #14160]                ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v7, v4
	str	q2, [sp, #9696]                 ; 16-byte Spill
	fcmgt.4s	v4, v11, v14
	mov.16b	v2, v4
	bsl.16b	v2, v7, v3
	str	q2, [sp, #1248]                 ; 16-byte Spill
	ldr	q2, [sp, #9712]                 ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v23, v0, v3
	fcmge.4s	v3, v23, v15
	fcmge.4s	v4, v14, v23
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9728]                 ; 16-byte Reload
	fsub.4s	v4, v2, v25
	and.16b	v11, v1, v4
	fcmge.4s	v4, v11, v15
	fcmge.4s	v5, v14, v11
	and.16b	v4, v4, v5
	and.16b	v4, v4, v11
	fmul.4s	v5, v4, v10
	movi.4s	v2, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v23
	fmul.4s	v7, v3, v10
	mov.16b	v18, v17
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v24
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v24
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	ldr	q25, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q23, [sp, #1200]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v3, v3, v5
	str	q11, [sp, #9712]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v11
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v11, v14
	ldr	q7, [sp, #14160]                ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v7, v4
	str	q2, [sp, #9728]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v14
	mov.16b	v2, v4
	bsl.16b	v2, v7, v3
	str	q2, [sp, #1216]                 ; 16-byte Spill
	ldr	q2, [sp, #9744]                 ; 16-byte Reload
	ldr	q11, [sp, #14048]               ; 16-byte Reload
	fsub.4s	v3, v2, v11
	and.16b	v23, v0, v3
	fcmge.4s	v3, v23, v15
	fcmge.4s	v4, v14, v23
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9760]                 ; 16-byte Reload
	ldr	q17, [sp, #14064]               ; 16-byte Reload
	fsub.4s	v4, v2, v17
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v10
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v23
	fmul.4s	v7, v3, v10
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v24
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v24
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q23, [sp, #1168]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v3, v3, v5
	str	q2, [sp, #9744]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	ldr	q7, [sp, #14160]                ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v7, v4
	str	q2, [sp, #9760]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v14
	mov.16b	v2, v4
	bsl.16b	v2, v7, v3
	str	q2, [sp, #1184]                 ; 16-byte Spill
	ldr	q2, [sp, #9776]                 ; 16-byte Reload
	fsub.4s	v3, v2, v11
	and.16b	v23, v0, v3
	fcmge.4s	v3, v23, v15
	fcmge.4s	v4, v14, v23
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9792]                 ; 16-byte Reload
	fsub.4s	v4, v2, v17
	and.16b	v11, v1, v4
	fcmge.4s	v4, v11, v15
	fcmge.4s	v5, v14, v11
	and.16b	v4, v4, v5
	and.16b	v4, v4, v11
	fmul.4s	v5, v4, v10
	movi.4s	v2, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v23
	fmul.4s	v7, v3, v10
	mov.16b	v18, v17
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v24
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v24
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q23, [sp, #1136]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v3, v3, v5
	str	q11, [sp, #9776]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v11
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v11, v14
	ldr	q7, [sp, #14160]                ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v7, v4
	str	q2, [sp, #9792]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v14
	mov.16b	v2, v4
	bsl.16b	v2, v7, v3
	str	q2, [sp, #1152]                 ; 16-byte Spill
	ldr	q2, [sp, #9808]                 ; 16-byte Reload
	ldr	q24, [sp, #14048]               ; 16-byte Reload
	fsub.4s	v3, v2, v24
	and.16b	v11, v0, v3
	fcmge.4s	v3, v11, v15
	fcmge.4s	v4, v14, v11
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9824]                 ; 16-byte Reload
	ldr	q17, [sp, #14064]               ; 16-byte Reload
	fsub.4s	v4, v2, v17
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v10
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v11
	fmul.4s	v7, v3, v10
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q20, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v20
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v20
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q11, [sp, #1104]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v11
	bic.16b	v3, v3, v5
	str	q2, [sp, #9808]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	ldr	q7, [sp, #14160]                ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v7, v4
	str	q2, [sp, #9824]                 ; 16-byte Spill
	fcmgt.4s	v4, v11, v14
	mov.16b	v2, v4
	bsl.16b	v2, v7, v3
	str	q2, [sp, #1120]                 ; 16-byte Spill
	ldr	q2, [sp, #9840]                 ; 16-byte Reload
	fsub.4s	v3, v2, v24
	and.16b	v23, v0, v3
	fcmge.4s	v3, v23, v15
	fcmge.4s	v4, v14, v23
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9856]                 ; 16-byte Reload
	fsub.4s	v4, v2, v17
	and.16b	v11, v1, v4
	fcmge.4s	v4, v11, v15
	fcmge.4s	v5, v14, v11
	and.16b	v4, v4, v5
	and.16b	v4, v4, v11
	fmul.4s	v5, v4, v10
	movi.4s	v2, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v23
	fmul.4s	v7, v3, v10
	mov.16b	v18, v17
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q2, [sp, #14144]                ; 16-byte Reload
	fmul.4s	v19, v19, v2
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v2
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	mov.16b	v24, v25
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q23, [sp, #1072]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v3, v3, v5
	str	q11, [sp, #9840]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v11
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v11, v14
	ldr	q25, [sp, #14160]               ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v25, v4
	str	q2, [sp, #9856]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v14
	mov.16b	v2, v4
	bsl.16b	v2, v25, v3
	str	q2, [sp, #1088]                 ; 16-byte Spill
	ldr	q2, [sp, #9872]                 ; 16-byte Reload
	ldr	q17, [sp, #14048]               ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v23, v0, v3
	fcmge.4s	v3, v23, v15
	fcmge.4s	v4, v14, v23
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9888]                 ; 16-byte Reload
	ldr	q11, [sp, #14064]               ; 16-byte Reload
	fsub.4s	v4, v2, v11
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v10
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v23
	fmul.4s	v7, v3, v10
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q20, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v20
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v20
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	mov.16b	v20, v24
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	movi.4s	v24, #63, lsl #24
	fadd.4s	v18, v18, v24
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q23, [sp, #1040]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v3, v3, v5
	str	q2, [sp, #9872]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	mov.16b	v2, v5
	bsl.16b	v2, v25, v4
	str	q2, [sp, #9888]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v14
	mov.16b	v2, v4
	bsl.16b	v2, v25, v3
	str	q2, [sp, #1056]                 ; 16-byte Spill
	ldr	q2, [sp, #9904]                 ; 16-byte Reload
	fsub.4s	v3, v2, v17
	and.16b	v23, v0, v3
	fcmge.4s	v3, v23, v15
	fcmge.4s	v4, v14, v23
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9920]                 ; 16-byte Reload
	fsub.4s	v4, v2, v11
	and.16b	v11, v1, v4
	fcmge.4s	v4, v11, v15
	fcmge.4s	v5, v14, v11
	and.16b	v4, v4, v5
	and.16b	v4, v4, v11
	fmul.4s	v5, v4, v10
	movi.4s	v2, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v23
	fmul.4s	v7, v3, v10
	mov.16b	v18, v17
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q24, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v24
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v24
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	ldr	q17, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	fcmgt.4s	v5, v15, v23
	bic.16b	v3, v3, v5
	str	q11, [sp, #9904]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v11
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v11, v14
	mov.16b	v2, v5
	bsl.16b	v2, v25, v4
	str	q2, [sp, #9920]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v14
	mov.16b	v2, v4
	bsl.16b	v2, v25, v3
	stp	q23, q2, [sp, #1008]            ; 32-byte Folded Spill
	ldr	q2, [sp, #9936]                 ; 16-byte Reload
	ldr	q3, [sp, #14048]                ; 16-byte Reload
	fsub.4s	v3, v2, v3
	and.16b	v11, v0, v3
	fcmge.4s	v3, v11, v15
	fcmge.4s	v4, v14, v11
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9952]                 ; 16-byte Reload
	ldr	q4, [sp, #14064]                ; 16-byte Reload
	fsub.4s	v4, v2, v4
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v10
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v11
	fmul.4s	v7, v3, v10
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v24
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v24
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	mov.16b	v24, v12
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	mov.16b	v20, v17
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	movi.4s	v17, #63, lsl #24
	fadd.4s	v18, v18, v17
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v17
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	fcmgt.4s	v5, v15, v11
	bic.16b	v3, v3, v5
	str	q2, [sp, #9936]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	mov.16b	v2, v5
	bsl.16b	v2, v25, v4
	str	q2, [sp, #9952]                 ; 16-byte Spill
	fcmgt.4s	v4, v11, v14
	mov.16b	v2, v4
	bsl.16b	v2, v25, v3
	stp	q11, q2, [sp, #976]             ; 32-byte Folded Spill
	ldr	q2, [sp, #2304]                 ; 16-byte Reload
	ldr	q11, [sp, #13968]               ; 16-byte Reload
	fsub.4s	v3, v2, v11
	and.16b	v23, v0, v3
	fcmge.4s	v3, v23, v15
	fcmge.4s	v4, v14, v23
	and.16b	v3, v3, v4
	ldr	q17, [sp, #13984]               ; 16-byte Reload
	ldr	q2, [sp, #2352]                 ; 16-byte Reload
	fsub.4s	v4, v2, v17
	and.16b	v12, v1, v4
	fcmge.4s	v4, v12, v15
	fcmge.4s	v5, v14, v12
	and.16b	v4, v4, v5
	and.16b	v4, v4, v12
	fmul.4s	v5, v4, v10
	movi.4s	v2, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v23
	fmul.4s	v7, v3, v10
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q2, [sp, #14144]                ; 16-byte Reload
	fmul.4s	v19, v19, v2
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v2
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	mov.16b	v20, v24
	str	q24, [sp, #13952]               ; 16-byte Spill
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	ldr	q24, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	fcmgt.4s	v5, v15, v23
	bic.16b	v3, v3, v5
	str	q12, [sp, #2304]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v12
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v12, v14
	mov.16b	v2, v5
	bsl.16b	v2, v25, v4
	str	q2, [sp, #2352]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v14
	mov.16b	v2, v4
	bsl.16b	v2, v25, v3
	stp	q23, q2, [sp, #944]             ; 32-byte Folded Spill
	ldr	q2, [sp, #9968]                 ; 16-byte Reload
	fsub.4s	v3, v2, v11
	and.16b	v12, v0, v3
	fcmge.4s	v3, v12, v15
	fcmge.4s	v4, v14, v12
	and.16b	v3, v3, v4
	ldr	q2, [sp, #9984]                 ; 16-byte Reload
	fsub.4s	v4, v2, v17
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v10
	mvni.4s	v17, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v12
	fmul.4s	v7, v3, v10
	bif.16b	v18, v7, v17
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q17, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v17
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v17
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	mov.16b	v17, v6
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	ldr	q25, [sp, #13952]               ; 16-byte Reload
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	fcmgt.4s	v5, v15, v12
	bic.16b	v3, v3, v5
	str	q2, [sp, #9968]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v6, v4
	str	q2, [sp, #9984]                 ; 16-byte Spill
	fcmgt.4s	v4, v12, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	stp	q12, q2, [sp, #912]             ; 32-byte Folded Spill
	ldr	q2, [sp, #10000]                ; 16-byte Reload
	fsub.4s	v3, v2, v11
	and.16b	v12, v0, v3
	fcmge.4s	v3, v12, v15
	fcmge.4s	v4, v14, v12
	and.16b	v3, v3, v4
	ldr	q2, [sp, #10016]                ; 16-byte Reload
	ldr	q24, [sp, #13984]               ; 16-byte Reload
	fsub.4s	v4, v2, v24
	and.16b	v23, v1, v4
	fcmge.4s	v4, v23, v15
	fcmge.4s	v5, v14, v23
	and.16b	v4, v4, v5
	and.16b	v4, v4, v23
	fmul.4s	v5, v4, v10
	movi.4s	v2, #75, lsl #24
	mvni.4s	v6, #128, lsl #24
	mov.16b	v7, v6
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v12
	fmul.4s	v7, v3, v10
	mov.16b	v18, v6
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q2, [sp, #14144]                ; 16-byte Reload
	fmul.4s	v19, v19, v2
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v2
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	ldr	q6, [sp, #14112]                ; 16-byte Reload
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	fcmgt.4s	v5, v15, v12
	bic.16b	v3, v3, v5
	str	q23, [sp, #10000]               ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v23, v14
	ldr	q6, [sp, #14160]                ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v6, v4
	str	q2, [sp, #10016]                ; 16-byte Spill
	fcmgt.4s	v4, v12, v14
	mov.16b	v2, v4
	bsl.16b	v2, v6, v3
	stp	q12, q2, [sp, #880]             ; 32-byte Folded Spill
	ldr	q2, [sp, #10032]                ; 16-byte Reload
	fsub.4s	v3, v2, v11
	mov.16b	v12, v11
	and.16b	v11, v0, v3
	fcmge.4s	v3, v11, v15
	fcmge.4s	v4, v14, v11
	and.16b	v3, v3, v4
	ldr	q2, [sp, #10048]                ; 16-byte Reload
	mov.16b	v6, v24
	fsub.4s	v4, v2, v24
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v10
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v11
	fmul.4s	v7, v3, v10
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q20, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v20
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v20
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	ldr	q23, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q11, [sp, #848]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v11
	bic.16b	v3, v3, v5
	str	q2, [sp, #10032]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	ldr	q7, [sp, #14160]                ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v7, v4
	str	q2, [sp, #10048]                ; 16-byte Spill
	fcmgt.4s	v4, v11, v14
	mov.16b	v2, v4
	bsl.16b	v2, v7, v3
	mov.16b	v11, v7
	str	q2, [sp, #864]                  ; 16-byte Spill
	ldr	q2, [sp, #10064]                ; 16-byte Reload
	fsub.4s	v3, v2, v12
	mov.16b	v24, v12
	and.16b	v12, v0, v3
	fcmge.4s	v3, v12, v15
	fcmge.4s	v4, v14, v12
	and.16b	v3, v3, v4
	ldr	q2, [sp, #10080]                ; 16-byte Reload
	fsub.4s	v4, v2, v6
	and.16b	v23, v1, v4
	fcmge.4s	v4, v23, v15
	fcmge.4s	v5, v14, v23
	and.16b	v4, v4, v5
	and.16b	v4, v4, v23
	fmul.4s	v5, v4, v10
	movi.4s	v2, #75, lsl #24
	mvni.4s	v6, #128, lsl #24
	mov.16b	v7, v6
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v12
	fmul.4s	v7, v3, v10
	mov.16b	v18, v6
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q2, [sp, #14144]                ; 16-byte Reload
	fmul.4s	v19, v19, v2
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v2
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	ldr	q6, [sp, #14112]                ; 16-byte Reload
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v6
	mov.16b	v25, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	fcmgt.4s	v5, v15, v12
	bic.16b	v3, v3, v5
	str	q23, [sp, #10064]               ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v23, v14
	mov.16b	v2, v5
	bsl.16b	v2, v11, v4
	str	q2, [sp, #10080]                ; 16-byte Spill
	fcmgt.4s	v4, v12, v14
	mov.16b	v2, v4
	bsl.16b	v2, v11, v3
	stp	q12, q2, [sp, #816]             ; 32-byte Folded Spill
	ldr	q2, [sp, #10096]                ; 16-byte Reload
	fsub.4s	v3, v2, v24
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v15
	fcmge.4s	v4, v14, v6
	and.16b	v3, v3, v4
	ldr	q2, [sp, #10112]                ; 16-byte Reload
	ldr	q23, [sp, #13984]               ; 16-byte Reload
	fsub.4s	v4, v2, v23
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	fmul.4s	v5, v4, v10
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v6
	fmul.4s	v7, v3, v10
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	ldr	q11, [sp, #14144]               ; 16-byte Reload
	fmul.4s	v19, v19, v11
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v11
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	ldr	q12, [sp, #13952]               ; 16-byte Reload
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	movi.4s	v24, #63, lsl #24
	fadd.4s	v18, v18, v24
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	fcmgt.4s	v5, v15, v6
	bic.16b	v3, v3, v5
	str	q2, [sp, #10096]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	ldr	q10, [sp, #14160]               ; 16-byte Reload
	mov.16b	v2, v5
	bsl.16b	v2, v10, v4
	str	q2, [sp, #10112]                ; 16-byte Spill
	fcmgt.4s	v4, v6, v14
	mov.16b	v2, v4
	bsl.16b	v2, v10, v3
	stp	q6, q2, [sp, #784]              ; 32-byte Folded Spill
	ldr	q2, [sp, #10128]                ; 16-byte Reload
	ldr	q25, [sp, #13968]               ; 16-byte Reload
	fsub.4s	v3, v2, v25
	and.16b	v24, v0, v3
	fcmge.4s	v3, v24, v15
	fcmge.4s	v4, v14, v24
	and.16b	v3, v3, v4
	ldr	q2, [sp, #10144]                ; 16-byte Reload
	fsub.4s	v4, v2, v23
	and.16b	v23, v1, v4
	fcmge.4s	v4, v23, v15
	fcmge.4s	v5, v14, v23
	and.16b	v4, v4, v5
	and.16b	v4, v4, v23
	ldr	q18, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v18
	movi.4s	v2, #75, lsl #24
	mvni.4s	v6, #128, lsl #24
	mov.16b	v7, v6
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v24
	fmul.4s	v7, v3, v18
	mov.16b	v18, v6
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v11
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v11
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	ldr	q6, [sp, #14112]                ; 16-byte Reload
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	fcmgt.4s	v5, v15, v24
	bic.16b	v3, v3, v5
	str	q23, [sp, #10128]               ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v23, v14
	mov.16b	v2, v5
	bsl.16b	v2, v10, v4
	str	q2, [sp, #10144]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v14
	mov.16b	v2, v4
	bsl.16b	v2, v10, v3
	stp	q24, q2, [sp, #752]             ; 32-byte Folded Spill
	ldr	q2, [sp, #10160]                ; 16-byte Reload
	mov.16b	v23, v25
	fsub.4s	v3, v2, v25
	and.16b	v24, v0, v3
	fcmge.4s	v3, v24, v15
	fcmge.4s	v4, v14, v24
	and.16b	v3, v3, v4
	ldr	q2, [sp, #2720]                 ; 16-byte Reload
	ldr	q9, [sp, #13984]                ; 16-byte Reload
	fsub.4s	v4, v2, v9
	and.16b	v12, v1, v4
	fcmge.4s	v4, v12, v15
	fcmge.4s	v5, v14, v12
	and.16b	v4, v4, v5
	and.16b	v4, v4, v12
	ldr	q25, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v25
	mvni.4s	v18, #128, lsl #24
	movi.4s	v2, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v24
	fmul.4s	v7, v3, v25
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q2, [sp, #14128]                ; 16-byte Reload
	fmul.4s	v19, v18, v2
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v2
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v11
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v11
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	ldr	q2, [sp, #13952]                ; 16-byte Reload
	fadd.4s	v18, v18, v2
	fmul.4s	v18, v4, v18
	mov.16b	v20, v6
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	movi.4s	v6, #63, lsl #24
	fadd.4s	v18, v18, v6
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v6
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	fcmgt.4s	v5, v15, v24
	bic.16b	v3, v3, v5
	str	q12, [sp, #2720]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v12
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v12, v14
	mov.16b	v2, v5
	bsl.16b	v2, v10, v4
	str	q2, [sp, #10160]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v14
	mov.16b	v2, v4
	bsl.16b	v2, v10, v3
	stp	q24, q2, [sp, #720]             ; 32-byte Folded Spill
	ldr	q2, [sp, #2736]                 ; 16-byte Reload
	fsub.4s	v3, v2, v23
	and.16b	v23, v0, v3
	fcmge.4s	v3, v23, v15
	fcmge.4s	v4, v14, v23
	and.16b	v3, v3, v4
	ldr	q2, [sp, #2752]                 ; 16-byte Reload
	fsub.4s	v4, v2, v9
	and.16b	v24, v1, v4
	fcmge.4s	v4, v24, v15
	fcmge.4s	v5, v14, v24
	and.16b	v4, v4, v5
	and.16b	v4, v4, v24
	fmul.4s	v5, v4, v25
	movi.4s	v2, #75, lsl #24
	mvni.4s	v6, #128, lsl #24
	mov.16b	v7, v6
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v23
	fmul.4s	v7, v3, v25
	mov.16b	v18, v6
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	ldr	q9, [sp, #14128]                ; 16-byte Reload
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v11
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v11
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	ldr	q12, [sp, #13952]               ; 16-byte Reload
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	ldr	q6, [sp, #14112]                ; 16-byte Reload
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	fcmgt.4s	v5, v15, v23
	bic.16b	v3, v3, v5
	str	q24, [sp, #2736]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v24
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v24, v14
	mov.16b	v2, v5
	bsl.16b	v2, v10, v4
	str	q2, [sp, #2752]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v14
	mov.16b	v2, v4
	bsl.16b	v2, v10, v3
	stp	q23, q2, [sp, #688]             ; 32-byte Folded Spill
	ldr	q2, [sp, #2832]                 ; 16-byte Reload
	ldr	q25, [sp, #13968]               ; 16-byte Reload
	fsub.4s	v3, v2, v25
	and.16b	v24, v0, v3
	fcmge.4s	v3, v24, v15
	fcmge.4s	v4, v14, v24
	and.16b	v3, v3, v4
	ldr	q2, [sp, #2848]                 ; 16-byte Reload
	ldr	q6, [sp, #13984]                ; 16-byte Reload
	fsub.4s	v4, v2, v6
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	ldr	q18, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v18
	mvni.4s	v19, #128, lsl #24
	movi.4s	v20, #75, lsl #24
	mov.16b	v7, v19
	bsl.16b	v7, v20, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v24
	fmul.4s	v7, v3, v18
	mov.16b	v18, v19
	bsl.16b	v18, v20, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v11
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v11
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v4, v18
	ldr	q23, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	fcmgt.4s	v5, v15, v24
	bic.16b	v3, v3, v5
	str	q2, [sp, #2832]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	mov.16b	v2, v5
	bsl.16b	v2, v10, v4
	str	q2, [sp, #2848]                 ; 16-byte Spill
	fcmgt.4s	v4, v24, v14
	mov.16b	v2, v4
	bsl.16b	v2, v10, v3
	stp	q24, q2, [sp, #656]             ; 32-byte Folded Spill
	ldr	q2, [sp, #2928]                 ; 16-byte Reload
	fsub.4s	v3, v2, v25
	and.16b	v24, v0, v3
	fcmge.4s	v3, v24, v15
	fcmge.4s	v4, v14, v24
	and.16b	v3, v3, v4
	ldr	q2, [sp, #2944]                 ; 16-byte Reload
	mov.16b	v23, v6
	fsub.4s	v4, v2, v6
	and.16b	v12, v1, v4
	fcmge.4s	v4, v12, v15
	fcmge.4s	v5, v14, v12
	and.16b	v4, v4, v5
	and.16b	v4, v4, v12
	ldr	q18, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v18
	movi.4s	v2, #75, lsl #24
	mvni.4s	v6, #128, lsl #24
	mov.16b	v7, v6
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v24
	fmul.4s	v7, v3, v18
	mov.16b	v18, v6
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v11
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v11
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	ldr	q6, [sp, #13952]                ; 16-byte Reload
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	ldr	q25, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	fcmgt.4s	v5, v15, v24
	bic.16b	v3, v3, v5
	str	q12, [sp, #2928]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v12
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v12, v14
	bit.16b	v4, v10, v5
	str	q4, [sp, #2944]                 ; 16-byte Spill
	fcmgt.4s	v4, v24, v14
	bit.16b	v3, v10, v4
	stp	q24, q3, [sp, #624]             ; 32-byte Folded Spill
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	ldr	q12, [sp, #13968]               ; 16-byte Reload
	fsub.4s	v3, v3, v12
	and.16b	v24, v0, v3
	fcmge.4s	v3, v24, v15
	fcmge.4s	v4, v14, v24
	and.16b	v3, v3, v4
	ldr	q4, [sp, #3040]                 ; 16-byte Reload
	fsub.4s	v4, v4, v23
	and.16b	v23, v1, v4
	fcmge.4s	v4, v23, v15
	fcmge.4s	v5, v14, v23
	and.16b	v4, v4, v5
	and.16b	v4, v4, v23
	ldr	q18, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v18
	mvni.4s	v19, #128, lsl #24
	movi.4s	v20, #75, lsl #24
	mov.16b	v7, v19
	bsl.16b	v7, v20, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v24
	fmul.4s	v7, v3, v18
	mov.16b	v18, v19
	bsl.16b	v18, v20, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v11
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v11
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q24, [sp, #3024]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v24
	bic.16b	v3, v3, v5
	str	q23, [sp, #3040]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v23
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v23, v14
	mov.16b	v2, v5
	bsl.16b	v2, v10, v4
	str	q2, [sp, #608]                  ; 16-byte Spill
	fcmgt.4s	v4, v24, v14
	mov.16b	v2, v4
	bsl.16b	v2, v10, v3
	str	q2, [sp, #592]                  ; 16-byte Spill
	ldr	q3, [sp, #3104]                 ; 16-byte Reload
	fsub.4s	v3, v3, v12
	and.16b	v24, v0, v3
	fcmge.4s	v3, v24, v15
	fcmge.4s	v4, v14, v24
	and.16b	v3, v3, v4
	ldr	q4, [sp, #3120]                 ; 16-byte Reload
	ldr	q25, [sp, #13984]               ; 16-byte Reload
	fsub.4s	v4, v4, v25
	and.16b	v12, v1, v4
	fcmge.4s	v4, v12, v15
	fcmge.4s	v5, v14, v12
	and.16b	v4, v4, v5
	and.16b	v4, v4, v12
	ldr	q18, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v18
	movi.4s	v2, #75, lsl #24
	mvni.4s	v6, #128, lsl #24
	mov.16b	v7, v6
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v24
	fmul.4s	v7, v3, v18
	mov.16b	v18, v6
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v11
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v11
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	ldr	q23, [sp, #13952]               ; 16-byte Reload
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	ldr	q6, [sp, #14112]                ; 16-byte Reload
	fadd.4s	v18, v18, v6
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v6
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q24, [sp, #3104]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v24
	bic.16b	v3, v3, v5
	str	q12, [sp, #3120]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v12
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v12, v14
	bit.16b	v4, v10, v5
	str	q4, [sp, #576]                  ; 16-byte Spill
	fcmgt.4s	v4, v24, v14
	bit.16b	v3, v10, v4
	str	q3, [sp, #560]                  ; 16-byte Spill
	ldr	q3, [sp, #3152]                 ; 16-byte Reload
	ldr	q6, [sp, #13968]                ; 16-byte Reload
	fsub.4s	v3, v3, v6
	and.16b	v12, v0, v3
	fcmge.4s	v3, v12, v15
	fcmge.4s	v4, v14, v12
	and.16b	v3, v3, v4
	ldr	q4, [sp, #3168]                 ; 16-byte Reload
	fsub.4s	v4, v4, v25
	and.16b	v2, v1, v4
	fcmge.4s	v4, v2, v15
	fcmge.4s	v5, v14, v2
	and.16b	v4, v4, v5
	and.16b	v4, v4, v2
	ldr	q25, [sp, #14096]               ; 16-byte Reload
	fmul.4s	v5, v4, v25
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v12
	fmul.4s	v7, v3, v25
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v11
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v11
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	mov.16b	v24, v23
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	ldr	q23, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q12, [sp, #3152]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v12
	bic.16b	v3, v3, v5
	str	q2, [sp, #3168]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v2
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v2, v14
	mov.16b	v2, v5
	bsl.16b	v2, v10, v4
	str	q2, [sp, #544]                  ; 16-byte Spill
	fcmgt.4s	v4, v12, v14
	mov.16b	v2, v4
	bsl.16b	v2, v10, v3
	str	q2, [sp, #528]                  ; 16-byte Spill
	ldr	q3, [sp, #3184]                 ; 16-byte Reload
	fsub.4s	v3, v3, v6
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v15
	fcmge.4s	v4, v14, v6
	and.16b	v3, v3, v4
	ldr	q4, [sp, #3200]                 ; 16-byte Reload
	ldr	q23, [sp, #13984]               ; 16-byte Reload
	fsub.4s	v4, v4, v23
	and.16b	v12, v1, v4
	fcmge.4s	v4, v12, v15
	fcmge.4s	v5, v14, v12
	and.16b	v4, v4, v5
	and.16b	v4, v4, v12
	fmul.4s	v5, v4, v25
	movi.4s	v2, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v2, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v6
	fmul.4s	v7, v3, v25
	bsl.16b	v18, v2, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v9
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v9
	fsub.4s	v3, v3, v20
	fmul.4s	v19, v19, v11
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v11
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v16
	fadd.4s	v18, v18, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	ldr	q20, [sp, #14112]               ; 16-byte Reload
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v4, v18
	movi.4s	v2, #63, lsl #24
	fadd.4s	v18, v18, v2
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v16
	fadd.4s	v19, v19, v17
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v24
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fadd.4s	v4, v4, v13
	sshr.4s	v19, v5, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v13
	fmul.4s	v4, v4, v20
	sub.4s	v7, v7, v18
	sub.4s	v5, v5, v19
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v4, v4, v5
	shl.4s	v5, v7, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	str	q6, [sp, #3184]                 ; 16-byte Spill
	fcmgt.4s	v5, v15, v6
	bic.16b	v3, v3, v5
	str	q12, [sp, #3200]                ; 16-byte Spill
	fcmgt.4s	v5, v15, v12
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v12, v14
	mov.16b	v2, v5
	bsl.16b	v2, v10, v4
	str	q2, [sp, #512]                  ; 16-byte Spill
	fcmgt.4s	v4, v6, v14
	mov.16b	v2, v4
	bsl.16b	v2, v10, v3
	str	q2, [sp, #496]                  ; 16-byte Spill
	ldr	q3, [sp, #3216]                 ; 16-byte Reload
	ldr	q2, [sp, #13968]                ; 16-byte Reload
	fsub.4s	v3, v3, v2
	and.16b	v19, v0, v3
	fcmge.4s	v3, v19, v15
	fcmge.4s	v4, v14, v19
	and.16b	v3, v3, v4
	ldr	q4, [sp, #3232]                 ; 16-byte Reload
	fsub.4s	v4, v4, v23
	and.16b	v20, v1, v4
	fcmge.4s	v4, v20, v15
	fcmge.4s	v5, v14, v20
	and.16b	v4, v4, v5
	and.16b	v4, v4, v20
	fmul.4s	v5, v4, v25
	mvni.4s	v2, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v2
	bsl.16b	v7, v18, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v3, v3, v19
	fmul.4s	v6, v3, v25
	mov.16b	v7, v2
	bsl.16b	v7, v18, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	fcvtzs.4s	v5, v5
	scvtf.4s	v7, v5
	fmul.4s	v18, v7, v9
	fsub.4s	v4, v4, v18
	fcvtzs.4s	v6, v6
	scvtf.4s	v18, v6
	fmul.4s	v2, v18, v9
	fsub.4s	v2, v3, v2
	fmul.4s	v3, v7, v11
	fmul.4s	v7, v18, v11
	fsub.4s	v2, v2, v7
	fsub.4s	v3, v4, v3
	fmul.4s	v4, v3, v16
	fmul.4s	v7, v2, v16
	fadd.4s	v7, v7, v17
	fadd.4s	v4, v4, v17
	fmul.4s	v4, v3, v4
	fmul.4s	v7, v2, v7
	fadd.4s	v7, v7, v22
	fadd.4s	v4, v4, v22
	fmul.4s	v4, v3, v4
	fmul.4s	v7, v2, v7
	fadd.4s	v7, v7, v24
	fadd.4s	v4, v4, v24
	fmul.4s	v4, v3, v4
	fmul.4s	v7, v2, v7
	ldr	q9, [sp, #14112]                ; 16-byte Reload
	fadd.4s	v7, v7, v9
	fadd.4s	v4, v4, v9
	fmul.4s	v4, v3, v4
	movi.4s	v17, #63, lsl #24
	fadd.4s	v4, v4, v17
	fmul.4s	v16, v3, v3
	fmul.4s	v4, v16, v4
	fmul.4s	v7, v2, v7
	fadd.4s	v7, v7, v17
	fmul.4s	v16, v2, v2
	fmul.4s	v7, v16, v7
	fadd.4s	v2, v2, v7
	fadd.4s	v3, v3, v4
	fadd.4s	v2, v2, v13
	sshr.4s	v4, v6, #1
	shl.4s	v7, v4, #23
	add.4s	v7, v7, v13
	fmul.4s	v2, v2, v7
	fadd.4s	v3, v3, v13
	sshr.4s	v7, v5, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v13
	fmul.4s	v3, v3, v16
	sub.4s	v4, v6, v4
	sub.4s	v5, v5, v7
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v13
	fmul.4s	v3, v3, v5
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v13
	fmul.4s	v2, v2, v4
	str	q19, [sp, #3216]                ; 16-byte Spill
	fcmgt.4s	v4, v15, v19
	bic.16b	v2, v2, v4
	str	q20, [sp, #3232]                ; 16-byte Spill
	fcmgt.4s	v4, v15, v20
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v20, v14
	bit.16b	v3, v10, v4
	str	q3, [sp, #480]                  ; 16-byte Spill
	fcmgt.4s	v3, v19, v14
	bit.16b	v2, v10, v3
	str	q2, [sp, #464]                  ; 16-byte Spill
	ldr	q5, [sp, #448]                  ; 16-byte Reload
	ldr	q2, [sp, #3056]                 ; 16-byte Reload
	and.16b	v2, v2, v5
	xtn.8b	v3, v2
	xtn.8b	v2, v5
	ldr	q4, [sp, #12944]                ; 16-byte Reload
	bic.8b	v4, v4, v2
	orr.8b	v3, v3, v4
	str	q3, [sp, #12944]                ; 16-byte Spill
	ldr	q3, [sp, #3072]                 ; 16-byte Reload
	and.16b	v3, v3, v5
	xtn.8b	v3, v3
	ldr	q4, [sp, #12960]                ; 16-byte Reload
	bic.8b	v4, v4, v2
	orr.8b	v3, v3, v4
	str	q3, [sp, #12960]                ; 16-byte Spill
	ldr	q3, [sp, #3088]                 ; 16-byte Reload
	and.16b	v3, v3, v5
	xtn.8b	v3, v3
	ldr	q4, [sp, #12992]                ; 16-byte Reload
	bic.8b	v4, v4, v2
	orr.8b	v3, v3, v4
	str	q3, [sp, #12992]                ; 16-byte Spill
	ldr	q6, [sp, #7984]                 ; 16-byte Reload
	ldr	d3, [sp, #3456]                 ; 8-byte Reload
	bit.8b	v6, v3, v2
	ldr	q12, [sp, #8000]                ; 16-byte Reload
	ldr	d3, [sp, #10848]                ; 8-byte Reload
	bit.8b	v12, v3, v2
	ldr	d3, [sp, #10832]                ; 8-byte Reload
	ldr	q4, [sp, #13008]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13008]                ; 16-byte Spill
	ldr	d3, [sp, #10816]                ; 8-byte Reload
	ldr	q4, [sp, #13024]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13024]                ; 16-byte Spill
	ldr	q7, [sp, #8016]                 ; 16-byte Reload
	ldr	d3, [sp, #3440]                 ; 8-byte Reload
	bit.8b	v7, v3, v2
	ldr	q14, [sp, #8032]                ; 16-byte Reload
	ldr	d3, [sp, #10800]                ; 8-byte Reload
	bit.8b	v14, v3, v2
	ldr	d3, [sp, #10784]                ; 8-byte Reload
	ldr	q4, [sp, #13040]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13040]                ; 16-byte Spill
	ldr	d3, [sp, #10768]                ; 8-byte Reload
	ldr	q4, [sp, #13056]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13056]                ; 16-byte Spill
	ldr	q16, [sp, #8048]                ; 16-byte Reload
	ldr	d3, [sp, #3424]                 ; 8-byte Reload
	bit.8b	v16, v3, v2
	ldr	q15, [sp, #8064]                ; 16-byte Reload
	ldr	d3, [sp, #10752]                ; 8-byte Reload
	bit.8b	v15, v3, v2
	ldr	d3, [sp, #10736]                ; 8-byte Reload
	ldr	q4, [sp, #13072]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13072]                ; 16-byte Spill
	ldr	d3, [sp, #10720]                ; 8-byte Reload
	ldr	q4, [sp, #13088]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13088]                ; 16-byte Spill
	ldr	q17, [sp, #8080]                ; 16-byte Reload
	ldr	d3, [sp, #3408]                 ; 8-byte Reload
	bit.8b	v17, v3, v2
	ldr	d3, [sp, #10704]                ; 8-byte Reload
	ldr	q4, [sp, #13104]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13104]                ; 16-byte Spill
	ldr	d3, [sp, #10688]                ; 8-byte Reload
	ldr	q4, [sp, #13120]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13120]                ; 16-byte Spill
	ldr	d3, [sp, #10672]                ; 8-byte Reload
	ldr	q4, [sp, #13136]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13136]                ; 16-byte Spill
	ldr	q18, [sp, #8096]                ; 16-byte Reload
	ldr	d3, [sp, #3392]                 ; 8-byte Reload
	bit.8b	v18, v3, v2
	ldr	d3, [sp, #10656]                ; 8-byte Reload
	ldr	q4, [sp, #13152]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13152]                ; 16-byte Spill
	ldr	d3, [sp, #10640]                ; 8-byte Reload
	ldr	q4, [sp, #13168]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13168]                ; 16-byte Spill
	ldr	d3, [sp, #10624]                ; 8-byte Reload
	ldr	q4, [sp, #13184]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13184]                ; 16-byte Spill
	ldr	q19, [sp, #8112]                ; 16-byte Reload
	ldr	d3, [sp, #3376]                 ; 8-byte Reload
	bit.8b	v19, v3, v2
	ldr	d3, [sp, #10608]                ; 8-byte Reload
	ldr	q4, [sp, #13200]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13200]                ; 16-byte Spill
	ldr	d3, [sp, #10592]                ; 8-byte Reload
	ldr	q4, [sp, #13216]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13216]                ; 16-byte Spill
	ldr	d3, [sp, #10576]                ; 8-byte Reload
	ldr	q4, [sp, #13232]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13232]                ; 16-byte Spill
	ldr	q20, [sp, #8128]                ; 16-byte Reload
	ldr	d3, [sp, #3360]                 ; 8-byte Reload
	bit.8b	v20, v3, v2
	ldr	d3, [sp, #10560]                ; 8-byte Reload
	ldr	q4, [sp, #13248]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13248]                ; 16-byte Spill
	ldr	d3, [sp, #10544]                ; 8-byte Reload
	ldr	q4, [sp, #13264]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13264]                ; 16-byte Spill
	ldr	d3, [sp, #10528]                ; 8-byte Reload
	ldr	q4, [sp, #13280]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13280]                ; 16-byte Spill
	ldr	q22, [sp, #8144]                ; 16-byte Reload
	ldr	d3, [sp, #3344]                 ; 8-byte Reload
	bit.8b	v22, v3, v2
	ldr	d3, [sp, #10512]                ; 8-byte Reload
	ldr	q4, [sp, #13296]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13296]                ; 16-byte Spill
	ldr	d3, [sp, #10496]                ; 8-byte Reload
	ldr	q4, [sp, #13312]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13312]                ; 16-byte Spill
	ldr	d3, [sp, #10480]                ; 8-byte Reload
	ldr	q4, [sp, #13328]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13328]                ; 16-byte Spill
	ldr	q23, [sp, #8160]                ; 16-byte Reload
	ldr	d3, [sp, #3328]                 ; 8-byte Reload
	bit.8b	v23, v3, v2
	ldr	d3, [sp, #10464]                ; 8-byte Reload
	ldr	q4, [sp, #13344]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13344]                ; 16-byte Spill
	ldr	d3, [sp, #10448]                ; 8-byte Reload
	ldr	q4, [sp, #13360]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13360]                ; 16-byte Spill
	ldr	d3, [sp, #10432]                ; 8-byte Reload
	ldr	q4, [sp, #13376]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13376]                ; 16-byte Spill
	ldr	q24, [sp, #8176]                ; 16-byte Reload
	ldr	d3, [sp, #3312]                 ; 8-byte Reload
	bit.8b	v24, v3, v2
	ldr	d3, [sp, #10416]                ; 8-byte Reload
	ldr	q4, [sp, #13392]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13392]                ; 16-byte Spill
	ldr	d3, [sp, #10400]                ; 8-byte Reload
	ldr	q4, [sp, #13408]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13408]                ; 16-byte Spill
	ldr	d3, [sp, #10384]                ; 8-byte Reload
	ldr	q4, [sp, #13424]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13424]                ; 16-byte Spill
	ldr	q25, [sp, #8192]                ; 16-byte Reload
	ldr	d3, [sp, #3304]                 ; 8-byte Reload
	bit.8b	v25, v3, v2
	ldr	d3, [sp, #10368]                ; 8-byte Reload
	ldr	q4, [sp, #13440]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13440]                ; 16-byte Spill
	ldr	d3, [sp, #10352]                ; 8-byte Reload
	ldr	q4, [sp, #13456]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13456]                ; 16-byte Spill
	ldr	d3, [sp, #10336]                ; 8-byte Reload
	ldr	q4, [sp, #13472]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13472]                ; 16-byte Spill
	ldr	q9, [sp, #8208]                 ; 16-byte Reload
	ldr	d3, [sp, #3296]                 ; 8-byte Reload
	bit.8b	v9, v3, v2
	ldr	d3, [sp, #10320]                ; 8-byte Reload
	ldr	q4, [sp, #13488]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13488]                ; 16-byte Spill
	ldr	d3, [sp, #10304]                ; 8-byte Reload
	ldr	q4, [sp, #13504]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13504]                ; 16-byte Spill
	ldr	d3, [sp, #10288]                ; 8-byte Reload
	ldr	q4, [sp, #13520]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13520]                ; 16-byte Spill
	ldr	q10, [sp, #8224]                ; 16-byte Reload
	ldr	d3, [sp, #3288]                 ; 8-byte Reload
	bit.8b	v10, v3, v2
	ldr	d3, [sp, #10272]                ; 8-byte Reload
	ldr	q4, [sp, #13536]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13536]                ; 16-byte Spill
	ldr	d3, [sp, #10256]                ; 8-byte Reload
	ldr	q4, [sp, #13552]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13552]                ; 16-byte Spill
	ldr	d3, [sp, #10240]                ; 8-byte Reload
	ldr	q4, [sp, #13568]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13568]                ; 16-byte Spill
	ldr	q13, [sp, #8240]                ; 16-byte Reload
	ldr	d3, [sp, #10224]                ; 8-byte Reload
	bit.8b	v13, v3, v2
	ldr	d3, [sp, #10208]                ; 8-byte Reload
	ldr	q4, [sp, #13584]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13584]                ; 16-byte Spill
	ldr	d3, [sp, #10192]                ; 8-byte Reload
	ldr	q4, [sp, #13600]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13600]                ; 16-byte Spill
	ldr	d3, [sp, #10176]                ; 8-byte Reload
	ldr	q4, [sp, #13616]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13616]                ; 16-byte Spill
	ldr	q11, [sp, #8256]                ; 16-byte Reload
	ldr	d3, [sp, #3280]                 ; 8-byte Reload
	bit.8b	v11, v3, v2
	ldr	d3, [sp, #3272]                 ; 8-byte Reload
	ldr	q4, [sp, #13632]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13632]                ; 16-byte Spill
	ldr	d3, [sp, #3264]                 ; 8-byte Reload
	ldr	q4, [sp, #13648]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13648]                ; 16-byte Spill
	ldr	d3, [sp, #3256]                 ; 8-byte Reload
	ldr	q4, [sp, #13664]                ; 16-byte Reload
	bit.8b	v4, v3, v2
	str	q4, [sp, #13664]                ; 16-byte Spill
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bic.8b	v2, v3, v2
	ldr	q3, [sp, #3136]                 ; 16-byte Reload
	and.16b	v3, v3, v5
	xtn.8b	v3, v3
	orr.8b	v2, v3, v2
	str	q2, [sp, #12976]                ; 16-byte Spill
	ldr	q2, [sp, #2960]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q4, [sp, #112]                  ; 16-byte Reload
	ldr	q3, [sp, #2976]                 ; 16-byte Reload
	bsl.16b	v2, v3, v4
	str	q2, [sp, #14160]                ; 16-byte Spill
	ldr	q2, [sp, #3008]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #2992]                 ; 16-byte Reload
	bsl.16b	v2, v3, v4
	str	q2, [sp, #14144]                ; 16-byte Spill
	ldr	q2, [sp, #2864]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #2880]                 ; 16-byte Reload
	bsl.16b	v2, v3, v4
	str	q2, [sp, #14128]                ; 16-byte Spill
	ldr	q2, [sp, #2896]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	bsl.16b	v2, v3, v4
	str	q2, [sp, #14112]                ; 16-byte Spill
	ldr	q2, [sp, #2768]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #2784]                 ; 16-byte Reload
	bsl.16b	v2, v3, v4
	str	q2, [sp, #14096]                ; 16-byte Spill
	ldr	q2, [sp, #2800]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	bsl.16b	v2, v3, v4
	str	q2, [sp, #13952]                ; 16-byte Spill
	ldr	q2, [sp, #2656]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #2672]                 ; 16-byte Reload
	bsl.16b	v2, v3, v4
	str	q2, [sp, #10848]                ; 16-byte Spill
	ldr	q2, [sp, #2688]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #2704]                 ; 16-byte Reload
	bsl.16b	v2, v3, v4
	str	q2, [sp, #10832]                ; 16-byte Spill
	ldr	q2, [sp, #2592]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #2608]                 ; 16-byte Reload
	bsl.16b	v2, v3, v4
	str	q2, [sp, #10800]                ; 16-byte Spill
	ldr	q2, [sp, #2624]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #2640]                 ; 16-byte Reload
	bsl.16b	v2, v3, v4
	ldr	q3, [sp, #2560]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2576]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10768]                ; 16-byte Spill
	ldr	q3, [sp, #8544]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8560]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10784]                ; 16-byte Spill
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2544]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10736]                ; 16-byte Spill
	ldr	q3, [sp, #8576]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8592]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10752]                ; 16-byte Spill
	ldr	q3, [sp, #2496]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2512]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10592]                ; 16-byte Spill
	ldr	q3, [sp, #8608]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8624]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10720]                ; 16-byte Spill
	ldr	q3, [sp, #2464]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2480]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10704]                ; 16-byte Spill
	ldr	q3, [sp, #8640]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8656]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8224]                 ; 16-byte Spill
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2448]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10672]                ; 16-byte Spill
	ldr	q3, [sp, #8672]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8688]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10688]                ; 16-byte Spill
	ldr	q3, [sp, #2400]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2416]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10656]                ; 16-byte Spill
	ldr	q3, [sp, #8704]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8720]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10560]                ; 16-byte Spill
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2384]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10624]                ; 16-byte Spill
	ldr	q3, [sp, #8736]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8752]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10640]                ; 16-byte Spill
	ldr	q3, [sp, #2320]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2336]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10576]                ; 16-byte Spill
	ldr	q3, [sp, #8768]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8784]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10608]                ; 16-byte Spill
	ldr	q3, [sp, #2272]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2288]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10544]                ; 16-byte Spill
	ldr	q3, [sp, #8800]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8816]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8240]                 ; 16-byte Spill
	ldr	q3, [sp, #2240]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2256]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10352]                ; 16-byte Spill
	ldr	q3, [sp, #8832]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8848]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10528]                ; 16-byte Spill
	ldr	q3, [sp, #2208]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2224]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10512]                ; 16-byte Spill
	ldr	q3, [sp, #8864]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8880]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8256]                 ; 16-byte Spill
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2192]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10480]                ; 16-byte Spill
	ldr	q3, [sp, #8896]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8912]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10496]                ; 16-byte Spill
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2144]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10448]                ; 16-byte Spill
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8928]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10464]                ; 16-byte Spill
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2112]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10416]                ; 16-byte Spill
	ldr	q3, [sp, #8944]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8960]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10432]                ; 16-byte Spill
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2080]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10384]                ; 16-byte Spill
	ldr	q3, [sp, #8976]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #8992]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10400]                ; 16-byte Spill
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2016]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10368]                ; 16-byte Spill
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2048]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10304]                ; 16-byte Spill
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1984]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10336]                ; 16-byte Spill
	ldr	q3, [sp, #9008]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9024]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8064]                 ; 16-byte Spill
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1952]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10288]                ; 16-byte Spill
	ldr	q3, [sp, #9040]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9056]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10320]                ; 16-byte Spill
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1920]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10256]                ; 16-byte Spill
	ldr	q3, [sp, #9072]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9088]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10272]                ; 16-byte Spill
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1888]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10240]                ; 16-byte Spill
	ldr	q3, [sp, #9104]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9120]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #3312]                 ; 16-byte Spill
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1856]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10208]                ; 16-byte Spill
	ldr	q3, [sp, #9136]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9152]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10224]                ; 16-byte Spill
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1824]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10176]                ; 16-byte Spill
	ldr	q3, [sp, #9168]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9184]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #10192]                ; 16-byte Spill
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1792]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #3360]                 ; 16-byte Spill
	ldr	q3, [sp, #9200]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9216]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #3328]                 ; 16-byte Spill
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1728]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #3392]                 ; 16-byte Spill
	ldr	q3, [sp, #9232]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9248]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #3344]                 ; 16-byte Spill
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1696]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #3424]                 ; 16-byte Spill
	ldr	q3, [sp, #9264]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9280]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #3376]                 ; 16-byte Spill
	ldr	q3, [sp, #1648]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1664]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #3456]                 ; 16-byte Spill
	ldr	q3, [sp, #9296]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9312]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #3408]                 ; 16-byte Spill
	ldr	q3, [sp, #1616]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1632]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8528]                 ; 16-byte Spill
	ldr	q3, [sp, #9328]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9344]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #3440]                 ; 16-byte Spill
	ldr	q3, [sp, #1584]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1600]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8560]                 ; 16-byte Spill
	ldr	q3, [sp, #9360]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9376]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8512]                 ; 16-byte Spill
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1568]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8592]                 ; 16-byte Spill
	ldr	q3, [sp, #9392]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9408]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8544]                 ; 16-byte Spill
	ldr	q3, [sp, #1520]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1536]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8624]                 ; 16-byte Spill
	ldr	q3, [sp, #9424]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9440]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8576]                 ; 16-byte Spill
	ldr	q3, [sp, #1488]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1504]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8656]                 ; 16-byte Spill
	ldr	q3, [sp, #9456]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9472]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8608]                 ; 16-byte Spill
	ldr	q3, [sp, #1456]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1472]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8704]                 ; 16-byte Spill
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1760]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8640]                 ; 16-byte Spill
	ldr	q3, [sp, #1424]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1440]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9360]                 ; 16-byte Spill
	ldr	q3, [sp, #9488]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9504]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8688]                 ; 16-byte Spill
	ldr	q3, [sp, #1392]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1408]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8752]                 ; 16-byte Spill
	ldr	q3, [sp, #9520]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9536]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8720]                 ; 16-byte Spill
	ldr	q3, [sp, #1360]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1376]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9328]                 ; 16-byte Spill
	ldr	q3, [sp, #9552]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9568]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8736]                 ; 16-byte Spill
	ldr	q3, [sp, #1328]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1344]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8800]                 ; 16-byte Spill
	ldr	q3, [sp, #9584]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9600]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8768]                 ; 16-byte Spill
	ldr	q3, [sp, #1296]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1312]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8816]                 ; 16-byte Spill
	ldr	q3, [sp, #9616]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9632]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8784]                 ; 16-byte Spill
	ldr	q3, [sp, #1264]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1280]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9088]                 ; 16-byte Spill
	ldr	q3, [sp, #9648]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9664]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9664]                 ; 16-byte Spill
	ldr	q3, [sp, #1232]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1248]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9648]                 ; 16-byte Spill
	ldr	q3, [sp, #9680]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9696]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8832]                 ; 16-byte Spill
	ldr	q3, [sp, #1200]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1216]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9616]                 ; 16-byte Spill
	ldr	q3, [sp, #9712]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9728]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9632]                 ; 16-byte Spill
	ldr	q3, [sp, #1168]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1184]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9584]                 ; 16-byte Spill
	ldr	q3, [sp, #9744]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9760]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9600]                 ; 16-byte Spill
	ldr	q3, [sp, #1136]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1152]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9552]                 ; 16-byte Spill
	ldr	q3, [sp, #9776]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9792]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9568]                 ; 16-byte Spill
	ldr	q3, [sp, #1104]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1120]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9520]                 ; 16-byte Spill
	ldr	q3, [sp, #9808]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9824]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9536]                 ; 16-byte Spill
	ldr	q3, [sp, #1072]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1088]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9488]                 ; 16-byte Spill
	ldr	q3, [sp, #9840]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9856]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9504]                 ; 16-byte Spill
	ldr	q3, [sp, #1040]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #1056]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9456]                 ; 16-byte Spill
	ldr	q3, [sp, #9872]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9888]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9472]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #1008]             ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9424]                 ; 16-byte Spill
	ldr	q3, [sp, #9904]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9920]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9440]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #976]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9392]                 ; 16-byte Spill
	ldr	q3, [sp, #9936]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9952]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9408]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #944]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9344]                 ; 16-byte Spill
	ldr	q3, [sp, #2304]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2352]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9376]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #912]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9312]                 ; 16-byte Spill
	ldr	q3, [sp, #9968]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #9984]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8848]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #880]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9296]                 ; 16-byte Spill
	ldr	q3, [sp, #10000]                ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #10016]                ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8864]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #848]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9264]                 ; 16-byte Spill
	ldr	q3, [sp, #10032]                ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #10048]                ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9280]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #816]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9232]                 ; 16-byte Spill
	ldr	q3, [sp, #10064]                ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #10080]                ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9248]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #784]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9200]                 ; 16-byte Spill
	ldr	q3, [sp, #10096]                ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #10112]                ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9216]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #752]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9168]                 ; 16-byte Spill
	ldr	q3, [sp, #10128]                ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #10144]                ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9184]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #720]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9136]                 ; 16-byte Spill
	ldr	q3, [sp, #2720]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #10160]                ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9152]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #688]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9104]                 ; 16-byte Spill
	ldr	q3, [sp, #2736]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2752]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9120]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #656]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8928]                 ; 16-byte Spill
	ldr	q3, [sp, #2832]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2848]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8896]                 ; 16-byte Spill
	ldp	q3, q5, [sp, #624]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8960]                 ; 16-byte Spill
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #2944]                 ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8912]                 ; 16-byte Spill
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #592]                  ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8992]                 ; 16-byte Spill
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #608]                  ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8944]                 ; 16-byte Spill
	ldr	q3, [sp, #3104]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #560]                  ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9024]                 ; 16-byte Spill
	ldr	q3, [sp, #3120]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #576]                  ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8976]                 ; 16-byte Spill
	ldr	q3, [sp, #3152]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #528]                  ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9056]                 ; 16-byte Spill
	ldr	q3, [sp, #3168]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #544]                  ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9008]                 ; 16-byte Spill
	ldr	q3, [sp, #3184]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #496]                  ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8672]                 ; 16-byte Spill
	ldr	q3, [sp, #3200]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #512]                  ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9040]                 ; 16-byte Spill
	ldr	q3, [sp, #3216]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #464]                  ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #9072]                 ; 16-byte Spill
	ldr	q3, [sp, #3232]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q5, [sp, #480]                  ; 16-byte Reload
	bsl.16b	v3, v5, v4
	str	q3, [sp, #8880]                 ; 16-byte Spill
	ldr	q4, [sp, #12944]                ; 16-byte Reload
	zip1.8b	v3, v4, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v2, v3, v2
	str	q2, [sp, #10816]                ; 16-byte Spill
	zip2.8b	v2, v4, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10800]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10800]                ; 16-byte Spill
	zip1.8b	v2, v6, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10784]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10784]                ; 16-byte Spill
	str	q6, [sp, #7984]                 ; 16-byte Spill
	zip2.8b	v2, v6, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10768]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10768]                ; 16-byte Spill
	zip1.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10752]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10752]                ; 16-byte Spill
	str	q7, [sp, #8016]                 ; 16-byte Spill
	zip2.8b	v2, v7, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10736]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10736]                ; 16-byte Spill
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10720]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10720]                ; 16-byte Spill
	str	q16, [sp, #8048]                ; 16-byte Spill
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10592]                ; 16-byte Reload
	and.16b	v4, v2, v3
	zip1.8b	v2, v17, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8224]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10592]                ; 16-byte Spill
	str	q17, [sp, #8080]                ; 16-byte Spill
	zip2.8b	v2, v17, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10704]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10704]                ; 16-byte Spill
	zip1.8b	v2, v18, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10688]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10688]                ; 16-byte Spill
	str	q18, [sp, #8096]                ; 16-byte Spill
	zip2.8b	v2, v18, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10672]                ; 16-byte Reload
	and.16b	v17, v2, v3
	zip1.8b	v2, v19, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10560]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10672]                ; 16-byte Spill
	str	q19, [sp, #8112]                ; 16-byte Spill
	zip2.8b	v2, v19, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10656]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10656]                ; 16-byte Spill
	zip1.8b	v2, v20, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10640]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10640]                ; 16-byte Spill
	str	q20, [sp, #8128]                ; 16-byte Spill
	zip2.8b	v2, v20, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10624]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10624]                ; 16-byte Spill
	zip1.8b	v2, v22, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10608]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10608]                ; 16-byte Spill
	str	q22, [sp, #8144]                ; 16-byte Spill
	zip2.8b	v2, v22, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10576]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10560]                ; 16-byte Spill
	zip1.8b	v2, v23, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8240]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10576]                ; 16-byte Spill
	str	q23, [sp, #8160]                ; 16-byte Spill
	zip2.8b	v2, v23, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10544]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10544]                ; 16-byte Spill
	zip1.8b	v2, v24, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10528]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10528]                ; 16-byte Spill
	str	q24, [sp, #8176]                ; 16-byte Spill
	zip2.8b	v2, v24, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10352]                ; 16-byte Reload
	and.16b	v18, v2, v3
	zip1.8b	v2, v25, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8256]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10352]                ; 16-byte Spill
	str	q25, [sp, #8192]                ; 16-byte Spill
	zip2.8b	v2, v25, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10512]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10512]                ; 16-byte Spill
	zip1.8b	v2, v9, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10496]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10496]                ; 16-byte Spill
	str	q9, [sp, #8208]                 ; 16-byte Spill
	zip2.8b	v2, v9, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10480]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10480]                ; 16-byte Spill
	zip1.8b	v2, v10, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10464]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10464]                ; 16-byte Spill
	str	q10, [sp, #8224]                ; 16-byte Spill
	zip2.8b	v2, v10, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10448]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10448]                ; 16-byte Spill
	zip1.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10432]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10432]                ; 16-byte Spill
	str	q13, [sp, #8240]                ; 16-byte Spill
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10416]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10416]                ; 16-byte Spill
	zip1.8b	v2, v11, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10400]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10400]                ; 16-byte Spill
	str	q11, [sp, #8256]                ; 16-byte Spill
	zip2.8b	v2, v11, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10384]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10384]                ; 16-byte Spill
	ldr	q3, [sp, #12960]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #10304]                ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #10304]                ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10368]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10368]                ; 16-byte Spill
	zip1.8b	v2, v12, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8064]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10160]                ; 16-byte Spill
	str	q12, [sp, #8000]                ; 16-byte Spill
	zip2.8b	v2, v12, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10336]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10336]                ; 16-byte Spill
	zip1.8b	v2, v14, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10320]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10320]                ; 16-byte Spill
	str	q14, [sp, #8032]                ; 16-byte Spill
	zip2.8b	v2, v14, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10288]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10288]                ; 16-byte Spill
	zip1.8b	v2, v15, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10272]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10272]                ; 16-byte Spill
	str	q15, [sp, #8064]                ; 16-byte Spill
	zip2.8b	v2, v15, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10256]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10256]                ; 16-byte Spill
	ldr	q3, [sp, #13104]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #3312]                 ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #9904]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10240]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10240]                ; 16-byte Spill
	ldr	q3, [sp, #13152]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #10224]                ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #10224]                ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10208]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10208]                ; 16-byte Spill
	ldr	q3, [sp, #13200]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #10192]                ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #10192]                ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #10176]                ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10176]                ; 16-byte Spill
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #3328]                 ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #10080]                ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #3360]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10144]                ; 16-byte Spill
	ldr	q3, [sp, #13296]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #3344]                 ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #10128]                ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #3392]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9952]                 ; 16-byte Spill
	ldr	q3, [sp, #13344]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #3376]                 ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #10112]                ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #3424]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10096]                ; 16-byte Spill
	ldr	q3, [sp, #13392]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #3408]                 ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #10064]                ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #3456]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10048]                ; 16-byte Spill
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #3440]                 ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #9776]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8528]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10032]                ; 16-byte Spill
	ldr	q3, [sp, #13488]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #8512]                 ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #10016]                ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8560]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #10000]                ; 16-byte Spill
	ldr	q3, [sp, #13536]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #8544]                 ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #9984]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8592]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9968]                 ; 16-byte Spill
	ldr	q3, [sp, #13584]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #8576]                 ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #9856]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8624]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9936]                 ; 16-byte Spill
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #8608]                 ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #9920]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8656]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9712]                 ; 16-byte Spill
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #8640]                 ; 16-byte Reload
	and.16b	v2, v2, v5
	str	q2, [sp, #9888]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8704]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9872]                 ; 16-byte Spill
	ldr	q3, [sp, #13008]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #8688]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9840]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9360]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9360]                 ; 16-byte Spill
	ldr	q3, [sp, #13040]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #8720]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9824]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8752]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9808]                 ; 16-byte Spill
	ldr	q3, [sp, #13072]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #8736]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9792]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9328]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9760]                 ; 16-byte Spill
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #8768]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9328]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8800]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9744]                 ; 16-byte Spill
	ldr	q3, [sp, #13168]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #8784]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9728]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8816]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9680]                 ; 16-byte Spill
	ldr	q3, [sp, #13216]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9664]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9696]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9088]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9664]                 ; 16-byte Spill
	ldr	q3, [sp, #13264]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #8832]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9088]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9648]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9648]                 ; 16-byte Spill
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9632]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9632]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9616]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9616]                 ; 16-byte Spill
	ldr	q3, [sp, #13360]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9600]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9600]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9584]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9584]                 ; 16-byte Spill
	ldr	q3, [sp, #13408]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9568]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9568]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9552]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9552]                 ; 16-byte Spill
	ldr	q3, [sp, #13456]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9536]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9536]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9520]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9520]                 ; 16-byte Spill
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9504]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9504]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9488]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9488]                 ; 16-byte Spill
	ldr	q3, [sp, #13552]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9472]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9472]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9456]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9456]                 ; 16-byte Spill
	ldr	q3, [sp, #13600]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9440]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9440]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9424]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9424]                 ; 16-byte Spill
	ldr	q3, [sp, #13648]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9408]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9408]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9392]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9392]                 ; 16-byte Spill
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9376]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9376]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9344]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9344]                 ; 16-byte Spill
	ldr	q3, [sp, #13024]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #8848]                 ; 16-byte Reload
	and.16b	v12, v2, v6
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9312]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9312]                 ; 16-byte Spill
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #8864]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #8800]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9296]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9296]                 ; 16-byte Spill
	ldr	q3, [sp, #13088]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9280]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9280]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9264]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9264]                 ; 16-byte Spill
	ldr	q3, [sp, #13136]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9248]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9248]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9232]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9232]                 ; 16-byte Spill
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9216]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9216]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9200]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9200]                 ; 16-byte Spill
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9184]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9184]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9168]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9168]                 ; 16-byte Spill
	ldr	q3, [sp, #13280]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9152]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9152]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9136]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9136]                 ; 16-byte Spill
	ldr	q3, [sp, #13328]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9120]                 ; 16-byte Reload
	and.16b	v2, v2, v6
	str	q2, [sp, #9120]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9104]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	str	q2, [sp, #9104]                 ; 16-byte Spill
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #8896]                 ; 16-byte Reload
	and.16b	v15, v2, v6
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8928]                 ; 16-byte Reload
	and.16b	v14, v2, v3
	ldr	q3, [sp, #13424]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #8912]                 ; 16-byte Reload
	and.16b	v13, v2, v6
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8960]                 ; 16-byte Reload
	and.16b	v11, v2, v3
	ldr	q3, [sp, #13472]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #8944]                 ; 16-byte Reload
	and.16b	v10, v2, v6
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8992]                 ; 16-byte Reload
	and.16b	v9, v2, v3
	ldr	q3, [sp, #13520]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #8976]                 ; 16-byte Reload
	and.16b	v25, v2, v6
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9024]                 ; 16-byte Reload
	and.16b	v24, v2, v3
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9008]                 ; 16-byte Reload
	and.16b	v23, v2, v6
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9056]                 ; 16-byte Reload
	and.16b	v19, v2, v3
	ldr	q3, [sp, #13616]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #9040]                 ; 16-byte Reload
	and.16b	v7, v2, v6
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #8672]                 ; 16-byte Reload
	and.16b	v6, v2, v3
	ldr	q3, [sp, #13664]                ; 16-byte Reload
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q5, [sp, #8880]                 ; 16-byte Reload
	and.16b	v5, v2, v5
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #9072]                 ; 16-byte Reload
	and.16b	v16, v2, v3
	ldr	q2, [sp, #5536]                 ; 16-byte Reload
	ldr	q3, [sp, #14160]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5536]                 ; 16-byte Spill
	str	q2, [x9, #2048]
	ldr	q2, [sp, #5520]                 ; 16-byte Reload
	ldr	q3, [sp, #14144]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5520]                 ; 16-byte Spill
	str	q2, [x9, #2064]
	ldr	q2, [sp, #5568]                 ; 16-byte Reload
	ldr	q3, [sp, #14128]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5568]                 ; 16-byte Spill
	str	q2, [x9, #2080]
	ldr	q2, [sp, #5552]                 ; 16-byte Reload
	ldr	q3, [sp, #14112]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5552]                 ; 16-byte Spill
	str	q2, [x9, #2096]
	ldr	q2, [sp, #5600]                 ; 16-byte Reload
	ldr	q3, [sp, #14096]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5600]                 ; 16-byte Spill
	str	q2, [x9, #2112]
	ldr	q2, [sp, #5584]                 ; 16-byte Reload
	ldr	q3, [sp, #13952]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5584]                 ; 16-byte Spill
	str	q2, [x9, #2128]
	ldr	q20, [sp, #5632]                ; 16-byte Reload
	ldr	q2, [sp, #10848]                ; 16-byte Reload
	bit.16b	v20, v2, v1
	str	q20, [x9, #2144]
	ldr	q2, [sp, #5616]                 ; 16-byte Reload
	ldr	q3, [sp, #10832]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5616]                 ; 16-byte Spill
	str	q2, [x9, #2160]
	ldr	q3, [sp, #3472]                 ; 16-byte Reload
	ldr	q2, [sp, #10800]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3488]                 ; 16-byte Reload
	ldr	q22, [sp, #10816]               ; 16-byte Reload
	bit.16b	v2, v22, v1
	str	q2, [sp, #3488]                 ; 16-byte Spill
	stp	q2, q3, [x9]
	str	q3, [sp, #3472]                 ; 16-byte Spill
	ldr	q3, [sp, #3504]                 ; 16-byte Reload
	ldr	q2, [sp, #10768]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3520]                 ; 16-byte Reload
	ldr	q22, [sp, #10784]               ; 16-byte Reload
	bit.16b	v2, v22, v1
	str	q2, [sp, #3520]                 ; 16-byte Spill
	stp	q2, q3, [x9, #32]
	str	q3, [sp, #3504]                 ; 16-byte Spill
	ldr	q3, [sp, #3536]                 ; 16-byte Reload
	ldr	q2, [sp, #10736]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3552]                 ; 16-byte Reload
	ldr	q22, [sp, #10752]               ; 16-byte Reload
	bit.16b	v2, v22, v1
	str	q2, [sp, #3552]                 ; 16-byte Spill
	stp	q2, q3, [x9, #64]
	str	q3, [sp, #3536]                 ; 16-byte Spill
	ldr	q3, [sp, #3568]                 ; 16-byte Reload
	str	q4, [sp, #9072]                 ; 16-byte Spill
	bit.16b	v3, v4, v0
	ldr	q2, [sp, #3584]                 ; 16-byte Reload
	ldr	q4, [sp, #10720]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3584]                 ; 16-byte Spill
	stp	q2, q3, [x9, #96]
	str	q3, [sp, #3568]                 ; 16-byte Spill
	ldr	q3, [sp, #3600]                 ; 16-byte Reload
	ldr	q2, [sp, #10704]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3616]                 ; 16-byte Reload
	ldr	q4, [sp, #10592]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3616]                 ; 16-byte Spill
	stp	q2, q3, [x9, #128]
	str	q3, [sp, #3600]                 ; 16-byte Spill
	ldr	q3, [sp, #3632]                 ; 16-byte Reload
	str	q17, [sp, #9056]                ; 16-byte Spill
	bit.16b	v3, v17, v0
	ldr	q2, [sp, #3648]                 ; 16-byte Reload
	ldr	q4, [sp, #10688]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3648]                 ; 16-byte Spill
	stp	q2, q3, [x9, #160]
	str	q3, [sp, #3632]                 ; 16-byte Spill
	ldr	q3, [sp, #3664]                 ; 16-byte Reload
	ldr	q2, [sp, #10656]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3680]                 ; 16-byte Reload
	ldr	q4, [sp, #10672]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3680]                 ; 16-byte Spill
	stp	q2, q3, [x9, #192]
	str	q3, [sp, #3664]                 ; 16-byte Spill
	ldr	q3, [sp, #3696]                 ; 16-byte Reload
	ldr	q2, [sp, #10624]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3712]                 ; 16-byte Reload
	ldr	q4, [sp, #10640]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3712]                 ; 16-byte Spill
	stp	q2, q3, [x9, #224]
	str	q3, [sp, #3696]                 ; 16-byte Spill
	ldr	q3, [sp, #3728]                 ; 16-byte Reload
	ldr	q2, [sp, #10560]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3744]                 ; 16-byte Reload
	ldr	q4, [sp, #10608]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3744]                 ; 16-byte Spill
	stp	q2, q3, [x9, #256]
	str	q3, [sp, #3728]                 ; 16-byte Spill
	ldr	q3, [sp, #3760]                 ; 16-byte Reload
	ldr	q2, [sp, #10544]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3776]                 ; 16-byte Reload
	ldr	q4, [sp, #10576]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3776]                 ; 16-byte Spill
	stp	q2, q3, [x9, #288]
	str	q3, [sp, #3760]                 ; 16-byte Spill
	ldr	q3, [sp, #3792]                 ; 16-byte Reload
	str	q18, [sp, #9040]                ; 16-byte Spill
	bit.16b	v3, v18, v0
	ldr	q2, [sp, #3808]                 ; 16-byte Reload
	ldr	q4, [sp, #10528]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3808]                 ; 16-byte Spill
	stp	q2, q3, [x9, #320]
	str	q3, [sp, #3792]                 ; 16-byte Spill
	ldr	q3, [sp, #3824]                 ; 16-byte Reload
	ldr	q2, [sp, #10512]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3840]                 ; 16-byte Reload
	ldr	q4, [sp, #10352]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3840]                 ; 16-byte Spill
	stp	q2, q3, [x9, #352]
	str	q3, [sp, #3824]                 ; 16-byte Spill
	ldr	q3, [sp, #3856]                 ; 16-byte Reload
	ldr	q2, [sp, #10480]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3872]                 ; 16-byte Reload
	ldr	q4, [sp, #10496]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3872]                 ; 16-byte Spill
	stp	q2, q3, [x9, #384]
	str	q3, [sp, #3856]                 ; 16-byte Spill
	ldr	q3, [sp, #3888]                 ; 16-byte Reload
	ldr	q2, [sp, #10448]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3904]                 ; 16-byte Reload
	ldr	q4, [sp, #10464]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3904]                 ; 16-byte Spill
	stp	q2, q3, [x9, #416]
	str	q3, [sp, #3888]                 ; 16-byte Spill
	ldr	q3, [sp, #3920]                 ; 16-byte Reload
	ldr	q2, [sp, #10416]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3936]                 ; 16-byte Reload
	ldr	q4, [sp, #10432]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3936]                 ; 16-byte Spill
	stp	q2, q3, [x9, #448]
	str	q3, [sp, #3920]                 ; 16-byte Spill
	ldr	q3, [sp, #3952]                 ; 16-byte Reload
	ldr	q2, [sp, #10384]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #3968]                 ; 16-byte Reload
	ldr	q4, [sp, #10400]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3968]                 ; 16-byte Spill
	stp	q2, q3, [x9, #480]
	str	q3, [sp, #3952]                 ; 16-byte Spill
	ldr	q3, [sp, #3984]                 ; 16-byte Reload
	ldr	q2, [sp, #10368]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4000]                 ; 16-byte Reload
	ldr	q4, [sp, #10304]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4000]                 ; 16-byte Spill
	stp	q2, q3, [x9, #512]
	str	q3, [sp, #3984]                 ; 16-byte Spill
	ldr	q3, [sp, #4016]                 ; 16-byte Reload
	ldr	q2, [sp, #10336]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4032]                 ; 16-byte Reload
	ldr	q4, [sp, #10160]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4032]                 ; 16-byte Spill
	stp	q2, q3, [x9, #544]
	str	q3, [sp, #4016]                 ; 16-byte Spill
	ldr	q3, [sp, #4048]                 ; 16-byte Reload
	ldr	q2, [sp, #10288]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4064]                 ; 16-byte Reload
	ldr	q4, [sp, #10320]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4064]                 ; 16-byte Spill
	stp	q2, q3, [x9, #576]
	str	q3, [sp, #4048]                 ; 16-byte Spill
	ldr	q3, [sp, #4080]                 ; 16-byte Reload
	ldr	q2, [sp, #10256]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4096]                 ; 16-byte Reload
	ldr	q4, [sp, #10272]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4096]                 ; 16-byte Spill
	stp	q2, q3, [x9, #608]
	str	q3, [sp, #4080]                 ; 16-byte Spill
	ldr	q3, [sp, #4112]                 ; 16-byte Reload
	ldr	q2, [sp, #10240]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4128]                 ; 16-byte Reload
	ldr	q4, [sp, #9904]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4128]                 ; 16-byte Spill
	stp	q2, q3, [x9, #640]
	str	q3, [sp, #4112]                 ; 16-byte Spill
	ldr	q3, [sp, #4144]                 ; 16-byte Reload
	ldr	q2, [sp, #10208]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4160]                 ; 16-byte Reload
	ldr	q4, [sp, #10224]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4160]                 ; 16-byte Spill
	stp	q2, q3, [x9, #672]
	str	q3, [sp, #4144]                 ; 16-byte Spill
	ldr	q3, [sp, #4176]                 ; 16-byte Reload
	ldr	q2, [sp, #10176]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4192]                 ; 16-byte Reload
	ldr	q4, [sp, #10192]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4192]                 ; 16-byte Spill
	stp	q2, q3, [x9, #704]
	str	q3, [sp, #4176]                 ; 16-byte Spill
	ldr	q3, [sp, #4208]                 ; 16-byte Reload
	ldr	q2, [sp, #10144]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4224]                 ; 16-byte Reload
	ldr	q4, [sp, #10080]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4224]                 ; 16-byte Spill
	stp	q2, q3, [x9, #736]
	str	q3, [sp, #4208]                 ; 16-byte Spill
	ldr	q3, [sp, #4240]                 ; 16-byte Reload
	ldr	q2, [sp, #9952]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4256]                 ; 16-byte Reload
	ldr	q4, [sp, #10128]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4256]                 ; 16-byte Spill
	stp	q2, q3, [x9, #768]
	str	q3, [sp, #4240]                 ; 16-byte Spill
	ldr	q3, [sp, #4272]                 ; 16-byte Reload
	ldr	q2, [sp, #10096]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4288]                 ; 16-byte Reload
	ldr	q4, [sp, #10112]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4288]                 ; 16-byte Spill
	stp	q2, q3, [x9, #800]
	str	q3, [sp, #4272]                 ; 16-byte Spill
	ldr	q3, [sp, #4304]                 ; 16-byte Reload
	ldr	q2, [sp, #10048]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4320]                 ; 16-byte Reload
	ldr	q4, [sp, #10064]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4320]                 ; 16-byte Spill
	stp	q2, q3, [x9, #832]
	str	q3, [sp, #4304]                 ; 16-byte Spill
	ldr	q3, [sp, #4336]                 ; 16-byte Reload
	ldr	q2, [sp, #10032]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4352]                 ; 16-byte Reload
	ldr	q4, [sp, #9776]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4352]                 ; 16-byte Spill
	stp	q2, q3, [x9, #864]
	str	q3, [sp, #4336]                 ; 16-byte Spill
	ldr	q3, [sp, #4368]                 ; 16-byte Reload
	ldr	q2, [sp, #10000]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4384]                 ; 16-byte Reload
	ldr	q4, [sp, #10016]                ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4384]                 ; 16-byte Spill
	stp	q2, q3, [x9, #896]
	str	q3, [sp, #4368]                 ; 16-byte Spill
	ldr	q3, [sp, #4400]                 ; 16-byte Reload
	ldr	q2, [sp, #9968]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4416]                 ; 16-byte Reload
	ldr	q4, [sp, #9984]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4416]                 ; 16-byte Spill
	stp	q2, q3, [x9, #928]
	str	q3, [sp, #4400]                 ; 16-byte Spill
	ldr	q3, [sp, #4432]                 ; 16-byte Reload
	ldr	q2, [sp, #9936]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4448]                 ; 16-byte Reload
	ldr	q4, [sp, #9856]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4448]                 ; 16-byte Spill
	stp	q2, q3, [x9, #960]
	str	q3, [sp, #4432]                 ; 16-byte Spill
	ldr	q3, [sp, #4464]                 ; 16-byte Reload
	ldr	q2, [sp, #9712]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	ldr	q2, [sp, #4480]                 ; 16-byte Reload
	ldr	q4, [sp, #9920]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4480]                 ; 16-byte Spill
	stp	q2, q3, [x9, #992]
	str	q3, [sp, #4464]                 ; 16-byte Spill
	ldr	q2, [sp, #4512]                 ; 16-byte Reload
	ldr	q3, [sp, #9888]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4512]                 ; 16-byte Spill
	str	q2, [x9, #1024]
	ldr	q2, [sp, #4496]                 ; 16-byte Reload
	ldr	q3, [sp, #9872]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4496]                 ; 16-byte Spill
	str	q2, [x9, #1040]
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #9840]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4544]                 ; 16-byte Spill
	str	q2, [x9, #1056]
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #9360]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4528]                 ; 16-byte Spill
	str	q2, [x9, #1072]
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #9824]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4576]                 ; 16-byte Spill
	str	q2, [x9, #1088]
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q4, [sp, #9808]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #4560]                 ; 16-byte Spill
	str	q2, [x9, #1104]
	ldr	q2, [sp, #4608]                 ; 16-byte Reload
	ldr	q4, [sp, #9792]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4608]                 ; 16-byte Spill
	str	q2, [x9, #1120]
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	ldr	q4, [sp, #9760]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #4592]                 ; 16-byte Spill
	str	q2, [x9, #1136]
	ldr	q2, [sp, #4640]                 ; 16-byte Reload
	ldr	q4, [sp, #9328]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4640]                 ; 16-byte Spill
	str	q2, [x9, #1152]
	ldr	q2, [sp, #4624]                 ; 16-byte Reload
	ldr	q4, [sp, #9744]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #4624]                 ; 16-byte Spill
	str	q2, [x9, #1168]
	ldr	q2, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #9728]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #4672]                 ; 16-byte Spill
	str	q2, [x9, #1184]
	ldr	q2, [sp, #4656]                 ; 16-byte Reload
	ldr	q3, [sp, #9680]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4656]                 ; 16-byte Spill
	str	q2, [x9, #1200]
	ldr	q2, [sp, #4704]                 ; 16-byte Reload
	ldr	q3, [sp, #9696]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4704]                 ; 16-byte Spill
	str	q2, [x9, #1216]
	ldr	q2, [sp, #4688]                 ; 16-byte Reload
	ldr	q3, [sp, #9664]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4688]                 ; 16-byte Spill
	str	q2, [x9, #1232]
	ldr	q2, [sp, #4736]                 ; 16-byte Reload
	ldr	q3, [sp, #9088]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4736]                 ; 16-byte Spill
	str	q2, [x9, #1248]
	ldr	q2, [sp, #4720]                 ; 16-byte Reload
	ldr	q3, [sp, #9648]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4720]                 ; 16-byte Spill
	str	q2, [x9, #1264]
	ldr	q2, [sp, #4768]                 ; 16-byte Reload
	ldr	q3, [sp, #9632]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4768]                 ; 16-byte Spill
	str	q2, [x9, #1280]
	ldr	q2, [sp, #4752]                 ; 16-byte Reload
	ldr	q3, [sp, #9616]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4752]                 ; 16-byte Spill
	str	q2, [x9, #1296]
	ldr	q2, [sp, #4800]                 ; 16-byte Reload
	ldr	q3, [sp, #9600]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4800]                 ; 16-byte Spill
	str	q2, [x9, #1312]
	ldr	q2, [sp, #4784]                 ; 16-byte Reload
	ldr	q3, [sp, #9584]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4784]                 ; 16-byte Spill
	str	q2, [x9, #1328]
	ldr	q2, [sp, #4832]                 ; 16-byte Reload
	ldr	q3, [sp, #9568]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4832]                 ; 16-byte Spill
	str	q2, [x9, #1344]
	ldr	q2, [sp, #4816]                 ; 16-byte Reload
	ldr	q3, [sp, #9552]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4816]                 ; 16-byte Spill
	str	q2, [x9, #1360]
	ldr	q2, [sp, #4864]                 ; 16-byte Reload
	ldr	q3, [sp, #9536]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4864]                 ; 16-byte Spill
	str	q2, [x9, #1376]
	ldr	q2, [sp, #4848]                 ; 16-byte Reload
	ldr	q3, [sp, #9520]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4848]                 ; 16-byte Spill
	str	q2, [x9, #1392]
	ldr	q2, [sp, #4896]                 ; 16-byte Reload
	ldr	q3, [sp, #9504]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4896]                 ; 16-byte Spill
	str	q2, [x9, #1408]
	ldr	q2, [sp, #4880]                 ; 16-byte Reload
	ldr	q3, [sp, #9488]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4880]                 ; 16-byte Spill
	str	q2, [x9, #1424]
	ldr	q2, [sp, #4928]                 ; 16-byte Reload
	ldr	q3, [sp, #9472]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4928]                 ; 16-byte Spill
	str	q2, [x9, #1440]
	ldr	q2, [sp, #4912]                 ; 16-byte Reload
	ldr	q3, [sp, #9456]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4912]                 ; 16-byte Spill
	str	q2, [x9, #1456]
	ldr	q2, [sp, #4960]                 ; 16-byte Reload
	ldr	q3, [sp, #9440]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4960]                 ; 16-byte Spill
	str	q2, [x9, #1472]
	ldr	q2, [sp, #4944]                 ; 16-byte Reload
	ldr	q3, [sp, #9424]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4944]                 ; 16-byte Spill
	str	q2, [x9, #1488]
	ldr	q2, [sp, #4992]                 ; 16-byte Reload
	ldr	q3, [sp, #9408]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4992]                 ; 16-byte Spill
	str	q2, [x9, #1504]
	ldr	q2, [sp, #4976]                 ; 16-byte Reload
	ldr	q3, [sp, #9392]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #4976]                 ; 16-byte Spill
	str	q2, [x9, #1520]
	ldr	q2, [sp, #5024]                 ; 16-byte Reload
	ldr	q3, [sp, #9376]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5024]                 ; 16-byte Spill
	str	q2, [x9, #1536]
	ldr	q2, [sp, #5008]                 ; 16-byte Reload
	ldr	q3, [sp, #9344]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5008]                 ; 16-byte Spill
	str	q2, [x9, #1552]
	ldr	q2, [sp, #5056]                 ; 16-byte Reload
	str	q12, [sp, #9024]                ; 16-byte Spill
	bit.16b	v2, v12, v1
	ldr	q12, [sp, #8800]                ; 16-byte Reload
	str	q2, [sp, #5056]                 ; 16-byte Spill
	str	q2, [x9, #1568]
	ldr	q2, [sp, #5040]                 ; 16-byte Reload
	ldr	q3, [sp, #9312]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5040]                 ; 16-byte Spill
	str	q2, [x9, #1584]
	ldr	q2, [sp, #5088]                 ; 16-byte Reload
	bit.16b	v2, v12, v1
	str	q2, [sp, #5088]                 ; 16-byte Spill
	str	q2, [x9, #1600]
	ldr	q2, [sp, #5072]                 ; 16-byte Reload
	ldr	q3, [sp, #9296]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5072]                 ; 16-byte Spill
	str	q2, [x9, #1616]
	ldr	q2, [sp, #5120]                 ; 16-byte Reload
	ldr	q3, [sp, #9280]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5120]                 ; 16-byte Spill
	str	q2, [x9, #1632]
	ldr	q2, [sp, #5104]                 ; 16-byte Reload
	ldr	q3, [sp, #9264]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5104]                 ; 16-byte Spill
	str	q2, [x9, #1648]
	ldr	q2, [sp, #5152]                 ; 16-byte Reload
	ldr	q3, [sp, #9248]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5152]                 ; 16-byte Spill
	str	q2, [x9, #1664]
	ldr	q2, [sp, #5136]                 ; 16-byte Reload
	ldr	q3, [sp, #9232]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5136]                 ; 16-byte Spill
	str	q2, [x9, #1680]
	ldr	q2, [sp, #5184]                 ; 16-byte Reload
	ldr	q3, [sp, #9216]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5184]                 ; 16-byte Spill
	str	q2, [x9, #1696]
	ldr	q2, [sp, #5168]                 ; 16-byte Reload
	ldr	q3, [sp, #9200]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5168]                 ; 16-byte Spill
	str	q2, [x9, #1712]
	ldr	q2, [sp, #5216]                 ; 16-byte Reload
	ldr	q3, [sp, #9184]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5216]                 ; 16-byte Spill
	str	q2, [x9, #1728]
	ldr	q2, [sp, #5200]                 ; 16-byte Reload
	ldr	q3, [sp, #9168]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5200]                 ; 16-byte Spill
	str	q2, [x9, #1744]
	ldr	q2, [sp, #5248]                 ; 16-byte Reload
	ldr	q3, [sp, #9152]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5248]                 ; 16-byte Spill
	str	q2, [x9, #1760]
	ldr	q2, [sp, #5232]                 ; 16-byte Reload
	ldr	q3, [sp, #9136]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5232]                 ; 16-byte Spill
	str	q2, [x9, #1776]
	ldr	q2, [sp, #5280]                 ; 16-byte Reload
	ldr	q3, [sp, #9120]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5280]                 ; 16-byte Spill
	str	q2, [x9, #1792]
	ldr	q2, [sp, #5264]                 ; 16-byte Reload
	ldr	q3, [sp, #9104]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #5264]                 ; 16-byte Spill
	str	q2, [x9, #1808]
	ldr	q2, [sp, #5312]                 ; 16-byte Reload
	str	q15, [sp, #9008]                ; 16-byte Spill
	bit.16b	v2, v15, v1
	str	q2, [sp, #5312]                 ; 16-byte Spill
	str	q2, [x9, #1824]
	ldr	q2, [sp, #5296]                 ; 16-byte Reload
	str	q14, [sp, #8992]                ; 16-byte Spill
	bit.16b	v2, v14, v0
	str	q2, [sp, #5296]                 ; 16-byte Spill
	str	q2, [x9, #1840]
	ldr	q2, [sp, #5344]                 ; 16-byte Reload
	str	q13, [sp, #8976]                ; 16-byte Spill
	bit.16b	v2, v13, v1
	str	q2, [sp, #5344]                 ; 16-byte Spill
	str	q2, [x9, #1856]
	ldr	q2, [sp, #5328]                 ; 16-byte Reload
	str	q11, [sp, #8960]                ; 16-byte Spill
	bit.16b	v2, v11, v0
	str	q2, [sp, #5328]                 ; 16-byte Spill
	str	q2, [x9, #1872]
	ldr	q2, [sp, #5376]                 ; 16-byte Reload
	str	q10, [sp, #8944]                ; 16-byte Spill
	bit.16b	v2, v10, v1
	str	q2, [sp, #5376]                 ; 16-byte Spill
	str	q2, [x9, #1888]
	ldr	q2, [sp, #5360]                 ; 16-byte Reload
	str	q9, [sp, #8928]                 ; 16-byte Spill
	bit.16b	v2, v9, v0
	str	q2, [sp, #5360]                 ; 16-byte Spill
	str	q2, [x9, #1904]
	ldr	q2, [sp, #5408]                 ; 16-byte Reload
	str	q25, [sp, #8912]                ; 16-byte Spill
	bit.16b	v2, v25, v1
	str	q2, [sp, #5408]                 ; 16-byte Spill
	str	q2, [x9, #1920]
	ldr	q2, [sp, #5392]                 ; 16-byte Reload
	str	q24, [sp, #8896]                ; 16-byte Spill
	bit.16b	v2, v24, v0
	str	q2, [sp, #5392]                 ; 16-byte Spill
	str	q2, [x9, #1936]
	ldr	q2, [sp, #5440]                 ; 16-byte Reload
	str	q23, [sp, #8880]                ; 16-byte Spill
	bit.16b	v2, v23, v1
	str	q2, [sp, #5440]                 ; 16-byte Spill
	str	q2, [x9, #1952]
	ldr	q2, [sp, #5424]                 ; 16-byte Reload
	str	q19, [sp, #8864]                ; 16-byte Spill
	bit.16b	v2, v19, v0
	str	q2, [sp, #5424]                 ; 16-byte Spill
	str	q2, [x9, #1968]
	ldr	q2, [sp, #5472]                 ; 16-byte Reload
	str	q7, [sp, #8848]                 ; 16-byte Spill
	bit.16b	v2, v7, v1
	str	q2, [sp, #5472]                 ; 16-byte Spill
	str	q2, [x9, #1984]
	ldr	q2, [sp, #5456]                 ; 16-byte Reload
	str	q6, [sp, #8832]                 ; 16-byte Spill
	bit.16b	v2, v6, v0
	str	q2, [sp, #5456]                 ; 16-byte Spill
	str	q2, [x9, #2000]
	ldr	q2, [sp, #5504]                 ; 16-byte Reload
	str	q5, [sp, #8816]                 ; 16-byte Spill
	bit.16b	v2, v5, v1
	str	q2, [sp, #5504]                 ; 16-byte Spill
	str	q2, [x9, #2016]
	ldr	q2, [sp, #5488]                 ; 16-byte Reload
	mov.16b	v17, v16
	bit.16b	v2, v16, v0
	str	q2, [sp, #5488]                 ; 16-byte Spill
	str	q2, [x9, #2032]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2192
	ldr	q10, [sp, #8432]                ; 16-byte Reload
	ldr	q13, [sp, #8416]                ; 16-byte Reload
	ldr	q11, [sp, #10896]               ; 16-byte Reload
LBB0_71:                                ; %direct.schedule.93.preheader
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_72 Depth 3
                                        ;         Child Loop BB0_73 Depth 4
	mov	x10, #0                         ; =0x0
	lsl	x11, x23, #5
	add	x12, x7, x23, lsl #10
	add	x1, x19, x11
	ldp	q23, q22, [x1]
	add	x1, x4, #64
LBB0_72:                                ; %direct.true1912
                                        ;   Parent Loop BB0_22 Depth=1
                                        ;     Parent Loop BB0_71 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_73 Depth 4
	mov	x2, #0                          ; =0x0
	orr	x6, x11, x10, lsl #2
	orr	x3, x6, #0x1
	and	x5, x3, x20
	add	x5, x12, x5, lsl #5
	ldp	q3, q2, [x5]
	orr	x5, x6, #0x2
	and	x24, x5, #0x1e
	add	x24, x12, x24, lsl #5
	ldp	q5, q4, [x24]
	add	x24, x12, x10, lsl #7
	ldp	q7, q6, [x24]
	fmul.4s	v7, v7, v23
	fmul.4s	v6, v6, v22
	fmul.4s	v3, v23, v3
	fmul.4s	v2, v22, v2
	fmul.4s	v5, v23, v5
	fmul.4s	v4, v22, v4
	ldp	q19, q18, [x24, #96]
	fmul.4s	v19, v23, v19
	fmul.4s	v18, v22, v18
	bit.16b	v8, v6, v0
	bit.16b	v31, v7, v1
	bit.16b	v30, v2, v0
	bit.16b	v29, v3, v1
	bit.16b	v28, v4, v0
	bit.16b	v27, v5, v1
	bit.16b	v26, v18, v0
	bit.16b	v21, v19, v1
	mov	x24, x1
LBB0_73:                                ; %direct.true1957
                                        ;   Parent Loop BB0_22 Depth=1
                                        ;     Parent Loop BB0_71 Depth=2
                                        ;       Parent Loop BB0_72 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	add	x25, x8, x2
	ldp	q3, q2, [x25]
	and.16b	v3, v1, v3
	and.16b	v2, v0, v2
	ldp	q5, q4, [x24, #-64]
	and.16b	v5, v1, v5
	and.16b	v4, v0, v4
	fmul.4s	v4, v2, v4
	fmul.4s	v5, v3, v5
	fadd.4s	v5, v31, v5
	fadd.4s	v25, v8, v4
	ldp	q6, q4, [x24, #-32]
	and.16b	v6, v1, v6
	and.16b	v4, v0, v4
	fmul.4s	v4, v2, v4
	fmul.4s	v6, v3, v6
	fadd.4s	v24, v29, v6
	fadd.4s	v14, v30, v4
	ldp	q6, q4, [x24]
	and.16b	v6, v1, v6
	and.16b	v4, v0, v4
	fmul.4s	v4, v2, v4
	fmul.4s	v6, v3, v6
	fadd.4s	v9, v27, v6
	fadd.4s	v15, v28, v4
	ldp	q6, q4, [x24, #32]
	and.16b	v6, v1, v6
	and.16b	v4, v0, v4
	fmul.4s	v4, v2, v4
	fmul.4s	v2, v3, v6
	fadd.4s	v2, v21, v2
	fadd.4s	v6, v26, v4
	bit.16b	v8, v25, v0
	bit.16b	v31, v5, v1
	bit.16b	v30, v14, v0
	bit.16b	v29, v24, v1
	bit.16b	v28, v15, v0
	bit.16b	v27, v9, v1
	bit.16b	v26, v6, v0
	bit.16b	v21, v2, v1
	add	x2, x2, #32
	add	x24, x24, #1024
	cmp	x2, #512
	b.ne	LBB0_73
; %bb.74:                               ; %direct.false1958
                                        ;   in Loop: Header=BB0_72 Depth=3
	add	x2, x21, x6, lsl #5
	ldp	q3, q4, [x2]
	bit.16b	v4, v25, v0
	bit.16b	v3, v5, v1
	stp	q3, q4, [x2]
	add	x3, x21, x3, lsl #5
	ldp	q3, q4, [x3]
	bit.16b	v4, v14, v0
	bit.16b	v3, v24, v1
	stp	q3, q4, [x3]
	add	x3, x21, x5, lsl #5
	ldp	q3, q4, [x3]
	bit.16b	v4, v15, v0
	bit.16b	v3, v9, v1
	stp	q3, q4, [x3]
	ldp	q3, q4, [x2, #96]
	bit.16b	v4, v6, v0
	bif.16b	v2, v3, v1
	stp	q2, q4, [x2, #96]
	add	x10, x10, #1
	add	x1, x1, #128
	cmp	x10, #8
	b.ne	LBB0_72
; %bb.75:                               ; %direct.false1913
                                        ;   in Loop: Header=BB0_71 Depth=2
	add	x23, x23, #1
	add	x8, x8, #512
	cmp	x23, #4
	b.ne	LBB0_71
; %bb.76:                               ; %direct.schedule.100.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x8, #0                          ; =0x0
	sshll.2d	v2, v1, #0
	sshll.2d	v5, v0, #0
	ldr	q3, [sp, #8384]                 ; 16-byte Reload
	ldr	q4, [sp, #14304]                ; 16-byte Reload
	ldr	q6, [sp, #8480]                 ; 16-byte Reload
	bit.16b	v3, v6, v4
	str	q3, [sp, #8384]                 ; 16-byte Spill
	ldr	q3, [sp, #8464]                 ; 16-byte Reload
	ldr	q4, [sp, #14320]                ; 16-byte Reload
	bit.16b	v13, v3, v4
	ldr	q3, [sp, #8400]                 ; 16-byte Reload
	ldr	q4, [sp, #8448]                 ; 16-byte Reload
	bit.16b	v3, v4, v5
	str	q3, [sp, #8400]                 ; 16-byte Spill
	ldr	q3, [sp, #8496]                 ; 16-byte Reload
	bit.16b	v10, v3, v2
	ldr	q6, [sp, #13936]                ; 16-byte Reload
LBB0_77:                                ; %direct.true2027
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d2, x8
	orr.16b	v3, v2, v10
	fmov	x10, d3
	add	x10, x21, x10
	ldp	q3, q4, [x10]
	orr.16b	v2, v2, v6
	fmov	x10, d2
	add	x10, x22, x10
	ldp	q2, q5, [x10]
	bif.16b	v4, v5, v0
	bit.16b	v2, v3, v1
	stp	q2, q4, [x10]
	add	x8, x8, #32
	cmp	x8, #1, lsl #12                 ; =4096
	b.ne	LBB0_77
; %bb.78:                               ; %direct.true2043.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q13, [sp, #8416]                ; 16-byte Spill
	str	q10, [sp, #8432]                ; 16-byte Spill
	str	q20, [sp, #5632]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldp	x1, x2, [sp, #432]              ; 16-byte Folded Reload
	ldr	x11, [sp, #7752]                ; 8-byte Reload
	ldr	q14, [sp, #10880]               ; 16-byte Reload
LBB0_79:                                ; %direct.true2043
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x22, x8
	ldp	q2, q3, [x10]
	add	x10, x7, x8
	ldp	q4, q5, [x10]
	bif.16b	v3, v5, v0
	bif.16b	v2, v4, v1
	stp	q2, q3, [x10]
	add	x8, x8, #32
	cmp	x8, #1, lsl #12                 ; =4096
	b.ne	LBB0_79
; %bb.80:                               ; %direct.false2044
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q2, [sp, #10912]                ; 16-byte Reload
	ldr	q3, [sp, #14016]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #10912]                ; 16-byte Spill
	ldr	q2, [sp, #10928]                ; 16-byte Reload
	ldr	q3, [sp, #14032]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #10928]                ; 16-byte Spill
	ldr	q2, [sp, #10944]                ; 16-byte Reload
	ldr	q3, [sp, #14000]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #10944]                ; 16-byte Spill
	ldr	q2, [sp, #10960]                ; 16-byte Reload
	ldr	q3, [sp, #14080]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #10960]                ; 16-byte Spill
	ldr	q2, [sp, #10976]                ; 16-byte Reload
	ldr	q3, [sp, #14048]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #10976]                ; 16-byte Spill
	ldr	q2, [sp, #11008]                ; 16-byte Reload
	ldr	q3, [sp, #14064]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #11008]                ; 16-byte Spill
	ldr	q2, [sp, #10992]                ; 16-byte Reload
	ldr	q3, [sp, #13968]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #10992]                ; 16-byte Spill
	ldr	q2, [sp, #13824]                ; 16-byte Reload
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #13824]                ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	ldr	q2, [sp, #9344]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q3, [sp, #9312]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #9376]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q5, [sp, #9024]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	fadd.4s	v3, v3, v12
	ldr	q5, [sp, #9296]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9264]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9280]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9248]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9232]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9200]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9216]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9184]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9168]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9136]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9152]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9120]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9104]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #8992]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9008]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #8976]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #8960]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #8928]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #8944]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #8912]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #8896]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #8864]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #8880]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #8848]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #8832]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	fadd.4s	v2, v2, v17
	ldr	q5, [sp, #8816]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #13808]                ; 16-byte Reload
	bit.16b	v5, v3, v1
	str	q5, [sp, #13808]                ; 16-byte Spill
	ldr	q3, [sp, #13792]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #13792]                ; 16-byte Spill
	ldr	q2, [sp, #9872]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q3, [sp, #9360]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #9888]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q5, [sp, #9840]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9824]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9808]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9760]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9792]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9328]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9744]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9680]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9728]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9696]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9664]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9648]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9088]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9632]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9616]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9584]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9600]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9568]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9552]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9520]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9536]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9504]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9488]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9456]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9472]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9440]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9424]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9392]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9408]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #13776]                ; 16-byte Reload
	bit.16b	v5, v3, v1
	str	q5, [sp, #13776]                ; 16-byte Spill
	ldr	q15, [sp, #8368]                ; 16-byte Reload
	bit.16b	v15, v2, v0
	ldr	q2, [sp, #10368]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q3, [sp, #10336]                ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #10304]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q5, [sp, #10160]                ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #10320]                ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #10288]                ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #10256]                ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #10272]                ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9904]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #10240]                ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #10208]                ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #10224]                ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #10192]                ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #10176]                ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #10144]                ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #10080]                ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #10128]                ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9952]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #10096]                ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #10112]                ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #10064]                ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #10048]                ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #10032]                ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9776]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #10016]                ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #10000]                ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9968]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9984]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9856]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q5, [sp, #9936]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9712]                 ; 16-byte Reload
	fadd.4s	v2, v2, v5
	ldr	q5, [sp, #9920]                 ; 16-byte Reload
	fadd.4s	v3, v3, v5
	ldr	q24, [sp, #8352]                ; 16-byte Reload
	bit.16b	v24, v3, v1
	ldr	q17, [sp, #8336]                ; 16-byte Reload
	bit.16b	v17, v2, v0
	ldr	q2, [sp, #10800]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q3, [sp, #10768]                ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #10816]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10784]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10752]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10736]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #9072]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #10720]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10592]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10704]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #9056]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #10688]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10672]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10656]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #10624]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #10640]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10608]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10560]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #10544]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #10576]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10528]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #9040]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #10512]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #10352]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10496]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10480]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #10448]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #10464]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10432]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #10416]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #10384]                ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #10400]                ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q23, [sp, #8320]                ; 16-byte Reload
	bit.16b	v23, v3, v1
	ldr	q16, [sp, #8304]                ; 16-byte Reload
	bit.16b	v16, v2, v0
	ldr	q2, [sp, #7920]                 ; 16-byte Reload
	ldr	q3, [sp, #14160]                ; 16-byte Reload
	fmul.4s	v3, v2, v3
	str	q3, [sp, #14160]                ; 16-byte Spill
	ldr	q3, [sp, #7904]                 ; 16-byte Reload
	ldr	q4, [sp, #14144]                ; 16-byte Reload
	fmul.4s	v20, v3, v4
	ldr	q13, [sp, #7952]                ; 16-byte Reload
	ldr	q4, [sp, #14128]                ; 16-byte Reload
	fmul.4s	v22, v13, v4
	ldr	q9, [sp, #7936]                 ; 16-byte Reload
	ldr	q4, [sp, #14112]                ; 16-byte Reload
	fmul.4s	v18, v9, v4
	ldr	q6, [sp, #7840]                 ; 16-byte Reload
	ldr	q4, [sp, #14096]                ; 16-byte Reload
	fmul.4s	v25, v6, v4
	ldr	q12, [sp, #7968]                ; 16-byte Reload
	ldr	q4, [sp, #13952]                ; 16-byte Reload
	fmul.4s	v7, v12, v4
	ldr	q4, [sp, #7872]                 ; 16-byte Reload
	ldr	q5, [sp, #10848]                ; 16-byte Reload
	fmul.4s	v10, v4, v5
	ldr	q5, [sp, #7856]                 ; 16-byte Reload
	ldr	q19, [sp, #10832]               ; 16-byte Reload
	fmul.4s	v19, v5, v19
	str	q16, [sp, #8304]                ; 16-byte Spill
	fadd.4s	v16, v20, v16
	str	q23, [sp, #8320]                ; 16-byte Spill
	ldr	q20, [sp, #14160]               ; 16-byte Reload
	fadd.4s	v23, v20, v23
	str	q17, [sp, #8336]                ; 16-byte Spill
	fadd.4s	v17, v18, v17
	str	q24, [sp, #8352]                ; 16-byte Spill
	fadd.4s	v24, v22, v24
	str	q15, [sp, #8368]                ; 16-byte Spill
	fadd.4s	v22, v7, v15
	ldr	q7, [sp, #13776]                ; 16-byte Reload
	fadd.4s	v25, v25, v7
	ldr	q7, [sp, #13792]                ; 16-byte Reload
	fadd.4s	v7, v19, v7
	ldr	q18, [sp, #13808]               ; 16-byte Reload
	fadd.4s	v20, v10, v18
	add	x11, x11, #1
	bit.16b	v2, v23, v1
	str	q2, [sp, #7920]                 ; 16-byte Spill
	bit.16b	v3, v16, v0
	str	q3, [sp, #7904]                 ; 16-byte Spill
	bit.16b	v13, v24, v1
	str	q13, [sp, #7952]                ; 16-byte Spill
	bit.16b	v9, v17, v0
	str	q9, [sp, #7936]                 ; 16-byte Spill
	bit.16b	v6, v25, v1
	str	q6, [sp, #7840]                 ; 16-byte Spill
	bit.16b	v12, v22, v0
	str	q12, [sp, #7968]                ; 16-byte Spill
	bit.16b	v4, v20, v1
	str	q4, [sp, #7872]                 ; 16-byte Spill
	bit.16b	v5, v7, v0
	str	q5, [sp, #7856]                 ; 16-byte Spill
	cmp	x11, #5
	ldr	q18, [sp, #13904]               ; 16-byte Reload
	ldr	q6, [sp, #13888]                ; 16-byte Reload
	ldr	q13, [sp, #13872]               ; 16-byte Reload
	ldr	q5, [sp, #13856]                ; 16-byte Reload
	ldr	q12, [sp, #13840]               ; 16-byte Reload
	ldr	q9, [sp, #7488]                 ; 16-byte Reload
	ldr	q10, [sp, #7472]                ; 16-byte Reload
	ldr	q4, [sp, #10864]                ; 16-byte Reload
	ldr	q19, [sp, #7456]                ; 16-byte Reload
	b.ne	LBB0_22
; %bb.81:                               ; %direct.false344
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	str	q23, [sp, #14352]
	str	q16, [sp, #14368]
	str	q24, [sp, #14384]
	str	q17, [sp, #14400]
	str	q25, [sp, #14416]
	str	q22, [sp, #14432]
	add	x10, sp, #14, lsl #12           ; =57344
	add	x10, x10, #2320
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #2064
	str	q20, [sp, #14448]
	str	q7, [sp, #14464]
	ldr	x16, [sp, #104]                 ; 8-byte Reload
	ldp	q17, q16, [sp, #64]             ; 32-byte Folded Reload
	ldp	q19, q18, [sp, #32]             ; 32-byte Folded Reload
	ldr	q20, [sp, #16]                  ; 16-byte Reload
	b	LBB0_83
LBB0_82:                                ; %else444
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x9, x9, #1
	add	x8, x8, #4
	cmp	x8, #512
	b.eq	LBB0_99
LBB0_83:                                ; %direct.true2080
                                        ; =>This Inner Loop Header: Depth=1
	lsr	x12, x9, #5
	dup.2d	v2, x12
	fmov	w12, s20
	add.2d	v3, v2, v19
	add	x13, x10, x9, lsl #5
	ldr	q4, [x13]
	and.16b	v4, v1, v4
	and	x14, x9, #0x60
	add	x14, x11, x14
	ldr	q5, [x14]
	and.16b	v5, v1, v5
	fdiv.4s	v5, v4, v5
	shl.2d	v4, v3, #7
	and	x15, x8, #0x7c
	dup.2d	v3, x15
	orr.16b	v6, v4, v3
	dup.2d	v4, x16
	add.2d	v6, v4, v6
	tbz	w12, #0, LBB0_87
; %bb.84:                               ; %cond.store
                                        ;   in Loop: Header=BB0_83 Depth=1
	fmov	x15, d6
	str	s5, [x15]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_88
LBB0_85:                                ; %else426
                                        ;   in Loop: Header=BB0_83 Depth=1
	add.2d	v6, v2, v17
	shl.2d	v6, v6, #7
	orr.16b	v6, v6, v3
	add.2d	v6, v4, v6
	tbz	w12, #2, LBB0_89
LBB0_86:                                ; %cond.store427
                                        ;   in Loop: Header=BB0_83 Depth=1
	fmov	x15, d6
	st1.s	{ v5 }[2], [x15]
	tbnz	w12, #3, LBB0_90
	b	LBB0_91
LBB0_87:                                ; %else423
                                        ;   in Loop: Header=BB0_83 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_85
LBB0_88:                                ; %cond.store424
                                        ;   in Loop: Header=BB0_83 Depth=1
	mov.d	x15, v6[1]
	st1.s	{ v5 }[1], [x15]
	add.2d	v6, v2, v17
	shl.2d	v6, v6, #7
	orr.16b	v6, v6, v3
	add.2d	v6, v4, v6
	tbnz	w12, #2, LBB0_86
LBB0_89:                                ; %else429
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbz	w12, #3, LBB0_91
LBB0_90:                                ; %cond.store430
                                        ;   in Loop: Header=BB0_83 Depth=1
	mov.d	x15, v6[1]
	st1.s	{ v5 }[3], [x15]
LBB0_91:                                ; %else432
                                        ;   in Loop: Header=BB0_83 Depth=1
	add.2d	v6, v2, v18
	ldr	q5, [x13, #16]
	and.16b	v5, v0, v5
	ldr	q7, [x14, #16]
	and.16b	v7, v0, v7
	fdiv.4s	v5, v5, v7
	shl.2d	v6, v6, #7
	orr.16b	v6, v6, v3
	add.2d	v6, v4, v6
	tbz	w12, #4, LBB0_95
; %bb.92:                               ; %cond.store433
                                        ;   in Loop: Header=BB0_83 Depth=1
	fmov	x13, d6
	str	s5, [x13]
	tbnz	w12, #5, LBB0_96
LBB0_93:                                ; %else438
                                        ;   in Loop: Header=BB0_83 Depth=1
	add.2d	v2, v2, v16
	shl.2d	v2, v2, #7
	orr.16b	v2, v2, v3
	add.2d	v2, v4, v2
	tbz	w12, #6, LBB0_97
LBB0_94:                                ; %cond.store439
                                        ;   in Loop: Header=BB0_83 Depth=1
	fmov	x13, d2
	st1.s	{ v5 }[2], [x13]
	tbz	w12, #7, LBB0_82
	b	LBB0_98
LBB0_95:                                ; %else435
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbz	w12, #5, LBB0_93
LBB0_96:                                ; %cond.store436
                                        ;   in Loop: Header=BB0_83 Depth=1
	mov.d	x13, v6[1]
	st1.s	{ v5 }[1], [x13]
	add.2d	v2, v2, v16
	shl.2d	v2, v2, #7
	orr.16b	v2, v2, v3
	add.2d	v2, v4, v2
	tbnz	w12, #6, LBB0_94
LBB0_97:                                ; %else441
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbz	w12, #7, LBB0_82
LBB0_98:                                ; %cond.store442
                                        ;   in Loop: Header=BB0_83 Depth=1
	mov.d	x12, v2[1]
	st1.s	{ v5 }[3], [x12]
	b	LBB0_82
LBB0_99:
	add	sp, sp, #16, lsl #12            ; =65536
	add	sp, sp, #2320
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_100:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

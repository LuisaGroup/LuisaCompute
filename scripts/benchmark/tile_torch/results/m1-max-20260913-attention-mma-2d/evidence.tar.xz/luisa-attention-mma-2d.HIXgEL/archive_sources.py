"""Freeze actual isolated source and selected build/tool provenance, not a loader attestation."""
import hashlib
import io
import json
from pathlib import Path
import platform
import subprocess
import tarfile
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/mike/CLionProjects/luisa')
SOURCE = Path('/tmp/luisa-next-integration.roZbN8/source')
BUILD = SOURCE.parent / 'build'
OWNED = (
    'include/luisa/tile/bridge/xir/lower.h',
    'include/luisa/tile/bridge/xir/planner.h',
    'src/backends/metal4/tile/metal_tile.cpp',
    'src/backends/simd/runtime/simd_tile.cpp',
    'src/tests/benchmark/benchmark_tile_xir.cpp',
    'src/tests/unit/tile/bridge/test_xir_runtime.cpp',
    'src/tests/unit/tile/bridge/test_xir_target_info.cpp',
    'src/tile/bridge/xir/lower.cpp',
    'src/tile/bridge/xir/planner.cpp',
    'src/tile/bridge/xir/representation.h',
)


def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def command(argv, cwd=None):
    return subprocess.check_output(argv, cwd=cwd, text=True, timeout=30).strip()


def equality():
    result = {}
    for relative in OWNED:
        main, isolated = sha(ROOT / relative), sha(SOURCE / relative)
        if main != isolated:
            raise RuntimeError('main/isolated owned source mismatch: ' + relative)
        result[relative] = dict(main_sha256=main, isolated_sha256=isolated, equal=True)
    return result


dst, manifest = OUT / 'sources.tar.gz', OUT / 'provenance.json'
if dst.exists() or manifest.exists():
    raise RuntimeError('snapshot already exists; do not overwrite frozen evidence')
owned_equal = equality()
main_head = command(['git', 'rev-parse', 'HEAD'], ROOT)
cost_commit = command(['git', 'rev-parse', 'cdd6d51cc'], ROOT)
paths = ['include/luisa/tile', 'src/tile', 'include/luisa/xir', 'src/xir', 'src/backends/simd',
         'src/tests/common', 'src/tests/benchmark/benchmark_tile_xir.cpp',
         'src/tests/unit/tile/bridge/test_xir_target_info.cpp', 'src/tests/unit/tile/bridge/test_xir_runtime.cpp',
         'src/tests/unit/simd/test_llvm_schedule_codegen.cpp', 'src/backends/metal4/tile/metal_tile.cpp']
host_paths = ['scripts/benchmark/tile_torch/native_tile.py', 'scripts/benchmark/tile_torch/native_tile_replay.cpp',
              'scripts/benchmark/tile_torch/compare_llm.py', 'scripts/benchmark/tile_torch/test_compare_llm.py',
              'scripts/benchmark/tile_torch/run.py']
files = {}
for root, entries in ((SOURCE, paths), (ROOT, host_paths)):
    for relative in entries:
        path = root / relative
        for file in (sorted(path.rglob('*')) if path.is_dir() else [path]):
            if file.is_file():
                if file.is_symlink():
                    raise RuntimeError('unexpected source symlink: ' + str(file))
                name = str(file.relative_to(root))
                if name in files:
                    raise RuntimeError('duplicate source archive member: ' + name)
                files[name] = file
build_files = [BUILD / 'CMakeCache.txt', BUILD / 'build.ninja', BUILD / 'compile_commands.json']
build_files += sorted((BUILD / 'CMakeFiles').glob('*/CMake*Compiler.cmake'))
build_files += sorted((BUILD / 'CMakeFiles').glob('*/CMakeSystem.cmake'))
for file in build_files:
    if file.is_file():
        files['_build/' + str(file.relative_to(BUILD))] = file
for name in ('run.py', 'archive_sources.py'):
    files['_experiment/' + name] = OUT / name
hashes = {name: sha(path) for name, path in files.items()}
patch = command(['git', 'diff', '--binary', 'HEAD', '--', *OWNED], ROOT).encode()
patch_name = '_provenance/owned-changes-from-main-head.patch'
hashes[patch_name] = hashlib.sha256(patch).hexdigest()
with tarfile.open(dst, 'w:gz', compresslevel=6) as archive:
    for name, file in sorted(files.items()):
        archive.add(file, arcname=name, recursive=False)
    info = tarfile.TarInfo(patch_name)
    info.size = len(patch)
    info.mtime = int(time.time())
    archive.addfile(info, io.BytesIO(patch))
if hashes != {**{name: sha(path) for name, path in files.items()}, patch_name: hashlib.sha256(patch).hexdigest()}:
    raise RuntimeError('source or build configuration changed during snapshot')
if equality() != owned_equal or command(['git', 'rev-parse', 'HEAD'], ROOT) != main_head:
    raise RuntimeError('main/isolated source identity changed during snapshot')
binary_paths = [BUILD / 'bin/benchmark_tile_xir', BUILD / 'bin/benchmark_tile_native',
                *sorted((BUILD / 'bin').glob('*.dylib')), *sorted((BUILD / 'bin').glob('*.so'))]
binaries = {path.name: sha(path) for path in binary_paths}
tool_paths = [Path('/usr/bin/c++'), Path('/usr/bin/cc'), Path('/usr/bin/ld'),
              Path('/opt/homebrew/bin/cmake'), Path('/opt/homebrew/bin/ninja'),
              Path('/opt/homebrew/opt/llvm/bin/clang++'), Path('/opt/homebrew/opt/llvm/bin/llvm-nm'),
              Path('/opt/homebrew/opt/llvm/bin/llvm-config')]
tools = {str(path): dict(resolved_path=str(path.resolve()), sha256=sha(path.resolve()))
         for path in tool_paths if path.is_file()}
tools['/opt/homebrew/opt/llvm/bin/clang++']['version'] = command(['/opt/homebrew/opt/llvm/bin/clang++', '--version'])
tools['/usr/bin/c++']['version'] = command(['/usr/bin/c++', '--version'])
tools['/opt/homebrew/opt/llvm/bin/llvm-config']['version'] = command(['/opt/homebrew/opt/llvm/bin/llvm-config', '--version'])
metadata = dict(
    checkpoint='2026-09-13 opt-in two-dimensional MMA grouping, fixed requested R4',
    frozen_unix=time.time(), platform=platform.platform(), main_head=main_head,
    origin_next=command(['git', 'rev-parse', 'origin/next'], ROOT),
    included_cost_fix_commit=cost_commit,
    cost_fix_codegen_paths=['include/luisa/tile/bridge/xir/planner.h',
                           'src/tile/bridge/xir/planner.cpp',
                           'src/tests/unit/tile/bridge/test_xir_target_info.cpp'],
    source_state='Actual isolated compiler source; selected ten owned code/test files equal the main working-tree bytes. Main HEAD includes the cdd MMA cost fixes and the archived owned patch records the uncommitted 2D candidate. Other isolated source is archived as observed, not asserted equal to all of main HEAD. Default 2D option remains false; fixed R4 off/on is a diagnostic, not a calibrated policy.',
    main_isolate_equality=owned_equal,
    source_sha256=hashes, source_archive_sha256=sha(dst), binary_sha256=binaries,
    build_configuration_sha256=sha(BUILD / 'CMakeCache.txt'),
    build_files_sha256={name: hashes[name] for name in hashes if name.startswith('_build/')},
    tool_fingerprints=tools,
    source_snapshot_not_loader_attestation=True,
    preflight='Full build retry1 and target_info passed per main-thread gate; remaining CTests were running at source freeze. This snapshot does not assert completion of the full test gate. No capture/replay or GPU is run by this archiver; execution logs will be retained separately after completion.',
    exclusions=[
        'Protected main-worktree TIRx WIP is excluded: compiler source is read from the isolated SOURCE, not copied from main src/tile.',
        'Selected backend/compiler/runtime binaries and tools are fingerprinted, not archived as a complete dynamic-loader closure.',
        'Build cache, ninja commands and compiler configuration snapshots are archived as configuration evidence, not a bit-reproducible build proof.',
        'Actual future captured ORC objects, linked helpers, complete inputs/oracles/outputs and timing receipts must be retained separately.',
        'No GPU health or performance result is implied. No test/capture success is inferred from source snapshot completion.',
    ])
manifest.write_text(json.dumps(metadata, indent=2, allow_nan=False) + '\n')
print(json.dumps(dict(source_archive=str(dst), source_members=len(hashes), bytes=dst.stat().st_size,
                      sha256=sha(dst), provenance=str(manifest), provenance_sha256=sha(manifest),
                      owned_main_isolate_equal=len(owned_equal), tool_fingerprints=len(tools)), indent=2))

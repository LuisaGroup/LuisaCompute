"""Frozen 1x4 versus opt-in 2x2 MMA grouping pilot: actual SIMD ORC objects.

Do not run capture/replay until the main thread has completed its build/test
gate and paused other heavy work. This file does not build the producer.
Preparation links captured objects; it never recompiles their LLVM source.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent
BUILD = Path('/tmp/luisa-next-integration.roZbN8/build')
RUNNER = ROOT / 'scripts/benchmark/tile_torch/native_tile.py'
PRODUCER = BUILD / 'bin/benchmark_tile_xir'
LLVM = Path('/opt/homebrew/opt/llvm/bin')
CASES = [
    ('prefill-q4-u0', (1, 4, 2, 32, 65, 32, 32), (4, 16), 0),
    ('prefill-q4-u8', (1, 4, 2, 32, 65, 32, 32), (4, 16), 8),
    ('heldout-q8-u0', (1, 4, 2, 64, 129, 32, 48), (8, 16), 0),
    ('heldout-batch-gqa-q4-u8', (2, 6, 2, 17, 67, 40, 48), (4, 16), 8),
    ('heldout-gqa-q8-u8', (1, 6, 2, 33, 131, 48, 40), (8, 16), 8),
    ('decode-m1-u8-control', (1, 8, 2, 1, 2053, 80, 96), (1, 16), 8),
]
VARIANTS = (('off', False), ('on', True))
ATOL = RTOL = 5e-5
FIXED_RESOURCES = (
    'static_snapshot_bytes_per_worker', 'static_snapshot_allocations',
    'snapshot_budget', 'private_workspace_bytes', 'local_lanes',
    'max_unrolled_tile_elements', 'max_unrolled_region_work',
    'unordered_reduction_partitions',
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def load(path):
    return json.loads(path.read_text())


def controls():
    return dict(
        cases=[dict(case=name, dimensions=list(dims), block=list(block), cap=cap)
               for name, dims, block, cap in CASES],
        variants=[dict(name=name, enable_mma_2d_blocking=enabled) for name, enabled in VARIANTS],
        requested_mma_output_block=4, full_packet_specialization=True,
        packet_width=8, workers_per_block=32, local_lanes=1,
        max_unrolled_tile_elements=64, max_unrolled_region_work=4096,
        require_ab_root_order_equal=True, require_ab_blocks_per_task_equal=True,
        attention_qk='mma', attention_pv='mma', precision='fp32', fast_math=False,
        native_cycles=3, native_samples=7, native_warmup_ms=30, native_target_ms=15,
        capture_samples=3, capture_sample_ms=1, capture_warmup_ms=1,
        process_timeout_s=60,
        metric='single_thread_native_entry_host_wall_us',
        independent_oracle='NumPy dense FP64 GQA, bottom-right causal, FP32 scale',
        require_ab_bitwise_output=True,
        decode_control_requires_identical_source_and_object=True,
        admission='Actual two_dimensional_mmas is recorded, not forced to 2 for an enabled request.',
    )


def freeze_plan(create):
    identities = {str(path): sha(path) for path in (
        Path(__file__).resolve(), RUNNER, PRODUCER,
        RUNNER.parent / 'native_tile_replay.cpp',
        ROOT / 'src/backends/simd/llvm/llvm_schedule_codegen.h',
    )}
    expected = dict(controls=controls(), frozen_sha256=identities,
                    python=str(Path(sys.executable).resolve()), llvm=str(LLVM))
    path = OUT / 'plan.json'
    if create:
        require(not path.exists(), 'plan already exists: use a new experiment directory, never overwrite')
        save(path, dict(**expected, frozen_unix=time.time(),
                       identity_boundary='Producer fingerprint and helper sources only; not a loader-closure attestation.'))
    else:
        plan = load(path)
        for key, value in expected.items():
            require(plan.get(key) == value, 'frozen experiment identity/config changed: ' + key)
    return sha(path)


def run(command, folder, stem, env=None):
    record = dict(command=command, started=time.time(),
                  environment={k: v for k, v in (env or {}).items() if k.startswith('LUISA_')},
                  timeout_s=60, process_group_isolated=True)
    save(folder / (stem + '.command.json'), record)
    process = None
    try:
        process = subprocess.Popen(command, env=env, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=True)
        try:
            stdout, stderr = process.communicate(timeout=60)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = process.communicate()
            record['error'] = 'timeout; entire isolated process group terminated'
        (folder / (stem + '.stdout')).write_bytes(stdout)
        (folder / (stem + '.stderr')).write_bytes(stderr)
        record.update(returncode=process.returncode, finished=time.time())
        save(folder / (stem + '.command.json'), record)
        require('error' not in record, record.get('error', ''))
        require(process.returncode == 0, f'{stem}: exit {process.returncode}; raw stdout/stderr retained')
        require(not stderr, f'{stem}: nonempty stderr; inspect retained raw diagnostics before acceptance')
        return stdout
    except Exception as error:
        record.update(error=str(error), finished=time.time())
        if process is not None:
            record['returncode'] = process.returncode
        save(folder / (stem + '.command.json'), record)
        raise


def field(realization, name, boolean=False):
    pattern = '(true|false)' if boolean else '(\\d+)'
    found = re.findall(r'\b' + re.escape(name) + '=' + pattern + r'\b', realization)
    require(len(found) == 1, 'missing/duplicate realization acknowledgement: ' + name)
    return found[0] == 'true' if boolean else int(found[0])


def execution_controls(metadata, prepared=None):
    text = metadata['realization']
    packet = re.findall(r'\bW(\d+), (\d+) workers/block\b', text)
    require(packet == [('8', '32')], 'expected exactly one W8/block32 realization')
    expected = dict(local_lanes=1, max_unrolled_tile_elements=64, max_unrolled_region_work=4096)
    for name, value in expected.items():
        require(field(text, name) == value, 'execution control mismatch: ' + name)
    orders = re.findall(r'\broot order \[([0-9]+(?:\s*,\s*[0-9]+)*)\]', text)
    require(len(orders) == 1, 'missing/duplicate root traversal order')
    order = [int(value.strip()) for value in orders[0].split(',')]
    require(sorted(order) == list(range(len(order))), 'root traversal is not a permutation')
    if prepared is not None:
        require(prepared['packet_width'] == 8, 'prepared packet width drift')
        require(prepared['block'] == [32, 1, 1], 'prepared block shape drift')
        require(prepared['metadata'] == metadata, 'prepared metadata differs from capture')
    return dict(**expected, packet_width=8, workers_per_block=32,
                root_order=order, blocks_per_task=field(text, 'blocks_per_task'))


def capture_one(name, dims, block, cap, variant, enabled):
    label = f'{name}-{variant}'
    folder = OUT / label
    folder.mkdir()
    prefix = folder / 'output.f32'
    env = {k: v for k, v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_'))}
    env.update(LUISA_TILE_BENCH_XIR_BACKEND='simd', LUISA_TILE_BENCH_ATTENTION_QK='mma',
               LUISA_TILE_BENCH_ATTENTION_PV='mma', LUISA_TILE_BENCH_XIR_MMA_OUTPUT_BLOCK='4',
               LUISA_TILE_BENCH_XIR_MMA_UNROLL_TERMS=str(cap),
               LUISA_TILE_BENCH_XIR_MMA_2D_BLOCKING='1' if enabled else '0',
               LUISA_TILE_BENCH_XIR_BLOCK_SIZE='32', LUISA_TILE_BENCH_XIR_LOCAL_LANES='1',
               LUISA_TILE_BENCH_XIR_REGION_WORK='4096',
               LUISA_TILE_BENCH_DUMP_SOURCE=str(prefix) + '.source.txt',
               LUISA_SIMD_DUMP_ASSEMBLY_DIR=str(folder / 'objects'),
               LUISA_SIMD_ENABLE_FULL_PACKET_SPECIALIZATION='1')
    metadata = json.loads(run([str(PRODUCER), 'llm', 'attention', ','.join(map(str, dims)),
                               *map(str, block), '3', '1', '1', str(prefix)], folder, 'capture', env))
    require(metadata['attention_qk'] == metadata['attention_pv'] == 'mma', 'decomposition drift')
    require(metadata.get('fast_math') is False and metadata.get('precision') == 'fp32', 'math drift')
    execution_controls(metadata)
    text = metadata['realization']
    require(field(text, 'requested_mma_output_block') == 4, 'R4 not acknowledged')
    require(field(text, 'requested_max_unrolled_mma_terms') == cap, 'fixed cap not acknowledged')
    require(field(text, 'requested_mma_2d_blocking', boolean=True) is enabled, '2D switch not acknowledged')
    count = field(text, 'two_dimensional_mmas')
    if not enabled or block[0] == 1:
        require(count == 0, 'disabled/decode control unexpectedly realized 2D MMA')
    run([sys.executable, str(RUNNER), 'prepare', '--capture-kind', 'llm', '--llvm', str(LLVM),
         '--prefix', str(prefix), '--log', str(folder / 'capture.stdout'),
         '--objects', str(folder / 'objects'), '--output', str(OUT / ('prepared-' + label)),
         '--name', variant], folder, 'prepare')
    prepared_manifest = load(OUT / f'prepared-{label}/prepared.json')
    execution = execution_controls(metadata, prepared_manifest)
    print(label, metadata['realization'], flush=True)
    return dict(label=label, two_dimensional_mmas=count,
                execution_controls=execution,
                prepared_manifest_sha256=sha(OUT / f'prepared-{label}/prepared.json'))


def pair_oracle(name, dims, block):
    # Imported only during admitted capture/replay phases; no Torch or GPU path.
    import numpy as np

    prepared = [OUT / f'prepared-{name}-{variant}' for variant, _ in VARIANTS]
    manifests = [load(path / 'prepared.json') for path in prepared]
    execution = [execution_controls(manifest['metadata'], manifest) for manifest in manifests]
    require(execution[0] == execution[1], 'A/B execution/root traversal/blocks-per-task drift')
    for directory, manifest in zip(prepared, manifests):
        require(manifest.get('status') == 'prepared', 'incomplete preparation')
        for relative, expected in manifest['files'].items():
            path = Path(relative)
            require(not path.is_absolute() and '..' not in path.parts, 'unsafe prepared artifact path')
            require(sha(directory / path) == expected, 'prepared artifact hash drift: ' + relative)
    for key in ('dimensions', 'attention_block', 'attention_qk', 'attention_pv', 'precision',
                'fast_math', 'relaxed_precision', 'source_reduction_policy', 'dispatch',
                'input_shapes', 'output_shape'):
        require(manifests[0]['metadata'][key] == manifests[1]['metadata'][key], 'A/B math/config drift: ' + key)
    require(manifests[0]['metadata']['dimensions'] == list(dims), 'declared shape mismatch')
    require(manifests[0]['metadata']['attention_block'] == list(block), 'declared block mismatch')
    for key in ('abi', 'symbol', 'packet_width', 'block', 'dispatch', 'workspace_bytes', 'tool_sha256'):
        require(manifests[0][key] == manifests[1][key], 'A/B launch/resource/tool drift: ' + key)
    for key in FIXED_RESOURCES:
        require(field(manifests[0]['metadata']['realization'], key) ==
                field(manifests[1]['metadata']['realization'], key), 'A/B capacity drift: ' + key)
    common = ('input0.f32', 'input1.f32', 'input2.f32', 'expected.f64', 'native_tile.py',
              'native_tile_replay.cpp', 'backends/simd/llvm/llvm_schedule_codegen.h')
    for relative in common:
        require(manifests[0]['files'][relative] == manifests[1]['files'][relative], 'A/B input/helper drift: ' + relative)
    if block[0] == 1:
        for relative in ('kernel.ll', 'kernel.o'):
            require(manifests[0]['files'][relative] == manifests[1]['files'][relative],
                    'decode control changed executable code: ' + relative)
    b, h, kh, q, keys, d, dv = dims
    shapes = ((b, h, q, d), (b, kh, keys, d), (b, kh, keys, dv))

    def array(path, shape, dtype):
        require(path.stat().st_size == math.prod(shape) * np.dtype(dtype).itemsize, 'tensor extent mismatch')
        values = np.fromfile(path, dtype=dtype).reshape(shape)
        require(np.isfinite(values).all(), 'nonfinite tensor')
        return values

    inputs = [array(prepared[0] / f'input{i}.f32', shape, '<f4').astype(np.float64)
              for i, shape in enumerate(shapes)]
    query, key, value = inputs
    key, value = np.repeat(key, h // kh, axis=1), np.repeat(value, h // kh, axis=1)
    scale = float(np.float32(1) / np.sqrt(np.float32(d)))
    score = (query @ np.swapaxes(key, -1, -2)) * scale
    causal = np.arange(keys)[None, :] <= np.arange(q)[:, None] + keys - q
    score = np.where(causal, score, -1e30)
    weight = np.where(causal, np.exp(score - score.max(axis=-1, keepdims=True)), 0)
    expected = (weight / weight.sum(axis=-1, keepdims=True)) @ value
    reference = array(prepared[0] / 'expected.f64', expected.shape, '<f8')
    require(np.allclose(reference, expected, atol=1e-12, rtol=1e-12), 'independent FP64 oracle mismatch')
    checks = []
    for directory, manifest in zip(prepared, manifests):
        output = array(directory / 'captured.f32', expected.shape, '<f4').astype(np.float64)
        error = np.abs(output - expected)
        require(np.all(error <= ATOL + RTOL * np.abs(expected)), 'complete captured output mismatch')
        checks.append(float(error.max()))
    require(manifests[0]['files']['captured.f32'] == manifests[1]['files']['captured.f32'],
            'strict A/B captured output is not bitwise identical')
    return dict(independent_fp64=True, elements=math.prod(expected.shape), atol=ATOL, rtol=RTOL,
                capture_max_abs_error=checks, ab_bitwise_equal=True,
                execution_controls=execution[0],
                captured_output_sha256=manifests[0]['files']['captured.f32'],
                decode_code_identical=block[0] == 1)


def capture():
    plan_sha = freeze_plan(create=True)
    record = dict(started=time.time(), plan_sha256=plan_sha,
                  cases=[dict(case=name, status='NotRun') for name, *_ in CASES])
    save(OUT / 'captures.json', record)
    try:
        for row, (name, dims, block, cap) in zip(record['cases'], CASES):
            row.update(status='Capturing', variants=[])
            save(OUT / 'captures.json', record)
            for variant, enabled in VARIANTS:
                row['variants'].append(capture_one(name, dims, block, cap, variant, enabled))
                save(OUT / 'captures.json', record)
            row.update(status='OK', correctness=pair_oracle(name, dims, block))
            save(OUT / 'captures.json', record)
        require(freeze_plan(create=False) == plan_sha, 'plan changed during capture')
        record.update(status='complete', finished=time.time())
    except Exception as error:
        row.update(status='Error', error=str(error))
        record.update(status='error', error=str(error), finished=time.time())
        raise
    finally:
        save(OUT / 'captures.json', record)


def replay():
    plan_sha = freeze_plan(create=False)
    captured = load(OUT / 'captures.json')
    require(captured.get('status') == 'complete', 'capture matrix incomplete; no partial timing acceptance')
    require(captured['plan_sha256'] == plan_sha, 'capture plan differs')
    record = dict(started=time.time(), load_before=os.getloadavg(), experiments=[],
                  plan_sha256=plan_sha, runner_sha256=sha(__file__),
                  declared_cases=[dict(case=name, dimensions=list(dims), block=list(block), cap=cap)
                                  for name, dims, block, cap in CASES])
    save(OUT / 'replays.json', record)
    try:
        for name, dims, block, cap in CASES:
            check = pair_oracle(name, dims, block)
            run([sys.executable, str(RUNNER), 'replay', '--prepared', str(OUT / f'prepared-{name}-off/prepared.json'),
                 '--prepared', str(OUT / f'prepared-{name}-on/prepared.json'), '--output', str(OUT / ('replay-' + name)),
                 '--cycles', '3', '--samples', '7', '--warmup-ms', '30', '--target-ms', '15'], OUT, 'replay-' + name)
            result = load(OUT / f'replay-{name}/results.json')
            require(result.get('status') == 'passed' and len(result['visits']) == 12, 'incomplete ABBA cohort')
            for visit in result['visits']:
                require(visit.get('valid') is True and len(visit['samples_us']) == 7, 'invalid ABBA visit')
                path = OUT / f'replay-{name}' / visit['output']
                require(sha(path) == visit['output_sha256'] == check['captured_output_sha256'],
                        'replay output differs from bitwise-equal FP64-checked capture')
            record['experiments'].append(dict(case=name, dimensions=list(dims), block=list(block), cap=cap,
                                              packet=True, correctness=check))
            save(OUT / 'replays.json', record)
            print(name, 'replayed', flush=True)
        require(freeze_plan(create=False) == plan_sha, 'plan changed during replay')
        record.update(status='complete', finished=time.time(), load_after=os.getloadavg())
    except Exception as error:
        record.update(status='error', error=str(error), finished=time.time(), load_after=os.getloadavg())
        raise
    finally:
        save(OUT / 'replays.json', record)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('capture', 'replay'))
    args = parser.parse_args()
    (capture if args.phase == 'capture' else replay)()

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill31, align 64
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca i64, align 8
  store i64 0, ptr %.slot33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %tile_snapshot.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill42, align 64
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %.spill44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill44, align 64
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca i64, align 8
  store i64 0, ptr %.slot51, align 4
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot54, align 32
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot60, align 32
  %.slot61 = alloca i64, align 8
  store i64 0, ptr %.slot61, align 4
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.spill66 = alloca i64, align 8
  store i64 0, ptr %.spill66, align 4
  %.spill67 = alloca i1, align 1
  store i1 false, ptr %.spill67, align 1
  %.spill68 = alloca i1, align 1
  store i1 false, ptr %.spill68, align 1
  %.spill69 = alloca i1, align 1
  store i1 false, ptr %.spill69, align 1
  %.spill70 = alloca i1, align 1
  store i1 false, ptr %.spill70, align 1
  %.spill71 = alloca i1, align 1
  store i1 false, ptr %.spill71, align 1
  %.spill72 = alloca i1, align 1
  store i1 false, ptr %.spill72, align 1
  %.spill73 = alloca i1, align 1
  store i1 false, ptr %.spill73, align 1
  %.spill74 = alloca i1, align 1
  store i1 false, ptr %.spill74, align 1
  %.spill75 = alloca i1, align 1
  store i1 false, ptr %.spill75, align 1
  %.spill76 = alloca i1, align 1
  store i1 false, ptr %.spill76, align 1
  %.spill77 = alloca i1, align 1
  store i1 false, ptr %.spill77, align 1
  %.spill78 = alloca i1, align 1
  store i1 false, ptr %.spill78, align 1
  %.spill79 = alloca i1, align 1
  store i1 false, ptr %.spill79, align 1
  %.spill80 = alloca i1, align 1
  store i1 false, ptr %.spill80, align 1
  %.spill81 = alloca i1, align 1
  store i1 false, ptr %.spill81, align 1
  %.spill82 = alloca i1, align 1
  store i1 false, ptr %.spill82, align 1
  %.spill83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill83, align 32
  %.spill84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill84, align 32
  %.spill85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill85, align 32
  %.spill86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill86, align 32
  %.spill87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill87, align 32
  %.spill88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill88, align 32
  %.spill89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill89, align 32
  %.spill90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill90, align 32
  %.spill91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill91, align 32
  %.spill92 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill92, align 32
  %.spill93 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill93, align 32
  %.spill94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill94, align 32
  %.spill95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %tile_snapshot.spill99 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill99, align 64
  %.slot100 = alloca i64, align 8
  store i64 0, ptr %.slot100, align 4
  %.slot101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill103, align 32
  %tile_snapshot.spill104 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill104, align 64
  %.spill105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.slot106 = alloca i64, align 8
  store i64 0, ptr %.slot106, align 4
  %.slot107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill108, align 32
  %tile_snapshot.spill109 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill109, align 64
  %.slot110 = alloca i64, align 8
  store i64 0, ptr %.slot110, align 4
  %.spill111 = alloca i64, align 8
  store i64 0, ptr %.spill111, align 4
  %.spill112 = alloca i64, align 8
  store i64 0, ptr %.spill112, align 4
  %.spill113 = alloca i64, align 8
  store i64 0, ptr %.spill113, align 4
  %.spill114 = alloca i64, align 8
  store i64 0, ptr %.spill114, align 4
  %.slot115 = alloca i64, align 8
  store i64 0, ptr %.slot115, align 4
  %.slot116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot116, align 32
  %.slot117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot117, align 32
  %.slot118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot118, align 32
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.slot120 = alloca i64, align 8
  store i64 0, ptr %.slot120, align 4
  %.slot121 = alloca i64, align 8
  store i64 0, ptr %.slot121, align 4
  %.slot122 = alloca i64, align 8
  store i64 0, ptr %.slot122, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert123 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat124 = shufflevector <8 x i32> %.splatinsert123, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat124, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert125 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat126 = shufflevector <8 x i32> %.splatinsert125, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat126, %61
  %64 = mul i32 %52, 1
  %.splatinsert127 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat128 = shufflevector <8 x i32> %.splatinsert127, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat128, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert129 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat130 = shufflevector <8 x i32> %.splatinsert129, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat130, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert131 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat132 = shufflevector <8 x i32> %.splatinsert131, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat132
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  store i64 0, ptr %.spill29, align 4
  %80 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = load <8 x i64>, ptr %.spill30, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill30, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %94 = icmp slt i64 %.state, 80
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load i64, ptr %.spill29, align 4
  %95 = add i64 %.spill.load, 0
  %.spill.load133 = load <8 x i64>, ptr %.spill, align 64
  %96 = add <8 x i64> %.spill.load133, zeroinitializer
  %97 = mul i64 %95, 8
  %.splatinsert134 = insertelement <8 x i64> poison, i64 %97, i64 0
  %.splat135 = shufflevector <8 x i64> %.splatinsert134, <8 x i64> poison, <8 x i32> zeroinitializer
  %98 = add <8 x i64> %.splat135, %96
  %.spill.load136 = load i64, ptr %.spill29, align 4
  %99 = add i64 %.spill.load136, 0
  %100 = mul <8 x i64> %98, splat (i64 1)
  %.splatinsert137 = insertelement <8 x i64> poison, i64 %99, i64 0
  %.splat138 = shufflevector <8 x i64> %.splatinsert137, <8 x i64> poison, <8 x i32> zeroinitializer
  %101 = add <8 x i64> %100, %.splat138
  %.state139 = load i64, ptr %.slot, align 4
  %102 = add i64 0, %.state139
  %103 = mul <8 x i64> %101, splat (i64 80)
  %.splatinsert140 = insertelement <8 x i64> poison, i64 %102, i64 0
  %.splat141 = shufflevector <8 x i64> %.splatinsert140, <8 x i64> poison, <8 x i32> zeroinitializer
  %104 = add <8 x i64> %103, %.splat141
  %105 = extractvalue { ptr, i64 } %29, 0
  %106 = mul <8 x i64> %104, splat (i64 4)
  %107 = getelementptr i8, ptr %105, <8 x i64> %106
  %108 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %107, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state142 = load i64, ptr %.slot, align 4
  %.splatinsert143 = insertelement <8 x i64> poison, i64 %.state142, i64 0
  %.splat144 = shufflevector <8 x i64> %.splatinsert143, <8 x i64> poison, <8 x i32> zeroinitializer
  %111 = mul <8 x i64> %.splat144, splat (i64 32)
  %112 = add <8 x i64> %110, %111
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %109, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %114, 1
  %117 = extractelement <8 x ptr> %115, i32 0
  %118 = extractelement <8 x i64> %116, i32 0
  %119 = sub i64 %118, 0
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %121 = select i1 %120, i64 %119, i64 0
  %private.contiguous.address = getelementptr i8, ptr %117, i64 %121
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %122 = select <8 x i1> %71, <8 x float> %108, <8 x float> %private.contiguous.preserve
  store <8 x float> %122, ptr %private.contiguous.address, align 4
  %.state145 = load i64, ptr %.slot, align 4
  %123 = add i64 %.state145, 1
  store i64 %123, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %71, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %71, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill31, align 64
  %133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 0
  %136 = select <8 x i1> %71, <8 x ptr> %134, <8 x ptr> %135
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %139 = select <8 x i1> %71, <8 x i64> %137, <8 x i64> %138
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  store { <8 x ptr>, <8 x i64> } %141, ptr %tile_snapshot.spill32, align 64
  store i64 0, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state146 = load i64, ptr %.slot33, align 4
  %142 = icmp slt i64 %.state146, 96
  br i1 %142, label %direct.true147, label %direct.false148

direct.schedule.5:                                ; preds = %direct.true147
  %tile_snapshot.spill.load149 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 1
  %.state150 = load i64, ptr %.slot33, align 4
  %.splatinsert151 = insertelement <8 x i64> poison, i64 %.state150, i64 0
  %.splat152 = shufflevector <8 x i64> %.splatinsert151, <8 x i64> poison, <8 x i32> zeroinitializer
  %145 = mul <8 x i64> %.splat152, splat (i64 32)
  %146 = add <8 x i64> %144, %145
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %143, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %148, 1
  %151 = extractelement <8 x ptr> %149, i32 0
  %152 = extractelement <8 x i64> %150, i32 0
  %153 = sub i64 %152, 0
  %154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %155 = select i1 %154, i64 %153, i64 0
  %private.contiguous.address153 = getelementptr i8, ptr %151, i64 %155
  %private.contiguous.preserve154 = load <8 x float>, ptr %private.contiguous.address153, align 4
  %156 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve154
  store <8 x float> %156, ptr %private.contiguous.address153, align 4
  %.state155 = load i64, ptr %.slot33, align 4
  %157 = add i64 %.state155, 1
  store i64 %157, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false148
  store i64 0, ptr %.slot34, align 4
  %158 = load <8 x float>, ptr %.slot35, align 32
  %159 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %158
  store <8 x float> %159, ptr %.slot35, align 32
  %160 = load <8 x float>, ptr %.slot36, align 32
  %161 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %160
  store <8 x float> %161, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.48, %direct.schedule.6
  %.state156 = load i64, ptr %.slot34, align 4
  %162 = icmp slt i64 %.state156, 129
  br i1 %162, label %direct.true157, label %direct.false158

direct.schedule.8:                                ; preds = %direct.true157
  %.state159 = load i64, ptr %.slot34, align 4
  %163 = sdiv i64 %.state159, 1
  %164 = mul i64 %163, 16
  store i64 %164, ptr %.spill37, align 4
  %165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %168 = select <8 x i1> %71, <8 x ptr> %166, <8 x ptr> %167
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %171 = select <8 x i1> %71, <8 x i64> %169, <8 x i64> %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  store { <8 x ptr>, <8 x i64> } %173, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state160 = load i64, ptr %.slot39, align 4
  %174 = icmp slt i64 %.state160, 1280
  br i1 %174, label %direct.true161, label %direct.false162

direct.schedule.10:                               ; preds = %direct.true161
  %.state163 = load i64, ptr %.slot39, align 4
  %175 = srem i64 %.state163, 80
  %.state164 = load i64, ptr %.slot39, align 4
  %176 = sdiv i64 %.state164, 80
  %.spill.load165 = load i64, ptr %.spill29, align 4
  %177 = add i64 %.spill.load165, 0
  %.spill.load166 = load <8 x i64>, ptr %.spill30, align 64
  %178 = add <8 x i64> %.spill.load166, zeroinitializer
  %179 = mul i64 %177, 2
  %.splatinsert167 = insertelement <8 x i64> poison, i64 %179, i64 0
  %.splat168 = shufflevector <8 x i64> %.splatinsert167, <8 x i64> poison, <8 x i32> zeroinitializer
  %180 = add <8 x i64> %.splat168, %178
  %.spill.load169 = load i64, ptr %.spill37, align 4
  %181 = add i64 %.spill.load169, %176
  %182 = mul <8 x i64> %180, splat (i64 2053)
  %.splatinsert170 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat171 = shufflevector <8 x i64> %.splatinsert170, <8 x i64> poison, <8 x i32> zeroinitializer
  %183 = add <8 x i64> %182, %.splat171
  %184 = icmp sge i64 %181, 0
  %185 = and i1 true, %184
  %186 = icmp slt i64 %181, 2053
  %187 = and i1 %185, %186
  %188 = add i64 0, %175
  %189 = mul <8 x i64> %183, splat (i64 80)
  %.splatinsert172 = insertelement <8 x i64> poison, i64 %188, i64 0
  %.splat173 = shufflevector <8 x i64> %.splatinsert172, <8 x i64> poison, <8 x i32> zeroinitializer
  %190 = add <8 x i64> %189, %.splat173
  %191 = load <8 x i64>, ptr %.spill40, align 64
  %192 = select <8 x i1> %71, <8 x i64> %190, <8 x i64> %191
  store <8 x i64> %192, ptr %.spill40, align 64
  br i1 %187, label %direct.true174, label %direct.false175

direct.schedule.11:                               ; preds = %direct.true174
  %.spill.load176 = load <8 x i64>, ptr %.spill40, align 64
  %193 = extractvalue { ptr, i64 } %35, 0
  %194 = mul <8 x i64> %.spill.load176, splat (i64 4)
  %195 = getelementptr i8, ptr %193, <8 x i64> %194
  %196 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %195, <8 x i1> %71, <8 x float> zeroinitializer)
  %197 = load <8 x float>, ptr %.slot41, align 32
  %198 = select <8 x i1> %71, <8 x float> %196, <8 x float> %197
  store <8 x float> %198, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.11, %direct.false175
  %tile_snapshot.spill.load177 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load177, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load177, 1
  %.state178 = load i64, ptr %.slot39, align 4
  %.splatinsert179 = insertelement <8 x i64> poison, i64 %.state178, i64 0
  %.splat180 = shufflevector <8 x i64> %.splatinsert179, <8 x i64> poison, <8 x i32> zeroinitializer
  %201 = mul <8 x i64> %.splat180, splat (i64 32)
  %202 = add <8 x i64> %200, %201
  %203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %199, 0
  %204 = insertvalue { <8 x ptr>, <8 x i64> } %203, <8 x i64> %202, 1
  %.state181 = load <8 x float>, ptr %.slot41, align 32
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %204, 1
  %207 = extractelement <8 x ptr> %205, i32 0
  %208 = extractelement <8 x i64> %206, i32 0
  %209 = sub i64 %208, 0
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %211 = select i1 %210, i64 %209, i64 0
  %private.contiguous.address182 = getelementptr i8, ptr %207, i64 %211
  %private.contiguous.preserve183 = load <8 x float>, ptr %private.contiguous.address182, align 4
  %212 = select <8 x i1> %71, <8 x float> %.state181, <8 x float> %private.contiguous.preserve183
  store <8 x float> %212, ptr %private.contiguous.address182, align 4
  %.state184 = load i64, ptr %.slot39, align 4
  %213 = add i64 %.state184, 1
  store i64 %213, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false162
  %214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %214, 0
  %217 = select <8 x i1> %71, <8 x ptr> %215, <8 x ptr> %216
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %214, 1
  %220 = select <8 x i1> %71, <8 x i64> %218, <8 x i64> %219
  %221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %222 = insertvalue { <8 x ptr>, <8 x i64> } %221, <8 x i64> %220, 1
  store { <8 x ptr>, <8 x i64> } %222, ptr %tile_snapshot.spill42, align 64
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state185 = load i64, ptr %.slot43, align 4
  %223 = icmp slt i64 %.state185, 1536
  br i1 %223, label %direct.true186, label %direct.false187

direct.schedule.15:                               ; preds = %direct.true186
  %.state188 = load i64, ptr %.slot43, align 4
  %224 = srem i64 %.state188, 96
  %.state189 = load i64, ptr %.slot43, align 4
  %225 = sdiv i64 %.state189, 96
  %.spill.load190 = load i64, ptr %.spill29, align 4
  %226 = add i64 %.spill.load190, 0
  %.spill.load191 = load <8 x i64>, ptr %.spill30, align 64
  %227 = add <8 x i64> %.spill.load191, zeroinitializer
  %228 = mul i64 %226, 2
  %.splatinsert192 = insertelement <8 x i64> poison, i64 %228, i64 0
  %.splat193 = shufflevector <8 x i64> %.splatinsert192, <8 x i64> poison, <8 x i32> zeroinitializer
  %229 = add <8 x i64> %.splat193, %227
  %.spill.load194 = load i64, ptr %.spill37, align 4
  %230 = add i64 %.spill.load194, %225
  %231 = mul <8 x i64> %229, splat (i64 2053)
  %.splatinsert195 = insertelement <8 x i64> poison, i64 %230, i64 0
  %.splat196 = shufflevector <8 x i64> %.splatinsert195, <8 x i64> poison, <8 x i32> zeroinitializer
  %232 = add <8 x i64> %231, %.splat196
  %233 = icmp sge i64 %230, 0
  %234 = and i1 true, %233
  %235 = icmp slt i64 %230, 2053
  %236 = and i1 %234, %235
  %237 = add i64 0, %224
  %238 = mul <8 x i64> %232, splat (i64 96)
  %.splatinsert197 = insertelement <8 x i64> poison, i64 %237, i64 0
  %.splat198 = shufflevector <8 x i64> %.splatinsert197, <8 x i64> poison, <8 x i32> zeroinitializer
  %239 = add <8 x i64> %238, %.splat198
  %240 = load <8 x i64>, ptr %.spill44, align 64
  %241 = select <8 x i1> %71, <8 x i64> %239, <8 x i64> %240
  store <8 x i64> %241, ptr %.spill44, align 64
  br i1 %236, label %direct.true199, label %direct.false200

direct.schedule.16:                               ; preds = %direct.true199
  %.spill.load201 = load <8 x i64>, ptr %.spill44, align 64
  %242 = extractvalue { ptr, i64 } %41, 0
  %243 = mul <8 x i64> %.spill.load201, splat (i64 4)
  %244 = getelementptr i8, ptr %242, <8 x i64> %243
  %245 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %244, <8 x i1> %71, <8 x float> zeroinitializer)
  %246 = load <8 x float>, ptr %.slot45, align 32
  %247 = select <8 x i1> %71, <8 x float> %245, <8 x float> %246
  store <8 x float> %247, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.16, %direct.false200
  %tile_snapshot.spill.load202 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load202, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load202, 1
  %.state203 = load i64, ptr %.slot43, align 4
  %.splatinsert204 = insertelement <8 x i64> poison, i64 %.state203, i64 0
  %.splat205 = shufflevector <8 x i64> %.splatinsert204, <8 x i64> poison, <8 x i32> zeroinitializer
  %250 = mul <8 x i64> %.splat205, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %.state206 = load <8 x float>, ptr %.slot45, align 32
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address207 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.preserve208 = load <8 x float>, ptr %private.contiguous.address207, align 4
  %261 = select <8 x i1> %71, <8 x float> %.state206, <8 x float> %private.contiguous.preserve208
  store <8 x float> %261, ptr %private.contiguous.address207, align 4
  %.state209 = load i64, ptr %.slot43, align 4
  %262 = add i64 %.state209, 1
  store i64 %262, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false187
  store i64 0, ptr %.slot46, align 4
  %263 = load <8 x float>, ptr %.slot47, align 32
  %264 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %263
  store <8 x float> %264, ptr %.slot47, align 32
  %265 = load <8 x float>, ptr %.slot48, align 32
  %266 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %265
  store <8 x float> %266, ptr %.slot48, align 32
  %267 = load <8 x float>, ptr %.slot49, align 32
  %268 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %267
  store <8 x float> %268, ptr %.slot49, align 32
  %269 = load <8 x float>, ptr %.slot50, align 32
  %270 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %269
  store <8 x float> %270, ptr %.slot50, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state210 = load i64, ptr %.slot46, align 4
  %271 = icmp slt i64 %.state210, 80
  br i1 %271, label %direct.true211, label %direct.false212

direct.schedule.20:                               ; preds = %direct.true211
  %.state213 = load i64, ptr %.slot46, align 4
  %272 = add i64 0, %.state213
  %tile_snapshot.spill.load214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 1
  %.splatinsert215 = insertelement <8 x i64> poison, i64 %272, i64 0
  %.splat216 = shufflevector <8 x i64> %.splatinsert215, <8 x i64> poison, <8 x i32> zeroinitializer
  %275 = mul <8 x i64> %.splat216, splat (i64 32)
  %276 = add <8 x i64> %274, %275
  %277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %273, 0
  %278 = insertvalue { <8 x ptr>, <8 x i64> } %277, <8 x i64> %276, 1
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %278, 1
  %281 = extractelement <8 x ptr> %279, i32 0
  %282 = extractelement <8 x i64> %280, i32 0
  %283 = sub i64 %282, 0
  %284 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %285 = select i1 %284, i64 %283, i64 0
  %private.contiguous.address217 = getelementptr i8, ptr %281, i64 %285
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address217, align 4
  %286 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 1
  %.splatinsert219 = insertelement <8 x i64> poison, i64 %272, i64 0
  %.splat220 = shufflevector <8 x i64> %.splatinsert219, <8 x i64> poison, <8 x i32> zeroinitializer
  %289 = mul <8 x i64> %.splat220, splat (i64 32)
  %290 = add <8 x i64> %288, %289
  %291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %287, 0
  %292 = insertvalue { <8 x ptr>, <8 x i64> } %291, <8 x i64> %290, 1
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %292, 1
  %295 = extractelement <8 x ptr> %293, i32 0
  %296 = extractelement <8 x i64> %294, i32 0
  %297 = sub i64 %296, 0
  %298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %299 = select i1 %298, i64 %297, i64 0
  %private.contiguous.address221 = getelementptr i8, ptr %295, i64 %299
  %private.contiguous.load222 = load <8 x float>, ptr %private.contiguous.address221, align 4
  %300 = select <8 x i1> %71, <8 x float> %private.contiguous.load222, <8 x float> zeroinitializer
  %301 = fmul <8 x float> %286, %300
  %.state223 = load <8 x float>, ptr %.slot47, align 32
  %302 = fadd <8 x float> %.state223, %301
  %.state224 = load i64, ptr %.slot46, align 4
  %303 = add i64 80, %.state224
  %tile_snapshot.spill.load225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 1
  %.splatinsert226 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat227 = shufflevector <8 x i64> %.splatinsert226, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat227, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address228 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load229 = load <8 x float>, ptr %private.contiguous.address228, align 4
  %317 = select <8 x i1> %71, <8 x float> %private.contiguous.load229, <8 x float> zeroinitializer
  %318 = fmul <8 x float> %286, %317
  %.state230 = load <8 x float>, ptr %.slot48, align 32
  %319 = fadd <8 x float> %.state230, %318
  %.state231 = load i64, ptr %.slot46, align 4
  %320 = add i64 160, %.state231
  %tile_snapshot.spill.load232 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 1
  %.splatinsert233 = insertelement <8 x i64> poison, i64 %320, i64 0
  %.splat234 = shufflevector <8 x i64> %.splatinsert233, <8 x i64> poison, <8 x i32> zeroinitializer
  %323 = mul <8 x i64> %.splat234, splat (i64 32)
  %324 = add <8 x i64> %322, %323
  %325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %321, 0
  %326 = insertvalue { <8 x ptr>, <8 x i64> } %325, <8 x i64> %324, 1
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %326, 1
  %329 = extractelement <8 x ptr> %327, i32 0
  %330 = extractelement <8 x i64> %328, i32 0
  %331 = sub i64 %330, 0
  %332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %333 = select i1 %332, i64 %331, i64 0
  %private.contiguous.address235 = getelementptr i8, ptr %329, i64 %333
  %private.contiguous.load236 = load <8 x float>, ptr %private.contiguous.address235, align 4
  %334 = select <8 x i1> %71, <8 x float> %private.contiguous.load236, <8 x float> zeroinitializer
  %335 = fmul <8 x float> %286, %334
  %.state237 = load <8 x float>, ptr %.slot49, align 32
  %336 = fadd <8 x float> %.state237, %335
  %.state238 = load i64, ptr %.slot46, align 4
  %337 = add i64 240, %.state238
  %tile_snapshot.spill.load239 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 1
  %.splatinsert240 = insertelement <8 x i64> poison, i64 %337, i64 0
  %.splat241 = shufflevector <8 x i64> %.splatinsert240, <8 x i64> poison, <8 x i32> zeroinitializer
  %340 = mul <8 x i64> %.splat241, splat (i64 32)
  %341 = add <8 x i64> %339, %340
  %342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %338, 0
  %343 = insertvalue { <8 x ptr>, <8 x i64> } %342, <8 x i64> %341, 1
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %343, 1
  %346 = extractelement <8 x ptr> %344, i32 0
  %347 = extractelement <8 x i64> %345, i32 0
  %348 = sub i64 %347, 0
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %350 = select i1 %349, i64 %348, i64 0
  %private.contiguous.address242 = getelementptr i8, ptr %346, i64 %350
  %private.contiguous.load243 = load <8 x float>, ptr %private.contiguous.address242, align 4
  %351 = select <8 x i1> %71, <8 x float> %private.contiguous.load243, <8 x float> zeroinitializer
  %352 = fmul <8 x float> %286, %351
  %.state244 = load <8 x float>, ptr %.slot50, align 32
  %353 = fadd <8 x float> %.state244, %352
  %.state245 = load i64, ptr %.slot46, align 4
  %354 = add i64 %.state245, 1
  store i64 %354, ptr %.slot46, align 4
  %355 = load <8 x float>, ptr %.slot47, align 32
  %356 = select <8 x i1> %71, <8 x float> %302, <8 x float> %355
  store <8 x float> %356, ptr %.slot47, align 32
  %357 = load <8 x float>, ptr %.slot48, align 32
  %358 = select <8 x i1> %71, <8 x float> %319, <8 x float> %357
  store <8 x float> %358, ptr %.slot48, align 32
  %359 = load <8 x float>, ptr %.slot49, align 32
  %360 = select <8 x i1> %71, <8 x float> %336, <8 x float> %359
  store <8 x float> %360, ptr %.slot49, align 32
  %361 = load <8 x float>, ptr %.slot50, align 32
  %362 = select <8 x i1> %71, <8 x float> %353, <8 x float> %361
  store <8 x float> %362, ptr %.slot50, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false212
  store i64 0, ptr %.slot51, align 4
  %363 = load <8 x float>, ptr %.slot52, align 32
  %364 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %363
  store <8 x float> %364, ptr %.slot52, align 32
  %365 = load <8 x float>, ptr %.slot53, align 32
  %366 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %365
  store <8 x float> %366, ptr %.slot53, align 32
  %367 = load <8 x float>, ptr %.slot54, align 32
  %368 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %367
  store <8 x float> %368, ptr %.slot54, align 32
  %369 = load <8 x float>, ptr %.slot55, align 32
  %370 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %369
  store <8 x float> %370, ptr %.slot55, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state246 = load i64, ptr %.slot51, align 4
  %371 = icmp slt i64 %.state246, 80
  br i1 %371, label %direct.true247, label %direct.false248

direct.schedule.23:                               ; preds = %direct.true247
  %.state249 = load i64, ptr %.slot51, align 4
  %372 = add i64 0, %.state249
  %tile_snapshot.spill.load250 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 1
  %.splatinsert251 = insertelement <8 x i64> poison, i64 %372, i64 0
  %.splat252 = shufflevector <8 x i64> %.splatinsert251, <8 x i64> poison, <8 x i32> zeroinitializer
  %375 = mul <8 x i64> %.splat252, splat (i64 32)
  %376 = add <8 x i64> %374, %375
  %377 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %373, 0
  %378 = insertvalue { <8 x ptr>, <8 x i64> } %377, <8 x i64> %376, 1
  %379 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %378, 1
  %381 = extractelement <8 x ptr> %379, i32 0
  %382 = extractelement <8 x i64> %380, i32 0
  %383 = sub i64 %382, 0
  %384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %385 = select i1 %384, i64 %383, i64 0
  %private.contiguous.address253 = getelementptr i8, ptr %381, i64 %385
  %private.contiguous.load254 = load <8 x float>, ptr %private.contiguous.address253, align 4
  %386 = select <8 x i1> %71, <8 x float> %private.contiguous.load254, <8 x float> zeroinitializer
  %.state255 = load i64, ptr %.slot51, align 4
  %387 = add i64 320, %.state255
  %tile_snapshot.spill.load256 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 0
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 1
  %.splatinsert257 = insertelement <8 x i64> poison, i64 %387, i64 0
  %.splat258 = shufflevector <8 x i64> %.splatinsert257, <8 x i64> poison, <8 x i32> zeroinitializer
  %390 = mul <8 x i64> %.splat258, splat (i64 32)
  %391 = add <8 x i64> %389, %390
  %392 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %388, 0
  %393 = insertvalue { <8 x ptr>, <8 x i64> } %392, <8 x i64> %391, 1
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %393, 1
  %396 = extractelement <8 x ptr> %394, i32 0
  %397 = extractelement <8 x i64> %395, i32 0
  %398 = sub i64 %397, 0
  %399 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %400 = select i1 %399, i64 %398, i64 0
  %private.contiguous.address259 = getelementptr i8, ptr %396, i64 %400
  %private.contiguous.load260 = load <8 x float>, ptr %private.contiguous.address259, align 4
  %401 = select <8 x i1> %71, <8 x float> %private.contiguous.load260, <8 x float> zeroinitializer
  %402 = fmul <8 x float> %386, %401
  %.state261 = load <8 x float>, ptr %.slot52, align 32
  %403 = fadd <8 x float> %.state261, %402
  %.state262 = load i64, ptr %.slot51, align 4
  %404 = add i64 400, %.state262
  %tile_snapshot.spill.load263 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load263, 0
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load263, 1
  %.splatinsert264 = insertelement <8 x i64> poison, i64 %404, i64 0
  %.splat265 = shufflevector <8 x i64> %.splatinsert264, <8 x i64> poison, <8 x i32> zeroinitializer
  %407 = mul <8 x i64> %.splat265, splat (i64 32)
  %408 = add <8 x i64> %406, %407
  %409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %405, 0
  %410 = insertvalue { <8 x ptr>, <8 x i64> } %409, <8 x i64> %408, 1
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %410, 1
  %413 = extractelement <8 x ptr> %411, i32 0
  %414 = extractelement <8 x i64> %412, i32 0
  %415 = sub i64 %414, 0
  %416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %417 = select i1 %416, i64 %415, i64 0
  %private.contiguous.address266 = getelementptr i8, ptr %413, i64 %417
  %private.contiguous.load267 = load <8 x float>, ptr %private.contiguous.address266, align 4
  %418 = select <8 x i1> %71, <8 x float> %private.contiguous.load267, <8 x float> zeroinitializer
  %419 = fmul <8 x float> %386, %418
  %.state268 = load <8 x float>, ptr %.slot53, align 32
  %420 = fadd <8 x float> %.state268, %419
  %.state269 = load i64, ptr %.slot51, align 4
  %421 = add i64 480, %.state269
  %tile_snapshot.spill.load270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %.splatinsert271 = insertelement <8 x i64> poison, i64 %421, i64 0
  %.splat272 = shufflevector <8 x i64> %.splatinsert271, <8 x i64> poison, <8 x i32> zeroinitializer
  %424 = mul <8 x i64> %.splat272, splat (i64 32)
  %425 = add <8 x i64> %423, %424
  %426 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %422, 0
  %427 = insertvalue { <8 x ptr>, <8 x i64> } %426, <8 x i64> %425, 1
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %429 = extractvalue { <8 x ptr>, <8 x i64> } %427, 1
  %430 = extractelement <8 x ptr> %428, i32 0
  %431 = extractelement <8 x i64> %429, i32 0
  %432 = sub i64 %431, 0
  %433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %434 = select i1 %433, i64 %432, i64 0
  %private.contiguous.address273 = getelementptr i8, ptr %430, i64 %434
  %private.contiguous.load274 = load <8 x float>, ptr %private.contiguous.address273, align 4
  %435 = select <8 x i1> %71, <8 x float> %private.contiguous.load274, <8 x float> zeroinitializer
  %436 = fmul <8 x float> %386, %435
  %.state275 = load <8 x float>, ptr %.slot54, align 32
  %437 = fadd <8 x float> %.state275, %436
  %.state276 = load i64, ptr %.slot51, align 4
  %438 = add i64 560, %.state276
  %tile_snapshot.spill.load277 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 1
  %.splatinsert278 = insertelement <8 x i64> poison, i64 %438, i64 0
  %.splat279 = shufflevector <8 x i64> %.splatinsert278, <8 x i64> poison, <8 x i32> zeroinitializer
  %441 = mul <8 x i64> %.splat279, splat (i64 32)
  %442 = add <8 x i64> %440, %441
  %443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %439, 0
  %444 = insertvalue { <8 x ptr>, <8 x i64> } %443, <8 x i64> %442, 1
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %444, 1
  %447 = extractelement <8 x ptr> %445, i32 0
  %448 = extractelement <8 x i64> %446, i32 0
  %449 = sub i64 %448, 0
  %450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %451 = select i1 %450, i64 %449, i64 0
  %private.contiguous.address280 = getelementptr i8, ptr %447, i64 %451
  %private.contiguous.load281 = load <8 x float>, ptr %private.contiguous.address280, align 4
  %452 = select <8 x i1> %71, <8 x float> %private.contiguous.load281, <8 x float> zeroinitializer
  %453 = fmul <8 x float> %386, %452
  %.state282 = load <8 x float>, ptr %.slot55, align 32
  %454 = fadd <8 x float> %.state282, %453
  %.state283 = load i64, ptr %.slot51, align 4
  %455 = add i64 %.state283, 1
  store i64 %455, ptr %.slot51, align 4
  %456 = load <8 x float>, ptr %.slot52, align 32
  %457 = select <8 x i1> %71, <8 x float> %403, <8 x float> %456
  store <8 x float> %457, ptr %.slot52, align 32
  %458 = load <8 x float>, ptr %.slot53, align 32
  %459 = select <8 x i1> %71, <8 x float> %420, <8 x float> %458
  store <8 x float> %459, ptr %.slot53, align 32
  %460 = load <8 x float>, ptr %.slot54, align 32
  %461 = select <8 x i1> %71, <8 x float> %437, <8 x float> %460
  store <8 x float> %461, ptr %.slot54, align 32
  %462 = load <8 x float>, ptr %.slot55, align 32
  %463 = select <8 x i1> %71, <8 x float> %454, <8 x float> %462
  store <8 x float> %463, ptr %.slot55, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false248
  store i64 0, ptr %.slot56, align 4
  %464 = load <8 x float>, ptr %.slot57, align 32
  %465 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %464
  store <8 x float> %465, ptr %.slot57, align 32
  %466 = load <8 x float>, ptr %.slot58, align 32
  %467 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %466
  store <8 x float> %467, ptr %.slot58, align 32
  %468 = load <8 x float>, ptr %.slot59, align 32
  %469 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %468
  store <8 x float> %469, ptr %.slot59, align 32
  %470 = load <8 x float>, ptr %.slot60, align 32
  %471 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %470
  store <8 x float> %471, ptr %.slot60, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state284 = load i64, ptr %.slot56, align 4
  %472 = icmp slt i64 %.state284, 80
  br i1 %472, label %direct.true285, label %direct.false286

direct.schedule.26:                               ; preds = %direct.true285
  %.state287 = load i64, ptr %.slot56, align 4
  %473 = add i64 0, %.state287
  %tile_snapshot.spill.load288 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 0
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 1
  %.splatinsert289 = insertelement <8 x i64> poison, i64 %473, i64 0
  %.splat290 = shufflevector <8 x i64> %.splatinsert289, <8 x i64> poison, <8 x i32> zeroinitializer
  %476 = mul <8 x i64> %.splat290, splat (i64 32)
  %477 = add <8 x i64> %475, %476
  %478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %474, 0
  %479 = insertvalue { <8 x ptr>, <8 x i64> } %478, <8 x i64> %477, 1
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %479, 1
  %482 = extractelement <8 x ptr> %480, i32 0
  %483 = extractelement <8 x i64> %481, i32 0
  %484 = sub i64 %483, 0
  %485 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %486 = select i1 %485, i64 %484, i64 0
  %private.contiguous.address291 = getelementptr i8, ptr %482, i64 %486
  %private.contiguous.load292 = load <8 x float>, ptr %private.contiguous.address291, align 4
  %487 = select <8 x i1> %71, <8 x float> %private.contiguous.load292, <8 x float> zeroinitializer
  %.state293 = load i64, ptr %.slot56, align 4
  %488 = add i64 640, %.state293
  %tile_snapshot.spill.load294 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load294, 0
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load294, 1
  %.splatinsert295 = insertelement <8 x i64> poison, i64 %488, i64 0
  %.splat296 = shufflevector <8 x i64> %.splatinsert295, <8 x i64> poison, <8 x i32> zeroinitializer
  %491 = mul <8 x i64> %.splat296, splat (i64 32)
  %492 = add <8 x i64> %490, %491
  %493 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %489, 0
  %494 = insertvalue { <8 x ptr>, <8 x i64> } %493, <8 x i64> %492, 1
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %494, 1
  %497 = extractelement <8 x ptr> %495, i32 0
  %498 = extractelement <8 x i64> %496, i32 0
  %499 = sub i64 %498, 0
  %500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %501 = select i1 %500, i64 %499, i64 0
  %private.contiguous.address297 = getelementptr i8, ptr %497, i64 %501
  %private.contiguous.load298 = load <8 x float>, ptr %private.contiguous.address297, align 4
  %502 = select <8 x i1> %71, <8 x float> %private.contiguous.load298, <8 x float> zeroinitializer
  %503 = fmul <8 x float> %487, %502
  %.state299 = load <8 x float>, ptr %.slot57, align 32
  %504 = fadd <8 x float> %.state299, %503
  %.state300 = load i64, ptr %.slot56, align 4
  %505 = add i64 720, %.state300
  %tile_snapshot.spill.load301 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load301, 0
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load301, 1
  %.splatinsert302 = insertelement <8 x i64> poison, i64 %505, i64 0
  %.splat303 = shufflevector <8 x i64> %.splatinsert302, <8 x i64> poison, <8 x i32> zeroinitializer
  %508 = mul <8 x i64> %.splat303, splat (i64 32)
  %509 = add <8 x i64> %507, %508
  %510 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %506, 0
  %511 = insertvalue { <8 x ptr>, <8 x i64> } %510, <8 x i64> %509, 1
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %511, 1
  %514 = extractelement <8 x ptr> %512, i32 0
  %515 = extractelement <8 x i64> %513, i32 0
  %516 = sub i64 %515, 0
  %517 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %518 = select i1 %517, i64 %516, i64 0
  %private.contiguous.address304 = getelementptr i8, ptr %514, i64 %518
  %private.contiguous.load305 = load <8 x float>, ptr %private.contiguous.address304, align 4
  %519 = select <8 x i1> %71, <8 x float> %private.contiguous.load305, <8 x float> zeroinitializer
  %520 = fmul <8 x float> %487, %519
  %.state306 = load <8 x float>, ptr %.slot58, align 32
  %521 = fadd <8 x float> %.state306, %520
  %.state307 = load i64, ptr %.slot56, align 4
  %522 = add i64 800, %.state307
  %tile_snapshot.spill.load308 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 0
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 1
  %.splatinsert309 = insertelement <8 x i64> poison, i64 %522, i64 0
  %.splat310 = shufflevector <8 x i64> %.splatinsert309, <8 x i64> poison, <8 x i32> zeroinitializer
  %525 = mul <8 x i64> %.splat310, splat (i64 32)
  %526 = add <8 x i64> %524, %525
  %527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %523, 0
  %528 = insertvalue { <8 x ptr>, <8 x i64> } %527, <8 x i64> %526, 1
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %528, 1
  %531 = extractelement <8 x ptr> %529, i32 0
  %532 = extractelement <8 x i64> %530, i32 0
  %533 = sub i64 %532, 0
  %534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %535 = select i1 %534, i64 %533, i64 0
  %private.contiguous.address311 = getelementptr i8, ptr %531, i64 %535
  %private.contiguous.load312 = load <8 x float>, ptr %private.contiguous.address311, align 4
  %536 = select <8 x i1> %71, <8 x float> %private.contiguous.load312, <8 x float> zeroinitializer
  %537 = fmul <8 x float> %487, %536
  %.state313 = load <8 x float>, ptr %.slot59, align 32
  %538 = fadd <8 x float> %.state313, %537
  %.state314 = load i64, ptr %.slot56, align 4
  %539 = add i64 880, %.state314
  %tile_snapshot.spill.load315 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %540 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 0
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 1
  %.splatinsert316 = insertelement <8 x i64> poison, i64 %539, i64 0
  %.splat317 = shufflevector <8 x i64> %.splatinsert316, <8 x i64> poison, <8 x i32> zeroinitializer
  %542 = mul <8 x i64> %.splat317, splat (i64 32)
  %543 = add <8 x i64> %541, %542
  %544 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %540, 0
  %545 = insertvalue { <8 x ptr>, <8 x i64> } %544, <8 x i64> %543, 1
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %545, 1
  %548 = extractelement <8 x ptr> %546, i32 0
  %549 = extractelement <8 x i64> %547, i32 0
  %550 = sub i64 %549, 0
  %551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %552 = select i1 %551, i64 %550, i64 0
  %private.contiguous.address318 = getelementptr i8, ptr %548, i64 %552
  %private.contiguous.load319 = load <8 x float>, ptr %private.contiguous.address318, align 4
  %553 = select <8 x i1> %71, <8 x float> %private.contiguous.load319, <8 x float> zeroinitializer
  %554 = fmul <8 x float> %487, %553
  %.state320 = load <8 x float>, ptr %.slot60, align 32
  %555 = fadd <8 x float> %.state320, %554
  %.state321 = load i64, ptr %.slot56, align 4
  %556 = add i64 %.state321, 1
  store i64 %556, ptr %.slot56, align 4
  %557 = load <8 x float>, ptr %.slot57, align 32
  %558 = select <8 x i1> %71, <8 x float> %504, <8 x float> %557
  store <8 x float> %558, ptr %.slot57, align 32
  %559 = load <8 x float>, ptr %.slot58, align 32
  %560 = select <8 x i1> %71, <8 x float> %521, <8 x float> %559
  store <8 x float> %560, ptr %.slot58, align 32
  %561 = load <8 x float>, ptr %.slot59, align 32
  %562 = select <8 x i1> %71, <8 x float> %538, <8 x float> %561
  store <8 x float> %562, ptr %.slot59, align 32
  %563 = load <8 x float>, ptr %.slot60, align 32
  %564 = select <8 x i1> %71, <8 x float> %555, <8 x float> %563
  store <8 x float> %564, ptr %.slot60, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false286
  store i64 0, ptr %.slot61, align 4
  %565 = load <8 x float>, ptr %.slot62, align 32
  %566 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %565
  store <8 x float> %566, ptr %.slot62, align 32
  %567 = load <8 x float>, ptr %.slot63, align 32
  %568 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %567
  store <8 x float> %568, ptr %.slot63, align 32
  %569 = load <8 x float>, ptr %.slot64, align 32
  %570 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %569
  store <8 x float> %570, ptr %.slot64, align 32
  %571 = load <8 x float>, ptr %.slot65, align 32
  %572 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %571
  store <8 x float> %572, ptr %.slot65, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state322 = load i64, ptr %.slot61, align 4
  %573 = icmp slt i64 %.state322, 80
  br i1 %573, label %direct.true323, label %direct.false324

direct.schedule.29:                               ; preds = %direct.true323
  %.state325 = load i64, ptr %.slot61, align 4
  %574 = add i64 0, %.state325
  %tile_snapshot.spill.load326 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load326, 0
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load326, 1
  %.splatinsert327 = insertelement <8 x i64> poison, i64 %574, i64 0
  %.splat328 = shufflevector <8 x i64> %.splatinsert327, <8 x i64> poison, <8 x i32> zeroinitializer
  %577 = mul <8 x i64> %.splat328, splat (i64 32)
  %578 = add <8 x i64> %576, %577
  %579 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %575, 0
  %580 = insertvalue { <8 x ptr>, <8 x i64> } %579, <8 x i64> %578, 1
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %580, 1
  %583 = extractelement <8 x ptr> %581, i32 0
  %584 = extractelement <8 x i64> %582, i32 0
  %585 = sub i64 %584, 0
  %586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %587 = select i1 %586, i64 %585, i64 0
  %private.contiguous.address329 = getelementptr i8, ptr %583, i64 %587
  %private.contiguous.load330 = load <8 x float>, ptr %private.contiguous.address329, align 4
  %588 = select <8 x i1> %71, <8 x float> %private.contiguous.load330, <8 x float> zeroinitializer
  %.state331 = load i64, ptr %.slot61, align 4
  %589 = add i64 960, %.state331
  %tile_snapshot.spill.load332 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load332, 0
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load332, 1
  %.splatinsert333 = insertelement <8 x i64> poison, i64 %589, i64 0
  %.splat334 = shufflevector <8 x i64> %.splatinsert333, <8 x i64> poison, <8 x i32> zeroinitializer
  %592 = mul <8 x i64> %.splat334, splat (i64 32)
  %593 = add <8 x i64> %591, %592
  %594 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %590, 0
  %595 = insertvalue { <8 x ptr>, <8 x i64> } %594, <8 x i64> %593, 1
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %597 = extractvalue { <8 x ptr>, <8 x i64> } %595, 1
  %598 = extractelement <8 x ptr> %596, i32 0
  %599 = extractelement <8 x i64> %597, i32 0
  %600 = sub i64 %599, 0
  %601 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %602 = select i1 %601, i64 %600, i64 0
  %private.contiguous.address335 = getelementptr i8, ptr %598, i64 %602
  %private.contiguous.load336 = load <8 x float>, ptr %private.contiguous.address335, align 4
  %603 = select <8 x i1> %71, <8 x float> %private.contiguous.load336, <8 x float> zeroinitializer
  %604 = fmul <8 x float> %588, %603
  %.state337 = load <8 x float>, ptr %.slot62, align 32
  %605 = fadd <8 x float> %.state337, %604
  %.state338 = load i64, ptr %.slot61, align 4
  %606 = add i64 1040, %.state338
  %tile_snapshot.spill.load339 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %607 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 0
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 1
  %.splatinsert340 = insertelement <8 x i64> poison, i64 %606, i64 0
  %.splat341 = shufflevector <8 x i64> %.splatinsert340, <8 x i64> poison, <8 x i32> zeroinitializer
  %609 = mul <8 x i64> %.splat341, splat (i64 32)
  %610 = add <8 x i64> %608, %609
  %611 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %607, 0
  %612 = insertvalue { <8 x ptr>, <8 x i64> } %611, <8 x i64> %610, 1
  %613 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %612, 1
  %615 = extractelement <8 x ptr> %613, i32 0
  %616 = extractelement <8 x i64> %614, i32 0
  %617 = sub i64 %616, 0
  %618 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %619 = select i1 %618, i64 %617, i64 0
  %private.contiguous.address342 = getelementptr i8, ptr %615, i64 %619
  %private.contiguous.load343 = load <8 x float>, ptr %private.contiguous.address342, align 4
  %620 = select <8 x i1> %71, <8 x float> %private.contiguous.load343, <8 x float> zeroinitializer
  %621 = fmul <8 x float> %588, %620
  %.state344 = load <8 x float>, ptr %.slot63, align 32
  %622 = fadd <8 x float> %.state344, %621
  %.state345 = load i64, ptr %.slot61, align 4
  %623 = add i64 1120, %.state345
  %tile_snapshot.spill.load346 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load346, 0
  %625 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load346, 1
  %.splatinsert347 = insertelement <8 x i64> poison, i64 %623, i64 0
  %.splat348 = shufflevector <8 x i64> %.splatinsert347, <8 x i64> poison, <8 x i32> zeroinitializer
  %626 = mul <8 x i64> %.splat348, splat (i64 32)
  %627 = add <8 x i64> %625, %626
  %628 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %624, 0
  %629 = insertvalue { <8 x ptr>, <8 x i64> } %628, <8 x i64> %627, 1
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %631 = extractvalue { <8 x ptr>, <8 x i64> } %629, 1
  %632 = extractelement <8 x ptr> %630, i32 0
  %633 = extractelement <8 x i64> %631, i32 0
  %634 = sub i64 %633, 0
  %635 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %636 = select i1 %635, i64 %634, i64 0
  %private.contiguous.address349 = getelementptr i8, ptr %632, i64 %636
  %private.contiguous.load350 = load <8 x float>, ptr %private.contiguous.address349, align 4
  %637 = select <8 x i1> %71, <8 x float> %private.contiguous.load350, <8 x float> zeroinitializer
  %638 = fmul <8 x float> %588, %637
  %.state351 = load <8 x float>, ptr %.slot64, align 32
  %639 = fadd <8 x float> %.state351, %638
  %.state352 = load i64, ptr %.slot61, align 4
  %640 = add i64 1200, %.state352
  %tile_snapshot.spill.load353 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %641 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load353, 0
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load353, 1
  %.splatinsert354 = insertelement <8 x i64> poison, i64 %640, i64 0
  %.splat355 = shufflevector <8 x i64> %.splatinsert354, <8 x i64> poison, <8 x i32> zeroinitializer
  %643 = mul <8 x i64> %.splat355, splat (i64 32)
  %644 = add <8 x i64> %642, %643
  %645 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %641, 0
  %646 = insertvalue { <8 x ptr>, <8 x i64> } %645, <8 x i64> %644, 1
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %646, 1
  %649 = extractelement <8 x ptr> %647, i32 0
  %650 = extractelement <8 x i64> %648, i32 0
  %651 = sub i64 %650, 0
  %652 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %653 = select i1 %652, i64 %651, i64 0
  %private.contiguous.address356 = getelementptr i8, ptr %649, i64 %653
  %private.contiguous.load357 = load <8 x float>, ptr %private.contiguous.address356, align 4
  %654 = select <8 x i1> %71, <8 x float> %private.contiguous.load357, <8 x float> zeroinitializer
  %655 = fmul <8 x float> %588, %654
  %.state358 = load <8 x float>, ptr %.slot65, align 32
  %656 = fadd <8 x float> %.state358, %655
  %.state359 = load i64, ptr %.slot61, align 4
  %657 = add i64 %.state359, 1
  store i64 %657, ptr %.slot61, align 4
  %658 = load <8 x float>, ptr %.slot62, align 32
  %659 = select <8 x i1> %71, <8 x float> %605, <8 x float> %658
  store <8 x float> %659, ptr %.slot62, align 32
  %660 = load <8 x float>, ptr %.slot63, align 32
  %661 = select <8 x i1> %71, <8 x float> %622, <8 x float> %660
  store <8 x float> %661, ptr %.slot63, align 32
  %662 = load <8 x float>, ptr %.slot64, align 32
  %663 = select <8 x i1> %71, <8 x float> %639, <8 x float> %662
  store <8 x float> %663, ptr %.slot64, align 32
  %664 = load <8 x float>, ptr %.slot65, align 32
  %665 = select <8 x i1> %71, <8 x float> %656, <8 x float> %664
  store <8 x float> %665, ptr %.slot65, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false324
  %.state360 = load <8 x float>, ptr %.slot47, align 32
  %666 = fmul <8 x float> %.state360, splat (float 0x3FBC9F25C0000000)
  %.state361 = load <8 x float>, ptr %.slot48, align 32
  %667 = fmul <8 x float> %.state361, splat (float 0x3FBC9F25C0000000)
  %.state362 = load <8 x float>, ptr %.slot49, align 32
  %668 = fmul <8 x float> %.state362, splat (float 0x3FBC9F25C0000000)
  %.state363 = load <8 x float>, ptr %.slot50, align 32
  %669 = fmul <8 x float> %.state363, splat (float 0x3FBC9F25C0000000)
  %.state364 = load <8 x float>, ptr %.slot52, align 32
  %670 = fmul <8 x float> %.state364, splat (float 0x3FBC9F25C0000000)
  %.state365 = load <8 x float>, ptr %.slot53, align 32
  %671 = fmul <8 x float> %.state365, splat (float 0x3FBC9F25C0000000)
  %.state366 = load <8 x float>, ptr %.slot54, align 32
  %672 = fmul <8 x float> %.state366, splat (float 0x3FBC9F25C0000000)
  %.state367 = load <8 x float>, ptr %.slot55, align 32
  %673 = fmul <8 x float> %.state367, splat (float 0x3FBC9F25C0000000)
  %.state368 = load <8 x float>, ptr %.slot57, align 32
  %674 = fmul <8 x float> %.state368, splat (float 0x3FBC9F25C0000000)
  %.state369 = load <8 x float>, ptr %.slot58, align 32
  %675 = fmul <8 x float> %.state369, splat (float 0x3FBC9F25C0000000)
  %.state370 = load <8 x float>, ptr %.slot59, align 32
  %676 = fmul <8 x float> %.state370, splat (float 0x3FBC9F25C0000000)
  %.state371 = load <8 x float>, ptr %.slot60, align 32
  %677 = fmul <8 x float> %.state371, splat (float 0x3FBC9F25C0000000)
  %.state372 = load <8 x float>, ptr %.slot62, align 32
  %678 = fmul <8 x float> %.state372, splat (float 0x3FBC9F25C0000000)
  %.state373 = load <8 x float>, ptr %.slot63, align 32
  %679 = fmul <8 x float> %.state373, splat (float 0x3FBC9F25C0000000)
  %.state374 = load <8 x float>, ptr %.slot64, align 32
  %680 = fmul <8 x float> %.state374, splat (float 0x3FBC9F25C0000000)
  %.state375 = load <8 x float>, ptr %.slot65, align 32
  %681 = fmul <8 x float> %.state375, splat (float 0x3FBC9F25C0000000)
  %.spill.load376 = load i64, ptr %.spill37, align 4
  %682 = add i64 0, %.spill.load376
  %.spill.load377 = load i64, ptr %.spill37, align 4
  %683 = add i64 1, %.spill.load377
  %.spill.load378 = load i64, ptr %.spill37, align 4
  %684 = add i64 2, %.spill.load378
  %.spill.load379 = load i64, ptr %.spill37, align 4
  %685 = add i64 3, %.spill.load379
  %.spill.load380 = load i64, ptr %.spill37, align 4
  %686 = add i64 4, %.spill.load380
  %.spill.load381 = load i64, ptr %.spill37, align 4
  %687 = add i64 5, %.spill.load381
  %.spill.load382 = load i64, ptr %.spill37, align 4
  %688 = add i64 6, %.spill.load382
  %.spill.load383 = load i64, ptr %.spill37, align 4
  %689 = add i64 7, %.spill.load383
  %.spill.load384 = load i64, ptr %.spill37, align 4
  %690 = add i64 8, %.spill.load384
  %.spill.load385 = load i64, ptr %.spill37, align 4
  %691 = add i64 9, %.spill.load385
  %.spill.load386 = load i64, ptr %.spill37, align 4
  %692 = add i64 10, %.spill.load386
  %.spill.load387 = load i64, ptr %.spill37, align 4
  %693 = add i64 11, %.spill.load387
  %.spill.load388 = load i64, ptr %.spill37, align 4
  %694 = add i64 12, %.spill.load388
  %.spill.load389 = load i64, ptr %.spill37, align 4
  %695 = add i64 13, %.spill.load389
  %.spill.load390 = load i64, ptr %.spill37, align 4
  %696 = add i64 14, %.spill.load390
  %.spill.load391 = load i64, ptr %.spill37, align 4
  %697 = add i64 15, %.spill.load391
  %698 = icmp slt i64 %682, 2053
  %699 = icmp slt i64 %683, 2053
  %700 = icmp slt i64 %684, 2053
  %701 = icmp slt i64 %685, 2053
  %702 = icmp slt i64 %686, 2053
  %703 = icmp slt i64 %687, 2053
  %704 = icmp slt i64 %688, 2053
  %705 = icmp slt i64 %689, 2053
  %706 = icmp slt i64 %690, 2053
  %707 = icmp slt i64 %691, 2053
  %708 = icmp slt i64 %692, 2053
  %709 = icmp slt i64 %693, 2053
  %710 = icmp slt i64 %694, 2053
  %711 = icmp slt i64 %695, 2053
  %712 = icmp slt i64 %696, 2053
  %713 = icmp slt i64 %697, 2053
  %.spill.load392 = load i64, ptr %.spill29, align 4
  %714 = add i64 0, %.spill.load392
  store i64 %714, ptr %.spill66, align 4
  %715 = add i64 %714, 2053
  %716 = sub i64 %715, 1
  %717 = icmp sle i64 %682, %716
  %718 = icmp sle i64 %683, %716
  %719 = icmp sle i64 %684, %716
  %720 = icmp sle i64 %685, %716
  %721 = icmp sle i64 %686, %716
  %722 = icmp sle i64 %687, %716
  %723 = icmp sle i64 %688, %716
  %724 = icmp sle i64 %689, %716
  %725 = icmp sle i64 %690, %716
  %726 = icmp sle i64 %691, %716
  %727 = icmp sle i64 %692, %716
  %728 = icmp sle i64 %693, %716
  %729 = icmp sle i64 %694, %716
  %730 = icmp sle i64 %695, %716
  %731 = icmp sle i64 %696, %716
  %732 = icmp sle i64 %697, %716
  %733 = and i1 %698, %717
  store i1 %733, ptr %.spill67, align 1
  %734 = and i1 %699, %718
  store i1 %734, ptr %.spill68, align 1
  %735 = and i1 %700, %719
  store i1 %735, ptr %.spill69, align 1
  %736 = and i1 %701, %720
  store i1 %736, ptr %.spill70, align 1
  %737 = and i1 %702, %721
  store i1 %737, ptr %.spill71, align 1
  %738 = and i1 %703, %722
  store i1 %738, ptr %.spill72, align 1
  %739 = and i1 %704, %723
  store i1 %739, ptr %.spill73, align 1
  %740 = and i1 %705, %724
  store i1 %740, ptr %.spill74, align 1
  %741 = and i1 %706, %725
  store i1 %741, ptr %.spill75, align 1
  %742 = and i1 %707, %726
  store i1 %742, ptr %.spill76, align 1
  %743 = and i1 %708, %727
  store i1 %743, ptr %.spill77, align 1
  %744 = and i1 %709, %728
  store i1 %744, ptr %.spill78, align 1
  %745 = and i1 %710, %729
  store i1 %745, ptr %.spill79, align 1
  %746 = and i1 %711, %730
  store i1 %746, ptr %.spill80, align 1
  %747 = and i1 %712, %731
  store i1 %747, ptr %.spill81, align 1
  %748 = and i1 %713, %732
  store i1 %748, ptr %.spill82, align 1
  %.splatinsert393 = insertelement <8 x i1> poison, i1 %733, i64 0
  %.splat394 = shufflevector <8 x i1> %.splatinsert393, <8 x i1> poison, <8 x i32> zeroinitializer
  %749 = select <8 x i1> %.splat394, <8 x float> %666, <8 x float> splat (float 0xC6293E5940000000)
  %750 = load <8 x float>, ptr %.spill83, align 32
  %751 = select <8 x i1> %71, <8 x float> %749, <8 x float> %750
  store <8 x float> %751, ptr %.spill83, align 32
  %.splatinsert395 = insertelement <8 x i1> poison, i1 %734, i64 0
  %.splat396 = shufflevector <8 x i1> %.splatinsert395, <8 x i1> poison, <8 x i32> zeroinitializer
  %752 = select <8 x i1> %.splat396, <8 x float> %667, <8 x float> splat (float 0xC6293E5940000000)
  %753 = load <8 x float>, ptr %.spill84, align 32
  %754 = select <8 x i1> %71, <8 x float> %752, <8 x float> %753
  store <8 x float> %754, ptr %.spill84, align 32
  %.splatinsert397 = insertelement <8 x i1> poison, i1 %735, i64 0
  %.splat398 = shufflevector <8 x i1> %.splatinsert397, <8 x i1> poison, <8 x i32> zeroinitializer
  %755 = select <8 x i1> %.splat398, <8 x float> %668, <8 x float> splat (float 0xC6293E5940000000)
  %756 = load <8 x float>, ptr %.spill85, align 32
  %757 = select <8 x i1> %71, <8 x float> %755, <8 x float> %756
  store <8 x float> %757, ptr %.spill85, align 32
  %.splatinsert399 = insertelement <8 x i1> poison, i1 %736, i64 0
  %.splat400 = shufflevector <8 x i1> %.splatinsert399, <8 x i1> poison, <8 x i32> zeroinitializer
  %758 = select <8 x i1> %.splat400, <8 x float> %669, <8 x float> splat (float 0xC6293E5940000000)
  %759 = load <8 x float>, ptr %.spill86, align 32
  %760 = select <8 x i1> %71, <8 x float> %758, <8 x float> %759
  store <8 x float> %760, ptr %.spill86, align 32
  %.splatinsert401 = insertelement <8 x i1> poison, i1 %737, i64 0
  %.splat402 = shufflevector <8 x i1> %.splatinsert401, <8 x i1> poison, <8 x i32> zeroinitializer
  %761 = select <8 x i1> %.splat402, <8 x float> %670, <8 x float> splat (float 0xC6293E5940000000)
  %762 = load <8 x float>, ptr %.spill87, align 32
  %763 = select <8 x i1> %71, <8 x float> %761, <8 x float> %762
  store <8 x float> %763, ptr %.spill87, align 32
  %.splatinsert403 = insertelement <8 x i1> poison, i1 %738, i64 0
  %.splat404 = shufflevector <8 x i1> %.splatinsert403, <8 x i1> poison, <8 x i32> zeroinitializer
  %764 = select <8 x i1> %.splat404, <8 x float> %671, <8 x float> splat (float 0xC6293E5940000000)
  %765 = load <8 x float>, ptr %.spill88, align 32
  %766 = select <8 x i1> %71, <8 x float> %764, <8 x float> %765
  store <8 x float> %766, ptr %.spill88, align 32
  %.splatinsert405 = insertelement <8 x i1> poison, i1 %739, i64 0
  %.splat406 = shufflevector <8 x i1> %.splatinsert405, <8 x i1> poison, <8 x i32> zeroinitializer
  %767 = select <8 x i1> %.splat406, <8 x float> %672, <8 x float> splat (float 0xC6293E5940000000)
  %768 = load <8 x float>, ptr %.spill89, align 32
  %769 = select <8 x i1> %71, <8 x float> %767, <8 x float> %768
  store <8 x float> %769, ptr %.spill89, align 32
  %.splatinsert407 = insertelement <8 x i1> poison, i1 %740, i64 0
  %.splat408 = shufflevector <8 x i1> %.splatinsert407, <8 x i1> poison, <8 x i32> zeroinitializer
  %770 = select <8 x i1> %.splat408, <8 x float> %673, <8 x float> splat (float 0xC6293E5940000000)
  %771 = load <8 x float>, ptr %.spill90, align 32
  %772 = select <8 x i1> %71, <8 x float> %770, <8 x float> %771
  store <8 x float> %772, ptr %.spill90, align 32
  %.splatinsert409 = insertelement <8 x i1> poison, i1 %741, i64 0
  %.splat410 = shufflevector <8 x i1> %.splatinsert409, <8 x i1> poison, <8 x i32> zeroinitializer
  %773 = select <8 x i1> %.splat410, <8 x float> %674, <8 x float> splat (float 0xC6293E5940000000)
  %774 = load <8 x float>, ptr %.spill91, align 32
  %775 = select <8 x i1> %71, <8 x float> %773, <8 x float> %774
  store <8 x float> %775, ptr %.spill91, align 32
  %.splatinsert411 = insertelement <8 x i1> poison, i1 %742, i64 0
  %.splat412 = shufflevector <8 x i1> %.splatinsert411, <8 x i1> poison, <8 x i32> zeroinitializer
  %776 = select <8 x i1> %.splat412, <8 x float> %675, <8 x float> splat (float 0xC6293E5940000000)
  %777 = load <8 x float>, ptr %.spill92, align 32
  %778 = select <8 x i1> %71, <8 x float> %776, <8 x float> %777
  store <8 x float> %778, ptr %.spill92, align 32
  %.splatinsert413 = insertelement <8 x i1> poison, i1 %743, i64 0
  %.splat414 = shufflevector <8 x i1> %.splatinsert413, <8 x i1> poison, <8 x i32> zeroinitializer
  %779 = select <8 x i1> %.splat414, <8 x float> %676, <8 x float> splat (float 0xC6293E5940000000)
  %780 = load <8 x float>, ptr %.spill93, align 32
  %781 = select <8 x i1> %71, <8 x float> %779, <8 x float> %780
  store <8 x float> %781, ptr %.spill93, align 32
  %.splatinsert415 = insertelement <8 x i1> poison, i1 %744, i64 0
  %.splat416 = shufflevector <8 x i1> %.splatinsert415, <8 x i1> poison, <8 x i32> zeroinitializer
  %782 = select <8 x i1> %.splat416, <8 x float> %677, <8 x float> splat (float 0xC6293E5940000000)
  %783 = load <8 x float>, ptr %.spill94, align 32
  %784 = select <8 x i1> %71, <8 x float> %782, <8 x float> %783
  store <8 x float> %784, ptr %.spill94, align 32
  %.splatinsert417 = insertelement <8 x i1> poison, i1 %745, i64 0
  %.splat418 = shufflevector <8 x i1> %.splatinsert417, <8 x i1> poison, <8 x i32> zeroinitializer
  %785 = select <8 x i1> %.splat418, <8 x float> %678, <8 x float> splat (float 0xC6293E5940000000)
  %786 = load <8 x float>, ptr %.spill95, align 32
  %787 = select <8 x i1> %71, <8 x float> %785, <8 x float> %786
  store <8 x float> %787, ptr %.spill95, align 32
  %.splatinsert419 = insertelement <8 x i1> poison, i1 %746, i64 0
  %.splat420 = shufflevector <8 x i1> %.splatinsert419, <8 x i1> poison, <8 x i32> zeroinitializer
  %788 = select <8 x i1> %.splat420, <8 x float> %679, <8 x float> splat (float 0xC6293E5940000000)
  %789 = load <8 x float>, ptr %.spill96, align 32
  %790 = select <8 x i1> %71, <8 x float> %788, <8 x float> %789
  store <8 x float> %790, ptr %.spill96, align 32
  %.splatinsert421 = insertelement <8 x i1> poison, i1 %747, i64 0
  %.splat422 = shufflevector <8 x i1> %.splatinsert421, <8 x i1> poison, <8 x i32> zeroinitializer
  %791 = select <8 x i1> %.splat422, <8 x float> %680, <8 x float> splat (float 0xC6293E5940000000)
  %792 = load <8 x float>, ptr %.spill97, align 32
  %793 = select <8 x i1> %71, <8 x float> %791, <8 x float> %792
  store <8 x float> %793, ptr %.spill97, align 32
  %.splatinsert423 = insertelement <8 x i1> poison, i1 %748, i64 0
  %.splat424 = shufflevector <8 x i1> %.splatinsert423, <8 x i1> poison, <8 x i32> zeroinitializer
  %794 = select <8 x i1> %.splat424, <8 x float> %681, <8 x float> splat (float 0xC6293E5940000000)
  %795 = load <8 x float>, ptr %.spill98, align 32
  %796 = select <8 x i1> %71, <8 x float> %794, <8 x float> %795
  store <8 x float> %796, ptr %.spill98, align 32
  %797 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill99, align 64
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %797, 0
  %800 = select <8 x i1> %71, <8 x ptr> %798, <8 x ptr> %799
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %802 = extractvalue { <8 x ptr>, <8 x i64> } %797, 1
  %803 = select <8 x i1> %71, <8 x i64> %801, <8 x i64> %802
  %804 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %800, 0
  %805 = insertvalue { <8 x ptr>, <8 x i64> } %804, <8 x i64> %803, 1
  store { <8 x ptr>, <8 x i64> } %805, ptr %tile_snapshot.spill99, align 64
  %806 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %808 = add <8 x i64> %807, zeroinitializer
  %809 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %806, 0
  %810 = insertvalue { <8 x ptr>, <8 x i64> } %809, <8 x i64> %808, 1
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %810, 1
  %813 = extractelement <8 x ptr> %811, i32 0
  %814 = extractelement <8 x i64> %812, i32 0
  %815 = sub i64 %814, 0
  %816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %817 = select i1 %816, i64 %815, i64 0
  %private.contiguous.address425 = getelementptr i8, ptr %813, i64 %817
  %private.contiguous.preserve426 = load <8 x float>, ptr %private.contiguous.address425, align 4
  %818 = select <8 x i1> %71, <8 x float> %749, <8 x float> %private.contiguous.preserve426
  store <8 x float> %818, ptr %private.contiguous.address425, align 4
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %821 = add <8 x i64> %820, splat (i64 32)
  %822 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %819, 0
  %823 = insertvalue { <8 x ptr>, <8 x i64> } %822, <8 x i64> %821, 1
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %823, 1
  %826 = extractelement <8 x ptr> %824, i32 0
  %827 = extractelement <8 x i64> %825, i32 0
  %828 = sub i64 %827, 0
  %829 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %830 = select i1 %829, i64 %828, i64 0
  %private.contiguous.address427 = getelementptr i8, ptr %826, i64 %830
  %private.contiguous.preserve428 = load <8 x float>, ptr %private.contiguous.address427, align 4
  %831 = select <8 x i1> %71, <8 x float> %752, <8 x float> %private.contiguous.preserve428
  store <8 x float> %831, ptr %private.contiguous.address427, align 4
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %834 = add <8 x i64> %833, splat (i64 64)
  %835 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %832, 0
  %836 = insertvalue { <8 x ptr>, <8 x i64> } %835, <8 x i64> %834, 1
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %838 = extractvalue { <8 x ptr>, <8 x i64> } %836, 1
  %839 = extractelement <8 x ptr> %837, i32 0
  %840 = extractelement <8 x i64> %838, i32 0
  %841 = sub i64 %840, 0
  %842 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %843 = select i1 %842, i64 %841, i64 0
  %private.contiguous.address429 = getelementptr i8, ptr %839, i64 %843
  %private.contiguous.preserve430 = load <8 x float>, ptr %private.contiguous.address429, align 4
  %844 = select <8 x i1> %71, <8 x float> %755, <8 x float> %private.contiguous.preserve430
  store <8 x float> %844, ptr %private.contiguous.address429, align 4
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %847 = add <8 x i64> %846, splat (i64 96)
  %848 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %845, 0
  %849 = insertvalue { <8 x ptr>, <8 x i64> } %848, <8 x i64> %847, 1
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %849, 1
  %852 = extractelement <8 x ptr> %850, i32 0
  %853 = extractelement <8 x i64> %851, i32 0
  %854 = sub i64 %853, 0
  %855 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %856 = select i1 %855, i64 %854, i64 0
  %private.contiguous.address431 = getelementptr i8, ptr %852, i64 %856
  %private.contiguous.preserve432 = load <8 x float>, ptr %private.contiguous.address431, align 4
  %857 = select <8 x i1> %71, <8 x float> %758, <8 x float> %private.contiguous.preserve432
  store <8 x float> %857, ptr %private.contiguous.address431, align 4
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %859 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %860 = add <8 x i64> %859, splat (i64 128)
  %861 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %858, 0
  %862 = insertvalue { <8 x ptr>, <8 x i64> } %861, <8 x i64> %860, 1
  %863 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %864 = extractvalue { <8 x ptr>, <8 x i64> } %862, 1
  %865 = extractelement <8 x ptr> %863, i32 0
  %866 = extractelement <8 x i64> %864, i32 0
  %867 = sub i64 %866, 0
  %868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %869 = select i1 %868, i64 %867, i64 0
  %private.contiguous.address433 = getelementptr i8, ptr %865, i64 %869
  %private.contiguous.preserve434 = load <8 x float>, ptr %private.contiguous.address433, align 4
  %870 = select <8 x i1> %71, <8 x float> %761, <8 x float> %private.contiguous.preserve434
  store <8 x float> %870, ptr %private.contiguous.address433, align 4
  %871 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %873 = add <8 x i64> %872, splat (i64 160)
  %874 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %871, 0
  %875 = insertvalue { <8 x ptr>, <8 x i64> } %874, <8 x i64> %873, 1
  %876 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %875, 1
  %878 = extractelement <8 x ptr> %876, i32 0
  %879 = extractelement <8 x i64> %877, i32 0
  %880 = sub i64 %879, 0
  %881 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %882 = select i1 %881, i64 %880, i64 0
  %private.contiguous.address435 = getelementptr i8, ptr %878, i64 %882
  %private.contiguous.preserve436 = load <8 x float>, ptr %private.contiguous.address435, align 4
  %883 = select <8 x i1> %71, <8 x float> %764, <8 x float> %private.contiguous.preserve436
  store <8 x float> %883, ptr %private.contiguous.address435, align 4
  %884 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %885 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %886 = add <8 x i64> %885, splat (i64 192)
  %887 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %884, 0
  %888 = insertvalue { <8 x ptr>, <8 x i64> } %887, <8 x i64> %886, 1
  %889 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %890 = extractvalue { <8 x ptr>, <8 x i64> } %888, 1
  %891 = extractelement <8 x ptr> %889, i32 0
  %892 = extractelement <8 x i64> %890, i32 0
  %893 = sub i64 %892, 0
  %894 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %895 = select i1 %894, i64 %893, i64 0
  %private.contiguous.address437 = getelementptr i8, ptr %891, i64 %895
  %private.contiguous.preserve438 = load <8 x float>, ptr %private.contiguous.address437, align 4
  %896 = select <8 x i1> %71, <8 x float> %767, <8 x float> %private.contiguous.preserve438
  store <8 x float> %896, ptr %private.contiguous.address437, align 4
  %897 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %898 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %899 = add <8 x i64> %898, splat (i64 224)
  %900 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %897, 0
  %901 = insertvalue { <8 x ptr>, <8 x i64> } %900, <8 x i64> %899, 1
  %902 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %903 = extractvalue { <8 x ptr>, <8 x i64> } %901, 1
  %904 = extractelement <8 x ptr> %902, i32 0
  %905 = extractelement <8 x i64> %903, i32 0
  %906 = sub i64 %905, 0
  %907 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %908 = select i1 %907, i64 %906, i64 0
  %private.contiguous.address439 = getelementptr i8, ptr %904, i64 %908
  %private.contiguous.preserve440 = load <8 x float>, ptr %private.contiguous.address439, align 4
  %909 = select <8 x i1> %71, <8 x float> %770, <8 x float> %private.contiguous.preserve440
  store <8 x float> %909, ptr %private.contiguous.address439, align 4
  %910 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %911 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %912 = add <8 x i64> %911, splat (i64 256)
  %913 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %910, 0
  %914 = insertvalue { <8 x ptr>, <8 x i64> } %913, <8 x i64> %912, 1
  %915 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %914, 1
  %917 = extractelement <8 x ptr> %915, i32 0
  %918 = extractelement <8 x i64> %916, i32 0
  %919 = sub i64 %918, 0
  %920 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %921 = select i1 %920, i64 %919, i64 0
  %private.contiguous.address441 = getelementptr i8, ptr %917, i64 %921
  %private.contiguous.preserve442 = load <8 x float>, ptr %private.contiguous.address441, align 4
  %922 = select <8 x i1> %71, <8 x float> %773, <8 x float> %private.contiguous.preserve442
  store <8 x float> %922, ptr %private.contiguous.address441, align 4
  %923 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %924 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %925 = add <8 x i64> %924, splat (i64 288)
  %926 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %923, 0
  %927 = insertvalue { <8 x ptr>, <8 x i64> } %926, <8 x i64> %925, 1
  %928 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %929 = extractvalue { <8 x ptr>, <8 x i64> } %927, 1
  %930 = extractelement <8 x ptr> %928, i32 0
  %931 = extractelement <8 x i64> %929, i32 0
  %932 = sub i64 %931, 0
  %933 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %934 = select i1 %933, i64 %932, i64 0
  %private.contiguous.address443 = getelementptr i8, ptr %930, i64 %934
  %private.contiguous.preserve444 = load <8 x float>, ptr %private.contiguous.address443, align 4
  %935 = select <8 x i1> %71, <8 x float> %776, <8 x float> %private.contiguous.preserve444
  store <8 x float> %935, ptr %private.contiguous.address443, align 4
  %936 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %937 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %938 = add <8 x i64> %937, splat (i64 320)
  %939 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %936, 0
  %940 = insertvalue { <8 x ptr>, <8 x i64> } %939, <8 x i64> %938, 1
  %941 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %942 = extractvalue { <8 x ptr>, <8 x i64> } %940, 1
  %943 = extractelement <8 x ptr> %941, i32 0
  %944 = extractelement <8 x i64> %942, i32 0
  %945 = sub i64 %944, 0
  %946 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %947 = select i1 %946, i64 %945, i64 0
  %private.contiguous.address445 = getelementptr i8, ptr %943, i64 %947
  %private.contiguous.preserve446 = load <8 x float>, ptr %private.contiguous.address445, align 4
  %948 = select <8 x i1> %71, <8 x float> %779, <8 x float> %private.contiguous.preserve446
  store <8 x float> %948, ptr %private.contiguous.address445, align 4
  %949 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %951 = add <8 x i64> %950, splat (i64 352)
  %952 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %949, 0
  %953 = insertvalue { <8 x ptr>, <8 x i64> } %952, <8 x i64> %951, 1
  %954 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %955 = extractvalue { <8 x ptr>, <8 x i64> } %953, 1
  %956 = extractelement <8 x ptr> %954, i32 0
  %957 = extractelement <8 x i64> %955, i32 0
  %958 = sub i64 %957, 0
  %959 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %960 = select i1 %959, i64 %958, i64 0
  %private.contiguous.address447 = getelementptr i8, ptr %956, i64 %960
  %private.contiguous.preserve448 = load <8 x float>, ptr %private.contiguous.address447, align 4
  %961 = select <8 x i1> %71, <8 x float> %782, <8 x float> %private.contiguous.preserve448
  store <8 x float> %961, ptr %private.contiguous.address447, align 4
  %962 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %963 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %964 = add <8 x i64> %963, splat (i64 384)
  %965 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %962, 0
  %966 = insertvalue { <8 x ptr>, <8 x i64> } %965, <8 x i64> %964, 1
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %968 = extractvalue { <8 x ptr>, <8 x i64> } %966, 1
  %969 = extractelement <8 x ptr> %967, i32 0
  %970 = extractelement <8 x i64> %968, i32 0
  %971 = sub i64 %970, 0
  %972 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %973 = select i1 %972, i64 %971, i64 0
  %private.contiguous.address449 = getelementptr i8, ptr %969, i64 %973
  %private.contiguous.preserve450 = load <8 x float>, ptr %private.contiguous.address449, align 4
  %974 = select <8 x i1> %71, <8 x float> %785, <8 x float> %private.contiguous.preserve450
  store <8 x float> %974, ptr %private.contiguous.address449, align 4
  %975 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %976 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %977 = add <8 x i64> %976, splat (i64 416)
  %978 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %975, 0
  %979 = insertvalue { <8 x ptr>, <8 x i64> } %978, <8 x i64> %977, 1
  %980 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %979, 1
  %982 = extractelement <8 x ptr> %980, i32 0
  %983 = extractelement <8 x i64> %981, i32 0
  %984 = sub i64 %983, 0
  %985 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %986 = select i1 %985, i64 %984, i64 0
  %private.contiguous.address451 = getelementptr i8, ptr %982, i64 %986
  %private.contiguous.preserve452 = load <8 x float>, ptr %private.contiguous.address451, align 4
  %987 = select <8 x i1> %71, <8 x float> %788, <8 x float> %private.contiguous.preserve452
  store <8 x float> %987, ptr %private.contiguous.address451, align 4
  %988 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %989 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %990 = add <8 x i64> %989, splat (i64 448)
  %991 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %988, 0
  %992 = insertvalue { <8 x ptr>, <8 x i64> } %991, <8 x i64> %990, 1
  %993 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %994 = extractvalue { <8 x ptr>, <8 x i64> } %992, 1
  %995 = extractelement <8 x ptr> %993, i32 0
  %996 = extractelement <8 x i64> %994, i32 0
  %997 = sub i64 %996, 0
  %998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %999 = select i1 %998, i64 %997, i64 0
  %private.contiguous.address453 = getelementptr i8, ptr %995, i64 %999
  %private.contiguous.preserve454 = load <8 x float>, ptr %private.contiguous.address453, align 4
  %1000 = select <8 x i1> %71, <8 x float> %791, <8 x float> %private.contiguous.preserve454
  store <8 x float> %1000, ptr %private.contiguous.address453, align 4
  %1001 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1003 = add <8 x i64> %1002, splat (i64 480)
  %1004 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1001, 0
  %1005 = insertvalue { <8 x ptr>, <8 x i64> } %1004, <8 x i64> %1003, 1
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1007 = extractvalue { <8 x ptr>, <8 x i64> } %1005, 1
  %1008 = extractelement <8 x ptr> %1006, i32 0
  %1009 = extractelement <8 x i64> %1007, i32 0
  %1010 = sub i64 %1009, 0
  %1011 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1012 = select i1 %1011, i64 %1010, i64 0
  %private.contiguous.address455 = getelementptr i8, ptr %1008, i64 %1012
  %private.contiguous.preserve456 = load <8 x float>, ptr %private.contiguous.address455, align 4
  %1013 = select <8 x i1> %71, <8 x float> %794, <8 x float> %private.contiguous.preserve456
  store <8 x float> %1013, ptr %private.contiguous.address455, align 4
  store i64 0, ptr %.slot100, align 4
  %1014 = load <8 x float>, ptr %.slot101, align 32
  %1015 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1014
  store <8 x float> %1015, ptr %.slot101, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state457 = load i64, ptr %.slot100, align 4
  %1016 = icmp slt i64 %.state457, 16
  br i1 %1016, label %direct.true458, label %direct.false459

direct.schedule.32:                               ; preds = %direct.true458
  %.state460 = load i64, ptr %.slot100, align 4
  %1017 = sdiv i64 %.state460, 1
  %.spill.load461 = load i64, ptr %.spill66, align 4
  %1018 = mul i64 %.spill.load461, 1
  %1019 = add i64 %1018, 0
  %1020 = mul i64 %1019, 1
  %1021 = add i64 %1020, 0
  %1022 = mul i64 %1021, 16
  %1023 = add i64 %1022, %1017
  %tile_snapshot.spill.load462 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill99, align 64
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load462, 0
  %1025 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load462, 1
  %.splatinsert463 = insertelement <8 x i64> poison, i64 %1023, i64 0
  %.splat464 = shufflevector <8 x i64> %.splatinsert463, <8 x i64> poison, <8 x i32> zeroinitializer
  %1026 = mul <8 x i64> %.splat464, splat (i64 32)
  %1027 = add <8 x i64> %1025, %1026
  %1028 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1024, 0
  %1029 = insertvalue { <8 x ptr>, <8 x i64> } %1028, <8 x i64> %1027, 1
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1031 = extractvalue { <8 x ptr>, <8 x i64> } %1029, 1
  %1032 = extractelement <8 x ptr> %1030, i32 0
  %1033 = extractelement <8 x i64> %1031, i32 0
  %1034 = sub i64 %1033, 0
  %1035 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1036 = select i1 %1035, i64 %1034, i64 0
  %private.contiguous.address465 = getelementptr i8, ptr %1032, i64 %1036
  %private.contiguous.load466 = load <8 x float>, ptr %private.contiguous.address465, align 4
  %1037 = select <8 x i1> %71, <8 x float> %private.contiguous.load466, <8 x float> zeroinitializer
  %.state467 = load <8 x float>, ptr %.slot101, align 32
  %1038 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state467, <8 x float> %1037)
  %.state468 = load i64, ptr %.slot100, align 4
  %1039 = add i64 %.state468, 1
  store i64 %1039, ptr %.slot100, align 4
  %1040 = load <8 x float>, ptr %.slot101, align 32
  %1041 = select <8 x i1> %71, <8 x float> %1038, <8 x float> %1040
  store <8 x float> %1041, ptr %.slot101, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false459
  %.state469 = load <8 x float>, ptr %.slot35, align 32
  %.state470 = load <8 x float>, ptr %.slot101, align 32
  %1042 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state469, <8 x float> %.state470)
  %1043 = load <8 x float>, ptr %.spill102, align 32
  %1044 = select <8 x i1> %71, <8 x float> %1042, <8 x float> %1043
  store <8 x float> %1044, ptr %.spill102, align 32
  %.state471 = load <8 x float>, ptr %.slot35, align 32
  %1045 = fsub <8 x float> %.state471, %1042
  %1046 = select <8 x i1> %71, <8 x float> %1045, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1046)
  %1047 = load <8 x float>, ptr %.spill103, align 32
  %1048 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %1047
  store <8 x float> %1048, ptr %.spill103, align 32
  %.spill.load472 = load <8 x float>, ptr %.spill83, align 32
  %1049 = fsub <8 x float> %.spill.load472, %1042
  %.spill.load473 = load <8 x float>, ptr %.spill84, align 32
  %1050 = fsub <8 x float> %.spill.load473, %1042
  %.spill.load474 = load <8 x float>, ptr %.spill85, align 32
  %1051 = fsub <8 x float> %.spill.load474, %1042
  %.spill.load475 = load <8 x float>, ptr %.spill86, align 32
  %1052 = fsub <8 x float> %.spill.load475, %1042
  %.spill.load476 = load <8 x float>, ptr %.spill87, align 32
  %1053 = fsub <8 x float> %.spill.load476, %1042
  %.spill.load477 = load <8 x float>, ptr %.spill88, align 32
  %1054 = fsub <8 x float> %.spill.load477, %1042
  %.spill.load478 = load <8 x float>, ptr %.spill89, align 32
  %1055 = fsub <8 x float> %.spill.load478, %1042
  %.spill.load479 = load <8 x float>, ptr %.spill90, align 32
  %1056 = fsub <8 x float> %.spill.load479, %1042
  %.spill.load480 = load <8 x float>, ptr %.spill91, align 32
  %1057 = fsub <8 x float> %.spill.load480, %1042
  %.spill.load481 = load <8 x float>, ptr %.spill92, align 32
  %1058 = fsub <8 x float> %.spill.load481, %1042
  %.spill.load482 = load <8 x float>, ptr %.spill93, align 32
  %1059 = fsub <8 x float> %.spill.load482, %1042
  %.spill.load483 = load <8 x float>, ptr %.spill94, align 32
  %1060 = fsub <8 x float> %.spill.load483, %1042
  %.spill.load484 = load <8 x float>, ptr %.spill95, align 32
  %1061 = fsub <8 x float> %.spill.load484, %1042
  %.spill.load485 = load <8 x float>, ptr %.spill96, align 32
  %1062 = fsub <8 x float> %.spill.load485, %1042
  %.spill.load486 = load <8 x float>, ptr %.spill97, align 32
  %1063 = fsub <8 x float> %.spill.load486, %1042
  %.spill.load487 = load <8 x float>, ptr %.spill98, align 32
  %1064 = fsub <8 x float> %.spill.load487, %1042
  %1065 = select <8 x i1> %71, <8 x float> %1049, <8 x float> zeroinitializer
  %native.exp488 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1065)
  %1066 = select <8 x i1> %71, <8 x float> %1050, <8 x float> zeroinitializer
  %native.exp489 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1066)
  %1067 = select <8 x i1> %71, <8 x float> %1051, <8 x float> zeroinitializer
  %native.exp490 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1067)
  %1068 = select <8 x i1> %71, <8 x float> %1052, <8 x float> zeroinitializer
  %native.exp491 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1068)
  %1069 = select <8 x i1> %71, <8 x float> %1053, <8 x float> zeroinitializer
  %native.exp492 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1069)
  %1070 = select <8 x i1> %71, <8 x float> %1054, <8 x float> zeroinitializer
  %native.exp493 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1070)
  %1071 = select <8 x i1> %71, <8 x float> %1055, <8 x float> zeroinitializer
  %native.exp494 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1071)
  %1072 = select <8 x i1> %71, <8 x float> %1056, <8 x float> zeroinitializer
  %native.exp495 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1072)
  %1073 = select <8 x i1> %71, <8 x float> %1057, <8 x float> zeroinitializer
  %native.exp496 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1073)
  %1074 = select <8 x i1> %71, <8 x float> %1058, <8 x float> zeroinitializer
  %native.exp497 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1074)
  %1075 = select <8 x i1> %71, <8 x float> %1059, <8 x float> zeroinitializer
  %native.exp498 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1075)
  %1076 = select <8 x i1> %71, <8 x float> %1060, <8 x float> zeroinitializer
  %native.exp499 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1076)
  %1077 = select <8 x i1> %71, <8 x float> %1061, <8 x float> zeroinitializer
  %native.exp500 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1077)
  %1078 = select <8 x i1> %71, <8 x float> %1062, <8 x float> zeroinitializer
  %native.exp501 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1078)
  %1079 = select <8 x i1> %71, <8 x float> %1063, <8 x float> zeroinitializer
  %native.exp502 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1079)
  %1080 = select <8 x i1> %71, <8 x float> %1064, <8 x float> zeroinitializer
  %native.exp503 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1080)
  %.spill.load504 = load i1, ptr %.spill67, align 1
  %.splatinsert505 = insertelement <8 x i1> poison, i1 %.spill.load504, i64 0
  %.splat506 = shufflevector <8 x i1> %.splatinsert505, <8 x i1> poison, <8 x i32> zeroinitializer
  %1081 = select <8 x i1> %.splat506, <8 x float> %native.exp488, <8 x float> zeroinitializer
  %.spill.load507 = load i1, ptr %.spill68, align 1
  %.splatinsert508 = insertelement <8 x i1> poison, i1 %.spill.load507, i64 0
  %.splat509 = shufflevector <8 x i1> %.splatinsert508, <8 x i1> poison, <8 x i32> zeroinitializer
  %1082 = select <8 x i1> %.splat509, <8 x float> %native.exp489, <8 x float> zeroinitializer
  %.spill.load510 = load i1, ptr %.spill69, align 1
  %.splatinsert511 = insertelement <8 x i1> poison, i1 %.spill.load510, i64 0
  %.splat512 = shufflevector <8 x i1> %.splatinsert511, <8 x i1> poison, <8 x i32> zeroinitializer
  %1083 = select <8 x i1> %.splat512, <8 x float> %native.exp490, <8 x float> zeroinitializer
  %.spill.load513 = load i1, ptr %.spill70, align 1
  %.splatinsert514 = insertelement <8 x i1> poison, i1 %.spill.load513, i64 0
  %.splat515 = shufflevector <8 x i1> %.splatinsert514, <8 x i1> poison, <8 x i32> zeroinitializer
  %1084 = select <8 x i1> %.splat515, <8 x float> %native.exp491, <8 x float> zeroinitializer
  %.spill.load516 = load i1, ptr %.spill71, align 1
  %.splatinsert517 = insertelement <8 x i1> poison, i1 %.spill.load516, i64 0
  %.splat518 = shufflevector <8 x i1> %.splatinsert517, <8 x i1> poison, <8 x i32> zeroinitializer
  %1085 = select <8 x i1> %.splat518, <8 x float> %native.exp492, <8 x float> zeroinitializer
  %.spill.load519 = load i1, ptr %.spill72, align 1
  %.splatinsert520 = insertelement <8 x i1> poison, i1 %.spill.load519, i64 0
  %.splat521 = shufflevector <8 x i1> %.splatinsert520, <8 x i1> poison, <8 x i32> zeroinitializer
  %1086 = select <8 x i1> %.splat521, <8 x float> %native.exp493, <8 x float> zeroinitializer
  %.spill.load522 = load i1, ptr %.spill73, align 1
  %.splatinsert523 = insertelement <8 x i1> poison, i1 %.spill.load522, i64 0
  %.splat524 = shufflevector <8 x i1> %.splatinsert523, <8 x i1> poison, <8 x i32> zeroinitializer
  %1087 = select <8 x i1> %.splat524, <8 x float> %native.exp494, <8 x float> zeroinitializer
  %.spill.load525 = load i1, ptr %.spill74, align 1
  %.splatinsert526 = insertelement <8 x i1> poison, i1 %.spill.load525, i64 0
  %.splat527 = shufflevector <8 x i1> %.splatinsert526, <8 x i1> poison, <8 x i32> zeroinitializer
  %1088 = select <8 x i1> %.splat527, <8 x float> %native.exp495, <8 x float> zeroinitializer
  %.spill.load528 = load i1, ptr %.spill75, align 1
  %.splatinsert529 = insertelement <8 x i1> poison, i1 %.spill.load528, i64 0
  %.splat530 = shufflevector <8 x i1> %.splatinsert529, <8 x i1> poison, <8 x i32> zeroinitializer
  %1089 = select <8 x i1> %.splat530, <8 x float> %native.exp496, <8 x float> zeroinitializer
  %.spill.load531 = load i1, ptr %.spill76, align 1
  %.splatinsert532 = insertelement <8 x i1> poison, i1 %.spill.load531, i64 0
  %.splat533 = shufflevector <8 x i1> %.splatinsert532, <8 x i1> poison, <8 x i32> zeroinitializer
  %1090 = select <8 x i1> %.splat533, <8 x float> %native.exp497, <8 x float> zeroinitializer
  %.spill.load534 = load i1, ptr %.spill77, align 1
  %.splatinsert535 = insertelement <8 x i1> poison, i1 %.spill.load534, i64 0
  %.splat536 = shufflevector <8 x i1> %.splatinsert535, <8 x i1> poison, <8 x i32> zeroinitializer
  %1091 = select <8 x i1> %.splat536, <8 x float> %native.exp498, <8 x float> zeroinitializer
  %.spill.load537 = load i1, ptr %.spill78, align 1
  %.splatinsert538 = insertelement <8 x i1> poison, i1 %.spill.load537, i64 0
  %.splat539 = shufflevector <8 x i1> %.splatinsert538, <8 x i1> poison, <8 x i32> zeroinitializer
  %1092 = select <8 x i1> %.splat539, <8 x float> %native.exp499, <8 x float> zeroinitializer
  %.spill.load540 = load i1, ptr %.spill79, align 1
  %.splatinsert541 = insertelement <8 x i1> poison, i1 %.spill.load540, i64 0
  %.splat542 = shufflevector <8 x i1> %.splatinsert541, <8 x i1> poison, <8 x i32> zeroinitializer
  %1093 = select <8 x i1> %.splat542, <8 x float> %native.exp500, <8 x float> zeroinitializer
  %.spill.load543 = load i1, ptr %.spill80, align 1
  %.splatinsert544 = insertelement <8 x i1> poison, i1 %.spill.load543, i64 0
  %.splat545 = shufflevector <8 x i1> %.splatinsert544, <8 x i1> poison, <8 x i32> zeroinitializer
  %1094 = select <8 x i1> %.splat545, <8 x float> %native.exp501, <8 x float> zeroinitializer
  %.spill.load546 = load i1, ptr %.spill81, align 1
  %.splatinsert547 = insertelement <8 x i1> poison, i1 %.spill.load546, i64 0
  %.splat548 = shufflevector <8 x i1> %.splatinsert547, <8 x i1> poison, <8 x i32> zeroinitializer
  %1095 = select <8 x i1> %.splat548, <8 x float> %native.exp502, <8 x float> zeroinitializer
  %.spill.load549 = load i1, ptr %.spill82, align 1
  %.splatinsert550 = insertelement <8 x i1> poison, i1 %.spill.load549, i64 0
  %.splat551 = shufflevector <8 x i1> %.splatinsert550, <8 x i1> poison, <8 x i32> zeroinitializer
  %1096 = select <8 x i1> %.splat551, <8 x float> %native.exp503, <8 x float> zeroinitializer
  %1097 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %1098 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1099 = extractvalue { <8 x ptr>, <8 x i64> } %1097, 0
  %1100 = select <8 x i1> %71, <8 x ptr> %1098, <8 x ptr> %1099
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %1097, 1
  %1103 = select <8 x i1> %71, <8 x i64> %1101, <8 x i64> %1102
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1100, 0
  %1105 = insertvalue { <8 x ptr>, <8 x i64> } %1104, <8 x i64> %1103, 1
  store { <8 x ptr>, <8 x i64> } %1105, ptr %tile_snapshot.spill104, align 64
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1108 = add <8 x i64> %1107, zeroinitializer
  %1109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1106, 0
  %1110 = insertvalue { <8 x ptr>, <8 x i64> } %1109, <8 x i64> %1108, 1
  %1111 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1112 = extractvalue { <8 x ptr>, <8 x i64> } %1110, 1
  %1113 = extractelement <8 x ptr> %1111, i32 0
  %1114 = extractelement <8 x i64> %1112, i32 0
  %1115 = sub i64 %1114, 0
  %1116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1117 = select i1 %1116, i64 %1115, i64 0
  %private.contiguous.address552 = getelementptr i8, ptr %1113, i64 %1117
  %private.contiguous.preserve553 = load <8 x float>, ptr %private.contiguous.address552, align 4
  %1118 = select <8 x i1> %71, <8 x float> %1081, <8 x float> %private.contiguous.preserve553
  store <8 x float> %1118, ptr %private.contiguous.address552, align 4
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1121 = add <8 x i64> %1120, splat (i64 32)
  %1122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1119, 0
  %1123 = insertvalue { <8 x ptr>, <8 x i64> } %1122, <8 x i64> %1121, 1
  %1124 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1125 = extractvalue { <8 x ptr>, <8 x i64> } %1123, 1
  %1126 = extractelement <8 x ptr> %1124, i32 0
  %1127 = extractelement <8 x i64> %1125, i32 0
  %1128 = sub i64 %1127, 0
  %1129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1130 = select i1 %1129, i64 %1128, i64 0
  %private.contiguous.address554 = getelementptr i8, ptr %1126, i64 %1130
  %private.contiguous.preserve555 = load <8 x float>, ptr %private.contiguous.address554, align 4
  %1131 = select <8 x i1> %71, <8 x float> %1082, <8 x float> %private.contiguous.preserve555
  store <8 x float> %1131, ptr %private.contiguous.address554, align 4
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1134 = add <8 x i64> %1133, splat (i64 64)
  %1135 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1132, 0
  %1136 = insertvalue { <8 x ptr>, <8 x i64> } %1135, <8 x i64> %1134, 1
  %1137 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1138 = extractvalue { <8 x ptr>, <8 x i64> } %1136, 1
  %1139 = extractelement <8 x ptr> %1137, i32 0
  %1140 = extractelement <8 x i64> %1138, i32 0
  %1141 = sub i64 %1140, 0
  %1142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1143 = select i1 %1142, i64 %1141, i64 0
  %private.contiguous.address556 = getelementptr i8, ptr %1139, i64 %1143
  %private.contiguous.preserve557 = load <8 x float>, ptr %private.contiguous.address556, align 4
  %1144 = select <8 x i1> %71, <8 x float> %1083, <8 x float> %private.contiguous.preserve557
  store <8 x float> %1144, ptr %private.contiguous.address556, align 4
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1147 = add <8 x i64> %1146, splat (i64 96)
  %1148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1145, 0
  %1149 = insertvalue { <8 x ptr>, <8 x i64> } %1148, <8 x i64> %1147, 1
  %1150 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1151 = extractvalue { <8 x ptr>, <8 x i64> } %1149, 1
  %1152 = extractelement <8 x ptr> %1150, i32 0
  %1153 = extractelement <8 x i64> %1151, i32 0
  %1154 = sub i64 %1153, 0
  %1155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1156 = select i1 %1155, i64 %1154, i64 0
  %private.contiguous.address558 = getelementptr i8, ptr %1152, i64 %1156
  %private.contiguous.preserve559 = load <8 x float>, ptr %private.contiguous.address558, align 4
  %1157 = select <8 x i1> %71, <8 x float> %1084, <8 x float> %private.contiguous.preserve559
  store <8 x float> %1157, ptr %private.contiguous.address558, align 4
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1160 = add <8 x i64> %1159, splat (i64 128)
  %1161 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1158, 0
  %1162 = insertvalue { <8 x ptr>, <8 x i64> } %1161, <8 x i64> %1160, 1
  %1163 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1164 = extractvalue { <8 x ptr>, <8 x i64> } %1162, 1
  %1165 = extractelement <8 x ptr> %1163, i32 0
  %1166 = extractelement <8 x i64> %1164, i32 0
  %1167 = sub i64 %1166, 0
  %1168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1169 = select i1 %1168, i64 %1167, i64 0
  %private.contiguous.address560 = getelementptr i8, ptr %1165, i64 %1169
  %private.contiguous.preserve561 = load <8 x float>, ptr %private.contiguous.address560, align 4
  %1170 = select <8 x i1> %71, <8 x float> %1085, <8 x float> %private.contiguous.preserve561
  store <8 x float> %1170, ptr %private.contiguous.address560, align 4
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1173 = add <8 x i64> %1172, splat (i64 160)
  %1174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1171, 0
  %1175 = insertvalue { <8 x ptr>, <8 x i64> } %1174, <8 x i64> %1173, 1
  %1176 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1177 = extractvalue { <8 x ptr>, <8 x i64> } %1175, 1
  %1178 = extractelement <8 x ptr> %1176, i32 0
  %1179 = extractelement <8 x i64> %1177, i32 0
  %1180 = sub i64 %1179, 0
  %1181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1182 = select i1 %1181, i64 %1180, i64 0
  %private.contiguous.address562 = getelementptr i8, ptr %1178, i64 %1182
  %private.contiguous.preserve563 = load <8 x float>, ptr %private.contiguous.address562, align 4
  %1183 = select <8 x i1> %71, <8 x float> %1086, <8 x float> %private.contiguous.preserve563
  store <8 x float> %1183, ptr %private.contiguous.address562, align 4
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1186 = add <8 x i64> %1185, splat (i64 192)
  %1187 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1184, 0
  %1188 = insertvalue { <8 x ptr>, <8 x i64> } %1187, <8 x i64> %1186, 1
  %1189 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1190 = extractvalue { <8 x ptr>, <8 x i64> } %1188, 1
  %1191 = extractelement <8 x ptr> %1189, i32 0
  %1192 = extractelement <8 x i64> %1190, i32 0
  %1193 = sub i64 %1192, 0
  %1194 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1195 = select i1 %1194, i64 %1193, i64 0
  %private.contiguous.address564 = getelementptr i8, ptr %1191, i64 %1195
  %private.contiguous.preserve565 = load <8 x float>, ptr %private.contiguous.address564, align 4
  %1196 = select <8 x i1> %71, <8 x float> %1087, <8 x float> %private.contiguous.preserve565
  store <8 x float> %1196, ptr %private.contiguous.address564, align 4
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1199 = add <8 x i64> %1198, splat (i64 224)
  %1200 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1197, 0
  %1201 = insertvalue { <8 x ptr>, <8 x i64> } %1200, <8 x i64> %1199, 1
  %1202 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1203 = extractvalue { <8 x ptr>, <8 x i64> } %1201, 1
  %1204 = extractelement <8 x ptr> %1202, i32 0
  %1205 = extractelement <8 x i64> %1203, i32 0
  %1206 = sub i64 %1205, 0
  %1207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1208 = select i1 %1207, i64 %1206, i64 0
  %private.contiguous.address566 = getelementptr i8, ptr %1204, i64 %1208
  %private.contiguous.preserve567 = load <8 x float>, ptr %private.contiguous.address566, align 4
  %1209 = select <8 x i1> %71, <8 x float> %1088, <8 x float> %private.contiguous.preserve567
  store <8 x float> %1209, ptr %private.contiguous.address566, align 4
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1211 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1212 = add <8 x i64> %1211, splat (i64 256)
  %1213 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1210, 0
  %1214 = insertvalue { <8 x ptr>, <8 x i64> } %1213, <8 x i64> %1212, 1
  %1215 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1216 = extractvalue { <8 x ptr>, <8 x i64> } %1214, 1
  %1217 = extractelement <8 x ptr> %1215, i32 0
  %1218 = extractelement <8 x i64> %1216, i32 0
  %1219 = sub i64 %1218, 0
  %1220 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1221 = select i1 %1220, i64 %1219, i64 0
  %private.contiguous.address568 = getelementptr i8, ptr %1217, i64 %1221
  %private.contiguous.preserve569 = load <8 x float>, ptr %private.contiguous.address568, align 4
  %1222 = select <8 x i1> %71, <8 x float> %1089, <8 x float> %private.contiguous.preserve569
  store <8 x float> %1222, ptr %private.contiguous.address568, align 4
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1224 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1225 = add <8 x i64> %1224, splat (i64 288)
  %1226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1223, 0
  %1227 = insertvalue { <8 x ptr>, <8 x i64> } %1226, <8 x i64> %1225, 1
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %1227, 1
  %1230 = extractelement <8 x ptr> %1228, i32 0
  %1231 = extractelement <8 x i64> %1229, i32 0
  %1232 = sub i64 %1231, 0
  %1233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1234 = select i1 %1233, i64 %1232, i64 0
  %private.contiguous.address570 = getelementptr i8, ptr %1230, i64 %1234
  %private.contiguous.preserve571 = load <8 x float>, ptr %private.contiguous.address570, align 4
  %1235 = select <8 x i1> %71, <8 x float> %1090, <8 x float> %private.contiguous.preserve571
  store <8 x float> %1235, ptr %private.contiguous.address570, align 4
  %1236 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1238 = add <8 x i64> %1237, splat (i64 320)
  %1239 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1236, 0
  %1240 = insertvalue { <8 x ptr>, <8 x i64> } %1239, <8 x i64> %1238, 1
  %1241 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1242 = extractvalue { <8 x ptr>, <8 x i64> } %1240, 1
  %1243 = extractelement <8 x ptr> %1241, i32 0
  %1244 = extractelement <8 x i64> %1242, i32 0
  %1245 = sub i64 %1244, 0
  %1246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1247 = select i1 %1246, i64 %1245, i64 0
  %private.contiguous.address572 = getelementptr i8, ptr %1243, i64 %1247
  %private.contiguous.preserve573 = load <8 x float>, ptr %private.contiguous.address572, align 4
  %1248 = select <8 x i1> %71, <8 x float> %1091, <8 x float> %private.contiguous.preserve573
  store <8 x float> %1248, ptr %private.contiguous.address572, align 4
  %1249 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1250 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1251 = add <8 x i64> %1250, splat (i64 352)
  %1252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1249, 0
  %1253 = insertvalue { <8 x ptr>, <8 x i64> } %1252, <8 x i64> %1251, 1
  %1254 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1255 = extractvalue { <8 x ptr>, <8 x i64> } %1253, 1
  %1256 = extractelement <8 x ptr> %1254, i32 0
  %1257 = extractelement <8 x i64> %1255, i32 0
  %1258 = sub i64 %1257, 0
  %1259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1260 = select i1 %1259, i64 %1258, i64 0
  %private.contiguous.address574 = getelementptr i8, ptr %1256, i64 %1260
  %private.contiguous.preserve575 = load <8 x float>, ptr %private.contiguous.address574, align 4
  %1261 = select <8 x i1> %71, <8 x float> %1092, <8 x float> %private.contiguous.preserve575
  store <8 x float> %1261, ptr %private.contiguous.address574, align 4
  %1262 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1264 = add <8 x i64> %1263, splat (i64 384)
  %1265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1262, 0
  %1266 = insertvalue { <8 x ptr>, <8 x i64> } %1265, <8 x i64> %1264, 1
  %1267 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1268 = extractvalue { <8 x ptr>, <8 x i64> } %1266, 1
  %1269 = extractelement <8 x ptr> %1267, i32 0
  %1270 = extractelement <8 x i64> %1268, i32 0
  %1271 = sub i64 %1270, 0
  %1272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1273 = select i1 %1272, i64 %1271, i64 0
  %private.contiguous.address576 = getelementptr i8, ptr %1269, i64 %1273
  %private.contiguous.preserve577 = load <8 x float>, ptr %private.contiguous.address576, align 4
  %1274 = select <8 x i1> %71, <8 x float> %1093, <8 x float> %private.contiguous.preserve577
  store <8 x float> %1274, ptr %private.contiguous.address576, align 4
  %1275 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1276 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1277 = add <8 x i64> %1276, splat (i64 416)
  %1278 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1275, 0
  %1279 = insertvalue { <8 x ptr>, <8 x i64> } %1278, <8 x i64> %1277, 1
  %1280 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1281 = extractvalue { <8 x ptr>, <8 x i64> } %1279, 1
  %1282 = extractelement <8 x ptr> %1280, i32 0
  %1283 = extractelement <8 x i64> %1281, i32 0
  %1284 = sub i64 %1283, 0
  %1285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1286 = select i1 %1285, i64 %1284, i64 0
  %private.contiguous.address578 = getelementptr i8, ptr %1282, i64 %1286
  %private.contiguous.preserve579 = load <8 x float>, ptr %private.contiguous.address578, align 4
  %1287 = select <8 x i1> %71, <8 x float> %1094, <8 x float> %private.contiguous.preserve579
  store <8 x float> %1287, ptr %private.contiguous.address578, align 4
  %1288 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1289 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1290 = add <8 x i64> %1289, splat (i64 448)
  %1291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1288, 0
  %1292 = insertvalue { <8 x ptr>, <8 x i64> } %1291, <8 x i64> %1290, 1
  %1293 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1294 = extractvalue { <8 x ptr>, <8 x i64> } %1292, 1
  %1295 = extractelement <8 x ptr> %1293, i32 0
  %1296 = extractelement <8 x i64> %1294, i32 0
  %1297 = sub i64 %1296, 0
  %1298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1299 = select i1 %1298, i64 %1297, i64 0
  %private.contiguous.address580 = getelementptr i8, ptr %1295, i64 %1299
  %private.contiguous.preserve581 = load <8 x float>, ptr %private.contiguous.address580, align 4
  %1300 = select <8 x i1> %71, <8 x float> %1095, <8 x float> %private.contiguous.preserve581
  store <8 x float> %1300, ptr %private.contiguous.address580, align 4
  %1301 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1302 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1303 = add <8 x i64> %1302, splat (i64 480)
  %1304 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1301, 0
  %1305 = insertvalue { <8 x ptr>, <8 x i64> } %1304, <8 x i64> %1303, 1
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1307 = extractvalue { <8 x ptr>, <8 x i64> } %1305, 1
  %1308 = extractelement <8 x ptr> %1306, i32 0
  %1309 = extractelement <8 x i64> %1307, i32 0
  %1310 = sub i64 %1309, 0
  %1311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1312 = select i1 %1311, i64 %1310, i64 0
  %private.contiguous.address582 = getelementptr i8, ptr %1308, i64 %1312
  %private.contiguous.preserve583 = load <8 x float>, ptr %private.contiguous.address582, align 4
  %1313 = select <8 x i1> %71, <8 x float> %1096, <8 x float> %private.contiguous.preserve583
  store <8 x float> %1313, ptr %private.contiguous.address582, align 4
  %.state584 = load <8 x float>, ptr %.slot36, align 32
  %1314 = fmul <8 x float> %.state584, %native.exp
  %1315 = load <8 x float>, ptr %.spill105, align 32
  %1316 = select <8 x i1> %71, <8 x float> %1314, <8 x float> %1315
  store <8 x float> %1316, ptr %.spill105, align 32
  store i64 0, ptr %.slot106, align 4
  %1317 = load <8 x float>, ptr %.slot107, align 32
  %1318 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1317
  store <8 x float> %1318, ptr %.slot107, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state585 = load i64, ptr %.slot106, align 4
  %1319 = icmp slt i64 %.state585, 16
  br i1 %1319, label %direct.true586, label %direct.false587

direct.schedule.35:                               ; preds = %direct.true586
  %.state588 = load i64, ptr %.slot106, align 4
  %1320 = sdiv i64 %.state588, 1
  %.spill.load589 = load i64, ptr %.spill66, align 4
  %1321 = mul i64 %.spill.load589, 1
  %1322 = add i64 %1321, 0
  %1323 = mul i64 %1322, 1
  %1324 = add i64 %1323, 0
  %1325 = mul i64 %1324, 16
  %1326 = add i64 %1325, %1320
  %tile_snapshot.spill.load590 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %1327 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load590, 0
  %1328 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load590, 1
  %.splatinsert591 = insertelement <8 x i64> poison, i64 %1326, i64 0
  %.splat592 = shufflevector <8 x i64> %.splatinsert591, <8 x i64> poison, <8 x i32> zeroinitializer
  %1329 = mul <8 x i64> %.splat592, splat (i64 32)
  %1330 = add <8 x i64> %1328, %1329
  %1331 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1327, 0
  %1332 = insertvalue { <8 x ptr>, <8 x i64> } %1331, <8 x i64> %1330, 1
  %1333 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1334 = extractvalue { <8 x ptr>, <8 x i64> } %1332, 1
  %1335 = extractelement <8 x ptr> %1333, i32 0
  %1336 = extractelement <8 x i64> %1334, i32 0
  %1337 = sub i64 %1336, 0
  %1338 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1339 = select i1 %1338, i64 %1337, i64 0
  %private.contiguous.address593 = getelementptr i8, ptr %1335, i64 %1339
  %private.contiguous.load594 = load <8 x float>, ptr %private.contiguous.address593, align 4
  %1340 = select <8 x i1> %71, <8 x float> %private.contiguous.load594, <8 x float> zeroinitializer
  %.state595 = load <8 x float>, ptr %.slot107, align 32
  %1341 = fadd <8 x float> %.state595, %1340
  %.state596 = load i64, ptr %.slot106, align 4
  %1342 = add i64 %.state596, 1
  store i64 %1342, ptr %.slot106, align 4
  %1343 = load <8 x float>, ptr %.slot107, align 32
  %1344 = select <8 x i1> %71, <8 x float> %1341, <8 x float> %1343
  store <8 x float> %1344, ptr %.slot107, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false587
  %.spill.load597 = load <8 x float>, ptr %.spill105, align 32
  %.state598 = load <8 x float>, ptr %.slot107, align 32
  %1345 = fadd <8 x float> %.spill.load597, %.state598
  %1346 = load <8 x float>, ptr %.spill108, align 32
  %1347 = select <8 x i1> %71, <8 x float> %1345, <8 x float> %1346
  store <8 x float> %1347, ptr %.spill108, align 32
  %1348 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill109, align 64
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %1348, 0
  %1351 = select <8 x i1> %71, <8 x ptr> %1349, <8 x ptr> %1350
  %1352 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1353 = extractvalue { <8 x ptr>, <8 x i64> } %1348, 1
  %1354 = select <8 x i1> %71, <8 x i64> %1352, <8 x i64> %1353
  %1355 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1351, 0
  %1356 = insertvalue { <8 x ptr>, <8 x i64> } %1355, <8 x i64> %1354, 1
  store { <8 x ptr>, <8 x i64> } %1356, ptr %tile_snapshot.spill109, align 64
  store i64 0, ptr %.slot110, align 4
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.41, %direct.schedule.36
  %.state599 = load i64, ptr %.slot110, align 4
  %1357 = icmp slt i64 %.state599, 24
  br i1 %1357, label %direct.true600, label %direct.false601

direct.schedule.38:                               ; preds = %direct.true600
  %.state602 = load i64, ptr %.slot110, align 4
  %1358 = mul i64 %.state602, 4
  %1359 = add i64 0, %1358
  %1360 = add i64 %1359, 0
  store i64 %1360, ptr %.spill111, align 4
  %1361 = add i64 0, %1360
  %tile_snapshot.spill.load603 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1362 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load603, 0
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load603, 1
  %.splatinsert604 = insertelement <8 x i64> poison, i64 %1361, i64 0
  %.splat605 = shufflevector <8 x i64> %.splatinsert604, <8 x i64> poison, <8 x i32> zeroinitializer
  %1364 = mul <8 x i64> %.splat605, splat (i64 32)
  %1365 = add <8 x i64> %1363, %1364
  %1366 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1362, 0
  %1367 = insertvalue { <8 x ptr>, <8 x i64> } %1366, <8 x i64> %1365, 1
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %1367, 1
  %1370 = extractelement <8 x ptr> %1368, i32 0
  %1371 = extractelement <8 x i64> %1369, i32 0
  %1372 = sub i64 %1371, 0
  %1373 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1374 = select i1 %1373, i64 %1372, i64 0
  %private.contiguous.address606 = getelementptr i8, ptr %1370, i64 %1374
  %private.contiguous.load607 = load <8 x float>, ptr %private.contiguous.address606, align 4
  %1375 = select <8 x i1> %71, <8 x float> %private.contiguous.load607, <8 x float> zeroinitializer
  %.spill.load608 = load <8 x float>, ptr %.spill103, align 32
  %1376 = fmul <8 x float> %1375, %.spill.load608
  %1377 = add i64 %1359, 1
  store i64 %1377, ptr %.spill112, align 4
  %1378 = add i64 0, %1377
  %tile_snapshot.spill.load609 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1379 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load609, 0
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load609, 1
  %.splatinsert610 = insertelement <8 x i64> poison, i64 %1378, i64 0
  %.splat611 = shufflevector <8 x i64> %.splatinsert610, <8 x i64> poison, <8 x i32> zeroinitializer
  %1381 = mul <8 x i64> %.splat611, splat (i64 32)
  %1382 = add <8 x i64> %1380, %1381
  %1383 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1379, 0
  %1384 = insertvalue { <8 x ptr>, <8 x i64> } %1383, <8 x i64> %1382, 1
  %1385 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %1384, 1
  %1387 = extractelement <8 x ptr> %1385, i32 0
  %1388 = extractelement <8 x i64> %1386, i32 0
  %1389 = sub i64 %1388, 0
  %1390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1391 = select i1 %1390, i64 %1389, i64 0
  %private.contiguous.address612 = getelementptr i8, ptr %1387, i64 %1391
  %private.contiguous.load613 = load <8 x float>, ptr %private.contiguous.address612, align 4
  %1392 = select <8 x i1> %71, <8 x float> %private.contiguous.load613, <8 x float> zeroinitializer
  %.spill.load614 = load <8 x float>, ptr %.spill103, align 32
  %1393 = fmul <8 x float> %1392, %.spill.load614
  %1394 = add i64 %1359, 2
  store i64 %1394, ptr %.spill113, align 4
  %1395 = add i64 0, %1394
  %tile_snapshot.spill.load615 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load615, 0
  %1397 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load615, 1
  %.splatinsert616 = insertelement <8 x i64> poison, i64 %1395, i64 0
  %.splat617 = shufflevector <8 x i64> %.splatinsert616, <8 x i64> poison, <8 x i32> zeroinitializer
  %1398 = mul <8 x i64> %.splat617, splat (i64 32)
  %1399 = add <8 x i64> %1397, %1398
  %1400 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1396, 0
  %1401 = insertvalue { <8 x ptr>, <8 x i64> } %1400, <8 x i64> %1399, 1
  %1402 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1403 = extractvalue { <8 x ptr>, <8 x i64> } %1401, 1
  %1404 = extractelement <8 x ptr> %1402, i32 0
  %1405 = extractelement <8 x i64> %1403, i32 0
  %1406 = sub i64 %1405, 0
  %1407 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1408 = select i1 %1407, i64 %1406, i64 0
  %private.contiguous.address618 = getelementptr i8, ptr %1404, i64 %1408
  %private.contiguous.load619 = load <8 x float>, ptr %private.contiguous.address618, align 4
  %1409 = select <8 x i1> %71, <8 x float> %private.contiguous.load619, <8 x float> zeroinitializer
  %.spill.load620 = load <8 x float>, ptr %.spill103, align 32
  %1410 = fmul <8 x float> %1409, %.spill.load620
  %1411 = add i64 %1359, 3
  store i64 %1411, ptr %.spill114, align 4
  %1412 = add i64 0, %1411
  %tile_snapshot.spill.load621 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1413 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load621, 0
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load621, 1
  %.splatinsert622 = insertelement <8 x i64> poison, i64 %1412, i64 0
  %.splat623 = shufflevector <8 x i64> %.splatinsert622, <8 x i64> poison, <8 x i32> zeroinitializer
  %1415 = mul <8 x i64> %.splat623, splat (i64 32)
  %1416 = add <8 x i64> %1414, %1415
  %1417 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1413, 0
  %1418 = insertvalue { <8 x ptr>, <8 x i64> } %1417, <8 x i64> %1416, 1
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %1418, 1
  %1421 = extractelement <8 x ptr> %1419, i32 0
  %1422 = extractelement <8 x i64> %1420, i32 0
  %1423 = sub i64 %1422, 0
  %1424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1425 = select i1 %1424, i64 %1423, i64 0
  %private.contiguous.address624 = getelementptr i8, ptr %1421, i64 %1425
  %private.contiguous.load625 = load <8 x float>, ptr %private.contiguous.address624, align 4
  %1426 = select <8 x i1> %71, <8 x float> %private.contiguous.load625, <8 x float> zeroinitializer
  %.spill.load626 = load <8 x float>, ptr %.spill103, align 32
  %1427 = fmul <8 x float> %1426, %.spill.load626
  store i64 0, ptr %.slot115, align 4
  %1428 = load <8 x float>, ptr %.slot116, align 32
  %1429 = select <8 x i1> %71, <8 x float> %1376, <8 x float> %1428
  store <8 x float> %1429, ptr %.slot116, align 32
  %1430 = load <8 x float>, ptr %.slot117, align 32
  %1431 = select <8 x i1> %71, <8 x float> %1393, <8 x float> %1430
  store <8 x float> %1431, ptr %.slot117, align 32
  %1432 = load <8 x float>, ptr %.slot118, align 32
  %1433 = select <8 x i1> %71, <8 x float> %1410, <8 x float> %1432
  store <8 x float> %1433, ptr %.slot118, align 32
  %1434 = load <8 x float>, ptr %.slot119, align 32
  %1435 = select <8 x i1> %71, <8 x float> %1427, <8 x float> %1434
  store <8 x float> %1435, ptr %.slot119, align 32
  br label %direct.schedule.39

direct.schedule.39:                               ; preds = %direct.schedule.40, %direct.schedule.38
  %.state627 = load i64, ptr %.slot115, align 4
  %1436 = icmp slt i64 %.state627, 16
  br i1 %1436, label %direct.true628, label %direct.false629

direct.schedule.40:                               ; preds = %direct.true628
  %.state630 = load i64, ptr %.slot115, align 4
  %1437 = add i64 0, %.state630
  %tile_snapshot.spill.load631 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %1438 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load631, 0
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load631, 1
  %.splatinsert632 = insertelement <8 x i64> poison, i64 %1437, i64 0
  %.splat633 = shufflevector <8 x i64> %.splatinsert632, <8 x i64> poison, <8 x i32> zeroinitializer
  %1440 = mul <8 x i64> %.splat633, splat (i64 32)
  %1441 = add <8 x i64> %1439, %1440
  %1442 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1438, 0
  %1443 = insertvalue { <8 x ptr>, <8 x i64> } %1442, <8 x i64> %1441, 1
  %1444 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1445 = extractvalue { <8 x ptr>, <8 x i64> } %1443, 1
  %1446 = extractelement <8 x ptr> %1444, i32 0
  %1447 = extractelement <8 x i64> %1445, i32 0
  %1448 = sub i64 %1447, 0
  %1449 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1450 = select i1 %1449, i64 %1448, i64 0
  %private.contiguous.address634 = getelementptr i8, ptr %1446, i64 %1450
  %private.contiguous.load635 = load <8 x float>, ptr %private.contiguous.address634, align 4
  %1451 = select <8 x i1> %71, <8 x float> %private.contiguous.load635, <8 x float> zeroinitializer
  %1452 = mul i64 %1437, 96
  %.spill.load636 = load i64, ptr %.spill111, align 4
  %1453 = add i64 %1452, %.spill.load636
  %tile_snapshot.spill.load637 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load637, 0
  %1455 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load637, 1
  %.splatinsert638 = insertelement <8 x i64> poison, i64 %1453, i64 0
  %.splat639 = shufflevector <8 x i64> %.splatinsert638, <8 x i64> poison, <8 x i32> zeroinitializer
  %1456 = mul <8 x i64> %.splat639, splat (i64 32)
  %1457 = add <8 x i64> %1455, %1456
  %1458 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1454, 0
  %1459 = insertvalue { <8 x ptr>, <8 x i64> } %1458, <8 x i64> %1457, 1
  %1460 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1461 = extractvalue { <8 x ptr>, <8 x i64> } %1459, 1
  %1462 = extractelement <8 x ptr> %1460, i32 0
  %1463 = extractelement <8 x i64> %1461, i32 0
  %1464 = sub i64 %1463, 0
  %1465 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1466 = select i1 %1465, i64 %1464, i64 0
  %private.contiguous.address640 = getelementptr i8, ptr %1462, i64 %1466
  %private.contiguous.load641 = load <8 x float>, ptr %private.contiguous.address640, align 4
  %1467 = select <8 x i1> %71, <8 x float> %private.contiguous.load641, <8 x float> zeroinitializer
  %1468 = fmul <8 x float> %1451, %1467
  %.state642 = load <8 x float>, ptr %.slot116, align 32
  %1469 = fadd <8 x float> %.state642, %1468
  %.spill.load643 = load i64, ptr %.spill112, align 4
  %1470 = add i64 %1452, %.spill.load643
  %tile_snapshot.spill.load644 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load644, 0
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load644, 1
  %.splatinsert645 = insertelement <8 x i64> poison, i64 %1470, i64 0
  %.splat646 = shufflevector <8 x i64> %.splatinsert645, <8 x i64> poison, <8 x i32> zeroinitializer
  %1473 = mul <8 x i64> %.splat646, splat (i64 32)
  %1474 = add <8 x i64> %1472, %1473
  %1475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1471, 0
  %1476 = insertvalue { <8 x ptr>, <8 x i64> } %1475, <8 x i64> %1474, 1
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1478 = extractvalue { <8 x ptr>, <8 x i64> } %1476, 1
  %1479 = extractelement <8 x ptr> %1477, i32 0
  %1480 = extractelement <8 x i64> %1478, i32 0
  %1481 = sub i64 %1480, 0
  %1482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1483 = select i1 %1482, i64 %1481, i64 0
  %private.contiguous.address647 = getelementptr i8, ptr %1479, i64 %1483
  %private.contiguous.load648 = load <8 x float>, ptr %private.contiguous.address647, align 4
  %1484 = select <8 x i1> %71, <8 x float> %private.contiguous.load648, <8 x float> zeroinitializer
  %1485 = fmul <8 x float> %1451, %1484
  %.state649 = load <8 x float>, ptr %.slot117, align 32
  %1486 = fadd <8 x float> %.state649, %1485
  %.spill.load650 = load i64, ptr %.spill113, align 4
  %1487 = add i64 %1452, %.spill.load650
  %tile_snapshot.spill.load651 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1488 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load651, 0
  %1489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load651, 1
  %.splatinsert652 = insertelement <8 x i64> poison, i64 %1487, i64 0
  %.splat653 = shufflevector <8 x i64> %.splatinsert652, <8 x i64> poison, <8 x i32> zeroinitializer
  %1490 = mul <8 x i64> %.splat653, splat (i64 32)
  %1491 = add <8 x i64> %1489, %1490
  %1492 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1488, 0
  %1493 = insertvalue { <8 x ptr>, <8 x i64> } %1492, <8 x i64> %1491, 1
  %1494 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1495 = extractvalue { <8 x ptr>, <8 x i64> } %1493, 1
  %1496 = extractelement <8 x ptr> %1494, i32 0
  %1497 = extractelement <8 x i64> %1495, i32 0
  %1498 = sub i64 %1497, 0
  %1499 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1500 = select i1 %1499, i64 %1498, i64 0
  %private.contiguous.address654 = getelementptr i8, ptr %1496, i64 %1500
  %private.contiguous.load655 = load <8 x float>, ptr %private.contiguous.address654, align 4
  %1501 = select <8 x i1> %71, <8 x float> %private.contiguous.load655, <8 x float> zeroinitializer
  %1502 = fmul <8 x float> %1451, %1501
  %.state656 = load <8 x float>, ptr %.slot118, align 32
  %1503 = fadd <8 x float> %.state656, %1502
  %.spill.load657 = load i64, ptr %.spill114, align 4
  %1504 = add i64 %1452, %.spill.load657
  %tile_snapshot.spill.load658 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1505 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 0
  %1506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 1
  %.splatinsert659 = insertelement <8 x i64> poison, i64 %1504, i64 0
  %.splat660 = shufflevector <8 x i64> %.splatinsert659, <8 x i64> poison, <8 x i32> zeroinitializer
  %1507 = mul <8 x i64> %.splat660, splat (i64 32)
  %1508 = add <8 x i64> %1506, %1507
  %1509 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1505, 0
  %1510 = insertvalue { <8 x ptr>, <8 x i64> } %1509, <8 x i64> %1508, 1
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1512 = extractvalue { <8 x ptr>, <8 x i64> } %1510, 1
  %1513 = extractelement <8 x ptr> %1511, i32 0
  %1514 = extractelement <8 x i64> %1512, i32 0
  %1515 = sub i64 %1514, 0
  %1516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1517 = select i1 %1516, i64 %1515, i64 0
  %private.contiguous.address661 = getelementptr i8, ptr %1513, i64 %1517
  %private.contiguous.load662 = load <8 x float>, ptr %private.contiguous.address661, align 4
  %1518 = select <8 x i1> %71, <8 x float> %private.contiguous.load662, <8 x float> zeroinitializer
  %1519 = fmul <8 x float> %1451, %1518
  %.state663 = load <8 x float>, ptr %.slot119, align 32
  %1520 = fadd <8 x float> %.state663, %1519
  %.state664 = load i64, ptr %.slot115, align 4
  %1521 = add i64 %.state664, 1
  store i64 %1521, ptr %.slot115, align 4
  %1522 = load <8 x float>, ptr %.slot116, align 32
  %1523 = select <8 x i1> %71, <8 x float> %1469, <8 x float> %1522
  store <8 x float> %1523, ptr %.slot116, align 32
  %1524 = load <8 x float>, ptr %.slot117, align 32
  %1525 = select <8 x i1> %71, <8 x float> %1486, <8 x float> %1524
  store <8 x float> %1525, ptr %.slot117, align 32
  %1526 = load <8 x float>, ptr %.slot118, align 32
  %1527 = select <8 x i1> %71, <8 x float> %1503, <8 x float> %1526
  store <8 x float> %1527, ptr %.slot118, align 32
  %1528 = load <8 x float>, ptr %.slot119, align 32
  %1529 = select <8 x i1> %71, <8 x float> %1520, <8 x float> %1528
  store <8 x float> %1529, ptr %.slot119, align 32
  br label %direct.schedule.39

direct.schedule.41:                               ; preds = %direct.false629
  %tile_snapshot.spill.load665 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill109, align 64
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load665, 0
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load665, 1
  %.spill.load666 = load i64, ptr %.spill111, align 4
  %.splatinsert667 = insertelement <8 x i64> poison, i64 %.spill.load666, i64 0
  %.splat668 = shufflevector <8 x i64> %.splatinsert667, <8 x i64> poison, <8 x i32> zeroinitializer
  %1532 = mul <8 x i64> %.splat668, splat (i64 32)
  %1533 = add <8 x i64> %1531, %1532
  %1534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1530, 0
  %1535 = insertvalue { <8 x ptr>, <8 x i64> } %1534, <8 x i64> %1533, 1
  %.state669 = load <8 x float>, ptr %.slot116, align 32
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %1535, 1
  %1538 = extractelement <8 x ptr> %1536, i32 0
  %1539 = extractelement <8 x i64> %1537, i32 0
  %1540 = sub i64 %1539, 0
  %1541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1542 = select i1 %1541, i64 %1540, i64 0
  %private.contiguous.address670 = getelementptr i8, ptr %1538, i64 %1542
  %private.contiguous.preserve671 = load <8 x float>, ptr %private.contiguous.address670, align 4
  %1543 = select <8 x i1> %71, <8 x float> %.state669, <8 x float> %private.contiguous.preserve671
  store <8 x float> %1543, ptr %private.contiguous.address670, align 4
  %tile_snapshot.spill.load672 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill109, align 64
  %1544 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load672, 0
  %1545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load672, 1
  %.spill.load673 = load i64, ptr %.spill112, align 4
  %.splatinsert674 = insertelement <8 x i64> poison, i64 %.spill.load673, i64 0
  %.splat675 = shufflevector <8 x i64> %.splatinsert674, <8 x i64> poison, <8 x i32> zeroinitializer
  %1546 = mul <8 x i64> %.splat675, splat (i64 32)
  %1547 = add <8 x i64> %1545, %1546
  %1548 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1544, 0
  %1549 = insertvalue { <8 x ptr>, <8 x i64> } %1548, <8 x i64> %1547, 1
  %.state676 = load <8 x float>, ptr %.slot117, align 32
  %1550 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1551 = extractvalue { <8 x ptr>, <8 x i64> } %1549, 1
  %1552 = extractelement <8 x ptr> %1550, i32 0
  %1553 = extractelement <8 x i64> %1551, i32 0
  %1554 = sub i64 %1553, 0
  %1555 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1556 = select i1 %1555, i64 %1554, i64 0
  %private.contiguous.address677 = getelementptr i8, ptr %1552, i64 %1556
  %private.contiguous.preserve678 = load <8 x float>, ptr %private.contiguous.address677, align 4
  %1557 = select <8 x i1> %71, <8 x float> %.state676, <8 x float> %private.contiguous.preserve678
  store <8 x float> %1557, ptr %private.contiguous.address677, align 4
  %tile_snapshot.spill.load679 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill109, align 64
  %1558 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load679, 0
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load679, 1
  %.spill.load680 = load i64, ptr %.spill113, align 4
  %.splatinsert681 = insertelement <8 x i64> poison, i64 %.spill.load680, i64 0
  %.splat682 = shufflevector <8 x i64> %.splatinsert681, <8 x i64> poison, <8 x i32> zeroinitializer
  %1560 = mul <8 x i64> %.splat682, splat (i64 32)
  %1561 = add <8 x i64> %1559, %1560
  %1562 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1558, 0
  %1563 = insertvalue { <8 x ptr>, <8 x i64> } %1562, <8 x i64> %1561, 1
  %.state683 = load <8 x float>, ptr %.slot118, align 32
  %1564 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1565 = extractvalue { <8 x ptr>, <8 x i64> } %1563, 1
  %1566 = extractelement <8 x ptr> %1564, i32 0
  %1567 = extractelement <8 x i64> %1565, i32 0
  %1568 = sub i64 %1567, 0
  %1569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1570 = select i1 %1569, i64 %1568, i64 0
  %private.contiguous.address684 = getelementptr i8, ptr %1566, i64 %1570
  %private.contiguous.preserve685 = load <8 x float>, ptr %private.contiguous.address684, align 4
  %1571 = select <8 x i1> %71, <8 x float> %.state683, <8 x float> %private.contiguous.preserve685
  store <8 x float> %1571, ptr %private.contiguous.address684, align 4
  %tile_snapshot.spill.load686 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill109, align 64
  %1572 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load686, 0
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load686, 1
  %.spill.load687 = load i64, ptr %.spill114, align 4
  %.splatinsert688 = insertelement <8 x i64> poison, i64 %.spill.load687, i64 0
  %.splat689 = shufflevector <8 x i64> %.splatinsert688, <8 x i64> poison, <8 x i32> zeroinitializer
  %1574 = mul <8 x i64> %.splat689, splat (i64 32)
  %1575 = add <8 x i64> %1573, %1574
  %1576 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1572, 0
  %1577 = insertvalue { <8 x ptr>, <8 x i64> } %1576, <8 x i64> %1575, 1
  %.state690 = load <8 x float>, ptr %.slot119, align 32
  %1578 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1579 = extractvalue { <8 x ptr>, <8 x i64> } %1577, 1
  %1580 = extractelement <8 x ptr> %1578, i32 0
  %1581 = extractelement <8 x i64> %1579, i32 0
  %1582 = sub i64 %1581, 0
  %1583 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1584 = select i1 %1583, i64 %1582, i64 0
  %private.contiguous.address691 = getelementptr i8, ptr %1580, i64 %1584
  %private.contiguous.preserve692 = load <8 x float>, ptr %private.contiguous.address691, align 4
  %1585 = select <8 x i1> %71, <8 x float> %.state690, <8 x float> %private.contiguous.preserve692
  store <8 x float> %1585, ptr %private.contiguous.address691, align 4
  %.state693 = load i64, ptr %.slot110, align 4
  %1586 = add i64 %.state693, 1
  store i64 %1586, ptr %.slot110, align 4
  br label %direct.schedule.37

direct.schedule.42:                               ; preds = %direct.false601
  store i64 0, ptr %.slot120, align 4
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state694 = load i64, ptr %.slot120, align 4
  %1587 = icmp slt i64 %.state694, 96
  br i1 %1587, label %direct.true695, label %direct.false696

direct.schedule.44:                               ; preds = %direct.true695
  %tile_snapshot.spill.load697 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill109, align 64
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load697, 0
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load697, 1
  %.state698 = load i64, ptr %.slot120, align 4
  %.splatinsert699 = insertelement <8 x i64> poison, i64 %.state698, i64 0
  %.splat700 = shufflevector <8 x i64> %.splatinsert699, <8 x i64> poison, <8 x i32> zeroinitializer
  %1590 = mul <8 x i64> %.splat700, splat (i64 32)
  %1591 = add <8 x i64> %1589, %1590
  %1592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1588, 0
  %1593 = insertvalue { <8 x ptr>, <8 x i64> } %1592, <8 x i64> %1591, 1
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1595 = extractvalue { <8 x ptr>, <8 x i64> } %1593, 1
  %1596 = extractelement <8 x ptr> %1594, i32 0
  %1597 = extractelement <8 x i64> %1595, i32 0
  %1598 = sub i64 %1597, 0
  %1599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1600 = select i1 %1599, i64 %1598, i64 0
  %private.contiguous.address701 = getelementptr i8, ptr %1596, i64 %1600
  %private.contiguous.load702 = load <8 x float>, ptr %private.contiguous.address701, align 4
  %1601 = select <8 x i1> %71, <8 x float> %private.contiguous.load702, <8 x float> zeroinitializer
  %tile_snapshot.spill.load703 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1602 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 0
  %1603 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 1
  %.state704 = load i64, ptr %.slot120, align 4
  %.splatinsert705 = insertelement <8 x i64> poison, i64 %.state704, i64 0
  %.splat706 = shufflevector <8 x i64> %.splatinsert705, <8 x i64> poison, <8 x i32> zeroinitializer
  %1604 = mul <8 x i64> %.splat706, splat (i64 32)
  %1605 = add <8 x i64> %1603, %1604
  %1606 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1602, 0
  %1607 = insertvalue { <8 x ptr>, <8 x i64> } %1606, <8 x i64> %1605, 1
  %1608 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1609 = extractvalue { <8 x ptr>, <8 x i64> } %1607, 1
  %1610 = extractelement <8 x ptr> %1608, i32 0
  %1611 = extractelement <8 x i64> %1609, i32 0
  %1612 = sub i64 %1611, 0
  %1613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1614 = select i1 %1613, i64 %1612, i64 0
  %private.contiguous.address707 = getelementptr i8, ptr %1610, i64 %1614
  %private.contiguous.preserve708 = load <8 x float>, ptr %private.contiguous.address707, align 4
  %1615 = select <8 x i1> %71, <8 x float> %1601, <8 x float> %private.contiguous.preserve708
  store <8 x float> %1615, ptr %private.contiguous.address707, align 4
  %.state709 = load i64, ptr %.slot120, align 4
  %1616 = add i64 %.state709, 1
  store i64 %1616, ptr %.slot120, align 4
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false696
  store i64 0, ptr %.slot121, align 4
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state710 = load i64, ptr %.slot121, align 4
  %1617 = icmp slt i64 %.state710, 96
  br i1 %1617, label %direct.true711, label %direct.false712

direct.schedule.47:                               ; preds = %direct.true711
  %tile_snapshot.spill.load713 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load713, 0
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load713, 1
  %.state714 = load i64, ptr %.slot121, align 4
  %.splatinsert715 = insertelement <8 x i64> poison, i64 %.state714, i64 0
  %.splat716 = shufflevector <8 x i64> %.splatinsert715, <8 x i64> poison, <8 x i32> zeroinitializer
  %1620 = mul <8 x i64> %.splat716, splat (i64 32)
  %1621 = add <8 x i64> %1619, %1620
  %1622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1618, 0
  %1623 = insertvalue { <8 x ptr>, <8 x i64> } %1622, <8 x i64> %1621, 1
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1625 = extractvalue { <8 x ptr>, <8 x i64> } %1623, 1
  %1626 = extractelement <8 x ptr> %1624, i32 0
  %1627 = extractelement <8 x i64> %1625, i32 0
  %1628 = sub i64 %1627, 0
  %1629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1630 = select i1 %1629, i64 %1628, i64 0
  %private.contiguous.address717 = getelementptr i8, ptr %1626, i64 %1630
  %private.contiguous.load718 = load <8 x float>, ptr %private.contiguous.address717, align 4
  %1631 = select <8 x i1> %71, <8 x float> %private.contiguous.load718, <8 x float> zeroinitializer
  %tile_snapshot.spill.load719 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load719, 0
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load719, 1
  %.state720 = load i64, ptr %.slot121, align 4
  %.splatinsert721 = insertelement <8 x i64> poison, i64 %.state720, i64 0
  %.splat722 = shufflevector <8 x i64> %.splatinsert721, <8 x i64> poison, <8 x i32> zeroinitializer
  %1634 = mul <8 x i64> %.splat722, splat (i64 32)
  %1635 = add <8 x i64> %1633, %1634
  %1636 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1632, 0
  %1637 = insertvalue { <8 x ptr>, <8 x i64> } %1636, <8 x i64> %1635, 1
  %1638 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1639 = extractvalue { <8 x ptr>, <8 x i64> } %1637, 1
  %1640 = extractelement <8 x ptr> %1638, i32 0
  %1641 = extractelement <8 x i64> %1639, i32 0
  %1642 = sub i64 %1641, 0
  %1643 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1644 = select i1 %1643, i64 %1642, i64 0
  %private.contiguous.address723 = getelementptr i8, ptr %1640, i64 %1644
  %private.contiguous.preserve724 = load <8 x float>, ptr %private.contiguous.address723, align 4
  %1645 = select <8 x i1> %71, <8 x float> %1631, <8 x float> %private.contiguous.preserve724
  store <8 x float> %1645, ptr %private.contiguous.address723, align 4
  %.state725 = load i64, ptr %.slot121, align 4
  %1646 = add i64 %.state725, 1
  store i64 %1646, ptr %.slot121, align 4
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false712
  %.state726 = load i64, ptr %.slot34, align 4
  %1647 = add i64 %.state726, 1
  %.spill.load727 = load <8 x float>, ptr %.spill102, align 32
  %.spill.load728 = load <8 x float>, ptr %.spill108, align 32
  store i64 %1647, ptr %.slot34, align 4
  %1648 = load <8 x float>, ptr %.slot35, align 32
  %1649 = select <8 x i1> %71, <8 x float> %.spill.load727, <8 x float> %1648
  store <8 x float> %1649, ptr %.slot35, align 32
  %1650 = load <8 x float>, ptr %.slot36, align 32
  %1651 = select <8 x i1> %71, <8 x float> %.spill.load728, <8 x float> %1650
  store <8 x float> %1651, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.49:                               ; preds = %direct.false158
  store i64 0, ptr %.slot122, align 4
  br label %direct.schedule.50

direct.schedule.50:                               ; preds = %direct.schedule.51, %direct.schedule.49
  %.state729 = load i64, ptr %.slot122, align 4
  %1652 = icmp slt i64 %.state729, 96
  br i1 %1652, label %direct.true730, label %direct.false731

direct.schedule.51:                               ; preds = %direct.true730
  %.spill.load732 = load i64, ptr %.spill29, align 4
  %1653 = add i64 %.spill.load732, 0
  %.spill.load733 = load <8 x i64>, ptr %.spill, align 64
  %1654 = add <8 x i64> %.spill.load733, zeroinitializer
  %1655 = mul i64 %1653, 8
  %.splatinsert734 = insertelement <8 x i64> poison, i64 %1655, i64 0
  %.splat735 = shufflevector <8 x i64> %.splatinsert734, <8 x i64> poison, <8 x i32> zeroinitializer
  %1656 = add <8 x i64> %.splat735, %1654
  %.spill.load736 = load i64, ptr %.spill29, align 4
  %1657 = add i64 %.spill.load736, 0
  %1658 = mul <8 x i64> %1656, splat (i64 1)
  %.splatinsert737 = insertelement <8 x i64> poison, i64 %1657, i64 0
  %.splat738 = shufflevector <8 x i64> %.splatinsert737, <8 x i64> poison, <8 x i32> zeroinitializer
  %1659 = add <8 x i64> %1658, %.splat738
  %.state739 = load i64, ptr %.slot122, align 4
  %1660 = add i64 0, %.state739
  %1661 = mul <8 x i64> %1659, splat (i64 96)
  %.splatinsert740 = insertelement <8 x i64> poison, i64 %1660, i64 0
  %.splat741 = shufflevector <8 x i64> %.splatinsert740, <8 x i64> poison, <8 x i32> zeroinitializer
  %1662 = add <8 x i64> %1661, %.splat741
  %.state742 = load i64, ptr %.slot122, align 4
  %1663 = add i64 0, %.state742
  %tile_snapshot.spill.load743 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load743, 0
  %1665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load743, 1
  %.splatinsert744 = insertelement <8 x i64> poison, i64 %1663, i64 0
  %.splat745 = shufflevector <8 x i64> %.splatinsert744, <8 x i64> poison, <8 x i32> zeroinitializer
  %1666 = mul <8 x i64> %.splat745, splat (i64 32)
  %1667 = add <8 x i64> %1665, %1666
  %1668 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1664, 0
  %1669 = insertvalue { <8 x ptr>, <8 x i64> } %1668, <8 x i64> %1667, 1
  %1670 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1671 = extractvalue { <8 x ptr>, <8 x i64> } %1669, 1
  %1672 = extractelement <8 x ptr> %1670, i32 0
  %1673 = extractelement <8 x i64> %1671, i32 0
  %1674 = sub i64 %1673, 0
  %1675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1676 = select i1 %1675, i64 %1674, i64 0
  %private.contiguous.address746 = getelementptr i8, ptr %1672, i64 %1676
  %private.contiguous.load747 = load <8 x float>, ptr %private.contiguous.address746, align 4
  %1677 = select <8 x i1> %71, <8 x float> %private.contiguous.load747, <8 x float> zeroinitializer
  %.state748 = load <8 x float>, ptr %.slot36, align 32
  %1678 = fdiv <8 x float> %1677, %.state748
  %1679 = extractvalue { ptr, i64 } %47, 0
  %1680 = mul <8 x i64> %1662, splat (i64 4)
  %1681 = getelementptr i8, ptr %1679, <8 x i64> %1680
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1678, <8 x ptr> align 1 %1681, <8 x i1> %71)
  %.state749 = load i64, ptr %.slot122, align 4
  %1682 = add i64 %.state749, 1
  store i64 %1682, ptr %.slot122, align 4
  br label %direct.schedule.50

direct.schedule.52:                               ; preds = %direct.false731
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true147:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false148:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true157:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false158:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.49

direct.true161:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false162:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true174:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false175:                                  ; preds = %direct.schedule.10
  %1683 = load <8 x float>, ptr %.slot41, align 32
  %1684 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1683
  store <8 x float> %1684, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.true186:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false187:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true199:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false200:                                  ; preds = %direct.schedule.15
  %1685 = load <8 x float>, ptr %.slot45, align 32
  %1686 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1685
  store <8 x float> %1686, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.true211:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false212:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true247:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false248:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true285:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false286:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true323:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false324:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true458:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false459:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true586:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false587:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true600:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false601:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.42

direct.true628:                                   ; preds = %direct.schedule.39
  br label %direct.schedule.40

direct.false629:                                  ; preds = %direct.schedule.39
  br label %direct.schedule.41

direct.true695:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false696:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true711:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false712:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true730:                                   ; preds = %direct.schedule.50
  br label %direct.schedule.51

direct.false731:                                  ; preds = %direct.schedule.50
  br label %direct.schedule.52
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #3 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #4

define internal void @llm_attention.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill31, align 64
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca i64, align 8
  store i64 0, ptr %.slot33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %tile_snapshot.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill42, align 64
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %.spill44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill44, align 64
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca i64, align 8
  store i64 0, ptr %.slot51, align 4
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot54, align 32
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot60, align 32
  %.slot61 = alloca i64, align 8
  store i64 0, ptr %.slot61, align 4
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.spill66 = alloca i64, align 8
  store i64 0, ptr %.spill66, align 4
  %.spill67 = alloca i1, align 1
  store i1 false, ptr %.spill67, align 1
  %.spill68 = alloca i1, align 1
  store i1 false, ptr %.spill68, align 1
  %.spill69 = alloca i1, align 1
  store i1 false, ptr %.spill69, align 1
  %.spill70 = alloca i1, align 1
  store i1 false, ptr %.spill70, align 1
  %.spill71 = alloca i1, align 1
  store i1 false, ptr %.spill71, align 1
  %.spill72 = alloca i1, align 1
  store i1 false, ptr %.spill72, align 1
  %.spill73 = alloca i1, align 1
  store i1 false, ptr %.spill73, align 1
  %.spill74 = alloca i1, align 1
  store i1 false, ptr %.spill74, align 1
  %.spill75 = alloca i1, align 1
  store i1 false, ptr %.spill75, align 1
  %.spill76 = alloca i1, align 1
  store i1 false, ptr %.spill76, align 1
  %.spill77 = alloca i1, align 1
  store i1 false, ptr %.spill77, align 1
  %.spill78 = alloca i1, align 1
  store i1 false, ptr %.spill78, align 1
  %.spill79 = alloca i1, align 1
  store i1 false, ptr %.spill79, align 1
  %.spill80 = alloca i1, align 1
  store i1 false, ptr %.spill80, align 1
  %.spill81 = alloca i1, align 1
  store i1 false, ptr %.spill81, align 1
  %.spill82 = alloca i1, align 1
  store i1 false, ptr %.spill82, align 1
  %.spill83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill83, align 32
  %.spill84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill84, align 32
  %.spill85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill85, align 32
  %.spill86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill86, align 32
  %.spill87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill87, align 32
  %.spill88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill88, align 32
  %.spill89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill89, align 32
  %.spill90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill90, align 32
  %.spill91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill91, align 32
  %.spill92 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill92, align 32
  %.spill93 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill93, align 32
  %.spill94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill94, align 32
  %.spill95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %tile_snapshot.spill99 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill99, align 64
  %.slot100 = alloca i64, align 8
  store i64 0, ptr %.slot100, align 4
  %.slot101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill103, align 32
  %tile_snapshot.spill104 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill104, align 64
  %.spill105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.slot106 = alloca i64, align 8
  store i64 0, ptr %.slot106, align 4
  %.slot107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill108, align 32
  %tile_snapshot.spill109 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill109, align 64
  %.slot110 = alloca i64, align 8
  store i64 0, ptr %.slot110, align 4
  %.spill111 = alloca i64, align 8
  store i64 0, ptr %.spill111, align 4
  %.spill112 = alloca i64, align 8
  store i64 0, ptr %.spill112, align 4
  %.spill113 = alloca i64, align 8
  store i64 0, ptr %.spill113, align 4
  %.spill114 = alloca i64, align 8
  store i64 0, ptr %.spill114, align 4
  %.slot115 = alloca i64, align 8
  store i64 0, ptr %.slot115, align 4
  %.slot116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot116, align 32
  %.slot117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot117, align 32
  %.slot118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot118, align 32
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.slot120 = alloca i64, align 8
  store i64 0, ptr %.slot120, align 4
  %.slot121 = alloca i64, align 8
  store i64 0, ptr %.slot121, align 4
  %.slot122 = alloca i64, align 8
  store i64 0, ptr %.slot122, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert123 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat124 = shufflevector <8 x i32> %.splatinsert123, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat124, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert125 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat126 = shufflevector <8 x i32> %.splatinsert125, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat126, %61
  %64 = mul i32 %52, 1
  %.splatinsert127 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat128 = shufflevector <8 x i32> %.splatinsert127, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat128, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert129 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat130 = shufflevector <8 x i32> %.splatinsert129, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat130, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert131 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat132 = shufflevector <8 x i32> %.splatinsert131, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat132
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  store i64 0, ptr %.spill29, align 4
  %80 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = load <8 x i64>, ptr %.spill30, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill30, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %94 = icmp slt i64 %.state, 80
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load i64, ptr %.spill29, align 4
  %95 = add i64 %.spill.load, 0
  %.spill.load133 = load <8 x i64>, ptr %.spill, align 64
  %96 = add <8 x i64> %.spill.load133, zeroinitializer
  %97 = mul i64 %95, 8
  %.splatinsert134 = insertelement <8 x i64> poison, i64 %97, i64 0
  %.splat135 = shufflevector <8 x i64> %.splatinsert134, <8 x i64> poison, <8 x i32> zeroinitializer
  %98 = add <8 x i64> %.splat135, %96
  %.spill.load136 = load i64, ptr %.spill29, align 4
  %99 = add i64 %.spill.load136, 0
  %100 = mul <8 x i64> %98, splat (i64 1)
  %.splatinsert137 = insertelement <8 x i64> poison, i64 %99, i64 0
  %.splat138 = shufflevector <8 x i64> %.splatinsert137, <8 x i64> poison, <8 x i32> zeroinitializer
  %101 = add <8 x i64> %100, %.splat138
  %.state139 = load i64, ptr %.slot, align 4
  %102 = add i64 0, %.state139
  %103 = mul <8 x i64> %101, splat (i64 80)
  %.splatinsert140 = insertelement <8 x i64> poison, i64 %102, i64 0
  %.splat141 = shufflevector <8 x i64> %.splatinsert140, <8 x i64> poison, <8 x i32> zeroinitializer
  %104 = add <8 x i64> %103, %.splat141
  %105 = extractvalue { ptr, i64 } %29, 0
  %106 = mul <8 x i64> %104, splat (i64 4)
  %107 = getelementptr i8, ptr %105, <8 x i64> %106
  %108 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %107, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state142 = load i64, ptr %.slot, align 4
  %.splatinsert143 = insertelement <8 x i64> poison, i64 %.state142, i64 0
  %.splat144 = shufflevector <8 x i64> %.splatinsert143, <8 x i64> poison, <8 x i32> zeroinitializer
  %111 = mul <8 x i64> %.splat144, splat (i64 32)
  %112 = add <8 x i64> %110, %111
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %109, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %114, 1
  %117 = extractelement <8 x ptr> %115, i32 0
  %118 = extractelement <8 x i64> %116, i32 0
  %119 = sub i64 %118, 0
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %121 = select i1 %120, i64 %119, i64 0
  %private.contiguous.address = getelementptr i8, ptr %117, i64 %121
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %122 = select <8 x i1> %71, <8 x float> %108, <8 x float> %private.contiguous.preserve
  store <8 x float> %122, ptr %private.contiguous.address, align 4
  %.state145 = load i64, ptr %.slot, align 4
  %123 = add i64 %.state145, 1
  store i64 %123, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %71, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %71, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill31, align 64
  %133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 0
  %136 = select <8 x i1> %71, <8 x ptr> %134, <8 x ptr> %135
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %139 = select <8 x i1> %71, <8 x i64> %137, <8 x i64> %138
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  store { <8 x ptr>, <8 x i64> } %141, ptr %tile_snapshot.spill32, align 64
  store i64 0, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state146 = load i64, ptr %.slot33, align 4
  %142 = icmp slt i64 %.state146, 96
  br i1 %142, label %direct.true147, label %direct.false148

direct.schedule.5:                                ; preds = %direct.true147
  %tile_snapshot.spill.load149 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 1
  %.state150 = load i64, ptr %.slot33, align 4
  %.splatinsert151 = insertelement <8 x i64> poison, i64 %.state150, i64 0
  %.splat152 = shufflevector <8 x i64> %.splatinsert151, <8 x i64> poison, <8 x i32> zeroinitializer
  %145 = mul <8 x i64> %.splat152, splat (i64 32)
  %146 = add <8 x i64> %144, %145
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %143, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %148, 1
  %151 = extractelement <8 x ptr> %149, i32 0
  %152 = extractelement <8 x i64> %150, i32 0
  %153 = sub i64 %152, 0
  %154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %155 = select i1 %154, i64 %153, i64 0
  %private.contiguous.address153 = getelementptr i8, ptr %151, i64 %155
  %private.contiguous.preserve154 = load <8 x float>, ptr %private.contiguous.address153, align 4
  %156 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve154
  store <8 x float> %156, ptr %private.contiguous.address153, align 4
  %.state155 = load i64, ptr %.slot33, align 4
  %157 = add i64 %.state155, 1
  store i64 %157, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false148
  store i64 0, ptr %.slot34, align 4
  %158 = load <8 x float>, ptr %.slot35, align 32
  %159 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %158
  store <8 x float> %159, ptr %.slot35, align 32
  %160 = load <8 x float>, ptr %.slot36, align 32
  %161 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %160
  store <8 x float> %161, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.48, %direct.schedule.6
  %.state156 = load i64, ptr %.slot34, align 4
  %162 = icmp slt i64 %.state156, 129
  br i1 %162, label %direct.true157, label %direct.false158

direct.schedule.8:                                ; preds = %direct.true157
  %.state159 = load i64, ptr %.slot34, align 4
  %163 = sdiv i64 %.state159, 1
  %164 = mul i64 %163, 16
  store i64 %164, ptr %.spill37, align 4
  %165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %168 = select <8 x i1> %71, <8 x ptr> %166, <8 x ptr> %167
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %171 = select <8 x i1> %71, <8 x i64> %169, <8 x i64> %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  store { <8 x ptr>, <8 x i64> } %173, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state160 = load i64, ptr %.slot39, align 4
  %174 = icmp slt i64 %.state160, 1280
  br i1 %174, label %direct.true161, label %direct.false162

direct.schedule.10:                               ; preds = %direct.true161
  %.state163 = load i64, ptr %.slot39, align 4
  %175 = srem i64 %.state163, 80
  %.state164 = load i64, ptr %.slot39, align 4
  %176 = sdiv i64 %.state164, 80
  %.spill.load165 = load i64, ptr %.spill29, align 4
  %177 = add i64 %.spill.load165, 0
  %.spill.load166 = load <8 x i64>, ptr %.spill30, align 64
  %178 = add <8 x i64> %.spill.load166, zeroinitializer
  %179 = mul i64 %177, 2
  %.splatinsert167 = insertelement <8 x i64> poison, i64 %179, i64 0
  %.splat168 = shufflevector <8 x i64> %.splatinsert167, <8 x i64> poison, <8 x i32> zeroinitializer
  %180 = add <8 x i64> %.splat168, %178
  %.spill.load169 = load i64, ptr %.spill37, align 4
  %181 = add i64 %.spill.load169, %176
  %182 = mul <8 x i64> %180, splat (i64 2053)
  %.splatinsert170 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat171 = shufflevector <8 x i64> %.splatinsert170, <8 x i64> poison, <8 x i32> zeroinitializer
  %183 = add <8 x i64> %182, %.splat171
  %184 = icmp sge i64 %181, 0
  %185 = and i1 true, %184
  %186 = icmp slt i64 %181, 2053
  %187 = and i1 %185, %186
  %188 = add i64 0, %175
  %189 = mul <8 x i64> %183, splat (i64 80)
  %.splatinsert172 = insertelement <8 x i64> poison, i64 %188, i64 0
  %.splat173 = shufflevector <8 x i64> %.splatinsert172, <8 x i64> poison, <8 x i32> zeroinitializer
  %190 = add <8 x i64> %189, %.splat173
  %191 = load <8 x i64>, ptr %.spill40, align 64
  %192 = select <8 x i1> %71, <8 x i64> %190, <8 x i64> %191
  store <8 x i64> %192, ptr %.spill40, align 64
  br i1 %187, label %direct.true174, label %direct.false175

direct.schedule.11:                               ; preds = %direct.true174
  %.spill.load176 = load <8 x i64>, ptr %.spill40, align 64
  %193 = extractvalue { ptr, i64 } %35, 0
  %194 = mul <8 x i64> %.spill.load176, splat (i64 4)
  %195 = getelementptr i8, ptr %193, <8 x i64> %194
  %196 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %195, <8 x i1> %71, <8 x float> zeroinitializer)
  %197 = load <8 x float>, ptr %.slot41, align 32
  %198 = select <8 x i1> %71, <8 x float> %196, <8 x float> %197
  store <8 x float> %198, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.false175, %direct.schedule.11
  %tile_snapshot.spill.load177 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load177, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load177, 1
  %.state178 = load i64, ptr %.slot39, align 4
  %.splatinsert179 = insertelement <8 x i64> poison, i64 %.state178, i64 0
  %.splat180 = shufflevector <8 x i64> %.splatinsert179, <8 x i64> poison, <8 x i32> zeroinitializer
  %201 = mul <8 x i64> %.splat180, splat (i64 32)
  %202 = add <8 x i64> %200, %201
  %203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %199, 0
  %204 = insertvalue { <8 x ptr>, <8 x i64> } %203, <8 x i64> %202, 1
  %.state181 = load <8 x float>, ptr %.slot41, align 32
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %204, 1
  %207 = extractelement <8 x ptr> %205, i32 0
  %208 = extractelement <8 x i64> %206, i32 0
  %209 = sub i64 %208, 0
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %211 = select i1 %210, i64 %209, i64 0
  %private.contiguous.address182 = getelementptr i8, ptr %207, i64 %211
  %private.contiguous.preserve183 = load <8 x float>, ptr %private.contiguous.address182, align 4
  %212 = select <8 x i1> %71, <8 x float> %.state181, <8 x float> %private.contiguous.preserve183
  store <8 x float> %212, ptr %private.contiguous.address182, align 4
  %.state184 = load i64, ptr %.slot39, align 4
  %213 = add i64 %.state184, 1
  store i64 %213, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false162
  %214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %214, 0
  %217 = select <8 x i1> %71, <8 x ptr> %215, <8 x ptr> %216
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %214, 1
  %220 = select <8 x i1> %71, <8 x i64> %218, <8 x i64> %219
  %221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %222 = insertvalue { <8 x ptr>, <8 x i64> } %221, <8 x i64> %220, 1
  store { <8 x ptr>, <8 x i64> } %222, ptr %tile_snapshot.spill42, align 64
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state185 = load i64, ptr %.slot43, align 4
  %223 = icmp slt i64 %.state185, 1536
  br i1 %223, label %direct.true186, label %direct.false187

direct.schedule.15:                               ; preds = %direct.true186
  %.state188 = load i64, ptr %.slot43, align 4
  %224 = srem i64 %.state188, 96
  %.state189 = load i64, ptr %.slot43, align 4
  %225 = sdiv i64 %.state189, 96
  %.spill.load190 = load i64, ptr %.spill29, align 4
  %226 = add i64 %.spill.load190, 0
  %.spill.load191 = load <8 x i64>, ptr %.spill30, align 64
  %227 = add <8 x i64> %.spill.load191, zeroinitializer
  %228 = mul i64 %226, 2
  %.splatinsert192 = insertelement <8 x i64> poison, i64 %228, i64 0
  %.splat193 = shufflevector <8 x i64> %.splatinsert192, <8 x i64> poison, <8 x i32> zeroinitializer
  %229 = add <8 x i64> %.splat193, %227
  %.spill.load194 = load i64, ptr %.spill37, align 4
  %230 = add i64 %.spill.load194, %225
  %231 = mul <8 x i64> %229, splat (i64 2053)
  %.splatinsert195 = insertelement <8 x i64> poison, i64 %230, i64 0
  %.splat196 = shufflevector <8 x i64> %.splatinsert195, <8 x i64> poison, <8 x i32> zeroinitializer
  %232 = add <8 x i64> %231, %.splat196
  %233 = icmp sge i64 %230, 0
  %234 = and i1 true, %233
  %235 = icmp slt i64 %230, 2053
  %236 = and i1 %234, %235
  %237 = add i64 0, %224
  %238 = mul <8 x i64> %232, splat (i64 96)
  %.splatinsert197 = insertelement <8 x i64> poison, i64 %237, i64 0
  %.splat198 = shufflevector <8 x i64> %.splatinsert197, <8 x i64> poison, <8 x i32> zeroinitializer
  %239 = add <8 x i64> %238, %.splat198
  %240 = load <8 x i64>, ptr %.spill44, align 64
  %241 = select <8 x i1> %71, <8 x i64> %239, <8 x i64> %240
  store <8 x i64> %241, ptr %.spill44, align 64
  br i1 %236, label %direct.true199, label %direct.false200

direct.schedule.16:                               ; preds = %direct.true199
  %.spill.load201 = load <8 x i64>, ptr %.spill44, align 64
  %242 = extractvalue { ptr, i64 } %41, 0
  %243 = mul <8 x i64> %.spill.load201, splat (i64 4)
  %244 = getelementptr i8, ptr %242, <8 x i64> %243
  %245 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %244, <8 x i1> %71, <8 x float> zeroinitializer)
  %246 = load <8 x float>, ptr %.slot45, align 32
  %247 = select <8 x i1> %71, <8 x float> %245, <8 x float> %246
  store <8 x float> %247, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.false200, %direct.schedule.16
  %tile_snapshot.spill.load202 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load202, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load202, 1
  %.state203 = load i64, ptr %.slot43, align 4
  %.splatinsert204 = insertelement <8 x i64> poison, i64 %.state203, i64 0
  %.splat205 = shufflevector <8 x i64> %.splatinsert204, <8 x i64> poison, <8 x i32> zeroinitializer
  %250 = mul <8 x i64> %.splat205, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %.state206 = load <8 x float>, ptr %.slot45, align 32
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address207 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.preserve208 = load <8 x float>, ptr %private.contiguous.address207, align 4
  %261 = select <8 x i1> %71, <8 x float> %.state206, <8 x float> %private.contiguous.preserve208
  store <8 x float> %261, ptr %private.contiguous.address207, align 4
  %.state209 = load i64, ptr %.slot43, align 4
  %262 = add i64 %.state209, 1
  store i64 %262, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false187
  store i64 0, ptr %.slot46, align 4
  %263 = load <8 x float>, ptr %.slot47, align 32
  %264 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %263
  store <8 x float> %264, ptr %.slot47, align 32
  %265 = load <8 x float>, ptr %.slot48, align 32
  %266 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %265
  store <8 x float> %266, ptr %.slot48, align 32
  %267 = load <8 x float>, ptr %.slot49, align 32
  %268 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %267
  store <8 x float> %268, ptr %.slot49, align 32
  %269 = load <8 x float>, ptr %.slot50, align 32
  %270 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %269
  store <8 x float> %270, ptr %.slot50, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state210 = load i64, ptr %.slot46, align 4
  %271 = icmp slt i64 %.state210, 80
  br i1 %271, label %direct.true211, label %direct.false212

direct.schedule.20:                               ; preds = %direct.true211
  %.state213 = load i64, ptr %.slot46, align 4
  %272 = add i64 0, %.state213
  %tile_snapshot.spill.load214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 1
  %.splatinsert215 = insertelement <8 x i64> poison, i64 %272, i64 0
  %.splat216 = shufflevector <8 x i64> %.splatinsert215, <8 x i64> poison, <8 x i32> zeroinitializer
  %275 = mul <8 x i64> %.splat216, splat (i64 32)
  %276 = add <8 x i64> %274, %275
  %277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %273, 0
  %278 = insertvalue { <8 x ptr>, <8 x i64> } %277, <8 x i64> %276, 1
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %278, 1
  %281 = extractelement <8 x ptr> %279, i32 0
  %282 = extractelement <8 x i64> %280, i32 0
  %283 = sub i64 %282, 0
  %284 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %285 = select i1 %284, i64 %283, i64 0
  %private.contiguous.address217 = getelementptr i8, ptr %281, i64 %285
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address217, align 4
  %286 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 1
  %.splatinsert219 = insertelement <8 x i64> poison, i64 %272, i64 0
  %.splat220 = shufflevector <8 x i64> %.splatinsert219, <8 x i64> poison, <8 x i32> zeroinitializer
  %289 = mul <8 x i64> %.splat220, splat (i64 32)
  %290 = add <8 x i64> %288, %289
  %291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %287, 0
  %292 = insertvalue { <8 x ptr>, <8 x i64> } %291, <8 x i64> %290, 1
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %292, 1
  %295 = extractelement <8 x ptr> %293, i32 0
  %296 = extractelement <8 x i64> %294, i32 0
  %297 = sub i64 %296, 0
  %298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %299 = select i1 %298, i64 %297, i64 0
  %private.contiguous.address221 = getelementptr i8, ptr %295, i64 %299
  %private.contiguous.load222 = load <8 x float>, ptr %private.contiguous.address221, align 4
  %300 = select <8 x i1> %71, <8 x float> %private.contiguous.load222, <8 x float> zeroinitializer
  %301 = fmul <8 x float> %286, %300
  %.state223 = load <8 x float>, ptr %.slot47, align 32
  %302 = fadd <8 x float> %.state223, %301
  %.state224 = load i64, ptr %.slot46, align 4
  %303 = add i64 80, %.state224
  %tile_snapshot.spill.load225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 1
  %.splatinsert226 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat227 = shufflevector <8 x i64> %.splatinsert226, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat227, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address228 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load229 = load <8 x float>, ptr %private.contiguous.address228, align 4
  %317 = select <8 x i1> %71, <8 x float> %private.contiguous.load229, <8 x float> zeroinitializer
  %318 = fmul <8 x float> %286, %317
  %.state230 = load <8 x float>, ptr %.slot48, align 32
  %319 = fadd <8 x float> %.state230, %318
  %.state231 = load i64, ptr %.slot46, align 4
  %320 = add i64 160, %.state231
  %tile_snapshot.spill.load232 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 1
  %.splatinsert233 = insertelement <8 x i64> poison, i64 %320, i64 0
  %.splat234 = shufflevector <8 x i64> %.splatinsert233, <8 x i64> poison, <8 x i32> zeroinitializer
  %323 = mul <8 x i64> %.splat234, splat (i64 32)
  %324 = add <8 x i64> %322, %323
  %325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %321, 0
  %326 = insertvalue { <8 x ptr>, <8 x i64> } %325, <8 x i64> %324, 1
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %326, 1
  %329 = extractelement <8 x ptr> %327, i32 0
  %330 = extractelement <8 x i64> %328, i32 0
  %331 = sub i64 %330, 0
  %332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %333 = select i1 %332, i64 %331, i64 0
  %private.contiguous.address235 = getelementptr i8, ptr %329, i64 %333
  %private.contiguous.load236 = load <8 x float>, ptr %private.contiguous.address235, align 4
  %334 = select <8 x i1> %71, <8 x float> %private.contiguous.load236, <8 x float> zeroinitializer
  %335 = fmul <8 x float> %286, %334
  %.state237 = load <8 x float>, ptr %.slot49, align 32
  %336 = fadd <8 x float> %.state237, %335
  %.state238 = load i64, ptr %.slot46, align 4
  %337 = add i64 240, %.state238
  %tile_snapshot.spill.load239 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 1
  %.splatinsert240 = insertelement <8 x i64> poison, i64 %337, i64 0
  %.splat241 = shufflevector <8 x i64> %.splatinsert240, <8 x i64> poison, <8 x i32> zeroinitializer
  %340 = mul <8 x i64> %.splat241, splat (i64 32)
  %341 = add <8 x i64> %339, %340
  %342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %338, 0
  %343 = insertvalue { <8 x ptr>, <8 x i64> } %342, <8 x i64> %341, 1
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %343, 1
  %346 = extractelement <8 x ptr> %344, i32 0
  %347 = extractelement <8 x i64> %345, i32 0
  %348 = sub i64 %347, 0
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %350 = select i1 %349, i64 %348, i64 0
  %private.contiguous.address242 = getelementptr i8, ptr %346, i64 %350
  %private.contiguous.load243 = load <8 x float>, ptr %private.contiguous.address242, align 4
  %351 = select <8 x i1> %71, <8 x float> %private.contiguous.load243, <8 x float> zeroinitializer
  %352 = fmul <8 x float> %286, %351
  %.state244 = load <8 x float>, ptr %.slot50, align 32
  %353 = fadd <8 x float> %.state244, %352
  %.state245 = load i64, ptr %.slot46, align 4
  %354 = add i64 %.state245, 1
  store i64 %354, ptr %.slot46, align 4
  %355 = load <8 x float>, ptr %.slot47, align 32
  %356 = select <8 x i1> %71, <8 x float> %302, <8 x float> %355
  store <8 x float> %356, ptr %.slot47, align 32
  %357 = load <8 x float>, ptr %.slot48, align 32
  %358 = select <8 x i1> %71, <8 x float> %319, <8 x float> %357
  store <8 x float> %358, ptr %.slot48, align 32
  %359 = load <8 x float>, ptr %.slot49, align 32
  %360 = select <8 x i1> %71, <8 x float> %336, <8 x float> %359
  store <8 x float> %360, ptr %.slot49, align 32
  %361 = load <8 x float>, ptr %.slot50, align 32
  %362 = select <8 x i1> %71, <8 x float> %353, <8 x float> %361
  store <8 x float> %362, ptr %.slot50, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false212
  store i64 0, ptr %.slot51, align 4
  %363 = load <8 x float>, ptr %.slot52, align 32
  %364 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %363
  store <8 x float> %364, ptr %.slot52, align 32
  %365 = load <8 x float>, ptr %.slot53, align 32
  %366 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %365
  store <8 x float> %366, ptr %.slot53, align 32
  %367 = load <8 x float>, ptr %.slot54, align 32
  %368 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %367
  store <8 x float> %368, ptr %.slot54, align 32
  %369 = load <8 x float>, ptr %.slot55, align 32
  %370 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %369
  store <8 x float> %370, ptr %.slot55, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state246 = load i64, ptr %.slot51, align 4
  %371 = icmp slt i64 %.state246, 80
  br i1 %371, label %direct.true247, label %direct.false248

direct.schedule.23:                               ; preds = %direct.true247
  %.state249 = load i64, ptr %.slot51, align 4
  %372 = add i64 0, %.state249
  %tile_snapshot.spill.load250 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 1
  %.splatinsert251 = insertelement <8 x i64> poison, i64 %372, i64 0
  %.splat252 = shufflevector <8 x i64> %.splatinsert251, <8 x i64> poison, <8 x i32> zeroinitializer
  %375 = mul <8 x i64> %.splat252, splat (i64 32)
  %376 = add <8 x i64> %374, %375
  %377 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %373, 0
  %378 = insertvalue { <8 x ptr>, <8 x i64> } %377, <8 x i64> %376, 1
  %379 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %378, 1
  %381 = extractelement <8 x ptr> %379, i32 0
  %382 = extractelement <8 x i64> %380, i32 0
  %383 = sub i64 %382, 0
  %384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %385 = select i1 %384, i64 %383, i64 0
  %private.contiguous.address253 = getelementptr i8, ptr %381, i64 %385
  %private.contiguous.load254 = load <8 x float>, ptr %private.contiguous.address253, align 4
  %386 = select <8 x i1> %71, <8 x float> %private.contiguous.load254, <8 x float> zeroinitializer
  %.state255 = load i64, ptr %.slot51, align 4
  %387 = add i64 320, %.state255
  %tile_snapshot.spill.load256 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 0
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 1
  %.splatinsert257 = insertelement <8 x i64> poison, i64 %387, i64 0
  %.splat258 = shufflevector <8 x i64> %.splatinsert257, <8 x i64> poison, <8 x i32> zeroinitializer
  %390 = mul <8 x i64> %.splat258, splat (i64 32)
  %391 = add <8 x i64> %389, %390
  %392 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %388, 0
  %393 = insertvalue { <8 x ptr>, <8 x i64> } %392, <8 x i64> %391, 1
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %393, 1
  %396 = extractelement <8 x ptr> %394, i32 0
  %397 = extractelement <8 x i64> %395, i32 0
  %398 = sub i64 %397, 0
  %399 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %400 = select i1 %399, i64 %398, i64 0
  %private.contiguous.address259 = getelementptr i8, ptr %396, i64 %400
  %private.contiguous.load260 = load <8 x float>, ptr %private.contiguous.address259, align 4
  %401 = select <8 x i1> %71, <8 x float> %private.contiguous.load260, <8 x float> zeroinitializer
  %402 = fmul <8 x float> %386, %401
  %.state261 = load <8 x float>, ptr %.slot52, align 32
  %403 = fadd <8 x float> %.state261, %402
  %.state262 = load i64, ptr %.slot51, align 4
  %404 = add i64 400, %.state262
  %tile_snapshot.spill.load263 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load263, 0
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load263, 1
  %.splatinsert264 = insertelement <8 x i64> poison, i64 %404, i64 0
  %.splat265 = shufflevector <8 x i64> %.splatinsert264, <8 x i64> poison, <8 x i32> zeroinitializer
  %407 = mul <8 x i64> %.splat265, splat (i64 32)
  %408 = add <8 x i64> %406, %407
  %409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %405, 0
  %410 = insertvalue { <8 x ptr>, <8 x i64> } %409, <8 x i64> %408, 1
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %410, 1
  %413 = extractelement <8 x ptr> %411, i32 0
  %414 = extractelement <8 x i64> %412, i32 0
  %415 = sub i64 %414, 0
  %416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %417 = select i1 %416, i64 %415, i64 0
  %private.contiguous.address266 = getelementptr i8, ptr %413, i64 %417
  %private.contiguous.load267 = load <8 x float>, ptr %private.contiguous.address266, align 4
  %418 = select <8 x i1> %71, <8 x float> %private.contiguous.load267, <8 x float> zeroinitializer
  %419 = fmul <8 x float> %386, %418
  %.state268 = load <8 x float>, ptr %.slot53, align 32
  %420 = fadd <8 x float> %.state268, %419
  %.state269 = load i64, ptr %.slot51, align 4
  %421 = add i64 480, %.state269
  %tile_snapshot.spill.load270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %.splatinsert271 = insertelement <8 x i64> poison, i64 %421, i64 0
  %.splat272 = shufflevector <8 x i64> %.splatinsert271, <8 x i64> poison, <8 x i32> zeroinitializer
  %424 = mul <8 x i64> %.splat272, splat (i64 32)
  %425 = add <8 x i64> %423, %424
  %426 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %422, 0
  %427 = insertvalue { <8 x ptr>, <8 x i64> } %426, <8 x i64> %425, 1
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %429 = extractvalue { <8 x ptr>, <8 x i64> } %427, 1
  %430 = extractelement <8 x ptr> %428, i32 0
  %431 = extractelement <8 x i64> %429, i32 0
  %432 = sub i64 %431, 0
  %433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %434 = select i1 %433, i64 %432, i64 0
  %private.contiguous.address273 = getelementptr i8, ptr %430, i64 %434
  %private.contiguous.load274 = load <8 x float>, ptr %private.contiguous.address273, align 4
  %435 = select <8 x i1> %71, <8 x float> %private.contiguous.load274, <8 x float> zeroinitializer
  %436 = fmul <8 x float> %386, %435
  %.state275 = load <8 x float>, ptr %.slot54, align 32
  %437 = fadd <8 x float> %.state275, %436
  %.state276 = load i64, ptr %.slot51, align 4
  %438 = add i64 560, %.state276
  %tile_snapshot.spill.load277 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 1
  %.splatinsert278 = insertelement <8 x i64> poison, i64 %438, i64 0
  %.splat279 = shufflevector <8 x i64> %.splatinsert278, <8 x i64> poison, <8 x i32> zeroinitializer
  %441 = mul <8 x i64> %.splat279, splat (i64 32)
  %442 = add <8 x i64> %440, %441
  %443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %439, 0
  %444 = insertvalue { <8 x ptr>, <8 x i64> } %443, <8 x i64> %442, 1
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %444, 1
  %447 = extractelement <8 x ptr> %445, i32 0
  %448 = extractelement <8 x i64> %446, i32 0
  %449 = sub i64 %448, 0
  %450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %451 = select i1 %450, i64 %449, i64 0
  %private.contiguous.address280 = getelementptr i8, ptr %447, i64 %451
  %private.contiguous.load281 = load <8 x float>, ptr %private.contiguous.address280, align 4
  %452 = select <8 x i1> %71, <8 x float> %private.contiguous.load281, <8 x float> zeroinitializer
  %453 = fmul <8 x float> %386, %452
  %.state282 = load <8 x float>, ptr %.slot55, align 32
  %454 = fadd <8 x float> %.state282, %453
  %.state283 = load i64, ptr %.slot51, align 4
  %455 = add i64 %.state283, 1
  store i64 %455, ptr %.slot51, align 4
  %456 = load <8 x float>, ptr %.slot52, align 32
  %457 = select <8 x i1> %71, <8 x float> %403, <8 x float> %456
  store <8 x float> %457, ptr %.slot52, align 32
  %458 = load <8 x float>, ptr %.slot53, align 32
  %459 = select <8 x i1> %71, <8 x float> %420, <8 x float> %458
  store <8 x float> %459, ptr %.slot53, align 32
  %460 = load <8 x float>, ptr %.slot54, align 32
  %461 = select <8 x i1> %71, <8 x float> %437, <8 x float> %460
  store <8 x float> %461, ptr %.slot54, align 32
  %462 = load <8 x float>, ptr %.slot55, align 32
  %463 = select <8 x i1> %71, <8 x float> %454, <8 x float> %462
  store <8 x float> %463, ptr %.slot55, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false248
  store i64 0, ptr %.slot56, align 4
  %464 = load <8 x float>, ptr %.slot57, align 32
  %465 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %464
  store <8 x float> %465, ptr %.slot57, align 32
  %466 = load <8 x float>, ptr %.slot58, align 32
  %467 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %466
  store <8 x float> %467, ptr %.slot58, align 32
  %468 = load <8 x float>, ptr %.slot59, align 32
  %469 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %468
  store <8 x float> %469, ptr %.slot59, align 32
  %470 = load <8 x float>, ptr %.slot60, align 32
  %471 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %470
  store <8 x float> %471, ptr %.slot60, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state284 = load i64, ptr %.slot56, align 4
  %472 = icmp slt i64 %.state284, 80
  br i1 %472, label %direct.true285, label %direct.false286

direct.schedule.26:                               ; preds = %direct.true285
  %.state287 = load i64, ptr %.slot56, align 4
  %473 = add i64 0, %.state287
  %tile_snapshot.spill.load288 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 0
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 1
  %.splatinsert289 = insertelement <8 x i64> poison, i64 %473, i64 0
  %.splat290 = shufflevector <8 x i64> %.splatinsert289, <8 x i64> poison, <8 x i32> zeroinitializer
  %476 = mul <8 x i64> %.splat290, splat (i64 32)
  %477 = add <8 x i64> %475, %476
  %478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %474, 0
  %479 = insertvalue { <8 x ptr>, <8 x i64> } %478, <8 x i64> %477, 1
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %479, 1
  %482 = extractelement <8 x ptr> %480, i32 0
  %483 = extractelement <8 x i64> %481, i32 0
  %484 = sub i64 %483, 0
  %485 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %486 = select i1 %485, i64 %484, i64 0
  %private.contiguous.address291 = getelementptr i8, ptr %482, i64 %486
  %private.contiguous.load292 = load <8 x float>, ptr %private.contiguous.address291, align 4
  %487 = select <8 x i1> %71, <8 x float> %private.contiguous.load292, <8 x float> zeroinitializer
  %.state293 = load i64, ptr %.slot56, align 4
  %488 = add i64 640, %.state293
  %tile_snapshot.spill.load294 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load294, 0
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load294, 1
  %.splatinsert295 = insertelement <8 x i64> poison, i64 %488, i64 0
  %.splat296 = shufflevector <8 x i64> %.splatinsert295, <8 x i64> poison, <8 x i32> zeroinitializer
  %491 = mul <8 x i64> %.splat296, splat (i64 32)
  %492 = add <8 x i64> %490, %491
  %493 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %489, 0
  %494 = insertvalue { <8 x ptr>, <8 x i64> } %493, <8 x i64> %492, 1
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %494, 1
  %497 = extractelement <8 x ptr> %495, i32 0
  %498 = extractelement <8 x i64> %496, i32 0
  %499 = sub i64 %498, 0
  %500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %501 = select i1 %500, i64 %499, i64 0
  %private.contiguous.address297 = getelementptr i8, ptr %497, i64 %501
  %private.contiguous.load298 = load <8 x float>, ptr %private.contiguous.address297, align 4
  %502 = select <8 x i1> %71, <8 x float> %private.contiguous.load298, <8 x float> zeroinitializer
  %503 = fmul <8 x float> %487, %502
  %.state299 = load <8 x float>, ptr %.slot57, align 32
  %504 = fadd <8 x float> %.state299, %503
  %.state300 = load i64, ptr %.slot56, align 4
  %505 = add i64 720, %.state300
  %tile_snapshot.spill.load301 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load301, 0
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load301, 1
  %.splatinsert302 = insertelement <8 x i64> poison, i64 %505, i64 0
  %.splat303 = shufflevector <8 x i64> %.splatinsert302, <8 x i64> poison, <8 x i32> zeroinitializer
  %508 = mul <8 x i64> %.splat303, splat (i64 32)
  %509 = add <8 x i64> %507, %508
  %510 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %506, 0
  %511 = insertvalue { <8 x ptr>, <8 x i64> } %510, <8 x i64> %509, 1
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %511, 1
  %514 = extractelement <8 x ptr> %512, i32 0
  %515 = extractelement <8 x i64> %513, i32 0
  %516 = sub i64 %515, 0
  %517 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %518 = select i1 %517, i64 %516, i64 0
  %private.contiguous.address304 = getelementptr i8, ptr %514, i64 %518
  %private.contiguous.load305 = load <8 x float>, ptr %private.contiguous.address304, align 4
  %519 = select <8 x i1> %71, <8 x float> %private.contiguous.load305, <8 x float> zeroinitializer
  %520 = fmul <8 x float> %487, %519
  %.state306 = load <8 x float>, ptr %.slot58, align 32
  %521 = fadd <8 x float> %.state306, %520
  %.state307 = load i64, ptr %.slot56, align 4
  %522 = add i64 800, %.state307
  %tile_snapshot.spill.load308 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 0
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 1
  %.splatinsert309 = insertelement <8 x i64> poison, i64 %522, i64 0
  %.splat310 = shufflevector <8 x i64> %.splatinsert309, <8 x i64> poison, <8 x i32> zeroinitializer
  %525 = mul <8 x i64> %.splat310, splat (i64 32)
  %526 = add <8 x i64> %524, %525
  %527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %523, 0
  %528 = insertvalue { <8 x ptr>, <8 x i64> } %527, <8 x i64> %526, 1
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %528, 1
  %531 = extractelement <8 x ptr> %529, i32 0
  %532 = extractelement <8 x i64> %530, i32 0
  %533 = sub i64 %532, 0
  %534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %535 = select i1 %534, i64 %533, i64 0
  %private.contiguous.address311 = getelementptr i8, ptr %531, i64 %535
  %private.contiguous.load312 = load <8 x float>, ptr %private.contiguous.address311, align 4
  %536 = select <8 x i1> %71, <8 x float> %private.contiguous.load312, <8 x float> zeroinitializer
  %537 = fmul <8 x float> %487, %536
  %.state313 = load <8 x float>, ptr %.slot59, align 32
  %538 = fadd <8 x float> %.state313, %537
  %.state314 = load i64, ptr %.slot56, align 4
  %539 = add i64 880, %.state314
  %tile_snapshot.spill.load315 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %540 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 0
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 1
  %.splatinsert316 = insertelement <8 x i64> poison, i64 %539, i64 0
  %.splat317 = shufflevector <8 x i64> %.splatinsert316, <8 x i64> poison, <8 x i32> zeroinitializer
  %542 = mul <8 x i64> %.splat317, splat (i64 32)
  %543 = add <8 x i64> %541, %542
  %544 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %540, 0
  %545 = insertvalue { <8 x ptr>, <8 x i64> } %544, <8 x i64> %543, 1
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %545, 1
  %548 = extractelement <8 x ptr> %546, i32 0
  %549 = extractelement <8 x i64> %547, i32 0
  %550 = sub i64 %549, 0
  %551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %552 = select i1 %551, i64 %550, i64 0
  %private.contiguous.address318 = getelementptr i8, ptr %548, i64 %552
  %private.contiguous.load319 = load <8 x float>, ptr %private.contiguous.address318, align 4
  %553 = select <8 x i1> %71, <8 x float> %private.contiguous.load319, <8 x float> zeroinitializer
  %554 = fmul <8 x float> %487, %553
  %.state320 = load <8 x float>, ptr %.slot60, align 32
  %555 = fadd <8 x float> %.state320, %554
  %.state321 = load i64, ptr %.slot56, align 4
  %556 = add i64 %.state321, 1
  store i64 %556, ptr %.slot56, align 4
  %557 = load <8 x float>, ptr %.slot57, align 32
  %558 = select <8 x i1> %71, <8 x float> %504, <8 x float> %557
  store <8 x float> %558, ptr %.slot57, align 32
  %559 = load <8 x float>, ptr %.slot58, align 32
  %560 = select <8 x i1> %71, <8 x float> %521, <8 x float> %559
  store <8 x float> %560, ptr %.slot58, align 32
  %561 = load <8 x float>, ptr %.slot59, align 32
  %562 = select <8 x i1> %71, <8 x float> %538, <8 x float> %561
  store <8 x float> %562, ptr %.slot59, align 32
  %563 = load <8 x float>, ptr %.slot60, align 32
  %564 = select <8 x i1> %71, <8 x float> %555, <8 x float> %563
  store <8 x float> %564, ptr %.slot60, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false286
  store i64 0, ptr %.slot61, align 4
  %565 = load <8 x float>, ptr %.slot62, align 32
  %566 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %565
  store <8 x float> %566, ptr %.slot62, align 32
  %567 = load <8 x float>, ptr %.slot63, align 32
  %568 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %567
  store <8 x float> %568, ptr %.slot63, align 32
  %569 = load <8 x float>, ptr %.slot64, align 32
  %570 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %569
  store <8 x float> %570, ptr %.slot64, align 32
  %571 = load <8 x float>, ptr %.slot65, align 32
  %572 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %571
  store <8 x float> %572, ptr %.slot65, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state322 = load i64, ptr %.slot61, align 4
  %573 = icmp slt i64 %.state322, 80
  br i1 %573, label %direct.true323, label %direct.false324

direct.schedule.29:                               ; preds = %direct.true323
  %.state325 = load i64, ptr %.slot61, align 4
  %574 = add i64 0, %.state325
  %tile_snapshot.spill.load326 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load326, 0
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load326, 1
  %.splatinsert327 = insertelement <8 x i64> poison, i64 %574, i64 0
  %.splat328 = shufflevector <8 x i64> %.splatinsert327, <8 x i64> poison, <8 x i32> zeroinitializer
  %577 = mul <8 x i64> %.splat328, splat (i64 32)
  %578 = add <8 x i64> %576, %577
  %579 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %575, 0
  %580 = insertvalue { <8 x ptr>, <8 x i64> } %579, <8 x i64> %578, 1
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %580, 1
  %583 = extractelement <8 x ptr> %581, i32 0
  %584 = extractelement <8 x i64> %582, i32 0
  %585 = sub i64 %584, 0
  %586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %587 = select i1 %586, i64 %585, i64 0
  %private.contiguous.address329 = getelementptr i8, ptr %583, i64 %587
  %private.contiguous.load330 = load <8 x float>, ptr %private.contiguous.address329, align 4
  %588 = select <8 x i1> %71, <8 x float> %private.contiguous.load330, <8 x float> zeroinitializer
  %.state331 = load i64, ptr %.slot61, align 4
  %589 = add i64 960, %.state331
  %tile_snapshot.spill.load332 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load332, 0
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load332, 1
  %.splatinsert333 = insertelement <8 x i64> poison, i64 %589, i64 0
  %.splat334 = shufflevector <8 x i64> %.splatinsert333, <8 x i64> poison, <8 x i32> zeroinitializer
  %592 = mul <8 x i64> %.splat334, splat (i64 32)
  %593 = add <8 x i64> %591, %592
  %594 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %590, 0
  %595 = insertvalue { <8 x ptr>, <8 x i64> } %594, <8 x i64> %593, 1
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %597 = extractvalue { <8 x ptr>, <8 x i64> } %595, 1
  %598 = extractelement <8 x ptr> %596, i32 0
  %599 = extractelement <8 x i64> %597, i32 0
  %600 = sub i64 %599, 0
  %601 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %602 = select i1 %601, i64 %600, i64 0
  %private.contiguous.address335 = getelementptr i8, ptr %598, i64 %602
  %private.contiguous.load336 = load <8 x float>, ptr %private.contiguous.address335, align 4
  %603 = select <8 x i1> %71, <8 x float> %private.contiguous.load336, <8 x float> zeroinitializer
  %604 = fmul <8 x float> %588, %603
  %.state337 = load <8 x float>, ptr %.slot62, align 32
  %605 = fadd <8 x float> %.state337, %604
  %.state338 = load i64, ptr %.slot61, align 4
  %606 = add i64 1040, %.state338
  %tile_snapshot.spill.load339 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %607 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 0
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 1
  %.splatinsert340 = insertelement <8 x i64> poison, i64 %606, i64 0
  %.splat341 = shufflevector <8 x i64> %.splatinsert340, <8 x i64> poison, <8 x i32> zeroinitializer
  %609 = mul <8 x i64> %.splat341, splat (i64 32)
  %610 = add <8 x i64> %608, %609
  %611 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %607, 0
  %612 = insertvalue { <8 x ptr>, <8 x i64> } %611, <8 x i64> %610, 1
  %613 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %612, 1
  %615 = extractelement <8 x ptr> %613, i32 0
  %616 = extractelement <8 x i64> %614, i32 0
  %617 = sub i64 %616, 0
  %618 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %619 = select i1 %618, i64 %617, i64 0
  %private.contiguous.address342 = getelementptr i8, ptr %615, i64 %619
  %private.contiguous.load343 = load <8 x float>, ptr %private.contiguous.address342, align 4
  %620 = select <8 x i1> %71, <8 x float> %private.contiguous.load343, <8 x float> zeroinitializer
  %621 = fmul <8 x float> %588, %620
  %.state344 = load <8 x float>, ptr %.slot63, align 32
  %622 = fadd <8 x float> %.state344, %621
  %.state345 = load i64, ptr %.slot61, align 4
  %623 = add i64 1120, %.state345
  %tile_snapshot.spill.load346 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load346, 0
  %625 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load346, 1
  %.splatinsert347 = insertelement <8 x i64> poison, i64 %623, i64 0
  %.splat348 = shufflevector <8 x i64> %.splatinsert347, <8 x i64> poison, <8 x i32> zeroinitializer
  %626 = mul <8 x i64> %.splat348, splat (i64 32)
  %627 = add <8 x i64> %625, %626
  %628 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %624, 0
  %629 = insertvalue { <8 x ptr>, <8 x i64> } %628, <8 x i64> %627, 1
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %631 = extractvalue { <8 x ptr>, <8 x i64> } %629, 1
  %632 = extractelement <8 x ptr> %630, i32 0
  %633 = extractelement <8 x i64> %631, i32 0
  %634 = sub i64 %633, 0
  %635 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %636 = select i1 %635, i64 %634, i64 0
  %private.contiguous.address349 = getelementptr i8, ptr %632, i64 %636
  %private.contiguous.load350 = load <8 x float>, ptr %private.contiguous.address349, align 4
  %637 = select <8 x i1> %71, <8 x float> %private.contiguous.load350, <8 x float> zeroinitializer
  %638 = fmul <8 x float> %588, %637
  %.state351 = load <8 x float>, ptr %.slot64, align 32
  %639 = fadd <8 x float> %.state351, %638
  %.state352 = load i64, ptr %.slot61, align 4
  %640 = add i64 1200, %.state352
  %tile_snapshot.spill.load353 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %641 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load353, 0
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load353, 1
  %.splatinsert354 = insertelement <8 x i64> poison, i64 %640, i64 0
  %.splat355 = shufflevector <8 x i64> %.splatinsert354, <8 x i64> poison, <8 x i32> zeroinitializer
  %643 = mul <8 x i64> %.splat355, splat (i64 32)
  %644 = add <8 x i64> %642, %643
  %645 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %641, 0
  %646 = insertvalue { <8 x ptr>, <8 x i64> } %645, <8 x i64> %644, 1
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %646, 1
  %649 = extractelement <8 x ptr> %647, i32 0
  %650 = extractelement <8 x i64> %648, i32 0
  %651 = sub i64 %650, 0
  %652 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %653 = select i1 %652, i64 %651, i64 0
  %private.contiguous.address356 = getelementptr i8, ptr %649, i64 %653
  %private.contiguous.load357 = load <8 x float>, ptr %private.contiguous.address356, align 4
  %654 = select <8 x i1> %71, <8 x float> %private.contiguous.load357, <8 x float> zeroinitializer
  %655 = fmul <8 x float> %588, %654
  %.state358 = load <8 x float>, ptr %.slot65, align 32
  %656 = fadd <8 x float> %.state358, %655
  %.state359 = load i64, ptr %.slot61, align 4
  %657 = add i64 %.state359, 1
  store i64 %657, ptr %.slot61, align 4
  %658 = load <8 x float>, ptr %.slot62, align 32
  %659 = select <8 x i1> %71, <8 x float> %605, <8 x float> %658
  store <8 x float> %659, ptr %.slot62, align 32
  %660 = load <8 x float>, ptr %.slot63, align 32
  %661 = select <8 x i1> %71, <8 x float> %622, <8 x float> %660
  store <8 x float> %661, ptr %.slot63, align 32
  %662 = load <8 x float>, ptr %.slot64, align 32
  %663 = select <8 x i1> %71, <8 x float> %639, <8 x float> %662
  store <8 x float> %663, ptr %.slot64, align 32
  %664 = load <8 x float>, ptr %.slot65, align 32
  %665 = select <8 x i1> %71, <8 x float> %656, <8 x float> %664
  store <8 x float> %665, ptr %.slot65, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false324
  %.state360 = load <8 x float>, ptr %.slot47, align 32
  %666 = fmul <8 x float> %.state360, splat (float 0x3FBC9F25C0000000)
  %.state361 = load <8 x float>, ptr %.slot48, align 32
  %667 = fmul <8 x float> %.state361, splat (float 0x3FBC9F25C0000000)
  %.state362 = load <8 x float>, ptr %.slot49, align 32
  %668 = fmul <8 x float> %.state362, splat (float 0x3FBC9F25C0000000)
  %.state363 = load <8 x float>, ptr %.slot50, align 32
  %669 = fmul <8 x float> %.state363, splat (float 0x3FBC9F25C0000000)
  %.state364 = load <8 x float>, ptr %.slot52, align 32
  %670 = fmul <8 x float> %.state364, splat (float 0x3FBC9F25C0000000)
  %.state365 = load <8 x float>, ptr %.slot53, align 32
  %671 = fmul <8 x float> %.state365, splat (float 0x3FBC9F25C0000000)
  %.state366 = load <8 x float>, ptr %.slot54, align 32
  %672 = fmul <8 x float> %.state366, splat (float 0x3FBC9F25C0000000)
  %.state367 = load <8 x float>, ptr %.slot55, align 32
  %673 = fmul <8 x float> %.state367, splat (float 0x3FBC9F25C0000000)
  %.state368 = load <8 x float>, ptr %.slot57, align 32
  %674 = fmul <8 x float> %.state368, splat (float 0x3FBC9F25C0000000)
  %.state369 = load <8 x float>, ptr %.slot58, align 32
  %675 = fmul <8 x float> %.state369, splat (float 0x3FBC9F25C0000000)
  %.state370 = load <8 x float>, ptr %.slot59, align 32
  %676 = fmul <8 x float> %.state370, splat (float 0x3FBC9F25C0000000)
  %.state371 = load <8 x float>, ptr %.slot60, align 32
  %677 = fmul <8 x float> %.state371, splat (float 0x3FBC9F25C0000000)
  %.state372 = load <8 x float>, ptr %.slot62, align 32
  %678 = fmul <8 x float> %.state372, splat (float 0x3FBC9F25C0000000)
  %.state373 = load <8 x float>, ptr %.slot63, align 32
  %679 = fmul <8 x float> %.state373, splat (float 0x3FBC9F25C0000000)
  %.state374 = load <8 x float>, ptr %.slot64, align 32
  %680 = fmul <8 x float> %.state374, splat (float 0x3FBC9F25C0000000)
  %.state375 = load <8 x float>, ptr %.slot65, align 32
  %681 = fmul <8 x float> %.state375, splat (float 0x3FBC9F25C0000000)
  %.spill.load376 = load i64, ptr %.spill37, align 4
  %682 = add i64 0, %.spill.load376
  %.spill.load377 = load i64, ptr %.spill37, align 4
  %683 = add i64 1, %.spill.load377
  %.spill.load378 = load i64, ptr %.spill37, align 4
  %684 = add i64 2, %.spill.load378
  %.spill.load379 = load i64, ptr %.spill37, align 4
  %685 = add i64 3, %.spill.load379
  %.spill.load380 = load i64, ptr %.spill37, align 4
  %686 = add i64 4, %.spill.load380
  %.spill.load381 = load i64, ptr %.spill37, align 4
  %687 = add i64 5, %.spill.load381
  %.spill.load382 = load i64, ptr %.spill37, align 4
  %688 = add i64 6, %.spill.load382
  %.spill.load383 = load i64, ptr %.spill37, align 4
  %689 = add i64 7, %.spill.load383
  %.spill.load384 = load i64, ptr %.spill37, align 4
  %690 = add i64 8, %.spill.load384
  %.spill.load385 = load i64, ptr %.spill37, align 4
  %691 = add i64 9, %.spill.load385
  %.spill.load386 = load i64, ptr %.spill37, align 4
  %692 = add i64 10, %.spill.load386
  %.spill.load387 = load i64, ptr %.spill37, align 4
  %693 = add i64 11, %.spill.load387
  %.spill.load388 = load i64, ptr %.spill37, align 4
  %694 = add i64 12, %.spill.load388
  %.spill.load389 = load i64, ptr %.spill37, align 4
  %695 = add i64 13, %.spill.load389
  %.spill.load390 = load i64, ptr %.spill37, align 4
  %696 = add i64 14, %.spill.load390
  %.spill.load391 = load i64, ptr %.spill37, align 4
  %697 = add i64 15, %.spill.load391
  %698 = icmp slt i64 %682, 2053
  %699 = icmp slt i64 %683, 2053
  %700 = icmp slt i64 %684, 2053
  %701 = icmp slt i64 %685, 2053
  %702 = icmp slt i64 %686, 2053
  %703 = icmp slt i64 %687, 2053
  %704 = icmp slt i64 %688, 2053
  %705 = icmp slt i64 %689, 2053
  %706 = icmp slt i64 %690, 2053
  %707 = icmp slt i64 %691, 2053
  %708 = icmp slt i64 %692, 2053
  %709 = icmp slt i64 %693, 2053
  %710 = icmp slt i64 %694, 2053
  %711 = icmp slt i64 %695, 2053
  %712 = icmp slt i64 %696, 2053
  %713 = icmp slt i64 %697, 2053
  %.spill.load392 = load i64, ptr %.spill29, align 4
  %714 = add i64 0, %.spill.load392
  store i64 %714, ptr %.spill66, align 4
  %715 = add i64 %714, 2053
  %716 = sub i64 %715, 1
  %717 = icmp sle i64 %682, %716
  %718 = icmp sle i64 %683, %716
  %719 = icmp sle i64 %684, %716
  %720 = icmp sle i64 %685, %716
  %721 = icmp sle i64 %686, %716
  %722 = icmp sle i64 %687, %716
  %723 = icmp sle i64 %688, %716
  %724 = icmp sle i64 %689, %716
  %725 = icmp sle i64 %690, %716
  %726 = icmp sle i64 %691, %716
  %727 = icmp sle i64 %692, %716
  %728 = icmp sle i64 %693, %716
  %729 = icmp sle i64 %694, %716
  %730 = icmp sle i64 %695, %716
  %731 = icmp sle i64 %696, %716
  %732 = icmp sle i64 %697, %716
  %733 = and i1 %698, %717
  store i1 %733, ptr %.spill67, align 1
  %734 = and i1 %699, %718
  store i1 %734, ptr %.spill68, align 1
  %735 = and i1 %700, %719
  store i1 %735, ptr %.spill69, align 1
  %736 = and i1 %701, %720
  store i1 %736, ptr %.spill70, align 1
  %737 = and i1 %702, %721
  store i1 %737, ptr %.spill71, align 1
  %738 = and i1 %703, %722
  store i1 %738, ptr %.spill72, align 1
  %739 = and i1 %704, %723
  store i1 %739, ptr %.spill73, align 1
  %740 = and i1 %705, %724
  store i1 %740, ptr %.spill74, align 1
  %741 = and i1 %706, %725
  store i1 %741, ptr %.spill75, align 1
  %742 = and i1 %707, %726
  store i1 %742, ptr %.spill76, align 1
  %743 = and i1 %708, %727
  store i1 %743, ptr %.spill77, align 1
  %744 = and i1 %709, %728
  store i1 %744, ptr %.spill78, align 1
  %745 = and i1 %710, %729
  store i1 %745, ptr %.spill79, align 1
  %746 = and i1 %711, %730
  store i1 %746, ptr %.spill80, align 1
  %747 = and i1 %712, %731
  store i1 %747, ptr %.spill81, align 1
  %748 = and i1 %713, %732
  store i1 %748, ptr %.spill82, align 1
  %.splatinsert393 = insertelement <8 x i1> poison, i1 %733, i64 0
  %.splat394 = shufflevector <8 x i1> %.splatinsert393, <8 x i1> poison, <8 x i32> zeroinitializer
  %749 = select <8 x i1> %.splat394, <8 x float> %666, <8 x float> splat (float 0xC6293E5940000000)
  %750 = load <8 x float>, ptr %.spill83, align 32
  %751 = select <8 x i1> %71, <8 x float> %749, <8 x float> %750
  store <8 x float> %751, ptr %.spill83, align 32
  %.splatinsert395 = insertelement <8 x i1> poison, i1 %734, i64 0
  %.splat396 = shufflevector <8 x i1> %.splatinsert395, <8 x i1> poison, <8 x i32> zeroinitializer
  %752 = select <8 x i1> %.splat396, <8 x float> %667, <8 x float> splat (float 0xC6293E5940000000)
  %753 = load <8 x float>, ptr %.spill84, align 32
  %754 = select <8 x i1> %71, <8 x float> %752, <8 x float> %753
  store <8 x float> %754, ptr %.spill84, align 32
  %.splatinsert397 = insertelement <8 x i1> poison, i1 %735, i64 0
  %.splat398 = shufflevector <8 x i1> %.splatinsert397, <8 x i1> poison, <8 x i32> zeroinitializer
  %755 = select <8 x i1> %.splat398, <8 x float> %668, <8 x float> splat (float 0xC6293E5940000000)
  %756 = load <8 x float>, ptr %.spill85, align 32
  %757 = select <8 x i1> %71, <8 x float> %755, <8 x float> %756
  store <8 x float> %757, ptr %.spill85, align 32
  %.splatinsert399 = insertelement <8 x i1> poison, i1 %736, i64 0
  %.splat400 = shufflevector <8 x i1> %.splatinsert399, <8 x i1> poison, <8 x i32> zeroinitializer
  %758 = select <8 x i1> %.splat400, <8 x float> %669, <8 x float> splat (float 0xC6293E5940000000)
  %759 = load <8 x float>, ptr %.spill86, align 32
  %760 = select <8 x i1> %71, <8 x float> %758, <8 x float> %759
  store <8 x float> %760, ptr %.spill86, align 32
  %.splatinsert401 = insertelement <8 x i1> poison, i1 %737, i64 0
  %.splat402 = shufflevector <8 x i1> %.splatinsert401, <8 x i1> poison, <8 x i32> zeroinitializer
  %761 = select <8 x i1> %.splat402, <8 x float> %670, <8 x float> splat (float 0xC6293E5940000000)
  %762 = load <8 x float>, ptr %.spill87, align 32
  %763 = select <8 x i1> %71, <8 x float> %761, <8 x float> %762
  store <8 x float> %763, ptr %.spill87, align 32
  %.splatinsert403 = insertelement <8 x i1> poison, i1 %738, i64 0
  %.splat404 = shufflevector <8 x i1> %.splatinsert403, <8 x i1> poison, <8 x i32> zeroinitializer
  %764 = select <8 x i1> %.splat404, <8 x float> %671, <8 x float> splat (float 0xC6293E5940000000)
  %765 = load <8 x float>, ptr %.spill88, align 32
  %766 = select <8 x i1> %71, <8 x float> %764, <8 x float> %765
  store <8 x float> %766, ptr %.spill88, align 32
  %.splatinsert405 = insertelement <8 x i1> poison, i1 %739, i64 0
  %.splat406 = shufflevector <8 x i1> %.splatinsert405, <8 x i1> poison, <8 x i32> zeroinitializer
  %767 = select <8 x i1> %.splat406, <8 x float> %672, <8 x float> splat (float 0xC6293E5940000000)
  %768 = load <8 x float>, ptr %.spill89, align 32
  %769 = select <8 x i1> %71, <8 x float> %767, <8 x float> %768
  store <8 x float> %769, ptr %.spill89, align 32
  %.splatinsert407 = insertelement <8 x i1> poison, i1 %740, i64 0
  %.splat408 = shufflevector <8 x i1> %.splatinsert407, <8 x i1> poison, <8 x i32> zeroinitializer
  %770 = select <8 x i1> %.splat408, <8 x float> %673, <8 x float> splat (float 0xC6293E5940000000)
  %771 = load <8 x float>, ptr %.spill90, align 32
  %772 = select <8 x i1> %71, <8 x float> %770, <8 x float> %771
  store <8 x float> %772, ptr %.spill90, align 32
  %.splatinsert409 = insertelement <8 x i1> poison, i1 %741, i64 0
  %.splat410 = shufflevector <8 x i1> %.splatinsert409, <8 x i1> poison, <8 x i32> zeroinitializer
  %773 = select <8 x i1> %.splat410, <8 x float> %674, <8 x float> splat (float 0xC6293E5940000000)
  %774 = load <8 x float>, ptr %.spill91, align 32
  %775 = select <8 x i1> %71, <8 x float> %773, <8 x float> %774
  store <8 x float> %775, ptr %.spill91, align 32
  %.splatinsert411 = insertelement <8 x i1> poison, i1 %742, i64 0
  %.splat412 = shufflevector <8 x i1> %.splatinsert411, <8 x i1> poison, <8 x i32> zeroinitializer
  %776 = select <8 x i1> %.splat412, <8 x float> %675, <8 x float> splat (float 0xC6293E5940000000)
  %777 = load <8 x float>, ptr %.spill92, align 32
  %778 = select <8 x i1> %71, <8 x float> %776, <8 x float> %777
  store <8 x float> %778, ptr %.spill92, align 32
  %.splatinsert413 = insertelement <8 x i1> poison, i1 %743, i64 0
  %.splat414 = shufflevector <8 x i1> %.splatinsert413, <8 x i1> poison, <8 x i32> zeroinitializer
  %779 = select <8 x i1> %.splat414, <8 x float> %676, <8 x float> splat (float 0xC6293E5940000000)
  %780 = load <8 x float>, ptr %.spill93, align 32
  %781 = select <8 x i1> %71, <8 x float> %779, <8 x float> %780
  store <8 x float> %781, ptr %.spill93, align 32
  %.splatinsert415 = insertelement <8 x i1> poison, i1 %744, i64 0
  %.splat416 = shufflevector <8 x i1> %.splatinsert415, <8 x i1> poison, <8 x i32> zeroinitializer
  %782 = select <8 x i1> %.splat416, <8 x float> %677, <8 x float> splat (float 0xC6293E5940000000)
  %783 = load <8 x float>, ptr %.spill94, align 32
  %784 = select <8 x i1> %71, <8 x float> %782, <8 x float> %783
  store <8 x float> %784, ptr %.spill94, align 32
  %.splatinsert417 = insertelement <8 x i1> poison, i1 %745, i64 0
  %.splat418 = shufflevector <8 x i1> %.splatinsert417, <8 x i1> poison, <8 x i32> zeroinitializer
  %785 = select <8 x i1> %.splat418, <8 x float> %678, <8 x float> splat (float 0xC6293E5940000000)
  %786 = load <8 x float>, ptr %.spill95, align 32
  %787 = select <8 x i1> %71, <8 x float> %785, <8 x float> %786
  store <8 x float> %787, ptr %.spill95, align 32
  %.splatinsert419 = insertelement <8 x i1> poison, i1 %746, i64 0
  %.splat420 = shufflevector <8 x i1> %.splatinsert419, <8 x i1> poison, <8 x i32> zeroinitializer
  %788 = select <8 x i1> %.splat420, <8 x float> %679, <8 x float> splat (float 0xC6293E5940000000)
  %789 = load <8 x float>, ptr %.spill96, align 32
  %790 = select <8 x i1> %71, <8 x float> %788, <8 x float> %789
  store <8 x float> %790, ptr %.spill96, align 32
  %.splatinsert421 = insertelement <8 x i1> poison, i1 %747, i64 0
  %.splat422 = shufflevector <8 x i1> %.splatinsert421, <8 x i1> poison, <8 x i32> zeroinitializer
  %791 = select <8 x i1> %.splat422, <8 x float> %680, <8 x float> splat (float 0xC6293E5940000000)
  %792 = load <8 x float>, ptr %.spill97, align 32
  %793 = select <8 x i1> %71, <8 x float> %791, <8 x float> %792
  store <8 x float> %793, ptr %.spill97, align 32
  %.splatinsert423 = insertelement <8 x i1> poison, i1 %748, i64 0
  %.splat424 = shufflevector <8 x i1> %.splatinsert423, <8 x i1> poison, <8 x i32> zeroinitializer
  %794 = select <8 x i1> %.splat424, <8 x float> %681, <8 x float> splat (float 0xC6293E5940000000)
  %795 = load <8 x float>, ptr %.spill98, align 32
  %796 = select <8 x i1> %71, <8 x float> %794, <8 x float> %795
  store <8 x float> %796, ptr %.spill98, align 32
  %797 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill99, align 64
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %797, 0
  %800 = select <8 x i1> %71, <8 x ptr> %798, <8 x ptr> %799
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %802 = extractvalue { <8 x ptr>, <8 x i64> } %797, 1
  %803 = select <8 x i1> %71, <8 x i64> %801, <8 x i64> %802
  %804 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %800, 0
  %805 = insertvalue { <8 x ptr>, <8 x i64> } %804, <8 x i64> %803, 1
  store { <8 x ptr>, <8 x i64> } %805, ptr %tile_snapshot.spill99, align 64
  %806 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %808 = add <8 x i64> %807, zeroinitializer
  %809 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %806, 0
  %810 = insertvalue { <8 x ptr>, <8 x i64> } %809, <8 x i64> %808, 1
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %810, 1
  %813 = extractelement <8 x ptr> %811, i32 0
  %814 = extractelement <8 x i64> %812, i32 0
  %815 = sub i64 %814, 0
  %816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %817 = select i1 %816, i64 %815, i64 0
  %private.contiguous.address425 = getelementptr i8, ptr %813, i64 %817
  %private.contiguous.preserve426 = load <8 x float>, ptr %private.contiguous.address425, align 4
  %818 = select <8 x i1> %71, <8 x float> %749, <8 x float> %private.contiguous.preserve426
  store <8 x float> %818, ptr %private.contiguous.address425, align 4
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %821 = add <8 x i64> %820, splat (i64 32)
  %822 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %819, 0
  %823 = insertvalue { <8 x ptr>, <8 x i64> } %822, <8 x i64> %821, 1
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %823, 1
  %826 = extractelement <8 x ptr> %824, i32 0
  %827 = extractelement <8 x i64> %825, i32 0
  %828 = sub i64 %827, 0
  %829 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %830 = select i1 %829, i64 %828, i64 0
  %private.contiguous.address427 = getelementptr i8, ptr %826, i64 %830
  %private.contiguous.preserve428 = load <8 x float>, ptr %private.contiguous.address427, align 4
  %831 = select <8 x i1> %71, <8 x float> %752, <8 x float> %private.contiguous.preserve428
  store <8 x float> %831, ptr %private.contiguous.address427, align 4
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %834 = add <8 x i64> %833, splat (i64 64)
  %835 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %832, 0
  %836 = insertvalue { <8 x ptr>, <8 x i64> } %835, <8 x i64> %834, 1
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %838 = extractvalue { <8 x ptr>, <8 x i64> } %836, 1
  %839 = extractelement <8 x ptr> %837, i32 0
  %840 = extractelement <8 x i64> %838, i32 0
  %841 = sub i64 %840, 0
  %842 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %843 = select i1 %842, i64 %841, i64 0
  %private.contiguous.address429 = getelementptr i8, ptr %839, i64 %843
  %private.contiguous.preserve430 = load <8 x float>, ptr %private.contiguous.address429, align 4
  %844 = select <8 x i1> %71, <8 x float> %755, <8 x float> %private.contiguous.preserve430
  store <8 x float> %844, ptr %private.contiguous.address429, align 4
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %847 = add <8 x i64> %846, splat (i64 96)
  %848 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %845, 0
  %849 = insertvalue { <8 x ptr>, <8 x i64> } %848, <8 x i64> %847, 1
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %849, 1
  %852 = extractelement <8 x ptr> %850, i32 0
  %853 = extractelement <8 x i64> %851, i32 0
  %854 = sub i64 %853, 0
  %855 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %856 = select i1 %855, i64 %854, i64 0
  %private.contiguous.address431 = getelementptr i8, ptr %852, i64 %856
  %private.contiguous.preserve432 = load <8 x float>, ptr %private.contiguous.address431, align 4
  %857 = select <8 x i1> %71, <8 x float> %758, <8 x float> %private.contiguous.preserve432
  store <8 x float> %857, ptr %private.contiguous.address431, align 4
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %859 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %860 = add <8 x i64> %859, splat (i64 128)
  %861 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %858, 0
  %862 = insertvalue { <8 x ptr>, <8 x i64> } %861, <8 x i64> %860, 1
  %863 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %864 = extractvalue { <8 x ptr>, <8 x i64> } %862, 1
  %865 = extractelement <8 x ptr> %863, i32 0
  %866 = extractelement <8 x i64> %864, i32 0
  %867 = sub i64 %866, 0
  %868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %869 = select i1 %868, i64 %867, i64 0
  %private.contiguous.address433 = getelementptr i8, ptr %865, i64 %869
  %private.contiguous.preserve434 = load <8 x float>, ptr %private.contiguous.address433, align 4
  %870 = select <8 x i1> %71, <8 x float> %761, <8 x float> %private.contiguous.preserve434
  store <8 x float> %870, ptr %private.contiguous.address433, align 4
  %871 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %873 = add <8 x i64> %872, splat (i64 160)
  %874 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %871, 0
  %875 = insertvalue { <8 x ptr>, <8 x i64> } %874, <8 x i64> %873, 1
  %876 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %875, 1
  %878 = extractelement <8 x ptr> %876, i32 0
  %879 = extractelement <8 x i64> %877, i32 0
  %880 = sub i64 %879, 0
  %881 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %882 = select i1 %881, i64 %880, i64 0
  %private.contiguous.address435 = getelementptr i8, ptr %878, i64 %882
  %private.contiguous.preserve436 = load <8 x float>, ptr %private.contiguous.address435, align 4
  %883 = select <8 x i1> %71, <8 x float> %764, <8 x float> %private.contiguous.preserve436
  store <8 x float> %883, ptr %private.contiguous.address435, align 4
  %884 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %885 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %886 = add <8 x i64> %885, splat (i64 192)
  %887 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %884, 0
  %888 = insertvalue { <8 x ptr>, <8 x i64> } %887, <8 x i64> %886, 1
  %889 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %890 = extractvalue { <8 x ptr>, <8 x i64> } %888, 1
  %891 = extractelement <8 x ptr> %889, i32 0
  %892 = extractelement <8 x i64> %890, i32 0
  %893 = sub i64 %892, 0
  %894 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %895 = select i1 %894, i64 %893, i64 0
  %private.contiguous.address437 = getelementptr i8, ptr %891, i64 %895
  %private.contiguous.preserve438 = load <8 x float>, ptr %private.contiguous.address437, align 4
  %896 = select <8 x i1> %71, <8 x float> %767, <8 x float> %private.contiguous.preserve438
  store <8 x float> %896, ptr %private.contiguous.address437, align 4
  %897 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %898 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %899 = add <8 x i64> %898, splat (i64 224)
  %900 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %897, 0
  %901 = insertvalue { <8 x ptr>, <8 x i64> } %900, <8 x i64> %899, 1
  %902 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %903 = extractvalue { <8 x ptr>, <8 x i64> } %901, 1
  %904 = extractelement <8 x ptr> %902, i32 0
  %905 = extractelement <8 x i64> %903, i32 0
  %906 = sub i64 %905, 0
  %907 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %908 = select i1 %907, i64 %906, i64 0
  %private.contiguous.address439 = getelementptr i8, ptr %904, i64 %908
  %private.contiguous.preserve440 = load <8 x float>, ptr %private.contiguous.address439, align 4
  %909 = select <8 x i1> %71, <8 x float> %770, <8 x float> %private.contiguous.preserve440
  store <8 x float> %909, ptr %private.contiguous.address439, align 4
  %910 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %911 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %912 = add <8 x i64> %911, splat (i64 256)
  %913 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %910, 0
  %914 = insertvalue { <8 x ptr>, <8 x i64> } %913, <8 x i64> %912, 1
  %915 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %914, 1
  %917 = extractelement <8 x ptr> %915, i32 0
  %918 = extractelement <8 x i64> %916, i32 0
  %919 = sub i64 %918, 0
  %920 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %921 = select i1 %920, i64 %919, i64 0
  %private.contiguous.address441 = getelementptr i8, ptr %917, i64 %921
  %private.contiguous.preserve442 = load <8 x float>, ptr %private.contiguous.address441, align 4
  %922 = select <8 x i1> %71, <8 x float> %773, <8 x float> %private.contiguous.preserve442
  store <8 x float> %922, ptr %private.contiguous.address441, align 4
  %923 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %924 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %925 = add <8 x i64> %924, splat (i64 288)
  %926 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %923, 0
  %927 = insertvalue { <8 x ptr>, <8 x i64> } %926, <8 x i64> %925, 1
  %928 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %929 = extractvalue { <8 x ptr>, <8 x i64> } %927, 1
  %930 = extractelement <8 x ptr> %928, i32 0
  %931 = extractelement <8 x i64> %929, i32 0
  %932 = sub i64 %931, 0
  %933 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %934 = select i1 %933, i64 %932, i64 0
  %private.contiguous.address443 = getelementptr i8, ptr %930, i64 %934
  %private.contiguous.preserve444 = load <8 x float>, ptr %private.contiguous.address443, align 4
  %935 = select <8 x i1> %71, <8 x float> %776, <8 x float> %private.contiguous.preserve444
  store <8 x float> %935, ptr %private.contiguous.address443, align 4
  %936 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %937 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %938 = add <8 x i64> %937, splat (i64 320)
  %939 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %936, 0
  %940 = insertvalue { <8 x ptr>, <8 x i64> } %939, <8 x i64> %938, 1
  %941 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %942 = extractvalue { <8 x ptr>, <8 x i64> } %940, 1
  %943 = extractelement <8 x ptr> %941, i32 0
  %944 = extractelement <8 x i64> %942, i32 0
  %945 = sub i64 %944, 0
  %946 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %947 = select i1 %946, i64 %945, i64 0
  %private.contiguous.address445 = getelementptr i8, ptr %943, i64 %947
  %private.contiguous.preserve446 = load <8 x float>, ptr %private.contiguous.address445, align 4
  %948 = select <8 x i1> %71, <8 x float> %779, <8 x float> %private.contiguous.preserve446
  store <8 x float> %948, ptr %private.contiguous.address445, align 4
  %949 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %951 = add <8 x i64> %950, splat (i64 352)
  %952 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %949, 0
  %953 = insertvalue { <8 x ptr>, <8 x i64> } %952, <8 x i64> %951, 1
  %954 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %955 = extractvalue { <8 x ptr>, <8 x i64> } %953, 1
  %956 = extractelement <8 x ptr> %954, i32 0
  %957 = extractelement <8 x i64> %955, i32 0
  %958 = sub i64 %957, 0
  %959 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %960 = select i1 %959, i64 %958, i64 0
  %private.contiguous.address447 = getelementptr i8, ptr %956, i64 %960
  %private.contiguous.preserve448 = load <8 x float>, ptr %private.contiguous.address447, align 4
  %961 = select <8 x i1> %71, <8 x float> %782, <8 x float> %private.contiguous.preserve448
  store <8 x float> %961, ptr %private.contiguous.address447, align 4
  %962 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %963 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %964 = add <8 x i64> %963, splat (i64 384)
  %965 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %962, 0
  %966 = insertvalue { <8 x ptr>, <8 x i64> } %965, <8 x i64> %964, 1
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %968 = extractvalue { <8 x ptr>, <8 x i64> } %966, 1
  %969 = extractelement <8 x ptr> %967, i32 0
  %970 = extractelement <8 x i64> %968, i32 0
  %971 = sub i64 %970, 0
  %972 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %973 = select i1 %972, i64 %971, i64 0
  %private.contiguous.address449 = getelementptr i8, ptr %969, i64 %973
  %private.contiguous.preserve450 = load <8 x float>, ptr %private.contiguous.address449, align 4
  %974 = select <8 x i1> %71, <8 x float> %785, <8 x float> %private.contiguous.preserve450
  store <8 x float> %974, ptr %private.contiguous.address449, align 4
  %975 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %976 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %977 = add <8 x i64> %976, splat (i64 416)
  %978 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %975, 0
  %979 = insertvalue { <8 x ptr>, <8 x i64> } %978, <8 x i64> %977, 1
  %980 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %979, 1
  %982 = extractelement <8 x ptr> %980, i32 0
  %983 = extractelement <8 x i64> %981, i32 0
  %984 = sub i64 %983, 0
  %985 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %986 = select i1 %985, i64 %984, i64 0
  %private.contiguous.address451 = getelementptr i8, ptr %982, i64 %986
  %private.contiguous.preserve452 = load <8 x float>, ptr %private.contiguous.address451, align 4
  %987 = select <8 x i1> %71, <8 x float> %788, <8 x float> %private.contiguous.preserve452
  store <8 x float> %987, ptr %private.contiguous.address451, align 4
  %988 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %989 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %990 = add <8 x i64> %989, splat (i64 448)
  %991 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %988, 0
  %992 = insertvalue { <8 x ptr>, <8 x i64> } %991, <8 x i64> %990, 1
  %993 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %994 = extractvalue { <8 x ptr>, <8 x i64> } %992, 1
  %995 = extractelement <8 x ptr> %993, i32 0
  %996 = extractelement <8 x i64> %994, i32 0
  %997 = sub i64 %996, 0
  %998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %999 = select i1 %998, i64 %997, i64 0
  %private.contiguous.address453 = getelementptr i8, ptr %995, i64 %999
  %private.contiguous.preserve454 = load <8 x float>, ptr %private.contiguous.address453, align 4
  %1000 = select <8 x i1> %71, <8 x float> %791, <8 x float> %private.contiguous.preserve454
  store <8 x float> %1000, ptr %private.contiguous.address453, align 4
  %1001 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1003 = add <8 x i64> %1002, splat (i64 480)
  %1004 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1001, 0
  %1005 = insertvalue { <8 x ptr>, <8 x i64> } %1004, <8 x i64> %1003, 1
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1007 = extractvalue { <8 x ptr>, <8 x i64> } %1005, 1
  %1008 = extractelement <8 x ptr> %1006, i32 0
  %1009 = extractelement <8 x i64> %1007, i32 0
  %1010 = sub i64 %1009, 0
  %1011 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1012 = select i1 %1011, i64 %1010, i64 0
  %private.contiguous.address455 = getelementptr i8, ptr %1008, i64 %1012
  %private.contiguous.preserve456 = load <8 x float>, ptr %private.contiguous.address455, align 4
  %1013 = select <8 x i1> %71, <8 x float> %794, <8 x float> %private.contiguous.preserve456
  store <8 x float> %1013, ptr %private.contiguous.address455, align 4
  store i64 0, ptr %.slot100, align 4
  %1014 = load <8 x float>, ptr %.slot101, align 32
  %1015 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1014
  store <8 x float> %1015, ptr %.slot101, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state457 = load i64, ptr %.slot100, align 4
  %1016 = icmp slt i64 %.state457, 16
  br i1 %1016, label %direct.true458, label %direct.false459

direct.schedule.32:                               ; preds = %direct.true458
  %.state460 = load i64, ptr %.slot100, align 4
  %1017 = sdiv i64 %.state460, 1
  %.spill.load461 = load i64, ptr %.spill66, align 4
  %1018 = mul i64 %.spill.load461, 1
  %1019 = add i64 %1018, 0
  %1020 = mul i64 %1019, 1
  %1021 = add i64 %1020, 0
  %1022 = mul i64 %1021, 16
  %1023 = add i64 %1022, %1017
  %tile_snapshot.spill.load462 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill99, align 64
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load462, 0
  %1025 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load462, 1
  %.splatinsert463 = insertelement <8 x i64> poison, i64 %1023, i64 0
  %.splat464 = shufflevector <8 x i64> %.splatinsert463, <8 x i64> poison, <8 x i32> zeroinitializer
  %1026 = mul <8 x i64> %.splat464, splat (i64 32)
  %1027 = add <8 x i64> %1025, %1026
  %1028 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1024, 0
  %1029 = insertvalue { <8 x ptr>, <8 x i64> } %1028, <8 x i64> %1027, 1
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1031 = extractvalue { <8 x ptr>, <8 x i64> } %1029, 1
  %1032 = extractelement <8 x ptr> %1030, i32 0
  %1033 = extractelement <8 x i64> %1031, i32 0
  %1034 = sub i64 %1033, 0
  %1035 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1036 = select i1 %1035, i64 %1034, i64 0
  %private.contiguous.address465 = getelementptr i8, ptr %1032, i64 %1036
  %private.contiguous.load466 = load <8 x float>, ptr %private.contiguous.address465, align 4
  %1037 = select <8 x i1> %71, <8 x float> %private.contiguous.load466, <8 x float> zeroinitializer
  %.state467 = load <8 x float>, ptr %.slot101, align 32
  %1038 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state467, <8 x float> %1037)
  %.state468 = load i64, ptr %.slot100, align 4
  %1039 = add i64 %.state468, 1
  store i64 %1039, ptr %.slot100, align 4
  %1040 = load <8 x float>, ptr %.slot101, align 32
  %1041 = select <8 x i1> %71, <8 x float> %1038, <8 x float> %1040
  store <8 x float> %1041, ptr %.slot101, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false459
  %.state469 = load <8 x float>, ptr %.slot35, align 32
  %.state470 = load <8 x float>, ptr %.slot101, align 32
  %1042 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state469, <8 x float> %.state470)
  %1043 = load <8 x float>, ptr %.spill102, align 32
  %1044 = select <8 x i1> %71, <8 x float> %1042, <8 x float> %1043
  store <8 x float> %1044, ptr %.spill102, align 32
  %.state471 = load <8 x float>, ptr %.slot35, align 32
  %1045 = fsub <8 x float> %.state471, %1042
  %1046 = select <8 x i1> %71, <8 x float> %1045, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1046)
  %1047 = load <8 x float>, ptr %.spill103, align 32
  %1048 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %1047
  store <8 x float> %1048, ptr %.spill103, align 32
  %.spill.load472 = load <8 x float>, ptr %.spill83, align 32
  %1049 = fsub <8 x float> %.spill.load472, %1042
  %.spill.load473 = load <8 x float>, ptr %.spill84, align 32
  %1050 = fsub <8 x float> %.spill.load473, %1042
  %.spill.load474 = load <8 x float>, ptr %.spill85, align 32
  %1051 = fsub <8 x float> %.spill.load474, %1042
  %.spill.load475 = load <8 x float>, ptr %.spill86, align 32
  %1052 = fsub <8 x float> %.spill.load475, %1042
  %.spill.load476 = load <8 x float>, ptr %.spill87, align 32
  %1053 = fsub <8 x float> %.spill.load476, %1042
  %.spill.load477 = load <8 x float>, ptr %.spill88, align 32
  %1054 = fsub <8 x float> %.spill.load477, %1042
  %.spill.load478 = load <8 x float>, ptr %.spill89, align 32
  %1055 = fsub <8 x float> %.spill.load478, %1042
  %.spill.load479 = load <8 x float>, ptr %.spill90, align 32
  %1056 = fsub <8 x float> %.spill.load479, %1042
  %.spill.load480 = load <8 x float>, ptr %.spill91, align 32
  %1057 = fsub <8 x float> %.spill.load480, %1042
  %.spill.load481 = load <8 x float>, ptr %.spill92, align 32
  %1058 = fsub <8 x float> %.spill.load481, %1042
  %.spill.load482 = load <8 x float>, ptr %.spill93, align 32
  %1059 = fsub <8 x float> %.spill.load482, %1042
  %.spill.load483 = load <8 x float>, ptr %.spill94, align 32
  %1060 = fsub <8 x float> %.spill.load483, %1042
  %.spill.load484 = load <8 x float>, ptr %.spill95, align 32
  %1061 = fsub <8 x float> %.spill.load484, %1042
  %.spill.load485 = load <8 x float>, ptr %.spill96, align 32
  %1062 = fsub <8 x float> %.spill.load485, %1042
  %.spill.load486 = load <8 x float>, ptr %.spill97, align 32
  %1063 = fsub <8 x float> %.spill.load486, %1042
  %.spill.load487 = load <8 x float>, ptr %.spill98, align 32
  %1064 = fsub <8 x float> %.spill.load487, %1042
  %1065 = select <8 x i1> %71, <8 x float> %1049, <8 x float> zeroinitializer
  %native.exp488 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1065)
  %1066 = select <8 x i1> %71, <8 x float> %1050, <8 x float> zeroinitializer
  %native.exp489 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1066)
  %1067 = select <8 x i1> %71, <8 x float> %1051, <8 x float> zeroinitializer
  %native.exp490 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1067)
  %1068 = select <8 x i1> %71, <8 x float> %1052, <8 x float> zeroinitializer
  %native.exp491 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1068)
  %1069 = select <8 x i1> %71, <8 x float> %1053, <8 x float> zeroinitializer
  %native.exp492 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1069)
  %1070 = select <8 x i1> %71, <8 x float> %1054, <8 x float> zeroinitializer
  %native.exp493 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1070)
  %1071 = select <8 x i1> %71, <8 x float> %1055, <8 x float> zeroinitializer
  %native.exp494 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1071)
  %1072 = select <8 x i1> %71, <8 x float> %1056, <8 x float> zeroinitializer
  %native.exp495 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1072)
  %1073 = select <8 x i1> %71, <8 x float> %1057, <8 x float> zeroinitializer
  %native.exp496 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1073)
  %1074 = select <8 x i1> %71, <8 x float> %1058, <8 x float> zeroinitializer
  %native.exp497 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1074)
  %1075 = select <8 x i1> %71, <8 x float> %1059, <8 x float> zeroinitializer
  %native.exp498 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1075)
  %1076 = select <8 x i1> %71, <8 x float> %1060, <8 x float> zeroinitializer
  %native.exp499 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1076)
  %1077 = select <8 x i1> %71, <8 x float> %1061, <8 x float> zeroinitializer
  %native.exp500 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1077)
  %1078 = select <8 x i1> %71, <8 x float> %1062, <8 x float> zeroinitializer
  %native.exp501 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1078)
  %1079 = select <8 x i1> %71, <8 x float> %1063, <8 x float> zeroinitializer
  %native.exp502 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1079)
  %1080 = select <8 x i1> %71, <8 x float> %1064, <8 x float> zeroinitializer
  %native.exp503 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1080)
  %.spill.load504 = load i1, ptr %.spill67, align 1
  %.splatinsert505 = insertelement <8 x i1> poison, i1 %.spill.load504, i64 0
  %.splat506 = shufflevector <8 x i1> %.splatinsert505, <8 x i1> poison, <8 x i32> zeroinitializer
  %1081 = select <8 x i1> %.splat506, <8 x float> %native.exp488, <8 x float> zeroinitializer
  %.spill.load507 = load i1, ptr %.spill68, align 1
  %.splatinsert508 = insertelement <8 x i1> poison, i1 %.spill.load507, i64 0
  %.splat509 = shufflevector <8 x i1> %.splatinsert508, <8 x i1> poison, <8 x i32> zeroinitializer
  %1082 = select <8 x i1> %.splat509, <8 x float> %native.exp489, <8 x float> zeroinitializer
  %.spill.load510 = load i1, ptr %.spill69, align 1
  %.splatinsert511 = insertelement <8 x i1> poison, i1 %.spill.load510, i64 0
  %.splat512 = shufflevector <8 x i1> %.splatinsert511, <8 x i1> poison, <8 x i32> zeroinitializer
  %1083 = select <8 x i1> %.splat512, <8 x float> %native.exp490, <8 x float> zeroinitializer
  %.spill.load513 = load i1, ptr %.spill70, align 1
  %.splatinsert514 = insertelement <8 x i1> poison, i1 %.spill.load513, i64 0
  %.splat515 = shufflevector <8 x i1> %.splatinsert514, <8 x i1> poison, <8 x i32> zeroinitializer
  %1084 = select <8 x i1> %.splat515, <8 x float> %native.exp491, <8 x float> zeroinitializer
  %.spill.load516 = load i1, ptr %.spill71, align 1
  %.splatinsert517 = insertelement <8 x i1> poison, i1 %.spill.load516, i64 0
  %.splat518 = shufflevector <8 x i1> %.splatinsert517, <8 x i1> poison, <8 x i32> zeroinitializer
  %1085 = select <8 x i1> %.splat518, <8 x float> %native.exp492, <8 x float> zeroinitializer
  %.spill.load519 = load i1, ptr %.spill72, align 1
  %.splatinsert520 = insertelement <8 x i1> poison, i1 %.spill.load519, i64 0
  %.splat521 = shufflevector <8 x i1> %.splatinsert520, <8 x i1> poison, <8 x i32> zeroinitializer
  %1086 = select <8 x i1> %.splat521, <8 x float> %native.exp493, <8 x float> zeroinitializer
  %.spill.load522 = load i1, ptr %.spill73, align 1
  %.splatinsert523 = insertelement <8 x i1> poison, i1 %.spill.load522, i64 0
  %.splat524 = shufflevector <8 x i1> %.splatinsert523, <8 x i1> poison, <8 x i32> zeroinitializer
  %1087 = select <8 x i1> %.splat524, <8 x float> %native.exp494, <8 x float> zeroinitializer
  %.spill.load525 = load i1, ptr %.spill74, align 1
  %.splatinsert526 = insertelement <8 x i1> poison, i1 %.spill.load525, i64 0
  %.splat527 = shufflevector <8 x i1> %.splatinsert526, <8 x i1> poison, <8 x i32> zeroinitializer
  %1088 = select <8 x i1> %.splat527, <8 x float> %native.exp495, <8 x float> zeroinitializer
  %.spill.load528 = load i1, ptr %.spill75, align 1
  %.splatinsert529 = insertelement <8 x i1> poison, i1 %.spill.load528, i64 0
  %.splat530 = shufflevector <8 x i1> %.splatinsert529, <8 x i1> poison, <8 x i32> zeroinitializer
  %1089 = select <8 x i1> %.splat530, <8 x float> %native.exp496, <8 x float> zeroinitializer
  %.spill.load531 = load i1, ptr %.spill76, align 1
  %.splatinsert532 = insertelement <8 x i1> poison, i1 %.spill.load531, i64 0
  %.splat533 = shufflevector <8 x i1> %.splatinsert532, <8 x i1> poison, <8 x i32> zeroinitializer
  %1090 = select <8 x i1> %.splat533, <8 x float> %native.exp497, <8 x float> zeroinitializer
  %.spill.load534 = load i1, ptr %.spill77, align 1
  %.splatinsert535 = insertelement <8 x i1> poison, i1 %.spill.load534, i64 0
  %.splat536 = shufflevector <8 x i1> %.splatinsert535, <8 x i1> poison, <8 x i32> zeroinitializer
  %1091 = select <8 x i1> %.splat536, <8 x float> %native.exp498, <8 x float> zeroinitializer
  %.spill.load537 = load i1, ptr %.spill78, align 1
  %.splatinsert538 = insertelement <8 x i1> poison, i1 %.spill.load537, i64 0
  %.splat539 = shufflevector <8 x i1> %.splatinsert538, <8 x i1> poison, <8 x i32> zeroinitializer
  %1092 = select <8 x i1> %.splat539, <8 x float> %native.exp499, <8 x float> zeroinitializer
  %.spill.load540 = load i1, ptr %.spill79, align 1
  %.splatinsert541 = insertelement <8 x i1> poison, i1 %.spill.load540, i64 0
  %.splat542 = shufflevector <8 x i1> %.splatinsert541, <8 x i1> poison, <8 x i32> zeroinitializer
  %1093 = select <8 x i1> %.splat542, <8 x float> %native.exp500, <8 x float> zeroinitializer
  %.spill.load543 = load i1, ptr %.spill80, align 1
  %.splatinsert544 = insertelement <8 x i1> poison, i1 %.spill.load543, i64 0
  %.splat545 = shufflevector <8 x i1> %.splatinsert544, <8 x i1> poison, <8 x i32> zeroinitializer
  %1094 = select <8 x i1> %.splat545, <8 x float> %native.exp501, <8 x float> zeroinitializer
  %.spill.load546 = load i1, ptr %.spill81, align 1
  %.splatinsert547 = insertelement <8 x i1> poison, i1 %.spill.load546, i64 0
  %.splat548 = shufflevector <8 x i1> %.splatinsert547, <8 x i1> poison, <8 x i32> zeroinitializer
  %1095 = select <8 x i1> %.splat548, <8 x float> %native.exp502, <8 x float> zeroinitializer
  %.spill.load549 = load i1, ptr %.spill82, align 1
  %.splatinsert550 = insertelement <8 x i1> poison, i1 %.spill.load549, i64 0
  %.splat551 = shufflevector <8 x i1> %.splatinsert550, <8 x i1> poison, <8 x i32> zeroinitializer
  %1096 = select <8 x i1> %.splat551, <8 x float> %native.exp503, <8 x float> zeroinitializer
  %1097 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %1098 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1099 = extractvalue { <8 x ptr>, <8 x i64> } %1097, 0
  %1100 = select <8 x i1> %71, <8 x ptr> %1098, <8 x ptr> %1099
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %1097, 1
  %1103 = select <8 x i1> %71, <8 x i64> %1101, <8 x i64> %1102
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1100, 0
  %1105 = insertvalue { <8 x ptr>, <8 x i64> } %1104, <8 x i64> %1103, 1
  store { <8 x ptr>, <8 x i64> } %1105, ptr %tile_snapshot.spill104, align 64
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1108 = add <8 x i64> %1107, zeroinitializer
  %1109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1106, 0
  %1110 = insertvalue { <8 x ptr>, <8 x i64> } %1109, <8 x i64> %1108, 1
  %1111 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1112 = extractvalue { <8 x ptr>, <8 x i64> } %1110, 1
  %1113 = extractelement <8 x ptr> %1111, i32 0
  %1114 = extractelement <8 x i64> %1112, i32 0
  %1115 = sub i64 %1114, 0
  %1116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1117 = select i1 %1116, i64 %1115, i64 0
  %private.contiguous.address552 = getelementptr i8, ptr %1113, i64 %1117
  %private.contiguous.preserve553 = load <8 x float>, ptr %private.contiguous.address552, align 4
  %1118 = select <8 x i1> %71, <8 x float> %1081, <8 x float> %private.contiguous.preserve553
  store <8 x float> %1118, ptr %private.contiguous.address552, align 4
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1121 = add <8 x i64> %1120, splat (i64 32)
  %1122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1119, 0
  %1123 = insertvalue { <8 x ptr>, <8 x i64> } %1122, <8 x i64> %1121, 1
  %1124 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1125 = extractvalue { <8 x ptr>, <8 x i64> } %1123, 1
  %1126 = extractelement <8 x ptr> %1124, i32 0
  %1127 = extractelement <8 x i64> %1125, i32 0
  %1128 = sub i64 %1127, 0
  %1129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1130 = select i1 %1129, i64 %1128, i64 0
  %private.contiguous.address554 = getelementptr i8, ptr %1126, i64 %1130
  %private.contiguous.preserve555 = load <8 x float>, ptr %private.contiguous.address554, align 4
  %1131 = select <8 x i1> %71, <8 x float> %1082, <8 x float> %private.contiguous.preserve555
  store <8 x float> %1131, ptr %private.contiguous.address554, align 4
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1134 = add <8 x i64> %1133, splat (i64 64)
  %1135 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1132, 0
  %1136 = insertvalue { <8 x ptr>, <8 x i64> } %1135, <8 x i64> %1134, 1
  %1137 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1138 = extractvalue { <8 x ptr>, <8 x i64> } %1136, 1
  %1139 = extractelement <8 x ptr> %1137, i32 0
  %1140 = extractelement <8 x i64> %1138, i32 0
  %1141 = sub i64 %1140, 0
  %1142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1143 = select i1 %1142, i64 %1141, i64 0
  %private.contiguous.address556 = getelementptr i8, ptr %1139, i64 %1143
  %private.contiguous.preserve557 = load <8 x float>, ptr %private.contiguous.address556, align 4
  %1144 = select <8 x i1> %71, <8 x float> %1083, <8 x float> %private.contiguous.preserve557
  store <8 x float> %1144, ptr %private.contiguous.address556, align 4
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1147 = add <8 x i64> %1146, splat (i64 96)
  %1148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1145, 0
  %1149 = insertvalue { <8 x ptr>, <8 x i64> } %1148, <8 x i64> %1147, 1
  %1150 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1151 = extractvalue { <8 x ptr>, <8 x i64> } %1149, 1
  %1152 = extractelement <8 x ptr> %1150, i32 0
  %1153 = extractelement <8 x i64> %1151, i32 0
  %1154 = sub i64 %1153, 0
  %1155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1156 = select i1 %1155, i64 %1154, i64 0
  %private.contiguous.address558 = getelementptr i8, ptr %1152, i64 %1156
  %private.contiguous.preserve559 = load <8 x float>, ptr %private.contiguous.address558, align 4
  %1157 = select <8 x i1> %71, <8 x float> %1084, <8 x float> %private.contiguous.preserve559
  store <8 x float> %1157, ptr %private.contiguous.address558, align 4
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1160 = add <8 x i64> %1159, splat (i64 128)
  %1161 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1158, 0
  %1162 = insertvalue { <8 x ptr>, <8 x i64> } %1161, <8 x i64> %1160, 1
  %1163 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1164 = extractvalue { <8 x ptr>, <8 x i64> } %1162, 1
  %1165 = extractelement <8 x ptr> %1163, i32 0
  %1166 = extractelement <8 x i64> %1164, i32 0
  %1167 = sub i64 %1166, 0
  %1168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1169 = select i1 %1168, i64 %1167, i64 0
  %private.contiguous.address560 = getelementptr i8, ptr %1165, i64 %1169
  %private.contiguous.preserve561 = load <8 x float>, ptr %private.contiguous.address560, align 4
  %1170 = select <8 x i1> %71, <8 x float> %1085, <8 x float> %private.contiguous.preserve561
  store <8 x float> %1170, ptr %private.contiguous.address560, align 4
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1173 = add <8 x i64> %1172, splat (i64 160)
  %1174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1171, 0
  %1175 = insertvalue { <8 x ptr>, <8 x i64> } %1174, <8 x i64> %1173, 1
  %1176 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1177 = extractvalue { <8 x ptr>, <8 x i64> } %1175, 1
  %1178 = extractelement <8 x ptr> %1176, i32 0
  %1179 = extractelement <8 x i64> %1177, i32 0
  %1180 = sub i64 %1179, 0
  %1181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1182 = select i1 %1181, i64 %1180, i64 0
  %private.contiguous.address562 = getelementptr i8, ptr %1178, i64 %1182
  %private.contiguous.preserve563 = load <8 x float>, ptr %private.contiguous.address562, align 4
  %1183 = select <8 x i1> %71, <8 x float> %1086, <8 x float> %private.contiguous.preserve563
  store <8 x float> %1183, ptr %private.contiguous.address562, align 4
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1186 = add <8 x i64> %1185, splat (i64 192)
  %1187 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1184, 0
  %1188 = insertvalue { <8 x ptr>, <8 x i64> } %1187, <8 x i64> %1186, 1
  %1189 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1190 = extractvalue { <8 x ptr>, <8 x i64> } %1188, 1
  %1191 = extractelement <8 x ptr> %1189, i32 0
  %1192 = extractelement <8 x i64> %1190, i32 0
  %1193 = sub i64 %1192, 0
  %1194 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1195 = select i1 %1194, i64 %1193, i64 0
  %private.contiguous.address564 = getelementptr i8, ptr %1191, i64 %1195
  %private.contiguous.preserve565 = load <8 x float>, ptr %private.contiguous.address564, align 4
  %1196 = select <8 x i1> %71, <8 x float> %1087, <8 x float> %private.contiguous.preserve565
  store <8 x float> %1196, ptr %private.contiguous.address564, align 4
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1199 = add <8 x i64> %1198, splat (i64 224)
  %1200 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1197, 0
  %1201 = insertvalue { <8 x ptr>, <8 x i64> } %1200, <8 x i64> %1199, 1
  %1202 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1203 = extractvalue { <8 x ptr>, <8 x i64> } %1201, 1
  %1204 = extractelement <8 x ptr> %1202, i32 0
  %1205 = extractelement <8 x i64> %1203, i32 0
  %1206 = sub i64 %1205, 0
  %1207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1208 = select i1 %1207, i64 %1206, i64 0
  %private.contiguous.address566 = getelementptr i8, ptr %1204, i64 %1208
  %private.contiguous.preserve567 = load <8 x float>, ptr %private.contiguous.address566, align 4
  %1209 = select <8 x i1> %71, <8 x float> %1088, <8 x float> %private.contiguous.preserve567
  store <8 x float> %1209, ptr %private.contiguous.address566, align 4
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1211 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1212 = add <8 x i64> %1211, splat (i64 256)
  %1213 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1210, 0
  %1214 = insertvalue { <8 x ptr>, <8 x i64> } %1213, <8 x i64> %1212, 1
  %1215 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1216 = extractvalue { <8 x ptr>, <8 x i64> } %1214, 1
  %1217 = extractelement <8 x ptr> %1215, i32 0
  %1218 = extractelement <8 x i64> %1216, i32 0
  %1219 = sub i64 %1218, 0
  %1220 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1221 = select i1 %1220, i64 %1219, i64 0
  %private.contiguous.address568 = getelementptr i8, ptr %1217, i64 %1221
  %private.contiguous.preserve569 = load <8 x float>, ptr %private.contiguous.address568, align 4
  %1222 = select <8 x i1> %71, <8 x float> %1089, <8 x float> %private.contiguous.preserve569
  store <8 x float> %1222, ptr %private.contiguous.address568, align 4
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1224 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1225 = add <8 x i64> %1224, splat (i64 288)
  %1226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1223, 0
  %1227 = insertvalue { <8 x ptr>, <8 x i64> } %1226, <8 x i64> %1225, 1
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %1227, 1
  %1230 = extractelement <8 x ptr> %1228, i32 0
  %1231 = extractelement <8 x i64> %1229, i32 0
  %1232 = sub i64 %1231, 0
  %1233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1234 = select i1 %1233, i64 %1232, i64 0
  %private.contiguous.address570 = getelementptr i8, ptr %1230, i64 %1234
  %private.contiguous.preserve571 = load <8 x float>, ptr %private.contiguous.address570, align 4
  %1235 = select <8 x i1> %71, <8 x float> %1090, <8 x float> %private.contiguous.preserve571
  store <8 x float> %1235, ptr %private.contiguous.address570, align 4
  %1236 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1238 = add <8 x i64> %1237, splat (i64 320)
  %1239 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1236, 0
  %1240 = insertvalue { <8 x ptr>, <8 x i64> } %1239, <8 x i64> %1238, 1
  %1241 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1242 = extractvalue { <8 x ptr>, <8 x i64> } %1240, 1
  %1243 = extractelement <8 x ptr> %1241, i32 0
  %1244 = extractelement <8 x i64> %1242, i32 0
  %1245 = sub i64 %1244, 0
  %1246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1247 = select i1 %1246, i64 %1245, i64 0
  %private.contiguous.address572 = getelementptr i8, ptr %1243, i64 %1247
  %private.contiguous.preserve573 = load <8 x float>, ptr %private.contiguous.address572, align 4
  %1248 = select <8 x i1> %71, <8 x float> %1091, <8 x float> %private.contiguous.preserve573
  store <8 x float> %1248, ptr %private.contiguous.address572, align 4
  %1249 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1250 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1251 = add <8 x i64> %1250, splat (i64 352)
  %1252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1249, 0
  %1253 = insertvalue { <8 x ptr>, <8 x i64> } %1252, <8 x i64> %1251, 1
  %1254 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1255 = extractvalue { <8 x ptr>, <8 x i64> } %1253, 1
  %1256 = extractelement <8 x ptr> %1254, i32 0
  %1257 = extractelement <8 x i64> %1255, i32 0
  %1258 = sub i64 %1257, 0
  %1259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1260 = select i1 %1259, i64 %1258, i64 0
  %private.contiguous.address574 = getelementptr i8, ptr %1256, i64 %1260
  %private.contiguous.preserve575 = load <8 x float>, ptr %private.contiguous.address574, align 4
  %1261 = select <8 x i1> %71, <8 x float> %1092, <8 x float> %private.contiguous.preserve575
  store <8 x float> %1261, ptr %private.contiguous.address574, align 4
  %1262 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1264 = add <8 x i64> %1263, splat (i64 384)
  %1265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1262, 0
  %1266 = insertvalue { <8 x ptr>, <8 x i64> } %1265, <8 x i64> %1264, 1
  %1267 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1268 = extractvalue { <8 x ptr>, <8 x i64> } %1266, 1
  %1269 = extractelement <8 x ptr> %1267, i32 0
  %1270 = extractelement <8 x i64> %1268, i32 0
  %1271 = sub i64 %1270, 0
  %1272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1273 = select i1 %1272, i64 %1271, i64 0
  %private.contiguous.address576 = getelementptr i8, ptr %1269, i64 %1273
  %private.contiguous.preserve577 = load <8 x float>, ptr %private.contiguous.address576, align 4
  %1274 = select <8 x i1> %71, <8 x float> %1093, <8 x float> %private.contiguous.preserve577
  store <8 x float> %1274, ptr %private.contiguous.address576, align 4
  %1275 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1276 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1277 = add <8 x i64> %1276, splat (i64 416)
  %1278 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1275, 0
  %1279 = insertvalue { <8 x ptr>, <8 x i64> } %1278, <8 x i64> %1277, 1
  %1280 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1281 = extractvalue { <8 x ptr>, <8 x i64> } %1279, 1
  %1282 = extractelement <8 x ptr> %1280, i32 0
  %1283 = extractelement <8 x i64> %1281, i32 0
  %1284 = sub i64 %1283, 0
  %1285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1286 = select i1 %1285, i64 %1284, i64 0
  %private.contiguous.address578 = getelementptr i8, ptr %1282, i64 %1286
  %private.contiguous.preserve579 = load <8 x float>, ptr %private.contiguous.address578, align 4
  %1287 = select <8 x i1> %71, <8 x float> %1094, <8 x float> %private.contiguous.preserve579
  store <8 x float> %1287, ptr %private.contiguous.address578, align 4
  %1288 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1289 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1290 = add <8 x i64> %1289, splat (i64 448)
  %1291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1288, 0
  %1292 = insertvalue { <8 x ptr>, <8 x i64> } %1291, <8 x i64> %1290, 1
  %1293 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1294 = extractvalue { <8 x ptr>, <8 x i64> } %1292, 1
  %1295 = extractelement <8 x ptr> %1293, i32 0
  %1296 = extractelement <8 x i64> %1294, i32 0
  %1297 = sub i64 %1296, 0
  %1298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1299 = select i1 %1298, i64 %1297, i64 0
  %private.contiguous.address580 = getelementptr i8, ptr %1295, i64 %1299
  %private.contiguous.preserve581 = load <8 x float>, ptr %private.contiguous.address580, align 4
  %1300 = select <8 x i1> %71, <8 x float> %1095, <8 x float> %private.contiguous.preserve581
  store <8 x float> %1300, ptr %private.contiguous.address580, align 4
  %1301 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1302 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1303 = add <8 x i64> %1302, splat (i64 480)
  %1304 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1301, 0
  %1305 = insertvalue { <8 x ptr>, <8 x i64> } %1304, <8 x i64> %1303, 1
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1307 = extractvalue { <8 x ptr>, <8 x i64> } %1305, 1
  %1308 = extractelement <8 x ptr> %1306, i32 0
  %1309 = extractelement <8 x i64> %1307, i32 0
  %1310 = sub i64 %1309, 0
  %1311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1312 = select i1 %1311, i64 %1310, i64 0
  %private.contiguous.address582 = getelementptr i8, ptr %1308, i64 %1312
  %private.contiguous.preserve583 = load <8 x float>, ptr %private.contiguous.address582, align 4
  %1313 = select <8 x i1> %71, <8 x float> %1096, <8 x float> %private.contiguous.preserve583
  store <8 x float> %1313, ptr %private.contiguous.address582, align 4
  %.state584 = load <8 x float>, ptr %.slot36, align 32
  %1314 = fmul <8 x float> %.state584, %native.exp
  %1315 = load <8 x float>, ptr %.spill105, align 32
  %1316 = select <8 x i1> %71, <8 x float> %1314, <8 x float> %1315
  store <8 x float> %1316, ptr %.spill105, align 32
  store i64 0, ptr %.slot106, align 4
  %1317 = load <8 x float>, ptr %.slot107, align 32
  %1318 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1317
  store <8 x float> %1318, ptr %.slot107, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state585 = load i64, ptr %.slot106, align 4
  %1319 = icmp slt i64 %.state585, 16
  br i1 %1319, label %direct.true586, label %direct.false587

direct.schedule.35:                               ; preds = %direct.true586
  %.state588 = load i64, ptr %.slot106, align 4
  %1320 = sdiv i64 %.state588, 1
  %.spill.load589 = load i64, ptr %.spill66, align 4
  %1321 = mul i64 %.spill.load589, 1
  %1322 = add i64 %1321, 0
  %1323 = mul i64 %1322, 1
  %1324 = add i64 %1323, 0
  %1325 = mul i64 %1324, 16
  %1326 = add i64 %1325, %1320
  %tile_snapshot.spill.load590 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %1327 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load590, 0
  %1328 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load590, 1
  %.splatinsert591 = insertelement <8 x i64> poison, i64 %1326, i64 0
  %.splat592 = shufflevector <8 x i64> %.splatinsert591, <8 x i64> poison, <8 x i32> zeroinitializer
  %1329 = mul <8 x i64> %.splat592, splat (i64 32)
  %1330 = add <8 x i64> %1328, %1329
  %1331 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1327, 0
  %1332 = insertvalue { <8 x ptr>, <8 x i64> } %1331, <8 x i64> %1330, 1
  %1333 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1334 = extractvalue { <8 x ptr>, <8 x i64> } %1332, 1
  %1335 = extractelement <8 x ptr> %1333, i32 0
  %1336 = extractelement <8 x i64> %1334, i32 0
  %1337 = sub i64 %1336, 0
  %1338 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1339 = select i1 %1338, i64 %1337, i64 0
  %private.contiguous.address593 = getelementptr i8, ptr %1335, i64 %1339
  %private.contiguous.load594 = load <8 x float>, ptr %private.contiguous.address593, align 4
  %1340 = select <8 x i1> %71, <8 x float> %private.contiguous.load594, <8 x float> zeroinitializer
  %.state595 = load <8 x float>, ptr %.slot107, align 32
  %1341 = fadd <8 x float> %.state595, %1340
  %.state596 = load i64, ptr %.slot106, align 4
  %1342 = add i64 %.state596, 1
  store i64 %1342, ptr %.slot106, align 4
  %1343 = load <8 x float>, ptr %.slot107, align 32
  %1344 = select <8 x i1> %71, <8 x float> %1341, <8 x float> %1343
  store <8 x float> %1344, ptr %.slot107, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false587
  %.spill.load597 = load <8 x float>, ptr %.spill105, align 32
  %.state598 = load <8 x float>, ptr %.slot107, align 32
  %1345 = fadd <8 x float> %.spill.load597, %.state598
  %1346 = load <8 x float>, ptr %.spill108, align 32
  %1347 = select <8 x i1> %71, <8 x float> %1345, <8 x float> %1346
  store <8 x float> %1347, ptr %.spill108, align 32
  %1348 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill109, align 64
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %1348, 0
  %1351 = select <8 x i1> %71, <8 x ptr> %1349, <8 x ptr> %1350
  %1352 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1353 = extractvalue { <8 x ptr>, <8 x i64> } %1348, 1
  %1354 = select <8 x i1> %71, <8 x i64> %1352, <8 x i64> %1353
  %1355 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1351, 0
  %1356 = insertvalue { <8 x ptr>, <8 x i64> } %1355, <8 x i64> %1354, 1
  store { <8 x ptr>, <8 x i64> } %1356, ptr %tile_snapshot.spill109, align 64
  store i64 0, ptr %.slot110, align 4
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.41, %direct.schedule.36
  %.state599 = load i64, ptr %.slot110, align 4
  %1357 = icmp slt i64 %.state599, 24
  br i1 %1357, label %direct.true600, label %direct.false601

direct.schedule.38:                               ; preds = %direct.true600
  %.state602 = load i64, ptr %.slot110, align 4
  %1358 = mul i64 %.state602, 4
  %1359 = add i64 0, %1358
  %1360 = add i64 %1359, 0
  store i64 %1360, ptr %.spill111, align 4
  %1361 = add i64 0, %1360
  %tile_snapshot.spill.load603 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1362 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load603, 0
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load603, 1
  %.splatinsert604 = insertelement <8 x i64> poison, i64 %1361, i64 0
  %.splat605 = shufflevector <8 x i64> %.splatinsert604, <8 x i64> poison, <8 x i32> zeroinitializer
  %1364 = mul <8 x i64> %.splat605, splat (i64 32)
  %1365 = add <8 x i64> %1363, %1364
  %1366 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1362, 0
  %1367 = insertvalue { <8 x ptr>, <8 x i64> } %1366, <8 x i64> %1365, 1
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %1367, 1
  %1370 = extractelement <8 x ptr> %1368, i32 0
  %1371 = extractelement <8 x i64> %1369, i32 0
  %1372 = sub i64 %1371, 0
  %1373 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1374 = select i1 %1373, i64 %1372, i64 0
  %private.contiguous.address606 = getelementptr i8, ptr %1370, i64 %1374
  %private.contiguous.load607 = load <8 x float>, ptr %private.contiguous.address606, align 4
  %1375 = select <8 x i1> %71, <8 x float> %private.contiguous.load607, <8 x float> zeroinitializer
  %.spill.load608 = load <8 x float>, ptr %.spill103, align 32
  %1376 = fmul <8 x float> %1375, %.spill.load608
  %1377 = add i64 %1359, 1
  store i64 %1377, ptr %.spill112, align 4
  %1378 = add i64 0, %1377
  %tile_snapshot.spill.load609 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1379 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load609, 0
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load609, 1
  %.splatinsert610 = insertelement <8 x i64> poison, i64 %1378, i64 0
  %.splat611 = shufflevector <8 x i64> %.splatinsert610, <8 x i64> poison, <8 x i32> zeroinitializer
  %1381 = mul <8 x i64> %.splat611, splat (i64 32)
  %1382 = add <8 x i64> %1380, %1381
  %1383 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1379, 0
  %1384 = insertvalue { <8 x ptr>, <8 x i64> } %1383, <8 x i64> %1382, 1
  %1385 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %1384, 1
  %1387 = extractelement <8 x ptr> %1385, i32 0
  %1388 = extractelement <8 x i64> %1386, i32 0
  %1389 = sub i64 %1388, 0
  %1390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1391 = select i1 %1390, i64 %1389, i64 0
  %private.contiguous.address612 = getelementptr i8, ptr %1387, i64 %1391
  %private.contiguous.load613 = load <8 x float>, ptr %private.contiguous.address612, align 4
  %1392 = select <8 x i1> %71, <8 x float> %private.contiguous.load613, <8 x float> zeroinitializer
  %.spill.load614 = load <8 x float>, ptr %.spill103, align 32
  %1393 = fmul <8 x float> %1392, %.spill.load614
  %1394 = add i64 %1359, 2
  store i64 %1394, ptr %.spill113, align 4
  %1395 = add i64 0, %1394
  %tile_snapshot.spill.load615 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load615, 0
  %1397 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load615, 1
  %.splatinsert616 = insertelement <8 x i64> poison, i64 %1395, i64 0
  %.splat617 = shufflevector <8 x i64> %.splatinsert616, <8 x i64> poison, <8 x i32> zeroinitializer
  %1398 = mul <8 x i64> %.splat617, splat (i64 32)
  %1399 = add <8 x i64> %1397, %1398
  %1400 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1396, 0
  %1401 = insertvalue { <8 x ptr>, <8 x i64> } %1400, <8 x i64> %1399, 1
  %1402 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1403 = extractvalue { <8 x ptr>, <8 x i64> } %1401, 1
  %1404 = extractelement <8 x ptr> %1402, i32 0
  %1405 = extractelement <8 x i64> %1403, i32 0
  %1406 = sub i64 %1405, 0
  %1407 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1408 = select i1 %1407, i64 %1406, i64 0
  %private.contiguous.address618 = getelementptr i8, ptr %1404, i64 %1408
  %private.contiguous.load619 = load <8 x float>, ptr %private.contiguous.address618, align 4
  %1409 = select <8 x i1> %71, <8 x float> %private.contiguous.load619, <8 x float> zeroinitializer
  %.spill.load620 = load <8 x float>, ptr %.spill103, align 32
  %1410 = fmul <8 x float> %1409, %.spill.load620
  %1411 = add i64 %1359, 3
  store i64 %1411, ptr %.spill114, align 4
  %1412 = add i64 0, %1411
  %tile_snapshot.spill.load621 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1413 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load621, 0
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load621, 1
  %.splatinsert622 = insertelement <8 x i64> poison, i64 %1412, i64 0
  %.splat623 = shufflevector <8 x i64> %.splatinsert622, <8 x i64> poison, <8 x i32> zeroinitializer
  %1415 = mul <8 x i64> %.splat623, splat (i64 32)
  %1416 = add <8 x i64> %1414, %1415
  %1417 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1413, 0
  %1418 = insertvalue { <8 x ptr>, <8 x i64> } %1417, <8 x i64> %1416, 1
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %1418, 1
  %1421 = extractelement <8 x ptr> %1419, i32 0
  %1422 = extractelement <8 x i64> %1420, i32 0
  %1423 = sub i64 %1422, 0
  %1424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1425 = select i1 %1424, i64 %1423, i64 0
  %private.contiguous.address624 = getelementptr i8, ptr %1421, i64 %1425
  %private.contiguous.load625 = load <8 x float>, ptr %private.contiguous.address624, align 4
  %1426 = select <8 x i1> %71, <8 x float> %private.contiguous.load625, <8 x float> zeroinitializer
  %.spill.load626 = load <8 x float>, ptr %.spill103, align 32
  %1427 = fmul <8 x float> %1426, %.spill.load626
  store i64 0, ptr %.slot115, align 4
  %1428 = load <8 x float>, ptr %.slot116, align 32
  %1429 = select <8 x i1> %71, <8 x float> %1376, <8 x float> %1428
  store <8 x float> %1429, ptr %.slot116, align 32
  %1430 = load <8 x float>, ptr %.slot117, align 32
  %1431 = select <8 x i1> %71, <8 x float> %1393, <8 x float> %1430
  store <8 x float> %1431, ptr %.slot117, align 32
  %1432 = load <8 x float>, ptr %.slot118, align 32
  %1433 = select <8 x i1> %71, <8 x float> %1410, <8 x float> %1432
  store <8 x float> %1433, ptr %.slot118, align 32
  %1434 = load <8 x float>, ptr %.slot119, align 32
  %1435 = select <8 x i1> %71, <8 x float> %1427, <8 x float> %1434
  store <8 x float> %1435, ptr %.slot119, align 32
  br label %direct.schedule.39

direct.schedule.39:                               ; preds = %direct.schedule.40, %direct.schedule.38
  %.state627 = load i64, ptr %.slot115, align 4
  %1436 = icmp slt i64 %.state627, 16
  br i1 %1436, label %direct.true628, label %direct.false629

direct.schedule.40:                               ; preds = %direct.true628
  %.state630 = load i64, ptr %.slot115, align 4
  %1437 = add i64 0, %.state630
  %tile_snapshot.spill.load631 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %1438 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load631, 0
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load631, 1
  %.splatinsert632 = insertelement <8 x i64> poison, i64 %1437, i64 0
  %.splat633 = shufflevector <8 x i64> %.splatinsert632, <8 x i64> poison, <8 x i32> zeroinitializer
  %1440 = mul <8 x i64> %.splat633, splat (i64 32)
  %1441 = add <8 x i64> %1439, %1440
  %1442 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1438, 0
  %1443 = insertvalue { <8 x ptr>, <8 x i64> } %1442, <8 x i64> %1441, 1
  %1444 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1445 = extractvalue { <8 x ptr>, <8 x i64> } %1443, 1
  %1446 = extractelement <8 x ptr> %1444, i32 0
  %1447 = extractelement <8 x i64> %1445, i32 0
  %1448 = sub i64 %1447, 0
  %1449 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1450 = select i1 %1449, i64 %1448, i64 0
  %private.contiguous.address634 = getelementptr i8, ptr %1446, i64 %1450
  %private.contiguous.load635 = load <8 x float>, ptr %private.contiguous.address634, align 4
  %1451 = select <8 x i1> %71, <8 x float> %private.contiguous.load635, <8 x float> zeroinitializer
  %1452 = mul i64 %1437, 96
  %.spill.load636 = load i64, ptr %.spill111, align 4
  %1453 = add i64 %1452, %.spill.load636
  %tile_snapshot.spill.load637 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load637, 0
  %1455 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load637, 1
  %.splatinsert638 = insertelement <8 x i64> poison, i64 %1453, i64 0
  %.splat639 = shufflevector <8 x i64> %.splatinsert638, <8 x i64> poison, <8 x i32> zeroinitializer
  %1456 = mul <8 x i64> %.splat639, splat (i64 32)
  %1457 = add <8 x i64> %1455, %1456
  %1458 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1454, 0
  %1459 = insertvalue { <8 x ptr>, <8 x i64> } %1458, <8 x i64> %1457, 1
  %1460 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1461 = extractvalue { <8 x ptr>, <8 x i64> } %1459, 1
  %1462 = extractelement <8 x ptr> %1460, i32 0
  %1463 = extractelement <8 x i64> %1461, i32 0
  %1464 = sub i64 %1463, 0
  %1465 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1466 = select i1 %1465, i64 %1464, i64 0
  %private.contiguous.address640 = getelementptr i8, ptr %1462, i64 %1466
  %private.contiguous.load641 = load <8 x float>, ptr %private.contiguous.address640, align 4
  %1467 = select <8 x i1> %71, <8 x float> %private.contiguous.load641, <8 x float> zeroinitializer
  %1468 = fmul <8 x float> %1451, %1467
  %.state642 = load <8 x float>, ptr %.slot116, align 32
  %1469 = fadd <8 x float> %.state642, %1468
  %.spill.load643 = load i64, ptr %.spill112, align 4
  %1470 = add i64 %1452, %.spill.load643
  %tile_snapshot.spill.load644 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load644, 0
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load644, 1
  %.splatinsert645 = insertelement <8 x i64> poison, i64 %1470, i64 0
  %.splat646 = shufflevector <8 x i64> %.splatinsert645, <8 x i64> poison, <8 x i32> zeroinitializer
  %1473 = mul <8 x i64> %.splat646, splat (i64 32)
  %1474 = add <8 x i64> %1472, %1473
  %1475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1471, 0
  %1476 = insertvalue { <8 x ptr>, <8 x i64> } %1475, <8 x i64> %1474, 1
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1478 = extractvalue { <8 x ptr>, <8 x i64> } %1476, 1
  %1479 = extractelement <8 x ptr> %1477, i32 0
  %1480 = extractelement <8 x i64> %1478, i32 0
  %1481 = sub i64 %1480, 0
  %1482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1483 = select i1 %1482, i64 %1481, i64 0
  %private.contiguous.address647 = getelementptr i8, ptr %1479, i64 %1483
  %private.contiguous.load648 = load <8 x float>, ptr %private.contiguous.address647, align 4
  %1484 = select <8 x i1> %71, <8 x float> %private.contiguous.load648, <8 x float> zeroinitializer
  %1485 = fmul <8 x float> %1451, %1484
  %.state649 = load <8 x float>, ptr %.slot117, align 32
  %1486 = fadd <8 x float> %.state649, %1485
  %.spill.load650 = load i64, ptr %.spill113, align 4
  %1487 = add i64 %1452, %.spill.load650
  %tile_snapshot.spill.load651 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1488 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load651, 0
  %1489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load651, 1
  %.splatinsert652 = insertelement <8 x i64> poison, i64 %1487, i64 0
  %.splat653 = shufflevector <8 x i64> %.splatinsert652, <8 x i64> poison, <8 x i32> zeroinitializer
  %1490 = mul <8 x i64> %.splat653, splat (i64 32)
  %1491 = add <8 x i64> %1489, %1490
  %1492 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1488, 0
  %1493 = insertvalue { <8 x ptr>, <8 x i64> } %1492, <8 x i64> %1491, 1
  %1494 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1495 = extractvalue { <8 x ptr>, <8 x i64> } %1493, 1
  %1496 = extractelement <8 x ptr> %1494, i32 0
  %1497 = extractelement <8 x i64> %1495, i32 0
  %1498 = sub i64 %1497, 0
  %1499 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1500 = select i1 %1499, i64 %1498, i64 0
  %private.contiguous.address654 = getelementptr i8, ptr %1496, i64 %1500
  %private.contiguous.load655 = load <8 x float>, ptr %private.contiguous.address654, align 4
  %1501 = select <8 x i1> %71, <8 x float> %private.contiguous.load655, <8 x float> zeroinitializer
  %1502 = fmul <8 x float> %1451, %1501
  %.state656 = load <8 x float>, ptr %.slot118, align 32
  %1503 = fadd <8 x float> %.state656, %1502
  %.spill.load657 = load i64, ptr %.spill114, align 4
  %1504 = add i64 %1452, %.spill.load657
  %tile_snapshot.spill.load658 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1505 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 0
  %1506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 1
  %.splatinsert659 = insertelement <8 x i64> poison, i64 %1504, i64 0
  %.splat660 = shufflevector <8 x i64> %.splatinsert659, <8 x i64> poison, <8 x i32> zeroinitializer
  %1507 = mul <8 x i64> %.splat660, splat (i64 32)
  %1508 = add <8 x i64> %1506, %1507
  %1509 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1505, 0
  %1510 = insertvalue { <8 x ptr>, <8 x i64> } %1509, <8 x i64> %1508, 1
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1512 = extractvalue { <8 x ptr>, <8 x i64> } %1510, 1
  %1513 = extractelement <8 x ptr> %1511, i32 0
  %1514 = extractelement <8 x i64> %1512, i32 0
  %1515 = sub i64 %1514, 0
  %1516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1517 = select i1 %1516, i64 %1515, i64 0
  %private.contiguous.address661 = getelementptr i8, ptr %1513, i64 %1517
  %private.contiguous.load662 = load <8 x float>, ptr %private.contiguous.address661, align 4
  %1518 = select <8 x i1> %71, <8 x float> %private.contiguous.load662, <8 x float> zeroinitializer
  %1519 = fmul <8 x float> %1451, %1518
  %.state663 = load <8 x float>, ptr %.slot119, align 32
  %1520 = fadd <8 x float> %.state663, %1519
  %.state664 = load i64, ptr %.slot115, align 4
  %1521 = add i64 %.state664, 1
  store i64 %1521, ptr %.slot115, align 4
  %1522 = load <8 x float>, ptr %.slot116, align 32
  %1523 = select <8 x i1> %71, <8 x float> %1469, <8 x float> %1522
  store <8 x float> %1523, ptr %.slot116, align 32
  %1524 = load <8 x float>, ptr %.slot117, align 32
  %1525 = select <8 x i1> %71, <8 x float> %1486, <8 x float> %1524
  store <8 x float> %1525, ptr %.slot117, align 32
  %1526 = load <8 x float>, ptr %.slot118, align 32
  %1527 = select <8 x i1> %71, <8 x float> %1503, <8 x float> %1526
  store <8 x float> %1527, ptr %.slot118, align 32
  %1528 = load <8 x float>, ptr %.slot119, align 32
  %1529 = select <8 x i1> %71, <8 x float> %1520, <8 x float> %1528
  store <8 x float> %1529, ptr %.slot119, align 32
  br label %direct.schedule.39

direct.schedule.41:                               ; preds = %direct.false629
  %tile_snapshot.spill.load665 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill109, align 64
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load665, 0
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load665, 1
  %.spill.load666 = load i64, ptr %.spill111, align 4
  %.splatinsert667 = insertelement <8 x i64> poison, i64 %.spill.load666, i64 0
  %.splat668 = shufflevector <8 x i64> %.splatinsert667, <8 x i64> poison, <8 x i32> zeroinitializer
  %1532 = mul <8 x i64> %.splat668, splat (i64 32)
  %1533 = add <8 x i64> %1531, %1532
  %1534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1530, 0
  %1535 = insertvalue { <8 x ptr>, <8 x i64> } %1534, <8 x i64> %1533, 1
  %.state669 = load <8 x float>, ptr %.slot116, align 32
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %1535, 1
  %1538 = extractelement <8 x ptr> %1536, i32 0
  %1539 = extractelement <8 x i64> %1537, i32 0
  %1540 = sub i64 %1539, 0
  %1541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1542 = select i1 %1541, i64 %1540, i64 0
  %private.contiguous.address670 = getelementptr i8, ptr %1538, i64 %1542
  %private.contiguous.preserve671 = load <8 x float>, ptr %private.contiguous.address670, align 4
  %1543 = select <8 x i1> %71, <8 x float> %.state669, <8 x float> %private.contiguous.preserve671
  store <8 x float> %1543, ptr %private.contiguous.address670, align 4
  %tile_snapshot.spill.load672 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill109, align 64
  %1544 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load672, 0
  %1545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load672, 1
  %.spill.load673 = load i64, ptr %.spill112, align 4
  %.splatinsert674 = insertelement <8 x i64> poison, i64 %.spill.load673, i64 0
  %.splat675 = shufflevector <8 x i64> %.splatinsert674, <8 x i64> poison, <8 x i32> zeroinitializer
  %1546 = mul <8 x i64> %.splat675, splat (i64 32)
  %1547 = add <8 x i64> %1545, %1546
  %1548 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1544, 0
  %1549 = insertvalue { <8 x ptr>, <8 x i64> } %1548, <8 x i64> %1547, 1
  %.state676 = load <8 x float>, ptr %.slot117, align 32
  %1550 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1551 = extractvalue { <8 x ptr>, <8 x i64> } %1549, 1
  %1552 = extractelement <8 x ptr> %1550, i32 0
  %1553 = extractelement <8 x i64> %1551, i32 0
  %1554 = sub i64 %1553, 0
  %1555 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1556 = select i1 %1555, i64 %1554, i64 0
  %private.contiguous.address677 = getelementptr i8, ptr %1552, i64 %1556
  %private.contiguous.preserve678 = load <8 x float>, ptr %private.contiguous.address677, align 4
  %1557 = select <8 x i1> %71, <8 x float> %.state676, <8 x float> %private.contiguous.preserve678
  store <8 x float> %1557, ptr %private.contiguous.address677, align 4
  %tile_snapshot.spill.load679 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill109, align 64
  %1558 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load679, 0
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load679, 1
  %.spill.load680 = load i64, ptr %.spill113, align 4
  %.splatinsert681 = insertelement <8 x i64> poison, i64 %.spill.load680, i64 0
  %.splat682 = shufflevector <8 x i64> %.splatinsert681, <8 x i64> poison, <8 x i32> zeroinitializer
  %1560 = mul <8 x i64> %.splat682, splat (i64 32)
  %1561 = add <8 x i64> %1559, %1560
  %1562 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1558, 0
  %1563 = insertvalue { <8 x ptr>, <8 x i64> } %1562, <8 x i64> %1561, 1
  %.state683 = load <8 x float>, ptr %.slot118, align 32
  %1564 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1565 = extractvalue { <8 x ptr>, <8 x i64> } %1563, 1
  %1566 = extractelement <8 x ptr> %1564, i32 0
  %1567 = extractelement <8 x i64> %1565, i32 0
  %1568 = sub i64 %1567, 0
  %1569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1570 = select i1 %1569, i64 %1568, i64 0
  %private.contiguous.address684 = getelementptr i8, ptr %1566, i64 %1570
  %private.contiguous.preserve685 = load <8 x float>, ptr %private.contiguous.address684, align 4
  %1571 = select <8 x i1> %71, <8 x float> %.state683, <8 x float> %private.contiguous.preserve685
  store <8 x float> %1571, ptr %private.contiguous.address684, align 4
  %tile_snapshot.spill.load686 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill109, align 64
  %1572 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load686, 0
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load686, 1
  %.spill.load687 = load i64, ptr %.spill114, align 4
  %.splatinsert688 = insertelement <8 x i64> poison, i64 %.spill.load687, i64 0
  %.splat689 = shufflevector <8 x i64> %.splatinsert688, <8 x i64> poison, <8 x i32> zeroinitializer
  %1574 = mul <8 x i64> %.splat689, splat (i64 32)
  %1575 = add <8 x i64> %1573, %1574
  %1576 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1572, 0
  %1577 = insertvalue { <8 x ptr>, <8 x i64> } %1576, <8 x i64> %1575, 1
  %.state690 = load <8 x float>, ptr %.slot119, align 32
  %1578 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1579 = extractvalue { <8 x ptr>, <8 x i64> } %1577, 1
  %1580 = extractelement <8 x ptr> %1578, i32 0
  %1581 = extractelement <8 x i64> %1579, i32 0
  %1582 = sub i64 %1581, 0
  %1583 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1584 = select i1 %1583, i64 %1582, i64 0
  %private.contiguous.address691 = getelementptr i8, ptr %1580, i64 %1584
  %private.contiguous.preserve692 = load <8 x float>, ptr %private.contiguous.address691, align 4
  %1585 = select <8 x i1> %71, <8 x float> %.state690, <8 x float> %private.contiguous.preserve692
  store <8 x float> %1585, ptr %private.contiguous.address691, align 4
  %.state693 = load i64, ptr %.slot110, align 4
  %1586 = add i64 %.state693, 1
  store i64 %1586, ptr %.slot110, align 4
  br label %direct.schedule.37

direct.schedule.42:                               ; preds = %direct.false601
  store i64 0, ptr %.slot120, align 4
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state694 = load i64, ptr %.slot120, align 4
  %1587 = icmp slt i64 %.state694, 96
  br i1 %1587, label %direct.true695, label %direct.false696

direct.schedule.44:                               ; preds = %direct.true695
  %tile_snapshot.spill.load697 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill109, align 64
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load697, 0
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load697, 1
  %.state698 = load i64, ptr %.slot120, align 4
  %.splatinsert699 = insertelement <8 x i64> poison, i64 %.state698, i64 0
  %.splat700 = shufflevector <8 x i64> %.splatinsert699, <8 x i64> poison, <8 x i32> zeroinitializer
  %1590 = mul <8 x i64> %.splat700, splat (i64 32)
  %1591 = add <8 x i64> %1589, %1590
  %1592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1588, 0
  %1593 = insertvalue { <8 x ptr>, <8 x i64> } %1592, <8 x i64> %1591, 1
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1595 = extractvalue { <8 x ptr>, <8 x i64> } %1593, 1
  %1596 = extractelement <8 x ptr> %1594, i32 0
  %1597 = extractelement <8 x i64> %1595, i32 0
  %1598 = sub i64 %1597, 0
  %1599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1600 = select i1 %1599, i64 %1598, i64 0
  %private.contiguous.address701 = getelementptr i8, ptr %1596, i64 %1600
  %private.contiguous.load702 = load <8 x float>, ptr %private.contiguous.address701, align 4
  %1601 = select <8 x i1> %71, <8 x float> %private.contiguous.load702, <8 x float> zeroinitializer
  %tile_snapshot.spill.load703 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1602 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 0
  %1603 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 1
  %.state704 = load i64, ptr %.slot120, align 4
  %.splatinsert705 = insertelement <8 x i64> poison, i64 %.state704, i64 0
  %.splat706 = shufflevector <8 x i64> %.splatinsert705, <8 x i64> poison, <8 x i32> zeroinitializer
  %1604 = mul <8 x i64> %.splat706, splat (i64 32)
  %1605 = add <8 x i64> %1603, %1604
  %1606 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1602, 0
  %1607 = insertvalue { <8 x ptr>, <8 x i64> } %1606, <8 x i64> %1605, 1
  %1608 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1609 = extractvalue { <8 x ptr>, <8 x i64> } %1607, 1
  %1610 = extractelement <8 x ptr> %1608, i32 0
  %1611 = extractelement <8 x i64> %1609, i32 0
  %1612 = sub i64 %1611, 0
  %1613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1614 = select i1 %1613, i64 %1612, i64 0
  %private.contiguous.address707 = getelementptr i8, ptr %1610, i64 %1614
  %private.contiguous.preserve708 = load <8 x float>, ptr %private.contiguous.address707, align 4
  %1615 = select <8 x i1> %71, <8 x float> %1601, <8 x float> %private.contiguous.preserve708
  store <8 x float> %1615, ptr %private.contiguous.address707, align 4
  %.state709 = load i64, ptr %.slot120, align 4
  %1616 = add i64 %.state709, 1
  store i64 %1616, ptr %.slot120, align 4
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false696
  store i64 0, ptr %.slot121, align 4
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state710 = load i64, ptr %.slot121, align 4
  %1617 = icmp slt i64 %.state710, 96
  br i1 %1617, label %direct.true711, label %direct.false712

direct.schedule.47:                               ; preds = %direct.true711
  %tile_snapshot.spill.load713 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load713, 0
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load713, 1
  %.state714 = load i64, ptr %.slot121, align 4
  %.splatinsert715 = insertelement <8 x i64> poison, i64 %.state714, i64 0
  %.splat716 = shufflevector <8 x i64> %.splatinsert715, <8 x i64> poison, <8 x i32> zeroinitializer
  %1620 = mul <8 x i64> %.splat716, splat (i64 32)
  %1621 = add <8 x i64> %1619, %1620
  %1622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1618, 0
  %1623 = insertvalue { <8 x ptr>, <8 x i64> } %1622, <8 x i64> %1621, 1
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1625 = extractvalue { <8 x ptr>, <8 x i64> } %1623, 1
  %1626 = extractelement <8 x ptr> %1624, i32 0
  %1627 = extractelement <8 x i64> %1625, i32 0
  %1628 = sub i64 %1627, 0
  %1629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1630 = select i1 %1629, i64 %1628, i64 0
  %private.contiguous.address717 = getelementptr i8, ptr %1626, i64 %1630
  %private.contiguous.load718 = load <8 x float>, ptr %private.contiguous.address717, align 4
  %1631 = select <8 x i1> %71, <8 x float> %private.contiguous.load718, <8 x float> zeroinitializer
  %tile_snapshot.spill.load719 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load719, 0
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load719, 1
  %.state720 = load i64, ptr %.slot121, align 4
  %.splatinsert721 = insertelement <8 x i64> poison, i64 %.state720, i64 0
  %.splat722 = shufflevector <8 x i64> %.splatinsert721, <8 x i64> poison, <8 x i32> zeroinitializer
  %1634 = mul <8 x i64> %.splat722, splat (i64 32)
  %1635 = add <8 x i64> %1633, %1634
  %1636 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1632, 0
  %1637 = insertvalue { <8 x ptr>, <8 x i64> } %1636, <8 x i64> %1635, 1
  %1638 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1639 = extractvalue { <8 x ptr>, <8 x i64> } %1637, 1
  %1640 = extractelement <8 x ptr> %1638, i32 0
  %1641 = extractelement <8 x i64> %1639, i32 0
  %1642 = sub i64 %1641, 0
  %1643 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1644 = select i1 %1643, i64 %1642, i64 0
  %private.contiguous.address723 = getelementptr i8, ptr %1640, i64 %1644
  %private.contiguous.preserve724 = load <8 x float>, ptr %private.contiguous.address723, align 4
  %1645 = select <8 x i1> %71, <8 x float> %1631, <8 x float> %private.contiguous.preserve724
  store <8 x float> %1645, ptr %private.contiguous.address723, align 4
  %.state725 = load i64, ptr %.slot121, align 4
  %1646 = add i64 %.state725, 1
  store i64 %1646, ptr %.slot121, align 4
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false712
  %.state726 = load i64, ptr %.slot34, align 4
  %1647 = add i64 %.state726, 1
  %.spill.load727 = load <8 x float>, ptr %.spill102, align 32
  %.spill.load728 = load <8 x float>, ptr %.spill108, align 32
  store i64 %1647, ptr %.slot34, align 4
  %1648 = load <8 x float>, ptr %.slot35, align 32
  %1649 = select <8 x i1> %71, <8 x float> %.spill.load727, <8 x float> %1648
  store <8 x float> %1649, ptr %.slot35, align 32
  %1650 = load <8 x float>, ptr %.slot36, align 32
  %1651 = select <8 x i1> %71, <8 x float> %.spill.load728, <8 x float> %1650
  store <8 x float> %1651, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.49:                               ; preds = %direct.false158
  store i64 0, ptr %.slot122, align 4
  br label %direct.schedule.50

direct.schedule.50:                               ; preds = %direct.schedule.51, %direct.schedule.49
  %.state729 = load i64, ptr %.slot122, align 4
  %1652 = icmp slt i64 %.state729, 96
  br i1 %1652, label %direct.true730, label %direct.false731

direct.schedule.51:                               ; preds = %direct.true730
  %.spill.load732 = load i64, ptr %.spill29, align 4
  %1653 = add i64 %.spill.load732, 0
  %.spill.load733 = load <8 x i64>, ptr %.spill, align 64
  %1654 = add <8 x i64> %.spill.load733, zeroinitializer
  %1655 = mul i64 %1653, 8
  %.splatinsert734 = insertelement <8 x i64> poison, i64 %1655, i64 0
  %.splat735 = shufflevector <8 x i64> %.splatinsert734, <8 x i64> poison, <8 x i32> zeroinitializer
  %1656 = add <8 x i64> %.splat735, %1654
  %.spill.load736 = load i64, ptr %.spill29, align 4
  %1657 = add i64 %.spill.load736, 0
  %1658 = mul <8 x i64> %1656, splat (i64 1)
  %.splatinsert737 = insertelement <8 x i64> poison, i64 %1657, i64 0
  %.splat738 = shufflevector <8 x i64> %.splatinsert737, <8 x i64> poison, <8 x i32> zeroinitializer
  %1659 = add <8 x i64> %1658, %.splat738
  %.state739 = load i64, ptr %.slot122, align 4
  %1660 = add i64 0, %.state739
  %1661 = mul <8 x i64> %1659, splat (i64 96)
  %.splatinsert740 = insertelement <8 x i64> poison, i64 %1660, i64 0
  %.splat741 = shufflevector <8 x i64> %.splatinsert740, <8 x i64> poison, <8 x i32> zeroinitializer
  %1662 = add <8 x i64> %1661, %.splat741
  %.state742 = load i64, ptr %.slot122, align 4
  %1663 = add i64 0, %.state742
  %tile_snapshot.spill.load743 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load743, 0
  %1665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load743, 1
  %.splatinsert744 = insertelement <8 x i64> poison, i64 %1663, i64 0
  %.splat745 = shufflevector <8 x i64> %.splatinsert744, <8 x i64> poison, <8 x i32> zeroinitializer
  %1666 = mul <8 x i64> %.splat745, splat (i64 32)
  %1667 = add <8 x i64> %1665, %1666
  %1668 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1664, 0
  %1669 = insertvalue { <8 x ptr>, <8 x i64> } %1668, <8 x i64> %1667, 1
  %1670 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1671 = extractvalue { <8 x ptr>, <8 x i64> } %1669, 1
  %1672 = extractelement <8 x ptr> %1670, i32 0
  %1673 = extractelement <8 x i64> %1671, i32 0
  %1674 = sub i64 %1673, 0
  %1675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1676 = select i1 %1675, i64 %1674, i64 0
  %private.contiguous.address746 = getelementptr i8, ptr %1672, i64 %1676
  %private.contiguous.load747 = load <8 x float>, ptr %private.contiguous.address746, align 4
  %1677 = select <8 x i1> %71, <8 x float> %private.contiguous.load747, <8 x float> zeroinitializer
  %.state748 = load <8 x float>, ptr %.slot36, align 32
  %1678 = fdiv <8 x float> %1677, %.state748
  %1679 = extractvalue { ptr, i64 } %47, 0
  %1680 = mul <8 x i64> %1662, splat (i64 4)
  %1681 = getelementptr i8, ptr %1679, <8 x i64> %1680
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1678, <8 x ptr> align 1 %1681, <8 x i1> %71)
  %.state749 = load i64, ptr %.slot122, align 4
  %1682 = add i64 %.state749, 1
  store i64 %1682, ptr %.slot122, align 4
  br label %direct.schedule.50

direct.schedule.52:                               ; preds = %direct.false731
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true147:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false148:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true157:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false158:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.49

direct.true161:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false162:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true174:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false175:                                  ; preds = %direct.schedule.10
  %1683 = load <8 x float>, ptr %.slot41, align 32
  %1684 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1683
  store <8 x float> %1684, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.true186:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false187:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true199:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false200:                                  ; preds = %direct.schedule.15
  %1685 = load <8 x float>, ptr %.slot45, align 32
  %1686 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1685
  store <8 x float> %1686, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.true211:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false212:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true247:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false248:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true285:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false286:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true323:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false324:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true458:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false459:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true586:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false587:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true600:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false601:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.42

direct.true628:                                   ; preds = %direct.schedule.39
  br label %direct.schedule.40

direct.false629:                                  ; preds = %direct.schedule.39
  br label %direct.schedule.41

direct.true695:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false696:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true711:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false712:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true730:                                   ; preds = %direct.schedule.50
  br label %direct.schedule.51

direct.false731:                                  ; preds = %direct.schedule.50
  br label %direct.schedule.52
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(write) }

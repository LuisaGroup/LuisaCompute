; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [37 x i32] [i32 5, i32 4, i32 8, i32 102, i32 15, i32 14, i32 20, i32 19, i32 29, i32 28, i32 27, i32 32, i32 35, i32 38, i32 41, i32 44, i32 47, i32 50, i32 53, i32 56, i32 59, i32 62, i32 65, i32 68, i32 71, i32 74, i32 77, i32 80, i32 83, i32 86, i32 95, i32 94, i32 93, i32 98, i32 101, i32 107, i32 106], align 4

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 12288
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 22528
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 32768
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 57344
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 77824
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 81920
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 16, i64 32, i64 48, i64 64, i64 80, i64 96, i64 112>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 82048
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 83072
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 83584
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 128, i64 256, i64 384, i64 512, i64 640, i64 768, i64 896>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 84608
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %33 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace41 = load ptr, ptr %33, align 8
  %tile_snapshot.private42 = getelementptr inbounds i8, ptr %private.workspace41, i64 88704
  %.splatinsert43 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private42, i64 0
  %.splat44 = shufflevector <8 x ptr> %.splatinsert43, <8 x ptr> poison, <8 x i32> zeroinitializer
  %34 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat44, 0
  %35 = insertvalue { <8 x ptr>, <8 x i64> } %34, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %36 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace45 = load ptr, ptr %36, align 8
  %tile_snapshot.private46 = getelementptr inbounds i8, ptr %private.workspace45, i64 88960
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %37 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %38 = insertvalue { <8 x ptr>, <8 x i64> } %37, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %39 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace49 = load ptr, ptr %39, align 8
  %tile_snapshot.private50 = getelementptr inbounds i8, ptr %private.workspace49, i64 89216
  %.splatinsert51 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private50, i64 0
  %.splat52 = shufflevector <8 x ptr> %.splatinsert51, <8 x ptr> poison, <8 x i32> zeroinitializer
  %40 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat52, 0
  %41 = insertvalue { <8 x ptr>, <8 x i64> } %40, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %42 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace53 = load ptr, ptr %42, align 8
  %tile_snapshot.private54 = getelementptr inbounds i8, ptr %private.workspace53, i64 93312
  %.splatinsert55 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private54, i64 0
  %.splat56 = shufflevector <8 x ptr> %.splatinsert55, <8 x ptr> poison, <8 x i32> zeroinitializer
  %43 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat56, 0
  %44 = insertvalue { <8 x ptr>, <8 x i64> } %43, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %45 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace57 = load ptr, ptr %45, align 8
  %tile_snapshot.private58 = getelementptr inbounds i8, ptr %private.workspace57, i64 103552
  %.splatinsert59 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private58, i64 0
  %.splat60 = shufflevector <8 x ptr> %.splatinsert59, <8 x ptr> poison, <8 x i32> zeroinitializer
  %46 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat60, 0
  %47 = insertvalue { <8 x ptr>, <8 x i64> } %46, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill61 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill61, align 64
  %.spill62 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill62, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill63 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill63, align 64
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %tile_snapshot.spill65 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill65, align 64
  %tile_snapshot.spill66 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill66, align 64
  %.slot67 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot67, align 64
  %.slot68 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot68, align 64
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot72, align 32
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot74, align 32
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %.slot79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot79, align 32
  %.slot80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot80, align 32
  %.slot81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot81, align 32
  %.slot82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot82, align 32
  %.slot83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot83, align 32
  %.slot84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot84, align 32
  %.spill85 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill85, align 64
  %tile_snapshot.spill86 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill86, align 64
  %.slot87 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot87, align 64
  %.spill88 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill88, align 64
  %.slot89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot89, align 32
  %tile_snapshot.spill90 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill90, align 64
  %.slot91 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot91, align 64
  %.spill92 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill92, align 64
  %.slot93 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot93, align 32
  %tile_snapshot.spill94 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill94, align 64
  %.slot95 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot95, align 64
  %.slot96 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot96, align 64
  %.spill97 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill97, align 64
  %.spill98 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill98, align 64
  %.spill99 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill99, align 64
  %.spill100 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill100, align 64
  %.spill101 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill101, align 64
  %.spill102 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill102, align 64
  %.spill103 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill103, align 64
  %.spill104 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill104, align 64
  %.spill105 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill105, align 64
  %.slot106 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot106, align 64
  %.slot107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot107, align 32
  %.slot108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot108, align 32
  %.slot109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot109, align 32
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %tile_snapshot.spill111 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill111, align 64
  %tile_snapshot.spill112 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill112, align 64
  %tile_snapshot.spill113 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill113, align 64
  %tile_snapshot.spill114 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill114, align 64
  %.slot115 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot115, align 64
  %tile_snapshot.spill116 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill116, align 64
  %.slot117 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot117, align 64
  %.slot118 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot118, align 64
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.slot120 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot120, align 64
  %.slot121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot121, align 32
  %.slot122 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot122, align 64
  %.slot123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot123, align 32
  %.slot124 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot124, align 64
  %.slot125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot125, align 32
  %.slot126 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot126, align 64
  %.slot127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot127, align 32
  %.slot128 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot128, align 64
  %.slot129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot129, align 32
  %.slot130 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot130, align 64
  %.slot131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot131, align 32
  %.slot132 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot132, align 64
  %.slot133 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot133, align 32
  %.spill134 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill134, align 32
  %.spill135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill135, align 32
  %.spill136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill136, align 32
  %.spill137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill137, align 32
  %.spill138 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill138, align 32
  %.spill139 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill139, align 32
  %.spill140 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill140, align 32
  %.spill141 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill141, align 32
  %tile_snapshot.spill142 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill142, align 64
  %.spill143 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill143, align 32
  %.spill144 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill144, align 32
  %.spill145 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill145, align 32
  %.spill146 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill146, align 32
  %.spill147 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill147, align 32
  %.spill148 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill148, align 32
  %.spill149 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill149, align 32
  %.spill150 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill150, align 32
  %tile_snapshot.spill151 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill151, align 64
  %tile_snapshot.spill152 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill152, align 64
  %.slot153 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot153, align 64
  %.spill154 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill154, align 32
  %.spill155 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill155, align 32
  %.spill156 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill156, align 32
  %.spill157 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill157, align 32
  %.spill158 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill158, align 32
  %.spill159 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill159, align 32
  %.spill160 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill160, align 32
  %.spill161 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill161, align 32
  %.slot162 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot162, align 64
  %.slot163 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot163, align 32
  %.slot164 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot164, align 64
  %.slot165 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot165, align 32
  %.slot166 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot166, align 64
  %.slot167 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot167, align 32
  %.slot168 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot168, align 64
  %.slot169 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot169, align 32
  %.slot170 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot170, align 64
  %.slot171 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot171, align 32
  %.slot172 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot172, align 64
  %.slot173 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot173, align 32
  %.slot174 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot174, align 64
  %.slot175 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot175, align 32
  %.slot176 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot176, align 64
  %.slot177 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot177, align 32
  %.spill178 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill178, align 32
  %.spill179 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill179, align 32
  %.spill180 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill180, align 32
  %.spill181 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill181, align 32
  %.spill182 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill182, align 32
  %.spill183 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill183, align 32
  %.spill184 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill184, align 32
  %.spill185 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill185, align 32
  %tile_snapshot.spill186 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill186, align 64
  %.slot187 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot187, align 64
  %.slot188 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot188, align 64
  %.spill189 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill189, align 64
  %.spill190 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill190, align 64
  %.spill191 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill191, align 64
  %.spill192 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill192, align 64
  %.spill193 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill193, align 64
  %.spill194 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill194, align 64
  %.spill195 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill195, align 64
  %.spill196 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill196, align 64
  %.spill197 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill197, align 64
  %.slot198 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot198, align 64
  %.slot199 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot199, align 32
  %.slot200 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot200, align 32
  %.slot201 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot201, align 32
  %.slot202 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot202, align 32
  %.slot203 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot203, align 64
  %.slot204 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot204, align 64
  %tile_snapshot.spill205 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill205, align 64
  %.slot206 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot206, align 64
  %.spill207 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill207, align 64
  %.spill208 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill208, align 32
  %48 = getelementptr i8, ptr %argument_buffer, i64 0
  %49 = load ptr, ptr %48, align 16
  %50 = getelementptr i8, ptr %48, i64 8
  %51 = load i64, ptr %50, align 8
  %52 = insertvalue { ptr, i64 } poison, ptr %49, 0
  %53 = insertvalue { ptr, i64 } %52, i64 %51, 1
  %54 = getelementptr i8, ptr %argument_buffer, i64 16
  %55 = load ptr, ptr %54, align 16
  %56 = getelementptr i8, ptr %54, i64 8
  %57 = load i64, ptr %56, align 8
  %58 = insertvalue { ptr, i64 } poison, ptr %55, 0
  %59 = insertvalue { ptr, i64 } %58, i64 %57, 1
  %60 = getelementptr i8, ptr %argument_buffer, i64 32
  %61 = load ptr, ptr %60, align 16
  %62 = getelementptr i8, ptr %60, i64 8
  %63 = load i64, ptr %62, align 8
  %64 = insertvalue { ptr, i64 } poison, ptr %61, 0
  %65 = insertvalue { ptr, i64 } %64, i64 %63, 1
  %66 = getelementptr i8, ptr %argument_buffer, i64 48
  %67 = load ptr, ptr %66, align 16
  %68 = getelementptr i8, ptr %66, i64 8
  %69 = load i64, ptr %68, align 8
  %70 = insertvalue { ptr, i64 } poison, ptr %67, 0
  %71 = insertvalue { ptr, i64 } %70, i64 %69, 1
  %72 = load i32, ptr %launch_config, align 4
  %73 = getelementptr i8, ptr %launch_config, i64 12
  %74 = load i32, ptr %73, align 4
  %75 = getelementptr i8, ptr %launch_config, i64 4
  %76 = load i32, ptr %75, align 4
  %77 = getelementptr i8, ptr %launch_config, i64 16
  %78 = load i32, ptr %77, align 4
  %79 = getelementptr i8, ptr %launch_config, i64 8
  %80 = load i32, ptr %79, align 4
  %81 = getelementptr i8, ptr %launch_config, i64 20
  %82 = load i32, ptr %81, align 4
  %83 = getelementptr i8, ptr %launch_config, i64 36
  %84 = load i32, ptr %83, align 4
  %.splatinsert209 = insertelement <8 x i32> poison, i32 %84, i64 0
  %.splat210 = shufflevector <8 x i32> %.splatinsert209, <8 x i32> poison, <8 x i32> zeroinitializer
  %85 = add <8 x i32> %.splat210, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %86 = mul i32 %72, 32
  %.splatinsert211 = insertelement <8 x i32> poison, i32 %86, i64 0
  %.splat212 = shufflevector <8 x i32> %.splatinsert211, <8 x i32> poison, <8 x i32> zeroinitializer
  %87 = add <8 x i32> %.splat212, %85
  %88 = mul i32 %76, 1
  %.splatinsert213 = insertelement <8 x i32> poison, i32 %88, i64 0
  %.splat214 = shufflevector <8 x i32> %.splatinsert213, <8 x i32> poison, <8 x i32> zeroinitializer
  %89 = add <8 x i32> %.splat214, zeroinitializer
  %90 = mul i32 %80, 1
  %.splatinsert215 = insertelement <8 x i32> poison, i32 %90, i64 0
  %.splat216 = shufflevector <8 x i32> %.splatinsert215, <8 x i32> poison, <8 x i32> zeroinitializer
  %91 = add <8 x i32> %.splat216, zeroinitializer
  %92 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %87, 0
  %93 = insertvalue [3 x <8 x i32>] %92, <8 x i32> %89, 1
  %94 = insertvalue [3 x <8 x i32>] %93, <8 x i32> %91, 2
  %.splatinsert217 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat218 = shufflevector <8 x i32> %.splatinsert217, <8 x i32> poison, <8 x i32> zeroinitializer
  %95 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat218
  store <8 x i1> %95, ptr %live.mask, align 1
  %96 = load i32, ptr %current.token, align 4
  %97 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %98 = load i32, ptr %ready.count, align 4
  %99 = icmp uge i32 %98, 8
  %100 = and i1 %97, %99
  br i1 %100, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %101 = select i1 %97, i32 %98, i32 0
  %102 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %101
  %103 = load <8 x i1>, ptr %102, align 1
  %104 = select i1 %97, <8 x i1> %95, <8 x i1> %103
  store <8 x i1> %104, ptr %102, align 1
  %105 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %101
  %106 = load i32, ptr %105, align 4
  %107 = select i1 %97, i32 0, i32 %106
  store i32 %107, ptr %105, align 4
  %108 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %101
  %109 = load i32, ptr %108, align 4
  %110 = select i1 %97, i32 %96, i32 %109
  store i32 %110, ptr %108, align 4
  %111 = add i32 %98, 1
  %112 = select i1 %97, i32 %111, i32 %98
  store i32 %112, ptr %ready.count, align 4
  %113 = load <8 x i1>, ptr %runnable.mask, align 1
  %114 = or <8 x i1> %113, %95
  store <8 x i1> %114, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit1562, %convergence.target.106.ready, %convergence.cascade.exit1544, %schedule.105, %varying.coherent.false1540, %varying.coherent.true1539, %varying.coherent.false1526, %varying.coherent.true1525, %convergence.target.102.ready, %convergence.cascade.exit1478, %convergence.target.101.ready, %convergence.cascade.exit1444, %schedule.100, %varying.coherent.false1437, %varying.coherent.true1436, %convergence.target.98.ready, %convergence.cascade.exit1413, %schedule.97, %varying.coherent.false1406, %varying.coherent.true1405, %convergence.target.95.ready, %convergence.cascade.exit1382, %convergence.target.94.ready, %convergence.cascade.exit1364, %convergence.target.93.ready, %convergence.cascade.exit1334, %schedule.92, %varying.coherent.false1315, %varying.coherent.true1314, %schedule.90, %varying.coherent.false1296, %varying.coherent.true1295, %schedule.88, %varying.coherent.false1287, %varying.coherent.true1286, %convergence.target.86.ready, %convergence.cascade.exit1247, %schedule.85, %varying.coherent.false1241, %varying.coherent.true1240, %convergence.target.83.ready, %convergence.cascade.exit1217, %schedule.82, %varying.coherent.false1211, %varying.coherent.true1210, %convergence.target.80.ready, %convergence.cascade.exit1187, %schedule.79, %varying.coherent.false1181, %varying.coherent.true1180, %convergence.target.77.ready, %convergence.cascade.exit1157, %schedule.76, %varying.coherent.false1151, %varying.coherent.true1150, %convergence.target.74.ready, %convergence.cascade.exit1127, %schedule.73, %varying.coherent.false1121, %varying.coherent.true1120, %convergence.target.71.ready, %convergence.cascade.exit1097, %schedule.70, %varying.coherent.false1091, %varying.coherent.true1090, %convergence.target.68.ready, %convergence.cascade.exit1067, %schedule.67, %varying.coherent.false1061, %varying.coherent.true1060, %convergence.target.65.ready, %convergence.cascade.exit1037, %schedule.64, %varying.coherent.false1031, %varying.coherent.true1030, %convergence.target.62.ready, %convergence.cascade.exit991, %schedule.61, %varying.coherent.false980, %varying.coherent.true979, %convergence.target.59.ready, %convergence.cascade.exit893, %schedule.58, %varying.coherent.false887, %varying.coherent.true886, %convergence.target.56.ready, %convergence.cascade.exit863, %schedule.55, %varying.coherent.false857, %varying.coherent.true856, %convergence.target.53.ready, %convergence.cascade.exit833, %schedule.52, %varying.coherent.false827, %varying.coherent.true826, %convergence.target.50.ready, %convergence.cascade.exit803, %schedule.49, %varying.coherent.false797, %varying.coherent.true796, %convergence.target.47.ready, %convergence.cascade.exit773, %schedule.46, %varying.coherent.false767, %varying.coherent.true766, %convergence.target.44.ready, %convergence.cascade.exit743, %schedule.43, %varying.coherent.false737, %varying.coherent.true736, %convergence.target.41.ready, %convergence.cascade.exit713, %schedule.40, %varying.coherent.false707, %varying.coherent.true706, %convergence.target.38.ready, %convergence.cascade.exit683, %schedule.37, %varying.coherent.false677, %varying.coherent.true676, %convergence.target.35.ready, %convergence.cascade.exit653, %schedule.34, %varying.coherent.false644, %varying.coherent.true643, %convergence.target.32.ready, %convergence.cascade.exit620, %schedule.31, %varying.coherent.false610, %varying.coherent.true609, %convergence.target.29.ready, %convergence.cascade.exit516, %convergence.target.28.ready, %convergence.cascade.exit498, %convergence.target.27.ready, %convergence.cascade.exit468, %schedule.26, %varying.coherent.false446, %varying.coherent.true445, %schedule.24, %varying.coherent.false435, %varying.coherent.true434, %schedule.22, %varying.coherent.false426, %varying.coherent.true425, %convergence.target.20.ready, %convergence.cascade.exit402, %convergence.target.19.ready, %convergence.cascade.exit381, %schedule.18, %varying.coherent.false378, %varying.coherent.true377, %varying.coherent.false366, %varying.coherent.true365, %convergence.target.15.ready, %convergence.cascade.exit342, %convergence.target.14.ready, %convergence.cascade.exit321, %schedule.13, %varying.coherent.false318, %varying.coherent.true317, %varying.coherent.false306, %varying.coherent.true305, %schedule.10, %varying.coherent.false296, %varying.coherent.true295, %convergence.target.8.ready, %convergence.cascade.exit272, %schedule.7, %varying.coherent.false267, %varying.coherent.true266, %convergence.target.5.ready, %convergence.cascade.exit243, %convergence.target.4.ready, %convergence.cascade.exit, %schedule.3, %varying.coherent.false231, %varying.coherent.true230, %varying.coherent.false, %varying.coherent.true, %schedule.0, %ready.overflow.resume
  %115 = load i32, ptr %ready.count, align 4
  %116 = icmp ne i32 %115, 0
  br i1 %116, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %117 = sub i32 %115, 1
  store i32 %117, ptr %ready.count, align 4
  %118 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %117
  %119 = load <8 x i1>, ptr %118, align 1
  store <8 x i1> %119, ptr %current.mask, align 1
  %120 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %117
  %121 = load i32, ptr %120, align 4
  %122 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %117
  %123 = load i32, ptr %122, align 4
  store i32 %123, ptr %current.token, align 4
  %124 = load <8 x i1>, ptr %runnable.mask, align 1
  %125 = xor <8 x i1> %119, splat (i1 true)
  %126 = and <8 x i1> %124, %125
  store <8 x i1> %126, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume1538, %ready.overflow.resume1524, %ready.overflow.resume1435, %ready.overflow.resume1404, %ready.overflow.resume1313, %ready.overflow.resume1294, %ready.overflow.resume1285, %ready.overflow.resume1239, %ready.overflow.resume1209, %ready.overflow.resume1179, %ready.overflow.resume1149, %ready.overflow.resume1119, %ready.overflow.resume1089, %ready.overflow.resume1059, %ready.overflow.resume1029, %ready.overflow.resume978, %ready.overflow.resume885, %ready.overflow.resume855, %ready.overflow.resume825, %ready.overflow.resume795, %ready.overflow.resume765, %ready.overflow.resume735, %ready.overflow.resume705, %ready.overflow.resume675, %ready.overflow.resume642, %ready.overflow.resume608, %ready.overflow.resume444, %ready.overflow.resume433, %ready.overflow.resume424, %ready.overflow.resume376, %ready.overflow.resume364, %ready.overflow.resume316, %ready.overflow.resume304, %ready.overflow.resume294, %ready.overflow.resume265, %ready.overflow.resume229, %ready.overflow.resume220, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %121, %scheduler.dispatch ], [ 5, %ready.overflow.resume220 ], [ 4, %ready.overflow.resume229 ], [ 8, %ready.overflow.resume265 ], [ 102, %ready.overflow.resume294 ], [ 15, %ready.overflow.resume304 ], [ 14, %ready.overflow.resume316 ], [ 20, %ready.overflow.resume364 ], [ 19, %ready.overflow.resume376 ], [ 29, %ready.overflow.resume424 ], [ 28, %ready.overflow.resume433 ], [ 27, %ready.overflow.resume444 ], [ 32, %ready.overflow.resume608 ], [ 35, %ready.overflow.resume642 ], [ 38, %ready.overflow.resume675 ], [ 41, %ready.overflow.resume705 ], [ 44, %ready.overflow.resume735 ], [ 47, %ready.overflow.resume765 ], [ 50, %ready.overflow.resume795 ], [ 53, %ready.overflow.resume825 ], [ 56, %ready.overflow.resume855 ], [ 59, %ready.overflow.resume885 ], [ 62, %ready.overflow.resume978 ], [ 65, %ready.overflow.resume1029 ], [ 68, %ready.overflow.resume1059 ], [ 71, %ready.overflow.resume1089 ], [ 74, %ready.overflow.resume1119 ], [ 77, %ready.overflow.resume1149 ], [ 80, %ready.overflow.resume1179 ], [ 83, %ready.overflow.resume1209 ], [ 86, %ready.overflow.resume1239 ], [ 95, %ready.overflow.resume1285 ], [ 94, %ready.overflow.resume1294 ], [ 93, %ready.overflow.resume1313 ], [ 98, %ready.overflow.resume1404 ], [ 101, %ready.overflow.resume1435 ], [ 107, %ready.overflow.resume1524 ], [ 106, %ready.overflow.resume1538 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
    i32 41, label %schedule.41
    i32 42, label %schedule.42
    i32 43, label %schedule.43
    i32 44, label %schedule.44
    i32 45, label %schedule.45
    i32 46, label %schedule.46
    i32 47, label %schedule.47
    i32 48, label %schedule.48
    i32 49, label %schedule.49
    i32 50, label %schedule.50
    i32 51, label %schedule.51
    i32 52, label %schedule.52
    i32 53, label %schedule.53
    i32 54, label %schedule.54
    i32 55, label %schedule.55
    i32 56, label %schedule.56
    i32 57, label %schedule.57
    i32 58, label %schedule.58
    i32 59, label %schedule.59
    i32 60, label %schedule.60
    i32 61, label %schedule.61
    i32 62, label %schedule.62
    i32 63, label %schedule.63
    i32 64, label %schedule.64
    i32 65, label %schedule.65
    i32 66, label %schedule.66
    i32 67, label %schedule.67
    i32 68, label %schedule.68
    i32 69, label %schedule.69
    i32 70, label %schedule.70
    i32 71, label %schedule.71
    i32 72, label %schedule.72
    i32 73, label %schedule.73
    i32 74, label %schedule.74
    i32 75, label %schedule.75
    i32 76, label %schedule.76
    i32 77, label %schedule.77
    i32 78, label %schedule.78
    i32 79, label %schedule.79
    i32 80, label %schedule.80
    i32 81, label %schedule.81
    i32 82, label %schedule.82
    i32 83, label %schedule.83
    i32 84, label %schedule.84
    i32 85, label %schedule.85
    i32 86, label %schedule.86
    i32 87, label %schedule.87
    i32 88, label %schedule.88
    i32 89, label %schedule.89
    i32 90, label %schedule.90
    i32 91, label %schedule.91
    i32 92, label %schedule.92
    i32 93, label %schedule.93
    i32 94, label %schedule.94
    i32 95, label %schedule.95
    i32 96, label %schedule.96
    i32 97, label %schedule.97
    i32 98, label %schedule.98
    i32 99, label %schedule.99
    i32 100, label %schedule.100
    i32 101, label %schedule.101
    i32 102, label %schedule.102
    i32 103, label %schedule.103
    i32 104, label %schedule.104
    i32 105, label %schedule.105
    i32 106, label %schedule.106
    i32 107, label %schedule.107
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %127 = load <8 x i1>, ptr %live.mask, align 1
  %128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %127)
  br i1 %128, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %129 = load <8 x i1>, ptr %current.mask, align 1
  %130 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %131 = bitcast <8 x i1> %129 to i8
  %132 = call i8 @llvm.cttz.i8(i8 %131, i1 false)
  %133 = zext i8 %132 to i32
  %134 = select i1 %130, i32 %133, i32 0
  %135 = extractvalue [3 x <8 x i32>] %94, 0
  %136 = zext <8 x i32> %135 to <8 x i64>
  %137 = select <8 x i1> %129, <8 x i64> %136, <8 x i64> zeroinitializer
  %138 = select <8 x i1> %129, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %139 = sdiv <8 x i64> %137, %138
  %140 = load <8 x i64>, ptr %.spill, align 64
  %141 = select <8 x i1> %129, <8 x i64> %139, <8 x i64> %140
  store <8 x i64> %141, ptr %.spill, align 64
  %142 = select <8 x i1> %129, <8 x i64> %136, <8 x i64> zeroinitializer
  %143 = select <8 x i1> %129, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %144 = sdiv <8 x i64> %142, %143
  %145 = select <8 x i1> %129, <8 x i64> %144, <8 x i64> zeroinitializer
  %146 = select <8 x i1> %129, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %147 = srem <8 x i64> %145, %146
  %148 = mul <8 x i64> %147, splat (i64 8)
  %149 = load <8 x i64>, ptr %.spill61, align 64
  %150 = select <8 x i1> %129, <8 x i64> %148, <8 x i64> %149
  store <8 x i64> %150, ptr %.spill61, align 64
  %151 = select <8 x i1> %129, <8 x i64> %139, <8 x i64> zeroinitializer
  %152 = select <8 x i1> %129, <8 x i64> splat (i64 3), <8 x i64> splat (i64 1)
  %153 = sdiv <8 x i64> %151, %152
  %154 = load <8 x i64>, ptr %.spill62, align 64
  %155 = select <8 x i1> %129, <8 x i64> %153, <8 x i64> %154
  store <8 x i64> %155, ptr %.spill62, align 64
  %156 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %156, 0
  %159 = select <8 x i1> %129, <8 x ptr> %157, <8 x ptr> %158
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %156, 1
  %162 = select <8 x i1> %129, <8 x i64> %160, <8 x i64> %161
  %163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %159, 0
  %164 = insertvalue { <8 x ptr>, <8 x i64> } %163, <8 x i64> %162, 1
  store { <8 x ptr>, <8 x i64> } %164, ptr %tile_snapshot.spill, align 64
  %165 = load <8 x i64>, ptr %.slot, align 64
  %166 = select <8 x i1> %129, <8 x i64> zeroinitializer, <8 x i64> %165
  store <8 x i64> %166, ptr %.slot, align 64
  store <8 x i1> %129, ptr %current.mask, align 1
  %167 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  br i1 %167, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %convergence.target.4.ready, %schedule.0, %scheduler.dispatch.route
  %168 = load <8 x i1>, ptr %current.mask, align 1
  %169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %168)
  %170 = bitcast <8 x i1> %168 to i8
  %171 = call i8 @llvm.cttz.i8(i8 %170, i1 false)
  %172 = zext i8 %171 to i32
  %173 = select i1 %169, i32 %172, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %174 = icmp slt <8 x i64> %.state, splat (i64 384)
  %175 = and <8 x i1> %168, %174
  %176 = xor <8 x i1> %174, splat (i1 true)
  %177 = and <8 x i1> %168, %176
  %178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %175)
  %179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %177)
  %180 = and i1 %178, %179
  br i1 %180, label %varying.divergent, label %varying.coherent

schedule.2:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %181 = load <8 x i1>, ptr %current.mask, align 1
  %182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %181)
  %183 = bitcast <8 x i1> %181 to i8
  %184 = call i8 @llvm.cttz.i8(i8 %183, i1 false)
  %185 = zext i8 %184 to i32
  %186 = select i1 %182, i32 %185, i32 0
  %.state221 = load <8 x i64>, ptr %.slot, align 64
  %187 = select <8 x i1> %181, <8 x i64> %.state221, <8 x i64> zeroinitializer
  %188 = select <8 x i1> %181, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %189 = srem <8 x i64> %187, %188
  %.state222 = load <8 x i64>, ptr %.slot, align 64
  %190 = select <8 x i1> %181, <8 x i64> %.state222, <8 x i64> zeroinitializer
  %191 = select <8 x i1> %181, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %192 = sdiv <8 x i64> %190, %191
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %193 = add <8 x i64> %.spill.load, zeroinitializer
  %194 = add <8 x i64> zeroinitializer, %193
  %.spill.load223 = load <8 x i64>, ptr %.spill61, align 64
  %195 = add <8 x i64> %.spill.load223, %192
  %196 = mul <8 x i64> %194, splat (i64 33)
  %197 = add <8 x i64> %196, %195
  %198 = icmp sge <8 x i64> %195, zeroinitializer
  %199 = and <8 x i1> splat (i1 true), %198
  %200 = icmp slt <8 x i64> %195, splat (i64 33)
  %201 = and <8 x i1> %199, %200
  %202 = add <8 x i64> zeroinitializer, %189
  %203 = mul <8 x i64> %197, splat (i64 48)
  %204 = add <8 x i64> %203, %202
  %205 = load <8 x i64>, ptr %.spill63, align 64
  %206 = select <8 x i1> %181, <8 x i64> %204, <8 x i64> %205
  store <8 x i64> %206, ptr %.spill63, align 64
  %207 = and <8 x i1> %181, %201
  %208 = xor <8 x i1> %201, splat (i1 true)
  %209 = and <8 x i1> %181, %208
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %207)
  %211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %209)
  %212 = and i1 %210, %211
  br i1 %212, label %varying.divergent224, label %varying.coherent225

schedule.3:                                       ; preds = %varying.coherent.true230, %scheduler.dispatch.route
  %213 = load <8 x i1>, ptr %current.mask, align 1
  %214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %213)
  %215 = bitcast <8 x i1> %213 to i8
  %216 = call i8 @llvm.cttz.i8(i8 %215, i1 false)
  %217 = zext i8 %216 to i32
  %218 = select i1 %214, i32 %217, i32 0
  %.spill.load232 = load <8 x i64>, ptr %.spill63, align 64
  %219 = extractvalue { ptr, i64 } %53, 0
  %220 = mul <8 x i64> %.spill.load232, splat (i64 4)
  %221 = getelementptr i8, ptr %219, <8 x i64> %220
  %222 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %221, <8 x i1> %213, <8 x float> zeroinitializer)
  %223 = load <8 x float>, ptr %.slot64, align 32
  %224 = select <8 x i1> %213, <8 x float> %222, <8 x float> %223
  store <8 x float> %224, ptr %.slot64, align 32
  store <8 x i1> %213, ptr %current.mask, align 1
  %225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %213)
  br i1 %225, label %schedule.4, label %scheduler.loop

schedule.4:                                       ; preds = %schedule.3, %varying.coherent.false231, %scheduler.dispatch.route
  %226 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.5:                                       ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %227 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token244 = load i32, ptr %current.token, align 4
  %convergence.token.present245 = icmp ne i32 %convergence.current.token244, 0
  br i1 %convergence.token.present245, label %convergence.cascade242, label %convergence.cascade.exit243

schedule.6:                                       ; preds = %schedule.7, %convergence.target.5.ready, %scheduler.dispatch.route
  %228 = load <8 x i1>, ptr %current.mask, align 1
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  %230 = bitcast <8 x i1> %228 to i8
  %231 = call i8 @llvm.cttz.i8(i8 %230, i1 false)
  %232 = zext i8 %231 to i32
  %233 = select i1 %229, i32 %232, i32 0
  %.state259 = load <8 x i64>, ptr %.slot67, align 64
  %234 = icmp slt <8 x i64> %.state259, splat (i64 320)
  %235 = and <8 x i1> %228, %234
  %236 = xor <8 x i1> %234, splat (i1 true)
  %237 = and <8 x i1> %228, %236
  %238 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %235)
  %239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %237)
  %240 = and i1 %238, %239
  br i1 %240, label %varying.divergent260, label %varying.coherent261

schedule.7:                                       ; preds = %varying.coherent.true266, %scheduler.dispatch.route
  %241 = load <8 x i1>, ptr %current.mask, align 1
  %242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %243 = bitcast <8 x i1> %241 to i8
  %244 = call i8 @llvm.cttz.i8(i8 %243, i1 false)
  %245 = zext i8 %244 to i32
  %246 = select i1 %242, i32 %245, i32 0
  %tile_snapshot.spill.load268 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load268, 0
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load268, 1
  %.state269 = load <8 x i64>, ptr %.slot67, align 64
  %249 = mul <8 x i64> %.state269, splat (i64 32)
  %250 = add <8 x i64> %248, %249
  %251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %247, 0
  %252 = insertvalue { <8 x ptr>, <8 x i64> } %251, <8 x i64> %250, 1
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %252, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %255 = getelementptr i8, <8 x ptr> %253, <8 x i64> %254
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %255, <8 x i1> %241)
  %.state270 = load <8 x i64>, ptr %.slot67, align 64
  %256 = add <8 x i64> %.state270, splat (i64 1)
  %257 = load <8 x i64>, ptr %.slot67, align 64
  %258 = select <8 x i1> %241, <8 x i64> %256, <8 x i64> %257
  store <8 x i64> %258, ptr %.slot67, align 64
  store <8 x i1> %241, ptr %current.mask, align 1
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  br i1 %259, label %schedule.6, label %scheduler.loop

schedule.8:                                       ; preds = %varying.coherent.false267, %scheduler.dispatch.route
  %260 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token273 = load i32, ptr %current.token, align 4
  %convergence.token.present274 = icmp ne i32 %convergence.current.token273, 0
  br i1 %convergence.token.present274, label %convergence.cascade271, label %convergence.cascade.exit272

schedule.9:                                       ; preds = %convergence.target.101.ready, %convergence.target.8.ready, %scheduler.dispatch.route
  %261 = load <8 x i1>, ptr %current.mask, align 1
  %262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %261)
  %263 = bitcast <8 x i1> %261 to i8
  %264 = call i8 @llvm.cttz.i8(i8 %263, i1 false)
  %265 = zext i8 %264 to i32
  %266 = select i1 %262, i32 %265, i32 0
  %.state288 = load <8 x i64>, ptr %.slot68, align 64
  %267 = icmp slt <8 x i64> %.state288, splat (i64 9)
  %268 = and <8 x i1> %261, %267
  %269 = xor <8 x i1> %267, splat (i1 true)
  %270 = and <8 x i1> %261, %269
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %268)
  %272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %270)
  %273 = and i1 %271, %272
  br i1 %273, label %varying.divergent289, label %varying.coherent290

schedule.10:                                      ; preds = %varying.coherent.true295, %scheduler.dispatch.route
  %274 = load <8 x i1>, ptr %current.mask, align 1
  %275 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %274)
  %276 = bitcast <8 x i1> %274 to i8
  %277 = call i8 @llvm.cttz.i8(i8 %276, i1 false)
  %278 = zext i8 %277 to i32
  %279 = select i1 %275, i32 %278, i32 0
  %.state297 = load <8 x i64>, ptr %.slot68, align 64
  %280 = select <8 x i1> %274, <8 x i64> %.state297, <8 x i64> zeroinitializer
  %281 = select <8 x i1> %274, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %282 = sdiv <8 x i64> %280, %281
  %283 = mul <8 x i64> %282, splat (i64 16)
  %284 = load <8 x i64>, ptr %.spill85, align 64
  %285 = select <8 x i1> %274, <8 x i64> %283, <8 x i64> %284
  store <8 x i64> %285, ptr %.spill85, align 64
  %286 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill86, align 64
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %286, 0
  %289 = select <8 x i1> %274, <8 x ptr> %287, <8 x ptr> %288
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %286, 1
  %292 = select <8 x i1> %274, <8 x i64> %290, <8 x i64> %291
  %293 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %289, 0
  %294 = insertvalue { <8 x ptr>, <8 x i64> } %293, <8 x i64> %292, 1
  store { <8 x ptr>, <8 x i64> } %294, ptr %tile_snapshot.spill86, align 64
  %295 = load <8 x i64>, ptr %.slot87, align 64
  %296 = select <8 x i1> %274, <8 x i64> zeroinitializer, <8 x i64> %295
  store <8 x i64> %296, ptr %.slot87, align 64
  store <8 x i1> %274, ptr %current.mask, align 1
  %297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %274)
  br i1 %297, label %schedule.11, label %scheduler.loop

schedule.11:                                      ; preds = %convergence.target.14.ready, %schedule.10, %scheduler.dispatch.route
  %298 = load <8 x i1>, ptr %current.mask, align 1
  %299 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %298)
  %300 = bitcast <8 x i1> %298 to i8
  %301 = call i8 @llvm.cttz.i8(i8 %300, i1 false)
  %302 = zext i8 %301 to i32
  %303 = select i1 %299, i32 %302, i32 0
  %.state298 = load <8 x i64>, ptr %.slot87, align 64
  %304 = icmp slt <8 x i64> %.state298, splat (i64 768)
  %305 = and <8 x i1> %298, %304
  %306 = xor <8 x i1> %304, splat (i1 true)
  %307 = and <8 x i1> %298, %306
  %308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %305)
  %309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %307)
  %310 = and i1 %308, %309
  br i1 %310, label %varying.divergent299, label %varying.coherent300

schedule.12:                                      ; preds = %varying.coherent.true305, %scheduler.dispatch.route
  %311 = load <8 x i1>, ptr %current.mask, align 1
  %312 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %311)
  %313 = bitcast <8 x i1> %311 to i8
  %314 = call i8 @llvm.cttz.i8(i8 %313, i1 false)
  %315 = zext i8 %314 to i32
  %316 = select i1 %312, i32 %315, i32 0
  %.state307 = load <8 x i64>, ptr %.slot87, align 64
  %317 = select <8 x i1> %311, <8 x i64> %.state307, <8 x i64> zeroinitializer
  %318 = select <8 x i1> %311, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %319 = srem <8 x i64> %317, %318
  %.state308 = load <8 x i64>, ptr %.slot87, align 64
  %320 = select <8 x i1> %311, <8 x i64> %.state308, <8 x i64> zeroinitializer
  %321 = select <8 x i1> %311, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %322 = sdiv <8 x i64> %320, %321
  %.spill.load309 = load <8 x i64>, ptr %.spill62, align 64
  %323 = add <8 x i64> %.spill.load309, zeroinitializer
  %324 = add <8 x i64> zeroinitializer, %323
  %.spill.load310 = load <8 x i64>, ptr %.spill85, align 64
  %325 = add <8 x i64> %.spill.load310, %322
  %326 = mul <8 x i64> %324, splat (i64 131)
  %327 = add <8 x i64> %326, %325
  %328 = icmp sge <8 x i64> %325, zeroinitializer
  %329 = and <8 x i1> splat (i1 true), %328
  %330 = icmp slt <8 x i64> %325, splat (i64 131)
  %331 = and <8 x i1> %329, %330
  %332 = add <8 x i64> zeroinitializer, %319
  %333 = mul <8 x i64> %327, splat (i64 48)
  %334 = add <8 x i64> %333, %332
  %335 = load <8 x i64>, ptr %.spill88, align 64
  %336 = select <8 x i1> %311, <8 x i64> %334, <8 x i64> %335
  store <8 x i64> %336, ptr %.spill88, align 64
  %337 = and <8 x i1> %311, %331
  %338 = xor <8 x i1> %331, splat (i1 true)
  %339 = and <8 x i1> %311, %338
  %340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %337)
  %341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %339)
  %342 = and i1 %340, %341
  br i1 %342, label %varying.divergent311, label %varying.coherent312

schedule.13:                                      ; preds = %varying.coherent.true317, %scheduler.dispatch.route
  %343 = load <8 x i1>, ptr %current.mask, align 1
  %344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %343)
  %345 = bitcast <8 x i1> %343 to i8
  %346 = call i8 @llvm.cttz.i8(i8 %345, i1 false)
  %347 = zext i8 %346 to i32
  %348 = select i1 %344, i32 %347, i32 0
  %.spill.load319 = load <8 x i64>, ptr %.spill88, align 64
  %349 = extractvalue { ptr, i64 } %59, 0
  %350 = mul <8 x i64> %.spill.load319, splat (i64 4)
  %351 = getelementptr i8, ptr %349, <8 x i64> %350
  %352 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %351, <8 x i1> %343, <8 x float> zeroinitializer)
  %353 = load <8 x float>, ptr %.slot89, align 32
  %354 = select <8 x i1> %343, <8 x float> %352, <8 x float> %353
  store <8 x float> %354, ptr %.slot89, align 32
  store <8 x i1> %343, ptr %current.mask, align 1
  %355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %343)
  br i1 %355, label %schedule.14, label %scheduler.loop

schedule.14:                                      ; preds = %schedule.13, %varying.coherent.false318, %scheduler.dispatch.route
  %356 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token322 = load i32, ptr %current.token, align 4
  %convergence.token.present323 = icmp ne i32 %convergence.current.token322, 0
  br i1 %convergence.token.present323, label %convergence.cascade320, label %convergence.cascade.exit321

schedule.15:                                      ; preds = %varying.coherent.false306, %scheduler.dispatch.route
  %357 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token343 = load i32, ptr %current.token, align 4
  %convergence.token.present344 = icmp ne i32 %convergence.current.token343, 0
  br i1 %convergence.token.present344, label %convergence.cascade341, label %convergence.cascade.exit342

schedule.16:                                      ; preds = %convergence.target.19.ready, %convergence.target.15.ready, %scheduler.dispatch.route
  %358 = load <8 x i1>, ptr %current.mask, align 1
  %359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %358)
  %360 = bitcast <8 x i1> %358 to i8
  %361 = call i8 @llvm.cttz.i8(i8 %360, i1 false)
  %362 = zext i8 %361 to i32
  %363 = select i1 %359, i32 %362, i32 0
  %.state358 = load <8 x i64>, ptr %.slot91, align 64
  %364 = icmp slt <8 x i64> %.state358, splat (i64 640)
  %365 = and <8 x i1> %358, %364
  %366 = xor <8 x i1> %364, splat (i1 true)
  %367 = and <8 x i1> %358, %366
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %365)
  %369 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %367)
  %370 = and i1 %368, %369
  br i1 %370, label %varying.divergent359, label %varying.coherent360

schedule.17:                                      ; preds = %varying.coherent.true365, %scheduler.dispatch.route
  %371 = load <8 x i1>, ptr %current.mask, align 1
  %372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  %373 = bitcast <8 x i1> %371 to i8
  %374 = call i8 @llvm.cttz.i8(i8 %373, i1 false)
  %375 = zext i8 %374 to i32
  %376 = select i1 %372, i32 %375, i32 0
  %.state367 = load <8 x i64>, ptr %.slot91, align 64
  %377 = select <8 x i1> %371, <8 x i64> %.state367, <8 x i64> zeroinitializer
  %378 = select <8 x i1> %371, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %379 = srem <8 x i64> %377, %378
  %.state368 = load <8 x i64>, ptr %.slot91, align 64
  %380 = select <8 x i1> %371, <8 x i64> %.state368, <8 x i64> zeroinitializer
  %381 = select <8 x i1> %371, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %382 = sdiv <8 x i64> %380, %381
  %.spill.load369 = load <8 x i64>, ptr %.spill62, align 64
  %383 = add <8 x i64> %.spill.load369, zeroinitializer
  %384 = add <8 x i64> zeroinitializer, %383
  %.spill.load370 = load <8 x i64>, ptr %.spill85, align 64
  %385 = add <8 x i64> %.spill.load370, %382
  %386 = mul <8 x i64> %384, splat (i64 131)
  %387 = add <8 x i64> %386, %385
  %388 = icmp sge <8 x i64> %385, zeroinitializer
  %389 = and <8 x i1> splat (i1 true), %388
  %390 = icmp slt <8 x i64> %385, splat (i64 131)
  %391 = and <8 x i1> %389, %390
  %392 = add <8 x i64> zeroinitializer, %379
  %393 = mul <8 x i64> %387, splat (i64 40)
  %394 = add <8 x i64> %393, %392
  %395 = load <8 x i64>, ptr %.spill92, align 64
  %396 = select <8 x i1> %371, <8 x i64> %394, <8 x i64> %395
  store <8 x i64> %396, ptr %.spill92, align 64
  %397 = and <8 x i1> %371, %391
  %398 = xor <8 x i1> %391, splat (i1 true)
  %399 = and <8 x i1> %371, %398
  %400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %397)
  %401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %399)
  %402 = and i1 %400, %401
  br i1 %402, label %varying.divergent371, label %varying.coherent372

schedule.18:                                      ; preds = %varying.coherent.true377, %scheduler.dispatch.route
  %403 = load <8 x i1>, ptr %current.mask, align 1
  %404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %403)
  %405 = bitcast <8 x i1> %403 to i8
  %406 = call i8 @llvm.cttz.i8(i8 %405, i1 false)
  %407 = zext i8 %406 to i32
  %408 = select i1 %404, i32 %407, i32 0
  %.spill.load379 = load <8 x i64>, ptr %.spill92, align 64
  %409 = extractvalue { ptr, i64 } %65, 0
  %410 = mul <8 x i64> %.spill.load379, splat (i64 4)
  %411 = getelementptr i8, ptr %409, <8 x i64> %410
  %412 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %411, <8 x i1> %403, <8 x float> zeroinitializer)
  %413 = load <8 x float>, ptr %.slot93, align 32
  %414 = select <8 x i1> %403, <8 x float> %412, <8 x float> %413
  store <8 x float> %414, ptr %.slot93, align 32
  store <8 x i1> %403, ptr %current.mask, align 1
  %415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %403)
  br i1 %415, label %schedule.19, label %scheduler.loop

schedule.19:                                      ; preds = %schedule.18, %varying.coherent.false378, %scheduler.dispatch.route
  %416 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token382 = load i32, ptr %current.token, align 4
  %convergence.token.present383 = icmp ne i32 %convergence.current.token382, 0
  br i1 %convergence.token.present383, label %convergence.cascade380, label %convergence.cascade.exit381

schedule.20:                                      ; preds = %varying.coherent.false366, %scheduler.dispatch.route
  %417 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token403 = load i32, ptr %current.token, align 4
  %convergence.token.present404 = icmp ne i32 %convergence.current.token403, 0
  br i1 %convergence.token.present404, label %convergence.cascade401, label %convergence.cascade.exit402

schedule.21:                                      ; preds = %convergence.target.28.ready, %convergence.target.20.ready, %scheduler.dispatch.route
  %418 = load <8 x i1>, ptr %current.mask, align 1
  %419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %418)
  %420 = bitcast <8 x i1> %418 to i8
  %421 = call i8 @llvm.cttz.i8(i8 %420, i1 false)
  %422 = zext i8 %421 to i32
  %423 = select i1 %419, i32 %422, i32 0
  %.state418 = load <8 x i64>, ptr %.slot95, align 64
  %424 = icmp slt <8 x i64> %.state418, splat (i64 8)
  %425 = and <8 x i1> %418, %424
  %426 = xor <8 x i1> %424, splat (i1 true)
  %427 = and <8 x i1> %418, %426
  %428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %425)
  %429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %427)
  %430 = and i1 %428, %429
  br i1 %430, label %varying.divergent419, label %varying.coherent420

schedule.22:                                      ; preds = %varying.coherent.true425, %scheduler.dispatch.route
  %431 = load <8 x i1>, ptr %current.mask, align 1
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %431)
  %433 = bitcast <8 x i1> %431 to i8
  %434 = call i8 @llvm.cttz.i8(i8 %433, i1 false)
  %435 = zext i8 %434 to i32
  %436 = select i1 %432, i32 %435, i32 0
  %437 = load <8 x i64>, ptr %.slot96, align 64
  %438 = select <8 x i1> %431, <8 x i64> zeroinitializer, <8 x i64> %437
  store <8 x i64> %438, ptr %.slot96, align 64
  store <8 x i1> %431, ptr %current.mask, align 1
  %439 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %431)
  br i1 %439, label %schedule.23, label %scheduler.loop

schedule.23:                                      ; preds = %convergence.target.27.ready, %schedule.22, %scheduler.dispatch.route
  %440 = load <8 x i1>, ptr %current.mask, align 1
  %441 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %440)
  %442 = bitcast <8 x i1> %440 to i8
  %443 = call i8 @llvm.cttz.i8(i8 %442, i1 false)
  %444 = zext i8 %443 to i32
  %445 = select i1 %441, i32 %444, i32 0
  %.state427 = load <8 x i64>, ptr %.slot96, align 64
  %446 = icmp slt <8 x i64> %.state427, splat (i64 4)
  %447 = and <8 x i1> %440, %446
  %448 = xor <8 x i1> %446, splat (i1 true)
  %449 = and <8 x i1> %440, %448
  %450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %447)
  %451 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %449)
  %452 = and i1 %450, %451
  br i1 %452, label %varying.divergent428, label %varying.coherent429

schedule.24:                                      ; preds = %varying.coherent.true434, %scheduler.dispatch.route
  %453 = load <8 x i1>, ptr %current.mask, align 1
  %454 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %453)
  %455 = bitcast <8 x i1> %453 to i8
  %456 = call i8 @llvm.cttz.i8(i8 %455, i1 false)
  %457 = zext i8 %456 to i32
  %458 = select i1 %454, i32 %457, i32 0
  %.state436 = load <8 x i64>, ptr %.slot95, align 64
  %459 = mul <8 x i64> %.state436, splat (i64 16)
  %.state437 = load <8 x i64>, ptr %.slot96, align 64
  %460 = mul <8 x i64> %.state437, splat (i64 4)
  %461 = add <8 x i64> %459, %460
  %462 = add <8 x i64> %461, zeroinitializer
  %463 = load <8 x i64>, ptr %.spill97, align 64
  %464 = select <8 x i1> %453, <8 x i64> %462, <8 x i64> %463
  store <8 x i64> %464, ptr %.spill97, align 64
  %465 = select <8 x i1> %453, <8 x i64> %462, <8 x i64> zeroinitializer
  %466 = select <8 x i1> %453, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %467 = srem <8 x i64> %465, %466
  %468 = load <8 x i64>, ptr %.spill98, align 64
  %469 = select <8 x i1> %453, <8 x i64> %467, <8 x i64> %468
  store <8 x i64> %469, ptr %.spill98, align 64
  %470 = select <8 x i1> %453, <8 x i64> %462, <8 x i64> zeroinitializer
  %471 = select <8 x i1> %453, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %472 = sdiv <8 x i64> %470, %471
  %473 = load <8 x i64>, ptr %.spill99, align 64
  %474 = select <8 x i1> %453, <8 x i64> %472, <8 x i64> %473
  store <8 x i64> %474, ptr %.spill99, align 64
  %475 = add <8 x i64> %461, splat (i64 1)
  %476 = load <8 x i64>, ptr %.spill100, align 64
  %477 = select <8 x i1> %453, <8 x i64> %475, <8 x i64> %476
  store <8 x i64> %477, ptr %.spill100, align 64
  %478 = select <8 x i1> %453, <8 x i64> %475, <8 x i64> zeroinitializer
  %479 = select <8 x i1> %453, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %480 = srem <8 x i64> %478, %479
  %481 = load <8 x i64>, ptr %.spill101, align 64
  %482 = select <8 x i1> %453, <8 x i64> %480, <8 x i64> %481
  store <8 x i64> %482, ptr %.spill101, align 64
  %483 = add <8 x i64> %461, splat (i64 2)
  %484 = load <8 x i64>, ptr %.spill102, align 64
  %485 = select <8 x i1> %453, <8 x i64> %483, <8 x i64> %484
  store <8 x i64> %485, ptr %.spill102, align 64
  %486 = select <8 x i1> %453, <8 x i64> %483, <8 x i64> zeroinitializer
  %487 = select <8 x i1> %453, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %488 = srem <8 x i64> %486, %487
  %489 = load <8 x i64>, ptr %.spill103, align 64
  %490 = select <8 x i1> %453, <8 x i64> %488, <8 x i64> %489
  store <8 x i64> %490, ptr %.spill103, align 64
  %491 = add <8 x i64> %461, splat (i64 3)
  %492 = load <8 x i64>, ptr %.spill104, align 64
  %493 = select <8 x i1> %453, <8 x i64> %491, <8 x i64> %492
  store <8 x i64> %493, ptr %.spill104, align 64
  %494 = select <8 x i1> %453, <8 x i64> %491, <8 x i64> zeroinitializer
  %495 = select <8 x i1> %453, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %496 = srem <8 x i64> %494, %495
  %497 = load <8 x i64>, ptr %.spill105, align 64
  %498 = select <8 x i1> %453, <8 x i64> %496, <8 x i64> %497
  store <8 x i64> %498, ptr %.spill105, align 64
  %499 = load <8 x i64>, ptr %.slot106, align 64
  %500 = select <8 x i1> %453, <8 x i64> zeroinitializer, <8 x i64> %499
  store <8 x i64> %500, ptr %.slot106, align 64
  %501 = load <8 x float>, ptr %.slot107, align 32
  %502 = select <8 x i1> %453, <8 x float> zeroinitializer, <8 x float> %501
  store <8 x float> %502, ptr %.slot107, align 32
  %503 = load <8 x float>, ptr %.slot108, align 32
  %504 = select <8 x i1> %453, <8 x float> zeroinitializer, <8 x float> %503
  store <8 x float> %504, ptr %.slot108, align 32
  %505 = load <8 x float>, ptr %.slot109, align 32
  %506 = select <8 x i1> %453, <8 x float> zeroinitializer, <8 x float> %505
  store <8 x float> %506, ptr %.slot109, align 32
  %507 = load <8 x float>, ptr %.slot110, align 32
  %508 = select <8 x i1> %453, <8 x float> zeroinitializer, <8 x float> %507
  store <8 x float> %508, ptr %.slot110, align 32
  store <8 x i1> %453, ptr %current.mask, align 1
  %509 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %453)
  br i1 %509, label %schedule.25, label %scheduler.loop

schedule.25:                                      ; preds = %schedule.26, %schedule.24, %scheduler.dispatch.route
  %510 = load <8 x i1>, ptr %current.mask, align 1
  %511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %510)
  %512 = bitcast <8 x i1> %510 to i8
  %513 = call i8 @llvm.cttz.i8(i8 %512, i1 false)
  %514 = zext i8 %513 to i32
  %515 = select i1 %511, i32 %514, i32 0
  %.state438 = load <8 x i64>, ptr %.slot106, align 64
  %516 = icmp slt <8 x i64> %.state438, splat (i64 48)
  %517 = and <8 x i1> %510, %516
  %518 = xor <8 x i1> %516, splat (i1 true)
  %519 = and <8 x i1> %510, %518
  %520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %517)
  %521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %519)
  %522 = and i1 %520, %521
  br i1 %522, label %varying.divergent439, label %varying.coherent440

schedule.26:                                      ; preds = %varying.coherent.true445, %scheduler.dispatch.route
  %523 = load <8 x i1>, ptr %current.mask, align 1
  %524 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %523)
  %525 = bitcast <8 x i1> %523 to i8
  %526 = call i8 @llvm.cttz.i8(i8 %525, i1 false)
  %527 = zext i8 %526 to i32
  %528 = select i1 %524, i32 %527, i32 0
  %.spill.load447 = load <8 x i64>, ptr %.spill99, align 64
  %529 = add <8 x i64> zeroinitializer, %.spill.load447
  %530 = mul <8 x i64> %529, splat (i64 48)
  %.state448 = load <8 x i64>, ptr %.slot106, align 64
  %531 = add <8 x i64> %530, %.state448
  %tile_snapshot.spill.load449 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load449, 0
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load449, 1
  %534 = mul <8 x i64> %531, splat (i64 32)
  %535 = add <8 x i64> %533, %534
  %536 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %532, 0
  %537 = insertvalue { <8 x ptr>, <8 x i64> } %536, <8 x i64> %535, 1
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %537, 0
  %539 = extractvalue { <8 x ptr>, <8 x i64> } %537, 1
  %540 = getelementptr i8, <8 x ptr> %538, <8 x i64> %539
  %541 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %540, <8 x i1> %523, <8 x float> zeroinitializer)
  %.spill.load450 = load <8 x i64>, ptr %.spill98, align 64
  %542 = add <8 x i64> zeroinitializer, %.spill.load450
  %543 = mul <8 x i64> %542, splat (i64 48)
  %.state451 = load <8 x i64>, ptr %.slot106, align 64
  %544 = add <8 x i64> %543, %.state451
  %tile_snapshot.spill.load452 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill86, align 64
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load452, 0
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load452, 1
  %547 = mul <8 x i64> %544, splat (i64 32)
  %548 = add <8 x i64> %546, %547
  %549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %545, 0
  %550 = insertvalue { <8 x ptr>, <8 x i64> } %549, <8 x i64> %548, 1
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %550, 0
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %550, 1
  %553 = getelementptr i8, <8 x ptr> %551, <8 x i64> %552
  %554 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %553, <8 x i1> %523, <8 x float> zeroinitializer)
  %555 = fmul <8 x float> %541, %554
  %.state453 = load <8 x float>, ptr %.slot107, align 32
  %556 = fadd <8 x float> %.state453, %555
  %.spill.load454 = load <8 x i64>, ptr %.spill101, align 64
  %557 = add <8 x i64> zeroinitializer, %.spill.load454
  %558 = mul <8 x i64> %557, splat (i64 48)
  %.state455 = load <8 x i64>, ptr %.slot106, align 64
  %559 = add <8 x i64> %558, %.state455
  %tile_snapshot.spill.load456 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill86, align 64
  %560 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 0
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 1
  %562 = mul <8 x i64> %559, splat (i64 32)
  %563 = add <8 x i64> %561, %562
  %564 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %560, 0
  %565 = insertvalue { <8 x ptr>, <8 x i64> } %564, <8 x i64> %563, 1
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %565, 0
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %565, 1
  %568 = getelementptr i8, <8 x ptr> %566, <8 x i64> %567
  %569 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %568, <8 x i1> %523, <8 x float> zeroinitializer)
  %570 = fmul <8 x float> %541, %569
  %.state457 = load <8 x float>, ptr %.slot108, align 32
  %571 = fadd <8 x float> %.state457, %570
  %.spill.load458 = load <8 x i64>, ptr %.spill103, align 64
  %572 = add <8 x i64> zeroinitializer, %.spill.load458
  %573 = mul <8 x i64> %572, splat (i64 48)
  %.state459 = load <8 x i64>, ptr %.slot106, align 64
  %574 = add <8 x i64> %573, %.state459
  %tile_snapshot.spill.load460 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill86, align 64
  %575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load460, 0
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load460, 1
  %577 = mul <8 x i64> %574, splat (i64 32)
  %578 = add <8 x i64> %576, %577
  %579 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %575, 0
  %580 = insertvalue { <8 x ptr>, <8 x i64> } %579, <8 x i64> %578, 1
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %580, 0
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %580, 1
  %583 = getelementptr i8, <8 x ptr> %581, <8 x i64> %582
  %584 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %583, <8 x i1> %523, <8 x float> zeroinitializer)
  %585 = fmul <8 x float> %541, %584
  %.state461 = load <8 x float>, ptr %.slot109, align 32
  %586 = fadd <8 x float> %.state461, %585
  %.spill.load462 = load <8 x i64>, ptr %.spill105, align 64
  %587 = add <8 x i64> zeroinitializer, %.spill.load462
  %588 = mul <8 x i64> %587, splat (i64 48)
  %.state463 = load <8 x i64>, ptr %.slot106, align 64
  %589 = add <8 x i64> %588, %.state463
  %tile_snapshot.spill.load464 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill86, align 64
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load464, 0
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load464, 1
  %592 = mul <8 x i64> %589, splat (i64 32)
  %593 = add <8 x i64> %591, %592
  %594 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %590, 0
  %595 = insertvalue { <8 x ptr>, <8 x i64> } %594, <8 x i64> %593, 1
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %595, 0
  %597 = extractvalue { <8 x ptr>, <8 x i64> } %595, 1
  %598 = getelementptr i8, <8 x ptr> %596, <8 x i64> %597
  %599 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %598, <8 x i1> %523, <8 x float> zeroinitializer)
  %600 = fmul <8 x float> %541, %599
  %.state465 = load <8 x float>, ptr %.slot110, align 32
  %601 = fadd <8 x float> %.state465, %600
  %.state466 = load <8 x i64>, ptr %.slot106, align 64
  %602 = add <8 x i64> %.state466, splat (i64 1)
  %603 = load <8 x i64>, ptr %.slot106, align 64
  %604 = select <8 x i1> %523, <8 x i64> %602, <8 x i64> %603
  store <8 x i64> %604, ptr %.slot106, align 64
  %605 = load <8 x float>, ptr %.slot107, align 32
  %606 = select <8 x i1> %523, <8 x float> %556, <8 x float> %605
  store <8 x float> %606, ptr %.slot107, align 32
  %607 = load <8 x float>, ptr %.slot108, align 32
  %608 = select <8 x i1> %523, <8 x float> %571, <8 x float> %607
  store <8 x float> %608, ptr %.slot108, align 32
  %609 = load <8 x float>, ptr %.slot109, align 32
  %610 = select <8 x i1> %523, <8 x float> %586, <8 x float> %609
  store <8 x float> %610, ptr %.slot109, align 32
  %611 = load <8 x float>, ptr %.slot110, align 32
  %612 = select <8 x i1> %523, <8 x float> %601, <8 x float> %611
  store <8 x float> %612, ptr %.slot110, align 32
  store <8 x i1> %523, ptr %current.mask, align 1
  %613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %523)
  br i1 %613, label %schedule.25, label %scheduler.loop

schedule.27:                                      ; preds = %varying.coherent.false446, %scheduler.dispatch.route
  %614 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token469 = load i32, ptr %current.token, align 4
  %convergence.token.present470 = icmp ne i32 %convergence.current.token469, 0
  br i1 %convergence.token.present470, label %convergence.cascade467, label %convergence.cascade.exit468

schedule.28:                                      ; preds = %varying.coherent.false435, %scheduler.dispatch.route
  %615 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token499 = load i32, ptr %current.token, align 4
  %convergence.token.present500 = icmp ne i32 %convergence.current.token499, 0
  br i1 %convergence.token.present500, label %convergence.cascade497, label %convergence.cascade.exit498

schedule.29:                                      ; preds = %varying.coherent.false426, %scheduler.dispatch.route
  %616 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token517 = load i32, ptr %current.token, align 4
  %convergence.token.present518 = icmp ne i32 %convergence.current.token517, 0
  br i1 %convergence.token.present518, label %convergence.cascade515, label %convergence.cascade.exit516

schedule.30:                                      ; preds = %schedule.31, %convergence.target.29.ready, %scheduler.dispatch.route
  %617 = load <8 x i1>, ptr %current.mask, align 1
  %618 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %617)
  %619 = bitcast <8 x i1> %617 to i8
  %620 = call i8 @llvm.cttz.i8(i8 %619, i1 false)
  %621 = zext i8 %620 to i32
  %622 = select i1 %618, i32 %621, i32 0
  %.state602 = load <8 x i64>, ptr %.slot115, align 64
  %623 = icmp slt <8 x i64> %.state602, splat (i64 128)
  %624 = and <8 x i1> %617, %623
  %625 = xor <8 x i1> %623, splat (i1 true)
  %626 = and <8 x i1> %617, %625
  %627 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %624)
  %628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %626)
  %629 = and i1 %627, %628
  br i1 %629, label %varying.divergent603, label %varying.coherent604

schedule.31:                                      ; preds = %varying.coherent.true609, %scheduler.dispatch.route
  %630 = load <8 x i1>, ptr %current.mask, align 1
  %631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %630)
  %632 = bitcast <8 x i1> %630 to i8
  %633 = call i8 @llvm.cttz.i8(i8 %632, i1 false)
  %634 = zext i8 %633 to i32
  %635 = select i1 %631, i32 %634, i32 0
  %.state611 = load <8 x i64>, ptr %.slot115, align 64
  %636 = select <8 x i1> %630, <8 x i64> %.state611, <8 x i64> zeroinitializer
  %637 = select <8 x i1> %630, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %638 = srem <8 x i64> %636, %637
  %.state612 = load <8 x i64>, ptr %.slot115, align 64
  %639 = select <8 x i1> %630, <8 x i64> %.state612, <8 x i64> zeroinitializer
  %640 = select <8 x i1> %630, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %641 = sdiv <8 x i64> %639, %640
  %642 = add <8 x i64> zeroinitializer, %641
  %tile_snapshot.spill.load613 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load613, 0
  %644 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load613, 1
  %645 = add <8 x i64> %644, %642
  %646 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %643, 0
  %647 = insertvalue { <8 x ptr>, <8 x i64> } %646, <8 x i64> %645, 1
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %647, 0
  %649 = extractvalue { <8 x ptr>, <8 x i64> } %647, 1
  %650 = getelementptr i8, <8 x ptr> %648, <8 x i64> %649
  %651 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %650, <8 x i1> %630, <8 x i8> zeroinitializer)
  %652 = icmp ne <8 x i8> %651, zeroinitializer
  %653 = mul <8 x i64> %642, splat (i64 8)
  %654 = add <8 x i64> %653, %638
  %655 = select <8 x i1> %630, <8 x i64> %654, <8 x i64> zeroinitializer
  %656 = select <8 x i1> %630, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %657 = srem <8 x i64> %655, %656
  %658 = select <8 x i1> %630, <8 x i64> %654, <8 x i64> zeroinitializer
  %659 = select <8 x i1> %630, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %660 = sdiv <8 x i64> %658, %659
  %661 = add <8 x i64> zeroinitializer, %660
  %tile_snapshot.spill.load614 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load614, 0
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load614, 1
  %664 = mul <8 x i64> %661, splat (i64 64)
  %665 = add <8 x i64> %663, %664
  %666 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %662, 0
  %667 = insertvalue { <8 x ptr>, <8 x i64> } %666, <8 x i64> %665, 1
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %667, 0
  %669 = extractvalue { <8 x ptr>, <8 x i64> } %667, 1
  %670 = getelementptr i8, <8 x ptr> %668, <8 x i64> %669
  %671 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %670, <8 x i1> %630, <8 x i64> zeroinitializer)
  %672 = add <8 x i64> zeroinitializer, %657
  %tile_snapshot.spill.load615 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill113, align 64
  %673 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load615, 0
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load615, 1
  %675 = mul <8 x i64> %672, splat (i64 64)
  %676 = add <8 x i64> %674, %675
  %677 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %673, 0
  %678 = insertvalue { <8 x ptr>, <8 x i64> } %677, <8 x i64> %676, 1
  %679 = extractvalue { <8 x ptr>, <8 x i64> } %678, 0
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %678, 1
  %681 = getelementptr i8, <8 x ptr> %679, <8 x i64> %680
  %682 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %681, <8 x i1> %630, <8 x i64> zeroinitializer)
  %683 = icmp sle <8 x i64> %671, %682
  %684 = and <8 x i1> %652, %683
  %tile_snapshot.spill.load616 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load616, 0
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load616, 1
  %.state617 = load <8 x i64>, ptr %.slot115, align 64
  %687 = add <8 x i64> %686, %.state617
  %688 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %685, 0
  %689 = insertvalue { <8 x ptr>, <8 x i64> } %688, <8 x i64> %687, 1
  %690 = extractvalue { <8 x ptr>, <8 x i64> } %689, 0
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %689, 1
  %692 = getelementptr i8, <8 x ptr> %690, <8 x i64> %691
  %693 = zext <8 x i1> %684 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %693, <8 x ptr> align 1 %692, <8 x i1> %630)
  %.state618 = load <8 x i64>, ptr %.slot115, align 64
  %694 = add <8 x i64> %.state618, splat (i64 1)
  %695 = load <8 x i64>, ptr %.slot115, align 64
  %696 = select <8 x i1> %630, <8 x i64> %694, <8 x i64> %695
  store <8 x i64> %696, ptr %.slot115, align 64
  store <8 x i1> %630, ptr %current.mask, align 1
  %697 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %630)
  br i1 %697, label %schedule.30, label %scheduler.loop

schedule.32:                                      ; preds = %varying.coherent.false610, %scheduler.dispatch.route
  %698 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token621 = load i32, ptr %current.token, align 4
  %convergence.token.present622 = icmp ne i32 %convergence.current.token621, 0
  br i1 %convergence.token.present622, label %convergence.cascade619, label %convergence.cascade.exit620

schedule.33:                                      ; preds = %schedule.34, %convergence.target.32.ready, %scheduler.dispatch.route
  %699 = load <8 x i1>, ptr %current.mask, align 1
  %700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %699)
  %701 = bitcast <8 x i1> %699 to i8
  %702 = call i8 @llvm.cttz.i8(i8 %701, i1 false)
  %703 = zext i8 %702 to i32
  %704 = select i1 %700, i32 %703, i32 0
  %.state636 = load <8 x i64>, ptr %.slot117, align 64
  %705 = icmp slt <8 x i64> %.state636, splat (i64 128)
  %706 = and <8 x i1> %699, %705
  %707 = xor <8 x i1> %705, splat (i1 true)
  %708 = and <8 x i1> %699, %707
  %709 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %706)
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %708)
  %711 = and i1 %709, %710
  br i1 %711, label %varying.divergent637, label %varying.coherent638

schedule.34:                                      ; preds = %varying.coherent.true643, %scheduler.dispatch.route
  %712 = load <8 x i1>, ptr %current.mask, align 1
  %713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %712)
  %714 = bitcast <8 x i1> %712 to i8
  %715 = call i8 @llvm.cttz.i8(i8 %714, i1 false)
  %716 = zext i8 %715 to i32
  %717 = select i1 %713, i32 %716, i32 0
  %.state645 = load <8 x i64>, ptr %.slot117, align 64
  %718 = select <8 x i1> %712, <8 x i64> %.state645, <8 x i64> zeroinitializer
  %719 = select <8 x i1> %712, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %720 = srem <8 x i64> %718, %719
  %.state646 = load <8 x i64>, ptr %.slot117, align 64
  %721 = select <8 x i1> %712, <8 x i64> %.state646, <8 x i64> zeroinitializer
  %722 = select <8 x i1> %712, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %723 = sdiv <8 x i64> %721, %722
  %724 = add <8 x i64> zeroinitializer, %720
  %725 = mul <8 x i64> %724, splat (i64 8)
  %726 = add <8 x i64> %725, %723
  %tile_snapshot.spill.load647 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %727 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load647, 0
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load647, 1
  %729 = add <8 x i64> %728, %726
  %730 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %727, 0
  %731 = insertvalue { <8 x ptr>, <8 x i64> } %730, <8 x i64> %729, 1
  %732 = extractvalue { <8 x ptr>, <8 x i64> } %731, 0
  %733 = extractvalue { <8 x ptr>, <8 x i64> } %731, 1
  %734 = getelementptr i8, <8 x ptr> %732, <8 x i64> %733
  %735 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %734, <8 x i1> %712, <8 x i8> zeroinitializer)
  %736 = icmp ne <8 x i8> %735, zeroinitializer
  %737 = add <8 x i64> zeroinitializer, %723
  %738 = mul <8 x i64> %737, splat (i64 16)
  %739 = add <8 x i64> %738, %720
  %740 = select <8 x i1> %712, <8 x i64> %739, <8 x i64> zeroinitializer
  %741 = select <8 x i1> %712, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %742 = srem <8 x i64> %740, %741
  %743 = select <8 x i1> %712, <8 x i64> %739, <8 x i64> zeroinitializer
  %744 = select <8 x i1> %712, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %745 = sdiv <8 x i64> %743, %744
  %746 = add <8 x i64> zeroinitializer, %745
  %747 = mul <8 x i64> %746, splat (i64 16)
  %748 = add <8 x i64> %747, %742
  %tile_snapshot.spill.load648 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %749 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load648, 0
  %750 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load648, 1
  %751 = mul <8 x i64> %748, splat (i64 32)
  %752 = add <8 x i64> %750, %751
  %753 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %749, 0
  %754 = insertvalue { <8 x ptr>, <8 x i64> } %753, <8 x i64> %752, 1
  %755 = extractvalue { <8 x ptr>, <8 x i64> } %754, 0
  %756 = extractvalue { <8 x ptr>, <8 x i64> } %754, 1
  %757 = getelementptr i8, <8 x ptr> %755, <8 x i64> %756
  %758 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %757, <8 x i1> %712, <8 x float> zeroinitializer)
  %759 = fmul <8 x float> %758, splat (float 0x3FC279A740000000)
  %760 = select <8 x i1> %736, <8 x float> %759, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load649 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load649, 0
  %762 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load649, 1
  %.state650 = load <8 x i64>, ptr %.slot117, align 64
  %763 = mul <8 x i64> %.state650, splat (i64 32)
  %764 = add <8 x i64> %762, %763
  %765 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %761, 0
  %766 = insertvalue { <8 x ptr>, <8 x i64> } %765, <8 x i64> %764, 1
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %766, 0
  %768 = extractvalue { <8 x ptr>, <8 x i64> } %766, 1
  %769 = getelementptr i8, <8 x ptr> %767, <8 x i64> %768
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %760, <8 x ptr> align 1 %769, <8 x i1> %712)
  %.state651 = load <8 x i64>, ptr %.slot117, align 64
  %770 = add <8 x i64> %.state651, splat (i64 1)
  %771 = load <8 x i64>, ptr %.slot117, align 64
  %772 = select <8 x i1> %712, <8 x i64> %770, <8 x i64> %771
  store <8 x i64> %772, ptr %.slot117, align 64
  store <8 x i1> %712, ptr %current.mask, align 1
  %773 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %712)
  br i1 %773, label %schedule.33, label %scheduler.loop

schedule.35:                                      ; preds = %varying.coherent.false644, %scheduler.dispatch.route
  %774 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token654 = load i32, ptr %current.token, align 4
  %convergence.token.present655 = icmp ne i32 %convergence.current.token654, 0
  br i1 %convergence.token.present655, label %convergence.cascade652, label %convergence.cascade.exit653

schedule.36:                                      ; preds = %schedule.37, %convergence.target.35.ready, %scheduler.dispatch.route
  %775 = load <8 x i1>, ptr %current.mask, align 1
  %776 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %775)
  %777 = bitcast <8 x i1> %775 to i8
  %778 = call i8 @llvm.cttz.i8(i8 %777, i1 false)
  %779 = zext i8 %778 to i32
  %780 = select i1 %776, i32 %779, i32 0
  %.state669 = load <8 x i64>, ptr %.slot118, align 64
  %781 = icmp slt <8 x i64> %.state669, splat (i64 16)
  %782 = and <8 x i1> %775, %781
  %783 = xor <8 x i1> %781, splat (i1 true)
  %784 = and <8 x i1> %775, %783
  %785 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %784)
  %787 = and i1 %785, %786
  br i1 %787, label %varying.divergent670, label %varying.coherent671

schedule.37:                                      ; preds = %varying.coherent.true676, %scheduler.dispatch.route
  %788 = load <8 x i1>, ptr %current.mask, align 1
  %789 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %788)
  %790 = bitcast <8 x i1> %788 to i8
  %791 = call i8 @llvm.cttz.i8(i8 %790, i1 false)
  %792 = zext i8 %791 to i32
  %793 = select i1 %789, i32 %792, i32 0
  %.state678 = load <8 x i64>, ptr %.slot118, align 64
  %794 = select <8 x i1> %788, <8 x i64> %.state678, <8 x i64> zeroinitializer
  %795 = select <8 x i1> %788, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %796 = sdiv <8 x i64> %794, %795
  %797 = add <8 x i64> zeroinitializer, %796
  %tile_snapshot.spill.load679 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load679, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load679, 1
  %800 = mul <8 x i64> %797, splat (i64 32)
  %801 = add <8 x i64> %799, %800
  %802 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %798, 0
  %803 = insertvalue { <8 x ptr>, <8 x i64> } %802, <8 x i64> %801, 1
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %803, 0
  %805 = extractvalue { <8 x ptr>, <8 x i64> } %803, 1
  %806 = getelementptr i8, <8 x ptr> %804, <8 x i64> %805
  %807 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %806, <8 x i1> %788, <8 x float> zeroinitializer)
  %.state680 = load <8 x float>, ptr %.slot119, align 32
  %808 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state680, <8 x float> %807)
  %.state681 = load <8 x i64>, ptr %.slot118, align 64
  %809 = add <8 x i64> %.state681, splat (i64 1)
  %810 = load <8 x i64>, ptr %.slot118, align 64
  %811 = select <8 x i1> %788, <8 x i64> %809, <8 x i64> %810
  store <8 x i64> %811, ptr %.slot118, align 64
  %812 = load <8 x float>, ptr %.slot119, align 32
  %813 = select <8 x i1> %788, <8 x float> %808, <8 x float> %812
  store <8 x float> %813, ptr %.slot119, align 32
  store <8 x i1> %788, ptr %current.mask, align 1
  %814 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %788)
  br i1 %814, label %schedule.36, label %scheduler.loop

schedule.38:                                      ; preds = %varying.coherent.false677, %scheduler.dispatch.route
  %815 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token684 = load i32, ptr %current.token, align 4
  %convergence.token.present685 = icmp ne i32 %convergence.current.token684, 0
  br i1 %convergence.token.present685, label %convergence.cascade682, label %convergence.cascade.exit683

schedule.39:                                      ; preds = %schedule.40, %convergence.target.38.ready, %scheduler.dispatch.route
  %816 = load <8 x i1>, ptr %current.mask, align 1
  %817 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %816)
  %818 = bitcast <8 x i1> %816 to i8
  %819 = call i8 @llvm.cttz.i8(i8 %818, i1 false)
  %820 = zext i8 %819 to i32
  %821 = select i1 %817, i32 %820, i32 0
  %.state699 = load <8 x i64>, ptr %.slot120, align 64
  %822 = icmp slt <8 x i64> %.state699, splat (i64 16)
  %823 = and <8 x i1> %816, %822
  %824 = xor <8 x i1> %822, splat (i1 true)
  %825 = and <8 x i1> %816, %824
  %826 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %823)
  %827 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %825)
  %828 = and i1 %826, %827
  br i1 %828, label %varying.divergent700, label %varying.coherent701

schedule.40:                                      ; preds = %varying.coherent.true706, %scheduler.dispatch.route
  %829 = load <8 x i1>, ptr %current.mask, align 1
  %830 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %829)
  %831 = bitcast <8 x i1> %829 to i8
  %832 = call i8 @llvm.cttz.i8(i8 %831, i1 false)
  %833 = zext i8 %832 to i32
  %834 = select i1 %830, i32 %833, i32 0
  %.state708 = load <8 x i64>, ptr %.slot120, align 64
  %835 = select <8 x i1> %829, <8 x i64> %.state708, <8 x i64> zeroinitializer
  %836 = select <8 x i1> %829, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %837 = sdiv <8 x i64> %835, %836
  %838 = add <8 x i64> splat (i64 16), %837
  %tile_snapshot.spill.load709 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load709, 0
  %840 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load709, 1
  %841 = mul <8 x i64> %838, splat (i64 32)
  %842 = add <8 x i64> %840, %841
  %843 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %839, 0
  %844 = insertvalue { <8 x ptr>, <8 x i64> } %843, <8 x i64> %842, 1
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %844, 0
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %844, 1
  %847 = getelementptr i8, <8 x ptr> %845, <8 x i64> %846
  %848 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %847, <8 x i1> %829, <8 x float> zeroinitializer)
  %.state710 = load <8 x float>, ptr %.slot121, align 32
  %849 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state710, <8 x float> %848)
  %.state711 = load <8 x i64>, ptr %.slot120, align 64
  %850 = add <8 x i64> %.state711, splat (i64 1)
  %851 = load <8 x i64>, ptr %.slot120, align 64
  %852 = select <8 x i1> %829, <8 x i64> %850, <8 x i64> %851
  store <8 x i64> %852, ptr %.slot120, align 64
  %853 = load <8 x float>, ptr %.slot121, align 32
  %854 = select <8 x i1> %829, <8 x float> %849, <8 x float> %853
  store <8 x float> %854, ptr %.slot121, align 32
  store <8 x i1> %829, ptr %current.mask, align 1
  %855 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %829)
  br i1 %855, label %schedule.39, label %scheduler.loop

schedule.41:                                      ; preds = %varying.coherent.false707, %scheduler.dispatch.route
  %856 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token714 = load i32, ptr %current.token, align 4
  %convergence.token.present715 = icmp ne i32 %convergence.current.token714, 0
  br i1 %convergence.token.present715, label %convergence.cascade712, label %convergence.cascade.exit713

schedule.42:                                      ; preds = %schedule.43, %convergence.target.41.ready, %scheduler.dispatch.route
  %857 = load <8 x i1>, ptr %current.mask, align 1
  %858 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %857)
  %859 = bitcast <8 x i1> %857 to i8
  %860 = call i8 @llvm.cttz.i8(i8 %859, i1 false)
  %861 = zext i8 %860 to i32
  %862 = select i1 %858, i32 %861, i32 0
  %.state729 = load <8 x i64>, ptr %.slot122, align 64
  %863 = icmp slt <8 x i64> %.state729, splat (i64 16)
  %864 = and <8 x i1> %857, %863
  %865 = xor <8 x i1> %863, splat (i1 true)
  %866 = and <8 x i1> %857, %865
  %867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %864)
  %868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %866)
  %869 = and i1 %867, %868
  br i1 %869, label %varying.divergent730, label %varying.coherent731

schedule.43:                                      ; preds = %varying.coherent.true736, %scheduler.dispatch.route
  %870 = load <8 x i1>, ptr %current.mask, align 1
  %871 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %870)
  %872 = bitcast <8 x i1> %870 to i8
  %873 = call i8 @llvm.cttz.i8(i8 %872, i1 false)
  %874 = zext i8 %873 to i32
  %875 = select i1 %871, i32 %874, i32 0
  %.state738 = load <8 x i64>, ptr %.slot122, align 64
  %876 = select <8 x i1> %870, <8 x i64> %.state738, <8 x i64> zeroinitializer
  %877 = select <8 x i1> %870, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %878 = sdiv <8 x i64> %876, %877
  %879 = add <8 x i64> splat (i64 32), %878
  %tile_snapshot.spill.load739 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %880 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load739, 0
  %881 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load739, 1
  %882 = mul <8 x i64> %879, splat (i64 32)
  %883 = add <8 x i64> %881, %882
  %884 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %880, 0
  %885 = insertvalue { <8 x ptr>, <8 x i64> } %884, <8 x i64> %883, 1
  %886 = extractvalue { <8 x ptr>, <8 x i64> } %885, 0
  %887 = extractvalue { <8 x ptr>, <8 x i64> } %885, 1
  %888 = getelementptr i8, <8 x ptr> %886, <8 x i64> %887
  %889 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %888, <8 x i1> %870, <8 x float> zeroinitializer)
  %.state740 = load <8 x float>, ptr %.slot123, align 32
  %890 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state740, <8 x float> %889)
  %.state741 = load <8 x i64>, ptr %.slot122, align 64
  %891 = add <8 x i64> %.state741, splat (i64 1)
  %892 = load <8 x i64>, ptr %.slot122, align 64
  %893 = select <8 x i1> %870, <8 x i64> %891, <8 x i64> %892
  store <8 x i64> %893, ptr %.slot122, align 64
  %894 = load <8 x float>, ptr %.slot123, align 32
  %895 = select <8 x i1> %870, <8 x float> %890, <8 x float> %894
  store <8 x float> %895, ptr %.slot123, align 32
  store <8 x i1> %870, ptr %current.mask, align 1
  %896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %870)
  br i1 %896, label %schedule.42, label %scheduler.loop

schedule.44:                                      ; preds = %varying.coherent.false737, %scheduler.dispatch.route
  %897 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token744 = load i32, ptr %current.token, align 4
  %convergence.token.present745 = icmp ne i32 %convergence.current.token744, 0
  br i1 %convergence.token.present745, label %convergence.cascade742, label %convergence.cascade.exit743

schedule.45:                                      ; preds = %schedule.46, %convergence.target.44.ready, %scheduler.dispatch.route
  %898 = load <8 x i1>, ptr %current.mask, align 1
  %899 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %898)
  %900 = bitcast <8 x i1> %898 to i8
  %901 = call i8 @llvm.cttz.i8(i8 %900, i1 false)
  %902 = zext i8 %901 to i32
  %903 = select i1 %899, i32 %902, i32 0
  %.state759 = load <8 x i64>, ptr %.slot124, align 64
  %904 = icmp slt <8 x i64> %.state759, splat (i64 16)
  %905 = and <8 x i1> %898, %904
  %906 = xor <8 x i1> %904, splat (i1 true)
  %907 = and <8 x i1> %898, %906
  %908 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %905)
  %909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %907)
  %910 = and i1 %908, %909
  br i1 %910, label %varying.divergent760, label %varying.coherent761

schedule.46:                                      ; preds = %varying.coherent.true766, %scheduler.dispatch.route
  %911 = load <8 x i1>, ptr %current.mask, align 1
  %912 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %911)
  %913 = bitcast <8 x i1> %911 to i8
  %914 = call i8 @llvm.cttz.i8(i8 %913, i1 false)
  %915 = zext i8 %914 to i32
  %916 = select i1 %912, i32 %915, i32 0
  %.state768 = load <8 x i64>, ptr %.slot124, align 64
  %917 = select <8 x i1> %911, <8 x i64> %.state768, <8 x i64> zeroinitializer
  %918 = select <8 x i1> %911, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %919 = sdiv <8 x i64> %917, %918
  %920 = add <8 x i64> splat (i64 48), %919
  %tile_snapshot.spill.load769 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 0
  %922 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 1
  %923 = mul <8 x i64> %920, splat (i64 32)
  %924 = add <8 x i64> %922, %923
  %925 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %921, 0
  %926 = insertvalue { <8 x ptr>, <8 x i64> } %925, <8 x i64> %924, 1
  %927 = extractvalue { <8 x ptr>, <8 x i64> } %926, 0
  %928 = extractvalue { <8 x ptr>, <8 x i64> } %926, 1
  %929 = getelementptr i8, <8 x ptr> %927, <8 x i64> %928
  %930 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %929, <8 x i1> %911, <8 x float> zeroinitializer)
  %.state770 = load <8 x float>, ptr %.slot125, align 32
  %931 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state770, <8 x float> %930)
  %.state771 = load <8 x i64>, ptr %.slot124, align 64
  %932 = add <8 x i64> %.state771, splat (i64 1)
  %933 = load <8 x i64>, ptr %.slot124, align 64
  %934 = select <8 x i1> %911, <8 x i64> %932, <8 x i64> %933
  store <8 x i64> %934, ptr %.slot124, align 64
  %935 = load <8 x float>, ptr %.slot125, align 32
  %936 = select <8 x i1> %911, <8 x float> %931, <8 x float> %935
  store <8 x float> %936, ptr %.slot125, align 32
  store <8 x i1> %911, ptr %current.mask, align 1
  %937 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %911)
  br i1 %937, label %schedule.45, label %scheduler.loop

schedule.47:                                      ; preds = %varying.coherent.false767, %scheduler.dispatch.route
  %938 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token774 = load i32, ptr %current.token, align 4
  %convergence.token.present775 = icmp ne i32 %convergence.current.token774, 0
  br i1 %convergence.token.present775, label %convergence.cascade772, label %convergence.cascade.exit773

schedule.48:                                      ; preds = %schedule.49, %convergence.target.47.ready, %scheduler.dispatch.route
  %939 = load <8 x i1>, ptr %current.mask, align 1
  %940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %939)
  %941 = bitcast <8 x i1> %939 to i8
  %942 = call i8 @llvm.cttz.i8(i8 %941, i1 false)
  %943 = zext i8 %942 to i32
  %944 = select i1 %940, i32 %943, i32 0
  %.state789 = load <8 x i64>, ptr %.slot126, align 64
  %945 = icmp slt <8 x i64> %.state789, splat (i64 16)
  %946 = and <8 x i1> %939, %945
  %947 = xor <8 x i1> %945, splat (i1 true)
  %948 = and <8 x i1> %939, %947
  %949 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %946)
  %950 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %948)
  %951 = and i1 %949, %950
  br i1 %951, label %varying.divergent790, label %varying.coherent791

schedule.49:                                      ; preds = %varying.coherent.true796, %scheduler.dispatch.route
  %952 = load <8 x i1>, ptr %current.mask, align 1
  %953 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %952)
  %954 = bitcast <8 x i1> %952 to i8
  %955 = call i8 @llvm.cttz.i8(i8 %954, i1 false)
  %956 = zext i8 %955 to i32
  %957 = select i1 %953, i32 %956, i32 0
  %.state798 = load <8 x i64>, ptr %.slot126, align 64
  %958 = select <8 x i1> %952, <8 x i64> %.state798, <8 x i64> zeroinitializer
  %959 = select <8 x i1> %952, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %960 = sdiv <8 x i64> %958, %959
  %961 = add <8 x i64> splat (i64 64), %960
  %tile_snapshot.spill.load799 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %962 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load799, 0
  %963 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load799, 1
  %964 = mul <8 x i64> %961, splat (i64 32)
  %965 = add <8 x i64> %963, %964
  %966 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %962, 0
  %967 = insertvalue { <8 x ptr>, <8 x i64> } %966, <8 x i64> %965, 1
  %968 = extractvalue { <8 x ptr>, <8 x i64> } %967, 0
  %969 = extractvalue { <8 x ptr>, <8 x i64> } %967, 1
  %970 = getelementptr i8, <8 x ptr> %968, <8 x i64> %969
  %971 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %970, <8 x i1> %952, <8 x float> zeroinitializer)
  %.state800 = load <8 x float>, ptr %.slot127, align 32
  %972 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state800, <8 x float> %971)
  %.state801 = load <8 x i64>, ptr %.slot126, align 64
  %973 = add <8 x i64> %.state801, splat (i64 1)
  %974 = load <8 x i64>, ptr %.slot126, align 64
  %975 = select <8 x i1> %952, <8 x i64> %973, <8 x i64> %974
  store <8 x i64> %975, ptr %.slot126, align 64
  %976 = load <8 x float>, ptr %.slot127, align 32
  %977 = select <8 x i1> %952, <8 x float> %972, <8 x float> %976
  store <8 x float> %977, ptr %.slot127, align 32
  store <8 x i1> %952, ptr %current.mask, align 1
  %978 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %952)
  br i1 %978, label %schedule.48, label %scheduler.loop

schedule.50:                                      ; preds = %varying.coherent.false797, %scheduler.dispatch.route
  %979 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token804 = load i32, ptr %current.token, align 4
  %convergence.token.present805 = icmp ne i32 %convergence.current.token804, 0
  br i1 %convergence.token.present805, label %convergence.cascade802, label %convergence.cascade.exit803

schedule.51:                                      ; preds = %schedule.52, %convergence.target.50.ready, %scheduler.dispatch.route
  %980 = load <8 x i1>, ptr %current.mask, align 1
  %981 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %980)
  %982 = bitcast <8 x i1> %980 to i8
  %983 = call i8 @llvm.cttz.i8(i8 %982, i1 false)
  %984 = zext i8 %983 to i32
  %985 = select i1 %981, i32 %984, i32 0
  %.state819 = load <8 x i64>, ptr %.slot128, align 64
  %986 = icmp slt <8 x i64> %.state819, splat (i64 16)
  %987 = and <8 x i1> %980, %986
  %988 = xor <8 x i1> %986, splat (i1 true)
  %989 = and <8 x i1> %980, %988
  %990 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %987)
  %991 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %989)
  %992 = and i1 %990, %991
  br i1 %992, label %varying.divergent820, label %varying.coherent821

schedule.52:                                      ; preds = %varying.coherent.true826, %scheduler.dispatch.route
  %993 = load <8 x i1>, ptr %current.mask, align 1
  %994 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %993)
  %995 = bitcast <8 x i1> %993 to i8
  %996 = call i8 @llvm.cttz.i8(i8 %995, i1 false)
  %997 = zext i8 %996 to i32
  %998 = select i1 %994, i32 %997, i32 0
  %.state828 = load <8 x i64>, ptr %.slot128, align 64
  %999 = select <8 x i1> %993, <8 x i64> %.state828, <8 x i64> zeroinitializer
  %1000 = select <8 x i1> %993, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1001 = sdiv <8 x i64> %999, %1000
  %1002 = add <8 x i64> splat (i64 80), %1001
  %tile_snapshot.spill.load829 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load829, 0
  %1004 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load829, 1
  %1005 = mul <8 x i64> %1002, splat (i64 32)
  %1006 = add <8 x i64> %1004, %1005
  %1007 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1003, 0
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } %1007, <8 x i64> %1006, 1
  %1009 = extractvalue { <8 x ptr>, <8 x i64> } %1008, 0
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %1008, 1
  %1011 = getelementptr i8, <8 x ptr> %1009, <8 x i64> %1010
  %1012 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1011, <8 x i1> %993, <8 x float> zeroinitializer)
  %.state830 = load <8 x float>, ptr %.slot129, align 32
  %1013 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state830, <8 x float> %1012)
  %.state831 = load <8 x i64>, ptr %.slot128, align 64
  %1014 = add <8 x i64> %.state831, splat (i64 1)
  %1015 = load <8 x i64>, ptr %.slot128, align 64
  %1016 = select <8 x i1> %993, <8 x i64> %1014, <8 x i64> %1015
  store <8 x i64> %1016, ptr %.slot128, align 64
  %1017 = load <8 x float>, ptr %.slot129, align 32
  %1018 = select <8 x i1> %993, <8 x float> %1013, <8 x float> %1017
  store <8 x float> %1018, ptr %.slot129, align 32
  store <8 x i1> %993, ptr %current.mask, align 1
  %1019 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %993)
  br i1 %1019, label %schedule.51, label %scheduler.loop

schedule.53:                                      ; preds = %varying.coherent.false827, %scheduler.dispatch.route
  %1020 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token834 = load i32, ptr %current.token, align 4
  %convergence.token.present835 = icmp ne i32 %convergence.current.token834, 0
  br i1 %convergence.token.present835, label %convergence.cascade832, label %convergence.cascade.exit833

schedule.54:                                      ; preds = %schedule.55, %convergence.target.53.ready, %scheduler.dispatch.route
  %1021 = load <8 x i1>, ptr %current.mask, align 1
  %1022 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1021)
  %1023 = bitcast <8 x i1> %1021 to i8
  %1024 = call i8 @llvm.cttz.i8(i8 %1023, i1 false)
  %1025 = zext i8 %1024 to i32
  %1026 = select i1 %1022, i32 %1025, i32 0
  %.state849 = load <8 x i64>, ptr %.slot130, align 64
  %1027 = icmp slt <8 x i64> %.state849, splat (i64 16)
  %1028 = and <8 x i1> %1021, %1027
  %1029 = xor <8 x i1> %1027, splat (i1 true)
  %1030 = and <8 x i1> %1021, %1029
  %1031 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1028)
  %1032 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1030)
  %1033 = and i1 %1031, %1032
  br i1 %1033, label %varying.divergent850, label %varying.coherent851

schedule.55:                                      ; preds = %varying.coherent.true856, %scheduler.dispatch.route
  %1034 = load <8 x i1>, ptr %current.mask, align 1
  %1035 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1034)
  %1036 = bitcast <8 x i1> %1034 to i8
  %1037 = call i8 @llvm.cttz.i8(i8 %1036, i1 false)
  %1038 = zext i8 %1037 to i32
  %1039 = select i1 %1035, i32 %1038, i32 0
  %.state858 = load <8 x i64>, ptr %.slot130, align 64
  %1040 = select <8 x i1> %1034, <8 x i64> %.state858, <8 x i64> zeroinitializer
  %1041 = select <8 x i1> %1034, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1042 = sdiv <8 x i64> %1040, %1041
  %1043 = add <8 x i64> splat (i64 96), %1042
  %tile_snapshot.spill.load859 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1044 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load859, 0
  %1045 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load859, 1
  %1046 = mul <8 x i64> %1043, splat (i64 32)
  %1047 = add <8 x i64> %1045, %1046
  %1048 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1044, 0
  %1049 = insertvalue { <8 x ptr>, <8 x i64> } %1048, <8 x i64> %1047, 1
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %1049, 0
  %1051 = extractvalue { <8 x ptr>, <8 x i64> } %1049, 1
  %1052 = getelementptr i8, <8 x ptr> %1050, <8 x i64> %1051
  %1053 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1052, <8 x i1> %1034, <8 x float> zeroinitializer)
  %.state860 = load <8 x float>, ptr %.slot131, align 32
  %1054 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state860, <8 x float> %1053)
  %.state861 = load <8 x i64>, ptr %.slot130, align 64
  %1055 = add <8 x i64> %.state861, splat (i64 1)
  %1056 = load <8 x i64>, ptr %.slot130, align 64
  %1057 = select <8 x i1> %1034, <8 x i64> %1055, <8 x i64> %1056
  store <8 x i64> %1057, ptr %.slot130, align 64
  %1058 = load <8 x float>, ptr %.slot131, align 32
  %1059 = select <8 x i1> %1034, <8 x float> %1054, <8 x float> %1058
  store <8 x float> %1059, ptr %.slot131, align 32
  store <8 x i1> %1034, ptr %current.mask, align 1
  %1060 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1034)
  br i1 %1060, label %schedule.54, label %scheduler.loop

schedule.56:                                      ; preds = %varying.coherent.false857, %scheduler.dispatch.route
  %1061 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token864 = load i32, ptr %current.token, align 4
  %convergence.token.present865 = icmp ne i32 %convergence.current.token864, 0
  br i1 %convergence.token.present865, label %convergence.cascade862, label %convergence.cascade.exit863

schedule.57:                                      ; preds = %schedule.58, %convergence.target.56.ready, %scheduler.dispatch.route
  %1062 = load <8 x i1>, ptr %current.mask, align 1
  %1063 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1062)
  %1064 = bitcast <8 x i1> %1062 to i8
  %1065 = call i8 @llvm.cttz.i8(i8 %1064, i1 false)
  %1066 = zext i8 %1065 to i32
  %1067 = select i1 %1063, i32 %1066, i32 0
  %.state879 = load <8 x i64>, ptr %.slot132, align 64
  %1068 = icmp slt <8 x i64> %.state879, splat (i64 16)
  %1069 = and <8 x i1> %1062, %1068
  %1070 = xor <8 x i1> %1068, splat (i1 true)
  %1071 = and <8 x i1> %1062, %1070
  %1072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1069)
  %1073 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1071)
  %1074 = and i1 %1072, %1073
  br i1 %1074, label %varying.divergent880, label %varying.coherent881

schedule.58:                                      ; preds = %varying.coherent.true886, %scheduler.dispatch.route
  %1075 = load <8 x i1>, ptr %current.mask, align 1
  %1076 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1075)
  %1077 = bitcast <8 x i1> %1075 to i8
  %1078 = call i8 @llvm.cttz.i8(i8 %1077, i1 false)
  %1079 = zext i8 %1078 to i32
  %1080 = select i1 %1076, i32 %1079, i32 0
  %.state888 = load <8 x i64>, ptr %.slot132, align 64
  %1081 = select <8 x i1> %1075, <8 x i64> %.state888, <8 x i64> zeroinitializer
  %1082 = select <8 x i1> %1075, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1083 = sdiv <8 x i64> %1081, %1082
  %1084 = add <8 x i64> splat (i64 112), %1083
  %tile_snapshot.spill.load889 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1085 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load889, 0
  %1086 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load889, 1
  %1087 = mul <8 x i64> %1084, splat (i64 32)
  %1088 = add <8 x i64> %1086, %1087
  %1089 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1085, 0
  %1090 = insertvalue { <8 x ptr>, <8 x i64> } %1089, <8 x i64> %1088, 1
  %1091 = extractvalue { <8 x ptr>, <8 x i64> } %1090, 0
  %1092 = extractvalue { <8 x ptr>, <8 x i64> } %1090, 1
  %1093 = getelementptr i8, <8 x ptr> %1091, <8 x i64> %1092
  %1094 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1093, <8 x i1> %1075, <8 x float> zeroinitializer)
  %.state890 = load <8 x float>, ptr %.slot133, align 32
  %1095 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state890, <8 x float> %1094)
  %.state891 = load <8 x i64>, ptr %.slot132, align 64
  %1096 = add <8 x i64> %.state891, splat (i64 1)
  %1097 = load <8 x i64>, ptr %.slot132, align 64
  %1098 = select <8 x i1> %1075, <8 x i64> %1096, <8 x i64> %1097
  store <8 x i64> %1098, ptr %.slot132, align 64
  %1099 = load <8 x float>, ptr %.slot133, align 32
  %1100 = select <8 x i1> %1075, <8 x float> %1095, <8 x float> %1099
  store <8 x float> %1100, ptr %.slot133, align 32
  store <8 x i1> %1075, ptr %current.mask, align 1
  %1101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1075)
  br i1 %1101, label %schedule.57, label %scheduler.loop

schedule.59:                                      ; preds = %varying.coherent.false887, %scheduler.dispatch.route
  %1102 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token894 = load i32, ptr %current.token, align 4
  %convergence.token.present895 = icmp ne i32 %convergence.current.token894, 0
  br i1 %convergence.token.present895, label %convergence.cascade892, label %convergence.cascade.exit893

schedule.60:                                      ; preds = %schedule.61, %convergence.target.59.ready, %scheduler.dispatch.route
  %1103 = load <8 x i1>, ptr %current.mask, align 1
  %1104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1103)
  %1105 = bitcast <8 x i1> %1103 to i8
  %1106 = call i8 @llvm.cttz.i8(i8 %1105, i1 false)
  %1107 = zext i8 %1106 to i32
  %1108 = select i1 %1104, i32 %1107, i32 0
  %.state972 = load <8 x i64>, ptr %.slot153, align 64
  %1109 = icmp slt <8 x i64> %.state972, splat (i64 128)
  %1110 = and <8 x i1> %1103, %1109
  %1111 = xor <8 x i1> %1109, splat (i1 true)
  %1112 = and <8 x i1> %1103, %1111
  %1113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1110)
  %1114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1112)
  %1115 = and i1 %1113, %1114
  br i1 %1115, label %varying.divergent973, label %varying.coherent974

schedule.61:                                      ; preds = %varying.coherent.true979, %scheduler.dispatch.route
  %1116 = load <8 x i1>, ptr %current.mask, align 1
  %1117 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1116)
  %1118 = bitcast <8 x i1> %1116 to i8
  %1119 = call i8 @llvm.cttz.i8(i8 %1118, i1 false)
  %1120 = zext i8 %1119 to i32
  %1121 = select i1 %1117, i32 %1120, i32 0
  %.state981 = load <8 x i64>, ptr %.slot153, align 64
  %1122 = select <8 x i1> %1116, <8 x i64> %.state981, <8 x i64> zeroinitializer
  %1123 = select <8 x i1> %1116, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %1124 = srem <8 x i64> %1122, %1123
  %.state982 = load <8 x i64>, ptr %.slot153, align 64
  %1125 = select <8 x i1> %1116, <8 x i64> %.state982, <8 x i64> zeroinitializer
  %1126 = select <8 x i1> %1116, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %1127 = sdiv <8 x i64> %1125, %1126
  %1128 = add <8 x i64> zeroinitializer, %1124
  %1129 = mul <8 x i64> %1128, splat (i64 8)
  %1130 = add <8 x i64> %1129, %1127
  %tile_snapshot.spill.load983 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %1131 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load983, 0
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load983, 1
  %1133 = add <8 x i64> %1132, %1130
  %1134 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1131, 0
  %1135 = insertvalue { <8 x ptr>, <8 x i64> } %1134, <8 x i64> %1133, 1
  %1136 = extractvalue { <8 x ptr>, <8 x i64> } %1135, 0
  %1137 = extractvalue { <8 x ptr>, <8 x i64> } %1135, 1
  %1138 = getelementptr i8, <8 x ptr> %1136, <8 x i64> %1137
  %1139 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %1138, <8 x i1> %1116, <8 x i8> zeroinitializer)
  %1140 = icmp ne <8 x i8> %1139, zeroinitializer
  %1141 = add <8 x i64> zeroinitializer, %1127
  %1142 = mul <8 x i64> %1141, splat (i64 16)
  %1143 = add <8 x i64> %1142, %1124
  %1144 = select <8 x i1> %1116, <8 x i64> %1143, <8 x i64> zeroinitializer
  %1145 = select <8 x i1> %1116, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %1146 = srem <8 x i64> %1144, %1145
  %1147 = select <8 x i1> %1116, <8 x i64> %1143, <8 x i64> zeroinitializer
  %1148 = select <8 x i1> %1116, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %1149 = sdiv <8 x i64> %1147, %1148
  %1150 = add <8 x i64> zeroinitializer, %1149
  %1151 = mul <8 x i64> %1150, splat (i64 16)
  %1152 = add <8 x i64> %1151, %1146
  %1153 = select <8 x i1> %1116, <8 x i64> %1152, <8 x i64> zeroinitializer
  %1154 = select <8 x i1> %1116, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %1155 = srem <8 x i64> %1153, %1154
  %1156 = select <8 x i1> %1116, <8 x i64> %1152, <8 x i64> zeroinitializer
  %1157 = select <8 x i1> %1116, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %1158 = sdiv <8 x i64> %1156, %1157
  %1159 = add <8 x i64> zeroinitializer, %1158
  %1160 = mul <8 x i64> %1159, splat (i64 16)
  %1161 = add <8 x i64> %1160, %1155
  %tile_snapshot.spill.load984 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load984, 0
  %1163 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load984, 1
  %1164 = mul <8 x i64> %1161, splat (i64 32)
  %1165 = add <8 x i64> %1163, %1164
  %1166 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1162, 0
  %1167 = insertvalue { <8 x ptr>, <8 x i64> } %1166, <8 x i64> %1165, 1
  %1168 = extractvalue { <8 x ptr>, <8 x i64> } %1167, 0
  %1169 = extractvalue { <8 x ptr>, <8 x i64> } %1167, 1
  %1170 = getelementptr i8, <8 x ptr> %1168, <8 x i64> %1169
  %1171 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1170, <8 x i1> %1116, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load985 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill142, align 64
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load985, 0
  %1173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load985, 1
  %1174 = mul <8 x i64> %1159, splat (i64 32)
  %1175 = add <8 x i64> %1173, %1174
  %1176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1172, 0
  %1177 = insertvalue { <8 x ptr>, <8 x i64> } %1176, <8 x i64> %1175, 1
  %1178 = extractvalue { <8 x ptr>, <8 x i64> } %1177, 0
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %1177, 1
  %1180 = getelementptr i8, <8 x ptr> %1178, <8 x i64> %1179
  %1181 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1180, <8 x i1> %1116, <8 x float> zeroinitializer)
  %1182 = fsub <8 x float> %1171, %1181
  %1183 = select <8 x i1> %1116, <8 x float> %1182, <8 x float> zeroinitializer
  %native.exp986 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1183)
  %1184 = select <8 x i1> %1140, <8 x float> %native.exp986, <8 x float> zeroinitializer
  %tile_snapshot.spill.load987 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load987, 0
  %1186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load987, 1
  %.state988 = load <8 x i64>, ptr %.slot153, align 64
  %1187 = mul <8 x i64> %.state988, splat (i64 32)
  %1188 = add <8 x i64> %1186, %1187
  %1189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1185, 0
  %1190 = insertvalue { <8 x ptr>, <8 x i64> } %1189, <8 x i64> %1188, 1
  %1191 = extractvalue { <8 x ptr>, <8 x i64> } %1190, 0
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %1190, 1
  %1193 = getelementptr i8, <8 x ptr> %1191, <8 x i64> %1192
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1184, <8 x ptr> align 1 %1193, <8 x i1> %1116)
  %.state989 = load <8 x i64>, ptr %.slot153, align 64
  %1194 = add <8 x i64> %.state989, splat (i64 1)
  %1195 = load <8 x i64>, ptr %.slot153, align 64
  %1196 = select <8 x i1> %1116, <8 x i64> %1194, <8 x i64> %1195
  store <8 x i64> %1196, ptr %.slot153, align 64
  store <8 x i1> %1116, ptr %current.mask, align 1
  %1197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1116)
  br i1 %1197, label %schedule.60, label %scheduler.loop

schedule.62:                                      ; preds = %varying.coherent.false980, %scheduler.dispatch.route
  %1198 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token992 = load i32, ptr %current.token, align 4
  %convergence.token.present993 = icmp ne i32 %convergence.current.token992, 0
  br i1 %convergence.token.present993, label %convergence.cascade990, label %convergence.cascade.exit991

schedule.63:                                      ; preds = %schedule.64, %convergence.target.62.ready, %scheduler.dispatch.route
  %1199 = load <8 x i1>, ptr %current.mask, align 1
  %1200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1199)
  %1201 = bitcast <8 x i1> %1199 to i8
  %1202 = call i8 @llvm.cttz.i8(i8 %1201, i1 false)
  %1203 = zext i8 %1202 to i32
  %1204 = select i1 %1200, i32 %1203, i32 0
  %.state1023 = load <8 x i64>, ptr %.slot162, align 64
  %1205 = icmp slt <8 x i64> %.state1023, splat (i64 16)
  %1206 = and <8 x i1> %1199, %1205
  %1207 = xor <8 x i1> %1205, splat (i1 true)
  %1208 = and <8 x i1> %1199, %1207
  %1209 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1206)
  %1210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1208)
  %1211 = and i1 %1209, %1210
  br i1 %1211, label %varying.divergent1024, label %varying.coherent1025

schedule.64:                                      ; preds = %varying.coherent.true1030, %scheduler.dispatch.route
  %1212 = load <8 x i1>, ptr %current.mask, align 1
  %1213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1212)
  %1214 = bitcast <8 x i1> %1212 to i8
  %1215 = call i8 @llvm.cttz.i8(i8 %1214, i1 false)
  %1216 = zext i8 %1215 to i32
  %1217 = select i1 %1213, i32 %1216, i32 0
  %.state1032 = load <8 x i64>, ptr %.slot162, align 64
  %1218 = select <8 x i1> %1212, <8 x i64> %.state1032, <8 x i64> zeroinitializer
  %1219 = select <8 x i1> %1212, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1220 = sdiv <8 x i64> %1218, %1219
  %1221 = add <8 x i64> zeroinitializer, %1220
  %tile_snapshot.spill.load1033 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1033, 0
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1033, 1
  %1224 = mul <8 x i64> %1221, splat (i64 32)
  %1225 = add <8 x i64> %1223, %1224
  %1226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1222, 0
  %1227 = insertvalue { <8 x ptr>, <8 x i64> } %1226, <8 x i64> %1225, 1
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %1227, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %1227, 1
  %1230 = getelementptr i8, <8 x ptr> %1228, <8 x i64> %1229
  %1231 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1230, <8 x i1> %1212, <8 x float> zeroinitializer)
  %.state1034 = load <8 x float>, ptr %.slot163, align 32
  %1232 = fadd <8 x float> %.state1034, %1231
  %.state1035 = load <8 x i64>, ptr %.slot162, align 64
  %1233 = add <8 x i64> %.state1035, splat (i64 1)
  %1234 = load <8 x i64>, ptr %.slot162, align 64
  %1235 = select <8 x i1> %1212, <8 x i64> %1233, <8 x i64> %1234
  store <8 x i64> %1235, ptr %.slot162, align 64
  %1236 = load <8 x float>, ptr %.slot163, align 32
  %1237 = select <8 x i1> %1212, <8 x float> %1232, <8 x float> %1236
  store <8 x float> %1237, ptr %.slot163, align 32
  store <8 x i1> %1212, ptr %current.mask, align 1
  %1238 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1212)
  br i1 %1238, label %schedule.63, label %scheduler.loop

schedule.65:                                      ; preds = %varying.coherent.false1031, %scheduler.dispatch.route
  %1239 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1038 = load i32, ptr %current.token, align 4
  %convergence.token.present1039 = icmp ne i32 %convergence.current.token1038, 0
  br i1 %convergence.token.present1039, label %convergence.cascade1036, label %convergence.cascade.exit1037

schedule.66:                                      ; preds = %schedule.67, %convergence.target.65.ready, %scheduler.dispatch.route
  %1240 = load <8 x i1>, ptr %current.mask, align 1
  %1241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1240)
  %1242 = bitcast <8 x i1> %1240 to i8
  %1243 = call i8 @llvm.cttz.i8(i8 %1242, i1 false)
  %1244 = zext i8 %1243 to i32
  %1245 = select i1 %1241, i32 %1244, i32 0
  %.state1053 = load <8 x i64>, ptr %.slot164, align 64
  %1246 = icmp slt <8 x i64> %.state1053, splat (i64 16)
  %1247 = and <8 x i1> %1240, %1246
  %1248 = xor <8 x i1> %1246, splat (i1 true)
  %1249 = and <8 x i1> %1240, %1248
  %1250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1247)
  %1251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1249)
  %1252 = and i1 %1250, %1251
  br i1 %1252, label %varying.divergent1054, label %varying.coherent1055

schedule.67:                                      ; preds = %varying.coherent.true1060, %scheduler.dispatch.route
  %1253 = load <8 x i1>, ptr %current.mask, align 1
  %1254 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1253)
  %1255 = bitcast <8 x i1> %1253 to i8
  %1256 = call i8 @llvm.cttz.i8(i8 %1255, i1 false)
  %1257 = zext i8 %1256 to i32
  %1258 = select i1 %1254, i32 %1257, i32 0
  %.state1062 = load <8 x i64>, ptr %.slot164, align 64
  %1259 = select <8 x i1> %1253, <8 x i64> %.state1062, <8 x i64> zeroinitializer
  %1260 = select <8 x i1> %1253, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1261 = sdiv <8 x i64> %1259, %1260
  %1262 = add <8 x i64> splat (i64 16), %1261
  %tile_snapshot.spill.load1063 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1063, 0
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1063, 1
  %1265 = mul <8 x i64> %1262, splat (i64 32)
  %1266 = add <8 x i64> %1264, %1265
  %1267 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1263, 0
  %1268 = insertvalue { <8 x ptr>, <8 x i64> } %1267, <8 x i64> %1266, 1
  %1269 = extractvalue { <8 x ptr>, <8 x i64> } %1268, 0
  %1270 = extractvalue { <8 x ptr>, <8 x i64> } %1268, 1
  %1271 = getelementptr i8, <8 x ptr> %1269, <8 x i64> %1270
  %1272 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1271, <8 x i1> %1253, <8 x float> zeroinitializer)
  %.state1064 = load <8 x float>, ptr %.slot165, align 32
  %1273 = fadd <8 x float> %.state1064, %1272
  %.state1065 = load <8 x i64>, ptr %.slot164, align 64
  %1274 = add <8 x i64> %.state1065, splat (i64 1)
  %1275 = load <8 x i64>, ptr %.slot164, align 64
  %1276 = select <8 x i1> %1253, <8 x i64> %1274, <8 x i64> %1275
  store <8 x i64> %1276, ptr %.slot164, align 64
  %1277 = load <8 x float>, ptr %.slot165, align 32
  %1278 = select <8 x i1> %1253, <8 x float> %1273, <8 x float> %1277
  store <8 x float> %1278, ptr %.slot165, align 32
  store <8 x i1> %1253, ptr %current.mask, align 1
  %1279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1253)
  br i1 %1279, label %schedule.66, label %scheduler.loop

schedule.68:                                      ; preds = %varying.coherent.false1061, %scheduler.dispatch.route
  %1280 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1068 = load i32, ptr %current.token, align 4
  %convergence.token.present1069 = icmp ne i32 %convergence.current.token1068, 0
  br i1 %convergence.token.present1069, label %convergence.cascade1066, label %convergence.cascade.exit1067

schedule.69:                                      ; preds = %schedule.70, %convergence.target.68.ready, %scheduler.dispatch.route
  %1281 = load <8 x i1>, ptr %current.mask, align 1
  %1282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1281)
  %1283 = bitcast <8 x i1> %1281 to i8
  %1284 = call i8 @llvm.cttz.i8(i8 %1283, i1 false)
  %1285 = zext i8 %1284 to i32
  %1286 = select i1 %1282, i32 %1285, i32 0
  %.state1083 = load <8 x i64>, ptr %.slot166, align 64
  %1287 = icmp slt <8 x i64> %.state1083, splat (i64 16)
  %1288 = and <8 x i1> %1281, %1287
  %1289 = xor <8 x i1> %1287, splat (i1 true)
  %1290 = and <8 x i1> %1281, %1289
  %1291 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1288)
  %1292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1290)
  %1293 = and i1 %1291, %1292
  br i1 %1293, label %varying.divergent1084, label %varying.coherent1085

schedule.70:                                      ; preds = %varying.coherent.true1090, %scheduler.dispatch.route
  %1294 = load <8 x i1>, ptr %current.mask, align 1
  %1295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1294)
  %1296 = bitcast <8 x i1> %1294 to i8
  %1297 = call i8 @llvm.cttz.i8(i8 %1296, i1 false)
  %1298 = zext i8 %1297 to i32
  %1299 = select i1 %1295, i32 %1298, i32 0
  %.state1092 = load <8 x i64>, ptr %.slot166, align 64
  %1300 = select <8 x i1> %1294, <8 x i64> %.state1092, <8 x i64> zeroinitializer
  %1301 = select <8 x i1> %1294, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1302 = sdiv <8 x i64> %1300, %1301
  %1303 = add <8 x i64> splat (i64 32), %1302
  %tile_snapshot.spill.load1093 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1093, 0
  %1305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1093, 1
  %1306 = mul <8 x i64> %1303, splat (i64 32)
  %1307 = add <8 x i64> %1305, %1306
  %1308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1304, 0
  %1309 = insertvalue { <8 x ptr>, <8 x i64> } %1308, <8 x i64> %1307, 1
  %1310 = extractvalue { <8 x ptr>, <8 x i64> } %1309, 0
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %1309, 1
  %1312 = getelementptr i8, <8 x ptr> %1310, <8 x i64> %1311
  %1313 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1312, <8 x i1> %1294, <8 x float> zeroinitializer)
  %.state1094 = load <8 x float>, ptr %.slot167, align 32
  %1314 = fadd <8 x float> %.state1094, %1313
  %.state1095 = load <8 x i64>, ptr %.slot166, align 64
  %1315 = add <8 x i64> %.state1095, splat (i64 1)
  %1316 = load <8 x i64>, ptr %.slot166, align 64
  %1317 = select <8 x i1> %1294, <8 x i64> %1315, <8 x i64> %1316
  store <8 x i64> %1317, ptr %.slot166, align 64
  %1318 = load <8 x float>, ptr %.slot167, align 32
  %1319 = select <8 x i1> %1294, <8 x float> %1314, <8 x float> %1318
  store <8 x float> %1319, ptr %.slot167, align 32
  store <8 x i1> %1294, ptr %current.mask, align 1
  %1320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1294)
  br i1 %1320, label %schedule.69, label %scheduler.loop

schedule.71:                                      ; preds = %varying.coherent.false1091, %scheduler.dispatch.route
  %1321 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1098 = load i32, ptr %current.token, align 4
  %convergence.token.present1099 = icmp ne i32 %convergence.current.token1098, 0
  br i1 %convergence.token.present1099, label %convergence.cascade1096, label %convergence.cascade.exit1097

schedule.72:                                      ; preds = %schedule.73, %convergence.target.71.ready, %scheduler.dispatch.route
  %1322 = load <8 x i1>, ptr %current.mask, align 1
  %1323 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1322)
  %1324 = bitcast <8 x i1> %1322 to i8
  %1325 = call i8 @llvm.cttz.i8(i8 %1324, i1 false)
  %1326 = zext i8 %1325 to i32
  %1327 = select i1 %1323, i32 %1326, i32 0
  %.state1113 = load <8 x i64>, ptr %.slot168, align 64
  %1328 = icmp slt <8 x i64> %.state1113, splat (i64 16)
  %1329 = and <8 x i1> %1322, %1328
  %1330 = xor <8 x i1> %1328, splat (i1 true)
  %1331 = and <8 x i1> %1322, %1330
  %1332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1329)
  %1333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1331)
  %1334 = and i1 %1332, %1333
  br i1 %1334, label %varying.divergent1114, label %varying.coherent1115

schedule.73:                                      ; preds = %varying.coherent.true1120, %scheduler.dispatch.route
  %1335 = load <8 x i1>, ptr %current.mask, align 1
  %1336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1335)
  %1337 = bitcast <8 x i1> %1335 to i8
  %1338 = call i8 @llvm.cttz.i8(i8 %1337, i1 false)
  %1339 = zext i8 %1338 to i32
  %1340 = select i1 %1336, i32 %1339, i32 0
  %.state1122 = load <8 x i64>, ptr %.slot168, align 64
  %1341 = select <8 x i1> %1335, <8 x i64> %.state1122, <8 x i64> zeroinitializer
  %1342 = select <8 x i1> %1335, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1343 = sdiv <8 x i64> %1341, %1342
  %1344 = add <8 x i64> splat (i64 48), %1343
  %tile_snapshot.spill.load1123 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1123, 0
  %1346 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1123, 1
  %1347 = mul <8 x i64> %1344, splat (i64 32)
  %1348 = add <8 x i64> %1346, %1347
  %1349 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1345, 0
  %1350 = insertvalue { <8 x ptr>, <8 x i64> } %1349, <8 x i64> %1348, 1
  %1351 = extractvalue { <8 x ptr>, <8 x i64> } %1350, 0
  %1352 = extractvalue { <8 x ptr>, <8 x i64> } %1350, 1
  %1353 = getelementptr i8, <8 x ptr> %1351, <8 x i64> %1352
  %1354 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1353, <8 x i1> %1335, <8 x float> zeroinitializer)
  %.state1124 = load <8 x float>, ptr %.slot169, align 32
  %1355 = fadd <8 x float> %.state1124, %1354
  %.state1125 = load <8 x i64>, ptr %.slot168, align 64
  %1356 = add <8 x i64> %.state1125, splat (i64 1)
  %1357 = load <8 x i64>, ptr %.slot168, align 64
  %1358 = select <8 x i1> %1335, <8 x i64> %1356, <8 x i64> %1357
  store <8 x i64> %1358, ptr %.slot168, align 64
  %1359 = load <8 x float>, ptr %.slot169, align 32
  %1360 = select <8 x i1> %1335, <8 x float> %1355, <8 x float> %1359
  store <8 x float> %1360, ptr %.slot169, align 32
  store <8 x i1> %1335, ptr %current.mask, align 1
  %1361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1335)
  br i1 %1361, label %schedule.72, label %scheduler.loop

schedule.74:                                      ; preds = %varying.coherent.false1121, %scheduler.dispatch.route
  %1362 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1128 = load i32, ptr %current.token, align 4
  %convergence.token.present1129 = icmp ne i32 %convergence.current.token1128, 0
  br i1 %convergence.token.present1129, label %convergence.cascade1126, label %convergence.cascade.exit1127

schedule.75:                                      ; preds = %schedule.76, %convergence.target.74.ready, %scheduler.dispatch.route
  %1363 = load <8 x i1>, ptr %current.mask, align 1
  %1364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1363)
  %1365 = bitcast <8 x i1> %1363 to i8
  %1366 = call i8 @llvm.cttz.i8(i8 %1365, i1 false)
  %1367 = zext i8 %1366 to i32
  %1368 = select i1 %1364, i32 %1367, i32 0
  %.state1143 = load <8 x i64>, ptr %.slot170, align 64
  %1369 = icmp slt <8 x i64> %.state1143, splat (i64 16)
  %1370 = and <8 x i1> %1363, %1369
  %1371 = xor <8 x i1> %1369, splat (i1 true)
  %1372 = and <8 x i1> %1363, %1371
  %1373 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1370)
  %1374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1372)
  %1375 = and i1 %1373, %1374
  br i1 %1375, label %varying.divergent1144, label %varying.coherent1145

schedule.76:                                      ; preds = %varying.coherent.true1150, %scheduler.dispatch.route
  %1376 = load <8 x i1>, ptr %current.mask, align 1
  %1377 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1376)
  %1378 = bitcast <8 x i1> %1376 to i8
  %1379 = call i8 @llvm.cttz.i8(i8 %1378, i1 false)
  %1380 = zext i8 %1379 to i32
  %1381 = select i1 %1377, i32 %1380, i32 0
  %.state1152 = load <8 x i64>, ptr %.slot170, align 64
  %1382 = select <8 x i1> %1376, <8 x i64> %.state1152, <8 x i64> zeroinitializer
  %1383 = select <8 x i1> %1376, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1384 = sdiv <8 x i64> %1382, %1383
  %1385 = add <8 x i64> splat (i64 64), %1384
  %tile_snapshot.spill.load1153 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1153, 0
  %1387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1153, 1
  %1388 = mul <8 x i64> %1385, splat (i64 32)
  %1389 = add <8 x i64> %1387, %1388
  %1390 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1386, 0
  %1391 = insertvalue { <8 x ptr>, <8 x i64> } %1390, <8 x i64> %1389, 1
  %1392 = extractvalue { <8 x ptr>, <8 x i64> } %1391, 0
  %1393 = extractvalue { <8 x ptr>, <8 x i64> } %1391, 1
  %1394 = getelementptr i8, <8 x ptr> %1392, <8 x i64> %1393
  %1395 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1394, <8 x i1> %1376, <8 x float> zeroinitializer)
  %.state1154 = load <8 x float>, ptr %.slot171, align 32
  %1396 = fadd <8 x float> %.state1154, %1395
  %.state1155 = load <8 x i64>, ptr %.slot170, align 64
  %1397 = add <8 x i64> %.state1155, splat (i64 1)
  %1398 = load <8 x i64>, ptr %.slot170, align 64
  %1399 = select <8 x i1> %1376, <8 x i64> %1397, <8 x i64> %1398
  store <8 x i64> %1399, ptr %.slot170, align 64
  %1400 = load <8 x float>, ptr %.slot171, align 32
  %1401 = select <8 x i1> %1376, <8 x float> %1396, <8 x float> %1400
  store <8 x float> %1401, ptr %.slot171, align 32
  store <8 x i1> %1376, ptr %current.mask, align 1
  %1402 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1376)
  br i1 %1402, label %schedule.75, label %scheduler.loop

schedule.77:                                      ; preds = %varying.coherent.false1151, %scheduler.dispatch.route
  %1403 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1158 = load i32, ptr %current.token, align 4
  %convergence.token.present1159 = icmp ne i32 %convergence.current.token1158, 0
  br i1 %convergence.token.present1159, label %convergence.cascade1156, label %convergence.cascade.exit1157

schedule.78:                                      ; preds = %schedule.79, %convergence.target.77.ready, %scheduler.dispatch.route
  %1404 = load <8 x i1>, ptr %current.mask, align 1
  %1405 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1404)
  %1406 = bitcast <8 x i1> %1404 to i8
  %1407 = call i8 @llvm.cttz.i8(i8 %1406, i1 false)
  %1408 = zext i8 %1407 to i32
  %1409 = select i1 %1405, i32 %1408, i32 0
  %.state1173 = load <8 x i64>, ptr %.slot172, align 64
  %1410 = icmp slt <8 x i64> %.state1173, splat (i64 16)
  %1411 = and <8 x i1> %1404, %1410
  %1412 = xor <8 x i1> %1410, splat (i1 true)
  %1413 = and <8 x i1> %1404, %1412
  %1414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1411)
  %1415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1413)
  %1416 = and i1 %1414, %1415
  br i1 %1416, label %varying.divergent1174, label %varying.coherent1175

schedule.79:                                      ; preds = %varying.coherent.true1180, %scheduler.dispatch.route
  %1417 = load <8 x i1>, ptr %current.mask, align 1
  %1418 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1417)
  %1419 = bitcast <8 x i1> %1417 to i8
  %1420 = call i8 @llvm.cttz.i8(i8 %1419, i1 false)
  %1421 = zext i8 %1420 to i32
  %1422 = select i1 %1418, i32 %1421, i32 0
  %.state1182 = load <8 x i64>, ptr %.slot172, align 64
  %1423 = select <8 x i1> %1417, <8 x i64> %.state1182, <8 x i64> zeroinitializer
  %1424 = select <8 x i1> %1417, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1425 = sdiv <8 x i64> %1423, %1424
  %1426 = add <8 x i64> splat (i64 80), %1425
  %tile_snapshot.spill.load1183 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1183, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1183, 1
  %1429 = mul <8 x i64> %1426, splat (i64 32)
  %1430 = add <8 x i64> %1428, %1429
  %1431 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1427, 0
  %1432 = insertvalue { <8 x ptr>, <8 x i64> } %1431, <8 x i64> %1430, 1
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %1432, 0
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %1432, 1
  %1435 = getelementptr i8, <8 x ptr> %1433, <8 x i64> %1434
  %1436 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1435, <8 x i1> %1417, <8 x float> zeroinitializer)
  %.state1184 = load <8 x float>, ptr %.slot173, align 32
  %1437 = fadd <8 x float> %.state1184, %1436
  %.state1185 = load <8 x i64>, ptr %.slot172, align 64
  %1438 = add <8 x i64> %.state1185, splat (i64 1)
  %1439 = load <8 x i64>, ptr %.slot172, align 64
  %1440 = select <8 x i1> %1417, <8 x i64> %1438, <8 x i64> %1439
  store <8 x i64> %1440, ptr %.slot172, align 64
  %1441 = load <8 x float>, ptr %.slot173, align 32
  %1442 = select <8 x i1> %1417, <8 x float> %1437, <8 x float> %1441
  store <8 x float> %1442, ptr %.slot173, align 32
  store <8 x i1> %1417, ptr %current.mask, align 1
  %1443 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1417)
  br i1 %1443, label %schedule.78, label %scheduler.loop

schedule.80:                                      ; preds = %varying.coherent.false1181, %scheduler.dispatch.route
  %1444 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1188 = load i32, ptr %current.token, align 4
  %convergence.token.present1189 = icmp ne i32 %convergence.current.token1188, 0
  br i1 %convergence.token.present1189, label %convergence.cascade1186, label %convergence.cascade.exit1187

schedule.81:                                      ; preds = %schedule.82, %convergence.target.80.ready, %scheduler.dispatch.route
  %1445 = load <8 x i1>, ptr %current.mask, align 1
  %1446 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1445)
  %1447 = bitcast <8 x i1> %1445 to i8
  %1448 = call i8 @llvm.cttz.i8(i8 %1447, i1 false)
  %1449 = zext i8 %1448 to i32
  %1450 = select i1 %1446, i32 %1449, i32 0
  %.state1203 = load <8 x i64>, ptr %.slot174, align 64
  %1451 = icmp slt <8 x i64> %.state1203, splat (i64 16)
  %1452 = and <8 x i1> %1445, %1451
  %1453 = xor <8 x i1> %1451, splat (i1 true)
  %1454 = and <8 x i1> %1445, %1453
  %1455 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1452)
  %1456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1454)
  %1457 = and i1 %1455, %1456
  br i1 %1457, label %varying.divergent1204, label %varying.coherent1205

schedule.82:                                      ; preds = %varying.coherent.true1210, %scheduler.dispatch.route
  %1458 = load <8 x i1>, ptr %current.mask, align 1
  %1459 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1458)
  %1460 = bitcast <8 x i1> %1458 to i8
  %1461 = call i8 @llvm.cttz.i8(i8 %1460, i1 false)
  %1462 = zext i8 %1461 to i32
  %1463 = select i1 %1459, i32 %1462, i32 0
  %.state1212 = load <8 x i64>, ptr %.slot174, align 64
  %1464 = select <8 x i1> %1458, <8 x i64> %.state1212, <8 x i64> zeroinitializer
  %1465 = select <8 x i1> %1458, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1466 = sdiv <8 x i64> %1464, %1465
  %1467 = add <8 x i64> splat (i64 96), %1466
  %tile_snapshot.spill.load1213 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1213, 0
  %1469 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1213, 1
  %1470 = mul <8 x i64> %1467, splat (i64 32)
  %1471 = add <8 x i64> %1469, %1470
  %1472 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1468, 0
  %1473 = insertvalue { <8 x ptr>, <8 x i64> } %1472, <8 x i64> %1471, 1
  %1474 = extractvalue { <8 x ptr>, <8 x i64> } %1473, 0
  %1475 = extractvalue { <8 x ptr>, <8 x i64> } %1473, 1
  %1476 = getelementptr i8, <8 x ptr> %1474, <8 x i64> %1475
  %1477 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1476, <8 x i1> %1458, <8 x float> zeroinitializer)
  %.state1214 = load <8 x float>, ptr %.slot175, align 32
  %1478 = fadd <8 x float> %.state1214, %1477
  %.state1215 = load <8 x i64>, ptr %.slot174, align 64
  %1479 = add <8 x i64> %.state1215, splat (i64 1)
  %1480 = load <8 x i64>, ptr %.slot174, align 64
  %1481 = select <8 x i1> %1458, <8 x i64> %1479, <8 x i64> %1480
  store <8 x i64> %1481, ptr %.slot174, align 64
  %1482 = load <8 x float>, ptr %.slot175, align 32
  %1483 = select <8 x i1> %1458, <8 x float> %1478, <8 x float> %1482
  store <8 x float> %1483, ptr %.slot175, align 32
  store <8 x i1> %1458, ptr %current.mask, align 1
  %1484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1458)
  br i1 %1484, label %schedule.81, label %scheduler.loop

schedule.83:                                      ; preds = %varying.coherent.false1211, %scheduler.dispatch.route
  %1485 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1218 = load i32, ptr %current.token, align 4
  %convergence.token.present1219 = icmp ne i32 %convergence.current.token1218, 0
  br i1 %convergence.token.present1219, label %convergence.cascade1216, label %convergence.cascade.exit1217

schedule.84:                                      ; preds = %schedule.85, %convergence.target.83.ready, %scheduler.dispatch.route
  %1486 = load <8 x i1>, ptr %current.mask, align 1
  %1487 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1486)
  %1488 = bitcast <8 x i1> %1486 to i8
  %1489 = call i8 @llvm.cttz.i8(i8 %1488, i1 false)
  %1490 = zext i8 %1489 to i32
  %1491 = select i1 %1487, i32 %1490, i32 0
  %.state1233 = load <8 x i64>, ptr %.slot176, align 64
  %1492 = icmp slt <8 x i64> %.state1233, splat (i64 16)
  %1493 = and <8 x i1> %1486, %1492
  %1494 = xor <8 x i1> %1492, splat (i1 true)
  %1495 = and <8 x i1> %1486, %1494
  %1496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1493)
  %1497 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1495)
  %1498 = and i1 %1496, %1497
  br i1 %1498, label %varying.divergent1234, label %varying.coherent1235

schedule.85:                                      ; preds = %varying.coherent.true1240, %scheduler.dispatch.route
  %1499 = load <8 x i1>, ptr %current.mask, align 1
  %1500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1499)
  %1501 = bitcast <8 x i1> %1499 to i8
  %1502 = call i8 @llvm.cttz.i8(i8 %1501, i1 false)
  %1503 = zext i8 %1502 to i32
  %1504 = select i1 %1500, i32 %1503, i32 0
  %.state1242 = load <8 x i64>, ptr %.slot176, align 64
  %1505 = select <8 x i1> %1499, <8 x i64> %.state1242, <8 x i64> zeroinitializer
  %1506 = select <8 x i1> %1499, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1507 = sdiv <8 x i64> %1505, %1506
  %1508 = add <8 x i64> splat (i64 112), %1507
  %tile_snapshot.spill.load1243 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1509 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1243, 0
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1243, 1
  %1511 = mul <8 x i64> %1508, splat (i64 32)
  %1512 = add <8 x i64> %1510, %1511
  %1513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1509, 0
  %1514 = insertvalue { <8 x ptr>, <8 x i64> } %1513, <8 x i64> %1512, 1
  %1515 = extractvalue { <8 x ptr>, <8 x i64> } %1514, 0
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %1514, 1
  %1517 = getelementptr i8, <8 x ptr> %1515, <8 x i64> %1516
  %1518 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1517, <8 x i1> %1499, <8 x float> zeroinitializer)
  %.state1244 = load <8 x float>, ptr %.slot177, align 32
  %1519 = fadd <8 x float> %.state1244, %1518
  %.state1245 = load <8 x i64>, ptr %.slot176, align 64
  %1520 = add <8 x i64> %.state1245, splat (i64 1)
  %1521 = load <8 x i64>, ptr %.slot176, align 64
  %1522 = select <8 x i1> %1499, <8 x i64> %1520, <8 x i64> %1521
  store <8 x i64> %1522, ptr %.slot176, align 64
  %1523 = load <8 x float>, ptr %.slot177, align 32
  %1524 = select <8 x i1> %1499, <8 x float> %1519, <8 x float> %1523
  store <8 x float> %1524, ptr %.slot177, align 32
  store <8 x i1> %1499, ptr %current.mask, align 1
  %1525 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1499)
  br i1 %1525, label %schedule.84, label %scheduler.loop

schedule.86:                                      ; preds = %varying.coherent.false1241, %scheduler.dispatch.route
  %1526 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1248 = load i32, ptr %current.token, align 4
  %convergence.token.present1249 = icmp ne i32 %convergence.current.token1248, 0
  br i1 %convergence.token.present1249, label %convergence.cascade1246, label %convergence.cascade.exit1247

schedule.87:                                      ; preds = %convergence.target.94.ready, %convergence.target.86.ready, %scheduler.dispatch.route
  %1527 = load <8 x i1>, ptr %current.mask, align 1
  %1528 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1527)
  %1529 = bitcast <8 x i1> %1527 to i8
  %1530 = call i8 @llvm.cttz.i8(i8 %1529, i1 false)
  %1531 = zext i8 %1530 to i32
  %1532 = select i1 %1528, i32 %1531, i32 0
  %.state1279 = load <8 x i64>, ptr %.slot187, align 64
  %1533 = icmp slt <8 x i64> %.state1279, splat (i64 8)
  %1534 = and <8 x i1> %1527, %1533
  %1535 = xor <8 x i1> %1533, splat (i1 true)
  %1536 = and <8 x i1> %1527, %1535
  %1537 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1534)
  %1538 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1536)
  %1539 = and i1 %1537, %1538
  br i1 %1539, label %varying.divergent1280, label %varying.coherent1281

schedule.88:                                      ; preds = %varying.coherent.true1286, %scheduler.dispatch.route
  %1540 = load <8 x i1>, ptr %current.mask, align 1
  %1541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1540)
  %1542 = bitcast <8 x i1> %1540 to i8
  %1543 = call i8 @llvm.cttz.i8(i8 %1542, i1 false)
  %1544 = zext i8 %1543 to i32
  %1545 = select i1 %1541, i32 %1544, i32 0
  %1546 = load <8 x i64>, ptr %.slot188, align 64
  %1547 = select <8 x i1> %1540, <8 x i64> zeroinitializer, <8 x i64> %1546
  store <8 x i64> %1547, ptr %.slot188, align 64
  store <8 x i1> %1540, ptr %current.mask, align 1
  %1548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1540)
  br i1 %1548, label %schedule.89, label %scheduler.loop

schedule.89:                                      ; preds = %convergence.target.93.ready, %schedule.88, %scheduler.dispatch.route
  %1549 = load <8 x i1>, ptr %current.mask, align 1
  %1550 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1549)
  %1551 = bitcast <8 x i1> %1549 to i8
  %1552 = call i8 @llvm.cttz.i8(i8 %1551, i1 false)
  %1553 = zext i8 %1552 to i32
  %1554 = select i1 %1550, i32 %1553, i32 0
  %.state1288 = load <8 x i64>, ptr %.slot188, align 64
  %1555 = icmp slt <8 x i64> %.state1288, splat (i64 10)
  %1556 = and <8 x i1> %1549, %1555
  %1557 = xor <8 x i1> %1555, splat (i1 true)
  %1558 = and <8 x i1> %1549, %1557
  %1559 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1556)
  %1560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1558)
  %1561 = and i1 %1559, %1560
  br i1 %1561, label %varying.divergent1289, label %varying.coherent1290

schedule.90:                                      ; preds = %varying.coherent.true1295, %scheduler.dispatch.route
  %1562 = load <8 x i1>, ptr %current.mask, align 1
  %1563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1562)
  %1564 = bitcast <8 x i1> %1562 to i8
  %1565 = call i8 @llvm.cttz.i8(i8 %1564, i1 false)
  %1566 = zext i8 %1565 to i32
  %1567 = select i1 %1563, i32 %1566, i32 0
  %.state1297 = load <8 x i64>, ptr %.slot187, align 64
  %1568 = mul <8 x i64> %.state1297, splat (i64 40)
  %.state1298 = load <8 x i64>, ptr %.slot188, align 64
  %1569 = mul <8 x i64> %.state1298, splat (i64 4)
  %1570 = add <8 x i64> %1568, %1569
  %1571 = add <8 x i64> %1570, zeroinitializer
  %1572 = load <8 x i64>, ptr %.spill189, align 64
  %1573 = select <8 x i1> %1562, <8 x i64> %1571, <8 x i64> %1572
  store <8 x i64> %1573, ptr %.spill189, align 64
  %1574 = select <8 x i1> %1562, <8 x i64> %1571, <8 x i64> zeroinitializer
  %1575 = select <8 x i1> %1562, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1576 = srem <8 x i64> %1574, %1575
  %1577 = load <8 x i64>, ptr %.spill190, align 64
  %1578 = select <8 x i1> %1562, <8 x i64> %1576, <8 x i64> %1577
  store <8 x i64> %1578, ptr %.spill190, align 64
  %1579 = select <8 x i1> %1562, <8 x i64> %1571, <8 x i64> zeroinitializer
  %1580 = select <8 x i1> %1562, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1581 = sdiv <8 x i64> %1579, %1580
  %1582 = add <8 x i64> zeroinitializer, %1581
  %1583 = load <8 x i64>, ptr %.spill191, align 64
  %1584 = select <8 x i1> %1562, <8 x i64> %1582, <8 x i64> %1583
  store <8 x i64> %1584, ptr %.spill191, align 64
  %1585 = mul <8 x i64> %1582, splat (i64 40)
  %1586 = add <8 x i64> %1585, %1576
  %tile_snapshot.spill.load1299 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %1587 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1299, 0
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1299, 1
  %1589 = mul <8 x i64> %1586, splat (i64 32)
  %1590 = add <8 x i64> %1588, %1589
  %1591 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1587, 0
  %1592 = insertvalue { <8 x ptr>, <8 x i64> } %1591, <8 x i64> %1590, 1
  %1593 = extractvalue { <8 x ptr>, <8 x i64> } %1592, 0
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %1592, 1
  %1595 = getelementptr i8, <8 x ptr> %1593, <8 x i64> %1594
  %1596 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1595, <8 x i1> %1562, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1300 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill151, align 64
  %1597 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1300, 0
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1300, 1
  %1599 = mul <8 x i64> %1582, splat (i64 32)
  %1600 = add <8 x i64> %1598, %1599
  %1601 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1597, 0
  %1602 = insertvalue { <8 x ptr>, <8 x i64> } %1601, <8 x i64> %1600, 1
  %1603 = extractvalue { <8 x ptr>, <8 x i64> } %1602, 0
  %1604 = extractvalue { <8 x ptr>, <8 x i64> } %1602, 1
  %1605 = getelementptr i8, <8 x ptr> %1603, <8 x i64> %1604
  %1606 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1605, <8 x i1> %1562, <8 x float> zeroinitializer)
  %1607 = fmul <8 x float> %1596, %1606
  %1608 = add <8 x i64> %1570, splat (i64 1)
  %1609 = load <8 x i64>, ptr %.spill192, align 64
  %1610 = select <8 x i1> %1562, <8 x i64> %1608, <8 x i64> %1609
  store <8 x i64> %1610, ptr %.spill192, align 64
  %1611 = select <8 x i1> %1562, <8 x i64> %1608, <8 x i64> zeroinitializer
  %1612 = select <8 x i1> %1562, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1613 = srem <8 x i64> %1611, %1612
  %1614 = load <8 x i64>, ptr %.spill193, align 64
  %1615 = select <8 x i1> %1562, <8 x i64> %1613, <8 x i64> %1614
  store <8 x i64> %1615, ptr %.spill193, align 64
  %1616 = select <8 x i1> %1562, <8 x i64> %1608, <8 x i64> zeroinitializer
  %1617 = select <8 x i1> %1562, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1618 = sdiv <8 x i64> %1616, %1617
  %1619 = add <8 x i64> zeroinitializer, %1618
  %1620 = mul <8 x i64> %1619, splat (i64 40)
  %1621 = add <8 x i64> %1620, %1613
  %tile_snapshot.spill.load1301 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %1622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1301, 0
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1301, 1
  %1624 = mul <8 x i64> %1621, splat (i64 32)
  %1625 = add <8 x i64> %1623, %1624
  %1626 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1622, 0
  %1627 = insertvalue { <8 x ptr>, <8 x i64> } %1626, <8 x i64> %1625, 1
  %1628 = extractvalue { <8 x ptr>, <8 x i64> } %1627, 0
  %1629 = extractvalue { <8 x ptr>, <8 x i64> } %1627, 1
  %1630 = getelementptr i8, <8 x ptr> %1628, <8 x i64> %1629
  %1631 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1630, <8 x i1> %1562, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1302 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill151, align 64
  %1632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1302, 0
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1302, 1
  %1634 = mul <8 x i64> %1619, splat (i64 32)
  %1635 = add <8 x i64> %1633, %1634
  %1636 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1632, 0
  %1637 = insertvalue { <8 x ptr>, <8 x i64> } %1636, <8 x i64> %1635, 1
  %1638 = extractvalue { <8 x ptr>, <8 x i64> } %1637, 0
  %1639 = extractvalue { <8 x ptr>, <8 x i64> } %1637, 1
  %1640 = getelementptr i8, <8 x ptr> %1638, <8 x i64> %1639
  %1641 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1640, <8 x i1> %1562, <8 x float> zeroinitializer)
  %1642 = fmul <8 x float> %1631, %1641
  %1643 = add <8 x i64> %1570, splat (i64 2)
  %1644 = load <8 x i64>, ptr %.spill194, align 64
  %1645 = select <8 x i1> %1562, <8 x i64> %1643, <8 x i64> %1644
  store <8 x i64> %1645, ptr %.spill194, align 64
  %1646 = select <8 x i1> %1562, <8 x i64> %1643, <8 x i64> zeroinitializer
  %1647 = select <8 x i1> %1562, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1648 = srem <8 x i64> %1646, %1647
  %1649 = load <8 x i64>, ptr %.spill195, align 64
  %1650 = select <8 x i1> %1562, <8 x i64> %1648, <8 x i64> %1649
  store <8 x i64> %1650, ptr %.spill195, align 64
  %1651 = select <8 x i1> %1562, <8 x i64> %1643, <8 x i64> zeroinitializer
  %1652 = select <8 x i1> %1562, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1653 = sdiv <8 x i64> %1651, %1652
  %1654 = add <8 x i64> zeroinitializer, %1653
  %1655 = mul <8 x i64> %1654, splat (i64 40)
  %1656 = add <8 x i64> %1655, %1648
  %tile_snapshot.spill.load1303 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %1657 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1303, 0
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1303, 1
  %1659 = mul <8 x i64> %1656, splat (i64 32)
  %1660 = add <8 x i64> %1658, %1659
  %1661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1657, 0
  %1662 = insertvalue { <8 x ptr>, <8 x i64> } %1661, <8 x i64> %1660, 1
  %1663 = extractvalue { <8 x ptr>, <8 x i64> } %1662, 0
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %1662, 1
  %1665 = getelementptr i8, <8 x ptr> %1663, <8 x i64> %1664
  %1666 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1665, <8 x i1> %1562, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1304 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill151, align 64
  %1667 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1304, 0
  %1668 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1304, 1
  %1669 = mul <8 x i64> %1654, splat (i64 32)
  %1670 = add <8 x i64> %1668, %1669
  %1671 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1667, 0
  %1672 = insertvalue { <8 x ptr>, <8 x i64> } %1671, <8 x i64> %1670, 1
  %1673 = extractvalue { <8 x ptr>, <8 x i64> } %1672, 0
  %1674 = extractvalue { <8 x ptr>, <8 x i64> } %1672, 1
  %1675 = getelementptr i8, <8 x ptr> %1673, <8 x i64> %1674
  %1676 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1675, <8 x i1> %1562, <8 x float> zeroinitializer)
  %1677 = fmul <8 x float> %1666, %1676
  %1678 = add <8 x i64> %1570, splat (i64 3)
  %1679 = load <8 x i64>, ptr %.spill196, align 64
  %1680 = select <8 x i1> %1562, <8 x i64> %1678, <8 x i64> %1679
  store <8 x i64> %1680, ptr %.spill196, align 64
  %1681 = select <8 x i1> %1562, <8 x i64> %1678, <8 x i64> zeroinitializer
  %1682 = select <8 x i1> %1562, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1683 = srem <8 x i64> %1681, %1682
  %1684 = load <8 x i64>, ptr %.spill197, align 64
  %1685 = select <8 x i1> %1562, <8 x i64> %1683, <8 x i64> %1684
  store <8 x i64> %1685, ptr %.spill197, align 64
  %1686 = select <8 x i1> %1562, <8 x i64> %1678, <8 x i64> zeroinitializer
  %1687 = select <8 x i1> %1562, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1688 = sdiv <8 x i64> %1686, %1687
  %1689 = add <8 x i64> zeroinitializer, %1688
  %1690 = mul <8 x i64> %1689, splat (i64 40)
  %1691 = add <8 x i64> %1690, %1683
  %tile_snapshot.spill.load1305 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1305, 0
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1305, 1
  %1694 = mul <8 x i64> %1691, splat (i64 32)
  %1695 = add <8 x i64> %1693, %1694
  %1696 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1692, 0
  %1697 = insertvalue { <8 x ptr>, <8 x i64> } %1696, <8 x i64> %1695, 1
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %1697, 0
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %1697, 1
  %1700 = getelementptr i8, <8 x ptr> %1698, <8 x i64> %1699
  %1701 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1700, <8 x i1> %1562, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1306 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill151, align 64
  %1702 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1306, 0
  %1703 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1306, 1
  %1704 = mul <8 x i64> %1689, splat (i64 32)
  %1705 = add <8 x i64> %1703, %1704
  %1706 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1702, 0
  %1707 = insertvalue { <8 x ptr>, <8 x i64> } %1706, <8 x i64> %1705, 1
  %1708 = extractvalue { <8 x ptr>, <8 x i64> } %1707, 0
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %1707, 1
  %1710 = getelementptr i8, <8 x ptr> %1708, <8 x i64> %1709
  %1711 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1710, <8 x i1> %1562, <8 x float> zeroinitializer)
  %1712 = fmul <8 x float> %1701, %1711
  %1713 = load <8 x i64>, ptr %.slot198, align 64
  %1714 = select <8 x i1> %1562, <8 x i64> zeroinitializer, <8 x i64> %1713
  store <8 x i64> %1714, ptr %.slot198, align 64
  %1715 = load <8 x float>, ptr %.slot199, align 32
  %1716 = select <8 x i1> %1562, <8 x float> %1607, <8 x float> %1715
  store <8 x float> %1716, ptr %.slot199, align 32
  %1717 = load <8 x float>, ptr %.slot200, align 32
  %1718 = select <8 x i1> %1562, <8 x float> %1642, <8 x float> %1717
  store <8 x float> %1718, ptr %.slot200, align 32
  %1719 = load <8 x float>, ptr %.slot201, align 32
  %1720 = select <8 x i1> %1562, <8 x float> %1677, <8 x float> %1719
  store <8 x float> %1720, ptr %.slot201, align 32
  %1721 = load <8 x float>, ptr %.slot202, align 32
  %1722 = select <8 x i1> %1562, <8 x float> %1712, <8 x float> %1721
  store <8 x float> %1722, ptr %.slot202, align 32
  store <8 x i1> %1562, ptr %current.mask, align 1
  %1723 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1562)
  br i1 %1723, label %schedule.91, label %scheduler.loop

schedule.91:                                      ; preds = %schedule.92, %schedule.90, %scheduler.dispatch.route
  %1724 = load <8 x i1>, ptr %current.mask, align 1
  %1725 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1724)
  %1726 = bitcast <8 x i1> %1724 to i8
  %1727 = call i8 @llvm.cttz.i8(i8 %1726, i1 false)
  %1728 = zext i8 %1727 to i32
  %1729 = select i1 %1725, i32 %1728, i32 0
  %.state1307 = load <8 x i64>, ptr %.slot198, align 64
  %1730 = icmp slt <8 x i64> %.state1307, splat (i64 16)
  %1731 = and <8 x i1> %1724, %1730
  %1732 = xor <8 x i1> %1730, splat (i1 true)
  %1733 = and <8 x i1> %1724, %1732
  %1734 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1731)
  %1735 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1733)
  %1736 = and i1 %1734, %1735
  br i1 %1736, label %varying.divergent1308, label %varying.coherent1309

schedule.92:                                      ; preds = %varying.coherent.true1314, %scheduler.dispatch.route
  %1737 = load <8 x i1>, ptr %current.mask, align 1
  %1738 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1737)
  %1739 = bitcast <8 x i1> %1737 to i8
  %1740 = call i8 @llvm.cttz.i8(i8 %1739, i1 false)
  %1741 = zext i8 %1740 to i32
  %1742 = select i1 %1738, i32 %1741, i32 0
  %.spill.load1316 = load <8 x i64>, ptr %.spill191, align 64
  %1743 = mul <8 x i64> %.spill.load1316, splat (i64 16)
  %.state1317 = load <8 x i64>, ptr %.slot198, align 64
  %1744 = add <8 x i64> %1743, %.state1317
  %tile_snapshot.spill.load1318 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1745 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1318, 0
  %1746 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1318, 1
  %1747 = mul <8 x i64> %1744, splat (i64 32)
  %1748 = add <8 x i64> %1746, %1747
  %1749 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1745, 0
  %1750 = insertvalue { <8 x ptr>, <8 x i64> } %1749, <8 x i64> %1748, 1
  %1751 = extractvalue { <8 x ptr>, <8 x i64> } %1750, 0
  %1752 = extractvalue { <8 x ptr>, <8 x i64> } %1750, 1
  %1753 = getelementptr i8, <8 x ptr> %1751, <8 x i64> %1752
  %1754 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1753, <8 x i1> %1737, <8 x float> zeroinitializer)
  %.state1319 = load <8 x i64>, ptr %.slot198, align 64
  %1755 = add <8 x i64> zeroinitializer, %.state1319
  %1756 = mul <8 x i64> %1755, splat (i64 40)
  %.spill.load1320 = load <8 x i64>, ptr %.spill190, align 64
  %1757 = add <8 x i64> %1756, %.spill.load1320
  %tile_snapshot.spill.load1321 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %1758 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1321, 0
  %1759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1321, 1
  %1760 = mul <8 x i64> %1757, splat (i64 32)
  %1761 = add <8 x i64> %1759, %1760
  %1762 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1758, 0
  %1763 = insertvalue { <8 x ptr>, <8 x i64> } %1762, <8 x i64> %1761, 1
  %1764 = extractvalue { <8 x ptr>, <8 x i64> } %1763, 0
  %1765 = extractvalue { <8 x ptr>, <8 x i64> } %1763, 1
  %1766 = getelementptr i8, <8 x ptr> %1764, <8 x i64> %1765
  %1767 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1766, <8 x i1> %1737, <8 x float> zeroinitializer)
  %1768 = fmul <8 x float> %1754, %1767
  %.state1322 = load <8 x float>, ptr %.slot199, align 32
  %1769 = fadd <8 x float> %.state1322, %1768
  %.spill.load1323 = load <8 x i64>, ptr %.spill193, align 64
  %1770 = add <8 x i64> %1756, %.spill.load1323
  %tile_snapshot.spill.load1324 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %1771 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1324, 0
  %1772 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1324, 1
  %1773 = mul <8 x i64> %1770, splat (i64 32)
  %1774 = add <8 x i64> %1772, %1773
  %1775 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1771, 0
  %1776 = insertvalue { <8 x ptr>, <8 x i64> } %1775, <8 x i64> %1774, 1
  %1777 = extractvalue { <8 x ptr>, <8 x i64> } %1776, 0
  %1778 = extractvalue { <8 x ptr>, <8 x i64> } %1776, 1
  %1779 = getelementptr i8, <8 x ptr> %1777, <8 x i64> %1778
  %1780 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1779, <8 x i1> %1737, <8 x float> zeroinitializer)
  %1781 = fmul <8 x float> %1754, %1780
  %.state1325 = load <8 x float>, ptr %.slot200, align 32
  %1782 = fadd <8 x float> %.state1325, %1781
  %.spill.load1326 = load <8 x i64>, ptr %.spill195, align 64
  %1783 = add <8 x i64> %1756, %.spill.load1326
  %tile_snapshot.spill.load1327 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %1784 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1327, 0
  %1785 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1327, 1
  %1786 = mul <8 x i64> %1783, splat (i64 32)
  %1787 = add <8 x i64> %1785, %1786
  %1788 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1784, 0
  %1789 = insertvalue { <8 x ptr>, <8 x i64> } %1788, <8 x i64> %1787, 1
  %1790 = extractvalue { <8 x ptr>, <8 x i64> } %1789, 0
  %1791 = extractvalue { <8 x ptr>, <8 x i64> } %1789, 1
  %1792 = getelementptr i8, <8 x ptr> %1790, <8 x i64> %1791
  %1793 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1792, <8 x i1> %1737, <8 x float> zeroinitializer)
  %1794 = fmul <8 x float> %1754, %1793
  %.state1328 = load <8 x float>, ptr %.slot201, align 32
  %1795 = fadd <8 x float> %.state1328, %1794
  %.spill.load1329 = load <8 x i64>, ptr %.spill197, align 64
  %1796 = add <8 x i64> %1756, %.spill.load1329
  %tile_snapshot.spill.load1330 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1330, 0
  %1798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1330, 1
  %1799 = mul <8 x i64> %1796, splat (i64 32)
  %1800 = add <8 x i64> %1798, %1799
  %1801 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1797, 0
  %1802 = insertvalue { <8 x ptr>, <8 x i64> } %1801, <8 x i64> %1800, 1
  %1803 = extractvalue { <8 x ptr>, <8 x i64> } %1802, 0
  %1804 = extractvalue { <8 x ptr>, <8 x i64> } %1802, 1
  %1805 = getelementptr i8, <8 x ptr> %1803, <8 x i64> %1804
  %1806 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1805, <8 x i1> %1737, <8 x float> zeroinitializer)
  %1807 = fmul <8 x float> %1754, %1806
  %.state1331 = load <8 x float>, ptr %.slot202, align 32
  %1808 = fadd <8 x float> %.state1331, %1807
  %.state1332 = load <8 x i64>, ptr %.slot198, align 64
  %1809 = add <8 x i64> %.state1332, splat (i64 1)
  %1810 = load <8 x i64>, ptr %.slot198, align 64
  %1811 = select <8 x i1> %1737, <8 x i64> %1809, <8 x i64> %1810
  store <8 x i64> %1811, ptr %.slot198, align 64
  %1812 = load <8 x float>, ptr %.slot199, align 32
  %1813 = select <8 x i1> %1737, <8 x float> %1769, <8 x float> %1812
  store <8 x float> %1813, ptr %.slot199, align 32
  %1814 = load <8 x float>, ptr %.slot200, align 32
  %1815 = select <8 x i1> %1737, <8 x float> %1782, <8 x float> %1814
  store <8 x float> %1815, ptr %.slot200, align 32
  %1816 = load <8 x float>, ptr %.slot201, align 32
  %1817 = select <8 x i1> %1737, <8 x float> %1795, <8 x float> %1816
  store <8 x float> %1817, ptr %.slot201, align 32
  %1818 = load <8 x float>, ptr %.slot202, align 32
  %1819 = select <8 x i1> %1737, <8 x float> %1808, <8 x float> %1818
  store <8 x float> %1819, ptr %.slot202, align 32
  store <8 x i1> %1737, ptr %current.mask, align 1
  %1820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1737)
  br i1 %1820, label %schedule.91, label %scheduler.loop

schedule.93:                                      ; preds = %varying.coherent.false1315, %scheduler.dispatch.route
  %1821 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1335 = load i32, ptr %current.token, align 4
  %convergence.token.present1336 = icmp ne i32 %convergence.current.token1335, 0
  br i1 %convergence.token.present1336, label %convergence.cascade1333, label %convergence.cascade.exit1334

schedule.94:                                      ; preds = %varying.coherent.false1296, %scheduler.dispatch.route
  %1822 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1365 = load i32, ptr %current.token, align 4
  %convergence.token.present1366 = icmp ne i32 %convergence.current.token1365, 0
  br i1 %convergence.token.present1366, label %convergence.cascade1363, label %convergence.cascade.exit1364

schedule.95:                                      ; preds = %varying.coherent.false1287, %scheduler.dispatch.route
  %1823 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1383 = load i32, ptr %current.token, align 4
  %convergence.token.present1384 = icmp ne i32 %convergence.current.token1383, 0
  br i1 %convergence.token.present1384, label %convergence.cascade1381, label %convergence.cascade.exit1382

schedule.96:                                      ; preds = %schedule.97, %convergence.target.95.ready, %scheduler.dispatch.route
  %1824 = load <8 x i1>, ptr %current.mask, align 1
  %1825 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1824)
  %1826 = bitcast <8 x i1> %1824 to i8
  %1827 = call i8 @llvm.cttz.i8(i8 %1826, i1 false)
  %1828 = zext i8 %1827 to i32
  %1829 = select i1 %1825, i32 %1828, i32 0
  %.state1398 = load <8 x i64>, ptr %.slot203, align 64
  %1830 = icmp slt <8 x i64> %.state1398, splat (i64 320)
  %1831 = and <8 x i1> %1824, %1830
  %1832 = xor <8 x i1> %1830, splat (i1 true)
  %1833 = and <8 x i1> %1824, %1832
  %1834 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1831)
  %1835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1833)
  %1836 = and i1 %1834, %1835
  br i1 %1836, label %varying.divergent1399, label %varying.coherent1400

schedule.97:                                      ; preds = %varying.coherent.true1405, %scheduler.dispatch.route
  %1837 = load <8 x i1>, ptr %current.mask, align 1
  %1838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1837)
  %1839 = bitcast <8 x i1> %1837 to i8
  %1840 = call i8 @llvm.cttz.i8(i8 %1839, i1 false)
  %1841 = zext i8 %1840 to i32
  %1842 = select i1 %1838, i32 %1841, i32 0
  %tile_snapshot.spill.load1407 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill186, align 64
  %1843 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1407, 0
  %1844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1407, 1
  %.state1408 = load <8 x i64>, ptr %.slot203, align 64
  %1845 = mul <8 x i64> %.state1408, splat (i64 32)
  %1846 = add <8 x i64> %1844, %1845
  %1847 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1843, 0
  %1848 = insertvalue { <8 x ptr>, <8 x i64> } %1847, <8 x i64> %1846, 1
  %1849 = extractvalue { <8 x ptr>, <8 x i64> } %1848, 0
  %1850 = extractvalue { <8 x ptr>, <8 x i64> } %1848, 1
  %1851 = getelementptr i8, <8 x ptr> %1849, <8 x i64> %1850
  %1852 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1851, <8 x i1> %1837, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1409 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %1853 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1409, 0
  %1854 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1409, 1
  %.state1410 = load <8 x i64>, ptr %.slot203, align 64
  %1855 = mul <8 x i64> %.state1410, splat (i64 32)
  %1856 = add <8 x i64> %1854, %1855
  %1857 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1853, 0
  %1858 = insertvalue { <8 x ptr>, <8 x i64> } %1857, <8 x i64> %1856, 1
  %1859 = extractvalue { <8 x ptr>, <8 x i64> } %1858, 0
  %1860 = extractvalue { <8 x ptr>, <8 x i64> } %1858, 1
  %1861 = getelementptr i8, <8 x ptr> %1859, <8 x i64> %1860
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1852, <8 x ptr> align 1 %1861, <8 x i1> %1837)
  %.state1411 = load <8 x i64>, ptr %.slot203, align 64
  %1862 = add <8 x i64> %.state1411, splat (i64 1)
  %1863 = load <8 x i64>, ptr %.slot203, align 64
  %1864 = select <8 x i1> %1837, <8 x i64> %1862, <8 x i64> %1863
  store <8 x i64> %1864, ptr %.slot203, align 64
  store <8 x i1> %1837, ptr %current.mask, align 1
  %1865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1837)
  br i1 %1865, label %schedule.96, label %scheduler.loop

schedule.98:                                      ; preds = %varying.coherent.false1406, %scheduler.dispatch.route
  %1866 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1414 = load i32, ptr %current.token, align 4
  %convergence.token.present1415 = icmp ne i32 %convergence.current.token1414, 0
  br i1 %convergence.token.present1415, label %convergence.cascade1412, label %convergence.cascade.exit1413

schedule.99:                                      ; preds = %schedule.100, %convergence.target.98.ready, %scheduler.dispatch.route
  %1867 = load <8 x i1>, ptr %current.mask, align 1
  %1868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1867)
  %1869 = bitcast <8 x i1> %1867 to i8
  %1870 = call i8 @llvm.cttz.i8(i8 %1869, i1 false)
  %1871 = zext i8 %1870 to i32
  %1872 = select i1 %1868, i32 %1871, i32 0
  %.state1429 = load <8 x i64>, ptr %.slot204, align 64
  %1873 = icmp slt <8 x i64> %.state1429, splat (i64 320)
  %1874 = and <8 x i1> %1867, %1873
  %1875 = xor <8 x i1> %1873, splat (i1 true)
  %1876 = and <8 x i1> %1867, %1875
  %1877 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1874)
  %1878 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1876)
  %1879 = and i1 %1877, %1878
  br i1 %1879, label %varying.divergent1430, label %varying.coherent1431

schedule.100:                                     ; preds = %varying.coherent.true1436, %scheduler.dispatch.route
  %1880 = load <8 x i1>, ptr %current.mask, align 1
  %1881 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1880)
  %1882 = bitcast <8 x i1> %1880 to i8
  %1883 = call i8 @llvm.cttz.i8(i8 %1882, i1 false)
  %1884 = zext i8 %1883 to i32
  %1885 = select i1 %1881, i32 %1884, i32 0
  %tile_snapshot.spill.load1438 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %1886 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1438, 0
  %1887 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1438, 1
  %.state1439 = load <8 x i64>, ptr %.slot204, align 64
  %1888 = mul <8 x i64> %.state1439, splat (i64 32)
  %1889 = add <8 x i64> %1887, %1888
  %1890 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1886, 0
  %1891 = insertvalue { <8 x ptr>, <8 x i64> } %1890, <8 x i64> %1889, 1
  %1892 = extractvalue { <8 x ptr>, <8 x i64> } %1891, 0
  %1893 = extractvalue { <8 x ptr>, <8 x i64> } %1891, 1
  %1894 = getelementptr i8, <8 x ptr> %1892, <8 x i64> %1893
  %1895 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1894, <8 x i1> %1880, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1440 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %1896 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1440, 0
  %1897 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1440, 1
  %.state1441 = load <8 x i64>, ptr %.slot204, align 64
  %1898 = mul <8 x i64> %.state1441, splat (i64 32)
  %1899 = add <8 x i64> %1897, %1898
  %1900 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1896, 0
  %1901 = insertvalue { <8 x ptr>, <8 x i64> } %1900, <8 x i64> %1899, 1
  %1902 = extractvalue { <8 x ptr>, <8 x i64> } %1901, 0
  %1903 = extractvalue { <8 x ptr>, <8 x i64> } %1901, 1
  %1904 = getelementptr i8, <8 x ptr> %1902, <8 x i64> %1903
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1895, <8 x ptr> align 1 %1904, <8 x i1> %1880)
  %.state1442 = load <8 x i64>, ptr %.slot204, align 64
  %1905 = add <8 x i64> %.state1442, splat (i64 1)
  %1906 = load <8 x i64>, ptr %.slot204, align 64
  %1907 = select <8 x i1> %1880, <8 x i64> %1905, <8 x i64> %1906
  store <8 x i64> %1907, ptr %.slot204, align 64
  store <8 x i1> %1880, ptr %current.mask, align 1
  %1908 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1880)
  br i1 %1908, label %schedule.99, label %scheduler.loop

schedule.101:                                     ; preds = %varying.coherent.false1437, %scheduler.dispatch.route
  %1909 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1445 = load i32, ptr %current.token, align 4
  %convergence.token.present1446 = icmp ne i32 %convergence.current.token1445, 0
  br i1 %convergence.token.present1446, label %convergence.cascade1443, label %convergence.cascade.exit1444

schedule.102:                                     ; preds = %varying.coherent.false296, %scheduler.dispatch.route
  %1910 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1479 = load i32, ptr %current.token, align 4
  %convergence.token.present1480 = icmp ne i32 %convergence.current.token1479, 0
  br i1 %convergence.token.present1480, label %convergence.cascade1477, label %convergence.cascade.exit1478

schedule.103:                                     ; preds = %convergence.target.106.ready, %convergence.target.102.ready, %scheduler.dispatch.route
  %1911 = load <8 x i1>, ptr %current.mask, align 1
  %1912 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1911)
  %1913 = bitcast <8 x i1> %1911 to i8
  %1914 = call i8 @llvm.cttz.i8(i8 %1913, i1 false)
  %1915 = zext i8 %1914 to i32
  %1916 = select i1 %1912, i32 %1915, i32 0
  %.state1518 = load <8 x i64>, ptr %.slot206, align 64
  %1917 = icmp slt <8 x i64> %.state1518, splat (i64 320)
  %1918 = and <8 x i1> %1911, %1917
  %1919 = xor <8 x i1> %1917, splat (i1 true)
  %1920 = and <8 x i1> %1911, %1919
  %1921 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1918)
  %1922 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1920)
  %1923 = and i1 %1921, %1922
  br i1 %1923, label %varying.divergent1519, label %varying.coherent1520

schedule.104:                                     ; preds = %varying.coherent.true1525, %scheduler.dispatch.route
  %1924 = load <8 x i1>, ptr %current.mask, align 1
  %1925 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1924)
  %1926 = bitcast <8 x i1> %1924 to i8
  %1927 = call i8 @llvm.cttz.i8(i8 %1926, i1 false)
  %1928 = zext i8 %1927 to i32
  %1929 = select i1 %1925, i32 %1928, i32 0
  %.state1527 = load <8 x i64>, ptr %.slot206, align 64
  %1930 = select <8 x i1> %1924, <8 x i64> %.state1527, <8 x i64> zeroinitializer
  %1931 = select <8 x i1> %1924, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1932 = srem <8 x i64> %1930, %1931
  %.state1528 = load <8 x i64>, ptr %.slot206, align 64
  %1933 = select <8 x i1> %1924, <8 x i64> %.state1528, <8 x i64> zeroinitializer
  %1934 = select <8 x i1> %1924, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1935 = sdiv <8 x i64> %1933, %1934
  %.spill.load1529 = load <8 x i64>, ptr %.spill, align 64
  %1936 = add <8 x i64> %.spill.load1529, zeroinitializer
  %1937 = add <8 x i64> zeroinitializer, %1936
  %.spill.load1530 = load <8 x i64>, ptr %.spill61, align 64
  %1938 = add <8 x i64> %.spill.load1530, %1935
  %1939 = mul <8 x i64> %1937, splat (i64 33)
  %1940 = add <8 x i64> %1939, %1938
  %1941 = icmp sge <8 x i64> %1938, zeroinitializer
  %1942 = and <8 x i1> splat (i1 true), %1941
  %1943 = icmp slt <8 x i64> %1938, splat (i64 33)
  %1944 = and <8 x i1> %1942, %1943
  %1945 = add <8 x i64> zeroinitializer, %1932
  %1946 = mul <8 x i64> %1940, splat (i64 40)
  %1947 = add <8 x i64> %1946, %1945
  %1948 = load <8 x i64>, ptr %.spill207, align 64
  %1949 = select <8 x i1> %1924, <8 x i64> %1947, <8 x i64> %1948
  store <8 x i64> %1949, ptr %.spill207, align 64
  %1950 = add <8 x i64> zeroinitializer, %1935
  %1951 = mul <8 x i64> %1950, splat (i64 40)
  %1952 = add <8 x i64> %1951, %1932
  %tile_snapshot.spill.load1531 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %1953 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1531, 0
  %1954 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1531, 1
  %1955 = mul <8 x i64> %1952, splat (i64 32)
  %1956 = add <8 x i64> %1954, %1955
  %1957 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1953, 0
  %1958 = insertvalue { <8 x ptr>, <8 x i64> } %1957, <8 x i64> %1956, 1
  %1959 = extractvalue { <8 x ptr>, <8 x i64> } %1958, 0
  %1960 = extractvalue { <8 x ptr>, <8 x i64> } %1958, 1
  %1961 = getelementptr i8, <8 x ptr> %1959, <8 x i64> %1960
  %1962 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1961, <8 x i1> %1924, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1532 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill205, align 64
  %1963 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1532, 0
  %1964 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1532, 1
  %1965 = mul <8 x i64> %1950, splat (i64 32)
  %1966 = add <8 x i64> %1964, %1965
  %1967 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1963, 0
  %1968 = insertvalue { <8 x ptr>, <8 x i64> } %1967, <8 x i64> %1966, 1
  %1969 = extractvalue { <8 x ptr>, <8 x i64> } %1968, 0
  %1970 = extractvalue { <8 x ptr>, <8 x i64> } %1968, 1
  %1971 = getelementptr i8, <8 x ptr> %1969, <8 x i64> %1970
  %1972 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1971, <8 x i1> %1924, <8 x float> zeroinitializer)
  %1973 = fdiv <8 x float> %1962, %1972
  %1974 = load <8 x float>, ptr %.spill208, align 32
  %1975 = select <8 x i1> %1924, <8 x float> %1973, <8 x float> %1974
  store <8 x float> %1975, ptr %.spill208, align 32
  %1976 = and <8 x i1> %1924, %1944
  %1977 = xor <8 x i1> %1944, splat (i1 true)
  %1978 = and <8 x i1> %1924, %1977
  %1979 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1976)
  %1980 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1978)
  %1981 = and i1 %1979, %1980
  br i1 %1981, label %varying.divergent1533, label %varying.coherent1534

schedule.105:                                     ; preds = %varying.coherent.true1539, %scheduler.dispatch.route
  %1982 = load <8 x i1>, ptr %current.mask, align 1
  %1983 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1982)
  %1984 = bitcast <8 x i1> %1982 to i8
  %1985 = call i8 @llvm.cttz.i8(i8 %1984, i1 false)
  %1986 = zext i8 %1985 to i32
  %1987 = select i1 %1983, i32 %1986, i32 0
  %.spill.load1541 = load <8 x i64>, ptr %.spill207, align 64
  %.spill.load1542 = load <8 x float>, ptr %.spill208, align 32
  %1988 = extractvalue { ptr, i64 } %71, 0
  %1989 = mul <8 x i64> %.spill.load1541, splat (i64 4)
  %1990 = getelementptr i8, ptr %1988, <8 x i64> %1989
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load1542, <8 x ptr> align 1 %1990, <8 x i1> %1982)
  store <8 x i1> %1982, ptr %current.mask, align 1
  %1991 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1982)
  br i1 %1991, label %schedule.106, label %scheduler.loop

schedule.106:                                     ; preds = %schedule.105, %varying.coherent.false1540, %scheduler.dispatch.route
  %1992 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1545 = load i32, ptr %current.token, align 4
  %convergence.token.present1546 = icmp ne i32 %convergence.current.token1545, 0
  br i1 %convergence.token.present1546, label %convergence.cascade1543, label %convergence.cascade.exit1544

schedule.107:                                     ; preds = %varying.coherent.false1526, %scheduler.dispatch.route
  %1993 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1563 = load i32, ptr %current.token, align 4
  %convergence.token.present1564 = icmp ne i32 %convergence.current.token1563, 0
  br i1 %convergence.token.present1564, label %convergence.cascade1561, label %convergence.cascade.exit1562

varying.divergent:                                ; preds = %schedule.1
  %1994 = load i32, ptr %current.token, align 4
  %1995 = icmp ne i32 %1994, 0
  %1996 = sub i32 %1994, 1
  %1997 = select i1 %1995, i32 %1996, i32 0
  %1998 = load i8, ptr %frame.active, align 1
  %1999 = trunc i32 %1997 to i8
  %2000 = shl i8 1, %1999
  %2001 = and i8 %1998, %2000
  %2002 = icmp ne i8 %2001, 0
  %2003 = load <8 x i32>, ptr %frame.static.id, align 32
  %2004 = extractelement <8 x i32> %2003, i32 %1997
  %2005 = icmp eq i32 %2004, 0
  %2006 = and i1 %2002, %2005
  %2007 = and i1 %1995, %2006
  %2008 = xor i1 %2007, true
  %2009 = and i1 true, %2008
  %2010 = xor i8 %1998, -1
  %2011 = icmp ne i8 %2010, 0
  %2012 = xor i1 %2011, true
  %2013 = and i1 %2009, %2012
  br i1 %2013, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.1
  br i1 %178, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %2014 = call i8 @llvm.cttz.i8(i8 %2010, i1 false)
  %2015 = zext i8 %2014 to i32
  %2016 = select i1 %2011, i32 %2015, i32 0
  %2017 = trunc i32 %2016 to i8
  %2018 = shl i8 1, %2017
  %2019 = or i8 %1998, %2018
  %2020 = select i1 %2009, i8 %2019, i8 %1998
  store i8 %2020, ptr %frame.active, align 1
  %2021 = load <8 x i32>, ptr %frame.static.id, align 32
  %2022 = extractelement <8 x i32> %2021, i32 %2016
  %2023 = select i1 %2009, i32 0, i32 %2022
  %2024 = load <8 x i32>, ptr %frame.static.id, align 32
  %2025 = insertelement <8 x i32> %2024, i32 %2023, i32 %2016
  store <8 x i32> %2025, ptr %frame.static.id, align 32
  %2026 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2027 = extractelement <8 x i32> %2026, i32 %2016
  %2028 = select i1 %2009, i32 %1994, i32 %2027
  %2029 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2030 = insertelement <8 x i32> %2029, i32 %2028, i32 %2016
  store <8 x i32> %2030, ptr %frame.parent.token, align 32
  %2031 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2016
  %2032 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2016
  %2033 = load <8 x i1>, ptr %2031, align 1
  %2034 = load <8 x i1>, ptr %2032, align 1
  %2035 = select i1 %2009, <8 x i1> %168, <8 x i1> %2033
  store <8 x i1> %2035, ptr %2031, align 1
  %2036 = select i1 %2009, <8 x i1> zeroinitializer, <8 x i1> %2034
  store <8 x i1> %2036, ptr %2032, align 1
  %2037 = add i32 %2016, 1
  %2038 = select i1 %2007, i32 %1994, i32 %2037
  %2039 = select i1 true, i32 %2038, i32 %1994
  store i32 %2039, ptr %current.token, align 4
  %2040 = load i32, ptr %current.token, align 4
  %2041 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %175)
  %2042 = load i32, ptr %ready.count, align 4
  %2043 = icmp uge i32 %2042, 8
  %2044 = and i1 %2041, %2043
  br i1 %2044, label %ready.overflow.trap219, label %ready.overflow.resume220

ready.overflow.trap219:                           ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume220:                         ; preds = %convergence.overflow.resume
  %2045 = select i1 %2041, i32 %2042, i32 0
  %2046 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2045
  %2047 = load <8 x i1>, ptr %2046, align 1
  %2048 = select i1 %2041, <8 x i1> %175, <8 x i1> %2047
  store <8 x i1> %2048, ptr %2046, align 1
  %2049 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2045
  %2050 = load i32, ptr %2049, align 4
  %2051 = select i1 %2041, i32 2, i32 %2050
  store i32 %2051, ptr %2049, align 4
  %2052 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2045
  %2053 = load i32, ptr %2052, align 4
  %2054 = select i1 %2041, i32 %2040, i32 %2053
  store i32 %2054, ptr %2052, align 4
  %2055 = add i32 %2042, 1
  %2056 = select i1 %2041, i32 %2055, i32 %2042
  store i32 %2056, ptr %ready.count, align 4
  %2057 = load <8 x i1>, ptr %runnable.mask, align 1
  %2058 = or <8 x i1> %2057, %175
  store <8 x i1> %2058, ptr %runnable.mask, align 1
  store <8 x i1> %177, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %168, ptr %current.mask, align 1
  %2059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %168)
  br i1 %2059, label %schedule.2, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %168, ptr %current.mask, align 1
  %2060 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %168)
  br i1 %2060, label %schedule.5, label %scheduler.loop

varying.divergent224:                             ; preds = %schedule.2
  %2061 = load i32, ptr %current.token, align 4
  %2062 = icmp ne i32 %2061, 0
  %2063 = sub i32 %2061, 1
  %2064 = select i1 %2062, i32 %2063, i32 0
  %2065 = load i8, ptr %frame.active, align 1
  %2066 = trunc i32 %2064 to i8
  %2067 = shl i8 1, %2066
  %2068 = and i8 %2065, %2067
  %2069 = icmp ne i8 %2068, 0
  %2070 = load <8 x i32>, ptr %frame.static.id, align 32
  %2071 = extractelement <8 x i32> %2070, i32 %2064
  %2072 = icmp eq i32 %2071, 1
  %2073 = and i1 %2069, %2072
  %2074 = and i1 %2062, %2073
  %2075 = xor i1 %2074, true
  %2076 = and i1 true, %2075
  %2077 = xor i8 %2065, -1
  %2078 = icmp ne i8 %2077, 0
  %2079 = xor i1 %2078, true
  %2080 = and i1 %2076, %2079
  br i1 %2080, label %convergence.overflow.trap226, label %convergence.overflow.resume227

varying.coherent225:                              ; preds = %schedule.2
  br i1 %210, label %varying.coherent.true230, label %varying.coherent.false231

convergence.overflow.trap226:                     ; preds = %varying.divergent224
  call void @llvm.trap()
  unreachable

convergence.overflow.resume227:                   ; preds = %varying.divergent224
  %2081 = call i8 @llvm.cttz.i8(i8 %2077, i1 false)
  %2082 = zext i8 %2081 to i32
  %2083 = select i1 %2078, i32 %2082, i32 0
  %2084 = trunc i32 %2083 to i8
  %2085 = shl i8 1, %2084
  %2086 = or i8 %2065, %2085
  %2087 = select i1 %2076, i8 %2086, i8 %2065
  store i8 %2087, ptr %frame.active, align 1
  %2088 = load <8 x i32>, ptr %frame.static.id, align 32
  %2089 = extractelement <8 x i32> %2088, i32 %2083
  %2090 = select i1 %2076, i32 1, i32 %2089
  %2091 = load <8 x i32>, ptr %frame.static.id, align 32
  %2092 = insertelement <8 x i32> %2091, i32 %2090, i32 %2083
  store <8 x i32> %2092, ptr %frame.static.id, align 32
  %2093 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2094 = extractelement <8 x i32> %2093, i32 %2083
  %2095 = select i1 %2076, i32 %2061, i32 %2094
  %2096 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2097 = insertelement <8 x i32> %2096, i32 %2095, i32 %2083
  store <8 x i32> %2097, ptr %frame.parent.token, align 32
  %2098 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2083
  %2099 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2083
  %2100 = load <8 x i1>, ptr %2098, align 1
  %2101 = load <8 x i1>, ptr %2099, align 1
  %2102 = select i1 %2076, <8 x i1> %181, <8 x i1> %2100
  store <8 x i1> %2102, ptr %2098, align 1
  %2103 = select i1 %2076, <8 x i1> zeroinitializer, <8 x i1> %2101
  store <8 x i1> %2103, ptr %2099, align 1
  %2104 = add i32 %2083, 1
  %2105 = select i1 %2074, i32 %2061, i32 %2104
  %2106 = select i1 true, i32 %2105, i32 %2061
  store i32 %2106, ptr %current.token, align 4
  %2107 = load <8 x float>, ptr %.slot64, align 32
  %2108 = select <8 x i1> %209, <8 x float> zeroinitializer, <8 x float> %2107
  store <8 x float> %2108, ptr %.slot64, align 32
  %2109 = load i32, ptr %current.token, align 4
  %2110 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %207)
  %2111 = load i32, ptr %ready.count, align 4
  %2112 = icmp uge i32 %2111, 8
  %2113 = and i1 %2110, %2112
  br i1 %2113, label %ready.overflow.trap228, label %ready.overflow.resume229

ready.overflow.trap228:                           ; preds = %convergence.overflow.resume227
  call void @llvm.trap()
  unreachable

ready.overflow.resume229:                         ; preds = %convergence.overflow.resume227
  %2114 = select i1 %2110, i32 %2111, i32 0
  %2115 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2114
  %2116 = load <8 x i1>, ptr %2115, align 1
  %2117 = select i1 %2110, <8 x i1> %207, <8 x i1> %2116
  store <8 x i1> %2117, ptr %2115, align 1
  %2118 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2114
  %2119 = load i32, ptr %2118, align 4
  %2120 = select i1 %2110, i32 3, i32 %2119
  store i32 %2120, ptr %2118, align 4
  %2121 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2114
  %2122 = load i32, ptr %2121, align 4
  %2123 = select i1 %2110, i32 %2109, i32 %2122
  store i32 %2123, ptr %2121, align 4
  %2124 = add i32 %2111, 1
  %2125 = select i1 %2110, i32 %2124, i32 %2111
  store i32 %2125, ptr %ready.count, align 4
  %2126 = load <8 x i1>, ptr %runnable.mask, align 1
  %2127 = or <8 x i1> %2126, %207
  store <8 x i1> %2127, ptr %runnable.mask, align 1
  store <8 x i1> %209, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true230:                         ; preds = %varying.coherent225
  store <8 x i1> %181, ptr %current.mask, align 1
  %2128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %181)
  br i1 %2128, label %schedule.3, label %scheduler.loop

varying.coherent.false231:                        ; preds = %varying.coherent225
  %2129 = load <8 x float>, ptr %.slot64, align 32
  %2130 = select <8 x i1> %181, <8 x float> zeroinitializer, <8 x float> %2129
  store <8 x float> %2130, ptr %.slot64, align 32
  store <8 x i1> %181, ptr %current.mask, align 1
  %2131 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %181)
  br i1 %2131, label %schedule.4, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.flow = phi <8 x i1> [ %226, %schedule.4 ], [ %2174, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.4 ], [ %2175, %convergence.cascade ]
  %2132 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %2133 = load i32, ptr %current.token, align 4
  %2134 = icmp ne i32 %2133, 0
  %2135 = and i1 %2132, %2134
  %2136 = sub i32 %2133, 1
  %2137 = select i1 %2135, i32 %2136, i32 0
  %2138 = load i8, ptr %frame.active, align 1
  %2139 = trunc i32 %2137 to i8
  %2140 = shl i8 1, %2139
  %2141 = and i8 %2138, %2140
  %2142 = icmp ne i8 %2141, 0
  %2143 = load <8 x i32>, ptr %frame.static.id, align 32
  %2144 = extractelement <8 x i32> %2143, i32 %2137
  %convergence.target.pointer = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2144
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %2145 = icmp eq i32 %convergence.dynamic.target, 4
  %2146 = and i1 %2142, %2145
  %2147 = and i1 %2135, %2146
  %2148 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2137
  %2149 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2137
  %2150 = load <8 x i1>, ptr %2148, align 1
  %2151 = load <8 x i1>, ptr %2149, align 1
  %2152 = or <8 x i1> %2151, %convergence.cascade.flow
  %2153 = load <8 x i1>, ptr %live.mask, align 1
  %2154 = and <8 x i1> %2150, %2153
  %2155 = icmp eq <8 x i1> %2152, %2154
  %2156 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2155)
  %2157 = and i1 %2147, %2156
  %2158 = select i1 %2157, <8 x i1> zeroinitializer, <8 x i1> %2152
  %2159 = select i1 %2147, <8 x i1> %2158, <8 x i1> %2151
  store <8 x i1> %2159, ptr %2149, align 1
  %2160 = select i1 %2157, <8 x i1> zeroinitializer, <8 x i1> %2150
  store <8 x i1> %2160, ptr %2148, align 1
  %2161 = trunc i32 %2137 to i8
  %2162 = shl i8 1, %2161
  %2163 = xor i8 %2162, -1
  %2164 = and i8 %2138, %2163
  %2165 = select i1 %2157, i8 %2164, i8 %2138
  store i8 %2165, ptr %frame.active, align 1
  %.splatinsert233 = insertelement <8 x i1> poison, i1 %2147, i64 0
  %.splat234 = shufflevector <8 x i1> %.splatinsert233, <8 x i1> poison, <8 x i32> zeroinitializer
  %2166 = and <8 x i1> %convergence.cascade.flow, %.splat234
  %2167 = load <8 x i1>, ptr %runnable.mask, align 1
  %2168 = xor <8 x i1> %2166, splat (i1 true)
  %2169 = and <8 x i1> %2167, %2168
  store <8 x i1> %2169, ptr %runnable.mask, align 1
  %.splatinsert235 = insertelement <8 x i1> poison, i1 %2157, i64 0
  %.splat236 = shufflevector <8 x i1> %.splatinsert235, <8 x i1> poison, <8 x i32> zeroinitializer
  %2170 = select <8 x i1> %.splat236, <8 x i1> %2152, <8 x i1> zeroinitializer
  %2171 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2172 = extractelement <8 x i32> %2171, i32 %2137
  %2173 = select i1 %2157, i32 %2172, i32 %2133
  store i32 %2173, ptr %current.token, align 4
  %.splatinsert237 = insertelement <8 x i1> poison, i1 %2147, i64 0
  %.splat238 = shufflevector <8 x i1> %.splatinsert237, <8 x i1> poison, <8 x i32> zeroinitializer
  %2174 = select <8 x i1> %.splat238, <8 x i1> %2170, <8 x i1> %convergence.cascade.flow
  %2175 = add i32 %convergence.cascade.depth, 1
  %2176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2174)
  %2177 = icmp ult i32 %2175, 8
  %2178 = and i1 %2176, %2177
  %2179 = and i1 %2147, %2178
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %2180 = and i1 %2179, %convergence.parent.present
  br i1 %2180, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.result = phi <8 x i1> [ %226, %schedule.4 ], [ %2174, %convergence.cascade ]
  %2181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %2181, label %convergence.target.4.ready, label %scheduler.loop

convergence.target.4.ready:                       ; preds = %convergence.cascade.exit
  %2182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %2183 = bitcast <8 x i1> %convergence.cascade.result to i8
  %2184 = call i8 @llvm.cttz.i8(i8 %2183, i1 false)
  %2185 = zext i8 %2184 to i32
  %2186 = select i1 %2182, i32 %2185, i32 0
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %2188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state239 = load <8 x i64>, ptr %.slot, align 64
  %2189 = mul <8 x i64> %.state239, splat (i64 32)
  %2190 = add <8 x i64> %2188, %2189
  %2191 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2187, 0
  %2192 = insertvalue { <8 x ptr>, <8 x i64> } %2191, <8 x i64> %2190, 1
  %.state240 = load <8 x float>, ptr %.slot64, align 32
  %2193 = extractvalue { <8 x ptr>, <8 x i64> } %2192, 0
  %2194 = extractvalue { <8 x ptr>, <8 x i64> } %2192, 1
  %2195 = getelementptr i8, <8 x ptr> %2193, <8 x i64> %2194
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state240, <8 x ptr> align 1 %2195, <8 x i1> %convergence.cascade.result)
  %.state241 = load <8 x i64>, ptr %.slot, align 64
  %2196 = add <8 x i64> %.state241, splat (i64 1)
  %2197 = load <8 x i64>, ptr %.slot, align 64
  %2198 = select <8 x i1> %convergence.cascade.result, <8 x i64> %2196, <8 x i64> %2197
  store <8 x i64> %2198, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %2199 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %2199, label %schedule.1, label %scheduler.loop

convergence.cascade242:                           ; preds = %convergence.cascade242, %schedule.5
  %convergence.cascade.flow246 = phi <8 x i1> [ %227, %schedule.5 ], [ %2242, %convergence.cascade242 ]
  %convergence.cascade.depth247 = phi i32 [ 0, %schedule.5 ], [ %2243, %convergence.cascade242 ]
  %2200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow246)
  %2201 = load i32, ptr %current.token, align 4
  %2202 = icmp ne i32 %2201, 0
  %2203 = and i1 %2200, %2202
  %2204 = sub i32 %2201, 1
  %2205 = select i1 %2203, i32 %2204, i32 0
  %2206 = load i8, ptr %frame.active, align 1
  %2207 = trunc i32 %2205 to i8
  %2208 = shl i8 1, %2207
  %2209 = and i8 %2206, %2208
  %2210 = icmp ne i8 %2209, 0
  %2211 = load <8 x i32>, ptr %frame.static.id, align 32
  %2212 = extractelement <8 x i32> %2211, i32 %2205
  %convergence.target.pointer248 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2212
  %convergence.dynamic.target249 = load i32, ptr %convergence.target.pointer248, align 4
  %2213 = icmp eq i32 %convergence.dynamic.target249, 5
  %2214 = and i1 %2210, %2213
  %2215 = and i1 %2203, %2214
  %2216 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2205
  %2217 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2205
  %2218 = load <8 x i1>, ptr %2216, align 1
  %2219 = load <8 x i1>, ptr %2217, align 1
  %2220 = or <8 x i1> %2219, %convergence.cascade.flow246
  %2221 = load <8 x i1>, ptr %live.mask, align 1
  %2222 = and <8 x i1> %2218, %2221
  %2223 = icmp eq <8 x i1> %2220, %2222
  %2224 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2223)
  %2225 = and i1 %2215, %2224
  %2226 = select i1 %2225, <8 x i1> zeroinitializer, <8 x i1> %2220
  %2227 = select i1 %2215, <8 x i1> %2226, <8 x i1> %2219
  store <8 x i1> %2227, ptr %2217, align 1
  %2228 = select i1 %2225, <8 x i1> zeroinitializer, <8 x i1> %2218
  store <8 x i1> %2228, ptr %2216, align 1
  %2229 = trunc i32 %2205 to i8
  %2230 = shl i8 1, %2229
  %2231 = xor i8 %2230, -1
  %2232 = and i8 %2206, %2231
  %2233 = select i1 %2225, i8 %2232, i8 %2206
  store i8 %2233, ptr %frame.active, align 1
  %.splatinsert250 = insertelement <8 x i1> poison, i1 %2215, i64 0
  %.splat251 = shufflevector <8 x i1> %.splatinsert250, <8 x i1> poison, <8 x i32> zeroinitializer
  %2234 = and <8 x i1> %convergence.cascade.flow246, %.splat251
  %2235 = load <8 x i1>, ptr %runnable.mask, align 1
  %2236 = xor <8 x i1> %2234, splat (i1 true)
  %2237 = and <8 x i1> %2235, %2236
  store <8 x i1> %2237, ptr %runnable.mask, align 1
  %.splatinsert252 = insertelement <8 x i1> poison, i1 %2225, i64 0
  %.splat253 = shufflevector <8 x i1> %.splatinsert252, <8 x i1> poison, <8 x i32> zeroinitializer
  %2238 = select <8 x i1> %.splat253, <8 x i1> %2220, <8 x i1> zeroinitializer
  %2239 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2240 = extractelement <8 x i32> %2239, i32 %2205
  %2241 = select i1 %2225, i32 %2240, i32 %2201
  store i32 %2241, ptr %current.token, align 4
  %.splatinsert254 = insertelement <8 x i1> poison, i1 %2215, i64 0
  %.splat255 = shufflevector <8 x i1> %.splatinsert254, <8 x i1> poison, <8 x i32> zeroinitializer
  %2242 = select <8 x i1> %.splat255, <8 x i1> %2238, <8 x i1> %convergence.cascade.flow246
  %2243 = add i32 %convergence.cascade.depth247, 1
  %2244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2242)
  %2245 = icmp ult i32 %2243, 8
  %2246 = and i1 %2244, %2245
  %2247 = and i1 %2215, %2246
  %convergence.parent.token256 = load i32, ptr %current.token, align 4
  %convergence.parent.present257 = icmp ne i32 %convergence.parent.token256, 0
  %2248 = and i1 %2247, %convergence.parent.present257
  br i1 %2248, label %convergence.cascade242, label %convergence.cascade.exit243

convergence.cascade.exit243:                      ; preds = %convergence.cascade242, %schedule.5
  %convergence.cascade.result258 = phi <8 x i1> [ %227, %schedule.5 ], [ %2242, %convergence.cascade242 ]
  %2249 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result258)
  br i1 %2249, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit243
  %2250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result258)
  %2251 = bitcast <8 x i1> %convergence.cascade.result258 to i8
  %2252 = call i8 @llvm.cttz.i8(i8 %2251, i1 false)
  %2253 = zext i8 %2252 to i32
  %2254 = select i1 %2250, i32 %2253, i32 0
  %2255 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %2256 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %2257 = extractvalue { <8 x ptr>, <8 x i64> } %2255, 0
  %2258 = select <8 x i1> %convergence.cascade.result258, <8 x ptr> %2256, <8 x ptr> %2257
  %2259 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %2260 = extractvalue { <8 x ptr>, <8 x i64> } %2255, 1
  %2261 = select <8 x i1> %convergence.cascade.result258, <8 x i64> %2259, <8 x i64> %2260
  %2262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2258, 0
  %2263 = insertvalue { <8 x ptr>, <8 x i64> } %2262, <8 x i64> %2261, 1
  store { <8 x ptr>, <8 x i64> } %2263, ptr %tile_snapshot.spill65, align 64
  %2264 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %2265 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %2266 = extractvalue { <8 x ptr>, <8 x i64> } %2264, 0
  %2267 = select <8 x i1> %convergence.cascade.result258, <8 x ptr> %2265, <8 x ptr> %2266
  %2268 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %2269 = extractvalue { <8 x ptr>, <8 x i64> } %2264, 1
  %2270 = select <8 x i1> %convergence.cascade.result258, <8 x i64> %2268, <8 x i64> %2269
  %2271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2267, 0
  %2272 = insertvalue { <8 x ptr>, <8 x i64> } %2271, <8 x i64> %2270, 1
  store { <8 x ptr>, <8 x i64> } %2272, ptr %tile_snapshot.spill66, align 64
  %2273 = load <8 x i64>, ptr %.slot67, align 64
  %2274 = select <8 x i1> %convergence.cascade.result258, <8 x i64> zeroinitializer, <8 x i64> %2273
  store <8 x i64> %2274, ptr %.slot67, align 64
  store <8 x i1> %convergence.cascade.result258, ptr %current.mask, align 1
  %2275 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result258)
  br i1 %2275, label %schedule.6, label %scheduler.loop

varying.divergent260:                             ; preds = %schedule.6
  %2276 = load i32, ptr %current.token, align 4
  %2277 = icmp ne i32 %2276, 0
  %2278 = sub i32 %2276, 1
  %2279 = select i1 %2277, i32 %2278, i32 0
  %2280 = load i8, ptr %frame.active, align 1
  %2281 = trunc i32 %2279 to i8
  %2282 = shl i8 1, %2281
  %2283 = and i8 %2280, %2282
  %2284 = icmp ne i8 %2283, 0
  %2285 = load <8 x i32>, ptr %frame.static.id, align 32
  %2286 = extractelement <8 x i32> %2285, i32 %2279
  %2287 = icmp eq i32 %2286, 2
  %2288 = and i1 %2284, %2287
  %2289 = and i1 %2277, %2288
  %2290 = xor i1 %2289, true
  %2291 = and i1 true, %2290
  %2292 = xor i8 %2280, -1
  %2293 = icmp ne i8 %2292, 0
  %2294 = xor i1 %2293, true
  %2295 = and i1 %2291, %2294
  br i1 %2295, label %convergence.overflow.trap262, label %convergence.overflow.resume263

varying.coherent261:                              ; preds = %schedule.6
  br i1 %238, label %varying.coherent.true266, label %varying.coherent.false267

convergence.overflow.trap262:                     ; preds = %varying.divergent260
  call void @llvm.trap()
  unreachable

convergence.overflow.resume263:                   ; preds = %varying.divergent260
  %2296 = call i8 @llvm.cttz.i8(i8 %2292, i1 false)
  %2297 = zext i8 %2296 to i32
  %2298 = select i1 %2293, i32 %2297, i32 0
  %2299 = trunc i32 %2298 to i8
  %2300 = shl i8 1, %2299
  %2301 = or i8 %2280, %2300
  %2302 = select i1 %2291, i8 %2301, i8 %2280
  store i8 %2302, ptr %frame.active, align 1
  %2303 = load <8 x i32>, ptr %frame.static.id, align 32
  %2304 = extractelement <8 x i32> %2303, i32 %2298
  %2305 = select i1 %2291, i32 2, i32 %2304
  %2306 = load <8 x i32>, ptr %frame.static.id, align 32
  %2307 = insertelement <8 x i32> %2306, i32 %2305, i32 %2298
  store <8 x i32> %2307, ptr %frame.static.id, align 32
  %2308 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2309 = extractelement <8 x i32> %2308, i32 %2298
  %2310 = select i1 %2291, i32 %2276, i32 %2309
  %2311 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2312 = insertelement <8 x i32> %2311, i32 %2310, i32 %2298
  store <8 x i32> %2312, ptr %frame.parent.token, align 32
  %2313 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2298
  %2314 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2298
  %2315 = load <8 x i1>, ptr %2313, align 1
  %2316 = load <8 x i1>, ptr %2314, align 1
  %2317 = select i1 %2291, <8 x i1> %228, <8 x i1> %2315
  store <8 x i1> %2317, ptr %2313, align 1
  %2318 = select i1 %2291, <8 x i1> zeroinitializer, <8 x i1> %2316
  store <8 x i1> %2318, ptr %2314, align 1
  %2319 = add i32 %2298, 1
  %2320 = select i1 %2289, i32 %2276, i32 %2319
  %2321 = select i1 true, i32 %2320, i32 %2276
  store i32 %2321, ptr %current.token, align 4
  %2322 = load i32, ptr %current.token, align 4
  %2323 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %235)
  %2324 = load i32, ptr %ready.count, align 4
  %2325 = icmp uge i32 %2324, 8
  %2326 = and i1 %2323, %2325
  br i1 %2326, label %ready.overflow.trap264, label %ready.overflow.resume265

ready.overflow.trap264:                           ; preds = %convergence.overflow.resume263
  call void @llvm.trap()
  unreachable

ready.overflow.resume265:                         ; preds = %convergence.overflow.resume263
  %2327 = select i1 %2323, i32 %2324, i32 0
  %2328 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2327
  %2329 = load <8 x i1>, ptr %2328, align 1
  %2330 = select i1 %2323, <8 x i1> %235, <8 x i1> %2329
  store <8 x i1> %2330, ptr %2328, align 1
  %2331 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2327
  %2332 = load i32, ptr %2331, align 4
  %2333 = select i1 %2323, i32 7, i32 %2332
  store i32 %2333, ptr %2331, align 4
  %2334 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2327
  %2335 = load i32, ptr %2334, align 4
  %2336 = select i1 %2323, i32 %2322, i32 %2335
  store i32 %2336, ptr %2334, align 4
  %2337 = add i32 %2324, 1
  %2338 = select i1 %2323, i32 %2337, i32 %2324
  store i32 %2338, ptr %ready.count, align 4
  %2339 = load <8 x i1>, ptr %runnable.mask, align 1
  %2340 = or <8 x i1> %2339, %235
  store <8 x i1> %2340, ptr %runnable.mask, align 1
  store <8 x i1> %237, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true266:                         ; preds = %varying.coherent261
  store <8 x i1> %228, ptr %current.mask, align 1
  %2341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  br i1 %2341, label %schedule.7, label %scheduler.loop

varying.coherent.false267:                        ; preds = %varying.coherent261
  store <8 x i1> %228, ptr %current.mask, align 1
  %2342 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  br i1 %2342, label %schedule.8, label %scheduler.loop

convergence.cascade271:                           ; preds = %convergence.cascade271, %schedule.8
  %convergence.cascade.flow275 = phi <8 x i1> [ %260, %schedule.8 ], [ %2385, %convergence.cascade271 ]
  %convergence.cascade.depth276 = phi i32 [ 0, %schedule.8 ], [ %2386, %convergence.cascade271 ]
  %2343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow275)
  %2344 = load i32, ptr %current.token, align 4
  %2345 = icmp ne i32 %2344, 0
  %2346 = and i1 %2343, %2345
  %2347 = sub i32 %2344, 1
  %2348 = select i1 %2346, i32 %2347, i32 0
  %2349 = load i8, ptr %frame.active, align 1
  %2350 = trunc i32 %2348 to i8
  %2351 = shl i8 1, %2350
  %2352 = and i8 %2349, %2351
  %2353 = icmp ne i8 %2352, 0
  %2354 = load <8 x i32>, ptr %frame.static.id, align 32
  %2355 = extractelement <8 x i32> %2354, i32 %2348
  %convergence.target.pointer277 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2355
  %convergence.dynamic.target278 = load i32, ptr %convergence.target.pointer277, align 4
  %2356 = icmp eq i32 %convergence.dynamic.target278, 8
  %2357 = and i1 %2353, %2356
  %2358 = and i1 %2346, %2357
  %2359 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2348
  %2360 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2348
  %2361 = load <8 x i1>, ptr %2359, align 1
  %2362 = load <8 x i1>, ptr %2360, align 1
  %2363 = or <8 x i1> %2362, %convergence.cascade.flow275
  %2364 = load <8 x i1>, ptr %live.mask, align 1
  %2365 = and <8 x i1> %2361, %2364
  %2366 = icmp eq <8 x i1> %2363, %2365
  %2367 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2366)
  %2368 = and i1 %2358, %2367
  %2369 = select i1 %2368, <8 x i1> zeroinitializer, <8 x i1> %2363
  %2370 = select i1 %2358, <8 x i1> %2369, <8 x i1> %2362
  store <8 x i1> %2370, ptr %2360, align 1
  %2371 = select i1 %2368, <8 x i1> zeroinitializer, <8 x i1> %2361
  store <8 x i1> %2371, ptr %2359, align 1
  %2372 = trunc i32 %2348 to i8
  %2373 = shl i8 1, %2372
  %2374 = xor i8 %2373, -1
  %2375 = and i8 %2349, %2374
  %2376 = select i1 %2368, i8 %2375, i8 %2349
  store i8 %2376, ptr %frame.active, align 1
  %.splatinsert279 = insertelement <8 x i1> poison, i1 %2358, i64 0
  %.splat280 = shufflevector <8 x i1> %.splatinsert279, <8 x i1> poison, <8 x i32> zeroinitializer
  %2377 = and <8 x i1> %convergence.cascade.flow275, %.splat280
  %2378 = load <8 x i1>, ptr %runnable.mask, align 1
  %2379 = xor <8 x i1> %2377, splat (i1 true)
  %2380 = and <8 x i1> %2378, %2379
  store <8 x i1> %2380, ptr %runnable.mask, align 1
  %.splatinsert281 = insertelement <8 x i1> poison, i1 %2368, i64 0
  %.splat282 = shufflevector <8 x i1> %.splatinsert281, <8 x i1> poison, <8 x i32> zeroinitializer
  %2381 = select <8 x i1> %.splat282, <8 x i1> %2363, <8 x i1> zeroinitializer
  %2382 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2383 = extractelement <8 x i32> %2382, i32 %2348
  %2384 = select i1 %2368, i32 %2383, i32 %2344
  store i32 %2384, ptr %current.token, align 4
  %.splatinsert283 = insertelement <8 x i1> poison, i1 %2358, i64 0
  %.splat284 = shufflevector <8 x i1> %.splatinsert283, <8 x i1> poison, <8 x i32> zeroinitializer
  %2385 = select <8 x i1> %.splat284, <8 x i1> %2381, <8 x i1> %convergence.cascade.flow275
  %2386 = add i32 %convergence.cascade.depth276, 1
  %2387 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2385)
  %2388 = icmp ult i32 %2386, 8
  %2389 = and i1 %2387, %2388
  %2390 = and i1 %2358, %2389
  %convergence.parent.token285 = load i32, ptr %current.token, align 4
  %convergence.parent.present286 = icmp ne i32 %convergence.parent.token285, 0
  %2391 = and i1 %2390, %convergence.parent.present286
  br i1 %2391, label %convergence.cascade271, label %convergence.cascade.exit272

convergence.cascade.exit272:                      ; preds = %convergence.cascade271, %schedule.8
  %convergence.cascade.result287 = phi <8 x i1> [ %260, %schedule.8 ], [ %2385, %convergence.cascade271 ]
  %2392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result287)
  br i1 %2392, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit272
  %2393 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result287)
  %2394 = bitcast <8 x i1> %convergence.cascade.result287 to i8
  %2395 = call i8 @llvm.cttz.i8(i8 %2394, i1 false)
  %2396 = zext i8 %2395 to i32
  %2397 = select i1 %2393, i32 %2396, i32 0
  %2398 = load <8 x i64>, ptr %.slot68, align 64
  %2399 = select <8 x i1> %convergence.cascade.result287, <8 x i64> zeroinitializer, <8 x i64> %2398
  store <8 x i64> %2399, ptr %.slot68, align 64
  %2400 = load <8 x float>, ptr %.slot69, align 32
  %2401 = select <8 x i1> %convergence.cascade.result287, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2400
  store <8 x float> %2401, ptr %.slot69, align 32
  %2402 = load <8 x float>, ptr %.slot70, align 32
  %2403 = select <8 x i1> %convergence.cascade.result287, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2402
  store <8 x float> %2403, ptr %.slot70, align 32
  %2404 = load <8 x float>, ptr %.slot71, align 32
  %2405 = select <8 x i1> %convergence.cascade.result287, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2404
  store <8 x float> %2405, ptr %.slot71, align 32
  %2406 = load <8 x float>, ptr %.slot72, align 32
  %2407 = select <8 x i1> %convergence.cascade.result287, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2406
  store <8 x float> %2407, ptr %.slot72, align 32
  %2408 = load <8 x float>, ptr %.slot73, align 32
  %2409 = select <8 x i1> %convergence.cascade.result287, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2408
  store <8 x float> %2409, ptr %.slot73, align 32
  %2410 = load <8 x float>, ptr %.slot74, align 32
  %2411 = select <8 x i1> %convergence.cascade.result287, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2410
  store <8 x float> %2411, ptr %.slot74, align 32
  %2412 = load <8 x float>, ptr %.slot75, align 32
  %2413 = select <8 x i1> %convergence.cascade.result287, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2412
  store <8 x float> %2413, ptr %.slot75, align 32
  %2414 = load <8 x float>, ptr %.slot76, align 32
  %2415 = select <8 x i1> %convergence.cascade.result287, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2414
  store <8 x float> %2415, ptr %.slot76, align 32
  %2416 = load <8 x float>, ptr %.slot77, align 32
  %2417 = select <8 x i1> %convergence.cascade.result287, <8 x float> zeroinitializer, <8 x float> %2416
  store <8 x float> %2417, ptr %.slot77, align 32
  %2418 = load <8 x float>, ptr %.slot78, align 32
  %2419 = select <8 x i1> %convergence.cascade.result287, <8 x float> zeroinitializer, <8 x float> %2418
  store <8 x float> %2419, ptr %.slot78, align 32
  %2420 = load <8 x float>, ptr %.slot79, align 32
  %2421 = select <8 x i1> %convergence.cascade.result287, <8 x float> zeroinitializer, <8 x float> %2420
  store <8 x float> %2421, ptr %.slot79, align 32
  %2422 = load <8 x float>, ptr %.slot80, align 32
  %2423 = select <8 x i1> %convergence.cascade.result287, <8 x float> zeroinitializer, <8 x float> %2422
  store <8 x float> %2423, ptr %.slot80, align 32
  %2424 = load <8 x float>, ptr %.slot81, align 32
  %2425 = select <8 x i1> %convergence.cascade.result287, <8 x float> zeroinitializer, <8 x float> %2424
  store <8 x float> %2425, ptr %.slot81, align 32
  %2426 = load <8 x float>, ptr %.slot82, align 32
  %2427 = select <8 x i1> %convergence.cascade.result287, <8 x float> zeroinitializer, <8 x float> %2426
  store <8 x float> %2427, ptr %.slot82, align 32
  %2428 = load <8 x float>, ptr %.slot83, align 32
  %2429 = select <8 x i1> %convergence.cascade.result287, <8 x float> zeroinitializer, <8 x float> %2428
  store <8 x float> %2429, ptr %.slot83, align 32
  %2430 = load <8 x float>, ptr %.slot84, align 32
  %2431 = select <8 x i1> %convergence.cascade.result287, <8 x float> zeroinitializer, <8 x float> %2430
  store <8 x float> %2431, ptr %.slot84, align 32
  store <8 x i1> %convergence.cascade.result287, ptr %current.mask, align 1
  %2432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result287)
  br i1 %2432, label %schedule.9, label %scheduler.loop

varying.divergent289:                             ; preds = %schedule.9
  %2433 = load i32, ptr %current.token, align 4
  %2434 = icmp ne i32 %2433, 0
  %2435 = sub i32 %2433, 1
  %2436 = select i1 %2434, i32 %2435, i32 0
  %2437 = load i8, ptr %frame.active, align 1
  %2438 = trunc i32 %2436 to i8
  %2439 = shl i8 1, %2438
  %2440 = and i8 %2437, %2439
  %2441 = icmp ne i8 %2440, 0
  %2442 = load <8 x i32>, ptr %frame.static.id, align 32
  %2443 = extractelement <8 x i32> %2442, i32 %2436
  %2444 = icmp eq i32 %2443, 3
  %2445 = and i1 %2441, %2444
  %2446 = and i1 %2434, %2445
  %2447 = xor i1 %2446, true
  %2448 = and i1 true, %2447
  %2449 = xor i8 %2437, -1
  %2450 = icmp ne i8 %2449, 0
  %2451 = xor i1 %2450, true
  %2452 = and i1 %2448, %2451
  br i1 %2452, label %convergence.overflow.trap291, label %convergence.overflow.resume292

varying.coherent290:                              ; preds = %schedule.9
  br i1 %271, label %varying.coherent.true295, label %varying.coherent.false296

convergence.overflow.trap291:                     ; preds = %varying.divergent289
  call void @llvm.trap()
  unreachable

convergence.overflow.resume292:                   ; preds = %varying.divergent289
  %2453 = call i8 @llvm.cttz.i8(i8 %2449, i1 false)
  %2454 = zext i8 %2453 to i32
  %2455 = select i1 %2450, i32 %2454, i32 0
  %2456 = trunc i32 %2455 to i8
  %2457 = shl i8 1, %2456
  %2458 = or i8 %2437, %2457
  %2459 = select i1 %2448, i8 %2458, i8 %2437
  store i8 %2459, ptr %frame.active, align 1
  %2460 = load <8 x i32>, ptr %frame.static.id, align 32
  %2461 = extractelement <8 x i32> %2460, i32 %2455
  %2462 = select i1 %2448, i32 3, i32 %2461
  %2463 = load <8 x i32>, ptr %frame.static.id, align 32
  %2464 = insertelement <8 x i32> %2463, i32 %2462, i32 %2455
  store <8 x i32> %2464, ptr %frame.static.id, align 32
  %2465 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2466 = extractelement <8 x i32> %2465, i32 %2455
  %2467 = select i1 %2448, i32 %2433, i32 %2466
  %2468 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2469 = insertelement <8 x i32> %2468, i32 %2467, i32 %2455
  store <8 x i32> %2469, ptr %frame.parent.token, align 32
  %2470 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2455
  %2471 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2455
  %2472 = load <8 x i1>, ptr %2470, align 1
  %2473 = load <8 x i1>, ptr %2471, align 1
  %2474 = select i1 %2448, <8 x i1> %261, <8 x i1> %2472
  store <8 x i1> %2474, ptr %2470, align 1
  %2475 = select i1 %2448, <8 x i1> zeroinitializer, <8 x i1> %2473
  store <8 x i1> %2475, ptr %2471, align 1
  %2476 = add i32 %2455, 1
  %2477 = select i1 %2446, i32 %2433, i32 %2476
  %2478 = select i1 true, i32 %2477, i32 %2433
  store i32 %2478, ptr %current.token, align 4
  %2479 = load i32, ptr %current.token, align 4
  %2480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %268)
  %2481 = load i32, ptr %ready.count, align 4
  %2482 = icmp uge i32 %2481, 8
  %2483 = and i1 %2480, %2482
  br i1 %2483, label %ready.overflow.trap293, label %ready.overflow.resume294

ready.overflow.trap293:                           ; preds = %convergence.overflow.resume292
  call void @llvm.trap()
  unreachable

ready.overflow.resume294:                         ; preds = %convergence.overflow.resume292
  %2484 = select i1 %2480, i32 %2481, i32 0
  %2485 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2484
  %2486 = load <8 x i1>, ptr %2485, align 1
  %2487 = select i1 %2480, <8 x i1> %268, <8 x i1> %2486
  store <8 x i1> %2487, ptr %2485, align 1
  %2488 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2484
  %2489 = load i32, ptr %2488, align 4
  %2490 = select i1 %2480, i32 10, i32 %2489
  store i32 %2490, ptr %2488, align 4
  %2491 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2484
  %2492 = load i32, ptr %2491, align 4
  %2493 = select i1 %2480, i32 %2479, i32 %2492
  store i32 %2493, ptr %2491, align 4
  %2494 = add i32 %2481, 1
  %2495 = select i1 %2480, i32 %2494, i32 %2481
  store i32 %2495, ptr %ready.count, align 4
  %2496 = load <8 x i1>, ptr %runnable.mask, align 1
  %2497 = or <8 x i1> %2496, %268
  store <8 x i1> %2497, ptr %runnable.mask, align 1
  store <8 x i1> %270, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true295:                         ; preds = %varying.coherent290
  store <8 x i1> %261, ptr %current.mask, align 1
  %2498 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %261)
  br i1 %2498, label %schedule.10, label %scheduler.loop

varying.coherent.false296:                        ; preds = %varying.coherent290
  store <8 x i1> %261, ptr %current.mask, align 1
  %2499 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %261)
  br i1 %2499, label %schedule.102, label %scheduler.loop

varying.divergent299:                             ; preds = %schedule.11
  %2500 = load i32, ptr %current.token, align 4
  %2501 = icmp ne i32 %2500, 0
  %2502 = sub i32 %2500, 1
  %2503 = select i1 %2501, i32 %2502, i32 0
  %2504 = load i8, ptr %frame.active, align 1
  %2505 = trunc i32 %2503 to i8
  %2506 = shl i8 1, %2505
  %2507 = and i8 %2504, %2506
  %2508 = icmp ne i8 %2507, 0
  %2509 = load <8 x i32>, ptr %frame.static.id, align 32
  %2510 = extractelement <8 x i32> %2509, i32 %2503
  %2511 = icmp eq i32 %2510, 4
  %2512 = and i1 %2508, %2511
  %2513 = and i1 %2501, %2512
  %2514 = xor i1 %2513, true
  %2515 = and i1 true, %2514
  %2516 = xor i8 %2504, -1
  %2517 = icmp ne i8 %2516, 0
  %2518 = xor i1 %2517, true
  %2519 = and i1 %2515, %2518
  br i1 %2519, label %convergence.overflow.trap301, label %convergence.overflow.resume302

varying.coherent300:                              ; preds = %schedule.11
  br i1 %308, label %varying.coherent.true305, label %varying.coherent.false306

convergence.overflow.trap301:                     ; preds = %varying.divergent299
  call void @llvm.trap()
  unreachable

convergence.overflow.resume302:                   ; preds = %varying.divergent299
  %2520 = call i8 @llvm.cttz.i8(i8 %2516, i1 false)
  %2521 = zext i8 %2520 to i32
  %2522 = select i1 %2517, i32 %2521, i32 0
  %2523 = trunc i32 %2522 to i8
  %2524 = shl i8 1, %2523
  %2525 = or i8 %2504, %2524
  %2526 = select i1 %2515, i8 %2525, i8 %2504
  store i8 %2526, ptr %frame.active, align 1
  %2527 = load <8 x i32>, ptr %frame.static.id, align 32
  %2528 = extractelement <8 x i32> %2527, i32 %2522
  %2529 = select i1 %2515, i32 4, i32 %2528
  %2530 = load <8 x i32>, ptr %frame.static.id, align 32
  %2531 = insertelement <8 x i32> %2530, i32 %2529, i32 %2522
  store <8 x i32> %2531, ptr %frame.static.id, align 32
  %2532 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2533 = extractelement <8 x i32> %2532, i32 %2522
  %2534 = select i1 %2515, i32 %2500, i32 %2533
  %2535 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2536 = insertelement <8 x i32> %2535, i32 %2534, i32 %2522
  store <8 x i32> %2536, ptr %frame.parent.token, align 32
  %2537 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2522
  %2538 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2522
  %2539 = load <8 x i1>, ptr %2537, align 1
  %2540 = load <8 x i1>, ptr %2538, align 1
  %2541 = select i1 %2515, <8 x i1> %298, <8 x i1> %2539
  store <8 x i1> %2541, ptr %2537, align 1
  %2542 = select i1 %2515, <8 x i1> zeroinitializer, <8 x i1> %2540
  store <8 x i1> %2542, ptr %2538, align 1
  %2543 = add i32 %2522, 1
  %2544 = select i1 %2513, i32 %2500, i32 %2543
  %2545 = select i1 true, i32 %2544, i32 %2500
  store i32 %2545, ptr %current.token, align 4
  %2546 = load i32, ptr %current.token, align 4
  %2547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %305)
  %2548 = load i32, ptr %ready.count, align 4
  %2549 = icmp uge i32 %2548, 8
  %2550 = and i1 %2547, %2549
  br i1 %2550, label %ready.overflow.trap303, label %ready.overflow.resume304

ready.overflow.trap303:                           ; preds = %convergence.overflow.resume302
  call void @llvm.trap()
  unreachable

ready.overflow.resume304:                         ; preds = %convergence.overflow.resume302
  %2551 = select i1 %2547, i32 %2548, i32 0
  %2552 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2551
  %2553 = load <8 x i1>, ptr %2552, align 1
  %2554 = select i1 %2547, <8 x i1> %305, <8 x i1> %2553
  store <8 x i1> %2554, ptr %2552, align 1
  %2555 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2551
  %2556 = load i32, ptr %2555, align 4
  %2557 = select i1 %2547, i32 12, i32 %2556
  store i32 %2557, ptr %2555, align 4
  %2558 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2551
  %2559 = load i32, ptr %2558, align 4
  %2560 = select i1 %2547, i32 %2546, i32 %2559
  store i32 %2560, ptr %2558, align 4
  %2561 = add i32 %2548, 1
  %2562 = select i1 %2547, i32 %2561, i32 %2548
  store i32 %2562, ptr %ready.count, align 4
  %2563 = load <8 x i1>, ptr %runnable.mask, align 1
  %2564 = or <8 x i1> %2563, %305
  store <8 x i1> %2564, ptr %runnable.mask, align 1
  store <8 x i1> %307, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true305:                         ; preds = %varying.coherent300
  store <8 x i1> %298, ptr %current.mask, align 1
  %2565 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %298)
  br i1 %2565, label %schedule.12, label %scheduler.loop

varying.coherent.false306:                        ; preds = %varying.coherent300
  store <8 x i1> %298, ptr %current.mask, align 1
  %2566 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %298)
  br i1 %2566, label %schedule.15, label %scheduler.loop

varying.divergent311:                             ; preds = %schedule.12
  %2567 = load i32, ptr %current.token, align 4
  %2568 = icmp ne i32 %2567, 0
  %2569 = sub i32 %2567, 1
  %2570 = select i1 %2568, i32 %2569, i32 0
  %2571 = load i8, ptr %frame.active, align 1
  %2572 = trunc i32 %2570 to i8
  %2573 = shl i8 1, %2572
  %2574 = and i8 %2571, %2573
  %2575 = icmp ne i8 %2574, 0
  %2576 = load <8 x i32>, ptr %frame.static.id, align 32
  %2577 = extractelement <8 x i32> %2576, i32 %2570
  %2578 = icmp eq i32 %2577, 5
  %2579 = and i1 %2575, %2578
  %2580 = and i1 %2568, %2579
  %2581 = xor i1 %2580, true
  %2582 = and i1 true, %2581
  %2583 = xor i8 %2571, -1
  %2584 = icmp ne i8 %2583, 0
  %2585 = xor i1 %2584, true
  %2586 = and i1 %2582, %2585
  br i1 %2586, label %convergence.overflow.trap313, label %convergence.overflow.resume314

varying.coherent312:                              ; preds = %schedule.12
  br i1 %340, label %varying.coherent.true317, label %varying.coherent.false318

convergence.overflow.trap313:                     ; preds = %varying.divergent311
  call void @llvm.trap()
  unreachable

convergence.overflow.resume314:                   ; preds = %varying.divergent311
  %2587 = call i8 @llvm.cttz.i8(i8 %2583, i1 false)
  %2588 = zext i8 %2587 to i32
  %2589 = select i1 %2584, i32 %2588, i32 0
  %2590 = trunc i32 %2589 to i8
  %2591 = shl i8 1, %2590
  %2592 = or i8 %2571, %2591
  %2593 = select i1 %2582, i8 %2592, i8 %2571
  store i8 %2593, ptr %frame.active, align 1
  %2594 = load <8 x i32>, ptr %frame.static.id, align 32
  %2595 = extractelement <8 x i32> %2594, i32 %2589
  %2596 = select i1 %2582, i32 5, i32 %2595
  %2597 = load <8 x i32>, ptr %frame.static.id, align 32
  %2598 = insertelement <8 x i32> %2597, i32 %2596, i32 %2589
  store <8 x i32> %2598, ptr %frame.static.id, align 32
  %2599 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2600 = extractelement <8 x i32> %2599, i32 %2589
  %2601 = select i1 %2582, i32 %2567, i32 %2600
  %2602 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2603 = insertelement <8 x i32> %2602, i32 %2601, i32 %2589
  store <8 x i32> %2603, ptr %frame.parent.token, align 32
  %2604 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2589
  %2605 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2589
  %2606 = load <8 x i1>, ptr %2604, align 1
  %2607 = load <8 x i1>, ptr %2605, align 1
  %2608 = select i1 %2582, <8 x i1> %311, <8 x i1> %2606
  store <8 x i1> %2608, ptr %2604, align 1
  %2609 = select i1 %2582, <8 x i1> zeroinitializer, <8 x i1> %2607
  store <8 x i1> %2609, ptr %2605, align 1
  %2610 = add i32 %2589, 1
  %2611 = select i1 %2580, i32 %2567, i32 %2610
  %2612 = select i1 true, i32 %2611, i32 %2567
  store i32 %2612, ptr %current.token, align 4
  %2613 = load <8 x float>, ptr %.slot89, align 32
  %2614 = select <8 x i1> %339, <8 x float> zeroinitializer, <8 x float> %2613
  store <8 x float> %2614, ptr %.slot89, align 32
  %2615 = load i32, ptr %current.token, align 4
  %2616 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %337)
  %2617 = load i32, ptr %ready.count, align 4
  %2618 = icmp uge i32 %2617, 8
  %2619 = and i1 %2616, %2618
  br i1 %2619, label %ready.overflow.trap315, label %ready.overflow.resume316

ready.overflow.trap315:                           ; preds = %convergence.overflow.resume314
  call void @llvm.trap()
  unreachable

ready.overflow.resume316:                         ; preds = %convergence.overflow.resume314
  %2620 = select i1 %2616, i32 %2617, i32 0
  %2621 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2620
  %2622 = load <8 x i1>, ptr %2621, align 1
  %2623 = select i1 %2616, <8 x i1> %337, <8 x i1> %2622
  store <8 x i1> %2623, ptr %2621, align 1
  %2624 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2620
  %2625 = load i32, ptr %2624, align 4
  %2626 = select i1 %2616, i32 13, i32 %2625
  store i32 %2626, ptr %2624, align 4
  %2627 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2620
  %2628 = load i32, ptr %2627, align 4
  %2629 = select i1 %2616, i32 %2615, i32 %2628
  store i32 %2629, ptr %2627, align 4
  %2630 = add i32 %2617, 1
  %2631 = select i1 %2616, i32 %2630, i32 %2617
  store i32 %2631, ptr %ready.count, align 4
  %2632 = load <8 x i1>, ptr %runnable.mask, align 1
  %2633 = or <8 x i1> %2632, %337
  store <8 x i1> %2633, ptr %runnable.mask, align 1
  store <8 x i1> %339, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true317:                         ; preds = %varying.coherent312
  store <8 x i1> %311, ptr %current.mask, align 1
  %2634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %311)
  br i1 %2634, label %schedule.13, label %scheduler.loop

varying.coherent.false318:                        ; preds = %varying.coherent312
  %2635 = load <8 x float>, ptr %.slot89, align 32
  %2636 = select <8 x i1> %311, <8 x float> zeroinitializer, <8 x float> %2635
  store <8 x float> %2636, ptr %.slot89, align 32
  store <8 x i1> %311, ptr %current.mask, align 1
  %2637 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %311)
  br i1 %2637, label %schedule.14, label %scheduler.loop

convergence.cascade320:                           ; preds = %convergence.cascade320, %schedule.14
  %convergence.cascade.flow324 = phi <8 x i1> [ %356, %schedule.14 ], [ %2680, %convergence.cascade320 ]
  %convergence.cascade.depth325 = phi i32 [ 0, %schedule.14 ], [ %2681, %convergence.cascade320 ]
  %2638 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow324)
  %2639 = load i32, ptr %current.token, align 4
  %2640 = icmp ne i32 %2639, 0
  %2641 = and i1 %2638, %2640
  %2642 = sub i32 %2639, 1
  %2643 = select i1 %2641, i32 %2642, i32 0
  %2644 = load i8, ptr %frame.active, align 1
  %2645 = trunc i32 %2643 to i8
  %2646 = shl i8 1, %2645
  %2647 = and i8 %2644, %2646
  %2648 = icmp ne i8 %2647, 0
  %2649 = load <8 x i32>, ptr %frame.static.id, align 32
  %2650 = extractelement <8 x i32> %2649, i32 %2643
  %convergence.target.pointer326 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2650
  %convergence.dynamic.target327 = load i32, ptr %convergence.target.pointer326, align 4
  %2651 = icmp eq i32 %convergence.dynamic.target327, 14
  %2652 = and i1 %2648, %2651
  %2653 = and i1 %2641, %2652
  %2654 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2643
  %2655 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2643
  %2656 = load <8 x i1>, ptr %2654, align 1
  %2657 = load <8 x i1>, ptr %2655, align 1
  %2658 = or <8 x i1> %2657, %convergence.cascade.flow324
  %2659 = load <8 x i1>, ptr %live.mask, align 1
  %2660 = and <8 x i1> %2656, %2659
  %2661 = icmp eq <8 x i1> %2658, %2660
  %2662 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2661)
  %2663 = and i1 %2653, %2662
  %2664 = select i1 %2663, <8 x i1> zeroinitializer, <8 x i1> %2658
  %2665 = select i1 %2653, <8 x i1> %2664, <8 x i1> %2657
  store <8 x i1> %2665, ptr %2655, align 1
  %2666 = select i1 %2663, <8 x i1> zeroinitializer, <8 x i1> %2656
  store <8 x i1> %2666, ptr %2654, align 1
  %2667 = trunc i32 %2643 to i8
  %2668 = shl i8 1, %2667
  %2669 = xor i8 %2668, -1
  %2670 = and i8 %2644, %2669
  %2671 = select i1 %2663, i8 %2670, i8 %2644
  store i8 %2671, ptr %frame.active, align 1
  %.splatinsert328 = insertelement <8 x i1> poison, i1 %2653, i64 0
  %.splat329 = shufflevector <8 x i1> %.splatinsert328, <8 x i1> poison, <8 x i32> zeroinitializer
  %2672 = and <8 x i1> %convergence.cascade.flow324, %.splat329
  %2673 = load <8 x i1>, ptr %runnable.mask, align 1
  %2674 = xor <8 x i1> %2672, splat (i1 true)
  %2675 = and <8 x i1> %2673, %2674
  store <8 x i1> %2675, ptr %runnable.mask, align 1
  %.splatinsert330 = insertelement <8 x i1> poison, i1 %2663, i64 0
  %.splat331 = shufflevector <8 x i1> %.splatinsert330, <8 x i1> poison, <8 x i32> zeroinitializer
  %2676 = select <8 x i1> %.splat331, <8 x i1> %2658, <8 x i1> zeroinitializer
  %2677 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2678 = extractelement <8 x i32> %2677, i32 %2643
  %2679 = select i1 %2663, i32 %2678, i32 %2639
  store i32 %2679, ptr %current.token, align 4
  %.splatinsert332 = insertelement <8 x i1> poison, i1 %2653, i64 0
  %.splat333 = shufflevector <8 x i1> %.splatinsert332, <8 x i1> poison, <8 x i32> zeroinitializer
  %2680 = select <8 x i1> %.splat333, <8 x i1> %2676, <8 x i1> %convergence.cascade.flow324
  %2681 = add i32 %convergence.cascade.depth325, 1
  %2682 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2680)
  %2683 = icmp ult i32 %2681, 8
  %2684 = and i1 %2682, %2683
  %2685 = and i1 %2653, %2684
  %convergence.parent.token334 = load i32, ptr %current.token, align 4
  %convergence.parent.present335 = icmp ne i32 %convergence.parent.token334, 0
  %2686 = and i1 %2685, %convergence.parent.present335
  br i1 %2686, label %convergence.cascade320, label %convergence.cascade.exit321

convergence.cascade.exit321:                      ; preds = %convergence.cascade320, %schedule.14
  %convergence.cascade.result336 = phi <8 x i1> [ %356, %schedule.14 ], [ %2680, %convergence.cascade320 ]
  %2687 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result336)
  br i1 %2687, label %convergence.target.14.ready, label %scheduler.loop

convergence.target.14.ready:                      ; preds = %convergence.cascade.exit321
  %2688 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result336)
  %2689 = bitcast <8 x i1> %convergence.cascade.result336 to i8
  %2690 = call i8 @llvm.cttz.i8(i8 %2689, i1 false)
  %2691 = zext i8 %2690 to i32
  %2692 = select i1 %2688, i32 %2691, i32 0
  %tile_snapshot.spill.load337 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill86, align 64
  %2693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load337, 0
  %2694 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load337, 1
  %.state338 = load <8 x i64>, ptr %.slot87, align 64
  %2695 = mul <8 x i64> %.state338, splat (i64 32)
  %2696 = add <8 x i64> %2694, %2695
  %2697 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2693, 0
  %2698 = insertvalue { <8 x ptr>, <8 x i64> } %2697, <8 x i64> %2696, 1
  %.state339 = load <8 x float>, ptr %.slot89, align 32
  %2699 = extractvalue { <8 x ptr>, <8 x i64> } %2698, 0
  %2700 = extractvalue { <8 x ptr>, <8 x i64> } %2698, 1
  %2701 = getelementptr i8, <8 x ptr> %2699, <8 x i64> %2700
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state339, <8 x ptr> align 1 %2701, <8 x i1> %convergence.cascade.result336)
  %.state340 = load <8 x i64>, ptr %.slot87, align 64
  %2702 = add <8 x i64> %.state340, splat (i64 1)
  %2703 = load <8 x i64>, ptr %.slot87, align 64
  %2704 = select <8 x i1> %convergence.cascade.result336, <8 x i64> %2702, <8 x i64> %2703
  store <8 x i64> %2704, ptr %.slot87, align 64
  store <8 x i1> %convergence.cascade.result336, ptr %current.mask, align 1
  %2705 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result336)
  br i1 %2705, label %schedule.11, label %scheduler.loop

convergence.cascade341:                           ; preds = %convergence.cascade341, %schedule.15
  %convergence.cascade.flow345 = phi <8 x i1> [ %357, %schedule.15 ], [ %2748, %convergence.cascade341 ]
  %convergence.cascade.depth346 = phi i32 [ 0, %schedule.15 ], [ %2749, %convergence.cascade341 ]
  %2706 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow345)
  %2707 = load i32, ptr %current.token, align 4
  %2708 = icmp ne i32 %2707, 0
  %2709 = and i1 %2706, %2708
  %2710 = sub i32 %2707, 1
  %2711 = select i1 %2709, i32 %2710, i32 0
  %2712 = load i8, ptr %frame.active, align 1
  %2713 = trunc i32 %2711 to i8
  %2714 = shl i8 1, %2713
  %2715 = and i8 %2712, %2714
  %2716 = icmp ne i8 %2715, 0
  %2717 = load <8 x i32>, ptr %frame.static.id, align 32
  %2718 = extractelement <8 x i32> %2717, i32 %2711
  %convergence.target.pointer347 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2718
  %convergence.dynamic.target348 = load i32, ptr %convergence.target.pointer347, align 4
  %2719 = icmp eq i32 %convergence.dynamic.target348, 15
  %2720 = and i1 %2716, %2719
  %2721 = and i1 %2709, %2720
  %2722 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2711
  %2723 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2711
  %2724 = load <8 x i1>, ptr %2722, align 1
  %2725 = load <8 x i1>, ptr %2723, align 1
  %2726 = or <8 x i1> %2725, %convergence.cascade.flow345
  %2727 = load <8 x i1>, ptr %live.mask, align 1
  %2728 = and <8 x i1> %2724, %2727
  %2729 = icmp eq <8 x i1> %2726, %2728
  %2730 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2729)
  %2731 = and i1 %2721, %2730
  %2732 = select i1 %2731, <8 x i1> zeroinitializer, <8 x i1> %2726
  %2733 = select i1 %2721, <8 x i1> %2732, <8 x i1> %2725
  store <8 x i1> %2733, ptr %2723, align 1
  %2734 = select i1 %2731, <8 x i1> zeroinitializer, <8 x i1> %2724
  store <8 x i1> %2734, ptr %2722, align 1
  %2735 = trunc i32 %2711 to i8
  %2736 = shl i8 1, %2735
  %2737 = xor i8 %2736, -1
  %2738 = and i8 %2712, %2737
  %2739 = select i1 %2731, i8 %2738, i8 %2712
  store i8 %2739, ptr %frame.active, align 1
  %.splatinsert349 = insertelement <8 x i1> poison, i1 %2721, i64 0
  %.splat350 = shufflevector <8 x i1> %.splatinsert349, <8 x i1> poison, <8 x i32> zeroinitializer
  %2740 = and <8 x i1> %convergence.cascade.flow345, %.splat350
  %2741 = load <8 x i1>, ptr %runnable.mask, align 1
  %2742 = xor <8 x i1> %2740, splat (i1 true)
  %2743 = and <8 x i1> %2741, %2742
  store <8 x i1> %2743, ptr %runnable.mask, align 1
  %.splatinsert351 = insertelement <8 x i1> poison, i1 %2731, i64 0
  %.splat352 = shufflevector <8 x i1> %.splatinsert351, <8 x i1> poison, <8 x i32> zeroinitializer
  %2744 = select <8 x i1> %.splat352, <8 x i1> %2726, <8 x i1> zeroinitializer
  %2745 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2746 = extractelement <8 x i32> %2745, i32 %2711
  %2747 = select i1 %2731, i32 %2746, i32 %2707
  store i32 %2747, ptr %current.token, align 4
  %.splatinsert353 = insertelement <8 x i1> poison, i1 %2721, i64 0
  %.splat354 = shufflevector <8 x i1> %.splatinsert353, <8 x i1> poison, <8 x i32> zeroinitializer
  %2748 = select <8 x i1> %.splat354, <8 x i1> %2744, <8 x i1> %convergence.cascade.flow345
  %2749 = add i32 %convergence.cascade.depth346, 1
  %2750 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2748)
  %2751 = icmp ult i32 %2749, 8
  %2752 = and i1 %2750, %2751
  %2753 = and i1 %2721, %2752
  %convergence.parent.token355 = load i32, ptr %current.token, align 4
  %convergence.parent.present356 = icmp ne i32 %convergence.parent.token355, 0
  %2754 = and i1 %2753, %convergence.parent.present356
  br i1 %2754, label %convergence.cascade341, label %convergence.cascade.exit342

convergence.cascade.exit342:                      ; preds = %convergence.cascade341, %schedule.15
  %convergence.cascade.result357 = phi <8 x i1> [ %357, %schedule.15 ], [ %2748, %convergence.cascade341 ]
  %2755 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result357)
  br i1 %2755, label %convergence.target.15.ready, label %scheduler.loop

convergence.target.15.ready:                      ; preds = %convergence.cascade.exit342
  %2756 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result357)
  %2757 = bitcast <8 x i1> %convergence.cascade.result357 to i8
  %2758 = call i8 @llvm.cttz.i8(i8 %2757, i1 false)
  %2759 = zext i8 %2758 to i32
  %2760 = select i1 %2756, i32 %2759, i32 0
  %2761 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %2762 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2763 = extractvalue { <8 x ptr>, <8 x i64> } %2761, 0
  %2764 = select <8 x i1> %convergence.cascade.result357, <8 x ptr> %2762, <8 x ptr> %2763
  %2765 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %2766 = extractvalue { <8 x ptr>, <8 x i64> } %2761, 1
  %2767 = select <8 x i1> %convergence.cascade.result357, <8 x i64> %2765, <8 x i64> %2766
  %2768 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2764, 0
  %2769 = insertvalue { <8 x ptr>, <8 x i64> } %2768, <8 x i64> %2767, 1
  store { <8 x ptr>, <8 x i64> } %2769, ptr %tile_snapshot.spill90, align 64
  %2770 = load <8 x i64>, ptr %.slot91, align 64
  %2771 = select <8 x i1> %convergence.cascade.result357, <8 x i64> zeroinitializer, <8 x i64> %2770
  store <8 x i64> %2771, ptr %.slot91, align 64
  store <8 x i1> %convergence.cascade.result357, ptr %current.mask, align 1
  %2772 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result357)
  br i1 %2772, label %schedule.16, label %scheduler.loop

varying.divergent359:                             ; preds = %schedule.16
  %2773 = load i32, ptr %current.token, align 4
  %2774 = icmp ne i32 %2773, 0
  %2775 = sub i32 %2773, 1
  %2776 = select i1 %2774, i32 %2775, i32 0
  %2777 = load i8, ptr %frame.active, align 1
  %2778 = trunc i32 %2776 to i8
  %2779 = shl i8 1, %2778
  %2780 = and i8 %2777, %2779
  %2781 = icmp ne i8 %2780, 0
  %2782 = load <8 x i32>, ptr %frame.static.id, align 32
  %2783 = extractelement <8 x i32> %2782, i32 %2776
  %2784 = icmp eq i32 %2783, 6
  %2785 = and i1 %2781, %2784
  %2786 = and i1 %2774, %2785
  %2787 = xor i1 %2786, true
  %2788 = and i1 true, %2787
  %2789 = xor i8 %2777, -1
  %2790 = icmp ne i8 %2789, 0
  %2791 = xor i1 %2790, true
  %2792 = and i1 %2788, %2791
  br i1 %2792, label %convergence.overflow.trap361, label %convergence.overflow.resume362

varying.coherent360:                              ; preds = %schedule.16
  br i1 %368, label %varying.coherent.true365, label %varying.coherent.false366

convergence.overflow.trap361:                     ; preds = %varying.divergent359
  call void @llvm.trap()
  unreachable

convergence.overflow.resume362:                   ; preds = %varying.divergent359
  %2793 = call i8 @llvm.cttz.i8(i8 %2789, i1 false)
  %2794 = zext i8 %2793 to i32
  %2795 = select i1 %2790, i32 %2794, i32 0
  %2796 = trunc i32 %2795 to i8
  %2797 = shl i8 1, %2796
  %2798 = or i8 %2777, %2797
  %2799 = select i1 %2788, i8 %2798, i8 %2777
  store i8 %2799, ptr %frame.active, align 1
  %2800 = load <8 x i32>, ptr %frame.static.id, align 32
  %2801 = extractelement <8 x i32> %2800, i32 %2795
  %2802 = select i1 %2788, i32 6, i32 %2801
  %2803 = load <8 x i32>, ptr %frame.static.id, align 32
  %2804 = insertelement <8 x i32> %2803, i32 %2802, i32 %2795
  store <8 x i32> %2804, ptr %frame.static.id, align 32
  %2805 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2806 = extractelement <8 x i32> %2805, i32 %2795
  %2807 = select i1 %2788, i32 %2773, i32 %2806
  %2808 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2809 = insertelement <8 x i32> %2808, i32 %2807, i32 %2795
  store <8 x i32> %2809, ptr %frame.parent.token, align 32
  %2810 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2795
  %2811 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2795
  %2812 = load <8 x i1>, ptr %2810, align 1
  %2813 = load <8 x i1>, ptr %2811, align 1
  %2814 = select i1 %2788, <8 x i1> %358, <8 x i1> %2812
  store <8 x i1> %2814, ptr %2810, align 1
  %2815 = select i1 %2788, <8 x i1> zeroinitializer, <8 x i1> %2813
  store <8 x i1> %2815, ptr %2811, align 1
  %2816 = add i32 %2795, 1
  %2817 = select i1 %2786, i32 %2773, i32 %2816
  %2818 = select i1 true, i32 %2817, i32 %2773
  store i32 %2818, ptr %current.token, align 4
  %2819 = load i32, ptr %current.token, align 4
  %2820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %365)
  %2821 = load i32, ptr %ready.count, align 4
  %2822 = icmp uge i32 %2821, 8
  %2823 = and i1 %2820, %2822
  br i1 %2823, label %ready.overflow.trap363, label %ready.overflow.resume364

ready.overflow.trap363:                           ; preds = %convergence.overflow.resume362
  call void @llvm.trap()
  unreachable

ready.overflow.resume364:                         ; preds = %convergence.overflow.resume362
  %2824 = select i1 %2820, i32 %2821, i32 0
  %2825 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2824
  %2826 = load <8 x i1>, ptr %2825, align 1
  %2827 = select i1 %2820, <8 x i1> %365, <8 x i1> %2826
  store <8 x i1> %2827, ptr %2825, align 1
  %2828 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2824
  %2829 = load i32, ptr %2828, align 4
  %2830 = select i1 %2820, i32 17, i32 %2829
  store i32 %2830, ptr %2828, align 4
  %2831 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2824
  %2832 = load i32, ptr %2831, align 4
  %2833 = select i1 %2820, i32 %2819, i32 %2832
  store i32 %2833, ptr %2831, align 4
  %2834 = add i32 %2821, 1
  %2835 = select i1 %2820, i32 %2834, i32 %2821
  store i32 %2835, ptr %ready.count, align 4
  %2836 = load <8 x i1>, ptr %runnable.mask, align 1
  %2837 = or <8 x i1> %2836, %365
  store <8 x i1> %2837, ptr %runnable.mask, align 1
  store <8 x i1> %367, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true365:                         ; preds = %varying.coherent360
  store <8 x i1> %358, ptr %current.mask, align 1
  %2838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %358)
  br i1 %2838, label %schedule.17, label %scheduler.loop

varying.coherent.false366:                        ; preds = %varying.coherent360
  store <8 x i1> %358, ptr %current.mask, align 1
  %2839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %358)
  br i1 %2839, label %schedule.20, label %scheduler.loop

varying.divergent371:                             ; preds = %schedule.17
  %2840 = load i32, ptr %current.token, align 4
  %2841 = icmp ne i32 %2840, 0
  %2842 = sub i32 %2840, 1
  %2843 = select i1 %2841, i32 %2842, i32 0
  %2844 = load i8, ptr %frame.active, align 1
  %2845 = trunc i32 %2843 to i8
  %2846 = shl i8 1, %2845
  %2847 = and i8 %2844, %2846
  %2848 = icmp ne i8 %2847, 0
  %2849 = load <8 x i32>, ptr %frame.static.id, align 32
  %2850 = extractelement <8 x i32> %2849, i32 %2843
  %2851 = icmp eq i32 %2850, 7
  %2852 = and i1 %2848, %2851
  %2853 = and i1 %2841, %2852
  %2854 = xor i1 %2853, true
  %2855 = and i1 true, %2854
  %2856 = xor i8 %2844, -1
  %2857 = icmp ne i8 %2856, 0
  %2858 = xor i1 %2857, true
  %2859 = and i1 %2855, %2858
  br i1 %2859, label %convergence.overflow.trap373, label %convergence.overflow.resume374

varying.coherent372:                              ; preds = %schedule.17
  br i1 %400, label %varying.coherent.true377, label %varying.coherent.false378

convergence.overflow.trap373:                     ; preds = %varying.divergent371
  call void @llvm.trap()
  unreachable

convergence.overflow.resume374:                   ; preds = %varying.divergent371
  %2860 = call i8 @llvm.cttz.i8(i8 %2856, i1 false)
  %2861 = zext i8 %2860 to i32
  %2862 = select i1 %2857, i32 %2861, i32 0
  %2863 = trunc i32 %2862 to i8
  %2864 = shl i8 1, %2863
  %2865 = or i8 %2844, %2864
  %2866 = select i1 %2855, i8 %2865, i8 %2844
  store i8 %2866, ptr %frame.active, align 1
  %2867 = load <8 x i32>, ptr %frame.static.id, align 32
  %2868 = extractelement <8 x i32> %2867, i32 %2862
  %2869 = select i1 %2855, i32 7, i32 %2868
  %2870 = load <8 x i32>, ptr %frame.static.id, align 32
  %2871 = insertelement <8 x i32> %2870, i32 %2869, i32 %2862
  store <8 x i32> %2871, ptr %frame.static.id, align 32
  %2872 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2873 = extractelement <8 x i32> %2872, i32 %2862
  %2874 = select i1 %2855, i32 %2840, i32 %2873
  %2875 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2876 = insertelement <8 x i32> %2875, i32 %2874, i32 %2862
  store <8 x i32> %2876, ptr %frame.parent.token, align 32
  %2877 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2862
  %2878 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2862
  %2879 = load <8 x i1>, ptr %2877, align 1
  %2880 = load <8 x i1>, ptr %2878, align 1
  %2881 = select i1 %2855, <8 x i1> %371, <8 x i1> %2879
  store <8 x i1> %2881, ptr %2877, align 1
  %2882 = select i1 %2855, <8 x i1> zeroinitializer, <8 x i1> %2880
  store <8 x i1> %2882, ptr %2878, align 1
  %2883 = add i32 %2862, 1
  %2884 = select i1 %2853, i32 %2840, i32 %2883
  %2885 = select i1 true, i32 %2884, i32 %2840
  store i32 %2885, ptr %current.token, align 4
  %2886 = load <8 x float>, ptr %.slot93, align 32
  %2887 = select <8 x i1> %399, <8 x float> zeroinitializer, <8 x float> %2886
  store <8 x float> %2887, ptr %.slot93, align 32
  %2888 = load i32, ptr %current.token, align 4
  %2889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %397)
  %2890 = load i32, ptr %ready.count, align 4
  %2891 = icmp uge i32 %2890, 8
  %2892 = and i1 %2889, %2891
  br i1 %2892, label %ready.overflow.trap375, label %ready.overflow.resume376

ready.overflow.trap375:                           ; preds = %convergence.overflow.resume374
  call void @llvm.trap()
  unreachable

ready.overflow.resume376:                         ; preds = %convergence.overflow.resume374
  %2893 = select i1 %2889, i32 %2890, i32 0
  %2894 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2893
  %2895 = load <8 x i1>, ptr %2894, align 1
  %2896 = select i1 %2889, <8 x i1> %397, <8 x i1> %2895
  store <8 x i1> %2896, ptr %2894, align 1
  %2897 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2893
  %2898 = load i32, ptr %2897, align 4
  %2899 = select i1 %2889, i32 18, i32 %2898
  store i32 %2899, ptr %2897, align 4
  %2900 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2893
  %2901 = load i32, ptr %2900, align 4
  %2902 = select i1 %2889, i32 %2888, i32 %2901
  store i32 %2902, ptr %2900, align 4
  %2903 = add i32 %2890, 1
  %2904 = select i1 %2889, i32 %2903, i32 %2890
  store i32 %2904, ptr %ready.count, align 4
  %2905 = load <8 x i1>, ptr %runnable.mask, align 1
  %2906 = or <8 x i1> %2905, %397
  store <8 x i1> %2906, ptr %runnable.mask, align 1
  store <8 x i1> %399, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true377:                         ; preds = %varying.coherent372
  store <8 x i1> %371, ptr %current.mask, align 1
  %2907 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  br i1 %2907, label %schedule.18, label %scheduler.loop

varying.coherent.false378:                        ; preds = %varying.coherent372
  %2908 = load <8 x float>, ptr %.slot93, align 32
  %2909 = select <8 x i1> %371, <8 x float> zeroinitializer, <8 x float> %2908
  store <8 x float> %2909, ptr %.slot93, align 32
  store <8 x i1> %371, ptr %current.mask, align 1
  %2910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  br i1 %2910, label %schedule.19, label %scheduler.loop

convergence.cascade380:                           ; preds = %convergence.cascade380, %schedule.19
  %convergence.cascade.flow384 = phi <8 x i1> [ %416, %schedule.19 ], [ %2953, %convergence.cascade380 ]
  %convergence.cascade.depth385 = phi i32 [ 0, %schedule.19 ], [ %2954, %convergence.cascade380 ]
  %2911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow384)
  %2912 = load i32, ptr %current.token, align 4
  %2913 = icmp ne i32 %2912, 0
  %2914 = and i1 %2911, %2913
  %2915 = sub i32 %2912, 1
  %2916 = select i1 %2914, i32 %2915, i32 0
  %2917 = load i8, ptr %frame.active, align 1
  %2918 = trunc i32 %2916 to i8
  %2919 = shl i8 1, %2918
  %2920 = and i8 %2917, %2919
  %2921 = icmp ne i8 %2920, 0
  %2922 = load <8 x i32>, ptr %frame.static.id, align 32
  %2923 = extractelement <8 x i32> %2922, i32 %2916
  %convergence.target.pointer386 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2923
  %convergence.dynamic.target387 = load i32, ptr %convergence.target.pointer386, align 4
  %2924 = icmp eq i32 %convergence.dynamic.target387, 19
  %2925 = and i1 %2921, %2924
  %2926 = and i1 %2914, %2925
  %2927 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2916
  %2928 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2916
  %2929 = load <8 x i1>, ptr %2927, align 1
  %2930 = load <8 x i1>, ptr %2928, align 1
  %2931 = or <8 x i1> %2930, %convergence.cascade.flow384
  %2932 = load <8 x i1>, ptr %live.mask, align 1
  %2933 = and <8 x i1> %2929, %2932
  %2934 = icmp eq <8 x i1> %2931, %2933
  %2935 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2934)
  %2936 = and i1 %2926, %2935
  %2937 = select i1 %2936, <8 x i1> zeroinitializer, <8 x i1> %2931
  %2938 = select i1 %2926, <8 x i1> %2937, <8 x i1> %2930
  store <8 x i1> %2938, ptr %2928, align 1
  %2939 = select i1 %2936, <8 x i1> zeroinitializer, <8 x i1> %2929
  store <8 x i1> %2939, ptr %2927, align 1
  %2940 = trunc i32 %2916 to i8
  %2941 = shl i8 1, %2940
  %2942 = xor i8 %2941, -1
  %2943 = and i8 %2917, %2942
  %2944 = select i1 %2936, i8 %2943, i8 %2917
  store i8 %2944, ptr %frame.active, align 1
  %.splatinsert388 = insertelement <8 x i1> poison, i1 %2926, i64 0
  %.splat389 = shufflevector <8 x i1> %.splatinsert388, <8 x i1> poison, <8 x i32> zeroinitializer
  %2945 = and <8 x i1> %convergence.cascade.flow384, %.splat389
  %2946 = load <8 x i1>, ptr %runnable.mask, align 1
  %2947 = xor <8 x i1> %2945, splat (i1 true)
  %2948 = and <8 x i1> %2946, %2947
  store <8 x i1> %2948, ptr %runnable.mask, align 1
  %.splatinsert390 = insertelement <8 x i1> poison, i1 %2936, i64 0
  %.splat391 = shufflevector <8 x i1> %.splatinsert390, <8 x i1> poison, <8 x i32> zeroinitializer
  %2949 = select <8 x i1> %.splat391, <8 x i1> %2931, <8 x i1> zeroinitializer
  %2950 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2951 = extractelement <8 x i32> %2950, i32 %2916
  %2952 = select i1 %2936, i32 %2951, i32 %2912
  store i32 %2952, ptr %current.token, align 4
  %.splatinsert392 = insertelement <8 x i1> poison, i1 %2926, i64 0
  %.splat393 = shufflevector <8 x i1> %.splatinsert392, <8 x i1> poison, <8 x i32> zeroinitializer
  %2953 = select <8 x i1> %.splat393, <8 x i1> %2949, <8 x i1> %convergence.cascade.flow384
  %2954 = add i32 %convergence.cascade.depth385, 1
  %2955 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2953)
  %2956 = icmp ult i32 %2954, 8
  %2957 = and i1 %2955, %2956
  %2958 = and i1 %2926, %2957
  %convergence.parent.token394 = load i32, ptr %current.token, align 4
  %convergence.parent.present395 = icmp ne i32 %convergence.parent.token394, 0
  %2959 = and i1 %2958, %convergence.parent.present395
  br i1 %2959, label %convergence.cascade380, label %convergence.cascade.exit381

convergence.cascade.exit381:                      ; preds = %convergence.cascade380, %schedule.19
  %convergence.cascade.result396 = phi <8 x i1> [ %416, %schedule.19 ], [ %2953, %convergence.cascade380 ]
  %2960 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result396)
  br i1 %2960, label %convergence.target.19.ready, label %scheduler.loop

convergence.target.19.ready:                      ; preds = %convergence.cascade.exit381
  %2961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result396)
  %2962 = bitcast <8 x i1> %convergence.cascade.result396 to i8
  %2963 = call i8 @llvm.cttz.i8(i8 %2962, i1 false)
  %2964 = zext i8 %2963 to i32
  %2965 = select i1 %2961, i32 %2964, i32 0
  %tile_snapshot.spill.load397 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %2966 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load397, 0
  %2967 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load397, 1
  %.state398 = load <8 x i64>, ptr %.slot91, align 64
  %2968 = mul <8 x i64> %.state398, splat (i64 32)
  %2969 = add <8 x i64> %2967, %2968
  %2970 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2966, 0
  %2971 = insertvalue { <8 x ptr>, <8 x i64> } %2970, <8 x i64> %2969, 1
  %.state399 = load <8 x float>, ptr %.slot93, align 32
  %2972 = extractvalue { <8 x ptr>, <8 x i64> } %2971, 0
  %2973 = extractvalue { <8 x ptr>, <8 x i64> } %2971, 1
  %2974 = getelementptr i8, <8 x ptr> %2972, <8 x i64> %2973
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state399, <8 x ptr> align 1 %2974, <8 x i1> %convergence.cascade.result396)
  %.state400 = load <8 x i64>, ptr %.slot91, align 64
  %2975 = add <8 x i64> %.state400, splat (i64 1)
  %2976 = load <8 x i64>, ptr %.slot91, align 64
  %2977 = select <8 x i1> %convergence.cascade.result396, <8 x i64> %2975, <8 x i64> %2976
  store <8 x i64> %2977, ptr %.slot91, align 64
  store <8 x i1> %convergence.cascade.result396, ptr %current.mask, align 1
  %2978 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result396)
  br i1 %2978, label %schedule.16, label %scheduler.loop

convergence.cascade401:                           ; preds = %convergence.cascade401, %schedule.20
  %convergence.cascade.flow405 = phi <8 x i1> [ %417, %schedule.20 ], [ %3021, %convergence.cascade401 ]
  %convergence.cascade.depth406 = phi i32 [ 0, %schedule.20 ], [ %3022, %convergence.cascade401 ]
  %2979 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow405)
  %2980 = load i32, ptr %current.token, align 4
  %2981 = icmp ne i32 %2980, 0
  %2982 = and i1 %2979, %2981
  %2983 = sub i32 %2980, 1
  %2984 = select i1 %2982, i32 %2983, i32 0
  %2985 = load i8, ptr %frame.active, align 1
  %2986 = trunc i32 %2984 to i8
  %2987 = shl i8 1, %2986
  %2988 = and i8 %2985, %2987
  %2989 = icmp ne i8 %2988, 0
  %2990 = load <8 x i32>, ptr %frame.static.id, align 32
  %2991 = extractelement <8 x i32> %2990, i32 %2984
  %convergence.target.pointer407 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2991
  %convergence.dynamic.target408 = load i32, ptr %convergence.target.pointer407, align 4
  %2992 = icmp eq i32 %convergence.dynamic.target408, 20
  %2993 = and i1 %2989, %2992
  %2994 = and i1 %2982, %2993
  %2995 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2984
  %2996 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2984
  %2997 = load <8 x i1>, ptr %2995, align 1
  %2998 = load <8 x i1>, ptr %2996, align 1
  %2999 = or <8 x i1> %2998, %convergence.cascade.flow405
  %3000 = load <8 x i1>, ptr %live.mask, align 1
  %3001 = and <8 x i1> %2997, %3000
  %3002 = icmp eq <8 x i1> %2999, %3001
  %3003 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3002)
  %3004 = and i1 %2994, %3003
  %3005 = select i1 %3004, <8 x i1> zeroinitializer, <8 x i1> %2999
  %3006 = select i1 %2994, <8 x i1> %3005, <8 x i1> %2998
  store <8 x i1> %3006, ptr %2996, align 1
  %3007 = select i1 %3004, <8 x i1> zeroinitializer, <8 x i1> %2997
  store <8 x i1> %3007, ptr %2995, align 1
  %3008 = trunc i32 %2984 to i8
  %3009 = shl i8 1, %3008
  %3010 = xor i8 %3009, -1
  %3011 = and i8 %2985, %3010
  %3012 = select i1 %3004, i8 %3011, i8 %2985
  store i8 %3012, ptr %frame.active, align 1
  %.splatinsert409 = insertelement <8 x i1> poison, i1 %2994, i64 0
  %.splat410 = shufflevector <8 x i1> %.splatinsert409, <8 x i1> poison, <8 x i32> zeroinitializer
  %3013 = and <8 x i1> %convergence.cascade.flow405, %.splat410
  %3014 = load <8 x i1>, ptr %runnable.mask, align 1
  %3015 = xor <8 x i1> %3013, splat (i1 true)
  %3016 = and <8 x i1> %3014, %3015
  store <8 x i1> %3016, ptr %runnable.mask, align 1
  %.splatinsert411 = insertelement <8 x i1> poison, i1 %3004, i64 0
  %.splat412 = shufflevector <8 x i1> %.splatinsert411, <8 x i1> poison, <8 x i32> zeroinitializer
  %3017 = select <8 x i1> %.splat412, <8 x i1> %2999, <8 x i1> zeroinitializer
  %3018 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3019 = extractelement <8 x i32> %3018, i32 %2984
  %3020 = select i1 %3004, i32 %3019, i32 %2980
  store i32 %3020, ptr %current.token, align 4
  %.splatinsert413 = insertelement <8 x i1> poison, i1 %2994, i64 0
  %.splat414 = shufflevector <8 x i1> %.splatinsert413, <8 x i1> poison, <8 x i32> zeroinitializer
  %3021 = select <8 x i1> %.splat414, <8 x i1> %3017, <8 x i1> %convergence.cascade.flow405
  %3022 = add i32 %convergence.cascade.depth406, 1
  %3023 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3021)
  %3024 = icmp ult i32 %3022, 8
  %3025 = and i1 %3023, %3024
  %3026 = and i1 %2994, %3025
  %convergence.parent.token415 = load i32, ptr %current.token, align 4
  %convergence.parent.present416 = icmp ne i32 %convergence.parent.token415, 0
  %3027 = and i1 %3026, %convergence.parent.present416
  br i1 %3027, label %convergence.cascade401, label %convergence.cascade.exit402

convergence.cascade.exit402:                      ; preds = %convergence.cascade401, %schedule.20
  %convergence.cascade.result417 = phi <8 x i1> [ %417, %schedule.20 ], [ %3021, %convergence.cascade401 ]
  %3028 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result417)
  br i1 %3028, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit402
  %3029 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result417)
  %3030 = bitcast <8 x i1> %convergence.cascade.result417 to i8
  %3031 = call i8 @llvm.cttz.i8(i8 %3030, i1 false)
  %3032 = zext i8 %3031 to i32
  %3033 = select i1 %3029, i32 %3032, i32 0
  %3034 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %3035 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3036 = extractvalue { <8 x ptr>, <8 x i64> } %3034, 0
  %3037 = select <8 x i1> %convergence.cascade.result417, <8 x ptr> %3035, <8 x ptr> %3036
  %3038 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3039 = extractvalue { <8 x ptr>, <8 x i64> } %3034, 1
  %3040 = select <8 x i1> %convergence.cascade.result417, <8 x i64> %3038, <8 x i64> %3039
  %3041 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3037, 0
  %3042 = insertvalue { <8 x ptr>, <8 x i64> } %3041, <8 x i64> %3040, 1
  store { <8 x ptr>, <8 x i64> } %3042, ptr %tile_snapshot.spill94, align 64
  %3043 = load <8 x i64>, ptr %.slot95, align 64
  %3044 = select <8 x i1> %convergence.cascade.result417, <8 x i64> zeroinitializer, <8 x i64> %3043
  store <8 x i64> %3044, ptr %.slot95, align 64
  store <8 x i1> %convergence.cascade.result417, ptr %current.mask, align 1
  %3045 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result417)
  br i1 %3045, label %schedule.21, label %scheduler.loop

varying.divergent419:                             ; preds = %schedule.21
  %3046 = load i32, ptr %current.token, align 4
  %3047 = icmp ne i32 %3046, 0
  %3048 = sub i32 %3046, 1
  %3049 = select i1 %3047, i32 %3048, i32 0
  %3050 = load i8, ptr %frame.active, align 1
  %3051 = trunc i32 %3049 to i8
  %3052 = shl i8 1, %3051
  %3053 = and i8 %3050, %3052
  %3054 = icmp ne i8 %3053, 0
  %3055 = load <8 x i32>, ptr %frame.static.id, align 32
  %3056 = extractelement <8 x i32> %3055, i32 %3049
  %3057 = icmp eq i32 %3056, 8
  %3058 = and i1 %3054, %3057
  %3059 = and i1 %3047, %3058
  %3060 = xor i1 %3059, true
  %3061 = and i1 true, %3060
  %3062 = xor i8 %3050, -1
  %3063 = icmp ne i8 %3062, 0
  %3064 = xor i1 %3063, true
  %3065 = and i1 %3061, %3064
  br i1 %3065, label %convergence.overflow.trap421, label %convergence.overflow.resume422

varying.coherent420:                              ; preds = %schedule.21
  br i1 %428, label %varying.coherent.true425, label %varying.coherent.false426

convergence.overflow.trap421:                     ; preds = %varying.divergent419
  call void @llvm.trap()
  unreachable

convergence.overflow.resume422:                   ; preds = %varying.divergent419
  %3066 = call i8 @llvm.cttz.i8(i8 %3062, i1 false)
  %3067 = zext i8 %3066 to i32
  %3068 = select i1 %3063, i32 %3067, i32 0
  %3069 = trunc i32 %3068 to i8
  %3070 = shl i8 1, %3069
  %3071 = or i8 %3050, %3070
  %3072 = select i1 %3061, i8 %3071, i8 %3050
  store i8 %3072, ptr %frame.active, align 1
  %3073 = load <8 x i32>, ptr %frame.static.id, align 32
  %3074 = extractelement <8 x i32> %3073, i32 %3068
  %3075 = select i1 %3061, i32 8, i32 %3074
  %3076 = load <8 x i32>, ptr %frame.static.id, align 32
  %3077 = insertelement <8 x i32> %3076, i32 %3075, i32 %3068
  store <8 x i32> %3077, ptr %frame.static.id, align 32
  %3078 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3079 = extractelement <8 x i32> %3078, i32 %3068
  %3080 = select i1 %3061, i32 %3046, i32 %3079
  %3081 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3082 = insertelement <8 x i32> %3081, i32 %3080, i32 %3068
  store <8 x i32> %3082, ptr %frame.parent.token, align 32
  %3083 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3068
  %3084 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3068
  %3085 = load <8 x i1>, ptr %3083, align 1
  %3086 = load <8 x i1>, ptr %3084, align 1
  %3087 = select i1 %3061, <8 x i1> %418, <8 x i1> %3085
  store <8 x i1> %3087, ptr %3083, align 1
  %3088 = select i1 %3061, <8 x i1> zeroinitializer, <8 x i1> %3086
  store <8 x i1> %3088, ptr %3084, align 1
  %3089 = add i32 %3068, 1
  %3090 = select i1 %3059, i32 %3046, i32 %3089
  %3091 = select i1 true, i32 %3090, i32 %3046
  store i32 %3091, ptr %current.token, align 4
  %3092 = load i32, ptr %current.token, align 4
  %3093 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %425)
  %3094 = load i32, ptr %ready.count, align 4
  %3095 = icmp uge i32 %3094, 8
  %3096 = and i1 %3093, %3095
  br i1 %3096, label %ready.overflow.trap423, label %ready.overflow.resume424

ready.overflow.trap423:                           ; preds = %convergence.overflow.resume422
  call void @llvm.trap()
  unreachable

ready.overflow.resume424:                         ; preds = %convergence.overflow.resume422
  %3097 = select i1 %3093, i32 %3094, i32 0
  %3098 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3097
  %3099 = load <8 x i1>, ptr %3098, align 1
  %3100 = select i1 %3093, <8 x i1> %425, <8 x i1> %3099
  store <8 x i1> %3100, ptr %3098, align 1
  %3101 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3097
  %3102 = load i32, ptr %3101, align 4
  %3103 = select i1 %3093, i32 22, i32 %3102
  store i32 %3103, ptr %3101, align 4
  %3104 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3097
  %3105 = load i32, ptr %3104, align 4
  %3106 = select i1 %3093, i32 %3092, i32 %3105
  store i32 %3106, ptr %3104, align 4
  %3107 = add i32 %3094, 1
  %3108 = select i1 %3093, i32 %3107, i32 %3094
  store i32 %3108, ptr %ready.count, align 4
  %3109 = load <8 x i1>, ptr %runnable.mask, align 1
  %3110 = or <8 x i1> %3109, %425
  store <8 x i1> %3110, ptr %runnable.mask, align 1
  store <8 x i1> %427, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true425:                         ; preds = %varying.coherent420
  store <8 x i1> %418, ptr %current.mask, align 1
  %3111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %418)
  br i1 %3111, label %schedule.22, label %scheduler.loop

varying.coherent.false426:                        ; preds = %varying.coherent420
  store <8 x i1> %418, ptr %current.mask, align 1
  %3112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %418)
  br i1 %3112, label %schedule.29, label %scheduler.loop

varying.divergent428:                             ; preds = %schedule.23
  %3113 = load i32, ptr %current.token, align 4
  %3114 = icmp ne i32 %3113, 0
  %3115 = sub i32 %3113, 1
  %3116 = select i1 %3114, i32 %3115, i32 0
  %3117 = load i8, ptr %frame.active, align 1
  %3118 = trunc i32 %3116 to i8
  %3119 = shl i8 1, %3118
  %3120 = and i8 %3117, %3119
  %3121 = icmp ne i8 %3120, 0
  %3122 = load <8 x i32>, ptr %frame.static.id, align 32
  %3123 = extractelement <8 x i32> %3122, i32 %3116
  %3124 = icmp eq i32 %3123, 9
  %3125 = and i1 %3121, %3124
  %3126 = and i1 %3114, %3125
  %3127 = xor i1 %3126, true
  %3128 = and i1 true, %3127
  %3129 = xor i8 %3117, -1
  %3130 = icmp ne i8 %3129, 0
  %3131 = xor i1 %3130, true
  %3132 = and i1 %3128, %3131
  br i1 %3132, label %convergence.overflow.trap430, label %convergence.overflow.resume431

varying.coherent429:                              ; preds = %schedule.23
  br i1 %450, label %varying.coherent.true434, label %varying.coherent.false435

convergence.overflow.trap430:                     ; preds = %varying.divergent428
  call void @llvm.trap()
  unreachable

convergence.overflow.resume431:                   ; preds = %varying.divergent428
  %3133 = call i8 @llvm.cttz.i8(i8 %3129, i1 false)
  %3134 = zext i8 %3133 to i32
  %3135 = select i1 %3130, i32 %3134, i32 0
  %3136 = trunc i32 %3135 to i8
  %3137 = shl i8 1, %3136
  %3138 = or i8 %3117, %3137
  %3139 = select i1 %3128, i8 %3138, i8 %3117
  store i8 %3139, ptr %frame.active, align 1
  %3140 = load <8 x i32>, ptr %frame.static.id, align 32
  %3141 = extractelement <8 x i32> %3140, i32 %3135
  %3142 = select i1 %3128, i32 9, i32 %3141
  %3143 = load <8 x i32>, ptr %frame.static.id, align 32
  %3144 = insertelement <8 x i32> %3143, i32 %3142, i32 %3135
  store <8 x i32> %3144, ptr %frame.static.id, align 32
  %3145 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3146 = extractelement <8 x i32> %3145, i32 %3135
  %3147 = select i1 %3128, i32 %3113, i32 %3146
  %3148 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3149 = insertelement <8 x i32> %3148, i32 %3147, i32 %3135
  store <8 x i32> %3149, ptr %frame.parent.token, align 32
  %3150 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3135
  %3151 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3135
  %3152 = load <8 x i1>, ptr %3150, align 1
  %3153 = load <8 x i1>, ptr %3151, align 1
  %3154 = select i1 %3128, <8 x i1> %440, <8 x i1> %3152
  store <8 x i1> %3154, ptr %3150, align 1
  %3155 = select i1 %3128, <8 x i1> zeroinitializer, <8 x i1> %3153
  store <8 x i1> %3155, ptr %3151, align 1
  %3156 = add i32 %3135, 1
  %3157 = select i1 %3126, i32 %3113, i32 %3156
  %3158 = select i1 true, i32 %3157, i32 %3113
  store i32 %3158, ptr %current.token, align 4
  %3159 = load i32, ptr %current.token, align 4
  %3160 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %447)
  %3161 = load i32, ptr %ready.count, align 4
  %3162 = icmp uge i32 %3161, 8
  %3163 = and i1 %3160, %3162
  br i1 %3163, label %ready.overflow.trap432, label %ready.overflow.resume433

ready.overflow.trap432:                           ; preds = %convergence.overflow.resume431
  call void @llvm.trap()
  unreachable

ready.overflow.resume433:                         ; preds = %convergence.overflow.resume431
  %3164 = select i1 %3160, i32 %3161, i32 0
  %3165 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3164
  %3166 = load <8 x i1>, ptr %3165, align 1
  %3167 = select i1 %3160, <8 x i1> %447, <8 x i1> %3166
  store <8 x i1> %3167, ptr %3165, align 1
  %3168 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3164
  %3169 = load i32, ptr %3168, align 4
  %3170 = select i1 %3160, i32 24, i32 %3169
  store i32 %3170, ptr %3168, align 4
  %3171 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3164
  %3172 = load i32, ptr %3171, align 4
  %3173 = select i1 %3160, i32 %3159, i32 %3172
  store i32 %3173, ptr %3171, align 4
  %3174 = add i32 %3161, 1
  %3175 = select i1 %3160, i32 %3174, i32 %3161
  store i32 %3175, ptr %ready.count, align 4
  %3176 = load <8 x i1>, ptr %runnable.mask, align 1
  %3177 = or <8 x i1> %3176, %447
  store <8 x i1> %3177, ptr %runnable.mask, align 1
  store <8 x i1> %449, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true434:                         ; preds = %varying.coherent429
  store <8 x i1> %440, ptr %current.mask, align 1
  %3178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %440)
  br i1 %3178, label %schedule.24, label %scheduler.loop

varying.coherent.false435:                        ; preds = %varying.coherent429
  store <8 x i1> %440, ptr %current.mask, align 1
  %3179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %440)
  br i1 %3179, label %schedule.28, label %scheduler.loop

varying.divergent439:                             ; preds = %schedule.25
  %3180 = load i32, ptr %current.token, align 4
  %3181 = icmp ne i32 %3180, 0
  %3182 = sub i32 %3180, 1
  %3183 = select i1 %3181, i32 %3182, i32 0
  %3184 = load i8, ptr %frame.active, align 1
  %3185 = trunc i32 %3183 to i8
  %3186 = shl i8 1, %3185
  %3187 = and i8 %3184, %3186
  %3188 = icmp ne i8 %3187, 0
  %3189 = load <8 x i32>, ptr %frame.static.id, align 32
  %3190 = extractelement <8 x i32> %3189, i32 %3183
  %3191 = icmp eq i32 %3190, 10
  %3192 = and i1 %3188, %3191
  %3193 = and i1 %3181, %3192
  %3194 = xor i1 %3193, true
  %3195 = and i1 true, %3194
  %3196 = xor i8 %3184, -1
  %3197 = icmp ne i8 %3196, 0
  %3198 = xor i1 %3197, true
  %3199 = and i1 %3195, %3198
  br i1 %3199, label %convergence.overflow.trap441, label %convergence.overflow.resume442

varying.coherent440:                              ; preds = %schedule.25
  br i1 %520, label %varying.coherent.true445, label %varying.coherent.false446

convergence.overflow.trap441:                     ; preds = %varying.divergent439
  call void @llvm.trap()
  unreachable

convergence.overflow.resume442:                   ; preds = %varying.divergent439
  %3200 = call i8 @llvm.cttz.i8(i8 %3196, i1 false)
  %3201 = zext i8 %3200 to i32
  %3202 = select i1 %3197, i32 %3201, i32 0
  %3203 = trunc i32 %3202 to i8
  %3204 = shl i8 1, %3203
  %3205 = or i8 %3184, %3204
  %3206 = select i1 %3195, i8 %3205, i8 %3184
  store i8 %3206, ptr %frame.active, align 1
  %3207 = load <8 x i32>, ptr %frame.static.id, align 32
  %3208 = extractelement <8 x i32> %3207, i32 %3202
  %3209 = select i1 %3195, i32 10, i32 %3208
  %3210 = load <8 x i32>, ptr %frame.static.id, align 32
  %3211 = insertelement <8 x i32> %3210, i32 %3209, i32 %3202
  store <8 x i32> %3211, ptr %frame.static.id, align 32
  %3212 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3213 = extractelement <8 x i32> %3212, i32 %3202
  %3214 = select i1 %3195, i32 %3180, i32 %3213
  %3215 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3216 = insertelement <8 x i32> %3215, i32 %3214, i32 %3202
  store <8 x i32> %3216, ptr %frame.parent.token, align 32
  %3217 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3202
  %3218 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3202
  %3219 = load <8 x i1>, ptr %3217, align 1
  %3220 = load <8 x i1>, ptr %3218, align 1
  %3221 = select i1 %3195, <8 x i1> %510, <8 x i1> %3219
  store <8 x i1> %3221, ptr %3217, align 1
  %3222 = select i1 %3195, <8 x i1> zeroinitializer, <8 x i1> %3220
  store <8 x i1> %3222, ptr %3218, align 1
  %3223 = add i32 %3202, 1
  %3224 = select i1 %3193, i32 %3180, i32 %3223
  %3225 = select i1 true, i32 %3224, i32 %3180
  store i32 %3225, ptr %current.token, align 4
  %3226 = load i32, ptr %current.token, align 4
  %3227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %517)
  %3228 = load i32, ptr %ready.count, align 4
  %3229 = icmp uge i32 %3228, 8
  %3230 = and i1 %3227, %3229
  br i1 %3230, label %ready.overflow.trap443, label %ready.overflow.resume444

ready.overflow.trap443:                           ; preds = %convergence.overflow.resume442
  call void @llvm.trap()
  unreachable

ready.overflow.resume444:                         ; preds = %convergence.overflow.resume442
  %3231 = select i1 %3227, i32 %3228, i32 0
  %3232 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3231
  %3233 = load <8 x i1>, ptr %3232, align 1
  %3234 = select i1 %3227, <8 x i1> %517, <8 x i1> %3233
  store <8 x i1> %3234, ptr %3232, align 1
  %3235 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3231
  %3236 = load i32, ptr %3235, align 4
  %3237 = select i1 %3227, i32 26, i32 %3236
  store i32 %3237, ptr %3235, align 4
  %3238 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3231
  %3239 = load i32, ptr %3238, align 4
  %3240 = select i1 %3227, i32 %3226, i32 %3239
  store i32 %3240, ptr %3238, align 4
  %3241 = add i32 %3228, 1
  %3242 = select i1 %3227, i32 %3241, i32 %3228
  store i32 %3242, ptr %ready.count, align 4
  %3243 = load <8 x i1>, ptr %runnable.mask, align 1
  %3244 = or <8 x i1> %3243, %517
  store <8 x i1> %3244, ptr %runnable.mask, align 1
  store <8 x i1> %519, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true445:                         ; preds = %varying.coherent440
  store <8 x i1> %510, ptr %current.mask, align 1
  %3245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %510)
  br i1 %3245, label %schedule.26, label %scheduler.loop

varying.coherent.false446:                        ; preds = %varying.coherent440
  store <8 x i1> %510, ptr %current.mask, align 1
  %3246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %510)
  br i1 %3246, label %schedule.27, label %scheduler.loop

convergence.cascade467:                           ; preds = %convergence.cascade467, %schedule.27
  %convergence.cascade.flow471 = phi <8 x i1> [ %614, %schedule.27 ], [ %3289, %convergence.cascade467 ]
  %convergence.cascade.depth472 = phi i32 [ 0, %schedule.27 ], [ %3290, %convergence.cascade467 ]
  %3247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow471)
  %3248 = load i32, ptr %current.token, align 4
  %3249 = icmp ne i32 %3248, 0
  %3250 = and i1 %3247, %3249
  %3251 = sub i32 %3248, 1
  %3252 = select i1 %3250, i32 %3251, i32 0
  %3253 = load i8, ptr %frame.active, align 1
  %3254 = trunc i32 %3252 to i8
  %3255 = shl i8 1, %3254
  %3256 = and i8 %3253, %3255
  %3257 = icmp ne i8 %3256, 0
  %3258 = load <8 x i32>, ptr %frame.static.id, align 32
  %3259 = extractelement <8 x i32> %3258, i32 %3252
  %convergence.target.pointer473 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %3259
  %convergence.dynamic.target474 = load i32, ptr %convergence.target.pointer473, align 4
  %3260 = icmp eq i32 %convergence.dynamic.target474, 27
  %3261 = and i1 %3257, %3260
  %3262 = and i1 %3250, %3261
  %3263 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3252
  %3264 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3252
  %3265 = load <8 x i1>, ptr %3263, align 1
  %3266 = load <8 x i1>, ptr %3264, align 1
  %3267 = or <8 x i1> %3266, %convergence.cascade.flow471
  %3268 = load <8 x i1>, ptr %live.mask, align 1
  %3269 = and <8 x i1> %3265, %3268
  %3270 = icmp eq <8 x i1> %3267, %3269
  %3271 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3270)
  %3272 = and i1 %3262, %3271
  %3273 = select i1 %3272, <8 x i1> zeroinitializer, <8 x i1> %3267
  %3274 = select i1 %3262, <8 x i1> %3273, <8 x i1> %3266
  store <8 x i1> %3274, ptr %3264, align 1
  %3275 = select i1 %3272, <8 x i1> zeroinitializer, <8 x i1> %3265
  store <8 x i1> %3275, ptr %3263, align 1
  %3276 = trunc i32 %3252 to i8
  %3277 = shl i8 1, %3276
  %3278 = xor i8 %3277, -1
  %3279 = and i8 %3253, %3278
  %3280 = select i1 %3272, i8 %3279, i8 %3253
  store i8 %3280, ptr %frame.active, align 1
  %.splatinsert475 = insertelement <8 x i1> poison, i1 %3262, i64 0
  %.splat476 = shufflevector <8 x i1> %.splatinsert475, <8 x i1> poison, <8 x i32> zeroinitializer
  %3281 = and <8 x i1> %convergence.cascade.flow471, %.splat476
  %3282 = load <8 x i1>, ptr %runnable.mask, align 1
  %3283 = xor <8 x i1> %3281, splat (i1 true)
  %3284 = and <8 x i1> %3282, %3283
  store <8 x i1> %3284, ptr %runnable.mask, align 1
  %.splatinsert477 = insertelement <8 x i1> poison, i1 %3272, i64 0
  %.splat478 = shufflevector <8 x i1> %.splatinsert477, <8 x i1> poison, <8 x i32> zeroinitializer
  %3285 = select <8 x i1> %.splat478, <8 x i1> %3267, <8 x i1> zeroinitializer
  %3286 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3287 = extractelement <8 x i32> %3286, i32 %3252
  %3288 = select i1 %3272, i32 %3287, i32 %3248
  store i32 %3288, ptr %current.token, align 4
  %.splatinsert479 = insertelement <8 x i1> poison, i1 %3262, i64 0
  %.splat480 = shufflevector <8 x i1> %.splatinsert479, <8 x i1> poison, <8 x i32> zeroinitializer
  %3289 = select <8 x i1> %.splat480, <8 x i1> %3285, <8 x i1> %convergence.cascade.flow471
  %3290 = add i32 %convergence.cascade.depth472, 1
  %3291 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3289)
  %3292 = icmp ult i32 %3290, 8
  %3293 = and i1 %3291, %3292
  %3294 = and i1 %3262, %3293
  %convergence.parent.token481 = load i32, ptr %current.token, align 4
  %convergence.parent.present482 = icmp ne i32 %convergence.parent.token481, 0
  %3295 = and i1 %3294, %convergence.parent.present482
  br i1 %3295, label %convergence.cascade467, label %convergence.cascade.exit468

convergence.cascade.exit468:                      ; preds = %convergence.cascade467, %schedule.27
  %convergence.cascade.result483 = phi <8 x i1> [ %614, %schedule.27 ], [ %3289, %convergence.cascade467 ]
  %3296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result483)
  br i1 %3296, label %convergence.target.27.ready, label %scheduler.loop

convergence.target.27.ready:                      ; preds = %convergence.cascade.exit468
  %3297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result483)
  %3298 = bitcast <8 x i1> %convergence.cascade.result483 to i8
  %3299 = call i8 @llvm.cttz.i8(i8 %3298, i1 false)
  %3300 = zext i8 %3299 to i32
  %3301 = select i1 %3297, i32 %3300, i32 0
  %tile_snapshot.spill.load484 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %3302 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load484, 0
  %3303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load484, 1
  %.spill.load485 = load <8 x i64>, ptr %.spill97, align 64
  %3304 = mul <8 x i64> %.spill.load485, splat (i64 32)
  %3305 = add <8 x i64> %3303, %3304
  %3306 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3302, 0
  %3307 = insertvalue { <8 x ptr>, <8 x i64> } %3306, <8 x i64> %3305, 1
  %.state486 = load <8 x float>, ptr %.slot107, align 32
  %3308 = extractvalue { <8 x ptr>, <8 x i64> } %3307, 0
  %3309 = extractvalue { <8 x ptr>, <8 x i64> } %3307, 1
  %3310 = getelementptr i8, <8 x ptr> %3308, <8 x i64> %3309
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state486, <8 x ptr> align 1 %3310, <8 x i1> %convergence.cascade.result483)
  %tile_snapshot.spill.load487 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %3311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load487, 0
  %3312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load487, 1
  %.spill.load488 = load <8 x i64>, ptr %.spill100, align 64
  %3313 = mul <8 x i64> %.spill.load488, splat (i64 32)
  %3314 = add <8 x i64> %3312, %3313
  %3315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3311, 0
  %3316 = insertvalue { <8 x ptr>, <8 x i64> } %3315, <8 x i64> %3314, 1
  %.state489 = load <8 x float>, ptr %.slot108, align 32
  %3317 = extractvalue { <8 x ptr>, <8 x i64> } %3316, 0
  %3318 = extractvalue { <8 x ptr>, <8 x i64> } %3316, 1
  %3319 = getelementptr i8, <8 x ptr> %3317, <8 x i64> %3318
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state489, <8 x ptr> align 1 %3319, <8 x i1> %convergence.cascade.result483)
  %tile_snapshot.spill.load490 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %3320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load490, 0
  %3321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load490, 1
  %.spill.load491 = load <8 x i64>, ptr %.spill102, align 64
  %3322 = mul <8 x i64> %.spill.load491, splat (i64 32)
  %3323 = add <8 x i64> %3321, %3322
  %3324 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3320, 0
  %3325 = insertvalue { <8 x ptr>, <8 x i64> } %3324, <8 x i64> %3323, 1
  %.state492 = load <8 x float>, ptr %.slot109, align 32
  %3326 = extractvalue { <8 x ptr>, <8 x i64> } %3325, 0
  %3327 = extractvalue { <8 x ptr>, <8 x i64> } %3325, 1
  %3328 = getelementptr i8, <8 x ptr> %3326, <8 x i64> %3327
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state492, <8 x ptr> align 1 %3328, <8 x i1> %convergence.cascade.result483)
  %tile_snapshot.spill.load493 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %3329 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load493, 0
  %3330 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load493, 1
  %.spill.load494 = load <8 x i64>, ptr %.spill104, align 64
  %3331 = mul <8 x i64> %.spill.load494, splat (i64 32)
  %3332 = add <8 x i64> %3330, %3331
  %3333 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3329, 0
  %3334 = insertvalue { <8 x ptr>, <8 x i64> } %3333, <8 x i64> %3332, 1
  %.state495 = load <8 x float>, ptr %.slot110, align 32
  %3335 = extractvalue { <8 x ptr>, <8 x i64> } %3334, 0
  %3336 = extractvalue { <8 x ptr>, <8 x i64> } %3334, 1
  %3337 = getelementptr i8, <8 x ptr> %3335, <8 x i64> %3336
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state495, <8 x ptr> align 1 %3337, <8 x i1> %convergence.cascade.result483)
  %.state496 = load <8 x i64>, ptr %.slot96, align 64
  %3338 = add <8 x i64> %.state496, splat (i64 1)
  %3339 = load <8 x i64>, ptr %.slot96, align 64
  %3340 = select <8 x i1> %convergence.cascade.result483, <8 x i64> %3338, <8 x i64> %3339
  store <8 x i64> %3340, ptr %.slot96, align 64
  store <8 x i1> %convergence.cascade.result483, ptr %current.mask, align 1
  %3341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result483)
  br i1 %3341, label %schedule.23, label %scheduler.loop

convergence.cascade497:                           ; preds = %convergence.cascade497, %schedule.28
  %convergence.cascade.flow501 = phi <8 x i1> [ %615, %schedule.28 ], [ %3384, %convergence.cascade497 ]
  %convergence.cascade.depth502 = phi i32 [ 0, %schedule.28 ], [ %3385, %convergence.cascade497 ]
  %3342 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow501)
  %3343 = load i32, ptr %current.token, align 4
  %3344 = icmp ne i32 %3343, 0
  %3345 = and i1 %3342, %3344
  %3346 = sub i32 %3343, 1
  %3347 = select i1 %3345, i32 %3346, i32 0
  %3348 = load i8, ptr %frame.active, align 1
  %3349 = trunc i32 %3347 to i8
  %3350 = shl i8 1, %3349
  %3351 = and i8 %3348, %3350
  %3352 = icmp ne i8 %3351, 0
  %3353 = load <8 x i32>, ptr %frame.static.id, align 32
  %3354 = extractelement <8 x i32> %3353, i32 %3347
  %convergence.target.pointer503 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %3354
  %convergence.dynamic.target504 = load i32, ptr %convergence.target.pointer503, align 4
  %3355 = icmp eq i32 %convergence.dynamic.target504, 28
  %3356 = and i1 %3352, %3355
  %3357 = and i1 %3345, %3356
  %3358 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3347
  %3359 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3347
  %3360 = load <8 x i1>, ptr %3358, align 1
  %3361 = load <8 x i1>, ptr %3359, align 1
  %3362 = or <8 x i1> %3361, %convergence.cascade.flow501
  %3363 = load <8 x i1>, ptr %live.mask, align 1
  %3364 = and <8 x i1> %3360, %3363
  %3365 = icmp eq <8 x i1> %3362, %3364
  %3366 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3365)
  %3367 = and i1 %3357, %3366
  %3368 = select i1 %3367, <8 x i1> zeroinitializer, <8 x i1> %3362
  %3369 = select i1 %3357, <8 x i1> %3368, <8 x i1> %3361
  store <8 x i1> %3369, ptr %3359, align 1
  %3370 = select i1 %3367, <8 x i1> zeroinitializer, <8 x i1> %3360
  store <8 x i1> %3370, ptr %3358, align 1
  %3371 = trunc i32 %3347 to i8
  %3372 = shl i8 1, %3371
  %3373 = xor i8 %3372, -1
  %3374 = and i8 %3348, %3373
  %3375 = select i1 %3367, i8 %3374, i8 %3348
  store i8 %3375, ptr %frame.active, align 1
  %.splatinsert505 = insertelement <8 x i1> poison, i1 %3357, i64 0
  %.splat506 = shufflevector <8 x i1> %.splatinsert505, <8 x i1> poison, <8 x i32> zeroinitializer
  %3376 = and <8 x i1> %convergence.cascade.flow501, %.splat506
  %3377 = load <8 x i1>, ptr %runnable.mask, align 1
  %3378 = xor <8 x i1> %3376, splat (i1 true)
  %3379 = and <8 x i1> %3377, %3378
  store <8 x i1> %3379, ptr %runnable.mask, align 1
  %.splatinsert507 = insertelement <8 x i1> poison, i1 %3367, i64 0
  %.splat508 = shufflevector <8 x i1> %.splatinsert507, <8 x i1> poison, <8 x i32> zeroinitializer
  %3380 = select <8 x i1> %.splat508, <8 x i1> %3362, <8 x i1> zeroinitializer
  %3381 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3382 = extractelement <8 x i32> %3381, i32 %3347
  %3383 = select i1 %3367, i32 %3382, i32 %3343
  store i32 %3383, ptr %current.token, align 4
  %.splatinsert509 = insertelement <8 x i1> poison, i1 %3357, i64 0
  %.splat510 = shufflevector <8 x i1> %.splatinsert509, <8 x i1> poison, <8 x i32> zeroinitializer
  %3384 = select <8 x i1> %.splat510, <8 x i1> %3380, <8 x i1> %convergence.cascade.flow501
  %3385 = add i32 %convergence.cascade.depth502, 1
  %3386 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3384)
  %3387 = icmp ult i32 %3385, 8
  %3388 = and i1 %3386, %3387
  %3389 = and i1 %3357, %3388
  %convergence.parent.token511 = load i32, ptr %current.token, align 4
  %convergence.parent.present512 = icmp ne i32 %convergence.parent.token511, 0
  %3390 = and i1 %3389, %convergence.parent.present512
  br i1 %3390, label %convergence.cascade497, label %convergence.cascade.exit498

convergence.cascade.exit498:                      ; preds = %convergence.cascade497, %schedule.28
  %convergence.cascade.result513 = phi <8 x i1> [ %615, %schedule.28 ], [ %3384, %convergence.cascade497 ]
  %3391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result513)
  br i1 %3391, label %convergence.target.28.ready, label %scheduler.loop

convergence.target.28.ready:                      ; preds = %convergence.cascade.exit498
  %3392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result513)
  %3393 = bitcast <8 x i1> %convergence.cascade.result513 to i8
  %3394 = call i8 @llvm.cttz.i8(i8 %3393, i1 false)
  %3395 = zext i8 %3394 to i32
  %3396 = select i1 %3392, i32 %3395, i32 0
  %.state514 = load <8 x i64>, ptr %.slot95, align 64
  %3397 = add <8 x i64> %.state514, splat (i64 1)
  %3398 = load <8 x i64>, ptr %.slot95, align 64
  %3399 = select <8 x i1> %convergence.cascade.result513, <8 x i64> %3397, <8 x i64> %3398
  store <8 x i64> %3399, ptr %.slot95, align 64
  store <8 x i1> %convergence.cascade.result513, ptr %current.mask, align 1
  %3400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result513)
  br i1 %3400, label %schedule.21, label %scheduler.loop

convergence.cascade515:                           ; preds = %convergence.cascade515, %schedule.29
  %convergence.cascade.flow519 = phi <8 x i1> [ %616, %schedule.29 ], [ %3443, %convergence.cascade515 ]
  %convergence.cascade.depth520 = phi i32 [ 0, %schedule.29 ], [ %3444, %convergence.cascade515 ]
  %3401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow519)
  %3402 = load i32, ptr %current.token, align 4
  %3403 = icmp ne i32 %3402, 0
  %3404 = and i1 %3401, %3403
  %3405 = sub i32 %3402, 1
  %3406 = select i1 %3404, i32 %3405, i32 0
  %3407 = load i8, ptr %frame.active, align 1
  %3408 = trunc i32 %3406 to i8
  %3409 = shl i8 1, %3408
  %3410 = and i8 %3407, %3409
  %3411 = icmp ne i8 %3410, 0
  %3412 = load <8 x i32>, ptr %frame.static.id, align 32
  %3413 = extractelement <8 x i32> %3412, i32 %3406
  %convergence.target.pointer521 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %3413
  %convergence.dynamic.target522 = load i32, ptr %convergence.target.pointer521, align 4
  %3414 = icmp eq i32 %convergence.dynamic.target522, 29
  %3415 = and i1 %3411, %3414
  %3416 = and i1 %3404, %3415
  %3417 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3406
  %3418 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3406
  %3419 = load <8 x i1>, ptr %3417, align 1
  %3420 = load <8 x i1>, ptr %3418, align 1
  %3421 = or <8 x i1> %3420, %convergence.cascade.flow519
  %3422 = load <8 x i1>, ptr %live.mask, align 1
  %3423 = and <8 x i1> %3419, %3422
  %3424 = icmp eq <8 x i1> %3421, %3423
  %3425 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3424)
  %3426 = and i1 %3416, %3425
  %3427 = select i1 %3426, <8 x i1> zeroinitializer, <8 x i1> %3421
  %3428 = select i1 %3416, <8 x i1> %3427, <8 x i1> %3420
  store <8 x i1> %3428, ptr %3418, align 1
  %3429 = select i1 %3426, <8 x i1> zeroinitializer, <8 x i1> %3419
  store <8 x i1> %3429, ptr %3417, align 1
  %3430 = trunc i32 %3406 to i8
  %3431 = shl i8 1, %3430
  %3432 = xor i8 %3431, -1
  %3433 = and i8 %3407, %3432
  %3434 = select i1 %3426, i8 %3433, i8 %3407
  store i8 %3434, ptr %frame.active, align 1
  %.splatinsert523 = insertelement <8 x i1> poison, i1 %3416, i64 0
  %.splat524 = shufflevector <8 x i1> %.splatinsert523, <8 x i1> poison, <8 x i32> zeroinitializer
  %3435 = and <8 x i1> %convergence.cascade.flow519, %.splat524
  %3436 = load <8 x i1>, ptr %runnable.mask, align 1
  %3437 = xor <8 x i1> %3435, splat (i1 true)
  %3438 = and <8 x i1> %3436, %3437
  store <8 x i1> %3438, ptr %runnable.mask, align 1
  %.splatinsert525 = insertelement <8 x i1> poison, i1 %3426, i64 0
  %.splat526 = shufflevector <8 x i1> %.splatinsert525, <8 x i1> poison, <8 x i32> zeroinitializer
  %3439 = select <8 x i1> %.splat526, <8 x i1> %3421, <8 x i1> zeroinitializer
  %3440 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3441 = extractelement <8 x i32> %3440, i32 %3406
  %3442 = select i1 %3426, i32 %3441, i32 %3402
  store i32 %3442, ptr %current.token, align 4
  %.splatinsert527 = insertelement <8 x i1> poison, i1 %3416, i64 0
  %.splat528 = shufflevector <8 x i1> %.splatinsert527, <8 x i1> poison, <8 x i32> zeroinitializer
  %3443 = select <8 x i1> %.splat528, <8 x i1> %3439, <8 x i1> %convergence.cascade.flow519
  %3444 = add i32 %convergence.cascade.depth520, 1
  %3445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3443)
  %3446 = icmp ult i32 %3444, 8
  %3447 = and i1 %3445, %3446
  %3448 = and i1 %3416, %3447
  %convergence.parent.token529 = load i32, ptr %current.token, align 4
  %convergence.parent.present530 = icmp ne i32 %convergence.parent.token529, 0
  %3449 = and i1 %3448, %convergence.parent.present530
  br i1 %3449, label %convergence.cascade515, label %convergence.cascade.exit516

convergence.cascade.exit516:                      ; preds = %convergence.cascade515, %schedule.29
  %convergence.cascade.result531 = phi <8 x i1> [ %616, %schedule.29 ], [ %3443, %convergence.cascade515 ]
  %3450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  br i1 %3450, label %convergence.target.29.ready, label %scheduler.loop

convergence.target.29.ready:                      ; preds = %convergence.cascade.exit516
  %3451 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3452 = bitcast <8 x i1> %convergence.cascade.result531 to i8
  %3453 = call i8 @llvm.cttz.i8(i8 %3452, i1 false)
  %3454 = zext i8 %3453 to i32
  %3455 = select i1 %3451, i32 %3454, i32 0
  %.spill.load532 = load <8 x i64>, ptr %.spill85, align 64
  %3456 = add <8 x i64> zeroinitializer, %.spill.load532
  %.spill.load533 = load <8 x i64>, ptr %.spill85, align 64
  %3457 = add <8 x i64> splat (i64 1), %.spill.load533
  %.spill.load534 = load <8 x i64>, ptr %.spill85, align 64
  %3458 = add <8 x i64> splat (i64 2), %.spill.load534
  %.spill.load535 = load <8 x i64>, ptr %.spill85, align 64
  %3459 = add <8 x i64> splat (i64 3), %.spill.load535
  %.spill.load536 = load <8 x i64>, ptr %.spill85, align 64
  %3460 = add <8 x i64> splat (i64 4), %.spill.load536
  %.spill.load537 = load <8 x i64>, ptr %.spill85, align 64
  %3461 = add <8 x i64> splat (i64 5), %.spill.load537
  %.spill.load538 = load <8 x i64>, ptr %.spill85, align 64
  %3462 = add <8 x i64> splat (i64 6), %.spill.load538
  %.spill.load539 = load <8 x i64>, ptr %.spill85, align 64
  %3463 = add <8 x i64> splat (i64 7), %.spill.load539
  %.spill.load540 = load <8 x i64>, ptr %.spill85, align 64
  %3464 = add <8 x i64> splat (i64 8), %.spill.load540
  %.spill.load541 = load <8 x i64>, ptr %.spill85, align 64
  %3465 = add <8 x i64> splat (i64 9), %.spill.load541
  %.spill.load542 = load <8 x i64>, ptr %.spill85, align 64
  %3466 = add <8 x i64> splat (i64 10), %.spill.load542
  %.spill.load543 = load <8 x i64>, ptr %.spill85, align 64
  %3467 = add <8 x i64> splat (i64 11), %.spill.load543
  %.spill.load544 = load <8 x i64>, ptr %.spill85, align 64
  %3468 = add <8 x i64> splat (i64 12), %.spill.load544
  %.spill.load545 = load <8 x i64>, ptr %.spill85, align 64
  %3469 = add <8 x i64> splat (i64 13), %.spill.load545
  %.spill.load546 = load <8 x i64>, ptr %.spill85, align 64
  %3470 = add <8 x i64> splat (i64 14), %.spill.load546
  %.spill.load547 = load <8 x i64>, ptr %.spill85, align 64
  %3471 = add <8 x i64> splat (i64 15), %.spill.load547
  %3472 = icmp slt <8 x i64> %3456, splat (i64 131)
  %3473 = icmp slt <8 x i64> %3457, splat (i64 131)
  %3474 = icmp slt <8 x i64> %3458, splat (i64 131)
  %3475 = icmp slt <8 x i64> %3459, splat (i64 131)
  %3476 = icmp slt <8 x i64> %3460, splat (i64 131)
  %3477 = icmp slt <8 x i64> %3461, splat (i64 131)
  %3478 = icmp slt <8 x i64> %3462, splat (i64 131)
  %3479 = icmp slt <8 x i64> %3463, splat (i64 131)
  %3480 = icmp slt <8 x i64> %3464, splat (i64 131)
  %3481 = icmp slt <8 x i64> %3465, splat (i64 131)
  %3482 = icmp slt <8 x i64> %3466, splat (i64 131)
  %3483 = icmp slt <8 x i64> %3467, splat (i64 131)
  %3484 = icmp slt <8 x i64> %3468, splat (i64 131)
  %3485 = icmp slt <8 x i64> %3469, splat (i64 131)
  %3486 = icmp slt <8 x i64> %3470, splat (i64 131)
  %3487 = icmp slt <8 x i64> %3471, splat (i64 131)
  %3488 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %3489 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3490 = extractvalue { <8 x ptr>, <8 x i64> } %3488, 0
  %3491 = select <8 x i1> %convergence.cascade.result531, <8 x ptr> %3489, <8 x ptr> %3490
  %3492 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3493 = extractvalue { <8 x ptr>, <8 x i64> } %3488, 1
  %3494 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3492, <8 x i64> %3493
  %3495 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3491, 0
  %3496 = insertvalue { <8 x ptr>, <8 x i64> } %3495, <8 x i64> %3494, 1
  store { <8 x ptr>, <8 x i64> } %3496, ptr %tile_snapshot.spill111, align 64
  %3497 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3498 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3499 = add <8 x i64> %3498, zeroinitializer
  %3500 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3497, 0
  %3501 = insertvalue { <8 x ptr>, <8 x i64> } %3500, <8 x i64> %3499, 1
  %3502 = extractvalue { <8 x ptr>, <8 x i64> } %3501, 0
  %3503 = extractvalue { <8 x ptr>, <8 x i64> } %3501, 1
  %3504 = getelementptr i8, <8 x ptr> %3502, <8 x i64> %3503
  %3505 = zext <8 x i1> %3472 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3505, <8 x ptr> align 1 %3504, <8 x i1> %convergence.cascade.result531)
  %3506 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3507 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3508 = add <8 x i64> %3507, splat (i64 1)
  %3509 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3506, 0
  %3510 = insertvalue { <8 x ptr>, <8 x i64> } %3509, <8 x i64> %3508, 1
  %3511 = extractvalue { <8 x ptr>, <8 x i64> } %3510, 0
  %3512 = extractvalue { <8 x ptr>, <8 x i64> } %3510, 1
  %3513 = getelementptr i8, <8 x ptr> %3511, <8 x i64> %3512
  %3514 = zext <8 x i1> %3473 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3514, <8 x ptr> align 1 %3513, <8 x i1> %convergence.cascade.result531)
  %3515 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3516 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3517 = add <8 x i64> %3516, splat (i64 2)
  %3518 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3515, 0
  %3519 = insertvalue { <8 x ptr>, <8 x i64> } %3518, <8 x i64> %3517, 1
  %3520 = extractvalue { <8 x ptr>, <8 x i64> } %3519, 0
  %3521 = extractvalue { <8 x ptr>, <8 x i64> } %3519, 1
  %3522 = getelementptr i8, <8 x ptr> %3520, <8 x i64> %3521
  %3523 = zext <8 x i1> %3474 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3523, <8 x ptr> align 1 %3522, <8 x i1> %convergence.cascade.result531)
  %3524 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3525 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3526 = add <8 x i64> %3525, splat (i64 3)
  %3527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3524, 0
  %3528 = insertvalue { <8 x ptr>, <8 x i64> } %3527, <8 x i64> %3526, 1
  %3529 = extractvalue { <8 x ptr>, <8 x i64> } %3528, 0
  %3530 = extractvalue { <8 x ptr>, <8 x i64> } %3528, 1
  %3531 = getelementptr i8, <8 x ptr> %3529, <8 x i64> %3530
  %3532 = zext <8 x i1> %3475 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3532, <8 x ptr> align 1 %3531, <8 x i1> %convergence.cascade.result531)
  %3533 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3534 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3535 = add <8 x i64> %3534, splat (i64 4)
  %3536 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3533, 0
  %3537 = insertvalue { <8 x ptr>, <8 x i64> } %3536, <8 x i64> %3535, 1
  %3538 = extractvalue { <8 x ptr>, <8 x i64> } %3537, 0
  %3539 = extractvalue { <8 x ptr>, <8 x i64> } %3537, 1
  %3540 = getelementptr i8, <8 x ptr> %3538, <8 x i64> %3539
  %3541 = zext <8 x i1> %3476 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3541, <8 x ptr> align 1 %3540, <8 x i1> %convergence.cascade.result531)
  %3542 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3543 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3544 = add <8 x i64> %3543, splat (i64 5)
  %3545 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3542, 0
  %3546 = insertvalue { <8 x ptr>, <8 x i64> } %3545, <8 x i64> %3544, 1
  %3547 = extractvalue { <8 x ptr>, <8 x i64> } %3546, 0
  %3548 = extractvalue { <8 x ptr>, <8 x i64> } %3546, 1
  %3549 = getelementptr i8, <8 x ptr> %3547, <8 x i64> %3548
  %3550 = zext <8 x i1> %3477 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3550, <8 x ptr> align 1 %3549, <8 x i1> %convergence.cascade.result531)
  %3551 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3552 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3553 = add <8 x i64> %3552, splat (i64 6)
  %3554 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3551, 0
  %3555 = insertvalue { <8 x ptr>, <8 x i64> } %3554, <8 x i64> %3553, 1
  %3556 = extractvalue { <8 x ptr>, <8 x i64> } %3555, 0
  %3557 = extractvalue { <8 x ptr>, <8 x i64> } %3555, 1
  %3558 = getelementptr i8, <8 x ptr> %3556, <8 x i64> %3557
  %3559 = zext <8 x i1> %3478 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3559, <8 x ptr> align 1 %3558, <8 x i1> %convergence.cascade.result531)
  %3560 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3561 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3562 = add <8 x i64> %3561, splat (i64 7)
  %3563 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3560, 0
  %3564 = insertvalue { <8 x ptr>, <8 x i64> } %3563, <8 x i64> %3562, 1
  %3565 = extractvalue { <8 x ptr>, <8 x i64> } %3564, 0
  %3566 = extractvalue { <8 x ptr>, <8 x i64> } %3564, 1
  %3567 = getelementptr i8, <8 x ptr> %3565, <8 x i64> %3566
  %3568 = zext <8 x i1> %3479 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3568, <8 x ptr> align 1 %3567, <8 x i1> %convergence.cascade.result531)
  %3569 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3570 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3571 = add <8 x i64> %3570, splat (i64 8)
  %3572 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3569, 0
  %3573 = insertvalue { <8 x ptr>, <8 x i64> } %3572, <8 x i64> %3571, 1
  %3574 = extractvalue { <8 x ptr>, <8 x i64> } %3573, 0
  %3575 = extractvalue { <8 x ptr>, <8 x i64> } %3573, 1
  %3576 = getelementptr i8, <8 x ptr> %3574, <8 x i64> %3575
  %3577 = zext <8 x i1> %3480 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3577, <8 x ptr> align 1 %3576, <8 x i1> %convergence.cascade.result531)
  %3578 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3579 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3580 = add <8 x i64> %3579, splat (i64 9)
  %3581 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3578, 0
  %3582 = insertvalue { <8 x ptr>, <8 x i64> } %3581, <8 x i64> %3580, 1
  %3583 = extractvalue { <8 x ptr>, <8 x i64> } %3582, 0
  %3584 = extractvalue { <8 x ptr>, <8 x i64> } %3582, 1
  %3585 = getelementptr i8, <8 x ptr> %3583, <8 x i64> %3584
  %3586 = zext <8 x i1> %3481 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3586, <8 x ptr> align 1 %3585, <8 x i1> %convergence.cascade.result531)
  %3587 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3588 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3589 = add <8 x i64> %3588, splat (i64 10)
  %3590 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3587, 0
  %3591 = insertvalue { <8 x ptr>, <8 x i64> } %3590, <8 x i64> %3589, 1
  %3592 = extractvalue { <8 x ptr>, <8 x i64> } %3591, 0
  %3593 = extractvalue { <8 x ptr>, <8 x i64> } %3591, 1
  %3594 = getelementptr i8, <8 x ptr> %3592, <8 x i64> %3593
  %3595 = zext <8 x i1> %3482 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3595, <8 x ptr> align 1 %3594, <8 x i1> %convergence.cascade.result531)
  %3596 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3597 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3598 = add <8 x i64> %3597, splat (i64 11)
  %3599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3596, 0
  %3600 = insertvalue { <8 x ptr>, <8 x i64> } %3599, <8 x i64> %3598, 1
  %3601 = extractvalue { <8 x ptr>, <8 x i64> } %3600, 0
  %3602 = extractvalue { <8 x ptr>, <8 x i64> } %3600, 1
  %3603 = getelementptr i8, <8 x ptr> %3601, <8 x i64> %3602
  %3604 = zext <8 x i1> %3483 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3604, <8 x ptr> align 1 %3603, <8 x i1> %convergence.cascade.result531)
  %3605 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3606 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3607 = add <8 x i64> %3606, splat (i64 12)
  %3608 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3605, 0
  %3609 = insertvalue { <8 x ptr>, <8 x i64> } %3608, <8 x i64> %3607, 1
  %3610 = extractvalue { <8 x ptr>, <8 x i64> } %3609, 0
  %3611 = extractvalue { <8 x ptr>, <8 x i64> } %3609, 1
  %3612 = getelementptr i8, <8 x ptr> %3610, <8 x i64> %3611
  %3613 = zext <8 x i1> %3484 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3613, <8 x ptr> align 1 %3612, <8 x i1> %convergence.cascade.result531)
  %3614 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3615 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3616 = add <8 x i64> %3615, splat (i64 13)
  %3617 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3614, 0
  %3618 = insertvalue { <8 x ptr>, <8 x i64> } %3617, <8 x i64> %3616, 1
  %3619 = extractvalue { <8 x ptr>, <8 x i64> } %3618, 0
  %3620 = extractvalue { <8 x ptr>, <8 x i64> } %3618, 1
  %3621 = getelementptr i8, <8 x ptr> %3619, <8 x i64> %3620
  %3622 = zext <8 x i1> %3485 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3622, <8 x ptr> align 1 %3621, <8 x i1> %convergence.cascade.result531)
  %3623 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3624 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3625 = add <8 x i64> %3624, splat (i64 14)
  %3626 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3623, 0
  %3627 = insertvalue { <8 x ptr>, <8 x i64> } %3626, <8 x i64> %3625, 1
  %3628 = extractvalue { <8 x ptr>, <8 x i64> } %3627, 0
  %3629 = extractvalue { <8 x ptr>, <8 x i64> } %3627, 1
  %3630 = getelementptr i8, <8 x ptr> %3628, <8 x i64> %3629
  %3631 = zext <8 x i1> %3486 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3631, <8 x ptr> align 1 %3630, <8 x i1> %convergence.cascade.result531)
  %3632 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3633 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3634 = add <8 x i64> %3633, splat (i64 15)
  %3635 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3632, 0
  %3636 = insertvalue { <8 x ptr>, <8 x i64> } %3635, <8 x i64> %3634, 1
  %3637 = extractvalue { <8 x ptr>, <8 x i64> } %3636, 0
  %3638 = extractvalue { <8 x ptr>, <8 x i64> } %3636, 1
  %3639 = getelementptr i8, <8 x ptr> %3637, <8 x i64> %3638
  %3640 = zext <8 x i1> %3487 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3640, <8 x ptr> align 1 %3639, <8 x i1> %convergence.cascade.result531)
  %3641 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %3642 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3643 = extractvalue { <8 x ptr>, <8 x i64> } %3641, 0
  %3644 = select <8 x i1> %convergence.cascade.result531, <8 x ptr> %3642, <8 x ptr> %3643
  %3645 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3646 = extractvalue { <8 x ptr>, <8 x i64> } %3641, 1
  %3647 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3645, <8 x i64> %3646
  %3648 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3644, 0
  %3649 = insertvalue { <8 x ptr>, <8 x i64> } %3648, <8 x i64> %3647, 1
  store { <8 x ptr>, <8 x i64> } %3649, ptr %tile_snapshot.spill112, align 64
  %3650 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3651 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3652 = add <8 x i64> %3651, zeroinitializer
  %3653 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3650, 0
  %3654 = insertvalue { <8 x ptr>, <8 x i64> } %3653, <8 x i64> %3652, 1
  %3655 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3656 = extractvalue { <8 x ptr>, <8 x i64> } %3654, 1
  %3657 = extractelement <8 x ptr> %3655, i32 0
  %3658 = extractelement <8 x i64> %3656, i32 %3455
  %3659 = zext i32 %3455 to i64
  %3660 = mul i64 %3659, 8
  %3661 = sub i64 %3658, %3660
  %3662 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3663 = select i1 %3662, i64 %3661, i64 0
  %private.contiguous.address = getelementptr i8, ptr %3657, i64 %3663
  %private.contiguous.preserve = load <8 x i64>, ptr %private.contiguous.address, align 8
  %3664 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3456, <8 x i64> %private.contiguous.preserve
  store <8 x i64> %3664, ptr %private.contiguous.address, align 8
  %3665 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3666 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3667 = add <8 x i64> %3666, splat (i64 64)
  %3668 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3665, 0
  %3669 = insertvalue { <8 x ptr>, <8 x i64> } %3668, <8 x i64> %3667, 1
  %3670 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3671 = extractvalue { <8 x ptr>, <8 x i64> } %3669, 1
  %3672 = extractelement <8 x ptr> %3670, i32 0
  %3673 = extractelement <8 x i64> %3671, i32 %3455
  %3674 = zext i32 %3455 to i64
  %3675 = mul i64 %3674, 8
  %3676 = sub i64 %3673, %3675
  %3677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3678 = select i1 %3677, i64 %3676, i64 0
  %private.contiguous.address548 = getelementptr i8, ptr %3672, i64 %3678
  %private.contiguous.preserve549 = load <8 x i64>, ptr %private.contiguous.address548, align 8
  %3679 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3457, <8 x i64> %private.contiguous.preserve549
  store <8 x i64> %3679, ptr %private.contiguous.address548, align 8
  %3680 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3681 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3682 = add <8 x i64> %3681, splat (i64 128)
  %3683 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3680, 0
  %3684 = insertvalue { <8 x ptr>, <8 x i64> } %3683, <8 x i64> %3682, 1
  %3685 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3686 = extractvalue { <8 x ptr>, <8 x i64> } %3684, 1
  %3687 = extractelement <8 x ptr> %3685, i32 0
  %3688 = extractelement <8 x i64> %3686, i32 %3455
  %3689 = zext i32 %3455 to i64
  %3690 = mul i64 %3689, 8
  %3691 = sub i64 %3688, %3690
  %3692 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3693 = select i1 %3692, i64 %3691, i64 0
  %private.contiguous.address550 = getelementptr i8, ptr %3687, i64 %3693
  %private.contiguous.preserve551 = load <8 x i64>, ptr %private.contiguous.address550, align 8
  %3694 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3458, <8 x i64> %private.contiguous.preserve551
  store <8 x i64> %3694, ptr %private.contiguous.address550, align 8
  %3695 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3696 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3697 = add <8 x i64> %3696, splat (i64 192)
  %3698 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3695, 0
  %3699 = insertvalue { <8 x ptr>, <8 x i64> } %3698, <8 x i64> %3697, 1
  %3700 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3701 = extractvalue { <8 x ptr>, <8 x i64> } %3699, 1
  %3702 = extractelement <8 x ptr> %3700, i32 0
  %3703 = extractelement <8 x i64> %3701, i32 %3455
  %3704 = zext i32 %3455 to i64
  %3705 = mul i64 %3704, 8
  %3706 = sub i64 %3703, %3705
  %3707 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3708 = select i1 %3707, i64 %3706, i64 0
  %private.contiguous.address552 = getelementptr i8, ptr %3702, i64 %3708
  %private.contiguous.preserve553 = load <8 x i64>, ptr %private.contiguous.address552, align 8
  %3709 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3459, <8 x i64> %private.contiguous.preserve553
  store <8 x i64> %3709, ptr %private.contiguous.address552, align 8
  %3710 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3711 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3712 = add <8 x i64> %3711, splat (i64 256)
  %3713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3710, 0
  %3714 = insertvalue { <8 x ptr>, <8 x i64> } %3713, <8 x i64> %3712, 1
  %3715 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3716 = extractvalue { <8 x ptr>, <8 x i64> } %3714, 1
  %3717 = extractelement <8 x ptr> %3715, i32 0
  %3718 = extractelement <8 x i64> %3716, i32 %3455
  %3719 = zext i32 %3455 to i64
  %3720 = mul i64 %3719, 8
  %3721 = sub i64 %3718, %3720
  %3722 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3723 = select i1 %3722, i64 %3721, i64 0
  %private.contiguous.address554 = getelementptr i8, ptr %3717, i64 %3723
  %private.contiguous.preserve555 = load <8 x i64>, ptr %private.contiguous.address554, align 8
  %3724 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3460, <8 x i64> %private.contiguous.preserve555
  store <8 x i64> %3724, ptr %private.contiguous.address554, align 8
  %3725 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3726 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3727 = add <8 x i64> %3726, splat (i64 320)
  %3728 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3725, 0
  %3729 = insertvalue { <8 x ptr>, <8 x i64> } %3728, <8 x i64> %3727, 1
  %3730 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3731 = extractvalue { <8 x ptr>, <8 x i64> } %3729, 1
  %3732 = extractelement <8 x ptr> %3730, i32 0
  %3733 = extractelement <8 x i64> %3731, i32 %3455
  %3734 = zext i32 %3455 to i64
  %3735 = mul i64 %3734, 8
  %3736 = sub i64 %3733, %3735
  %3737 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3738 = select i1 %3737, i64 %3736, i64 0
  %private.contiguous.address556 = getelementptr i8, ptr %3732, i64 %3738
  %private.contiguous.preserve557 = load <8 x i64>, ptr %private.contiguous.address556, align 8
  %3739 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3461, <8 x i64> %private.contiguous.preserve557
  store <8 x i64> %3739, ptr %private.contiguous.address556, align 8
  %3740 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3741 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3742 = add <8 x i64> %3741, splat (i64 384)
  %3743 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3740, 0
  %3744 = insertvalue { <8 x ptr>, <8 x i64> } %3743, <8 x i64> %3742, 1
  %3745 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3746 = extractvalue { <8 x ptr>, <8 x i64> } %3744, 1
  %3747 = extractelement <8 x ptr> %3745, i32 0
  %3748 = extractelement <8 x i64> %3746, i32 %3455
  %3749 = zext i32 %3455 to i64
  %3750 = mul i64 %3749, 8
  %3751 = sub i64 %3748, %3750
  %3752 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3753 = select i1 %3752, i64 %3751, i64 0
  %private.contiguous.address558 = getelementptr i8, ptr %3747, i64 %3753
  %private.contiguous.preserve559 = load <8 x i64>, ptr %private.contiguous.address558, align 8
  %3754 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3462, <8 x i64> %private.contiguous.preserve559
  store <8 x i64> %3754, ptr %private.contiguous.address558, align 8
  %3755 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3756 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3757 = add <8 x i64> %3756, splat (i64 448)
  %3758 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3755, 0
  %3759 = insertvalue { <8 x ptr>, <8 x i64> } %3758, <8 x i64> %3757, 1
  %3760 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3761 = extractvalue { <8 x ptr>, <8 x i64> } %3759, 1
  %3762 = extractelement <8 x ptr> %3760, i32 0
  %3763 = extractelement <8 x i64> %3761, i32 %3455
  %3764 = zext i32 %3455 to i64
  %3765 = mul i64 %3764, 8
  %3766 = sub i64 %3763, %3765
  %3767 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3768 = select i1 %3767, i64 %3766, i64 0
  %private.contiguous.address560 = getelementptr i8, ptr %3762, i64 %3768
  %private.contiguous.preserve561 = load <8 x i64>, ptr %private.contiguous.address560, align 8
  %3769 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3463, <8 x i64> %private.contiguous.preserve561
  store <8 x i64> %3769, ptr %private.contiguous.address560, align 8
  %3770 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3771 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3772 = add <8 x i64> %3771, splat (i64 512)
  %3773 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3770, 0
  %3774 = insertvalue { <8 x ptr>, <8 x i64> } %3773, <8 x i64> %3772, 1
  %3775 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3776 = extractvalue { <8 x ptr>, <8 x i64> } %3774, 1
  %3777 = extractelement <8 x ptr> %3775, i32 0
  %3778 = extractelement <8 x i64> %3776, i32 %3455
  %3779 = zext i32 %3455 to i64
  %3780 = mul i64 %3779, 8
  %3781 = sub i64 %3778, %3780
  %3782 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3783 = select i1 %3782, i64 %3781, i64 0
  %private.contiguous.address562 = getelementptr i8, ptr %3777, i64 %3783
  %private.contiguous.preserve563 = load <8 x i64>, ptr %private.contiguous.address562, align 8
  %3784 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3464, <8 x i64> %private.contiguous.preserve563
  store <8 x i64> %3784, ptr %private.contiguous.address562, align 8
  %3785 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3786 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3787 = add <8 x i64> %3786, splat (i64 576)
  %3788 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3785, 0
  %3789 = insertvalue { <8 x ptr>, <8 x i64> } %3788, <8 x i64> %3787, 1
  %3790 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3791 = extractvalue { <8 x ptr>, <8 x i64> } %3789, 1
  %3792 = extractelement <8 x ptr> %3790, i32 0
  %3793 = extractelement <8 x i64> %3791, i32 %3455
  %3794 = zext i32 %3455 to i64
  %3795 = mul i64 %3794, 8
  %3796 = sub i64 %3793, %3795
  %3797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3798 = select i1 %3797, i64 %3796, i64 0
  %private.contiguous.address564 = getelementptr i8, ptr %3792, i64 %3798
  %private.contiguous.preserve565 = load <8 x i64>, ptr %private.contiguous.address564, align 8
  %3799 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3465, <8 x i64> %private.contiguous.preserve565
  store <8 x i64> %3799, ptr %private.contiguous.address564, align 8
  %3800 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3801 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3802 = add <8 x i64> %3801, splat (i64 640)
  %3803 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3800, 0
  %3804 = insertvalue { <8 x ptr>, <8 x i64> } %3803, <8 x i64> %3802, 1
  %3805 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3806 = extractvalue { <8 x ptr>, <8 x i64> } %3804, 1
  %3807 = extractelement <8 x ptr> %3805, i32 0
  %3808 = extractelement <8 x i64> %3806, i32 %3455
  %3809 = zext i32 %3455 to i64
  %3810 = mul i64 %3809, 8
  %3811 = sub i64 %3808, %3810
  %3812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3813 = select i1 %3812, i64 %3811, i64 0
  %private.contiguous.address566 = getelementptr i8, ptr %3807, i64 %3813
  %private.contiguous.preserve567 = load <8 x i64>, ptr %private.contiguous.address566, align 8
  %3814 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3466, <8 x i64> %private.contiguous.preserve567
  store <8 x i64> %3814, ptr %private.contiguous.address566, align 8
  %3815 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3816 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3817 = add <8 x i64> %3816, splat (i64 704)
  %3818 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3815, 0
  %3819 = insertvalue { <8 x ptr>, <8 x i64> } %3818, <8 x i64> %3817, 1
  %3820 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3821 = extractvalue { <8 x ptr>, <8 x i64> } %3819, 1
  %3822 = extractelement <8 x ptr> %3820, i32 0
  %3823 = extractelement <8 x i64> %3821, i32 %3455
  %3824 = zext i32 %3455 to i64
  %3825 = mul i64 %3824, 8
  %3826 = sub i64 %3823, %3825
  %3827 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3828 = select i1 %3827, i64 %3826, i64 0
  %private.contiguous.address568 = getelementptr i8, ptr %3822, i64 %3828
  %private.contiguous.preserve569 = load <8 x i64>, ptr %private.contiguous.address568, align 8
  %3829 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3467, <8 x i64> %private.contiguous.preserve569
  store <8 x i64> %3829, ptr %private.contiguous.address568, align 8
  %3830 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3831 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3832 = add <8 x i64> %3831, splat (i64 768)
  %3833 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3830, 0
  %3834 = insertvalue { <8 x ptr>, <8 x i64> } %3833, <8 x i64> %3832, 1
  %3835 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3836 = extractvalue { <8 x ptr>, <8 x i64> } %3834, 1
  %3837 = extractelement <8 x ptr> %3835, i32 0
  %3838 = extractelement <8 x i64> %3836, i32 %3455
  %3839 = zext i32 %3455 to i64
  %3840 = mul i64 %3839, 8
  %3841 = sub i64 %3838, %3840
  %3842 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3843 = select i1 %3842, i64 %3841, i64 0
  %private.contiguous.address570 = getelementptr i8, ptr %3837, i64 %3843
  %private.contiguous.preserve571 = load <8 x i64>, ptr %private.contiguous.address570, align 8
  %3844 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3468, <8 x i64> %private.contiguous.preserve571
  store <8 x i64> %3844, ptr %private.contiguous.address570, align 8
  %3845 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3846 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3847 = add <8 x i64> %3846, splat (i64 832)
  %3848 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3845, 0
  %3849 = insertvalue { <8 x ptr>, <8 x i64> } %3848, <8 x i64> %3847, 1
  %3850 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3851 = extractvalue { <8 x ptr>, <8 x i64> } %3849, 1
  %3852 = extractelement <8 x ptr> %3850, i32 0
  %3853 = extractelement <8 x i64> %3851, i32 %3455
  %3854 = zext i32 %3455 to i64
  %3855 = mul i64 %3854, 8
  %3856 = sub i64 %3853, %3855
  %3857 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3858 = select i1 %3857, i64 %3856, i64 0
  %private.contiguous.address572 = getelementptr i8, ptr %3852, i64 %3858
  %private.contiguous.preserve573 = load <8 x i64>, ptr %private.contiguous.address572, align 8
  %3859 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3469, <8 x i64> %private.contiguous.preserve573
  store <8 x i64> %3859, ptr %private.contiguous.address572, align 8
  %3860 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3861 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3862 = add <8 x i64> %3861, splat (i64 896)
  %3863 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3860, 0
  %3864 = insertvalue { <8 x ptr>, <8 x i64> } %3863, <8 x i64> %3862, 1
  %3865 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3866 = extractvalue { <8 x ptr>, <8 x i64> } %3864, 1
  %3867 = extractelement <8 x ptr> %3865, i32 0
  %3868 = extractelement <8 x i64> %3866, i32 %3455
  %3869 = zext i32 %3455 to i64
  %3870 = mul i64 %3869, 8
  %3871 = sub i64 %3868, %3870
  %3872 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3873 = select i1 %3872, i64 %3871, i64 0
  %private.contiguous.address574 = getelementptr i8, ptr %3867, i64 %3873
  %private.contiguous.preserve575 = load <8 x i64>, ptr %private.contiguous.address574, align 8
  %3874 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3470, <8 x i64> %private.contiguous.preserve575
  store <8 x i64> %3874, ptr %private.contiguous.address574, align 8
  %3875 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3876 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3877 = add <8 x i64> %3876, splat (i64 960)
  %3878 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3875, 0
  %3879 = insertvalue { <8 x ptr>, <8 x i64> } %3878, <8 x i64> %3877, 1
  %3880 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3881 = extractvalue { <8 x ptr>, <8 x i64> } %3879, 1
  %3882 = extractelement <8 x ptr> %3880, i32 0
  %3883 = extractelement <8 x i64> %3881, i32 %3455
  %3884 = zext i32 %3455 to i64
  %3885 = mul i64 %3884, 8
  %3886 = sub i64 %3883, %3885
  %3887 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3888 = select i1 %3887, i64 %3886, i64 0
  %private.contiguous.address576 = getelementptr i8, ptr %3882, i64 %3888
  %private.contiguous.preserve577 = load <8 x i64>, ptr %private.contiguous.address576, align 8
  %3889 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3471, <8 x i64> %private.contiguous.preserve577
  store <8 x i64> %3889, ptr %private.contiguous.address576, align 8
  %.spill.load578 = load <8 x i64>, ptr %.spill61, align 64
  %3890 = add <8 x i64> zeroinitializer, %.spill.load578
  %.spill.load579 = load <8 x i64>, ptr %.spill61, align 64
  %3891 = add <8 x i64> splat (i64 1), %.spill.load579
  %.spill.load580 = load <8 x i64>, ptr %.spill61, align 64
  %3892 = add <8 x i64> splat (i64 2), %.spill.load580
  %.spill.load581 = load <8 x i64>, ptr %.spill61, align 64
  %3893 = add <8 x i64> splat (i64 3), %.spill.load581
  %.spill.load582 = load <8 x i64>, ptr %.spill61, align 64
  %3894 = add <8 x i64> splat (i64 4), %.spill.load582
  %.spill.load583 = load <8 x i64>, ptr %.spill61, align 64
  %3895 = add <8 x i64> splat (i64 5), %.spill.load583
  %.spill.load584 = load <8 x i64>, ptr %.spill61, align 64
  %3896 = add <8 x i64> splat (i64 6), %.spill.load584
  %.spill.load585 = load <8 x i64>, ptr %.spill61, align 64
  %3897 = add <8 x i64> splat (i64 7), %.spill.load585
  %3898 = add <8 x i64> %3890, splat (i64 131)
  %3899 = add <8 x i64> %3891, splat (i64 131)
  %3900 = add <8 x i64> %3892, splat (i64 131)
  %3901 = add <8 x i64> %3893, splat (i64 131)
  %3902 = add <8 x i64> %3894, splat (i64 131)
  %3903 = add <8 x i64> %3895, splat (i64 131)
  %3904 = add <8 x i64> %3896, splat (i64 131)
  %3905 = add <8 x i64> %3897, splat (i64 131)
  %3906 = sub <8 x i64> %3898, splat (i64 33)
  %3907 = sub <8 x i64> %3899, splat (i64 33)
  %3908 = sub <8 x i64> %3900, splat (i64 33)
  %3909 = sub <8 x i64> %3901, splat (i64 33)
  %3910 = sub <8 x i64> %3902, splat (i64 33)
  %3911 = sub <8 x i64> %3903, splat (i64 33)
  %3912 = sub <8 x i64> %3904, splat (i64 33)
  %3913 = sub <8 x i64> %3905, splat (i64 33)
  %3914 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill113, align 64
  %3915 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3916 = extractvalue { <8 x ptr>, <8 x i64> } %3914, 0
  %3917 = select <8 x i1> %convergence.cascade.result531, <8 x ptr> %3915, <8 x ptr> %3916
  %3918 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3919 = extractvalue { <8 x ptr>, <8 x i64> } %3914, 1
  %3920 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3918, <8 x i64> %3919
  %3921 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3917, 0
  %3922 = insertvalue { <8 x ptr>, <8 x i64> } %3921, <8 x i64> %3920, 1
  store { <8 x ptr>, <8 x i64> } %3922, ptr %tile_snapshot.spill113, align 64
  %3923 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3924 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3925 = add <8 x i64> %3924, zeroinitializer
  %3926 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3923, 0
  %3927 = insertvalue { <8 x ptr>, <8 x i64> } %3926, <8 x i64> %3925, 1
  %3928 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3929 = extractvalue { <8 x ptr>, <8 x i64> } %3927, 1
  %3930 = extractelement <8 x ptr> %3928, i32 0
  %3931 = extractelement <8 x i64> %3929, i32 %3455
  %3932 = zext i32 %3455 to i64
  %3933 = mul i64 %3932, 8
  %3934 = sub i64 %3931, %3933
  %3935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3936 = select i1 %3935, i64 %3934, i64 0
  %private.contiguous.address586 = getelementptr i8, ptr %3930, i64 %3936
  %private.contiguous.preserve587 = load <8 x i64>, ptr %private.contiguous.address586, align 8
  %3937 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3906, <8 x i64> %private.contiguous.preserve587
  store <8 x i64> %3937, ptr %private.contiguous.address586, align 8
  %3938 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3939 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3940 = add <8 x i64> %3939, splat (i64 64)
  %3941 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3938, 0
  %3942 = insertvalue { <8 x ptr>, <8 x i64> } %3941, <8 x i64> %3940, 1
  %3943 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3944 = extractvalue { <8 x ptr>, <8 x i64> } %3942, 1
  %3945 = extractelement <8 x ptr> %3943, i32 0
  %3946 = extractelement <8 x i64> %3944, i32 %3455
  %3947 = zext i32 %3455 to i64
  %3948 = mul i64 %3947, 8
  %3949 = sub i64 %3946, %3948
  %3950 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3951 = select i1 %3950, i64 %3949, i64 0
  %private.contiguous.address588 = getelementptr i8, ptr %3945, i64 %3951
  %private.contiguous.preserve589 = load <8 x i64>, ptr %private.contiguous.address588, align 8
  %3952 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3907, <8 x i64> %private.contiguous.preserve589
  store <8 x i64> %3952, ptr %private.contiguous.address588, align 8
  %3953 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3954 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3955 = add <8 x i64> %3954, splat (i64 128)
  %3956 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3953, 0
  %3957 = insertvalue { <8 x ptr>, <8 x i64> } %3956, <8 x i64> %3955, 1
  %3958 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3959 = extractvalue { <8 x ptr>, <8 x i64> } %3957, 1
  %3960 = extractelement <8 x ptr> %3958, i32 0
  %3961 = extractelement <8 x i64> %3959, i32 %3455
  %3962 = zext i32 %3455 to i64
  %3963 = mul i64 %3962, 8
  %3964 = sub i64 %3961, %3963
  %3965 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3966 = select i1 %3965, i64 %3964, i64 0
  %private.contiguous.address590 = getelementptr i8, ptr %3960, i64 %3966
  %private.contiguous.preserve591 = load <8 x i64>, ptr %private.contiguous.address590, align 8
  %3967 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3908, <8 x i64> %private.contiguous.preserve591
  store <8 x i64> %3967, ptr %private.contiguous.address590, align 8
  %3968 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3969 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3970 = add <8 x i64> %3969, splat (i64 192)
  %3971 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3968, 0
  %3972 = insertvalue { <8 x ptr>, <8 x i64> } %3971, <8 x i64> %3970, 1
  %3973 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3974 = extractvalue { <8 x ptr>, <8 x i64> } %3972, 1
  %3975 = extractelement <8 x ptr> %3973, i32 0
  %3976 = extractelement <8 x i64> %3974, i32 %3455
  %3977 = zext i32 %3455 to i64
  %3978 = mul i64 %3977, 8
  %3979 = sub i64 %3976, %3978
  %3980 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3981 = select i1 %3980, i64 %3979, i64 0
  %private.contiguous.address592 = getelementptr i8, ptr %3975, i64 %3981
  %private.contiguous.preserve593 = load <8 x i64>, ptr %private.contiguous.address592, align 8
  %3982 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3909, <8 x i64> %private.contiguous.preserve593
  store <8 x i64> %3982, ptr %private.contiguous.address592, align 8
  %3983 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3984 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3985 = add <8 x i64> %3984, splat (i64 256)
  %3986 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3983, 0
  %3987 = insertvalue { <8 x ptr>, <8 x i64> } %3986, <8 x i64> %3985, 1
  %3988 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3989 = extractvalue { <8 x ptr>, <8 x i64> } %3987, 1
  %3990 = extractelement <8 x ptr> %3988, i32 0
  %3991 = extractelement <8 x i64> %3989, i32 %3455
  %3992 = zext i32 %3455 to i64
  %3993 = mul i64 %3992, 8
  %3994 = sub i64 %3991, %3993
  %3995 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %3996 = select i1 %3995, i64 %3994, i64 0
  %private.contiguous.address594 = getelementptr i8, ptr %3990, i64 %3996
  %private.contiguous.preserve595 = load <8 x i64>, ptr %private.contiguous.address594, align 8
  %3997 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3910, <8 x i64> %private.contiguous.preserve595
  store <8 x i64> %3997, ptr %private.contiguous.address594, align 8
  %3998 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3999 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %4000 = add <8 x i64> %3999, splat (i64 320)
  %4001 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3998, 0
  %4002 = insertvalue { <8 x ptr>, <8 x i64> } %4001, <8 x i64> %4000, 1
  %4003 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %4004 = extractvalue { <8 x ptr>, <8 x i64> } %4002, 1
  %4005 = extractelement <8 x ptr> %4003, i32 0
  %4006 = extractelement <8 x i64> %4004, i32 %3455
  %4007 = zext i32 %3455 to i64
  %4008 = mul i64 %4007, 8
  %4009 = sub i64 %4006, %4008
  %4010 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %4011 = select i1 %4010, i64 %4009, i64 0
  %private.contiguous.address596 = getelementptr i8, ptr %4005, i64 %4011
  %private.contiguous.preserve597 = load <8 x i64>, ptr %private.contiguous.address596, align 8
  %4012 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3911, <8 x i64> %private.contiguous.preserve597
  store <8 x i64> %4012, ptr %private.contiguous.address596, align 8
  %4013 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %4014 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %4015 = add <8 x i64> %4014, splat (i64 384)
  %4016 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4013, 0
  %4017 = insertvalue { <8 x ptr>, <8 x i64> } %4016, <8 x i64> %4015, 1
  %4018 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %4019 = extractvalue { <8 x ptr>, <8 x i64> } %4017, 1
  %4020 = extractelement <8 x ptr> %4018, i32 0
  %4021 = extractelement <8 x i64> %4019, i32 %3455
  %4022 = zext i32 %3455 to i64
  %4023 = mul i64 %4022, 8
  %4024 = sub i64 %4021, %4023
  %4025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %4026 = select i1 %4025, i64 %4024, i64 0
  %private.contiguous.address598 = getelementptr i8, ptr %4020, i64 %4026
  %private.contiguous.preserve599 = load <8 x i64>, ptr %private.contiguous.address598, align 8
  %4027 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3912, <8 x i64> %private.contiguous.preserve599
  store <8 x i64> %4027, ptr %private.contiguous.address598, align 8
  %4028 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %4029 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %4030 = add <8 x i64> %4029, splat (i64 448)
  %4031 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4028, 0
  %4032 = insertvalue { <8 x ptr>, <8 x i64> } %4031, <8 x i64> %4030, 1
  %4033 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %4034 = extractvalue { <8 x ptr>, <8 x i64> } %4032, 1
  %4035 = extractelement <8 x ptr> %4033, i32 0
  %4036 = extractelement <8 x i64> %4034, i32 %3455
  %4037 = zext i32 %3455 to i64
  %4038 = mul i64 %4037, 8
  %4039 = sub i64 %4036, %4038
  %4040 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  %4041 = select i1 %4040, i64 %4039, i64 0
  %private.contiguous.address600 = getelementptr i8, ptr %4035, i64 %4041
  %private.contiguous.preserve601 = load <8 x i64>, ptr %private.contiguous.address600, align 8
  %4042 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %3913, <8 x i64> %private.contiguous.preserve601
  store <8 x i64> %4042, ptr %private.contiguous.address600, align 8
  %4043 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %4044 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4045 = extractvalue { <8 x ptr>, <8 x i64> } %4043, 0
  %4046 = select <8 x i1> %convergence.cascade.result531, <8 x ptr> %4044, <8 x ptr> %4045
  %4047 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4048 = extractvalue { <8 x ptr>, <8 x i64> } %4043, 1
  %4049 = select <8 x i1> %convergence.cascade.result531, <8 x i64> %4047, <8 x i64> %4048
  %4050 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4046, 0
  %4051 = insertvalue { <8 x ptr>, <8 x i64> } %4050, <8 x i64> %4049, 1
  store { <8 x ptr>, <8 x i64> } %4051, ptr %tile_snapshot.spill114, align 64
  %4052 = load <8 x i64>, ptr %.slot115, align 64
  %4053 = select <8 x i1> %convergence.cascade.result531, <8 x i64> zeroinitializer, <8 x i64> %4052
  store <8 x i64> %4053, ptr %.slot115, align 64
  store <8 x i1> %convergence.cascade.result531, ptr %current.mask, align 1
  %4054 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result531)
  br i1 %4054, label %schedule.30, label %scheduler.loop

varying.divergent603:                             ; preds = %schedule.30
  %4055 = load i32, ptr %current.token, align 4
  %4056 = icmp ne i32 %4055, 0
  %4057 = sub i32 %4055, 1
  %4058 = select i1 %4056, i32 %4057, i32 0
  %4059 = load i8, ptr %frame.active, align 1
  %4060 = trunc i32 %4058 to i8
  %4061 = shl i8 1, %4060
  %4062 = and i8 %4059, %4061
  %4063 = icmp ne i8 %4062, 0
  %4064 = load <8 x i32>, ptr %frame.static.id, align 32
  %4065 = extractelement <8 x i32> %4064, i32 %4058
  %4066 = icmp eq i32 %4065, 11
  %4067 = and i1 %4063, %4066
  %4068 = and i1 %4056, %4067
  %4069 = xor i1 %4068, true
  %4070 = and i1 true, %4069
  %4071 = xor i8 %4059, -1
  %4072 = icmp ne i8 %4071, 0
  %4073 = xor i1 %4072, true
  %4074 = and i1 %4070, %4073
  br i1 %4074, label %convergence.overflow.trap605, label %convergence.overflow.resume606

varying.coherent604:                              ; preds = %schedule.30
  br i1 %627, label %varying.coherent.true609, label %varying.coherent.false610

convergence.overflow.trap605:                     ; preds = %varying.divergent603
  call void @llvm.trap()
  unreachable

convergence.overflow.resume606:                   ; preds = %varying.divergent603
  %4075 = call i8 @llvm.cttz.i8(i8 %4071, i1 false)
  %4076 = zext i8 %4075 to i32
  %4077 = select i1 %4072, i32 %4076, i32 0
  %4078 = trunc i32 %4077 to i8
  %4079 = shl i8 1, %4078
  %4080 = or i8 %4059, %4079
  %4081 = select i1 %4070, i8 %4080, i8 %4059
  store i8 %4081, ptr %frame.active, align 1
  %4082 = load <8 x i32>, ptr %frame.static.id, align 32
  %4083 = extractelement <8 x i32> %4082, i32 %4077
  %4084 = select i1 %4070, i32 11, i32 %4083
  %4085 = load <8 x i32>, ptr %frame.static.id, align 32
  %4086 = insertelement <8 x i32> %4085, i32 %4084, i32 %4077
  store <8 x i32> %4086, ptr %frame.static.id, align 32
  %4087 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4088 = extractelement <8 x i32> %4087, i32 %4077
  %4089 = select i1 %4070, i32 %4055, i32 %4088
  %4090 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4091 = insertelement <8 x i32> %4090, i32 %4089, i32 %4077
  store <8 x i32> %4091, ptr %frame.parent.token, align 32
  %4092 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4077
  %4093 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4077
  %4094 = load <8 x i1>, ptr %4092, align 1
  %4095 = load <8 x i1>, ptr %4093, align 1
  %4096 = select i1 %4070, <8 x i1> %617, <8 x i1> %4094
  store <8 x i1> %4096, ptr %4092, align 1
  %4097 = select i1 %4070, <8 x i1> zeroinitializer, <8 x i1> %4095
  store <8 x i1> %4097, ptr %4093, align 1
  %4098 = add i32 %4077, 1
  %4099 = select i1 %4068, i32 %4055, i32 %4098
  %4100 = select i1 true, i32 %4099, i32 %4055
  store i32 %4100, ptr %current.token, align 4
  %4101 = load i32, ptr %current.token, align 4
  %4102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %624)
  %4103 = load i32, ptr %ready.count, align 4
  %4104 = icmp uge i32 %4103, 8
  %4105 = and i1 %4102, %4104
  br i1 %4105, label %ready.overflow.trap607, label %ready.overflow.resume608

ready.overflow.trap607:                           ; preds = %convergence.overflow.resume606
  call void @llvm.trap()
  unreachable

ready.overflow.resume608:                         ; preds = %convergence.overflow.resume606
  %4106 = select i1 %4102, i32 %4103, i32 0
  %4107 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4106
  %4108 = load <8 x i1>, ptr %4107, align 1
  %4109 = select i1 %4102, <8 x i1> %624, <8 x i1> %4108
  store <8 x i1> %4109, ptr %4107, align 1
  %4110 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4106
  %4111 = load i32, ptr %4110, align 4
  %4112 = select i1 %4102, i32 31, i32 %4111
  store i32 %4112, ptr %4110, align 4
  %4113 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4106
  %4114 = load i32, ptr %4113, align 4
  %4115 = select i1 %4102, i32 %4101, i32 %4114
  store i32 %4115, ptr %4113, align 4
  %4116 = add i32 %4103, 1
  %4117 = select i1 %4102, i32 %4116, i32 %4103
  store i32 %4117, ptr %ready.count, align 4
  %4118 = load <8 x i1>, ptr %runnable.mask, align 1
  %4119 = or <8 x i1> %4118, %624
  store <8 x i1> %4119, ptr %runnable.mask, align 1
  store <8 x i1> %626, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true609:                         ; preds = %varying.coherent604
  store <8 x i1> %617, ptr %current.mask, align 1
  %4120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %617)
  br i1 %4120, label %schedule.31, label %scheduler.loop

varying.coherent.false610:                        ; preds = %varying.coherent604
  store <8 x i1> %617, ptr %current.mask, align 1
  %4121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %617)
  br i1 %4121, label %schedule.32, label %scheduler.loop

convergence.cascade619:                           ; preds = %convergence.cascade619, %schedule.32
  %convergence.cascade.flow623 = phi <8 x i1> [ %698, %schedule.32 ], [ %4164, %convergence.cascade619 ]
  %convergence.cascade.depth624 = phi i32 [ 0, %schedule.32 ], [ %4165, %convergence.cascade619 ]
  %4122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow623)
  %4123 = load i32, ptr %current.token, align 4
  %4124 = icmp ne i32 %4123, 0
  %4125 = and i1 %4122, %4124
  %4126 = sub i32 %4123, 1
  %4127 = select i1 %4125, i32 %4126, i32 0
  %4128 = load i8, ptr %frame.active, align 1
  %4129 = trunc i32 %4127 to i8
  %4130 = shl i8 1, %4129
  %4131 = and i8 %4128, %4130
  %4132 = icmp ne i8 %4131, 0
  %4133 = load <8 x i32>, ptr %frame.static.id, align 32
  %4134 = extractelement <8 x i32> %4133, i32 %4127
  %convergence.target.pointer625 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4134
  %convergence.dynamic.target626 = load i32, ptr %convergence.target.pointer625, align 4
  %4135 = icmp eq i32 %convergence.dynamic.target626, 32
  %4136 = and i1 %4132, %4135
  %4137 = and i1 %4125, %4136
  %4138 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4127
  %4139 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4127
  %4140 = load <8 x i1>, ptr %4138, align 1
  %4141 = load <8 x i1>, ptr %4139, align 1
  %4142 = or <8 x i1> %4141, %convergence.cascade.flow623
  %4143 = load <8 x i1>, ptr %live.mask, align 1
  %4144 = and <8 x i1> %4140, %4143
  %4145 = icmp eq <8 x i1> %4142, %4144
  %4146 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4145)
  %4147 = and i1 %4137, %4146
  %4148 = select i1 %4147, <8 x i1> zeroinitializer, <8 x i1> %4142
  %4149 = select i1 %4137, <8 x i1> %4148, <8 x i1> %4141
  store <8 x i1> %4149, ptr %4139, align 1
  %4150 = select i1 %4147, <8 x i1> zeroinitializer, <8 x i1> %4140
  store <8 x i1> %4150, ptr %4138, align 1
  %4151 = trunc i32 %4127 to i8
  %4152 = shl i8 1, %4151
  %4153 = xor i8 %4152, -1
  %4154 = and i8 %4128, %4153
  %4155 = select i1 %4147, i8 %4154, i8 %4128
  store i8 %4155, ptr %frame.active, align 1
  %.splatinsert627 = insertelement <8 x i1> poison, i1 %4137, i64 0
  %.splat628 = shufflevector <8 x i1> %.splatinsert627, <8 x i1> poison, <8 x i32> zeroinitializer
  %4156 = and <8 x i1> %convergence.cascade.flow623, %.splat628
  %4157 = load <8 x i1>, ptr %runnable.mask, align 1
  %4158 = xor <8 x i1> %4156, splat (i1 true)
  %4159 = and <8 x i1> %4157, %4158
  store <8 x i1> %4159, ptr %runnable.mask, align 1
  %.splatinsert629 = insertelement <8 x i1> poison, i1 %4147, i64 0
  %.splat630 = shufflevector <8 x i1> %.splatinsert629, <8 x i1> poison, <8 x i32> zeroinitializer
  %4160 = select <8 x i1> %.splat630, <8 x i1> %4142, <8 x i1> zeroinitializer
  %4161 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4162 = extractelement <8 x i32> %4161, i32 %4127
  %4163 = select i1 %4147, i32 %4162, i32 %4123
  store i32 %4163, ptr %current.token, align 4
  %.splatinsert631 = insertelement <8 x i1> poison, i1 %4137, i64 0
  %.splat632 = shufflevector <8 x i1> %.splatinsert631, <8 x i1> poison, <8 x i32> zeroinitializer
  %4164 = select <8 x i1> %.splat632, <8 x i1> %4160, <8 x i1> %convergence.cascade.flow623
  %4165 = add i32 %convergence.cascade.depth624, 1
  %4166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4164)
  %4167 = icmp ult i32 %4165, 8
  %4168 = and i1 %4166, %4167
  %4169 = and i1 %4137, %4168
  %convergence.parent.token633 = load i32, ptr %current.token, align 4
  %convergence.parent.present634 = icmp ne i32 %convergence.parent.token633, 0
  %4170 = and i1 %4169, %convergence.parent.present634
  br i1 %4170, label %convergence.cascade619, label %convergence.cascade.exit620

convergence.cascade.exit620:                      ; preds = %convergence.cascade619, %schedule.32
  %convergence.cascade.result635 = phi <8 x i1> [ %698, %schedule.32 ], [ %4164, %convergence.cascade619 ]
  %4171 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result635)
  br i1 %4171, label %convergence.target.32.ready, label %scheduler.loop

convergence.target.32.ready:                      ; preds = %convergence.cascade.exit620
  %4172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result635)
  %4173 = bitcast <8 x i1> %convergence.cascade.result635 to i8
  %4174 = call i8 @llvm.cttz.i8(i8 %4173, i1 false)
  %4175 = zext i8 %4174 to i32
  %4176 = select i1 %4172, i32 %4175, i32 0
  %4177 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %4178 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %4179 = extractvalue { <8 x ptr>, <8 x i64> } %4177, 0
  %4180 = select <8 x i1> %convergence.cascade.result635, <8 x ptr> %4178, <8 x ptr> %4179
  %4181 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %4182 = extractvalue { <8 x ptr>, <8 x i64> } %4177, 1
  %4183 = select <8 x i1> %convergence.cascade.result635, <8 x i64> %4181, <8 x i64> %4182
  %4184 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4180, 0
  %4185 = insertvalue { <8 x ptr>, <8 x i64> } %4184, <8 x i64> %4183, 1
  store { <8 x ptr>, <8 x i64> } %4185, ptr %tile_snapshot.spill116, align 64
  %4186 = load <8 x i64>, ptr %.slot117, align 64
  %4187 = select <8 x i1> %convergence.cascade.result635, <8 x i64> zeroinitializer, <8 x i64> %4186
  store <8 x i64> %4187, ptr %.slot117, align 64
  store <8 x i1> %convergence.cascade.result635, ptr %current.mask, align 1
  %4188 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result635)
  br i1 %4188, label %schedule.33, label %scheduler.loop

varying.divergent637:                             ; preds = %schedule.33
  %4189 = load i32, ptr %current.token, align 4
  %4190 = icmp ne i32 %4189, 0
  %4191 = sub i32 %4189, 1
  %4192 = select i1 %4190, i32 %4191, i32 0
  %4193 = load i8, ptr %frame.active, align 1
  %4194 = trunc i32 %4192 to i8
  %4195 = shl i8 1, %4194
  %4196 = and i8 %4193, %4195
  %4197 = icmp ne i8 %4196, 0
  %4198 = load <8 x i32>, ptr %frame.static.id, align 32
  %4199 = extractelement <8 x i32> %4198, i32 %4192
  %4200 = icmp eq i32 %4199, 12
  %4201 = and i1 %4197, %4200
  %4202 = and i1 %4190, %4201
  %4203 = xor i1 %4202, true
  %4204 = and i1 true, %4203
  %4205 = xor i8 %4193, -1
  %4206 = icmp ne i8 %4205, 0
  %4207 = xor i1 %4206, true
  %4208 = and i1 %4204, %4207
  br i1 %4208, label %convergence.overflow.trap639, label %convergence.overflow.resume640

varying.coherent638:                              ; preds = %schedule.33
  br i1 %709, label %varying.coherent.true643, label %varying.coherent.false644

convergence.overflow.trap639:                     ; preds = %varying.divergent637
  call void @llvm.trap()
  unreachable

convergence.overflow.resume640:                   ; preds = %varying.divergent637
  %4209 = call i8 @llvm.cttz.i8(i8 %4205, i1 false)
  %4210 = zext i8 %4209 to i32
  %4211 = select i1 %4206, i32 %4210, i32 0
  %4212 = trunc i32 %4211 to i8
  %4213 = shl i8 1, %4212
  %4214 = or i8 %4193, %4213
  %4215 = select i1 %4204, i8 %4214, i8 %4193
  store i8 %4215, ptr %frame.active, align 1
  %4216 = load <8 x i32>, ptr %frame.static.id, align 32
  %4217 = extractelement <8 x i32> %4216, i32 %4211
  %4218 = select i1 %4204, i32 12, i32 %4217
  %4219 = load <8 x i32>, ptr %frame.static.id, align 32
  %4220 = insertelement <8 x i32> %4219, i32 %4218, i32 %4211
  store <8 x i32> %4220, ptr %frame.static.id, align 32
  %4221 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4222 = extractelement <8 x i32> %4221, i32 %4211
  %4223 = select i1 %4204, i32 %4189, i32 %4222
  %4224 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4225 = insertelement <8 x i32> %4224, i32 %4223, i32 %4211
  store <8 x i32> %4225, ptr %frame.parent.token, align 32
  %4226 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4211
  %4227 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4211
  %4228 = load <8 x i1>, ptr %4226, align 1
  %4229 = load <8 x i1>, ptr %4227, align 1
  %4230 = select i1 %4204, <8 x i1> %699, <8 x i1> %4228
  store <8 x i1> %4230, ptr %4226, align 1
  %4231 = select i1 %4204, <8 x i1> zeroinitializer, <8 x i1> %4229
  store <8 x i1> %4231, ptr %4227, align 1
  %4232 = add i32 %4211, 1
  %4233 = select i1 %4202, i32 %4189, i32 %4232
  %4234 = select i1 true, i32 %4233, i32 %4189
  store i32 %4234, ptr %current.token, align 4
  %4235 = load i32, ptr %current.token, align 4
  %4236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %706)
  %4237 = load i32, ptr %ready.count, align 4
  %4238 = icmp uge i32 %4237, 8
  %4239 = and i1 %4236, %4238
  br i1 %4239, label %ready.overflow.trap641, label %ready.overflow.resume642

ready.overflow.trap641:                           ; preds = %convergence.overflow.resume640
  call void @llvm.trap()
  unreachable

ready.overflow.resume642:                         ; preds = %convergence.overflow.resume640
  %4240 = select i1 %4236, i32 %4237, i32 0
  %4241 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4240
  %4242 = load <8 x i1>, ptr %4241, align 1
  %4243 = select i1 %4236, <8 x i1> %706, <8 x i1> %4242
  store <8 x i1> %4243, ptr %4241, align 1
  %4244 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4240
  %4245 = load i32, ptr %4244, align 4
  %4246 = select i1 %4236, i32 34, i32 %4245
  store i32 %4246, ptr %4244, align 4
  %4247 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4240
  %4248 = load i32, ptr %4247, align 4
  %4249 = select i1 %4236, i32 %4235, i32 %4248
  store i32 %4249, ptr %4247, align 4
  %4250 = add i32 %4237, 1
  %4251 = select i1 %4236, i32 %4250, i32 %4237
  store i32 %4251, ptr %ready.count, align 4
  %4252 = load <8 x i1>, ptr %runnable.mask, align 1
  %4253 = or <8 x i1> %4252, %706
  store <8 x i1> %4253, ptr %runnable.mask, align 1
  store <8 x i1> %708, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true643:                         ; preds = %varying.coherent638
  store <8 x i1> %699, ptr %current.mask, align 1
  %4254 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %699)
  br i1 %4254, label %schedule.34, label %scheduler.loop

varying.coherent.false644:                        ; preds = %varying.coherent638
  store <8 x i1> %699, ptr %current.mask, align 1
  %4255 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %699)
  br i1 %4255, label %schedule.35, label %scheduler.loop

convergence.cascade652:                           ; preds = %convergence.cascade652, %schedule.35
  %convergence.cascade.flow656 = phi <8 x i1> [ %774, %schedule.35 ], [ %4298, %convergence.cascade652 ]
  %convergence.cascade.depth657 = phi i32 [ 0, %schedule.35 ], [ %4299, %convergence.cascade652 ]
  %4256 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow656)
  %4257 = load i32, ptr %current.token, align 4
  %4258 = icmp ne i32 %4257, 0
  %4259 = and i1 %4256, %4258
  %4260 = sub i32 %4257, 1
  %4261 = select i1 %4259, i32 %4260, i32 0
  %4262 = load i8, ptr %frame.active, align 1
  %4263 = trunc i32 %4261 to i8
  %4264 = shl i8 1, %4263
  %4265 = and i8 %4262, %4264
  %4266 = icmp ne i8 %4265, 0
  %4267 = load <8 x i32>, ptr %frame.static.id, align 32
  %4268 = extractelement <8 x i32> %4267, i32 %4261
  %convergence.target.pointer658 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4268
  %convergence.dynamic.target659 = load i32, ptr %convergence.target.pointer658, align 4
  %4269 = icmp eq i32 %convergence.dynamic.target659, 35
  %4270 = and i1 %4266, %4269
  %4271 = and i1 %4259, %4270
  %4272 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4261
  %4273 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4261
  %4274 = load <8 x i1>, ptr %4272, align 1
  %4275 = load <8 x i1>, ptr %4273, align 1
  %4276 = or <8 x i1> %4275, %convergence.cascade.flow656
  %4277 = load <8 x i1>, ptr %live.mask, align 1
  %4278 = and <8 x i1> %4274, %4277
  %4279 = icmp eq <8 x i1> %4276, %4278
  %4280 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4279)
  %4281 = and i1 %4271, %4280
  %4282 = select i1 %4281, <8 x i1> zeroinitializer, <8 x i1> %4276
  %4283 = select i1 %4271, <8 x i1> %4282, <8 x i1> %4275
  store <8 x i1> %4283, ptr %4273, align 1
  %4284 = select i1 %4281, <8 x i1> zeroinitializer, <8 x i1> %4274
  store <8 x i1> %4284, ptr %4272, align 1
  %4285 = trunc i32 %4261 to i8
  %4286 = shl i8 1, %4285
  %4287 = xor i8 %4286, -1
  %4288 = and i8 %4262, %4287
  %4289 = select i1 %4281, i8 %4288, i8 %4262
  store i8 %4289, ptr %frame.active, align 1
  %.splatinsert660 = insertelement <8 x i1> poison, i1 %4271, i64 0
  %.splat661 = shufflevector <8 x i1> %.splatinsert660, <8 x i1> poison, <8 x i32> zeroinitializer
  %4290 = and <8 x i1> %convergence.cascade.flow656, %.splat661
  %4291 = load <8 x i1>, ptr %runnable.mask, align 1
  %4292 = xor <8 x i1> %4290, splat (i1 true)
  %4293 = and <8 x i1> %4291, %4292
  store <8 x i1> %4293, ptr %runnable.mask, align 1
  %.splatinsert662 = insertelement <8 x i1> poison, i1 %4281, i64 0
  %.splat663 = shufflevector <8 x i1> %.splatinsert662, <8 x i1> poison, <8 x i32> zeroinitializer
  %4294 = select <8 x i1> %.splat663, <8 x i1> %4276, <8 x i1> zeroinitializer
  %4295 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4296 = extractelement <8 x i32> %4295, i32 %4261
  %4297 = select i1 %4281, i32 %4296, i32 %4257
  store i32 %4297, ptr %current.token, align 4
  %.splatinsert664 = insertelement <8 x i1> poison, i1 %4271, i64 0
  %.splat665 = shufflevector <8 x i1> %.splatinsert664, <8 x i1> poison, <8 x i32> zeroinitializer
  %4298 = select <8 x i1> %.splat665, <8 x i1> %4294, <8 x i1> %convergence.cascade.flow656
  %4299 = add i32 %convergence.cascade.depth657, 1
  %4300 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4298)
  %4301 = icmp ult i32 %4299, 8
  %4302 = and i1 %4300, %4301
  %4303 = and i1 %4271, %4302
  %convergence.parent.token666 = load i32, ptr %current.token, align 4
  %convergence.parent.present667 = icmp ne i32 %convergence.parent.token666, 0
  %4304 = and i1 %4303, %convergence.parent.present667
  br i1 %4304, label %convergence.cascade652, label %convergence.cascade.exit653

convergence.cascade.exit653:                      ; preds = %convergence.cascade652, %schedule.35
  %convergence.cascade.result668 = phi <8 x i1> [ %774, %schedule.35 ], [ %4298, %convergence.cascade652 ]
  %4305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result668)
  br i1 %4305, label %convergence.target.35.ready, label %scheduler.loop

convergence.target.35.ready:                      ; preds = %convergence.cascade.exit653
  %4306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result668)
  %4307 = bitcast <8 x i1> %convergence.cascade.result668 to i8
  %4308 = call i8 @llvm.cttz.i8(i8 %4307, i1 false)
  %4309 = zext i8 %4308 to i32
  %4310 = select i1 %4306, i32 %4309, i32 0
  %4311 = load <8 x i64>, ptr %.slot118, align 64
  %4312 = select <8 x i1> %convergence.cascade.result668, <8 x i64> zeroinitializer, <8 x i64> %4311
  store <8 x i64> %4312, ptr %.slot118, align 64
  %4313 = load <8 x float>, ptr %.slot119, align 32
  %4314 = select <8 x i1> %convergence.cascade.result668, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4313
  store <8 x float> %4314, ptr %.slot119, align 32
  store <8 x i1> %convergence.cascade.result668, ptr %current.mask, align 1
  %4315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result668)
  br i1 %4315, label %schedule.36, label %scheduler.loop

varying.divergent670:                             ; preds = %schedule.36
  %4316 = load i32, ptr %current.token, align 4
  %4317 = icmp ne i32 %4316, 0
  %4318 = sub i32 %4316, 1
  %4319 = select i1 %4317, i32 %4318, i32 0
  %4320 = load i8, ptr %frame.active, align 1
  %4321 = trunc i32 %4319 to i8
  %4322 = shl i8 1, %4321
  %4323 = and i8 %4320, %4322
  %4324 = icmp ne i8 %4323, 0
  %4325 = load <8 x i32>, ptr %frame.static.id, align 32
  %4326 = extractelement <8 x i32> %4325, i32 %4319
  %4327 = icmp eq i32 %4326, 13
  %4328 = and i1 %4324, %4327
  %4329 = and i1 %4317, %4328
  %4330 = xor i1 %4329, true
  %4331 = and i1 true, %4330
  %4332 = xor i8 %4320, -1
  %4333 = icmp ne i8 %4332, 0
  %4334 = xor i1 %4333, true
  %4335 = and i1 %4331, %4334
  br i1 %4335, label %convergence.overflow.trap672, label %convergence.overflow.resume673

varying.coherent671:                              ; preds = %schedule.36
  br i1 %785, label %varying.coherent.true676, label %varying.coherent.false677

convergence.overflow.trap672:                     ; preds = %varying.divergent670
  call void @llvm.trap()
  unreachable

convergence.overflow.resume673:                   ; preds = %varying.divergent670
  %4336 = call i8 @llvm.cttz.i8(i8 %4332, i1 false)
  %4337 = zext i8 %4336 to i32
  %4338 = select i1 %4333, i32 %4337, i32 0
  %4339 = trunc i32 %4338 to i8
  %4340 = shl i8 1, %4339
  %4341 = or i8 %4320, %4340
  %4342 = select i1 %4331, i8 %4341, i8 %4320
  store i8 %4342, ptr %frame.active, align 1
  %4343 = load <8 x i32>, ptr %frame.static.id, align 32
  %4344 = extractelement <8 x i32> %4343, i32 %4338
  %4345 = select i1 %4331, i32 13, i32 %4344
  %4346 = load <8 x i32>, ptr %frame.static.id, align 32
  %4347 = insertelement <8 x i32> %4346, i32 %4345, i32 %4338
  store <8 x i32> %4347, ptr %frame.static.id, align 32
  %4348 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4349 = extractelement <8 x i32> %4348, i32 %4338
  %4350 = select i1 %4331, i32 %4316, i32 %4349
  %4351 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4352 = insertelement <8 x i32> %4351, i32 %4350, i32 %4338
  store <8 x i32> %4352, ptr %frame.parent.token, align 32
  %4353 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4338
  %4354 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4338
  %4355 = load <8 x i1>, ptr %4353, align 1
  %4356 = load <8 x i1>, ptr %4354, align 1
  %4357 = select i1 %4331, <8 x i1> %775, <8 x i1> %4355
  store <8 x i1> %4357, ptr %4353, align 1
  %4358 = select i1 %4331, <8 x i1> zeroinitializer, <8 x i1> %4356
  store <8 x i1> %4358, ptr %4354, align 1
  %4359 = add i32 %4338, 1
  %4360 = select i1 %4329, i32 %4316, i32 %4359
  %4361 = select i1 true, i32 %4360, i32 %4316
  store i32 %4361, ptr %current.token, align 4
  %4362 = load i32, ptr %current.token, align 4
  %4363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %4364 = load i32, ptr %ready.count, align 4
  %4365 = icmp uge i32 %4364, 8
  %4366 = and i1 %4363, %4365
  br i1 %4366, label %ready.overflow.trap674, label %ready.overflow.resume675

ready.overflow.trap674:                           ; preds = %convergence.overflow.resume673
  call void @llvm.trap()
  unreachable

ready.overflow.resume675:                         ; preds = %convergence.overflow.resume673
  %4367 = select i1 %4363, i32 %4364, i32 0
  %4368 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4367
  %4369 = load <8 x i1>, ptr %4368, align 1
  %4370 = select i1 %4363, <8 x i1> %782, <8 x i1> %4369
  store <8 x i1> %4370, ptr %4368, align 1
  %4371 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4367
  %4372 = load i32, ptr %4371, align 4
  %4373 = select i1 %4363, i32 37, i32 %4372
  store i32 %4373, ptr %4371, align 4
  %4374 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4367
  %4375 = load i32, ptr %4374, align 4
  %4376 = select i1 %4363, i32 %4362, i32 %4375
  store i32 %4376, ptr %4374, align 4
  %4377 = add i32 %4364, 1
  %4378 = select i1 %4363, i32 %4377, i32 %4364
  store i32 %4378, ptr %ready.count, align 4
  %4379 = load <8 x i1>, ptr %runnable.mask, align 1
  %4380 = or <8 x i1> %4379, %782
  store <8 x i1> %4380, ptr %runnable.mask, align 1
  store <8 x i1> %784, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true676:                         ; preds = %varying.coherent671
  store <8 x i1> %775, ptr %current.mask, align 1
  %4381 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %775)
  br i1 %4381, label %schedule.37, label %scheduler.loop

varying.coherent.false677:                        ; preds = %varying.coherent671
  store <8 x i1> %775, ptr %current.mask, align 1
  %4382 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %775)
  br i1 %4382, label %schedule.38, label %scheduler.loop

convergence.cascade682:                           ; preds = %convergence.cascade682, %schedule.38
  %convergence.cascade.flow686 = phi <8 x i1> [ %815, %schedule.38 ], [ %4425, %convergence.cascade682 ]
  %convergence.cascade.depth687 = phi i32 [ 0, %schedule.38 ], [ %4426, %convergence.cascade682 ]
  %4383 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow686)
  %4384 = load i32, ptr %current.token, align 4
  %4385 = icmp ne i32 %4384, 0
  %4386 = and i1 %4383, %4385
  %4387 = sub i32 %4384, 1
  %4388 = select i1 %4386, i32 %4387, i32 0
  %4389 = load i8, ptr %frame.active, align 1
  %4390 = trunc i32 %4388 to i8
  %4391 = shl i8 1, %4390
  %4392 = and i8 %4389, %4391
  %4393 = icmp ne i8 %4392, 0
  %4394 = load <8 x i32>, ptr %frame.static.id, align 32
  %4395 = extractelement <8 x i32> %4394, i32 %4388
  %convergence.target.pointer688 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4395
  %convergence.dynamic.target689 = load i32, ptr %convergence.target.pointer688, align 4
  %4396 = icmp eq i32 %convergence.dynamic.target689, 38
  %4397 = and i1 %4393, %4396
  %4398 = and i1 %4386, %4397
  %4399 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4388
  %4400 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4388
  %4401 = load <8 x i1>, ptr %4399, align 1
  %4402 = load <8 x i1>, ptr %4400, align 1
  %4403 = or <8 x i1> %4402, %convergence.cascade.flow686
  %4404 = load <8 x i1>, ptr %live.mask, align 1
  %4405 = and <8 x i1> %4401, %4404
  %4406 = icmp eq <8 x i1> %4403, %4405
  %4407 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4406)
  %4408 = and i1 %4398, %4407
  %4409 = select i1 %4408, <8 x i1> zeroinitializer, <8 x i1> %4403
  %4410 = select i1 %4398, <8 x i1> %4409, <8 x i1> %4402
  store <8 x i1> %4410, ptr %4400, align 1
  %4411 = select i1 %4408, <8 x i1> zeroinitializer, <8 x i1> %4401
  store <8 x i1> %4411, ptr %4399, align 1
  %4412 = trunc i32 %4388 to i8
  %4413 = shl i8 1, %4412
  %4414 = xor i8 %4413, -1
  %4415 = and i8 %4389, %4414
  %4416 = select i1 %4408, i8 %4415, i8 %4389
  store i8 %4416, ptr %frame.active, align 1
  %.splatinsert690 = insertelement <8 x i1> poison, i1 %4398, i64 0
  %.splat691 = shufflevector <8 x i1> %.splatinsert690, <8 x i1> poison, <8 x i32> zeroinitializer
  %4417 = and <8 x i1> %convergence.cascade.flow686, %.splat691
  %4418 = load <8 x i1>, ptr %runnable.mask, align 1
  %4419 = xor <8 x i1> %4417, splat (i1 true)
  %4420 = and <8 x i1> %4418, %4419
  store <8 x i1> %4420, ptr %runnable.mask, align 1
  %.splatinsert692 = insertelement <8 x i1> poison, i1 %4408, i64 0
  %.splat693 = shufflevector <8 x i1> %.splatinsert692, <8 x i1> poison, <8 x i32> zeroinitializer
  %4421 = select <8 x i1> %.splat693, <8 x i1> %4403, <8 x i1> zeroinitializer
  %4422 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4423 = extractelement <8 x i32> %4422, i32 %4388
  %4424 = select i1 %4408, i32 %4423, i32 %4384
  store i32 %4424, ptr %current.token, align 4
  %.splatinsert694 = insertelement <8 x i1> poison, i1 %4398, i64 0
  %.splat695 = shufflevector <8 x i1> %.splatinsert694, <8 x i1> poison, <8 x i32> zeroinitializer
  %4425 = select <8 x i1> %.splat695, <8 x i1> %4421, <8 x i1> %convergence.cascade.flow686
  %4426 = add i32 %convergence.cascade.depth687, 1
  %4427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4425)
  %4428 = icmp ult i32 %4426, 8
  %4429 = and i1 %4427, %4428
  %4430 = and i1 %4398, %4429
  %convergence.parent.token696 = load i32, ptr %current.token, align 4
  %convergence.parent.present697 = icmp ne i32 %convergence.parent.token696, 0
  %4431 = and i1 %4430, %convergence.parent.present697
  br i1 %4431, label %convergence.cascade682, label %convergence.cascade.exit683

convergence.cascade.exit683:                      ; preds = %convergence.cascade682, %schedule.38
  %convergence.cascade.result698 = phi <8 x i1> [ %815, %schedule.38 ], [ %4425, %convergence.cascade682 ]
  %4432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result698)
  br i1 %4432, label %convergence.target.38.ready, label %scheduler.loop

convergence.target.38.ready:                      ; preds = %convergence.cascade.exit683
  %4433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result698)
  %4434 = bitcast <8 x i1> %convergence.cascade.result698 to i8
  %4435 = call i8 @llvm.cttz.i8(i8 %4434, i1 false)
  %4436 = zext i8 %4435 to i32
  %4437 = select i1 %4433, i32 %4436, i32 0
  %4438 = load <8 x i64>, ptr %.slot120, align 64
  %4439 = select <8 x i1> %convergence.cascade.result698, <8 x i64> zeroinitializer, <8 x i64> %4438
  store <8 x i64> %4439, ptr %.slot120, align 64
  %4440 = load <8 x float>, ptr %.slot121, align 32
  %4441 = select <8 x i1> %convergence.cascade.result698, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4440
  store <8 x float> %4441, ptr %.slot121, align 32
  store <8 x i1> %convergence.cascade.result698, ptr %current.mask, align 1
  %4442 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result698)
  br i1 %4442, label %schedule.39, label %scheduler.loop

varying.divergent700:                             ; preds = %schedule.39
  %4443 = load i32, ptr %current.token, align 4
  %4444 = icmp ne i32 %4443, 0
  %4445 = sub i32 %4443, 1
  %4446 = select i1 %4444, i32 %4445, i32 0
  %4447 = load i8, ptr %frame.active, align 1
  %4448 = trunc i32 %4446 to i8
  %4449 = shl i8 1, %4448
  %4450 = and i8 %4447, %4449
  %4451 = icmp ne i8 %4450, 0
  %4452 = load <8 x i32>, ptr %frame.static.id, align 32
  %4453 = extractelement <8 x i32> %4452, i32 %4446
  %4454 = icmp eq i32 %4453, 14
  %4455 = and i1 %4451, %4454
  %4456 = and i1 %4444, %4455
  %4457 = xor i1 %4456, true
  %4458 = and i1 true, %4457
  %4459 = xor i8 %4447, -1
  %4460 = icmp ne i8 %4459, 0
  %4461 = xor i1 %4460, true
  %4462 = and i1 %4458, %4461
  br i1 %4462, label %convergence.overflow.trap702, label %convergence.overflow.resume703

varying.coherent701:                              ; preds = %schedule.39
  br i1 %826, label %varying.coherent.true706, label %varying.coherent.false707

convergence.overflow.trap702:                     ; preds = %varying.divergent700
  call void @llvm.trap()
  unreachable

convergence.overflow.resume703:                   ; preds = %varying.divergent700
  %4463 = call i8 @llvm.cttz.i8(i8 %4459, i1 false)
  %4464 = zext i8 %4463 to i32
  %4465 = select i1 %4460, i32 %4464, i32 0
  %4466 = trunc i32 %4465 to i8
  %4467 = shl i8 1, %4466
  %4468 = or i8 %4447, %4467
  %4469 = select i1 %4458, i8 %4468, i8 %4447
  store i8 %4469, ptr %frame.active, align 1
  %4470 = load <8 x i32>, ptr %frame.static.id, align 32
  %4471 = extractelement <8 x i32> %4470, i32 %4465
  %4472 = select i1 %4458, i32 14, i32 %4471
  %4473 = load <8 x i32>, ptr %frame.static.id, align 32
  %4474 = insertelement <8 x i32> %4473, i32 %4472, i32 %4465
  store <8 x i32> %4474, ptr %frame.static.id, align 32
  %4475 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4476 = extractelement <8 x i32> %4475, i32 %4465
  %4477 = select i1 %4458, i32 %4443, i32 %4476
  %4478 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4479 = insertelement <8 x i32> %4478, i32 %4477, i32 %4465
  store <8 x i32> %4479, ptr %frame.parent.token, align 32
  %4480 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4465
  %4481 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4465
  %4482 = load <8 x i1>, ptr %4480, align 1
  %4483 = load <8 x i1>, ptr %4481, align 1
  %4484 = select i1 %4458, <8 x i1> %816, <8 x i1> %4482
  store <8 x i1> %4484, ptr %4480, align 1
  %4485 = select i1 %4458, <8 x i1> zeroinitializer, <8 x i1> %4483
  store <8 x i1> %4485, ptr %4481, align 1
  %4486 = add i32 %4465, 1
  %4487 = select i1 %4456, i32 %4443, i32 %4486
  %4488 = select i1 true, i32 %4487, i32 %4443
  store i32 %4488, ptr %current.token, align 4
  %4489 = load i32, ptr %current.token, align 4
  %4490 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %823)
  %4491 = load i32, ptr %ready.count, align 4
  %4492 = icmp uge i32 %4491, 8
  %4493 = and i1 %4490, %4492
  br i1 %4493, label %ready.overflow.trap704, label %ready.overflow.resume705

ready.overflow.trap704:                           ; preds = %convergence.overflow.resume703
  call void @llvm.trap()
  unreachable

ready.overflow.resume705:                         ; preds = %convergence.overflow.resume703
  %4494 = select i1 %4490, i32 %4491, i32 0
  %4495 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4494
  %4496 = load <8 x i1>, ptr %4495, align 1
  %4497 = select i1 %4490, <8 x i1> %823, <8 x i1> %4496
  store <8 x i1> %4497, ptr %4495, align 1
  %4498 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4494
  %4499 = load i32, ptr %4498, align 4
  %4500 = select i1 %4490, i32 40, i32 %4499
  store i32 %4500, ptr %4498, align 4
  %4501 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4494
  %4502 = load i32, ptr %4501, align 4
  %4503 = select i1 %4490, i32 %4489, i32 %4502
  store i32 %4503, ptr %4501, align 4
  %4504 = add i32 %4491, 1
  %4505 = select i1 %4490, i32 %4504, i32 %4491
  store i32 %4505, ptr %ready.count, align 4
  %4506 = load <8 x i1>, ptr %runnable.mask, align 1
  %4507 = or <8 x i1> %4506, %823
  store <8 x i1> %4507, ptr %runnable.mask, align 1
  store <8 x i1> %825, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true706:                         ; preds = %varying.coherent701
  store <8 x i1> %816, ptr %current.mask, align 1
  %4508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %816)
  br i1 %4508, label %schedule.40, label %scheduler.loop

varying.coherent.false707:                        ; preds = %varying.coherent701
  store <8 x i1> %816, ptr %current.mask, align 1
  %4509 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %816)
  br i1 %4509, label %schedule.41, label %scheduler.loop

convergence.cascade712:                           ; preds = %convergence.cascade712, %schedule.41
  %convergence.cascade.flow716 = phi <8 x i1> [ %856, %schedule.41 ], [ %4552, %convergence.cascade712 ]
  %convergence.cascade.depth717 = phi i32 [ 0, %schedule.41 ], [ %4553, %convergence.cascade712 ]
  %4510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow716)
  %4511 = load i32, ptr %current.token, align 4
  %4512 = icmp ne i32 %4511, 0
  %4513 = and i1 %4510, %4512
  %4514 = sub i32 %4511, 1
  %4515 = select i1 %4513, i32 %4514, i32 0
  %4516 = load i8, ptr %frame.active, align 1
  %4517 = trunc i32 %4515 to i8
  %4518 = shl i8 1, %4517
  %4519 = and i8 %4516, %4518
  %4520 = icmp ne i8 %4519, 0
  %4521 = load <8 x i32>, ptr %frame.static.id, align 32
  %4522 = extractelement <8 x i32> %4521, i32 %4515
  %convergence.target.pointer718 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4522
  %convergence.dynamic.target719 = load i32, ptr %convergence.target.pointer718, align 4
  %4523 = icmp eq i32 %convergence.dynamic.target719, 41
  %4524 = and i1 %4520, %4523
  %4525 = and i1 %4513, %4524
  %4526 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4515
  %4527 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4515
  %4528 = load <8 x i1>, ptr %4526, align 1
  %4529 = load <8 x i1>, ptr %4527, align 1
  %4530 = or <8 x i1> %4529, %convergence.cascade.flow716
  %4531 = load <8 x i1>, ptr %live.mask, align 1
  %4532 = and <8 x i1> %4528, %4531
  %4533 = icmp eq <8 x i1> %4530, %4532
  %4534 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4533)
  %4535 = and i1 %4525, %4534
  %4536 = select i1 %4535, <8 x i1> zeroinitializer, <8 x i1> %4530
  %4537 = select i1 %4525, <8 x i1> %4536, <8 x i1> %4529
  store <8 x i1> %4537, ptr %4527, align 1
  %4538 = select i1 %4535, <8 x i1> zeroinitializer, <8 x i1> %4528
  store <8 x i1> %4538, ptr %4526, align 1
  %4539 = trunc i32 %4515 to i8
  %4540 = shl i8 1, %4539
  %4541 = xor i8 %4540, -1
  %4542 = and i8 %4516, %4541
  %4543 = select i1 %4535, i8 %4542, i8 %4516
  store i8 %4543, ptr %frame.active, align 1
  %.splatinsert720 = insertelement <8 x i1> poison, i1 %4525, i64 0
  %.splat721 = shufflevector <8 x i1> %.splatinsert720, <8 x i1> poison, <8 x i32> zeroinitializer
  %4544 = and <8 x i1> %convergence.cascade.flow716, %.splat721
  %4545 = load <8 x i1>, ptr %runnable.mask, align 1
  %4546 = xor <8 x i1> %4544, splat (i1 true)
  %4547 = and <8 x i1> %4545, %4546
  store <8 x i1> %4547, ptr %runnable.mask, align 1
  %.splatinsert722 = insertelement <8 x i1> poison, i1 %4535, i64 0
  %.splat723 = shufflevector <8 x i1> %.splatinsert722, <8 x i1> poison, <8 x i32> zeroinitializer
  %4548 = select <8 x i1> %.splat723, <8 x i1> %4530, <8 x i1> zeroinitializer
  %4549 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4550 = extractelement <8 x i32> %4549, i32 %4515
  %4551 = select i1 %4535, i32 %4550, i32 %4511
  store i32 %4551, ptr %current.token, align 4
  %.splatinsert724 = insertelement <8 x i1> poison, i1 %4525, i64 0
  %.splat725 = shufflevector <8 x i1> %.splatinsert724, <8 x i1> poison, <8 x i32> zeroinitializer
  %4552 = select <8 x i1> %.splat725, <8 x i1> %4548, <8 x i1> %convergence.cascade.flow716
  %4553 = add i32 %convergence.cascade.depth717, 1
  %4554 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4552)
  %4555 = icmp ult i32 %4553, 8
  %4556 = and i1 %4554, %4555
  %4557 = and i1 %4525, %4556
  %convergence.parent.token726 = load i32, ptr %current.token, align 4
  %convergence.parent.present727 = icmp ne i32 %convergence.parent.token726, 0
  %4558 = and i1 %4557, %convergence.parent.present727
  br i1 %4558, label %convergence.cascade712, label %convergence.cascade.exit713

convergence.cascade.exit713:                      ; preds = %convergence.cascade712, %schedule.41
  %convergence.cascade.result728 = phi <8 x i1> [ %856, %schedule.41 ], [ %4552, %convergence.cascade712 ]
  %4559 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result728)
  br i1 %4559, label %convergence.target.41.ready, label %scheduler.loop

convergence.target.41.ready:                      ; preds = %convergence.cascade.exit713
  %4560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result728)
  %4561 = bitcast <8 x i1> %convergence.cascade.result728 to i8
  %4562 = call i8 @llvm.cttz.i8(i8 %4561, i1 false)
  %4563 = zext i8 %4562 to i32
  %4564 = select i1 %4560, i32 %4563, i32 0
  %4565 = load <8 x i64>, ptr %.slot122, align 64
  %4566 = select <8 x i1> %convergence.cascade.result728, <8 x i64> zeroinitializer, <8 x i64> %4565
  store <8 x i64> %4566, ptr %.slot122, align 64
  %4567 = load <8 x float>, ptr %.slot123, align 32
  %4568 = select <8 x i1> %convergence.cascade.result728, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4567
  store <8 x float> %4568, ptr %.slot123, align 32
  store <8 x i1> %convergence.cascade.result728, ptr %current.mask, align 1
  %4569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result728)
  br i1 %4569, label %schedule.42, label %scheduler.loop

varying.divergent730:                             ; preds = %schedule.42
  %4570 = load i32, ptr %current.token, align 4
  %4571 = icmp ne i32 %4570, 0
  %4572 = sub i32 %4570, 1
  %4573 = select i1 %4571, i32 %4572, i32 0
  %4574 = load i8, ptr %frame.active, align 1
  %4575 = trunc i32 %4573 to i8
  %4576 = shl i8 1, %4575
  %4577 = and i8 %4574, %4576
  %4578 = icmp ne i8 %4577, 0
  %4579 = load <8 x i32>, ptr %frame.static.id, align 32
  %4580 = extractelement <8 x i32> %4579, i32 %4573
  %4581 = icmp eq i32 %4580, 15
  %4582 = and i1 %4578, %4581
  %4583 = and i1 %4571, %4582
  %4584 = xor i1 %4583, true
  %4585 = and i1 true, %4584
  %4586 = xor i8 %4574, -1
  %4587 = icmp ne i8 %4586, 0
  %4588 = xor i1 %4587, true
  %4589 = and i1 %4585, %4588
  br i1 %4589, label %convergence.overflow.trap732, label %convergence.overflow.resume733

varying.coherent731:                              ; preds = %schedule.42
  br i1 %867, label %varying.coherent.true736, label %varying.coherent.false737

convergence.overflow.trap732:                     ; preds = %varying.divergent730
  call void @llvm.trap()
  unreachable

convergence.overflow.resume733:                   ; preds = %varying.divergent730
  %4590 = call i8 @llvm.cttz.i8(i8 %4586, i1 false)
  %4591 = zext i8 %4590 to i32
  %4592 = select i1 %4587, i32 %4591, i32 0
  %4593 = trunc i32 %4592 to i8
  %4594 = shl i8 1, %4593
  %4595 = or i8 %4574, %4594
  %4596 = select i1 %4585, i8 %4595, i8 %4574
  store i8 %4596, ptr %frame.active, align 1
  %4597 = load <8 x i32>, ptr %frame.static.id, align 32
  %4598 = extractelement <8 x i32> %4597, i32 %4592
  %4599 = select i1 %4585, i32 15, i32 %4598
  %4600 = load <8 x i32>, ptr %frame.static.id, align 32
  %4601 = insertelement <8 x i32> %4600, i32 %4599, i32 %4592
  store <8 x i32> %4601, ptr %frame.static.id, align 32
  %4602 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4603 = extractelement <8 x i32> %4602, i32 %4592
  %4604 = select i1 %4585, i32 %4570, i32 %4603
  %4605 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4606 = insertelement <8 x i32> %4605, i32 %4604, i32 %4592
  store <8 x i32> %4606, ptr %frame.parent.token, align 32
  %4607 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4592
  %4608 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4592
  %4609 = load <8 x i1>, ptr %4607, align 1
  %4610 = load <8 x i1>, ptr %4608, align 1
  %4611 = select i1 %4585, <8 x i1> %857, <8 x i1> %4609
  store <8 x i1> %4611, ptr %4607, align 1
  %4612 = select i1 %4585, <8 x i1> zeroinitializer, <8 x i1> %4610
  store <8 x i1> %4612, ptr %4608, align 1
  %4613 = add i32 %4592, 1
  %4614 = select i1 %4583, i32 %4570, i32 %4613
  %4615 = select i1 true, i32 %4614, i32 %4570
  store i32 %4615, ptr %current.token, align 4
  %4616 = load i32, ptr %current.token, align 4
  %4617 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %864)
  %4618 = load i32, ptr %ready.count, align 4
  %4619 = icmp uge i32 %4618, 8
  %4620 = and i1 %4617, %4619
  br i1 %4620, label %ready.overflow.trap734, label %ready.overflow.resume735

ready.overflow.trap734:                           ; preds = %convergence.overflow.resume733
  call void @llvm.trap()
  unreachable

ready.overflow.resume735:                         ; preds = %convergence.overflow.resume733
  %4621 = select i1 %4617, i32 %4618, i32 0
  %4622 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4621
  %4623 = load <8 x i1>, ptr %4622, align 1
  %4624 = select i1 %4617, <8 x i1> %864, <8 x i1> %4623
  store <8 x i1> %4624, ptr %4622, align 1
  %4625 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4621
  %4626 = load i32, ptr %4625, align 4
  %4627 = select i1 %4617, i32 43, i32 %4626
  store i32 %4627, ptr %4625, align 4
  %4628 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4621
  %4629 = load i32, ptr %4628, align 4
  %4630 = select i1 %4617, i32 %4616, i32 %4629
  store i32 %4630, ptr %4628, align 4
  %4631 = add i32 %4618, 1
  %4632 = select i1 %4617, i32 %4631, i32 %4618
  store i32 %4632, ptr %ready.count, align 4
  %4633 = load <8 x i1>, ptr %runnable.mask, align 1
  %4634 = or <8 x i1> %4633, %864
  store <8 x i1> %4634, ptr %runnable.mask, align 1
  store <8 x i1> %866, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true736:                         ; preds = %varying.coherent731
  store <8 x i1> %857, ptr %current.mask, align 1
  %4635 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %857)
  br i1 %4635, label %schedule.43, label %scheduler.loop

varying.coherent.false737:                        ; preds = %varying.coherent731
  store <8 x i1> %857, ptr %current.mask, align 1
  %4636 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %857)
  br i1 %4636, label %schedule.44, label %scheduler.loop

convergence.cascade742:                           ; preds = %convergence.cascade742, %schedule.44
  %convergence.cascade.flow746 = phi <8 x i1> [ %897, %schedule.44 ], [ %4679, %convergence.cascade742 ]
  %convergence.cascade.depth747 = phi i32 [ 0, %schedule.44 ], [ %4680, %convergence.cascade742 ]
  %4637 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow746)
  %4638 = load i32, ptr %current.token, align 4
  %4639 = icmp ne i32 %4638, 0
  %4640 = and i1 %4637, %4639
  %4641 = sub i32 %4638, 1
  %4642 = select i1 %4640, i32 %4641, i32 0
  %4643 = load i8, ptr %frame.active, align 1
  %4644 = trunc i32 %4642 to i8
  %4645 = shl i8 1, %4644
  %4646 = and i8 %4643, %4645
  %4647 = icmp ne i8 %4646, 0
  %4648 = load <8 x i32>, ptr %frame.static.id, align 32
  %4649 = extractelement <8 x i32> %4648, i32 %4642
  %convergence.target.pointer748 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4649
  %convergence.dynamic.target749 = load i32, ptr %convergence.target.pointer748, align 4
  %4650 = icmp eq i32 %convergence.dynamic.target749, 44
  %4651 = and i1 %4647, %4650
  %4652 = and i1 %4640, %4651
  %4653 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4642
  %4654 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4642
  %4655 = load <8 x i1>, ptr %4653, align 1
  %4656 = load <8 x i1>, ptr %4654, align 1
  %4657 = or <8 x i1> %4656, %convergence.cascade.flow746
  %4658 = load <8 x i1>, ptr %live.mask, align 1
  %4659 = and <8 x i1> %4655, %4658
  %4660 = icmp eq <8 x i1> %4657, %4659
  %4661 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4660)
  %4662 = and i1 %4652, %4661
  %4663 = select i1 %4662, <8 x i1> zeroinitializer, <8 x i1> %4657
  %4664 = select i1 %4652, <8 x i1> %4663, <8 x i1> %4656
  store <8 x i1> %4664, ptr %4654, align 1
  %4665 = select i1 %4662, <8 x i1> zeroinitializer, <8 x i1> %4655
  store <8 x i1> %4665, ptr %4653, align 1
  %4666 = trunc i32 %4642 to i8
  %4667 = shl i8 1, %4666
  %4668 = xor i8 %4667, -1
  %4669 = and i8 %4643, %4668
  %4670 = select i1 %4662, i8 %4669, i8 %4643
  store i8 %4670, ptr %frame.active, align 1
  %.splatinsert750 = insertelement <8 x i1> poison, i1 %4652, i64 0
  %.splat751 = shufflevector <8 x i1> %.splatinsert750, <8 x i1> poison, <8 x i32> zeroinitializer
  %4671 = and <8 x i1> %convergence.cascade.flow746, %.splat751
  %4672 = load <8 x i1>, ptr %runnable.mask, align 1
  %4673 = xor <8 x i1> %4671, splat (i1 true)
  %4674 = and <8 x i1> %4672, %4673
  store <8 x i1> %4674, ptr %runnable.mask, align 1
  %.splatinsert752 = insertelement <8 x i1> poison, i1 %4662, i64 0
  %.splat753 = shufflevector <8 x i1> %.splatinsert752, <8 x i1> poison, <8 x i32> zeroinitializer
  %4675 = select <8 x i1> %.splat753, <8 x i1> %4657, <8 x i1> zeroinitializer
  %4676 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4677 = extractelement <8 x i32> %4676, i32 %4642
  %4678 = select i1 %4662, i32 %4677, i32 %4638
  store i32 %4678, ptr %current.token, align 4
  %.splatinsert754 = insertelement <8 x i1> poison, i1 %4652, i64 0
  %.splat755 = shufflevector <8 x i1> %.splatinsert754, <8 x i1> poison, <8 x i32> zeroinitializer
  %4679 = select <8 x i1> %.splat755, <8 x i1> %4675, <8 x i1> %convergence.cascade.flow746
  %4680 = add i32 %convergence.cascade.depth747, 1
  %4681 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4679)
  %4682 = icmp ult i32 %4680, 8
  %4683 = and i1 %4681, %4682
  %4684 = and i1 %4652, %4683
  %convergence.parent.token756 = load i32, ptr %current.token, align 4
  %convergence.parent.present757 = icmp ne i32 %convergence.parent.token756, 0
  %4685 = and i1 %4684, %convergence.parent.present757
  br i1 %4685, label %convergence.cascade742, label %convergence.cascade.exit743

convergence.cascade.exit743:                      ; preds = %convergence.cascade742, %schedule.44
  %convergence.cascade.result758 = phi <8 x i1> [ %897, %schedule.44 ], [ %4679, %convergence.cascade742 ]
  %4686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result758)
  br i1 %4686, label %convergence.target.44.ready, label %scheduler.loop

convergence.target.44.ready:                      ; preds = %convergence.cascade.exit743
  %4687 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result758)
  %4688 = bitcast <8 x i1> %convergence.cascade.result758 to i8
  %4689 = call i8 @llvm.cttz.i8(i8 %4688, i1 false)
  %4690 = zext i8 %4689 to i32
  %4691 = select i1 %4687, i32 %4690, i32 0
  %4692 = load <8 x i64>, ptr %.slot124, align 64
  %4693 = select <8 x i1> %convergence.cascade.result758, <8 x i64> zeroinitializer, <8 x i64> %4692
  store <8 x i64> %4693, ptr %.slot124, align 64
  %4694 = load <8 x float>, ptr %.slot125, align 32
  %4695 = select <8 x i1> %convergence.cascade.result758, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4694
  store <8 x float> %4695, ptr %.slot125, align 32
  store <8 x i1> %convergence.cascade.result758, ptr %current.mask, align 1
  %4696 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result758)
  br i1 %4696, label %schedule.45, label %scheduler.loop

varying.divergent760:                             ; preds = %schedule.45
  %4697 = load i32, ptr %current.token, align 4
  %4698 = icmp ne i32 %4697, 0
  %4699 = sub i32 %4697, 1
  %4700 = select i1 %4698, i32 %4699, i32 0
  %4701 = load i8, ptr %frame.active, align 1
  %4702 = trunc i32 %4700 to i8
  %4703 = shl i8 1, %4702
  %4704 = and i8 %4701, %4703
  %4705 = icmp ne i8 %4704, 0
  %4706 = load <8 x i32>, ptr %frame.static.id, align 32
  %4707 = extractelement <8 x i32> %4706, i32 %4700
  %4708 = icmp eq i32 %4707, 16
  %4709 = and i1 %4705, %4708
  %4710 = and i1 %4698, %4709
  %4711 = xor i1 %4710, true
  %4712 = and i1 true, %4711
  %4713 = xor i8 %4701, -1
  %4714 = icmp ne i8 %4713, 0
  %4715 = xor i1 %4714, true
  %4716 = and i1 %4712, %4715
  br i1 %4716, label %convergence.overflow.trap762, label %convergence.overflow.resume763

varying.coherent761:                              ; preds = %schedule.45
  br i1 %908, label %varying.coherent.true766, label %varying.coherent.false767

convergence.overflow.trap762:                     ; preds = %varying.divergent760
  call void @llvm.trap()
  unreachable

convergence.overflow.resume763:                   ; preds = %varying.divergent760
  %4717 = call i8 @llvm.cttz.i8(i8 %4713, i1 false)
  %4718 = zext i8 %4717 to i32
  %4719 = select i1 %4714, i32 %4718, i32 0
  %4720 = trunc i32 %4719 to i8
  %4721 = shl i8 1, %4720
  %4722 = or i8 %4701, %4721
  %4723 = select i1 %4712, i8 %4722, i8 %4701
  store i8 %4723, ptr %frame.active, align 1
  %4724 = load <8 x i32>, ptr %frame.static.id, align 32
  %4725 = extractelement <8 x i32> %4724, i32 %4719
  %4726 = select i1 %4712, i32 16, i32 %4725
  %4727 = load <8 x i32>, ptr %frame.static.id, align 32
  %4728 = insertelement <8 x i32> %4727, i32 %4726, i32 %4719
  store <8 x i32> %4728, ptr %frame.static.id, align 32
  %4729 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4730 = extractelement <8 x i32> %4729, i32 %4719
  %4731 = select i1 %4712, i32 %4697, i32 %4730
  %4732 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4733 = insertelement <8 x i32> %4732, i32 %4731, i32 %4719
  store <8 x i32> %4733, ptr %frame.parent.token, align 32
  %4734 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4719
  %4735 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4719
  %4736 = load <8 x i1>, ptr %4734, align 1
  %4737 = load <8 x i1>, ptr %4735, align 1
  %4738 = select i1 %4712, <8 x i1> %898, <8 x i1> %4736
  store <8 x i1> %4738, ptr %4734, align 1
  %4739 = select i1 %4712, <8 x i1> zeroinitializer, <8 x i1> %4737
  store <8 x i1> %4739, ptr %4735, align 1
  %4740 = add i32 %4719, 1
  %4741 = select i1 %4710, i32 %4697, i32 %4740
  %4742 = select i1 true, i32 %4741, i32 %4697
  store i32 %4742, ptr %current.token, align 4
  %4743 = load i32, ptr %current.token, align 4
  %4744 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %905)
  %4745 = load i32, ptr %ready.count, align 4
  %4746 = icmp uge i32 %4745, 8
  %4747 = and i1 %4744, %4746
  br i1 %4747, label %ready.overflow.trap764, label %ready.overflow.resume765

ready.overflow.trap764:                           ; preds = %convergence.overflow.resume763
  call void @llvm.trap()
  unreachable

ready.overflow.resume765:                         ; preds = %convergence.overflow.resume763
  %4748 = select i1 %4744, i32 %4745, i32 0
  %4749 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4748
  %4750 = load <8 x i1>, ptr %4749, align 1
  %4751 = select i1 %4744, <8 x i1> %905, <8 x i1> %4750
  store <8 x i1> %4751, ptr %4749, align 1
  %4752 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4748
  %4753 = load i32, ptr %4752, align 4
  %4754 = select i1 %4744, i32 46, i32 %4753
  store i32 %4754, ptr %4752, align 4
  %4755 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4748
  %4756 = load i32, ptr %4755, align 4
  %4757 = select i1 %4744, i32 %4743, i32 %4756
  store i32 %4757, ptr %4755, align 4
  %4758 = add i32 %4745, 1
  %4759 = select i1 %4744, i32 %4758, i32 %4745
  store i32 %4759, ptr %ready.count, align 4
  %4760 = load <8 x i1>, ptr %runnable.mask, align 1
  %4761 = or <8 x i1> %4760, %905
  store <8 x i1> %4761, ptr %runnable.mask, align 1
  store <8 x i1> %907, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true766:                         ; preds = %varying.coherent761
  store <8 x i1> %898, ptr %current.mask, align 1
  %4762 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %898)
  br i1 %4762, label %schedule.46, label %scheduler.loop

varying.coherent.false767:                        ; preds = %varying.coherent761
  store <8 x i1> %898, ptr %current.mask, align 1
  %4763 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %898)
  br i1 %4763, label %schedule.47, label %scheduler.loop

convergence.cascade772:                           ; preds = %convergence.cascade772, %schedule.47
  %convergence.cascade.flow776 = phi <8 x i1> [ %938, %schedule.47 ], [ %4806, %convergence.cascade772 ]
  %convergence.cascade.depth777 = phi i32 [ 0, %schedule.47 ], [ %4807, %convergence.cascade772 ]
  %4764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow776)
  %4765 = load i32, ptr %current.token, align 4
  %4766 = icmp ne i32 %4765, 0
  %4767 = and i1 %4764, %4766
  %4768 = sub i32 %4765, 1
  %4769 = select i1 %4767, i32 %4768, i32 0
  %4770 = load i8, ptr %frame.active, align 1
  %4771 = trunc i32 %4769 to i8
  %4772 = shl i8 1, %4771
  %4773 = and i8 %4770, %4772
  %4774 = icmp ne i8 %4773, 0
  %4775 = load <8 x i32>, ptr %frame.static.id, align 32
  %4776 = extractelement <8 x i32> %4775, i32 %4769
  %convergence.target.pointer778 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4776
  %convergence.dynamic.target779 = load i32, ptr %convergence.target.pointer778, align 4
  %4777 = icmp eq i32 %convergence.dynamic.target779, 47
  %4778 = and i1 %4774, %4777
  %4779 = and i1 %4767, %4778
  %4780 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4769
  %4781 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4769
  %4782 = load <8 x i1>, ptr %4780, align 1
  %4783 = load <8 x i1>, ptr %4781, align 1
  %4784 = or <8 x i1> %4783, %convergence.cascade.flow776
  %4785 = load <8 x i1>, ptr %live.mask, align 1
  %4786 = and <8 x i1> %4782, %4785
  %4787 = icmp eq <8 x i1> %4784, %4786
  %4788 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4787)
  %4789 = and i1 %4779, %4788
  %4790 = select i1 %4789, <8 x i1> zeroinitializer, <8 x i1> %4784
  %4791 = select i1 %4779, <8 x i1> %4790, <8 x i1> %4783
  store <8 x i1> %4791, ptr %4781, align 1
  %4792 = select i1 %4789, <8 x i1> zeroinitializer, <8 x i1> %4782
  store <8 x i1> %4792, ptr %4780, align 1
  %4793 = trunc i32 %4769 to i8
  %4794 = shl i8 1, %4793
  %4795 = xor i8 %4794, -1
  %4796 = and i8 %4770, %4795
  %4797 = select i1 %4789, i8 %4796, i8 %4770
  store i8 %4797, ptr %frame.active, align 1
  %.splatinsert780 = insertelement <8 x i1> poison, i1 %4779, i64 0
  %.splat781 = shufflevector <8 x i1> %.splatinsert780, <8 x i1> poison, <8 x i32> zeroinitializer
  %4798 = and <8 x i1> %convergence.cascade.flow776, %.splat781
  %4799 = load <8 x i1>, ptr %runnable.mask, align 1
  %4800 = xor <8 x i1> %4798, splat (i1 true)
  %4801 = and <8 x i1> %4799, %4800
  store <8 x i1> %4801, ptr %runnable.mask, align 1
  %.splatinsert782 = insertelement <8 x i1> poison, i1 %4789, i64 0
  %.splat783 = shufflevector <8 x i1> %.splatinsert782, <8 x i1> poison, <8 x i32> zeroinitializer
  %4802 = select <8 x i1> %.splat783, <8 x i1> %4784, <8 x i1> zeroinitializer
  %4803 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4804 = extractelement <8 x i32> %4803, i32 %4769
  %4805 = select i1 %4789, i32 %4804, i32 %4765
  store i32 %4805, ptr %current.token, align 4
  %.splatinsert784 = insertelement <8 x i1> poison, i1 %4779, i64 0
  %.splat785 = shufflevector <8 x i1> %.splatinsert784, <8 x i1> poison, <8 x i32> zeroinitializer
  %4806 = select <8 x i1> %.splat785, <8 x i1> %4802, <8 x i1> %convergence.cascade.flow776
  %4807 = add i32 %convergence.cascade.depth777, 1
  %4808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4806)
  %4809 = icmp ult i32 %4807, 8
  %4810 = and i1 %4808, %4809
  %4811 = and i1 %4779, %4810
  %convergence.parent.token786 = load i32, ptr %current.token, align 4
  %convergence.parent.present787 = icmp ne i32 %convergence.parent.token786, 0
  %4812 = and i1 %4811, %convergence.parent.present787
  br i1 %4812, label %convergence.cascade772, label %convergence.cascade.exit773

convergence.cascade.exit773:                      ; preds = %convergence.cascade772, %schedule.47
  %convergence.cascade.result788 = phi <8 x i1> [ %938, %schedule.47 ], [ %4806, %convergence.cascade772 ]
  %4813 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result788)
  br i1 %4813, label %convergence.target.47.ready, label %scheduler.loop

convergence.target.47.ready:                      ; preds = %convergence.cascade.exit773
  %4814 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result788)
  %4815 = bitcast <8 x i1> %convergence.cascade.result788 to i8
  %4816 = call i8 @llvm.cttz.i8(i8 %4815, i1 false)
  %4817 = zext i8 %4816 to i32
  %4818 = select i1 %4814, i32 %4817, i32 0
  %4819 = load <8 x i64>, ptr %.slot126, align 64
  %4820 = select <8 x i1> %convergence.cascade.result788, <8 x i64> zeroinitializer, <8 x i64> %4819
  store <8 x i64> %4820, ptr %.slot126, align 64
  %4821 = load <8 x float>, ptr %.slot127, align 32
  %4822 = select <8 x i1> %convergence.cascade.result788, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4821
  store <8 x float> %4822, ptr %.slot127, align 32
  store <8 x i1> %convergence.cascade.result788, ptr %current.mask, align 1
  %4823 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result788)
  br i1 %4823, label %schedule.48, label %scheduler.loop

varying.divergent790:                             ; preds = %schedule.48
  %4824 = load i32, ptr %current.token, align 4
  %4825 = icmp ne i32 %4824, 0
  %4826 = sub i32 %4824, 1
  %4827 = select i1 %4825, i32 %4826, i32 0
  %4828 = load i8, ptr %frame.active, align 1
  %4829 = trunc i32 %4827 to i8
  %4830 = shl i8 1, %4829
  %4831 = and i8 %4828, %4830
  %4832 = icmp ne i8 %4831, 0
  %4833 = load <8 x i32>, ptr %frame.static.id, align 32
  %4834 = extractelement <8 x i32> %4833, i32 %4827
  %4835 = icmp eq i32 %4834, 17
  %4836 = and i1 %4832, %4835
  %4837 = and i1 %4825, %4836
  %4838 = xor i1 %4837, true
  %4839 = and i1 true, %4838
  %4840 = xor i8 %4828, -1
  %4841 = icmp ne i8 %4840, 0
  %4842 = xor i1 %4841, true
  %4843 = and i1 %4839, %4842
  br i1 %4843, label %convergence.overflow.trap792, label %convergence.overflow.resume793

varying.coherent791:                              ; preds = %schedule.48
  br i1 %949, label %varying.coherent.true796, label %varying.coherent.false797

convergence.overflow.trap792:                     ; preds = %varying.divergent790
  call void @llvm.trap()
  unreachable

convergence.overflow.resume793:                   ; preds = %varying.divergent790
  %4844 = call i8 @llvm.cttz.i8(i8 %4840, i1 false)
  %4845 = zext i8 %4844 to i32
  %4846 = select i1 %4841, i32 %4845, i32 0
  %4847 = trunc i32 %4846 to i8
  %4848 = shl i8 1, %4847
  %4849 = or i8 %4828, %4848
  %4850 = select i1 %4839, i8 %4849, i8 %4828
  store i8 %4850, ptr %frame.active, align 1
  %4851 = load <8 x i32>, ptr %frame.static.id, align 32
  %4852 = extractelement <8 x i32> %4851, i32 %4846
  %4853 = select i1 %4839, i32 17, i32 %4852
  %4854 = load <8 x i32>, ptr %frame.static.id, align 32
  %4855 = insertelement <8 x i32> %4854, i32 %4853, i32 %4846
  store <8 x i32> %4855, ptr %frame.static.id, align 32
  %4856 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4857 = extractelement <8 x i32> %4856, i32 %4846
  %4858 = select i1 %4839, i32 %4824, i32 %4857
  %4859 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4860 = insertelement <8 x i32> %4859, i32 %4858, i32 %4846
  store <8 x i32> %4860, ptr %frame.parent.token, align 32
  %4861 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4846
  %4862 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4846
  %4863 = load <8 x i1>, ptr %4861, align 1
  %4864 = load <8 x i1>, ptr %4862, align 1
  %4865 = select i1 %4839, <8 x i1> %939, <8 x i1> %4863
  store <8 x i1> %4865, ptr %4861, align 1
  %4866 = select i1 %4839, <8 x i1> zeroinitializer, <8 x i1> %4864
  store <8 x i1> %4866, ptr %4862, align 1
  %4867 = add i32 %4846, 1
  %4868 = select i1 %4837, i32 %4824, i32 %4867
  %4869 = select i1 true, i32 %4868, i32 %4824
  store i32 %4869, ptr %current.token, align 4
  %4870 = load i32, ptr %current.token, align 4
  %4871 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %946)
  %4872 = load i32, ptr %ready.count, align 4
  %4873 = icmp uge i32 %4872, 8
  %4874 = and i1 %4871, %4873
  br i1 %4874, label %ready.overflow.trap794, label %ready.overflow.resume795

ready.overflow.trap794:                           ; preds = %convergence.overflow.resume793
  call void @llvm.trap()
  unreachable

ready.overflow.resume795:                         ; preds = %convergence.overflow.resume793
  %4875 = select i1 %4871, i32 %4872, i32 0
  %4876 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4875
  %4877 = load <8 x i1>, ptr %4876, align 1
  %4878 = select i1 %4871, <8 x i1> %946, <8 x i1> %4877
  store <8 x i1> %4878, ptr %4876, align 1
  %4879 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4875
  %4880 = load i32, ptr %4879, align 4
  %4881 = select i1 %4871, i32 49, i32 %4880
  store i32 %4881, ptr %4879, align 4
  %4882 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4875
  %4883 = load i32, ptr %4882, align 4
  %4884 = select i1 %4871, i32 %4870, i32 %4883
  store i32 %4884, ptr %4882, align 4
  %4885 = add i32 %4872, 1
  %4886 = select i1 %4871, i32 %4885, i32 %4872
  store i32 %4886, ptr %ready.count, align 4
  %4887 = load <8 x i1>, ptr %runnable.mask, align 1
  %4888 = or <8 x i1> %4887, %946
  store <8 x i1> %4888, ptr %runnable.mask, align 1
  store <8 x i1> %948, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true796:                         ; preds = %varying.coherent791
  store <8 x i1> %939, ptr %current.mask, align 1
  %4889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %939)
  br i1 %4889, label %schedule.49, label %scheduler.loop

varying.coherent.false797:                        ; preds = %varying.coherent791
  store <8 x i1> %939, ptr %current.mask, align 1
  %4890 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %939)
  br i1 %4890, label %schedule.50, label %scheduler.loop

convergence.cascade802:                           ; preds = %convergence.cascade802, %schedule.50
  %convergence.cascade.flow806 = phi <8 x i1> [ %979, %schedule.50 ], [ %4933, %convergence.cascade802 ]
  %convergence.cascade.depth807 = phi i32 [ 0, %schedule.50 ], [ %4934, %convergence.cascade802 ]
  %4891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow806)
  %4892 = load i32, ptr %current.token, align 4
  %4893 = icmp ne i32 %4892, 0
  %4894 = and i1 %4891, %4893
  %4895 = sub i32 %4892, 1
  %4896 = select i1 %4894, i32 %4895, i32 0
  %4897 = load i8, ptr %frame.active, align 1
  %4898 = trunc i32 %4896 to i8
  %4899 = shl i8 1, %4898
  %4900 = and i8 %4897, %4899
  %4901 = icmp ne i8 %4900, 0
  %4902 = load <8 x i32>, ptr %frame.static.id, align 32
  %4903 = extractelement <8 x i32> %4902, i32 %4896
  %convergence.target.pointer808 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4903
  %convergence.dynamic.target809 = load i32, ptr %convergence.target.pointer808, align 4
  %4904 = icmp eq i32 %convergence.dynamic.target809, 50
  %4905 = and i1 %4901, %4904
  %4906 = and i1 %4894, %4905
  %4907 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4896
  %4908 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4896
  %4909 = load <8 x i1>, ptr %4907, align 1
  %4910 = load <8 x i1>, ptr %4908, align 1
  %4911 = or <8 x i1> %4910, %convergence.cascade.flow806
  %4912 = load <8 x i1>, ptr %live.mask, align 1
  %4913 = and <8 x i1> %4909, %4912
  %4914 = icmp eq <8 x i1> %4911, %4913
  %4915 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4914)
  %4916 = and i1 %4906, %4915
  %4917 = select i1 %4916, <8 x i1> zeroinitializer, <8 x i1> %4911
  %4918 = select i1 %4906, <8 x i1> %4917, <8 x i1> %4910
  store <8 x i1> %4918, ptr %4908, align 1
  %4919 = select i1 %4916, <8 x i1> zeroinitializer, <8 x i1> %4909
  store <8 x i1> %4919, ptr %4907, align 1
  %4920 = trunc i32 %4896 to i8
  %4921 = shl i8 1, %4920
  %4922 = xor i8 %4921, -1
  %4923 = and i8 %4897, %4922
  %4924 = select i1 %4916, i8 %4923, i8 %4897
  store i8 %4924, ptr %frame.active, align 1
  %.splatinsert810 = insertelement <8 x i1> poison, i1 %4906, i64 0
  %.splat811 = shufflevector <8 x i1> %.splatinsert810, <8 x i1> poison, <8 x i32> zeroinitializer
  %4925 = and <8 x i1> %convergence.cascade.flow806, %.splat811
  %4926 = load <8 x i1>, ptr %runnable.mask, align 1
  %4927 = xor <8 x i1> %4925, splat (i1 true)
  %4928 = and <8 x i1> %4926, %4927
  store <8 x i1> %4928, ptr %runnable.mask, align 1
  %.splatinsert812 = insertelement <8 x i1> poison, i1 %4916, i64 0
  %.splat813 = shufflevector <8 x i1> %.splatinsert812, <8 x i1> poison, <8 x i32> zeroinitializer
  %4929 = select <8 x i1> %.splat813, <8 x i1> %4911, <8 x i1> zeroinitializer
  %4930 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4931 = extractelement <8 x i32> %4930, i32 %4896
  %4932 = select i1 %4916, i32 %4931, i32 %4892
  store i32 %4932, ptr %current.token, align 4
  %.splatinsert814 = insertelement <8 x i1> poison, i1 %4906, i64 0
  %.splat815 = shufflevector <8 x i1> %.splatinsert814, <8 x i1> poison, <8 x i32> zeroinitializer
  %4933 = select <8 x i1> %.splat815, <8 x i1> %4929, <8 x i1> %convergence.cascade.flow806
  %4934 = add i32 %convergence.cascade.depth807, 1
  %4935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4933)
  %4936 = icmp ult i32 %4934, 8
  %4937 = and i1 %4935, %4936
  %4938 = and i1 %4906, %4937
  %convergence.parent.token816 = load i32, ptr %current.token, align 4
  %convergence.parent.present817 = icmp ne i32 %convergence.parent.token816, 0
  %4939 = and i1 %4938, %convergence.parent.present817
  br i1 %4939, label %convergence.cascade802, label %convergence.cascade.exit803

convergence.cascade.exit803:                      ; preds = %convergence.cascade802, %schedule.50
  %convergence.cascade.result818 = phi <8 x i1> [ %979, %schedule.50 ], [ %4933, %convergence.cascade802 ]
  %4940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result818)
  br i1 %4940, label %convergence.target.50.ready, label %scheduler.loop

convergence.target.50.ready:                      ; preds = %convergence.cascade.exit803
  %4941 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result818)
  %4942 = bitcast <8 x i1> %convergence.cascade.result818 to i8
  %4943 = call i8 @llvm.cttz.i8(i8 %4942, i1 false)
  %4944 = zext i8 %4943 to i32
  %4945 = select i1 %4941, i32 %4944, i32 0
  %4946 = load <8 x i64>, ptr %.slot128, align 64
  %4947 = select <8 x i1> %convergence.cascade.result818, <8 x i64> zeroinitializer, <8 x i64> %4946
  store <8 x i64> %4947, ptr %.slot128, align 64
  %4948 = load <8 x float>, ptr %.slot129, align 32
  %4949 = select <8 x i1> %convergence.cascade.result818, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4948
  store <8 x float> %4949, ptr %.slot129, align 32
  store <8 x i1> %convergence.cascade.result818, ptr %current.mask, align 1
  %4950 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result818)
  br i1 %4950, label %schedule.51, label %scheduler.loop

varying.divergent820:                             ; preds = %schedule.51
  %4951 = load i32, ptr %current.token, align 4
  %4952 = icmp ne i32 %4951, 0
  %4953 = sub i32 %4951, 1
  %4954 = select i1 %4952, i32 %4953, i32 0
  %4955 = load i8, ptr %frame.active, align 1
  %4956 = trunc i32 %4954 to i8
  %4957 = shl i8 1, %4956
  %4958 = and i8 %4955, %4957
  %4959 = icmp ne i8 %4958, 0
  %4960 = load <8 x i32>, ptr %frame.static.id, align 32
  %4961 = extractelement <8 x i32> %4960, i32 %4954
  %4962 = icmp eq i32 %4961, 18
  %4963 = and i1 %4959, %4962
  %4964 = and i1 %4952, %4963
  %4965 = xor i1 %4964, true
  %4966 = and i1 true, %4965
  %4967 = xor i8 %4955, -1
  %4968 = icmp ne i8 %4967, 0
  %4969 = xor i1 %4968, true
  %4970 = and i1 %4966, %4969
  br i1 %4970, label %convergence.overflow.trap822, label %convergence.overflow.resume823

varying.coherent821:                              ; preds = %schedule.51
  br i1 %990, label %varying.coherent.true826, label %varying.coherent.false827

convergence.overflow.trap822:                     ; preds = %varying.divergent820
  call void @llvm.trap()
  unreachable

convergence.overflow.resume823:                   ; preds = %varying.divergent820
  %4971 = call i8 @llvm.cttz.i8(i8 %4967, i1 false)
  %4972 = zext i8 %4971 to i32
  %4973 = select i1 %4968, i32 %4972, i32 0
  %4974 = trunc i32 %4973 to i8
  %4975 = shl i8 1, %4974
  %4976 = or i8 %4955, %4975
  %4977 = select i1 %4966, i8 %4976, i8 %4955
  store i8 %4977, ptr %frame.active, align 1
  %4978 = load <8 x i32>, ptr %frame.static.id, align 32
  %4979 = extractelement <8 x i32> %4978, i32 %4973
  %4980 = select i1 %4966, i32 18, i32 %4979
  %4981 = load <8 x i32>, ptr %frame.static.id, align 32
  %4982 = insertelement <8 x i32> %4981, i32 %4980, i32 %4973
  store <8 x i32> %4982, ptr %frame.static.id, align 32
  %4983 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4984 = extractelement <8 x i32> %4983, i32 %4973
  %4985 = select i1 %4966, i32 %4951, i32 %4984
  %4986 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4987 = insertelement <8 x i32> %4986, i32 %4985, i32 %4973
  store <8 x i32> %4987, ptr %frame.parent.token, align 32
  %4988 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4973
  %4989 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4973
  %4990 = load <8 x i1>, ptr %4988, align 1
  %4991 = load <8 x i1>, ptr %4989, align 1
  %4992 = select i1 %4966, <8 x i1> %980, <8 x i1> %4990
  store <8 x i1> %4992, ptr %4988, align 1
  %4993 = select i1 %4966, <8 x i1> zeroinitializer, <8 x i1> %4991
  store <8 x i1> %4993, ptr %4989, align 1
  %4994 = add i32 %4973, 1
  %4995 = select i1 %4964, i32 %4951, i32 %4994
  %4996 = select i1 true, i32 %4995, i32 %4951
  store i32 %4996, ptr %current.token, align 4
  %4997 = load i32, ptr %current.token, align 4
  %4998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %987)
  %4999 = load i32, ptr %ready.count, align 4
  %5000 = icmp uge i32 %4999, 8
  %5001 = and i1 %4998, %5000
  br i1 %5001, label %ready.overflow.trap824, label %ready.overflow.resume825

ready.overflow.trap824:                           ; preds = %convergence.overflow.resume823
  call void @llvm.trap()
  unreachable

ready.overflow.resume825:                         ; preds = %convergence.overflow.resume823
  %5002 = select i1 %4998, i32 %4999, i32 0
  %5003 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5002
  %5004 = load <8 x i1>, ptr %5003, align 1
  %5005 = select i1 %4998, <8 x i1> %987, <8 x i1> %5004
  store <8 x i1> %5005, ptr %5003, align 1
  %5006 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5002
  %5007 = load i32, ptr %5006, align 4
  %5008 = select i1 %4998, i32 52, i32 %5007
  store i32 %5008, ptr %5006, align 4
  %5009 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5002
  %5010 = load i32, ptr %5009, align 4
  %5011 = select i1 %4998, i32 %4997, i32 %5010
  store i32 %5011, ptr %5009, align 4
  %5012 = add i32 %4999, 1
  %5013 = select i1 %4998, i32 %5012, i32 %4999
  store i32 %5013, ptr %ready.count, align 4
  %5014 = load <8 x i1>, ptr %runnable.mask, align 1
  %5015 = or <8 x i1> %5014, %987
  store <8 x i1> %5015, ptr %runnable.mask, align 1
  store <8 x i1> %989, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true826:                         ; preds = %varying.coherent821
  store <8 x i1> %980, ptr %current.mask, align 1
  %5016 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %980)
  br i1 %5016, label %schedule.52, label %scheduler.loop

varying.coherent.false827:                        ; preds = %varying.coherent821
  store <8 x i1> %980, ptr %current.mask, align 1
  %5017 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %980)
  br i1 %5017, label %schedule.53, label %scheduler.loop

convergence.cascade832:                           ; preds = %convergence.cascade832, %schedule.53
  %convergence.cascade.flow836 = phi <8 x i1> [ %1020, %schedule.53 ], [ %5060, %convergence.cascade832 ]
  %convergence.cascade.depth837 = phi i32 [ 0, %schedule.53 ], [ %5061, %convergence.cascade832 ]
  %5018 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow836)
  %5019 = load i32, ptr %current.token, align 4
  %5020 = icmp ne i32 %5019, 0
  %5021 = and i1 %5018, %5020
  %5022 = sub i32 %5019, 1
  %5023 = select i1 %5021, i32 %5022, i32 0
  %5024 = load i8, ptr %frame.active, align 1
  %5025 = trunc i32 %5023 to i8
  %5026 = shl i8 1, %5025
  %5027 = and i8 %5024, %5026
  %5028 = icmp ne i8 %5027, 0
  %5029 = load <8 x i32>, ptr %frame.static.id, align 32
  %5030 = extractelement <8 x i32> %5029, i32 %5023
  %convergence.target.pointer838 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %5030
  %convergence.dynamic.target839 = load i32, ptr %convergence.target.pointer838, align 4
  %5031 = icmp eq i32 %convergence.dynamic.target839, 53
  %5032 = and i1 %5028, %5031
  %5033 = and i1 %5021, %5032
  %5034 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5023
  %5035 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5023
  %5036 = load <8 x i1>, ptr %5034, align 1
  %5037 = load <8 x i1>, ptr %5035, align 1
  %5038 = or <8 x i1> %5037, %convergence.cascade.flow836
  %5039 = load <8 x i1>, ptr %live.mask, align 1
  %5040 = and <8 x i1> %5036, %5039
  %5041 = icmp eq <8 x i1> %5038, %5040
  %5042 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5041)
  %5043 = and i1 %5033, %5042
  %5044 = select i1 %5043, <8 x i1> zeroinitializer, <8 x i1> %5038
  %5045 = select i1 %5033, <8 x i1> %5044, <8 x i1> %5037
  store <8 x i1> %5045, ptr %5035, align 1
  %5046 = select i1 %5043, <8 x i1> zeroinitializer, <8 x i1> %5036
  store <8 x i1> %5046, ptr %5034, align 1
  %5047 = trunc i32 %5023 to i8
  %5048 = shl i8 1, %5047
  %5049 = xor i8 %5048, -1
  %5050 = and i8 %5024, %5049
  %5051 = select i1 %5043, i8 %5050, i8 %5024
  store i8 %5051, ptr %frame.active, align 1
  %.splatinsert840 = insertelement <8 x i1> poison, i1 %5033, i64 0
  %.splat841 = shufflevector <8 x i1> %.splatinsert840, <8 x i1> poison, <8 x i32> zeroinitializer
  %5052 = and <8 x i1> %convergence.cascade.flow836, %.splat841
  %5053 = load <8 x i1>, ptr %runnable.mask, align 1
  %5054 = xor <8 x i1> %5052, splat (i1 true)
  %5055 = and <8 x i1> %5053, %5054
  store <8 x i1> %5055, ptr %runnable.mask, align 1
  %.splatinsert842 = insertelement <8 x i1> poison, i1 %5043, i64 0
  %.splat843 = shufflevector <8 x i1> %.splatinsert842, <8 x i1> poison, <8 x i32> zeroinitializer
  %5056 = select <8 x i1> %.splat843, <8 x i1> %5038, <8 x i1> zeroinitializer
  %5057 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5058 = extractelement <8 x i32> %5057, i32 %5023
  %5059 = select i1 %5043, i32 %5058, i32 %5019
  store i32 %5059, ptr %current.token, align 4
  %.splatinsert844 = insertelement <8 x i1> poison, i1 %5033, i64 0
  %.splat845 = shufflevector <8 x i1> %.splatinsert844, <8 x i1> poison, <8 x i32> zeroinitializer
  %5060 = select <8 x i1> %.splat845, <8 x i1> %5056, <8 x i1> %convergence.cascade.flow836
  %5061 = add i32 %convergence.cascade.depth837, 1
  %5062 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5060)
  %5063 = icmp ult i32 %5061, 8
  %5064 = and i1 %5062, %5063
  %5065 = and i1 %5033, %5064
  %convergence.parent.token846 = load i32, ptr %current.token, align 4
  %convergence.parent.present847 = icmp ne i32 %convergence.parent.token846, 0
  %5066 = and i1 %5065, %convergence.parent.present847
  br i1 %5066, label %convergence.cascade832, label %convergence.cascade.exit833

convergence.cascade.exit833:                      ; preds = %convergence.cascade832, %schedule.53
  %convergence.cascade.result848 = phi <8 x i1> [ %1020, %schedule.53 ], [ %5060, %convergence.cascade832 ]
  %5067 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result848)
  br i1 %5067, label %convergence.target.53.ready, label %scheduler.loop

convergence.target.53.ready:                      ; preds = %convergence.cascade.exit833
  %5068 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result848)
  %5069 = bitcast <8 x i1> %convergence.cascade.result848 to i8
  %5070 = call i8 @llvm.cttz.i8(i8 %5069, i1 false)
  %5071 = zext i8 %5070 to i32
  %5072 = select i1 %5068, i32 %5071, i32 0
  %5073 = load <8 x i64>, ptr %.slot130, align 64
  %5074 = select <8 x i1> %convergence.cascade.result848, <8 x i64> zeroinitializer, <8 x i64> %5073
  store <8 x i64> %5074, ptr %.slot130, align 64
  %5075 = load <8 x float>, ptr %.slot131, align 32
  %5076 = select <8 x i1> %convergence.cascade.result848, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %5075
  store <8 x float> %5076, ptr %.slot131, align 32
  store <8 x i1> %convergence.cascade.result848, ptr %current.mask, align 1
  %5077 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result848)
  br i1 %5077, label %schedule.54, label %scheduler.loop

varying.divergent850:                             ; preds = %schedule.54
  %5078 = load i32, ptr %current.token, align 4
  %5079 = icmp ne i32 %5078, 0
  %5080 = sub i32 %5078, 1
  %5081 = select i1 %5079, i32 %5080, i32 0
  %5082 = load i8, ptr %frame.active, align 1
  %5083 = trunc i32 %5081 to i8
  %5084 = shl i8 1, %5083
  %5085 = and i8 %5082, %5084
  %5086 = icmp ne i8 %5085, 0
  %5087 = load <8 x i32>, ptr %frame.static.id, align 32
  %5088 = extractelement <8 x i32> %5087, i32 %5081
  %5089 = icmp eq i32 %5088, 19
  %5090 = and i1 %5086, %5089
  %5091 = and i1 %5079, %5090
  %5092 = xor i1 %5091, true
  %5093 = and i1 true, %5092
  %5094 = xor i8 %5082, -1
  %5095 = icmp ne i8 %5094, 0
  %5096 = xor i1 %5095, true
  %5097 = and i1 %5093, %5096
  br i1 %5097, label %convergence.overflow.trap852, label %convergence.overflow.resume853

varying.coherent851:                              ; preds = %schedule.54
  br i1 %1031, label %varying.coherent.true856, label %varying.coherent.false857

convergence.overflow.trap852:                     ; preds = %varying.divergent850
  call void @llvm.trap()
  unreachable

convergence.overflow.resume853:                   ; preds = %varying.divergent850
  %5098 = call i8 @llvm.cttz.i8(i8 %5094, i1 false)
  %5099 = zext i8 %5098 to i32
  %5100 = select i1 %5095, i32 %5099, i32 0
  %5101 = trunc i32 %5100 to i8
  %5102 = shl i8 1, %5101
  %5103 = or i8 %5082, %5102
  %5104 = select i1 %5093, i8 %5103, i8 %5082
  store i8 %5104, ptr %frame.active, align 1
  %5105 = load <8 x i32>, ptr %frame.static.id, align 32
  %5106 = extractelement <8 x i32> %5105, i32 %5100
  %5107 = select i1 %5093, i32 19, i32 %5106
  %5108 = load <8 x i32>, ptr %frame.static.id, align 32
  %5109 = insertelement <8 x i32> %5108, i32 %5107, i32 %5100
  store <8 x i32> %5109, ptr %frame.static.id, align 32
  %5110 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5111 = extractelement <8 x i32> %5110, i32 %5100
  %5112 = select i1 %5093, i32 %5078, i32 %5111
  %5113 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5114 = insertelement <8 x i32> %5113, i32 %5112, i32 %5100
  store <8 x i32> %5114, ptr %frame.parent.token, align 32
  %5115 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5100
  %5116 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5100
  %5117 = load <8 x i1>, ptr %5115, align 1
  %5118 = load <8 x i1>, ptr %5116, align 1
  %5119 = select i1 %5093, <8 x i1> %1021, <8 x i1> %5117
  store <8 x i1> %5119, ptr %5115, align 1
  %5120 = select i1 %5093, <8 x i1> zeroinitializer, <8 x i1> %5118
  store <8 x i1> %5120, ptr %5116, align 1
  %5121 = add i32 %5100, 1
  %5122 = select i1 %5091, i32 %5078, i32 %5121
  %5123 = select i1 true, i32 %5122, i32 %5078
  store i32 %5123, ptr %current.token, align 4
  %5124 = load i32, ptr %current.token, align 4
  %5125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1028)
  %5126 = load i32, ptr %ready.count, align 4
  %5127 = icmp uge i32 %5126, 8
  %5128 = and i1 %5125, %5127
  br i1 %5128, label %ready.overflow.trap854, label %ready.overflow.resume855

ready.overflow.trap854:                           ; preds = %convergence.overflow.resume853
  call void @llvm.trap()
  unreachable

ready.overflow.resume855:                         ; preds = %convergence.overflow.resume853
  %5129 = select i1 %5125, i32 %5126, i32 0
  %5130 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5129
  %5131 = load <8 x i1>, ptr %5130, align 1
  %5132 = select i1 %5125, <8 x i1> %1028, <8 x i1> %5131
  store <8 x i1> %5132, ptr %5130, align 1
  %5133 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5129
  %5134 = load i32, ptr %5133, align 4
  %5135 = select i1 %5125, i32 55, i32 %5134
  store i32 %5135, ptr %5133, align 4
  %5136 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5129
  %5137 = load i32, ptr %5136, align 4
  %5138 = select i1 %5125, i32 %5124, i32 %5137
  store i32 %5138, ptr %5136, align 4
  %5139 = add i32 %5126, 1
  %5140 = select i1 %5125, i32 %5139, i32 %5126
  store i32 %5140, ptr %ready.count, align 4
  %5141 = load <8 x i1>, ptr %runnable.mask, align 1
  %5142 = or <8 x i1> %5141, %1028
  store <8 x i1> %5142, ptr %runnable.mask, align 1
  store <8 x i1> %1030, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true856:                         ; preds = %varying.coherent851
  store <8 x i1> %1021, ptr %current.mask, align 1
  %5143 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1021)
  br i1 %5143, label %schedule.55, label %scheduler.loop

varying.coherent.false857:                        ; preds = %varying.coherent851
  store <8 x i1> %1021, ptr %current.mask, align 1
  %5144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1021)
  br i1 %5144, label %schedule.56, label %scheduler.loop

convergence.cascade862:                           ; preds = %convergence.cascade862, %schedule.56
  %convergence.cascade.flow866 = phi <8 x i1> [ %1061, %schedule.56 ], [ %5187, %convergence.cascade862 ]
  %convergence.cascade.depth867 = phi i32 [ 0, %schedule.56 ], [ %5188, %convergence.cascade862 ]
  %5145 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow866)
  %5146 = load i32, ptr %current.token, align 4
  %5147 = icmp ne i32 %5146, 0
  %5148 = and i1 %5145, %5147
  %5149 = sub i32 %5146, 1
  %5150 = select i1 %5148, i32 %5149, i32 0
  %5151 = load i8, ptr %frame.active, align 1
  %5152 = trunc i32 %5150 to i8
  %5153 = shl i8 1, %5152
  %5154 = and i8 %5151, %5153
  %5155 = icmp ne i8 %5154, 0
  %5156 = load <8 x i32>, ptr %frame.static.id, align 32
  %5157 = extractelement <8 x i32> %5156, i32 %5150
  %convergence.target.pointer868 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %5157
  %convergence.dynamic.target869 = load i32, ptr %convergence.target.pointer868, align 4
  %5158 = icmp eq i32 %convergence.dynamic.target869, 56
  %5159 = and i1 %5155, %5158
  %5160 = and i1 %5148, %5159
  %5161 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5150
  %5162 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5150
  %5163 = load <8 x i1>, ptr %5161, align 1
  %5164 = load <8 x i1>, ptr %5162, align 1
  %5165 = or <8 x i1> %5164, %convergence.cascade.flow866
  %5166 = load <8 x i1>, ptr %live.mask, align 1
  %5167 = and <8 x i1> %5163, %5166
  %5168 = icmp eq <8 x i1> %5165, %5167
  %5169 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5168)
  %5170 = and i1 %5160, %5169
  %5171 = select i1 %5170, <8 x i1> zeroinitializer, <8 x i1> %5165
  %5172 = select i1 %5160, <8 x i1> %5171, <8 x i1> %5164
  store <8 x i1> %5172, ptr %5162, align 1
  %5173 = select i1 %5170, <8 x i1> zeroinitializer, <8 x i1> %5163
  store <8 x i1> %5173, ptr %5161, align 1
  %5174 = trunc i32 %5150 to i8
  %5175 = shl i8 1, %5174
  %5176 = xor i8 %5175, -1
  %5177 = and i8 %5151, %5176
  %5178 = select i1 %5170, i8 %5177, i8 %5151
  store i8 %5178, ptr %frame.active, align 1
  %.splatinsert870 = insertelement <8 x i1> poison, i1 %5160, i64 0
  %.splat871 = shufflevector <8 x i1> %.splatinsert870, <8 x i1> poison, <8 x i32> zeroinitializer
  %5179 = and <8 x i1> %convergence.cascade.flow866, %.splat871
  %5180 = load <8 x i1>, ptr %runnable.mask, align 1
  %5181 = xor <8 x i1> %5179, splat (i1 true)
  %5182 = and <8 x i1> %5180, %5181
  store <8 x i1> %5182, ptr %runnable.mask, align 1
  %.splatinsert872 = insertelement <8 x i1> poison, i1 %5170, i64 0
  %.splat873 = shufflevector <8 x i1> %.splatinsert872, <8 x i1> poison, <8 x i32> zeroinitializer
  %5183 = select <8 x i1> %.splat873, <8 x i1> %5165, <8 x i1> zeroinitializer
  %5184 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5185 = extractelement <8 x i32> %5184, i32 %5150
  %5186 = select i1 %5170, i32 %5185, i32 %5146
  store i32 %5186, ptr %current.token, align 4
  %.splatinsert874 = insertelement <8 x i1> poison, i1 %5160, i64 0
  %.splat875 = shufflevector <8 x i1> %.splatinsert874, <8 x i1> poison, <8 x i32> zeroinitializer
  %5187 = select <8 x i1> %.splat875, <8 x i1> %5183, <8 x i1> %convergence.cascade.flow866
  %5188 = add i32 %convergence.cascade.depth867, 1
  %5189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5187)
  %5190 = icmp ult i32 %5188, 8
  %5191 = and i1 %5189, %5190
  %5192 = and i1 %5160, %5191
  %convergence.parent.token876 = load i32, ptr %current.token, align 4
  %convergence.parent.present877 = icmp ne i32 %convergence.parent.token876, 0
  %5193 = and i1 %5192, %convergence.parent.present877
  br i1 %5193, label %convergence.cascade862, label %convergence.cascade.exit863

convergence.cascade.exit863:                      ; preds = %convergence.cascade862, %schedule.56
  %convergence.cascade.result878 = phi <8 x i1> [ %1061, %schedule.56 ], [ %5187, %convergence.cascade862 ]
  %5194 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result878)
  br i1 %5194, label %convergence.target.56.ready, label %scheduler.loop

convergence.target.56.ready:                      ; preds = %convergence.cascade.exit863
  %5195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result878)
  %5196 = bitcast <8 x i1> %convergence.cascade.result878 to i8
  %5197 = call i8 @llvm.cttz.i8(i8 %5196, i1 false)
  %5198 = zext i8 %5197 to i32
  %5199 = select i1 %5195, i32 %5198, i32 0
  %5200 = load <8 x i64>, ptr %.slot132, align 64
  %5201 = select <8 x i1> %convergence.cascade.result878, <8 x i64> zeroinitializer, <8 x i64> %5200
  store <8 x i64> %5201, ptr %.slot132, align 64
  %5202 = load <8 x float>, ptr %.slot133, align 32
  %5203 = select <8 x i1> %convergence.cascade.result878, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %5202
  store <8 x float> %5203, ptr %.slot133, align 32
  store <8 x i1> %convergence.cascade.result878, ptr %current.mask, align 1
  %5204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result878)
  br i1 %5204, label %schedule.57, label %scheduler.loop

varying.divergent880:                             ; preds = %schedule.57
  %5205 = load i32, ptr %current.token, align 4
  %5206 = icmp ne i32 %5205, 0
  %5207 = sub i32 %5205, 1
  %5208 = select i1 %5206, i32 %5207, i32 0
  %5209 = load i8, ptr %frame.active, align 1
  %5210 = trunc i32 %5208 to i8
  %5211 = shl i8 1, %5210
  %5212 = and i8 %5209, %5211
  %5213 = icmp ne i8 %5212, 0
  %5214 = load <8 x i32>, ptr %frame.static.id, align 32
  %5215 = extractelement <8 x i32> %5214, i32 %5208
  %5216 = icmp eq i32 %5215, 20
  %5217 = and i1 %5213, %5216
  %5218 = and i1 %5206, %5217
  %5219 = xor i1 %5218, true
  %5220 = and i1 true, %5219
  %5221 = xor i8 %5209, -1
  %5222 = icmp ne i8 %5221, 0
  %5223 = xor i1 %5222, true
  %5224 = and i1 %5220, %5223
  br i1 %5224, label %convergence.overflow.trap882, label %convergence.overflow.resume883

varying.coherent881:                              ; preds = %schedule.57
  br i1 %1072, label %varying.coherent.true886, label %varying.coherent.false887

convergence.overflow.trap882:                     ; preds = %varying.divergent880
  call void @llvm.trap()
  unreachable

convergence.overflow.resume883:                   ; preds = %varying.divergent880
  %5225 = call i8 @llvm.cttz.i8(i8 %5221, i1 false)
  %5226 = zext i8 %5225 to i32
  %5227 = select i1 %5222, i32 %5226, i32 0
  %5228 = trunc i32 %5227 to i8
  %5229 = shl i8 1, %5228
  %5230 = or i8 %5209, %5229
  %5231 = select i1 %5220, i8 %5230, i8 %5209
  store i8 %5231, ptr %frame.active, align 1
  %5232 = load <8 x i32>, ptr %frame.static.id, align 32
  %5233 = extractelement <8 x i32> %5232, i32 %5227
  %5234 = select i1 %5220, i32 20, i32 %5233
  %5235 = load <8 x i32>, ptr %frame.static.id, align 32
  %5236 = insertelement <8 x i32> %5235, i32 %5234, i32 %5227
  store <8 x i32> %5236, ptr %frame.static.id, align 32
  %5237 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5238 = extractelement <8 x i32> %5237, i32 %5227
  %5239 = select i1 %5220, i32 %5205, i32 %5238
  %5240 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5241 = insertelement <8 x i32> %5240, i32 %5239, i32 %5227
  store <8 x i32> %5241, ptr %frame.parent.token, align 32
  %5242 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5227
  %5243 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5227
  %5244 = load <8 x i1>, ptr %5242, align 1
  %5245 = load <8 x i1>, ptr %5243, align 1
  %5246 = select i1 %5220, <8 x i1> %1062, <8 x i1> %5244
  store <8 x i1> %5246, ptr %5242, align 1
  %5247 = select i1 %5220, <8 x i1> zeroinitializer, <8 x i1> %5245
  store <8 x i1> %5247, ptr %5243, align 1
  %5248 = add i32 %5227, 1
  %5249 = select i1 %5218, i32 %5205, i32 %5248
  %5250 = select i1 true, i32 %5249, i32 %5205
  store i32 %5250, ptr %current.token, align 4
  %5251 = load i32, ptr %current.token, align 4
  %5252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1069)
  %5253 = load i32, ptr %ready.count, align 4
  %5254 = icmp uge i32 %5253, 8
  %5255 = and i1 %5252, %5254
  br i1 %5255, label %ready.overflow.trap884, label %ready.overflow.resume885

ready.overflow.trap884:                           ; preds = %convergence.overflow.resume883
  call void @llvm.trap()
  unreachable

ready.overflow.resume885:                         ; preds = %convergence.overflow.resume883
  %5256 = select i1 %5252, i32 %5253, i32 0
  %5257 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5256
  %5258 = load <8 x i1>, ptr %5257, align 1
  %5259 = select i1 %5252, <8 x i1> %1069, <8 x i1> %5258
  store <8 x i1> %5259, ptr %5257, align 1
  %5260 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5256
  %5261 = load i32, ptr %5260, align 4
  %5262 = select i1 %5252, i32 58, i32 %5261
  store i32 %5262, ptr %5260, align 4
  %5263 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5256
  %5264 = load i32, ptr %5263, align 4
  %5265 = select i1 %5252, i32 %5251, i32 %5264
  store i32 %5265, ptr %5263, align 4
  %5266 = add i32 %5253, 1
  %5267 = select i1 %5252, i32 %5266, i32 %5253
  store i32 %5267, ptr %ready.count, align 4
  %5268 = load <8 x i1>, ptr %runnable.mask, align 1
  %5269 = or <8 x i1> %5268, %1069
  store <8 x i1> %5269, ptr %runnable.mask, align 1
  store <8 x i1> %1071, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true886:                         ; preds = %varying.coherent881
  store <8 x i1> %1062, ptr %current.mask, align 1
  %5270 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1062)
  br i1 %5270, label %schedule.58, label %scheduler.loop

varying.coherent.false887:                        ; preds = %varying.coherent881
  store <8 x i1> %1062, ptr %current.mask, align 1
  %5271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1062)
  br i1 %5271, label %schedule.59, label %scheduler.loop

convergence.cascade892:                           ; preds = %convergence.cascade892, %schedule.59
  %convergence.cascade.flow896 = phi <8 x i1> [ %1102, %schedule.59 ], [ %5314, %convergence.cascade892 ]
  %convergence.cascade.depth897 = phi i32 [ 0, %schedule.59 ], [ %5315, %convergence.cascade892 ]
  %5272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow896)
  %5273 = load i32, ptr %current.token, align 4
  %5274 = icmp ne i32 %5273, 0
  %5275 = and i1 %5272, %5274
  %5276 = sub i32 %5273, 1
  %5277 = select i1 %5275, i32 %5276, i32 0
  %5278 = load i8, ptr %frame.active, align 1
  %5279 = trunc i32 %5277 to i8
  %5280 = shl i8 1, %5279
  %5281 = and i8 %5278, %5280
  %5282 = icmp ne i8 %5281, 0
  %5283 = load <8 x i32>, ptr %frame.static.id, align 32
  %5284 = extractelement <8 x i32> %5283, i32 %5277
  %convergence.target.pointer898 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %5284
  %convergence.dynamic.target899 = load i32, ptr %convergence.target.pointer898, align 4
  %5285 = icmp eq i32 %convergence.dynamic.target899, 59
  %5286 = and i1 %5282, %5285
  %5287 = and i1 %5275, %5286
  %5288 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5277
  %5289 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5277
  %5290 = load <8 x i1>, ptr %5288, align 1
  %5291 = load <8 x i1>, ptr %5289, align 1
  %5292 = or <8 x i1> %5291, %convergence.cascade.flow896
  %5293 = load <8 x i1>, ptr %live.mask, align 1
  %5294 = and <8 x i1> %5290, %5293
  %5295 = icmp eq <8 x i1> %5292, %5294
  %5296 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5295)
  %5297 = and i1 %5287, %5296
  %5298 = select i1 %5297, <8 x i1> zeroinitializer, <8 x i1> %5292
  %5299 = select i1 %5287, <8 x i1> %5298, <8 x i1> %5291
  store <8 x i1> %5299, ptr %5289, align 1
  %5300 = select i1 %5297, <8 x i1> zeroinitializer, <8 x i1> %5290
  store <8 x i1> %5300, ptr %5288, align 1
  %5301 = trunc i32 %5277 to i8
  %5302 = shl i8 1, %5301
  %5303 = xor i8 %5302, -1
  %5304 = and i8 %5278, %5303
  %5305 = select i1 %5297, i8 %5304, i8 %5278
  store i8 %5305, ptr %frame.active, align 1
  %.splatinsert900 = insertelement <8 x i1> poison, i1 %5287, i64 0
  %.splat901 = shufflevector <8 x i1> %.splatinsert900, <8 x i1> poison, <8 x i32> zeroinitializer
  %5306 = and <8 x i1> %convergence.cascade.flow896, %.splat901
  %5307 = load <8 x i1>, ptr %runnable.mask, align 1
  %5308 = xor <8 x i1> %5306, splat (i1 true)
  %5309 = and <8 x i1> %5307, %5308
  store <8 x i1> %5309, ptr %runnable.mask, align 1
  %.splatinsert902 = insertelement <8 x i1> poison, i1 %5297, i64 0
  %.splat903 = shufflevector <8 x i1> %.splatinsert902, <8 x i1> poison, <8 x i32> zeroinitializer
  %5310 = select <8 x i1> %.splat903, <8 x i1> %5292, <8 x i1> zeroinitializer
  %5311 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5312 = extractelement <8 x i32> %5311, i32 %5277
  %5313 = select i1 %5297, i32 %5312, i32 %5273
  store i32 %5313, ptr %current.token, align 4
  %.splatinsert904 = insertelement <8 x i1> poison, i1 %5287, i64 0
  %.splat905 = shufflevector <8 x i1> %.splatinsert904, <8 x i1> poison, <8 x i32> zeroinitializer
  %5314 = select <8 x i1> %.splat905, <8 x i1> %5310, <8 x i1> %convergence.cascade.flow896
  %5315 = add i32 %convergence.cascade.depth897, 1
  %5316 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5314)
  %5317 = icmp ult i32 %5315, 8
  %5318 = and i1 %5316, %5317
  %5319 = and i1 %5287, %5318
  %convergence.parent.token906 = load i32, ptr %current.token, align 4
  %convergence.parent.present907 = icmp ne i32 %convergence.parent.token906, 0
  %5320 = and i1 %5319, %convergence.parent.present907
  br i1 %5320, label %convergence.cascade892, label %convergence.cascade.exit893

convergence.cascade.exit893:                      ; preds = %convergence.cascade892, %schedule.59
  %convergence.cascade.result908 = phi <8 x i1> [ %1102, %schedule.59 ], [ %5314, %convergence.cascade892 ]
  %5321 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  br i1 %5321, label %convergence.target.59.ready, label %scheduler.loop

convergence.target.59.ready:                      ; preds = %convergence.cascade.exit893
  %5322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5323 = bitcast <8 x i1> %convergence.cascade.result908 to i8
  %5324 = call i8 @llvm.cttz.i8(i8 %5323, i1 false)
  %5325 = zext i8 %5324 to i32
  %5326 = select i1 %5322, i32 %5325, i32 0
  %.state909 = load <8 x float>, ptr %.slot69, align 32
  %.state910 = load <8 x float>, ptr %.slot119, align 32
  %5327 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state909, <8 x float> %.state910)
  %5328 = load <8 x float>, ptr %.spill134, align 32
  %5329 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5327, <8 x float> %5328
  store <8 x float> %5329, ptr %.spill134, align 32
  %.state911 = load <8 x float>, ptr %.slot70, align 32
  %.state912 = load <8 x float>, ptr %.slot121, align 32
  %5330 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state911, <8 x float> %.state912)
  %5331 = load <8 x float>, ptr %.spill135, align 32
  %5332 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5330, <8 x float> %5331
  store <8 x float> %5332, ptr %.spill135, align 32
  %.state913 = load <8 x float>, ptr %.slot71, align 32
  %.state914 = load <8 x float>, ptr %.slot123, align 32
  %5333 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state913, <8 x float> %.state914)
  %5334 = load <8 x float>, ptr %.spill136, align 32
  %5335 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5333, <8 x float> %5334
  store <8 x float> %5335, ptr %.spill136, align 32
  %.state915 = load <8 x float>, ptr %.slot72, align 32
  %.state916 = load <8 x float>, ptr %.slot125, align 32
  %5336 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state915, <8 x float> %.state916)
  %5337 = load <8 x float>, ptr %.spill137, align 32
  %5338 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5336, <8 x float> %5337
  store <8 x float> %5338, ptr %.spill137, align 32
  %.state917 = load <8 x float>, ptr %.slot73, align 32
  %.state918 = load <8 x float>, ptr %.slot127, align 32
  %5339 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state917, <8 x float> %.state918)
  %5340 = load <8 x float>, ptr %.spill138, align 32
  %5341 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5339, <8 x float> %5340
  store <8 x float> %5341, ptr %.spill138, align 32
  %.state919 = load <8 x float>, ptr %.slot74, align 32
  %.state920 = load <8 x float>, ptr %.slot129, align 32
  %5342 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state919, <8 x float> %.state920)
  %5343 = load <8 x float>, ptr %.spill139, align 32
  %5344 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5342, <8 x float> %5343
  store <8 x float> %5344, ptr %.spill139, align 32
  %.state921 = load <8 x float>, ptr %.slot75, align 32
  %.state922 = load <8 x float>, ptr %.slot131, align 32
  %5345 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state921, <8 x float> %.state922)
  %5346 = load <8 x float>, ptr %.spill140, align 32
  %5347 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5345, <8 x float> %5346
  store <8 x float> %5347, ptr %.spill140, align 32
  %.state923 = load <8 x float>, ptr %.slot76, align 32
  %.state924 = load <8 x float>, ptr %.slot133, align 32
  %5348 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state923, <8 x float> %.state924)
  %5349 = load <8 x float>, ptr %.spill141, align 32
  %5350 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5348, <8 x float> %5349
  store <8 x float> %5350, ptr %.spill141, align 32
  %5351 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill142, align 64
  %5352 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5353 = extractvalue { <8 x ptr>, <8 x i64> } %5351, 0
  %5354 = select <8 x i1> %convergence.cascade.result908, <8 x ptr> %5352, <8 x ptr> %5353
  %5355 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5356 = extractvalue { <8 x ptr>, <8 x i64> } %5351, 1
  %5357 = select <8 x i1> %convergence.cascade.result908, <8 x i64> %5355, <8 x i64> %5356
  %5358 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5354, 0
  %5359 = insertvalue { <8 x ptr>, <8 x i64> } %5358, <8 x i64> %5357, 1
  store { <8 x ptr>, <8 x i64> } %5359, ptr %tile_snapshot.spill142, align 64
  %5360 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5361 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5362 = add <8 x i64> %5361, zeroinitializer
  %5363 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5360, 0
  %5364 = insertvalue { <8 x ptr>, <8 x i64> } %5363, <8 x i64> %5362, 1
  %5365 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5366 = extractvalue { <8 x ptr>, <8 x i64> } %5364, 1
  %5367 = extractelement <8 x ptr> %5365, i32 0
  %5368 = extractelement <8 x i64> %5366, i32 %5326
  %5369 = zext i32 %5326 to i64
  %5370 = mul i64 %5369, 4
  %5371 = sub i64 %5368, %5370
  %5372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5373 = select i1 %5372, i64 %5371, i64 0
  %private.contiguous.address925 = getelementptr i8, ptr %5367, i64 %5373
  %private.contiguous.preserve926 = load <8 x float>, ptr %private.contiguous.address925, align 4
  %5374 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5327, <8 x float> %private.contiguous.preserve926
  store <8 x float> %5374, ptr %private.contiguous.address925, align 4
  %5375 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5376 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5377 = add <8 x i64> %5376, splat (i64 32)
  %5378 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5375, 0
  %5379 = insertvalue { <8 x ptr>, <8 x i64> } %5378, <8 x i64> %5377, 1
  %5380 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5381 = extractvalue { <8 x ptr>, <8 x i64> } %5379, 1
  %5382 = extractelement <8 x ptr> %5380, i32 0
  %5383 = extractelement <8 x i64> %5381, i32 %5326
  %5384 = zext i32 %5326 to i64
  %5385 = mul i64 %5384, 4
  %5386 = sub i64 %5383, %5385
  %5387 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5388 = select i1 %5387, i64 %5386, i64 0
  %private.contiguous.address927 = getelementptr i8, ptr %5382, i64 %5388
  %private.contiguous.preserve928 = load <8 x float>, ptr %private.contiguous.address927, align 4
  %5389 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5330, <8 x float> %private.contiguous.preserve928
  store <8 x float> %5389, ptr %private.contiguous.address927, align 4
  %5390 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5391 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5392 = add <8 x i64> %5391, splat (i64 64)
  %5393 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5390, 0
  %5394 = insertvalue { <8 x ptr>, <8 x i64> } %5393, <8 x i64> %5392, 1
  %5395 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5396 = extractvalue { <8 x ptr>, <8 x i64> } %5394, 1
  %5397 = extractelement <8 x ptr> %5395, i32 0
  %5398 = extractelement <8 x i64> %5396, i32 %5326
  %5399 = zext i32 %5326 to i64
  %5400 = mul i64 %5399, 4
  %5401 = sub i64 %5398, %5400
  %5402 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5403 = select i1 %5402, i64 %5401, i64 0
  %private.contiguous.address929 = getelementptr i8, ptr %5397, i64 %5403
  %private.contiguous.preserve930 = load <8 x float>, ptr %private.contiguous.address929, align 4
  %5404 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5333, <8 x float> %private.contiguous.preserve930
  store <8 x float> %5404, ptr %private.contiguous.address929, align 4
  %5405 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5406 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5407 = add <8 x i64> %5406, splat (i64 96)
  %5408 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5405, 0
  %5409 = insertvalue { <8 x ptr>, <8 x i64> } %5408, <8 x i64> %5407, 1
  %5410 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5411 = extractvalue { <8 x ptr>, <8 x i64> } %5409, 1
  %5412 = extractelement <8 x ptr> %5410, i32 0
  %5413 = extractelement <8 x i64> %5411, i32 %5326
  %5414 = zext i32 %5326 to i64
  %5415 = mul i64 %5414, 4
  %5416 = sub i64 %5413, %5415
  %5417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5418 = select i1 %5417, i64 %5416, i64 0
  %private.contiguous.address931 = getelementptr i8, ptr %5412, i64 %5418
  %private.contiguous.preserve932 = load <8 x float>, ptr %private.contiguous.address931, align 4
  %5419 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5336, <8 x float> %private.contiguous.preserve932
  store <8 x float> %5419, ptr %private.contiguous.address931, align 4
  %5420 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5421 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5422 = add <8 x i64> %5421, splat (i64 128)
  %5423 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5420, 0
  %5424 = insertvalue { <8 x ptr>, <8 x i64> } %5423, <8 x i64> %5422, 1
  %5425 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5426 = extractvalue { <8 x ptr>, <8 x i64> } %5424, 1
  %5427 = extractelement <8 x ptr> %5425, i32 0
  %5428 = extractelement <8 x i64> %5426, i32 %5326
  %5429 = zext i32 %5326 to i64
  %5430 = mul i64 %5429, 4
  %5431 = sub i64 %5428, %5430
  %5432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5433 = select i1 %5432, i64 %5431, i64 0
  %private.contiguous.address933 = getelementptr i8, ptr %5427, i64 %5433
  %private.contiguous.preserve934 = load <8 x float>, ptr %private.contiguous.address933, align 4
  %5434 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5339, <8 x float> %private.contiguous.preserve934
  store <8 x float> %5434, ptr %private.contiguous.address933, align 4
  %5435 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5436 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5437 = add <8 x i64> %5436, splat (i64 160)
  %5438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5435, 0
  %5439 = insertvalue { <8 x ptr>, <8 x i64> } %5438, <8 x i64> %5437, 1
  %5440 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5441 = extractvalue { <8 x ptr>, <8 x i64> } %5439, 1
  %5442 = extractelement <8 x ptr> %5440, i32 0
  %5443 = extractelement <8 x i64> %5441, i32 %5326
  %5444 = zext i32 %5326 to i64
  %5445 = mul i64 %5444, 4
  %5446 = sub i64 %5443, %5445
  %5447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5448 = select i1 %5447, i64 %5446, i64 0
  %private.contiguous.address935 = getelementptr i8, ptr %5442, i64 %5448
  %private.contiguous.preserve936 = load <8 x float>, ptr %private.contiguous.address935, align 4
  %5449 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5342, <8 x float> %private.contiguous.preserve936
  store <8 x float> %5449, ptr %private.contiguous.address935, align 4
  %5450 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5451 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5452 = add <8 x i64> %5451, splat (i64 192)
  %5453 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5450, 0
  %5454 = insertvalue { <8 x ptr>, <8 x i64> } %5453, <8 x i64> %5452, 1
  %5455 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5456 = extractvalue { <8 x ptr>, <8 x i64> } %5454, 1
  %5457 = extractelement <8 x ptr> %5455, i32 0
  %5458 = extractelement <8 x i64> %5456, i32 %5326
  %5459 = zext i32 %5326 to i64
  %5460 = mul i64 %5459, 4
  %5461 = sub i64 %5458, %5460
  %5462 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5463 = select i1 %5462, i64 %5461, i64 0
  %private.contiguous.address937 = getelementptr i8, ptr %5457, i64 %5463
  %private.contiguous.preserve938 = load <8 x float>, ptr %private.contiguous.address937, align 4
  %5464 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5345, <8 x float> %private.contiguous.preserve938
  store <8 x float> %5464, ptr %private.contiguous.address937, align 4
  %5465 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5466 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5467 = add <8 x i64> %5466, splat (i64 224)
  %5468 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5465, 0
  %5469 = insertvalue { <8 x ptr>, <8 x i64> } %5468, <8 x i64> %5467, 1
  %5470 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5471 = extractvalue { <8 x ptr>, <8 x i64> } %5469, 1
  %5472 = extractelement <8 x ptr> %5470, i32 0
  %5473 = extractelement <8 x i64> %5471, i32 %5326
  %5474 = zext i32 %5326 to i64
  %5475 = mul i64 %5474, 4
  %5476 = sub i64 %5473, %5475
  %5477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5478 = select i1 %5477, i64 %5476, i64 0
  %private.contiguous.address939 = getelementptr i8, ptr %5472, i64 %5478
  %private.contiguous.preserve940 = load <8 x float>, ptr %private.contiguous.address939, align 4
  %5479 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5348, <8 x float> %private.contiguous.preserve940
  store <8 x float> %5479, ptr %private.contiguous.address939, align 4
  %.state941 = load <8 x float>, ptr %.slot69, align 32
  %5480 = fsub <8 x float> %.state941, %5327
  %.state942 = load <8 x float>, ptr %.slot70, align 32
  %5481 = fsub <8 x float> %.state942, %5330
  %.state943 = load <8 x float>, ptr %.slot71, align 32
  %5482 = fsub <8 x float> %.state943, %5333
  %.state944 = load <8 x float>, ptr %.slot72, align 32
  %5483 = fsub <8 x float> %.state944, %5336
  %.state945 = load <8 x float>, ptr %.slot73, align 32
  %5484 = fsub <8 x float> %.state945, %5339
  %.state946 = load <8 x float>, ptr %.slot74, align 32
  %5485 = fsub <8 x float> %.state946, %5342
  %.state947 = load <8 x float>, ptr %.slot75, align 32
  %5486 = fsub <8 x float> %.state947, %5345
  %.state948 = load <8 x float>, ptr %.slot76, align 32
  %5487 = fsub <8 x float> %.state948, %5348
  %5488 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5480, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5488)
  %5489 = load <8 x float>, ptr %.spill143, align 32
  %5490 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp, <8 x float> %5489
  store <8 x float> %5490, ptr %.spill143, align 32
  %5491 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5481, <8 x float> zeroinitializer
  %native.exp949 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5491)
  %5492 = load <8 x float>, ptr %.spill144, align 32
  %5493 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp949, <8 x float> %5492
  store <8 x float> %5493, ptr %.spill144, align 32
  %5494 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5482, <8 x float> zeroinitializer
  %native.exp950 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5494)
  %5495 = load <8 x float>, ptr %.spill145, align 32
  %5496 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp950, <8 x float> %5495
  store <8 x float> %5496, ptr %.spill145, align 32
  %5497 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5483, <8 x float> zeroinitializer
  %native.exp951 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5497)
  %5498 = load <8 x float>, ptr %.spill146, align 32
  %5499 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp951, <8 x float> %5498
  store <8 x float> %5499, ptr %.spill146, align 32
  %5500 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5484, <8 x float> zeroinitializer
  %native.exp952 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5500)
  %5501 = load <8 x float>, ptr %.spill147, align 32
  %5502 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp952, <8 x float> %5501
  store <8 x float> %5502, ptr %.spill147, align 32
  %5503 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5485, <8 x float> zeroinitializer
  %native.exp953 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5503)
  %5504 = load <8 x float>, ptr %.spill148, align 32
  %5505 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp953, <8 x float> %5504
  store <8 x float> %5505, ptr %.spill148, align 32
  %5506 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5486, <8 x float> zeroinitializer
  %native.exp954 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5506)
  %5507 = load <8 x float>, ptr %.spill149, align 32
  %5508 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp954, <8 x float> %5507
  store <8 x float> %5508, ptr %.spill149, align 32
  %5509 = select <8 x i1> %convergence.cascade.result908, <8 x float> %5487, <8 x float> zeroinitializer
  %native.exp955 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5509)
  %5510 = load <8 x float>, ptr %.spill150, align 32
  %5511 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp955, <8 x float> %5510
  store <8 x float> %5511, ptr %.spill150, align 32
  %5512 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill151, align 64
  %5513 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5514 = extractvalue { <8 x ptr>, <8 x i64> } %5512, 0
  %5515 = select <8 x i1> %convergence.cascade.result908, <8 x ptr> %5513, <8 x ptr> %5514
  %5516 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5517 = extractvalue { <8 x ptr>, <8 x i64> } %5512, 1
  %5518 = select <8 x i1> %convergence.cascade.result908, <8 x i64> %5516, <8 x i64> %5517
  %5519 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5515, 0
  %5520 = insertvalue { <8 x ptr>, <8 x i64> } %5519, <8 x i64> %5518, 1
  store { <8 x ptr>, <8 x i64> } %5520, ptr %tile_snapshot.spill151, align 64
  %5521 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5522 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5523 = add <8 x i64> %5522, zeroinitializer
  %5524 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5521, 0
  %5525 = insertvalue { <8 x ptr>, <8 x i64> } %5524, <8 x i64> %5523, 1
  %5526 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5527 = extractvalue { <8 x ptr>, <8 x i64> } %5525, 1
  %5528 = extractelement <8 x ptr> %5526, i32 0
  %5529 = extractelement <8 x i64> %5527, i32 %5326
  %5530 = zext i32 %5326 to i64
  %5531 = mul i64 %5530, 4
  %5532 = sub i64 %5529, %5531
  %5533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5534 = select i1 %5533, i64 %5532, i64 0
  %private.contiguous.address956 = getelementptr i8, ptr %5528, i64 %5534
  %private.contiguous.preserve957 = load <8 x float>, ptr %private.contiguous.address956, align 4
  %5535 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve957
  store <8 x float> %5535, ptr %private.contiguous.address956, align 4
  %5536 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5537 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5538 = add <8 x i64> %5537, splat (i64 32)
  %5539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5536, 0
  %5540 = insertvalue { <8 x ptr>, <8 x i64> } %5539, <8 x i64> %5538, 1
  %5541 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5542 = extractvalue { <8 x ptr>, <8 x i64> } %5540, 1
  %5543 = extractelement <8 x ptr> %5541, i32 0
  %5544 = extractelement <8 x i64> %5542, i32 %5326
  %5545 = zext i32 %5326 to i64
  %5546 = mul i64 %5545, 4
  %5547 = sub i64 %5544, %5546
  %5548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5549 = select i1 %5548, i64 %5547, i64 0
  %private.contiguous.address958 = getelementptr i8, ptr %5543, i64 %5549
  %private.contiguous.preserve959 = load <8 x float>, ptr %private.contiguous.address958, align 4
  %5550 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp949, <8 x float> %private.contiguous.preserve959
  store <8 x float> %5550, ptr %private.contiguous.address958, align 4
  %5551 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5552 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5553 = add <8 x i64> %5552, splat (i64 64)
  %5554 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5551, 0
  %5555 = insertvalue { <8 x ptr>, <8 x i64> } %5554, <8 x i64> %5553, 1
  %5556 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5557 = extractvalue { <8 x ptr>, <8 x i64> } %5555, 1
  %5558 = extractelement <8 x ptr> %5556, i32 0
  %5559 = extractelement <8 x i64> %5557, i32 %5326
  %5560 = zext i32 %5326 to i64
  %5561 = mul i64 %5560, 4
  %5562 = sub i64 %5559, %5561
  %5563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5564 = select i1 %5563, i64 %5562, i64 0
  %private.contiguous.address960 = getelementptr i8, ptr %5558, i64 %5564
  %private.contiguous.preserve961 = load <8 x float>, ptr %private.contiguous.address960, align 4
  %5565 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp950, <8 x float> %private.contiguous.preserve961
  store <8 x float> %5565, ptr %private.contiguous.address960, align 4
  %5566 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5567 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5568 = add <8 x i64> %5567, splat (i64 96)
  %5569 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5566, 0
  %5570 = insertvalue { <8 x ptr>, <8 x i64> } %5569, <8 x i64> %5568, 1
  %5571 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5572 = extractvalue { <8 x ptr>, <8 x i64> } %5570, 1
  %5573 = extractelement <8 x ptr> %5571, i32 0
  %5574 = extractelement <8 x i64> %5572, i32 %5326
  %5575 = zext i32 %5326 to i64
  %5576 = mul i64 %5575, 4
  %5577 = sub i64 %5574, %5576
  %5578 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5579 = select i1 %5578, i64 %5577, i64 0
  %private.contiguous.address962 = getelementptr i8, ptr %5573, i64 %5579
  %private.contiguous.preserve963 = load <8 x float>, ptr %private.contiguous.address962, align 4
  %5580 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp951, <8 x float> %private.contiguous.preserve963
  store <8 x float> %5580, ptr %private.contiguous.address962, align 4
  %5581 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5582 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5583 = add <8 x i64> %5582, splat (i64 128)
  %5584 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5581, 0
  %5585 = insertvalue { <8 x ptr>, <8 x i64> } %5584, <8 x i64> %5583, 1
  %5586 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5587 = extractvalue { <8 x ptr>, <8 x i64> } %5585, 1
  %5588 = extractelement <8 x ptr> %5586, i32 0
  %5589 = extractelement <8 x i64> %5587, i32 %5326
  %5590 = zext i32 %5326 to i64
  %5591 = mul i64 %5590, 4
  %5592 = sub i64 %5589, %5591
  %5593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5594 = select i1 %5593, i64 %5592, i64 0
  %private.contiguous.address964 = getelementptr i8, ptr %5588, i64 %5594
  %private.contiguous.preserve965 = load <8 x float>, ptr %private.contiguous.address964, align 4
  %5595 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp952, <8 x float> %private.contiguous.preserve965
  store <8 x float> %5595, ptr %private.contiguous.address964, align 4
  %5596 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5597 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5598 = add <8 x i64> %5597, splat (i64 160)
  %5599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5596, 0
  %5600 = insertvalue { <8 x ptr>, <8 x i64> } %5599, <8 x i64> %5598, 1
  %5601 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5602 = extractvalue { <8 x ptr>, <8 x i64> } %5600, 1
  %5603 = extractelement <8 x ptr> %5601, i32 0
  %5604 = extractelement <8 x i64> %5602, i32 %5326
  %5605 = zext i32 %5326 to i64
  %5606 = mul i64 %5605, 4
  %5607 = sub i64 %5604, %5606
  %5608 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5609 = select i1 %5608, i64 %5607, i64 0
  %private.contiguous.address966 = getelementptr i8, ptr %5603, i64 %5609
  %private.contiguous.preserve967 = load <8 x float>, ptr %private.contiguous.address966, align 4
  %5610 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp953, <8 x float> %private.contiguous.preserve967
  store <8 x float> %5610, ptr %private.contiguous.address966, align 4
  %5611 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5612 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5613 = add <8 x i64> %5612, splat (i64 192)
  %5614 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5611, 0
  %5615 = insertvalue { <8 x ptr>, <8 x i64> } %5614, <8 x i64> %5613, 1
  %5616 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5617 = extractvalue { <8 x ptr>, <8 x i64> } %5615, 1
  %5618 = extractelement <8 x ptr> %5616, i32 0
  %5619 = extractelement <8 x i64> %5617, i32 %5326
  %5620 = zext i32 %5326 to i64
  %5621 = mul i64 %5620, 4
  %5622 = sub i64 %5619, %5621
  %5623 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5624 = select i1 %5623, i64 %5622, i64 0
  %private.contiguous.address968 = getelementptr i8, ptr %5618, i64 %5624
  %private.contiguous.preserve969 = load <8 x float>, ptr %private.contiguous.address968, align 4
  %5625 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp954, <8 x float> %private.contiguous.preserve969
  store <8 x float> %5625, ptr %private.contiguous.address968, align 4
  %5626 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5627 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5628 = add <8 x i64> %5627, splat (i64 224)
  %5629 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5626, 0
  %5630 = insertvalue { <8 x ptr>, <8 x i64> } %5629, <8 x i64> %5628, 1
  %5631 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5632 = extractvalue { <8 x ptr>, <8 x i64> } %5630, 1
  %5633 = extractelement <8 x ptr> %5631, i32 0
  %5634 = extractelement <8 x i64> %5632, i32 %5326
  %5635 = zext i32 %5326 to i64
  %5636 = mul i64 %5635, 4
  %5637 = sub i64 %5634, %5636
  %5638 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  %5639 = select i1 %5638, i64 %5637, i64 0
  %private.contiguous.address970 = getelementptr i8, ptr %5633, i64 %5639
  %private.contiguous.preserve971 = load <8 x float>, ptr %private.contiguous.address970, align 4
  %5640 = select <8 x i1> %convergence.cascade.result908, <8 x float> %native.exp955, <8 x float> %private.contiguous.preserve971
  store <8 x float> %5640, ptr %private.contiguous.address970, align 4
  %5641 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %5642 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %5643 = extractvalue { <8 x ptr>, <8 x i64> } %5641, 0
  %5644 = select <8 x i1> %convergence.cascade.result908, <8 x ptr> %5642, <8 x ptr> %5643
  %5645 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %5646 = extractvalue { <8 x ptr>, <8 x i64> } %5641, 1
  %5647 = select <8 x i1> %convergence.cascade.result908, <8 x i64> %5645, <8 x i64> %5646
  %5648 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5644, 0
  %5649 = insertvalue { <8 x ptr>, <8 x i64> } %5648, <8 x i64> %5647, 1
  store { <8 x ptr>, <8 x i64> } %5649, ptr %tile_snapshot.spill152, align 64
  %5650 = load <8 x i64>, ptr %.slot153, align 64
  %5651 = select <8 x i1> %convergence.cascade.result908, <8 x i64> zeroinitializer, <8 x i64> %5650
  store <8 x i64> %5651, ptr %.slot153, align 64
  store <8 x i1> %convergence.cascade.result908, ptr %current.mask, align 1
  %5652 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result908)
  br i1 %5652, label %schedule.60, label %scheduler.loop

varying.divergent973:                             ; preds = %schedule.60
  %5653 = load i32, ptr %current.token, align 4
  %5654 = icmp ne i32 %5653, 0
  %5655 = sub i32 %5653, 1
  %5656 = select i1 %5654, i32 %5655, i32 0
  %5657 = load i8, ptr %frame.active, align 1
  %5658 = trunc i32 %5656 to i8
  %5659 = shl i8 1, %5658
  %5660 = and i8 %5657, %5659
  %5661 = icmp ne i8 %5660, 0
  %5662 = load <8 x i32>, ptr %frame.static.id, align 32
  %5663 = extractelement <8 x i32> %5662, i32 %5656
  %5664 = icmp eq i32 %5663, 21
  %5665 = and i1 %5661, %5664
  %5666 = and i1 %5654, %5665
  %5667 = xor i1 %5666, true
  %5668 = and i1 true, %5667
  %5669 = xor i8 %5657, -1
  %5670 = icmp ne i8 %5669, 0
  %5671 = xor i1 %5670, true
  %5672 = and i1 %5668, %5671
  br i1 %5672, label %convergence.overflow.trap975, label %convergence.overflow.resume976

varying.coherent974:                              ; preds = %schedule.60
  br i1 %1113, label %varying.coherent.true979, label %varying.coherent.false980

convergence.overflow.trap975:                     ; preds = %varying.divergent973
  call void @llvm.trap()
  unreachable

convergence.overflow.resume976:                   ; preds = %varying.divergent973
  %5673 = call i8 @llvm.cttz.i8(i8 %5669, i1 false)
  %5674 = zext i8 %5673 to i32
  %5675 = select i1 %5670, i32 %5674, i32 0
  %5676 = trunc i32 %5675 to i8
  %5677 = shl i8 1, %5676
  %5678 = or i8 %5657, %5677
  %5679 = select i1 %5668, i8 %5678, i8 %5657
  store i8 %5679, ptr %frame.active, align 1
  %5680 = load <8 x i32>, ptr %frame.static.id, align 32
  %5681 = extractelement <8 x i32> %5680, i32 %5675
  %5682 = select i1 %5668, i32 21, i32 %5681
  %5683 = load <8 x i32>, ptr %frame.static.id, align 32
  %5684 = insertelement <8 x i32> %5683, i32 %5682, i32 %5675
  store <8 x i32> %5684, ptr %frame.static.id, align 32
  %5685 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5686 = extractelement <8 x i32> %5685, i32 %5675
  %5687 = select i1 %5668, i32 %5653, i32 %5686
  %5688 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5689 = insertelement <8 x i32> %5688, i32 %5687, i32 %5675
  store <8 x i32> %5689, ptr %frame.parent.token, align 32
  %5690 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5675
  %5691 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5675
  %5692 = load <8 x i1>, ptr %5690, align 1
  %5693 = load <8 x i1>, ptr %5691, align 1
  %5694 = select i1 %5668, <8 x i1> %1103, <8 x i1> %5692
  store <8 x i1> %5694, ptr %5690, align 1
  %5695 = select i1 %5668, <8 x i1> zeroinitializer, <8 x i1> %5693
  store <8 x i1> %5695, ptr %5691, align 1
  %5696 = add i32 %5675, 1
  %5697 = select i1 %5666, i32 %5653, i32 %5696
  %5698 = select i1 true, i32 %5697, i32 %5653
  store i32 %5698, ptr %current.token, align 4
  %5699 = load i32, ptr %current.token, align 4
  %5700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1110)
  %5701 = load i32, ptr %ready.count, align 4
  %5702 = icmp uge i32 %5701, 8
  %5703 = and i1 %5700, %5702
  br i1 %5703, label %ready.overflow.trap977, label %ready.overflow.resume978

ready.overflow.trap977:                           ; preds = %convergence.overflow.resume976
  call void @llvm.trap()
  unreachable

ready.overflow.resume978:                         ; preds = %convergence.overflow.resume976
  %5704 = select i1 %5700, i32 %5701, i32 0
  %5705 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5704
  %5706 = load <8 x i1>, ptr %5705, align 1
  %5707 = select i1 %5700, <8 x i1> %1110, <8 x i1> %5706
  store <8 x i1> %5707, ptr %5705, align 1
  %5708 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5704
  %5709 = load i32, ptr %5708, align 4
  %5710 = select i1 %5700, i32 61, i32 %5709
  store i32 %5710, ptr %5708, align 4
  %5711 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5704
  %5712 = load i32, ptr %5711, align 4
  %5713 = select i1 %5700, i32 %5699, i32 %5712
  store i32 %5713, ptr %5711, align 4
  %5714 = add i32 %5701, 1
  %5715 = select i1 %5700, i32 %5714, i32 %5701
  store i32 %5715, ptr %ready.count, align 4
  %5716 = load <8 x i1>, ptr %runnable.mask, align 1
  %5717 = or <8 x i1> %5716, %1110
  store <8 x i1> %5717, ptr %runnable.mask, align 1
  store <8 x i1> %1112, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true979:                         ; preds = %varying.coherent974
  store <8 x i1> %1103, ptr %current.mask, align 1
  %5718 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1103)
  br i1 %5718, label %schedule.61, label %scheduler.loop

varying.coherent.false980:                        ; preds = %varying.coherent974
  store <8 x i1> %1103, ptr %current.mask, align 1
  %5719 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1103)
  br i1 %5719, label %schedule.62, label %scheduler.loop

convergence.cascade990:                           ; preds = %convergence.cascade990, %schedule.62
  %convergence.cascade.flow994 = phi <8 x i1> [ %1198, %schedule.62 ], [ %5762, %convergence.cascade990 ]
  %convergence.cascade.depth995 = phi i32 [ 0, %schedule.62 ], [ %5763, %convergence.cascade990 ]
  %5720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow994)
  %5721 = load i32, ptr %current.token, align 4
  %5722 = icmp ne i32 %5721, 0
  %5723 = and i1 %5720, %5722
  %5724 = sub i32 %5721, 1
  %5725 = select i1 %5723, i32 %5724, i32 0
  %5726 = load i8, ptr %frame.active, align 1
  %5727 = trunc i32 %5725 to i8
  %5728 = shl i8 1, %5727
  %5729 = and i8 %5726, %5728
  %5730 = icmp ne i8 %5729, 0
  %5731 = load <8 x i32>, ptr %frame.static.id, align 32
  %5732 = extractelement <8 x i32> %5731, i32 %5725
  %convergence.target.pointer996 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %5732
  %convergence.dynamic.target997 = load i32, ptr %convergence.target.pointer996, align 4
  %5733 = icmp eq i32 %convergence.dynamic.target997, 62
  %5734 = and i1 %5730, %5733
  %5735 = and i1 %5723, %5734
  %5736 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5725
  %5737 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5725
  %5738 = load <8 x i1>, ptr %5736, align 1
  %5739 = load <8 x i1>, ptr %5737, align 1
  %5740 = or <8 x i1> %5739, %convergence.cascade.flow994
  %5741 = load <8 x i1>, ptr %live.mask, align 1
  %5742 = and <8 x i1> %5738, %5741
  %5743 = icmp eq <8 x i1> %5740, %5742
  %5744 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5743)
  %5745 = and i1 %5735, %5744
  %5746 = select i1 %5745, <8 x i1> zeroinitializer, <8 x i1> %5740
  %5747 = select i1 %5735, <8 x i1> %5746, <8 x i1> %5739
  store <8 x i1> %5747, ptr %5737, align 1
  %5748 = select i1 %5745, <8 x i1> zeroinitializer, <8 x i1> %5738
  store <8 x i1> %5748, ptr %5736, align 1
  %5749 = trunc i32 %5725 to i8
  %5750 = shl i8 1, %5749
  %5751 = xor i8 %5750, -1
  %5752 = and i8 %5726, %5751
  %5753 = select i1 %5745, i8 %5752, i8 %5726
  store i8 %5753, ptr %frame.active, align 1
  %.splatinsert998 = insertelement <8 x i1> poison, i1 %5735, i64 0
  %.splat999 = shufflevector <8 x i1> %.splatinsert998, <8 x i1> poison, <8 x i32> zeroinitializer
  %5754 = and <8 x i1> %convergence.cascade.flow994, %.splat999
  %5755 = load <8 x i1>, ptr %runnable.mask, align 1
  %5756 = xor <8 x i1> %5754, splat (i1 true)
  %5757 = and <8 x i1> %5755, %5756
  store <8 x i1> %5757, ptr %runnable.mask, align 1
  %.splatinsert1000 = insertelement <8 x i1> poison, i1 %5745, i64 0
  %.splat1001 = shufflevector <8 x i1> %.splatinsert1000, <8 x i1> poison, <8 x i32> zeroinitializer
  %5758 = select <8 x i1> %.splat1001, <8 x i1> %5740, <8 x i1> zeroinitializer
  %5759 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5760 = extractelement <8 x i32> %5759, i32 %5725
  %5761 = select i1 %5745, i32 %5760, i32 %5721
  store i32 %5761, ptr %current.token, align 4
  %.splatinsert1002 = insertelement <8 x i1> poison, i1 %5735, i64 0
  %.splat1003 = shufflevector <8 x i1> %.splatinsert1002, <8 x i1> poison, <8 x i32> zeroinitializer
  %5762 = select <8 x i1> %.splat1003, <8 x i1> %5758, <8 x i1> %convergence.cascade.flow994
  %5763 = add i32 %convergence.cascade.depth995, 1
  %5764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5762)
  %5765 = icmp ult i32 %5763, 8
  %5766 = and i1 %5764, %5765
  %5767 = and i1 %5735, %5766
  %convergence.parent.token1004 = load i32, ptr %current.token, align 4
  %convergence.parent.present1005 = icmp ne i32 %convergence.parent.token1004, 0
  %5768 = and i1 %5767, %convergence.parent.present1005
  br i1 %5768, label %convergence.cascade990, label %convergence.cascade.exit991

convergence.cascade.exit991:                      ; preds = %convergence.cascade990, %schedule.62
  %convergence.cascade.result1006 = phi <8 x i1> [ %1198, %schedule.62 ], [ %5762, %convergence.cascade990 ]
  %5769 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1006)
  br i1 %5769, label %convergence.target.62.ready, label %scheduler.loop

convergence.target.62.ready:                      ; preds = %convergence.cascade.exit991
  %5770 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1006)
  %5771 = bitcast <8 x i1> %convergence.cascade.result1006 to i8
  %5772 = call i8 @llvm.cttz.i8(i8 %5771, i1 false)
  %5773 = zext i8 %5772 to i32
  %5774 = select i1 %5770, i32 %5773, i32 0
  %.state1007 = load <8 x float>, ptr %.slot77, align 32
  %.spill.load1008 = load <8 x float>, ptr %.spill143, align 32
  %5775 = fmul <8 x float> %.state1007, %.spill.load1008
  %5776 = load <8 x float>, ptr %.spill154, align 32
  %5777 = select <8 x i1> %convergence.cascade.result1006, <8 x float> %5775, <8 x float> %5776
  store <8 x float> %5777, ptr %.spill154, align 32
  %.state1009 = load <8 x float>, ptr %.slot78, align 32
  %.spill.load1010 = load <8 x float>, ptr %.spill144, align 32
  %5778 = fmul <8 x float> %.state1009, %.spill.load1010
  %5779 = load <8 x float>, ptr %.spill155, align 32
  %5780 = select <8 x i1> %convergence.cascade.result1006, <8 x float> %5778, <8 x float> %5779
  store <8 x float> %5780, ptr %.spill155, align 32
  %.state1011 = load <8 x float>, ptr %.slot79, align 32
  %.spill.load1012 = load <8 x float>, ptr %.spill145, align 32
  %5781 = fmul <8 x float> %.state1011, %.spill.load1012
  %5782 = load <8 x float>, ptr %.spill156, align 32
  %5783 = select <8 x i1> %convergence.cascade.result1006, <8 x float> %5781, <8 x float> %5782
  store <8 x float> %5783, ptr %.spill156, align 32
  %.state1013 = load <8 x float>, ptr %.slot80, align 32
  %.spill.load1014 = load <8 x float>, ptr %.spill146, align 32
  %5784 = fmul <8 x float> %.state1013, %.spill.load1014
  %5785 = load <8 x float>, ptr %.spill157, align 32
  %5786 = select <8 x i1> %convergence.cascade.result1006, <8 x float> %5784, <8 x float> %5785
  store <8 x float> %5786, ptr %.spill157, align 32
  %.state1015 = load <8 x float>, ptr %.slot81, align 32
  %.spill.load1016 = load <8 x float>, ptr %.spill147, align 32
  %5787 = fmul <8 x float> %.state1015, %.spill.load1016
  %5788 = load <8 x float>, ptr %.spill158, align 32
  %5789 = select <8 x i1> %convergence.cascade.result1006, <8 x float> %5787, <8 x float> %5788
  store <8 x float> %5789, ptr %.spill158, align 32
  %.state1017 = load <8 x float>, ptr %.slot82, align 32
  %.spill.load1018 = load <8 x float>, ptr %.spill148, align 32
  %5790 = fmul <8 x float> %.state1017, %.spill.load1018
  %5791 = load <8 x float>, ptr %.spill159, align 32
  %5792 = select <8 x i1> %convergence.cascade.result1006, <8 x float> %5790, <8 x float> %5791
  store <8 x float> %5792, ptr %.spill159, align 32
  %.state1019 = load <8 x float>, ptr %.slot83, align 32
  %.spill.load1020 = load <8 x float>, ptr %.spill149, align 32
  %5793 = fmul <8 x float> %.state1019, %.spill.load1020
  %5794 = load <8 x float>, ptr %.spill160, align 32
  %5795 = select <8 x i1> %convergence.cascade.result1006, <8 x float> %5793, <8 x float> %5794
  store <8 x float> %5795, ptr %.spill160, align 32
  %.state1021 = load <8 x float>, ptr %.slot84, align 32
  %.spill.load1022 = load <8 x float>, ptr %.spill150, align 32
  %5796 = fmul <8 x float> %.state1021, %.spill.load1022
  %5797 = load <8 x float>, ptr %.spill161, align 32
  %5798 = select <8 x i1> %convergence.cascade.result1006, <8 x float> %5796, <8 x float> %5797
  store <8 x float> %5798, ptr %.spill161, align 32
  %5799 = load <8 x i64>, ptr %.slot162, align 64
  %5800 = select <8 x i1> %convergence.cascade.result1006, <8 x i64> zeroinitializer, <8 x i64> %5799
  store <8 x i64> %5800, ptr %.slot162, align 64
  %5801 = load <8 x float>, ptr %.slot163, align 32
  %5802 = select <8 x i1> %convergence.cascade.result1006, <8 x float> zeroinitializer, <8 x float> %5801
  store <8 x float> %5802, ptr %.slot163, align 32
  store <8 x i1> %convergence.cascade.result1006, ptr %current.mask, align 1
  %5803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1006)
  br i1 %5803, label %schedule.63, label %scheduler.loop

varying.divergent1024:                            ; preds = %schedule.63
  %5804 = load i32, ptr %current.token, align 4
  %5805 = icmp ne i32 %5804, 0
  %5806 = sub i32 %5804, 1
  %5807 = select i1 %5805, i32 %5806, i32 0
  %5808 = load i8, ptr %frame.active, align 1
  %5809 = trunc i32 %5807 to i8
  %5810 = shl i8 1, %5809
  %5811 = and i8 %5808, %5810
  %5812 = icmp ne i8 %5811, 0
  %5813 = load <8 x i32>, ptr %frame.static.id, align 32
  %5814 = extractelement <8 x i32> %5813, i32 %5807
  %5815 = icmp eq i32 %5814, 22
  %5816 = and i1 %5812, %5815
  %5817 = and i1 %5805, %5816
  %5818 = xor i1 %5817, true
  %5819 = and i1 true, %5818
  %5820 = xor i8 %5808, -1
  %5821 = icmp ne i8 %5820, 0
  %5822 = xor i1 %5821, true
  %5823 = and i1 %5819, %5822
  br i1 %5823, label %convergence.overflow.trap1026, label %convergence.overflow.resume1027

varying.coherent1025:                             ; preds = %schedule.63
  br i1 %1209, label %varying.coherent.true1030, label %varying.coherent.false1031

convergence.overflow.trap1026:                    ; preds = %varying.divergent1024
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1027:                  ; preds = %varying.divergent1024
  %5824 = call i8 @llvm.cttz.i8(i8 %5820, i1 false)
  %5825 = zext i8 %5824 to i32
  %5826 = select i1 %5821, i32 %5825, i32 0
  %5827 = trunc i32 %5826 to i8
  %5828 = shl i8 1, %5827
  %5829 = or i8 %5808, %5828
  %5830 = select i1 %5819, i8 %5829, i8 %5808
  store i8 %5830, ptr %frame.active, align 1
  %5831 = load <8 x i32>, ptr %frame.static.id, align 32
  %5832 = extractelement <8 x i32> %5831, i32 %5826
  %5833 = select i1 %5819, i32 22, i32 %5832
  %5834 = load <8 x i32>, ptr %frame.static.id, align 32
  %5835 = insertelement <8 x i32> %5834, i32 %5833, i32 %5826
  store <8 x i32> %5835, ptr %frame.static.id, align 32
  %5836 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5837 = extractelement <8 x i32> %5836, i32 %5826
  %5838 = select i1 %5819, i32 %5804, i32 %5837
  %5839 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5840 = insertelement <8 x i32> %5839, i32 %5838, i32 %5826
  store <8 x i32> %5840, ptr %frame.parent.token, align 32
  %5841 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5826
  %5842 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5826
  %5843 = load <8 x i1>, ptr %5841, align 1
  %5844 = load <8 x i1>, ptr %5842, align 1
  %5845 = select i1 %5819, <8 x i1> %1199, <8 x i1> %5843
  store <8 x i1> %5845, ptr %5841, align 1
  %5846 = select i1 %5819, <8 x i1> zeroinitializer, <8 x i1> %5844
  store <8 x i1> %5846, ptr %5842, align 1
  %5847 = add i32 %5826, 1
  %5848 = select i1 %5817, i32 %5804, i32 %5847
  %5849 = select i1 true, i32 %5848, i32 %5804
  store i32 %5849, ptr %current.token, align 4
  %5850 = load i32, ptr %current.token, align 4
  %5851 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1206)
  %5852 = load i32, ptr %ready.count, align 4
  %5853 = icmp uge i32 %5852, 8
  %5854 = and i1 %5851, %5853
  br i1 %5854, label %ready.overflow.trap1028, label %ready.overflow.resume1029

ready.overflow.trap1028:                          ; preds = %convergence.overflow.resume1027
  call void @llvm.trap()
  unreachable

ready.overflow.resume1029:                        ; preds = %convergence.overflow.resume1027
  %5855 = select i1 %5851, i32 %5852, i32 0
  %5856 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5855
  %5857 = load <8 x i1>, ptr %5856, align 1
  %5858 = select i1 %5851, <8 x i1> %1206, <8 x i1> %5857
  store <8 x i1> %5858, ptr %5856, align 1
  %5859 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5855
  %5860 = load i32, ptr %5859, align 4
  %5861 = select i1 %5851, i32 64, i32 %5860
  store i32 %5861, ptr %5859, align 4
  %5862 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5855
  %5863 = load i32, ptr %5862, align 4
  %5864 = select i1 %5851, i32 %5850, i32 %5863
  store i32 %5864, ptr %5862, align 4
  %5865 = add i32 %5852, 1
  %5866 = select i1 %5851, i32 %5865, i32 %5852
  store i32 %5866, ptr %ready.count, align 4
  %5867 = load <8 x i1>, ptr %runnable.mask, align 1
  %5868 = or <8 x i1> %5867, %1206
  store <8 x i1> %5868, ptr %runnable.mask, align 1
  store <8 x i1> %1208, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1030:                        ; preds = %varying.coherent1025
  store <8 x i1> %1199, ptr %current.mask, align 1
  %5869 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1199)
  br i1 %5869, label %schedule.64, label %scheduler.loop

varying.coherent.false1031:                       ; preds = %varying.coherent1025
  store <8 x i1> %1199, ptr %current.mask, align 1
  %5870 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1199)
  br i1 %5870, label %schedule.65, label %scheduler.loop

convergence.cascade1036:                          ; preds = %convergence.cascade1036, %schedule.65
  %convergence.cascade.flow1040 = phi <8 x i1> [ %1239, %schedule.65 ], [ %5913, %convergence.cascade1036 ]
  %convergence.cascade.depth1041 = phi i32 [ 0, %schedule.65 ], [ %5914, %convergence.cascade1036 ]
  %5871 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1040)
  %5872 = load i32, ptr %current.token, align 4
  %5873 = icmp ne i32 %5872, 0
  %5874 = and i1 %5871, %5873
  %5875 = sub i32 %5872, 1
  %5876 = select i1 %5874, i32 %5875, i32 0
  %5877 = load i8, ptr %frame.active, align 1
  %5878 = trunc i32 %5876 to i8
  %5879 = shl i8 1, %5878
  %5880 = and i8 %5877, %5879
  %5881 = icmp ne i8 %5880, 0
  %5882 = load <8 x i32>, ptr %frame.static.id, align 32
  %5883 = extractelement <8 x i32> %5882, i32 %5876
  %convergence.target.pointer1042 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %5883
  %convergence.dynamic.target1043 = load i32, ptr %convergence.target.pointer1042, align 4
  %5884 = icmp eq i32 %convergence.dynamic.target1043, 65
  %5885 = and i1 %5881, %5884
  %5886 = and i1 %5874, %5885
  %5887 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5876
  %5888 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5876
  %5889 = load <8 x i1>, ptr %5887, align 1
  %5890 = load <8 x i1>, ptr %5888, align 1
  %5891 = or <8 x i1> %5890, %convergence.cascade.flow1040
  %5892 = load <8 x i1>, ptr %live.mask, align 1
  %5893 = and <8 x i1> %5889, %5892
  %5894 = icmp eq <8 x i1> %5891, %5893
  %5895 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5894)
  %5896 = and i1 %5886, %5895
  %5897 = select i1 %5896, <8 x i1> zeroinitializer, <8 x i1> %5891
  %5898 = select i1 %5886, <8 x i1> %5897, <8 x i1> %5890
  store <8 x i1> %5898, ptr %5888, align 1
  %5899 = select i1 %5896, <8 x i1> zeroinitializer, <8 x i1> %5889
  store <8 x i1> %5899, ptr %5887, align 1
  %5900 = trunc i32 %5876 to i8
  %5901 = shl i8 1, %5900
  %5902 = xor i8 %5901, -1
  %5903 = and i8 %5877, %5902
  %5904 = select i1 %5896, i8 %5903, i8 %5877
  store i8 %5904, ptr %frame.active, align 1
  %.splatinsert1044 = insertelement <8 x i1> poison, i1 %5886, i64 0
  %.splat1045 = shufflevector <8 x i1> %.splatinsert1044, <8 x i1> poison, <8 x i32> zeroinitializer
  %5905 = and <8 x i1> %convergence.cascade.flow1040, %.splat1045
  %5906 = load <8 x i1>, ptr %runnable.mask, align 1
  %5907 = xor <8 x i1> %5905, splat (i1 true)
  %5908 = and <8 x i1> %5906, %5907
  store <8 x i1> %5908, ptr %runnable.mask, align 1
  %.splatinsert1046 = insertelement <8 x i1> poison, i1 %5896, i64 0
  %.splat1047 = shufflevector <8 x i1> %.splatinsert1046, <8 x i1> poison, <8 x i32> zeroinitializer
  %5909 = select <8 x i1> %.splat1047, <8 x i1> %5891, <8 x i1> zeroinitializer
  %5910 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5911 = extractelement <8 x i32> %5910, i32 %5876
  %5912 = select i1 %5896, i32 %5911, i32 %5872
  store i32 %5912, ptr %current.token, align 4
  %.splatinsert1048 = insertelement <8 x i1> poison, i1 %5886, i64 0
  %.splat1049 = shufflevector <8 x i1> %.splatinsert1048, <8 x i1> poison, <8 x i32> zeroinitializer
  %5913 = select <8 x i1> %.splat1049, <8 x i1> %5909, <8 x i1> %convergence.cascade.flow1040
  %5914 = add i32 %convergence.cascade.depth1041, 1
  %5915 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5913)
  %5916 = icmp ult i32 %5914, 8
  %5917 = and i1 %5915, %5916
  %5918 = and i1 %5886, %5917
  %convergence.parent.token1050 = load i32, ptr %current.token, align 4
  %convergence.parent.present1051 = icmp ne i32 %convergence.parent.token1050, 0
  %5919 = and i1 %5918, %convergence.parent.present1051
  br i1 %5919, label %convergence.cascade1036, label %convergence.cascade.exit1037

convergence.cascade.exit1037:                     ; preds = %convergence.cascade1036, %schedule.65
  %convergence.cascade.result1052 = phi <8 x i1> [ %1239, %schedule.65 ], [ %5913, %convergence.cascade1036 ]
  %5920 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1052)
  br i1 %5920, label %convergence.target.65.ready, label %scheduler.loop

convergence.target.65.ready:                      ; preds = %convergence.cascade.exit1037
  %5921 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1052)
  %5922 = bitcast <8 x i1> %convergence.cascade.result1052 to i8
  %5923 = call i8 @llvm.cttz.i8(i8 %5922, i1 false)
  %5924 = zext i8 %5923 to i32
  %5925 = select i1 %5921, i32 %5924, i32 0
  %5926 = load <8 x i64>, ptr %.slot164, align 64
  %5927 = select <8 x i1> %convergence.cascade.result1052, <8 x i64> zeroinitializer, <8 x i64> %5926
  store <8 x i64> %5927, ptr %.slot164, align 64
  %5928 = load <8 x float>, ptr %.slot165, align 32
  %5929 = select <8 x i1> %convergence.cascade.result1052, <8 x float> zeroinitializer, <8 x float> %5928
  store <8 x float> %5929, ptr %.slot165, align 32
  store <8 x i1> %convergence.cascade.result1052, ptr %current.mask, align 1
  %5930 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1052)
  br i1 %5930, label %schedule.66, label %scheduler.loop

varying.divergent1054:                            ; preds = %schedule.66
  %5931 = load i32, ptr %current.token, align 4
  %5932 = icmp ne i32 %5931, 0
  %5933 = sub i32 %5931, 1
  %5934 = select i1 %5932, i32 %5933, i32 0
  %5935 = load i8, ptr %frame.active, align 1
  %5936 = trunc i32 %5934 to i8
  %5937 = shl i8 1, %5936
  %5938 = and i8 %5935, %5937
  %5939 = icmp ne i8 %5938, 0
  %5940 = load <8 x i32>, ptr %frame.static.id, align 32
  %5941 = extractelement <8 x i32> %5940, i32 %5934
  %5942 = icmp eq i32 %5941, 23
  %5943 = and i1 %5939, %5942
  %5944 = and i1 %5932, %5943
  %5945 = xor i1 %5944, true
  %5946 = and i1 true, %5945
  %5947 = xor i8 %5935, -1
  %5948 = icmp ne i8 %5947, 0
  %5949 = xor i1 %5948, true
  %5950 = and i1 %5946, %5949
  br i1 %5950, label %convergence.overflow.trap1056, label %convergence.overflow.resume1057

varying.coherent1055:                             ; preds = %schedule.66
  br i1 %1250, label %varying.coherent.true1060, label %varying.coherent.false1061

convergence.overflow.trap1056:                    ; preds = %varying.divergent1054
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1057:                  ; preds = %varying.divergent1054
  %5951 = call i8 @llvm.cttz.i8(i8 %5947, i1 false)
  %5952 = zext i8 %5951 to i32
  %5953 = select i1 %5948, i32 %5952, i32 0
  %5954 = trunc i32 %5953 to i8
  %5955 = shl i8 1, %5954
  %5956 = or i8 %5935, %5955
  %5957 = select i1 %5946, i8 %5956, i8 %5935
  store i8 %5957, ptr %frame.active, align 1
  %5958 = load <8 x i32>, ptr %frame.static.id, align 32
  %5959 = extractelement <8 x i32> %5958, i32 %5953
  %5960 = select i1 %5946, i32 23, i32 %5959
  %5961 = load <8 x i32>, ptr %frame.static.id, align 32
  %5962 = insertelement <8 x i32> %5961, i32 %5960, i32 %5953
  store <8 x i32> %5962, ptr %frame.static.id, align 32
  %5963 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5964 = extractelement <8 x i32> %5963, i32 %5953
  %5965 = select i1 %5946, i32 %5931, i32 %5964
  %5966 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5967 = insertelement <8 x i32> %5966, i32 %5965, i32 %5953
  store <8 x i32> %5967, ptr %frame.parent.token, align 32
  %5968 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5953
  %5969 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5953
  %5970 = load <8 x i1>, ptr %5968, align 1
  %5971 = load <8 x i1>, ptr %5969, align 1
  %5972 = select i1 %5946, <8 x i1> %1240, <8 x i1> %5970
  store <8 x i1> %5972, ptr %5968, align 1
  %5973 = select i1 %5946, <8 x i1> zeroinitializer, <8 x i1> %5971
  store <8 x i1> %5973, ptr %5969, align 1
  %5974 = add i32 %5953, 1
  %5975 = select i1 %5944, i32 %5931, i32 %5974
  %5976 = select i1 true, i32 %5975, i32 %5931
  store i32 %5976, ptr %current.token, align 4
  %5977 = load i32, ptr %current.token, align 4
  %5978 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1247)
  %5979 = load i32, ptr %ready.count, align 4
  %5980 = icmp uge i32 %5979, 8
  %5981 = and i1 %5978, %5980
  br i1 %5981, label %ready.overflow.trap1058, label %ready.overflow.resume1059

ready.overflow.trap1058:                          ; preds = %convergence.overflow.resume1057
  call void @llvm.trap()
  unreachable

ready.overflow.resume1059:                        ; preds = %convergence.overflow.resume1057
  %5982 = select i1 %5978, i32 %5979, i32 0
  %5983 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5982
  %5984 = load <8 x i1>, ptr %5983, align 1
  %5985 = select i1 %5978, <8 x i1> %1247, <8 x i1> %5984
  store <8 x i1> %5985, ptr %5983, align 1
  %5986 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5982
  %5987 = load i32, ptr %5986, align 4
  %5988 = select i1 %5978, i32 67, i32 %5987
  store i32 %5988, ptr %5986, align 4
  %5989 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5982
  %5990 = load i32, ptr %5989, align 4
  %5991 = select i1 %5978, i32 %5977, i32 %5990
  store i32 %5991, ptr %5989, align 4
  %5992 = add i32 %5979, 1
  %5993 = select i1 %5978, i32 %5992, i32 %5979
  store i32 %5993, ptr %ready.count, align 4
  %5994 = load <8 x i1>, ptr %runnable.mask, align 1
  %5995 = or <8 x i1> %5994, %1247
  store <8 x i1> %5995, ptr %runnable.mask, align 1
  store <8 x i1> %1249, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1060:                        ; preds = %varying.coherent1055
  store <8 x i1> %1240, ptr %current.mask, align 1
  %5996 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1240)
  br i1 %5996, label %schedule.67, label %scheduler.loop

varying.coherent.false1061:                       ; preds = %varying.coherent1055
  store <8 x i1> %1240, ptr %current.mask, align 1
  %5997 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1240)
  br i1 %5997, label %schedule.68, label %scheduler.loop

convergence.cascade1066:                          ; preds = %convergence.cascade1066, %schedule.68
  %convergence.cascade.flow1070 = phi <8 x i1> [ %1280, %schedule.68 ], [ %6040, %convergence.cascade1066 ]
  %convergence.cascade.depth1071 = phi i32 [ 0, %schedule.68 ], [ %6041, %convergence.cascade1066 ]
  %5998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1070)
  %5999 = load i32, ptr %current.token, align 4
  %6000 = icmp ne i32 %5999, 0
  %6001 = and i1 %5998, %6000
  %6002 = sub i32 %5999, 1
  %6003 = select i1 %6001, i32 %6002, i32 0
  %6004 = load i8, ptr %frame.active, align 1
  %6005 = trunc i32 %6003 to i8
  %6006 = shl i8 1, %6005
  %6007 = and i8 %6004, %6006
  %6008 = icmp ne i8 %6007, 0
  %6009 = load <8 x i32>, ptr %frame.static.id, align 32
  %6010 = extractelement <8 x i32> %6009, i32 %6003
  %convergence.target.pointer1072 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6010
  %convergence.dynamic.target1073 = load i32, ptr %convergence.target.pointer1072, align 4
  %6011 = icmp eq i32 %convergence.dynamic.target1073, 68
  %6012 = and i1 %6008, %6011
  %6013 = and i1 %6001, %6012
  %6014 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6003
  %6015 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6003
  %6016 = load <8 x i1>, ptr %6014, align 1
  %6017 = load <8 x i1>, ptr %6015, align 1
  %6018 = or <8 x i1> %6017, %convergence.cascade.flow1070
  %6019 = load <8 x i1>, ptr %live.mask, align 1
  %6020 = and <8 x i1> %6016, %6019
  %6021 = icmp eq <8 x i1> %6018, %6020
  %6022 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6021)
  %6023 = and i1 %6013, %6022
  %6024 = select i1 %6023, <8 x i1> zeroinitializer, <8 x i1> %6018
  %6025 = select i1 %6013, <8 x i1> %6024, <8 x i1> %6017
  store <8 x i1> %6025, ptr %6015, align 1
  %6026 = select i1 %6023, <8 x i1> zeroinitializer, <8 x i1> %6016
  store <8 x i1> %6026, ptr %6014, align 1
  %6027 = trunc i32 %6003 to i8
  %6028 = shl i8 1, %6027
  %6029 = xor i8 %6028, -1
  %6030 = and i8 %6004, %6029
  %6031 = select i1 %6023, i8 %6030, i8 %6004
  store i8 %6031, ptr %frame.active, align 1
  %.splatinsert1074 = insertelement <8 x i1> poison, i1 %6013, i64 0
  %.splat1075 = shufflevector <8 x i1> %.splatinsert1074, <8 x i1> poison, <8 x i32> zeroinitializer
  %6032 = and <8 x i1> %convergence.cascade.flow1070, %.splat1075
  %6033 = load <8 x i1>, ptr %runnable.mask, align 1
  %6034 = xor <8 x i1> %6032, splat (i1 true)
  %6035 = and <8 x i1> %6033, %6034
  store <8 x i1> %6035, ptr %runnable.mask, align 1
  %.splatinsert1076 = insertelement <8 x i1> poison, i1 %6023, i64 0
  %.splat1077 = shufflevector <8 x i1> %.splatinsert1076, <8 x i1> poison, <8 x i32> zeroinitializer
  %6036 = select <8 x i1> %.splat1077, <8 x i1> %6018, <8 x i1> zeroinitializer
  %6037 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6038 = extractelement <8 x i32> %6037, i32 %6003
  %6039 = select i1 %6023, i32 %6038, i32 %5999
  store i32 %6039, ptr %current.token, align 4
  %.splatinsert1078 = insertelement <8 x i1> poison, i1 %6013, i64 0
  %.splat1079 = shufflevector <8 x i1> %.splatinsert1078, <8 x i1> poison, <8 x i32> zeroinitializer
  %6040 = select <8 x i1> %.splat1079, <8 x i1> %6036, <8 x i1> %convergence.cascade.flow1070
  %6041 = add i32 %convergence.cascade.depth1071, 1
  %6042 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6040)
  %6043 = icmp ult i32 %6041, 8
  %6044 = and i1 %6042, %6043
  %6045 = and i1 %6013, %6044
  %convergence.parent.token1080 = load i32, ptr %current.token, align 4
  %convergence.parent.present1081 = icmp ne i32 %convergence.parent.token1080, 0
  %6046 = and i1 %6045, %convergence.parent.present1081
  br i1 %6046, label %convergence.cascade1066, label %convergence.cascade.exit1067

convergence.cascade.exit1067:                     ; preds = %convergence.cascade1066, %schedule.68
  %convergence.cascade.result1082 = phi <8 x i1> [ %1280, %schedule.68 ], [ %6040, %convergence.cascade1066 ]
  %6047 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1082)
  br i1 %6047, label %convergence.target.68.ready, label %scheduler.loop

convergence.target.68.ready:                      ; preds = %convergence.cascade.exit1067
  %6048 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1082)
  %6049 = bitcast <8 x i1> %convergence.cascade.result1082 to i8
  %6050 = call i8 @llvm.cttz.i8(i8 %6049, i1 false)
  %6051 = zext i8 %6050 to i32
  %6052 = select i1 %6048, i32 %6051, i32 0
  %6053 = load <8 x i64>, ptr %.slot166, align 64
  %6054 = select <8 x i1> %convergence.cascade.result1082, <8 x i64> zeroinitializer, <8 x i64> %6053
  store <8 x i64> %6054, ptr %.slot166, align 64
  %6055 = load <8 x float>, ptr %.slot167, align 32
  %6056 = select <8 x i1> %convergence.cascade.result1082, <8 x float> zeroinitializer, <8 x float> %6055
  store <8 x float> %6056, ptr %.slot167, align 32
  store <8 x i1> %convergence.cascade.result1082, ptr %current.mask, align 1
  %6057 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1082)
  br i1 %6057, label %schedule.69, label %scheduler.loop

varying.divergent1084:                            ; preds = %schedule.69
  %6058 = load i32, ptr %current.token, align 4
  %6059 = icmp ne i32 %6058, 0
  %6060 = sub i32 %6058, 1
  %6061 = select i1 %6059, i32 %6060, i32 0
  %6062 = load i8, ptr %frame.active, align 1
  %6063 = trunc i32 %6061 to i8
  %6064 = shl i8 1, %6063
  %6065 = and i8 %6062, %6064
  %6066 = icmp ne i8 %6065, 0
  %6067 = load <8 x i32>, ptr %frame.static.id, align 32
  %6068 = extractelement <8 x i32> %6067, i32 %6061
  %6069 = icmp eq i32 %6068, 24
  %6070 = and i1 %6066, %6069
  %6071 = and i1 %6059, %6070
  %6072 = xor i1 %6071, true
  %6073 = and i1 true, %6072
  %6074 = xor i8 %6062, -1
  %6075 = icmp ne i8 %6074, 0
  %6076 = xor i1 %6075, true
  %6077 = and i1 %6073, %6076
  br i1 %6077, label %convergence.overflow.trap1086, label %convergence.overflow.resume1087

varying.coherent1085:                             ; preds = %schedule.69
  br i1 %1291, label %varying.coherent.true1090, label %varying.coherent.false1091

convergence.overflow.trap1086:                    ; preds = %varying.divergent1084
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1087:                  ; preds = %varying.divergent1084
  %6078 = call i8 @llvm.cttz.i8(i8 %6074, i1 false)
  %6079 = zext i8 %6078 to i32
  %6080 = select i1 %6075, i32 %6079, i32 0
  %6081 = trunc i32 %6080 to i8
  %6082 = shl i8 1, %6081
  %6083 = or i8 %6062, %6082
  %6084 = select i1 %6073, i8 %6083, i8 %6062
  store i8 %6084, ptr %frame.active, align 1
  %6085 = load <8 x i32>, ptr %frame.static.id, align 32
  %6086 = extractelement <8 x i32> %6085, i32 %6080
  %6087 = select i1 %6073, i32 24, i32 %6086
  %6088 = load <8 x i32>, ptr %frame.static.id, align 32
  %6089 = insertelement <8 x i32> %6088, i32 %6087, i32 %6080
  store <8 x i32> %6089, ptr %frame.static.id, align 32
  %6090 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6091 = extractelement <8 x i32> %6090, i32 %6080
  %6092 = select i1 %6073, i32 %6058, i32 %6091
  %6093 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6094 = insertelement <8 x i32> %6093, i32 %6092, i32 %6080
  store <8 x i32> %6094, ptr %frame.parent.token, align 32
  %6095 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6080
  %6096 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6080
  %6097 = load <8 x i1>, ptr %6095, align 1
  %6098 = load <8 x i1>, ptr %6096, align 1
  %6099 = select i1 %6073, <8 x i1> %1281, <8 x i1> %6097
  store <8 x i1> %6099, ptr %6095, align 1
  %6100 = select i1 %6073, <8 x i1> zeroinitializer, <8 x i1> %6098
  store <8 x i1> %6100, ptr %6096, align 1
  %6101 = add i32 %6080, 1
  %6102 = select i1 %6071, i32 %6058, i32 %6101
  %6103 = select i1 true, i32 %6102, i32 %6058
  store i32 %6103, ptr %current.token, align 4
  %6104 = load i32, ptr %current.token, align 4
  %6105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1288)
  %6106 = load i32, ptr %ready.count, align 4
  %6107 = icmp uge i32 %6106, 8
  %6108 = and i1 %6105, %6107
  br i1 %6108, label %ready.overflow.trap1088, label %ready.overflow.resume1089

ready.overflow.trap1088:                          ; preds = %convergence.overflow.resume1087
  call void @llvm.trap()
  unreachable

ready.overflow.resume1089:                        ; preds = %convergence.overflow.resume1087
  %6109 = select i1 %6105, i32 %6106, i32 0
  %6110 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6109
  %6111 = load <8 x i1>, ptr %6110, align 1
  %6112 = select i1 %6105, <8 x i1> %1288, <8 x i1> %6111
  store <8 x i1> %6112, ptr %6110, align 1
  %6113 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6109
  %6114 = load i32, ptr %6113, align 4
  %6115 = select i1 %6105, i32 70, i32 %6114
  store i32 %6115, ptr %6113, align 4
  %6116 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6109
  %6117 = load i32, ptr %6116, align 4
  %6118 = select i1 %6105, i32 %6104, i32 %6117
  store i32 %6118, ptr %6116, align 4
  %6119 = add i32 %6106, 1
  %6120 = select i1 %6105, i32 %6119, i32 %6106
  store i32 %6120, ptr %ready.count, align 4
  %6121 = load <8 x i1>, ptr %runnable.mask, align 1
  %6122 = or <8 x i1> %6121, %1288
  store <8 x i1> %6122, ptr %runnable.mask, align 1
  store <8 x i1> %1290, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1090:                        ; preds = %varying.coherent1085
  store <8 x i1> %1281, ptr %current.mask, align 1
  %6123 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1281)
  br i1 %6123, label %schedule.70, label %scheduler.loop

varying.coherent.false1091:                       ; preds = %varying.coherent1085
  store <8 x i1> %1281, ptr %current.mask, align 1
  %6124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1281)
  br i1 %6124, label %schedule.71, label %scheduler.loop

convergence.cascade1096:                          ; preds = %convergence.cascade1096, %schedule.71
  %convergence.cascade.flow1100 = phi <8 x i1> [ %1321, %schedule.71 ], [ %6167, %convergence.cascade1096 ]
  %convergence.cascade.depth1101 = phi i32 [ 0, %schedule.71 ], [ %6168, %convergence.cascade1096 ]
  %6125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1100)
  %6126 = load i32, ptr %current.token, align 4
  %6127 = icmp ne i32 %6126, 0
  %6128 = and i1 %6125, %6127
  %6129 = sub i32 %6126, 1
  %6130 = select i1 %6128, i32 %6129, i32 0
  %6131 = load i8, ptr %frame.active, align 1
  %6132 = trunc i32 %6130 to i8
  %6133 = shl i8 1, %6132
  %6134 = and i8 %6131, %6133
  %6135 = icmp ne i8 %6134, 0
  %6136 = load <8 x i32>, ptr %frame.static.id, align 32
  %6137 = extractelement <8 x i32> %6136, i32 %6130
  %convergence.target.pointer1102 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6137
  %convergence.dynamic.target1103 = load i32, ptr %convergence.target.pointer1102, align 4
  %6138 = icmp eq i32 %convergence.dynamic.target1103, 71
  %6139 = and i1 %6135, %6138
  %6140 = and i1 %6128, %6139
  %6141 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6130
  %6142 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6130
  %6143 = load <8 x i1>, ptr %6141, align 1
  %6144 = load <8 x i1>, ptr %6142, align 1
  %6145 = or <8 x i1> %6144, %convergence.cascade.flow1100
  %6146 = load <8 x i1>, ptr %live.mask, align 1
  %6147 = and <8 x i1> %6143, %6146
  %6148 = icmp eq <8 x i1> %6145, %6147
  %6149 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6148)
  %6150 = and i1 %6140, %6149
  %6151 = select i1 %6150, <8 x i1> zeroinitializer, <8 x i1> %6145
  %6152 = select i1 %6140, <8 x i1> %6151, <8 x i1> %6144
  store <8 x i1> %6152, ptr %6142, align 1
  %6153 = select i1 %6150, <8 x i1> zeroinitializer, <8 x i1> %6143
  store <8 x i1> %6153, ptr %6141, align 1
  %6154 = trunc i32 %6130 to i8
  %6155 = shl i8 1, %6154
  %6156 = xor i8 %6155, -1
  %6157 = and i8 %6131, %6156
  %6158 = select i1 %6150, i8 %6157, i8 %6131
  store i8 %6158, ptr %frame.active, align 1
  %.splatinsert1104 = insertelement <8 x i1> poison, i1 %6140, i64 0
  %.splat1105 = shufflevector <8 x i1> %.splatinsert1104, <8 x i1> poison, <8 x i32> zeroinitializer
  %6159 = and <8 x i1> %convergence.cascade.flow1100, %.splat1105
  %6160 = load <8 x i1>, ptr %runnable.mask, align 1
  %6161 = xor <8 x i1> %6159, splat (i1 true)
  %6162 = and <8 x i1> %6160, %6161
  store <8 x i1> %6162, ptr %runnable.mask, align 1
  %.splatinsert1106 = insertelement <8 x i1> poison, i1 %6150, i64 0
  %.splat1107 = shufflevector <8 x i1> %.splatinsert1106, <8 x i1> poison, <8 x i32> zeroinitializer
  %6163 = select <8 x i1> %.splat1107, <8 x i1> %6145, <8 x i1> zeroinitializer
  %6164 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6165 = extractelement <8 x i32> %6164, i32 %6130
  %6166 = select i1 %6150, i32 %6165, i32 %6126
  store i32 %6166, ptr %current.token, align 4
  %.splatinsert1108 = insertelement <8 x i1> poison, i1 %6140, i64 0
  %.splat1109 = shufflevector <8 x i1> %.splatinsert1108, <8 x i1> poison, <8 x i32> zeroinitializer
  %6167 = select <8 x i1> %.splat1109, <8 x i1> %6163, <8 x i1> %convergence.cascade.flow1100
  %6168 = add i32 %convergence.cascade.depth1101, 1
  %6169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6167)
  %6170 = icmp ult i32 %6168, 8
  %6171 = and i1 %6169, %6170
  %6172 = and i1 %6140, %6171
  %convergence.parent.token1110 = load i32, ptr %current.token, align 4
  %convergence.parent.present1111 = icmp ne i32 %convergence.parent.token1110, 0
  %6173 = and i1 %6172, %convergence.parent.present1111
  br i1 %6173, label %convergence.cascade1096, label %convergence.cascade.exit1097

convergence.cascade.exit1097:                     ; preds = %convergence.cascade1096, %schedule.71
  %convergence.cascade.result1112 = phi <8 x i1> [ %1321, %schedule.71 ], [ %6167, %convergence.cascade1096 ]
  %6174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1112)
  br i1 %6174, label %convergence.target.71.ready, label %scheduler.loop

convergence.target.71.ready:                      ; preds = %convergence.cascade.exit1097
  %6175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1112)
  %6176 = bitcast <8 x i1> %convergence.cascade.result1112 to i8
  %6177 = call i8 @llvm.cttz.i8(i8 %6176, i1 false)
  %6178 = zext i8 %6177 to i32
  %6179 = select i1 %6175, i32 %6178, i32 0
  %6180 = load <8 x i64>, ptr %.slot168, align 64
  %6181 = select <8 x i1> %convergence.cascade.result1112, <8 x i64> zeroinitializer, <8 x i64> %6180
  store <8 x i64> %6181, ptr %.slot168, align 64
  %6182 = load <8 x float>, ptr %.slot169, align 32
  %6183 = select <8 x i1> %convergence.cascade.result1112, <8 x float> zeroinitializer, <8 x float> %6182
  store <8 x float> %6183, ptr %.slot169, align 32
  store <8 x i1> %convergence.cascade.result1112, ptr %current.mask, align 1
  %6184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1112)
  br i1 %6184, label %schedule.72, label %scheduler.loop

varying.divergent1114:                            ; preds = %schedule.72
  %6185 = load i32, ptr %current.token, align 4
  %6186 = icmp ne i32 %6185, 0
  %6187 = sub i32 %6185, 1
  %6188 = select i1 %6186, i32 %6187, i32 0
  %6189 = load i8, ptr %frame.active, align 1
  %6190 = trunc i32 %6188 to i8
  %6191 = shl i8 1, %6190
  %6192 = and i8 %6189, %6191
  %6193 = icmp ne i8 %6192, 0
  %6194 = load <8 x i32>, ptr %frame.static.id, align 32
  %6195 = extractelement <8 x i32> %6194, i32 %6188
  %6196 = icmp eq i32 %6195, 25
  %6197 = and i1 %6193, %6196
  %6198 = and i1 %6186, %6197
  %6199 = xor i1 %6198, true
  %6200 = and i1 true, %6199
  %6201 = xor i8 %6189, -1
  %6202 = icmp ne i8 %6201, 0
  %6203 = xor i1 %6202, true
  %6204 = and i1 %6200, %6203
  br i1 %6204, label %convergence.overflow.trap1116, label %convergence.overflow.resume1117

varying.coherent1115:                             ; preds = %schedule.72
  br i1 %1332, label %varying.coherent.true1120, label %varying.coherent.false1121

convergence.overflow.trap1116:                    ; preds = %varying.divergent1114
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1117:                  ; preds = %varying.divergent1114
  %6205 = call i8 @llvm.cttz.i8(i8 %6201, i1 false)
  %6206 = zext i8 %6205 to i32
  %6207 = select i1 %6202, i32 %6206, i32 0
  %6208 = trunc i32 %6207 to i8
  %6209 = shl i8 1, %6208
  %6210 = or i8 %6189, %6209
  %6211 = select i1 %6200, i8 %6210, i8 %6189
  store i8 %6211, ptr %frame.active, align 1
  %6212 = load <8 x i32>, ptr %frame.static.id, align 32
  %6213 = extractelement <8 x i32> %6212, i32 %6207
  %6214 = select i1 %6200, i32 25, i32 %6213
  %6215 = load <8 x i32>, ptr %frame.static.id, align 32
  %6216 = insertelement <8 x i32> %6215, i32 %6214, i32 %6207
  store <8 x i32> %6216, ptr %frame.static.id, align 32
  %6217 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6218 = extractelement <8 x i32> %6217, i32 %6207
  %6219 = select i1 %6200, i32 %6185, i32 %6218
  %6220 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6221 = insertelement <8 x i32> %6220, i32 %6219, i32 %6207
  store <8 x i32> %6221, ptr %frame.parent.token, align 32
  %6222 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6207
  %6223 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6207
  %6224 = load <8 x i1>, ptr %6222, align 1
  %6225 = load <8 x i1>, ptr %6223, align 1
  %6226 = select i1 %6200, <8 x i1> %1322, <8 x i1> %6224
  store <8 x i1> %6226, ptr %6222, align 1
  %6227 = select i1 %6200, <8 x i1> zeroinitializer, <8 x i1> %6225
  store <8 x i1> %6227, ptr %6223, align 1
  %6228 = add i32 %6207, 1
  %6229 = select i1 %6198, i32 %6185, i32 %6228
  %6230 = select i1 true, i32 %6229, i32 %6185
  store i32 %6230, ptr %current.token, align 4
  %6231 = load i32, ptr %current.token, align 4
  %6232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1329)
  %6233 = load i32, ptr %ready.count, align 4
  %6234 = icmp uge i32 %6233, 8
  %6235 = and i1 %6232, %6234
  br i1 %6235, label %ready.overflow.trap1118, label %ready.overflow.resume1119

ready.overflow.trap1118:                          ; preds = %convergence.overflow.resume1117
  call void @llvm.trap()
  unreachable

ready.overflow.resume1119:                        ; preds = %convergence.overflow.resume1117
  %6236 = select i1 %6232, i32 %6233, i32 0
  %6237 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6236
  %6238 = load <8 x i1>, ptr %6237, align 1
  %6239 = select i1 %6232, <8 x i1> %1329, <8 x i1> %6238
  store <8 x i1> %6239, ptr %6237, align 1
  %6240 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6236
  %6241 = load i32, ptr %6240, align 4
  %6242 = select i1 %6232, i32 73, i32 %6241
  store i32 %6242, ptr %6240, align 4
  %6243 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6236
  %6244 = load i32, ptr %6243, align 4
  %6245 = select i1 %6232, i32 %6231, i32 %6244
  store i32 %6245, ptr %6243, align 4
  %6246 = add i32 %6233, 1
  %6247 = select i1 %6232, i32 %6246, i32 %6233
  store i32 %6247, ptr %ready.count, align 4
  %6248 = load <8 x i1>, ptr %runnable.mask, align 1
  %6249 = or <8 x i1> %6248, %1329
  store <8 x i1> %6249, ptr %runnable.mask, align 1
  store <8 x i1> %1331, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1120:                        ; preds = %varying.coherent1115
  store <8 x i1> %1322, ptr %current.mask, align 1
  %6250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1322)
  br i1 %6250, label %schedule.73, label %scheduler.loop

varying.coherent.false1121:                       ; preds = %varying.coherent1115
  store <8 x i1> %1322, ptr %current.mask, align 1
  %6251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1322)
  br i1 %6251, label %schedule.74, label %scheduler.loop

convergence.cascade1126:                          ; preds = %convergence.cascade1126, %schedule.74
  %convergence.cascade.flow1130 = phi <8 x i1> [ %1362, %schedule.74 ], [ %6294, %convergence.cascade1126 ]
  %convergence.cascade.depth1131 = phi i32 [ 0, %schedule.74 ], [ %6295, %convergence.cascade1126 ]
  %6252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1130)
  %6253 = load i32, ptr %current.token, align 4
  %6254 = icmp ne i32 %6253, 0
  %6255 = and i1 %6252, %6254
  %6256 = sub i32 %6253, 1
  %6257 = select i1 %6255, i32 %6256, i32 0
  %6258 = load i8, ptr %frame.active, align 1
  %6259 = trunc i32 %6257 to i8
  %6260 = shl i8 1, %6259
  %6261 = and i8 %6258, %6260
  %6262 = icmp ne i8 %6261, 0
  %6263 = load <8 x i32>, ptr %frame.static.id, align 32
  %6264 = extractelement <8 x i32> %6263, i32 %6257
  %convergence.target.pointer1132 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6264
  %convergence.dynamic.target1133 = load i32, ptr %convergence.target.pointer1132, align 4
  %6265 = icmp eq i32 %convergence.dynamic.target1133, 74
  %6266 = and i1 %6262, %6265
  %6267 = and i1 %6255, %6266
  %6268 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6257
  %6269 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6257
  %6270 = load <8 x i1>, ptr %6268, align 1
  %6271 = load <8 x i1>, ptr %6269, align 1
  %6272 = or <8 x i1> %6271, %convergence.cascade.flow1130
  %6273 = load <8 x i1>, ptr %live.mask, align 1
  %6274 = and <8 x i1> %6270, %6273
  %6275 = icmp eq <8 x i1> %6272, %6274
  %6276 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6275)
  %6277 = and i1 %6267, %6276
  %6278 = select i1 %6277, <8 x i1> zeroinitializer, <8 x i1> %6272
  %6279 = select i1 %6267, <8 x i1> %6278, <8 x i1> %6271
  store <8 x i1> %6279, ptr %6269, align 1
  %6280 = select i1 %6277, <8 x i1> zeroinitializer, <8 x i1> %6270
  store <8 x i1> %6280, ptr %6268, align 1
  %6281 = trunc i32 %6257 to i8
  %6282 = shl i8 1, %6281
  %6283 = xor i8 %6282, -1
  %6284 = and i8 %6258, %6283
  %6285 = select i1 %6277, i8 %6284, i8 %6258
  store i8 %6285, ptr %frame.active, align 1
  %.splatinsert1134 = insertelement <8 x i1> poison, i1 %6267, i64 0
  %.splat1135 = shufflevector <8 x i1> %.splatinsert1134, <8 x i1> poison, <8 x i32> zeroinitializer
  %6286 = and <8 x i1> %convergence.cascade.flow1130, %.splat1135
  %6287 = load <8 x i1>, ptr %runnable.mask, align 1
  %6288 = xor <8 x i1> %6286, splat (i1 true)
  %6289 = and <8 x i1> %6287, %6288
  store <8 x i1> %6289, ptr %runnable.mask, align 1
  %.splatinsert1136 = insertelement <8 x i1> poison, i1 %6277, i64 0
  %.splat1137 = shufflevector <8 x i1> %.splatinsert1136, <8 x i1> poison, <8 x i32> zeroinitializer
  %6290 = select <8 x i1> %.splat1137, <8 x i1> %6272, <8 x i1> zeroinitializer
  %6291 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6292 = extractelement <8 x i32> %6291, i32 %6257
  %6293 = select i1 %6277, i32 %6292, i32 %6253
  store i32 %6293, ptr %current.token, align 4
  %.splatinsert1138 = insertelement <8 x i1> poison, i1 %6267, i64 0
  %.splat1139 = shufflevector <8 x i1> %.splatinsert1138, <8 x i1> poison, <8 x i32> zeroinitializer
  %6294 = select <8 x i1> %.splat1139, <8 x i1> %6290, <8 x i1> %convergence.cascade.flow1130
  %6295 = add i32 %convergence.cascade.depth1131, 1
  %6296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6294)
  %6297 = icmp ult i32 %6295, 8
  %6298 = and i1 %6296, %6297
  %6299 = and i1 %6267, %6298
  %convergence.parent.token1140 = load i32, ptr %current.token, align 4
  %convergence.parent.present1141 = icmp ne i32 %convergence.parent.token1140, 0
  %6300 = and i1 %6299, %convergence.parent.present1141
  br i1 %6300, label %convergence.cascade1126, label %convergence.cascade.exit1127

convergence.cascade.exit1127:                     ; preds = %convergence.cascade1126, %schedule.74
  %convergence.cascade.result1142 = phi <8 x i1> [ %1362, %schedule.74 ], [ %6294, %convergence.cascade1126 ]
  %6301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1142)
  br i1 %6301, label %convergence.target.74.ready, label %scheduler.loop

convergence.target.74.ready:                      ; preds = %convergence.cascade.exit1127
  %6302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1142)
  %6303 = bitcast <8 x i1> %convergence.cascade.result1142 to i8
  %6304 = call i8 @llvm.cttz.i8(i8 %6303, i1 false)
  %6305 = zext i8 %6304 to i32
  %6306 = select i1 %6302, i32 %6305, i32 0
  %6307 = load <8 x i64>, ptr %.slot170, align 64
  %6308 = select <8 x i1> %convergence.cascade.result1142, <8 x i64> zeroinitializer, <8 x i64> %6307
  store <8 x i64> %6308, ptr %.slot170, align 64
  %6309 = load <8 x float>, ptr %.slot171, align 32
  %6310 = select <8 x i1> %convergence.cascade.result1142, <8 x float> zeroinitializer, <8 x float> %6309
  store <8 x float> %6310, ptr %.slot171, align 32
  store <8 x i1> %convergence.cascade.result1142, ptr %current.mask, align 1
  %6311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1142)
  br i1 %6311, label %schedule.75, label %scheduler.loop

varying.divergent1144:                            ; preds = %schedule.75
  %6312 = load i32, ptr %current.token, align 4
  %6313 = icmp ne i32 %6312, 0
  %6314 = sub i32 %6312, 1
  %6315 = select i1 %6313, i32 %6314, i32 0
  %6316 = load i8, ptr %frame.active, align 1
  %6317 = trunc i32 %6315 to i8
  %6318 = shl i8 1, %6317
  %6319 = and i8 %6316, %6318
  %6320 = icmp ne i8 %6319, 0
  %6321 = load <8 x i32>, ptr %frame.static.id, align 32
  %6322 = extractelement <8 x i32> %6321, i32 %6315
  %6323 = icmp eq i32 %6322, 26
  %6324 = and i1 %6320, %6323
  %6325 = and i1 %6313, %6324
  %6326 = xor i1 %6325, true
  %6327 = and i1 true, %6326
  %6328 = xor i8 %6316, -1
  %6329 = icmp ne i8 %6328, 0
  %6330 = xor i1 %6329, true
  %6331 = and i1 %6327, %6330
  br i1 %6331, label %convergence.overflow.trap1146, label %convergence.overflow.resume1147

varying.coherent1145:                             ; preds = %schedule.75
  br i1 %1373, label %varying.coherent.true1150, label %varying.coherent.false1151

convergence.overflow.trap1146:                    ; preds = %varying.divergent1144
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1147:                  ; preds = %varying.divergent1144
  %6332 = call i8 @llvm.cttz.i8(i8 %6328, i1 false)
  %6333 = zext i8 %6332 to i32
  %6334 = select i1 %6329, i32 %6333, i32 0
  %6335 = trunc i32 %6334 to i8
  %6336 = shl i8 1, %6335
  %6337 = or i8 %6316, %6336
  %6338 = select i1 %6327, i8 %6337, i8 %6316
  store i8 %6338, ptr %frame.active, align 1
  %6339 = load <8 x i32>, ptr %frame.static.id, align 32
  %6340 = extractelement <8 x i32> %6339, i32 %6334
  %6341 = select i1 %6327, i32 26, i32 %6340
  %6342 = load <8 x i32>, ptr %frame.static.id, align 32
  %6343 = insertelement <8 x i32> %6342, i32 %6341, i32 %6334
  store <8 x i32> %6343, ptr %frame.static.id, align 32
  %6344 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6345 = extractelement <8 x i32> %6344, i32 %6334
  %6346 = select i1 %6327, i32 %6312, i32 %6345
  %6347 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6348 = insertelement <8 x i32> %6347, i32 %6346, i32 %6334
  store <8 x i32> %6348, ptr %frame.parent.token, align 32
  %6349 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6334
  %6350 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6334
  %6351 = load <8 x i1>, ptr %6349, align 1
  %6352 = load <8 x i1>, ptr %6350, align 1
  %6353 = select i1 %6327, <8 x i1> %1363, <8 x i1> %6351
  store <8 x i1> %6353, ptr %6349, align 1
  %6354 = select i1 %6327, <8 x i1> zeroinitializer, <8 x i1> %6352
  store <8 x i1> %6354, ptr %6350, align 1
  %6355 = add i32 %6334, 1
  %6356 = select i1 %6325, i32 %6312, i32 %6355
  %6357 = select i1 true, i32 %6356, i32 %6312
  store i32 %6357, ptr %current.token, align 4
  %6358 = load i32, ptr %current.token, align 4
  %6359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1370)
  %6360 = load i32, ptr %ready.count, align 4
  %6361 = icmp uge i32 %6360, 8
  %6362 = and i1 %6359, %6361
  br i1 %6362, label %ready.overflow.trap1148, label %ready.overflow.resume1149

ready.overflow.trap1148:                          ; preds = %convergence.overflow.resume1147
  call void @llvm.trap()
  unreachable

ready.overflow.resume1149:                        ; preds = %convergence.overflow.resume1147
  %6363 = select i1 %6359, i32 %6360, i32 0
  %6364 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6363
  %6365 = load <8 x i1>, ptr %6364, align 1
  %6366 = select i1 %6359, <8 x i1> %1370, <8 x i1> %6365
  store <8 x i1> %6366, ptr %6364, align 1
  %6367 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6363
  %6368 = load i32, ptr %6367, align 4
  %6369 = select i1 %6359, i32 76, i32 %6368
  store i32 %6369, ptr %6367, align 4
  %6370 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6363
  %6371 = load i32, ptr %6370, align 4
  %6372 = select i1 %6359, i32 %6358, i32 %6371
  store i32 %6372, ptr %6370, align 4
  %6373 = add i32 %6360, 1
  %6374 = select i1 %6359, i32 %6373, i32 %6360
  store i32 %6374, ptr %ready.count, align 4
  %6375 = load <8 x i1>, ptr %runnable.mask, align 1
  %6376 = or <8 x i1> %6375, %1370
  store <8 x i1> %6376, ptr %runnable.mask, align 1
  store <8 x i1> %1372, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1150:                        ; preds = %varying.coherent1145
  store <8 x i1> %1363, ptr %current.mask, align 1
  %6377 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1363)
  br i1 %6377, label %schedule.76, label %scheduler.loop

varying.coherent.false1151:                       ; preds = %varying.coherent1145
  store <8 x i1> %1363, ptr %current.mask, align 1
  %6378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1363)
  br i1 %6378, label %schedule.77, label %scheduler.loop

convergence.cascade1156:                          ; preds = %convergence.cascade1156, %schedule.77
  %convergence.cascade.flow1160 = phi <8 x i1> [ %1403, %schedule.77 ], [ %6421, %convergence.cascade1156 ]
  %convergence.cascade.depth1161 = phi i32 [ 0, %schedule.77 ], [ %6422, %convergence.cascade1156 ]
  %6379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1160)
  %6380 = load i32, ptr %current.token, align 4
  %6381 = icmp ne i32 %6380, 0
  %6382 = and i1 %6379, %6381
  %6383 = sub i32 %6380, 1
  %6384 = select i1 %6382, i32 %6383, i32 0
  %6385 = load i8, ptr %frame.active, align 1
  %6386 = trunc i32 %6384 to i8
  %6387 = shl i8 1, %6386
  %6388 = and i8 %6385, %6387
  %6389 = icmp ne i8 %6388, 0
  %6390 = load <8 x i32>, ptr %frame.static.id, align 32
  %6391 = extractelement <8 x i32> %6390, i32 %6384
  %convergence.target.pointer1162 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6391
  %convergence.dynamic.target1163 = load i32, ptr %convergence.target.pointer1162, align 4
  %6392 = icmp eq i32 %convergence.dynamic.target1163, 77
  %6393 = and i1 %6389, %6392
  %6394 = and i1 %6382, %6393
  %6395 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6384
  %6396 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6384
  %6397 = load <8 x i1>, ptr %6395, align 1
  %6398 = load <8 x i1>, ptr %6396, align 1
  %6399 = or <8 x i1> %6398, %convergence.cascade.flow1160
  %6400 = load <8 x i1>, ptr %live.mask, align 1
  %6401 = and <8 x i1> %6397, %6400
  %6402 = icmp eq <8 x i1> %6399, %6401
  %6403 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6402)
  %6404 = and i1 %6394, %6403
  %6405 = select i1 %6404, <8 x i1> zeroinitializer, <8 x i1> %6399
  %6406 = select i1 %6394, <8 x i1> %6405, <8 x i1> %6398
  store <8 x i1> %6406, ptr %6396, align 1
  %6407 = select i1 %6404, <8 x i1> zeroinitializer, <8 x i1> %6397
  store <8 x i1> %6407, ptr %6395, align 1
  %6408 = trunc i32 %6384 to i8
  %6409 = shl i8 1, %6408
  %6410 = xor i8 %6409, -1
  %6411 = and i8 %6385, %6410
  %6412 = select i1 %6404, i8 %6411, i8 %6385
  store i8 %6412, ptr %frame.active, align 1
  %.splatinsert1164 = insertelement <8 x i1> poison, i1 %6394, i64 0
  %.splat1165 = shufflevector <8 x i1> %.splatinsert1164, <8 x i1> poison, <8 x i32> zeroinitializer
  %6413 = and <8 x i1> %convergence.cascade.flow1160, %.splat1165
  %6414 = load <8 x i1>, ptr %runnable.mask, align 1
  %6415 = xor <8 x i1> %6413, splat (i1 true)
  %6416 = and <8 x i1> %6414, %6415
  store <8 x i1> %6416, ptr %runnable.mask, align 1
  %.splatinsert1166 = insertelement <8 x i1> poison, i1 %6404, i64 0
  %.splat1167 = shufflevector <8 x i1> %.splatinsert1166, <8 x i1> poison, <8 x i32> zeroinitializer
  %6417 = select <8 x i1> %.splat1167, <8 x i1> %6399, <8 x i1> zeroinitializer
  %6418 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6419 = extractelement <8 x i32> %6418, i32 %6384
  %6420 = select i1 %6404, i32 %6419, i32 %6380
  store i32 %6420, ptr %current.token, align 4
  %.splatinsert1168 = insertelement <8 x i1> poison, i1 %6394, i64 0
  %.splat1169 = shufflevector <8 x i1> %.splatinsert1168, <8 x i1> poison, <8 x i32> zeroinitializer
  %6421 = select <8 x i1> %.splat1169, <8 x i1> %6417, <8 x i1> %convergence.cascade.flow1160
  %6422 = add i32 %convergence.cascade.depth1161, 1
  %6423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6421)
  %6424 = icmp ult i32 %6422, 8
  %6425 = and i1 %6423, %6424
  %6426 = and i1 %6394, %6425
  %convergence.parent.token1170 = load i32, ptr %current.token, align 4
  %convergence.parent.present1171 = icmp ne i32 %convergence.parent.token1170, 0
  %6427 = and i1 %6426, %convergence.parent.present1171
  br i1 %6427, label %convergence.cascade1156, label %convergence.cascade.exit1157

convergence.cascade.exit1157:                     ; preds = %convergence.cascade1156, %schedule.77
  %convergence.cascade.result1172 = phi <8 x i1> [ %1403, %schedule.77 ], [ %6421, %convergence.cascade1156 ]
  %6428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1172)
  br i1 %6428, label %convergence.target.77.ready, label %scheduler.loop

convergence.target.77.ready:                      ; preds = %convergence.cascade.exit1157
  %6429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1172)
  %6430 = bitcast <8 x i1> %convergence.cascade.result1172 to i8
  %6431 = call i8 @llvm.cttz.i8(i8 %6430, i1 false)
  %6432 = zext i8 %6431 to i32
  %6433 = select i1 %6429, i32 %6432, i32 0
  %6434 = load <8 x i64>, ptr %.slot172, align 64
  %6435 = select <8 x i1> %convergence.cascade.result1172, <8 x i64> zeroinitializer, <8 x i64> %6434
  store <8 x i64> %6435, ptr %.slot172, align 64
  %6436 = load <8 x float>, ptr %.slot173, align 32
  %6437 = select <8 x i1> %convergence.cascade.result1172, <8 x float> zeroinitializer, <8 x float> %6436
  store <8 x float> %6437, ptr %.slot173, align 32
  store <8 x i1> %convergence.cascade.result1172, ptr %current.mask, align 1
  %6438 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1172)
  br i1 %6438, label %schedule.78, label %scheduler.loop

varying.divergent1174:                            ; preds = %schedule.78
  %6439 = load i32, ptr %current.token, align 4
  %6440 = icmp ne i32 %6439, 0
  %6441 = sub i32 %6439, 1
  %6442 = select i1 %6440, i32 %6441, i32 0
  %6443 = load i8, ptr %frame.active, align 1
  %6444 = trunc i32 %6442 to i8
  %6445 = shl i8 1, %6444
  %6446 = and i8 %6443, %6445
  %6447 = icmp ne i8 %6446, 0
  %6448 = load <8 x i32>, ptr %frame.static.id, align 32
  %6449 = extractelement <8 x i32> %6448, i32 %6442
  %6450 = icmp eq i32 %6449, 27
  %6451 = and i1 %6447, %6450
  %6452 = and i1 %6440, %6451
  %6453 = xor i1 %6452, true
  %6454 = and i1 true, %6453
  %6455 = xor i8 %6443, -1
  %6456 = icmp ne i8 %6455, 0
  %6457 = xor i1 %6456, true
  %6458 = and i1 %6454, %6457
  br i1 %6458, label %convergence.overflow.trap1176, label %convergence.overflow.resume1177

varying.coherent1175:                             ; preds = %schedule.78
  br i1 %1414, label %varying.coherent.true1180, label %varying.coherent.false1181

convergence.overflow.trap1176:                    ; preds = %varying.divergent1174
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1177:                  ; preds = %varying.divergent1174
  %6459 = call i8 @llvm.cttz.i8(i8 %6455, i1 false)
  %6460 = zext i8 %6459 to i32
  %6461 = select i1 %6456, i32 %6460, i32 0
  %6462 = trunc i32 %6461 to i8
  %6463 = shl i8 1, %6462
  %6464 = or i8 %6443, %6463
  %6465 = select i1 %6454, i8 %6464, i8 %6443
  store i8 %6465, ptr %frame.active, align 1
  %6466 = load <8 x i32>, ptr %frame.static.id, align 32
  %6467 = extractelement <8 x i32> %6466, i32 %6461
  %6468 = select i1 %6454, i32 27, i32 %6467
  %6469 = load <8 x i32>, ptr %frame.static.id, align 32
  %6470 = insertelement <8 x i32> %6469, i32 %6468, i32 %6461
  store <8 x i32> %6470, ptr %frame.static.id, align 32
  %6471 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6472 = extractelement <8 x i32> %6471, i32 %6461
  %6473 = select i1 %6454, i32 %6439, i32 %6472
  %6474 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6475 = insertelement <8 x i32> %6474, i32 %6473, i32 %6461
  store <8 x i32> %6475, ptr %frame.parent.token, align 32
  %6476 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6461
  %6477 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6461
  %6478 = load <8 x i1>, ptr %6476, align 1
  %6479 = load <8 x i1>, ptr %6477, align 1
  %6480 = select i1 %6454, <8 x i1> %1404, <8 x i1> %6478
  store <8 x i1> %6480, ptr %6476, align 1
  %6481 = select i1 %6454, <8 x i1> zeroinitializer, <8 x i1> %6479
  store <8 x i1> %6481, ptr %6477, align 1
  %6482 = add i32 %6461, 1
  %6483 = select i1 %6452, i32 %6439, i32 %6482
  %6484 = select i1 true, i32 %6483, i32 %6439
  store i32 %6484, ptr %current.token, align 4
  %6485 = load i32, ptr %current.token, align 4
  %6486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1411)
  %6487 = load i32, ptr %ready.count, align 4
  %6488 = icmp uge i32 %6487, 8
  %6489 = and i1 %6486, %6488
  br i1 %6489, label %ready.overflow.trap1178, label %ready.overflow.resume1179

ready.overflow.trap1178:                          ; preds = %convergence.overflow.resume1177
  call void @llvm.trap()
  unreachable

ready.overflow.resume1179:                        ; preds = %convergence.overflow.resume1177
  %6490 = select i1 %6486, i32 %6487, i32 0
  %6491 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6490
  %6492 = load <8 x i1>, ptr %6491, align 1
  %6493 = select i1 %6486, <8 x i1> %1411, <8 x i1> %6492
  store <8 x i1> %6493, ptr %6491, align 1
  %6494 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6490
  %6495 = load i32, ptr %6494, align 4
  %6496 = select i1 %6486, i32 79, i32 %6495
  store i32 %6496, ptr %6494, align 4
  %6497 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6490
  %6498 = load i32, ptr %6497, align 4
  %6499 = select i1 %6486, i32 %6485, i32 %6498
  store i32 %6499, ptr %6497, align 4
  %6500 = add i32 %6487, 1
  %6501 = select i1 %6486, i32 %6500, i32 %6487
  store i32 %6501, ptr %ready.count, align 4
  %6502 = load <8 x i1>, ptr %runnable.mask, align 1
  %6503 = or <8 x i1> %6502, %1411
  store <8 x i1> %6503, ptr %runnable.mask, align 1
  store <8 x i1> %1413, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1180:                        ; preds = %varying.coherent1175
  store <8 x i1> %1404, ptr %current.mask, align 1
  %6504 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1404)
  br i1 %6504, label %schedule.79, label %scheduler.loop

varying.coherent.false1181:                       ; preds = %varying.coherent1175
  store <8 x i1> %1404, ptr %current.mask, align 1
  %6505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1404)
  br i1 %6505, label %schedule.80, label %scheduler.loop

convergence.cascade1186:                          ; preds = %convergence.cascade1186, %schedule.80
  %convergence.cascade.flow1190 = phi <8 x i1> [ %1444, %schedule.80 ], [ %6548, %convergence.cascade1186 ]
  %convergence.cascade.depth1191 = phi i32 [ 0, %schedule.80 ], [ %6549, %convergence.cascade1186 ]
  %6506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1190)
  %6507 = load i32, ptr %current.token, align 4
  %6508 = icmp ne i32 %6507, 0
  %6509 = and i1 %6506, %6508
  %6510 = sub i32 %6507, 1
  %6511 = select i1 %6509, i32 %6510, i32 0
  %6512 = load i8, ptr %frame.active, align 1
  %6513 = trunc i32 %6511 to i8
  %6514 = shl i8 1, %6513
  %6515 = and i8 %6512, %6514
  %6516 = icmp ne i8 %6515, 0
  %6517 = load <8 x i32>, ptr %frame.static.id, align 32
  %6518 = extractelement <8 x i32> %6517, i32 %6511
  %convergence.target.pointer1192 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6518
  %convergence.dynamic.target1193 = load i32, ptr %convergence.target.pointer1192, align 4
  %6519 = icmp eq i32 %convergence.dynamic.target1193, 80
  %6520 = and i1 %6516, %6519
  %6521 = and i1 %6509, %6520
  %6522 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6511
  %6523 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6511
  %6524 = load <8 x i1>, ptr %6522, align 1
  %6525 = load <8 x i1>, ptr %6523, align 1
  %6526 = or <8 x i1> %6525, %convergence.cascade.flow1190
  %6527 = load <8 x i1>, ptr %live.mask, align 1
  %6528 = and <8 x i1> %6524, %6527
  %6529 = icmp eq <8 x i1> %6526, %6528
  %6530 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6529)
  %6531 = and i1 %6521, %6530
  %6532 = select i1 %6531, <8 x i1> zeroinitializer, <8 x i1> %6526
  %6533 = select i1 %6521, <8 x i1> %6532, <8 x i1> %6525
  store <8 x i1> %6533, ptr %6523, align 1
  %6534 = select i1 %6531, <8 x i1> zeroinitializer, <8 x i1> %6524
  store <8 x i1> %6534, ptr %6522, align 1
  %6535 = trunc i32 %6511 to i8
  %6536 = shl i8 1, %6535
  %6537 = xor i8 %6536, -1
  %6538 = and i8 %6512, %6537
  %6539 = select i1 %6531, i8 %6538, i8 %6512
  store i8 %6539, ptr %frame.active, align 1
  %.splatinsert1194 = insertelement <8 x i1> poison, i1 %6521, i64 0
  %.splat1195 = shufflevector <8 x i1> %.splatinsert1194, <8 x i1> poison, <8 x i32> zeroinitializer
  %6540 = and <8 x i1> %convergence.cascade.flow1190, %.splat1195
  %6541 = load <8 x i1>, ptr %runnable.mask, align 1
  %6542 = xor <8 x i1> %6540, splat (i1 true)
  %6543 = and <8 x i1> %6541, %6542
  store <8 x i1> %6543, ptr %runnable.mask, align 1
  %.splatinsert1196 = insertelement <8 x i1> poison, i1 %6531, i64 0
  %.splat1197 = shufflevector <8 x i1> %.splatinsert1196, <8 x i1> poison, <8 x i32> zeroinitializer
  %6544 = select <8 x i1> %.splat1197, <8 x i1> %6526, <8 x i1> zeroinitializer
  %6545 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6546 = extractelement <8 x i32> %6545, i32 %6511
  %6547 = select i1 %6531, i32 %6546, i32 %6507
  store i32 %6547, ptr %current.token, align 4
  %.splatinsert1198 = insertelement <8 x i1> poison, i1 %6521, i64 0
  %.splat1199 = shufflevector <8 x i1> %.splatinsert1198, <8 x i1> poison, <8 x i32> zeroinitializer
  %6548 = select <8 x i1> %.splat1199, <8 x i1> %6544, <8 x i1> %convergence.cascade.flow1190
  %6549 = add i32 %convergence.cascade.depth1191, 1
  %6550 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6548)
  %6551 = icmp ult i32 %6549, 8
  %6552 = and i1 %6550, %6551
  %6553 = and i1 %6521, %6552
  %convergence.parent.token1200 = load i32, ptr %current.token, align 4
  %convergence.parent.present1201 = icmp ne i32 %convergence.parent.token1200, 0
  %6554 = and i1 %6553, %convergence.parent.present1201
  br i1 %6554, label %convergence.cascade1186, label %convergence.cascade.exit1187

convergence.cascade.exit1187:                     ; preds = %convergence.cascade1186, %schedule.80
  %convergence.cascade.result1202 = phi <8 x i1> [ %1444, %schedule.80 ], [ %6548, %convergence.cascade1186 ]
  %6555 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1202)
  br i1 %6555, label %convergence.target.80.ready, label %scheduler.loop

convergence.target.80.ready:                      ; preds = %convergence.cascade.exit1187
  %6556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1202)
  %6557 = bitcast <8 x i1> %convergence.cascade.result1202 to i8
  %6558 = call i8 @llvm.cttz.i8(i8 %6557, i1 false)
  %6559 = zext i8 %6558 to i32
  %6560 = select i1 %6556, i32 %6559, i32 0
  %6561 = load <8 x i64>, ptr %.slot174, align 64
  %6562 = select <8 x i1> %convergence.cascade.result1202, <8 x i64> zeroinitializer, <8 x i64> %6561
  store <8 x i64> %6562, ptr %.slot174, align 64
  %6563 = load <8 x float>, ptr %.slot175, align 32
  %6564 = select <8 x i1> %convergence.cascade.result1202, <8 x float> zeroinitializer, <8 x float> %6563
  store <8 x float> %6564, ptr %.slot175, align 32
  store <8 x i1> %convergence.cascade.result1202, ptr %current.mask, align 1
  %6565 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1202)
  br i1 %6565, label %schedule.81, label %scheduler.loop

varying.divergent1204:                            ; preds = %schedule.81
  %6566 = load i32, ptr %current.token, align 4
  %6567 = icmp ne i32 %6566, 0
  %6568 = sub i32 %6566, 1
  %6569 = select i1 %6567, i32 %6568, i32 0
  %6570 = load i8, ptr %frame.active, align 1
  %6571 = trunc i32 %6569 to i8
  %6572 = shl i8 1, %6571
  %6573 = and i8 %6570, %6572
  %6574 = icmp ne i8 %6573, 0
  %6575 = load <8 x i32>, ptr %frame.static.id, align 32
  %6576 = extractelement <8 x i32> %6575, i32 %6569
  %6577 = icmp eq i32 %6576, 28
  %6578 = and i1 %6574, %6577
  %6579 = and i1 %6567, %6578
  %6580 = xor i1 %6579, true
  %6581 = and i1 true, %6580
  %6582 = xor i8 %6570, -1
  %6583 = icmp ne i8 %6582, 0
  %6584 = xor i1 %6583, true
  %6585 = and i1 %6581, %6584
  br i1 %6585, label %convergence.overflow.trap1206, label %convergence.overflow.resume1207

varying.coherent1205:                             ; preds = %schedule.81
  br i1 %1455, label %varying.coherent.true1210, label %varying.coherent.false1211

convergence.overflow.trap1206:                    ; preds = %varying.divergent1204
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1207:                  ; preds = %varying.divergent1204
  %6586 = call i8 @llvm.cttz.i8(i8 %6582, i1 false)
  %6587 = zext i8 %6586 to i32
  %6588 = select i1 %6583, i32 %6587, i32 0
  %6589 = trunc i32 %6588 to i8
  %6590 = shl i8 1, %6589
  %6591 = or i8 %6570, %6590
  %6592 = select i1 %6581, i8 %6591, i8 %6570
  store i8 %6592, ptr %frame.active, align 1
  %6593 = load <8 x i32>, ptr %frame.static.id, align 32
  %6594 = extractelement <8 x i32> %6593, i32 %6588
  %6595 = select i1 %6581, i32 28, i32 %6594
  %6596 = load <8 x i32>, ptr %frame.static.id, align 32
  %6597 = insertelement <8 x i32> %6596, i32 %6595, i32 %6588
  store <8 x i32> %6597, ptr %frame.static.id, align 32
  %6598 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6599 = extractelement <8 x i32> %6598, i32 %6588
  %6600 = select i1 %6581, i32 %6566, i32 %6599
  %6601 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6602 = insertelement <8 x i32> %6601, i32 %6600, i32 %6588
  store <8 x i32> %6602, ptr %frame.parent.token, align 32
  %6603 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6588
  %6604 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6588
  %6605 = load <8 x i1>, ptr %6603, align 1
  %6606 = load <8 x i1>, ptr %6604, align 1
  %6607 = select i1 %6581, <8 x i1> %1445, <8 x i1> %6605
  store <8 x i1> %6607, ptr %6603, align 1
  %6608 = select i1 %6581, <8 x i1> zeroinitializer, <8 x i1> %6606
  store <8 x i1> %6608, ptr %6604, align 1
  %6609 = add i32 %6588, 1
  %6610 = select i1 %6579, i32 %6566, i32 %6609
  %6611 = select i1 true, i32 %6610, i32 %6566
  store i32 %6611, ptr %current.token, align 4
  %6612 = load i32, ptr %current.token, align 4
  %6613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1452)
  %6614 = load i32, ptr %ready.count, align 4
  %6615 = icmp uge i32 %6614, 8
  %6616 = and i1 %6613, %6615
  br i1 %6616, label %ready.overflow.trap1208, label %ready.overflow.resume1209

ready.overflow.trap1208:                          ; preds = %convergence.overflow.resume1207
  call void @llvm.trap()
  unreachable

ready.overflow.resume1209:                        ; preds = %convergence.overflow.resume1207
  %6617 = select i1 %6613, i32 %6614, i32 0
  %6618 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6617
  %6619 = load <8 x i1>, ptr %6618, align 1
  %6620 = select i1 %6613, <8 x i1> %1452, <8 x i1> %6619
  store <8 x i1> %6620, ptr %6618, align 1
  %6621 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6617
  %6622 = load i32, ptr %6621, align 4
  %6623 = select i1 %6613, i32 82, i32 %6622
  store i32 %6623, ptr %6621, align 4
  %6624 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6617
  %6625 = load i32, ptr %6624, align 4
  %6626 = select i1 %6613, i32 %6612, i32 %6625
  store i32 %6626, ptr %6624, align 4
  %6627 = add i32 %6614, 1
  %6628 = select i1 %6613, i32 %6627, i32 %6614
  store i32 %6628, ptr %ready.count, align 4
  %6629 = load <8 x i1>, ptr %runnable.mask, align 1
  %6630 = or <8 x i1> %6629, %1452
  store <8 x i1> %6630, ptr %runnable.mask, align 1
  store <8 x i1> %1454, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1210:                        ; preds = %varying.coherent1205
  store <8 x i1> %1445, ptr %current.mask, align 1
  %6631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1445)
  br i1 %6631, label %schedule.82, label %scheduler.loop

varying.coherent.false1211:                       ; preds = %varying.coherent1205
  store <8 x i1> %1445, ptr %current.mask, align 1
  %6632 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1445)
  br i1 %6632, label %schedule.83, label %scheduler.loop

convergence.cascade1216:                          ; preds = %convergence.cascade1216, %schedule.83
  %convergence.cascade.flow1220 = phi <8 x i1> [ %1485, %schedule.83 ], [ %6675, %convergence.cascade1216 ]
  %convergence.cascade.depth1221 = phi i32 [ 0, %schedule.83 ], [ %6676, %convergence.cascade1216 ]
  %6633 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1220)
  %6634 = load i32, ptr %current.token, align 4
  %6635 = icmp ne i32 %6634, 0
  %6636 = and i1 %6633, %6635
  %6637 = sub i32 %6634, 1
  %6638 = select i1 %6636, i32 %6637, i32 0
  %6639 = load i8, ptr %frame.active, align 1
  %6640 = trunc i32 %6638 to i8
  %6641 = shl i8 1, %6640
  %6642 = and i8 %6639, %6641
  %6643 = icmp ne i8 %6642, 0
  %6644 = load <8 x i32>, ptr %frame.static.id, align 32
  %6645 = extractelement <8 x i32> %6644, i32 %6638
  %convergence.target.pointer1222 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6645
  %convergence.dynamic.target1223 = load i32, ptr %convergence.target.pointer1222, align 4
  %6646 = icmp eq i32 %convergence.dynamic.target1223, 83
  %6647 = and i1 %6643, %6646
  %6648 = and i1 %6636, %6647
  %6649 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6638
  %6650 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6638
  %6651 = load <8 x i1>, ptr %6649, align 1
  %6652 = load <8 x i1>, ptr %6650, align 1
  %6653 = or <8 x i1> %6652, %convergence.cascade.flow1220
  %6654 = load <8 x i1>, ptr %live.mask, align 1
  %6655 = and <8 x i1> %6651, %6654
  %6656 = icmp eq <8 x i1> %6653, %6655
  %6657 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6656)
  %6658 = and i1 %6648, %6657
  %6659 = select i1 %6658, <8 x i1> zeroinitializer, <8 x i1> %6653
  %6660 = select i1 %6648, <8 x i1> %6659, <8 x i1> %6652
  store <8 x i1> %6660, ptr %6650, align 1
  %6661 = select i1 %6658, <8 x i1> zeroinitializer, <8 x i1> %6651
  store <8 x i1> %6661, ptr %6649, align 1
  %6662 = trunc i32 %6638 to i8
  %6663 = shl i8 1, %6662
  %6664 = xor i8 %6663, -1
  %6665 = and i8 %6639, %6664
  %6666 = select i1 %6658, i8 %6665, i8 %6639
  store i8 %6666, ptr %frame.active, align 1
  %.splatinsert1224 = insertelement <8 x i1> poison, i1 %6648, i64 0
  %.splat1225 = shufflevector <8 x i1> %.splatinsert1224, <8 x i1> poison, <8 x i32> zeroinitializer
  %6667 = and <8 x i1> %convergence.cascade.flow1220, %.splat1225
  %6668 = load <8 x i1>, ptr %runnable.mask, align 1
  %6669 = xor <8 x i1> %6667, splat (i1 true)
  %6670 = and <8 x i1> %6668, %6669
  store <8 x i1> %6670, ptr %runnable.mask, align 1
  %.splatinsert1226 = insertelement <8 x i1> poison, i1 %6658, i64 0
  %.splat1227 = shufflevector <8 x i1> %.splatinsert1226, <8 x i1> poison, <8 x i32> zeroinitializer
  %6671 = select <8 x i1> %.splat1227, <8 x i1> %6653, <8 x i1> zeroinitializer
  %6672 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6673 = extractelement <8 x i32> %6672, i32 %6638
  %6674 = select i1 %6658, i32 %6673, i32 %6634
  store i32 %6674, ptr %current.token, align 4
  %.splatinsert1228 = insertelement <8 x i1> poison, i1 %6648, i64 0
  %.splat1229 = shufflevector <8 x i1> %.splatinsert1228, <8 x i1> poison, <8 x i32> zeroinitializer
  %6675 = select <8 x i1> %.splat1229, <8 x i1> %6671, <8 x i1> %convergence.cascade.flow1220
  %6676 = add i32 %convergence.cascade.depth1221, 1
  %6677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6675)
  %6678 = icmp ult i32 %6676, 8
  %6679 = and i1 %6677, %6678
  %6680 = and i1 %6648, %6679
  %convergence.parent.token1230 = load i32, ptr %current.token, align 4
  %convergence.parent.present1231 = icmp ne i32 %convergence.parent.token1230, 0
  %6681 = and i1 %6680, %convergence.parent.present1231
  br i1 %6681, label %convergence.cascade1216, label %convergence.cascade.exit1217

convergence.cascade.exit1217:                     ; preds = %convergence.cascade1216, %schedule.83
  %convergence.cascade.result1232 = phi <8 x i1> [ %1485, %schedule.83 ], [ %6675, %convergence.cascade1216 ]
  %6682 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1232)
  br i1 %6682, label %convergence.target.83.ready, label %scheduler.loop

convergence.target.83.ready:                      ; preds = %convergence.cascade.exit1217
  %6683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1232)
  %6684 = bitcast <8 x i1> %convergence.cascade.result1232 to i8
  %6685 = call i8 @llvm.cttz.i8(i8 %6684, i1 false)
  %6686 = zext i8 %6685 to i32
  %6687 = select i1 %6683, i32 %6686, i32 0
  %6688 = load <8 x i64>, ptr %.slot176, align 64
  %6689 = select <8 x i1> %convergence.cascade.result1232, <8 x i64> zeroinitializer, <8 x i64> %6688
  store <8 x i64> %6689, ptr %.slot176, align 64
  %6690 = load <8 x float>, ptr %.slot177, align 32
  %6691 = select <8 x i1> %convergence.cascade.result1232, <8 x float> zeroinitializer, <8 x float> %6690
  store <8 x float> %6691, ptr %.slot177, align 32
  store <8 x i1> %convergence.cascade.result1232, ptr %current.mask, align 1
  %6692 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1232)
  br i1 %6692, label %schedule.84, label %scheduler.loop

varying.divergent1234:                            ; preds = %schedule.84
  %6693 = load i32, ptr %current.token, align 4
  %6694 = icmp ne i32 %6693, 0
  %6695 = sub i32 %6693, 1
  %6696 = select i1 %6694, i32 %6695, i32 0
  %6697 = load i8, ptr %frame.active, align 1
  %6698 = trunc i32 %6696 to i8
  %6699 = shl i8 1, %6698
  %6700 = and i8 %6697, %6699
  %6701 = icmp ne i8 %6700, 0
  %6702 = load <8 x i32>, ptr %frame.static.id, align 32
  %6703 = extractelement <8 x i32> %6702, i32 %6696
  %6704 = icmp eq i32 %6703, 29
  %6705 = and i1 %6701, %6704
  %6706 = and i1 %6694, %6705
  %6707 = xor i1 %6706, true
  %6708 = and i1 true, %6707
  %6709 = xor i8 %6697, -1
  %6710 = icmp ne i8 %6709, 0
  %6711 = xor i1 %6710, true
  %6712 = and i1 %6708, %6711
  br i1 %6712, label %convergence.overflow.trap1236, label %convergence.overflow.resume1237

varying.coherent1235:                             ; preds = %schedule.84
  br i1 %1496, label %varying.coherent.true1240, label %varying.coherent.false1241

convergence.overflow.trap1236:                    ; preds = %varying.divergent1234
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1237:                  ; preds = %varying.divergent1234
  %6713 = call i8 @llvm.cttz.i8(i8 %6709, i1 false)
  %6714 = zext i8 %6713 to i32
  %6715 = select i1 %6710, i32 %6714, i32 0
  %6716 = trunc i32 %6715 to i8
  %6717 = shl i8 1, %6716
  %6718 = or i8 %6697, %6717
  %6719 = select i1 %6708, i8 %6718, i8 %6697
  store i8 %6719, ptr %frame.active, align 1
  %6720 = load <8 x i32>, ptr %frame.static.id, align 32
  %6721 = extractelement <8 x i32> %6720, i32 %6715
  %6722 = select i1 %6708, i32 29, i32 %6721
  %6723 = load <8 x i32>, ptr %frame.static.id, align 32
  %6724 = insertelement <8 x i32> %6723, i32 %6722, i32 %6715
  store <8 x i32> %6724, ptr %frame.static.id, align 32
  %6725 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6726 = extractelement <8 x i32> %6725, i32 %6715
  %6727 = select i1 %6708, i32 %6693, i32 %6726
  %6728 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6729 = insertelement <8 x i32> %6728, i32 %6727, i32 %6715
  store <8 x i32> %6729, ptr %frame.parent.token, align 32
  %6730 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6715
  %6731 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6715
  %6732 = load <8 x i1>, ptr %6730, align 1
  %6733 = load <8 x i1>, ptr %6731, align 1
  %6734 = select i1 %6708, <8 x i1> %1486, <8 x i1> %6732
  store <8 x i1> %6734, ptr %6730, align 1
  %6735 = select i1 %6708, <8 x i1> zeroinitializer, <8 x i1> %6733
  store <8 x i1> %6735, ptr %6731, align 1
  %6736 = add i32 %6715, 1
  %6737 = select i1 %6706, i32 %6693, i32 %6736
  %6738 = select i1 true, i32 %6737, i32 %6693
  store i32 %6738, ptr %current.token, align 4
  %6739 = load i32, ptr %current.token, align 4
  %6740 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1493)
  %6741 = load i32, ptr %ready.count, align 4
  %6742 = icmp uge i32 %6741, 8
  %6743 = and i1 %6740, %6742
  br i1 %6743, label %ready.overflow.trap1238, label %ready.overflow.resume1239

ready.overflow.trap1238:                          ; preds = %convergence.overflow.resume1237
  call void @llvm.trap()
  unreachable

ready.overflow.resume1239:                        ; preds = %convergence.overflow.resume1237
  %6744 = select i1 %6740, i32 %6741, i32 0
  %6745 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6744
  %6746 = load <8 x i1>, ptr %6745, align 1
  %6747 = select i1 %6740, <8 x i1> %1493, <8 x i1> %6746
  store <8 x i1> %6747, ptr %6745, align 1
  %6748 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6744
  %6749 = load i32, ptr %6748, align 4
  %6750 = select i1 %6740, i32 85, i32 %6749
  store i32 %6750, ptr %6748, align 4
  %6751 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6744
  %6752 = load i32, ptr %6751, align 4
  %6753 = select i1 %6740, i32 %6739, i32 %6752
  store i32 %6753, ptr %6751, align 4
  %6754 = add i32 %6741, 1
  %6755 = select i1 %6740, i32 %6754, i32 %6741
  store i32 %6755, ptr %ready.count, align 4
  %6756 = load <8 x i1>, ptr %runnable.mask, align 1
  %6757 = or <8 x i1> %6756, %1493
  store <8 x i1> %6757, ptr %runnable.mask, align 1
  store <8 x i1> %1495, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1240:                        ; preds = %varying.coherent1235
  store <8 x i1> %1486, ptr %current.mask, align 1
  %6758 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1486)
  br i1 %6758, label %schedule.85, label %scheduler.loop

varying.coherent.false1241:                       ; preds = %varying.coherent1235
  store <8 x i1> %1486, ptr %current.mask, align 1
  %6759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1486)
  br i1 %6759, label %schedule.86, label %scheduler.loop

convergence.cascade1246:                          ; preds = %convergence.cascade1246, %schedule.86
  %convergence.cascade.flow1250 = phi <8 x i1> [ %1526, %schedule.86 ], [ %6802, %convergence.cascade1246 ]
  %convergence.cascade.depth1251 = phi i32 [ 0, %schedule.86 ], [ %6803, %convergence.cascade1246 ]
  %6760 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1250)
  %6761 = load i32, ptr %current.token, align 4
  %6762 = icmp ne i32 %6761, 0
  %6763 = and i1 %6760, %6762
  %6764 = sub i32 %6761, 1
  %6765 = select i1 %6763, i32 %6764, i32 0
  %6766 = load i8, ptr %frame.active, align 1
  %6767 = trunc i32 %6765 to i8
  %6768 = shl i8 1, %6767
  %6769 = and i8 %6766, %6768
  %6770 = icmp ne i8 %6769, 0
  %6771 = load <8 x i32>, ptr %frame.static.id, align 32
  %6772 = extractelement <8 x i32> %6771, i32 %6765
  %convergence.target.pointer1252 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6772
  %convergence.dynamic.target1253 = load i32, ptr %convergence.target.pointer1252, align 4
  %6773 = icmp eq i32 %convergence.dynamic.target1253, 86
  %6774 = and i1 %6770, %6773
  %6775 = and i1 %6763, %6774
  %6776 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6765
  %6777 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6765
  %6778 = load <8 x i1>, ptr %6776, align 1
  %6779 = load <8 x i1>, ptr %6777, align 1
  %6780 = or <8 x i1> %6779, %convergence.cascade.flow1250
  %6781 = load <8 x i1>, ptr %live.mask, align 1
  %6782 = and <8 x i1> %6778, %6781
  %6783 = icmp eq <8 x i1> %6780, %6782
  %6784 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6783)
  %6785 = and i1 %6775, %6784
  %6786 = select i1 %6785, <8 x i1> zeroinitializer, <8 x i1> %6780
  %6787 = select i1 %6775, <8 x i1> %6786, <8 x i1> %6779
  store <8 x i1> %6787, ptr %6777, align 1
  %6788 = select i1 %6785, <8 x i1> zeroinitializer, <8 x i1> %6778
  store <8 x i1> %6788, ptr %6776, align 1
  %6789 = trunc i32 %6765 to i8
  %6790 = shl i8 1, %6789
  %6791 = xor i8 %6790, -1
  %6792 = and i8 %6766, %6791
  %6793 = select i1 %6785, i8 %6792, i8 %6766
  store i8 %6793, ptr %frame.active, align 1
  %.splatinsert1254 = insertelement <8 x i1> poison, i1 %6775, i64 0
  %.splat1255 = shufflevector <8 x i1> %.splatinsert1254, <8 x i1> poison, <8 x i32> zeroinitializer
  %6794 = and <8 x i1> %convergence.cascade.flow1250, %.splat1255
  %6795 = load <8 x i1>, ptr %runnable.mask, align 1
  %6796 = xor <8 x i1> %6794, splat (i1 true)
  %6797 = and <8 x i1> %6795, %6796
  store <8 x i1> %6797, ptr %runnable.mask, align 1
  %.splatinsert1256 = insertelement <8 x i1> poison, i1 %6785, i64 0
  %.splat1257 = shufflevector <8 x i1> %.splatinsert1256, <8 x i1> poison, <8 x i32> zeroinitializer
  %6798 = select <8 x i1> %.splat1257, <8 x i1> %6780, <8 x i1> zeroinitializer
  %6799 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6800 = extractelement <8 x i32> %6799, i32 %6765
  %6801 = select i1 %6785, i32 %6800, i32 %6761
  store i32 %6801, ptr %current.token, align 4
  %.splatinsert1258 = insertelement <8 x i1> poison, i1 %6775, i64 0
  %.splat1259 = shufflevector <8 x i1> %.splatinsert1258, <8 x i1> poison, <8 x i32> zeroinitializer
  %6802 = select <8 x i1> %.splat1259, <8 x i1> %6798, <8 x i1> %convergence.cascade.flow1250
  %6803 = add i32 %convergence.cascade.depth1251, 1
  %6804 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6802)
  %6805 = icmp ult i32 %6803, 8
  %6806 = and i1 %6804, %6805
  %6807 = and i1 %6775, %6806
  %convergence.parent.token1260 = load i32, ptr %current.token, align 4
  %convergence.parent.present1261 = icmp ne i32 %convergence.parent.token1260, 0
  %6808 = and i1 %6807, %convergence.parent.present1261
  br i1 %6808, label %convergence.cascade1246, label %convergence.cascade.exit1247

convergence.cascade.exit1247:                     ; preds = %convergence.cascade1246, %schedule.86
  %convergence.cascade.result1262 = phi <8 x i1> [ %1526, %schedule.86 ], [ %6802, %convergence.cascade1246 ]
  %6809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1262)
  br i1 %6809, label %convergence.target.86.ready, label %scheduler.loop

convergence.target.86.ready:                      ; preds = %convergence.cascade.exit1247
  %6810 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1262)
  %6811 = bitcast <8 x i1> %convergence.cascade.result1262 to i8
  %6812 = call i8 @llvm.cttz.i8(i8 %6811, i1 false)
  %6813 = zext i8 %6812 to i32
  %6814 = select i1 %6810, i32 %6813, i32 0
  %.spill.load1263 = load <8 x float>, ptr %.spill154, align 32
  %.state1264 = load <8 x float>, ptr %.slot163, align 32
  %6815 = fadd <8 x float> %.spill.load1263, %.state1264
  %6816 = load <8 x float>, ptr %.spill178, align 32
  %6817 = select <8 x i1> %convergence.cascade.result1262, <8 x float> %6815, <8 x float> %6816
  store <8 x float> %6817, ptr %.spill178, align 32
  %.spill.load1265 = load <8 x float>, ptr %.spill155, align 32
  %.state1266 = load <8 x float>, ptr %.slot165, align 32
  %6818 = fadd <8 x float> %.spill.load1265, %.state1266
  %6819 = load <8 x float>, ptr %.spill179, align 32
  %6820 = select <8 x i1> %convergence.cascade.result1262, <8 x float> %6818, <8 x float> %6819
  store <8 x float> %6820, ptr %.spill179, align 32
  %.spill.load1267 = load <8 x float>, ptr %.spill156, align 32
  %.state1268 = load <8 x float>, ptr %.slot167, align 32
  %6821 = fadd <8 x float> %.spill.load1267, %.state1268
  %6822 = load <8 x float>, ptr %.spill180, align 32
  %6823 = select <8 x i1> %convergence.cascade.result1262, <8 x float> %6821, <8 x float> %6822
  store <8 x float> %6823, ptr %.spill180, align 32
  %.spill.load1269 = load <8 x float>, ptr %.spill157, align 32
  %.state1270 = load <8 x float>, ptr %.slot169, align 32
  %6824 = fadd <8 x float> %.spill.load1269, %.state1270
  %6825 = load <8 x float>, ptr %.spill181, align 32
  %6826 = select <8 x i1> %convergence.cascade.result1262, <8 x float> %6824, <8 x float> %6825
  store <8 x float> %6826, ptr %.spill181, align 32
  %.spill.load1271 = load <8 x float>, ptr %.spill158, align 32
  %.state1272 = load <8 x float>, ptr %.slot171, align 32
  %6827 = fadd <8 x float> %.spill.load1271, %.state1272
  %6828 = load <8 x float>, ptr %.spill182, align 32
  %6829 = select <8 x i1> %convergence.cascade.result1262, <8 x float> %6827, <8 x float> %6828
  store <8 x float> %6829, ptr %.spill182, align 32
  %.spill.load1273 = load <8 x float>, ptr %.spill159, align 32
  %.state1274 = load <8 x float>, ptr %.slot173, align 32
  %6830 = fadd <8 x float> %.spill.load1273, %.state1274
  %6831 = load <8 x float>, ptr %.spill183, align 32
  %6832 = select <8 x i1> %convergence.cascade.result1262, <8 x float> %6830, <8 x float> %6831
  store <8 x float> %6832, ptr %.spill183, align 32
  %.spill.load1275 = load <8 x float>, ptr %.spill160, align 32
  %.state1276 = load <8 x float>, ptr %.slot175, align 32
  %6833 = fadd <8 x float> %.spill.load1275, %.state1276
  %6834 = load <8 x float>, ptr %.spill184, align 32
  %6835 = select <8 x i1> %convergence.cascade.result1262, <8 x float> %6833, <8 x float> %6834
  store <8 x float> %6835, ptr %.spill184, align 32
  %.spill.load1277 = load <8 x float>, ptr %.spill161, align 32
  %.state1278 = load <8 x float>, ptr %.slot177, align 32
  %6836 = fadd <8 x float> %.spill.load1277, %.state1278
  %6837 = load <8 x float>, ptr %.spill185, align 32
  %6838 = select <8 x i1> %convergence.cascade.result1262, <8 x float> %6836, <8 x float> %6837
  store <8 x float> %6838, ptr %.spill185, align 32
  %6839 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill186, align 64
  %6840 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %6841 = extractvalue { <8 x ptr>, <8 x i64> } %6839, 0
  %6842 = select <8 x i1> %convergence.cascade.result1262, <8 x ptr> %6840, <8 x ptr> %6841
  %6843 = extractvalue { <8 x ptr>, <8 x i64> } %44, 1
  %6844 = extractvalue { <8 x ptr>, <8 x i64> } %6839, 1
  %6845 = select <8 x i1> %convergence.cascade.result1262, <8 x i64> %6843, <8 x i64> %6844
  %6846 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6842, 0
  %6847 = insertvalue { <8 x ptr>, <8 x i64> } %6846, <8 x i64> %6845, 1
  store { <8 x ptr>, <8 x i64> } %6847, ptr %tile_snapshot.spill186, align 64
  %6848 = load <8 x i64>, ptr %.slot187, align 64
  %6849 = select <8 x i1> %convergence.cascade.result1262, <8 x i64> zeroinitializer, <8 x i64> %6848
  store <8 x i64> %6849, ptr %.slot187, align 64
  store <8 x i1> %convergence.cascade.result1262, ptr %current.mask, align 1
  %6850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1262)
  br i1 %6850, label %schedule.87, label %scheduler.loop

varying.divergent1280:                            ; preds = %schedule.87
  %6851 = load i32, ptr %current.token, align 4
  %6852 = icmp ne i32 %6851, 0
  %6853 = sub i32 %6851, 1
  %6854 = select i1 %6852, i32 %6853, i32 0
  %6855 = load i8, ptr %frame.active, align 1
  %6856 = trunc i32 %6854 to i8
  %6857 = shl i8 1, %6856
  %6858 = and i8 %6855, %6857
  %6859 = icmp ne i8 %6858, 0
  %6860 = load <8 x i32>, ptr %frame.static.id, align 32
  %6861 = extractelement <8 x i32> %6860, i32 %6854
  %6862 = icmp eq i32 %6861, 30
  %6863 = and i1 %6859, %6862
  %6864 = and i1 %6852, %6863
  %6865 = xor i1 %6864, true
  %6866 = and i1 true, %6865
  %6867 = xor i8 %6855, -1
  %6868 = icmp ne i8 %6867, 0
  %6869 = xor i1 %6868, true
  %6870 = and i1 %6866, %6869
  br i1 %6870, label %convergence.overflow.trap1282, label %convergence.overflow.resume1283

varying.coherent1281:                             ; preds = %schedule.87
  br i1 %1537, label %varying.coherent.true1286, label %varying.coherent.false1287

convergence.overflow.trap1282:                    ; preds = %varying.divergent1280
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1283:                  ; preds = %varying.divergent1280
  %6871 = call i8 @llvm.cttz.i8(i8 %6867, i1 false)
  %6872 = zext i8 %6871 to i32
  %6873 = select i1 %6868, i32 %6872, i32 0
  %6874 = trunc i32 %6873 to i8
  %6875 = shl i8 1, %6874
  %6876 = or i8 %6855, %6875
  %6877 = select i1 %6866, i8 %6876, i8 %6855
  store i8 %6877, ptr %frame.active, align 1
  %6878 = load <8 x i32>, ptr %frame.static.id, align 32
  %6879 = extractelement <8 x i32> %6878, i32 %6873
  %6880 = select i1 %6866, i32 30, i32 %6879
  %6881 = load <8 x i32>, ptr %frame.static.id, align 32
  %6882 = insertelement <8 x i32> %6881, i32 %6880, i32 %6873
  store <8 x i32> %6882, ptr %frame.static.id, align 32
  %6883 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6884 = extractelement <8 x i32> %6883, i32 %6873
  %6885 = select i1 %6866, i32 %6851, i32 %6884
  %6886 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6887 = insertelement <8 x i32> %6886, i32 %6885, i32 %6873
  store <8 x i32> %6887, ptr %frame.parent.token, align 32
  %6888 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6873
  %6889 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6873
  %6890 = load <8 x i1>, ptr %6888, align 1
  %6891 = load <8 x i1>, ptr %6889, align 1
  %6892 = select i1 %6866, <8 x i1> %1527, <8 x i1> %6890
  store <8 x i1> %6892, ptr %6888, align 1
  %6893 = select i1 %6866, <8 x i1> zeroinitializer, <8 x i1> %6891
  store <8 x i1> %6893, ptr %6889, align 1
  %6894 = add i32 %6873, 1
  %6895 = select i1 %6864, i32 %6851, i32 %6894
  %6896 = select i1 true, i32 %6895, i32 %6851
  store i32 %6896, ptr %current.token, align 4
  %6897 = load i32, ptr %current.token, align 4
  %6898 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1534)
  %6899 = load i32, ptr %ready.count, align 4
  %6900 = icmp uge i32 %6899, 8
  %6901 = and i1 %6898, %6900
  br i1 %6901, label %ready.overflow.trap1284, label %ready.overflow.resume1285

ready.overflow.trap1284:                          ; preds = %convergence.overflow.resume1283
  call void @llvm.trap()
  unreachable

ready.overflow.resume1285:                        ; preds = %convergence.overflow.resume1283
  %6902 = select i1 %6898, i32 %6899, i32 0
  %6903 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6902
  %6904 = load <8 x i1>, ptr %6903, align 1
  %6905 = select i1 %6898, <8 x i1> %1534, <8 x i1> %6904
  store <8 x i1> %6905, ptr %6903, align 1
  %6906 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6902
  %6907 = load i32, ptr %6906, align 4
  %6908 = select i1 %6898, i32 88, i32 %6907
  store i32 %6908, ptr %6906, align 4
  %6909 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6902
  %6910 = load i32, ptr %6909, align 4
  %6911 = select i1 %6898, i32 %6897, i32 %6910
  store i32 %6911, ptr %6909, align 4
  %6912 = add i32 %6899, 1
  %6913 = select i1 %6898, i32 %6912, i32 %6899
  store i32 %6913, ptr %ready.count, align 4
  %6914 = load <8 x i1>, ptr %runnable.mask, align 1
  %6915 = or <8 x i1> %6914, %1534
  store <8 x i1> %6915, ptr %runnable.mask, align 1
  store <8 x i1> %1536, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1286:                        ; preds = %varying.coherent1281
  store <8 x i1> %1527, ptr %current.mask, align 1
  %6916 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1527)
  br i1 %6916, label %schedule.88, label %scheduler.loop

varying.coherent.false1287:                       ; preds = %varying.coherent1281
  store <8 x i1> %1527, ptr %current.mask, align 1
  %6917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1527)
  br i1 %6917, label %schedule.95, label %scheduler.loop

varying.divergent1289:                            ; preds = %schedule.89
  %6918 = load i32, ptr %current.token, align 4
  %6919 = icmp ne i32 %6918, 0
  %6920 = sub i32 %6918, 1
  %6921 = select i1 %6919, i32 %6920, i32 0
  %6922 = load i8, ptr %frame.active, align 1
  %6923 = trunc i32 %6921 to i8
  %6924 = shl i8 1, %6923
  %6925 = and i8 %6922, %6924
  %6926 = icmp ne i8 %6925, 0
  %6927 = load <8 x i32>, ptr %frame.static.id, align 32
  %6928 = extractelement <8 x i32> %6927, i32 %6921
  %6929 = icmp eq i32 %6928, 31
  %6930 = and i1 %6926, %6929
  %6931 = and i1 %6919, %6930
  %6932 = xor i1 %6931, true
  %6933 = and i1 true, %6932
  %6934 = xor i8 %6922, -1
  %6935 = icmp ne i8 %6934, 0
  %6936 = xor i1 %6935, true
  %6937 = and i1 %6933, %6936
  br i1 %6937, label %convergence.overflow.trap1291, label %convergence.overflow.resume1292

varying.coherent1290:                             ; preds = %schedule.89
  br i1 %1559, label %varying.coherent.true1295, label %varying.coherent.false1296

convergence.overflow.trap1291:                    ; preds = %varying.divergent1289
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1292:                  ; preds = %varying.divergent1289
  %6938 = call i8 @llvm.cttz.i8(i8 %6934, i1 false)
  %6939 = zext i8 %6938 to i32
  %6940 = select i1 %6935, i32 %6939, i32 0
  %6941 = trunc i32 %6940 to i8
  %6942 = shl i8 1, %6941
  %6943 = or i8 %6922, %6942
  %6944 = select i1 %6933, i8 %6943, i8 %6922
  store i8 %6944, ptr %frame.active, align 1
  %6945 = load <8 x i32>, ptr %frame.static.id, align 32
  %6946 = extractelement <8 x i32> %6945, i32 %6940
  %6947 = select i1 %6933, i32 31, i32 %6946
  %6948 = load <8 x i32>, ptr %frame.static.id, align 32
  %6949 = insertelement <8 x i32> %6948, i32 %6947, i32 %6940
  store <8 x i32> %6949, ptr %frame.static.id, align 32
  %6950 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6951 = extractelement <8 x i32> %6950, i32 %6940
  %6952 = select i1 %6933, i32 %6918, i32 %6951
  %6953 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6954 = insertelement <8 x i32> %6953, i32 %6952, i32 %6940
  store <8 x i32> %6954, ptr %frame.parent.token, align 32
  %6955 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6940
  %6956 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6940
  %6957 = load <8 x i1>, ptr %6955, align 1
  %6958 = load <8 x i1>, ptr %6956, align 1
  %6959 = select i1 %6933, <8 x i1> %1549, <8 x i1> %6957
  store <8 x i1> %6959, ptr %6955, align 1
  %6960 = select i1 %6933, <8 x i1> zeroinitializer, <8 x i1> %6958
  store <8 x i1> %6960, ptr %6956, align 1
  %6961 = add i32 %6940, 1
  %6962 = select i1 %6931, i32 %6918, i32 %6961
  %6963 = select i1 true, i32 %6962, i32 %6918
  store i32 %6963, ptr %current.token, align 4
  %6964 = load i32, ptr %current.token, align 4
  %6965 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1556)
  %6966 = load i32, ptr %ready.count, align 4
  %6967 = icmp uge i32 %6966, 8
  %6968 = and i1 %6965, %6967
  br i1 %6968, label %ready.overflow.trap1293, label %ready.overflow.resume1294

ready.overflow.trap1293:                          ; preds = %convergence.overflow.resume1292
  call void @llvm.trap()
  unreachable

ready.overflow.resume1294:                        ; preds = %convergence.overflow.resume1292
  %6969 = select i1 %6965, i32 %6966, i32 0
  %6970 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6969
  %6971 = load <8 x i1>, ptr %6970, align 1
  %6972 = select i1 %6965, <8 x i1> %1556, <8 x i1> %6971
  store <8 x i1> %6972, ptr %6970, align 1
  %6973 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6969
  %6974 = load i32, ptr %6973, align 4
  %6975 = select i1 %6965, i32 90, i32 %6974
  store i32 %6975, ptr %6973, align 4
  %6976 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6969
  %6977 = load i32, ptr %6976, align 4
  %6978 = select i1 %6965, i32 %6964, i32 %6977
  store i32 %6978, ptr %6976, align 4
  %6979 = add i32 %6966, 1
  %6980 = select i1 %6965, i32 %6979, i32 %6966
  store i32 %6980, ptr %ready.count, align 4
  %6981 = load <8 x i1>, ptr %runnable.mask, align 1
  %6982 = or <8 x i1> %6981, %1556
  store <8 x i1> %6982, ptr %runnable.mask, align 1
  store <8 x i1> %1558, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1295:                        ; preds = %varying.coherent1290
  store <8 x i1> %1549, ptr %current.mask, align 1
  %6983 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1549)
  br i1 %6983, label %schedule.90, label %scheduler.loop

varying.coherent.false1296:                       ; preds = %varying.coherent1290
  store <8 x i1> %1549, ptr %current.mask, align 1
  %6984 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1549)
  br i1 %6984, label %schedule.94, label %scheduler.loop

varying.divergent1308:                            ; preds = %schedule.91
  %6985 = load i32, ptr %current.token, align 4
  %6986 = icmp ne i32 %6985, 0
  %6987 = sub i32 %6985, 1
  %6988 = select i1 %6986, i32 %6987, i32 0
  %6989 = load i8, ptr %frame.active, align 1
  %6990 = trunc i32 %6988 to i8
  %6991 = shl i8 1, %6990
  %6992 = and i8 %6989, %6991
  %6993 = icmp ne i8 %6992, 0
  %6994 = load <8 x i32>, ptr %frame.static.id, align 32
  %6995 = extractelement <8 x i32> %6994, i32 %6988
  %6996 = icmp eq i32 %6995, 32
  %6997 = and i1 %6993, %6996
  %6998 = and i1 %6986, %6997
  %6999 = xor i1 %6998, true
  %7000 = and i1 true, %6999
  %7001 = xor i8 %6989, -1
  %7002 = icmp ne i8 %7001, 0
  %7003 = xor i1 %7002, true
  %7004 = and i1 %7000, %7003
  br i1 %7004, label %convergence.overflow.trap1310, label %convergence.overflow.resume1311

varying.coherent1309:                             ; preds = %schedule.91
  br i1 %1734, label %varying.coherent.true1314, label %varying.coherent.false1315

convergence.overflow.trap1310:                    ; preds = %varying.divergent1308
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1311:                  ; preds = %varying.divergent1308
  %7005 = call i8 @llvm.cttz.i8(i8 %7001, i1 false)
  %7006 = zext i8 %7005 to i32
  %7007 = select i1 %7002, i32 %7006, i32 0
  %7008 = trunc i32 %7007 to i8
  %7009 = shl i8 1, %7008
  %7010 = or i8 %6989, %7009
  %7011 = select i1 %7000, i8 %7010, i8 %6989
  store i8 %7011, ptr %frame.active, align 1
  %7012 = load <8 x i32>, ptr %frame.static.id, align 32
  %7013 = extractelement <8 x i32> %7012, i32 %7007
  %7014 = select i1 %7000, i32 32, i32 %7013
  %7015 = load <8 x i32>, ptr %frame.static.id, align 32
  %7016 = insertelement <8 x i32> %7015, i32 %7014, i32 %7007
  store <8 x i32> %7016, ptr %frame.static.id, align 32
  %7017 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7018 = extractelement <8 x i32> %7017, i32 %7007
  %7019 = select i1 %7000, i32 %6985, i32 %7018
  %7020 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7021 = insertelement <8 x i32> %7020, i32 %7019, i32 %7007
  store <8 x i32> %7021, ptr %frame.parent.token, align 32
  %7022 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7007
  %7023 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7007
  %7024 = load <8 x i1>, ptr %7022, align 1
  %7025 = load <8 x i1>, ptr %7023, align 1
  %7026 = select i1 %7000, <8 x i1> %1724, <8 x i1> %7024
  store <8 x i1> %7026, ptr %7022, align 1
  %7027 = select i1 %7000, <8 x i1> zeroinitializer, <8 x i1> %7025
  store <8 x i1> %7027, ptr %7023, align 1
  %7028 = add i32 %7007, 1
  %7029 = select i1 %6998, i32 %6985, i32 %7028
  %7030 = select i1 true, i32 %7029, i32 %6985
  store i32 %7030, ptr %current.token, align 4
  %7031 = load i32, ptr %current.token, align 4
  %7032 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1731)
  %7033 = load i32, ptr %ready.count, align 4
  %7034 = icmp uge i32 %7033, 8
  %7035 = and i1 %7032, %7034
  br i1 %7035, label %ready.overflow.trap1312, label %ready.overflow.resume1313

ready.overflow.trap1312:                          ; preds = %convergence.overflow.resume1311
  call void @llvm.trap()
  unreachable

ready.overflow.resume1313:                        ; preds = %convergence.overflow.resume1311
  %7036 = select i1 %7032, i32 %7033, i32 0
  %7037 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7036
  %7038 = load <8 x i1>, ptr %7037, align 1
  %7039 = select i1 %7032, <8 x i1> %1731, <8 x i1> %7038
  store <8 x i1> %7039, ptr %7037, align 1
  %7040 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7036
  %7041 = load i32, ptr %7040, align 4
  %7042 = select i1 %7032, i32 92, i32 %7041
  store i32 %7042, ptr %7040, align 4
  %7043 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7036
  %7044 = load i32, ptr %7043, align 4
  %7045 = select i1 %7032, i32 %7031, i32 %7044
  store i32 %7045, ptr %7043, align 4
  %7046 = add i32 %7033, 1
  %7047 = select i1 %7032, i32 %7046, i32 %7033
  store i32 %7047, ptr %ready.count, align 4
  %7048 = load <8 x i1>, ptr %runnable.mask, align 1
  %7049 = or <8 x i1> %7048, %1731
  store <8 x i1> %7049, ptr %runnable.mask, align 1
  store <8 x i1> %1733, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1314:                        ; preds = %varying.coherent1309
  store <8 x i1> %1724, ptr %current.mask, align 1
  %7050 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1724)
  br i1 %7050, label %schedule.92, label %scheduler.loop

varying.coherent.false1315:                       ; preds = %varying.coherent1309
  store <8 x i1> %1724, ptr %current.mask, align 1
  %7051 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1724)
  br i1 %7051, label %schedule.93, label %scheduler.loop

convergence.cascade1333:                          ; preds = %convergence.cascade1333, %schedule.93
  %convergence.cascade.flow1337 = phi <8 x i1> [ %1821, %schedule.93 ], [ %7094, %convergence.cascade1333 ]
  %convergence.cascade.depth1338 = phi i32 [ 0, %schedule.93 ], [ %7095, %convergence.cascade1333 ]
  %7052 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1337)
  %7053 = load i32, ptr %current.token, align 4
  %7054 = icmp ne i32 %7053, 0
  %7055 = and i1 %7052, %7054
  %7056 = sub i32 %7053, 1
  %7057 = select i1 %7055, i32 %7056, i32 0
  %7058 = load i8, ptr %frame.active, align 1
  %7059 = trunc i32 %7057 to i8
  %7060 = shl i8 1, %7059
  %7061 = and i8 %7058, %7060
  %7062 = icmp ne i8 %7061, 0
  %7063 = load <8 x i32>, ptr %frame.static.id, align 32
  %7064 = extractelement <8 x i32> %7063, i32 %7057
  %convergence.target.pointer1339 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7064
  %convergence.dynamic.target1340 = load i32, ptr %convergence.target.pointer1339, align 4
  %7065 = icmp eq i32 %convergence.dynamic.target1340, 93
  %7066 = and i1 %7062, %7065
  %7067 = and i1 %7055, %7066
  %7068 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7057
  %7069 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7057
  %7070 = load <8 x i1>, ptr %7068, align 1
  %7071 = load <8 x i1>, ptr %7069, align 1
  %7072 = or <8 x i1> %7071, %convergence.cascade.flow1337
  %7073 = load <8 x i1>, ptr %live.mask, align 1
  %7074 = and <8 x i1> %7070, %7073
  %7075 = icmp eq <8 x i1> %7072, %7074
  %7076 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7075)
  %7077 = and i1 %7067, %7076
  %7078 = select i1 %7077, <8 x i1> zeroinitializer, <8 x i1> %7072
  %7079 = select i1 %7067, <8 x i1> %7078, <8 x i1> %7071
  store <8 x i1> %7079, ptr %7069, align 1
  %7080 = select i1 %7077, <8 x i1> zeroinitializer, <8 x i1> %7070
  store <8 x i1> %7080, ptr %7068, align 1
  %7081 = trunc i32 %7057 to i8
  %7082 = shl i8 1, %7081
  %7083 = xor i8 %7082, -1
  %7084 = and i8 %7058, %7083
  %7085 = select i1 %7077, i8 %7084, i8 %7058
  store i8 %7085, ptr %frame.active, align 1
  %.splatinsert1341 = insertelement <8 x i1> poison, i1 %7067, i64 0
  %.splat1342 = shufflevector <8 x i1> %.splatinsert1341, <8 x i1> poison, <8 x i32> zeroinitializer
  %7086 = and <8 x i1> %convergence.cascade.flow1337, %.splat1342
  %7087 = load <8 x i1>, ptr %runnable.mask, align 1
  %7088 = xor <8 x i1> %7086, splat (i1 true)
  %7089 = and <8 x i1> %7087, %7088
  store <8 x i1> %7089, ptr %runnable.mask, align 1
  %.splatinsert1343 = insertelement <8 x i1> poison, i1 %7077, i64 0
  %.splat1344 = shufflevector <8 x i1> %.splatinsert1343, <8 x i1> poison, <8 x i32> zeroinitializer
  %7090 = select <8 x i1> %.splat1344, <8 x i1> %7072, <8 x i1> zeroinitializer
  %7091 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7092 = extractelement <8 x i32> %7091, i32 %7057
  %7093 = select i1 %7077, i32 %7092, i32 %7053
  store i32 %7093, ptr %current.token, align 4
  %.splatinsert1345 = insertelement <8 x i1> poison, i1 %7067, i64 0
  %.splat1346 = shufflevector <8 x i1> %.splatinsert1345, <8 x i1> poison, <8 x i32> zeroinitializer
  %7094 = select <8 x i1> %.splat1346, <8 x i1> %7090, <8 x i1> %convergence.cascade.flow1337
  %7095 = add i32 %convergence.cascade.depth1338, 1
  %7096 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7094)
  %7097 = icmp ult i32 %7095, 8
  %7098 = and i1 %7096, %7097
  %7099 = and i1 %7067, %7098
  %convergence.parent.token1347 = load i32, ptr %current.token, align 4
  %convergence.parent.present1348 = icmp ne i32 %convergence.parent.token1347, 0
  %7100 = and i1 %7099, %convergence.parent.present1348
  br i1 %7100, label %convergence.cascade1333, label %convergence.cascade.exit1334

convergence.cascade.exit1334:                     ; preds = %convergence.cascade1333, %schedule.93
  %convergence.cascade.result1349 = phi <8 x i1> [ %1821, %schedule.93 ], [ %7094, %convergence.cascade1333 ]
  %7101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1349)
  br i1 %7101, label %convergence.target.93.ready, label %scheduler.loop

convergence.target.93.ready:                      ; preds = %convergence.cascade.exit1334
  %7102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1349)
  %7103 = bitcast <8 x i1> %convergence.cascade.result1349 to i8
  %7104 = call i8 @llvm.cttz.i8(i8 %7103, i1 false)
  %7105 = zext i8 %7104 to i32
  %7106 = select i1 %7102, i32 %7105, i32 0
  %tile_snapshot.spill.load1350 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill186, align 64
  %7107 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1350, 0
  %7108 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1350, 1
  %.spill.load1351 = load <8 x i64>, ptr %.spill189, align 64
  %7109 = mul <8 x i64> %.spill.load1351, splat (i64 32)
  %7110 = add <8 x i64> %7108, %7109
  %7111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7107, 0
  %7112 = insertvalue { <8 x ptr>, <8 x i64> } %7111, <8 x i64> %7110, 1
  %.state1352 = load <8 x float>, ptr %.slot199, align 32
  %7113 = extractvalue { <8 x ptr>, <8 x i64> } %7112, 0
  %7114 = extractvalue { <8 x ptr>, <8 x i64> } %7112, 1
  %7115 = getelementptr i8, <8 x ptr> %7113, <8 x i64> %7114
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1352, <8 x ptr> align 1 %7115, <8 x i1> %convergence.cascade.result1349)
  %tile_snapshot.spill.load1353 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill186, align 64
  %7116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1353, 0
  %7117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1353, 1
  %.spill.load1354 = load <8 x i64>, ptr %.spill192, align 64
  %7118 = mul <8 x i64> %.spill.load1354, splat (i64 32)
  %7119 = add <8 x i64> %7117, %7118
  %7120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7116, 0
  %7121 = insertvalue { <8 x ptr>, <8 x i64> } %7120, <8 x i64> %7119, 1
  %.state1355 = load <8 x float>, ptr %.slot200, align 32
  %7122 = extractvalue { <8 x ptr>, <8 x i64> } %7121, 0
  %7123 = extractvalue { <8 x ptr>, <8 x i64> } %7121, 1
  %7124 = getelementptr i8, <8 x ptr> %7122, <8 x i64> %7123
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1355, <8 x ptr> align 1 %7124, <8 x i1> %convergence.cascade.result1349)
  %tile_snapshot.spill.load1356 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill186, align 64
  %7125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1356, 0
  %7126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1356, 1
  %.spill.load1357 = load <8 x i64>, ptr %.spill194, align 64
  %7127 = mul <8 x i64> %.spill.load1357, splat (i64 32)
  %7128 = add <8 x i64> %7126, %7127
  %7129 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7125, 0
  %7130 = insertvalue { <8 x ptr>, <8 x i64> } %7129, <8 x i64> %7128, 1
  %.state1358 = load <8 x float>, ptr %.slot201, align 32
  %7131 = extractvalue { <8 x ptr>, <8 x i64> } %7130, 0
  %7132 = extractvalue { <8 x ptr>, <8 x i64> } %7130, 1
  %7133 = getelementptr i8, <8 x ptr> %7131, <8 x i64> %7132
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1358, <8 x ptr> align 1 %7133, <8 x i1> %convergence.cascade.result1349)
  %tile_snapshot.spill.load1359 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill186, align 64
  %7134 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1359, 0
  %7135 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1359, 1
  %.spill.load1360 = load <8 x i64>, ptr %.spill196, align 64
  %7136 = mul <8 x i64> %.spill.load1360, splat (i64 32)
  %7137 = add <8 x i64> %7135, %7136
  %7138 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7134, 0
  %7139 = insertvalue { <8 x ptr>, <8 x i64> } %7138, <8 x i64> %7137, 1
  %.state1361 = load <8 x float>, ptr %.slot202, align 32
  %7140 = extractvalue { <8 x ptr>, <8 x i64> } %7139, 0
  %7141 = extractvalue { <8 x ptr>, <8 x i64> } %7139, 1
  %7142 = getelementptr i8, <8 x ptr> %7140, <8 x i64> %7141
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1361, <8 x ptr> align 1 %7142, <8 x i1> %convergence.cascade.result1349)
  %.state1362 = load <8 x i64>, ptr %.slot188, align 64
  %7143 = add <8 x i64> %.state1362, splat (i64 1)
  %7144 = load <8 x i64>, ptr %.slot188, align 64
  %7145 = select <8 x i1> %convergence.cascade.result1349, <8 x i64> %7143, <8 x i64> %7144
  store <8 x i64> %7145, ptr %.slot188, align 64
  store <8 x i1> %convergence.cascade.result1349, ptr %current.mask, align 1
  %7146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1349)
  br i1 %7146, label %schedule.89, label %scheduler.loop

convergence.cascade1363:                          ; preds = %convergence.cascade1363, %schedule.94
  %convergence.cascade.flow1367 = phi <8 x i1> [ %1822, %schedule.94 ], [ %7189, %convergence.cascade1363 ]
  %convergence.cascade.depth1368 = phi i32 [ 0, %schedule.94 ], [ %7190, %convergence.cascade1363 ]
  %7147 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1367)
  %7148 = load i32, ptr %current.token, align 4
  %7149 = icmp ne i32 %7148, 0
  %7150 = and i1 %7147, %7149
  %7151 = sub i32 %7148, 1
  %7152 = select i1 %7150, i32 %7151, i32 0
  %7153 = load i8, ptr %frame.active, align 1
  %7154 = trunc i32 %7152 to i8
  %7155 = shl i8 1, %7154
  %7156 = and i8 %7153, %7155
  %7157 = icmp ne i8 %7156, 0
  %7158 = load <8 x i32>, ptr %frame.static.id, align 32
  %7159 = extractelement <8 x i32> %7158, i32 %7152
  %convergence.target.pointer1369 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7159
  %convergence.dynamic.target1370 = load i32, ptr %convergence.target.pointer1369, align 4
  %7160 = icmp eq i32 %convergence.dynamic.target1370, 94
  %7161 = and i1 %7157, %7160
  %7162 = and i1 %7150, %7161
  %7163 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7152
  %7164 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7152
  %7165 = load <8 x i1>, ptr %7163, align 1
  %7166 = load <8 x i1>, ptr %7164, align 1
  %7167 = or <8 x i1> %7166, %convergence.cascade.flow1367
  %7168 = load <8 x i1>, ptr %live.mask, align 1
  %7169 = and <8 x i1> %7165, %7168
  %7170 = icmp eq <8 x i1> %7167, %7169
  %7171 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7170)
  %7172 = and i1 %7162, %7171
  %7173 = select i1 %7172, <8 x i1> zeroinitializer, <8 x i1> %7167
  %7174 = select i1 %7162, <8 x i1> %7173, <8 x i1> %7166
  store <8 x i1> %7174, ptr %7164, align 1
  %7175 = select i1 %7172, <8 x i1> zeroinitializer, <8 x i1> %7165
  store <8 x i1> %7175, ptr %7163, align 1
  %7176 = trunc i32 %7152 to i8
  %7177 = shl i8 1, %7176
  %7178 = xor i8 %7177, -1
  %7179 = and i8 %7153, %7178
  %7180 = select i1 %7172, i8 %7179, i8 %7153
  store i8 %7180, ptr %frame.active, align 1
  %.splatinsert1371 = insertelement <8 x i1> poison, i1 %7162, i64 0
  %.splat1372 = shufflevector <8 x i1> %.splatinsert1371, <8 x i1> poison, <8 x i32> zeroinitializer
  %7181 = and <8 x i1> %convergence.cascade.flow1367, %.splat1372
  %7182 = load <8 x i1>, ptr %runnable.mask, align 1
  %7183 = xor <8 x i1> %7181, splat (i1 true)
  %7184 = and <8 x i1> %7182, %7183
  store <8 x i1> %7184, ptr %runnable.mask, align 1
  %.splatinsert1373 = insertelement <8 x i1> poison, i1 %7172, i64 0
  %.splat1374 = shufflevector <8 x i1> %.splatinsert1373, <8 x i1> poison, <8 x i32> zeroinitializer
  %7185 = select <8 x i1> %.splat1374, <8 x i1> %7167, <8 x i1> zeroinitializer
  %7186 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7187 = extractelement <8 x i32> %7186, i32 %7152
  %7188 = select i1 %7172, i32 %7187, i32 %7148
  store i32 %7188, ptr %current.token, align 4
  %.splatinsert1375 = insertelement <8 x i1> poison, i1 %7162, i64 0
  %.splat1376 = shufflevector <8 x i1> %.splatinsert1375, <8 x i1> poison, <8 x i32> zeroinitializer
  %7189 = select <8 x i1> %.splat1376, <8 x i1> %7185, <8 x i1> %convergence.cascade.flow1367
  %7190 = add i32 %convergence.cascade.depth1368, 1
  %7191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7189)
  %7192 = icmp ult i32 %7190, 8
  %7193 = and i1 %7191, %7192
  %7194 = and i1 %7162, %7193
  %convergence.parent.token1377 = load i32, ptr %current.token, align 4
  %convergence.parent.present1378 = icmp ne i32 %convergence.parent.token1377, 0
  %7195 = and i1 %7194, %convergence.parent.present1378
  br i1 %7195, label %convergence.cascade1363, label %convergence.cascade.exit1364

convergence.cascade.exit1364:                     ; preds = %convergence.cascade1363, %schedule.94
  %convergence.cascade.result1379 = phi <8 x i1> [ %1822, %schedule.94 ], [ %7189, %convergence.cascade1363 ]
  %7196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1379)
  br i1 %7196, label %convergence.target.94.ready, label %scheduler.loop

convergence.target.94.ready:                      ; preds = %convergence.cascade.exit1364
  %7197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1379)
  %7198 = bitcast <8 x i1> %convergence.cascade.result1379 to i8
  %7199 = call i8 @llvm.cttz.i8(i8 %7198, i1 false)
  %7200 = zext i8 %7199 to i32
  %7201 = select i1 %7197, i32 %7200, i32 0
  %.state1380 = load <8 x i64>, ptr %.slot187, align 64
  %7202 = add <8 x i64> %.state1380, splat (i64 1)
  %7203 = load <8 x i64>, ptr %.slot187, align 64
  %7204 = select <8 x i1> %convergence.cascade.result1379, <8 x i64> %7202, <8 x i64> %7203
  store <8 x i64> %7204, ptr %.slot187, align 64
  store <8 x i1> %convergence.cascade.result1379, ptr %current.mask, align 1
  %7205 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1379)
  br i1 %7205, label %schedule.87, label %scheduler.loop

convergence.cascade1381:                          ; preds = %convergence.cascade1381, %schedule.95
  %convergence.cascade.flow1385 = phi <8 x i1> [ %1823, %schedule.95 ], [ %7248, %convergence.cascade1381 ]
  %convergence.cascade.depth1386 = phi i32 [ 0, %schedule.95 ], [ %7249, %convergence.cascade1381 ]
  %7206 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1385)
  %7207 = load i32, ptr %current.token, align 4
  %7208 = icmp ne i32 %7207, 0
  %7209 = and i1 %7206, %7208
  %7210 = sub i32 %7207, 1
  %7211 = select i1 %7209, i32 %7210, i32 0
  %7212 = load i8, ptr %frame.active, align 1
  %7213 = trunc i32 %7211 to i8
  %7214 = shl i8 1, %7213
  %7215 = and i8 %7212, %7214
  %7216 = icmp ne i8 %7215, 0
  %7217 = load <8 x i32>, ptr %frame.static.id, align 32
  %7218 = extractelement <8 x i32> %7217, i32 %7211
  %convergence.target.pointer1387 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7218
  %convergence.dynamic.target1388 = load i32, ptr %convergence.target.pointer1387, align 4
  %7219 = icmp eq i32 %convergence.dynamic.target1388, 95
  %7220 = and i1 %7216, %7219
  %7221 = and i1 %7209, %7220
  %7222 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7211
  %7223 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7211
  %7224 = load <8 x i1>, ptr %7222, align 1
  %7225 = load <8 x i1>, ptr %7223, align 1
  %7226 = or <8 x i1> %7225, %convergence.cascade.flow1385
  %7227 = load <8 x i1>, ptr %live.mask, align 1
  %7228 = and <8 x i1> %7224, %7227
  %7229 = icmp eq <8 x i1> %7226, %7228
  %7230 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7229)
  %7231 = and i1 %7221, %7230
  %7232 = select i1 %7231, <8 x i1> zeroinitializer, <8 x i1> %7226
  %7233 = select i1 %7221, <8 x i1> %7232, <8 x i1> %7225
  store <8 x i1> %7233, ptr %7223, align 1
  %7234 = select i1 %7231, <8 x i1> zeroinitializer, <8 x i1> %7224
  store <8 x i1> %7234, ptr %7222, align 1
  %7235 = trunc i32 %7211 to i8
  %7236 = shl i8 1, %7235
  %7237 = xor i8 %7236, -1
  %7238 = and i8 %7212, %7237
  %7239 = select i1 %7231, i8 %7238, i8 %7212
  store i8 %7239, ptr %frame.active, align 1
  %.splatinsert1389 = insertelement <8 x i1> poison, i1 %7221, i64 0
  %.splat1390 = shufflevector <8 x i1> %.splatinsert1389, <8 x i1> poison, <8 x i32> zeroinitializer
  %7240 = and <8 x i1> %convergence.cascade.flow1385, %.splat1390
  %7241 = load <8 x i1>, ptr %runnable.mask, align 1
  %7242 = xor <8 x i1> %7240, splat (i1 true)
  %7243 = and <8 x i1> %7241, %7242
  store <8 x i1> %7243, ptr %runnable.mask, align 1
  %.splatinsert1391 = insertelement <8 x i1> poison, i1 %7231, i64 0
  %.splat1392 = shufflevector <8 x i1> %.splatinsert1391, <8 x i1> poison, <8 x i32> zeroinitializer
  %7244 = select <8 x i1> %.splat1392, <8 x i1> %7226, <8 x i1> zeroinitializer
  %7245 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7246 = extractelement <8 x i32> %7245, i32 %7211
  %7247 = select i1 %7231, i32 %7246, i32 %7207
  store i32 %7247, ptr %current.token, align 4
  %.splatinsert1393 = insertelement <8 x i1> poison, i1 %7221, i64 0
  %.splat1394 = shufflevector <8 x i1> %.splatinsert1393, <8 x i1> poison, <8 x i32> zeroinitializer
  %7248 = select <8 x i1> %.splat1394, <8 x i1> %7244, <8 x i1> %convergence.cascade.flow1385
  %7249 = add i32 %convergence.cascade.depth1386, 1
  %7250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7248)
  %7251 = icmp ult i32 %7249, 8
  %7252 = and i1 %7250, %7251
  %7253 = and i1 %7221, %7252
  %convergence.parent.token1395 = load i32, ptr %current.token, align 4
  %convergence.parent.present1396 = icmp ne i32 %convergence.parent.token1395, 0
  %7254 = and i1 %7253, %convergence.parent.present1396
  br i1 %7254, label %convergence.cascade1381, label %convergence.cascade.exit1382

convergence.cascade.exit1382:                     ; preds = %convergence.cascade1381, %schedule.95
  %convergence.cascade.result1397 = phi <8 x i1> [ %1823, %schedule.95 ], [ %7248, %convergence.cascade1381 ]
  %7255 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1397)
  br i1 %7255, label %convergence.target.95.ready, label %scheduler.loop

convergence.target.95.ready:                      ; preds = %convergence.cascade.exit1382
  %7256 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1397)
  %7257 = bitcast <8 x i1> %convergence.cascade.result1397 to i8
  %7258 = call i8 @llvm.cttz.i8(i8 %7257, i1 false)
  %7259 = zext i8 %7258 to i32
  %7260 = select i1 %7256, i32 %7259, i32 0
  %7261 = load <8 x i64>, ptr %.slot203, align 64
  %7262 = select <8 x i1> %convergence.cascade.result1397, <8 x i64> zeroinitializer, <8 x i64> %7261
  store <8 x i64> %7262, ptr %.slot203, align 64
  store <8 x i1> %convergence.cascade.result1397, ptr %current.mask, align 1
  %7263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1397)
  br i1 %7263, label %schedule.96, label %scheduler.loop

varying.divergent1399:                            ; preds = %schedule.96
  %7264 = load i32, ptr %current.token, align 4
  %7265 = icmp ne i32 %7264, 0
  %7266 = sub i32 %7264, 1
  %7267 = select i1 %7265, i32 %7266, i32 0
  %7268 = load i8, ptr %frame.active, align 1
  %7269 = trunc i32 %7267 to i8
  %7270 = shl i8 1, %7269
  %7271 = and i8 %7268, %7270
  %7272 = icmp ne i8 %7271, 0
  %7273 = load <8 x i32>, ptr %frame.static.id, align 32
  %7274 = extractelement <8 x i32> %7273, i32 %7267
  %7275 = icmp eq i32 %7274, 33
  %7276 = and i1 %7272, %7275
  %7277 = and i1 %7265, %7276
  %7278 = xor i1 %7277, true
  %7279 = and i1 true, %7278
  %7280 = xor i8 %7268, -1
  %7281 = icmp ne i8 %7280, 0
  %7282 = xor i1 %7281, true
  %7283 = and i1 %7279, %7282
  br i1 %7283, label %convergence.overflow.trap1401, label %convergence.overflow.resume1402

varying.coherent1400:                             ; preds = %schedule.96
  br i1 %1834, label %varying.coherent.true1405, label %varying.coherent.false1406

convergence.overflow.trap1401:                    ; preds = %varying.divergent1399
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1402:                  ; preds = %varying.divergent1399
  %7284 = call i8 @llvm.cttz.i8(i8 %7280, i1 false)
  %7285 = zext i8 %7284 to i32
  %7286 = select i1 %7281, i32 %7285, i32 0
  %7287 = trunc i32 %7286 to i8
  %7288 = shl i8 1, %7287
  %7289 = or i8 %7268, %7288
  %7290 = select i1 %7279, i8 %7289, i8 %7268
  store i8 %7290, ptr %frame.active, align 1
  %7291 = load <8 x i32>, ptr %frame.static.id, align 32
  %7292 = extractelement <8 x i32> %7291, i32 %7286
  %7293 = select i1 %7279, i32 33, i32 %7292
  %7294 = load <8 x i32>, ptr %frame.static.id, align 32
  %7295 = insertelement <8 x i32> %7294, i32 %7293, i32 %7286
  store <8 x i32> %7295, ptr %frame.static.id, align 32
  %7296 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7297 = extractelement <8 x i32> %7296, i32 %7286
  %7298 = select i1 %7279, i32 %7264, i32 %7297
  %7299 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7300 = insertelement <8 x i32> %7299, i32 %7298, i32 %7286
  store <8 x i32> %7300, ptr %frame.parent.token, align 32
  %7301 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7286
  %7302 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7286
  %7303 = load <8 x i1>, ptr %7301, align 1
  %7304 = load <8 x i1>, ptr %7302, align 1
  %7305 = select i1 %7279, <8 x i1> %1824, <8 x i1> %7303
  store <8 x i1> %7305, ptr %7301, align 1
  %7306 = select i1 %7279, <8 x i1> zeroinitializer, <8 x i1> %7304
  store <8 x i1> %7306, ptr %7302, align 1
  %7307 = add i32 %7286, 1
  %7308 = select i1 %7277, i32 %7264, i32 %7307
  %7309 = select i1 true, i32 %7308, i32 %7264
  store i32 %7309, ptr %current.token, align 4
  %7310 = load i32, ptr %current.token, align 4
  %7311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1831)
  %7312 = load i32, ptr %ready.count, align 4
  %7313 = icmp uge i32 %7312, 8
  %7314 = and i1 %7311, %7313
  br i1 %7314, label %ready.overflow.trap1403, label %ready.overflow.resume1404

ready.overflow.trap1403:                          ; preds = %convergence.overflow.resume1402
  call void @llvm.trap()
  unreachable

ready.overflow.resume1404:                        ; preds = %convergence.overflow.resume1402
  %7315 = select i1 %7311, i32 %7312, i32 0
  %7316 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7315
  %7317 = load <8 x i1>, ptr %7316, align 1
  %7318 = select i1 %7311, <8 x i1> %1831, <8 x i1> %7317
  store <8 x i1> %7318, ptr %7316, align 1
  %7319 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7315
  %7320 = load i32, ptr %7319, align 4
  %7321 = select i1 %7311, i32 97, i32 %7320
  store i32 %7321, ptr %7319, align 4
  %7322 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7315
  %7323 = load i32, ptr %7322, align 4
  %7324 = select i1 %7311, i32 %7310, i32 %7323
  store i32 %7324, ptr %7322, align 4
  %7325 = add i32 %7312, 1
  %7326 = select i1 %7311, i32 %7325, i32 %7312
  store i32 %7326, ptr %ready.count, align 4
  %7327 = load <8 x i1>, ptr %runnable.mask, align 1
  %7328 = or <8 x i1> %7327, %1831
  store <8 x i1> %7328, ptr %runnable.mask, align 1
  store <8 x i1> %1833, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1405:                        ; preds = %varying.coherent1400
  store <8 x i1> %1824, ptr %current.mask, align 1
  %7329 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1824)
  br i1 %7329, label %schedule.97, label %scheduler.loop

varying.coherent.false1406:                       ; preds = %varying.coherent1400
  store <8 x i1> %1824, ptr %current.mask, align 1
  %7330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1824)
  br i1 %7330, label %schedule.98, label %scheduler.loop

convergence.cascade1412:                          ; preds = %convergence.cascade1412, %schedule.98
  %convergence.cascade.flow1416 = phi <8 x i1> [ %1866, %schedule.98 ], [ %7373, %convergence.cascade1412 ]
  %convergence.cascade.depth1417 = phi i32 [ 0, %schedule.98 ], [ %7374, %convergence.cascade1412 ]
  %7331 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1416)
  %7332 = load i32, ptr %current.token, align 4
  %7333 = icmp ne i32 %7332, 0
  %7334 = and i1 %7331, %7333
  %7335 = sub i32 %7332, 1
  %7336 = select i1 %7334, i32 %7335, i32 0
  %7337 = load i8, ptr %frame.active, align 1
  %7338 = trunc i32 %7336 to i8
  %7339 = shl i8 1, %7338
  %7340 = and i8 %7337, %7339
  %7341 = icmp ne i8 %7340, 0
  %7342 = load <8 x i32>, ptr %frame.static.id, align 32
  %7343 = extractelement <8 x i32> %7342, i32 %7336
  %convergence.target.pointer1418 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7343
  %convergence.dynamic.target1419 = load i32, ptr %convergence.target.pointer1418, align 4
  %7344 = icmp eq i32 %convergence.dynamic.target1419, 98
  %7345 = and i1 %7341, %7344
  %7346 = and i1 %7334, %7345
  %7347 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7336
  %7348 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7336
  %7349 = load <8 x i1>, ptr %7347, align 1
  %7350 = load <8 x i1>, ptr %7348, align 1
  %7351 = or <8 x i1> %7350, %convergence.cascade.flow1416
  %7352 = load <8 x i1>, ptr %live.mask, align 1
  %7353 = and <8 x i1> %7349, %7352
  %7354 = icmp eq <8 x i1> %7351, %7353
  %7355 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7354)
  %7356 = and i1 %7346, %7355
  %7357 = select i1 %7356, <8 x i1> zeroinitializer, <8 x i1> %7351
  %7358 = select i1 %7346, <8 x i1> %7357, <8 x i1> %7350
  store <8 x i1> %7358, ptr %7348, align 1
  %7359 = select i1 %7356, <8 x i1> zeroinitializer, <8 x i1> %7349
  store <8 x i1> %7359, ptr %7347, align 1
  %7360 = trunc i32 %7336 to i8
  %7361 = shl i8 1, %7360
  %7362 = xor i8 %7361, -1
  %7363 = and i8 %7337, %7362
  %7364 = select i1 %7356, i8 %7363, i8 %7337
  store i8 %7364, ptr %frame.active, align 1
  %.splatinsert1420 = insertelement <8 x i1> poison, i1 %7346, i64 0
  %.splat1421 = shufflevector <8 x i1> %.splatinsert1420, <8 x i1> poison, <8 x i32> zeroinitializer
  %7365 = and <8 x i1> %convergence.cascade.flow1416, %.splat1421
  %7366 = load <8 x i1>, ptr %runnable.mask, align 1
  %7367 = xor <8 x i1> %7365, splat (i1 true)
  %7368 = and <8 x i1> %7366, %7367
  store <8 x i1> %7368, ptr %runnable.mask, align 1
  %.splatinsert1422 = insertelement <8 x i1> poison, i1 %7356, i64 0
  %.splat1423 = shufflevector <8 x i1> %.splatinsert1422, <8 x i1> poison, <8 x i32> zeroinitializer
  %7369 = select <8 x i1> %.splat1423, <8 x i1> %7351, <8 x i1> zeroinitializer
  %7370 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7371 = extractelement <8 x i32> %7370, i32 %7336
  %7372 = select i1 %7356, i32 %7371, i32 %7332
  store i32 %7372, ptr %current.token, align 4
  %.splatinsert1424 = insertelement <8 x i1> poison, i1 %7346, i64 0
  %.splat1425 = shufflevector <8 x i1> %.splatinsert1424, <8 x i1> poison, <8 x i32> zeroinitializer
  %7373 = select <8 x i1> %.splat1425, <8 x i1> %7369, <8 x i1> %convergence.cascade.flow1416
  %7374 = add i32 %convergence.cascade.depth1417, 1
  %7375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7373)
  %7376 = icmp ult i32 %7374, 8
  %7377 = and i1 %7375, %7376
  %7378 = and i1 %7346, %7377
  %convergence.parent.token1426 = load i32, ptr %current.token, align 4
  %convergence.parent.present1427 = icmp ne i32 %convergence.parent.token1426, 0
  %7379 = and i1 %7378, %convergence.parent.present1427
  br i1 %7379, label %convergence.cascade1412, label %convergence.cascade.exit1413

convergence.cascade.exit1413:                     ; preds = %convergence.cascade1412, %schedule.98
  %convergence.cascade.result1428 = phi <8 x i1> [ %1866, %schedule.98 ], [ %7373, %convergence.cascade1412 ]
  %7380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1428)
  br i1 %7380, label %convergence.target.98.ready, label %scheduler.loop

convergence.target.98.ready:                      ; preds = %convergence.cascade.exit1413
  %7381 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1428)
  %7382 = bitcast <8 x i1> %convergence.cascade.result1428 to i8
  %7383 = call i8 @llvm.cttz.i8(i8 %7382, i1 false)
  %7384 = zext i8 %7383 to i32
  %7385 = select i1 %7381, i32 %7384, i32 0
  %7386 = load <8 x i64>, ptr %.slot204, align 64
  %7387 = select <8 x i1> %convergence.cascade.result1428, <8 x i64> zeroinitializer, <8 x i64> %7386
  store <8 x i64> %7387, ptr %.slot204, align 64
  store <8 x i1> %convergence.cascade.result1428, ptr %current.mask, align 1
  %7388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1428)
  br i1 %7388, label %schedule.99, label %scheduler.loop

varying.divergent1430:                            ; preds = %schedule.99
  %7389 = load i32, ptr %current.token, align 4
  %7390 = icmp ne i32 %7389, 0
  %7391 = sub i32 %7389, 1
  %7392 = select i1 %7390, i32 %7391, i32 0
  %7393 = load i8, ptr %frame.active, align 1
  %7394 = trunc i32 %7392 to i8
  %7395 = shl i8 1, %7394
  %7396 = and i8 %7393, %7395
  %7397 = icmp ne i8 %7396, 0
  %7398 = load <8 x i32>, ptr %frame.static.id, align 32
  %7399 = extractelement <8 x i32> %7398, i32 %7392
  %7400 = icmp eq i32 %7399, 34
  %7401 = and i1 %7397, %7400
  %7402 = and i1 %7390, %7401
  %7403 = xor i1 %7402, true
  %7404 = and i1 true, %7403
  %7405 = xor i8 %7393, -1
  %7406 = icmp ne i8 %7405, 0
  %7407 = xor i1 %7406, true
  %7408 = and i1 %7404, %7407
  br i1 %7408, label %convergence.overflow.trap1432, label %convergence.overflow.resume1433

varying.coherent1431:                             ; preds = %schedule.99
  br i1 %1877, label %varying.coherent.true1436, label %varying.coherent.false1437

convergence.overflow.trap1432:                    ; preds = %varying.divergent1430
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1433:                  ; preds = %varying.divergent1430
  %7409 = call i8 @llvm.cttz.i8(i8 %7405, i1 false)
  %7410 = zext i8 %7409 to i32
  %7411 = select i1 %7406, i32 %7410, i32 0
  %7412 = trunc i32 %7411 to i8
  %7413 = shl i8 1, %7412
  %7414 = or i8 %7393, %7413
  %7415 = select i1 %7404, i8 %7414, i8 %7393
  store i8 %7415, ptr %frame.active, align 1
  %7416 = load <8 x i32>, ptr %frame.static.id, align 32
  %7417 = extractelement <8 x i32> %7416, i32 %7411
  %7418 = select i1 %7404, i32 34, i32 %7417
  %7419 = load <8 x i32>, ptr %frame.static.id, align 32
  %7420 = insertelement <8 x i32> %7419, i32 %7418, i32 %7411
  store <8 x i32> %7420, ptr %frame.static.id, align 32
  %7421 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7422 = extractelement <8 x i32> %7421, i32 %7411
  %7423 = select i1 %7404, i32 %7389, i32 %7422
  %7424 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7425 = insertelement <8 x i32> %7424, i32 %7423, i32 %7411
  store <8 x i32> %7425, ptr %frame.parent.token, align 32
  %7426 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7411
  %7427 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7411
  %7428 = load <8 x i1>, ptr %7426, align 1
  %7429 = load <8 x i1>, ptr %7427, align 1
  %7430 = select i1 %7404, <8 x i1> %1867, <8 x i1> %7428
  store <8 x i1> %7430, ptr %7426, align 1
  %7431 = select i1 %7404, <8 x i1> zeroinitializer, <8 x i1> %7429
  store <8 x i1> %7431, ptr %7427, align 1
  %7432 = add i32 %7411, 1
  %7433 = select i1 %7402, i32 %7389, i32 %7432
  %7434 = select i1 true, i32 %7433, i32 %7389
  store i32 %7434, ptr %current.token, align 4
  %7435 = load i32, ptr %current.token, align 4
  %7436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1874)
  %7437 = load i32, ptr %ready.count, align 4
  %7438 = icmp uge i32 %7437, 8
  %7439 = and i1 %7436, %7438
  br i1 %7439, label %ready.overflow.trap1434, label %ready.overflow.resume1435

ready.overflow.trap1434:                          ; preds = %convergence.overflow.resume1433
  call void @llvm.trap()
  unreachable

ready.overflow.resume1435:                        ; preds = %convergence.overflow.resume1433
  %7440 = select i1 %7436, i32 %7437, i32 0
  %7441 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7440
  %7442 = load <8 x i1>, ptr %7441, align 1
  %7443 = select i1 %7436, <8 x i1> %1874, <8 x i1> %7442
  store <8 x i1> %7443, ptr %7441, align 1
  %7444 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7440
  %7445 = load i32, ptr %7444, align 4
  %7446 = select i1 %7436, i32 100, i32 %7445
  store i32 %7446, ptr %7444, align 4
  %7447 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7440
  %7448 = load i32, ptr %7447, align 4
  %7449 = select i1 %7436, i32 %7435, i32 %7448
  store i32 %7449, ptr %7447, align 4
  %7450 = add i32 %7437, 1
  %7451 = select i1 %7436, i32 %7450, i32 %7437
  store i32 %7451, ptr %ready.count, align 4
  %7452 = load <8 x i1>, ptr %runnable.mask, align 1
  %7453 = or <8 x i1> %7452, %1874
  store <8 x i1> %7453, ptr %runnable.mask, align 1
  store <8 x i1> %1876, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1436:                        ; preds = %varying.coherent1431
  store <8 x i1> %1867, ptr %current.mask, align 1
  %7454 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1867)
  br i1 %7454, label %schedule.100, label %scheduler.loop

varying.coherent.false1437:                       ; preds = %varying.coherent1431
  store <8 x i1> %1867, ptr %current.mask, align 1
  %7455 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1867)
  br i1 %7455, label %schedule.101, label %scheduler.loop

convergence.cascade1443:                          ; preds = %convergence.cascade1443, %schedule.101
  %convergence.cascade.flow1447 = phi <8 x i1> [ %1909, %schedule.101 ], [ %7498, %convergence.cascade1443 ]
  %convergence.cascade.depth1448 = phi i32 [ 0, %schedule.101 ], [ %7499, %convergence.cascade1443 ]
  %7456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1447)
  %7457 = load i32, ptr %current.token, align 4
  %7458 = icmp ne i32 %7457, 0
  %7459 = and i1 %7456, %7458
  %7460 = sub i32 %7457, 1
  %7461 = select i1 %7459, i32 %7460, i32 0
  %7462 = load i8, ptr %frame.active, align 1
  %7463 = trunc i32 %7461 to i8
  %7464 = shl i8 1, %7463
  %7465 = and i8 %7462, %7464
  %7466 = icmp ne i8 %7465, 0
  %7467 = load <8 x i32>, ptr %frame.static.id, align 32
  %7468 = extractelement <8 x i32> %7467, i32 %7461
  %convergence.target.pointer1449 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7468
  %convergence.dynamic.target1450 = load i32, ptr %convergence.target.pointer1449, align 4
  %7469 = icmp eq i32 %convergence.dynamic.target1450, 101
  %7470 = and i1 %7466, %7469
  %7471 = and i1 %7459, %7470
  %7472 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7461
  %7473 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7461
  %7474 = load <8 x i1>, ptr %7472, align 1
  %7475 = load <8 x i1>, ptr %7473, align 1
  %7476 = or <8 x i1> %7475, %convergence.cascade.flow1447
  %7477 = load <8 x i1>, ptr %live.mask, align 1
  %7478 = and <8 x i1> %7474, %7477
  %7479 = icmp eq <8 x i1> %7476, %7478
  %7480 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7479)
  %7481 = and i1 %7471, %7480
  %7482 = select i1 %7481, <8 x i1> zeroinitializer, <8 x i1> %7476
  %7483 = select i1 %7471, <8 x i1> %7482, <8 x i1> %7475
  store <8 x i1> %7483, ptr %7473, align 1
  %7484 = select i1 %7481, <8 x i1> zeroinitializer, <8 x i1> %7474
  store <8 x i1> %7484, ptr %7472, align 1
  %7485 = trunc i32 %7461 to i8
  %7486 = shl i8 1, %7485
  %7487 = xor i8 %7486, -1
  %7488 = and i8 %7462, %7487
  %7489 = select i1 %7481, i8 %7488, i8 %7462
  store i8 %7489, ptr %frame.active, align 1
  %.splatinsert1451 = insertelement <8 x i1> poison, i1 %7471, i64 0
  %.splat1452 = shufflevector <8 x i1> %.splatinsert1451, <8 x i1> poison, <8 x i32> zeroinitializer
  %7490 = and <8 x i1> %convergence.cascade.flow1447, %.splat1452
  %7491 = load <8 x i1>, ptr %runnable.mask, align 1
  %7492 = xor <8 x i1> %7490, splat (i1 true)
  %7493 = and <8 x i1> %7491, %7492
  store <8 x i1> %7493, ptr %runnable.mask, align 1
  %.splatinsert1453 = insertelement <8 x i1> poison, i1 %7481, i64 0
  %.splat1454 = shufflevector <8 x i1> %.splatinsert1453, <8 x i1> poison, <8 x i32> zeroinitializer
  %7494 = select <8 x i1> %.splat1454, <8 x i1> %7476, <8 x i1> zeroinitializer
  %7495 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7496 = extractelement <8 x i32> %7495, i32 %7461
  %7497 = select i1 %7481, i32 %7496, i32 %7457
  store i32 %7497, ptr %current.token, align 4
  %.splatinsert1455 = insertelement <8 x i1> poison, i1 %7471, i64 0
  %.splat1456 = shufflevector <8 x i1> %.splatinsert1455, <8 x i1> poison, <8 x i32> zeroinitializer
  %7498 = select <8 x i1> %.splat1456, <8 x i1> %7494, <8 x i1> %convergence.cascade.flow1447
  %7499 = add i32 %convergence.cascade.depth1448, 1
  %7500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7498)
  %7501 = icmp ult i32 %7499, 8
  %7502 = and i1 %7500, %7501
  %7503 = and i1 %7471, %7502
  %convergence.parent.token1457 = load i32, ptr %current.token, align 4
  %convergence.parent.present1458 = icmp ne i32 %convergence.parent.token1457, 0
  %7504 = and i1 %7503, %convergence.parent.present1458
  br i1 %7504, label %convergence.cascade1443, label %convergence.cascade.exit1444

convergence.cascade.exit1444:                     ; preds = %convergence.cascade1443, %schedule.101
  %convergence.cascade.result1459 = phi <8 x i1> [ %1909, %schedule.101 ], [ %7498, %convergence.cascade1443 ]
  %7505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1459)
  br i1 %7505, label %convergence.target.101.ready, label %scheduler.loop

convergence.target.101.ready:                     ; preds = %convergence.cascade.exit1444
  %7506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1459)
  %7507 = bitcast <8 x i1> %convergence.cascade.result1459 to i8
  %7508 = call i8 @llvm.cttz.i8(i8 %7507, i1 false)
  %7509 = zext i8 %7508 to i32
  %7510 = select i1 %7506, i32 %7509, i32 0
  %.state1460 = load <8 x i64>, ptr %.slot68, align 64
  %7511 = add <8 x i64> %.state1460, splat (i64 1)
  %.spill.load1461 = load <8 x float>, ptr %.spill134, align 32
  %.spill.load1462 = load <8 x float>, ptr %.spill135, align 32
  %.spill.load1463 = load <8 x float>, ptr %.spill136, align 32
  %.spill.load1464 = load <8 x float>, ptr %.spill137, align 32
  %.spill.load1465 = load <8 x float>, ptr %.spill138, align 32
  %.spill.load1466 = load <8 x float>, ptr %.spill139, align 32
  %.spill.load1467 = load <8 x float>, ptr %.spill140, align 32
  %.spill.load1468 = load <8 x float>, ptr %.spill141, align 32
  %.spill.load1469 = load <8 x float>, ptr %.spill178, align 32
  %.spill.load1470 = load <8 x float>, ptr %.spill179, align 32
  %.spill.load1471 = load <8 x float>, ptr %.spill180, align 32
  %.spill.load1472 = load <8 x float>, ptr %.spill181, align 32
  %.spill.load1473 = load <8 x float>, ptr %.spill182, align 32
  %.spill.load1474 = load <8 x float>, ptr %.spill183, align 32
  %.spill.load1475 = load <8 x float>, ptr %.spill184, align 32
  %.spill.load1476 = load <8 x float>, ptr %.spill185, align 32
  %7512 = load <8 x i64>, ptr %.slot68, align 64
  %7513 = select <8 x i1> %convergence.cascade.result1459, <8 x i64> %7511, <8 x i64> %7512
  store <8 x i64> %7513, ptr %.slot68, align 64
  %7514 = load <8 x float>, ptr %.slot69, align 32
  %7515 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1461, <8 x float> %7514
  store <8 x float> %7515, ptr %.slot69, align 32
  %7516 = load <8 x float>, ptr %.slot70, align 32
  %7517 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1462, <8 x float> %7516
  store <8 x float> %7517, ptr %.slot70, align 32
  %7518 = load <8 x float>, ptr %.slot71, align 32
  %7519 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1463, <8 x float> %7518
  store <8 x float> %7519, ptr %.slot71, align 32
  %7520 = load <8 x float>, ptr %.slot72, align 32
  %7521 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1464, <8 x float> %7520
  store <8 x float> %7521, ptr %.slot72, align 32
  %7522 = load <8 x float>, ptr %.slot73, align 32
  %7523 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1465, <8 x float> %7522
  store <8 x float> %7523, ptr %.slot73, align 32
  %7524 = load <8 x float>, ptr %.slot74, align 32
  %7525 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1466, <8 x float> %7524
  store <8 x float> %7525, ptr %.slot74, align 32
  %7526 = load <8 x float>, ptr %.slot75, align 32
  %7527 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1467, <8 x float> %7526
  store <8 x float> %7527, ptr %.slot75, align 32
  %7528 = load <8 x float>, ptr %.slot76, align 32
  %7529 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1468, <8 x float> %7528
  store <8 x float> %7529, ptr %.slot76, align 32
  %7530 = load <8 x float>, ptr %.slot77, align 32
  %7531 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1469, <8 x float> %7530
  store <8 x float> %7531, ptr %.slot77, align 32
  %7532 = load <8 x float>, ptr %.slot78, align 32
  %7533 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1470, <8 x float> %7532
  store <8 x float> %7533, ptr %.slot78, align 32
  %7534 = load <8 x float>, ptr %.slot79, align 32
  %7535 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1471, <8 x float> %7534
  store <8 x float> %7535, ptr %.slot79, align 32
  %7536 = load <8 x float>, ptr %.slot80, align 32
  %7537 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1472, <8 x float> %7536
  store <8 x float> %7537, ptr %.slot80, align 32
  %7538 = load <8 x float>, ptr %.slot81, align 32
  %7539 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1473, <8 x float> %7538
  store <8 x float> %7539, ptr %.slot81, align 32
  %7540 = load <8 x float>, ptr %.slot82, align 32
  %7541 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1474, <8 x float> %7540
  store <8 x float> %7541, ptr %.slot82, align 32
  %7542 = load <8 x float>, ptr %.slot83, align 32
  %7543 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1475, <8 x float> %7542
  store <8 x float> %7543, ptr %.slot83, align 32
  %7544 = load <8 x float>, ptr %.slot84, align 32
  %7545 = select <8 x i1> %convergence.cascade.result1459, <8 x float> %.spill.load1476, <8 x float> %7544
  store <8 x float> %7545, ptr %.slot84, align 32
  store <8 x i1> %convergence.cascade.result1459, ptr %current.mask, align 1
  %7546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1459)
  br i1 %7546, label %schedule.9, label %scheduler.loop

convergence.cascade1477:                          ; preds = %convergence.cascade1477, %schedule.102
  %convergence.cascade.flow1481 = phi <8 x i1> [ %1910, %schedule.102 ], [ %7589, %convergence.cascade1477 ]
  %convergence.cascade.depth1482 = phi i32 [ 0, %schedule.102 ], [ %7590, %convergence.cascade1477 ]
  %7547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1481)
  %7548 = load i32, ptr %current.token, align 4
  %7549 = icmp ne i32 %7548, 0
  %7550 = and i1 %7547, %7549
  %7551 = sub i32 %7548, 1
  %7552 = select i1 %7550, i32 %7551, i32 0
  %7553 = load i8, ptr %frame.active, align 1
  %7554 = trunc i32 %7552 to i8
  %7555 = shl i8 1, %7554
  %7556 = and i8 %7553, %7555
  %7557 = icmp ne i8 %7556, 0
  %7558 = load <8 x i32>, ptr %frame.static.id, align 32
  %7559 = extractelement <8 x i32> %7558, i32 %7552
  %convergence.target.pointer1483 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7559
  %convergence.dynamic.target1484 = load i32, ptr %convergence.target.pointer1483, align 4
  %7560 = icmp eq i32 %convergence.dynamic.target1484, 102
  %7561 = and i1 %7557, %7560
  %7562 = and i1 %7550, %7561
  %7563 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7552
  %7564 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7552
  %7565 = load <8 x i1>, ptr %7563, align 1
  %7566 = load <8 x i1>, ptr %7564, align 1
  %7567 = or <8 x i1> %7566, %convergence.cascade.flow1481
  %7568 = load <8 x i1>, ptr %live.mask, align 1
  %7569 = and <8 x i1> %7565, %7568
  %7570 = icmp eq <8 x i1> %7567, %7569
  %7571 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7570)
  %7572 = and i1 %7562, %7571
  %7573 = select i1 %7572, <8 x i1> zeroinitializer, <8 x i1> %7567
  %7574 = select i1 %7562, <8 x i1> %7573, <8 x i1> %7566
  store <8 x i1> %7574, ptr %7564, align 1
  %7575 = select i1 %7572, <8 x i1> zeroinitializer, <8 x i1> %7565
  store <8 x i1> %7575, ptr %7563, align 1
  %7576 = trunc i32 %7552 to i8
  %7577 = shl i8 1, %7576
  %7578 = xor i8 %7577, -1
  %7579 = and i8 %7553, %7578
  %7580 = select i1 %7572, i8 %7579, i8 %7553
  store i8 %7580, ptr %frame.active, align 1
  %.splatinsert1485 = insertelement <8 x i1> poison, i1 %7562, i64 0
  %.splat1486 = shufflevector <8 x i1> %.splatinsert1485, <8 x i1> poison, <8 x i32> zeroinitializer
  %7581 = and <8 x i1> %convergence.cascade.flow1481, %.splat1486
  %7582 = load <8 x i1>, ptr %runnable.mask, align 1
  %7583 = xor <8 x i1> %7581, splat (i1 true)
  %7584 = and <8 x i1> %7582, %7583
  store <8 x i1> %7584, ptr %runnable.mask, align 1
  %.splatinsert1487 = insertelement <8 x i1> poison, i1 %7572, i64 0
  %.splat1488 = shufflevector <8 x i1> %.splatinsert1487, <8 x i1> poison, <8 x i32> zeroinitializer
  %7585 = select <8 x i1> %.splat1488, <8 x i1> %7567, <8 x i1> zeroinitializer
  %7586 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7587 = extractelement <8 x i32> %7586, i32 %7552
  %7588 = select i1 %7572, i32 %7587, i32 %7548
  store i32 %7588, ptr %current.token, align 4
  %.splatinsert1489 = insertelement <8 x i1> poison, i1 %7562, i64 0
  %.splat1490 = shufflevector <8 x i1> %.splatinsert1489, <8 x i1> poison, <8 x i32> zeroinitializer
  %7589 = select <8 x i1> %.splat1490, <8 x i1> %7585, <8 x i1> %convergence.cascade.flow1481
  %7590 = add i32 %convergence.cascade.depth1482, 1
  %7591 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7589)
  %7592 = icmp ult i32 %7590, 8
  %7593 = and i1 %7591, %7592
  %7594 = and i1 %7562, %7593
  %convergence.parent.token1491 = load i32, ptr %current.token, align 4
  %convergence.parent.present1492 = icmp ne i32 %convergence.parent.token1491, 0
  %7595 = and i1 %7594, %convergence.parent.present1492
  br i1 %7595, label %convergence.cascade1477, label %convergence.cascade.exit1478

convergence.cascade.exit1478:                     ; preds = %convergence.cascade1477, %schedule.102
  %convergence.cascade.result1493 = phi <8 x i1> [ %1910, %schedule.102 ], [ %7589, %convergence.cascade1477 ]
  %7596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1493)
  br i1 %7596, label %convergence.target.102.ready, label %scheduler.loop

convergence.target.102.ready:                     ; preds = %convergence.cascade.exit1478
  %7597 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1493)
  %7598 = bitcast <8 x i1> %convergence.cascade.result1493 to i8
  %7599 = call i8 @llvm.cttz.i8(i8 %7598, i1 false)
  %7600 = zext i8 %7599 to i32
  %7601 = select i1 %7597, i32 %7600, i32 0
  %7602 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill205, align 64
  %7603 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7604 = extractvalue { <8 x ptr>, <8 x i64> } %7602, 0
  %7605 = select <8 x i1> %convergence.cascade.result1493, <8 x ptr> %7603, <8 x ptr> %7604
  %7606 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7607 = extractvalue { <8 x ptr>, <8 x i64> } %7602, 1
  %7608 = select <8 x i1> %convergence.cascade.result1493, <8 x i64> %7606, <8 x i64> %7607
  %7609 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7605, 0
  %7610 = insertvalue { <8 x ptr>, <8 x i64> } %7609, <8 x i64> %7608, 1
  store { <8 x ptr>, <8 x i64> } %7610, ptr %tile_snapshot.spill205, align 64
  %7611 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7612 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7613 = add <8 x i64> %7612, zeroinitializer
  %7614 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7611, 0
  %7615 = insertvalue { <8 x ptr>, <8 x i64> } %7614, <8 x i64> %7613, 1
  %.state1494 = load <8 x float>, ptr %.slot77, align 32
  %7616 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7617 = extractvalue { <8 x ptr>, <8 x i64> } %7615, 1
  %7618 = extractelement <8 x ptr> %7616, i32 0
  %7619 = extractelement <8 x i64> %7617, i32 %7601
  %7620 = zext i32 %7601 to i64
  %7621 = mul i64 %7620, 4
  %7622 = sub i64 %7619, %7621
  %7623 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1493)
  %7624 = select i1 %7623, i64 %7622, i64 0
  %private.contiguous.address1495 = getelementptr i8, ptr %7618, i64 %7624
  %private.contiguous.preserve1496 = load <8 x float>, ptr %private.contiguous.address1495, align 4
  %7625 = select <8 x i1> %convergence.cascade.result1493, <8 x float> %.state1494, <8 x float> %private.contiguous.preserve1496
  store <8 x float> %7625, ptr %private.contiguous.address1495, align 4
  %7626 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7627 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7628 = add <8 x i64> %7627, splat (i64 32)
  %7629 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7626, 0
  %7630 = insertvalue { <8 x ptr>, <8 x i64> } %7629, <8 x i64> %7628, 1
  %.state1497 = load <8 x float>, ptr %.slot78, align 32
  %7631 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7632 = extractvalue { <8 x ptr>, <8 x i64> } %7630, 1
  %7633 = extractelement <8 x ptr> %7631, i32 0
  %7634 = extractelement <8 x i64> %7632, i32 %7601
  %7635 = zext i32 %7601 to i64
  %7636 = mul i64 %7635, 4
  %7637 = sub i64 %7634, %7636
  %7638 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1493)
  %7639 = select i1 %7638, i64 %7637, i64 0
  %private.contiguous.address1498 = getelementptr i8, ptr %7633, i64 %7639
  %private.contiguous.preserve1499 = load <8 x float>, ptr %private.contiguous.address1498, align 4
  %7640 = select <8 x i1> %convergence.cascade.result1493, <8 x float> %.state1497, <8 x float> %private.contiguous.preserve1499
  store <8 x float> %7640, ptr %private.contiguous.address1498, align 4
  %7641 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7642 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7643 = add <8 x i64> %7642, splat (i64 64)
  %7644 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7641, 0
  %7645 = insertvalue { <8 x ptr>, <8 x i64> } %7644, <8 x i64> %7643, 1
  %.state1500 = load <8 x float>, ptr %.slot79, align 32
  %7646 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7647 = extractvalue { <8 x ptr>, <8 x i64> } %7645, 1
  %7648 = extractelement <8 x ptr> %7646, i32 0
  %7649 = extractelement <8 x i64> %7647, i32 %7601
  %7650 = zext i32 %7601 to i64
  %7651 = mul i64 %7650, 4
  %7652 = sub i64 %7649, %7651
  %7653 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1493)
  %7654 = select i1 %7653, i64 %7652, i64 0
  %private.contiguous.address1501 = getelementptr i8, ptr %7648, i64 %7654
  %private.contiguous.preserve1502 = load <8 x float>, ptr %private.contiguous.address1501, align 4
  %7655 = select <8 x i1> %convergence.cascade.result1493, <8 x float> %.state1500, <8 x float> %private.contiguous.preserve1502
  store <8 x float> %7655, ptr %private.contiguous.address1501, align 4
  %7656 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7657 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7658 = add <8 x i64> %7657, splat (i64 96)
  %7659 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7656, 0
  %7660 = insertvalue { <8 x ptr>, <8 x i64> } %7659, <8 x i64> %7658, 1
  %.state1503 = load <8 x float>, ptr %.slot80, align 32
  %7661 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7662 = extractvalue { <8 x ptr>, <8 x i64> } %7660, 1
  %7663 = extractelement <8 x ptr> %7661, i32 0
  %7664 = extractelement <8 x i64> %7662, i32 %7601
  %7665 = zext i32 %7601 to i64
  %7666 = mul i64 %7665, 4
  %7667 = sub i64 %7664, %7666
  %7668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1493)
  %7669 = select i1 %7668, i64 %7667, i64 0
  %private.contiguous.address1504 = getelementptr i8, ptr %7663, i64 %7669
  %private.contiguous.preserve1505 = load <8 x float>, ptr %private.contiguous.address1504, align 4
  %7670 = select <8 x i1> %convergence.cascade.result1493, <8 x float> %.state1503, <8 x float> %private.contiguous.preserve1505
  store <8 x float> %7670, ptr %private.contiguous.address1504, align 4
  %7671 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7672 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7673 = add <8 x i64> %7672, splat (i64 128)
  %7674 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7671, 0
  %7675 = insertvalue { <8 x ptr>, <8 x i64> } %7674, <8 x i64> %7673, 1
  %.state1506 = load <8 x float>, ptr %.slot81, align 32
  %7676 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7677 = extractvalue { <8 x ptr>, <8 x i64> } %7675, 1
  %7678 = extractelement <8 x ptr> %7676, i32 0
  %7679 = extractelement <8 x i64> %7677, i32 %7601
  %7680 = zext i32 %7601 to i64
  %7681 = mul i64 %7680, 4
  %7682 = sub i64 %7679, %7681
  %7683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1493)
  %7684 = select i1 %7683, i64 %7682, i64 0
  %private.contiguous.address1507 = getelementptr i8, ptr %7678, i64 %7684
  %private.contiguous.preserve1508 = load <8 x float>, ptr %private.contiguous.address1507, align 4
  %7685 = select <8 x i1> %convergence.cascade.result1493, <8 x float> %.state1506, <8 x float> %private.contiguous.preserve1508
  store <8 x float> %7685, ptr %private.contiguous.address1507, align 4
  %7686 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7687 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7688 = add <8 x i64> %7687, splat (i64 160)
  %7689 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7686, 0
  %7690 = insertvalue { <8 x ptr>, <8 x i64> } %7689, <8 x i64> %7688, 1
  %.state1509 = load <8 x float>, ptr %.slot82, align 32
  %7691 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7692 = extractvalue { <8 x ptr>, <8 x i64> } %7690, 1
  %7693 = extractelement <8 x ptr> %7691, i32 0
  %7694 = extractelement <8 x i64> %7692, i32 %7601
  %7695 = zext i32 %7601 to i64
  %7696 = mul i64 %7695, 4
  %7697 = sub i64 %7694, %7696
  %7698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1493)
  %7699 = select i1 %7698, i64 %7697, i64 0
  %private.contiguous.address1510 = getelementptr i8, ptr %7693, i64 %7699
  %private.contiguous.preserve1511 = load <8 x float>, ptr %private.contiguous.address1510, align 4
  %7700 = select <8 x i1> %convergence.cascade.result1493, <8 x float> %.state1509, <8 x float> %private.contiguous.preserve1511
  store <8 x float> %7700, ptr %private.contiguous.address1510, align 4
  %7701 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7702 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7703 = add <8 x i64> %7702, splat (i64 192)
  %7704 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7701, 0
  %7705 = insertvalue { <8 x ptr>, <8 x i64> } %7704, <8 x i64> %7703, 1
  %.state1512 = load <8 x float>, ptr %.slot83, align 32
  %7706 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7707 = extractvalue { <8 x ptr>, <8 x i64> } %7705, 1
  %7708 = extractelement <8 x ptr> %7706, i32 0
  %7709 = extractelement <8 x i64> %7707, i32 %7601
  %7710 = zext i32 %7601 to i64
  %7711 = mul i64 %7710, 4
  %7712 = sub i64 %7709, %7711
  %7713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1493)
  %7714 = select i1 %7713, i64 %7712, i64 0
  %private.contiguous.address1513 = getelementptr i8, ptr %7708, i64 %7714
  %private.contiguous.preserve1514 = load <8 x float>, ptr %private.contiguous.address1513, align 4
  %7715 = select <8 x i1> %convergence.cascade.result1493, <8 x float> %.state1512, <8 x float> %private.contiguous.preserve1514
  store <8 x float> %7715, ptr %private.contiguous.address1513, align 4
  %7716 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7717 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7718 = add <8 x i64> %7717, splat (i64 224)
  %7719 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7716, 0
  %7720 = insertvalue { <8 x ptr>, <8 x i64> } %7719, <8 x i64> %7718, 1
  %.state1515 = load <8 x float>, ptr %.slot84, align 32
  %7721 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7722 = extractvalue { <8 x ptr>, <8 x i64> } %7720, 1
  %7723 = extractelement <8 x ptr> %7721, i32 0
  %7724 = extractelement <8 x i64> %7722, i32 %7601
  %7725 = zext i32 %7601 to i64
  %7726 = mul i64 %7725, 4
  %7727 = sub i64 %7724, %7726
  %7728 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1493)
  %7729 = select i1 %7728, i64 %7727, i64 0
  %private.contiguous.address1516 = getelementptr i8, ptr %7723, i64 %7729
  %private.contiguous.preserve1517 = load <8 x float>, ptr %private.contiguous.address1516, align 4
  %7730 = select <8 x i1> %convergence.cascade.result1493, <8 x float> %.state1515, <8 x float> %private.contiguous.preserve1517
  store <8 x float> %7730, ptr %private.contiguous.address1516, align 4
  %7731 = load <8 x i64>, ptr %.slot206, align 64
  %7732 = select <8 x i1> %convergence.cascade.result1493, <8 x i64> zeroinitializer, <8 x i64> %7731
  store <8 x i64> %7732, ptr %.slot206, align 64
  store <8 x i1> %convergence.cascade.result1493, ptr %current.mask, align 1
  %7733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1493)
  br i1 %7733, label %schedule.103, label %scheduler.loop

varying.divergent1519:                            ; preds = %schedule.103
  %7734 = load i32, ptr %current.token, align 4
  %7735 = icmp ne i32 %7734, 0
  %7736 = sub i32 %7734, 1
  %7737 = select i1 %7735, i32 %7736, i32 0
  %7738 = load i8, ptr %frame.active, align 1
  %7739 = trunc i32 %7737 to i8
  %7740 = shl i8 1, %7739
  %7741 = and i8 %7738, %7740
  %7742 = icmp ne i8 %7741, 0
  %7743 = load <8 x i32>, ptr %frame.static.id, align 32
  %7744 = extractelement <8 x i32> %7743, i32 %7737
  %7745 = icmp eq i32 %7744, 35
  %7746 = and i1 %7742, %7745
  %7747 = and i1 %7735, %7746
  %7748 = xor i1 %7747, true
  %7749 = and i1 true, %7748
  %7750 = xor i8 %7738, -1
  %7751 = icmp ne i8 %7750, 0
  %7752 = xor i1 %7751, true
  %7753 = and i1 %7749, %7752
  br i1 %7753, label %convergence.overflow.trap1521, label %convergence.overflow.resume1522

varying.coherent1520:                             ; preds = %schedule.103
  br i1 %1921, label %varying.coherent.true1525, label %varying.coherent.false1526

convergence.overflow.trap1521:                    ; preds = %varying.divergent1519
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1522:                  ; preds = %varying.divergent1519
  %7754 = call i8 @llvm.cttz.i8(i8 %7750, i1 false)
  %7755 = zext i8 %7754 to i32
  %7756 = select i1 %7751, i32 %7755, i32 0
  %7757 = trunc i32 %7756 to i8
  %7758 = shl i8 1, %7757
  %7759 = or i8 %7738, %7758
  %7760 = select i1 %7749, i8 %7759, i8 %7738
  store i8 %7760, ptr %frame.active, align 1
  %7761 = load <8 x i32>, ptr %frame.static.id, align 32
  %7762 = extractelement <8 x i32> %7761, i32 %7756
  %7763 = select i1 %7749, i32 35, i32 %7762
  %7764 = load <8 x i32>, ptr %frame.static.id, align 32
  %7765 = insertelement <8 x i32> %7764, i32 %7763, i32 %7756
  store <8 x i32> %7765, ptr %frame.static.id, align 32
  %7766 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7767 = extractelement <8 x i32> %7766, i32 %7756
  %7768 = select i1 %7749, i32 %7734, i32 %7767
  %7769 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7770 = insertelement <8 x i32> %7769, i32 %7768, i32 %7756
  store <8 x i32> %7770, ptr %frame.parent.token, align 32
  %7771 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7756
  %7772 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7756
  %7773 = load <8 x i1>, ptr %7771, align 1
  %7774 = load <8 x i1>, ptr %7772, align 1
  %7775 = select i1 %7749, <8 x i1> %1911, <8 x i1> %7773
  store <8 x i1> %7775, ptr %7771, align 1
  %7776 = select i1 %7749, <8 x i1> zeroinitializer, <8 x i1> %7774
  store <8 x i1> %7776, ptr %7772, align 1
  %7777 = add i32 %7756, 1
  %7778 = select i1 %7747, i32 %7734, i32 %7777
  %7779 = select i1 true, i32 %7778, i32 %7734
  store i32 %7779, ptr %current.token, align 4
  %7780 = load i32, ptr %current.token, align 4
  %7781 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1918)
  %7782 = load i32, ptr %ready.count, align 4
  %7783 = icmp uge i32 %7782, 8
  %7784 = and i1 %7781, %7783
  br i1 %7784, label %ready.overflow.trap1523, label %ready.overflow.resume1524

ready.overflow.trap1523:                          ; preds = %convergence.overflow.resume1522
  call void @llvm.trap()
  unreachable

ready.overflow.resume1524:                        ; preds = %convergence.overflow.resume1522
  %7785 = select i1 %7781, i32 %7782, i32 0
  %7786 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7785
  %7787 = load <8 x i1>, ptr %7786, align 1
  %7788 = select i1 %7781, <8 x i1> %1918, <8 x i1> %7787
  store <8 x i1> %7788, ptr %7786, align 1
  %7789 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7785
  %7790 = load i32, ptr %7789, align 4
  %7791 = select i1 %7781, i32 104, i32 %7790
  store i32 %7791, ptr %7789, align 4
  %7792 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7785
  %7793 = load i32, ptr %7792, align 4
  %7794 = select i1 %7781, i32 %7780, i32 %7793
  store i32 %7794, ptr %7792, align 4
  %7795 = add i32 %7782, 1
  %7796 = select i1 %7781, i32 %7795, i32 %7782
  store i32 %7796, ptr %ready.count, align 4
  %7797 = load <8 x i1>, ptr %runnable.mask, align 1
  %7798 = or <8 x i1> %7797, %1918
  store <8 x i1> %7798, ptr %runnable.mask, align 1
  store <8 x i1> %1920, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1525:                        ; preds = %varying.coherent1520
  store <8 x i1> %1911, ptr %current.mask, align 1
  %7799 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1911)
  br i1 %7799, label %schedule.104, label %scheduler.loop

varying.coherent.false1526:                       ; preds = %varying.coherent1520
  store <8 x i1> %1911, ptr %current.mask, align 1
  %7800 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1911)
  br i1 %7800, label %schedule.107, label %scheduler.loop

varying.divergent1533:                            ; preds = %schedule.104
  %7801 = load i32, ptr %current.token, align 4
  %7802 = icmp ne i32 %7801, 0
  %7803 = sub i32 %7801, 1
  %7804 = select i1 %7802, i32 %7803, i32 0
  %7805 = load i8, ptr %frame.active, align 1
  %7806 = trunc i32 %7804 to i8
  %7807 = shl i8 1, %7806
  %7808 = and i8 %7805, %7807
  %7809 = icmp ne i8 %7808, 0
  %7810 = load <8 x i32>, ptr %frame.static.id, align 32
  %7811 = extractelement <8 x i32> %7810, i32 %7804
  %7812 = icmp eq i32 %7811, 36
  %7813 = and i1 %7809, %7812
  %7814 = and i1 %7802, %7813
  %7815 = xor i1 %7814, true
  %7816 = and i1 true, %7815
  %7817 = xor i8 %7805, -1
  %7818 = icmp ne i8 %7817, 0
  %7819 = xor i1 %7818, true
  %7820 = and i1 %7816, %7819
  br i1 %7820, label %convergence.overflow.trap1535, label %convergence.overflow.resume1536

varying.coherent1534:                             ; preds = %schedule.104
  br i1 %1979, label %varying.coherent.true1539, label %varying.coherent.false1540

convergence.overflow.trap1535:                    ; preds = %varying.divergent1533
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1536:                  ; preds = %varying.divergent1533
  %7821 = call i8 @llvm.cttz.i8(i8 %7817, i1 false)
  %7822 = zext i8 %7821 to i32
  %7823 = select i1 %7818, i32 %7822, i32 0
  %7824 = trunc i32 %7823 to i8
  %7825 = shl i8 1, %7824
  %7826 = or i8 %7805, %7825
  %7827 = select i1 %7816, i8 %7826, i8 %7805
  store i8 %7827, ptr %frame.active, align 1
  %7828 = load <8 x i32>, ptr %frame.static.id, align 32
  %7829 = extractelement <8 x i32> %7828, i32 %7823
  %7830 = select i1 %7816, i32 36, i32 %7829
  %7831 = load <8 x i32>, ptr %frame.static.id, align 32
  %7832 = insertelement <8 x i32> %7831, i32 %7830, i32 %7823
  store <8 x i32> %7832, ptr %frame.static.id, align 32
  %7833 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7834 = extractelement <8 x i32> %7833, i32 %7823
  %7835 = select i1 %7816, i32 %7801, i32 %7834
  %7836 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7837 = insertelement <8 x i32> %7836, i32 %7835, i32 %7823
  store <8 x i32> %7837, ptr %frame.parent.token, align 32
  %7838 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7823
  %7839 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7823
  %7840 = load <8 x i1>, ptr %7838, align 1
  %7841 = load <8 x i1>, ptr %7839, align 1
  %7842 = select i1 %7816, <8 x i1> %1924, <8 x i1> %7840
  store <8 x i1> %7842, ptr %7838, align 1
  %7843 = select i1 %7816, <8 x i1> zeroinitializer, <8 x i1> %7841
  store <8 x i1> %7843, ptr %7839, align 1
  %7844 = add i32 %7823, 1
  %7845 = select i1 %7814, i32 %7801, i32 %7844
  %7846 = select i1 true, i32 %7845, i32 %7801
  store i32 %7846, ptr %current.token, align 4
  %7847 = load i32, ptr %current.token, align 4
  %7848 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1976)
  %7849 = load i32, ptr %ready.count, align 4
  %7850 = icmp uge i32 %7849, 8
  %7851 = and i1 %7848, %7850
  br i1 %7851, label %ready.overflow.trap1537, label %ready.overflow.resume1538

ready.overflow.trap1537:                          ; preds = %convergence.overflow.resume1536
  call void @llvm.trap()
  unreachable

ready.overflow.resume1538:                        ; preds = %convergence.overflow.resume1536
  %7852 = select i1 %7848, i32 %7849, i32 0
  %7853 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7852
  %7854 = load <8 x i1>, ptr %7853, align 1
  %7855 = select i1 %7848, <8 x i1> %1976, <8 x i1> %7854
  store <8 x i1> %7855, ptr %7853, align 1
  %7856 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7852
  %7857 = load i32, ptr %7856, align 4
  %7858 = select i1 %7848, i32 105, i32 %7857
  store i32 %7858, ptr %7856, align 4
  %7859 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7852
  %7860 = load i32, ptr %7859, align 4
  %7861 = select i1 %7848, i32 %7847, i32 %7860
  store i32 %7861, ptr %7859, align 4
  %7862 = add i32 %7849, 1
  %7863 = select i1 %7848, i32 %7862, i32 %7849
  store i32 %7863, ptr %ready.count, align 4
  %7864 = load <8 x i1>, ptr %runnable.mask, align 1
  %7865 = or <8 x i1> %7864, %1976
  store <8 x i1> %7865, ptr %runnable.mask, align 1
  store <8 x i1> %1978, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1539:                        ; preds = %varying.coherent1534
  store <8 x i1> %1924, ptr %current.mask, align 1
  %7866 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1924)
  br i1 %7866, label %schedule.105, label %scheduler.loop

varying.coherent.false1540:                       ; preds = %varying.coherent1534
  store <8 x i1> %1924, ptr %current.mask, align 1
  %7867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1924)
  br i1 %7867, label %schedule.106, label %scheduler.loop

convergence.cascade1543:                          ; preds = %convergence.cascade1543, %schedule.106
  %convergence.cascade.flow1547 = phi <8 x i1> [ %1992, %schedule.106 ], [ %7910, %convergence.cascade1543 ]
  %convergence.cascade.depth1548 = phi i32 [ 0, %schedule.106 ], [ %7911, %convergence.cascade1543 ]
  %7868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1547)
  %7869 = load i32, ptr %current.token, align 4
  %7870 = icmp ne i32 %7869, 0
  %7871 = and i1 %7868, %7870
  %7872 = sub i32 %7869, 1
  %7873 = select i1 %7871, i32 %7872, i32 0
  %7874 = load i8, ptr %frame.active, align 1
  %7875 = trunc i32 %7873 to i8
  %7876 = shl i8 1, %7875
  %7877 = and i8 %7874, %7876
  %7878 = icmp ne i8 %7877, 0
  %7879 = load <8 x i32>, ptr %frame.static.id, align 32
  %7880 = extractelement <8 x i32> %7879, i32 %7873
  %convergence.target.pointer1549 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7880
  %convergence.dynamic.target1550 = load i32, ptr %convergence.target.pointer1549, align 4
  %7881 = icmp eq i32 %convergence.dynamic.target1550, 106
  %7882 = and i1 %7878, %7881
  %7883 = and i1 %7871, %7882
  %7884 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7873
  %7885 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7873
  %7886 = load <8 x i1>, ptr %7884, align 1
  %7887 = load <8 x i1>, ptr %7885, align 1
  %7888 = or <8 x i1> %7887, %convergence.cascade.flow1547
  %7889 = load <8 x i1>, ptr %live.mask, align 1
  %7890 = and <8 x i1> %7886, %7889
  %7891 = icmp eq <8 x i1> %7888, %7890
  %7892 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7891)
  %7893 = and i1 %7883, %7892
  %7894 = select i1 %7893, <8 x i1> zeroinitializer, <8 x i1> %7888
  %7895 = select i1 %7883, <8 x i1> %7894, <8 x i1> %7887
  store <8 x i1> %7895, ptr %7885, align 1
  %7896 = select i1 %7893, <8 x i1> zeroinitializer, <8 x i1> %7886
  store <8 x i1> %7896, ptr %7884, align 1
  %7897 = trunc i32 %7873 to i8
  %7898 = shl i8 1, %7897
  %7899 = xor i8 %7898, -1
  %7900 = and i8 %7874, %7899
  %7901 = select i1 %7893, i8 %7900, i8 %7874
  store i8 %7901, ptr %frame.active, align 1
  %.splatinsert1551 = insertelement <8 x i1> poison, i1 %7883, i64 0
  %.splat1552 = shufflevector <8 x i1> %.splatinsert1551, <8 x i1> poison, <8 x i32> zeroinitializer
  %7902 = and <8 x i1> %convergence.cascade.flow1547, %.splat1552
  %7903 = load <8 x i1>, ptr %runnable.mask, align 1
  %7904 = xor <8 x i1> %7902, splat (i1 true)
  %7905 = and <8 x i1> %7903, %7904
  store <8 x i1> %7905, ptr %runnable.mask, align 1
  %.splatinsert1553 = insertelement <8 x i1> poison, i1 %7893, i64 0
  %.splat1554 = shufflevector <8 x i1> %.splatinsert1553, <8 x i1> poison, <8 x i32> zeroinitializer
  %7906 = select <8 x i1> %.splat1554, <8 x i1> %7888, <8 x i1> zeroinitializer
  %7907 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7908 = extractelement <8 x i32> %7907, i32 %7873
  %7909 = select i1 %7893, i32 %7908, i32 %7869
  store i32 %7909, ptr %current.token, align 4
  %.splatinsert1555 = insertelement <8 x i1> poison, i1 %7883, i64 0
  %.splat1556 = shufflevector <8 x i1> %.splatinsert1555, <8 x i1> poison, <8 x i32> zeroinitializer
  %7910 = select <8 x i1> %.splat1556, <8 x i1> %7906, <8 x i1> %convergence.cascade.flow1547
  %7911 = add i32 %convergence.cascade.depth1548, 1
  %7912 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7910)
  %7913 = icmp ult i32 %7911, 8
  %7914 = and i1 %7912, %7913
  %7915 = and i1 %7883, %7914
  %convergence.parent.token1557 = load i32, ptr %current.token, align 4
  %convergence.parent.present1558 = icmp ne i32 %convergence.parent.token1557, 0
  %7916 = and i1 %7915, %convergence.parent.present1558
  br i1 %7916, label %convergence.cascade1543, label %convergence.cascade.exit1544

convergence.cascade.exit1544:                     ; preds = %convergence.cascade1543, %schedule.106
  %convergence.cascade.result1559 = phi <8 x i1> [ %1992, %schedule.106 ], [ %7910, %convergence.cascade1543 ]
  %7917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1559)
  br i1 %7917, label %convergence.target.106.ready, label %scheduler.loop

convergence.target.106.ready:                     ; preds = %convergence.cascade.exit1544
  %7918 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1559)
  %7919 = bitcast <8 x i1> %convergence.cascade.result1559 to i8
  %7920 = call i8 @llvm.cttz.i8(i8 %7919, i1 false)
  %7921 = zext i8 %7920 to i32
  %7922 = select i1 %7918, i32 %7921, i32 0
  %.state1560 = load <8 x i64>, ptr %.slot206, align 64
  %7923 = add <8 x i64> %.state1560, splat (i64 1)
  %7924 = load <8 x i64>, ptr %.slot206, align 64
  %7925 = select <8 x i1> %convergence.cascade.result1559, <8 x i64> %7923, <8 x i64> %7924
  store <8 x i64> %7925, ptr %.slot206, align 64
  store <8 x i1> %convergence.cascade.result1559, ptr %current.mask, align 1
  %7926 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1559)
  br i1 %7926, label %schedule.103, label %scheduler.loop

convergence.cascade1561:                          ; preds = %convergence.cascade1561, %schedule.107
  %convergence.cascade.flow1565 = phi <8 x i1> [ %1993, %schedule.107 ], [ %7969, %convergence.cascade1561 ]
  %convergence.cascade.depth1566 = phi i32 [ 0, %schedule.107 ], [ %7970, %convergence.cascade1561 ]
  %7927 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1565)
  %7928 = load i32, ptr %current.token, align 4
  %7929 = icmp ne i32 %7928, 0
  %7930 = and i1 %7927, %7929
  %7931 = sub i32 %7928, 1
  %7932 = select i1 %7930, i32 %7931, i32 0
  %7933 = load i8, ptr %frame.active, align 1
  %7934 = trunc i32 %7932 to i8
  %7935 = shl i8 1, %7934
  %7936 = and i8 %7933, %7935
  %7937 = icmp ne i8 %7936, 0
  %7938 = load <8 x i32>, ptr %frame.static.id, align 32
  %7939 = extractelement <8 x i32> %7938, i32 %7932
  %convergence.target.pointer1567 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7939
  %convergence.dynamic.target1568 = load i32, ptr %convergence.target.pointer1567, align 4
  %7940 = icmp eq i32 %convergence.dynamic.target1568, 107
  %7941 = and i1 %7937, %7940
  %7942 = and i1 %7930, %7941
  %7943 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7932
  %7944 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7932
  %7945 = load <8 x i1>, ptr %7943, align 1
  %7946 = load <8 x i1>, ptr %7944, align 1
  %7947 = or <8 x i1> %7946, %convergence.cascade.flow1565
  %7948 = load <8 x i1>, ptr %live.mask, align 1
  %7949 = and <8 x i1> %7945, %7948
  %7950 = icmp eq <8 x i1> %7947, %7949
  %7951 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7950)
  %7952 = and i1 %7942, %7951
  %7953 = select i1 %7952, <8 x i1> zeroinitializer, <8 x i1> %7947
  %7954 = select i1 %7942, <8 x i1> %7953, <8 x i1> %7946
  store <8 x i1> %7954, ptr %7944, align 1
  %7955 = select i1 %7952, <8 x i1> zeroinitializer, <8 x i1> %7945
  store <8 x i1> %7955, ptr %7943, align 1
  %7956 = trunc i32 %7932 to i8
  %7957 = shl i8 1, %7956
  %7958 = xor i8 %7957, -1
  %7959 = and i8 %7933, %7958
  %7960 = select i1 %7952, i8 %7959, i8 %7933
  store i8 %7960, ptr %frame.active, align 1
  %.splatinsert1569 = insertelement <8 x i1> poison, i1 %7942, i64 0
  %.splat1570 = shufflevector <8 x i1> %.splatinsert1569, <8 x i1> poison, <8 x i32> zeroinitializer
  %7961 = and <8 x i1> %convergence.cascade.flow1565, %.splat1570
  %7962 = load <8 x i1>, ptr %runnable.mask, align 1
  %7963 = xor <8 x i1> %7961, splat (i1 true)
  %7964 = and <8 x i1> %7962, %7963
  store <8 x i1> %7964, ptr %runnable.mask, align 1
  %.splatinsert1571 = insertelement <8 x i1> poison, i1 %7952, i64 0
  %.splat1572 = shufflevector <8 x i1> %.splatinsert1571, <8 x i1> poison, <8 x i32> zeroinitializer
  %7965 = select <8 x i1> %.splat1572, <8 x i1> %7947, <8 x i1> zeroinitializer
  %7966 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7967 = extractelement <8 x i32> %7966, i32 %7932
  %7968 = select i1 %7952, i32 %7967, i32 %7928
  store i32 %7968, ptr %current.token, align 4
  %.splatinsert1573 = insertelement <8 x i1> poison, i1 %7942, i64 0
  %.splat1574 = shufflevector <8 x i1> %.splatinsert1573, <8 x i1> poison, <8 x i32> zeroinitializer
  %7969 = select <8 x i1> %.splat1574, <8 x i1> %7965, <8 x i1> %convergence.cascade.flow1565
  %7970 = add i32 %convergence.cascade.depth1566, 1
  %7971 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7969)
  %7972 = icmp ult i32 %7970, 8
  %7973 = and i1 %7971, %7972
  %7974 = and i1 %7942, %7973
  %convergence.parent.token1575 = load i32, ptr %current.token, align 4
  %convergence.parent.present1576 = icmp ne i32 %convergence.parent.token1575, 0
  %7975 = and i1 %7974, %convergence.parent.present1576
  br i1 %7975, label %convergence.cascade1561, label %convergence.cascade.exit1562

convergence.cascade.exit1562:                     ; preds = %convergence.cascade1561, %schedule.107
  %convergence.cascade.result1577 = phi <8 x i1> [ %1993, %schedule.107 ], [ %7969, %convergence.cascade1561 ]
  %7976 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1577)
  br i1 %7976, label %convergence.target.107.ready, label %scheduler.loop

convergence.target.107.ready:                     ; preds = %convergence.cascade.exit1562
  %7977 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1577)
  %7978 = bitcast <8 x i1> %convergence.cascade.result1577 to i8
  %7979 = call i8 @llvm.cttz.i8(i8 %7978, i1 false)
  %7980 = zext i8 %7979 to i32
  %7981 = select i1 %7977, i32 %7980, i32 0
  %7982 = load <8 x i1>, ptr %live.mask, align 1
  %7983 = xor <8 x i1> %convergence.cascade.result1577, splat (i1 true)
  %7984 = and <8 x i1> %7982, %7983
  store <8 x i1> %7984, ptr %live.mask, align 1
  %7985 = load <8 x i1>, ptr %runnable.mask, align 1
  %7986 = xor <8 x i1> %convergence.cascade.result1577, splat (i1 true)
  %7987 = and <8 x i1> %7985, %7986
  store <8 x i1> %7987, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.107.ready
  %7988 = load i8, ptr %frame.active, align 1
  %7989 = and i8 %7988, 1
  %7990 = icmp ne i8 %7989, 0
  %7991 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %7992 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %7993 = load <8 x i1>, ptr %7991, align 1
  %7994 = load <8 x i1>, ptr %7992, align 1
  %7995 = and <8 x i1> %7993, %7984
  %7996 = icmp eq <8 x i1> %7994, %7995
  %7997 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7996)
  %7998 = and i1 %7990, %7997
  %.splatinsert1578 = insertelement <8 x i1> poison, i1 %7998, i64 0
  %.splat1579 = shufflevector <8 x i1> %.splatinsert1578, <8 x i1> poison, <8 x i32> zeroinitializer
  %7999 = select <8 x i1> %.splat1579, <8 x i1> %7994, <8 x i1> zeroinitializer
  %8000 = select i1 %7998, <8 x i1> zeroinitializer, <8 x i1> %7995
  store <8 x i1> %8000, ptr %7991, align 1
  %8001 = select i1 %7998, <8 x i1> zeroinitializer, <8 x i1> %7994
  store <8 x i1> %8001, ptr %7992, align 1
  %8002 = and i8 %7988, -2
  %8003 = select i1 %7998, i8 %8002, i8 %7988
  store i8 %8003, ptr %frame.active, align 1
  %8004 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8005 = extractelement <8 x i32> %8004, i32 0
  %8006 = load <8 x i32>, ptr %frame.static.id, align 32
  %8007 = extractelement <8 x i32> %8006, i32 0
  %convergence.target.pointer1580 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8007
  %convergence.dynamic.target1581 = load i32, ptr %convergence.target.pointer1580, align 4
  %8008 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7999)
  %8009 = load i32, ptr %ready.count, align 4
  %8010 = icmp uge i32 %8009, 8
  %8011 = and i1 %8008, %8010
  br i1 %8011, label %ready.overflow.trap1582, label %ready.overflow.resume1583

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume1625, %convergence.target.107.ready
  br label %scheduler.loop

ready.overflow.trap1582:                          ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume1583:                        ; preds = %return.frame.cleanup
  %8012 = select i1 %8008, i32 %8009, i32 0
  %8013 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8012
  %8014 = load <8 x i1>, ptr %8013, align 1
  %8015 = select i1 %8008, <8 x i1> %7999, <8 x i1> %8014
  store <8 x i1> %8015, ptr %8013, align 1
  %8016 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8012
  %8017 = load i32, ptr %8016, align 4
  %8018 = select i1 %8008, i32 %convergence.dynamic.target1581, i32 %8017
  store i32 %8018, ptr %8016, align 4
  %8019 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8012
  %8020 = load i32, ptr %8019, align 4
  %8021 = select i1 %8008, i32 %8005, i32 %8020
  store i32 %8021, ptr %8019, align 4
  %8022 = add i32 %8009, 1
  %8023 = select i1 %8008, i32 %8022, i32 %8009
  store i32 %8023, ptr %ready.count, align 4
  %8024 = load <8 x i1>, ptr %runnable.mask, align 1
  %8025 = or <8 x i1> %8024, %7999
  store <8 x i1> %8025, ptr %runnable.mask, align 1
  %8026 = load i8, ptr %frame.active, align 1
  %8027 = and i8 %8026, 2
  %8028 = icmp ne i8 %8027, 0
  %8029 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %8030 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %8031 = load <8 x i1>, ptr %8029, align 1
  %8032 = load <8 x i1>, ptr %8030, align 1
  %8033 = and <8 x i1> %8031, %7984
  %8034 = icmp eq <8 x i1> %8032, %8033
  %8035 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8034)
  %8036 = and i1 %8028, %8035
  %.splatinsert1584 = insertelement <8 x i1> poison, i1 %8036, i64 0
  %.splat1585 = shufflevector <8 x i1> %.splatinsert1584, <8 x i1> poison, <8 x i32> zeroinitializer
  %8037 = select <8 x i1> %.splat1585, <8 x i1> %8032, <8 x i1> zeroinitializer
  %8038 = select i1 %8036, <8 x i1> zeroinitializer, <8 x i1> %8033
  store <8 x i1> %8038, ptr %8029, align 1
  %8039 = select i1 %8036, <8 x i1> zeroinitializer, <8 x i1> %8032
  store <8 x i1> %8039, ptr %8030, align 1
  %8040 = and i8 %8026, -3
  %8041 = select i1 %8036, i8 %8040, i8 %8026
  store i8 %8041, ptr %frame.active, align 1
  %8042 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8043 = extractelement <8 x i32> %8042, i32 1
  %8044 = load <8 x i32>, ptr %frame.static.id, align 32
  %8045 = extractelement <8 x i32> %8044, i32 1
  %convergence.target.pointer1586 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8045
  %convergence.dynamic.target1587 = load i32, ptr %convergence.target.pointer1586, align 4
  %8046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8037)
  %8047 = load i32, ptr %ready.count, align 4
  %8048 = icmp uge i32 %8047, 8
  %8049 = and i1 %8046, %8048
  br i1 %8049, label %ready.overflow.trap1588, label %ready.overflow.resume1589

ready.overflow.trap1588:                          ; preds = %ready.overflow.resume1583
  call void @llvm.trap()
  unreachable

ready.overflow.resume1589:                        ; preds = %ready.overflow.resume1583
  %8050 = select i1 %8046, i32 %8047, i32 0
  %8051 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8050
  %8052 = load <8 x i1>, ptr %8051, align 1
  %8053 = select i1 %8046, <8 x i1> %8037, <8 x i1> %8052
  store <8 x i1> %8053, ptr %8051, align 1
  %8054 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8050
  %8055 = load i32, ptr %8054, align 4
  %8056 = select i1 %8046, i32 %convergence.dynamic.target1587, i32 %8055
  store i32 %8056, ptr %8054, align 4
  %8057 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8050
  %8058 = load i32, ptr %8057, align 4
  %8059 = select i1 %8046, i32 %8043, i32 %8058
  store i32 %8059, ptr %8057, align 4
  %8060 = add i32 %8047, 1
  %8061 = select i1 %8046, i32 %8060, i32 %8047
  store i32 %8061, ptr %ready.count, align 4
  %8062 = load <8 x i1>, ptr %runnable.mask, align 1
  %8063 = or <8 x i1> %8062, %8037
  store <8 x i1> %8063, ptr %runnable.mask, align 1
  %8064 = load i8, ptr %frame.active, align 1
  %8065 = and i8 %8064, 4
  %8066 = icmp ne i8 %8065, 0
  %8067 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %8068 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %8069 = load <8 x i1>, ptr %8067, align 1
  %8070 = load <8 x i1>, ptr %8068, align 1
  %8071 = and <8 x i1> %8069, %7984
  %8072 = icmp eq <8 x i1> %8070, %8071
  %8073 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8072)
  %8074 = and i1 %8066, %8073
  %.splatinsert1590 = insertelement <8 x i1> poison, i1 %8074, i64 0
  %.splat1591 = shufflevector <8 x i1> %.splatinsert1590, <8 x i1> poison, <8 x i32> zeroinitializer
  %8075 = select <8 x i1> %.splat1591, <8 x i1> %8070, <8 x i1> zeroinitializer
  %8076 = select i1 %8074, <8 x i1> zeroinitializer, <8 x i1> %8071
  store <8 x i1> %8076, ptr %8067, align 1
  %8077 = select i1 %8074, <8 x i1> zeroinitializer, <8 x i1> %8070
  store <8 x i1> %8077, ptr %8068, align 1
  %8078 = and i8 %8064, -5
  %8079 = select i1 %8074, i8 %8078, i8 %8064
  store i8 %8079, ptr %frame.active, align 1
  %8080 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8081 = extractelement <8 x i32> %8080, i32 2
  %8082 = load <8 x i32>, ptr %frame.static.id, align 32
  %8083 = extractelement <8 x i32> %8082, i32 2
  %convergence.target.pointer1592 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8083
  %convergence.dynamic.target1593 = load i32, ptr %convergence.target.pointer1592, align 4
  %8084 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8075)
  %8085 = load i32, ptr %ready.count, align 4
  %8086 = icmp uge i32 %8085, 8
  %8087 = and i1 %8084, %8086
  br i1 %8087, label %ready.overflow.trap1594, label %ready.overflow.resume1595

ready.overflow.trap1594:                          ; preds = %ready.overflow.resume1589
  call void @llvm.trap()
  unreachable

ready.overflow.resume1595:                        ; preds = %ready.overflow.resume1589
  %8088 = select i1 %8084, i32 %8085, i32 0
  %8089 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8088
  %8090 = load <8 x i1>, ptr %8089, align 1
  %8091 = select i1 %8084, <8 x i1> %8075, <8 x i1> %8090
  store <8 x i1> %8091, ptr %8089, align 1
  %8092 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8088
  %8093 = load i32, ptr %8092, align 4
  %8094 = select i1 %8084, i32 %convergence.dynamic.target1593, i32 %8093
  store i32 %8094, ptr %8092, align 4
  %8095 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8088
  %8096 = load i32, ptr %8095, align 4
  %8097 = select i1 %8084, i32 %8081, i32 %8096
  store i32 %8097, ptr %8095, align 4
  %8098 = add i32 %8085, 1
  %8099 = select i1 %8084, i32 %8098, i32 %8085
  store i32 %8099, ptr %ready.count, align 4
  %8100 = load <8 x i1>, ptr %runnable.mask, align 1
  %8101 = or <8 x i1> %8100, %8075
  store <8 x i1> %8101, ptr %runnable.mask, align 1
  %8102 = load i8, ptr %frame.active, align 1
  %8103 = and i8 %8102, 8
  %8104 = icmp ne i8 %8103, 0
  %8105 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %8106 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %8107 = load <8 x i1>, ptr %8105, align 1
  %8108 = load <8 x i1>, ptr %8106, align 1
  %8109 = and <8 x i1> %8107, %7984
  %8110 = icmp eq <8 x i1> %8108, %8109
  %8111 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8110)
  %8112 = and i1 %8104, %8111
  %.splatinsert1596 = insertelement <8 x i1> poison, i1 %8112, i64 0
  %.splat1597 = shufflevector <8 x i1> %.splatinsert1596, <8 x i1> poison, <8 x i32> zeroinitializer
  %8113 = select <8 x i1> %.splat1597, <8 x i1> %8108, <8 x i1> zeroinitializer
  %8114 = select i1 %8112, <8 x i1> zeroinitializer, <8 x i1> %8109
  store <8 x i1> %8114, ptr %8105, align 1
  %8115 = select i1 %8112, <8 x i1> zeroinitializer, <8 x i1> %8108
  store <8 x i1> %8115, ptr %8106, align 1
  %8116 = and i8 %8102, -9
  %8117 = select i1 %8112, i8 %8116, i8 %8102
  store i8 %8117, ptr %frame.active, align 1
  %8118 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8119 = extractelement <8 x i32> %8118, i32 3
  %8120 = load <8 x i32>, ptr %frame.static.id, align 32
  %8121 = extractelement <8 x i32> %8120, i32 3
  %convergence.target.pointer1598 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8121
  %convergence.dynamic.target1599 = load i32, ptr %convergence.target.pointer1598, align 4
  %8122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8113)
  %8123 = load i32, ptr %ready.count, align 4
  %8124 = icmp uge i32 %8123, 8
  %8125 = and i1 %8122, %8124
  br i1 %8125, label %ready.overflow.trap1600, label %ready.overflow.resume1601

ready.overflow.trap1600:                          ; preds = %ready.overflow.resume1595
  call void @llvm.trap()
  unreachable

ready.overflow.resume1601:                        ; preds = %ready.overflow.resume1595
  %8126 = select i1 %8122, i32 %8123, i32 0
  %8127 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8126
  %8128 = load <8 x i1>, ptr %8127, align 1
  %8129 = select i1 %8122, <8 x i1> %8113, <8 x i1> %8128
  store <8 x i1> %8129, ptr %8127, align 1
  %8130 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8126
  %8131 = load i32, ptr %8130, align 4
  %8132 = select i1 %8122, i32 %convergence.dynamic.target1599, i32 %8131
  store i32 %8132, ptr %8130, align 4
  %8133 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8126
  %8134 = load i32, ptr %8133, align 4
  %8135 = select i1 %8122, i32 %8119, i32 %8134
  store i32 %8135, ptr %8133, align 4
  %8136 = add i32 %8123, 1
  %8137 = select i1 %8122, i32 %8136, i32 %8123
  store i32 %8137, ptr %ready.count, align 4
  %8138 = load <8 x i1>, ptr %runnable.mask, align 1
  %8139 = or <8 x i1> %8138, %8113
  store <8 x i1> %8139, ptr %runnable.mask, align 1
  %8140 = load i8, ptr %frame.active, align 1
  %8141 = and i8 %8140, 16
  %8142 = icmp ne i8 %8141, 0
  %8143 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %8144 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %8145 = load <8 x i1>, ptr %8143, align 1
  %8146 = load <8 x i1>, ptr %8144, align 1
  %8147 = and <8 x i1> %8145, %7984
  %8148 = icmp eq <8 x i1> %8146, %8147
  %8149 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8148)
  %8150 = and i1 %8142, %8149
  %.splatinsert1602 = insertelement <8 x i1> poison, i1 %8150, i64 0
  %.splat1603 = shufflevector <8 x i1> %.splatinsert1602, <8 x i1> poison, <8 x i32> zeroinitializer
  %8151 = select <8 x i1> %.splat1603, <8 x i1> %8146, <8 x i1> zeroinitializer
  %8152 = select i1 %8150, <8 x i1> zeroinitializer, <8 x i1> %8147
  store <8 x i1> %8152, ptr %8143, align 1
  %8153 = select i1 %8150, <8 x i1> zeroinitializer, <8 x i1> %8146
  store <8 x i1> %8153, ptr %8144, align 1
  %8154 = and i8 %8140, -17
  %8155 = select i1 %8150, i8 %8154, i8 %8140
  store i8 %8155, ptr %frame.active, align 1
  %8156 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8157 = extractelement <8 x i32> %8156, i32 4
  %8158 = load <8 x i32>, ptr %frame.static.id, align 32
  %8159 = extractelement <8 x i32> %8158, i32 4
  %convergence.target.pointer1604 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8159
  %convergence.dynamic.target1605 = load i32, ptr %convergence.target.pointer1604, align 4
  %8160 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8151)
  %8161 = load i32, ptr %ready.count, align 4
  %8162 = icmp uge i32 %8161, 8
  %8163 = and i1 %8160, %8162
  br i1 %8163, label %ready.overflow.trap1606, label %ready.overflow.resume1607

ready.overflow.trap1606:                          ; preds = %ready.overflow.resume1601
  call void @llvm.trap()
  unreachable

ready.overflow.resume1607:                        ; preds = %ready.overflow.resume1601
  %8164 = select i1 %8160, i32 %8161, i32 0
  %8165 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8164
  %8166 = load <8 x i1>, ptr %8165, align 1
  %8167 = select i1 %8160, <8 x i1> %8151, <8 x i1> %8166
  store <8 x i1> %8167, ptr %8165, align 1
  %8168 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8164
  %8169 = load i32, ptr %8168, align 4
  %8170 = select i1 %8160, i32 %convergence.dynamic.target1605, i32 %8169
  store i32 %8170, ptr %8168, align 4
  %8171 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8164
  %8172 = load i32, ptr %8171, align 4
  %8173 = select i1 %8160, i32 %8157, i32 %8172
  store i32 %8173, ptr %8171, align 4
  %8174 = add i32 %8161, 1
  %8175 = select i1 %8160, i32 %8174, i32 %8161
  store i32 %8175, ptr %ready.count, align 4
  %8176 = load <8 x i1>, ptr %runnable.mask, align 1
  %8177 = or <8 x i1> %8176, %8151
  store <8 x i1> %8177, ptr %runnable.mask, align 1
  %8178 = load i8, ptr %frame.active, align 1
  %8179 = and i8 %8178, 32
  %8180 = icmp ne i8 %8179, 0
  %8181 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %8182 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %8183 = load <8 x i1>, ptr %8181, align 1
  %8184 = load <8 x i1>, ptr %8182, align 1
  %8185 = and <8 x i1> %8183, %7984
  %8186 = icmp eq <8 x i1> %8184, %8185
  %8187 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8186)
  %8188 = and i1 %8180, %8187
  %.splatinsert1608 = insertelement <8 x i1> poison, i1 %8188, i64 0
  %.splat1609 = shufflevector <8 x i1> %.splatinsert1608, <8 x i1> poison, <8 x i32> zeroinitializer
  %8189 = select <8 x i1> %.splat1609, <8 x i1> %8184, <8 x i1> zeroinitializer
  %8190 = select i1 %8188, <8 x i1> zeroinitializer, <8 x i1> %8185
  store <8 x i1> %8190, ptr %8181, align 1
  %8191 = select i1 %8188, <8 x i1> zeroinitializer, <8 x i1> %8184
  store <8 x i1> %8191, ptr %8182, align 1
  %8192 = and i8 %8178, -33
  %8193 = select i1 %8188, i8 %8192, i8 %8178
  store i8 %8193, ptr %frame.active, align 1
  %8194 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8195 = extractelement <8 x i32> %8194, i32 5
  %8196 = load <8 x i32>, ptr %frame.static.id, align 32
  %8197 = extractelement <8 x i32> %8196, i32 5
  %convergence.target.pointer1610 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8197
  %convergence.dynamic.target1611 = load i32, ptr %convergence.target.pointer1610, align 4
  %8198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8189)
  %8199 = load i32, ptr %ready.count, align 4
  %8200 = icmp uge i32 %8199, 8
  %8201 = and i1 %8198, %8200
  br i1 %8201, label %ready.overflow.trap1612, label %ready.overflow.resume1613

ready.overflow.trap1612:                          ; preds = %ready.overflow.resume1607
  call void @llvm.trap()
  unreachable

ready.overflow.resume1613:                        ; preds = %ready.overflow.resume1607
  %8202 = select i1 %8198, i32 %8199, i32 0
  %8203 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8202
  %8204 = load <8 x i1>, ptr %8203, align 1
  %8205 = select i1 %8198, <8 x i1> %8189, <8 x i1> %8204
  store <8 x i1> %8205, ptr %8203, align 1
  %8206 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8202
  %8207 = load i32, ptr %8206, align 4
  %8208 = select i1 %8198, i32 %convergence.dynamic.target1611, i32 %8207
  store i32 %8208, ptr %8206, align 4
  %8209 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8202
  %8210 = load i32, ptr %8209, align 4
  %8211 = select i1 %8198, i32 %8195, i32 %8210
  store i32 %8211, ptr %8209, align 4
  %8212 = add i32 %8199, 1
  %8213 = select i1 %8198, i32 %8212, i32 %8199
  store i32 %8213, ptr %ready.count, align 4
  %8214 = load <8 x i1>, ptr %runnable.mask, align 1
  %8215 = or <8 x i1> %8214, %8189
  store <8 x i1> %8215, ptr %runnable.mask, align 1
  %8216 = load i8, ptr %frame.active, align 1
  %8217 = and i8 %8216, 64
  %8218 = icmp ne i8 %8217, 0
  %8219 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %8220 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %8221 = load <8 x i1>, ptr %8219, align 1
  %8222 = load <8 x i1>, ptr %8220, align 1
  %8223 = and <8 x i1> %8221, %7984
  %8224 = icmp eq <8 x i1> %8222, %8223
  %8225 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8224)
  %8226 = and i1 %8218, %8225
  %.splatinsert1614 = insertelement <8 x i1> poison, i1 %8226, i64 0
  %.splat1615 = shufflevector <8 x i1> %.splatinsert1614, <8 x i1> poison, <8 x i32> zeroinitializer
  %8227 = select <8 x i1> %.splat1615, <8 x i1> %8222, <8 x i1> zeroinitializer
  %8228 = select i1 %8226, <8 x i1> zeroinitializer, <8 x i1> %8223
  store <8 x i1> %8228, ptr %8219, align 1
  %8229 = select i1 %8226, <8 x i1> zeroinitializer, <8 x i1> %8222
  store <8 x i1> %8229, ptr %8220, align 1
  %8230 = and i8 %8216, -65
  %8231 = select i1 %8226, i8 %8230, i8 %8216
  store i8 %8231, ptr %frame.active, align 1
  %8232 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8233 = extractelement <8 x i32> %8232, i32 6
  %8234 = load <8 x i32>, ptr %frame.static.id, align 32
  %8235 = extractelement <8 x i32> %8234, i32 6
  %convergence.target.pointer1616 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8235
  %convergence.dynamic.target1617 = load i32, ptr %convergence.target.pointer1616, align 4
  %8236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8227)
  %8237 = load i32, ptr %ready.count, align 4
  %8238 = icmp uge i32 %8237, 8
  %8239 = and i1 %8236, %8238
  br i1 %8239, label %ready.overflow.trap1618, label %ready.overflow.resume1619

ready.overflow.trap1618:                          ; preds = %ready.overflow.resume1613
  call void @llvm.trap()
  unreachable

ready.overflow.resume1619:                        ; preds = %ready.overflow.resume1613
  %8240 = select i1 %8236, i32 %8237, i32 0
  %8241 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8240
  %8242 = load <8 x i1>, ptr %8241, align 1
  %8243 = select i1 %8236, <8 x i1> %8227, <8 x i1> %8242
  store <8 x i1> %8243, ptr %8241, align 1
  %8244 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8240
  %8245 = load i32, ptr %8244, align 4
  %8246 = select i1 %8236, i32 %convergence.dynamic.target1617, i32 %8245
  store i32 %8246, ptr %8244, align 4
  %8247 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8240
  %8248 = load i32, ptr %8247, align 4
  %8249 = select i1 %8236, i32 %8233, i32 %8248
  store i32 %8249, ptr %8247, align 4
  %8250 = add i32 %8237, 1
  %8251 = select i1 %8236, i32 %8250, i32 %8237
  store i32 %8251, ptr %ready.count, align 4
  %8252 = load <8 x i1>, ptr %runnable.mask, align 1
  %8253 = or <8 x i1> %8252, %8227
  store <8 x i1> %8253, ptr %runnable.mask, align 1
  %8254 = load i8, ptr %frame.active, align 1
  %8255 = and i8 %8254, -128
  %8256 = icmp ne i8 %8255, 0
  %8257 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %8258 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %8259 = load <8 x i1>, ptr %8257, align 1
  %8260 = load <8 x i1>, ptr %8258, align 1
  %8261 = and <8 x i1> %8259, %7984
  %8262 = icmp eq <8 x i1> %8260, %8261
  %8263 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8262)
  %8264 = and i1 %8256, %8263
  %.splatinsert1620 = insertelement <8 x i1> poison, i1 %8264, i64 0
  %.splat1621 = shufflevector <8 x i1> %.splatinsert1620, <8 x i1> poison, <8 x i32> zeroinitializer
  %8265 = select <8 x i1> %.splat1621, <8 x i1> %8260, <8 x i1> zeroinitializer
  %8266 = select i1 %8264, <8 x i1> zeroinitializer, <8 x i1> %8261
  store <8 x i1> %8266, ptr %8257, align 1
  %8267 = select i1 %8264, <8 x i1> zeroinitializer, <8 x i1> %8260
  store <8 x i1> %8267, ptr %8258, align 1
  %8268 = and i8 %8254, 127
  %8269 = select i1 %8264, i8 %8268, i8 %8254
  store i8 %8269, ptr %frame.active, align 1
  %8270 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8271 = extractelement <8 x i32> %8270, i32 7
  %8272 = load <8 x i32>, ptr %frame.static.id, align 32
  %8273 = extractelement <8 x i32> %8272, i32 7
  %convergence.target.pointer1622 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8273
  %convergence.dynamic.target1623 = load i32, ptr %convergence.target.pointer1622, align 4
  %8274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8265)
  %8275 = load i32, ptr %ready.count, align 4
  %8276 = icmp uge i32 %8275, 8
  %8277 = and i1 %8274, %8276
  br i1 %8277, label %ready.overflow.trap1624, label %ready.overflow.resume1625

ready.overflow.trap1624:                          ; preds = %ready.overflow.resume1619
  call void @llvm.trap()
  unreachable

ready.overflow.resume1625:                        ; preds = %ready.overflow.resume1619
  %8278 = select i1 %8274, i32 %8275, i32 0
  %8279 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8278
  %8280 = load <8 x i1>, ptr %8279, align 1
  %8281 = select i1 %8274, <8 x i1> %8265, <8 x i1> %8280
  store <8 x i1> %8281, ptr %8279, align 1
  %8282 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8278
  %8283 = load i32, ptr %8282, align 4
  %8284 = select i1 %8274, i32 %convergence.dynamic.target1623, i32 %8283
  store i32 %8284, ptr %8282, align 4
  %8285 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8278
  %8286 = load i32, ptr %8285, align 4
  %8287 = select i1 %8274, i32 %8271, i32 %8286
  store i32 %8287, ptr %8285, align 4
  %8288 = add i32 %8275, 1
  %8289 = select i1 %8274, i32 %8288, i32 %8275
  store i32 %8289, ptr %ready.count, align 4
  %8290 = load <8 x i1>, ptr %runnable.mask, align 1
  %8291 = or <8 x i1> %8290, %8265
  store <8 x i1> %8291, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr>, <8 x i1>, <8 x i64>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #4

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

define dso_local void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

# 2D MMA validation checkpoint

2026-09-13. Main branch next, base cdd6d51cc plus the ten owned 2D MMA
implementation/test changes. Selected isolated build:
`/tmp/luisa-next-integration.roZbN8/build`. Protected TIRx WIP and upstream
commits absent from this export were not incorporated. No GPU execution.

The first full build failed in the new host test because `format` lacked its
declaring header. `build.log` is retained. The test adds the formatting header
and uses existing `is_int64()`/`is_float32()` type predicates, avoiding an
unnecessary template specialization dependency. The numerical/work oracle
was not loosened. A second full build succeeds (`build-retry1.log`).

Four relevant CTests pass in 142.88 seconds: SIMD schedule codegen 37.71 s,
XIR target info 0.61 s, SIMD Tile Runtime 66.31 s, SIMD Tile LLM 38.24 s.
The target-info test was also run alone after the full build (1.53 s).
Its new matrix contains 96 plan/lower configurations, plus explicit fallback
and zero-K SSA-layout checks. The new runtime test executes 60 dispatches.

Seven exact-name host checks pass with nonzero assertions (respectively
5, 21, 220, 183, 9900, 24, 46). Each reports 19 unrelated tests skipped;
none is accepted as a zero-assertion pass. Logs name the individual tests.
Two previously recorded host SSA-budget fatal tests remain outside this gate;
this is not a claim that the full repository test suite passes.

Seven changed translation units receive clangd/clang-tidy checks: lower,
planner, both backend forwarding units, the benchmark, and both test units.
All report zero errors; warnings are retained. All ten changed C++ files pass
clang-format --dry-run --Werror; git diff --check passes. The temporary LSP
server and its clangd child were stopped before native timing.

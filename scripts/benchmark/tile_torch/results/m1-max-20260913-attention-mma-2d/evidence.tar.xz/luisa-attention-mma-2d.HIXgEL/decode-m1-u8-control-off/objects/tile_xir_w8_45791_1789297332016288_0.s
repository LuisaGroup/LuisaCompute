	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.full_packet
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention.full_packet:             ; @llm_attention.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2080
	mov	x8, #0                          ; =0x0
	ldr	x21, [x1, #136]
	ldr	x9, [x0]
	ldr	x20, [x0, #16]
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
	ldr	x22, [x0, #32]
	ldr	x11, [x0, #48]
	str	x11, [sp, #8]                   ; 8-byte Spill
	dup.4s	v0, w10
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x10, lCPI0_0@PAGEOFF]
	add.4s	v3, v0, v1
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x10, lCPI0_1@PAGEOFF]
	add.4s	v2, v0, v1
	ushll2.2d	v1, v2, #0
	ushll2.2d	v0, v3, #0
	stp	q0, q1, [sp, #48]               ; 32-byte Folded Spill
	ushll.2d	v1, v2, #0
	ushll.2d	v0, v3, #0
	stp	q0, q1, [sp, #16]               ; 32-byte Folded Spill
	movi.4s	v1, #80
	umull2.2d	v0, v2, v1
	umull2.2d	v1, v3, v1
	movi.2s	v4, #80
	umull.2d	v2, v2, v4
	umull.2d	v3, v3, v4
	dup.2d	v4, x9
LBB0_1:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v5, x8
	add.2d	v6, v5, v0
	add.2d	v7, v5, v2
	add.2d	v16, v5, v1
	add.2d	v5, v5, v3
	shl.2d	v5, v5, #2
	shl.2d	v16, v16, #2
	shl.2d	v7, v7, #2
	shl.2d	v6, v6, #2
	add.2d	v6, v4, v6
	add.2d	v7, v4, v7
	add.2d	v16, v4, v16
	add.2d	v5, v4, v5
	mov.d	x9, v5[1]
	fmov	x10, d5
	mov.d	x11, v16[1]
	fmov	x12, d16
	mov.d	x13, v7[1]
	fmov	x14, d7
	mov.d	x15, v6[1]
	ldr	s5, [x10]
	ld1.s	{ v5 }[1], [x9]
	fmov	x9, d6
	ld1.s	{ v5 }[2], [x12]
	ld1.s	{ v5 }[3], [x11]
	ldr	s6, [x14]
	ld1.s	{ v6 }[1], [x13]
	ld1.s	{ v6 }[2], [x9]
	ld1.s	{ v6 }[3], [x15]
	add	x9, x21, x8, lsl #5
	stp	q5, q6, [x9]
	add	x8, x8, #1
	cmp	x8, #80
	b.ne	LBB0_1
; %bb.2:                                ; %direct.true147.preheader
	add	x23, x21, #2560
	add	x0, x21, #2560
	mov	w1, #3072                       ; =0xc00
	bl	_bzero
	mov	x17, #0                         ; =0x0
	mov	w8, #8704                       ; =0x2200
	add	x25, x21, x8
	mov	w8, #49664                      ; =0xc200
	add	x26, x21, x8
	add	x8, x21, #24, lsl #12           ; =98304
	add	x19, x8, #1536
	ldp	q2, q0, [sp, #48]               ; 32-byte Folded Reload
	shrn.2s	v0, v0, #2
	ldp	q3, q1, [sp, #16]               ; 32-byte Folded Reload
	shrn.2s	v1, v1, #2
	shrn.2s	v2, v2, #2
	mov	w8, #2053                       ; =0x805
	shrn.2s	v3, v3, #2
	mov	w9, #49760                      ; =0xc260
	add	x9, x21, x9
	str	x9, [sp, #472]                  ; 8-byte Spill
	mov	w10, #62154                     ; =0xf2ca
	movk	w10, #61769, lsl #16
	add	x9, x21, #24, lsl #12           ; =98304
	dup.2s	v4, w8
	add	x8, x9, #512
	str	x8, [sp, #464]                  ; 8-byte Spill
	add	x8, x21, #24, lsl #12           ; =98304
	umull.2d	v5, v3, v4
	add	x8, x8, #544
	str	x8, [sp, #440]                  ; 8-byte Spill
	add	x8, x21, #24, lsl #12           ; =98304
	umull.2d	v6, v2, v4
	add	x8, x8, #576
	str	x8, [sp, #408]                  ; 8-byte Spill
	add	x8, x21, #24, lsl #12           ; =98304
	umull.2d	v7, v1, v4
	add	x8, x8, #608
	str	x8, [sp, #376]                  ; 8-byte Spill
	add	x8, x21, #24, lsl #12           ; =98304
	umull.2d	v16, v0, v4
	add	x9, x8, #640
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #672
	stp	x8, x9, [sp, #336]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	dup.4s	v1, w10
	add	x9, x8, #704
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #736
	stp	x8, x9, [sp, #320]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #768
	str	x8, [sp, #312]                  ; 8-byte Spill
	add	x8, x21, #24, lsl #12           ; =98304
	dup.2d	v17, x20
	add	x9, x8, #800
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #832
	stp	x8, x9, [sp, #272]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #864
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #896
	stp	x8, x9, [sp, #256]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #928
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #960
	stp	x8, x9, [sp, #240]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #992
	str	x8, [sp, #232]                  ; 8-byte Spill
	mvni.4s	v0, #63, msl #16
	add	x8, x21, #24, lsl #12           ; =98304
	fneg.4s	v0, v0
	str	q0, [sp, #208]                  ; 16-byte Spill
	add	x9, x8, #1056
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1088
	stp	x8, x9, [sp, #192]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1120
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1152
	stp	x8, x9, [sp, #176]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1184
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1216
	stp	x8, x9, [sp, #160]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1248
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1280
	stp	x8, x9, [sp, #144]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1312
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1344
	stp	x8, x9, [sp, #128]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1376
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1408
	stp	x8, x9, [sp, #112]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1440
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1472
	stp	x8, x9, [sp, #96]               ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1504
	str	x8, [sp, #88]                   ; 8-byte Spill
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	mov.16b	v0, v1
	mov	w8, #33792                      ; =0x8400
	movk	w8, #1, lsl #16
	add	x20, x21, x8
	mov	w27, #52429                     ; =0xcccd
	mov	w0, #80                         ; =0x50
	mov	w28, #43691                     ; =0xaaab
	mov	w1, #96                         ; =0x60
	mov	w24, #3                         ; =0x3
	str	q5, [sp, #448]                  ; 16-byte Spill
	str	q6, [sp, #416]                  ; 16-byte Spill
	str	q7, [sp, #384]                  ; 16-byte Spill
	str	q16, [sp, #352]                 ; 16-byte Spill
	str	q17, [sp, #288]                 ; 16-byte Spill
LBB0_3:                                 ; %direct.true157
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_12 Depth 2
                                        ;     Child Loop BB0_14 Depth 2
                                        ;     Child Loop BB0_16 Depth 2
                                        ;     Child Loop BB0_18 Depth 2
                                        ;     Child Loop BB0_20 Depth 2
                                        ;       Child Loop BB0_21 Depth 3
	str	q0, [sp, #2000]                 ; 16-byte Spill
	str	q1, [sp, #2016]                 ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	lsl	x8, x17, #4
	b	LBB0_5
LBB0_4:                                 ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_5 Depth=2
	add	x10, x25, x9, lsl #5
	stp	q0, q1, [x10]
	add	x9, x9, #1
	cmp	x9, #1280
	b.eq	LBB0_7
LBB0_5:                                 ; %direct.true161
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w10, w9, #0xffff
	mul	w10, w10, w27
	lsr	w10, w10, #22
	add	x11, x8, x10
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	cmp	x11, #2052
	b.hi	LBB0_4
; %bb.6:                                ; %direct.true174
                                        ;   in Loop: Header=BB0_5 Depth=2
	dup.2d	v0, x11
	add.2d	v1, v0, v16
	add.2d	v2, v0, v7
	add.2d	v3, v0, v6
	add.2d	v0, v0, v5
	mov.d	x11, v0[1]
	fmov	x12, d0
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	fmov	d0, x12
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	mov.d	v0[1], x11
	mov.d	x11, v3[1]
	fmov	x12, d3
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	fmov	d3, x12
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	mov.d	v3[1], x11
	mov.d	x11, v2[1]
	fmov	x12, d2
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	fmov	d2, x12
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	mov.d	v2[1], x11
	mov.d	x11, v1[1]
	fmov	x12, d1
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	fmov	d1, x12
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	mov.d	v1[1], x11
	msub	w10, w10, w0, w9
	and	x10, x10, #0xffff
	dup.2d	v4, x10
	add.2d	v1, v1, v4
	add.2d	v2, v2, v4
	add.2d	v3, v3, v4
	add.2d	v0, v0, v4
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	add.2d	v1, v17, v1
	add.2d	v2, v17, v2
	add.2d	v3, v17, v3
	add.2d	v0, v17, v0
	mov.d	x10, v0[1]
	fmov	x11, d0
	mov.d	x12, v3[1]
	fmov	x13, d3
	mov.d	x14, v2[1]
	fmov	x15, d2
	mov.d	x16, v1[1]
	ldr	s0, [x11]
	ld1.s	{ v0 }[1], [x10]
	fmov	x10, d1
	ld1.s	{ v0 }[2], [x13]
	ld1.s	{ v0 }[3], [x12]
	ldr	s1, [x15]
	ld1.s	{ v1 }[1], [x14]
	ld1.s	{ v1 }[2], [x10]
	ld1.s	{ v1 }[3], [x16]
	b	LBB0_4
LBB0_7:                                 ; %direct.true186.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	b	LBB0_9
LBB0_8:                                 ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_9 Depth=2
	add	x10, x26, x9, lsl #5
	stp	q0, q1, [x10]
	add	x9, x9, #1
	cmp	x9, #1536
	b.eq	LBB0_11
LBB0_9:                                 ; %direct.true186
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w10, w9, #0xffff
	mul	w10, w10, w28
	lsr	w10, w10, #22
	add	x11, x8, x10
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	cmp	x11, #2052
	b.hi	LBB0_8
; %bb.10:                               ; %direct.true199
                                        ;   in Loop: Header=BB0_9 Depth=2
	dup.2d	v0, x11
	add.2d	v1, v0, v16
	add.2d	v2, v0, v7
	add.2d	v3, v0, v6
	add.2d	v0, v0, v5
	mov.d	x11, v0[1]
	fmov	x12, d0
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	fmov	d0, x12
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v0[1], x11
	mov.d	x11, v3[1]
	fmov	x12, d3
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	fmov	d3, x12
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v3[1], x11
	mov.d	x11, v2[1]
	fmov	x12, d2
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	fmov	d2, x12
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v2[1], x11
	mov.d	x11, v1[1]
	fmov	x12, d1
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	fmov	d1, x12
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v1[1], x11
	msub	w10, w10, w1, w9
	and	x10, x10, #0xffff
	dup.2d	v4, x10
	add.2d	v1, v1, v4
	add.2d	v2, v2, v4
	add.2d	v3, v3, v4
	add.2d	v0, v0, v4
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v4, x22
	add.2d	v1, v4, v1
	add.2d	v2, v4, v2
	add.2d	v3, v4, v3
	add.2d	v0, v4, v0
	mov.d	x10, v0[1]
	fmov	x11, d0
	mov.d	x12, v3[1]
	fmov	x13, d3
	mov.d	x14, v2[1]
	fmov	x15, d2
	mov.d	x16, v1[1]
	ldr	s0, [x11]
	ld1.s	{ v0 }[1], [x10]
	fmov	x10, d1
	ld1.s	{ v0 }[2], [x13]
	ld1.s	{ v0 }[3], [x12]
	ldr	s1, [x15]
	ld1.s	{ v1 }[1], [x14]
	ld1.s	{ v1 }[2], [x10]
	ld1.s	{ v1 }[3], [x16]
	b	LBB0_8
LBB0_11:                                ; %direct.true211.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q20, [sp, #1520]                ; 16-byte Spill
	str	q19, [sp, #1536]                ; 16-byte Spill
	movi.2d	v1, #0000000000000000
	mov	x8, x21
	movi.2d	v0, #0000000000000000
	mov	w9, #80                         ; =0x50
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
LBB0_12:                                ; %direct.true211
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q16, [x8]
	ldr	q18, [x8, #8720]
	ldr	q19, [x8, #8704]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v1, v1, v18
	fadd.4s	v7, v7, v19
	ldr	q18, [x8, #11280]
	ldr	q19, [x8, #11264]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v5, v5, v19
	ldr	q18, [x8, #13840]
	ldr	q19, [x8, #13824]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v19
	ldr	q18, [x8, #16400]
	ldr	q19, [x8, #16384]
	fmul.4s	v17, v17, v19
	fmul.4s	v16, v16, v18
	fadd.4s	v2, v2, v16
	fadd.4s	v0, v0, v17
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_12
; %bb.13:                               ; %direct.true247.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v17, #0000000000000000
	mov	x8, x21
	movi.2d	v16, #0000000000000000
	mov	w9, #80                         ; =0x50
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
LBB0_14:                                ; %direct.true247
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q25, q24, [x8]
	ldr	q26, [x8, #18960]
	ldr	q27, [x8, #18944]
	fmul.4s	v27, v25, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v17, v17, v26
	fadd.4s	v23, v23, v27
	ldr	q26, [x8, #21520]
	ldr	q27, [x8, #21504]
	fmul.4s	v27, v25, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v21, v21, v27
	ldr	q26, [x8, #24080]
	ldr	q27, [x8, #24064]
	fmul.4s	v27, v25, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v20, v20, v26
	fadd.4s	v19, v19, v27
	ldr	q26, [x8, #26640]
	ldr	q27, [x8, #26624]
	fmul.4s	v25, v25, v27
	fmul.4s	v24, v24, v26
	fadd.4s	v18, v18, v24
	fadd.4s	v16, v16, v25
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_14
; %bb.15:                               ; %direct.true285.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q3, [sp, #1984]                 ; 16-byte Spill
	str	q2, [sp, #2032]                 ; 16-byte Spill
	str	q1, [sp, #2048]                 ; 16-byte Spill
	movi.2d	v25, #0000000000000000
	mov	x8, x21
	movi.2d	v24, #0000000000000000
	mov	w9, #80                         ; =0x50
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
LBB0_16:                                ; %direct.true285
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q9, q8, [x8]
	ldr	q10, [x8, #29200]
	ldr	q11, [x8, #29184]
	fmul.4s	v11, v9, v11
	fmul.4s	v10, v8, v10
	fadd.4s	v25, v25, v10
	fadd.4s	v31, v31, v11
	ldr	q10, [x8, #31760]
	ldr	q11, [x8, #31744]
	fmul.4s	v11, v9, v11
	fmul.4s	v10, v8, v10
	fadd.4s	v30, v30, v10
	fadd.4s	v29, v29, v11
	ldr	q10, [x8, #34320]
	ldr	q11, [x8, #34304]
	fmul.4s	v11, v9, v11
	fmul.4s	v10, v8, v10
	fadd.4s	v28, v28, v10
	fadd.4s	v27, v27, v11
	ldr	q10, [x8, #36880]
	ldr	q11, [x8, #36864]
	fmul.4s	v9, v9, v11
	fmul.4s	v8, v8, v10
	fadd.4s	v26, v26, v8
	fadd.4s	v24, v24, v9
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_16
; %bb.17:                               ; %direct.true323.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q0, [sp, #2064]                 ; 16-byte Spill
	movi.2d	v9, #0000000000000000
	mov	x8, x21
	movi.2d	v8, #0000000000000000
	mov	w9, #80                         ; =0x50
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v15, #0000000000000000
LBB0_18:                                ; %direct.true323
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8]
	ldr	q2, [x8, #39440]
	ldr	q3, [x8, #39424]
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fadd.4s	v9, v9, v2
	fadd.4s	v15, v15, v3
	ldr	q2, [x8, #42000]
	ldr	q3, [x8, #41984]
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fadd.4s	v14, v14, v2
	fadd.4s	v13, v13, v3
	ldr	q2, [x8, #44560]
	ldr	q3, [x8, #44544]
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fadd.4s	v12, v12, v2
	fadd.4s	v11, v11, v3
	ldr	q2, [x8, #47120]
	ldr	q3, [x8, #47104]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v10, v10, v0
	fadd.4s	v8, v8, v1
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_18
; %bb.19:                               ; %direct.false324
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	mov	w9, #63790                      ; =0xf92e
	movk	w9, #15844, lsl #16
	dup.4s	v0, w9
	fmul.4s	v1, v7, v0
	str	q1, [sp, #1824]                 ; 16-byte Spill
	ldr	q1, [sp, #2048]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1648]                 ; 16-byte Spill
	fmul.4s	v1, v5, v0
	str	q1, [sp, #1632]                 ; 16-byte Spill
	fmul.4s	v1, v6, v0
	str	q1, [sp, #1616]                 ; 16-byte Spill
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1600]                 ; 16-byte Spill
	fmul.4s	v1, v4, v0
	str	q1, [sp, #1584]                 ; 16-byte Spill
	ldr	q1, [sp, #2064]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #2064]                 ; 16-byte Spill
	ldr	q1, [sp, #2032]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1568]                 ; 16-byte Spill
	fmul.4s	v1, v23, v0
	str	q1, [sp, #2048]                 ; 16-byte Spill
	fmul.4s	v1, v17, v0
	str	q1, [sp, #2032]                 ; 16-byte Spill
	fmul.4s	v1, v22, v0
	fmul.4s	v3, v21, v0
	fmul.4s	v4, v20, v0
	fmul.4s	v5, v19, v0
	fmul.4s	v6, v18, v0
	fmul.4s	v7, v16, v0
	fmul.4s	v16, v25, v0
	fmul.4s	v17, v31, v0
	fmul.4s	v18, v30, v0
	fmul.4s	v19, v29, v0
	fmul.4s	v20, v28, v0
	fmul.4s	v21, v27, v0
	fmul.4s	v22, v26, v0
	fmul.4s	v23, v24, v0
	fmul.4s	v24, v9, v0
	fmul.4s	v25, v15, v0
	fmul.4s	v26, v14, v0
	fmul.4s	v27, v13, v0
	fmul.4s	v28, v12, v0
	fmul.4s	v29, v11, v0
	fmul.4s	v30, v10, v0
	fmul.4s	v0, v8, v0
	str	x17, [sp, #1560]                ; 8-byte Spill
	cmp	x17, #128
	cset	w9, lo
	dup.4h	v2, w9
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v8, v2, #0
	str	q8, [sp, #560]                  ; 16-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v31, w9
	mov.16b	v2, v8
	bsl.16b	v2, v3, v31
	str	q2, [sp, #1984]                 ; 16-byte Spill
	mov.16b	v11, v8
	bsl.16b	v11, v1, v31
	mov.16b	v3, v8
	bsl.16b	v3, v5, v31
	str	q3, [sp, #1904]                 ; 16-byte Spill
	mov.16b	v10, v8
	bsl.16b	v10, v4, v31
	str	q10, [sp, #1664]                ; 16-byte Spill
	mov.16b	v4, v8
	bsl.16b	v4, v7, v31
	str	q4, [sp, #1968]                 ; 16-byte Spill
	mov.16b	v9, v8
	bsl.16b	v9, v6, v31
	str	q9, [sp, #1680]                 ; 16-byte Spill
	mov.16b	v6, v8
	bsl.16b	v6, v17, v31
	str	q6, [sp, #1888]                 ; 16-byte Spill
	mov.16b	v17, v8
	bsl.16b	v17, v16, v31
	str	q17, [sp, #1696]                ; 16-byte Spill
	mov.16b	v7, v8
	bsl.16b	v7, v19, v31
	str	q7, [sp, #1952]                 ; 16-byte Spill
	bif.16b	v18, v31, v8
	str	q18, [sp, #1712]                ; 16-byte Spill
	mov.16b	v16, v8
	bsl.16b	v16, v21, v31
	str	q16, [sp, #1872]                ; 16-byte Spill
	bif.16b	v20, v31, v8
	str	q20, [sp, #1728]                ; 16-byte Spill
	mov.16b	v19, v8
	bsl.16b	v19, v23, v31
	str	q19, [sp, #1936]                ; 16-byte Spill
	bif.16b	v22, v31, v8
	str	q22, [sp, #1744]                ; 16-byte Spill
	mov.16b	v21, v8
	bsl.16b	v21, v25, v31
	str	q21, [sp, #1856]                ; 16-byte Spill
	bif.16b	v24, v31, v8
	str	q24, [sp, #1760]                ; 16-byte Spill
	mov.16b	v23, v8
	bsl.16b	v23, v27, v31
	str	q23, [sp, #1920]                ; 16-byte Spill
	mov.16b	v27, v8
	bsl.16b	v27, v26, v31
	str	q27, [sp, #1776]                ; 16-byte Spill
	mov.16b	v25, v8
	bsl.16b	v25, v29, v31
	str	q25, [sp, #1840]                ; 16-byte Spill
	mov.16b	v5, v8
	bsl.16b	v5, v28, v31
	str	q5, [sp, #1792]                 ; 16-byte Spill
	mov.16b	v12, v8
	bsl.16b	v12, v0, v31
	str	q12, [sp, #1344]                ; 16-byte Spill
	bit.16b	v31, v30, v8
	str	q31, [sp, #1808]                ; 16-byte Spill
	mvni.4s	v26, #127, msl #16
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	fmaxnm.4s	v0, v1, v26
	ldr	q28, [sp, #1632]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v28
	ldr	q29, [sp, #1600]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v29
	ldr	q30, [sp, #2064]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v30
	ldr	q30, [sp, #2048]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v30
	fmaxnm.4s	v0, v0, v2
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v0, v0, v6
	fmaxnm.4s	v0, v0, v7
	fmaxnm.4s	v0, v0, v16
	fmaxnm.4s	v0, v0, v19
	fmaxnm.4s	v0, v0, v21
	fmaxnm.4s	v0, v0, v23
	fmaxnm.4s	v0, v0, v25
	fmaxnm.4s	v0, v0, v12
	ldr	q2, [sp, #2016]                 ; 16-byte Reload
	fmaxnm.4s	v12, v2, v0
	fsub.4s	v2, v1, v12
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v16, w9
	fcmge.4s	v0, v2, v16
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v7, w9
	fcmge.4s	v1, v7, v2
	and.16b	v0, v0, v1
	ldr	q3, [sp, #1648]                 ; 16-byte Reload
	fmaxnm.4s	v1, v3, v26
	ldr	q13, [sp, #1616]                ; 16-byte Reload
	fmaxnm.4s	v1, v1, v13
	ldr	q14, [sp, #1584]                ; 16-byte Reload
	fmaxnm.4s	v1, v1, v14
	ldr	q15, [sp, #1568]                ; 16-byte Reload
	fmaxnm.4s	v1, v1, v15
	ldr	q4, [sp, #2032]                 ; 16-byte Reload
	fmaxnm.4s	v1, v1, v4
	fmaxnm.4s	v1, v1, v11
	str	q11, [sp, #1136]                ; 16-byte Spill
	fmaxnm.4s	v1, v1, v10
	fmaxnm.4s	v1, v1, v9
	fmaxnm.4s	v1, v1, v17
	fmaxnm.4s	v1, v1, v18
	fmaxnm.4s	v1, v1, v20
	fmaxnm.4s	v1, v1, v22
	fmaxnm.4s	v1, v1, v24
	fmaxnm.4s	v1, v1, v27
	fmaxnm.4s	v1, v1, v5
	fmaxnm.4s	v1, v1, v31
	ldr	q4, [sp, #2000]                 ; 16-byte Reload
	fmaxnm.4s	v8, v4, v1
	fsub.4s	v10, v3, v8
	fcmge.4s	v1, v10, v16
	fcmge.4s	v3, v7, v10
	and.16b	v1, v1, v3
	and.16b	v1, v1, v10
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v19, w9
	fmul.4s	v3, v1, v19
	movi.4s	v5, #75, lsl #24
	mvni.4s	v6, #128, lsl #24
	mov.16b	v4, v6
	bsl.16b	v4, v5, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v2
	fmul.4s	v0, v4, v19
	bif.16b	v5, v0, v6
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	mov	w9, #29184                      ; =0x7200
	movk	w9, #16177, lsl #16
	dup.4s	v20, w9
	fmul.4s	v6, v3, v20
	fsub.4s	v6, v1, v6
	fcvtzs.4s	v1, v5
	scvtf.4s	v5, v1
	fmul.4s	v17, v5, v20
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #13759, lsl #16
	dup.4s	v21, w9
	fsub.4s	v4, v4, v17
	fmul.4s	v5, v5, v21
	fsub.4s	v5, v4, v5
	fmul.4s	v3, v3, v21
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v22, w9
	fsub.4s	v3, v6, v3
	fmul.4s	v4, v3, v22
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v23, w9
	fadd.4s	v4, v4, v23
	fmul.4s	v4, v3, v4
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v27, w9
	fadd.4s	v4, v4, v27
	fmul.4s	v4, v3, v4
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v25, w9
	fadd.4s	v4, v4, v25
	fmul.4s	v6, v3, v4
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v4, w9
	fadd.4s	v6, v6, v4
	fmul.4s	v6, v3, v6
	movi.4s	v31, #63, lsl #24
	fadd.4s	v6, v6, v31
	fmul.4s	v17, v3, v3
	fmul.4s	v6, v17, v6
	fmul.4s	v17, v5, v22
	fadd.4s	v17, v17, v23
	fmul.4s	v17, v5, v17
	fadd.4s	v17, v17, v27
	fmul.4s	v17, v5, v17
	fadd.4s	v17, v17, v25
	fmul.4s	v17, v5, v17
	fadd.4s	v17, v17, v4
	fmul.4s	v17, v5, v17
	fadd.4s	v17, v17, v31
	fmul.4s	v18, v5, v5
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	fadd.4s	v3, v3, v6
	fmov.4s	v24, #1.00000000
	fadd.4s	v5, v5, v24
	sshr.4s	v6, v1, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v24
	fmul.4s	v5, v5, v17
	fadd.4s	v3, v3, v24
	sshr.4s	v17, v0, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v24
	fmul.4s	v3, v3, v18
	sub.4s	v1, v1, v6
	sub.4s	v0, v0, v17
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v3, v0
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	str	q2, [sp, #1424]                 ; 16-byte Spill
	fcmgt.4s	v3, v16, v2
	bic.16b	v1, v1, v3
	str	q10, [sp, #1472]                ; 16-byte Spill
	fcmgt.4s	v3, v16, v10
	bic.16b	v0, v0, v3
	fcmgt.4s	v5, v10, v7
	fneg.4s	v30, v26
	bit.16b	v0, v30, v5
	str	q0, [sp, #1456]                 ; 16-byte Spill
	fcmgt.4s	v0, v2, v7
	bsl.16b	v0, v30, v1
	str	q0, [sp, #1440]                 ; 16-byte Spill
	fsub.4s	v28, v28, v12
	fcmge.4s	v0, v28, v16
	fcmge.4s	v1, v7, v28
	and.16b	v0, v0, v1
	fsub.4s	v10, v13, v8
	fcmge.4s	v1, v10, v16
	fcmge.4s	v5, v7, v10
	and.16b	v1, v1, v5
	and.16b	v1, v1, v10
	fmul.4s	v5, v1, v19
	movi.4s	v2, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v6, v17
	bsl.16b	v6, v2, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v28
	fmul.4s	v0, v6, v19
	bsl.16b	v17, v2, v0
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v26, v18, v20
	fsub.4s	v6, v6, v26
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v26, v6, v6
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v26, v18, #23
	add.4s	v26, v26, v24
	fmul.4s	v1, v1, v26
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	str	q28, [sp, #1360]                ; 16-byte Spill
	fcmgt.4s	v5, v16, v28
	bic.16b	v1, v1, v5
	str	q10, [sp, #1392]                ; 16-byte Spill
	fcmgt.4s	v5, v16, v10
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v10, v7
	bit.16b	v0, v30, v5
	str	q0, [sp, #1408]                 ; 16-byte Spill
	fcmgt.4s	v0, v28, v7
	bsl.16b	v0, v30, v1
	str	q0, [sp, #1376]                 ; 16-byte Spill
	fsub.4s	v28, v29, v12
	fcmge.4s	v0, v28, v16
	fcmge.4s	v1, v7, v28
	and.16b	v0, v0, v1
	fsub.4s	v2, v14, v8
	fcmge.4s	v1, v2, v16
	fcmge.4s	v5, v7, v2
	and.16b	v1, v1, v5
	and.16b	v1, v1, v2
	fmul.4s	v5, v1, v19
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v6, v18
	bsl.16b	v6, v17, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v28
	fmul.4s	v0, v6, v19
	bif.16b	v17, v0, v18
	mvni.4s	v29, #128, lsl #24
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v26, v18, v20
	fsub.4s	v6, v6, v26
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v26, v6, v6
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v26, v18, #23
	add.4s	v26, v26, v24
	fmul.4s	v1, v1, v26
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	str	q28, [sp, #1280]                ; 16-byte Spill
	fcmgt.4s	v5, v16, v28
	bic.16b	v1, v1, v5
	str	q2, [sp, #1312]                 ; 16-byte Spill
	fcmgt.4s	v5, v16, v2
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v2, v7
	bit.16b	v0, v30, v5
	str	q0, [sp, #1328]                 ; 16-byte Spill
	fcmgt.4s	v0, v28, v7
	bsl.16b	v0, v30, v1
	str	q0, [sp, #1296]                 ; 16-byte Spill
	ldr	q0, [sp, #2064]                 ; 16-byte Reload
	fsub.4s	v28, v0, v12
	fcmge.4s	v0, v28, v16
	fcmge.4s	v1, v7, v28
	and.16b	v0, v0, v1
	fsub.4s	v2, v15, v8
	fcmge.4s	v1, v2, v16
	fcmge.4s	v5, v7, v2
	and.16b	v1, v1, v5
	and.16b	v1, v1, v2
	fmul.4s	v5, v1, v19
	movi.4s	v17, #75, lsl #24
	mov.16b	v6, v29
	bsl.16b	v6, v17, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v28
	fmul.4s	v0, v6, v19
	bif.16b	v17, v0, v29
	movi.4s	v9, #75, lsl #24
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v26, v18, v20
	fsub.4s	v6, v6, v26
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v26, v6, v6
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v26, v18, #23
	add.4s	v26, v26, v24
	fmul.4s	v1, v1, v26
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	str	q28, [sp, #1216]                ; 16-byte Spill
	fcmgt.4s	v5, v16, v28
	bic.16b	v1, v1, v5
	str	q2, [sp, #1248]                 ; 16-byte Spill
	fcmgt.4s	v5, v16, v2
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v2, v7
	bit.16b	v0, v30, v5
	str	q0, [sp, #1264]                 ; 16-byte Spill
	fcmgt.4s	v0, v28, v7
	bsl.16b	v0, v30, v1
	str	q0, [sp, #1232]                 ; 16-byte Spill
	ldr	q0, [sp, #2048]                 ; 16-byte Reload
	fsub.4s	v28, v0, v12
	fcmge.4s	v0, v28, v16
	fcmge.4s	v1, v7, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #2032]                 ; 16-byte Reload
	fsub.4s	v2, v1, v8
	fcmge.4s	v1, v2, v16
	fcmge.4s	v5, v7, v2
	and.16b	v1, v1, v5
	and.16b	v1, v1, v2
	fmul.4s	v5, v1, v19
	mov.16b	v6, v29
	bsl.16b	v6, v9, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v28
	fmul.4s	v0, v6, v19
	mov.16b	v17, v29
	bsl.16b	v17, v9, v0
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v26, v18, v20
	fsub.4s	v6, v6, v26
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v26, v6, v6
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v26, v18, #23
	add.4s	v26, v26, v24
	fmul.4s	v1, v1, v26
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	str	q28, [sp, #1152]                ; 16-byte Spill
	fcmgt.4s	v5, v16, v28
	bic.16b	v1, v1, v5
	str	q2, [sp, #1184]                 ; 16-byte Spill
	fcmgt.4s	v5, v16, v2
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v2, v7
	bit.16b	v0, v30, v5
	str	q0, [sp, #1200]                 ; 16-byte Spill
	fcmgt.4s	v0, v28, v7
	bsl.16b	v0, v30, v1
	str	q0, [sp, #1168]                 ; 16-byte Spill
	fsub.4s	v28, v11, v8
	fcmge.4s	v0, v28, v16
	fcmge.4s	v1, v7, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	mov.16b	v9, v12
	fsub.4s	v29, v1, v12
	fcmge.4s	v1, v29, v16
	fcmge.4s	v5, v7, v29
	and.16b	v1, v1, v5
	and.16b	v1, v1, v29
	fmul.4s	v5, v1, v19
	mvni.4s	v2, #128, lsl #24
	movi.4s	v17, #75, lsl #24
	mov.16b	v6, v2
	bsl.16b	v6, v17, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v28
	fmul.4s	v0, v6, v19
	bif.16b	v17, v0, v2
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v26, v18, v20
	fsub.4s	v6, v6, v26
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v26, v6, v6
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v26, v18, #23
	add.4s	v26, v26, v24
	fmul.4s	v1, v1, v26
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	str	q28, [sp, #1072]                ; 16-byte Spill
	fcmgt.4s	v5, v16, v28
	bic.16b	v1, v1, v5
	str	q29, [sp, #1104]                ; 16-byte Spill
	fcmgt.4s	v5, v16, v29
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v29, v7
	bit.16b	v0, v30, v5
	str	q0, [sp, #1120]                 ; 16-byte Spill
	fcmgt.4s	v0, v28, v7
	bsl.16b	v0, v30, v1
	str	q0, [sp, #1088]                 ; 16-byte Spill
	ldr	q0, [sp, #1664]                 ; 16-byte Reload
	fsub.4s	v28, v0, v8
	fcmge.4s	v0, v28, v16
	fcmge.4s	v1, v7, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fsub.4s	v2, v1, v12
	fcmge.4s	v1, v2, v16
	fcmge.4s	v5, v7, v2
	and.16b	v1, v1, v5
	and.16b	v1, v1, v2
	fmul.4s	v5, v1, v19
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v6, v18
	bsl.16b	v6, v17, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v28
	fmul.4s	v0, v6, v19
	bif.16b	v17, v0, v18
	mvni.4s	v29, #128, lsl #24
	movi.4s	v10, #75, lsl #24
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v26, v18, v20
	fsub.4s	v6, v6, v26
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v26, v6, v6
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v26, v18, #23
	add.4s	v26, v26, v24
	fmul.4s	v1, v1, v26
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	fcmgt.4s	v5, v16, v28
	bic.16b	v1, v1, v5
	str	q2, [sp, #1040]                 ; 16-byte Spill
	fcmgt.4s	v5, v16, v2
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v2, v7
	bit.16b	v0, v30, v5
	str	q0, [sp, #1056]                 ; 16-byte Spill
	fcmgt.4s	v0, v28, v7
	bsl.16b	v0, v30, v1
	stp	q28, q0, [sp, #1008]            ; 32-byte Folded Spill
	ldr	q0, [sp, #1680]                 ; 16-byte Reload
	fsub.4s	v28, v0, v8
	fcmge.4s	v0, v28, v16
	fcmge.4s	v1, v7, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	fsub.4s	v2, v1, v12
	fcmge.4s	v1, v2, v16
	fcmge.4s	v5, v7, v2
	and.16b	v1, v1, v5
	and.16b	v1, v1, v2
	fmul.4s	v5, v1, v19
	mov.16b	v6, v29
	bsl.16b	v6, v10, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v28
	fmul.4s	v0, v6, v19
	mov.16b	v17, v29
	bsl.16b	v17, v10, v0
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v26, v18, v20
	fsub.4s	v6, v6, v26
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v26, v6, v6
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v26, v18, #23
	add.4s	v26, v26, v24
	fmul.4s	v1, v1, v26
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	fcmgt.4s	v5, v16, v28
	bic.16b	v1, v1, v5
	fcmgt.4s	v5, v16, v2
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v2, v7
	bit.16b	v0, v30, v5
	stp	q2, q0, [sp, #976]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v28, v7
	bsl.16b	v0, v30, v1
	stp	q28, q0, [sp, #944]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1696]                 ; 16-byte Reload
	fsub.4s	v28, v0, v8
	fcmge.4s	v0, v28, v16
	fcmge.4s	v1, v7, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	fsub.4s	v29, v1, v12
	fcmge.4s	v1, v29, v16
	fcmge.4s	v5, v7, v29
	and.16b	v1, v1, v5
	and.16b	v1, v1, v29
	fmul.4s	v5, v1, v19
	mvni.4s	v2, #128, lsl #24
	movi.4s	v17, #75, lsl #24
	mov.16b	v6, v2
	bsl.16b	v6, v17, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v28
	fmul.4s	v0, v6, v19
	bif.16b	v17, v0, v2
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v26, v18, v20
	fsub.4s	v6, v6, v26
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v26, v6, v6
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v26, v18, #23
	add.4s	v26, v26, v24
	fmul.4s	v1, v1, v26
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	fcmgt.4s	v5, v16, v28
	bic.16b	v1, v1, v5
	fcmgt.4s	v5, v16, v29
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v29, v7
	bit.16b	v0, v30, v5
	stp	q29, q0, [sp, #912]             ; 32-byte Folded Spill
	fcmgt.4s	v0, v28, v7
	bsl.16b	v0, v30, v1
	stp	q28, q0, [sp, #880]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1712]                 ; 16-byte Reload
	fsub.4s	v28, v0, v8
	fcmge.4s	v0, v28, v16
	fcmge.4s	v1, v7, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1952]                 ; 16-byte Reload
	fsub.4s	v2, v1, v12
	fcmge.4s	v1, v2, v16
	fcmge.4s	v5, v7, v2
	and.16b	v1, v1, v5
	and.16b	v1, v1, v2
	fmul.4s	v5, v1, v19
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v6, v18
	bsl.16b	v6, v17, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v28
	fmul.4s	v0, v6, v19
	bif.16b	v17, v0, v18
	mvni.4s	v29, #128, lsl #24
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v26, v18, v20
	fsub.4s	v6, v6, v26
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v26, v6, v6
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v26, v18, #23
	add.4s	v26, v26, v24
	fmul.4s	v1, v1, v26
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	fcmgt.4s	v5, v16, v28
	bic.16b	v1, v1, v5
	fcmgt.4s	v5, v16, v2
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v2, v7
	bit.16b	v0, v30, v5
	stp	q2, q0, [sp, #848]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v28, v7
	bsl.16b	v0, v30, v1
	stp	q28, q0, [sp, #816]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1728]                 ; 16-byte Reload
	fsub.4s	v28, v0, v8
	fcmge.4s	v0, v28, v16
	fcmge.4s	v1, v7, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	fsub.4s	v2, v1, v12
	fcmge.4s	v1, v2, v16
	fcmge.4s	v5, v7, v2
	and.16b	v1, v1, v5
	and.16b	v1, v1, v2
	fmul.4s	v5, v1, v19
	mov.16b	v6, v29
	bsl.16b	v6, v10, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v28
	fmul.4s	v0, v6, v19
	mov.16b	v17, v29
	bsl.16b	v17, v10, v0
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v26, v18, v20
	fsub.4s	v6, v6, v26
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v26, v6, v6
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v26, v18, #23
	add.4s	v26, v26, v24
	fmul.4s	v1, v1, v26
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	fcmgt.4s	v5, v16, v28
	bic.16b	v1, v1, v5
	fcmgt.4s	v5, v16, v2
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v2, v7
	bit.16b	v0, v30, v5
	stp	q2, q0, [sp, #784]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v28, v7
	bsl.16b	v0, v30, v1
	stp	q28, q0, [sp, #752]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1744]                 ; 16-byte Reload
	fsub.4s	v28, v0, v8
	fcmge.4s	v0, v28, v16
	fcmge.4s	v1, v7, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1936]                 ; 16-byte Reload
	fsub.4s	v29, v1, v12
	fcmge.4s	v1, v29, v16
	fcmge.4s	v5, v7, v29
	and.16b	v1, v1, v5
	and.16b	v1, v1, v29
	fmul.4s	v5, v1, v19
	mvni.4s	v2, #128, lsl #24
	movi.4s	v17, #75, lsl #24
	mov.16b	v6, v2
	bsl.16b	v6, v17, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v28
	fmul.4s	v0, v6, v19
	bif.16b	v17, v0, v2
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v26, v18, v20
	fsub.4s	v6, v6, v26
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v26, v6, v6
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v26, v18, #23
	add.4s	v26, v26, v24
	fmul.4s	v1, v1, v26
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	fcmgt.4s	v5, v16, v28
	bic.16b	v1, v1, v5
	fcmgt.4s	v5, v16, v29
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v29, v7
	bit.16b	v0, v30, v5
	stp	q29, q0, [sp, #720]             ; 32-byte Folded Spill
	fcmgt.4s	v0, v28, v7
	bsl.16b	v0, v30, v1
	stp	q28, q0, [sp, #688]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1760]                 ; 16-byte Reload
	fsub.4s	v2, v0, v8
	fcmge.4s	v0, v2, v16
	fcmge.4s	v1, v7, v2
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1856]                 ; 16-byte Reload
	fsub.4s	v28, v1, v12
	fcmge.4s	v1, v28, v16
	fcmge.4s	v5, v7, v28
	and.16b	v1, v1, v5
	and.16b	v1, v1, v28
	fmul.4s	v5, v1, v19
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v6, v18
	bsl.16b	v6, v17, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v2
	fmul.4s	v0, v6, v19
	bif.16b	v17, v0, v18
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v26, v18, v20
	fsub.4s	v6, v6, v26
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v26, v6, v6
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v26, v18, #23
	add.4s	v26, v26, v24
	fmul.4s	v1, v1, v26
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	fcmgt.4s	v5, v16, v2
	bic.16b	v1, v1, v5
	fcmgt.4s	v5, v16, v28
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v28, v7
	bit.16b	v0, v30, v5
	str	q0, [sp, #672]                  ; 16-byte Spill
	fcmgt.4s	v0, v2, v7
	bsl.16b	v0, v30, v1
	stp	q2, q0, [sp, #640]              ; 32-byte Folded Spill
	ldr	q0, [sp, #1776]                 ; 16-byte Reload
	fsub.4s	v12, v0, v8
	fcmge.4s	v0, v12, v16
	fcmge.4s	v1, v7, v12
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	fsub.4s	v26, v1, v9
	fcmge.4s	v1, v26, v16
	fcmge.4s	v5, v7, v26
	and.16b	v1, v1, v5
	and.16b	v1, v1, v26
	fmul.4s	v5, v1, v19
	mvni.4s	v2, #128, lsl #24
	movi.4s	v17, #75, lsl #24
	mov.16b	v6, v2
	bsl.16b	v6, v17, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v12
	fmul.4s	v0, v6, v19
	bif.16b	v17, v0, v2
	mvni.4s	v29, #128, lsl #24
	fadd.4s	v0, v0, v17
	fsub.4s	v17, v0, v17
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v18, v5, v20
	fsub.4s	v1, v1, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v10, v18, v20
	fsub.4s	v6, v6, v10
	fmul.4s	v18, v18, v21
	fsub.4s	v6, v6, v18
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v18, v1, v1
	fmul.4s	v5, v18, v5
	fmul.4s	v18, v6, v22
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v10, v6, v6
	fmul.4s	v18, v10, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v5, v5, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v0, #1
	shl.4s	v10, v18, #23
	add.4s	v10, v10, v24
	fmul.4s	v1, v1, v10
	sub.4s	v6, v17, v6
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	fcmgt.4s	v5, v16, v12
	bic.16b	v1, v1, v5
	fcmgt.4s	v5, v16, v26
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v26, v7
	bit.16b	v0, v30, v5
	str	q0, [sp, #624]                  ; 16-byte Spill
	fcmgt.4s	v0, v12, v7
	bsl.16b	v0, v30, v1
	str	q0, [sp, #608]                  ; 16-byte Spill
	ldr	q0, [sp, #1792]                 ; 16-byte Reload
	fsub.4s	v18, v0, v8
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	fsub.4s	v17, v1, v9
	fcmge.4s	v1, v17, v16
	fcmge.4s	v5, v7, v17
	and.16b	v1, v1, v5
	and.16b	v1, v1, v17
	fmul.4s	v5, v1, v19
	movi.4s	v2, #75, lsl #24
	mov.16b	v6, v29
	bsl.16b	v6, v2, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v0, v18
	fmul.4s	v0, v6, v19
	mov.16b	v10, v29
	bsl.16b	v10, v2, v0
	fadd.4s	v0, v0, v10
	fsub.4s	v10, v0, v10
	fcvtzs.4s	v0, v5
	scvtf.4s	v5, v0
	fmul.4s	v11, v5, v20
	fsub.4s	v1, v1, v11
	fcvtzs.4s	v10, v10
	scvtf.4s	v11, v10
	fmul.4s	v15, v11, v20
	fsub.4s	v6, v6, v15
	fmul.4s	v11, v11, v21
	fsub.4s	v6, v6, v11
	fmul.4s	v5, v5, v21
	fsub.4s	v1, v1, v5
	fmul.4s	v5, v1, v22
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v4
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v11, v1, v1
	fmul.4s	v5, v11, v5
	fmul.4s	v11, v6, v22
	fadd.4s	v11, v11, v23
	fmul.4s	v11, v6, v11
	fadd.4s	v11, v11, v27
	fmul.4s	v11, v6, v11
	fadd.4s	v11, v11, v25
	fmul.4s	v11, v6, v11
	fadd.4s	v11, v11, v4
	fmul.4s	v11, v6, v11
	fadd.4s	v11, v11, v31
	fmul.4s	v15, v6, v6
	fmul.4s	v11, v15, v11
	fadd.4s	v6, v6, v11
	fadd.4s	v1, v1, v5
	fadd.4s	v5, v6, v24
	sshr.4s	v6, v10, #1
	shl.4s	v11, v6, #23
	add.4s	v11, v11, v24
	fmul.4s	v5, v5, v11
	fadd.4s	v1, v1, v24
	sshr.4s	v11, v0, #1
	shl.4s	v15, v11, #23
	add.4s	v15, v15, v24
	fmul.4s	v1, v1, v15
	sub.4s	v6, v10, v6
	sub.4s	v0, v0, v11
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v6, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v5, v1
	fcmgt.4s	v5, v16, v18
	bic.16b	v1, v1, v5
	fcmgt.4s	v5, v16, v17
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v17, v7
	bit.16b	v0, v30, v5
	str	q0, [sp, #592]                  ; 16-byte Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v30, v1
	str	q0, [sp, #576]                  ; 16-byte Spill
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	fsub.4s	v6, v0, v8
	fcmge.4s	v0, v6, v16
	fcmge.4s	v1, v7, v6
	and.16b	v0, v0, v1
	ldr	q29, [sp, #1344]                ; 16-byte Reload
	fsub.4s	v5, v29, v9
	fcmge.4s	v1, v5, v16
	fcmge.4s	v10, v7, v5
	and.16b	v1, v1, v10
	and.16b	v1, v1, v5
	fmul.4s	v10, v1, v19
	mvni.4s	v2, #128, lsl #24
	movi.4s	v13, #75, lsl #24
	mov.16b	v11, v2
	bsl.16b	v11, v13, v10
	fadd.4s	v10, v10, v11
	fsub.4s	v10, v10, v11
	and.16b	v11, v0, v6
	fmul.4s	v0, v11, v19
	mov.16b	v15, v2
	bsl.16b	v15, v13, v0
	movi.4s	v3, #75, lsl #24
	fadd.4s	v0, v0, v15
	fsub.4s	v15, v0, v15
	fcvtzs.4s	v0, v10
	scvtf.4s	v10, v0
	fmul.4s	v14, v10, v20
	fsub.4s	v1, v1, v14
	fcvtzs.4s	v14, v15
	scvtf.4s	v15, v14
	fmul.4s	v13, v15, v20
	fsub.4s	v11, v11, v13
	fmul.4s	v13, v15, v21
	fsub.4s	v11, v11, v13
	fmul.4s	v10, v10, v21
	fsub.4s	v1, v1, v10
	fmul.4s	v10, v1, v22
	fadd.4s	v10, v10, v23
	fmul.4s	v10, v1, v10
	fadd.4s	v10, v10, v27
	fmul.4s	v10, v1, v10
	fadd.4s	v10, v10, v25
	fmul.4s	v10, v1, v10
	fadd.4s	v10, v10, v4
	fmul.4s	v10, v1, v10
	fadd.4s	v10, v10, v31
	fmul.4s	v13, v1, v1
	fmul.4s	v10, v13, v10
	fmul.4s	v13, v11, v22
	fadd.4s	v13, v13, v23
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v25
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v4
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v31
	fmul.4s	v15, v11, v11
	fmul.4s	v13, v15, v13
	fadd.4s	v11, v11, v13
	fadd.4s	v1, v1, v10
	fadd.4s	v10, v11, v24
	sshr.4s	v11, v14, #1
	shl.4s	v13, v11, #23
	add.4s	v13, v13, v24
	fmul.4s	v10, v10, v13
	fadd.4s	v1, v1, v24
	sshr.4s	v13, v0, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v24
	fmul.4s	v1, v1, v15
	sub.4s	v11, v14, v11
	sub.4s	v0, v0, v13
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v11, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v10, v1
	fcmgt.4s	v10, v16, v6
	bic.16b	v1, v1, v10
	fcmgt.4s	v10, v16, v5
	bic.16b	v0, v0, v10
	fcmgt.4s	v10, v5, v7
	bit.16b	v0, v30, v10
	str	q0, [sp, #544]                  ; 16-byte Spill
	fcmgt.4s	v0, v6, v7
	bsl.16b	v0, v30, v1
	str	q0, [sp, #528]                  ; 16-byte Spill
	str	q8, [sp, #1488]                 ; 16-byte Spill
	ldr	q0, [sp, #2000]                 ; 16-byte Reload
	fsub.4s	v2, v0, v8
	fcmge.4s	v0, v2, v16
	fcmge.4s	v13, v7, v2
	and.16b	v13, v0, v13
	str	q9, [sp, #1504]                 ; 16-byte Spill
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
	fsub.4s	v8, v1, v9
	fcmge.4s	v14, v8, v16
	fcmge.4s	v15, v7, v8
	and.16b	v14, v14, v15
	and.16b	v14, v14, v8
	fmul.4s	v15, v14, v19
	mvni.4s	v1, #128, lsl #24
	mov.16b	v0, v1
	bsl.16b	v0, v3, v15
	fadd.4s	v15, v15, v0
	fsub.4s	v0, v15, v0
	and.16b	v13, v13, v2
	fmul.4s	v19, v13, v19
	mov.16b	v15, v1
	bsl.16b	v15, v3, v19
	fadd.4s	v19, v19, v15
	fsub.4s	v19, v19, v15
	fcvtzs.4s	v0, v0
	scvtf.4s	v15, v0
	fmul.4s	v11, v15, v20
	fsub.4s	v11, v14, v11
	fcvtzs.4s	v19, v19
	scvtf.4s	v14, v19
	fmul.4s	v20, v14, v20
	fsub.4s	v20, v13, v20
	fmul.4s	v13, v15, v21
	fmul.4s	v21, v14, v21
	fsub.4s	v20, v20, v21
	fsub.4s	v21, v11, v13
	fmul.4s	v11, v21, v22
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v23
	fadd.4s	v23, v11, v23
	fmul.4s	v23, v21, v23
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v27
	fadd.4s	v23, v23, v27
	fmul.4s	v23, v21, v23
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v25
	fadd.4s	v23, v23, v25
	fmul.4s	v23, v21, v23
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v4
	fadd.4s	v4, v23, v4
	fmul.4s	v4, v21, v4
	fadd.4s	v4, v4, v31
	fmul.4s	v23, v21, v21
	fmul.4s	v4, v23, v4
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v23, v20, v20
	fmul.4s	v22, v23, v22
	fadd.4s	v20, v20, v22
	fadd.4s	v4, v21, v4
	fadd.4s	v20, v20, v24
	sshr.4s	v21, v19, #1
	shl.4s	v22, v21, #23
	add.4s	v22, v22, v24
	fmul.4s	v20, v20, v22
	fadd.4s	v4, v4, v24
	sshr.4s	v22, v0, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v24
	fmul.4s	v4, v4, v23
	sub.4s	v19, v19, v21
	sub.4s	v0, v0, v22
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v4, v0
	shl.4s	v4, v19, #23
	add.4s	v4, v4, v24
	fmul.4s	v4, v20, v4
	fcmgt.4s	v19, v16, v2
	bic.16b	v19, v4, v19
	fcmgt.4s	v4, v16, v8
	bic.16b	v0, v0, v4
	fcmgt.4s	v4, v8, v7
	bit.16b	v0, v30, v4
	str	q0, [sp, #512]                  ; 16-byte Spill
	fcmgt.4s	v0, v2, v7
	bsl.16b	v0, v30, v19
	stp	q2, q0, [sp, #480]              ; 32-byte Folded Spill
	ldr	x9, [sp, #464]                  ; 8-byte Reload
	ldr	q1, [sp, #1648]                 ; 16-byte Reload
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	x9, [sp, #440]                  ; 8-byte Reload
	ldr	q1, [sp, #1616]                 ; 16-byte Reload
	ldr	q0, [sp, #1632]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	x9, [sp, #408]                  ; 8-byte Reload
	ldr	q1, [sp, #1584]                 ; 16-byte Reload
	ldr	q0, [sp, #1600]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	x9, [sp, #376]                  ; 8-byte Reload
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	ldr	q0, [sp, #2064]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldp	x9, x10, [sp, #336]             ; 16-byte Folded Reload
	ldr	q1, [sp, #2032]                 ; 16-byte Reload
	ldr	q0, [sp, #2048]                 ; 16-byte Reload
	stp	q0, q1, [x10]
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	ldr	q0, [sp, #1984]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldp	x9, x10, [sp, #320]             ; 16-byte Folded Reload
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	ldr	q0, [sp, #1904]                 ; 16-byte Reload
	stp	q0, q1, [x10]
	ldr	q1, [sp, #1680]                 ; 16-byte Reload
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	x9, [sp, #312]                  ; 8-byte Reload
	ldr	q1, [sp, #1696]                 ; 16-byte Reload
	ldr	q0, [sp, #1888]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldp	x9, x10, [sp, #272]             ; 16-byte Folded Reload
	ldr	q1, [sp, #1712]                 ; 16-byte Reload
	ldr	q0, [sp, #1952]                 ; 16-byte Reload
	stp	q0, q1, [x10]
	ldr	q1, [sp, #1728]                 ; 16-byte Reload
	ldr	q0, [sp, #1872]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldp	x9, x10, [sp, #256]             ; 16-byte Folded Reload
	ldr	q1, [sp, #1744]                 ; 16-byte Reload
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	stp	q0, q1, [x10]
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	ldr	q0, [sp, #1856]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldp	x9, x10, [sp, #240]             ; 16-byte Folded Reload
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	ldr	q0, [sp, #1920]                 ; 16-byte Reload
	stp	q0, q1, [x10]
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	ldr	q0, [sp, #1840]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	x9, [sp, #232]                  ; 8-byte Reload
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	stp	q29, q0, [x9]
	ldr	q0, [sp, #1424]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q13, [sp, #208]                 ; 16-byte Reload
	ldr	q7, [sp, #1440]                 ; 16-byte Reload
	bsl.16b	v0, v7, v13
	str	q0, [sp, #2064]                 ; 16-byte Spill
	ldr	q0, [sp, #1472]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #1456]                 ; 16-byte Reload
	bsl.16b	v0, v7, v13
	str	q0, [sp, #2032]                 ; 16-byte Spill
	ldr	q0, [sp, #1360]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #1376]                 ; 16-byte Reload
	bsl.16b	v0, v7, v13
	str	q0, [sp, #2048]                 ; 16-byte Spill
	ldr	q0, [sp, #1392]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #1408]                 ; 16-byte Reload
	bsl.16b	v0, v7, v13
	str	q0, [sp, #2000]                 ; 16-byte Spill
	ldr	q0, [sp, #1280]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #1296]                 ; 16-byte Reload
	bsl.16b	v0, v7, v13
	str	q0, [sp, #2016]                 ; 16-byte Spill
	ldr	q0, [sp, #1312]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #1328]                 ; 16-byte Reload
	bsl.16b	v0, v7, v13
	str	q0, [sp, #1984]                 ; 16-byte Spill
	ldr	q0, [sp, #1216]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #1232]                 ; 16-byte Reload
	bsl.16b	v0, v7, v13
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q0, [sp, #1248]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #1264]                 ; 16-byte Reload
	mov.16b	v14, v0
	bsl.16b	v14, v7, v13
	ldr	q0, [sp, #1152]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #1168]                 ; 16-byte Reload
	mov.16b	v15, v0
	bsl.16b	v15, v7, v13
	ldr	q0, [sp, #1184]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #1200]                 ; 16-byte Reload
	mov.16b	v10, v0
	bsl.16b	v10, v7, v13
	ldr	q0, [sp, #1072]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #1088]                 ; 16-byte Reload
	mov.16b	v1, v0
	bsl.16b	v1, v7, v13
	ldr	q7, [sp, #1104]                 ; 16-byte Reload
	fcmeq.4s	v7, v7, v7
	ldr	q16, [sp, #1120]                ; 16-byte Reload
	bsl.16b	v7, v16, v13
	ldp	q16, q19, [sp, #1008]           ; 32-byte Folded Reload
	fcmeq.4s	v16, v16, v16
	bsl.16b	v16, v19, v13
	ldr	q19, [sp, #1040]                ; 16-byte Reload
	fcmeq.4s	v19, v19, v19
	ldr	q20, [sp, #1056]                ; 16-byte Reload
	bsl.16b	v19, v20, v13
	ldp	q20, q21, [sp, #944]            ; 32-byte Folded Reload
	fcmeq.4s	v20, v20, v20
	bsl.16b	v20, v21, v13
	ldp	q21, q22, [sp, #976]            ; 32-byte Folded Reload
	fcmeq.4s	v21, v21, v21
	bsl.16b	v21, v22, v13
	ldp	q22, q23, [sp, #880]            ; 32-byte Folded Reload
	fcmeq.4s	v22, v22, v22
	bsl.16b	v22, v23, v13
	ldp	q23, q24, [sp, #912]            ; 32-byte Folded Reload
	fcmeq.4s	v23, v23, v23
	bsl.16b	v23, v24, v13
	ldp	q24, q25, [sp, #816]            ; 32-byte Folded Reload
	fcmeq.4s	v24, v24, v24
	bsl.16b	v24, v25, v13
	ldp	q25, q27, [sp, #848]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	bsl.16b	v25, v27, v13
	ldp	q0, q27, [sp, #752]             ; 32-byte Folded Reload
	fcmeq.4s	v11, v0, v0
	bsl.16b	v11, v27, v13
	ldp	q3, q27, [sp, #784]             ; 32-byte Folded Reload
	fcmeq.4s	v9, v3, v3
	bsl.16b	v9, v27, v13
	ldp	q4, q27, [sp, #688]             ; 32-byte Folded Reload
	fcmeq.4s	v31, v4, v4
	bsl.16b	v31, v27, v13
	ldp	q29, q27, [sp, #720]            ; 32-byte Folded Reload
	fcmeq.4s	v30, v29, v29
	bsl.16b	v30, v27, v13
	ldr	q27, [sp, #640]                 ; 16-byte Reload
	fcmeq.4s	v29, v27, v27
	ldr	q27, [sp, #656]                 ; 16-byte Reload
	bsl.16b	v29, v27, v13
	fcmeq.4s	v28, v28, v28
	ldr	q27, [sp, #672]                 ; 16-byte Reload
	bsl.16b	v28, v27, v13
	fcmeq.4s	v27, v12, v12
	ldr	q12, [sp, #608]                 ; 16-byte Reload
	bsl.16b	v27, v12, v13
	fcmeq.4s	v26, v26, v26
	ldr	q12, [sp, #624]                 ; 16-byte Reload
	bsl.16b	v26, v12, v13
	fcmeq.4s	v18, v18, v18
	ldr	q12, [sp, #576]                 ; 16-byte Reload
	bsl.16b	v18, v12, v13
	fcmeq.4s	v17, v17, v17
	ldr	q12, [sp, #592]                 ; 16-byte Reload
	bsl.16b	v17, v12, v13
	fcmeq.4s	v6, v6, v6
	ldr	q12, [sp, #528]                 ; 16-byte Reload
	mov.16b	v0, v6
	bsl.16b	v0, v12, v13
	fcmeq.4s	v5, v5, v5
	ldp	q6, q12, [sp, #544]             ; 32-byte Folded Reload
	bsl.16b	v5, v6, v13
	and.16b	v7, v12, v7
	and.16b	v2, v12, v1
	and.16b	v6, v12, v19
	and.16b	v1, v12, v16
	and.16b	v16, v12, v21
	and.16b	v3, v12, v20
	and.16b	v23, v12, v23
	and.16b	v22, v12, v22
	and.16b	v19, v12, v25
	and.16b	v4, v12, v24
	and.16b	v24, v12, v9
	and.16b	v25, v12, v11
	and.16b	v20, v12, v30
	and.16b	v30, v12, v31
	and.16b	v28, v12, v28
	and.16b	v29, v12, v29
	and.16b	v21, v12, v26
	and.16b	v26, v12, v27
	and.16b	v17, v12, v17
	and.16b	v18, v12, v18
	and.16b	v5, v12, v5
	and.16b	v27, v12, v0
	ldp	q0, q31, [sp, #480]             ; 32-byte Folded Reload
	fcmeq.4s	v0, v0, v0
	bif.16b	v31, v13, v0
	fcmeq.4s	v0, v8, v8
	ldr	q8, [sp, #512]                  ; 16-byte Reload
	bif.16b	v8, v13, v0
	mov	w9, #33792                      ; =0x8400
	movk	w9, #1, lsl #16
	add	x9, x21, x9
	ldr	q0, [sp, #2032]                 ; 16-byte Reload
	str	q0, [x9, #16]
	ldr	q0, [sp, #2064]                 ; 16-byte Reload
	str	q0, [x9]
	ldp	x9, x10, [sp, #192]             ; 16-byte Folded Reload
	ldr	q0, [sp, #2000]                 ; 16-byte Reload
	str	q0, [x10, #16]
	ldr	q0, [sp, #2048]                 ; 16-byte Reload
	str	q0, [x10]
	ldr	q0, [sp, #1984]                 ; 16-byte Reload
	str	q0, [x9, #16]
	ldr	q0, [sp, #2016]                 ; 16-byte Reload
	str	q0, [x9]
	ldp	x9, x10, [sp, #176]             ; 16-byte Folded Reload
	str	q14, [sp, #1952]                ; 16-byte Spill
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	stp	q0, q14, [x10]
	str	q10, [sp, #1920]                ; 16-byte Spill
	stp	q15, q10, [x9]
	str	q15, [sp, #1936]                ; 16-byte Spill
	ldp	x9, x10, [sp, #160]             ; 16-byte Folded Reload
	str	q2, [sp, #1648]                 ; 16-byte Spill
	stp	q7, q2, [x10]
	str	q7, [sp, #1904]                 ; 16-byte Spill
	str	q1, [sp, #1792]                 ; 16-byte Spill
	stp	q6, q1, [x9]
	str	q6, [sp, #1808]                 ; 16-byte Spill
	ldp	x9, x11, [sp, #144]             ; 16-byte Folded Reload
	str	q3, [sp, #1632]                 ; 16-byte Spill
	stp	q16, q3, [x11]
	str	q16, [sp, #1888]                ; 16-byte Spill
	str	q22, [sp, #1760]                ; 16-byte Spill
	stp	q23, q22, [x9]
	str	q23, [sp, #1776]                ; 16-byte Spill
	ldr	x9, [sp, #136]                  ; 8-byte Reload
	str	q4, [sp, #1616]                 ; 16-byte Spill
	stp	q19, q4, [x9]
	str	q19, [sp, #1872]                ; 16-byte Spill
	ldr	x9, [sp, #128]                  ; 8-byte Reload
	str	q25, [sp, #1728]                ; 16-byte Spill
	stp	q24, q25, [x9]
	str	q24, [sp, #1744]                ; 16-byte Spill
	ldr	x9, [sp, #120]                  ; 8-byte Reload
	str	q30, [sp, #1600]                ; 16-byte Spill
	stp	q20, q30, [x9]
	str	q20, [sp, #1856]                ; 16-byte Spill
	ldr	x9, [sp, #112]                  ; 8-byte Reload
	str	q29, [sp, #1696]                ; 16-byte Spill
	stp	q28, q29, [x9]
	str	q28, [sp, #1712]                ; 16-byte Spill
	ldr	x9, [sp, #104]                  ; 8-byte Reload
	str	q26, [sp, #1584]                ; 16-byte Spill
	stp	q21, q26, [x9]
	str	q21, [sp, #1840]                ; 16-byte Spill
	ldr	x9, [sp, #96]                   ; 8-byte Reload
	str	q18, [sp, #1664]                ; 16-byte Spill
	stp	q17, q18, [x9]
	str	q17, [sp, #1680]                ; 16-byte Spill
	ldr	x9, [sp, #88]                   ; 8-byte Reload
	str	q27, [sp, #1568]                ; 16-byte Spill
	stp	q5, q27, [x9]
	str	q5, [sp, #1824]                 ; 16-byte Spill
	ldr	x9, [sp, #472]                  ; 8-byte Reload
LBB0_20:                                ; %direct.true600
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_21 Depth 3
	mov	x10, #0                         ; =0x0
	lsl	x11, x8, #7
	add	x12, x23, x11
	ldp	q0, q1, [x12]
	fmul.4s	v1, v31, v1
	fmul.4s	v0, v8, v0
	mov	w12, #1                         ; =0x1
	bfi	x12, x8, #2, #61
	add	x13, x23, x12, lsl #5
	ldp	q2, q3, [x13]
	fmul.4s	v3, v31, v3
	fmul.4s	v2, v8, v2
	mov	w13, #2                         ; =0x2
	bfi	x13, x8, #2, #61
	add	x14, x23, x13, lsl #5
	ldp	q4, q5, [x14]
	fmul.4s	v7, v31, v5
	fmul.4s	v6, v8, v4
	orr	x14, x24, x8, lsl #2
	add	x15, x23, x14, lsl #5
	ldp	q4, q5, [x15]
	fmul.4s	v5, v31, v5
	fmul.4s	v4, v8, v4
	mov	x15, x9
LBB0_21:                                ; %direct.true628
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_20 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x16, x20, x10
	ldp	q17, q16, [x16]
	ldp	q19, q18, [x15, #-96]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v1, v1, v18
	fadd.4s	v0, v0, v19
	ldp	q19, q18, [x15, #-64]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v3, v3, v18
	fadd.4s	v2, v2, v19
	ldp	q19, q18, [x15, #-32]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v7, v7, v18
	fadd.4s	v6, v6, v19
	ldp	q19, q18, [x15]
	fmul.4s	v17, v17, v19
	fmul.4s	v16, v16, v18
	fadd.4s	v5, v5, v16
	fadd.4s	v4, v4, v17
	add	x10, x10, #32
	add	x15, x15, #3072
	cmp	x10, #512
	b.ne	LBB0_21
; %bb.22:                               ; %direct.false629
                                        ;   in Loop: Header=BB0_20 Depth=2
	add	x10, x19, x11
	stp	q0, q1, [x10]
	add	x10, x19, x12, lsl #5
	stp	q2, q3, [x10]
	add	x10, x19, x13, lsl #5
	stp	q6, q7, [x10]
	add	x10, x19, x14, lsl #5
	add	x8, x8, #1
	add	x9, x9, #128
	stp	q4, q5, [x10]
	cmp	x8, #24
	b.ne	LBB0_20
; %bb.23:                               ; %direct.true695.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w8, #5632                       ; =0x1600
	add	x0, x21, x8
	mov	x1, x19
	mov	w2, #3072                       ; =0xc00
	str	q31, [sp, #1456]                ; 16-byte Spill
	str	q8, [sp, #1472]                 ; 16-byte Spill
	bl	_memcpy
	add	x0, x21, #2560
	mov	x1, x19
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldr	q0, [sp, #1520]                 ; 16-byte Reload
	ldr	q1, [sp, #1456]                 ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #1536]                 ; 16-byte Reload
	ldr	q2, [sp, #1472]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	movi.2d	v3, #0000000000000000
	ldr	q2, [sp, #2032]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q4, [sp, #2000]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2064]                 ; 16-byte Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #2048]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2016]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1984]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1952]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1936]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1920]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1648]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1904]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1776]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1760]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1616]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1872]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1600]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1696]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1584]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1568]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v19, v1, v3
	fadd.4s	v20, v0, v2
	ldr	x17, [sp, #1560]                ; 8-byte Reload
	add	x17, x17, #1
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Reload
	cmp	x17, #129
	ldr	q5, [sp, #448]                  ; 16-byte Reload
	ldr	q6, [sp, #416]                  ; 16-byte Reload
	ldr	q7, [sp, #384]                  ; 16-byte Reload
	ldr	q16, [sp, #352]                 ; 16-byte Reload
	ldr	q17, [sp, #288]                 ; 16-byte Reload
	mov	w0, #80                         ; =0x50
	mov	w1, #96                         ; =0x60
	b.ne	LBB0_3
; %bb.24:                               ; %direct.schedule.50.preheader
	mov	x8, #0                          ; =0x0
	ldp	q0, q2, [sp, #16]               ; 32-byte Folded Reload
	xtn.2s	v0, v0
	movi.2s	v3, #96
	umull.2d	v0, v0, v3
	ldp	q1, q4, [sp, #48]               ; 32-byte Folded Reload
	xtn.2s	v1, v1
	umull.2d	v1, v1, v3
	xtn.2s	v2, v2
	umull.2d	v2, v2, v3
	xtn.2s	v4, v4
	umull.2d	v3, v4, v3
	ldr	x11, [sp, #8]                   ; 8-byte Reload
LBB0_25:                                ; %direct.true730
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v4, x8
	add.2d	v5, v4, v3
	add.2d	v6, v4, v2
	add.2d	v7, v4, v1
	add.2d	v4, v4, v0
	add	x9, x23, x8, lsl #5
	ldp	q16, q17, [x9]
	fdiv.4s	v17, v17, v20
	fdiv.4s	v16, v16, v19
	shl.2d	v4, v4, #2
	shl.2d	v7, v7, #2
	shl.2d	v6, v6, #2
	shl.2d	v5, v5, #2
	dup.2d	v18, x11
	add.2d	v5, v18, v5
	add.2d	v4, v18, v4
	mov.d	x9, v4[1]
	fmov	x10, d4
	str	s16, [x10]
	st1.s	{ v16 }[1], [x9]
	add.2d	v4, v18, v7
	mov.d	x9, v4[1]
	fmov	x10, d4
	st1.s	{ v16 }[2], [x10]
	add.2d	v4, v18, v6
	st1.s	{ v16 }[3], [x9]
	mov.d	x9, v4[1]
	fmov	x10, d4
	str	s17, [x10]
	st1.s	{ v17 }[1], [x9]
	mov.d	x9, v5[1]
	fmov	x10, d5
	st1.s	{ v17 }[2], [x10]
	st1.s	{ v17 }[3], [x9]
	add	x8, x8, #1
	cmp	x8, #96
	b.ne	LBB0_25
; %bb.26:                               ; %common.ret
	add	sp, sp, #2080
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_110
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2688
	mov	x22, x3
	mov	x24, x2
	mov	x25, x0
	mov	w28, #0                         ; =0x0
	ldp	w20, w8, [x2, #44]
	str	w8, [sp, #172]                  ; 4-byte Spill
Lloh4:
	adrp	x8, lCPI1_0@PAGE
Lloh5:
	ldr	q25, [x8, lCPI1_0@PAGEOFF]
Lloh6:
	adrp	x8, lCPI1_1@PAGE
Lloh7:
	ldr	q19, [x8, lCPI1_1@PAGEOFF]
Lloh8:
	adrp	x8, lCPI1_2@PAGE
Lloh9:
	ldr	q18, [x8, lCPI1_2@PAGEOFF]
	mov	w23, #52429                     ; =0xcccd
	mov	w26, #80                        ; =0x50
	mov	w27, #43691                     ; =0xaaab
	mov	w19, #96                        ; =0x60
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #192]                  ; 16-byte Spill
	ldp	w12, w13, [x2]
	ldp	w14, w8, [x2, #8]
	str	x8, [sp, #160]                  ; 8-byte Spill
	str	w3, [sp, #28]                   ; 4-byte Spill
	stp	x0, x2, [sp, #8]                ; 16-byte Folded Spill
	str	w20, [sp, #140]                 ; 4-byte Spill
	str	q25, [sp, #464]                 ; 16-byte Spill
	str	q19, [sp, #112]                 ; 16-byte Spill
	str	q18, [sp, #144]                 ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x24, #36]
	ldr	w20, [sp, #140]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x12, [sp, #184]                 ; 8-byte Reload
	add	w8, w12, #1
	cmp	w8, w20
	cset	w8, eq
	csinc	w12, wzr, w12, eq
	cinc	w9, w13, eq
	ldr	w10, [sp, #172]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w13, wzr, w9, ne
	add	w14, w14, w8
	add	w28, w28, #1
	cmp	w28, w22
	b.eq	LBB1_109
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_32 Depth 2
                                        ;     Child Loop BB1_34 Depth 2
                                        ;       Child Loop BB1_36 Depth 3
                                        ;       Child Loop BB1_55 Depth 3
                                        ;       Child Loop BB1_73 Depth 3
                                        ;       Child Loop BB1_75 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_79 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;       Child Loop BB1_83 Depth 3
                                        ;         Child Loop BB1_84 Depth 4
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_89 Depth 3
                                        ;     Child Loop BB1_93 Depth 2
	ubfiz	x8, x12, #5, #32
	ldr	x15, [sp, #160]                 ; 8-byte Reload
	cmp	x8, x15
	csel	x9, x8, xzr, ls
	subs	x10, x15, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x15, x9
	str	x12, [sp, #184]                 ; 8-byte Spill
	stp	w12, w13, [x24]
	stp	w14, w13, [sp, #176]            ; 8-byte Folded Spill
	str	w14, [x24, #8]
	str	wzr, [x24, #36]
	ccmp	x8, x15, #2, hi
	csel	x21, x10, xzr, ls
	cmp	x21, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x25
	mov	x1, x24
	bl	_llm_attention.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x24, #36]
	mov	x0, x25
	mov	x1, x24
	bl	_llm_attention.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x24, #36]
	mov	x0, x25
	mov	x1, x24
	bl	_llm_attention.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x24, #36]
	mov	x0, x25
	mov	x1, x24
	bl	_llm_attention.full_packet
	ldp	w14, w13, [sp, #176]            ; 8-byte Folded Reload
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x20, x21, #3
	cbz	x20, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x24, #36]
	mov	x0, x25
	mov	x1, x24
	bl	_llm_attention.full_packet
	cmp	x20, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x24, #36]
	mov	x0, x25
	mov	x1, x24
	bl	_llm_attention.full_packet
	cmp	x20, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x24, #36]
	mov	x0, x25
	mov	x1, x24
	bl	_llm_attention.full_packet
	cmp	x20, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x24, #36]
	mov	x0, x25
	mov	x1, x24
	bl	_llm_attention.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x24, #36]
	mov	x0, x25
	mov	x1, x24
	bl	_llm_attention.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x24, #36]
	mov	x0, x25
	mov	x1, x24
	bl	_llm_attention.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x24, #36]
	mov	x0, x25
	mov	x1, x24
	bl	_llm_attention.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w21, #0x7
	ldr	q25, [sp, #464]                 ; 16-byte Reload
	ldr	q19, [sp, #112]                 ; 16-byte Reload
	ldr	q18, [sp, #144]                 ; 16-byte Reload
	ldp	w14, w13, [sp, #176]            ; 8-byte Folded Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v20, w8
	cmhi.4s	v0, v20, v19
	cmhi.4s	v2, v20, v25
	uzp1.8h	v6, v2, v0
	umaxv.8h	h1, v6
	fmov	w8, s1
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [x24, #136]
	add	x8, x10, #2560
	mov	w11, #5632                      ; =0x1600
	add	x11, x10, x11
	mov	w12, #8704                      ; =0x2200
	add	x12, x10, x12
	mov	w13, #49664                     ; =0xc200
	add	x13, x10, x13
	mov	w14, #33280                     ; =0x8200
	movk	w14, #1, lsl #16
	add	x14, x10, x14
	mov	w15, #33792                     ; =0x8400
	movk	w15, #1, lsl #16
	add	x15, x10, x15
	mov	w16, #34304                     ; =0x8600
	movk	w16, #1, lsl #16
	add	x16, x10, x16
	ldr	x1, [x25]
	ldr	x17, [x25, #16]
	ldr	x0, [x25, #32]
	lsl	w2, w20, #3
	ldr	x3, [sp, #184]                  ; 8-byte Reload
	orr	w2, w2, w3, lsl #5
	dup.4s	v1, w2
	ldr	x2, [x25, #48]
	str	x2, [sp, #96]                   ; 8-byte Spill
	orr.16b	v3, v1, v19
	orr.16b	v1, v1, v25
	and.16b	v5, v2, v1
	and.16b	v4, v0, v3
	ushll2.2d	v21, v4, #0
	ushll2.2d	v22, v5, #0
	ushll.2d	v23, v4, #0
	ushll.2d	v24, v5, #0
	movi.4s	v3, #80
	umull2.2d	v1, v4, v3
	umull2.2d	v3, v5, v3
	movi.2s	v7, #80
	umull.2d	v4, v4, v7
	umull.2d	v5, v5, v7
	and.16b	v6, v6, v18
	addv.8h	h7, v6
	dup.2d	v6, x1
	str	q7, [sp, #2448]                 ; 16-byte Spill
	fmov	w1, s7
	b	LBB1_15
LBB1_14:                                ; %else244
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x2, x10, x9, lsl #5
	ldp	q17, q18, [x2]
	bif.16b	v16, v18, v0
	bif.16b	v7, v17, v2
	stp	q7, q16, [x2]
	add	x9, x9, #1
	cmp	x9, #80
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x9
	add.2d	v7, v17, v5
	shl.2d	v7, v7, #2
	add.2d	v18, v6, v7
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w1, #0, LBB1_23
; %bb.16:                               ; %else
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w2, w1, #0xff
	tbnz	w2, #1, LBB1_24
LBB1_17:                                ; %else226
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v18, v17, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v6, v18
	tbnz	w2, #2, LBB1_25
LBB1_18:                                ; %else229
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w2, #3, LBB1_26
LBB1_19:                                ; %else232
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v18, v17, v4
	shl.2d	v18, v18, #2
	add.2d	v18, v6, v18
	tbnz	w2, #4, LBB1_27
LBB1_20:                                ; %else235
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w2, #5, LBB1_28
LBB1_21:                                ; %else238
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v17, v17, v1
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbnz	w2, #6, LBB1_29
LBB1_22:                                ; %else241
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w2, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x2, d18
	ldr	s7, [x2]
	and	w2, w1, #0xff
	tbz	w2, #1, LBB1_17
LBB1_24:                                ; %cond.load225
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x3, v18[1]
	ld1.s	{ v7 }[1], [x3]
	add.2d	v18, v17, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v6, v18
	tbz	w2, #2, LBB1_18
LBB1_25:                                ; %cond.load228
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x3, d18
	ld1.s	{ v7 }[2], [x3]
	tbz	w2, #3, LBB1_19
LBB1_26:                                ; %cond.load231
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x3, v18[1]
	ld1.s	{ v7 }[3], [x3]
	add.2d	v18, v17, v4
	shl.2d	v18, v18, #2
	add.2d	v18, v6, v18
	tbz	w2, #4, LBB1_20
LBB1_27:                                ; %cond.load234
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x3, d18
	ld1.s	{ v16 }[0], [x3]
	tbz	w2, #5, LBB1_21
LBB1_28:                                ; %cond.load237
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x3, v18[1]
	ld1.s	{ v16 }[1], [x3]
	add.2d	v17, v17, v1
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbz	w2, #6, LBB1_22
LBB1_29:                                ; %cond.load240
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x3, d17
	ld1.s	{ v16 }[2], [x3]
	tbz	w2, #7, LBB1_14
LBB1_30:                                ; %cond.load243
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x2, v17[1]
	ld1.s	{ v16 }[3], [x2]
	b	LBB1_14
LBB1_31:                                ; %direct.true147.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w28, [sp, #108]                 ; 4-byte Spill
	mov	x9, #0                          ; =0x0
LBB1_32:                                ; %direct.true147.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x1, x8, x9
	ldp	q1, q3, [x1]
	cmhs.4s	v4, v19, v20
	and.16b	v3, v4, v3
	cmhs.4s	v4, v25, v20
	and.16b	v1, v4, v1
	stp	q1, q3, [x1]
	add	x9, x9, #32
	cmp	x9, #3072
	b.ne	LBB1_32
; %bb.33:                               ; %direct.false148.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q20, [sp, #448]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	sshll.2d	v1, v2, #0
	sshll.2d	v3, v0, #0
	sshll2.2d	v9, v2, #0
	sshll2.2d	v18, v0, #0
	stp	q24, q23, [sp, #32]             ; 32-byte Folded Spill
	ushr.2d	v4, v24, #2
	stp	q22, q21, [sp, #64]             ; 32-byte Folded Spill
	ushr.2d	v5, v22, #2
	ushr.2d	v6, v23, #2
	ushr.2d	v7, v21, #2
Lloh10:
	adrp	x9, lCPI1_6@PAGE
Lloh11:
	ldr	q16, [x9, lCPI1_6@PAGEOFF]
	str	q16, [sp, #1840]                ; 16-byte Spill
	and.16b	v16, v1, v16
	str	q16, [sp, #2576]                ; 16-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v16, w9
	and.16b	v17, v0, v16
	str	q17, [sp, #2272]                ; 16-byte Spill
	str	q16, [sp, #416]                 ; 16-byte Spill
	and.16b	v16, v2, v16
	str	q16, [sp, #2256]                ; 16-byte Spill
	mov.d	x9, v7[1]
	mov	w3, #2053                       ; =0x805
	mul	x9, x9, x3
	fmov	x2, d7
	mul	x2, x2, x3
	fmov	d7, x2
	mov.d	v7[1], x9
	mov.d	x9, v6[1]
	mul	x9, x9, x3
	fmov	x2, d6
	mul	x2, x2, x3
	fmov	d6, x2
	mov.d	v6[1], x9
	mov.d	x9, v5[1]
	mul	x9, x9, x3
	fmov	x2, d5
	mul	x2, x2, x3
	fmov	d5, x2
	mov.d	v5[1], x9
	mov.d	x9, v4[1]
	mul	x9, x9, x3
	fmov	x2, d4
	mul	x2, x2, x3
	fmov	d4, x2
	mov.d	v4[1], x9
	and.16b	v24, v1, v4
	and.16b	v1, v9, v5
	str	q1, [sp, #2560]                 ; 16-byte Spill
	and.16b	v3, v3, v6
	str	q18, [sp, #2608]                ; 16-byte Spill
	and.16b	v1, v18, v7
	str	q1, [sp, #2544]                 ; 16-byte Spill
	movi.2d	v20, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #2464]                 ; 16-byte Spill
	str	q1, [sp, #1824]                 ; 16-byte Spill
	str	q1, [sp, #1808]                 ; 16-byte Spill
	mov	w9, #33312                      ; =0x8220
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #376]                  ; 8-byte Spill
	str	q1, [sp, #1792]                 ; 16-byte Spill
	mov	w9, #33344                      ; =0x8240
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #368]                  ; 8-byte Spill
	str	q1, [sp, #1776]                 ; 16-byte Spill
	mov	w9, #33376                      ; =0x8260
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #360]                  ; 8-byte Spill
	str	q1, [sp, #1760]                 ; 16-byte Spill
	mov	w9, #33408                      ; =0x8280
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #352]                  ; 8-byte Spill
	str	q1, [sp, #1744]                 ; 16-byte Spill
	mov	w9, #33440                      ; =0x82a0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #344]                  ; 8-byte Spill
	str	q1, [sp, #1728]                 ; 16-byte Spill
	mov	w9, #33472                      ; =0x82c0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #336]                  ; 8-byte Spill
	str	q1, [sp, #2240]                 ; 16-byte Spill
	mov	w9, #33504                      ; =0x82e0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #328]                  ; 8-byte Spill
	str	q1, [sp, #2224]                 ; 16-byte Spill
	mov	w9, #33536                      ; =0x8300
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #320]                  ; 8-byte Spill
	str	q1, [sp, #1712]                 ; 16-byte Spill
	mov	w9, #33568                      ; =0x8320
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #312]                  ; 8-byte Spill
	str	q1, [sp, #1696]                 ; 16-byte Spill
	mov	w9, #33600                      ; =0x8340
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #304]                  ; 8-byte Spill
	mov	w9, #33632                      ; =0x8360
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #296]                  ; 8-byte Spill
	mov	w9, #33664                      ; =0x8380
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #288]                  ; 8-byte Spill
	mov	w9, #33696                      ; =0x83a0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #280]                  ; 8-byte Spill
	mov	w9, #33728                      ; =0x83c0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #272]                  ; 8-byte Spill
	mov	w9, #33760                      ; =0x83e0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #264]                  ; 8-byte Spill
	mov	w9, #33824                      ; =0x8420
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #256]                  ; 8-byte Spill
	mov	w9, #33856                      ; =0x8440
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #248]                  ; 8-byte Spill
	mov	w9, #33888                      ; =0x8460
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #240]                  ; 8-byte Spill
	mov	w9, #33920                      ; =0x8480
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #232]                  ; 8-byte Spill
	mov	w9, #33952                      ; =0x84a0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #224]                  ; 8-byte Spill
	mov	w9, #33984                      ; =0x84c0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #216]                  ; 8-byte Spill
	mov	w9, #34016                      ; =0x84e0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #208]                  ; 8-byte Spill
	mov	w9, #34048                      ; =0x8500
	movk	w9, #1, lsl #16
	add	x25, x10, x9
	mov	w9, #34080                      ; =0x8520
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	mov	w2, #34112                      ; =0x8540
	movk	w2, #1, lsl #16
	add	x22, x10, x2
	mov	w2, #34144                      ; =0x8560
	movk	w2, #1, lsl #16
	add	x24, x10, x2
	mov	w2, #34176                      ; =0x8580
	movk	w2, #1, lsl #16
	add	x28, x10, x2
	mov	w2, #34208                      ; =0x85a0
	movk	w2, #1, lsl #16
	add	x20, x10, x2
	mov	w2, #34240                      ; =0x85c0
	movk	w2, #1, lsl #16
	add	x2, x10, x2
	mov	w3, #34272                      ; =0x85e0
	movk	w3, #1, lsl #16
	add	x3, x10, x3
	str	q1, [sp, #1680]                 ; 16-byte Spill
	str	q1, [sp, #1664]                 ; 16-byte Spill
	str	q1, [sp, #2208]                 ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	str	q4, [sp, #2192]                 ; 16-byte Spill
	str	q1, [sp, #2176]                 ; 16-byte Spill
	movi.2d	v8, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	str	q1, [sp, #2640]                 ; 16-byte Spill
	str	q1, [sp, #2624]                 ; 16-byte Spill
	str	q1, [sp, #2160]                 ; 16-byte Spill
	str	q4, [sp, #2144]                 ; 16-byte Spill
	str	q1, [sp, #2128]                 ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	str	q1, [sp, #2112]                 ; 16-byte Spill
	movi.2d	v25, #0000000000000000
	str	q1, [sp, #1600]                 ; 16-byte Spill
	str	q1, [sp, #2096]                 ; 16-byte Spill
	str	q1, [sp, #2080]                 ; 16-byte Spill
	str	q1, [sp, #2064]                 ; 16-byte Spill
	str	q4, [sp, #2048]                 ; 16-byte Spill
	str	q4, [sp, #2032]                 ; 16-byte Spill
	movi.2d	v16, #0000000000000000
	movi.2d	v23, #0000000000000000
	str	q4, [sp, #2016]                 ; 16-byte Spill
	str	q1, [sp, #2000]                 ; 16-byte Spill
	movi.2d	v22, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v18, #0000000000000000
	str	q4, [sp, #2528]                 ; 16-byte Spill
	str	q4, [sp, #2512]                 ; 16-byte Spill
	str	q4, [sp, #2496]                 ; 16-byte Spill
	str	q4, [sp, #2656]                 ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q4, [sp, #1648]                 ; 16-byte Spill
	str	q4, [sp, #1632]                 ; 16-byte Spill
	str	q4, [sp, #1616]                 ; 16-byte Spill
	str	q4, [sp, #1856]                 ; 16-byte Spill
	str	q9, [sp, #432]                  ; 16-byte Spill
	stp	q3, q24, [sp, #384]             ; 32-byte Folded Spill
LBB1_34:                                ; %direct.true157.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_36 Depth 3
                                        ;       Child Loop BB1_55 Depth 3
                                        ;       Child Loop BB1_73 Depth 3
                                        ;       Child Loop BB1_75 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_79 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;       Child Loop BB1_83 Depth 3
                                        ;         Child Loop BB1_84 Depth 4
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_89 Depth 3
	str	q19, [sp, #2480]                ; 16-byte Spill
	str	q18, [sp, #2592]                ; 16-byte Spill
	mov	x5, #0                          ; =0x0
	lsl	x4, x1, #4
	b	LBB1_36
LBB1_35:                                ; %direct.schedule.12.i.i
                                        ;   in Loop: Header=BB1_36 Depth=3
	str	q18, [sp, #2496]                ; 16-byte Spill
	str	q6, [sp, #2512]                 ; 16-byte Spill
	str	q5, [sp, #2528]                 ; 16-byte Spill
	add	x6, x12, x5, lsl #5
	ldp	q4, q5, [x6]
	bit.16b	v5, v21, v0
	bit.16b	v4, v7, v2
	stp	q4, q5, [x6]
	add	x5, x5, #1
	cmp	x5, #1280
	b.eq	LBB1_53
LBB1_36:                                ; %direct.true161.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w6, w5, #0xffff
	mul	w6, w6, w23
	lsr	w7, w6, #22
	add	x6, x4, x7
	dup.2d	v4, x6
	ldr	q5, [sp, #2560]                 ; 16-byte Reload
	add.2d	v5, v4, v5
	add.2d	v6, v4, v3
	ldr	q7, [sp, #2544]                 ; 16-byte Reload
	add.2d	v7, v4, v7
	mov.d	x30, v7[1]
	fmov	x21, d7
	add	x21, x21, x21, lsl #2
	lsl	x21, x21, #4
	fmov	d7, x21
	add	x21, x30, x30, lsl #2
	lsl	x21, x21, #4
	mov.d	v7[1], x21
	mov.d	x21, v6[1]
	fmov	x30, d6
	add	x30, x30, x30, lsl #2
	lsl	x30, x30, #4
	fmov	d6, x30
	add	x21, x21, x21, lsl #2
	lsl	x21, x21, #4
	mov.d	v6[1], x21
	mov.d	x21, v5[1]
	add.2d	v4, v4, v24
	fmov	x30, d5
	add	x30, x30, x30, lsl #2
	lsl	x30, x30, #4
	fmov	d5, x30
	add	x21, x21, x21, lsl #2
	lsl	x21, x21, #4
	mov.d	v5[1], x21
	mov.d	x21, v4[1]
	fmov	x30, d4
	add	x30, x30, x30, lsl #2
	lsl	x30, x30, #4
	fmov	d4, x30
	sshll.2d	v17, v2, #0
	msub	w7, w7, w26, w5
	and	x7, x7, #0xffff
	add	x21, x21, x21, lsl #2
	lsl	x21, x21, #4
	mov.d	v4[1], x21
	dup.2d	v18, x7
	sshll.2d	v19, v0, #0
	add.2d	v4, v4, v18
	add.2d	v5, v5, v18
	add.2d	v6, v6, v18
	add.2d	v7, v7, v18
	ldr	q18, [sp, #2656]                ; 16-byte Reload
	ldr	q21, [sp, #2608]                ; 16-byte Reload
	bit.16b	v18, v7, v21
	str	q18, [sp, #2656]                ; 16-byte Spill
	ldr	q18, [sp, #2496]                ; 16-byte Reload
	bit.16b	v18, v6, v19
	ldr	q6, [sp, #2512]                 ; 16-byte Reload
	bit.16b	v6, v5, v9
	ldr	q5, [sp, #2528]                 ; 16-byte Reload
	bit.16b	v5, v4, v17
	movi.2d	v7, #0000000000000000
	movi.2d	v21, #0000000000000000
	cmp	x6, #2052
	b.hi	LBB1_35
; %bb.37:                               ; %direct.true174.i.i
                                        ;   in Loop: Header=BB1_36 Depth=3
	ldr	q4, [sp, #2448]                 ; 16-byte Reload
	fmov	w6, s4
	shl.2d	v4, v5, #2
	dup.2d	v17, x17
	add.2d	v4, v17, v4
	tbnz	w6, #0, LBB1_45
; %bb.38:                               ; %else251
                                        ;   in Loop: Header=BB1_36 Depth=3
	and	w6, w6, #0xff
	tbnz	w6, #1, LBB1_46
LBB1_39:                                ; %else257
                                        ;   in Loop: Header=BB1_36 Depth=3
	shl.2d	v4, v6, #2
	add.2d	v4, v17, v4
	tbnz	w6, #2, LBB1_47
LBB1_40:                                ; %else263
                                        ;   in Loop: Header=BB1_36 Depth=3
	tbnz	w6, #3, LBB1_48
LBB1_41:                                ; %else269
                                        ;   in Loop: Header=BB1_36 Depth=3
	shl.2d	v4, v18, #2
	add.2d	v4, v17, v4
	tbnz	w6, #4, LBB1_49
LBB1_42:                                ; %else275
                                        ;   in Loop: Header=BB1_36 Depth=3
	tbnz	w6, #5, LBB1_50
LBB1_43:                                ; %else281
                                        ;   in Loop: Header=BB1_36 Depth=3
	ldr	q4, [sp, #2656]                 ; 16-byte Reload
	shl.2d	v4, v4, #2
	add.2d	v4, v17, v4
	tbnz	w6, #6, LBB1_51
LBB1_44:                                ; %else287
                                        ;   in Loop: Header=BB1_36 Depth=3
	tbz	w6, #7, LBB1_35
	b	LBB1_52
LBB1_45:                                ; %cond.load247
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x7, d4
	ldr	s7, [x7]
	and	w6, w6, #0xff
	tbz	w6, #1, LBB1_39
LBB1_46:                                ; %cond.load253
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x7, v4[1]
	ld1.s	{ v7 }[1], [x7]
	shl.2d	v4, v6, #2
	add.2d	v4, v17, v4
	tbz	w6, #2, LBB1_40
LBB1_47:                                ; %cond.load259
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x7, d4
	ld1.s	{ v7 }[2], [x7]
	tbz	w6, #3, LBB1_41
LBB1_48:                                ; %cond.load265
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x7, v4[1]
	ld1.s	{ v7 }[3], [x7]
	shl.2d	v4, v18, #2
	add.2d	v4, v17, v4
	tbz	w6, #4, LBB1_42
LBB1_49:                                ; %cond.load271
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x7, d4
	ld1.s	{ v21 }[0], [x7]
	tbz	w6, #5, LBB1_43
LBB1_50:                                ; %cond.load277
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x7, v4[1]
	ld1.s	{ v21 }[1], [x7]
	ldr	q4, [sp, #2656]                 ; 16-byte Reload
	shl.2d	v4, v4, #2
	add.2d	v4, v17, v4
	tbz	w6, #6, LBB1_44
LBB1_51:                                ; %cond.load283
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x7, d4
	ld1.s	{ v21 }[2], [x7]
	tbz	w6, #7, LBB1_35
LBB1_52:                                ; %cond.load289
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x6, v4[1]
	ld1.s	{ v21 }[3], [x6]
	b	LBB1_35
LBB1_53:                                ; %direct.true186.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q8, [sp, #2304]                 ; 16-byte Spill
	mov	x5, #0                          ; =0x0
	b	LBB1_55
LBB1_54:                                ; %direct.schedule.17.i.i
                                        ;   in Loop: Header=BB1_55 Depth=3
	str	q18, [sp, #2592]                ; 16-byte Spill
	add	x6, x13, x5, lsl #5
	ldp	q4, q5, [x6]
	bit.16b	v5, v21, v0
	bit.16b	v4, v7, v2
	stp	q4, q5, [x6]
	add	x5, x5, #1
	cmp	x5, #1536
	b.eq	LBB1_72
LBB1_55:                                ; %direct.true186.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w6, w5, #0xffff
	mul	w6, w6, w27
	lsr	w7, w6, #22
	add	x6, x4, x7
	dup.2d	v4, x6
	ldr	q5, [sp, #2560]                 ; 16-byte Reload
	add.2d	v5, v4, v5
	add.2d	v6, v4, v3
	ldr	q7, [sp, #2544]                 ; 16-byte Reload
	add.2d	v7, v4, v7
	mov.d	x21, v7[1]
	fmov	x30, d7
	add	x30, x30, x30, lsl #1
	lsl	x30, x30, #5
	fmov	d7, x30
	add	x21, x21, x21, lsl #1
	lsl	x21, x21, #5
	mov.d	v7[1], x21
	mov.d	x21, v6[1]
	fmov	x30, d6
	add	x30, x30, x30, lsl #1
	lsl	x30, x30, #5
	fmov	d6, x30
	add	x21, x21, x21, lsl #1
	lsl	x21, x21, #5
	mov.d	v6[1], x21
	mov.d	x21, v5[1]
	add.2d	v4, v4, v24
	fmov	x30, d5
	add	x30, x30, x30, lsl #1
	lsl	x30, x30, #5
	fmov	d5, x30
	add	x21, x21, x21, lsl #1
	lsl	x21, x21, #5
	mov.d	v5[1], x21
	mov.d	x21, v4[1]
	fmov	x30, d4
	add	x30, x30, x30, lsl #1
	lsl	x30, x30, #5
	fmov	d4, x30
	sshll.2d	v17, v2, #0
	msub	w7, w7, w19, w5
	and	x7, x7, #0xffff
	add	x21, x21, x21, lsl #1
	lsl	x21, x21, #5
	mov.d	v4[1], x21
	dup.2d	v18, x7
	sshll.2d	v19, v0, #0
	add.2d	v4, v4, v18
	add.2d	v5, v5, v18
	add.2d	v6, v6, v18
	add.2d	v7, v7, v18
	ldr	q18, [sp, #2592]                ; 16-byte Reload
	ldr	q21, [sp, #2608]                ; 16-byte Reload
	bit.16b	v18, v7, v21
	bit.16b	v1, v6, v19
	bit.16b	v28, v5, v9
	bit.16b	v22, v4, v17
	movi.2d	v7, #0000000000000000
	movi.2d	v21, #0000000000000000
	cmp	x6, #2053
	b.hs	LBB1_54
; %bb.56:                               ; %direct.true199.i.i
                                        ;   in Loop: Header=BB1_55 Depth=3
	ldr	q4, [sp, #2448]                 ; 16-byte Reload
	fmov	w6, s4
	shl.2d	v4, v22, #2
	dup.2d	v17, x0
	add.2d	v4, v17, v4
	tbnz	w6, #0, LBB1_64
; %bb.57:                               ; %else300
                                        ;   in Loop: Header=BB1_55 Depth=3
	and	w6, w6, #0xff
	tbnz	w6, #1, LBB1_65
LBB1_58:                                ; %else306
                                        ;   in Loop: Header=BB1_55 Depth=3
	shl.2d	v4, v28, #2
	add.2d	v4, v17, v4
	tbnz	w6, #2, LBB1_66
LBB1_59:                                ; %else312
                                        ;   in Loop: Header=BB1_55 Depth=3
	tbnz	w6, #3, LBB1_67
LBB1_60:                                ; %else318
                                        ;   in Loop: Header=BB1_55 Depth=3
	shl.2d	v4, v1, #2
	add.2d	v4, v17, v4
	tbnz	w6, #4, LBB1_68
LBB1_61:                                ; %else324
                                        ;   in Loop: Header=BB1_55 Depth=3
	tbnz	w6, #5, LBB1_69
LBB1_62:                                ; %else330
                                        ;   in Loop: Header=BB1_55 Depth=3
	shl.2d	v4, v18, #2
	add.2d	v4, v17, v4
	tbnz	w6, #6, LBB1_70
LBB1_63:                                ; %else336
                                        ;   in Loop: Header=BB1_55 Depth=3
	tbz	w6, #7, LBB1_54
	b	LBB1_71
LBB1_64:                                ; %cond.load296
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x7, d4
	ldr	s7, [x7]
	and	w6, w6, #0xff
	tbz	w6, #1, LBB1_58
LBB1_65:                                ; %cond.load302
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x7, v4[1]
	ld1.s	{ v7 }[1], [x7]
	shl.2d	v4, v28, #2
	add.2d	v4, v17, v4
	tbz	w6, #2, LBB1_59
LBB1_66:                                ; %cond.load308
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x7, d4
	ld1.s	{ v7 }[2], [x7]
	tbz	w6, #3, LBB1_60
LBB1_67:                                ; %cond.load314
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x7, v4[1]
	ld1.s	{ v7 }[3], [x7]
	shl.2d	v4, v1, #2
	add.2d	v4, v17, v4
	tbz	w6, #4, LBB1_61
LBB1_68:                                ; %cond.load320
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x7, d4
	ld1.s	{ v21 }[0], [x7]
	tbz	w6, #5, LBB1_62
LBB1_69:                                ; %cond.load326
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x7, v4[1]
	ld1.s	{ v21 }[1], [x7]
	shl.2d	v4, v18, #2
	add.2d	v4, v17, v4
	tbz	w6, #6, LBB1_63
LBB1_70:                                ; %cond.load332
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x7, d4
	ld1.s	{ v21 }[2], [x7]
	tbz	w6, #7, LBB1_54
LBB1_71:                                ; %cond.load338
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x6, v4[1]
	ld1.s	{ v21 }[3], [x6]
	b	LBB1_54
LBB1_72:                                ; %direct.false187.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q1, [sp, #1536]                 ; 16-byte Spill
	str	q28, [sp, #1552]                ; 16-byte Spill
	str	q22, [sp, #1568]                ; 16-byte Spill
	str	q20, [sp, #1584]                ; 16-byte Spill
	mov	x4, #0                          ; =0x0
	sshll.2d	v4, v2, #0
	sshll.2d	v5, v0, #0
Lloh12:
	adrp	x5, lCPI1_3@PAGE
Lloh13:
	ldr	q6, [x5, lCPI1_3@PAGEOFF]
	ldr	q1, [sp, #1616]                 ; 16-byte Reload
	ldr	q3, [sp, #2608]                 ; 16-byte Reload
	str	q6, [sp, #2432]                 ; 16-byte Spill
	bit.16b	v1, v6, v3
	str	q1, [sp, #1616]                 ; 16-byte Spill
Lloh14:
	adrp	x5, lCPI1_4@PAGE
Lloh15:
	ldr	q3, [x5, lCPI1_4@PAGEOFF]
	ldr	q1, [sp, #1648]                 ; 16-byte Reload
	str	q3, [sp, #1504]                 ; 16-byte Spill
	bit.16b	v1, v3, v9
	str	q1, [sp, #1648]                 ; 16-byte Spill
Lloh16:
	adrp	x5, lCPI1_5@PAGE
Lloh17:
	ldr	q3, [x5, lCPI1_5@PAGEOFF]
	ldr	q1, [sp, #1632]                 ; 16-byte Reload
	str	q3, [sp, #1520]                 ; 16-byte Spill
	bit.16b	v1, v3, v5
	str	q1, [sp, #1632]                 ; 16-byte Spill
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	ldr	q1, [sp, #2480]                 ; 16-byte Reload
	bit.16b	v1, v3, v4
	str	q1, [sp, #2480]                 ; 16-byte Spill
	ldr	q24, [sp, #2000]                ; 16-byte Reload
	bic.16b	v24, v24, v0
	ldr	q22, [sp, #2016]                ; 16-byte Reload
	bic.16b	v22, v22, v2
	bic.16b	v23, v23, v0
	bic.16b	v16, v16, v2
	ldr	q21, [sp, #2032]                ; 16-byte Reload
	bic.16b	v21, v21, v0
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	bic.16b	v3, v3, v2
	ldr	q8, [sp, #2064]                 ; 16-byte Reload
	bic.16b	v8, v8, v0
	ldr	q9, [sp, #2080]                 ; 16-byte Reload
	bic.16b	v9, v9, v2
LBB1_73:                                ; %direct.true211.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d4, x4
	ldr	q5, [sp, #2576]                 ; 16-byte Reload
	orr.16b	v5, v4, v5
	fmov	x5, d5
	add	x5, x10, x5
	ldp	q6, q5, [x5]
	and.16b	v6, v2, v6
	and.16b	v5, v0, v5
	ldr	q7, [sp, #2480]                 ; 16-byte Reload
	orr.16b	v4, v4, v7
	fmov	x5, d4
	add	x5, x12, x5
	ldp	q7, q4, [x5]
	and.16b	v7, v2, v7
	and.16b	v4, v0, v4
	fmul.4s	v4, v5, v4
	fmul.4s	v7, v6, v7
	fadd.4s	v7, v22, v7
	fadd.4s	v4, v24, v4
	add	x5, x10, x4
	ldr	q17, [x5, #11280]
	ldr	q18, [x5, #11264]
	and.16b	v18, v2, v18
	and.16b	v17, v0, v17
	fmul.4s	v17, v5, v17
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v16, v18
	fadd.4s	v17, v23, v17
	ldr	q19, [x5, #13840]
	ldr	q20, [x5, #13824]
	and.16b	v20, v2, v20
	and.16b	v19, v0, v19
	fmul.4s	v19, v5, v19
	fmul.4s	v20, v6, v20
	fadd.4s	v20, v3, v20
	fadd.4s	v19, v21, v19
	mov.16b	v28, v22
	mov.16b	v22, v23
	mov.16b	v23, v16
	mov.16b	v16, v21
	ldr	q21, [x5, #16400]
	mov.16b	v1, v24
	ldr	q24, [x5, #16384]
	and.16b	v24, v2, v24
	and.16b	v21, v0, v21
	fmul.4s	v5, v5, v21
	mov.16b	v21, v16
	mov.16b	v16, v23
	mov.16b	v23, v22
	fmul.4s	v6, v6, v24
	fadd.4s	v6, v9, v6
	fadd.4s	v5, v8, v5
	mov.16b	v24, v0
	bsl.16b	v24, v4, v1
	mov.16b	v22, v2
	bsl.16b	v22, v7, v28
	bit.16b	v23, v17, v0
	bit.16b	v16, v18, v2
	bit.16b	v21, v19, v0
	bit.16b	v3, v20, v2
	bit.16b	v8, v5, v0
	bit.16b	v9, v6, v2
	add	x4, x4, #32
	cmp	x4, #2560
	b.ne	LBB1_73
; %bb.74:                               ; %direct.false212.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q24, [sp, #2000]                ; 16-byte Spill
	str	q22, [sp, #2016]                ; 16-byte Spill
	str	q23, [sp, #1904]                ; 16-byte Spill
	str	q16, [sp, #1920]                ; 16-byte Spill
	str	q21, [sp, #2032]                ; 16-byte Spill
	str	q3, [sp, #2048]                 ; 16-byte Spill
	str	q8, [sp, #2064]                 ; 16-byte Spill
	str	q9, [sp, #2080]                 ; 16-byte Spill
	ldr	q9, [sp, #2096]                 ; 16-byte Reload
	bic.16b	v9, v9, v0
	ldr	q22, [sp, #1600]                ; 16-byte Reload
	bic.16b	v22, v22, v2
	bic.16b	v25, v25, v0
	ldr	q23, [sp, #2112]                ; 16-byte Reload
	bic.16b	v23, v23, v2
	bic.16b	v15, v15, v0
	ldr	q21, [sp, #2128]                ; 16-byte Reload
	bic.16b	v21, v21, v2
	ldr	q7, [sp, #2144]                 ; 16-byte Reload
	bic.16b	v7, v7, v0
	mov	x4, x10
	mov	w5, #80                         ; =0x50
	ldr	q1, [sp, #2160]                 ; 16-byte Reload
	bic.16b	v1, v1, v2
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
LBB1_75:                                ; %direct.true247.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q5, q4, [x4]
	and.16b	v5, v2, v5
	and.16b	v4, v0, v4
	ldr	q6, [x4, #18960]
	mov.16b	v28, v7
	ldr	q7, [x4, #18944]
	and.16b	v7, v2, v7
	and.16b	v6, v0, v6
	fmul.4s	v6, v4, v6
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v22, v7
	fadd.4s	v6, v9, v6
	ldr	q17, [x4, #21520]
	ldr	q18, [x4, #21504]
	and.16b	v18, v2, v18
	and.16b	v17, v0, v17
	fmul.4s	v17, v4, v17
	fmul.4s	v18, v5, v18
	fadd.4s	v18, v23, v18
	fadd.4s	v17, v25, v17
	ldr	q19, [x4, #24080]
	ldr	q20, [x4, #24064]
	and.16b	v20, v2, v20
	and.16b	v19, v0, v19
	fmul.4s	v19, v4, v19
	fmul.4s	v20, v5, v20
	fadd.4s	v20, v21, v20
	fadd.4s	v19, v15, v19
	mov.16b	v16, v25
	mov.16b	v25, v15
	mov.16b	v15, v21
	ldr	q21, [x4, #26640]
	ldr	q24, [x4, #26624]
	and.16b	v24, v2, v24
	and.16b	v21, v0, v21
	fmul.4s	v4, v4, v21
	mov.16b	v21, v15
	mov.16b	v15, v25
	fmul.4s	v5, v5, v24
	fadd.4s	v5, v1, v5
	fadd.4s	v4, v28, v4
	bit.16b	v9, v6, v0
	bit.16b	v22, v7, v2
	mov.16b	v25, v0
	bsl.16b	v25, v17, v16
	bit.16b	v23, v18, v2
	bit.16b	v15, v19, v0
	bit.16b	v21, v20, v2
	mov.16b	v7, v0
	bsl.16b	v7, v4, v28
	bit.16b	v1, v5, v2
	add	x4, x4, #32
	subs	x5, x5, #1
	b.ne	LBB1_75
; %bb.76:                               ; %direct.false248.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q9, [sp, #2096]                 ; 16-byte Spill
	mov.16b	v28, v22
	str	q25, [sp, #1936]                ; 16-byte Spill
	str	q23, [sp, #2112]                ; 16-byte Spill
	str	q15, [sp, #1952]                ; 16-byte Spill
	str	q21, [sp, #2128]                ; 16-byte Spill
	str	q7, [sp, #2144]                 ; 16-byte Spill
	str	q1, [sp, #2160]                 ; 16-byte Spill
	ldr	q1, [sp, #2624]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2624]                 ; 16-byte Spill
	ldr	q1, [sp, #2640]                 ; 16-byte Reload
	bic.16b	v1, v1, v2
	str	q1, [sp, #2640]                 ; 16-byte Spill
	bic.16b	v27, v27, v0
	bic.16b	v26, v26, v2
	ldr	q8, [sp, #2304]                 ; 16-byte Reload
	bic.16b	v8, v8, v0
	ldr	q25, [sp, #2176]                ; 16-byte Reload
	bic.16b	v25, v25, v2
	ldr	q24, [sp, #2192]                ; 16-byte Reload
	bic.16b	v24, v24, v0
	mov	x4, x10
	mov	w5, #80                         ; =0x50
	ldr	q9, [sp, #2208]                 ; 16-byte Reload
	bic.16b	v9, v9, v2
LBB1_77:                                ; %direct.true285.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q5, q4, [x4]
	and.16b	v5, v2, v5
	and.16b	v4, v0, v4
	ldr	q6, [x4, #29200]
	ldr	q7, [x4, #29184]
	and.16b	v7, v2, v7
	and.16b	v6, v0, v6
	fmul.4s	v6, v4, v6
	fmul.4s	v7, v5, v7
	ldr	q22, [sp, #2640]                ; 16-byte Reload
	fadd.4s	v7, v22, v7
	ldr	q23, [sp, #2624]                ; 16-byte Reload
	fadd.4s	v6, v23, v6
	ldr	q17, [x4, #31760]
	ldr	q18, [x4, #31744]
	and.16b	v18, v2, v18
	and.16b	v17, v0, v17
	fmul.4s	v17, v4, v17
	fmul.4s	v18, v5, v18
	fadd.4s	v18, v26, v18
	fadd.4s	v17, v27, v17
	ldr	q19, [x4, #34320]
	ldr	q20, [x4, #34304]
	and.16b	v20, v2, v20
	and.16b	v19, v0, v19
	fmul.4s	v19, v4, v19
	fmul.4s	v20, v5, v20
	fadd.4s	v20, v25, v20
	fadd.4s	v19, v8, v19
	ldr	q21, [x4, #36880]
	mov.16b	v16, v27
	mov.16b	v27, v26
	mov.16b	v26, v8
	mov.16b	v8, v25
	mov.16b	v25, v24
	ldr	q24, [x4, #36864]
	and.16b	v24, v2, v24
	and.16b	v21, v0, v21
	fmul.4s	v4, v4, v21
	fmul.4s	v5, v5, v24
	mov.16b	v24, v25
	mov.16b	v25, v8
	mov.16b	v8, v26
	mov.16b	v26, v27
	fadd.4s	v5, v9, v5
	fadd.4s	v4, v24, v4
	bit.16b	v23, v6, v0
	str	q23, [sp, #2624]                ; 16-byte Spill
	bit.16b	v22, v7, v2
	str	q22, [sp, #2640]                ; 16-byte Spill
	mov.16b	v27, v0
	bsl.16b	v27, v17, v16
	bit.16b	v26, v18, v2
	bit.16b	v8, v19, v0
	bit.16b	v25, v20, v2
	bit.16b	v24, v4, v0
	bit.16b	v9, v5, v2
	add	x4, x4, #32
	subs	x5, x5, #1
	b.ne	LBB1_77
; %bb.78:                               ; %direct.false286.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q27, [sp, #1968]                ; 16-byte Spill
	str	q26, [sp, #1984]                ; 16-byte Spill
	str	q8, [sp, #2304]                 ; 16-byte Spill
	str	q25, [sp, #2176]                ; 16-byte Spill
	str	q24, [sp, #2192]                ; 16-byte Spill
	str	q9, [sp, #2208]                 ; 16-byte Spill
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	ldr	q15, [sp, #1680]                ; 16-byte Reload
	bic.16b	v15, v15, v2
	ldr	q8, [sp, #1696]                 ; 16-byte Reload
	bic.16b	v8, v8, v0
	ldr	q27, [sp, #1712]                ; 16-byte Reload
	bic.16b	v27, v27, v2
	ldr	q26, [sp, #2224]                ; 16-byte Reload
	bic.16b	v26, v26, v0
	ldr	q25, [sp, #2240]                ; 16-byte Reload
	bic.16b	v25, v25, v2
	ldr	q22, [sp, #1728]                ; 16-byte Reload
	bic.16b	v22, v22, v0
	mov	x4, x10
	mov	w5, #80                         ; =0x50
	bic.16b	v3, v3, v2
	ldr	q16, [sp, #2064]                ; 16-byte Reload
LBB1_79:                                ; %direct.true323.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q5, q4, [x4]
	and.16b	v5, v2, v5
	and.16b	v4, v0, v4
	ldr	q6, [x4, #39440]
	ldr	q7, [x4, #39424]
	and.16b	v7, v2, v7
	and.16b	v6, v0, v6
	fmul.4s	v6, v4, v6
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v15, v7
	fadd.4s	v6, v1, v6
	ldr	q17, [x4, #42000]
	ldr	q18, [x4, #41984]
	and.16b	v18, v2, v18
	and.16b	v17, v0, v17
	fmul.4s	v17, v4, v17
	fmul.4s	v18, v5, v18
	fadd.4s	v18, v27, v18
	fadd.4s	v17, v8, v17
	ldr	q19, [x4, #44560]
	ldr	q20, [x4, #44544]
	and.16b	v20, v2, v20
	and.16b	v19, v0, v19
	fmul.4s	v19, v4, v19
	fmul.4s	v20, v5, v20
	fadd.4s	v20, v25, v20
	fadd.4s	v19, v26, v19
	ldr	q21, [x4, #47120]
	ldr	q24, [x4, #47104]
	and.16b	v24, v2, v24
	and.16b	v21, v0, v21
	fmul.4s	v4, v4, v21
	fmul.4s	v5, v5, v24
	fadd.4s	v5, v3, v5
	fadd.4s	v4, v22, v4
	bit.16b	v1, v6, v0
	bit.16b	v15, v7, v2
	bit.16b	v8, v17, v0
	bit.16b	v27, v18, v2
	bit.16b	v26, v19, v0
	bit.16b	v25, v20, v2
	bit.16b	v22, v4, v0
	bit.16b	v3, v5, v2
	add	x4, x4, #32
	subs	x5, x5, #1
	b.ne	LBB1_79
; %bb.80:                               ; %direct.false324.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x4, #0                          ; =0x0
	mov	w5, #63790                      ; =0xf92e
	movk	w5, #15844, lsl #16
	mov.16b	v23, v1
	dup.4s	v21, w5
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
	fmul.4s	v7, v1, v21
	ldr	q1, [sp, #2000]                 ; 16-byte Reload
	fmul.4s	v6, v1, v21
	mov	w5, #33280                      ; =0x8200
	movk	w5, #1, lsl #16
	add	x5, x10, x5
	ldp	q4, q5, [x5]
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	fmul.4s	v18, v1, v21
	cmp	x1, #128
	str	q6, [sp, #2416]                 ; 16-byte Spill
	bit.16b	v5, v6, v0
	str	q7, [sp, #2400]                 ; 16-byte Spill
	bit.16b	v4, v7, v2
	stp	q4, q5, [x5]
	cset	w5, lo
	dup.4h	v4, w5
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v17, v1, v21
	ldr	q1, [sp, #2048]                 ; 16-byte Reload
	fmul.4s	v19, v1, v21
	ldr	q1, [sp, #2032]                 ; 16-byte Reload
	fmul.4s	v20, v1, v21
	ldr	q1, [sp, #2080]                 ; 16-byte Reload
	fmul.4s	v9, v1, v21
	ldp	x6, x7, [sp, #368]              ; 16-byte Folded Reload
	ldp	q5, q6, [x7]
	fmul.4s	v7, v16, v21
	str	q28, [sp, #1600]                ; 16-byte Spill
	fmul.4s	v24, v28, v21
	str	q17, [sp, #1888]                ; 16-byte Spill
	bit.16b	v6, v17, v0
	str	q18, [sp, #1408]                ; 16-byte Spill
	bit.16b	v5, v18, v2
	stp	q5, q6, [x7]
	ldr	q1, [sp, #2096]                 ; 16-byte Reload
	fmul.4s	v16, v1, v21
	ldr	q1, [sp, #1936]                 ; 16-byte Reload
	fmul.4s	v5, v1, v21
	ldr	q1, [sp, #2112]                 ; 16-byte Reload
	fmul.4s	v6, v1, v21
	ldp	q17, q18, [x6]
	ldr	q1, [sp, #1952]                 ; 16-byte Reload
	fmul.4s	v28, v1, v21
	str	q20, [sp, #1328]                ; 16-byte Spill
	bit.16b	v18, v20, v0
	str	q19, [sp, #1312]                ; 16-byte Spill
	bit.16b	v17, v19, v2
	stp	q17, q18, [x6]
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	fmul.4s	v18, v1, v21
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v20, v1, v21
	str	q25, [sp, #2240]                ; 16-byte Spill
	ldr	q1, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v25, v1, v21
	ldr	x6, [sp, #360]                  ; 8-byte Reload
	str	q26, [sp, #2224]                ; 16-byte Spill
	ldp	q17, q26, [x6]
	ldr	q1, [sp, #2624]                 ; 16-byte Reload
	fmul.4s	v1, v1, v21
	str	q1, [sp, #2368]                 ; 16-byte Spill
	str	q7, [sp, #1232]                 ; 16-byte Spill
	bit.16b	v26, v7, v0
	str	q9, [sp, #1216]                 ; 16-byte Spill
	bit.16b	v17, v9, v2
	stp	q17, q26, [x6]
	ldr	q1, [sp, #2640]                 ; 16-byte Reload
	fmul.4s	v26, v1, v21
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	fmul.4s	v1, v1, v21
	str	q1, [sp, #2384]                 ; 16-byte Spill
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	fmul.4s	v1, v1, v21
	str	q1, [sp, #2352]                 ; 16-byte Spill
	ldr	x6, [sp, #352]                  ; 8-byte Reload
	ldp	q17, q7, [x6]
	ushll.4s	v4, v4, #0
	str	q16, [sp, #1136]                ; 16-byte Spill
	bit.16b	v7, v16, v0
	str	q24, [sp, #1120]                ; 16-byte Spill
	bit.16b	v17, v24, v2
	stp	q17, q7, [x6]
	shl.4s	v4, v4, #31
	cmlt.4s	v17, v4, #0
	mov.16b	v24, v22
	mov.16b	v9, v3
	ldr	q3, [sp, #416]                  ; 16-byte Reload
	mov.16b	v1, v17
	bsl.16b	v1, v6, v3
	ldr	x6, [sp, #344]                  ; 8-byte Reload
	ldp	q4, q6, [x6]
	bif.16b	v5, v3, v17
	str	q5, [sp, #1024]                 ; 16-byte Spill
	bif.16b	v5, v6, v0
	str	q1, [sp, #1040]                 ; 16-byte Spill
	bit.16b	v4, v1, v2
	stp	q4, q5, [x6]
	ldr	q1, [sp, #2176]                 ; 16-byte Reload
	fmul.4s	v4, v1, v21
	ldr	q1, [sp, #2304]                 ; 16-byte Reload
	fmul.4s	v5, v1, v21
	mov.16b	v1, v17
	bsl.16b	v1, v18, v3
	ldr	x6, [sp, #336]                  ; 8-byte Reload
	ldp	q6, q7, [x6]
	mov.16b	v16, v17
	bsl.16b	v16, v28, v3
	stp	q16, q1, [sp, #928]             ; 32-byte Folded Spill
	bit.16b	v7, v16, v0
	bit.16b	v6, v1, v2
	stp	q6, q7, [x6]
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v6, v1, v21
	ldr	q7, [sp, #2192]                 ; 16-byte Reload
	fmul.4s	v7, v7, v21
	mov.16b	v1, v17
	bsl.16b	v1, v25, v3
	ldr	x6, [sp, #328]                  ; 8-byte Reload
	ldp	q18, q19, [x6]
	mov.16b	v16, v17
	bsl.16b	v16, v20, v3
	stp	q16, q1, [sp, #832]             ; 32-byte Folded Spill
	bit.16b	v19, v16, v0
	bit.16b	v18, v1, v2
	stp	q18, q19, [x6]
	str	q15, [sp, #1680]                ; 16-byte Spill
	fmul.4s	v18, v15, v21
	str	q23, [sp, #1664]                ; 16-byte Spill
	fmul.4s	v19, v23, v21
	mov.16b	v1, v17
	bsl.16b	v1, v26, v3
	ldr	x6, [sp, #320]                  ; 8-byte Reload
	ldp	q20, q25, [x6]
	ldr	q16, [sp, #2368]                ; 16-byte Reload
	bif.16b	v16, v3, v17
	stp	q16, q1, [sp, #736]             ; 32-byte Folded Spill
	bit.16b	v25, v16, v0
	bit.16b	v20, v1, v2
	stp	q20, q25, [x6]
	str	q8, [sp, #1696]                 ; 16-byte Spill
	fmul.4s	v20, v8, v21
	str	q27, [sp, #1712]                ; 16-byte Spill
	fmul.4s	v25, v27, v21
	ldr	q1, [sp, #2352]                 ; 16-byte Reload
	bif.16b	v1, v3, v17
	ldr	x6, [sp, #312]                  ; 8-byte Reload
	ldp	q27, q26, [x6]
	ldr	q16, [sp, #2384]                ; 16-byte Reload
	bif.16b	v16, v3, v17
	stp	q16, q1, [sp, #768]             ; 32-byte Folded Spill
	bit.16b	v27, v16, v2
	bit.16b	v26, v1, v0
	stp	q27, q26, [x6]
	mov.16b	v1, v17
	bsl.16b	v1, v5, v3
	mov.16b	v22, v17
	bsl.16b	v22, v4, v3
	bif.16b	v7, v3, v17
	ldr	x6, [sp, #304]                  ; 8-byte Reload
	ldp	q5, q4, [x6]
	mov.16b	v16, v17
	bsl.16b	v16, v6, v3
	stp	q22, q1, [sp, #864]             ; 32-byte Folded Spill
	bit.16b	v5, v22, v2
	bit.16b	v4, v1, v0
	stp	q5, q4, [x6]
	mov.16b	v1, v17
	bsl.16b	v1, v19, v3
	mov.16b	v6, v17
	bsl.16b	v6, v18, v3
	ldr	x6, [sp, #296]                  ; 8-byte Reload
	ldp	q5, q4, [x6]
	stp	q16, q7, [sp, #960]             ; 32-byte Folded Spill
	bit.16b	v5, v16, v2
	bit.16b	v4, v7, v0
	stp	q5, q4, [x6]
	ldr	x6, [sp, #288]                  ; 8-byte Reload
	ldp	q5, q4, [x6]
	str	q6, [sp, #1056]                 ; 16-byte Spill
	bit.16b	v5, v6, v2
	str	q1, [sp, #1072]                 ; 16-byte Spill
	bit.16b	v4, v1, v0
	stp	q5, q4, [x6]
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	fmul.4s	v4, v1, v21
	ldr	q1, [sp, #2224]                 ; 16-byte Reload
	fmul.4s	v5, v1, v21
	str	q9, [sp, #1744]                 ; 16-byte Spill
	fmul.4s	v6, v9, v21
	str	q24, [sp, #1728]                ; 16-byte Spill
	fmul.4s	v7, v24, v21
	mov.16b	v19, v17
	bsl.16b	v19, v25, v3
	bif.16b	v20, v3, v17
	mov.16b	v16, v17
	bsl.16b	v16, v5, v3
	mov.16b	v18, v17
	bsl.16b	v18, v4, v3
	mov.16b	v1, v17
	bsl.16b	v1, v7, v3
	bit.16b	v3, v6, v17
	ldr	x6, [sp, #280]                  ; 8-byte Reload
	ldp	q5, q4, [x6]
	str	q20, [sp, #1152]                ; 16-byte Spill
	bit.16b	v4, v20, v0
	str	q19, [sp, #1168]                ; 16-byte Spill
	bit.16b	v5, v19, v2
	stp	q5, q4, [x6]
	ldr	x6, [sp, #272]                  ; 8-byte Reload
	ldp	q4, q5, [x6]
	str	q18, [sp, #1248]                ; 16-byte Spill
	bit.16b	v4, v18, v2
	str	q16, [sp, #1264]                ; 16-byte Spill
	bit.16b	v5, v16, v0
	stp	q4, q5, [x6]
	ldr	x6, [sp, #264]                  ; 8-byte Reload
	ldp	q4, q5, [x6]
	str	q3, [sp, #1344]                 ; 16-byte Spill
	bit.16b	v4, v3, v2
	str	q1, [sp, #1360]                 ; 16-byte Spill
	bit.16b	v5, v1, v0
	stp	q4, q5, [x6]
	mvni.4s	v4, #127, msl #16
	ldr	q7, [sp, #1760]                 ; 16-byte Reload
	bit.16b	v7, v4, v0
	ldr	q6, [sp, #1776]                 ; 16-byte Reload
	bit.16b	v6, v4, v2
	dup.8b	v1, w5
	str	d1, [sp, #1488]                 ; 8-byte Spill
LBB1_81:                                ; %direct.true458.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x5, x14, x4
	ldp	q4, q5, [x5]
	and.16b	v5, v0, v5
	and.16b	v4, v2, v4
	fmaxnm.4s	v4, v6, v4
	fmaxnm.4s	v5, v7, v5
	bit.16b	v7, v5, v0
	bit.16b	v6, v4, v2
	add	x4, x4, #32
	cmp	x4, #512
	b.ne	LBB1_81
; %bb.82:                               ; %direct.false459.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x4, #0                          ; =0x0
	ldr	q4, [sp, #2608]                 ; 16-byte Reload
	ldr	q5, [sp, #1792]                 ; 16-byte Reload
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	bit.16b	v5, v1, v4
	str	q5, [sp, #1792]                 ; 16-byte Spill
	str	q6, [sp, #1776]                 ; 16-byte Spill
	ldr	q1, [sp, #2256]                 ; 16-byte Reload
	fmaxnm.4s	v9, v1, v6
	ldr	q3, [sp, #2400]                 ; 16-byte Reload
	fsub.4s	v4, v3, v9
	ldp	q5, q1, [sp, #448]              ; 32-byte Folded Reload
	cmhi.4s	v21, v5, v1
	and.16b	v1, v21, v4
	mov	w5, #-1026555904                ; =0xc2d00000
	dup.4s	v28, w5
	fcmge.4s	v4, v1, v28
	mov	w5, #1120403456                 ; =0x42c80000
	dup.4s	v8, w5
	fcmge.4s	v5, v8, v1
	and.16b	v4, v4, v5
	str	q7, [sp, #1760]                 ; 16-byte Spill
	ldr	q5, [sp, #2272]                 ; 16-byte Reload
	fmaxnm.4s	v3, v5, v7
	str	q3, [sp, #2352]                 ; 16-byte Spill
	ldr	q5, [sp, #2416]                 ; 16-byte Reload
	fsub.4s	v5, v5, v3
	and.16b	v20, v0, v5
	fcmge.4s	v5, v20, v28
	fcmge.4s	v6, v8, v20
	and.16b	v5, v5, v6
	and.16b	v5, v5, v20
	mov	w5, #43579                      ; =0xaa3b
	movk	w5, #16312, lsl #16
	dup.4s	v25, w5
	fmul.4s	v6, v5, v25
	movi.4s	v16, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v16, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v1
	fmul.4s	v7, v4, v25
	bsl.16b	v17, v16, v7
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	mov	w5, #29184                      ; =0x7200
	movk	w5, #16177, lsl #16
	dup.4s	v26, w5
	fmul.4s	v18, v6, v26
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v26
	mov	w5, #48782                      ; =0xbe8e
	movk	w5, #13759, lsl #16
	dup.4s	v24, w5
	fsub.4s	v4, v4, v19
	fmul.4s	v18, v18, v24
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v24
	mov	w5, #11226                      ; =0x2bda
	movk	w5, #14672, lsl #16
	dup.4s	v15, w5
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v15
	mov	w5, #38601                      ; =0x96c9
	movk	w5, #15030, lsl #16
	dup.4s	v3, w5
	fadd.4s	v6, v6, v3
	str	q3, [sp, #1872]                 ; 16-byte Spill
	fmul.4s	v6, v5, v6
	mov	w5, #34982                      ; =0x88a6
	movk	w5, #15368, lsl #16
	dup.4s	v19, w5
	fadd.4s	v6, v6, v19
	str	q19, [sp, #2320]                ; 16-byte Spill
	fmul.4s	v6, v5, v6
	mov	w5, #43642                      ; =0xaa7a
	movk	w5, #15658, lsl #16
	dup.4s	v22, w5
	fadd.4s	v6, v6, v22
	fmul.4s	v6, v5, v6
	mov	w5, #43691                      ; =0xaaab
	movk	w5, #15914, lsl #16
	dup.4s	v23, w5
	fadd.4s	v6, v6, v23
	str	q23, [sp, #2336]                ; 16-byte Spill
	fmul.4s	v6, v5, v6
	movi.4s	v18, #63, lsl #24
	fadd.4s	v6, v6, v18
	movi.4s	v16, #63, lsl #24
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v15
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v19
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fmov.4s	v3, #1.00000000
	fadd.4s	v4, v4, v3
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v3
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v3
	fmov.4s	v23, #1.00000000
	fmul.4s	v4, v4, v6
	str	q1, [sp, #1424]                 ; 16-byte Spill
	fcmgt.4s	v6, v28, v1
	bic.16b	v4, v4, v6
	str	q20, [sp, #1472]                ; 16-byte Spill
	fcmgt.4s	v6, v28, v20
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v20, v8
	mvni.4s	v7, #127, msl #16
	fneg.4s	v3, v7
	str	q3, [sp, #2400]                 ; 16-byte Spill
	bit.16b	v5, v3, v6
	str	q5, [sp, #1456]                 ; 16-byte Spill
	fcmgt.4s	v5, v1, v8
	mov.16b	v1, v5
	bsl.16b	v1, v3, v4
	str	q1, [sp, #1440]                 ; 16-byte Spill
	str	q9, [sp, #2368]                 ; 16-byte Spill
	ldr	q1, [sp, #1408]                 ; 16-byte Reload
	fsub.4s	v4, v1, v9
	and.16b	v20, v21, v4
	fcmge.4s	v4, v20, v28
	fcmge.4s	v5, v8, v20
	and.16b	v4, v4, v5
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	ldr	q27, [sp, #2352]                ; 16-byte Reload
	fsub.4s	v5, v1, v27
	and.16b	v1, v0, v5
	str	q1, [sp, #1888]                 ; 16-byte Spill
	fcmge.4s	v5, v1, v28
	fcmge.4s	v6, v8, v1
	and.16b	v5, v5, v6
	and.16b	v5, v5, v1
	fmul.4s	v6, v5, v25
	mvni.4s	v1, #128, lsl #24
	movi.4s	v17, #75, lsl #24
	mov.16b	v7, v1
	bsl.16b	v7, v17, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v20
	fmul.4s	v7, v4, v25
	bif.16b	v17, v7, v1
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	fmul.4s	v18, v6, v26
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v26
	fsub.4s	v4, v4, v19
	fmul.4s	v18, v18, v24
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v24
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v15
	ldr	q19, [sp, #1872]                ; 16-byte Reload
	fadd.4s	v6, v6, v19
	fmul.4s	v6, v5, v6
	ldr	q3, [sp, #2320]                 ; 16-byte Reload
	fadd.4s	v6, v6, v3
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v22
	fmul.4s	v6, v5, v6
	ldr	q1, [sp, #2336]                 ; 16-byte Reload
	fadd.4s	v6, v6, v1
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v16
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v15
	fadd.4s	v18, v18, v19
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v16
	movi.4s	v3, #63, lsl #24
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fadd.4s	v4, v4, v23
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v23
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v23
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v23
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v23
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v23
	fmul.4s	v4, v4, v6
	str	q20, [sp, #1376]                ; 16-byte Spill
	fcmgt.4s	v6, v28, v20
	bic.16b	v4, v4, v6
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	fcmgt.4s	v6, v28, v1
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v1, v8
	ldr	q16, [sp, #2400]                ; 16-byte Reload
	mov.16b	v1, v6
	bsl.16b	v1, v16, v5
	str	q1, [sp, #1408]                 ; 16-byte Spill
	fcmgt.4s	v5, v20, v8
	mov.16b	v1, v5
	bsl.16b	v1, v16, v4
	str	q1, [sp, #1392]                 ; 16-byte Spill
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	fsub.4s	v4, v1, v9
	and.16b	v20, v21, v4
	fcmge.4s	v4, v20, v28
	fcmge.4s	v5, v8, v20
	and.16b	v4, v4, v5
	mov.16b	v1, v27
	ldr	q5, [sp, #1328]                 ; 16-byte Reload
	fsub.4s	v5, v5, v27
	and.16b	v9, v0, v5
	fcmge.4s	v5, v9, v28
	fcmge.4s	v6, v8, v9
	and.16b	v5, v5, v6
	and.16b	v5, v5, v9
	fmul.4s	v6, v5, v25
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v17, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v20
	fmul.4s	v7, v4, v25
	bif.16b	v17, v7, v18
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	fmul.4s	v18, v6, v26
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v26
	fsub.4s	v4, v4, v19
	str	q24, [sp, #2416]                ; 16-byte Spill
	fmul.4s	v18, v18, v24
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v24
	fsub.4s	v5, v5, v6
	mov.16b	v27, v15
	fmul.4s	v6, v5, v15
	ldr	q15, [sp, #1872]                ; 16-byte Reload
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	ldr	q19, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v6, v6, v19
	fmul.4s	v6, v5, v6
	mov.16b	v24, v22
	fadd.4s	v6, v6, v22
	fmul.4s	v6, v5, v6
	ldr	q22, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v6, v6, v22
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v3
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v19
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v3
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fadd.4s	v4, v4, v23
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v23
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v23
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v23
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v23
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v23
	fmul.4s	v4, v4, v6
	str	q20, [sp, #1280]                ; 16-byte Spill
	fcmgt.4s	v6, v28, v20
	bic.16b	v4, v4, v6
	str	q9, [sp, #1312]                 ; 16-byte Spill
	fcmgt.4s	v6, v28, v9
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v9, v8
	bit.16b	v5, v16, v6
	str	q5, [sp, #1328]                 ; 16-byte Spill
	fcmgt.4s	v5, v20, v8
	bit.16b	v4, v16, v5
	str	q4, [sp, #1296]                 ; 16-byte Spill
	ldr	q20, [sp, #2368]                ; 16-byte Reload
	ldr	q4, [sp, #1216]                 ; 16-byte Reload
	fsub.4s	v4, v4, v20
	and.16b	v9, v21, v4
	fcmge.4s	v4, v9, v28
	fcmge.4s	v5, v8, v9
	and.16b	v4, v4, v5
	ldr	q5, [sp, #1232]                 ; 16-byte Reload
	fsub.4s	v5, v5, v1
	mov.16b	v3, v1
	and.16b	v1, v0, v5
	fcmge.4s	v5, v1, v28
	fcmge.4s	v6, v8, v1
	and.16b	v5, v5, v6
	and.16b	v5, v5, v1
	fmul.4s	v6, v5, v25
	mvni.4s	v16, #128, lsl #24
	movi.4s	v17, #75, lsl #24
	mov.16b	v7, v16
	bsl.16b	v7, v17, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v9
	fmul.4s	v7, v4, v25
	bif.16b	v17, v7, v16
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	str	q26, [sp, #2432]                ; 16-byte Spill
	fmul.4s	v18, v6, v26
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v26
	fsub.4s	v4, v4, v19
	ldr	q26, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v18, v18, v26
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v26
	fsub.4s	v5, v5, v6
	mov.16b	v22, v27
	fmul.4s	v6, v5, v27
	mov.16b	v27, v15
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	ldr	q15, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	mov.16b	v19, v24
	str	q24, [sp, #2288]                ; 16-byte Spill
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v5, v6
	ldr	q24, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v5, v6
	movi.4s	v16, #63, lsl #24
	fadd.4s	v6, v6, v16
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v22
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v19
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fadd.4s	v4, v4, v23
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v23
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v23
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v23
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v23
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v23
	fmul.4s	v4, v4, v6
	str	q9, [sp, #1184]                 ; 16-byte Spill
	fcmgt.4s	v6, v28, v9
	bic.16b	v4, v4, v6
	str	q1, [sp, #1216]                 ; 16-byte Spill
	fcmgt.4s	v6, v28, v1
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v1, v8
	ldr	q7, [sp, #2400]                 ; 16-byte Reload
	mov.16b	v1, v6
	bsl.16b	v1, v7, v5
	str	q1, [sp, #1232]                 ; 16-byte Spill
	fcmgt.4s	v5, v9, v8
	mov.16b	v1, v5
	bsl.16b	v1, v7, v4
	str	q1, [sp, #1200]                 ; 16-byte Spill
	ldr	q1, [sp, #1120]                 ; 16-byte Reload
	fsub.4s	v4, v1, v20
	and.16b	v9, v21, v4
	fcmge.4s	v4, v9, v28
	fcmge.4s	v5, v8, v9
	and.16b	v4, v4, v5
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	fsub.4s	v5, v1, v3
	and.16b	v20, v0, v5
	fcmge.4s	v5, v20, v28
	fcmge.4s	v6, v8, v20
	and.16b	v5, v5, v6
	and.16b	v5, v5, v20
	str	q25, [sp, #2384]                ; 16-byte Spill
	fmul.4s	v6, v5, v25
	mvni.4s	v1, #128, lsl #24
	movi.4s	v17, #75, lsl #24
	mov.16b	v7, v1
	bsl.16b	v7, v17, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v9
	fmul.4s	v7, v4, v25
	bif.16b	v17, v7, v1
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	ldr	q23, [sp, #2432]                ; 16-byte Reload
	fmul.4s	v18, v6, v23
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v23
	fsub.4s	v4, v4, v19
	fmul.4s	v18, v18, v26
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v26
	fsub.4s	v5, v5, v6
	mov.16b	v25, v22
	fmul.4s	v6, v5, v22
	mov.16b	v26, v27
	fadd.4s	v6, v6, v27
	fmul.4s	v6, v5, v6
	mov.16b	v16, v15
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	ldr	q22, [sp, #2288]                ; 16-byte Reload
	fadd.4s	v6, v6, v22
	fmul.4s	v6, v5, v6
	ldr	q24, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v5, v6
	movi.4s	v3, #63, lsl #24
	fadd.4s	v6, v6, v3
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v25
	mov.16b	v27, v25
	fadd.4s	v18, v18, v26
	mov.16b	v15, v26
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v3
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fmov.4s	v1, #1.00000000
	fadd.4s	v4, v4, v1
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v1
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v1
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v1
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v1
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v1
	fmov.4s	v3, #1.00000000
	fmul.4s	v4, v4, v6
	str	q9, [sp, #1088]                 ; 16-byte Spill
	fcmgt.4s	v6, v28, v9
	bic.16b	v4, v4, v6
	str	q20, [sp, #1120]                ; 16-byte Spill
	fcmgt.4s	v6, v28, v20
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v20, v8
	ldr	q7, [sp, #2400]                 ; 16-byte Reload
	mov.16b	v1, v6
	bsl.16b	v1, v7, v5
	str	q1, [sp, #1136]                 ; 16-byte Spill
	fcmgt.4s	v5, v9, v8
	mov.16b	v1, v5
	bsl.16b	v1, v7, v4
	str	q1, [sp, #1104]                 ; 16-byte Spill
	ldr	q20, [sp, #2352]                ; 16-byte Reload
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	fsub.4s	v4, v1, v20
	and.16b	v9, v0, v4
	fcmge.4s	v4, v9, v28
	fcmge.4s	v5, v8, v9
	and.16b	v4, v4, v5
	ldr	q26, [sp, #2368]                ; 16-byte Reload
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	fsub.4s	v5, v1, v26
	and.16b	v25, v21, v5
	fcmge.4s	v5, v25, v28
	fcmge.4s	v6, v8, v25
	and.16b	v5, v5, v6
	and.16b	v5, v5, v25
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	fmul.4s	v6, v5, v1
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v17, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v9
	fmul.4s	v7, v4, v1
	bif.16b	v17, v7, v18
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	fmul.4s	v18, v6, v23
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v23
	fsub.4s	v4, v4, v19
	ldr	q1, [sp, #2416]                 ; 16-byte Reload
	fmul.4s	v18, v18, v1
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v1
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v27
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v16
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v22
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v5, v6
	movi.4s	v1, #63, lsl #24
	fadd.4s	v6, v6, v1
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fadd.4s	v4, v4, v3
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v3
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v3
	fmul.4s	v4, v4, v6
	str	q9, [sp, #992]                  ; 16-byte Spill
	fcmgt.4s	v6, v28, v9
	bic.16b	v4, v4, v6
	fcmgt.4s	v6, v28, v25
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v25, v8
	ldr	q7, [sp, #2400]                 ; 16-byte Reload
	mov.16b	v1, v6
	bsl.16b	v1, v7, v5
	str	q1, [sp, #1040]                 ; 16-byte Spill
	fcmgt.4s	v5, v9, v8
	mov.16b	v1, v5
	bsl.16b	v1, v7, v4
	mov.16b	v9, v7
	stp	q1, q25, [sp, #1008]            ; 32-byte Folded Spill
	ldp	q6, q1, [sp, #928]              ; 32-byte Folded Reload
	fsub.4s	v4, v6, v20
	and.16b	v25, v0, v4
	fcmge.4s	v4, v25, v28
	fcmge.4s	v5, v8, v25
	and.16b	v4, v4, v5
	fsub.4s	v5, v1, v26
	and.16b	v26, v21, v5
	fcmge.4s	v5, v26, v28
	fcmge.4s	v6, v8, v26
	and.16b	v5, v5, v6
	and.16b	v5, v5, v26
	ldr	q20, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v6, v5, v20
	movi.4s	v1, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v1, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v25
	fmul.4s	v7, v4, v20
	bsl.16b	v17, v1, v7
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	fmul.4s	v18, v6, v23
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v23
	fsub.4s	v4, v4, v19
	ldr	q1, [sp, #2416]                 ; 16-byte Reload
	fmul.4s	v18, v18, v1
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v1
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v27
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v16
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v22
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v5, v6
	movi.4s	v1, #63, lsl #24
	fadd.4s	v6, v6, v1
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	mov.16b	v23, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fadd.4s	v4, v4, v3
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v3
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v3
	fmul.4s	v4, v4, v6
	fcmgt.4s	v6, v28, v25
	bic.16b	v4, v4, v6
	fcmgt.4s	v6, v28, v26
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v26, v8
	mov.16b	v1, v6
	bsl.16b	v1, v9, v5
	stp	q26, q1, [sp, #928]             ; 32-byte Folded Spill
	fcmgt.4s	v5, v25, v8
	mov.16b	v1, v5
	bsl.16b	v1, v9, v4
	stp	q25, q1, [sp, #896]             ; 32-byte Folded Spill
	ldr	q9, [sp, #2352]                 ; 16-byte Reload
	ldr	q1, [sp, #832]                  ; 16-byte Reload
	fsub.4s	v4, v1, v9
	and.16b	v1, v0, v4
	fcmge.4s	v4, v1, v28
	fcmge.4s	v5, v8, v1
	and.16b	v4, v4, v5
	ldr	q5, [sp, #848]                  ; 16-byte Reload
	ldr	q22, [sp, #2368]                ; 16-byte Reload
	fsub.4s	v5, v5, v22
	and.16b	v25, v21, v5
	fcmge.4s	v5, v25, v28
	fcmge.4s	v6, v8, v25
	and.16b	v5, v5, v6
	and.16b	v5, v5, v25
	fmul.4s	v6, v5, v20
	mvni.4s	v17, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v18, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v1
	fmul.4s	v7, v4, v20
	bsl.16b	v17, v18, v7
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	ldr	q16, [sp, #2432]                ; 16-byte Reload
	fmul.4s	v18, v6, v16
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v16
	fsub.4s	v4, v4, v19
	ldr	q16, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v16
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v27
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	ldr	q20, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v6, v6, v20
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v5, v6
	movi.4s	v19, #63, lsl #24
	fadd.4s	v6, v6, v19
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v23
	mov.16b	v26, v23
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v19
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fadd.4s	v4, v4, v3
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v3
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v3
	fmul.4s	v4, v4, v6
	str	q1, [sp, #800]                  ; 16-byte Spill
	fcmgt.4s	v6, v28, v1
	bic.16b	v4, v4, v6
	fcmgt.4s	v6, v28, v25
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v25, v8
	ldr	q3, [sp, #2400]                 ; 16-byte Reload
	bit.16b	v5, v3, v6
	stp	q25, q5, [sp, #832]             ; 32-byte Folded Spill
	fcmgt.4s	v5, v1, v8
	mov.16b	v1, v5
	bsl.16b	v1, v3, v4
	str	q1, [sp, #816]                  ; 16-byte Spill
	ldr	q1, [sp, #736]                  ; 16-byte Reload
	fsub.4s	v4, v1, v9
	and.16b	v1, v0, v4
	fcmge.4s	v4, v1, v28
	fcmge.4s	v5, v8, v1
	and.16b	v4, v4, v5
	mov.16b	v9, v22
	ldr	q5, [sp, #752]                  ; 16-byte Reload
	fsub.4s	v5, v5, v22
	and.16b	v25, v21, v5
	fcmge.4s	v5, v25, v28
	fcmge.4s	v6, v8, v25
	and.16b	v5, v5, v6
	and.16b	v5, v5, v25
	ldr	q23, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v6, v5, v23
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v17, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v1
	fmul.4s	v7, v4, v23
	bif.16b	v17, v7, v18
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	fmul.4s	v18, v6, v3
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v3
	fsub.4s	v4, v4, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v16
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v27
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v20
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v5, v6
	movi.4s	v3, #63, lsl #24
	fadd.4s	v6, v6, v3
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v26
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v3
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fmov.4s	v3, #1.00000000
	fadd.4s	v4, v4, v3
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v3
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v3
	fmul.4s	v4, v4, v6
	str	q1, [sp, #704]                  ; 16-byte Spill
	fcmgt.4s	v6, v28, v1
	bic.16b	v4, v4, v6
	fcmgt.4s	v6, v28, v25
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v25, v8
	ldr	q22, [sp, #2400]                ; 16-byte Reload
	bit.16b	v5, v22, v6
	stp	q25, q5, [sp, #736]             ; 32-byte Folded Spill
	fcmgt.4s	v5, v1, v8
	mov.16b	v1, v5
	bsl.16b	v1, v22, v4
	str	q1, [sp, #720]                  ; 16-byte Spill
	ldp	q6, q1, [sp, #768]              ; 32-byte Folded Reload
	fsub.4s	v4, v6, v9
	and.16b	v25, v21, v4
	fcmge.4s	v4, v25, v28
	fcmge.4s	v5, v8, v25
	and.16b	v4, v4, v5
	ldr	q26, [sp, #2352]                ; 16-byte Reload
	fsub.4s	v5, v1, v26
	and.16b	v1, v0, v5
	fcmge.4s	v5, v1, v28
	fcmge.4s	v6, v8, v1
	and.16b	v5, v5, v6
	and.16b	v5, v5, v1
	fmul.4s	v6, v5, v23
	mvni.4s	v17, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v18, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v25
	fmul.4s	v7, v4, v23
	bsl.16b	v17, v18, v7
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	ldr	q19, [sp, #2432]                ; 16-byte Reload
	fmul.4s	v18, v6, v19
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v19
	fsub.4s	v4, v4, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v16
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v27
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v20
	fmul.4s	v6, v5, v6
	ldr	q19, [sp, #2288]                ; 16-byte Reload
	fadd.4s	v6, v6, v19
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v5, v6
	movi.4s	v16, #63, lsl #24
	fadd.4s	v6, v6, v16
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v19
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v16
	movi.4s	v23, #63, lsl #24
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fadd.4s	v4, v4, v3
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v3
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v3
	fmul.4s	v4, v4, v6
	fcmgt.4s	v6, v28, v25
	bic.16b	v4, v4, v6
	str	q1, [sp, #768]                  ; 16-byte Spill
	fcmgt.4s	v6, v28, v1
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v1, v8
	mov.16b	v1, v6
	bsl.16b	v1, v22, v5
	str	q1, [sp, #784]                  ; 16-byte Spill
	fcmgt.4s	v5, v25, v8
	mov.16b	v1, v5
	bsl.16b	v1, v22, v4
	stp	q25, q1, [sp, #672]             ; 32-byte Folded Spill
	ldp	q6, q1, [sp, #864]              ; 32-byte Folded Reload
	fsub.4s	v4, v6, v9
	and.16b	v22, v21, v4
	fcmge.4s	v4, v22, v28
	fcmge.4s	v5, v8, v22
	and.16b	v4, v4, v5
	mov.16b	v25, v26
	fsub.4s	v5, v1, v26
	and.16b	v1, v0, v5
	fcmge.4s	v5, v1, v28
	fcmge.4s	v6, v8, v1
	and.16b	v5, v5, v6
	and.16b	v5, v5, v1
	ldr	q16, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v6, v5, v16
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v17, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v22
	fmul.4s	v7, v4, v16
	bif.16b	v17, v7, v18
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	ldr	q16, [sp, #2432]                ; 16-byte Reload
	fmul.4s	v18, v6, v16
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v16
	fsub.4s	v4, v4, v19
	ldr	q16, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v16
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v27
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	mov.16b	v26, v20
	fadd.4s	v6, v6, v20
	fmul.4s	v6, v5, v6
	ldr	q20, [sp, #2288]                ; 16-byte Reload
	fadd.4s	v6, v6, v20
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v23
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v26
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v23
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fadd.4s	v4, v4, v3
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v3
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v3
	fmul.4s	v4, v4, v6
	fcmgt.4s	v6, v28, v22
	bic.16b	v4, v4, v6
	str	q1, [sp, #864]                  ; 16-byte Spill
	fcmgt.4s	v6, v28, v1
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v1, v8
	ldr	q7, [sp, #2400]                 ; 16-byte Reload
	mov.16b	v1, v6
	bsl.16b	v1, v7, v5
	str	q1, [sp, #880]                  ; 16-byte Spill
	fcmgt.4s	v5, v22, v8
	mov.16b	v1, v5
	bsl.16b	v1, v7, v4
	stp	q22, q1, [sp, #640]             ; 32-byte Folded Spill
	ldp	q6, q1, [sp, #960]              ; 32-byte Folded Reload
	fsub.4s	v4, v6, v9
	and.16b	v16, v21, v4
	fcmge.4s	v4, v16, v28
	fcmge.4s	v5, v8, v16
	and.16b	v4, v4, v5
	fsub.4s	v5, v1, v25
	and.16b	v1, v0, v5
	fcmge.4s	v5, v1, v28
	fcmge.4s	v6, v8, v1
	and.16b	v5, v5, v6
	and.16b	v5, v5, v1
	ldr	q19, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v6, v5, v19
	mvni.4s	v17, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v18, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v16
	fmul.4s	v7, v4, v19
	bsl.16b	v17, v18, v7
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	ldr	q19, [sp, #2432]                ; 16-byte Reload
	fmul.4s	v18, v6, v19
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v19
	fsub.4s	v4, v4, v19
	ldr	q22, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v18, v18, v22
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v22
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v27
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v20
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v5, v6
	movi.4s	v19, #63, lsl #24
	fadd.4s	v6, v6, v19
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v26
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v19
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fadd.4s	v4, v4, v3
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v3
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v3
	fmul.4s	v4, v4, v6
	fcmgt.4s	v6, v28, v16
	bic.16b	v4, v4, v6
	str	q1, [sp, #960]                  ; 16-byte Spill
	fcmgt.4s	v6, v28, v1
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v1, v8
	ldr	q3, [sp, #2400]                 ; 16-byte Reload
	mov.16b	v1, v6
	bsl.16b	v1, v3, v5
	str	q1, [sp, #976]                  ; 16-byte Spill
	fcmgt.4s	v5, v16, v8
	mov.16b	v1, v5
	bsl.16b	v1, v3, v4
	stp	q16, q1, [sp, #608]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1056]                 ; 16-byte Reload
	fsub.4s	v4, v1, v9
	and.16b	v16, v21, v4
	fcmge.4s	v4, v16, v28
	fcmge.4s	v5, v8, v16
	and.16b	v4, v4, v5
	ldr	q1, [sp, #1072]                 ; 16-byte Reload
	fsub.4s	v5, v1, v25
	and.16b	v1, v0, v5
	fcmge.4s	v5, v1, v28
	fcmge.4s	v6, v8, v1
	and.16b	v5, v5, v6
	and.16b	v5, v5, v1
	ldr	q3, [sp, #2384]                 ; 16-byte Reload
	fmul.4s	v6, v5, v3
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	mov.16b	v7, v19
	bsl.16b	v7, v18, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v16
	fmul.4s	v7, v4, v3
	mov.16b	v17, v19
	bsl.16b	v17, v18, v7
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	ldr	q23, [sp, #2432]                ; 16-byte Reload
	fmul.4s	v18, v6, v23
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v23
	fsub.4s	v4, v4, v19
	fmul.4s	v18, v18, v22
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v22
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v27
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v5, v6
	mov.16b	v22, v20
	fadd.4s	v6, v6, v20
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v5, v6
	movi.4s	v3, #63, lsl #24
	fadd.4s	v6, v6, v3
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v26
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v3
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fmov.4s	v3, #1.00000000
	fadd.4s	v4, v4, v3
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v3
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v3
	fmul.4s	v4, v4, v6
	fcmgt.4s	v6, v28, v16
	bic.16b	v4, v4, v6
	str	q1, [sp, #1056]                 ; 16-byte Spill
	fcmgt.4s	v6, v28, v1
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v1, v8
	ldr	q20, [sp, #2400]                ; 16-byte Reload
	mov.16b	v1, v6
	bsl.16b	v1, v20, v5
	str	q1, [sp, #1072]                 ; 16-byte Spill
	fcmgt.4s	v5, v16, v8
	mov.16b	v1, v5
	bsl.16b	v1, v20, v4
	stp	q16, q1, [sp, #576]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1152]                 ; 16-byte Reload
	fsub.4s	v4, v1, v25
	and.16b	v16, v0, v4
	fcmge.4s	v4, v16, v28
	fcmge.4s	v5, v8, v16
	and.16b	v4, v4, v5
	ldr	q1, [sp, #1168]                 ; 16-byte Reload
	ldr	q9, [sp, #2368]                 ; 16-byte Reload
	fsub.4s	v5, v1, v9
	and.16b	v1, v21, v5
	fcmge.4s	v5, v1, v28
	fcmge.4s	v6, v8, v1
	and.16b	v5, v5, v6
	and.16b	v5, v5, v1
	ldr	q17, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v6, v5, v17
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v16
	fmul.4s	v7, v4, v17
	mov.16b	v17, v18
	bsl.16b	v17, v19, v7
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	fmul.4s	v18, v6, v23
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v23
	fsub.4s	v4, v4, v19
	ldr	q19, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v18, v18, v19
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v19
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v27
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v5, v6
	mov.16b	v23, v22
	fadd.4s	v6, v6, v22
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v5, v6
	movi.4s	v19, #63, lsl #24
	fadd.4s	v6, v6, v19
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v26
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v24
	mov.16b	v22, v24
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v19
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fadd.4s	v4, v4, v3
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v3
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v3
	fmul.4s	v4, v4, v6
	fcmgt.4s	v6, v28, v16
	bic.16b	v4, v4, v6
	str	q1, [sp, #1152]                 ; 16-byte Spill
	fcmgt.4s	v6, v28, v1
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v1, v8
	bit.16b	v5, v20, v6
	str	q5, [sp, #1168]                 ; 16-byte Spill
	fcmgt.4s	v5, v16, v8
	bit.16b	v4, v20, v5
	stp	q16, q4, [sp, #544]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1248]                 ; 16-byte Reload
	fsub.4s	v4, v1, v9
	and.16b	v20, v21, v4
	fcmge.4s	v4, v20, v28
	fcmge.4s	v5, v8, v20
	and.16b	v4, v4, v5
	ldr	q1, [sp, #1264]                 ; 16-byte Reload
	fsub.4s	v5, v1, v25
	mov.16b	v24, v25
	and.16b	v9, v0, v5
	fcmge.4s	v5, v9, v28
	fcmge.4s	v6, v8, v9
	and.16b	v5, v5, v6
	and.16b	v5, v5, v9
	ldr	q25, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v6, v5, v25
	movi.4s	v1, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v7, v16
	bsl.16b	v7, v1, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v20
	fmul.4s	v7, v4, v25
	mov.16b	v17, v16
	bsl.16b	v17, v1, v7
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	fmul.4s	v18, v6, v1
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v1
	fsub.4s	v4, v4, v19
	ldr	q1, [sp, #2416]                 ; 16-byte Reload
	fmul.4s	v18, v18, v1
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v1
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v27
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v22
	fmul.4s	v6, v5, v6
	movi.4s	v16, #63, lsl #24
	fadd.4s	v6, v6, v16
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v26
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fadd.4s	v4, v4, v3
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v3
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v3
	fmul.4s	v4, v4, v6
	fcmgt.4s	v6, v28, v20
	bic.16b	v4, v4, v6
	str	q9, [sp, #1248]                 ; 16-byte Spill
	fcmgt.4s	v6, v28, v9
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v9, v8
	ldr	q9, [sp, #2400]                 ; 16-byte Reload
	mov.16b	v1, v6
	bsl.16b	v1, v9, v5
	str	q1, [sp, #1264]                 ; 16-byte Spill
	fcmgt.4s	v5, v20, v8
	mov.16b	v1, v5
	bsl.16b	v1, v9, v4
	stp	q20, q1, [sp, #512]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1344]                 ; 16-byte Reload
	ldr	q16, [sp, #2368]                ; 16-byte Reload
	fsub.4s	v4, v1, v16
	and.16b	v20, v21, v4
	fcmge.4s	v4, v20, v28
	fcmge.4s	v5, v8, v20
	and.16b	v4, v4, v5
	ldr	q1, [sp, #1360]                 ; 16-byte Reload
	fsub.4s	v5, v1, v24
	and.16b	v22, v0, v5
	fcmge.4s	v5, v22, v28
	fcmge.4s	v6, v8, v22
	and.16b	v5, v5, v6
	and.16b	v5, v5, v22
	fmul.4s	v6, v5, v25
	mvni.4s	v1, #128, lsl #24
	movi.4s	v17, #75, lsl #24
	mov.16b	v7, v1
	bsl.16b	v7, v17, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v20
	fmul.4s	v7, v4, v25
	bif.16b	v17, v7, v1
	fadd.4s	v7, v7, v17
	fsub.4s	v17, v7, v17
	fcvtzs.4s	v7, v6
	scvtf.4s	v6, v7
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	fmul.4s	v18, v6, v1
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v1
	fsub.4s	v4, v4, v19
	ldr	q1, [sp, #2416]                 ; 16-byte Reload
	fmul.4s	v18, v18, v1
	fsub.4s	v4, v4, v18
	fmul.4s	v6, v6, v1
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v5, v27
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v5, v6
	ldr	q3, [sp, #2336]                 ; 16-byte Reload
	fadd.4s	v6, v6, v3
	fmul.4s	v6, v5, v6
	movi.4s	v1, #63, lsl #24
	fadd.4s	v6, v6, v1
	fmul.4s	v18, v5, v5
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v26
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v6
	fmov.4s	v1, #1.00000000
	fadd.4s	v4, v4, v1
	sshr.4s	v6, v17, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v1
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v1
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v1
	fmul.4s	v5, v5, v19
	sub.4s	v6, v17, v6
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v1
	fmul.4s	v5, v5, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v1
	fmov.4s	v23, #1.00000000
	fmul.4s	v4, v4, v6
	mov.16b	v1, v28
	fcmgt.4s	v6, v28, v20
	bic.16b	v4, v4, v6
	str	q22, [sp, #1344]                ; 16-byte Spill
	fcmgt.4s	v6, v28, v22
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v22, v8
	mov.16b	v7, v9
	mov.16b	v3, v6
	bsl.16b	v3, v9, v5
	str	q3, [sp, #1360]                 ; 16-byte Spill
	fcmgt.4s	v5, v20, v8
	mov.16b	v9, v20
	bit.16b	v4, v7, v5
	str	q4, [sp, #496]                  ; 16-byte Spill
	mov.16b	v28, v7
	ldr	q4, [sp, #2256]                 ; 16-byte Reload
	fsub.4s	v4, v4, v16
	and.16b	v25, v21, v4
	fcmge.4s	v4, v25, v1
	fcmge.4s	v5, v8, v25
	and.16b	v4, v4, v5
	ldr	q5, [sp, #2272]                 ; 16-byte Reload
	ldr	q6, [sp, #2352]                 ; 16-byte Reload
	fsub.4s	v5, v5, v6
	and.16b	v24, v0, v5
	fcmge.4s	v5, v24, v1
	fcmge.4s	v6, v8, v24
	and.16b	v5, v5, v6
	and.16b	v5, v5, v24
	ldr	q18, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v6, v5, v18
	movi.4s	v17, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	mov.16b	v7, v19
	bsl.16b	v7, v17, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v25
	fmul.4s	v7, v4, v18
	bif.16b	v17, v7, v19
	fadd.4s	v7, v7, v17
	fsub.4s	v7, v7, v17
	fcvtzs.4s	v6, v6
	scvtf.4s	v17, v6
	ldr	q19, [sp, #2432]                ; 16-byte Reload
	fmul.4s	v18, v17, v19
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v7, v7
	scvtf.4s	v18, v7
	fmul.4s	v19, v18, v19
	fsub.4s	v4, v4, v19
	ldr	q16, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v17, v17, v16
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fsub.4s	v5, v5, v17
	fmul.4s	v17, v5, v27
	fmul.4s	v18, v4, v27
	fadd.4s	v18, v18, v15
	fadd.4s	v17, v17, v15
	fmul.4s	v17, v5, v17
	fmul.4s	v18, v4, v18
	ldr	q15, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v18, v18, v15
	fadd.4s	v17, v17, v15
	fmul.4s	v17, v5, v17
	fmul.4s	v18, v4, v18
	ldr	q16, [sp, #2288]                ; 16-byte Reload
	fadd.4s	v18, v18, v16
	fadd.4s	v17, v17, v16
	fmul.4s	v17, v5, v17
	fmul.4s	v18, v4, v18
	ldr	q16, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v16
	fadd.4s	v17, v17, v16
	fmul.4s	v17, v5, v17
	movi.4s	v16, #63, lsl #24
	fadd.4s	v17, v17, v16
	fmul.4s	v19, v5, v5
	fmul.4s	v17, v19, v17
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v5, v5, v17
	fadd.4s	v4, v4, v23
	sshr.4s	v17, v7, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v23
	fmul.4s	v4, v4, v18
	fadd.4s	v5, v5, v23
	sshr.4s	v18, v6, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v23
	fmul.4s	v5, v5, v19
	sub.4s	v7, v7, v17
	sub.4s	v6, v6, v18
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v23
	fmul.4s	v5, v5, v6
	shl.4s	v6, v7, #23
	add.4s	v6, v6, v23
	fmul.4s	v4, v4, v6
	fcmgt.4s	v6, v1, v25
	bic.16b	v4, v4, v6
	fcmgt.4s	v6, v1, v24
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v24, v8
	mov.16b	v23, v6
	bsl.16b	v23, v28, v5
	fcmgt.4s	v5, v25, v8
	mov.16b	v1, v5
	bsl.16b	v1, v28, v4
	str	q1, [sp, #480]                  ; 16-byte Spill
	sshll2.2d	v4, v21, #0
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	bit.16b	v3, v1, v4
	str	q3, [sp, #1824]                 ; 16-byte Spill
	sshll.2d	v4, v0, #0
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	ldr	q1, [sp, #1520]                 ; 16-byte Reload
	bit.16b	v3, v1, v4
	str	q3, [sp, #1808]                 ; 16-byte Spill
	ldr	q1, [sp, #1424]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q3, [sp, #192]                  ; 16-byte Reload
	ldr	q1, [sp, #1440]                 ; 16-byte Reload
	mov.16b	v16, v4
	bsl.16b	v16, v1, v3
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1456]                 ; 16-byte Reload
	mov.16b	v6, v4
	bsl.16b	v6, v1, v3
	ldr	q1, [sp, #1376]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1392]                 ; 16-byte Reload
	mov.16b	v17, v4
	bsl.16b	v17, v1, v3
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1408]                 ; 16-byte Reload
	mov.16b	v18, v4
	bsl.16b	v18, v1, v3
	ldr	q1, [sp, #1280]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1296]                 ; 16-byte Reload
	mov.16b	v19, v4
	bsl.16b	v19, v1, v3
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1328]                 ; 16-byte Reload
	mov.16b	v20, v4
	bsl.16b	v20, v1, v3
	ldr	q1, [sp, #1184]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1200]                 ; 16-byte Reload
	mov.16b	v28, v4
	bsl.16b	v28, v1, v3
	ldr	q1, [sp, #1216]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1232]                 ; 16-byte Reload
	mov.16b	v8, v4
	bsl.16b	v8, v1, v3
	ldr	q1, [sp, #1088]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1104]                 ; 16-byte Reload
	mov.16b	v15, v4
	bsl.16b	v15, v1, v3
	ldr	q1, [sp, #1120]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	mov.16b	v7, v4
	bsl.16b	v7, v1, v3
	ldp	q5, q1, [sp, #992]              ; 32-byte Folded Reload
	fcmeq.4s	v4, v5, v5
	mov.16b	v22, v4
	bsl.16b	v22, v1, v3
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	bsl.16b	v4, v1, v3
	ldr	q1, [sp, #896]                  ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #912]                  ; 16-byte Reload
	mov.16b	v27, v5
	bsl.16b	v27, v1, v3
	ldr	q1, [sp, #928]                  ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #944]                  ; 16-byte Reload
	mov.16b	v26, v5
	bsl.16b	v26, v1, v3
	ldr	q1, [sp, #800]                  ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #816]                  ; 16-byte Reload
	bif.16b	v1, v3, v5
	str	q1, [sp, #1440]                 ; 16-byte Spill
	ldr	q1, [sp, #832]                  ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #848]                  ; 16-byte Reload
	bif.16b	v1, v3, v5
	str	q1, [sp, #1424]                 ; 16-byte Spill
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #720]                  ; 16-byte Reload
	bif.16b	v1, v3, v5
	str	q1, [sp, #1408]                 ; 16-byte Spill
	ldr	q1, [sp, #736]                  ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #752]                  ; 16-byte Reload
	bif.16b	v1, v3, v5
	str	q1, [sp, #1392]                 ; 16-byte Spill
	ldr	q1, [sp, #672]                  ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #688]                  ; 16-byte Reload
	bif.16b	v1, v3, v5
	str	q1, [sp, #1376]                 ; 16-byte Spill
	mov	w5, #33792                      ; =0x8400
	movk	w5, #1, lsl #16
	add	x5, x10, x5
	ldr	q5, [x5, #16]
	str	q6, [sp, #2416]                 ; 16-byte Spill
	bit.16b	v5, v6, v0
	ldr	q6, [x5]
	str	q16, [sp, #2432]                ; 16-byte Spill
	bit.16b	v6, v16, v21
	stp	q6, q5, [x5]
	ldp	q6, q1, [sp, #768]              ; 32-byte Folded Reload
	fcmeq.4s	v5, v6, v6
	bif.16b	v1, v3, v5
	str	q1, [sp, #1328]                 ; 16-byte Spill
	ldr	q1, [sp, #640]                  ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #656]                  ; 16-byte Reload
	bif.16b	v1, v3, v5
	str	q1, [sp, #1312]                 ; 16-byte Spill
	ldr	x5, [sp, #256]                  ; 8-byte Reload
	ldp	q6, q5, [x5]
	str	q18, [sp, #2384]                ; 16-byte Spill
	bit.16b	v5, v18, v0
	str	q17, [sp, #2400]                ; 16-byte Spill
	bit.16b	v6, v17, v21
	stp	q6, q5, [x5]
	ldp	q6, q1, [sp, #864]              ; 32-byte Folded Reload
	fcmeq.4s	v5, v6, v6
	bif.16b	v1, v3, v5
	str	q1, [sp, #1296]                 ; 16-byte Spill
	ldr	q1, [sp, #608]                  ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #624]                  ; 16-byte Reload
	bif.16b	v1, v3, v5
	str	q1, [sp, #1280]                 ; 16-byte Spill
	ldr	q1, [sp, #960]                  ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #976]                  ; 16-byte Reload
	bif.16b	v1, v3, v5
	str	q1, [sp, #1232]                 ; 16-byte Spill
	ldp	x5, x6, [sp, #240]              ; 16-byte Folded Reload
	ldp	q6, q5, [x6]
	str	q20, [sp, #2320]                ; 16-byte Spill
	bit.16b	v5, v20, v0
	str	q19, [sp, #2336]                ; 16-byte Spill
	bit.16b	v6, v19, v21
	stp	q6, q5, [x6]
	ldp	q6, q5, [x5]
	str	q8, [sp, #1888]                 ; 16-byte Spill
	bit.16b	v5, v8, v0
	str	q28, [sp, #2288]                ; 16-byte Spill
	bit.16b	v6, v28, v21
	stp	q6, q5, [x5]
	ldp	x5, x7, [sp, #224]              ; 16-byte Folded Reload
	ldp	q6, q5, [x7]
	str	q7, [sp, #1520]                 ; 16-byte Spill
	bit.16b	v5, v7, v0
	str	q15, [sp, #1872]                ; 16-byte Spill
	bit.16b	v6, v15, v21
	stp	q6, q5, [x7]
	ldr	d1, [sp, #1488]                 ; 8-byte Reload
	zip1.8b	v5, v1, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v17, v5, #0
	and.16b	v6, v17, v4
	zip2.8b	v4, v1, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v18, v4, #0
	and.16b	v1, v18, v22
	ldp	q5, q4, [x5]
	str	q1, [sp, #1488]                 ; 16-byte Spill
	bit.16b	v4, v1, v0
	str	q6, [sp, #1504]                 ; 16-byte Spill
	bit.16b	v5, v6, v21
	stp	q5, q4, [x5]
	ldp	q5, q1, [sp, #576]              ; 32-byte Folded Reload
	fcmeq.4s	v4, v5, v5
	bsl.16b	v4, v1, v3
	and.16b	v1, v17, v26
	and.16b	v6, v18, v27
	ldr	x5, [sp, #216]                  ; 8-byte Reload
	ldr	q5, [x5, #16]
	str	q6, [sp, #1456]                 ; 16-byte Spill
	bit.16b	v5, v6, v0
	ldr	q6, [x5]
	str	q1, [sp, #1472]                 ; 16-byte Spill
	bit.16b	v6, v1, v21
	stp	q6, q5, [x5]
	ldr	q1, [sp, #1056]                 ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #1072]                 ; 16-byte Reload
	bsl.16b	v5, v1, v3
	ldr	q1, [sp, #1424]                 ; 16-byte Reload
	and.16b	v1, v17, v1
	ldr	q6, [sp, #1440]                 ; 16-byte Reload
	and.16b	v7, v18, v6
	ldr	x5, [sp, #208]                  ; 8-byte Reload
	ldr	q6, [x5, #16]
	str	q7, [sp, #1424]                 ; 16-byte Spill
	bit.16b	v6, v7, v0
	ldr	q7, [x5]
	str	q1, [sp, #1440]                 ; 16-byte Spill
	bit.16b	v7, v1, v21
	stp	q7, q6, [x5]
	ldp	q7, q1, [sp, #544]              ; 32-byte Folded Reload
	fcmeq.4s	v6, v7, v7
	bsl.16b	v6, v1, v3
	ldr	q1, [sp, #1392]                 ; 16-byte Reload
	and.16b	v1, v17, v1
	ldr	q7, [sp, #1408]                 ; 16-byte Reload
	and.16b	v16, v18, v7
	ldp	q19, q7, [x25]
	str	q16, [sp, #1392]                ; 16-byte Spill
	bit.16b	v7, v16, v0
	str	q1, [sp, #1408]                 ; 16-byte Spill
	bit.16b	v19, v1, v21
	stp	q19, q7, [x25]
	ldr	q1, [sp, #1152]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1168]                 ; 16-byte Reload
	bsl.16b	v7, v1, v3
	ldr	q1, [sp, #1328]                 ; 16-byte Reload
	and.16b	v1, v18, v1
	ldr	q16, [sp, #1376]                ; 16-byte Reload
	and.16b	v16, v17, v16
	ldp	q19, q20, [x9]
	str	q16, [sp, #1328]                ; 16-byte Spill
	bit.16b	v19, v16, v21
	str	q1, [sp, #1376]                 ; 16-byte Spill
	bit.16b	v20, v1, v0
	stp	q19, q20, [x9]
	ldr	q1, [sp, #512]                  ; 16-byte Reload
	fcmeq.4s	v19, v1, v1
	ldr	q1, [sp, #528]                  ; 16-byte Reload
	bsl.16b	v19, v1, v3
	ldr	q1, [sp, #1296]                 ; 16-byte Reload
	and.16b	v16, v18, v1
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	and.16b	v1, v17, v1
	ldp	q20, q26, [x22]
	str	q1, [sp, #1312]                 ; 16-byte Spill
	bit.16b	v20, v1, v21
	str	q16, [sp, #1296]                ; 16-byte Spill
	bit.16b	v26, v16, v0
	stp	q20, q26, [x22]
	ldr	q1, [sp, #1248]                 ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #1264]                 ; 16-byte Reload
	bsl.16b	v20, v1, v3
	ldr	q1, [sp, #1232]                 ; 16-byte Reload
	and.16b	v1, v18, v1
	ldr	q16, [sp, #1280]                ; 16-byte Reload
	and.16b	v16, v17, v16
	ldp	q26, q27, [x24]
	str	q16, [sp, #1264]                ; 16-byte Spill
	bit.16b	v26, v16, v21
	str	q1, [sp, #1280]                 ; 16-byte Spill
	bit.16b	v27, v1, v0
	stp	q26, q27, [x24]
	fcmeq.4s	v26, v9, v9
	ldr	q1, [sp, #496]                  ; 16-byte Reload
	bsl.16b	v26, v1, v3
	and.16b	v16, v18, v5
	and.16b	v1, v17, v4
	ldp	q4, q5, [x28]
	str	q1, [sp, #1248]                 ; 16-byte Spill
	bit.16b	v4, v1, v21
	str	q16, [sp, #1232]                ; 16-byte Spill
	bit.16b	v5, v16, v0
	stp	q4, q5, [x28]
	ldr	q1, [sp, #1344]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1360]                 ; 16-byte Reload
	bsl.16b	v4, v1, v3
	and.16b	v1, v17, v7
	and.16b	v6, v18, v6
	ldr	q5, [x20, #16]
	str	q6, [sp, #1344]                 ; 16-byte Spill
	bit.16b	v5, v6, v0
	ldr	q6, [x20]
	str	q1, [sp, #1360]                 ; 16-byte Spill
	bit.16b	v6, v1, v21
	stp	q6, q5, [x20]
	and.16b	v6, v18, v20
	and.16b	v1, v18, v4
	and.16b	v5, v17, v19
	and.16b	v7, v17, v26
	ldr	q4, [x2]
	str	q5, [sp, #1184]                 ; 16-byte Spill
	bit.16b	v4, v5, v21
	ldr	q5, [x2, #16]
	str	q6, [sp, #1200]                 ; 16-byte Spill
	bit.16b	v5, v6, v0
	stp	q4, q5, [x2]
	ldp	q4, q5, [x3]
	str	q7, [sp, #1168]                 ; 16-byte Spill
	bit.16b	v4, v7, v21
	str	q1, [sp, #1216]                 ; 16-byte Spill
	bit.16b	v5, v1, v0
	stp	q4, q5, [x3]
	fcmeq.4s	v4, v25, v25
	ldr	q1, [sp, #480]                  ; 16-byte Reload
	mov.16b	v7, v4
	bsl.16b	v7, v1, v3
	fcmeq.4s	v4, v24, v24
	mov.16b	v24, v4
	bsl.16b	v24, v23, v3
	sshll.2d	v4, v21, #0
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	ldr	q9, [sp, #2464]                 ; 16-byte Reload
	bit.16b	v9, v3, v4
	mov	w5, #49760                      ; =0xc260
	add	x7, x10, x5
	ldr	q16, [sp, #1920]                ; 16-byte Reload
	ldr	q28, [sp, #1552]                ; 16-byte Reload
	ldr	q1, [sp, #1536]                 ; 16-byte Reload
	str	q9, [sp, #2464]                 ; 16-byte Spill
LBB1_83:                                ; %direct.true600.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_84 Depth 4
	mov	x6, #0                          ; =0x0
	lsl	x5, x4, #7
	dup.2d	v25, x5
	ldr	q3, [sp, #2576]                 ; 16-byte Reload
	orr.16b	v4, v25, v3
	fmov	x5, d4
	add	x5, x8, x5
	ldp	q5, q4, [x5]
	fmul.4s	v5, v7, v5
	fmul.4s	v4, v24, v4
	mov	w5, #32                         ; =0x20
	bfi	x5, x4, #7, #57
	dup.2d	v26, x5
	orr.16b	v6, v26, v3
	fmov	x5, d6
	add	x5, x8, x5
	ldp	q17, q6, [x5]
	fmul.4s	v18, v7, v17
	fmul.4s	v6, v24, v6
	mov	w5, #64                         ; =0x40
	bfi	x5, x4, #7, #57
	dup.2d	v27, x5
	orr.16b	v17, v27, v3
	fmov	x5, d17
	add	x5, x8, x5
	ldp	q19, q17, [x5]
	fmul.4s	v19, v7, v19
	fmul.4s	v20, v24, v17
	mov	w5, #96                         ; =0x60
	bfi	x5, x4, #7, #57
	dup.2d	v17, x5
	orr.16b	v8, v17, v3
	fmov	x5, d8
	add	x5, x8, x5
	ldp	q15, q8, [x5]
	fmul.4s	v15, v7, v15
	fmul.4s	v8, v24, v8
	bit.16b	v14, v4, v0
	bit.16b	v13, v5, v21
	bit.16b	v12, v6, v0
	bit.16b	v11, v18, v21
	bit.16b	v10, v20, v0
	bit.16b	v31, v19, v21
	bit.16b	v30, v8, v0
	bit.16b	v29, v15, v21
	mov	x5, x7
LBB1_84:                                ; %direct.true628.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ;       Parent Loop BB1_83 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	add	x21, x15, x6
	ldp	q5, q4, [x21]
	and.16b	v18, v21, v5
	and.16b	v4, v0, v4
	ldp	q6, q5, [x5, #-96]
	and.16b	v6, v21, v6
	and.16b	v5, v0, v5
	fmul.4s	v19, v4, v5
	fmul.4s	v5, v18, v6
	fadd.4s	v5, v13, v5
	fadd.4s	v8, v14, v19
	ldp	q19, q6, [x5, #-64]
	and.16b	v19, v21, v19
	and.16b	v6, v0, v6
	fmul.4s	v6, v4, v6
	fmul.4s	v19, v18, v19
	fadd.4s	v20, v11, v19
	fadd.4s	v19, v12, v6
	ldp	q15, q6, [x5, #-32]
	and.16b	v15, v21, v15
	and.16b	v6, v0, v6
	fmul.4s	v6, v4, v6
	fmul.4s	v15, v18, v15
	fadd.4s	v15, v31, v15
	fadd.4s	v6, v10, v6
	ldp	q3, q9, [x5]
	and.16b	v3, v21, v3
	and.16b	v9, v0, v9
	fmul.4s	v4, v4, v9
	fmul.4s	v3, v18, v3
	fadd.4s	v18, v29, v3
	fadd.4s	v4, v30, v4
	bit.16b	v14, v8, v0
	bit.16b	v13, v5, v21
	bit.16b	v12, v19, v0
	bit.16b	v11, v20, v21
	bit.16b	v10, v6, v0
	bit.16b	v31, v15, v21
	bit.16b	v30, v4, v0
	bit.16b	v29, v18, v21
	add	x6, x6, #32
	add	x5, x5, #3072
	cmp	x6, #512
	b.ne	LBB1_84
; %bb.85:                               ; %direct.false629.i.i
                                        ;   in Loop: Header=BB1_83 Depth=3
	ldr	q9, [sp, #2464]                 ; 16-byte Reload
	orr.16b	v3, v25, v9
	fmov	x5, d3
	add	x5, x16, x5
	ldp	q3, q25, [x5]
	bit.16b	v25, v8, v0
	bit.16b	v3, v5, v21
	stp	q3, q25, [x5]
	orr.16b	v3, v26, v9
	fmov	x5, d3
	add	x5, x16, x5
	ldp	q3, q5, [x5]
	bit.16b	v5, v19, v0
	bit.16b	v3, v20, v21
	stp	q3, q5, [x5]
	orr.16b	v3, v27, v9
	fmov	x5, d3
	add	x5, x16, x5
	ldp	q3, q5, [x5]
	bit.16b	v5, v6, v0
	bit.16b	v3, v15, v21
	stp	q3, q5, [x5]
	orr.16b	v3, v17, v9
	fmov	x5, d3
	add	x5, x16, x5
	ldp	q3, q5, [x5]
	bif.16b	v4, v5, v0
	bit.16b	v3, v18, v21
	stp	q3, q4, [x5]
	add	x4, x4, #1
	add	x7, x7, #128
	cmp	x4, #24
	b.ne	LBB1_83
; %bb.86:                               ; %direct.true695.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x4, #0                          ; =0x0
	ldr	q17, [sp, #2576]                ; 16-byte Reload
LBB1_87:                                ; %direct.true695.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d3, x4
	orr.16b	v4, v3, v9
	fmov	x5, d4
	add	x5, x16, x5
	ldp	q4, q5, [x5]
	orr.16b	v3, v3, v17
	fmov	x5, d3
	add	x5, x11, x5
	ldp	q3, q6, [x5]
	bif.16b	v5, v6, v0
	bit.16b	v3, v4, v21
	stp	q3, q5, [x5]
	add	x4, x4, #32
	cmp	x4, #3072
	b.ne	LBB1_87
; %bb.88:                               ; %direct.true711.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x4, x10
	mov	w5, #96                         ; =0x60
	ldr	q20, [sp, #1584]                ; 16-byte Reload
	ldr	q9, [sp, #432]                  ; 16-byte Reload
	ldr	q8, [sp, #2304]                 ; 16-byte Reload
	ldr	q26, [sp, #1984]                ; 16-byte Reload
	ldr	q27, [sp, #1968]                ; 16-byte Reload
	ldr	q15, [sp, #1952]                ; 16-byte Reload
	ldr	q18, [sp, #2592]                ; 16-byte Reload
	ldr	q19, [sp, #2480]                ; 16-byte Reload
	ldr	q25, [sp, #1936]                ; 16-byte Reload
	ldr	q22, [sp, #1568]                ; 16-byte Reload
	ldr	q23, [sp, #1904]                ; 16-byte Reload
LBB1_89:                                ; %direct.true711.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x4, #5632]
	ldr	q4, [x4, #5648]
	ldr	q5, [x4, #2560]
	ldr	q6, [x4, #2576]
	bif.16b	v4, v6, v0
	bif.16b	v3, v5, v21
	str	q3, [x4, #2560]
	str	q4, [x4, #2576]
	add	x4, x4, #32
	subs	x5, x5, #1
	b.ne	LBB1_89
; %bb.90:                               ; %direct.false712.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	ldr	q3, [sp, #2272]                 ; 16-byte Reload
	ldr	q4, [sp, #2352]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #2272]                 ; 16-byte Spill
	ldr	q3, [sp, #2256]                 ; 16-byte Reload
	ldr	q4, [sp, #2368]                 ; 16-byte Reload
	bit.16b	v3, v4, v21
	str	q3, [sp, #2256]                 ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q5, [sp, #2400]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #2416]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #2384]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #2320]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #2336]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #2288]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1520]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1872]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1504]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1488]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1456]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1472]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1440]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1424]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1392]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1408]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1328]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1376]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1296]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1312]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1264]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1280]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1232]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1248]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1360]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1344]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1200]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1184]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1168]                 ; 16-byte Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1216]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	ldr	q17, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v5, v17, v7
	fmul.4s	v6, v20, v24
	fadd.4s	v4, v6, v4
	fadd.4s	v3, v5, v3
	bit.16b	v17, v3, v21
	str	q17, [sp, #1856]                ; 16-byte Spill
	bit.16b	v20, v4, v0
	add	x1, x1, #1
	cmp	x1, #129
	ldp	q3, q24, [sp, #384]             ; 32-byte Folded Reload
	b.ne	LBB1_34
; %bb.91:                               ; %direct.schedule.50.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	ldp	q1, q3, [sp, #32]               ; 32-byte Folded Reload
	xtn.2s	v1, v1
	movi.2s	v5, #96
	umull.2d	v1, v1, v5
	ldp	q2, q4, [sp, #64]               ; 32-byte Folded Reload
	xtn.2s	v2, v2
	umull.2d	v2, v2, v5
	xtn.2s	v3, v3
	umull.2d	v3, v3, v5
	xtn.2s	v4, v4
	umull.2d	v4, v4, v5
	ldr	w22, [sp, #28]                  ; 4-byte Reload
	ldp	x25, x24, [sp, #8]              ; 16-byte Folded Reload
	ldr	w28, [sp, #108]                 ; 4-byte Reload
	ldr	q18, [sp, #144]                 ; 16-byte Reload
	ldp	w14, w13, [sp, #176]            ; 8-byte Folded Reload
	ldr	x12, [sp, #96]                  ; 8-byte Reload
	ldr	q22, [sp, #1856]                ; 16-byte Reload
	b	LBB1_93
LBB1_92:                                ; %else367
                                        ;   in Loop: Header=BB1_93 Depth=2
	add	x9, x9, #1
	cmp	x9, #96
	b.eq	LBB1_2
LBB1_93:                                ; %direct.true730.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	uzp1.8h	v5, v21, v0
	and.16b	v5, v5, v18
	addv.8h	h5, v5
	fmov	w10, s5
	dup.2d	v5, x9
	add.2d	v6, v5, v1
	add	x11, x8, x9, lsl #5
	ldp	q16, q7, [x11]
	and.16b	v16, v21, v16
	fdiv.4s	v16, v16, v22
	shl.2d	v17, v6, #2
	dup.2d	v6, x12
	add.2d	v17, v6, v17
	tbnz	w10, #0, LBB1_101
; %bb.94:                               ; %else346
                                        ;   in Loop: Header=BB1_93 Depth=2
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB1_102
LBB1_95:                                ; %else349
                                        ;   in Loop: Header=BB1_93 Depth=2
	add.2d	v17, v5, v2
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbnz	w10, #2, LBB1_103
LBB1_96:                                ; %else352
                                        ;   in Loop: Header=BB1_93 Depth=2
	tbnz	w10, #3, LBB1_104
LBB1_97:                                ; %else355
                                        ;   in Loop: Header=BB1_93 Depth=2
	add.2d	v16, v5, v3
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v20
	shl.2d	v16, v16, #2
	add.2d	v16, v6, v16
	tbnz	w10, #4, LBB1_105
LBB1_98:                                ; %else358
                                        ;   in Loop: Header=BB1_93 Depth=2
	tbnz	w10, #5, LBB1_106
LBB1_99:                                ; %else361
                                        ;   in Loop: Header=BB1_93 Depth=2
	add.2d	v5, v5, v4
	shl.2d	v5, v5, #2
	add.2d	v5, v6, v5
	tbnz	w10, #6, LBB1_107
LBB1_100:                               ; %else364
                                        ;   in Loop: Header=BB1_93 Depth=2
	tbz	w10, #7, LBB1_92
	b	LBB1_108
LBB1_101:                               ; %cond.store
                                        ;   in Loop: Header=BB1_93 Depth=2
	fmov	x11, d17
	str	s16, [x11]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB1_95
LBB1_102:                               ; %cond.store347
                                        ;   in Loop: Header=BB1_93 Depth=2
	mov.d	x11, v17[1]
	st1.s	{ v16 }[1], [x11]
	add.2d	v17, v5, v2
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbz	w10, #2, LBB1_96
LBB1_103:                               ; %cond.store350
                                        ;   in Loop: Header=BB1_93 Depth=2
	fmov	x11, d17
	st1.s	{ v16 }[2], [x11]
	tbz	w10, #3, LBB1_97
LBB1_104:                               ; %cond.store353
                                        ;   in Loop: Header=BB1_93 Depth=2
	mov.d	x11, v17[1]
	st1.s	{ v16 }[3], [x11]
	add.2d	v16, v5, v3
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v20
	shl.2d	v16, v16, #2
	add.2d	v16, v6, v16
	tbz	w10, #4, LBB1_98
LBB1_105:                               ; %cond.store356
                                        ;   in Loop: Header=BB1_93 Depth=2
	fmov	x11, d16
	str	s7, [x11]
	tbz	w10, #5, LBB1_99
LBB1_106:                               ; %cond.store359
                                        ;   in Loop: Header=BB1_93 Depth=2
	mov.d	x11, v16[1]
	st1.s	{ v7 }[1], [x11]
	add.2d	v5, v5, v4
	shl.2d	v5, v5, #2
	add.2d	v5, v6, v5
	tbz	w10, #6, LBB1_100
LBB1_107:                               ; %cond.store362
                                        ;   in Loop: Header=BB1_93 Depth=2
	fmov	x11, d5
	st1.s	{ v7 }[2], [x11]
	tbz	w10, #7, LBB1_92
LBB1_108:                               ; %cond.store365
                                        ;   in Loop: Header=BB1_93 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v7 }[3], [x10]
	b	LBB1_92
LBB1_109:
	add	sp, sp, #2688
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB1_110:                               ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
                                        ; -- End function
.subsections_via_symbols

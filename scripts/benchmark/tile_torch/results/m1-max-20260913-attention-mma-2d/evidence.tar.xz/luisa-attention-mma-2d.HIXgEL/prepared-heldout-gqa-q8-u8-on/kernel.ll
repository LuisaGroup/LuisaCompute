; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [37 x i32] [i32 5, i32 4, i32 8, i32 102, i32 15, i32 14, i32 20, i32 19, i32 29, i32 28, i32 27, i32 32, i32 35, i32 38, i32 41, i32 44, i32 47, i32 50, i32 53, i32 56, i32 59, i32 62, i32 65, i32 68, i32 71, i32 74, i32 77, i32 80, i32 83, i32 86, i32 95, i32 94, i32 93, i32 98, i32 101, i32 107, i32 106], align 4

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 12288
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 22528
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 32768
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 57344
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 77824
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 81920
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 16, i64 32, i64 48, i64 64, i64 80, i64 96, i64 112>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 82048
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 83072
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 83584
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 128, i64 256, i64 384, i64 512, i64 640, i64 768, i64 896>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 84608
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %33 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace41 = load ptr, ptr %33, align 8
  %tile_snapshot.private42 = getelementptr inbounds i8, ptr %private.workspace41, i64 88704
  %.splatinsert43 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private42, i64 0
  %.splat44 = shufflevector <8 x ptr> %.splatinsert43, <8 x ptr> poison, <8 x i32> zeroinitializer
  %34 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat44, 0
  %35 = insertvalue { <8 x ptr>, <8 x i64> } %34, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %36 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace45 = load ptr, ptr %36, align 8
  %tile_snapshot.private46 = getelementptr inbounds i8, ptr %private.workspace45, i64 88960
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %37 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %38 = insertvalue { <8 x ptr>, <8 x i64> } %37, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %39 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace49 = load ptr, ptr %39, align 8
  %tile_snapshot.private50 = getelementptr inbounds i8, ptr %private.workspace49, i64 89216
  %.splatinsert51 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private50, i64 0
  %.splat52 = shufflevector <8 x ptr> %.splatinsert51, <8 x ptr> poison, <8 x i32> zeroinitializer
  %40 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat52, 0
  %41 = insertvalue { <8 x ptr>, <8 x i64> } %40, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %42 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace53 = load ptr, ptr %42, align 8
  %tile_snapshot.private54 = getelementptr inbounds i8, ptr %private.workspace53, i64 93312
  %.splatinsert55 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private54, i64 0
  %.splat56 = shufflevector <8 x ptr> %.splatinsert55, <8 x ptr> poison, <8 x i32> zeroinitializer
  %43 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat56, 0
  %44 = insertvalue { <8 x ptr>, <8 x i64> } %43, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %45 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace57 = load ptr, ptr %45, align 8
  %tile_snapshot.private58 = getelementptr inbounds i8, ptr %private.workspace57, i64 103552
  %.splatinsert59 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private58, i64 0
  %.splat60 = shufflevector <8 x ptr> %.splatinsert59, <8 x ptr> poison, <8 x i32> zeroinitializer
  %46 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat60, 0
  %47 = insertvalue { <8 x ptr>, <8 x i64> } %46, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill61 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill61, align 64
  %.spill62 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill62, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill63 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill63, align 64
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %tile_snapshot.spill65 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill65, align 64
  %tile_snapshot.spill66 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill66, align 64
  %.slot67 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot67, align 64
  %.slot68 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot68, align 64
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot72, align 32
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot74, align 32
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %.slot79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot79, align 32
  %.slot80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot80, align 32
  %.slot81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot81, align 32
  %.slot82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot82, align 32
  %.slot83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot83, align 32
  %.slot84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot84, align 32
  %.spill85 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill85, align 64
  %tile_snapshot.spill86 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill86, align 64
  %.slot87 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot87, align 64
  %.spill88 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill88, align 64
  %.slot89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot89, align 32
  %tile_snapshot.spill90 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill90, align 64
  %.slot91 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot91, align 64
  %.spill92 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill92, align 64
  %.slot93 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot93, align 32
  %tile_snapshot.spill94 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill94, align 64
  %.slot95 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot95, align 64
  %.spill96 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill96, align 64
  %.slot97 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot97, align 64
  %.spill98 = alloca i64, align 8
  store i64 0, ptr %.spill98, align 4
  %.spill99 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill99, align 64
  %.spill100 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill100, align 64
  %.spill101 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill101, align 64
  %.spill102 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill102, align 64
  %.spill103 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill103, align 64
  %.spill104 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill104, align 64
  %.spill105 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill105, align 64
  %.spill106 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill106, align 64
  %.slot107 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot107, align 64
  %.slot108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot108, align 32
  %.slot109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot109, align 32
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %.slot111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot111, align 32
  %tile_snapshot.spill112 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill112, align 64
  %tile_snapshot.spill113 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill113, align 64
  %tile_snapshot.spill114 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill114, align 64
  %tile_snapshot.spill115 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill115, align 64
  %.slot116 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot116, align 64
  %tile_snapshot.spill117 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill117, align 64
  %.slot118 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot118, align 64
  %.slot119 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot119, align 64
  %.slot120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot120, align 32
  %.slot121 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot121, align 64
  %.slot122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot122, align 32
  %.slot123 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot123, align 64
  %.slot124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot124, align 32
  %.slot125 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot125, align 64
  %.slot126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot126, align 32
  %.slot127 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot127, align 64
  %.slot128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot128, align 32
  %.slot129 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot129, align 64
  %.slot130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot130, align 32
  %.slot131 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot131, align 64
  %.slot132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot132, align 32
  %.slot133 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot133, align 64
  %.slot134 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot134, align 32
  %.spill135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill135, align 32
  %.spill136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill136, align 32
  %.spill137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill137, align 32
  %.spill138 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill138, align 32
  %.spill139 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill139, align 32
  %.spill140 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill140, align 32
  %.spill141 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill141, align 32
  %.spill142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill142, align 32
  %tile_snapshot.spill143 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill143, align 64
  %.spill144 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill144, align 32
  %.spill145 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill145, align 32
  %.spill146 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill146, align 32
  %.spill147 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill147, align 32
  %.spill148 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill148, align 32
  %.spill149 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill149, align 32
  %.spill150 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill150, align 32
  %.spill151 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill151, align 32
  %tile_snapshot.spill152 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill152, align 64
  %tile_snapshot.spill153 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill153, align 64
  %.slot154 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot154, align 64
  %.spill155 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill155, align 32
  %.spill156 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill156, align 32
  %.spill157 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill157, align 32
  %.spill158 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill158, align 32
  %.spill159 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill159, align 32
  %.spill160 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill160, align 32
  %.spill161 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill161, align 32
  %.spill162 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill162, align 32
  %.slot163 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot163, align 64
  %.slot164 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot164, align 32
  %.slot165 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot165, align 64
  %.slot166 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot166, align 32
  %.slot167 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot167, align 64
  %.slot168 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot168, align 32
  %.slot169 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot169, align 64
  %.slot170 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot170, align 32
  %.slot171 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot171, align 64
  %.slot172 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot172, align 32
  %.slot173 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot173, align 64
  %.slot174 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot174, align 32
  %.slot175 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot175, align 64
  %.slot176 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot176, align 32
  %.slot177 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot177, align 64
  %.slot178 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot178, align 32
  %.spill179 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill179, align 32
  %.spill180 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill180, align 32
  %.spill181 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill181, align 32
  %.spill182 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill182, align 32
  %.spill183 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill183, align 32
  %.spill184 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill184, align 32
  %.spill185 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill185, align 32
  %.spill186 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill186, align 32
  %tile_snapshot.spill187 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill187, align 64
  %.slot188 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot188, align 64
  %.spill189 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill189, align 64
  %.slot190 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot190, align 64
  %.spill191 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill191, align 64
  %.spill192 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill192, align 64
  %.spill193 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill193, align 64
  %.spill194 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill194, align 64
  %.spill195 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill195, align 64
  %.spill196 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill196, align 64
  %.spill197 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill197, align 64
  %.spill198 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill198, align 64
  %.slot199 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot199, align 64
  %.slot200 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot200, align 32
  %.slot201 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot201, align 32
  %.slot202 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot202, align 32
  %.slot203 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot203, align 32
  %.slot204 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot204, align 64
  %.slot205 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot205, align 64
  %tile_snapshot.spill206 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill206, align 64
  %.slot207 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot207, align 64
  %.spill208 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill208, align 64
  %.spill209 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill209, align 32
  %48 = getelementptr i8, ptr %argument_buffer, i64 0
  %49 = load ptr, ptr %48, align 16
  %50 = getelementptr i8, ptr %48, i64 8
  %51 = load i64, ptr %50, align 8
  %52 = insertvalue { ptr, i64 } poison, ptr %49, 0
  %53 = insertvalue { ptr, i64 } %52, i64 %51, 1
  %54 = getelementptr i8, ptr %argument_buffer, i64 16
  %55 = load ptr, ptr %54, align 16
  %56 = getelementptr i8, ptr %54, i64 8
  %57 = load i64, ptr %56, align 8
  %58 = insertvalue { ptr, i64 } poison, ptr %55, 0
  %59 = insertvalue { ptr, i64 } %58, i64 %57, 1
  %60 = getelementptr i8, ptr %argument_buffer, i64 32
  %61 = load ptr, ptr %60, align 16
  %62 = getelementptr i8, ptr %60, i64 8
  %63 = load i64, ptr %62, align 8
  %64 = insertvalue { ptr, i64 } poison, ptr %61, 0
  %65 = insertvalue { ptr, i64 } %64, i64 %63, 1
  %66 = getelementptr i8, ptr %argument_buffer, i64 48
  %67 = load ptr, ptr %66, align 16
  %68 = getelementptr i8, ptr %66, i64 8
  %69 = load i64, ptr %68, align 8
  %70 = insertvalue { ptr, i64 } poison, ptr %67, 0
  %71 = insertvalue { ptr, i64 } %70, i64 %69, 1
  %72 = load i32, ptr %launch_config, align 4
  %73 = getelementptr i8, ptr %launch_config, i64 12
  %74 = load i32, ptr %73, align 4
  %75 = getelementptr i8, ptr %launch_config, i64 4
  %76 = load i32, ptr %75, align 4
  %77 = getelementptr i8, ptr %launch_config, i64 16
  %78 = load i32, ptr %77, align 4
  %79 = getelementptr i8, ptr %launch_config, i64 8
  %80 = load i32, ptr %79, align 4
  %81 = getelementptr i8, ptr %launch_config, i64 20
  %82 = load i32, ptr %81, align 4
  %83 = getelementptr i8, ptr %launch_config, i64 36
  %84 = load i32, ptr %83, align 4
  %.splatinsert210 = insertelement <8 x i32> poison, i32 %84, i64 0
  %.splat211 = shufflevector <8 x i32> %.splatinsert210, <8 x i32> poison, <8 x i32> zeroinitializer
  %85 = add <8 x i32> %.splat211, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %86 = mul i32 %72, 32
  %.splatinsert212 = insertelement <8 x i32> poison, i32 %86, i64 0
  %.splat213 = shufflevector <8 x i32> %.splatinsert212, <8 x i32> poison, <8 x i32> zeroinitializer
  %87 = add <8 x i32> %.splat213, %85
  %88 = mul i32 %76, 1
  %.splatinsert214 = insertelement <8 x i32> poison, i32 %88, i64 0
  %.splat215 = shufflevector <8 x i32> %.splatinsert214, <8 x i32> poison, <8 x i32> zeroinitializer
  %89 = add <8 x i32> %.splat215, zeroinitializer
  %90 = mul i32 %80, 1
  %.splatinsert216 = insertelement <8 x i32> poison, i32 %90, i64 0
  %.splat217 = shufflevector <8 x i32> %.splatinsert216, <8 x i32> poison, <8 x i32> zeroinitializer
  %91 = add <8 x i32> %.splat217, zeroinitializer
  %92 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %87, 0
  %93 = insertvalue [3 x <8 x i32>] %92, <8 x i32> %89, 1
  %94 = insertvalue [3 x <8 x i32>] %93, <8 x i32> %91, 2
  %.splatinsert218 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat219 = shufflevector <8 x i32> %.splatinsert218, <8 x i32> poison, <8 x i32> zeroinitializer
  %95 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat219
  store <8 x i1> %95, ptr %live.mask, align 1
  %96 = load i32, ptr %current.token, align 4
  %97 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %98 = load i32, ptr %ready.count, align 4
  %99 = icmp uge i32 %98, 8
  %100 = and i1 %97, %99
  br i1 %100, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %101 = select i1 %97, i32 %98, i32 0
  %102 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %101
  %103 = load <8 x i1>, ptr %102, align 1
  %104 = select i1 %97, <8 x i1> %95, <8 x i1> %103
  store <8 x i1> %104, ptr %102, align 1
  %105 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %101
  %106 = load i32, ptr %105, align 4
  %107 = select i1 %97, i32 0, i32 %106
  store i32 %107, ptr %105, align 4
  %108 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %101
  %109 = load i32, ptr %108, align 4
  %110 = select i1 %97, i32 %96, i32 %109
  store i32 %110, ptr %108, align 4
  %111 = add i32 %98, 1
  %112 = select i1 %97, i32 %111, i32 %98
  store i32 %112, ptr %ready.count, align 4
  %113 = load <8 x i1>, ptr %runnable.mask, align 1
  %114 = or <8 x i1> %113, %95
  store <8 x i1> %114, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit1567, %convergence.target.106.ready, %convergence.cascade.exit1549, %schedule.105, %varying.coherent.false1545, %varying.coherent.true1544, %varying.coherent.false1531, %varying.coherent.true1530, %convergence.target.102.ready, %convergence.cascade.exit1483, %convergence.target.101.ready, %convergence.cascade.exit1449, %schedule.100, %varying.coherent.false1442, %varying.coherent.true1441, %convergence.target.98.ready, %convergence.cascade.exit1418, %schedule.97, %varying.coherent.false1411, %varying.coherent.true1410, %convergence.target.95.ready, %convergence.cascade.exit1387, %convergence.target.94.ready, %convergence.cascade.exit1369, %convergence.target.93.ready, %convergence.cascade.exit1339, %schedule.92, %varying.coherent.false1321, %varying.coherent.true1320, %schedule.90, %varying.coherent.false1302, %varying.coherent.true1301, %schedule.88, %varying.coherent.false1292, %varying.coherent.true1291, %convergence.target.86.ready, %convergence.cascade.exit1252, %schedule.85, %varying.coherent.false1246, %varying.coherent.true1245, %convergence.target.83.ready, %convergence.cascade.exit1222, %schedule.82, %varying.coherent.false1216, %varying.coherent.true1215, %convergence.target.80.ready, %convergence.cascade.exit1192, %schedule.79, %varying.coherent.false1186, %varying.coherent.true1185, %convergence.target.77.ready, %convergence.cascade.exit1162, %schedule.76, %varying.coherent.false1156, %varying.coherent.true1155, %convergence.target.74.ready, %convergence.cascade.exit1132, %schedule.73, %varying.coherent.false1126, %varying.coherent.true1125, %convergence.target.71.ready, %convergence.cascade.exit1102, %schedule.70, %varying.coherent.false1096, %varying.coherent.true1095, %convergence.target.68.ready, %convergence.cascade.exit1072, %schedule.67, %varying.coherent.false1066, %varying.coherent.true1065, %convergence.target.65.ready, %convergence.cascade.exit1042, %schedule.64, %varying.coherent.false1036, %varying.coherent.true1035, %convergence.target.62.ready, %convergence.cascade.exit996, %schedule.61, %varying.coherent.false985, %varying.coherent.true984, %convergence.target.59.ready, %convergence.cascade.exit898, %schedule.58, %varying.coherent.false892, %varying.coherent.true891, %convergence.target.56.ready, %convergence.cascade.exit868, %schedule.55, %varying.coherent.false862, %varying.coherent.true861, %convergence.target.53.ready, %convergence.cascade.exit838, %schedule.52, %varying.coherent.false832, %varying.coherent.true831, %convergence.target.50.ready, %convergence.cascade.exit808, %schedule.49, %varying.coherent.false802, %varying.coherent.true801, %convergence.target.47.ready, %convergence.cascade.exit778, %schedule.46, %varying.coherent.false772, %varying.coherent.true771, %convergence.target.44.ready, %convergence.cascade.exit748, %schedule.43, %varying.coherent.false742, %varying.coherent.true741, %convergence.target.41.ready, %convergence.cascade.exit718, %schedule.40, %varying.coherent.false712, %varying.coherent.true711, %convergence.target.38.ready, %convergence.cascade.exit688, %schedule.37, %varying.coherent.false682, %varying.coherent.true681, %convergence.target.35.ready, %convergence.cascade.exit658, %schedule.34, %varying.coherent.false649, %varying.coherent.true648, %convergence.target.32.ready, %convergence.cascade.exit625, %schedule.31, %varying.coherent.false615, %varying.coherent.true614, %convergence.target.29.ready, %convergence.cascade.exit521, %convergence.target.28.ready, %convergence.cascade.exit503, %convergence.target.27.ready, %convergence.cascade.exit473, %schedule.26, %varying.coherent.false448, %varying.coherent.true447, %schedule.24, %varying.coherent.false437, %varying.coherent.true436, %schedule.22, %varying.coherent.false427, %varying.coherent.true426, %convergence.target.20.ready, %convergence.cascade.exit403, %convergence.target.19.ready, %convergence.cascade.exit382, %schedule.18, %varying.coherent.false379, %varying.coherent.true378, %varying.coherent.false367, %varying.coherent.true366, %convergence.target.15.ready, %convergence.cascade.exit343, %convergence.target.14.ready, %convergence.cascade.exit322, %schedule.13, %varying.coherent.false319, %varying.coherent.true318, %varying.coherent.false307, %varying.coherent.true306, %schedule.10, %varying.coherent.false297, %varying.coherent.true296, %convergence.target.8.ready, %convergence.cascade.exit273, %schedule.7, %varying.coherent.false268, %varying.coherent.true267, %convergence.target.5.ready, %convergence.cascade.exit244, %convergence.target.4.ready, %convergence.cascade.exit, %schedule.3, %varying.coherent.false232, %varying.coherent.true231, %varying.coherent.false, %varying.coherent.true, %schedule.0, %ready.overflow.resume
  %115 = load i32, ptr %ready.count, align 4
  %116 = icmp ne i32 %115, 0
  br i1 %116, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %117 = sub i32 %115, 1
  store i32 %117, ptr %ready.count, align 4
  %118 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %117
  %119 = load <8 x i1>, ptr %118, align 1
  store <8 x i1> %119, ptr %current.mask, align 1
  %120 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %117
  %121 = load i32, ptr %120, align 4
  %122 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %117
  %123 = load i32, ptr %122, align 4
  store i32 %123, ptr %current.token, align 4
  %124 = load <8 x i1>, ptr %runnable.mask, align 1
  %125 = xor <8 x i1> %119, splat (i1 true)
  %126 = and <8 x i1> %124, %125
  store <8 x i1> %126, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume1543, %ready.overflow.resume1529, %ready.overflow.resume1440, %ready.overflow.resume1409, %ready.overflow.resume1319, %ready.overflow.resume1300, %ready.overflow.resume1290, %ready.overflow.resume1244, %ready.overflow.resume1214, %ready.overflow.resume1184, %ready.overflow.resume1154, %ready.overflow.resume1124, %ready.overflow.resume1094, %ready.overflow.resume1064, %ready.overflow.resume1034, %ready.overflow.resume983, %ready.overflow.resume890, %ready.overflow.resume860, %ready.overflow.resume830, %ready.overflow.resume800, %ready.overflow.resume770, %ready.overflow.resume740, %ready.overflow.resume710, %ready.overflow.resume680, %ready.overflow.resume647, %ready.overflow.resume613, %ready.overflow.resume446, %ready.overflow.resume435, %ready.overflow.resume425, %ready.overflow.resume377, %ready.overflow.resume365, %ready.overflow.resume317, %ready.overflow.resume305, %ready.overflow.resume295, %ready.overflow.resume266, %ready.overflow.resume230, %ready.overflow.resume221, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %121, %scheduler.dispatch ], [ 5, %ready.overflow.resume221 ], [ 4, %ready.overflow.resume230 ], [ 8, %ready.overflow.resume266 ], [ 102, %ready.overflow.resume295 ], [ 15, %ready.overflow.resume305 ], [ 14, %ready.overflow.resume317 ], [ 20, %ready.overflow.resume365 ], [ 19, %ready.overflow.resume377 ], [ 29, %ready.overflow.resume425 ], [ 28, %ready.overflow.resume435 ], [ 27, %ready.overflow.resume446 ], [ 32, %ready.overflow.resume613 ], [ 35, %ready.overflow.resume647 ], [ 38, %ready.overflow.resume680 ], [ 41, %ready.overflow.resume710 ], [ 44, %ready.overflow.resume740 ], [ 47, %ready.overflow.resume770 ], [ 50, %ready.overflow.resume800 ], [ 53, %ready.overflow.resume830 ], [ 56, %ready.overflow.resume860 ], [ 59, %ready.overflow.resume890 ], [ 62, %ready.overflow.resume983 ], [ 65, %ready.overflow.resume1034 ], [ 68, %ready.overflow.resume1064 ], [ 71, %ready.overflow.resume1094 ], [ 74, %ready.overflow.resume1124 ], [ 77, %ready.overflow.resume1154 ], [ 80, %ready.overflow.resume1184 ], [ 83, %ready.overflow.resume1214 ], [ 86, %ready.overflow.resume1244 ], [ 95, %ready.overflow.resume1290 ], [ 94, %ready.overflow.resume1300 ], [ 93, %ready.overflow.resume1319 ], [ 98, %ready.overflow.resume1409 ], [ 101, %ready.overflow.resume1440 ], [ 107, %ready.overflow.resume1529 ], [ 106, %ready.overflow.resume1543 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
    i32 41, label %schedule.41
    i32 42, label %schedule.42
    i32 43, label %schedule.43
    i32 44, label %schedule.44
    i32 45, label %schedule.45
    i32 46, label %schedule.46
    i32 47, label %schedule.47
    i32 48, label %schedule.48
    i32 49, label %schedule.49
    i32 50, label %schedule.50
    i32 51, label %schedule.51
    i32 52, label %schedule.52
    i32 53, label %schedule.53
    i32 54, label %schedule.54
    i32 55, label %schedule.55
    i32 56, label %schedule.56
    i32 57, label %schedule.57
    i32 58, label %schedule.58
    i32 59, label %schedule.59
    i32 60, label %schedule.60
    i32 61, label %schedule.61
    i32 62, label %schedule.62
    i32 63, label %schedule.63
    i32 64, label %schedule.64
    i32 65, label %schedule.65
    i32 66, label %schedule.66
    i32 67, label %schedule.67
    i32 68, label %schedule.68
    i32 69, label %schedule.69
    i32 70, label %schedule.70
    i32 71, label %schedule.71
    i32 72, label %schedule.72
    i32 73, label %schedule.73
    i32 74, label %schedule.74
    i32 75, label %schedule.75
    i32 76, label %schedule.76
    i32 77, label %schedule.77
    i32 78, label %schedule.78
    i32 79, label %schedule.79
    i32 80, label %schedule.80
    i32 81, label %schedule.81
    i32 82, label %schedule.82
    i32 83, label %schedule.83
    i32 84, label %schedule.84
    i32 85, label %schedule.85
    i32 86, label %schedule.86
    i32 87, label %schedule.87
    i32 88, label %schedule.88
    i32 89, label %schedule.89
    i32 90, label %schedule.90
    i32 91, label %schedule.91
    i32 92, label %schedule.92
    i32 93, label %schedule.93
    i32 94, label %schedule.94
    i32 95, label %schedule.95
    i32 96, label %schedule.96
    i32 97, label %schedule.97
    i32 98, label %schedule.98
    i32 99, label %schedule.99
    i32 100, label %schedule.100
    i32 101, label %schedule.101
    i32 102, label %schedule.102
    i32 103, label %schedule.103
    i32 104, label %schedule.104
    i32 105, label %schedule.105
    i32 106, label %schedule.106
    i32 107, label %schedule.107
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %127 = load <8 x i1>, ptr %live.mask, align 1
  %128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %127)
  br i1 %128, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %129 = load <8 x i1>, ptr %current.mask, align 1
  %130 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %131 = bitcast <8 x i1> %129 to i8
  %132 = call i8 @llvm.cttz.i8(i8 %131, i1 false)
  %133 = zext i8 %132 to i32
  %134 = select i1 %130, i32 %133, i32 0
  %135 = extractvalue [3 x <8 x i32>] %94, 0
  %136 = zext <8 x i32> %135 to <8 x i64>
  %137 = select <8 x i1> %129, <8 x i64> %136, <8 x i64> zeroinitializer
  %138 = select <8 x i1> %129, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %139 = sdiv <8 x i64> %137, %138
  %140 = load <8 x i64>, ptr %.spill, align 64
  %141 = select <8 x i1> %129, <8 x i64> %139, <8 x i64> %140
  store <8 x i64> %141, ptr %.spill, align 64
  %142 = select <8 x i1> %129, <8 x i64> %136, <8 x i64> zeroinitializer
  %143 = select <8 x i1> %129, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %144 = sdiv <8 x i64> %142, %143
  %145 = select <8 x i1> %129, <8 x i64> %144, <8 x i64> zeroinitializer
  %146 = select <8 x i1> %129, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %147 = srem <8 x i64> %145, %146
  %148 = mul <8 x i64> %147, splat (i64 8)
  %149 = load <8 x i64>, ptr %.spill61, align 64
  %150 = select <8 x i1> %129, <8 x i64> %148, <8 x i64> %149
  store <8 x i64> %150, ptr %.spill61, align 64
  %151 = select <8 x i1> %129, <8 x i64> %139, <8 x i64> zeroinitializer
  %152 = select <8 x i1> %129, <8 x i64> splat (i64 3), <8 x i64> splat (i64 1)
  %153 = sdiv <8 x i64> %151, %152
  %154 = load <8 x i64>, ptr %.spill62, align 64
  %155 = select <8 x i1> %129, <8 x i64> %153, <8 x i64> %154
  store <8 x i64> %155, ptr %.spill62, align 64
  %156 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %156, 0
  %159 = select <8 x i1> %129, <8 x ptr> %157, <8 x ptr> %158
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %156, 1
  %162 = select <8 x i1> %129, <8 x i64> %160, <8 x i64> %161
  %163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %159, 0
  %164 = insertvalue { <8 x ptr>, <8 x i64> } %163, <8 x i64> %162, 1
  store { <8 x ptr>, <8 x i64> } %164, ptr %tile_snapshot.spill, align 64
  %165 = load <8 x i64>, ptr %.slot, align 64
  %166 = select <8 x i1> %129, <8 x i64> zeroinitializer, <8 x i64> %165
  store <8 x i64> %166, ptr %.slot, align 64
  store <8 x i1> %129, ptr %current.mask, align 1
  %167 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  br i1 %167, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %convergence.target.4.ready, %schedule.0, %scheduler.dispatch.route
  %168 = load <8 x i1>, ptr %current.mask, align 1
  %169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %168)
  %170 = bitcast <8 x i1> %168 to i8
  %171 = call i8 @llvm.cttz.i8(i8 %170, i1 false)
  %172 = zext i8 %171 to i32
  %173 = select i1 %169, i32 %172, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %174 = icmp slt <8 x i64> %.state, splat (i64 384)
  %175 = and <8 x i1> %168, %174
  %176 = xor <8 x i1> %174, splat (i1 true)
  %177 = and <8 x i1> %168, %176
  %178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %175)
  %179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %177)
  %180 = and i1 %178, %179
  br i1 %180, label %varying.divergent, label %varying.coherent

schedule.2:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %181 = load <8 x i1>, ptr %current.mask, align 1
  %182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %181)
  %183 = bitcast <8 x i1> %181 to i8
  %184 = call i8 @llvm.cttz.i8(i8 %183, i1 false)
  %185 = zext i8 %184 to i32
  %186 = select i1 %182, i32 %185, i32 0
  %.state222 = load <8 x i64>, ptr %.slot, align 64
  %187 = select <8 x i1> %181, <8 x i64> %.state222, <8 x i64> zeroinitializer
  %188 = select <8 x i1> %181, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %189 = srem <8 x i64> %187, %188
  %.state223 = load <8 x i64>, ptr %.slot, align 64
  %190 = select <8 x i1> %181, <8 x i64> %.state223, <8 x i64> zeroinitializer
  %191 = select <8 x i1> %181, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %192 = sdiv <8 x i64> %190, %191
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %193 = add <8 x i64> %.spill.load, zeroinitializer
  %194 = add <8 x i64> zeroinitializer, %193
  %.spill.load224 = load <8 x i64>, ptr %.spill61, align 64
  %195 = add <8 x i64> %.spill.load224, %192
  %196 = mul <8 x i64> %194, splat (i64 33)
  %197 = add <8 x i64> %196, %195
  %198 = icmp sge <8 x i64> %195, zeroinitializer
  %199 = and <8 x i1> splat (i1 true), %198
  %200 = icmp slt <8 x i64> %195, splat (i64 33)
  %201 = and <8 x i1> %199, %200
  %202 = add <8 x i64> zeroinitializer, %189
  %203 = mul <8 x i64> %197, splat (i64 48)
  %204 = add <8 x i64> %203, %202
  %205 = load <8 x i64>, ptr %.spill63, align 64
  %206 = select <8 x i1> %181, <8 x i64> %204, <8 x i64> %205
  store <8 x i64> %206, ptr %.spill63, align 64
  %207 = and <8 x i1> %181, %201
  %208 = xor <8 x i1> %201, splat (i1 true)
  %209 = and <8 x i1> %181, %208
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %207)
  %211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %209)
  %212 = and i1 %210, %211
  br i1 %212, label %varying.divergent225, label %varying.coherent226

schedule.3:                                       ; preds = %varying.coherent.true231, %scheduler.dispatch.route
  %213 = load <8 x i1>, ptr %current.mask, align 1
  %214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %213)
  %215 = bitcast <8 x i1> %213 to i8
  %216 = call i8 @llvm.cttz.i8(i8 %215, i1 false)
  %217 = zext i8 %216 to i32
  %218 = select i1 %214, i32 %217, i32 0
  %.spill.load233 = load <8 x i64>, ptr %.spill63, align 64
  %219 = extractvalue { ptr, i64 } %53, 0
  %220 = mul <8 x i64> %.spill.load233, splat (i64 4)
  %221 = getelementptr i8, ptr %219, <8 x i64> %220
  %222 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %221, <8 x i1> %213, <8 x float> zeroinitializer)
  %223 = load <8 x float>, ptr %.slot64, align 32
  %224 = select <8 x i1> %213, <8 x float> %222, <8 x float> %223
  store <8 x float> %224, ptr %.slot64, align 32
  store <8 x i1> %213, ptr %current.mask, align 1
  %225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %213)
  br i1 %225, label %schedule.4, label %scheduler.loop

schedule.4:                                       ; preds = %schedule.3, %varying.coherent.false232, %scheduler.dispatch.route
  %226 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.5:                                       ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %227 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token245 = load i32, ptr %current.token, align 4
  %convergence.token.present246 = icmp ne i32 %convergence.current.token245, 0
  br i1 %convergence.token.present246, label %convergence.cascade243, label %convergence.cascade.exit244

schedule.6:                                       ; preds = %schedule.7, %convergence.target.5.ready, %scheduler.dispatch.route
  %228 = load <8 x i1>, ptr %current.mask, align 1
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  %230 = bitcast <8 x i1> %228 to i8
  %231 = call i8 @llvm.cttz.i8(i8 %230, i1 false)
  %232 = zext i8 %231 to i32
  %233 = select i1 %229, i32 %232, i32 0
  %.state260 = load <8 x i64>, ptr %.slot67, align 64
  %234 = icmp slt <8 x i64> %.state260, splat (i64 320)
  %235 = and <8 x i1> %228, %234
  %236 = xor <8 x i1> %234, splat (i1 true)
  %237 = and <8 x i1> %228, %236
  %238 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %235)
  %239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %237)
  %240 = and i1 %238, %239
  br i1 %240, label %varying.divergent261, label %varying.coherent262

schedule.7:                                       ; preds = %varying.coherent.true267, %scheduler.dispatch.route
  %241 = load <8 x i1>, ptr %current.mask, align 1
  %242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %243 = bitcast <8 x i1> %241 to i8
  %244 = call i8 @llvm.cttz.i8(i8 %243, i1 false)
  %245 = zext i8 %244 to i32
  %246 = select i1 %242, i32 %245, i32 0
  %tile_snapshot.spill.load269 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load269, 0
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load269, 1
  %.state270 = load <8 x i64>, ptr %.slot67, align 64
  %249 = mul <8 x i64> %.state270, splat (i64 32)
  %250 = add <8 x i64> %248, %249
  %251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %247, 0
  %252 = insertvalue { <8 x ptr>, <8 x i64> } %251, <8 x i64> %250, 1
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %252, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %255 = getelementptr i8, <8 x ptr> %253, <8 x i64> %254
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %255, <8 x i1> %241)
  %.state271 = load <8 x i64>, ptr %.slot67, align 64
  %256 = add <8 x i64> %.state271, splat (i64 1)
  %257 = load <8 x i64>, ptr %.slot67, align 64
  %258 = select <8 x i1> %241, <8 x i64> %256, <8 x i64> %257
  store <8 x i64> %258, ptr %.slot67, align 64
  store <8 x i1> %241, ptr %current.mask, align 1
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  br i1 %259, label %schedule.6, label %scheduler.loop

schedule.8:                                       ; preds = %varying.coherent.false268, %scheduler.dispatch.route
  %260 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token274 = load i32, ptr %current.token, align 4
  %convergence.token.present275 = icmp ne i32 %convergence.current.token274, 0
  br i1 %convergence.token.present275, label %convergence.cascade272, label %convergence.cascade.exit273

schedule.9:                                       ; preds = %convergence.target.101.ready, %convergence.target.8.ready, %scheduler.dispatch.route
  %261 = load <8 x i1>, ptr %current.mask, align 1
  %262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %261)
  %263 = bitcast <8 x i1> %261 to i8
  %264 = call i8 @llvm.cttz.i8(i8 %263, i1 false)
  %265 = zext i8 %264 to i32
  %266 = select i1 %262, i32 %265, i32 0
  %.state289 = load <8 x i64>, ptr %.slot68, align 64
  %267 = icmp slt <8 x i64> %.state289, splat (i64 9)
  %268 = and <8 x i1> %261, %267
  %269 = xor <8 x i1> %267, splat (i1 true)
  %270 = and <8 x i1> %261, %269
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %268)
  %272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %270)
  %273 = and i1 %271, %272
  br i1 %273, label %varying.divergent290, label %varying.coherent291

schedule.10:                                      ; preds = %varying.coherent.true296, %scheduler.dispatch.route
  %274 = load <8 x i1>, ptr %current.mask, align 1
  %275 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %274)
  %276 = bitcast <8 x i1> %274 to i8
  %277 = call i8 @llvm.cttz.i8(i8 %276, i1 false)
  %278 = zext i8 %277 to i32
  %279 = select i1 %275, i32 %278, i32 0
  %.state298 = load <8 x i64>, ptr %.slot68, align 64
  %280 = select <8 x i1> %274, <8 x i64> %.state298, <8 x i64> zeroinitializer
  %281 = select <8 x i1> %274, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %282 = sdiv <8 x i64> %280, %281
  %283 = mul <8 x i64> %282, splat (i64 16)
  %284 = load <8 x i64>, ptr %.spill85, align 64
  %285 = select <8 x i1> %274, <8 x i64> %283, <8 x i64> %284
  store <8 x i64> %285, ptr %.spill85, align 64
  %286 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill86, align 64
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %286, 0
  %289 = select <8 x i1> %274, <8 x ptr> %287, <8 x ptr> %288
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %286, 1
  %292 = select <8 x i1> %274, <8 x i64> %290, <8 x i64> %291
  %293 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %289, 0
  %294 = insertvalue { <8 x ptr>, <8 x i64> } %293, <8 x i64> %292, 1
  store { <8 x ptr>, <8 x i64> } %294, ptr %tile_snapshot.spill86, align 64
  %295 = load <8 x i64>, ptr %.slot87, align 64
  %296 = select <8 x i1> %274, <8 x i64> zeroinitializer, <8 x i64> %295
  store <8 x i64> %296, ptr %.slot87, align 64
  store <8 x i1> %274, ptr %current.mask, align 1
  %297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %274)
  br i1 %297, label %schedule.11, label %scheduler.loop

schedule.11:                                      ; preds = %convergence.target.14.ready, %schedule.10, %scheduler.dispatch.route
  %298 = load <8 x i1>, ptr %current.mask, align 1
  %299 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %298)
  %300 = bitcast <8 x i1> %298 to i8
  %301 = call i8 @llvm.cttz.i8(i8 %300, i1 false)
  %302 = zext i8 %301 to i32
  %303 = select i1 %299, i32 %302, i32 0
  %.state299 = load <8 x i64>, ptr %.slot87, align 64
  %304 = icmp slt <8 x i64> %.state299, splat (i64 768)
  %305 = and <8 x i1> %298, %304
  %306 = xor <8 x i1> %304, splat (i1 true)
  %307 = and <8 x i1> %298, %306
  %308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %305)
  %309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %307)
  %310 = and i1 %308, %309
  br i1 %310, label %varying.divergent300, label %varying.coherent301

schedule.12:                                      ; preds = %varying.coherent.true306, %scheduler.dispatch.route
  %311 = load <8 x i1>, ptr %current.mask, align 1
  %312 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %311)
  %313 = bitcast <8 x i1> %311 to i8
  %314 = call i8 @llvm.cttz.i8(i8 %313, i1 false)
  %315 = zext i8 %314 to i32
  %316 = select i1 %312, i32 %315, i32 0
  %.state308 = load <8 x i64>, ptr %.slot87, align 64
  %317 = select <8 x i1> %311, <8 x i64> %.state308, <8 x i64> zeroinitializer
  %318 = select <8 x i1> %311, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %319 = srem <8 x i64> %317, %318
  %.state309 = load <8 x i64>, ptr %.slot87, align 64
  %320 = select <8 x i1> %311, <8 x i64> %.state309, <8 x i64> zeroinitializer
  %321 = select <8 x i1> %311, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %322 = sdiv <8 x i64> %320, %321
  %.spill.load310 = load <8 x i64>, ptr %.spill62, align 64
  %323 = add <8 x i64> %.spill.load310, zeroinitializer
  %324 = add <8 x i64> zeroinitializer, %323
  %.spill.load311 = load <8 x i64>, ptr %.spill85, align 64
  %325 = add <8 x i64> %.spill.load311, %322
  %326 = mul <8 x i64> %324, splat (i64 131)
  %327 = add <8 x i64> %326, %325
  %328 = icmp sge <8 x i64> %325, zeroinitializer
  %329 = and <8 x i1> splat (i1 true), %328
  %330 = icmp slt <8 x i64> %325, splat (i64 131)
  %331 = and <8 x i1> %329, %330
  %332 = add <8 x i64> zeroinitializer, %319
  %333 = mul <8 x i64> %327, splat (i64 48)
  %334 = add <8 x i64> %333, %332
  %335 = load <8 x i64>, ptr %.spill88, align 64
  %336 = select <8 x i1> %311, <8 x i64> %334, <8 x i64> %335
  store <8 x i64> %336, ptr %.spill88, align 64
  %337 = and <8 x i1> %311, %331
  %338 = xor <8 x i1> %331, splat (i1 true)
  %339 = and <8 x i1> %311, %338
  %340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %337)
  %341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %339)
  %342 = and i1 %340, %341
  br i1 %342, label %varying.divergent312, label %varying.coherent313

schedule.13:                                      ; preds = %varying.coherent.true318, %scheduler.dispatch.route
  %343 = load <8 x i1>, ptr %current.mask, align 1
  %344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %343)
  %345 = bitcast <8 x i1> %343 to i8
  %346 = call i8 @llvm.cttz.i8(i8 %345, i1 false)
  %347 = zext i8 %346 to i32
  %348 = select i1 %344, i32 %347, i32 0
  %.spill.load320 = load <8 x i64>, ptr %.spill88, align 64
  %349 = extractvalue { ptr, i64 } %59, 0
  %350 = mul <8 x i64> %.spill.load320, splat (i64 4)
  %351 = getelementptr i8, ptr %349, <8 x i64> %350
  %352 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %351, <8 x i1> %343, <8 x float> zeroinitializer)
  %353 = load <8 x float>, ptr %.slot89, align 32
  %354 = select <8 x i1> %343, <8 x float> %352, <8 x float> %353
  store <8 x float> %354, ptr %.slot89, align 32
  store <8 x i1> %343, ptr %current.mask, align 1
  %355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %343)
  br i1 %355, label %schedule.14, label %scheduler.loop

schedule.14:                                      ; preds = %schedule.13, %varying.coherent.false319, %scheduler.dispatch.route
  %356 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token323 = load i32, ptr %current.token, align 4
  %convergence.token.present324 = icmp ne i32 %convergence.current.token323, 0
  br i1 %convergence.token.present324, label %convergence.cascade321, label %convergence.cascade.exit322

schedule.15:                                      ; preds = %varying.coherent.false307, %scheduler.dispatch.route
  %357 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token344 = load i32, ptr %current.token, align 4
  %convergence.token.present345 = icmp ne i32 %convergence.current.token344, 0
  br i1 %convergence.token.present345, label %convergence.cascade342, label %convergence.cascade.exit343

schedule.16:                                      ; preds = %convergence.target.19.ready, %convergence.target.15.ready, %scheduler.dispatch.route
  %358 = load <8 x i1>, ptr %current.mask, align 1
  %359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %358)
  %360 = bitcast <8 x i1> %358 to i8
  %361 = call i8 @llvm.cttz.i8(i8 %360, i1 false)
  %362 = zext i8 %361 to i32
  %363 = select i1 %359, i32 %362, i32 0
  %.state359 = load <8 x i64>, ptr %.slot91, align 64
  %364 = icmp slt <8 x i64> %.state359, splat (i64 640)
  %365 = and <8 x i1> %358, %364
  %366 = xor <8 x i1> %364, splat (i1 true)
  %367 = and <8 x i1> %358, %366
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %365)
  %369 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %367)
  %370 = and i1 %368, %369
  br i1 %370, label %varying.divergent360, label %varying.coherent361

schedule.17:                                      ; preds = %varying.coherent.true366, %scheduler.dispatch.route
  %371 = load <8 x i1>, ptr %current.mask, align 1
  %372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  %373 = bitcast <8 x i1> %371 to i8
  %374 = call i8 @llvm.cttz.i8(i8 %373, i1 false)
  %375 = zext i8 %374 to i32
  %376 = select i1 %372, i32 %375, i32 0
  %.state368 = load <8 x i64>, ptr %.slot91, align 64
  %377 = select <8 x i1> %371, <8 x i64> %.state368, <8 x i64> zeroinitializer
  %378 = select <8 x i1> %371, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %379 = srem <8 x i64> %377, %378
  %.state369 = load <8 x i64>, ptr %.slot91, align 64
  %380 = select <8 x i1> %371, <8 x i64> %.state369, <8 x i64> zeroinitializer
  %381 = select <8 x i1> %371, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %382 = sdiv <8 x i64> %380, %381
  %.spill.load370 = load <8 x i64>, ptr %.spill62, align 64
  %383 = add <8 x i64> %.spill.load370, zeroinitializer
  %384 = add <8 x i64> zeroinitializer, %383
  %.spill.load371 = load <8 x i64>, ptr %.spill85, align 64
  %385 = add <8 x i64> %.spill.load371, %382
  %386 = mul <8 x i64> %384, splat (i64 131)
  %387 = add <8 x i64> %386, %385
  %388 = icmp sge <8 x i64> %385, zeroinitializer
  %389 = and <8 x i1> splat (i1 true), %388
  %390 = icmp slt <8 x i64> %385, splat (i64 131)
  %391 = and <8 x i1> %389, %390
  %392 = add <8 x i64> zeroinitializer, %379
  %393 = mul <8 x i64> %387, splat (i64 40)
  %394 = add <8 x i64> %393, %392
  %395 = load <8 x i64>, ptr %.spill92, align 64
  %396 = select <8 x i1> %371, <8 x i64> %394, <8 x i64> %395
  store <8 x i64> %396, ptr %.spill92, align 64
  %397 = and <8 x i1> %371, %391
  %398 = xor <8 x i1> %391, splat (i1 true)
  %399 = and <8 x i1> %371, %398
  %400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %397)
  %401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %399)
  %402 = and i1 %400, %401
  br i1 %402, label %varying.divergent372, label %varying.coherent373

schedule.18:                                      ; preds = %varying.coherent.true378, %scheduler.dispatch.route
  %403 = load <8 x i1>, ptr %current.mask, align 1
  %404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %403)
  %405 = bitcast <8 x i1> %403 to i8
  %406 = call i8 @llvm.cttz.i8(i8 %405, i1 false)
  %407 = zext i8 %406 to i32
  %408 = select i1 %404, i32 %407, i32 0
  %.spill.load380 = load <8 x i64>, ptr %.spill92, align 64
  %409 = extractvalue { ptr, i64 } %65, 0
  %410 = mul <8 x i64> %.spill.load380, splat (i64 4)
  %411 = getelementptr i8, ptr %409, <8 x i64> %410
  %412 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %411, <8 x i1> %403, <8 x float> zeroinitializer)
  %413 = load <8 x float>, ptr %.slot93, align 32
  %414 = select <8 x i1> %403, <8 x float> %412, <8 x float> %413
  store <8 x float> %414, ptr %.slot93, align 32
  store <8 x i1> %403, ptr %current.mask, align 1
  %415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %403)
  br i1 %415, label %schedule.19, label %scheduler.loop

schedule.19:                                      ; preds = %schedule.18, %varying.coherent.false379, %scheduler.dispatch.route
  %416 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token383 = load i32, ptr %current.token, align 4
  %convergence.token.present384 = icmp ne i32 %convergence.current.token383, 0
  br i1 %convergence.token.present384, label %convergence.cascade381, label %convergence.cascade.exit382

schedule.20:                                      ; preds = %varying.coherent.false367, %scheduler.dispatch.route
  %417 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token404 = load i32, ptr %current.token, align 4
  %convergence.token.present405 = icmp ne i32 %convergence.current.token404, 0
  br i1 %convergence.token.present405, label %convergence.cascade402, label %convergence.cascade.exit403

schedule.21:                                      ; preds = %convergence.target.28.ready, %convergence.target.20.ready, %scheduler.dispatch.route
  %418 = load <8 x i1>, ptr %current.mask, align 1
  %419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %418)
  %420 = bitcast <8 x i1> %418 to i8
  %421 = call i8 @llvm.cttz.i8(i8 %420, i1 false)
  %422 = zext i8 %421 to i32
  %423 = select i1 %419, i32 %422, i32 0
  %.state419 = load <8 x i64>, ptr %.slot95, align 64
  %424 = icmp slt <8 x i64> %.state419, splat (i64 4)
  %425 = and <8 x i1> %418, %424
  %426 = xor <8 x i1> %424, splat (i1 true)
  %427 = and <8 x i1> %418, %426
  %428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %425)
  %429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %427)
  %430 = and i1 %428, %429
  br i1 %430, label %varying.divergent420, label %varying.coherent421

schedule.22:                                      ; preds = %varying.coherent.true426, %scheduler.dispatch.route
  %431 = load <8 x i1>, ptr %current.mask, align 1
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %431)
  %433 = bitcast <8 x i1> %431 to i8
  %434 = call i8 @llvm.cttz.i8(i8 %433, i1 false)
  %435 = zext i8 %434 to i32
  %436 = select i1 %432, i32 %435, i32 0
  %.state428 = load <8 x i64>, ptr %.slot95, align 64
  %437 = mul <8 x i64> %.state428, splat (i64 2)
  %438 = load <8 x i64>, ptr %.spill96, align 64
  %439 = select <8 x i1> %431, <8 x i64> %437, <8 x i64> %438
  store <8 x i64> %439, ptr %.spill96, align 64
  %440 = load <8 x i64>, ptr %.slot97, align 64
  %441 = select <8 x i1> %431, <8 x i64> zeroinitializer, <8 x i64> %440
  store <8 x i64> %441, ptr %.slot97, align 64
  store <8 x i1> %431, ptr %current.mask, align 1
  %442 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %431)
  br i1 %442, label %schedule.23, label %scheduler.loop

schedule.23:                                      ; preds = %convergence.target.27.ready, %schedule.22, %scheduler.dispatch.route
  %443 = load <8 x i1>, ptr %current.mask, align 1
  %444 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %443)
  %445 = bitcast <8 x i1> %443 to i8
  %446 = call i8 @llvm.cttz.i8(i8 %445, i1 false)
  %447 = zext i8 %446 to i32
  %448 = select i1 %444, i32 %447, i32 0
  %.state429 = load <8 x i64>, ptr %.slot97, align 64
  %449 = icmp slt <8 x i64> %.state429, splat (i64 8)
  %450 = and <8 x i1> %443, %449
  %451 = xor <8 x i1> %449, splat (i1 true)
  %452 = and <8 x i1> %443, %451
  %453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %450)
  %454 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %452)
  %455 = and i1 %453, %454
  br i1 %455, label %varying.divergent430, label %varying.coherent431

schedule.24:                                      ; preds = %varying.coherent.true436, %scheduler.dispatch.route
  %456 = load <8 x i1>, ptr %current.mask, align 1
  %457 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %456)
  %458 = bitcast <8 x i1> %456 to i8
  %459 = call i8 @llvm.cttz.i8(i8 %458, i1 false)
  %460 = zext i8 %459 to i32
  %461 = select i1 %457, i32 %460, i32 0
  %.state438 = load <8 x i64>, ptr %.slot97, align 64
  %462 = mul <8 x i64> %.state438, splat (i64 2)
  store i64 0, ptr %.spill98, align 4
  %.spill.load439 = load <8 x i64>, ptr %.spill96, align 64
  %463 = add <8 x i64> zeroinitializer, %.spill.load439
  %464 = mul <8 x i64> %463, splat (i64 16)
  %465 = add <8 x i64> %464, %462
  %466 = add <8 x i64> %465, zeroinitializer
  %467 = load <8 x i64>, ptr %.spill99, align 64
  %468 = select <8 x i1> %456, <8 x i64> %466, <8 x i64> %467
  store <8 x i64> %468, ptr %.spill99, align 64
  %469 = select <8 x i1> %456, <8 x i64> %466, <8 x i64> zeroinitializer
  %470 = select <8 x i1> %456, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %471 = srem <8 x i64> %469, %470
  %472 = load <8 x i64>, ptr %.spill100, align 64
  %473 = select <8 x i1> %456, <8 x i64> %471, <8 x i64> %472
  store <8 x i64> %473, ptr %.spill100, align 64
  %474 = select <8 x i1> %456, <8 x i64> %466, <8 x i64> zeroinitializer
  %475 = select <8 x i1> %456, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %476 = sdiv <8 x i64> %474, %475
  %477 = load <8 x i64>, ptr %.spill101, align 64
  %478 = select <8 x i1> %456, <8 x i64> %476, <8 x i64> %477
  store <8 x i64> %478, ptr %.spill101, align 64
  %479 = add <8 x i64> %465, splat (i64 1)
  %480 = load <8 x i64>, ptr %.spill102, align 64
  %481 = select <8 x i1> %456, <8 x i64> %479, <8 x i64> %480
  store <8 x i64> %481, ptr %.spill102, align 64
  %482 = select <8 x i1> %456, <8 x i64> %479, <8 x i64> zeroinitializer
  %483 = select <8 x i1> %456, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %484 = srem <8 x i64> %482, %483
  %485 = load <8 x i64>, ptr %.spill103, align 64
  %486 = select <8 x i1> %456, <8 x i64> %484, <8 x i64> %485
  store <8 x i64> %486, ptr %.spill103, align 64
  %487 = add <8 x i64> %465, splat (i64 16)
  %488 = load <8 x i64>, ptr %.spill104, align 64
  %489 = select <8 x i1> %456, <8 x i64> %487, <8 x i64> %488
  store <8 x i64> %489, ptr %.spill104, align 64
  %490 = select <8 x i1> %456, <8 x i64> %487, <8 x i64> zeroinitializer
  %491 = select <8 x i1> %456, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %492 = sdiv <8 x i64> %490, %491
  %493 = load <8 x i64>, ptr %.spill105, align 64
  %494 = select <8 x i1> %456, <8 x i64> %492, <8 x i64> %493
  store <8 x i64> %494, ptr %.spill105, align 64
  %495 = add <8 x i64> %465, splat (i64 17)
  %496 = load <8 x i64>, ptr %.spill106, align 64
  %497 = select <8 x i1> %456, <8 x i64> %495, <8 x i64> %496
  store <8 x i64> %497, ptr %.spill106, align 64
  %498 = load <8 x i64>, ptr %.slot107, align 64
  %499 = select <8 x i1> %456, <8 x i64> zeroinitializer, <8 x i64> %498
  store <8 x i64> %499, ptr %.slot107, align 64
  %500 = load <8 x float>, ptr %.slot108, align 32
  %501 = select <8 x i1> %456, <8 x float> zeroinitializer, <8 x float> %500
  store <8 x float> %501, ptr %.slot108, align 32
  %502 = load <8 x float>, ptr %.slot109, align 32
  %503 = select <8 x i1> %456, <8 x float> zeroinitializer, <8 x float> %502
  store <8 x float> %503, ptr %.slot109, align 32
  %504 = load <8 x float>, ptr %.slot110, align 32
  %505 = select <8 x i1> %456, <8 x float> zeroinitializer, <8 x float> %504
  store <8 x float> %505, ptr %.slot110, align 32
  %506 = load <8 x float>, ptr %.slot111, align 32
  %507 = select <8 x i1> %456, <8 x float> zeroinitializer, <8 x float> %506
  store <8 x float> %507, ptr %.slot111, align 32
  store <8 x i1> %456, ptr %current.mask, align 1
  %508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %456)
  br i1 %508, label %schedule.25, label %scheduler.loop

schedule.25:                                      ; preds = %schedule.26, %schedule.24, %scheduler.dispatch.route
  %509 = load <8 x i1>, ptr %current.mask, align 1
  %510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %509)
  %511 = bitcast <8 x i1> %509 to i8
  %512 = call i8 @llvm.cttz.i8(i8 %511, i1 false)
  %513 = zext i8 %512 to i32
  %514 = select i1 %510, i32 %513, i32 0
  %.state440 = load <8 x i64>, ptr %.slot107, align 64
  %515 = icmp slt <8 x i64> %.state440, splat (i64 48)
  %516 = and <8 x i1> %509, %515
  %517 = xor <8 x i1> %515, splat (i1 true)
  %518 = and <8 x i1> %509, %517
  %519 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %516)
  %520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %518)
  %521 = and i1 %519, %520
  br i1 %521, label %varying.divergent441, label %varying.coherent442

schedule.26:                                      ; preds = %varying.coherent.true447, %scheduler.dispatch.route
  %522 = load <8 x i1>, ptr %current.mask, align 1
  %523 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %522)
  %524 = bitcast <8 x i1> %522 to i8
  %525 = call i8 @llvm.cttz.i8(i8 %524, i1 false)
  %526 = zext i8 %525 to i32
  %527 = select i1 %523, i32 %526, i32 0
  %.spill.load449 = load i64, ptr %.spill98, align 4
  %.splatinsert450 = insertelement <8 x i64> poison, i64 %.spill.load449, i64 0
  %.splat451 = shufflevector <8 x i64> %.splatinsert450, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load452 = load <8 x i64>, ptr %.spill101, align 64
  %528 = add <8 x i64> %.splat451, %.spill.load452
  %529 = mul <8 x i64> %528, splat (i64 48)
  %.state453 = load <8 x i64>, ptr %.slot107, align 64
  %530 = add <8 x i64> %529, %.state453
  %tile_snapshot.spill.load454 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load454, 0
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load454, 1
  %533 = mul <8 x i64> %530, splat (i64 32)
  %534 = add <8 x i64> %532, %533
  %535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %531, 0
  %536 = insertvalue { <8 x ptr>, <8 x i64> } %535, <8 x i64> %534, 1
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %536, 0
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %536, 1
  %539 = getelementptr i8, <8 x ptr> %537, <8 x i64> %538
  %540 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %539, <8 x i1> %522, <8 x float> zeroinitializer)
  %.spill.load455 = load i64, ptr %.spill98, align 4
  %.splatinsert456 = insertelement <8 x i64> poison, i64 %.spill.load455, i64 0
  %.splat457 = shufflevector <8 x i64> %.splatinsert456, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load458 = load <8 x i64>, ptr %.spill105, align 64
  %541 = add <8 x i64> %.splat457, %.spill.load458
  %542 = mul <8 x i64> %541, splat (i64 48)
  %.state459 = load <8 x i64>, ptr %.slot107, align 64
  %543 = add <8 x i64> %542, %.state459
  %tile_snapshot.spill.load460 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %544 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load460, 0
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load460, 1
  %546 = mul <8 x i64> %543, splat (i64 32)
  %547 = add <8 x i64> %545, %546
  %548 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %544, 0
  %549 = insertvalue { <8 x ptr>, <8 x i64> } %548, <8 x i64> %547, 1
  %550 = extractvalue { <8 x ptr>, <8 x i64> } %549, 0
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %549, 1
  %552 = getelementptr i8, <8 x ptr> %550, <8 x i64> %551
  %553 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %552, <8 x i1> %522, <8 x float> zeroinitializer)
  %.spill.load461 = load <8 x i64>, ptr %.spill100, align 64
  %554 = add <8 x i64> zeroinitializer, %.spill.load461
  %555 = mul <8 x i64> %554, splat (i64 48)
  %.state462 = load <8 x i64>, ptr %.slot107, align 64
  %556 = add <8 x i64> %555, %.state462
  %tile_snapshot.spill.load463 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill86, align 64
  %557 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load463, 0
  %558 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load463, 1
  %559 = mul <8 x i64> %556, splat (i64 32)
  %560 = add <8 x i64> %558, %559
  %561 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %557, 0
  %562 = insertvalue { <8 x ptr>, <8 x i64> } %561, <8 x i64> %560, 1
  %563 = extractvalue { <8 x ptr>, <8 x i64> } %562, 0
  %564 = extractvalue { <8 x ptr>, <8 x i64> } %562, 1
  %565 = getelementptr i8, <8 x ptr> %563, <8 x i64> %564
  %566 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %565, <8 x i1> %522, <8 x float> zeroinitializer)
  %.spill.load464 = load <8 x i64>, ptr %.spill103, align 64
  %567 = add <8 x i64> zeroinitializer, %.spill.load464
  %568 = mul <8 x i64> %567, splat (i64 48)
  %.state465 = load <8 x i64>, ptr %.slot107, align 64
  %569 = add <8 x i64> %568, %.state465
  %tile_snapshot.spill.load466 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill86, align 64
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load466, 0
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load466, 1
  %572 = mul <8 x i64> %569, splat (i64 32)
  %573 = add <8 x i64> %571, %572
  %574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %570, 0
  %575 = insertvalue { <8 x ptr>, <8 x i64> } %574, <8 x i64> %573, 1
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %575, 0
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %575, 1
  %578 = getelementptr i8, <8 x ptr> %576, <8 x i64> %577
  %579 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %578, <8 x i1> %522, <8 x float> zeroinitializer)
  %580 = fmul <8 x float> %540, %566
  %.state467 = load <8 x float>, ptr %.slot108, align 32
  %581 = fadd <8 x float> %.state467, %580
  %582 = fmul <8 x float> %540, %579
  %.state468 = load <8 x float>, ptr %.slot109, align 32
  %583 = fadd <8 x float> %.state468, %582
  %584 = fmul <8 x float> %553, %566
  %.state469 = load <8 x float>, ptr %.slot110, align 32
  %585 = fadd <8 x float> %.state469, %584
  %586 = fmul <8 x float> %553, %579
  %.state470 = load <8 x float>, ptr %.slot111, align 32
  %587 = fadd <8 x float> %.state470, %586
  %.state471 = load <8 x i64>, ptr %.slot107, align 64
  %588 = add <8 x i64> %.state471, splat (i64 1)
  %589 = load <8 x i64>, ptr %.slot107, align 64
  %590 = select <8 x i1> %522, <8 x i64> %588, <8 x i64> %589
  store <8 x i64> %590, ptr %.slot107, align 64
  %591 = load <8 x float>, ptr %.slot108, align 32
  %592 = select <8 x i1> %522, <8 x float> %581, <8 x float> %591
  store <8 x float> %592, ptr %.slot108, align 32
  %593 = load <8 x float>, ptr %.slot109, align 32
  %594 = select <8 x i1> %522, <8 x float> %583, <8 x float> %593
  store <8 x float> %594, ptr %.slot109, align 32
  %595 = load <8 x float>, ptr %.slot110, align 32
  %596 = select <8 x i1> %522, <8 x float> %585, <8 x float> %595
  store <8 x float> %596, ptr %.slot110, align 32
  %597 = load <8 x float>, ptr %.slot111, align 32
  %598 = select <8 x i1> %522, <8 x float> %587, <8 x float> %597
  store <8 x float> %598, ptr %.slot111, align 32
  store <8 x i1> %522, ptr %current.mask, align 1
  %599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %522)
  br i1 %599, label %schedule.25, label %scheduler.loop

schedule.27:                                      ; preds = %varying.coherent.false448, %scheduler.dispatch.route
  %600 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token474 = load i32, ptr %current.token, align 4
  %convergence.token.present475 = icmp ne i32 %convergence.current.token474, 0
  br i1 %convergence.token.present475, label %convergence.cascade472, label %convergence.cascade.exit473

schedule.28:                                      ; preds = %varying.coherent.false437, %scheduler.dispatch.route
  %601 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token504 = load i32, ptr %current.token, align 4
  %convergence.token.present505 = icmp ne i32 %convergence.current.token504, 0
  br i1 %convergence.token.present505, label %convergence.cascade502, label %convergence.cascade.exit503

schedule.29:                                      ; preds = %varying.coherent.false427, %scheduler.dispatch.route
  %602 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token522 = load i32, ptr %current.token, align 4
  %convergence.token.present523 = icmp ne i32 %convergence.current.token522, 0
  br i1 %convergence.token.present523, label %convergence.cascade520, label %convergence.cascade.exit521

schedule.30:                                      ; preds = %schedule.31, %convergence.target.29.ready, %scheduler.dispatch.route
  %603 = load <8 x i1>, ptr %current.mask, align 1
  %604 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %603)
  %605 = bitcast <8 x i1> %603 to i8
  %606 = call i8 @llvm.cttz.i8(i8 %605, i1 false)
  %607 = zext i8 %606 to i32
  %608 = select i1 %604, i32 %607, i32 0
  %.state607 = load <8 x i64>, ptr %.slot116, align 64
  %609 = icmp slt <8 x i64> %.state607, splat (i64 128)
  %610 = and <8 x i1> %603, %609
  %611 = xor <8 x i1> %609, splat (i1 true)
  %612 = and <8 x i1> %603, %611
  %613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %610)
  %614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %612)
  %615 = and i1 %613, %614
  br i1 %615, label %varying.divergent608, label %varying.coherent609

schedule.31:                                      ; preds = %varying.coherent.true614, %scheduler.dispatch.route
  %616 = load <8 x i1>, ptr %current.mask, align 1
  %617 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %616)
  %618 = bitcast <8 x i1> %616 to i8
  %619 = call i8 @llvm.cttz.i8(i8 %618, i1 false)
  %620 = zext i8 %619 to i32
  %621 = select i1 %617, i32 %620, i32 0
  %.state616 = load <8 x i64>, ptr %.slot116, align 64
  %622 = select <8 x i1> %616, <8 x i64> %.state616, <8 x i64> zeroinitializer
  %623 = select <8 x i1> %616, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %624 = srem <8 x i64> %622, %623
  %.state617 = load <8 x i64>, ptr %.slot116, align 64
  %625 = select <8 x i1> %616, <8 x i64> %.state617, <8 x i64> zeroinitializer
  %626 = select <8 x i1> %616, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %627 = sdiv <8 x i64> %625, %626
  %628 = add <8 x i64> zeroinitializer, %627
  %tile_snapshot.spill.load618 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load618, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load618, 1
  %631 = add <8 x i64> %630, %628
  %632 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %629, 0
  %633 = insertvalue { <8 x ptr>, <8 x i64> } %632, <8 x i64> %631, 1
  %634 = extractvalue { <8 x ptr>, <8 x i64> } %633, 0
  %635 = extractvalue { <8 x ptr>, <8 x i64> } %633, 1
  %636 = getelementptr i8, <8 x ptr> %634, <8 x i64> %635
  %637 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %636, <8 x i1> %616, <8 x i8> zeroinitializer)
  %638 = icmp ne <8 x i8> %637, zeroinitializer
  %639 = mul <8 x i64> %628, splat (i64 8)
  %640 = add <8 x i64> %639, %624
  %641 = select <8 x i1> %616, <8 x i64> %640, <8 x i64> zeroinitializer
  %642 = select <8 x i1> %616, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %643 = srem <8 x i64> %641, %642
  %644 = select <8 x i1> %616, <8 x i64> %640, <8 x i64> zeroinitializer
  %645 = select <8 x i1> %616, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %646 = sdiv <8 x i64> %644, %645
  %647 = add <8 x i64> zeroinitializer, %646
  %tile_snapshot.spill.load619 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill113, align 64
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load619, 0
  %649 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load619, 1
  %650 = mul <8 x i64> %647, splat (i64 64)
  %651 = add <8 x i64> %649, %650
  %652 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %648, 0
  %653 = insertvalue { <8 x ptr>, <8 x i64> } %652, <8 x i64> %651, 1
  %654 = extractvalue { <8 x ptr>, <8 x i64> } %653, 0
  %655 = extractvalue { <8 x ptr>, <8 x i64> } %653, 1
  %656 = getelementptr i8, <8 x ptr> %654, <8 x i64> %655
  %657 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %656, <8 x i1> %616, <8 x i64> zeroinitializer)
  %658 = add <8 x i64> zeroinitializer, %643
  %tile_snapshot.spill.load620 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %659 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load620, 0
  %660 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load620, 1
  %661 = mul <8 x i64> %658, splat (i64 64)
  %662 = add <8 x i64> %660, %661
  %663 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %659, 0
  %664 = insertvalue { <8 x ptr>, <8 x i64> } %663, <8 x i64> %662, 1
  %665 = extractvalue { <8 x ptr>, <8 x i64> } %664, 0
  %666 = extractvalue { <8 x ptr>, <8 x i64> } %664, 1
  %667 = getelementptr i8, <8 x ptr> %665, <8 x i64> %666
  %668 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %667, <8 x i1> %616, <8 x i64> zeroinitializer)
  %669 = icmp sle <8 x i64> %657, %668
  %670 = and <8 x i1> %638, %669
  %tile_snapshot.spill.load621 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %671 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load621, 0
  %672 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load621, 1
  %.state622 = load <8 x i64>, ptr %.slot116, align 64
  %673 = add <8 x i64> %672, %.state622
  %674 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %671, 0
  %675 = insertvalue { <8 x ptr>, <8 x i64> } %674, <8 x i64> %673, 1
  %676 = extractvalue { <8 x ptr>, <8 x i64> } %675, 0
  %677 = extractvalue { <8 x ptr>, <8 x i64> } %675, 1
  %678 = getelementptr i8, <8 x ptr> %676, <8 x i64> %677
  %679 = zext <8 x i1> %670 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %679, <8 x ptr> align 1 %678, <8 x i1> %616)
  %.state623 = load <8 x i64>, ptr %.slot116, align 64
  %680 = add <8 x i64> %.state623, splat (i64 1)
  %681 = load <8 x i64>, ptr %.slot116, align 64
  %682 = select <8 x i1> %616, <8 x i64> %680, <8 x i64> %681
  store <8 x i64> %682, ptr %.slot116, align 64
  store <8 x i1> %616, ptr %current.mask, align 1
  %683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %616)
  br i1 %683, label %schedule.30, label %scheduler.loop

schedule.32:                                      ; preds = %varying.coherent.false615, %scheduler.dispatch.route
  %684 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token626 = load i32, ptr %current.token, align 4
  %convergence.token.present627 = icmp ne i32 %convergence.current.token626, 0
  br i1 %convergence.token.present627, label %convergence.cascade624, label %convergence.cascade.exit625

schedule.33:                                      ; preds = %schedule.34, %convergence.target.32.ready, %scheduler.dispatch.route
  %685 = load <8 x i1>, ptr %current.mask, align 1
  %686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %685)
  %687 = bitcast <8 x i1> %685 to i8
  %688 = call i8 @llvm.cttz.i8(i8 %687, i1 false)
  %689 = zext i8 %688 to i32
  %690 = select i1 %686, i32 %689, i32 0
  %.state641 = load <8 x i64>, ptr %.slot118, align 64
  %691 = icmp slt <8 x i64> %.state641, splat (i64 128)
  %692 = and <8 x i1> %685, %691
  %693 = xor <8 x i1> %691, splat (i1 true)
  %694 = and <8 x i1> %685, %693
  %695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %692)
  %696 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %694)
  %697 = and i1 %695, %696
  br i1 %697, label %varying.divergent642, label %varying.coherent643

schedule.34:                                      ; preds = %varying.coherent.true648, %scheduler.dispatch.route
  %698 = load <8 x i1>, ptr %current.mask, align 1
  %699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %698)
  %700 = bitcast <8 x i1> %698 to i8
  %701 = call i8 @llvm.cttz.i8(i8 %700, i1 false)
  %702 = zext i8 %701 to i32
  %703 = select i1 %699, i32 %702, i32 0
  %.state650 = load <8 x i64>, ptr %.slot118, align 64
  %704 = select <8 x i1> %698, <8 x i64> %.state650, <8 x i64> zeroinitializer
  %705 = select <8 x i1> %698, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %706 = srem <8 x i64> %704, %705
  %.state651 = load <8 x i64>, ptr %.slot118, align 64
  %707 = select <8 x i1> %698, <8 x i64> %.state651, <8 x i64> zeroinitializer
  %708 = select <8 x i1> %698, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %709 = sdiv <8 x i64> %707, %708
  %710 = add <8 x i64> zeroinitializer, %706
  %711 = mul <8 x i64> %710, splat (i64 8)
  %712 = add <8 x i64> %711, %709
  %tile_snapshot.spill.load652 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %713 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load652, 0
  %714 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load652, 1
  %715 = add <8 x i64> %714, %712
  %716 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %713, 0
  %717 = insertvalue { <8 x ptr>, <8 x i64> } %716, <8 x i64> %715, 1
  %718 = extractvalue { <8 x ptr>, <8 x i64> } %717, 0
  %719 = extractvalue { <8 x ptr>, <8 x i64> } %717, 1
  %720 = getelementptr i8, <8 x ptr> %718, <8 x i64> %719
  %721 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %720, <8 x i1> %698, <8 x i8> zeroinitializer)
  %722 = icmp ne <8 x i8> %721, zeroinitializer
  %723 = add <8 x i64> zeroinitializer, %709
  %724 = mul <8 x i64> %723, splat (i64 16)
  %725 = add <8 x i64> %724, %706
  %726 = select <8 x i1> %698, <8 x i64> %725, <8 x i64> zeroinitializer
  %727 = select <8 x i1> %698, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %728 = srem <8 x i64> %726, %727
  %729 = select <8 x i1> %698, <8 x i64> %725, <8 x i64> zeroinitializer
  %730 = select <8 x i1> %698, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %731 = sdiv <8 x i64> %729, %730
  %732 = add <8 x i64> zeroinitializer, %731
  %733 = mul <8 x i64> %732, splat (i64 16)
  %734 = add <8 x i64> %733, %728
  %tile_snapshot.spill.load653 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %735 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load653, 0
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load653, 1
  %737 = mul <8 x i64> %734, splat (i64 32)
  %738 = add <8 x i64> %736, %737
  %739 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %735, 0
  %740 = insertvalue { <8 x ptr>, <8 x i64> } %739, <8 x i64> %738, 1
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %740, 0
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %740, 1
  %743 = getelementptr i8, <8 x ptr> %741, <8 x i64> %742
  %744 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %743, <8 x i1> %698, <8 x float> zeroinitializer)
  %745 = fmul <8 x float> %744, splat (float 0x3FC279A740000000)
  %746 = select <8 x i1> %722, <8 x float> %745, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load654 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %747 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load654, 0
  %748 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load654, 1
  %.state655 = load <8 x i64>, ptr %.slot118, align 64
  %749 = mul <8 x i64> %.state655, splat (i64 32)
  %750 = add <8 x i64> %748, %749
  %751 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %747, 0
  %752 = insertvalue { <8 x ptr>, <8 x i64> } %751, <8 x i64> %750, 1
  %753 = extractvalue { <8 x ptr>, <8 x i64> } %752, 0
  %754 = extractvalue { <8 x ptr>, <8 x i64> } %752, 1
  %755 = getelementptr i8, <8 x ptr> %753, <8 x i64> %754
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %746, <8 x ptr> align 1 %755, <8 x i1> %698)
  %.state656 = load <8 x i64>, ptr %.slot118, align 64
  %756 = add <8 x i64> %.state656, splat (i64 1)
  %757 = load <8 x i64>, ptr %.slot118, align 64
  %758 = select <8 x i1> %698, <8 x i64> %756, <8 x i64> %757
  store <8 x i64> %758, ptr %.slot118, align 64
  store <8 x i1> %698, ptr %current.mask, align 1
  %759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %698)
  br i1 %759, label %schedule.33, label %scheduler.loop

schedule.35:                                      ; preds = %varying.coherent.false649, %scheduler.dispatch.route
  %760 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token659 = load i32, ptr %current.token, align 4
  %convergence.token.present660 = icmp ne i32 %convergence.current.token659, 0
  br i1 %convergence.token.present660, label %convergence.cascade657, label %convergence.cascade.exit658

schedule.36:                                      ; preds = %schedule.37, %convergence.target.35.ready, %scheduler.dispatch.route
  %761 = load <8 x i1>, ptr %current.mask, align 1
  %762 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %761)
  %763 = bitcast <8 x i1> %761 to i8
  %764 = call i8 @llvm.cttz.i8(i8 %763, i1 false)
  %765 = zext i8 %764 to i32
  %766 = select i1 %762, i32 %765, i32 0
  %.state674 = load <8 x i64>, ptr %.slot119, align 64
  %767 = icmp slt <8 x i64> %.state674, splat (i64 16)
  %768 = and <8 x i1> %761, %767
  %769 = xor <8 x i1> %767, splat (i1 true)
  %770 = and <8 x i1> %761, %769
  %771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %768)
  %772 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %770)
  %773 = and i1 %771, %772
  br i1 %773, label %varying.divergent675, label %varying.coherent676

schedule.37:                                      ; preds = %varying.coherent.true681, %scheduler.dispatch.route
  %774 = load <8 x i1>, ptr %current.mask, align 1
  %775 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %774)
  %776 = bitcast <8 x i1> %774 to i8
  %777 = call i8 @llvm.cttz.i8(i8 %776, i1 false)
  %778 = zext i8 %777 to i32
  %779 = select i1 %775, i32 %778, i32 0
  %.state683 = load <8 x i64>, ptr %.slot119, align 64
  %780 = select <8 x i1> %774, <8 x i64> %.state683, <8 x i64> zeroinitializer
  %781 = select <8 x i1> %774, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %782 = sdiv <8 x i64> %780, %781
  %783 = add <8 x i64> zeroinitializer, %782
  %tile_snapshot.spill.load684 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %784 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load684, 0
  %785 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load684, 1
  %786 = mul <8 x i64> %783, splat (i64 32)
  %787 = add <8 x i64> %785, %786
  %788 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %784, 0
  %789 = insertvalue { <8 x ptr>, <8 x i64> } %788, <8 x i64> %787, 1
  %790 = extractvalue { <8 x ptr>, <8 x i64> } %789, 0
  %791 = extractvalue { <8 x ptr>, <8 x i64> } %789, 1
  %792 = getelementptr i8, <8 x ptr> %790, <8 x i64> %791
  %793 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %792, <8 x i1> %774, <8 x float> zeroinitializer)
  %.state685 = load <8 x float>, ptr %.slot120, align 32
  %794 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state685, <8 x float> %793)
  %.state686 = load <8 x i64>, ptr %.slot119, align 64
  %795 = add <8 x i64> %.state686, splat (i64 1)
  %796 = load <8 x i64>, ptr %.slot119, align 64
  %797 = select <8 x i1> %774, <8 x i64> %795, <8 x i64> %796
  store <8 x i64> %797, ptr %.slot119, align 64
  %798 = load <8 x float>, ptr %.slot120, align 32
  %799 = select <8 x i1> %774, <8 x float> %794, <8 x float> %798
  store <8 x float> %799, ptr %.slot120, align 32
  store <8 x i1> %774, ptr %current.mask, align 1
  %800 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %774)
  br i1 %800, label %schedule.36, label %scheduler.loop

schedule.38:                                      ; preds = %varying.coherent.false682, %scheduler.dispatch.route
  %801 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token689 = load i32, ptr %current.token, align 4
  %convergence.token.present690 = icmp ne i32 %convergence.current.token689, 0
  br i1 %convergence.token.present690, label %convergence.cascade687, label %convergence.cascade.exit688

schedule.39:                                      ; preds = %schedule.40, %convergence.target.38.ready, %scheduler.dispatch.route
  %802 = load <8 x i1>, ptr %current.mask, align 1
  %803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %802)
  %804 = bitcast <8 x i1> %802 to i8
  %805 = call i8 @llvm.cttz.i8(i8 %804, i1 false)
  %806 = zext i8 %805 to i32
  %807 = select i1 %803, i32 %806, i32 0
  %.state704 = load <8 x i64>, ptr %.slot121, align 64
  %808 = icmp slt <8 x i64> %.state704, splat (i64 16)
  %809 = and <8 x i1> %802, %808
  %810 = xor <8 x i1> %808, splat (i1 true)
  %811 = and <8 x i1> %802, %810
  %812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %809)
  %813 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %811)
  %814 = and i1 %812, %813
  br i1 %814, label %varying.divergent705, label %varying.coherent706

schedule.40:                                      ; preds = %varying.coherent.true711, %scheduler.dispatch.route
  %815 = load <8 x i1>, ptr %current.mask, align 1
  %816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %815)
  %817 = bitcast <8 x i1> %815 to i8
  %818 = call i8 @llvm.cttz.i8(i8 %817, i1 false)
  %819 = zext i8 %818 to i32
  %820 = select i1 %816, i32 %819, i32 0
  %.state713 = load <8 x i64>, ptr %.slot121, align 64
  %821 = select <8 x i1> %815, <8 x i64> %.state713, <8 x i64> zeroinitializer
  %822 = select <8 x i1> %815, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %823 = sdiv <8 x i64> %821, %822
  %824 = add <8 x i64> splat (i64 16), %823
  %tile_snapshot.spill.load714 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load714, 0
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load714, 1
  %827 = mul <8 x i64> %824, splat (i64 32)
  %828 = add <8 x i64> %826, %827
  %829 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %825, 0
  %830 = insertvalue { <8 x ptr>, <8 x i64> } %829, <8 x i64> %828, 1
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %830, 0
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %830, 1
  %833 = getelementptr i8, <8 x ptr> %831, <8 x i64> %832
  %834 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %833, <8 x i1> %815, <8 x float> zeroinitializer)
  %.state715 = load <8 x float>, ptr %.slot122, align 32
  %835 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state715, <8 x float> %834)
  %.state716 = load <8 x i64>, ptr %.slot121, align 64
  %836 = add <8 x i64> %.state716, splat (i64 1)
  %837 = load <8 x i64>, ptr %.slot121, align 64
  %838 = select <8 x i1> %815, <8 x i64> %836, <8 x i64> %837
  store <8 x i64> %838, ptr %.slot121, align 64
  %839 = load <8 x float>, ptr %.slot122, align 32
  %840 = select <8 x i1> %815, <8 x float> %835, <8 x float> %839
  store <8 x float> %840, ptr %.slot122, align 32
  store <8 x i1> %815, ptr %current.mask, align 1
  %841 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %815)
  br i1 %841, label %schedule.39, label %scheduler.loop

schedule.41:                                      ; preds = %varying.coherent.false712, %scheduler.dispatch.route
  %842 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token719 = load i32, ptr %current.token, align 4
  %convergence.token.present720 = icmp ne i32 %convergence.current.token719, 0
  br i1 %convergence.token.present720, label %convergence.cascade717, label %convergence.cascade.exit718

schedule.42:                                      ; preds = %schedule.43, %convergence.target.41.ready, %scheduler.dispatch.route
  %843 = load <8 x i1>, ptr %current.mask, align 1
  %844 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %843)
  %845 = bitcast <8 x i1> %843 to i8
  %846 = call i8 @llvm.cttz.i8(i8 %845, i1 false)
  %847 = zext i8 %846 to i32
  %848 = select i1 %844, i32 %847, i32 0
  %.state734 = load <8 x i64>, ptr %.slot123, align 64
  %849 = icmp slt <8 x i64> %.state734, splat (i64 16)
  %850 = and <8 x i1> %843, %849
  %851 = xor <8 x i1> %849, splat (i1 true)
  %852 = and <8 x i1> %843, %851
  %853 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %850)
  %854 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %852)
  %855 = and i1 %853, %854
  br i1 %855, label %varying.divergent735, label %varying.coherent736

schedule.43:                                      ; preds = %varying.coherent.true741, %scheduler.dispatch.route
  %856 = load <8 x i1>, ptr %current.mask, align 1
  %857 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %856)
  %858 = bitcast <8 x i1> %856 to i8
  %859 = call i8 @llvm.cttz.i8(i8 %858, i1 false)
  %860 = zext i8 %859 to i32
  %861 = select i1 %857, i32 %860, i32 0
  %.state743 = load <8 x i64>, ptr %.slot123, align 64
  %862 = select <8 x i1> %856, <8 x i64> %.state743, <8 x i64> zeroinitializer
  %863 = select <8 x i1> %856, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %864 = sdiv <8 x i64> %862, %863
  %865 = add <8 x i64> splat (i64 32), %864
  %tile_snapshot.spill.load744 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %866 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load744, 0
  %867 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load744, 1
  %868 = mul <8 x i64> %865, splat (i64 32)
  %869 = add <8 x i64> %867, %868
  %870 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %866, 0
  %871 = insertvalue { <8 x ptr>, <8 x i64> } %870, <8 x i64> %869, 1
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %871, 0
  %873 = extractvalue { <8 x ptr>, <8 x i64> } %871, 1
  %874 = getelementptr i8, <8 x ptr> %872, <8 x i64> %873
  %875 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %874, <8 x i1> %856, <8 x float> zeroinitializer)
  %.state745 = load <8 x float>, ptr %.slot124, align 32
  %876 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state745, <8 x float> %875)
  %.state746 = load <8 x i64>, ptr %.slot123, align 64
  %877 = add <8 x i64> %.state746, splat (i64 1)
  %878 = load <8 x i64>, ptr %.slot123, align 64
  %879 = select <8 x i1> %856, <8 x i64> %877, <8 x i64> %878
  store <8 x i64> %879, ptr %.slot123, align 64
  %880 = load <8 x float>, ptr %.slot124, align 32
  %881 = select <8 x i1> %856, <8 x float> %876, <8 x float> %880
  store <8 x float> %881, ptr %.slot124, align 32
  store <8 x i1> %856, ptr %current.mask, align 1
  %882 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %856)
  br i1 %882, label %schedule.42, label %scheduler.loop

schedule.44:                                      ; preds = %varying.coherent.false742, %scheduler.dispatch.route
  %883 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token749 = load i32, ptr %current.token, align 4
  %convergence.token.present750 = icmp ne i32 %convergence.current.token749, 0
  br i1 %convergence.token.present750, label %convergence.cascade747, label %convergence.cascade.exit748

schedule.45:                                      ; preds = %schedule.46, %convergence.target.44.ready, %scheduler.dispatch.route
  %884 = load <8 x i1>, ptr %current.mask, align 1
  %885 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %884)
  %886 = bitcast <8 x i1> %884 to i8
  %887 = call i8 @llvm.cttz.i8(i8 %886, i1 false)
  %888 = zext i8 %887 to i32
  %889 = select i1 %885, i32 %888, i32 0
  %.state764 = load <8 x i64>, ptr %.slot125, align 64
  %890 = icmp slt <8 x i64> %.state764, splat (i64 16)
  %891 = and <8 x i1> %884, %890
  %892 = xor <8 x i1> %890, splat (i1 true)
  %893 = and <8 x i1> %884, %892
  %894 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %891)
  %895 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %893)
  %896 = and i1 %894, %895
  br i1 %896, label %varying.divergent765, label %varying.coherent766

schedule.46:                                      ; preds = %varying.coherent.true771, %scheduler.dispatch.route
  %897 = load <8 x i1>, ptr %current.mask, align 1
  %898 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %897)
  %899 = bitcast <8 x i1> %897 to i8
  %900 = call i8 @llvm.cttz.i8(i8 %899, i1 false)
  %901 = zext i8 %900 to i32
  %902 = select i1 %898, i32 %901, i32 0
  %.state773 = load <8 x i64>, ptr %.slot125, align 64
  %903 = select <8 x i1> %897, <8 x i64> %.state773, <8 x i64> zeroinitializer
  %904 = select <8 x i1> %897, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %905 = sdiv <8 x i64> %903, %904
  %906 = add <8 x i64> splat (i64 48), %905
  %tile_snapshot.spill.load774 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %907 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load774, 0
  %908 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load774, 1
  %909 = mul <8 x i64> %906, splat (i64 32)
  %910 = add <8 x i64> %908, %909
  %911 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %907, 0
  %912 = insertvalue { <8 x ptr>, <8 x i64> } %911, <8 x i64> %910, 1
  %913 = extractvalue { <8 x ptr>, <8 x i64> } %912, 0
  %914 = extractvalue { <8 x ptr>, <8 x i64> } %912, 1
  %915 = getelementptr i8, <8 x ptr> %913, <8 x i64> %914
  %916 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %915, <8 x i1> %897, <8 x float> zeroinitializer)
  %.state775 = load <8 x float>, ptr %.slot126, align 32
  %917 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state775, <8 x float> %916)
  %.state776 = load <8 x i64>, ptr %.slot125, align 64
  %918 = add <8 x i64> %.state776, splat (i64 1)
  %919 = load <8 x i64>, ptr %.slot125, align 64
  %920 = select <8 x i1> %897, <8 x i64> %918, <8 x i64> %919
  store <8 x i64> %920, ptr %.slot125, align 64
  %921 = load <8 x float>, ptr %.slot126, align 32
  %922 = select <8 x i1> %897, <8 x float> %917, <8 x float> %921
  store <8 x float> %922, ptr %.slot126, align 32
  store <8 x i1> %897, ptr %current.mask, align 1
  %923 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %897)
  br i1 %923, label %schedule.45, label %scheduler.loop

schedule.47:                                      ; preds = %varying.coherent.false772, %scheduler.dispatch.route
  %924 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token779 = load i32, ptr %current.token, align 4
  %convergence.token.present780 = icmp ne i32 %convergence.current.token779, 0
  br i1 %convergence.token.present780, label %convergence.cascade777, label %convergence.cascade.exit778

schedule.48:                                      ; preds = %schedule.49, %convergence.target.47.ready, %scheduler.dispatch.route
  %925 = load <8 x i1>, ptr %current.mask, align 1
  %926 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %925)
  %927 = bitcast <8 x i1> %925 to i8
  %928 = call i8 @llvm.cttz.i8(i8 %927, i1 false)
  %929 = zext i8 %928 to i32
  %930 = select i1 %926, i32 %929, i32 0
  %.state794 = load <8 x i64>, ptr %.slot127, align 64
  %931 = icmp slt <8 x i64> %.state794, splat (i64 16)
  %932 = and <8 x i1> %925, %931
  %933 = xor <8 x i1> %931, splat (i1 true)
  %934 = and <8 x i1> %925, %933
  %935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %932)
  %936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %934)
  %937 = and i1 %935, %936
  br i1 %937, label %varying.divergent795, label %varying.coherent796

schedule.49:                                      ; preds = %varying.coherent.true801, %scheduler.dispatch.route
  %938 = load <8 x i1>, ptr %current.mask, align 1
  %939 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %938)
  %940 = bitcast <8 x i1> %938 to i8
  %941 = call i8 @llvm.cttz.i8(i8 %940, i1 false)
  %942 = zext i8 %941 to i32
  %943 = select i1 %939, i32 %942, i32 0
  %.state803 = load <8 x i64>, ptr %.slot127, align 64
  %944 = select <8 x i1> %938, <8 x i64> %.state803, <8 x i64> zeroinitializer
  %945 = select <8 x i1> %938, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %946 = sdiv <8 x i64> %944, %945
  %947 = add <8 x i64> splat (i64 64), %946
  %tile_snapshot.spill.load804 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %948 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 0
  %949 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 1
  %950 = mul <8 x i64> %947, splat (i64 32)
  %951 = add <8 x i64> %949, %950
  %952 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %948, 0
  %953 = insertvalue { <8 x ptr>, <8 x i64> } %952, <8 x i64> %951, 1
  %954 = extractvalue { <8 x ptr>, <8 x i64> } %953, 0
  %955 = extractvalue { <8 x ptr>, <8 x i64> } %953, 1
  %956 = getelementptr i8, <8 x ptr> %954, <8 x i64> %955
  %957 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %956, <8 x i1> %938, <8 x float> zeroinitializer)
  %.state805 = load <8 x float>, ptr %.slot128, align 32
  %958 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state805, <8 x float> %957)
  %.state806 = load <8 x i64>, ptr %.slot127, align 64
  %959 = add <8 x i64> %.state806, splat (i64 1)
  %960 = load <8 x i64>, ptr %.slot127, align 64
  %961 = select <8 x i1> %938, <8 x i64> %959, <8 x i64> %960
  store <8 x i64> %961, ptr %.slot127, align 64
  %962 = load <8 x float>, ptr %.slot128, align 32
  %963 = select <8 x i1> %938, <8 x float> %958, <8 x float> %962
  store <8 x float> %963, ptr %.slot128, align 32
  store <8 x i1> %938, ptr %current.mask, align 1
  %964 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %938)
  br i1 %964, label %schedule.48, label %scheduler.loop

schedule.50:                                      ; preds = %varying.coherent.false802, %scheduler.dispatch.route
  %965 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token809 = load i32, ptr %current.token, align 4
  %convergence.token.present810 = icmp ne i32 %convergence.current.token809, 0
  br i1 %convergence.token.present810, label %convergence.cascade807, label %convergence.cascade.exit808

schedule.51:                                      ; preds = %schedule.52, %convergence.target.50.ready, %scheduler.dispatch.route
  %966 = load <8 x i1>, ptr %current.mask, align 1
  %967 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %966)
  %968 = bitcast <8 x i1> %966 to i8
  %969 = call i8 @llvm.cttz.i8(i8 %968, i1 false)
  %970 = zext i8 %969 to i32
  %971 = select i1 %967, i32 %970, i32 0
  %.state824 = load <8 x i64>, ptr %.slot129, align 64
  %972 = icmp slt <8 x i64> %.state824, splat (i64 16)
  %973 = and <8 x i1> %966, %972
  %974 = xor <8 x i1> %972, splat (i1 true)
  %975 = and <8 x i1> %966, %974
  %976 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %973)
  %977 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %975)
  %978 = and i1 %976, %977
  br i1 %978, label %varying.divergent825, label %varying.coherent826

schedule.52:                                      ; preds = %varying.coherent.true831, %scheduler.dispatch.route
  %979 = load <8 x i1>, ptr %current.mask, align 1
  %980 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %979)
  %981 = bitcast <8 x i1> %979 to i8
  %982 = call i8 @llvm.cttz.i8(i8 %981, i1 false)
  %983 = zext i8 %982 to i32
  %984 = select i1 %980, i32 %983, i32 0
  %.state833 = load <8 x i64>, ptr %.slot129, align 64
  %985 = select <8 x i1> %979, <8 x i64> %.state833, <8 x i64> zeroinitializer
  %986 = select <8 x i1> %979, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %987 = sdiv <8 x i64> %985, %986
  %988 = add <8 x i64> splat (i64 80), %987
  %tile_snapshot.spill.load834 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %989 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load834, 0
  %990 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load834, 1
  %991 = mul <8 x i64> %988, splat (i64 32)
  %992 = add <8 x i64> %990, %991
  %993 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %989, 0
  %994 = insertvalue { <8 x ptr>, <8 x i64> } %993, <8 x i64> %992, 1
  %995 = extractvalue { <8 x ptr>, <8 x i64> } %994, 0
  %996 = extractvalue { <8 x ptr>, <8 x i64> } %994, 1
  %997 = getelementptr i8, <8 x ptr> %995, <8 x i64> %996
  %998 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %997, <8 x i1> %979, <8 x float> zeroinitializer)
  %.state835 = load <8 x float>, ptr %.slot130, align 32
  %999 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state835, <8 x float> %998)
  %.state836 = load <8 x i64>, ptr %.slot129, align 64
  %1000 = add <8 x i64> %.state836, splat (i64 1)
  %1001 = load <8 x i64>, ptr %.slot129, align 64
  %1002 = select <8 x i1> %979, <8 x i64> %1000, <8 x i64> %1001
  store <8 x i64> %1002, ptr %.slot129, align 64
  %1003 = load <8 x float>, ptr %.slot130, align 32
  %1004 = select <8 x i1> %979, <8 x float> %999, <8 x float> %1003
  store <8 x float> %1004, ptr %.slot130, align 32
  store <8 x i1> %979, ptr %current.mask, align 1
  %1005 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %979)
  br i1 %1005, label %schedule.51, label %scheduler.loop

schedule.53:                                      ; preds = %varying.coherent.false832, %scheduler.dispatch.route
  %1006 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token839 = load i32, ptr %current.token, align 4
  %convergence.token.present840 = icmp ne i32 %convergence.current.token839, 0
  br i1 %convergence.token.present840, label %convergence.cascade837, label %convergence.cascade.exit838

schedule.54:                                      ; preds = %schedule.55, %convergence.target.53.ready, %scheduler.dispatch.route
  %1007 = load <8 x i1>, ptr %current.mask, align 1
  %1008 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1007)
  %1009 = bitcast <8 x i1> %1007 to i8
  %1010 = call i8 @llvm.cttz.i8(i8 %1009, i1 false)
  %1011 = zext i8 %1010 to i32
  %1012 = select i1 %1008, i32 %1011, i32 0
  %.state854 = load <8 x i64>, ptr %.slot131, align 64
  %1013 = icmp slt <8 x i64> %.state854, splat (i64 16)
  %1014 = and <8 x i1> %1007, %1013
  %1015 = xor <8 x i1> %1013, splat (i1 true)
  %1016 = and <8 x i1> %1007, %1015
  %1017 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1014)
  %1018 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1016)
  %1019 = and i1 %1017, %1018
  br i1 %1019, label %varying.divergent855, label %varying.coherent856

schedule.55:                                      ; preds = %varying.coherent.true861, %scheduler.dispatch.route
  %1020 = load <8 x i1>, ptr %current.mask, align 1
  %1021 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1020)
  %1022 = bitcast <8 x i1> %1020 to i8
  %1023 = call i8 @llvm.cttz.i8(i8 %1022, i1 false)
  %1024 = zext i8 %1023 to i32
  %1025 = select i1 %1021, i32 %1024, i32 0
  %.state863 = load <8 x i64>, ptr %.slot131, align 64
  %1026 = select <8 x i1> %1020, <8 x i64> %.state863, <8 x i64> zeroinitializer
  %1027 = select <8 x i1> %1020, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1028 = sdiv <8 x i64> %1026, %1027
  %1029 = add <8 x i64> splat (i64 96), %1028
  %tile_snapshot.spill.load864 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load864, 0
  %1031 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load864, 1
  %1032 = mul <8 x i64> %1029, splat (i64 32)
  %1033 = add <8 x i64> %1031, %1032
  %1034 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1030, 0
  %1035 = insertvalue { <8 x ptr>, <8 x i64> } %1034, <8 x i64> %1033, 1
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %1035, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %1035, 1
  %1038 = getelementptr i8, <8 x ptr> %1036, <8 x i64> %1037
  %1039 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1038, <8 x i1> %1020, <8 x float> zeroinitializer)
  %.state865 = load <8 x float>, ptr %.slot132, align 32
  %1040 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state865, <8 x float> %1039)
  %.state866 = load <8 x i64>, ptr %.slot131, align 64
  %1041 = add <8 x i64> %.state866, splat (i64 1)
  %1042 = load <8 x i64>, ptr %.slot131, align 64
  %1043 = select <8 x i1> %1020, <8 x i64> %1041, <8 x i64> %1042
  store <8 x i64> %1043, ptr %.slot131, align 64
  %1044 = load <8 x float>, ptr %.slot132, align 32
  %1045 = select <8 x i1> %1020, <8 x float> %1040, <8 x float> %1044
  store <8 x float> %1045, ptr %.slot132, align 32
  store <8 x i1> %1020, ptr %current.mask, align 1
  %1046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1020)
  br i1 %1046, label %schedule.54, label %scheduler.loop

schedule.56:                                      ; preds = %varying.coherent.false862, %scheduler.dispatch.route
  %1047 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token869 = load i32, ptr %current.token, align 4
  %convergence.token.present870 = icmp ne i32 %convergence.current.token869, 0
  br i1 %convergence.token.present870, label %convergence.cascade867, label %convergence.cascade.exit868

schedule.57:                                      ; preds = %schedule.58, %convergence.target.56.ready, %scheduler.dispatch.route
  %1048 = load <8 x i1>, ptr %current.mask, align 1
  %1049 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1048)
  %1050 = bitcast <8 x i1> %1048 to i8
  %1051 = call i8 @llvm.cttz.i8(i8 %1050, i1 false)
  %1052 = zext i8 %1051 to i32
  %1053 = select i1 %1049, i32 %1052, i32 0
  %.state884 = load <8 x i64>, ptr %.slot133, align 64
  %1054 = icmp slt <8 x i64> %.state884, splat (i64 16)
  %1055 = and <8 x i1> %1048, %1054
  %1056 = xor <8 x i1> %1054, splat (i1 true)
  %1057 = and <8 x i1> %1048, %1056
  %1058 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1055)
  %1059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1057)
  %1060 = and i1 %1058, %1059
  br i1 %1060, label %varying.divergent885, label %varying.coherent886

schedule.58:                                      ; preds = %varying.coherent.true891, %scheduler.dispatch.route
  %1061 = load <8 x i1>, ptr %current.mask, align 1
  %1062 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1061)
  %1063 = bitcast <8 x i1> %1061 to i8
  %1064 = call i8 @llvm.cttz.i8(i8 %1063, i1 false)
  %1065 = zext i8 %1064 to i32
  %1066 = select i1 %1062, i32 %1065, i32 0
  %.state893 = load <8 x i64>, ptr %.slot133, align 64
  %1067 = select <8 x i1> %1061, <8 x i64> %.state893, <8 x i64> zeroinitializer
  %1068 = select <8 x i1> %1061, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1069 = sdiv <8 x i64> %1067, %1068
  %1070 = add <8 x i64> splat (i64 112), %1069
  %tile_snapshot.spill.load894 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %1071 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load894, 0
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load894, 1
  %1073 = mul <8 x i64> %1070, splat (i64 32)
  %1074 = add <8 x i64> %1072, %1073
  %1075 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1071, 0
  %1076 = insertvalue { <8 x ptr>, <8 x i64> } %1075, <8 x i64> %1074, 1
  %1077 = extractvalue { <8 x ptr>, <8 x i64> } %1076, 0
  %1078 = extractvalue { <8 x ptr>, <8 x i64> } %1076, 1
  %1079 = getelementptr i8, <8 x ptr> %1077, <8 x i64> %1078
  %1080 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1079, <8 x i1> %1061, <8 x float> zeroinitializer)
  %.state895 = load <8 x float>, ptr %.slot134, align 32
  %1081 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state895, <8 x float> %1080)
  %.state896 = load <8 x i64>, ptr %.slot133, align 64
  %1082 = add <8 x i64> %.state896, splat (i64 1)
  %1083 = load <8 x i64>, ptr %.slot133, align 64
  %1084 = select <8 x i1> %1061, <8 x i64> %1082, <8 x i64> %1083
  store <8 x i64> %1084, ptr %.slot133, align 64
  %1085 = load <8 x float>, ptr %.slot134, align 32
  %1086 = select <8 x i1> %1061, <8 x float> %1081, <8 x float> %1085
  store <8 x float> %1086, ptr %.slot134, align 32
  store <8 x i1> %1061, ptr %current.mask, align 1
  %1087 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1061)
  br i1 %1087, label %schedule.57, label %scheduler.loop

schedule.59:                                      ; preds = %varying.coherent.false892, %scheduler.dispatch.route
  %1088 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token899 = load i32, ptr %current.token, align 4
  %convergence.token.present900 = icmp ne i32 %convergence.current.token899, 0
  br i1 %convergence.token.present900, label %convergence.cascade897, label %convergence.cascade.exit898

schedule.60:                                      ; preds = %schedule.61, %convergence.target.59.ready, %scheduler.dispatch.route
  %1089 = load <8 x i1>, ptr %current.mask, align 1
  %1090 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1089)
  %1091 = bitcast <8 x i1> %1089 to i8
  %1092 = call i8 @llvm.cttz.i8(i8 %1091, i1 false)
  %1093 = zext i8 %1092 to i32
  %1094 = select i1 %1090, i32 %1093, i32 0
  %.state977 = load <8 x i64>, ptr %.slot154, align 64
  %1095 = icmp slt <8 x i64> %.state977, splat (i64 128)
  %1096 = and <8 x i1> %1089, %1095
  %1097 = xor <8 x i1> %1095, splat (i1 true)
  %1098 = and <8 x i1> %1089, %1097
  %1099 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1096)
  %1100 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1098)
  %1101 = and i1 %1099, %1100
  br i1 %1101, label %varying.divergent978, label %varying.coherent979

schedule.61:                                      ; preds = %varying.coherent.true984, %scheduler.dispatch.route
  %1102 = load <8 x i1>, ptr %current.mask, align 1
  %1103 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1102)
  %1104 = bitcast <8 x i1> %1102 to i8
  %1105 = call i8 @llvm.cttz.i8(i8 %1104, i1 false)
  %1106 = zext i8 %1105 to i32
  %1107 = select i1 %1103, i32 %1106, i32 0
  %.state986 = load <8 x i64>, ptr %.slot154, align 64
  %1108 = select <8 x i1> %1102, <8 x i64> %.state986, <8 x i64> zeroinitializer
  %1109 = select <8 x i1> %1102, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %1110 = srem <8 x i64> %1108, %1109
  %.state987 = load <8 x i64>, ptr %.slot154, align 64
  %1111 = select <8 x i1> %1102, <8 x i64> %.state987, <8 x i64> zeroinitializer
  %1112 = select <8 x i1> %1102, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %1113 = sdiv <8 x i64> %1111, %1112
  %1114 = add <8 x i64> zeroinitializer, %1110
  %1115 = mul <8 x i64> %1114, splat (i64 8)
  %1116 = add <8 x i64> %1115, %1113
  %tile_snapshot.spill.load988 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %1117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load988, 0
  %1118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load988, 1
  %1119 = add <8 x i64> %1118, %1116
  %1120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1117, 0
  %1121 = insertvalue { <8 x ptr>, <8 x i64> } %1120, <8 x i64> %1119, 1
  %1122 = extractvalue { <8 x ptr>, <8 x i64> } %1121, 0
  %1123 = extractvalue { <8 x ptr>, <8 x i64> } %1121, 1
  %1124 = getelementptr i8, <8 x ptr> %1122, <8 x i64> %1123
  %1125 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %1124, <8 x i1> %1102, <8 x i8> zeroinitializer)
  %1126 = icmp ne <8 x i8> %1125, zeroinitializer
  %1127 = add <8 x i64> zeroinitializer, %1113
  %1128 = mul <8 x i64> %1127, splat (i64 16)
  %1129 = add <8 x i64> %1128, %1110
  %1130 = select <8 x i1> %1102, <8 x i64> %1129, <8 x i64> zeroinitializer
  %1131 = select <8 x i1> %1102, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %1132 = srem <8 x i64> %1130, %1131
  %1133 = select <8 x i1> %1102, <8 x i64> %1129, <8 x i64> zeroinitializer
  %1134 = select <8 x i1> %1102, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %1135 = sdiv <8 x i64> %1133, %1134
  %1136 = add <8 x i64> zeroinitializer, %1135
  %1137 = mul <8 x i64> %1136, splat (i64 16)
  %1138 = add <8 x i64> %1137, %1132
  %1139 = select <8 x i1> %1102, <8 x i64> %1138, <8 x i64> zeroinitializer
  %1140 = select <8 x i1> %1102, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %1141 = srem <8 x i64> %1139, %1140
  %1142 = select <8 x i1> %1102, <8 x i64> %1138, <8 x i64> zeroinitializer
  %1143 = select <8 x i1> %1102, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %1144 = sdiv <8 x i64> %1142, %1143
  %1145 = add <8 x i64> zeroinitializer, %1144
  %1146 = mul <8 x i64> %1145, splat (i64 16)
  %1147 = add <8 x i64> %1146, %1141
  %tile_snapshot.spill.load989 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %1148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load989, 0
  %1149 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load989, 1
  %1150 = mul <8 x i64> %1147, splat (i64 32)
  %1151 = add <8 x i64> %1149, %1150
  %1152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1148, 0
  %1153 = insertvalue { <8 x ptr>, <8 x i64> } %1152, <8 x i64> %1151, 1
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %1153, 0
  %1155 = extractvalue { <8 x ptr>, <8 x i64> } %1153, 1
  %1156 = getelementptr i8, <8 x ptr> %1154, <8 x i64> %1155
  %1157 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1156, <8 x i1> %1102, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load990 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill143, align 64
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load990, 0
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load990, 1
  %1160 = mul <8 x i64> %1145, splat (i64 32)
  %1161 = add <8 x i64> %1159, %1160
  %1162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1158, 0
  %1163 = insertvalue { <8 x ptr>, <8 x i64> } %1162, <8 x i64> %1161, 1
  %1164 = extractvalue { <8 x ptr>, <8 x i64> } %1163, 0
  %1165 = extractvalue { <8 x ptr>, <8 x i64> } %1163, 1
  %1166 = getelementptr i8, <8 x ptr> %1164, <8 x i64> %1165
  %1167 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1166, <8 x i1> %1102, <8 x float> zeroinitializer)
  %1168 = fsub <8 x float> %1157, %1167
  %1169 = select <8 x i1> %1102, <8 x float> %1168, <8 x float> zeroinitializer
  %native.exp991 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1169)
  %1170 = select <8 x i1> %1126, <8 x float> %native.exp991, <8 x float> zeroinitializer
  %tile_snapshot.spill.load992 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load992, 0
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load992, 1
  %.state993 = load <8 x i64>, ptr %.slot154, align 64
  %1173 = mul <8 x i64> %.state993, splat (i64 32)
  %1174 = add <8 x i64> %1172, %1173
  %1175 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1171, 0
  %1176 = insertvalue { <8 x ptr>, <8 x i64> } %1175, <8 x i64> %1174, 1
  %1177 = extractvalue { <8 x ptr>, <8 x i64> } %1176, 0
  %1178 = extractvalue { <8 x ptr>, <8 x i64> } %1176, 1
  %1179 = getelementptr i8, <8 x ptr> %1177, <8 x i64> %1178
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1170, <8 x ptr> align 1 %1179, <8 x i1> %1102)
  %.state994 = load <8 x i64>, ptr %.slot154, align 64
  %1180 = add <8 x i64> %.state994, splat (i64 1)
  %1181 = load <8 x i64>, ptr %.slot154, align 64
  %1182 = select <8 x i1> %1102, <8 x i64> %1180, <8 x i64> %1181
  store <8 x i64> %1182, ptr %.slot154, align 64
  store <8 x i1> %1102, ptr %current.mask, align 1
  %1183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1102)
  br i1 %1183, label %schedule.60, label %scheduler.loop

schedule.62:                                      ; preds = %varying.coherent.false985, %scheduler.dispatch.route
  %1184 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token997 = load i32, ptr %current.token, align 4
  %convergence.token.present998 = icmp ne i32 %convergence.current.token997, 0
  br i1 %convergence.token.present998, label %convergence.cascade995, label %convergence.cascade.exit996

schedule.63:                                      ; preds = %schedule.64, %convergence.target.62.ready, %scheduler.dispatch.route
  %1185 = load <8 x i1>, ptr %current.mask, align 1
  %1186 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1185)
  %1187 = bitcast <8 x i1> %1185 to i8
  %1188 = call i8 @llvm.cttz.i8(i8 %1187, i1 false)
  %1189 = zext i8 %1188 to i32
  %1190 = select i1 %1186, i32 %1189, i32 0
  %.state1028 = load <8 x i64>, ptr %.slot163, align 64
  %1191 = icmp slt <8 x i64> %.state1028, splat (i64 16)
  %1192 = and <8 x i1> %1185, %1191
  %1193 = xor <8 x i1> %1191, splat (i1 true)
  %1194 = and <8 x i1> %1185, %1193
  %1195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1192)
  %1196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1194)
  %1197 = and i1 %1195, %1196
  br i1 %1197, label %varying.divergent1029, label %varying.coherent1030

schedule.64:                                      ; preds = %varying.coherent.true1035, %scheduler.dispatch.route
  %1198 = load <8 x i1>, ptr %current.mask, align 1
  %1199 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1198)
  %1200 = bitcast <8 x i1> %1198 to i8
  %1201 = call i8 @llvm.cttz.i8(i8 %1200, i1 false)
  %1202 = zext i8 %1201 to i32
  %1203 = select i1 %1199, i32 %1202, i32 0
  %.state1037 = load <8 x i64>, ptr %.slot163, align 64
  %1204 = select <8 x i1> %1198, <8 x i64> %.state1037, <8 x i64> zeroinitializer
  %1205 = select <8 x i1> %1198, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1206 = sdiv <8 x i64> %1204, %1205
  %1207 = add <8 x i64> zeroinitializer, %1206
  %tile_snapshot.spill.load1038 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1038, 0
  %1209 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1038, 1
  %1210 = mul <8 x i64> %1207, splat (i64 32)
  %1211 = add <8 x i64> %1209, %1210
  %1212 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1208, 0
  %1213 = insertvalue { <8 x ptr>, <8 x i64> } %1212, <8 x i64> %1211, 1
  %1214 = extractvalue { <8 x ptr>, <8 x i64> } %1213, 0
  %1215 = extractvalue { <8 x ptr>, <8 x i64> } %1213, 1
  %1216 = getelementptr i8, <8 x ptr> %1214, <8 x i64> %1215
  %1217 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1216, <8 x i1> %1198, <8 x float> zeroinitializer)
  %.state1039 = load <8 x float>, ptr %.slot164, align 32
  %1218 = fadd <8 x float> %.state1039, %1217
  %.state1040 = load <8 x i64>, ptr %.slot163, align 64
  %1219 = add <8 x i64> %.state1040, splat (i64 1)
  %1220 = load <8 x i64>, ptr %.slot163, align 64
  %1221 = select <8 x i1> %1198, <8 x i64> %1219, <8 x i64> %1220
  store <8 x i64> %1221, ptr %.slot163, align 64
  %1222 = load <8 x float>, ptr %.slot164, align 32
  %1223 = select <8 x i1> %1198, <8 x float> %1218, <8 x float> %1222
  store <8 x float> %1223, ptr %.slot164, align 32
  store <8 x i1> %1198, ptr %current.mask, align 1
  %1224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1198)
  br i1 %1224, label %schedule.63, label %scheduler.loop

schedule.65:                                      ; preds = %varying.coherent.false1036, %scheduler.dispatch.route
  %1225 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1043 = load i32, ptr %current.token, align 4
  %convergence.token.present1044 = icmp ne i32 %convergence.current.token1043, 0
  br i1 %convergence.token.present1044, label %convergence.cascade1041, label %convergence.cascade.exit1042

schedule.66:                                      ; preds = %schedule.67, %convergence.target.65.ready, %scheduler.dispatch.route
  %1226 = load <8 x i1>, ptr %current.mask, align 1
  %1227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1226)
  %1228 = bitcast <8 x i1> %1226 to i8
  %1229 = call i8 @llvm.cttz.i8(i8 %1228, i1 false)
  %1230 = zext i8 %1229 to i32
  %1231 = select i1 %1227, i32 %1230, i32 0
  %.state1058 = load <8 x i64>, ptr %.slot165, align 64
  %1232 = icmp slt <8 x i64> %.state1058, splat (i64 16)
  %1233 = and <8 x i1> %1226, %1232
  %1234 = xor <8 x i1> %1232, splat (i1 true)
  %1235 = and <8 x i1> %1226, %1234
  %1236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1233)
  %1237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1235)
  %1238 = and i1 %1236, %1237
  br i1 %1238, label %varying.divergent1059, label %varying.coherent1060

schedule.67:                                      ; preds = %varying.coherent.true1065, %scheduler.dispatch.route
  %1239 = load <8 x i1>, ptr %current.mask, align 1
  %1240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1239)
  %1241 = bitcast <8 x i1> %1239 to i8
  %1242 = call i8 @llvm.cttz.i8(i8 %1241, i1 false)
  %1243 = zext i8 %1242 to i32
  %1244 = select i1 %1240, i32 %1243, i32 0
  %.state1067 = load <8 x i64>, ptr %.slot165, align 64
  %1245 = select <8 x i1> %1239, <8 x i64> %.state1067, <8 x i64> zeroinitializer
  %1246 = select <8 x i1> %1239, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1247 = sdiv <8 x i64> %1245, %1246
  %1248 = add <8 x i64> splat (i64 16), %1247
  %tile_snapshot.spill.load1068 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1068, 0
  %1250 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1068, 1
  %1251 = mul <8 x i64> %1248, splat (i64 32)
  %1252 = add <8 x i64> %1250, %1251
  %1253 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1249, 0
  %1254 = insertvalue { <8 x ptr>, <8 x i64> } %1253, <8 x i64> %1252, 1
  %1255 = extractvalue { <8 x ptr>, <8 x i64> } %1254, 0
  %1256 = extractvalue { <8 x ptr>, <8 x i64> } %1254, 1
  %1257 = getelementptr i8, <8 x ptr> %1255, <8 x i64> %1256
  %1258 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1257, <8 x i1> %1239, <8 x float> zeroinitializer)
  %.state1069 = load <8 x float>, ptr %.slot166, align 32
  %1259 = fadd <8 x float> %.state1069, %1258
  %.state1070 = load <8 x i64>, ptr %.slot165, align 64
  %1260 = add <8 x i64> %.state1070, splat (i64 1)
  %1261 = load <8 x i64>, ptr %.slot165, align 64
  %1262 = select <8 x i1> %1239, <8 x i64> %1260, <8 x i64> %1261
  store <8 x i64> %1262, ptr %.slot165, align 64
  %1263 = load <8 x float>, ptr %.slot166, align 32
  %1264 = select <8 x i1> %1239, <8 x float> %1259, <8 x float> %1263
  store <8 x float> %1264, ptr %.slot166, align 32
  store <8 x i1> %1239, ptr %current.mask, align 1
  %1265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1239)
  br i1 %1265, label %schedule.66, label %scheduler.loop

schedule.68:                                      ; preds = %varying.coherent.false1066, %scheduler.dispatch.route
  %1266 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1073 = load i32, ptr %current.token, align 4
  %convergence.token.present1074 = icmp ne i32 %convergence.current.token1073, 0
  br i1 %convergence.token.present1074, label %convergence.cascade1071, label %convergence.cascade.exit1072

schedule.69:                                      ; preds = %schedule.70, %convergence.target.68.ready, %scheduler.dispatch.route
  %1267 = load <8 x i1>, ptr %current.mask, align 1
  %1268 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1267)
  %1269 = bitcast <8 x i1> %1267 to i8
  %1270 = call i8 @llvm.cttz.i8(i8 %1269, i1 false)
  %1271 = zext i8 %1270 to i32
  %1272 = select i1 %1268, i32 %1271, i32 0
  %.state1088 = load <8 x i64>, ptr %.slot167, align 64
  %1273 = icmp slt <8 x i64> %.state1088, splat (i64 16)
  %1274 = and <8 x i1> %1267, %1273
  %1275 = xor <8 x i1> %1273, splat (i1 true)
  %1276 = and <8 x i1> %1267, %1275
  %1277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1274)
  %1278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1276)
  %1279 = and i1 %1277, %1278
  br i1 %1279, label %varying.divergent1089, label %varying.coherent1090

schedule.70:                                      ; preds = %varying.coherent.true1095, %scheduler.dispatch.route
  %1280 = load <8 x i1>, ptr %current.mask, align 1
  %1281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1280)
  %1282 = bitcast <8 x i1> %1280 to i8
  %1283 = call i8 @llvm.cttz.i8(i8 %1282, i1 false)
  %1284 = zext i8 %1283 to i32
  %1285 = select i1 %1281, i32 %1284, i32 0
  %.state1097 = load <8 x i64>, ptr %.slot167, align 64
  %1286 = select <8 x i1> %1280, <8 x i64> %.state1097, <8 x i64> zeroinitializer
  %1287 = select <8 x i1> %1280, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1288 = sdiv <8 x i64> %1286, %1287
  %1289 = add <8 x i64> splat (i64 32), %1288
  %tile_snapshot.spill.load1098 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1290 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1098, 0
  %1291 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1098, 1
  %1292 = mul <8 x i64> %1289, splat (i64 32)
  %1293 = add <8 x i64> %1291, %1292
  %1294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1290, 0
  %1295 = insertvalue { <8 x ptr>, <8 x i64> } %1294, <8 x i64> %1293, 1
  %1296 = extractvalue { <8 x ptr>, <8 x i64> } %1295, 0
  %1297 = extractvalue { <8 x ptr>, <8 x i64> } %1295, 1
  %1298 = getelementptr i8, <8 x ptr> %1296, <8 x i64> %1297
  %1299 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1298, <8 x i1> %1280, <8 x float> zeroinitializer)
  %.state1099 = load <8 x float>, ptr %.slot168, align 32
  %1300 = fadd <8 x float> %.state1099, %1299
  %.state1100 = load <8 x i64>, ptr %.slot167, align 64
  %1301 = add <8 x i64> %.state1100, splat (i64 1)
  %1302 = load <8 x i64>, ptr %.slot167, align 64
  %1303 = select <8 x i1> %1280, <8 x i64> %1301, <8 x i64> %1302
  store <8 x i64> %1303, ptr %.slot167, align 64
  %1304 = load <8 x float>, ptr %.slot168, align 32
  %1305 = select <8 x i1> %1280, <8 x float> %1300, <8 x float> %1304
  store <8 x float> %1305, ptr %.slot168, align 32
  store <8 x i1> %1280, ptr %current.mask, align 1
  %1306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1280)
  br i1 %1306, label %schedule.69, label %scheduler.loop

schedule.71:                                      ; preds = %varying.coherent.false1096, %scheduler.dispatch.route
  %1307 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1103 = load i32, ptr %current.token, align 4
  %convergence.token.present1104 = icmp ne i32 %convergence.current.token1103, 0
  br i1 %convergence.token.present1104, label %convergence.cascade1101, label %convergence.cascade.exit1102

schedule.72:                                      ; preds = %schedule.73, %convergence.target.71.ready, %scheduler.dispatch.route
  %1308 = load <8 x i1>, ptr %current.mask, align 1
  %1309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1308)
  %1310 = bitcast <8 x i1> %1308 to i8
  %1311 = call i8 @llvm.cttz.i8(i8 %1310, i1 false)
  %1312 = zext i8 %1311 to i32
  %1313 = select i1 %1309, i32 %1312, i32 0
  %.state1118 = load <8 x i64>, ptr %.slot169, align 64
  %1314 = icmp slt <8 x i64> %.state1118, splat (i64 16)
  %1315 = and <8 x i1> %1308, %1314
  %1316 = xor <8 x i1> %1314, splat (i1 true)
  %1317 = and <8 x i1> %1308, %1316
  %1318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1315)
  %1319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1317)
  %1320 = and i1 %1318, %1319
  br i1 %1320, label %varying.divergent1119, label %varying.coherent1120

schedule.73:                                      ; preds = %varying.coherent.true1125, %scheduler.dispatch.route
  %1321 = load <8 x i1>, ptr %current.mask, align 1
  %1322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1321)
  %1323 = bitcast <8 x i1> %1321 to i8
  %1324 = call i8 @llvm.cttz.i8(i8 %1323, i1 false)
  %1325 = zext i8 %1324 to i32
  %1326 = select i1 %1322, i32 %1325, i32 0
  %.state1127 = load <8 x i64>, ptr %.slot169, align 64
  %1327 = select <8 x i1> %1321, <8 x i64> %.state1127, <8 x i64> zeroinitializer
  %1328 = select <8 x i1> %1321, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1329 = sdiv <8 x i64> %1327, %1328
  %1330 = add <8 x i64> splat (i64 48), %1329
  %tile_snapshot.spill.load1128 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1331 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1128, 0
  %1332 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1128, 1
  %1333 = mul <8 x i64> %1330, splat (i64 32)
  %1334 = add <8 x i64> %1332, %1333
  %1335 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1331, 0
  %1336 = insertvalue { <8 x ptr>, <8 x i64> } %1335, <8 x i64> %1334, 1
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %1336, 0
  %1338 = extractvalue { <8 x ptr>, <8 x i64> } %1336, 1
  %1339 = getelementptr i8, <8 x ptr> %1337, <8 x i64> %1338
  %1340 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1339, <8 x i1> %1321, <8 x float> zeroinitializer)
  %.state1129 = load <8 x float>, ptr %.slot170, align 32
  %1341 = fadd <8 x float> %.state1129, %1340
  %.state1130 = load <8 x i64>, ptr %.slot169, align 64
  %1342 = add <8 x i64> %.state1130, splat (i64 1)
  %1343 = load <8 x i64>, ptr %.slot169, align 64
  %1344 = select <8 x i1> %1321, <8 x i64> %1342, <8 x i64> %1343
  store <8 x i64> %1344, ptr %.slot169, align 64
  %1345 = load <8 x float>, ptr %.slot170, align 32
  %1346 = select <8 x i1> %1321, <8 x float> %1341, <8 x float> %1345
  store <8 x float> %1346, ptr %.slot170, align 32
  store <8 x i1> %1321, ptr %current.mask, align 1
  %1347 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1321)
  br i1 %1347, label %schedule.72, label %scheduler.loop

schedule.74:                                      ; preds = %varying.coherent.false1126, %scheduler.dispatch.route
  %1348 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1133 = load i32, ptr %current.token, align 4
  %convergence.token.present1134 = icmp ne i32 %convergence.current.token1133, 0
  br i1 %convergence.token.present1134, label %convergence.cascade1131, label %convergence.cascade.exit1132

schedule.75:                                      ; preds = %schedule.76, %convergence.target.74.ready, %scheduler.dispatch.route
  %1349 = load <8 x i1>, ptr %current.mask, align 1
  %1350 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1349)
  %1351 = bitcast <8 x i1> %1349 to i8
  %1352 = call i8 @llvm.cttz.i8(i8 %1351, i1 false)
  %1353 = zext i8 %1352 to i32
  %1354 = select i1 %1350, i32 %1353, i32 0
  %.state1148 = load <8 x i64>, ptr %.slot171, align 64
  %1355 = icmp slt <8 x i64> %.state1148, splat (i64 16)
  %1356 = and <8 x i1> %1349, %1355
  %1357 = xor <8 x i1> %1355, splat (i1 true)
  %1358 = and <8 x i1> %1349, %1357
  %1359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1356)
  %1360 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1358)
  %1361 = and i1 %1359, %1360
  br i1 %1361, label %varying.divergent1149, label %varying.coherent1150

schedule.76:                                      ; preds = %varying.coherent.true1155, %scheduler.dispatch.route
  %1362 = load <8 x i1>, ptr %current.mask, align 1
  %1363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1362)
  %1364 = bitcast <8 x i1> %1362 to i8
  %1365 = call i8 @llvm.cttz.i8(i8 %1364, i1 false)
  %1366 = zext i8 %1365 to i32
  %1367 = select i1 %1363, i32 %1366, i32 0
  %.state1157 = load <8 x i64>, ptr %.slot171, align 64
  %1368 = select <8 x i1> %1362, <8 x i64> %.state1157, <8 x i64> zeroinitializer
  %1369 = select <8 x i1> %1362, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1370 = sdiv <8 x i64> %1368, %1369
  %1371 = add <8 x i64> splat (i64 64), %1370
  %tile_snapshot.spill.load1158 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1372 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1158, 0
  %1373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1158, 1
  %1374 = mul <8 x i64> %1371, splat (i64 32)
  %1375 = add <8 x i64> %1373, %1374
  %1376 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1372, 0
  %1377 = insertvalue { <8 x ptr>, <8 x i64> } %1376, <8 x i64> %1375, 1
  %1378 = extractvalue { <8 x ptr>, <8 x i64> } %1377, 0
  %1379 = extractvalue { <8 x ptr>, <8 x i64> } %1377, 1
  %1380 = getelementptr i8, <8 x ptr> %1378, <8 x i64> %1379
  %1381 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1380, <8 x i1> %1362, <8 x float> zeroinitializer)
  %.state1159 = load <8 x float>, ptr %.slot172, align 32
  %1382 = fadd <8 x float> %.state1159, %1381
  %.state1160 = load <8 x i64>, ptr %.slot171, align 64
  %1383 = add <8 x i64> %.state1160, splat (i64 1)
  %1384 = load <8 x i64>, ptr %.slot171, align 64
  %1385 = select <8 x i1> %1362, <8 x i64> %1383, <8 x i64> %1384
  store <8 x i64> %1385, ptr %.slot171, align 64
  %1386 = load <8 x float>, ptr %.slot172, align 32
  %1387 = select <8 x i1> %1362, <8 x float> %1382, <8 x float> %1386
  store <8 x float> %1387, ptr %.slot172, align 32
  store <8 x i1> %1362, ptr %current.mask, align 1
  %1388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1362)
  br i1 %1388, label %schedule.75, label %scheduler.loop

schedule.77:                                      ; preds = %varying.coherent.false1156, %scheduler.dispatch.route
  %1389 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1163 = load i32, ptr %current.token, align 4
  %convergence.token.present1164 = icmp ne i32 %convergence.current.token1163, 0
  br i1 %convergence.token.present1164, label %convergence.cascade1161, label %convergence.cascade.exit1162

schedule.78:                                      ; preds = %schedule.79, %convergence.target.77.ready, %scheduler.dispatch.route
  %1390 = load <8 x i1>, ptr %current.mask, align 1
  %1391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1390)
  %1392 = bitcast <8 x i1> %1390 to i8
  %1393 = call i8 @llvm.cttz.i8(i8 %1392, i1 false)
  %1394 = zext i8 %1393 to i32
  %1395 = select i1 %1391, i32 %1394, i32 0
  %.state1178 = load <8 x i64>, ptr %.slot173, align 64
  %1396 = icmp slt <8 x i64> %.state1178, splat (i64 16)
  %1397 = and <8 x i1> %1390, %1396
  %1398 = xor <8 x i1> %1396, splat (i1 true)
  %1399 = and <8 x i1> %1390, %1398
  %1400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1397)
  %1401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1399)
  %1402 = and i1 %1400, %1401
  br i1 %1402, label %varying.divergent1179, label %varying.coherent1180

schedule.79:                                      ; preds = %varying.coherent.true1185, %scheduler.dispatch.route
  %1403 = load <8 x i1>, ptr %current.mask, align 1
  %1404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1403)
  %1405 = bitcast <8 x i1> %1403 to i8
  %1406 = call i8 @llvm.cttz.i8(i8 %1405, i1 false)
  %1407 = zext i8 %1406 to i32
  %1408 = select i1 %1404, i32 %1407, i32 0
  %.state1187 = load <8 x i64>, ptr %.slot173, align 64
  %1409 = select <8 x i1> %1403, <8 x i64> %.state1187, <8 x i64> zeroinitializer
  %1410 = select <8 x i1> %1403, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1411 = sdiv <8 x i64> %1409, %1410
  %1412 = add <8 x i64> splat (i64 80), %1411
  %tile_snapshot.spill.load1188 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1413 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1188, 0
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1188, 1
  %1415 = mul <8 x i64> %1412, splat (i64 32)
  %1416 = add <8 x i64> %1414, %1415
  %1417 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1413, 0
  %1418 = insertvalue { <8 x ptr>, <8 x i64> } %1417, <8 x i64> %1416, 1
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %1418, 0
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %1418, 1
  %1421 = getelementptr i8, <8 x ptr> %1419, <8 x i64> %1420
  %1422 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1421, <8 x i1> %1403, <8 x float> zeroinitializer)
  %.state1189 = load <8 x float>, ptr %.slot174, align 32
  %1423 = fadd <8 x float> %.state1189, %1422
  %.state1190 = load <8 x i64>, ptr %.slot173, align 64
  %1424 = add <8 x i64> %.state1190, splat (i64 1)
  %1425 = load <8 x i64>, ptr %.slot173, align 64
  %1426 = select <8 x i1> %1403, <8 x i64> %1424, <8 x i64> %1425
  store <8 x i64> %1426, ptr %.slot173, align 64
  %1427 = load <8 x float>, ptr %.slot174, align 32
  %1428 = select <8 x i1> %1403, <8 x float> %1423, <8 x float> %1427
  store <8 x float> %1428, ptr %.slot174, align 32
  store <8 x i1> %1403, ptr %current.mask, align 1
  %1429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1403)
  br i1 %1429, label %schedule.78, label %scheduler.loop

schedule.80:                                      ; preds = %varying.coherent.false1186, %scheduler.dispatch.route
  %1430 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1193 = load i32, ptr %current.token, align 4
  %convergence.token.present1194 = icmp ne i32 %convergence.current.token1193, 0
  br i1 %convergence.token.present1194, label %convergence.cascade1191, label %convergence.cascade.exit1192

schedule.81:                                      ; preds = %schedule.82, %convergence.target.80.ready, %scheduler.dispatch.route
  %1431 = load <8 x i1>, ptr %current.mask, align 1
  %1432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1431)
  %1433 = bitcast <8 x i1> %1431 to i8
  %1434 = call i8 @llvm.cttz.i8(i8 %1433, i1 false)
  %1435 = zext i8 %1434 to i32
  %1436 = select i1 %1432, i32 %1435, i32 0
  %.state1208 = load <8 x i64>, ptr %.slot175, align 64
  %1437 = icmp slt <8 x i64> %.state1208, splat (i64 16)
  %1438 = and <8 x i1> %1431, %1437
  %1439 = xor <8 x i1> %1437, splat (i1 true)
  %1440 = and <8 x i1> %1431, %1439
  %1441 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1438)
  %1442 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1440)
  %1443 = and i1 %1441, %1442
  br i1 %1443, label %varying.divergent1209, label %varying.coherent1210

schedule.82:                                      ; preds = %varying.coherent.true1215, %scheduler.dispatch.route
  %1444 = load <8 x i1>, ptr %current.mask, align 1
  %1445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1444)
  %1446 = bitcast <8 x i1> %1444 to i8
  %1447 = call i8 @llvm.cttz.i8(i8 %1446, i1 false)
  %1448 = zext i8 %1447 to i32
  %1449 = select i1 %1445, i32 %1448, i32 0
  %.state1217 = load <8 x i64>, ptr %.slot175, align 64
  %1450 = select <8 x i1> %1444, <8 x i64> %.state1217, <8 x i64> zeroinitializer
  %1451 = select <8 x i1> %1444, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1452 = sdiv <8 x i64> %1450, %1451
  %1453 = add <8 x i64> splat (i64 96), %1452
  %tile_snapshot.spill.load1218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1218, 0
  %1455 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1218, 1
  %1456 = mul <8 x i64> %1453, splat (i64 32)
  %1457 = add <8 x i64> %1455, %1456
  %1458 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1454, 0
  %1459 = insertvalue { <8 x ptr>, <8 x i64> } %1458, <8 x i64> %1457, 1
  %1460 = extractvalue { <8 x ptr>, <8 x i64> } %1459, 0
  %1461 = extractvalue { <8 x ptr>, <8 x i64> } %1459, 1
  %1462 = getelementptr i8, <8 x ptr> %1460, <8 x i64> %1461
  %1463 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1462, <8 x i1> %1444, <8 x float> zeroinitializer)
  %.state1219 = load <8 x float>, ptr %.slot176, align 32
  %1464 = fadd <8 x float> %.state1219, %1463
  %.state1220 = load <8 x i64>, ptr %.slot175, align 64
  %1465 = add <8 x i64> %.state1220, splat (i64 1)
  %1466 = load <8 x i64>, ptr %.slot175, align 64
  %1467 = select <8 x i1> %1444, <8 x i64> %1465, <8 x i64> %1466
  store <8 x i64> %1467, ptr %.slot175, align 64
  %1468 = load <8 x float>, ptr %.slot176, align 32
  %1469 = select <8 x i1> %1444, <8 x float> %1464, <8 x float> %1468
  store <8 x float> %1469, ptr %.slot176, align 32
  store <8 x i1> %1444, ptr %current.mask, align 1
  %1470 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1444)
  br i1 %1470, label %schedule.81, label %scheduler.loop

schedule.83:                                      ; preds = %varying.coherent.false1216, %scheduler.dispatch.route
  %1471 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1223 = load i32, ptr %current.token, align 4
  %convergence.token.present1224 = icmp ne i32 %convergence.current.token1223, 0
  br i1 %convergence.token.present1224, label %convergence.cascade1221, label %convergence.cascade.exit1222

schedule.84:                                      ; preds = %schedule.85, %convergence.target.83.ready, %scheduler.dispatch.route
  %1472 = load <8 x i1>, ptr %current.mask, align 1
  %1473 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1472)
  %1474 = bitcast <8 x i1> %1472 to i8
  %1475 = call i8 @llvm.cttz.i8(i8 %1474, i1 false)
  %1476 = zext i8 %1475 to i32
  %1477 = select i1 %1473, i32 %1476, i32 0
  %.state1238 = load <8 x i64>, ptr %.slot177, align 64
  %1478 = icmp slt <8 x i64> %.state1238, splat (i64 16)
  %1479 = and <8 x i1> %1472, %1478
  %1480 = xor <8 x i1> %1478, splat (i1 true)
  %1481 = and <8 x i1> %1472, %1480
  %1482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1479)
  %1483 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1481)
  %1484 = and i1 %1482, %1483
  br i1 %1484, label %varying.divergent1239, label %varying.coherent1240

schedule.85:                                      ; preds = %varying.coherent.true1245, %scheduler.dispatch.route
  %1485 = load <8 x i1>, ptr %current.mask, align 1
  %1486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1485)
  %1487 = bitcast <8 x i1> %1485 to i8
  %1488 = call i8 @llvm.cttz.i8(i8 %1487, i1 false)
  %1489 = zext i8 %1488 to i32
  %1490 = select i1 %1486, i32 %1489, i32 0
  %.state1247 = load <8 x i64>, ptr %.slot177, align 64
  %1491 = select <8 x i1> %1485, <8 x i64> %.state1247, <8 x i64> zeroinitializer
  %1492 = select <8 x i1> %1485, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1493 = sdiv <8 x i64> %1491, %1492
  %1494 = add <8 x i64> splat (i64 112), %1493
  %tile_snapshot.spill.load1248 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1248, 0
  %1496 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1248, 1
  %1497 = mul <8 x i64> %1494, splat (i64 32)
  %1498 = add <8 x i64> %1496, %1497
  %1499 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1495, 0
  %1500 = insertvalue { <8 x ptr>, <8 x i64> } %1499, <8 x i64> %1498, 1
  %1501 = extractvalue { <8 x ptr>, <8 x i64> } %1500, 0
  %1502 = extractvalue { <8 x ptr>, <8 x i64> } %1500, 1
  %1503 = getelementptr i8, <8 x ptr> %1501, <8 x i64> %1502
  %1504 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1503, <8 x i1> %1485, <8 x float> zeroinitializer)
  %.state1249 = load <8 x float>, ptr %.slot178, align 32
  %1505 = fadd <8 x float> %.state1249, %1504
  %.state1250 = load <8 x i64>, ptr %.slot177, align 64
  %1506 = add <8 x i64> %.state1250, splat (i64 1)
  %1507 = load <8 x i64>, ptr %.slot177, align 64
  %1508 = select <8 x i1> %1485, <8 x i64> %1506, <8 x i64> %1507
  store <8 x i64> %1508, ptr %.slot177, align 64
  %1509 = load <8 x float>, ptr %.slot178, align 32
  %1510 = select <8 x i1> %1485, <8 x float> %1505, <8 x float> %1509
  store <8 x float> %1510, ptr %.slot178, align 32
  store <8 x i1> %1485, ptr %current.mask, align 1
  %1511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1485)
  br i1 %1511, label %schedule.84, label %scheduler.loop

schedule.86:                                      ; preds = %varying.coherent.false1246, %scheduler.dispatch.route
  %1512 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1253 = load i32, ptr %current.token, align 4
  %convergence.token.present1254 = icmp ne i32 %convergence.current.token1253, 0
  br i1 %convergence.token.present1254, label %convergence.cascade1251, label %convergence.cascade.exit1252

schedule.87:                                      ; preds = %convergence.target.94.ready, %convergence.target.86.ready, %scheduler.dispatch.route
  %1513 = load <8 x i1>, ptr %current.mask, align 1
  %1514 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1513)
  %1515 = bitcast <8 x i1> %1513 to i8
  %1516 = call i8 @llvm.cttz.i8(i8 %1515, i1 false)
  %1517 = zext i8 %1516 to i32
  %1518 = select i1 %1514, i32 %1517, i32 0
  %.state1284 = load <8 x i64>, ptr %.slot188, align 64
  %1519 = icmp slt <8 x i64> %.state1284, splat (i64 4)
  %1520 = and <8 x i1> %1513, %1519
  %1521 = xor <8 x i1> %1519, splat (i1 true)
  %1522 = and <8 x i1> %1513, %1521
  %1523 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1520)
  %1524 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1522)
  %1525 = and i1 %1523, %1524
  br i1 %1525, label %varying.divergent1285, label %varying.coherent1286

schedule.88:                                      ; preds = %varying.coherent.true1291, %scheduler.dispatch.route
  %1526 = load <8 x i1>, ptr %current.mask, align 1
  %1527 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1526)
  %1528 = bitcast <8 x i1> %1526 to i8
  %1529 = call i8 @llvm.cttz.i8(i8 %1528, i1 false)
  %1530 = zext i8 %1529 to i32
  %1531 = select i1 %1527, i32 %1530, i32 0
  %.state1293 = load <8 x i64>, ptr %.slot188, align 64
  %1532 = mul <8 x i64> %.state1293, splat (i64 2)
  %1533 = load <8 x i64>, ptr %.spill189, align 64
  %1534 = select <8 x i1> %1526, <8 x i64> %1532, <8 x i64> %1533
  store <8 x i64> %1534, ptr %.spill189, align 64
  %1535 = load <8 x i64>, ptr %.slot190, align 64
  %1536 = select <8 x i1> %1526, <8 x i64> zeroinitializer, <8 x i64> %1535
  store <8 x i64> %1536, ptr %.slot190, align 64
  store <8 x i1> %1526, ptr %current.mask, align 1
  %1537 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1526)
  br i1 %1537, label %schedule.89, label %scheduler.loop

schedule.89:                                      ; preds = %convergence.target.93.ready, %schedule.88, %scheduler.dispatch.route
  %1538 = load <8 x i1>, ptr %current.mask, align 1
  %1539 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1538)
  %1540 = bitcast <8 x i1> %1538 to i8
  %1541 = call i8 @llvm.cttz.i8(i8 %1540, i1 false)
  %1542 = zext i8 %1541 to i32
  %1543 = select i1 %1539, i32 %1542, i32 0
  %.state1294 = load <8 x i64>, ptr %.slot190, align 64
  %1544 = icmp slt <8 x i64> %.state1294, splat (i64 20)
  %1545 = and <8 x i1> %1538, %1544
  %1546 = xor <8 x i1> %1544, splat (i1 true)
  %1547 = and <8 x i1> %1538, %1546
  %1548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1545)
  %1549 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1547)
  %1550 = and i1 %1548, %1549
  br i1 %1550, label %varying.divergent1295, label %varying.coherent1296

schedule.90:                                      ; preds = %varying.coherent.true1301, %scheduler.dispatch.route
  %1551 = load <8 x i1>, ptr %current.mask, align 1
  %1552 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1551)
  %1553 = bitcast <8 x i1> %1551 to i8
  %1554 = call i8 @llvm.cttz.i8(i8 %1553, i1 false)
  %1555 = zext i8 %1554 to i32
  %1556 = select i1 %1552, i32 %1555, i32 0
  %.state1303 = load <8 x i64>, ptr %.slot190, align 64
  %1557 = mul <8 x i64> %.state1303, splat (i64 2)
  %.spill.load1304 = load <8 x i64>, ptr %.spill189, align 64
  %1558 = add <8 x i64> zeroinitializer, %.spill.load1304
  %1559 = mul <8 x i64> %1558, splat (i64 40)
  %1560 = add <8 x i64> %1559, %1557
  %1561 = add <8 x i64> %1560, zeroinitializer
  %1562 = load <8 x i64>, ptr %.spill191, align 64
  %1563 = select <8 x i1> %1551, <8 x i64> %1561, <8 x i64> %1562
  store <8 x i64> %1563, ptr %.spill191, align 64
  %1564 = select <8 x i1> %1551, <8 x i64> %1561, <8 x i64> zeroinitializer
  %1565 = select <8 x i1> %1551, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1566 = srem <8 x i64> %1564, %1565
  %1567 = load <8 x i64>, ptr %.spill192, align 64
  %1568 = select <8 x i1> %1551, <8 x i64> %1566, <8 x i64> %1567
  store <8 x i64> %1568, ptr %.spill192, align 64
  %1569 = select <8 x i1> %1551, <8 x i64> %1561, <8 x i64> zeroinitializer
  %1570 = select <8 x i1> %1551, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1571 = sdiv <8 x i64> %1569, %1570
  %1572 = add <8 x i64> zeroinitializer, %1571
  %1573 = load <8 x i64>, ptr %.spill193, align 64
  %1574 = select <8 x i1> %1551, <8 x i64> %1572, <8 x i64> %1573
  store <8 x i64> %1574, ptr %.spill193, align 64
  %1575 = mul <8 x i64> %1572, splat (i64 40)
  %1576 = add <8 x i64> %1575, %1566
  %tile_snapshot.spill.load1305 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %1577 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1305, 0
  %1578 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1305, 1
  %1579 = mul <8 x i64> %1576, splat (i64 32)
  %1580 = add <8 x i64> %1578, %1579
  %1581 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1577, 0
  %1582 = insertvalue { <8 x ptr>, <8 x i64> } %1581, <8 x i64> %1580, 1
  %1583 = extractvalue { <8 x ptr>, <8 x i64> } %1582, 0
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %1582, 1
  %1585 = getelementptr i8, <8 x ptr> %1583, <8 x i64> %1584
  %1586 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1585, <8 x i1> %1551, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1306 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1587 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1306, 0
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1306, 1
  %1589 = mul <8 x i64> %1572, splat (i64 32)
  %1590 = add <8 x i64> %1588, %1589
  %1591 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1587, 0
  %1592 = insertvalue { <8 x ptr>, <8 x i64> } %1591, <8 x i64> %1590, 1
  %1593 = extractvalue { <8 x ptr>, <8 x i64> } %1592, 0
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %1592, 1
  %1595 = getelementptr i8, <8 x ptr> %1593, <8 x i64> %1594
  %1596 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1595, <8 x i1> %1551, <8 x float> zeroinitializer)
  %1597 = fmul <8 x float> %1586, %1596
  %1598 = add <8 x i64> %1560, splat (i64 1)
  %1599 = load <8 x i64>, ptr %.spill194, align 64
  %1600 = select <8 x i1> %1551, <8 x i64> %1598, <8 x i64> %1599
  store <8 x i64> %1600, ptr %.spill194, align 64
  %1601 = select <8 x i1> %1551, <8 x i64> %1598, <8 x i64> zeroinitializer
  %1602 = select <8 x i1> %1551, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1603 = srem <8 x i64> %1601, %1602
  %1604 = load <8 x i64>, ptr %.spill195, align 64
  %1605 = select <8 x i1> %1551, <8 x i64> %1603, <8 x i64> %1604
  store <8 x i64> %1605, ptr %.spill195, align 64
  %1606 = select <8 x i1> %1551, <8 x i64> %1598, <8 x i64> zeroinitializer
  %1607 = select <8 x i1> %1551, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1608 = sdiv <8 x i64> %1606, %1607
  %1609 = add <8 x i64> zeroinitializer, %1608
  %1610 = mul <8 x i64> %1609, splat (i64 40)
  %1611 = add <8 x i64> %1610, %1603
  %tile_snapshot.spill.load1307 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %1612 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1307, 0
  %1613 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1307, 1
  %1614 = mul <8 x i64> %1611, splat (i64 32)
  %1615 = add <8 x i64> %1613, %1614
  %1616 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1612, 0
  %1617 = insertvalue { <8 x ptr>, <8 x i64> } %1616, <8 x i64> %1615, 1
  %1618 = extractvalue { <8 x ptr>, <8 x i64> } %1617, 0
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %1617, 1
  %1620 = getelementptr i8, <8 x ptr> %1618, <8 x i64> %1619
  %1621 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1620, <8 x i1> %1551, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1308 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1308, 0
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1308, 1
  %1624 = mul <8 x i64> %1609, splat (i64 32)
  %1625 = add <8 x i64> %1623, %1624
  %1626 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1622, 0
  %1627 = insertvalue { <8 x ptr>, <8 x i64> } %1626, <8 x i64> %1625, 1
  %1628 = extractvalue { <8 x ptr>, <8 x i64> } %1627, 0
  %1629 = extractvalue { <8 x ptr>, <8 x i64> } %1627, 1
  %1630 = getelementptr i8, <8 x ptr> %1628, <8 x i64> %1629
  %1631 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1630, <8 x i1> %1551, <8 x float> zeroinitializer)
  %1632 = fmul <8 x float> %1621, %1631
  %1633 = add <8 x i64> %1560, splat (i64 40)
  %1634 = load <8 x i64>, ptr %.spill196, align 64
  %1635 = select <8 x i1> %1551, <8 x i64> %1633, <8 x i64> %1634
  store <8 x i64> %1635, ptr %.spill196, align 64
  %1636 = select <8 x i1> %1551, <8 x i64> %1633, <8 x i64> zeroinitializer
  %1637 = select <8 x i1> %1551, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1638 = srem <8 x i64> %1636, %1637
  %1639 = select <8 x i1> %1551, <8 x i64> %1633, <8 x i64> zeroinitializer
  %1640 = select <8 x i1> %1551, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1641 = sdiv <8 x i64> %1639, %1640
  %1642 = add <8 x i64> zeroinitializer, %1641
  %1643 = load <8 x i64>, ptr %.spill197, align 64
  %1644 = select <8 x i1> %1551, <8 x i64> %1642, <8 x i64> %1643
  store <8 x i64> %1644, ptr %.spill197, align 64
  %1645 = mul <8 x i64> %1642, splat (i64 40)
  %1646 = add <8 x i64> %1645, %1638
  %tile_snapshot.spill.load1309 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1309, 0
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1309, 1
  %1649 = mul <8 x i64> %1646, splat (i64 32)
  %1650 = add <8 x i64> %1648, %1649
  %1651 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1647, 0
  %1652 = insertvalue { <8 x ptr>, <8 x i64> } %1651, <8 x i64> %1650, 1
  %1653 = extractvalue { <8 x ptr>, <8 x i64> } %1652, 0
  %1654 = extractvalue { <8 x ptr>, <8 x i64> } %1652, 1
  %1655 = getelementptr i8, <8 x ptr> %1653, <8 x i64> %1654
  %1656 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1655, <8 x i1> %1551, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1310 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1657 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1310, 0
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1310, 1
  %1659 = mul <8 x i64> %1642, splat (i64 32)
  %1660 = add <8 x i64> %1658, %1659
  %1661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1657, 0
  %1662 = insertvalue { <8 x ptr>, <8 x i64> } %1661, <8 x i64> %1660, 1
  %1663 = extractvalue { <8 x ptr>, <8 x i64> } %1662, 0
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %1662, 1
  %1665 = getelementptr i8, <8 x ptr> %1663, <8 x i64> %1664
  %1666 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1665, <8 x i1> %1551, <8 x float> zeroinitializer)
  %1667 = fmul <8 x float> %1656, %1666
  %1668 = add <8 x i64> %1560, splat (i64 41)
  %1669 = load <8 x i64>, ptr %.spill198, align 64
  %1670 = select <8 x i1> %1551, <8 x i64> %1668, <8 x i64> %1669
  store <8 x i64> %1670, ptr %.spill198, align 64
  %1671 = select <8 x i1> %1551, <8 x i64> %1668, <8 x i64> zeroinitializer
  %1672 = select <8 x i1> %1551, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1673 = srem <8 x i64> %1671, %1672
  %1674 = select <8 x i1> %1551, <8 x i64> %1668, <8 x i64> zeroinitializer
  %1675 = select <8 x i1> %1551, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1676 = sdiv <8 x i64> %1674, %1675
  %1677 = add <8 x i64> zeroinitializer, %1676
  %1678 = mul <8 x i64> %1677, splat (i64 40)
  %1679 = add <8 x i64> %1678, %1673
  %tile_snapshot.spill.load1311 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %1680 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1311, 0
  %1681 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1311, 1
  %1682 = mul <8 x i64> %1679, splat (i64 32)
  %1683 = add <8 x i64> %1681, %1682
  %1684 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1680, 0
  %1685 = insertvalue { <8 x ptr>, <8 x i64> } %1684, <8 x i64> %1683, 1
  %1686 = extractvalue { <8 x ptr>, <8 x i64> } %1685, 0
  %1687 = extractvalue { <8 x ptr>, <8 x i64> } %1685, 1
  %1688 = getelementptr i8, <8 x ptr> %1686, <8 x i64> %1687
  %1689 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1688, <8 x i1> %1551, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1312 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %1690 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1312, 0
  %1691 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1312, 1
  %1692 = mul <8 x i64> %1677, splat (i64 32)
  %1693 = add <8 x i64> %1691, %1692
  %1694 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1690, 0
  %1695 = insertvalue { <8 x ptr>, <8 x i64> } %1694, <8 x i64> %1693, 1
  %1696 = extractvalue { <8 x ptr>, <8 x i64> } %1695, 0
  %1697 = extractvalue { <8 x ptr>, <8 x i64> } %1695, 1
  %1698 = getelementptr i8, <8 x ptr> %1696, <8 x i64> %1697
  %1699 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1698, <8 x i1> %1551, <8 x float> zeroinitializer)
  %1700 = fmul <8 x float> %1689, %1699
  %1701 = load <8 x i64>, ptr %.slot199, align 64
  %1702 = select <8 x i1> %1551, <8 x i64> zeroinitializer, <8 x i64> %1701
  store <8 x i64> %1702, ptr %.slot199, align 64
  %1703 = load <8 x float>, ptr %.slot200, align 32
  %1704 = select <8 x i1> %1551, <8 x float> %1597, <8 x float> %1703
  store <8 x float> %1704, ptr %.slot200, align 32
  %1705 = load <8 x float>, ptr %.slot201, align 32
  %1706 = select <8 x i1> %1551, <8 x float> %1632, <8 x float> %1705
  store <8 x float> %1706, ptr %.slot201, align 32
  %1707 = load <8 x float>, ptr %.slot202, align 32
  %1708 = select <8 x i1> %1551, <8 x float> %1667, <8 x float> %1707
  store <8 x float> %1708, ptr %.slot202, align 32
  %1709 = load <8 x float>, ptr %.slot203, align 32
  %1710 = select <8 x i1> %1551, <8 x float> %1700, <8 x float> %1709
  store <8 x float> %1710, ptr %.slot203, align 32
  store <8 x i1> %1551, ptr %current.mask, align 1
  %1711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1551)
  br i1 %1711, label %schedule.91, label %scheduler.loop

schedule.91:                                      ; preds = %schedule.92, %schedule.90, %scheduler.dispatch.route
  %1712 = load <8 x i1>, ptr %current.mask, align 1
  %1713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1712)
  %1714 = bitcast <8 x i1> %1712 to i8
  %1715 = call i8 @llvm.cttz.i8(i8 %1714, i1 false)
  %1716 = zext i8 %1715 to i32
  %1717 = select i1 %1713, i32 %1716, i32 0
  %.state1313 = load <8 x i64>, ptr %.slot199, align 64
  %1718 = icmp slt <8 x i64> %.state1313, splat (i64 16)
  %1719 = and <8 x i1> %1712, %1718
  %1720 = xor <8 x i1> %1718, splat (i1 true)
  %1721 = and <8 x i1> %1712, %1720
  %1722 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1719)
  %1723 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1721)
  %1724 = and i1 %1722, %1723
  br i1 %1724, label %varying.divergent1314, label %varying.coherent1315

schedule.92:                                      ; preds = %varying.coherent.true1320, %scheduler.dispatch.route
  %1725 = load <8 x i1>, ptr %current.mask, align 1
  %1726 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1725)
  %1727 = bitcast <8 x i1> %1725 to i8
  %1728 = call i8 @llvm.cttz.i8(i8 %1727, i1 false)
  %1729 = zext i8 %1728 to i32
  %1730 = select i1 %1726, i32 %1729, i32 0
  %.spill.load1322 = load <8 x i64>, ptr %.spill193, align 64
  %1731 = mul <8 x i64> %.spill.load1322, splat (i64 16)
  %.state1323 = load <8 x i64>, ptr %.slot199, align 64
  %1732 = add <8 x i64> %1731, %.state1323
  %tile_snapshot.spill.load1324 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1324, 0
  %1734 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1324, 1
  %1735 = mul <8 x i64> %1732, splat (i64 32)
  %1736 = add <8 x i64> %1734, %1735
  %1737 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1733, 0
  %1738 = insertvalue { <8 x ptr>, <8 x i64> } %1737, <8 x i64> %1736, 1
  %1739 = extractvalue { <8 x ptr>, <8 x i64> } %1738, 0
  %1740 = extractvalue { <8 x ptr>, <8 x i64> } %1738, 1
  %1741 = getelementptr i8, <8 x ptr> %1739, <8 x i64> %1740
  %1742 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1741, <8 x i1> %1725, <8 x float> zeroinitializer)
  %.spill.load1325 = load <8 x i64>, ptr %.spill197, align 64
  %1743 = mul <8 x i64> %.spill.load1325, splat (i64 16)
  %.state1326 = load <8 x i64>, ptr %.slot199, align 64
  %1744 = add <8 x i64> %1743, %.state1326
  %tile_snapshot.spill.load1327 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1745 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1327, 0
  %1746 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1327, 1
  %1747 = mul <8 x i64> %1744, splat (i64 32)
  %1748 = add <8 x i64> %1746, %1747
  %1749 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1745, 0
  %1750 = insertvalue { <8 x ptr>, <8 x i64> } %1749, <8 x i64> %1748, 1
  %1751 = extractvalue { <8 x ptr>, <8 x i64> } %1750, 0
  %1752 = extractvalue { <8 x ptr>, <8 x i64> } %1750, 1
  %1753 = getelementptr i8, <8 x ptr> %1751, <8 x i64> %1752
  %1754 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1753, <8 x i1> %1725, <8 x float> zeroinitializer)
  %.state1328 = load <8 x i64>, ptr %.slot199, align 64
  %1755 = add <8 x i64> zeroinitializer, %.state1328
  %1756 = mul <8 x i64> %1755, splat (i64 40)
  %.spill.load1329 = load <8 x i64>, ptr %.spill192, align 64
  %1757 = add <8 x i64> %1756, %.spill.load1329
  %tile_snapshot.spill.load1330 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %1758 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1330, 0
  %1759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1330, 1
  %1760 = mul <8 x i64> %1757, splat (i64 32)
  %1761 = add <8 x i64> %1759, %1760
  %1762 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1758, 0
  %1763 = insertvalue { <8 x ptr>, <8 x i64> } %1762, <8 x i64> %1761, 1
  %1764 = extractvalue { <8 x ptr>, <8 x i64> } %1763, 0
  %1765 = extractvalue { <8 x ptr>, <8 x i64> } %1763, 1
  %1766 = getelementptr i8, <8 x ptr> %1764, <8 x i64> %1765
  %1767 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1766, <8 x i1> %1725, <8 x float> zeroinitializer)
  %.spill.load1331 = load <8 x i64>, ptr %.spill195, align 64
  %1768 = add <8 x i64> %1756, %.spill.load1331
  %tile_snapshot.spill.load1332 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %1769 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1332, 0
  %1770 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1332, 1
  %1771 = mul <8 x i64> %1768, splat (i64 32)
  %1772 = add <8 x i64> %1770, %1771
  %1773 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1769, 0
  %1774 = insertvalue { <8 x ptr>, <8 x i64> } %1773, <8 x i64> %1772, 1
  %1775 = extractvalue { <8 x ptr>, <8 x i64> } %1774, 0
  %1776 = extractvalue { <8 x ptr>, <8 x i64> } %1774, 1
  %1777 = getelementptr i8, <8 x ptr> %1775, <8 x i64> %1776
  %1778 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1777, <8 x i1> %1725, <8 x float> zeroinitializer)
  %1779 = fmul <8 x float> %1742, %1767
  %.state1333 = load <8 x float>, ptr %.slot200, align 32
  %1780 = fadd <8 x float> %.state1333, %1779
  %1781 = fmul <8 x float> %1742, %1778
  %.state1334 = load <8 x float>, ptr %.slot201, align 32
  %1782 = fadd <8 x float> %.state1334, %1781
  %1783 = fmul <8 x float> %1754, %1767
  %.state1335 = load <8 x float>, ptr %.slot202, align 32
  %1784 = fadd <8 x float> %.state1335, %1783
  %1785 = fmul <8 x float> %1754, %1778
  %.state1336 = load <8 x float>, ptr %.slot203, align 32
  %1786 = fadd <8 x float> %.state1336, %1785
  %.state1337 = load <8 x i64>, ptr %.slot199, align 64
  %1787 = add <8 x i64> %.state1337, splat (i64 1)
  %1788 = load <8 x i64>, ptr %.slot199, align 64
  %1789 = select <8 x i1> %1725, <8 x i64> %1787, <8 x i64> %1788
  store <8 x i64> %1789, ptr %.slot199, align 64
  %1790 = load <8 x float>, ptr %.slot200, align 32
  %1791 = select <8 x i1> %1725, <8 x float> %1780, <8 x float> %1790
  store <8 x float> %1791, ptr %.slot200, align 32
  %1792 = load <8 x float>, ptr %.slot201, align 32
  %1793 = select <8 x i1> %1725, <8 x float> %1782, <8 x float> %1792
  store <8 x float> %1793, ptr %.slot201, align 32
  %1794 = load <8 x float>, ptr %.slot202, align 32
  %1795 = select <8 x i1> %1725, <8 x float> %1784, <8 x float> %1794
  store <8 x float> %1795, ptr %.slot202, align 32
  %1796 = load <8 x float>, ptr %.slot203, align 32
  %1797 = select <8 x i1> %1725, <8 x float> %1786, <8 x float> %1796
  store <8 x float> %1797, ptr %.slot203, align 32
  store <8 x i1> %1725, ptr %current.mask, align 1
  %1798 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1725)
  br i1 %1798, label %schedule.91, label %scheduler.loop

schedule.93:                                      ; preds = %varying.coherent.false1321, %scheduler.dispatch.route
  %1799 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1340 = load i32, ptr %current.token, align 4
  %convergence.token.present1341 = icmp ne i32 %convergence.current.token1340, 0
  br i1 %convergence.token.present1341, label %convergence.cascade1338, label %convergence.cascade.exit1339

schedule.94:                                      ; preds = %varying.coherent.false1302, %scheduler.dispatch.route
  %1800 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1370 = load i32, ptr %current.token, align 4
  %convergence.token.present1371 = icmp ne i32 %convergence.current.token1370, 0
  br i1 %convergence.token.present1371, label %convergence.cascade1368, label %convergence.cascade.exit1369

schedule.95:                                      ; preds = %varying.coherent.false1292, %scheduler.dispatch.route
  %1801 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1388 = load i32, ptr %current.token, align 4
  %convergence.token.present1389 = icmp ne i32 %convergence.current.token1388, 0
  br i1 %convergence.token.present1389, label %convergence.cascade1386, label %convergence.cascade.exit1387

schedule.96:                                      ; preds = %schedule.97, %convergence.target.95.ready, %scheduler.dispatch.route
  %1802 = load <8 x i1>, ptr %current.mask, align 1
  %1803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1802)
  %1804 = bitcast <8 x i1> %1802 to i8
  %1805 = call i8 @llvm.cttz.i8(i8 %1804, i1 false)
  %1806 = zext i8 %1805 to i32
  %1807 = select i1 %1803, i32 %1806, i32 0
  %.state1403 = load <8 x i64>, ptr %.slot204, align 64
  %1808 = icmp slt <8 x i64> %.state1403, splat (i64 320)
  %1809 = and <8 x i1> %1802, %1808
  %1810 = xor <8 x i1> %1808, splat (i1 true)
  %1811 = and <8 x i1> %1802, %1810
  %1812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1809)
  %1813 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1811)
  %1814 = and i1 %1812, %1813
  br i1 %1814, label %varying.divergent1404, label %varying.coherent1405

schedule.97:                                      ; preds = %varying.coherent.true1410, %scheduler.dispatch.route
  %1815 = load <8 x i1>, ptr %current.mask, align 1
  %1816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1815)
  %1817 = bitcast <8 x i1> %1815 to i8
  %1818 = call i8 @llvm.cttz.i8(i8 %1817, i1 false)
  %1819 = zext i8 %1818 to i32
  %1820 = select i1 %1816, i32 %1819, i32 0
  %tile_snapshot.spill.load1412 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill187, align 64
  %1821 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1412, 0
  %1822 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1412, 1
  %.state1413 = load <8 x i64>, ptr %.slot204, align 64
  %1823 = mul <8 x i64> %.state1413, splat (i64 32)
  %1824 = add <8 x i64> %1822, %1823
  %1825 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1821, 0
  %1826 = insertvalue { <8 x ptr>, <8 x i64> } %1825, <8 x i64> %1824, 1
  %1827 = extractvalue { <8 x ptr>, <8 x i64> } %1826, 0
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %1826, 1
  %1829 = getelementptr i8, <8 x ptr> %1827, <8 x i64> %1828
  %1830 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1829, <8 x i1> %1815, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1414 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %1831 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1414, 0
  %1832 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1414, 1
  %.state1415 = load <8 x i64>, ptr %.slot204, align 64
  %1833 = mul <8 x i64> %.state1415, splat (i64 32)
  %1834 = add <8 x i64> %1832, %1833
  %1835 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1831, 0
  %1836 = insertvalue { <8 x ptr>, <8 x i64> } %1835, <8 x i64> %1834, 1
  %1837 = extractvalue { <8 x ptr>, <8 x i64> } %1836, 0
  %1838 = extractvalue { <8 x ptr>, <8 x i64> } %1836, 1
  %1839 = getelementptr i8, <8 x ptr> %1837, <8 x i64> %1838
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1830, <8 x ptr> align 1 %1839, <8 x i1> %1815)
  %.state1416 = load <8 x i64>, ptr %.slot204, align 64
  %1840 = add <8 x i64> %.state1416, splat (i64 1)
  %1841 = load <8 x i64>, ptr %.slot204, align 64
  %1842 = select <8 x i1> %1815, <8 x i64> %1840, <8 x i64> %1841
  store <8 x i64> %1842, ptr %.slot204, align 64
  store <8 x i1> %1815, ptr %current.mask, align 1
  %1843 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1815)
  br i1 %1843, label %schedule.96, label %scheduler.loop

schedule.98:                                      ; preds = %varying.coherent.false1411, %scheduler.dispatch.route
  %1844 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1419 = load i32, ptr %current.token, align 4
  %convergence.token.present1420 = icmp ne i32 %convergence.current.token1419, 0
  br i1 %convergence.token.present1420, label %convergence.cascade1417, label %convergence.cascade.exit1418

schedule.99:                                      ; preds = %schedule.100, %convergence.target.98.ready, %scheduler.dispatch.route
  %1845 = load <8 x i1>, ptr %current.mask, align 1
  %1846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1845)
  %1847 = bitcast <8 x i1> %1845 to i8
  %1848 = call i8 @llvm.cttz.i8(i8 %1847, i1 false)
  %1849 = zext i8 %1848 to i32
  %1850 = select i1 %1846, i32 %1849, i32 0
  %.state1434 = load <8 x i64>, ptr %.slot205, align 64
  %1851 = icmp slt <8 x i64> %.state1434, splat (i64 320)
  %1852 = and <8 x i1> %1845, %1851
  %1853 = xor <8 x i1> %1851, splat (i1 true)
  %1854 = and <8 x i1> %1845, %1853
  %1855 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1852)
  %1856 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1854)
  %1857 = and i1 %1855, %1856
  br i1 %1857, label %varying.divergent1435, label %varying.coherent1436

schedule.100:                                     ; preds = %varying.coherent.true1441, %scheduler.dispatch.route
  %1858 = load <8 x i1>, ptr %current.mask, align 1
  %1859 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1858)
  %1860 = bitcast <8 x i1> %1858 to i8
  %1861 = call i8 @llvm.cttz.i8(i8 %1860, i1 false)
  %1862 = zext i8 %1861 to i32
  %1863 = select i1 %1859, i32 %1862, i32 0
  %tile_snapshot.spill.load1443 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %1864 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1443, 0
  %1865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1443, 1
  %.state1444 = load <8 x i64>, ptr %.slot205, align 64
  %1866 = mul <8 x i64> %.state1444, splat (i64 32)
  %1867 = add <8 x i64> %1865, %1866
  %1868 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1864, 0
  %1869 = insertvalue { <8 x ptr>, <8 x i64> } %1868, <8 x i64> %1867, 1
  %1870 = extractvalue { <8 x ptr>, <8 x i64> } %1869, 0
  %1871 = extractvalue { <8 x ptr>, <8 x i64> } %1869, 1
  %1872 = getelementptr i8, <8 x ptr> %1870, <8 x i64> %1871
  %1873 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1872, <8 x i1> %1858, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1445 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %1874 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1445, 0
  %1875 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1445, 1
  %.state1446 = load <8 x i64>, ptr %.slot205, align 64
  %1876 = mul <8 x i64> %.state1446, splat (i64 32)
  %1877 = add <8 x i64> %1875, %1876
  %1878 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1874, 0
  %1879 = insertvalue { <8 x ptr>, <8 x i64> } %1878, <8 x i64> %1877, 1
  %1880 = extractvalue { <8 x ptr>, <8 x i64> } %1879, 0
  %1881 = extractvalue { <8 x ptr>, <8 x i64> } %1879, 1
  %1882 = getelementptr i8, <8 x ptr> %1880, <8 x i64> %1881
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1873, <8 x ptr> align 1 %1882, <8 x i1> %1858)
  %.state1447 = load <8 x i64>, ptr %.slot205, align 64
  %1883 = add <8 x i64> %.state1447, splat (i64 1)
  %1884 = load <8 x i64>, ptr %.slot205, align 64
  %1885 = select <8 x i1> %1858, <8 x i64> %1883, <8 x i64> %1884
  store <8 x i64> %1885, ptr %.slot205, align 64
  store <8 x i1> %1858, ptr %current.mask, align 1
  %1886 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1858)
  br i1 %1886, label %schedule.99, label %scheduler.loop

schedule.101:                                     ; preds = %varying.coherent.false1442, %scheduler.dispatch.route
  %1887 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1450 = load i32, ptr %current.token, align 4
  %convergence.token.present1451 = icmp ne i32 %convergence.current.token1450, 0
  br i1 %convergence.token.present1451, label %convergence.cascade1448, label %convergence.cascade.exit1449

schedule.102:                                     ; preds = %varying.coherent.false297, %scheduler.dispatch.route
  %1888 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1484 = load i32, ptr %current.token, align 4
  %convergence.token.present1485 = icmp ne i32 %convergence.current.token1484, 0
  br i1 %convergence.token.present1485, label %convergence.cascade1482, label %convergence.cascade.exit1483

schedule.103:                                     ; preds = %convergence.target.106.ready, %convergence.target.102.ready, %scheduler.dispatch.route
  %1889 = load <8 x i1>, ptr %current.mask, align 1
  %1890 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1889)
  %1891 = bitcast <8 x i1> %1889 to i8
  %1892 = call i8 @llvm.cttz.i8(i8 %1891, i1 false)
  %1893 = zext i8 %1892 to i32
  %1894 = select i1 %1890, i32 %1893, i32 0
  %.state1523 = load <8 x i64>, ptr %.slot207, align 64
  %1895 = icmp slt <8 x i64> %.state1523, splat (i64 320)
  %1896 = and <8 x i1> %1889, %1895
  %1897 = xor <8 x i1> %1895, splat (i1 true)
  %1898 = and <8 x i1> %1889, %1897
  %1899 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1896)
  %1900 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1898)
  %1901 = and i1 %1899, %1900
  br i1 %1901, label %varying.divergent1524, label %varying.coherent1525

schedule.104:                                     ; preds = %varying.coherent.true1530, %scheduler.dispatch.route
  %1902 = load <8 x i1>, ptr %current.mask, align 1
  %1903 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1902)
  %1904 = bitcast <8 x i1> %1902 to i8
  %1905 = call i8 @llvm.cttz.i8(i8 %1904, i1 false)
  %1906 = zext i8 %1905 to i32
  %1907 = select i1 %1903, i32 %1906, i32 0
  %.state1532 = load <8 x i64>, ptr %.slot207, align 64
  %1908 = select <8 x i1> %1902, <8 x i64> %.state1532, <8 x i64> zeroinitializer
  %1909 = select <8 x i1> %1902, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1910 = srem <8 x i64> %1908, %1909
  %.state1533 = load <8 x i64>, ptr %.slot207, align 64
  %1911 = select <8 x i1> %1902, <8 x i64> %.state1533, <8 x i64> zeroinitializer
  %1912 = select <8 x i1> %1902, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1913 = sdiv <8 x i64> %1911, %1912
  %.spill.load1534 = load <8 x i64>, ptr %.spill, align 64
  %1914 = add <8 x i64> %.spill.load1534, zeroinitializer
  %1915 = add <8 x i64> zeroinitializer, %1914
  %.spill.load1535 = load <8 x i64>, ptr %.spill61, align 64
  %1916 = add <8 x i64> %.spill.load1535, %1913
  %1917 = mul <8 x i64> %1915, splat (i64 33)
  %1918 = add <8 x i64> %1917, %1916
  %1919 = icmp sge <8 x i64> %1916, zeroinitializer
  %1920 = and <8 x i1> splat (i1 true), %1919
  %1921 = icmp slt <8 x i64> %1916, splat (i64 33)
  %1922 = and <8 x i1> %1920, %1921
  %1923 = add <8 x i64> zeroinitializer, %1910
  %1924 = mul <8 x i64> %1918, splat (i64 40)
  %1925 = add <8 x i64> %1924, %1923
  %1926 = load <8 x i64>, ptr %.spill208, align 64
  %1927 = select <8 x i1> %1902, <8 x i64> %1925, <8 x i64> %1926
  store <8 x i64> %1927, ptr %.spill208, align 64
  %1928 = add <8 x i64> zeroinitializer, %1913
  %1929 = mul <8 x i64> %1928, splat (i64 40)
  %1930 = add <8 x i64> %1929, %1910
  %tile_snapshot.spill.load1536 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1536, 0
  %1932 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1536, 1
  %1933 = mul <8 x i64> %1930, splat (i64 32)
  %1934 = add <8 x i64> %1932, %1933
  %1935 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1931, 0
  %1936 = insertvalue { <8 x ptr>, <8 x i64> } %1935, <8 x i64> %1934, 1
  %1937 = extractvalue { <8 x ptr>, <8 x i64> } %1936, 0
  %1938 = extractvalue { <8 x ptr>, <8 x i64> } %1936, 1
  %1939 = getelementptr i8, <8 x ptr> %1937, <8 x i64> %1938
  %1940 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1939, <8 x i1> %1902, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1537 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill206, align 64
  %1941 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1537, 0
  %1942 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1537, 1
  %1943 = mul <8 x i64> %1928, splat (i64 32)
  %1944 = add <8 x i64> %1942, %1943
  %1945 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1941, 0
  %1946 = insertvalue { <8 x ptr>, <8 x i64> } %1945, <8 x i64> %1944, 1
  %1947 = extractvalue { <8 x ptr>, <8 x i64> } %1946, 0
  %1948 = extractvalue { <8 x ptr>, <8 x i64> } %1946, 1
  %1949 = getelementptr i8, <8 x ptr> %1947, <8 x i64> %1948
  %1950 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1949, <8 x i1> %1902, <8 x float> zeroinitializer)
  %1951 = fdiv <8 x float> %1940, %1950
  %1952 = load <8 x float>, ptr %.spill209, align 32
  %1953 = select <8 x i1> %1902, <8 x float> %1951, <8 x float> %1952
  store <8 x float> %1953, ptr %.spill209, align 32
  %1954 = and <8 x i1> %1902, %1922
  %1955 = xor <8 x i1> %1922, splat (i1 true)
  %1956 = and <8 x i1> %1902, %1955
  %1957 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1954)
  %1958 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1956)
  %1959 = and i1 %1957, %1958
  br i1 %1959, label %varying.divergent1538, label %varying.coherent1539

schedule.105:                                     ; preds = %varying.coherent.true1544, %scheduler.dispatch.route
  %1960 = load <8 x i1>, ptr %current.mask, align 1
  %1961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1960)
  %1962 = bitcast <8 x i1> %1960 to i8
  %1963 = call i8 @llvm.cttz.i8(i8 %1962, i1 false)
  %1964 = zext i8 %1963 to i32
  %1965 = select i1 %1961, i32 %1964, i32 0
  %.spill.load1546 = load <8 x i64>, ptr %.spill208, align 64
  %.spill.load1547 = load <8 x float>, ptr %.spill209, align 32
  %1966 = extractvalue { ptr, i64 } %71, 0
  %1967 = mul <8 x i64> %.spill.load1546, splat (i64 4)
  %1968 = getelementptr i8, ptr %1966, <8 x i64> %1967
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load1547, <8 x ptr> align 1 %1968, <8 x i1> %1960)
  store <8 x i1> %1960, ptr %current.mask, align 1
  %1969 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1960)
  br i1 %1969, label %schedule.106, label %scheduler.loop

schedule.106:                                     ; preds = %schedule.105, %varying.coherent.false1545, %scheduler.dispatch.route
  %1970 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1550 = load i32, ptr %current.token, align 4
  %convergence.token.present1551 = icmp ne i32 %convergence.current.token1550, 0
  br i1 %convergence.token.present1551, label %convergence.cascade1548, label %convergence.cascade.exit1549

schedule.107:                                     ; preds = %varying.coherent.false1531, %scheduler.dispatch.route
  %1971 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1568 = load i32, ptr %current.token, align 4
  %convergence.token.present1569 = icmp ne i32 %convergence.current.token1568, 0
  br i1 %convergence.token.present1569, label %convergence.cascade1566, label %convergence.cascade.exit1567

varying.divergent:                                ; preds = %schedule.1
  %1972 = load i32, ptr %current.token, align 4
  %1973 = icmp ne i32 %1972, 0
  %1974 = sub i32 %1972, 1
  %1975 = select i1 %1973, i32 %1974, i32 0
  %1976 = load i8, ptr %frame.active, align 1
  %1977 = trunc i32 %1975 to i8
  %1978 = shl i8 1, %1977
  %1979 = and i8 %1976, %1978
  %1980 = icmp ne i8 %1979, 0
  %1981 = load <8 x i32>, ptr %frame.static.id, align 32
  %1982 = extractelement <8 x i32> %1981, i32 %1975
  %1983 = icmp eq i32 %1982, 0
  %1984 = and i1 %1980, %1983
  %1985 = and i1 %1973, %1984
  %1986 = xor i1 %1985, true
  %1987 = and i1 true, %1986
  %1988 = xor i8 %1976, -1
  %1989 = icmp ne i8 %1988, 0
  %1990 = xor i1 %1989, true
  %1991 = and i1 %1987, %1990
  br i1 %1991, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.1
  br i1 %178, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %1992 = call i8 @llvm.cttz.i8(i8 %1988, i1 false)
  %1993 = zext i8 %1992 to i32
  %1994 = select i1 %1989, i32 %1993, i32 0
  %1995 = trunc i32 %1994 to i8
  %1996 = shl i8 1, %1995
  %1997 = or i8 %1976, %1996
  %1998 = select i1 %1987, i8 %1997, i8 %1976
  store i8 %1998, ptr %frame.active, align 1
  %1999 = load <8 x i32>, ptr %frame.static.id, align 32
  %2000 = extractelement <8 x i32> %1999, i32 %1994
  %2001 = select i1 %1987, i32 0, i32 %2000
  %2002 = load <8 x i32>, ptr %frame.static.id, align 32
  %2003 = insertelement <8 x i32> %2002, i32 %2001, i32 %1994
  store <8 x i32> %2003, ptr %frame.static.id, align 32
  %2004 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2005 = extractelement <8 x i32> %2004, i32 %1994
  %2006 = select i1 %1987, i32 %1972, i32 %2005
  %2007 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2008 = insertelement <8 x i32> %2007, i32 %2006, i32 %1994
  store <8 x i32> %2008, ptr %frame.parent.token, align 32
  %2009 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1994
  %2010 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1994
  %2011 = load <8 x i1>, ptr %2009, align 1
  %2012 = load <8 x i1>, ptr %2010, align 1
  %2013 = select i1 %1987, <8 x i1> %168, <8 x i1> %2011
  store <8 x i1> %2013, ptr %2009, align 1
  %2014 = select i1 %1987, <8 x i1> zeroinitializer, <8 x i1> %2012
  store <8 x i1> %2014, ptr %2010, align 1
  %2015 = add i32 %1994, 1
  %2016 = select i1 %1985, i32 %1972, i32 %2015
  %2017 = select i1 true, i32 %2016, i32 %1972
  store i32 %2017, ptr %current.token, align 4
  %2018 = load i32, ptr %current.token, align 4
  %2019 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %175)
  %2020 = load i32, ptr %ready.count, align 4
  %2021 = icmp uge i32 %2020, 8
  %2022 = and i1 %2019, %2021
  br i1 %2022, label %ready.overflow.trap220, label %ready.overflow.resume221

ready.overflow.trap220:                           ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume221:                         ; preds = %convergence.overflow.resume
  %2023 = select i1 %2019, i32 %2020, i32 0
  %2024 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2023
  %2025 = load <8 x i1>, ptr %2024, align 1
  %2026 = select i1 %2019, <8 x i1> %175, <8 x i1> %2025
  store <8 x i1> %2026, ptr %2024, align 1
  %2027 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2023
  %2028 = load i32, ptr %2027, align 4
  %2029 = select i1 %2019, i32 2, i32 %2028
  store i32 %2029, ptr %2027, align 4
  %2030 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2023
  %2031 = load i32, ptr %2030, align 4
  %2032 = select i1 %2019, i32 %2018, i32 %2031
  store i32 %2032, ptr %2030, align 4
  %2033 = add i32 %2020, 1
  %2034 = select i1 %2019, i32 %2033, i32 %2020
  store i32 %2034, ptr %ready.count, align 4
  %2035 = load <8 x i1>, ptr %runnable.mask, align 1
  %2036 = or <8 x i1> %2035, %175
  store <8 x i1> %2036, ptr %runnable.mask, align 1
  store <8 x i1> %177, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %168, ptr %current.mask, align 1
  %2037 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %168)
  br i1 %2037, label %schedule.2, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %168, ptr %current.mask, align 1
  %2038 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %168)
  br i1 %2038, label %schedule.5, label %scheduler.loop

varying.divergent225:                             ; preds = %schedule.2
  %2039 = load i32, ptr %current.token, align 4
  %2040 = icmp ne i32 %2039, 0
  %2041 = sub i32 %2039, 1
  %2042 = select i1 %2040, i32 %2041, i32 0
  %2043 = load i8, ptr %frame.active, align 1
  %2044 = trunc i32 %2042 to i8
  %2045 = shl i8 1, %2044
  %2046 = and i8 %2043, %2045
  %2047 = icmp ne i8 %2046, 0
  %2048 = load <8 x i32>, ptr %frame.static.id, align 32
  %2049 = extractelement <8 x i32> %2048, i32 %2042
  %2050 = icmp eq i32 %2049, 1
  %2051 = and i1 %2047, %2050
  %2052 = and i1 %2040, %2051
  %2053 = xor i1 %2052, true
  %2054 = and i1 true, %2053
  %2055 = xor i8 %2043, -1
  %2056 = icmp ne i8 %2055, 0
  %2057 = xor i1 %2056, true
  %2058 = and i1 %2054, %2057
  br i1 %2058, label %convergence.overflow.trap227, label %convergence.overflow.resume228

varying.coherent226:                              ; preds = %schedule.2
  br i1 %210, label %varying.coherent.true231, label %varying.coherent.false232

convergence.overflow.trap227:                     ; preds = %varying.divergent225
  call void @llvm.trap()
  unreachable

convergence.overflow.resume228:                   ; preds = %varying.divergent225
  %2059 = call i8 @llvm.cttz.i8(i8 %2055, i1 false)
  %2060 = zext i8 %2059 to i32
  %2061 = select i1 %2056, i32 %2060, i32 0
  %2062 = trunc i32 %2061 to i8
  %2063 = shl i8 1, %2062
  %2064 = or i8 %2043, %2063
  %2065 = select i1 %2054, i8 %2064, i8 %2043
  store i8 %2065, ptr %frame.active, align 1
  %2066 = load <8 x i32>, ptr %frame.static.id, align 32
  %2067 = extractelement <8 x i32> %2066, i32 %2061
  %2068 = select i1 %2054, i32 1, i32 %2067
  %2069 = load <8 x i32>, ptr %frame.static.id, align 32
  %2070 = insertelement <8 x i32> %2069, i32 %2068, i32 %2061
  store <8 x i32> %2070, ptr %frame.static.id, align 32
  %2071 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2072 = extractelement <8 x i32> %2071, i32 %2061
  %2073 = select i1 %2054, i32 %2039, i32 %2072
  %2074 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2075 = insertelement <8 x i32> %2074, i32 %2073, i32 %2061
  store <8 x i32> %2075, ptr %frame.parent.token, align 32
  %2076 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2061
  %2077 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2061
  %2078 = load <8 x i1>, ptr %2076, align 1
  %2079 = load <8 x i1>, ptr %2077, align 1
  %2080 = select i1 %2054, <8 x i1> %181, <8 x i1> %2078
  store <8 x i1> %2080, ptr %2076, align 1
  %2081 = select i1 %2054, <8 x i1> zeroinitializer, <8 x i1> %2079
  store <8 x i1> %2081, ptr %2077, align 1
  %2082 = add i32 %2061, 1
  %2083 = select i1 %2052, i32 %2039, i32 %2082
  %2084 = select i1 true, i32 %2083, i32 %2039
  store i32 %2084, ptr %current.token, align 4
  %2085 = load <8 x float>, ptr %.slot64, align 32
  %2086 = select <8 x i1> %209, <8 x float> zeroinitializer, <8 x float> %2085
  store <8 x float> %2086, ptr %.slot64, align 32
  %2087 = load i32, ptr %current.token, align 4
  %2088 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %207)
  %2089 = load i32, ptr %ready.count, align 4
  %2090 = icmp uge i32 %2089, 8
  %2091 = and i1 %2088, %2090
  br i1 %2091, label %ready.overflow.trap229, label %ready.overflow.resume230

ready.overflow.trap229:                           ; preds = %convergence.overflow.resume228
  call void @llvm.trap()
  unreachable

ready.overflow.resume230:                         ; preds = %convergence.overflow.resume228
  %2092 = select i1 %2088, i32 %2089, i32 0
  %2093 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2092
  %2094 = load <8 x i1>, ptr %2093, align 1
  %2095 = select i1 %2088, <8 x i1> %207, <8 x i1> %2094
  store <8 x i1> %2095, ptr %2093, align 1
  %2096 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2092
  %2097 = load i32, ptr %2096, align 4
  %2098 = select i1 %2088, i32 3, i32 %2097
  store i32 %2098, ptr %2096, align 4
  %2099 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2092
  %2100 = load i32, ptr %2099, align 4
  %2101 = select i1 %2088, i32 %2087, i32 %2100
  store i32 %2101, ptr %2099, align 4
  %2102 = add i32 %2089, 1
  %2103 = select i1 %2088, i32 %2102, i32 %2089
  store i32 %2103, ptr %ready.count, align 4
  %2104 = load <8 x i1>, ptr %runnable.mask, align 1
  %2105 = or <8 x i1> %2104, %207
  store <8 x i1> %2105, ptr %runnable.mask, align 1
  store <8 x i1> %209, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true231:                         ; preds = %varying.coherent226
  store <8 x i1> %181, ptr %current.mask, align 1
  %2106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %181)
  br i1 %2106, label %schedule.3, label %scheduler.loop

varying.coherent.false232:                        ; preds = %varying.coherent226
  %2107 = load <8 x float>, ptr %.slot64, align 32
  %2108 = select <8 x i1> %181, <8 x float> zeroinitializer, <8 x float> %2107
  store <8 x float> %2108, ptr %.slot64, align 32
  store <8 x i1> %181, ptr %current.mask, align 1
  %2109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %181)
  br i1 %2109, label %schedule.4, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.flow = phi <8 x i1> [ %226, %schedule.4 ], [ %2152, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.4 ], [ %2153, %convergence.cascade ]
  %2110 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %2111 = load i32, ptr %current.token, align 4
  %2112 = icmp ne i32 %2111, 0
  %2113 = and i1 %2110, %2112
  %2114 = sub i32 %2111, 1
  %2115 = select i1 %2113, i32 %2114, i32 0
  %2116 = load i8, ptr %frame.active, align 1
  %2117 = trunc i32 %2115 to i8
  %2118 = shl i8 1, %2117
  %2119 = and i8 %2116, %2118
  %2120 = icmp ne i8 %2119, 0
  %2121 = load <8 x i32>, ptr %frame.static.id, align 32
  %2122 = extractelement <8 x i32> %2121, i32 %2115
  %convergence.target.pointer = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2122
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %2123 = icmp eq i32 %convergence.dynamic.target, 4
  %2124 = and i1 %2120, %2123
  %2125 = and i1 %2113, %2124
  %2126 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2115
  %2127 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2115
  %2128 = load <8 x i1>, ptr %2126, align 1
  %2129 = load <8 x i1>, ptr %2127, align 1
  %2130 = or <8 x i1> %2129, %convergence.cascade.flow
  %2131 = load <8 x i1>, ptr %live.mask, align 1
  %2132 = and <8 x i1> %2128, %2131
  %2133 = icmp eq <8 x i1> %2130, %2132
  %2134 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2133)
  %2135 = and i1 %2125, %2134
  %2136 = select i1 %2135, <8 x i1> zeroinitializer, <8 x i1> %2130
  %2137 = select i1 %2125, <8 x i1> %2136, <8 x i1> %2129
  store <8 x i1> %2137, ptr %2127, align 1
  %2138 = select i1 %2135, <8 x i1> zeroinitializer, <8 x i1> %2128
  store <8 x i1> %2138, ptr %2126, align 1
  %2139 = trunc i32 %2115 to i8
  %2140 = shl i8 1, %2139
  %2141 = xor i8 %2140, -1
  %2142 = and i8 %2116, %2141
  %2143 = select i1 %2135, i8 %2142, i8 %2116
  store i8 %2143, ptr %frame.active, align 1
  %.splatinsert234 = insertelement <8 x i1> poison, i1 %2125, i64 0
  %.splat235 = shufflevector <8 x i1> %.splatinsert234, <8 x i1> poison, <8 x i32> zeroinitializer
  %2144 = and <8 x i1> %convergence.cascade.flow, %.splat235
  %2145 = load <8 x i1>, ptr %runnable.mask, align 1
  %2146 = xor <8 x i1> %2144, splat (i1 true)
  %2147 = and <8 x i1> %2145, %2146
  store <8 x i1> %2147, ptr %runnable.mask, align 1
  %.splatinsert236 = insertelement <8 x i1> poison, i1 %2135, i64 0
  %.splat237 = shufflevector <8 x i1> %.splatinsert236, <8 x i1> poison, <8 x i32> zeroinitializer
  %2148 = select <8 x i1> %.splat237, <8 x i1> %2130, <8 x i1> zeroinitializer
  %2149 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2150 = extractelement <8 x i32> %2149, i32 %2115
  %2151 = select i1 %2135, i32 %2150, i32 %2111
  store i32 %2151, ptr %current.token, align 4
  %.splatinsert238 = insertelement <8 x i1> poison, i1 %2125, i64 0
  %.splat239 = shufflevector <8 x i1> %.splatinsert238, <8 x i1> poison, <8 x i32> zeroinitializer
  %2152 = select <8 x i1> %.splat239, <8 x i1> %2148, <8 x i1> %convergence.cascade.flow
  %2153 = add i32 %convergence.cascade.depth, 1
  %2154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2152)
  %2155 = icmp ult i32 %2153, 8
  %2156 = and i1 %2154, %2155
  %2157 = and i1 %2125, %2156
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %2158 = and i1 %2157, %convergence.parent.present
  br i1 %2158, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.result = phi <8 x i1> [ %226, %schedule.4 ], [ %2152, %convergence.cascade ]
  %2159 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %2159, label %convergence.target.4.ready, label %scheduler.loop

convergence.target.4.ready:                       ; preds = %convergence.cascade.exit
  %2160 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %2161 = bitcast <8 x i1> %convergence.cascade.result to i8
  %2162 = call i8 @llvm.cttz.i8(i8 %2161, i1 false)
  %2163 = zext i8 %2162 to i32
  %2164 = select i1 %2160, i32 %2163, i32 0
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %2166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state240 = load <8 x i64>, ptr %.slot, align 64
  %2167 = mul <8 x i64> %.state240, splat (i64 32)
  %2168 = add <8 x i64> %2166, %2167
  %2169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2165, 0
  %2170 = insertvalue { <8 x ptr>, <8 x i64> } %2169, <8 x i64> %2168, 1
  %.state241 = load <8 x float>, ptr %.slot64, align 32
  %2171 = extractvalue { <8 x ptr>, <8 x i64> } %2170, 0
  %2172 = extractvalue { <8 x ptr>, <8 x i64> } %2170, 1
  %2173 = getelementptr i8, <8 x ptr> %2171, <8 x i64> %2172
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state241, <8 x ptr> align 1 %2173, <8 x i1> %convergence.cascade.result)
  %.state242 = load <8 x i64>, ptr %.slot, align 64
  %2174 = add <8 x i64> %.state242, splat (i64 1)
  %2175 = load <8 x i64>, ptr %.slot, align 64
  %2176 = select <8 x i1> %convergence.cascade.result, <8 x i64> %2174, <8 x i64> %2175
  store <8 x i64> %2176, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %2177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %2177, label %schedule.1, label %scheduler.loop

convergence.cascade243:                           ; preds = %convergence.cascade243, %schedule.5
  %convergence.cascade.flow247 = phi <8 x i1> [ %227, %schedule.5 ], [ %2220, %convergence.cascade243 ]
  %convergence.cascade.depth248 = phi i32 [ 0, %schedule.5 ], [ %2221, %convergence.cascade243 ]
  %2178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow247)
  %2179 = load i32, ptr %current.token, align 4
  %2180 = icmp ne i32 %2179, 0
  %2181 = and i1 %2178, %2180
  %2182 = sub i32 %2179, 1
  %2183 = select i1 %2181, i32 %2182, i32 0
  %2184 = load i8, ptr %frame.active, align 1
  %2185 = trunc i32 %2183 to i8
  %2186 = shl i8 1, %2185
  %2187 = and i8 %2184, %2186
  %2188 = icmp ne i8 %2187, 0
  %2189 = load <8 x i32>, ptr %frame.static.id, align 32
  %2190 = extractelement <8 x i32> %2189, i32 %2183
  %convergence.target.pointer249 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2190
  %convergence.dynamic.target250 = load i32, ptr %convergence.target.pointer249, align 4
  %2191 = icmp eq i32 %convergence.dynamic.target250, 5
  %2192 = and i1 %2188, %2191
  %2193 = and i1 %2181, %2192
  %2194 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2183
  %2195 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2183
  %2196 = load <8 x i1>, ptr %2194, align 1
  %2197 = load <8 x i1>, ptr %2195, align 1
  %2198 = or <8 x i1> %2197, %convergence.cascade.flow247
  %2199 = load <8 x i1>, ptr %live.mask, align 1
  %2200 = and <8 x i1> %2196, %2199
  %2201 = icmp eq <8 x i1> %2198, %2200
  %2202 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2201)
  %2203 = and i1 %2193, %2202
  %2204 = select i1 %2203, <8 x i1> zeroinitializer, <8 x i1> %2198
  %2205 = select i1 %2193, <8 x i1> %2204, <8 x i1> %2197
  store <8 x i1> %2205, ptr %2195, align 1
  %2206 = select i1 %2203, <8 x i1> zeroinitializer, <8 x i1> %2196
  store <8 x i1> %2206, ptr %2194, align 1
  %2207 = trunc i32 %2183 to i8
  %2208 = shl i8 1, %2207
  %2209 = xor i8 %2208, -1
  %2210 = and i8 %2184, %2209
  %2211 = select i1 %2203, i8 %2210, i8 %2184
  store i8 %2211, ptr %frame.active, align 1
  %.splatinsert251 = insertelement <8 x i1> poison, i1 %2193, i64 0
  %.splat252 = shufflevector <8 x i1> %.splatinsert251, <8 x i1> poison, <8 x i32> zeroinitializer
  %2212 = and <8 x i1> %convergence.cascade.flow247, %.splat252
  %2213 = load <8 x i1>, ptr %runnable.mask, align 1
  %2214 = xor <8 x i1> %2212, splat (i1 true)
  %2215 = and <8 x i1> %2213, %2214
  store <8 x i1> %2215, ptr %runnable.mask, align 1
  %.splatinsert253 = insertelement <8 x i1> poison, i1 %2203, i64 0
  %.splat254 = shufflevector <8 x i1> %.splatinsert253, <8 x i1> poison, <8 x i32> zeroinitializer
  %2216 = select <8 x i1> %.splat254, <8 x i1> %2198, <8 x i1> zeroinitializer
  %2217 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2218 = extractelement <8 x i32> %2217, i32 %2183
  %2219 = select i1 %2203, i32 %2218, i32 %2179
  store i32 %2219, ptr %current.token, align 4
  %.splatinsert255 = insertelement <8 x i1> poison, i1 %2193, i64 0
  %.splat256 = shufflevector <8 x i1> %.splatinsert255, <8 x i1> poison, <8 x i32> zeroinitializer
  %2220 = select <8 x i1> %.splat256, <8 x i1> %2216, <8 x i1> %convergence.cascade.flow247
  %2221 = add i32 %convergence.cascade.depth248, 1
  %2222 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2220)
  %2223 = icmp ult i32 %2221, 8
  %2224 = and i1 %2222, %2223
  %2225 = and i1 %2193, %2224
  %convergence.parent.token257 = load i32, ptr %current.token, align 4
  %convergence.parent.present258 = icmp ne i32 %convergence.parent.token257, 0
  %2226 = and i1 %2225, %convergence.parent.present258
  br i1 %2226, label %convergence.cascade243, label %convergence.cascade.exit244

convergence.cascade.exit244:                      ; preds = %convergence.cascade243, %schedule.5
  %convergence.cascade.result259 = phi <8 x i1> [ %227, %schedule.5 ], [ %2220, %convergence.cascade243 ]
  %2227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result259)
  br i1 %2227, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit244
  %2228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result259)
  %2229 = bitcast <8 x i1> %convergence.cascade.result259 to i8
  %2230 = call i8 @llvm.cttz.i8(i8 %2229, i1 false)
  %2231 = zext i8 %2230 to i32
  %2232 = select i1 %2228, i32 %2231, i32 0
  %2233 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %2234 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %2235 = extractvalue { <8 x ptr>, <8 x i64> } %2233, 0
  %2236 = select <8 x i1> %convergence.cascade.result259, <8 x ptr> %2234, <8 x ptr> %2235
  %2237 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %2238 = extractvalue { <8 x ptr>, <8 x i64> } %2233, 1
  %2239 = select <8 x i1> %convergence.cascade.result259, <8 x i64> %2237, <8 x i64> %2238
  %2240 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2236, 0
  %2241 = insertvalue { <8 x ptr>, <8 x i64> } %2240, <8 x i64> %2239, 1
  store { <8 x ptr>, <8 x i64> } %2241, ptr %tile_snapshot.spill65, align 64
  %2242 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %2243 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %2244 = extractvalue { <8 x ptr>, <8 x i64> } %2242, 0
  %2245 = select <8 x i1> %convergence.cascade.result259, <8 x ptr> %2243, <8 x ptr> %2244
  %2246 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %2247 = extractvalue { <8 x ptr>, <8 x i64> } %2242, 1
  %2248 = select <8 x i1> %convergence.cascade.result259, <8 x i64> %2246, <8 x i64> %2247
  %2249 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2245, 0
  %2250 = insertvalue { <8 x ptr>, <8 x i64> } %2249, <8 x i64> %2248, 1
  store { <8 x ptr>, <8 x i64> } %2250, ptr %tile_snapshot.spill66, align 64
  %2251 = load <8 x i64>, ptr %.slot67, align 64
  %2252 = select <8 x i1> %convergence.cascade.result259, <8 x i64> zeroinitializer, <8 x i64> %2251
  store <8 x i64> %2252, ptr %.slot67, align 64
  store <8 x i1> %convergence.cascade.result259, ptr %current.mask, align 1
  %2253 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result259)
  br i1 %2253, label %schedule.6, label %scheduler.loop

varying.divergent261:                             ; preds = %schedule.6
  %2254 = load i32, ptr %current.token, align 4
  %2255 = icmp ne i32 %2254, 0
  %2256 = sub i32 %2254, 1
  %2257 = select i1 %2255, i32 %2256, i32 0
  %2258 = load i8, ptr %frame.active, align 1
  %2259 = trunc i32 %2257 to i8
  %2260 = shl i8 1, %2259
  %2261 = and i8 %2258, %2260
  %2262 = icmp ne i8 %2261, 0
  %2263 = load <8 x i32>, ptr %frame.static.id, align 32
  %2264 = extractelement <8 x i32> %2263, i32 %2257
  %2265 = icmp eq i32 %2264, 2
  %2266 = and i1 %2262, %2265
  %2267 = and i1 %2255, %2266
  %2268 = xor i1 %2267, true
  %2269 = and i1 true, %2268
  %2270 = xor i8 %2258, -1
  %2271 = icmp ne i8 %2270, 0
  %2272 = xor i1 %2271, true
  %2273 = and i1 %2269, %2272
  br i1 %2273, label %convergence.overflow.trap263, label %convergence.overflow.resume264

varying.coherent262:                              ; preds = %schedule.6
  br i1 %238, label %varying.coherent.true267, label %varying.coherent.false268

convergence.overflow.trap263:                     ; preds = %varying.divergent261
  call void @llvm.trap()
  unreachable

convergence.overflow.resume264:                   ; preds = %varying.divergent261
  %2274 = call i8 @llvm.cttz.i8(i8 %2270, i1 false)
  %2275 = zext i8 %2274 to i32
  %2276 = select i1 %2271, i32 %2275, i32 0
  %2277 = trunc i32 %2276 to i8
  %2278 = shl i8 1, %2277
  %2279 = or i8 %2258, %2278
  %2280 = select i1 %2269, i8 %2279, i8 %2258
  store i8 %2280, ptr %frame.active, align 1
  %2281 = load <8 x i32>, ptr %frame.static.id, align 32
  %2282 = extractelement <8 x i32> %2281, i32 %2276
  %2283 = select i1 %2269, i32 2, i32 %2282
  %2284 = load <8 x i32>, ptr %frame.static.id, align 32
  %2285 = insertelement <8 x i32> %2284, i32 %2283, i32 %2276
  store <8 x i32> %2285, ptr %frame.static.id, align 32
  %2286 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2287 = extractelement <8 x i32> %2286, i32 %2276
  %2288 = select i1 %2269, i32 %2254, i32 %2287
  %2289 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2290 = insertelement <8 x i32> %2289, i32 %2288, i32 %2276
  store <8 x i32> %2290, ptr %frame.parent.token, align 32
  %2291 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2276
  %2292 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2276
  %2293 = load <8 x i1>, ptr %2291, align 1
  %2294 = load <8 x i1>, ptr %2292, align 1
  %2295 = select i1 %2269, <8 x i1> %228, <8 x i1> %2293
  store <8 x i1> %2295, ptr %2291, align 1
  %2296 = select i1 %2269, <8 x i1> zeroinitializer, <8 x i1> %2294
  store <8 x i1> %2296, ptr %2292, align 1
  %2297 = add i32 %2276, 1
  %2298 = select i1 %2267, i32 %2254, i32 %2297
  %2299 = select i1 true, i32 %2298, i32 %2254
  store i32 %2299, ptr %current.token, align 4
  %2300 = load i32, ptr %current.token, align 4
  %2301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %235)
  %2302 = load i32, ptr %ready.count, align 4
  %2303 = icmp uge i32 %2302, 8
  %2304 = and i1 %2301, %2303
  br i1 %2304, label %ready.overflow.trap265, label %ready.overflow.resume266

ready.overflow.trap265:                           ; preds = %convergence.overflow.resume264
  call void @llvm.trap()
  unreachable

ready.overflow.resume266:                         ; preds = %convergence.overflow.resume264
  %2305 = select i1 %2301, i32 %2302, i32 0
  %2306 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2305
  %2307 = load <8 x i1>, ptr %2306, align 1
  %2308 = select i1 %2301, <8 x i1> %235, <8 x i1> %2307
  store <8 x i1> %2308, ptr %2306, align 1
  %2309 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2305
  %2310 = load i32, ptr %2309, align 4
  %2311 = select i1 %2301, i32 7, i32 %2310
  store i32 %2311, ptr %2309, align 4
  %2312 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2305
  %2313 = load i32, ptr %2312, align 4
  %2314 = select i1 %2301, i32 %2300, i32 %2313
  store i32 %2314, ptr %2312, align 4
  %2315 = add i32 %2302, 1
  %2316 = select i1 %2301, i32 %2315, i32 %2302
  store i32 %2316, ptr %ready.count, align 4
  %2317 = load <8 x i1>, ptr %runnable.mask, align 1
  %2318 = or <8 x i1> %2317, %235
  store <8 x i1> %2318, ptr %runnable.mask, align 1
  store <8 x i1> %237, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true267:                         ; preds = %varying.coherent262
  store <8 x i1> %228, ptr %current.mask, align 1
  %2319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  br i1 %2319, label %schedule.7, label %scheduler.loop

varying.coherent.false268:                        ; preds = %varying.coherent262
  store <8 x i1> %228, ptr %current.mask, align 1
  %2320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  br i1 %2320, label %schedule.8, label %scheduler.loop

convergence.cascade272:                           ; preds = %convergence.cascade272, %schedule.8
  %convergence.cascade.flow276 = phi <8 x i1> [ %260, %schedule.8 ], [ %2363, %convergence.cascade272 ]
  %convergence.cascade.depth277 = phi i32 [ 0, %schedule.8 ], [ %2364, %convergence.cascade272 ]
  %2321 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow276)
  %2322 = load i32, ptr %current.token, align 4
  %2323 = icmp ne i32 %2322, 0
  %2324 = and i1 %2321, %2323
  %2325 = sub i32 %2322, 1
  %2326 = select i1 %2324, i32 %2325, i32 0
  %2327 = load i8, ptr %frame.active, align 1
  %2328 = trunc i32 %2326 to i8
  %2329 = shl i8 1, %2328
  %2330 = and i8 %2327, %2329
  %2331 = icmp ne i8 %2330, 0
  %2332 = load <8 x i32>, ptr %frame.static.id, align 32
  %2333 = extractelement <8 x i32> %2332, i32 %2326
  %convergence.target.pointer278 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2333
  %convergence.dynamic.target279 = load i32, ptr %convergence.target.pointer278, align 4
  %2334 = icmp eq i32 %convergence.dynamic.target279, 8
  %2335 = and i1 %2331, %2334
  %2336 = and i1 %2324, %2335
  %2337 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2326
  %2338 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2326
  %2339 = load <8 x i1>, ptr %2337, align 1
  %2340 = load <8 x i1>, ptr %2338, align 1
  %2341 = or <8 x i1> %2340, %convergence.cascade.flow276
  %2342 = load <8 x i1>, ptr %live.mask, align 1
  %2343 = and <8 x i1> %2339, %2342
  %2344 = icmp eq <8 x i1> %2341, %2343
  %2345 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2344)
  %2346 = and i1 %2336, %2345
  %2347 = select i1 %2346, <8 x i1> zeroinitializer, <8 x i1> %2341
  %2348 = select i1 %2336, <8 x i1> %2347, <8 x i1> %2340
  store <8 x i1> %2348, ptr %2338, align 1
  %2349 = select i1 %2346, <8 x i1> zeroinitializer, <8 x i1> %2339
  store <8 x i1> %2349, ptr %2337, align 1
  %2350 = trunc i32 %2326 to i8
  %2351 = shl i8 1, %2350
  %2352 = xor i8 %2351, -1
  %2353 = and i8 %2327, %2352
  %2354 = select i1 %2346, i8 %2353, i8 %2327
  store i8 %2354, ptr %frame.active, align 1
  %.splatinsert280 = insertelement <8 x i1> poison, i1 %2336, i64 0
  %.splat281 = shufflevector <8 x i1> %.splatinsert280, <8 x i1> poison, <8 x i32> zeroinitializer
  %2355 = and <8 x i1> %convergence.cascade.flow276, %.splat281
  %2356 = load <8 x i1>, ptr %runnable.mask, align 1
  %2357 = xor <8 x i1> %2355, splat (i1 true)
  %2358 = and <8 x i1> %2356, %2357
  store <8 x i1> %2358, ptr %runnable.mask, align 1
  %.splatinsert282 = insertelement <8 x i1> poison, i1 %2346, i64 0
  %.splat283 = shufflevector <8 x i1> %.splatinsert282, <8 x i1> poison, <8 x i32> zeroinitializer
  %2359 = select <8 x i1> %.splat283, <8 x i1> %2341, <8 x i1> zeroinitializer
  %2360 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2361 = extractelement <8 x i32> %2360, i32 %2326
  %2362 = select i1 %2346, i32 %2361, i32 %2322
  store i32 %2362, ptr %current.token, align 4
  %.splatinsert284 = insertelement <8 x i1> poison, i1 %2336, i64 0
  %.splat285 = shufflevector <8 x i1> %.splatinsert284, <8 x i1> poison, <8 x i32> zeroinitializer
  %2363 = select <8 x i1> %.splat285, <8 x i1> %2359, <8 x i1> %convergence.cascade.flow276
  %2364 = add i32 %convergence.cascade.depth277, 1
  %2365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2363)
  %2366 = icmp ult i32 %2364, 8
  %2367 = and i1 %2365, %2366
  %2368 = and i1 %2336, %2367
  %convergence.parent.token286 = load i32, ptr %current.token, align 4
  %convergence.parent.present287 = icmp ne i32 %convergence.parent.token286, 0
  %2369 = and i1 %2368, %convergence.parent.present287
  br i1 %2369, label %convergence.cascade272, label %convergence.cascade.exit273

convergence.cascade.exit273:                      ; preds = %convergence.cascade272, %schedule.8
  %convergence.cascade.result288 = phi <8 x i1> [ %260, %schedule.8 ], [ %2363, %convergence.cascade272 ]
  %2370 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result288)
  br i1 %2370, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit273
  %2371 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result288)
  %2372 = bitcast <8 x i1> %convergence.cascade.result288 to i8
  %2373 = call i8 @llvm.cttz.i8(i8 %2372, i1 false)
  %2374 = zext i8 %2373 to i32
  %2375 = select i1 %2371, i32 %2374, i32 0
  %2376 = load <8 x i64>, ptr %.slot68, align 64
  %2377 = select <8 x i1> %convergence.cascade.result288, <8 x i64> zeroinitializer, <8 x i64> %2376
  store <8 x i64> %2377, ptr %.slot68, align 64
  %2378 = load <8 x float>, ptr %.slot69, align 32
  %2379 = select <8 x i1> %convergence.cascade.result288, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2378
  store <8 x float> %2379, ptr %.slot69, align 32
  %2380 = load <8 x float>, ptr %.slot70, align 32
  %2381 = select <8 x i1> %convergence.cascade.result288, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2380
  store <8 x float> %2381, ptr %.slot70, align 32
  %2382 = load <8 x float>, ptr %.slot71, align 32
  %2383 = select <8 x i1> %convergence.cascade.result288, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2382
  store <8 x float> %2383, ptr %.slot71, align 32
  %2384 = load <8 x float>, ptr %.slot72, align 32
  %2385 = select <8 x i1> %convergence.cascade.result288, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2384
  store <8 x float> %2385, ptr %.slot72, align 32
  %2386 = load <8 x float>, ptr %.slot73, align 32
  %2387 = select <8 x i1> %convergence.cascade.result288, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2386
  store <8 x float> %2387, ptr %.slot73, align 32
  %2388 = load <8 x float>, ptr %.slot74, align 32
  %2389 = select <8 x i1> %convergence.cascade.result288, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2388
  store <8 x float> %2389, ptr %.slot74, align 32
  %2390 = load <8 x float>, ptr %.slot75, align 32
  %2391 = select <8 x i1> %convergence.cascade.result288, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2390
  store <8 x float> %2391, ptr %.slot75, align 32
  %2392 = load <8 x float>, ptr %.slot76, align 32
  %2393 = select <8 x i1> %convergence.cascade.result288, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2392
  store <8 x float> %2393, ptr %.slot76, align 32
  %2394 = load <8 x float>, ptr %.slot77, align 32
  %2395 = select <8 x i1> %convergence.cascade.result288, <8 x float> zeroinitializer, <8 x float> %2394
  store <8 x float> %2395, ptr %.slot77, align 32
  %2396 = load <8 x float>, ptr %.slot78, align 32
  %2397 = select <8 x i1> %convergence.cascade.result288, <8 x float> zeroinitializer, <8 x float> %2396
  store <8 x float> %2397, ptr %.slot78, align 32
  %2398 = load <8 x float>, ptr %.slot79, align 32
  %2399 = select <8 x i1> %convergence.cascade.result288, <8 x float> zeroinitializer, <8 x float> %2398
  store <8 x float> %2399, ptr %.slot79, align 32
  %2400 = load <8 x float>, ptr %.slot80, align 32
  %2401 = select <8 x i1> %convergence.cascade.result288, <8 x float> zeroinitializer, <8 x float> %2400
  store <8 x float> %2401, ptr %.slot80, align 32
  %2402 = load <8 x float>, ptr %.slot81, align 32
  %2403 = select <8 x i1> %convergence.cascade.result288, <8 x float> zeroinitializer, <8 x float> %2402
  store <8 x float> %2403, ptr %.slot81, align 32
  %2404 = load <8 x float>, ptr %.slot82, align 32
  %2405 = select <8 x i1> %convergence.cascade.result288, <8 x float> zeroinitializer, <8 x float> %2404
  store <8 x float> %2405, ptr %.slot82, align 32
  %2406 = load <8 x float>, ptr %.slot83, align 32
  %2407 = select <8 x i1> %convergence.cascade.result288, <8 x float> zeroinitializer, <8 x float> %2406
  store <8 x float> %2407, ptr %.slot83, align 32
  %2408 = load <8 x float>, ptr %.slot84, align 32
  %2409 = select <8 x i1> %convergence.cascade.result288, <8 x float> zeroinitializer, <8 x float> %2408
  store <8 x float> %2409, ptr %.slot84, align 32
  store <8 x i1> %convergence.cascade.result288, ptr %current.mask, align 1
  %2410 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result288)
  br i1 %2410, label %schedule.9, label %scheduler.loop

varying.divergent290:                             ; preds = %schedule.9
  %2411 = load i32, ptr %current.token, align 4
  %2412 = icmp ne i32 %2411, 0
  %2413 = sub i32 %2411, 1
  %2414 = select i1 %2412, i32 %2413, i32 0
  %2415 = load i8, ptr %frame.active, align 1
  %2416 = trunc i32 %2414 to i8
  %2417 = shl i8 1, %2416
  %2418 = and i8 %2415, %2417
  %2419 = icmp ne i8 %2418, 0
  %2420 = load <8 x i32>, ptr %frame.static.id, align 32
  %2421 = extractelement <8 x i32> %2420, i32 %2414
  %2422 = icmp eq i32 %2421, 3
  %2423 = and i1 %2419, %2422
  %2424 = and i1 %2412, %2423
  %2425 = xor i1 %2424, true
  %2426 = and i1 true, %2425
  %2427 = xor i8 %2415, -1
  %2428 = icmp ne i8 %2427, 0
  %2429 = xor i1 %2428, true
  %2430 = and i1 %2426, %2429
  br i1 %2430, label %convergence.overflow.trap292, label %convergence.overflow.resume293

varying.coherent291:                              ; preds = %schedule.9
  br i1 %271, label %varying.coherent.true296, label %varying.coherent.false297

convergence.overflow.trap292:                     ; preds = %varying.divergent290
  call void @llvm.trap()
  unreachable

convergence.overflow.resume293:                   ; preds = %varying.divergent290
  %2431 = call i8 @llvm.cttz.i8(i8 %2427, i1 false)
  %2432 = zext i8 %2431 to i32
  %2433 = select i1 %2428, i32 %2432, i32 0
  %2434 = trunc i32 %2433 to i8
  %2435 = shl i8 1, %2434
  %2436 = or i8 %2415, %2435
  %2437 = select i1 %2426, i8 %2436, i8 %2415
  store i8 %2437, ptr %frame.active, align 1
  %2438 = load <8 x i32>, ptr %frame.static.id, align 32
  %2439 = extractelement <8 x i32> %2438, i32 %2433
  %2440 = select i1 %2426, i32 3, i32 %2439
  %2441 = load <8 x i32>, ptr %frame.static.id, align 32
  %2442 = insertelement <8 x i32> %2441, i32 %2440, i32 %2433
  store <8 x i32> %2442, ptr %frame.static.id, align 32
  %2443 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2444 = extractelement <8 x i32> %2443, i32 %2433
  %2445 = select i1 %2426, i32 %2411, i32 %2444
  %2446 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2447 = insertelement <8 x i32> %2446, i32 %2445, i32 %2433
  store <8 x i32> %2447, ptr %frame.parent.token, align 32
  %2448 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2433
  %2449 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2433
  %2450 = load <8 x i1>, ptr %2448, align 1
  %2451 = load <8 x i1>, ptr %2449, align 1
  %2452 = select i1 %2426, <8 x i1> %261, <8 x i1> %2450
  store <8 x i1> %2452, ptr %2448, align 1
  %2453 = select i1 %2426, <8 x i1> zeroinitializer, <8 x i1> %2451
  store <8 x i1> %2453, ptr %2449, align 1
  %2454 = add i32 %2433, 1
  %2455 = select i1 %2424, i32 %2411, i32 %2454
  %2456 = select i1 true, i32 %2455, i32 %2411
  store i32 %2456, ptr %current.token, align 4
  %2457 = load i32, ptr %current.token, align 4
  %2458 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %268)
  %2459 = load i32, ptr %ready.count, align 4
  %2460 = icmp uge i32 %2459, 8
  %2461 = and i1 %2458, %2460
  br i1 %2461, label %ready.overflow.trap294, label %ready.overflow.resume295

ready.overflow.trap294:                           ; preds = %convergence.overflow.resume293
  call void @llvm.trap()
  unreachable

ready.overflow.resume295:                         ; preds = %convergence.overflow.resume293
  %2462 = select i1 %2458, i32 %2459, i32 0
  %2463 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2462
  %2464 = load <8 x i1>, ptr %2463, align 1
  %2465 = select i1 %2458, <8 x i1> %268, <8 x i1> %2464
  store <8 x i1> %2465, ptr %2463, align 1
  %2466 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2462
  %2467 = load i32, ptr %2466, align 4
  %2468 = select i1 %2458, i32 10, i32 %2467
  store i32 %2468, ptr %2466, align 4
  %2469 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2462
  %2470 = load i32, ptr %2469, align 4
  %2471 = select i1 %2458, i32 %2457, i32 %2470
  store i32 %2471, ptr %2469, align 4
  %2472 = add i32 %2459, 1
  %2473 = select i1 %2458, i32 %2472, i32 %2459
  store i32 %2473, ptr %ready.count, align 4
  %2474 = load <8 x i1>, ptr %runnable.mask, align 1
  %2475 = or <8 x i1> %2474, %268
  store <8 x i1> %2475, ptr %runnable.mask, align 1
  store <8 x i1> %270, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true296:                         ; preds = %varying.coherent291
  store <8 x i1> %261, ptr %current.mask, align 1
  %2476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %261)
  br i1 %2476, label %schedule.10, label %scheduler.loop

varying.coherent.false297:                        ; preds = %varying.coherent291
  store <8 x i1> %261, ptr %current.mask, align 1
  %2477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %261)
  br i1 %2477, label %schedule.102, label %scheduler.loop

varying.divergent300:                             ; preds = %schedule.11
  %2478 = load i32, ptr %current.token, align 4
  %2479 = icmp ne i32 %2478, 0
  %2480 = sub i32 %2478, 1
  %2481 = select i1 %2479, i32 %2480, i32 0
  %2482 = load i8, ptr %frame.active, align 1
  %2483 = trunc i32 %2481 to i8
  %2484 = shl i8 1, %2483
  %2485 = and i8 %2482, %2484
  %2486 = icmp ne i8 %2485, 0
  %2487 = load <8 x i32>, ptr %frame.static.id, align 32
  %2488 = extractelement <8 x i32> %2487, i32 %2481
  %2489 = icmp eq i32 %2488, 4
  %2490 = and i1 %2486, %2489
  %2491 = and i1 %2479, %2490
  %2492 = xor i1 %2491, true
  %2493 = and i1 true, %2492
  %2494 = xor i8 %2482, -1
  %2495 = icmp ne i8 %2494, 0
  %2496 = xor i1 %2495, true
  %2497 = and i1 %2493, %2496
  br i1 %2497, label %convergence.overflow.trap302, label %convergence.overflow.resume303

varying.coherent301:                              ; preds = %schedule.11
  br i1 %308, label %varying.coherent.true306, label %varying.coherent.false307

convergence.overflow.trap302:                     ; preds = %varying.divergent300
  call void @llvm.trap()
  unreachable

convergence.overflow.resume303:                   ; preds = %varying.divergent300
  %2498 = call i8 @llvm.cttz.i8(i8 %2494, i1 false)
  %2499 = zext i8 %2498 to i32
  %2500 = select i1 %2495, i32 %2499, i32 0
  %2501 = trunc i32 %2500 to i8
  %2502 = shl i8 1, %2501
  %2503 = or i8 %2482, %2502
  %2504 = select i1 %2493, i8 %2503, i8 %2482
  store i8 %2504, ptr %frame.active, align 1
  %2505 = load <8 x i32>, ptr %frame.static.id, align 32
  %2506 = extractelement <8 x i32> %2505, i32 %2500
  %2507 = select i1 %2493, i32 4, i32 %2506
  %2508 = load <8 x i32>, ptr %frame.static.id, align 32
  %2509 = insertelement <8 x i32> %2508, i32 %2507, i32 %2500
  store <8 x i32> %2509, ptr %frame.static.id, align 32
  %2510 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2511 = extractelement <8 x i32> %2510, i32 %2500
  %2512 = select i1 %2493, i32 %2478, i32 %2511
  %2513 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2514 = insertelement <8 x i32> %2513, i32 %2512, i32 %2500
  store <8 x i32> %2514, ptr %frame.parent.token, align 32
  %2515 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2500
  %2516 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2500
  %2517 = load <8 x i1>, ptr %2515, align 1
  %2518 = load <8 x i1>, ptr %2516, align 1
  %2519 = select i1 %2493, <8 x i1> %298, <8 x i1> %2517
  store <8 x i1> %2519, ptr %2515, align 1
  %2520 = select i1 %2493, <8 x i1> zeroinitializer, <8 x i1> %2518
  store <8 x i1> %2520, ptr %2516, align 1
  %2521 = add i32 %2500, 1
  %2522 = select i1 %2491, i32 %2478, i32 %2521
  %2523 = select i1 true, i32 %2522, i32 %2478
  store i32 %2523, ptr %current.token, align 4
  %2524 = load i32, ptr %current.token, align 4
  %2525 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %305)
  %2526 = load i32, ptr %ready.count, align 4
  %2527 = icmp uge i32 %2526, 8
  %2528 = and i1 %2525, %2527
  br i1 %2528, label %ready.overflow.trap304, label %ready.overflow.resume305

ready.overflow.trap304:                           ; preds = %convergence.overflow.resume303
  call void @llvm.trap()
  unreachable

ready.overflow.resume305:                         ; preds = %convergence.overflow.resume303
  %2529 = select i1 %2525, i32 %2526, i32 0
  %2530 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2529
  %2531 = load <8 x i1>, ptr %2530, align 1
  %2532 = select i1 %2525, <8 x i1> %305, <8 x i1> %2531
  store <8 x i1> %2532, ptr %2530, align 1
  %2533 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2529
  %2534 = load i32, ptr %2533, align 4
  %2535 = select i1 %2525, i32 12, i32 %2534
  store i32 %2535, ptr %2533, align 4
  %2536 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2529
  %2537 = load i32, ptr %2536, align 4
  %2538 = select i1 %2525, i32 %2524, i32 %2537
  store i32 %2538, ptr %2536, align 4
  %2539 = add i32 %2526, 1
  %2540 = select i1 %2525, i32 %2539, i32 %2526
  store i32 %2540, ptr %ready.count, align 4
  %2541 = load <8 x i1>, ptr %runnable.mask, align 1
  %2542 = or <8 x i1> %2541, %305
  store <8 x i1> %2542, ptr %runnable.mask, align 1
  store <8 x i1> %307, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true306:                         ; preds = %varying.coherent301
  store <8 x i1> %298, ptr %current.mask, align 1
  %2543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %298)
  br i1 %2543, label %schedule.12, label %scheduler.loop

varying.coherent.false307:                        ; preds = %varying.coherent301
  store <8 x i1> %298, ptr %current.mask, align 1
  %2544 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %298)
  br i1 %2544, label %schedule.15, label %scheduler.loop

varying.divergent312:                             ; preds = %schedule.12
  %2545 = load i32, ptr %current.token, align 4
  %2546 = icmp ne i32 %2545, 0
  %2547 = sub i32 %2545, 1
  %2548 = select i1 %2546, i32 %2547, i32 0
  %2549 = load i8, ptr %frame.active, align 1
  %2550 = trunc i32 %2548 to i8
  %2551 = shl i8 1, %2550
  %2552 = and i8 %2549, %2551
  %2553 = icmp ne i8 %2552, 0
  %2554 = load <8 x i32>, ptr %frame.static.id, align 32
  %2555 = extractelement <8 x i32> %2554, i32 %2548
  %2556 = icmp eq i32 %2555, 5
  %2557 = and i1 %2553, %2556
  %2558 = and i1 %2546, %2557
  %2559 = xor i1 %2558, true
  %2560 = and i1 true, %2559
  %2561 = xor i8 %2549, -1
  %2562 = icmp ne i8 %2561, 0
  %2563 = xor i1 %2562, true
  %2564 = and i1 %2560, %2563
  br i1 %2564, label %convergence.overflow.trap314, label %convergence.overflow.resume315

varying.coherent313:                              ; preds = %schedule.12
  br i1 %340, label %varying.coherent.true318, label %varying.coherent.false319

convergence.overflow.trap314:                     ; preds = %varying.divergent312
  call void @llvm.trap()
  unreachable

convergence.overflow.resume315:                   ; preds = %varying.divergent312
  %2565 = call i8 @llvm.cttz.i8(i8 %2561, i1 false)
  %2566 = zext i8 %2565 to i32
  %2567 = select i1 %2562, i32 %2566, i32 0
  %2568 = trunc i32 %2567 to i8
  %2569 = shl i8 1, %2568
  %2570 = or i8 %2549, %2569
  %2571 = select i1 %2560, i8 %2570, i8 %2549
  store i8 %2571, ptr %frame.active, align 1
  %2572 = load <8 x i32>, ptr %frame.static.id, align 32
  %2573 = extractelement <8 x i32> %2572, i32 %2567
  %2574 = select i1 %2560, i32 5, i32 %2573
  %2575 = load <8 x i32>, ptr %frame.static.id, align 32
  %2576 = insertelement <8 x i32> %2575, i32 %2574, i32 %2567
  store <8 x i32> %2576, ptr %frame.static.id, align 32
  %2577 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2578 = extractelement <8 x i32> %2577, i32 %2567
  %2579 = select i1 %2560, i32 %2545, i32 %2578
  %2580 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2581 = insertelement <8 x i32> %2580, i32 %2579, i32 %2567
  store <8 x i32> %2581, ptr %frame.parent.token, align 32
  %2582 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2567
  %2583 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2567
  %2584 = load <8 x i1>, ptr %2582, align 1
  %2585 = load <8 x i1>, ptr %2583, align 1
  %2586 = select i1 %2560, <8 x i1> %311, <8 x i1> %2584
  store <8 x i1> %2586, ptr %2582, align 1
  %2587 = select i1 %2560, <8 x i1> zeroinitializer, <8 x i1> %2585
  store <8 x i1> %2587, ptr %2583, align 1
  %2588 = add i32 %2567, 1
  %2589 = select i1 %2558, i32 %2545, i32 %2588
  %2590 = select i1 true, i32 %2589, i32 %2545
  store i32 %2590, ptr %current.token, align 4
  %2591 = load <8 x float>, ptr %.slot89, align 32
  %2592 = select <8 x i1> %339, <8 x float> zeroinitializer, <8 x float> %2591
  store <8 x float> %2592, ptr %.slot89, align 32
  %2593 = load i32, ptr %current.token, align 4
  %2594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %337)
  %2595 = load i32, ptr %ready.count, align 4
  %2596 = icmp uge i32 %2595, 8
  %2597 = and i1 %2594, %2596
  br i1 %2597, label %ready.overflow.trap316, label %ready.overflow.resume317

ready.overflow.trap316:                           ; preds = %convergence.overflow.resume315
  call void @llvm.trap()
  unreachable

ready.overflow.resume317:                         ; preds = %convergence.overflow.resume315
  %2598 = select i1 %2594, i32 %2595, i32 0
  %2599 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2598
  %2600 = load <8 x i1>, ptr %2599, align 1
  %2601 = select i1 %2594, <8 x i1> %337, <8 x i1> %2600
  store <8 x i1> %2601, ptr %2599, align 1
  %2602 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2598
  %2603 = load i32, ptr %2602, align 4
  %2604 = select i1 %2594, i32 13, i32 %2603
  store i32 %2604, ptr %2602, align 4
  %2605 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2598
  %2606 = load i32, ptr %2605, align 4
  %2607 = select i1 %2594, i32 %2593, i32 %2606
  store i32 %2607, ptr %2605, align 4
  %2608 = add i32 %2595, 1
  %2609 = select i1 %2594, i32 %2608, i32 %2595
  store i32 %2609, ptr %ready.count, align 4
  %2610 = load <8 x i1>, ptr %runnable.mask, align 1
  %2611 = or <8 x i1> %2610, %337
  store <8 x i1> %2611, ptr %runnable.mask, align 1
  store <8 x i1> %339, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true318:                         ; preds = %varying.coherent313
  store <8 x i1> %311, ptr %current.mask, align 1
  %2612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %311)
  br i1 %2612, label %schedule.13, label %scheduler.loop

varying.coherent.false319:                        ; preds = %varying.coherent313
  %2613 = load <8 x float>, ptr %.slot89, align 32
  %2614 = select <8 x i1> %311, <8 x float> zeroinitializer, <8 x float> %2613
  store <8 x float> %2614, ptr %.slot89, align 32
  store <8 x i1> %311, ptr %current.mask, align 1
  %2615 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %311)
  br i1 %2615, label %schedule.14, label %scheduler.loop

convergence.cascade321:                           ; preds = %convergence.cascade321, %schedule.14
  %convergence.cascade.flow325 = phi <8 x i1> [ %356, %schedule.14 ], [ %2658, %convergence.cascade321 ]
  %convergence.cascade.depth326 = phi i32 [ 0, %schedule.14 ], [ %2659, %convergence.cascade321 ]
  %2616 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow325)
  %2617 = load i32, ptr %current.token, align 4
  %2618 = icmp ne i32 %2617, 0
  %2619 = and i1 %2616, %2618
  %2620 = sub i32 %2617, 1
  %2621 = select i1 %2619, i32 %2620, i32 0
  %2622 = load i8, ptr %frame.active, align 1
  %2623 = trunc i32 %2621 to i8
  %2624 = shl i8 1, %2623
  %2625 = and i8 %2622, %2624
  %2626 = icmp ne i8 %2625, 0
  %2627 = load <8 x i32>, ptr %frame.static.id, align 32
  %2628 = extractelement <8 x i32> %2627, i32 %2621
  %convergence.target.pointer327 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2628
  %convergence.dynamic.target328 = load i32, ptr %convergence.target.pointer327, align 4
  %2629 = icmp eq i32 %convergence.dynamic.target328, 14
  %2630 = and i1 %2626, %2629
  %2631 = and i1 %2619, %2630
  %2632 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2621
  %2633 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2621
  %2634 = load <8 x i1>, ptr %2632, align 1
  %2635 = load <8 x i1>, ptr %2633, align 1
  %2636 = or <8 x i1> %2635, %convergence.cascade.flow325
  %2637 = load <8 x i1>, ptr %live.mask, align 1
  %2638 = and <8 x i1> %2634, %2637
  %2639 = icmp eq <8 x i1> %2636, %2638
  %2640 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2639)
  %2641 = and i1 %2631, %2640
  %2642 = select i1 %2641, <8 x i1> zeroinitializer, <8 x i1> %2636
  %2643 = select i1 %2631, <8 x i1> %2642, <8 x i1> %2635
  store <8 x i1> %2643, ptr %2633, align 1
  %2644 = select i1 %2641, <8 x i1> zeroinitializer, <8 x i1> %2634
  store <8 x i1> %2644, ptr %2632, align 1
  %2645 = trunc i32 %2621 to i8
  %2646 = shl i8 1, %2645
  %2647 = xor i8 %2646, -1
  %2648 = and i8 %2622, %2647
  %2649 = select i1 %2641, i8 %2648, i8 %2622
  store i8 %2649, ptr %frame.active, align 1
  %.splatinsert329 = insertelement <8 x i1> poison, i1 %2631, i64 0
  %.splat330 = shufflevector <8 x i1> %.splatinsert329, <8 x i1> poison, <8 x i32> zeroinitializer
  %2650 = and <8 x i1> %convergence.cascade.flow325, %.splat330
  %2651 = load <8 x i1>, ptr %runnable.mask, align 1
  %2652 = xor <8 x i1> %2650, splat (i1 true)
  %2653 = and <8 x i1> %2651, %2652
  store <8 x i1> %2653, ptr %runnable.mask, align 1
  %.splatinsert331 = insertelement <8 x i1> poison, i1 %2641, i64 0
  %.splat332 = shufflevector <8 x i1> %.splatinsert331, <8 x i1> poison, <8 x i32> zeroinitializer
  %2654 = select <8 x i1> %.splat332, <8 x i1> %2636, <8 x i1> zeroinitializer
  %2655 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2656 = extractelement <8 x i32> %2655, i32 %2621
  %2657 = select i1 %2641, i32 %2656, i32 %2617
  store i32 %2657, ptr %current.token, align 4
  %.splatinsert333 = insertelement <8 x i1> poison, i1 %2631, i64 0
  %.splat334 = shufflevector <8 x i1> %.splatinsert333, <8 x i1> poison, <8 x i32> zeroinitializer
  %2658 = select <8 x i1> %.splat334, <8 x i1> %2654, <8 x i1> %convergence.cascade.flow325
  %2659 = add i32 %convergence.cascade.depth326, 1
  %2660 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2658)
  %2661 = icmp ult i32 %2659, 8
  %2662 = and i1 %2660, %2661
  %2663 = and i1 %2631, %2662
  %convergence.parent.token335 = load i32, ptr %current.token, align 4
  %convergence.parent.present336 = icmp ne i32 %convergence.parent.token335, 0
  %2664 = and i1 %2663, %convergence.parent.present336
  br i1 %2664, label %convergence.cascade321, label %convergence.cascade.exit322

convergence.cascade.exit322:                      ; preds = %convergence.cascade321, %schedule.14
  %convergence.cascade.result337 = phi <8 x i1> [ %356, %schedule.14 ], [ %2658, %convergence.cascade321 ]
  %2665 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result337)
  br i1 %2665, label %convergence.target.14.ready, label %scheduler.loop

convergence.target.14.ready:                      ; preds = %convergence.cascade.exit322
  %2666 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result337)
  %2667 = bitcast <8 x i1> %convergence.cascade.result337 to i8
  %2668 = call i8 @llvm.cttz.i8(i8 %2667, i1 false)
  %2669 = zext i8 %2668 to i32
  %2670 = select i1 %2666, i32 %2669, i32 0
  %tile_snapshot.spill.load338 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill86, align 64
  %2671 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load338, 0
  %2672 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load338, 1
  %.state339 = load <8 x i64>, ptr %.slot87, align 64
  %2673 = mul <8 x i64> %.state339, splat (i64 32)
  %2674 = add <8 x i64> %2672, %2673
  %2675 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2671, 0
  %2676 = insertvalue { <8 x ptr>, <8 x i64> } %2675, <8 x i64> %2674, 1
  %.state340 = load <8 x float>, ptr %.slot89, align 32
  %2677 = extractvalue { <8 x ptr>, <8 x i64> } %2676, 0
  %2678 = extractvalue { <8 x ptr>, <8 x i64> } %2676, 1
  %2679 = getelementptr i8, <8 x ptr> %2677, <8 x i64> %2678
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state340, <8 x ptr> align 1 %2679, <8 x i1> %convergence.cascade.result337)
  %.state341 = load <8 x i64>, ptr %.slot87, align 64
  %2680 = add <8 x i64> %.state341, splat (i64 1)
  %2681 = load <8 x i64>, ptr %.slot87, align 64
  %2682 = select <8 x i1> %convergence.cascade.result337, <8 x i64> %2680, <8 x i64> %2681
  store <8 x i64> %2682, ptr %.slot87, align 64
  store <8 x i1> %convergence.cascade.result337, ptr %current.mask, align 1
  %2683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result337)
  br i1 %2683, label %schedule.11, label %scheduler.loop

convergence.cascade342:                           ; preds = %convergence.cascade342, %schedule.15
  %convergence.cascade.flow346 = phi <8 x i1> [ %357, %schedule.15 ], [ %2726, %convergence.cascade342 ]
  %convergence.cascade.depth347 = phi i32 [ 0, %schedule.15 ], [ %2727, %convergence.cascade342 ]
  %2684 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow346)
  %2685 = load i32, ptr %current.token, align 4
  %2686 = icmp ne i32 %2685, 0
  %2687 = and i1 %2684, %2686
  %2688 = sub i32 %2685, 1
  %2689 = select i1 %2687, i32 %2688, i32 0
  %2690 = load i8, ptr %frame.active, align 1
  %2691 = trunc i32 %2689 to i8
  %2692 = shl i8 1, %2691
  %2693 = and i8 %2690, %2692
  %2694 = icmp ne i8 %2693, 0
  %2695 = load <8 x i32>, ptr %frame.static.id, align 32
  %2696 = extractelement <8 x i32> %2695, i32 %2689
  %convergence.target.pointer348 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2696
  %convergence.dynamic.target349 = load i32, ptr %convergence.target.pointer348, align 4
  %2697 = icmp eq i32 %convergence.dynamic.target349, 15
  %2698 = and i1 %2694, %2697
  %2699 = and i1 %2687, %2698
  %2700 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2689
  %2701 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2689
  %2702 = load <8 x i1>, ptr %2700, align 1
  %2703 = load <8 x i1>, ptr %2701, align 1
  %2704 = or <8 x i1> %2703, %convergence.cascade.flow346
  %2705 = load <8 x i1>, ptr %live.mask, align 1
  %2706 = and <8 x i1> %2702, %2705
  %2707 = icmp eq <8 x i1> %2704, %2706
  %2708 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2707)
  %2709 = and i1 %2699, %2708
  %2710 = select i1 %2709, <8 x i1> zeroinitializer, <8 x i1> %2704
  %2711 = select i1 %2699, <8 x i1> %2710, <8 x i1> %2703
  store <8 x i1> %2711, ptr %2701, align 1
  %2712 = select i1 %2709, <8 x i1> zeroinitializer, <8 x i1> %2702
  store <8 x i1> %2712, ptr %2700, align 1
  %2713 = trunc i32 %2689 to i8
  %2714 = shl i8 1, %2713
  %2715 = xor i8 %2714, -1
  %2716 = and i8 %2690, %2715
  %2717 = select i1 %2709, i8 %2716, i8 %2690
  store i8 %2717, ptr %frame.active, align 1
  %.splatinsert350 = insertelement <8 x i1> poison, i1 %2699, i64 0
  %.splat351 = shufflevector <8 x i1> %.splatinsert350, <8 x i1> poison, <8 x i32> zeroinitializer
  %2718 = and <8 x i1> %convergence.cascade.flow346, %.splat351
  %2719 = load <8 x i1>, ptr %runnable.mask, align 1
  %2720 = xor <8 x i1> %2718, splat (i1 true)
  %2721 = and <8 x i1> %2719, %2720
  store <8 x i1> %2721, ptr %runnable.mask, align 1
  %.splatinsert352 = insertelement <8 x i1> poison, i1 %2709, i64 0
  %.splat353 = shufflevector <8 x i1> %.splatinsert352, <8 x i1> poison, <8 x i32> zeroinitializer
  %2722 = select <8 x i1> %.splat353, <8 x i1> %2704, <8 x i1> zeroinitializer
  %2723 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2724 = extractelement <8 x i32> %2723, i32 %2689
  %2725 = select i1 %2709, i32 %2724, i32 %2685
  store i32 %2725, ptr %current.token, align 4
  %.splatinsert354 = insertelement <8 x i1> poison, i1 %2699, i64 0
  %.splat355 = shufflevector <8 x i1> %.splatinsert354, <8 x i1> poison, <8 x i32> zeroinitializer
  %2726 = select <8 x i1> %.splat355, <8 x i1> %2722, <8 x i1> %convergence.cascade.flow346
  %2727 = add i32 %convergence.cascade.depth347, 1
  %2728 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2726)
  %2729 = icmp ult i32 %2727, 8
  %2730 = and i1 %2728, %2729
  %2731 = and i1 %2699, %2730
  %convergence.parent.token356 = load i32, ptr %current.token, align 4
  %convergence.parent.present357 = icmp ne i32 %convergence.parent.token356, 0
  %2732 = and i1 %2731, %convergence.parent.present357
  br i1 %2732, label %convergence.cascade342, label %convergence.cascade.exit343

convergence.cascade.exit343:                      ; preds = %convergence.cascade342, %schedule.15
  %convergence.cascade.result358 = phi <8 x i1> [ %357, %schedule.15 ], [ %2726, %convergence.cascade342 ]
  %2733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result358)
  br i1 %2733, label %convergence.target.15.ready, label %scheduler.loop

convergence.target.15.ready:                      ; preds = %convergence.cascade.exit343
  %2734 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result358)
  %2735 = bitcast <8 x i1> %convergence.cascade.result358 to i8
  %2736 = call i8 @llvm.cttz.i8(i8 %2735, i1 false)
  %2737 = zext i8 %2736 to i32
  %2738 = select i1 %2734, i32 %2737, i32 0
  %2739 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %2740 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2741 = extractvalue { <8 x ptr>, <8 x i64> } %2739, 0
  %2742 = select <8 x i1> %convergence.cascade.result358, <8 x ptr> %2740, <8 x ptr> %2741
  %2743 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %2744 = extractvalue { <8 x ptr>, <8 x i64> } %2739, 1
  %2745 = select <8 x i1> %convergence.cascade.result358, <8 x i64> %2743, <8 x i64> %2744
  %2746 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2742, 0
  %2747 = insertvalue { <8 x ptr>, <8 x i64> } %2746, <8 x i64> %2745, 1
  store { <8 x ptr>, <8 x i64> } %2747, ptr %tile_snapshot.spill90, align 64
  %2748 = load <8 x i64>, ptr %.slot91, align 64
  %2749 = select <8 x i1> %convergence.cascade.result358, <8 x i64> zeroinitializer, <8 x i64> %2748
  store <8 x i64> %2749, ptr %.slot91, align 64
  store <8 x i1> %convergence.cascade.result358, ptr %current.mask, align 1
  %2750 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result358)
  br i1 %2750, label %schedule.16, label %scheduler.loop

varying.divergent360:                             ; preds = %schedule.16
  %2751 = load i32, ptr %current.token, align 4
  %2752 = icmp ne i32 %2751, 0
  %2753 = sub i32 %2751, 1
  %2754 = select i1 %2752, i32 %2753, i32 0
  %2755 = load i8, ptr %frame.active, align 1
  %2756 = trunc i32 %2754 to i8
  %2757 = shl i8 1, %2756
  %2758 = and i8 %2755, %2757
  %2759 = icmp ne i8 %2758, 0
  %2760 = load <8 x i32>, ptr %frame.static.id, align 32
  %2761 = extractelement <8 x i32> %2760, i32 %2754
  %2762 = icmp eq i32 %2761, 6
  %2763 = and i1 %2759, %2762
  %2764 = and i1 %2752, %2763
  %2765 = xor i1 %2764, true
  %2766 = and i1 true, %2765
  %2767 = xor i8 %2755, -1
  %2768 = icmp ne i8 %2767, 0
  %2769 = xor i1 %2768, true
  %2770 = and i1 %2766, %2769
  br i1 %2770, label %convergence.overflow.trap362, label %convergence.overflow.resume363

varying.coherent361:                              ; preds = %schedule.16
  br i1 %368, label %varying.coherent.true366, label %varying.coherent.false367

convergence.overflow.trap362:                     ; preds = %varying.divergent360
  call void @llvm.trap()
  unreachable

convergence.overflow.resume363:                   ; preds = %varying.divergent360
  %2771 = call i8 @llvm.cttz.i8(i8 %2767, i1 false)
  %2772 = zext i8 %2771 to i32
  %2773 = select i1 %2768, i32 %2772, i32 0
  %2774 = trunc i32 %2773 to i8
  %2775 = shl i8 1, %2774
  %2776 = or i8 %2755, %2775
  %2777 = select i1 %2766, i8 %2776, i8 %2755
  store i8 %2777, ptr %frame.active, align 1
  %2778 = load <8 x i32>, ptr %frame.static.id, align 32
  %2779 = extractelement <8 x i32> %2778, i32 %2773
  %2780 = select i1 %2766, i32 6, i32 %2779
  %2781 = load <8 x i32>, ptr %frame.static.id, align 32
  %2782 = insertelement <8 x i32> %2781, i32 %2780, i32 %2773
  store <8 x i32> %2782, ptr %frame.static.id, align 32
  %2783 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2784 = extractelement <8 x i32> %2783, i32 %2773
  %2785 = select i1 %2766, i32 %2751, i32 %2784
  %2786 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2787 = insertelement <8 x i32> %2786, i32 %2785, i32 %2773
  store <8 x i32> %2787, ptr %frame.parent.token, align 32
  %2788 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2773
  %2789 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2773
  %2790 = load <8 x i1>, ptr %2788, align 1
  %2791 = load <8 x i1>, ptr %2789, align 1
  %2792 = select i1 %2766, <8 x i1> %358, <8 x i1> %2790
  store <8 x i1> %2792, ptr %2788, align 1
  %2793 = select i1 %2766, <8 x i1> zeroinitializer, <8 x i1> %2791
  store <8 x i1> %2793, ptr %2789, align 1
  %2794 = add i32 %2773, 1
  %2795 = select i1 %2764, i32 %2751, i32 %2794
  %2796 = select i1 true, i32 %2795, i32 %2751
  store i32 %2796, ptr %current.token, align 4
  %2797 = load i32, ptr %current.token, align 4
  %2798 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %365)
  %2799 = load i32, ptr %ready.count, align 4
  %2800 = icmp uge i32 %2799, 8
  %2801 = and i1 %2798, %2800
  br i1 %2801, label %ready.overflow.trap364, label %ready.overflow.resume365

ready.overflow.trap364:                           ; preds = %convergence.overflow.resume363
  call void @llvm.trap()
  unreachable

ready.overflow.resume365:                         ; preds = %convergence.overflow.resume363
  %2802 = select i1 %2798, i32 %2799, i32 0
  %2803 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2802
  %2804 = load <8 x i1>, ptr %2803, align 1
  %2805 = select i1 %2798, <8 x i1> %365, <8 x i1> %2804
  store <8 x i1> %2805, ptr %2803, align 1
  %2806 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2802
  %2807 = load i32, ptr %2806, align 4
  %2808 = select i1 %2798, i32 17, i32 %2807
  store i32 %2808, ptr %2806, align 4
  %2809 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2802
  %2810 = load i32, ptr %2809, align 4
  %2811 = select i1 %2798, i32 %2797, i32 %2810
  store i32 %2811, ptr %2809, align 4
  %2812 = add i32 %2799, 1
  %2813 = select i1 %2798, i32 %2812, i32 %2799
  store i32 %2813, ptr %ready.count, align 4
  %2814 = load <8 x i1>, ptr %runnable.mask, align 1
  %2815 = or <8 x i1> %2814, %365
  store <8 x i1> %2815, ptr %runnable.mask, align 1
  store <8 x i1> %367, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true366:                         ; preds = %varying.coherent361
  store <8 x i1> %358, ptr %current.mask, align 1
  %2816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %358)
  br i1 %2816, label %schedule.17, label %scheduler.loop

varying.coherent.false367:                        ; preds = %varying.coherent361
  store <8 x i1> %358, ptr %current.mask, align 1
  %2817 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %358)
  br i1 %2817, label %schedule.20, label %scheduler.loop

varying.divergent372:                             ; preds = %schedule.17
  %2818 = load i32, ptr %current.token, align 4
  %2819 = icmp ne i32 %2818, 0
  %2820 = sub i32 %2818, 1
  %2821 = select i1 %2819, i32 %2820, i32 0
  %2822 = load i8, ptr %frame.active, align 1
  %2823 = trunc i32 %2821 to i8
  %2824 = shl i8 1, %2823
  %2825 = and i8 %2822, %2824
  %2826 = icmp ne i8 %2825, 0
  %2827 = load <8 x i32>, ptr %frame.static.id, align 32
  %2828 = extractelement <8 x i32> %2827, i32 %2821
  %2829 = icmp eq i32 %2828, 7
  %2830 = and i1 %2826, %2829
  %2831 = and i1 %2819, %2830
  %2832 = xor i1 %2831, true
  %2833 = and i1 true, %2832
  %2834 = xor i8 %2822, -1
  %2835 = icmp ne i8 %2834, 0
  %2836 = xor i1 %2835, true
  %2837 = and i1 %2833, %2836
  br i1 %2837, label %convergence.overflow.trap374, label %convergence.overflow.resume375

varying.coherent373:                              ; preds = %schedule.17
  br i1 %400, label %varying.coherent.true378, label %varying.coherent.false379

convergence.overflow.trap374:                     ; preds = %varying.divergent372
  call void @llvm.trap()
  unreachable

convergence.overflow.resume375:                   ; preds = %varying.divergent372
  %2838 = call i8 @llvm.cttz.i8(i8 %2834, i1 false)
  %2839 = zext i8 %2838 to i32
  %2840 = select i1 %2835, i32 %2839, i32 0
  %2841 = trunc i32 %2840 to i8
  %2842 = shl i8 1, %2841
  %2843 = or i8 %2822, %2842
  %2844 = select i1 %2833, i8 %2843, i8 %2822
  store i8 %2844, ptr %frame.active, align 1
  %2845 = load <8 x i32>, ptr %frame.static.id, align 32
  %2846 = extractelement <8 x i32> %2845, i32 %2840
  %2847 = select i1 %2833, i32 7, i32 %2846
  %2848 = load <8 x i32>, ptr %frame.static.id, align 32
  %2849 = insertelement <8 x i32> %2848, i32 %2847, i32 %2840
  store <8 x i32> %2849, ptr %frame.static.id, align 32
  %2850 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2851 = extractelement <8 x i32> %2850, i32 %2840
  %2852 = select i1 %2833, i32 %2818, i32 %2851
  %2853 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2854 = insertelement <8 x i32> %2853, i32 %2852, i32 %2840
  store <8 x i32> %2854, ptr %frame.parent.token, align 32
  %2855 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2840
  %2856 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2840
  %2857 = load <8 x i1>, ptr %2855, align 1
  %2858 = load <8 x i1>, ptr %2856, align 1
  %2859 = select i1 %2833, <8 x i1> %371, <8 x i1> %2857
  store <8 x i1> %2859, ptr %2855, align 1
  %2860 = select i1 %2833, <8 x i1> zeroinitializer, <8 x i1> %2858
  store <8 x i1> %2860, ptr %2856, align 1
  %2861 = add i32 %2840, 1
  %2862 = select i1 %2831, i32 %2818, i32 %2861
  %2863 = select i1 true, i32 %2862, i32 %2818
  store i32 %2863, ptr %current.token, align 4
  %2864 = load <8 x float>, ptr %.slot93, align 32
  %2865 = select <8 x i1> %399, <8 x float> zeroinitializer, <8 x float> %2864
  store <8 x float> %2865, ptr %.slot93, align 32
  %2866 = load i32, ptr %current.token, align 4
  %2867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %397)
  %2868 = load i32, ptr %ready.count, align 4
  %2869 = icmp uge i32 %2868, 8
  %2870 = and i1 %2867, %2869
  br i1 %2870, label %ready.overflow.trap376, label %ready.overflow.resume377

ready.overflow.trap376:                           ; preds = %convergence.overflow.resume375
  call void @llvm.trap()
  unreachable

ready.overflow.resume377:                         ; preds = %convergence.overflow.resume375
  %2871 = select i1 %2867, i32 %2868, i32 0
  %2872 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2871
  %2873 = load <8 x i1>, ptr %2872, align 1
  %2874 = select i1 %2867, <8 x i1> %397, <8 x i1> %2873
  store <8 x i1> %2874, ptr %2872, align 1
  %2875 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2871
  %2876 = load i32, ptr %2875, align 4
  %2877 = select i1 %2867, i32 18, i32 %2876
  store i32 %2877, ptr %2875, align 4
  %2878 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2871
  %2879 = load i32, ptr %2878, align 4
  %2880 = select i1 %2867, i32 %2866, i32 %2879
  store i32 %2880, ptr %2878, align 4
  %2881 = add i32 %2868, 1
  %2882 = select i1 %2867, i32 %2881, i32 %2868
  store i32 %2882, ptr %ready.count, align 4
  %2883 = load <8 x i1>, ptr %runnable.mask, align 1
  %2884 = or <8 x i1> %2883, %397
  store <8 x i1> %2884, ptr %runnable.mask, align 1
  store <8 x i1> %399, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true378:                         ; preds = %varying.coherent373
  store <8 x i1> %371, ptr %current.mask, align 1
  %2885 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  br i1 %2885, label %schedule.18, label %scheduler.loop

varying.coherent.false379:                        ; preds = %varying.coherent373
  %2886 = load <8 x float>, ptr %.slot93, align 32
  %2887 = select <8 x i1> %371, <8 x float> zeroinitializer, <8 x float> %2886
  store <8 x float> %2887, ptr %.slot93, align 32
  store <8 x i1> %371, ptr %current.mask, align 1
  %2888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  br i1 %2888, label %schedule.19, label %scheduler.loop

convergence.cascade381:                           ; preds = %convergence.cascade381, %schedule.19
  %convergence.cascade.flow385 = phi <8 x i1> [ %416, %schedule.19 ], [ %2931, %convergence.cascade381 ]
  %convergence.cascade.depth386 = phi i32 [ 0, %schedule.19 ], [ %2932, %convergence.cascade381 ]
  %2889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow385)
  %2890 = load i32, ptr %current.token, align 4
  %2891 = icmp ne i32 %2890, 0
  %2892 = and i1 %2889, %2891
  %2893 = sub i32 %2890, 1
  %2894 = select i1 %2892, i32 %2893, i32 0
  %2895 = load i8, ptr %frame.active, align 1
  %2896 = trunc i32 %2894 to i8
  %2897 = shl i8 1, %2896
  %2898 = and i8 %2895, %2897
  %2899 = icmp ne i8 %2898, 0
  %2900 = load <8 x i32>, ptr %frame.static.id, align 32
  %2901 = extractelement <8 x i32> %2900, i32 %2894
  %convergence.target.pointer387 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2901
  %convergence.dynamic.target388 = load i32, ptr %convergence.target.pointer387, align 4
  %2902 = icmp eq i32 %convergence.dynamic.target388, 19
  %2903 = and i1 %2899, %2902
  %2904 = and i1 %2892, %2903
  %2905 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2894
  %2906 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2894
  %2907 = load <8 x i1>, ptr %2905, align 1
  %2908 = load <8 x i1>, ptr %2906, align 1
  %2909 = or <8 x i1> %2908, %convergence.cascade.flow385
  %2910 = load <8 x i1>, ptr %live.mask, align 1
  %2911 = and <8 x i1> %2907, %2910
  %2912 = icmp eq <8 x i1> %2909, %2911
  %2913 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2912)
  %2914 = and i1 %2904, %2913
  %2915 = select i1 %2914, <8 x i1> zeroinitializer, <8 x i1> %2909
  %2916 = select i1 %2904, <8 x i1> %2915, <8 x i1> %2908
  store <8 x i1> %2916, ptr %2906, align 1
  %2917 = select i1 %2914, <8 x i1> zeroinitializer, <8 x i1> %2907
  store <8 x i1> %2917, ptr %2905, align 1
  %2918 = trunc i32 %2894 to i8
  %2919 = shl i8 1, %2918
  %2920 = xor i8 %2919, -1
  %2921 = and i8 %2895, %2920
  %2922 = select i1 %2914, i8 %2921, i8 %2895
  store i8 %2922, ptr %frame.active, align 1
  %.splatinsert389 = insertelement <8 x i1> poison, i1 %2904, i64 0
  %.splat390 = shufflevector <8 x i1> %.splatinsert389, <8 x i1> poison, <8 x i32> zeroinitializer
  %2923 = and <8 x i1> %convergence.cascade.flow385, %.splat390
  %2924 = load <8 x i1>, ptr %runnable.mask, align 1
  %2925 = xor <8 x i1> %2923, splat (i1 true)
  %2926 = and <8 x i1> %2924, %2925
  store <8 x i1> %2926, ptr %runnable.mask, align 1
  %.splatinsert391 = insertelement <8 x i1> poison, i1 %2914, i64 0
  %.splat392 = shufflevector <8 x i1> %.splatinsert391, <8 x i1> poison, <8 x i32> zeroinitializer
  %2927 = select <8 x i1> %.splat392, <8 x i1> %2909, <8 x i1> zeroinitializer
  %2928 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2929 = extractelement <8 x i32> %2928, i32 %2894
  %2930 = select i1 %2914, i32 %2929, i32 %2890
  store i32 %2930, ptr %current.token, align 4
  %.splatinsert393 = insertelement <8 x i1> poison, i1 %2904, i64 0
  %.splat394 = shufflevector <8 x i1> %.splatinsert393, <8 x i1> poison, <8 x i32> zeroinitializer
  %2931 = select <8 x i1> %.splat394, <8 x i1> %2927, <8 x i1> %convergence.cascade.flow385
  %2932 = add i32 %convergence.cascade.depth386, 1
  %2933 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2931)
  %2934 = icmp ult i32 %2932, 8
  %2935 = and i1 %2933, %2934
  %2936 = and i1 %2904, %2935
  %convergence.parent.token395 = load i32, ptr %current.token, align 4
  %convergence.parent.present396 = icmp ne i32 %convergence.parent.token395, 0
  %2937 = and i1 %2936, %convergence.parent.present396
  br i1 %2937, label %convergence.cascade381, label %convergence.cascade.exit382

convergence.cascade.exit382:                      ; preds = %convergence.cascade381, %schedule.19
  %convergence.cascade.result397 = phi <8 x i1> [ %416, %schedule.19 ], [ %2931, %convergence.cascade381 ]
  %2938 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result397)
  br i1 %2938, label %convergence.target.19.ready, label %scheduler.loop

convergence.target.19.ready:                      ; preds = %convergence.cascade.exit382
  %2939 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result397)
  %2940 = bitcast <8 x i1> %convergence.cascade.result397 to i8
  %2941 = call i8 @llvm.cttz.i8(i8 %2940, i1 false)
  %2942 = zext i8 %2941 to i32
  %2943 = select i1 %2939, i32 %2942, i32 0
  %tile_snapshot.spill.load398 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %2944 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load398, 0
  %2945 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load398, 1
  %.state399 = load <8 x i64>, ptr %.slot91, align 64
  %2946 = mul <8 x i64> %.state399, splat (i64 32)
  %2947 = add <8 x i64> %2945, %2946
  %2948 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2944, 0
  %2949 = insertvalue { <8 x ptr>, <8 x i64> } %2948, <8 x i64> %2947, 1
  %.state400 = load <8 x float>, ptr %.slot93, align 32
  %2950 = extractvalue { <8 x ptr>, <8 x i64> } %2949, 0
  %2951 = extractvalue { <8 x ptr>, <8 x i64> } %2949, 1
  %2952 = getelementptr i8, <8 x ptr> %2950, <8 x i64> %2951
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state400, <8 x ptr> align 1 %2952, <8 x i1> %convergence.cascade.result397)
  %.state401 = load <8 x i64>, ptr %.slot91, align 64
  %2953 = add <8 x i64> %.state401, splat (i64 1)
  %2954 = load <8 x i64>, ptr %.slot91, align 64
  %2955 = select <8 x i1> %convergence.cascade.result397, <8 x i64> %2953, <8 x i64> %2954
  store <8 x i64> %2955, ptr %.slot91, align 64
  store <8 x i1> %convergence.cascade.result397, ptr %current.mask, align 1
  %2956 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result397)
  br i1 %2956, label %schedule.16, label %scheduler.loop

convergence.cascade402:                           ; preds = %convergence.cascade402, %schedule.20
  %convergence.cascade.flow406 = phi <8 x i1> [ %417, %schedule.20 ], [ %2999, %convergence.cascade402 ]
  %convergence.cascade.depth407 = phi i32 [ 0, %schedule.20 ], [ %3000, %convergence.cascade402 ]
  %2957 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow406)
  %2958 = load i32, ptr %current.token, align 4
  %2959 = icmp ne i32 %2958, 0
  %2960 = and i1 %2957, %2959
  %2961 = sub i32 %2958, 1
  %2962 = select i1 %2960, i32 %2961, i32 0
  %2963 = load i8, ptr %frame.active, align 1
  %2964 = trunc i32 %2962 to i8
  %2965 = shl i8 1, %2964
  %2966 = and i8 %2963, %2965
  %2967 = icmp ne i8 %2966, 0
  %2968 = load <8 x i32>, ptr %frame.static.id, align 32
  %2969 = extractelement <8 x i32> %2968, i32 %2962
  %convergence.target.pointer408 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %2969
  %convergence.dynamic.target409 = load i32, ptr %convergence.target.pointer408, align 4
  %2970 = icmp eq i32 %convergence.dynamic.target409, 20
  %2971 = and i1 %2967, %2970
  %2972 = and i1 %2960, %2971
  %2973 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2962
  %2974 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2962
  %2975 = load <8 x i1>, ptr %2973, align 1
  %2976 = load <8 x i1>, ptr %2974, align 1
  %2977 = or <8 x i1> %2976, %convergence.cascade.flow406
  %2978 = load <8 x i1>, ptr %live.mask, align 1
  %2979 = and <8 x i1> %2975, %2978
  %2980 = icmp eq <8 x i1> %2977, %2979
  %2981 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2980)
  %2982 = and i1 %2972, %2981
  %2983 = select i1 %2982, <8 x i1> zeroinitializer, <8 x i1> %2977
  %2984 = select i1 %2972, <8 x i1> %2983, <8 x i1> %2976
  store <8 x i1> %2984, ptr %2974, align 1
  %2985 = select i1 %2982, <8 x i1> zeroinitializer, <8 x i1> %2975
  store <8 x i1> %2985, ptr %2973, align 1
  %2986 = trunc i32 %2962 to i8
  %2987 = shl i8 1, %2986
  %2988 = xor i8 %2987, -1
  %2989 = and i8 %2963, %2988
  %2990 = select i1 %2982, i8 %2989, i8 %2963
  store i8 %2990, ptr %frame.active, align 1
  %.splatinsert410 = insertelement <8 x i1> poison, i1 %2972, i64 0
  %.splat411 = shufflevector <8 x i1> %.splatinsert410, <8 x i1> poison, <8 x i32> zeroinitializer
  %2991 = and <8 x i1> %convergence.cascade.flow406, %.splat411
  %2992 = load <8 x i1>, ptr %runnable.mask, align 1
  %2993 = xor <8 x i1> %2991, splat (i1 true)
  %2994 = and <8 x i1> %2992, %2993
  store <8 x i1> %2994, ptr %runnable.mask, align 1
  %.splatinsert412 = insertelement <8 x i1> poison, i1 %2982, i64 0
  %.splat413 = shufflevector <8 x i1> %.splatinsert412, <8 x i1> poison, <8 x i32> zeroinitializer
  %2995 = select <8 x i1> %.splat413, <8 x i1> %2977, <8 x i1> zeroinitializer
  %2996 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2997 = extractelement <8 x i32> %2996, i32 %2962
  %2998 = select i1 %2982, i32 %2997, i32 %2958
  store i32 %2998, ptr %current.token, align 4
  %.splatinsert414 = insertelement <8 x i1> poison, i1 %2972, i64 0
  %.splat415 = shufflevector <8 x i1> %.splatinsert414, <8 x i1> poison, <8 x i32> zeroinitializer
  %2999 = select <8 x i1> %.splat415, <8 x i1> %2995, <8 x i1> %convergence.cascade.flow406
  %3000 = add i32 %convergence.cascade.depth407, 1
  %3001 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2999)
  %3002 = icmp ult i32 %3000, 8
  %3003 = and i1 %3001, %3002
  %3004 = and i1 %2972, %3003
  %convergence.parent.token416 = load i32, ptr %current.token, align 4
  %convergence.parent.present417 = icmp ne i32 %convergence.parent.token416, 0
  %3005 = and i1 %3004, %convergence.parent.present417
  br i1 %3005, label %convergence.cascade402, label %convergence.cascade.exit403

convergence.cascade.exit403:                      ; preds = %convergence.cascade402, %schedule.20
  %convergence.cascade.result418 = phi <8 x i1> [ %417, %schedule.20 ], [ %2999, %convergence.cascade402 ]
  %3006 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result418)
  br i1 %3006, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit403
  %3007 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result418)
  %3008 = bitcast <8 x i1> %convergence.cascade.result418 to i8
  %3009 = call i8 @llvm.cttz.i8(i8 %3008, i1 false)
  %3010 = zext i8 %3009 to i32
  %3011 = select i1 %3007, i32 %3010, i32 0
  %3012 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %3013 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3014 = extractvalue { <8 x ptr>, <8 x i64> } %3012, 0
  %3015 = select <8 x i1> %convergence.cascade.result418, <8 x ptr> %3013, <8 x ptr> %3014
  %3016 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3017 = extractvalue { <8 x ptr>, <8 x i64> } %3012, 1
  %3018 = select <8 x i1> %convergence.cascade.result418, <8 x i64> %3016, <8 x i64> %3017
  %3019 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3015, 0
  %3020 = insertvalue { <8 x ptr>, <8 x i64> } %3019, <8 x i64> %3018, 1
  store { <8 x ptr>, <8 x i64> } %3020, ptr %tile_snapshot.spill94, align 64
  %3021 = load <8 x i64>, ptr %.slot95, align 64
  %3022 = select <8 x i1> %convergence.cascade.result418, <8 x i64> zeroinitializer, <8 x i64> %3021
  store <8 x i64> %3022, ptr %.slot95, align 64
  store <8 x i1> %convergence.cascade.result418, ptr %current.mask, align 1
  %3023 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result418)
  br i1 %3023, label %schedule.21, label %scheduler.loop

varying.divergent420:                             ; preds = %schedule.21
  %3024 = load i32, ptr %current.token, align 4
  %3025 = icmp ne i32 %3024, 0
  %3026 = sub i32 %3024, 1
  %3027 = select i1 %3025, i32 %3026, i32 0
  %3028 = load i8, ptr %frame.active, align 1
  %3029 = trunc i32 %3027 to i8
  %3030 = shl i8 1, %3029
  %3031 = and i8 %3028, %3030
  %3032 = icmp ne i8 %3031, 0
  %3033 = load <8 x i32>, ptr %frame.static.id, align 32
  %3034 = extractelement <8 x i32> %3033, i32 %3027
  %3035 = icmp eq i32 %3034, 8
  %3036 = and i1 %3032, %3035
  %3037 = and i1 %3025, %3036
  %3038 = xor i1 %3037, true
  %3039 = and i1 true, %3038
  %3040 = xor i8 %3028, -1
  %3041 = icmp ne i8 %3040, 0
  %3042 = xor i1 %3041, true
  %3043 = and i1 %3039, %3042
  br i1 %3043, label %convergence.overflow.trap422, label %convergence.overflow.resume423

varying.coherent421:                              ; preds = %schedule.21
  br i1 %428, label %varying.coherent.true426, label %varying.coherent.false427

convergence.overflow.trap422:                     ; preds = %varying.divergent420
  call void @llvm.trap()
  unreachable

convergence.overflow.resume423:                   ; preds = %varying.divergent420
  %3044 = call i8 @llvm.cttz.i8(i8 %3040, i1 false)
  %3045 = zext i8 %3044 to i32
  %3046 = select i1 %3041, i32 %3045, i32 0
  %3047 = trunc i32 %3046 to i8
  %3048 = shl i8 1, %3047
  %3049 = or i8 %3028, %3048
  %3050 = select i1 %3039, i8 %3049, i8 %3028
  store i8 %3050, ptr %frame.active, align 1
  %3051 = load <8 x i32>, ptr %frame.static.id, align 32
  %3052 = extractelement <8 x i32> %3051, i32 %3046
  %3053 = select i1 %3039, i32 8, i32 %3052
  %3054 = load <8 x i32>, ptr %frame.static.id, align 32
  %3055 = insertelement <8 x i32> %3054, i32 %3053, i32 %3046
  store <8 x i32> %3055, ptr %frame.static.id, align 32
  %3056 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3057 = extractelement <8 x i32> %3056, i32 %3046
  %3058 = select i1 %3039, i32 %3024, i32 %3057
  %3059 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3060 = insertelement <8 x i32> %3059, i32 %3058, i32 %3046
  store <8 x i32> %3060, ptr %frame.parent.token, align 32
  %3061 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3046
  %3062 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3046
  %3063 = load <8 x i1>, ptr %3061, align 1
  %3064 = load <8 x i1>, ptr %3062, align 1
  %3065 = select i1 %3039, <8 x i1> %418, <8 x i1> %3063
  store <8 x i1> %3065, ptr %3061, align 1
  %3066 = select i1 %3039, <8 x i1> zeroinitializer, <8 x i1> %3064
  store <8 x i1> %3066, ptr %3062, align 1
  %3067 = add i32 %3046, 1
  %3068 = select i1 %3037, i32 %3024, i32 %3067
  %3069 = select i1 true, i32 %3068, i32 %3024
  store i32 %3069, ptr %current.token, align 4
  %3070 = load i32, ptr %current.token, align 4
  %3071 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %425)
  %3072 = load i32, ptr %ready.count, align 4
  %3073 = icmp uge i32 %3072, 8
  %3074 = and i1 %3071, %3073
  br i1 %3074, label %ready.overflow.trap424, label %ready.overflow.resume425

ready.overflow.trap424:                           ; preds = %convergence.overflow.resume423
  call void @llvm.trap()
  unreachable

ready.overflow.resume425:                         ; preds = %convergence.overflow.resume423
  %3075 = select i1 %3071, i32 %3072, i32 0
  %3076 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3075
  %3077 = load <8 x i1>, ptr %3076, align 1
  %3078 = select i1 %3071, <8 x i1> %425, <8 x i1> %3077
  store <8 x i1> %3078, ptr %3076, align 1
  %3079 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3075
  %3080 = load i32, ptr %3079, align 4
  %3081 = select i1 %3071, i32 22, i32 %3080
  store i32 %3081, ptr %3079, align 4
  %3082 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3075
  %3083 = load i32, ptr %3082, align 4
  %3084 = select i1 %3071, i32 %3070, i32 %3083
  store i32 %3084, ptr %3082, align 4
  %3085 = add i32 %3072, 1
  %3086 = select i1 %3071, i32 %3085, i32 %3072
  store i32 %3086, ptr %ready.count, align 4
  %3087 = load <8 x i1>, ptr %runnable.mask, align 1
  %3088 = or <8 x i1> %3087, %425
  store <8 x i1> %3088, ptr %runnable.mask, align 1
  store <8 x i1> %427, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true426:                         ; preds = %varying.coherent421
  store <8 x i1> %418, ptr %current.mask, align 1
  %3089 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %418)
  br i1 %3089, label %schedule.22, label %scheduler.loop

varying.coherent.false427:                        ; preds = %varying.coherent421
  store <8 x i1> %418, ptr %current.mask, align 1
  %3090 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %418)
  br i1 %3090, label %schedule.29, label %scheduler.loop

varying.divergent430:                             ; preds = %schedule.23
  %3091 = load i32, ptr %current.token, align 4
  %3092 = icmp ne i32 %3091, 0
  %3093 = sub i32 %3091, 1
  %3094 = select i1 %3092, i32 %3093, i32 0
  %3095 = load i8, ptr %frame.active, align 1
  %3096 = trunc i32 %3094 to i8
  %3097 = shl i8 1, %3096
  %3098 = and i8 %3095, %3097
  %3099 = icmp ne i8 %3098, 0
  %3100 = load <8 x i32>, ptr %frame.static.id, align 32
  %3101 = extractelement <8 x i32> %3100, i32 %3094
  %3102 = icmp eq i32 %3101, 9
  %3103 = and i1 %3099, %3102
  %3104 = and i1 %3092, %3103
  %3105 = xor i1 %3104, true
  %3106 = and i1 true, %3105
  %3107 = xor i8 %3095, -1
  %3108 = icmp ne i8 %3107, 0
  %3109 = xor i1 %3108, true
  %3110 = and i1 %3106, %3109
  br i1 %3110, label %convergence.overflow.trap432, label %convergence.overflow.resume433

varying.coherent431:                              ; preds = %schedule.23
  br i1 %453, label %varying.coherent.true436, label %varying.coherent.false437

convergence.overflow.trap432:                     ; preds = %varying.divergent430
  call void @llvm.trap()
  unreachable

convergence.overflow.resume433:                   ; preds = %varying.divergent430
  %3111 = call i8 @llvm.cttz.i8(i8 %3107, i1 false)
  %3112 = zext i8 %3111 to i32
  %3113 = select i1 %3108, i32 %3112, i32 0
  %3114 = trunc i32 %3113 to i8
  %3115 = shl i8 1, %3114
  %3116 = or i8 %3095, %3115
  %3117 = select i1 %3106, i8 %3116, i8 %3095
  store i8 %3117, ptr %frame.active, align 1
  %3118 = load <8 x i32>, ptr %frame.static.id, align 32
  %3119 = extractelement <8 x i32> %3118, i32 %3113
  %3120 = select i1 %3106, i32 9, i32 %3119
  %3121 = load <8 x i32>, ptr %frame.static.id, align 32
  %3122 = insertelement <8 x i32> %3121, i32 %3120, i32 %3113
  store <8 x i32> %3122, ptr %frame.static.id, align 32
  %3123 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3124 = extractelement <8 x i32> %3123, i32 %3113
  %3125 = select i1 %3106, i32 %3091, i32 %3124
  %3126 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3127 = insertelement <8 x i32> %3126, i32 %3125, i32 %3113
  store <8 x i32> %3127, ptr %frame.parent.token, align 32
  %3128 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3113
  %3129 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3113
  %3130 = load <8 x i1>, ptr %3128, align 1
  %3131 = load <8 x i1>, ptr %3129, align 1
  %3132 = select i1 %3106, <8 x i1> %443, <8 x i1> %3130
  store <8 x i1> %3132, ptr %3128, align 1
  %3133 = select i1 %3106, <8 x i1> zeroinitializer, <8 x i1> %3131
  store <8 x i1> %3133, ptr %3129, align 1
  %3134 = add i32 %3113, 1
  %3135 = select i1 %3104, i32 %3091, i32 %3134
  %3136 = select i1 true, i32 %3135, i32 %3091
  store i32 %3136, ptr %current.token, align 4
  %3137 = load i32, ptr %current.token, align 4
  %3138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %450)
  %3139 = load i32, ptr %ready.count, align 4
  %3140 = icmp uge i32 %3139, 8
  %3141 = and i1 %3138, %3140
  br i1 %3141, label %ready.overflow.trap434, label %ready.overflow.resume435

ready.overflow.trap434:                           ; preds = %convergence.overflow.resume433
  call void @llvm.trap()
  unreachable

ready.overflow.resume435:                         ; preds = %convergence.overflow.resume433
  %3142 = select i1 %3138, i32 %3139, i32 0
  %3143 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3142
  %3144 = load <8 x i1>, ptr %3143, align 1
  %3145 = select i1 %3138, <8 x i1> %450, <8 x i1> %3144
  store <8 x i1> %3145, ptr %3143, align 1
  %3146 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3142
  %3147 = load i32, ptr %3146, align 4
  %3148 = select i1 %3138, i32 24, i32 %3147
  store i32 %3148, ptr %3146, align 4
  %3149 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3142
  %3150 = load i32, ptr %3149, align 4
  %3151 = select i1 %3138, i32 %3137, i32 %3150
  store i32 %3151, ptr %3149, align 4
  %3152 = add i32 %3139, 1
  %3153 = select i1 %3138, i32 %3152, i32 %3139
  store i32 %3153, ptr %ready.count, align 4
  %3154 = load <8 x i1>, ptr %runnable.mask, align 1
  %3155 = or <8 x i1> %3154, %450
  store <8 x i1> %3155, ptr %runnable.mask, align 1
  store <8 x i1> %452, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true436:                         ; preds = %varying.coherent431
  store <8 x i1> %443, ptr %current.mask, align 1
  %3156 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %443)
  br i1 %3156, label %schedule.24, label %scheduler.loop

varying.coherent.false437:                        ; preds = %varying.coherent431
  store <8 x i1> %443, ptr %current.mask, align 1
  %3157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %443)
  br i1 %3157, label %schedule.28, label %scheduler.loop

varying.divergent441:                             ; preds = %schedule.25
  %3158 = load i32, ptr %current.token, align 4
  %3159 = icmp ne i32 %3158, 0
  %3160 = sub i32 %3158, 1
  %3161 = select i1 %3159, i32 %3160, i32 0
  %3162 = load i8, ptr %frame.active, align 1
  %3163 = trunc i32 %3161 to i8
  %3164 = shl i8 1, %3163
  %3165 = and i8 %3162, %3164
  %3166 = icmp ne i8 %3165, 0
  %3167 = load <8 x i32>, ptr %frame.static.id, align 32
  %3168 = extractelement <8 x i32> %3167, i32 %3161
  %3169 = icmp eq i32 %3168, 10
  %3170 = and i1 %3166, %3169
  %3171 = and i1 %3159, %3170
  %3172 = xor i1 %3171, true
  %3173 = and i1 true, %3172
  %3174 = xor i8 %3162, -1
  %3175 = icmp ne i8 %3174, 0
  %3176 = xor i1 %3175, true
  %3177 = and i1 %3173, %3176
  br i1 %3177, label %convergence.overflow.trap443, label %convergence.overflow.resume444

varying.coherent442:                              ; preds = %schedule.25
  br i1 %519, label %varying.coherent.true447, label %varying.coherent.false448

convergence.overflow.trap443:                     ; preds = %varying.divergent441
  call void @llvm.trap()
  unreachable

convergence.overflow.resume444:                   ; preds = %varying.divergent441
  %3178 = call i8 @llvm.cttz.i8(i8 %3174, i1 false)
  %3179 = zext i8 %3178 to i32
  %3180 = select i1 %3175, i32 %3179, i32 0
  %3181 = trunc i32 %3180 to i8
  %3182 = shl i8 1, %3181
  %3183 = or i8 %3162, %3182
  %3184 = select i1 %3173, i8 %3183, i8 %3162
  store i8 %3184, ptr %frame.active, align 1
  %3185 = load <8 x i32>, ptr %frame.static.id, align 32
  %3186 = extractelement <8 x i32> %3185, i32 %3180
  %3187 = select i1 %3173, i32 10, i32 %3186
  %3188 = load <8 x i32>, ptr %frame.static.id, align 32
  %3189 = insertelement <8 x i32> %3188, i32 %3187, i32 %3180
  store <8 x i32> %3189, ptr %frame.static.id, align 32
  %3190 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3191 = extractelement <8 x i32> %3190, i32 %3180
  %3192 = select i1 %3173, i32 %3158, i32 %3191
  %3193 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3194 = insertelement <8 x i32> %3193, i32 %3192, i32 %3180
  store <8 x i32> %3194, ptr %frame.parent.token, align 32
  %3195 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3180
  %3196 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3180
  %3197 = load <8 x i1>, ptr %3195, align 1
  %3198 = load <8 x i1>, ptr %3196, align 1
  %3199 = select i1 %3173, <8 x i1> %509, <8 x i1> %3197
  store <8 x i1> %3199, ptr %3195, align 1
  %3200 = select i1 %3173, <8 x i1> zeroinitializer, <8 x i1> %3198
  store <8 x i1> %3200, ptr %3196, align 1
  %3201 = add i32 %3180, 1
  %3202 = select i1 %3171, i32 %3158, i32 %3201
  %3203 = select i1 true, i32 %3202, i32 %3158
  store i32 %3203, ptr %current.token, align 4
  %3204 = load i32, ptr %current.token, align 4
  %3205 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %516)
  %3206 = load i32, ptr %ready.count, align 4
  %3207 = icmp uge i32 %3206, 8
  %3208 = and i1 %3205, %3207
  br i1 %3208, label %ready.overflow.trap445, label %ready.overflow.resume446

ready.overflow.trap445:                           ; preds = %convergence.overflow.resume444
  call void @llvm.trap()
  unreachable

ready.overflow.resume446:                         ; preds = %convergence.overflow.resume444
  %3209 = select i1 %3205, i32 %3206, i32 0
  %3210 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3209
  %3211 = load <8 x i1>, ptr %3210, align 1
  %3212 = select i1 %3205, <8 x i1> %516, <8 x i1> %3211
  store <8 x i1> %3212, ptr %3210, align 1
  %3213 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3209
  %3214 = load i32, ptr %3213, align 4
  %3215 = select i1 %3205, i32 26, i32 %3214
  store i32 %3215, ptr %3213, align 4
  %3216 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3209
  %3217 = load i32, ptr %3216, align 4
  %3218 = select i1 %3205, i32 %3204, i32 %3217
  store i32 %3218, ptr %3216, align 4
  %3219 = add i32 %3206, 1
  %3220 = select i1 %3205, i32 %3219, i32 %3206
  store i32 %3220, ptr %ready.count, align 4
  %3221 = load <8 x i1>, ptr %runnable.mask, align 1
  %3222 = or <8 x i1> %3221, %516
  store <8 x i1> %3222, ptr %runnable.mask, align 1
  store <8 x i1> %518, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true447:                         ; preds = %varying.coherent442
  store <8 x i1> %509, ptr %current.mask, align 1
  %3223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %509)
  br i1 %3223, label %schedule.26, label %scheduler.loop

varying.coherent.false448:                        ; preds = %varying.coherent442
  store <8 x i1> %509, ptr %current.mask, align 1
  %3224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %509)
  br i1 %3224, label %schedule.27, label %scheduler.loop

convergence.cascade472:                           ; preds = %convergence.cascade472, %schedule.27
  %convergence.cascade.flow476 = phi <8 x i1> [ %600, %schedule.27 ], [ %3267, %convergence.cascade472 ]
  %convergence.cascade.depth477 = phi i32 [ 0, %schedule.27 ], [ %3268, %convergence.cascade472 ]
  %3225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow476)
  %3226 = load i32, ptr %current.token, align 4
  %3227 = icmp ne i32 %3226, 0
  %3228 = and i1 %3225, %3227
  %3229 = sub i32 %3226, 1
  %3230 = select i1 %3228, i32 %3229, i32 0
  %3231 = load i8, ptr %frame.active, align 1
  %3232 = trunc i32 %3230 to i8
  %3233 = shl i8 1, %3232
  %3234 = and i8 %3231, %3233
  %3235 = icmp ne i8 %3234, 0
  %3236 = load <8 x i32>, ptr %frame.static.id, align 32
  %3237 = extractelement <8 x i32> %3236, i32 %3230
  %convergence.target.pointer478 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %3237
  %convergence.dynamic.target479 = load i32, ptr %convergence.target.pointer478, align 4
  %3238 = icmp eq i32 %convergence.dynamic.target479, 27
  %3239 = and i1 %3235, %3238
  %3240 = and i1 %3228, %3239
  %3241 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3230
  %3242 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3230
  %3243 = load <8 x i1>, ptr %3241, align 1
  %3244 = load <8 x i1>, ptr %3242, align 1
  %3245 = or <8 x i1> %3244, %convergence.cascade.flow476
  %3246 = load <8 x i1>, ptr %live.mask, align 1
  %3247 = and <8 x i1> %3243, %3246
  %3248 = icmp eq <8 x i1> %3245, %3247
  %3249 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3248)
  %3250 = and i1 %3240, %3249
  %3251 = select i1 %3250, <8 x i1> zeroinitializer, <8 x i1> %3245
  %3252 = select i1 %3240, <8 x i1> %3251, <8 x i1> %3244
  store <8 x i1> %3252, ptr %3242, align 1
  %3253 = select i1 %3250, <8 x i1> zeroinitializer, <8 x i1> %3243
  store <8 x i1> %3253, ptr %3241, align 1
  %3254 = trunc i32 %3230 to i8
  %3255 = shl i8 1, %3254
  %3256 = xor i8 %3255, -1
  %3257 = and i8 %3231, %3256
  %3258 = select i1 %3250, i8 %3257, i8 %3231
  store i8 %3258, ptr %frame.active, align 1
  %.splatinsert480 = insertelement <8 x i1> poison, i1 %3240, i64 0
  %.splat481 = shufflevector <8 x i1> %.splatinsert480, <8 x i1> poison, <8 x i32> zeroinitializer
  %3259 = and <8 x i1> %convergence.cascade.flow476, %.splat481
  %3260 = load <8 x i1>, ptr %runnable.mask, align 1
  %3261 = xor <8 x i1> %3259, splat (i1 true)
  %3262 = and <8 x i1> %3260, %3261
  store <8 x i1> %3262, ptr %runnable.mask, align 1
  %.splatinsert482 = insertelement <8 x i1> poison, i1 %3250, i64 0
  %.splat483 = shufflevector <8 x i1> %.splatinsert482, <8 x i1> poison, <8 x i32> zeroinitializer
  %3263 = select <8 x i1> %.splat483, <8 x i1> %3245, <8 x i1> zeroinitializer
  %3264 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3265 = extractelement <8 x i32> %3264, i32 %3230
  %3266 = select i1 %3250, i32 %3265, i32 %3226
  store i32 %3266, ptr %current.token, align 4
  %.splatinsert484 = insertelement <8 x i1> poison, i1 %3240, i64 0
  %.splat485 = shufflevector <8 x i1> %.splatinsert484, <8 x i1> poison, <8 x i32> zeroinitializer
  %3267 = select <8 x i1> %.splat485, <8 x i1> %3263, <8 x i1> %convergence.cascade.flow476
  %3268 = add i32 %convergence.cascade.depth477, 1
  %3269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3267)
  %3270 = icmp ult i32 %3268, 8
  %3271 = and i1 %3269, %3270
  %3272 = and i1 %3240, %3271
  %convergence.parent.token486 = load i32, ptr %current.token, align 4
  %convergence.parent.present487 = icmp ne i32 %convergence.parent.token486, 0
  %3273 = and i1 %3272, %convergence.parent.present487
  br i1 %3273, label %convergence.cascade472, label %convergence.cascade.exit473

convergence.cascade.exit473:                      ; preds = %convergence.cascade472, %schedule.27
  %convergence.cascade.result488 = phi <8 x i1> [ %600, %schedule.27 ], [ %3267, %convergence.cascade472 ]
  %3274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result488)
  br i1 %3274, label %convergence.target.27.ready, label %scheduler.loop

convergence.target.27.ready:                      ; preds = %convergence.cascade.exit473
  %3275 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result488)
  %3276 = bitcast <8 x i1> %convergence.cascade.result488 to i8
  %3277 = call i8 @llvm.cttz.i8(i8 %3276, i1 false)
  %3278 = zext i8 %3277 to i32
  %3279 = select i1 %3275, i32 %3278, i32 0
  %tile_snapshot.spill.load489 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %3280 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load489, 0
  %3281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load489, 1
  %.spill.load490 = load <8 x i64>, ptr %.spill99, align 64
  %3282 = mul <8 x i64> %.spill.load490, splat (i64 32)
  %3283 = add <8 x i64> %3281, %3282
  %3284 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3280, 0
  %3285 = insertvalue { <8 x ptr>, <8 x i64> } %3284, <8 x i64> %3283, 1
  %.state491 = load <8 x float>, ptr %.slot108, align 32
  %3286 = extractvalue { <8 x ptr>, <8 x i64> } %3285, 0
  %3287 = extractvalue { <8 x ptr>, <8 x i64> } %3285, 1
  %3288 = getelementptr i8, <8 x ptr> %3286, <8 x i64> %3287
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state491, <8 x ptr> align 1 %3288, <8 x i1> %convergence.cascade.result488)
  %tile_snapshot.spill.load492 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %3289 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load492, 0
  %3290 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load492, 1
  %.spill.load493 = load <8 x i64>, ptr %.spill102, align 64
  %3291 = mul <8 x i64> %.spill.load493, splat (i64 32)
  %3292 = add <8 x i64> %3290, %3291
  %3293 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3289, 0
  %3294 = insertvalue { <8 x ptr>, <8 x i64> } %3293, <8 x i64> %3292, 1
  %.state494 = load <8 x float>, ptr %.slot109, align 32
  %3295 = extractvalue { <8 x ptr>, <8 x i64> } %3294, 0
  %3296 = extractvalue { <8 x ptr>, <8 x i64> } %3294, 1
  %3297 = getelementptr i8, <8 x ptr> %3295, <8 x i64> %3296
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state494, <8 x ptr> align 1 %3297, <8 x i1> %convergence.cascade.result488)
  %tile_snapshot.spill.load495 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %3298 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load495, 0
  %3299 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load495, 1
  %.spill.load496 = load <8 x i64>, ptr %.spill104, align 64
  %3300 = mul <8 x i64> %.spill.load496, splat (i64 32)
  %3301 = add <8 x i64> %3299, %3300
  %3302 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3298, 0
  %3303 = insertvalue { <8 x ptr>, <8 x i64> } %3302, <8 x i64> %3301, 1
  %.state497 = load <8 x float>, ptr %.slot110, align 32
  %3304 = extractvalue { <8 x ptr>, <8 x i64> } %3303, 0
  %3305 = extractvalue { <8 x ptr>, <8 x i64> } %3303, 1
  %3306 = getelementptr i8, <8 x ptr> %3304, <8 x i64> %3305
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state497, <8 x ptr> align 1 %3306, <8 x i1> %convergence.cascade.result488)
  %tile_snapshot.spill.load498 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %3307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load498, 0
  %3308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load498, 1
  %.spill.load499 = load <8 x i64>, ptr %.spill106, align 64
  %3309 = mul <8 x i64> %.spill.load499, splat (i64 32)
  %3310 = add <8 x i64> %3308, %3309
  %3311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3307, 0
  %3312 = insertvalue { <8 x ptr>, <8 x i64> } %3311, <8 x i64> %3310, 1
  %.state500 = load <8 x float>, ptr %.slot111, align 32
  %3313 = extractvalue { <8 x ptr>, <8 x i64> } %3312, 0
  %3314 = extractvalue { <8 x ptr>, <8 x i64> } %3312, 1
  %3315 = getelementptr i8, <8 x ptr> %3313, <8 x i64> %3314
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state500, <8 x ptr> align 1 %3315, <8 x i1> %convergence.cascade.result488)
  %.state501 = load <8 x i64>, ptr %.slot97, align 64
  %3316 = add <8 x i64> %.state501, splat (i64 1)
  %3317 = load <8 x i64>, ptr %.slot97, align 64
  %3318 = select <8 x i1> %convergence.cascade.result488, <8 x i64> %3316, <8 x i64> %3317
  store <8 x i64> %3318, ptr %.slot97, align 64
  store <8 x i1> %convergence.cascade.result488, ptr %current.mask, align 1
  %3319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result488)
  br i1 %3319, label %schedule.23, label %scheduler.loop

convergence.cascade502:                           ; preds = %convergence.cascade502, %schedule.28
  %convergence.cascade.flow506 = phi <8 x i1> [ %601, %schedule.28 ], [ %3362, %convergence.cascade502 ]
  %convergence.cascade.depth507 = phi i32 [ 0, %schedule.28 ], [ %3363, %convergence.cascade502 ]
  %3320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow506)
  %3321 = load i32, ptr %current.token, align 4
  %3322 = icmp ne i32 %3321, 0
  %3323 = and i1 %3320, %3322
  %3324 = sub i32 %3321, 1
  %3325 = select i1 %3323, i32 %3324, i32 0
  %3326 = load i8, ptr %frame.active, align 1
  %3327 = trunc i32 %3325 to i8
  %3328 = shl i8 1, %3327
  %3329 = and i8 %3326, %3328
  %3330 = icmp ne i8 %3329, 0
  %3331 = load <8 x i32>, ptr %frame.static.id, align 32
  %3332 = extractelement <8 x i32> %3331, i32 %3325
  %convergence.target.pointer508 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %3332
  %convergence.dynamic.target509 = load i32, ptr %convergence.target.pointer508, align 4
  %3333 = icmp eq i32 %convergence.dynamic.target509, 28
  %3334 = and i1 %3330, %3333
  %3335 = and i1 %3323, %3334
  %3336 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3325
  %3337 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3325
  %3338 = load <8 x i1>, ptr %3336, align 1
  %3339 = load <8 x i1>, ptr %3337, align 1
  %3340 = or <8 x i1> %3339, %convergence.cascade.flow506
  %3341 = load <8 x i1>, ptr %live.mask, align 1
  %3342 = and <8 x i1> %3338, %3341
  %3343 = icmp eq <8 x i1> %3340, %3342
  %3344 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3343)
  %3345 = and i1 %3335, %3344
  %3346 = select i1 %3345, <8 x i1> zeroinitializer, <8 x i1> %3340
  %3347 = select i1 %3335, <8 x i1> %3346, <8 x i1> %3339
  store <8 x i1> %3347, ptr %3337, align 1
  %3348 = select i1 %3345, <8 x i1> zeroinitializer, <8 x i1> %3338
  store <8 x i1> %3348, ptr %3336, align 1
  %3349 = trunc i32 %3325 to i8
  %3350 = shl i8 1, %3349
  %3351 = xor i8 %3350, -1
  %3352 = and i8 %3326, %3351
  %3353 = select i1 %3345, i8 %3352, i8 %3326
  store i8 %3353, ptr %frame.active, align 1
  %.splatinsert510 = insertelement <8 x i1> poison, i1 %3335, i64 0
  %.splat511 = shufflevector <8 x i1> %.splatinsert510, <8 x i1> poison, <8 x i32> zeroinitializer
  %3354 = and <8 x i1> %convergence.cascade.flow506, %.splat511
  %3355 = load <8 x i1>, ptr %runnable.mask, align 1
  %3356 = xor <8 x i1> %3354, splat (i1 true)
  %3357 = and <8 x i1> %3355, %3356
  store <8 x i1> %3357, ptr %runnable.mask, align 1
  %.splatinsert512 = insertelement <8 x i1> poison, i1 %3345, i64 0
  %.splat513 = shufflevector <8 x i1> %.splatinsert512, <8 x i1> poison, <8 x i32> zeroinitializer
  %3358 = select <8 x i1> %.splat513, <8 x i1> %3340, <8 x i1> zeroinitializer
  %3359 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3360 = extractelement <8 x i32> %3359, i32 %3325
  %3361 = select i1 %3345, i32 %3360, i32 %3321
  store i32 %3361, ptr %current.token, align 4
  %.splatinsert514 = insertelement <8 x i1> poison, i1 %3335, i64 0
  %.splat515 = shufflevector <8 x i1> %.splatinsert514, <8 x i1> poison, <8 x i32> zeroinitializer
  %3362 = select <8 x i1> %.splat515, <8 x i1> %3358, <8 x i1> %convergence.cascade.flow506
  %3363 = add i32 %convergence.cascade.depth507, 1
  %3364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3362)
  %3365 = icmp ult i32 %3363, 8
  %3366 = and i1 %3364, %3365
  %3367 = and i1 %3335, %3366
  %convergence.parent.token516 = load i32, ptr %current.token, align 4
  %convergence.parent.present517 = icmp ne i32 %convergence.parent.token516, 0
  %3368 = and i1 %3367, %convergence.parent.present517
  br i1 %3368, label %convergence.cascade502, label %convergence.cascade.exit503

convergence.cascade.exit503:                      ; preds = %convergence.cascade502, %schedule.28
  %convergence.cascade.result518 = phi <8 x i1> [ %601, %schedule.28 ], [ %3362, %convergence.cascade502 ]
  %3369 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result518)
  br i1 %3369, label %convergence.target.28.ready, label %scheduler.loop

convergence.target.28.ready:                      ; preds = %convergence.cascade.exit503
  %3370 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result518)
  %3371 = bitcast <8 x i1> %convergence.cascade.result518 to i8
  %3372 = call i8 @llvm.cttz.i8(i8 %3371, i1 false)
  %3373 = zext i8 %3372 to i32
  %3374 = select i1 %3370, i32 %3373, i32 0
  %.state519 = load <8 x i64>, ptr %.slot95, align 64
  %3375 = add <8 x i64> %.state519, splat (i64 1)
  %3376 = load <8 x i64>, ptr %.slot95, align 64
  %3377 = select <8 x i1> %convergence.cascade.result518, <8 x i64> %3375, <8 x i64> %3376
  store <8 x i64> %3377, ptr %.slot95, align 64
  store <8 x i1> %convergence.cascade.result518, ptr %current.mask, align 1
  %3378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result518)
  br i1 %3378, label %schedule.21, label %scheduler.loop

convergence.cascade520:                           ; preds = %convergence.cascade520, %schedule.29
  %convergence.cascade.flow524 = phi <8 x i1> [ %602, %schedule.29 ], [ %3421, %convergence.cascade520 ]
  %convergence.cascade.depth525 = phi i32 [ 0, %schedule.29 ], [ %3422, %convergence.cascade520 ]
  %3379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow524)
  %3380 = load i32, ptr %current.token, align 4
  %3381 = icmp ne i32 %3380, 0
  %3382 = and i1 %3379, %3381
  %3383 = sub i32 %3380, 1
  %3384 = select i1 %3382, i32 %3383, i32 0
  %3385 = load i8, ptr %frame.active, align 1
  %3386 = trunc i32 %3384 to i8
  %3387 = shl i8 1, %3386
  %3388 = and i8 %3385, %3387
  %3389 = icmp ne i8 %3388, 0
  %3390 = load <8 x i32>, ptr %frame.static.id, align 32
  %3391 = extractelement <8 x i32> %3390, i32 %3384
  %convergence.target.pointer526 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %3391
  %convergence.dynamic.target527 = load i32, ptr %convergence.target.pointer526, align 4
  %3392 = icmp eq i32 %convergence.dynamic.target527, 29
  %3393 = and i1 %3389, %3392
  %3394 = and i1 %3382, %3393
  %3395 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3384
  %3396 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3384
  %3397 = load <8 x i1>, ptr %3395, align 1
  %3398 = load <8 x i1>, ptr %3396, align 1
  %3399 = or <8 x i1> %3398, %convergence.cascade.flow524
  %3400 = load <8 x i1>, ptr %live.mask, align 1
  %3401 = and <8 x i1> %3397, %3400
  %3402 = icmp eq <8 x i1> %3399, %3401
  %3403 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3402)
  %3404 = and i1 %3394, %3403
  %3405 = select i1 %3404, <8 x i1> zeroinitializer, <8 x i1> %3399
  %3406 = select i1 %3394, <8 x i1> %3405, <8 x i1> %3398
  store <8 x i1> %3406, ptr %3396, align 1
  %3407 = select i1 %3404, <8 x i1> zeroinitializer, <8 x i1> %3397
  store <8 x i1> %3407, ptr %3395, align 1
  %3408 = trunc i32 %3384 to i8
  %3409 = shl i8 1, %3408
  %3410 = xor i8 %3409, -1
  %3411 = and i8 %3385, %3410
  %3412 = select i1 %3404, i8 %3411, i8 %3385
  store i8 %3412, ptr %frame.active, align 1
  %.splatinsert528 = insertelement <8 x i1> poison, i1 %3394, i64 0
  %.splat529 = shufflevector <8 x i1> %.splatinsert528, <8 x i1> poison, <8 x i32> zeroinitializer
  %3413 = and <8 x i1> %convergence.cascade.flow524, %.splat529
  %3414 = load <8 x i1>, ptr %runnable.mask, align 1
  %3415 = xor <8 x i1> %3413, splat (i1 true)
  %3416 = and <8 x i1> %3414, %3415
  store <8 x i1> %3416, ptr %runnable.mask, align 1
  %.splatinsert530 = insertelement <8 x i1> poison, i1 %3404, i64 0
  %.splat531 = shufflevector <8 x i1> %.splatinsert530, <8 x i1> poison, <8 x i32> zeroinitializer
  %3417 = select <8 x i1> %.splat531, <8 x i1> %3399, <8 x i1> zeroinitializer
  %3418 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3419 = extractelement <8 x i32> %3418, i32 %3384
  %3420 = select i1 %3404, i32 %3419, i32 %3380
  store i32 %3420, ptr %current.token, align 4
  %.splatinsert532 = insertelement <8 x i1> poison, i1 %3394, i64 0
  %.splat533 = shufflevector <8 x i1> %.splatinsert532, <8 x i1> poison, <8 x i32> zeroinitializer
  %3421 = select <8 x i1> %.splat533, <8 x i1> %3417, <8 x i1> %convergence.cascade.flow524
  %3422 = add i32 %convergence.cascade.depth525, 1
  %3423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3421)
  %3424 = icmp ult i32 %3422, 8
  %3425 = and i1 %3423, %3424
  %3426 = and i1 %3394, %3425
  %convergence.parent.token534 = load i32, ptr %current.token, align 4
  %convergence.parent.present535 = icmp ne i32 %convergence.parent.token534, 0
  %3427 = and i1 %3426, %convergence.parent.present535
  br i1 %3427, label %convergence.cascade520, label %convergence.cascade.exit521

convergence.cascade.exit521:                      ; preds = %convergence.cascade520, %schedule.29
  %convergence.cascade.result536 = phi <8 x i1> [ %602, %schedule.29 ], [ %3421, %convergence.cascade520 ]
  %3428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  br i1 %3428, label %convergence.target.29.ready, label %scheduler.loop

convergence.target.29.ready:                      ; preds = %convergence.cascade.exit521
  %3429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3430 = bitcast <8 x i1> %convergence.cascade.result536 to i8
  %3431 = call i8 @llvm.cttz.i8(i8 %3430, i1 false)
  %3432 = zext i8 %3431 to i32
  %3433 = select i1 %3429, i32 %3432, i32 0
  %.spill.load537 = load <8 x i64>, ptr %.spill85, align 64
  %3434 = add <8 x i64> zeroinitializer, %.spill.load537
  %.spill.load538 = load <8 x i64>, ptr %.spill85, align 64
  %3435 = add <8 x i64> splat (i64 1), %.spill.load538
  %.spill.load539 = load <8 x i64>, ptr %.spill85, align 64
  %3436 = add <8 x i64> splat (i64 2), %.spill.load539
  %.spill.load540 = load <8 x i64>, ptr %.spill85, align 64
  %3437 = add <8 x i64> splat (i64 3), %.spill.load540
  %.spill.load541 = load <8 x i64>, ptr %.spill85, align 64
  %3438 = add <8 x i64> splat (i64 4), %.spill.load541
  %.spill.load542 = load <8 x i64>, ptr %.spill85, align 64
  %3439 = add <8 x i64> splat (i64 5), %.spill.load542
  %.spill.load543 = load <8 x i64>, ptr %.spill85, align 64
  %3440 = add <8 x i64> splat (i64 6), %.spill.load543
  %.spill.load544 = load <8 x i64>, ptr %.spill85, align 64
  %3441 = add <8 x i64> splat (i64 7), %.spill.load544
  %.spill.load545 = load <8 x i64>, ptr %.spill85, align 64
  %3442 = add <8 x i64> splat (i64 8), %.spill.load545
  %.spill.load546 = load <8 x i64>, ptr %.spill85, align 64
  %3443 = add <8 x i64> splat (i64 9), %.spill.load546
  %.spill.load547 = load <8 x i64>, ptr %.spill85, align 64
  %3444 = add <8 x i64> splat (i64 10), %.spill.load547
  %.spill.load548 = load <8 x i64>, ptr %.spill85, align 64
  %3445 = add <8 x i64> splat (i64 11), %.spill.load548
  %.spill.load549 = load <8 x i64>, ptr %.spill85, align 64
  %3446 = add <8 x i64> splat (i64 12), %.spill.load549
  %.spill.load550 = load <8 x i64>, ptr %.spill85, align 64
  %3447 = add <8 x i64> splat (i64 13), %.spill.load550
  %.spill.load551 = load <8 x i64>, ptr %.spill85, align 64
  %3448 = add <8 x i64> splat (i64 14), %.spill.load551
  %.spill.load552 = load <8 x i64>, ptr %.spill85, align 64
  %3449 = add <8 x i64> splat (i64 15), %.spill.load552
  %3450 = icmp slt <8 x i64> %3434, splat (i64 131)
  %3451 = icmp slt <8 x i64> %3435, splat (i64 131)
  %3452 = icmp slt <8 x i64> %3436, splat (i64 131)
  %3453 = icmp slt <8 x i64> %3437, splat (i64 131)
  %3454 = icmp slt <8 x i64> %3438, splat (i64 131)
  %3455 = icmp slt <8 x i64> %3439, splat (i64 131)
  %3456 = icmp slt <8 x i64> %3440, splat (i64 131)
  %3457 = icmp slt <8 x i64> %3441, splat (i64 131)
  %3458 = icmp slt <8 x i64> %3442, splat (i64 131)
  %3459 = icmp slt <8 x i64> %3443, splat (i64 131)
  %3460 = icmp slt <8 x i64> %3444, splat (i64 131)
  %3461 = icmp slt <8 x i64> %3445, splat (i64 131)
  %3462 = icmp slt <8 x i64> %3446, splat (i64 131)
  %3463 = icmp slt <8 x i64> %3447, splat (i64 131)
  %3464 = icmp slt <8 x i64> %3448, splat (i64 131)
  %3465 = icmp slt <8 x i64> %3449, splat (i64 131)
  %3466 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %3467 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3468 = extractvalue { <8 x ptr>, <8 x i64> } %3466, 0
  %3469 = select <8 x i1> %convergence.cascade.result536, <8 x ptr> %3467, <8 x ptr> %3468
  %3470 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3471 = extractvalue { <8 x ptr>, <8 x i64> } %3466, 1
  %3472 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3470, <8 x i64> %3471
  %3473 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3469, 0
  %3474 = insertvalue { <8 x ptr>, <8 x i64> } %3473, <8 x i64> %3472, 1
  store { <8 x ptr>, <8 x i64> } %3474, ptr %tile_snapshot.spill112, align 64
  %3475 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3476 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3477 = add <8 x i64> %3476, zeroinitializer
  %3478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3475, 0
  %3479 = insertvalue { <8 x ptr>, <8 x i64> } %3478, <8 x i64> %3477, 1
  %3480 = extractvalue { <8 x ptr>, <8 x i64> } %3479, 0
  %3481 = extractvalue { <8 x ptr>, <8 x i64> } %3479, 1
  %3482 = getelementptr i8, <8 x ptr> %3480, <8 x i64> %3481
  %3483 = zext <8 x i1> %3450 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3483, <8 x ptr> align 1 %3482, <8 x i1> %convergence.cascade.result536)
  %3484 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3485 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3486 = add <8 x i64> %3485, splat (i64 1)
  %3487 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3484, 0
  %3488 = insertvalue { <8 x ptr>, <8 x i64> } %3487, <8 x i64> %3486, 1
  %3489 = extractvalue { <8 x ptr>, <8 x i64> } %3488, 0
  %3490 = extractvalue { <8 x ptr>, <8 x i64> } %3488, 1
  %3491 = getelementptr i8, <8 x ptr> %3489, <8 x i64> %3490
  %3492 = zext <8 x i1> %3451 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3492, <8 x ptr> align 1 %3491, <8 x i1> %convergence.cascade.result536)
  %3493 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3494 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3495 = add <8 x i64> %3494, splat (i64 2)
  %3496 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3493, 0
  %3497 = insertvalue { <8 x ptr>, <8 x i64> } %3496, <8 x i64> %3495, 1
  %3498 = extractvalue { <8 x ptr>, <8 x i64> } %3497, 0
  %3499 = extractvalue { <8 x ptr>, <8 x i64> } %3497, 1
  %3500 = getelementptr i8, <8 x ptr> %3498, <8 x i64> %3499
  %3501 = zext <8 x i1> %3452 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3501, <8 x ptr> align 1 %3500, <8 x i1> %convergence.cascade.result536)
  %3502 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3503 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3504 = add <8 x i64> %3503, splat (i64 3)
  %3505 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3502, 0
  %3506 = insertvalue { <8 x ptr>, <8 x i64> } %3505, <8 x i64> %3504, 1
  %3507 = extractvalue { <8 x ptr>, <8 x i64> } %3506, 0
  %3508 = extractvalue { <8 x ptr>, <8 x i64> } %3506, 1
  %3509 = getelementptr i8, <8 x ptr> %3507, <8 x i64> %3508
  %3510 = zext <8 x i1> %3453 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3510, <8 x ptr> align 1 %3509, <8 x i1> %convergence.cascade.result536)
  %3511 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3512 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3513 = add <8 x i64> %3512, splat (i64 4)
  %3514 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3511, 0
  %3515 = insertvalue { <8 x ptr>, <8 x i64> } %3514, <8 x i64> %3513, 1
  %3516 = extractvalue { <8 x ptr>, <8 x i64> } %3515, 0
  %3517 = extractvalue { <8 x ptr>, <8 x i64> } %3515, 1
  %3518 = getelementptr i8, <8 x ptr> %3516, <8 x i64> %3517
  %3519 = zext <8 x i1> %3454 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3519, <8 x ptr> align 1 %3518, <8 x i1> %convergence.cascade.result536)
  %3520 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3521 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3522 = add <8 x i64> %3521, splat (i64 5)
  %3523 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3520, 0
  %3524 = insertvalue { <8 x ptr>, <8 x i64> } %3523, <8 x i64> %3522, 1
  %3525 = extractvalue { <8 x ptr>, <8 x i64> } %3524, 0
  %3526 = extractvalue { <8 x ptr>, <8 x i64> } %3524, 1
  %3527 = getelementptr i8, <8 x ptr> %3525, <8 x i64> %3526
  %3528 = zext <8 x i1> %3455 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3528, <8 x ptr> align 1 %3527, <8 x i1> %convergence.cascade.result536)
  %3529 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3530 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3531 = add <8 x i64> %3530, splat (i64 6)
  %3532 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3529, 0
  %3533 = insertvalue { <8 x ptr>, <8 x i64> } %3532, <8 x i64> %3531, 1
  %3534 = extractvalue { <8 x ptr>, <8 x i64> } %3533, 0
  %3535 = extractvalue { <8 x ptr>, <8 x i64> } %3533, 1
  %3536 = getelementptr i8, <8 x ptr> %3534, <8 x i64> %3535
  %3537 = zext <8 x i1> %3456 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3537, <8 x ptr> align 1 %3536, <8 x i1> %convergence.cascade.result536)
  %3538 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3539 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3540 = add <8 x i64> %3539, splat (i64 7)
  %3541 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3538, 0
  %3542 = insertvalue { <8 x ptr>, <8 x i64> } %3541, <8 x i64> %3540, 1
  %3543 = extractvalue { <8 x ptr>, <8 x i64> } %3542, 0
  %3544 = extractvalue { <8 x ptr>, <8 x i64> } %3542, 1
  %3545 = getelementptr i8, <8 x ptr> %3543, <8 x i64> %3544
  %3546 = zext <8 x i1> %3457 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3546, <8 x ptr> align 1 %3545, <8 x i1> %convergence.cascade.result536)
  %3547 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3548 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3549 = add <8 x i64> %3548, splat (i64 8)
  %3550 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3547, 0
  %3551 = insertvalue { <8 x ptr>, <8 x i64> } %3550, <8 x i64> %3549, 1
  %3552 = extractvalue { <8 x ptr>, <8 x i64> } %3551, 0
  %3553 = extractvalue { <8 x ptr>, <8 x i64> } %3551, 1
  %3554 = getelementptr i8, <8 x ptr> %3552, <8 x i64> %3553
  %3555 = zext <8 x i1> %3458 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3555, <8 x ptr> align 1 %3554, <8 x i1> %convergence.cascade.result536)
  %3556 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3557 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3558 = add <8 x i64> %3557, splat (i64 9)
  %3559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3556, 0
  %3560 = insertvalue { <8 x ptr>, <8 x i64> } %3559, <8 x i64> %3558, 1
  %3561 = extractvalue { <8 x ptr>, <8 x i64> } %3560, 0
  %3562 = extractvalue { <8 x ptr>, <8 x i64> } %3560, 1
  %3563 = getelementptr i8, <8 x ptr> %3561, <8 x i64> %3562
  %3564 = zext <8 x i1> %3459 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3564, <8 x ptr> align 1 %3563, <8 x i1> %convergence.cascade.result536)
  %3565 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3566 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3567 = add <8 x i64> %3566, splat (i64 10)
  %3568 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3565, 0
  %3569 = insertvalue { <8 x ptr>, <8 x i64> } %3568, <8 x i64> %3567, 1
  %3570 = extractvalue { <8 x ptr>, <8 x i64> } %3569, 0
  %3571 = extractvalue { <8 x ptr>, <8 x i64> } %3569, 1
  %3572 = getelementptr i8, <8 x ptr> %3570, <8 x i64> %3571
  %3573 = zext <8 x i1> %3460 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3573, <8 x ptr> align 1 %3572, <8 x i1> %convergence.cascade.result536)
  %3574 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3575 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3576 = add <8 x i64> %3575, splat (i64 11)
  %3577 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3574, 0
  %3578 = insertvalue { <8 x ptr>, <8 x i64> } %3577, <8 x i64> %3576, 1
  %3579 = extractvalue { <8 x ptr>, <8 x i64> } %3578, 0
  %3580 = extractvalue { <8 x ptr>, <8 x i64> } %3578, 1
  %3581 = getelementptr i8, <8 x ptr> %3579, <8 x i64> %3580
  %3582 = zext <8 x i1> %3461 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3582, <8 x ptr> align 1 %3581, <8 x i1> %convergence.cascade.result536)
  %3583 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3584 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3585 = add <8 x i64> %3584, splat (i64 12)
  %3586 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3583, 0
  %3587 = insertvalue { <8 x ptr>, <8 x i64> } %3586, <8 x i64> %3585, 1
  %3588 = extractvalue { <8 x ptr>, <8 x i64> } %3587, 0
  %3589 = extractvalue { <8 x ptr>, <8 x i64> } %3587, 1
  %3590 = getelementptr i8, <8 x ptr> %3588, <8 x i64> %3589
  %3591 = zext <8 x i1> %3462 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3591, <8 x ptr> align 1 %3590, <8 x i1> %convergence.cascade.result536)
  %3592 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3593 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3594 = add <8 x i64> %3593, splat (i64 13)
  %3595 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3592, 0
  %3596 = insertvalue { <8 x ptr>, <8 x i64> } %3595, <8 x i64> %3594, 1
  %3597 = extractvalue { <8 x ptr>, <8 x i64> } %3596, 0
  %3598 = extractvalue { <8 x ptr>, <8 x i64> } %3596, 1
  %3599 = getelementptr i8, <8 x ptr> %3597, <8 x i64> %3598
  %3600 = zext <8 x i1> %3463 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3600, <8 x ptr> align 1 %3599, <8 x i1> %convergence.cascade.result536)
  %3601 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3602 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3603 = add <8 x i64> %3602, splat (i64 14)
  %3604 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3601, 0
  %3605 = insertvalue { <8 x ptr>, <8 x i64> } %3604, <8 x i64> %3603, 1
  %3606 = extractvalue { <8 x ptr>, <8 x i64> } %3605, 0
  %3607 = extractvalue { <8 x ptr>, <8 x i64> } %3605, 1
  %3608 = getelementptr i8, <8 x ptr> %3606, <8 x i64> %3607
  %3609 = zext <8 x i1> %3464 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3609, <8 x ptr> align 1 %3608, <8 x i1> %convergence.cascade.result536)
  %3610 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3611 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3612 = add <8 x i64> %3611, splat (i64 15)
  %3613 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3610, 0
  %3614 = insertvalue { <8 x ptr>, <8 x i64> } %3613, <8 x i64> %3612, 1
  %3615 = extractvalue { <8 x ptr>, <8 x i64> } %3614, 0
  %3616 = extractvalue { <8 x ptr>, <8 x i64> } %3614, 1
  %3617 = getelementptr i8, <8 x ptr> %3615, <8 x i64> %3616
  %3618 = zext <8 x i1> %3465 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3618, <8 x ptr> align 1 %3617, <8 x i1> %convergence.cascade.result536)
  %3619 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill113, align 64
  %3620 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3621 = extractvalue { <8 x ptr>, <8 x i64> } %3619, 0
  %3622 = select <8 x i1> %convergence.cascade.result536, <8 x ptr> %3620, <8 x ptr> %3621
  %3623 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3624 = extractvalue { <8 x ptr>, <8 x i64> } %3619, 1
  %3625 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3623, <8 x i64> %3624
  %3626 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3622, 0
  %3627 = insertvalue { <8 x ptr>, <8 x i64> } %3626, <8 x i64> %3625, 1
  store { <8 x ptr>, <8 x i64> } %3627, ptr %tile_snapshot.spill113, align 64
  %3628 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3629 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3630 = add <8 x i64> %3629, zeroinitializer
  %3631 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3628, 0
  %3632 = insertvalue { <8 x ptr>, <8 x i64> } %3631, <8 x i64> %3630, 1
  %3633 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3634 = extractvalue { <8 x ptr>, <8 x i64> } %3632, 1
  %3635 = extractelement <8 x ptr> %3633, i32 0
  %3636 = extractelement <8 x i64> %3634, i32 %3433
  %3637 = zext i32 %3433 to i64
  %3638 = mul i64 %3637, 8
  %3639 = sub i64 %3636, %3638
  %3640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3641 = select i1 %3640, i64 %3639, i64 0
  %private.contiguous.address = getelementptr i8, ptr %3635, i64 %3641
  %private.contiguous.preserve = load <8 x i64>, ptr %private.contiguous.address, align 8
  %3642 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3434, <8 x i64> %private.contiguous.preserve
  store <8 x i64> %3642, ptr %private.contiguous.address, align 8
  %3643 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3644 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3645 = add <8 x i64> %3644, splat (i64 64)
  %3646 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3643, 0
  %3647 = insertvalue { <8 x ptr>, <8 x i64> } %3646, <8 x i64> %3645, 1
  %3648 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3649 = extractvalue { <8 x ptr>, <8 x i64> } %3647, 1
  %3650 = extractelement <8 x ptr> %3648, i32 0
  %3651 = extractelement <8 x i64> %3649, i32 %3433
  %3652 = zext i32 %3433 to i64
  %3653 = mul i64 %3652, 8
  %3654 = sub i64 %3651, %3653
  %3655 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3656 = select i1 %3655, i64 %3654, i64 0
  %private.contiguous.address553 = getelementptr i8, ptr %3650, i64 %3656
  %private.contiguous.preserve554 = load <8 x i64>, ptr %private.contiguous.address553, align 8
  %3657 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3435, <8 x i64> %private.contiguous.preserve554
  store <8 x i64> %3657, ptr %private.contiguous.address553, align 8
  %3658 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3659 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3660 = add <8 x i64> %3659, splat (i64 128)
  %3661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3658, 0
  %3662 = insertvalue { <8 x ptr>, <8 x i64> } %3661, <8 x i64> %3660, 1
  %3663 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3664 = extractvalue { <8 x ptr>, <8 x i64> } %3662, 1
  %3665 = extractelement <8 x ptr> %3663, i32 0
  %3666 = extractelement <8 x i64> %3664, i32 %3433
  %3667 = zext i32 %3433 to i64
  %3668 = mul i64 %3667, 8
  %3669 = sub i64 %3666, %3668
  %3670 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3671 = select i1 %3670, i64 %3669, i64 0
  %private.contiguous.address555 = getelementptr i8, ptr %3665, i64 %3671
  %private.contiguous.preserve556 = load <8 x i64>, ptr %private.contiguous.address555, align 8
  %3672 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3436, <8 x i64> %private.contiguous.preserve556
  store <8 x i64> %3672, ptr %private.contiguous.address555, align 8
  %3673 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3674 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3675 = add <8 x i64> %3674, splat (i64 192)
  %3676 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3673, 0
  %3677 = insertvalue { <8 x ptr>, <8 x i64> } %3676, <8 x i64> %3675, 1
  %3678 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3679 = extractvalue { <8 x ptr>, <8 x i64> } %3677, 1
  %3680 = extractelement <8 x ptr> %3678, i32 0
  %3681 = extractelement <8 x i64> %3679, i32 %3433
  %3682 = zext i32 %3433 to i64
  %3683 = mul i64 %3682, 8
  %3684 = sub i64 %3681, %3683
  %3685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3686 = select i1 %3685, i64 %3684, i64 0
  %private.contiguous.address557 = getelementptr i8, ptr %3680, i64 %3686
  %private.contiguous.preserve558 = load <8 x i64>, ptr %private.contiguous.address557, align 8
  %3687 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3437, <8 x i64> %private.contiguous.preserve558
  store <8 x i64> %3687, ptr %private.contiguous.address557, align 8
  %3688 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3689 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3690 = add <8 x i64> %3689, splat (i64 256)
  %3691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3688, 0
  %3692 = insertvalue { <8 x ptr>, <8 x i64> } %3691, <8 x i64> %3690, 1
  %3693 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3694 = extractvalue { <8 x ptr>, <8 x i64> } %3692, 1
  %3695 = extractelement <8 x ptr> %3693, i32 0
  %3696 = extractelement <8 x i64> %3694, i32 %3433
  %3697 = zext i32 %3433 to i64
  %3698 = mul i64 %3697, 8
  %3699 = sub i64 %3696, %3698
  %3700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3701 = select i1 %3700, i64 %3699, i64 0
  %private.contiguous.address559 = getelementptr i8, ptr %3695, i64 %3701
  %private.contiguous.preserve560 = load <8 x i64>, ptr %private.contiguous.address559, align 8
  %3702 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3438, <8 x i64> %private.contiguous.preserve560
  store <8 x i64> %3702, ptr %private.contiguous.address559, align 8
  %3703 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3704 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3705 = add <8 x i64> %3704, splat (i64 320)
  %3706 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3703, 0
  %3707 = insertvalue { <8 x ptr>, <8 x i64> } %3706, <8 x i64> %3705, 1
  %3708 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3709 = extractvalue { <8 x ptr>, <8 x i64> } %3707, 1
  %3710 = extractelement <8 x ptr> %3708, i32 0
  %3711 = extractelement <8 x i64> %3709, i32 %3433
  %3712 = zext i32 %3433 to i64
  %3713 = mul i64 %3712, 8
  %3714 = sub i64 %3711, %3713
  %3715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3716 = select i1 %3715, i64 %3714, i64 0
  %private.contiguous.address561 = getelementptr i8, ptr %3710, i64 %3716
  %private.contiguous.preserve562 = load <8 x i64>, ptr %private.contiguous.address561, align 8
  %3717 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3439, <8 x i64> %private.contiguous.preserve562
  store <8 x i64> %3717, ptr %private.contiguous.address561, align 8
  %3718 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3719 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3720 = add <8 x i64> %3719, splat (i64 384)
  %3721 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3718, 0
  %3722 = insertvalue { <8 x ptr>, <8 x i64> } %3721, <8 x i64> %3720, 1
  %3723 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3724 = extractvalue { <8 x ptr>, <8 x i64> } %3722, 1
  %3725 = extractelement <8 x ptr> %3723, i32 0
  %3726 = extractelement <8 x i64> %3724, i32 %3433
  %3727 = zext i32 %3433 to i64
  %3728 = mul i64 %3727, 8
  %3729 = sub i64 %3726, %3728
  %3730 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3731 = select i1 %3730, i64 %3729, i64 0
  %private.contiguous.address563 = getelementptr i8, ptr %3725, i64 %3731
  %private.contiguous.preserve564 = load <8 x i64>, ptr %private.contiguous.address563, align 8
  %3732 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3440, <8 x i64> %private.contiguous.preserve564
  store <8 x i64> %3732, ptr %private.contiguous.address563, align 8
  %3733 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3734 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3735 = add <8 x i64> %3734, splat (i64 448)
  %3736 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3733, 0
  %3737 = insertvalue { <8 x ptr>, <8 x i64> } %3736, <8 x i64> %3735, 1
  %3738 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3739 = extractvalue { <8 x ptr>, <8 x i64> } %3737, 1
  %3740 = extractelement <8 x ptr> %3738, i32 0
  %3741 = extractelement <8 x i64> %3739, i32 %3433
  %3742 = zext i32 %3433 to i64
  %3743 = mul i64 %3742, 8
  %3744 = sub i64 %3741, %3743
  %3745 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3746 = select i1 %3745, i64 %3744, i64 0
  %private.contiguous.address565 = getelementptr i8, ptr %3740, i64 %3746
  %private.contiguous.preserve566 = load <8 x i64>, ptr %private.contiguous.address565, align 8
  %3747 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3441, <8 x i64> %private.contiguous.preserve566
  store <8 x i64> %3747, ptr %private.contiguous.address565, align 8
  %3748 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3749 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3750 = add <8 x i64> %3749, splat (i64 512)
  %3751 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3748, 0
  %3752 = insertvalue { <8 x ptr>, <8 x i64> } %3751, <8 x i64> %3750, 1
  %3753 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3754 = extractvalue { <8 x ptr>, <8 x i64> } %3752, 1
  %3755 = extractelement <8 x ptr> %3753, i32 0
  %3756 = extractelement <8 x i64> %3754, i32 %3433
  %3757 = zext i32 %3433 to i64
  %3758 = mul i64 %3757, 8
  %3759 = sub i64 %3756, %3758
  %3760 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3761 = select i1 %3760, i64 %3759, i64 0
  %private.contiguous.address567 = getelementptr i8, ptr %3755, i64 %3761
  %private.contiguous.preserve568 = load <8 x i64>, ptr %private.contiguous.address567, align 8
  %3762 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3442, <8 x i64> %private.contiguous.preserve568
  store <8 x i64> %3762, ptr %private.contiguous.address567, align 8
  %3763 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3764 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3765 = add <8 x i64> %3764, splat (i64 576)
  %3766 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3763, 0
  %3767 = insertvalue { <8 x ptr>, <8 x i64> } %3766, <8 x i64> %3765, 1
  %3768 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3769 = extractvalue { <8 x ptr>, <8 x i64> } %3767, 1
  %3770 = extractelement <8 x ptr> %3768, i32 0
  %3771 = extractelement <8 x i64> %3769, i32 %3433
  %3772 = zext i32 %3433 to i64
  %3773 = mul i64 %3772, 8
  %3774 = sub i64 %3771, %3773
  %3775 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3776 = select i1 %3775, i64 %3774, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %3770, i64 %3776
  %private.contiguous.preserve570 = load <8 x i64>, ptr %private.contiguous.address569, align 8
  %3777 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3443, <8 x i64> %private.contiguous.preserve570
  store <8 x i64> %3777, ptr %private.contiguous.address569, align 8
  %3778 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3779 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3780 = add <8 x i64> %3779, splat (i64 640)
  %3781 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3778, 0
  %3782 = insertvalue { <8 x ptr>, <8 x i64> } %3781, <8 x i64> %3780, 1
  %3783 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3784 = extractvalue { <8 x ptr>, <8 x i64> } %3782, 1
  %3785 = extractelement <8 x ptr> %3783, i32 0
  %3786 = extractelement <8 x i64> %3784, i32 %3433
  %3787 = zext i32 %3433 to i64
  %3788 = mul i64 %3787, 8
  %3789 = sub i64 %3786, %3788
  %3790 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3791 = select i1 %3790, i64 %3789, i64 0
  %private.contiguous.address571 = getelementptr i8, ptr %3785, i64 %3791
  %private.contiguous.preserve572 = load <8 x i64>, ptr %private.contiguous.address571, align 8
  %3792 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3444, <8 x i64> %private.contiguous.preserve572
  store <8 x i64> %3792, ptr %private.contiguous.address571, align 8
  %3793 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3794 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3795 = add <8 x i64> %3794, splat (i64 704)
  %3796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3793, 0
  %3797 = insertvalue { <8 x ptr>, <8 x i64> } %3796, <8 x i64> %3795, 1
  %3798 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3799 = extractvalue { <8 x ptr>, <8 x i64> } %3797, 1
  %3800 = extractelement <8 x ptr> %3798, i32 0
  %3801 = extractelement <8 x i64> %3799, i32 %3433
  %3802 = zext i32 %3433 to i64
  %3803 = mul i64 %3802, 8
  %3804 = sub i64 %3801, %3803
  %3805 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3806 = select i1 %3805, i64 %3804, i64 0
  %private.contiguous.address573 = getelementptr i8, ptr %3800, i64 %3806
  %private.contiguous.preserve574 = load <8 x i64>, ptr %private.contiguous.address573, align 8
  %3807 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3445, <8 x i64> %private.contiguous.preserve574
  store <8 x i64> %3807, ptr %private.contiguous.address573, align 8
  %3808 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3809 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3810 = add <8 x i64> %3809, splat (i64 768)
  %3811 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3808, 0
  %3812 = insertvalue { <8 x ptr>, <8 x i64> } %3811, <8 x i64> %3810, 1
  %3813 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3814 = extractvalue { <8 x ptr>, <8 x i64> } %3812, 1
  %3815 = extractelement <8 x ptr> %3813, i32 0
  %3816 = extractelement <8 x i64> %3814, i32 %3433
  %3817 = zext i32 %3433 to i64
  %3818 = mul i64 %3817, 8
  %3819 = sub i64 %3816, %3818
  %3820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3821 = select i1 %3820, i64 %3819, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %3815, i64 %3821
  %private.contiguous.preserve576 = load <8 x i64>, ptr %private.contiguous.address575, align 8
  %3822 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3446, <8 x i64> %private.contiguous.preserve576
  store <8 x i64> %3822, ptr %private.contiguous.address575, align 8
  %3823 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3824 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3825 = add <8 x i64> %3824, splat (i64 832)
  %3826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3823, 0
  %3827 = insertvalue { <8 x ptr>, <8 x i64> } %3826, <8 x i64> %3825, 1
  %3828 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3829 = extractvalue { <8 x ptr>, <8 x i64> } %3827, 1
  %3830 = extractelement <8 x ptr> %3828, i32 0
  %3831 = extractelement <8 x i64> %3829, i32 %3433
  %3832 = zext i32 %3433 to i64
  %3833 = mul i64 %3832, 8
  %3834 = sub i64 %3831, %3833
  %3835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3836 = select i1 %3835, i64 %3834, i64 0
  %private.contiguous.address577 = getelementptr i8, ptr %3830, i64 %3836
  %private.contiguous.preserve578 = load <8 x i64>, ptr %private.contiguous.address577, align 8
  %3837 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3447, <8 x i64> %private.contiguous.preserve578
  store <8 x i64> %3837, ptr %private.contiguous.address577, align 8
  %3838 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3839 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3840 = add <8 x i64> %3839, splat (i64 896)
  %3841 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3838, 0
  %3842 = insertvalue { <8 x ptr>, <8 x i64> } %3841, <8 x i64> %3840, 1
  %3843 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3844 = extractvalue { <8 x ptr>, <8 x i64> } %3842, 1
  %3845 = extractelement <8 x ptr> %3843, i32 0
  %3846 = extractelement <8 x i64> %3844, i32 %3433
  %3847 = zext i32 %3433 to i64
  %3848 = mul i64 %3847, 8
  %3849 = sub i64 %3846, %3848
  %3850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3851 = select i1 %3850, i64 %3849, i64 0
  %private.contiguous.address579 = getelementptr i8, ptr %3845, i64 %3851
  %private.contiguous.preserve580 = load <8 x i64>, ptr %private.contiguous.address579, align 8
  %3852 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3448, <8 x i64> %private.contiguous.preserve580
  store <8 x i64> %3852, ptr %private.contiguous.address579, align 8
  %3853 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3854 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3855 = add <8 x i64> %3854, splat (i64 960)
  %3856 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3853, 0
  %3857 = insertvalue { <8 x ptr>, <8 x i64> } %3856, <8 x i64> %3855, 1
  %3858 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3859 = extractvalue { <8 x ptr>, <8 x i64> } %3857, 1
  %3860 = extractelement <8 x ptr> %3858, i32 0
  %3861 = extractelement <8 x i64> %3859, i32 %3433
  %3862 = zext i32 %3433 to i64
  %3863 = mul i64 %3862, 8
  %3864 = sub i64 %3861, %3863
  %3865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3866 = select i1 %3865, i64 %3864, i64 0
  %private.contiguous.address581 = getelementptr i8, ptr %3860, i64 %3866
  %private.contiguous.preserve582 = load <8 x i64>, ptr %private.contiguous.address581, align 8
  %3867 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3449, <8 x i64> %private.contiguous.preserve582
  store <8 x i64> %3867, ptr %private.contiguous.address581, align 8
  %.spill.load583 = load <8 x i64>, ptr %.spill61, align 64
  %3868 = add <8 x i64> zeroinitializer, %.spill.load583
  %.spill.load584 = load <8 x i64>, ptr %.spill61, align 64
  %3869 = add <8 x i64> splat (i64 1), %.spill.load584
  %.spill.load585 = load <8 x i64>, ptr %.spill61, align 64
  %3870 = add <8 x i64> splat (i64 2), %.spill.load585
  %.spill.load586 = load <8 x i64>, ptr %.spill61, align 64
  %3871 = add <8 x i64> splat (i64 3), %.spill.load586
  %.spill.load587 = load <8 x i64>, ptr %.spill61, align 64
  %3872 = add <8 x i64> splat (i64 4), %.spill.load587
  %.spill.load588 = load <8 x i64>, ptr %.spill61, align 64
  %3873 = add <8 x i64> splat (i64 5), %.spill.load588
  %.spill.load589 = load <8 x i64>, ptr %.spill61, align 64
  %3874 = add <8 x i64> splat (i64 6), %.spill.load589
  %.spill.load590 = load <8 x i64>, ptr %.spill61, align 64
  %3875 = add <8 x i64> splat (i64 7), %.spill.load590
  %3876 = add <8 x i64> %3868, splat (i64 131)
  %3877 = add <8 x i64> %3869, splat (i64 131)
  %3878 = add <8 x i64> %3870, splat (i64 131)
  %3879 = add <8 x i64> %3871, splat (i64 131)
  %3880 = add <8 x i64> %3872, splat (i64 131)
  %3881 = add <8 x i64> %3873, splat (i64 131)
  %3882 = add <8 x i64> %3874, splat (i64 131)
  %3883 = add <8 x i64> %3875, splat (i64 131)
  %3884 = sub <8 x i64> %3876, splat (i64 33)
  %3885 = sub <8 x i64> %3877, splat (i64 33)
  %3886 = sub <8 x i64> %3878, splat (i64 33)
  %3887 = sub <8 x i64> %3879, splat (i64 33)
  %3888 = sub <8 x i64> %3880, splat (i64 33)
  %3889 = sub <8 x i64> %3881, splat (i64 33)
  %3890 = sub <8 x i64> %3882, splat (i64 33)
  %3891 = sub <8 x i64> %3883, splat (i64 33)
  %3892 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %3893 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3894 = extractvalue { <8 x ptr>, <8 x i64> } %3892, 0
  %3895 = select <8 x i1> %convergence.cascade.result536, <8 x ptr> %3893, <8 x ptr> %3894
  %3896 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3897 = extractvalue { <8 x ptr>, <8 x i64> } %3892, 1
  %3898 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3896, <8 x i64> %3897
  %3899 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3895, 0
  %3900 = insertvalue { <8 x ptr>, <8 x i64> } %3899, <8 x i64> %3898, 1
  store { <8 x ptr>, <8 x i64> } %3900, ptr %tile_snapshot.spill114, align 64
  %3901 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3902 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3903 = add <8 x i64> %3902, zeroinitializer
  %3904 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3901, 0
  %3905 = insertvalue { <8 x ptr>, <8 x i64> } %3904, <8 x i64> %3903, 1
  %3906 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3907 = extractvalue { <8 x ptr>, <8 x i64> } %3905, 1
  %3908 = extractelement <8 x ptr> %3906, i32 0
  %3909 = extractelement <8 x i64> %3907, i32 %3433
  %3910 = zext i32 %3433 to i64
  %3911 = mul i64 %3910, 8
  %3912 = sub i64 %3909, %3911
  %3913 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3914 = select i1 %3913, i64 %3912, i64 0
  %private.contiguous.address591 = getelementptr i8, ptr %3908, i64 %3914
  %private.contiguous.preserve592 = load <8 x i64>, ptr %private.contiguous.address591, align 8
  %3915 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3884, <8 x i64> %private.contiguous.preserve592
  store <8 x i64> %3915, ptr %private.contiguous.address591, align 8
  %3916 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3917 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3918 = add <8 x i64> %3917, splat (i64 64)
  %3919 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3916, 0
  %3920 = insertvalue { <8 x ptr>, <8 x i64> } %3919, <8 x i64> %3918, 1
  %3921 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3922 = extractvalue { <8 x ptr>, <8 x i64> } %3920, 1
  %3923 = extractelement <8 x ptr> %3921, i32 0
  %3924 = extractelement <8 x i64> %3922, i32 %3433
  %3925 = zext i32 %3433 to i64
  %3926 = mul i64 %3925, 8
  %3927 = sub i64 %3924, %3926
  %3928 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3929 = select i1 %3928, i64 %3927, i64 0
  %private.contiguous.address593 = getelementptr i8, ptr %3923, i64 %3929
  %private.contiguous.preserve594 = load <8 x i64>, ptr %private.contiguous.address593, align 8
  %3930 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3885, <8 x i64> %private.contiguous.preserve594
  store <8 x i64> %3930, ptr %private.contiguous.address593, align 8
  %3931 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3932 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3933 = add <8 x i64> %3932, splat (i64 128)
  %3934 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3931, 0
  %3935 = insertvalue { <8 x ptr>, <8 x i64> } %3934, <8 x i64> %3933, 1
  %3936 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3937 = extractvalue { <8 x ptr>, <8 x i64> } %3935, 1
  %3938 = extractelement <8 x ptr> %3936, i32 0
  %3939 = extractelement <8 x i64> %3937, i32 %3433
  %3940 = zext i32 %3433 to i64
  %3941 = mul i64 %3940, 8
  %3942 = sub i64 %3939, %3941
  %3943 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3944 = select i1 %3943, i64 %3942, i64 0
  %private.contiguous.address595 = getelementptr i8, ptr %3938, i64 %3944
  %private.contiguous.preserve596 = load <8 x i64>, ptr %private.contiguous.address595, align 8
  %3945 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3886, <8 x i64> %private.contiguous.preserve596
  store <8 x i64> %3945, ptr %private.contiguous.address595, align 8
  %3946 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3947 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3948 = add <8 x i64> %3947, splat (i64 192)
  %3949 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3946, 0
  %3950 = insertvalue { <8 x ptr>, <8 x i64> } %3949, <8 x i64> %3948, 1
  %3951 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3952 = extractvalue { <8 x ptr>, <8 x i64> } %3950, 1
  %3953 = extractelement <8 x ptr> %3951, i32 0
  %3954 = extractelement <8 x i64> %3952, i32 %3433
  %3955 = zext i32 %3433 to i64
  %3956 = mul i64 %3955, 8
  %3957 = sub i64 %3954, %3956
  %3958 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3959 = select i1 %3958, i64 %3957, i64 0
  %private.contiguous.address597 = getelementptr i8, ptr %3953, i64 %3959
  %private.contiguous.preserve598 = load <8 x i64>, ptr %private.contiguous.address597, align 8
  %3960 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3887, <8 x i64> %private.contiguous.preserve598
  store <8 x i64> %3960, ptr %private.contiguous.address597, align 8
  %3961 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3962 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3963 = add <8 x i64> %3962, splat (i64 256)
  %3964 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3961, 0
  %3965 = insertvalue { <8 x ptr>, <8 x i64> } %3964, <8 x i64> %3963, 1
  %3966 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3967 = extractvalue { <8 x ptr>, <8 x i64> } %3965, 1
  %3968 = extractelement <8 x ptr> %3966, i32 0
  %3969 = extractelement <8 x i64> %3967, i32 %3433
  %3970 = zext i32 %3433 to i64
  %3971 = mul i64 %3970, 8
  %3972 = sub i64 %3969, %3971
  %3973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3974 = select i1 %3973, i64 %3972, i64 0
  %private.contiguous.address599 = getelementptr i8, ptr %3968, i64 %3974
  %private.contiguous.preserve600 = load <8 x i64>, ptr %private.contiguous.address599, align 8
  %3975 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3888, <8 x i64> %private.contiguous.preserve600
  store <8 x i64> %3975, ptr %private.contiguous.address599, align 8
  %3976 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3977 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3978 = add <8 x i64> %3977, splat (i64 320)
  %3979 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3976, 0
  %3980 = insertvalue { <8 x ptr>, <8 x i64> } %3979, <8 x i64> %3978, 1
  %3981 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3982 = extractvalue { <8 x ptr>, <8 x i64> } %3980, 1
  %3983 = extractelement <8 x ptr> %3981, i32 0
  %3984 = extractelement <8 x i64> %3982, i32 %3433
  %3985 = zext i32 %3433 to i64
  %3986 = mul i64 %3985, 8
  %3987 = sub i64 %3984, %3986
  %3988 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3989 = select i1 %3988, i64 %3987, i64 0
  %private.contiguous.address601 = getelementptr i8, ptr %3983, i64 %3989
  %private.contiguous.preserve602 = load <8 x i64>, ptr %private.contiguous.address601, align 8
  %3990 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3889, <8 x i64> %private.contiguous.preserve602
  store <8 x i64> %3990, ptr %private.contiguous.address601, align 8
  %3991 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3992 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3993 = add <8 x i64> %3992, splat (i64 384)
  %3994 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3991, 0
  %3995 = insertvalue { <8 x ptr>, <8 x i64> } %3994, <8 x i64> %3993, 1
  %3996 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3997 = extractvalue { <8 x ptr>, <8 x i64> } %3995, 1
  %3998 = extractelement <8 x ptr> %3996, i32 0
  %3999 = extractelement <8 x i64> %3997, i32 %3433
  %4000 = zext i32 %3433 to i64
  %4001 = mul i64 %4000, 8
  %4002 = sub i64 %3999, %4001
  %4003 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %4004 = select i1 %4003, i64 %4002, i64 0
  %private.contiguous.address603 = getelementptr i8, ptr %3998, i64 %4004
  %private.contiguous.preserve604 = load <8 x i64>, ptr %private.contiguous.address603, align 8
  %4005 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3890, <8 x i64> %private.contiguous.preserve604
  store <8 x i64> %4005, ptr %private.contiguous.address603, align 8
  %4006 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %4007 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %4008 = add <8 x i64> %4007, splat (i64 448)
  %4009 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4006, 0
  %4010 = insertvalue { <8 x ptr>, <8 x i64> } %4009, <8 x i64> %4008, 1
  %4011 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %4012 = extractvalue { <8 x ptr>, <8 x i64> } %4010, 1
  %4013 = extractelement <8 x ptr> %4011, i32 0
  %4014 = extractelement <8 x i64> %4012, i32 %3433
  %4015 = zext i32 %3433 to i64
  %4016 = mul i64 %4015, 8
  %4017 = sub i64 %4014, %4016
  %4018 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %4019 = select i1 %4018, i64 %4017, i64 0
  %private.contiguous.address605 = getelementptr i8, ptr %4013, i64 %4019
  %private.contiguous.preserve606 = load <8 x i64>, ptr %private.contiguous.address605, align 8
  %4020 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %3891, <8 x i64> %private.contiguous.preserve606
  store <8 x i64> %4020, ptr %private.contiguous.address605, align 8
  %4021 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %4022 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4023 = extractvalue { <8 x ptr>, <8 x i64> } %4021, 0
  %4024 = select <8 x i1> %convergence.cascade.result536, <8 x ptr> %4022, <8 x ptr> %4023
  %4025 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4026 = extractvalue { <8 x ptr>, <8 x i64> } %4021, 1
  %4027 = select <8 x i1> %convergence.cascade.result536, <8 x i64> %4025, <8 x i64> %4026
  %4028 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4024, 0
  %4029 = insertvalue { <8 x ptr>, <8 x i64> } %4028, <8 x i64> %4027, 1
  store { <8 x ptr>, <8 x i64> } %4029, ptr %tile_snapshot.spill115, align 64
  %4030 = load <8 x i64>, ptr %.slot116, align 64
  %4031 = select <8 x i1> %convergence.cascade.result536, <8 x i64> zeroinitializer, <8 x i64> %4030
  store <8 x i64> %4031, ptr %.slot116, align 64
  store <8 x i1> %convergence.cascade.result536, ptr %current.mask, align 1
  %4032 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  br i1 %4032, label %schedule.30, label %scheduler.loop

varying.divergent608:                             ; preds = %schedule.30
  %4033 = load i32, ptr %current.token, align 4
  %4034 = icmp ne i32 %4033, 0
  %4035 = sub i32 %4033, 1
  %4036 = select i1 %4034, i32 %4035, i32 0
  %4037 = load i8, ptr %frame.active, align 1
  %4038 = trunc i32 %4036 to i8
  %4039 = shl i8 1, %4038
  %4040 = and i8 %4037, %4039
  %4041 = icmp ne i8 %4040, 0
  %4042 = load <8 x i32>, ptr %frame.static.id, align 32
  %4043 = extractelement <8 x i32> %4042, i32 %4036
  %4044 = icmp eq i32 %4043, 11
  %4045 = and i1 %4041, %4044
  %4046 = and i1 %4034, %4045
  %4047 = xor i1 %4046, true
  %4048 = and i1 true, %4047
  %4049 = xor i8 %4037, -1
  %4050 = icmp ne i8 %4049, 0
  %4051 = xor i1 %4050, true
  %4052 = and i1 %4048, %4051
  br i1 %4052, label %convergence.overflow.trap610, label %convergence.overflow.resume611

varying.coherent609:                              ; preds = %schedule.30
  br i1 %613, label %varying.coherent.true614, label %varying.coherent.false615

convergence.overflow.trap610:                     ; preds = %varying.divergent608
  call void @llvm.trap()
  unreachable

convergence.overflow.resume611:                   ; preds = %varying.divergent608
  %4053 = call i8 @llvm.cttz.i8(i8 %4049, i1 false)
  %4054 = zext i8 %4053 to i32
  %4055 = select i1 %4050, i32 %4054, i32 0
  %4056 = trunc i32 %4055 to i8
  %4057 = shl i8 1, %4056
  %4058 = or i8 %4037, %4057
  %4059 = select i1 %4048, i8 %4058, i8 %4037
  store i8 %4059, ptr %frame.active, align 1
  %4060 = load <8 x i32>, ptr %frame.static.id, align 32
  %4061 = extractelement <8 x i32> %4060, i32 %4055
  %4062 = select i1 %4048, i32 11, i32 %4061
  %4063 = load <8 x i32>, ptr %frame.static.id, align 32
  %4064 = insertelement <8 x i32> %4063, i32 %4062, i32 %4055
  store <8 x i32> %4064, ptr %frame.static.id, align 32
  %4065 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4066 = extractelement <8 x i32> %4065, i32 %4055
  %4067 = select i1 %4048, i32 %4033, i32 %4066
  %4068 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4069 = insertelement <8 x i32> %4068, i32 %4067, i32 %4055
  store <8 x i32> %4069, ptr %frame.parent.token, align 32
  %4070 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4055
  %4071 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4055
  %4072 = load <8 x i1>, ptr %4070, align 1
  %4073 = load <8 x i1>, ptr %4071, align 1
  %4074 = select i1 %4048, <8 x i1> %603, <8 x i1> %4072
  store <8 x i1> %4074, ptr %4070, align 1
  %4075 = select i1 %4048, <8 x i1> zeroinitializer, <8 x i1> %4073
  store <8 x i1> %4075, ptr %4071, align 1
  %4076 = add i32 %4055, 1
  %4077 = select i1 %4046, i32 %4033, i32 %4076
  %4078 = select i1 true, i32 %4077, i32 %4033
  store i32 %4078, ptr %current.token, align 4
  %4079 = load i32, ptr %current.token, align 4
  %4080 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %610)
  %4081 = load i32, ptr %ready.count, align 4
  %4082 = icmp uge i32 %4081, 8
  %4083 = and i1 %4080, %4082
  br i1 %4083, label %ready.overflow.trap612, label %ready.overflow.resume613

ready.overflow.trap612:                           ; preds = %convergence.overflow.resume611
  call void @llvm.trap()
  unreachable

ready.overflow.resume613:                         ; preds = %convergence.overflow.resume611
  %4084 = select i1 %4080, i32 %4081, i32 0
  %4085 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4084
  %4086 = load <8 x i1>, ptr %4085, align 1
  %4087 = select i1 %4080, <8 x i1> %610, <8 x i1> %4086
  store <8 x i1> %4087, ptr %4085, align 1
  %4088 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4084
  %4089 = load i32, ptr %4088, align 4
  %4090 = select i1 %4080, i32 31, i32 %4089
  store i32 %4090, ptr %4088, align 4
  %4091 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4084
  %4092 = load i32, ptr %4091, align 4
  %4093 = select i1 %4080, i32 %4079, i32 %4092
  store i32 %4093, ptr %4091, align 4
  %4094 = add i32 %4081, 1
  %4095 = select i1 %4080, i32 %4094, i32 %4081
  store i32 %4095, ptr %ready.count, align 4
  %4096 = load <8 x i1>, ptr %runnable.mask, align 1
  %4097 = or <8 x i1> %4096, %610
  store <8 x i1> %4097, ptr %runnable.mask, align 1
  store <8 x i1> %612, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true614:                         ; preds = %varying.coherent609
  store <8 x i1> %603, ptr %current.mask, align 1
  %4098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %603)
  br i1 %4098, label %schedule.31, label %scheduler.loop

varying.coherent.false615:                        ; preds = %varying.coherent609
  store <8 x i1> %603, ptr %current.mask, align 1
  %4099 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %603)
  br i1 %4099, label %schedule.32, label %scheduler.loop

convergence.cascade624:                           ; preds = %convergence.cascade624, %schedule.32
  %convergence.cascade.flow628 = phi <8 x i1> [ %684, %schedule.32 ], [ %4142, %convergence.cascade624 ]
  %convergence.cascade.depth629 = phi i32 [ 0, %schedule.32 ], [ %4143, %convergence.cascade624 ]
  %4100 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow628)
  %4101 = load i32, ptr %current.token, align 4
  %4102 = icmp ne i32 %4101, 0
  %4103 = and i1 %4100, %4102
  %4104 = sub i32 %4101, 1
  %4105 = select i1 %4103, i32 %4104, i32 0
  %4106 = load i8, ptr %frame.active, align 1
  %4107 = trunc i32 %4105 to i8
  %4108 = shl i8 1, %4107
  %4109 = and i8 %4106, %4108
  %4110 = icmp ne i8 %4109, 0
  %4111 = load <8 x i32>, ptr %frame.static.id, align 32
  %4112 = extractelement <8 x i32> %4111, i32 %4105
  %convergence.target.pointer630 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4112
  %convergence.dynamic.target631 = load i32, ptr %convergence.target.pointer630, align 4
  %4113 = icmp eq i32 %convergence.dynamic.target631, 32
  %4114 = and i1 %4110, %4113
  %4115 = and i1 %4103, %4114
  %4116 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4105
  %4117 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4105
  %4118 = load <8 x i1>, ptr %4116, align 1
  %4119 = load <8 x i1>, ptr %4117, align 1
  %4120 = or <8 x i1> %4119, %convergence.cascade.flow628
  %4121 = load <8 x i1>, ptr %live.mask, align 1
  %4122 = and <8 x i1> %4118, %4121
  %4123 = icmp eq <8 x i1> %4120, %4122
  %4124 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4123)
  %4125 = and i1 %4115, %4124
  %4126 = select i1 %4125, <8 x i1> zeroinitializer, <8 x i1> %4120
  %4127 = select i1 %4115, <8 x i1> %4126, <8 x i1> %4119
  store <8 x i1> %4127, ptr %4117, align 1
  %4128 = select i1 %4125, <8 x i1> zeroinitializer, <8 x i1> %4118
  store <8 x i1> %4128, ptr %4116, align 1
  %4129 = trunc i32 %4105 to i8
  %4130 = shl i8 1, %4129
  %4131 = xor i8 %4130, -1
  %4132 = and i8 %4106, %4131
  %4133 = select i1 %4125, i8 %4132, i8 %4106
  store i8 %4133, ptr %frame.active, align 1
  %.splatinsert632 = insertelement <8 x i1> poison, i1 %4115, i64 0
  %.splat633 = shufflevector <8 x i1> %.splatinsert632, <8 x i1> poison, <8 x i32> zeroinitializer
  %4134 = and <8 x i1> %convergence.cascade.flow628, %.splat633
  %4135 = load <8 x i1>, ptr %runnable.mask, align 1
  %4136 = xor <8 x i1> %4134, splat (i1 true)
  %4137 = and <8 x i1> %4135, %4136
  store <8 x i1> %4137, ptr %runnable.mask, align 1
  %.splatinsert634 = insertelement <8 x i1> poison, i1 %4125, i64 0
  %.splat635 = shufflevector <8 x i1> %.splatinsert634, <8 x i1> poison, <8 x i32> zeroinitializer
  %4138 = select <8 x i1> %.splat635, <8 x i1> %4120, <8 x i1> zeroinitializer
  %4139 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4140 = extractelement <8 x i32> %4139, i32 %4105
  %4141 = select i1 %4125, i32 %4140, i32 %4101
  store i32 %4141, ptr %current.token, align 4
  %.splatinsert636 = insertelement <8 x i1> poison, i1 %4115, i64 0
  %.splat637 = shufflevector <8 x i1> %.splatinsert636, <8 x i1> poison, <8 x i32> zeroinitializer
  %4142 = select <8 x i1> %.splat637, <8 x i1> %4138, <8 x i1> %convergence.cascade.flow628
  %4143 = add i32 %convergence.cascade.depth629, 1
  %4144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4142)
  %4145 = icmp ult i32 %4143, 8
  %4146 = and i1 %4144, %4145
  %4147 = and i1 %4115, %4146
  %convergence.parent.token638 = load i32, ptr %current.token, align 4
  %convergence.parent.present639 = icmp ne i32 %convergence.parent.token638, 0
  %4148 = and i1 %4147, %convergence.parent.present639
  br i1 %4148, label %convergence.cascade624, label %convergence.cascade.exit625

convergence.cascade.exit625:                      ; preds = %convergence.cascade624, %schedule.32
  %convergence.cascade.result640 = phi <8 x i1> [ %684, %schedule.32 ], [ %4142, %convergence.cascade624 ]
  %4149 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result640)
  br i1 %4149, label %convergence.target.32.ready, label %scheduler.loop

convergence.target.32.ready:                      ; preds = %convergence.cascade.exit625
  %4150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result640)
  %4151 = bitcast <8 x i1> %convergence.cascade.result640 to i8
  %4152 = call i8 @llvm.cttz.i8(i8 %4151, i1 false)
  %4153 = zext i8 %4152 to i32
  %4154 = select i1 %4150, i32 %4153, i32 0
  %4155 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %4156 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %4157 = extractvalue { <8 x ptr>, <8 x i64> } %4155, 0
  %4158 = select <8 x i1> %convergence.cascade.result640, <8 x ptr> %4156, <8 x ptr> %4157
  %4159 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %4160 = extractvalue { <8 x ptr>, <8 x i64> } %4155, 1
  %4161 = select <8 x i1> %convergence.cascade.result640, <8 x i64> %4159, <8 x i64> %4160
  %4162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4158, 0
  %4163 = insertvalue { <8 x ptr>, <8 x i64> } %4162, <8 x i64> %4161, 1
  store { <8 x ptr>, <8 x i64> } %4163, ptr %tile_snapshot.spill117, align 64
  %4164 = load <8 x i64>, ptr %.slot118, align 64
  %4165 = select <8 x i1> %convergence.cascade.result640, <8 x i64> zeroinitializer, <8 x i64> %4164
  store <8 x i64> %4165, ptr %.slot118, align 64
  store <8 x i1> %convergence.cascade.result640, ptr %current.mask, align 1
  %4166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result640)
  br i1 %4166, label %schedule.33, label %scheduler.loop

varying.divergent642:                             ; preds = %schedule.33
  %4167 = load i32, ptr %current.token, align 4
  %4168 = icmp ne i32 %4167, 0
  %4169 = sub i32 %4167, 1
  %4170 = select i1 %4168, i32 %4169, i32 0
  %4171 = load i8, ptr %frame.active, align 1
  %4172 = trunc i32 %4170 to i8
  %4173 = shl i8 1, %4172
  %4174 = and i8 %4171, %4173
  %4175 = icmp ne i8 %4174, 0
  %4176 = load <8 x i32>, ptr %frame.static.id, align 32
  %4177 = extractelement <8 x i32> %4176, i32 %4170
  %4178 = icmp eq i32 %4177, 12
  %4179 = and i1 %4175, %4178
  %4180 = and i1 %4168, %4179
  %4181 = xor i1 %4180, true
  %4182 = and i1 true, %4181
  %4183 = xor i8 %4171, -1
  %4184 = icmp ne i8 %4183, 0
  %4185 = xor i1 %4184, true
  %4186 = and i1 %4182, %4185
  br i1 %4186, label %convergence.overflow.trap644, label %convergence.overflow.resume645

varying.coherent643:                              ; preds = %schedule.33
  br i1 %695, label %varying.coherent.true648, label %varying.coherent.false649

convergence.overflow.trap644:                     ; preds = %varying.divergent642
  call void @llvm.trap()
  unreachable

convergence.overflow.resume645:                   ; preds = %varying.divergent642
  %4187 = call i8 @llvm.cttz.i8(i8 %4183, i1 false)
  %4188 = zext i8 %4187 to i32
  %4189 = select i1 %4184, i32 %4188, i32 0
  %4190 = trunc i32 %4189 to i8
  %4191 = shl i8 1, %4190
  %4192 = or i8 %4171, %4191
  %4193 = select i1 %4182, i8 %4192, i8 %4171
  store i8 %4193, ptr %frame.active, align 1
  %4194 = load <8 x i32>, ptr %frame.static.id, align 32
  %4195 = extractelement <8 x i32> %4194, i32 %4189
  %4196 = select i1 %4182, i32 12, i32 %4195
  %4197 = load <8 x i32>, ptr %frame.static.id, align 32
  %4198 = insertelement <8 x i32> %4197, i32 %4196, i32 %4189
  store <8 x i32> %4198, ptr %frame.static.id, align 32
  %4199 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4200 = extractelement <8 x i32> %4199, i32 %4189
  %4201 = select i1 %4182, i32 %4167, i32 %4200
  %4202 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4203 = insertelement <8 x i32> %4202, i32 %4201, i32 %4189
  store <8 x i32> %4203, ptr %frame.parent.token, align 32
  %4204 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4189
  %4205 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4189
  %4206 = load <8 x i1>, ptr %4204, align 1
  %4207 = load <8 x i1>, ptr %4205, align 1
  %4208 = select i1 %4182, <8 x i1> %685, <8 x i1> %4206
  store <8 x i1> %4208, ptr %4204, align 1
  %4209 = select i1 %4182, <8 x i1> zeroinitializer, <8 x i1> %4207
  store <8 x i1> %4209, ptr %4205, align 1
  %4210 = add i32 %4189, 1
  %4211 = select i1 %4180, i32 %4167, i32 %4210
  %4212 = select i1 true, i32 %4211, i32 %4167
  store i32 %4212, ptr %current.token, align 4
  %4213 = load i32, ptr %current.token, align 4
  %4214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %692)
  %4215 = load i32, ptr %ready.count, align 4
  %4216 = icmp uge i32 %4215, 8
  %4217 = and i1 %4214, %4216
  br i1 %4217, label %ready.overflow.trap646, label %ready.overflow.resume647

ready.overflow.trap646:                           ; preds = %convergence.overflow.resume645
  call void @llvm.trap()
  unreachable

ready.overflow.resume647:                         ; preds = %convergence.overflow.resume645
  %4218 = select i1 %4214, i32 %4215, i32 0
  %4219 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4218
  %4220 = load <8 x i1>, ptr %4219, align 1
  %4221 = select i1 %4214, <8 x i1> %692, <8 x i1> %4220
  store <8 x i1> %4221, ptr %4219, align 1
  %4222 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4218
  %4223 = load i32, ptr %4222, align 4
  %4224 = select i1 %4214, i32 34, i32 %4223
  store i32 %4224, ptr %4222, align 4
  %4225 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4218
  %4226 = load i32, ptr %4225, align 4
  %4227 = select i1 %4214, i32 %4213, i32 %4226
  store i32 %4227, ptr %4225, align 4
  %4228 = add i32 %4215, 1
  %4229 = select i1 %4214, i32 %4228, i32 %4215
  store i32 %4229, ptr %ready.count, align 4
  %4230 = load <8 x i1>, ptr %runnable.mask, align 1
  %4231 = or <8 x i1> %4230, %692
  store <8 x i1> %4231, ptr %runnable.mask, align 1
  store <8 x i1> %694, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true648:                         ; preds = %varying.coherent643
  store <8 x i1> %685, ptr %current.mask, align 1
  %4232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %685)
  br i1 %4232, label %schedule.34, label %scheduler.loop

varying.coherent.false649:                        ; preds = %varying.coherent643
  store <8 x i1> %685, ptr %current.mask, align 1
  %4233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %685)
  br i1 %4233, label %schedule.35, label %scheduler.loop

convergence.cascade657:                           ; preds = %convergence.cascade657, %schedule.35
  %convergence.cascade.flow661 = phi <8 x i1> [ %760, %schedule.35 ], [ %4276, %convergence.cascade657 ]
  %convergence.cascade.depth662 = phi i32 [ 0, %schedule.35 ], [ %4277, %convergence.cascade657 ]
  %4234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow661)
  %4235 = load i32, ptr %current.token, align 4
  %4236 = icmp ne i32 %4235, 0
  %4237 = and i1 %4234, %4236
  %4238 = sub i32 %4235, 1
  %4239 = select i1 %4237, i32 %4238, i32 0
  %4240 = load i8, ptr %frame.active, align 1
  %4241 = trunc i32 %4239 to i8
  %4242 = shl i8 1, %4241
  %4243 = and i8 %4240, %4242
  %4244 = icmp ne i8 %4243, 0
  %4245 = load <8 x i32>, ptr %frame.static.id, align 32
  %4246 = extractelement <8 x i32> %4245, i32 %4239
  %convergence.target.pointer663 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4246
  %convergence.dynamic.target664 = load i32, ptr %convergence.target.pointer663, align 4
  %4247 = icmp eq i32 %convergence.dynamic.target664, 35
  %4248 = and i1 %4244, %4247
  %4249 = and i1 %4237, %4248
  %4250 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4239
  %4251 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4239
  %4252 = load <8 x i1>, ptr %4250, align 1
  %4253 = load <8 x i1>, ptr %4251, align 1
  %4254 = or <8 x i1> %4253, %convergence.cascade.flow661
  %4255 = load <8 x i1>, ptr %live.mask, align 1
  %4256 = and <8 x i1> %4252, %4255
  %4257 = icmp eq <8 x i1> %4254, %4256
  %4258 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4257)
  %4259 = and i1 %4249, %4258
  %4260 = select i1 %4259, <8 x i1> zeroinitializer, <8 x i1> %4254
  %4261 = select i1 %4249, <8 x i1> %4260, <8 x i1> %4253
  store <8 x i1> %4261, ptr %4251, align 1
  %4262 = select i1 %4259, <8 x i1> zeroinitializer, <8 x i1> %4252
  store <8 x i1> %4262, ptr %4250, align 1
  %4263 = trunc i32 %4239 to i8
  %4264 = shl i8 1, %4263
  %4265 = xor i8 %4264, -1
  %4266 = and i8 %4240, %4265
  %4267 = select i1 %4259, i8 %4266, i8 %4240
  store i8 %4267, ptr %frame.active, align 1
  %.splatinsert665 = insertelement <8 x i1> poison, i1 %4249, i64 0
  %.splat666 = shufflevector <8 x i1> %.splatinsert665, <8 x i1> poison, <8 x i32> zeroinitializer
  %4268 = and <8 x i1> %convergence.cascade.flow661, %.splat666
  %4269 = load <8 x i1>, ptr %runnable.mask, align 1
  %4270 = xor <8 x i1> %4268, splat (i1 true)
  %4271 = and <8 x i1> %4269, %4270
  store <8 x i1> %4271, ptr %runnable.mask, align 1
  %.splatinsert667 = insertelement <8 x i1> poison, i1 %4259, i64 0
  %.splat668 = shufflevector <8 x i1> %.splatinsert667, <8 x i1> poison, <8 x i32> zeroinitializer
  %4272 = select <8 x i1> %.splat668, <8 x i1> %4254, <8 x i1> zeroinitializer
  %4273 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4274 = extractelement <8 x i32> %4273, i32 %4239
  %4275 = select i1 %4259, i32 %4274, i32 %4235
  store i32 %4275, ptr %current.token, align 4
  %.splatinsert669 = insertelement <8 x i1> poison, i1 %4249, i64 0
  %.splat670 = shufflevector <8 x i1> %.splatinsert669, <8 x i1> poison, <8 x i32> zeroinitializer
  %4276 = select <8 x i1> %.splat670, <8 x i1> %4272, <8 x i1> %convergence.cascade.flow661
  %4277 = add i32 %convergence.cascade.depth662, 1
  %4278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4276)
  %4279 = icmp ult i32 %4277, 8
  %4280 = and i1 %4278, %4279
  %4281 = and i1 %4249, %4280
  %convergence.parent.token671 = load i32, ptr %current.token, align 4
  %convergence.parent.present672 = icmp ne i32 %convergence.parent.token671, 0
  %4282 = and i1 %4281, %convergence.parent.present672
  br i1 %4282, label %convergence.cascade657, label %convergence.cascade.exit658

convergence.cascade.exit658:                      ; preds = %convergence.cascade657, %schedule.35
  %convergence.cascade.result673 = phi <8 x i1> [ %760, %schedule.35 ], [ %4276, %convergence.cascade657 ]
  %4283 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result673)
  br i1 %4283, label %convergence.target.35.ready, label %scheduler.loop

convergence.target.35.ready:                      ; preds = %convergence.cascade.exit658
  %4284 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result673)
  %4285 = bitcast <8 x i1> %convergence.cascade.result673 to i8
  %4286 = call i8 @llvm.cttz.i8(i8 %4285, i1 false)
  %4287 = zext i8 %4286 to i32
  %4288 = select i1 %4284, i32 %4287, i32 0
  %4289 = load <8 x i64>, ptr %.slot119, align 64
  %4290 = select <8 x i1> %convergence.cascade.result673, <8 x i64> zeroinitializer, <8 x i64> %4289
  store <8 x i64> %4290, ptr %.slot119, align 64
  %4291 = load <8 x float>, ptr %.slot120, align 32
  %4292 = select <8 x i1> %convergence.cascade.result673, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4291
  store <8 x float> %4292, ptr %.slot120, align 32
  store <8 x i1> %convergence.cascade.result673, ptr %current.mask, align 1
  %4293 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result673)
  br i1 %4293, label %schedule.36, label %scheduler.loop

varying.divergent675:                             ; preds = %schedule.36
  %4294 = load i32, ptr %current.token, align 4
  %4295 = icmp ne i32 %4294, 0
  %4296 = sub i32 %4294, 1
  %4297 = select i1 %4295, i32 %4296, i32 0
  %4298 = load i8, ptr %frame.active, align 1
  %4299 = trunc i32 %4297 to i8
  %4300 = shl i8 1, %4299
  %4301 = and i8 %4298, %4300
  %4302 = icmp ne i8 %4301, 0
  %4303 = load <8 x i32>, ptr %frame.static.id, align 32
  %4304 = extractelement <8 x i32> %4303, i32 %4297
  %4305 = icmp eq i32 %4304, 13
  %4306 = and i1 %4302, %4305
  %4307 = and i1 %4295, %4306
  %4308 = xor i1 %4307, true
  %4309 = and i1 true, %4308
  %4310 = xor i8 %4298, -1
  %4311 = icmp ne i8 %4310, 0
  %4312 = xor i1 %4311, true
  %4313 = and i1 %4309, %4312
  br i1 %4313, label %convergence.overflow.trap677, label %convergence.overflow.resume678

varying.coherent676:                              ; preds = %schedule.36
  br i1 %771, label %varying.coherent.true681, label %varying.coherent.false682

convergence.overflow.trap677:                     ; preds = %varying.divergent675
  call void @llvm.trap()
  unreachable

convergence.overflow.resume678:                   ; preds = %varying.divergent675
  %4314 = call i8 @llvm.cttz.i8(i8 %4310, i1 false)
  %4315 = zext i8 %4314 to i32
  %4316 = select i1 %4311, i32 %4315, i32 0
  %4317 = trunc i32 %4316 to i8
  %4318 = shl i8 1, %4317
  %4319 = or i8 %4298, %4318
  %4320 = select i1 %4309, i8 %4319, i8 %4298
  store i8 %4320, ptr %frame.active, align 1
  %4321 = load <8 x i32>, ptr %frame.static.id, align 32
  %4322 = extractelement <8 x i32> %4321, i32 %4316
  %4323 = select i1 %4309, i32 13, i32 %4322
  %4324 = load <8 x i32>, ptr %frame.static.id, align 32
  %4325 = insertelement <8 x i32> %4324, i32 %4323, i32 %4316
  store <8 x i32> %4325, ptr %frame.static.id, align 32
  %4326 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4327 = extractelement <8 x i32> %4326, i32 %4316
  %4328 = select i1 %4309, i32 %4294, i32 %4327
  %4329 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4330 = insertelement <8 x i32> %4329, i32 %4328, i32 %4316
  store <8 x i32> %4330, ptr %frame.parent.token, align 32
  %4331 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4316
  %4332 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4316
  %4333 = load <8 x i1>, ptr %4331, align 1
  %4334 = load <8 x i1>, ptr %4332, align 1
  %4335 = select i1 %4309, <8 x i1> %761, <8 x i1> %4333
  store <8 x i1> %4335, ptr %4331, align 1
  %4336 = select i1 %4309, <8 x i1> zeroinitializer, <8 x i1> %4334
  store <8 x i1> %4336, ptr %4332, align 1
  %4337 = add i32 %4316, 1
  %4338 = select i1 %4307, i32 %4294, i32 %4337
  %4339 = select i1 true, i32 %4338, i32 %4294
  store i32 %4339, ptr %current.token, align 4
  %4340 = load i32, ptr %current.token, align 4
  %4341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %768)
  %4342 = load i32, ptr %ready.count, align 4
  %4343 = icmp uge i32 %4342, 8
  %4344 = and i1 %4341, %4343
  br i1 %4344, label %ready.overflow.trap679, label %ready.overflow.resume680

ready.overflow.trap679:                           ; preds = %convergence.overflow.resume678
  call void @llvm.trap()
  unreachable

ready.overflow.resume680:                         ; preds = %convergence.overflow.resume678
  %4345 = select i1 %4341, i32 %4342, i32 0
  %4346 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4345
  %4347 = load <8 x i1>, ptr %4346, align 1
  %4348 = select i1 %4341, <8 x i1> %768, <8 x i1> %4347
  store <8 x i1> %4348, ptr %4346, align 1
  %4349 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4345
  %4350 = load i32, ptr %4349, align 4
  %4351 = select i1 %4341, i32 37, i32 %4350
  store i32 %4351, ptr %4349, align 4
  %4352 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4345
  %4353 = load i32, ptr %4352, align 4
  %4354 = select i1 %4341, i32 %4340, i32 %4353
  store i32 %4354, ptr %4352, align 4
  %4355 = add i32 %4342, 1
  %4356 = select i1 %4341, i32 %4355, i32 %4342
  store i32 %4356, ptr %ready.count, align 4
  %4357 = load <8 x i1>, ptr %runnable.mask, align 1
  %4358 = or <8 x i1> %4357, %768
  store <8 x i1> %4358, ptr %runnable.mask, align 1
  store <8 x i1> %770, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true681:                         ; preds = %varying.coherent676
  store <8 x i1> %761, ptr %current.mask, align 1
  %4359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %761)
  br i1 %4359, label %schedule.37, label %scheduler.loop

varying.coherent.false682:                        ; preds = %varying.coherent676
  store <8 x i1> %761, ptr %current.mask, align 1
  %4360 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %761)
  br i1 %4360, label %schedule.38, label %scheduler.loop

convergence.cascade687:                           ; preds = %convergence.cascade687, %schedule.38
  %convergence.cascade.flow691 = phi <8 x i1> [ %801, %schedule.38 ], [ %4403, %convergence.cascade687 ]
  %convergence.cascade.depth692 = phi i32 [ 0, %schedule.38 ], [ %4404, %convergence.cascade687 ]
  %4361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow691)
  %4362 = load i32, ptr %current.token, align 4
  %4363 = icmp ne i32 %4362, 0
  %4364 = and i1 %4361, %4363
  %4365 = sub i32 %4362, 1
  %4366 = select i1 %4364, i32 %4365, i32 0
  %4367 = load i8, ptr %frame.active, align 1
  %4368 = trunc i32 %4366 to i8
  %4369 = shl i8 1, %4368
  %4370 = and i8 %4367, %4369
  %4371 = icmp ne i8 %4370, 0
  %4372 = load <8 x i32>, ptr %frame.static.id, align 32
  %4373 = extractelement <8 x i32> %4372, i32 %4366
  %convergence.target.pointer693 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4373
  %convergence.dynamic.target694 = load i32, ptr %convergence.target.pointer693, align 4
  %4374 = icmp eq i32 %convergence.dynamic.target694, 38
  %4375 = and i1 %4371, %4374
  %4376 = and i1 %4364, %4375
  %4377 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4366
  %4378 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4366
  %4379 = load <8 x i1>, ptr %4377, align 1
  %4380 = load <8 x i1>, ptr %4378, align 1
  %4381 = or <8 x i1> %4380, %convergence.cascade.flow691
  %4382 = load <8 x i1>, ptr %live.mask, align 1
  %4383 = and <8 x i1> %4379, %4382
  %4384 = icmp eq <8 x i1> %4381, %4383
  %4385 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4384)
  %4386 = and i1 %4376, %4385
  %4387 = select i1 %4386, <8 x i1> zeroinitializer, <8 x i1> %4381
  %4388 = select i1 %4376, <8 x i1> %4387, <8 x i1> %4380
  store <8 x i1> %4388, ptr %4378, align 1
  %4389 = select i1 %4386, <8 x i1> zeroinitializer, <8 x i1> %4379
  store <8 x i1> %4389, ptr %4377, align 1
  %4390 = trunc i32 %4366 to i8
  %4391 = shl i8 1, %4390
  %4392 = xor i8 %4391, -1
  %4393 = and i8 %4367, %4392
  %4394 = select i1 %4386, i8 %4393, i8 %4367
  store i8 %4394, ptr %frame.active, align 1
  %.splatinsert695 = insertelement <8 x i1> poison, i1 %4376, i64 0
  %.splat696 = shufflevector <8 x i1> %.splatinsert695, <8 x i1> poison, <8 x i32> zeroinitializer
  %4395 = and <8 x i1> %convergence.cascade.flow691, %.splat696
  %4396 = load <8 x i1>, ptr %runnable.mask, align 1
  %4397 = xor <8 x i1> %4395, splat (i1 true)
  %4398 = and <8 x i1> %4396, %4397
  store <8 x i1> %4398, ptr %runnable.mask, align 1
  %.splatinsert697 = insertelement <8 x i1> poison, i1 %4386, i64 0
  %.splat698 = shufflevector <8 x i1> %.splatinsert697, <8 x i1> poison, <8 x i32> zeroinitializer
  %4399 = select <8 x i1> %.splat698, <8 x i1> %4381, <8 x i1> zeroinitializer
  %4400 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4401 = extractelement <8 x i32> %4400, i32 %4366
  %4402 = select i1 %4386, i32 %4401, i32 %4362
  store i32 %4402, ptr %current.token, align 4
  %.splatinsert699 = insertelement <8 x i1> poison, i1 %4376, i64 0
  %.splat700 = shufflevector <8 x i1> %.splatinsert699, <8 x i1> poison, <8 x i32> zeroinitializer
  %4403 = select <8 x i1> %.splat700, <8 x i1> %4399, <8 x i1> %convergence.cascade.flow691
  %4404 = add i32 %convergence.cascade.depth692, 1
  %4405 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4403)
  %4406 = icmp ult i32 %4404, 8
  %4407 = and i1 %4405, %4406
  %4408 = and i1 %4376, %4407
  %convergence.parent.token701 = load i32, ptr %current.token, align 4
  %convergence.parent.present702 = icmp ne i32 %convergence.parent.token701, 0
  %4409 = and i1 %4408, %convergence.parent.present702
  br i1 %4409, label %convergence.cascade687, label %convergence.cascade.exit688

convergence.cascade.exit688:                      ; preds = %convergence.cascade687, %schedule.38
  %convergence.cascade.result703 = phi <8 x i1> [ %801, %schedule.38 ], [ %4403, %convergence.cascade687 ]
  %4410 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result703)
  br i1 %4410, label %convergence.target.38.ready, label %scheduler.loop

convergence.target.38.ready:                      ; preds = %convergence.cascade.exit688
  %4411 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result703)
  %4412 = bitcast <8 x i1> %convergence.cascade.result703 to i8
  %4413 = call i8 @llvm.cttz.i8(i8 %4412, i1 false)
  %4414 = zext i8 %4413 to i32
  %4415 = select i1 %4411, i32 %4414, i32 0
  %4416 = load <8 x i64>, ptr %.slot121, align 64
  %4417 = select <8 x i1> %convergence.cascade.result703, <8 x i64> zeroinitializer, <8 x i64> %4416
  store <8 x i64> %4417, ptr %.slot121, align 64
  %4418 = load <8 x float>, ptr %.slot122, align 32
  %4419 = select <8 x i1> %convergence.cascade.result703, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4418
  store <8 x float> %4419, ptr %.slot122, align 32
  store <8 x i1> %convergence.cascade.result703, ptr %current.mask, align 1
  %4420 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result703)
  br i1 %4420, label %schedule.39, label %scheduler.loop

varying.divergent705:                             ; preds = %schedule.39
  %4421 = load i32, ptr %current.token, align 4
  %4422 = icmp ne i32 %4421, 0
  %4423 = sub i32 %4421, 1
  %4424 = select i1 %4422, i32 %4423, i32 0
  %4425 = load i8, ptr %frame.active, align 1
  %4426 = trunc i32 %4424 to i8
  %4427 = shl i8 1, %4426
  %4428 = and i8 %4425, %4427
  %4429 = icmp ne i8 %4428, 0
  %4430 = load <8 x i32>, ptr %frame.static.id, align 32
  %4431 = extractelement <8 x i32> %4430, i32 %4424
  %4432 = icmp eq i32 %4431, 14
  %4433 = and i1 %4429, %4432
  %4434 = and i1 %4422, %4433
  %4435 = xor i1 %4434, true
  %4436 = and i1 true, %4435
  %4437 = xor i8 %4425, -1
  %4438 = icmp ne i8 %4437, 0
  %4439 = xor i1 %4438, true
  %4440 = and i1 %4436, %4439
  br i1 %4440, label %convergence.overflow.trap707, label %convergence.overflow.resume708

varying.coherent706:                              ; preds = %schedule.39
  br i1 %812, label %varying.coherent.true711, label %varying.coherent.false712

convergence.overflow.trap707:                     ; preds = %varying.divergent705
  call void @llvm.trap()
  unreachable

convergence.overflow.resume708:                   ; preds = %varying.divergent705
  %4441 = call i8 @llvm.cttz.i8(i8 %4437, i1 false)
  %4442 = zext i8 %4441 to i32
  %4443 = select i1 %4438, i32 %4442, i32 0
  %4444 = trunc i32 %4443 to i8
  %4445 = shl i8 1, %4444
  %4446 = or i8 %4425, %4445
  %4447 = select i1 %4436, i8 %4446, i8 %4425
  store i8 %4447, ptr %frame.active, align 1
  %4448 = load <8 x i32>, ptr %frame.static.id, align 32
  %4449 = extractelement <8 x i32> %4448, i32 %4443
  %4450 = select i1 %4436, i32 14, i32 %4449
  %4451 = load <8 x i32>, ptr %frame.static.id, align 32
  %4452 = insertelement <8 x i32> %4451, i32 %4450, i32 %4443
  store <8 x i32> %4452, ptr %frame.static.id, align 32
  %4453 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4454 = extractelement <8 x i32> %4453, i32 %4443
  %4455 = select i1 %4436, i32 %4421, i32 %4454
  %4456 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4457 = insertelement <8 x i32> %4456, i32 %4455, i32 %4443
  store <8 x i32> %4457, ptr %frame.parent.token, align 32
  %4458 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4443
  %4459 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4443
  %4460 = load <8 x i1>, ptr %4458, align 1
  %4461 = load <8 x i1>, ptr %4459, align 1
  %4462 = select i1 %4436, <8 x i1> %802, <8 x i1> %4460
  store <8 x i1> %4462, ptr %4458, align 1
  %4463 = select i1 %4436, <8 x i1> zeroinitializer, <8 x i1> %4461
  store <8 x i1> %4463, ptr %4459, align 1
  %4464 = add i32 %4443, 1
  %4465 = select i1 %4434, i32 %4421, i32 %4464
  %4466 = select i1 true, i32 %4465, i32 %4421
  store i32 %4466, ptr %current.token, align 4
  %4467 = load i32, ptr %current.token, align 4
  %4468 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %809)
  %4469 = load i32, ptr %ready.count, align 4
  %4470 = icmp uge i32 %4469, 8
  %4471 = and i1 %4468, %4470
  br i1 %4471, label %ready.overflow.trap709, label %ready.overflow.resume710

ready.overflow.trap709:                           ; preds = %convergence.overflow.resume708
  call void @llvm.trap()
  unreachable

ready.overflow.resume710:                         ; preds = %convergence.overflow.resume708
  %4472 = select i1 %4468, i32 %4469, i32 0
  %4473 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4472
  %4474 = load <8 x i1>, ptr %4473, align 1
  %4475 = select i1 %4468, <8 x i1> %809, <8 x i1> %4474
  store <8 x i1> %4475, ptr %4473, align 1
  %4476 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4472
  %4477 = load i32, ptr %4476, align 4
  %4478 = select i1 %4468, i32 40, i32 %4477
  store i32 %4478, ptr %4476, align 4
  %4479 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4472
  %4480 = load i32, ptr %4479, align 4
  %4481 = select i1 %4468, i32 %4467, i32 %4480
  store i32 %4481, ptr %4479, align 4
  %4482 = add i32 %4469, 1
  %4483 = select i1 %4468, i32 %4482, i32 %4469
  store i32 %4483, ptr %ready.count, align 4
  %4484 = load <8 x i1>, ptr %runnable.mask, align 1
  %4485 = or <8 x i1> %4484, %809
  store <8 x i1> %4485, ptr %runnable.mask, align 1
  store <8 x i1> %811, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true711:                         ; preds = %varying.coherent706
  store <8 x i1> %802, ptr %current.mask, align 1
  %4486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %802)
  br i1 %4486, label %schedule.40, label %scheduler.loop

varying.coherent.false712:                        ; preds = %varying.coherent706
  store <8 x i1> %802, ptr %current.mask, align 1
  %4487 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %802)
  br i1 %4487, label %schedule.41, label %scheduler.loop

convergence.cascade717:                           ; preds = %convergence.cascade717, %schedule.41
  %convergence.cascade.flow721 = phi <8 x i1> [ %842, %schedule.41 ], [ %4530, %convergence.cascade717 ]
  %convergence.cascade.depth722 = phi i32 [ 0, %schedule.41 ], [ %4531, %convergence.cascade717 ]
  %4488 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow721)
  %4489 = load i32, ptr %current.token, align 4
  %4490 = icmp ne i32 %4489, 0
  %4491 = and i1 %4488, %4490
  %4492 = sub i32 %4489, 1
  %4493 = select i1 %4491, i32 %4492, i32 0
  %4494 = load i8, ptr %frame.active, align 1
  %4495 = trunc i32 %4493 to i8
  %4496 = shl i8 1, %4495
  %4497 = and i8 %4494, %4496
  %4498 = icmp ne i8 %4497, 0
  %4499 = load <8 x i32>, ptr %frame.static.id, align 32
  %4500 = extractelement <8 x i32> %4499, i32 %4493
  %convergence.target.pointer723 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4500
  %convergence.dynamic.target724 = load i32, ptr %convergence.target.pointer723, align 4
  %4501 = icmp eq i32 %convergence.dynamic.target724, 41
  %4502 = and i1 %4498, %4501
  %4503 = and i1 %4491, %4502
  %4504 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4493
  %4505 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4493
  %4506 = load <8 x i1>, ptr %4504, align 1
  %4507 = load <8 x i1>, ptr %4505, align 1
  %4508 = or <8 x i1> %4507, %convergence.cascade.flow721
  %4509 = load <8 x i1>, ptr %live.mask, align 1
  %4510 = and <8 x i1> %4506, %4509
  %4511 = icmp eq <8 x i1> %4508, %4510
  %4512 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4511)
  %4513 = and i1 %4503, %4512
  %4514 = select i1 %4513, <8 x i1> zeroinitializer, <8 x i1> %4508
  %4515 = select i1 %4503, <8 x i1> %4514, <8 x i1> %4507
  store <8 x i1> %4515, ptr %4505, align 1
  %4516 = select i1 %4513, <8 x i1> zeroinitializer, <8 x i1> %4506
  store <8 x i1> %4516, ptr %4504, align 1
  %4517 = trunc i32 %4493 to i8
  %4518 = shl i8 1, %4517
  %4519 = xor i8 %4518, -1
  %4520 = and i8 %4494, %4519
  %4521 = select i1 %4513, i8 %4520, i8 %4494
  store i8 %4521, ptr %frame.active, align 1
  %.splatinsert725 = insertelement <8 x i1> poison, i1 %4503, i64 0
  %.splat726 = shufflevector <8 x i1> %.splatinsert725, <8 x i1> poison, <8 x i32> zeroinitializer
  %4522 = and <8 x i1> %convergence.cascade.flow721, %.splat726
  %4523 = load <8 x i1>, ptr %runnable.mask, align 1
  %4524 = xor <8 x i1> %4522, splat (i1 true)
  %4525 = and <8 x i1> %4523, %4524
  store <8 x i1> %4525, ptr %runnable.mask, align 1
  %.splatinsert727 = insertelement <8 x i1> poison, i1 %4513, i64 0
  %.splat728 = shufflevector <8 x i1> %.splatinsert727, <8 x i1> poison, <8 x i32> zeroinitializer
  %4526 = select <8 x i1> %.splat728, <8 x i1> %4508, <8 x i1> zeroinitializer
  %4527 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4528 = extractelement <8 x i32> %4527, i32 %4493
  %4529 = select i1 %4513, i32 %4528, i32 %4489
  store i32 %4529, ptr %current.token, align 4
  %.splatinsert729 = insertelement <8 x i1> poison, i1 %4503, i64 0
  %.splat730 = shufflevector <8 x i1> %.splatinsert729, <8 x i1> poison, <8 x i32> zeroinitializer
  %4530 = select <8 x i1> %.splat730, <8 x i1> %4526, <8 x i1> %convergence.cascade.flow721
  %4531 = add i32 %convergence.cascade.depth722, 1
  %4532 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4530)
  %4533 = icmp ult i32 %4531, 8
  %4534 = and i1 %4532, %4533
  %4535 = and i1 %4503, %4534
  %convergence.parent.token731 = load i32, ptr %current.token, align 4
  %convergence.parent.present732 = icmp ne i32 %convergence.parent.token731, 0
  %4536 = and i1 %4535, %convergence.parent.present732
  br i1 %4536, label %convergence.cascade717, label %convergence.cascade.exit718

convergence.cascade.exit718:                      ; preds = %convergence.cascade717, %schedule.41
  %convergence.cascade.result733 = phi <8 x i1> [ %842, %schedule.41 ], [ %4530, %convergence.cascade717 ]
  %4537 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result733)
  br i1 %4537, label %convergence.target.41.ready, label %scheduler.loop

convergence.target.41.ready:                      ; preds = %convergence.cascade.exit718
  %4538 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result733)
  %4539 = bitcast <8 x i1> %convergence.cascade.result733 to i8
  %4540 = call i8 @llvm.cttz.i8(i8 %4539, i1 false)
  %4541 = zext i8 %4540 to i32
  %4542 = select i1 %4538, i32 %4541, i32 0
  %4543 = load <8 x i64>, ptr %.slot123, align 64
  %4544 = select <8 x i1> %convergence.cascade.result733, <8 x i64> zeroinitializer, <8 x i64> %4543
  store <8 x i64> %4544, ptr %.slot123, align 64
  %4545 = load <8 x float>, ptr %.slot124, align 32
  %4546 = select <8 x i1> %convergence.cascade.result733, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4545
  store <8 x float> %4546, ptr %.slot124, align 32
  store <8 x i1> %convergence.cascade.result733, ptr %current.mask, align 1
  %4547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result733)
  br i1 %4547, label %schedule.42, label %scheduler.loop

varying.divergent735:                             ; preds = %schedule.42
  %4548 = load i32, ptr %current.token, align 4
  %4549 = icmp ne i32 %4548, 0
  %4550 = sub i32 %4548, 1
  %4551 = select i1 %4549, i32 %4550, i32 0
  %4552 = load i8, ptr %frame.active, align 1
  %4553 = trunc i32 %4551 to i8
  %4554 = shl i8 1, %4553
  %4555 = and i8 %4552, %4554
  %4556 = icmp ne i8 %4555, 0
  %4557 = load <8 x i32>, ptr %frame.static.id, align 32
  %4558 = extractelement <8 x i32> %4557, i32 %4551
  %4559 = icmp eq i32 %4558, 15
  %4560 = and i1 %4556, %4559
  %4561 = and i1 %4549, %4560
  %4562 = xor i1 %4561, true
  %4563 = and i1 true, %4562
  %4564 = xor i8 %4552, -1
  %4565 = icmp ne i8 %4564, 0
  %4566 = xor i1 %4565, true
  %4567 = and i1 %4563, %4566
  br i1 %4567, label %convergence.overflow.trap737, label %convergence.overflow.resume738

varying.coherent736:                              ; preds = %schedule.42
  br i1 %853, label %varying.coherent.true741, label %varying.coherent.false742

convergence.overflow.trap737:                     ; preds = %varying.divergent735
  call void @llvm.trap()
  unreachable

convergence.overflow.resume738:                   ; preds = %varying.divergent735
  %4568 = call i8 @llvm.cttz.i8(i8 %4564, i1 false)
  %4569 = zext i8 %4568 to i32
  %4570 = select i1 %4565, i32 %4569, i32 0
  %4571 = trunc i32 %4570 to i8
  %4572 = shl i8 1, %4571
  %4573 = or i8 %4552, %4572
  %4574 = select i1 %4563, i8 %4573, i8 %4552
  store i8 %4574, ptr %frame.active, align 1
  %4575 = load <8 x i32>, ptr %frame.static.id, align 32
  %4576 = extractelement <8 x i32> %4575, i32 %4570
  %4577 = select i1 %4563, i32 15, i32 %4576
  %4578 = load <8 x i32>, ptr %frame.static.id, align 32
  %4579 = insertelement <8 x i32> %4578, i32 %4577, i32 %4570
  store <8 x i32> %4579, ptr %frame.static.id, align 32
  %4580 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4581 = extractelement <8 x i32> %4580, i32 %4570
  %4582 = select i1 %4563, i32 %4548, i32 %4581
  %4583 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4584 = insertelement <8 x i32> %4583, i32 %4582, i32 %4570
  store <8 x i32> %4584, ptr %frame.parent.token, align 32
  %4585 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4570
  %4586 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4570
  %4587 = load <8 x i1>, ptr %4585, align 1
  %4588 = load <8 x i1>, ptr %4586, align 1
  %4589 = select i1 %4563, <8 x i1> %843, <8 x i1> %4587
  store <8 x i1> %4589, ptr %4585, align 1
  %4590 = select i1 %4563, <8 x i1> zeroinitializer, <8 x i1> %4588
  store <8 x i1> %4590, ptr %4586, align 1
  %4591 = add i32 %4570, 1
  %4592 = select i1 %4561, i32 %4548, i32 %4591
  %4593 = select i1 true, i32 %4592, i32 %4548
  store i32 %4593, ptr %current.token, align 4
  %4594 = load i32, ptr %current.token, align 4
  %4595 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %850)
  %4596 = load i32, ptr %ready.count, align 4
  %4597 = icmp uge i32 %4596, 8
  %4598 = and i1 %4595, %4597
  br i1 %4598, label %ready.overflow.trap739, label %ready.overflow.resume740

ready.overflow.trap739:                           ; preds = %convergence.overflow.resume738
  call void @llvm.trap()
  unreachable

ready.overflow.resume740:                         ; preds = %convergence.overflow.resume738
  %4599 = select i1 %4595, i32 %4596, i32 0
  %4600 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4599
  %4601 = load <8 x i1>, ptr %4600, align 1
  %4602 = select i1 %4595, <8 x i1> %850, <8 x i1> %4601
  store <8 x i1> %4602, ptr %4600, align 1
  %4603 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4599
  %4604 = load i32, ptr %4603, align 4
  %4605 = select i1 %4595, i32 43, i32 %4604
  store i32 %4605, ptr %4603, align 4
  %4606 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4599
  %4607 = load i32, ptr %4606, align 4
  %4608 = select i1 %4595, i32 %4594, i32 %4607
  store i32 %4608, ptr %4606, align 4
  %4609 = add i32 %4596, 1
  %4610 = select i1 %4595, i32 %4609, i32 %4596
  store i32 %4610, ptr %ready.count, align 4
  %4611 = load <8 x i1>, ptr %runnable.mask, align 1
  %4612 = or <8 x i1> %4611, %850
  store <8 x i1> %4612, ptr %runnable.mask, align 1
  store <8 x i1> %852, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true741:                         ; preds = %varying.coherent736
  store <8 x i1> %843, ptr %current.mask, align 1
  %4613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %843)
  br i1 %4613, label %schedule.43, label %scheduler.loop

varying.coherent.false742:                        ; preds = %varying.coherent736
  store <8 x i1> %843, ptr %current.mask, align 1
  %4614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %843)
  br i1 %4614, label %schedule.44, label %scheduler.loop

convergence.cascade747:                           ; preds = %convergence.cascade747, %schedule.44
  %convergence.cascade.flow751 = phi <8 x i1> [ %883, %schedule.44 ], [ %4657, %convergence.cascade747 ]
  %convergence.cascade.depth752 = phi i32 [ 0, %schedule.44 ], [ %4658, %convergence.cascade747 ]
  %4615 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow751)
  %4616 = load i32, ptr %current.token, align 4
  %4617 = icmp ne i32 %4616, 0
  %4618 = and i1 %4615, %4617
  %4619 = sub i32 %4616, 1
  %4620 = select i1 %4618, i32 %4619, i32 0
  %4621 = load i8, ptr %frame.active, align 1
  %4622 = trunc i32 %4620 to i8
  %4623 = shl i8 1, %4622
  %4624 = and i8 %4621, %4623
  %4625 = icmp ne i8 %4624, 0
  %4626 = load <8 x i32>, ptr %frame.static.id, align 32
  %4627 = extractelement <8 x i32> %4626, i32 %4620
  %convergence.target.pointer753 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4627
  %convergence.dynamic.target754 = load i32, ptr %convergence.target.pointer753, align 4
  %4628 = icmp eq i32 %convergence.dynamic.target754, 44
  %4629 = and i1 %4625, %4628
  %4630 = and i1 %4618, %4629
  %4631 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4620
  %4632 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4620
  %4633 = load <8 x i1>, ptr %4631, align 1
  %4634 = load <8 x i1>, ptr %4632, align 1
  %4635 = or <8 x i1> %4634, %convergence.cascade.flow751
  %4636 = load <8 x i1>, ptr %live.mask, align 1
  %4637 = and <8 x i1> %4633, %4636
  %4638 = icmp eq <8 x i1> %4635, %4637
  %4639 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4638)
  %4640 = and i1 %4630, %4639
  %4641 = select i1 %4640, <8 x i1> zeroinitializer, <8 x i1> %4635
  %4642 = select i1 %4630, <8 x i1> %4641, <8 x i1> %4634
  store <8 x i1> %4642, ptr %4632, align 1
  %4643 = select i1 %4640, <8 x i1> zeroinitializer, <8 x i1> %4633
  store <8 x i1> %4643, ptr %4631, align 1
  %4644 = trunc i32 %4620 to i8
  %4645 = shl i8 1, %4644
  %4646 = xor i8 %4645, -1
  %4647 = and i8 %4621, %4646
  %4648 = select i1 %4640, i8 %4647, i8 %4621
  store i8 %4648, ptr %frame.active, align 1
  %.splatinsert755 = insertelement <8 x i1> poison, i1 %4630, i64 0
  %.splat756 = shufflevector <8 x i1> %.splatinsert755, <8 x i1> poison, <8 x i32> zeroinitializer
  %4649 = and <8 x i1> %convergence.cascade.flow751, %.splat756
  %4650 = load <8 x i1>, ptr %runnable.mask, align 1
  %4651 = xor <8 x i1> %4649, splat (i1 true)
  %4652 = and <8 x i1> %4650, %4651
  store <8 x i1> %4652, ptr %runnable.mask, align 1
  %.splatinsert757 = insertelement <8 x i1> poison, i1 %4640, i64 0
  %.splat758 = shufflevector <8 x i1> %.splatinsert757, <8 x i1> poison, <8 x i32> zeroinitializer
  %4653 = select <8 x i1> %.splat758, <8 x i1> %4635, <8 x i1> zeroinitializer
  %4654 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4655 = extractelement <8 x i32> %4654, i32 %4620
  %4656 = select i1 %4640, i32 %4655, i32 %4616
  store i32 %4656, ptr %current.token, align 4
  %.splatinsert759 = insertelement <8 x i1> poison, i1 %4630, i64 0
  %.splat760 = shufflevector <8 x i1> %.splatinsert759, <8 x i1> poison, <8 x i32> zeroinitializer
  %4657 = select <8 x i1> %.splat760, <8 x i1> %4653, <8 x i1> %convergence.cascade.flow751
  %4658 = add i32 %convergence.cascade.depth752, 1
  %4659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4657)
  %4660 = icmp ult i32 %4658, 8
  %4661 = and i1 %4659, %4660
  %4662 = and i1 %4630, %4661
  %convergence.parent.token761 = load i32, ptr %current.token, align 4
  %convergence.parent.present762 = icmp ne i32 %convergence.parent.token761, 0
  %4663 = and i1 %4662, %convergence.parent.present762
  br i1 %4663, label %convergence.cascade747, label %convergence.cascade.exit748

convergence.cascade.exit748:                      ; preds = %convergence.cascade747, %schedule.44
  %convergence.cascade.result763 = phi <8 x i1> [ %883, %schedule.44 ], [ %4657, %convergence.cascade747 ]
  %4664 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result763)
  br i1 %4664, label %convergence.target.44.ready, label %scheduler.loop

convergence.target.44.ready:                      ; preds = %convergence.cascade.exit748
  %4665 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result763)
  %4666 = bitcast <8 x i1> %convergence.cascade.result763 to i8
  %4667 = call i8 @llvm.cttz.i8(i8 %4666, i1 false)
  %4668 = zext i8 %4667 to i32
  %4669 = select i1 %4665, i32 %4668, i32 0
  %4670 = load <8 x i64>, ptr %.slot125, align 64
  %4671 = select <8 x i1> %convergence.cascade.result763, <8 x i64> zeroinitializer, <8 x i64> %4670
  store <8 x i64> %4671, ptr %.slot125, align 64
  %4672 = load <8 x float>, ptr %.slot126, align 32
  %4673 = select <8 x i1> %convergence.cascade.result763, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4672
  store <8 x float> %4673, ptr %.slot126, align 32
  store <8 x i1> %convergence.cascade.result763, ptr %current.mask, align 1
  %4674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result763)
  br i1 %4674, label %schedule.45, label %scheduler.loop

varying.divergent765:                             ; preds = %schedule.45
  %4675 = load i32, ptr %current.token, align 4
  %4676 = icmp ne i32 %4675, 0
  %4677 = sub i32 %4675, 1
  %4678 = select i1 %4676, i32 %4677, i32 0
  %4679 = load i8, ptr %frame.active, align 1
  %4680 = trunc i32 %4678 to i8
  %4681 = shl i8 1, %4680
  %4682 = and i8 %4679, %4681
  %4683 = icmp ne i8 %4682, 0
  %4684 = load <8 x i32>, ptr %frame.static.id, align 32
  %4685 = extractelement <8 x i32> %4684, i32 %4678
  %4686 = icmp eq i32 %4685, 16
  %4687 = and i1 %4683, %4686
  %4688 = and i1 %4676, %4687
  %4689 = xor i1 %4688, true
  %4690 = and i1 true, %4689
  %4691 = xor i8 %4679, -1
  %4692 = icmp ne i8 %4691, 0
  %4693 = xor i1 %4692, true
  %4694 = and i1 %4690, %4693
  br i1 %4694, label %convergence.overflow.trap767, label %convergence.overflow.resume768

varying.coherent766:                              ; preds = %schedule.45
  br i1 %894, label %varying.coherent.true771, label %varying.coherent.false772

convergence.overflow.trap767:                     ; preds = %varying.divergent765
  call void @llvm.trap()
  unreachable

convergence.overflow.resume768:                   ; preds = %varying.divergent765
  %4695 = call i8 @llvm.cttz.i8(i8 %4691, i1 false)
  %4696 = zext i8 %4695 to i32
  %4697 = select i1 %4692, i32 %4696, i32 0
  %4698 = trunc i32 %4697 to i8
  %4699 = shl i8 1, %4698
  %4700 = or i8 %4679, %4699
  %4701 = select i1 %4690, i8 %4700, i8 %4679
  store i8 %4701, ptr %frame.active, align 1
  %4702 = load <8 x i32>, ptr %frame.static.id, align 32
  %4703 = extractelement <8 x i32> %4702, i32 %4697
  %4704 = select i1 %4690, i32 16, i32 %4703
  %4705 = load <8 x i32>, ptr %frame.static.id, align 32
  %4706 = insertelement <8 x i32> %4705, i32 %4704, i32 %4697
  store <8 x i32> %4706, ptr %frame.static.id, align 32
  %4707 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4708 = extractelement <8 x i32> %4707, i32 %4697
  %4709 = select i1 %4690, i32 %4675, i32 %4708
  %4710 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4711 = insertelement <8 x i32> %4710, i32 %4709, i32 %4697
  store <8 x i32> %4711, ptr %frame.parent.token, align 32
  %4712 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4697
  %4713 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4697
  %4714 = load <8 x i1>, ptr %4712, align 1
  %4715 = load <8 x i1>, ptr %4713, align 1
  %4716 = select i1 %4690, <8 x i1> %884, <8 x i1> %4714
  store <8 x i1> %4716, ptr %4712, align 1
  %4717 = select i1 %4690, <8 x i1> zeroinitializer, <8 x i1> %4715
  store <8 x i1> %4717, ptr %4713, align 1
  %4718 = add i32 %4697, 1
  %4719 = select i1 %4688, i32 %4675, i32 %4718
  %4720 = select i1 true, i32 %4719, i32 %4675
  store i32 %4720, ptr %current.token, align 4
  %4721 = load i32, ptr %current.token, align 4
  %4722 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %891)
  %4723 = load i32, ptr %ready.count, align 4
  %4724 = icmp uge i32 %4723, 8
  %4725 = and i1 %4722, %4724
  br i1 %4725, label %ready.overflow.trap769, label %ready.overflow.resume770

ready.overflow.trap769:                           ; preds = %convergence.overflow.resume768
  call void @llvm.trap()
  unreachable

ready.overflow.resume770:                         ; preds = %convergence.overflow.resume768
  %4726 = select i1 %4722, i32 %4723, i32 0
  %4727 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4726
  %4728 = load <8 x i1>, ptr %4727, align 1
  %4729 = select i1 %4722, <8 x i1> %891, <8 x i1> %4728
  store <8 x i1> %4729, ptr %4727, align 1
  %4730 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4726
  %4731 = load i32, ptr %4730, align 4
  %4732 = select i1 %4722, i32 46, i32 %4731
  store i32 %4732, ptr %4730, align 4
  %4733 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4726
  %4734 = load i32, ptr %4733, align 4
  %4735 = select i1 %4722, i32 %4721, i32 %4734
  store i32 %4735, ptr %4733, align 4
  %4736 = add i32 %4723, 1
  %4737 = select i1 %4722, i32 %4736, i32 %4723
  store i32 %4737, ptr %ready.count, align 4
  %4738 = load <8 x i1>, ptr %runnable.mask, align 1
  %4739 = or <8 x i1> %4738, %891
  store <8 x i1> %4739, ptr %runnable.mask, align 1
  store <8 x i1> %893, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true771:                         ; preds = %varying.coherent766
  store <8 x i1> %884, ptr %current.mask, align 1
  %4740 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %884)
  br i1 %4740, label %schedule.46, label %scheduler.loop

varying.coherent.false772:                        ; preds = %varying.coherent766
  store <8 x i1> %884, ptr %current.mask, align 1
  %4741 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %884)
  br i1 %4741, label %schedule.47, label %scheduler.loop

convergence.cascade777:                           ; preds = %convergence.cascade777, %schedule.47
  %convergence.cascade.flow781 = phi <8 x i1> [ %924, %schedule.47 ], [ %4784, %convergence.cascade777 ]
  %convergence.cascade.depth782 = phi i32 [ 0, %schedule.47 ], [ %4785, %convergence.cascade777 ]
  %4742 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow781)
  %4743 = load i32, ptr %current.token, align 4
  %4744 = icmp ne i32 %4743, 0
  %4745 = and i1 %4742, %4744
  %4746 = sub i32 %4743, 1
  %4747 = select i1 %4745, i32 %4746, i32 0
  %4748 = load i8, ptr %frame.active, align 1
  %4749 = trunc i32 %4747 to i8
  %4750 = shl i8 1, %4749
  %4751 = and i8 %4748, %4750
  %4752 = icmp ne i8 %4751, 0
  %4753 = load <8 x i32>, ptr %frame.static.id, align 32
  %4754 = extractelement <8 x i32> %4753, i32 %4747
  %convergence.target.pointer783 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4754
  %convergence.dynamic.target784 = load i32, ptr %convergence.target.pointer783, align 4
  %4755 = icmp eq i32 %convergence.dynamic.target784, 47
  %4756 = and i1 %4752, %4755
  %4757 = and i1 %4745, %4756
  %4758 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4747
  %4759 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4747
  %4760 = load <8 x i1>, ptr %4758, align 1
  %4761 = load <8 x i1>, ptr %4759, align 1
  %4762 = or <8 x i1> %4761, %convergence.cascade.flow781
  %4763 = load <8 x i1>, ptr %live.mask, align 1
  %4764 = and <8 x i1> %4760, %4763
  %4765 = icmp eq <8 x i1> %4762, %4764
  %4766 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4765)
  %4767 = and i1 %4757, %4766
  %4768 = select i1 %4767, <8 x i1> zeroinitializer, <8 x i1> %4762
  %4769 = select i1 %4757, <8 x i1> %4768, <8 x i1> %4761
  store <8 x i1> %4769, ptr %4759, align 1
  %4770 = select i1 %4767, <8 x i1> zeroinitializer, <8 x i1> %4760
  store <8 x i1> %4770, ptr %4758, align 1
  %4771 = trunc i32 %4747 to i8
  %4772 = shl i8 1, %4771
  %4773 = xor i8 %4772, -1
  %4774 = and i8 %4748, %4773
  %4775 = select i1 %4767, i8 %4774, i8 %4748
  store i8 %4775, ptr %frame.active, align 1
  %.splatinsert785 = insertelement <8 x i1> poison, i1 %4757, i64 0
  %.splat786 = shufflevector <8 x i1> %.splatinsert785, <8 x i1> poison, <8 x i32> zeroinitializer
  %4776 = and <8 x i1> %convergence.cascade.flow781, %.splat786
  %4777 = load <8 x i1>, ptr %runnable.mask, align 1
  %4778 = xor <8 x i1> %4776, splat (i1 true)
  %4779 = and <8 x i1> %4777, %4778
  store <8 x i1> %4779, ptr %runnable.mask, align 1
  %.splatinsert787 = insertelement <8 x i1> poison, i1 %4767, i64 0
  %.splat788 = shufflevector <8 x i1> %.splatinsert787, <8 x i1> poison, <8 x i32> zeroinitializer
  %4780 = select <8 x i1> %.splat788, <8 x i1> %4762, <8 x i1> zeroinitializer
  %4781 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4782 = extractelement <8 x i32> %4781, i32 %4747
  %4783 = select i1 %4767, i32 %4782, i32 %4743
  store i32 %4783, ptr %current.token, align 4
  %.splatinsert789 = insertelement <8 x i1> poison, i1 %4757, i64 0
  %.splat790 = shufflevector <8 x i1> %.splatinsert789, <8 x i1> poison, <8 x i32> zeroinitializer
  %4784 = select <8 x i1> %.splat790, <8 x i1> %4780, <8 x i1> %convergence.cascade.flow781
  %4785 = add i32 %convergence.cascade.depth782, 1
  %4786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4784)
  %4787 = icmp ult i32 %4785, 8
  %4788 = and i1 %4786, %4787
  %4789 = and i1 %4757, %4788
  %convergence.parent.token791 = load i32, ptr %current.token, align 4
  %convergence.parent.present792 = icmp ne i32 %convergence.parent.token791, 0
  %4790 = and i1 %4789, %convergence.parent.present792
  br i1 %4790, label %convergence.cascade777, label %convergence.cascade.exit778

convergence.cascade.exit778:                      ; preds = %convergence.cascade777, %schedule.47
  %convergence.cascade.result793 = phi <8 x i1> [ %924, %schedule.47 ], [ %4784, %convergence.cascade777 ]
  %4791 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result793)
  br i1 %4791, label %convergence.target.47.ready, label %scheduler.loop

convergence.target.47.ready:                      ; preds = %convergence.cascade.exit778
  %4792 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result793)
  %4793 = bitcast <8 x i1> %convergence.cascade.result793 to i8
  %4794 = call i8 @llvm.cttz.i8(i8 %4793, i1 false)
  %4795 = zext i8 %4794 to i32
  %4796 = select i1 %4792, i32 %4795, i32 0
  %4797 = load <8 x i64>, ptr %.slot127, align 64
  %4798 = select <8 x i1> %convergence.cascade.result793, <8 x i64> zeroinitializer, <8 x i64> %4797
  store <8 x i64> %4798, ptr %.slot127, align 64
  %4799 = load <8 x float>, ptr %.slot128, align 32
  %4800 = select <8 x i1> %convergence.cascade.result793, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4799
  store <8 x float> %4800, ptr %.slot128, align 32
  store <8 x i1> %convergence.cascade.result793, ptr %current.mask, align 1
  %4801 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result793)
  br i1 %4801, label %schedule.48, label %scheduler.loop

varying.divergent795:                             ; preds = %schedule.48
  %4802 = load i32, ptr %current.token, align 4
  %4803 = icmp ne i32 %4802, 0
  %4804 = sub i32 %4802, 1
  %4805 = select i1 %4803, i32 %4804, i32 0
  %4806 = load i8, ptr %frame.active, align 1
  %4807 = trunc i32 %4805 to i8
  %4808 = shl i8 1, %4807
  %4809 = and i8 %4806, %4808
  %4810 = icmp ne i8 %4809, 0
  %4811 = load <8 x i32>, ptr %frame.static.id, align 32
  %4812 = extractelement <8 x i32> %4811, i32 %4805
  %4813 = icmp eq i32 %4812, 17
  %4814 = and i1 %4810, %4813
  %4815 = and i1 %4803, %4814
  %4816 = xor i1 %4815, true
  %4817 = and i1 true, %4816
  %4818 = xor i8 %4806, -1
  %4819 = icmp ne i8 %4818, 0
  %4820 = xor i1 %4819, true
  %4821 = and i1 %4817, %4820
  br i1 %4821, label %convergence.overflow.trap797, label %convergence.overflow.resume798

varying.coherent796:                              ; preds = %schedule.48
  br i1 %935, label %varying.coherent.true801, label %varying.coherent.false802

convergence.overflow.trap797:                     ; preds = %varying.divergent795
  call void @llvm.trap()
  unreachable

convergence.overflow.resume798:                   ; preds = %varying.divergent795
  %4822 = call i8 @llvm.cttz.i8(i8 %4818, i1 false)
  %4823 = zext i8 %4822 to i32
  %4824 = select i1 %4819, i32 %4823, i32 0
  %4825 = trunc i32 %4824 to i8
  %4826 = shl i8 1, %4825
  %4827 = or i8 %4806, %4826
  %4828 = select i1 %4817, i8 %4827, i8 %4806
  store i8 %4828, ptr %frame.active, align 1
  %4829 = load <8 x i32>, ptr %frame.static.id, align 32
  %4830 = extractelement <8 x i32> %4829, i32 %4824
  %4831 = select i1 %4817, i32 17, i32 %4830
  %4832 = load <8 x i32>, ptr %frame.static.id, align 32
  %4833 = insertelement <8 x i32> %4832, i32 %4831, i32 %4824
  store <8 x i32> %4833, ptr %frame.static.id, align 32
  %4834 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4835 = extractelement <8 x i32> %4834, i32 %4824
  %4836 = select i1 %4817, i32 %4802, i32 %4835
  %4837 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4838 = insertelement <8 x i32> %4837, i32 %4836, i32 %4824
  store <8 x i32> %4838, ptr %frame.parent.token, align 32
  %4839 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4824
  %4840 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4824
  %4841 = load <8 x i1>, ptr %4839, align 1
  %4842 = load <8 x i1>, ptr %4840, align 1
  %4843 = select i1 %4817, <8 x i1> %925, <8 x i1> %4841
  store <8 x i1> %4843, ptr %4839, align 1
  %4844 = select i1 %4817, <8 x i1> zeroinitializer, <8 x i1> %4842
  store <8 x i1> %4844, ptr %4840, align 1
  %4845 = add i32 %4824, 1
  %4846 = select i1 %4815, i32 %4802, i32 %4845
  %4847 = select i1 true, i32 %4846, i32 %4802
  store i32 %4847, ptr %current.token, align 4
  %4848 = load i32, ptr %current.token, align 4
  %4849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %932)
  %4850 = load i32, ptr %ready.count, align 4
  %4851 = icmp uge i32 %4850, 8
  %4852 = and i1 %4849, %4851
  br i1 %4852, label %ready.overflow.trap799, label %ready.overflow.resume800

ready.overflow.trap799:                           ; preds = %convergence.overflow.resume798
  call void @llvm.trap()
  unreachable

ready.overflow.resume800:                         ; preds = %convergence.overflow.resume798
  %4853 = select i1 %4849, i32 %4850, i32 0
  %4854 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4853
  %4855 = load <8 x i1>, ptr %4854, align 1
  %4856 = select i1 %4849, <8 x i1> %932, <8 x i1> %4855
  store <8 x i1> %4856, ptr %4854, align 1
  %4857 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4853
  %4858 = load i32, ptr %4857, align 4
  %4859 = select i1 %4849, i32 49, i32 %4858
  store i32 %4859, ptr %4857, align 4
  %4860 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4853
  %4861 = load i32, ptr %4860, align 4
  %4862 = select i1 %4849, i32 %4848, i32 %4861
  store i32 %4862, ptr %4860, align 4
  %4863 = add i32 %4850, 1
  %4864 = select i1 %4849, i32 %4863, i32 %4850
  store i32 %4864, ptr %ready.count, align 4
  %4865 = load <8 x i1>, ptr %runnable.mask, align 1
  %4866 = or <8 x i1> %4865, %932
  store <8 x i1> %4866, ptr %runnable.mask, align 1
  store <8 x i1> %934, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true801:                         ; preds = %varying.coherent796
  store <8 x i1> %925, ptr %current.mask, align 1
  %4867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %925)
  br i1 %4867, label %schedule.49, label %scheduler.loop

varying.coherent.false802:                        ; preds = %varying.coherent796
  store <8 x i1> %925, ptr %current.mask, align 1
  %4868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %925)
  br i1 %4868, label %schedule.50, label %scheduler.loop

convergence.cascade807:                           ; preds = %convergence.cascade807, %schedule.50
  %convergence.cascade.flow811 = phi <8 x i1> [ %965, %schedule.50 ], [ %4911, %convergence.cascade807 ]
  %convergence.cascade.depth812 = phi i32 [ 0, %schedule.50 ], [ %4912, %convergence.cascade807 ]
  %4869 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow811)
  %4870 = load i32, ptr %current.token, align 4
  %4871 = icmp ne i32 %4870, 0
  %4872 = and i1 %4869, %4871
  %4873 = sub i32 %4870, 1
  %4874 = select i1 %4872, i32 %4873, i32 0
  %4875 = load i8, ptr %frame.active, align 1
  %4876 = trunc i32 %4874 to i8
  %4877 = shl i8 1, %4876
  %4878 = and i8 %4875, %4877
  %4879 = icmp ne i8 %4878, 0
  %4880 = load <8 x i32>, ptr %frame.static.id, align 32
  %4881 = extractelement <8 x i32> %4880, i32 %4874
  %convergence.target.pointer813 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %4881
  %convergence.dynamic.target814 = load i32, ptr %convergence.target.pointer813, align 4
  %4882 = icmp eq i32 %convergence.dynamic.target814, 50
  %4883 = and i1 %4879, %4882
  %4884 = and i1 %4872, %4883
  %4885 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4874
  %4886 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4874
  %4887 = load <8 x i1>, ptr %4885, align 1
  %4888 = load <8 x i1>, ptr %4886, align 1
  %4889 = or <8 x i1> %4888, %convergence.cascade.flow811
  %4890 = load <8 x i1>, ptr %live.mask, align 1
  %4891 = and <8 x i1> %4887, %4890
  %4892 = icmp eq <8 x i1> %4889, %4891
  %4893 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4892)
  %4894 = and i1 %4884, %4893
  %4895 = select i1 %4894, <8 x i1> zeroinitializer, <8 x i1> %4889
  %4896 = select i1 %4884, <8 x i1> %4895, <8 x i1> %4888
  store <8 x i1> %4896, ptr %4886, align 1
  %4897 = select i1 %4894, <8 x i1> zeroinitializer, <8 x i1> %4887
  store <8 x i1> %4897, ptr %4885, align 1
  %4898 = trunc i32 %4874 to i8
  %4899 = shl i8 1, %4898
  %4900 = xor i8 %4899, -1
  %4901 = and i8 %4875, %4900
  %4902 = select i1 %4894, i8 %4901, i8 %4875
  store i8 %4902, ptr %frame.active, align 1
  %.splatinsert815 = insertelement <8 x i1> poison, i1 %4884, i64 0
  %.splat816 = shufflevector <8 x i1> %.splatinsert815, <8 x i1> poison, <8 x i32> zeroinitializer
  %4903 = and <8 x i1> %convergence.cascade.flow811, %.splat816
  %4904 = load <8 x i1>, ptr %runnable.mask, align 1
  %4905 = xor <8 x i1> %4903, splat (i1 true)
  %4906 = and <8 x i1> %4904, %4905
  store <8 x i1> %4906, ptr %runnable.mask, align 1
  %.splatinsert817 = insertelement <8 x i1> poison, i1 %4894, i64 0
  %.splat818 = shufflevector <8 x i1> %.splatinsert817, <8 x i1> poison, <8 x i32> zeroinitializer
  %4907 = select <8 x i1> %.splat818, <8 x i1> %4889, <8 x i1> zeroinitializer
  %4908 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4909 = extractelement <8 x i32> %4908, i32 %4874
  %4910 = select i1 %4894, i32 %4909, i32 %4870
  store i32 %4910, ptr %current.token, align 4
  %.splatinsert819 = insertelement <8 x i1> poison, i1 %4884, i64 0
  %.splat820 = shufflevector <8 x i1> %.splatinsert819, <8 x i1> poison, <8 x i32> zeroinitializer
  %4911 = select <8 x i1> %.splat820, <8 x i1> %4907, <8 x i1> %convergence.cascade.flow811
  %4912 = add i32 %convergence.cascade.depth812, 1
  %4913 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4911)
  %4914 = icmp ult i32 %4912, 8
  %4915 = and i1 %4913, %4914
  %4916 = and i1 %4884, %4915
  %convergence.parent.token821 = load i32, ptr %current.token, align 4
  %convergence.parent.present822 = icmp ne i32 %convergence.parent.token821, 0
  %4917 = and i1 %4916, %convergence.parent.present822
  br i1 %4917, label %convergence.cascade807, label %convergence.cascade.exit808

convergence.cascade.exit808:                      ; preds = %convergence.cascade807, %schedule.50
  %convergence.cascade.result823 = phi <8 x i1> [ %965, %schedule.50 ], [ %4911, %convergence.cascade807 ]
  %4918 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result823)
  br i1 %4918, label %convergence.target.50.ready, label %scheduler.loop

convergence.target.50.ready:                      ; preds = %convergence.cascade.exit808
  %4919 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result823)
  %4920 = bitcast <8 x i1> %convergence.cascade.result823 to i8
  %4921 = call i8 @llvm.cttz.i8(i8 %4920, i1 false)
  %4922 = zext i8 %4921 to i32
  %4923 = select i1 %4919, i32 %4922, i32 0
  %4924 = load <8 x i64>, ptr %.slot129, align 64
  %4925 = select <8 x i1> %convergence.cascade.result823, <8 x i64> zeroinitializer, <8 x i64> %4924
  store <8 x i64> %4925, ptr %.slot129, align 64
  %4926 = load <8 x float>, ptr %.slot130, align 32
  %4927 = select <8 x i1> %convergence.cascade.result823, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4926
  store <8 x float> %4927, ptr %.slot130, align 32
  store <8 x i1> %convergence.cascade.result823, ptr %current.mask, align 1
  %4928 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result823)
  br i1 %4928, label %schedule.51, label %scheduler.loop

varying.divergent825:                             ; preds = %schedule.51
  %4929 = load i32, ptr %current.token, align 4
  %4930 = icmp ne i32 %4929, 0
  %4931 = sub i32 %4929, 1
  %4932 = select i1 %4930, i32 %4931, i32 0
  %4933 = load i8, ptr %frame.active, align 1
  %4934 = trunc i32 %4932 to i8
  %4935 = shl i8 1, %4934
  %4936 = and i8 %4933, %4935
  %4937 = icmp ne i8 %4936, 0
  %4938 = load <8 x i32>, ptr %frame.static.id, align 32
  %4939 = extractelement <8 x i32> %4938, i32 %4932
  %4940 = icmp eq i32 %4939, 18
  %4941 = and i1 %4937, %4940
  %4942 = and i1 %4930, %4941
  %4943 = xor i1 %4942, true
  %4944 = and i1 true, %4943
  %4945 = xor i8 %4933, -1
  %4946 = icmp ne i8 %4945, 0
  %4947 = xor i1 %4946, true
  %4948 = and i1 %4944, %4947
  br i1 %4948, label %convergence.overflow.trap827, label %convergence.overflow.resume828

varying.coherent826:                              ; preds = %schedule.51
  br i1 %976, label %varying.coherent.true831, label %varying.coherent.false832

convergence.overflow.trap827:                     ; preds = %varying.divergent825
  call void @llvm.trap()
  unreachable

convergence.overflow.resume828:                   ; preds = %varying.divergent825
  %4949 = call i8 @llvm.cttz.i8(i8 %4945, i1 false)
  %4950 = zext i8 %4949 to i32
  %4951 = select i1 %4946, i32 %4950, i32 0
  %4952 = trunc i32 %4951 to i8
  %4953 = shl i8 1, %4952
  %4954 = or i8 %4933, %4953
  %4955 = select i1 %4944, i8 %4954, i8 %4933
  store i8 %4955, ptr %frame.active, align 1
  %4956 = load <8 x i32>, ptr %frame.static.id, align 32
  %4957 = extractelement <8 x i32> %4956, i32 %4951
  %4958 = select i1 %4944, i32 18, i32 %4957
  %4959 = load <8 x i32>, ptr %frame.static.id, align 32
  %4960 = insertelement <8 x i32> %4959, i32 %4958, i32 %4951
  store <8 x i32> %4960, ptr %frame.static.id, align 32
  %4961 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4962 = extractelement <8 x i32> %4961, i32 %4951
  %4963 = select i1 %4944, i32 %4929, i32 %4962
  %4964 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4965 = insertelement <8 x i32> %4964, i32 %4963, i32 %4951
  store <8 x i32> %4965, ptr %frame.parent.token, align 32
  %4966 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4951
  %4967 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4951
  %4968 = load <8 x i1>, ptr %4966, align 1
  %4969 = load <8 x i1>, ptr %4967, align 1
  %4970 = select i1 %4944, <8 x i1> %966, <8 x i1> %4968
  store <8 x i1> %4970, ptr %4966, align 1
  %4971 = select i1 %4944, <8 x i1> zeroinitializer, <8 x i1> %4969
  store <8 x i1> %4971, ptr %4967, align 1
  %4972 = add i32 %4951, 1
  %4973 = select i1 %4942, i32 %4929, i32 %4972
  %4974 = select i1 true, i32 %4973, i32 %4929
  store i32 %4974, ptr %current.token, align 4
  %4975 = load i32, ptr %current.token, align 4
  %4976 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %973)
  %4977 = load i32, ptr %ready.count, align 4
  %4978 = icmp uge i32 %4977, 8
  %4979 = and i1 %4976, %4978
  br i1 %4979, label %ready.overflow.trap829, label %ready.overflow.resume830

ready.overflow.trap829:                           ; preds = %convergence.overflow.resume828
  call void @llvm.trap()
  unreachable

ready.overflow.resume830:                         ; preds = %convergence.overflow.resume828
  %4980 = select i1 %4976, i32 %4977, i32 0
  %4981 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4980
  %4982 = load <8 x i1>, ptr %4981, align 1
  %4983 = select i1 %4976, <8 x i1> %973, <8 x i1> %4982
  store <8 x i1> %4983, ptr %4981, align 1
  %4984 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4980
  %4985 = load i32, ptr %4984, align 4
  %4986 = select i1 %4976, i32 52, i32 %4985
  store i32 %4986, ptr %4984, align 4
  %4987 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4980
  %4988 = load i32, ptr %4987, align 4
  %4989 = select i1 %4976, i32 %4975, i32 %4988
  store i32 %4989, ptr %4987, align 4
  %4990 = add i32 %4977, 1
  %4991 = select i1 %4976, i32 %4990, i32 %4977
  store i32 %4991, ptr %ready.count, align 4
  %4992 = load <8 x i1>, ptr %runnable.mask, align 1
  %4993 = or <8 x i1> %4992, %973
  store <8 x i1> %4993, ptr %runnable.mask, align 1
  store <8 x i1> %975, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true831:                         ; preds = %varying.coherent826
  store <8 x i1> %966, ptr %current.mask, align 1
  %4994 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %966)
  br i1 %4994, label %schedule.52, label %scheduler.loop

varying.coherent.false832:                        ; preds = %varying.coherent826
  store <8 x i1> %966, ptr %current.mask, align 1
  %4995 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %966)
  br i1 %4995, label %schedule.53, label %scheduler.loop

convergence.cascade837:                           ; preds = %convergence.cascade837, %schedule.53
  %convergence.cascade.flow841 = phi <8 x i1> [ %1006, %schedule.53 ], [ %5038, %convergence.cascade837 ]
  %convergence.cascade.depth842 = phi i32 [ 0, %schedule.53 ], [ %5039, %convergence.cascade837 ]
  %4996 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow841)
  %4997 = load i32, ptr %current.token, align 4
  %4998 = icmp ne i32 %4997, 0
  %4999 = and i1 %4996, %4998
  %5000 = sub i32 %4997, 1
  %5001 = select i1 %4999, i32 %5000, i32 0
  %5002 = load i8, ptr %frame.active, align 1
  %5003 = trunc i32 %5001 to i8
  %5004 = shl i8 1, %5003
  %5005 = and i8 %5002, %5004
  %5006 = icmp ne i8 %5005, 0
  %5007 = load <8 x i32>, ptr %frame.static.id, align 32
  %5008 = extractelement <8 x i32> %5007, i32 %5001
  %convergence.target.pointer843 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %5008
  %convergence.dynamic.target844 = load i32, ptr %convergence.target.pointer843, align 4
  %5009 = icmp eq i32 %convergence.dynamic.target844, 53
  %5010 = and i1 %5006, %5009
  %5011 = and i1 %4999, %5010
  %5012 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5001
  %5013 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5001
  %5014 = load <8 x i1>, ptr %5012, align 1
  %5015 = load <8 x i1>, ptr %5013, align 1
  %5016 = or <8 x i1> %5015, %convergence.cascade.flow841
  %5017 = load <8 x i1>, ptr %live.mask, align 1
  %5018 = and <8 x i1> %5014, %5017
  %5019 = icmp eq <8 x i1> %5016, %5018
  %5020 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5019)
  %5021 = and i1 %5011, %5020
  %5022 = select i1 %5021, <8 x i1> zeroinitializer, <8 x i1> %5016
  %5023 = select i1 %5011, <8 x i1> %5022, <8 x i1> %5015
  store <8 x i1> %5023, ptr %5013, align 1
  %5024 = select i1 %5021, <8 x i1> zeroinitializer, <8 x i1> %5014
  store <8 x i1> %5024, ptr %5012, align 1
  %5025 = trunc i32 %5001 to i8
  %5026 = shl i8 1, %5025
  %5027 = xor i8 %5026, -1
  %5028 = and i8 %5002, %5027
  %5029 = select i1 %5021, i8 %5028, i8 %5002
  store i8 %5029, ptr %frame.active, align 1
  %.splatinsert845 = insertelement <8 x i1> poison, i1 %5011, i64 0
  %.splat846 = shufflevector <8 x i1> %.splatinsert845, <8 x i1> poison, <8 x i32> zeroinitializer
  %5030 = and <8 x i1> %convergence.cascade.flow841, %.splat846
  %5031 = load <8 x i1>, ptr %runnable.mask, align 1
  %5032 = xor <8 x i1> %5030, splat (i1 true)
  %5033 = and <8 x i1> %5031, %5032
  store <8 x i1> %5033, ptr %runnable.mask, align 1
  %.splatinsert847 = insertelement <8 x i1> poison, i1 %5021, i64 0
  %.splat848 = shufflevector <8 x i1> %.splatinsert847, <8 x i1> poison, <8 x i32> zeroinitializer
  %5034 = select <8 x i1> %.splat848, <8 x i1> %5016, <8 x i1> zeroinitializer
  %5035 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5036 = extractelement <8 x i32> %5035, i32 %5001
  %5037 = select i1 %5021, i32 %5036, i32 %4997
  store i32 %5037, ptr %current.token, align 4
  %.splatinsert849 = insertelement <8 x i1> poison, i1 %5011, i64 0
  %.splat850 = shufflevector <8 x i1> %.splatinsert849, <8 x i1> poison, <8 x i32> zeroinitializer
  %5038 = select <8 x i1> %.splat850, <8 x i1> %5034, <8 x i1> %convergence.cascade.flow841
  %5039 = add i32 %convergence.cascade.depth842, 1
  %5040 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5038)
  %5041 = icmp ult i32 %5039, 8
  %5042 = and i1 %5040, %5041
  %5043 = and i1 %5011, %5042
  %convergence.parent.token851 = load i32, ptr %current.token, align 4
  %convergence.parent.present852 = icmp ne i32 %convergence.parent.token851, 0
  %5044 = and i1 %5043, %convergence.parent.present852
  br i1 %5044, label %convergence.cascade837, label %convergence.cascade.exit838

convergence.cascade.exit838:                      ; preds = %convergence.cascade837, %schedule.53
  %convergence.cascade.result853 = phi <8 x i1> [ %1006, %schedule.53 ], [ %5038, %convergence.cascade837 ]
  %5045 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result853)
  br i1 %5045, label %convergence.target.53.ready, label %scheduler.loop

convergence.target.53.ready:                      ; preds = %convergence.cascade.exit838
  %5046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result853)
  %5047 = bitcast <8 x i1> %convergence.cascade.result853 to i8
  %5048 = call i8 @llvm.cttz.i8(i8 %5047, i1 false)
  %5049 = zext i8 %5048 to i32
  %5050 = select i1 %5046, i32 %5049, i32 0
  %5051 = load <8 x i64>, ptr %.slot131, align 64
  %5052 = select <8 x i1> %convergence.cascade.result853, <8 x i64> zeroinitializer, <8 x i64> %5051
  store <8 x i64> %5052, ptr %.slot131, align 64
  %5053 = load <8 x float>, ptr %.slot132, align 32
  %5054 = select <8 x i1> %convergence.cascade.result853, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %5053
  store <8 x float> %5054, ptr %.slot132, align 32
  store <8 x i1> %convergence.cascade.result853, ptr %current.mask, align 1
  %5055 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result853)
  br i1 %5055, label %schedule.54, label %scheduler.loop

varying.divergent855:                             ; preds = %schedule.54
  %5056 = load i32, ptr %current.token, align 4
  %5057 = icmp ne i32 %5056, 0
  %5058 = sub i32 %5056, 1
  %5059 = select i1 %5057, i32 %5058, i32 0
  %5060 = load i8, ptr %frame.active, align 1
  %5061 = trunc i32 %5059 to i8
  %5062 = shl i8 1, %5061
  %5063 = and i8 %5060, %5062
  %5064 = icmp ne i8 %5063, 0
  %5065 = load <8 x i32>, ptr %frame.static.id, align 32
  %5066 = extractelement <8 x i32> %5065, i32 %5059
  %5067 = icmp eq i32 %5066, 19
  %5068 = and i1 %5064, %5067
  %5069 = and i1 %5057, %5068
  %5070 = xor i1 %5069, true
  %5071 = and i1 true, %5070
  %5072 = xor i8 %5060, -1
  %5073 = icmp ne i8 %5072, 0
  %5074 = xor i1 %5073, true
  %5075 = and i1 %5071, %5074
  br i1 %5075, label %convergence.overflow.trap857, label %convergence.overflow.resume858

varying.coherent856:                              ; preds = %schedule.54
  br i1 %1017, label %varying.coherent.true861, label %varying.coherent.false862

convergence.overflow.trap857:                     ; preds = %varying.divergent855
  call void @llvm.trap()
  unreachable

convergence.overflow.resume858:                   ; preds = %varying.divergent855
  %5076 = call i8 @llvm.cttz.i8(i8 %5072, i1 false)
  %5077 = zext i8 %5076 to i32
  %5078 = select i1 %5073, i32 %5077, i32 0
  %5079 = trunc i32 %5078 to i8
  %5080 = shl i8 1, %5079
  %5081 = or i8 %5060, %5080
  %5082 = select i1 %5071, i8 %5081, i8 %5060
  store i8 %5082, ptr %frame.active, align 1
  %5083 = load <8 x i32>, ptr %frame.static.id, align 32
  %5084 = extractelement <8 x i32> %5083, i32 %5078
  %5085 = select i1 %5071, i32 19, i32 %5084
  %5086 = load <8 x i32>, ptr %frame.static.id, align 32
  %5087 = insertelement <8 x i32> %5086, i32 %5085, i32 %5078
  store <8 x i32> %5087, ptr %frame.static.id, align 32
  %5088 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5089 = extractelement <8 x i32> %5088, i32 %5078
  %5090 = select i1 %5071, i32 %5056, i32 %5089
  %5091 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5092 = insertelement <8 x i32> %5091, i32 %5090, i32 %5078
  store <8 x i32> %5092, ptr %frame.parent.token, align 32
  %5093 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5078
  %5094 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5078
  %5095 = load <8 x i1>, ptr %5093, align 1
  %5096 = load <8 x i1>, ptr %5094, align 1
  %5097 = select i1 %5071, <8 x i1> %1007, <8 x i1> %5095
  store <8 x i1> %5097, ptr %5093, align 1
  %5098 = select i1 %5071, <8 x i1> zeroinitializer, <8 x i1> %5096
  store <8 x i1> %5098, ptr %5094, align 1
  %5099 = add i32 %5078, 1
  %5100 = select i1 %5069, i32 %5056, i32 %5099
  %5101 = select i1 true, i32 %5100, i32 %5056
  store i32 %5101, ptr %current.token, align 4
  %5102 = load i32, ptr %current.token, align 4
  %5103 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1014)
  %5104 = load i32, ptr %ready.count, align 4
  %5105 = icmp uge i32 %5104, 8
  %5106 = and i1 %5103, %5105
  br i1 %5106, label %ready.overflow.trap859, label %ready.overflow.resume860

ready.overflow.trap859:                           ; preds = %convergence.overflow.resume858
  call void @llvm.trap()
  unreachable

ready.overflow.resume860:                         ; preds = %convergence.overflow.resume858
  %5107 = select i1 %5103, i32 %5104, i32 0
  %5108 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5107
  %5109 = load <8 x i1>, ptr %5108, align 1
  %5110 = select i1 %5103, <8 x i1> %1014, <8 x i1> %5109
  store <8 x i1> %5110, ptr %5108, align 1
  %5111 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5107
  %5112 = load i32, ptr %5111, align 4
  %5113 = select i1 %5103, i32 55, i32 %5112
  store i32 %5113, ptr %5111, align 4
  %5114 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5107
  %5115 = load i32, ptr %5114, align 4
  %5116 = select i1 %5103, i32 %5102, i32 %5115
  store i32 %5116, ptr %5114, align 4
  %5117 = add i32 %5104, 1
  %5118 = select i1 %5103, i32 %5117, i32 %5104
  store i32 %5118, ptr %ready.count, align 4
  %5119 = load <8 x i1>, ptr %runnable.mask, align 1
  %5120 = or <8 x i1> %5119, %1014
  store <8 x i1> %5120, ptr %runnable.mask, align 1
  store <8 x i1> %1016, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true861:                         ; preds = %varying.coherent856
  store <8 x i1> %1007, ptr %current.mask, align 1
  %5121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1007)
  br i1 %5121, label %schedule.55, label %scheduler.loop

varying.coherent.false862:                        ; preds = %varying.coherent856
  store <8 x i1> %1007, ptr %current.mask, align 1
  %5122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1007)
  br i1 %5122, label %schedule.56, label %scheduler.loop

convergence.cascade867:                           ; preds = %convergence.cascade867, %schedule.56
  %convergence.cascade.flow871 = phi <8 x i1> [ %1047, %schedule.56 ], [ %5165, %convergence.cascade867 ]
  %convergence.cascade.depth872 = phi i32 [ 0, %schedule.56 ], [ %5166, %convergence.cascade867 ]
  %5123 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow871)
  %5124 = load i32, ptr %current.token, align 4
  %5125 = icmp ne i32 %5124, 0
  %5126 = and i1 %5123, %5125
  %5127 = sub i32 %5124, 1
  %5128 = select i1 %5126, i32 %5127, i32 0
  %5129 = load i8, ptr %frame.active, align 1
  %5130 = trunc i32 %5128 to i8
  %5131 = shl i8 1, %5130
  %5132 = and i8 %5129, %5131
  %5133 = icmp ne i8 %5132, 0
  %5134 = load <8 x i32>, ptr %frame.static.id, align 32
  %5135 = extractelement <8 x i32> %5134, i32 %5128
  %convergence.target.pointer873 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %5135
  %convergence.dynamic.target874 = load i32, ptr %convergence.target.pointer873, align 4
  %5136 = icmp eq i32 %convergence.dynamic.target874, 56
  %5137 = and i1 %5133, %5136
  %5138 = and i1 %5126, %5137
  %5139 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5128
  %5140 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5128
  %5141 = load <8 x i1>, ptr %5139, align 1
  %5142 = load <8 x i1>, ptr %5140, align 1
  %5143 = or <8 x i1> %5142, %convergence.cascade.flow871
  %5144 = load <8 x i1>, ptr %live.mask, align 1
  %5145 = and <8 x i1> %5141, %5144
  %5146 = icmp eq <8 x i1> %5143, %5145
  %5147 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5146)
  %5148 = and i1 %5138, %5147
  %5149 = select i1 %5148, <8 x i1> zeroinitializer, <8 x i1> %5143
  %5150 = select i1 %5138, <8 x i1> %5149, <8 x i1> %5142
  store <8 x i1> %5150, ptr %5140, align 1
  %5151 = select i1 %5148, <8 x i1> zeroinitializer, <8 x i1> %5141
  store <8 x i1> %5151, ptr %5139, align 1
  %5152 = trunc i32 %5128 to i8
  %5153 = shl i8 1, %5152
  %5154 = xor i8 %5153, -1
  %5155 = and i8 %5129, %5154
  %5156 = select i1 %5148, i8 %5155, i8 %5129
  store i8 %5156, ptr %frame.active, align 1
  %.splatinsert875 = insertelement <8 x i1> poison, i1 %5138, i64 0
  %.splat876 = shufflevector <8 x i1> %.splatinsert875, <8 x i1> poison, <8 x i32> zeroinitializer
  %5157 = and <8 x i1> %convergence.cascade.flow871, %.splat876
  %5158 = load <8 x i1>, ptr %runnable.mask, align 1
  %5159 = xor <8 x i1> %5157, splat (i1 true)
  %5160 = and <8 x i1> %5158, %5159
  store <8 x i1> %5160, ptr %runnable.mask, align 1
  %.splatinsert877 = insertelement <8 x i1> poison, i1 %5148, i64 0
  %.splat878 = shufflevector <8 x i1> %.splatinsert877, <8 x i1> poison, <8 x i32> zeroinitializer
  %5161 = select <8 x i1> %.splat878, <8 x i1> %5143, <8 x i1> zeroinitializer
  %5162 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5163 = extractelement <8 x i32> %5162, i32 %5128
  %5164 = select i1 %5148, i32 %5163, i32 %5124
  store i32 %5164, ptr %current.token, align 4
  %.splatinsert879 = insertelement <8 x i1> poison, i1 %5138, i64 0
  %.splat880 = shufflevector <8 x i1> %.splatinsert879, <8 x i1> poison, <8 x i32> zeroinitializer
  %5165 = select <8 x i1> %.splat880, <8 x i1> %5161, <8 x i1> %convergence.cascade.flow871
  %5166 = add i32 %convergence.cascade.depth872, 1
  %5167 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5165)
  %5168 = icmp ult i32 %5166, 8
  %5169 = and i1 %5167, %5168
  %5170 = and i1 %5138, %5169
  %convergence.parent.token881 = load i32, ptr %current.token, align 4
  %convergence.parent.present882 = icmp ne i32 %convergence.parent.token881, 0
  %5171 = and i1 %5170, %convergence.parent.present882
  br i1 %5171, label %convergence.cascade867, label %convergence.cascade.exit868

convergence.cascade.exit868:                      ; preds = %convergence.cascade867, %schedule.56
  %convergence.cascade.result883 = phi <8 x i1> [ %1047, %schedule.56 ], [ %5165, %convergence.cascade867 ]
  %5172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result883)
  br i1 %5172, label %convergence.target.56.ready, label %scheduler.loop

convergence.target.56.ready:                      ; preds = %convergence.cascade.exit868
  %5173 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result883)
  %5174 = bitcast <8 x i1> %convergence.cascade.result883 to i8
  %5175 = call i8 @llvm.cttz.i8(i8 %5174, i1 false)
  %5176 = zext i8 %5175 to i32
  %5177 = select i1 %5173, i32 %5176, i32 0
  %5178 = load <8 x i64>, ptr %.slot133, align 64
  %5179 = select <8 x i1> %convergence.cascade.result883, <8 x i64> zeroinitializer, <8 x i64> %5178
  store <8 x i64> %5179, ptr %.slot133, align 64
  %5180 = load <8 x float>, ptr %.slot134, align 32
  %5181 = select <8 x i1> %convergence.cascade.result883, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %5180
  store <8 x float> %5181, ptr %.slot134, align 32
  store <8 x i1> %convergence.cascade.result883, ptr %current.mask, align 1
  %5182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result883)
  br i1 %5182, label %schedule.57, label %scheduler.loop

varying.divergent885:                             ; preds = %schedule.57
  %5183 = load i32, ptr %current.token, align 4
  %5184 = icmp ne i32 %5183, 0
  %5185 = sub i32 %5183, 1
  %5186 = select i1 %5184, i32 %5185, i32 0
  %5187 = load i8, ptr %frame.active, align 1
  %5188 = trunc i32 %5186 to i8
  %5189 = shl i8 1, %5188
  %5190 = and i8 %5187, %5189
  %5191 = icmp ne i8 %5190, 0
  %5192 = load <8 x i32>, ptr %frame.static.id, align 32
  %5193 = extractelement <8 x i32> %5192, i32 %5186
  %5194 = icmp eq i32 %5193, 20
  %5195 = and i1 %5191, %5194
  %5196 = and i1 %5184, %5195
  %5197 = xor i1 %5196, true
  %5198 = and i1 true, %5197
  %5199 = xor i8 %5187, -1
  %5200 = icmp ne i8 %5199, 0
  %5201 = xor i1 %5200, true
  %5202 = and i1 %5198, %5201
  br i1 %5202, label %convergence.overflow.trap887, label %convergence.overflow.resume888

varying.coherent886:                              ; preds = %schedule.57
  br i1 %1058, label %varying.coherent.true891, label %varying.coherent.false892

convergence.overflow.trap887:                     ; preds = %varying.divergent885
  call void @llvm.trap()
  unreachable

convergence.overflow.resume888:                   ; preds = %varying.divergent885
  %5203 = call i8 @llvm.cttz.i8(i8 %5199, i1 false)
  %5204 = zext i8 %5203 to i32
  %5205 = select i1 %5200, i32 %5204, i32 0
  %5206 = trunc i32 %5205 to i8
  %5207 = shl i8 1, %5206
  %5208 = or i8 %5187, %5207
  %5209 = select i1 %5198, i8 %5208, i8 %5187
  store i8 %5209, ptr %frame.active, align 1
  %5210 = load <8 x i32>, ptr %frame.static.id, align 32
  %5211 = extractelement <8 x i32> %5210, i32 %5205
  %5212 = select i1 %5198, i32 20, i32 %5211
  %5213 = load <8 x i32>, ptr %frame.static.id, align 32
  %5214 = insertelement <8 x i32> %5213, i32 %5212, i32 %5205
  store <8 x i32> %5214, ptr %frame.static.id, align 32
  %5215 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5216 = extractelement <8 x i32> %5215, i32 %5205
  %5217 = select i1 %5198, i32 %5183, i32 %5216
  %5218 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5219 = insertelement <8 x i32> %5218, i32 %5217, i32 %5205
  store <8 x i32> %5219, ptr %frame.parent.token, align 32
  %5220 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5205
  %5221 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5205
  %5222 = load <8 x i1>, ptr %5220, align 1
  %5223 = load <8 x i1>, ptr %5221, align 1
  %5224 = select i1 %5198, <8 x i1> %1048, <8 x i1> %5222
  store <8 x i1> %5224, ptr %5220, align 1
  %5225 = select i1 %5198, <8 x i1> zeroinitializer, <8 x i1> %5223
  store <8 x i1> %5225, ptr %5221, align 1
  %5226 = add i32 %5205, 1
  %5227 = select i1 %5196, i32 %5183, i32 %5226
  %5228 = select i1 true, i32 %5227, i32 %5183
  store i32 %5228, ptr %current.token, align 4
  %5229 = load i32, ptr %current.token, align 4
  %5230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1055)
  %5231 = load i32, ptr %ready.count, align 4
  %5232 = icmp uge i32 %5231, 8
  %5233 = and i1 %5230, %5232
  br i1 %5233, label %ready.overflow.trap889, label %ready.overflow.resume890

ready.overflow.trap889:                           ; preds = %convergence.overflow.resume888
  call void @llvm.trap()
  unreachable

ready.overflow.resume890:                         ; preds = %convergence.overflow.resume888
  %5234 = select i1 %5230, i32 %5231, i32 0
  %5235 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5234
  %5236 = load <8 x i1>, ptr %5235, align 1
  %5237 = select i1 %5230, <8 x i1> %1055, <8 x i1> %5236
  store <8 x i1> %5237, ptr %5235, align 1
  %5238 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5234
  %5239 = load i32, ptr %5238, align 4
  %5240 = select i1 %5230, i32 58, i32 %5239
  store i32 %5240, ptr %5238, align 4
  %5241 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5234
  %5242 = load i32, ptr %5241, align 4
  %5243 = select i1 %5230, i32 %5229, i32 %5242
  store i32 %5243, ptr %5241, align 4
  %5244 = add i32 %5231, 1
  %5245 = select i1 %5230, i32 %5244, i32 %5231
  store i32 %5245, ptr %ready.count, align 4
  %5246 = load <8 x i1>, ptr %runnable.mask, align 1
  %5247 = or <8 x i1> %5246, %1055
  store <8 x i1> %5247, ptr %runnable.mask, align 1
  store <8 x i1> %1057, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true891:                         ; preds = %varying.coherent886
  store <8 x i1> %1048, ptr %current.mask, align 1
  %5248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1048)
  br i1 %5248, label %schedule.58, label %scheduler.loop

varying.coherent.false892:                        ; preds = %varying.coherent886
  store <8 x i1> %1048, ptr %current.mask, align 1
  %5249 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1048)
  br i1 %5249, label %schedule.59, label %scheduler.loop

convergence.cascade897:                           ; preds = %convergence.cascade897, %schedule.59
  %convergence.cascade.flow901 = phi <8 x i1> [ %1088, %schedule.59 ], [ %5292, %convergence.cascade897 ]
  %convergence.cascade.depth902 = phi i32 [ 0, %schedule.59 ], [ %5293, %convergence.cascade897 ]
  %5250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow901)
  %5251 = load i32, ptr %current.token, align 4
  %5252 = icmp ne i32 %5251, 0
  %5253 = and i1 %5250, %5252
  %5254 = sub i32 %5251, 1
  %5255 = select i1 %5253, i32 %5254, i32 0
  %5256 = load i8, ptr %frame.active, align 1
  %5257 = trunc i32 %5255 to i8
  %5258 = shl i8 1, %5257
  %5259 = and i8 %5256, %5258
  %5260 = icmp ne i8 %5259, 0
  %5261 = load <8 x i32>, ptr %frame.static.id, align 32
  %5262 = extractelement <8 x i32> %5261, i32 %5255
  %convergence.target.pointer903 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %5262
  %convergence.dynamic.target904 = load i32, ptr %convergence.target.pointer903, align 4
  %5263 = icmp eq i32 %convergence.dynamic.target904, 59
  %5264 = and i1 %5260, %5263
  %5265 = and i1 %5253, %5264
  %5266 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5255
  %5267 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5255
  %5268 = load <8 x i1>, ptr %5266, align 1
  %5269 = load <8 x i1>, ptr %5267, align 1
  %5270 = or <8 x i1> %5269, %convergence.cascade.flow901
  %5271 = load <8 x i1>, ptr %live.mask, align 1
  %5272 = and <8 x i1> %5268, %5271
  %5273 = icmp eq <8 x i1> %5270, %5272
  %5274 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5273)
  %5275 = and i1 %5265, %5274
  %5276 = select i1 %5275, <8 x i1> zeroinitializer, <8 x i1> %5270
  %5277 = select i1 %5265, <8 x i1> %5276, <8 x i1> %5269
  store <8 x i1> %5277, ptr %5267, align 1
  %5278 = select i1 %5275, <8 x i1> zeroinitializer, <8 x i1> %5268
  store <8 x i1> %5278, ptr %5266, align 1
  %5279 = trunc i32 %5255 to i8
  %5280 = shl i8 1, %5279
  %5281 = xor i8 %5280, -1
  %5282 = and i8 %5256, %5281
  %5283 = select i1 %5275, i8 %5282, i8 %5256
  store i8 %5283, ptr %frame.active, align 1
  %.splatinsert905 = insertelement <8 x i1> poison, i1 %5265, i64 0
  %.splat906 = shufflevector <8 x i1> %.splatinsert905, <8 x i1> poison, <8 x i32> zeroinitializer
  %5284 = and <8 x i1> %convergence.cascade.flow901, %.splat906
  %5285 = load <8 x i1>, ptr %runnable.mask, align 1
  %5286 = xor <8 x i1> %5284, splat (i1 true)
  %5287 = and <8 x i1> %5285, %5286
  store <8 x i1> %5287, ptr %runnable.mask, align 1
  %.splatinsert907 = insertelement <8 x i1> poison, i1 %5275, i64 0
  %.splat908 = shufflevector <8 x i1> %.splatinsert907, <8 x i1> poison, <8 x i32> zeroinitializer
  %5288 = select <8 x i1> %.splat908, <8 x i1> %5270, <8 x i1> zeroinitializer
  %5289 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5290 = extractelement <8 x i32> %5289, i32 %5255
  %5291 = select i1 %5275, i32 %5290, i32 %5251
  store i32 %5291, ptr %current.token, align 4
  %.splatinsert909 = insertelement <8 x i1> poison, i1 %5265, i64 0
  %.splat910 = shufflevector <8 x i1> %.splatinsert909, <8 x i1> poison, <8 x i32> zeroinitializer
  %5292 = select <8 x i1> %.splat910, <8 x i1> %5288, <8 x i1> %convergence.cascade.flow901
  %5293 = add i32 %convergence.cascade.depth902, 1
  %5294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5292)
  %5295 = icmp ult i32 %5293, 8
  %5296 = and i1 %5294, %5295
  %5297 = and i1 %5265, %5296
  %convergence.parent.token911 = load i32, ptr %current.token, align 4
  %convergence.parent.present912 = icmp ne i32 %convergence.parent.token911, 0
  %5298 = and i1 %5297, %convergence.parent.present912
  br i1 %5298, label %convergence.cascade897, label %convergence.cascade.exit898

convergence.cascade.exit898:                      ; preds = %convergence.cascade897, %schedule.59
  %convergence.cascade.result913 = phi <8 x i1> [ %1088, %schedule.59 ], [ %5292, %convergence.cascade897 ]
  %5299 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  br i1 %5299, label %convergence.target.59.ready, label %scheduler.loop

convergence.target.59.ready:                      ; preds = %convergence.cascade.exit898
  %5300 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5301 = bitcast <8 x i1> %convergence.cascade.result913 to i8
  %5302 = call i8 @llvm.cttz.i8(i8 %5301, i1 false)
  %5303 = zext i8 %5302 to i32
  %5304 = select i1 %5300, i32 %5303, i32 0
  %.state914 = load <8 x float>, ptr %.slot69, align 32
  %.state915 = load <8 x float>, ptr %.slot120, align 32
  %5305 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state914, <8 x float> %.state915)
  %5306 = load <8 x float>, ptr %.spill135, align 32
  %5307 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5305, <8 x float> %5306
  store <8 x float> %5307, ptr %.spill135, align 32
  %.state916 = load <8 x float>, ptr %.slot70, align 32
  %.state917 = load <8 x float>, ptr %.slot122, align 32
  %5308 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state916, <8 x float> %.state917)
  %5309 = load <8 x float>, ptr %.spill136, align 32
  %5310 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5308, <8 x float> %5309
  store <8 x float> %5310, ptr %.spill136, align 32
  %.state918 = load <8 x float>, ptr %.slot71, align 32
  %.state919 = load <8 x float>, ptr %.slot124, align 32
  %5311 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state918, <8 x float> %.state919)
  %5312 = load <8 x float>, ptr %.spill137, align 32
  %5313 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5311, <8 x float> %5312
  store <8 x float> %5313, ptr %.spill137, align 32
  %.state920 = load <8 x float>, ptr %.slot72, align 32
  %.state921 = load <8 x float>, ptr %.slot126, align 32
  %5314 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state920, <8 x float> %.state921)
  %5315 = load <8 x float>, ptr %.spill138, align 32
  %5316 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5314, <8 x float> %5315
  store <8 x float> %5316, ptr %.spill138, align 32
  %.state922 = load <8 x float>, ptr %.slot73, align 32
  %.state923 = load <8 x float>, ptr %.slot128, align 32
  %5317 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state922, <8 x float> %.state923)
  %5318 = load <8 x float>, ptr %.spill139, align 32
  %5319 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5317, <8 x float> %5318
  store <8 x float> %5319, ptr %.spill139, align 32
  %.state924 = load <8 x float>, ptr %.slot74, align 32
  %.state925 = load <8 x float>, ptr %.slot130, align 32
  %5320 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state924, <8 x float> %.state925)
  %5321 = load <8 x float>, ptr %.spill140, align 32
  %5322 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5320, <8 x float> %5321
  store <8 x float> %5322, ptr %.spill140, align 32
  %.state926 = load <8 x float>, ptr %.slot75, align 32
  %.state927 = load <8 x float>, ptr %.slot132, align 32
  %5323 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state926, <8 x float> %.state927)
  %5324 = load <8 x float>, ptr %.spill141, align 32
  %5325 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5323, <8 x float> %5324
  store <8 x float> %5325, ptr %.spill141, align 32
  %.state928 = load <8 x float>, ptr %.slot76, align 32
  %.state929 = load <8 x float>, ptr %.slot134, align 32
  %5326 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state928, <8 x float> %.state929)
  %5327 = load <8 x float>, ptr %.spill142, align 32
  %5328 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5326, <8 x float> %5327
  store <8 x float> %5328, ptr %.spill142, align 32
  %5329 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill143, align 64
  %5330 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5331 = extractvalue { <8 x ptr>, <8 x i64> } %5329, 0
  %5332 = select <8 x i1> %convergence.cascade.result913, <8 x ptr> %5330, <8 x ptr> %5331
  %5333 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5334 = extractvalue { <8 x ptr>, <8 x i64> } %5329, 1
  %5335 = select <8 x i1> %convergence.cascade.result913, <8 x i64> %5333, <8 x i64> %5334
  %5336 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5332, 0
  %5337 = insertvalue { <8 x ptr>, <8 x i64> } %5336, <8 x i64> %5335, 1
  store { <8 x ptr>, <8 x i64> } %5337, ptr %tile_snapshot.spill143, align 64
  %5338 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5339 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5340 = add <8 x i64> %5339, zeroinitializer
  %5341 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5338, 0
  %5342 = insertvalue { <8 x ptr>, <8 x i64> } %5341, <8 x i64> %5340, 1
  %5343 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5344 = extractvalue { <8 x ptr>, <8 x i64> } %5342, 1
  %5345 = extractelement <8 x ptr> %5343, i32 0
  %5346 = extractelement <8 x i64> %5344, i32 %5304
  %5347 = zext i32 %5304 to i64
  %5348 = mul i64 %5347, 4
  %5349 = sub i64 %5346, %5348
  %5350 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5351 = select i1 %5350, i64 %5349, i64 0
  %private.contiguous.address930 = getelementptr i8, ptr %5345, i64 %5351
  %private.contiguous.preserve931 = load <8 x float>, ptr %private.contiguous.address930, align 4
  %5352 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5305, <8 x float> %private.contiguous.preserve931
  store <8 x float> %5352, ptr %private.contiguous.address930, align 4
  %5353 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5354 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5355 = add <8 x i64> %5354, splat (i64 32)
  %5356 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5353, 0
  %5357 = insertvalue { <8 x ptr>, <8 x i64> } %5356, <8 x i64> %5355, 1
  %5358 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5359 = extractvalue { <8 x ptr>, <8 x i64> } %5357, 1
  %5360 = extractelement <8 x ptr> %5358, i32 0
  %5361 = extractelement <8 x i64> %5359, i32 %5304
  %5362 = zext i32 %5304 to i64
  %5363 = mul i64 %5362, 4
  %5364 = sub i64 %5361, %5363
  %5365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5366 = select i1 %5365, i64 %5364, i64 0
  %private.contiguous.address932 = getelementptr i8, ptr %5360, i64 %5366
  %private.contiguous.preserve933 = load <8 x float>, ptr %private.contiguous.address932, align 4
  %5367 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5308, <8 x float> %private.contiguous.preserve933
  store <8 x float> %5367, ptr %private.contiguous.address932, align 4
  %5368 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5369 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5370 = add <8 x i64> %5369, splat (i64 64)
  %5371 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5368, 0
  %5372 = insertvalue { <8 x ptr>, <8 x i64> } %5371, <8 x i64> %5370, 1
  %5373 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5374 = extractvalue { <8 x ptr>, <8 x i64> } %5372, 1
  %5375 = extractelement <8 x ptr> %5373, i32 0
  %5376 = extractelement <8 x i64> %5374, i32 %5304
  %5377 = zext i32 %5304 to i64
  %5378 = mul i64 %5377, 4
  %5379 = sub i64 %5376, %5378
  %5380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5381 = select i1 %5380, i64 %5379, i64 0
  %private.contiguous.address934 = getelementptr i8, ptr %5375, i64 %5381
  %private.contiguous.preserve935 = load <8 x float>, ptr %private.contiguous.address934, align 4
  %5382 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5311, <8 x float> %private.contiguous.preserve935
  store <8 x float> %5382, ptr %private.contiguous.address934, align 4
  %5383 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5384 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5385 = add <8 x i64> %5384, splat (i64 96)
  %5386 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5383, 0
  %5387 = insertvalue { <8 x ptr>, <8 x i64> } %5386, <8 x i64> %5385, 1
  %5388 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5389 = extractvalue { <8 x ptr>, <8 x i64> } %5387, 1
  %5390 = extractelement <8 x ptr> %5388, i32 0
  %5391 = extractelement <8 x i64> %5389, i32 %5304
  %5392 = zext i32 %5304 to i64
  %5393 = mul i64 %5392, 4
  %5394 = sub i64 %5391, %5393
  %5395 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5396 = select i1 %5395, i64 %5394, i64 0
  %private.contiguous.address936 = getelementptr i8, ptr %5390, i64 %5396
  %private.contiguous.preserve937 = load <8 x float>, ptr %private.contiguous.address936, align 4
  %5397 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5314, <8 x float> %private.contiguous.preserve937
  store <8 x float> %5397, ptr %private.contiguous.address936, align 4
  %5398 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5399 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5400 = add <8 x i64> %5399, splat (i64 128)
  %5401 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5398, 0
  %5402 = insertvalue { <8 x ptr>, <8 x i64> } %5401, <8 x i64> %5400, 1
  %5403 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5404 = extractvalue { <8 x ptr>, <8 x i64> } %5402, 1
  %5405 = extractelement <8 x ptr> %5403, i32 0
  %5406 = extractelement <8 x i64> %5404, i32 %5304
  %5407 = zext i32 %5304 to i64
  %5408 = mul i64 %5407, 4
  %5409 = sub i64 %5406, %5408
  %5410 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5411 = select i1 %5410, i64 %5409, i64 0
  %private.contiguous.address938 = getelementptr i8, ptr %5405, i64 %5411
  %private.contiguous.preserve939 = load <8 x float>, ptr %private.contiguous.address938, align 4
  %5412 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5317, <8 x float> %private.contiguous.preserve939
  store <8 x float> %5412, ptr %private.contiguous.address938, align 4
  %5413 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5414 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5415 = add <8 x i64> %5414, splat (i64 160)
  %5416 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5413, 0
  %5417 = insertvalue { <8 x ptr>, <8 x i64> } %5416, <8 x i64> %5415, 1
  %5418 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5419 = extractvalue { <8 x ptr>, <8 x i64> } %5417, 1
  %5420 = extractelement <8 x ptr> %5418, i32 0
  %5421 = extractelement <8 x i64> %5419, i32 %5304
  %5422 = zext i32 %5304 to i64
  %5423 = mul i64 %5422, 4
  %5424 = sub i64 %5421, %5423
  %5425 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5426 = select i1 %5425, i64 %5424, i64 0
  %private.contiguous.address940 = getelementptr i8, ptr %5420, i64 %5426
  %private.contiguous.preserve941 = load <8 x float>, ptr %private.contiguous.address940, align 4
  %5427 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5320, <8 x float> %private.contiguous.preserve941
  store <8 x float> %5427, ptr %private.contiguous.address940, align 4
  %5428 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5429 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5430 = add <8 x i64> %5429, splat (i64 192)
  %5431 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5428, 0
  %5432 = insertvalue { <8 x ptr>, <8 x i64> } %5431, <8 x i64> %5430, 1
  %5433 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5434 = extractvalue { <8 x ptr>, <8 x i64> } %5432, 1
  %5435 = extractelement <8 x ptr> %5433, i32 0
  %5436 = extractelement <8 x i64> %5434, i32 %5304
  %5437 = zext i32 %5304 to i64
  %5438 = mul i64 %5437, 4
  %5439 = sub i64 %5436, %5438
  %5440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5441 = select i1 %5440, i64 %5439, i64 0
  %private.contiguous.address942 = getelementptr i8, ptr %5435, i64 %5441
  %private.contiguous.preserve943 = load <8 x float>, ptr %private.contiguous.address942, align 4
  %5442 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5323, <8 x float> %private.contiguous.preserve943
  store <8 x float> %5442, ptr %private.contiguous.address942, align 4
  %5443 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5444 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %5445 = add <8 x i64> %5444, splat (i64 224)
  %5446 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5443, 0
  %5447 = insertvalue { <8 x ptr>, <8 x i64> } %5446, <8 x i64> %5445, 1
  %5448 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %5449 = extractvalue { <8 x ptr>, <8 x i64> } %5447, 1
  %5450 = extractelement <8 x ptr> %5448, i32 0
  %5451 = extractelement <8 x i64> %5449, i32 %5304
  %5452 = zext i32 %5304 to i64
  %5453 = mul i64 %5452, 4
  %5454 = sub i64 %5451, %5453
  %5455 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5456 = select i1 %5455, i64 %5454, i64 0
  %private.contiguous.address944 = getelementptr i8, ptr %5450, i64 %5456
  %private.contiguous.preserve945 = load <8 x float>, ptr %private.contiguous.address944, align 4
  %5457 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5326, <8 x float> %private.contiguous.preserve945
  store <8 x float> %5457, ptr %private.contiguous.address944, align 4
  %.state946 = load <8 x float>, ptr %.slot69, align 32
  %5458 = fsub <8 x float> %.state946, %5305
  %.state947 = load <8 x float>, ptr %.slot70, align 32
  %5459 = fsub <8 x float> %.state947, %5308
  %.state948 = load <8 x float>, ptr %.slot71, align 32
  %5460 = fsub <8 x float> %.state948, %5311
  %.state949 = load <8 x float>, ptr %.slot72, align 32
  %5461 = fsub <8 x float> %.state949, %5314
  %.state950 = load <8 x float>, ptr %.slot73, align 32
  %5462 = fsub <8 x float> %.state950, %5317
  %.state951 = load <8 x float>, ptr %.slot74, align 32
  %5463 = fsub <8 x float> %.state951, %5320
  %.state952 = load <8 x float>, ptr %.slot75, align 32
  %5464 = fsub <8 x float> %.state952, %5323
  %.state953 = load <8 x float>, ptr %.slot76, align 32
  %5465 = fsub <8 x float> %.state953, %5326
  %5466 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5458, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5466)
  %5467 = load <8 x float>, ptr %.spill144, align 32
  %5468 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp, <8 x float> %5467
  store <8 x float> %5468, ptr %.spill144, align 32
  %5469 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5459, <8 x float> zeroinitializer
  %native.exp954 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5469)
  %5470 = load <8 x float>, ptr %.spill145, align 32
  %5471 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp954, <8 x float> %5470
  store <8 x float> %5471, ptr %.spill145, align 32
  %5472 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5460, <8 x float> zeroinitializer
  %native.exp955 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5472)
  %5473 = load <8 x float>, ptr %.spill146, align 32
  %5474 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp955, <8 x float> %5473
  store <8 x float> %5474, ptr %.spill146, align 32
  %5475 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5461, <8 x float> zeroinitializer
  %native.exp956 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5475)
  %5476 = load <8 x float>, ptr %.spill147, align 32
  %5477 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp956, <8 x float> %5476
  store <8 x float> %5477, ptr %.spill147, align 32
  %5478 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5462, <8 x float> zeroinitializer
  %native.exp957 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5478)
  %5479 = load <8 x float>, ptr %.spill148, align 32
  %5480 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp957, <8 x float> %5479
  store <8 x float> %5480, ptr %.spill148, align 32
  %5481 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5463, <8 x float> zeroinitializer
  %native.exp958 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5481)
  %5482 = load <8 x float>, ptr %.spill149, align 32
  %5483 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp958, <8 x float> %5482
  store <8 x float> %5483, ptr %.spill149, align 32
  %5484 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5464, <8 x float> zeroinitializer
  %native.exp959 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5484)
  %5485 = load <8 x float>, ptr %.spill150, align 32
  %5486 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp959, <8 x float> %5485
  store <8 x float> %5486, ptr %.spill150, align 32
  %5487 = select <8 x i1> %convergence.cascade.result913, <8 x float> %5465, <8 x float> zeroinitializer
  %native.exp960 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5487)
  %5488 = load <8 x float>, ptr %.spill151, align 32
  %5489 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp960, <8 x float> %5488
  store <8 x float> %5489, ptr %.spill151, align 32
  %5490 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill152, align 64
  %5491 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5492 = extractvalue { <8 x ptr>, <8 x i64> } %5490, 0
  %5493 = select <8 x i1> %convergence.cascade.result913, <8 x ptr> %5491, <8 x ptr> %5492
  %5494 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5495 = extractvalue { <8 x ptr>, <8 x i64> } %5490, 1
  %5496 = select <8 x i1> %convergence.cascade.result913, <8 x i64> %5494, <8 x i64> %5495
  %5497 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5493, 0
  %5498 = insertvalue { <8 x ptr>, <8 x i64> } %5497, <8 x i64> %5496, 1
  store { <8 x ptr>, <8 x i64> } %5498, ptr %tile_snapshot.spill152, align 64
  %5499 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5500 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5501 = add <8 x i64> %5500, zeroinitializer
  %5502 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5499, 0
  %5503 = insertvalue { <8 x ptr>, <8 x i64> } %5502, <8 x i64> %5501, 1
  %5504 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5505 = extractvalue { <8 x ptr>, <8 x i64> } %5503, 1
  %5506 = extractelement <8 x ptr> %5504, i32 0
  %5507 = extractelement <8 x i64> %5505, i32 %5304
  %5508 = zext i32 %5304 to i64
  %5509 = mul i64 %5508, 4
  %5510 = sub i64 %5507, %5509
  %5511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5512 = select i1 %5511, i64 %5510, i64 0
  %private.contiguous.address961 = getelementptr i8, ptr %5506, i64 %5512
  %private.contiguous.preserve962 = load <8 x float>, ptr %private.contiguous.address961, align 4
  %5513 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve962
  store <8 x float> %5513, ptr %private.contiguous.address961, align 4
  %5514 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5515 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5516 = add <8 x i64> %5515, splat (i64 32)
  %5517 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5514, 0
  %5518 = insertvalue { <8 x ptr>, <8 x i64> } %5517, <8 x i64> %5516, 1
  %5519 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5520 = extractvalue { <8 x ptr>, <8 x i64> } %5518, 1
  %5521 = extractelement <8 x ptr> %5519, i32 0
  %5522 = extractelement <8 x i64> %5520, i32 %5304
  %5523 = zext i32 %5304 to i64
  %5524 = mul i64 %5523, 4
  %5525 = sub i64 %5522, %5524
  %5526 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5527 = select i1 %5526, i64 %5525, i64 0
  %private.contiguous.address963 = getelementptr i8, ptr %5521, i64 %5527
  %private.contiguous.preserve964 = load <8 x float>, ptr %private.contiguous.address963, align 4
  %5528 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp954, <8 x float> %private.contiguous.preserve964
  store <8 x float> %5528, ptr %private.contiguous.address963, align 4
  %5529 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5530 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5531 = add <8 x i64> %5530, splat (i64 64)
  %5532 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5529, 0
  %5533 = insertvalue { <8 x ptr>, <8 x i64> } %5532, <8 x i64> %5531, 1
  %5534 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5535 = extractvalue { <8 x ptr>, <8 x i64> } %5533, 1
  %5536 = extractelement <8 x ptr> %5534, i32 0
  %5537 = extractelement <8 x i64> %5535, i32 %5304
  %5538 = zext i32 %5304 to i64
  %5539 = mul i64 %5538, 4
  %5540 = sub i64 %5537, %5539
  %5541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5542 = select i1 %5541, i64 %5540, i64 0
  %private.contiguous.address965 = getelementptr i8, ptr %5536, i64 %5542
  %private.contiguous.preserve966 = load <8 x float>, ptr %private.contiguous.address965, align 4
  %5543 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp955, <8 x float> %private.contiguous.preserve966
  store <8 x float> %5543, ptr %private.contiguous.address965, align 4
  %5544 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5545 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5546 = add <8 x i64> %5545, splat (i64 96)
  %5547 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5544, 0
  %5548 = insertvalue { <8 x ptr>, <8 x i64> } %5547, <8 x i64> %5546, 1
  %5549 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5550 = extractvalue { <8 x ptr>, <8 x i64> } %5548, 1
  %5551 = extractelement <8 x ptr> %5549, i32 0
  %5552 = extractelement <8 x i64> %5550, i32 %5304
  %5553 = zext i32 %5304 to i64
  %5554 = mul i64 %5553, 4
  %5555 = sub i64 %5552, %5554
  %5556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5557 = select i1 %5556, i64 %5555, i64 0
  %private.contiguous.address967 = getelementptr i8, ptr %5551, i64 %5557
  %private.contiguous.preserve968 = load <8 x float>, ptr %private.contiguous.address967, align 4
  %5558 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp956, <8 x float> %private.contiguous.preserve968
  store <8 x float> %5558, ptr %private.contiguous.address967, align 4
  %5559 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5560 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5561 = add <8 x i64> %5560, splat (i64 128)
  %5562 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5559, 0
  %5563 = insertvalue { <8 x ptr>, <8 x i64> } %5562, <8 x i64> %5561, 1
  %5564 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5565 = extractvalue { <8 x ptr>, <8 x i64> } %5563, 1
  %5566 = extractelement <8 x ptr> %5564, i32 0
  %5567 = extractelement <8 x i64> %5565, i32 %5304
  %5568 = zext i32 %5304 to i64
  %5569 = mul i64 %5568, 4
  %5570 = sub i64 %5567, %5569
  %5571 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5572 = select i1 %5571, i64 %5570, i64 0
  %private.contiguous.address969 = getelementptr i8, ptr %5566, i64 %5572
  %private.contiguous.preserve970 = load <8 x float>, ptr %private.contiguous.address969, align 4
  %5573 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp957, <8 x float> %private.contiguous.preserve970
  store <8 x float> %5573, ptr %private.contiguous.address969, align 4
  %5574 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5575 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5576 = add <8 x i64> %5575, splat (i64 160)
  %5577 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5574, 0
  %5578 = insertvalue { <8 x ptr>, <8 x i64> } %5577, <8 x i64> %5576, 1
  %5579 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5580 = extractvalue { <8 x ptr>, <8 x i64> } %5578, 1
  %5581 = extractelement <8 x ptr> %5579, i32 0
  %5582 = extractelement <8 x i64> %5580, i32 %5304
  %5583 = zext i32 %5304 to i64
  %5584 = mul i64 %5583, 4
  %5585 = sub i64 %5582, %5584
  %5586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5587 = select i1 %5586, i64 %5585, i64 0
  %private.contiguous.address971 = getelementptr i8, ptr %5581, i64 %5587
  %private.contiguous.preserve972 = load <8 x float>, ptr %private.contiguous.address971, align 4
  %5588 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp958, <8 x float> %private.contiguous.preserve972
  store <8 x float> %5588, ptr %private.contiguous.address971, align 4
  %5589 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5590 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5591 = add <8 x i64> %5590, splat (i64 192)
  %5592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5589, 0
  %5593 = insertvalue { <8 x ptr>, <8 x i64> } %5592, <8 x i64> %5591, 1
  %5594 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5595 = extractvalue { <8 x ptr>, <8 x i64> } %5593, 1
  %5596 = extractelement <8 x ptr> %5594, i32 0
  %5597 = extractelement <8 x i64> %5595, i32 %5304
  %5598 = zext i32 %5304 to i64
  %5599 = mul i64 %5598, 4
  %5600 = sub i64 %5597, %5599
  %5601 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5602 = select i1 %5601, i64 %5600, i64 0
  %private.contiguous.address973 = getelementptr i8, ptr %5596, i64 %5602
  %private.contiguous.preserve974 = load <8 x float>, ptr %private.contiguous.address973, align 4
  %5603 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp959, <8 x float> %private.contiguous.preserve974
  store <8 x float> %5603, ptr %private.contiguous.address973, align 4
  %5604 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5605 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %5606 = add <8 x i64> %5605, splat (i64 224)
  %5607 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5604, 0
  %5608 = insertvalue { <8 x ptr>, <8 x i64> } %5607, <8 x i64> %5606, 1
  %5609 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %5610 = extractvalue { <8 x ptr>, <8 x i64> } %5608, 1
  %5611 = extractelement <8 x ptr> %5609, i32 0
  %5612 = extractelement <8 x i64> %5610, i32 %5304
  %5613 = zext i32 %5304 to i64
  %5614 = mul i64 %5613, 4
  %5615 = sub i64 %5612, %5614
  %5616 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %5617 = select i1 %5616, i64 %5615, i64 0
  %private.contiguous.address975 = getelementptr i8, ptr %5611, i64 %5617
  %private.contiguous.preserve976 = load <8 x float>, ptr %private.contiguous.address975, align 4
  %5618 = select <8 x i1> %convergence.cascade.result913, <8 x float> %native.exp960, <8 x float> %private.contiguous.preserve976
  store <8 x float> %5618, ptr %private.contiguous.address975, align 4
  %5619 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %5620 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %5621 = extractvalue { <8 x ptr>, <8 x i64> } %5619, 0
  %5622 = select <8 x i1> %convergence.cascade.result913, <8 x ptr> %5620, <8 x ptr> %5621
  %5623 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %5624 = extractvalue { <8 x ptr>, <8 x i64> } %5619, 1
  %5625 = select <8 x i1> %convergence.cascade.result913, <8 x i64> %5623, <8 x i64> %5624
  %5626 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5622, 0
  %5627 = insertvalue { <8 x ptr>, <8 x i64> } %5626, <8 x i64> %5625, 1
  store { <8 x ptr>, <8 x i64> } %5627, ptr %tile_snapshot.spill153, align 64
  %5628 = load <8 x i64>, ptr %.slot154, align 64
  %5629 = select <8 x i1> %convergence.cascade.result913, <8 x i64> zeroinitializer, <8 x i64> %5628
  store <8 x i64> %5629, ptr %.slot154, align 64
  store <8 x i1> %convergence.cascade.result913, ptr %current.mask, align 1
  %5630 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  br i1 %5630, label %schedule.60, label %scheduler.loop

varying.divergent978:                             ; preds = %schedule.60
  %5631 = load i32, ptr %current.token, align 4
  %5632 = icmp ne i32 %5631, 0
  %5633 = sub i32 %5631, 1
  %5634 = select i1 %5632, i32 %5633, i32 0
  %5635 = load i8, ptr %frame.active, align 1
  %5636 = trunc i32 %5634 to i8
  %5637 = shl i8 1, %5636
  %5638 = and i8 %5635, %5637
  %5639 = icmp ne i8 %5638, 0
  %5640 = load <8 x i32>, ptr %frame.static.id, align 32
  %5641 = extractelement <8 x i32> %5640, i32 %5634
  %5642 = icmp eq i32 %5641, 21
  %5643 = and i1 %5639, %5642
  %5644 = and i1 %5632, %5643
  %5645 = xor i1 %5644, true
  %5646 = and i1 true, %5645
  %5647 = xor i8 %5635, -1
  %5648 = icmp ne i8 %5647, 0
  %5649 = xor i1 %5648, true
  %5650 = and i1 %5646, %5649
  br i1 %5650, label %convergence.overflow.trap980, label %convergence.overflow.resume981

varying.coherent979:                              ; preds = %schedule.60
  br i1 %1099, label %varying.coherent.true984, label %varying.coherent.false985

convergence.overflow.trap980:                     ; preds = %varying.divergent978
  call void @llvm.trap()
  unreachable

convergence.overflow.resume981:                   ; preds = %varying.divergent978
  %5651 = call i8 @llvm.cttz.i8(i8 %5647, i1 false)
  %5652 = zext i8 %5651 to i32
  %5653 = select i1 %5648, i32 %5652, i32 0
  %5654 = trunc i32 %5653 to i8
  %5655 = shl i8 1, %5654
  %5656 = or i8 %5635, %5655
  %5657 = select i1 %5646, i8 %5656, i8 %5635
  store i8 %5657, ptr %frame.active, align 1
  %5658 = load <8 x i32>, ptr %frame.static.id, align 32
  %5659 = extractelement <8 x i32> %5658, i32 %5653
  %5660 = select i1 %5646, i32 21, i32 %5659
  %5661 = load <8 x i32>, ptr %frame.static.id, align 32
  %5662 = insertelement <8 x i32> %5661, i32 %5660, i32 %5653
  store <8 x i32> %5662, ptr %frame.static.id, align 32
  %5663 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5664 = extractelement <8 x i32> %5663, i32 %5653
  %5665 = select i1 %5646, i32 %5631, i32 %5664
  %5666 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5667 = insertelement <8 x i32> %5666, i32 %5665, i32 %5653
  store <8 x i32> %5667, ptr %frame.parent.token, align 32
  %5668 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5653
  %5669 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5653
  %5670 = load <8 x i1>, ptr %5668, align 1
  %5671 = load <8 x i1>, ptr %5669, align 1
  %5672 = select i1 %5646, <8 x i1> %1089, <8 x i1> %5670
  store <8 x i1> %5672, ptr %5668, align 1
  %5673 = select i1 %5646, <8 x i1> zeroinitializer, <8 x i1> %5671
  store <8 x i1> %5673, ptr %5669, align 1
  %5674 = add i32 %5653, 1
  %5675 = select i1 %5644, i32 %5631, i32 %5674
  %5676 = select i1 true, i32 %5675, i32 %5631
  store i32 %5676, ptr %current.token, align 4
  %5677 = load i32, ptr %current.token, align 4
  %5678 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1096)
  %5679 = load i32, ptr %ready.count, align 4
  %5680 = icmp uge i32 %5679, 8
  %5681 = and i1 %5678, %5680
  br i1 %5681, label %ready.overflow.trap982, label %ready.overflow.resume983

ready.overflow.trap982:                           ; preds = %convergence.overflow.resume981
  call void @llvm.trap()
  unreachable

ready.overflow.resume983:                         ; preds = %convergence.overflow.resume981
  %5682 = select i1 %5678, i32 %5679, i32 0
  %5683 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5682
  %5684 = load <8 x i1>, ptr %5683, align 1
  %5685 = select i1 %5678, <8 x i1> %1096, <8 x i1> %5684
  store <8 x i1> %5685, ptr %5683, align 1
  %5686 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5682
  %5687 = load i32, ptr %5686, align 4
  %5688 = select i1 %5678, i32 61, i32 %5687
  store i32 %5688, ptr %5686, align 4
  %5689 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5682
  %5690 = load i32, ptr %5689, align 4
  %5691 = select i1 %5678, i32 %5677, i32 %5690
  store i32 %5691, ptr %5689, align 4
  %5692 = add i32 %5679, 1
  %5693 = select i1 %5678, i32 %5692, i32 %5679
  store i32 %5693, ptr %ready.count, align 4
  %5694 = load <8 x i1>, ptr %runnable.mask, align 1
  %5695 = or <8 x i1> %5694, %1096
  store <8 x i1> %5695, ptr %runnable.mask, align 1
  store <8 x i1> %1098, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true984:                         ; preds = %varying.coherent979
  store <8 x i1> %1089, ptr %current.mask, align 1
  %5696 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1089)
  br i1 %5696, label %schedule.61, label %scheduler.loop

varying.coherent.false985:                        ; preds = %varying.coherent979
  store <8 x i1> %1089, ptr %current.mask, align 1
  %5697 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1089)
  br i1 %5697, label %schedule.62, label %scheduler.loop

convergence.cascade995:                           ; preds = %convergence.cascade995, %schedule.62
  %convergence.cascade.flow999 = phi <8 x i1> [ %1184, %schedule.62 ], [ %5740, %convergence.cascade995 ]
  %convergence.cascade.depth1000 = phi i32 [ 0, %schedule.62 ], [ %5741, %convergence.cascade995 ]
  %5698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow999)
  %5699 = load i32, ptr %current.token, align 4
  %5700 = icmp ne i32 %5699, 0
  %5701 = and i1 %5698, %5700
  %5702 = sub i32 %5699, 1
  %5703 = select i1 %5701, i32 %5702, i32 0
  %5704 = load i8, ptr %frame.active, align 1
  %5705 = trunc i32 %5703 to i8
  %5706 = shl i8 1, %5705
  %5707 = and i8 %5704, %5706
  %5708 = icmp ne i8 %5707, 0
  %5709 = load <8 x i32>, ptr %frame.static.id, align 32
  %5710 = extractelement <8 x i32> %5709, i32 %5703
  %convergence.target.pointer1001 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %5710
  %convergence.dynamic.target1002 = load i32, ptr %convergence.target.pointer1001, align 4
  %5711 = icmp eq i32 %convergence.dynamic.target1002, 62
  %5712 = and i1 %5708, %5711
  %5713 = and i1 %5701, %5712
  %5714 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5703
  %5715 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5703
  %5716 = load <8 x i1>, ptr %5714, align 1
  %5717 = load <8 x i1>, ptr %5715, align 1
  %5718 = or <8 x i1> %5717, %convergence.cascade.flow999
  %5719 = load <8 x i1>, ptr %live.mask, align 1
  %5720 = and <8 x i1> %5716, %5719
  %5721 = icmp eq <8 x i1> %5718, %5720
  %5722 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5721)
  %5723 = and i1 %5713, %5722
  %5724 = select i1 %5723, <8 x i1> zeroinitializer, <8 x i1> %5718
  %5725 = select i1 %5713, <8 x i1> %5724, <8 x i1> %5717
  store <8 x i1> %5725, ptr %5715, align 1
  %5726 = select i1 %5723, <8 x i1> zeroinitializer, <8 x i1> %5716
  store <8 x i1> %5726, ptr %5714, align 1
  %5727 = trunc i32 %5703 to i8
  %5728 = shl i8 1, %5727
  %5729 = xor i8 %5728, -1
  %5730 = and i8 %5704, %5729
  %5731 = select i1 %5723, i8 %5730, i8 %5704
  store i8 %5731, ptr %frame.active, align 1
  %.splatinsert1003 = insertelement <8 x i1> poison, i1 %5713, i64 0
  %.splat1004 = shufflevector <8 x i1> %.splatinsert1003, <8 x i1> poison, <8 x i32> zeroinitializer
  %5732 = and <8 x i1> %convergence.cascade.flow999, %.splat1004
  %5733 = load <8 x i1>, ptr %runnable.mask, align 1
  %5734 = xor <8 x i1> %5732, splat (i1 true)
  %5735 = and <8 x i1> %5733, %5734
  store <8 x i1> %5735, ptr %runnable.mask, align 1
  %.splatinsert1005 = insertelement <8 x i1> poison, i1 %5723, i64 0
  %.splat1006 = shufflevector <8 x i1> %.splatinsert1005, <8 x i1> poison, <8 x i32> zeroinitializer
  %5736 = select <8 x i1> %.splat1006, <8 x i1> %5718, <8 x i1> zeroinitializer
  %5737 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5738 = extractelement <8 x i32> %5737, i32 %5703
  %5739 = select i1 %5723, i32 %5738, i32 %5699
  store i32 %5739, ptr %current.token, align 4
  %.splatinsert1007 = insertelement <8 x i1> poison, i1 %5713, i64 0
  %.splat1008 = shufflevector <8 x i1> %.splatinsert1007, <8 x i1> poison, <8 x i32> zeroinitializer
  %5740 = select <8 x i1> %.splat1008, <8 x i1> %5736, <8 x i1> %convergence.cascade.flow999
  %5741 = add i32 %convergence.cascade.depth1000, 1
  %5742 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5740)
  %5743 = icmp ult i32 %5741, 8
  %5744 = and i1 %5742, %5743
  %5745 = and i1 %5713, %5744
  %convergence.parent.token1009 = load i32, ptr %current.token, align 4
  %convergence.parent.present1010 = icmp ne i32 %convergence.parent.token1009, 0
  %5746 = and i1 %5745, %convergence.parent.present1010
  br i1 %5746, label %convergence.cascade995, label %convergence.cascade.exit996

convergence.cascade.exit996:                      ; preds = %convergence.cascade995, %schedule.62
  %convergence.cascade.result1011 = phi <8 x i1> [ %1184, %schedule.62 ], [ %5740, %convergence.cascade995 ]
  %5747 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1011)
  br i1 %5747, label %convergence.target.62.ready, label %scheduler.loop

convergence.target.62.ready:                      ; preds = %convergence.cascade.exit996
  %5748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1011)
  %5749 = bitcast <8 x i1> %convergence.cascade.result1011 to i8
  %5750 = call i8 @llvm.cttz.i8(i8 %5749, i1 false)
  %5751 = zext i8 %5750 to i32
  %5752 = select i1 %5748, i32 %5751, i32 0
  %.state1012 = load <8 x float>, ptr %.slot77, align 32
  %.spill.load1013 = load <8 x float>, ptr %.spill144, align 32
  %5753 = fmul <8 x float> %.state1012, %.spill.load1013
  %5754 = load <8 x float>, ptr %.spill155, align 32
  %5755 = select <8 x i1> %convergence.cascade.result1011, <8 x float> %5753, <8 x float> %5754
  store <8 x float> %5755, ptr %.spill155, align 32
  %.state1014 = load <8 x float>, ptr %.slot78, align 32
  %.spill.load1015 = load <8 x float>, ptr %.spill145, align 32
  %5756 = fmul <8 x float> %.state1014, %.spill.load1015
  %5757 = load <8 x float>, ptr %.spill156, align 32
  %5758 = select <8 x i1> %convergence.cascade.result1011, <8 x float> %5756, <8 x float> %5757
  store <8 x float> %5758, ptr %.spill156, align 32
  %.state1016 = load <8 x float>, ptr %.slot79, align 32
  %.spill.load1017 = load <8 x float>, ptr %.spill146, align 32
  %5759 = fmul <8 x float> %.state1016, %.spill.load1017
  %5760 = load <8 x float>, ptr %.spill157, align 32
  %5761 = select <8 x i1> %convergence.cascade.result1011, <8 x float> %5759, <8 x float> %5760
  store <8 x float> %5761, ptr %.spill157, align 32
  %.state1018 = load <8 x float>, ptr %.slot80, align 32
  %.spill.load1019 = load <8 x float>, ptr %.spill147, align 32
  %5762 = fmul <8 x float> %.state1018, %.spill.load1019
  %5763 = load <8 x float>, ptr %.spill158, align 32
  %5764 = select <8 x i1> %convergence.cascade.result1011, <8 x float> %5762, <8 x float> %5763
  store <8 x float> %5764, ptr %.spill158, align 32
  %.state1020 = load <8 x float>, ptr %.slot81, align 32
  %.spill.load1021 = load <8 x float>, ptr %.spill148, align 32
  %5765 = fmul <8 x float> %.state1020, %.spill.load1021
  %5766 = load <8 x float>, ptr %.spill159, align 32
  %5767 = select <8 x i1> %convergence.cascade.result1011, <8 x float> %5765, <8 x float> %5766
  store <8 x float> %5767, ptr %.spill159, align 32
  %.state1022 = load <8 x float>, ptr %.slot82, align 32
  %.spill.load1023 = load <8 x float>, ptr %.spill149, align 32
  %5768 = fmul <8 x float> %.state1022, %.spill.load1023
  %5769 = load <8 x float>, ptr %.spill160, align 32
  %5770 = select <8 x i1> %convergence.cascade.result1011, <8 x float> %5768, <8 x float> %5769
  store <8 x float> %5770, ptr %.spill160, align 32
  %.state1024 = load <8 x float>, ptr %.slot83, align 32
  %.spill.load1025 = load <8 x float>, ptr %.spill150, align 32
  %5771 = fmul <8 x float> %.state1024, %.spill.load1025
  %5772 = load <8 x float>, ptr %.spill161, align 32
  %5773 = select <8 x i1> %convergence.cascade.result1011, <8 x float> %5771, <8 x float> %5772
  store <8 x float> %5773, ptr %.spill161, align 32
  %.state1026 = load <8 x float>, ptr %.slot84, align 32
  %.spill.load1027 = load <8 x float>, ptr %.spill151, align 32
  %5774 = fmul <8 x float> %.state1026, %.spill.load1027
  %5775 = load <8 x float>, ptr %.spill162, align 32
  %5776 = select <8 x i1> %convergence.cascade.result1011, <8 x float> %5774, <8 x float> %5775
  store <8 x float> %5776, ptr %.spill162, align 32
  %5777 = load <8 x i64>, ptr %.slot163, align 64
  %5778 = select <8 x i1> %convergence.cascade.result1011, <8 x i64> zeroinitializer, <8 x i64> %5777
  store <8 x i64> %5778, ptr %.slot163, align 64
  %5779 = load <8 x float>, ptr %.slot164, align 32
  %5780 = select <8 x i1> %convergence.cascade.result1011, <8 x float> zeroinitializer, <8 x float> %5779
  store <8 x float> %5780, ptr %.slot164, align 32
  store <8 x i1> %convergence.cascade.result1011, ptr %current.mask, align 1
  %5781 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1011)
  br i1 %5781, label %schedule.63, label %scheduler.loop

varying.divergent1029:                            ; preds = %schedule.63
  %5782 = load i32, ptr %current.token, align 4
  %5783 = icmp ne i32 %5782, 0
  %5784 = sub i32 %5782, 1
  %5785 = select i1 %5783, i32 %5784, i32 0
  %5786 = load i8, ptr %frame.active, align 1
  %5787 = trunc i32 %5785 to i8
  %5788 = shl i8 1, %5787
  %5789 = and i8 %5786, %5788
  %5790 = icmp ne i8 %5789, 0
  %5791 = load <8 x i32>, ptr %frame.static.id, align 32
  %5792 = extractelement <8 x i32> %5791, i32 %5785
  %5793 = icmp eq i32 %5792, 22
  %5794 = and i1 %5790, %5793
  %5795 = and i1 %5783, %5794
  %5796 = xor i1 %5795, true
  %5797 = and i1 true, %5796
  %5798 = xor i8 %5786, -1
  %5799 = icmp ne i8 %5798, 0
  %5800 = xor i1 %5799, true
  %5801 = and i1 %5797, %5800
  br i1 %5801, label %convergence.overflow.trap1031, label %convergence.overflow.resume1032

varying.coherent1030:                             ; preds = %schedule.63
  br i1 %1195, label %varying.coherent.true1035, label %varying.coherent.false1036

convergence.overflow.trap1031:                    ; preds = %varying.divergent1029
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1032:                  ; preds = %varying.divergent1029
  %5802 = call i8 @llvm.cttz.i8(i8 %5798, i1 false)
  %5803 = zext i8 %5802 to i32
  %5804 = select i1 %5799, i32 %5803, i32 0
  %5805 = trunc i32 %5804 to i8
  %5806 = shl i8 1, %5805
  %5807 = or i8 %5786, %5806
  %5808 = select i1 %5797, i8 %5807, i8 %5786
  store i8 %5808, ptr %frame.active, align 1
  %5809 = load <8 x i32>, ptr %frame.static.id, align 32
  %5810 = extractelement <8 x i32> %5809, i32 %5804
  %5811 = select i1 %5797, i32 22, i32 %5810
  %5812 = load <8 x i32>, ptr %frame.static.id, align 32
  %5813 = insertelement <8 x i32> %5812, i32 %5811, i32 %5804
  store <8 x i32> %5813, ptr %frame.static.id, align 32
  %5814 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5815 = extractelement <8 x i32> %5814, i32 %5804
  %5816 = select i1 %5797, i32 %5782, i32 %5815
  %5817 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5818 = insertelement <8 x i32> %5817, i32 %5816, i32 %5804
  store <8 x i32> %5818, ptr %frame.parent.token, align 32
  %5819 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5804
  %5820 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5804
  %5821 = load <8 x i1>, ptr %5819, align 1
  %5822 = load <8 x i1>, ptr %5820, align 1
  %5823 = select i1 %5797, <8 x i1> %1185, <8 x i1> %5821
  store <8 x i1> %5823, ptr %5819, align 1
  %5824 = select i1 %5797, <8 x i1> zeroinitializer, <8 x i1> %5822
  store <8 x i1> %5824, ptr %5820, align 1
  %5825 = add i32 %5804, 1
  %5826 = select i1 %5795, i32 %5782, i32 %5825
  %5827 = select i1 true, i32 %5826, i32 %5782
  store i32 %5827, ptr %current.token, align 4
  %5828 = load i32, ptr %current.token, align 4
  %5829 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1192)
  %5830 = load i32, ptr %ready.count, align 4
  %5831 = icmp uge i32 %5830, 8
  %5832 = and i1 %5829, %5831
  br i1 %5832, label %ready.overflow.trap1033, label %ready.overflow.resume1034

ready.overflow.trap1033:                          ; preds = %convergence.overflow.resume1032
  call void @llvm.trap()
  unreachable

ready.overflow.resume1034:                        ; preds = %convergence.overflow.resume1032
  %5833 = select i1 %5829, i32 %5830, i32 0
  %5834 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5833
  %5835 = load <8 x i1>, ptr %5834, align 1
  %5836 = select i1 %5829, <8 x i1> %1192, <8 x i1> %5835
  store <8 x i1> %5836, ptr %5834, align 1
  %5837 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5833
  %5838 = load i32, ptr %5837, align 4
  %5839 = select i1 %5829, i32 64, i32 %5838
  store i32 %5839, ptr %5837, align 4
  %5840 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5833
  %5841 = load i32, ptr %5840, align 4
  %5842 = select i1 %5829, i32 %5828, i32 %5841
  store i32 %5842, ptr %5840, align 4
  %5843 = add i32 %5830, 1
  %5844 = select i1 %5829, i32 %5843, i32 %5830
  store i32 %5844, ptr %ready.count, align 4
  %5845 = load <8 x i1>, ptr %runnable.mask, align 1
  %5846 = or <8 x i1> %5845, %1192
  store <8 x i1> %5846, ptr %runnable.mask, align 1
  store <8 x i1> %1194, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1035:                        ; preds = %varying.coherent1030
  store <8 x i1> %1185, ptr %current.mask, align 1
  %5847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1185)
  br i1 %5847, label %schedule.64, label %scheduler.loop

varying.coherent.false1036:                       ; preds = %varying.coherent1030
  store <8 x i1> %1185, ptr %current.mask, align 1
  %5848 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1185)
  br i1 %5848, label %schedule.65, label %scheduler.loop

convergence.cascade1041:                          ; preds = %convergence.cascade1041, %schedule.65
  %convergence.cascade.flow1045 = phi <8 x i1> [ %1225, %schedule.65 ], [ %5891, %convergence.cascade1041 ]
  %convergence.cascade.depth1046 = phi i32 [ 0, %schedule.65 ], [ %5892, %convergence.cascade1041 ]
  %5849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1045)
  %5850 = load i32, ptr %current.token, align 4
  %5851 = icmp ne i32 %5850, 0
  %5852 = and i1 %5849, %5851
  %5853 = sub i32 %5850, 1
  %5854 = select i1 %5852, i32 %5853, i32 0
  %5855 = load i8, ptr %frame.active, align 1
  %5856 = trunc i32 %5854 to i8
  %5857 = shl i8 1, %5856
  %5858 = and i8 %5855, %5857
  %5859 = icmp ne i8 %5858, 0
  %5860 = load <8 x i32>, ptr %frame.static.id, align 32
  %5861 = extractelement <8 x i32> %5860, i32 %5854
  %convergence.target.pointer1047 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %5861
  %convergence.dynamic.target1048 = load i32, ptr %convergence.target.pointer1047, align 4
  %5862 = icmp eq i32 %convergence.dynamic.target1048, 65
  %5863 = and i1 %5859, %5862
  %5864 = and i1 %5852, %5863
  %5865 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5854
  %5866 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5854
  %5867 = load <8 x i1>, ptr %5865, align 1
  %5868 = load <8 x i1>, ptr %5866, align 1
  %5869 = or <8 x i1> %5868, %convergence.cascade.flow1045
  %5870 = load <8 x i1>, ptr %live.mask, align 1
  %5871 = and <8 x i1> %5867, %5870
  %5872 = icmp eq <8 x i1> %5869, %5871
  %5873 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5872)
  %5874 = and i1 %5864, %5873
  %5875 = select i1 %5874, <8 x i1> zeroinitializer, <8 x i1> %5869
  %5876 = select i1 %5864, <8 x i1> %5875, <8 x i1> %5868
  store <8 x i1> %5876, ptr %5866, align 1
  %5877 = select i1 %5874, <8 x i1> zeroinitializer, <8 x i1> %5867
  store <8 x i1> %5877, ptr %5865, align 1
  %5878 = trunc i32 %5854 to i8
  %5879 = shl i8 1, %5878
  %5880 = xor i8 %5879, -1
  %5881 = and i8 %5855, %5880
  %5882 = select i1 %5874, i8 %5881, i8 %5855
  store i8 %5882, ptr %frame.active, align 1
  %.splatinsert1049 = insertelement <8 x i1> poison, i1 %5864, i64 0
  %.splat1050 = shufflevector <8 x i1> %.splatinsert1049, <8 x i1> poison, <8 x i32> zeroinitializer
  %5883 = and <8 x i1> %convergence.cascade.flow1045, %.splat1050
  %5884 = load <8 x i1>, ptr %runnable.mask, align 1
  %5885 = xor <8 x i1> %5883, splat (i1 true)
  %5886 = and <8 x i1> %5884, %5885
  store <8 x i1> %5886, ptr %runnable.mask, align 1
  %.splatinsert1051 = insertelement <8 x i1> poison, i1 %5874, i64 0
  %.splat1052 = shufflevector <8 x i1> %.splatinsert1051, <8 x i1> poison, <8 x i32> zeroinitializer
  %5887 = select <8 x i1> %.splat1052, <8 x i1> %5869, <8 x i1> zeroinitializer
  %5888 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5889 = extractelement <8 x i32> %5888, i32 %5854
  %5890 = select i1 %5874, i32 %5889, i32 %5850
  store i32 %5890, ptr %current.token, align 4
  %.splatinsert1053 = insertelement <8 x i1> poison, i1 %5864, i64 0
  %.splat1054 = shufflevector <8 x i1> %.splatinsert1053, <8 x i1> poison, <8 x i32> zeroinitializer
  %5891 = select <8 x i1> %.splat1054, <8 x i1> %5887, <8 x i1> %convergence.cascade.flow1045
  %5892 = add i32 %convergence.cascade.depth1046, 1
  %5893 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5891)
  %5894 = icmp ult i32 %5892, 8
  %5895 = and i1 %5893, %5894
  %5896 = and i1 %5864, %5895
  %convergence.parent.token1055 = load i32, ptr %current.token, align 4
  %convergence.parent.present1056 = icmp ne i32 %convergence.parent.token1055, 0
  %5897 = and i1 %5896, %convergence.parent.present1056
  br i1 %5897, label %convergence.cascade1041, label %convergence.cascade.exit1042

convergence.cascade.exit1042:                     ; preds = %convergence.cascade1041, %schedule.65
  %convergence.cascade.result1057 = phi <8 x i1> [ %1225, %schedule.65 ], [ %5891, %convergence.cascade1041 ]
  %5898 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1057)
  br i1 %5898, label %convergence.target.65.ready, label %scheduler.loop

convergence.target.65.ready:                      ; preds = %convergence.cascade.exit1042
  %5899 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1057)
  %5900 = bitcast <8 x i1> %convergence.cascade.result1057 to i8
  %5901 = call i8 @llvm.cttz.i8(i8 %5900, i1 false)
  %5902 = zext i8 %5901 to i32
  %5903 = select i1 %5899, i32 %5902, i32 0
  %5904 = load <8 x i64>, ptr %.slot165, align 64
  %5905 = select <8 x i1> %convergence.cascade.result1057, <8 x i64> zeroinitializer, <8 x i64> %5904
  store <8 x i64> %5905, ptr %.slot165, align 64
  %5906 = load <8 x float>, ptr %.slot166, align 32
  %5907 = select <8 x i1> %convergence.cascade.result1057, <8 x float> zeroinitializer, <8 x float> %5906
  store <8 x float> %5907, ptr %.slot166, align 32
  store <8 x i1> %convergence.cascade.result1057, ptr %current.mask, align 1
  %5908 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1057)
  br i1 %5908, label %schedule.66, label %scheduler.loop

varying.divergent1059:                            ; preds = %schedule.66
  %5909 = load i32, ptr %current.token, align 4
  %5910 = icmp ne i32 %5909, 0
  %5911 = sub i32 %5909, 1
  %5912 = select i1 %5910, i32 %5911, i32 0
  %5913 = load i8, ptr %frame.active, align 1
  %5914 = trunc i32 %5912 to i8
  %5915 = shl i8 1, %5914
  %5916 = and i8 %5913, %5915
  %5917 = icmp ne i8 %5916, 0
  %5918 = load <8 x i32>, ptr %frame.static.id, align 32
  %5919 = extractelement <8 x i32> %5918, i32 %5912
  %5920 = icmp eq i32 %5919, 23
  %5921 = and i1 %5917, %5920
  %5922 = and i1 %5910, %5921
  %5923 = xor i1 %5922, true
  %5924 = and i1 true, %5923
  %5925 = xor i8 %5913, -1
  %5926 = icmp ne i8 %5925, 0
  %5927 = xor i1 %5926, true
  %5928 = and i1 %5924, %5927
  br i1 %5928, label %convergence.overflow.trap1061, label %convergence.overflow.resume1062

varying.coherent1060:                             ; preds = %schedule.66
  br i1 %1236, label %varying.coherent.true1065, label %varying.coherent.false1066

convergence.overflow.trap1061:                    ; preds = %varying.divergent1059
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1062:                  ; preds = %varying.divergent1059
  %5929 = call i8 @llvm.cttz.i8(i8 %5925, i1 false)
  %5930 = zext i8 %5929 to i32
  %5931 = select i1 %5926, i32 %5930, i32 0
  %5932 = trunc i32 %5931 to i8
  %5933 = shl i8 1, %5932
  %5934 = or i8 %5913, %5933
  %5935 = select i1 %5924, i8 %5934, i8 %5913
  store i8 %5935, ptr %frame.active, align 1
  %5936 = load <8 x i32>, ptr %frame.static.id, align 32
  %5937 = extractelement <8 x i32> %5936, i32 %5931
  %5938 = select i1 %5924, i32 23, i32 %5937
  %5939 = load <8 x i32>, ptr %frame.static.id, align 32
  %5940 = insertelement <8 x i32> %5939, i32 %5938, i32 %5931
  store <8 x i32> %5940, ptr %frame.static.id, align 32
  %5941 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5942 = extractelement <8 x i32> %5941, i32 %5931
  %5943 = select i1 %5924, i32 %5909, i32 %5942
  %5944 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5945 = insertelement <8 x i32> %5944, i32 %5943, i32 %5931
  store <8 x i32> %5945, ptr %frame.parent.token, align 32
  %5946 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5931
  %5947 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5931
  %5948 = load <8 x i1>, ptr %5946, align 1
  %5949 = load <8 x i1>, ptr %5947, align 1
  %5950 = select i1 %5924, <8 x i1> %1226, <8 x i1> %5948
  store <8 x i1> %5950, ptr %5946, align 1
  %5951 = select i1 %5924, <8 x i1> zeroinitializer, <8 x i1> %5949
  store <8 x i1> %5951, ptr %5947, align 1
  %5952 = add i32 %5931, 1
  %5953 = select i1 %5922, i32 %5909, i32 %5952
  %5954 = select i1 true, i32 %5953, i32 %5909
  store i32 %5954, ptr %current.token, align 4
  %5955 = load i32, ptr %current.token, align 4
  %5956 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1233)
  %5957 = load i32, ptr %ready.count, align 4
  %5958 = icmp uge i32 %5957, 8
  %5959 = and i1 %5956, %5958
  br i1 %5959, label %ready.overflow.trap1063, label %ready.overflow.resume1064

ready.overflow.trap1063:                          ; preds = %convergence.overflow.resume1062
  call void @llvm.trap()
  unreachable

ready.overflow.resume1064:                        ; preds = %convergence.overflow.resume1062
  %5960 = select i1 %5956, i32 %5957, i32 0
  %5961 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5960
  %5962 = load <8 x i1>, ptr %5961, align 1
  %5963 = select i1 %5956, <8 x i1> %1233, <8 x i1> %5962
  store <8 x i1> %5963, ptr %5961, align 1
  %5964 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5960
  %5965 = load i32, ptr %5964, align 4
  %5966 = select i1 %5956, i32 67, i32 %5965
  store i32 %5966, ptr %5964, align 4
  %5967 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5960
  %5968 = load i32, ptr %5967, align 4
  %5969 = select i1 %5956, i32 %5955, i32 %5968
  store i32 %5969, ptr %5967, align 4
  %5970 = add i32 %5957, 1
  %5971 = select i1 %5956, i32 %5970, i32 %5957
  store i32 %5971, ptr %ready.count, align 4
  %5972 = load <8 x i1>, ptr %runnable.mask, align 1
  %5973 = or <8 x i1> %5972, %1233
  store <8 x i1> %5973, ptr %runnable.mask, align 1
  store <8 x i1> %1235, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1065:                        ; preds = %varying.coherent1060
  store <8 x i1> %1226, ptr %current.mask, align 1
  %5974 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1226)
  br i1 %5974, label %schedule.67, label %scheduler.loop

varying.coherent.false1066:                       ; preds = %varying.coherent1060
  store <8 x i1> %1226, ptr %current.mask, align 1
  %5975 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1226)
  br i1 %5975, label %schedule.68, label %scheduler.loop

convergence.cascade1071:                          ; preds = %convergence.cascade1071, %schedule.68
  %convergence.cascade.flow1075 = phi <8 x i1> [ %1266, %schedule.68 ], [ %6018, %convergence.cascade1071 ]
  %convergence.cascade.depth1076 = phi i32 [ 0, %schedule.68 ], [ %6019, %convergence.cascade1071 ]
  %5976 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1075)
  %5977 = load i32, ptr %current.token, align 4
  %5978 = icmp ne i32 %5977, 0
  %5979 = and i1 %5976, %5978
  %5980 = sub i32 %5977, 1
  %5981 = select i1 %5979, i32 %5980, i32 0
  %5982 = load i8, ptr %frame.active, align 1
  %5983 = trunc i32 %5981 to i8
  %5984 = shl i8 1, %5983
  %5985 = and i8 %5982, %5984
  %5986 = icmp ne i8 %5985, 0
  %5987 = load <8 x i32>, ptr %frame.static.id, align 32
  %5988 = extractelement <8 x i32> %5987, i32 %5981
  %convergence.target.pointer1077 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %5988
  %convergence.dynamic.target1078 = load i32, ptr %convergence.target.pointer1077, align 4
  %5989 = icmp eq i32 %convergence.dynamic.target1078, 68
  %5990 = and i1 %5986, %5989
  %5991 = and i1 %5979, %5990
  %5992 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5981
  %5993 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5981
  %5994 = load <8 x i1>, ptr %5992, align 1
  %5995 = load <8 x i1>, ptr %5993, align 1
  %5996 = or <8 x i1> %5995, %convergence.cascade.flow1075
  %5997 = load <8 x i1>, ptr %live.mask, align 1
  %5998 = and <8 x i1> %5994, %5997
  %5999 = icmp eq <8 x i1> %5996, %5998
  %6000 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5999)
  %6001 = and i1 %5991, %6000
  %6002 = select i1 %6001, <8 x i1> zeroinitializer, <8 x i1> %5996
  %6003 = select i1 %5991, <8 x i1> %6002, <8 x i1> %5995
  store <8 x i1> %6003, ptr %5993, align 1
  %6004 = select i1 %6001, <8 x i1> zeroinitializer, <8 x i1> %5994
  store <8 x i1> %6004, ptr %5992, align 1
  %6005 = trunc i32 %5981 to i8
  %6006 = shl i8 1, %6005
  %6007 = xor i8 %6006, -1
  %6008 = and i8 %5982, %6007
  %6009 = select i1 %6001, i8 %6008, i8 %5982
  store i8 %6009, ptr %frame.active, align 1
  %.splatinsert1079 = insertelement <8 x i1> poison, i1 %5991, i64 0
  %.splat1080 = shufflevector <8 x i1> %.splatinsert1079, <8 x i1> poison, <8 x i32> zeroinitializer
  %6010 = and <8 x i1> %convergence.cascade.flow1075, %.splat1080
  %6011 = load <8 x i1>, ptr %runnable.mask, align 1
  %6012 = xor <8 x i1> %6010, splat (i1 true)
  %6013 = and <8 x i1> %6011, %6012
  store <8 x i1> %6013, ptr %runnable.mask, align 1
  %.splatinsert1081 = insertelement <8 x i1> poison, i1 %6001, i64 0
  %.splat1082 = shufflevector <8 x i1> %.splatinsert1081, <8 x i1> poison, <8 x i32> zeroinitializer
  %6014 = select <8 x i1> %.splat1082, <8 x i1> %5996, <8 x i1> zeroinitializer
  %6015 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6016 = extractelement <8 x i32> %6015, i32 %5981
  %6017 = select i1 %6001, i32 %6016, i32 %5977
  store i32 %6017, ptr %current.token, align 4
  %.splatinsert1083 = insertelement <8 x i1> poison, i1 %5991, i64 0
  %.splat1084 = shufflevector <8 x i1> %.splatinsert1083, <8 x i1> poison, <8 x i32> zeroinitializer
  %6018 = select <8 x i1> %.splat1084, <8 x i1> %6014, <8 x i1> %convergence.cascade.flow1075
  %6019 = add i32 %convergence.cascade.depth1076, 1
  %6020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6018)
  %6021 = icmp ult i32 %6019, 8
  %6022 = and i1 %6020, %6021
  %6023 = and i1 %5991, %6022
  %convergence.parent.token1085 = load i32, ptr %current.token, align 4
  %convergence.parent.present1086 = icmp ne i32 %convergence.parent.token1085, 0
  %6024 = and i1 %6023, %convergence.parent.present1086
  br i1 %6024, label %convergence.cascade1071, label %convergence.cascade.exit1072

convergence.cascade.exit1072:                     ; preds = %convergence.cascade1071, %schedule.68
  %convergence.cascade.result1087 = phi <8 x i1> [ %1266, %schedule.68 ], [ %6018, %convergence.cascade1071 ]
  %6025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1087)
  br i1 %6025, label %convergence.target.68.ready, label %scheduler.loop

convergence.target.68.ready:                      ; preds = %convergence.cascade.exit1072
  %6026 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1087)
  %6027 = bitcast <8 x i1> %convergence.cascade.result1087 to i8
  %6028 = call i8 @llvm.cttz.i8(i8 %6027, i1 false)
  %6029 = zext i8 %6028 to i32
  %6030 = select i1 %6026, i32 %6029, i32 0
  %6031 = load <8 x i64>, ptr %.slot167, align 64
  %6032 = select <8 x i1> %convergence.cascade.result1087, <8 x i64> zeroinitializer, <8 x i64> %6031
  store <8 x i64> %6032, ptr %.slot167, align 64
  %6033 = load <8 x float>, ptr %.slot168, align 32
  %6034 = select <8 x i1> %convergence.cascade.result1087, <8 x float> zeroinitializer, <8 x float> %6033
  store <8 x float> %6034, ptr %.slot168, align 32
  store <8 x i1> %convergence.cascade.result1087, ptr %current.mask, align 1
  %6035 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1087)
  br i1 %6035, label %schedule.69, label %scheduler.loop

varying.divergent1089:                            ; preds = %schedule.69
  %6036 = load i32, ptr %current.token, align 4
  %6037 = icmp ne i32 %6036, 0
  %6038 = sub i32 %6036, 1
  %6039 = select i1 %6037, i32 %6038, i32 0
  %6040 = load i8, ptr %frame.active, align 1
  %6041 = trunc i32 %6039 to i8
  %6042 = shl i8 1, %6041
  %6043 = and i8 %6040, %6042
  %6044 = icmp ne i8 %6043, 0
  %6045 = load <8 x i32>, ptr %frame.static.id, align 32
  %6046 = extractelement <8 x i32> %6045, i32 %6039
  %6047 = icmp eq i32 %6046, 24
  %6048 = and i1 %6044, %6047
  %6049 = and i1 %6037, %6048
  %6050 = xor i1 %6049, true
  %6051 = and i1 true, %6050
  %6052 = xor i8 %6040, -1
  %6053 = icmp ne i8 %6052, 0
  %6054 = xor i1 %6053, true
  %6055 = and i1 %6051, %6054
  br i1 %6055, label %convergence.overflow.trap1091, label %convergence.overflow.resume1092

varying.coherent1090:                             ; preds = %schedule.69
  br i1 %1277, label %varying.coherent.true1095, label %varying.coherent.false1096

convergence.overflow.trap1091:                    ; preds = %varying.divergent1089
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1092:                  ; preds = %varying.divergent1089
  %6056 = call i8 @llvm.cttz.i8(i8 %6052, i1 false)
  %6057 = zext i8 %6056 to i32
  %6058 = select i1 %6053, i32 %6057, i32 0
  %6059 = trunc i32 %6058 to i8
  %6060 = shl i8 1, %6059
  %6061 = or i8 %6040, %6060
  %6062 = select i1 %6051, i8 %6061, i8 %6040
  store i8 %6062, ptr %frame.active, align 1
  %6063 = load <8 x i32>, ptr %frame.static.id, align 32
  %6064 = extractelement <8 x i32> %6063, i32 %6058
  %6065 = select i1 %6051, i32 24, i32 %6064
  %6066 = load <8 x i32>, ptr %frame.static.id, align 32
  %6067 = insertelement <8 x i32> %6066, i32 %6065, i32 %6058
  store <8 x i32> %6067, ptr %frame.static.id, align 32
  %6068 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6069 = extractelement <8 x i32> %6068, i32 %6058
  %6070 = select i1 %6051, i32 %6036, i32 %6069
  %6071 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6072 = insertelement <8 x i32> %6071, i32 %6070, i32 %6058
  store <8 x i32> %6072, ptr %frame.parent.token, align 32
  %6073 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6058
  %6074 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6058
  %6075 = load <8 x i1>, ptr %6073, align 1
  %6076 = load <8 x i1>, ptr %6074, align 1
  %6077 = select i1 %6051, <8 x i1> %1267, <8 x i1> %6075
  store <8 x i1> %6077, ptr %6073, align 1
  %6078 = select i1 %6051, <8 x i1> zeroinitializer, <8 x i1> %6076
  store <8 x i1> %6078, ptr %6074, align 1
  %6079 = add i32 %6058, 1
  %6080 = select i1 %6049, i32 %6036, i32 %6079
  %6081 = select i1 true, i32 %6080, i32 %6036
  store i32 %6081, ptr %current.token, align 4
  %6082 = load i32, ptr %current.token, align 4
  %6083 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1274)
  %6084 = load i32, ptr %ready.count, align 4
  %6085 = icmp uge i32 %6084, 8
  %6086 = and i1 %6083, %6085
  br i1 %6086, label %ready.overflow.trap1093, label %ready.overflow.resume1094

ready.overflow.trap1093:                          ; preds = %convergence.overflow.resume1092
  call void @llvm.trap()
  unreachable

ready.overflow.resume1094:                        ; preds = %convergence.overflow.resume1092
  %6087 = select i1 %6083, i32 %6084, i32 0
  %6088 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6087
  %6089 = load <8 x i1>, ptr %6088, align 1
  %6090 = select i1 %6083, <8 x i1> %1274, <8 x i1> %6089
  store <8 x i1> %6090, ptr %6088, align 1
  %6091 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6087
  %6092 = load i32, ptr %6091, align 4
  %6093 = select i1 %6083, i32 70, i32 %6092
  store i32 %6093, ptr %6091, align 4
  %6094 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6087
  %6095 = load i32, ptr %6094, align 4
  %6096 = select i1 %6083, i32 %6082, i32 %6095
  store i32 %6096, ptr %6094, align 4
  %6097 = add i32 %6084, 1
  %6098 = select i1 %6083, i32 %6097, i32 %6084
  store i32 %6098, ptr %ready.count, align 4
  %6099 = load <8 x i1>, ptr %runnable.mask, align 1
  %6100 = or <8 x i1> %6099, %1274
  store <8 x i1> %6100, ptr %runnable.mask, align 1
  store <8 x i1> %1276, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1095:                        ; preds = %varying.coherent1090
  store <8 x i1> %1267, ptr %current.mask, align 1
  %6101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1267)
  br i1 %6101, label %schedule.70, label %scheduler.loop

varying.coherent.false1096:                       ; preds = %varying.coherent1090
  store <8 x i1> %1267, ptr %current.mask, align 1
  %6102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1267)
  br i1 %6102, label %schedule.71, label %scheduler.loop

convergence.cascade1101:                          ; preds = %convergence.cascade1101, %schedule.71
  %convergence.cascade.flow1105 = phi <8 x i1> [ %1307, %schedule.71 ], [ %6145, %convergence.cascade1101 ]
  %convergence.cascade.depth1106 = phi i32 [ 0, %schedule.71 ], [ %6146, %convergence.cascade1101 ]
  %6103 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1105)
  %6104 = load i32, ptr %current.token, align 4
  %6105 = icmp ne i32 %6104, 0
  %6106 = and i1 %6103, %6105
  %6107 = sub i32 %6104, 1
  %6108 = select i1 %6106, i32 %6107, i32 0
  %6109 = load i8, ptr %frame.active, align 1
  %6110 = trunc i32 %6108 to i8
  %6111 = shl i8 1, %6110
  %6112 = and i8 %6109, %6111
  %6113 = icmp ne i8 %6112, 0
  %6114 = load <8 x i32>, ptr %frame.static.id, align 32
  %6115 = extractelement <8 x i32> %6114, i32 %6108
  %convergence.target.pointer1107 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6115
  %convergence.dynamic.target1108 = load i32, ptr %convergence.target.pointer1107, align 4
  %6116 = icmp eq i32 %convergence.dynamic.target1108, 71
  %6117 = and i1 %6113, %6116
  %6118 = and i1 %6106, %6117
  %6119 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6108
  %6120 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6108
  %6121 = load <8 x i1>, ptr %6119, align 1
  %6122 = load <8 x i1>, ptr %6120, align 1
  %6123 = or <8 x i1> %6122, %convergence.cascade.flow1105
  %6124 = load <8 x i1>, ptr %live.mask, align 1
  %6125 = and <8 x i1> %6121, %6124
  %6126 = icmp eq <8 x i1> %6123, %6125
  %6127 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6126)
  %6128 = and i1 %6118, %6127
  %6129 = select i1 %6128, <8 x i1> zeroinitializer, <8 x i1> %6123
  %6130 = select i1 %6118, <8 x i1> %6129, <8 x i1> %6122
  store <8 x i1> %6130, ptr %6120, align 1
  %6131 = select i1 %6128, <8 x i1> zeroinitializer, <8 x i1> %6121
  store <8 x i1> %6131, ptr %6119, align 1
  %6132 = trunc i32 %6108 to i8
  %6133 = shl i8 1, %6132
  %6134 = xor i8 %6133, -1
  %6135 = and i8 %6109, %6134
  %6136 = select i1 %6128, i8 %6135, i8 %6109
  store i8 %6136, ptr %frame.active, align 1
  %.splatinsert1109 = insertelement <8 x i1> poison, i1 %6118, i64 0
  %.splat1110 = shufflevector <8 x i1> %.splatinsert1109, <8 x i1> poison, <8 x i32> zeroinitializer
  %6137 = and <8 x i1> %convergence.cascade.flow1105, %.splat1110
  %6138 = load <8 x i1>, ptr %runnable.mask, align 1
  %6139 = xor <8 x i1> %6137, splat (i1 true)
  %6140 = and <8 x i1> %6138, %6139
  store <8 x i1> %6140, ptr %runnable.mask, align 1
  %.splatinsert1111 = insertelement <8 x i1> poison, i1 %6128, i64 0
  %.splat1112 = shufflevector <8 x i1> %.splatinsert1111, <8 x i1> poison, <8 x i32> zeroinitializer
  %6141 = select <8 x i1> %.splat1112, <8 x i1> %6123, <8 x i1> zeroinitializer
  %6142 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6143 = extractelement <8 x i32> %6142, i32 %6108
  %6144 = select i1 %6128, i32 %6143, i32 %6104
  store i32 %6144, ptr %current.token, align 4
  %.splatinsert1113 = insertelement <8 x i1> poison, i1 %6118, i64 0
  %.splat1114 = shufflevector <8 x i1> %.splatinsert1113, <8 x i1> poison, <8 x i32> zeroinitializer
  %6145 = select <8 x i1> %.splat1114, <8 x i1> %6141, <8 x i1> %convergence.cascade.flow1105
  %6146 = add i32 %convergence.cascade.depth1106, 1
  %6147 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6145)
  %6148 = icmp ult i32 %6146, 8
  %6149 = and i1 %6147, %6148
  %6150 = and i1 %6118, %6149
  %convergence.parent.token1115 = load i32, ptr %current.token, align 4
  %convergence.parent.present1116 = icmp ne i32 %convergence.parent.token1115, 0
  %6151 = and i1 %6150, %convergence.parent.present1116
  br i1 %6151, label %convergence.cascade1101, label %convergence.cascade.exit1102

convergence.cascade.exit1102:                     ; preds = %convergence.cascade1101, %schedule.71
  %convergence.cascade.result1117 = phi <8 x i1> [ %1307, %schedule.71 ], [ %6145, %convergence.cascade1101 ]
  %6152 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1117)
  br i1 %6152, label %convergence.target.71.ready, label %scheduler.loop

convergence.target.71.ready:                      ; preds = %convergence.cascade.exit1102
  %6153 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1117)
  %6154 = bitcast <8 x i1> %convergence.cascade.result1117 to i8
  %6155 = call i8 @llvm.cttz.i8(i8 %6154, i1 false)
  %6156 = zext i8 %6155 to i32
  %6157 = select i1 %6153, i32 %6156, i32 0
  %6158 = load <8 x i64>, ptr %.slot169, align 64
  %6159 = select <8 x i1> %convergence.cascade.result1117, <8 x i64> zeroinitializer, <8 x i64> %6158
  store <8 x i64> %6159, ptr %.slot169, align 64
  %6160 = load <8 x float>, ptr %.slot170, align 32
  %6161 = select <8 x i1> %convergence.cascade.result1117, <8 x float> zeroinitializer, <8 x float> %6160
  store <8 x float> %6161, ptr %.slot170, align 32
  store <8 x i1> %convergence.cascade.result1117, ptr %current.mask, align 1
  %6162 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1117)
  br i1 %6162, label %schedule.72, label %scheduler.loop

varying.divergent1119:                            ; preds = %schedule.72
  %6163 = load i32, ptr %current.token, align 4
  %6164 = icmp ne i32 %6163, 0
  %6165 = sub i32 %6163, 1
  %6166 = select i1 %6164, i32 %6165, i32 0
  %6167 = load i8, ptr %frame.active, align 1
  %6168 = trunc i32 %6166 to i8
  %6169 = shl i8 1, %6168
  %6170 = and i8 %6167, %6169
  %6171 = icmp ne i8 %6170, 0
  %6172 = load <8 x i32>, ptr %frame.static.id, align 32
  %6173 = extractelement <8 x i32> %6172, i32 %6166
  %6174 = icmp eq i32 %6173, 25
  %6175 = and i1 %6171, %6174
  %6176 = and i1 %6164, %6175
  %6177 = xor i1 %6176, true
  %6178 = and i1 true, %6177
  %6179 = xor i8 %6167, -1
  %6180 = icmp ne i8 %6179, 0
  %6181 = xor i1 %6180, true
  %6182 = and i1 %6178, %6181
  br i1 %6182, label %convergence.overflow.trap1121, label %convergence.overflow.resume1122

varying.coherent1120:                             ; preds = %schedule.72
  br i1 %1318, label %varying.coherent.true1125, label %varying.coherent.false1126

convergence.overflow.trap1121:                    ; preds = %varying.divergent1119
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1122:                  ; preds = %varying.divergent1119
  %6183 = call i8 @llvm.cttz.i8(i8 %6179, i1 false)
  %6184 = zext i8 %6183 to i32
  %6185 = select i1 %6180, i32 %6184, i32 0
  %6186 = trunc i32 %6185 to i8
  %6187 = shl i8 1, %6186
  %6188 = or i8 %6167, %6187
  %6189 = select i1 %6178, i8 %6188, i8 %6167
  store i8 %6189, ptr %frame.active, align 1
  %6190 = load <8 x i32>, ptr %frame.static.id, align 32
  %6191 = extractelement <8 x i32> %6190, i32 %6185
  %6192 = select i1 %6178, i32 25, i32 %6191
  %6193 = load <8 x i32>, ptr %frame.static.id, align 32
  %6194 = insertelement <8 x i32> %6193, i32 %6192, i32 %6185
  store <8 x i32> %6194, ptr %frame.static.id, align 32
  %6195 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6196 = extractelement <8 x i32> %6195, i32 %6185
  %6197 = select i1 %6178, i32 %6163, i32 %6196
  %6198 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6199 = insertelement <8 x i32> %6198, i32 %6197, i32 %6185
  store <8 x i32> %6199, ptr %frame.parent.token, align 32
  %6200 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6185
  %6201 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6185
  %6202 = load <8 x i1>, ptr %6200, align 1
  %6203 = load <8 x i1>, ptr %6201, align 1
  %6204 = select i1 %6178, <8 x i1> %1308, <8 x i1> %6202
  store <8 x i1> %6204, ptr %6200, align 1
  %6205 = select i1 %6178, <8 x i1> zeroinitializer, <8 x i1> %6203
  store <8 x i1> %6205, ptr %6201, align 1
  %6206 = add i32 %6185, 1
  %6207 = select i1 %6176, i32 %6163, i32 %6206
  %6208 = select i1 true, i32 %6207, i32 %6163
  store i32 %6208, ptr %current.token, align 4
  %6209 = load i32, ptr %current.token, align 4
  %6210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1315)
  %6211 = load i32, ptr %ready.count, align 4
  %6212 = icmp uge i32 %6211, 8
  %6213 = and i1 %6210, %6212
  br i1 %6213, label %ready.overflow.trap1123, label %ready.overflow.resume1124

ready.overflow.trap1123:                          ; preds = %convergence.overflow.resume1122
  call void @llvm.trap()
  unreachable

ready.overflow.resume1124:                        ; preds = %convergence.overflow.resume1122
  %6214 = select i1 %6210, i32 %6211, i32 0
  %6215 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6214
  %6216 = load <8 x i1>, ptr %6215, align 1
  %6217 = select i1 %6210, <8 x i1> %1315, <8 x i1> %6216
  store <8 x i1> %6217, ptr %6215, align 1
  %6218 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6214
  %6219 = load i32, ptr %6218, align 4
  %6220 = select i1 %6210, i32 73, i32 %6219
  store i32 %6220, ptr %6218, align 4
  %6221 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6214
  %6222 = load i32, ptr %6221, align 4
  %6223 = select i1 %6210, i32 %6209, i32 %6222
  store i32 %6223, ptr %6221, align 4
  %6224 = add i32 %6211, 1
  %6225 = select i1 %6210, i32 %6224, i32 %6211
  store i32 %6225, ptr %ready.count, align 4
  %6226 = load <8 x i1>, ptr %runnable.mask, align 1
  %6227 = or <8 x i1> %6226, %1315
  store <8 x i1> %6227, ptr %runnable.mask, align 1
  store <8 x i1> %1317, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1125:                        ; preds = %varying.coherent1120
  store <8 x i1> %1308, ptr %current.mask, align 1
  %6228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1308)
  br i1 %6228, label %schedule.73, label %scheduler.loop

varying.coherent.false1126:                       ; preds = %varying.coherent1120
  store <8 x i1> %1308, ptr %current.mask, align 1
  %6229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1308)
  br i1 %6229, label %schedule.74, label %scheduler.loop

convergence.cascade1131:                          ; preds = %convergence.cascade1131, %schedule.74
  %convergence.cascade.flow1135 = phi <8 x i1> [ %1348, %schedule.74 ], [ %6272, %convergence.cascade1131 ]
  %convergence.cascade.depth1136 = phi i32 [ 0, %schedule.74 ], [ %6273, %convergence.cascade1131 ]
  %6230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1135)
  %6231 = load i32, ptr %current.token, align 4
  %6232 = icmp ne i32 %6231, 0
  %6233 = and i1 %6230, %6232
  %6234 = sub i32 %6231, 1
  %6235 = select i1 %6233, i32 %6234, i32 0
  %6236 = load i8, ptr %frame.active, align 1
  %6237 = trunc i32 %6235 to i8
  %6238 = shl i8 1, %6237
  %6239 = and i8 %6236, %6238
  %6240 = icmp ne i8 %6239, 0
  %6241 = load <8 x i32>, ptr %frame.static.id, align 32
  %6242 = extractelement <8 x i32> %6241, i32 %6235
  %convergence.target.pointer1137 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6242
  %convergence.dynamic.target1138 = load i32, ptr %convergence.target.pointer1137, align 4
  %6243 = icmp eq i32 %convergence.dynamic.target1138, 74
  %6244 = and i1 %6240, %6243
  %6245 = and i1 %6233, %6244
  %6246 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6235
  %6247 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6235
  %6248 = load <8 x i1>, ptr %6246, align 1
  %6249 = load <8 x i1>, ptr %6247, align 1
  %6250 = or <8 x i1> %6249, %convergence.cascade.flow1135
  %6251 = load <8 x i1>, ptr %live.mask, align 1
  %6252 = and <8 x i1> %6248, %6251
  %6253 = icmp eq <8 x i1> %6250, %6252
  %6254 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6253)
  %6255 = and i1 %6245, %6254
  %6256 = select i1 %6255, <8 x i1> zeroinitializer, <8 x i1> %6250
  %6257 = select i1 %6245, <8 x i1> %6256, <8 x i1> %6249
  store <8 x i1> %6257, ptr %6247, align 1
  %6258 = select i1 %6255, <8 x i1> zeroinitializer, <8 x i1> %6248
  store <8 x i1> %6258, ptr %6246, align 1
  %6259 = trunc i32 %6235 to i8
  %6260 = shl i8 1, %6259
  %6261 = xor i8 %6260, -1
  %6262 = and i8 %6236, %6261
  %6263 = select i1 %6255, i8 %6262, i8 %6236
  store i8 %6263, ptr %frame.active, align 1
  %.splatinsert1139 = insertelement <8 x i1> poison, i1 %6245, i64 0
  %.splat1140 = shufflevector <8 x i1> %.splatinsert1139, <8 x i1> poison, <8 x i32> zeroinitializer
  %6264 = and <8 x i1> %convergence.cascade.flow1135, %.splat1140
  %6265 = load <8 x i1>, ptr %runnable.mask, align 1
  %6266 = xor <8 x i1> %6264, splat (i1 true)
  %6267 = and <8 x i1> %6265, %6266
  store <8 x i1> %6267, ptr %runnable.mask, align 1
  %.splatinsert1141 = insertelement <8 x i1> poison, i1 %6255, i64 0
  %.splat1142 = shufflevector <8 x i1> %.splatinsert1141, <8 x i1> poison, <8 x i32> zeroinitializer
  %6268 = select <8 x i1> %.splat1142, <8 x i1> %6250, <8 x i1> zeroinitializer
  %6269 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6270 = extractelement <8 x i32> %6269, i32 %6235
  %6271 = select i1 %6255, i32 %6270, i32 %6231
  store i32 %6271, ptr %current.token, align 4
  %.splatinsert1143 = insertelement <8 x i1> poison, i1 %6245, i64 0
  %.splat1144 = shufflevector <8 x i1> %.splatinsert1143, <8 x i1> poison, <8 x i32> zeroinitializer
  %6272 = select <8 x i1> %.splat1144, <8 x i1> %6268, <8 x i1> %convergence.cascade.flow1135
  %6273 = add i32 %convergence.cascade.depth1136, 1
  %6274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6272)
  %6275 = icmp ult i32 %6273, 8
  %6276 = and i1 %6274, %6275
  %6277 = and i1 %6245, %6276
  %convergence.parent.token1145 = load i32, ptr %current.token, align 4
  %convergence.parent.present1146 = icmp ne i32 %convergence.parent.token1145, 0
  %6278 = and i1 %6277, %convergence.parent.present1146
  br i1 %6278, label %convergence.cascade1131, label %convergence.cascade.exit1132

convergence.cascade.exit1132:                     ; preds = %convergence.cascade1131, %schedule.74
  %convergence.cascade.result1147 = phi <8 x i1> [ %1348, %schedule.74 ], [ %6272, %convergence.cascade1131 ]
  %6279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1147)
  br i1 %6279, label %convergence.target.74.ready, label %scheduler.loop

convergence.target.74.ready:                      ; preds = %convergence.cascade.exit1132
  %6280 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1147)
  %6281 = bitcast <8 x i1> %convergence.cascade.result1147 to i8
  %6282 = call i8 @llvm.cttz.i8(i8 %6281, i1 false)
  %6283 = zext i8 %6282 to i32
  %6284 = select i1 %6280, i32 %6283, i32 0
  %6285 = load <8 x i64>, ptr %.slot171, align 64
  %6286 = select <8 x i1> %convergence.cascade.result1147, <8 x i64> zeroinitializer, <8 x i64> %6285
  store <8 x i64> %6286, ptr %.slot171, align 64
  %6287 = load <8 x float>, ptr %.slot172, align 32
  %6288 = select <8 x i1> %convergence.cascade.result1147, <8 x float> zeroinitializer, <8 x float> %6287
  store <8 x float> %6288, ptr %.slot172, align 32
  store <8 x i1> %convergence.cascade.result1147, ptr %current.mask, align 1
  %6289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1147)
  br i1 %6289, label %schedule.75, label %scheduler.loop

varying.divergent1149:                            ; preds = %schedule.75
  %6290 = load i32, ptr %current.token, align 4
  %6291 = icmp ne i32 %6290, 0
  %6292 = sub i32 %6290, 1
  %6293 = select i1 %6291, i32 %6292, i32 0
  %6294 = load i8, ptr %frame.active, align 1
  %6295 = trunc i32 %6293 to i8
  %6296 = shl i8 1, %6295
  %6297 = and i8 %6294, %6296
  %6298 = icmp ne i8 %6297, 0
  %6299 = load <8 x i32>, ptr %frame.static.id, align 32
  %6300 = extractelement <8 x i32> %6299, i32 %6293
  %6301 = icmp eq i32 %6300, 26
  %6302 = and i1 %6298, %6301
  %6303 = and i1 %6291, %6302
  %6304 = xor i1 %6303, true
  %6305 = and i1 true, %6304
  %6306 = xor i8 %6294, -1
  %6307 = icmp ne i8 %6306, 0
  %6308 = xor i1 %6307, true
  %6309 = and i1 %6305, %6308
  br i1 %6309, label %convergence.overflow.trap1151, label %convergence.overflow.resume1152

varying.coherent1150:                             ; preds = %schedule.75
  br i1 %1359, label %varying.coherent.true1155, label %varying.coherent.false1156

convergence.overflow.trap1151:                    ; preds = %varying.divergent1149
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1152:                  ; preds = %varying.divergent1149
  %6310 = call i8 @llvm.cttz.i8(i8 %6306, i1 false)
  %6311 = zext i8 %6310 to i32
  %6312 = select i1 %6307, i32 %6311, i32 0
  %6313 = trunc i32 %6312 to i8
  %6314 = shl i8 1, %6313
  %6315 = or i8 %6294, %6314
  %6316 = select i1 %6305, i8 %6315, i8 %6294
  store i8 %6316, ptr %frame.active, align 1
  %6317 = load <8 x i32>, ptr %frame.static.id, align 32
  %6318 = extractelement <8 x i32> %6317, i32 %6312
  %6319 = select i1 %6305, i32 26, i32 %6318
  %6320 = load <8 x i32>, ptr %frame.static.id, align 32
  %6321 = insertelement <8 x i32> %6320, i32 %6319, i32 %6312
  store <8 x i32> %6321, ptr %frame.static.id, align 32
  %6322 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6323 = extractelement <8 x i32> %6322, i32 %6312
  %6324 = select i1 %6305, i32 %6290, i32 %6323
  %6325 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6326 = insertelement <8 x i32> %6325, i32 %6324, i32 %6312
  store <8 x i32> %6326, ptr %frame.parent.token, align 32
  %6327 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6312
  %6328 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6312
  %6329 = load <8 x i1>, ptr %6327, align 1
  %6330 = load <8 x i1>, ptr %6328, align 1
  %6331 = select i1 %6305, <8 x i1> %1349, <8 x i1> %6329
  store <8 x i1> %6331, ptr %6327, align 1
  %6332 = select i1 %6305, <8 x i1> zeroinitializer, <8 x i1> %6330
  store <8 x i1> %6332, ptr %6328, align 1
  %6333 = add i32 %6312, 1
  %6334 = select i1 %6303, i32 %6290, i32 %6333
  %6335 = select i1 true, i32 %6334, i32 %6290
  store i32 %6335, ptr %current.token, align 4
  %6336 = load i32, ptr %current.token, align 4
  %6337 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1356)
  %6338 = load i32, ptr %ready.count, align 4
  %6339 = icmp uge i32 %6338, 8
  %6340 = and i1 %6337, %6339
  br i1 %6340, label %ready.overflow.trap1153, label %ready.overflow.resume1154

ready.overflow.trap1153:                          ; preds = %convergence.overflow.resume1152
  call void @llvm.trap()
  unreachable

ready.overflow.resume1154:                        ; preds = %convergence.overflow.resume1152
  %6341 = select i1 %6337, i32 %6338, i32 0
  %6342 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6341
  %6343 = load <8 x i1>, ptr %6342, align 1
  %6344 = select i1 %6337, <8 x i1> %1356, <8 x i1> %6343
  store <8 x i1> %6344, ptr %6342, align 1
  %6345 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6341
  %6346 = load i32, ptr %6345, align 4
  %6347 = select i1 %6337, i32 76, i32 %6346
  store i32 %6347, ptr %6345, align 4
  %6348 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6341
  %6349 = load i32, ptr %6348, align 4
  %6350 = select i1 %6337, i32 %6336, i32 %6349
  store i32 %6350, ptr %6348, align 4
  %6351 = add i32 %6338, 1
  %6352 = select i1 %6337, i32 %6351, i32 %6338
  store i32 %6352, ptr %ready.count, align 4
  %6353 = load <8 x i1>, ptr %runnable.mask, align 1
  %6354 = or <8 x i1> %6353, %1356
  store <8 x i1> %6354, ptr %runnable.mask, align 1
  store <8 x i1> %1358, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1155:                        ; preds = %varying.coherent1150
  store <8 x i1> %1349, ptr %current.mask, align 1
  %6355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1349)
  br i1 %6355, label %schedule.76, label %scheduler.loop

varying.coherent.false1156:                       ; preds = %varying.coherent1150
  store <8 x i1> %1349, ptr %current.mask, align 1
  %6356 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1349)
  br i1 %6356, label %schedule.77, label %scheduler.loop

convergence.cascade1161:                          ; preds = %convergence.cascade1161, %schedule.77
  %convergence.cascade.flow1165 = phi <8 x i1> [ %1389, %schedule.77 ], [ %6399, %convergence.cascade1161 ]
  %convergence.cascade.depth1166 = phi i32 [ 0, %schedule.77 ], [ %6400, %convergence.cascade1161 ]
  %6357 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1165)
  %6358 = load i32, ptr %current.token, align 4
  %6359 = icmp ne i32 %6358, 0
  %6360 = and i1 %6357, %6359
  %6361 = sub i32 %6358, 1
  %6362 = select i1 %6360, i32 %6361, i32 0
  %6363 = load i8, ptr %frame.active, align 1
  %6364 = trunc i32 %6362 to i8
  %6365 = shl i8 1, %6364
  %6366 = and i8 %6363, %6365
  %6367 = icmp ne i8 %6366, 0
  %6368 = load <8 x i32>, ptr %frame.static.id, align 32
  %6369 = extractelement <8 x i32> %6368, i32 %6362
  %convergence.target.pointer1167 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6369
  %convergence.dynamic.target1168 = load i32, ptr %convergence.target.pointer1167, align 4
  %6370 = icmp eq i32 %convergence.dynamic.target1168, 77
  %6371 = and i1 %6367, %6370
  %6372 = and i1 %6360, %6371
  %6373 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6362
  %6374 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6362
  %6375 = load <8 x i1>, ptr %6373, align 1
  %6376 = load <8 x i1>, ptr %6374, align 1
  %6377 = or <8 x i1> %6376, %convergence.cascade.flow1165
  %6378 = load <8 x i1>, ptr %live.mask, align 1
  %6379 = and <8 x i1> %6375, %6378
  %6380 = icmp eq <8 x i1> %6377, %6379
  %6381 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6380)
  %6382 = and i1 %6372, %6381
  %6383 = select i1 %6382, <8 x i1> zeroinitializer, <8 x i1> %6377
  %6384 = select i1 %6372, <8 x i1> %6383, <8 x i1> %6376
  store <8 x i1> %6384, ptr %6374, align 1
  %6385 = select i1 %6382, <8 x i1> zeroinitializer, <8 x i1> %6375
  store <8 x i1> %6385, ptr %6373, align 1
  %6386 = trunc i32 %6362 to i8
  %6387 = shl i8 1, %6386
  %6388 = xor i8 %6387, -1
  %6389 = and i8 %6363, %6388
  %6390 = select i1 %6382, i8 %6389, i8 %6363
  store i8 %6390, ptr %frame.active, align 1
  %.splatinsert1169 = insertelement <8 x i1> poison, i1 %6372, i64 0
  %.splat1170 = shufflevector <8 x i1> %.splatinsert1169, <8 x i1> poison, <8 x i32> zeroinitializer
  %6391 = and <8 x i1> %convergence.cascade.flow1165, %.splat1170
  %6392 = load <8 x i1>, ptr %runnable.mask, align 1
  %6393 = xor <8 x i1> %6391, splat (i1 true)
  %6394 = and <8 x i1> %6392, %6393
  store <8 x i1> %6394, ptr %runnable.mask, align 1
  %.splatinsert1171 = insertelement <8 x i1> poison, i1 %6382, i64 0
  %.splat1172 = shufflevector <8 x i1> %.splatinsert1171, <8 x i1> poison, <8 x i32> zeroinitializer
  %6395 = select <8 x i1> %.splat1172, <8 x i1> %6377, <8 x i1> zeroinitializer
  %6396 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6397 = extractelement <8 x i32> %6396, i32 %6362
  %6398 = select i1 %6382, i32 %6397, i32 %6358
  store i32 %6398, ptr %current.token, align 4
  %.splatinsert1173 = insertelement <8 x i1> poison, i1 %6372, i64 0
  %.splat1174 = shufflevector <8 x i1> %.splatinsert1173, <8 x i1> poison, <8 x i32> zeroinitializer
  %6399 = select <8 x i1> %.splat1174, <8 x i1> %6395, <8 x i1> %convergence.cascade.flow1165
  %6400 = add i32 %convergence.cascade.depth1166, 1
  %6401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6399)
  %6402 = icmp ult i32 %6400, 8
  %6403 = and i1 %6401, %6402
  %6404 = and i1 %6372, %6403
  %convergence.parent.token1175 = load i32, ptr %current.token, align 4
  %convergence.parent.present1176 = icmp ne i32 %convergence.parent.token1175, 0
  %6405 = and i1 %6404, %convergence.parent.present1176
  br i1 %6405, label %convergence.cascade1161, label %convergence.cascade.exit1162

convergence.cascade.exit1162:                     ; preds = %convergence.cascade1161, %schedule.77
  %convergence.cascade.result1177 = phi <8 x i1> [ %1389, %schedule.77 ], [ %6399, %convergence.cascade1161 ]
  %6406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1177)
  br i1 %6406, label %convergence.target.77.ready, label %scheduler.loop

convergence.target.77.ready:                      ; preds = %convergence.cascade.exit1162
  %6407 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1177)
  %6408 = bitcast <8 x i1> %convergence.cascade.result1177 to i8
  %6409 = call i8 @llvm.cttz.i8(i8 %6408, i1 false)
  %6410 = zext i8 %6409 to i32
  %6411 = select i1 %6407, i32 %6410, i32 0
  %6412 = load <8 x i64>, ptr %.slot173, align 64
  %6413 = select <8 x i1> %convergence.cascade.result1177, <8 x i64> zeroinitializer, <8 x i64> %6412
  store <8 x i64> %6413, ptr %.slot173, align 64
  %6414 = load <8 x float>, ptr %.slot174, align 32
  %6415 = select <8 x i1> %convergence.cascade.result1177, <8 x float> zeroinitializer, <8 x float> %6414
  store <8 x float> %6415, ptr %.slot174, align 32
  store <8 x i1> %convergence.cascade.result1177, ptr %current.mask, align 1
  %6416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1177)
  br i1 %6416, label %schedule.78, label %scheduler.loop

varying.divergent1179:                            ; preds = %schedule.78
  %6417 = load i32, ptr %current.token, align 4
  %6418 = icmp ne i32 %6417, 0
  %6419 = sub i32 %6417, 1
  %6420 = select i1 %6418, i32 %6419, i32 0
  %6421 = load i8, ptr %frame.active, align 1
  %6422 = trunc i32 %6420 to i8
  %6423 = shl i8 1, %6422
  %6424 = and i8 %6421, %6423
  %6425 = icmp ne i8 %6424, 0
  %6426 = load <8 x i32>, ptr %frame.static.id, align 32
  %6427 = extractelement <8 x i32> %6426, i32 %6420
  %6428 = icmp eq i32 %6427, 27
  %6429 = and i1 %6425, %6428
  %6430 = and i1 %6418, %6429
  %6431 = xor i1 %6430, true
  %6432 = and i1 true, %6431
  %6433 = xor i8 %6421, -1
  %6434 = icmp ne i8 %6433, 0
  %6435 = xor i1 %6434, true
  %6436 = and i1 %6432, %6435
  br i1 %6436, label %convergence.overflow.trap1181, label %convergence.overflow.resume1182

varying.coherent1180:                             ; preds = %schedule.78
  br i1 %1400, label %varying.coherent.true1185, label %varying.coherent.false1186

convergence.overflow.trap1181:                    ; preds = %varying.divergent1179
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1182:                  ; preds = %varying.divergent1179
  %6437 = call i8 @llvm.cttz.i8(i8 %6433, i1 false)
  %6438 = zext i8 %6437 to i32
  %6439 = select i1 %6434, i32 %6438, i32 0
  %6440 = trunc i32 %6439 to i8
  %6441 = shl i8 1, %6440
  %6442 = or i8 %6421, %6441
  %6443 = select i1 %6432, i8 %6442, i8 %6421
  store i8 %6443, ptr %frame.active, align 1
  %6444 = load <8 x i32>, ptr %frame.static.id, align 32
  %6445 = extractelement <8 x i32> %6444, i32 %6439
  %6446 = select i1 %6432, i32 27, i32 %6445
  %6447 = load <8 x i32>, ptr %frame.static.id, align 32
  %6448 = insertelement <8 x i32> %6447, i32 %6446, i32 %6439
  store <8 x i32> %6448, ptr %frame.static.id, align 32
  %6449 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6450 = extractelement <8 x i32> %6449, i32 %6439
  %6451 = select i1 %6432, i32 %6417, i32 %6450
  %6452 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6453 = insertelement <8 x i32> %6452, i32 %6451, i32 %6439
  store <8 x i32> %6453, ptr %frame.parent.token, align 32
  %6454 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6439
  %6455 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6439
  %6456 = load <8 x i1>, ptr %6454, align 1
  %6457 = load <8 x i1>, ptr %6455, align 1
  %6458 = select i1 %6432, <8 x i1> %1390, <8 x i1> %6456
  store <8 x i1> %6458, ptr %6454, align 1
  %6459 = select i1 %6432, <8 x i1> zeroinitializer, <8 x i1> %6457
  store <8 x i1> %6459, ptr %6455, align 1
  %6460 = add i32 %6439, 1
  %6461 = select i1 %6430, i32 %6417, i32 %6460
  %6462 = select i1 true, i32 %6461, i32 %6417
  store i32 %6462, ptr %current.token, align 4
  %6463 = load i32, ptr %current.token, align 4
  %6464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1397)
  %6465 = load i32, ptr %ready.count, align 4
  %6466 = icmp uge i32 %6465, 8
  %6467 = and i1 %6464, %6466
  br i1 %6467, label %ready.overflow.trap1183, label %ready.overflow.resume1184

ready.overflow.trap1183:                          ; preds = %convergence.overflow.resume1182
  call void @llvm.trap()
  unreachable

ready.overflow.resume1184:                        ; preds = %convergence.overflow.resume1182
  %6468 = select i1 %6464, i32 %6465, i32 0
  %6469 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6468
  %6470 = load <8 x i1>, ptr %6469, align 1
  %6471 = select i1 %6464, <8 x i1> %1397, <8 x i1> %6470
  store <8 x i1> %6471, ptr %6469, align 1
  %6472 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6468
  %6473 = load i32, ptr %6472, align 4
  %6474 = select i1 %6464, i32 79, i32 %6473
  store i32 %6474, ptr %6472, align 4
  %6475 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6468
  %6476 = load i32, ptr %6475, align 4
  %6477 = select i1 %6464, i32 %6463, i32 %6476
  store i32 %6477, ptr %6475, align 4
  %6478 = add i32 %6465, 1
  %6479 = select i1 %6464, i32 %6478, i32 %6465
  store i32 %6479, ptr %ready.count, align 4
  %6480 = load <8 x i1>, ptr %runnable.mask, align 1
  %6481 = or <8 x i1> %6480, %1397
  store <8 x i1> %6481, ptr %runnable.mask, align 1
  store <8 x i1> %1399, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1185:                        ; preds = %varying.coherent1180
  store <8 x i1> %1390, ptr %current.mask, align 1
  %6482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1390)
  br i1 %6482, label %schedule.79, label %scheduler.loop

varying.coherent.false1186:                       ; preds = %varying.coherent1180
  store <8 x i1> %1390, ptr %current.mask, align 1
  %6483 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1390)
  br i1 %6483, label %schedule.80, label %scheduler.loop

convergence.cascade1191:                          ; preds = %convergence.cascade1191, %schedule.80
  %convergence.cascade.flow1195 = phi <8 x i1> [ %1430, %schedule.80 ], [ %6526, %convergence.cascade1191 ]
  %convergence.cascade.depth1196 = phi i32 [ 0, %schedule.80 ], [ %6527, %convergence.cascade1191 ]
  %6484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1195)
  %6485 = load i32, ptr %current.token, align 4
  %6486 = icmp ne i32 %6485, 0
  %6487 = and i1 %6484, %6486
  %6488 = sub i32 %6485, 1
  %6489 = select i1 %6487, i32 %6488, i32 0
  %6490 = load i8, ptr %frame.active, align 1
  %6491 = trunc i32 %6489 to i8
  %6492 = shl i8 1, %6491
  %6493 = and i8 %6490, %6492
  %6494 = icmp ne i8 %6493, 0
  %6495 = load <8 x i32>, ptr %frame.static.id, align 32
  %6496 = extractelement <8 x i32> %6495, i32 %6489
  %convergence.target.pointer1197 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6496
  %convergence.dynamic.target1198 = load i32, ptr %convergence.target.pointer1197, align 4
  %6497 = icmp eq i32 %convergence.dynamic.target1198, 80
  %6498 = and i1 %6494, %6497
  %6499 = and i1 %6487, %6498
  %6500 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6489
  %6501 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6489
  %6502 = load <8 x i1>, ptr %6500, align 1
  %6503 = load <8 x i1>, ptr %6501, align 1
  %6504 = or <8 x i1> %6503, %convergence.cascade.flow1195
  %6505 = load <8 x i1>, ptr %live.mask, align 1
  %6506 = and <8 x i1> %6502, %6505
  %6507 = icmp eq <8 x i1> %6504, %6506
  %6508 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6507)
  %6509 = and i1 %6499, %6508
  %6510 = select i1 %6509, <8 x i1> zeroinitializer, <8 x i1> %6504
  %6511 = select i1 %6499, <8 x i1> %6510, <8 x i1> %6503
  store <8 x i1> %6511, ptr %6501, align 1
  %6512 = select i1 %6509, <8 x i1> zeroinitializer, <8 x i1> %6502
  store <8 x i1> %6512, ptr %6500, align 1
  %6513 = trunc i32 %6489 to i8
  %6514 = shl i8 1, %6513
  %6515 = xor i8 %6514, -1
  %6516 = and i8 %6490, %6515
  %6517 = select i1 %6509, i8 %6516, i8 %6490
  store i8 %6517, ptr %frame.active, align 1
  %.splatinsert1199 = insertelement <8 x i1> poison, i1 %6499, i64 0
  %.splat1200 = shufflevector <8 x i1> %.splatinsert1199, <8 x i1> poison, <8 x i32> zeroinitializer
  %6518 = and <8 x i1> %convergence.cascade.flow1195, %.splat1200
  %6519 = load <8 x i1>, ptr %runnable.mask, align 1
  %6520 = xor <8 x i1> %6518, splat (i1 true)
  %6521 = and <8 x i1> %6519, %6520
  store <8 x i1> %6521, ptr %runnable.mask, align 1
  %.splatinsert1201 = insertelement <8 x i1> poison, i1 %6509, i64 0
  %.splat1202 = shufflevector <8 x i1> %.splatinsert1201, <8 x i1> poison, <8 x i32> zeroinitializer
  %6522 = select <8 x i1> %.splat1202, <8 x i1> %6504, <8 x i1> zeroinitializer
  %6523 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6524 = extractelement <8 x i32> %6523, i32 %6489
  %6525 = select i1 %6509, i32 %6524, i32 %6485
  store i32 %6525, ptr %current.token, align 4
  %.splatinsert1203 = insertelement <8 x i1> poison, i1 %6499, i64 0
  %.splat1204 = shufflevector <8 x i1> %.splatinsert1203, <8 x i1> poison, <8 x i32> zeroinitializer
  %6526 = select <8 x i1> %.splat1204, <8 x i1> %6522, <8 x i1> %convergence.cascade.flow1195
  %6527 = add i32 %convergence.cascade.depth1196, 1
  %6528 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6526)
  %6529 = icmp ult i32 %6527, 8
  %6530 = and i1 %6528, %6529
  %6531 = and i1 %6499, %6530
  %convergence.parent.token1205 = load i32, ptr %current.token, align 4
  %convergence.parent.present1206 = icmp ne i32 %convergence.parent.token1205, 0
  %6532 = and i1 %6531, %convergence.parent.present1206
  br i1 %6532, label %convergence.cascade1191, label %convergence.cascade.exit1192

convergence.cascade.exit1192:                     ; preds = %convergence.cascade1191, %schedule.80
  %convergence.cascade.result1207 = phi <8 x i1> [ %1430, %schedule.80 ], [ %6526, %convergence.cascade1191 ]
  %6533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1207)
  br i1 %6533, label %convergence.target.80.ready, label %scheduler.loop

convergence.target.80.ready:                      ; preds = %convergence.cascade.exit1192
  %6534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1207)
  %6535 = bitcast <8 x i1> %convergence.cascade.result1207 to i8
  %6536 = call i8 @llvm.cttz.i8(i8 %6535, i1 false)
  %6537 = zext i8 %6536 to i32
  %6538 = select i1 %6534, i32 %6537, i32 0
  %6539 = load <8 x i64>, ptr %.slot175, align 64
  %6540 = select <8 x i1> %convergence.cascade.result1207, <8 x i64> zeroinitializer, <8 x i64> %6539
  store <8 x i64> %6540, ptr %.slot175, align 64
  %6541 = load <8 x float>, ptr %.slot176, align 32
  %6542 = select <8 x i1> %convergence.cascade.result1207, <8 x float> zeroinitializer, <8 x float> %6541
  store <8 x float> %6542, ptr %.slot176, align 32
  store <8 x i1> %convergence.cascade.result1207, ptr %current.mask, align 1
  %6543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1207)
  br i1 %6543, label %schedule.81, label %scheduler.loop

varying.divergent1209:                            ; preds = %schedule.81
  %6544 = load i32, ptr %current.token, align 4
  %6545 = icmp ne i32 %6544, 0
  %6546 = sub i32 %6544, 1
  %6547 = select i1 %6545, i32 %6546, i32 0
  %6548 = load i8, ptr %frame.active, align 1
  %6549 = trunc i32 %6547 to i8
  %6550 = shl i8 1, %6549
  %6551 = and i8 %6548, %6550
  %6552 = icmp ne i8 %6551, 0
  %6553 = load <8 x i32>, ptr %frame.static.id, align 32
  %6554 = extractelement <8 x i32> %6553, i32 %6547
  %6555 = icmp eq i32 %6554, 28
  %6556 = and i1 %6552, %6555
  %6557 = and i1 %6545, %6556
  %6558 = xor i1 %6557, true
  %6559 = and i1 true, %6558
  %6560 = xor i8 %6548, -1
  %6561 = icmp ne i8 %6560, 0
  %6562 = xor i1 %6561, true
  %6563 = and i1 %6559, %6562
  br i1 %6563, label %convergence.overflow.trap1211, label %convergence.overflow.resume1212

varying.coherent1210:                             ; preds = %schedule.81
  br i1 %1441, label %varying.coherent.true1215, label %varying.coherent.false1216

convergence.overflow.trap1211:                    ; preds = %varying.divergent1209
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1212:                  ; preds = %varying.divergent1209
  %6564 = call i8 @llvm.cttz.i8(i8 %6560, i1 false)
  %6565 = zext i8 %6564 to i32
  %6566 = select i1 %6561, i32 %6565, i32 0
  %6567 = trunc i32 %6566 to i8
  %6568 = shl i8 1, %6567
  %6569 = or i8 %6548, %6568
  %6570 = select i1 %6559, i8 %6569, i8 %6548
  store i8 %6570, ptr %frame.active, align 1
  %6571 = load <8 x i32>, ptr %frame.static.id, align 32
  %6572 = extractelement <8 x i32> %6571, i32 %6566
  %6573 = select i1 %6559, i32 28, i32 %6572
  %6574 = load <8 x i32>, ptr %frame.static.id, align 32
  %6575 = insertelement <8 x i32> %6574, i32 %6573, i32 %6566
  store <8 x i32> %6575, ptr %frame.static.id, align 32
  %6576 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6577 = extractelement <8 x i32> %6576, i32 %6566
  %6578 = select i1 %6559, i32 %6544, i32 %6577
  %6579 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6580 = insertelement <8 x i32> %6579, i32 %6578, i32 %6566
  store <8 x i32> %6580, ptr %frame.parent.token, align 32
  %6581 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6566
  %6582 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6566
  %6583 = load <8 x i1>, ptr %6581, align 1
  %6584 = load <8 x i1>, ptr %6582, align 1
  %6585 = select i1 %6559, <8 x i1> %1431, <8 x i1> %6583
  store <8 x i1> %6585, ptr %6581, align 1
  %6586 = select i1 %6559, <8 x i1> zeroinitializer, <8 x i1> %6584
  store <8 x i1> %6586, ptr %6582, align 1
  %6587 = add i32 %6566, 1
  %6588 = select i1 %6557, i32 %6544, i32 %6587
  %6589 = select i1 true, i32 %6588, i32 %6544
  store i32 %6589, ptr %current.token, align 4
  %6590 = load i32, ptr %current.token, align 4
  %6591 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1438)
  %6592 = load i32, ptr %ready.count, align 4
  %6593 = icmp uge i32 %6592, 8
  %6594 = and i1 %6591, %6593
  br i1 %6594, label %ready.overflow.trap1213, label %ready.overflow.resume1214

ready.overflow.trap1213:                          ; preds = %convergence.overflow.resume1212
  call void @llvm.trap()
  unreachable

ready.overflow.resume1214:                        ; preds = %convergence.overflow.resume1212
  %6595 = select i1 %6591, i32 %6592, i32 0
  %6596 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6595
  %6597 = load <8 x i1>, ptr %6596, align 1
  %6598 = select i1 %6591, <8 x i1> %1438, <8 x i1> %6597
  store <8 x i1> %6598, ptr %6596, align 1
  %6599 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6595
  %6600 = load i32, ptr %6599, align 4
  %6601 = select i1 %6591, i32 82, i32 %6600
  store i32 %6601, ptr %6599, align 4
  %6602 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6595
  %6603 = load i32, ptr %6602, align 4
  %6604 = select i1 %6591, i32 %6590, i32 %6603
  store i32 %6604, ptr %6602, align 4
  %6605 = add i32 %6592, 1
  %6606 = select i1 %6591, i32 %6605, i32 %6592
  store i32 %6606, ptr %ready.count, align 4
  %6607 = load <8 x i1>, ptr %runnable.mask, align 1
  %6608 = or <8 x i1> %6607, %1438
  store <8 x i1> %6608, ptr %runnable.mask, align 1
  store <8 x i1> %1440, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1215:                        ; preds = %varying.coherent1210
  store <8 x i1> %1431, ptr %current.mask, align 1
  %6609 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1431)
  br i1 %6609, label %schedule.82, label %scheduler.loop

varying.coherent.false1216:                       ; preds = %varying.coherent1210
  store <8 x i1> %1431, ptr %current.mask, align 1
  %6610 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1431)
  br i1 %6610, label %schedule.83, label %scheduler.loop

convergence.cascade1221:                          ; preds = %convergence.cascade1221, %schedule.83
  %convergence.cascade.flow1225 = phi <8 x i1> [ %1471, %schedule.83 ], [ %6653, %convergence.cascade1221 ]
  %convergence.cascade.depth1226 = phi i32 [ 0, %schedule.83 ], [ %6654, %convergence.cascade1221 ]
  %6611 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1225)
  %6612 = load i32, ptr %current.token, align 4
  %6613 = icmp ne i32 %6612, 0
  %6614 = and i1 %6611, %6613
  %6615 = sub i32 %6612, 1
  %6616 = select i1 %6614, i32 %6615, i32 0
  %6617 = load i8, ptr %frame.active, align 1
  %6618 = trunc i32 %6616 to i8
  %6619 = shl i8 1, %6618
  %6620 = and i8 %6617, %6619
  %6621 = icmp ne i8 %6620, 0
  %6622 = load <8 x i32>, ptr %frame.static.id, align 32
  %6623 = extractelement <8 x i32> %6622, i32 %6616
  %convergence.target.pointer1227 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6623
  %convergence.dynamic.target1228 = load i32, ptr %convergence.target.pointer1227, align 4
  %6624 = icmp eq i32 %convergence.dynamic.target1228, 83
  %6625 = and i1 %6621, %6624
  %6626 = and i1 %6614, %6625
  %6627 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6616
  %6628 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6616
  %6629 = load <8 x i1>, ptr %6627, align 1
  %6630 = load <8 x i1>, ptr %6628, align 1
  %6631 = or <8 x i1> %6630, %convergence.cascade.flow1225
  %6632 = load <8 x i1>, ptr %live.mask, align 1
  %6633 = and <8 x i1> %6629, %6632
  %6634 = icmp eq <8 x i1> %6631, %6633
  %6635 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6634)
  %6636 = and i1 %6626, %6635
  %6637 = select i1 %6636, <8 x i1> zeroinitializer, <8 x i1> %6631
  %6638 = select i1 %6626, <8 x i1> %6637, <8 x i1> %6630
  store <8 x i1> %6638, ptr %6628, align 1
  %6639 = select i1 %6636, <8 x i1> zeroinitializer, <8 x i1> %6629
  store <8 x i1> %6639, ptr %6627, align 1
  %6640 = trunc i32 %6616 to i8
  %6641 = shl i8 1, %6640
  %6642 = xor i8 %6641, -1
  %6643 = and i8 %6617, %6642
  %6644 = select i1 %6636, i8 %6643, i8 %6617
  store i8 %6644, ptr %frame.active, align 1
  %.splatinsert1229 = insertelement <8 x i1> poison, i1 %6626, i64 0
  %.splat1230 = shufflevector <8 x i1> %.splatinsert1229, <8 x i1> poison, <8 x i32> zeroinitializer
  %6645 = and <8 x i1> %convergence.cascade.flow1225, %.splat1230
  %6646 = load <8 x i1>, ptr %runnable.mask, align 1
  %6647 = xor <8 x i1> %6645, splat (i1 true)
  %6648 = and <8 x i1> %6646, %6647
  store <8 x i1> %6648, ptr %runnable.mask, align 1
  %.splatinsert1231 = insertelement <8 x i1> poison, i1 %6636, i64 0
  %.splat1232 = shufflevector <8 x i1> %.splatinsert1231, <8 x i1> poison, <8 x i32> zeroinitializer
  %6649 = select <8 x i1> %.splat1232, <8 x i1> %6631, <8 x i1> zeroinitializer
  %6650 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6651 = extractelement <8 x i32> %6650, i32 %6616
  %6652 = select i1 %6636, i32 %6651, i32 %6612
  store i32 %6652, ptr %current.token, align 4
  %.splatinsert1233 = insertelement <8 x i1> poison, i1 %6626, i64 0
  %.splat1234 = shufflevector <8 x i1> %.splatinsert1233, <8 x i1> poison, <8 x i32> zeroinitializer
  %6653 = select <8 x i1> %.splat1234, <8 x i1> %6649, <8 x i1> %convergence.cascade.flow1225
  %6654 = add i32 %convergence.cascade.depth1226, 1
  %6655 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6653)
  %6656 = icmp ult i32 %6654, 8
  %6657 = and i1 %6655, %6656
  %6658 = and i1 %6626, %6657
  %convergence.parent.token1235 = load i32, ptr %current.token, align 4
  %convergence.parent.present1236 = icmp ne i32 %convergence.parent.token1235, 0
  %6659 = and i1 %6658, %convergence.parent.present1236
  br i1 %6659, label %convergence.cascade1221, label %convergence.cascade.exit1222

convergence.cascade.exit1222:                     ; preds = %convergence.cascade1221, %schedule.83
  %convergence.cascade.result1237 = phi <8 x i1> [ %1471, %schedule.83 ], [ %6653, %convergence.cascade1221 ]
  %6660 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1237)
  br i1 %6660, label %convergence.target.83.ready, label %scheduler.loop

convergence.target.83.ready:                      ; preds = %convergence.cascade.exit1222
  %6661 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1237)
  %6662 = bitcast <8 x i1> %convergence.cascade.result1237 to i8
  %6663 = call i8 @llvm.cttz.i8(i8 %6662, i1 false)
  %6664 = zext i8 %6663 to i32
  %6665 = select i1 %6661, i32 %6664, i32 0
  %6666 = load <8 x i64>, ptr %.slot177, align 64
  %6667 = select <8 x i1> %convergence.cascade.result1237, <8 x i64> zeroinitializer, <8 x i64> %6666
  store <8 x i64> %6667, ptr %.slot177, align 64
  %6668 = load <8 x float>, ptr %.slot178, align 32
  %6669 = select <8 x i1> %convergence.cascade.result1237, <8 x float> zeroinitializer, <8 x float> %6668
  store <8 x float> %6669, ptr %.slot178, align 32
  store <8 x i1> %convergence.cascade.result1237, ptr %current.mask, align 1
  %6670 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1237)
  br i1 %6670, label %schedule.84, label %scheduler.loop

varying.divergent1239:                            ; preds = %schedule.84
  %6671 = load i32, ptr %current.token, align 4
  %6672 = icmp ne i32 %6671, 0
  %6673 = sub i32 %6671, 1
  %6674 = select i1 %6672, i32 %6673, i32 0
  %6675 = load i8, ptr %frame.active, align 1
  %6676 = trunc i32 %6674 to i8
  %6677 = shl i8 1, %6676
  %6678 = and i8 %6675, %6677
  %6679 = icmp ne i8 %6678, 0
  %6680 = load <8 x i32>, ptr %frame.static.id, align 32
  %6681 = extractelement <8 x i32> %6680, i32 %6674
  %6682 = icmp eq i32 %6681, 29
  %6683 = and i1 %6679, %6682
  %6684 = and i1 %6672, %6683
  %6685 = xor i1 %6684, true
  %6686 = and i1 true, %6685
  %6687 = xor i8 %6675, -1
  %6688 = icmp ne i8 %6687, 0
  %6689 = xor i1 %6688, true
  %6690 = and i1 %6686, %6689
  br i1 %6690, label %convergence.overflow.trap1241, label %convergence.overflow.resume1242

varying.coherent1240:                             ; preds = %schedule.84
  br i1 %1482, label %varying.coherent.true1245, label %varying.coherent.false1246

convergence.overflow.trap1241:                    ; preds = %varying.divergent1239
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1242:                  ; preds = %varying.divergent1239
  %6691 = call i8 @llvm.cttz.i8(i8 %6687, i1 false)
  %6692 = zext i8 %6691 to i32
  %6693 = select i1 %6688, i32 %6692, i32 0
  %6694 = trunc i32 %6693 to i8
  %6695 = shl i8 1, %6694
  %6696 = or i8 %6675, %6695
  %6697 = select i1 %6686, i8 %6696, i8 %6675
  store i8 %6697, ptr %frame.active, align 1
  %6698 = load <8 x i32>, ptr %frame.static.id, align 32
  %6699 = extractelement <8 x i32> %6698, i32 %6693
  %6700 = select i1 %6686, i32 29, i32 %6699
  %6701 = load <8 x i32>, ptr %frame.static.id, align 32
  %6702 = insertelement <8 x i32> %6701, i32 %6700, i32 %6693
  store <8 x i32> %6702, ptr %frame.static.id, align 32
  %6703 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6704 = extractelement <8 x i32> %6703, i32 %6693
  %6705 = select i1 %6686, i32 %6671, i32 %6704
  %6706 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6707 = insertelement <8 x i32> %6706, i32 %6705, i32 %6693
  store <8 x i32> %6707, ptr %frame.parent.token, align 32
  %6708 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6693
  %6709 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6693
  %6710 = load <8 x i1>, ptr %6708, align 1
  %6711 = load <8 x i1>, ptr %6709, align 1
  %6712 = select i1 %6686, <8 x i1> %1472, <8 x i1> %6710
  store <8 x i1> %6712, ptr %6708, align 1
  %6713 = select i1 %6686, <8 x i1> zeroinitializer, <8 x i1> %6711
  store <8 x i1> %6713, ptr %6709, align 1
  %6714 = add i32 %6693, 1
  %6715 = select i1 %6684, i32 %6671, i32 %6714
  %6716 = select i1 true, i32 %6715, i32 %6671
  store i32 %6716, ptr %current.token, align 4
  %6717 = load i32, ptr %current.token, align 4
  %6718 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1479)
  %6719 = load i32, ptr %ready.count, align 4
  %6720 = icmp uge i32 %6719, 8
  %6721 = and i1 %6718, %6720
  br i1 %6721, label %ready.overflow.trap1243, label %ready.overflow.resume1244

ready.overflow.trap1243:                          ; preds = %convergence.overflow.resume1242
  call void @llvm.trap()
  unreachable

ready.overflow.resume1244:                        ; preds = %convergence.overflow.resume1242
  %6722 = select i1 %6718, i32 %6719, i32 0
  %6723 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6722
  %6724 = load <8 x i1>, ptr %6723, align 1
  %6725 = select i1 %6718, <8 x i1> %1479, <8 x i1> %6724
  store <8 x i1> %6725, ptr %6723, align 1
  %6726 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6722
  %6727 = load i32, ptr %6726, align 4
  %6728 = select i1 %6718, i32 85, i32 %6727
  store i32 %6728, ptr %6726, align 4
  %6729 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6722
  %6730 = load i32, ptr %6729, align 4
  %6731 = select i1 %6718, i32 %6717, i32 %6730
  store i32 %6731, ptr %6729, align 4
  %6732 = add i32 %6719, 1
  %6733 = select i1 %6718, i32 %6732, i32 %6719
  store i32 %6733, ptr %ready.count, align 4
  %6734 = load <8 x i1>, ptr %runnable.mask, align 1
  %6735 = or <8 x i1> %6734, %1479
  store <8 x i1> %6735, ptr %runnable.mask, align 1
  store <8 x i1> %1481, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1245:                        ; preds = %varying.coherent1240
  store <8 x i1> %1472, ptr %current.mask, align 1
  %6736 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1472)
  br i1 %6736, label %schedule.85, label %scheduler.loop

varying.coherent.false1246:                       ; preds = %varying.coherent1240
  store <8 x i1> %1472, ptr %current.mask, align 1
  %6737 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1472)
  br i1 %6737, label %schedule.86, label %scheduler.loop

convergence.cascade1251:                          ; preds = %convergence.cascade1251, %schedule.86
  %convergence.cascade.flow1255 = phi <8 x i1> [ %1512, %schedule.86 ], [ %6780, %convergence.cascade1251 ]
  %convergence.cascade.depth1256 = phi i32 [ 0, %schedule.86 ], [ %6781, %convergence.cascade1251 ]
  %6738 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1255)
  %6739 = load i32, ptr %current.token, align 4
  %6740 = icmp ne i32 %6739, 0
  %6741 = and i1 %6738, %6740
  %6742 = sub i32 %6739, 1
  %6743 = select i1 %6741, i32 %6742, i32 0
  %6744 = load i8, ptr %frame.active, align 1
  %6745 = trunc i32 %6743 to i8
  %6746 = shl i8 1, %6745
  %6747 = and i8 %6744, %6746
  %6748 = icmp ne i8 %6747, 0
  %6749 = load <8 x i32>, ptr %frame.static.id, align 32
  %6750 = extractelement <8 x i32> %6749, i32 %6743
  %convergence.target.pointer1257 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %6750
  %convergence.dynamic.target1258 = load i32, ptr %convergence.target.pointer1257, align 4
  %6751 = icmp eq i32 %convergence.dynamic.target1258, 86
  %6752 = and i1 %6748, %6751
  %6753 = and i1 %6741, %6752
  %6754 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6743
  %6755 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6743
  %6756 = load <8 x i1>, ptr %6754, align 1
  %6757 = load <8 x i1>, ptr %6755, align 1
  %6758 = or <8 x i1> %6757, %convergence.cascade.flow1255
  %6759 = load <8 x i1>, ptr %live.mask, align 1
  %6760 = and <8 x i1> %6756, %6759
  %6761 = icmp eq <8 x i1> %6758, %6760
  %6762 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6761)
  %6763 = and i1 %6753, %6762
  %6764 = select i1 %6763, <8 x i1> zeroinitializer, <8 x i1> %6758
  %6765 = select i1 %6753, <8 x i1> %6764, <8 x i1> %6757
  store <8 x i1> %6765, ptr %6755, align 1
  %6766 = select i1 %6763, <8 x i1> zeroinitializer, <8 x i1> %6756
  store <8 x i1> %6766, ptr %6754, align 1
  %6767 = trunc i32 %6743 to i8
  %6768 = shl i8 1, %6767
  %6769 = xor i8 %6768, -1
  %6770 = and i8 %6744, %6769
  %6771 = select i1 %6763, i8 %6770, i8 %6744
  store i8 %6771, ptr %frame.active, align 1
  %.splatinsert1259 = insertelement <8 x i1> poison, i1 %6753, i64 0
  %.splat1260 = shufflevector <8 x i1> %.splatinsert1259, <8 x i1> poison, <8 x i32> zeroinitializer
  %6772 = and <8 x i1> %convergence.cascade.flow1255, %.splat1260
  %6773 = load <8 x i1>, ptr %runnable.mask, align 1
  %6774 = xor <8 x i1> %6772, splat (i1 true)
  %6775 = and <8 x i1> %6773, %6774
  store <8 x i1> %6775, ptr %runnable.mask, align 1
  %.splatinsert1261 = insertelement <8 x i1> poison, i1 %6763, i64 0
  %.splat1262 = shufflevector <8 x i1> %.splatinsert1261, <8 x i1> poison, <8 x i32> zeroinitializer
  %6776 = select <8 x i1> %.splat1262, <8 x i1> %6758, <8 x i1> zeroinitializer
  %6777 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6778 = extractelement <8 x i32> %6777, i32 %6743
  %6779 = select i1 %6763, i32 %6778, i32 %6739
  store i32 %6779, ptr %current.token, align 4
  %.splatinsert1263 = insertelement <8 x i1> poison, i1 %6753, i64 0
  %.splat1264 = shufflevector <8 x i1> %.splatinsert1263, <8 x i1> poison, <8 x i32> zeroinitializer
  %6780 = select <8 x i1> %.splat1264, <8 x i1> %6776, <8 x i1> %convergence.cascade.flow1255
  %6781 = add i32 %convergence.cascade.depth1256, 1
  %6782 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6780)
  %6783 = icmp ult i32 %6781, 8
  %6784 = and i1 %6782, %6783
  %6785 = and i1 %6753, %6784
  %convergence.parent.token1265 = load i32, ptr %current.token, align 4
  %convergence.parent.present1266 = icmp ne i32 %convergence.parent.token1265, 0
  %6786 = and i1 %6785, %convergence.parent.present1266
  br i1 %6786, label %convergence.cascade1251, label %convergence.cascade.exit1252

convergence.cascade.exit1252:                     ; preds = %convergence.cascade1251, %schedule.86
  %convergence.cascade.result1267 = phi <8 x i1> [ %1512, %schedule.86 ], [ %6780, %convergence.cascade1251 ]
  %6787 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1267)
  br i1 %6787, label %convergence.target.86.ready, label %scheduler.loop

convergence.target.86.ready:                      ; preds = %convergence.cascade.exit1252
  %6788 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1267)
  %6789 = bitcast <8 x i1> %convergence.cascade.result1267 to i8
  %6790 = call i8 @llvm.cttz.i8(i8 %6789, i1 false)
  %6791 = zext i8 %6790 to i32
  %6792 = select i1 %6788, i32 %6791, i32 0
  %.spill.load1268 = load <8 x float>, ptr %.spill155, align 32
  %.state1269 = load <8 x float>, ptr %.slot164, align 32
  %6793 = fadd <8 x float> %.spill.load1268, %.state1269
  %6794 = load <8 x float>, ptr %.spill179, align 32
  %6795 = select <8 x i1> %convergence.cascade.result1267, <8 x float> %6793, <8 x float> %6794
  store <8 x float> %6795, ptr %.spill179, align 32
  %.spill.load1270 = load <8 x float>, ptr %.spill156, align 32
  %.state1271 = load <8 x float>, ptr %.slot166, align 32
  %6796 = fadd <8 x float> %.spill.load1270, %.state1271
  %6797 = load <8 x float>, ptr %.spill180, align 32
  %6798 = select <8 x i1> %convergence.cascade.result1267, <8 x float> %6796, <8 x float> %6797
  store <8 x float> %6798, ptr %.spill180, align 32
  %.spill.load1272 = load <8 x float>, ptr %.spill157, align 32
  %.state1273 = load <8 x float>, ptr %.slot168, align 32
  %6799 = fadd <8 x float> %.spill.load1272, %.state1273
  %6800 = load <8 x float>, ptr %.spill181, align 32
  %6801 = select <8 x i1> %convergence.cascade.result1267, <8 x float> %6799, <8 x float> %6800
  store <8 x float> %6801, ptr %.spill181, align 32
  %.spill.load1274 = load <8 x float>, ptr %.spill158, align 32
  %.state1275 = load <8 x float>, ptr %.slot170, align 32
  %6802 = fadd <8 x float> %.spill.load1274, %.state1275
  %6803 = load <8 x float>, ptr %.spill182, align 32
  %6804 = select <8 x i1> %convergence.cascade.result1267, <8 x float> %6802, <8 x float> %6803
  store <8 x float> %6804, ptr %.spill182, align 32
  %.spill.load1276 = load <8 x float>, ptr %.spill159, align 32
  %.state1277 = load <8 x float>, ptr %.slot172, align 32
  %6805 = fadd <8 x float> %.spill.load1276, %.state1277
  %6806 = load <8 x float>, ptr %.spill183, align 32
  %6807 = select <8 x i1> %convergence.cascade.result1267, <8 x float> %6805, <8 x float> %6806
  store <8 x float> %6807, ptr %.spill183, align 32
  %.spill.load1278 = load <8 x float>, ptr %.spill160, align 32
  %.state1279 = load <8 x float>, ptr %.slot174, align 32
  %6808 = fadd <8 x float> %.spill.load1278, %.state1279
  %6809 = load <8 x float>, ptr %.spill184, align 32
  %6810 = select <8 x i1> %convergence.cascade.result1267, <8 x float> %6808, <8 x float> %6809
  store <8 x float> %6810, ptr %.spill184, align 32
  %.spill.load1280 = load <8 x float>, ptr %.spill161, align 32
  %.state1281 = load <8 x float>, ptr %.slot176, align 32
  %6811 = fadd <8 x float> %.spill.load1280, %.state1281
  %6812 = load <8 x float>, ptr %.spill185, align 32
  %6813 = select <8 x i1> %convergence.cascade.result1267, <8 x float> %6811, <8 x float> %6812
  store <8 x float> %6813, ptr %.spill185, align 32
  %.spill.load1282 = load <8 x float>, ptr %.spill162, align 32
  %.state1283 = load <8 x float>, ptr %.slot178, align 32
  %6814 = fadd <8 x float> %.spill.load1282, %.state1283
  %6815 = load <8 x float>, ptr %.spill186, align 32
  %6816 = select <8 x i1> %convergence.cascade.result1267, <8 x float> %6814, <8 x float> %6815
  store <8 x float> %6816, ptr %.spill186, align 32
  %6817 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill187, align 64
  %6818 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %6819 = extractvalue { <8 x ptr>, <8 x i64> } %6817, 0
  %6820 = select <8 x i1> %convergence.cascade.result1267, <8 x ptr> %6818, <8 x ptr> %6819
  %6821 = extractvalue { <8 x ptr>, <8 x i64> } %44, 1
  %6822 = extractvalue { <8 x ptr>, <8 x i64> } %6817, 1
  %6823 = select <8 x i1> %convergence.cascade.result1267, <8 x i64> %6821, <8 x i64> %6822
  %6824 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6820, 0
  %6825 = insertvalue { <8 x ptr>, <8 x i64> } %6824, <8 x i64> %6823, 1
  store { <8 x ptr>, <8 x i64> } %6825, ptr %tile_snapshot.spill187, align 64
  %6826 = load <8 x i64>, ptr %.slot188, align 64
  %6827 = select <8 x i1> %convergence.cascade.result1267, <8 x i64> zeroinitializer, <8 x i64> %6826
  store <8 x i64> %6827, ptr %.slot188, align 64
  store <8 x i1> %convergence.cascade.result1267, ptr %current.mask, align 1
  %6828 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1267)
  br i1 %6828, label %schedule.87, label %scheduler.loop

varying.divergent1285:                            ; preds = %schedule.87
  %6829 = load i32, ptr %current.token, align 4
  %6830 = icmp ne i32 %6829, 0
  %6831 = sub i32 %6829, 1
  %6832 = select i1 %6830, i32 %6831, i32 0
  %6833 = load i8, ptr %frame.active, align 1
  %6834 = trunc i32 %6832 to i8
  %6835 = shl i8 1, %6834
  %6836 = and i8 %6833, %6835
  %6837 = icmp ne i8 %6836, 0
  %6838 = load <8 x i32>, ptr %frame.static.id, align 32
  %6839 = extractelement <8 x i32> %6838, i32 %6832
  %6840 = icmp eq i32 %6839, 30
  %6841 = and i1 %6837, %6840
  %6842 = and i1 %6830, %6841
  %6843 = xor i1 %6842, true
  %6844 = and i1 true, %6843
  %6845 = xor i8 %6833, -1
  %6846 = icmp ne i8 %6845, 0
  %6847 = xor i1 %6846, true
  %6848 = and i1 %6844, %6847
  br i1 %6848, label %convergence.overflow.trap1287, label %convergence.overflow.resume1288

varying.coherent1286:                             ; preds = %schedule.87
  br i1 %1523, label %varying.coherent.true1291, label %varying.coherent.false1292

convergence.overflow.trap1287:                    ; preds = %varying.divergent1285
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1288:                  ; preds = %varying.divergent1285
  %6849 = call i8 @llvm.cttz.i8(i8 %6845, i1 false)
  %6850 = zext i8 %6849 to i32
  %6851 = select i1 %6846, i32 %6850, i32 0
  %6852 = trunc i32 %6851 to i8
  %6853 = shl i8 1, %6852
  %6854 = or i8 %6833, %6853
  %6855 = select i1 %6844, i8 %6854, i8 %6833
  store i8 %6855, ptr %frame.active, align 1
  %6856 = load <8 x i32>, ptr %frame.static.id, align 32
  %6857 = extractelement <8 x i32> %6856, i32 %6851
  %6858 = select i1 %6844, i32 30, i32 %6857
  %6859 = load <8 x i32>, ptr %frame.static.id, align 32
  %6860 = insertelement <8 x i32> %6859, i32 %6858, i32 %6851
  store <8 x i32> %6860, ptr %frame.static.id, align 32
  %6861 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6862 = extractelement <8 x i32> %6861, i32 %6851
  %6863 = select i1 %6844, i32 %6829, i32 %6862
  %6864 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6865 = insertelement <8 x i32> %6864, i32 %6863, i32 %6851
  store <8 x i32> %6865, ptr %frame.parent.token, align 32
  %6866 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6851
  %6867 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6851
  %6868 = load <8 x i1>, ptr %6866, align 1
  %6869 = load <8 x i1>, ptr %6867, align 1
  %6870 = select i1 %6844, <8 x i1> %1513, <8 x i1> %6868
  store <8 x i1> %6870, ptr %6866, align 1
  %6871 = select i1 %6844, <8 x i1> zeroinitializer, <8 x i1> %6869
  store <8 x i1> %6871, ptr %6867, align 1
  %6872 = add i32 %6851, 1
  %6873 = select i1 %6842, i32 %6829, i32 %6872
  %6874 = select i1 true, i32 %6873, i32 %6829
  store i32 %6874, ptr %current.token, align 4
  %6875 = load i32, ptr %current.token, align 4
  %6876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1520)
  %6877 = load i32, ptr %ready.count, align 4
  %6878 = icmp uge i32 %6877, 8
  %6879 = and i1 %6876, %6878
  br i1 %6879, label %ready.overflow.trap1289, label %ready.overflow.resume1290

ready.overflow.trap1289:                          ; preds = %convergence.overflow.resume1288
  call void @llvm.trap()
  unreachable

ready.overflow.resume1290:                        ; preds = %convergence.overflow.resume1288
  %6880 = select i1 %6876, i32 %6877, i32 0
  %6881 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6880
  %6882 = load <8 x i1>, ptr %6881, align 1
  %6883 = select i1 %6876, <8 x i1> %1520, <8 x i1> %6882
  store <8 x i1> %6883, ptr %6881, align 1
  %6884 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6880
  %6885 = load i32, ptr %6884, align 4
  %6886 = select i1 %6876, i32 88, i32 %6885
  store i32 %6886, ptr %6884, align 4
  %6887 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6880
  %6888 = load i32, ptr %6887, align 4
  %6889 = select i1 %6876, i32 %6875, i32 %6888
  store i32 %6889, ptr %6887, align 4
  %6890 = add i32 %6877, 1
  %6891 = select i1 %6876, i32 %6890, i32 %6877
  store i32 %6891, ptr %ready.count, align 4
  %6892 = load <8 x i1>, ptr %runnable.mask, align 1
  %6893 = or <8 x i1> %6892, %1520
  store <8 x i1> %6893, ptr %runnable.mask, align 1
  store <8 x i1> %1522, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1291:                        ; preds = %varying.coherent1286
  store <8 x i1> %1513, ptr %current.mask, align 1
  %6894 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1513)
  br i1 %6894, label %schedule.88, label %scheduler.loop

varying.coherent.false1292:                       ; preds = %varying.coherent1286
  store <8 x i1> %1513, ptr %current.mask, align 1
  %6895 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1513)
  br i1 %6895, label %schedule.95, label %scheduler.loop

varying.divergent1295:                            ; preds = %schedule.89
  %6896 = load i32, ptr %current.token, align 4
  %6897 = icmp ne i32 %6896, 0
  %6898 = sub i32 %6896, 1
  %6899 = select i1 %6897, i32 %6898, i32 0
  %6900 = load i8, ptr %frame.active, align 1
  %6901 = trunc i32 %6899 to i8
  %6902 = shl i8 1, %6901
  %6903 = and i8 %6900, %6902
  %6904 = icmp ne i8 %6903, 0
  %6905 = load <8 x i32>, ptr %frame.static.id, align 32
  %6906 = extractelement <8 x i32> %6905, i32 %6899
  %6907 = icmp eq i32 %6906, 31
  %6908 = and i1 %6904, %6907
  %6909 = and i1 %6897, %6908
  %6910 = xor i1 %6909, true
  %6911 = and i1 true, %6910
  %6912 = xor i8 %6900, -1
  %6913 = icmp ne i8 %6912, 0
  %6914 = xor i1 %6913, true
  %6915 = and i1 %6911, %6914
  br i1 %6915, label %convergence.overflow.trap1297, label %convergence.overflow.resume1298

varying.coherent1296:                             ; preds = %schedule.89
  br i1 %1548, label %varying.coherent.true1301, label %varying.coherent.false1302

convergence.overflow.trap1297:                    ; preds = %varying.divergent1295
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1298:                  ; preds = %varying.divergent1295
  %6916 = call i8 @llvm.cttz.i8(i8 %6912, i1 false)
  %6917 = zext i8 %6916 to i32
  %6918 = select i1 %6913, i32 %6917, i32 0
  %6919 = trunc i32 %6918 to i8
  %6920 = shl i8 1, %6919
  %6921 = or i8 %6900, %6920
  %6922 = select i1 %6911, i8 %6921, i8 %6900
  store i8 %6922, ptr %frame.active, align 1
  %6923 = load <8 x i32>, ptr %frame.static.id, align 32
  %6924 = extractelement <8 x i32> %6923, i32 %6918
  %6925 = select i1 %6911, i32 31, i32 %6924
  %6926 = load <8 x i32>, ptr %frame.static.id, align 32
  %6927 = insertelement <8 x i32> %6926, i32 %6925, i32 %6918
  store <8 x i32> %6927, ptr %frame.static.id, align 32
  %6928 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6929 = extractelement <8 x i32> %6928, i32 %6918
  %6930 = select i1 %6911, i32 %6896, i32 %6929
  %6931 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6932 = insertelement <8 x i32> %6931, i32 %6930, i32 %6918
  store <8 x i32> %6932, ptr %frame.parent.token, align 32
  %6933 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6918
  %6934 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6918
  %6935 = load <8 x i1>, ptr %6933, align 1
  %6936 = load <8 x i1>, ptr %6934, align 1
  %6937 = select i1 %6911, <8 x i1> %1538, <8 x i1> %6935
  store <8 x i1> %6937, ptr %6933, align 1
  %6938 = select i1 %6911, <8 x i1> zeroinitializer, <8 x i1> %6936
  store <8 x i1> %6938, ptr %6934, align 1
  %6939 = add i32 %6918, 1
  %6940 = select i1 %6909, i32 %6896, i32 %6939
  %6941 = select i1 true, i32 %6940, i32 %6896
  store i32 %6941, ptr %current.token, align 4
  %6942 = load i32, ptr %current.token, align 4
  %6943 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1545)
  %6944 = load i32, ptr %ready.count, align 4
  %6945 = icmp uge i32 %6944, 8
  %6946 = and i1 %6943, %6945
  br i1 %6946, label %ready.overflow.trap1299, label %ready.overflow.resume1300

ready.overflow.trap1299:                          ; preds = %convergence.overflow.resume1298
  call void @llvm.trap()
  unreachable

ready.overflow.resume1300:                        ; preds = %convergence.overflow.resume1298
  %6947 = select i1 %6943, i32 %6944, i32 0
  %6948 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6947
  %6949 = load <8 x i1>, ptr %6948, align 1
  %6950 = select i1 %6943, <8 x i1> %1545, <8 x i1> %6949
  store <8 x i1> %6950, ptr %6948, align 1
  %6951 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6947
  %6952 = load i32, ptr %6951, align 4
  %6953 = select i1 %6943, i32 90, i32 %6952
  store i32 %6953, ptr %6951, align 4
  %6954 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6947
  %6955 = load i32, ptr %6954, align 4
  %6956 = select i1 %6943, i32 %6942, i32 %6955
  store i32 %6956, ptr %6954, align 4
  %6957 = add i32 %6944, 1
  %6958 = select i1 %6943, i32 %6957, i32 %6944
  store i32 %6958, ptr %ready.count, align 4
  %6959 = load <8 x i1>, ptr %runnable.mask, align 1
  %6960 = or <8 x i1> %6959, %1545
  store <8 x i1> %6960, ptr %runnable.mask, align 1
  store <8 x i1> %1547, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1301:                        ; preds = %varying.coherent1296
  store <8 x i1> %1538, ptr %current.mask, align 1
  %6961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1538)
  br i1 %6961, label %schedule.90, label %scheduler.loop

varying.coherent.false1302:                       ; preds = %varying.coherent1296
  store <8 x i1> %1538, ptr %current.mask, align 1
  %6962 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1538)
  br i1 %6962, label %schedule.94, label %scheduler.loop

varying.divergent1314:                            ; preds = %schedule.91
  %6963 = load i32, ptr %current.token, align 4
  %6964 = icmp ne i32 %6963, 0
  %6965 = sub i32 %6963, 1
  %6966 = select i1 %6964, i32 %6965, i32 0
  %6967 = load i8, ptr %frame.active, align 1
  %6968 = trunc i32 %6966 to i8
  %6969 = shl i8 1, %6968
  %6970 = and i8 %6967, %6969
  %6971 = icmp ne i8 %6970, 0
  %6972 = load <8 x i32>, ptr %frame.static.id, align 32
  %6973 = extractelement <8 x i32> %6972, i32 %6966
  %6974 = icmp eq i32 %6973, 32
  %6975 = and i1 %6971, %6974
  %6976 = and i1 %6964, %6975
  %6977 = xor i1 %6976, true
  %6978 = and i1 true, %6977
  %6979 = xor i8 %6967, -1
  %6980 = icmp ne i8 %6979, 0
  %6981 = xor i1 %6980, true
  %6982 = and i1 %6978, %6981
  br i1 %6982, label %convergence.overflow.trap1316, label %convergence.overflow.resume1317

varying.coherent1315:                             ; preds = %schedule.91
  br i1 %1722, label %varying.coherent.true1320, label %varying.coherent.false1321

convergence.overflow.trap1316:                    ; preds = %varying.divergent1314
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1317:                  ; preds = %varying.divergent1314
  %6983 = call i8 @llvm.cttz.i8(i8 %6979, i1 false)
  %6984 = zext i8 %6983 to i32
  %6985 = select i1 %6980, i32 %6984, i32 0
  %6986 = trunc i32 %6985 to i8
  %6987 = shl i8 1, %6986
  %6988 = or i8 %6967, %6987
  %6989 = select i1 %6978, i8 %6988, i8 %6967
  store i8 %6989, ptr %frame.active, align 1
  %6990 = load <8 x i32>, ptr %frame.static.id, align 32
  %6991 = extractelement <8 x i32> %6990, i32 %6985
  %6992 = select i1 %6978, i32 32, i32 %6991
  %6993 = load <8 x i32>, ptr %frame.static.id, align 32
  %6994 = insertelement <8 x i32> %6993, i32 %6992, i32 %6985
  store <8 x i32> %6994, ptr %frame.static.id, align 32
  %6995 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6996 = extractelement <8 x i32> %6995, i32 %6985
  %6997 = select i1 %6978, i32 %6963, i32 %6996
  %6998 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6999 = insertelement <8 x i32> %6998, i32 %6997, i32 %6985
  store <8 x i32> %6999, ptr %frame.parent.token, align 32
  %7000 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6985
  %7001 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6985
  %7002 = load <8 x i1>, ptr %7000, align 1
  %7003 = load <8 x i1>, ptr %7001, align 1
  %7004 = select i1 %6978, <8 x i1> %1712, <8 x i1> %7002
  store <8 x i1> %7004, ptr %7000, align 1
  %7005 = select i1 %6978, <8 x i1> zeroinitializer, <8 x i1> %7003
  store <8 x i1> %7005, ptr %7001, align 1
  %7006 = add i32 %6985, 1
  %7007 = select i1 %6976, i32 %6963, i32 %7006
  %7008 = select i1 true, i32 %7007, i32 %6963
  store i32 %7008, ptr %current.token, align 4
  %7009 = load i32, ptr %current.token, align 4
  %7010 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1719)
  %7011 = load i32, ptr %ready.count, align 4
  %7012 = icmp uge i32 %7011, 8
  %7013 = and i1 %7010, %7012
  br i1 %7013, label %ready.overflow.trap1318, label %ready.overflow.resume1319

ready.overflow.trap1318:                          ; preds = %convergence.overflow.resume1317
  call void @llvm.trap()
  unreachable

ready.overflow.resume1319:                        ; preds = %convergence.overflow.resume1317
  %7014 = select i1 %7010, i32 %7011, i32 0
  %7015 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7014
  %7016 = load <8 x i1>, ptr %7015, align 1
  %7017 = select i1 %7010, <8 x i1> %1719, <8 x i1> %7016
  store <8 x i1> %7017, ptr %7015, align 1
  %7018 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7014
  %7019 = load i32, ptr %7018, align 4
  %7020 = select i1 %7010, i32 92, i32 %7019
  store i32 %7020, ptr %7018, align 4
  %7021 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7014
  %7022 = load i32, ptr %7021, align 4
  %7023 = select i1 %7010, i32 %7009, i32 %7022
  store i32 %7023, ptr %7021, align 4
  %7024 = add i32 %7011, 1
  %7025 = select i1 %7010, i32 %7024, i32 %7011
  store i32 %7025, ptr %ready.count, align 4
  %7026 = load <8 x i1>, ptr %runnable.mask, align 1
  %7027 = or <8 x i1> %7026, %1719
  store <8 x i1> %7027, ptr %runnable.mask, align 1
  store <8 x i1> %1721, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1320:                        ; preds = %varying.coherent1315
  store <8 x i1> %1712, ptr %current.mask, align 1
  %7028 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1712)
  br i1 %7028, label %schedule.92, label %scheduler.loop

varying.coherent.false1321:                       ; preds = %varying.coherent1315
  store <8 x i1> %1712, ptr %current.mask, align 1
  %7029 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1712)
  br i1 %7029, label %schedule.93, label %scheduler.loop

convergence.cascade1338:                          ; preds = %convergence.cascade1338, %schedule.93
  %convergence.cascade.flow1342 = phi <8 x i1> [ %1799, %schedule.93 ], [ %7072, %convergence.cascade1338 ]
  %convergence.cascade.depth1343 = phi i32 [ 0, %schedule.93 ], [ %7073, %convergence.cascade1338 ]
  %7030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1342)
  %7031 = load i32, ptr %current.token, align 4
  %7032 = icmp ne i32 %7031, 0
  %7033 = and i1 %7030, %7032
  %7034 = sub i32 %7031, 1
  %7035 = select i1 %7033, i32 %7034, i32 0
  %7036 = load i8, ptr %frame.active, align 1
  %7037 = trunc i32 %7035 to i8
  %7038 = shl i8 1, %7037
  %7039 = and i8 %7036, %7038
  %7040 = icmp ne i8 %7039, 0
  %7041 = load <8 x i32>, ptr %frame.static.id, align 32
  %7042 = extractelement <8 x i32> %7041, i32 %7035
  %convergence.target.pointer1344 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7042
  %convergence.dynamic.target1345 = load i32, ptr %convergence.target.pointer1344, align 4
  %7043 = icmp eq i32 %convergence.dynamic.target1345, 93
  %7044 = and i1 %7040, %7043
  %7045 = and i1 %7033, %7044
  %7046 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7035
  %7047 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7035
  %7048 = load <8 x i1>, ptr %7046, align 1
  %7049 = load <8 x i1>, ptr %7047, align 1
  %7050 = or <8 x i1> %7049, %convergence.cascade.flow1342
  %7051 = load <8 x i1>, ptr %live.mask, align 1
  %7052 = and <8 x i1> %7048, %7051
  %7053 = icmp eq <8 x i1> %7050, %7052
  %7054 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7053)
  %7055 = and i1 %7045, %7054
  %7056 = select i1 %7055, <8 x i1> zeroinitializer, <8 x i1> %7050
  %7057 = select i1 %7045, <8 x i1> %7056, <8 x i1> %7049
  store <8 x i1> %7057, ptr %7047, align 1
  %7058 = select i1 %7055, <8 x i1> zeroinitializer, <8 x i1> %7048
  store <8 x i1> %7058, ptr %7046, align 1
  %7059 = trunc i32 %7035 to i8
  %7060 = shl i8 1, %7059
  %7061 = xor i8 %7060, -1
  %7062 = and i8 %7036, %7061
  %7063 = select i1 %7055, i8 %7062, i8 %7036
  store i8 %7063, ptr %frame.active, align 1
  %.splatinsert1346 = insertelement <8 x i1> poison, i1 %7045, i64 0
  %.splat1347 = shufflevector <8 x i1> %.splatinsert1346, <8 x i1> poison, <8 x i32> zeroinitializer
  %7064 = and <8 x i1> %convergence.cascade.flow1342, %.splat1347
  %7065 = load <8 x i1>, ptr %runnable.mask, align 1
  %7066 = xor <8 x i1> %7064, splat (i1 true)
  %7067 = and <8 x i1> %7065, %7066
  store <8 x i1> %7067, ptr %runnable.mask, align 1
  %.splatinsert1348 = insertelement <8 x i1> poison, i1 %7055, i64 0
  %.splat1349 = shufflevector <8 x i1> %.splatinsert1348, <8 x i1> poison, <8 x i32> zeroinitializer
  %7068 = select <8 x i1> %.splat1349, <8 x i1> %7050, <8 x i1> zeroinitializer
  %7069 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7070 = extractelement <8 x i32> %7069, i32 %7035
  %7071 = select i1 %7055, i32 %7070, i32 %7031
  store i32 %7071, ptr %current.token, align 4
  %.splatinsert1350 = insertelement <8 x i1> poison, i1 %7045, i64 0
  %.splat1351 = shufflevector <8 x i1> %.splatinsert1350, <8 x i1> poison, <8 x i32> zeroinitializer
  %7072 = select <8 x i1> %.splat1351, <8 x i1> %7068, <8 x i1> %convergence.cascade.flow1342
  %7073 = add i32 %convergence.cascade.depth1343, 1
  %7074 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7072)
  %7075 = icmp ult i32 %7073, 8
  %7076 = and i1 %7074, %7075
  %7077 = and i1 %7045, %7076
  %convergence.parent.token1352 = load i32, ptr %current.token, align 4
  %convergence.parent.present1353 = icmp ne i32 %convergence.parent.token1352, 0
  %7078 = and i1 %7077, %convergence.parent.present1353
  br i1 %7078, label %convergence.cascade1338, label %convergence.cascade.exit1339

convergence.cascade.exit1339:                     ; preds = %convergence.cascade1338, %schedule.93
  %convergence.cascade.result1354 = phi <8 x i1> [ %1799, %schedule.93 ], [ %7072, %convergence.cascade1338 ]
  %7079 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1354)
  br i1 %7079, label %convergence.target.93.ready, label %scheduler.loop

convergence.target.93.ready:                      ; preds = %convergence.cascade.exit1339
  %7080 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1354)
  %7081 = bitcast <8 x i1> %convergence.cascade.result1354 to i8
  %7082 = call i8 @llvm.cttz.i8(i8 %7081, i1 false)
  %7083 = zext i8 %7082 to i32
  %7084 = select i1 %7080, i32 %7083, i32 0
  %tile_snapshot.spill.load1355 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill187, align 64
  %7085 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1355, 0
  %7086 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1355, 1
  %.spill.load1356 = load <8 x i64>, ptr %.spill191, align 64
  %7087 = mul <8 x i64> %.spill.load1356, splat (i64 32)
  %7088 = add <8 x i64> %7086, %7087
  %7089 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7085, 0
  %7090 = insertvalue { <8 x ptr>, <8 x i64> } %7089, <8 x i64> %7088, 1
  %.state1357 = load <8 x float>, ptr %.slot200, align 32
  %7091 = extractvalue { <8 x ptr>, <8 x i64> } %7090, 0
  %7092 = extractvalue { <8 x ptr>, <8 x i64> } %7090, 1
  %7093 = getelementptr i8, <8 x ptr> %7091, <8 x i64> %7092
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1357, <8 x ptr> align 1 %7093, <8 x i1> %convergence.cascade.result1354)
  %tile_snapshot.spill.load1358 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill187, align 64
  %7094 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1358, 0
  %7095 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1358, 1
  %.spill.load1359 = load <8 x i64>, ptr %.spill194, align 64
  %7096 = mul <8 x i64> %.spill.load1359, splat (i64 32)
  %7097 = add <8 x i64> %7095, %7096
  %7098 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7094, 0
  %7099 = insertvalue { <8 x ptr>, <8 x i64> } %7098, <8 x i64> %7097, 1
  %.state1360 = load <8 x float>, ptr %.slot201, align 32
  %7100 = extractvalue { <8 x ptr>, <8 x i64> } %7099, 0
  %7101 = extractvalue { <8 x ptr>, <8 x i64> } %7099, 1
  %7102 = getelementptr i8, <8 x ptr> %7100, <8 x i64> %7101
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1360, <8 x ptr> align 1 %7102, <8 x i1> %convergence.cascade.result1354)
  %tile_snapshot.spill.load1361 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill187, align 64
  %7103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1361, 0
  %7104 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1361, 1
  %.spill.load1362 = load <8 x i64>, ptr %.spill196, align 64
  %7105 = mul <8 x i64> %.spill.load1362, splat (i64 32)
  %7106 = add <8 x i64> %7104, %7105
  %7107 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7103, 0
  %7108 = insertvalue { <8 x ptr>, <8 x i64> } %7107, <8 x i64> %7106, 1
  %.state1363 = load <8 x float>, ptr %.slot202, align 32
  %7109 = extractvalue { <8 x ptr>, <8 x i64> } %7108, 0
  %7110 = extractvalue { <8 x ptr>, <8 x i64> } %7108, 1
  %7111 = getelementptr i8, <8 x ptr> %7109, <8 x i64> %7110
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1363, <8 x ptr> align 1 %7111, <8 x i1> %convergence.cascade.result1354)
  %tile_snapshot.spill.load1364 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill187, align 64
  %7112 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1364, 0
  %7113 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1364, 1
  %.spill.load1365 = load <8 x i64>, ptr %.spill198, align 64
  %7114 = mul <8 x i64> %.spill.load1365, splat (i64 32)
  %7115 = add <8 x i64> %7113, %7114
  %7116 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7112, 0
  %7117 = insertvalue { <8 x ptr>, <8 x i64> } %7116, <8 x i64> %7115, 1
  %.state1366 = load <8 x float>, ptr %.slot203, align 32
  %7118 = extractvalue { <8 x ptr>, <8 x i64> } %7117, 0
  %7119 = extractvalue { <8 x ptr>, <8 x i64> } %7117, 1
  %7120 = getelementptr i8, <8 x ptr> %7118, <8 x i64> %7119
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1366, <8 x ptr> align 1 %7120, <8 x i1> %convergence.cascade.result1354)
  %.state1367 = load <8 x i64>, ptr %.slot190, align 64
  %7121 = add <8 x i64> %.state1367, splat (i64 1)
  %7122 = load <8 x i64>, ptr %.slot190, align 64
  %7123 = select <8 x i1> %convergence.cascade.result1354, <8 x i64> %7121, <8 x i64> %7122
  store <8 x i64> %7123, ptr %.slot190, align 64
  store <8 x i1> %convergence.cascade.result1354, ptr %current.mask, align 1
  %7124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1354)
  br i1 %7124, label %schedule.89, label %scheduler.loop

convergence.cascade1368:                          ; preds = %convergence.cascade1368, %schedule.94
  %convergence.cascade.flow1372 = phi <8 x i1> [ %1800, %schedule.94 ], [ %7167, %convergence.cascade1368 ]
  %convergence.cascade.depth1373 = phi i32 [ 0, %schedule.94 ], [ %7168, %convergence.cascade1368 ]
  %7125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1372)
  %7126 = load i32, ptr %current.token, align 4
  %7127 = icmp ne i32 %7126, 0
  %7128 = and i1 %7125, %7127
  %7129 = sub i32 %7126, 1
  %7130 = select i1 %7128, i32 %7129, i32 0
  %7131 = load i8, ptr %frame.active, align 1
  %7132 = trunc i32 %7130 to i8
  %7133 = shl i8 1, %7132
  %7134 = and i8 %7131, %7133
  %7135 = icmp ne i8 %7134, 0
  %7136 = load <8 x i32>, ptr %frame.static.id, align 32
  %7137 = extractelement <8 x i32> %7136, i32 %7130
  %convergence.target.pointer1374 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7137
  %convergence.dynamic.target1375 = load i32, ptr %convergence.target.pointer1374, align 4
  %7138 = icmp eq i32 %convergence.dynamic.target1375, 94
  %7139 = and i1 %7135, %7138
  %7140 = and i1 %7128, %7139
  %7141 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7130
  %7142 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7130
  %7143 = load <8 x i1>, ptr %7141, align 1
  %7144 = load <8 x i1>, ptr %7142, align 1
  %7145 = or <8 x i1> %7144, %convergence.cascade.flow1372
  %7146 = load <8 x i1>, ptr %live.mask, align 1
  %7147 = and <8 x i1> %7143, %7146
  %7148 = icmp eq <8 x i1> %7145, %7147
  %7149 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7148)
  %7150 = and i1 %7140, %7149
  %7151 = select i1 %7150, <8 x i1> zeroinitializer, <8 x i1> %7145
  %7152 = select i1 %7140, <8 x i1> %7151, <8 x i1> %7144
  store <8 x i1> %7152, ptr %7142, align 1
  %7153 = select i1 %7150, <8 x i1> zeroinitializer, <8 x i1> %7143
  store <8 x i1> %7153, ptr %7141, align 1
  %7154 = trunc i32 %7130 to i8
  %7155 = shl i8 1, %7154
  %7156 = xor i8 %7155, -1
  %7157 = and i8 %7131, %7156
  %7158 = select i1 %7150, i8 %7157, i8 %7131
  store i8 %7158, ptr %frame.active, align 1
  %.splatinsert1376 = insertelement <8 x i1> poison, i1 %7140, i64 0
  %.splat1377 = shufflevector <8 x i1> %.splatinsert1376, <8 x i1> poison, <8 x i32> zeroinitializer
  %7159 = and <8 x i1> %convergence.cascade.flow1372, %.splat1377
  %7160 = load <8 x i1>, ptr %runnable.mask, align 1
  %7161 = xor <8 x i1> %7159, splat (i1 true)
  %7162 = and <8 x i1> %7160, %7161
  store <8 x i1> %7162, ptr %runnable.mask, align 1
  %.splatinsert1378 = insertelement <8 x i1> poison, i1 %7150, i64 0
  %.splat1379 = shufflevector <8 x i1> %.splatinsert1378, <8 x i1> poison, <8 x i32> zeroinitializer
  %7163 = select <8 x i1> %.splat1379, <8 x i1> %7145, <8 x i1> zeroinitializer
  %7164 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7165 = extractelement <8 x i32> %7164, i32 %7130
  %7166 = select i1 %7150, i32 %7165, i32 %7126
  store i32 %7166, ptr %current.token, align 4
  %.splatinsert1380 = insertelement <8 x i1> poison, i1 %7140, i64 0
  %.splat1381 = shufflevector <8 x i1> %.splatinsert1380, <8 x i1> poison, <8 x i32> zeroinitializer
  %7167 = select <8 x i1> %.splat1381, <8 x i1> %7163, <8 x i1> %convergence.cascade.flow1372
  %7168 = add i32 %convergence.cascade.depth1373, 1
  %7169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7167)
  %7170 = icmp ult i32 %7168, 8
  %7171 = and i1 %7169, %7170
  %7172 = and i1 %7140, %7171
  %convergence.parent.token1382 = load i32, ptr %current.token, align 4
  %convergence.parent.present1383 = icmp ne i32 %convergence.parent.token1382, 0
  %7173 = and i1 %7172, %convergence.parent.present1383
  br i1 %7173, label %convergence.cascade1368, label %convergence.cascade.exit1369

convergence.cascade.exit1369:                     ; preds = %convergence.cascade1368, %schedule.94
  %convergence.cascade.result1384 = phi <8 x i1> [ %1800, %schedule.94 ], [ %7167, %convergence.cascade1368 ]
  %7174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1384)
  br i1 %7174, label %convergence.target.94.ready, label %scheduler.loop

convergence.target.94.ready:                      ; preds = %convergence.cascade.exit1369
  %7175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1384)
  %7176 = bitcast <8 x i1> %convergence.cascade.result1384 to i8
  %7177 = call i8 @llvm.cttz.i8(i8 %7176, i1 false)
  %7178 = zext i8 %7177 to i32
  %7179 = select i1 %7175, i32 %7178, i32 0
  %.state1385 = load <8 x i64>, ptr %.slot188, align 64
  %7180 = add <8 x i64> %.state1385, splat (i64 1)
  %7181 = load <8 x i64>, ptr %.slot188, align 64
  %7182 = select <8 x i1> %convergence.cascade.result1384, <8 x i64> %7180, <8 x i64> %7181
  store <8 x i64> %7182, ptr %.slot188, align 64
  store <8 x i1> %convergence.cascade.result1384, ptr %current.mask, align 1
  %7183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1384)
  br i1 %7183, label %schedule.87, label %scheduler.loop

convergence.cascade1386:                          ; preds = %convergence.cascade1386, %schedule.95
  %convergence.cascade.flow1390 = phi <8 x i1> [ %1801, %schedule.95 ], [ %7226, %convergence.cascade1386 ]
  %convergence.cascade.depth1391 = phi i32 [ 0, %schedule.95 ], [ %7227, %convergence.cascade1386 ]
  %7184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1390)
  %7185 = load i32, ptr %current.token, align 4
  %7186 = icmp ne i32 %7185, 0
  %7187 = and i1 %7184, %7186
  %7188 = sub i32 %7185, 1
  %7189 = select i1 %7187, i32 %7188, i32 0
  %7190 = load i8, ptr %frame.active, align 1
  %7191 = trunc i32 %7189 to i8
  %7192 = shl i8 1, %7191
  %7193 = and i8 %7190, %7192
  %7194 = icmp ne i8 %7193, 0
  %7195 = load <8 x i32>, ptr %frame.static.id, align 32
  %7196 = extractelement <8 x i32> %7195, i32 %7189
  %convergence.target.pointer1392 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7196
  %convergence.dynamic.target1393 = load i32, ptr %convergence.target.pointer1392, align 4
  %7197 = icmp eq i32 %convergence.dynamic.target1393, 95
  %7198 = and i1 %7194, %7197
  %7199 = and i1 %7187, %7198
  %7200 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7189
  %7201 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7189
  %7202 = load <8 x i1>, ptr %7200, align 1
  %7203 = load <8 x i1>, ptr %7201, align 1
  %7204 = or <8 x i1> %7203, %convergence.cascade.flow1390
  %7205 = load <8 x i1>, ptr %live.mask, align 1
  %7206 = and <8 x i1> %7202, %7205
  %7207 = icmp eq <8 x i1> %7204, %7206
  %7208 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7207)
  %7209 = and i1 %7199, %7208
  %7210 = select i1 %7209, <8 x i1> zeroinitializer, <8 x i1> %7204
  %7211 = select i1 %7199, <8 x i1> %7210, <8 x i1> %7203
  store <8 x i1> %7211, ptr %7201, align 1
  %7212 = select i1 %7209, <8 x i1> zeroinitializer, <8 x i1> %7202
  store <8 x i1> %7212, ptr %7200, align 1
  %7213 = trunc i32 %7189 to i8
  %7214 = shl i8 1, %7213
  %7215 = xor i8 %7214, -1
  %7216 = and i8 %7190, %7215
  %7217 = select i1 %7209, i8 %7216, i8 %7190
  store i8 %7217, ptr %frame.active, align 1
  %.splatinsert1394 = insertelement <8 x i1> poison, i1 %7199, i64 0
  %.splat1395 = shufflevector <8 x i1> %.splatinsert1394, <8 x i1> poison, <8 x i32> zeroinitializer
  %7218 = and <8 x i1> %convergence.cascade.flow1390, %.splat1395
  %7219 = load <8 x i1>, ptr %runnable.mask, align 1
  %7220 = xor <8 x i1> %7218, splat (i1 true)
  %7221 = and <8 x i1> %7219, %7220
  store <8 x i1> %7221, ptr %runnable.mask, align 1
  %.splatinsert1396 = insertelement <8 x i1> poison, i1 %7209, i64 0
  %.splat1397 = shufflevector <8 x i1> %.splatinsert1396, <8 x i1> poison, <8 x i32> zeroinitializer
  %7222 = select <8 x i1> %.splat1397, <8 x i1> %7204, <8 x i1> zeroinitializer
  %7223 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7224 = extractelement <8 x i32> %7223, i32 %7189
  %7225 = select i1 %7209, i32 %7224, i32 %7185
  store i32 %7225, ptr %current.token, align 4
  %.splatinsert1398 = insertelement <8 x i1> poison, i1 %7199, i64 0
  %.splat1399 = shufflevector <8 x i1> %.splatinsert1398, <8 x i1> poison, <8 x i32> zeroinitializer
  %7226 = select <8 x i1> %.splat1399, <8 x i1> %7222, <8 x i1> %convergence.cascade.flow1390
  %7227 = add i32 %convergence.cascade.depth1391, 1
  %7228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7226)
  %7229 = icmp ult i32 %7227, 8
  %7230 = and i1 %7228, %7229
  %7231 = and i1 %7199, %7230
  %convergence.parent.token1400 = load i32, ptr %current.token, align 4
  %convergence.parent.present1401 = icmp ne i32 %convergence.parent.token1400, 0
  %7232 = and i1 %7231, %convergence.parent.present1401
  br i1 %7232, label %convergence.cascade1386, label %convergence.cascade.exit1387

convergence.cascade.exit1387:                     ; preds = %convergence.cascade1386, %schedule.95
  %convergence.cascade.result1402 = phi <8 x i1> [ %1801, %schedule.95 ], [ %7226, %convergence.cascade1386 ]
  %7233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1402)
  br i1 %7233, label %convergence.target.95.ready, label %scheduler.loop

convergence.target.95.ready:                      ; preds = %convergence.cascade.exit1387
  %7234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1402)
  %7235 = bitcast <8 x i1> %convergence.cascade.result1402 to i8
  %7236 = call i8 @llvm.cttz.i8(i8 %7235, i1 false)
  %7237 = zext i8 %7236 to i32
  %7238 = select i1 %7234, i32 %7237, i32 0
  %7239 = load <8 x i64>, ptr %.slot204, align 64
  %7240 = select <8 x i1> %convergence.cascade.result1402, <8 x i64> zeroinitializer, <8 x i64> %7239
  store <8 x i64> %7240, ptr %.slot204, align 64
  store <8 x i1> %convergence.cascade.result1402, ptr %current.mask, align 1
  %7241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1402)
  br i1 %7241, label %schedule.96, label %scheduler.loop

varying.divergent1404:                            ; preds = %schedule.96
  %7242 = load i32, ptr %current.token, align 4
  %7243 = icmp ne i32 %7242, 0
  %7244 = sub i32 %7242, 1
  %7245 = select i1 %7243, i32 %7244, i32 0
  %7246 = load i8, ptr %frame.active, align 1
  %7247 = trunc i32 %7245 to i8
  %7248 = shl i8 1, %7247
  %7249 = and i8 %7246, %7248
  %7250 = icmp ne i8 %7249, 0
  %7251 = load <8 x i32>, ptr %frame.static.id, align 32
  %7252 = extractelement <8 x i32> %7251, i32 %7245
  %7253 = icmp eq i32 %7252, 33
  %7254 = and i1 %7250, %7253
  %7255 = and i1 %7243, %7254
  %7256 = xor i1 %7255, true
  %7257 = and i1 true, %7256
  %7258 = xor i8 %7246, -1
  %7259 = icmp ne i8 %7258, 0
  %7260 = xor i1 %7259, true
  %7261 = and i1 %7257, %7260
  br i1 %7261, label %convergence.overflow.trap1406, label %convergence.overflow.resume1407

varying.coherent1405:                             ; preds = %schedule.96
  br i1 %1812, label %varying.coherent.true1410, label %varying.coherent.false1411

convergence.overflow.trap1406:                    ; preds = %varying.divergent1404
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1407:                  ; preds = %varying.divergent1404
  %7262 = call i8 @llvm.cttz.i8(i8 %7258, i1 false)
  %7263 = zext i8 %7262 to i32
  %7264 = select i1 %7259, i32 %7263, i32 0
  %7265 = trunc i32 %7264 to i8
  %7266 = shl i8 1, %7265
  %7267 = or i8 %7246, %7266
  %7268 = select i1 %7257, i8 %7267, i8 %7246
  store i8 %7268, ptr %frame.active, align 1
  %7269 = load <8 x i32>, ptr %frame.static.id, align 32
  %7270 = extractelement <8 x i32> %7269, i32 %7264
  %7271 = select i1 %7257, i32 33, i32 %7270
  %7272 = load <8 x i32>, ptr %frame.static.id, align 32
  %7273 = insertelement <8 x i32> %7272, i32 %7271, i32 %7264
  store <8 x i32> %7273, ptr %frame.static.id, align 32
  %7274 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7275 = extractelement <8 x i32> %7274, i32 %7264
  %7276 = select i1 %7257, i32 %7242, i32 %7275
  %7277 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7278 = insertelement <8 x i32> %7277, i32 %7276, i32 %7264
  store <8 x i32> %7278, ptr %frame.parent.token, align 32
  %7279 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7264
  %7280 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7264
  %7281 = load <8 x i1>, ptr %7279, align 1
  %7282 = load <8 x i1>, ptr %7280, align 1
  %7283 = select i1 %7257, <8 x i1> %1802, <8 x i1> %7281
  store <8 x i1> %7283, ptr %7279, align 1
  %7284 = select i1 %7257, <8 x i1> zeroinitializer, <8 x i1> %7282
  store <8 x i1> %7284, ptr %7280, align 1
  %7285 = add i32 %7264, 1
  %7286 = select i1 %7255, i32 %7242, i32 %7285
  %7287 = select i1 true, i32 %7286, i32 %7242
  store i32 %7287, ptr %current.token, align 4
  %7288 = load i32, ptr %current.token, align 4
  %7289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1809)
  %7290 = load i32, ptr %ready.count, align 4
  %7291 = icmp uge i32 %7290, 8
  %7292 = and i1 %7289, %7291
  br i1 %7292, label %ready.overflow.trap1408, label %ready.overflow.resume1409

ready.overflow.trap1408:                          ; preds = %convergence.overflow.resume1407
  call void @llvm.trap()
  unreachable

ready.overflow.resume1409:                        ; preds = %convergence.overflow.resume1407
  %7293 = select i1 %7289, i32 %7290, i32 0
  %7294 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7293
  %7295 = load <8 x i1>, ptr %7294, align 1
  %7296 = select i1 %7289, <8 x i1> %1809, <8 x i1> %7295
  store <8 x i1> %7296, ptr %7294, align 1
  %7297 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7293
  %7298 = load i32, ptr %7297, align 4
  %7299 = select i1 %7289, i32 97, i32 %7298
  store i32 %7299, ptr %7297, align 4
  %7300 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7293
  %7301 = load i32, ptr %7300, align 4
  %7302 = select i1 %7289, i32 %7288, i32 %7301
  store i32 %7302, ptr %7300, align 4
  %7303 = add i32 %7290, 1
  %7304 = select i1 %7289, i32 %7303, i32 %7290
  store i32 %7304, ptr %ready.count, align 4
  %7305 = load <8 x i1>, ptr %runnable.mask, align 1
  %7306 = or <8 x i1> %7305, %1809
  store <8 x i1> %7306, ptr %runnable.mask, align 1
  store <8 x i1> %1811, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1410:                        ; preds = %varying.coherent1405
  store <8 x i1> %1802, ptr %current.mask, align 1
  %7307 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1802)
  br i1 %7307, label %schedule.97, label %scheduler.loop

varying.coherent.false1411:                       ; preds = %varying.coherent1405
  store <8 x i1> %1802, ptr %current.mask, align 1
  %7308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1802)
  br i1 %7308, label %schedule.98, label %scheduler.loop

convergence.cascade1417:                          ; preds = %convergence.cascade1417, %schedule.98
  %convergence.cascade.flow1421 = phi <8 x i1> [ %1844, %schedule.98 ], [ %7351, %convergence.cascade1417 ]
  %convergence.cascade.depth1422 = phi i32 [ 0, %schedule.98 ], [ %7352, %convergence.cascade1417 ]
  %7309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1421)
  %7310 = load i32, ptr %current.token, align 4
  %7311 = icmp ne i32 %7310, 0
  %7312 = and i1 %7309, %7311
  %7313 = sub i32 %7310, 1
  %7314 = select i1 %7312, i32 %7313, i32 0
  %7315 = load i8, ptr %frame.active, align 1
  %7316 = trunc i32 %7314 to i8
  %7317 = shl i8 1, %7316
  %7318 = and i8 %7315, %7317
  %7319 = icmp ne i8 %7318, 0
  %7320 = load <8 x i32>, ptr %frame.static.id, align 32
  %7321 = extractelement <8 x i32> %7320, i32 %7314
  %convergence.target.pointer1423 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7321
  %convergence.dynamic.target1424 = load i32, ptr %convergence.target.pointer1423, align 4
  %7322 = icmp eq i32 %convergence.dynamic.target1424, 98
  %7323 = and i1 %7319, %7322
  %7324 = and i1 %7312, %7323
  %7325 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7314
  %7326 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7314
  %7327 = load <8 x i1>, ptr %7325, align 1
  %7328 = load <8 x i1>, ptr %7326, align 1
  %7329 = or <8 x i1> %7328, %convergence.cascade.flow1421
  %7330 = load <8 x i1>, ptr %live.mask, align 1
  %7331 = and <8 x i1> %7327, %7330
  %7332 = icmp eq <8 x i1> %7329, %7331
  %7333 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7332)
  %7334 = and i1 %7324, %7333
  %7335 = select i1 %7334, <8 x i1> zeroinitializer, <8 x i1> %7329
  %7336 = select i1 %7324, <8 x i1> %7335, <8 x i1> %7328
  store <8 x i1> %7336, ptr %7326, align 1
  %7337 = select i1 %7334, <8 x i1> zeroinitializer, <8 x i1> %7327
  store <8 x i1> %7337, ptr %7325, align 1
  %7338 = trunc i32 %7314 to i8
  %7339 = shl i8 1, %7338
  %7340 = xor i8 %7339, -1
  %7341 = and i8 %7315, %7340
  %7342 = select i1 %7334, i8 %7341, i8 %7315
  store i8 %7342, ptr %frame.active, align 1
  %.splatinsert1425 = insertelement <8 x i1> poison, i1 %7324, i64 0
  %.splat1426 = shufflevector <8 x i1> %.splatinsert1425, <8 x i1> poison, <8 x i32> zeroinitializer
  %7343 = and <8 x i1> %convergence.cascade.flow1421, %.splat1426
  %7344 = load <8 x i1>, ptr %runnable.mask, align 1
  %7345 = xor <8 x i1> %7343, splat (i1 true)
  %7346 = and <8 x i1> %7344, %7345
  store <8 x i1> %7346, ptr %runnable.mask, align 1
  %.splatinsert1427 = insertelement <8 x i1> poison, i1 %7334, i64 0
  %.splat1428 = shufflevector <8 x i1> %.splatinsert1427, <8 x i1> poison, <8 x i32> zeroinitializer
  %7347 = select <8 x i1> %.splat1428, <8 x i1> %7329, <8 x i1> zeroinitializer
  %7348 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7349 = extractelement <8 x i32> %7348, i32 %7314
  %7350 = select i1 %7334, i32 %7349, i32 %7310
  store i32 %7350, ptr %current.token, align 4
  %.splatinsert1429 = insertelement <8 x i1> poison, i1 %7324, i64 0
  %.splat1430 = shufflevector <8 x i1> %.splatinsert1429, <8 x i1> poison, <8 x i32> zeroinitializer
  %7351 = select <8 x i1> %.splat1430, <8 x i1> %7347, <8 x i1> %convergence.cascade.flow1421
  %7352 = add i32 %convergence.cascade.depth1422, 1
  %7353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7351)
  %7354 = icmp ult i32 %7352, 8
  %7355 = and i1 %7353, %7354
  %7356 = and i1 %7324, %7355
  %convergence.parent.token1431 = load i32, ptr %current.token, align 4
  %convergence.parent.present1432 = icmp ne i32 %convergence.parent.token1431, 0
  %7357 = and i1 %7356, %convergence.parent.present1432
  br i1 %7357, label %convergence.cascade1417, label %convergence.cascade.exit1418

convergence.cascade.exit1418:                     ; preds = %convergence.cascade1417, %schedule.98
  %convergence.cascade.result1433 = phi <8 x i1> [ %1844, %schedule.98 ], [ %7351, %convergence.cascade1417 ]
  %7358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1433)
  br i1 %7358, label %convergence.target.98.ready, label %scheduler.loop

convergence.target.98.ready:                      ; preds = %convergence.cascade.exit1418
  %7359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1433)
  %7360 = bitcast <8 x i1> %convergence.cascade.result1433 to i8
  %7361 = call i8 @llvm.cttz.i8(i8 %7360, i1 false)
  %7362 = zext i8 %7361 to i32
  %7363 = select i1 %7359, i32 %7362, i32 0
  %7364 = load <8 x i64>, ptr %.slot205, align 64
  %7365 = select <8 x i1> %convergence.cascade.result1433, <8 x i64> zeroinitializer, <8 x i64> %7364
  store <8 x i64> %7365, ptr %.slot205, align 64
  store <8 x i1> %convergence.cascade.result1433, ptr %current.mask, align 1
  %7366 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1433)
  br i1 %7366, label %schedule.99, label %scheduler.loop

varying.divergent1435:                            ; preds = %schedule.99
  %7367 = load i32, ptr %current.token, align 4
  %7368 = icmp ne i32 %7367, 0
  %7369 = sub i32 %7367, 1
  %7370 = select i1 %7368, i32 %7369, i32 0
  %7371 = load i8, ptr %frame.active, align 1
  %7372 = trunc i32 %7370 to i8
  %7373 = shl i8 1, %7372
  %7374 = and i8 %7371, %7373
  %7375 = icmp ne i8 %7374, 0
  %7376 = load <8 x i32>, ptr %frame.static.id, align 32
  %7377 = extractelement <8 x i32> %7376, i32 %7370
  %7378 = icmp eq i32 %7377, 34
  %7379 = and i1 %7375, %7378
  %7380 = and i1 %7368, %7379
  %7381 = xor i1 %7380, true
  %7382 = and i1 true, %7381
  %7383 = xor i8 %7371, -1
  %7384 = icmp ne i8 %7383, 0
  %7385 = xor i1 %7384, true
  %7386 = and i1 %7382, %7385
  br i1 %7386, label %convergence.overflow.trap1437, label %convergence.overflow.resume1438

varying.coherent1436:                             ; preds = %schedule.99
  br i1 %1855, label %varying.coherent.true1441, label %varying.coherent.false1442

convergence.overflow.trap1437:                    ; preds = %varying.divergent1435
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1438:                  ; preds = %varying.divergent1435
  %7387 = call i8 @llvm.cttz.i8(i8 %7383, i1 false)
  %7388 = zext i8 %7387 to i32
  %7389 = select i1 %7384, i32 %7388, i32 0
  %7390 = trunc i32 %7389 to i8
  %7391 = shl i8 1, %7390
  %7392 = or i8 %7371, %7391
  %7393 = select i1 %7382, i8 %7392, i8 %7371
  store i8 %7393, ptr %frame.active, align 1
  %7394 = load <8 x i32>, ptr %frame.static.id, align 32
  %7395 = extractelement <8 x i32> %7394, i32 %7389
  %7396 = select i1 %7382, i32 34, i32 %7395
  %7397 = load <8 x i32>, ptr %frame.static.id, align 32
  %7398 = insertelement <8 x i32> %7397, i32 %7396, i32 %7389
  store <8 x i32> %7398, ptr %frame.static.id, align 32
  %7399 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7400 = extractelement <8 x i32> %7399, i32 %7389
  %7401 = select i1 %7382, i32 %7367, i32 %7400
  %7402 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7403 = insertelement <8 x i32> %7402, i32 %7401, i32 %7389
  store <8 x i32> %7403, ptr %frame.parent.token, align 32
  %7404 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7389
  %7405 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7389
  %7406 = load <8 x i1>, ptr %7404, align 1
  %7407 = load <8 x i1>, ptr %7405, align 1
  %7408 = select i1 %7382, <8 x i1> %1845, <8 x i1> %7406
  store <8 x i1> %7408, ptr %7404, align 1
  %7409 = select i1 %7382, <8 x i1> zeroinitializer, <8 x i1> %7407
  store <8 x i1> %7409, ptr %7405, align 1
  %7410 = add i32 %7389, 1
  %7411 = select i1 %7380, i32 %7367, i32 %7410
  %7412 = select i1 true, i32 %7411, i32 %7367
  store i32 %7412, ptr %current.token, align 4
  %7413 = load i32, ptr %current.token, align 4
  %7414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1852)
  %7415 = load i32, ptr %ready.count, align 4
  %7416 = icmp uge i32 %7415, 8
  %7417 = and i1 %7414, %7416
  br i1 %7417, label %ready.overflow.trap1439, label %ready.overflow.resume1440

ready.overflow.trap1439:                          ; preds = %convergence.overflow.resume1438
  call void @llvm.trap()
  unreachable

ready.overflow.resume1440:                        ; preds = %convergence.overflow.resume1438
  %7418 = select i1 %7414, i32 %7415, i32 0
  %7419 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7418
  %7420 = load <8 x i1>, ptr %7419, align 1
  %7421 = select i1 %7414, <8 x i1> %1852, <8 x i1> %7420
  store <8 x i1> %7421, ptr %7419, align 1
  %7422 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7418
  %7423 = load i32, ptr %7422, align 4
  %7424 = select i1 %7414, i32 100, i32 %7423
  store i32 %7424, ptr %7422, align 4
  %7425 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7418
  %7426 = load i32, ptr %7425, align 4
  %7427 = select i1 %7414, i32 %7413, i32 %7426
  store i32 %7427, ptr %7425, align 4
  %7428 = add i32 %7415, 1
  %7429 = select i1 %7414, i32 %7428, i32 %7415
  store i32 %7429, ptr %ready.count, align 4
  %7430 = load <8 x i1>, ptr %runnable.mask, align 1
  %7431 = or <8 x i1> %7430, %1852
  store <8 x i1> %7431, ptr %runnable.mask, align 1
  store <8 x i1> %1854, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1441:                        ; preds = %varying.coherent1436
  store <8 x i1> %1845, ptr %current.mask, align 1
  %7432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1845)
  br i1 %7432, label %schedule.100, label %scheduler.loop

varying.coherent.false1442:                       ; preds = %varying.coherent1436
  store <8 x i1> %1845, ptr %current.mask, align 1
  %7433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1845)
  br i1 %7433, label %schedule.101, label %scheduler.loop

convergence.cascade1448:                          ; preds = %convergence.cascade1448, %schedule.101
  %convergence.cascade.flow1452 = phi <8 x i1> [ %1887, %schedule.101 ], [ %7476, %convergence.cascade1448 ]
  %convergence.cascade.depth1453 = phi i32 [ 0, %schedule.101 ], [ %7477, %convergence.cascade1448 ]
  %7434 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1452)
  %7435 = load i32, ptr %current.token, align 4
  %7436 = icmp ne i32 %7435, 0
  %7437 = and i1 %7434, %7436
  %7438 = sub i32 %7435, 1
  %7439 = select i1 %7437, i32 %7438, i32 0
  %7440 = load i8, ptr %frame.active, align 1
  %7441 = trunc i32 %7439 to i8
  %7442 = shl i8 1, %7441
  %7443 = and i8 %7440, %7442
  %7444 = icmp ne i8 %7443, 0
  %7445 = load <8 x i32>, ptr %frame.static.id, align 32
  %7446 = extractelement <8 x i32> %7445, i32 %7439
  %convergence.target.pointer1454 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7446
  %convergence.dynamic.target1455 = load i32, ptr %convergence.target.pointer1454, align 4
  %7447 = icmp eq i32 %convergence.dynamic.target1455, 101
  %7448 = and i1 %7444, %7447
  %7449 = and i1 %7437, %7448
  %7450 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7439
  %7451 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7439
  %7452 = load <8 x i1>, ptr %7450, align 1
  %7453 = load <8 x i1>, ptr %7451, align 1
  %7454 = or <8 x i1> %7453, %convergence.cascade.flow1452
  %7455 = load <8 x i1>, ptr %live.mask, align 1
  %7456 = and <8 x i1> %7452, %7455
  %7457 = icmp eq <8 x i1> %7454, %7456
  %7458 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7457)
  %7459 = and i1 %7449, %7458
  %7460 = select i1 %7459, <8 x i1> zeroinitializer, <8 x i1> %7454
  %7461 = select i1 %7449, <8 x i1> %7460, <8 x i1> %7453
  store <8 x i1> %7461, ptr %7451, align 1
  %7462 = select i1 %7459, <8 x i1> zeroinitializer, <8 x i1> %7452
  store <8 x i1> %7462, ptr %7450, align 1
  %7463 = trunc i32 %7439 to i8
  %7464 = shl i8 1, %7463
  %7465 = xor i8 %7464, -1
  %7466 = and i8 %7440, %7465
  %7467 = select i1 %7459, i8 %7466, i8 %7440
  store i8 %7467, ptr %frame.active, align 1
  %.splatinsert1456 = insertelement <8 x i1> poison, i1 %7449, i64 0
  %.splat1457 = shufflevector <8 x i1> %.splatinsert1456, <8 x i1> poison, <8 x i32> zeroinitializer
  %7468 = and <8 x i1> %convergence.cascade.flow1452, %.splat1457
  %7469 = load <8 x i1>, ptr %runnable.mask, align 1
  %7470 = xor <8 x i1> %7468, splat (i1 true)
  %7471 = and <8 x i1> %7469, %7470
  store <8 x i1> %7471, ptr %runnable.mask, align 1
  %.splatinsert1458 = insertelement <8 x i1> poison, i1 %7459, i64 0
  %.splat1459 = shufflevector <8 x i1> %.splatinsert1458, <8 x i1> poison, <8 x i32> zeroinitializer
  %7472 = select <8 x i1> %.splat1459, <8 x i1> %7454, <8 x i1> zeroinitializer
  %7473 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7474 = extractelement <8 x i32> %7473, i32 %7439
  %7475 = select i1 %7459, i32 %7474, i32 %7435
  store i32 %7475, ptr %current.token, align 4
  %.splatinsert1460 = insertelement <8 x i1> poison, i1 %7449, i64 0
  %.splat1461 = shufflevector <8 x i1> %.splatinsert1460, <8 x i1> poison, <8 x i32> zeroinitializer
  %7476 = select <8 x i1> %.splat1461, <8 x i1> %7472, <8 x i1> %convergence.cascade.flow1452
  %7477 = add i32 %convergence.cascade.depth1453, 1
  %7478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7476)
  %7479 = icmp ult i32 %7477, 8
  %7480 = and i1 %7478, %7479
  %7481 = and i1 %7449, %7480
  %convergence.parent.token1462 = load i32, ptr %current.token, align 4
  %convergence.parent.present1463 = icmp ne i32 %convergence.parent.token1462, 0
  %7482 = and i1 %7481, %convergence.parent.present1463
  br i1 %7482, label %convergence.cascade1448, label %convergence.cascade.exit1449

convergence.cascade.exit1449:                     ; preds = %convergence.cascade1448, %schedule.101
  %convergence.cascade.result1464 = phi <8 x i1> [ %1887, %schedule.101 ], [ %7476, %convergence.cascade1448 ]
  %7483 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1464)
  br i1 %7483, label %convergence.target.101.ready, label %scheduler.loop

convergence.target.101.ready:                     ; preds = %convergence.cascade.exit1449
  %7484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1464)
  %7485 = bitcast <8 x i1> %convergence.cascade.result1464 to i8
  %7486 = call i8 @llvm.cttz.i8(i8 %7485, i1 false)
  %7487 = zext i8 %7486 to i32
  %7488 = select i1 %7484, i32 %7487, i32 0
  %.state1465 = load <8 x i64>, ptr %.slot68, align 64
  %7489 = add <8 x i64> %.state1465, splat (i64 1)
  %.spill.load1466 = load <8 x float>, ptr %.spill135, align 32
  %.spill.load1467 = load <8 x float>, ptr %.spill136, align 32
  %.spill.load1468 = load <8 x float>, ptr %.spill137, align 32
  %.spill.load1469 = load <8 x float>, ptr %.spill138, align 32
  %.spill.load1470 = load <8 x float>, ptr %.spill139, align 32
  %.spill.load1471 = load <8 x float>, ptr %.spill140, align 32
  %.spill.load1472 = load <8 x float>, ptr %.spill141, align 32
  %.spill.load1473 = load <8 x float>, ptr %.spill142, align 32
  %.spill.load1474 = load <8 x float>, ptr %.spill179, align 32
  %.spill.load1475 = load <8 x float>, ptr %.spill180, align 32
  %.spill.load1476 = load <8 x float>, ptr %.spill181, align 32
  %.spill.load1477 = load <8 x float>, ptr %.spill182, align 32
  %.spill.load1478 = load <8 x float>, ptr %.spill183, align 32
  %.spill.load1479 = load <8 x float>, ptr %.spill184, align 32
  %.spill.load1480 = load <8 x float>, ptr %.spill185, align 32
  %.spill.load1481 = load <8 x float>, ptr %.spill186, align 32
  %7490 = load <8 x i64>, ptr %.slot68, align 64
  %7491 = select <8 x i1> %convergence.cascade.result1464, <8 x i64> %7489, <8 x i64> %7490
  store <8 x i64> %7491, ptr %.slot68, align 64
  %7492 = load <8 x float>, ptr %.slot69, align 32
  %7493 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1466, <8 x float> %7492
  store <8 x float> %7493, ptr %.slot69, align 32
  %7494 = load <8 x float>, ptr %.slot70, align 32
  %7495 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1467, <8 x float> %7494
  store <8 x float> %7495, ptr %.slot70, align 32
  %7496 = load <8 x float>, ptr %.slot71, align 32
  %7497 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1468, <8 x float> %7496
  store <8 x float> %7497, ptr %.slot71, align 32
  %7498 = load <8 x float>, ptr %.slot72, align 32
  %7499 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1469, <8 x float> %7498
  store <8 x float> %7499, ptr %.slot72, align 32
  %7500 = load <8 x float>, ptr %.slot73, align 32
  %7501 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1470, <8 x float> %7500
  store <8 x float> %7501, ptr %.slot73, align 32
  %7502 = load <8 x float>, ptr %.slot74, align 32
  %7503 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1471, <8 x float> %7502
  store <8 x float> %7503, ptr %.slot74, align 32
  %7504 = load <8 x float>, ptr %.slot75, align 32
  %7505 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1472, <8 x float> %7504
  store <8 x float> %7505, ptr %.slot75, align 32
  %7506 = load <8 x float>, ptr %.slot76, align 32
  %7507 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1473, <8 x float> %7506
  store <8 x float> %7507, ptr %.slot76, align 32
  %7508 = load <8 x float>, ptr %.slot77, align 32
  %7509 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1474, <8 x float> %7508
  store <8 x float> %7509, ptr %.slot77, align 32
  %7510 = load <8 x float>, ptr %.slot78, align 32
  %7511 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1475, <8 x float> %7510
  store <8 x float> %7511, ptr %.slot78, align 32
  %7512 = load <8 x float>, ptr %.slot79, align 32
  %7513 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1476, <8 x float> %7512
  store <8 x float> %7513, ptr %.slot79, align 32
  %7514 = load <8 x float>, ptr %.slot80, align 32
  %7515 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1477, <8 x float> %7514
  store <8 x float> %7515, ptr %.slot80, align 32
  %7516 = load <8 x float>, ptr %.slot81, align 32
  %7517 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1478, <8 x float> %7516
  store <8 x float> %7517, ptr %.slot81, align 32
  %7518 = load <8 x float>, ptr %.slot82, align 32
  %7519 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1479, <8 x float> %7518
  store <8 x float> %7519, ptr %.slot82, align 32
  %7520 = load <8 x float>, ptr %.slot83, align 32
  %7521 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1480, <8 x float> %7520
  store <8 x float> %7521, ptr %.slot83, align 32
  %7522 = load <8 x float>, ptr %.slot84, align 32
  %7523 = select <8 x i1> %convergence.cascade.result1464, <8 x float> %.spill.load1481, <8 x float> %7522
  store <8 x float> %7523, ptr %.slot84, align 32
  store <8 x i1> %convergence.cascade.result1464, ptr %current.mask, align 1
  %7524 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1464)
  br i1 %7524, label %schedule.9, label %scheduler.loop

convergence.cascade1482:                          ; preds = %convergence.cascade1482, %schedule.102
  %convergence.cascade.flow1486 = phi <8 x i1> [ %1888, %schedule.102 ], [ %7567, %convergence.cascade1482 ]
  %convergence.cascade.depth1487 = phi i32 [ 0, %schedule.102 ], [ %7568, %convergence.cascade1482 ]
  %7525 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1486)
  %7526 = load i32, ptr %current.token, align 4
  %7527 = icmp ne i32 %7526, 0
  %7528 = and i1 %7525, %7527
  %7529 = sub i32 %7526, 1
  %7530 = select i1 %7528, i32 %7529, i32 0
  %7531 = load i8, ptr %frame.active, align 1
  %7532 = trunc i32 %7530 to i8
  %7533 = shl i8 1, %7532
  %7534 = and i8 %7531, %7533
  %7535 = icmp ne i8 %7534, 0
  %7536 = load <8 x i32>, ptr %frame.static.id, align 32
  %7537 = extractelement <8 x i32> %7536, i32 %7530
  %convergence.target.pointer1488 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7537
  %convergence.dynamic.target1489 = load i32, ptr %convergence.target.pointer1488, align 4
  %7538 = icmp eq i32 %convergence.dynamic.target1489, 102
  %7539 = and i1 %7535, %7538
  %7540 = and i1 %7528, %7539
  %7541 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7530
  %7542 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7530
  %7543 = load <8 x i1>, ptr %7541, align 1
  %7544 = load <8 x i1>, ptr %7542, align 1
  %7545 = or <8 x i1> %7544, %convergence.cascade.flow1486
  %7546 = load <8 x i1>, ptr %live.mask, align 1
  %7547 = and <8 x i1> %7543, %7546
  %7548 = icmp eq <8 x i1> %7545, %7547
  %7549 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7548)
  %7550 = and i1 %7540, %7549
  %7551 = select i1 %7550, <8 x i1> zeroinitializer, <8 x i1> %7545
  %7552 = select i1 %7540, <8 x i1> %7551, <8 x i1> %7544
  store <8 x i1> %7552, ptr %7542, align 1
  %7553 = select i1 %7550, <8 x i1> zeroinitializer, <8 x i1> %7543
  store <8 x i1> %7553, ptr %7541, align 1
  %7554 = trunc i32 %7530 to i8
  %7555 = shl i8 1, %7554
  %7556 = xor i8 %7555, -1
  %7557 = and i8 %7531, %7556
  %7558 = select i1 %7550, i8 %7557, i8 %7531
  store i8 %7558, ptr %frame.active, align 1
  %.splatinsert1490 = insertelement <8 x i1> poison, i1 %7540, i64 0
  %.splat1491 = shufflevector <8 x i1> %.splatinsert1490, <8 x i1> poison, <8 x i32> zeroinitializer
  %7559 = and <8 x i1> %convergence.cascade.flow1486, %.splat1491
  %7560 = load <8 x i1>, ptr %runnable.mask, align 1
  %7561 = xor <8 x i1> %7559, splat (i1 true)
  %7562 = and <8 x i1> %7560, %7561
  store <8 x i1> %7562, ptr %runnable.mask, align 1
  %.splatinsert1492 = insertelement <8 x i1> poison, i1 %7550, i64 0
  %.splat1493 = shufflevector <8 x i1> %.splatinsert1492, <8 x i1> poison, <8 x i32> zeroinitializer
  %7563 = select <8 x i1> %.splat1493, <8 x i1> %7545, <8 x i1> zeroinitializer
  %7564 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7565 = extractelement <8 x i32> %7564, i32 %7530
  %7566 = select i1 %7550, i32 %7565, i32 %7526
  store i32 %7566, ptr %current.token, align 4
  %.splatinsert1494 = insertelement <8 x i1> poison, i1 %7540, i64 0
  %.splat1495 = shufflevector <8 x i1> %.splatinsert1494, <8 x i1> poison, <8 x i32> zeroinitializer
  %7567 = select <8 x i1> %.splat1495, <8 x i1> %7563, <8 x i1> %convergence.cascade.flow1486
  %7568 = add i32 %convergence.cascade.depth1487, 1
  %7569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7567)
  %7570 = icmp ult i32 %7568, 8
  %7571 = and i1 %7569, %7570
  %7572 = and i1 %7540, %7571
  %convergence.parent.token1496 = load i32, ptr %current.token, align 4
  %convergence.parent.present1497 = icmp ne i32 %convergence.parent.token1496, 0
  %7573 = and i1 %7572, %convergence.parent.present1497
  br i1 %7573, label %convergence.cascade1482, label %convergence.cascade.exit1483

convergence.cascade.exit1483:                     ; preds = %convergence.cascade1482, %schedule.102
  %convergence.cascade.result1498 = phi <8 x i1> [ %1888, %schedule.102 ], [ %7567, %convergence.cascade1482 ]
  %7574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1498)
  br i1 %7574, label %convergence.target.102.ready, label %scheduler.loop

convergence.target.102.ready:                     ; preds = %convergence.cascade.exit1483
  %7575 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1498)
  %7576 = bitcast <8 x i1> %convergence.cascade.result1498 to i8
  %7577 = call i8 @llvm.cttz.i8(i8 %7576, i1 false)
  %7578 = zext i8 %7577 to i32
  %7579 = select i1 %7575, i32 %7578, i32 0
  %7580 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill206, align 64
  %7581 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7582 = extractvalue { <8 x ptr>, <8 x i64> } %7580, 0
  %7583 = select <8 x i1> %convergence.cascade.result1498, <8 x ptr> %7581, <8 x ptr> %7582
  %7584 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7585 = extractvalue { <8 x ptr>, <8 x i64> } %7580, 1
  %7586 = select <8 x i1> %convergence.cascade.result1498, <8 x i64> %7584, <8 x i64> %7585
  %7587 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7583, 0
  %7588 = insertvalue { <8 x ptr>, <8 x i64> } %7587, <8 x i64> %7586, 1
  store { <8 x ptr>, <8 x i64> } %7588, ptr %tile_snapshot.spill206, align 64
  %7589 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7590 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7591 = add <8 x i64> %7590, zeroinitializer
  %7592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7589, 0
  %7593 = insertvalue { <8 x ptr>, <8 x i64> } %7592, <8 x i64> %7591, 1
  %.state1499 = load <8 x float>, ptr %.slot77, align 32
  %7594 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7595 = extractvalue { <8 x ptr>, <8 x i64> } %7593, 1
  %7596 = extractelement <8 x ptr> %7594, i32 0
  %7597 = extractelement <8 x i64> %7595, i32 %7579
  %7598 = zext i32 %7579 to i64
  %7599 = mul i64 %7598, 4
  %7600 = sub i64 %7597, %7599
  %7601 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1498)
  %7602 = select i1 %7601, i64 %7600, i64 0
  %private.contiguous.address1500 = getelementptr i8, ptr %7596, i64 %7602
  %private.contiguous.preserve1501 = load <8 x float>, ptr %private.contiguous.address1500, align 4
  %7603 = select <8 x i1> %convergence.cascade.result1498, <8 x float> %.state1499, <8 x float> %private.contiguous.preserve1501
  store <8 x float> %7603, ptr %private.contiguous.address1500, align 4
  %7604 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7605 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7606 = add <8 x i64> %7605, splat (i64 32)
  %7607 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7604, 0
  %7608 = insertvalue { <8 x ptr>, <8 x i64> } %7607, <8 x i64> %7606, 1
  %.state1502 = load <8 x float>, ptr %.slot78, align 32
  %7609 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7610 = extractvalue { <8 x ptr>, <8 x i64> } %7608, 1
  %7611 = extractelement <8 x ptr> %7609, i32 0
  %7612 = extractelement <8 x i64> %7610, i32 %7579
  %7613 = zext i32 %7579 to i64
  %7614 = mul i64 %7613, 4
  %7615 = sub i64 %7612, %7614
  %7616 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1498)
  %7617 = select i1 %7616, i64 %7615, i64 0
  %private.contiguous.address1503 = getelementptr i8, ptr %7611, i64 %7617
  %private.contiguous.preserve1504 = load <8 x float>, ptr %private.contiguous.address1503, align 4
  %7618 = select <8 x i1> %convergence.cascade.result1498, <8 x float> %.state1502, <8 x float> %private.contiguous.preserve1504
  store <8 x float> %7618, ptr %private.contiguous.address1503, align 4
  %7619 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7620 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7621 = add <8 x i64> %7620, splat (i64 64)
  %7622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7619, 0
  %7623 = insertvalue { <8 x ptr>, <8 x i64> } %7622, <8 x i64> %7621, 1
  %.state1505 = load <8 x float>, ptr %.slot79, align 32
  %7624 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7625 = extractvalue { <8 x ptr>, <8 x i64> } %7623, 1
  %7626 = extractelement <8 x ptr> %7624, i32 0
  %7627 = extractelement <8 x i64> %7625, i32 %7579
  %7628 = zext i32 %7579 to i64
  %7629 = mul i64 %7628, 4
  %7630 = sub i64 %7627, %7629
  %7631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1498)
  %7632 = select i1 %7631, i64 %7630, i64 0
  %private.contiguous.address1506 = getelementptr i8, ptr %7626, i64 %7632
  %private.contiguous.preserve1507 = load <8 x float>, ptr %private.contiguous.address1506, align 4
  %7633 = select <8 x i1> %convergence.cascade.result1498, <8 x float> %.state1505, <8 x float> %private.contiguous.preserve1507
  store <8 x float> %7633, ptr %private.contiguous.address1506, align 4
  %7634 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7635 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7636 = add <8 x i64> %7635, splat (i64 96)
  %7637 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7634, 0
  %7638 = insertvalue { <8 x ptr>, <8 x i64> } %7637, <8 x i64> %7636, 1
  %.state1508 = load <8 x float>, ptr %.slot80, align 32
  %7639 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7640 = extractvalue { <8 x ptr>, <8 x i64> } %7638, 1
  %7641 = extractelement <8 x ptr> %7639, i32 0
  %7642 = extractelement <8 x i64> %7640, i32 %7579
  %7643 = zext i32 %7579 to i64
  %7644 = mul i64 %7643, 4
  %7645 = sub i64 %7642, %7644
  %7646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1498)
  %7647 = select i1 %7646, i64 %7645, i64 0
  %private.contiguous.address1509 = getelementptr i8, ptr %7641, i64 %7647
  %private.contiguous.preserve1510 = load <8 x float>, ptr %private.contiguous.address1509, align 4
  %7648 = select <8 x i1> %convergence.cascade.result1498, <8 x float> %.state1508, <8 x float> %private.contiguous.preserve1510
  store <8 x float> %7648, ptr %private.contiguous.address1509, align 4
  %7649 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7650 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7651 = add <8 x i64> %7650, splat (i64 128)
  %7652 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7649, 0
  %7653 = insertvalue { <8 x ptr>, <8 x i64> } %7652, <8 x i64> %7651, 1
  %.state1511 = load <8 x float>, ptr %.slot81, align 32
  %7654 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7655 = extractvalue { <8 x ptr>, <8 x i64> } %7653, 1
  %7656 = extractelement <8 x ptr> %7654, i32 0
  %7657 = extractelement <8 x i64> %7655, i32 %7579
  %7658 = zext i32 %7579 to i64
  %7659 = mul i64 %7658, 4
  %7660 = sub i64 %7657, %7659
  %7661 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1498)
  %7662 = select i1 %7661, i64 %7660, i64 0
  %private.contiguous.address1512 = getelementptr i8, ptr %7656, i64 %7662
  %private.contiguous.preserve1513 = load <8 x float>, ptr %private.contiguous.address1512, align 4
  %7663 = select <8 x i1> %convergence.cascade.result1498, <8 x float> %.state1511, <8 x float> %private.contiguous.preserve1513
  store <8 x float> %7663, ptr %private.contiguous.address1512, align 4
  %7664 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7665 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7666 = add <8 x i64> %7665, splat (i64 160)
  %7667 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7664, 0
  %7668 = insertvalue { <8 x ptr>, <8 x i64> } %7667, <8 x i64> %7666, 1
  %.state1514 = load <8 x float>, ptr %.slot82, align 32
  %7669 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7670 = extractvalue { <8 x ptr>, <8 x i64> } %7668, 1
  %7671 = extractelement <8 x ptr> %7669, i32 0
  %7672 = extractelement <8 x i64> %7670, i32 %7579
  %7673 = zext i32 %7579 to i64
  %7674 = mul i64 %7673, 4
  %7675 = sub i64 %7672, %7674
  %7676 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1498)
  %7677 = select i1 %7676, i64 %7675, i64 0
  %private.contiguous.address1515 = getelementptr i8, ptr %7671, i64 %7677
  %private.contiguous.preserve1516 = load <8 x float>, ptr %private.contiguous.address1515, align 4
  %7678 = select <8 x i1> %convergence.cascade.result1498, <8 x float> %.state1514, <8 x float> %private.contiguous.preserve1516
  store <8 x float> %7678, ptr %private.contiguous.address1515, align 4
  %7679 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7680 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7681 = add <8 x i64> %7680, splat (i64 192)
  %7682 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7679, 0
  %7683 = insertvalue { <8 x ptr>, <8 x i64> } %7682, <8 x i64> %7681, 1
  %.state1517 = load <8 x float>, ptr %.slot83, align 32
  %7684 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7685 = extractvalue { <8 x ptr>, <8 x i64> } %7683, 1
  %7686 = extractelement <8 x ptr> %7684, i32 0
  %7687 = extractelement <8 x i64> %7685, i32 %7579
  %7688 = zext i32 %7579 to i64
  %7689 = mul i64 %7688, 4
  %7690 = sub i64 %7687, %7689
  %7691 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1498)
  %7692 = select i1 %7691, i64 %7690, i64 0
  %private.contiguous.address1518 = getelementptr i8, ptr %7686, i64 %7692
  %private.contiguous.preserve1519 = load <8 x float>, ptr %private.contiguous.address1518, align 4
  %7693 = select <8 x i1> %convergence.cascade.result1498, <8 x float> %.state1517, <8 x float> %private.contiguous.preserve1519
  store <8 x float> %7693, ptr %private.contiguous.address1518, align 4
  %7694 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7695 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %7696 = add <8 x i64> %7695, splat (i64 224)
  %7697 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7694, 0
  %7698 = insertvalue { <8 x ptr>, <8 x i64> } %7697, <8 x i64> %7696, 1
  %.state1520 = load <8 x float>, ptr %.slot84, align 32
  %7699 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %7700 = extractvalue { <8 x ptr>, <8 x i64> } %7698, 1
  %7701 = extractelement <8 x ptr> %7699, i32 0
  %7702 = extractelement <8 x i64> %7700, i32 %7579
  %7703 = zext i32 %7579 to i64
  %7704 = mul i64 %7703, 4
  %7705 = sub i64 %7702, %7704
  %7706 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1498)
  %7707 = select i1 %7706, i64 %7705, i64 0
  %private.contiguous.address1521 = getelementptr i8, ptr %7701, i64 %7707
  %private.contiguous.preserve1522 = load <8 x float>, ptr %private.contiguous.address1521, align 4
  %7708 = select <8 x i1> %convergence.cascade.result1498, <8 x float> %.state1520, <8 x float> %private.contiguous.preserve1522
  store <8 x float> %7708, ptr %private.contiguous.address1521, align 4
  %7709 = load <8 x i64>, ptr %.slot207, align 64
  %7710 = select <8 x i1> %convergence.cascade.result1498, <8 x i64> zeroinitializer, <8 x i64> %7709
  store <8 x i64> %7710, ptr %.slot207, align 64
  store <8 x i1> %convergence.cascade.result1498, ptr %current.mask, align 1
  %7711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1498)
  br i1 %7711, label %schedule.103, label %scheduler.loop

varying.divergent1524:                            ; preds = %schedule.103
  %7712 = load i32, ptr %current.token, align 4
  %7713 = icmp ne i32 %7712, 0
  %7714 = sub i32 %7712, 1
  %7715 = select i1 %7713, i32 %7714, i32 0
  %7716 = load i8, ptr %frame.active, align 1
  %7717 = trunc i32 %7715 to i8
  %7718 = shl i8 1, %7717
  %7719 = and i8 %7716, %7718
  %7720 = icmp ne i8 %7719, 0
  %7721 = load <8 x i32>, ptr %frame.static.id, align 32
  %7722 = extractelement <8 x i32> %7721, i32 %7715
  %7723 = icmp eq i32 %7722, 35
  %7724 = and i1 %7720, %7723
  %7725 = and i1 %7713, %7724
  %7726 = xor i1 %7725, true
  %7727 = and i1 true, %7726
  %7728 = xor i8 %7716, -1
  %7729 = icmp ne i8 %7728, 0
  %7730 = xor i1 %7729, true
  %7731 = and i1 %7727, %7730
  br i1 %7731, label %convergence.overflow.trap1526, label %convergence.overflow.resume1527

varying.coherent1525:                             ; preds = %schedule.103
  br i1 %1899, label %varying.coherent.true1530, label %varying.coherent.false1531

convergence.overflow.trap1526:                    ; preds = %varying.divergent1524
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1527:                  ; preds = %varying.divergent1524
  %7732 = call i8 @llvm.cttz.i8(i8 %7728, i1 false)
  %7733 = zext i8 %7732 to i32
  %7734 = select i1 %7729, i32 %7733, i32 0
  %7735 = trunc i32 %7734 to i8
  %7736 = shl i8 1, %7735
  %7737 = or i8 %7716, %7736
  %7738 = select i1 %7727, i8 %7737, i8 %7716
  store i8 %7738, ptr %frame.active, align 1
  %7739 = load <8 x i32>, ptr %frame.static.id, align 32
  %7740 = extractelement <8 x i32> %7739, i32 %7734
  %7741 = select i1 %7727, i32 35, i32 %7740
  %7742 = load <8 x i32>, ptr %frame.static.id, align 32
  %7743 = insertelement <8 x i32> %7742, i32 %7741, i32 %7734
  store <8 x i32> %7743, ptr %frame.static.id, align 32
  %7744 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7745 = extractelement <8 x i32> %7744, i32 %7734
  %7746 = select i1 %7727, i32 %7712, i32 %7745
  %7747 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7748 = insertelement <8 x i32> %7747, i32 %7746, i32 %7734
  store <8 x i32> %7748, ptr %frame.parent.token, align 32
  %7749 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7734
  %7750 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7734
  %7751 = load <8 x i1>, ptr %7749, align 1
  %7752 = load <8 x i1>, ptr %7750, align 1
  %7753 = select i1 %7727, <8 x i1> %1889, <8 x i1> %7751
  store <8 x i1> %7753, ptr %7749, align 1
  %7754 = select i1 %7727, <8 x i1> zeroinitializer, <8 x i1> %7752
  store <8 x i1> %7754, ptr %7750, align 1
  %7755 = add i32 %7734, 1
  %7756 = select i1 %7725, i32 %7712, i32 %7755
  %7757 = select i1 true, i32 %7756, i32 %7712
  store i32 %7757, ptr %current.token, align 4
  %7758 = load i32, ptr %current.token, align 4
  %7759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1896)
  %7760 = load i32, ptr %ready.count, align 4
  %7761 = icmp uge i32 %7760, 8
  %7762 = and i1 %7759, %7761
  br i1 %7762, label %ready.overflow.trap1528, label %ready.overflow.resume1529

ready.overflow.trap1528:                          ; preds = %convergence.overflow.resume1527
  call void @llvm.trap()
  unreachable

ready.overflow.resume1529:                        ; preds = %convergence.overflow.resume1527
  %7763 = select i1 %7759, i32 %7760, i32 0
  %7764 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7763
  %7765 = load <8 x i1>, ptr %7764, align 1
  %7766 = select i1 %7759, <8 x i1> %1896, <8 x i1> %7765
  store <8 x i1> %7766, ptr %7764, align 1
  %7767 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7763
  %7768 = load i32, ptr %7767, align 4
  %7769 = select i1 %7759, i32 104, i32 %7768
  store i32 %7769, ptr %7767, align 4
  %7770 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7763
  %7771 = load i32, ptr %7770, align 4
  %7772 = select i1 %7759, i32 %7758, i32 %7771
  store i32 %7772, ptr %7770, align 4
  %7773 = add i32 %7760, 1
  %7774 = select i1 %7759, i32 %7773, i32 %7760
  store i32 %7774, ptr %ready.count, align 4
  %7775 = load <8 x i1>, ptr %runnable.mask, align 1
  %7776 = or <8 x i1> %7775, %1896
  store <8 x i1> %7776, ptr %runnable.mask, align 1
  store <8 x i1> %1898, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1530:                        ; preds = %varying.coherent1525
  store <8 x i1> %1889, ptr %current.mask, align 1
  %7777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1889)
  br i1 %7777, label %schedule.104, label %scheduler.loop

varying.coherent.false1531:                       ; preds = %varying.coherent1525
  store <8 x i1> %1889, ptr %current.mask, align 1
  %7778 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1889)
  br i1 %7778, label %schedule.107, label %scheduler.loop

varying.divergent1538:                            ; preds = %schedule.104
  %7779 = load i32, ptr %current.token, align 4
  %7780 = icmp ne i32 %7779, 0
  %7781 = sub i32 %7779, 1
  %7782 = select i1 %7780, i32 %7781, i32 0
  %7783 = load i8, ptr %frame.active, align 1
  %7784 = trunc i32 %7782 to i8
  %7785 = shl i8 1, %7784
  %7786 = and i8 %7783, %7785
  %7787 = icmp ne i8 %7786, 0
  %7788 = load <8 x i32>, ptr %frame.static.id, align 32
  %7789 = extractelement <8 x i32> %7788, i32 %7782
  %7790 = icmp eq i32 %7789, 36
  %7791 = and i1 %7787, %7790
  %7792 = and i1 %7780, %7791
  %7793 = xor i1 %7792, true
  %7794 = and i1 true, %7793
  %7795 = xor i8 %7783, -1
  %7796 = icmp ne i8 %7795, 0
  %7797 = xor i1 %7796, true
  %7798 = and i1 %7794, %7797
  br i1 %7798, label %convergence.overflow.trap1540, label %convergence.overflow.resume1541

varying.coherent1539:                             ; preds = %schedule.104
  br i1 %1957, label %varying.coherent.true1544, label %varying.coherent.false1545

convergence.overflow.trap1540:                    ; preds = %varying.divergent1538
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1541:                  ; preds = %varying.divergent1538
  %7799 = call i8 @llvm.cttz.i8(i8 %7795, i1 false)
  %7800 = zext i8 %7799 to i32
  %7801 = select i1 %7796, i32 %7800, i32 0
  %7802 = trunc i32 %7801 to i8
  %7803 = shl i8 1, %7802
  %7804 = or i8 %7783, %7803
  %7805 = select i1 %7794, i8 %7804, i8 %7783
  store i8 %7805, ptr %frame.active, align 1
  %7806 = load <8 x i32>, ptr %frame.static.id, align 32
  %7807 = extractelement <8 x i32> %7806, i32 %7801
  %7808 = select i1 %7794, i32 36, i32 %7807
  %7809 = load <8 x i32>, ptr %frame.static.id, align 32
  %7810 = insertelement <8 x i32> %7809, i32 %7808, i32 %7801
  store <8 x i32> %7810, ptr %frame.static.id, align 32
  %7811 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7812 = extractelement <8 x i32> %7811, i32 %7801
  %7813 = select i1 %7794, i32 %7779, i32 %7812
  %7814 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7815 = insertelement <8 x i32> %7814, i32 %7813, i32 %7801
  store <8 x i32> %7815, ptr %frame.parent.token, align 32
  %7816 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7801
  %7817 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7801
  %7818 = load <8 x i1>, ptr %7816, align 1
  %7819 = load <8 x i1>, ptr %7817, align 1
  %7820 = select i1 %7794, <8 x i1> %1902, <8 x i1> %7818
  store <8 x i1> %7820, ptr %7816, align 1
  %7821 = select i1 %7794, <8 x i1> zeroinitializer, <8 x i1> %7819
  store <8 x i1> %7821, ptr %7817, align 1
  %7822 = add i32 %7801, 1
  %7823 = select i1 %7792, i32 %7779, i32 %7822
  %7824 = select i1 true, i32 %7823, i32 %7779
  store i32 %7824, ptr %current.token, align 4
  %7825 = load i32, ptr %current.token, align 4
  %7826 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1954)
  %7827 = load i32, ptr %ready.count, align 4
  %7828 = icmp uge i32 %7827, 8
  %7829 = and i1 %7826, %7828
  br i1 %7829, label %ready.overflow.trap1542, label %ready.overflow.resume1543

ready.overflow.trap1542:                          ; preds = %convergence.overflow.resume1541
  call void @llvm.trap()
  unreachable

ready.overflow.resume1543:                        ; preds = %convergence.overflow.resume1541
  %7830 = select i1 %7826, i32 %7827, i32 0
  %7831 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7830
  %7832 = load <8 x i1>, ptr %7831, align 1
  %7833 = select i1 %7826, <8 x i1> %1954, <8 x i1> %7832
  store <8 x i1> %7833, ptr %7831, align 1
  %7834 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7830
  %7835 = load i32, ptr %7834, align 4
  %7836 = select i1 %7826, i32 105, i32 %7835
  store i32 %7836, ptr %7834, align 4
  %7837 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7830
  %7838 = load i32, ptr %7837, align 4
  %7839 = select i1 %7826, i32 %7825, i32 %7838
  store i32 %7839, ptr %7837, align 4
  %7840 = add i32 %7827, 1
  %7841 = select i1 %7826, i32 %7840, i32 %7827
  store i32 %7841, ptr %ready.count, align 4
  %7842 = load <8 x i1>, ptr %runnable.mask, align 1
  %7843 = or <8 x i1> %7842, %1954
  store <8 x i1> %7843, ptr %runnable.mask, align 1
  store <8 x i1> %1956, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1544:                        ; preds = %varying.coherent1539
  store <8 x i1> %1902, ptr %current.mask, align 1
  %7844 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1902)
  br i1 %7844, label %schedule.105, label %scheduler.loop

varying.coherent.false1545:                       ; preds = %varying.coherent1539
  store <8 x i1> %1902, ptr %current.mask, align 1
  %7845 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1902)
  br i1 %7845, label %schedule.106, label %scheduler.loop

convergence.cascade1548:                          ; preds = %convergence.cascade1548, %schedule.106
  %convergence.cascade.flow1552 = phi <8 x i1> [ %1970, %schedule.106 ], [ %7888, %convergence.cascade1548 ]
  %convergence.cascade.depth1553 = phi i32 [ 0, %schedule.106 ], [ %7889, %convergence.cascade1548 ]
  %7846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1552)
  %7847 = load i32, ptr %current.token, align 4
  %7848 = icmp ne i32 %7847, 0
  %7849 = and i1 %7846, %7848
  %7850 = sub i32 %7847, 1
  %7851 = select i1 %7849, i32 %7850, i32 0
  %7852 = load i8, ptr %frame.active, align 1
  %7853 = trunc i32 %7851 to i8
  %7854 = shl i8 1, %7853
  %7855 = and i8 %7852, %7854
  %7856 = icmp ne i8 %7855, 0
  %7857 = load <8 x i32>, ptr %frame.static.id, align 32
  %7858 = extractelement <8 x i32> %7857, i32 %7851
  %convergence.target.pointer1554 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7858
  %convergence.dynamic.target1555 = load i32, ptr %convergence.target.pointer1554, align 4
  %7859 = icmp eq i32 %convergence.dynamic.target1555, 106
  %7860 = and i1 %7856, %7859
  %7861 = and i1 %7849, %7860
  %7862 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7851
  %7863 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7851
  %7864 = load <8 x i1>, ptr %7862, align 1
  %7865 = load <8 x i1>, ptr %7863, align 1
  %7866 = or <8 x i1> %7865, %convergence.cascade.flow1552
  %7867 = load <8 x i1>, ptr %live.mask, align 1
  %7868 = and <8 x i1> %7864, %7867
  %7869 = icmp eq <8 x i1> %7866, %7868
  %7870 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7869)
  %7871 = and i1 %7861, %7870
  %7872 = select i1 %7871, <8 x i1> zeroinitializer, <8 x i1> %7866
  %7873 = select i1 %7861, <8 x i1> %7872, <8 x i1> %7865
  store <8 x i1> %7873, ptr %7863, align 1
  %7874 = select i1 %7871, <8 x i1> zeroinitializer, <8 x i1> %7864
  store <8 x i1> %7874, ptr %7862, align 1
  %7875 = trunc i32 %7851 to i8
  %7876 = shl i8 1, %7875
  %7877 = xor i8 %7876, -1
  %7878 = and i8 %7852, %7877
  %7879 = select i1 %7871, i8 %7878, i8 %7852
  store i8 %7879, ptr %frame.active, align 1
  %.splatinsert1556 = insertelement <8 x i1> poison, i1 %7861, i64 0
  %.splat1557 = shufflevector <8 x i1> %.splatinsert1556, <8 x i1> poison, <8 x i32> zeroinitializer
  %7880 = and <8 x i1> %convergence.cascade.flow1552, %.splat1557
  %7881 = load <8 x i1>, ptr %runnable.mask, align 1
  %7882 = xor <8 x i1> %7880, splat (i1 true)
  %7883 = and <8 x i1> %7881, %7882
  store <8 x i1> %7883, ptr %runnable.mask, align 1
  %.splatinsert1558 = insertelement <8 x i1> poison, i1 %7871, i64 0
  %.splat1559 = shufflevector <8 x i1> %.splatinsert1558, <8 x i1> poison, <8 x i32> zeroinitializer
  %7884 = select <8 x i1> %.splat1559, <8 x i1> %7866, <8 x i1> zeroinitializer
  %7885 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7886 = extractelement <8 x i32> %7885, i32 %7851
  %7887 = select i1 %7871, i32 %7886, i32 %7847
  store i32 %7887, ptr %current.token, align 4
  %.splatinsert1560 = insertelement <8 x i1> poison, i1 %7861, i64 0
  %.splat1561 = shufflevector <8 x i1> %.splatinsert1560, <8 x i1> poison, <8 x i32> zeroinitializer
  %7888 = select <8 x i1> %.splat1561, <8 x i1> %7884, <8 x i1> %convergence.cascade.flow1552
  %7889 = add i32 %convergence.cascade.depth1553, 1
  %7890 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7888)
  %7891 = icmp ult i32 %7889, 8
  %7892 = and i1 %7890, %7891
  %7893 = and i1 %7861, %7892
  %convergence.parent.token1562 = load i32, ptr %current.token, align 4
  %convergence.parent.present1563 = icmp ne i32 %convergence.parent.token1562, 0
  %7894 = and i1 %7893, %convergence.parent.present1563
  br i1 %7894, label %convergence.cascade1548, label %convergence.cascade.exit1549

convergence.cascade.exit1549:                     ; preds = %convergence.cascade1548, %schedule.106
  %convergence.cascade.result1564 = phi <8 x i1> [ %1970, %schedule.106 ], [ %7888, %convergence.cascade1548 ]
  %7895 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1564)
  br i1 %7895, label %convergence.target.106.ready, label %scheduler.loop

convergence.target.106.ready:                     ; preds = %convergence.cascade.exit1549
  %7896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1564)
  %7897 = bitcast <8 x i1> %convergence.cascade.result1564 to i8
  %7898 = call i8 @llvm.cttz.i8(i8 %7897, i1 false)
  %7899 = zext i8 %7898 to i32
  %7900 = select i1 %7896, i32 %7899, i32 0
  %.state1565 = load <8 x i64>, ptr %.slot207, align 64
  %7901 = add <8 x i64> %.state1565, splat (i64 1)
  %7902 = load <8 x i64>, ptr %.slot207, align 64
  %7903 = select <8 x i1> %convergence.cascade.result1564, <8 x i64> %7901, <8 x i64> %7902
  store <8 x i64> %7903, ptr %.slot207, align 64
  store <8 x i1> %convergence.cascade.result1564, ptr %current.mask, align 1
  %7904 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1564)
  br i1 %7904, label %schedule.103, label %scheduler.loop

convergence.cascade1566:                          ; preds = %convergence.cascade1566, %schedule.107
  %convergence.cascade.flow1570 = phi <8 x i1> [ %1971, %schedule.107 ], [ %7947, %convergence.cascade1566 ]
  %convergence.cascade.depth1571 = phi i32 [ 0, %schedule.107 ], [ %7948, %convergence.cascade1566 ]
  %7905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1570)
  %7906 = load i32, ptr %current.token, align 4
  %7907 = icmp ne i32 %7906, 0
  %7908 = and i1 %7905, %7907
  %7909 = sub i32 %7906, 1
  %7910 = select i1 %7908, i32 %7909, i32 0
  %7911 = load i8, ptr %frame.active, align 1
  %7912 = trunc i32 %7910 to i8
  %7913 = shl i8 1, %7912
  %7914 = and i8 %7911, %7913
  %7915 = icmp ne i8 %7914, 0
  %7916 = load <8 x i32>, ptr %frame.static.id, align 32
  %7917 = extractelement <8 x i32> %7916, i32 %7910
  %convergence.target.pointer1572 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7917
  %convergence.dynamic.target1573 = load i32, ptr %convergence.target.pointer1572, align 4
  %7918 = icmp eq i32 %convergence.dynamic.target1573, 107
  %7919 = and i1 %7915, %7918
  %7920 = and i1 %7908, %7919
  %7921 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7910
  %7922 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7910
  %7923 = load <8 x i1>, ptr %7921, align 1
  %7924 = load <8 x i1>, ptr %7922, align 1
  %7925 = or <8 x i1> %7924, %convergence.cascade.flow1570
  %7926 = load <8 x i1>, ptr %live.mask, align 1
  %7927 = and <8 x i1> %7923, %7926
  %7928 = icmp eq <8 x i1> %7925, %7927
  %7929 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7928)
  %7930 = and i1 %7920, %7929
  %7931 = select i1 %7930, <8 x i1> zeroinitializer, <8 x i1> %7925
  %7932 = select i1 %7920, <8 x i1> %7931, <8 x i1> %7924
  store <8 x i1> %7932, ptr %7922, align 1
  %7933 = select i1 %7930, <8 x i1> zeroinitializer, <8 x i1> %7923
  store <8 x i1> %7933, ptr %7921, align 1
  %7934 = trunc i32 %7910 to i8
  %7935 = shl i8 1, %7934
  %7936 = xor i8 %7935, -1
  %7937 = and i8 %7911, %7936
  %7938 = select i1 %7930, i8 %7937, i8 %7911
  store i8 %7938, ptr %frame.active, align 1
  %.splatinsert1574 = insertelement <8 x i1> poison, i1 %7920, i64 0
  %.splat1575 = shufflevector <8 x i1> %.splatinsert1574, <8 x i1> poison, <8 x i32> zeroinitializer
  %7939 = and <8 x i1> %convergence.cascade.flow1570, %.splat1575
  %7940 = load <8 x i1>, ptr %runnable.mask, align 1
  %7941 = xor <8 x i1> %7939, splat (i1 true)
  %7942 = and <8 x i1> %7940, %7941
  store <8 x i1> %7942, ptr %runnable.mask, align 1
  %.splatinsert1576 = insertelement <8 x i1> poison, i1 %7930, i64 0
  %.splat1577 = shufflevector <8 x i1> %.splatinsert1576, <8 x i1> poison, <8 x i32> zeroinitializer
  %7943 = select <8 x i1> %.splat1577, <8 x i1> %7925, <8 x i1> zeroinitializer
  %7944 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7945 = extractelement <8 x i32> %7944, i32 %7910
  %7946 = select i1 %7930, i32 %7945, i32 %7906
  store i32 %7946, ptr %current.token, align 4
  %.splatinsert1578 = insertelement <8 x i1> poison, i1 %7920, i64 0
  %.splat1579 = shufflevector <8 x i1> %.splatinsert1578, <8 x i1> poison, <8 x i32> zeroinitializer
  %7947 = select <8 x i1> %.splat1579, <8 x i1> %7943, <8 x i1> %convergence.cascade.flow1570
  %7948 = add i32 %convergence.cascade.depth1571, 1
  %7949 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7947)
  %7950 = icmp ult i32 %7948, 8
  %7951 = and i1 %7949, %7950
  %7952 = and i1 %7920, %7951
  %convergence.parent.token1580 = load i32, ptr %current.token, align 4
  %convergence.parent.present1581 = icmp ne i32 %convergence.parent.token1580, 0
  %7953 = and i1 %7952, %convergence.parent.present1581
  br i1 %7953, label %convergence.cascade1566, label %convergence.cascade.exit1567

convergence.cascade.exit1567:                     ; preds = %convergence.cascade1566, %schedule.107
  %convergence.cascade.result1582 = phi <8 x i1> [ %1971, %schedule.107 ], [ %7947, %convergence.cascade1566 ]
  %7954 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1582)
  br i1 %7954, label %convergence.target.107.ready, label %scheduler.loop

convergence.target.107.ready:                     ; preds = %convergence.cascade.exit1567
  %7955 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1582)
  %7956 = bitcast <8 x i1> %convergence.cascade.result1582 to i8
  %7957 = call i8 @llvm.cttz.i8(i8 %7956, i1 false)
  %7958 = zext i8 %7957 to i32
  %7959 = select i1 %7955, i32 %7958, i32 0
  %7960 = load <8 x i1>, ptr %live.mask, align 1
  %7961 = xor <8 x i1> %convergence.cascade.result1582, splat (i1 true)
  %7962 = and <8 x i1> %7960, %7961
  store <8 x i1> %7962, ptr %live.mask, align 1
  %7963 = load <8 x i1>, ptr %runnable.mask, align 1
  %7964 = xor <8 x i1> %convergence.cascade.result1582, splat (i1 true)
  %7965 = and <8 x i1> %7963, %7964
  store <8 x i1> %7965, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.107.ready
  %7966 = load i8, ptr %frame.active, align 1
  %7967 = and i8 %7966, 1
  %7968 = icmp ne i8 %7967, 0
  %7969 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %7970 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %7971 = load <8 x i1>, ptr %7969, align 1
  %7972 = load <8 x i1>, ptr %7970, align 1
  %7973 = and <8 x i1> %7971, %7962
  %7974 = icmp eq <8 x i1> %7972, %7973
  %7975 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7974)
  %7976 = and i1 %7968, %7975
  %.splatinsert1583 = insertelement <8 x i1> poison, i1 %7976, i64 0
  %.splat1584 = shufflevector <8 x i1> %.splatinsert1583, <8 x i1> poison, <8 x i32> zeroinitializer
  %7977 = select <8 x i1> %.splat1584, <8 x i1> %7972, <8 x i1> zeroinitializer
  %7978 = select i1 %7976, <8 x i1> zeroinitializer, <8 x i1> %7973
  store <8 x i1> %7978, ptr %7969, align 1
  %7979 = select i1 %7976, <8 x i1> zeroinitializer, <8 x i1> %7972
  store <8 x i1> %7979, ptr %7970, align 1
  %7980 = and i8 %7966, -2
  %7981 = select i1 %7976, i8 %7980, i8 %7966
  store i8 %7981, ptr %frame.active, align 1
  %7982 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7983 = extractelement <8 x i32> %7982, i32 0
  %7984 = load <8 x i32>, ptr %frame.static.id, align 32
  %7985 = extractelement <8 x i32> %7984, i32 0
  %convergence.target.pointer1585 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %7985
  %convergence.dynamic.target1586 = load i32, ptr %convergence.target.pointer1585, align 4
  %7986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7977)
  %7987 = load i32, ptr %ready.count, align 4
  %7988 = icmp uge i32 %7987, 8
  %7989 = and i1 %7986, %7988
  br i1 %7989, label %ready.overflow.trap1587, label %ready.overflow.resume1588

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume1630, %convergence.target.107.ready
  br label %scheduler.loop

ready.overflow.trap1587:                          ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume1588:                        ; preds = %return.frame.cleanup
  %7990 = select i1 %7986, i32 %7987, i32 0
  %7991 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7990
  %7992 = load <8 x i1>, ptr %7991, align 1
  %7993 = select i1 %7986, <8 x i1> %7977, <8 x i1> %7992
  store <8 x i1> %7993, ptr %7991, align 1
  %7994 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7990
  %7995 = load i32, ptr %7994, align 4
  %7996 = select i1 %7986, i32 %convergence.dynamic.target1586, i32 %7995
  store i32 %7996, ptr %7994, align 4
  %7997 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7990
  %7998 = load i32, ptr %7997, align 4
  %7999 = select i1 %7986, i32 %7983, i32 %7998
  store i32 %7999, ptr %7997, align 4
  %8000 = add i32 %7987, 1
  %8001 = select i1 %7986, i32 %8000, i32 %7987
  store i32 %8001, ptr %ready.count, align 4
  %8002 = load <8 x i1>, ptr %runnable.mask, align 1
  %8003 = or <8 x i1> %8002, %7977
  store <8 x i1> %8003, ptr %runnable.mask, align 1
  %8004 = load i8, ptr %frame.active, align 1
  %8005 = and i8 %8004, 2
  %8006 = icmp ne i8 %8005, 0
  %8007 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %8008 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %8009 = load <8 x i1>, ptr %8007, align 1
  %8010 = load <8 x i1>, ptr %8008, align 1
  %8011 = and <8 x i1> %8009, %7962
  %8012 = icmp eq <8 x i1> %8010, %8011
  %8013 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8012)
  %8014 = and i1 %8006, %8013
  %.splatinsert1589 = insertelement <8 x i1> poison, i1 %8014, i64 0
  %.splat1590 = shufflevector <8 x i1> %.splatinsert1589, <8 x i1> poison, <8 x i32> zeroinitializer
  %8015 = select <8 x i1> %.splat1590, <8 x i1> %8010, <8 x i1> zeroinitializer
  %8016 = select i1 %8014, <8 x i1> zeroinitializer, <8 x i1> %8011
  store <8 x i1> %8016, ptr %8007, align 1
  %8017 = select i1 %8014, <8 x i1> zeroinitializer, <8 x i1> %8010
  store <8 x i1> %8017, ptr %8008, align 1
  %8018 = and i8 %8004, -3
  %8019 = select i1 %8014, i8 %8018, i8 %8004
  store i8 %8019, ptr %frame.active, align 1
  %8020 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8021 = extractelement <8 x i32> %8020, i32 1
  %8022 = load <8 x i32>, ptr %frame.static.id, align 32
  %8023 = extractelement <8 x i32> %8022, i32 1
  %convergence.target.pointer1591 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8023
  %convergence.dynamic.target1592 = load i32, ptr %convergence.target.pointer1591, align 4
  %8024 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8015)
  %8025 = load i32, ptr %ready.count, align 4
  %8026 = icmp uge i32 %8025, 8
  %8027 = and i1 %8024, %8026
  br i1 %8027, label %ready.overflow.trap1593, label %ready.overflow.resume1594

ready.overflow.trap1593:                          ; preds = %ready.overflow.resume1588
  call void @llvm.trap()
  unreachable

ready.overflow.resume1594:                        ; preds = %ready.overflow.resume1588
  %8028 = select i1 %8024, i32 %8025, i32 0
  %8029 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8028
  %8030 = load <8 x i1>, ptr %8029, align 1
  %8031 = select i1 %8024, <8 x i1> %8015, <8 x i1> %8030
  store <8 x i1> %8031, ptr %8029, align 1
  %8032 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8028
  %8033 = load i32, ptr %8032, align 4
  %8034 = select i1 %8024, i32 %convergence.dynamic.target1592, i32 %8033
  store i32 %8034, ptr %8032, align 4
  %8035 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8028
  %8036 = load i32, ptr %8035, align 4
  %8037 = select i1 %8024, i32 %8021, i32 %8036
  store i32 %8037, ptr %8035, align 4
  %8038 = add i32 %8025, 1
  %8039 = select i1 %8024, i32 %8038, i32 %8025
  store i32 %8039, ptr %ready.count, align 4
  %8040 = load <8 x i1>, ptr %runnable.mask, align 1
  %8041 = or <8 x i1> %8040, %8015
  store <8 x i1> %8041, ptr %runnable.mask, align 1
  %8042 = load i8, ptr %frame.active, align 1
  %8043 = and i8 %8042, 4
  %8044 = icmp ne i8 %8043, 0
  %8045 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %8046 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %8047 = load <8 x i1>, ptr %8045, align 1
  %8048 = load <8 x i1>, ptr %8046, align 1
  %8049 = and <8 x i1> %8047, %7962
  %8050 = icmp eq <8 x i1> %8048, %8049
  %8051 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8050)
  %8052 = and i1 %8044, %8051
  %.splatinsert1595 = insertelement <8 x i1> poison, i1 %8052, i64 0
  %.splat1596 = shufflevector <8 x i1> %.splatinsert1595, <8 x i1> poison, <8 x i32> zeroinitializer
  %8053 = select <8 x i1> %.splat1596, <8 x i1> %8048, <8 x i1> zeroinitializer
  %8054 = select i1 %8052, <8 x i1> zeroinitializer, <8 x i1> %8049
  store <8 x i1> %8054, ptr %8045, align 1
  %8055 = select i1 %8052, <8 x i1> zeroinitializer, <8 x i1> %8048
  store <8 x i1> %8055, ptr %8046, align 1
  %8056 = and i8 %8042, -5
  %8057 = select i1 %8052, i8 %8056, i8 %8042
  store i8 %8057, ptr %frame.active, align 1
  %8058 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8059 = extractelement <8 x i32> %8058, i32 2
  %8060 = load <8 x i32>, ptr %frame.static.id, align 32
  %8061 = extractelement <8 x i32> %8060, i32 2
  %convergence.target.pointer1597 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8061
  %convergence.dynamic.target1598 = load i32, ptr %convergence.target.pointer1597, align 4
  %8062 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8053)
  %8063 = load i32, ptr %ready.count, align 4
  %8064 = icmp uge i32 %8063, 8
  %8065 = and i1 %8062, %8064
  br i1 %8065, label %ready.overflow.trap1599, label %ready.overflow.resume1600

ready.overflow.trap1599:                          ; preds = %ready.overflow.resume1594
  call void @llvm.trap()
  unreachable

ready.overflow.resume1600:                        ; preds = %ready.overflow.resume1594
  %8066 = select i1 %8062, i32 %8063, i32 0
  %8067 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8066
  %8068 = load <8 x i1>, ptr %8067, align 1
  %8069 = select i1 %8062, <8 x i1> %8053, <8 x i1> %8068
  store <8 x i1> %8069, ptr %8067, align 1
  %8070 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8066
  %8071 = load i32, ptr %8070, align 4
  %8072 = select i1 %8062, i32 %convergence.dynamic.target1598, i32 %8071
  store i32 %8072, ptr %8070, align 4
  %8073 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8066
  %8074 = load i32, ptr %8073, align 4
  %8075 = select i1 %8062, i32 %8059, i32 %8074
  store i32 %8075, ptr %8073, align 4
  %8076 = add i32 %8063, 1
  %8077 = select i1 %8062, i32 %8076, i32 %8063
  store i32 %8077, ptr %ready.count, align 4
  %8078 = load <8 x i1>, ptr %runnable.mask, align 1
  %8079 = or <8 x i1> %8078, %8053
  store <8 x i1> %8079, ptr %runnable.mask, align 1
  %8080 = load i8, ptr %frame.active, align 1
  %8081 = and i8 %8080, 8
  %8082 = icmp ne i8 %8081, 0
  %8083 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %8084 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %8085 = load <8 x i1>, ptr %8083, align 1
  %8086 = load <8 x i1>, ptr %8084, align 1
  %8087 = and <8 x i1> %8085, %7962
  %8088 = icmp eq <8 x i1> %8086, %8087
  %8089 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8088)
  %8090 = and i1 %8082, %8089
  %.splatinsert1601 = insertelement <8 x i1> poison, i1 %8090, i64 0
  %.splat1602 = shufflevector <8 x i1> %.splatinsert1601, <8 x i1> poison, <8 x i32> zeroinitializer
  %8091 = select <8 x i1> %.splat1602, <8 x i1> %8086, <8 x i1> zeroinitializer
  %8092 = select i1 %8090, <8 x i1> zeroinitializer, <8 x i1> %8087
  store <8 x i1> %8092, ptr %8083, align 1
  %8093 = select i1 %8090, <8 x i1> zeroinitializer, <8 x i1> %8086
  store <8 x i1> %8093, ptr %8084, align 1
  %8094 = and i8 %8080, -9
  %8095 = select i1 %8090, i8 %8094, i8 %8080
  store i8 %8095, ptr %frame.active, align 1
  %8096 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8097 = extractelement <8 x i32> %8096, i32 3
  %8098 = load <8 x i32>, ptr %frame.static.id, align 32
  %8099 = extractelement <8 x i32> %8098, i32 3
  %convergence.target.pointer1603 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8099
  %convergence.dynamic.target1604 = load i32, ptr %convergence.target.pointer1603, align 4
  %8100 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8091)
  %8101 = load i32, ptr %ready.count, align 4
  %8102 = icmp uge i32 %8101, 8
  %8103 = and i1 %8100, %8102
  br i1 %8103, label %ready.overflow.trap1605, label %ready.overflow.resume1606

ready.overflow.trap1605:                          ; preds = %ready.overflow.resume1600
  call void @llvm.trap()
  unreachable

ready.overflow.resume1606:                        ; preds = %ready.overflow.resume1600
  %8104 = select i1 %8100, i32 %8101, i32 0
  %8105 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8104
  %8106 = load <8 x i1>, ptr %8105, align 1
  %8107 = select i1 %8100, <8 x i1> %8091, <8 x i1> %8106
  store <8 x i1> %8107, ptr %8105, align 1
  %8108 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8104
  %8109 = load i32, ptr %8108, align 4
  %8110 = select i1 %8100, i32 %convergence.dynamic.target1604, i32 %8109
  store i32 %8110, ptr %8108, align 4
  %8111 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8104
  %8112 = load i32, ptr %8111, align 4
  %8113 = select i1 %8100, i32 %8097, i32 %8112
  store i32 %8113, ptr %8111, align 4
  %8114 = add i32 %8101, 1
  %8115 = select i1 %8100, i32 %8114, i32 %8101
  store i32 %8115, ptr %ready.count, align 4
  %8116 = load <8 x i1>, ptr %runnable.mask, align 1
  %8117 = or <8 x i1> %8116, %8091
  store <8 x i1> %8117, ptr %runnable.mask, align 1
  %8118 = load i8, ptr %frame.active, align 1
  %8119 = and i8 %8118, 16
  %8120 = icmp ne i8 %8119, 0
  %8121 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %8122 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %8123 = load <8 x i1>, ptr %8121, align 1
  %8124 = load <8 x i1>, ptr %8122, align 1
  %8125 = and <8 x i1> %8123, %7962
  %8126 = icmp eq <8 x i1> %8124, %8125
  %8127 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8126)
  %8128 = and i1 %8120, %8127
  %.splatinsert1607 = insertelement <8 x i1> poison, i1 %8128, i64 0
  %.splat1608 = shufflevector <8 x i1> %.splatinsert1607, <8 x i1> poison, <8 x i32> zeroinitializer
  %8129 = select <8 x i1> %.splat1608, <8 x i1> %8124, <8 x i1> zeroinitializer
  %8130 = select i1 %8128, <8 x i1> zeroinitializer, <8 x i1> %8125
  store <8 x i1> %8130, ptr %8121, align 1
  %8131 = select i1 %8128, <8 x i1> zeroinitializer, <8 x i1> %8124
  store <8 x i1> %8131, ptr %8122, align 1
  %8132 = and i8 %8118, -17
  %8133 = select i1 %8128, i8 %8132, i8 %8118
  store i8 %8133, ptr %frame.active, align 1
  %8134 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8135 = extractelement <8 x i32> %8134, i32 4
  %8136 = load <8 x i32>, ptr %frame.static.id, align 32
  %8137 = extractelement <8 x i32> %8136, i32 4
  %convergence.target.pointer1609 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8137
  %convergence.dynamic.target1610 = load i32, ptr %convergence.target.pointer1609, align 4
  %8138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8129)
  %8139 = load i32, ptr %ready.count, align 4
  %8140 = icmp uge i32 %8139, 8
  %8141 = and i1 %8138, %8140
  br i1 %8141, label %ready.overflow.trap1611, label %ready.overflow.resume1612

ready.overflow.trap1611:                          ; preds = %ready.overflow.resume1606
  call void @llvm.trap()
  unreachable

ready.overflow.resume1612:                        ; preds = %ready.overflow.resume1606
  %8142 = select i1 %8138, i32 %8139, i32 0
  %8143 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8142
  %8144 = load <8 x i1>, ptr %8143, align 1
  %8145 = select i1 %8138, <8 x i1> %8129, <8 x i1> %8144
  store <8 x i1> %8145, ptr %8143, align 1
  %8146 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8142
  %8147 = load i32, ptr %8146, align 4
  %8148 = select i1 %8138, i32 %convergence.dynamic.target1610, i32 %8147
  store i32 %8148, ptr %8146, align 4
  %8149 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8142
  %8150 = load i32, ptr %8149, align 4
  %8151 = select i1 %8138, i32 %8135, i32 %8150
  store i32 %8151, ptr %8149, align 4
  %8152 = add i32 %8139, 1
  %8153 = select i1 %8138, i32 %8152, i32 %8139
  store i32 %8153, ptr %ready.count, align 4
  %8154 = load <8 x i1>, ptr %runnable.mask, align 1
  %8155 = or <8 x i1> %8154, %8129
  store <8 x i1> %8155, ptr %runnable.mask, align 1
  %8156 = load i8, ptr %frame.active, align 1
  %8157 = and i8 %8156, 32
  %8158 = icmp ne i8 %8157, 0
  %8159 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %8160 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %8161 = load <8 x i1>, ptr %8159, align 1
  %8162 = load <8 x i1>, ptr %8160, align 1
  %8163 = and <8 x i1> %8161, %7962
  %8164 = icmp eq <8 x i1> %8162, %8163
  %8165 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8164)
  %8166 = and i1 %8158, %8165
  %.splatinsert1613 = insertelement <8 x i1> poison, i1 %8166, i64 0
  %.splat1614 = shufflevector <8 x i1> %.splatinsert1613, <8 x i1> poison, <8 x i32> zeroinitializer
  %8167 = select <8 x i1> %.splat1614, <8 x i1> %8162, <8 x i1> zeroinitializer
  %8168 = select i1 %8166, <8 x i1> zeroinitializer, <8 x i1> %8163
  store <8 x i1> %8168, ptr %8159, align 1
  %8169 = select i1 %8166, <8 x i1> zeroinitializer, <8 x i1> %8162
  store <8 x i1> %8169, ptr %8160, align 1
  %8170 = and i8 %8156, -33
  %8171 = select i1 %8166, i8 %8170, i8 %8156
  store i8 %8171, ptr %frame.active, align 1
  %8172 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8173 = extractelement <8 x i32> %8172, i32 5
  %8174 = load <8 x i32>, ptr %frame.static.id, align 32
  %8175 = extractelement <8 x i32> %8174, i32 5
  %convergence.target.pointer1615 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8175
  %convergence.dynamic.target1616 = load i32, ptr %convergence.target.pointer1615, align 4
  %8176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8167)
  %8177 = load i32, ptr %ready.count, align 4
  %8178 = icmp uge i32 %8177, 8
  %8179 = and i1 %8176, %8178
  br i1 %8179, label %ready.overflow.trap1617, label %ready.overflow.resume1618

ready.overflow.trap1617:                          ; preds = %ready.overflow.resume1612
  call void @llvm.trap()
  unreachable

ready.overflow.resume1618:                        ; preds = %ready.overflow.resume1612
  %8180 = select i1 %8176, i32 %8177, i32 0
  %8181 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8180
  %8182 = load <8 x i1>, ptr %8181, align 1
  %8183 = select i1 %8176, <8 x i1> %8167, <8 x i1> %8182
  store <8 x i1> %8183, ptr %8181, align 1
  %8184 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8180
  %8185 = load i32, ptr %8184, align 4
  %8186 = select i1 %8176, i32 %convergence.dynamic.target1616, i32 %8185
  store i32 %8186, ptr %8184, align 4
  %8187 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8180
  %8188 = load i32, ptr %8187, align 4
  %8189 = select i1 %8176, i32 %8173, i32 %8188
  store i32 %8189, ptr %8187, align 4
  %8190 = add i32 %8177, 1
  %8191 = select i1 %8176, i32 %8190, i32 %8177
  store i32 %8191, ptr %ready.count, align 4
  %8192 = load <8 x i1>, ptr %runnable.mask, align 1
  %8193 = or <8 x i1> %8192, %8167
  store <8 x i1> %8193, ptr %runnable.mask, align 1
  %8194 = load i8, ptr %frame.active, align 1
  %8195 = and i8 %8194, 64
  %8196 = icmp ne i8 %8195, 0
  %8197 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %8198 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %8199 = load <8 x i1>, ptr %8197, align 1
  %8200 = load <8 x i1>, ptr %8198, align 1
  %8201 = and <8 x i1> %8199, %7962
  %8202 = icmp eq <8 x i1> %8200, %8201
  %8203 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8202)
  %8204 = and i1 %8196, %8203
  %.splatinsert1619 = insertelement <8 x i1> poison, i1 %8204, i64 0
  %.splat1620 = shufflevector <8 x i1> %.splatinsert1619, <8 x i1> poison, <8 x i32> zeroinitializer
  %8205 = select <8 x i1> %.splat1620, <8 x i1> %8200, <8 x i1> zeroinitializer
  %8206 = select i1 %8204, <8 x i1> zeroinitializer, <8 x i1> %8201
  store <8 x i1> %8206, ptr %8197, align 1
  %8207 = select i1 %8204, <8 x i1> zeroinitializer, <8 x i1> %8200
  store <8 x i1> %8207, ptr %8198, align 1
  %8208 = and i8 %8194, -65
  %8209 = select i1 %8204, i8 %8208, i8 %8194
  store i8 %8209, ptr %frame.active, align 1
  %8210 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8211 = extractelement <8 x i32> %8210, i32 6
  %8212 = load <8 x i32>, ptr %frame.static.id, align 32
  %8213 = extractelement <8 x i32> %8212, i32 6
  %convergence.target.pointer1621 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8213
  %convergence.dynamic.target1622 = load i32, ptr %convergence.target.pointer1621, align 4
  %8214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8205)
  %8215 = load i32, ptr %ready.count, align 4
  %8216 = icmp uge i32 %8215, 8
  %8217 = and i1 %8214, %8216
  br i1 %8217, label %ready.overflow.trap1623, label %ready.overflow.resume1624

ready.overflow.trap1623:                          ; preds = %ready.overflow.resume1618
  call void @llvm.trap()
  unreachable

ready.overflow.resume1624:                        ; preds = %ready.overflow.resume1618
  %8218 = select i1 %8214, i32 %8215, i32 0
  %8219 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8218
  %8220 = load <8 x i1>, ptr %8219, align 1
  %8221 = select i1 %8214, <8 x i1> %8205, <8 x i1> %8220
  store <8 x i1> %8221, ptr %8219, align 1
  %8222 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8218
  %8223 = load i32, ptr %8222, align 4
  %8224 = select i1 %8214, i32 %convergence.dynamic.target1622, i32 %8223
  store i32 %8224, ptr %8222, align 4
  %8225 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8218
  %8226 = load i32, ptr %8225, align 4
  %8227 = select i1 %8214, i32 %8211, i32 %8226
  store i32 %8227, ptr %8225, align 4
  %8228 = add i32 %8215, 1
  %8229 = select i1 %8214, i32 %8228, i32 %8215
  store i32 %8229, ptr %ready.count, align 4
  %8230 = load <8 x i1>, ptr %runnable.mask, align 1
  %8231 = or <8 x i1> %8230, %8205
  store <8 x i1> %8231, ptr %runnable.mask, align 1
  %8232 = load i8, ptr %frame.active, align 1
  %8233 = and i8 %8232, -128
  %8234 = icmp ne i8 %8233, 0
  %8235 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %8236 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %8237 = load <8 x i1>, ptr %8235, align 1
  %8238 = load <8 x i1>, ptr %8236, align 1
  %8239 = and <8 x i1> %8237, %7962
  %8240 = icmp eq <8 x i1> %8238, %8239
  %8241 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8240)
  %8242 = and i1 %8234, %8241
  %.splatinsert1625 = insertelement <8 x i1> poison, i1 %8242, i64 0
  %.splat1626 = shufflevector <8 x i1> %.splatinsert1625, <8 x i1> poison, <8 x i32> zeroinitializer
  %8243 = select <8 x i1> %.splat1626, <8 x i1> %8238, <8 x i1> zeroinitializer
  %8244 = select i1 %8242, <8 x i1> zeroinitializer, <8 x i1> %8239
  store <8 x i1> %8244, ptr %8235, align 1
  %8245 = select i1 %8242, <8 x i1> zeroinitializer, <8 x i1> %8238
  store <8 x i1> %8245, ptr %8236, align 1
  %8246 = and i8 %8232, 127
  %8247 = select i1 %8242, i8 %8246, i8 %8232
  store i8 %8247, ptr %frame.active, align 1
  %8248 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8249 = extractelement <8 x i32> %8248, i32 7
  %8250 = load <8 x i32>, ptr %frame.static.id, align 32
  %8251 = extractelement <8 x i32> %8250, i32 7
  %convergence.target.pointer1627 = getelementptr inbounds [37 x i32], ptr @convergence.targets, i32 0, i32 %8251
  %convergence.dynamic.target1628 = load i32, ptr %convergence.target.pointer1627, align 4
  %8252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8243)
  %8253 = load i32, ptr %ready.count, align 4
  %8254 = icmp uge i32 %8253, 8
  %8255 = and i1 %8252, %8254
  br i1 %8255, label %ready.overflow.trap1629, label %ready.overflow.resume1630

ready.overflow.trap1629:                          ; preds = %ready.overflow.resume1624
  call void @llvm.trap()
  unreachable

ready.overflow.resume1630:                        ; preds = %ready.overflow.resume1624
  %8256 = select i1 %8252, i32 %8253, i32 0
  %8257 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8256
  %8258 = load <8 x i1>, ptr %8257, align 1
  %8259 = select i1 %8252, <8 x i1> %8243, <8 x i1> %8258
  store <8 x i1> %8259, ptr %8257, align 1
  %8260 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8256
  %8261 = load i32, ptr %8260, align 4
  %8262 = select i1 %8252, i32 %convergence.dynamic.target1628, i32 %8261
  store i32 %8262, ptr %8260, align 4
  %8263 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8256
  %8264 = load i32, ptr %8263, align 4
  %8265 = select i1 %8252, i32 %8249, i32 %8264
  store i32 %8265, ptr %8263, align 4
  %8266 = add i32 %8253, 1
  %8267 = select i1 %8252, i32 %8266, i32 %8253
  store i32 %8267, ptr %ready.count, align 4
  %8268 = load <8 x i1>, ptr %runnable.mask, align 1
  %8269 = or <8 x i1> %8268, %8243
  store <8 x i1> %8269, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr>, <8 x i1>, <8 x i64>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #4

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

define dso_local void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	96                              ; 0x60
	.quad	112                             ; 0x70
lCPI0_4:
	.quad	64                              ; 0x40
	.quad	80                              ; 0x50
lCPI0_5:
	.quad	32                              ; 0x20
	.quad	48                              ; 0x30
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	16                              ; 0x10
lCPI0_7:
	.quad	97                              ; 0x61
	.quad	113                             ; 0x71
lCPI0_8:
	.quad	65                              ; 0x41
	.quad	81                              ; 0x51
lCPI0_9:
	.quad	33                              ; 0x21
	.quad	49                              ; 0x31
lCPI0_10:
	.quad	1                               ; 0x1
	.quad	17                              ; 0x11
lCPI0_11:
	.quad	98                              ; 0x62
	.quad	114                             ; 0x72
lCPI0_12:
	.quad	66                              ; 0x42
	.quad	82                              ; 0x52
lCPI0_13:
	.quad	34                              ; 0x22
	.quad	50                              ; 0x32
lCPI0_14:
	.quad	2                               ; 0x2
	.quad	18                              ; 0x12
lCPI0_15:
	.quad	99                              ; 0x63
	.quad	115                             ; 0x73
lCPI0_16:
	.quad	67                              ; 0x43
	.quad	83                              ; 0x53
lCPI0_17:
	.quad	35                              ; 0x23
	.quad	51                              ; 0x33
lCPI0_18:
	.quad	3                               ; 0x3
	.quad	19                              ; 0x13
lCPI0_19:
	.quad	100                             ; 0x64
	.quad	116                             ; 0x74
lCPI0_20:
	.quad	68                              ; 0x44
	.quad	84                              ; 0x54
lCPI0_21:
	.quad	36                              ; 0x24
	.quad	52                              ; 0x34
lCPI0_22:
	.quad	4                               ; 0x4
	.quad	20                              ; 0x14
lCPI0_23:
	.quad	101                             ; 0x65
	.quad	117                             ; 0x75
lCPI0_24:
	.quad	69                              ; 0x45
	.quad	85                              ; 0x55
lCPI0_25:
	.quad	37                              ; 0x25
	.quad	53                              ; 0x35
lCPI0_26:
	.quad	5                               ; 0x5
	.quad	21                              ; 0x15
lCPI0_27:
	.quad	102                             ; 0x66
	.quad	118                             ; 0x76
lCPI0_28:
	.quad	70                              ; 0x46
	.quad	86                              ; 0x56
lCPI0_29:
	.quad	38                              ; 0x26
	.quad	54                              ; 0x36
lCPI0_30:
	.quad	6                               ; 0x6
	.quad	22                              ; 0x16
lCPI0_31:
	.quad	103                             ; 0x67
	.quad	119                             ; 0x77
lCPI0_32:
	.quad	71                              ; 0x47
	.quad	87                              ; 0x57
lCPI0_33:
	.quad	39                              ; 0x27
	.quad	55                              ; 0x37
lCPI0_34:
	.quad	7                               ; 0x7
	.quad	23                              ; 0x17
lCPI0_35:
	.quad	104                             ; 0x68
	.quad	120                             ; 0x78
lCPI0_36:
	.quad	72                              ; 0x48
	.quad	88                              ; 0x58
lCPI0_37:
	.quad	40                              ; 0x28
	.quad	56                              ; 0x38
lCPI0_38:
	.quad	8                               ; 0x8
	.quad	24                              ; 0x18
lCPI0_39:
	.quad	105                             ; 0x69
	.quad	121                             ; 0x79
lCPI0_40:
	.quad	73                              ; 0x49
	.quad	89                              ; 0x59
lCPI0_41:
	.quad	41                              ; 0x29
	.quad	57                              ; 0x39
lCPI0_42:
	.quad	9                               ; 0x9
	.quad	25                              ; 0x19
lCPI0_43:
	.quad	106                             ; 0x6a
	.quad	122                             ; 0x7a
lCPI0_44:
	.quad	74                              ; 0x4a
	.quad	90                              ; 0x5a
lCPI0_45:
	.quad	42                              ; 0x2a
	.quad	58                              ; 0x3a
lCPI0_46:
	.quad	10                              ; 0xa
	.quad	26                              ; 0x1a
lCPI0_47:
	.quad	107                             ; 0x6b
	.quad	123                             ; 0x7b
lCPI0_48:
	.quad	75                              ; 0x4b
	.quad	91                              ; 0x5b
lCPI0_49:
	.quad	43                              ; 0x2b
	.quad	59                              ; 0x3b
lCPI0_50:
	.quad	11                              ; 0xb
	.quad	27                              ; 0x1b
lCPI0_51:
	.quad	108                             ; 0x6c
	.quad	124                             ; 0x7c
lCPI0_52:
	.quad	76                              ; 0x4c
	.quad	92                              ; 0x5c
lCPI0_53:
	.quad	44                              ; 0x2c
	.quad	60                              ; 0x3c
lCPI0_54:
	.quad	12                              ; 0xc
	.quad	28                              ; 0x1c
lCPI0_55:
	.quad	109                             ; 0x6d
	.quad	125                             ; 0x7d
lCPI0_56:
	.quad	77                              ; 0x4d
	.quad	93                              ; 0x5d
lCPI0_57:
	.quad	45                              ; 0x2d
	.quad	61                              ; 0x3d
lCPI0_58:
	.quad	13                              ; 0xd
	.quad	29                              ; 0x1d
lCPI0_59:
	.quad	110                             ; 0x6e
	.quad	126                             ; 0x7e
lCPI0_60:
	.quad	78                              ; 0x4e
	.quad	94                              ; 0x5e
lCPI0_61:
	.quad	46                              ; 0x2e
	.quad	62                              ; 0x3e
lCPI0_62:
	.quad	14                              ; 0xe
	.quad	30                              ; 0x1e
lCPI0_63:
	.quad	111                             ; 0x6f
	.quad	127                             ; 0x7f
lCPI0_64:
	.quad	79                              ; 0x4f
	.quad	95                              ; 0x5f
lCPI0_65:
	.quad	47                              ; 0x2f
	.quad	63                              ; 0x3f
lCPI0_66:
	.quad	15                              ; 0xf
	.quad	31                              ; 0x1f
lCPI0_67:
	.quad	768                             ; 0x300
	.quad	896                             ; 0x380
lCPI0_68:
	.quad	256                             ; 0x100
	.quad	384                             ; 0x180
lCPI0_69:
	.quad	512                             ; 0x200
	.quad	640                             ; 0x280
lCPI0_70:
	.quad	0                               ; 0x0
	.quad	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #1344
	dup.4s	v19, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q20, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q18, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v13, v19, v18
	cmhi.4s	v1, v19, v20
	uzp1.8h	v21, v1, v13
	umaxv.8h	h2, v21
	fmov	w8, s2
	tbz	w8, #0, LBB0_403
; %bb.1:                                ; %direct.activate
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	ldr	x11, [x1, #136]
	add	x8, x11, #2, lsl #12            ; =8192
	add	x12, x11, #8, lsl #12           ; =32768
	add	x13, x11, #19, lsl #12          ; =77824
	dup.2d	v0, x13
	str	q0, [sp, #3536]                 ; 16-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #128
	str	x13, [sp, #3512]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x2, x13, #1152
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #1664
	dup.2d	v0, x13
	str	q0, [sp, #3488]                 ; 16-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #2688
	str	x13, [sp, #3480]                ; 8-byte Spill
	add	x13, x11, #20, lsl #12          ; =81920
	add	x13, x13, #2688
	str	x13, [sp, #3472]                ; 8-byte Spill
	sshll.2d	v23, v1, #0
	sshll.2d	v4, v13, #0
	sshll2.2d	v9, v1, #0
	ldr	w13, [x1]
	ldr	w15, [x1, #36]
	add	w13, w15, w13, lsl #5
	dup.4s	v2, w13
	sshll2.2d	v10, v13, #0
	add.4s	v3, v2, v18
	add.4s	v2, v2, v20
	and.16b	v2, v1, v2
	and.16b	v3, v13, v3
	ushll2.2d	v16, v3, #0
	ushll2.2d	v6, v2, #0
	ushll.2d	v7, v3, #0
	ushll.2d	v17, v2, #0
	mov	w13, #56                        ; =0x38
	dup.2d	v24, x13
	add	x13, x11, #20, lsl #12          ; =81920
	add	x1, x13, #2944
	add	x13, x11, #20, lsl #12          ; =81920
	add	x3, x13, #3200
	add	x13, x11, #24, lsl #12          ; =98304
	add	x17, x13, #3200
	ldr	x13, [x0]
	ldr	x24, [x0, #16]
Lloh4:
	adrp	x15, lCPI0_2@PAGE
Lloh5:
	ldr	q22, [x15, lCPI0_2@PAGEOFF]
	ldr	x25, [x0, #32]
	ushll.2d	v25, v2, #3
	ushll.2d	v5, v3, #3
	ushll2.2d	v26, v2, #3
	ushll2.2d	v27, v3, #3
	and.16b	v2, v27, v24
	and.16b	v3, v26, v24
	ldr	x15, [x0, #48]
	str	x15, [sp, #64]                  ; 8-byte Spill
	and.16b	v29, v4, v5
	and.16b	v5, v5, v24
	and.16b	v4, v25, v24
	and.16b	v30, v10, v27
	and.16b	v31, v9, v26
	and.16b	v12, v23, v25
	b	LBB0_3
LBB0_2:                                 ; %else278
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x11, x10, lsl #5
	ldp	q25, q26, [x15]
	bif.16b	v24, v26, v13
	bif.16b	v23, v25, v1
	stp	q23, q24, [x15]
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x9, #1024
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	and.16b	v23, v21, v22
	addv.8h	h0, v23
	lsr	x15, x10, #5
	dup.2d	v25, x15
	fmov	w15, s0
	add.2d	v23, v25, v12
	shl.2d	v23, v23, #7
	and	x16, x9, #0x7c
	dup.2d	v26, x16
	orr.16b	v23, v23, v26
	dup.2d	v27, x13
	add.2d	v28, v27, v23
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w15, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_12
LBB0_5:                                 ; %else260
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v28, v25, v31
	shl.2d	v28, v28, #7
	orr.16b	v28, v28, v26
	add.2d	v28, v27, v28
	tbnz	w15, #2, LBB0_13
LBB0_6:                                 ; %else263
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #3, LBB0_14
LBB0_7:                                 ; %else266
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v28, v25, v29
	shl.2d	v28, v28, #7
	orr.16b	v28, v28, v26
	add.2d	v28, v27, v28
	tbnz	w15, #4, LBB0_15
LBB0_8:                                 ; %else269
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #5, LBB0_16
LBB0_9:                                 ; %else272
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v25, v25, v30
	shl.2d	v25, v25, #7
	orr.16b	v25, v25, v26
	add.2d	v25, v27, v25
	tbnz	w15, #6, LBB0_17
LBB0_10:                                ; %else275
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w15, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x16, d28
	ldr	s23, [x16]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_5
LBB0_12:                                ; %cond.load259
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x16, v28[1]
	ld1.s	{ v23 }[1], [x16]
	add.2d	v28, v25, v31
	shl.2d	v28, v28, #7
	orr.16b	v28, v28, v26
	add.2d	v28, v27, v28
	tbz	w15, #2, LBB0_6
LBB0_13:                                ; %cond.load262
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x16, d28
	ld1.s	{ v23 }[2], [x16]
	tbz	w15, #3, LBB0_7
LBB0_14:                                ; %cond.load265
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x16, v28[1]
	ld1.s	{ v23 }[3], [x16]
	add.2d	v28, v25, v29
	shl.2d	v28, v28, #7
	orr.16b	v28, v28, v26
	add.2d	v28, v27, v28
	tbz	w15, #4, LBB0_8
LBB0_15:                                ; %cond.load268
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x16, d28
	ld1.s	{ v24 }[0], [x16]
	tbz	w15, #5, LBB0_9
LBB0_16:                                ; %cond.load271
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x16, v28[1]
	ld1.s	{ v24 }[1], [x16]
	add.2d	v25, v25, v30
	shl.2d	v25, v25, #7
	orr.16b	v25, v25, v26
	add.2d	v25, v27, v25
	tbz	w15, #6, LBB0_10
LBB0_17:                                ; %cond.load274
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x16, d25
	ld1.s	{ v24 }[2], [x16]
	tbz	w15, #7, LBB0_2
LBB0_18:                                ; %cond.load277
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x15, v25[1]
	ld1.s	{ v24 }[3], [x15]
	b	LBB0_2
LBB0_19:                                ; %direct.true199.preheader
	stp	q31, q30, [sp, #16]             ; 32-byte Folded Spill
	str	q29, [sp, #48]                  ; 16-byte Spill
	add	x9, x11, #18, lsl #12           ; =73728
	str	x9, [sp, #5496]                 ; 8-byte Spill
	str	x2, [sp, #3504]                 ; 8-byte Spill
	str	q0, [sp, #3552]                 ; 16-byte Spill
	str	x17, [sp, #72]                  ; 8-byte Spill
	mov	x9, #0                          ; =0x0
	cmhs.4s	v18, v18, v19
	cmhs.4s	v19, v20, v19
LBB0_20:                                ; %direct.true199
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x8, x9
	ldp	q20, q21, [x10]
	and.16b	v21, v18, v21
	and.16b	v20, v19, v20
	stp	q20, q21, [x10]
	add	x9, x9, #32
	cmp	x9, #3, lsl #12                 ; =12288
	b.ne	LBB0_20
; %bb.21:                               ; %direct.false200
	sshll.2d	v20, v13, #0
	mov	x26, #0                         ; =0x0
	sshll.2d	v21, v1, #0
	ushr.2d	v17, v17, #4
	ushr.2d	v16, v16, #4
	mov.d	x9, v16[1]
	ushr.2d	v6, v6, #4
	ushr.2d	v7, v7, #4
	mov.d	x10, v7[1]
	fmov	x13, d7
	add	x13, x13, x13, lsl #7
	fmov	d7, x13
	add	x10, x10, x10, lsl #7
	mov.d	v7[1], x10
	mov.d	x10, v6[1]
	fmov	x15, d16
	fmov	x13, d6
	mov.d	x16, v17[1]
	fmov	x17, d17
	add	x17, x17, x17, lsl #7
	fmov	d6, x17
	add	x16, x16, x16, lsl #7
	mov.d	v6[1], x16
	and.16b	v26, v21, v6
	and.16b	v27, v20, v7
	mov	w16, #65                        ; =0x41
	dup.2d	v6, x16
	orr.16b	v0, v5, v6
	str	q0, [sp, #3408]                 ; 16-byte Spill
	mov	w16, #66                        ; =0x42
	mov	w17, #67                        ; =0x43
	orr.16b	v0, v3, v6
	str	q0, [sp, #3392]                 ; 16-byte Spill
	orr.16b	v0, v4, v6
	str	q0, [sp, #3376]                 ; 16-byte Spill
	mov	w0, #68                         ; =0x44
	mov	w2, #69                         ; =0x45
	mov	w4, #70                         ; =0x46
	mov	w5, #71                         ; =0x47
	orr.16b	v0, v2, v6
	str	q0, [sp, #3360]                 ; 16-byte Spill
	dup.2d	v6, x16
	orr.16b	v0, v5, v6
	str	q0, [sp, #3344]                 ; 16-byte Spill
	orr.16b	v0, v3, v6
	str	q0, [sp, #3328]                 ; 16-byte Spill
	mov	w16, #72                        ; =0x48
	orr.16b	v0, v4, v6
	str	q0, [sp, #3312]                 ; 16-byte Spill
	orr.16b	v0, v2, v6
	str	q0, [sp, #3296]                 ; 16-byte Spill
	dup.2d	v6, x17
	orr.16b	v0, v5, v6
	str	q0, [sp, #3280]                 ; 16-byte Spill
	orr.16b	v0, v3, v6
	str	q0, [sp, #3264]                 ; 16-byte Spill
	orr.16b	v0, v4, v6
	str	q0, [sp, #3248]                 ; 16-byte Spill
	orr.16b	v0, v2, v6
	str	q0, [sp, #3232]                 ; 16-byte Spill
	dup.2d	v6, x0
	orr.16b	v0, v5, v6
	str	q0, [sp, #3216]                 ; 16-byte Spill
	orr.16b	v0, v3, v6
	str	q0, [sp, #3200]                 ; 16-byte Spill
	orr.16b	v0, v4, v6
	str	q0, [sp, #3184]                 ; 16-byte Spill
	orr.16b	v0, v2, v6
	str	q0, [sp, #3168]                 ; 16-byte Spill
	dup.2d	v6, x2
	orr.16b	v0, v5, v6
	str	q0, [sp, #3152]                 ; 16-byte Spill
	orr.16b	v0, v3, v6
	str	q0, [sp, #3136]                 ; 16-byte Spill
	orr.16b	v0, v4, v6
	str	q0, [sp, #3120]                 ; 16-byte Spill
	orr.16b	v0, v2, v6
	str	q0, [sp, #3104]                 ; 16-byte Spill
	dup.2d	v6, x4
	orr.16b	v0, v5, v6
	str	q0, [sp, #3088]                 ; 16-byte Spill
	orr.16b	v0, v3, v6
	str	q0, [sp, #3072]                 ; 16-byte Spill
	orr.16b	v0, v4, v6
	str	q0, [sp, #3056]                 ; 16-byte Spill
	orr.16b	v0, v2, v6
	str	q0, [sp, #3040]                 ; 16-byte Spill
	dup.2d	v6, x5
	orr.16b	v0, v5, v6
	str	q0, [sp, #3024]                 ; 16-byte Spill
	orr.16b	v0, v3, v6
	str	q0, [sp, #3008]                 ; 16-byte Spill
	orr.16b	v0, v4, v6
	str	q0, [sp, #2992]                 ; 16-byte Spill
	orr.16b	v0, v2, v6
	str	q0, [sp, #2976]                 ; 16-byte Spill
	dup.2d	v6, x16
	add.2d	v0, v5, v6
	str	q0, [sp, #2960]                 ; 16-byte Spill
	add.2d	v0, v3, v6
	str	q0, [sp, #2944]                 ; 16-byte Spill
	add.2d	v0, v4, v6
	str	q0, [sp, #2928]                 ; 16-byte Spill
	add.2d	v0, v2, v6
	str	q0, [sp, #2912]                 ; 16-byte Spill
	uzp1.8h	v2, v19, v18
	add	x15, x15, x15, lsl #7
	add	x16, x9, x9, lsl #7
	add	x9, x13, x13, lsl #7
	add	x10, x10, x10, lsl #7
	add	x13, x11, #19, lsl #12          ; =77824
	add	x14, x13, #3200
	add	x13, x11, #19, lsl #12          ; =77824
	add	x2, x13, #3712
	add	x13, x11, #20, lsl #12          ; =81920
	add	x13, x13, #128
	str	x13, [sp, #2888]                ; 8-byte Spill
	add	x13, x11, #20, lsl #12          ; =81920
	add	x13, x13, #640
	str	x13, [sp, #2880]                ; 8-byte Spill
	add	x13, x11, #20, lsl #12          ; =81920
	add	x13, x13, #1152
	str	x13, [sp, #2872]                ; 8-byte Spill
	add	x13, x11, #20, lsl #12          ; =81920
	add	x13, x13, #1664
	str	x13, [sp, #2864]                ; 8-byte Spill
	add	x13, x11, #20, lsl #12          ; =81920
	add	x13, x13, #2176
	str	x13, [sp, #2856]                ; 8-byte Spill
	add	x13, x11, #21, lsl #12          ; =86016
	add	x13, x13, #3296
	str	x13, [sp, #2848]                ; 8-byte Spill
	mov	w13, #49184                     ; =0xc020
	add	x13, x11, x13
	str	x13, [sp, #2840]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #128
	str	x13, [sp, #2832]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #192
	str	x13, [sp, #2824]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #256
	str	x13, [sp, #2816]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #320
	str	x13, [sp, #2808]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #384
	str	x13, [sp, #2800]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #448
	str	x13, [sp, #2792]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #512
	str	x13, [sp, #2784]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #576
	str	x13, [sp, #2776]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #640
	str	x13, [sp, #2768]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #704
	str	x13, [sp, #2760]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #768
	str	x13, [sp, #2752]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #832
	str	x13, [sp, #2744]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #896
	str	x13, [sp, #2736]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #960
	str	x13, [sp, #2728]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #1024
	str	x13, [sp, #2720]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #1088
	str	x13, [sp, #2712]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #1152
	str	x13, [sp, #2704]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #1216
	str	x13, [sp, #2696]                ; 8-byte Spill
	fmov	d3, x15
	mov.d	v3[1], x16
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #1280
	str	x13, [sp, #2688]                ; 8-byte Spill
	add	x13, x11, #19, lsl #12          ; =77824
	add	x13, x13, #1344
	str	x13, [sp, #2680]                ; 8-byte Spill
	fmov	d4, x9
	mov.d	v4[1], x10
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #1408
	str	x9, [sp, #2672]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #1472
	str	x9, [sp, #2664]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #1536
	str	x9, [sp, #2656]                 ; 8-byte Spill
	add	x9, x11, #19, lsl #12           ; =77824
	add	x9, x9, #1600
	str	x9, [sp, #2648]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2688
	str	x9, [sp, #2640]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2720
	str	x9, [sp, #2632]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2752
	str	x9, [sp, #2624]                 ; 8-byte Spill
	and.16b	v28, v9, v4
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2784
	str	x9, [sp, #2600]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2816
	str	x9, [sp, #2592]                 ; 8-byte Spill
	and.16b	v11, v10, v3
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2848
	str	x9, [sp, #2568]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2880
	str	x9, [sp, #2560]                 ; 8-byte Spill
Lloh6:
	adrp	x9, lCPI0_7@PAGE
Lloh7:
	ldr	q3, [x9, lCPI0_7@PAGEOFF]
	ldr	q0, [sp, #3536]                 ; 16-byte Reload
	add.2d	v3, v0, v3
	str	q3, [sp, #2544]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2912
	str	x9, [sp, #2536]                 ; 8-byte Spill
Lloh8:
	adrp	x9, lCPI0_8@PAGE
Lloh9:
	ldr	q3, [x9, lCPI0_8@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2512]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2944
	str	x9, [sp, #2504]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #2976
	str	x9, [sp, #2496]                 ; 8-byte Spill
Lloh10:
	adrp	x9, lCPI0_9@PAGE
Lloh11:
	ldr	q3, [x9, lCPI0_9@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2480]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3008
	str	x9, [sp, #2472]                 ; 8-byte Spill
Lloh12:
	adrp	x9, lCPI0_10@PAGE
Lloh13:
	ldr	q3, [x9, lCPI0_10@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2448]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3040
	str	x9, [sp, #2440]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3072
	str	x9, [sp, #2432]                 ; 8-byte Spill
Lloh14:
	adrp	x9, lCPI0_11@PAGE
Lloh15:
	ldr	q3, [x9, lCPI0_11@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2416]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3104
	str	x9, [sp, #2408]                 ; 8-byte Spill
Lloh16:
	adrp	x9, lCPI0_12@PAGE
Lloh17:
	ldr	q3, [x9, lCPI0_12@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2384]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3136
	str	x9, [sp, #2376]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3168
	str	x9, [sp, #2368]                 ; 8-byte Spill
Lloh18:
	adrp	x9, lCPI0_13@PAGE
Lloh19:
	ldr	q3, [x9, lCPI0_13@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2352]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3200
	str	x9, [sp, #2344]                 ; 8-byte Spill
Lloh20:
	adrp	x9, lCPI0_14@PAGE
Lloh21:
	ldr	q3, [x9, lCPI0_14@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2320]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3232
	str	x9, [sp, #2312]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3264
	str	x9, [sp, #2304]                 ; 8-byte Spill
Lloh22:
	adrp	x9, lCPI0_15@PAGE
Lloh23:
	ldr	q3, [x9, lCPI0_15@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2288]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3296
	str	x9, [sp, #2280]                 ; 8-byte Spill
Lloh24:
	adrp	x9, lCPI0_16@PAGE
Lloh25:
	ldr	q3, [x9, lCPI0_16@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2256]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3328
	str	x9, [sp, #2248]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3360
	str	x9, [sp, #2240]                 ; 8-byte Spill
Lloh26:
	adrp	x9, lCPI0_17@PAGE
Lloh27:
	ldr	q3, [x9, lCPI0_17@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2224]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3392
	str	x9, [sp, #2216]                 ; 8-byte Spill
Lloh28:
	adrp	x9, lCPI0_18@PAGE
Lloh29:
	ldr	q3, [x9, lCPI0_18@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2192]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3424
	str	x9, [sp, #2184]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3456
	str	x9, [sp, #2176]                 ; 8-byte Spill
Lloh30:
	adrp	x9, lCPI0_19@PAGE
Lloh31:
	ldr	q3, [x9, lCPI0_19@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2160]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3488
	str	x9, [sp, #2152]                 ; 8-byte Spill
Lloh32:
	adrp	x9, lCPI0_20@PAGE
Lloh33:
	ldr	q3, [x9, lCPI0_20@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2128]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3520
	str	x9, [sp, #2120]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3552
	str	x9, [sp, #2112]                 ; 8-byte Spill
Lloh34:
	adrp	x9, lCPI0_21@PAGE
Lloh35:
	ldr	q3, [x9, lCPI0_21@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2096]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3584
	str	x9, [sp, #2088]                 ; 8-byte Spill
Lloh36:
	adrp	x9, lCPI0_22@PAGE
Lloh37:
	ldr	q3, [x9, lCPI0_22@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2064]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3616
	str	x9, [sp, #2056]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3648
	str	x9, [sp, #2048]                 ; 8-byte Spill
Lloh38:
	adrp	x9, lCPI0_23@PAGE
Lloh39:
	ldr	q3, [x9, lCPI0_23@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2032]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3680
	str	x9, [sp, #2024]                 ; 8-byte Spill
Lloh40:
	adrp	x9, lCPI0_24@PAGE
Lloh41:
	ldr	q3, [x9, lCPI0_24@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #2000]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3712
	str	x9, [sp, #1992]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3744
	str	x9, [sp, #1984]                 ; 8-byte Spill
Lloh42:
	adrp	x9, lCPI0_25@PAGE
Lloh43:
	ldr	q3, [x9, lCPI0_25@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1968]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3776
	str	x9, [sp, #1960]                 ; 8-byte Spill
Lloh44:
	adrp	x9, lCPI0_26@PAGE
Lloh45:
	ldr	q3, [x9, lCPI0_26@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1936]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3808
	str	x9, [sp, #1928]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3840
	str	x9, [sp, #1920]                 ; 8-byte Spill
Lloh46:
	adrp	x9, lCPI0_27@PAGE
Lloh47:
	ldr	q3, [x9, lCPI0_27@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1904]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3872
	str	x9, [sp, #1896]                 ; 8-byte Spill
Lloh48:
	adrp	x9, lCPI0_28@PAGE
Lloh49:
	ldr	q3, [x9, lCPI0_28@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1872]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3904
	str	x9, [sp, #1864]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3936
	str	x9, [sp, #1856]                 ; 8-byte Spill
Lloh50:
	adrp	x9, lCPI0_29@PAGE
Lloh51:
	ldr	q3, [x9, lCPI0_29@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1840]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #3968
	str	x9, [sp, #1832]                 ; 8-byte Spill
Lloh52:
	adrp	x9, lCPI0_30@PAGE
Lloh53:
	ldr	q3, [x9, lCPI0_30@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1808]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #4000
	str	x9, [sp, #1800]                 ; 8-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #4032
	str	x9, [sp, #1792]                 ; 8-byte Spill
Lloh54:
	adrp	x9, lCPI0_31@PAGE
Lloh55:
	ldr	q3, [x9, lCPI0_31@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1776]                 ; 16-byte Spill
	add	x9, x11, #20, lsl #12           ; =81920
	add	x9, x9, #4064
	str	x9, [sp, #1768]                 ; 8-byte Spill
Lloh56:
	adrp	x9, lCPI0_32@PAGE
Lloh57:
	ldr	q3, [x9, lCPI0_32@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1744]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #32
	str	x9, [sp, #1736]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #64
	str	x9, [sp, #1728]                 ; 8-byte Spill
Lloh58:
	adrp	x9, lCPI0_33@PAGE
Lloh59:
	ldr	q3, [x9, lCPI0_33@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1712]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #96
	str	x9, [sp, #1704]                 ; 8-byte Spill
Lloh60:
	adrp	x9, lCPI0_34@PAGE
Lloh61:
	ldr	q3, [x9, lCPI0_34@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1680]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #128
	str	x9, [sp, #1672]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #160
	str	x9, [sp, #1664]                 ; 8-byte Spill
Lloh62:
	adrp	x9, lCPI0_35@PAGE
Lloh63:
	ldr	q3, [x9, lCPI0_35@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1648]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #192
	str	x9, [sp, #1640]                 ; 8-byte Spill
Lloh64:
	adrp	x9, lCPI0_36@PAGE
Lloh65:
	ldr	q3, [x9, lCPI0_36@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1616]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #224
	str	x9, [sp, #1608]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #256
	str	x9, [sp, #1600]                 ; 8-byte Spill
Lloh66:
	adrp	x9, lCPI0_37@PAGE
Lloh67:
	ldr	q3, [x9, lCPI0_37@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1584]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #288
	str	x9, [sp, #1576]                 ; 8-byte Spill
Lloh68:
	adrp	x9, lCPI0_38@PAGE
Lloh69:
	ldr	q3, [x9, lCPI0_38@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1552]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #320
	str	x9, [sp, #1544]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #352
	str	x9, [sp, #1536]                 ; 8-byte Spill
Lloh70:
	adrp	x9, lCPI0_39@PAGE
Lloh71:
	ldr	q3, [x9, lCPI0_39@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1520]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #384
	str	x9, [sp, #1512]                 ; 8-byte Spill
Lloh72:
	adrp	x9, lCPI0_40@PAGE
Lloh73:
	ldr	q3, [x9, lCPI0_40@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1488]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #416
	str	x9, [sp, #1480]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #448
	str	x9, [sp, #1472]                 ; 8-byte Spill
Lloh74:
	adrp	x9, lCPI0_41@PAGE
Lloh75:
	ldr	q3, [x9, lCPI0_41@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1456]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #480
	str	x9, [sp, #1448]                 ; 8-byte Spill
Lloh76:
	adrp	x9, lCPI0_42@PAGE
Lloh77:
	ldr	q3, [x9, lCPI0_42@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1424]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #512
	str	x9, [sp, #1416]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #544
	str	x9, [sp, #1408]                 ; 8-byte Spill
Lloh78:
	adrp	x9, lCPI0_43@PAGE
Lloh79:
	ldr	q3, [x9, lCPI0_43@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1392]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #576
	str	x9, [sp, #1384]                 ; 8-byte Spill
Lloh80:
	adrp	x9, lCPI0_44@PAGE
Lloh81:
	ldr	q3, [x9, lCPI0_44@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1360]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #608
	str	x9, [sp, #1352]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #640
	str	x9, [sp, #1344]                 ; 8-byte Spill
Lloh82:
	adrp	x9, lCPI0_45@PAGE
Lloh83:
	ldr	q3, [x9, lCPI0_45@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1328]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #672
	str	x9, [sp, #1320]                 ; 8-byte Spill
Lloh84:
	adrp	x9, lCPI0_46@PAGE
Lloh85:
	ldr	q3, [x9, lCPI0_46@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1296]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #704
	str	x9, [sp, #1288]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #736
	str	x9, [sp, #1280]                 ; 8-byte Spill
Lloh86:
	adrp	x9, lCPI0_47@PAGE
Lloh87:
	ldr	q3, [x9, lCPI0_47@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1264]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #768
	str	x9, [sp, #1256]                 ; 8-byte Spill
Lloh88:
	adrp	x9, lCPI0_48@PAGE
Lloh89:
	ldr	q3, [x9, lCPI0_48@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1232]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #800
	str	x9, [sp, #1224]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #832
	str	x9, [sp, #1216]                 ; 8-byte Spill
Lloh90:
	adrp	x9, lCPI0_49@PAGE
Lloh91:
	ldr	q3, [x9, lCPI0_49@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1200]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #864
	str	x9, [sp, #1192]                 ; 8-byte Spill
Lloh92:
	adrp	x9, lCPI0_50@PAGE
Lloh93:
	ldr	q3, [x9, lCPI0_50@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1168]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #896
	str	x9, [sp, #1160]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #928
	str	x9, [sp, #1152]                 ; 8-byte Spill
Lloh94:
	adrp	x9, lCPI0_51@PAGE
Lloh95:
	ldr	q3, [x9, lCPI0_51@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1136]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #960
	str	x9, [sp, #1128]                 ; 8-byte Spill
Lloh96:
	adrp	x9, lCPI0_52@PAGE
Lloh97:
	ldr	q3, [x9, lCPI0_52@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #1104]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #992
	str	x9, [sp, #1096]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1024
	str	x9, [sp, #1088]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1056
	str	x9, [sp, #1080]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1088
	str	x9, [sp, #1072]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1120
	str	x9, [sp, #1064]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1152
	str	x9, [sp, #1056]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1184
	str	x9, [sp, #1048]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1216
	str	x9, [sp, #1040]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1248
	str	x9, [sp, #1032]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1280
	str	x9, [sp, #1024]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1312
	str	x9, [sp, #1016]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1344
	str	x9, [sp, #1008]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1376
	str	x9, [sp, #1000]                 ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1408
	str	x9, [sp, #992]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1440
	str	x9, [sp, #984]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1472
	str	x9, [sp, #976]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1504
	str	x9, [sp, #968]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1536
	str	x9, [sp, #960]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1568
	str	x9, [sp, #952]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1600
	str	x9, [sp, #944]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1632
	str	x9, [sp, #936]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1664
	str	x9, [sp, #928]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1696
	str	x9, [sp, #920]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1728
	str	x9, [sp, #912]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1760
	str	x9, [sp, #904]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1792
	str	x9, [sp, #896]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1824
	str	x9, [sp, #888]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1856
	str	x9, [sp, #880]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1888
	str	x9, [sp, #872]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1920
	str	x9, [sp, #864]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1952
	str	x9, [sp, #856]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #1984
	str	x9, [sp, #848]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2016
	str	x9, [sp, #840]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2048
	str	x9, [sp, #832]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2080
	str	x9, [sp, #824]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2112
	str	x9, [sp, #816]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2144
	str	x9, [sp, #808]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2176
	str	x9, [sp, #800]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2208
	str	x9, [sp, #792]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2240
	str	x9, [sp, #784]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2272
	str	x9, [sp, #776]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2304
	str	x9, [sp, #768]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2336
	str	x9, [sp, #760]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2368
	str	x9, [sp, #752]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2400
	str	x9, [sp, #744]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2432
	str	x9, [sp, #736]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2464
	str	x9, [sp, #728]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2496
	str	x9, [sp, #720]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2528
	str	x9, [sp, #712]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2560
	str	x9, [sp, #704]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2592
	str	x9, [sp, #696]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2624
	str	x9, [sp, #688]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2656
	str	x9, [sp, #680]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2688
	str	x9, [sp, #672]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2720
	str	x9, [sp, #664]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2752
	str	x9, [sp, #656]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2784
	str	x9, [sp, #648]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2816
	str	x9, [sp, #640]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2848
	str	x9, [sp, #632]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2880
	str	x9, [sp, #624]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2912
	str	x9, [sp, #616]                  ; 8-byte Spill
	mov	w15, #48                        ; =0x30
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2944
	str	x9, [sp, #592]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #2976
	str	x9, [sp, #584]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #3008
	str	x9, [sp, #576]                  ; 8-byte Spill
	mov	w17, #43691                     ; =0xaaab
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #3040
	str	x9, [sp, #568]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #3072
	str	x9, [sp, #560]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #3104
	str	x9, [sp, #552]                  ; 8-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	add	x9, x9, #3136
	str	x9, [sp, #544]                  ; 8-byte Spill
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #4928]                 ; 16-byte Spill
	str	q3, [sp, #4912]                 ; 16-byte Spill
	str	q3, [sp, #4896]                 ; 16-byte Spill
	str	q3, [sp, #4880]                 ; 16-byte Spill
	str	q3, [sp, #4864]                 ; 16-byte Spill
	str	q3, [sp, #4848]                 ; 16-byte Spill
	str	q3, [sp, #4832]                 ; 16-byte Spill
	str	q3, [sp, #4816]                 ; 16-byte Spill
	str	q3, [sp, #4800]                 ; 16-byte Spill
	str	q3, [sp, #4784]                 ; 16-byte Spill
	str	q3, [sp, #4768]                 ; 16-byte Spill
	str	q3, [sp, #4752]                 ; 16-byte Spill
	str	q3, [sp, #4736]                 ; 16-byte Spill
	str	q3, [sp, #4720]                 ; 16-byte Spill
	str	q3, [sp, #4704]                 ; 16-byte Spill
	str	q3, [sp, #4688]                 ; 16-byte Spill
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	str	q3, [sp, #4672]                 ; 16-byte Spill
	str	q3, [sp, #4656]                 ; 16-byte Spill
	str	q3, [sp, #4640]                 ; 16-byte Spill
	str	q3, [sp, #4624]                 ; 16-byte Spill
	str	q3, [sp, #4608]                 ; 16-byte Spill
	str	q3, [sp, #5632]                 ; 16-byte Spill
	str	q3, [sp, #5616]                 ; 16-byte Spill
	str	q3, [sp, #4592]                 ; 16-byte Spill
	str	q3, [sp, #4576]                 ; 16-byte Spill
	str	q3, [sp, #4560]                 ; 16-byte Spill
	str	q3, [sp, #4544]                 ; 16-byte Spill
	str	q3, [sp, #5664]                 ; 16-byte Spill
	str	q3, [sp, #5248]                 ; 16-byte Spill
	str	q3, [sp, #5232]                 ; 16-byte Spill
	str	q3, [sp, #4528]                 ; 16-byte Spill
	str	q3, [sp, #4512]                 ; 16-byte Spill
	str	q3, [sp, #4496]                 ; 16-byte Spill
	str	q3, [sp, #4480]                 ; 16-byte Spill
	str	q3, [sp, #4464]                 ; 16-byte Spill
	str	q3, [sp, #4448]                 ; 16-byte Spill
	str	q3, [sp, #4432]                 ; 16-byte Spill
	str	q3, [sp, #4416]                 ; 16-byte Spill
	str	q3, [sp, #4400]                 ; 16-byte Spill
	str	q3, [sp, #4384]                 ; 16-byte Spill
	str	q3, [sp, #4368]                 ; 16-byte Spill
	str	q3, [sp, #4352]                 ; 16-byte Spill
	str	q3, [sp, #5600]                 ; 16-byte Spill
	str	q3, [sp, #5584]                 ; 16-byte Spill
	str	q3, [sp, #5568]                 ; 16-byte Spill
	str	q3, [sp, #5552]                 ; 16-byte Spill
	str	q3, [sp, #4336]                 ; 16-byte Spill
	str	q3, [sp, #5680]                 ; 16-byte Spill
	str	q3, [sp, #5536]                 ; 16-byte Spill
	str	q3, [sp, #5216]                 ; 16-byte Spill
	str	q3, [sp, #5200]                 ; 16-byte Spill
	str	q3, [sp, #4320]                 ; 16-byte Spill
	str	q3, [sp, #4304]                 ; 16-byte Spill
	str	q3, [sp, #4288]                 ; 16-byte Spill
	str	q3, [sp, #4272]                 ; 16-byte Spill
	str	q3, [sp, #4256]                 ; 16-byte Spill
	str	q3, [sp, #4240]                 ; 16-byte Spill
	add	x9, x11, #21, lsl #12           ; =86016
	str	q3, [sp, #5184]                 ; 16-byte Spill
	str	q3, [sp, #5168]                 ; 16-byte Spill
	str	q3, [sp, #5152]                 ; 16-byte Spill
	str	q3, [sp, #5136]                 ; 16-byte Spill
	str	q3, [sp, #5120]                 ; 16-byte Spill
	add	x9, x9, #3168
	str	x9, [sp, #536]                  ; 8-byte Spill
	str	q3, [sp, #5104]                 ; 16-byte Spill
	str	q3, [sp, #5088]                 ; 16-byte Spill
	str	q3, [sp, #5072]                 ; 16-byte Spill
	str	q3, [sp, #5056]                 ; 16-byte Spill
	str	q3, [sp, #5040]                 ; 16-byte Spill
	mvni.4s	v3, #63, msl #16
	fneg.4s	v3, v3
	str	q3, [sp, #5520]                 ; 16-byte Spill
Lloh98:
	adrp	x9, lCPI0_53@PAGE
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #5024]                 ; 16-byte Spill
	str	q3, [sp, #5008]                 ; 16-byte Spill
Lloh99:
	ldr	q3, [x9, lCPI0_53@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #512]                  ; 16-byte Spill
Lloh100:
	adrp	x9, lCPI0_54@PAGE
Lloh101:
	ldr	q3, [x9, lCPI0_54@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #496]                  ; 16-byte Spill
Lloh102:
	adrp	x9, lCPI0_70@PAGE
Lloh103:
	ldr	q3, [x9, lCPI0_70@PAGEOFF]
	str	q3, [sp, #480]                  ; 16-byte Spill
Lloh104:
	adrp	x9, lCPI0_68@PAGE
Lloh105:
	adrp	x10, lCPI0_69@PAGE
Lloh106:
	adrp	x13, lCPI0_67@PAGE
Lloh107:
	ldr	q3, [x13, lCPI0_67@PAGEOFF]
	str	q3, [sp, #464]                  ; 16-byte Spill
Lloh108:
	ldr	q3, [x9, lCPI0_68@PAGEOFF]
	str	q3, [sp, #448]                  ; 16-byte Spill
Lloh109:
	ldr	q3, [x10, lCPI0_69@PAGEOFF]
	str	q3, [sp, #432]                  ; 16-byte Spill
Lloh110:
	adrp	x9, lCPI0_55@PAGE
Lloh111:
	ldr	q3, [x9, lCPI0_55@PAGEOFF]
	add.2d	v3, v0, v3
	str	q3, [sp, #416]                  ; 16-byte Spill
	xtn.8b	v2, v2
	str	d2, [sp, #5504]                 ; 8-byte Spill
Lloh112:
	adrp	x9, lCPI0_56@PAGE
Lloh113:
	ldr	q2, [x9, lCPI0_56@PAGEOFF]
	add.2d	v2, v0, v2
	str	q2, [sp, #400]                  ; 16-byte Spill
Lloh114:
	adrp	x9, lCPI0_57@PAGE
Lloh115:
	ldr	q2, [x9, lCPI0_57@PAGEOFF]
	add.2d	v2, v0, v2
	str	q2, [sp, #384]                  ; 16-byte Spill
Lloh116:
	adrp	x9, lCPI0_58@PAGE
Lloh117:
	ldr	q2, [x9, lCPI0_58@PAGEOFF]
	add.2d	v2, v0, v2
	str	q2, [sp, #368]                  ; 16-byte Spill
Lloh118:
	adrp	x9, lCPI0_59@PAGE
Lloh119:
	ldr	q2, [x9, lCPI0_59@PAGEOFF]
	add.2d	v2, v0, v2
	str	q2, [sp, #352]                  ; 16-byte Spill
Lloh120:
	adrp	x9, lCPI0_60@PAGE
Lloh121:
	ldr	q2, [x9, lCPI0_60@PAGEOFF]
	add.2d	v2, v0, v2
	str	q2, [sp, #336]                  ; 16-byte Spill
Lloh122:
	adrp	x9, lCPI0_61@PAGE
Lloh123:
	ldr	q2, [x9, lCPI0_61@PAGEOFF]
	add.2d	v2, v0, v2
	str	q2, [sp, #320]                  ; 16-byte Spill
Lloh124:
	adrp	x9, lCPI0_62@PAGE
Lloh125:
	ldr	q2, [x9, lCPI0_62@PAGEOFF]
	add.2d	v2, v0, v2
	str	q2, [sp, #304]                  ; 16-byte Spill
Lloh126:
	adrp	x9, lCPI0_63@PAGE
Lloh127:
	ldr	q2, [x9, lCPI0_63@PAGEOFF]
	add.2d	v2, v0, v2
	str	q2, [sp, #288]                  ; 16-byte Spill
Lloh128:
	adrp	x9, lCPI0_64@PAGE
Lloh129:
	ldr	q2, [x9, lCPI0_64@PAGEOFF]
	add.2d	v2, v0, v2
	str	q2, [sp, #272]                  ; 16-byte Spill
Lloh130:
	adrp	x9, lCPI0_65@PAGE
Lloh131:
	ldr	q2, [x9, lCPI0_65@PAGEOFF]
	add.2d	v2, v0, v2
	str	q2, [sp, #256]                  ; 16-byte Spill
Lloh132:
	adrp	x9, lCPI0_66@PAGE
Lloh133:
	ldr	q2, [x9, lCPI0_66@PAGEOFF]
	add.2d	v2, v0, v2
	str	q2, [sp, #240]                  ; 16-byte Spill
	mov	w0, #62154                      ; =0xf2ca
	movk	w0, #61769, lsl #16
Lloh134:
	adrp	x9, lCPI0_4@PAGE
Lloh135:
	adrp	x10, lCPI0_5@PAGE
Lloh136:
	adrp	x13, lCPI0_6@PAGE
	dup.4s	v2, w0
Lloh137:
	adrp	x0, lCPI0_3@PAGE
Lloh138:
	ldr	q3, [x0, lCPI0_3@PAGEOFF]
Lloh139:
	ldr	q4, [x9, lCPI0_4@PAGEOFF]
Lloh140:
	ldr	q5, [x10, lCPI0_5@PAGEOFF]
Lloh141:
	ldr	q6, [x13, lCPI0_6@PAGEOFF]
	and.16b	v7, v1, v2
	str	q7, [sp, #5456]                 ; 16-byte Spill
	stp	q3, q2, [sp, #192]              ; 32-byte Folded Spill
	and.16b	v2, v13, v2
	str	q2, [sp, #5424]                 ; 16-byte Spill
	stp	q5, q4, [sp, #160]              ; 32-byte Folded Spill
	add.2d	v4, v0, v4
	stp	q4, q6, [sp, #128]              ; 32-byte Folded Spill
	add.2d	v4, v0, v5
	str	q4, [sp, #112]                  ; 16-byte Spill
	add.2d	v4, v0, v6
	str	q7, [sp, #5408]                 ; 16-byte Spill
	str	q2, [sp, #5392]                 ; 16-byte Spill
	str	q7, [sp, #5376]                 ; 16-byte Spill
	str	q2, [sp, #5360]                 ; 16-byte Spill
	add.2d	v0, v0, v3
	stp	q0, q4, [sp, #80]               ; 32-byte Folded Spill
	str	q7, [sp, #5344]                 ; 16-byte Spill
	str	q2, [sp, #5328]                 ; 16-byte Spill
	str	q7, [sp, #5312]                 ; 16-byte Spill
	str	q2, [sp, #5296]                 ; 16-byte Spill
	str	q7, [sp, #5280]                 ; 16-byte Spill
	str	q2, [sp, #5264]                 ; 16-byte Spill
	str	q7, [sp, #5472]                 ; 16-byte Spill
	str	q7, [sp, #4992]                 ; 16-byte Spill
	str	q2, [sp, #5440]                 ; 16-byte Spill
	str	q2, [sp, #4976]                 ; 16-byte Spill
	add	x16, x11, #12, lsl #12          ; =49152
	str	q12, [sp, #3520]                ; 16-byte Spill
	str	q9, [sp, #4960]                 ; 16-byte Spill
	str	q10, [sp, #4944]                ; 16-byte Spill
	str	x24, [sp, #3464]                ; 8-byte Spill
	str	x25, [sp, #3456]                ; 8-byte Spill
	str	q26, [sp, #3440]                ; 16-byte Spill
	str	q27, [sp, #3424]                ; 16-byte Spill
	str	x14, [sp, #2904]                ; 8-byte Spill
	str	x2, [sp, #2896]                 ; 8-byte Spill
	str	q28, [sp, #2608]                ; 16-byte Spill
	str	q11, [sp, #2576]                ; 16-byte Spill
	str	x1, [sp, #608]                  ; 8-byte Spill
	str	x3, [sp, #600]                  ; 8-byte Spill
	str	x12, [sp, #5512]                ; 8-byte Spill
	str	x8, [sp, #232]                  ; 8-byte Spill
LBB0_22:                                ; %direct.true209
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_28 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;       Child Loop BB0_32 Depth 3
                                        ;     Child Loop BB0_175 Depth 2
                                        ;     Child Loop BB0_209 Depth 2
                                        ;     Child Loop BB0_226 Depth 2
                                        ;     Child Loop BB0_228 Depth 2
                                        ;     Child Loop BB0_230 Depth 2
                                        ;     Child Loop BB0_232 Depth 2
                                        ;     Child Loop BB0_234 Depth 2
                                        ;     Child Loop BB0_236 Depth 2
                                        ;     Child Loop BB0_238 Depth 2
                                        ;     Child Loop BB0_240 Depth 2
                                        ;     Child Loop BB0_243 Depth 2
                                        ;     Child Loop BB0_260 Depth 2
                                        ;       Child Loop BB0_261 Depth 3
                                        ;     Child Loop BB0_264 Depth 2
                                        ;     Child Loop BB0_266 Depth 2
	mov	x9, #0                          ; =0x0
	lsl	x5, x26, #4
	ldr	q0, [sp, #4672]                 ; 16-byte Reload
	b	LBB0_24
LBB0_23:                                ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_24 Depth=2
	sshll.2d	v5, v13, #0
	add.2d	v6, v4, v11
	add.2d	v7, v4, v28
	add.2d	v4, v4, v27
	shl.2d	v4, v4, #5
	shl.2d	v7, v7, #5
	shl.2d	v6, v6, #5
	orr.16b	v6, v6, v3
	orr.16b	v7, v7, v3
	orr.16b	v3, v4, v3
	bit.16b	v22, v3, v5
	bit.16b	v21, v7, v9
	bit.16b	v23, v6, v10
	bit.16b	v19, v2, v13
	bit.16b	v18, v2, v1
	add	x10, x12, x9, lsl #5
	ldp	q3, q4, [x10]
	bit.16b	v4, v2, v13
	bif.16b	v2, v3, v1
	stp	q2, q4, [x10]
	add	x9, x9, #1
	cmp	x9, #512
	b.eq	LBB0_26
LBB0_24:                                ; %direct.true213
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v1, #0
	and	x10, x9, #0x1f
	orr	x13, x5, x9, lsr #5
	dup.2d	v4, x13
	add.2d	v3, v4, v26
	shl.2d	v5, v3, #5
	dup.2d	v3, x10
	orr.16b	v5, v5, v3
	bit.16b	v20, v5, v2
	movi.2d	v2, #0000000000000000
	cmp	x13, #128
	b.hi	LBB0_23
; %bb.25:                               ; %direct.true223
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x10, d20
	add	x10, x24, x10, lsl #2
	ld1r.4s	{ v2 }, [x10]
	b	LBB0_23
LBB0_26:                                ; %direct.true237.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	q16, [sp, #4656]                ; 16-byte Reload
	ldr	q17, [sp, #4640]                ; 16-byte Reload
	ldr	q25, [sp, #4624]                ; 16-byte Reload
	ldr	q29, [sp, #4608]                ; 16-byte Reload
	movi.2d	v8, #0000000000000000
	b	LBB0_28
LBB0_27:                                ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_28 Depth=2
	add.2d	v5, v4, v28
	add.2d	v6, v4, v27
	add.2d	v4, v4, v11
	mov.d	x10, v4[1]
	fmov	x13, d4
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	fmov	d4, x13
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #4
	mov.d	v4[1], x10
	mov.d	x10, v6[1]
	fmov	x13, d6
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	fmov	d6, x13
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #4
	mov.d	v6[1], x10
	mov.d	x10, v5[1]
	fmov	x13, d5
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	fmov	d5, x13
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #4
	mov.d	v5[1], x10
	sshll.2d	v7, v13, #0
	add.2d	v5, v5, v3
	add.2d	v6, v6, v3
	add.2d	v3, v4, v3
	bit.16b	v29, v3, v10
	bit.16b	v25, v6, v7
	bit.16b	v17, v5, v9
	bit.16b	v0, v2, v13
	bit.16b	v24, v2, v1
	add	x10, x16, x9, lsl #5
	ldp	q3, q4, [x10]
	bit.16b	v4, v2, v13
	bif.16b	v2, v3, v1
	stp	q2, q4, [x10]
	add	x9, x9, #1
	cmp	x9, #768
	b.eq	LBB0_30
LBB0_28:                                ; %direct.true237
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w10, w9, #0xffff
	mul	w10, w10, w17
	lsr	w10, w10, #21
	add	x13, x5, x10
	dup.2d	v4, x13
	add.2d	v2, v4, v26
	mov.d	x0, v2[1]
	fmov	x4, d2
	add	x4, x4, x4, lsl #1
	lsl	x4, x4, #4
	fmov	d2, x4
	sshll.2d	v5, v1, #0
	msub	w10, w10, w15, w9
	and	x10, x10, #0xffff
	add	x0, x0, x0, lsl #1
	lsl	x0, x0, #4
	mov.d	v2[1], x0
	dup.2d	v3, x10
	add.2d	v2, v2, v3
	bit.16b	v16, v2, v5
	movi.2d	v2, #0000000000000000
	cmp	x13, #128
	b.hi	LBB0_27
; %bb.29:                               ; %direct.true247
                                        ;   in Loop: Header=BB0_28 Depth=2
	fmov	x10, d16
	add	x10, x25, x10, lsl #2
	ld1r.4s	{ v2 }, [x10]
	b	LBB0_27
LBB0_30:                                ; %direct.schedule.21.preheader.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	x5, [sp, #4096]                 ; 8-byte Spill
	str	q29, [sp, #4608]                ; 16-byte Spill
	str	q25, [sp, #4624]                ; 16-byte Spill
	str	q17, [sp, #4640]                ; 16-byte Spill
	str	q16, [sp, #4656]                ; 16-byte Spill
	str	q0, [sp, #4672]                 ; 16-byte Spill
	str	q24, [sp, #4112]                ; 16-byte Spill
	str	q23, [sp, #4128]                ; 16-byte Spill
	str	q22, [sp, #4144]                ; 16-byte Spill
	str	q21, [sp, #4160]                ; 16-byte Spill
	str	q20, [sp, #4176]                ; 16-byte Spill
	str	q19, [sp, #4192]                ; 16-byte Spill
	str	q18, [sp, #4208]                ; 16-byte Spill
	str	x26, [sp, #4232]                ; 8-byte Spill
	mov	x8, #0                          ; =0x0
LBB0_31:                                ; %direct.schedule.21.preheader
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_32 Depth 3
	mov	x24, #0                         ; =0x0
	lsl	x25, x8, #9
	str	x8, [sp, #5648]                 ; 8-byte Spill
	add	x0, x11, x8, lsl #10
	mov	w21, #37056                     ; =0x90c0
	ldr	x12, [sp, #5496]                ; 8-byte Reload
	ldr	x8, [sp, #5512]                 ; 8-byte Reload
	mov	w16, #40128                     ; =0x9cc0
	mov	w6, #38144                      ; =0x9500
	mov	w22, #40192                     ; =0x9d00
	mov	w1, #38208                      ; =0x9540
	mov	w5, #40256                      ; =0x9d40
	mov	w20, #38272                     ; =0x9580
	mov	w15, #40320                     ; =0x9d80
	mov	w14, #38336                     ; =0x95c0
	mov	w17, #40384                     ; =0x9dc0
	mov	w2, #38400                      ; =0x9600
	mov	w3, #40448                      ; =0x9e00
	mov	w7, #38464                      ; =0x9640
	mov	w19, #40512                     ; =0x9e40
	mov	w23, #38528                     ; =0x9680
LBB0_32:                                ; %direct.true264
                                        ;   Parent Loop BB0_22 Depth=1
                                        ;     Parent Loop BB0_31 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q2, q3, [x0]
	and.16b	v24, v13, v3
	lsl	x9, x24, #12
	add	x4, x9, x11
	add	x28, x8, x9
	mov	w9, #36864                      ; =0x9000
	prfm	pldl1keep, [x4, x9]
	and.16b	v19, v1, v2
	ldp	q0, q2, [x28]
	str	q0, [sp, #8880]                 ; 16-byte Spill
	str	q2, [sp, #8896]                 ; 16-byte Spill
	add	x26, x25, x24, lsl #7
	orr	x30, x26, #0x20
	mov	w9, #13312                      ; =0x3400
	and	x9, x9, x30, lsl #5
	add	x10, x8, x9
	mov	w9, #37888                      ; =0x9400
	prfm	pldl1keep, [x4, x9]
	ldp	q2, q3, [x10]
	and.16b	v3, v13, v3
	orr	x27, x26, #0x40
	and.16b	v2, v1, v2
	lsl	x9, x27, #5
	and	x9, x9, #0x3800
	add	x9, x8, x9
	mov	w13, #38912                     ; =0x9800
	prfm	pldl1keep, [x4, x13]
	ldp	q20, q21, [x9]
	fmul.4s	v2, v19, v2
	mov	w13, #39936                     ; =0x9c00
	prfm	pldl1keep, [x4, x13]
	ldp	q5, q4, [x0, #32]
	and.16b	v28, v1, v5
	fmul.4s	v3, v24, v3
	and.16b	v14, v13, v4
	ldp	q5, q4, [x10, #32]
	and.16b	v5, v1, v5
	and.16b	v4, v13, v4
	fmul.4s	v4, v14, v4
	ldp	q6, q7, [x0, #64]
	and.16b	v31, v13, v7
	and.16b	v0, v1, v6
	str	q0, [sp, #8352]                 ; 16-byte Spill
	ldr	q6, [x28, #3072]
	str	q6, [sp, #8752]                 ; 16-byte Spill
	fmul.4s	v5, v28, v5
	ldr	q6, [x28, #3088]
	str	q6, [sp, #8768]                 ; 16-byte Spill
	ldp	q6, q7, [x28, #32]
	str	q7, [sp, #8832]                 ; 16-byte Spill
	str	q6, [sp, #8784]                 ; 16-byte Spill
	ldp	q11, q30, [x9, #32]
	fadd.4s	v3, v3, v8
	ldr	q6, [x28, #3120]
	str	q6, [sp, #8800]                 ; 16-byte Spill
	ldr	q6, [x28, #3104]
	str	q6, [sp, #8816]                 ; 16-byte Spill
	mov	w13, #36928                     ; =0x9040
	prfm	pldl1keep, [x4, x13]
	ldp	q7, q6, [x28, #64]
	str	q7, [sp, #8864]                 ; 16-byte Spill
	str	q6, [sp, #8848]                 ; 16-byte Spill
	fadd.4s	v2, v2, v8
	mov	w13, #37952                     ; =0x9440
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q7, [x10, #64]
	and.16b	v7, v13, v7
	and.16b	v6, v1, v6
	fadd.4s	v2, v2, v5
	fmul.4s	v5, v0, v6
	fmul.4s	v6, v31, v7
	mov	w13, #38976                     ; =0x9840
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q7, [x9, #64]
	str	q7, [sp, #8336]                 ; 16-byte Spill
	str	q0, [sp, #8320]                 ; 16-byte Spill
	fadd.4s	v3, v3, v4
	mov	w13, #40000                     ; =0x9c40
	prfm	pldl1keep, [x4, x13]
	ldp	q7, q4, [x0, #96]
	and.16b	v7, v1, v7
	str	q7, [sp, #6192]                 ; 16-byte Spill
	and.16b	v0, v13, v4
	str	q0, [sp, #8208]                 ; 16-byte Spill
	fadd.4s	v3, v3, v6
	ldp	q6, q4, [x10, #96]
	and.16b	v6, v1, v6
	and.16b	v4, v13, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v5
	fmul.4s	v5, v7, v6
	fadd.4s	v2, v2, v5
	ldr	q0, [x28, #3136]
	str	q0, [sp, #8688]                 ; 16-byte Spill
	ldr	q0, [x28, #3152]
	str	q0, [sp, #8704]                 ; 16-byte Spill
	ldp	q0, q5, [x28, #96]
	str	q5, [sp, #8736]                 ; 16-byte Spill
	fadd.4s	v3, v3, v4
	str	q0, [sp, #8720]                 ; 16-byte Spill
	ldp	q4, q0, [x9, #96]
	str	q4, [sp, #8176]                 ; 16-byte Spill
	str	q0, [sp, #8144]                 ; 16-byte Spill
	ldr	q0, [x28, #3184]
	str	q0, [sp, #8656]                 ; 16-byte Spill
	ldr	q0, [x28, #3168]
	str	q0, [sp, #8672]                 ; 16-byte Spill
	ldp	q4, q5, [x0, #128]
	mov	w13, #36992                     ; =0x9080
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q0, [x28, #128]
	str	q6, [sp, #8640]                 ; 16-byte Spill
	str	q0, [sp, #8624]                 ; 16-byte Spill
	mov	w13, #38016                     ; =0x9480
	prfm	pldl1keep, [x4, x13]
	and.16b	v0, v13, v5
	str	q0, [sp, #8128]                 ; 16-byte Spill
	ldr	q5, [x10, #144]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v23, v1, v4
	ldr	q4, [x10, #128]
	and.16b	v4, v1, v4
	fmul.4s	v4, v23, v4
	fadd.4s	v2, v2, v4
	mov	w13, #39040                     ; =0x9880
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #128]
	str	q4, [sp, #8112]                 ; 16-byte Spill
	str	q0, [sp, #8096]                 ; 16-byte Spill
	mov	w13, #40064                     ; =0x9c80
	prfm	pldl1keep, [x4, x13]
	ldr	q4, [x0, #160]
	and.16b	v0, v1, v4
	str	q0, [sp, #8080]                 ; 16-byte Spill
	ldr	q4, [x10, #160]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #176]
	and.16b	v25, v13, v4
	ldr	q4, [x10, #176]
	and.16b	v4, v13, v4
	fmul.4s	v4, v25, v4
	fadd.4s	v3, v3, v4
	ldp	q4, q5, [x0, #192]
	and.16b	v0, v13, v5
	str	q0, [sp, #7904]                 ; 16-byte Spill
	ldr	q5, [x28, #3200]
	str	q5, [sp, #8496]                 ; 16-byte Spill
	ldr	q5, [x28, #3216]
	str	q5, [sp, #8512]                 ; 16-byte Spill
	ldp	q5, q6, [x28, #160]
	str	q6, [sp, #8592]                 ; 16-byte Spill
	str	q5, [sp, #8528]                 ; 16-byte Spill
	ldp	q6, q5, [x9, #160]
	str	q6, [sp, #7936]                 ; 16-byte Spill
	str	q5, [sp, #7920]                 ; 16-byte Spill
	ldr	q5, [x28, #3248]
	str	q5, [sp, #8544]                 ; 16-byte Spill
	ldr	q5, [x28, #3232]
	str	q5, [sp, #8576]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x21]
	ldp	q6, q5, [x28, #192]
	str	q6, [sp, #8608]                 ; 16-byte Spill
	str	q5, [sp, #8560]                 ; 16-byte Spill
	mov	w13, #38080                     ; =0x94c0
	prfm	pldl1keep, [x4, x13]
	ldr	q5, [x10, #208]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v27, v1, v4
	ldr	q4, [x10, #192]
	and.16b	v4, v1, v4
	fmul.4s	v4, v27, v4
	fadd.4s	v2, v2, v4
	mov	w13, #39104                     ; =0x98c0
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #192]
	str	q4, [sp, #7888]                 ; 16-byte Spill
	str	q0, [sp, #7872]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x16]
	ldr	q4, [x0, #224]
	and.16b	v0, v1, v4
	str	q0, [sp, #7744]                 ; 16-byte Spill
	ldr	q4, [x10, #224]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #240]
	and.16b	v9, v13, v4
	ldr	q4, [x10, #240]
	and.16b	v4, v13, v4
	fmul.4s	v4, v9, v4
	fadd.4s	v3, v3, v4
	ldp	q4, q5, [x0, #256]
	and.16b	v0, v13, v5
	str	q0, [sp, #7664]                 ; 16-byte Spill
	ldr	q5, [x28, #3264]
	str	q5, [sp, #8368]                 ; 16-byte Spill
	ldr	q5, [x28, #3280]
	str	q5, [sp, #8384]                 ; 16-byte Spill
	ldp	q5, q6, [x28, #224]
	str	q6, [sp, #8464]                 ; 16-byte Spill
	str	q5, [sp, #8400]                 ; 16-byte Spill
	ldp	q6, q5, [x9, #224]
	str	q6, [sp, #7712]                 ; 16-byte Spill
	str	q5, [sp, #7696]                 ; 16-byte Spill
	ldr	q5, [x28, #3312]
	str	q5, [sp, #8416]                 ; 16-byte Spill
	ldr	q5, [x28, #3296]
	str	q5, [sp, #8448]                 ; 16-byte Spill
	mov	w13, #37120                     ; =0x9100
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q5, [x28, #256]
	str	q6, [sp, #8480]                 ; 16-byte Spill
	str	q5, [sp, #8432]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x6]
	ldr	q5, [x10, #272]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v12, v1, v4
	ldr	q4, [x10, #256]
	and.16b	v4, v1, v4
	fmul.4s	v4, v12, v4
	fadd.4s	v2, v2, v4
	mov	w13, #39168                     ; =0x9900
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #256]
	str	q4, [sp, #7568]                 ; 16-byte Spill
	str	q0, [sp, #7536]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x22]
	ldr	q4, [x0, #288]
	and.16b	v0, v1, v4
	str	q0, [sp, #9264]                 ; 16-byte Spill
	ldr	q4, [x10, #288]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #304]
	and.16b	v0, v13, v4
	str	q0, [sp, #8912]                 ; 16-byte Spill
	ldr	q4, [x10, #304]
	and.16b	v4, v13, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v3, v3, v4
	ldr	q0, [x28, #3328]
	str	q0, [sp, #8240]                 ; 16-byte Spill
	ldr	q0, [x28, #3344]
	str	q0, [sp, #8272]                 ; 16-byte Spill
	ldp	q0, q4, [x28, #288]
	str	q4, [sp, #8304]                 ; 16-byte Spill
	str	q0, [sp, #8288]                 ; 16-byte Spill
	ldp	q4, q0, [x9, #288]
	str	q4, [sp, #7504]                 ; 16-byte Spill
	str	q0, [sp, #7488]                 ; 16-byte Spill
	ldr	q0, [x28, #3376]
	str	q0, [sp, #8224]                 ; 16-byte Spill
	ldr	q0, [x28, #3360]
	str	q0, [sp, #8256]                 ; 16-byte Spill
	ldp	q4, q5, [x0, #320]
	mov	w13, #37184                     ; =0x9140
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q0, [x28, #320]
	str	q6, [sp, #8192]                 ; 16-byte Spill
	str	q0, [sp, #8160]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x1]
	and.16b	v0, v13, v5
	str	q0, [sp, #9488]                 ; 16-byte Spill
	ldr	q5, [x10, #336]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v0, v1, v4
	str	q0, [sp, #9472]                 ; 16-byte Spill
	ldr	q4, [x10, #320]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	mov	w13, #39232                     ; =0x9940
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #320]
	str	q4, [sp, #7392]                 ; 16-byte Spill
	str	q0, [sp, #7360]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x5]
	ldr	q4, [x0, #352]
	and.16b	v0, v1, v4
	str	q0, [sp, #9456]                 ; 16-byte Spill
	ldr	q4, [x10, #352]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #368]
	and.16b	v0, v13, v4
	str	q0, [sp, #9440]                 ; 16-byte Spill
	ldr	q4, [x10, #368]
	and.16b	v4, v13, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v3, v3, v4
	ldp	q4, q5, [x0, #384]
	and.16b	v0, v13, v5
	str	q0, [sp, #9424]                 ; 16-byte Spill
	ldr	q5, [x28, #3392]
	str	q5, [sp, #7952]                 ; 16-byte Spill
	ldr	q5, [x28, #3408]
	str	q5, [sp, #7968]                 ; 16-byte Spill
	ldp	q5, q6, [x28, #352]
	str	q6, [sp, #8048]                 ; 16-byte Spill
	str	q5, [sp, #7984]                 ; 16-byte Spill
	ldp	q6, q5, [x9, #352]
	str	q6, [sp, #7312]                 ; 16-byte Spill
	str	q5, [sp, #7296]                 ; 16-byte Spill
	ldr	q5, [x28, #3440]
	str	q5, [sp, #8000]                 ; 16-byte Spill
	ldr	q5, [x28, #3424]
	str	q5, [sp, #8032]                 ; 16-byte Spill
	mov	w13, #37248                     ; =0x9180
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q5, [x28, #384]
	str	q6, [sp, #8064]                 ; 16-byte Spill
	str	q5, [sp, #8016]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x20]
	ldr	q5, [x10, #400]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v0, v1, v4
	str	q0, [sp, #9408]                 ; 16-byte Spill
	ldr	q4, [x10, #384]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	mov	w13, #39296                     ; =0x9980
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #384]
	str	q4, [sp, #7152]                 ; 16-byte Spill
	str	q0, [sp, #7136]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x15]
	ldr	q4, [x0, #416]
	and.16b	v0, v1, v4
	str	q0, [sp, #9392]                 ; 16-byte Spill
	ldr	q4, [x10, #416]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #432]
	and.16b	v0, v13, v4
	str	q0, [sp, #9376]                 ; 16-byte Spill
	ldr	q4, [x10, #432]
	and.16b	v4, v13, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v3, v3, v4
	ldp	q4, q5, [x0, #448]
	and.16b	v0, v13, v5
	str	q0, [sp, #9360]                 ; 16-byte Spill
	ldr	q5, [x28, #3456]
	str	q5, [sp, #7728]                 ; 16-byte Spill
	ldr	q5, [x28, #3472]
	str	q5, [sp, #7760]                 ; 16-byte Spill
	ldp	q5, q6, [x28, #416]
	str	q6, [sp, #7840]                 ; 16-byte Spill
	str	q5, [sp, #7776]                 ; 16-byte Spill
	ldp	q6, q5, [x9, #416]
	str	q6, [sp, #6992]                 ; 16-byte Spill
	str	q5, [sp, #6976]                 ; 16-byte Spill
	ldr	q5, [x28, #3504]
	str	q5, [sp, #7792]                 ; 16-byte Spill
	ldr	q5, [x28, #3488]
	str	q5, [sp, #7824]                 ; 16-byte Spill
	mov	w13, #37312                     ; =0x91c0
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q5, [x28, #448]
	str	q6, [sp, #7856]                 ; 16-byte Spill
	str	q5, [sp, #7808]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x14]
	ldr	q5, [x10, #464]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v0, v1, v4
	str	q0, [sp, #9344]                 ; 16-byte Spill
	ldr	q4, [x10, #448]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	mov	w13, #39360                     ; =0x99c0
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #448]
	str	q4, [sp, #6960]                 ; 16-byte Spill
	str	q0, [sp, #6944]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x17]
	ldr	q4, [x0, #480]
	and.16b	v0, v1, v4
	str	q0, [sp, #9328]                 ; 16-byte Spill
	ldr	q4, [x10, #480]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #496]
	and.16b	v0, v13, v4
	str	q0, [sp, #9312]                 ; 16-byte Spill
	ldr	q4, [x10, #496]
	and.16b	v4, v13, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v3, v3, v4
	ldr	q0, [x28, #3520]
	str	q0, [sp, #7600]                 ; 16-byte Spill
	ldr	q0, [x28, #3536]
	str	q0, [sp, #7632]                 ; 16-byte Spill
	ldp	q0, q4, [x28, #480]
	str	q4, [sp, #7680]                 ; 16-byte Spill
	str	q0, [sp, #7648]                 ; 16-byte Spill
	ldp	q4, q0, [x9, #480]
	str	q4, [sp, #6912]                 ; 16-byte Spill
	str	q0, [sp, #6832]                 ; 16-byte Spill
	ldr	q0, [x28, #3568]
	str	q0, [sp, #7584]                 ; 16-byte Spill
	ldr	q0, [x28, #3552]
	str	q0, [sp, #7616]                 ; 16-byte Spill
	ldp	q4, q5, [x0, #512]
	mov	w13, #37376                     ; =0x9200
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q0, [x28, #512]
	str	q6, [sp, #7552]                 ; 16-byte Spill
	str	q0, [sp, #7520]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x2]
	and.16b	v0, v13, v5
	str	q0, [sp, #9296]                 ; 16-byte Spill
	ldr	q5, [x10, #528]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v0, v1, v4
	str	q0, [sp, #9280]                 ; 16-byte Spill
	ldr	q4, [x10, #512]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	mov	w13, #39424                     ; =0x9a00
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #512]
	str	q4, [sp, #6768]                 ; 16-byte Spill
	str	q0, [sp, #6752]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x3]
	ldr	q4, [x0, #544]
	and.16b	v0, v1, v4
	str	q0, [sp, #9248]                 ; 16-byte Spill
	ldr	q4, [x10, #544]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #560]
	and.16b	v0, v13, v4
	str	q0, [sp, #9232]                 ; 16-byte Spill
	ldr	q4, [x10, #560]
	and.16b	v4, v13, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v3, v3, v4
	ldp	q4, q5, [x0, #576]
	and.16b	v0, v13, v5
	str	q0, [sp, #9216]                 ; 16-byte Spill
	ldr	q5, [x28, #3584]
	str	q5, [sp, #7328]                 ; 16-byte Spill
	ldr	q5, [x28, #3600]
	str	q5, [sp, #7344]                 ; 16-byte Spill
	ldp	q5, q6, [x28, #544]
	str	q6, [sp, #7456]                 ; 16-byte Spill
	str	q5, [sp, #7376]                 ; 16-byte Spill
	ldp	q6, q5, [x9, #544]
	str	q6, [sp, #6608]                 ; 16-byte Spill
	str	q5, [sp, #6592]                 ; 16-byte Spill
	ldr	q5, [x28, #3632]
	str	q5, [sp, #7408]                 ; 16-byte Spill
	ldr	q5, [x28, #3616]
	str	q5, [sp, #7440]                 ; 16-byte Spill
	mov	w13, #37440                     ; =0x9240
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q5, [x28, #576]
	str	q6, [sp, #7472]                 ; 16-byte Spill
	str	q5, [sp, #7424]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x7]
	ldr	q5, [x10, #592]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v0, v1, v4
	str	q0, [sp, #9200]                 ; 16-byte Spill
	ldr	q4, [x10, #576]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	mov	w13, #39488                     ; =0x9a40
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #576]
	str	q4, [sp, #6576]                 ; 16-byte Spill
	str	q0, [sp, #6544]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x19]
	ldr	q4, [x0, #608]
	and.16b	v0, v1, v4
	str	q0, [sp, #9184]                 ; 16-byte Spill
	ldr	q4, [x10, #608]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #624]
	and.16b	v0, v13, v4
	str	q0, [sp, #9168]                 ; 16-byte Spill
	ldr	q4, [x10, #624]
	and.16b	v4, v13, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v3, v3, v4
	ldp	q4, q5, [x0, #640]
	and.16b	v0, v13, v5
	str	q0, [sp, #9152]                 ; 16-byte Spill
	ldr	q5, [x28, #3648]
	str	q5, [sp, #7168]                 ; 16-byte Spill
	ldr	q5, [x28, #3664]
	str	q5, [sp, #7184]                 ; 16-byte Spill
	ldp	q5, q6, [x28, #608]
	str	q6, [sp, #7264]                 ; 16-byte Spill
	str	q5, [sp, #7200]                 ; 16-byte Spill
	ldp	q6, q5, [x9, #608]
	str	q6, [sp, #6416]                 ; 16-byte Spill
	str	q5, [sp, #6400]                 ; 16-byte Spill
	ldr	q5, [x28, #3696]
	str	q5, [sp, #7216]                 ; 16-byte Spill
	ldr	q5, [x28, #3680]
	str	q5, [sp, #7248]                 ; 16-byte Spill
	mov	w13, #37504                     ; =0x9280
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q5, [x28, #640]
	str	q6, [sp, #7280]                 ; 16-byte Spill
	str	q5, [sp, #7232]                 ; 16-byte Spill
	prfm	pldl1keep, [x4, x23]
	ldr	q5, [x10, #656]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v0, v1, v4
	str	q0, [sp, #9136]                 ; 16-byte Spill
	ldr	q4, [x10, #640]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	mov	w13, #39552                     ; =0x9a80
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #640]
	str	q4, [sp, #6384]                 ; 16-byte Spill
	str	q0, [sp, #6352]                 ; 16-byte Spill
	mov	w13, #40576                     ; =0x9e80
	prfm	pldl1keep, [x4, x13]
	ldr	q4, [x0, #672]
	and.16b	v0, v1, v4
	str	q0, [sp, #9120]                 ; 16-byte Spill
	ldr	q4, [x10, #672]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #688]
	and.16b	v0, v13, v4
	str	q0, [sp, #9104]                 ; 16-byte Spill
	ldr	q4, [x10, #688]
	and.16b	v4, v13, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v3, v3, v4
	ldr	q0, [x28, #3712]
	str	q0, [sp, #7056]                 ; 16-byte Spill
	ldr	q0, [x28, #3728]
	str	q0, [sp, #7088]                 ; 16-byte Spill
	ldp	q0, q4, [x28, #672]
	str	q4, [sp, #7120]                 ; 16-byte Spill
	str	q0, [sp, #7104]                 ; 16-byte Spill
	ldp	q4, q0, [x9, #672]
	str	q4, [sp, #6224]                 ; 16-byte Spill
	str	q0, [sp, #6208]                 ; 16-byte Spill
	ldr	q0, [x28, #3760]
	str	q0, [sp, #7040]                 ; 16-byte Spill
	ldr	q0, [x28, #3744]
	str	q0, [sp, #7072]                 ; 16-byte Spill
	ldp	q4, q5, [x0, #704]
	mov	w13, #37568                     ; =0x92c0
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q0, [x28, #704]
	str	q6, [sp, #7024]                 ; 16-byte Spill
	str	q0, [sp, #7008]                 ; 16-byte Spill
	mov	w13, #38592                     ; =0x96c0
	prfm	pldl1keep, [x4, x13]
	and.16b	v0, v13, v5
	str	q0, [sp, #9088]                 ; 16-byte Spill
	ldr	q5, [x10, #720]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v0, v1, v4
	str	q0, [sp, #9072]                 ; 16-byte Spill
	ldr	q4, [x10, #704]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	mov	w13, #39616                     ; =0x9ac0
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #704]
	str	q4, [sp, #6176]                 ; 16-byte Spill
	str	q0, [sp, #6144]                 ; 16-byte Spill
	mov	w13, #40640                     ; =0x9ec0
	prfm	pldl1keep, [x4, x13]
	ldr	q4, [x0, #736]
	and.16b	v0, v1, v4
	str	q0, [sp, #9056]                 ; 16-byte Spill
	ldr	q4, [x10, #736]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #752]
	and.16b	v0, v13, v4
	str	q0, [sp, #9040]                 ; 16-byte Spill
	ldr	q4, [x10, #752]
	and.16b	v4, v13, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v3, v3, v4
	ldp	q4, q5, [x0, #768]
	and.16b	v0, v13, v5
	str	q0, [sp, #9024]                 ; 16-byte Spill
	ldr	q5, [x28, #3776]
	str	q5, [sp, #6784]                 ; 16-byte Spill
	ldr	q5, [x28, #3792]
	str	q5, [sp, #6800]                 ; 16-byte Spill
	ldp	q5, q6, [x28, #736]
	str	q6, [sp, #6896]                 ; 16-byte Spill
	str	q5, [sp, #6816]                 ; 16-byte Spill
	ldp	q6, q5, [x9, #736]
	str	q6, [sp, #6048]                 ; 16-byte Spill
	str	q5, [sp, #6032]                 ; 16-byte Spill
	ldr	q5, [x28, #3824]
	str	q5, [sp, #6848]                 ; 16-byte Spill
	ldr	q5, [x28, #3808]
	str	q5, [sp, #6880]                 ; 16-byte Spill
	mov	w13, #37632                     ; =0x9300
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q5, [x28, #768]
	str	q6, [sp, #6928]                 ; 16-byte Spill
	str	q5, [sp, #6864]                 ; 16-byte Spill
	mov	w13, #38656                     ; =0x9700
	prfm	pldl1keep, [x4, x13]
	ldr	q5, [x10, #784]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v0, v1, v4
	str	q0, [sp, #9008]                 ; 16-byte Spill
	ldr	q4, [x10, #768]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	mov	w13, #39680                     ; =0x9b00
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #768]
	str	q4, [sp, #6016]                 ; 16-byte Spill
	str	q0, [sp, #6000]                 ; 16-byte Spill
	mov	w13, #40704                     ; =0x9f00
	prfm	pldl1keep, [x4, x13]
	ldr	q4, [x0, #800]
	and.16b	v0, v1, v4
	str	q0, [sp, #8992]                 ; 16-byte Spill
	ldr	q4, [x10, #800]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #816]
	and.16b	v0, v13, v4
	str	q0, [sp, #8976]                 ; 16-byte Spill
	ldr	q4, [x10, #816]
	and.16b	v4, v13, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v3, v3, v4
	ldp	q4, q5, [x0, #832]
	and.16b	v0, v13, v5
	str	q0, [sp, #8960]                 ; 16-byte Spill
	ldr	q5, [x28, #3840]
	str	q5, [sp, #6624]                 ; 16-byte Spill
	ldr	q5, [x28, #3856]
	str	q5, [sp, #6640]                 ; 16-byte Spill
	ldp	q5, q6, [x28, #800]
	str	q6, [sp, #6720]                 ; 16-byte Spill
	str	q5, [sp, #6656]                 ; 16-byte Spill
	ldp	q6, q5, [x9, #800]
	str	q6, [sp, #5984]                 ; 16-byte Spill
	str	q5, [sp, #5968]                 ; 16-byte Spill
	ldr	q5, [x28, #3888]
	str	q5, [sp, #6672]                 ; 16-byte Spill
	ldr	q5, [x28, #3872]
	str	q5, [sp, #6704]                 ; 16-byte Spill
	mov	w13, #37696                     ; =0x9340
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q5, [x28, #832]
	str	q6, [sp, #6736]                 ; 16-byte Spill
	str	q5, [sp, #6688]                 ; 16-byte Spill
	mov	w13, #38720                     ; =0x9740
	prfm	pldl1keep, [x4, x13]
	ldr	q5, [x10, #848]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v10, v1, v4
	ldr	q4, [x10, #832]
	and.16b	v4, v1, v4
	fmul.4s	v4, v10, v4
	str	q10, [sp, #5856]                ; 16-byte Spill
	fadd.4s	v2, v2, v4
	mov	w13, #39744                     ; =0x9b40
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #832]
	str	q4, [sp, #5952]                 ; 16-byte Spill
	str	q0, [sp, #5936]                 ; 16-byte Spill
	mov	w13, #40768                     ; =0x9f40
	prfm	pldl1keep, [x4, x13]
	ldr	q4, [x0, #864]
	and.16b	v8, v1, v4
	ldr	q4, [x10, #864]
	and.16b	v4, v1, v4
	fmul.4s	v4, v8, v4
	str	q8, [sp, #5840]                 ; 16-byte Spill
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #880]
	and.16b	v22, v13, v4
	ldr	q4, [x10, #880]
	and.16b	v4, v13, v4
	fmul.4s	v4, v22, v4
	str	q22, [sp, #5872]                ; 16-byte Spill
	fadd.4s	v3, v3, v4
	ldr	q0, [x28, #3904]
	str	q0, [sp, #6496]                 ; 16-byte Spill
	ldr	q0, [x28, #3920]
	str	q0, [sp, #6512]                 ; 16-byte Spill
	ldp	q0, q4, [x28, #864]
	str	q4, [sp, #6560]                 ; 16-byte Spill
	str	q0, [sp, #6528]                 ; 16-byte Spill
	ldp	q4, q0, [x9, #864]
	str	q4, [sp, #5920]                 ; 16-byte Spill
	str	q0, [sp, #5888]                 ; 16-byte Spill
	ldr	q0, [x28, #3952]
	str	q0, [sp, #6464]                 ; 16-byte Spill
	ldr	q0, [x28, #3936]
	str	q0, [sp, #6480]                 ; 16-byte Spill
	ldp	q4, q5, [x0, #896]
	mov	w13, #37760                     ; =0x9380
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q0, [x28, #896]
	str	q6, [sp, #6448]                 ; 16-byte Spill
	str	q0, [sp, #6432]                 ; 16-byte Spill
	mov	w13, #38784                     ; =0x9780
	prfm	pldl1keep, [x4, x13]
	and.16b	v0, v13, v5
	str	q0, [sp, #5824]                 ; 16-byte Spill
	ldr	q5, [x10, #912]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v0, v1, v4
	str	q0, [sp, #5792]                 ; 16-byte Spill
	ldr	q4, [x10, #896]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	mov	w13, #39808                     ; =0x9b80
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #896]
	str	q4, [sp, #5808]                 ; 16-byte Spill
	movi.2d	v16, #0000000000000000
	str	q0, [sp, #5776]                 ; 16-byte Spill
	mov	w13, #40832                     ; =0x9f80
	prfm	pldl1keep, [x4, x13]
	ldr	q4, [x0, #928]
	and.16b	v0, v1, v4
	str	q0, [sp, #5760]                 ; 16-byte Spill
	ldr	q4, [x10, #928]
	and.16b	v4, v1, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #944]
	and.16b	v0, v13, v4
	str	q0, [sp, #8928]                 ; 16-byte Spill
	ldr	q4, [x10, #944]
	and.16b	v4, v13, v4
	fmul.4s	v4, v0, v4
	fadd.4s	v3, v3, v4
	ldp	q4, q5, [x0, #960]
	and.16b	v0, v13, v5
	str	q0, [sp, #8944]                 ; 16-byte Spill
	ldr	q5, [x28, #3968]
	str	q5, [sp, #6240]                 ; 16-byte Spill
	ldr	q5, [x28, #3984]
	str	q5, [sp, #6256]                 ; 16-byte Spill
	ldp	q5, q6, [x28, #928]
	str	q6, [sp, #6336]                 ; 16-byte Spill
	str	q5, [sp, #6272]                 ; 16-byte Spill
	ldp	q6, q5, [x9, #928]
	str	q6, [sp, #5744]                 ; 16-byte Spill
	str	q5, [sp, #5728]                 ; 16-byte Spill
	ldr	q5, [x28, #4016]
	str	q5, [sp, #6288]                 ; 16-byte Spill
	ldr	q5, [x28, #4000]
	str	q5, [sp, #6304]                 ; 16-byte Spill
	mov	w13, #37824                     ; =0x93c0
	prfm	pldl1keep, [x4, x13]
	ldp	q6, q5, [x28, #960]
	str	q6, [sp, #6368]                 ; 16-byte Spill
	str	q5, [sp, #6320]                 ; 16-byte Spill
	mov	w13, #38848                     ; =0x97c0
	prfm	pldl1keep, [x4, x13]
	ldr	q5, [x10, #976]
	and.16b	v5, v13, v5
	fmul.4s	v5, v0, v5
	fadd.4s	v3, v3, v5
	and.16b	v18, v1, v4
	ldr	q4, [x10, #960]
	and.16b	v4, v1, v4
	fmul.4s	v4, v18, v4
	str	q18, [sp, #5904]                ; 16-byte Spill
	fadd.4s	v2, v2, v4
	mov	w13, #39872                     ; =0x9bc0
	prfm	pldl1keep, [x4, x13]
	ldp	q0, q4, [x9, #960]
	str	q4, [sp, #5712]                 ; 16-byte Spill
	str	q0, [sp, #5696]                 ; 16-byte Spill
	mov	w13, #40896                     ; =0x9fc0
	prfm	pldl1keep, [x4, x13]
	ldr	q4, [x0, #992]
	and.16b	v29, v1, v4
	ldp	q4, q15, [x10, #992]
	and.16b	v4, v1, v4
	fmul.4s	v4, v29, v4
	fadd.4s	v2, v2, v4
	ldr	q4, [x0, #1008]
	and.16b	v26, v13, v4
	and.16b	v15, v13, v15
	fmul.4s	v15, v26, v15
	fadd.4s	v3, v3, v15
	add	x10, x12, x30
	ldr	q15, [x10, #16]
	bit.16b	v15, v3, v13
	ldr	q3, [x10]
	mov.16b	v0, v1
	bsl.16b	v0, v2, v3
	ldp	q3, q2, [x9, #992]
	ldr	q4, [x28, #4032]
	str	q4, [sp, #6064]                 ; 16-byte Spill
	ldr	q4, [x28, #4048]
	str	q4, [sp, #6080]                 ; 16-byte Spill
	ldp	q4, q5, [x28, #992]
	str	q5, [sp, #6112]                 ; 16-byte Spill
	str	q4, [sp, #6096]                 ; 16-byte Spill
	ldr	q4, [x28, #4080]
	str	q4, [sp, #6160]                 ; 16-byte Spill
	ldr	q4, [x28, #4064]
	str	q4, [sp, #6128]                 ; 16-byte Spill
	stp	q0, q15, [x10]
	and.16b	v0, v13, v21
	mov.16b	v7, v24
	fmul.4s	v0, v24, v0
	and.16b	v15, v13, v30
	fadd.4s	v0, v0, v16
	mov.16b	v17, v14
	fmul.4s	v15, v14, v15
	fadd.4s	v0, v0, v15
	and.16b	v15, v1, v20
	mov.16b	v4, v19
	fmul.4s	v15, v19, v15
	and.16b	v14, v1, v11
	fadd.4s	v15, v15, v16
	mov.16b	v5, v28
	fmul.4s	v14, v28, v14
	fadd.4s	v14, v15, v14
	ldr	q6, [sp, #8320]                 ; 16-byte Reload
	and.16b	v15, v1, v6
	ldr	q19, [sp, #8352]                ; 16-byte Reload
	fmul.4s	v15, v19, v15
	fadd.4s	v14, v14, v15
	ldr	q6, [sp, #8336]                 ; 16-byte Reload
	and.16b	v15, v13, v6
	mov.16b	v6, v31
	fmul.4s	v15, v31, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #8144]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q21, [sp, #8208]                ; 16-byte Reload
	fmul.4s	v15, v21, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #8176]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q20, [sp, #6192]                ; 16-byte Reload
	fmul.4s	v15, v20, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #8096]                ; 16-byte Reload
	and.16b	v15, v1, v16
	mov.16b	v24, v23
	fmul.4s	v15, v23, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #8112]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q23, [sp, #8128]                ; 16-byte Reload
	fmul.4s	v15, v23, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #7920]                ; 16-byte Reload
	and.16b	v15, v13, v16
	mov.16b	v28, v25
	fmul.4s	v15, v25, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #7936]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q25, [sp, #8080]                ; 16-byte Reload
	fmul.4s	v15, v25, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #7872]                ; 16-byte Reload
	and.16b	v15, v1, v16
	mov.16b	v30, v27
	fmul.4s	v15, v27, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #7888]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q27, [sp, #7904]                ; 16-byte Reload
	fmul.4s	v15, v27, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #7696]                ; 16-byte Reload
	and.16b	v15, v13, v16
	fmul.4s	v15, v9, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #7712]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q31, [sp, #7744]                ; 16-byte Reload
	fmul.4s	v15, v31, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #7536]                ; 16-byte Reload
	and.16b	v15, v1, v16
	fmul.4s	v15, v12, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #7568]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q11, [sp, #7664]                ; 16-byte Reload
	fmul.4s	v15, v11, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #7488]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #8912]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #7504]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9264]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #7360]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9472]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #7392]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9488]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #7296]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9440]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #7312]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9456]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #7136]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9408]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #7152]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9424]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #6976]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9376]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #6992]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9392]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #6944]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9344]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #6960]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9360]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #6832]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9312]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #6912]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9328]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #6752]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9280]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #6768]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9296]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #6592]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9232]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #6608]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9248]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #6544]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9200]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #6576]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9216]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #6400]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9168]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #6416]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9184]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #6352]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9136]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #6384]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9152]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #6208]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9104]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #6224]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9120]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #6144]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9072]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #6176]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9088]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #6032]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9040]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #6048]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9056]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #6000]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #9008]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #6016]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #9024]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #5968]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #8976]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #5984]                ; 16-byte Reload
	and.16b	v15, v1, v16
	ldr	q16, [sp, #8992]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #5936]                ; 16-byte Reload
	and.16b	v15, v1, v16
	fmul.4s	v15, v10, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #5952]                ; 16-byte Reload
	and.16b	v15, v13, v16
	ldr	q16, [sp, #8960]                ; 16-byte Reload
	fmul.4s	v15, v16, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #5888]                ; 16-byte Reload
	and.16b	v15, v13, v16
	fmul.4s	v15, v22, v15
	fadd.4s	v0, v0, v15
	ldr	q16, [sp, #5920]                ; 16-byte Reload
	and.16b	v15, v1, v16
	fmul.4s	v15, v8, v15
	fadd.4s	v14, v14, v15
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	and.16b	v8, v1, v16
	ldr	q15, [sp, #5792]                ; 16-byte Reload
	fmul.4s	v8, v15, v8
	fadd.4s	v8, v14, v8
	ldr	q16, [sp, #5808]                ; 16-byte Reload
	and.16b	v10, v13, v16
	ldr	q14, [sp, #5824]                ; 16-byte Reload
	fmul.4s	v10, v14, v10
	fadd.4s	v0, v0, v10
	ldr	q16, [sp, #5728]                ; 16-byte Reload
	and.16b	v22, v13, v16
	ldr	q16, [sp, #8928]                ; 16-byte Reload
	fmul.4s	v22, v16, v22
	fadd.4s	v0, v0, v22
	ldr	q16, [sp, #5744]                ; 16-byte Reload
	and.16b	v22, v1, v16
	ldr	q10, [sp, #5760]                ; 16-byte Reload
	fmul.4s	v22, v10, v22
	fadd.4s	v22, v8, v22
	movi.2d	v8, #0000000000000000
	ldr	q16, [sp, #5696]                ; 16-byte Reload
	and.16b	v16, v1, v16
	fmul.4s	v16, v18, v16
	fadd.4s	v16, v22, v16
	ldr	q18, [sp, #5712]                ; 16-byte Reload
	and.16b	v18, v13, v18
	ldr	q22, [sp, #8944]                ; 16-byte Reload
	fmul.4s	v18, v22, v18
	fadd.4s	v0, v0, v18
	and.16b	v2, v13, v2
	fmul.4s	v2, v26, v2
	fadd.4s	v0, v0, v2
	and.16b	v2, v1, v3
	fmul.4s	v2, v29, v2
	fadd.4s	v2, v16, v2
	add	x9, x12, x27
	ldr	q3, [x9]
	bif.16b	v2, v3, v1
	ldr	q3, [x9, #16]
	bif.16b	v0, v3, v13
	stp	q2, q0, [x9]
	ldr	q0, [sp, #8880]                 ; 16-byte Reload
	and.16b	v0, v1, v0
	fmul.4s	v0, v4, v0
	ldr	q2, [sp, #8752]                 ; 16-byte Reload
	and.16b	v2, v1, v2
	fmul.4s	v2, v4, v2
	ldr	q3, [sp, #8896]                 ; 16-byte Reload
	and.16b	v3, v13, v3
	fmul.4s	v3, v7, v3
	ldr	q4, [sp, #8768]                 ; 16-byte Reload
	and.16b	v16, v13, v4
	fmul.4s	v16, v7, v16
	fadd.4s	v0, v0, v8
	ldr	q4, [sp, #8784]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	mov.16b	v7, v5
	fmul.4s	v18, v5, v18
	fadd.4s	v0, v0, v18
	fadd.4s	v3, v3, v8
	ldr	q4, [sp, #8832]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	fmul.4s	v18, v17, v18
	fadd.4s	v3, v3, v18
	ldr	q5, [sp, #8800]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	fmul.4s	v18, v17, v18
	ldr	q4, [sp, #8816]                 ; 16-byte Reload
	and.16b	v22, v1, v4
	fmul.4s	v22, v7, v22
	fadd.4s	v2, v2, v8
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v8
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #8848]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	mov.16b	v4, v6
	fmul.4s	v18, v6, v18
	fadd.4s	v3, v3, v18
	ldr	q5, [sp, #8864]                 ; 16-byte Reload
	and.16b	v18, v1, v5
	fmul.4s	v18, v19, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #8688]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v19, v18
	ldr	q5, [sp, #8704]                 ; 16-byte Reload
	and.16b	v22, v13, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #8720]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	fmul.4s	v18, v20, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #8736]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	fmul.4s	v18, v21, v18
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #8656]                 ; 16-byte Reload
	and.16b	v18, v13, v6
	fmul.4s	v18, v21, v18
	ldr	q5, [sp, #8672]                 ; 16-byte Reload
	and.16b	v22, v1, v5
	fmul.4s	v22, v20, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #8624]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	fmul.4s	v18, v23, v18
	fadd.4s	v3, v3, v18
	ldr	q4, [sp, #8640]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	fmul.4s	v18, v24, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #8496]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v24, v18
	ldr	q4, [sp, #8512]                 ; 16-byte Reload
	and.16b	v22, v13, v4
	fmul.4s	v22, v23, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #8528]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	fmul.4s	v18, v25, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #8592]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	fmul.4s	v18, v28, v18
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #8544]                 ; 16-byte Reload
	and.16b	v18, v13, v6
	fmul.4s	v18, v28, v18
	ldr	q5, [sp, #8576]                 ; 16-byte Reload
	and.16b	v22, v1, v5
	fmul.4s	v22, v25, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #8560]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	fmul.4s	v18, v27, v18
	fadd.4s	v3, v3, v18
	ldr	q5, [sp, #8608]                 ; 16-byte Reload
	and.16b	v18, v1, v5
	fmul.4s	v18, v30, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #8368]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v30, v18
	ldr	q5, [sp, #8384]                 ; 16-byte Reload
	and.16b	v22, v13, v5
	fmul.4s	v22, v27, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #8400]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	fmul.4s	v18, v31, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #8464]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	fmul.4s	v18, v9, v18
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #8416]                 ; 16-byte Reload
	and.16b	v18, v13, v6
	fmul.4s	v18, v9, v18
	ldr	q5, [sp, #8448]                 ; 16-byte Reload
	and.16b	v22, v1, v5
	fmul.4s	v22, v31, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #8432]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	fmul.4s	v18, v11, v18
	fadd.4s	v3, v3, v18
	ldr	q5, [sp, #8480]                 ; 16-byte Reload
	and.16b	v18, v1, v5
	fmul.4s	v18, v12, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #8240]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v12, v18
	ldr	q5, [sp, #8272]                 ; 16-byte Reload
	and.16b	v22, v13, v5
	fmul.4s	v22, v11, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #8288]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #9264]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #8304]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	ldr	q5, [sp, #8912]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #8224]                 ; 16-byte Reload
	and.16b	v18, v13, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #8256]                 ; 16-byte Reload
	and.16b	v22, v1, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #8160]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	ldr	q5, [sp, #9488]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v3, v3, v18
	ldr	q4, [sp, #8192]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #9472]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #7952]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v4, v18
	ldr	q4, [sp, #7968]                 ; 16-byte Reload
	and.16b	v22, v13, v4
	fmul.4s	v22, v5, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #7984]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #9456]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #8048]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	ldr	q5, [sp, #9440]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #8000]                 ; 16-byte Reload
	and.16b	v18, v13, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #8032]                 ; 16-byte Reload
	and.16b	v22, v1, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #8016]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	ldr	q4, [sp, #9424]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v3, v3, v18
	ldr	q5, [sp, #8064]                 ; 16-byte Reload
	and.16b	v18, v1, v5
	ldr	q5, [sp, #9408]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #7728]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #7760]                 ; 16-byte Reload
	and.16b	v22, v13, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #7776]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #9392]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #7840]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	ldr	q5, [sp, #9376]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #7792]                 ; 16-byte Reload
	and.16b	v18, v13, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #7824]                 ; 16-byte Reload
	and.16b	v22, v1, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #7808]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	ldr	q4, [sp, #9360]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v3, v3, v18
	ldr	q5, [sp, #7856]                 ; 16-byte Reload
	and.16b	v18, v1, v5
	ldr	q5, [sp, #9344]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #7600]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #7632]                 ; 16-byte Reload
	and.16b	v22, v13, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #7648]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #9328]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #7680]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	ldr	q5, [sp, #9312]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #7584]                 ; 16-byte Reload
	and.16b	v18, v13, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #7616]                 ; 16-byte Reload
	and.16b	v22, v1, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #7520]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	ldr	q5, [sp, #9296]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v3, v3, v18
	ldr	q4, [sp, #7552]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #9280]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #7328]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v4, v18
	ldr	q4, [sp, #7344]                 ; 16-byte Reload
	and.16b	v22, v13, v4
	fmul.4s	v22, v5, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #7376]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #9248]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #7456]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	ldr	q5, [sp, #9232]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #7408]                 ; 16-byte Reload
	and.16b	v18, v13, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #7440]                 ; 16-byte Reload
	and.16b	v22, v1, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #7424]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	ldr	q4, [sp, #9216]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v3, v3, v18
	ldr	q5, [sp, #7472]                 ; 16-byte Reload
	and.16b	v18, v1, v5
	ldr	q5, [sp, #9200]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #7168]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #7184]                 ; 16-byte Reload
	and.16b	v22, v13, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #7200]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #9184]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #7264]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	ldr	q5, [sp, #9168]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #7216]                 ; 16-byte Reload
	and.16b	v18, v13, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #7248]                 ; 16-byte Reload
	and.16b	v22, v1, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #7232]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	ldr	q4, [sp, #9152]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v3, v3, v18
	ldr	q5, [sp, #7280]                 ; 16-byte Reload
	and.16b	v18, v1, v5
	ldr	q5, [sp, #9136]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #7056]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #7088]                 ; 16-byte Reload
	and.16b	v22, v13, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #7104]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #9120]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #7120]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	ldr	q5, [sp, #9104]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #7040]                 ; 16-byte Reload
	and.16b	v18, v13, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #7072]                 ; 16-byte Reload
	and.16b	v22, v1, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #7008]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	ldr	q5, [sp, #9088]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v3, v3, v18
	ldr	q4, [sp, #7024]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #9072]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #6784]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v4, v18
	ldr	q4, [sp, #6800]                 ; 16-byte Reload
	and.16b	v22, v13, v4
	fmul.4s	v22, v5, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #6816]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #9056]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #6896]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	ldr	q5, [sp, #9040]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #6848]                 ; 16-byte Reload
	and.16b	v18, v13, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #6880]                 ; 16-byte Reload
	and.16b	v22, v1, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #6864]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	ldr	q4, [sp, #9024]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v3, v3, v18
	ldr	q5, [sp, #6928]                 ; 16-byte Reload
	and.16b	v18, v1, v5
	ldr	q5, [sp, #9008]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #6624]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #6640]                 ; 16-byte Reload
	and.16b	v22, v13, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #6656]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #8992]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #6720]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	ldr	q5, [sp, #8976]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #6672]                 ; 16-byte Reload
	and.16b	v18, v13, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #6704]                 ; 16-byte Reload
	and.16b	v22, v1, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v16, v16, v18
	ldr	q4, [sp, #6688]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	ldr	q4, [sp, #8960]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v3, v3, v18
	ldr	q5, [sp, #6736]                 ; 16-byte Reload
	and.16b	v18, v1, v5
	ldr	q5, [sp, #5856]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	fadd.4s	v0, v0, v18
	ldr	q6, [sp, #6496]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v18, v5, v18
	ldr	q5, [sp, #6512]                 ; 16-byte Reload
	and.16b	v22, v13, v5
	fmul.4s	v22, v4, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #6528]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	ldr	q4, [sp, #5840]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #6560]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	ldr	q5, [sp, #5872]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	ldr	q6, [sp, #6464]                 ; 16-byte Reload
	and.16b	v22, v13, v6
	fmul.4s	v22, v5, v22
	ldr	q5, [sp, #6480]                 ; 16-byte Reload
	and.16b	v23, v1, v5
	fadd.4s	v3, v3, v18
	fmul.4s	v18, v4, v23
	fadd.4s	v2, v2, v18
	fadd.4s	v16, v16, v22
	ldr	q4, [sp, #6432]                 ; 16-byte Reload
	and.16b	v18, v13, v4
	fmul.4s	v18, v14, v18
	fadd.4s	v3, v3, v18
	ldr	q4, [sp, #6448]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	fmul.4s	v18, v15, v18
	ldr	q6, [sp, #6240]                 ; 16-byte Reload
	and.16b	v22, v1, v6
	fmul.4s	v20, v15, v22
	ldr	q4, [sp, #6256]                 ; 16-byte Reload
	and.16b	v22, v13, v4
	fadd.4s	v0, v0, v18
	fmul.4s	v18, v14, v22
	fadd.4s	v16, v16, v18
	fadd.4s	v2, v2, v20
	ldr	q4, [sp, #6272]                 ; 16-byte Reload
	and.16b	v18, v1, v4
	fmul.4s	v18, v10, v18
	fadd.4s	v0, v0, v18
	ldr	q5, [sp, #6336]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	ldr	q5, [sp, #8928]                 ; 16-byte Reload
	fmul.4s	v18, v5, v18
	ldr	q6, [sp, #6288]                 ; 16-byte Reload
	and.16b	v20, v13, v6
	fmul.4s	v17, v5, v20
	ldr	q5, [sp, #6304]                 ; 16-byte Reload
	and.16b	v20, v1, v5
	fadd.4s	v3, v3, v18
	fmul.4s	v18, v10, v20
	fadd.4s	v2, v2, v18
	fadd.4s	v16, v16, v17
	ldr	q4, [sp, #6320]                 ; 16-byte Reload
	and.16b	v17, v13, v4
	ldr	q4, [sp, #8944]                 ; 16-byte Reload
	fmul.4s	v17, v4, v17
	fadd.4s	v3, v3, v17
	ldr	q5, [sp, #6368]                 ; 16-byte Reload
	and.16b	v17, v1, v5
	ldr	q5, [sp, #5904]                 ; 16-byte Reload
	fmul.4s	v17, v5, v17
	ldr	q6, [sp, #6064]                 ; 16-byte Reload
	and.16b	v18, v1, v6
	fmul.4s	v6, v5, v18
	ldr	q5, [sp, #6080]                 ; 16-byte Reload
	and.16b	v18, v13, v5
	fadd.4s	v0, v0, v17
	fmul.4s	v7, v4, v18
	fadd.4s	v7, v16, v7
	ldr	q4, [sp, #6096]                 ; 16-byte Reload
	and.16b	v16, v1, v4
	ldr	q4, [sp, #6112]                 ; 16-byte Reload
	and.16b	v17, v13, v4
	fmul.4s	v17, v26, v17
	fadd.4s	v2, v2, v6
	add	x9, x12, x26
	fmul.4s	v6, v29, v16
	ldr	q16, [sp, #6128]                ; 16-byte Reload
	and.16b	v16, v1, v16
	ldp	q18, q19, [x9]
	fadd.4s	v0, v0, v6
	ldr	q6, [sp, #6160]                 ; 16-byte Reload
	and.16b	v6, v13, v6
	fmul.4s	v4, v26, v6
	fmul.4s	v5, v29, v16
	ldp	q6, q16, [x9, #96]
	fadd.4s	v3, v3, v17
	fadd.4s	v2, v2, v5
	fadd.4s	v4, v7, v4
	bif.16b	v3, v19, v13
	bif.16b	v0, v18, v1
	stp	q0, q3, [x9]
	mov.16b	v0, v13
	bsl.16b	v0, v4, v16
	bif.16b	v2, v6, v1
	stp	q2, q0, [x9, #96]
	add	x24, x24, #1
	cmp	x24, #4
	b.ne	LBB0_32
; %bb.33:                               ; %direct.false265
                                        ;   in Loop: Header=BB0_31 Depth=2
	ldr	x8, [sp, #5648]                 ; 8-byte Reload
	add	x8, x8, #1
	cmp	x8, #8
	b.ne	LBB0_31
; %bb.34:                               ; %direct.false262
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q30, [sp, #3552]                ; 16-byte Reload
	fmov	w9, s30
	mov	w13, #1                         ; =0x1
	tbz	w9, #0, LBB0_36
; %bb.35:                               ; %cond.store
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #96]                   ; 16-byte Reload
	fmov	x10, d0
	strb	w13, [x10]
LBB0_36:                                ; %else282
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w9, w9, #0xff
	ldr	q17, [sp, #4960]                ; 16-byte Reload
	ldr	q18, [sp, #4944]                ; 16-byte Reload
	ldr	q21, [sp, #4592]                ; 16-byte Reload
	ldr	q22, [sp, #4576]                ; 16-byte Reload
	ldr	q23, [sp, #4560]                ; 16-byte Reload
	ldr	q24, [sp, #4544]                ; 16-byte Reload
	ldr	q8, [sp, #5248]                 ; 16-byte Reload
	ldr	q9, [sp, #5232]                 ; 16-byte Reload
	ldr	q10, [sp, #4528]                ; 16-byte Reload
	ldr	q25, [sp, #4512]                ; 16-byte Reload
	ldr	q26, [sp, #4496]                ; 16-byte Reload
	ldr	q11, [sp, #4448]                ; 16-byte Reload
	ldr	q12, [sp, #4432]                ; 16-byte Reload
	ldr	q14, [sp, #4416]                ; 16-byte Reload
	ldr	q15, [sp, #4400]                ; 16-byte Reload
	ldr	q27, [sp, #4368]                ; 16-byte Reload
	ldr	q28, [sp, #4352]                ; 16-byte Reload
	ldr	q29, [sp, #4336]                ; 16-byte Reload
	ldr	q19, [sp, #5216]                ; 16-byte Reload
	movi.8b	v20, #1
	mvni.4s	v31, #127, msl #16
	tbz	w9, #1, LBB0_38
; %bb.37:                               ; %cond.store283
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #96]                   ; 16-byte Reload
	mov.d	x10, v0[1]
	strb	w13, [x10]
LBB0_38:                                ; %else285
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w9, #2, LBB0_40
; %bb.39:                               ; %cond.store286
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #112]                  ; 16-byte Reload
	fmov	x10, d0
	strb	w13, [x10]
LBB0_40:                                ; %else288
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	x1, [sp, #608]                  ; 8-byte Reload
	ldr	x3, [sp, #600]                  ; 8-byte Reload
	mov	w17, #43691                     ; =0xaaab
	ldr	x12, [sp, #5512]                ; 8-byte Reload
	ldr	x8, [sp, #232]                  ; 8-byte Reload
	mov	x14, #-6148914691236517206      ; =0xaaaaaaaaaaaaaaaa
	movk	x14, #43691
	mov	w2, #1267                       ; =0x4f3
	movk	w2, #15925, lsl #16
	mov	w5, #29184                      ; =0x7200
	movk	w5, #48945, lsl #16
	mov	x6, #-1536                      ; =0xfffffffffffffa00
	mov	x7, #-48                        ; =0xffffffffffffffd0
	mov	w19, #48782                     ; =0xbe8e
	movk	w19, #46527, lsl #16
	ldr	x16, [sp, #4096]                ; 8-byte Reload
	tbnz	w9, #3, LBB0_268
; %bb.41:                               ; %else291
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #4, LBB0_269
LBB0_42:                                ; %else294
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #5, LBB0_270
LBB0_43:                                ; %else297
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #6, LBB0_271
LBB0_44:                                ; %else300
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #7, LBB0_272
LBB0_45:                                ; %else303
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x20, x16, #0x1
	cmp	x20, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbnz	w9, #0, LBB0_273
LBB0_46:                                ; %else307
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_274
LBB0_47:                                ; %else310
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #2, LBB0_275
LBB0_48:                                ; %else313
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #3, LBB0_276
LBB0_49:                                ; %else316
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #4, LBB0_277
LBB0_50:                                ; %else319
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #5, LBB0_278
LBB0_51:                                ; %else322
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #6, LBB0_279
LBB0_52:                                ; %else325
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #7, LBB0_280
LBB0_53:                                ; %else328
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x21, x16, #0x2
	cmp	x21, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbnz	w9, #0, LBB0_281
LBB0_54:                                ; %else333
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_282
LBB0_55:                                ; %else337
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #2, LBB0_283
LBB0_56:                                ; %else341
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #3, LBB0_284
LBB0_57:                                ; %else345
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #4, LBB0_285
LBB0_58:                                ; %else349
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #5, LBB0_286
LBB0_59:                                ; %else353
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #6, LBB0_287
LBB0_60:                                ; %else357
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #7, LBB0_288
LBB0_61:                                ; %else361
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x22, x16, #0x3
	cmp	x22, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbnz	w9, #0, LBB0_289
LBB0_62:                                ; %else366
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_290
LBB0_63:                                ; %else370
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #2, LBB0_291
LBB0_64:                                ; %else374
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #3, LBB0_292
LBB0_65:                                ; %else378
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #4, LBB0_293
LBB0_66:                                ; %else382
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #5, LBB0_294
LBB0_67:                                ; %else386
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #6, LBB0_295
LBB0_68:                                ; %else390
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #7, LBB0_296
LBB0_69:                                ; %else394
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x23, x16, #0x4
	cmp	x23, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbnz	w9, #0, LBB0_297
LBB0_70:                                ; %else399
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_298
LBB0_71:                                ; %else403
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #2, LBB0_299
LBB0_72:                                ; %else407
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #3, LBB0_300
LBB0_73:                                ; %else411
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #4, LBB0_301
LBB0_74:                                ; %else415
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #5, LBB0_302
LBB0_75:                                ; %else419
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #6, LBB0_303
LBB0_76:                                ; %else423
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w9, #7, LBB0_78
LBB0_77:                                ; %cond.store424
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2160]                 ; 16-byte Reload
	mov.d	x9, v0[1]
	st1.b	{ v2 }[7], [x9]
LBB0_78:                                ; %else427
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	w9, #5                          ; =0x5
	orr	x9, x16, x9
	str	x9, [sp, #9488]                 ; 8-byte Spill
	cmp	x9, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbnz	w9, #0, LBB0_304
; %bb.79:                               ; %else432
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_305
LBB0_80:                                ; %else436
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #2, LBB0_306
LBB0_81:                                ; %else440
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #3, LBB0_307
LBB0_82:                                ; %else444
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #4, LBB0_308
LBB0_83:                                ; %else448
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #5, LBB0_309
LBB0_84:                                ; %else452
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #6, LBB0_310
LBB0_85:                                ; %else456
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w9, #7, LBB0_87
LBB0_86:                                ; %cond.store457
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2032]                 ; 16-byte Reload
	mov.d	x9, v0[1]
	st1.b	{ v2 }[7], [x9]
LBB0_87:                                ; %else460
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x10, x16, #0x6
	orr	x9, x16, #0x6
	str	x9, [sp, #9472]                 ; 8-byte Spill
	cmp	x10, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbnz	w9, #0, LBB0_311
; %bb.88:                               ; %else465
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_312
LBB0_89:                                ; %else469
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #2, LBB0_313
LBB0_90:                                ; %else473
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #3, LBB0_314
LBB0_91:                                ; %else477
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #4, LBB0_315
LBB0_92:                                ; %else481
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #5, LBB0_316
LBB0_93:                                ; %else485
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #6, LBB0_317
LBB0_94:                                ; %else489
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w9, #7, LBB0_96
LBB0_95:                                ; %cond.store490
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1904]                 ; 16-byte Reload
	mov.d	x9, v0[1]
	st1.b	{ v2 }[7], [x9]
LBB0_96:                                ; %else493
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x10, x16, #0x7
	orr	x9, x16, #0x7
	str	x9, [sp, #9456]                 ; 8-byte Spill
	cmp	x10, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbnz	w9, #0, LBB0_318
; %bb.97:                               ; %else498
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_319
LBB0_98:                                ; %else502
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #2, LBB0_320
LBB0_99:                                ; %else506
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #3, LBB0_321
LBB0_100:                               ; %else510
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #4, LBB0_322
LBB0_101:                               ; %else514
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #5, LBB0_323
LBB0_102:                               ; %else518
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #6, LBB0_324
LBB0_103:                               ; %else522
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #7, LBB0_325
LBB0_104:                               ; %else526
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x26, x16, #0x8
	cmp	x26, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbnz	w9, #0, LBB0_326
LBB0_105:                               ; %else531
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_327
LBB0_106:                               ; %else535
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #2, LBB0_328
LBB0_107:                               ; %else539
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #3, LBB0_329
LBB0_108:                               ; %else543
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #4, LBB0_330
LBB0_109:                               ; %else547
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #5, LBB0_331
LBB0_110:                               ; %else551
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w9, #6, LBB0_332
LBB0_111:                               ; %else555
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w9, #7, LBB0_113
LBB0_112:                               ; %cond.store556
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1648]                 ; 16-byte Reload
	mov.d	x9, v0[1]
	st1.b	{ v2 }[7], [x9]
LBB0_113:                               ; %else559
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	w9, #9                          ; =0x9
	orr	x9, x16, x9
	cmp	x9, #129
	cset	w13, lo
	fmov	w10, s30
	dup.8b	v2, w13
	tbnz	w10, #0, LBB0_333
; %bb.114:                              ; %else564
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_334
LBB0_115:                               ; %else568
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w10, #2, LBB0_335
LBB0_116:                               ; %else572
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w10, #3, LBB0_336
LBB0_117:                               ; %else576
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w10, #4, LBB0_337
LBB0_118:                               ; %else580
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w10, #5, LBB0_338
LBB0_119:                               ; %else584
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w10, #6, LBB0_339
LBB0_120:                               ; %else588
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w10, #7, LBB0_122
LBB0_121:                               ; %cond.store589
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1520]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[7], [x10]
LBB0_122:                               ; %else592
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	w10, #10                        ; =0xa
	orr	x10, x16, x10
	cmp	x10, #129
	cset	w0, lo
	fmov	w13, s30
	dup.8b	v2, w0
	tbnz	w13, #0, LBB0_340
; %bb.123:                              ; %else597
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB0_341
LBB0_124:                               ; %else601
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w13, #2, LBB0_342
LBB0_125:                               ; %else605
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w13, #3, LBB0_343
LBB0_126:                               ; %else609
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w13, #4, LBB0_344
LBB0_127:                               ; %else613
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w13, #5, LBB0_345
LBB0_128:                               ; %else617
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w13, #6, LBB0_346
LBB0_129:                               ; %else621
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w13, #7, LBB0_131
LBB0_130:                               ; %cond.store622
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1392]                 ; 16-byte Reload
	mov.d	x13, v0[1]
	st1.b	{ v2 }[7], [x13]
LBB0_131:                               ; %else625
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	w13, #11                        ; =0xb
	orr	x13, x16, x13
	cmp	x13, #129
	cset	w4, lo
	fmov	w0, s30
	dup.8b	v2, w4
	tbnz	w0, #0, LBB0_347
; %bb.132:                              ; %else630
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w0, w0, #0xff
	tbnz	w0, #1, LBB0_348
LBB0_133:                               ; %else634
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w0, #2, LBB0_349
LBB0_134:                               ; %else638
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w0, #3, LBB0_350
LBB0_135:                               ; %else642
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w0, #4, LBB0_351
LBB0_136:                               ; %else646
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w0, #5, LBB0_352
LBB0_137:                               ; %else650
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w0, #6, LBB0_353
LBB0_138:                               ; %else654
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w0, #7, LBB0_354
LBB0_139:                               ; %else658
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x0, x16, #0xc
	cmp	x0, #129
	cset	w24, lo
	fmov	w4, s30
	dup.8b	v2, w24
	tbnz	w4, #0, LBB0_355
LBB0_140:                               ; %else663
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w4, w4, #0xff
	tbnz	w4, #1, LBB0_356
LBB0_141:                               ; %else667
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w4, #2, LBB0_357
LBB0_142:                               ; %else671
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w4, #3, LBB0_358
LBB0_143:                               ; %else675
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w4, #4, LBB0_359
LBB0_144:                               ; %else679
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w4, #5, LBB0_360
LBB0_145:                               ; %else683
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w4, #6, LBB0_361
LBB0_146:                               ; %else687
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w4, #7, LBB0_148
LBB0_147:                               ; %cond.store688
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1136]                 ; 16-byte Reload
	mov.d	x4, v0[1]
	st1.b	{ v2 }[7], [x4]
LBB0_148:                               ; %else691
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	w15, #13                        ; =0xd
	orr	x4, x16, x15
	cmp	x4, #129
	cset	w25, lo
	fmov	w24, s30
	dup.8b	v2, w25
	tbnz	w24, #0, LBB0_362
; %bb.149:                              ; %else696
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w24, w24, #0xff
	ldr	x15, [sp, #3504]                ; 8-byte Reload
	tbnz	w24, #1, LBB0_363
LBB0_150:                               ; %else700
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w24, #2, LBB0_364
LBB0_151:                               ; %else704
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w24, #3, LBB0_365
LBB0_152:                               ; %else708
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w24, #4, LBB0_366
LBB0_153:                               ; %else712
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w24, #5, LBB0_367
LBB0_154:                               ; %else716
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w24, #6, LBB0_368
LBB0_155:                               ; %else720
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w24, #7, LBB0_369
LBB0_156:                               ; %else724
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x24, x16, #0xe
	cmp	x24, #129
	cset	w27, lo
	fmov	w25, s30
	dup.8b	v2, w27
	tbnz	w25, #0, LBB0_370
LBB0_157:                               ; %else729
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w25, w25, #0xff
	tbnz	w25, #1, LBB0_371
LBB0_158:                               ; %else733
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w25, #2, LBB0_372
LBB0_159:                               ; %else737
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w25, #3, LBB0_373
LBB0_160:                               ; %else741
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w25, #4, LBB0_374
LBB0_161:                               ; %else745
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w25, #5, LBB0_375
LBB0_162:                               ; %else749
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w25, #6, LBB0_376
LBB0_163:                               ; %else753
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w25, #7, LBB0_377
LBB0_164:                               ; %else757
                                        ;   in Loop: Header=BB0_22 Depth=1
	orr	x25, x16, #0xf
	cmp	x25, #129
	cset	w28, lo
	fmov	w27, s30
	dup.8b	v2, w28
	tbnz	w27, #0, LBB0_378
LBB0_165:                               ; %else762
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w27, w27, #0xff
	tbnz	w27, #1, LBB0_379
LBB0_166:                               ; %else766
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w27, #2, LBB0_380
LBB0_167:                               ; %else770
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w27, #3, LBB0_381
LBB0_168:                               ; %else774
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w27, #4, LBB0_382
LBB0_169:                               ; %else778
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w27, #5, LBB0_383
LBB0_170:                               ; %else782
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w27, #6, LBB0_384
LBB0_171:                               ; %else786
                                        ;   in Loop: Header=BB0_22 Depth=1
	sshll.2d	v3, v1, #0
	sshll.2d	v4, v13, #0
	tbz	w27, #7, LBB0_173
LBB0_172:                               ; %cond.store787
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #288]                  ; 16-byte Reload
	mov.d	x27, v0[1]
	st1.b	{ v2 }[7], [x27]
LBB0_173:                               ; %else790
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x27, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
	mov	x30, #0                         ; =0x0
	dup.2d	v5, x16
	ldr	q0, [sp, #3536]                 ; 16-byte Reload
	ldr	q2, [sp, #5632]                 ; 16-byte Reload
	bit.16b	v2, v0, v4
	str	q2, [sp, #5632]                 ; 16-byte Spill
	ldr	x16, [sp, #2832]                ; 8-byte Reload
	ldp	q7, q6, [x16, #32]
	bit.16b	v25, v0, v3
	ldr	q2, [sp, #176]                  ; 16-byte Reload
	bit.16b	v23, v2, v4
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	bit.16b	v21, v2, v3
	sshll.2d	v3, v13, #0
	ldp	q16, q4, [x16]
	sshll.2d	v2, v1, #0
	bit.16b	v16, v5, v2
	bit.16b	v7, v5, v3
	bit.16b	v4, v5, v17
	bif.16b	v5, v6, v18
	dup.2d	v6, x20
	stp	q7, q5, [x16, #32]
	stp	q16, q4, [x16]
	ldr	x16, [sp, #2824]                ; 8-byte Reload
	ldp	q5, q4, [x16, #32]
	ldp	q16, q7, [x16]
	bit.16b	v16, v6, v2
	bit.16b	v5, v6, v3
	bit.16b	v7, v6, v17
	bit.16b	v4, v6, v18
	dup.2d	v6, x21
	stp	q5, q4, [x16, #32]
	stp	q16, q7, [x16]
	ldr	x16, [sp, #2816]                ; 8-byte Reload
	ldp	q5, q4, [x16, #32]
	ldp	q16, q7, [x16]
	bit.16b	v16, v6, v2
	bit.16b	v5, v6, v3
	bit.16b	v7, v6, v17
	bit.16b	v4, v6, v18
	stp	q5, q4, [x16, #32]
	stp	q16, q7, [x16]
	dup.2d	v4, x22
	ldr	x16, [sp, #2808]                ; 8-byte Reload
	ldp	q6, q5, [x16, #32]
	ldp	q16, q7, [x16]
	bit.16b	v16, v4, v2
	bit.16b	v6, v4, v3
	bit.16b	v7, v4, v17
	bif.16b	v4, v5, v18
	stp	q6, q4, [x16, #32]
	stp	q16, q7, [x16]
	dup.2d	v4, x23
	ldr	x16, [sp, #2800]                ; 8-byte Reload
	ldp	q6, q5, [x16, #32]
	ldp	q16, q7, [x16]
	bit.16b	v16, v4, v2
	bit.16b	v6, v4, v3
	bit.16b	v7, v4, v17
	bif.16b	v4, v5, v18
	stp	q6, q4, [x16, #32]
	stp	q16, q7, [x16]
	ldr	x16, [sp, #9488]                ; 8-byte Reload
	dup.2d	v4, x16
	ldr	x16, [sp, #2792]                ; 8-byte Reload
	ldp	q6, q5, [x16, #32]
	ldp	q16, q7, [x16]
	bit.16b	v16, v4, v2
	bit.16b	v6, v4, v3
	bit.16b	v7, v4, v17
	bif.16b	v4, v5, v18
	stp	q6, q4, [x16, #32]
	stp	q16, q7, [x16]
	ldr	x16, [sp, #9472]                ; 8-byte Reload
	dup.2d	v4, x16
	ldr	x16, [sp, #2784]                ; 8-byte Reload
	ldp	q6, q5, [x16, #32]
	ldp	q16, q7, [x16]
	bit.16b	v16, v4, v2
	bit.16b	v6, v4, v3
	bit.16b	v7, v4, v17
	bif.16b	v4, v5, v18
	stp	q6, q4, [x16, #32]
	stp	q16, q7, [x16]
	ldr	x16, [sp, #9456]                ; 8-byte Reload
	dup.2d	v4, x16
	ldr	x16, [sp, #2776]                ; 8-byte Reload
	ldp	q6, q5, [x16, #32]
	ldp	q16, q7, [x16]
	bit.16b	v16, v4, v2
	bit.16b	v6, v4, v3
	bit.16b	v7, v4, v17
	bif.16b	v4, v5, v18
	stp	q6, q4, [x16, #32]
	stp	q16, q7, [x16]
	dup.2d	v4, x26
	ldr	x16, [sp, #2768]                ; 8-byte Reload
	ldp	q6, q5, [x16, #32]
	ldp	q16, q7, [x16]
	bit.16b	v16, v4, v2
	bit.16b	v6, v4, v3
	bit.16b	v7, v4, v17
	bif.16b	v4, v5, v18
	stp	q6, q4, [x16, #32]
	stp	q16, q7, [x16]
	dup.2d	v4, x9
	ldr	x9, [sp, #2760]                 ; 8-byte Reload
	ldp	q6, q5, [x9, #32]
	ldp	q16, q7, [x9]
	bit.16b	v16, v4, v2
	bit.16b	v7, v4, v17
	bit.16b	v6, v4, v3
	bif.16b	v4, v5, v18
	stp	q6, q4, [x9, #32]
	stp	q16, q7, [x9]
	dup.2d	v4, x10
	ldr	x9, [sp, #2752]                 ; 8-byte Reload
	ldp	q5, q6, [x9, #32]
	ldp	q7, q16, [x9]
	bit.16b	v16, v4, v17
	bit.16b	v7, v4, v2
	bit.16b	v6, v4, v18
	bif.16b	v4, v5, v3
	stp	q4, q6, [x9, #32]
	stp	q7, q16, [x9]
	dup.2d	v4, x13
	ldr	x9, [sp, #2744]                 ; 8-byte Reload
	ldp	q5, q6, [x9, #32]
	ldp	q7, q16, [x9]
	bit.16b	v16, v4, v17
	bit.16b	v7, v4, v2
	bit.16b	v6, v4, v18
	bif.16b	v4, v5, v3
	stp	q4, q6, [x9, #32]
	stp	q7, q16, [x9]
	dup.2d	v4, x0
	ldr	x9, [sp, #2736]                 ; 8-byte Reload
	ldp	q6, q5, [x9, #32]
	ldp	q16, q7, [x9]
	bit.16b	v16, v4, v2
	bit.16b	v7, v4, v17
	bit.16b	v6, v4, v3
	bif.16b	v4, v5, v18
	stp	q6, q4, [x9, #32]
	stp	q16, q7, [x9]
	dup.2d	v4, x4
	ldr	x9, [sp, #2728]                 ; 8-byte Reload
	ldp	q6, q5, [x9, #32]
	ldp	q16, q7, [x9]
	bit.16b	v16, v4, v2
	bit.16b	v7, v4, v17
	bit.16b	v6, v4, v3
	bif.16b	v4, v5, v18
	stp	q6, q4, [x9, #32]
	stp	q16, q7, [x9]
	dup.2d	v4, x24
	ldr	x9, [sp, #2720]                 ; 8-byte Reload
	ldp	q6, q5, [x9, #32]
	ldp	q16, q7, [x9]
	bit.16b	v16, v4, v2
	bit.16b	v7, v4, v17
	bit.16b	v6, v4, v3
	bif.16b	v4, v5, v18
	stp	q6, q4, [x9, #32]
	stp	q16, q7, [x9]
	dup.2d	v4, x25
	ldr	x9, [sp, #2712]                 ; 8-byte Reload
	ldp	q6, q5, [x9, #32]
	ldp	q16, q7, [x9]
	bit.16b	v16, v4, v2
	bit.16b	v7, v4, v17
	bit.16b	v6, v4, v3
	bif.16b	v4, v5, v18
	stp	q6, q4, [x9, #32]
	stp	q16, q7, [x9]
	ldr	x9, [sp, #2704]                 ; 8-byte Reload
	ldp	q5, q4, [x9, #32]
	ldr	q6, [sp, #3408]                 ; 16-byte Reload
	bit.16b	v5, v6, v3
	ldr	q6, [sp, #3360]                 ; 16-byte Reload
	bit.16b	v4, v6, v18
	stp	q5, q4, [x9, #32]
	ldp	q5, q4, [x9]
	ldr	q6, [sp, #3376]                 ; 16-byte Reload
	bit.16b	v5, v6, v2
	ldr	q6, [sp, #3392]                 ; 16-byte Reload
	bit.16b	v4, v6, v17
	stp	q5, q4, [x9]
	ldr	x9, [sp, #2696]                 ; 8-byte Reload
	ldp	q5, q4, [x9, #32]
	ldr	q6, [sp, #3344]                 ; 16-byte Reload
	bit.16b	v5, v6, v3
	ldr	q6, [sp, #3296]                 ; 16-byte Reload
	bit.16b	v4, v6, v18
	stp	q5, q4, [x9, #32]
	ldp	q5, q4, [x9]
	ldr	q6, [sp, #3312]                 ; 16-byte Reload
	bit.16b	v5, v6, v2
	ldr	q6, [sp, #3328]                 ; 16-byte Reload
	bit.16b	v4, v6, v17
	stp	q5, q4, [x9]
	ldr	x9, [sp, #2688]                 ; 8-byte Reload
	ldp	q5, q4, [x9, #32]
	ldr	q6, [sp, #3280]                 ; 16-byte Reload
	bit.16b	v5, v6, v3
	ldr	q6, [sp, #3232]                 ; 16-byte Reload
	bit.16b	v4, v6, v18
	stp	q5, q4, [x9, #32]
	ldp	q5, q4, [x9]
	ldr	q6, [sp, #3248]                 ; 16-byte Reload
	bit.16b	v5, v6, v2
	ldr	q6, [sp, #3264]                 ; 16-byte Reload
	bit.16b	v4, v6, v17
	stp	q5, q4, [x9]
	ldr	x9, [sp, #2680]                 ; 8-byte Reload
	ldp	q5, q4, [x9, #32]
	ldr	q6, [sp, #3216]                 ; 16-byte Reload
	bit.16b	v5, v6, v3
	ldr	q6, [sp, #3168]                 ; 16-byte Reload
	bit.16b	v4, v6, v18
	stp	q5, q4, [x9, #32]
	ldp	q5, q4, [x9]
	ldr	q6, [sp, #3184]                 ; 16-byte Reload
	bit.16b	v5, v6, v2
	ldr	q6, [sp, #3200]                 ; 16-byte Reload
	bit.16b	v4, v6, v17
	stp	q5, q4, [x9]
	ldr	x9, [sp, #2672]                 ; 8-byte Reload
	ldp	q5, q4, [x9, #32]
	ldr	q6, [sp, #3152]                 ; 16-byte Reload
	bit.16b	v5, v6, v3
	ldr	q6, [sp, #3104]                 ; 16-byte Reload
	bit.16b	v4, v6, v18
	stp	q5, q4, [x9, #32]
	ldp	q5, q4, [x9]
	ldr	q6, [sp, #3120]                 ; 16-byte Reload
	bit.16b	v5, v6, v2
	ldr	q6, [sp, #3136]                 ; 16-byte Reload
	bit.16b	v4, v6, v17
	stp	q5, q4, [x9]
	ldr	x9, [sp, #2664]                 ; 8-byte Reload
	ldp	q5, q4, [x9, #32]
	ldr	q6, [sp, #3088]                 ; 16-byte Reload
	bit.16b	v5, v6, v3
	ldr	q6, [sp, #3040]                 ; 16-byte Reload
	bit.16b	v4, v6, v18
	stp	q5, q4, [x9, #32]
	ldp	q5, q4, [x9]
	ldr	q6, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v5, v6, v2
	ldr	q6, [sp, #3072]                 ; 16-byte Reload
	bit.16b	v4, v6, v17
	stp	q5, q4, [x9]
	ldr	x9, [sp, #2656]                 ; 8-byte Reload
	ldp	q5, q4, [x9, #32]
	ldr	q6, [sp, #3024]                 ; 16-byte Reload
	bit.16b	v5, v6, v3
	ldr	q6, [sp, #2976]                 ; 16-byte Reload
	bit.16b	v4, v6, v18
	stp	q5, q4, [x9, #32]
	ldr	q4, [x9]
	ldr	q6, [sp, #2992]                 ; 16-byte Reload
	bit.16b	v4, v6, v2
	ldr	x10, [sp, #2648]                ; 8-byte Reload
	ldr	q5, [x10, #32]
	ldr	q6, [sp, #2960]                 ; 16-byte Reload
	bit.16b	v5, v6, v3
	ldr	q6, [sp, #3488]                 ; 16-byte Reload
	bit.16b	v14, v6, v3
	ldr	q7, [sp, #432]                  ; 16-byte Reload
	bit.16b	v9, v7, v3
	ldr	q3, [x10]
	ldr	q7, [sp, #2928]                 ; 16-byte Reload
	bit.16b	v3, v7, v2
	bit.16b	v11, v6, v2
	ldr	q7, [sp, #480]                  ; 16-byte Reload
	ldr	q16, [sp, #5664]                ; 16-byte Reload
	bit.16b	v16, v7, v2
	str	q16, [sp, #5664]                ; 16-byte Spill
	ldr	q2, [x9, #16]
	ldr	q7, [sp, #3008]                 ; 16-byte Reload
	bit.16b	v2, v7, v17
	stp	q4, q2, [x9]
	ldr	q2, [x10, #48]
	ldr	q4, [sp, #2912]                 ; 16-byte Reload
	bit.16b	v2, v4, v18
	stp	q5, q2, [x10, #32]
	ldr	q2, [x10, #16]
	ldr	q4, [sp, #2944]                 ; 16-byte Reload
	bit.16b	v2, v4, v17
	stp	q3, q2, [x10]
	ldr	q2, [sp, #5616]                 ; 16-byte Reload
	bit.16b	v2, v0, v18
	str	q2, [sp, #5616]                 ; 16-byte Spill
	bit.16b	v26, v0, v17
	ldr	q0, [sp, #192]                  ; 16-byte Reload
	bit.16b	v24, v0, v18
	ldr	q0, [sp, #160]                  ; 16-byte Reload
	bit.16b	v22, v0, v17
	bit.16b	v15, v6, v18
	bit.16b	v12, v6, v17
	ldp	q0, q2, [sp, #448]              ; 32-byte Folded Reload
	bit.16b	v10, v2, v18
	bit.16b	v8, v0, v17
	ldr	x13, [sp, #3512]                ; 8-byte Reload
	ldr	q18, [sp, #4384]                ; 16-byte Reload
	b	LBB0_175
LBB0_174:                               ; %else872
                                        ;   in Loop: Header=BB0_175 Depth=2
	add	x30, x30, #1
	add	x28, x28, #8
	add	x27, x27, #64
	cmp	x30, #128
	b.eq	LBB0_207
LBB0_175:                               ; %direct.true1226
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s30
	lsr	x10, x30, #3
	dup.2d	v3, x10
	orr.16b	v0, v3, v21
	add.2d	v4, v25, v0
	tbz	w9, #0, LBB0_177
; %bb.176:                              ; %cond.load792
                                        ;   in Loop: Header=BB0_175 Depth=2
	fmov	x10, d4
	ldr	b2, [x10]
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_178
	b	LBB0_179
LBB0_177:                               ;   in Loop: Header=BB0_175 Depth=2
	movi.2d	v2, #0000000000000000
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_179
LBB0_178:                               ; %cond.load798
                                        ;   in Loop: Header=BB0_175 Depth=2
	mov.d	x10, v4[1]
	ld1.b	{ v2 }[1], [x10]
LBB0_179:                               ; %else802
                                        ;   in Loop: Header=BB0_175 Depth=2
	orr.16b	v0, v3, v22
	add.2d	v4, v26, v0
	tbnz	w9, #2, LBB0_194
; %bb.180:                              ; %else808
                                        ;   in Loop: Header=BB0_175 Depth=2
	tbnz	w9, #3, LBB0_195
LBB0_181:                               ; %else814
                                        ;   in Loop: Header=BB0_175 Depth=2
	orr.16b	v0, v3, v23
	ldr	q4, [sp, #5632]                 ; 16-byte Reload
	add.2d	v4, v4, v0
	tbnz	w9, #4, LBB0_196
LBB0_182:                               ; %else820
                                        ;   in Loop: Header=BB0_175 Depth=2
	tbnz	w9, #5, LBB0_197
LBB0_183:                               ; %else826
                                        ;   in Loop: Header=BB0_175 Depth=2
	orr.16b	v0, v3, v24
	ldr	q3, [sp, #5616]                 ; 16-byte Reload
	add.2d	v3, v3, v0
	tbnz	w9, #6, LBB0_198
LBB0_184:                               ; %else832
                                        ;   in Loop: Header=BB0_175 Depth=2
	tbz	w9, #7, LBB0_186
LBB0_185:                               ; %cond.load834
                                        ;   in Loop: Header=BB0_175 Depth=2
	mov.d	x9, v3[1]
	ld1.b	{ v2 }[7], [x9]
LBB0_186:                               ; %else838
                                        ;   in Loop: Header=BB0_175 Depth=2
	fmov	w9, s30
	cmeq.8b	v0, v2, #0
	and	x10, x28, #0x3c0
	add	x10, x13, x10
	ldp	q2, q3, [x10]
	ldp	q4, q5, [x10, #32]
	and	x10, x27, #0x1c0
	add	x10, x15, x10
	ldp	q6, q7, [x10]
	ldp	q16, q17, [x10, #32]
	cmge.2d	v5, v17, v5
	cmge.2d	v4, v16, v4
	uzp1.4s	v4, v4, v5
	cmge.2d	v3, v7, v3
	cmge.2d	v2, v6, v2
	uzp1.4s	v2, v2, v3
	uzp1.8h	v2, v2, v4
	xtn.8b	v2, v2
	ldr	d3, [sp, #5504]                 ; 8-byte Reload
	orr.8b	v2, v3, v2
	bic.8b	v0, v2, v0
	dup.2d	v3, x30
	ldr	q2, [sp, #5664]                 ; 16-byte Reload
	orr.16b	v2, v3, v2
	add.2d	v4, v11, v2
	and.8b	v2, v0, v20
	tbnz	w9, #0, LBB0_199
; %bb.187:                              ; %else844
                                        ;   in Loop: Header=BB0_175 Depth=2
	and	w9, w9, #0xff
	ldr	q6, [sp, #5600]                 ; 16-byte Reload
	ldr	q7, [sp, #5584]                 ; 16-byte Reload
	ldr	q16, [sp, #5568]                ; 16-byte Reload
	ldr	q17, [sp, #5552]                ; 16-byte Reload
	tbnz	w9, #1, LBB0_200
LBB0_188:                               ; %else848
                                        ;   in Loop: Header=BB0_175 Depth=2
	orr.16b	v0, v3, v8
	add.2d	v4, v12, v0
	tbnz	w9, #2, LBB0_201
LBB0_189:                               ; %else852
                                        ;   in Loop: Header=BB0_175 Depth=2
	tbnz	w9, #3, LBB0_202
LBB0_190:                               ; %else856
                                        ;   in Loop: Header=BB0_175 Depth=2
	orr.16b	v0, v3, v9
	add.2d	v4, v14, v0
	tbnz	w9, #4, LBB0_203
LBB0_191:                               ; %else860
                                        ;   in Loop: Header=BB0_175 Depth=2
	tbnz	w9, #5, LBB0_204
LBB0_192:                               ; %else864
                                        ;   in Loop: Header=BB0_175 Depth=2
	orr.16b	v0, v3, v10
	add.2d	v3, v15, v0
	tbnz	w9, #6, LBB0_205
LBB0_193:                               ; %else868
                                        ;   in Loop: Header=BB0_175 Depth=2
	tbz	w9, #7, LBB0_174
	b	LBB0_206
LBB0_194:                               ; %cond.load804
                                        ;   in Loop: Header=BB0_175 Depth=2
	fmov	x10, d4
	ld1.b	{ v2 }[2], [x10]
	tbz	w9, #3, LBB0_181
LBB0_195:                               ; %cond.load810
                                        ;   in Loop: Header=BB0_175 Depth=2
	mov.d	x10, v4[1]
	ld1.b	{ v2 }[3], [x10]
	orr.16b	v0, v3, v23
	ldr	q4, [sp, #5632]                 ; 16-byte Reload
	add.2d	v4, v4, v0
	tbz	w9, #4, LBB0_182
LBB0_196:                               ; %cond.load816
                                        ;   in Loop: Header=BB0_175 Depth=2
	fmov	x10, d4
	ld1.b	{ v2 }[4], [x10]
	tbz	w9, #5, LBB0_183
LBB0_197:                               ; %cond.load822
                                        ;   in Loop: Header=BB0_175 Depth=2
	mov.d	x10, v4[1]
	ld1.b	{ v2 }[5], [x10]
	orr.16b	v0, v3, v24
	ldr	q3, [sp, #5616]                 ; 16-byte Reload
	add.2d	v3, v3, v0
	tbz	w9, #6, LBB0_184
LBB0_198:                               ; %cond.load828
                                        ;   in Loop: Header=BB0_175 Depth=2
	fmov	x10, d3
	ld1.b	{ v2 }[6], [x10]
	tbnz	w9, #7, LBB0_185
	b	LBB0_186
LBB0_199:                               ; %cond.store841
                                        ;   in Loop: Header=BB0_175 Depth=2
	fmov	x10, d4
	str	b2, [x10]
	and	w9, w9, #0xff
	ldr	q6, [sp, #5600]                 ; 16-byte Reload
	ldr	q7, [sp, #5584]                 ; 16-byte Reload
	ldr	q16, [sp, #5568]                ; 16-byte Reload
	ldr	q17, [sp, #5552]                ; 16-byte Reload
	tbz	w9, #1, LBB0_188
LBB0_200:                               ; %cond.store845
                                        ;   in Loop: Header=BB0_175 Depth=2
	mov.d	x10, v4[1]
	st1.b	{ v2 }[1], [x10]
	orr.16b	v0, v3, v8
	add.2d	v4, v12, v0
	tbz	w9, #2, LBB0_189
LBB0_201:                               ; %cond.store849
                                        ;   in Loop: Header=BB0_175 Depth=2
	fmov	x10, d4
	st1.b	{ v2 }[2], [x10]
	tbz	w9, #3, LBB0_190
LBB0_202:                               ; %cond.store853
                                        ;   in Loop: Header=BB0_175 Depth=2
	mov.d	x10, v4[1]
	st1.b	{ v2 }[3], [x10]
	orr.16b	v0, v3, v9
	add.2d	v4, v14, v0
	tbz	w9, #4, LBB0_191
LBB0_203:                               ; %cond.store857
                                        ;   in Loop: Header=BB0_175 Depth=2
	fmov	x10, d4
	st1.b	{ v2 }[4], [x10]
	tbz	w9, #5, LBB0_192
LBB0_204:                               ; %cond.store861
                                        ;   in Loop: Header=BB0_175 Depth=2
	mov.d	x10, v4[1]
	st1.b	{ v2 }[5], [x10]
	orr.16b	v0, v3, v10
	add.2d	v3, v15, v0
	tbz	w9, #6, LBB0_193
LBB0_205:                               ; %cond.store865
                                        ;   in Loop: Header=BB0_175 Depth=2
	fmov	x10, d3
	st1.b	{ v2 }[6], [x10]
	tbz	w9, #7, LBB0_174
LBB0_206:                               ; %cond.store869
                                        ;   in Loop: Header=BB0_175 Depth=2
	mov.d	x9, v3[1]
	st1.b	{ v2 }[7], [x9]
	b	LBB0_174
LBB0_207:                               ; %direct.true1249.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #-128                      ; =0xffffffffffffff80
	add	x13, x11, #18, lsl #12          ; =73728
	ldr	x15, [sp, #3480]                ; 8-byte Reload
	ldr	q20, [sp, #208]                 ; 16-byte Reload
	b	LBB0_209
LBB0_208:                               ; %else920
                                        ;   in Loop: Header=BB0_209 Depth=2
	cmeq.8b	v0, v2, #0
	sshll.8h	v0, v0, #0
	sshll2.4s	v2, v0, #0
	sshll.4s	v0, v0, #0
	ldp	q4, q3, [x13]
	dup.4s	v5, w2
	fmul.4s	v4, v4, v5
	fmul.4s	v3, v3, v5
	and.16b	v3, v13, v3
	and.16b	v4, v1, v4
	bsl.16b	v0, v20, v4
	bsl.16b	v2, v20, v3
	ldr	q3, [x13, #6784]
	ldr	q4, [x13, #6800]
	bif.16b	v2, v4, v13
	bif.16b	v0, v3, v1
	str	q0, [x13, #6784]
	str	q2, [x13, #6800]
	add	x9, x9, #8
	add	x13, x13, #32
	adds	x10, x10, #1
	ldr	q5, [sp, #5536]                 ; 16-byte Reload
	b.hs	LBB0_225
LBB0_209:                               ; %direct.true1249
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w0, s30
	add	x4, x10, #128
	and	x24, x9, #0x78
	orr	x4, x24, x4, lsr #4
	dup.2d	v3, x4
	ldr	q0, [sp, #5664]                 ; 16-byte Reload
	orr.16b	v0, v3, v0
	add.2d	v4, v11, v0
	tbz	w0, #0, LBB0_211
; %bb.210:                              ; %cond.load874
                                        ;   in Loop: Header=BB0_209 Depth=2
	fmov	x4, d4
	ldr	b2, [x4]
	and	w0, w0, #0xff
	tbnz	w0, #1, LBB0_212
	b	LBB0_213
LBB0_211:                               ;   in Loop: Header=BB0_209 Depth=2
	movi.2d	v2, #0000000000000000
	and	w0, w0, #0xff
	tbz	w0, #1, LBB0_213
LBB0_212:                               ; %cond.load880
                                        ;   in Loop: Header=BB0_209 Depth=2
	mov.d	x4, v4[1]
	ld1.b	{ v2 }[1], [x4]
LBB0_213:                               ; %else884
                                        ;   in Loop: Header=BB0_209 Depth=2
	orr.16b	v0, v3, v8
	add.2d	v4, v12, v0
	tbnz	w0, #2, LBB0_219
; %bb.214:                              ; %else890
                                        ;   in Loop: Header=BB0_209 Depth=2
	tbnz	w0, #3, LBB0_220
LBB0_215:                               ; %else896
                                        ;   in Loop: Header=BB0_209 Depth=2
	orr.16b	v0, v3, v9
	add.2d	v4, v14, v0
	tbnz	w0, #4, LBB0_221
LBB0_216:                               ; %else902
                                        ;   in Loop: Header=BB0_209 Depth=2
	tbnz	w0, #5, LBB0_222
LBB0_217:                               ; %else908
                                        ;   in Loop: Header=BB0_209 Depth=2
	orr.16b	v0, v3, v10
	add.2d	v3, v15, v0
	tbnz	w0, #6, LBB0_223
LBB0_218:                               ; %else914
                                        ;   in Loop: Header=BB0_209 Depth=2
	tbz	w0, #7, LBB0_208
	b	LBB0_224
LBB0_219:                               ; %cond.load886
                                        ;   in Loop: Header=BB0_209 Depth=2
	fmov	x4, d4
	ld1.b	{ v2 }[2], [x4]
	tbz	w0, #3, LBB0_215
LBB0_220:                               ; %cond.load892
                                        ;   in Loop: Header=BB0_209 Depth=2
	mov.d	x4, v4[1]
	ld1.b	{ v2 }[3], [x4]
	orr.16b	v0, v3, v9
	add.2d	v4, v14, v0
	tbz	w0, #4, LBB0_216
LBB0_221:                               ; %cond.load898
                                        ;   in Loop: Header=BB0_209 Depth=2
	fmov	x4, d4
	ld1.b	{ v2 }[4], [x4]
	tbz	w0, #5, LBB0_217
LBB0_222:                               ; %cond.load904
                                        ;   in Loop: Header=BB0_209 Depth=2
	mov.d	x4, v4[1]
	ld1.b	{ v2 }[5], [x4]
	orr.16b	v0, v3, v10
	add.2d	v3, v15, v0
	tbz	w0, #6, LBB0_218
LBB0_223:                               ; %cond.load910
                                        ;   in Loop: Header=BB0_209 Depth=2
	fmov	x4, d3
	ld1.b	{ v2 }[6], [x4]
	tbz	w0, #7, LBB0_208
LBB0_224:                               ; %cond.load916
                                        ;   in Loop: Header=BB0_209 Depth=2
	mov.d	x0, v3[1]
	ld1.b	{ v2 }[7], [x0]
	b	LBB0_208
LBB0_225:                               ; %direct.false1250
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	q4, [sp, #4464]                 ; 16-byte Reload
	bit.16b	v4, v31, v13
	ldr	q3, [sp, #4480]                 ; 16-byte Reload
	bit.16b	v3, v31, v1
LBB0_226:                               ; %direct.true1269
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x15, x9
	ldp	q0, q2, [x10]
	and.16b	v2, v13, v2
	and.16b	v0, v1, v0
	fmaxnm.4s	v0, v3, v0
	fmaxnm.4s	v2, v4, v2
	bit.16b	v4, v2, v13
	bit.16b	v3, v0, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_226
; %bb.227:                              ; %direct.false1270
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x9, #0                          ; =0x0
	bit.16b	v16, v31, v13
	bit.16b	v7, v31, v1
	ldr	x13, [sp, #2888]                ; 8-byte Reload
	ldr	x16, [sp, #2904]                ; 8-byte Reload
	ldr	x0, [sp, #2896]                 ; 8-byte Reload
LBB0_228:                               ; %direct.true1280
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x16, x9
	ldp	q0, q2, [x10]
	and.16b	v2, v13, v2
	and.16b	v0, v1, v0
	fmaxnm.4s	v0, v7, v0
	fmaxnm.4s	v2, v16, v2
	bit.16b	v16, v2, v13
	bit.16b	v7, v0, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_228
; %bb.229:                              ; %direct.false1281
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x9, #0                          ; =0x0
	bit.16b	v6, v31, v13
	bit.16b	v28, v31, v1
LBB0_230:                               ; %direct.true1291
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x0, x9
	ldp	q0, q2, [x10]
	and.16b	v2, v13, v2
	and.16b	v0, v1, v0
	fmaxnm.4s	v0, v28, v0
	fmaxnm.4s	v2, v6, v2
	bit.16b	v6, v2, v13
	bit.16b	v28, v0, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_230
; %bb.231:                              ; %direct.false1292
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x9, #0                          ; =0x0
	bit.16b	v27, v31, v13
	bit.16b	v18, v31, v1
LBB0_232:                               ; %direct.true1302
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x13, x9
	ldp	q0, q2, [x10]
	and.16b	v2, v13, v2
	and.16b	v0, v1, v0
	fmaxnm.4s	v0, v18, v0
	fmaxnm.4s	v2, v27, v2
	bit.16b	v27, v2, v13
	bit.16b	v18, v0, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_232
; %bb.233:                              ; %direct.false1303
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	q20, [sp, #5200]                ; 16-byte Reload
	bit.16b	v20, v31, v13
	bit.16b	v19, v31, v1
	ldr	x13, [sp, #2880]                ; 8-byte Reload
LBB0_234:                               ; %direct.true1313
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x13, x9
	ldp	q0, q2, [x10]
	and.16b	v2, v13, v2
	and.16b	v0, v1, v0
	fmaxnm.4s	v0, v19, v0
	fmaxnm.4s	v2, v20, v2
	bit.16b	v20, v2, v13
	bit.16b	v19, v0, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_234
; %bb.235:                              ; %direct.false1314
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q20, [sp, #5200]                ; 16-byte Spill
	str	q19, [sp, #5216]                ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	bit.16b	v5, v31, v13
	ldr	q0, [sp, #5680]                 ; 16-byte Reload
	bit.16b	v0, v31, v1
	ldr	x13, [sp, #2872]                ; 8-byte Reload
LBB0_236:                               ; %direct.true1324
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	q0, [sp, #5680]                 ; 16-byte Spill
	add	x10, x13, x9
	ldp	q0, q2, [x10]
	and.16b	v2, v13, v2
	and.16b	v0, v1, v0
	mov.16b	v19, v5
	ldr	q5, [sp, #5680]                 ; 16-byte Reload
	fmaxnm.4s	v0, v5, v0
	fmaxnm.4s	v2, v19, v2
	mov.16b	v5, v13
	bsl.16b	v5, v2, v19
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	bit.16b	v2, v0, v1
	str	q2, [sp, #5680]                 ; 16-byte Spill
	ldr	q0, [sp, #5680]                 ; 16-byte Reload
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_236
; %bb.237:                              ; %direct.false1325
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x9, #0                          ; =0x0
	bit.16b	v29, v31, v13
	bit.16b	v17, v31, v1
	ldr	x13, [sp, #2864]                ; 8-byte Reload
	ldr	q20, [sp, #4256]                ; 16-byte Reload
LBB0_238:                               ; %direct.true1335
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x13, x9
	ldp	q0, q2, [x10]
	and.16b	v2, v13, v2
	and.16b	v0, v1, v0
	fmaxnm.4s	v0, v17, v0
	fmaxnm.4s	v2, v29, v2
	bit.16b	v29, v2, v13
	bit.16b	v17, v0, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_238
; %bb.239:                              ; %direct.false1336
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q9, [sp, #5232]                 ; 16-byte Spill
	str	q8, [sp, #5248]                 ; 16-byte Spill
	str	q26, [sp, #4496]                ; 16-byte Spill
	str	q25, [sp, #4512]                ; 16-byte Spill
	str	q24, [sp, #4544]                ; 16-byte Spill
	str	q23, [sp, #4560]                ; 16-byte Spill
	str	q22, [sp, #4576]                ; 16-byte Spill
	str	q21, [sp, #4592]                ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	ldr	q21, [sp, #4240]                ; 16-byte Reload
	bit.16b	v21, v31, v13
	bit.16b	v20, v31, v1
	ldr	x13, [sp, #2856]                ; 8-byte Reload
	ldr	q19, [sp, #5216]                ; 16-byte Reload
LBB0_240:                               ; %direct.true1346
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x13, x9
	ldp	q0, q2, [x10]
	and.16b	v2, v13, v2
	and.16b	v0, v1, v0
	fmaxnm.4s	v0, v20, v0
	fmaxnm.4s	v2, v21, v2
	bit.16b	v21, v2, v13
	bit.16b	v20, v0, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_240
; %bb.241:                              ; %direct.false1347
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	str	q3, [sp, #4480]                 ; 16-byte Spill
	ldr	q22, [sp, #4992]                ; 16-byte Reload
	fmaxnm.4s	v25, v22, v3
	str	q4, [sp, #4464]                 ; 16-byte Spill
	ldr	q24, [sp, #4976]                ; 16-byte Reload
	fmaxnm.4s	v26, v24, v4
	str	q7, [sp, #5584]                 ; 16-byte Spill
	ldr	q0, [sp, #5280]                 ; 16-byte Reload
	fmaxnm.4s	v9, v0, v7
	str	q16, [sp, #5568]                ; 16-byte Spill
	ldr	q0, [sp, #5264]                 ; 16-byte Reload
	fmaxnm.4s	v31, v0, v16
	str	q28, [sp, #4352]                ; 16-byte Spill
	ldr	q0, [sp, #5312]                 ; 16-byte Reload
	fmaxnm.4s	v3, v0, v28
	str	q3, [sp, #9456]                 ; 16-byte Spill
	str	q6, [sp, #5600]                 ; 16-byte Spill
	ldr	q0, [sp, #5296]                 ; 16-byte Reload
	fmaxnm.4s	v4, v0, v6
	str	q4, [sp, #9360]                 ; 16-byte Spill
	str	q18, [sp, #4384]                ; 16-byte Spill
	ldr	q0, [sp, #5344]                 ; 16-byte Reload
	fmaxnm.4s	v6, v0, v18
	str	q6, [sp, #9440]                 ; 16-byte Spill
	str	q27, [sp, #4368]                ; 16-byte Spill
	ldr	q0, [sp, #5328]                 ; 16-byte Reload
	fmaxnm.4s	v8, v0, v27
	str	q8, [sp, #9344]                 ; 16-byte Spill
	ldr	q0, [sp, #5376]                 ; 16-byte Reload
	fmaxnm.4s	v16, v0, v19
	str	q16, [sp, #9424]                ; 16-byte Spill
	ldr	q0, [sp, #5200]                 ; 16-byte Reload
	ldr	q2, [sp, #5360]                 ; 16-byte Reload
	fmaxnm.4s	v7, v2, v0
	str	q7, [sp, #9328]                 ; 16-byte Spill
	ldr	q0, [sp, #5680]                 ; 16-byte Reload
	ldr	q2, [sp, #5408]                 ; 16-byte Reload
	fmaxnm.4s	v28, v2, v0
	str	q28, [sp, #9408]                ; 16-byte Spill
	str	q5, [sp, #5536]                 ; 16-byte Spill
	ldr	q0, [sp, #5392]                 ; 16-byte Reload
	fmaxnm.4s	v18, v0, v5
	str	q18, [sp, #9312]                ; 16-byte Spill
	str	q17, [sp, #5552]                ; 16-byte Spill
	ldr	q0, [sp, #5456]                 ; 16-byte Reload
	fmaxnm.4s	v27, v0, v17
	str	q27, [sp, #9392]                ; 16-byte Spill
	str	q29, [sp, #4336]                ; 16-byte Spill
	ldr	q0, [sp, #5424]                 ; 16-byte Reload
	fmaxnm.4s	v19, v0, v29
	str	q19, [sp, #9296]                ; 16-byte Spill
	str	q20, [sp, #4256]                ; 16-byte Spill
	ldr	q0, [sp, #5472]                 ; 16-byte Reload
	fmaxnm.4s	v23, v0, v20
	str	q23, [sp, #9376]                ; 16-byte Spill
	str	q21, [sp, #4240]                ; 16-byte Spill
	ldr	q0, [sp, #5440]                 ; 16-byte Reload
	fmaxnm.4s	v21, v0, v21
	str	q21, [sp, #9280]                ; 16-byte Spill
	ldr	x13, [sp, #2640]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	bit.16b	v2, v26, v13
	bit.16b	v0, v25, v1
	stp	q0, q2, [x13]
	ldr	x13, [sp, #2632]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	bit.16b	v2, v31, v13
	bit.16b	v0, v9, v1
	stp	q0, q2, [x13]
	ldr	x13, [sp, #2624]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	bit.16b	v2, v4, v13
	bit.16b	v0, v3, v1
	ldr	x16, [sp, #2600]                ; 8-byte Reload
	ldp	q3, q4, [x16]
	bit.16b	v4, v8, v13
	mov.16b	v5, v1
	bsl.16b	v5, v6, v3
	ldr	x0, [sp, #2592]                 ; 8-byte Reload
	ldp	q3, q6, [x0]
	bit.16b	v6, v7, v13
	mov.16b	v7, v1
	bsl.16b	v7, v16, v3
	ldr	x4, [sp, #2568]                 ; 8-byte Reload
	ldp	q3, q16, [x4]
	bit.16b	v16, v18, v13
	mov.16b	v17, v1
	bsl.16b	v17, v28, v3
	ldr	x24, [sp, #2560]                ; 8-byte Reload
	ldp	q3, q18, [x24]
	bit.16b	v18, v19, v13
	mov.16b	v19, v1
	bsl.16b	v19, v27, v3
	ldr	x25, [sp, #2536]                ; 8-byte Reload
	ldp	q3, q20, [x25]
	bit.16b	v20, v21, v13
	bif.16b	v23, v3, v1
	str	q26, [sp, #9088]                ; 16-byte Spill
	fsub.4s	v3, v24, v26
	stp	q0, q2, [x13]
	str	q25, [sp, #9120]                ; 16-byte Spill
	fsub.4s	v0, v22, v25
	and.16b	v21, v1, v0
	mov	w13, #-1026555904               ; =0xc2d00000
	dup.4s	v2, w13
	and.16b	v22, v13, v3
	fcmge.4s	v0, v22, v2
	mov	w13, #1120403456                ; =0x42c80000
	dup.4s	v3, w13
	stp	q5, q4, [x16]
	fcmge.4s	v4, v21, v2
	fcmge.4s	v5, v3, v22
	fcmge.4s	v24, v3, v21
	stp	q7, q6, [x0]
	and.16b	v6, v4, v24
	and.16b	v0, v0, v5
	and.16b	v0, v0, v22
	mov	w13, #43579                     ; =0xaa3b
	movk	w13, #16312, lsl #16
	dup.4s	v4, w13
	stp	q17, q16, [x4]
	and.16b	v5, v6, v21
	fmul.4s	v6, v5, v4
	fmul.4s	v7, v0, v4
	stp	q19, q18, [x24]
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v16, v18
	bsl.16b	v16, v17, v7
	bif.16b	v17, v6, v18
	movi.4s	v28, #75, lsl #24
	fadd.4s	v6, v6, v17
	stp	q23, q20, [x25]
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	fsub.4s	v6, v6, v17
	fcvtzs.4s	v18, v6
	fcvtzs.4s	v23, v7
	scvtf.4s	v6, v23
	mov	w13, #29184                     ; =0x7200
	movk	w13, #16177, lsl #16
	dup.4s	v19, w13
	scvtf.4s	v7, v18
	fmul.4s	v16, v7, v19
	fmul.4s	v17, v6, v19
	fsub.4s	v0, v0, v17
	mov	w13, #48782                     ; =0xbe8e
	movk	w13, #13759, lsl #16
	dup.4s	v20, w13
	fsub.4s	v5, v5, v16
	fmul.4s	v6, v6, v20
	fmul.4s	v7, v7, v20
	fsub.4s	v24, v5, v7
	mov	w13, #11226                     ; =0x2bda
	movk	w13, #14672, lsl #16
	dup.4s	v5, w13
	fsub.4s	v0, v0, v6
	fmul.4s	v7, v0, v5
	mov	w13, #38601                     ; =0x96c9
	movk	w13, #15030, lsl #16
	dup.4s	v6, w13
	fadd.4s	v7, v7, v6
	fmul.4s	v16, v0, v7
	mov	w13, #34982                     ; =0x88a6
	movk	w13, #15368, lsl #16
	dup.4s	v7, w13
	fadd.4s	v16, v16, v7
	fmul.4s	v17, v0, v16
	mov	w13, #43642                     ; =0xaa7a
	movk	w13, #15658, lsl #16
	dup.4s	v16, w13
	fadd.4s	v17, v17, v16
	fmul.4s	v25, v0, v17
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15914, lsl #16
	dup.4s	v17, w13
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v0, v25
	movi.4s	v26, #63, lsl #24
	fadd.4s	v25, v25, v26
	movi.4s	v8, #63, lsl #24
	fmul.4s	v26, v0, v0
	fmul.4s	v25, v26, v25
	fmul.4s	v26, v24, v5
	fadd.4s	v26, v26, v6
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v8
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v0, v0, v25
	fmov.4s	v29, #1.00000000
	fadd.4s	v24, v24, v29
	sshr.4s	v25, v18, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v29
	fmul.4s	v24, v24, v26
	fadd.4s	v0, v0, v29
	sshr.4s	v26, v23, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v29
	fmul.4s	v0, v0, v27
	sub.4s	v18, v18, v25
	sub.4s	v23, v23, v26
	shl.4s	v23, v23, #23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v29
	add.4s	v23, v23, v29
	fmul.4s	v0, v0, v23
	fmul.4s	v18, v24, v18
	fcmgt.4s	v23, v2, v21
	bic.16b	v23, v18, v23
	fcmgt.4s	v18, v2, v22
	bic.16b	v0, v0, v18
	fcmgt.4s	v24, v22, v3
	mvni.4s	v18, #127, msl #16
	fneg.4s	v18, v18
	bit.16b	v0, v18, v24
	fcmgt.4s	v24, v21, v3
	bit.16b	v23, v18, v24
	str	q31, [sp, #9072]                ; 16-byte Spill
	ldr	q24, [sp, #5264]                ; 16-byte Reload
	fsub.4s	v24, v24, v31
	fcmeq.4s	v22, v22, v22
	fcmeq.4s	v21, v21, v21
	ldr	q31, [sp, #5520]                ; 16-byte Reload
	bsl.16b	v21, v23, v31
	str	q21, [sp, #9488]                ; 16-byte Spill
	bif.16b	v0, v31, v22
	str	q0, [sp, #9472]                 ; 16-byte Spill
	and.16b	v21, v13, v24
	fcmge.4s	v0, v21, v2
	fcmge.4s	v22, v3, v21
	and.16b	v0, v0, v22
	str	q9, [sp, #9104]                 ; 16-byte Spill
	ldr	q23, [sp, #5280]                ; 16-byte Reload
	fsub.4s	v22, v23, v9
	and.16b	v22, v1, v22
	fcmge.4s	v23, v22, v2
	fcmge.4s	v24, v3, v22
	and.16b	v23, v23, v24
	and.16b	v24, v23, v22
	fmul.4s	v23, v24, v4
	mvni.4s	v26, #128, lsl #24
	mov.16b	v25, v26
	bsl.16b	v25, v28, v23
	fadd.4s	v23, v23, v25
	fsub.4s	v23, v23, v25
	and.16b	v0, v0, v21
	fmul.4s	v25, v0, v4
	bsl.16b	v26, v28, v25
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v23, v23
	scvtf.4s	v26, v23
	fmul.4s	v27, v26, v19
	fsub.4s	v24, v24, v27
	fcvtzs.4s	v25, v25
	scvtf.4s	v27, v25
	fmul.4s	v28, v27, v19
	fsub.4s	v0, v0, v28
	fmul.4s	v27, v27, v20
	fsub.4s	v0, v0, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v26, v24, v5
	fadd.4s	v26, v26, v6
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v8
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fmul.4s	v27, v0, v5
	fadd.4s	v27, v27, v6
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v16
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v17
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v8
	fmul.4s	v28, v0, v0
	fmul.4s	v27, v28, v27
	fadd.4s	v0, v0, v27
	fadd.4s	v24, v24, v26
	fadd.4s	v0, v0, v29
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v29
	fmul.4s	v0, v0, v27
	fadd.4s	v24, v24, v29
	sshr.4s	v27, v23, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v29
	fmul.4s	v24, v24, v28
	sub.4s	v25, v25, v26
	sub.4s	v23, v23, v27
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v29
	fmul.4s	v23, v24, v23
	shl.4s	v24, v25, #23
	add.4s	v24, v24, v29
	fmul.4s	v0, v0, v24
	fcmgt.4s	v24, v2, v21
	bic.16b	v0, v0, v24
	fcmgt.4s	v24, v2, v22
	bic.16b	v23, v23, v24
	fcmgt.4s	v24, v22, v3
	bit.16b	v23, v18, v24
	fcmgt.4s	v24, v21, v3
	bit.16b	v0, v18, v24
	fcmeq.4s	v21, v21, v21
	bif.16b	v0, v31, v21
	str	q0, [sp, #9264]                 ; 16-byte Spill
	fcmeq.4s	v0, v22, v22
	bsl.16b	v0, v23, v31
	str	q0, [sp, #9248]                 ; 16-byte Spill
	ldr	q21, [sp, #5296]                ; 16-byte Reload
	ldr	q0, [sp, #9360]                 ; 16-byte Reload
	fsub.4s	v0, v21, v0
	and.16b	v21, v13, v0
	fcmge.4s	v0, v21, v2
	fcmge.4s	v22, v3, v21
	and.16b	v0, v0, v22
	ldr	q23, [sp, #5312]                ; 16-byte Reload
	ldr	q22, [sp, #9456]                ; 16-byte Reload
	fsub.4s	v22, v23, v22
	and.16b	v22, v1, v22
	fcmge.4s	v23, v22, v2
	fcmge.4s	v24, v3, v22
	and.16b	v23, v23, v24
	and.16b	v24, v23, v22
	fmul.4s	v23, v24, v4
	mvni.4s	v26, #128, lsl #24
	movi.4s	v27, #75, lsl #24
	mov.16b	v25, v26
	bsl.16b	v25, v27, v23
	fadd.4s	v23, v23, v25
	fsub.4s	v23, v23, v25
	and.16b	v0, v0, v21
	fmul.4s	v25, v0, v4
	bsl.16b	v26, v27, v25
	movi.4s	v9, #75, lsl #24
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v23, v23
	scvtf.4s	v26, v23
	fmul.4s	v27, v26, v19
	fsub.4s	v24, v24, v27
	fcvtzs.4s	v25, v25
	scvtf.4s	v27, v25
	fmul.4s	v28, v27, v19
	fsub.4s	v0, v0, v28
	fmul.4s	v27, v27, v20
	fsub.4s	v0, v0, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v26, v24, v5
	fadd.4s	v26, v26, v6
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	movi.4s	v28, #63, lsl #24
	fadd.4s	v26, v26, v28
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fmul.4s	v27, v0, v5
	fadd.4s	v27, v27, v6
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v16
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v17
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v28
	fmul.4s	v28, v0, v0
	fmul.4s	v27, v28, v27
	fadd.4s	v0, v0, v27
	fadd.4s	v24, v24, v26
	fadd.4s	v0, v0, v29
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v29
	fmul.4s	v0, v0, v27
	fadd.4s	v24, v24, v29
	sshr.4s	v27, v23, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v29
	fmul.4s	v24, v24, v28
	sub.4s	v25, v25, v26
	sub.4s	v23, v23, v27
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v29
	fmul.4s	v23, v24, v23
	shl.4s	v24, v25, #23
	add.4s	v24, v24, v29
	fmul.4s	v0, v0, v24
	fcmgt.4s	v24, v2, v21
	bic.16b	v0, v0, v24
	fcmgt.4s	v24, v2, v22
	bic.16b	v23, v23, v24
	fcmgt.4s	v24, v22, v3
	bit.16b	v23, v18, v24
	fcmgt.4s	v24, v21, v3
	bit.16b	v0, v18, v24
	fcmeq.4s	v21, v21, v21
	bif.16b	v0, v31, v21
	str	q0, [sp, #9232]                 ; 16-byte Spill
	fcmeq.4s	v0, v22, v22
	bsl.16b	v0, v23, v31
	str	q0, [sp, #9216]                 ; 16-byte Spill
	ldr	q21, [sp, #5328]                ; 16-byte Reload
	ldr	q0, [sp, #9344]                 ; 16-byte Reload
	fsub.4s	v0, v21, v0
	and.16b	v21, v13, v0
	fcmge.4s	v0, v21, v2
	fcmge.4s	v22, v3, v21
	and.16b	v0, v0, v22
	ldr	q23, [sp, #5344]                ; 16-byte Reload
	ldr	q22, [sp, #9440]                ; 16-byte Reload
	fsub.4s	v22, v23, v22
	and.16b	v22, v1, v22
	fcmge.4s	v23, v22, v2
	fcmge.4s	v24, v3, v22
	and.16b	v23, v23, v24
	and.16b	v24, v23, v22
	fmul.4s	v23, v24, v4
	mvni.4s	v26, #128, lsl #24
	mov.16b	v25, v26
	bsl.16b	v25, v9, v23
	fadd.4s	v23, v23, v25
	fsub.4s	v23, v23, v25
	and.16b	v0, v0, v21
	fmul.4s	v25, v0, v4
	bsl.16b	v26, v9, v25
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v23, v23
	scvtf.4s	v26, v23
	fmul.4s	v27, v26, v19
	fsub.4s	v24, v24, v27
	fcvtzs.4s	v25, v25
	scvtf.4s	v27, v25
	fmul.4s	v28, v27, v19
	fsub.4s	v0, v0, v28
	fmul.4s	v27, v27, v20
	fsub.4s	v0, v0, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v26, v24, v5
	fadd.4s	v26, v26, v6
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v8
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fmul.4s	v27, v0, v5
	fadd.4s	v27, v27, v6
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v16
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v17
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v8
	fmul.4s	v28, v0, v0
	fmul.4s	v27, v28, v27
	fadd.4s	v0, v0, v27
	fadd.4s	v24, v24, v26
	fadd.4s	v0, v0, v29
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v29
	fmul.4s	v0, v0, v27
	fadd.4s	v24, v24, v29
	sshr.4s	v27, v23, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v29
	fmul.4s	v24, v24, v28
	sub.4s	v25, v25, v26
	sub.4s	v23, v23, v27
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v29
	fmul.4s	v23, v24, v23
	shl.4s	v24, v25, #23
	add.4s	v24, v24, v29
	fmul.4s	v0, v0, v24
	fcmgt.4s	v24, v2, v21
	bic.16b	v0, v0, v24
	fcmgt.4s	v24, v2, v22
	bic.16b	v23, v23, v24
	fcmgt.4s	v24, v22, v3
	bit.16b	v23, v18, v24
	fcmgt.4s	v24, v21, v3
	bit.16b	v0, v18, v24
	fcmeq.4s	v21, v21, v21
	bif.16b	v0, v31, v21
	str	q0, [sp, #9200]                 ; 16-byte Spill
	fcmeq.4s	v0, v22, v22
	bsl.16b	v0, v23, v31
	str	q0, [sp, #9184]                 ; 16-byte Spill
	ldr	q21, [sp, #5360]                ; 16-byte Reload
	ldr	q0, [sp, #9328]                 ; 16-byte Reload
	fsub.4s	v0, v21, v0
	and.16b	v21, v13, v0
	fcmge.4s	v0, v21, v2
	fcmge.4s	v22, v3, v21
	and.16b	v0, v0, v22
	ldr	q23, [sp, #5376]                ; 16-byte Reload
	ldr	q22, [sp, #9424]                ; 16-byte Reload
	fsub.4s	v22, v23, v22
	and.16b	v22, v1, v22
	fcmge.4s	v23, v22, v2
	fcmge.4s	v24, v3, v22
	and.16b	v23, v23, v24
	and.16b	v24, v23, v22
	fmul.4s	v23, v24, v4
	mvni.4s	v26, #128, lsl #24
	movi.4s	v27, #75, lsl #24
	mov.16b	v25, v26
	bsl.16b	v25, v27, v23
	fadd.4s	v23, v23, v25
	fsub.4s	v23, v23, v25
	and.16b	v0, v0, v21
	fmul.4s	v25, v0, v4
	bsl.16b	v26, v27, v25
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v23, v23
	scvtf.4s	v26, v23
	fmul.4s	v27, v26, v19
	fsub.4s	v24, v24, v27
	fcvtzs.4s	v25, v25
	scvtf.4s	v27, v25
	fmul.4s	v28, v27, v19
	fsub.4s	v0, v0, v28
	fmul.4s	v27, v27, v20
	fsub.4s	v0, v0, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v26, v24, v5
	fadd.4s	v26, v26, v6
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	movi.4s	v28, #63, lsl #24
	fadd.4s	v26, v26, v28
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fmul.4s	v27, v0, v5
	fadd.4s	v27, v27, v6
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v16
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v17
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v28
	fmul.4s	v28, v0, v0
	fmul.4s	v27, v28, v27
	fadd.4s	v0, v0, v27
	fadd.4s	v24, v24, v26
	fadd.4s	v0, v0, v29
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v29
	fmul.4s	v0, v0, v27
	fadd.4s	v24, v24, v29
	sshr.4s	v27, v23, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v29
	fmul.4s	v24, v24, v28
	sub.4s	v25, v25, v26
	sub.4s	v23, v23, v27
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v29
	fmul.4s	v23, v24, v23
	shl.4s	v24, v25, #23
	add.4s	v24, v24, v29
	fmul.4s	v0, v0, v24
	fcmgt.4s	v24, v2, v21
	bic.16b	v0, v0, v24
	fcmgt.4s	v24, v2, v22
	bic.16b	v23, v23, v24
	fcmgt.4s	v24, v22, v3
	bit.16b	v23, v18, v24
	fcmgt.4s	v24, v21, v3
	bit.16b	v0, v18, v24
	fcmeq.4s	v21, v21, v21
	mov.16b	v8, v21
	bsl.16b	v8, v0, v31
	fcmeq.4s	v0, v22, v22
	bsl.16b	v0, v23, v31
	str	q0, [sp, #9168]                 ; 16-byte Spill
	ldr	q21, [sp, #5408]                ; 16-byte Reload
	ldr	q0, [sp, #9408]                 ; 16-byte Reload
	fsub.4s	v0, v21, v0
	and.16b	v21, v1, v0
	fcmge.4s	v0, v21, v2
	fcmge.4s	v22, v3, v21
	and.16b	v0, v0, v22
	ldr	q23, [sp, #5392]                ; 16-byte Reload
	ldr	q22, [sp, #9312]                ; 16-byte Reload
	fsub.4s	v22, v23, v22
	and.16b	v22, v13, v22
	fcmge.4s	v23, v22, v2
	fcmge.4s	v24, v3, v22
	and.16b	v23, v23, v24
	and.16b	v24, v23, v22
	fmul.4s	v23, v24, v4
	mvni.4s	v26, #128, lsl #24
	mov.16b	v25, v26
	bsl.16b	v25, v9, v23
	fadd.4s	v23, v23, v25
	fsub.4s	v23, v23, v25
	and.16b	v0, v0, v21
	fmul.4s	v25, v0, v4
	bsl.16b	v26, v9, v25
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v23, v23
	scvtf.4s	v26, v23
	fmul.4s	v27, v26, v19
	fsub.4s	v24, v24, v27
	fcvtzs.4s	v25, v25
	scvtf.4s	v27, v25
	fmul.4s	v28, v27, v19
	fsub.4s	v0, v0, v28
	fmul.4s	v27, v27, v20
	fsub.4s	v0, v0, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v26, v24, v5
	fadd.4s	v26, v26, v6
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	movi.4s	v28, #63, lsl #24
	fadd.4s	v26, v26, v28
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fmul.4s	v27, v0, v5
	fadd.4s	v27, v27, v6
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v16
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v17
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v28
	fmul.4s	v28, v0, v0
	fmul.4s	v27, v28, v27
	fadd.4s	v0, v0, v27
	fadd.4s	v24, v24, v26
	fadd.4s	v0, v0, v29
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v29
	fmul.4s	v0, v0, v27
	fadd.4s	v24, v24, v29
	sshr.4s	v27, v23, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v29
	fmul.4s	v24, v24, v28
	sub.4s	v25, v25, v26
	sub.4s	v23, v23, v27
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v29
	fmul.4s	v23, v24, v23
	shl.4s	v24, v25, #23
	add.4s	v24, v24, v29
	fmul.4s	v0, v0, v24
	fcmgt.4s	v24, v2, v21
	bic.16b	v0, v0, v24
	fcmgt.4s	v24, v2, v22
	bic.16b	v23, v23, v24
	fcmgt.4s	v24, v22, v3
	bit.16b	v23, v18, v24
	fcmgt.4s	v24, v21, v3
	bit.16b	v0, v18, v24
	fcmeq.4s	v21, v21, v21
	bif.16b	v0, v31, v21
	str	q0, [sp, #9152]                 ; 16-byte Spill
	fcmeq.4s	v0, v22, v22
	bsl.16b	v0, v23, v31
	str	q0, [sp, #9136]                 ; 16-byte Spill
	ldr	q21, [sp, #5424]                ; 16-byte Reload
	ldr	q0, [sp, #9296]                 ; 16-byte Reload
	fsub.4s	v0, v21, v0
	and.16b	v21, v13, v0
	fcmge.4s	v0, v21, v2
	fcmge.4s	v22, v3, v21
	and.16b	v0, v0, v22
	ldr	q23, [sp, #5456]                ; 16-byte Reload
	ldr	q22, [sp, #9392]                ; 16-byte Reload
	fsub.4s	v22, v23, v22
	and.16b	v22, v1, v22
	fcmge.4s	v23, v22, v2
	fcmge.4s	v24, v3, v22
	and.16b	v23, v23, v24
	and.16b	v24, v23, v22
	fmul.4s	v23, v24, v4
	mvni.4s	v26, #128, lsl #24
	movi.4s	v27, #75, lsl #24
	mov.16b	v25, v26
	bsl.16b	v25, v27, v23
	fadd.4s	v23, v23, v25
	fsub.4s	v23, v23, v25
	and.16b	v0, v0, v21
	fmul.4s	v25, v0, v4
	bsl.16b	v26, v27, v25
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v23, v23
	scvtf.4s	v26, v23
	fmul.4s	v27, v26, v19
	fsub.4s	v24, v24, v27
	fcvtzs.4s	v25, v25
	scvtf.4s	v27, v25
	fmul.4s	v28, v27, v19
	fsub.4s	v0, v0, v28
	fmul.4s	v27, v27, v20
	fsub.4s	v0, v0, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v26, v24, v5
	fadd.4s	v26, v26, v6
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	movi.4s	v28, #63, lsl #24
	fadd.4s	v26, v26, v28
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fmul.4s	v27, v0, v5
	fadd.4s	v27, v27, v6
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v16
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v17
	fmul.4s	v27, v0, v27
	fadd.4s	v27, v27, v28
	fmul.4s	v28, v0, v0
	fmul.4s	v27, v28, v27
	fadd.4s	v0, v0, v27
	fadd.4s	v24, v24, v26
	fadd.4s	v0, v0, v29
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v29
	fmul.4s	v0, v0, v27
	fadd.4s	v24, v24, v29
	sshr.4s	v27, v23, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v29
	fmul.4s	v24, v24, v28
	sub.4s	v25, v25, v26
	sub.4s	v23, v23, v27
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v29
	fmul.4s	v23, v24, v23
	shl.4s	v24, v25, #23
	add.4s	v24, v24, v29
	fmul.4s	v0, v0, v24
	fcmgt.4s	v24, v2, v21
	bic.16b	v0, v0, v24
	fcmgt.4s	v24, v2, v22
	bic.16b	v23, v23, v24
	fcmgt.4s	v24, v22, v3
	bit.16b	v23, v18, v24
	fcmgt.4s	v24, v21, v3
	bit.16b	v0, v18, v24
	fcmeq.4s	v21, v21, v21
	mov.16b	v9, v21
	bsl.16b	v9, v0, v31
	fcmeq.4s	v0, v22, v22
	mov.16b	v28, v0
	bsl.16b	v28, v23, v31
	ldr	q21, [sp, #5440]                ; 16-byte Reload
	ldr	q0, [sp, #9280]                 ; 16-byte Reload
	fsub.4s	v0, v21, v0
	and.16b	v21, v13, v0
	fcmge.4s	v0, v21, v2
	fcmge.4s	v22, v3, v21
	and.16b	v0, v0, v22
	ldr	q23, [sp, #5472]                ; 16-byte Reload
	ldr	q22, [sp, #9376]                ; 16-byte Reload
	fsub.4s	v22, v23, v22
	and.16b	v22, v1, v22
	fcmge.4s	v23, v22, v2
	fcmge.4s	v24, v3, v22
	and.16b	v23, v23, v24
	and.16b	v24, v23, v22
	fmul.4s	v23, v24, v4
	movi.4s	v26, #75, lsl #24
	mvni.4s	v27, #128, lsl #24
	mov.16b	v25, v27
	bsl.16b	v25, v26, v23
	fadd.4s	v23, v23, v25
	fsub.4s	v23, v23, v25
	and.16b	v0, v0, v21
	fmul.4s	v25, v0, v4
	bif.16b	v26, v25, v27
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v23, v23
	scvtf.4s	v26, v23
	fmul.4s	v27, v26, v19
	fsub.4s	v27, v24, v27
	fcvtzs.4s	v24, v25
	scvtf.4s	v25, v24
	fmul.4s	v19, v25, v19
	fsub.4s	v0, v0, v19
	fmul.4s	v19, v26, v20
	fmul.4s	v20, v25, v20
	fsub.4s	v0, v0, v20
	fsub.4s	v19, v27, v19
	fmul.4s	v20, v19, v5
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v19, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v19, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v19, v20
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v19, v20
	movi.4s	v26, #63, lsl #24
	fadd.4s	v20, v20, v26
	fmul.4s	v25, v19, v19
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v0, v5
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v0, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v0, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v0, v25
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v0, v25
	fadd.4s	v25, v25, v26
	fmul.4s	v26, v0, v0
	fmul.4s	v25, v26, v25
	fadd.4s	v0, v0, v25
	fadd.4s	v19, v19, v20
	ldr	x13, [sp, #2504]                ; 8-byte Reload
	ldr	q20, [x13, #16]
	ldr	q25, [sp, #9472]                ; 16-byte Reload
	bit.16b	v20, v25, v13
	ldr	q25, [x13]
	ldr	q26, [sp, #9488]                ; 16-byte Reload
	bit.16b	v25, v26, v1
	stp	q25, q20, [x13]
	fadd.4s	v0, v0, v29
	sshr.4s	v20, v24, #1
	shl.4s	v25, v20, #23
	add.4s	v25, v25, v29
	fmul.4s	v0, v0, v25
	ldr	x13, [sp, #2496]                ; 8-byte Reload
	ldr	q25, [x13]
	ldr	q26, [sp, #9248]                ; 16-byte Reload
	bit.16b	v25, v26, v1
	ldr	q26, [x13, #16]
	ldr	q27, [sp, #9264]                ; 16-byte Reload
	bit.16b	v26, v27, v13
	stp	q25, q26, [x13]
	ldr	x13, [sp, #2472]                ; 8-byte Reload
	ldr	q25, [x13]
	ldr	q26, [sp, #9216]                ; 16-byte Reload
	bit.16b	v25, v26, v1
	ldr	q26, [x13, #16]
	ldr	q27, [sp, #9232]                ; 16-byte Reload
	bit.16b	v26, v27, v13
	stp	q25, q26, [x13]
	fadd.4s	v19, v19, v29
	sshr.4s	v25, v23, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v29
	fmul.4s	v19, v19, v26
	sub.4s	v20, v24, v20
	sub.4s	v23, v23, v25
	ldr	x13, [sp, #2440]                ; 8-byte Reload
	ldr	q24, [x13]
	ldr	q25, [sp, #9184]                ; 16-byte Reload
	bit.16b	v24, v25, v1
	ldr	q25, [x13, #16]
	ldr	q26, [sp, #9200]                ; 16-byte Reload
	bit.16b	v25, v26, v13
	stp	q24, q25, [x13]
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v29
	fmul.4s	v19, v19, v23
	ldr	x13, [sp, #2432]                ; 8-byte Reload
	ldr	q23, [x13]
	ldr	q24, [sp, #9168]                ; 16-byte Reload
	bit.16b	v23, v24, v1
	ldr	q24, [x13, #16]
	str	q8, [sp, #9056]                 ; 16-byte Spill
	bit.16b	v24, v8, v13
	stp	q23, q24, [x13]
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v29
	fmul.4s	v0, v0, v20
	fcmgt.4s	v20, v2, v21
	bic.16b	v0, v0, v20
	ldr	x13, [sp, #2408]                ; 8-byte Reload
	ldr	q20, [x13, #16]
	ldr	q23, [sp, #9136]                ; 16-byte Reload
	bit.16b	v20, v23, v13
	ldr	q23, [x13]
	ldr	q24, [sp, #9152]                ; 16-byte Reload
	bit.16b	v23, v24, v1
	stp	q23, q20, [x13]
	fcmgt.4s	v20, v2, v22
	bic.16b	v19, v19, v20
	fcmgt.4s	v20, v22, v3
	bit.16b	v19, v18, v20
	ldr	x13, [sp, #2376]                ; 8-byte Reload
	ldp	q20, q23, [x13]
	str	q28, [sp, #9024]                ; 16-byte Spill
	bit.16b	v20, v28, v1
	str	q9, [sp, #9040]                 ; 16-byte Spill
	bit.16b	v23, v9, v13
	stp	q20, q23, [x13]
	fcmgt.4s	v20, v21, v3
	bit.16b	v0, v18, v20
	fcmeq.4s	v20, v21, v21
	bsl.16b	v20, v0, v31
	fcmeq.4s	v0, v22, v22
	bif.16b	v19, v31, v0
	ldr	x13, [sp, #2368]                ; 8-byte Reload
	ldr	q0, [x13]
	str	q19, [sp, #8992]                ; 16-byte Spill
	bit.16b	v0, v19, v1
	ldr	q19, [x13, #16]
	str	q20, [sp, #9008]                ; 16-byte Spill
	bit.16b	v19, v20, v13
	stp	q0, q19, [x13]
	mov	x13, #-128                      ; =0xffffffffffffff80
	mov	x0, x15
	ldr	x15, [sp, #3472]                ; 8-byte Reload
	ldr	q8, [sp, #5248]                 ; 16-byte Reload
	ldr	q9, [sp, #5232]                 ; 16-byte Reload
	b	LBB0_243
LBB0_242:                               ; %else969
                                        ;   in Loop: Header=BB0_243 Depth=2
	cmeq.8b	v0, v19, #0
	sshll.8h	v0, v0, #0
	sshll2.4s	v19, v0, #0
	sshll.4s	v20, v0, #0
	ldp	q21, q0, [x0]
	and	x4, x10, #0xe0
	add	x4, x15, x4
	ldp	q23, q22, [x4]
	fsub.4s	v23, v21, v23
	fsub.4s	v0, v0, v22
	and.16b	v21, v13, v0
	and.16b	v22, v1, v23
	fcmge.4s	v0, v22, v2
	fcmge.4s	v23, v21, v2
	fcmge.4s	v24, v3, v22
	fcmge.4s	v25, v3, v21
	and.16b	v23, v23, v25
	and.16b	v0, v0, v24
	and.16b	v0, v0, v22
	and.16b	v23, v23, v21
	fmul.4s	v24, v23, v4
	fmul.4s	v25, v0, v4
	movi.4s	v27, #75, lsl #24
	mvni.4s	v28, #128, lsl #24
	mov.16b	v26, v28
	bsl.16b	v26, v27, v25
	bif.16b	v27, v24, v28
	fadd.4s	v24, v24, v27
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fsub.4s	v24, v24, v27
	fcvtzs.4s	v24, v24
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	scvtf.4s	v27, v24
	dup.4s	v28, w5
	fmul.4s	v29, v27, v28
	fmul.4s	v28, v26, v28
	fadd.4s	v0, v0, v28
	fadd.4s	v23, v23, v29
	dup.4s	v28, w19
	fmul.4s	v26, v26, v28
	fmul.4s	v27, v27, v28
	fadd.4s	v23, v23, v27
	fadd.4s	v0, v0, v26
	fmul.4s	v26, v0, v5
	fmul.4s	v27, v23, v5
	fadd.4s	v27, v27, v6
	fadd.4s	v26, v26, v6
	fmul.4s	v26, v0, v26
	fmul.4s	v27, v23, v27
	fadd.4s	v27, v27, v7
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v0, v26
	fmul.4s	v27, v23, v27
	fadd.4s	v27, v27, v16
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v0, v26
	fmul.4s	v27, v23, v27
	fadd.4s	v27, v27, v17
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v0, v26
	fmul.4s	v27, v23, v27
	movi.4s	v28, #63, lsl #24
	fadd.4s	v27, v27, v28
	fadd.4s	v26, v26, v28
	fmul.4s	v28, v23, v23
	fmul.4s	v29, v0, v0
	fmul.4s	v26, v29, v26
	fmul.4s	v27, v28, v27
	fadd.4s	v23, v23, v27
	fadd.4s	v0, v0, v26
	fmov.4s	v31, #1.00000000
	fadd.4s	v0, v0, v31
	fadd.4s	v23, v23, v31
	sshr.4s	v26, v25, #1
	sshr.4s	v27, v24, #1
	shl.4s	v28, v27, #23
	shl.4s	v29, v26, #23
	add.4s	v29, v29, v31
	add.4s	v28, v28, v31
	fmul.4s	v23, v23, v28
	fmul.4s	v0, v0, v29
	sub.4s	v24, v24, v27
	sub.4s	v25, v25, v26
	shl.4s	v25, v25, #23
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v31
	add.4s	v25, v25, v31
	fmul.4s	v0, v0, v25
	fmul.4s	v23, v23, v24
	fcmgt.4s	v24, v2, v21
	bic.16b	v23, v23, v24
	fcmgt.4s	v24, v2, v22
	bic.16b	v0, v0, v24
	fcmgt.4s	v24, v21, v3
	fcmgt.4s	v25, v22, v3
	bit.16b	v0, v18, v25
	bit.16b	v23, v18, v24
	fcmeq.4s	v22, v22, v22
	fcmeq.4s	v21, v21, v21
	ldr	q24, [sp, #5520]                ; 16-byte Reload
	bsl.16b	v21, v23, v24
	bif.16b	v0, v24, v22
	bic.16b	v0, v0, v20
	bic.16b	v19, v21, v19
	ldr	q20, [x0, #4608]
	ldr	q21, [x0, #4624]
	bif.16b	v19, v21, v13
	bif.16b	v0, v20, v1
	add	x10, x10, #2
	str	q0, [x0, #4608]
	str	q19, [x0, #4624]
	add	x13, x13, #1
	add	x9, x9, #8
	add	x0, x0, #32
	cmp	x10, #256
	b.eq	LBB0_259
LBB0_243:                               ; %direct.true1420
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w4, s30
	add	x24, x13, #128
	and	x25, x9, #0x78
	orr	x24, x25, x24, lsr #4
	dup.2d	v20, x24
	ldr	q0, [sp, #5664]                 ; 16-byte Reload
	orr.16b	v0, v20, v0
	add.2d	v21, v11, v0
	tbz	w4, #0, LBB0_245
; %bb.244:                              ; %cond.load923
                                        ;   in Loop: Header=BB0_243 Depth=2
	fmov	x24, d21
	ldr	b19, [x24]
	and	w4, w4, #0xff
	tbnz	w4, #1, LBB0_246
	b	LBB0_247
LBB0_245:                               ;   in Loop: Header=BB0_243 Depth=2
	movi.2d	v19, #0000000000000000
	and	w4, w4, #0xff
	tbz	w4, #1, LBB0_247
LBB0_246:                               ; %cond.load929
                                        ;   in Loop: Header=BB0_243 Depth=2
	mov.d	x24, v21[1]
	ld1.b	{ v19 }[1], [x24]
LBB0_247:                               ; %else933
                                        ;   in Loop: Header=BB0_243 Depth=2
	orr.16b	v0, v20, v8
	add.2d	v21, v12, v0
	tbnz	w4, #2, LBB0_253
; %bb.248:                              ; %else939
                                        ;   in Loop: Header=BB0_243 Depth=2
	tbnz	w4, #3, LBB0_254
LBB0_249:                               ; %else945
                                        ;   in Loop: Header=BB0_243 Depth=2
	orr.16b	v0, v20, v9
	add.2d	v21, v14, v0
	tbnz	w4, #4, LBB0_255
LBB0_250:                               ; %else951
                                        ;   in Loop: Header=BB0_243 Depth=2
	tbnz	w4, #5, LBB0_256
LBB0_251:                               ; %else957
                                        ;   in Loop: Header=BB0_243 Depth=2
	orr.16b	v0, v20, v10
	add.2d	v20, v15, v0
	tbnz	w4, #6, LBB0_257
LBB0_252:                               ; %else963
                                        ;   in Loop: Header=BB0_243 Depth=2
	tbz	w4, #7, LBB0_242
	b	LBB0_258
LBB0_253:                               ; %cond.load935
                                        ;   in Loop: Header=BB0_243 Depth=2
	fmov	x24, d21
	ld1.b	{ v19 }[2], [x24]
	tbz	w4, #3, LBB0_249
LBB0_254:                               ; %cond.load941
                                        ;   in Loop: Header=BB0_243 Depth=2
	mov.d	x24, v21[1]
	ld1.b	{ v19 }[3], [x24]
	orr.16b	v0, v20, v9
	add.2d	v21, v14, v0
	tbz	w4, #4, LBB0_250
LBB0_255:                               ; %cond.load947
                                        ;   in Loop: Header=BB0_243 Depth=2
	fmov	x24, d21
	ld1.b	{ v19 }[4], [x24]
	tbz	w4, #5, LBB0_251
LBB0_256:                               ; %cond.load953
                                        ;   in Loop: Header=BB0_243 Depth=2
	mov.d	x24, v21[1]
	ld1.b	{ v19 }[5], [x24]
	orr.16b	v0, v20, v10
	add.2d	v20, v15, v0
	tbz	w4, #6, LBB0_252
LBB0_257:                               ; %cond.load959
                                        ;   in Loop: Header=BB0_243 Depth=2
	fmov	x24, d20
	ld1.b	{ v19 }[6], [x24]
	tbz	w4, #7, LBB0_242
LBB0_258:                               ; %cond.load965
                                        ;   in Loop: Header=BB0_243 Depth=2
	mov.d	x4, v20[1]
	ld1.b	{ v19 }[7], [x4]
	b	LBB0_242
LBB0_259:                               ; %direct.false1421
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q15, [sp, #4400]                ; 16-byte Spill
	str	q14, [sp, #4416]                ; 16-byte Spill
	str	q12, [sp, #4432]                ; 16-byte Spill
	str	q11, [sp, #4448]                ; 16-byte Spill
	str	q10, [sp, #4528]                ; 16-byte Spill
	ldr	x13, [sp, #2344]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8976]                 ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	str	q0, [sp, #8960]                 ; 16-byte Spill
	ldr	x13, [sp, #2312]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8624]                 ; 16-byte Spill
	str	q0, [sp, #8832]                 ; 16-byte Spill
	ldr	x13, [sp, #2304]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8944]                 ; 16-byte Spill
	str	q0, [sp, #8608]                 ; 16-byte Spill
	ldr	x13, [sp, #2280]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8800]                 ; 16-byte Spill
	str	q0, [sp, #8816]                 ; 16-byte Spill
	ldr	x13, [sp, #2248]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8928]                 ; 16-byte Spill
	str	q0, [sp, #8592]                 ; 16-byte Spill
	ldr	x13, [sp, #2240]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8768]                 ; 16-byte Spill
	str	q0, [sp, #8784]                 ; 16-byte Spill
	ldr	x13, [sp, #2216]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8912]                 ; 16-byte Spill
	str	q0, [sp, #8576]                 ; 16-byte Spill
	ldr	x13, [sp, #2184]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8736]                 ; 16-byte Spill
	str	q0, [sp, #8752]                 ; 16-byte Spill
	ldr	x13, [sp, #2176]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8896]                 ; 16-byte Spill
	str	q0, [sp, #8560]                 ; 16-byte Spill
	ldr	x13, [sp, #2152]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8704]                 ; 16-byte Spill
	str	q0, [sp, #8720]                 ; 16-byte Spill
	ldr	x13, [sp, #2120]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8880]                 ; 16-byte Spill
	str	q0, [sp, #8544]                 ; 16-byte Spill
	ldr	x13, [sp, #2112]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8672]                 ; 16-byte Spill
	str	q0, [sp, #8688]                 ; 16-byte Spill
	ldr	x13, [sp, #2088]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8864]                 ; 16-byte Spill
	str	q0, [sp, #8528]                 ; 16-byte Spill
	ldr	x13, [sp, #2056]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8640]                 ; 16-byte Spill
	str	q0, [sp, #8656]                 ; 16-byte Spill
	ldr	x13, [sp, #2048]                ; 8-byte Reload
	ldp	q0, q2, [x13]
	str	q2, [sp, #8848]                 ; 16-byte Spill
	str	q0, [sp, #8512]                 ; 16-byte Spill
	add	x13, x11, #21, lsl #12          ; =86016
	ldp	q0, q2, [x13]
	str	q2, [sp, #8464]                 ; 16-byte Spill
	str	q0, [sp, #8448]                 ; 16-byte Spill
	ldr	x13, [sp, #2840]                ; 8-byte Reload
	ldr	x0, [sp, #2848]                 ; 8-byte Reload
	ldr	x15, [sp, #2024]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8480]                 ; 16-byte Spill
	str	q0, [sp, #8496]                 ; 16-byte Spill
	ldr	x15, [sp, #1992]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8240]                 ; 16-byte Spill
	str	q0, [sp, #8352]                 ; 16-byte Spill
	ldr	x15, [sp, #1984]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8048]                 ; 16-byte Spill
	str	q0, [sp, #8224]                 ; 16-byte Spill
	ldr	x15, [sp, #1960]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8336]                 ; 16-byte Spill
	str	q0, [sp, #8032]                 ; 16-byte Spill
	ldr	x15, [sp, #1928]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8192]                 ; 16-byte Spill
	str	q0, [sp, #8208]                 ; 16-byte Spill
	ldr	x15, [sp, #1920]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8320]                 ; 16-byte Spill
	str	q0, [sp, #8016]                 ; 16-byte Spill
	ldr	x15, [sp, #1896]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8160]                 ; 16-byte Spill
	str	q0, [sp, #8176]                 ; 16-byte Spill
	ldr	x15, [sp, #1864]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8304]                 ; 16-byte Spill
	str	q0, [sp, #8000]                 ; 16-byte Spill
	ldr	x15, [sp, #1856]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8128]                 ; 16-byte Spill
	str	q0, [sp, #8144]                 ; 16-byte Spill
	ldr	x15, [sp, #1832]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8288]                 ; 16-byte Spill
	str	q0, [sp, #7984]                 ; 16-byte Spill
	ldr	x15, [sp, #1800]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8096]                 ; 16-byte Spill
	str	q0, [sp, #8112]                 ; 16-byte Spill
	ldr	x15, [sp, #1792]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8272]                 ; 16-byte Spill
	str	q0, [sp, #7968]                 ; 16-byte Spill
	ldr	x15, [sp, #1768]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8064]                 ; 16-byte Spill
	str	q0, [sp, #8080]                 ; 16-byte Spill
	ldr	x15, [sp, #1736]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8400]                 ; 16-byte Spill
	str	q0, [sp, #8416]                 ; 16-byte Spill
	ldr	x15, [sp, #1728]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8432]                 ; 16-byte Spill
	str	q0, [sp, #8256]                 ; 16-byte Spill
	ldr	x15, [sp, #1704]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #8368]                 ; 16-byte Spill
	str	q0, [sp, #8384]                 ; 16-byte Spill
	ldr	x15, [sp, #1672]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7824]                 ; 16-byte Spill
	str	q0, [sp, #7952]                 ; 16-byte Spill
	ldr	x15, [sp, #1664]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7568]                 ; 16-byte Spill
	str	q0, [sp, #7808]                 ; 16-byte Spill
	ldr	x15, [sp, #1640]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7936]                 ; 16-byte Spill
	str	q0, [sp, #7552]                 ; 16-byte Spill
	ldr	x15, [sp, #1608]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7776]                 ; 16-byte Spill
	str	q0, [sp, #7792]                 ; 16-byte Spill
	ldr	x15, [sp, #1600]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7920]                 ; 16-byte Spill
	str	q0, [sp, #7536]                 ; 16-byte Spill
	ldr	x15, [sp, #1576]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7744]                 ; 16-byte Spill
	str	q0, [sp, #7760]                 ; 16-byte Spill
	ldr	x15, [sp, #1544]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7904]                 ; 16-byte Spill
	str	q0, [sp, #7520]                 ; 16-byte Spill
	ldr	x15, [sp, #1536]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7712]                 ; 16-byte Spill
	str	q0, [sp, #7728]                 ; 16-byte Spill
	ldr	x15, [sp, #1512]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7888]                 ; 16-byte Spill
	str	q0, [sp, #7504]                 ; 16-byte Spill
	ldr	x15, [sp, #1480]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7680]                 ; 16-byte Spill
	str	q0, [sp, #7696]                 ; 16-byte Spill
	ldr	x15, [sp, #1472]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7872]                 ; 16-byte Spill
	str	q0, [sp, #7488]                 ; 16-byte Spill
	ldr	x15, [sp, #1448]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7648]                 ; 16-byte Spill
	str	q0, [sp, #7664]                 ; 16-byte Spill
	ldr	x15, [sp, #1416]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7856]                 ; 16-byte Spill
	str	q0, [sp, #7472]                 ; 16-byte Spill
	ldr	x15, [sp, #1408]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7616]                 ; 16-byte Spill
	str	q0, [sp, #7632]                 ; 16-byte Spill
	ldr	x15, [sp, #1384]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7840]                 ; 16-byte Spill
	str	q0, [sp, #7456]                 ; 16-byte Spill
	ldr	x15, [sp, #1352]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7584]                 ; 16-byte Spill
	str	q0, [sp, #7600]                 ; 16-byte Spill
	ldr	x15, [sp, #1344]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7312]                 ; 16-byte Spill
	str	q0, [sp, #7440]                 ; 16-byte Spill
	ldr	x15, [sp, #1320]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7056]                 ; 16-byte Spill
	str	q0, [sp, #7296]                 ; 16-byte Spill
	ldr	x15, [sp, #1288]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7424]                 ; 16-byte Spill
	str	q0, [sp, #7040]                 ; 16-byte Spill
	ldr	x15, [sp, #1280]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7264]                 ; 16-byte Spill
	str	q0, [sp, #7280]                 ; 16-byte Spill
	ldr	x15, [sp, #1256]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7408]                 ; 16-byte Spill
	str	q0, [sp, #7024]                 ; 16-byte Spill
	ldr	x15, [sp, #1224]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7232]                 ; 16-byte Spill
	str	q0, [sp, #7248]                 ; 16-byte Spill
	ldr	x15, [sp, #1216]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7392]                 ; 16-byte Spill
	str	q0, [sp, #7008]                 ; 16-byte Spill
	ldr	x15, [sp, #1192]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7200]                 ; 16-byte Spill
	str	q0, [sp, #7216]                 ; 16-byte Spill
	ldr	x15, [sp, #1160]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7376]                 ; 16-byte Spill
	str	q0, [sp, #6992]                 ; 16-byte Spill
	ldr	x15, [sp, #1152]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7168]                 ; 16-byte Spill
	str	q0, [sp, #7184]                 ; 16-byte Spill
	ldr	x15, [sp, #1128]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7360]                 ; 16-byte Spill
	str	q0, [sp, #6976]                 ; 16-byte Spill
	ldr	x15, [sp, #1096]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7136]                 ; 16-byte Spill
	str	q0, [sp, #7152]                 ; 16-byte Spill
	ldr	x15, [sp, #1088]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7344]                 ; 16-byte Spill
	str	q0, [sp, #6960]                 ; 16-byte Spill
	ldr	x15, [sp, #1080]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7104]                 ; 16-byte Spill
	str	q0, [sp, #7120]                 ; 16-byte Spill
	ldr	x15, [sp, #1072]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7328]                 ; 16-byte Spill
	str	q0, [sp, #6944]                 ; 16-byte Spill
	ldr	x15, [sp, #1064]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #7072]                 ; 16-byte Spill
	str	q0, [sp, #7088]                 ; 16-byte Spill
	ldr	x15, [sp, #1056]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6800]                 ; 16-byte Spill
	str	q0, [sp, #6928]                 ; 16-byte Spill
	ldr	x15, [sp, #1048]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6544]                 ; 16-byte Spill
	str	q0, [sp, #6784]                 ; 16-byte Spill
	ldr	x15, [sp, #1040]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6912]                 ; 16-byte Spill
	str	q0, [sp, #6528]                 ; 16-byte Spill
	ldr	x15, [sp, #1032]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6752]                 ; 16-byte Spill
	str	q0, [sp, #6768]                 ; 16-byte Spill
	ldr	x15, [sp, #1024]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6896]                 ; 16-byte Spill
	str	q0, [sp, #6512]                 ; 16-byte Spill
	ldr	x15, [sp, #1016]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6720]                 ; 16-byte Spill
	str	q0, [sp, #6736]                 ; 16-byte Spill
	ldr	x15, [sp, #1008]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6880]                 ; 16-byte Spill
	str	q0, [sp, #6496]                 ; 16-byte Spill
	ldr	x15, [sp, #1000]                ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6688]                 ; 16-byte Spill
	str	q0, [sp, #6704]                 ; 16-byte Spill
	ldr	x15, [sp, #992]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6864]                 ; 16-byte Spill
	str	q0, [sp, #6480]                 ; 16-byte Spill
	ldr	x15, [sp, #984]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6656]                 ; 16-byte Spill
	str	q0, [sp, #6672]                 ; 16-byte Spill
	ldr	x15, [sp, #976]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6848]                 ; 16-byte Spill
	str	q0, [sp, #6464]                 ; 16-byte Spill
	ldr	x15, [sp, #968]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6624]                 ; 16-byte Spill
	str	q0, [sp, #6640]                 ; 16-byte Spill
	ldr	x15, [sp, #960]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6832]                 ; 16-byte Spill
	str	q0, [sp, #6448]                 ; 16-byte Spill
	ldr	x15, [sp, #952]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6592]                 ; 16-byte Spill
	str	q0, [sp, #6608]                 ; 16-byte Spill
	ldr	x15, [sp, #944]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6816]                 ; 16-byte Spill
	str	q0, [sp, #6432]                 ; 16-byte Spill
	ldr	x15, [sp, #936]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6560]                 ; 16-byte Spill
	str	q0, [sp, #6576]                 ; 16-byte Spill
	ldr	x15, [sp, #928]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6288]                 ; 16-byte Spill
	str	q0, [sp, #6416]                 ; 16-byte Spill
	ldr	x15, [sp, #920]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6032]                 ; 16-byte Spill
	str	q0, [sp, #6272]                 ; 16-byte Spill
	ldr	x15, [sp, #912]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6400]                 ; 16-byte Spill
	str	q0, [sp, #6016]                 ; 16-byte Spill
	ldr	x15, [sp, #904]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6240]                 ; 16-byte Spill
	str	q0, [sp, #6256]                 ; 16-byte Spill
	ldr	x15, [sp, #896]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6384]                 ; 16-byte Spill
	str	q0, [sp, #6000]                 ; 16-byte Spill
	ldr	x15, [sp, #888]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6208]                 ; 16-byte Spill
	str	q0, [sp, #6224]                 ; 16-byte Spill
	ldr	x15, [sp, #880]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6368]                 ; 16-byte Spill
	str	q0, [sp, #5984]                 ; 16-byte Spill
	ldr	x15, [sp, #872]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6176]                 ; 16-byte Spill
	str	q0, [sp, #6192]                 ; 16-byte Spill
	ldr	x15, [sp, #864]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6352]                 ; 16-byte Spill
	str	q0, [sp, #5968]                 ; 16-byte Spill
	ldr	x15, [sp, #856]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6144]                 ; 16-byte Spill
	str	q0, [sp, #6160]                 ; 16-byte Spill
	ldr	x15, [sp, #848]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6336]                 ; 16-byte Spill
	str	q0, [sp, #5952]                 ; 16-byte Spill
	ldr	x15, [sp, #840]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6112]                 ; 16-byte Spill
	str	q0, [sp, #6128]                 ; 16-byte Spill
	ldr	x15, [sp, #832]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6320]                 ; 16-byte Spill
	str	q0, [sp, #5936]                 ; 16-byte Spill
	ldr	x15, [sp, #824]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6080]                 ; 16-byte Spill
	str	q0, [sp, #6096]                 ; 16-byte Spill
	ldr	x15, [sp, #816]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6304]                 ; 16-byte Spill
	str	q0, [sp, #5920]                 ; 16-byte Spill
	ldr	x15, [sp, #808]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #6048]                 ; 16-byte Spill
	str	q0, [sp, #6064]                 ; 16-byte Spill
	ldr	x15, [sp, #800]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #5776]                 ; 16-byte Spill
	str	q0, [sp, #5904]                 ; 16-byte Spill
	ldr	x15, [sp, #792]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #3952]                 ; 16-byte Spill
	str	q0, [sp, #5760]                 ; 16-byte Spill
	ldr	x15, [sp, #784]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #5888]                 ; 16-byte Spill
	str	q0, [sp, #3936]                 ; 16-byte Spill
	ldr	x15, [sp, #776]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #5728]                 ; 16-byte Spill
	str	q0, [sp, #5744]                 ; 16-byte Spill
	ldr	x15, [sp, #768]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #5872]                 ; 16-byte Spill
	str	q0, [sp, #3920]                 ; 16-byte Spill
	ldr	x15, [sp, #760]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #5696]                 ; 16-byte Spill
	str	q0, [sp, #5712]                 ; 16-byte Spill
	ldr	x15, [sp, #752]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #5856]                 ; 16-byte Spill
	str	q0, [sp, #3904]                 ; 16-byte Spill
	ldr	x15, [sp, #744]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #4096]                 ; 16-byte Spill
	str	q0, [sp, #5648]                 ; 16-byte Spill
	ldr	x15, [sp, #736]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #5840]                 ; 16-byte Spill
	str	q0, [sp, #3888]                 ; 16-byte Spill
	ldr	x15, [sp, #728]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #4064]                 ; 16-byte Spill
	str	q0, [sp, #4080]                 ; 16-byte Spill
	ldr	x15, [sp, #720]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #5824]                 ; 16-byte Spill
	str	q0, [sp, #3872]                 ; 16-byte Spill
	ldr	x15, [sp, #712]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #4032]                 ; 16-byte Spill
	str	q0, [sp, #4048]                 ; 16-byte Spill
	ldr	x15, [sp, #704]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #5808]                 ; 16-byte Spill
	str	q0, [sp, #3856]                 ; 16-byte Spill
	ldr	x15, [sp, #696]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #4000]                 ; 16-byte Spill
	str	q0, [sp, #4016]                 ; 16-byte Spill
	ldr	x15, [sp, #688]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #5792]                 ; 16-byte Spill
	str	q0, [sp, #3840]                 ; 16-byte Spill
	ldr	x15, [sp, #680]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #3968]                 ; 16-byte Spill
	str	q0, [sp, #3984]                 ; 16-byte Spill
	ldr	x15, [sp, #672]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #3696]                 ; 16-byte Spill
	str	q0, [sp, #3824]                 ; 16-byte Spill
	ldr	x15, [sp, #664]                 ; 8-byte Reload
	ldp	q0, q6, [x15]
	str	q0, [sp, #3680]                 ; 16-byte Spill
	ldr	x15, [sp, #656]                 ; 8-byte Reload
	ldp	q7, q0, [x15]
	str	q0, [sp, #3808]                 ; 16-byte Spill
	ldr	x15, [sp, #648]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #3648]                 ; 16-byte Spill
	str	q0, [sp, #3664]                 ; 16-byte Spill
	ldr	x15, [sp, #640]                 ; 8-byte Reload
	ldp	q16, q0, [x15]
	str	q0, [sp, #3792]                 ; 16-byte Spill
	ldr	x15, [sp, #632]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #3616]                 ; 16-byte Spill
	str	q0, [sp, #3632]                 ; 16-byte Spill
	ldr	x15, [sp, #624]                 ; 8-byte Reload
	ldp	q17, q0, [x15]
	str	q0, [sp, #3776]                 ; 16-byte Spill
	ldr	x15, [sp, #616]                 ; 8-byte Reload
	ldp	q0, q31, [x15]
	str	q0, [sp, #3600]                 ; 16-byte Spill
	ldr	x15, [sp, #592]                 ; 8-byte Reload
	ldp	q0, q2, [x15]
	str	q2, [sp, #3760]                 ; 16-byte Spill
	ldr	x15, [sp, #584]                 ; 8-byte Reload
	ldp	q8, q9, [x15]
	ldr	x15, [sp, #576]                 ; 8-byte Reload
	ldp	q15, q2, [x15]
	str	q2, [sp, #3744]                 ; 16-byte Spill
	ldr	x15, [sp, #568]                 ; 8-byte Reload
	ldp	q10, q11, [x15]
	ldr	x15, [sp, #560]                 ; 8-byte Reload
	ldp	q4, q2, [x15]
	str	q2, [sp, #3728]                 ; 16-byte Spill
	ldr	x15, [sp, #552]                 ; 8-byte Reload
	ldp	q12, q14, [x15]
	ldr	x15, [sp, #544]                 ; 8-byte Reload
	ldp	q5, q2, [x15]
	str	q2, [sp, #3712]                 ; 16-byte Spill
	ldr	x15, [sp, #536]                 ; 8-byte Reload
	ldp	q2, q3, [x15]
	str	q3, [sp, #3568]                 ; 16-byte Spill
	str	q2, [sp, #3584]                 ; 16-byte Spill
LBB0_260:                               ; %direct.schedule.84.preheader
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_261 Depth 3
	mov	x4, #0                          ; =0x0
	mov	x24, x13
	mov	x25, x0
	mov	x26, x9
LBB0_261:                               ; %direct.true1569
                                        ;   Parent Loop BB0_22 Depth=1
                                        ;     Parent Loop BB0_260 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x27, x9, x4
	umulh	x28, x27, x14
	lsr	x28, x28, #5
	add	x30, x28, x28, lsl #1
	lsl	x30, x30, #4
	add	x2, x11, #12, lsl #12           ; =49152
	sub	x5, x27, x30
	add	x15, x8, x27, lsl #5
	add	x16, x1, x28, lsl #5
	ldp	q21, q18, [x16]
	ldp	q20, q19, [x15]
	fmul.4s	v20, v20, v21
	fmul.4s	v19, v19, v18
	and.16b	v19, v13, v19
	umulh	x15, x26, x14
	and.16b	v20, v1, v20
	lsr	x15, x15, #5
	madd	x16, x15, x7, x27
	add	x16, x16, x30
	add	x16, x8, x16, lsl #5
	ldp	q22, q23, [x16, #32]
	fmul.4s	v23, v18, v23
	fmul.4s	v22, v21, v22
	ldp	q2, q3, [x16, #64]
	fmul.4s	v3, v18, v3
	and.16b	v22, v1, v22
	fmul.4s	v2, v21, v2
	ldp	q24, q25, [x16, #96]
	fmul.4s	v18, v18, v25
	fmul.4s	v21, v21, v24
	and.16b	v23, v13, v23
	add	x28, x3, x28, lsl #9
	ldp	q25, q24, [x28]
	and.16b	v25, v1, v25
	and.16b	v24, v13, v24
	and.16b	v2, v1, v2
	add	x30, x2, x5, lsl #5
	add	x16, x11, #12, lsl #12          ; =49152
	ldp	q27, q26, [x30]
	and.16b	v27, v1, v27
	and.16b	v26, v13, v26
	and.16b	v3, v13, v3
	fmul.4s	v26, v24, v26
	fmul.4s	v27, v25, v27
	fadd.4s	v20, v20, v27
	fadd.4s	v19, v19, v26
	madd	x27, x15, x6, x24
	and.16b	v21, v1, v21
	ldp	q26, q27, [x27]
	and.16b	v27, v13, v27
	and.16b	v26, v1, v26
	fmul.4s	v26, v25, v26
	and.16b	v18, v13, v18
	fmul.4s	v27, v24, v27
	ldp	q28, q29, [x27, #32]
	and.16b	v29, v13, v29
	and.16b	v28, v1, v28
	fadd.4s	v23, v23, v27
	fmul.4s	v27, v25, v28
	fmul.4s	v28, v24, v29
	ldp	q29, q30, [x27, #64]
	and.16b	v30, v13, v30
	fadd.4s	v22, v22, v26
	and.16b	v26, v1, v29
	fmul.4s	v25, v25, v26
	fmul.4s	v24, v24, v30
	ldp	q26, q29, [x28, #32]
	fadd.4s	v3, v3, v28
	and.16b	v28, v13, v29
	and.16b	v26, v1, v26
	ldr	q29, [x30, #1536]
	ldr	q30, [x30, #1552]
	and.16b	v30, v13, v30
	fadd.4s	v2, v2, v27
	and.16b	v27, v1, v29
	fmul.4s	v27, v26, v27
	fmul.4s	v29, v28, v30
	fadd.4s	v19, v19, v29
	fadd.4s	v20, v20, v27
	fadd.4s	v18, v18, v24
	ldr	q24, [x27, #1552]
	ldr	q27, [x27, #1536]
	and.16b	v27, v1, v27
	and.16b	v24, v13, v24
	fmul.4s	v24, v28, v24
	fadd.4s	v21, v21, v25
	fmul.4s	v25, v26, v27
	ldr	q27, [x27, #1584]
	ldr	q29, [x27, #1568]
	and.16b	v29, v1, v29
	and.16b	v27, v13, v27
	fadd.4s	v22, v22, v25
	fmul.4s	v25, v28, v27
	fmul.4s	v27, v26, v29
	ldr	q29, [x27, #1616]
	ldr	q30, [x27, #1600]
	and.16b	v30, v1, v30
	fadd.4s	v23, v23, v24
	and.16b	v24, v13, v29
	fmul.4s	v24, v28, v24
	fmul.4s	v26, v26, v30
	ldp	q29, q28, [x28, #64]
	fadd.4s	v2, v2, v27
	and.16b	v27, v1, v29
	and.16b	v28, v13, v28
	ldr	q29, [x30, #3088]
	ldr	q30, [x30, #3072]
	and.16b	v30, v1, v30
	fadd.4s	v3, v3, v25
	and.16b	v25, v13, v29
	fmul.4s	v25, v28, v25
	fmul.4s	v29, v27, v30
	fadd.4s	v20, v20, v29
	fadd.4s	v19, v19, v25
	fadd.4s	v21, v21, v26
	ldr	q25, [x27, #3072]
	ldr	q26, [x27, #3088]
	and.16b	v26, v13, v26
	and.16b	v25, v1, v25
	fmul.4s	v25, v27, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v24, v28, v26
	ldr	q26, [x27, #3104]
	ldr	q29, [x27, #3120]
	and.16b	v29, v13, v29
	and.16b	v26, v1, v26
	fadd.4s	v23, v23, v24
	fmul.4s	v24, v27, v26
	fmul.4s	v26, v28, v29
	ldr	q29, [x27, #3136]
	ldr	q30, [x27, #3152]
	and.16b	v30, v13, v30
	fadd.4s	v22, v22, v25
	and.16b	v25, v1, v29
	fmul.4s	v25, v27, v25
	fmul.4s	v27, v28, v30
	ldp	q28, q29, [x28, #96]
	fadd.4s	v3, v3, v26
	and.16b	v26, v13, v29
	and.16b	v28, v1, v28
	ldr	q29, [x30, #4608]
	ldr	q30, [x30, #4624]
	and.16b	v30, v13, v30
	fadd.4s	v2, v2, v24
	and.16b	v24, v1, v29
	fmul.4s	v24, v28, v24
	fmul.4s	v29, v26, v30
	fadd.4s	v19, v19, v29
	fadd.4s	v20, v20, v24
	fadd.4s	v18, v18, v27
	ldr	q24, [x27, #4624]
	ldr	q27, [x27, #4608]
	and.16b	v27, v1, v27
	and.16b	v24, v13, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v21, v21, v25
	fmul.4s	v25, v28, v27
	ldr	q27, [x27, #4656]
	ldr	q29, [x27, #4640]
	and.16b	v29, v1, v29
	and.16b	v27, v13, v27
	fadd.4s	v22, v22, v25
	fmul.4s	v25, v26, v27
	fmul.4s	v27, v28, v29
	ldr	q29, [x27, #4688]
	ldr	q30, [x27, #4672]
	and.16b	v30, v1, v30
	fadd.4s	v23, v23, v24
	and.16b	v24, v13, v29
	fmul.4s	v24, v26, v24
	fmul.4s	v26, v28, v30
	ldp	q29, q28, [x28, #128]
	fadd.4s	v2, v2, v27
	and.16b	v27, v1, v29
	and.16b	v28, v13, v28
	ldr	q29, [x30, #6160]
	ldr	q30, [x30, #6144]
	and.16b	v30, v1, v30
	fadd.4s	v3, v3, v25
	and.16b	v25, v13, v29
	fmul.4s	v25, v28, v25
	fmul.4s	v29, v27, v30
	fadd.4s	v20, v20, v29
	fadd.4s	v19, v19, v25
	fadd.4s	v21, v21, v26
	ldr	q25, [x27, #6144]
	ldr	q26, [x27, #6160]
	and.16b	v26, v13, v26
	and.16b	v25, v1, v25
	fmul.4s	v25, v27, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v24, v28, v26
	ldr	q26, [x27, #6176]
	ldr	q29, [x27, #6192]
	and.16b	v29, v13, v29
	and.16b	v26, v1, v26
	fadd.4s	v23, v23, v24
	fmul.4s	v24, v27, v26
	fmul.4s	v26, v28, v29
	ldr	q29, [x27, #6208]
	ldr	q30, [x27, #6224]
	and.16b	v30, v13, v30
	fadd.4s	v22, v22, v25
	and.16b	v25, v1, v29
	fmul.4s	v25, v27, v25
	fmul.4s	v27, v28, v30
	ldp	q28, q29, [x28, #160]
	fadd.4s	v3, v3, v26
	and.16b	v26, v13, v29
	and.16b	v28, v1, v28
	ldr	q29, [x30, #7680]
	ldr	q30, [x30, #7696]
	and.16b	v30, v13, v30
	fadd.4s	v2, v2, v24
	and.16b	v24, v1, v29
	fmul.4s	v24, v28, v24
	fmul.4s	v29, v26, v30
	fadd.4s	v19, v19, v29
	fadd.4s	v20, v20, v24
	fadd.4s	v18, v18, v27
	ldr	q24, [x27, #7696]
	ldr	q27, [x27, #7680]
	and.16b	v27, v1, v27
	and.16b	v24, v13, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v21, v21, v25
	fmul.4s	v25, v28, v27
	ldr	q27, [x27, #7728]
	ldr	q29, [x27, #7712]
	and.16b	v29, v1, v29
	and.16b	v27, v13, v27
	fadd.4s	v22, v22, v25
	fmul.4s	v25, v26, v27
	fmul.4s	v27, v28, v29
	ldr	q29, [x27, #7760]
	ldr	q30, [x27, #7744]
	and.16b	v30, v1, v30
	fadd.4s	v23, v23, v24
	and.16b	v24, v13, v29
	fmul.4s	v24, v26, v24
	fmul.4s	v26, v28, v30
	ldp	q29, q28, [x28, #192]
	fadd.4s	v2, v2, v27
	and.16b	v27, v1, v29
	and.16b	v28, v13, v28
	ldr	q29, [x30, #9232]
	ldr	q30, [x30, #9216]
	and.16b	v30, v1, v30
	fadd.4s	v3, v3, v25
	and.16b	v25, v13, v29
	fmul.4s	v25, v28, v25
	fmul.4s	v29, v27, v30
	fadd.4s	v20, v20, v29
	fadd.4s	v19, v19, v25
	fadd.4s	v21, v21, v26
	ldr	q25, [x27, #9216]
	ldr	q26, [x27, #9232]
	and.16b	v26, v13, v26
	and.16b	v25, v1, v25
	fmul.4s	v25, v27, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v24, v28, v26
	ldr	q26, [x27, #9248]
	ldr	q29, [x27, #9264]
	and.16b	v29, v13, v29
	and.16b	v26, v1, v26
	fadd.4s	v23, v23, v24
	fmul.4s	v24, v27, v26
	fmul.4s	v26, v28, v29
	ldr	q29, [x27, #9280]
	ldr	q30, [x27, #9296]
	and.16b	v30, v13, v30
	fadd.4s	v22, v22, v25
	and.16b	v25, v1, v29
	fmul.4s	v25, v27, v25
	fmul.4s	v27, v28, v30
	ldp	q28, q29, [x28, #224]
	fadd.4s	v3, v3, v26
	and.16b	v26, v13, v29
	and.16b	v28, v1, v28
	ldr	q29, [x30, #10752]
	ldr	q30, [x30, #10768]
	and.16b	v30, v13, v30
	fadd.4s	v2, v2, v24
	and.16b	v24, v1, v29
	fmul.4s	v24, v28, v24
	fmul.4s	v29, v26, v30
	fadd.4s	v19, v19, v29
	fadd.4s	v20, v20, v24
	fadd.4s	v18, v18, v27
	ldr	q24, [x27, #10768]
	ldr	q27, [x27, #10752]
	and.16b	v27, v1, v27
	and.16b	v24, v13, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v21, v21, v25
	fmul.4s	v25, v28, v27
	ldr	q27, [x27, #10800]
	ldr	q29, [x27, #10784]
	and.16b	v29, v1, v29
	and.16b	v27, v13, v27
	fadd.4s	v22, v22, v25
	fmul.4s	v25, v26, v27
	fmul.4s	v27, v28, v29
	ldr	q29, [x27, #10832]
	ldr	q30, [x27, #10816]
	and.16b	v30, v1, v30
	fadd.4s	v23, v23, v24
	and.16b	v24, v13, v29
	fmul.4s	v24, v26, v24
	fmul.4s	v26, v28, v30
	ldp	q29, q28, [x28, #256]
	fadd.4s	v2, v2, v27
	and.16b	v27, v1, v29
	and.16b	v28, v13, v28
	ldr	q29, [x30, #12304]
	ldr	q30, [x30, #12288]
	and.16b	v30, v1, v30
	fadd.4s	v3, v3, v25
	and.16b	v25, v13, v29
	fmul.4s	v25, v28, v25
	fmul.4s	v29, v27, v30
	fadd.4s	v20, v20, v29
	fadd.4s	v19, v19, v25
	fadd.4s	v21, v21, v26
	ldr	q25, [x27, #12288]
	ldr	q26, [x27, #12304]
	and.16b	v26, v13, v26
	and.16b	v25, v1, v25
	fmul.4s	v25, v27, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v24, v28, v26
	ldr	q26, [x27, #12320]
	ldr	q29, [x27, #12336]
	and.16b	v29, v13, v29
	and.16b	v26, v1, v26
	fadd.4s	v23, v23, v24
	fmul.4s	v24, v27, v26
	fmul.4s	v26, v28, v29
	ldr	q29, [x27, #12352]
	ldr	q30, [x27, #12368]
	and.16b	v30, v13, v30
	fadd.4s	v22, v22, v25
	and.16b	v25, v1, v29
	fmul.4s	v25, v27, v25
	fmul.4s	v27, v28, v30
	ldp	q28, q29, [x28, #288]
	fadd.4s	v3, v3, v26
	and.16b	v26, v13, v29
	and.16b	v28, v1, v28
	ldr	q29, [x30, #13824]
	ldr	q30, [x30, #13840]
	and.16b	v30, v13, v30
	fadd.4s	v2, v2, v24
	and.16b	v24, v1, v29
	fmul.4s	v24, v28, v24
	fmul.4s	v29, v26, v30
	fadd.4s	v19, v19, v29
	fadd.4s	v20, v20, v24
	fadd.4s	v18, v18, v27
	ldr	q24, [x27, #13840]
	ldr	q27, [x27, #13824]
	and.16b	v27, v1, v27
	and.16b	v24, v13, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v21, v21, v25
	fmul.4s	v25, v28, v27
	ldr	q27, [x27, #13872]
	ldr	q29, [x27, #13856]
	and.16b	v29, v1, v29
	and.16b	v27, v13, v27
	fadd.4s	v22, v22, v25
	fmul.4s	v25, v26, v27
	fmul.4s	v27, v28, v29
	ldr	q29, [x27, #13904]
	ldr	q30, [x27, #13888]
	and.16b	v30, v1, v30
	fadd.4s	v23, v23, v24
	and.16b	v24, v13, v29
	fmul.4s	v24, v26, v24
	fmul.4s	v26, v28, v30
	ldp	q29, q28, [x28, #320]
	fadd.4s	v2, v2, v27
	and.16b	v27, v1, v29
	and.16b	v28, v13, v28
	ldr	q29, [x30, #15376]
	ldr	q30, [x30, #15360]
	and.16b	v30, v1, v30
	fadd.4s	v3, v3, v25
	and.16b	v25, v13, v29
	fmul.4s	v25, v28, v25
	fmul.4s	v29, v27, v30
	fadd.4s	v20, v20, v29
	fadd.4s	v19, v19, v25
	fadd.4s	v21, v21, v26
	ldr	q25, [x27, #15360]
	ldr	q26, [x27, #15376]
	and.16b	v26, v13, v26
	and.16b	v25, v1, v25
	fmul.4s	v25, v27, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v24, v28, v26
	ldr	q26, [x27, #15392]
	ldr	q29, [x27, #15408]
	and.16b	v29, v13, v29
	and.16b	v26, v1, v26
	fadd.4s	v23, v23, v24
	fmul.4s	v24, v27, v26
	fmul.4s	v26, v28, v29
	ldr	q29, [x27, #15424]
	ldr	q30, [x27, #15440]
	and.16b	v30, v13, v30
	fadd.4s	v22, v22, v25
	and.16b	v25, v1, v29
	fmul.4s	v25, v27, v25
	fmul.4s	v27, v28, v30
	ldp	q28, q29, [x28, #352]
	fadd.4s	v3, v3, v26
	and.16b	v26, v13, v29
	and.16b	v28, v1, v28
	ldr	q29, [x30, #16896]
	ldr	q30, [x30, #16912]
	and.16b	v30, v13, v30
	fadd.4s	v2, v2, v24
	and.16b	v24, v1, v29
	fmul.4s	v24, v28, v24
	fmul.4s	v29, v26, v30
	fadd.4s	v19, v19, v29
	fadd.4s	v20, v20, v24
	fadd.4s	v18, v18, v27
	ldr	q24, [x27, #16912]
	ldr	q27, [x27, #16896]
	and.16b	v27, v1, v27
	and.16b	v24, v13, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v21, v21, v25
	fmul.4s	v25, v28, v27
	ldr	q27, [x27, #16944]
	ldr	q29, [x27, #16928]
	and.16b	v29, v1, v29
	and.16b	v27, v13, v27
	fadd.4s	v22, v22, v25
	fmul.4s	v25, v26, v27
	fmul.4s	v27, v28, v29
	ldr	q29, [x27, #16976]
	ldr	q30, [x27, #16960]
	and.16b	v30, v1, v30
	fadd.4s	v23, v23, v24
	and.16b	v24, v13, v29
	fmul.4s	v24, v26, v24
	fmul.4s	v26, v28, v30
	ldp	q29, q28, [x28, #384]
	fadd.4s	v2, v2, v27
	and.16b	v27, v1, v29
	and.16b	v28, v13, v28
	ldr	q29, [x30, #18448]
	ldr	q30, [x30, #18432]
	and.16b	v30, v1, v30
	fadd.4s	v3, v3, v25
	and.16b	v25, v13, v29
	fmul.4s	v25, v28, v25
	fmul.4s	v29, v27, v30
	fadd.4s	v20, v20, v29
	fadd.4s	v19, v19, v25
	fadd.4s	v21, v21, v26
	ldr	q25, [x27, #18432]
	ldr	q26, [x27, #18448]
	and.16b	v26, v13, v26
	and.16b	v25, v1, v25
	fmul.4s	v25, v27, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v24, v28, v26
	ldr	q26, [x27, #18464]
	ldr	q29, [x27, #18480]
	and.16b	v29, v13, v29
	and.16b	v26, v1, v26
	fadd.4s	v23, v23, v24
	fmul.4s	v24, v27, v26
	fmul.4s	v26, v28, v29
	ldr	q29, [x27, #18496]
	ldr	q30, [x27, #18512]
	and.16b	v30, v13, v30
	fadd.4s	v22, v22, v25
	and.16b	v25, v1, v29
	fmul.4s	v25, v27, v25
	fmul.4s	v27, v28, v30
	ldp	q28, q29, [x28, #416]
	fadd.4s	v3, v3, v26
	and.16b	v26, v13, v29
	and.16b	v28, v1, v28
	ldr	q29, [x30, #19968]
	ldr	q30, [x30, #19984]
	and.16b	v30, v13, v30
	fadd.4s	v2, v2, v24
	and.16b	v24, v1, v29
	fmul.4s	v24, v28, v24
	fmul.4s	v29, v26, v30
	fadd.4s	v19, v19, v29
	fadd.4s	v20, v20, v24
	fadd.4s	v18, v18, v27
	ldr	q24, [x27, #19984]
	ldr	q27, [x27, #19968]
	and.16b	v27, v1, v27
	and.16b	v24, v13, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v21, v21, v25
	fmul.4s	v25, v28, v27
	ldr	q27, [x27, #20016]
	ldr	q29, [x27, #20000]
	and.16b	v29, v1, v29
	and.16b	v27, v13, v27
	fadd.4s	v22, v22, v25
	fmul.4s	v25, v26, v27
	fmul.4s	v27, v28, v29
	ldr	q29, [x27, #20048]
	ldr	q30, [x27, #20032]
	and.16b	v30, v1, v30
	fadd.4s	v23, v23, v24
	and.16b	v24, v13, v29
	fmul.4s	v24, v26, v24
	fmul.4s	v26, v28, v30
	ldp	q29, q28, [x28, #448]
	fadd.4s	v2, v2, v27
	and.16b	v27, v1, v29
	and.16b	v28, v13, v28
	ldr	q29, [x30, #21520]
	ldr	q30, [x30, #21504]
	and.16b	v30, v1, v30
	fadd.4s	v3, v3, v25
	and.16b	v25, v13, v29
	fmul.4s	v25, v28, v25
	fmul.4s	v29, v27, v30
	fadd.4s	v20, v20, v29
	fadd.4s	v19, v19, v25
	fadd.4s	v21, v21, v26
	ldr	q25, [x27, #21504]
	ldr	q26, [x27, #21520]
	and.16b	v26, v13, v26
	and.16b	v25, v1, v25
	fmul.4s	v25, v27, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v24, v28, v26
	ldr	q26, [x27, #21536]
	ldr	q29, [x27, #21552]
	and.16b	v29, v13, v29
	and.16b	v26, v1, v26
	fadd.4s	v23, v23, v24
	fmul.4s	v24, v27, v26
	fmul.4s	v26, v28, v29
	ldr	q29, [x27, #21568]
	ldr	q30, [x27, #21584]
	and.16b	v30, v13, v30
	fadd.4s	v22, v22, v25
	and.16b	v25, v1, v29
	fmul.4s	v25, v27, v25
	fmul.4s	v27, v28, v30
	ldp	q28, q29, [x28, #480]
	fadd.4s	v3, v3, v26
	and.16b	v26, v13, v29
	and.16b	v28, v1, v28
	ldr	q29, [x30, #23040]
	ldr	q30, [x30, #23056]
	and.16b	v30, v13, v30
	fadd.4s	v2, v2, v24
	fmul.4s	v24, v26, v30
	ldr	q30, [x27, #23056]
	fadd.4s	v19, v19, v24
	ldr	q24, [x27, #23040]
	and.16b	v29, v1, v29
	fadd.4s	v18, v18, v27
	ldr	q27, [x27, #23088]
	fmul.4s	v29, v28, v29
	fadd.4s	v20, v20, v29
	ldr	q29, [x27, #23072]
	and.16b	v24, v1, v24
	fadd.4s	v21, v21, v25
	fmul.4s	v24, v28, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x27, #23120]
	and.16b	v25, v13, v30
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x27, #23104]
	and.16b	v29, v1, v29
	and.16b	v27, v13, v27
	fmul.4s	v27, v26, v27
	fmul.4s	v29, v28, v29
	fadd.4s	v2, v2, v29
	and.16b	v24, v13, v24
	fmul.4s	v24, v26, v24
	ldp	q29, q26, [x25, #-96]
	and.16b	v25, v1, v25
	fadd.4s	v3, v3, v27
	fmul.4s	v25, v28, v25
	fadd.4s	v21, v21, v25
	ldp	q25, q27, [x25, #-64]
	bif.16b	v20, v29, v1
	fadd.4s	v18, v18, v24
	ldp	q24, q28, [x25, #-32]
	bif.16b	v19, v26, v13
	stp	q20, q19, [x25, #-96]
	ldp	q26, q19, [x25]
	add	x4, x4, #4
	mov.16b	v20, v13
	bsl.16b	v20, v23, v27
	bif.16b	v22, v25, v1
	stp	q22, q20, [x25, #-64]
	bif.16b	v3, v28, v13
	bif.16b	v2, v24, v1
	bif.16b	v18, v19, v13
	mov.16b	v19, v1
	bsl.16b	v19, v21, v26
	stp	q2, q3, [x25, #-32]
	stp	q19, q18, [x25], #128
	add	x26, x26, #4
	add	x24, x24, #128
	cmp	x4, #48
	b.ne	LBB0_261
; %bb.262:                              ; %direct.false1570
                                        ;   in Loop: Header=BB0_260 Depth=2
	add	x10, x10, #1
	add	x9, x9, #48
	add	x0, x0, #1536
	add	x13, x13, #1536
	cmp	x10, #8
	b.ne	LBB0_260
; %bb.263:                              ; %direct.true2036.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	w9, #384                        ; =0x180
	mov	x10, x11
	mov	w14, #23680                     ; =0x5c80
	movk	w14, #1, lsl #16
LBB0_264:                               ; %direct.true2036
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x13, x10, x14
	ldp	q2, q3, [x13]
	ldr	q18, [x10, #20480]
	ldr	q19, [x10, #20496]
	bif.16b	v3, v19, v13
	bif.16b	v2, v18, v1
	str	q2, [x10, #20480]
	str	q3, [x10, #20496]
	add	x10, x10, #32
	subs	x9, x9, #1
	b.ne	LBB0_264
; %bb.265:                              ; %direct.true2052.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x9, x11
	mov	w10, #384                       ; =0x180
	ldr	x24, [sp, #3464]                ; 8-byte Reload
	ldr	x25, [sp, #3456]                ; 8-byte Reload
	ldr	x26, [sp, #4232]                ; 8-byte Reload
	mov	w15, #48                        ; =0x30
LBB0_266:                               ; %direct.true2052
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x9, #20480]
	ldr	q3, [x9, #20496]
	ldr	q18, [x9, #8192]
	ldr	q19, [x9, #8208]
	bif.16b	v3, v19, v13
	bif.16b	v2, v18, v1
	str	q2, [x9, #8192]
	str	q3, [x9, #8208]
	add	x9, x9, #32
	subs	x10, x10, #1
	b.ne	LBB0_266
; %bb.267:                              ; %direct.false2053
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q2, [sp, #4976]                 ; 16-byte Reload
	ldr	q3, [sp, #9088]                 ; 16-byte Reload
	bit.16b	v2, v3, v13
	str	q2, [sp, #4976]                 ; 16-byte Spill
	ldr	q2, [sp, #4992]                 ; 16-byte Reload
	ldr	q3, [sp, #9120]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4992]                 ; 16-byte Spill
	ldr	q2, [sp, #5264]                 ; 16-byte Reload
	ldr	q3, [sp, #9072]                 ; 16-byte Reload
	bit.16b	v2, v3, v13
	str	q2, [sp, #5264]                 ; 16-byte Spill
	ldr	q2, [sp, #5280]                 ; 16-byte Reload
	ldr	q3, [sp, #9104]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5280]                 ; 16-byte Spill
	ldr	q2, [sp, #5296]                 ; 16-byte Reload
	ldr	q3, [sp, #9360]                 ; 16-byte Reload
	bit.16b	v2, v3, v13
	str	q2, [sp, #5296]                 ; 16-byte Spill
	ldr	q2, [sp, #5312]                 ; 16-byte Reload
	ldr	q3, [sp, #9456]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5312]                 ; 16-byte Spill
	ldr	q2, [sp, #5328]                 ; 16-byte Reload
	ldr	q3, [sp, #9344]                 ; 16-byte Reload
	bit.16b	v2, v3, v13
	str	q2, [sp, #5328]                 ; 16-byte Spill
	ldr	q2, [sp, #5344]                 ; 16-byte Reload
	ldr	q3, [sp, #9440]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5344]                 ; 16-byte Spill
	ldr	q2, [sp, #5360]                 ; 16-byte Reload
	ldr	q3, [sp, #9328]                 ; 16-byte Reload
	bit.16b	v2, v3, v13
	str	q2, [sp, #5360]                 ; 16-byte Spill
	ldr	q2, [sp, #5376]                 ; 16-byte Reload
	ldr	q3, [sp, #9424]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5376]                 ; 16-byte Spill
	ldr	q2, [sp, #5392]                 ; 16-byte Reload
	ldr	q3, [sp, #9312]                 ; 16-byte Reload
	bit.16b	v2, v3, v13
	str	q2, [sp, #5392]                 ; 16-byte Spill
	ldr	q2, [sp, #5408]                 ; 16-byte Reload
	ldr	q3, [sp, #9408]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5408]                 ; 16-byte Spill
	ldr	q2, [sp, #5424]                 ; 16-byte Reload
	ldr	q3, [sp, #9296]                 ; 16-byte Reload
	bit.16b	v2, v3, v13
	str	q2, [sp, #5424]                 ; 16-byte Spill
	ldr	q2, [sp, #5456]                 ; 16-byte Reload
	ldr	q3, [sp, #9392]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5456]                 ; 16-byte Spill
	ldr	q2, [sp, #5440]                 ; 16-byte Reload
	ldr	q3, [sp, #9280]                 ; 16-byte Reload
	bit.16b	v2, v3, v13
	str	q2, [sp, #5440]                 ; 16-byte Spill
	ldr	q2, [sp, #5472]                 ; 16-byte Reload
	ldr	q3, [sp, #9376]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #5472]                 ; 16-byte Spill
	movi.2d	v18, #0000000000000000
	ldr	q2, [sp, #3696]                 ; 16-byte Reload
	fadd.4s	v2, v2, v18
	fadd.4s	v2, v2, v6
	ldr	q3, [sp, #3824]                 ; 16-byte Reload
	fadd.4s	v3, v3, v18
	ldr	q6, [sp, #3680]                 ; 16-byte Reload
	fadd.4s	v3, v3, v6
	fadd.4s	v3, v3, v7
	ldr	q6, [sp, #3808]                 ; 16-byte Reload
	fadd.4s	v2, v2, v6
	ldr	q6, [sp, #3648]                 ; 16-byte Reload
	fadd.4s	v2, v2, v6
	ldr	q6, [sp, #3664]                 ; 16-byte Reload
	fadd.4s	v3, v3, v6
	fadd.4s	v3, v3, v16
	ldr	q6, [sp, #3792]                 ; 16-byte Reload
	fadd.4s	v2, v2, v6
	ldr	q6, [sp, #3616]                 ; 16-byte Reload
	fadd.4s	v2, v2, v6
	ldr	q6, [sp, #3632]                 ; 16-byte Reload
	fadd.4s	v3, v3, v6
	fadd.4s	v3, v3, v17
	ldr	q6, [sp, #3776]                 ; 16-byte Reload
	fadd.4s	v2, v2, v6
	fadd.4s	v2, v2, v31
	ldr	q6, [sp, #3600]                 ; 16-byte Reload
	fadd.4s	v3, v3, v6
	fadd.4s	v0, v3, v0
	ldr	q3, [sp, #3760]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	fadd.4s	v2, v2, v9
	fadd.4s	v0, v0, v8
	fadd.4s	v0, v0, v15
	ldr	q3, [sp, #3744]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	fadd.4s	v2, v2, v11
	fadd.4s	v0, v0, v10
	fadd.4s	v0, v0, v4
	ldr	q3, [sp, #3728]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	fadd.4s	v2, v2, v14
	fadd.4s	v0, v0, v12
	fadd.4s	v0, v0, v5
	ldr	q3, [sp, #3712]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3568]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3584]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #5024]                 ; 16-byte Reload
	bit.16b	v3, v0, v1
	str	q3, [sp, #5024]                 ; 16-byte Spill
	ldr	q0, [sp, #5008]                 ; 16-byte Reload
	bit.16b	v0, v2, v13
	str	q0, [sp, #5008]                 ; 16-byte Spill
	ldr	q0, [sp, #5776]                 ; 16-byte Reload
	fadd.4s	v0, v0, v18
	ldr	q2, [sp, #3952]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #5904]                 ; 16-byte Reload
	fadd.4s	v2, v2, v18
	ldr	q3, [sp, #5760]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3936]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5888]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #5728]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #5744]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3920]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5872]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #5696]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #5712]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3904]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5856]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #4096]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #5648]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3888]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5840]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #4064]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #4080]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3872]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5824]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #4032]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #4048]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3856]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5808]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #4000]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #4016]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5792]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #3968]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #3984]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5104]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #5104]                 ; 16-byte Spill
	ldr	q2, [sp, #5088]                 ; 16-byte Reload
	bit.16b	v2, v0, v13
	str	q2, [sp, #5088]                 ; 16-byte Spill
	ldr	q0, [sp, #6288]                 ; 16-byte Reload
	fadd.4s	v0, v0, v18
	ldr	q2, [sp, #6032]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6416]                 ; 16-byte Reload
	fadd.4s	v2, v2, v18
	ldr	q3, [sp, #6272]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6016]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6400]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6240]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6256]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6000]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6384]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6208]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6224]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5984]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6368]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6176]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6192]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5968]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6352]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6144]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6160]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5952]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6336]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6112]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6128]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5936]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6320]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6080]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6096]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5920]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6304]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6048]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6064]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5072]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #5072]                 ; 16-byte Spill
	ldr	q2, [sp, #5056]                 ; 16-byte Reload
	bit.16b	v2, v0, v13
	str	q2, [sp, #5056]                 ; 16-byte Spill
	ldr	q0, [sp, #6800]                 ; 16-byte Reload
	fadd.4s	v0, v0, v18
	ldr	q2, [sp, #6544]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6928]                 ; 16-byte Reload
	fadd.4s	v2, v2, v18
	ldr	q3, [sp, #6784]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6528]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6912]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6752]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6768]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6512]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6896]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6720]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6736]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6496]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6880]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6688]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6704]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6480]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6864]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6656]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6672]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6464]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6848]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6624]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6640]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6448]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6832]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6592]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6608]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6432]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6816]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6560]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #6576]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5040]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #5040]                 ; 16-byte Spill
	ldr	q2, [sp, #5184]                 ; 16-byte Reload
	bit.16b	v2, v0, v13
	str	q2, [sp, #5184]                 ; 16-byte Spill
	ldr	q0, [sp, #7312]                 ; 16-byte Reload
	fadd.4s	v0, v0, v18
	ldr	q2, [sp, #7056]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #7440]                 ; 16-byte Reload
	fadd.4s	v2, v2, v18
	ldr	q3, [sp, #7296]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7040]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7424]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7264]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7280]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7024]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7408]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7232]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7248]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7008]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7392]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7200]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7216]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6992]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7376]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7168]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7184]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6976]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7360]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7136]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7152]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6960]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7344]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7104]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7120]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6944]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7328]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7072]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7088]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5168]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #5168]                 ; 16-byte Spill
	ldr	q2, [sp, #5152]                 ; 16-byte Reload
	bit.16b	v2, v0, v13
	str	q2, [sp, #5152]                 ; 16-byte Spill
	ldr	q0, [sp, #7824]                 ; 16-byte Reload
	fadd.4s	v0, v0, v18
	ldr	q2, [sp, #7568]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #7952]                 ; 16-byte Reload
	fadd.4s	v2, v2, v18
	ldr	q3, [sp, #7808]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7552]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7936]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7776]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7792]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7536]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7920]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7744]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7760]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7520]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7904]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7712]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7728]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7504]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7888]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7680]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7696]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7488]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7872]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7648]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7664]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7472]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7856]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7616]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7632]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7456]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7840]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7584]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #7600]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5136]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #5136]                 ; 16-byte Spill
	ldr	q2, [sp, #5120]                 ; 16-byte Reload
	bit.16b	v2, v0, v13
	str	q2, [sp, #5120]                 ; 16-byte Spill
	ldr	q0, [sp, #8240]                 ; 16-byte Reload
	fadd.4s	v0, v0, v18
	ldr	q2, [sp, #8048]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #8352]                 ; 16-byte Reload
	fadd.4s	v2, v2, v18
	ldr	q3, [sp, #8224]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8032]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8336]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8192]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8208]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8016]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8320]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8160]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8176]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8000]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8304]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8128]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8144]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7984]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8288]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8096]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8112]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7968]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8272]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8064]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8080]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8448]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8464]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8400]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8416]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8256]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8432]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8368]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8384]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q27, [sp, #4320]                ; 16-byte Reload
	bit.16b	v27, v2, v1
	ldr	q26, [sp, #4304]                ; 16-byte Reload
	bit.16b	v26, v0, v13
	ldr	q0, [sp, #8976]                 ; 16-byte Reload
	fadd.4s	v0, v0, v18
	ldr	q2, [sp, #8624]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #8960]                 ; 16-byte Reload
	fadd.4s	v2, v2, v18
	ldr	q3, [sp, #8832]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8608]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8944]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8800]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8816]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8592]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8928]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8768]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8784]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8576]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8912]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8736]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8752]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8560]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8896]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8704]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8720]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8544]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8880]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8672]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8688]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8528]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8864]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8640]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8656]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8512]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #8848]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8480]                 ; 16-byte Reload
	fadd.4s	v4, v0, v3
	ldr	q0, [sp, #8496]                 ; 16-byte Reload
	fadd.4s	v2, v2, v0
	ldr	q3, [sp, #4288]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	ldr	q0, [sp, #4272]                 ; 16-byte Reload
	bit.16b	v0, v4, v13
	ldr	q5, [sp, #4896]                 ; 16-byte Reload
	ldr	q2, [sp, #9488]                 ; 16-byte Reload
	fmul.4s	v2, v5, v2
	str	q2, [sp, #9488]                 ; 16-byte Spill
	ldr	q9, [sp, #4880]                 ; 16-byte Reload
	ldr	q2, [sp, #9472]                 ; 16-byte Reload
	fmul.4s	v29, v9, v2
	ldr	q2, [sp, #4928]                 ; 16-byte Reload
	ldr	q4, [sp, #9248]                 ; 16-byte Reload
	fmul.4s	v4, v2, v4
	str	q4, [sp, #9440]                 ; 16-byte Spill
	ldr	q25, [sp, #4912]                ; 16-byte Reload
	ldr	q4, [sp, #9264]                 ; 16-byte Reload
	fmul.4s	v4, v25, v4
	ldr	q14, [sp, #4800]                ; 16-byte Reload
	ldr	q6, [sp, #9216]                 ; 16-byte Reload
	fmul.4s	v6, v14, v6
	str	q6, [sp, #9424]                 ; 16-byte Spill
	ldr	q18, [sp, #4784]                ; 16-byte Reload
	ldr	q6, [sp, #9232]                 ; 16-byte Reload
	fmul.4s	v31, v18, v6
	ldr	q12, [sp, #4832]                ; 16-byte Reload
	ldr	q7, [sp, #9184]                 ; 16-byte Reload
	fmul.4s	v7, v12, v7
	ldr	q15, [sp, #4816]                ; 16-byte Reload
	ldr	q16, [sp, #9200]                ; 16-byte Reload
	fmul.4s	v16, v15, v16
	ldr	q10, [sp, #4864]                ; 16-byte Reload
	ldr	q17, [sp, #9168]                ; 16-byte Reload
	fmul.4s	v6, v10, v17
	str	q6, [sp, #9408]                 ; 16-byte Spill
	ldr	q11, [sp, #4848]                ; 16-byte Reload
	ldr	q17, [sp, #9056]                ; 16-byte Reload
	fmul.4s	v17, v11, v17
	ldr	q23, [sp, #4704]                ; 16-byte Reload
	ldr	q19, [sp, #9152]                ; 16-byte Reload
	fmul.4s	v6, v23, v19
	str	q6, [sp, #9392]                 ; 16-byte Spill
	ldr	q24, [sp, #4688]                ; 16-byte Reload
	ldr	q19, [sp, #9136]                ; 16-byte Reload
	fmul.4s	v28, v24, v19
	ldr	q21, [sp, #4736]                ; 16-byte Reload
	ldr	q19, [sp, #9024]                ; 16-byte Reload
	fmul.4s	v6, v21, v19
	str	q6, [sp, #9376]                 ; 16-byte Spill
	ldr	q22, [sp, #4720]                ; 16-byte Reload
	ldr	q19, [sp, #9040]                ; 16-byte Reload
	fmul.4s	v30, v22, v19
	ldr	q19, [sp, #4768]                ; 16-byte Reload
	ldr	q20, [sp, #8992]                ; 16-byte Reload
	fmul.4s	v6, v19, v20
	str	q6, [sp, #9456]                 ; 16-byte Spill
	ldr	q20, [sp, #4752]                ; 16-byte Reload
	ldr	q8, [sp, #9008]                 ; 16-byte Reload
	fmul.4s	v8, v20, v8
	str	q0, [sp, #4272]                 ; 16-byte Spill
	fadd.4s	v6, v29, v0
	str	q3, [sp, #4288]                 ; 16-byte Spill
	ldr	q0, [sp, #9488]                 ; 16-byte Reload
	fadd.4s	v0, v0, v3
	str	q26, [sp, #4304]                ; 16-byte Spill
	fadd.4s	v3, v4, v26
	str	q3, [sp, #9472]                 ; 16-byte Spill
	str	q27, [sp, #4320]                ; 16-byte Spill
	ldr	q3, [sp, #9440]                 ; 16-byte Reload
	fadd.4s	v4, v3, v27
	ldr	q3, [sp, #5120]                 ; 16-byte Reload
	fadd.4s	v3, v31, v3
	ldr	q26, [sp, #5136]                ; 16-byte Reload
	ldr	q27, [sp, #9424]                ; 16-byte Reload
	fadd.4s	v31, v27, v26
	ldr	q26, [sp, #5152]                ; 16-byte Reload
	fadd.4s	v16, v16, v26
	str	q16, [sp, #9488]                ; 16-byte Spill
	ldr	q16, [sp, #5168]                ; 16-byte Reload
	fadd.4s	v16, v7, v16
	ldr	q7, [sp, #5184]                 ; 16-byte Reload
	fadd.4s	v7, v17, v7
	str	q7, [sp, #9440]                 ; 16-byte Spill
	ldr	q17, [sp, #5040]                ; 16-byte Reload
	ldr	q7, [sp, #9408]                 ; 16-byte Reload
	fadd.4s	v29, v7, v17
	ldr	q26, [sp, #5056]                ; 16-byte Reload
	fadd.4s	v28, v28, v26
	ldr	q26, [sp, #5072]                ; 16-byte Reload
	ldr	q7, [sp, #9392]                 ; 16-byte Reload
	fadd.4s	v27, v7, v26
	ldr	q26, [sp, #5088]                ; 16-byte Reload
	fadd.4s	v17, v30, v26
	ldr	q26, [sp, #5104]                ; 16-byte Reload
	ldr	q7, [sp, #9376]                 ; 16-byte Reload
	fadd.4s	v30, v7, v26
	ldr	q26, [sp, #5008]                ; 16-byte Reload
	fadd.4s	v8, v8, v26
	ldr	q26, [sp, #5024]                ; 16-byte Reload
	ldr	q7, [sp, #9456]                 ; 16-byte Reload
	fadd.4s	v26, v7, v26
	add	x26, x26, #1
	str	q0, [sp, #9408]                 ; 16-byte Spill
	bit.16b	v5, v0, v1
	str	q5, [sp, #4896]                 ; 16-byte Spill
	mov.16b	v5, v6
	bit.16b	v9, v6, v13
	mov.16b	v0, v3
	ldr	q3, [sp, #9472]                 ; 16-byte Reload
	str	q9, [sp, #4880]                 ; 16-byte Spill
	str	q4, [sp, #9424]                 ; 16-byte Spill
	bit.16b	v2, v4, v1
	str	q2, [sp, #4928]                 ; 16-byte Spill
	mov.16b	v2, v27
	bit.16b	v25, v3, v13
	str	q25, [sp, #4912]                ; 16-byte Spill
	str	q31, [sp, #9456]                ; 16-byte Spill
	bit.16b	v14, v31, v1
	mov.16b	v31, v8
	mov.16b	v8, v26
	str	q14, [sp, #4800]                ; 16-byte Spill
	bit.16b	v18, v0, v13
	str	q18, [sp, #4784]                ; 16-byte Spill
	mov.16b	v14, v16
	bit.16b	v12, v16, v1
	ldr	q16, [sp, #9488]                ; 16-byte Reload
	str	q12, [sp, #4832]                ; 16-byte Spill
	bit.16b	v15, v16, v13
	str	q15, [sp, #4816]                ; 16-byte Spill
	mov.16b	v15, v29
	bit.16b	v10, v29, v1
	mov.16b	v29, v30
	mov.16b	v30, v17
	ldr	q17, [sp, #9440]                ; 16-byte Reload
	str	q10, [sp, #4864]                ; 16-byte Spill
	bit.16b	v11, v17, v13
	str	q11, [sp, #4848]                ; 16-byte Spill
	bit.16b	v23, v27, v1
	str	q23, [sp, #4704]                ; 16-byte Spill
	mov.16b	v6, v28
	bit.16b	v24, v28, v13
	str	q24, [sp, #4688]                ; 16-byte Spill
	bit.16b	v21, v29, v1
	str	q21, [sp, #4736]                ; 16-byte Spill
	bit.16b	v22, v30, v13
	str	q22, [sp, #4720]                ; 16-byte Spill
	bit.16b	v19, v26, v1
	str	q19, [sp, #4768]                ; 16-byte Spill
	bit.16b	v20, v31, v13
	str	q20, [sp, #4752]                ; 16-byte Spill
	cmp	x26, #9
	ldr	q12, [sp, #3520]                ; 16-byte Reload
	ldr	q9, [sp, #4960]                 ; 16-byte Reload
	ldr	q10, [sp, #4944]                ; 16-byte Reload
	ldr	q26, [sp, #3440]                ; 16-byte Reload
	ldr	q27, [sp, #3424]                ; 16-byte Reload
	ldr	q28, [sp, #2608]                ; 16-byte Reload
	ldr	q11, [sp, #2576]                ; 16-byte Reload
	ldr	q18, [sp, #4208]                ; 16-byte Reload
	ldr	q19, [sp, #4192]                ; 16-byte Reload
	ldr	q20, [sp, #4176]                ; 16-byte Reload
	ldr	q21, [sp, #4160]                ; 16-byte Reload
	ldr	q22, [sp, #4144]                ; 16-byte Reload
	ldr	q23, [sp, #4128]                ; 16-byte Reload
	ldr	q24, [sp, #4112]                ; 16-byte Reload
	b.ne	LBB0_22
	b	LBB0_385
LBB0_268:                               ; %cond.store289
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #112]                  ; 16-byte Reload
	mov.d	x10, v0[1]
	strb	w13, [x10]
	tbz	w9, #4, LBB0_42
LBB0_269:                               ; %cond.store292
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #128]                  ; 16-byte Reload
	fmov	x10, d0
	strb	w13, [x10]
	tbz	w9, #5, LBB0_43
LBB0_270:                               ; %cond.store295
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #128]                  ; 16-byte Reload
	mov.d	x10, v0[1]
	strb	w13, [x10]
	tbz	w9, #6, LBB0_44
LBB0_271:                               ; %cond.store298
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #80]                   ; 16-byte Reload
	fmov	x10, d0
	strb	w13, [x10]
	tbz	w9, #7, LBB0_45
LBB0_272:                               ; %cond.store301
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #80]                   ; 16-byte Reload
	mov.d	x9, v0[1]
	strb	w13, [x9]
	orr	x20, x16, #0x1
	cmp	x20, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbz	w9, #0, LBB0_46
LBB0_273:                               ; %cond.store305
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2448]                 ; 16-byte Reload
	fmov	x10, d0
	str	b2, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_47
LBB0_274:                               ; %cond.store308
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2448]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[1], [x10]
	tbz	w9, #2, LBB0_48
LBB0_275:                               ; %cond.store311
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2480]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[2], [x10]
	tbz	w9, #3, LBB0_49
LBB0_276:                               ; %cond.store314
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2480]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[3], [x10]
	tbz	w9, #4, LBB0_50
LBB0_277:                               ; %cond.store317
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2512]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[4], [x10]
	tbz	w9, #5, LBB0_51
LBB0_278:                               ; %cond.store320
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2512]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[5], [x10]
	tbz	w9, #6, LBB0_52
LBB0_279:                               ; %cond.store323
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2544]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[6], [x10]
	tbz	w9, #7, LBB0_53
LBB0_280:                               ; %cond.store326
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2544]                 ; 16-byte Reload
	mov.d	x9, v0[1]
	st1.b	{ v2 }[7], [x9]
	orr	x21, x16, #0x2
	cmp	x21, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbz	w9, #0, LBB0_54
LBB0_281:                               ; %cond.store330
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2320]                 ; 16-byte Reload
	fmov	x10, d0
	str	b2, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_55
LBB0_282:                               ; %cond.store334
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2320]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[1], [x10]
	tbz	w9, #2, LBB0_56
LBB0_283:                               ; %cond.store338
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2352]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[2], [x10]
	tbz	w9, #3, LBB0_57
LBB0_284:                               ; %cond.store342
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2352]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[3], [x10]
	tbz	w9, #4, LBB0_58
LBB0_285:                               ; %cond.store346
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2384]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[4], [x10]
	tbz	w9, #5, LBB0_59
LBB0_286:                               ; %cond.store350
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2384]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[5], [x10]
	tbz	w9, #6, LBB0_60
LBB0_287:                               ; %cond.store354
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2416]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[6], [x10]
	tbz	w9, #7, LBB0_61
LBB0_288:                               ; %cond.store358
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2416]                 ; 16-byte Reload
	mov.d	x9, v0[1]
	st1.b	{ v2 }[7], [x9]
	orr	x22, x16, #0x3
	cmp	x22, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbz	w9, #0, LBB0_62
LBB0_289:                               ; %cond.store363
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2192]                 ; 16-byte Reload
	fmov	x10, d0
	str	b2, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_63
LBB0_290:                               ; %cond.store367
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2192]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[1], [x10]
	tbz	w9, #2, LBB0_64
LBB0_291:                               ; %cond.store371
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2224]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[2], [x10]
	tbz	w9, #3, LBB0_65
LBB0_292:                               ; %cond.store375
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2224]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[3], [x10]
	tbz	w9, #4, LBB0_66
LBB0_293:                               ; %cond.store379
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2256]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[4], [x10]
	tbz	w9, #5, LBB0_67
LBB0_294:                               ; %cond.store383
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2256]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[5], [x10]
	tbz	w9, #6, LBB0_68
LBB0_295:                               ; %cond.store387
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2288]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[6], [x10]
	tbz	w9, #7, LBB0_69
LBB0_296:                               ; %cond.store391
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2288]                 ; 16-byte Reload
	mov.d	x9, v0[1]
	st1.b	{ v2 }[7], [x9]
	orr	x23, x16, #0x4
	cmp	x23, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbz	w9, #0, LBB0_70
LBB0_297:                               ; %cond.store396
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2064]                 ; 16-byte Reload
	fmov	x10, d0
	str	b2, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_71
LBB0_298:                               ; %cond.store400
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2064]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[1], [x10]
	tbz	w9, #2, LBB0_72
LBB0_299:                               ; %cond.store404
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2096]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[2], [x10]
	tbz	w9, #3, LBB0_73
LBB0_300:                               ; %cond.store408
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2096]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[3], [x10]
	tbz	w9, #4, LBB0_74
LBB0_301:                               ; %cond.store412
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2128]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[4], [x10]
	tbz	w9, #5, LBB0_75
LBB0_302:                               ; %cond.store416
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2128]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[5], [x10]
	tbz	w9, #6, LBB0_76
LBB0_303:                               ; %cond.store420
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2160]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[6], [x10]
	tbnz	w9, #7, LBB0_77
	b	LBB0_78
LBB0_304:                               ; %cond.store429
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	fmov	x10, d0
	str	b2, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_80
LBB0_305:                               ; %cond.store433
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[1], [x10]
	tbz	w9, #2, LBB0_81
LBB0_306:                               ; %cond.store437
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[2], [x10]
	tbz	w9, #3, LBB0_82
LBB0_307:                               ; %cond.store441
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[3], [x10]
	tbz	w9, #4, LBB0_83
LBB0_308:                               ; %cond.store445
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2000]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[4], [x10]
	tbz	w9, #5, LBB0_84
LBB0_309:                               ; %cond.store449
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2000]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[5], [x10]
	tbz	w9, #6, LBB0_85
LBB0_310:                               ; %cond.store453
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #2032]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[6], [x10]
	tbnz	w9, #7, LBB0_86
	b	LBB0_87
LBB0_311:                               ; %cond.store462
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	fmov	x10, d0
	str	b2, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_89
LBB0_312:                               ; %cond.store466
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[1], [x10]
	tbz	w9, #2, LBB0_90
LBB0_313:                               ; %cond.store470
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1840]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[2], [x10]
	tbz	w9, #3, LBB0_91
LBB0_314:                               ; %cond.store474
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1840]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[3], [x10]
	tbz	w9, #4, LBB0_92
LBB0_315:                               ; %cond.store478
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1872]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[4], [x10]
	tbz	w9, #5, LBB0_93
LBB0_316:                               ; %cond.store482
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1872]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[5], [x10]
	tbz	w9, #6, LBB0_94
LBB0_317:                               ; %cond.store486
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1904]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[6], [x10]
	tbnz	w9, #7, LBB0_95
	b	LBB0_96
LBB0_318:                               ; %cond.store495
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1680]                 ; 16-byte Reload
	fmov	x10, d0
	str	b2, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_98
LBB0_319:                               ; %cond.store499
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1680]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[1], [x10]
	tbz	w9, #2, LBB0_99
LBB0_320:                               ; %cond.store503
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1712]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[2], [x10]
	tbz	w9, #3, LBB0_100
LBB0_321:                               ; %cond.store507
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1712]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[3], [x10]
	tbz	w9, #4, LBB0_101
LBB0_322:                               ; %cond.store511
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1744]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[4], [x10]
	tbz	w9, #5, LBB0_102
LBB0_323:                               ; %cond.store515
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1744]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[5], [x10]
	tbz	w9, #6, LBB0_103
LBB0_324:                               ; %cond.store519
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1776]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[6], [x10]
	tbz	w9, #7, LBB0_104
LBB0_325:                               ; %cond.store523
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1776]                 ; 16-byte Reload
	mov.d	x9, v0[1]
	st1.b	{ v2 }[7], [x9]
	orr	x26, x16, #0x8
	cmp	x26, #129
	cset	w10, lo
	fmov	w9, s30
	dup.8b	v2, w10
	tbz	w9, #0, LBB0_105
LBB0_326:                               ; %cond.store528
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1552]                 ; 16-byte Reload
	fmov	x10, d0
	str	b2, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_106
LBB0_327:                               ; %cond.store532
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1552]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[1], [x10]
	tbz	w9, #2, LBB0_107
LBB0_328:                               ; %cond.store536
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1584]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[2], [x10]
	tbz	w9, #3, LBB0_108
LBB0_329:                               ; %cond.store540
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1584]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[3], [x10]
	tbz	w9, #4, LBB0_109
LBB0_330:                               ; %cond.store544
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1616]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[4], [x10]
	tbz	w9, #5, LBB0_110
LBB0_331:                               ; %cond.store548
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1616]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.b	{ v2 }[5], [x10]
	tbz	w9, #6, LBB0_111
LBB0_332:                               ; %cond.store552
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1648]                 ; 16-byte Reload
	fmov	x10, d0
	st1.b	{ v2 }[6], [x10]
	tbnz	w9, #7, LBB0_112
	b	LBB0_113
LBB0_333:                               ; %cond.store561
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1424]                 ; 16-byte Reload
	fmov	x13, d0
	str	b2, [x13]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_115
LBB0_334:                               ; %cond.store565
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1424]                 ; 16-byte Reload
	mov.d	x13, v0[1]
	st1.b	{ v2 }[1], [x13]
	tbz	w10, #2, LBB0_116
LBB0_335:                               ; %cond.store569
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1456]                 ; 16-byte Reload
	fmov	x13, d0
	st1.b	{ v2 }[2], [x13]
	tbz	w10, #3, LBB0_117
LBB0_336:                               ; %cond.store573
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1456]                 ; 16-byte Reload
	mov.d	x13, v0[1]
	st1.b	{ v2 }[3], [x13]
	tbz	w10, #4, LBB0_118
LBB0_337:                               ; %cond.store577
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1488]                 ; 16-byte Reload
	fmov	x13, d0
	st1.b	{ v2 }[4], [x13]
	tbz	w10, #5, LBB0_119
LBB0_338:                               ; %cond.store581
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1488]                 ; 16-byte Reload
	mov.d	x13, v0[1]
	st1.b	{ v2 }[5], [x13]
	tbz	w10, #6, LBB0_120
LBB0_339:                               ; %cond.store585
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1520]                 ; 16-byte Reload
	fmov	x13, d0
	st1.b	{ v2 }[6], [x13]
	tbnz	w10, #7, LBB0_121
	b	LBB0_122
LBB0_340:                               ; %cond.store594
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1296]                 ; 16-byte Reload
	fmov	x0, d0
	str	b2, [x0]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB0_124
LBB0_341:                               ; %cond.store598
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1296]                 ; 16-byte Reload
	mov.d	x0, v0[1]
	st1.b	{ v2 }[1], [x0]
	tbz	w13, #2, LBB0_125
LBB0_342:                               ; %cond.store602
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1328]                 ; 16-byte Reload
	fmov	x0, d0
	st1.b	{ v2 }[2], [x0]
	tbz	w13, #3, LBB0_126
LBB0_343:                               ; %cond.store606
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1328]                 ; 16-byte Reload
	mov.d	x0, v0[1]
	st1.b	{ v2 }[3], [x0]
	tbz	w13, #4, LBB0_127
LBB0_344:                               ; %cond.store610
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1360]                 ; 16-byte Reload
	fmov	x0, d0
	st1.b	{ v2 }[4], [x0]
	tbz	w13, #5, LBB0_128
LBB0_345:                               ; %cond.store614
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1360]                 ; 16-byte Reload
	mov.d	x0, v0[1]
	st1.b	{ v2 }[5], [x0]
	tbz	w13, #6, LBB0_129
LBB0_346:                               ; %cond.store618
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1392]                 ; 16-byte Reload
	fmov	x0, d0
	st1.b	{ v2 }[6], [x0]
	tbnz	w13, #7, LBB0_130
	b	LBB0_131
LBB0_347:                               ; %cond.store627
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1168]                 ; 16-byte Reload
	fmov	x4, d0
	str	b2, [x4]
	and	w0, w0, #0xff
	tbz	w0, #1, LBB0_133
LBB0_348:                               ; %cond.store631
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1168]                 ; 16-byte Reload
	mov.d	x4, v0[1]
	st1.b	{ v2 }[1], [x4]
	tbz	w0, #2, LBB0_134
LBB0_349:                               ; %cond.store635
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1200]                 ; 16-byte Reload
	fmov	x4, d0
	st1.b	{ v2 }[2], [x4]
	tbz	w0, #3, LBB0_135
LBB0_350:                               ; %cond.store639
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1200]                 ; 16-byte Reload
	mov.d	x4, v0[1]
	st1.b	{ v2 }[3], [x4]
	tbz	w0, #4, LBB0_136
LBB0_351:                               ; %cond.store643
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1232]                 ; 16-byte Reload
	fmov	x4, d0
	st1.b	{ v2 }[4], [x4]
	tbz	w0, #5, LBB0_137
LBB0_352:                               ; %cond.store647
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1232]                 ; 16-byte Reload
	mov.d	x4, v0[1]
	st1.b	{ v2 }[5], [x4]
	tbz	w0, #6, LBB0_138
LBB0_353:                               ; %cond.store651
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1264]                 ; 16-byte Reload
	fmov	x4, d0
	st1.b	{ v2 }[6], [x4]
	tbz	w0, #7, LBB0_139
LBB0_354:                               ; %cond.store655
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1264]                 ; 16-byte Reload
	mov.d	x0, v0[1]
	st1.b	{ v2 }[7], [x0]
	orr	x0, x16, #0xc
	cmp	x0, #129
	cset	w24, lo
	fmov	w4, s30
	dup.8b	v2, w24
	tbz	w4, #0, LBB0_140
LBB0_355:                               ; %cond.store660
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #496]                  ; 16-byte Reload
	fmov	x24, d0
	str	b2, [x24]
	and	w4, w4, #0xff
	tbz	w4, #1, LBB0_141
LBB0_356:                               ; %cond.store664
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #496]                  ; 16-byte Reload
	mov.d	x24, v0[1]
	st1.b	{ v2 }[1], [x24]
	tbz	w4, #2, LBB0_142
LBB0_357:                               ; %cond.store668
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #512]                  ; 16-byte Reload
	fmov	x24, d0
	st1.b	{ v2 }[2], [x24]
	tbz	w4, #3, LBB0_143
LBB0_358:                               ; %cond.store672
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #512]                  ; 16-byte Reload
	mov.d	x24, v0[1]
	st1.b	{ v2 }[3], [x24]
	tbz	w4, #4, LBB0_144
LBB0_359:                               ; %cond.store676
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1104]                 ; 16-byte Reload
	fmov	x24, d0
	st1.b	{ v2 }[4], [x24]
	tbz	w4, #5, LBB0_145
LBB0_360:                               ; %cond.store680
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1104]                 ; 16-byte Reload
	mov.d	x24, v0[1]
	st1.b	{ v2 }[5], [x24]
	tbz	w4, #6, LBB0_146
LBB0_361:                               ; %cond.store684
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #1136]                 ; 16-byte Reload
	fmov	x24, d0
	st1.b	{ v2 }[6], [x24]
	tbnz	w4, #7, LBB0_147
	b	LBB0_148
LBB0_362:                               ; %cond.store693
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #368]                  ; 16-byte Reload
	fmov	x25, d0
	str	b2, [x25]
	and	w24, w24, #0xff
	ldr	x15, [sp, #3504]                ; 8-byte Reload
	tbz	w24, #1, LBB0_150
LBB0_363:                               ; %cond.store697
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #368]                  ; 16-byte Reload
	mov.d	x25, v0[1]
	st1.b	{ v2 }[1], [x25]
	tbz	w24, #2, LBB0_151
LBB0_364:                               ; %cond.store701
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #384]                  ; 16-byte Reload
	fmov	x25, d0
	st1.b	{ v2 }[2], [x25]
	tbz	w24, #3, LBB0_152
LBB0_365:                               ; %cond.store705
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #384]                  ; 16-byte Reload
	mov.d	x25, v0[1]
	st1.b	{ v2 }[3], [x25]
	tbz	w24, #4, LBB0_153
LBB0_366:                               ; %cond.store709
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #400]                  ; 16-byte Reload
	fmov	x25, d0
	st1.b	{ v2 }[4], [x25]
	tbz	w24, #5, LBB0_154
LBB0_367:                               ; %cond.store713
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #400]                  ; 16-byte Reload
	mov.d	x25, v0[1]
	st1.b	{ v2 }[5], [x25]
	tbz	w24, #6, LBB0_155
LBB0_368:                               ; %cond.store717
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #416]                  ; 16-byte Reload
	fmov	x25, d0
	st1.b	{ v2 }[6], [x25]
	tbz	w24, #7, LBB0_156
LBB0_369:                               ; %cond.store721
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #416]                  ; 16-byte Reload
	mov.d	x24, v0[1]
	st1.b	{ v2 }[7], [x24]
	orr	x24, x16, #0xe
	cmp	x24, #129
	cset	w27, lo
	fmov	w25, s30
	dup.8b	v2, w27
	tbz	w25, #0, LBB0_157
LBB0_370:                               ; %cond.store726
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #304]                  ; 16-byte Reload
	fmov	x27, d0
	str	b2, [x27]
	and	w25, w25, #0xff
	tbz	w25, #1, LBB0_158
LBB0_371:                               ; %cond.store730
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #304]                  ; 16-byte Reload
	mov.d	x27, v0[1]
	st1.b	{ v2 }[1], [x27]
	tbz	w25, #2, LBB0_159
LBB0_372:                               ; %cond.store734
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #320]                  ; 16-byte Reload
	fmov	x27, d0
	st1.b	{ v2 }[2], [x27]
	tbz	w25, #3, LBB0_160
LBB0_373:                               ; %cond.store738
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #320]                  ; 16-byte Reload
	mov.d	x27, v0[1]
	st1.b	{ v2 }[3], [x27]
	tbz	w25, #4, LBB0_161
LBB0_374:                               ; %cond.store742
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #336]                  ; 16-byte Reload
	fmov	x27, d0
	st1.b	{ v2 }[4], [x27]
	tbz	w25, #5, LBB0_162
LBB0_375:                               ; %cond.store746
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #336]                  ; 16-byte Reload
	mov.d	x27, v0[1]
	st1.b	{ v2 }[5], [x27]
	tbz	w25, #6, LBB0_163
LBB0_376:                               ; %cond.store750
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #352]                  ; 16-byte Reload
	fmov	x27, d0
	st1.b	{ v2 }[6], [x27]
	tbz	w25, #7, LBB0_164
LBB0_377:                               ; %cond.store754
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #352]                  ; 16-byte Reload
	mov.d	x25, v0[1]
	st1.b	{ v2 }[7], [x25]
	orr	x25, x16, #0xf
	cmp	x25, #129
	cset	w28, lo
	fmov	w27, s30
	dup.8b	v2, w28
	tbz	w27, #0, LBB0_165
LBB0_378:                               ; %cond.store759
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #240]                  ; 16-byte Reload
	fmov	x28, d0
	str	b2, [x28]
	and	w27, w27, #0xff
	tbz	w27, #1, LBB0_166
LBB0_379:                               ; %cond.store763
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #240]                  ; 16-byte Reload
	mov.d	x28, v0[1]
	st1.b	{ v2 }[1], [x28]
	tbz	w27, #2, LBB0_167
LBB0_380:                               ; %cond.store767
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #256]                  ; 16-byte Reload
	fmov	x28, d0
	st1.b	{ v2 }[2], [x28]
	tbz	w27, #3, LBB0_168
LBB0_381:                               ; %cond.store771
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #256]                  ; 16-byte Reload
	mov.d	x28, v0[1]
	st1.b	{ v2 }[3], [x28]
	tbz	w27, #4, LBB0_169
LBB0_382:                               ; %cond.store775
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #272]                  ; 16-byte Reload
	fmov	x28, d0
	st1.b	{ v2 }[4], [x28]
	tbz	w27, #5, LBB0_170
LBB0_383:                               ; %cond.store779
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #272]                  ; 16-byte Reload
	mov.d	x28, v0[1]
	st1.b	{ v2 }[5], [x28]
	tbz	w27, #6, LBB0_171
LBB0_384:                               ; %cond.store783
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q0, [sp, #288]                  ; 16-byte Reload
	fmov	x28, d0
	st1.b	{ v2 }[6], [x28]
	sshll.2d	v3, v1, #0
	sshll.2d	v4, v13, #0
	tbnz	w27, #7, LBB0_172
	b	LBB0_173
LBB0_385:                               ; %direct.false210
	mov	x9, #0                          ; =0x0
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3200
	ldp	q26, q27, [x10]
	mov.16b	v25, v13
	bsl.16b	v25, v5, v27
	ldr	q4, [sp, #9408]                 ; 16-byte Reload
	mov.16b	v24, v1
	bsl.16b	v24, v4, v26
	stp	q24, q25, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3232
	ldp	q24, q25, [x10]
	mov.16b	v23, v13
	bsl.16b	v23, v3, v25
	ldr	q3, [sp, #9424]                 ; 16-byte Reload
	mov.16b	v22, v1
	bsl.16b	v22, v3, v24
	stp	q22, q23, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3264
	ldp	q22, q23, [x10]
	mov.16b	v21, v13
	bsl.16b	v21, v0, v23
	ldr	q0, [sp, #9456]                 ; 16-byte Reload
	mov.16b	v20, v1
	bsl.16b	v20, v0, v22
	stp	q20, q21, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3296
	ldp	q20, q21, [x10]
	mov.16b	v19, v13
	bsl.16b	v19, v16, v21
	mov.16b	v18, v1
	bsl.16b	v18, v14, v20
	stp	q18, q19, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3328
	ldp	q18, q19, [x10]
	bif.16b	v17, v19, v13
	mov.16b	v16, v1
	bsl.16b	v16, v15, v18
	stp	q16, q17, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3360
	ldp	q16, q17, [x10]
	mov.16b	v7, v13
	bsl.16b	v7, v6, v17
	mov.16b	v6, v1
	bsl.16b	v6, v2, v16
	stp	q6, q7, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x10, x10, #3392
	ldp	q6, q7, [x10]
	mov.16b	v5, v13
	bsl.16b	v5, v30, v7
	mov.16b	v4, v1
	bsl.16b	v4, v29, v6
	stp	q4, q5, [x10]
	add	x10, x11, #24, lsl #12          ; =98304
	add	x11, x10, #3424
	ldp	q4, q5, [x11]
	mov.16b	v3, v13
	bsl.16b	v3, v31, v5
	mov.16b	v2, v1
	bsl.16b	v2, v8, v4
	mov	w10, #43691                     ; =0xaaab
	stp	q2, q3, [x11]
	mov	w11, #48                        ; =0x30
	ldp	x17, x16, [sp, #64]             ; 16-byte Folded Reload
	ldr	q17, [sp, #3552]                ; 16-byte Reload
	ldp	q19, q18, [sp, #32]             ; 32-byte Folded Reload
	ldr	q20, [sp, #16]                  ; 16-byte Reload
	b	LBB0_387
LBB0_386:                               ; %else1003
                                        ;   in Loop: Header=BB0_387 Depth=1
	add	x9, x9, #1
	cmp	x9, #384
	b.eq	LBB0_403
LBB0_387:                               ; %direct.true2109
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w12, s17
	and	w13, w9, #0xffff
	mul	w13, w13, w10
	lsr	w13, w13, #21
	dup.2d	v2, x13
	add.2d	v0, v12, v2
	mov.d	x14, v0[1]
	fmov	x15, d0
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d0, x15
	msub	w15, w13, w11, w9
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	mov.d	v0[1], x14
	and	x14, x15, #0xffff
	dup.2d	v3, x14
	add.2d	v0, v0, v3
	umaddl	x14, w13, w11, x14
	add	x14, x8, x14, lsl #5
	ldp	q4, q5, [x14]
	and.16b	v4, v1, v4
	add	x13, x16, x13, lsl #5
	ldp	q7, q6, [x13]
	and.16b	v7, v1, v7
	fdiv.4s	v7, v4, v7
	shl.2d	v0, v0, #2
	dup.2d	v4, x17
	add.2d	v16, v4, v0
	tbz	w12, #0, LBB0_389
; %bb.388:                              ; %cond.store972
                                        ;   in Loop: Header=BB0_387 Depth=1
	fmov	x13, d16
	str	s7, [x13]
LBB0_389:                               ; %else975
                                        ;   in Loop: Header=BB0_387 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_391
; %bb.390:                              ; %cond.store976
                                        ;   in Loop: Header=BB0_387 Depth=1
	mov.d	x13, v16[1]
	st1.s	{ v7 }[1], [x13]
LBB0_391:                               ; %else979
                                        ;   in Loop: Header=BB0_387 Depth=1
	add.2d	v0, v20, v2
	mov.d	x13, v0[1]
	fmov	x14, d0
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d0, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	mov.d	v0[1], x13
	add.2d	v0, v0, v3
	shl.2d	v0, v0, #2
	add.2d	v16, v4, v0
	tbz	w12, #2, LBB0_393
; %bb.392:                              ; %cond.store980
                                        ;   in Loop: Header=BB0_387 Depth=1
	fmov	x13, d16
	st1.s	{ v7 }[2], [x13]
LBB0_393:                               ; %else983
                                        ;   in Loop: Header=BB0_387 Depth=1
	tbz	w12, #3, LBB0_395
; %bb.394:                              ; %cond.store984
                                        ;   in Loop: Header=BB0_387 Depth=1
	mov.d	x13, v16[1]
	st1.s	{ v7 }[3], [x13]
LBB0_395:                               ; %else987
                                        ;   in Loop: Header=BB0_387 Depth=1
	add.2d	v0, v18, v2
	mov.d	x13, v0[1]
	fmov	x14, d0
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d0, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	mov.d	v0[1], x13
	add.2d	v0, v0, v3
	and.16b	v5, v13, v5
	and.16b	v6, v13, v6
	fdiv.4s	v5, v5, v6
	shl.2d	v0, v0, #2
	add.2d	v6, v4, v0
	tbz	w12, #4, LBB0_397
; %bb.396:                              ; %cond.store988
                                        ;   in Loop: Header=BB0_387 Depth=1
	fmov	x13, d6
	str	s5, [x13]
LBB0_397:                               ; %else991
                                        ;   in Loop: Header=BB0_387 Depth=1
	tbz	w12, #5, LBB0_399
; %bb.398:                              ; %cond.store992
                                        ;   in Loop: Header=BB0_387 Depth=1
	mov.d	x13, v6[1]
	st1.s	{ v5 }[1], [x13]
LBB0_399:                               ; %else995
                                        ;   in Loop: Header=BB0_387 Depth=1
	add.2d	v0, v19, v2
	mov.d	x13, v0[1]
	fmov	x14, d0
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d0, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	mov.d	v0[1], x13
	add.2d	v0, v0, v3
	shl.2d	v0, v0, #2
	add.2d	v2, v4, v0
	tbnz	w12, #6, LBB0_401
; %bb.400:                              ; %else999
                                        ;   in Loop: Header=BB0_387 Depth=1
	tbz	w12, #7, LBB0_386
	b	LBB0_402
LBB0_401:                               ; %cond.store996
                                        ;   in Loop: Header=BB0_387 Depth=1
	fmov	x13, d2
	st1.s	{ v5 }[2], [x13]
	tbz	w12, #7, LBB0_386
LBB0_402:                               ; %cond.store1000
                                        ;   in Loop: Header=BB0_387 Depth=1
	mov.d	x12, v2[1]
	st1.s	{ v5 }[3], [x12]
	b	LBB0_386
LBB0_403:                               ; %common.ret
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #1344
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh137, Lloh138
	.loh AdrpLdr	Lloh136, Lloh141
	.loh AdrpLdr	Lloh135, Lloh140
	.loh AdrpLdr	Lloh134, Lloh139
	.loh AdrpAdrp	Lloh132, Lloh134
	.loh AdrpLdr	Lloh132, Lloh133
	.loh AdrpAdrp	Lloh130, Lloh132
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpAdrp	Lloh128, Lloh130
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpAdrp	Lloh126, Lloh128
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpAdrp	Lloh124, Lloh126
	.loh AdrpLdr	Lloh124, Lloh125
	.loh AdrpAdrp	Lloh122, Lloh124
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpAdrp	Lloh120, Lloh122
	.loh AdrpLdr	Lloh120, Lloh121
	.loh AdrpAdrp	Lloh118, Lloh120
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpAdrp	Lloh116, Lloh118
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpAdrp	Lloh114, Lloh116
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpAdrp	Lloh112, Lloh114
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpAdrp	Lloh110, Lloh112
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpAdrp	Lloh106, Lloh136
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpAdrp	Lloh105, Lloh135
	.loh AdrpLdr	Lloh105, Lloh109
	.loh AdrpAdrp	Lloh104, Lloh110
	.loh AdrpLdr	Lloh104, Lloh108
	.loh AdrpAdrp	Lloh102, Lloh104
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpAdrp	Lloh100, Lloh102
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpAdrp	Lloh98, Lloh100
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

"""Fixed-BQ block-mapping experiment; no compiler policy change or GPU overlap."""
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent
BUILD = Path('/Users/mike/.cache/luisa-tile/metal-next.6pECu2/build')
SELECTED = Path('/Users/mike/.cache/luisa-tile/metal-next.6pECu2/source')
HELPERS = ROOT / 'scripts/benchmark/tile_torch'
sys.path.insert(0, str(HELPERS))
from compare_llm import capture_benchmark, record_process_output

CASES = [
    ('attention-small-q4', 'attention', (1, 4, 2, 16, 33, 32, 32), (4, 16), 16, 32),
    ('attention-small-q1', 'attention', (1, 4, 2, 16, 33, 32, 32), (1, 16), 64, 64),
    ('attention-prefill-q4', 'attention', (1, 4, 2, 64, 128, 64, 64), (4, 16), 64, 64),
    ('attention-prefill-q1', 'attention', (1, 4, 2, 64, 128, 64, 64), (1, 16), 256, 256),
    ('rmsnorm-tail', 'rmsnorm', (257, 1025), (1, 1), 257, 256),
    ('swiglu-wide-grid', 'swiglu', (8192, 65), (1, 1), 8192, 256),
]
ORDER = [0, 32, 32, 0] * 2


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def capture_host(command, environment, timeout, directory, receipt):
    """Host build/checks: retain GPU-pattern matches, but use process status.

    Not used for native benchmarks. A path such as metal-next/.../error.c
    in a compiler warning is not evidence of a GPU command-buffer failure.
    """
    process = subprocess.Popen(command, env=environment, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    try:
        stdout, stderr = process.communicate(timeout=timeout)
    except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        stdout, stderr = process.communicate()
        record_process_output(directory, 'process', stdout, stderr, receipt,
                              dict(exit_code=process.returncode, timed_out=isinstance(error, subprocess.TimeoutExpired)))
        raise
    record_process_output(directory, 'process', stdout, stderr, receipt,
                          dict(exit_code=process.returncode, timed_out=False))
    result = subprocess.CompletedProcess(command, process.returncode, stdout, stderr)
    result.check_returncode()
    return result


def run(name, command, timeout, *, host_only=False):
    folder = OUT / name
    folder.mkdir()
    env = {k: v for k, v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_', 'DYLD_'))}
    env.update(PYTORCH_ENABLE_MPS_FALLBACK='0', OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
    receipt = dict(command=command, cwd=os.getcwd(), started=time.time(), timeout_seconds=timeout, host_only=host_only,
                   source_sha256={str(p): sha(p) for p in (Path(__file__), HELPERS / 'compare_llm.py', HELPERS / 'run.py')},
                   environment={k: v for k, v in env.items() if k.startswith(('LUISA_', 'MTL_', 'DYLD_', 'PYTORCH_', 'OMP_', 'VECLIB_'))})
    save(folder / 'command.json', receipt)
    try:
        result = (capture_host(command, env, timeout, folder, receipt) if host_only else
                  capture_benchmark(command, env, timeout, folder, 'process', receipt))
        receipt.update(status='passed', finished=time.time())
        save(folder / 'result.json', receipt)
        print(name, 'passed', flush=True)
        return result.stdout
    except BaseException as error:
        receipt.update(status='failed', finished=time.time(), error=str(error))
        save(folder / 'result.json', receipt)
        raise


def field(realization, name):
    values = re.findall(r'(?:^|;)\s*' + re.escape(name) + r'=([^;]+)', realization)
    assert len(values) == 1, (name, realization)
    return values[0]


def main():
    if sys.argv[1] == 'configure':
        run('configure-head', ['cmake', '-S', str(SELECTED), '-B', str(BUILD), '-G', 'Ninja',
            '-DCMAKE_BUILD_TYPE=RelWithDebInfo', '-DCMAKE_C_COMPILER=/usr/bin/cc', '-DCMAKE_CXX_COMPILER=/usr/bin/c++',
            '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DCMAKE_OSX_DEPLOYMENT_TARGET=13',
            '-DLUISA_COMPUTE_ENABLE_GUI=OFF', '-DLUISA_COMPUTE_ENABLE_CUDA=OFF', '-DLUISA_COMPUTE_ENABLE_DX=OFF',
            '-DLUISA_COMPUTE_ENABLE_VULKAN=OFF', '-DLUISA_COMPUTE_ENABLE_FALLBACK=OFF',
            '-DLUISA_COMPUTE_ENABLE_METAL=ON', '-DLUISA_COMPUTE_ENABLE_METAL4=ON', '-DLUISA_COMPUTE_ENABLE_SIMD=ON',
            '-DLUISA_COMPUTE_BUILD_TESTS=ON', '-DLUISA_COMPUTE_ENABLE_TILE_TIRX_BRIDGE=ON',
            '-DLLVM_DIR=/opt/homebrew/opt/llvm@22/lib/cmake/llvm',
            '-DLUISA_COMPUTE_TVM_INCLUDE_DIR=/Users/mike/.cache/luisa-tile/tvm-pinned.9TMqn1/include',
            '-DLUISA_COMPUTE_TVM_FFI_INCLUDE_DIR=/Users/mike/.cache/luisa-tile/tvm-pinned.9TMqn1/3rdparty/tvm-ffi/include',
            '-DLUISA_COMPUTE_TVM_LIBRARY_DIR=/Users/mike/.cache/luisa-tile/tvm-fragment-build.0ToXYr/lib',
            '-DLUISA_COMPUTE_TVM_FFI_LIBRARY_DIR=/Users/mike/.cache/luisa-tile/tvm-fragment-build.0ToXYr/lib'], 300, host_only=True)
        return
    if sys.argv[1] == 'build':
        run('build-head-confirm', ['cmake', '--build', str(BUILD), '-j', '6'], 1800, host_only=True)
        return
    assert sys.argv[1] == 'probe'
    assert json.loads((OUT / 'build-head-confirm/result.json').read_text())['status'] == 'passed'
    run('power-assertions', ['pmset', '-g', 'assertions'], 5, host_only=True)
    old = json.loads(Path('/tmp/luisa-metal-attention-recovery.5MPxs3/native-provenance.json').read_text())
    old_source = Path(old['selected_source'])
    selected = {str(SELECTED / Path(p).relative_to(old_source)): sha(SELECTED / Path(p).relative_to(old_source))
                for p in old['files_sha256'] if Path(p).is_relative_to(old_source)}
    assert selected
    exported = json.loads((OUT / 'source-export.json').read_text())
    assert exported['exports'][0]['commit'].startswith('b21d33053')
    artifacts = [p for p in (BUILD / 'bin').iterdir() if p.is_file() and (p.suffix in ('.dylib', '.so') or p.name == 'benchmark_tile_xir')]
    helper_paths = [HELPERS / p for p in ('metal4_timing.py', 'compare_llm.py', 'run.py', 'repeat.py')]
    frozen = {str(p): sha(p) for p in [Path(__file__), *helper_paths, *artifacts]}
    save(OUT / 'plan.json', dict(started=time.time(), source_head='b21d33053', selected_source=str(SELECTED),
        selected_source_sha256=selected, frozen_sha256=frozen, cases=CASES, block_order=ORDER,
        samples=3, repetitions=8, local_lanes=1, math='FP32, fast_math=false, QK/PV MMA',
        purpose='Fixed BQ/IR: automatic block packing versus pinned block32; two ABBA cycles per case, no timing-based candidate selection',
        boundary='Fresh committed HEAD source and pinned recursive submodule exports; excludes protected worktree WIP. Instrumented dispatch, feedback-only CB and host wall remain separate. No cross-framework comparison.'))
    rows, inputs, outputs, structures, checksums = [], {}, {}, {}, {}
    for case, op, dims, tile, dispatch, auto_block in CASES:
        for position, requested in enumerate(ORDER):
            tag = f'{case}-{position}-block{requested}'
            output = OUT / tag / 'cohort'
            command = [sys.executable, str(helper_paths[0]), '--binary', str(BUILD / 'bin/benchmark_tile_xir'),
                       '--case', op + ':' + ','.join(map(str, dims)), '--attention-block', *map(str, tile),
                       '--local-lanes', '1', '--block-size', str(requested), '--rounds', '1',
                       '--samples', '3', '--repetitions', '8', '--timeout', '60', '--output', str(output)]
            try:
                assert all(sha(p) == expected for p, expected in frozen.items())
                run(tag, command, 75)
                report = json.loads((output / 'results.json').read_text())
                assert report['cohort_valid'] and report['artifacts_unchanged'] and len(report['results']) == 1
                row = report['results'][0]
                assert row['valid'] and row['actual_local_lanes'] == 1
                payload = json.loads((output / row['stdout']).read_text())
                actual = requested or auto_block
                assert payload['dispatch'] == [dispatch, 1, 1]
                assert row['requested_block_size'] == requested and row['actual_block_size'] == actual
                sample = payload['device_timing']['throughput'][0]['dispatches'][0]
                assert sample['block_size'] == [actual, 1, 1]
                assert checksums.setdefault((case, actual), sample['shader_checksum']) == sample['shader_checksum']
                tensor = row['command'][-1]
                in_hashes = [row['tensor_receipts'][tensor + f'.input{i}.f32']['sha256'] for i in range(3)]
                assert inputs.setdefault((op, dims), in_hashes) == in_hashes
                out_hash = row['tensor_receipts'][tensor]['sha256']
                assert outputs.setdefault(case, out_hash) == out_hash
                keys = ('local_lanes', 'static_snapshot_bytes_per_worker', 'static_snapshot_allocations',
                        'max_unrolled_tile_elements', 'max_unrolled_region_work', 'unordered_reduction_partitions',
                        'fused_reduction_loads', 'fused_reduction_expressions', 'fused_pointwise_regions',
                        'deferred_maps', 'blocked_mmas', 'two_dimensional_mmas', 'rolled_mmas',
                        'fast_math', 'ordered_reduction', 'strict_mma')
                structure = {key: field(row['realization'], key) for key in keys}
                order = re.findall(r'; root order (\[[^]]*\])', row['realization'])
                assert len(order) == 1
                structure['root_order'] = order[0]
                assert structures.setdefault(case, structure) == structure
                rows.append(dict(case=case, position=position, requested_block=requested, actual_block=actual,
                                 dispatch=dispatch, threadgroups=(dispatch + actual - 1) // actual,
                                 result=tag + '/cohort/results.json', metrics=row['metrics'], structure=structure,
                                 checksum=sample['shader_checksum'], output_sha256=out_hash))
                print(json.dumps(dict(case=case, position=position, actual_block=actual, threadgroups=rows[-1]['threadgroups'],
                      precise_us=row['metrics']['throughput_instrumented_dispatch_ns']['median']/1000,
                      control_us=row['metrics']['throughput_feedback_only_command_buffer_ns_per_dispatch']['median']/1000)), flush=True)
            except BaseException as error:
                save(OUT / 'failure.json', dict(status='incomplete', case=case, position=position,
                                              error=str(error), completed=rows))
                raise
    assert all(sha(p) == expected for p, expected in frozen.items())
    assert all(sha(p) == expected for p, expected in selected.items())
    save(OUT / 'results.json', dict(status='complete', finished=time.time(), rows=rows, artifacts_unchanged=True))


if __name__ == '__main__':
    main()

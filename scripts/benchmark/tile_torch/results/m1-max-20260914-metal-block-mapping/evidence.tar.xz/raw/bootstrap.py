"""Recreate an exact committed source snapshot in a persistent task cache.

No user working-tree edits or submodule updates: export each pinned git tree
from already available local objects. Fail if a required object is missing.
"""
import io
import json
from pathlib import Path
import subprocess
import tarfile
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
TASK = Path('/Users/mike/.cache/luisa-tile/metal-next.6pECu2')
OUT = Path(__file__).resolve().parent
COMMIT = 'b21d33053'


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])


def export(repo, revision, destination, records):
    commit = git(repo, 'rev-parse', revision + '^{commit}').decode().strip()
    destination.mkdir(parents=True, exist_ok=True)
    archive = git(repo, 'archive', '--format=tar', commit)
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:') as stream:
        stream.extractall(destination, filter='data')
    records.append(dict(repository=str(repo), commit=commit, destination=str(destination)))
    for entry in git(repo, 'ls-tree', '-r', '-z', commit).split(b'\0'):
        if entry.startswith(b'160000 '):
            metadata, path = entry.decode().split('\t', 1)
            export(repo / path, metadata.split()[2], destination / path, records)


if __name__ == '__main__':
    assert not (TASK / 'source').exists()
    started, records = time.time(), []
    export(ROOT, COMMIT, TASK / 'source', records)
    with (OUT / 'source-export.json').open('x') as stream:
        json.dump(dict(started=started, finished=time.time(), exports=records,
                       boundary='Committed main and recursive submodule trees only; user WIP untouched; not copied from expired temporary source.'), stream, indent=2)
    print(json.dumps(dict(status='exported', root=str(TASK / 'source'), git_trees=len(records))))

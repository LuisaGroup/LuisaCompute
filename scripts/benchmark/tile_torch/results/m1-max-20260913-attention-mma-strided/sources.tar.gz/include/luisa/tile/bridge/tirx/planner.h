#pragma once

#include <cstdint>

#include <luisa/core/dll_export.h>
#include <luisa/core/stl/string.h>
#include <luisa/core/stl/vector.h>

namespace luisa::compute::tile::bridge::tirx {

class ExecutionCostPolicy;

enum class MatrixCostBasis : uint8_t {
    SIMDGROUP_REFERENCE,
    METAL_MPP_MEMORY,
};

// Relative issue-work coefficients, NOT measured nanoseconds or a promise of
// occupancy. Device calibration can replace these priors without changing
// candidate legality or the solver. Unknown register allocation is represented
// by live fragment scalars, never reported as a measured hardware register count.
struct ExecutionCostModel {
    double matrix_issue{1.0};
    double shared_fragment_transfer{2.0};
    double independent_element{0.0078125};
    double subgroup_setup{8.0};
    // Metal reduction planner v1 scores discrete SIMD-group
    // realizations in abstract issue rounds. The first term prices one scalar
    // stripe round, the second prices each reduction collective per
    // participating SIMD-group, and the third prices a cooperative
    // threadgroup. One-group programs amortize the latter when several
    // independent logical programs share a threadgroup.
    double subgroup_reduction_scalar_round{1.0};
    double subgroup_reduction_collective{2.0};
    double subgroup_reduction_group_setup{16.0};
    // Optional resource-service terms for the distributed payload. Zero
    // preserves the historical round prior until a backend calibrates them.
    // Input is IR access bytes, NOT DRAM traffic or physical register spills.
    double subgroup_reduction_global_access_byte{0.0};
    double subgroup_reduction_private_access_byte{0.0};
    // MPP reads A/B from memory inside each tensor operation. These terms are
    // expressed in logical 8x8 fragments. The footprint terms distinguish the
    // two row-major operands without pretending to be byte-accurate cache
    // traffic; the aspect terms are versioned target priors for MPP descriptor
    // and subgroup-grid shape. Correctness-checked JIT data may replace them.
    double metal_mpp_memory_fragment{1.0};
    double metal_mpp_lhs_footprint{0.125};
    double metal_mpp_rhs_footprint{0.375};
    double metal_mpp_output_fragment{1.0};
    double metal_mpp_tensor_operation{8.0};
    double metal_mpp_accumulator_init{1.0};
    double metal_mpp_tile_aspect{0.1875};
    double metal_mpp_local_row_aspect{0.25};
    double metal_mpp_local_column_aspect{0.125};
    // Non-matrix element work is divided across the participating subgroups.
    // One logical unit therefore represents one scalar per subgroup lane.
    double metal_mpp_independent_element{0.03125};
    // Fixed critical-path prior for entering one cooperative MPP program.
    double metal_mpp_group_setup{8.0};
    uint32_t preferred_subgroups{4u};
    uint32_t preferred_fragment_scalars_per_lane{32u};
    // Reference-realization latency-wave prior for independent programs.
    uint32_t preferred_concurrent_programs{64u};
    // MPP v2 uses subgroup demand rather than pretending that 64-, 128-, and
    // 256-thread programs consume the same machine capacity. This M1-class
    // prior is deliberately replaceable by a calibrated target profile; it is
    // not a queried occupancy limit or a portable hardware fact.
    uint32_t metal_mpp_concurrent_subgroups{512u};
};

struct PlannerOptions {
    // Automatic CPU roots below this many independent tasks stay serial to
    // avoid paying the TVM thread-pool launch cost. Explicit worker bindings
    // remain hard constraints. One preserves the always-parallel policy.
    uint32_t min_cpu_parallel_tasks{64u};
    // Opt-in LLVM storage realization. At most this many bytes of compact,
    // nonescaping compiler temporaries become stack allocations per PrimFunc
    // (including alignment padding). Valid range is [0,65536]. Zero, or a
    // disabled planner, retains TVM workspace allocation.
    // This is not a bound on LLVM spills or user/TVM-owned stack objects.
    uint32_t max_cpu_stack_bytes{0u};
    // Logical SIMD-pack budget, not a hardware vector width/register count.
    // Sixteen retains single-row packing. Larger powers of two (up to 128)
    // may combine adjacent independent rows while preserving each element's
    // serial recurrence. Requires CPU auto-vectorization when non-default.
    uint32_t max_cpu_vector_lanes{16u};
    bool enabled{true};
    // Fuse an automatic root program with its sole independent element map.
    // Requires immutable input forwarding and disjoint output effects. This
    // is a physical mapping choice; explicit worker/group bindings stay exact.
    bool fuse_gpu_elementwise{true};
    // Admit automatic, ordered Tile programs containing matrix work to the
    // existing cooperative resource/distribution planner. Parallel and Tile
    // element independence are language contracts, not facts to rediscover.
    // Unsupported effects/placements or insufficient resources retain the
    // worker realization; explicit execution bindings remain exact.
    bool map_gpu_cooperative_programs{true};
    // Opt-in Metal realization for proved FP32 add/max/min reductions.
    // Independent short programs may share one threadgroup; wider programs
    // search every whole-SIMD-group width within the target limit and the
    // two-level collective's capacity (at most 32 subgroups). Element domains
    // are striped over workers and reducers use native collectives plus proved
    // shared partials when necessary. This only enables the candidate family;
    // each reduction must independently grant unordered-tree permission and
    // pass the compatible-merge matcher. An ordered tree or explicit fold is
    // never widened by this switch. The language default is unordered_tree;
    // target availability/noalias contracts are still explicit here.
    bool metal_subgroup_reductions{false};
    // Zero retains the automatic family's incumbent (packing only single-
    // subgroup programs). Nonzero fixes independent logical programs per
    // group; threads_per_group is the TOTAL physical group width and must be
    // divisible by programs * subgroup size. Each program can use several
    // subgroups with isolated partials and a proved uniform fence sequence.
    // With no exact thread count, search all fitting cooperating widths.
    uint32_t reduction_programs_per_group{0u};
    // Partial unrolling of each worker's ordered stripe. Does not introduce
    // independent accumulators or change its floating-point recurrence order.
    // A bounded code-size choice, not a hardware vector-width promise.
    uint32_t reduction_unroll_factor{1u};
    // Consecutive logical elements owned by one worker before advancing to
    // the next worker (1, 2, 4 or 8). An ownership layout, not a vector ISA
    // guarantee. Non-default widths require the reduction-tree permission.
    uint32_t reduction_lane_elements{1u};
    // Opt-in retention of proved immutable input snapshots reused by distinct
    // element/reduction domains. The reduction mapper must prove same-worker
    // ownership and charge the existing private-stripe budget. Repeated reads
    // within one domain alone do not request a cache. Requires subgroup
    // reductions; an unrealizable request fails instead of changing mappings.
    bool cache_reduction_inputs{false};
    bool retain_accumulators{true};
    // Elide the initial/final shared accumulator only when its literal fill
    // and sole, fully in-bounds global store have been proved by analysis.
    bool direct_accumulator_store{true};
    // Merge compiler-inserted group barriers only across independent effects.
    // Retain loop-boundary fences unless the independent-subgroup option below
    // is also selected. Explicit/unknown synchronization is never removed.
    bool coalesce_group_barriers{true};
    // A profitability choice, not permission to assume independence. Requires
    // a whole-group proof of private subgroup programs and one terminal store.
    // Default off: even redundant fences can improve cache/issue scheduling.
    bool elide_independent_subgroup_barriers{false};
    // Zero lets the solver choose. A nonzero value is an exact tuning
    // constraint, checked against the target before any code is generated.
    uint32_t threads_per_group{0u};
    // Opt-in bijective traversal of the last two logical program axes.
    // Independent Metal group programs visit bounded row-major rectangles;
    // outer batch axes, launch cardinality and worker ownership are unchanged.
    // These are exact JIT constraints, not calibrated cache/occupancy costs.
    // One row retains the original row-major traversal. Both sizes are positive.
    uint32_t program_order_rows{1u};
    uint32_t program_order_columns{1u};
    // Opt-in closed scalar DAGs in MPP output fragments. A legality proof is
    // not a profitability proof; retain the established path until calibrated
    // cost policies or measured JIT selection choose this candidate.
    bool fuse_matrix_epilogues{false};
    // A compiler search/code-size budget, not a claimed hardware register limit.
    uint32_t max_fragment_scalars_per_lane{64u};
    // Bound compiler-created worker-private stripes for one logical row
    // program. This is a software-state budget, not a hardware register count:
    // the final backend may keep, spill, or scalarize these values. Candidates
    // above the limit are rejected before code generation so wide reused Tiles
    // cannot silently create pathological per-thread arrays.
    uint32_t max_reduction_striped_scalars_per_worker{64u};
    // Bound compilation work independently of target capacity. If an automatic
    // search would exceed this many widths, require a larger budget or an exact
    // thread count instead of silently truncating the supposedly exact search.
    uint32_t max_thread_candidates{32u};
    // Maximum independent values loaded before their stores in a cooperative
    // copy. One retains the scalar load/store sequence; no async engine or
    // vector-alignment promise is implied. The emitter checks each domain.
    uint32_t max_copy_batch{1u};
    // Bound worker-private software-prefetch storage, not hardware registers.
    // Zero disables late prefetching; pipeline window one is always ordered.
    uint32_t max_pipeline_prefetch_scalars_per_lane{32u};
    ExecutionCostModel cost;
    // Borrowed for synchronous planning/compilation only; never retained in a
    // shader or serialized. The backend owns device calibration and policy.
    const ExecutionCostPolicy *cost_policy{nullptr};
};

struct ExecutionLimits {
    uint32_t max_threads{256u};
    uint32_t subgroup_size{32u};
    uint64_t shared_memory_bytes{0u};
};

// Source-level payload access demand: identical loads are counted once per
// statement/expression, never across statements or traversals. Both lazy
// branches are included conservatively; scalar setup/collectives are excluded.
// These are logical access bytes, not cache-line transactions or emitted ISA.
struct ReductionAccessDemand {
    double global_read_bytes{0.0};
    double global_write_bytes{0.0};
    double private_read_bytes{0.0};
    double private_write_bytes{0.0};
};

struct ReductionCandidate {
    uint64_t programs{0u};
    uint32_t threads{0u};
    uint32_t subgroups_per_program{0u};
    uint32_t programs_per_group{0u};
    uint64_t shared_memory_bytes{0u};
    uint64_t striped_scalars_per_worker{0u};
    uint64_t reductions{0u};
    double scalar_rounds{0.0};
    uint32_t unroll_factor{1u};
    uint32_t lane_elements{1u};
    // Exact launch/ownership features, not measured occupancy. Packed tails
    // may leave some programs inactive in the last physical threadgroup.
    uint64_t threadgroups{0u};
    // Sum over separately distributed domains (including reduction inputs).
    // Dividing by scalar_rounds * cooperating workers gives useful lane work
    // relative to the maximum per-worker scalar recurrence length.
    double scalar_elements{0.0};
    double lane_utilization{0.0};
    bool payload_accesses_known{false};
    ReductionAccessDemand payload_accesses_per_program;
    // Sum of the longest worker stripe's demand for each distributed domain.
    // Domains are rounded independently, using this candidate's ownership map.
    ReductionAccessDemand payload_accesses_per_worker;
};

// The solver minimizes kernel_score, not program_score. A backend may combine
// the local critical path with whole-launch service demands; the final score
// need not equal program_score * concurrent_waves. Waves are a model feature,
// never a measurement of hardware residency.
struct ReductionCost {
    double program_score{0.0};
    double concurrent_waves{1.0};
    double kernel_score{0.0};
};

// Bridge-owned proofs and candidate generation precede these read-only
// profitability hooks. Hard device limits and numerical permissions are not
// overridable by a score. No TVM types, RTTI or cross-module ownership.
class LUISA_TILE_TIRX_BRIDGE_API ExecutionCostPolicy {
public:
    virtual ~ExecutionCostPolicy() noexcept = default;
    [[nodiscard]] virtual ExecutionCostModel coefficients(
        const ExecutionLimits &limits, MatrixCostBasis basis,
        const ExecutionCostModel &prior) const noexcept = 0;
    [[nodiscard]] virtual double reduction_score(
        const ReductionCandidate &candidate, const ExecutionCostModel &model) const noexcept = 0;
    // The compatibility implementation applies the historical program-wave
    // prior to reduction_score(). Override this hook for a machine objective;
    // the bridge will not multiply the returned kernel score a second time.
    [[nodiscard]] virtual ReductionCost reduction_cost(
        const ReductionCandidate &candidate, const ExecutionCostModel &model) const noexcept;
};

// Existing deterministic prior. Backends can inherit and override either
// calibration or the complete row-program objective independently of search.
class LUISA_TILE_TIRX_BRIDGE_API AnalyticExecutionCostPolicy : public ExecutionCostPolicy {
public:
    [[nodiscard]] ExecutionCostModel coefficients(
        const ExecutionLimits &, MatrixCostBasis, const ExecutionCostModel &prior) const noexcept override { return prior; }
    [[nodiscard]] double reduction_score(
        const ReductionCandidate &candidate, const ExecutionCostModel &model) const noexcept override;
};

// Optional backend-calibrated service model. All coefficients share the
// caller's score units (e.g. fitted microseconds); none are hardware facts.
// Byte inputs are conservative IR demand, not measured DRAM/register traffic.
struct ReductionServiceModel {
    uint32_t concurrent_subgroups{0u};
    double dispatch{0.0};
    double scalar_round{0.0};
    double collective{0.0};
    double global_program_byte{0.0};
    double global_worker_byte{0.0};
    double private_worker_byte{0.0};
};

class LUISA_TILE_TIRX_BRIDGE_API ServiceExecutionCostPolicy : public AnalyticExecutionCostPolicy {
private:
    ReductionServiceModel _model;

public:
    explicit ServiceExecutionCostPolicy(ReductionServiceModel model) noexcept : _model{model} {}
    [[nodiscard]] bool valid() const noexcept;
    [[nodiscard]] ReductionCost reduction_cost(
        const ReductionCandidate &candidate, const ExecutionCostModel &model) const noexcept override;
};

struct MatrixWorkload {
    uint64_t rows{0u};
    uint64_t columns{0u};
    uint64_t contraction{0u};
    uint64_t executions{1u};
    // A proved closed recurrence: C -> MMA -> D -> yield C, with no other
    // observation of C/D inside this many loop iterations. Zero disables it.
    uint64_t accumulator_iterations{0u};
    bool has_direct_output{false};
    // A literal positive-zero MMA, or a proved one-iteration positive-zero
    // recurrence whose direct output may use MPP's D=A*B mode.
    bool overwrites_accumulator{false};
    // Mean positive physical K over the static execution domain, derived
    // from the same bounded input expression emitted by MPP. Zero means
    // unknown/use nominal contraction. This cost fact never grants legality.
    double mean_contraction{0.0};
    // Disjoint subsets of GroupWorkload::independent_elements. The closed
    // recurrence removes its yield copy; direct output also replaces the
    // initial fill and scalar sink. Charge each subset unless that candidate
    // actually performs the corresponding realization.
    uint64_t recurrence_elements{0u};
    uint64_t direct_output_elements{0u};
    // Additional, disjoint compiler-owned scalar-DAG storage. It disappears
    // only with direct output; its arithmetic is still independent work.
    uint64_t epilogue_storage_bytes{0u};
};

struct GroupWorkload {
    uint64_t programs{0u};
    uint64_t independent_elements{0u};
    uint64_t max_independent_elements{1u};
    uint64_t shared_memory_bytes{0u};
    luisa::vector<MatrixWorkload> matrices;
    // Largest independently owned output domain of an admitted one-subgroup
    // collective. This is a realization width requirement, not a prediction
    // that collective execution is faster than a serial fold.
    uint64_t max_collective_outputs{0u};
};

struct MatrixDistribution {
    // A zero subgroup grid selects the existing one-atom-at-a-time reference
    // realization, including uniform subgroup tails. Otherwise the exact map is
    // (sg_m * atom_rows + local_m, sg_n * atom_columns + local_n).
    uint32_t subgroups_m{0u};
    uint32_t subgroups_n{0u};
    uint64_t atom_rows{1u};
    uint64_t atom_columns{1u};
    bool persistent_accumulator{false};
    bool direct_accumulator_store{false};

    [[nodiscard]] bool rectangular() const noexcept { return subgroups_m != 0u && subgroups_n != 0u; }
};

struct PlanCost {
    double matrix_issues{0.0};
    double nominal_matrix_issues{0.0};
    double shared_fragment_transfers{0.0};
    double direct_fragment_stores{0.0};
    double metal_mpp_operations{0.0};
    double memory_fragment_reads{0.0};
    double lhs_footprint_fragments{0.0};
    double rhs_footprint_fragments{0.0};
    double accumulator_initializations{0.0};
    double tile_aspect_fragments{0.0};
    double local_row_aspect_issues{0.0};
    double local_column_aspect_issues{0.0};
    double independent_elements{0.0};
    double elided_independent_elements{0.0};
    uint64_t fragment_scalars_per_lane{0u};
    // score is local program work. Solvers minimize kernel_score, which may
    // also include machine service demand. A custom reduction policy owns the
    // whole objective; no additional wave prior is applied by the bridge.
    double score{0.0};
    double concurrent_waves{1.0};
    double kernel_score{0.0};
};

struct GroupPlan {
    luisa::string name;
    uint64_t programs{0u};
    uint64_t program_grid_rows{0u};
    uint64_t program_grid_columns{0u};
    uint32_t program_order_rows{1u};
    uint32_t program_order_columns{1u};
    uint32_t threads{1u};
    uint64_t shared_memory_bytes{0u};
    uint64_t candidates_considered{0u};
    uint64_t candidates_rejected{0u};
    uint32_t max_copy_batch{1u};
    uint64_t batched_copy_operations{0u};
    uint64_t prefetched_pipeline_loops{0u};
    uint64_t prefetch_storage_scalars_per_lane{0u};
    // Reduction-realization facts. Zero subgroups means this is not a native
    // subgroup-reduction plan. Striped storage is compiler-local state after
    // logical Tile materializations are compacted to each worker's ownership.
    uint32_t reduction_subgroups_per_program{0u};
    uint32_t reduction_programs_per_group{0u};
    uint64_t striped_storage_scalars_per_worker{0u};
    uint64_t reduction_operations{0u};
    uint64_t reduction_elements{0u};
    uint64_t elementwise_elements_per_program{0u};
    // Shared pure Tile SSA values scalarized to one definition per worker.
    uint32_t elementwise_scalar_temporaries{0u};
    uint32_t reduction_unroll_factor{1u};
    uint32_t reduction_lane_elements{1u};
    uint64_t reduction_threadgroups{0u};
    double reduction_scalar_rounds{0.0};
    double reduction_lane_utilization{0.0};
    bool reduction_payload_accesses_known{false};
    ReductionAccessDemand reduction_payload_accesses_per_program;
    ReductionAccessDemand reduction_payload_accesses_per_worker;
    // Static emitted synchronization sites, not dynamic barrier executions.
    // Filled by realization; the bootstrap ranking does not yet price them.
    uint64_t group_barrier_sites_before{0u};
    uint64_t group_barrier_sites_after{0u};
    // Realization proof, independent of the selected fence-elision policy.
    bool independent_subgroups{false};
    luisa::vector<MatrixDistribution> matrices;
    MatrixCostBasis cost_basis{MatrixCostBasis::SIMDGROUP_REFERENCE};
    // Explicit realization selected by the target bridge. cost_basis records
    // which separately versioned feature model ranked it.
    bool metal_mpp{false};
    bool automatic_cooperative{false};
    PlanCost cost;
    bool optimized{false};
};

struct PlanningResult {
    GroupPlan plan;
    luisa::string error;

    [[nodiscard]] bool ok() const noexcept { return error.empty(); }
    [[nodiscard]] explicit operator bool() const noexcept { return ok(); }
};

// Exhaustive discrete solver for the currently implemented group realization
// family: thread count x rectangular subgroup factorizations x resident atom
// blocks. Covers every exact rectangular factorization in the supplied bounds,
// not all possible GPU programs. No compiler IR, JIT, measurements, or mutable
// global state is needed to rank candidates. The SIMD-group basis includes the
// reference realization; an
// explicit MPP basis has no scalar fallback and fails if no legal descriptor
// exists. MatrixWorkloads must come from proved semantic MMA contracts.
[[nodiscard]] LUISA_TILE_TIRX_BRIDGE_API PlanningResult plan_group(
    const GroupWorkload &workload, const ExecutionLimits &limits,
    const PlannerOptions &options = {},
    MatrixCostBasis cost_basis = MatrixCostBasis::SIMDGROUP_REFERENCE) noexcept;

// Independent, integer-only coverage/resource check, also applied by codegen.
// Cost-model coefficients cannot grant legality to a candidate.
[[nodiscard]] LUISA_TILE_TIRX_BRIDGE_API bool verify_matrix_distribution(
    const MatrixWorkload &workload, const MatrixDistribution &distribution,
    uint32_t threads, uint32_t subgroup_size) noexcept;

}// namespace luisa::compute::tile::bridge::tirx

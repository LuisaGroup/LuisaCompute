#include <algorithm>
#include <cstdint>
#include <functional>
#include <limits>

#include <tvm/ffi/extra/structural_equal.h>
#include <tvm/tirx/analysis.h>
#include <tvm/tirx/buffer.h>
#include <tvm/tirx/builtin.h>
#include <tvm/tirx/op.h>
#include <tvm/tirx/stmt_functor.h>

#include <luisa/core/stl/unordered_map.h>
#include <luisa/core/stl/vector.h>
#include <luisa/core/mathematics.h>

#include "execution.h"

namespace luisa::compute::tile::bridge::tirx::detail {

namespace {

class VectorStorageExpander final : public DiagnosticStmtExprMutator {

private:
    tvm::PrimExpr _lane;
    tvm::PrimExpr _extent;
    uint64_t _lane_count{0u};
    luisa::unordered_map<const tvm::tirx::VarNode *, tvm::tirx::BufferVar> _buffers;
    tvm::ffi::Array<tvm::tirx::Stmt> _allocations;

private:
    [[nodiscard]] tvm::ffi::Optional<tvm::PrimExpr> _predicate(
        const tvm::ffi::Optional<tvm::PrimExpr> &predicate) {
        return predicate ? VisitPrimExpr(predicate.value()) : tvm::ffi::Optional<tvm::PrimExpr>{};
    }

protected:
    [[nodiscard]] tvm::tirx::Stmt VisitStmt_(const tvm::tirx::AllocBufferNode *allocation) final {
        auto buffer = allocation->buffer;
        // These are virtual, compact compiler temporaries. An explicitly
        // placed or dynamically shaped resource needs its own address-map
        // transformation; do not discard such a contract here.
        auto offset = buffer->elem_offset.as<tvm::IntImmNode>();
        if (buffer.scope() != "local" || !buffer->strides.empty() ||
            buffer->layout || !buffer->allocated_addr.empty() ||
            offset == nullptr || offset->value != 0) {
            return _diagnostic.reject("TileIR vector scope requires compact compiler-local allocations", tvm::ffi::GetRef<tvm::tirx::AllocBuffer>(allocation));
        }
        auto volume = _lane_count;
        for (auto &&dimension : buffer->shape) {
            auto extent = dimension.as<tvm::IntImmNode>();
            if (extent == nullptr || extent->value < 0 ||
                (extent->value != 0 && volume > static_cast<uint64_t>(std::numeric_limits<int64_t>::max() / extent->value))) {
                return _diagnostic.reject("TileIR vector private allocation needs a static shape within int64 range", tvm::ffi::GetRef<tvm::tirx::AllocBuffer>(allocation));
            }
            volume *= static_cast<uint64_t>(extent->value);
        }
        // Address((local indices), lane) = flatten(local indices) * lanes +
        // lane. The trailing axis becomes a contiguous SIMD vector after
        // FlattenBuffer; no execution coordinate changes the logical Tile.
        auto shape = buffer->shape;
        shape.push_back(_extent);
        auto type = tvm::tirx::BufferType{
            buffer->storage_scope, buffer->dtype, std::move(shape), {}, buffer->elem_offset, buffer->data_alignment, buffer->offset_factor};
        auto expanded = tvm::tirx::BufferVar{buffer.name() + "_lanes", std::move(type), buffer.span()};
        _buffers.emplace(buffer.get(), expanded);
        _allocations.push_back(tvm::tirx::AllocBuffer{std::move(expanded), allocation->annotations, allocation->span});
        return tvm::tirx::Evaluate{tvm::IntImm::Int32(0)};
    }

    [[nodiscard]] tvm::Expr VisitExpr_(const tvm::tirx::BufferLoadNode *load) final {
        auto indices = load->indices.Map([this](const tvm::PrimExpr &index) { return VisitPrimExpr(index); });
        auto buffer = load->buffer;
        if (auto iter = _buffers.find(buffer.get()); iter != _buffers.end()) {
            buffer = iter->second;
            indices.push_back(_lane);
        }
        return tvm::tirx::BufferLoad{std::move(buffer), std::move(indices), _predicate(load->predicate), load->span};
    }

    [[nodiscard]] tvm::tirx::Stmt VisitStmt_(const tvm::tirx::BufferStoreNode *store) final {
        auto indices = store->indices.Map([this](const tvm::PrimExpr &index) { return VisitPrimExpr(index); });
        auto value = VisitPrimExpr(store->value);
        auto buffer = store->buffer;
        if (auto iter = _buffers.find(buffer.get()); iter != _buffers.end()) {
            buffer = iter->second;
            indices.push_back(_lane);
        }
        return tvm::tirx::BufferStore{std::move(buffer), std::move(value), std::move(indices), _predicate(store->predicate), store->span};
    }

    [[nodiscard]] tvm::Expr VisitExpr_(const tvm::tirx::VarNode *variable) final {
        if (_buffers.contains(variable)) {
            return _diagnostic.reject("TileIR vector private allocation cannot escape through an opaque buffer use", tvm::ffi::GetRef<tvm::tirx::Var>(variable));
        }
        return StmtExprMutator::VisitExpr_(variable);
    }

public:
    explicit VectorStorageExpander(const tvm::tirx::For &loop, Diagnostic &diagnostic)
        : DiagnosticStmtExprMutator{diagnostic}, _lane{loop->loop_var - loop->min}, _extent{loop->extent} {
        auto extent = _extent.as<tvm::IntImmNode>();
        if (extent == nullptr || extent->value <= 0 || extent->value > std::numeric_limits<uint16_t>::max()) {
            _diagnostic.set_error("TileIR vector scope requires a positive static width representable by TIRx");
            return;
        }
        _lane_count = static_cast<uint64_t>(extent->value);
    }

    [[nodiscard]] tvm::tirx::Stmt run(tvm::tirx::For loop) {
        if (_diagnostic.failed()) { return loop; }
        auto body = VisitStmt(loop->body);
        if (_diagnostic.failed()) { return loop; }
        loop.CopyOnWrite()->body = std::move(body);
        // Lexical compiler storage inside a vector instance is allocated once
        // for the whole vector and indexed separately by every lane. Parent
        // storage stays outside this visitor and is neither replicated nor
        // silently moved to a different resource class.
        _allocations.push_back(std::move(loop));
        return tvm::tirx::SeqStmt::Flatten(_allocations);
    }
};

class ProvenVectorGuards final : public tvm::tirx::StmtExprMutator {
private:
    const luisa::vector<tvm::PrimExpr> &_guards;

protected:
    [[nodiscard]] tvm::Expr VisitExpr(const tvm::Expr &expression) final {
        for (auto &guard : _guards) {
            if (tvm::ffi::StructuralEqual{}(expression, guard)) { return tvm::IntImm::Bool(true); }
        }
        return StmtExprMutator::VisitExpr(expression);
    }

public:
    explicit ProvenVectorGuards(const luisa::vector<tvm::PrimExpr> &guards) : _guards{guards} {}
};

// A lane-dependent lazy load otherwise scalarizes the entire SIMD operation.
// Version the pack once: the fast arm assumes only predicates checked for
// EVERY lane, while the slow arm retains the original guards and padding.
// Scalar conditions (including the ordered reduction coordinate) stay put.
class VectorGuardSpecializer final : public tvm::tirx::StmtMutator {
protected:
    [[nodiscard]] tvm::tirx::Stmt VisitStmt_(const tvm::tirx::ForNode *node) final {
        if (node->kind != tvm::tirx::ForKind::kVectorized) { return StmtMutator::VisitStmt_(node); }
        auto loop = tvm::ffi::GetRef<tvm::tirx::For>(node);
        auto minimum = loop->min.as<tvm::IntImmNode>();
        auto extent = loop->extent.as<tvm::IntImmNode>();
        if (minimum == nullptr || extent == nullptr || extent->value < 4 || extent->value > 16 || loop->step ||
            minimum->value > std::numeric_limits<int64_t>::max() - extent->value) { return loop; }
        luisa::unordered_set<const tvm::tirx::VarNode *> available;
        for (auto &variable : tvm::tirx::UndefinedVars(loop, {})) { available.emplace(variable.get()); }
        available.emplace(loop->loop_var.get());
        auto safe = [&](const tvm::PrimExpr &condition) {
            auto valid = true;
            auto uses_lane = false;
            tvm::tirx::PostOrderVisit(condition, [&](const tvm::ffi::ObjectRef &object) {
                if (auto variable = object.as<tvm::tirx::VarNode>()) {
                    valid &= available.contains(variable) &&
                             (variable->ty == tvm::PrimType::Int(64) || variable->ty == tvm::PrimType::Int(32) || variable->ty == tvm::PrimType::Bool());
                    uses_lane |= variable == loop->loop_var.get();
                } else if (auto division = object.as<tvm::tirx::FloorDivNode>()) {
                    auto divisor = division->b.as<tvm::IntImmNode>();
                    valid &= divisor != nullptr && divisor->value > 0;
                } else if (auto modulo = object.as<tvm::tirx::FloorModNode>()) {
                    auto divisor = modulo->b.as<tvm::IntImmNode>();
                    valid &= divisor != nullptr && divisor->value > 0;
                } else {
                    // No memory reads, calls, floating point, dynamic division,
                    // or local definitions may be speculated outside the pack.
                    valid &= object.as<tvm::IntImmNode>() || object.as<tvm::tirx::AddNode>() || object.as<tvm::tirx::SubNode>() ||
                             object.as<tvm::tirx::MulNode>() || object.as<tvm::tirx::MinNode>() || object.as<tvm::tirx::MaxNode>() ||
                             object.as<tvm::tirx::LTNode>() || object.as<tvm::tirx::LENode>() || object.as<tvm::tirx::GTNode>() ||
                             object.as<tvm::tirx::GENode>() || object.as<tvm::tirx::EQNode>() || object.as<tvm::tirx::NENode>() ||
                             object.as<tvm::tirx::AndNode>() || object.as<tvm::tirx::OrNode>() || object.as<tvm::tirx::NotNode>();
                }
            });
            return valid && uses_lane;
        };
        luisa::vector<tvm::PrimExpr> guards;
        std::function<void(const tvm::PrimExpr &)> collect = [&](const tvm::PrimExpr &condition) {
            if (auto conjunction = condition.as<tvm::tirx::AndNode>()) {
                collect(conjunction->a);
                collect(conjunction->b);
            } else if (safe(condition) && std::none_of(guards.begin(), guards.end(), [&](auto &guard) { return tvm::ffi::StructuralEqual{}(condition, guard); })) {
                guards.emplace_back(condition);
            }
        };
        auto versionable = true;
        tvm::tirx::PreOrderVisit(loop->body, [&](const tvm::ffi::ObjectRef &object) {
            // Address subexpressions of a predicated read are not necessarily
            // evaluated. Only specialize value-level lazy loads, not indices.
            if (object.as<tvm::tirx::BufferLoadNode>()) { return false; }
            if (object.as<tvm::tirx::LetNode>() || object.as<tvm::tirx::ReduceNode>() || object.as<tvm::tirx::ProducerLoadNode>()) {
                versionable = false;
                return false;
            }
            if (auto call = object.as<tvm::CallNode>()) {
                if (call->op.same_as(tvm::tirx::builtin::if_then_else()) && call->args.size() == 3u) {
                    collect(call->args[0].as_or_throw<tvm::PrimExpr>());
                } else {
                    versionable = false;
                }
                // Do not speculate predicates from either lazy branch. Even
                // integer arithmetic there may overflow on an untaken arm.
                return false;
            }
            if (auto child = object.as<tvm::tirx::ForNode>()) {
                auto count = child->extent.as<tvm::IntImmNode>();
                auto step = child->step ? child->step.value().as<tvm::IntImmNode>() : nullptr;
                versionable &= child->kind == tvm::tirx::ForKind::kSerial && !child->thread_binding && count != nullptr && count->value > 0 &&
                               (!child->step || (step != nullptr && step->value == 1));
            } else if (auto conditional = object.as<tvm::tirx::IfThenElseNode>()) {
                auto lane_dependent = false;
                tvm::tirx::PostOrderVisit(conditional->condition, [&](const tvm::ffi::ObjectRef &node) {
                    lane_dependent |= node.same_as(loop->loop_var);
                });
                auto before = guards.size();
                collect(conditional->condition);
                // A statement guard may protect an otherwise invalid store.
                // Version it only when every lane-dependent part contributes
                // a proved pack predicate. Scalar conditions remain inside
                // both versions and are never speculated.
                versionable &= !conditional->else_case &&
                               (!lane_dependent || guards.size() != before);
            } else if (auto store = object.as<tvm::tirx::BufferStoreNode>()) {
                versionable &= !store->predicate;
            } else if (object.as<tvm::tirx::StmtNode>() && !object.as<tvm::tirx::SeqStmtNode>()) {
                // No local definitions, early exits, or opaque effects. Every
                // selected predicate must already be evaluated for every lane
                // on each defined original execution.
                versionable = false;
            }
            return versionable;
        });
        // Bound both the predicate construction and code duplication. This is
        // one binary version, not an exponential decision tree per predicate.
        if (!versionable || guards.empty() || guards.size() > 8u) { return loop; }
        tvm::PrimExpr full = tvm::IntImm::Bool(true);
        for (auto &guard : guards) {
            for (auto lane = int64_t{0}; lane < extent->value; lane++) {
                auto coordinate = tvm::IntImm{loop->loop_var.ty(), minimum->value + lane};
                full = full && tvm::tirx::Substitute(guard, tvm::ffi::Map<tvm::tirx::Var, tvm::Expr>{{loop->loop_var, coordinate}});
            }
        }
        auto fast = ProvenVectorGuards{guards}(loop);
        return tvm::tirx::IfThenElse{std::move(full), std::move(fast), std::move(loop)};
    }
};

}// namespace

tvm::tirx::Stmt privatize_vector_storage(const tvm::tirx::For &loop, Diagnostic &diagnostic) {
    return VectorStorageExpander{loop, diagnostic}.run(loop);
}

tvm::tirx::Stmt vectorize_independent_elements(const tvm::tirx::For &loop, uint32_t max_lanes) {
    auto annotation = loop->annotations.Get(independent_elements_annotation);
    auto rank = annotation ? annotation.value().as<tvm::IntImmNode>() : nullptr;
    if (rank == nullptr || rank->value <= 0 ||
        loop->annotations.size() != 1u + loop->annotations.count(mma_annotation)) { return {}; }
    luisa::vector<const tvm::tirx::ForNode *> axes;
    auto inner = loop.get();
    for (auto i = int64_t{0}; i < rank->value; i++) {
        auto step = inner && inner->step ? inner->step.value().as<tvm::IntImmNode>() : nullptr;
        if (inner == nullptr || inner->kind != tvm::tirx::ForKind::kSerial || inner->thread_binding ||
            inner->loop_var.ty() != tvm::PrimType::Int(64) ||
            inner->min.as<tvm::IntImmNode>() == nullptr || inner->extent.as<tvm::IntImmNode>() == nullptr ||
            (inner->step && (step == nullptr || step->value != 1)) || (i != 0 && !inner->annotations.empty())) { return {}; }
        axes.push_back(inner);
        if (i + 1 != rank->value) { inner = inner->body.as<tvm::tirx::ForNode>(); }
    }
    auto extent = inner->extent.as<tvm::IntImmNode>()->value;
    if (extent < 4) { return {}; }
    // Logical packs may span several hardware vectors. Keeping independent
    // accumulators together exposes instruction-level parallelism to LLVM
    // without unrolling/reassociating the temporal recurrence itself.
    auto width = int64_t{4};
    while (width < 16 && extent >= width * 2) { width *= 2; }
    auto compatible = true;
    tvm::tirx::PostOrderVisit(inner->body, [&](const tvm::ffi::ObjectRef &node) {
        // These need storage privatization or a richer vectorizer. Automatic
        // packing must not make an otherwise valid reference kernel fail.
        compatible &= node.as<tvm::tirx::AllocBufferNode>() == nullptr && node.as<tvm::tirx::WhileNode>() == nullptr;
        if (auto child = node.as<tvm::tirx::ForNode>()) {
            compatible &= child->kind == tvm::tirx::ForKind::kSerial && !child->thread_binding;
        }
    });
    if (!compatible) { return {}; }

    // Factor the two innermost independent coordinates into a Cartesian
    // register pack. Keep row vectors separate: flattening the coordinates
    // into one wide vector loses contiguous load/store structure in TIRx.
    // Jam rectangular serial loops across the rows instead. Independence is
    // supplied by the element-domain contract, not an MMA marker; every
    // element retains its original temporal order and arithmetic expression.
    auto rows = int64_t{1};
    const tvm::tirx::ForNode *row_axis = nullptr;
    if (max_lanes > 16u && axes.size() >= 2u) {
        row_axis = axes[axes.size() - 2u];
        auto row_count = row_axis->extent.as<tvm::IntImmNode>()->value;
        while (rows * width * 2 <= max_lanes && rows * 2 <= row_count) { rows *= 2; }
    }
    if (rows > 1) {
        auto row_count = row_axis->extent.as<tvm::IntImmNode>()->value;
        auto row_pack = tvm::tirx::PrimVar{row_axis->loop_var->name + "_pack", tvm::PrimType::Int(64)};
        auto column_pack = tvm::tirx::PrimVar{inner->loop_var->name + "_pack", tvm::PrimType::Int(64)};
        auto invariant = [&](const tvm::PrimExpr &expression) {
            auto result = true;
            tvm::tirx::PostOrderVisit(expression, [&](const tvm::ffi::ObjectRef &node) {
                result &= !node.same_as(row_axis->loop_var) && !node.same_as(inner->loop_var);
            });
            return result;
        };
        // Only distribute statement sequences and rectangular serial loops.
        // Definitions, conditions, opaque effects, or lane-dependent bounds
        // need a richer region transform: retain the single-row fallback.
        std::function<tvm::tirx::Stmt(const tvm::tirx::Stmt &)> pack;
        pack = [&](const tvm::tirx::Stmt &statement) -> tvm::tirx::Stmt {
            if (auto sequence = statement.as<tvm::tirx::SeqStmtNode>()) {
                tvm::ffi::Array<tvm::tirx::Stmt> packed;
                for (auto &child : sequence->seq) {
                    auto result = pack(child);
                    if (!result.defined()) { return {}; }
                    packed.push_back(std::move(result));
                }
                return tvm::tirx::SeqStmt::Flatten(std::move(packed));
            }
            if (auto temporal = statement.as<tvm::tirx::ForNode>()) {
                if (temporal->kind != tvm::tirx::ForKind::kSerial || temporal->thread_binding || !temporal->annotations.empty() ||
                    !invariant(temporal->min) || !invariant(temporal->extent) || (temporal->step && !invariant(temporal->step.value()))) { return {}; }
                auto result = pack(temporal->body);
                if (!result.defined()) { return {}; }
                return tvm::tirx::For{temporal->loop_var, temporal->min, temporal->extent, temporal->kind, std::move(result), std::nullopt, {}, temporal->step, temporal->span};
            }
            if (!statement.as<tvm::tirx::BufferStoreNode>()) { return {}; }
            tvm::ffi::Array<tvm::tirx::Stmt> packed;
            for (auto row = int64_t{0}; row < rows; row++) {
                auto lane = tvm::tirx::PrimVar{inner->loop_var->name + "_lane", tvm::PrimType::Int(64)};
                tvm::ffi::Map<tvm::tirx::Var, tvm::Expr> coordinates{
                    {row_axis->loop_var, row_axis->min + row_pack * tvm::IntImm::Int64(rows) + tvm::IntImm::Int64(row)},
                    {inner->loop_var, inner->min + column_pack * tvm::IntImm::Int64(width) + lane}};
                auto result = tvm::tirx::Substitute(statement, coordinates);
                packed.push_back(tvm::tirx::For{lane, tvm::IntImm::Int64(0), tvm::IntImm::Int64(width), tvm::tirx::ForKind::kVectorized, std::move(result)});
            }
            return tvm::tirx::SeqStmt::Flatten(std::move(packed));
        };
        auto body = pack(inner->body);
        if (!body.defined()) { return vectorize_independent_elements(loop, 16u); }
        body = tvm::tirx::For{column_pack, tvm::IntImm::Int64(0), tvm::IntImm::Int64(extent / width), tvm::tirx::ForKind::kSerial, std::move(body)};
        body = tvm::tirx::For{row_pack, tvm::IntImm::Int64(0), tvm::IntImm::Int64(row_count / rows), tvm::tirx::ForKind::kSerial, std::move(body)};
        tvm::ffi::Array<tvm::tirx::Stmt> pieces{std::move(body)};
        if (extent % width != 0) {
            auto tail = tvm::tirx::For{inner->loop_var, inner->min + tvm::IntImm::Int64(extent / width * width), tvm::IntImm::Int64(extent % width), tvm::tirx::ForKind::kSerial, inner->body};
            pieces.push_back(tvm::tirx::For{row_axis->loop_var, row_axis->min, tvm::IntImm::Int64(row_count / rows * rows), tvm::tirx::ForKind::kSerial, std::move(tail)});
        }
        if (row_count % rows != 0) {
            // The row tail covers every column, disjoint from both the full
            // Cartesian packs and the column tail of their complete rows.
            auto tail = tvm::tirx::For{inner->loop_var, inner->min, inner->extent, tvm::tirx::ForKind::kSerial, inner->body};
            pieces.push_back(tvm::tirx::For{row_axis->loop_var, row_axis->min + tvm::IntImm::Int64(row_count / rows * rows), tvm::IntImm::Int64(row_count % rows), tvm::tirx::ForKind::kSerial, std::move(tail)});
        }
        body = tvm::tirx::SeqStmt::Flatten(std::move(pieces));
        for (auto i = axes.size() - 2u; i != 0u; i--) {
            auto outer = axes[i - 1u];
            auto annotations = outer->annotations;
            annotations.erase(independent_elements_annotation);
            annotations.erase(mma_annotation);
            body = tvm::tirx::For{outer->loop_var, outer->min, outer->extent, tvm::tirx::ForKind::kSerial, std::move(body), std::nullopt, std::move(annotations), outer->step, outer->span};
        }
        return VectorGuardSpecializer{}(body);
    }

    // Independence is supplied by the element-domain contract. This is only
    // a coordinate factorization; it neither re-proves memory dependencies
    // nor changes serial K/reduction recurrences inside an element instance.
    auto chunk = tvm::tirx::PrimVar{inner->loop_var->name + "_pack", tvm::PrimType::Int(64)};
    auto lane = tvm::tirx::PrimVar{inner->loop_var->name + "_lane", tvm::PrimType::Int(64)};
    auto coordinate = inner->min + chunk * tvm::IntImm::Int64(width) + lane;
    auto body = tvm::tirx::Substitute(inner->body, tvm::ffi::Map<tvm::tirx::Var, tvm::Expr>{{inner->loop_var, coordinate}});
    body = tvm::tirx::For{lane, tvm::IntImm::Int64(0), tvm::IntImm::Int64(width), tvm::tirx::ForKind::kVectorized, std::move(body)};
    body = tvm::tirx::For{chunk, tvm::IntImm::Int64(0), tvm::IntImm::Int64(extent / width), tvm::tirx::ForKind::kSerial, std::move(body)};
    if (extent % width != 0) {
        auto tail = tvm::tirx::For{inner->loop_var, inner->min + tvm::IntImm::Int64(extent / width * width), tvm::IntImm::Int64(extent % width), tvm::tirx::ForKind::kSerial, inner->body};
        body = tvm::tirx::SeqStmt::Flatten(tvm::ffi::Array<tvm::tirx::Stmt>{std::move(body), std::move(tail)});
    }
    for (auto i = axes.size() - 1u; i != 0u; i--) {
        auto outer = axes[i - 1u];
        auto annotations = outer->annotations;
        annotations.erase(independent_elements_annotation);
        annotations.erase(mma_annotation);
        body = tvm::tirx::For{outer->loop_var, outer->min, outer->extent, tvm::tirx::ForKind::kSerial, std::move(body), std::nullopt, std::move(annotations), outer->step, outer->span};
    }
    return VectorGuardSpecializer{}(body);
}

namespace {

// Strip only empty structural-export placeholders. Other statements retain
// their identity for the complete effect/domain audit below.
[[nodiscard]] tvm::tirx::Stmt sole_effect(const tvm::tirx::Stmt &body) {
    if (auto evaluate = body.as<tvm::tirx::EvaluateNode>();
        evaluate && (evaluate->value.as<tvm::IntImmNode>() || evaluate->value.as<tvm::FloatImmNode>())) { return {}; }
    if (auto sequence = body.as<tvm::tirx::SeqStmtNode>()) {
        tvm::tirx::Stmt result;
        for (auto &child : sequence->seq) {
            auto effect = sole_effect(child);
            if (!effect.defined()) { continue; }
            if (result.defined()) { return body; }
            result = std::move(effect);
        }
        return result;
    }
    return body;
}

[[nodiscard]] bool static_unit_domain(const tvm::tirx::ForNode *loop) {
    if (!loop || loop->kind != tvm::tirx::ForKind::kSerial || loop->thread_binding || loop->step ||
        loop->loop_var.ty() != tvm::PrimType::Int(64)) { return false; }
    auto extent = loop->extent.as<tvm::IntImmNode>();
    auto minimum = loop->min.as<tvm::IntImmNode>();
    return extent && minimum && extent->value > 0 && minimum->value <= INT64_MAX - extent->value;
}

struct ElementDomain {
    luisa::vector<const tvm::tirx::ForNode *> axes;
    tvm::tirx::Stmt point;
    uint64_t volume{1u};
};

[[nodiscard]] std::optional<ElementDomain> element_domain(tvm::tirx::Stmt body, bool producer) {
    auto outer = body.as<tvm::tirx::ForNode>();
    if (!outer || outer->annotations.size() != (producer ? 2u : 1u)) { return {}; }
    if (producer) {
        auto provenance = outer->annotations.Get(materialized_pure_tile_annotation);
        auto version = provenance ? provenance.value().as<tvm::IntImmNode>() : nullptr;
        if (!version || version->value != 1) { return {}; }
    }
    auto rank_attribute = outer->annotations.Get(independent_elements_annotation);
    auto rank = rank_attribute ? rank_attribute.value().as<tvm::IntImmNode>() : nullptr;
    if (!rank || rank->value <= 0 || rank->value > 16) { return {}; }
    ElementDomain result;
    for (auto i = int64_t{0}; i < rank->value; i++) {
        auto axis = body.as<tvm::tirx::ForNode>();
        if (!static_unit_domain(axis) || (i != 0 && !axis->annotations.empty())) { return {}; }
        auto extent = static_cast<uint64_t>(axis->extent.as<tvm::IntImmNode>()->value);
        if (result.volume > INT64_MAX / extent) { return {}; }
        result.volume *= extent;
        result.axes.emplace_back(axis);
        body = axis->body;
    }
    result.point = std::move(body);
    return result;
}

// Only sequence grouping and empty export placeholders are transparent. A
// pipeline, branch, nested execution domain, or resource marker is a boundary.
void element_sequence(const tvm::tirx::Stmt &body, luisa::vector<tvm::tirx::Stmt> &parts) {
    if (auto sequence = body.as<tvm::tirx::SeqStmtNode>()) {
        for (auto &child : sequence->seq) { element_sequence(child, parts); }
    } else if (auto effect = sole_effect(body); effect.defined()) {
        parts.emplace_back(std::move(effect));
    }
}

using ElementScalars = luisa::unordered_map<const tvm::tirx::VarNode *, tvm::PrimExpr>;

[[nodiscard]] bool pure_element_call(const tvm::CallNode *call) {
    static auto effects = tvm::Op::GetAttrMap<tvm::tirx::TCallEffectKind>("TCallEffectKind");
    auto op = call->op.as<tvm::Op>();
    return !call->op.same_as(tvm::tirx::builtin::address_of()) && op && effects.count(op.value()) &&
           effects[op.value()] <= static_cast<int64_t>(tvm::tirx::CallEffectKind::kPure);
}

// A temporary may disappear only after every read has the same local owner as
// its unique, dominating producer. Shape equality is not a dependence proof:
// a transpose, neighbor read, broadcast, or indirect index keeps Tile storage.
class ElementScalarReads final : public tvm::tirx::StmtExprMutator {
private:
    const ElementScalars &_scalars;
    const luisa::unordered_set<const tvm::tirx::VarNode *> &_allocated;
    const luisa::vector<const tvm::tirx::ForNode *> &_axes;
    const luisa::vector<const tvm::tirx::ForNode *> &_domain;

protected:
    [[nodiscard]] tvm::Expr VisitExpr_(const tvm::tirx::VarNode *variable) final {
        valid &= !_allocated.contains(variable);
        return StmtExprMutator::VisitExpr_(variable);
    }
    [[nodiscard]] tvm::Expr VisitExpr_(const tvm::tirx::ProducerLoadNode *load) final {
        valid = false;
        return StmtExprMutator::VisitExpr_(load);
    }
    [[nodiscard]] tvm::Expr VisitExpr_(const tvm::CallNode *call) final {
        valid &= pure_element_call(call);
        return StmtExprMutator::VisitExpr_(call);
    }
    [[nodiscard]] tvm::Expr VisitExpr_(const tvm::tirx::BufferLoadNode *load) final {
        if (load->buffer.scope() == "global") { return StmtExprMutator::VisitExpr_(load); }
        auto scalar = _scalars.find(load->buffer.get());
        if (scalar == _scalars.end() || load->predicate || load->indices.size() != _axes.size()) {
            valid = false;
            return tvm::ffi::GetRef<tvm::tirx::BufferLoad>(load);
        }
        for (auto i = 0u; i < _axes.size(); i++) {
            // Even an algebraically redundant index subexpression must pass
            // the effect/escape audit before its memory access disappears.
            static_cast<void>(VisitPrimExpr(load->indices[i]));
            valid &= prove_in_loop_domain(load->indices[i] == _axes[i]->loop_var - _axes[i]->min, _domain);
        }
        return scalar->second;
    }

public:
    bool valid{true};
    [[nodiscard]] tvm::PrimExpr value(const tvm::PrimExpr &expression) { return VisitPrimExpr(expression); }
    ElementScalarReads(const ElementScalars &scalars, const luisa::unordered_set<const tvm::tirx::VarNode *> &allocated,
                       const luisa::vector<const tvm::tirx::ForNode *> &axes,
                       const luisa::vector<const tvm::tirx::ForNode *> &domain)
        : _scalars{scalars}, _allocated{allocated}, _axes{axes}, _domain{domain} {}
};

struct ElementProgram {
    ElementDomain domain;
    uint32_t scalar_temporaries{0u};
};

// Fuse a bounded, same-domain SSA graph and its output domains before mapping.
// Each Bind still computes its producer once per logical element; this is
// storage scalarization and loop fusion, not expression cloning/recomputation.
// The later effect audit proves disjoint output regions and no global RAW/WAR
// dependence before this interleaving of the original loop domains commits.
[[nodiscard]] std::optional<ElementProgram> element_program(const tvm::tirx::ForNode *root) {
    luisa::vector<tvm::tirx::Stmt> parts;
    element_sequence(root->body, parts);
    if (parts.empty()) { return {}; }
    auto consumer = element_domain(parts.back(), false);
    if (!consumer) { return {}; }
    luisa::vector<const tvm::tirx::ForNode *> domain{root};
    domain.insert(domain.end(), consumer->axes.begin(), consumer->axes.end());
    luisa::unordered_set<const tvm::tirx::VarNode *> allocated;
    ElementScalars scalars;
    tvm::ffi::Array<tvm::tirx::Stmt> points;
    for (auto i = size_t{0}; i < parts.size(); i++) {
        if (auto allocation = parts[i].as<tvm::tirx::AllocBufferNode>()) {
            auto buffer = allocation->buffer;
            auto offset = buffer->elem_offset.as<tvm::IntImmNode>();
            if (!allocation->annotations.empty() || buffer.scope() != "local" || !buffer->strides.empty() ||
                buffer->layout || !buffer->allocated_addr.empty() || !offset || offset->value != 0 ||
                buffer->dtype.IsScalableVector() || buffer->dtype.lanes() != 1 || buffer->shape.size() != consumer->axes.size() ||
                allocated.size() == 64u || !allocated.emplace(buffer.get()).second) { return {}; }
            for (auto j = 0u; j < consumer->axes.size(); j++) {
                if (!tvm::ffi::StructuralEqual{}(buffer->shape[j], consumer->axes[j]->extent)) { return {}; }
            }
            continue;
        }
        auto outer = parts[i].as<tvm::tirx::ForNode>();
        auto materialized = outer && outer->annotations.count(materialized_pure_tile_annotation);
        auto producer = element_domain(parts[i], materialized);
        if (!producer || producer->axes.size() != consumer->axes.size()) { return {}; }
        tvm::ffi::Map<tvm::tirx::Var, tvm::Expr> coordinates;
        for (auto j = 0u; j < producer->axes.size(); j++) {
            auto from = producer->axes[j], to = consumer->axes[j];
            if (!tvm::ffi::StructuralEqual{}(from->extent, to->extent)) { return {}; }
            coordinates.Set(from->loop_var, to->loop_var - to->min + from->min);
        }
        auto point = tvm::tirx::Substitute(producer->point, coordinates);
        if (!materialized) {
            ElementScalarReads reads{scalars, allocated, consumer->axes, domain};
            points.push_back(reads(point));
            if (!reads.valid) { return {}; }
            continue;
        }
        auto store = point.as<tvm::tirx::BufferStoreNode>();
        if (!store || store->predicate || store->value.ty() != store->buffer->dtype ||
            !allocated.contains(store->buffer.get()) || scalars.contains(store->buffer.get()) ||
            store->indices.size() != consumer->axes.size()) { return {}; }
        ElementScalarReads reads{scalars, allocated, consumer->axes, domain};
        for (auto j = 0u; j < consumer->axes.size(); j++) {
            static_cast<void>(reads.value(store->indices[j]));
            if (!prove_in_loop_domain(store->indices[j] == consumer->axes[j]->loop_var - consumer->axes[j]->min, domain)) { return {}; }
        }
        auto value = reads.value(store->value);
        if (!reads.valid) { return {}; }
        auto dtype = store->buffer->dtype;
        if (dtype == tvm::PrimType::BFloat(16)) {
            // A fused scalar must retain the original BF16 rounding event.
            // Keep its exact bits in the binding: the pinned TVMx BF16 pass
            // promotes Bind values but does not consistently retype the Var.
            auto scalar = tvm::tirx::PrimVar{store->buffer.name() + "_bits", tvm::PrimType::UInt(16)};
            points.push_back(tvm::tirx::Bind{scalar, tvm::reinterpret(tvm::PrimType::UInt(16), std::move(value))});
            scalars.emplace(store->buffer.get(), tvm::reinterpret(dtype, scalar));
        } else {
            auto scalar = tvm::tirx::PrimVar{store->buffer.name() + "_element", dtype};
            points.push_back(tvm::tirx::Bind{scalar, std::move(value)});
            scalars.emplace(store->buffer.get(), std::move(scalar));
        }
    }
    if (scalars.size() != allocated.size()) { return {}; }
    consumer->point = tvm::tirx::SeqStmt::Flatten(points);
    return ElementProgram{std::move(*consumer), static_cast<uint32_t>(scalars.size())};
}

class ElementGridAudit final : public tvm::tirx::StmtExprVisitor {
private:
    const luisa::vector<const tvm::tirx::ForNode *> &_axes;
    luisa::vector<const tvm::tirx::ForNode *> _domain;
    luisa::unordered_set<const tvm::tirx::VarNode *> _reads, _writes, _escaped;
    luisa::vector<const tvm::tirx::BufferStoreNode *> _stores;

    // The root parallel already promises independence between programs. What
    // fusion additionally needs is disjointness between two output loops for
    // arbitrary, INDEPENDENT local coordinates within the same program.
    [[nodiscard]] bool _disjoint(const tvm::tirx::BufferStoreNode *a,
                                 const tvm::tirx::BufferStoreNode *b) const {
        auto address = [&](const tvm::tirx::BufferStoreNode *store) -> std::optional<tvm::PrimExpr> {
            tvm::PrimExpr result = tvm::IntImm::Int64(0);
            for (auto i = 0u; i < store->indices.size(); i++) {
                auto index = store->indices[i], extent = store->buffer->shape[i];
                // In-bounds compact coordinates and the checked buffer volume
                // keep linearization in int64. Predicate-sensitive ranges and
                // noncompact layouts deliberately retain the original loops.
                if (index.ty() != tvm::PrimType::Int(64) ||
                    !prove_in_loop_domain(index >= tvm::IntImm::Int64(0) && index < extent, _domain)) { return {}; }
                result = result * extent + index;
            }
            return result;
        };
        auto left = address(a), right = address(b);
        if (!left || !right) { return false; }
        tvm::ffi::Array<tvm::tirx::For> fresh;
        tvm::ffi::Map<tvm::tirx::Var, tvm::Expr> rename;
        auto domain = _domain;
        for (auto axis : _axes) {
            auto variable = tvm::tirx::PrimVar{axis->loop_var->name + "_other_element", axis->loop_var.ty()};
            rename.Set(axis->loop_var, variable);
            fresh.push_back(tvm::tirx::For{variable, axis->min, axis->extent, tvm::tirx::ForKind::kSerial,
                                           tvm::tirx::Evaluate{tvm::IntImm::Int32(0)}});
            domain.emplace_back(fresh.back().get());
        }
        auto other = tvm::tirx::Substitute(*right, rename);
        return prove_in_loop_domain(*left < other, domain) || prove_in_loop_domain(other < *left, domain);
    }

protected:
    void VisitStmt(const tvm::tirx::Stmt &statement) final {
        if (!statement.as<tvm::tirx::BufferStoreNode>() && !statement.as<tvm::tirx::IfThenElseNode>() &&
            !statement.as<tvm::tirx::SeqStmtNode>() && !statement.as<tvm::tirx::EvaluateNode>() &&
            !statement.as<tvm::tirx::BindNode>()) {
            valid = false;
            return;
        }
        StmtExprVisitor::VisitStmt(statement);
    }
    void VisitExpr_(const tvm::tirx::VarNode *variable) final { _escaped.emplace(variable); }
    void VisitExpr_(const tvm::tirx::ProducerLoadNode *) final { valid = false; }
    void VisitExpr_(const tvm::CallNode *call) final {
        valid &= pure_element_call(call);
        StmtExprVisitor::VisitExpr_(call);
    }
    void VisitExpr_(const tvm::tirx::BufferLoadNode *load) final {
        valid &= load->buffer.scope() == "global";
        _reads.emplace(load->buffer.get());
        StmtExprVisitor::VisitExpr_(load);
        if (load->predicate) { VisitExpr(load->predicate.value()); }
    }
    void VisitStmt_(const tvm::tirx::BufferStoreNode *store) final {
        _writes.emplace(store->buffer.get());
        valid &= store->buffer.scope() == "global";
        // Coordinate injectivity implies address injectivity only for this
        // compact buffer family. Arbitrary strides/layouts need their own
        // address-map proof before they may participate in fusion.
        valid &= store->buffer->strides.empty() && !store->buffer->layout &&
                 store->buffer->allocated_addr.empty() &&
                 store->indices.size() == store->buffer->shape.size();
        auto offset = store->buffer->elem_offset.as<tvm::IntImmNode>();
        valid &= offset && offset->value == 0;
        auto output_volume = uint64_t{1u};
        for (auto &extent : store->buffer->shape) {
            auto size = extent.as<tvm::IntImmNode>();
            if (!size || size->value <= 0 || output_volume > INT64_MAX / static_cast<uint64_t>(size->value)) {
                valid = false;
                break;
            }
            output_volume *= static_cast<uint64_t>(size->value);
        }
        tvm::ffi::Map<tvm::tirx::Var, tvm::Expr> origin;
        for (auto axis : _axes) { origin.Set(axis->loop_var, axis->min); }
        // Prove injectivity inside one logical program independently of the
        // annotation: every nontrivial local coordinate has its own output
        // coordinate, with coefficient one and no other local dependence.
        for (auto axis : _axes) {
            if (axis->extent.as<tvm::IntImmNode>()->value == 1) { continue; }
            auto covered = false;
            for (auto &index : store->indices) {
                auto base = tvm::tirx::Substitute(index, origin);
                covered |= prove_in_loop_domain(index - base == axis->loop_var - axis->min, _domain);
            }
            valid &= covered;
        }
        if (valid) {
            // No operator names or shape tables: admit any statically proved
            // separated compact output intervals, in either source order.
            for (auto previous : _stores) {
                if (store->buffer.same_as(previous->buffer)) { valid &= _disjoint(previous, store); }
            }
        }
        _stores.emplace_back(store);
        StmtExprVisitor::VisitStmt_(store);
        if (store->predicate) { VisitExpr(store->predicate.value()); }
    }

public:
    bool valid{true};
    ElementGridAudit(const tvm::tirx::ForNode *root, const luisa::vector<const tvm::tirx::ForNode *> &axes)
        : _axes{axes}, _domain{root} { _domain.insert(_domain.end(), axes.begin(), axes.end()); }
    [[nodiscard]] bool run(const tvm::tirx::Stmt &body) {
        VisitStmt(body);
        for (auto buffer : _writes) { valid &= !_reads.contains(buffer) && !_escaped.contains(buffer); }
        for (auto buffer : _reads) { valid &= !_escaped.contains(buffer); }
        return valid && !_writes.empty();
    }
};

}// namespace

tvm::tirx::Stmt try_map_gpu_elementwise(const tvm::tirx::Stmt &body, uint32_t max_threads,
                                        const PlannerOptions &options, luisa::vector<GroupPlan> &plans,
                                        bool warp_align_threads) {
    auto root_statement = sole_effect(body);
    auto root = root_statement.as<tvm::tirx::ForNode>();
    if (!static_unit_domain(root) || root->annotations.size() != 1u + root->annotations.count(logical_program_shape_annotation) || !root->annotations.count(logical_parallel_annotation) ||
        max_threads == 0u || options.threads_per_group > max_threads) { return {}; }
    auto program = element_program(root);
    if (!program) { return {}; }
    auto &axes = program->domain.axes;
    auto &elements = program->domain.point;
    auto volume = program->domain.volume;
    auto programs = static_cast<uint64_t>(root->extent.as<tvm::IntImmNode>()->value);
    if (programs > INT64_MAX / volume || !ElementGridAudit{root, axes}.run(elements)) { return {}; }
    auto count = programs * volume;
    auto threads = options.threads_per_group ? options.threads_per_group : std::min<uint64_t>(count, std::min(max_threads, 256u));
    if (warp_align_threads) {
        // CUDA/NVPTX blocks must be warp aligned. Round a below-cap width up to
        // the 32-thread warp (padding lanes are guarded out below); if that
        // would exceed the hardware cap, round the unaligned cap down instead.
        constexpr auto cuda_warp_size = uint64_t{32u};
        auto aligned_up = ((threads + cuda_warp_size - 1u) / cuda_warp_size) * cuda_warp_size;
        threads = aligned_up <= max_threads ?
                      aligned_up :
                      threads / cuda_warp_size * cuda_warp_size;
        if (threads == 0u) { return {}; }
    }
    auto blocks = luisa::ceil_div(count, threads);
    if (blocks > INT64_MAX / threads) { return {}; }
    auto zero = tvm::IntImm::Int64(0);
    auto block = tvm::tirx::PrimVar{root->loop_var->name + "_element_block", tvm::PrimType::Int(64)};
    auto worker = tvm::tirx::PrimVar{root->loop_var->name + "_element_worker", tvm::PrimType::Int(64)};
    auto width = tvm::IntImm::Int64(static_cast<int64_t>(threads));
    auto linear = block * width + worker;
    auto tile_volume = tvm::IntImm::Int64(static_cast<int64_t>(volume));
    tvm::ffi::Map<tvm::tirx::Var, tvm::Expr> coordinates{{root->loop_var, root->min + tvm::floordiv(linear, tile_volume)}};
    auto local = tvm::floormod(linear, tile_volume);
    for (auto i = axes.size(); i != 0u; i--) {
        auto axis = axes[i - 1u];
        coordinates.Set(axis->loop_var, axis->min + tvm::floormod(local, axis->extent));
        local = tvm::floordiv(local, axis->extent);
    }
    auto result = tvm::tirx::Substitute(elements, coordinates);
    if (count % threads) { result = tvm::tirx::IfThenElse{linear < tvm::IntImm::Int64(static_cast<int64_t>(count)), std::move(result)}; }
    auto thread_axis = tvm::tirx::IterVar{tvm::Range::FromMinExtent(zero, width), worker, tvm::tirx::IterVarType::kThreadIndex, "threadIdx.x"};
    result = tvm::tirx::For{worker, zero, width, tvm::tirx::ForKind::kThreadBinding, std::move(result), thread_axis};
    auto block_count = tvm::IntImm::Int64(static_cast<int64_t>(blocks));
    auto block_axis = tvm::tirx::IterVar{tvm::Range::FromMinExtent(zero, block_count), block, tvm::tirx::IterVarType::kThreadIndex, "blockIdx.x"};
    result = tvm::tirx::For{block, zero, block_count, tvm::tirx::ForKind::kThreadBinding, std::move(result), block_axis};
    GroupPlan plan;
    plan.name = std::string{root->loop_var->name};
    plan.programs = programs;
    plan.threads = static_cast<uint32_t>(threads);
    plan.elementwise_elements_per_program = volume;
    plan.elementwise_scalar_temporaries = program->scalar_temporaries;
    plan.candidates_considered = 1u;
    plan.optimized = true;
    plans.emplace_back(std::move(plan));
    return result;
}

}// namespace luisa::compute::tile::bridge::tirx::detail

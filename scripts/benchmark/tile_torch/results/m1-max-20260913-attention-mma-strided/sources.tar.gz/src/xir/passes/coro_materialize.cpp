#include "helpers.h"
#include "coro_frame_abi.h"
#include "coro_packed_word.h"

#include <luisa/ast/type.h>
#include <luisa/core/logging.h>
#include <luisa/core/stl/algorithm.h>
#include <luisa/core/stl/format.h>
#include <luisa/core/stl/unordered_map.h>
#include <luisa/xir/argument.h>
#include <luisa/xir/basic_block.h>
#include <luisa/xir/builder.h>
#include <luisa/xir/constant.h>
#include <luisa/xir/function.h>
#include <luisa/xir/instructions/alloca.h>
#include <luisa/xir/instructions/coro.h>
#include <luisa/xir/instructions/gep.h>
#include <luisa/xir/instructions/load.h>
#include <luisa/xir/instructions/return.h>
#include <luisa/xir/instructions/store.h>
#include <luisa/xir/module.h>
#include <luisa/xir/passes/coro_cfg_distill.h>
#include <luisa/xir/passes/coro_materialize.h>
#include <luisa/xir/passes/coro_split.h>

#include <limits>

namespace luisa::compute::xir {

namespace detail {

static constexpr size_t FRAME_RESERVED_FIELD_COUNT =
    CORO_FRAME_RESERVED_FIELD_COUNT;
static constexpr uint32_t FRAME_FIELD_TOKEN_CMAT = 6u;

struct RegisterInfo {
    luisa::string name;
    const Type *type;
};

[[nodiscard]] static Value *find_frame_operand(CallableFunction *func) noexcept {
    if (func == nullptr || func->definition() == nullptr) { return nullptr; }
    Value *frame = nullptr;
    func->traverse_instructions([&](Instruction *inst) noexcept {
        if (frame != nullptr) { return; }
        switch (inst->derived_instruction_tag()) {
            case DerivedInstructionTag::CORO_SUSPEND:
                frame = static_cast<CoroSuspendInst *>(inst)->frame();
                break;
            case DerivedInstructionTag::CORO_RESUME:
                frame = static_cast<CoroResumeInst *>(inst)->frame();
                break;
            default:
                break;
        }
    });
    return frame;
}

[[nodiscard]] static bool is_token_store(Value *frame_arg, StoreInst *store) noexcept {
    auto *var = store->variable();
    if (!var->isa<Instruction>()) { return false; }
    auto *inst = static_cast<Instruction *>(var);
    if (inst->derived_instruction_tag() != DerivedInstructionTag::GEP) { return false; }
    auto *gep = static_cast<GEPInst *>(inst);
    if (gep->base() != frame_arg) { return false; }
    if (gep->index_count() != 1u) { return false; }
    auto *field_idx = gep->index(0u);
    uint64_t decoded_index = 0u;
    return try_decode_constant_nonnegative_integer(
               field_idx, decoded_index) &&
           decoded_index == FRAME_FIELD_TOKEN_CMAT;
}

[[nodiscard]] static bool collect_registers(
    const luisa::vector<CallableFunction *> &callables,
    luisa::vector<RegisterInfo> &regs,
    const luisa::unordered_set<luisa::string> *filter = nullptr) noexcept {
    luisa::unordered_map<luisa::string, const Type *> name_to_type;
    auto valid = true;
    for (auto *callable : callables) {
        if (callable == nullptr || callable->definition() == nullptr) {
            valid = false;
            continue;
        }
        luisa::unordered_set<luisa::string> local_names;
        auto *def = callable->definition();
        def->traverse_instructions([&](Instruction *inst) noexcept {
            if (inst->derived_instruction_tag() != DerivedInstructionTag::ALLOCA) { return; }
            auto *alloca = static_cast<AllocaInst *>(inst);
            if (!alloca->is_local()) { return; }
            auto name_opt = alloca->name();
            if (!name_opt.has_value()) { return; }
            luisa::string name(name_opt.value());
            if (filter != nullptr && !filter->contains(name)) { return; }
            // One frame field denotes one logical register. Two locals in the
            // same callable cannot share it, even if their types happen to
            // match. Across split callables the same logical name is allowed
            // only when its type is identical.
            if (!local_names.emplace(name).second) {
                valid = false;
                return;
            }
            auto [iter, inserted] =
                name_to_type.try_emplace(name, alloca->type());
            if (!inserted && iter->second != alloca->type()) {
                valid = false;
            }
        });
    }
    if (!valid) { return false; }
    regs.reserve(name_to_type.size());
    for (auto &[name, type] : name_to_type) {
        regs.push_back(RegisterInfo{.name = name, .type = type});
    }
    luisa::sort(regs.begin(), regs.end(), [](auto &a, auto &b) noexcept {
        return a.name < b.name;
    });
    return true;
}

[[nodiscard]] static const Type *build_frame_type(const luisa::vector<RegisterInfo> &regs) noexcept {
    luisa::vector<const Type *> fields;
    fields.reserve(FRAME_RESERVED_FIELD_COUNT + regs.size());
    for (auto i = 0u; i < FRAME_RESERVED_FIELD_COUNT; i++) {
        fields.push_back(Type::of<uint>());
    }
    for (auto &reg : regs) { fields.push_back(reg.type); }
    return Type::structure(fields);
}

[[nodiscard]] static luisa::unordered_map<luisa::string, size_t> build_field_map(
    const luisa::vector<RegisterInfo> &regs) noexcept {
    luisa::unordered_map<luisa::string, size_t> map;
    for (size_t i = 0u; i < regs.size(); ++i) {
        map.emplace(regs[i].name, FRAME_RESERVED_FIELD_COUNT + i);
    }
    return map;
}

[[nodiscard]] static bool frame_type_matches_cfg(Value *frame,
                                                 const CoroCfgDistillResult &cfg) noexcept {
    if (frame == nullptr || frame->type() == nullptr || !frame->type()->is_structure()) { return false; }
    auto members = frame->type()->members();
    if (members.size() != FRAME_RESERVED_FIELD_COUNT + cfg.frame_slots.size()) { return false; }
    for (auto i = 0u; i < FRAME_RESERVED_FIELD_COUNT; ++i) {
        if (members[i] != Type::of<uint>()) { return false; }
    }
    for (size_t i = 0u; i < cfg.frame_slots.size(); ++i) {
        if (cfg.frame_slots[i].type == nullptr ||
            members[FRAME_RESERVED_FIELD_COUNT + i] != cfg.frame_slots[i].type) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] static bool validate_cfg_trigger_tokens(const CoroCfgDistillResult &cfg) noexcept {
    if (!cfg.succeeded() || cfg.scopes.empty()) { return false; }
    luisa::unordered_set<uint32_t> tokens;
    for (size_t i = 0u; i < cfg.scopes.size(); ++i) {
        auto token = cfg.scopes[i].trigger_token;
        if ((i == 0u && token != 0u) ||
            (i != 0u && (token == 0u || token == TERMINAL_TOKEN)) ||
            !tokens.emplace(token).second) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] static bool validate_materialize_frame(
    CallableFunction *callable, Value *frame,
    const Type *expected_type) noexcept {
    if (callable == nullptr || callable->definition() == nullptr ||
        frame == nullptr || !frame->isa<Argument>() ||
        frame->type() != expected_type) {
        return false;
    }
    auto *argument = static_cast<Argument *>(frame);
    if (!argument->is_reference() ||
        argument->parent_function() != callable) {
        return false;
    }
    auto valid = true;
    callable->traverse_instructions([&](Instruction *inst) noexcept {
        switch (inst->derived_instruction_tag()) {
            case DerivedInstructionTag::CORO_SUSPEND:
                valid &= static_cast<CoroSuspendInst *>(inst)->frame() ==
                         frame;
                break;
            case DerivedInstructionTag::CORO_RESUME:
                valid &= static_cast<CoroResumeInst *>(inst)->frame() ==
                         frame;
                break;
            default: break;
        }
    });
    return valid;
}

static void coro_materialize_clone_metadata(const MetadataListMixin &source,
                           MetadataListMixin &target) noexcept {
    for (auto *metadata : source.metadata_list()) {
        target.metadata_list().push_front(metadata->clone());
    }
}

static void coro_materialize_clone_instruction_metadata(
    const Instruction *source, Instruction *target) noexcept {
    if (source == nullptr || target == nullptr) { return; }
    coro_materialize_clone_metadata(*source, *target);
}

[[nodiscard]] static bool validate_resume_boundary(
    CallableFunction *callable, uint32_t trigger_token) noexcept {
    if (callable == nullptr || callable->definition() == nullptr) {
        return false;
    }
    auto resume_count = 0u;
    auto valid = true;
    callable->traverse_instructions([&](Instruction *inst) noexcept {
        if (!inst->isa<CoroResumeInst>()) { return; }
        ++resume_count;
        valid &= trigger_token != 0u &&
                 static_cast<CoroResumeInst *>(inst)->token() ==
                     trigger_token;
    });
    return valid &&
           resume_count == (trigger_token == 0u ? 0u : 1u);
}

static void store_user_vars_to_frame(XIRBuilder &b, Module *mod, Value *frame_arg,
                                     const luisa::vector<RegisterInfo> &regs,
                                     const luisa::unordered_map<luisa::string, size_t> &field_map,
                                     const luisa::unordered_map<luisa::string, Value *> &local_map,
                                     const luisa::unordered_set<luisa::string> *live_filter,
                                     size_t &count) noexcept {
    for (auto &reg : regs) {
        if (live_filter != nullptr && !live_filter->contains(reg.name)) { continue; }
        auto it = local_map.find(reg.name);
        if (it == local_map.end()) { continue; }
        auto *local_val = it->second;
        auto fi = field_map.at(reg.name);
        LUISA_ASSERT(fi <= std::numeric_limits<uint32_t>::max(),
                     "Coroutine frame field index is not representable.");
        auto field_index = static_cast<uint32_t>(fi);
        auto *idx_c =
            mod->create_constant(Type::of<uint32_t>(), &field_index);
        auto *gep = b.gep(reg.type, frame_arg, {idx_c});
        if (local_val->isa<AllocaInst>()) {
            auto *loaded = b.load(reg.type, local_val);
            b.store(gep, loaded);
        } else {
            b.store(gep, local_val);
        }
        count++;
    }
}

static void load_user_vars_from_frame(XIRBuilder &b, Module *mod, Value *frame_arg,
                                      const luisa::vector<RegisterInfo> &regs,
                                      const luisa::unordered_map<luisa::string, size_t> &field_map,
                                      const luisa::unordered_map<luisa::string, Value *> &local_map,
                                      const luisa::unordered_set<luisa::string> *live_filter,
                                      size_t &count) noexcept {
    for (auto &reg : regs) {
        if (live_filter != nullptr && !live_filter->contains(reg.name)) { continue; }
        auto it = local_map.find(reg.name);
        if (it == local_map.end()) { continue; }
        auto *local_val = it->second;
        auto fi = field_map.at(reg.name);
        LUISA_ASSERT(fi <= std::numeric_limits<uint32_t>::max(),
                     "Coroutine frame field index is not representable.");
        auto field_index = static_cast<uint32_t>(fi);
        auto *idx_c =
            mod->create_constant(Type::of<uint32_t>(), &field_index);
        auto *gep = b.gep(reg.type, frame_arg, {idx_c});
        auto *loaded = b.load(reg.type, gep);
        if (local_val->isa<AllocaInst>()) {
            b.store(local_val, loaded);
        }
        count++;
    }
}

static void process_callable(Module *mod, CallableFunction *func, Value *frame_arg,
                             const luisa::vector<RegisterInfo> &regs,
                             const luisa::unordered_map<luisa::string, size_t> &field_map,
                             const luisa::unordered_set<luisa::string> *live_in,
                             const luisa::unordered_set<luisa::string> *live_out,
                             bool materialize_user_vars,
                             CoroMaterializeInfo &info) noexcept {

    if (func == nullptr || func->definition() == nullptr || frame_arg == nullptr) { return; }

    luisa::unordered_map<luisa::string, Value *> local_map;
    func->traverse_instructions([&](Instruction *inst) noexcept {
        if (inst->derived_instruction_tag() == DerivedInstructionTag::ALLOCA) {
            auto *alloca = static_cast<AllocaInst *>(inst);
            if (!alloca->is_local()) { return; }
            auto name_opt = alloca->name();
            if (name_opt.has_value()) {
                local_map.emplace(name_opt.value(), alloca);
            }
        }
    });
    XIRBuilder b;

    luisa::vector<CoroSuspendInst *> suspends;
    func->traverse_instructions([&](Instruction *inst) noexcept {
        if (inst->derived_instruction_tag() == DerivedInstructionTag::CORO_SUSPEND) {
            suspends.push_back(static_cast<CoroSuspendInst *>(inst));
        }
    });
    for (auto *s : suspends) {
        auto token = s->token();
        auto *prev = s->prev();
        if (prev != nullptr && !prev->is_sentinel()) {
            b.set_insertion_point(prev);
        } else {
            b.set_insertion_point(s->parent_block());
        }
        if (materialize_user_vars) {
            store_user_vars_to_frame(b, mod, frame_arg, regs, field_map, local_map,
                                     live_out, info.store_inserted_count);
        }

        auto *field_token = mod->create_constant(Type::of<uint32_t>(), &FRAME_FIELD_TOKEN_CMAT);
        auto *gep0 = b.gep(Type::of<uint32_t>(), frame_arg, {field_token});
        auto *tok_c = mod->create_constant(Type::of<uint32_t>(), &token);
        b.store(gep0, tok_c);
        auto *replacement = b.return_void();
        coro_materialize_clone_instruction_metadata(s, replacement);
        s->remove_self();
        info.suspend_lowered_count++;
    }

    luisa::vector<CoroTerminateInst *> terms;
    func->traverse_instructions([&](Instruction *inst) noexcept {
        if (inst->derived_instruction_tag() == DerivedInstructionTag::CORO_TERMINATE) {
            terms.push_back(static_cast<CoroTerminateInst *>(inst));
        }
    });
    for (auto *t : terms) {
        auto *prev = t->prev();
        if (prev != nullptr && !prev->is_sentinel()) {
            b.set_insertion_point(prev);
        } else {
            b.set_insertion_point(t->parent_block());
        }
        auto *field_token = mod->create_constant(Type::of<uint32_t>(), &FRAME_FIELD_TOKEN_CMAT);
        auto *gep0 = b.gep(Type::of<uint32_t>(), frame_arg, {field_token});
        auto term_tok = TERMINAL_TOKEN;
        auto *term_c = mod->create_constant(Type::of<uint32_t>(), &term_tok);
        b.store(gep0, term_c);
        auto *replacement = b.return_void();
        coro_materialize_clone_instruction_metadata(t, replacement);
        t->remove_self();
        info.terminal_lowered_count++;
    }

    size_t token_store_count = 0;
    if (suspends.empty()) {
        luisa::vector<StoreInst *> token_stores;
        func->traverse_instructions([&](Instruction *inst) noexcept {
            if (inst->derived_instruction_tag() == DerivedInstructionTag::STORE) {
                auto *store = static_cast<StoreInst *>(inst);
                if (is_token_store(frame_arg, store)) {
                    token_stores.push_back(store);
                }
            }
        });
        for (auto *ts : token_stores) {
            auto *prev = ts->prev();
            if (prev != nullptr && !prev->is_sentinel()) {
                b.set_insertion_point(prev);
            } else {
                b.set_insertion_point(ts->parent_block());
            }
            if (materialize_user_vars) {
                store_user_vars_to_frame(b, mod, frame_arg, regs, field_map, local_map,
                                         live_out, info.store_inserted_count);
            }
        }
    }

    luisa::vector<CoroResumeInst *> resumes;
    func->traverse_instructions([&](Instruction *inst) noexcept {
        if (inst->derived_instruction_tag() == DerivedInstructionTag::CORO_RESUME) {
            resumes.push_back(static_cast<CoroResumeInst *>(inst));
        }
    });
    for (auto *r : resumes) {
        b.set_insertion_point(r);
        if (materialize_user_vars) {
            load_user_vars_from_frame(b, mod, frame_arg, regs, field_map, local_map,
                                      live_in, info.load_inserted_count);
        }
        // Resume has no runtime operation after materialization. Its parent
        // block is the unique continuation-entry boundary, so it owns the
        // source provenance once the marker is removed.
        coro_materialize_clone_metadata(*r, *r->parent_block());
        r->remove_self();
        info.resume_lowered_count++;
    }
}

[[nodiscard]] static luisa::unordered_set<luisa::string> collect_live_register_names(
    const CoroCfgDistillResult *cfg) noexcept {
    luisa::unordered_set<luisa::string> names;
    if (cfg == nullptr) { return names; }
    for (auto &scope : cfg->scopes) {
        for (auto &name : scope.live_in_variables) { names.emplace(name); }
        for (auto &name : scope.live_out_variables) { names.emplace(name); }
    }
    return names;
}

static void append_field_indices(luisa::vector<size_t> &dst,
                                 const luisa::vector<luisa::string> &names,
                                 const luisa::unordered_map<luisa::string, size_t> &field_map) noexcept {
    luisa::unordered_set<size_t> seen;
    for (auto &name : names) {
        if (auto it = field_map.find(name); it != field_map.end()) {
            if (seen.emplace(it->second).second) {
                dst.emplace_back(it->second);
            }
        }
    }
    luisa::sort(dst.begin(), dst.end());
}

static void populate_transition_edges(CoroMaterializeInfo &info,
                                      const CoroCfgDistillResult *cfg,
                                      const luisa::unordered_map<luisa::string, size_t> &field_map) noexcept {
    if (cfg == nullptr) { return; }
    info.edges.clear();
    for (size_t from = 0u; from < cfg->edges.size(); ++from) {
        for (auto to : cfg->edges[from]) {
            if (to >= cfg->scopes.size()) { continue; }
            CoroMaterializeInfo::TransitionEdge edge;
            edge.from_scope = from;
            edge.to_scope = to;
            append_field_indices(edge.store_fields, cfg->scopes[from].live_out_variables, field_map);
            append_field_indices(edge.load_fields, cfg->scopes[to].live_in_variables, field_map);
            info.edges.emplace_back(std::move(edge));
        }
    }
}

static void append_frame_value_field_indices(
    luisa::vector<size_t> &dst,
    luisa::span<const size_t> frame_value_indices,
    const CoroCfgDistillResult &cfg) noexcept {
    luisa::unordered_set<size_t> seen{dst.begin(), dst.end()};
    for (auto frame_value_index : frame_value_indices) {
        if (frame_value_index >= cfg.frame_values.size()) { continue; }
        auto field_index = FRAME_RESERVED_FIELD_COUNT +
                           cfg.frame_values[frame_value_index].slot;
        if (seen.emplace(field_index).second) {
            dst.emplace_back(field_index);
        }
    }
    luisa::sort(dst.begin(), dst.end());
}

[[nodiscard]] static luisa::vector<luisa::vector<size_t>>
collect_partial_packed_word_input_fields(
    const CoroCfgDistillResult &cfg) noexcept {
    // A packed word is an indivisible physical transfer resource even though
    // its logical Boolean values are independently live. For an outgoing
    // edge e and physical word w, let D(e, w) be the mask of lanes stored by
    // the continuation and L(e, w) the mask live after the transition. The
    // split callable performs a read-modify-write when D is non-empty. It
    // therefore needs the old physical word at entry exactly when
    //
    //     D(e, w) != 0 and (L(e, w) - D(e, w)) != 0.
    //
    // The second term denotes lanes that must pass through unchanged. Logical
    // live-in alone is insufficient: a continuation need not evaluate those
    // dormant values, while a compacting scheduler still has to preserve
    // their bits during the whole-word store.
    luisa::vector<luisa::vector<size_t>> fields(cfg.scopes.size());
    for (auto &transition : cfg.transition_edges) {
        if (transition.from_scope >= fields.size()) { continue; }
        auto masks = coro_packed_word_masks(
            cfg, transition.store_frame_value_indices,
            transition.live_frame_value_indices);
        auto &scope_fields = fields[transition.from_scope];
        for (size_t slot = 0u; slot < masks.size(); ++slot) {
            if (masks[slot].stored != 0u && masks[slot].preserved != 0u) {
                auto field = FRAME_RESERVED_FIELD_COUNT + slot;
                if (std::find(scope_fields.begin(), scope_fields.end(), field) ==
                    scope_fields.end()) {
                    scope_fields.emplace_back(field);
                }
            }
        }
    }
    for (auto &scope_fields : fields) {
        luisa::sort(scope_fields.begin(), scope_fields.end());
    }
    return fields;
}

static void populate_value_transition_edges(CoroMaterializeInfo &info,
                                            const CoroCfgDistillResult &cfg) noexcept {
    info.edges.clear();
    auto partial_word_inputs =
        collect_partial_packed_word_input_fields(cfg);
    for (auto &transition : cfg.transition_edges) {
        if (transition.to_scope >= cfg.scopes.size()) { continue; }
        CoroMaterializeInfo::TransitionEdge edge;
        edge.from_scope = transition.from_scope;
        edge.to_scope = transition.to_scope;
        append_frame_value_field_indices(
            edge.store_fields, transition.store_frame_value_indices, cfg);
        append_frame_value_field_indices(
            edge.load_fields,
            cfg.scopes[transition.to_scope].live_in_frame_value_indices,
            cfg);
        if (transition.to_scope < partial_word_inputs.size()) {
            auto &preserved = partial_word_inputs[transition.to_scope];
            for (auto field : preserved) {
                if (std::find(edge.load_fields.begin(), edge.load_fields.end(),
                              field) == edge.load_fields.end()) {
                    edge.load_fields.emplace_back(field);
                }
            }
            luisa::sort(edge.load_fields.begin(), edge.load_fields.end());
        }
        info.edges.emplace_back(std::move(edge));
    }
}

[[nodiscard]] static luisa::vector<luisa::unordered_set<luisa::string>> make_scope_live_sets(
    const CoroCfgDistillResult *cfg, bool live_in) noexcept {
    luisa::vector<luisa::unordered_set<luisa::string>> sets;
    if (cfg == nullptr) { return sets; }
    sets.reserve(cfg->scopes.size());
    for (auto &scope : cfg->scopes) {
        auto &set = sets.emplace_back();
        auto &names = live_in ? scope.live_in_variables : scope.live_out_variables;
        for (auto &name : names) { set.emplace(name); }
    }
    return sets;
}

[[nodiscard]] static luisa::vector<CallableFunction *> collect_materialize_callables(
    Module *module) noexcept {
    luisa::vector<CallableFunction *> callables;
    if (module == nullptr) { return callables; }
    for (auto *function : module->function_list()) {
        if (function->isa<CallableFunction>() && function->definition() != nullptr) {
            auto *callable = static_cast<CallableFunction *>(function);
            if (find_frame_operand(callable) != nullptr) {
                callables.emplace_back(callable);
            }
        }
    }
    return callables;
}

[[nodiscard]] static size_t count_structured_inputs(
    const CoroCfgDistillResult *cfg,
    const luisa::vector<CallableFunction *> &callables) noexcept {
    size_t count = 0u;
    luisa::unordered_set<FunctionDefinition *> definitions;
    if (cfg != nullptr) {
        for (auto &scope : cfg->scopes) {
            for (auto *block : scope.blocks) {
                if (block == nullptr) { continue; }
                auto *parent = block->parent_function();
                if (parent != nullptr && parent->definition() != nullptr) {
                    definitions.emplace(parent->definition());
                }
            }
        }
    }
    for (auto *callable : callables) {
        if (callable != nullptr && callable->definition() != nullptr) {
            definitions.emplace(callable->definition());
        }
    }
    for (auto *definition : definitions) {
        if (contains_structured_control_flow(definition)) {
            ++count;
        }
    }
    return count;
}

static void warn_structured_rejection(size_t count) noexcept {
    LUISA_WARNING_WITH_LOCATION(
        "Coro materialize rejected {} function definition(s) with structured or ambiguous "
        "CFG; run destructure_cfg first. The module "
        "was left unchanged.",
        count);
}

}// namespace detail

CoroMaterializeInfo coro_materialize_pass_run_on_module(Module *m) noexcept {
    CoroMaterializeInfo info;
    if (m == nullptr) { return info; }

    auto callables = detail::collect_materialize_callables(m);
    // Preflight the complete worklist before collecting/materializing the
    // first callable so a rejection cannot leave a partially mutated module.
    info.structured_cfg_error_count = detail::count_structured_inputs(nullptr, callables);
    if (info.structured_cfg_error_count != 0u) {
        detail::warn_structured_rejection(info.structured_cfg_error_count);
        return info;
    }

    luisa::vector<detail::RegisterInfo> regs;
    if (!detail::collect_registers(callables, regs)) {
        info.invalid_input_error_count = 1u;
        LUISA_WARNING_WITH_LOCATION(
            "Coro materialize rejected duplicate or type-inconsistent "
            "register names. The module was left unchanged.");
        return info;
    }
    auto *expected_frame_type = detail::build_frame_type(regs);
    for (auto *func : callables) {
        if (!detail::validate_materialize_frame(
                func, detail::find_frame_operand(func),
                expected_frame_type)) {
            ++info.invalid_input_error_count;
        }
    }
    if (info.invalid_input_error_count != 0u) {
        LUISA_WARNING_WITH_LOCATION(
            "Coro materialize rejected {} callable(s) with an invalid or "
            "inconsistent frame. The module was left unchanged.",
            info.invalid_input_error_count);
        return info;
    }
    info.register_count = regs.size();
    for (const auto &reg : regs) {
        info.name_to_type.emplace(reg.name, reg.type);
    }

    auto field_map = detail::build_field_map(regs);
    info.name_to_field = field_map;
    info.frame_field_count = detail::FRAME_RESERVED_FIELD_COUNT + regs.size();
    info.frame_fields.reserve(regs.size());
    for (size_t i = 0u; i < regs.size(); ++i) {
        info.frame_fields.emplace_back(CoroMaterializeInfo::FrameField{
            .name = regs[i].name,
            .type = regs[i].type,
            .index = detail::FRAME_RESERVED_FIELD_COUNT + i,
        });
    }

    for (auto *func : callables) {
        detail::process_callable(m, func, detail::find_frame_operand(func), regs, field_map, nullptr, nullptr, true, info);
        info.callable_count++;
    }

    return info;
}

CoroMaterializeInfo coro_materialize_pass_run_on_module_with_cfg(
    Module *m, const CoroCfgDistillResult &cfg) noexcept {
    CoroMaterializeInfo info;
    if (m == nullptr) { return info; }
    if (!detail::validate_cfg_trigger_tokens(cfg)) {
        info.invalid_input_error_count = 1u;
        return info;
    }
    auto callables = detail::collect_materialize_callables(m);
    info.structured_cfg_error_count = detail::count_structured_inputs(&cfg, callables);
    if (info.structured_cfg_error_count != 0u) {
        detail::warn_structured_rejection(info.structured_cfg_error_count);
        return info;
    }
    return coro_materialize_pass_run_on_module(m);
}

CoroMaterializeInfo coro_materialize_pass_run_on_module_with_cfg(
    Module *m, const CoroCfgDistillResult &cfg, const CoroSplitInfo &split) noexcept {
    CoroMaterializeInfo info;
    if (m == nullptr) { return info; }
    info.structured_cfg_error_count = split.structured_cfg_error_count;
    info.invalid_input_error_count = split.invalid_cfg_error_count;
    if (!detail::validate_cfg_trigger_tokens(cfg)) {
        ++info.invalid_input_error_count;
    }

    // Validate the complete request before projecting it by scope index. Doing
    // this after projection would let a duplicate or out-of-range entry hide a
    // malformed/structured callable and would break all-or-nothing rejection.
    luisa::vector<CallableFunction *> requested_callables;
    requested_callables.reserve(split.subroutines.size());
    luisa::unordered_set<size_t> seen_scope_indices;
    luisa::unordered_set<CallableFunction *> seen_callables;
    for (auto &subroutine : split.subroutines) {
        auto valid = true;
        if (subroutine.scope_index >= cfg.scopes.size() ||
            !seen_scope_indices.emplace(subroutine.scope_index).second) {
            valid = false;
        }
        auto *callable = subroutine.callable;
        if (callable == nullptr || callable->definition() == nullptr ||
            callable->parent_module() != m) {
            valid = false;
        } else {
            requested_callables.emplace_back(callable);
            if (!seen_callables.emplace(callable).second) { valid = false; }
        }
        auto *frame = subroutine.frame_argument;
        if (frame == nullptr || !frame->isa<Argument>()) {
            valid = false;
        } else {
            auto *argument = static_cast<Argument *>(frame);
            if (!argument->is_reference() || argument->parent_function() != callable) {
                valid = false;
            }
        }
        if (!detail::frame_type_matches_cfg(frame, cfg)) { valid = false; }
        if (callable != nullptr && frame != nullptr &&
            !detail::validate_materialize_frame(
                callable, frame, frame->type())) {
            valid = false;
        }
        if (subroutine.scope_index < cfg.scopes.size() &&
            subroutine.trigger_token != cfg.scopes[subroutine.scope_index].trigger_token) {
            valid = false;
        }
        if (subroutine.scope_index < cfg.scopes.size() &&
            callable != nullptr &&
            !detail::validate_resume_boundary(
                callable,
                cfg.scopes[subroutine.scope_index].trigger_token)) {
            valid = false;
        }
        if (!valid) {
            ++info.invalid_input_error_count;
        }
    }
    if (!cfg.scopes.empty() && seen_scope_indices.size() != cfg.scopes.size()) {
        ++info.invalid_input_error_count;
    }

    auto detected_structured_count = detail::count_structured_inputs(&cfg, requested_callables);
    if (detected_structured_count > info.structured_cfg_error_count) {
        info.structured_cfg_error_count = detected_structured_count;
    }
    if (!info.succeeded()) {
        if (info.structured_cfg_error_count != 0u) {
            detail::warn_structured_rejection(info.structured_cfg_error_count);
        }
        if (info.invalid_input_error_count != 0u) {
            LUISA_WARNING_WITH_LOCATION(
                "Coro materialize rejected invalid coro-split metadata. "
                "The module was left unchanged.");
        }
        return info;
    }

    luisa::vector<const CoroSplitInfo::Subroutine *> subroutines(cfg.scopes.size(), nullptr);
    for (auto &subroutine : split.subroutines) {
        subroutines[subroutine.scope_index] = &subroutine;
    }
    info.register_count = cfg.frame_values.size();
    info.frame_field_count = detail::FRAME_RESERVED_FIELD_COUNT + cfg.frame_slots.size();
    info.frame_fields.reserve(cfg.frame_slots.size());
    luisa::unordered_set<luisa::string> used_names;
    for (size_t i = 0u; i < cfg.frame_slots.size(); ++i) {
        auto &slot = cfg.frame_slots[i];
        auto field_index = i + detail::FRAME_RESERVED_FIELD_COUNT;
        auto name = slot.name;
        if (!used_names.emplace(name).second) {
            auto base = name;
            auto suffix = i;
            do {
                name = luisa::format("{}#{}", base, suffix++);
            } while (!used_names.emplace(name).second);
        }
        info.frame_fields.emplace_back(CoroMaterializeInfo::FrameField{
            .name = name,
            .type = slot.type,
            .index = field_index,
        });
        info.name_to_field.emplace(name, field_index);
        info.name_to_type.emplace(name, slot.type);
    }
    for (auto &value : cfg.frame_values) {
        auto field_index =
            detail::FRAME_RESERVED_FIELD_COUNT + value.slot;
        auto *physical_type = cfg.frame_slots[value.slot].type;
        auto [field_iter, field_inserted] =
            info.name_to_field.emplace(value.name, field_index);
        auto [type_iter, type_inserted] =
            info.name_to_type.emplace(value.name, physical_type);
        LUISA_ASSERT(
            (field_inserted || field_iter->second == field_index) &&
                (type_inserted || type_iter->second == physical_type),
            "Coroutine logical frame alias '{}' is inconsistent with its "
            "physical slot.",
            value.name);
        for (auto &alias : value.aliases) {
            auto [alias_field_iter, alias_field_inserted] =
                info.name_to_field.emplace(alias, field_index);
            auto [alias_type_iter, alias_type_inserted] =
                info.name_to_type.emplace(alias, physical_type);
            LUISA_ASSERT(
                (alias_field_inserted ||
                 alias_field_iter->second == field_index) &&
                    (alias_type_inserted ||
                     alias_type_iter->second == physical_type),
                "Coroutine designated frame alias '{}' is inconsistent "
                "with its physical slot.",
                alias);
        }
    }
    detail::populate_value_transition_edges(info, cfg);

    for (auto *subroutine : subroutines) {
        if (subroutine == nullptr) { continue; }
        detail::process_callable(m, subroutine->callable, subroutine->frame_argument,
                                 {}, {}, nullptr, nullptr, false, info);
        info.callable_count++;
    }

    return info;
}

}// namespace luisa::compute::xir

#include <luisa/core/logging.h>
#include <luisa/ast/type.h>
#include <luisa/xir/module.h>
#include <luisa/xir/function.h>
#include <luisa/xir/builder.h>
#include <luisa/xir/instructions/call.h>
#include <luisa/xir/instructions/gep.h>
#include <luisa/xir/passes/call_graph.h>
#include <luisa/xir/passes/promote_ref_arg.h>
#include <luisa/xir/passes/pass_pipeline.h>
#include <luisa/xir/metadata/comment.h>
#include <luisa/xir/metadata/signature_constraint.h>

#include "helpers.h"

namespace luisa::compute::xir {

namespace detail {

// checks if a function is a promotable callable, i.e., it is a callable function and all of its uses are call instructions
[[nodiscard]] static auto is_promotable_callable(FunctionDefinition *f) noexcept {
    if (f == nullptr || f->body_block() == nullptr) { return false; }
    // we may not process non-callable functions as their signatures might be imported/exported
    if (!f->isa<CallableFunction>()) { return false; }
    // A root callable has no call site at which to materialize the snapshot,
    // and its signature may be consumed outside this module. Rewriting it is
    // both unprofitable and outside this pass's closed-world proof.
    if (f->use_list().empty()) { return false; }
    // if the function has a signature constraint, we cannot modify its signature
    if (f->find_metadata<SignatureConstraintMD>() != nullptr) { return false; }
    // otherwise, we check if all users of the callable are CallInst (non-call instructions
    // such as RayQueryPipelineInst may not allow changes to callee functions' signatures)
    for (auto &&use : f->use_list()) {
        auto *user = use->user();
        if (user == nullptr || !user->isa<CallInst>()) {
            return false;
        }
        auto *call = static_cast<CallInst *>(user);
        if (call->callee() != f ||
            use != call->operand_use(CallInst::operand_index_callee)) {
            return false;
        }
    }
    return true;
}

static void traverse_call_graph_post_order(Function *f, const CallGraph &call_graph,
                                           luisa::unordered_set<Function *> &visited,
                                           luisa::vector<CallableFunction *> &post_order) noexcept {
    if (visited.emplace(f).second) {
        if (auto def = f->definition()) {
            auto edges = call_graph.call_edges(def);
            for (auto &&call : edges) {
                traverse_call_graph_post_order(call->callee(), call_graph, visited, post_order);
            }
            if (is_promotable_callable(def)) {
                post_order.emplace_back(static_cast<CallableFunction *>(def));
            }
        }
    }
}

// Effects and snapshot legality are separate proofs. A leaf's reference may
// remain unpromoted because its actuals are unknown caller references, while
// still being read-only through every nested use. Propagate that read-only
// fact without assuming that distinct reference formals cannot alias.
class ReadonlyPointerAnalysis {
private:
    enum class State { visiting, readonly, may_write };
    luisa::unordered_map<Value *, State> _states;

    [[nodiscard]] bool call_use_is_readonly(CallInst *call, Use *use) noexcept {
        if (call->operand_count() == 0u) { return false; }
        auto *callee_value = call->operand(CallInst::operand_index_callee);
        if (callee_value == nullptr || !callee_value->isa<Function>()) { return false; }
        auto *callee = static_cast<Function *>(callee_value)->definition();
        if (callee == nullptr || callee->body_block() == nullptr ||
            call->argument_count() != callee->arguments().count_size()) {
            return false;
        }
        auto index = size_t{0u};
        for (auto *argument : callee->arguments()) {
            if (call->argument_uses()[index] == use) {
                return argument->is_reference() && is_readonly(argument);
            }
            ++index;
        }
        return false;
    }

    [[nodiscard]] bool check_uses(Value *pointer) noexcept {
        for (auto *use : pointer->use_list()) {
            auto *user = use->user();
            if (user == nullptr) { continue; }
            if (!user->isa<Instruction>()) { return false; }
            switch (static_cast<Instruction *>(user)->derived_instruction_tag()) {
                case DerivedInstructionTag::LOAD:
                case DerivedInstructionTag::RAY_QUERY_OBJECT_READ: break;
                case DerivedInstructionTag::GEP: {
                    auto *gep = static_cast<GEPInst *>(user);
                    if (gep->base() != pointer || !is_readonly(gep)) { return false; }
                    break;
                }
                case DerivedInstructionTag::CALL: {
                    if (!call_use_is_readonly(static_cast<CallInst *>(user), use)) {
                        return false;
                    }
                    break;
                }
                default: return false;
            }
        }
        return true;
    }

public:
    [[nodiscard]] bool is_readonly(Value *pointer) noexcept {
        if (auto it = _states.find(pointer); it != _states.end()) {
            // An unresolved recursive effect remains conservative; do not
            // manufacture a read-only fixed point for a recursive SCC.
            return it->second == State::readonly;
        }
        _states.emplace(pointer, State::visiting);
        auto readonly = check_uses(pointer);
        _states[pointer] = readonly ? State::readonly : State::may_write;
        return readonly;
    }
};

[[nodiscard]] static Argument *promote_ref_arg(CallableFunction *f, Argument *arg) noexcept {
    // create a new value argument
    auto new_arg = arg->insert_after_self(f->create_value_argument(arg->type())->remove_self());
    // The new value argument is the unique signature-level replacement for
    // the old reference argument, so it inherits the old argument metadata.
    for (auto *metadata : arg->metadata_list()) {
        new_arg->metadata_list().push_front(metadata->clone());
    }
    new_arg->add_comment("promoted reference argument");
    // we need to create a local variable to hold the value of the reference argument
    {
        XIRBuilder b;
        b.set_insertion_point(f->body_block()->instructions().head_sentinel());
        auto local = b.alloca_local(arg->type());
        b.store(local, new_arg);
        arg->replace_all_uses_with(local);
    }
    // now we can remove the original reference argument
    arg->remove_self();
    return new_arg;
}

struct PromotedArg {
    Argument *arg;
    size_t index;
};

[[nodiscard]] static bool all_call_sites_prove_snapshot_safe(
    CallableFunction *f, PromotedArg candidate,
    luisa::span<const PromotedArg> writable_args) noexcept {
    for (auto &&use : f->use_list()) {
        auto *user = use->user();
        if (user == nullptr || !user->isa<CallInst>()) {
            return false;
        }
        auto *call = static_cast<CallInst *>(user);
        if (call->callee() != f ||
            use != call->operand_use(CallInst::operand_index_callee) ||
            call->argument_count() != f->arguments().count_size()) {
            return false;
        }
        if (candidate.index >= call->argument_count()) { return false; }
        auto *candidate_root = trace_pointer_base_local_alloca_inst(
            call->argument(candidate.index));
        if (candidate_root == nullptr) { return false; }
        for (auto writable : writable_args) {
            if (writable.index >= call->argument_count()) { return false; }
            auto *writable_root = trace_pointer_base_local_alloca_inst(
                call->argument(writable.index));
            // Distinct local allocas cannot alias. Unknown roots and GEPs of
            // the same root remain conservative: a callee write may otherwise
            // be observed by a later load through the candidate reference.
            if (writable_root == nullptr || writable_root == candidate_root) {
                return false;
            }
        }
    }
    return true;
}

static void promote_ref_args_in_function(CallableFunction *f, PromoteRefArgInfo &info) {
    // All effect queries precede this function's mutation. Discard the cache
    // afterwards: signature promotion rewrites uses in callers and callees.
    ReadonlyPointerAnalysis readonly;
    // Collect recursively read-only candidates and references that may be
    // written. A syntactically read-only reference is not immutable when a
    // writable reference aliases it, so promotion additionally needs a
    // call-site no-alias proof below.
    luisa::fixed_vector<PromotedArg, 16> candidates;
    luisa::fixed_vector<PromotedArg, 16> writable_args;
    {
        size_t index = 0;
        for (auto arg : f->arguments()) {
            if (arg->is_reference()) {
                auto ref = PromotedArg{
                    .arg = static_cast<ReferenceArgument *>(arg),
                    .index = index};
                if (readonly.is_readonly(arg)) {
                    if (!arg->type()->is_custom()) {
                        candidates.emplace_back(ref);
                    }
                } else {
                    writable_args.emplace_back(ref);
                }
            }
            index++;
        }
    }
    if (candidates.empty()) { return; }
    // Promotion snapshots a reference once at the call site. This is only
    // equivalent for thread-local storage: a shared/reference actual may be
    // changed by another invocation across a barrier. If the callable also
    // writes through reference arguments, every call site must additionally
    // prove that their local-allocation roots differ from the candidate root.
    // Preflight all candidates before changing either signatures or calls.
    luisa::fixed_vector<PromotedArg, 16> promoted_args;
    for (auto candidate : candidates) {
        if (all_call_sites_prove_snapshot_safe(f, candidate, writable_args)) {
            promoted_args.emplace_back(candidate);
        }
    }
    if (promoted_args.empty()) { return; }
    // record the number of promoted reference arguments
    info.promoted_ref_arg_count += promoted_args.size();
    // promote the reference arguments
    for (auto &p : promoted_args) { p.arg = promote_ref_arg(f, p.arg); }
    // update the call-site arguments
    for (auto use : f->use_list()) {
        if (auto user = use->user(); user != nullptr && user->isa<CallInst>()) {
            auto call = static_cast<CallInst *>(user);
            LUISA_DEBUG_ASSERT(
                call->callee() == f &&
                    use == call->operand_use(CallInst::operand_index_callee),
                "PromoteRefArg preflight accepted a non-callee function use.");
            XIRBuilder b;
            b.set_insertion_point(call->prev());
            for (auto p : promoted_args) {
                auto loaded = b.load(p.arg->type(), call->argument(p.index));
                call->set_argument(p.index, loaded);
            }
        }
    }
}

static void promote_ref_args_in_module(Module *m, PromoteRefArgInfo &info) noexcept {
    if (m == nullptr) { return; }
    // we compute the call graph and collect the functions in post-order (i.e., leaves first)
    // so that we can process the callees before the callers to avoid reprocessing the same
    // function multiple times
    luisa::vector<CallableFunction *> post_order;
    {
        auto call_graph = compute_call_graph(m);
        luisa::unordered_set<Function *> visited;
        for (auto &&f : call_graph.root_functions()) {
            traverse_call_graph_post_order(f, call_graph, visited, post_order);
        }
    }
    // now we can iteratively promote the reference arguments of the functions in post-order
    for (auto f : post_order) {
        promote_ref_args_in_function(f, info);
    }
}

}// namespace detail

PromoteRefArgInfo promote_ref_arg_pass_run_on_module(Module *module, PassReport *report) noexcept {
    PromoteRefArgInfo info;
    if (module != nullptr) {
        detail::promote_ref_args_in_module(module, info);
    }
    if (report != nullptr) {
        report->set("promoted_ref_arg", info.promoted_ref_arg_count);
    }
    return info;
}

}// namespace luisa::compute::xir

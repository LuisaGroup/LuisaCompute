"""Freeze the actual isolated producer and host tools, not protected WIP."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import tarfile
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/mike/CLionProjects/luisa')
SOURCE = Path('/tmp/luisa-next-integration.roZbN8/source')
BUILD = SOURCE.parent / 'build'


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


paths = ['include/luisa/tile', 'src/tile', 'include/luisa/xir', 'src/xir', 'src/backends/simd',
         'src/tests/common', 'src/tests/benchmark/benchmark_tile_xir.cpp',
         'src/tests/unit/tile/bridge/test_xir_target_info.cpp', 'src/tests/unit/tile/bridge/test_xir_runtime.cpp',
         'src/tests/unit/simd/test_llvm_schedule_codegen.cpp', 'src/backends/metal4/tile/metal_tile.cpp']
host_paths = ['scripts/benchmark/tile_torch/native_tile.py', 'scripts/benchmark/tile_torch/native_tile_replay.cpp',
              'scripts/benchmark/tile_torch/compare_llm.py', 'scripts/benchmark/tile_torch/test_compare_llm.py',
              'scripts/benchmark/tile_torch/run.py']
dst = OUT / 'sources.tar.gz'
if dst.exists():
    raise RuntimeError('source archive already exists')
hashes = {}
with tarfile.open(dst, 'w:gz', compresslevel=6) as archive:
    for root, entries in [(SOURCE, paths), (ROOT, host_paths)]:
        for relative in entries:
            path = root / relative
            archive.add(path, arcname=relative)
            for f in (path.rglob('*') if path.is_dir() else [path]):
                if f.is_file():
                    hashes[str(f.relative_to(root))] = sha(f)
binary_paths = [BUILD / 'bin/benchmark_tile_xir', BUILD / 'bin/benchmark_tile_native',
                *sorted((BUILD / 'bin').glob('*.dylib')), *sorted((BUILD / 'bin').glob('*.so'))]
metadata = dict(checkpoint='2026-09-13 generic MMA output grouping with strided RHS', frozen_unix=time.time(),
                platform=platform.platform(),
                main_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                origin_next=subprocess.check_output(['git', 'rev-parse', 'origin/next'], cwd=ROOT, text=True).strip(),
                source_state='Isolated producer at b74264bab plus generic strided RHS MMA output grouping. Protected TIRx WIP and 19 upstream commits excluded. R1 default unchanged. Compare fixed R1/R4 at a predeclared MMA cap. No calibrated cost/default change.',
                source_sha256=hashes, source_archive_sha256=sha(dst),
                binary_sha256={p.name: sha(p) for p in binary_paths},
                build_configuration_sha256=sha(BUILD / 'CMakeCache.txt'),
                preflight='GPU preflight belongs to the separate attention-mma-roll checkpoint, not this producer. This CPU experiment follows full build and relevant CTests; source and actual ORC objects are frozen independently.',
                exclusions=['Full Runtime dependency binaries fingerprinted, not all archived.',
                            'Actual timed ORC objects, linked dylibs/helper, inputs/oracles/output retained.',
                            'Guard payload not saved; guards checked by execution helper.',
                            'GPU command-buffer controls are not isolated zero-overhead kernel time.',
                            'Neither the opt-in candidate nor a small health probe establishes the full performance goal.'])
(OUT / 'provenance.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(dst, dst.stat().st_size)

"""Predeclared generic MMA output grouping pilot, including strided RHS. R1 vs R4 at fixed cap."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent
BUILD = Path('/tmp/luisa-next-integration.roZbN8/build')
RUNNER = ROOT / 'scripts/benchmark/tile_torch/native_tile.py'
CASES = [
    ('decode-u8-on', (1, 8, 2, 1, 2053, 80, 96), (1, 16), 8, True),
    ('mha-u0-off', (1, 8, 8, 1, 2048, 64, 64), (1, 16), 0, False),
    ('mha-u8-off', (1, 8, 8, 1, 2048, 64, 64), (1, 16), 8, False),
    ('mha-u8-on', (1, 8, 8, 1, 2048, 64, 64), (1, 16), 8, True),
    ('prefill-u0-on', (1, 4, 2, 32, 65, 32, 32), (4, 16), 0, True),
    ('prefill-u8-on', (1, 4, 2, 32, 65, 32, 32), (4, 16), 8, True),
]

def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def run(command, folder, stem, env=None):
    record = dict(command=command, started=time.time(),
                  environment={k: v for k, v in (env or {}).items() if k.startswith('LUISA_')})
    save(folder / (stem + '.command.json'), record)
    try:
        result = subprocess.run(command, env=env, capture_output=True, timeout=60)
    except subprocess.TimeoutExpired as error:
        (folder / (stem + '.stdout')).write_bytes(error.stdout or b'')
        (folder / (stem + '.stderr')).write_bytes(error.stderr or b'')
        record.update(error='timeout', finished=time.time())
        save(folder / (stem + '.command.json'), record)
        raise
    (folder / (stem + '.stdout')).write_bytes(result.stdout)
    (folder / (stem + '.stderr')).write_bytes(result.stderr)
    record.update(returncode=result.returncode, finished=time.time())
    save(folder / (stem + '.command.json'), record)
    result.check_returncode()
    return result.stdout


def capture():
    for name, dims, block, limit, packet in CASES:
        for width in (1, 4):
            label = f'{name}-r{width}'
            folder = OUT / label
            folder.mkdir()
            prefix = folder / 'output.f32'
            env = {k: v for k, v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_'))}
            env.update(LUISA_TILE_BENCH_XIR_BACKEND='simd', LUISA_TILE_BENCH_ATTENTION_QK='mma',
                       LUISA_TILE_BENCH_ATTENTION_PV='mma', LUISA_TILE_BENCH_XIR_MMA_OUTPUT_BLOCK=str(width),
                       LUISA_TILE_BENCH_XIR_MMA_UNROLL_TERMS=str(limit),
                       LUISA_TILE_BENCH_DUMP_SOURCE=str(prefix) + '.source.txt',
                       LUISA_SIMD_DUMP_ASSEMBLY_DIR=str(folder / 'objects'))
            env['LUISA_SIMD_' + ('ENABLE' if packet else 'DISABLE') + '_FULL_PACKET_SPECIALIZATION'] = '1'
            metadata = json.loads(run([str(BUILD / 'bin/benchmark_tile_xir'), 'llm', 'attention',
                                       ','.join(map(str, dims)), *map(str, block), '3', '1', '1', str(prefix)],
                                      folder, 'capture', env))
            assert metadata['attention_qk'] == metadata['attention_pv'] == 'mma'
            assert f'max_unrolled_mma_terms={limit};' in metadata['realization']
            assert f'requested_mma_output_block={width};' in metadata['realization']
            run([sys.executable, str(RUNNER), 'prepare', '--capture-kind', 'llm', '--llvm',
                 '/opt/homebrew/opt/llvm/bin', '--prefix', str(prefix), '--log', str(folder / 'capture.stdout'),
                 '--objects', str(folder / 'objects'), '--output', str(OUT / ('prepared-' + label)),
                 '--name', f'r{width}'], folder, 'prepare')
            print(label, metadata['realization'], flush=True)


def replay():
    record = dict(started=time.time(), load_before=os.getloadavg(), experiments=[],
                  runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    for name, dims, block, limit, packet in CASES:
        run([sys.executable, str(RUNNER), 'replay', '--prepared', str(OUT / f'prepared-{name}-r1/prepared.json'),
             '--prepared', str(OUT / f'prepared-{name}-r4/prepared.json'), '--output', str(OUT / ('replay-' + name)),
             '--cycles', '3', '--samples', '7', '--warmup-ms', '30', '--target-ms', '15'], OUT, 'replay-' + name)
        record['experiments'].append(dict(case=name, dimensions=dims, block=block, cap=limit, packet=packet))
        save(OUT / 'replays.json', record)
        print(name, 'replayed', flush=True)
    record.update(finished=time.time(), load_after=os.getloadavg())
    save(OUT / 'replays.json', record)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=('capture', 'replay'))
    args = parser.parse_args()
    (capture if args.phase == 'capture' else replay)()

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #3808
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q4, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q5, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v25, v0, v5
	str	q0, [sp, #4864]                 ; 16-byte Spill
	cmhi.4s	v2, v0, v4
	uzp1.8h	v0, v2, v25
	umaxv.8h	h1, v0
	fmov	w8, s1
	tbnz	w8, #0, LBB0_1
	b	LBB0_1803
LBB0_1:                                 ; %direct.activate
	mov	x17, x0
	ldr	x9, [x0]
Lloh4:
	adrp	x8, lCPI0_2@PAGE
Lloh5:
	ldr	q1, [x8, lCPI0_2@PAGEOFF]
	and.16b	v0, v0, v1
	addv.8h	h3, v0
	fmov	w10, s3
	and	w8, w10, #0xff
	ldr	w11, [x1]
	ldr	w12, [x1, #36]
	add	w11, w12, w11, lsl #5
	dup.4s	v1, w11
	add.4s	v0, v1, v5
	str	q4, [sp, #4848]                 ; 16-byte Spill
	add.4s	v1, v1, v4
	and.16b	v7, v2, v1
	ushll.2d	v6, v7, #8
	dup.2d	v31, x9
	add.2d	v1, v31, v6
	movi.2d	v4, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w10, #0, LBB0_97
; %bb.2:                                ; %else
	and.16b	v17, v25, v0
	str	q7, [sp, #11312]                ; 16-byte Spill
	ushll2.2d	v7, v7, #8
	tbnz	w8, #1, LBB0_98
LBB0_3:                                 ; %else1098
	add.2d	v0, v31, v7
	tbnz	w8, #2, LBB0_99
LBB0_4:                                 ; %else1101
	ushll.2d	v16, v17, #8
	tbnz	w8, #3, LBB0_100
LBB0_5:                                 ; %else1104
	add.2d	v0, v31, v16
	tbnz	w8, #4, LBB0_101
LBB0_6:                                 ; %else1107
	str	q17, [sp, #11264]               ; 16-byte Spill
	ushll2.2d	v17, v17, #8
	tbnz	w8, #5, LBB0_102
LBB0_7:                                 ; %else1110
	add.2d	v0, v31, v17
	tbnz	w8, #6, LBB0_103
LBB0_8:                                 ; %else1113
	str	q5, [sp, #4832]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_10
LBB0_9:                                 ; %cond.load1115
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_10:                                ; %else1116
	str	q18, [sp, #11328]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #4                         ; =0x4
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #3136]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v5, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_104
; %bb.11:                               ; %else1123
	orr.16b	v19, v7, v0
	tbnz	w8, #1, LBB0_105
LBB0_12:                                ; %else1129
	add.2d	v1, v31, v19
	tbnz	w8, #2, LBB0_106
LBB0_13:                                ; %else1135
	orr.16b	v20, v16, v0
	tbnz	w8, #3, LBB0_107
LBB0_14:                                ; %else1141
	add.2d	v1, v31, v20
	tbnz	w8, #4, LBB0_108
LBB0_15:                                ; %else1147
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_109
LBB0_16:                                ; %else1153
	str	q0, [sp, #3088]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_110
LBB0_17:                                ; %else1159
	str	q19, [sp, #3120]                ; 16-byte Spill
	str	q20, [sp, #3104]                ; 16-byte Spill
	tbz	w8, #7, LBB0_19
LBB0_18:                                ; %cond.load1161
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_19:                                ; %else1165
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #8                         ; =0x8
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #3072]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w9, #0, LBB0_111
; %bb.20:                               ; %else1172
	orr.16b	v21, v7, v0
	tbnz	w8, #1, LBB0_112
LBB0_21:                                ; %else1178
	add.2d	v1, v31, v21
	tbnz	w8, #2, LBB0_113
LBB0_22:                                ; %else1184
	orr.16b	v22, v16, v0
	tbnz	w8, #3, LBB0_114
LBB0_23:                                ; %else1190
	add.2d	v1, v31, v22
	tbnz	w8, #4, LBB0_115
LBB0_24:                                ; %else1196
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_116
LBB0_25:                                ; %else1202
	str	q0, [sp, #3024]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_117
LBB0_26:                                ; %else1208
	str	q21, [sp, #3056]                ; 16-byte Spill
	str	q22, [sp, #3040]                ; 16-byte Spill
	tbz	w8, #7, LBB0_28
LBB0_27:                                ; %cond.load1210
	mov.d	x8, v0[1]
	ld1.s	{ v20 }[3], [x8]
LBB0_28:                                ; %else1214
	str	q4, [sp, #11568]                ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #12                        ; =0xc
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #3008]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbnz	w9, #0, LBB0_118
; %bb.29:                               ; %else1221
	orr.16b	v4, v7, v0
	tbnz	w8, #1, LBB0_119
LBB0_30:                                ; %else1227
	add.2d	v1, v31, v4
	tbnz	w8, #2, LBB0_120
LBB0_31:                                ; %else1233
	orr.16b	v23, v16, v0
	tbnz	w8, #3, LBB0_121
LBB0_32:                                ; %else1239
	add.2d	v1, v31, v23
	tbnz	w8, #4, LBB0_122
LBB0_33:                                ; %else1245
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_123
LBB0_34:                                ; %else1251
	str	q0, [sp, #2960]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_124
LBB0_35:                                ; %else1257
	str	q23, [sp, #2976]                ; 16-byte Spill
	tbz	w8, #7, LBB0_37
LBB0_36:                                ; %cond.load1259
	mov.d	x8, v0[1]
	ld1.s	{ v22 }[3], [x8]
LBB0_37:                                ; %else1263
	str	q5, [sp, #11552]                ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #16                        ; =0x10
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2944]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w9, #0, LBB0_125
; %bb.38:                               ; %else1270
	orr.16b	v5, v7, v0
	tbnz	w8, #1, LBB0_126
LBB0_39:                                ; %else1276
	add.2d	v1, v31, v5
	tbnz	w8, #2, LBB0_127
LBB0_40:                                ; %else1282
	orr.16b	v26, v16, v0
	tbnz	w8, #3, LBB0_128
LBB0_41:                                ; %else1288
	add.2d	v1, v31, v26
	tbnz	w8, #4, LBB0_129
LBB0_42:                                ; %else1294
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_130
LBB0_43:                                ; %else1300
	str	q0, [sp, #2896]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_131
LBB0_44:                                ; %else1306
	str	q26, [sp, #2912]                ; 16-byte Spill
	tbz	w8, #7, LBB0_46
LBB0_45:                                ; %cond.load1308
	mov.d	x8, v0[1]
	ld1.s	{ v24 }[3], [x8]
LBB0_46:                                ; %else1312
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #20                        ; =0x14
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2880]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w9, #0, LBB0_132
; %bb.47:                               ; %else1319
	orr.16b	v28, v7, v0
	tbnz	w8, #1, LBB0_133
LBB0_48:                                ; %else1325
	add.2d	v1, v31, v28
	tbnz	w8, #2, LBB0_134
LBB0_49:                                ; %else1331
	orr.16b	v29, v16, v0
	tbnz	w8, #3, LBB0_135
LBB0_50:                                ; %else1337
	add.2d	v1, v31, v29
	tbnz	w8, #4, LBB0_136
LBB0_51:                                ; %else1343
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_137
LBB0_52:                                ; %else1349
	str	q0, [sp, #2832]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_138
LBB0_53:                                ; %else1355
	str	q28, [sp, #2864]                ; 16-byte Spill
	str	q29, [sp, #2848]                ; 16-byte Spill
	tbz	w8, #7, LBB0_55
LBB0_54:                                ; %cond.load1357
	mov.d	x8, v0[1]
	ld1.s	{ v27 }[3], [x8]
LBB0_55:                                ; %else1361
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #24                        ; =0x18
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2816]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w9, #0, LBB0_139
; %bb.56:                               ; %else1368
	orr.16b	v30, v7, v0
	tbnz	w8, #1, LBB0_140
LBB0_57:                                ; %else1374
	add.2d	v1, v31, v30
	tbnz	w8, #2, LBB0_141
LBB0_58:                                ; %else1380
	orr.16b	v8, v16, v0
	tbnz	w8, #3, LBB0_142
LBB0_59:                                ; %else1386
	add.2d	v1, v31, v8
	tbnz	w8, #4, LBB0_143
LBB0_60:                                ; %else1392
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_144
LBB0_61:                                ; %else1398
	str	q0, [sp, #2768]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_145
LBB0_62:                                ; %else1404
	str	q30, [sp, #2800]                ; 16-byte Spill
	str	q8, [sp, #2784]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_64
LBB0_63:                                ; %cond.load1406
	mov.d	x8, v0[1]
	ld1.s	{ v29 }[3], [x8]
LBB0_64:                                ; %else1410
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #28                        ; =0x1c
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2752]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v30, #0000000000000000
	movi.2d	v8, #0000000000000000
	tbnz	w9, #0, LBB0_146
; %bb.65:                               ; %else1417
	orr.16b	v9, v7, v0
	tbnz	w8, #1, LBB0_147
LBB0_66:                                ; %else1423
	add.2d	v1, v31, v9
	tbnz	w8, #2, LBB0_148
LBB0_67:                                ; %else1429
	orr.16b	v10, v16, v0
	tbnz	w8, #3, LBB0_149
LBB0_68:                                ; %else1435
	add.2d	v1, v31, v10
	tbnz	w8, #4, LBB0_150
LBB0_69:                                ; %else1441
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_151
LBB0_70:                                ; %else1447
	str	q0, [sp, #2704]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_152
LBB0_71:                                ; %else1453
	str	q9, [sp, #2736]                 ; 16-byte Spill
	str	q10, [sp, #2720]                ; 16-byte Spill
	tbz	w8, #7, LBB0_73
LBB0_72:                                ; %cond.load1455
	mov.d	x8, v0[1]
	ld1.s	{ v8 }[3], [x8]
LBB0_73:                                ; %else1459
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #32                        ; =0x20
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2688]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	tbnz	w9, #0, LBB0_153
; %bb.74:                               ; %else1466
	orr.16b	v11, v7, v0
	tbnz	w8, #1, LBB0_154
LBB0_75:                                ; %else1472
	add.2d	v1, v31, v11
	tbnz	w8, #2, LBB0_155
LBB0_76:                                ; %else1478
	orr.16b	v12, v16, v0
	tbnz	w8, #3, LBB0_156
LBB0_77:                                ; %else1484
	add.2d	v1, v31, v12
	tbnz	w8, #4, LBB0_157
LBB0_78:                                ; %else1490
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_158
LBB0_79:                                ; %else1496
	str	q0, [sp, #2640]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_159
LBB0_80:                                ; %else1502
	str	q11, [sp, #2672]                ; 16-byte Spill
	str	q12, [sp, #2656]                ; 16-byte Spill
	tbz	w8, #7, LBB0_82
LBB0_81:                                ; %cond.load1504
	mov.d	x8, v0[1]
	ld1.s	{ v10 }[3], [x8]
LBB0_82:                                ; %else1508
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #36                        ; =0x24
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2624]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v11, #0000000000000000
	movi.2d	v15, #0000000000000000
	tbnz	w9, #0, LBB0_160
; %bb.83:                               ; %else1515
	orr.16b	v13, v7, v0
	tbnz	w8, #1, LBB0_161
LBB0_84:                                ; %else1521
	add.2d	v1, v31, v13
	tbnz	w8, #2, LBB0_162
LBB0_85:                                ; %else1527
	orr.16b	v14, v16, v0
	tbnz	w8, #3, LBB0_163
LBB0_86:                                ; %else1533
	add.2d	v1, v31, v14
	tbnz	w8, #4, LBB0_164
LBB0_87:                                ; %else1539
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_165
LBB0_88:                                ; %else1545
	str	q0, [sp, #2576]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_166
LBB0_89:                                ; %else1551
	str	q13, [sp, #2608]                ; 16-byte Spill
	str	q14, [sp, #2592]                ; 16-byte Spill
	mov.16b	v12, v9
	tbz	w8, #7, LBB0_91
LBB0_90:                                ; %cond.load1553
	mov.d	x8, v0[1]
	ld1.s	{ v15 }[3], [x8]
LBB0_91:                                ; %else1557
	str	q15, [sp, #11232]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #40                        ; =0x28
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2560]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v13, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_167
; %bb.92:                               ; %else1564
	orr.16b	v15, v7, v0
	tbnz	w8, #1, LBB0_168
LBB0_93:                                ; %else1570
	mov.16b	v14, v11
	add.2d	v1, v31, v15
	tbnz	w8, #2, LBB0_169
LBB0_94:                                ; %else1576
	mov.16b	v11, v13
	orr.16b	v13, v16, v0
	str	q13, [sp, #4096]                ; 16-byte Spill
	tbz	w8, #3, LBB0_170
LBB0_95:                                ; %cond.load1578
	mov.d	x9, v1[1]
	mov.16b	v13, v11
	ld1.s	{ v13 }[3], [x9]
	ldr	q1, [sp, #4096]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v11, v14
	tbnz	w8, #4, LBB0_171
LBB0_96:
	mov.16b	v14, v9
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_172
	b	LBB0_173
LBB0_97:                                ; %cond.load
	fmov	x9, d1
	ldr	s4, [x9]
	and.16b	v17, v25, v0
	str	q7, [sp, #11312]                ; 16-byte Spill
	ushll2.2d	v7, v7, #8
	tbz	w8, #1, LBB0_3
LBB0_98:                                ; %cond.load1097
	mov.d	x9, v1[1]
	ld1.s	{ v4 }[1], [x9]
	add.2d	v0, v31, v7
	tbz	w8, #2, LBB0_4
LBB0_99:                                ; %cond.load1100
	fmov	x9, d0
	ld1.s	{ v4 }[2], [x9]
	ushll.2d	v16, v17, #8
	tbz	w8, #3, LBB0_5
LBB0_100:                               ; %cond.load1103
	mov.d	x9, v0[1]
	ld1.s	{ v4 }[3], [x9]
	add.2d	v0, v31, v16
	tbz	w8, #4, LBB0_6
LBB0_101:                               ; %cond.load1106
	fmov	x9, d0
	ld1.s	{ v18 }[0], [x9]
	str	q17, [sp, #11264]               ; 16-byte Spill
	ushll2.2d	v17, v17, #8
	tbz	w8, #5, LBB0_7
LBB0_102:                               ; %cond.load1109
	mov.d	x9, v0[1]
	ld1.s	{ v18 }[1], [x9]
	add.2d	v0, v31, v17
	tbz	w8, #6, LBB0_8
LBB0_103:                               ; %cond.load1112
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	str	q5, [sp, #4832]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_9
	b	LBB0_10
LBB0_104:                               ; %cond.load1119
	fmov	x9, d1
	ldr	s5, [x9]
	orr.16b	v19, v7, v0
	tbz	w8, #1, LBB0_12
LBB0_105:                               ; %cond.load1125
	mov.d	x9, v1[1]
	ld1.s	{ v5 }[1], [x9]
	add.2d	v1, v31, v19
	tbz	w8, #2, LBB0_13
LBB0_106:                               ; %cond.load1131
	fmov	x9, d1
	ld1.s	{ v5 }[2], [x9]
	orr.16b	v20, v16, v0
	tbz	w8, #3, LBB0_14
LBB0_107:                               ; %cond.load1137
	mov.d	x9, v1[1]
	ld1.s	{ v5 }[3], [x9]
	add.2d	v1, v31, v20
	tbz	w8, #4, LBB0_15
LBB0_108:                               ; %cond.load1143
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_16
LBB0_109:                               ; %cond.load1149
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #3088]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_17
LBB0_110:                               ; %cond.load1155
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	str	q19, [sp, #3120]                ; 16-byte Spill
	str	q20, [sp, #3104]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_18
	b	LBB0_19
LBB0_111:                               ; %cond.load1168
	fmov	x9, d1
	ldr	s19, [x9]
	orr.16b	v21, v7, v0
	tbz	w8, #1, LBB0_21
LBB0_112:                               ; %cond.load1174
	mov.d	x9, v1[1]
	ld1.s	{ v19 }[1], [x9]
	add.2d	v1, v31, v21
	tbz	w8, #2, LBB0_22
LBB0_113:                               ; %cond.load1180
	fmov	x9, d1
	ld1.s	{ v19 }[2], [x9]
	orr.16b	v22, v16, v0
	tbz	w8, #3, LBB0_23
LBB0_114:                               ; %cond.load1186
	mov.d	x9, v1[1]
	ld1.s	{ v19 }[3], [x9]
	add.2d	v1, v31, v22
	tbz	w8, #4, LBB0_24
LBB0_115:                               ; %cond.load1192
	fmov	x9, d1
	ld1.s	{ v20 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_25
LBB0_116:                               ; %cond.load1198
	mov.d	x9, v1[1]
	ld1.s	{ v20 }[1], [x9]
	str	q0, [sp, #3024]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_26
LBB0_117:                               ; %cond.load1204
	fmov	x9, d0
	ld1.s	{ v20 }[2], [x9]
	str	q21, [sp, #3056]                ; 16-byte Spill
	str	q22, [sp, #3040]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_27
	b	LBB0_28
LBB0_118:                               ; %cond.load1217
	fmov	x9, d1
	ldr	s21, [x9]
	orr.16b	v4, v7, v0
	tbz	w8, #1, LBB0_30
LBB0_119:                               ; %cond.load1223
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[1], [x9]
	add.2d	v1, v31, v4
	tbz	w8, #2, LBB0_31
LBB0_120:                               ; %cond.load1229
	fmov	x9, d1
	ld1.s	{ v21 }[2], [x9]
	orr.16b	v23, v16, v0
	tbz	w8, #3, LBB0_32
LBB0_121:                               ; %cond.load1235
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[3], [x9]
	add.2d	v1, v31, v23
	tbz	w8, #4, LBB0_33
LBB0_122:                               ; %cond.load1241
	fmov	x9, d1
	ld1.s	{ v22 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_34
LBB0_123:                               ; %cond.load1247
	mov.d	x9, v1[1]
	ld1.s	{ v22 }[1], [x9]
	str	q0, [sp, #2960]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_35
LBB0_124:                               ; %cond.load1253
	fmov	x9, d0
	ld1.s	{ v22 }[2], [x9]
	str	q23, [sp, #2976]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_36
	b	LBB0_37
LBB0_125:                               ; %cond.load1266
	fmov	x9, d1
	ldr	s23, [x9]
	orr.16b	v5, v7, v0
	tbz	w8, #1, LBB0_39
LBB0_126:                               ; %cond.load1272
	mov.d	x9, v1[1]
	ld1.s	{ v23 }[1], [x9]
	add.2d	v1, v31, v5
	tbz	w8, #2, LBB0_40
LBB0_127:                               ; %cond.load1278
	fmov	x9, d1
	ld1.s	{ v23 }[2], [x9]
	orr.16b	v26, v16, v0
	tbz	w8, #3, LBB0_41
LBB0_128:                               ; %cond.load1284
	mov.d	x9, v1[1]
	ld1.s	{ v23 }[3], [x9]
	add.2d	v1, v31, v26
	tbz	w8, #4, LBB0_42
LBB0_129:                               ; %cond.load1290
	fmov	x9, d1
	ld1.s	{ v24 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_43
LBB0_130:                               ; %cond.load1296
	mov.d	x9, v1[1]
	ld1.s	{ v24 }[1], [x9]
	str	q0, [sp, #2896]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_44
LBB0_131:                               ; %cond.load1302
	fmov	x9, d0
	ld1.s	{ v24 }[2], [x9]
	str	q26, [sp, #2912]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_45
	b	LBB0_46
LBB0_132:                               ; %cond.load1315
	fmov	x9, d1
	ldr	s26, [x9]
	orr.16b	v28, v7, v0
	tbz	w8, #1, LBB0_48
LBB0_133:                               ; %cond.load1321
	mov.d	x9, v1[1]
	ld1.s	{ v26 }[1], [x9]
	add.2d	v1, v31, v28
	tbz	w8, #2, LBB0_49
LBB0_134:                               ; %cond.load1327
	fmov	x9, d1
	ld1.s	{ v26 }[2], [x9]
	orr.16b	v29, v16, v0
	tbz	w8, #3, LBB0_50
LBB0_135:                               ; %cond.load1333
	mov.d	x9, v1[1]
	ld1.s	{ v26 }[3], [x9]
	add.2d	v1, v31, v29
	tbz	w8, #4, LBB0_51
LBB0_136:                               ; %cond.load1339
	fmov	x9, d1
	ld1.s	{ v27 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_52
LBB0_137:                               ; %cond.load1345
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[1], [x9]
	str	q0, [sp, #2832]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_53
LBB0_138:                               ; %cond.load1351
	fmov	x9, d0
	ld1.s	{ v27 }[2], [x9]
	str	q28, [sp, #2864]                ; 16-byte Spill
	str	q29, [sp, #2848]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_54
	b	LBB0_55
LBB0_139:                               ; %cond.load1364
	fmov	x9, d1
	ldr	s28, [x9]
	orr.16b	v30, v7, v0
	tbz	w8, #1, LBB0_57
LBB0_140:                               ; %cond.load1370
	mov.d	x9, v1[1]
	ld1.s	{ v28 }[1], [x9]
	add.2d	v1, v31, v30
	tbz	w8, #2, LBB0_58
LBB0_141:                               ; %cond.load1376
	fmov	x9, d1
	ld1.s	{ v28 }[2], [x9]
	orr.16b	v8, v16, v0
	tbz	w8, #3, LBB0_59
LBB0_142:                               ; %cond.load1382
	mov.d	x9, v1[1]
	ld1.s	{ v28 }[3], [x9]
	add.2d	v1, v31, v8
	tbz	w8, #4, LBB0_60
LBB0_143:                               ; %cond.load1388
	fmov	x9, d1
	ld1.s	{ v29 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_61
LBB0_144:                               ; %cond.load1394
	mov.d	x9, v1[1]
	ld1.s	{ v29 }[1], [x9]
	str	q0, [sp, #2768]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_62
LBB0_145:                               ; %cond.load1400
	fmov	x9, d0
	ld1.s	{ v29 }[2], [x9]
	str	q30, [sp, #2800]                ; 16-byte Spill
	str	q8, [sp, #2784]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_63
	b	LBB0_64
LBB0_146:                               ; %cond.load1413
	fmov	x9, d1
	ldr	s30, [x9]
	orr.16b	v9, v7, v0
	tbz	w8, #1, LBB0_66
LBB0_147:                               ; %cond.load1419
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[1], [x9]
	add.2d	v1, v31, v9
	tbz	w8, #2, LBB0_67
LBB0_148:                               ; %cond.load1425
	fmov	x9, d1
	ld1.s	{ v30 }[2], [x9]
	orr.16b	v10, v16, v0
	tbz	w8, #3, LBB0_68
LBB0_149:                               ; %cond.load1431
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[3], [x9]
	add.2d	v1, v31, v10
	tbz	w8, #4, LBB0_69
LBB0_150:                               ; %cond.load1437
	fmov	x9, d1
	ld1.s	{ v8 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_70
LBB0_151:                               ; %cond.load1443
	mov.d	x9, v1[1]
	ld1.s	{ v8 }[1], [x9]
	str	q0, [sp, #2704]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_71
LBB0_152:                               ; %cond.load1449
	fmov	x9, d0
	ld1.s	{ v8 }[2], [x9]
	str	q9, [sp, #2736]                 ; 16-byte Spill
	str	q10, [sp, #2720]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_72
	b	LBB0_73
LBB0_153:                               ; %cond.load1462
	fmov	x9, d1
	ldr	s9, [x9]
	orr.16b	v11, v7, v0
	tbz	w8, #1, LBB0_75
LBB0_154:                               ; %cond.load1468
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	add.2d	v1, v31, v11
	tbz	w8, #2, LBB0_76
LBB0_155:                               ; %cond.load1474
	fmov	x9, d1
	ld1.s	{ v9 }[2], [x9]
	orr.16b	v12, v16, v0
	tbz	w8, #3, LBB0_77
LBB0_156:                               ; %cond.load1480
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[3], [x9]
	add.2d	v1, v31, v12
	tbz	w8, #4, LBB0_78
LBB0_157:                               ; %cond.load1486
	fmov	x9, d1
	ld1.s	{ v10 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_79
LBB0_158:                               ; %cond.load1492
	mov.d	x9, v1[1]
	ld1.s	{ v10 }[1], [x9]
	str	q0, [sp, #2640]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_80
LBB0_159:                               ; %cond.load1498
	fmov	x9, d0
	ld1.s	{ v10 }[2], [x9]
	str	q11, [sp, #2672]                ; 16-byte Spill
	str	q12, [sp, #2656]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_81
	b	LBB0_82
LBB0_160:                               ; %cond.load1511
	fmov	x9, d1
	ldr	s11, [x9]
	orr.16b	v13, v7, v0
	tbz	w8, #1, LBB0_84
LBB0_161:                               ; %cond.load1517
	mov.d	x9, v1[1]
	ld1.s	{ v11 }[1], [x9]
	add.2d	v1, v31, v13
	tbz	w8, #2, LBB0_85
LBB0_162:                               ; %cond.load1523
	fmov	x9, d1
	ld1.s	{ v11 }[2], [x9]
	orr.16b	v14, v16, v0
	tbz	w8, #3, LBB0_86
LBB0_163:                               ; %cond.load1529
	mov.d	x9, v1[1]
	ld1.s	{ v11 }[3], [x9]
	add.2d	v1, v31, v14
	tbz	w8, #4, LBB0_87
LBB0_164:                               ; %cond.load1535
	fmov	x9, d1
	ld1.s	{ v15 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_88
LBB0_165:                               ; %cond.load1541
	mov.d	x9, v1[1]
	ld1.s	{ v15 }[1], [x9]
	str	q0, [sp, #2576]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_89
LBB0_166:                               ; %cond.load1547
	fmov	x9, d0
	ld1.s	{ v15 }[2], [x9]
	str	q13, [sp, #2608]                ; 16-byte Spill
	str	q14, [sp, #2592]                ; 16-byte Spill
	mov.16b	v12, v9
	tbnz	w8, #7, LBB0_90
	b	LBB0_91
LBB0_167:                               ; %cond.load1560
	fmov	x9, d1
	ldr	s13, [x9]
	orr.16b	v15, v7, v0
	tbz	w8, #1, LBB0_93
LBB0_168:                               ; %cond.load1566
	mov.d	x9, v1[1]
	ld1.s	{ v13 }[1], [x9]
	mov.16b	v14, v11
	add.2d	v1, v31, v15
	tbz	w8, #2, LBB0_94
LBB0_169:                               ; %cond.load1572
	fmov	x9, d1
	ld1.s	{ v13 }[2], [x9]
	mov.16b	v11, v13
	orr.16b	v13, v16, v0
	str	q13, [sp, #4096]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_95
LBB0_170:
	mov.16b	v13, v11
	ldr	q1, [sp, #4096]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v11, v14
	tbz	w8, #4, LBB0_96
LBB0_171:                               ; %cond.load1584
	fmov	x9, d1
	mov.16b	v14, v9
	ld1.s	{ v14 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_173
LBB0_172:                               ; %cond.load1590
	mov.d	x9, v1[1]
	ld1.s	{ v14 }[1], [x9]
LBB0_173:                               ; %else1594
	str	q0, [sp, #2528]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_315
; %bb.174:                              ; %else1600
	str	q4, [sp, #2992]                 ; 16-byte Spill
	str	q15, [sp, #2544]                ; 16-byte Spill
	str	q13, [sp, #11216]               ; 16-byte Spill
	tbz	w8, #7, LBB0_176
LBB0_175:                               ; %cond.load1602
	mov.d	x8, v0[1]
	ld1.s	{ v14 }[3], [x8]
LBB0_176:                               ; %else1606
	str	q18, [sp, #11536]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #44                        ; =0x2c
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2512]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v13, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB0_316
; %bb.177:                              ; %else1613
	orr.16b	v18, v7, v0
	str	q18, [sp, #4080]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_317
LBB0_178:                               ; %else1619
	ldr	q1, [sp, #4080]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v18, v4
	tbnz	w8, #2, LBB0_318
LBB0_179:                               ; %else1625
	orr.16b	v4, v16, v0
	tbnz	w8, #3, LBB0_319
LBB0_180:                               ; %else1631
	add.2d	v1, v31, v4
	tbnz	w8, #4, LBB0_320
LBB0_181:                               ; %else1637
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_321
LBB0_182:                               ; %else1643
	str	q0, [sp, #2480]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_322
LBB0_183:                               ; %else1649
	str	q5, [sp, #2928]                 ; 16-byte Spill
	str	q13, [sp, #11184]               ; 16-byte Spill
	tbz	w8, #7, LBB0_185
LBB0_184:                               ; %cond.load1651
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_185:                               ; %else1655
	str	q19, [sp, #11520]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #48                        ; =0x30
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2464]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v13, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w9, #0, LBB0_323
; %bb.186:                              ; %else1662
	orr.16b	v19, v7, v0
	str	q19, [sp, #4064]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_324
LBB0_187:                               ; %else1668
	ldr	q1, [sp, #4064]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v19, v5
	tbnz	w8, #2, LBB0_325
LBB0_188:                               ; %else1674
	orr.16b	v5, v16, v0
	tbnz	w8, #3, LBB0_326
LBB0_189:                               ; %else1680
	add.2d	v1, v31, v5
	tbnz	w8, #4, LBB0_327
LBB0_190:                               ; %else1686
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_328
LBB0_191:                               ; %else1692
	str	q0, [sp, #2432]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_329
LBB0_192:                               ; %else1698
	str	q4, [sp, #2496]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_194
LBB0_193:                               ; %cond.load1700
	mov.d	x8, v0[1]
	ld1.s	{ v19 }[3], [x8]
LBB0_194:                               ; %else1704
	str	q20, [sp, #11504]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #52                        ; =0x34
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2416]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v20, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB0_330
; %bb.195:                              ; %else1711
	str	q20, [sp, #11840]               ; 16-byte Spill
	orr.16b	v20, v7, v0
	str	q20, [sp, #4048]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_331
LBB0_196:                               ; %else1717
	ldr	q1, [sp, #4048]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v20, v4
	tbnz	w8, #2, LBB0_332
LBB0_197:                               ; %else1723
	orr.16b	v4, v16, v0
	tbnz	w8, #3, LBB0_333
LBB0_198:                               ; %else1729
	add.2d	v1, v31, v4
	tbnz	w8, #4, LBB0_334
LBB0_199:                               ; %else1735
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_335
LBB0_200:                               ; %else1741
	str	q0, [sp, #2384]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_336
LBB0_201:                               ; %else1747
	str	q5, [sp, #2448]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_203
LBB0_202:                               ; %cond.load1749
	mov.d	x8, v0[1]
	ld1.s	{ v20 }[3], [x8]
LBB0_203:                               ; %else1753
	str	q21, [sp, #11488]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #56                        ; =0x38
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2368]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v21, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w9, #0, LBB0_337
; %bb.204:                              ; %else1760
	str	q21, [sp, #11824]               ; 16-byte Spill
	orr.16b	v21, v7, v0
	str	q21, [sp, #4032]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_338
LBB0_205:                               ; %else1766
	ldr	q1, [sp, #4032]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v21, v5
	tbnz	w8, #2, LBB0_339
LBB0_206:                               ; %else1772
	orr.16b	v5, v16, v0
	tbnz	w8, #3, LBB0_340
LBB0_207:                               ; %else1778
	add.2d	v1, v31, v5
	tbnz	w8, #4, LBB0_341
LBB0_208:                               ; %else1784
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_342
LBB0_209:                               ; %else1790
	str	q0, [sp, #2336]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_343
LBB0_210:                               ; %else1796
	str	q4, [sp, #2400]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_212
LBB0_211:                               ; %cond.load1798
	mov.d	x8, v0[1]
	ld1.s	{ v21 }[3], [x8]
LBB0_212:                               ; %else1802
	str	q22, [sp, #11472]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #60                        ; =0x3c
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2320]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v22, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB0_344
; %bb.213:                              ; %else1809
	str	q22, [sp, #11808]               ; 16-byte Spill
	orr.16b	v22, v7, v0
	str	q22, [sp, #4016]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_345
LBB0_214:                               ; %else1815
	ldr	q1, [sp, #4016]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v22, v4
	tbnz	w8, #2, LBB0_346
LBB0_215:                               ; %else1821
	orr.16b	v4, v16, v0
	tbnz	w8, #3, LBB0_347
LBB0_216:                               ; %else1827
	add.2d	v1, v31, v4
	tbnz	w8, #4, LBB0_348
LBB0_217:                               ; %else1833
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_349
LBB0_218:                               ; %else1839
	str	q0, [sp, #2288]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_350
LBB0_219:                               ; %else1845
	str	q5, [sp, #2352]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_221
LBB0_220:                               ; %cond.load1847
	mov.d	x8, v0[1]
	ld1.s	{ v22 }[3], [x8]
LBB0_221:                               ; %else1851
	str	q23, [sp, #11456]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #64                        ; =0x40
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2272]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v23, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w9, #0, LBB0_351
; %bb.222:                              ; %else1858
	str	q23, [sp, #11792]               ; 16-byte Spill
	orr.16b	v23, v7, v0
	str	q23, [sp, #4000]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_352
LBB0_223:                               ; %else1864
	ldr	q1, [sp, #4000]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v23, v5
	tbnz	w8, #2, LBB0_353
LBB0_224:                               ; %else1870
	orr.16b	v5, v16, v0
	tbnz	w8, #3, LBB0_354
LBB0_225:                               ; %else1876
	add.2d	v1, v31, v5
	tbnz	w8, #4, LBB0_355
LBB0_226:                               ; %else1882
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_356
LBB0_227:                               ; %else1888
	str	q0, [sp, #2240]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_357
LBB0_228:                               ; %else1894
	str	q4, [sp, #2304]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_230
LBB0_229:                               ; %cond.load1896
	mov.d	x8, v0[1]
	ld1.s	{ v23 }[3], [x8]
LBB0_230:                               ; %else1900
	str	q24, [sp, #11440]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #68                        ; =0x44
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2224]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v24, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB0_358
; %bb.231:                              ; %else1907
	str	q24, [sp, #11776]               ; 16-byte Spill
	orr.16b	v24, v7, v0
	str	q24, [sp, #3984]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_359
LBB0_232:                               ; %else1913
	ldr	q1, [sp, #3984]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v24, v4
	tbnz	w8, #2, LBB0_360
LBB0_233:                               ; %else1919
	orr.16b	v4, v16, v0
	tbnz	w8, #3, LBB0_361
LBB0_234:                               ; %else1925
	add.2d	v1, v31, v4
	tbnz	w8, #4, LBB0_362
LBB0_235:                               ; %else1931
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_363
LBB0_236:                               ; %else1937
	str	q0, [sp, #2192]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_364
LBB0_237:                               ; %else1943
	str	q5, [sp, #2256]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_239
LBB0_238:                               ; %cond.load1945
	mov.d	x8, v0[1]
	ld1.s	{ v24 }[3], [x8]
LBB0_239:                               ; %else1949
	str	q26, [sp, #11424]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #72                        ; =0x48
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2176]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v26, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w9, #0, LBB0_365
; %bb.240:                              ; %else1956
	str	q26, [sp, #11760]               ; 16-byte Spill
	orr.16b	v26, v7, v0
	str	q26, [sp, #3968]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_366
LBB0_241:                               ; %else1962
	ldr	q1, [sp, #3968]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v26, v5
	tbnz	w8, #2, LBB0_367
LBB0_242:                               ; %else1968
	orr.16b	v5, v16, v0
	tbnz	w8, #3, LBB0_368
LBB0_243:                               ; %else1974
	add.2d	v1, v31, v5
	tbnz	w8, #4, LBB0_369
LBB0_244:                               ; %else1980
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_370
LBB0_245:                               ; %else1986
	str	q0, [sp, #2144]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_371
LBB0_246:                               ; %else1992
	str	q13, [sp, #11152]               ; 16-byte Spill
	tbz	w8, #7, LBB0_248
LBB0_247:                               ; %cond.load1994
	mov.d	x8, v0[1]
	ld1.s	{ v26 }[3], [x8]
LBB0_248:                               ; %else1998
	str	q27, [sp, #11408]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #76                        ; =0x4c
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2128]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v15, #0000000000000000
	movi.2d	v13, #0000000000000000
	tbnz	w9, #0, LBB0_372
; %bb.249:                              ; %else2005
	orr.16b	v27, v7, v0
	str	q27, [sp, #3952]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_373
LBB0_250:                               ; %else2011
	ldr	q1, [sp, #3952]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_374
LBB0_251:                               ; %else2017
	str	q15, [sp, #11632]               ; 16-byte Spill
	orr.16b	v27, v16, v0
	tbnz	w8, #3, LBB0_375
LBB0_252:                               ; %else2023
	add.2d	v1, v31, v27
	tbnz	w8, #4, LBB0_376
LBB0_253:                               ; %else2029
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_377
LBB0_254:                               ; %else2035
	str	q0, [sp, #2096]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_378
LBB0_255:                               ; %else2041
	str	q4, [sp, #2208]                 ; 16-byte Spill
	str	q27, [sp, #2112]                ; 16-byte Spill
	tbz	w8, #7, LBB0_257
LBB0_256:                               ; %cond.load2043
	mov.d	x8, v0[1]
	ld1.s	{ v13 }[3], [x8]
LBB0_257:                               ; %else2047
	str	q28, [sp, #11392]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #80                        ; =0x50
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2080]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v27, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB0_379
; %bb.258:                              ; %else2054
	orr.16b	v28, v7, v0
	str	q28, [sp, #3936]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_380
LBB0_259:                               ; %else2060
	ldr	q1, [sp, #3936]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v28, v4
	tbnz	w8, #2, LBB0_381
LBB0_260:                               ; %else2066
	orr.16b	v4, v16, v0
	tbnz	w8, #3, LBB0_382
LBB0_261:                               ; %else2072
	add.2d	v1, v31, v4
	tbnz	w8, #4, LBB0_383
LBB0_262:                               ; %else2078
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_384
LBB0_263:                               ; %else2084
	str	q0, [sp, #2048]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_385
LBB0_264:                               ; %else2090
	str	q5, [sp, #2160]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_266
LBB0_265:                               ; %cond.load2092
	mov.d	x8, v0[1]
	ld1.s	{ v28 }[3], [x8]
LBB0_266:                               ; %else2096
	str	q29, [sp, #11376]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #84                        ; =0x54
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #2032]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v15, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w9, #0, LBB0_386
; %bb.267:                              ; %else2103
	orr.16b	v29, v7, v0
	str	q29, [sp, #3920]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_387
LBB0_268:                               ; %else2109
	ldr	q1, [sp, #3920]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v29, v5
	tbnz	w8, #2, LBB0_388
LBB0_269:                               ; %else2115
	orr.16b	v5, v16, v0
	tbnz	w8, #3, LBB0_389
LBB0_270:                               ; %else2121
	add.2d	v1, v31, v5
	tbnz	w8, #4, LBB0_390
LBB0_271:                               ; %else2127
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_391
LBB0_272:                               ; %else2133
	str	q0, [sp, #2000]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_392
LBB0_273:                               ; %else2139
	str	q4, [sp, #2064]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_275
LBB0_274:                               ; %cond.load2141
	mov.d	x8, v0[1]
	ld1.s	{ v29 }[3], [x8]
LBB0_275:                               ; %else2145
	str	q30, [sp, #11360]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #88                        ; =0x58
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1984]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v30, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB0_393
; %bb.276:                              ; %else2152
	str	q30, [sp, #11744]               ; 16-byte Spill
	orr.16b	v30, v7, v0
	str	q30, [sp, #3904]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_394
LBB0_277:                               ; %else2158
	ldr	q1, [sp, #3904]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v30, v4
	tbnz	w8, #2, LBB0_395
LBB0_278:                               ; %else2164
	orr.16b	v4, v16, v0
	tbnz	w8, #3, LBB0_396
LBB0_279:                               ; %else2170
	add.2d	v1, v31, v4
	tbnz	w8, #4, LBB0_397
LBB0_280:                               ; %else2176
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_398
LBB0_281:                               ; %else2182
	str	q0, [sp, #1952]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_399
LBB0_282:                               ; %else2188
	str	q5, [sp, #2016]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_284
LBB0_283:                               ; %cond.load2190
	mov.d	x8, v0[1]
	ld1.s	{ v30 }[3], [x8]
LBB0_284:                               ; %else2194
	str	q8, [sp, #11344]                ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #92                        ; =0x5c
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1936]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v8, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w9, #0, LBB0_400
; %bb.285:                              ; %else2201
	str	q8, [sp, #11728]                ; 16-byte Spill
	orr.16b	v8, v7, v0
	str	q8, [sp, #3888]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_401
LBB0_286:                               ; %else2207
	ldr	q1, [sp, #3888]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v8, v5
	tbnz	w8, #2, LBB0_402
LBB0_287:                               ; %else2213
	orr.16b	v5, v16, v0
	tbnz	w8, #3, LBB0_403
LBB0_288:                               ; %else2219
	add.2d	v1, v31, v5
	tbnz	w8, #4, LBB0_404
LBB0_289:                               ; %else2225
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_405
LBB0_290:                               ; %else2231
	str	q0, [sp, #1904]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_406
LBB0_291:                               ; %else2237
	str	q4, [sp, #1968]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_293
LBB0_292:                               ; %cond.load2239
	mov.d	x8, v0[1]
	ld1.s	{ v8 }[3], [x8]
LBB0_293:                               ; %else2243
	str	q12, [sp, #11296]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #96                        ; =0x60
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1888]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB0_407
; %bb.294:                              ; %else2250
	str	q9, [sp, #11712]                ; 16-byte Spill
	orr.16b	v9, v7, v0
	str	q9, [sp, #3872]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_408
LBB0_295:                               ; %else2256
	ldr	q1, [sp, #3872]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v9, v4
	tbnz	w8, #2, LBB0_409
LBB0_296:                               ; %else2262
	orr.16b	v4, v16, v0
	tbnz	w8, #3, LBB0_410
LBB0_297:                               ; %else2268
	add.2d	v1, v31, v4
	tbnz	w8, #4, LBB0_411
LBB0_298:                               ; %else2274
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_412
LBB0_299:                               ; %else2280
	str	q0, [sp, #1856]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_413
LBB0_300:                               ; %else2286
	str	q5, [sp, #1920]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_302
LBB0_301:                               ; %cond.load2288
	mov.d	x8, v0[1]
	ld1.s	{ v9 }[3], [x8]
LBB0_302:                               ; %else2292
	str	q10, [sp, #11280]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #100                       ; =0x64
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1840]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v10, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w9, #0, LBB0_414
; %bb.303:                              ; %else2299
	str	q10, [sp, #11696]               ; 16-byte Spill
	orr.16b	v10, v7, v0
	str	q10, [sp, #3856]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_415
LBB0_304:                               ; %else2305
	ldr	q1, [sp, #3856]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v10, v5
	tbnz	w8, #2, LBB0_416
LBB0_305:                               ; %else2311
	orr.16b	v5, v16, v0
	tbnz	w8, #3, LBB0_417
LBB0_306:                               ; %else2317
	add.2d	v1, v31, v5
	tbnz	w8, #4, LBB0_418
LBB0_307:                               ; %else2323
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_419
LBB0_308:                               ; %else2329
	str	q0, [sp, #1808]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_420
LBB0_309:                               ; %else2335
	str	q4, [sp, #1872]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_311
LBB0_310:                               ; %cond.load2337
	mov.d	x8, v0[1]
	ld1.s	{ v10 }[3], [x8]
LBB0_311:                               ; %else2341
	str	q5, [sp, #1824]                 ; 16-byte Spill
	str	q11, [sp, #11248]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #104                       ; =0x68
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1792]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w9, #0, LBB0_313
; %bb.312:                              ; %cond.load2344
	fmov	x9, d1
	ldr	s5, [x9]
LBB0_313:                               ; %else2348
	str	q27, [sp, #11008]               ; 16-byte Spill
	orr.16b	v11, v7, v0
	str	q11, [sp, #3840]                ; 16-byte Spill
	tbz	w8, #1, LBB0_421
; %bb.314:                              ; %cond.load2350
	mov.d	x9, v1[1]
	mov.16b	v27, v5
	ld1.s	{ v27 }[1], [x9]
	ldr	q1, [sp, #3840]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v5, v4
	tbnz	w8, #2, LBB0_422
	b	LBB0_423
LBB0_315:                               ; %cond.load1596
	fmov	x9, d0
	ld1.s	{ v14 }[2], [x9]
	str	q4, [sp, #2992]                 ; 16-byte Spill
	str	q15, [sp, #2544]                ; 16-byte Spill
	str	q13, [sp, #11216]               ; 16-byte Spill
	tbnz	w8, #7, LBB0_175
	b	LBB0_176
LBB0_316:                               ; %cond.load1609
	fmov	x9, d1
	ldr	s13, [x9]
	orr.16b	v18, v7, v0
	str	q18, [sp, #4080]                ; 16-byte Spill
	tbz	w8, #1, LBB0_178
LBB0_317:                               ; %cond.load1615
	mov.d	x9, v1[1]
	ld1.s	{ v13 }[1], [x9]
	ldr	q1, [sp, #4080]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v18, v4
	tbz	w8, #2, LBB0_179
LBB0_318:                               ; %cond.load1621
	fmov	x9, d1
	ld1.s	{ v13 }[2], [x9]
	orr.16b	v4, v16, v0
	tbz	w8, #3, LBB0_180
LBB0_319:                               ; %cond.load1627
	mov.d	x9, v1[1]
	ld1.s	{ v13 }[3], [x9]
	add.2d	v1, v31, v4
	tbz	w8, #4, LBB0_181
LBB0_320:                               ; %cond.load1633
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_182
LBB0_321:                               ; %cond.load1639
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #2480]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_183
LBB0_322:                               ; %cond.load1645
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	str	q5, [sp, #2928]                 ; 16-byte Spill
	str	q13, [sp, #11184]               ; 16-byte Spill
	tbnz	w8, #7, LBB0_184
	b	LBB0_185
LBB0_323:                               ; %cond.load1658
	fmov	x9, d1
	ldr	s13, [x9]
	orr.16b	v19, v7, v0
	str	q19, [sp, #4064]                ; 16-byte Spill
	tbz	w8, #1, LBB0_187
LBB0_324:                               ; %cond.load1664
	mov.d	x9, v1[1]
	ld1.s	{ v13 }[1], [x9]
	ldr	q1, [sp, #4064]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v19, v5
	tbz	w8, #2, LBB0_188
LBB0_325:                               ; %cond.load1670
	fmov	x9, d1
	ld1.s	{ v13 }[2], [x9]
	orr.16b	v5, v16, v0
	tbz	w8, #3, LBB0_189
LBB0_326:                               ; %cond.load1676
	mov.d	x9, v1[1]
	ld1.s	{ v13 }[3], [x9]
	add.2d	v1, v31, v5
	tbz	w8, #4, LBB0_190
LBB0_327:                               ; %cond.load1682
	fmov	x9, d1
	ld1.s	{ v19 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_191
LBB0_328:                               ; %cond.load1688
	mov.d	x9, v1[1]
	ld1.s	{ v19 }[1], [x9]
	str	q0, [sp, #2432]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_192
LBB0_329:                               ; %cond.load1694
	fmov	x9, d0
	ld1.s	{ v19 }[2], [x9]
	str	q4, [sp, #2496]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_193
	b	LBB0_194
LBB0_330:                               ; %cond.load1707
	fmov	x9, d1
	ldr	s20, [x9]
	str	q20, [sp, #11840]               ; 16-byte Spill
	orr.16b	v20, v7, v0
	str	q20, [sp, #4048]                ; 16-byte Spill
	tbz	w8, #1, LBB0_196
LBB0_331:                               ; %cond.load1713
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11840]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #11840]                ; 16-byte Spill
	ldr	q1, [sp, #4048]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v20, v4
	tbz	w8, #2, LBB0_197
LBB0_332:                               ; %cond.load1719
	fmov	x9, d1
	ldr	q4, [sp, #11840]                ; 16-byte Reload
	ld1.s	{ v4 }[2], [x9]
	str	q4, [sp, #11840]                ; 16-byte Spill
	orr.16b	v4, v16, v0
	tbz	w8, #3, LBB0_198
LBB0_333:                               ; %cond.load1725
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11840]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11840]                ; 16-byte Spill
	add.2d	v1, v31, v4
	tbz	w8, #4, LBB0_199
LBB0_334:                               ; %cond.load1731
	fmov	x9, d1
	ld1.s	{ v20 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_200
LBB0_335:                               ; %cond.load1737
	mov.d	x9, v1[1]
	ld1.s	{ v20 }[1], [x9]
	str	q0, [sp, #2384]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_201
LBB0_336:                               ; %cond.load1743
	fmov	x9, d0
	ld1.s	{ v20 }[2], [x9]
	str	q5, [sp, #2448]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_202
	b	LBB0_203
LBB0_337:                               ; %cond.load1756
	fmov	x9, d1
	ldr	s21, [x9]
	str	q21, [sp, #11824]               ; 16-byte Spill
	orr.16b	v21, v7, v0
	str	q21, [sp, #4032]                ; 16-byte Spill
	tbz	w8, #1, LBB0_205
LBB0_338:                               ; %cond.load1762
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11824]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #11824]                ; 16-byte Spill
	ldr	q1, [sp, #4032]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v21, v5
	tbz	w8, #2, LBB0_206
LBB0_339:                               ; %cond.load1768
	fmov	x9, d1
	ldr	q5, [sp, #11824]                ; 16-byte Reload
	ld1.s	{ v5 }[2], [x9]
	str	q5, [sp, #11824]                ; 16-byte Spill
	orr.16b	v5, v16, v0
	tbz	w8, #3, LBB0_207
LBB0_340:                               ; %cond.load1774
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11824]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11824]                ; 16-byte Spill
	add.2d	v1, v31, v5
	tbz	w8, #4, LBB0_208
LBB0_341:                               ; %cond.load1780
	fmov	x9, d1
	ld1.s	{ v21 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_209
LBB0_342:                               ; %cond.load1786
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[1], [x9]
	str	q0, [sp, #2336]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_210
LBB0_343:                               ; %cond.load1792
	fmov	x9, d0
	ld1.s	{ v21 }[2], [x9]
	str	q4, [sp, #2400]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_211
	b	LBB0_212
LBB0_344:                               ; %cond.load1805
	fmov	x9, d1
	ldr	s22, [x9]
	str	q22, [sp, #11808]               ; 16-byte Spill
	orr.16b	v22, v7, v0
	str	q22, [sp, #4016]                ; 16-byte Spill
	tbz	w8, #1, LBB0_214
LBB0_345:                               ; %cond.load1811
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11808]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #11808]                ; 16-byte Spill
	ldr	q1, [sp, #4016]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v22, v4
	tbz	w8, #2, LBB0_215
LBB0_346:                               ; %cond.load1817
	fmov	x9, d1
	ldr	q4, [sp, #11808]                ; 16-byte Reload
	ld1.s	{ v4 }[2], [x9]
	str	q4, [sp, #11808]                ; 16-byte Spill
	orr.16b	v4, v16, v0
	tbz	w8, #3, LBB0_216
LBB0_347:                               ; %cond.load1823
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11808]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11808]                ; 16-byte Spill
	add.2d	v1, v31, v4
	tbz	w8, #4, LBB0_217
LBB0_348:                               ; %cond.load1829
	fmov	x9, d1
	ld1.s	{ v22 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_218
LBB0_349:                               ; %cond.load1835
	mov.d	x9, v1[1]
	ld1.s	{ v22 }[1], [x9]
	str	q0, [sp, #2288]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_219
LBB0_350:                               ; %cond.load1841
	fmov	x9, d0
	ld1.s	{ v22 }[2], [x9]
	str	q5, [sp, #2352]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_220
	b	LBB0_221
LBB0_351:                               ; %cond.load1854
	fmov	x9, d1
	ldr	s23, [x9]
	str	q23, [sp, #11792]               ; 16-byte Spill
	orr.16b	v23, v7, v0
	str	q23, [sp, #4000]                ; 16-byte Spill
	tbz	w8, #1, LBB0_223
LBB0_352:                               ; %cond.load1860
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11792]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #11792]                ; 16-byte Spill
	ldr	q1, [sp, #4000]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v23, v5
	tbz	w8, #2, LBB0_224
LBB0_353:                               ; %cond.load1866
	fmov	x9, d1
	ldr	q5, [sp, #11792]                ; 16-byte Reload
	ld1.s	{ v5 }[2], [x9]
	str	q5, [sp, #11792]                ; 16-byte Spill
	orr.16b	v5, v16, v0
	tbz	w8, #3, LBB0_225
LBB0_354:                               ; %cond.load1872
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11792]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11792]                ; 16-byte Spill
	add.2d	v1, v31, v5
	tbz	w8, #4, LBB0_226
LBB0_355:                               ; %cond.load1878
	fmov	x9, d1
	ld1.s	{ v23 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_227
LBB0_356:                               ; %cond.load1884
	mov.d	x9, v1[1]
	ld1.s	{ v23 }[1], [x9]
	str	q0, [sp, #2240]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_228
LBB0_357:                               ; %cond.load1890
	fmov	x9, d0
	ld1.s	{ v23 }[2], [x9]
	str	q4, [sp, #2304]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_229
	b	LBB0_230
LBB0_358:                               ; %cond.load1903
	fmov	x9, d1
	ldr	s24, [x9]
	str	q24, [sp, #11776]               ; 16-byte Spill
	orr.16b	v24, v7, v0
	str	q24, [sp, #3984]                ; 16-byte Spill
	tbz	w8, #1, LBB0_232
LBB0_359:                               ; %cond.load1909
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11776]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #11776]                ; 16-byte Spill
	ldr	q1, [sp, #3984]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v24, v4
	tbz	w8, #2, LBB0_233
LBB0_360:                               ; %cond.load1915
	fmov	x9, d1
	ldr	q4, [sp, #11776]                ; 16-byte Reload
	ld1.s	{ v4 }[2], [x9]
	str	q4, [sp, #11776]                ; 16-byte Spill
	orr.16b	v4, v16, v0
	tbz	w8, #3, LBB0_234
LBB0_361:                               ; %cond.load1921
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11776]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11776]                ; 16-byte Spill
	add.2d	v1, v31, v4
	tbz	w8, #4, LBB0_235
LBB0_362:                               ; %cond.load1927
	fmov	x9, d1
	ld1.s	{ v24 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_236
LBB0_363:                               ; %cond.load1933
	mov.d	x9, v1[1]
	ld1.s	{ v24 }[1], [x9]
	str	q0, [sp, #2192]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_237
LBB0_364:                               ; %cond.load1939
	fmov	x9, d0
	ld1.s	{ v24 }[2], [x9]
	str	q5, [sp, #2256]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_238
	b	LBB0_239
LBB0_365:                               ; %cond.load1952
	fmov	x9, d1
	ldr	s26, [x9]
	str	q26, [sp, #11760]               ; 16-byte Spill
	orr.16b	v26, v7, v0
	str	q26, [sp, #3968]                ; 16-byte Spill
	tbz	w8, #1, LBB0_241
LBB0_366:                               ; %cond.load1958
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #11760]                ; 16-byte Spill
	ldr	q1, [sp, #3968]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v26, v5
	tbz	w8, #2, LBB0_242
LBB0_367:                               ; %cond.load1964
	fmov	x9, d1
	ldr	q5, [sp, #11760]                ; 16-byte Reload
	ld1.s	{ v5 }[2], [x9]
	str	q5, [sp, #11760]                ; 16-byte Spill
	orr.16b	v5, v16, v0
	tbz	w8, #3, LBB0_243
LBB0_368:                               ; %cond.load1970
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11760]                ; 16-byte Spill
	add.2d	v1, v31, v5
	tbz	w8, #4, LBB0_244
LBB0_369:                               ; %cond.load1976
	fmov	x9, d1
	ld1.s	{ v26 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_245
LBB0_370:                               ; %cond.load1982
	mov.d	x9, v1[1]
	ld1.s	{ v26 }[1], [x9]
	str	q0, [sp, #2144]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_246
LBB0_371:                               ; %cond.load1988
	fmov	x9, d0
	ld1.s	{ v26 }[2], [x9]
	str	q13, [sp, #11152]               ; 16-byte Spill
	tbnz	w8, #7, LBB0_247
	b	LBB0_248
LBB0_372:                               ; %cond.load2001
	fmov	x9, d1
	ldr	s15, [x9]
	orr.16b	v27, v7, v0
	str	q27, [sp, #3952]                ; 16-byte Spill
	tbz	w8, #1, LBB0_250
LBB0_373:                               ; %cond.load2007
	mov.d	x9, v1[1]
	ld1.s	{ v15 }[1], [x9]
	ldr	q1, [sp, #3952]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_251
LBB0_374:                               ; %cond.load2013
	fmov	x9, d1
	ld1.s	{ v15 }[2], [x9]
	str	q15, [sp, #11632]               ; 16-byte Spill
	orr.16b	v27, v16, v0
	tbz	w8, #3, LBB0_252
LBB0_375:                               ; %cond.load2019
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11632]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11632]                ; 16-byte Spill
	add.2d	v1, v31, v27
	tbz	w8, #4, LBB0_253
LBB0_376:                               ; %cond.load2025
	fmov	x9, d1
	ld1.s	{ v13 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_254
LBB0_377:                               ; %cond.load2031
	mov.d	x9, v1[1]
	ld1.s	{ v13 }[1], [x9]
	str	q0, [sp, #2096]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_255
LBB0_378:                               ; %cond.load2037
	fmov	x9, d0
	ld1.s	{ v13 }[2], [x9]
	str	q4, [sp, #2208]                 ; 16-byte Spill
	str	q27, [sp, #2112]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_256
	b	LBB0_257
LBB0_379:                               ; %cond.load2050
	fmov	x9, d1
	ldr	s27, [x9]
	orr.16b	v28, v7, v0
	str	q28, [sp, #3936]                ; 16-byte Spill
	tbz	w8, #1, LBB0_259
LBB0_380:                               ; %cond.load2056
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[1], [x9]
	ldr	q1, [sp, #3936]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v28, v4
	tbz	w8, #2, LBB0_260
LBB0_381:                               ; %cond.load2062
	fmov	x9, d1
	ld1.s	{ v27 }[2], [x9]
	orr.16b	v4, v16, v0
	tbz	w8, #3, LBB0_261
LBB0_382:                               ; %cond.load2068
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[3], [x9]
	add.2d	v1, v31, v4
	tbz	w8, #4, LBB0_262
LBB0_383:                               ; %cond.load2074
	fmov	x9, d1
	ld1.s	{ v28 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_263
LBB0_384:                               ; %cond.load2080
	mov.d	x9, v1[1]
	ld1.s	{ v28 }[1], [x9]
	str	q0, [sp, #2048]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_264
LBB0_385:                               ; %cond.load2086
	fmov	x9, d0
	ld1.s	{ v28 }[2], [x9]
	str	q5, [sp, #2160]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_265
	b	LBB0_266
LBB0_386:                               ; %cond.load2099
	fmov	x9, d1
	ldr	s15, [x9]
	orr.16b	v29, v7, v0
	str	q29, [sp, #3920]                ; 16-byte Spill
	tbz	w8, #1, LBB0_268
LBB0_387:                               ; %cond.load2105
	mov.d	x9, v1[1]
	ld1.s	{ v15 }[1], [x9]
	ldr	q1, [sp, #3920]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v29, v5
	tbz	w8, #2, LBB0_269
LBB0_388:                               ; %cond.load2111
	fmov	x9, d1
	ld1.s	{ v15 }[2], [x9]
	orr.16b	v5, v16, v0
	tbz	w8, #3, LBB0_270
LBB0_389:                               ; %cond.load2117
	mov.d	x9, v1[1]
	ld1.s	{ v15 }[3], [x9]
	add.2d	v1, v31, v5
	tbz	w8, #4, LBB0_271
LBB0_390:                               ; %cond.load2123
	fmov	x9, d1
	ld1.s	{ v29 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_272
LBB0_391:                               ; %cond.load2129
	mov.d	x9, v1[1]
	ld1.s	{ v29 }[1], [x9]
	str	q0, [sp, #2000]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_273
LBB0_392:                               ; %cond.load2135
	fmov	x9, d0
	ld1.s	{ v29 }[2], [x9]
	str	q4, [sp, #2064]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_274
	b	LBB0_275
LBB0_393:                               ; %cond.load2148
	fmov	x9, d1
	ldr	s30, [x9]
	str	q30, [sp, #11744]               ; 16-byte Spill
	orr.16b	v30, v7, v0
	str	q30, [sp, #3904]                ; 16-byte Spill
	tbz	w8, #1, LBB0_277
LBB0_394:                               ; %cond.load2154
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11744]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #11744]                ; 16-byte Spill
	ldr	q1, [sp, #3904]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v30, v4
	tbz	w8, #2, LBB0_278
LBB0_395:                               ; %cond.load2160
	fmov	x9, d1
	ldr	q4, [sp, #11744]                ; 16-byte Reload
	ld1.s	{ v4 }[2], [x9]
	str	q4, [sp, #11744]                ; 16-byte Spill
	orr.16b	v4, v16, v0
	tbz	w8, #3, LBB0_279
LBB0_396:                               ; %cond.load2166
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11744]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11744]                ; 16-byte Spill
	add.2d	v1, v31, v4
	tbz	w8, #4, LBB0_280
LBB0_397:                               ; %cond.load2172
	fmov	x9, d1
	ld1.s	{ v30 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_281
LBB0_398:                               ; %cond.load2178
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[1], [x9]
	str	q0, [sp, #1952]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_282
LBB0_399:                               ; %cond.load2184
	fmov	x9, d0
	ld1.s	{ v30 }[2], [x9]
	str	q5, [sp, #2016]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_283
	b	LBB0_284
LBB0_400:                               ; %cond.load2197
	fmov	x9, d1
	ldr	s8, [x9]
	str	q8, [sp, #11728]                ; 16-byte Spill
	orr.16b	v8, v7, v0
	str	q8, [sp, #3888]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_286
LBB0_401:                               ; %cond.load2203
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11728]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #11728]                ; 16-byte Spill
	ldr	q1, [sp, #3888]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v8, v5
	tbz	w8, #2, LBB0_287
LBB0_402:                               ; %cond.load2209
	fmov	x9, d1
	ldr	q5, [sp, #11728]                ; 16-byte Reload
	ld1.s	{ v5 }[2], [x9]
	str	q5, [sp, #11728]                ; 16-byte Spill
	orr.16b	v5, v16, v0
	tbz	w8, #3, LBB0_288
LBB0_403:                               ; %cond.load2215
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11728]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11728]                ; 16-byte Spill
	add.2d	v1, v31, v5
	tbz	w8, #4, LBB0_289
LBB0_404:                               ; %cond.load2221
	fmov	x9, d1
	ld1.s	{ v8 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_290
LBB0_405:                               ; %cond.load2227
	mov.d	x9, v1[1]
	ld1.s	{ v8 }[1], [x9]
	str	q0, [sp, #1904]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_291
LBB0_406:                               ; %cond.load2233
	fmov	x9, d0
	ld1.s	{ v8 }[2], [x9]
	str	q4, [sp, #1968]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_292
	b	LBB0_293
LBB0_407:                               ; %cond.load2246
	fmov	x9, d1
	ldr	s9, [x9]
	str	q9, [sp, #11712]                ; 16-byte Spill
	orr.16b	v9, v7, v0
	str	q9, [sp, #3872]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_295
LBB0_408:                               ; %cond.load2252
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11712]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #11712]                ; 16-byte Spill
	ldr	q1, [sp, #3872]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v9, v4
	tbz	w8, #2, LBB0_296
LBB0_409:                               ; %cond.load2258
	fmov	x9, d1
	ldr	q4, [sp, #11712]                ; 16-byte Reload
	ld1.s	{ v4 }[2], [x9]
	str	q4, [sp, #11712]                ; 16-byte Spill
	orr.16b	v4, v16, v0
	tbz	w8, #3, LBB0_297
LBB0_410:                               ; %cond.load2264
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11712]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11712]                ; 16-byte Spill
	add.2d	v1, v31, v4
	tbz	w8, #4, LBB0_298
LBB0_411:                               ; %cond.load2270
	fmov	x9, d1
	ld1.s	{ v9 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_299
LBB0_412:                               ; %cond.load2276
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	str	q0, [sp, #1856]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_300
LBB0_413:                               ; %cond.load2282
	fmov	x9, d0
	ld1.s	{ v9 }[2], [x9]
	str	q5, [sp, #1920]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_301
	b	LBB0_302
LBB0_414:                               ; %cond.load2295
	fmov	x9, d1
	ldr	s10, [x9]
	str	q10, [sp, #11696]               ; 16-byte Spill
	orr.16b	v10, v7, v0
	str	q10, [sp, #3856]                ; 16-byte Spill
	tbz	w8, #1, LBB0_304
LBB0_415:                               ; %cond.load2301
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11696]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #11696]                ; 16-byte Spill
	ldr	q1, [sp, #3856]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v10, v5
	tbz	w8, #2, LBB0_305
LBB0_416:                               ; %cond.load2307
	fmov	x9, d1
	ldr	q5, [sp, #11696]                ; 16-byte Reload
	ld1.s	{ v5 }[2], [x9]
	str	q5, [sp, #11696]                ; 16-byte Spill
	orr.16b	v5, v16, v0
	tbz	w8, #3, LBB0_306
LBB0_417:                               ; %cond.load2313
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11696]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11696]                ; 16-byte Spill
	add.2d	v1, v31, v5
	tbz	w8, #4, LBB0_307
LBB0_418:                               ; %cond.load2319
	fmov	x9, d1
	ld1.s	{ v10 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_308
LBB0_419:                               ; %cond.load2325
	mov.d	x9, v1[1]
	ld1.s	{ v10 }[1], [x9]
	str	q0, [sp, #1808]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_309
LBB0_420:                               ; %cond.load2331
	fmov	x9, d0
	ld1.s	{ v10 }[2], [x9]
	str	q4, [sp, #1872]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_310
	b	LBB0_311
LBB0_421:
	mov.16b	v27, v5
	ldr	q1, [sp, #3840]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v5, v4
	tbz	w8, #2, LBB0_423
LBB0_422:                               ; %cond.load2356
	fmov	x9, d1
	ld1.s	{ v27 }[2], [x9]
LBB0_423:                               ; %else2360
	orr.16b	v4, v16, v0
	tbnz	w8, #3, LBB0_685
; %bb.424:                              ; %else2366
	add.2d	v1, v31, v4
	tbnz	w8, #4, LBB0_686
LBB0_425:                               ; %else2372
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_687
LBB0_426:                               ; %else2378
	str	q0, [sp, #1760]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_688
LBB0_427:                               ; %else2384
	tbz	w8, #7, LBB0_429
LBB0_428:                               ; %cond.load2386
	mov.d	x8, v0[1]
	ld1.s	{ v5 }[3], [x8]
LBB0_429:                               ; %else2390
	str	q27, [sp, #10880]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #108                       ; =0x6c
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1744]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v27, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbnz	w9, #0, LBB0_689
; %bb.430:                              ; %else2397
	orr.16b	v12, v7, v0
	str	q12, [sp, #3824]                ; 16-byte Spill
	str	q5, [sp, #10864]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_690
LBB0_431:                               ; %else2403
	ldr	q1, [sp, #3824]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v5, v11
	tbnz	w8, #2, LBB0_691
LBB0_432:                               ; %else2409
	orr.16b	v11, v16, v0
	tbnz	w8, #3, LBB0_692
LBB0_433:                               ; %else2415
	add.2d	v1, v31, v11
	tbnz	w8, #4, LBB0_693
LBB0_434:                               ; %else2421
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_694
LBB0_435:                               ; %else2427
	str	q0, [sp, #1712]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_695
LBB0_436:                               ; %else2433
	str	q4, [sp, #1776]                 ; 16-byte Spill
	str	q11, [sp, #1728]                ; 16-byte Spill
	tbz	w8, #7, LBB0_438
LBB0_437:                               ; %cond.load2435
	mov.d	x8, v0[1]
	ld1.s	{ v5 }[3], [x8]
LBB0_438:                               ; %else2439
	str	q13, [sp, #11024]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #112                       ; =0x70
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1696]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v11, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB0_696
; %bb.439:                              ; %else2446
	orr.16b	v13, v7, v0
	str	q13, [sp, #3808]                ; 16-byte Spill
	str	q27, [sp, #10848]               ; 16-byte Spill
	tbnz	w8, #1, LBB0_697
LBB0_440:                               ; %else2452
	ldr	q1, [sp, #3808]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v12, v4
	tbnz	w8, #2, LBB0_698
LBB0_441:                               ; %else2458
	orr.16b	v4, v16, v0
	tbnz	w8, #3, LBB0_699
LBB0_442:                               ; %else2464
	add.2d	v1, v31, v4
	tbnz	w8, #4, LBB0_700
LBB0_443:                               ; %else2470
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_701
LBB0_444:                               ; %else2476
	str	q0, [sp, #1664]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_702
LBB0_445:                               ; %else2482
	str	q4, [sp, #1680]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_447
LBB0_446:                               ; %cond.load2484
	mov.d	x8, v0[1]
	ld1.s	{ v12 }[3], [x8]
LBB0_447:                               ; %else2488
	str	q12, [sp, #11680]               ; 16-byte Spill
	str	q14, [sp, #11200]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #116                       ; =0x74
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1648]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v4, #0000000000000000
	movi.2d	v12, #0000000000000000
	tbnz	w9, #0, LBB0_703
; %bb.448:                              ; %else2495
	orr.16b	v14, v7, v0
	str	q14, [sp, #3792]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_704
LBB0_449:                               ; %else2501
	ldr	q1, [sp, #3792]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v13, v12
	tbnz	w8, #2, LBB0_705
LBB0_450:                               ; %else2507
	orr.16b	v12, v16, v0
	tbnz	w8, #3, LBB0_706
LBB0_451:                               ; %else2513
	add.2d	v1, v31, v12
	tbnz	w8, #4, LBB0_707
LBB0_452:                               ; %else2519
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_708
LBB0_453:                               ; %else2525
	str	q0, [sp, #1616]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_709
LBB0_454:                               ; %else2531
	str	q12, [sp, #1632]                ; 16-byte Spill
	tbz	w8, #7, LBB0_456
LBB0_455:                               ; %cond.load2533
	mov.d	x8, v0[1]
	ld1.s	{ v13 }[3], [x8]
LBB0_456:                               ; %else2537
	str	q13, [sp, #11664]               ; 16-byte Spill
	str	q15, [sp, #10976]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #120                       ; =0x78
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1600]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v27, #0000000000000000
	movi.2d	v13, #0000000000000000
	tbnz	w9, #0, LBB0_710
; %bb.457:                              ; %else2544
	orr.16b	v15, v7, v0
	str	q15, [sp, #3776]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_711
LBB0_458:                               ; %else2550
	ldr	q1, [sp, #3776]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v14, v13
	tbnz	w8, #2, LBB0_712
LBB0_459:                               ; %else2556
	orr.16b	v13, v16, v0
	tbnz	w8, #3, LBB0_713
LBB0_460:                               ; %else2562
	add.2d	v1, v31, v13
	tbnz	w8, #4, LBB0_714
LBB0_461:                               ; %else2568
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_715
LBB0_462:                               ; %else2574
	str	q0, [sp, #1568]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_716
LBB0_463:                               ; %else2580
	str	q13, [sp, #1584]                ; 16-byte Spill
	tbz	w8, #7, LBB0_465
LBB0_464:                               ; %cond.load2582
	mov.d	x8, v0[1]
	ld1.s	{ v14 }[3], [x8]
LBB0_465:                               ; %else2586
	str	q14, [sp, #10768]               ; 16-byte Spill
	str	q18, [sp, #11168]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #124                       ; =0x7c
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1552]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbnz	w9, #0, LBB0_717
; %bb.466:                              ; %else2593
	orr.16b	v18, v7, v0
	str	q18, [sp, #3760]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_718
LBB0_467:                               ; %else2599
	ldr	q1, [sp, #3760]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_719
LBB0_468:                               ; %else2605
	orr.16b	v18, v16, v0
	tbnz	w8, #3, LBB0_720
LBB0_469:                               ; %else2611
	add.2d	v1, v31, v18
	tbnz	w8, #4, LBB0_721
LBB0_470:                               ; %else2617
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_722
LBB0_471:                               ; %else2623
	str	q0, [sp, #1520]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_723
LBB0_472:                               ; %else2629
	str	q18, [sp, #1536]                ; 16-byte Spill
	tbz	w8, #7, LBB0_474
LBB0_473:                               ; %cond.load2631
	mov.d	x8, v0[1]
	ld1.s	{ v14 }[3], [x8]
LBB0_474:                               ; %else2635
	str	q14, [sp, #10736]               ; 16-byte Spill
	str	q19, [sp, #11136]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #128                       ; =0x80
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1504]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v14, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_724
; %bb.475:                              ; %else2642
	orr.16b	v19, v7, v0
	str	q19, [sp, #3744]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_725
LBB0_476:                               ; %else2648
	ldr	q1, [sp, #3744]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v19, v18
	tbnz	w8, #2, LBB0_726
LBB0_477:                               ; %else2654
	orr.16b	v18, v16, v0
	tbnz	w8, #3, LBB0_727
LBB0_478:                               ; %else2660
	add.2d	v1, v31, v18
	tbnz	w8, #4, LBB0_728
LBB0_479:                               ; %else2666
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_729
LBB0_480:                               ; %else2672
	str	q0, [sp, #1472]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_730
LBB0_481:                               ; %else2678
	str	q18, [sp, #1488]                ; 16-byte Spill
	str	q27, [sp, #10784]               ; 16-byte Spill
	tbz	w8, #7, LBB0_483
LBB0_482:                               ; %cond.load2680
	mov.d	x8, v0[1]
	ld1.s	{ v19 }[3], [x8]
LBB0_483:                               ; %else2684
	str	q20, [sp, #11120]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #132                       ; =0x84
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1456]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v27, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_731
; %bb.484:                              ; %else2691
	orr.16b	v20, v7, v0
	str	q20, [sp, #3728]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_732
LBB0_485:                               ; %else2697
	ldr	q1, [sp, #3728]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v20, v18
	tbnz	w8, #2, LBB0_733
LBB0_486:                               ; %else2703
	orr.16b	v18, v16, v0
	tbnz	w8, #3, LBB0_734
LBB0_487:                               ; %else2709
	add.2d	v1, v31, v18
	tbnz	w8, #4, LBB0_735
LBB0_488:                               ; %else2715
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_736
LBB0_489:                               ; %else2721
	str	q0, [sp, #1424]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_737
LBB0_490:                               ; %else2727
	str	q18, [sp, #1440]                ; 16-byte Spill
	str	q19, [sp, #10704]               ; 16-byte Spill
	tbz	w8, #7, LBB0_492
LBB0_491:                               ; %cond.load2729
	mov.d	x8, v0[1]
	ld1.s	{ v20 }[3], [x8]
LBB0_492:                               ; %else2733
	str	q21, [sp, #11104]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #136                       ; =0x88
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1408]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v15, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbnz	w9, #0, LBB0_738
; %bb.493:                              ; %else2740
	orr.16b	v21, v7, v0
	str	q21, [sp, #3712]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_739
LBB0_494:                               ; %else2746
	ldr	q1, [sp, #3712]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v18, v19
	tbnz	w8, #2, LBB0_740
LBB0_495:                               ; %else2752
	orr.16b	v19, v16, v0
	tbnz	w8, #3, LBB0_741
LBB0_496:                               ; %else2758
	add.2d	v1, v31, v19
	tbnz	w8, #4, LBB0_742
LBB0_497:                               ; %else2764
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_743
LBB0_498:                               ; %else2770
	str	q0, [sp, #1376]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_744
LBB0_499:                               ; %else2776
	str	q19, [sp, #1392]                ; 16-byte Spill
	str	q20, [sp, #10672]               ; 16-byte Spill
	tbz	w8, #7, LBB0_501
LBB0_500:                               ; %cond.load2778
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_501:                               ; %else2782
	str	q22, [sp, #11088]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #140                       ; =0x8c
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1360]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v21, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w9, #0, LBB0_745
; %bb.502:                              ; %else2789
	orr.16b	v22, v7, v0
	str	q22, [sp, #3696]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_746
LBB0_503:                               ; %else2795
	ldr	q1, [sp, #3696]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v19, v20
	tbnz	w8, #2, LBB0_747
LBB0_504:                               ; %else2801
	orr.16b	v20, v16, v0
	tbnz	w8, #3, LBB0_748
LBB0_505:                               ; %else2807
	add.2d	v1, v31, v20
	tbnz	w8, #4, LBB0_749
LBB0_506:                               ; %else2813
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_750
LBB0_507:                               ; %else2819
	str	q0, [sp, #1328]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_751
LBB0_508:                               ; %else2825
	str	q20, [sp, #1344]                ; 16-byte Spill
	str	q21, [sp, #11648]               ; 16-byte Spill
	tbz	w8, #7, LBB0_510
LBB0_509:                               ; %cond.load2827
	mov.d	x8, v0[1]
	ld1.s	{ v19 }[3], [x8]
LBB0_510:                               ; %else2831
	str	q23, [sp, #11072]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #144                       ; =0x90
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1312]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w9, #0, LBB0_752
; %bb.511:                              ; %else2838
	orr.16b	v23, v7, v0
	str	q23, [sp, #3680]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_753
LBB0_512:                               ; %else2844
	ldr	q1, [sp, #3680]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	str	q5, [sp, #10832]                ; 16-byte Spill
	tbnz	w8, #2, LBB0_754
LBB0_513:                               ; %else2850
	orr.16b	v5, v16, v0
	tbnz	w8, #3, LBB0_755
LBB0_514:                               ; %else2856
	add.2d	v1, v31, v5
	tbnz	w8, #4, LBB0_756
LBB0_515:                               ; %else2862
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_757
LBB0_516:                               ; %else2868
	str	q0, [sp, #1280]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_758
LBB0_517:                               ; %else2874
	tbz	w8, #7, LBB0_519
LBB0_518:                               ; %cond.load2876
	mov.d	x8, v0[1]
	ld1.s	{ v21 }[3], [x8]
LBB0_519:                               ; %else2880
	str	q21, [sp, #10592]               ; 16-byte Spill
	str	q24, [sp, #11056]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #148                       ; =0x94
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1264]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbnz	w9, #0, LBB0_759
; %bb.520:                              ; %else2887
	orr.16b	v24, v7, v0
	str	q24, [sp, #3664]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_760
LBB0_521:                               ; %else2893
	ldr	q1, [sp, #3664]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	str	q18, [sp, #10640]               ; 16-byte Spill
	tbnz	w8, #2, LBB0_761
LBB0_522:                               ; %else2899
	orr.16b	v18, v16, v0
	tbnz	w8, #3, LBB0_762
LBB0_523:                               ; %else2905
	add.2d	v1, v31, v18
	tbnz	w8, #4, LBB0_763
LBB0_524:                               ; %else2911
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_764
LBB0_525:                               ; %else2917
	str	q0, [sp, #1232]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_765
LBB0_526:                               ; %else2923
	tbz	w8, #7, LBB0_528
LBB0_527:                               ; %cond.load2925
	mov.d	x8, v0[1]
	ld1.s	{ v22 }[3], [x8]
LBB0_528:                               ; %else2929
	str	q22, [sp, #10544]               ; 16-byte Spill
	str	q26, [sp, #11040]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #152                       ; =0x98
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1216]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w9, #0, LBB0_766
; %bb.529:                              ; %else2936
	orr.16b	v26, v7, v0
	str	q26, [sp, #3648]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_767
LBB0_530:                               ; %else2942
	ldr	q1, [sp, #3648]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	str	q19, [sp, #10624]               ; 16-byte Spill
	tbnz	w8, #2, LBB0_768
LBB0_531:                               ; %else2948
	orr.16b	v19, v16, v0
	tbnz	w8, #3, LBB0_769
LBB0_532:                               ; %else2954
	add.2d	v1, v31, v19
	tbnz	w8, #4, LBB0_770
LBB0_533:                               ; %else2960
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_771
LBB0_534:                               ; %else2966
	str	q0, [sp, #1184]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_772
LBB0_535:                               ; %else2972
	tbz	w8, #7, LBB0_537
LBB0_536:                               ; %cond.load2974
	mov.d	x8, v0[1]
	ld1.s	{ v23 }[3], [x8]
LBB0_537:                               ; %else2978
	str	q23, [sp, #10480]               ; 16-byte Spill
	str	q27, [sp, #10688]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #156                       ; =0x9c
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1168]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w9, #0, LBB0_773
; %bb.538:                              ; %else2985
	orr.16b	v27, v7, v0
	str	q27, [sp, #3632]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_774
LBB0_539:                               ; %else2991
	ldr	q1, [sp, #3632]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	str	q20, [sp, #10608]               ; 16-byte Spill
	tbnz	w8, #2, LBB0_775
LBB0_540:                               ; %else2997
	orr.16b	v20, v16, v0
	tbnz	w8, #3, LBB0_776
LBB0_541:                               ; %else3003
	add.2d	v1, v31, v20
	tbnz	w8, #4, LBB0_777
LBB0_542:                               ; %else3009
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_778
LBB0_543:                               ; %else3015
	str	q0, [sp, #1136]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_779
LBB0_544:                               ; %else3021
	tbz	w8, #7, LBB0_546
LBB0_545:                               ; %cond.load3023
	mov.d	x8, v0[1]
	ld1.s	{ v24 }[3], [x8]
LBB0_546:                               ; %else3027
	str	q24, [sp, #10448]               ; 16-byte Spill
	str	q28, [sp, #10992]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #160                       ; =0xa0
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1120]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v24, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbnz	w9, #0, LBB0_780
; %bb.547:                              ; %else3034
	orr.16b	v28, v7, v0
	str	q28, [sp, #3616]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_781
LBB0_548:                               ; %else3040
	ldr	q1, [sp, #3616]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v27, v26
	tbnz	w8, #2, LBB0_782
LBB0_549:                               ; %else3046
	orr.16b	v26, v16, v0
	tbnz	w8, #3, LBB0_783
LBB0_550:                               ; %else3052
	add.2d	v1, v31, v26
	tbnz	w8, #4, LBB0_784
LBB0_551:                               ; %else3058
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_785
LBB0_552:                               ; %else3064
	str	q0, [sp, #1088]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_786
LBB0_553:                               ; %else3070
	str	q26, [sp, #1104]                ; 16-byte Spill
	tbz	w8, #7, LBB0_555
LBB0_554:                               ; %cond.load3072
	mov.d	x8, v0[1]
	ld1.s	{ v27 }[3], [x8]
LBB0_555:                               ; %else3076
	str	q27, [sp, #10336]               ; 16-byte Spill
	str	q29, [sp, #10960]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #164                       ; =0xa4
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1072]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w9, #0, LBB0_787
; %bb.556:                              ; %else3083
	orr.16b	v29, v7, v0
	str	q29, [sp, #3600]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_788
LBB0_557:                               ; %else3089
	ldr	q1, [sp, #3600]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v28, v27
	tbnz	w8, #2, LBB0_789
LBB0_558:                               ; %else3095
	orr.16b	v27, v16, v0
	tbnz	w8, #3, LBB0_790
LBB0_559:                               ; %else3101
	add.2d	v1, v31, v27
	tbnz	w8, #4, LBB0_791
LBB0_560:                               ; %else3107
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_792
LBB0_561:                               ; %else3113
	str	q0, [sp, #1040]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_793
LBB0_562:                               ; %else3119
	str	q27, [sp, #1056]                ; 16-byte Spill
	tbz	w8, #7, LBB0_564
LBB0_563:                               ; %cond.load3121
	mov.d	x8, v0[1]
	ld1.s	{ v28 }[3], [x8]
LBB0_564:                               ; %else3125
	str	q28, [sp, #10224]               ; 16-byte Spill
	str	q30, [sp, #10944]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #168                       ; =0xa8
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #1024]                 ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w9, #0, LBB0_794
; %bb.565:                              ; %else3132
	orr.16b	v30, v7, v0
	str	q30, [sp, #3584]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_795
LBB0_566:                               ; %else3138
	ldr	q1, [sp, #3584]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v29, v28
	tbnz	w8, #2, LBB0_796
LBB0_567:                               ; %else3144
	orr.16b	v28, v16, v0
	tbnz	w8, #3, LBB0_797
LBB0_568:                               ; %else3150
	add.2d	v1, v31, v28
	tbnz	w8, #4, LBB0_798
LBB0_569:                               ; %else3156
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_799
LBB0_570:                               ; %else3162
	str	q0, [sp, #992]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_800
LBB0_571:                               ; %else3168
	str	q28, [sp, #1008]                ; 16-byte Spill
	tbz	w8, #7, LBB0_573
LBB0_572:                               ; %cond.load3170
	mov.d	x8, v0[1]
	ld1.s	{ v29 }[3], [x8]
LBB0_573:                               ; %else3174
	str	q29, [sp, #9936]                ; 16-byte Spill
	str	q8, [sp, #10928]                ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #172                       ; =0xac
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #976]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w9, #0, LBB0_801
; %bb.574:                              ; %else3181
	orr.16b	v8, v7, v0
	str	q8, [sp, #3568]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_802
LBB0_575:                               ; %else3187
	ldr	q1, [sp, #3568]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v30, v29
	tbnz	w8, #2, LBB0_803
LBB0_576:                               ; %else3193
	orr.16b	v29, v16, v0
	tbnz	w8, #3, LBB0_804
LBB0_577:                               ; %else3199
	add.2d	v1, v31, v29
	tbnz	w8, #4, LBB0_805
LBB0_578:                               ; %else3205
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_806
LBB0_579:                               ; %else3211
	str	q0, [sp, #944]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_807
LBB0_580:                               ; %else3217
	str	q29, [sp, #960]                 ; 16-byte Spill
	str	q15, [sp, #10656]               ; 16-byte Spill
	tbz	w8, #7, LBB0_582
LBB0_581:                               ; %cond.load3219
	mov.d	x8, v0[1]
	ld1.s	{ v30 }[3], [x8]
LBB0_582:                               ; %else3223
	str	q9, [sp, #10912]                ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #176                       ; =0xb0
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #928]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v12, #0000000000000000
	movi.2d	v8, #0000000000000000
	tbnz	w9, #0, LBB0_808
; %bb.583:                              ; %else3230
	orr.16b	v9, v7, v0
	str	q9, [sp, #3552]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_809
LBB0_584:                               ; %else3236
	ldr	q1, [sp, #3552]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	str	q21, [sp, #10576]               ; 16-byte Spill
	tbnz	w8, #2, LBB0_810
LBB0_585:                               ; %else3242
	orr.16b	v21, v16, v0
	tbnz	w8, #3, LBB0_811
LBB0_586:                               ; %else3248
	add.2d	v1, v31, v21
	tbnz	w8, #4, LBB0_812
LBB0_587:                               ; %else3254
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_813
LBB0_588:                               ; %else3260
	str	q0, [sp, #896]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_814
LBB0_589:                               ; %else3266
	str	q5, [sp, #1296]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_591
LBB0_590:                               ; %cond.load3268
	mov.d	x8, v0[1]
	ld1.s	{ v8 }[3], [x8]
LBB0_591:                               ; %else3272
	str	q10, [sp, #10896]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #180                       ; =0xb4
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #880]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v15, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w9, #0, LBB0_815
; %bb.592:                              ; %else3279
	orr.16b	v10, v7, v0
	str	q10, [sp, #3536]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_816
LBB0_593:                               ; %else3285
	ldr	q1, [sp, #3536]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v10, v5
	tbnz	w8, #2, LBB0_817
LBB0_594:                               ; %else3291
	orr.16b	v5, v16, v0
	tbnz	w8, #3, LBB0_818
LBB0_595:                               ; %else3297
	add.2d	v1, v31, v5
	tbnz	w8, #4, LBB0_819
LBB0_596:                               ; %else3303
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_820
LBB0_597:                               ; %else3309
	str	q0, [sp, #848]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_821
LBB0_598:                               ; %else3315
	str	q18, [sp, #1248]                ; 16-byte Spill
	str	q5, [sp, #864]                  ; 16-byte Spill
	tbz	w8, #7, LBB0_600
LBB0_599:                               ; %cond.load3317
	mov.d	x8, v0[1]
	ld1.s	{ v10 }[3], [x8]
LBB0_600:                               ; %else3321
	str	q11, [sp, #10816]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #184                       ; =0xb8
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #832]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v5, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_822
; %bb.601:                              ; %else3328
	orr.16b	v11, v7, v0
	str	q11, [sp, #3520]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_823
LBB0_602:                               ; %else3334
	ldr	q1, [sp, #3520]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v11, v18
	tbnz	w8, #2, LBB0_824
LBB0_603:                               ; %else3340
	orr.16b	v18, v16, v0
	tbnz	w8, #3, LBB0_825
LBB0_604:                               ; %else3346
	add.2d	v1, v31, v18
	tbnz	w8, #4, LBB0_826
LBB0_605:                               ; %else3352
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_827
LBB0_606:                               ; %else3358
	str	q0, [sp, #800]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_828
LBB0_607:                               ; %else3364
	str	q19, [sp, #1200]                ; 16-byte Spill
	str	q18, [sp, #816]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_609
LBB0_608:                               ; %cond.load3366
	mov.d	x8, v0[1]
	ld1.s	{ v11 }[3], [x8]
LBB0_609:                               ; %else3370
	str	q4, [sp, #10800]                ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #188                       ; =0xbc
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #784]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbnz	w9, #0, LBB0_829
; %bb.610:                              ; %else3377
	orr.16b	v4, v7, v0
	str	q4, [sp, #3504]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_830
LBB0_611:                               ; %else3383
	ldr	q1, [sp, #3504]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v4, v19
	tbnz	w8, #2, LBB0_831
LBB0_612:                               ; %else3389
	orr.16b	v19, v16, v0
	tbnz	w8, #3, LBB0_832
LBB0_613:                               ; %else3395
	add.2d	v1, v31, v19
	tbnz	w8, #4, LBB0_833
LBB0_614:                               ; %else3401
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_834
LBB0_615:                               ; %else3407
	str	q0, [sp, #752]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_835
LBB0_616:                               ; %else3413
	str	q20, [sp, #1152]                ; 16-byte Spill
	str	q19, [sp, #768]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_618
LBB0_617:                               ; %cond.load3415
	mov.d	x8, v0[1]
	ld1.s	{ v4 }[3], [x8]
LBB0_618:                               ; %else3419
	str	q5, [sp, #10368]                ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #192                       ; =0xc0
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #736]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w9, #0, LBB0_836
; %bb.619:                              ; %else3426
	orr.16b	v5, v7, v0
	str	q5, [sp, #3488]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_837
LBB0_620:                               ; %else3432
	mov.16b	v29, v28
	ldr	q1, [sp, #3488]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v28, v27
	tbnz	w8, #2, LBB0_838
LBB0_621:                               ; %else3438
	orr.16b	v27, v16, v0
	str	q27, [sp, #3472]                ; 16-byte Spill
	str	q30, [sp, #10432]               ; 16-byte Spill
	tbnz	w8, #3, LBB0_839
LBB0_622:                               ; %else3444
	ldr	q1, [sp, #3472]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v30, v28
	str	q29, [sp, #10384]               ; 16-byte Spill
	tbnz	w8, #4, LBB0_840
LBB0_623:                               ; %else3450
	orr.16b	v0, v17, v0
	str	q12, [sp, #10000]               ; 16-byte Spill
	tbnz	w8, #5, LBB0_841
LBB0_624:                               ; %else3456
	str	q0, [sp, #720]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_842
LBB0_625:                               ; %else3462
	tbz	w8, #7, LBB0_627
LBB0_626:                               ; %cond.load3464
	mov.d	x8, v0[1]
	ld1.s	{ v20 }[3], [x8]
LBB0_627:                               ; %else3468
	str	q20, [sp, #10304]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #196                       ; =0xc4
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #704]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v20, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w9, #0, LBB0_843
; %bb.628:                              ; %else3475
	orr.16b	v12, v7, v0
	str	q12, [sp, #3456]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_844
LBB0_629:                               ; %else3481
	ldr	q12, [sp, #11680]               ; 16-byte Reload
	ldr	q1, [sp, #3456]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_845
LBB0_630:                               ; %else3487
	orr.16b	v29, v16, v0
	str	q29, [sp, #3440]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_846
LBB0_631:                               ; %else3493
	ldr	q1, [sp, #3440]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #4, LBB0_847
LBB0_632:                               ; %else3499
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_848
LBB0_633:                               ; %else3505
	str	q0, [sp, #688]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_849
LBB0_634:                               ; %else3511
	tbz	w8, #7, LBB0_636
LBB0_635:                               ; %cond.load3513
	mov.d	x8, v0[1]
	ld1.s	{ v5 }[3], [x8]
LBB0_636:                               ; %else3517
	str	q5, [sp, #10272]                ; 16-byte Spill
	str	q13, [sp, #10752]               ; 16-byte Spill
	str	q12, [sp, #11680]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #200                       ; =0xc8
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #672]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v5, #0000000000000000
	movi.2d	v12, #0000000000000000
	tbnz	w9, #0, LBB0_850
; %bb.637:                              ; %else3524
	orr.16b	v13, v7, v0
	str	q13, [sp, #3424]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_851
LBB0_638:                               ; %else3530
	ldr	q13, [sp, #11664]               ; 16-byte Reload
	ldr	q1, [sp, #3424]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_852
LBB0_639:                               ; %else3536
	orr.16b	v29, v16, v0
	tbnz	w8, #3, LBB0_853
LBB0_640:                               ; %else3542
	add.2d	v1, v31, v29
	tbnz	w8, #4, LBB0_854
LBB0_641:                               ; %else3548
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_855
LBB0_642:                               ; %else3554
	str	q0, [sp, #640]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_856
LBB0_643:                               ; %else3560
	str	q21, [sp, #912]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_645
LBB0_644:                               ; %cond.load3562
	mov.d	x8, v0[1]
	ld1.s	{ v12 }[3], [x8]
LBB0_645:                               ; %else3566
	str	q12, [sp, #10256]               ; 16-byte Spill
	str	q14, [sp, #10720]               ; 16-byte Spill
	str	q13, [sp, #11664]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #204                       ; =0xcc
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #624]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v21, #0000000000000000
	movi.2d	v13, #0000000000000000
	tbnz	w9, #0, LBB0_857
; %bb.646:                              ; %else3573
	orr.16b	v14, v7, v0
	str	q14, [sp, #3408]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_858
LBB0_647:                               ; %else3579
	ldr	q1, [sp, #3408]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_859
LBB0_648:                               ; %else3585
	orr.16b	v27, v16, v0
	tbnz	w8, #3, LBB0_860
LBB0_649:                               ; %else3591
	add.2d	v1, v31, v27
	tbnz	w8, #4, LBB0_861
LBB0_650:                               ; %else3597
	orr.16b	v0, v17, v0
	str	q26, [sp, #10496]               ; 16-byte Spill
	tbnz	w8, #5, LBB0_862
LBB0_651:                               ; %else3603
	mov.16b	v26, v24
	str	q0, [sp, #592]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	mov.16b	v24, v23
	tbnz	w8, #6, LBB0_863
LBB0_652:                               ; %else3609
	mov.16b	v23, v22
	mov.16b	v22, v5
	tbz	w8, #7, LBB0_654
LBB0_653:                               ; %cond.load3611
	mov.d	x8, v0[1]
	ld1.s	{ v13 }[3], [x8]
LBB0_654:                               ; %else3615
	str	q13, [sp, #10240]               ; 16-byte Spill
	str	q15, [sp, #10400]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #208                       ; =0xd0
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #576]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v12, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w9, #0, LBB0_864
; %bb.655:                              ; %else3622
	orr.16b	v15, v7, v0
	str	q15, [sp, #3392]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_865
LBB0_656:                               ; %else3628
	ldr	q1, [sp, #3392]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_866
LBB0_657:                               ; %else3634
	orr.16b	v28, v16, v0
	tbnz	w8, #3, LBB0_867
LBB0_658:                               ; %else3640
	add.2d	v1, v31, v28
	tbnz	w8, #4, LBB0_868
LBB0_659:                               ; %else3646
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_869
LBB0_660:                               ; %else3652
	str	q0, [sp, #544]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_870
LBB0_661:                               ; %else3658
	str	q12, [sp, #10112]               ; 16-byte Spill
	tbz	w8, #7, LBB0_663
LBB0_662:                               ; %cond.load3660
	mov.d	x8, v0[1]
	ld1.s	{ v5 }[3], [x8]
LBB0_663:                               ; %else3664
	str	q5, [sp, #10208]                ; 16-byte Spill
	str	q18, [sp, #10352]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #212                       ; =0xd4
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #528]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v14, #0000000000000000
	movi.2d	v12, #0000000000000000
	str	q22, [sp, #10144]               ; 16-byte Spill
	tbnz	w9, #0, LBB0_871
; %bb.664:                              ; %else3671
	orr.16b	v18, v7, v0
	str	q18, [sp, #3376]                ; 16-byte Spill
	str	q21, [sp, #10192]               ; 16-byte Spill
	tbnz	w8, #1, LBB0_872
LBB0_665:                               ; %else3677
	ldr	q21, [sp, #11648]               ; 16-byte Reload
	ldr	q1, [sp, #3376]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_873
LBB0_666:                               ; %else3683
	orr.16b	v18, v16, v0
	tbnz	w8, #3, LBB0_874
LBB0_667:                               ; %else3689
	add.2d	v1, v31, v18
	tbnz	w8, #4, LBB0_875
LBB0_668:                               ; %else3695
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_876
LBB0_669:                               ; %else3701
	str	q0, [sp, #496]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_877
LBB0_670:                               ; %else3707
	tbz	w8, #7, LBB0_672
LBB0_671:                               ; %cond.load3709
	mov.d	x8, v0[1]
	ld1.s	{ v12 }[3], [x8]
LBB0_672:                               ; %else3713
	str	q19, [sp, #10320]               ; 16-byte Spill
	str	q21, [sp, #11648]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #216                       ; =0xd8
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #480]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbnz	w9, #0, LBB0_878
; %bb.673:                              ; %else3720
	orr.16b	v19, v7, v0
	str	q19, [sp, #3360]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_879
LBB0_674:                               ; %else3726
	ldr	q1, [sp, #3360]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_880
LBB0_675:                               ; %else3732
	orr.16b	v9, v16, v0
	tbnz	w8, #3, LBB0_881
LBB0_676:                               ; %else3738
	add.2d	v1, v31, v9
	tbnz	w8, #4, LBB0_882
LBB0_677:                               ; %else3744
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_883
LBB0_678:                               ; %else3750
	str	q0, [sp, #448]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_884
LBB0_679:                               ; %else3756
	tbz	w8, #7, LBB0_681
LBB0_680:                               ; %cond.load3758
	mov.d	x8, v0[1]
	ld1.s	{ v22 }[3], [x8]
LBB0_681:                               ; %else3762
	str	q14, [sp, #9984]                ; 16-byte Spill
	str	q20, [sp, #10288]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #220                       ; =0xdc
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #432]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v5, #0000000000000000
	movi.2d	v13, #0000000000000000
	tbz	w9, #0, LBB0_683
; %bb.682:                              ; %cond.load3765
	fmov	x9, d1
	ldr	s5, [x9]
LBB0_683:                               ; %else3769
	orr.16b	v20, v7, v0
	str	q20, [sp, #3344]                ; 16-byte Spill
	tbz	w8, #1, LBB0_885
; %bb.684:                              ; %cond.load3771
	mov.d	x9, v1[1]
	mov.16b	v20, v5
	ld1.s	{ v20 }[1], [x9]
	ldr	q1, [sp, #3344]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v5, v13
	tbnz	w8, #2, LBB0_886
	b	LBB0_887
LBB0_685:                               ; %cond.load2362
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[3], [x9]
	add.2d	v1, v31, v4
	tbz	w8, #4, LBB0_425
LBB0_686:                               ; %cond.load2368
	fmov	x9, d1
	ld1.s	{ v5 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_426
LBB0_687:                               ; %cond.load2374
	mov.d	x9, v1[1]
	ld1.s	{ v5 }[1], [x9]
	str	q0, [sp, #1760]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_427
LBB0_688:                               ; %cond.load2380
	fmov	x9, d0
	ld1.s	{ v5 }[2], [x9]
	tbnz	w8, #7, LBB0_428
	b	LBB0_429
LBB0_689:                               ; %cond.load2393
	fmov	x9, d1
	ldr	s27, [x9]
	orr.16b	v12, v7, v0
	str	q12, [sp, #3824]                ; 16-byte Spill
	str	q5, [sp, #10864]                ; 16-byte Spill
	tbz	w8, #1, LBB0_431
LBB0_690:                               ; %cond.load2399
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[1], [x9]
	ldr	q1, [sp, #3824]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v5, v11
	tbz	w8, #2, LBB0_432
LBB0_691:                               ; %cond.load2405
	fmov	x9, d1
	ld1.s	{ v27 }[2], [x9]
	orr.16b	v11, v16, v0
	tbz	w8, #3, LBB0_433
LBB0_692:                               ; %cond.load2411
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[3], [x9]
	add.2d	v1, v31, v11
	tbz	w8, #4, LBB0_434
LBB0_693:                               ; %cond.load2417
	fmov	x9, d1
	ld1.s	{ v5 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_435
LBB0_694:                               ; %cond.load2423
	mov.d	x9, v1[1]
	ld1.s	{ v5 }[1], [x9]
	str	q0, [sp, #1712]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_436
LBB0_695:                               ; %cond.load2429
	fmov	x9, d0
	ld1.s	{ v5 }[2], [x9]
	str	q4, [sp, #1776]                 ; 16-byte Spill
	str	q11, [sp, #1728]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_437
	b	LBB0_438
LBB0_696:                               ; %cond.load2442
	fmov	x9, d1
	ldr	s11, [x9]
	orr.16b	v13, v7, v0
	str	q13, [sp, #3808]                ; 16-byte Spill
	str	q27, [sp, #10848]               ; 16-byte Spill
	tbz	w8, #1, LBB0_440
LBB0_697:                               ; %cond.load2448
	mov.d	x9, v1[1]
	ld1.s	{ v11 }[1], [x9]
	ldr	q1, [sp, #3808]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v12, v4
	tbz	w8, #2, LBB0_441
LBB0_698:                               ; %cond.load2454
	fmov	x9, d1
	ld1.s	{ v11 }[2], [x9]
	orr.16b	v4, v16, v0
	tbz	w8, #3, LBB0_442
LBB0_699:                               ; %cond.load2460
	mov.d	x9, v1[1]
	ld1.s	{ v11 }[3], [x9]
	add.2d	v1, v31, v4
	tbz	w8, #4, LBB0_443
LBB0_700:                               ; %cond.load2466
	fmov	x9, d1
	ld1.s	{ v12 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_444
LBB0_701:                               ; %cond.load2472
	mov.d	x9, v1[1]
	ld1.s	{ v12 }[1], [x9]
	str	q0, [sp, #1664]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_445
LBB0_702:                               ; %cond.load2478
	fmov	x9, d0
	ld1.s	{ v12 }[2], [x9]
	str	q4, [sp, #1680]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_446
	b	LBB0_447
LBB0_703:                               ; %cond.load2491
	fmov	x9, d1
	ldr	s4, [x9]
	orr.16b	v14, v7, v0
	str	q14, [sp, #3792]                ; 16-byte Spill
	tbz	w8, #1, LBB0_449
LBB0_704:                               ; %cond.load2497
	mov.d	x9, v1[1]
	ld1.s	{ v4 }[1], [x9]
	ldr	q1, [sp, #3792]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v13, v12
	tbz	w8, #2, LBB0_450
LBB0_705:                               ; %cond.load2503
	fmov	x9, d1
	ld1.s	{ v4 }[2], [x9]
	orr.16b	v12, v16, v0
	tbz	w8, #3, LBB0_451
LBB0_706:                               ; %cond.load2509
	mov.d	x9, v1[1]
	ld1.s	{ v4 }[3], [x9]
	add.2d	v1, v31, v12
	tbz	w8, #4, LBB0_452
LBB0_707:                               ; %cond.load2515
	fmov	x9, d1
	ld1.s	{ v13 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_453
LBB0_708:                               ; %cond.load2521
	mov.d	x9, v1[1]
	ld1.s	{ v13 }[1], [x9]
	str	q0, [sp, #1616]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_454
LBB0_709:                               ; %cond.load2527
	fmov	x9, d0
	ld1.s	{ v13 }[2], [x9]
	str	q12, [sp, #1632]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_455
	b	LBB0_456
LBB0_710:                               ; %cond.load2540
	fmov	x9, d1
	ldr	s27, [x9]
	orr.16b	v15, v7, v0
	str	q15, [sp, #3776]                ; 16-byte Spill
	tbz	w8, #1, LBB0_458
LBB0_711:                               ; %cond.load2546
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[1], [x9]
	ldr	q1, [sp, #3776]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v14, v13
	tbz	w8, #2, LBB0_459
LBB0_712:                               ; %cond.load2552
	fmov	x9, d1
	ld1.s	{ v27 }[2], [x9]
	orr.16b	v13, v16, v0
	tbz	w8, #3, LBB0_460
LBB0_713:                               ; %cond.load2558
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[3], [x9]
	add.2d	v1, v31, v13
	tbz	w8, #4, LBB0_461
LBB0_714:                               ; %cond.load2564
	fmov	x9, d1
	ld1.s	{ v14 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_462
LBB0_715:                               ; %cond.load2570
	mov.d	x9, v1[1]
	ld1.s	{ v14 }[1], [x9]
	str	q0, [sp, #1568]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_463
LBB0_716:                               ; %cond.load2576
	fmov	x9, d0
	ld1.s	{ v14 }[2], [x9]
	str	q13, [sp, #1584]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_464
	b	LBB0_465
LBB0_717:                               ; %cond.load2589
	fmov	x9, d1
	ldr	s13, [x9]
	orr.16b	v18, v7, v0
	str	q18, [sp, #3760]                ; 16-byte Spill
	tbz	w8, #1, LBB0_467
LBB0_718:                               ; %cond.load2595
	mov.d	x9, v1[1]
	ld1.s	{ v13 }[1], [x9]
	ldr	q1, [sp, #3760]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_468
LBB0_719:                               ; %cond.load2601
	fmov	x9, d1
	ld1.s	{ v13 }[2], [x9]
	orr.16b	v18, v16, v0
	tbz	w8, #3, LBB0_469
LBB0_720:                               ; %cond.load2607
	mov.d	x9, v1[1]
	ld1.s	{ v13 }[3], [x9]
	add.2d	v1, v31, v18
	tbz	w8, #4, LBB0_470
LBB0_721:                               ; %cond.load2613
	fmov	x9, d1
	ld1.s	{ v14 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_471
LBB0_722:                               ; %cond.load2619
	mov.d	x9, v1[1]
	ld1.s	{ v14 }[1], [x9]
	str	q0, [sp, #1520]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_472
LBB0_723:                               ; %cond.load2625
	fmov	x9, d0
	ld1.s	{ v14 }[2], [x9]
	str	q18, [sp, #1536]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_473
	b	LBB0_474
LBB0_724:                               ; %cond.load2638
	fmov	x9, d1
	ldr	s14, [x9]
	orr.16b	v19, v7, v0
	str	q19, [sp, #3744]                ; 16-byte Spill
	tbz	w8, #1, LBB0_476
LBB0_725:                               ; %cond.load2644
	mov.d	x9, v1[1]
	ld1.s	{ v14 }[1], [x9]
	ldr	q1, [sp, #3744]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v19, v18
	tbz	w8, #2, LBB0_477
LBB0_726:                               ; %cond.load2650
	fmov	x9, d1
	ld1.s	{ v14 }[2], [x9]
	orr.16b	v18, v16, v0
	tbz	w8, #3, LBB0_478
LBB0_727:                               ; %cond.load2656
	mov.d	x9, v1[1]
	ld1.s	{ v14 }[3], [x9]
	add.2d	v1, v31, v18
	tbz	w8, #4, LBB0_479
LBB0_728:                               ; %cond.load2662
	fmov	x9, d1
	ld1.s	{ v19 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_480
LBB0_729:                               ; %cond.load2668
	mov.d	x9, v1[1]
	ld1.s	{ v19 }[1], [x9]
	str	q0, [sp, #1472]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_481
LBB0_730:                               ; %cond.load2674
	fmov	x9, d0
	ld1.s	{ v19 }[2], [x9]
	str	q18, [sp, #1488]                ; 16-byte Spill
	str	q27, [sp, #10784]               ; 16-byte Spill
	tbnz	w8, #7, LBB0_482
	b	LBB0_483
LBB0_731:                               ; %cond.load2687
	fmov	x9, d1
	ldr	s27, [x9]
	orr.16b	v20, v7, v0
	str	q20, [sp, #3728]                ; 16-byte Spill
	tbz	w8, #1, LBB0_485
LBB0_732:                               ; %cond.load2693
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[1], [x9]
	ldr	q1, [sp, #3728]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v20, v18
	tbz	w8, #2, LBB0_486
LBB0_733:                               ; %cond.load2699
	fmov	x9, d1
	ld1.s	{ v27 }[2], [x9]
	orr.16b	v18, v16, v0
	tbz	w8, #3, LBB0_487
LBB0_734:                               ; %cond.load2705
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[3], [x9]
	add.2d	v1, v31, v18
	tbz	w8, #4, LBB0_488
LBB0_735:                               ; %cond.load2711
	fmov	x9, d1
	ld1.s	{ v20 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_489
LBB0_736:                               ; %cond.load2717
	mov.d	x9, v1[1]
	ld1.s	{ v20 }[1], [x9]
	str	q0, [sp, #1424]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_490
LBB0_737:                               ; %cond.load2723
	fmov	x9, d0
	ld1.s	{ v20 }[2], [x9]
	str	q18, [sp, #1440]                ; 16-byte Spill
	str	q19, [sp, #10704]               ; 16-byte Spill
	tbnz	w8, #7, LBB0_491
	b	LBB0_492
LBB0_738:                               ; %cond.load2736
	fmov	x9, d1
	ldr	s15, [x9]
	orr.16b	v21, v7, v0
	str	q21, [sp, #3712]                ; 16-byte Spill
	tbz	w8, #1, LBB0_494
LBB0_739:                               ; %cond.load2742
	mov.d	x9, v1[1]
	ld1.s	{ v15 }[1], [x9]
	ldr	q1, [sp, #3712]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v18, v19
	tbz	w8, #2, LBB0_495
LBB0_740:                               ; %cond.load2748
	fmov	x9, d1
	ld1.s	{ v15 }[2], [x9]
	orr.16b	v19, v16, v0
	tbz	w8, #3, LBB0_496
LBB0_741:                               ; %cond.load2754
	mov.d	x9, v1[1]
	ld1.s	{ v15 }[3], [x9]
	add.2d	v1, v31, v19
	tbz	w8, #4, LBB0_497
LBB0_742:                               ; %cond.load2760
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_498
LBB0_743:                               ; %cond.load2766
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1376]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_499
LBB0_744:                               ; %cond.load2772
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	str	q19, [sp, #1392]                ; 16-byte Spill
	str	q20, [sp, #10672]               ; 16-byte Spill
	tbnz	w8, #7, LBB0_500
	b	LBB0_501
LBB0_745:                               ; %cond.load2785
	fmov	x9, d1
	ldr	s21, [x9]
	orr.16b	v22, v7, v0
	str	q22, [sp, #3696]                ; 16-byte Spill
	tbz	w8, #1, LBB0_503
LBB0_746:                               ; %cond.load2791
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[1], [x9]
	ldr	q1, [sp, #3696]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v19, v20
	tbz	w8, #2, LBB0_504
LBB0_747:                               ; %cond.load2797
	fmov	x9, d1
	ld1.s	{ v21 }[2], [x9]
	orr.16b	v20, v16, v0
	tbz	w8, #3, LBB0_505
LBB0_748:                               ; %cond.load2803
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[3], [x9]
	add.2d	v1, v31, v20
	tbz	w8, #4, LBB0_506
LBB0_749:                               ; %cond.load2809
	fmov	x9, d1
	ld1.s	{ v19 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_507
LBB0_750:                               ; %cond.load2815
	mov.d	x9, v1[1]
	ld1.s	{ v19 }[1], [x9]
	str	q0, [sp, #1328]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_508
LBB0_751:                               ; %cond.load2821
	fmov	x9, d0
	ld1.s	{ v19 }[2], [x9]
	str	q20, [sp, #1344]                ; 16-byte Spill
	str	q21, [sp, #11648]               ; 16-byte Spill
	tbnz	w8, #7, LBB0_509
	b	LBB0_510
LBB0_752:                               ; %cond.load2834
	fmov	x9, d1
	ldr	s20, [x9]
	orr.16b	v23, v7, v0
	str	q23, [sp, #3680]                ; 16-byte Spill
	tbz	w8, #1, LBB0_512
LBB0_753:                               ; %cond.load2840
	mov.d	x9, v1[1]
	ld1.s	{ v20 }[1], [x9]
	ldr	q1, [sp, #3680]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	str	q5, [sp, #10832]                ; 16-byte Spill
	tbz	w8, #2, LBB0_513
LBB0_754:                               ; %cond.load2846
	fmov	x9, d1
	ld1.s	{ v20 }[2], [x9]
	orr.16b	v5, v16, v0
	tbz	w8, #3, LBB0_514
LBB0_755:                               ; %cond.load2852
	mov.d	x9, v1[1]
	ld1.s	{ v20 }[3], [x9]
	add.2d	v1, v31, v5
	tbz	w8, #4, LBB0_515
LBB0_756:                               ; %cond.load2858
	fmov	x9, d1
	ld1.s	{ v21 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_516
LBB0_757:                               ; %cond.load2864
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[1], [x9]
	str	q0, [sp, #1280]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_517
LBB0_758:                               ; %cond.load2870
	fmov	x9, d0
	ld1.s	{ v21 }[2], [x9]
	tbnz	w8, #7, LBB0_518
	b	LBB0_519
LBB0_759:                               ; %cond.load2883
	fmov	x9, d1
	ldr	s21, [x9]
	orr.16b	v24, v7, v0
	str	q24, [sp, #3664]                ; 16-byte Spill
	tbz	w8, #1, LBB0_521
LBB0_760:                               ; %cond.load2889
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[1], [x9]
	ldr	q1, [sp, #3664]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	str	q18, [sp, #10640]               ; 16-byte Spill
	tbz	w8, #2, LBB0_522
LBB0_761:                               ; %cond.load2895
	fmov	x9, d1
	ld1.s	{ v21 }[2], [x9]
	orr.16b	v18, v16, v0
	tbz	w8, #3, LBB0_523
LBB0_762:                               ; %cond.load2901
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[3], [x9]
	add.2d	v1, v31, v18
	tbz	w8, #4, LBB0_524
LBB0_763:                               ; %cond.load2907
	fmov	x9, d1
	ld1.s	{ v22 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_525
LBB0_764:                               ; %cond.load2913
	mov.d	x9, v1[1]
	ld1.s	{ v22 }[1], [x9]
	str	q0, [sp, #1232]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_526
LBB0_765:                               ; %cond.load2919
	fmov	x9, d0
	ld1.s	{ v22 }[2], [x9]
	tbnz	w8, #7, LBB0_527
	b	LBB0_528
LBB0_766:                               ; %cond.load2932
	fmov	x9, d1
	ldr	s22, [x9]
	orr.16b	v26, v7, v0
	str	q26, [sp, #3648]                ; 16-byte Spill
	tbz	w8, #1, LBB0_530
LBB0_767:                               ; %cond.load2938
	mov.d	x9, v1[1]
	ld1.s	{ v22 }[1], [x9]
	ldr	q1, [sp, #3648]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	str	q19, [sp, #10624]               ; 16-byte Spill
	tbz	w8, #2, LBB0_531
LBB0_768:                               ; %cond.load2944
	fmov	x9, d1
	ld1.s	{ v22 }[2], [x9]
	orr.16b	v19, v16, v0
	tbz	w8, #3, LBB0_532
LBB0_769:                               ; %cond.load2950
	mov.d	x9, v1[1]
	ld1.s	{ v22 }[3], [x9]
	add.2d	v1, v31, v19
	tbz	w8, #4, LBB0_533
LBB0_770:                               ; %cond.load2956
	fmov	x9, d1
	ld1.s	{ v23 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_534
LBB0_771:                               ; %cond.load2962
	mov.d	x9, v1[1]
	ld1.s	{ v23 }[1], [x9]
	str	q0, [sp, #1184]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_535
LBB0_772:                               ; %cond.load2968
	fmov	x9, d0
	ld1.s	{ v23 }[2], [x9]
	tbnz	w8, #7, LBB0_536
	b	LBB0_537
LBB0_773:                               ; %cond.load2981
	fmov	x9, d1
	ldr	s23, [x9]
	orr.16b	v27, v7, v0
	str	q27, [sp, #3632]                ; 16-byte Spill
	tbz	w8, #1, LBB0_539
LBB0_774:                               ; %cond.load2987
	mov.d	x9, v1[1]
	ld1.s	{ v23 }[1], [x9]
	ldr	q1, [sp, #3632]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	str	q20, [sp, #10608]               ; 16-byte Spill
	tbz	w8, #2, LBB0_540
LBB0_775:                               ; %cond.load2993
	fmov	x9, d1
	ld1.s	{ v23 }[2], [x9]
	orr.16b	v20, v16, v0
	tbz	w8, #3, LBB0_541
LBB0_776:                               ; %cond.load2999
	mov.d	x9, v1[1]
	ld1.s	{ v23 }[3], [x9]
	add.2d	v1, v31, v20
	tbz	w8, #4, LBB0_542
LBB0_777:                               ; %cond.load3005
	fmov	x9, d1
	ld1.s	{ v24 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_543
LBB0_778:                               ; %cond.load3011
	mov.d	x9, v1[1]
	ld1.s	{ v24 }[1], [x9]
	str	q0, [sp, #1136]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_544
LBB0_779:                               ; %cond.load3017
	fmov	x9, d0
	ld1.s	{ v24 }[2], [x9]
	tbnz	w8, #7, LBB0_545
	b	LBB0_546
LBB0_780:                               ; %cond.load3030
	fmov	x9, d1
	ldr	s24, [x9]
	orr.16b	v28, v7, v0
	str	q28, [sp, #3616]                ; 16-byte Spill
	tbz	w8, #1, LBB0_548
LBB0_781:                               ; %cond.load3036
	mov.d	x9, v1[1]
	ld1.s	{ v24 }[1], [x9]
	ldr	q1, [sp, #3616]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v27, v26
	tbz	w8, #2, LBB0_549
LBB0_782:                               ; %cond.load3042
	fmov	x9, d1
	ld1.s	{ v24 }[2], [x9]
	orr.16b	v26, v16, v0
	tbz	w8, #3, LBB0_550
LBB0_783:                               ; %cond.load3048
	mov.d	x9, v1[1]
	ld1.s	{ v24 }[3], [x9]
	add.2d	v1, v31, v26
	tbz	w8, #4, LBB0_551
LBB0_784:                               ; %cond.load3054
	fmov	x9, d1
	ld1.s	{ v27 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_552
LBB0_785:                               ; %cond.load3060
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[1], [x9]
	str	q0, [sp, #1088]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_553
LBB0_786:                               ; %cond.load3066
	fmov	x9, d0
	ld1.s	{ v27 }[2], [x9]
	str	q26, [sp, #1104]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_554
	b	LBB0_555
LBB0_787:                               ; %cond.load3079
	fmov	x9, d1
	ldr	s26, [x9]
	orr.16b	v29, v7, v0
	str	q29, [sp, #3600]                ; 16-byte Spill
	tbz	w8, #1, LBB0_557
LBB0_788:                               ; %cond.load3085
	mov.d	x9, v1[1]
	ld1.s	{ v26 }[1], [x9]
	ldr	q1, [sp, #3600]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v28, v27
	tbz	w8, #2, LBB0_558
LBB0_789:                               ; %cond.load3091
	fmov	x9, d1
	ld1.s	{ v26 }[2], [x9]
	orr.16b	v27, v16, v0
	tbz	w8, #3, LBB0_559
LBB0_790:                               ; %cond.load3097
	mov.d	x9, v1[1]
	ld1.s	{ v26 }[3], [x9]
	add.2d	v1, v31, v27
	tbz	w8, #4, LBB0_560
LBB0_791:                               ; %cond.load3103
	fmov	x9, d1
	ld1.s	{ v28 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_561
LBB0_792:                               ; %cond.load3109
	mov.d	x9, v1[1]
	ld1.s	{ v28 }[1], [x9]
	str	q0, [sp, #1040]                 ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_562
LBB0_793:                               ; %cond.load3115
	fmov	x9, d0
	ld1.s	{ v28 }[2], [x9]
	str	q27, [sp, #1056]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_563
	b	LBB0_564
LBB0_794:                               ; %cond.load3128
	fmov	x9, d1
	ldr	s27, [x9]
	orr.16b	v30, v7, v0
	str	q30, [sp, #3584]                ; 16-byte Spill
	tbz	w8, #1, LBB0_566
LBB0_795:                               ; %cond.load3134
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[1], [x9]
	ldr	q1, [sp, #3584]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v29, v28
	tbz	w8, #2, LBB0_567
LBB0_796:                               ; %cond.load3140
	fmov	x9, d1
	ld1.s	{ v27 }[2], [x9]
	orr.16b	v28, v16, v0
	tbz	w8, #3, LBB0_568
LBB0_797:                               ; %cond.load3146
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[3], [x9]
	add.2d	v1, v31, v28
	tbz	w8, #4, LBB0_569
LBB0_798:                               ; %cond.load3152
	fmov	x9, d1
	ld1.s	{ v29 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_570
LBB0_799:                               ; %cond.load3158
	mov.d	x9, v1[1]
	ld1.s	{ v29 }[1], [x9]
	str	q0, [sp, #992]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_571
LBB0_800:                               ; %cond.load3164
	fmov	x9, d0
	ld1.s	{ v29 }[2], [x9]
	str	q28, [sp, #1008]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_572
	b	LBB0_573
LBB0_801:                               ; %cond.load3177
	fmov	x9, d1
	ldr	s28, [x9]
	orr.16b	v8, v7, v0
	str	q8, [sp, #3568]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_575
LBB0_802:                               ; %cond.load3183
	mov.d	x9, v1[1]
	ld1.s	{ v28 }[1], [x9]
	ldr	q1, [sp, #3568]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v30, v29
	tbz	w8, #2, LBB0_576
LBB0_803:                               ; %cond.load3189
	fmov	x9, d1
	ld1.s	{ v28 }[2], [x9]
	orr.16b	v29, v16, v0
	tbz	w8, #3, LBB0_577
LBB0_804:                               ; %cond.load3195
	mov.d	x9, v1[1]
	ld1.s	{ v28 }[3], [x9]
	add.2d	v1, v31, v29
	tbz	w8, #4, LBB0_578
LBB0_805:                               ; %cond.load3201
	fmov	x9, d1
	ld1.s	{ v30 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_579
LBB0_806:                               ; %cond.load3207
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[1], [x9]
	str	q0, [sp, #944]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_580
LBB0_807:                               ; %cond.load3213
	fmov	x9, d0
	ld1.s	{ v30 }[2], [x9]
	str	q29, [sp, #960]                 ; 16-byte Spill
	str	q15, [sp, #10656]               ; 16-byte Spill
	tbnz	w8, #7, LBB0_581
	b	LBB0_582
LBB0_808:                               ; %cond.load3226
	fmov	x9, d1
	ldr	s12, [x9]
	orr.16b	v9, v7, v0
	str	q9, [sp, #3552]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_584
LBB0_809:                               ; %cond.load3232
	mov.d	x9, v1[1]
	ld1.s	{ v12 }[1], [x9]
	ldr	q1, [sp, #3552]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	str	q21, [sp, #10576]               ; 16-byte Spill
	tbz	w8, #2, LBB0_585
LBB0_810:                               ; %cond.load3238
	fmov	x9, d1
	ld1.s	{ v12 }[2], [x9]
	orr.16b	v21, v16, v0
	tbz	w8, #3, LBB0_586
LBB0_811:                               ; %cond.load3244
	mov.d	x9, v1[1]
	ld1.s	{ v12 }[3], [x9]
	add.2d	v1, v31, v21
	tbz	w8, #4, LBB0_587
LBB0_812:                               ; %cond.load3250
	fmov	x9, d1
	ld1.s	{ v8 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_588
LBB0_813:                               ; %cond.load3256
	mov.d	x9, v1[1]
	ld1.s	{ v8 }[1], [x9]
	str	q0, [sp, #896]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_589
LBB0_814:                               ; %cond.load3262
	fmov	x9, d0
	ld1.s	{ v8 }[2], [x9]
	str	q5, [sp, #1296]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_590
	b	LBB0_591
LBB0_815:                               ; %cond.load3275
	fmov	x9, d1
	ldr	s15, [x9]
	orr.16b	v10, v7, v0
	str	q10, [sp, #3536]                ; 16-byte Spill
	tbz	w8, #1, LBB0_593
LBB0_816:                               ; %cond.load3281
	mov.d	x9, v1[1]
	ld1.s	{ v15 }[1], [x9]
	ldr	q1, [sp, #3536]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v10, v5
	tbz	w8, #2, LBB0_594
LBB0_817:                               ; %cond.load3287
	fmov	x9, d1
	ld1.s	{ v15 }[2], [x9]
	orr.16b	v5, v16, v0
	tbz	w8, #3, LBB0_595
LBB0_818:                               ; %cond.load3293
	mov.d	x9, v1[1]
	ld1.s	{ v15 }[3], [x9]
	add.2d	v1, v31, v5
	tbz	w8, #4, LBB0_596
LBB0_819:                               ; %cond.load3299
	fmov	x9, d1
	ld1.s	{ v10 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_597
LBB0_820:                               ; %cond.load3305
	mov.d	x9, v1[1]
	ld1.s	{ v10 }[1], [x9]
	str	q0, [sp, #848]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_598
LBB0_821:                               ; %cond.load3311
	fmov	x9, d0
	ld1.s	{ v10 }[2], [x9]
	str	q18, [sp, #1248]                ; 16-byte Spill
	str	q5, [sp, #864]                  ; 16-byte Spill
	tbnz	w8, #7, LBB0_599
	b	LBB0_600
LBB0_822:                               ; %cond.load3324
	fmov	x9, d1
	ldr	s5, [x9]
	orr.16b	v11, v7, v0
	str	q11, [sp, #3520]                ; 16-byte Spill
	tbz	w8, #1, LBB0_602
LBB0_823:                               ; %cond.load3330
	mov.d	x9, v1[1]
	ld1.s	{ v5 }[1], [x9]
	ldr	q1, [sp, #3520]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v11, v18
	tbz	w8, #2, LBB0_603
LBB0_824:                               ; %cond.load3336
	fmov	x9, d1
	ld1.s	{ v5 }[2], [x9]
	orr.16b	v18, v16, v0
	tbz	w8, #3, LBB0_604
LBB0_825:                               ; %cond.load3342
	mov.d	x9, v1[1]
	ld1.s	{ v5 }[3], [x9]
	add.2d	v1, v31, v18
	tbz	w8, #4, LBB0_605
LBB0_826:                               ; %cond.load3348
	fmov	x9, d1
	ld1.s	{ v11 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_606
LBB0_827:                               ; %cond.load3354
	mov.d	x9, v1[1]
	ld1.s	{ v11 }[1], [x9]
	str	q0, [sp, #800]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_607
LBB0_828:                               ; %cond.load3360
	fmov	x9, d0
	ld1.s	{ v11 }[2], [x9]
	str	q19, [sp, #1200]                ; 16-byte Spill
	str	q18, [sp, #816]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_608
	b	LBB0_609
LBB0_829:                               ; %cond.load3373
	fmov	x9, d1
	ldr	s18, [x9]
	orr.16b	v4, v7, v0
	str	q4, [sp, #3504]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_611
LBB0_830:                               ; %cond.load3379
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	ldr	q1, [sp, #3504]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v4, v19
	tbz	w8, #2, LBB0_612
LBB0_831:                               ; %cond.load3385
	fmov	x9, d1
	ld1.s	{ v18 }[2], [x9]
	orr.16b	v19, v16, v0
	tbz	w8, #3, LBB0_613
LBB0_832:                               ; %cond.load3391
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[3], [x9]
	add.2d	v1, v31, v19
	tbz	w8, #4, LBB0_614
LBB0_833:                               ; %cond.load3397
	fmov	x9, d1
	ld1.s	{ v4 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_615
LBB0_834:                               ; %cond.load3403
	mov.d	x9, v1[1]
	ld1.s	{ v4 }[1], [x9]
	str	q0, [sp, #752]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_616
LBB0_835:                               ; %cond.load3409
	fmov	x9, d0
	ld1.s	{ v4 }[2], [x9]
	str	q20, [sp, #1152]                ; 16-byte Spill
	str	q19, [sp, #768]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_617
	b	LBB0_618
LBB0_836:                               ; %cond.load3422
	fmov	x9, d1
	ldr	s19, [x9]
	orr.16b	v5, v7, v0
	str	q5, [sp, #3488]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_620
LBB0_837:                               ; %cond.load3428
	mov.d	x9, v1[1]
	ld1.s	{ v19 }[1], [x9]
	mov.16b	v29, v28
	ldr	q1, [sp, #3488]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v28, v27
	tbz	w8, #2, LBB0_621
LBB0_838:                               ; %cond.load3434
	fmov	x9, d1
	ld1.s	{ v19 }[2], [x9]
	orr.16b	v27, v16, v0
	str	q27, [sp, #3472]                ; 16-byte Spill
	str	q30, [sp, #10432]               ; 16-byte Spill
	tbz	w8, #3, LBB0_622
LBB0_839:                               ; %cond.load3440
	mov.d	x9, v1[1]
	ld1.s	{ v19 }[3], [x9]
	ldr	q1, [sp, #3472]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v30, v28
	str	q29, [sp, #10384]               ; 16-byte Spill
	tbz	w8, #4, LBB0_623
LBB0_840:                               ; %cond.load3446
	fmov	x9, d1
	ld1.s	{ v20 }[0], [x9]
	orr.16b	v0, v17, v0
	str	q12, [sp, #10000]               ; 16-byte Spill
	tbz	w8, #5, LBB0_624
LBB0_841:                               ; %cond.load3452
	mov.d	x9, v1[1]
	ld1.s	{ v20 }[1], [x9]
	str	q0, [sp, #720]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_625
LBB0_842:                               ; %cond.load3458
	fmov	x9, d0
	ld1.s	{ v20 }[2], [x9]
	tbnz	w8, #7, LBB0_626
	b	LBB0_627
LBB0_843:                               ; %cond.load3471
	fmov	x9, d1
	ldr	s20, [x9]
	orr.16b	v12, v7, v0
	str	q12, [sp, #3456]                ; 16-byte Spill
	tbz	w8, #1, LBB0_629
LBB0_844:                               ; %cond.load3477
	mov.d	x9, v1[1]
	ld1.s	{ v20 }[1], [x9]
	ldr	q12, [sp, #11680]               ; 16-byte Reload
	ldr	q1, [sp, #3456]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_630
LBB0_845:                               ; %cond.load3483
	fmov	x9, d1
	ld1.s	{ v20 }[2], [x9]
	orr.16b	v29, v16, v0
	str	q29, [sp, #3440]                ; 16-byte Spill
	tbz	w8, #3, LBB0_631
LBB0_846:                               ; %cond.load3489
	mov.d	x9, v1[1]
	ld1.s	{ v20 }[3], [x9]
	ldr	q1, [sp, #3440]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #4, LBB0_632
LBB0_847:                               ; %cond.load3495
	fmov	x9, d1
	ld1.s	{ v5 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_633
LBB0_848:                               ; %cond.load3501
	mov.d	x9, v1[1]
	ld1.s	{ v5 }[1], [x9]
	str	q0, [sp, #688]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_634
LBB0_849:                               ; %cond.load3507
	fmov	x9, d0
	ld1.s	{ v5 }[2], [x9]
	tbnz	w8, #7, LBB0_635
	b	LBB0_636
LBB0_850:                               ; %cond.load3520
	fmov	x9, d1
	ldr	s5, [x9]
	orr.16b	v13, v7, v0
	str	q13, [sp, #3424]                ; 16-byte Spill
	tbz	w8, #1, LBB0_638
LBB0_851:                               ; %cond.load3526
	mov.d	x9, v1[1]
	ld1.s	{ v5 }[1], [x9]
	ldr	q13, [sp, #11664]               ; 16-byte Reload
	ldr	q1, [sp, #3424]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_639
LBB0_852:                               ; %cond.load3532
	fmov	x9, d1
	ld1.s	{ v5 }[2], [x9]
	orr.16b	v29, v16, v0
	tbz	w8, #3, LBB0_640
LBB0_853:                               ; %cond.load3538
	mov.d	x9, v1[1]
	ld1.s	{ v5 }[3], [x9]
	add.2d	v1, v31, v29
	tbz	w8, #4, LBB0_641
LBB0_854:                               ; %cond.load3544
	fmov	x9, d1
	ld1.s	{ v12 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_642
LBB0_855:                               ; %cond.load3550
	mov.d	x9, v1[1]
	ld1.s	{ v12 }[1], [x9]
	str	q0, [sp, #640]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_643
LBB0_856:                               ; %cond.load3556
	fmov	x9, d0
	ld1.s	{ v12 }[2], [x9]
	str	q21, [sp, #912]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_644
	b	LBB0_645
LBB0_857:                               ; %cond.load3569
	fmov	x9, d1
	ldr	s21, [x9]
	orr.16b	v14, v7, v0
	str	q14, [sp, #3408]                ; 16-byte Spill
	tbz	w8, #1, LBB0_647
LBB0_858:                               ; %cond.load3575
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[1], [x9]
	ldr	q1, [sp, #3408]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_648
LBB0_859:                               ; %cond.load3581
	fmov	x9, d1
	ld1.s	{ v21 }[2], [x9]
	orr.16b	v27, v16, v0
	tbz	w8, #3, LBB0_649
LBB0_860:                               ; %cond.load3587
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[3], [x9]
	add.2d	v1, v31, v27
	tbz	w8, #4, LBB0_650
LBB0_861:                               ; %cond.load3593
	fmov	x9, d1
	ld1.s	{ v13 }[0], [x9]
	orr.16b	v0, v17, v0
	str	q26, [sp, #10496]               ; 16-byte Spill
	tbz	w8, #5, LBB0_651
LBB0_862:                               ; %cond.load3599
	mov.d	x9, v1[1]
	ld1.s	{ v13 }[1], [x9]
	mov.16b	v26, v24
	str	q0, [sp, #592]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	mov.16b	v24, v23
	tbz	w8, #6, LBB0_652
LBB0_863:                               ; %cond.load3605
	fmov	x9, d0
	ld1.s	{ v13 }[2], [x9]
	mov.16b	v23, v22
	mov.16b	v22, v5
	tbnz	w8, #7, LBB0_653
	b	LBB0_654
LBB0_864:                               ; %cond.load3618
	fmov	x9, d1
	ldr	s12, [x9]
	orr.16b	v15, v7, v0
	str	q15, [sp, #3392]                ; 16-byte Spill
	tbz	w8, #1, LBB0_656
LBB0_865:                               ; %cond.load3624
	mov.d	x9, v1[1]
	ld1.s	{ v12 }[1], [x9]
	ldr	q1, [sp, #3392]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_657
LBB0_866:                               ; %cond.load3630
	fmov	x9, d1
	ld1.s	{ v12 }[2], [x9]
	orr.16b	v28, v16, v0
	tbz	w8, #3, LBB0_658
LBB0_867:                               ; %cond.load3636
	mov.d	x9, v1[1]
	ld1.s	{ v12 }[3], [x9]
	add.2d	v1, v31, v28
	tbz	w8, #4, LBB0_659
LBB0_868:                               ; %cond.load3642
	fmov	x9, d1
	ld1.s	{ v5 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_660
LBB0_869:                               ; %cond.load3648
	mov.d	x9, v1[1]
	ld1.s	{ v5 }[1], [x9]
	str	q0, [sp, #544]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_661
LBB0_870:                               ; %cond.load3654
	fmov	x9, d0
	ld1.s	{ v5 }[2], [x9]
	str	q12, [sp, #10112]               ; 16-byte Spill
	tbnz	w8, #7, LBB0_662
	b	LBB0_663
LBB0_871:                               ; %cond.load3667
	fmov	x9, d1
	ldr	s14, [x9]
	orr.16b	v18, v7, v0
	str	q18, [sp, #3376]                ; 16-byte Spill
	str	q21, [sp, #10192]               ; 16-byte Spill
	tbz	w8, #1, LBB0_665
LBB0_872:                               ; %cond.load3673
	mov.d	x9, v1[1]
	ld1.s	{ v14 }[1], [x9]
	ldr	q21, [sp, #11648]               ; 16-byte Reload
	ldr	q1, [sp, #3376]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_666
LBB0_873:                               ; %cond.load3679
	fmov	x9, d1
	ld1.s	{ v14 }[2], [x9]
	orr.16b	v18, v16, v0
	tbz	w8, #3, LBB0_667
LBB0_874:                               ; %cond.load3685
	mov.d	x9, v1[1]
	ld1.s	{ v14 }[3], [x9]
	add.2d	v1, v31, v18
	tbz	w8, #4, LBB0_668
LBB0_875:                               ; %cond.load3691
	fmov	x9, d1
	ld1.s	{ v12 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_669
LBB0_876:                               ; %cond.load3697
	mov.d	x9, v1[1]
	ld1.s	{ v12 }[1], [x9]
	str	q0, [sp, #496]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_670
LBB0_877:                               ; %cond.load3703
	fmov	x9, d0
	ld1.s	{ v12 }[2], [x9]
	tbnz	w8, #7, LBB0_671
	b	LBB0_672
LBB0_878:                               ; %cond.load3716
	fmov	x9, d1
	ldr	s21, [x9]
	orr.16b	v19, v7, v0
	str	q19, [sp, #3360]                ; 16-byte Spill
	tbz	w8, #1, LBB0_674
LBB0_879:                               ; %cond.load3722
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[1], [x9]
	ldr	q1, [sp, #3360]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_675
LBB0_880:                               ; %cond.load3728
	fmov	x9, d1
	ld1.s	{ v21 }[2], [x9]
	orr.16b	v9, v16, v0
	tbz	w8, #3, LBB0_676
LBB0_881:                               ; %cond.load3734
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[3], [x9]
	add.2d	v1, v31, v9
	tbz	w8, #4, LBB0_677
LBB0_882:                               ; %cond.load3740
	fmov	x9, d1
	ld1.s	{ v22 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_678
LBB0_883:                               ; %cond.load3746
	mov.d	x9, v1[1]
	ld1.s	{ v22 }[1], [x9]
	str	q0, [sp, #448]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_679
LBB0_884:                               ; %cond.load3752
	fmov	x9, d0
	ld1.s	{ v22 }[2], [x9]
	tbnz	w8, #7, LBB0_680
	b	LBB0_681
LBB0_885:
	mov.16b	v20, v5
	ldr	q1, [sp, #3344]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v5, v13
	tbz	w8, #2, LBB0_887
LBB0_886:                               ; %cond.load3777
	fmov	x9, d1
	ld1.s	{ v20 }[2], [x9]
LBB0_887:                               ; %else3781
	str	q20, [sp, #11616]               ; 16-byte Spill
	orr.16b	v20, v16, v0
	tbnz	w8, #3, LBB0_933
; %bb.888:                              ; %else3787
	add.2d	v1, v31, v20
	tbnz	w8, #4, LBB0_934
LBB0_889:                               ; %else3793
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_935
LBB0_890:                               ; %else3799
	str	q0, [sp, #400]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_936
LBB0_891:                               ; %else3805
	str	q18, [sp, #512]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_893
LBB0_892:                               ; %cond.load3807
	mov.d	x8, v0[1]
	ld1.s	{ v5 }[3], [x8]
LBB0_893:                               ; %else3811
	str	q21, [sp, #10176]               ; 16-byte Spill
	str	q12, [sp, #10160]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #224                       ; =0xe0
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #384]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v18, #0000000000000000
	movi.2d	v12, #0000000000000000
	tbnz	w9, #0, LBB0_937
; %bb.894:                              ; %else3818
	orr.16b	v21, v7, v0
	str	q21, [sp, #3328]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_938
LBB0_895:                               ; %else3824
	ldr	q1, [sp, #3328]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_939
LBB0_896:                               ; %else3830
	orr.16b	v21, v16, v0
	tbnz	w8, #3, LBB0_940
LBB0_897:                               ; %else3836
	add.2d	v1, v31, v21
	tbnz	w8, #4, LBB0_941
LBB0_898:                               ; %else3842
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_942
LBB0_899:                               ; %else3848
	str	q0, [sp, #352]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_943
LBB0_900:                               ; %else3854
	tbz	w8, #7, LBB0_902
LBB0_901:                               ; %cond.load3856
	mov.d	x8, v0[1]
	ld1.s	{ v12 }[3], [x8]
LBB0_902:                               ; %else3860
	str	q22, [sp, #10128]               ; 16-byte Spill
	str	q23, [sp, #10560]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #228                       ; =0xe4
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #336]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v23, #0000000000000000
	movi.2d	v15, #0000000000000000
	tbnz	w9, #0, LBB0_944
; %bb.903:                              ; %else3867
	orr.16b	v22, v7, v0
	str	q22, [sp, #3312]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_945
LBB0_904:                               ; %else3873
	ldr	q1, [sp, #3312]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_946
LBB0_905:                               ; %else3879
	orr.16b	v22, v16, v0
	tbnz	w8, #3, LBB0_947
LBB0_906:                               ; %else3885
	add.2d	v1, v31, v22
	tbnz	w8, #4, LBB0_948
LBB0_907:                               ; %else3891
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_949
LBB0_908:                               ; %else3897
	str	q0, [sp, #304]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_950
LBB0_909:                               ; %else3903
	tbz	w8, #7, LBB0_911
LBB0_910:                               ; %cond.load3905
	mov.d	x8, v0[1]
	ld1.s	{ v15 }[3], [x8]
LBB0_911:                               ; %else3909
	str	q15, [sp, #10064]               ; 16-byte Spill
	str	q23, [sp, #10080]               ; 16-byte Spill
	str	q24, [sp, #10528]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #232                       ; =0xe8
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #288]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v15, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w9, #0, LBB0_951
; %bb.912:                              ; %else3916
	orr.16b	v23, v7, v0
	str	q23, [sp, #3296]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_952
LBB0_913:                               ; %else3922
	ldr	q1, [sp, #3296]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_953
LBB0_914:                               ; %else3928
	orr.16b	v23, v16, v0
	tbnz	w8, #3, LBB0_954
LBB0_915:                               ; %else3934
	add.2d	v1, v31, v23
	tbnz	w8, #4, LBB0_955
LBB0_916:                               ; %else3940
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_956
LBB0_917:                               ; %else3946
	str	q0, [sp, #256]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_957
LBB0_918:                               ; %else3952
	str	q18, [sp, #9904]                ; 16-byte Spill
	mov.16b	v18, v29
	tbz	w8, #7, LBB0_920
LBB0_919:                               ; %cond.load3954
	mov.d	x8, v0[1]
	ld1.s	{ v24 }[3], [x8]
LBB0_920:                               ; %else3958
	str	q24, [sp, #10048]               ; 16-byte Spill
	str	q26, [sp, #10512]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #236                       ; =0xec
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #240]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v26, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w9, #0, LBB0_958
; %bb.921:                              ; %else3965
	orr.16b	v24, v7, v0
	str	q24, [sp, #3280]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_959
LBB0_922:                               ; %else3971
	ldr	q1, [sp, #3280]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_960
LBB0_923:                               ; %else3977
	orr.16b	v24, v16, v0
	tbnz	w8, #3, LBB0_961
LBB0_924:                               ; %else3983
	add.2d	v1, v31, v24
	tbnz	w8, #4, LBB0_962
LBB0_925:                               ; %else3989
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_963
LBB0_926:                               ; %else3995
	str	q0, [sp, #208]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_964
LBB0_927:                               ; %else4001
	mov.16b	v14, v27
	tbz	w8, #7, LBB0_929
LBB0_928:                               ; %cond.load4003
	mov.d	x8, v0[1]
	ld1.s	{ v29 }[3], [x8]
LBB0_929:                               ; %else4007
	mov.16b	v13, v28
	str	q26, [sp, #10032]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #240                       ; =0xf0
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #192]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v28, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbz	w9, #0, LBB0_931
; %bb.930:                              ; %cond.load4010
	fmov	x9, d1
	ldr	s28, [x9]
LBB0_931:                               ; %else4014
	orr.16b	v26, v7, v0
	str	q26, [sp, #3264]                ; 16-byte Spill
	tbz	w8, #1, LBB0_965
; %bb.932:                              ; %cond.load4016
	mov.d	x9, v1[1]
	mov.16b	v26, v28
	ld1.s	{ v26 }[1], [x9]
	ldr	q1, [sp, #3264]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v28, v27
	tbnz	w8, #2, LBB0_966
	b	LBB0_967
LBB0_933:                               ; %cond.load3783
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11616]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11616]                ; 16-byte Spill
	add.2d	v1, v31, v20
	tbz	w8, #4, LBB0_889
LBB0_934:                               ; %cond.load3789
	fmov	x9, d1
	ld1.s	{ v5 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_890
LBB0_935:                               ; %cond.load3795
	mov.d	x9, v1[1]
	ld1.s	{ v5 }[1], [x9]
	str	q0, [sp, #400]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_891
LBB0_936:                               ; %cond.load3801
	fmov	x9, d0
	ld1.s	{ v5 }[2], [x9]
	str	q18, [sp, #512]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_892
	b	LBB0_893
LBB0_937:                               ; %cond.load3814
	fmov	x9, d1
	ldr	s18, [x9]
	orr.16b	v21, v7, v0
	str	q21, [sp, #3328]                ; 16-byte Spill
	tbz	w8, #1, LBB0_895
LBB0_938:                               ; %cond.load3820
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	ldr	q1, [sp, #3328]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_896
LBB0_939:                               ; %cond.load3826
	fmov	x9, d1
	ld1.s	{ v18 }[2], [x9]
	orr.16b	v21, v16, v0
	tbz	w8, #3, LBB0_897
LBB0_940:                               ; %cond.load3832
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[3], [x9]
	add.2d	v1, v31, v21
	tbz	w8, #4, LBB0_898
LBB0_941:                               ; %cond.load3838
	fmov	x9, d1
	ld1.s	{ v12 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_899
LBB0_942:                               ; %cond.load3844
	mov.d	x9, v1[1]
	ld1.s	{ v12 }[1], [x9]
	str	q0, [sp, #352]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_900
LBB0_943:                               ; %cond.load3850
	fmov	x9, d0
	ld1.s	{ v12 }[2], [x9]
	tbnz	w8, #7, LBB0_901
	b	LBB0_902
LBB0_944:                               ; %cond.load3863
	fmov	x9, d1
	ldr	s23, [x9]
	orr.16b	v22, v7, v0
	str	q22, [sp, #3312]                ; 16-byte Spill
	tbz	w8, #1, LBB0_904
LBB0_945:                               ; %cond.load3869
	mov.d	x9, v1[1]
	ld1.s	{ v23 }[1], [x9]
	ldr	q1, [sp, #3312]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_905
LBB0_946:                               ; %cond.load3875
	fmov	x9, d1
	ld1.s	{ v23 }[2], [x9]
	orr.16b	v22, v16, v0
	tbz	w8, #3, LBB0_906
LBB0_947:                               ; %cond.load3881
	mov.d	x9, v1[1]
	ld1.s	{ v23 }[3], [x9]
	add.2d	v1, v31, v22
	tbz	w8, #4, LBB0_907
LBB0_948:                               ; %cond.load3887
	fmov	x9, d1
	ld1.s	{ v15 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_908
LBB0_949:                               ; %cond.load3893
	mov.d	x9, v1[1]
	ld1.s	{ v15 }[1], [x9]
	str	q0, [sp, #304]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_909
LBB0_950:                               ; %cond.load3899
	fmov	x9, d0
	ld1.s	{ v15 }[2], [x9]
	tbnz	w8, #7, LBB0_910
	b	LBB0_911
LBB0_951:                               ; %cond.load3912
	fmov	x9, d1
	ldr	s15, [x9]
	orr.16b	v23, v7, v0
	str	q23, [sp, #3296]                ; 16-byte Spill
	tbz	w8, #1, LBB0_913
LBB0_952:                               ; %cond.load3918
	mov.d	x9, v1[1]
	ld1.s	{ v15 }[1], [x9]
	ldr	q1, [sp, #3296]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_914
LBB0_953:                               ; %cond.load3924
	fmov	x9, d1
	ld1.s	{ v15 }[2], [x9]
	orr.16b	v23, v16, v0
	tbz	w8, #3, LBB0_915
LBB0_954:                               ; %cond.load3930
	mov.d	x9, v1[1]
	ld1.s	{ v15 }[3], [x9]
	add.2d	v1, v31, v23
	tbz	w8, #4, LBB0_916
LBB0_955:                               ; %cond.load3936
	fmov	x9, d1
	ld1.s	{ v24 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_917
LBB0_956:                               ; %cond.load3942
	mov.d	x9, v1[1]
	ld1.s	{ v24 }[1], [x9]
	str	q0, [sp, #256]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_918
LBB0_957:                               ; %cond.load3948
	fmov	x9, d0
	ld1.s	{ v24 }[2], [x9]
	str	q18, [sp, #9904]                ; 16-byte Spill
	mov.16b	v18, v29
	tbnz	w8, #7, LBB0_919
	b	LBB0_920
LBB0_958:                               ; %cond.load3961
	fmov	x9, d1
	ldr	s26, [x9]
	orr.16b	v24, v7, v0
	str	q24, [sp, #3280]                ; 16-byte Spill
	tbz	w8, #1, LBB0_922
LBB0_959:                               ; %cond.load3967
	mov.d	x9, v1[1]
	ld1.s	{ v26 }[1], [x9]
	ldr	q1, [sp, #3280]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_923
LBB0_960:                               ; %cond.load3973
	fmov	x9, d1
	ld1.s	{ v26 }[2], [x9]
	orr.16b	v24, v16, v0
	tbz	w8, #3, LBB0_924
LBB0_961:                               ; %cond.load3979
	mov.d	x9, v1[1]
	ld1.s	{ v26 }[3], [x9]
	add.2d	v1, v31, v24
	tbz	w8, #4, LBB0_925
LBB0_962:                               ; %cond.load3985
	fmov	x9, d1
	ld1.s	{ v29 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_926
LBB0_963:                               ; %cond.load3991
	mov.d	x9, v1[1]
	ld1.s	{ v29 }[1], [x9]
	str	q0, [sp, #208]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_927
LBB0_964:                               ; %cond.load3997
	fmov	x9, d0
	ld1.s	{ v29 }[2], [x9]
	mov.16b	v14, v27
	tbnz	w8, #7, LBB0_928
	b	LBB0_929
LBB0_965:
	mov.16b	v26, v28
	ldr	q1, [sp, #3264]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v28, v27
	tbz	w8, #2, LBB0_967
LBB0_966:                               ; %cond.load4022
	fmov	x9, d1
	ld1.s	{ v26 }[2], [x9]
LBB0_967:                               ; %else4026
	str	q26, [sp, #11600]               ; 16-byte Spill
	orr.16b	v26, v16, v0
	tbnz	w8, #3, LBB0_977
; %bb.968:                              ; %else4032
	add.2d	v1, v31, v26
	tbnz	w8, #4, LBB0_978
LBB0_969:                               ; %else4038
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_979
LBB0_970:                               ; %else4044
	str	q0, [sp, #160]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_980
LBB0_971:                               ; %else4050
	tbz	w8, #7, LBB0_973
LBB0_972:                               ; %cond.load4052
	mov.d	x8, v0[1]
	ld1.s	{ v28 }[3], [x8]
LBB0_973:                               ; %else4056
	str	q30, [sp, #10464]               ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #244                       ; =0xf4
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #144]                  ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v30, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w9, #0, LBB0_975
; %bb.974:                              ; %cond.load4059
	fmov	x9, d1
	ldr	s30, [x9]
LBB0_975:                               ; %else4063
	orr.16b	v27, v7, v0
	str	q27, [sp, #3248]                ; 16-byte Spill
	tbz	w8, #1, LBB0_981
; %bb.976:                              ; %cond.load4065
	mov.d	x9, v1[1]
	mov.16b	v27, v30
	ld1.s	{ v27 }[1], [x9]
	ldr	q1, [sp, #3248]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v30, v19
	tbnz	w8, #2, LBB0_982
	b	LBB0_983
LBB0_977:                               ; %cond.load4028
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11600]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11600]                ; 16-byte Spill
	add.2d	v1, v31, v26
	tbz	w8, #4, LBB0_969
LBB0_978:                               ; %cond.load4034
	fmov	x9, d1
	ld1.s	{ v28 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_970
LBB0_979:                               ; %cond.load4040
	mov.d	x9, v1[1]
	ld1.s	{ v28 }[1], [x9]
	str	q0, [sp, #160]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_971
LBB0_980:                               ; %cond.load4046
	fmov	x9, d0
	ld1.s	{ v28 }[2], [x9]
	tbnz	w8, #7, LBB0_972
	b	LBB0_973
LBB0_981:
	mov.16b	v27, v30
	ldr	q1, [sp, #3248]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	mov.16b	v30, v19
	tbz	w8, #2, LBB0_983
LBB0_982:                               ; %cond.load4071
	fmov	x9, d1
	ld1.s	{ v27 }[2], [x9]
LBB0_983:                               ; %else4075
	str	q27, [sp, #11584]               ; 16-byte Spill
	orr.16b	v27, v16, v0
	tbnz	w8, #3, LBB0_1008
; %bb.984:                              ; %else4081
	add.2d	v1, v31, v27
	tbnz	w8, #4, LBB0_1009
LBB0_985:                               ; %else4087
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_1010
LBB0_986:                               ; %else4093
	str	q0, [sp, #112]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_1011
LBB0_987:                               ; %else4099
	str	q8, [sp, #10416]                ; 16-byte Spill
	tbz	w8, #7, LBB0_989
LBB0_988:                               ; %cond.load4101
	mov.d	x8, v0[1]
	ld1.s	{ v30 }[3], [x8]
LBB0_989:                               ; %else4105
	str	q28, [sp, #9952]                ; 16-byte Spill
	fmov	w9, s3
	and	w8, w9, #0xff
	mov	w10, #248                       ; =0xf8
	dup.2d	v0, x10
	orr.16b	v1, v6, v0
	str	q1, [sp, #96]                   ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v8, #0000000000000000
	tbnz	w9, #0, LBB0_1012
; %bb.990:                              ; %else4112
	orr.16b	v28, v7, v0
	str	q28, [sp, #3232]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1013
LBB0_991:                               ; %else4118
	ldr	q1, [sp, #3232]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w8, #2, LBB0_1014
LBB0_992:                               ; %else4124
	orr.16b	v28, v16, v0
	tbnz	w8, #3, LBB0_1015
LBB0_993:                               ; %else4130
	add.2d	v1, v31, v28
	tbnz	w8, #4, LBB0_1016
LBB0_994:                               ; %else4136
	orr.16b	v0, v17, v0
	tbnz	w8, #5, LBB0_1017
LBB0_995:                               ; %else4142
	str	q0, [sp, #64]                   ; 16-byte Spill
	add.2d	v0, v31, v0
	tbnz	w8, #6, LBB0_1018
LBB0_996:                               ; %else4148
	str	q4, [sp, #10096]                ; 16-byte Spill
	str	q10, [sp, #9968]                ; 16-byte Spill
	str	q30, [sp, #9920]                ; 16-byte Spill
	str	q11, [sp, #9792]                ; 16-byte Spill
	tbz	w8, #7, LBB0_998
LBB0_997:                               ; %cond.load4150
	mov.d	x8, v0[1]
	ld1.s	{ v8 }[3], [x8]
LBB0_998:                               ; %else4154
	str	q29, [sp, #10016]               ; 16-byte Spill
	ldr	q10, [sp, #10000]               ; 16-byte Reload
	ldr	q30, [sp, #10224]               ; 16-byte Reload
	fmov	w8, s3
	and	w11, w8, #0xff
	mov	w9, #252                        ; =0xfc
	dup.2d	v0, x9
	orr.16b	v1, v6, v0
	str	q1, [sp, #48]                   ; 16-byte Spill
	add.2d	v1, v31, v1
	movi.2d	v11, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w8, #0, LBB0_1019
; %bb.999:                              ; %else4161
	orr.16b	v29, v7, v0
	str	q29, [sp, #3216]                ; 16-byte Spill
	tbnz	w11, #1, LBB0_1020
LBB0_1000:                              ; %else4167
	ldr	q1, [sp, #3216]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbnz	w11, #2, LBB0_1021
LBB0_1001:                              ; %else4173
	orr.16b	v29, v16, v0
	tbnz	w11, #3, LBB0_1022
LBB0_1002:                              ; %else4179
	add.2d	v1, v31, v29
	tbnz	w11, #4, LBB0_1023
LBB0_1003:                              ; %else4185
	mov	w9, #34816                      ; =0x8800
	orr.16b	v0, v17, v0
	tbnz	w11, #5, LBB0_1024
LBB0_1004:                              ; %else4191
	ldr	x8, [x1, #136]
	str	q0, [sp, #16]                   ; 16-byte Spill
	add.2d	v0, v31, v0
	str	q11, [sp, #9824]                ; 16-byte Spill
	tbz	w11, #6, LBB0_1006
LBB0_1005:                              ; %cond.load4193
	fmov	x10, d0
	ld1.s	{ v4 }[2], [x10]
LBB0_1006:                              ; %else4197
	str	q8, [sp, #9872]                 ; 16-byte Spill
	str	q12, [sp, #9808]                ; 16-byte Spill
	add	x9, x8, x9
	add	x10, x8, #16, lsl #12           ; =65536
	add	x10, x10, #2560
	ldr	q31, [sp, #11264]               ; 16-byte Reload
	ushll2.2d	v1, v31, #0
	str	q1, [sp, #9840]                 ; 16-byte Spill
	ldr	q1, [sp, #11312]                ; 16-byte Reload
	ushll2.2d	v8, v1, #0
	str	q8, [sp, #9856]                 ; 16-byte Spill
	ushll.2d	v31, v31, #0
	str	q31, [sp, #11264]               ; 16-byte Spill
	ushll.2d	v1, v1, #0
	str	q1, [sp, #11312]                ; 16-byte Spill
	str	q3, [sp, #4880]                 ; 16-byte Spill
	str	q6, [sp, #3200]                 ; 16-byte Spill
	str	q7, [sp, #3184]                 ; 16-byte Spill
	str	q16, [sp, #3168]                ; 16-byte Spill
	str	q17, [sp, #3152]                ; 16-byte Spill
	str	q18, [sp, #656]                 ; 16-byte Spill
	str	q14, [sp, #608]                 ; 16-byte Spill
	str	q13, [sp, #560]                 ; 16-byte Spill
	str	q9, [sp, #464]                  ; 16-byte Spill
	str	q20, [sp, #416]                 ; 16-byte Spill
	str	q21, [sp, #368]                 ; 16-byte Spill
	str	q22, [sp, #320]                 ; 16-byte Spill
	str	q23, [sp, #272]                 ; 16-byte Spill
	str	q24, [sp, #224]                 ; 16-byte Spill
	str	q26, [sp, #176]                 ; 16-byte Spill
	str	q27, [sp, #128]                 ; 16-byte Spill
	str	q28, [sp, #80]                  ; 16-byte Spill
	str	q29, [sp, #32]                  ; 16-byte Spill
	str	q19, [sp, #9888]                ; 16-byte Spill
	mov.16b	v8, v5
	tbz	w11, #7, LBB0_1025
; %bb.1007:                             ; %cond.load4199
	mov.d	x11, v0[1]
	mov.16b	v11, v4
	ld1.s	{ v11 }[3], [x11]
	b	LBB0_1026
LBB0_1008:                              ; %cond.load4077
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11584]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #11584]                ; 16-byte Spill
	add.2d	v1, v31, v27
	tbz	w8, #4, LBB0_985
LBB0_1009:                              ; %cond.load4083
	fmov	x9, d1
	ld1.s	{ v30 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_986
LBB0_1010:                              ; %cond.load4089
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[1], [x9]
	str	q0, [sp, #112]                  ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_987
LBB0_1011:                              ; %cond.load4095
	fmov	x9, d0
	ld1.s	{ v30 }[2], [x9]
	str	q8, [sp, #10416]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_988
	b	LBB0_989
LBB0_1012:                              ; %cond.load4108
	fmov	x9, d1
	ldr	s19, [x9]
	orr.16b	v28, v7, v0
	str	q28, [sp, #3232]                ; 16-byte Spill
	tbz	w8, #1, LBB0_991
LBB0_1013:                              ; %cond.load4114
	mov.d	x9, v1[1]
	ld1.s	{ v19 }[1], [x9]
	ldr	q1, [sp, #3232]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w8, #2, LBB0_992
LBB0_1014:                              ; %cond.load4120
	fmov	x9, d1
	ld1.s	{ v19 }[2], [x9]
	orr.16b	v28, v16, v0
	tbz	w8, #3, LBB0_993
LBB0_1015:                              ; %cond.load4126
	mov.d	x9, v1[1]
	ld1.s	{ v19 }[3], [x9]
	add.2d	v1, v31, v28
	tbz	w8, #4, LBB0_994
LBB0_1016:                              ; %cond.load4132
	fmov	x9, d1
	ld1.s	{ v8 }[0], [x9]
	orr.16b	v0, v17, v0
	tbz	w8, #5, LBB0_995
LBB0_1017:                              ; %cond.load4138
	mov.d	x9, v1[1]
	ld1.s	{ v8 }[1], [x9]
	str	q0, [sp, #64]                   ; 16-byte Spill
	add.2d	v0, v31, v0
	tbz	w8, #6, LBB0_996
LBB0_1018:                              ; %cond.load4144
	fmov	x9, d0
	ld1.s	{ v8 }[2], [x9]
	str	q4, [sp, #10096]                ; 16-byte Spill
	str	q10, [sp, #9968]                ; 16-byte Spill
	str	q30, [sp, #9920]                ; 16-byte Spill
	str	q11, [sp, #9792]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_997
	b	LBB0_998
LBB0_1019:                              ; %cond.load4157
	fmov	x8, d1
	ldr	s11, [x8]
	orr.16b	v29, v7, v0
	str	q29, [sp, #3216]                ; 16-byte Spill
	tbz	w11, #1, LBB0_1000
LBB0_1020:                              ; %cond.load4163
	mov.d	x8, v1[1]
	ld1.s	{ v11 }[1], [x8]
	ldr	q1, [sp, #3216]                 ; 16-byte Reload
	add.2d	v1, v31, v1
	tbz	w11, #2, LBB0_1001
LBB0_1021:                              ; %cond.load4169
	fmov	x8, d1
	ld1.s	{ v11 }[2], [x8]
	orr.16b	v29, v16, v0
	tbz	w11, #3, LBB0_1002
LBB0_1022:                              ; %cond.load4175
	mov.d	x8, v1[1]
	ld1.s	{ v11 }[3], [x8]
	add.2d	v1, v31, v29
	tbz	w11, #4, LBB0_1003
LBB0_1023:                              ; %cond.load4181
	fmov	x8, d1
	ld1.s	{ v4 }[0], [x8]
	mov	w9, #34816                      ; =0x8800
	orr.16b	v0, v17, v0
	tbz	w11, #5, LBB0_1004
LBB0_1024:                              ; %cond.load4187
	mov.d	x8, v1[1]
	ld1.s	{ v4 }[1], [x8]
	ldr	x8, [x1, #136]
	str	q0, [sp, #16]                   ; 16-byte Spill
	add.2d	v0, v31, v0
	str	q11, [sp, #9824]                ; 16-byte Spill
	tbnz	w11, #6, LBB0_1005
	b	LBB0_1006
LBB0_1025:
	mov.16b	v11, v4
LBB0_1026:                              ; %else4203
	ldr	q0, [x8, #16]
	ldr	q1, [sp, #11328]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11328]                ; 16-byte Spill
	mov	x11, #0                         ; =0x0
	ldr	q0, [x8]
	ldr	q1, [sp, #11568]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #9776]                 ; 16-byte Spill
	ldr	q0, [x8, #48]
	ldr	q1, [sp, #11536]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11568]                ; 16-byte Spill
	ldr	q0, [x8, #32]
	ldr	q1, [sp, #11552]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11536]                ; 16-byte Spill
	ldr	q0, [x8, #80]
	ldr	q1, [sp, #11504]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11552]                ; 16-byte Spill
	ldr	q0, [x8, #64]
	ldr	q1, [sp, #11520]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11504]                ; 16-byte Spill
	ldr	q0, [x8, #112]
	ldr	q1, [sp, #11472]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11520]                ; 16-byte Spill
	ldr	q0, [x8, #96]
	ldr	q1, [sp, #11488]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11472]                ; 16-byte Spill
	ldr	q0, [x8, #144]
	ldr	q1, [sp, #11440]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11488]                ; 16-byte Spill
	ldr	q0, [x8, #128]
	ldr	q1, [sp, #11456]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11440]                ; 16-byte Spill
	ldr	q0, [x8, #176]
	ldr	q1, [sp, #11408]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11456]                ; 16-byte Spill
	ldr	q0, [x8, #160]
	ldr	q1, [sp, #11424]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11408]                ; 16-byte Spill
	ldr	q0, [x8, #208]
	ldr	q1, [sp, #11376]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11424]                ; 16-byte Spill
	ldr	q0, [x8, #192]
	ldr	q1, [sp, #11392]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11376]                ; 16-byte Spill
	ldr	q0, [x8, #240]
	ldr	q1, [sp, #11344]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11392]                ; 16-byte Spill
	ldr	q0, [x8, #224]
	ldr	q1, [sp, #11360]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11344]                ; 16-byte Spill
	ldr	q0, [x8, #272]
	ldr	q1, [sp, #11280]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11360]                ; 16-byte Spill
	ldr	q0, [x8, #256]
	ldr	q1, [sp, #11296]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11280]                ; 16-byte Spill
	ldr	q0, [x8, #288]
	ldr	q1, [sp, #11248]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11296]                ; 16-byte Spill
	ldr	q0, [x8, #304]
	ldr	q1, [sp, #11232]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11232]                ; 16-byte Spill
	ldr	q0, [x8, #320]
	ldr	q1, [sp, #11216]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11248]                ; 16-byte Spill
	ldr	q0, [x8, #336]
	ldr	q1, [sp, #11200]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11200]                ; 16-byte Spill
	ldr	q0, [x8, #352]
	ldr	q1, [sp, #11184]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11216]                ; 16-byte Spill
	ldr	q0, [x8, #368]
	ldr	q1, [sp, #11168]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11168]                ; 16-byte Spill
	ldr	q0, [x8, #384]
	ldr	q1, [sp, #11152]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11184]                ; 16-byte Spill
	ldr	q0, [x8, #400]
	ldr	q1, [sp, #11136]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11136]                ; 16-byte Spill
	ldr	q0, [x8, #432]
	ldr	q1, [sp, #11120]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11152]                ; 16-byte Spill
	ldr	q0, [x8, #416]
	ldr	q1, [sp, #11840]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11120]                ; 16-byte Spill
	ldr	q0, [x8, #448]
	ldr	q1, [sp, #11824]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11840]                ; 16-byte Spill
	ldr	q0, [x8, #464]
	ldr	q1, [sp, #11104]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11104]                ; 16-byte Spill
	ldr	q0, [x8, #480]
	ldr	q1, [sp, #11808]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11824]                ; 16-byte Spill
	ldr	q0, [x8, #496]
	ldr	q1, [sp, #11088]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11088]                ; 16-byte Spill
	ldr	q0, [x8, #512]
	ldr	q1, [sp, #11792]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11808]                ; 16-byte Spill
	ldr	q0, [x8, #528]
	ldr	q1, [sp, #11072]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #9760]                 ; 16-byte Spill
	ldr	q0, [x8, #544]
	ldr	q1, [sp, #11776]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11072]                ; 16-byte Spill
	ldr	q0, [x8, #560]
	ldr	q1, [sp, #11056]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11056]                ; 16-byte Spill
	ldr	q0, [x8, #576]
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11760]                ; 16-byte Spill
	ldr	q0, [x8, #592]
	ldr	q1, [sp, #11040]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #11040]                ; 16-byte Spill
	ldr	q0, [x8, #608]
	ldr	q1, [sp, #11632]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11632]                ; 16-byte Spill
	ldr	q0, [x8, #624]
	ldr	q1, [sp, #11024]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #9744]                 ; 16-byte Spill
	ldr	q0, [x8, #640]
	ldr	q1, [sp, #11008]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11024]                ; 16-byte Spill
	ldr	q0, [x8, #656]
	ldr	q1, [sp, #10992]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10992]                ; 16-byte Spill
	ldr	q0, [x8, #672]
	ldr	q1, [sp, #10976]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11008]                ; 16-byte Spill
	ldr	q0, [x8, #688]
	ldr	q1, [sp, #10960]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10976]                ; 16-byte Spill
	ldr	q0, [x8, #704]
	ldr	q1, [sp, #11744]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11744]                ; 16-byte Spill
	ldr	q0, [x8, #720]
	ldr	q1, [sp, #10944]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10960]                ; 16-byte Spill
	ldr	q0, [x8, #736]
	ldr	q1, [sp, #11728]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11728]                ; 16-byte Spill
	ldr	q0, [x8, #752]
	ldr	q1, [sp, #10928]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10944]                ; 16-byte Spill
	ldr	q0, [x8, #768]
	ldr	q1, [sp, #11712]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11712]                ; 16-byte Spill
	ldr	q0, [x8, #784]
	ldr	q1, [sp, #10912]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10928]                ; 16-byte Spill
	ldr	q0, [x8, #800]
	ldr	q1, [sp, #11696]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11696]                ; 16-byte Spill
	ldr	q0, [x8, #816]
	ldr	q1, [sp, #10896]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10896]                ; 16-byte Spill
	ldr	q0, [x8, #832]
	ldr	q1, [sp, #10880]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10912]                ; 16-byte Spill
	ldr	q0, [x8, #848]
	ldr	q1, [sp, #10864]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10864]                ; 16-byte Spill
	ldr	q0, [x8, #864]
	ldr	q1, [sp, #10848]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10880]                ; 16-byte Spill
	ldr	q0, [x8, #880]
	ldr	q1, [sp, #10832]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10832]                ; 16-byte Spill
	ldr	q0, [x8, #896]
	ldr	q1, [sp, #10816]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10848]                ; 16-byte Spill
	ldr	q0, [x8, #912]
	ldr	q1, [sp, #11680]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10816]                ; 16-byte Spill
	ldr	q0, [x8, #928]
	ldr	q1, [sp, #10800]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11680]                ; 16-byte Spill
	ldr	q0, [x8, #944]
	ldr	q1, [sp, #11664]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10800]                ; 16-byte Spill
	ldr	q0, [x8, #960]
	ldr	q1, [sp, #10784]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11664]                ; 16-byte Spill
	ldr	q0, [x8, #976]
	ldr	q1, [sp, #10768]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10768]                ; 16-byte Spill
	ldr	q0, [x8, #992]
	ldr	q1, [sp, #10752]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10784]                ; 16-byte Spill
	ldr	q0, [x8, #1008]
	ldr	q1, [sp, #10736]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10736]                ; 16-byte Spill
	ldr	q0, [x8, #1024]
	ldr	q1, [sp, #10720]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10752]                ; 16-byte Spill
	ldr	q0, [x8, #1040]
	ldr	q1, [sp, #10704]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10704]                ; 16-byte Spill
	ldr	q0, [x8, #1056]
	ldr	q1, [sp, #10688]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10720]                ; 16-byte Spill
	ldr	q0, [x8, #1072]
	ldr	q1, [sp, #10672]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10672]                ; 16-byte Spill
	ldr	q0, [x8, #1088]
	ldr	q1, [sp, #10656]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10688]                ; 16-byte Spill
	ldr	q0, [x8, #1104]
	ldr	q1, [sp, #10640]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10656]                ; 16-byte Spill
	ldr	q0, [x8, #1120]
	ldr	q1, [sp, #11648]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #11648]                ; 16-byte Spill
	ldr	q0, [x8, #1136]
	ldr	q1, [sp, #10624]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10624]                ; 16-byte Spill
	ldr	q0, [x8, #1152]
	ldr	q1, [sp, #10608]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10640]                ; 16-byte Spill
	ldr	q0, [x8, #1168]
	ldr	q1, [sp, #10592]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10592]                ; 16-byte Spill
	ldr	q0, [x8, #1184]
	ldr	q1, [sp, #10576]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10608]                ; 16-byte Spill
	ldr	q0, [x8, #1200]
	ldr	q1, [sp, #10544]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10544]                ; 16-byte Spill
	ldr	q0, [x8, #1216]
	ldr	q1, [sp, #10560]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10576]                ; 16-byte Spill
	ldr	q0, [x8, #1232]
	ldr	q1, [sp, #10480]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10480]                ; 16-byte Spill
	ldr	q0, [x8, #1248]
	ldr	q1, [sp, #10528]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10560]                ; 16-byte Spill
	ldr	q0, [x8, #1264]
	ldr	q1, [sp, #10448]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10448]                ; 16-byte Spill
	ldr	q0, [x8, #1280]
	ldr	q1, [sp, #10512]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10528]                ; 16-byte Spill
	ldr	q0, [x8, #1296]
	ldr	q1, [sp, #10336]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10336]                ; 16-byte Spill
	ldr	q0, [x8, #1312]
	ldr	q1, [sp, #10496]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10512]                ; 16-byte Spill
	ldr	q0, [x8, #1328]
	bit.16b	v0, v30, v25
	str	q0, [sp, #10224]                ; 16-byte Spill
	ldr	q0, [x8, #1344]
	ldr	q1, [sp, #10464]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10496]                ; 16-byte Spill
	ldr	q0, [x8, #1360]
	ldr	q1, [sp, #9936]                 ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #9936]                 ; 16-byte Spill
	ldr	q0, [x8, #1376]
	ldr	q1, [sp, #10384]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10464]                ; 16-byte Spill
	ldr	q0, [x8, #1392]
	ldr	q1, [sp, #10432]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10384]                ; 16-byte Spill
	ldr	q0, [x8, #1408]
	bit.16b	v0, v10, v2
	str	q0, [sp, #10432]                ; 16-byte Spill
	ldr	q0, [x8, #1424]
	ldr	q1, [sp, #10416]                ; 16-byte Reload
	bit.16b	v0, v1, v25
	str	q0, [sp, #10000]                ; 16-byte Spill
	ldr	q0, [x8, #1440]
	ldr	q1, [sp, #10400]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10416]                ; 16-byte Spill
	ldr	q0, [x8, #1456]
	ldr	q1, [sp, #9968]                 ; 16-byte Reload
	mov.16b	v12, v25
	bsl.16b	v12, v1, v0
	ldr	q0, [x8, #1472]
	ldr	q1, [sp, #10368]                ; 16-byte Reload
	bit.16b	v0, v1, v2
	str	q0, [sp, #10400]                ; 16-byte Spill
	ldr	q0, [x8, #1488]
	str	q2, [sp, #11776]                ; 16-byte Spill
	ldr	q1, [sp, #9792]                 ; 16-byte Reload
	mov.16b	v30, v25
	bsl.16b	v30, v1, v0
	ldr	q0, [x8, #1504]
	ldr	q1, [sp, #11776]                ; 16-byte Reload
	ldr	q2, [sp, #10352]                ; 16-byte Reload
	mov.16b	v31, v1
	bsl.16b	v31, v2, v0
	ldr	q0, [x8, #1520]
	ldr	q1, [sp, #10096]                ; 16-byte Reload
	mov.16b	v28, v25
	bsl.16b	v28, v1, v0
	ldr	q0, [x8, #1536]
	ldr	q1, [sp, #11776]                ; 16-byte Reload
	ldr	q2, [sp, #10320]                ; 16-byte Reload
	mov.16b	v29, v1
	bsl.16b	v29, v2, v0
	ldr	q0, [x8, #1552]
	ldr	q1, [sp, #10304]                ; 16-byte Reload
	mov.16b	v4, v25
	bsl.16b	v4, v1, v0
	ldr	q0, [x8, #1568]
	ldr	q1, [sp, #11776]                ; 16-byte Reload
	ldr	q2, [sp, #10288]                ; 16-byte Reload
	mov.16b	v6, v1
	bsl.16b	v6, v2, v0
	ldr	q0, [x8, #1584]
	ldr	q1, [sp, #10272]                ; 16-byte Reload
	mov.16b	v3, v25
	bsl.16b	v3, v1, v0
	ldr	q0, [x8, #1600]
	ldr	q1, [sp, #11776]                ; 16-byte Reload
	ldr	q2, [sp, #10144]                ; 16-byte Reload
	mov.16b	v5, v1
	bsl.16b	v5, v2, v0
	ldr	q0, [x8, #1616]
	ldr	q1, [sp, #10256]                ; 16-byte Reload
	mov.16b	v2, v25
	bsl.16b	v2, v1, v0
	ldr	q1, [x8, #1632]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q7, [sp, #10192]                ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v7, v1
	ldr	q1, [x8, #1648]
	ldr	q0, [sp, #10240]                ; 16-byte Reload
	bit.16b	v1, v0, v25
	ldr	q7, [x8, #1664]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q17, [sp, #10112]               ; 16-byte Reload
	mov.16b	v9, v0
	bsl.16b	v9, v17, v7
	ldr	q7, [x8, #1680]
	ldr	q0, [sp, #10208]                ; 16-byte Reload
	mov.16b	v17, v25
	bsl.16b	v17, v0, v7
	ldr	q7, [x8, #1696]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q18, [sp, #9984]                ; 16-byte Reload
	mov.16b	v10, v0
	bsl.16b	v10, v18, v7
	ldr	q7, [x8, #1712]
	ldr	q0, [sp, #10160]                ; 16-byte Reload
	mov.16b	v18, v25
	bsl.16b	v18, v0, v7
	ldr	q7, [x8, #1728]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q19, [sp, #10176]               ; 16-byte Reload
	bsl.16b	v0, v19, v7
	str	q0, [sp, #10368]                ; 16-byte Spill
	ldr	q7, [x8, #1744]
	ldr	q0, [sp, #10128]                ; 16-byte Reload
	bit.16b	v7, v0, v25
	ldr	q19, [x8, #1760]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q20, [sp, #11616]               ; 16-byte Reload
	bsl.16b	v0, v20, v19
	str	q0, [sp, #11616]                ; 16-byte Spill
	ldr	q19, [x8, #1776]
	bit.16b	v19, v8, v25
	ldr	q20, [x8, #1792]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q21, [sp, #9904]                ; 16-byte Reload
	bsl.16b	v0, v21, v20
	str	q0, [sp, #10352]                ; 16-byte Spill
	ldr	q20, [x8, #1808]
	ldr	q0, [sp, #9808]                 ; 16-byte Reload
	bit.16b	v20, v0, v25
	ldr	q21, [x8, #1824]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q22, [sp, #10080]               ; 16-byte Reload
	bsl.16b	v0, v22, v21
	str	q0, [sp, #10320]                ; 16-byte Spill
	ldr	q21, [x8, #1840]
	ldr	q0, [sp, #10064]                ; 16-byte Reload
	bit.16b	v21, v0, v25
	ldr	q22, [x8, #1856]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	bsl.16b	v0, v15, v22
	str	q0, [sp, #10288]                ; 16-byte Spill
	ldr	q22, [x8, #1872]
	ldr	q0, [sp, #10048]                ; 16-byte Reload
	bit.16b	v22, v0, v25
	ldr	q23, [x8, #1888]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q24, [sp, #10032]               ; 16-byte Reload
	bsl.16b	v0, v24, v23
	str	q0, [sp, #10272]                ; 16-byte Spill
	ldr	q23, [x8, #1904]
	ldr	q0, [sp, #10016]                ; 16-byte Reload
	bit.16b	v23, v0, v25
	ldr	q24, [x8, #1920]
	str	q25, [sp, #11792]               ; 16-byte Spill
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q25, [sp, #11600]               ; 16-byte Reload
	mov.16b	v13, v0
	bsl.16b	v13, v25, v24
	ldr	q24, [x8, #1936]
	ldr	q0, [sp, #11792]                ; 16-byte Reload
	ldr	q25, [sp, #9952]                ; 16-byte Reload
	bit.16b	v24, v25, v0
	ldr	q25, [x8, #1952]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q26, [sp, #11584]               ; 16-byte Reload
	mov.16b	v14, v0
	bsl.16b	v14, v26, v25
	ldr	q25, [x8, #1968]
	ldr	q0, [sp, #11792]                ; 16-byte Reload
	ldr	q26, [sp, #9920]                ; 16-byte Reload
	bit.16b	v25, v26, v0
	ldr	q26, [x8, #1984]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q27, [sp, #9888]                ; 16-byte Reload
	mov.16b	v15, v0
	bsl.16b	v15, v27, v26
	ldr	q26, [x8, #2000]
	ldr	q0, [sp, #11792]                ; 16-byte Reload
	ldr	q27, [sp, #9872]                ; 16-byte Reload
	bit.16b	v26, v27, v0
	ldr	q27, [x8, #2016]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q8, [sp, #9824]                 ; 16-byte Reload
	bsl.16b	v0, v8, v27
	str	q0, [sp, #11600]                ; 16-byte Spill
	ldr	q27, [x8, #2032]
	ldr	q0, [sp, #11792]                ; 16-byte Reload
	bit.16b	v27, v11, v0
	ldr	q0, [sp, #11264]                ; 16-byte Reload
	shl.2d	v0, v0, #19
	ldr	q11, [sp, #11792]               ; 16-byte Reload
	sshll.2d	v11, v11, #0
	and.16b	v0, v11, v0
	str	q0, [sp, #4816]                 ; 16-byte Spill
	ldr	q0, [sp, #11312]                ; 16-byte Reload
	shl.2d	v0, v0, #19
	ldr	q11, [sp, #11776]               ; 16-byte Reload
	sshll.2d	v11, v11, #0
	and.16b	v8, v11, v0
	ldr	q0, [sp, #9776]                 ; 16-byte Reload
	str	q0, [x8]
	ldr	q0, [sp, #11328]                ; 16-byte Reload
	str	q0, [x8, #16]
	ldr	q0, [sp, #11536]                ; 16-byte Reload
	str	q0, [x8, #32]
	ldr	q0, [sp, #11568]                ; 16-byte Reload
	str	q0, [x8, #48]
	ldr	q0, [sp, #11504]                ; 16-byte Reload
	str	q0, [x8, #64]
	ldr	q0, [sp, #11552]                ; 16-byte Reload
	str	q0, [x8, #80]
	ldr	q0, [sp, #11472]                ; 16-byte Reload
	str	q0, [x8, #96]
	ldr	q0, [sp, #11520]                ; 16-byte Reload
	str	q0, [x8, #112]
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	str	q0, [x8, #128]
	ldr	q0, [sp, #11488]                ; 16-byte Reload
	str	q0, [x8, #144]
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	str	q0, [x8, #160]
	ldr	q0, [sp, #11456]                ; 16-byte Reload
	str	q0, [x8, #176]
	ldr	q0, [sp, #11376]                ; 16-byte Reload
	str	q0, [x8, #192]
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	str	q0, [x8, #208]
	ldr	q0, [sp, #11344]                ; 16-byte Reload
	str	q0, [x8, #224]
	ldr	q0, [sp, #11392]                ; 16-byte Reload
	str	q0, [x8, #240]
	ldr	q0, [sp, #11280]                ; 16-byte Reload
	str	q0, [x8, #256]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	str	q0, [x8, #272]
	ldr	q0, [sp, #11232]                ; 16-byte Reload
	str	q0, [x8, #304]
	ldr	q0, [sp, #11296]                ; 16-byte Reload
	str	q0, [x8, #288]
	ldr	q0, [sp, #11200]                ; 16-byte Reload
	str	q0, [x8, #336]
	ldr	q0, [sp, #11248]                ; 16-byte Reload
	str	q0, [x8, #320]
	ldr	q0, [sp, #11168]                ; 16-byte Reload
	str	q0, [x8, #368]
	ldr	q0, [sp, #11216]                ; 16-byte Reload
	str	q0, [x8, #352]
	ldr	q0, [sp, #11136]                ; 16-byte Reload
	str	q0, [x8, #400]
	ldr	q0, [sp, #11184]                ; 16-byte Reload
	str	q0, [x8, #384]
	ldr	q0, [sp, #11120]                ; 16-byte Reload
	str	q0, [x8, #416]
	ldr	q0, [sp, #11152]                ; 16-byte Reload
	str	q0, [x8, #432]
	ldr	q0, [sp, #11104]                ; 16-byte Reload
	str	q0, [x8, #464]
	ldr	q0, [sp, #11840]                ; 16-byte Reload
	str	q0, [x8, #448]
	ldr	q0, [sp, #11088]                ; 16-byte Reload
	str	q0, [x8, #496]
	ldr	q0, [sp, #11824]                ; 16-byte Reload
	str	q0, [x8, #480]
	ldr	q0, [sp, #9760]                 ; 16-byte Reload
	str	q0, [x8, #528]
	ldr	q0, [sp, #11808]                ; 16-byte Reload
	str	q0, [x8, #512]
	ldr	q0, [sp, #11056]                ; 16-byte Reload
	str	q0, [x8, #560]
	ldr	q0, [sp, #11072]                ; 16-byte Reload
	str	q0, [x8, #544]
	ldr	q0, [sp, #11040]                ; 16-byte Reload
	str	q0, [x8, #592]
	ldr	q0, [sp, #11760]                ; 16-byte Reload
	str	q0, [x8, #576]
	ldr	q0, [sp, #9744]                 ; 16-byte Reload
	str	q0, [x8, #624]
	ldr	q0, [sp, #11632]                ; 16-byte Reload
	str	q0, [x8, #608]
	ldr	q0, [sp, #10992]                ; 16-byte Reload
	str	q0, [x8, #656]
	ldr	q0, [sp, #11024]                ; 16-byte Reload
	str	q0, [x8, #640]
	ldr	q0, [sp, #10976]                ; 16-byte Reload
	str	q0, [x8, #688]
	ldr	q0, [sp, #11008]                ; 16-byte Reload
	str	q0, [x8, #672]
	ldr	q0, [sp, #10960]                ; 16-byte Reload
	str	q0, [x8, #720]
	ldr	q0, [sp, #11744]                ; 16-byte Reload
	str	q0, [x8, #704]
	ldr	q0, [sp, #10944]                ; 16-byte Reload
	str	q0, [x8, #752]
	ldr	q0, [sp, #11728]                ; 16-byte Reload
	str	q0, [x8, #736]
	ldr	q0, [sp, #10928]                ; 16-byte Reload
	str	q0, [x8, #784]
	ldr	q0, [sp, #11712]                ; 16-byte Reload
	str	q0, [x8, #768]
	ldr	q0, [sp, #10896]                ; 16-byte Reload
	str	q0, [x8, #816]
	ldr	q0, [sp, #11696]                ; 16-byte Reload
	str	q0, [x8, #800]
	ldr	q0, [sp, #10864]                ; 16-byte Reload
	str	q0, [x8, #848]
	ldr	q0, [sp, #10912]                ; 16-byte Reload
	str	q0, [x8, #832]
	ldr	q0, [sp, #10832]                ; 16-byte Reload
	str	q0, [x8, #880]
	ldr	q0, [sp, #10880]                ; 16-byte Reload
	str	q0, [x8, #864]
	ldr	q0, [sp, #10816]                ; 16-byte Reload
	str	q0, [x8, #912]
	ldr	q0, [sp, #10848]                ; 16-byte Reload
	str	q0, [x8, #896]
	ldr	q0, [sp, #10800]                ; 16-byte Reload
	str	q0, [x8, #944]
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	str	q0, [x8, #928]
	ldr	q0, [sp, #10768]                ; 16-byte Reload
	str	q0, [x8, #976]
	ldr	q0, [sp, #11664]                ; 16-byte Reload
	str	q0, [x8, #960]
	ldr	q0, [sp, #10736]                ; 16-byte Reload
	str	q0, [x8, #1008]
	ldr	q0, [sp, #10784]                ; 16-byte Reload
	str	q0, [x8, #992]
	ldr	q0, [sp, #10704]                ; 16-byte Reload
	str	q0, [x8, #1040]
	ldr	q0, [sp, #10752]                ; 16-byte Reload
	str	q0, [x8, #1024]
	ldr	q0, [sp, #10672]                ; 16-byte Reload
	str	q0, [x8, #1072]
	ldr	q0, [sp, #10720]                ; 16-byte Reload
	str	q0, [x8, #1056]
	ldr	q0, [sp, #10656]                ; 16-byte Reload
	str	q0, [x8, #1104]
	ldr	q0, [sp, #10688]                ; 16-byte Reload
	str	q0, [x8, #1088]
	ldr	q0, [sp, #10624]                ; 16-byte Reload
	str	q0, [x8, #1136]
	ldr	q0, [sp, #11648]                ; 16-byte Reload
	str	q0, [x8, #1120]
	ldr	q0, [sp, #10592]                ; 16-byte Reload
	str	q0, [x8, #1168]
	ldr	q0, [sp, #10640]                ; 16-byte Reload
	str	q0, [x8, #1152]
	ldr	q0, [sp, #10544]                ; 16-byte Reload
	str	q0, [x8, #1200]
	ldr	q0, [sp, #10608]                ; 16-byte Reload
	str	q0, [x8, #1184]
	ldr	q0, [sp, #10480]                ; 16-byte Reload
	str	q0, [x8, #1232]
	ldr	q0, [sp, #10576]                ; 16-byte Reload
	str	q0, [x8, #1216]
	ldr	q0, [sp, #10448]                ; 16-byte Reload
	str	q0, [x8, #1264]
	ldr	q0, [sp, #10560]                ; 16-byte Reload
	str	q0, [x8, #1248]
	ldr	q0, [sp, #10336]                ; 16-byte Reload
	str	q0, [x8, #1296]
	ldr	q0, [sp, #10528]                ; 16-byte Reload
	str	q0, [x8, #1280]
	ldr	q0, [sp, #10224]                ; 16-byte Reload
	str	q0, [x8, #1328]
	ldr	q0, [sp, #10512]                ; 16-byte Reload
	str	q0, [x8, #1312]
	ldr	q0, [sp, #9936]                 ; 16-byte Reload
	str	q0, [x8, #1360]
	ldr	q0, [sp, #10496]                ; 16-byte Reload
	str	q0, [x8, #1344]
	ldr	q0, [sp, #10384]                ; 16-byte Reload
	str	q0, [x8, #1392]
	ldr	q0, [sp, #10464]                ; 16-byte Reload
	str	q0, [x8, #1376]
	ldr	q0, [sp, #10000]                ; 16-byte Reload
	str	q0, [x8, #1424]
	ldr	q0, [sp, #10432]                ; 16-byte Reload
	str	q0, [x8, #1408]
	str	q12, [x8, #1456]
	ldr	q0, [sp, #10416]                ; 16-byte Reload
	str	q0, [x8, #1440]
	str	q30, [x8, #1488]
	ldr	q30, [sp, #11776]               ; 16-byte Reload
	ldr	q0, [sp, #10400]                ; 16-byte Reload
	str	q0, [x8, #1472]
	str	q28, [x8, #1520]
	str	q31, [x8, #1504]
	str	q4, [x8, #1552]
	str	q29, [x8, #1536]
	str	q3, [x8, #1584]
	str	q6, [x8, #1568]
	str	q2, [x8, #1616]
	ldr	q0, [sp, #11792]                ; 16-byte Reload
	sshll2.2d	v2, v0, #0
	str	q5, [x8, #1600]
	sshll2.2d	v3, v30, #0
	mov	w12, #62154                     ; =0xf2ca
	movk	w12, #61769, lsl #16
	str	q1, [x8, #1648]
	dup.4s	v0, w12
	str	q16, [x8, #1632]
	ldr	q1, [sp, #11792]                ; 16-byte Reload
	and.16b	v1, v1, v0
	str	q1, [sp, #11744]                ; 16-byte Spill
	and.16b	v0, v30, v0
	str	q0, [sp, #11728]                ; 16-byte Spill
	ldr	q0, [sp, #9840]                 ; 16-byte Reload
	shl.2d	v0, v0, #19
	ldr	q1, [sp, #9856]                 ; 16-byte Reload
	shl.2d	v1, v1, #19
	str	q3, [sp, #4128]                 ; 16-byte Spill
	and.16b	v1, v3, v1
	str	q1, [sp, #11840]                ; 16-byte Spill
	str	q2, [sp, #4112]                 ; 16-byte Spill
	and.16b	v0, v2, v0
	str	q0, [sp, #11824]                ; 16-byte Spill
	mov.16b	v2, v30
	str	q17, [x8, #1680]
	str	q9, [x8, #1664]
	str	q18, [x8, #1712]
	str	q10, [x8, #1696]
	str	q7, [x8, #1744]
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #4784]                 ; 16-byte Spill
	ldr	q0, [sp, #10368]                ; 16-byte Reload
	str	q0, [x8, #1728]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #10336]                ; 16-byte Spill
	str	q19, [x8, #1776]
	str	q0, [sp, #10368]                ; 16-byte Spill
	ldr	q0, [sp, #11616]                ; 16-byte Reload
	str	q0, [x8, #1760]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #10256]                ; 16-byte Spill
	str	q20, [x8, #1808]
	str	q0, [sp, #10304]                ; 16-byte Spill
	ldr	q0, [sp, #10352]                ; 16-byte Reload
	str	q0, [x8, #1792]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #10192]                ; 16-byte Spill
	str	q21, [x8, #1840]
	str	q0, [sp, #10240]                ; 16-byte Spill
	ldr	q0, [sp, #10320]                ; 16-byte Reload
	str	q0, [x8, #1824]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #10144]                ; 16-byte Spill
	str	q22, [x8, #1872]
	str	q0, [sp, #10160]                ; 16-byte Spill
	ldr	q0, [sp, #10288]                ; 16-byte Reload
	str	q0, [x8, #1856]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #10112]                ; 16-byte Spill
	str	q23, [x8, #1904]
	str	q0, [sp, #10128]                ; 16-byte Spill
	ldr	q0, [sp, #10272]                ; 16-byte Reload
	str	q0, [x8, #1888]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #10080]                ; 16-byte Spill
	str	q24, [x8, #1936]
	str	q0, [sp, #10096]                ; 16-byte Spill
	str	q13, [x8, #1920]
	ldr	q13, [sp, #11792]               ; 16-byte Reload
	str	q0, [sp, #10048]                ; 16-byte Spill
	str	q25, [x8, #1968]
	str	q0, [sp, #10064]                ; 16-byte Spill
	str	q14, [x8, #1952]
	str	q0, [sp, #10016]                ; 16-byte Spill
	str	q26, [x8, #2000]
	str	q0, [sp, #10032]                ; 16-byte Spill
	str	q15, [x8, #1984]
	str	q0, [sp, #9984]                 ; 16-byte Spill
	str	q27, [x8, #2032]
	str	q0, [sp, #10000]                ; 16-byte Spill
	ldr	q0, [sp, #11600]                ; 16-byte Reload
	str	q0, [x8, #2016]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #9968]                 ; 16-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #2048
	mov	w13, #34848                     ; =0x8820
	add	x13, x8, x13
	str	x13, [sp, #4776]                ; 8-byte Spill
	mov	w13, #34880                     ; =0x8840
	add	x13, x8, x13
	str	x13, [sp, #4768]                ; 8-byte Spill
	mov	w13, #34912                     ; =0x8860
	add	x13, x8, x13
	str	x13, [sp, #4760]                ; 8-byte Spill
	mov	w13, #34944                     ; =0x8880
	add	x13, x8, x13
	str	x13, [sp, #4752]                ; 8-byte Spill
	mov	w13, #34976                     ; =0x88a0
	add	x13, x8, x13
	str	x13, [sp, #4744]                ; 8-byte Spill
	mov	w13, #35008                     ; =0x88c0
	add	x13, x8, x13
	str	x13, [sp, #4736]                ; 8-byte Spill
	mov	w13, #35040                     ; =0x88e0
	add	x13, x8, x13
	str	x13, [sp, #4728]                ; 8-byte Spill
	mov	w13, #35072                     ; =0x8900
	add	x13, x8, x13
	str	x13, [sp, #4720]                ; 8-byte Spill
	mov	w13, #35104                     ; =0x8920
	add	x13, x8, x13
	str	x13, [sp, #4712]                ; 8-byte Spill
	mov	w13, #35136                     ; =0x8940
	add	x13, x8, x13
	str	x13, [sp, #4704]                ; 8-byte Spill
	mov	w13, #35168                     ; =0x8960
	add	x13, x8, x13
	str	x13, [sp, #4696]                ; 8-byte Spill
	mov	w13, #35200                     ; =0x8980
	add	x13, x8, x13
	str	x13, [sp, #4688]                ; 8-byte Spill
	mov	w13, #35232                     ; =0x89a0
	add	x13, x8, x13
	str	x13, [sp, #4680]                ; 8-byte Spill
	mov	w13, #35264                     ; =0x89c0
	add	x13, x8, x13
	str	x13, [sp, #4672]                ; 8-byte Spill
	mov	w13, #35296                     ; =0x89e0
	add	x13, x8, x13
	str	x13, [sp, #4664]                ; 8-byte Spill
	mov	w13, #35328                     ; =0x8a00
	add	x22, x8, x13
	mov	w13, #35360                     ; =0x8a20
	add	x13, x8, x13
	str	x13, [sp, #4656]                ; 8-byte Spill
	mov	w13, #35392                     ; =0x8a40
	add	x13, x8, x13
	str	x13, [sp, #4648]                ; 8-byte Spill
	mov	w13, #35424                     ; =0x8a60
	add	x13, x8, x13
	str	x13, [sp, #4640]                ; 8-byte Spill
	mov	w13, #35456                     ; =0x8a80
	add	x13, x8, x13
	str	x13, [sp, #4632]                ; 8-byte Spill
	mov	w13, #35488                     ; =0x8aa0
	add	x13, x8, x13
	str	x13, [sp, #4624]                ; 8-byte Spill
	mov	w13, #35520                     ; =0x8ac0
	add	x13, x8, x13
	str	x13, [sp, #4616]                ; 8-byte Spill
	mov	w13, #35552                     ; =0x8ae0
	add	x13, x8, x13
	str	x13, [sp, #4608]                ; 8-byte Spill
	mov	w13, #35584                     ; =0x8b00
	add	x13, x8, x13
	str	x13, [sp, #4600]                ; 8-byte Spill
	mov	w13, #35616                     ; =0x8b20
	add	x13, x8, x13
	str	x13, [sp, #4592]                ; 8-byte Spill
	mov	w13, #35648                     ; =0x8b40
	add	x13, x8, x13
	str	x13, [sp, #4584]                ; 8-byte Spill
	mov	w13, #35680                     ; =0x8b60
	add	x13, x8, x13
	str	x13, [sp, #4576]                ; 8-byte Spill
	mov	w13, #35712                     ; =0x8b80
	add	x13, x8, x13
	str	x13, [sp, #4568]                ; 8-byte Spill
	mov	w13, #35744                     ; =0x8ba0
	add	x13, x8, x13
	str	x13, [sp, #4560]                ; 8-byte Spill
	mov	w13, #35776                     ; =0x8bc0
	add	x13, x8, x13
	str	x13, [sp, #4552]                ; 8-byte Spill
	mov	w13, #35808                     ; =0x8be0
	add	x13, x8, x13
	str	x13, [sp, #4544]                ; 8-byte Spill
	mov	w13, #35840                     ; =0x8c00
	add	x13, x8, x13
	str	x13, [sp, #4536]                ; 8-byte Spill
	mov	w13, #35872                     ; =0x8c20
	add	x13, x8, x13
	str	x13, [sp, #4528]                ; 8-byte Spill
	mov	w13, #35904                     ; =0x8c40
	add	x13, x8, x13
	str	x13, [sp, #4520]                ; 8-byte Spill
	mov	w13, #35936                     ; =0x8c60
	add	x13, x8, x13
	str	x13, [sp, #4512]                ; 8-byte Spill
	mov	w13, #35968                     ; =0x8c80
	add	x13, x8, x13
	str	x13, [sp, #4504]                ; 8-byte Spill
	mov	w13, #36000                     ; =0x8ca0
	add	x13, x8, x13
	str	x13, [sp, #4496]                ; 8-byte Spill
	mov	w13, #36032                     ; =0x8cc0
	add	x13, x8, x13
	str	x13, [sp, #4488]                ; 8-byte Spill
	mov	w13, #36064                     ; =0x8ce0
	add	x13, x8, x13
	str	x13, [sp, #4480]                ; 8-byte Spill
	mov	w13, #36096                     ; =0x8d00
	add	x13, x8, x13
	str	x13, [sp, #4472]                ; 8-byte Spill
	mov	w13, #36128                     ; =0x8d20
	add	x13, x8, x13
	str	x13, [sp, #4464]                ; 8-byte Spill
	mov	w13, #36160                     ; =0x8d40
	add	x13, x8, x13
	str	x13, [sp, #4456]                ; 8-byte Spill
	mov	w13, #36192                     ; =0x8d60
	add	x13, x8, x13
	str	x13, [sp, #4448]                ; 8-byte Spill
	mov	w13, #36224                     ; =0x8d80
	add	x13, x8, x13
	str	x13, [sp, #4440]                ; 8-byte Spill
	mov	w13, #36256                     ; =0x8da0
	add	x13, x8, x13
	str	x13, [sp, #4432]                ; 8-byte Spill
	mov	w13, #36288                     ; =0x8dc0
	add	x13, x8, x13
	str	x13, [sp, #4424]                ; 8-byte Spill
	mov	w13, #36320                     ; =0x8de0
	add	x13, x8, x13
	str	x13, [sp, #4416]                ; 8-byte Spill
	mov	w13, #36352                     ; =0x8e00
	add	x13, x8, x13
	str	x13, [sp, #4408]                ; 8-byte Spill
	mov	w13, #36384                     ; =0x8e20
	add	x13, x8, x13
	str	x13, [sp, #4400]                ; 8-byte Spill
	mov	w13, #36416                     ; =0x8e40
	add	x13, x8, x13
	str	x13, [sp, #4392]                ; 8-byte Spill
	mov	w13, #36448                     ; =0x8e60
	add	x13, x8, x13
	str	x13, [sp, #4384]                ; 8-byte Spill
	mov	w13, #36480                     ; =0x8e80
	add	x13, x8, x13
	str	x13, [sp, #4376]                ; 8-byte Spill
	mov	w13, #36512                     ; =0x8ea0
	add	x13, x8, x13
	str	x13, [sp, #4368]                ; 8-byte Spill
	mov	w13, #36544                     ; =0x8ec0
	add	x13, x8, x13
	str	x13, [sp, #4360]                ; 8-byte Spill
	mov	w13, #36576                     ; =0x8ee0
	add	x13, x8, x13
	str	x13, [sp, #4352]                ; 8-byte Spill
	mov	w13, #36608                     ; =0x8f00
	add	x13, x8, x13
	str	x13, [sp, #4344]                ; 8-byte Spill
	mov	w13, #36640                     ; =0x8f20
	add	x13, x8, x13
	str	x13, [sp, #4336]                ; 8-byte Spill
	mov	w13, #36672                     ; =0x8f40
	add	x13, x8, x13
	str	x13, [sp, #4328]                ; 8-byte Spill
	mov	w13, #36704                     ; =0x8f60
	add	x13, x8, x13
	str	x13, [sp, #4320]                ; 8-byte Spill
	mov	w13, #36736                     ; =0x8f80
	add	x13, x8, x13
	str	x13, [sp, #4312]                ; 8-byte Spill
	mov	w13, #36768                     ; =0x8fa0
	add	x13, x8, x13
	str	x13, [sp, #4304]                ; 8-byte Spill
	mov	w13, #36800                     ; =0x8fc0
	add	x13, x8, x13
	str	x13, [sp, #4296]                ; 8-byte Spill
	mov	w13, #36832                     ; =0x8fe0
	add	x13, x8, x13
	str	x13, [sp, #4288]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2048
	str	x13, [sp, #4280]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2080
	str	x13, [sp, #4272]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2112
	str	x13, [sp, #4264]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2144
	str	x13, [sp, #4256]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2176
	str	x13, [sp, #4248]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2208
	str	x13, [sp, #4240]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2240
	str	x13, [sp, #4232]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2272
	str	x13, [sp, #4224]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2304
	str	x13, [sp, #4216]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2336
	str	x13, [sp, #4208]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2368
	str	x13, [sp, #4200]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2400
	str	x13, [sp, #4192]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2432
	str	x13, [sp, #4184]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2464
	str	x13, [sp, #4176]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2496
	str	x13, [sp, #4168]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2528
	str	x13, [sp, #4160]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2560
	str	x13, [sp, #4152]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2592
	str	x13, [sp, #4144]                ; 8-byte Spill
	add	x13, x8, #16, lsl #12           ; =65536
	add	x7, x13, #2624
	add	x13, x8, #16, lsl #12           ; =65536
	add	x19, x13, #2656
	add	x13, x8, #16, lsl #12           ; =65536
	add	x20, x13, #2688
	add	x13, x8, #16, lsl #12           ; =65536
	add	x21, x13, #2720
	add	x13, x8, #16, lsl #12           ; =65536
	add	x23, x13, #2752
	add	x13, x8, #16, lsl #12           ; =65536
	add	x24, x13, #2784
	add	x13, x8, #16, lsl #12           ; =65536
	add	x25, x13, #2816
	add	x13, x8, #16, lsl #12           ; =65536
	add	x26, x13, #2848
	add	x13, x8, #16, lsl #12           ; =65536
	add	x27, x13, #2880
	add	x13, x8, #16, lsl #12           ; =65536
	add	x28, x13, #2912
	add	x13, x8, #16, lsl #12           ; =65536
	add	x30, x13, #2944
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #2976
	add	x14, x8, #16, lsl #12           ; =65536
	add	x0, x14, #3008
	add	x14, x8, #16, lsl #12           ; =65536
	add	x14, x14, #3040
	ldr	x15, [x17, #16]
	ldr	x16, [x17, #32]
	ldr	x17, [x17, #48]
	str	x17, [sp, #8]                   ; 8-byte Spill
	add	x17, x8, #2048
	str	q0, [sp, #10288]                ; 16-byte Spill
	str	q0, [sp, #10320]                ; 16-byte Spill
	str	q0, [sp, #10224]                ; 16-byte Spill
	str	q0, [sp, #10272]                ; 16-byte Spill
	str	q0, [sp, #10176]                ; 16-byte Spill
	str	q0, [sp, #10208]                ; 16-byte Spill
	str	q0, [sp, #10432]                ; 16-byte Spill
	str	q0, [sp, #10448]                ; 16-byte Spill
	str	q0, [sp, #10400]                ; 16-byte Spill
	str	q0, [sp, #10416]                ; 16-byte Spill
	str	q0, [sp, #10352]                ; 16-byte Spill
	str	q0, [sp, #10384]                ; 16-byte Spill
	str	q0, [sp, #10528]                ; 16-byte Spill
	str	q0, [sp, #10544]                ; 16-byte Spill
	str	q0, [sp, #10496]                ; 16-byte Spill
	str	q0, [sp, #10512]                ; 16-byte Spill
	str	q0, [sp, #10464]                ; 16-byte Spill
	str	q0, [sp, #10480]                ; 16-byte Spill
	str	q0, [sp, #10624]                ; 16-byte Spill
	str	q0, [sp, #10640]                ; 16-byte Spill
	str	q0, [sp, #10592]                ; 16-byte Spill
	str	q0, [sp, #10608]                ; 16-byte Spill
	str	q0, [sp, #10560]                ; 16-byte Spill
	str	q0, [sp, #10576]                ; 16-byte Spill
	str	q0, [sp, #10720]                ; 16-byte Spill
	str	q0, [sp, #10736]                ; 16-byte Spill
	str	q0, [sp, #10688]                ; 16-byte Spill
	str	q0, [sp, #10704]                ; 16-byte Spill
	str	q0, [sp, #10656]                ; 16-byte Spill
	str	q0, [sp, #10672]                ; 16-byte Spill
	str	q0, [sp, #10816]                ; 16-byte Spill
	str	q0, [sp, #10832]                ; 16-byte Spill
	str	q0, [sp, #10784]                ; 16-byte Spill
	str	q0, [sp, #10800]                ; 16-byte Spill
	str	q0, [sp, #10752]                ; 16-byte Spill
	str	q0, [sp, #10768]                ; 16-byte Spill
	str	q0, [sp, #10912]                ; 16-byte Spill
	str	q0, [sp, #10928]                ; 16-byte Spill
	str	q0, [sp, #10880]                ; 16-byte Spill
	str	q0, [sp, #10896]                ; 16-byte Spill
	str	q0, [sp, #10848]                ; 16-byte Spill
	str	q0, [sp, #10864]                ; 16-byte Spill
	str	q0, [sp, #11008]                ; 16-byte Spill
	str	q0, [sp, #11024]                ; 16-byte Spill
	str	q0, [sp, #10976]                ; 16-byte Spill
	str	q0, [sp, #10992]                ; 16-byte Spill
	str	q0, [sp, #10944]                ; 16-byte Spill
	str	q0, [sp, #10960]                ; 16-byte Spill
	str	q0, [sp, #11104]                ; 16-byte Spill
	str	q0, [sp, #11120]                ; 16-byte Spill
	str	q0, [sp, #11072]                ; 16-byte Spill
	str	q0, [sp, #11088]                ; 16-byte Spill
	str	q0, [sp, #11040]                ; 16-byte Spill
	str	q0, [sp, #11056]                ; 16-byte Spill
	str	q0, [sp, #11200]                ; 16-byte Spill
	str	q0, [sp, #11216]                ; 16-byte Spill
	str	q0, [sp, #11168]                ; 16-byte Spill
	str	q0, [sp, #11184]                ; 16-byte Spill
	str	q0, [sp, #11136]                ; 16-byte Spill
	str	q0, [sp, #11152]                ; 16-byte Spill
	str	q0, [sp, #11296]                ; 16-byte Spill
	str	q0, [sp, #11312]                ; 16-byte Spill
	str	q0, [sp, #11264]                ; 16-byte Spill
	str	q0, [sp, #11280]                ; 16-byte Spill
	str	q0, [sp, #11232]                ; 16-byte Spill
	str	q0, [sp, #11248]                ; 16-byte Spill
	str	q0, [sp, #11392]                ; 16-byte Spill
	str	q0, [sp, #11408]                ; 16-byte Spill
	str	q0, [sp, #11360]                ; 16-byte Spill
	str	q0, [sp, #11376]                ; 16-byte Spill
	str	q0, [sp, #11328]                ; 16-byte Spill
	str	q0, [sp, #11344]                ; 16-byte Spill
	str	q0, [sp, #11488]                ; 16-byte Spill
	str	q0, [sp, #11504]                ; 16-byte Spill
	str	q0, [sp, #11456]                ; 16-byte Spill
	str	q0, [sp, #11472]                ; 16-byte Spill
	str	q0, [sp, #11424]                ; 16-byte Spill
	str	q0, [sp, #11440]                ; 16-byte Spill
	str	q0, [sp, #11584]                ; 16-byte Spill
	str	q0, [sp, #11600]                ; 16-byte Spill
	str	q0, [sp, #11552]                ; 16-byte Spill
	str	q0, [sp, #11568]                ; 16-byte Spill
	str	q0, [sp, #11520]                ; 16-byte Spill
	str	q0, [sp, #11536]                ; 16-byte Spill
	str	q0, [sp, #11680]                ; 16-byte Spill
	str	q0, [sp, #11696]                ; 16-byte Spill
	str	q0, [sp, #11648]                ; 16-byte Spill
	str	q0, [sp, #11664]                ; 16-byte Spill
	str	q0, [sp, #11616]                ; 16-byte Spill
	str	q0, [sp, #11632]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v15, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v30, #0000000000000000
	str	q0, [sp, #9424]                 ; 16-byte Spill
	movi.2d	v31, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v4, #0000000000000000
	str	q0, [sp, #9648]                 ; 16-byte Spill
	movi.2d	v12, #0000000000000000
	str	q0, [sp, #9632]                 ; 16-byte Spill
	str	q0, [sp, #9616]                 ; 16-byte Spill
	str	q0, [sp, #9600]                 ; 16-byte Spill
	str	q0, [sp, #9584]                 ; 16-byte Spill
	str	q0, [sp, #9568]                 ; 16-byte Spill
	str	q0, [sp, #9552]                 ; 16-byte Spill
	str	q0, [sp, #9536]                 ; 16-byte Spill
	str	q0, [sp, #9408]                 ; 16-byte Spill
	str	q0, [sp, #9392]                 ; 16-byte Spill
	str	q0, [sp, #9376]                 ; 16-byte Spill
	str	q0, [sp, #9360]                 ; 16-byte Spill
	movi.2d	v1, #0000000000000000
	str	q0, [sp, #9344]                 ; 16-byte Spill
	str	q0, [sp, #9328]                 ; 16-byte Spill
	str	q0, [sp, #9312]                 ; 16-byte Spill
	str	q0, [sp, #9296]                 ; 16-byte Spill
	str	q0, [sp, #9280]                 ; 16-byte Spill
	str	q0, [sp, #9264]                 ; 16-byte Spill
	str	q0, [sp, #9248]                 ; 16-byte Spill
	str	q0, [sp, #9232]                 ; 16-byte Spill
	str	q0, [sp, #9216]                 ; 16-byte Spill
	str	q0, [sp, #9200]                 ; 16-byte Spill
	str	q0, [sp, #9184]                 ; 16-byte Spill
	str	q0, [sp, #9168]                 ; 16-byte Spill
	str	q0, [sp, #9152]                 ; 16-byte Spill
	str	q0, [sp, #9136]                 ; 16-byte Spill
	str	q0, [sp, #9120]                 ; 16-byte Spill
	str	q0, [sp, #9104]                 ; 16-byte Spill
	str	q0, [sp, #9088]                 ; 16-byte Spill
	str	q0, [sp, #9072]                 ; 16-byte Spill
	str	q0, [sp, #9056]                 ; 16-byte Spill
	str	q0, [sp, #9040]                 ; 16-byte Spill
	str	q0, [sp, #9024]                 ; 16-byte Spill
	str	q0, [sp, #9008]                 ; 16-byte Spill
	str	q0, [sp, #8992]                 ; 16-byte Spill
	str	q0, [sp, #8976]                 ; 16-byte Spill
	str	q0, [sp, #8960]                 ; 16-byte Spill
	str	q0, [sp, #8944]                 ; 16-byte Spill
	str	q0, [sp, #8928]                 ; 16-byte Spill
	str	q0, [sp, #8912]                 ; 16-byte Spill
	str	q0, [sp, #8896]                 ; 16-byte Spill
	str	q0, [sp, #8880]                 ; 16-byte Spill
	str	q0, [sp, #8864]                 ; 16-byte Spill
	str	q0, [sp, #8848]                 ; 16-byte Spill
	str	q0, [sp, #8832]                 ; 16-byte Spill
	str	q0, [sp, #8816]                 ; 16-byte Spill
	str	q0, [sp, #8800]                 ; 16-byte Spill
	str	q0, [sp, #8784]                 ; 16-byte Spill
	str	q0, [sp, #8768]                 ; 16-byte Spill
	str	q0, [sp, #8752]                 ; 16-byte Spill
	str	q0, [sp, #8736]                 ; 16-byte Spill
	str	q0, [sp, #8720]                 ; 16-byte Spill
	str	q0, [sp, #8704]                 ; 16-byte Spill
	str	q0, [sp, #8688]                 ; 16-byte Spill
	str	q0, [sp, #8672]                 ; 16-byte Spill
	str	q0, [sp, #8656]                 ; 16-byte Spill
	str	q0, [sp, #8640]                 ; 16-byte Spill
	str	q0, [sp, #8624]                 ; 16-byte Spill
	str	q0, [sp, #8608]                 ; 16-byte Spill
	str	q0, [sp, #8592]                 ; 16-byte Spill
	str	q0, [sp, #8576]                 ; 16-byte Spill
	str	q0, [sp, #8560]                 ; 16-byte Spill
	str	q0, [sp, #8544]                 ; 16-byte Spill
	str	q0, [sp, #8528]                 ; 16-byte Spill
	str	q0, [sp, #8512]                 ; 16-byte Spill
	str	q0, [sp, #8496]                 ; 16-byte Spill
	str	q0, [sp, #8480]                 ; 16-byte Spill
	str	q0, [sp, #8464]                 ; 16-byte Spill
	str	q0, [sp, #8448]                 ; 16-byte Spill
	str	q0, [sp, #8432]                 ; 16-byte Spill
	str	q0, [sp, #8416]                 ; 16-byte Spill
	str	q0, [sp, #8400]                 ; 16-byte Spill
	str	q0, [sp, #8384]                 ; 16-byte Spill
	str	q0, [sp, #8368]                 ; 16-byte Spill
	str	q0, [sp, #8352]                 ; 16-byte Spill
	str	q0, [sp, #8336]                 ; 16-byte Spill
	str	q0, [sp, #8320]                 ; 16-byte Spill
	str	q0, [sp, #8304]                 ; 16-byte Spill
	str	q0, [sp, #8288]                 ; 16-byte Spill
	str	q0, [sp, #8272]                 ; 16-byte Spill
	str	q0, [sp, #8256]                 ; 16-byte Spill
	str	q0, [sp, #8240]                 ; 16-byte Spill
	str	q0, [sp, #8224]                 ; 16-byte Spill
	str	q0, [sp, #8208]                 ; 16-byte Spill
	str	q0, [sp, #8192]                 ; 16-byte Spill
	str	q0, [sp, #8176]                 ; 16-byte Spill
	str	q0, [sp, #8160]                 ; 16-byte Spill
	str	q0, [sp, #8144]                 ; 16-byte Spill
	str	q0, [sp, #8128]                 ; 16-byte Spill
	str	q0, [sp, #8112]                 ; 16-byte Spill
	str	q0, [sp, #8096]                 ; 16-byte Spill
	str	q0, [sp, #8080]                 ; 16-byte Spill
	str	q0, [sp, #8064]                 ; 16-byte Spill
	str	q0, [sp, #8048]                 ; 16-byte Spill
	str	q0, [sp, #8032]                 ; 16-byte Spill
	str	q0, [sp, #8016]                 ; 16-byte Spill
	str	q0, [sp, #8000]                 ; 16-byte Spill
	str	q0, [sp, #7984]                 ; 16-byte Spill
	str	q0, [sp, #7968]                 ; 16-byte Spill
	str	q0, [sp, #7952]                 ; 16-byte Spill
	str	q0, [sp, #7936]                 ; 16-byte Spill
	str	q0, [sp, #7920]                 ; 16-byte Spill
	str	q0, [sp, #7904]                 ; 16-byte Spill
	str	q0, [sp, #7888]                 ; 16-byte Spill
	str	q0, [sp, #7872]                 ; 16-byte Spill
	str	q0, [sp, #7856]                 ; 16-byte Spill
	str	q0, [sp, #7840]                 ; 16-byte Spill
	str	q0, [sp, #7824]                 ; 16-byte Spill
	str	q0, [sp, #7808]                 ; 16-byte Spill
	str	q0, [sp, #7792]                 ; 16-byte Spill
	str	q0, [sp, #7776]                 ; 16-byte Spill
	str	q0, [sp, #7760]                 ; 16-byte Spill
	str	q0, [sp, #7744]                 ; 16-byte Spill
	str	q0, [sp, #7728]                 ; 16-byte Spill
	str	q0, [sp, #7712]                 ; 16-byte Spill
	str	q0, [sp, #7696]                 ; 16-byte Spill
	str	q0, [sp, #7680]                 ; 16-byte Spill
	str	q0, [sp, #7664]                 ; 16-byte Spill
	str	q0, [sp, #7648]                 ; 16-byte Spill
	str	q0, [sp, #7632]                 ; 16-byte Spill
	str	q0, [sp, #7616]                 ; 16-byte Spill
	str	q0, [sp, #7600]                 ; 16-byte Spill
	str	q0, [sp, #7584]                 ; 16-byte Spill
	str	q0, [sp, #7568]                 ; 16-byte Spill
	str	q0, [sp, #7552]                 ; 16-byte Spill
	str	q0, [sp, #7536]                 ; 16-byte Spill
	str	q0, [sp, #7520]                 ; 16-byte Spill
	str	q0, [sp, #7504]                 ; 16-byte Spill
	str	q0, [sp, #7488]                 ; 16-byte Spill
	str	q0, [sp, #7472]                 ; 16-byte Spill
	str	q0, [sp, #7456]                 ; 16-byte Spill
	str	q0, [sp, #7440]                 ; 16-byte Spill
	str	q0, [sp, #7424]                 ; 16-byte Spill
	str	q0, [sp, #7408]                 ; 16-byte Spill
	str	q0, [sp, #7392]                 ; 16-byte Spill
	str	q0, [sp, #7376]                 ; 16-byte Spill
	str	q0, [sp, #7360]                 ; 16-byte Spill
	str	q0, [sp, #7344]                 ; 16-byte Spill
	str	q0, [sp, #7328]                 ; 16-byte Spill
	str	q0, [sp, #9952]                 ; 16-byte Spill
	str	q0, [sp, #9920]                 ; 16-byte Spill
	str	q0, [sp, #9936]                 ; 16-byte Spill
	str	q0, [sp, #9888]                 ; 16-byte Spill
	str	q0, [sp, #9904]                 ; 16-byte Spill
	str	q0, [sp, #9856]                 ; 16-byte Spill
	str	q0, [sp, #9872]                 ; 16-byte Spill
	str	q0, [sp, #9824]                 ; 16-byte Spill
	str	q0, [sp, #9840]                 ; 16-byte Spill
	str	q0, [sp, #9792]                 ; 16-byte Spill
	str	q0, [sp, #9808]                 ; 16-byte Spill
	str	q0, [sp, #9760]                 ; 16-byte Spill
	str	q0, [sp, #9776]                 ; 16-byte Spill
	str	q0, [sp, #9728]                 ; 16-byte Spill
	str	q0, [sp, #9744]                 ; 16-byte Spill
	str	q0, [sp, #9696]                 ; 16-byte Spill
	str	q0, [sp, #9712]                 ; 16-byte Spill
	str	q0, [sp, #9664]                 ; 16-byte Spill
	str	q0, [sp, #9680]                 ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	movi.2d	v5, #0000000000000000
	str	q8, [sp, #4800]                 ; 16-byte Spill
LBB0_1027:                              ; %direct.true
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_1029 Depth 2
                                        ;     Child Loop BB0_1047 Depth 2
                                        ;     Child Loop BB0_1064 Depth 2
                                        ;     Child Loop BB0_1066 Depth 2
                                        ;     Child Loop BB0_1068 Depth 2
                                        ;     Child Loop BB0_1070 Depth 2
                                        ;     Child Loop BB0_1072 Depth 2
                                        ;     Child Loop BB0_1074 Depth 2
                                        ;     Child Loop BB0_1076 Depth 2
                                        ;     Child Loop BB0_1078 Depth 2
                                        ;     Child Loop BB0_1080 Depth 2
                                        ;     Child Loop BB0_1082 Depth 2
                                        ;     Child Loop BB0_1084 Depth 2
                                        ;     Child Loop BB0_1086 Depth 2
                                        ;     Child Loop BB0_1088 Depth 2
                                        ;     Child Loop BB0_1090 Depth 2
                                        ;     Child Loop BB0_1092 Depth 2
                                        ;     Child Loop BB0_1094 Depth 2
                                        ;     Child Loop BB0_1096 Depth 2
                                        ;     Child Loop BB0_1098 Depth 2
                                        ;     Child Loop BB0_1100 Depth 2
                                        ;     Child Loop BB0_1102 Depth 2
                                        ;     Child Loop BB0_1104 Depth 2
                                        ;     Child Loop BB0_1106 Depth 2
                                        ;     Child Loop BB0_1108 Depth 2
                                        ;     Child Loop BB0_1110 Depth 2
                                        ;     Child Loop BB0_1112 Depth 2
                                        ;     Child Loop BB0_1114 Depth 2
                                        ;     Child Loop BB0_1116 Depth 2
                                        ;     Child Loop BB0_1118 Depth 2
                                        ;     Child Loop BB0_1120 Depth 2
                                        ;     Child Loop BB0_1122 Depth 2
                                        ;     Child Loop BB0_1124 Depth 2
                                        ;     Child Loop BB0_1126 Depth 2
                                        ;     Child Loop BB0_1128 Depth 2
                                        ;     Child Loop BB0_1130 Depth 2
                                        ;     Child Loop BB0_1132 Depth 2
                                        ;     Child Loop BB0_1134 Depth 2
                                        ;     Child Loop BB0_1136 Depth 2
                                        ;     Child Loop BB0_1138 Depth 2
                                        ;     Child Loop BB0_1140 Depth 2
                                        ;     Child Loop BB0_1142 Depth 2
                                        ;     Child Loop BB0_1144 Depth 2
                                        ;     Child Loop BB0_1146 Depth 2
                                        ;     Child Loop BB0_1148 Depth 2
                                        ;     Child Loop BB0_1150 Depth 2
                                        ;     Child Loop BB0_1152 Depth 2
                                        ;     Child Loop BB0_1154 Depth 2
                                        ;     Child Loop BB0_1156 Depth 2
                                        ;     Child Loop BB0_1158 Depth 2
                                        ;     Child Loop BB0_1160 Depth 2
                                        ;     Child Loop BB0_1162 Depth 2
                                        ;     Child Loop BB0_1164 Depth 2
                                        ;     Child Loop BB0_1166 Depth 2
                                        ;     Child Loop BB0_1168 Depth 2
                                        ;     Child Loop BB0_1170 Depth 2
                                        ;     Child Loop BB0_1172 Depth 2
                                        ;     Child Loop BB0_1174 Depth 2
                                        ;     Child Loop BB0_1176 Depth 2
                                        ;     Child Loop BB0_1178 Depth 2
                                        ;     Child Loop BB0_1180 Depth 2
                                        ;     Child Loop BB0_1182 Depth 2
                                        ;     Child Loop BB0_1184 Depth 2
                                        ;     Child Loop BB0_1186 Depth 2
                                        ;     Child Loop BB0_1188 Depth 2
                                        ;     Child Loop BB0_1190 Depth 2
                                        ;     Child Loop BB0_1192 Depth 2
                                        ;     Child Loop BB0_1194 Depth 2
                                        ;     Child Loop BB0_1196 Depth 2
                                        ;     Child Loop BB0_1198 Depth 2
                                        ;     Child Loop BB0_1200 Depth 2
                                        ;     Child Loop BB0_1202 Depth 2
                                        ;     Child Loop BB0_1204 Depth 2
                                        ;     Child Loop BB0_1206 Depth 2
                                        ;     Child Loop BB0_1208 Depth 2
                                        ;     Child Loop BB0_1210 Depth 2
                                        ;     Child Loop BB0_1212 Depth 2
                                        ;     Child Loop BB0_1214 Depth 2
                                        ;     Child Loop BB0_1216 Depth 2
                                        ;     Child Loop BB0_1218 Depth 2
                                        ;     Child Loop BB0_1220 Depth 2
                                        ;     Child Loop BB0_1222 Depth 2
                                        ;     Child Loop BB0_1224 Depth 2
	str	q1, [sp, #11712]                ; 16-byte Spill
	str	q5, [sp, #7312]                 ; 16-byte Spill
	str	q6, [sp, #7296]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	lsl	x3, x11, #4
	ldr	q5, [sp, #4880]                 ; 16-byte Reload
	ldr	q7, [sp, #4816]                 ; 16-byte Reload
	mov.16b	v14, v8
	b	LBB0_1029
LBB0_1028:                              ; %else6355
                                        ;   in Loop: Header=BB0_1029 Depth=2
	add	x4, x17, x2, lsl #5
	ldp	q2, q3, [x4]
	bif.16b	v1, v3, v13
	bif.16b	v0, v2, v8
	mov.16b	v2, v8
	stp	q0, q1, [x4]
	add	x2, x2, #1
	add	x1, x1, #4
	cmp	x1, #1, lsl #12                 ; =4096
	b.eq	LBB0_1045
LBB0_1029:                              ; %direct.true557
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v8, v2
	mov.16b	v6, v4
	fmov	w4, s5
	orr	x5, x3, x2, lsr #6
	and	x6, x1, #0xfc
	orr	x5, x6, x5, lsl #8
	dup.2d	v2, x5
	orr.16b	v0, v2, v14
	dup.2d	v3, x15
	add.2d	v4, v3, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbnz	w4, #0, LBB0_1037
; %bb.1030:                             ; %else6313
                                        ;   in Loop: Header=BB0_1029 Depth=2
	and	w4, w4, #0xff
	tbnz	w4, #1, LBB0_1038
LBB0_1031:                              ; %else6319
                                        ;   in Loop: Header=BB0_1029 Depth=2
	ldr	q4, [sp, #11840]                ; 16-byte Reload
	orr.16b	v4, v2, v4
	add.2d	v4, v3, v4
	tbnz	w4, #2, LBB0_1039
LBB0_1032:                              ; %else6325
                                        ;   in Loop: Header=BB0_1029 Depth=2
	tbnz	w4, #3, LBB0_1040
LBB0_1033:                              ; %else6331
                                        ;   in Loop: Header=BB0_1029 Depth=2
	orr.16b	v4, v2, v7
	add.2d	v4, v3, v4
	tbnz	w4, #4, LBB0_1041
LBB0_1034:                              ; %else6337
                                        ;   in Loop: Header=BB0_1029 Depth=2
	tbnz	w4, #5, LBB0_1042
LBB0_1035:                              ; %else6343
                                        ;   in Loop: Header=BB0_1029 Depth=2
	mov.16b	v4, v6
	ldr	q11, [sp, #11824]               ; 16-byte Reload
	orr.16b	v2, v2, v11
	add.2d	v2, v3, v2
	tbnz	w4, #6, LBB0_1043
LBB0_1036:                              ; %else6349
                                        ;   in Loop: Header=BB0_1029 Depth=2
	tbz	w4, #7, LBB0_1028
	b	LBB0_1044
LBB0_1037:                              ; %cond.load6309
                                        ;   in Loop: Header=BB0_1029 Depth=2
	fmov	x5, d4
	ldr	s0, [x5]
	and	w4, w4, #0xff
	tbz	w4, #1, LBB0_1031
LBB0_1038:                              ; %cond.load6315
                                        ;   in Loop: Header=BB0_1029 Depth=2
	mov.d	x5, v4[1]
	ld1.s	{ v0 }[1], [x5]
	ldr	q4, [sp, #11840]                ; 16-byte Reload
	orr.16b	v4, v2, v4
	add.2d	v4, v3, v4
	tbz	w4, #2, LBB0_1032
LBB0_1039:                              ; %cond.load6321
                                        ;   in Loop: Header=BB0_1029 Depth=2
	fmov	x5, d4
	ld1.s	{ v0 }[2], [x5]
	tbz	w4, #3, LBB0_1033
LBB0_1040:                              ; %cond.load6327
                                        ;   in Loop: Header=BB0_1029 Depth=2
	mov.d	x5, v4[1]
	ld1.s	{ v0 }[3], [x5]
	orr.16b	v4, v2, v7
	add.2d	v4, v3, v4
	tbz	w4, #4, LBB0_1034
LBB0_1041:                              ; %cond.load6333
                                        ;   in Loop: Header=BB0_1029 Depth=2
	fmov	x5, d4
	ld1.s	{ v1 }[0], [x5]
	tbz	w4, #5, LBB0_1035
LBB0_1042:                              ; %cond.load6339
                                        ;   in Loop: Header=BB0_1029 Depth=2
	mov.d	x5, v4[1]
	ld1.s	{ v1 }[1], [x5]
	mov.16b	v4, v6
	ldr	q11, [sp, #11824]               ; 16-byte Reload
	orr.16b	v2, v2, v11
	add.2d	v2, v3, v2
	tbz	w4, #6, LBB0_1036
LBB0_1043:                              ; %cond.load6345
                                        ;   in Loop: Header=BB0_1029 Depth=2
	fmov	x5, d2
	ld1.s	{ v1 }[2], [x5]
	tbz	w4, #7, LBB0_1028
LBB0_1044:                              ; %cond.load6351
                                        ;   in Loop: Header=BB0_1029 Depth=2
	mov.d	x4, v2[1]
	ld1.s	{ v1 }[3], [x4]
	b	LBB0_1028
LBB0_1045:                              ; %direct.true576.preheader
                                        ;   in Loop: Header=BB0_1027 Depth=1
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	b	LBB0_1047
LBB0_1046:                              ; %else6404
                                        ;   in Loop: Header=BB0_1047 Depth=2
	add	x4, x9, x2, lsl #5
	ldp	q2, q3, [x4]
	bif.16b	v1, v3, v13
	bif.16b	v0, v2, v8
	stp	q0, q1, [x4]
	add	x2, x2, #1
	add	x1, x1, #4
	cmp	x1, #1, lsl #12                 ; =4096
	b.eq	LBB0_1063
LBB0_1047:                              ; %direct.true576
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w4, s5
	orr	x5, x3, x2, lsr #6
	and	x6, x1, #0xfc
	orr	x5, x6, x5, lsl #8
	dup.2d	v2, x5
	orr.16b	v0, v2, v14
	dup.2d	v3, x16
	add.2d	v4, v3, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbnz	w4, #0, LBB0_1055
; %bb.1048:                             ; %else6362
                                        ;   in Loop: Header=BB0_1047 Depth=2
	and	w4, w4, #0xff
	tbnz	w4, #1, LBB0_1056
LBB0_1049:                              ; %else6368
                                        ;   in Loop: Header=BB0_1047 Depth=2
	ldr	q4, [sp, #11840]                ; 16-byte Reload
	orr.16b	v4, v2, v4
	add.2d	v4, v3, v4
	tbnz	w4, #2, LBB0_1057
LBB0_1050:                              ; %else6374
                                        ;   in Loop: Header=BB0_1047 Depth=2
	tbnz	w4, #3, LBB0_1058
LBB0_1051:                              ; %else6380
                                        ;   in Loop: Header=BB0_1047 Depth=2
	orr.16b	v4, v2, v7
	add.2d	v4, v3, v4
	tbnz	w4, #4, LBB0_1059
LBB0_1052:                              ; %else6386
                                        ;   in Loop: Header=BB0_1047 Depth=2
	tbnz	w4, #5, LBB0_1060
LBB0_1053:                              ; %else6392
                                        ;   in Loop: Header=BB0_1047 Depth=2
	ldr	q4, [sp, #11824]                ; 16-byte Reload
	orr.16b	v2, v2, v4
	add.2d	v2, v3, v2
	tbnz	w4, #6, LBB0_1061
LBB0_1054:                              ; %else6398
                                        ;   in Loop: Header=BB0_1047 Depth=2
	tbz	w4, #7, LBB0_1046
	b	LBB0_1062
LBB0_1055:                              ; %cond.load6358
                                        ;   in Loop: Header=BB0_1047 Depth=2
	fmov	x5, d4
	ldr	s0, [x5]
	and	w4, w4, #0xff
	tbz	w4, #1, LBB0_1049
LBB0_1056:                              ; %cond.load6364
                                        ;   in Loop: Header=BB0_1047 Depth=2
	mov.d	x5, v4[1]
	ld1.s	{ v0 }[1], [x5]
	ldr	q4, [sp, #11840]                ; 16-byte Reload
	orr.16b	v4, v2, v4
	add.2d	v4, v3, v4
	tbz	w4, #2, LBB0_1050
LBB0_1057:                              ; %cond.load6370
                                        ;   in Loop: Header=BB0_1047 Depth=2
	fmov	x5, d4
	ld1.s	{ v0 }[2], [x5]
	tbz	w4, #3, LBB0_1051
LBB0_1058:                              ; %cond.load6376
                                        ;   in Loop: Header=BB0_1047 Depth=2
	mov.d	x5, v4[1]
	ld1.s	{ v0 }[3], [x5]
	orr.16b	v4, v2, v7
	add.2d	v4, v3, v4
	tbz	w4, #4, LBB0_1052
LBB0_1059:                              ; %cond.load6382
                                        ;   in Loop: Header=BB0_1047 Depth=2
	fmov	x5, d4
	ld1.s	{ v1 }[0], [x5]
	tbz	w4, #5, LBB0_1053
LBB0_1060:                              ; %cond.load6388
                                        ;   in Loop: Header=BB0_1047 Depth=2
	mov.d	x5, v4[1]
	ld1.s	{ v1 }[1], [x5]
	ldr	q4, [sp, #11824]                ; 16-byte Reload
	orr.16b	v2, v2, v4
	add.2d	v2, v3, v2
	tbz	w4, #6, LBB0_1054
LBB0_1061:                              ; %cond.load6394
                                        ;   in Loop: Header=BB0_1047 Depth=2
	fmov	x5, d2
	ld1.s	{ v1 }[2], [x5]
	tbz	w4, #7, LBB0_1046
LBB0_1062:                              ; %cond.load6400
                                        ;   in Loop: Header=BB0_1047 Depth=2
	mov.d	x4, v2[1]
	ld1.s	{ v1 }[3], [x4]
	b	LBB0_1046
LBB0_1063:                              ; %direct.false577
                                        ;   in Loop: Header=BB0_1027 Depth=1
	mov.16b	v2, v8
	ldr	q0, [sp, #4864]                 ; 16-byte Reload
	ldr	q1, [sp, #4832]                 ; 16-byte Reload
	cmhs.4s	v8, v1, v0
	and.16b	v22, v8, v22
	ldr	q1, [sp, #4848]                 ; 16-byte Reload
	cmhs.4s	v11, v1, v0
	and.16b	v21, v11, v21
	mov	w1, #64                         ; =0x40
	mov	x2, x8
LBB0_1064:                              ; %direct.true597
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x2]
	ldr	q4, [x2, #2048]
	ldr	q5, [x2, #2064]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v21, v0
	fadd.4s	v1, v22, v1
	bit.16b	v22, v1, v13
	bit.16b	v21, v0, v2
	add	x2, x2, #32
	subs	x1, x1, #1
	b.ne	LBB0_1064
; %bb.1065:                             ; %direct.false598
                                        ;   in Loop: Header=BB0_1027 Depth=1
	and.16b	v20, v8, v20
	and.16b	v19, v11, v19
	mov	x1, x8
	mov	w2, #64                         ; =0x40
	ldr	q7, [sp, #9424]                 ; 16-byte Reload
LBB0_1066:                              ; %direct.true612
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #4096]
	ldr	q5, [x1, #4112]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v19, v0
	fadd.4s	v1, v20, v1
	bit.16b	v20, v1, v13
	bit.16b	v19, v0, v2
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1066
; %bb.1067:                             ; %direct.false613
                                        ;   in Loop: Header=BB0_1027 Depth=1
	and.16b	v18, v8, v18
	and.16b	v17, v11, v17
	mov	x1, x8
	mov	w2, #64                         ; =0x40
	ldr	q3, [sp, #9536]                 ; 16-byte Reload
LBB0_1068:                              ; %direct.true629
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #6144]
	ldr	q5, [x1, #6160]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v17, v0
	fadd.4s	v1, v18, v1
	bit.16b	v18, v1, v13
	bit.16b	v17, v0, v2
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1068
; %bb.1069:                             ; %direct.false630
                                        ;   in Loop: Header=BB0_1027 Depth=1
	and.16b	v29, v8, v29
	and.16b	v27, v11, v27
	mov	x1, x8
	mov	w2, #64                         ; =0x40
LBB0_1070:                              ; %direct.true646
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #8192]
	ldr	q5, [x1, #8208]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v27, v0
	fadd.4s	v1, v29, v1
	bit.16b	v29, v1, v13
	bit.16b	v27, v0, v2
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1070
; %bb.1071:                             ; %direct.false647
                                        ;   in Loop: Header=BB0_1027 Depth=1
	and.16b	v26, v8, v26
	and.16b	v25, v11, v25
	mov	x1, x8
	mov	w2, #64                         ; =0x40
LBB0_1072:                              ; %direct.true663
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #10240]
	ldr	q5, [x1, #10256]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v25, v0
	fadd.4s	v1, v26, v1
	bit.16b	v26, v1, v13
	bit.16b	v25, v0, v2
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1072
; %bb.1073:                             ; %direct.false664
                                        ;   in Loop: Header=BB0_1027 Depth=1
	and.16b	v24, v8, v24
	and.16b	v23, v11, v23
	mov	x1, x8
	mov	w2, #64                         ; =0x40
LBB0_1074:                              ; %direct.true680
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #12288]
	ldr	q5, [x1, #12304]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v23, v0
	fadd.4s	v1, v24, v1
	bit.16b	v24, v1, v13
	bit.16b	v23, v0, v2
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1074
; %bb.1075:                             ; %direct.false681
                                        ;   in Loop: Header=BB0_1027 Depth=1
	and.16b	v31, v8, v31
	and.16b	v7, v11, v7
	mov	x1, x8
	mov	w2, #64                         ; =0x40
LBB0_1076:                              ; %direct.true697
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #14336]
	ldr	q5, [x1, #14352]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v7, v0
	fadd.4s	v1, v31, v1
	bit.16b	v31, v1, v13
	bit.16b	v7, v0, v2
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1076
; %bb.1077:                             ; %direct.false698
                                        ;   in Loop: Header=BB0_1027 Depth=1
	and.16b	v30, v8, v30
	and.16b	v28, v11, v28
	mov	x1, x8
	mov	w2, #64                         ; =0x40
LBB0_1078:                              ; %direct.true714
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #16384]
	ldr	q5, [x1, #16400]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v28, v0
	fadd.4s	v1, v30, v1
	bit.16b	v30, v1, v13
	bit.16b	v28, v0, v2
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1078
; %bb.1079:                             ; %direct.false715
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q8, [sp, #11808]                ; 16-byte Spill
	and.16b	v15, v8, v15
	and.16b	v9, v11, v9
	mov	x1, x8
	mov	w2, #64                         ; =0x40
LBB0_1080:                              ; %direct.true731
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #18432]
	ldr	q5, [x1, #18448]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v9, v0
	fadd.4s	v1, v15, v1
	bit.16b	v15, v1, v13
	bit.16b	v9, v0, v2
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1080
; %bb.1081:                             ; %direct.false732
                                        ;   in Loop: Header=BB0_1027 Depth=1
	mov.16b	v8, v2
	ldr	q2, [sp, #9632]                 ; 16-byte Reload
	ldr	q0, [sp, #11808]                ; 16-byte Reload
	and.16b	v2, v0, v2
	and.16b	v12, v11, v12
	mov	x1, x8
	mov	w2, #64                         ; =0x40
LBB0_1082:                              ; %direct.true748
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #20480]
	ldr	q5, [x1, #20496]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v12, v0
	fadd.4s	v1, v2, v1
	bit.16b	v2, v1, v13
	bit.16b	v12, v0, v8
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1082
; %bb.1083:                             ; %direct.false749
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q2, [sp, #9632]                 ; 16-byte Spill
	str	q12, [sp, #9440]                ; 16-byte Spill
	ldr	q12, [sp, #9648]                ; 16-byte Reload
	ldr	q0, [sp, #11808]                ; 16-byte Reload
	and.16b	v12, v0, v12
	and.16b	v6, v11, v6
	mov	x1, x8
	mov	w2, #64                         ; =0x40
LBB0_1084:                              ; %direct.true765
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #22528]
	ldr	q5, [x1, #22544]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v6, v0
	fadd.4s	v1, v12, v1
	bit.16b	v12, v1, v13
	bit.16b	v6, v0, v8
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1084
; %bb.1085:                             ; %direct.false766
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q12, [sp, #9648]                ; 16-byte Spill
	str	q6, [sp, #9456]                 ; 16-byte Spill
	ldr	q0, [sp, #11808]                ; 16-byte Reload
	and.16b	v10, v0, v10
	and.16b	v16, v11, v16
	mov	x1, x8
	mov	w2, #64                         ; =0x40
	ldr	q2, [sp, #9616]                 ; 16-byte Reload
LBB0_1086:                              ; %direct.true782
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #24576]
	ldr	q5, [x1, #24592]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v16, v0
	fadd.4s	v1, v10, v1
	bit.16b	v10, v1, v13
	bit.16b	v16, v0, v8
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1086
; %bb.1087:                             ; %direct.false783
                                        ;   in Loop: Header=BB0_1027 Depth=1
	ldr	q0, [sp, #11808]                ; 16-byte Reload
	and.16b	v3, v0, v3
	ldr	q12, [sp, #9552]                ; 16-byte Reload
	str	q11, [sp, #11760]               ; 16-byte Spill
	and.16b	v12, v11, v12
	mov	x1, x8
	mov	w2, #64                         ; =0x40
	ldr	q6, [sp, #9600]                 ; 16-byte Reload
	ldr	q11, [sp, #9568]                ; 16-byte Reload
LBB0_1088:                              ; %direct.true799
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #26624]
	ldr	q5, [x1, #26640]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v12, v0
	fadd.4s	v1, v3, v1
	bit.16b	v3, v1, v13
	bit.16b	v12, v0, v8
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1088
; %bb.1089:                             ; %direct.false800
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q3, [sp, #9536]                 ; 16-byte Spill
	str	q12, [sp, #9552]                ; 16-byte Spill
	ldr	q0, [sp, #11808]                ; 16-byte Reload
	and.16b	v3, v0, v11
	ldr	q12, [sp, #9584]                ; 16-byte Reload
	ldr	q11, [sp, #11760]               ; 16-byte Reload
	and.16b	v12, v11, v12
	mov	x1, x8
	mov	w2, #64                         ; =0x40
LBB0_1090:                              ; %direct.true816
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #28672]
	ldr	q5, [x1, #28688]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v12, v0
	fadd.4s	v1, v3, v1
	bit.16b	v3, v1, v13
	bit.16b	v12, v0, v8
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1090
; %bb.1091:                             ; %direct.false817
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q3, [sp, #9568]                 ; 16-byte Spill
	str	q12, [sp, #9584]                ; 16-byte Spill
	ldr	q0, [sp, #11808]                ; 16-byte Reload
	and.16b	v6, v0, v6
	and.16b	v2, v11, v2
	mov	x1, x8
	mov	w2, #64                         ; =0x40
	ldr	q11, [sp, #11712]               ; 16-byte Reload
LBB0_1092:                              ; %direct.true833
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q4, [x1, #30720]
	ldr	q5, [x1, #30736]
	fmul.4s	v1, v1, v5
	fmul.4s	v0, v0, v4
	fadd.4s	v0, v2, v0
	fadd.4s	v1, v6, v1
	bit.16b	v6, v1, v13
	bit.16b	v2, v0, v8
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1092
; %bb.1093:                             ; %direct.false834
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q6, [sp, #9600]                 ; 16-byte Spill
	str	q2, [sp, #9616]                 ; 16-byte Spill
	str	q10, [sp, #9472]                ; 16-byte Spill
	str	q16, [sp, #9488]                ; 16-byte Spill
	str	q31, [sp, #9504]                ; 16-byte Spill
	str	q30, [sp, #9520]                ; 16-byte Spill
	ldr	q4, [sp, #9344]                 ; 16-byte Reload
	ldr	q0, [sp, #11808]                ; 16-byte Reload
	and.16b	v4, v0, v4
	ldr	q0, [sp, #11760]                ; 16-byte Reload
	and.16b	v11, v0, v11
	mov	x1, x8
	mov	w2, #64                         ; =0x40
	ldr	q12, [sp, #9568]                ; 16-byte Reload
LBB0_1094:                              ; %direct.true850
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x1]
	ldr	q2, [x1, #32768]
	ldr	q3, [x1, #32784]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v11, v0
	fadd.4s	v1, v4, v1
	bit.16b	v4, v1, v13
	bit.16b	v11, v0, v8
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_1094
; %bb.1095:                             ; %direct.false851
                                        ;   in Loop: Header=BB0_1027 Depth=1
	mov	x1, #0                          ; =0x0
	movi.4s	v16, #62, lsl #24
	str	q21, [sp, #7216]                ; 16-byte Spill
	fmul.4s	v3, v21, v16
	str	q22, [sp, #7200]                ; 16-byte Spill
	fmul.4s	v6, v22, v16
	ldr	x2, [sp, #4280]                 ; 8-byte Reload
	mov.16b	v21, v4
	ldp	q2, q4, [x2]
	str	q19, [sp, #7248]                ; 16-byte Spill
	fmul.4s	v1, v19, v16
	str	q20, [sp, #7232]                ; 16-byte Spill
	fmul.4s	v0, v20, v16
	bit.16b	v4, v6, v13
	bit.16b	v2, v3, v8
	stp	q2, q4, [x2]
	str	q17, [sp, #7280]                ; 16-byte Spill
	fmul.4s	v10, v17, v16
	str	q18, [sp, #7264]                ; 16-byte Spill
	fmul.4s	v5, v18, v16
	str	q27, [sp, #7120]                ; 16-byte Spill
	fmul.4s	v31, v27, v16
	ldr	x2, [sp, #4272]                 ; 8-byte Reload
	ldp	q2, q4, [x2]
	str	q29, [sp, #7104]                ; 16-byte Spill
	fmul.4s	v27, v29, v16
	bit.16b	v4, v0, v13
	bit.16b	v2, v1, v8
	stp	q2, q4, [x2]
	str	q25, [sp, #7152]                ; 16-byte Spill
	fmul.4s	v22, v25, v16
	str	q26, [sp, #7136]                ; 16-byte Spill
	fmul.4s	v20, v26, v16
	str	q23, [sp, #7184]                ; 16-byte Spill
	fmul.4s	v18, v23, v16
	ldr	x2, [sp, #4264]                 ; 8-byte Reload
	ldp	q2, q4, [x2]
	str	q24, [sp, #7168]                ; 16-byte Spill
	fmul.4s	v17, v24, v16
	str	q5, [sp, #6880]                 ; 16-byte Spill
	bit.16b	v4, v5, v13
	bit.16b	v2, v10, v8
	stp	q2, q4, [x2]
	str	q7, [sp, #9424]                 ; 16-byte Spill
	fmul.4s	v30, v7, v16
	ldr	q2, [sp, #9504]                 ; 16-byte Reload
	fmul.4s	v4, v2, v16
	str	q28, [sp, #7056]                ; 16-byte Spill
	fmul.4s	v29, v28, v16
	ldr	x2, [sp, #4256]                 ; 8-byte Reload
	ldp	q5, q7, [x2]
	ldr	q2, [sp, #9520]                 ; 16-byte Reload
	fmul.4s	v19, v2, v16
	str	q27, [sp, #6784]                ; 16-byte Spill
	bit.16b	v7, v27, v13
	str	q31, [sp, #6768]                ; 16-byte Spill
	bit.16b	v5, v31, v8
	stp	q5, q7, [x2]
	str	q9, [sp, #7088]                 ; 16-byte Spill
	fmul.4s	v14, v9, v16
	str	q15, [sp, #7072]                ; 16-byte Spill
	fmul.4s	v9, v15, v16
	ldr	q2, [sp, #9632]                 ; 16-byte Reload
	fmul.4s	v28, v2, v16
	ldr	x2, [sp, #4248]                 ; 8-byte Reload
	ldp	q5, q7, [x2]
	ldr	q2, [sp, #9440]                 ; 16-byte Reload
	fmul.4s	v27, v2, v16
	str	q20, [sp, #6688]                ; 16-byte Spill
	bit.16b	v7, v20, v13
	str	q22, [sp, #6672]                ; 16-byte Spill
	bit.16b	v5, v22, v8
	stp	q5, q7, [x2]
	ldr	q2, [sp, #9648]                 ; 16-byte Reload
	fmul.4s	v26, v2, v16
	ldr	q2, [sp, #9456]                 ; 16-byte Reload
	fmul.4s	v25, v2, v16
	ldr	q2, [sp, #9472]                 ; 16-byte Reload
	fmul.4s	v24, v2, v16
	ldr	x2, [sp, #4240]                 ; 8-byte Reload
	ldp	q5, q7, [x2]
	ldr	q2, [sp, #9488]                 ; 16-byte Reload
	fmul.4s	v23, v2, v16
	str	q17, [sp, #6592]                ; 16-byte Spill
	bit.16b	v7, v17, v13
	str	q18, [sp, #6576]                ; 16-byte Spill
	bit.16b	v5, v18, v8
	stp	q5, q7, [x2]
	ldr	q2, [sp, #9536]                 ; 16-byte Reload
	fmul.4s	v22, v2, v16
	ldr	q2, [sp, #9552]                 ; 16-byte Reload
	fmul.4s	v20, v2, v16
	ldr	q2, [sp, #9584]                 ; 16-byte Reload
	fmul.4s	v18, v2, v16
	ldr	x2, [sp, #4232]                 ; 8-byte Reload
	ldp	q5, q7, [x2]
	fmul.4s	v17, v12, v16
	str	q4, [sp, #6496]                 ; 16-byte Spill
	bit.16b	v7, v4, v13
	str	q30, [sp, #6480]                ; 16-byte Spill
	bit.16b	v5, v30, v8
	stp	q5, q7, [x2]
	ldr	q2, [sp, #9600]                 ; 16-byte Reload
	fmul.4s	v4, v2, v16
	ldr	q2, [sp, #9616]                 ; 16-byte Reload
	fmul.4s	v2, v2, v16
	ldr	x2, [sp, #4224]                 ; 8-byte Reload
	ldp	q5, q7, [x2]
	str	q19, [sp, #6400]                ; 16-byte Spill
	bit.16b	v7, v19, v13
	str	q29, [sp, #6384]                ; 16-byte Spill
	bit.16b	v5, v29, v8
	stp	q5, q7, [x2]
	ldr	x2, [sp, #4216]                 ; 8-byte Reload
	ldp	q5, q7, [x2]
	str	q9, [sp, #6336]                 ; 16-byte Spill
	bit.16b	v7, v9, v13
	str	q14, [sp, #6320]                ; 16-byte Spill
	bit.16b	v5, v14, v8
	stp	q5, q7, [x2]
	ldr	x2, [sp, #4208]                 ; 8-byte Reload
	ldp	q7, q5, [x2]
	str	q27, [sp, #6432]                ; 16-byte Spill
	bit.16b	v7, v27, v8
	str	q28, [sp, #6416]                ; 16-byte Spill
	bit.16b	v5, v28, v13
	stp	q7, q5, [x2]
	ldr	x2, [sp, #4200]                 ; 8-byte Reload
	ldp	q7, q5, [x2]
	str	q25, [sp, #6528]                ; 16-byte Spill
	bit.16b	v7, v25, v8
	str	q26, [sp, #6512]                ; 16-byte Spill
	bit.16b	v5, v26, v13
	stp	q7, q5, [x2]
	ldr	x2, [sp, #4192]                 ; 8-byte Reload
	ldp	q7, q5, [x2]
	str	q23, [sp, #6624]                ; 16-byte Spill
	bit.16b	v7, v23, v8
	str	q24, [sp, #6608]                ; 16-byte Spill
	bit.16b	v5, v24, v13
	stp	q7, q5, [x2]
	ldr	x2, [sp, #4184]                 ; 8-byte Reload
	ldp	q7, q5, [x2]
	str	q20, [sp, #6720]                ; 16-byte Spill
	bit.16b	v7, v20, v8
	str	q22, [sp, #6704]                ; 16-byte Spill
	bit.16b	v5, v22, v13
	stp	q7, q5, [x2]
	ldr	x2, [sp, #4176]                 ; 8-byte Reload
	ldp	q5, q7, [x2]
	str	q17, [sp, #6816]                ; 16-byte Spill
	bit.16b	v7, v17, v13
	str	q18, [sp, #6800]                ; 16-byte Spill
	bit.16b	v5, v18, v8
	stp	q5, q7, [x2]
	ldr	x2, [sp, #4168]                 ; 8-byte Reload
	ldp	q7, q5, [x2]
	str	q2, [sp, #6912]                 ; 16-byte Spill
	bit.16b	v7, v2, v8
	str	q4, [sp, #6896]                 ; 16-byte Spill
	bit.16b	v5, v4, v13
	stp	q7, q5, [x2]
	str	q11, [sp, #11712]               ; 16-byte Spill
	fmul.4s	v2, v11, v16
	ldr	x2, [sp, #4160]                 ; 8-byte Reload
	ldp	q5, q7, [x2]
	str	q2, [sp, #7040]                 ; 16-byte Spill
	bit.16b	v5, v2, v8
	str	q21, [sp, #9344]                ; 16-byte Spill
	fmul.4s	v2, v21, v16
	str	q2, [sp, #7024]                 ; 16-byte Spill
	bit.16b	v7, v2, v13
	stp	q5, q7, [x2]
	mvni.4s	v5, #127, msl #16
	ldr	q17, [sp, #9360]                ; 16-byte Reload
	bit.16b	v17, v5, v13
	mvni.4s	v2, #127, msl #16
	ldr	q16, [sp, #9376]                ; 16-byte Reload
	bit.16b	v16, v5, v8
LBB0_1096:                              ; %direct.true964
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, x12, x1
	ldp	q5, q7, [x2]
	and.16b	v7, v13, v7
	and.16b	v5, v8, v5
	fmaxnm.4s	v5, v16, v5
	fmaxnm.4s	v7, v17, v7
	bit.16b	v17, v7, v13
	bit.16b	v16, v5, v8
	add	x1, x1, #32
	cmp	x1, #512
	b.ne	LBB0_1096
; %bb.1097:                             ; %direct.false965
                                        ;   in Loop: Header=BB0_1027 Depth=1
	mov	x1, #0                          ; =0x0
	str	q16, [sp, #9376]                ; 16-byte Spill
	ldr	q5, [sp, #11728]                ; 16-byte Reload
	fmaxnm.4s	v4, v5, v16
	fsub.4s	v3, v3, v4
	and.16b	v28, v8, v3
	mov	w2, #-1026555904                ; =0xc2d00000
	dup.4s	v5, w2
	fcmge.4s	v7, v28, v5
	mov	w2, #1120403456                 ; =0x42c80000
	dup.4s	v3, w2
	fcmge.4s	v16, v3, v28
	and.16b	v7, v7, v16
	str	q17, [sp, #9360]                ; 16-byte Spill
	ldr	q16, [sp, #11744]               ; 16-byte Reload
	fmaxnm.4s	v27, v16, v17
	fsub.4s	v6, v6, v27
	and.16b	v14, v13, v6
	fcmge.4s	v6, v14, v5
	fcmge.4s	v16, v3, v14
	and.16b	v16, v6, v16
	mov	w2, #43579                      ; =0xaa3b
	movk	w2, #16312, lsl #16
	dup.4s	v25, w2
	and.16b	v16, v16, v14
	fmul.4s	v17, v16, v25
	movi.4s	v20, #75, lsl #24
	mvni.4s	v21, #128, lsl #24
	mov.16b	v18, v21
	bsl.16b	v18, v20, v17
	fadd.4s	v17, v17, v18
	fsub.4s	v17, v17, v18
	and.16b	v18, v7, v28
	fmul.4s	v7, v18, v25
	bif.16b	v20, v7, v21
	fadd.4s	v7, v7, v20
	fsub.4s	v20, v7, v20
	fcvtzs.4s	v24, v17
	scvtf.4s	v17, v24
	mov	w2, #29184                      ; =0x7200
	movk	w2, #16177, lsl #16
	dup.4s	v7, w2
	fmul.4s	v21, v17, v7
	fsub.4s	v21, v16, v21
	fcvtzs.4s	v11, v20
	scvtf.4s	v20, v11
	fmul.4s	v16, v20, v7
	fsub.4s	v18, v18, v16
	mov	w2, #48782                      ; =0xbe8e
	movk	w2, #13759, lsl #16
	dup.4s	v16, w2
	fmul.4s	v20, v20, v16
	fsub.4s	v12, v18, v20
	fmul.4s	v17, v17, v16
	fsub.4s	v13, v21, v17
	mov	w2, #11226                      ; =0x2bda
	movk	w2, #14672, lsl #16
	dup.4s	v17, w2
	mov	w2, #38601                      ; =0x96c9
	movk	w2, #15030, lsl #16
	dup.4s	v18, w2
	fmul.4s	v20, v13, v17
	fadd.4s	v20, v20, v18
	fmul.4s	v21, v13, v20
	mov	w2, #34982                      ; =0x88a6
	movk	w2, #15368, lsl #16
	dup.4s	v20, w2
	fadd.4s	v21, v21, v20
	fmul.4s	v22, v13, v21
	mov	w2, #43642                      ; =0xaa7a
	movk	w2, #15658, lsl #16
	dup.4s	v6, w2
	fadd.4s	v15, v22, v6
	mov	w2, #43691                      ; =0xaaab
	movk	w2, #15914, lsl #16
	dup.4s	v22, w2
	fmul.4s	v15, v13, v15
	fadd.4s	v15, v15, v22
	fmul.4s	v15, v13, v15
	movi.4s	v21, #63, lsl #24
	fadd.4s	v15, v15, v21
	movi.4s	v26, #63, lsl #24
	fmul.4s	v23, v13, v13
	fmul.4s	v23, v23, v15
	fmul.4s	v15, v12, v17
	fadd.4s	v15, v15, v18
	fmul.4s	v15, v12, v15
	fadd.4s	v15, v15, v20
	fmul.4s	v15, v12, v15
	fadd.4s	v15, v15, v6
	fmul.4s	v15, v12, v15
	fadd.4s	v15, v15, v22
	fmul.4s	v15, v12, v15
	fadd.4s	v15, v15, v26
	fmul.4s	v9, v12, v12
	fmul.4s	v9, v9, v15
	fadd.4s	v9, v12, v9
	fadd.4s	v23, v13, v23
	fmov.4s	v21, #1.00000000
	fadd.4s	v9, v9, v21
	sshr.4s	v12, v11, #1
	shl.4s	v13, v12, #23
	add.4s	v13, v13, v21
	fmul.4s	v9, v9, v13
	fadd.4s	v23, v23, v21
	sshr.4s	v13, v24, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v21
	fmul.4s	v23, v23, v15
	sub.4s	v11, v11, v12
	sub.4s	v24, v24, v13
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v21
	fmul.4s	v23, v23, v24
	shl.4s	v24, v11, #23
	add.4s	v24, v24, v21
	fmul.4s	v24, v9, v24
	str	q28, [sp, #6992]                ; 16-byte Spill
	fcmgt.4s	v9, v5, v28
	bic.16b	v9, v24, v9
	str	q14, [sp, #11808]               ; 16-byte Spill
	fcmgt.4s	v24, v5, v14
	bic.16b	v23, v23, v24
	fcmgt.4s	v11, v14, v3
	fneg.4s	v24, v2
	mov.16b	v2, v11
	bsl.16b	v2, v24, v23
	str	q2, [sp, #11760]                ; 16-byte Spill
	fcmgt.4s	v23, v28, v3
	mov.16b	v2, v23
	bsl.16b	v2, v24, v9
	str	q2, [sp, #7008]                 ; 16-byte Spill
	fsub.4s	v1, v1, v4
	and.16b	v14, v8, v1
	fcmge.4s	v1, v14, v5
	fcmge.4s	v23, v3, v14
	and.16b	v1, v1, v23
	fsub.4s	v0, v0, v27
	ldr	q23, [sp, #11792]               ; 16-byte Reload
	and.16b	v15, v23, v0
	fcmge.4s	v0, v15, v5
	fcmge.4s	v23, v3, v15
	and.16b	v0, v0, v23
	and.16b	v23, v0, v15
	fmul.4s	v0, v23, v25
	movi.4s	v2, #75, lsl #24
	mvni.4s	v28, #128, lsl #24
	mov.16b	v9, v28
	bsl.16b	v9, v2, v0
	fadd.4s	v0, v0, v9
	fsub.4s	v0, v0, v9
	and.16b	v1, v1, v14
	fmul.4s	v9, v1, v25
	mov.16b	v11, v28
	bsl.16b	v11, v2, v9
	fadd.4s	v9, v9, v11
	fsub.4s	v9, v9, v11
	fcvtzs.4s	v0, v0
	scvtf.4s	v11, v0
	fmul.4s	v12, v11, v7
	fsub.4s	v23, v23, v12
	fcvtzs.4s	v9, v9
	scvtf.4s	v12, v9
	fmul.4s	v13, v12, v7
	fsub.4s	v1, v1, v13
	fmul.4s	v12, v12, v16
	fsub.4s	v1, v1, v12
	fmul.4s	v11, v11, v16
	fsub.4s	v23, v23, v11
	fmul.4s	v11, v23, v17
	fadd.4s	v11, v11, v18
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v20
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v6
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v22
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v26
	fmul.4s	v12, v23, v23
	fmul.4s	v11, v12, v11
	fmul.4s	v12, v1, v17
	fadd.4s	v12, v12, v18
	fmul.4s	v12, v1, v12
	fadd.4s	v12, v12, v20
	fmul.4s	v12, v1, v12
	fadd.4s	v12, v12, v6
	fmul.4s	v12, v1, v12
	fadd.4s	v12, v12, v22
	fmul.4s	v12, v1, v12
	fadd.4s	v12, v12, v26
	fmul.4s	v13, v1, v1
	fmul.4s	v12, v13, v12
	fadd.4s	v1, v1, v12
	fadd.4s	v23, v23, v11
	fadd.4s	v1, v1, v21
	sshr.4s	v11, v9, #1
	shl.4s	v12, v11, #23
	add.4s	v12, v12, v21
	fmul.4s	v1, v1, v12
	fadd.4s	v23, v23, v21
	sshr.4s	v12, v0, #1
	shl.4s	v13, v12, #23
	add.4s	v13, v13, v21
	fmul.4s	v23, v23, v13
	sub.4s	v9, v9, v11
	sub.4s	v0, v0, v12
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v23, v0
	shl.4s	v23, v9, #23
	add.4s	v23, v23, v21
	fmul.4s	v1, v1, v23
	str	q14, [sp, #6928]                ; 16-byte Spill
	fcmgt.4s	v23, v5, v14
	bic.16b	v1, v1, v23
	str	q15, [sp, #6960]                ; 16-byte Spill
	fcmgt.4s	v23, v5, v15
	bic.16b	v0, v0, v23
	fcmgt.4s	v23, v15, v3
	bit.16b	v0, v24, v23
	str	q0, [sp, #6976]                 ; 16-byte Spill
	fcmgt.4s	v0, v14, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6944]                 ; 16-byte Spill
	fsub.4s	v0, v10, v4
	and.16b	v13, v8, v0
	fcmge.4s	v0, v13, v5
	fcmge.4s	v1, v3, v13
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6880]                 ; 16-byte Reload
	fsub.4s	v1, v1, v27
	ldr	q23, [sp, #11792]               ; 16-byte Reload
	and.16b	v12, v23, v1
	fcmge.4s	v1, v12, v5
	fcmge.4s	v23, v3, v12
	and.16b	v1, v1, v23
	and.16b	v1, v1, v12
	fmul.4s	v23, v1, v25
	mvni.4s	v2, #128, lsl #24
	movi.4s	v28, #75, lsl #24
	mov.16b	v31, v2
	bsl.16b	v31, v28, v23
	fadd.4s	v23, v23, v31
	fsub.4s	v23, v23, v31
	and.16b	v31, v0, v13
	fmul.4s	v0, v31, v25
	mov.16b	v14, v25
	mov.16b	v9, v2
	bsl.16b	v9, v28, v0
	fadd.4s	v0, v0, v9
	fsub.4s	v9, v0, v9
	fcvtzs.4s	v0, v23
	scvtf.4s	v23, v0
	fmul.4s	v10, v23, v7
	fsub.4s	v1, v1, v10
	fcvtzs.4s	v9, v9
	scvtf.4s	v10, v9
	fmul.4s	v11, v10, v7
	fsub.4s	v31, v31, v11
	fmul.4s	v10, v10, v16
	fsub.4s	v31, v31, v10
	fmul.4s	v23, v23, v16
	fsub.4s	v1, v1, v23
	fmul.4s	v23, v1, v17
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v22
	fmul.4s	v23, v1, v23
	movi.4s	v2, #63, lsl #24
	fadd.4s	v23, v23, v2
	fmul.4s	v10, v1, v1
	fmul.4s	v23, v10, v23
	fmul.4s	v10, v31, v17
	fadd.4s	v10, v10, v18
	fmul.4s	v10, v31, v10
	fadd.4s	v10, v10, v20
	fmul.4s	v10, v31, v10
	fadd.4s	v10, v10, v6
	fmul.4s	v10, v31, v10
	fadd.4s	v10, v10, v22
	fmul.4s	v10, v31, v10
	fadd.4s	v10, v10, v2
	fmul.4s	v11, v31, v31
	fmul.4s	v10, v11, v10
	fadd.4s	v31, v31, v10
	fadd.4s	v1, v1, v23
	fadd.4s	v23, v31, v21
	sshr.4s	v31, v9, #1
	shl.4s	v10, v31, #23
	add.4s	v10, v10, v21
	fmul.4s	v23, v23, v10
	fadd.4s	v1, v1, v21
	sshr.4s	v10, v0, #1
	shl.4s	v11, v10, #23
	add.4s	v11, v11, v21
	fmul.4s	v1, v1, v11
	sub.4s	v31, v9, v31
	sub.4s	v0, v0, v10
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v31, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v23, v1
	str	q13, [sp, #6832]                ; 16-byte Spill
	fcmgt.4s	v23, v5, v13
	bic.16b	v1, v1, v23
	str	q12, [sp, #6864]                ; 16-byte Spill
	fcmgt.4s	v23, v5, v12
	bic.16b	v0, v0, v23
	fcmgt.4s	v23, v12, v3
	bit.16b	v0, v24, v23
	str	q0, [sp, #6880]                 ; 16-byte Spill
	fcmgt.4s	v0, v13, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6848]                 ; 16-byte Spill
	ldr	q0, [sp, #6768]                 ; 16-byte Reload
	fsub.4s	v0, v0, v4
	mov.16b	v11, v4
	and.16b	v28, v8, v0
	fcmge.4s	v0, v28, v5
	fcmge.4s	v1, v3, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6784]                 ; 16-byte Reload
	fsub.4s	v1, v1, v27
	mov.16b	v12, v27
	ldr	q23, [sp, #11792]               ; 16-byte Reload
	and.16b	v25, v23, v1
	fcmge.4s	v1, v25, v5
	fcmge.4s	v23, v3, v25
	and.16b	v1, v1, v23
	and.16b	v1, v1, v25
	fmul.4s	v23, v1, v14
	movi.4s	v2, #75, lsl #24
	mvni.4s	v4, #128, lsl #24
	mov.16b	v29, v4
	bsl.16b	v29, v2, v23
	fadd.4s	v23, v23, v29
	fsub.4s	v23, v23, v29
	and.16b	v29, v0, v28
	fmul.4s	v0, v29, v14
	mov.16b	v30, v4
	bsl.16b	v30, v2, v0
	fadd.4s	v0, v0, v30
	fsub.4s	v30, v0, v30
	fcvtzs.4s	v0, v23
	scvtf.4s	v23, v0
	fmul.4s	v31, v23, v7
	fsub.4s	v1, v1, v31
	fcvtzs.4s	v30, v30
	scvtf.4s	v31, v30
	fmul.4s	v9, v31, v7
	fsub.4s	v29, v29, v9
	fmul.4s	v31, v31, v16
	fsub.4s	v29, v29, v31
	fmul.4s	v23, v23, v16
	fsub.4s	v1, v1, v23
	fmul.4s	v23, v1, v17
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v22
	fmul.4s	v23, v1, v23
	movi.4s	v2, #63, lsl #24
	fadd.4s	v23, v23, v2
	fmul.4s	v31, v1, v1
	fmul.4s	v23, v31, v23
	fmul.4s	v31, v29, v17
	fadd.4s	v31, v31, v18
	fmul.4s	v31, v29, v31
	fadd.4s	v31, v31, v20
	fmul.4s	v31, v29, v31
	fadd.4s	v31, v31, v6
	fmul.4s	v31, v29, v31
	fadd.4s	v31, v31, v22
	fmul.4s	v31, v29, v31
	fadd.4s	v31, v31, v2
	movi.4s	v10, #63, lsl #24
	fmul.4s	v9, v29, v29
	fmul.4s	v31, v9, v31
	fadd.4s	v29, v29, v31
	fadd.4s	v1, v1, v23
	fadd.4s	v23, v29, v21
	sshr.4s	v29, v30, #1
	shl.4s	v31, v29, #23
	add.4s	v31, v31, v21
	fmul.4s	v23, v23, v31
	fadd.4s	v1, v1, v21
	sshr.4s	v31, v0, #1
	shl.4s	v9, v31, #23
	add.4s	v9, v9, v21
	fmul.4s	v1, v1, v9
	sub.4s	v29, v30, v29
	sub.4s	v0, v0, v31
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v29, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v23, v1
	str	q28, [sp, #6736]                ; 16-byte Spill
	fcmgt.4s	v23, v5, v28
	bic.16b	v1, v1, v23
	str	q25, [sp, #6768]                ; 16-byte Spill
	fcmgt.4s	v23, v5, v25
	bic.16b	v0, v0, v23
	fcmgt.4s	v23, v25, v3
	bit.16b	v0, v24, v23
	str	q0, [sp, #6784]                 ; 16-byte Spill
	fcmgt.4s	v0, v28, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6752]                 ; 16-byte Spill
	ldr	q0, [sp, #6672]                 ; 16-byte Reload
	fsub.4s	v0, v0, v11
	and.16b	v4, v8, v0
	fcmge.4s	v0, v4, v5
	fcmge.4s	v1, v3, v4
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6688]                 ; 16-byte Reload
	fsub.4s	v1, v1, v27
	ldr	q23, [sp, #11792]               ; 16-byte Reload
	and.16b	v2, v23, v1
	fcmge.4s	v1, v2, v5
	fcmge.4s	v23, v3, v2
	and.16b	v1, v1, v23
	and.16b	v1, v1, v2
	fmul.4s	v23, v1, v14
	mvni.4s	v19, #128, lsl #24
	movi.4s	v25, #75, lsl #24
	mov.16b	v27, v19
	bsl.16b	v27, v25, v23
	fadd.4s	v23, v23, v27
	fsub.4s	v23, v23, v27
	and.16b	v27, v0, v4
	fmul.4s	v0, v27, v14
	mov.16b	v28, v19
	bsl.16b	v28, v25, v0
	mvni.4s	v9, #128, lsl #24
	fadd.4s	v0, v0, v28
	fsub.4s	v28, v0, v28
	fcvtzs.4s	v0, v23
	scvtf.4s	v23, v0
	fmul.4s	v29, v23, v7
	fsub.4s	v1, v1, v29
	fcvtzs.4s	v28, v28
	scvtf.4s	v29, v28
	fmul.4s	v30, v29, v7
	fsub.4s	v27, v27, v30
	fmul.4s	v29, v29, v16
	fsub.4s	v27, v27, v29
	fmul.4s	v23, v23, v16
	fsub.4s	v1, v1, v23
	fmul.4s	v23, v1, v17
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v22
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v29, v1, v1
	fmul.4s	v23, v29, v23
	fmul.4s	v29, v27, v17
	fadd.4s	v29, v29, v18
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v20
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v6
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v22
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v10
	fmul.4s	v30, v27, v27
	fmul.4s	v29, v30, v29
	fadd.4s	v27, v27, v29
	fadd.4s	v1, v1, v23
	fadd.4s	v23, v27, v21
	sshr.4s	v27, v28, #1
	shl.4s	v29, v27, #23
	add.4s	v29, v29, v21
	fmul.4s	v23, v23, v29
	fadd.4s	v1, v1, v21
	sshr.4s	v29, v0, #1
	shl.4s	v30, v29, #23
	add.4s	v30, v30, v21
	fmul.4s	v1, v1, v30
	sub.4s	v27, v28, v27
	sub.4s	v0, v0, v29
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v27, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v23, v1
	str	q4, [sp, #6640]                 ; 16-byte Spill
	fcmgt.4s	v23, v5, v4
	bic.16b	v1, v1, v23
	str	q2, [sp, #6672]                 ; 16-byte Spill
	fcmgt.4s	v23, v5, v2
	bic.16b	v0, v0, v23
	fcmgt.4s	v23, v2, v3
	bit.16b	v0, v24, v23
	str	q0, [sp, #6688]                 ; 16-byte Spill
	fcmgt.4s	v0, v4, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6656]                 ; 16-byte Spill
	ldr	q0, [sp, #6576]                 ; 16-byte Reload
	fsub.4s	v0, v0, v11
	and.16b	v4, v8, v0
	fcmge.4s	v0, v4, v5
	fcmge.4s	v1, v3, v4
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6592]                 ; 16-byte Reload
	fsub.4s	v1, v1, v12
	ldr	q23, [sp, #11792]               ; 16-byte Reload
	and.16b	v2, v23, v1
	fcmge.4s	v1, v2, v5
	fcmge.4s	v23, v3, v2
	and.16b	v1, v1, v23
	and.16b	v1, v1, v2
	fmul.4s	v23, v1, v14
	movi.4s	v19, #75, lsl #24
	mov.16b	v25, v9
	bsl.16b	v25, v19, v23
	fadd.4s	v23, v23, v25
	fsub.4s	v23, v23, v25
	and.16b	v25, v0, v4
	fmul.4s	v0, v25, v14
	mov.16b	v26, v9
	bsl.16b	v26, v19, v0
	fadd.4s	v0, v0, v26
	fsub.4s	v26, v0, v26
	fcvtzs.4s	v0, v23
	scvtf.4s	v23, v0
	fmul.4s	v27, v23, v7
	fsub.4s	v1, v1, v27
	fcvtzs.4s	v26, v26
	scvtf.4s	v27, v26
	fmul.4s	v28, v27, v7
	fsub.4s	v25, v25, v28
	fmul.4s	v27, v27, v16
	fsub.4s	v25, v25, v27
	fmul.4s	v23, v23, v16
	fsub.4s	v1, v1, v23
	fmul.4s	v23, v1, v17
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v22
	fmul.4s	v23, v1, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v27, v1, v1
	fmul.4s	v23, v27, v23
	fmul.4s	v27, v25, v17
	fadd.4s	v27, v27, v18
	fmul.4s	v27, v25, v27
	fadd.4s	v27, v27, v20
	fmul.4s	v27, v25, v27
	fadd.4s	v27, v27, v6
	fmul.4s	v27, v25, v27
	fadd.4s	v27, v27, v22
	fmul.4s	v27, v25, v27
	fadd.4s	v27, v27, v10
	fmul.4s	v28, v25, v25
	fmul.4s	v27, v28, v27
	fadd.4s	v25, v25, v27
	fadd.4s	v1, v1, v23
	fadd.4s	v23, v25, v21
	sshr.4s	v25, v26, #1
	shl.4s	v27, v25, #23
	add.4s	v27, v27, v21
	fmul.4s	v23, v23, v27
	fadd.4s	v1, v1, v21
	sshr.4s	v27, v0, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v21
	fmul.4s	v1, v1, v28
	sub.4s	v25, v26, v25
	sub.4s	v0, v0, v27
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v25, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v23, v1
	str	q4, [sp, #6544]                 ; 16-byte Spill
	fcmgt.4s	v23, v5, v4
	bic.16b	v1, v1, v23
	str	q2, [sp, #6576]                 ; 16-byte Spill
	fcmgt.4s	v23, v5, v2
	bic.16b	v0, v0, v23
	fcmgt.4s	v23, v2, v3
	bit.16b	v0, v24, v23
	str	q0, [sp, #6592]                 ; 16-byte Spill
	fcmgt.4s	v0, v4, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6560]                 ; 16-byte Spill
	ldr	q0, [sp, #6480]                 ; 16-byte Reload
	fsub.4s	v0, v0, v11
	and.16b	v27, v8, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6496]                 ; 16-byte Reload
	fsub.4s	v1, v1, v12
	ldr	q4, [sp, #11792]                ; 16-byte Reload
	and.16b	v2, v4, v1
	fcmge.4s	v1, v2, v5
	fcmge.4s	v4, v3, v2
	and.16b	v1, v1, v4
	and.16b	v1, v1, v2
	fmul.4s	v4, v1, v14
	movi.4s	v23, #75, lsl #24
	mov.16b	v19, v9
	bsl.16b	v19, v23, v4
	fadd.4s	v4, v4, v19
	fsub.4s	v4, v4, v19
	and.16b	v19, v0, v27
	fmul.4s	v0, v19, v14
	bif.16b	v23, v0, v9
	movi.4s	v28, #75, lsl #24
	fadd.4s	v0, v0, v23
	fsub.4s	v23, v0, v23
	fcvtzs.4s	v0, v4
	scvtf.4s	v4, v0
	fmul.4s	v25, v4, v7
	fsub.4s	v1, v1, v25
	fcvtzs.4s	v23, v23
	scvtf.4s	v25, v23
	fmul.4s	v26, v25, v7
	fsub.4s	v19, v19, v26
	fmul.4s	v25, v25, v16
	fsub.4s	v19, v19, v25
	fmul.4s	v4, v4, v16
	fsub.4s	v1, v1, v4
	fmul.4s	v4, v1, v17
	fadd.4s	v4, v4, v18
	fmul.4s	v4, v1, v4
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v1, v4
	fadd.4s	v4, v4, v6
	fmul.4s	v4, v1, v4
	fadd.4s	v4, v4, v22
	fmul.4s	v4, v1, v4
	fadd.4s	v4, v4, v10
	fmul.4s	v25, v1, v1
	fmul.4s	v4, v25, v4
	fmul.4s	v25, v19, v17
	fadd.4s	v25, v25, v18
	fmul.4s	v25, v19, v25
	fadd.4s	v25, v25, v20
	fmul.4s	v25, v19, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v19, v25
	fadd.4s	v25, v25, v22
	fmul.4s	v25, v19, v25
	fadd.4s	v25, v25, v10
	fmul.4s	v26, v19, v19
	fmul.4s	v25, v26, v25
	fadd.4s	v19, v19, v25
	fadd.4s	v1, v1, v4
	fadd.4s	v4, v19, v21
	sshr.4s	v19, v23, #1
	shl.4s	v25, v19, #23
	add.4s	v25, v25, v21
	fmul.4s	v4, v4, v25
	fadd.4s	v1, v1, v21
	sshr.4s	v25, v0, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v21
	fmul.4s	v1, v1, v26
	sub.4s	v19, v23, v19
	sub.4s	v0, v0, v25
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v19, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v4, v1
	str	q27, [sp, #6448]                ; 16-byte Spill
	fcmgt.4s	v4, v5, v27
	bic.16b	v1, v1, v4
	str	q2, [sp, #6480]                 ; 16-byte Spill
	fcmgt.4s	v4, v5, v2
	bic.16b	v0, v0, v4
	fcmgt.4s	v4, v2, v3
	bit.16b	v0, v24, v4
	str	q0, [sp, #6496]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6464]                 ; 16-byte Spill
	ldr	q0, [sp, #6384]                 ; 16-byte Reload
	fsub.4s	v0, v0, v11
	and.16b	v27, v8, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6400]                 ; 16-byte Reload
	fsub.4s	v1, v1, v12
	ldr	q2, [sp, #11792]                ; 16-byte Reload
	and.16b	v26, v2, v1
	fcmge.4s	v1, v26, v5
	fcmge.4s	v2, v3, v26
	and.16b	v1, v1, v2
	and.16b	v1, v1, v26
	fmul.4s	v2, v1, v14
	mov.16b	v4, v9
	bsl.16b	v4, v28, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v27
	fmul.4s	v0, v4, v14
	mov.16b	v19, v9
	bsl.16b	v19, v28, v0
	fadd.4s	v0, v0, v19
	fsub.4s	v19, v0, v19
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v23, v2, v7
	fsub.4s	v1, v1, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v25, v23, v7
	fsub.4s	v4, v4, v25
	fmul.4s	v23, v23, v16
	fsub.4s	v4, v4, v23
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v20
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v22
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v10
	fmul.4s	v23, v1, v1
	fmul.4s	v2, v23, v2
	fmul.4s	v23, v4, v17
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v22
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v25, v4, v4
	fmul.4s	v23, v25, v23
	fadd.4s	v4, v4, v23
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v21
	sshr.4s	v4, v19, #1
	shl.4s	v23, v4, #23
	add.4s	v23, v23, v21
	fmul.4s	v2, v2, v23
	fadd.4s	v1, v1, v21
	sshr.4s	v23, v0, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v21
	fmul.4s	v1, v1, v25
	sub.4s	v4, v19, v4
	sub.4s	v0, v0, v23
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v2, v1
	str	q27, [sp, #6352]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v27
	bic.16b	v1, v1, v2
	str	q26, [sp, #6384]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v26
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v26, v3
	bit.16b	v0, v24, v2
	str	q0, [sp, #6400]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6368]                 ; 16-byte Spill
	ldr	q0, [sp, #6320]                 ; 16-byte Reload
	fsub.4s	v0, v0, v11
	and.16b	v27, v8, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6336]                 ; 16-byte Reload
	fsub.4s	v1, v1, v12
	ldr	q2, [sp, #11792]                ; 16-byte Reload
	and.16b	v26, v2, v1
	fcmge.4s	v1, v26, v5
	fcmge.4s	v2, v3, v26
	and.16b	v1, v1, v2
	and.16b	v1, v1, v26
	fmul.4s	v2, v1, v14
	movi.4s	v19, #75, lsl #24
	mov.16b	v4, v9
	bsl.16b	v4, v19, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v27
	fmul.4s	v0, v4, v14
	bif.16b	v19, v0, v9
	fadd.4s	v0, v0, v19
	fsub.4s	v19, v0, v19
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v23, v2, v7
	fsub.4s	v1, v1, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v25, v23, v7
	fsub.4s	v4, v4, v25
	fmul.4s	v23, v23, v16
	fsub.4s	v4, v4, v23
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v20
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v22
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v10
	fmul.4s	v23, v1, v1
	fmul.4s	v2, v23, v2
	fmul.4s	v23, v4, v17
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v22
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v25, v4, v4
	fmul.4s	v23, v25, v23
	fadd.4s	v4, v4, v23
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v21
	sshr.4s	v4, v19, #1
	shl.4s	v23, v4, #23
	add.4s	v23, v23, v21
	fmul.4s	v2, v2, v23
	fadd.4s	v1, v1, v21
	sshr.4s	v23, v0, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v21
	fmul.4s	v1, v1, v25
	sub.4s	v4, v19, v4
	sub.4s	v0, v0, v23
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v2, v1
	str	q27, [sp, #6288]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v27
	bic.16b	v1, v1, v2
	str	q26, [sp, #6320]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v26
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v26, v3
	bit.16b	v0, v24, v2
	str	q0, [sp, #6336]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6304]                 ; 16-byte Spill
	ldr	q0, [sp, #6416]                 ; 16-byte Reload
	fsub.4s	v0, v0, v12
	ldr	q1, [sp, #11792]                ; 16-byte Reload
	and.16b	v27, v1, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6432]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v26, v8, v1
	fcmge.4s	v1, v26, v5
	fcmge.4s	v2, v3, v26
	and.16b	v1, v1, v2
	and.16b	v1, v1, v26
	fmul.4s	v2, v1, v14
	mov.16b	v4, v9
	bsl.16b	v4, v28, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v27
	fmul.4s	v0, v4, v14
	mov.16b	v19, v9
	bsl.16b	v19, v28, v0
	fadd.4s	v0, v0, v19
	fsub.4s	v19, v0, v19
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v23, v2, v7
	fsub.4s	v1, v1, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v25, v23, v7
	fsub.4s	v4, v4, v25
	fmul.4s	v23, v23, v16
	fsub.4s	v4, v4, v23
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v20
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v22
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v10
	fmul.4s	v23, v1, v1
	fmul.4s	v2, v23, v2
	fmul.4s	v23, v4, v17
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v22
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v25, v4, v4
	fmul.4s	v23, v25, v23
	fadd.4s	v4, v4, v23
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v21
	sshr.4s	v4, v19, #1
	shl.4s	v23, v4, #23
	add.4s	v23, v23, v21
	fmul.4s	v2, v2, v23
	fadd.4s	v1, v1, v21
	sshr.4s	v23, v0, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v21
	fmul.4s	v1, v1, v25
	sub.4s	v4, v19, v4
	sub.4s	v0, v0, v23
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v2, v1
	str	q27, [sp, #6256]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v27
	bic.16b	v1, v1, v2
	str	q26, [sp, #6416]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v26
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v26, v3
	bit.16b	v0, v24, v2
	str	q0, [sp, #6432]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6272]                 ; 16-byte Spill
	ldr	q0, [sp, #6512]                 ; 16-byte Reload
	fsub.4s	v0, v0, v12
	ldr	q1, [sp, #11792]                ; 16-byte Reload
	and.16b	v27, v1, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6528]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v26, v8, v1
	fcmge.4s	v1, v26, v5
	fcmge.4s	v2, v3, v26
	and.16b	v1, v1, v2
	and.16b	v1, v1, v26
	fmul.4s	v2, v1, v14
	movi.4s	v19, #75, lsl #24
	mov.16b	v4, v9
	bsl.16b	v4, v19, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v27
	fmul.4s	v0, v4, v14
	bif.16b	v19, v0, v9
	fadd.4s	v0, v0, v19
	fsub.4s	v19, v0, v19
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v23, v2, v7
	fsub.4s	v1, v1, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v25, v23, v7
	fsub.4s	v4, v4, v25
	fmul.4s	v23, v23, v16
	fsub.4s	v4, v4, v23
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v20
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v22
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v10
	fmul.4s	v23, v1, v1
	fmul.4s	v2, v23, v2
	fmul.4s	v23, v4, v17
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v22
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v25, v4, v4
	fmul.4s	v23, v25, v23
	fadd.4s	v4, v4, v23
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v21
	sshr.4s	v4, v19, #1
	shl.4s	v23, v4, #23
	add.4s	v23, v23, v21
	fmul.4s	v2, v2, v23
	fadd.4s	v1, v1, v21
	sshr.4s	v23, v0, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v21
	fmul.4s	v1, v1, v25
	sub.4s	v4, v19, v4
	sub.4s	v0, v0, v23
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v2, v1
	str	q27, [sp, #6224]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v27
	bic.16b	v1, v1, v2
	str	q26, [sp, #6512]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v26
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v26, v3
	bit.16b	v0, v24, v2
	str	q0, [sp, #6528]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6240]                 ; 16-byte Spill
	ldr	q0, [sp, #6608]                 ; 16-byte Reload
	fsub.4s	v0, v0, v12
	ldr	q1, [sp, #11792]                ; 16-byte Reload
	and.16b	v27, v1, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6624]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v26, v8, v1
	fcmge.4s	v1, v26, v5
	fcmge.4s	v2, v3, v26
	and.16b	v1, v1, v2
	and.16b	v1, v1, v26
	fmul.4s	v2, v1, v14
	mov.16b	v4, v9
	bsl.16b	v4, v28, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v27
	fmul.4s	v0, v4, v14
	mov.16b	v19, v9
	bsl.16b	v19, v28, v0
	fadd.4s	v0, v0, v19
	fsub.4s	v19, v0, v19
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v23, v2, v7
	fsub.4s	v1, v1, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v25, v23, v7
	fsub.4s	v4, v4, v25
	fmul.4s	v23, v23, v16
	fsub.4s	v4, v4, v23
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v20
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v22
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v10
	fmul.4s	v23, v1, v1
	fmul.4s	v2, v23, v2
	fmul.4s	v23, v4, v17
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v22
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v25, v4, v4
	fmul.4s	v23, v25, v23
	fadd.4s	v4, v4, v23
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v21
	sshr.4s	v4, v19, #1
	shl.4s	v23, v4, #23
	add.4s	v23, v23, v21
	fmul.4s	v2, v2, v23
	fadd.4s	v1, v1, v21
	sshr.4s	v23, v0, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v21
	fmul.4s	v1, v1, v25
	sub.4s	v4, v19, v4
	sub.4s	v0, v0, v23
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v2, v1
	str	q27, [sp, #6192]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v27
	bic.16b	v1, v1, v2
	str	q26, [sp, #6608]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v26
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v26, v3
	bit.16b	v0, v24, v2
	str	q0, [sp, #6624]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6208]                 ; 16-byte Spill
	ldr	q0, [sp, #6704]                 ; 16-byte Reload
	fsub.4s	v0, v0, v12
	ldr	q1, [sp, #11792]                ; 16-byte Reload
	and.16b	v29, v1, v0
	fcmge.4s	v0, v29, v5
	fcmge.4s	v1, v3, v29
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6720]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v31, v8, v1
	fcmge.4s	v1, v31, v5
	fcmge.4s	v2, v3, v31
	and.16b	v1, v1, v2
	and.16b	v1, v1, v31
	fmul.4s	v2, v1, v14
	movi.4s	v19, #75, lsl #24
	mov.16b	v4, v9
	bsl.16b	v4, v19, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v29
	fmul.4s	v0, v4, v14
	bif.16b	v19, v0, v9
	fadd.4s	v0, v0, v19
	fsub.4s	v19, v0, v19
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v23, v2, v7
	fsub.4s	v1, v1, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v25, v23, v7
	fsub.4s	v4, v4, v25
	fmul.4s	v23, v23, v16
	fsub.4s	v4, v4, v23
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v20
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v22
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v10
	fmul.4s	v23, v1, v1
	fmul.4s	v2, v23, v2
	fmul.4s	v23, v4, v17
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v22
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v25, v4, v4
	fmul.4s	v23, v25, v23
	fadd.4s	v4, v4, v23
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v21
	sshr.4s	v4, v19, #1
	shl.4s	v23, v4, #23
	add.4s	v23, v23, v21
	fmul.4s	v2, v2, v23
	fadd.4s	v1, v1, v21
	sshr.4s	v23, v0, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v21
	fmul.4s	v1, v1, v25
	sub.4s	v4, v19, v4
	sub.4s	v0, v0, v23
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v2, v1
	fcmgt.4s	v2, v5, v29
	bic.16b	v1, v1, v2
	fcmgt.4s	v2, v5, v31
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v31, v3
	bit.16b	v0, v24, v2
	str	q0, [sp, #6176]                 ; 16-byte Spill
	fcmgt.4s	v0, v29, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6160]                 ; 16-byte Spill
	ldr	q0, [sp, #6800]                 ; 16-byte Reload
	fsub.4s	v0, v0, v11
	and.16b	v27, v8, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	mov.16b	v30, v12
	ldr	q1, [sp, #6816]                 ; 16-byte Reload
	fsub.4s	v1, v1, v12
	ldr	q2, [sp, #11792]                ; 16-byte Reload
	and.16b	v28, v2, v1
	fcmge.4s	v1, v28, v5
	fcmge.4s	v2, v3, v28
	and.16b	v1, v1, v2
	and.16b	v1, v1, v28
	fmul.4s	v2, v1, v14
	movi.4s	v19, #75, lsl #24
	mov.16b	v4, v9
	bsl.16b	v4, v19, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v27
	fmul.4s	v0, v4, v14
	bif.16b	v19, v0, v9
	fadd.4s	v0, v0, v19
	fsub.4s	v19, v0, v19
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v23, v2, v7
	fsub.4s	v1, v1, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v12, v23, v7
	fsub.4s	v4, v4, v12
	fmul.4s	v23, v23, v16
	fsub.4s	v4, v4, v23
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v20
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v22
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v10
	fmul.4s	v23, v1, v1
	fmul.4s	v2, v23, v2
	fmul.4s	v23, v4, v17
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v22
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v12, v4, v4
	fmul.4s	v23, v12, v23
	fadd.4s	v4, v4, v23
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v21
	sshr.4s	v4, v19, #1
	shl.4s	v23, v4, #23
	add.4s	v23, v23, v21
	fmul.4s	v2, v2, v23
	fadd.4s	v1, v1, v21
	sshr.4s	v23, v0, #1
	shl.4s	v12, v23, #23
	add.4s	v12, v12, v21
	fmul.4s	v1, v1, v12
	sub.4s	v4, v19, v4
	sub.4s	v0, v0, v23
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v2, v1
	fcmgt.4s	v2, v5, v27
	bic.16b	v1, v1, v2
	fcmgt.4s	v2, v5, v28
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v28, v3
	bit.16b	v0, v24, v2
	str	q0, [sp, #6144]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6128]                 ; 16-byte Spill
	ldr	q0, [sp, #6896]                 ; 16-byte Reload
	fsub.4s	v0, v0, v30
	ldr	q1, [sp, #11792]                ; 16-byte Reload
	and.16b	v25, v1, v0
	fcmge.4s	v0, v25, v5
	fcmge.4s	v1, v3, v25
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6912]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v26, v8, v1
	fcmge.4s	v1, v26, v5
	fcmge.4s	v2, v3, v26
	and.16b	v1, v1, v2
	and.16b	v1, v1, v26
	fmul.4s	v2, v1, v14
	movi.4s	v19, #75, lsl #24
	mov.16b	v4, v9
	bsl.16b	v4, v19, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v25
	fmul.4s	v0, v4, v14
	mov.16b	v12, v9
	bsl.16b	v12, v19, v0
	fadd.4s	v0, v0, v12
	fsub.4s	v12, v0, v12
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v13, v2, v7
	fsub.4s	v1, v1, v13
	fcvtzs.4s	v12, v12
	scvtf.4s	v13, v12
	fmul.4s	v15, v13, v7
	fsub.4s	v4, v4, v15
	fmul.4s	v13, v13, v16
	fsub.4s	v4, v4, v13
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v20
	fmul.4s	v2, v1, v2
	mov.16b	v23, v6
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v22
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v10
	fmul.4s	v13, v1, v1
	fmul.4s	v2, v13, v2
	fmul.4s	v13, v4, v17
	fadd.4s	v13, v13, v18
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v20
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v6
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v22
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v10
	fmul.4s	v15, v4, v4
	fmul.4s	v13, v15, v13
	fadd.4s	v4, v4, v13
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v21
	sshr.4s	v4, v12, #1
	shl.4s	v13, v4, #23
	add.4s	v13, v13, v21
	fmul.4s	v2, v2, v13
	fadd.4s	v1, v1, v21
	sshr.4s	v13, v0, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v21
	fmul.4s	v1, v1, v15
	sub.4s	v4, v12, v4
	sub.4s	v0, v0, v13
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v2, v1
	fcmgt.4s	v2, v5, v25
	bic.16b	v1, v1, v2
	fcmgt.4s	v2, v5, v26
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v26, v3
	bit.16b	v0, v24, v2
	str	q0, [sp, #6080]                 ; 16-byte Spill
	fcmgt.4s	v0, v25, v3
	bsl.16b	v0, v24, v1
	str	q0, [sp, #6112]                 ; 16-byte Spill
	ldr	q0, [sp, #7024]                 ; 16-byte Reload
	fsub.4s	v0, v0, v30
	ldr	q1, [sp, #11792]                ; 16-byte Reload
	and.16b	v19, v1, v0
	fcmge.4s	v0, v19, v5
	fcmge.4s	v1, v3, v19
	and.16b	v0, v0, v1
	mov.16b	v2, v11
	ldr	q1, [sp, #7040]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v4, v8, v1
	fcmge.4s	v1, v4, v5
	fcmge.4s	v12, v3, v4
	and.16b	v1, v1, v12
	and.16b	v1, v1, v4
	mov.16b	v6, v14
	fmul.4s	v12, v1, v14
	movi.4s	v10, #75, lsl #24
	mov.16b	v13, v9
	bsl.16b	v13, v10, v12
	fadd.4s	v12, v12, v13
	fsub.4s	v12, v12, v13
	and.16b	v13, v0, v19
	fmul.4s	v0, v13, v14
	mov.16b	v15, v9
	bsl.16b	v15, v10, v0
	fadd.4s	v0, v0, v15
	fsub.4s	v15, v0, v15
	fcvtzs.4s	v0, v12
	scvtf.4s	v12, v0
	fmul.4s	v11, v12, v7
	fsub.4s	v1, v1, v11
	fcvtzs.4s	v11, v15
	scvtf.4s	v15, v11
	fmul.4s	v14, v15, v7
	fsub.4s	v13, v13, v14
	fmul.4s	v14, v15, v16
	fsub.4s	v13, v13, v14
	fmul.4s	v12, v12, v16
	fsub.4s	v1, v1, v12
	fmul.4s	v12, v1, v17
	fadd.4s	v12, v12, v18
	fmul.4s	v12, v1, v12
	fadd.4s	v12, v12, v20
	fmul.4s	v12, v1, v12
	fadd.4s	v12, v12, v23
	fmul.4s	v12, v1, v12
	fadd.4s	v12, v12, v22
	fmul.4s	v12, v1, v12
	movi.4s	v15, #63, lsl #24
	fadd.4s	v12, v12, v15
	fmul.4s	v14, v1, v1
	fmul.4s	v12, v14, v12
	fmul.4s	v14, v13, v17
	fadd.4s	v14, v14, v18
	fmul.4s	v14, v13, v14
	fadd.4s	v14, v14, v20
	fmul.4s	v14, v13, v14
	fadd.4s	v14, v14, v23
	fmul.4s	v14, v13, v14
	fadd.4s	v14, v14, v22
	fmul.4s	v14, v13, v14
	fadd.4s	v14, v14, v15
	fmul.4s	v15, v13, v13
	fmul.4s	v14, v15, v14
	fadd.4s	v13, v13, v14
	fadd.4s	v1, v1, v12
	fadd.4s	v12, v13, v21
	sshr.4s	v13, v11, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v21
	fmul.4s	v12, v12, v14
	fadd.4s	v1, v1, v21
	sshr.4s	v14, v0, #1
	shl.4s	v15, v14, #23
	add.4s	v15, v15, v21
	fmul.4s	v1, v1, v15
	sub.4s	v11, v11, v13
	sub.4s	v0, v0, v14
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v1, v0
	shl.4s	v1, v11, #23
	add.4s	v1, v1, v21
	fmul.4s	v1, v12, v1
	fcmgt.4s	v11, v5, v19
	bic.16b	v1, v1, v11
	fcmgt.4s	v11, v5, v4
	bic.16b	v0, v0, v11
	fcmgt.4s	v11, v4, v3
	bit.16b	v0, v24, v11
	str	q0, [sp, #6096]                 ; 16-byte Spill
	fcmgt.4s	v0, v19, v3
	mov.16b	v12, v0
	bsl.16b	v12, v24, v1
	str	q2, [sp, #7040]                 ; 16-byte Spill
	ldr	q0, [sp, #11728]                ; 16-byte Reload
	fsub.4s	v0, v0, v2
	and.16b	v2, v8, v0
	fcmge.4s	v0, v2, v5
	fcmge.4s	v11, v3, v2
	and.16b	v11, v0, v11
	str	q30, [sp, #7024]                ; 16-byte Spill
	ldr	q1, [sp, #11744]                ; 16-byte Reload
	fsub.4s	v0, v1, v30
	ldr	q1, [sp, #11792]                ; 16-byte Reload
	and.16b	v1, v1, v0
	fcmge.4s	v14, v1, v5
	fcmge.4s	v15, v3, v1
	and.16b	v14, v14, v15
	and.16b	v14, v14, v1
	fmul.4s	v15, v14, v6
	mov.16b	v0, v9
	bsl.16b	v0, v10, v15
	fadd.4s	v15, v15, v0
	fsub.4s	v0, v15, v0
	and.16b	v11, v11, v2
	fmul.4s	v6, v11, v6
	mov.16b	v15, v9
	bsl.16b	v15, v10, v6
	fadd.4s	v6, v6, v15
	fsub.4s	v6, v6, v15
	fcvtzs.4s	v0, v0
	scvtf.4s	v15, v0
	fmul.4s	v13, v15, v7
	fsub.4s	v13, v14, v13
	fcvtzs.4s	v6, v6
	scvtf.4s	v14, v6
	fmul.4s	v7, v14, v7
	fsub.4s	v7, v11, v7
	fmul.4s	v11, v15, v16
	fmul.4s	v16, v14, v16
	fsub.4s	v7, v7, v16
	fsub.4s	v16, v13, v11
	ldr	q13, [sp, #11792]               ; 16-byte Reload
	fmul.4s	v11, v16, v17
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v18
	fadd.4s	v18, v11, v18
	fmul.4s	v18, v16, v18
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v20
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v16, v18
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v23
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v16, v18
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v16, v18
	movi.4s	v22, #63, lsl #24
	fadd.4s	v18, v18, v22
	fmul.4s	v20, v16, v16
	fmul.4s	v18, v20, v18
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v22
	fmul.4s	v20, v7, v7
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	fadd.4s	v16, v16, v18
	fadd.4s	v7, v7, v21
	sshr.4s	v17, v6, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v21
	fmul.4s	v7, v7, v18
	fadd.4s	v16, v16, v21
	sshr.4s	v18, v0, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v21
	fmul.4s	v16, v16, v20
	sub.4s	v6, v6, v17
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v21
	fmul.4s	v0, v16, v0
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v21
	fmul.4s	v6, v7, v6
	fcmgt.4s	v7, v5, v2
	bic.16b	v6, v6, v7
	fcmgt.4s	v5, v5, v1
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v1, v3
	bsl.16b	v5, v24, v0
	fcmgt.4s	v0, v2, v3
	mov.16b	v3, v0
	bsl.16b	v3, v24, v6
	ldr	q0, [sp, #6992]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #4784]                 ; 16-byte Reload
	ldr	q6, [sp, #7008]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	ldr	q0, [sp, #11808]                ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #11760]                ; 16-byte Reload
	bif.16b	v6, v7, v0
	ldr	q0, [sp, #6928]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q17, [sp, #6944]                ; 16-byte Reload
	bif.16b	v17, v7, v0
	ldr	q0, [sp, #6960]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q18, [sp, #6976]                ; 16-byte Reload
	bif.16b	v18, v7, v0
	ldr	q0, [sp, #6832]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q20, [sp, #6848]                ; 16-byte Reload
	bif.16b	v20, v7, v0
	ldr	x2, [sp, #4152]                 ; 8-byte Reload
	ldr	q0, [x2, #16]
	str	q6, [sp, #6992]                 ; 16-byte Spill
	bit.16b	v0, v6, v13
	ldr	q6, [x2]
	str	q16, [sp, #7008]                ; 16-byte Spill
	bit.16b	v6, v16, v8
	stp	q6, q0, [x2]
	ldr	q0, [sp, #6864]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6880]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	ldr	q0, [sp, #6736]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6752]                 ; 16-byte Reload
	mov.16b	v21, v0
	bsl.16b	v21, v6, v7
	ldr	x2, [sp, #4144]                 ; 8-byte Reload
	ldp	q6, q0, [x2]
	str	q18, [sp, #6960]                ; 16-byte Spill
	bit.16b	v0, v18, v13
	str	q17, [sp, #6976]                ; 16-byte Spill
	bit.16b	v6, v17, v8
	stp	q6, q0, [x2]
	ldr	q0, [sp, #6768]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6784]                 ; 16-byte Reload
	mov.16b	v17, v0
	bsl.16b	v17, v6, v7
	ldr	q0, [sp, #6640]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6656]                 ; 16-byte Reload
	mov.16b	v18, v0
	bsl.16b	v18, v6, v7
	ldp	q6, q0, [x7]
	str	q16, [sp, #6928]                ; 16-byte Spill
	bit.16b	v0, v16, v13
	str	q20, [sp, #6944]                ; 16-byte Spill
	bit.16b	v6, v20, v8
	stp	q6, q0, [x7]
	ldr	q0, [sp, #6672]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6688]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	ldr	q0, [sp, #6544]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6560]                 ; 16-byte Reload
	mov.16b	v20, v0
	bsl.16b	v20, v6, v7
	ldp	q6, q0, [x19]
	str	q17, [sp, #6896]                ; 16-byte Spill
	bit.16b	v0, v17, v13
	str	q21, [sp, #6912]                ; 16-byte Spill
	bit.16b	v6, v21, v8
	stp	q6, q0, [x19]
	ldr	q0, [sp, #6576]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6592]                 ; 16-byte Reload
	mov.16b	v17, v0
	bsl.16b	v17, v6, v7
	ldr	q0, [sp, #6448]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6464]                 ; 16-byte Reload
	mov.16b	v21, v0
	bsl.16b	v21, v6, v7
	ldp	q6, q0, [x20]
	str	q16, [sp, #6864]                ; 16-byte Spill
	bit.16b	v0, v16, v13
	str	q18, [sp, #6880]                ; 16-byte Spill
	bit.16b	v6, v18, v8
	stp	q6, q0, [x20]
	ldr	q0, [sp, #6480]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6496]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	ldr	q0, [sp, #6352]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6368]                 ; 16-byte Reload
	mov.16b	v18, v0
	bsl.16b	v18, v6, v7
	ldp	q6, q0, [x21]
	str	q17, [sp, #6832]                ; 16-byte Spill
	bit.16b	v0, v17, v13
	str	q20, [sp, #6848]                ; 16-byte Spill
	bit.16b	v6, v20, v8
	stp	q6, q0, [x21]
	ldr	q0, [sp, #6384]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6400]                 ; 16-byte Reload
	mov.16b	v17, v0
	bsl.16b	v17, v6, v7
	ldr	q0, [sp, #6288]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6304]                 ; 16-byte Reload
	mov.16b	v20, v0
	bsl.16b	v20, v6, v7
	ldp	q6, q0, [x23]
	str	q16, [sp, #6800]                ; 16-byte Spill
	bit.16b	v0, v16, v13
	str	q21, [sp, #6816]                ; 16-byte Spill
	bit.16b	v6, v21, v8
	stp	q6, q0, [x23]
	ldr	q0, [sp, #6320]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6336]                 ; 16-byte Reload
	mov.16b	v21, v0
	bsl.16b	v21, v6, v7
	ldr	q0, [sp, #6256]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6272]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	ldp	q6, q0, [x24]
	str	q17, [sp, #6768]                ; 16-byte Spill
	bit.16b	v0, v17, v13
	str	q18, [sp, #6784]                ; 16-byte Spill
	bit.16b	v6, v18, v8
	stp	q6, q0, [x24]
	ldr	q0, [sp, #6416]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6432]                 ; 16-byte Reload
	mov.16b	v17, v0
	bsl.16b	v17, v6, v7
	ldr	q0, [sp, #6224]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6240]                 ; 16-byte Reload
	mov.16b	v18, v0
	bsl.16b	v18, v6, v7
	ldp	q6, q0, [x25]
	str	q21, [sp, #6720]                ; 16-byte Spill
	bit.16b	v0, v21, v13
	str	q20, [sp, #6752]                ; 16-byte Spill
	bit.16b	v6, v20, v8
	stp	q6, q0, [x25]
	ldr	q0, [sp, #6512]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6528]                 ; 16-byte Reload
	mov.16b	v20, v0
	bsl.16b	v20, v6, v7
	ldr	q0, [sp, #6192]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6208]                 ; 16-byte Reload
	mov.16b	v21, v0
	bsl.16b	v21, v6, v7
	ldp	q0, q6, [x26]
	str	q17, [sp, #6704]                ; 16-byte Spill
	bit.16b	v0, v17, v8
	str	q16, [sp, #6736]                ; 16-byte Spill
	bit.16b	v6, v16, v13
	stp	q0, q6, [x26]
	ldr	q0, [sp, #6608]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6624]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	fcmeq.4s	v0, v29, v29
	ldr	q6, [sp, #6160]                 ; 16-byte Reload
	mov.16b	v17, v0
	bsl.16b	v17, v6, v7
	ldp	q0, q6, [x27]
	str	q20, [sp, #6672]                ; 16-byte Spill
	bit.16b	v0, v20, v8
	str	q18, [sp, #6688]                ; 16-byte Spill
	bit.16b	v6, v18, v13
	stp	q0, q6, [x27]
	fcmeq.4s	v0, v31, v31
	ldr	q6, [sp, #6176]                 ; 16-byte Reload
	mov.16b	v18, v0
	bsl.16b	v18, v6, v7
	fcmeq.4s	v0, v27, v27
	ldr	q6, [sp, #6128]                 ; 16-byte Reload
	mov.16b	v20, v0
	bsl.16b	v20, v6, v7
	ldp	q0, q6, [x28]
	str	q16, [sp, #6640]                ; 16-byte Spill
	bit.16b	v0, v16, v8
	str	q21, [sp, #6656]                ; 16-byte Spill
	bit.16b	v6, v21, v13
	stp	q0, q6, [x28]
	fcmeq.4s	v0, v28, v28
	ldr	q6, [sp, #6144]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	fcmeq.4s	v0, v25, v25
	ldr	q6, [sp, #6112]                 ; 16-byte Reload
	mov.16b	v21, v0
	bsl.16b	v21, v6, v7
	ldp	q0, q6, [x30]
	str	q18, [sp, #6608]                ; 16-byte Spill
	bit.16b	v0, v18, v8
	str	q17, [sp, #6624]                ; 16-byte Spill
	bit.16b	v6, v17, v13
	stp	q0, q6, [x30]
	fcmeq.4s	v0, v26, v26
	ldr	q6, [sp, #6080]                 ; 16-byte Reload
	bif.16b	v6, v7, v0
	fcmeq.4s	v0, v19, v19
	mov.16b	v17, v0
	bsl.16b	v17, v12, v7
	fcmeq.4s	v0, v4, v4
	ldr	q4, [sp, #6096]                 ; 16-byte Reload
	mov.16b	v18, v0
	bsl.16b	v18, v4, v7
	ldp	q4, q0, [x13]
	str	q16, [sp, #6576]                ; 16-byte Spill
	bit.16b	v0, v16, v13
	str	q20, [sp, #6592]                ; 16-byte Spill
	bit.16b	v4, v20, v8
	stp	q4, q0, [x13]
	ldp	q0, q4, [x0]
	str	q6, [sp, #6544]                 ; 16-byte Spill
	bit.16b	v0, v6, v8
	str	q21, [sp, #6560]                ; 16-byte Spill
	bit.16b	v4, v21, v13
	stp	q0, q4, [x0]
	ldp	q0, q4, [x14]
	str	q18, [sp, #6512]                ; 16-byte Spill
	bit.16b	v0, v18, v8
	str	q17, [sp, #6528]                ; 16-byte Spill
	bit.16b	v4, v17, v13
	stp	q0, q4, [x14]
	fcmeq.4s	v0, v2, v2
	mov.16b	v6, v0
	bsl.16b	v6, v3, v7
	fcmeq.4s	v0, v1, v1
	mov.16b	v1, v0
	bsl.16b	v1, v5, v7
	ldr	q0, [sp, #9664]                 ; 16-byte Reload
	fmul.4s	v0, v0, v6
	ldr	q5, [sp, #9408]                 ; 16-byte Reload
	bit.16b	v5, v0, v8
	ldr	q0, [sp, #9680]                 ; 16-byte Reload
	str	q1, [sp, #11808]                ; 16-byte Spill
	fmul.4s	v0, v0, v1
	ldr	q4, [sp, #9392]                 ; 16-byte Reload
	bit.16b	v4, v0, v13
	mov	x2, x9
	mov.16b	v30, v8
LBB0_1098:                              ; %direct.true1234
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v5, v0
	fadd.4s	v1, v4, v1
	bit.16b	v4, v1, v13
	bit.16b	v5, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1098
; %bb.1099:                             ; %direct.false1235
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q5, [sp, #9408]                 ; 16-byte Spill
	str	q4, [sp, #9392]                 ; 16-byte Spill
	str	q1, [sp, #6480]                 ; 16-byte Spill
	str	q0, [sp, #6496]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #9696]                 ; 16-byte Reload
	str	q6, [sp, #11760]                ; 16-byte Spill
	fmul.4s	v0, v0, v6
	ldr	q1, [sp, #9712]                 ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q14, [sp, #9248]                ; 16-byte Reload
	bit.16b	v14, v1, v13
	ldr	q15, [sp, #9264]                ; 16-byte Reload
	bit.16b	v15, v0, v30
	ldr	x2, [sp, #4776]                 ; 8-byte Reload
	ldr	q31, [sp, #9296]                ; 16-byte Reload
	ldr	q8, [sp, #9216]                 ; 16-byte Reload
	ldr	q27, [sp, #9184]                ; 16-byte Reload
	ldr	q9, [sp, #9168]                 ; 16-byte Reload
	ldr	q20, [sp, #9152]                ; 16-byte Reload
	ldr	q6, [sp, #9136]                 ; 16-byte Reload
	ldr	q19, [sp, #9088]                ; 16-byte Reload
	ldr	q25, [sp, #9040]                ; 16-byte Reload
	ldr	q29, [sp, #8912]                ; 16-byte Reload
	ldr	q26, [sp, #8880]                ; 16-byte Reload
	ldr	q24, [sp, #8720]                ; 16-byte Reload
	ldr	q11, [sp, #8688]                ; 16-byte Reload
	ldr	q21, [sp, #8592]                ; 16-byte Reload
	ldr	q28, [sp, #8528]                ; 16-byte Reload
	ldr	q10, [sp, #8496]                ; 16-byte Reload
	ldr	q17, [sp, #8400]                ; 16-byte Reload
	ldr	q12, [sp, #8336]                ; 16-byte Reload
	ldr	q23, [sp, #8304]                ; 16-byte Reload
	ldr	q16, [sp, #8208]                ; 16-byte Reload
	ldr	q5, [sp, #8144]                 ; 16-byte Reload
	ldr	q7, [sp, #8112]                 ; 16-byte Reload
	ldr	q4, [sp, #8016]                 ; 16-byte Reload
	ldr	q22, [sp, #7952]                ; 16-byte Reload
	ldr	q18, [sp, #7920]                ; 16-byte Reload
LBB0_1100:                              ; %direct.true1251
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v15, v0
	fadd.4s	v1, v14, v1
	bit.16b	v14, v1, v13
	bit.16b	v15, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1100
; %bb.1101:                             ; %direct.false1252
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q15, [sp, #9264]                ; 16-byte Spill
	str	q14, [sp, #9248]                ; 16-byte Spill
	str	q1, [sp, #6448]                 ; 16-byte Spill
	str	q0, [sp, #6464]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #9728]                 ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #9744]                 ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q14, [sp, #9280]                ; 16-byte Reload
	bit.16b	v14, v1, v13
	bit.16b	v31, v0, v30
	ldr	x2, [sp, #4768]                 ; 8-byte Reload
LBB0_1102:                              ; %direct.true1268
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v31, v0
	fadd.4s	v1, v14, v1
	bit.16b	v14, v1, v13
	bit.16b	v31, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1102
; %bb.1103:                             ; %direct.false1269
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q31, [sp, #9296]                ; 16-byte Spill
	str	q1, [sp, #6416]                 ; 16-byte Spill
	str	q0, [sp, #6432]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #9760]                 ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #9776]                 ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q15, [sp, #9312]                ; 16-byte Reload
	bit.16b	v15, v1, v13
	ldr	q31, [sp, #9328]                ; 16-byte Reload
	bit.16b	v31, v0, v30
	ldr	x2, [sp, #4760]                 ; 8-byte Reload
LBB0_1104:                              ; %direct.true1285
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v31, v0
	fadd.4s	v1, v15, v1
	bit.16b	v15, v1, v13
	bit.16b	v31, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1104
; %bb.1105:                             ; %direct.false1286
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q15, [sp, #9312]                ; 16-byte Spill
	str	q31, [sp, #9328]                ; 16-byte Spill
	str	q1, [sp, #6384]                 ; 16-byte Spill
	str	q0, [sp, #6400]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #9792]                 ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #9808]                 ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v20, v1, v13
	bit.16b	v9, v0, v30
	ldr	x2, [sp, #4752]                 ; 8-byte Reload
LBB0_1106:                              ; %direct.true1302
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v9, v0
	fadd.4s	v1, v20, v1
	bit.16b	v20, v1, v13
	bit.16b	v9, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1106
; %bb.1107:                             ; %direct.false1303
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q14, [sp, #9280]                ; 16-byte Spill
	str	q1, [sp, #6352]                 ; 16-byte Spill
	str	q0, [sp, #6368]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #9824]                 ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #9840]                 ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v27, v1, v13
	ldr	q14, [sp, #9200]                ; 16-byte Reload
	bit.16b	v14, v0, v30
	ldr	x2, [sp, #4744]                 ; 8-byte Reload
	ldr	q31, [sp, #9056]                ; 16-byte Reload
	ldr	q15, [sp, #9120]                ; 16-byte Reload
LBB0_1108:                              ; %direct.true1319
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v14, v0
	fadd.4s	v1, v27, v1
	bit.16b	v27, v1, v13
	bit.16b	v14, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1108
; %bb.1109:                             ; %direct.false1320
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q14, [sp, #9200]                ; 16-byte Spill
	str	q1, [sp, #6320]                 ; 16-byte Spill
	str	q0, [sp, #6336]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #9856]                 ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #9872]                 ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v8, v1, v13
	ldr	q14, [sp, #9232]                ; 16-byte Reload
	bit.16b	v14, v0, v30
	ldr	x2, [sp, #4736]                 ; 8-byte Reload
LBB0_1110:                              ; %direct.true1336
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v14, v0
	fadd.4s	v1, v8, v1
	bit.16b	v8, v1, v13
	bit.16b	v14, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1110
; %bb.1111:                             ; %direct.false1337
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q14, [sp, #9232]                ; 16-byte Spill
	str	q1, [sp, #6288]                 ; 16-byte Spill
	str	q0, [sp, #6304]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #9888]                 ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #9904]                 ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v31, v1, v13
	ldr	q14, [sp, #9072]                ; 16-byte Reload
	bit.16b	v14, v0, v30
	ldr	x2, [sp, #4728]                 ; 8-byte Reload
LBB0_1112:                              ; %direct.true1353
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v14, v0
	fadd.4s	v1, v31, v1
	bit.16b	v31, v1, v13
	bit.16b	v14, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1112
; %bb.1113:                             ; %direct.false1354
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q14, [sp, #9072]                ; 16-byte Spill
	str	q1, [sp, #6256]                 ; 16-byte Spill
	str	q0, [sp, #6272]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #9920]                 ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #9936]                 ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v19, v1, v13
	ldr	q14, [sp, #9104]                ; 16-byte Reload
	bit.16b	v14, v0, v30
	ldr	x2, [sp, #4720]                 ; 8-byte Reload
LBB0_1114:                              ; %direct.true1370
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v14, v0
	fadd.4s	v1, v19, v1
	bit.16b	v19, v1, v13
	bit.16b	v14, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1114
; %bb.1115:                             ; %direct.false1371
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #6224]                 ; 16-byte Spill
	str	q0, [sp, #6240]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #9968]                 ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #9952]                 ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v15, v1, v13
	bit.16b	v6, v0, v30
	ldr	x2, [sp, #4712]                 ; 8-byte Reload
LBB0_1116:                              ; %direct.true1387
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v6, v0
	fadd.4s	v1, v15, v1
	bit.16b	v15, v1, v13
	bit.16b	v6, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1116
; %bb.1117:                             ; %direct.false1388
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q15, [sp, #9120]                ; 16-byte Spill
	str	q27, [sp, #9184]                ; 16-byte Spill
	str	q1, [sp, #6192]                 ; 16-byte Spill
	str	q0, [sp, #6208]                 ; 16-byte Spill
	str	q8, [sp, #9216]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #9984]                 ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #10000]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q15, [sp, #8960]                ; 16-byte Reload
	bit.16b	v15, v1, v13
	ldr	q27, [sp, #8976]                ; 16-byte Reload
	bit.16b	v27, v0, v30
	ldr	x2, [sp, #4704]                 ; 8-byte Reload
LBB0_1118:                              ; %direct.true1404
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v27, v0
	fadd.4s	v1, v15, v1
	bit.16b	v15, v1, v13
	bit.16b	v27, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1118
; %bb.1119:                             ; %direct.false1405
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q27, [sp, #8976]                ; 16-byte Spill
	str	q1, [sp, #6160]                 ; 16-byte Spill
	str	q0, [sp, #6176]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10016]                ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #10032]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q27, [sp, #8992]                ; 16-byte Reload
	bit.16b	v27, v1, v13
	ldr	q8, [sp, #9008]                 ; 16-byte Reload
	bit.16b	v8, v0, v30
	ldr	x2, [sp, #4696]                 ; 8-byte Reload
LBB0_1120:                              ; %direct.true1421
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v8, v0
	fadd.4s	v1, v27, v1
	bit.16b	v27, v1, v13
	bit.16b	v8, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1120
; %bb.1121:                             ; %direct.false1422
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #6128]                 ; 16-byte Spill
	str	q0, [sp, #6144]                 ; 16-byte Spill
	str	q27, [sp, #8992]                ; 16-byte Spill
	str	q8, [sp, #9008]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10048]                ; 16-byte Reload
	ldr	q27, [sp, #11760]               ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10064]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q8, [sp, #9024]                 ; 16-byte Reload
	bit.16b	v8, v1, v13
	bit.16b	v25, v0, v30
	ldr	x2, [sp, #4688]                 ; 8-byte Reload
LBB0_1122:                              ; %direct.true1438
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v25, v0
	fadd.4s	v1, v8, v1
	bit.16b	v8, v1, v13
	bit.16b	v25, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1122
; %bb.1123:                             ; %direct.false1439
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #6096]                 ; 16-byte Spill
	str	q0, [sp, #6112]                 ; 16-byte Spill
	str	q25, [sp, #9040]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10080]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10096]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q25, [sp, #8864]                ; 16-byte Reload
	bit.16b	v25, v1, v13
	bit.16b	v26, v0, v30
	ldr	x2, [sp, #4680]                 ; 8-byte Reload
	str	q15, [sp, #8960]                ; 16-byte Spill
LBB0_1124:                              ; %direct.true1455
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v26, v0
	fadd.4s	v1, v25, v1
	bit.16b	v25, v1, v13
	bit.16b	v26, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1124
; %bb.1125:                             ; %direct.false1456
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #6064]                 ; 16-byte Spill
	str	q0, [sp, #6080]                 ; 16-byte Spill
	str	q25, [sp, #8864]                ; 16-byte Spill
	str	q26, [sp, #8880]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10112]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10128]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q26, [sp, #8896]                ; 16-byte Reload
	bit.16b	v26, v1, v13
	bit.16b	v29, v0, v30
	ldr	x2, [sp, #4672]                 ; 8-byte Reload
	ldr	q15, [sp, #7808]                ; 16-byte Reload
LBB0_1126:                              ; %direct.true1472
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v29, v0
	fadd.4s	v1, v26, v1
	bit.16b	v26, v1, v13
	bit.16b	v29, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1126
; %bb.1127:                             ; %direct.false1473
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #6032]                 ; 16-byte Spill
	str	q0, [sp, #6048]                 ; 16-byte Spill
	str	q26, [sp, #8896]                ; 16-byte Spill
	str	q29, [sp, #8912]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10144]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10160]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q29, [sp, #8928]                ; 16-byte Reload
	bit.16b	v29, v1, v13
	ldr	q26, [sp, #8944]                ; 16-byte Reload
	bit.16b	v26, v0, v30
	ldr	x2, [sp, #4664]                 ; 8-byte Reload
	ldr	q27, [sp, #8848]                ; 16-byte Reload
	ldr	q25, [sp, #7616]                ; 16-byte Reload
LBB0_1128:                              ; %direct.true1489
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v26, v0
	fadd.4s	v1, v29, v1
	bit.16b	v29, v1, v13
	bit.16b	v26, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1128
; %bb.1129:                             ; %direct.false1490
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #6000]                 ; 16-byte Spill
	str	q0, [sp, #6016]                 ; 16-byte Spill
	str	q9, [sp, #9168]                 ; 16-byte Spill
	str	q29, [sp, #8928]                ; 16-byte Spill
	str	q26, [sp, #8944]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10192]                ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #10240]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q29, [sp, #8768]                ; 16-byte Reload
	bit.16b	v29, v1, v13
	ldr	q26, [sp, #8784]                ; 16-byte Reload
	bit.16b	v26, v0, v30
	mov	x2, x10
LBB0_1130:                              ; %direct.true1506
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x2], #32
	add	x3, x22, x1
	ldp	q2, q3, [x3]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v26, v0
	fadd.4s	v1, v29, v1
	bit.16b	v29, v1, v13
	bit.16b	v26, v0, v30
	add	x1, x1, #2048
	cmp	x1, #8, lsl #12                 ; =32768
	b.ne	LBB0_1130
; %bb.1131:                             ; %direct.false1507
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5968]                 ; 16-byte Spill
	str	q0, [sp, #5984]                 ; 16-byte Spill
	str	q29, [sp, #8768]                ; 16-byte Spill
	str	q26, [sp, #8784]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10256]                ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #10304]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q9, [sp, #8800]                 ; 16-byte Reload
	bit.16b	v9, v1, v13
	ldr	q29, [sp, #8816]                ; 16-byte Reload
	bit.16b	v29, v0, v30
	ldr	x2, [sp, #4656]                 ; 8-byte Reload
	ldr	q26, [sp, #8832]                ; 16-byte Reload
LBB0_1132:                              ; %direct.true1523
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v29, v0
	fadd.4s	v1, v9, v1
	bit.16b	v9, v1, v13
	bit.16b	v29, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1132
; %bb.1133:                             ; %direct.false1524
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q29, [sp, #8816]                ; 16-byte Spill
	str	q1, [sp, #5936]                 ; 16-byte Spill
	str	q0, [sp, #5952]                 ; 16-byte Spill
	str	q20, [sp, #9152]                ; 16-byte Spill
	str	q9, [sp, #8800]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10336]                ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #10368]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v26, v1, v13
	bit.16b	v27, v0, v30
	ldr	x2, [sp, #4648]                 ; 8-byte Reload
	ldr	q29, [sp, #7472]                ; 16-byte Reload
LBB0_1134:                              ; %direct.true1540
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v27, v0
	fadd.4s	v1, v26, v1
	bit.16b	v26, v1, v13
	bit.16b	v27, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1134
; %bb.1135:                             ; %direct.false1541
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q27, [sp, #8848]                ; 16-byte Spill
	str	q1, [sp, #5904]                 ; 16-byte Spill
	str	q0, [sp, #5920]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10176]                ; 16-byte Reload
	ldr	q27, [sp, #11760]               ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10208]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q20, [sp, #8672]                ; 16-byte Reload
	bit.16b	v20, v1, v13
	bit.16b	v11, v0, v30
	ldr	x2, [sp, #4640]                 ; 8-byte Reload
	ldr	q9, [sp, #8752]                 ; 16-byte Reload
LBB0_1136:                              ; %direct.true1557
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v11, v0
	fadd.4s	v1, v20, v1
	bit.16b	v20, v1, v13
	bit.16b	v11, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1136
; %bb.1137:                             ; %direct.false1558
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5872]                 ; 16-byte Spill
	str	q0, [sp, #5888]                 ; 16-byte Spill
	str	q20, [sp, #8672]                ; 16-byte Spill
	str	q11, [sp, #8688]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10224]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10272]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q11, [sp, #8704]                ; 16-byte Reload
	bit.16b	v11, v1, v13
	bit.16b	v24, v0, v30
	ldr	x2, [sp, #4632]                 ; 8-byte Reload
LBB0_1138:                              ; %direct.true1574
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v24, v0
	fadd.4s	v1, v11, v1
	bit.16b	v11, v1, v13
	bit.16b	v24, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1138
; %bb.1139:                             ; %direct.false1575
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5840]                 ; 16-byte Spill
	str	q0, [sp, #5856]                 ; 16-byte Spill
	str	q11, [sp, #8704]                ; 16-byte Spill
	str	q24, [sp, #8720]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10288]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10320]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q24, [sp, #8736]                ; 16-byte Reload
	bit.16b	v24, v1, v13
	bit.16b	v9, v0, v30
	ldr	x2, [sp, #4624]                 ; 8-byte Reload
	ldr	q20, [sp, #8656]                ; 16-byte Reload
LBB0_1140:                              ; %direct.true1591
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v9, v0
	fadd.4s	v1, v24, v1
	bit.16b	v24, v1, v13
	bit.16b	v9, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1140
; %bb.1141:                             ; %direct.false1592
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5808]                 ; 16-byte Spill
	str	q0, [sp, #5824]                 ; 16-byte Spill
	str	q24, [sp, #8736]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10352]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10384]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q24, [sp, #8576]                ; 16-byte Reload
	bit.16b	v24, v1, v13
	bit.16b	v21, v0, v30
	ldr	x2, [sp, #4616]                 ; 8-byte Reload
	ldr	q11, [sp, #8624]                ; 16-byte Reload
LBB0_1142:                              ; %direct.true1608
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v21, v0
	fadd.4s	v1, v24, v1
	bit.16b	v24, v1, v13
	bit.16b	v21, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1142
; %bb.1143:                             ; %direct.false1609
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5776]                 ; 16-byte Spill
	str	q0, [sp, #5792]                 ; 16-byte Spill
	str	q24, [sp, #8576]                ; 16-byte Spill
	str	q21, [sp, #8592]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10400]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10416]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q21, [sp, #8608]                ; 16-byte Reload
	bit.16b	v21, v1, v13
	bit.16b	v11, v0, v30
	ldr	x2, [sp, #4608]                 ; 8-byte Reload
	ldr	q24, [sp, #8640]                ; 16-byte Reload
LBB0_1144:                              ; %direct.true1625
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v11, v0
	fadd.4s	v1, v21, v1
	bit.16b	v21, v1, v13
	bit.16b	v11, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1144
; %bb.1145:                             ; %direct.false1626
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5744]                 ; 16-byte Spill
	str	q0, [sp, #5760]                 ; 16-byte Spill
	str	q19, [sp, #9088]                ; 16-byte Spill
	str	q21, [sp, #8608]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10432]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10448]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v24, v1, v13
	bit.16b	v20, v0, v30
	ldr	x2, [sp, #4600]                 ; 8-byte Reload
LBB0_1146:                              ; %direct.true1642
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v20, v0
	fadd.4s	v1, v24, v1
	bit.16b	v24, v1, v13
	bit.16b	v20, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1146
; %bb.1147:                             ; %direct.false1643
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5712]                 ; 16-byte Spill
	str	q0, [sp, #5728]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10464]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10480]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q19, [sp, #8480]                ; 16-byte Reload
	bit.16b	v19, v1, v13
	bit.16b	v10, v0, v30
	ldr	x2, [sp, #4592]                 ; 8-byte Reload
	ldr	q21, [sp, #8560]                ; 16-byte Reload
LBB0_1148:                              ; %direct.true1659
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v10, v0
	fadd.4s	v1, v19, v1
	bit.16b	v19, v1, v13
	bit.16b	v10, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1148
; %bb.1149:                             ; %direct.false1660
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5680]                 ; 16-byte Spill
	str	q0, [sp, #5696]                 ; 16-byte Spill
	str	q19, [sp, #8480]                ; 16-byte Spill
	str	q10, [sp, #8496]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10496]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10512]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q10, [sp, #8512]                ; 16-byte Reload
	bit.16b	v10, v1, v13
	bit.16b	v28, v0, v30
	ldr	x2, [sp, #4584]                 ; 8-byte Reload
LBB0_1150:                              ; %direct.true1676
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v28, v0
	fadd.4s	v1, v10, v1
	bit.16b	v10, v1, v13
	bit.16b	v28, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1150
; %bb.1151:                             ; %direct.false1677
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5648]                 ; 16-byte Spill
	str	q0, [sp, #5664]                 ; 16-byte Spill
	str	q10, [sp, #8512]                ; 16-byte Spill
	str	q28, [sp, #8528]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10528]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10544]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q28, [sp, #8544]                ; 16-byte Reload
	bit.16b	v28, v1, v13
	bit.16b	v21, v0, v30
	ldr	x2, [sp, #4576]                 ; 8-byte Reload
	ldr	q19, [sp, #8464]                ; 16-byte Reload
LBB0_1152:                              ; %direct.true1693
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v21, v0
	fadd.4s	v1, v28, v1
	bit.16b	v28, v1, v13
	bit.16b	v21, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1152
; %bb.1153:                             ; %direct.false1694
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5616]                 ; 16-byte Spill
	str	q0, [sp, #5632]                 ; 16-byte Spill
	str	q28, [sp, #8544]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10560]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10576]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q28, [sp, #8384]                ; 16-byte Reload
	bit.16b	v28, v1, v13
	bit.16b	v17, v0, v30
	ldr	x2, [sp, #4568]                 ; 8-byte Reload
	ldr	q10, [sp, #8432]                ; 16-byte Reload
LBB0_1154:                              ; %direct.true1710
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v17, v0
	fadd.4s	v1, v28, v1
	bit.16b	v28, v1, v13
	bit.16b	v17, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1154
; %bb.1155:                             ; %direct.false1711
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5584]                 ; 16-byte Spill
	str	q0, [sp, #5600]                 ; 16-byte Spill
	str	q28, [sp, #8384]                ; 16-byte Spill
	str	q17, [sp, #8400]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10592]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10608]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q17, [sp, #8416]                ; 16-byte Reload
	bit.16b	v17, v1, v13
	bit.16b	v10, v0, v30
	ldr	x2, [sp, #4560]                 ; 8-byte Reload
	ldr	q28, [sp, #8448]                ; 16-byte Reload
LBB0_1156:                              ; %direct.true1727
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v10, v0
	fadd.4s	v1, v17, v1
	bit.16b	v17, v1, v13
	bit.16b	v10, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1156
; %bb.1157:                             ; %direct.false1728
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5552]                 ; 16-byte Spill
	str	q0, [sp, #5568]                 ; 16-byte Spill
	str	q6, [sp, #9136]                 ; 16-byte Spill
	str	q17, [sp, #8416]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10624]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10640]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v28, v1, v13
	bit.16b	v19, v0, v30
	ldr	x2, [sp, #4552]                 ; 8-byte Reload
LBB0_1158:                              ; %direct.true1744
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v19, v0
	fadd.4s	v1, v28, v1
	bit.16b	v28, v1, v13
	bit.16b	v19, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1158
; %bb.1159:                             ; %direct.false1745
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5520]                 ; 16-byte Spill
	str	q0, [sp, #5536]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10656]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10672]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q6, [sp, #8288]                 ; 16-byte Reload
	bit.16b	v6, v1, v13
	bit.16b	v23, v0, v30
	ldr	x2, [sp, #4544]                 ; 8-byte Reload
	ldr	q17, [sp, #8368]                ; 16-byte Reload
LBB0_1160:                              ; %direct.true1761
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v23, v0
	fadd.4s	v1, v6, v1
	bit.16b	v6, v1, v13
	bit.16b	v23, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1160
; %bb.1161:                             ; %direct.false1762
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5488]                 ; 16-byte Spill
	str	q0, [sp, #5504]                 ; 16-byte Spill
	str	q6, [sp, #8288]                 ; 16-byte Spill
	str	q23, [sp, #8304]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10688]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10704]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q23, [sp, #8320]                ; 16-byte Reload
	bit.16b	v23, v1, v13
	bit.16b	v12, v0, v30
	ldr	x2, [sp, #4536]                 ; 8-byte Reload
LBB0_1162:                              ; %direct.true1778
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v12, v0
	fadd.4s	v1, v23, v1
	bit.16b	v23, v1, v13
	bit.16b	v12, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1162
; %bb.1163:                             ; %direct.false1779
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5456]                 ; 16-byte Spill
	str	q0, [sp, #5472]                 ; 16-byte Spill
	str	q23, [sp, #8320]                ; 16-byte Spill
	str	q12, [sp, #8336]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10720]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10736]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q12, [sp, #8352]                ; 16-byte Reload
	bit.16b	v12, v1, v13
	bit.16b	v17, v0, v30
	ldr	x2, [sp, #4528]                 ; 8-byte Reload
	ldr	q6, [sp, #8272]                 ; 16-byte Reload
LBB0_1164:                              ; %direct.true1795
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v17, v0
	fadd.4s	v1, v12, v1
	bit.16b	v12, v1, v13
	bit.16b	v17, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1164
; %bb.1165:                             ; %direct.false1796
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5424]                 ; 16-byte Spill
	str	q0, [sp, #5440]                 ; 16-byte Spill
	str	q12, [sp, #8352]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10752]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10768]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q12, [sp, #8192]                ; 16-byte Reload
	bit.16b	v12, v1, v13
	bit.16b	v16, v0, v30
	ldr	x2, [sp, #4520]                 ; 8-byte Reload
	ldr	q23, [sp, #8256]                ; 16-byte Reload
LBB0_1166:                              ; %direct.true1812
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v16, v0
	fadd.4s	v1, v12, v1
	bit.16b	v12, v1, v13
	bit.16b	v16, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1166
; %bb.1167:                             ; %direct.false1813
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5392]                 ; 16-byte Spill
	str	q0, [sp, #5408]                 ; 16-byte Spill
	str	q12, [sp, #8192]                ; 16-byte Spill
	str	q16, [sp, #8208]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10784]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10800]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q16, [sp, #8224]                ; 16-byte Reload
	bit.16b	v16, v1, v13
	ldr	q12, [sp, #8240]                ; 16-byte Reload
	bit.16b	v12, v0, v30
	ldr	x2, [sp, #4512]                 ; 8-byte Reload
LBB0_1168:                              ; %direct.true1829
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v12, v0
	fadd.4s	v1, v16, v1
	bit.16b	v16, v1, v13
	bit.16b	v12, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1168
; %bb.1169:                             ; %direct.false1830
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5360]                 ; 16-byte Spill
	str	q0, [sp, #5376]                 ; 16-byte Spill
	str	q8, [sp, #9024]                 ; 16-byte Spill
	str	q16, [sp, #8224]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10816]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10832]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v23, v1, v13
	bit.16b	v6, v0, v30
	ldr	x2, [sp, #4504]                 ; 8-byte Reload
LBB0_1170:                              ; %direct.true1846
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v6, v0
	fadd.4s	v1, v23, v1
	bit.16b	v23, v1, v13
	bit.16b	v6, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1170
; %bb.1171:                             ; %direct.false1847
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5328]                 ; 16-byte Spill
	str	q0, [sp, #5344]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10848]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10864]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q8, [sp, #8096]                 ; 16-byte Reload
	bit.16b	v8, v1, v13
	bit.16b	v7, v0, v30
	ldr	x2, [sp, #4496]                 ; 8-byte Reload
	ldr	q16, [sp, #8176]                ; 16-byte Reload
LBB0_1172:                              ; %direct.true1863
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v7, v0
	fadd.4s	v1, v8, v1
	bit.16b	v8, v1, v13
	bit.16b	v7, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1172
; %bb.1173:                             ; %direct.false1864
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5296]                 ; 16-byte Spill
	str	q0, [sp, #5312]                 ; 16-byte Spill
	str	q8, [sp, #8096]                 ; 16-byte Spill
	str	q7, [sp, #8112]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10880]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10896]                ; 16-byte Reload
	ldr	q8, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v8
	ldr	q7, [sp, #8128]                 ; 16-byte Reload
	bit.16b	v7, v1, v13
	bit.16b	v5, v0, v30
	ldr	x2, [sp, #4488]                 ; 8-byte Reload
LBB0_1174:                              ; %direct.true1880
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v5, v0
	fadd.4s	v1, v7, v1
	bit.16b	v7, v1, v13
	bit.16b	v5, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1174
; %bb.1175:                             ; %direct.false1881
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5264]                 ; 16-byte Spill
	str	q0, [sp, #5280]                 ; 16-byte Spill
	str	q7, [sp, #8128]                 ; 16-byte Spill
	str	q5, [sp, #8144]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10912]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10928]                ; 16-byte Reload
	fmul.4s	v1, v1, v8
	ldr	q5, [sp, #8160]                 ; 16-byte Reload
	bit.16b	v5, v1, v13
	bit.16b	v16, v0, v30
	ldr	x2, [sp, #4480]                 ; 8-byte Reload
	ldr	q8, [sp, #8048]                 ; 16-byte Reload
LBB0_1176:                              ; %direct.true1897
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v16, v0
	fadd.4s	v1, v5, v1
	bit.16b	v5, v1, v13
	bit.16b	v16, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1176
; %bb.1177:                             ; %direct.false1898
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5232]                 ; 16-byte Spill
	str	q0, [sp, #5248]                 ; 16-byte Spill
	str	q5, [sp, #8160]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10944]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10960]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q5, [sp, #8000]                 ; 16-byte Reload
	bit.16b	v5, v1, v13
	bit.16b	v4, v0, v30
	ldr	x2, [sp, #4472]                 ; 8-byte Reload
	ldr	q7, [sp, #8064]                 ; 16-byte Reload
LBB0_1178:                              ; %direct.true1914
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v4, v0
	fadd.4s	v1, v5, v1
	bit.16b	v5, v1, v13
	bit.16b	v4, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1178
; %bb.1179:                             ; %direct.false1915
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5200]                 ; 16-byte Spill
	str	q0, [sp, #5216]                 ; 16-byte Spill
	str	q5, [sp, #8000]                 ; 16-byte Spill
	str	q4, [sp, #8016]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #10976]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #10992]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q4, [sp, #8032]                 ; 16-byte Reload
	bit.16b	v4, v1, v13
	bit.16b	v8, v0, v30
	ldr	x2, [sp, #4464]                 ; 8-byte Reload
	ldr	q5, [sp, #8080]                 ; 16-byte Reload
LBB0_1180:                              ; %direct.true1931
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v8, v0
	fadd.4s	v1, v4, v1
	bit.16b	v4, v1, v13
	bit.16b	v8, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1180
; %bb.1181:                             ; %direct.false1932
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5168]                 ; 16-byte Spill
	str	q0, [sp, #5184]                 ; 16-byte Spill
	str	q14, [sp, #9104]                ; 16-byte Spill
	str	q4, [sp, #8032]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11008]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #11024]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v7, v1, v13
	bit.16b	v5, v0, v30
	ldr	x2, [sp, #4456]                 ; 8-byte Reload
LBB0_1182:                              ; %direct.true1948
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v5, v0
	fadd.4s	v1, v7, v1
	bit.16b	v7, v1, v13
	bit.16b	v5, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1182
; %bb.1183:                             ; %direct.false1949
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5136]                 ; 16-byte Spill
	str	q0, [sp, #5152]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11040]                ; 16-byte Reload
	fmul.4s	v0, v0, v27
	ldr	q1, [sp, #11056]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q14, [sp, #7904]                ; 16-byte Reload
	bit.16b	v14, v1, v13
	bit.16b	v18, v0, v30
	ldr	x2, [sp, #4448]                 ; 8-byte Reload
	ldr	q4, [sp, #7984]                 ; 16-byte Reload
LBB0_1184:                              ; %direct.true1965
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v18, v0
	fadd.4s	v1, v14, v1
	bit.16b	v14, v1, v13
	bit.16b	v18, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1184
; %bb.1185:                             ; %direct.false1966
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5104]                 ; 16-byte Spill
	str	q0, [sp, #5120]                 ; 16-byte Spill
	str	q14, [sp, #7904]                ; 16-byte Spill
	str	q18, [sp, #7920]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11072]                ; 16-byte Reload
	ldr	q14, [sp, #11760]               ; 16-byte Reload
	fmul.4s	v0, v0, v14
	ldr	q1, [sp, #11088]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q18, [sp, #7936]                ; 16-byte Reload
	bit.16b	v18, v1, v13
	bit.16b	v22, v0, v30
	ldr	x2, [sp, #4440]                 ; 8-byte Reload
LBB0_1186:                              ; %direct.true1982
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v22, v0
	fadd.4s	v1, v18, v1
	bit.16b	v18, v1, v13
	bit.16b	v22, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1186
; %bb.1187:                             ; %direct.false1983
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5072]                 ; 16-byte Spill
	str	q0, [sp, #5088]                 ; 16-byte Spill
	str	q18, [sp, #7936]                ; 16-byte Spill
	str	q22, [sp, #7952]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11104]                ; 16-byte Reload
	fmul.4s	v0, v0, v14
	ldr	q1, [sp, #11120]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q22, [sp, #7968]                ; 16-byte Reload
	bit.16b	v22, v1, v13
	bit.16b	v4, v0, v30
	ldr	x2, [sp, #4432]                 ; 8-byte Reload
	ldr	q14, [sp, #7856]                ; 16-byte Reload
LBB0_1188:                              ; %direct.true1999
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v4, v0
	fadd.4s	v1, v22, v1
	bit.16b	v22, v1, v13
	bit.16b	v4, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1188
; %bb.1189:                             ; %direct.false2000
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5040]                 ; 16-byte Spill
	str	q0, [sp, #5056]                 ; 16-byte Spill
	str	q22, [sp, #7968]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11136]                ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #11152]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v15, v1, v13
	ldr	q22, [sp, #7824]                ; 16-byte Reload
	bit.16b	v22, v0, v30
	ldr	x2, [sp, #4424]                 ; 8-byte Reload
	ldr	q18, [sp, #7888]                ; 16-byte Reload
LBB0_1190:                              ; %direct.true2016
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v22, v0
	fadd.4s	v1, v15, v1
	bit.16b	v15, v1, v13
	bit.16b	v22, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1190
; %bb.1191:                             ; %direct.false2017
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #5008]                 ; 16-byte Spill
	str	q0, [sp, #5024]                 ; 16-byte Spill
	str	q15, [sp, #7808]                ; 16-byte Spill
	str	q22, [sp, #7824]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11168]                ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #11184]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q15, [sp, #7840]                ; 16-byte Reload
	bit.16b	v15, v1, v13
	bit.16b	v14, v0, v30
	ldr	x2, [sp, #4416]                 ; 8-byte Reload
	ldr	q22, [sp, #7872]                ; 16-byte Reload
LBB0_1192:                              ; %direct.true2033
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v14, v0
	fadd.4s	v1, v15, v1
	bit.16b	v15, v1, v13
	bit.16b	v14, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1192
; %bb.1193:                             ; %direct.false2034
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #4976]                 ; 16-byte Spill
	str	q0, [sp, #4992]                 ; 16-byte Spill
	str	q31, [sp, #9056]                ; 16-byte Spill
	str	q15, [sp, #7840]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11200]                ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #11216]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	bit.16b	v22, v1, v13
	bit.16b	v18, v0, v30
	ldr	x2, [sp, #4408]                 ; 8-byte Reload
LBB0_1194:                              ; %direct.true2050
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v18, v0
	fadd.4s	v1, v22, v1
	bit.16b	v22, v1, v13
	bit.16b	v18, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1194
; %bb.1195:                             ; %direct.false2051
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q1, [sp, #4928]                 ; 16-byte Spill
	str	q0, [sp, #4944]                 ; 16-byte Spill
	str	q14, [sp, #7856]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11232]                ; 16-byte Reload
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #11248]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q15, [sp, #7712]                ; 16-byte Reload
	bit.16b	v15, v1, v13
	ldr	q14, [sp, #7728]                ; 16-byte Reload
	bit.16b	v14, v0, v30
	ldr	x2, [sp, #4400]                 ; 8-byte Reload
	ldr	q31, [sp, #7376]                ; 16-byte Reload
	ldr	q27, [sp, #7328]                ; 16-byte Reload
LBB0_1196:                              ; %direct.true2067
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v2, v14, v0
	fadd.4s	v0, v15, v1
	bit.16b	v15, v0, v13
	bit.16b	v14, v2, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1196
; %bb.1197:                             ; %direct.false2068
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q2, [sp, #4896]                 ; 16-byte Spill
	str	q0, [sp, #4960]                 ; 16-byte Spill
	str	q15, [sp, #7712]                ; 16-byte Spill
	str	q14, [sp, #7728]                ; 16-byte Spill
	str	q18, [sp, #7888]                ; 16-byte Spill
	str	q4, [sp, #7984]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11264]                ; 16-byte Reload
	ldr	q14, [sp, #11760]               ; 16-byte Reload
	fmul.4s	v0, v0, v14
	ldr	q1, [sp, #11280]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q18, [sp, #7744]                ; 16-byte Reload
	bit.16b	v18, v1, v13
	ldr	q4, [sp, #7760]                 ; 16-byte Reload
	bit.16b	v4, v0, v30
	ldr	x2, [sp, #4392]                 ; 8-byte Reload
LBB0_1198:                              ; %direct.true2084
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v4, v0
	fadd.4s	v15, v18, v1
	bit.16b	v18, v15, v13
	bit.16b	v4, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1198
; %bb.1199:                             ; %direct.false2085
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q0, [sp, #4912]                 ; 16-byte Spill
	str	q18, [sp, #7744]                ; 16-byte Spill
	str	q4, [sp, #7760]                 ; 16-byte Spill
	str	q22, [sp, #7872]                ; 16-byte Spill
	str	q5, [sp, #8080]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11296]                ; 16-byte Reload
	fmul.4s	v0, v0, v14
	ldr	q1, [sp, #11312]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q22, [sp, #7776]                ; 16-byte Reload
	bit.16b	v22, v1, v13
	ldr	q5, [sp, #7792]                 ; 16-byte Reload
	bit.16b	v5, v0, v30
	ldr	x2, [sp, #4384]                 ; 8-byte Reload
LBB0_1200:                              ; %direct.true2101
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v4, v5, v0
	fadd.4s	v18, v22, v1
	bit.16b	v22, v18, v13
	bit.16b	v5, v4, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1200
; %bb.1201:                             ; %direct.false2102
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q22, [sp, #7776]                ; 16-byte Spill
	str	q5, [sp, #7792]                 ; 16-byte Spill
	str	q8, [sp, #8048]                 ; 16-byte Spill
	str	q7, [sp, #8064]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11328]                ; 16-byte Reload
	fmul.4s	v0, v0, v14
	ldr	q1, [sp, #11344]                ; 16-byte Reload
	ldr	q8, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v8
	bit.16b	v25, v1, v13
	ldr	q7, [sp, #7632]                 ; 16-byte Reload
	bit.16b	v7, v0, v30
	ldr	x2, [sp, #4376]                 ; 8-byte Reload
LBB0_1202:                              ; %direct.true2118
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v22, v7, v0
	fadd.4s	v5, v25, v1
	bit.16b	v25, v5, v13
	bit.16b	v7, v22, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1202
; %bb.1203:                             ; %direct.false2119
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q25, [sp, #7616]                ; 16-byte Spill
	str	q7, [sp, #7632]                 ; 16-byte Spill
	str	q16, [sp, #8176]                ; 16-byte Spill
	str	q6, [sp, #8272]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	fmul.4s	v0, v0, v14
	ldr	q1, [sp, #11376]                ; 16-byte Reload
	fmul.4s	v1, v1, v8
	ldr	q16, [sp, #7648]                ; 16-byte Reload
	bit.16b	v16, v1, v13
	ldr	q6, [sp, #7664]                 ; 16-byte Reload
	bit.16b	v6, v0, v30
	ldr	x2, [sp, #4368]                 ; 8-byte Reload
LBB0_1204:                              ; %direct.true2135
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v8, v6, v0
	fadd.4s	v7, v16, v1
	bit.16b	v16, v7, v13
	bit.16b	v6, v8, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1204
; %bb.1205:                             ; %direct.false2136
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q16, [sp, #7648]                ; 16-byte Spill
	str	q6, [sp, #7664]                 ; 16-byte Spill
	str	q23, [sp, #8256]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11392]                ; 16-byte Reload
	fmul.4s	v0, v0, v14
	ldr	q1, [sp, #11408]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q25, [sp, #7680]                ; 16-byte Reload
	bit.16b	v25, v1, v13
	ldr	q23, [sp, #7696]                ; 16-byte Reload
	bit.16b	v23, v0, v30
	ldr	x2, [sp, #4360]                 ; 8-byte Reload
LBB0_1206:                              ; %direct.true2152
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v6, v23, v0
	fadd.4s	v16, v25, v1
	bit.16b	v25, v16, v13
	bit.16b	v23, v6, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1206
; %bb.1207:                             ; %direct.false2153
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q25, [sp, #7680]                ; 16-byte Spill
	str	q23, [sp, #7696]                ; 16-byte Spill
	str	q12, [sp, #8240]                ; 16-byte Spill
	str	q17, [sp, #8368]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	fmul.4s	v0, v0, v14
	ldr	q1, [sp, #11440]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q25, [sp, #7520]                ; 16-byte Reload
	bit.16b	v25, v1, v13
	ldr	q17, [sp, #7536]                ; 16-byte Reload
	bit.16b	v17, v0, v30
	ldr	x2, [sp, #4352]                 ; 8-byte Reload
LBB0_1208:                              ; %direct.true2169
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q3, [x2]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v23, v17, v0
	fadd.4s	v3, v25, v1
	bit.16b	v25, v3, v13
	bit.16b	v17, v23, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1208
; %bb.1209:                             ; %direct.false2170
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q25, [sp, #7520]                ; 16-byte Spill
	str	q17, [sp, #7536]                ; 16-byte Spill
	str	q19, [sp, #8464]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11456]                ; 16-byte Reload
	fmul.4s	v0, v0, v14
	ldr	q1, [sp, #11472]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q25, [sp, #7552]                ; 16-byte Reload
	bit.16b	v25, v1, v13
	ldr	q19, [sp, #7568]                ; 16-byte Reload
	bit.16b	v19, v0, v30
	ldr	x2, [sp, #4344]                 ; 8-byte Reload
LBB0_1210:                              ; %direct.true2186
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q17, [x2]
	fmul.4s	v1, v1, v17
	fmul.4s	v0, v0, v2
	fadd.4s	v17, v19, v0
	fadd.4s	v12, v25, v1
	bit.16b	v25, v12, v13
	bit.16b	v19, v17, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1210
; %bb.1211:                             ; %direct.false2187
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q19, [sp, #7568]                ; 16-byte Spill
	str	q10, [sp, #8432]                ; 16-byte Spill
	str	q28, [sp, #8448]                ; 16-byte Spill
	str	q21, [sp, #8560]                ; 16-byte Spill
	str	q20, [sp, #8656]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q0, [sp, #11488]                ; 16-byte Reload
	fmul.4s	v0, v0, v14
	ldr	q1, [sp, #11504]                ; 16-byte Reload
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q21, [sp, #7584]                ; 16-byte Reload
	bit.16b	v21, v1, v13
	ldr	q20, [sp, #7600]                ; 16-byte Reload
	bit.16b	v20, v0, v30
	ldr	x2, [sp, #4336]                 ; 8-byte Reload
LBB0_1212:                              ; %direct.true2203
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q0, q1, [x3]
	ldp	q2, q19, [x2]
	fmul.4s	v1, v1, v19
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v20, v0
	fadd.4s	v1, v21, v1
	bit.16b	v21, v1, v13
	bit.16b	v20, v0, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1212
; %bb.1213:                             ; %direct.false2204
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q21, [sp, #7584]                ; 16-byte Spill
	str	q20, [sp, #7600]                ; 16-byte Spill
	str	q11, [sp, #8624]                ; 16-byte Spill
	str	q24, [sp, #8640]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q2, [sp, #11520]                ; 16-byte Reload
	fmul.4s	v2, v2, v14
	ldr	q19, [sp, #11536]               ; 16-byte Reload
	ldr	q20, [sp, #11808]               ; 16-byte Reload
	fmul.4s	v19, v19, v20
	ldr	q11, [sp, #7424]                ; 16-byte Reload
	bit.16b	v11, v19, v13
	ldr	q24, [sp, #7440]                ; 16-byte Reload
	bit.16b	v24, v2, v30
	ldr	x2, [sp, #4328]                 ; 8-byte Reload
LBB0_1214:                              ; %direct.true2220
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q2, q19, [x3]
	ldp	q20, q21, [x2]
	fmul.4s	v19, v19, v21
	fmul.4s	v2, v2, v20
	fadd.4s	v28, v24, v2
	fadd.4s	v10, v11, v19
	bit.16b	v11, v10, v13
	bit.16b	v24, v28, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1214
; %bb.1215:                             ; %direct.false2221
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q11, [sp, #7424]                ; 16-byte Spill
	str	q24, [sp, #7440]                ; 16-byte Spill
	str	q9, [sp, #8752]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q2, [sp, #11552]                ; 16-byte Reload
	fmul.4s	v2, v2, v14
	ldr	q19, [sp, #11568]               ; 16-byte Reload
	ldr	q20, [sp, #11808]               ; 16-byte Reload
	fmul.4s	v19, v19, v20
	ldr	q9, [sp, #7456]                 ; 16-byte Reload
	bit.16b	v9, v19, v13
	bit.16b	v29, v2, v30
	ldr	x2, [sp, #4320]                 ; 8-byte Reload
LBB0_1216:                              ; %direct.true2237
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q2, q19, [x3]
	ldp	q20, q21, [x2]
	fmul.4s	v19, v19, v21
	fmul.4s	v2, v2, v20
	fadd.4s	v24, v29, v2
	fadd.4s	v11, v9, v19
	bit.16b	v9, v11, v13
	bit.16b	v29, v24, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1216
; %bb.1217:                             ; %direct.false2238
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q9, [sp, #7456]                 ; 16-byte Spill
	str	q29, [sp, #7472]                ; 16-byte Spill
	str	q25, [sp, #7552]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q2, [sp, #11584]                ; 16-byte Reload
	fmul.4s	v2, v2, v14
	ldr	q19, [sp, #11600]               ; 16-byte Reload
	ldr	q20, [sp, #11808]               ; 16-byte Reload
	fmul.4s	v19, v19, v20
	ldr	q29, [sp, #7488]                ; 16-byte Reload
	bit.16b	v29, v19, v13
	ldr	q25, [sp, #7504]                ; 16-byte Reload
	bit.16b	v25, v2, v30
	ldr	x2, [sp, #4312]                 ; 8-byte Reload
LBB0_1218:                              ; %direct.true2254
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q2, q19, [x3]
	ldp	q20, q21, [x2]
	fmul.4s	v19, v19, v21
	fmul.4s	v2, v2, v20
	fadd.4s	v9, v25, v2
	fadd.4s	v19, v29, v19
	bit.16b	v29, v19, v13
	bit.16b	v25, v9, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1218
; %bb.1219:                             ; %direct.false2255
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q29, [sp, #7488]                ; 16-byte Spill
	str	q25, [sp, #7504]                ; 16-byte Spill
	str	q26, [sp, #8832]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q2, [sp, #11616]                ; 16-byte Reload
	fmul.4s	v2, v2, v14
	ldr	q20, [sp, #11632]               ; 16-byte Reload
	ldr	q21, [sp, #11808]               ; 16-byte Reload
	fmul.4s	v20, v20, v21
	bit.16b	v27, v20, v13
	ldr	q26, [sp, #7344]                ; 16-byte Reload
	bit.16b	v26, v2, v30
	ldr	x2, [sp, #4304]                 ; 8-byte Reload
LBB0_1220:                              ; %direct.true2271
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q2, q20, [x3]
	ldp	q21, q25, [x2]
	fmul.4s	v20, v20, v25
	fmul.4s	v2, v2, v21
	fadd.4s	v25, v26, v2
	fadd.4s	v20, v27, v20
	bit.16b	v27, v20, v13
	bit.16b	v26, v25, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1220
; %bb.1221:                             ; %direct.false2272
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q27, [sp, #7328]                ; 16-byte Spill
	str	q26, [sp, #7344]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q2, [sp, #11648]                ; 16-byte Reload
	fmul.4s	v2, v2, v14
	ldr	q21, [sp, #11664]               ; 16-byte Reload
	ldr	q26, [sp, #11808]               ; 16-byte Reload
	fmul.4s	v21, v21, v26
	ldr	q27, [sp, #7360]                ; 16-byte Reload
	bit.16b	v27, v21, v13
	bit.16b	v31, v2, v30
	ldr	x2, [sp, #4296]                 ; 8-byte Reload
LBB0_1222:                              ; %direct.true2288
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q2, q21, [x3]
	ldp	q26, q29, [x2]
	fmul.4s	v21, v21, v29
	fmul.4s	v2, v2, v26
	fadd.4s	v29, v31, v2
	fadd.4s	v2, v27, v21
	bit.16b	v27, v2, v13
	bit.16b	v31, v29, v30
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1222
; %bb.1223:                             ; %direct.false2289
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q27, [sp, #7360]                ; 16-byte Spill
	str	q31, [sp, #7376]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q21, [sp, #11680]               ; 16-byte Reload
	fmul.4s	v21, v21, v14
	ldr	q26, [sp, #11696]               ; 16-byte Reload
	ldr	q27, [sp, #11808]               ; 16-byte Reload
	fmul.4s	v26, v26, v27
	ldr	q31, [sp, #7392]                ; 16-byte Reload
	bit.16b	v31, v26, v13
	ldr	q27, [sp, #7408]                ; 16-byte Reload
	bit.16b	v27, v21, v30
	ldr	x2, [sp, #4288]                 ; 8-byte Reload
LBB0_1224:                              ; %direct.true2305
                                        ;   Parent Loop BB0_1027 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x10, x1
	ldp	q21, q26, [x3]
	ldp	q13, q30, [x2]
	fmul.4s	v30, v26, v30
	fmul.4s	v21, v21, v13
	ldr	q14, [sp, #11792]               ; 16-byte Reload
	fadd.4s	v26, v27, v21
	fadd.4s	v21, v31, v30
	ldr	q13, [sp, #11776]               ; 16-byte Reload
	bit.16b	v31, v21, v14
	bit.16b	v27, v26, v13
	add	x1, x1, #32
	add	x2, x2, #2048
	cmp	x1, #512
	b.ne	LBB0_1224
; %bb.1225:                             ; %direct.false2306
                                        ;   in Loop: Header=BB0_1027 Depth=1
	str	q31, [sp, #7392]                ; 16-byte Spill
	str	q27, [sp, #7408]                ; 16-byte Spill
	ldr	q30, [sp, #11744]               ; 16-byte Reload
	ldr	q27, [sp, #7024]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #11744]               ; 16-byte Spill
	ldr	q30, [sp, #11728]               ; 16-byte Reload
	ldr	q27, [sp, #7040]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #11728]               ; 16-byte Spill
	ldr	q30, [sp, #9680]                ; 16-byte Reload
	ldr	q27, [sp, #6480]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #9680]                ; 16-byte Spill
	ldr	q27, [sp, #9664]                ; 16-byte Reload
	ldr	q30, [sp, #6496]                ; 16-byte Reload
	bit.16b	v27, v30, v13
	str	q27, [sp, #9664]                ; 16-byte Spill
	ldr	q30, [sp, #9712]                ; 16-byte Reload
	ldr	q27, [sp, #6448]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #9712]                ; 16-byte Spill
	ldr	q30, [sp, #9696]                ; 16-byte Reload
	ldr	q27, [sp, #6464]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #9696]                ; 16-byte Spill
	ldr	q30, [sp, #9744]                ; 16-byte Reload
	ldr	q27, [sp, #6416]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #9744]                ; 16-byte Spill
	ldr	q30, [sp, #9728]                ; 16-byte Reload
	ldr	q27, [sp, #6432]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #9728]                ; 16-byte Spill
	ldr	q30, [sp, #9776]                ; 16-byte Reload
	ldr	q27, [sp, #6384]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #9776]                ; 16-byte Spill
	ldr	q30, [sp, #9760]                ; 16-byte Reload
	ldr	q27, [sp, #6400]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #9760]                ; 16-byte Spill
	ldr	q30, [sp, #9808]                ; 16-byte Reload
	ldr	q27, [sp, #6352]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #9808]                ; 16-byte Spill
	ldr	q30, [sp, #9792]                ; 16-byte Reload
	ldr	q27, [sp, #6368]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #9792]                ; 16-byte Spill
	ldr	q30, [sp, #9840]                ; 16-byte Reload
	ldr	q27, [sp, #6320]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #9840]                ; 16-byte Spill
	ldr	q30, [sp, #9824]                ; 16-byte Reload
	ldr	q27, [sp, #6336]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #9824]                ; 16-byte Spill
	ldr	q30, [sp, #9872]                ; 16-byte Reload
	ldr	q27, [sp, #6288]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #9872]                ; 16-byte Spill
	ldr	q30, [sp, #9856]                ; 16-byte Reload
	ldr	q27, [sp, #6304]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #9856]                ; 16-byte Spill
	ldr	q30, [sp, #9904]                ; 16-byte Reload
	ldr	q27, [sp, #6256]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #9904]                ; 16-byte Spill
	ldr	q30, [sp, #9888]                ; 16-byte Reload
	ldr	q27, [sp, #6272]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #9888]                ; 16-byte Spill
	ldr	q30, [sp, #9936]                ; 16-byte Reload
	ldr	q27, [sp, #6224]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #9936]                ; 16-byte Spill
	ldr	q30, [sp, #9920]                ; 16-byte Reload
	ldr	q27, [sp, #6240]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #9920]                ; 16-byte Spill
	ldr	q30, [sp, #9952]                ; 16-byte Reload
	ldr	q27, [sp, #6192]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #9952]                ; 16-byte Spill
	ldr	q30, [sp, #9968]                ; 16-byte Reload
	ldr	q27, [sp, #6208]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #9968]                ; 16-byte Spill
	ldr	q30, [sp, #10000]               ; 16-byte Reload
	ldr	q27, [sp, #6160]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10000]               ; 16-byte Spill
	ldr	q30, [sp, #9984]                ; 16-byte Reload
	ldr	q27, [sp, #6176]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #9984]                ; 16-byte Spill
	ldr	q30, [sp, #10032]               ; 16-byte Reload
	ldr	q27, [sp, #6128]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10032]               ; 16-byte Spill
	ldr	q30, [sp, #10016]               ; 16-byte Reload
	ldr	q27, [sp, #6144]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10016]               ; 16-byte Spill
	ldr	q30, [sp, #10064]               ; 16-byte Reload
	ldr	q27, [sp, #6096]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10064]               ; 16-byte Spill
	ldr	q30, [sp, #10048]               ; 16-byte Reload
	ldr	q27, [sp, #6112]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10048]               ; 16-byte Spill
	ldr	q30, [sp, #10096]               ; 16-byte Reload
	ldr	q27, [sp, #6064]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10096]               ; 16-byte Spill
	ldr	q30, [sp, #10080]               ; 16-byte Reload
	ldr	q27, [sp, #6080]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10080]               ; 16-byte Spill
	ldr	q30, [sp, #10128]               ; 16-byte Reload
	ldr	q27, [sp, #6032]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10128]               ; 16-byte Spill
	ldr	q30, [sp, #10112]               ; 16-byte Reload
	ldr	q27, [sp, #6048]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10112]               ; 16-byte Spill
	ldr	q30, [sp, #10160]               ; 16-byte Reload
	ldr	q27, [sp, #6000]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10160]               ; 16-byte Spill
	ldr	q30, [sp, #10144]               ; 16-byte Reload
	ldr	q27, [sp, #6016]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10144]               ; 16-byte Spill
	ldr	q30, [sp, #10240]               ; 16-byte Reload
	ldr	q27, [sp, #5968]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10240]               ; 16-byte Spill
	ldr	q30, [sp, #10192]               ; 16-byte Reload
	ldr	q27, [sp, #5984]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10192]               ; 16-byte Spill
	ldr	q30, [sp, #10304]               ; 16-byte Reload
	ldr	q27, [sp, #5936]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10304]               ; 16-byte Spill
	ldr	q30, [sp, #10256]               ; 16-byte Reload
	ldr	q27, [sp, #5952]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10256]               ; 16-byte Spill
	ldr	q30, [sp, #10368]               ; 16-byte Reload
	ldr	q27, [sp, #5904]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10368]               ; 16-byte Spill
	ldr	q30, [sp, #10336]               ; 16-byte Reload
	ldr	q27, [sp, #5920]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10336]               ; 16-byte Spill
	ldr	q30, [sp, #10208]               ; 16-byte Reload
	ldr	q27, [sp, #5872]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10208]               ; 16-byte Spill
	ldr	q30, [sp, #10176]               ; 16-byte Reload
	ldr	q27, [sp, #5888]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10176]               ; 16-byte Spill
	ldr	q30, [sp, #10272]               ; 16-byte Reload
	ldr	q27, [sp, #5840]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10272]               ; 16-byte Spill
	ldr	q30, [sp, #10224]               ; 16-byte Reload
	ldr	q27, [sp, #5856]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10224]               ; 16-byte Spill
	ldr	q30, [sp, #10320]               ; 16-byte Reload
	ldr	q27, [sp, #5808]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10320]               ; 16-byte Spill
	ldr	q30, [sp, #10288]               ; 16-byte Reload
	ldr	q27, [sp, #5824]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10288]               ; 16-byte Spill
	ldr	q30, [sp, #10384]               ; 16-byte Reload
	ldr	q27, [sp, #5776]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10384]               ; 16-byte Spill
	ldr	q30, [sp, #10352]               ; 16-byte Reload
	ldr	q27, [sp, #5792]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10352]               ; 16-byte Spill
	ldr	q30, [sp, #10416]               ; 16-byte Reload
	ldr	q27, [sp, #5744]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10416]               ; 16-byte Spill
	ldr	q30, [sp, #10400]               ; 16-byte Reload
	ldr	q27, [sp, #5760]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10400]               ; 16-byte Spill
	ldr	q30, [sp, #10448]               ; 16-byte Reload
	ldr	q27, [sp, #5712]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10448]               ; 16-byte Spill
	ldr	q30, [sp, #10432]               ; 16-byte Reload
	ldr	q27, [sp, #5728]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10432]               ; 16-byte Spill
	ldr	q30, [sp, #10480]               ; 16-byte Reload
	ldr	q27, [sp, #5680]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10480]               ; 16-byte Spill
	ldr	q30, [sp, #10464]               ; 16-byte Reload
	ldr	q27, [sp, #5696]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10464]               ; 16-byte Spill
	ldr	q30, [sp, #10512]               ; 16-byte Reload
	ldr	q27, [sp, #5648]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10512]               ; 16-byte Spill
	ldr	q30, [sp, #10496]               ; 16-byte Reload
	ldr	q27, [sp, #5664]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10496]               ; 16-byte Spill
	ldr	q30, [sp, #10544]               ; 16-byte Reload
	ldr	q27, [sp, #5616]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10544]               ; 16-byte Spill
	ldr	q30, [sp, #10528]               ; 16-byte Reload
	ldr	q27, [sp, #5632]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10528]               ; 16-byte Spill
	ldr	q30, [sp, #10576]               ; 16-byte Reload
	ldr	q27, [sp, #5584]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10576]               ; 16-byte Spill
	ldr	q30, [sp, #10560]               ; 16-byte Reload
	ldr	q27, [sp, #5600]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10560]               ; 16-byte Spill
	ldr	q30, [sp, #10608]               ; 16-byte Reload
	ldr	q27, [sp, #5552]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10608]               ; 16-byte Spill
	ldr	q30, [sp, #10592]               ; 16-byte Reload
	ldr	q27, [sp, #5568]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10592]               ; 16-byte Spill
	ldr	q30, [sp, #10640]               ; 16-byte Reload
	ldr	q27, [sp, #5520]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10640]               ; 16-byte Spill
	ldr	q30, [sp, #10624]               ; 16-byte Reload
	ldr	q27, [sp, #5536]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10624]               ; 16-byte Spill
	ldr	q30, [sp, #10672]               ; 16-byte Reload
	ldr	q27, [sp, #5488]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10672]               ; 16-byte Spill
	ldr	q30, [sp, #10656]               ; 16-byte Reload
	ldr	q27, [sp, #5504]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10656]               ; 16-byte Spill
	ldr	q30, [sp, #10704]               ; 16-byte Reload
	ldr	q27, [sp, #5456]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10704]               ; 16-byte Spill
	ldr	q30, [sp, #10688]               ; 16-byte Reload
	ldr	q27, [sp, #5472]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10688]               ; 16-byte Spill
	ldr	q30, [sp, #10736]               ; 16-byte Reload
	ldr	q27, [sp, #5424]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10736]               ; 16-byte Spill
	ldr	q30, [sp, #10720]               ; 16-byte Reload
	ldr	q27, [sp, #5440]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10720]               ; 16-byte Spill
	ldr	q30, [sp, #10768]               ; 16-byte Reload
	ldr	q27, [sp, #5392]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10768]               ; 16-byte Spill
	ldr	q30, [sp, #10752]               ; 16-byte Reload
	ldr	q27, [sp, #5408]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10752]               ; 16-byte Spill
	ldr	q30, [sp, #10800]               ; 16-byte Reload
	ldr	q27, [sp, #5360]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10800]               ; 16-byte Spill
	ldr	q30, [sp, #10784]               ; 16-byte Reload
	ldr	q27, [sp, #5376]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10784]               ; 16-byte Spill
	ldr	q30, [sp, #10832]               ; 16-byte Reload
	ldr	q27, [sp, #5328]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10832]               ; 16-byte Spill
	ldr	q30, [sp, #10816]               ; 16-byte Reload
	ldr	q27, [sp, #5344]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10816]               ; 16-byte Spill
	ldr	q30, [sp, #10864]               ; 16-byte Reload
	ldr	q27, [sp, #5296]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10864]               ; 16-byte Spill
	ldr	q30, [sp, #10848]               ; 16-byte Reload
	ldr	q27, [sp, #5312]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10848]               ; 16-byte Spill
	ldr	q30, [sp, #10896]               ; 16-byte Reload
	ldr	q27, [sp, #5264]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10896]               ; 16-byte Spill
	ldr	q30, [sp, #10880]               ; 16-byte Reload
	ldr	q27, [sp, #5280]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10880]               ; 16-byte Spill
	ldr	q30, [sp, #10928]               ; 16-byte Reload
	ldr	q27, [sp, #5232]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10928]               ; 16-byte Spill
	ldr	q30, [sp, #10912]               ; 16-byte Reload
	ldr	q27, [sp, #5248]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10912]               ; 16-byte Spill
	ldr	q30, [sp, #10960]               ; 16-byte Reload
	ldr	q27, [sp, #5200]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10960]               ; 16-byte Spill
	ldr	q30, [sp, #10944]               ; 16-byte Reload
	ldr	q27, [sp, #5216]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10944]               ; 16-byte Spill
	ldr	q30, [sp, #10992]               ; 16-byte Reload
	ldr	q27, [sp, #5168]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #10992]               ; 16-byte Spill
	ldr	q30, [sp, #10976]               ; 16-byte Reload
	ldr	q27, [sp, #5184]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #10976]               ; 16-byte Spill
	ldr	q30, [sp, #11024]               ; 16-byte Reload
	ldr	q27, [sp, #5136]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #11024]               ; 16-byte Spill
	ldr	q30, [sp, #11008]               ; 16-byte Reload
	ldr	q27, [sp, #5152]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #11008]               ; 16-byte Spill
	ldr	q30, [sp, #11056]               ; 16-byte Reload
	ldr	q27, [sp, #5104]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #11056]               ; 16-byte Spill
	ldr	q30, [sp, #11040]               ; 16-byte Reload
	ldr	q27, [sp, #5120]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #11040]               ; 16-byte Spill
	ldr	q30, [sp, #11088]               ; 16-byte Reload
	ldr	q27, [sp, #5072]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #11088]               ; 16-byte Spill
	ldr	q30, [sp, #11072]               ; 16-byte Reload
	ldr	q27, [sp, #5088]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #11072]               ; 16-byte Spill
	ldr	q30, [sp, #11120]               ; 16-byte Reload
	ldr	q27, [sp, #5040]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #11120]               ; 16-byte Spill
	ldr	q30, [sp, #11104]               ; 16-byte Reload
	ldr	q27, [sp, #5056]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #11104]               ; 16-byte Spill
	ldr	q30, [sp, #11152]               ; 16-byte Reload
	ldr	q27, [sp, #5008]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #11152]               ; 16-byte Spill
	ldr	q30, [sp, #11136]               ; 16-byte Reload
	ldr	q27, [sp, #5024]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #11136]               ; 16-byte Spill
	ldr	q30, [sp, #11184]               ; 16-byte Reload
	ldr	q27, [sp, #4976]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #11184]               ; 16-byte Spill
	ldr	q30, [sp, #11168]               ; 16-byte Reload
	ldr	q27, [sp, #4992]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #11168]               ; 16-byte Spill
	ldr	q30, [sp, #11216]               ; 16-byte Reload
	ldr	q27, [sp, #4928]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #11216]               ; 16-byte Spill
	ldr	q30, [sp, #11200]               ; 16-byte Reload
	ldr	q27, [sp, #4944]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #11200]               ; 16-byte Spill
	ldr	q30, [sp, #11248]               ; 16-byte Reload
	ldr	q27, [sp, #4960]                ; 16-byte Reload
	bit.16b	v30, v27, v14
	str	q30, [sp, #11248]               ; 16-byte Spill
	ldr	q30, [sp, #11232]               ; 16-byte Reload
	ldr	q27, [sp, #4896]                ; 16-byte Reload
	bit.16b	v30, v27, v13
	str	q30, [sp, #11232]               ; 16-byte Spill
	ldr	q27, [sp, #11280]               ; 16-byte Reload
	bit.16b	v27, v15, v14
	str	q27, [sp, #11280]               ; 16-byte Spill
	ldr	q27, [sp, #11264]               ; 16-byte Reload
	ldr	q30, [sp, #4912]                ; 16-byte Reload
	bit.16b	v27, v30, v13
	str	q27, [sp, #11264]               ; 16-byte Spill
	ldr	q27, [sp, #11312]               ; 16-byte Reload
	bit.16b	v27, v18, v14
	str	q27, [sp, #11312]               ; 16-byte Spill
	ldr	q18, [sp, #11296]               ; 16-byte Reload
	bit.16b	v18, v4, v13
	str	q18, [sp, #11296]               ; 16-byte Spill
	ldr	q4, [sp, #11344]                ; 16-byte Reload
	bit.16b	v4, v5, v14
	str	q4, [sp, #11344]                ; 16-byte Spill
	ldr	q4, [sp, #11328]                ; 16-byte Reload
	bit.16b	v4, v22, v13
	str	q4, [sp, #11328]                ; 16-byte Spill
	ldr	q4, [sp, #11376]                ; 16-byte Reload
	bit.16b	v4, v7, v14
	str	q4, [sp, #11376]                ; 16-byte Spill
	ldr	q4, [sp, #11360]                ; 16-byte Reload
	bit.16b	v4, v8, v13
	str	q4, [sp, #11360]                ; 16-byte Spill
	ldr	q4, [sp, #11408]                ; 16-byte Reload
	bit.16b	v4, v16, v14
	str	q4, [sp, #11408]                ; 16-byte Spill
	ldr	q4, [sp, #11392]                ; 16-byte Reload
	bit.16b	v4, v6, v13
	str	q4, [sp, #11392]                ; 16-byte Spill
	ldr	q4, [sp, #11440]                ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #11440]                ; 16-byte Spill
	ldr	q3, [sp, #11424]                ; 16-byte Reload
	bit.16b	v3, v23, v13
	str	q3, [sp, #11424]                ; 16-byte Spill
	ldr	q3, [sp, #11472]                ; 16-byte Reload
	bit.16b	v3, v12, v14
	str	q3, [sp, #11472]                ; 16-byte Spill
	ldr	q3, [sp, #11456]                ; 16-byte Reload
	bit.16b	v3, v17, v13
	str	q3, [sp, #11456]                ; 16-byte Spill
	ldr	q3, [sp, #11504]                ; 16-byte Reload
	bit.16b	v3, v1, v14
	str	q3, [sp, #11504]                ; 16-byte Spill
	ldr	q1, [sp, #11488]                ; 16-byte Reload
	bit.16b	v1, v0, v13
	str	q1, [sp, #11488]                ; 16-byte Spill
	ldr	q0, [sp, #11536]                ; 16-byte Reload
	bit.16b	v0, v10, v14
	str	q0, [sp, #11536]                ; 16-byte Spill
	ldr	q0, [sp, #11520]                ; 16-byte Reload
	bit.16b	v0, v28, v13
	str	q0, [sp, #11520]                ; 16-byte Spill
	ldr	q0, [sp, #11568]                ; 16-byte Reload
	bit.16b	v0, v11, v14
	str	q0, [sp, #11568]                ; 16-byte Spill
	ldr	q0, [sp, #11552]                ; 16-byte Reload
	bit.16b	v0, v24, v13
	str	q0, [sp, #11552]                ; 16-byte Spill
	ldr	q0, [sp, #11600]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #11600]                ; 16-byte Spill
	ldr	q0, [sp, #11584]                ; 16-byte Reload
	bit.16b	v0, v9, v13
	str	q0, [sp, #11584]                ; 16-byte Spill
	ldr	q0, [sp, #11632]                ; 16-byte Reload
	bit.16b	v0, v20, v14
	str	q0, [sp, #11632]                ; 16-byte Spill
	ldr	q0, [sp, #11616]                ; 16-byte Reload
	bit.16b	v0, v25, v13
	str	q0, [sp, #11616]                ; 16-byte Spill
	ldr	q0, [sp, #11664]                ; 16-byte Reload
	bit.16b	v0, v2, v14
	str	q0, [sp, #11664]                ; 16-byte Spill
	ldr	q0, [sp, #11648]                ; 16-byte Reload
	bit.16b	v0, v29, v13
	str	q0, [sp, #11648]                ; 16-byte Spill
	ldr	q0, [sp, #11696]                ; 16-byte Reload
	bit.16b	v0, v21, v14
	str	q0, [sp, #11696]                ; 16-byte Spill
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	bit.16b	v0, v26, v13
	str	q0, [sp, #11680]                ; 16-byte Spill
	movi.2d	v1, #0000000000000000
	ldr	q0, [sp, #7008]                 ; 16-byte Reload
	fadd.4s	v0, v0, v1
	ldr	q2, [sp, #6976]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6992]                 ; 16-byte Reload
	fadd.4s	v1, v2, v1
	ldr	q2, [sp, #6960]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6928]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6944]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6912]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6896]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6864]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6880]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6848]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6832]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6800]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6816]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6784]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6768]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6720]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6752]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6704]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6736]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6688]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6672]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6640]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6656]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6624]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6608]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6592]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6576]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6560]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6544]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6512]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6528]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q6, [sp, #7296]                 ; 16-byte Reload
	ldr	q2, [sp, #11760]                ; 16-byte Reload
	fmul.4s	v2, v6, v2
	ldr	q5, [sp, #7312]                 ; 16-byte Reload
	ldr	q3, [sp, #11808]                ; 16-byte Reload
	fmul.4s	v3, v5, v3
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	bit.16b	v6, v0, v13
	bit.16b	v5, v1, v14
	add	x11, x11, #1
	cmp	x11, #128
	ldr	q8, [sp, #4800]                 ; 16-byte Reload
	ldr	q17, [sp, #7280]                ; 16-byte Reload
	ldr	q18, [sp, #7264]                ; 16-byte Reload
	ldr	q19, [sp, #7248]                ; 16-byte Reload
	ldr	q20, [sp, #7232]                ; 16-byte Reload
	ldr	q21, [sp, #7216]                ; 16-byte Reload
	ldr	q22, [sp, #7200]                ; 16-byte Reload
	ldr	q23, [sp, #7184]                ; 16-byte Reload
	ldr	q24, [sp, #7168]                ; 16-byte Reload
	ldr	q25, [sp, #7152]                ; 16-byte Reload
	ldr	q26, [sp, #7136]                ; 16-byte Reload
	ldr	q27, [sp, #7120]                ; 16-byte Reload
	ldr	q29, [sp, #7104]                ; 16-byte Reload
	ldr	q9, [sp, #7088]                 ; 16-byte Reload
	ldr	q15, [sp, #7072]                ; 16-byte Reload
	ldr	q28, [sp, #7056]                ; 16-byte Reload
	ldr	q30, [sp, #9520]                ; 16-byte Reload
	ldr	q31, [sp, #9504]                ; 16-byte Reload
	ldr	q16, [sp, #9488]                ; 16-byte Reload
	ldr	q10, [sp, #9472]                ; 16-byte Reload
	ldr	q4, [sp, #9456]                 ; 16-byte Reload
	ldr	q12, [sp, #9440]                ; 16-byte Reload
	ldr	q1, [sp, #11712]                ; 16-byte Reload
	mov.16b	v2, v13
	mov.16b	v13, v14
	b.ne	LBB0_1027
; %bb.1226:                             ; %direct.false
	mov.16b	v12, v5
	ldr	q5, [sp, #4880]                 ; 16-byte Reload
	fmov	w9, s5
	and	w8, w9, #0xff
	mov.16b	v30, v2
	sshll.2d	v1, v2, #0
	mov.16b	v15, v6
	ldr	q0, [sp, #9664]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v6
	ldr	q2, [sp, #3200]                 ; 16-byte Reload
	and.16b	v1, v1, v2
	ldr	x10, [sp, #8]                   ; 8-byte Reload
	dup.2d	v2, x10
	add.2d	v1, v2, v1
	ldr	q3, [sp, #3184]                 ; 16-byte Reload
	ldr	q6, [sp, #3168]                 ; 16-byte Reload
	ldr	q7, [sp, #3152]                 ; 16-byte Reload
	ldr	q16, [sp, #3120]                ; 16-byte Reload
	ldr	q17, [sp, #3104]                ; 16-byte Reload
	ldr	q18, [sp, #3056]                ; 16-byte Reload
	ldr	q19, [sp, #3040]                ; 16-byte Reload
	ldr	q20, [sp, #2992]                ; 16-byte Reload
	ldr	q21, [sp, #2976]                ; 16-byte Reload
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	ldr	q23, [sp, #2912]                ; 16-byte Reload
	ldr	q24, [sp, #2864]                ; 16-byte Reload
	ldr	q25, [sp, #2848]                ; 16-byte Reload
	ldr	q26, [sp, #2800]                ; 16-byte Reload
	ldr	q27, [sp, #2736]                ; 16-byte Reload
	ldr	q28, [sp, #2720]                ; 16-byte Reload
	ldr	q29, [sp, #2672]                ; 16-byte Reload
	ldr	q31, [sp, #2656]                ; 16-byte Reload
	ldr	q8, [sp, #2608]                 ; 16-byte Reload
	ldr	q9, [sp, #2544]                 ; 16-byte Reload
	ldr	q10, [sp, #4096]                ; 16-byte Reload
	ldr	q11, [sp, #1776]                ; 16-byte Reload
	ldr	q14, [sp, #1728]                ; 16-byte Reload
	tbnz	w9, #0, LBB0_1804
; %bb.1227:                             ; %else4207
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1805
LBB0_1228:                              ; %else4210
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1806
LBB0_1229:                              ; %else4213
	and.16b	v3, v3, v6
	tbnz	w8, #3, LBB0_1807
LBB0_1230:                              ; %else4216
	ldr	q0, [sp, #9680]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1808
LBB0_1231:                              ; %else4219
	ldr	q3, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v3, v7
	tbnz	w8, #5, LBB0_1809
LBB0_1232:                              ; %else4222
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1810
LBB0_1233:                              ; %else4225
	tbz	w8, #7, LBB0_1235
LBB0_1234:                              ; %cond.store4226
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1235:                              ; %else4228
	ldr	q0, [sp, #9696]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #3136]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1811
; %bb.1236:                             ; %else4233
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v16
	tbnz	w8, #1, LBB0_1812
LBB0_1237:                              ; %else4237
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1813
LBB0_1238:                              ; %else4241
	and.16b	v3, v3, v17
	tbnz	w8, #3, LBB0_1814
LBB0_1239:                              ; %else4245
	ldr	q0, [sp, #9712]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1815
LBB0_1240:                              ; %else4249
	ldr	q3, [sp, #3088]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1816
LBB0_1241:                              ; %else4253
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1817
LBB0_1242:                              ; %else4257
	tbz	w8, #7, LBB0_1244
LBB0_1243:                              ; %cond.store4258
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1244:                              ; %else4261
	ldr	q0, [sp, #9728]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #3072]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1818
; %bb.1245:                             ; %else4266
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v18
	tbnz	w8, #1, LBB0_1819
LBB0_1246:                              ; %else4270
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q6, [sp, #2496]                 ; 16-byte Reload
	tbnz	w8, #2, LBB0_1820
LBB0_1247:                              ; %else4274
	and.16b	v3, v3, v19
	tbnz	w8, #3, LBB0_1821
LBB0_1248:                              ; %else4278
	ldr	q0, [sp, #9744]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q7, [sp, #2448]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_1822
LBB0_1249:                              ; %else4282
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1823
LBB0_1250:                              ; %else4286
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1824
LBB0_1251:                              ; %else4290
	tbz	w8, #7, LBB0_1253
LBB0_1252:                              ; %cond.store4291
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1253:                              ; %else4294
	ldr	q0, [sp, #9760]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #3008]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1825
; %bb.1254:                             ; %else4299
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v20
	tbnz	w8, #1, LBB0_1826
LBB0_1255:                              ; %else4303
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q16, [sp, #2400]                ; 16-byte Reload
	tbnz	w8, #2, LBB0_1827
LBB0_1256:                              ; %else4307
	and.16b	v3, v3, v21
	tbnz	w8, #3, LBB0_1828
LBB0_1257:                              ; %else4311
	ldr	q0, [sp, #9776]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q17, [sp, #2352]                ; 16-byte Reload
	tbnz	w8, #4, LBB0_1829
LBB0_1258:                              ; %else4315
	ldr	q3, [sp, #2960]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1830
LBB0_1259:                              ; %else4319
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1831
LBB0_1260:                              ; %else4323
	tbz	w8, #7, LBB0_1262
LBB0_1261:                              ; %cond.store4324
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1262:                              ; %else4327
	ldr	q0, [sp, #9792]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2944]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1832
; %bb.1263:                             ; %else4332
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v22
	tbnz	w8, #1, LBB0_1833
LBB0_1264:                              ; %else4336
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q18, [sp, #2304]                ; 16-byte Reload
	tbnz	w8, #2, LBB0_1834
LBB0_1265:                              ; %else4340
	and.16b	v3, v3, v23
	tbnz	w8, #3, LBB0_1835
LBB0_1266:                              ; %else4344
	ldr	q0, [sp, #9808]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q19, [sp, #2256]                ; 16-byte Reload
	tbnz	w8, #4, LBB0_1836
LBB0_1267:                              ; %else4348
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1837
LBB0_1268:                              ; %else4352
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1838
LBB0_1269:                              ; %else4356
	tbz	w8, #7, LBB0_1271
LBB0_1270:                              ; %cond.store4357
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1271:                              ; %else4360
	ldr	q0, [sp, #9824]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2880]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1839
; %bb.1272:                             ; %else4365
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v24
	tbnz	w8, #1, LBB0_1840
LBB0_1273:                              ; %else4369
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q20, [sp, #2208]                ; 16-byte Reload
	tbnz	w8, #2, LBB0_1841
LBB0_1274:                              ; %else4373
	and.16b	v3, v3, v25
	tbnz	w8, #3, LBB0_1842
LBB0_1275:                              ; %else4377
	ldr	q0, [sp, #9840]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1843
LBB0_1276:                              ; %else4381
	ldr	q3, [sp, #2832]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1844
LBB0_1277:                              ; %else4385
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1845
LBB0_1278:                              ; %else4389
	tbz	w8, #7, LBB0_1280
LBB0_1279:                              ; %cond.store4390
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1280:                              ; %else4393
	ldr	q0, [sp, #9856]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1846
; %bb.1281:                             ; %else4398
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v26
	tbnz	w8, #1, LBB0_1847
LBB0_1282:                              ; %else4402
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q21, [sp, #2160]                ; 16-byte Reload
	tbnz	w8, #2, LBB0_1848
LBB0_1283:                              ; %else4406
	ldr	q4, [sp, #2784]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1849
LBB0_1284:                              ; %else4410
	ldr	q0, [sp, #9872]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1850
LBB0_1285:                              ; %else4414
	ldr	q3, [sp, #2768]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1851
LBB0_1286:                              ; %else4418
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1852
LBB0_1287:                              ; %else4422
	tbz	w8, #7, LBB0_1289
LBB0_1288:                              ; %cond.store4423
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1289:                              ; %else4426
	ldr	q0, [sp, #9888]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2752]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1853
; %bb.1290:                             ; %else4431
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v27
	tbnz	w8, #1, LBB0_1854
LBB0_1291:                              ; %else4435
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q22, [sp, #2112]                ; 16-byte Reload
	tbnz	w8, #2, LBB0_1855
LBB0_1292:                              ; %else4439
	and.16b	v3, v3, v28
	tbnz	w8, #3, LBB0_1856
LBB0_1293:                              ; %else4443
	ldr	q0, [sp, #9904]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q23, [sp, #2064]                ; 16-byte Reload
	ldr	q28, [sp, #1104]                ; 16-byte Reload
	tbnz	w8, #4, LBB0_1857
LBB0_1294:                              ; %else4447
	ldr	q3, [sp, #2704]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1858
LBB0_1295:                              ; %else4451
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1859
LBB0_1296:                              ; %else4455
	tbz	w8, #7, LBB0_1298
LBB0_1297:                              ; %cond.store4456
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1298:                              ; %else4459
	ldr	q0, [sp, #9920]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2688]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1860
; %bb.1299:                             ; %else4464
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v29
	tbnz	w8, #1, LBB0_1861
LBB0_1300:                              ; %else4468
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q24, [sp, #2016]                ; 16-byte Reload
	ldr	q29, [sp, #1056]                ; 16-byte Reload
	tbnz	w8, #2, LBB0_1862
LBB0_1301:                              ; %else4472
	and.16b	v3, v3, v31
	tbnz	w8, #3, LBB0_1863
LBB0_1302:                              ; %else4476
	ldr	q0, [sp, #9936]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1864
LBB0_1303:                              ; %else4480
	ldr	q3, [sp, #2640]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1865
LBB0_1304:                              ; %else4484
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1866
LBB0_1305:                              ; %else4488
	tbz	w8, #7, LBB0_1307
LBB0_1306:                              ; %cond.store4489
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1307:                              ; %else4492
	ldr	q0, [sp, #9968]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2624]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1867
; %bb.1308:                             ; %else4497
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v8
	tbnz	w8, #1, LBB0_1868
LBB0_1309:                              ; %else4501
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q25, [sp, #1920]                ; 16-byte Reload
	ldr	q31, [sp, #960]                 ; 16-byte Reload
	tbnz	w8, #2, LBB0_1869
LBB0_1310:                              ; %else4505
	ldr	q4, [sp, #2592]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1870
LBB0_1311:                              ; %else4509
	ldr	q0, [sp, #9952]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1871
LBB0_1312:                              ; %else4513
	ldr	q3, [sp, #2576]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1872
LBB0_1313:                              ; %else4517
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1873
LBB0_1314:                              ; %else4521
	tbz	w8, #7, LBB0_1316
LBB0_1315:                              ; %cond.store4522
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1316:                              ; %else4525
	ldr	q0, [sp, #9984]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2560]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1874
; %bb.1317:                             ; %else4530
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v9
	tbnz	w8, #1, LBB0_1875
LBB0_1318:                              ; %else4534
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q26, [sp, #1872]                ; 16-byte Reload
	ldr	q8, [sp, #912]                  ; 16-byte Reload
	tbnz	w8, #2, LBB0_1876
LBB0_1319:                              ; %else4538
	and.16b	v3, v3, v10
	tbz	w8, #3, LBB0_1321
LBB0_1320:                              ; %cond.store4539
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
LBB0_1321:                              ; %else4542
	ldr	q0, [sp, #10000]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q27, [sp, #1824]                ; 16-byte Reload
	ldr	q9, [sp, #864]                  ; 16-byte Reload
	ldr	q10, [sp, #4112]                ; 16-byte Reload
	tbnz	w8, #4, LBB0_1877
; %bb.1322:                             ; %else4546
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1878
LBB0_1323:                              ; %else4550
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1879
LBB0_1324:                              ; %else4554
	tbz	w8, #7, LBB0_1326
LBB0_1325:                              ; %cond.store4555
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1326:                              ; %else4558
	ldr	q0, [sp, #10016]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2512]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1880
; %bb.1327:                             ; %else4563
	ldr	q3, [sp, #4080]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1881
LBB0_1328:                              ; %else4567
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1882
LBB0_1329:                              ; %else4571
	and.16b	v3, v3, v6
	tbnz	w8, #3, LBB0_1883
LBB0_1330:                              ; %else4575
	ldr	q0, [sp, #10032]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1884
LBB0_1331:                              ; %else4579
	ldr	q3, [sp, #2480]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1885
LBB0_1332:                              ; %else4583
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1886
LBB0_1333:                              ; %else4587
	tbz	w8, #7, LBB0_1335
LBB0_1334:                              ; %cond.store4588
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1335:                              ; %else4591
	ldr	q0, [sp, #10048]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2464]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1887
; %bb.1336:                             ; %else4596
	ldr	q3, [sp, #4064]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1888
LBB0_1337:                              ; %else4600
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1889
LBB0_1338:                              ; %else4604
	and.16b	v3, v3, v7
	tbnz	w8, #3, LBB0_1890
LBB0_1339:                              ; %else4608
	ldr	q0, [sp, #10064]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1891
LBB0_1340:                              ; %else4612
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1892
LBB0_1341:                              ; %else4616
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1893
LBB0_1342:                              ; %else4620
	tbz	w8, #7, LBB0_1344
LBB0_1343:                              ; %cond.store4621
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1344:                              ; %else4624
	ldr	q0, [sp, #10080]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2416]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1894
; %bb.1345:                             ; %else4629
	ldr	q3, [sp, #4048]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1895
LBB0_1346:                              ; %else4633
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1896
LBB0_1347:                              ; %else4637
	and.16b	v3, v3, v16
	tbnz	w8, #3, LBB0_1897
LBB0_1348:                              ; %else4641
	ldr	q0, [sp, #10096]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1898
LBB0_1349:                              ; %else4645
	ldr	q3, [sp, #2384]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1899
LBB0_1350:                              ; %else4649
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1900
LBB0_1351:                              ; %else4653
	tbz	w8, #7, LBB0_1353
LBB0_1352:                              ; %cond.store4654
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1353:                              ; %else4657
	ldr	q0, [sp, #10112]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1901
; %bb.1354:                             ; %else4662
	ldr	q3, [sp, #4032]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1902
LBB0_1355:                              ; %else4666
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1903
LBB0_1356:                              ; %else4670
	and.16b	v3, v3, v17
	tbnz	w8, #3, LBB0_1904
LBB0_1357:                              ; %else4674
	ldr	q0, [sp, #10128]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1905
LBB0_1358:                              ; %else4678
	ldr	q3, [sp, #2336]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1906
LBB0_1359:                              ; %else4682
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1907
LBB0_1360:                              ; %else4686
	tbz	w8, #7, LBB0_1362
LBB0_1361:                              ; %cond.store4687
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1362:                              ; %else4690
	ldr	q0, [sp, #10144]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2320]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1908
; %bb.1363:                             ; %else4695
	ldr	q3, [sp, #4016]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1909
LBB0_1364:                              ; %else4699
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1910
LBB0_1365:                              ; %else4703
	and.16b	v3, v3, v18
	tbnz	w8, #3, LBB0_1911
LBB0_1366:                              ; %else4707
	ldr	q0, [sp, #10160]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q6, [sp, #1536]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_1912
LBB0_1367:                              ; %else4711
	ldr	q3, [sp, #2288]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1913
LBB0_1368:                              ; %else4715
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1914
LBB0_1369:                              ; %else4719
	tbz	w8, #7, LBB0_1371
LBB0_1370:                              ; %cond.store4720
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1371:                              ; %else4723
	ldr	q0, [sp, #10192]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2272]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1915
; %bb.1372:                             ; %else4728
	ldr	q3, [sp, #4000]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1916
LBB0_1373:                              ; %else4732
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1917
LBB0_1374:                              ; %else4736
	and.16b	v3, v3, v19
	tbnz	w8, #3, LBB0_1918
LBB0_1375:                              ; %else4740
	ldr	q0, [sp, #10240]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q7, [sp, #1488]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_1919
LBB0_1376:                              ; %else4744
	ldr	q3, [sp, #2240]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1920
LBB0_1377:                              ; %else4748
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1921
LBB0_1378:                              ; %else4752
	tbz	w8, #7, LBB0_1380
LBB0_1379:                              ; %cond.store4753
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1380:                              ; %else4756
	ldr	q0, [sp, #10256]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2224]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1922
; %bb.1381:                             ; %else4761
	ldr	q3, [sp, #3984]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1923
LBB0_1382:                              ; %else4765
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1924
LBB0_1383:                              ; %else4769
	and.16b	v3, v3, v20
	tbnz	w8, #3, LBB0_1925
LBB0_1384:                              ; %else4773
	ldr	q0, [sp, #10304]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q16, [sp, #1440]                ; 16-byte Reload
	tbnz	w8, #4, LBB0_1926
LBB0_1385:                              ; %else4777
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1927
LBB0_1386:                              ; %else4781
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1928
LBB0_1387:                              ; %else4785
	tbz	w8, #7, LBB0_1389
LBB0_1388:                              ; %cond.store4786
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1389:                              ; %else4789
	ldr	q0, [sp, #10336]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1929
; %bb.1390:                             ; %else4794
	ldr	q3, [sp, #3968]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1930
LBB0_1391:                              ; %else4798
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1931
LBB0_1392:                              ; %else4802
	and.16b	v3, v3, v21
	tbnz	w8, #3, LBB0_1932
LBB0_1393:                              ; %else4806
	ldr	q0, [sp, #10368]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q17, [sp, #1392]                ; 16-byte Reload
	tbnz	w8, #4, LBB0_1933
LBB0_1394:                              ; %else4810
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1934
LBB0_1395:                              ; %else4814
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1935
LBB0_1396:                              ; %else4818
	tbz	w8, #7, LBB0_1398
LBB0_1397:                              ; %cond.store4819
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1398:                              ; %else4822
	ldr	q0, [sp, #10176]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1936
; %bb.1399:                             ; %else4827
	ldr	q3, [sp, #3952]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1937
LBB0_1400:                              ; %else4831
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1938
LBB0_1401:                              ; %else4835
	and.16b	v3, v3, v22
	tbnz	w8, #3, LBB0_1939
LBB0_1402:                              ; %else4839
	ldr	q0, [sp, #10208]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q18, [sp, #1344]                ; 16-byte Reload
	tbnz	w8, #4, LBB0_1940
LBB0_1403:                              ; %else4843
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1941
LBB0_1404:                              ; %else4847
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1942
LBB0_1405:                              ; %else4851
	tbz	w8, #7, LBB0_1407
LBB0_1406:                              ; %cond.store4852
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1407:                              ; %else4855
	ldr	q0, [sp, #10224]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1943
; %bb.1408:                             ; %else4860
	ldr	q3, [sp, #3936]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1944
LBB0_1409:                              ; %else4864
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1945
LBB0_1410:                              ; %else4868
	and.16b	v3, v3, v23
	tbnz	w8, #3, LBB0_1946
LBB0_1411:                              ; %else4872
	ldr	q0, [sp, #10272]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q19, [sp, #1296]                ; 16-byte Reload
	tbnz	w8, #4, LBB0_1947
LBB0_1412:                              ; %else4876
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1948
LBB0_1413:                              ; %else4880
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1949
LBB0_1414:                              ; %else4884
	tbz	w8, #7, LBB0_1416
LBB0_1415:                              ; %cond.store4885
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1416:                              ; %else4888
	ldr	q0, [sp, #10288]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1950
; %bb.1417:                             ; %else4893
	ldr	q3, [sp, #3920]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1951
LBB0_1418:                              ; %else4897
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1952
LBB0_1419:                              ; %else4901
	and.16b	v3, v3, v24
	tbnz	w8, #3, LBB0_1953
LBB0_1420:                              ; %else4905
	ldr	q0, [sp, #10320]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q20, [sp, #1248]                ; 16-byte Reload
	tbnz	w8, #4, LBB0_1954
LBB0_1421:                              ; %else4909
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1955
LBB0_1422:                              ; %else4913
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1956
LBB0_1423:                              ; %else4917
	tbz	w8, #7, LBB0_1425
LBB0_1424:                              ; %cond.store4918
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1425:                              ; %else4921
	ldr	q0, [sp, #10352]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1957
; %bb.1426:                             ; %else4926
	ldr	q3, [sp, #3904]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1958
LBB0_1427:                              ; %else4930
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1959
LBB0_1428:                              ; %else4934
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1960
LBB0_1429:                              ; %else4938
	ldr	q0, [sp, #10384]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1961
LBB0_1430:                              ; %else4942
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1962
LBB0_1431:                              ; %else4946
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1963
LBB0_1432:                              ; %else4950
	tbz	w8, #7, LBB0_1434
LBB0_1433:                              ; %cond.store4951
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1434:                              ; %else4954
	ldr	q0, [sp, #10400]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1964
; %bb.1435:                             ; %else4959
	ldr	q3, [sp, #3888]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1965
LBB0_1436:                              ; %else4963
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1966
LBB0_1437:                              ; %else4967
	and.16b	v3, v3, v25
	tbnz	w8, #3, LBB0_1967
LBB0_1438:                              ; %else4971
	ldr	q0, [sp, #10416]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1968
LBB0_1439:                              ; %else4975
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1969
LBB0_1440:                              ; %else4979
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1970
LBB0_1441:                              ; %else4983
	tbz	w8, #7, LBB0_1443
LBB0_1442:                              ; %cond.store4984
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1443:                              ; %else4987
	ldr	q0, [sp, #10432]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1888]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1971
; %bb.1444:                             ; %else4992
	ldr	q3, [sp, #3872]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1972
LBB0_1445:                              ; %else4996
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1973
LBB0_1446:                              ; %else5000
	and.16b	v3, v3, v26
	tbnz	w8, #3, LBB0_1974
LBB0_1447:                              ; %else5004
	ldr	q0, [sp, #10448]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q21, [sp, #1200]                ; 16-byte Reload
	tbnz	w8, #4, LBB0_1975
LBB0_1448:                              ; %else5008
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1976
LBB0_1449:                              ; %else5012
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1977
LBB0_1450:                              ; %else5016
	tbz	w8, #7, LBB0_1452
LBB0_1451:                              ; %cond.store5017
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1452:                              ; %else5020
	ldr	q0, [sp, #10464]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1978
; %bb.1453:                             ; %else5025
	ldr	q3, [sp, #3856]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1979
LBB0_1454:                              ; %else5029
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1980
LBB0_1455:                              ; %else5033
	and.16b	v3, v3, v27
	tbnz	w8, #3, LBB0_1981
LBB0_1456:                              ; %else5037
	ldr	q0, [sp, #10480]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q22, [sp, #1152]                ; 16-byte Reload
	ldr	q27, [sp, #128]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_1982
LBB0_1457:                              ; %else5041
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1983
LBB0_1458:                              ; %else5045
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1984
LBB0_1459:                              ; %else5049
	tbz	w8, #7, LBB0_1461
LBB0_1460:                              ; %cond.store5050
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1461:                              ; %else5053
	ldr	q0, [sp, #10496]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1985
; %bb.1462:                             ; %else5058
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbnz	w8, #1, LBB0_1986
LBB0_1463:                              ; %else5062
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1987
LBB0_1464:                              ; %else5066
	and.16b	v3, v3, v11
	tbnz	w8, #3, LBB0_1988
LBB0_1465:                              ; %else5070
	ldr	q0, [sp, #10512]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q23, [sp, #816]                 ; 16-byte Reload
	ldr	q11, [sp, #4128]                ; 16-byte Reload
	tbnz	w8, #4, LBB0_1989
LBB0_1466:                              ; %else5074
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1990
LBB0_1467:                              ; %else5078
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1991
LBB0_1468:                              ; %else5082
	tbz	w8, #7, LBB0_1470
LBB0_1469:                              ; %cond.store5083
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1470:                              ; %else5086
	ldr	q0, [sp, #10528]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1992
; %bb.1471:                             ; %else5091
	ldr	q3, [sp, #3824]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_1993
LBB0_1472:                              ; %else5095
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1994
LBB0_1473:                              ; %else5099
	and.16b	v3, v3, v14
	tbnz	w8, #3, LBB0_1995
LBB0_1474:                              ; %else5103
	ldr	q0, [sp, #10544]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q24, [sp, #3440]                ; 16-byte Reload
	tbnz	w8, #4, LBB0_1996
LBB0_1475:                              ; %else5107
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_1997
LBB0_1476:                              ; %else5111
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1998
LBB0_1477:                              ; %else5115
	tbz	w8, #7, LBB0_1479
LBB0_1478:                              ; %cond.store5116
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1479:                              ; %else5119
	ldr	q0, [sp, #10560]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1999
; %bb.1480:                             ; %else5124
	ldr	q3, [sp, #3808]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2000
LBB0_1481:                              ; %else5128
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2001
LBB0_1482:                              ; %else5132
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2002
LBB0_1483:                              ; %else5136
	ldr	q0, [sp, #10576]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2003
LBB0_1484:                              ; %else5140
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2004
LBB0_1485:                              ; %else5144
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2005
LBB0_1486:                              ; %else5148
	tbz	w8, #7, LBB0_1488
LBB0_1487:                              ; %cond.store5149
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1488:                              ; %else5152
	ldr	q0, [sp, #10592]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1648]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2006
; %bb.1489:                             ; %else5157
	ldr	q3, [sp, #3792]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2007
LBB0_1490:                              ; %else5161
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2008
LBB0_1491:                              ; %else5165
	ldr	q4, [sp, #1632]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2009
LBB0_1492:                              ; %else5169
	ldr	q0, [sp, #10608]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q25, [sp, #608]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_2010
LBB0_1493:                              ; %else5173
	ldr	q3, [sp, #1616]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2011
LBB0_1494:                              ; %else5177
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2012
LBB0_1495:                              ; %else5181
	tbz	w8, #7, LBB0_1497
LBB0_1496:                              ; %cond.store5182
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1497:                              ; %else5185
	ldr	q0, [sp, #10624]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1600]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2013
; %bb.1498:                             ; %else5190
	ldr	q3, [sp, #3776]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2014
LBB0_1499:                              ; %else5194
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2015
LBB0_1500:                              ; %else5198
	ldr	q4, [sp, #1584]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2016
LBB0_1501:                              ; %else5202
	ldr	q0, [sp, #10640]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q26, [sp, #560]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_2017
LBB0_1502:                              ; %else5206
	ldr	q3, [sp, #1568]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2018
LBB0_1503:                              ; %else5210
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2019
LBB0_1504:                              ; %else5214
	tbz	w8, #7, LBB0_1506
LBB0_1505:                              ; %cond.store5215
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1506:                              ; %else5218
	ldr	q0, [sp, #10656]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2020
; %bb.1507:                             ; %else5223
	ldr	q3, [sp, #3760]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2021
LBB0_1508:                              ; %else5227
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2022
LBB0_1509:                              ; %else5231
	and.16b	v3, v3, v6
	tbnz	w8, #3, LBB0_2023
LBB0_1510:                              ; %else5235
	ldr	q0, [sp, #10672]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2024
LBB0_1511:                              ; %else5239
	ldr	q3, [sp, #1520]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2025
LBB0_1512:                              ; %else5243
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2026
LBB0_1513:                              ; %else5247
	tbz	w8, #7, LBB0_1515
LBB0_1514:                              ; %cond.store5248
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1515:                              ; %else5251
	ldr	q0, [sp, #10688]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1504]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2027
; %bb.1516:                             ; %else5256
	ldr	q3, [sp, #3744]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2028
LBB0_1517:                              ; %else5260
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2029
LBB0_1518:                              ; %else5264
	and.16b	v3, v3, v7
	tbnz	w8, #3, LBB0_2030
LBB0_1519:                              ; %else5268
	ldr	q0, [sp, #10704]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2031
LBB0_1520:                              ; %else5272
	ldr	q3, [sp, #1472]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2032
LBB0_1521:                              ; %else5276
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2033
LBB0_1522:                              ; %else5280
	tbz	w8, #7, LBB0_1524
LBB0_1523:                              ; %cond.store5281
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1524:                              ; %else5284
	ldr	q0, [sp, #10720]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1456]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2034
; %bb.1525:                             ; %else5289
	ldr	q3, [sp, #3728]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2035
LBB0_1526:                              ; %else5293
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2036
LBB0_1527:                              ; %else5297
	and.16b	v3, v3, v16
	tbnz	w8, #3, LBB0_2037
LBB0_1528:                              ; %else5301
	ldr	q0, [sp, #10736]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2038
LBB0_1529:                              ; %else5305
	ldr	q3, [sp, #1424]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2039
LBB0_1530:                              ; %else5309
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2040
LBB0_1531:                              ; %else5313
	tbz	w8, #7, LBB0_1533
LBB0_1532:                              ; %cond.store5314
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1533:                              ; %else5317
	ldr	q0, [sp, #10752]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1408]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2041
; %bb.1534:                             ; %else5322
	ldr	q3, [sp, #3712]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2042
LBB0_1535:                              ; %else5326
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2043
LBB0_1536:                              ; %else5330
	and.16b	v3, v3, v17
	tbnz	w8, #3, LBB0_2044
LBB0_1537:                              ; %else5334
	ldr	q0, [sp, #10768]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2045
LBB0_1538:                              ; %else5338
	ldr	q3, [sp, #1376]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2046
LBB0_1539:                              ; %else5342
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2047
LBB0_1540:                              ; %else5346
	tbz	w8, #7, LBB0_1542
LBB0_1541:                              ; %cond.store5347
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1542:                              ; %else5350
	ldr	q0, [sp, #10784]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1360]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2048
; %bb.1543:                             ; %else5355
	ldr	q3, [sp, #3696]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2049
LBB0_1544:                              ; %else5359
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2050
LBB0_1545:                              ; %else5363
	and.16b	v3, v3, v18
	tbnz	w8, #3, LBB0_2051
LBB0_1546:                              ; %else5367
	ldr	q0, [sp, #10800]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q6, [sp, #512]                  ; 16-byte Reload
	tbnz	w8, #4, LBB0_2052
LBB0_1547:                              ; %else5371
	ldr	q3, [sp, #1328]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2053
LBB0_1548:                              ; %else5375
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2054
LBB0_1549:                              ; %else5379
	tbz	w8, #7, LBB0_1551
LBB0_1550:                              ; %cond.store5380
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1551:                              ; %else5383
	ldr	q0, [sp, #10816]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1312]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2055
; %bb.1552:                             ; %else5388
	ldr	q3, [sp, #3680]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2056
LBB0_1553:                              ; %else5392
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2057
LBB0_1554:                              ; %else5396
	and.16b	v3, v3, v19
	tbnz	w8, #3, LBB0_2058
LBB0_1555:                              ; %else5400
	ldr	q0, [sp, #10832]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q7, [sp, #464]                  ; 16-byte Reload
	tbnz	w8, #4, LBB0_2059
LBB0_1556:                              ; %else5404
	ldr	q3, [sp, #1280]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2060
LBB0_1557:                              ; %else5408
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2061
LBB0_1558:                              ; %else5412
	tbz	w8, #7, LBB0_1560
LBB0_1559:                              ; %cond.store5413
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1560:                              ; %else5416
	ldr	q0, [sp, #10848]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1264]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2062
; %bb.1561:                             ; %else5421
	ldr	q3, [sp, #3664]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2063
LBB0_1562:                              ; %else5425
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2064
LBB0_1563:                              ; %else5429
	and.16b	v3, v3, v20
	tbnz	w8, #3, LBB0_2065
LBB0_1564:                              ; %else5433
	ldr	q0, [sp, #10864]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q16, [sp, #416]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_2066
LBB0_1565:                              ; %else5437
	ldr	q3, [sp, #1232]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2067
LBB0_1566:                              ; %else5441
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2068
LBB0_1567:                              ; %else5445
	tbz	w8, #7, LBB0_1569
LBB0_1568:                              ; %cond.store5446
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1569:                              ; %else5449
	ldr	q0, [sp, #10880]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1216]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2069
; %bb.1570:                             ; %else5454
	ldr	q3, [sp, #3648]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2070
LBB0_1571:                              ; %else5458
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2071
LBB0_1572:                              ; %else5462
	and.16b	v3, v3, v21
	tbnz	w8, #3, LBB0_2072
LBB0_1573:                              ; %else5466
	ldr	q0, [sp, #10896]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q17, [sp, #368]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_2073
LBB0_1574:                              ; %else5470
	ldr	q3, [sp, #1184]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2074
LBB0_1575:                              ; %else5474
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2075
LBB0_1576:                              ; %else5478
	tbz	w8, #7, LBB0_1578
LBB0_1577:                              ; %cond.store5479
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1578:                              ; %else5482
	ldr	q0, [sp, #10912]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1168]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2076
; %bb.1579:                             ; %else5487
	ldr	q3, [sp, #3632]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2077
LBB0_1580:                              ; %else5491
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2078
LBB0_1581:                              ; %else5495
	and.16b	v3, v3, v22
	tbnz	w8, #3, LBB0_2079
LBB0_1582:                              ; %else5499
	ldr	q0, [sp, #10928]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q18, [sp, #320]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_2080
LBB0_1583:                              ; %else5503
	ldr	q3, [sp, #1136]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2081
LBB0_1584:                              ; %else5507
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2082
LBB0_1585:                              ; %else5511
	tbz	w8, #7, LBB0_1587
LBB0_1586:                              ; %cond.store5512
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1587:                              ; %else5515
	ldr	q0, [sp, #10944]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1120]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2083
; %bb.1588:                             ; %else5520
	ldr	q3, [sp, #3616]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2084
LBB0_1589:                              ; %else5524
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2085
LBB0_1590:                              ; %else5528
	and.16b	v3, v3, v28
	tbnz	w8, #3, LBB0_2086
LBB0_1591:                              ; %else5532
	ldr	q0, [sp, #10960]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q22, [sp, #80]                  ; 16-byte Reload
	tbnz	w8, #4, LBB0_2087
LBB0_1592:                              ; %else5536
	ldr	q3, [sp, #1088]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2088
LBB0_1593:                              ; %else5540
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2089
LBB0_1594:                              ; %else5544
	tbz	w8, #7, LBB0_1596
LBB0_1595:                              ; %cond.store5545
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1596:                              ; %else5548
	ldr	q0, [sp, #10976]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1072]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2090
; %bb.1597:                             ; %else5553
	ldr	q3, [sp, #3600]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2091
LBB0_1598:                              ; %else5557
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2092
LBB0_1599:                              ; %else5561
	and.16b	v3, v3, v29
	tbnz	w8, #3, LBB0_2093
LBB0_1600:                              ; %else5565
	ldr	q0, [sp, #10992]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q28, [sp, #32]                  ; 16-byte Reload
	tbnz	w8, #4, LBB0_2094
LBB0_1601:                              ; %else5569
	ldr	q3, [sp, #1040]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2095
LBB0_1602:                              ; %else5573
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2096
LBB0_1603:                              ; %else5577
	tbz	w8, #7, LBB0_1605
LBB0_1604:                              ; %cond.store5578
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1605:                              ; %else5581
	ldr	q0, [sp, #11008]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #1024]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2097
; %bb.1606:                             ; %else5586
	ldr	q3, [sp, #3584]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2098
LBB0_1607:                              ; %else5590
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2099
LBB0_1608:                              ; %else5594
	ldr	q4, [sp, #1008]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2100
LBB0_1609:                              ; %else5598
	ldr	q0, [sp, #11024]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2101
LBB0_1610:                              ; %else5602
	ldr	q3, [sp, #992]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2102
LBB0_1611:                              ; %else5606
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2103
LBB0_1612:                              ; %else5610
	tbz	w8, #7, LBB0_1614
LBB0_1613:                              ; %cond.store5611
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1614:                              ; %else5614
	ldr	q0, [sp, #11040]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #976]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2104
; %bb.1615:                             ; %else5619
	ldr	q3, [sp, #3568]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2105
LBB0_1616:                              ; %else5623
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2106
LBB0_1617:                              ; %else5627
	and.16b	v3, v3, v31
	tbnz	w8, #3, LBB0_2107
LBB0_1618:                              ; %else5631
	ldr	q0, [sp, #11056]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2108
LBB0_1619:                              ; %else5635
	ldr	q3, [sp, #944]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2109
LBB0_1620:                              ; %else5639
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2110
LBB0_1621:                              ; %else5643
	tbz	w8, #7, LBB0_1623
LBB0_1622:                              ; %cond.store5644
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1623:                              ; %else5647
	ldr	q0, [sp, #11072]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #928]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2111
; %bb.1624:                             ; %else5652
	ldr	q3, [sp, #3552]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2112
LBB0_1625:                              ; %else5656
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2113
LBB0_1626:                              ; %else5660
	and.16b	v3, v3, v8
	tbnz	w8, #3, LBB0_2114
LBB0_1627:                              ; %else5664
	ldr	q0, [sp, #11088]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2115
LBB0_1628:                              ; %else5668
	ldr	q3, [sp, #896]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2116
LBB0_1629:                              ; %else5672
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2117
LBB0_1630:                              ; %else5676
	tbz	w8, #7, LBB0_1632
LBB0_1631:                              ; %cond.store5677
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1632:                              ; %else5680
	ldr	q0, [sp, #11104]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #880]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2118
; %bb.1633:                             ; %else5685
	ldr	q3, [sp, #3536]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2119
LBB0_1634:                              ; %else5689
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2120
LBB0_1635:                              ; %else5693
	and.16b	v3, v3, v9
	tbnz	w8, #3, LBB0_2121
LBB0_1636:                              ; %else5697
	ldr	q0, [sp, #11120]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2122
LBB0_1637:                              ; %else5701
	ldr	q3, [sp, #848]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2123
LBB0_1638:                              ; %else5705
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2124
LBB0_1639:                              ; %else5709
	tbz	w8, #7, LBB0_1641
LBB0_1640:                              ; %cond.store5710
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1641:                              ; %else5713
	ldr	q0, [sp, #11136]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #832]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2125
; %bb.1642:                             ; %else5718
	ldr	q3, [sp, #3520]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2126
LBB0_1643:                              ; %else5722
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2127
LBB0_1644:                              ; %else5726
	and.16b	v3, v3, v23
	tbnz	w8, #3, LBB0_2128
LBB0_1645:                              ; %else5730
	ldr	q0, [sp, #11152]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q19, [sp, #272]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_2129
LBB0_1646:                              ; %else5734
	ldr	q3, [sp, #800]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2130
LBB0_1647:                              ; %else5738
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2131
LBB0_1648:                              ; %else5742
	tbz	w8, #7, LBB0_1650
LBB0_1649:                              ; %cond.store5743
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1650:                              ; %else5746
	ldr	q0, [sp, #11168]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #784]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2132
; %bb.1651:                             ; %else5751
	ldr	q3, [sp, #3504]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2133
LBB0_1652:                              ; %else5755
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2134
LBB0_1653:                              ; %else5759
	ldr	q4, [sp, #768]                  ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2135
LBB0_1654:                              ; %else5763
	ldr	q0, [sp, #11184]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2136
LBB0_1655:                              ; %else5767
	ldr	q3, [sp, #752]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2137
LBB0_1656:                              ; %else5771
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2138
LBB0_1657:                              ; %else5775
	tbz	w8, #7, LBB0_1659
LBB0_1658:                              ; %cond.store5776
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1659:                              ; %else5779
	ldr	q0, [sp, #11200]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #736]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2139
; %bb.1660:                             ; %else5784
	ldr	q3, [sp, #3488]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2140
LBB0_1661:                              ; %else5788
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2141
LBB0_1662:                              ; %else5792
	ldr	q4, [sp, #3472]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2142
LBB0_1663:                              ; %else5796
	ldr	q0, [sp, #11216]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2143
LBB0_1664:                              ; %else5800
	ldr	q3, [sp, #720]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2144
LBB0_1665:                              ; %else5804
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2145
LBB0_1666:                              ; %else5808
	tbz	w8, #7, LBB0_1668
LBB0_1667:                              ; %cond.store5809
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1668:                              ; %else5812
	ldr	q0, [sp, #11232]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #704]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2146
; %bb.1669:                             ; %else5817
	ldr	q3, [sp, #3456]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2147
LBB0_1670:                              ; %else5821
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2148
LBB0_1671:                              ; %else5825
	and.16b	v3, v3, v24
	tbnz	w8, #3, LBB0_2149
LBB0_1672:                              ; %else5829
	ldr	q0, [sp, #11248]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q20, [sp, #224]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_2150
LBB0_1673:                              ; %else5833
	ldr	q3, [sp, #688]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2151
LBB0_1674:                              ; %else5837
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2152
LBB0_1675:                              ; %else5841
	tbz	w8, #7, LBB0_1677
LBB0_1676:                              ; %cond.store5842
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1677:                              ; %else5845
	ldr	q0, [sp, #11264]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #672]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2153
; %bb.1678:                             ; %else5850
	ldr	q3, [sp, #3424]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2154
LBB0_1679:                              ; %else5854
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2155
LBB0_1680:                              ; %else5858
	ldr	q4, [sp, #656]                  ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2156
LBB0_1681:                              ; %else5862
	ldr	q0, [sp, #11280]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2157
LBB0_1682:                              ; %else5866
	ldr	q3, [sp, #640]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2158
LBB0_1683:                              ; %else5870
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2159
LBB0_1684:                              ; %else5874
	tbz	w8, #7, LBB0_1686
LBB0_1685:                              ; %cond.store5875
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1686:                              ; %else5878
	ldr	q0, [sp, #11296]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #624]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2160
; %bb.1687:                             ; %else5883
	ldr	q3, [sp, #3408]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2161
LBB0_1688:                              ; %else5887
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2162
LBB0_1689:                              ; %else5891
	and.16b	v3, v3, v25
	tbnz	w8, #3, LBB0_2163
LBB0_1690:                              ; %else5895
	ldr	q0, [sp, #11312]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2164
LBB0_1691:                              ; %else5899
	ldr	q3, [sp, #592]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2165
LBB0_1692:                              ; %else5903
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2166
LBB0_1693:                              ; %else5907
	tbz	w8, #7, LBB0_1695
LBB0_1694:                              ; %cond.store5908
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1695:                              ; %else5911
	ldr	q0, [sp, #11328]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #576]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2167
; %bb.1696:                             ; %else5916
	ldr	q3, [sp, #3392]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2168
LBB0_1697:                              ; %else5920
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2169
LBB0_1698:                              ; %else5924
	and.16b	v3, v3, v26
	tbnz	w8, #3, LBB0_2170
LBB0_1699:                              ; %else5928
	ldr	q0, [sp, #11344]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q21, [sp, #176]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_2171
LBB0_1700:                              ; %else5932
	ldr	q3, [sp, #544]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2172
LBB0_1701:                              ; %else5936
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2173
LBB0_1702:                              ; %else5940
	tbz	w8, #7, LBB0_1704
LBB0_1703:                              ; %cond.store5941
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1704:                              ; %else5944
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #528]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2174
; %bb.1705:                             ; %else5949
	ldr	q3, [sp, #3376]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2175
LBB0_1706:                              ; %else5953
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2176
LBB0_1707:                              ; %else5957
	and.16b	v3, v3, v6
	tbnz	w8, #3, LBB0_2177
LBB0_1708:                              ; %else5961
	ldr	q0, [sp, #11376]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2178
LBB0_1709:                              ; %else5965
	ldr	q3, [sp, #496]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2179
LBB0_1710:                              ; %else5969
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2180
LBB0_1711:                              ; %else5973
	tbz	w8, #7, LBB0_1713
LBB0_1712:                              ; %cond.store5974
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1713:                              ; %else5977
	ldr	q0, [sp, #11392]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #480]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2181
; %bb.1714:                             ; %else5982
	ldr	q3, [sp, #3360]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2182
LBB0_1715:                              ; %else5986
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2183
LBB0_1716:                              ; %else5990
	and.16b	v3, v3, v7
	tbnz	w8, #3, LBB0_2184
LBB0_1717:                              ; %else5994
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2185
LBB0_1718:                              ; %else5998
	ldr	q3, [sp, #448]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2186
LBB0_1719:                              ; %else6002
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2187
LBB0_1720:                              ; %else6006
	tbz	w8, #7, LBB0_1722
LBB0_1721:                              ; %cond.store6007
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1722:                              ; %else6010
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #432]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2188
; %bb.1723:                             ; %else6015
	ldr	q3, [sp, #3344]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2189
LBB0_1724:                              ; %else6019
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2190
LBB0_1725:                              ; %else6023
	and.16b	v3, v3, v16
	tbnz	w8, #3, LBB0_2191
LBB0_1726:                              ; %else6027
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2192
LBB0_1727:                              ; %else6031
	ldr	q3, [sp, #400]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2193
LBB0_1728:                              ; %else6035
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2194
LBB0_1729:                              ; %else6039
	tbz	w8, #7, LBB0_1731
LBB0_1730:                              ; %cond.store6040
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1731:                              ; %else6043
	ldr	q0, [sp, #11456]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #384]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2195
; %bb.1732:                             ; %else6048
	ldr	q3, [sp, #3328]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2196
LBB0_1733:                              ; %else6052
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2197
LBB0_1734:                              ; %else6056
	and.16b	v3, v3, v17
	tbnz	w8, #3, LBB0_2198
LBB0_1735:                              ; %else6060
	ldr	q0, [sp, #11472]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2199
LBB0_1736:                              ; %else6064
	ldr	q3, [sp, #352]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2200
LBB0_1737:                              ; %else6068
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2201
LBB0_1738:                              ; %else6072
	tbz	w8, #7, LBB0_1740
LBB0_1739:                              ; %cond.store6073
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1740:                              ; %else6076
	ldr	q0, [sp, #11488]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #336]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2202
; %bb.1741:                             ; %else6081
	ldr	q3, [sp, #3312]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2203
LBB0_1742:                              ; %else6085
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2204
LBB0_1743:                              ; %else6089
	and.16b	v3, v3, v18
	tbnz	w8, #3, LBB0_2205
LBB0_1744:                              ; %else6093
	ldr	q0, [sp, #11504]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2206
LBB0_1745:                              ; %else6097
	ldr	q3, [sp, #304]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2207
LBB0_1746:                              ; %else6101
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2208
LBB0_1747:                              ; %else6105
	tbz	w8, #7, LBB0_1749
LBB0_1748:                              ; %cond.store6106
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1749:                              ; %else6109
	ldr	q0, [sp, #11520]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #288]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2209
; %bb.1750:                             ; %else6114
	ldr	q3, [sp, #3296]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2210
LBB0_1751:                              ; %else6118
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2211
LBB0_1752:                              ; %else6122
	and.16b	v3, v3, v19
	tbnz	w8, #3, LBB0_2212
LBB0_1753:                              ; %else6126
	ldr	q0, [sp, #11536]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2213
LBB0_1754:                              ; %else6130
	ldr	q3, [sp, #256]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2214
LBB0_1755:                              ; %else6134
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2215
LBB0_1756:                              ; %else6138
	tbz	w8, #7, LBB0_1758
LBB0_1757:                              ; %cond.store6139
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1758:                              ; %else6142
	ldr	q0, [sp, #11552]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #240]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2216
; %bb.1759:                             ; %else6147
	ldr	q3, [sp, #3280]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2217
LBB0_1760:                              ; %else6151
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2218
LBB0_1761:                              ; %else6155
	and.16b	v3, v3, v20
	tbnz	w8, #3, LBB0_2219
LBB0_1762:                              ; %else6159
	ldr	q0, [sp, #11568]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2220
LBB0_1763:                              ; %else6163
	ldr	q3, [sp, #208]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2221
LBB0_1764:                              ; %else6167
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2222
LBB0_1765:                              ; %else6171
	tbz	w8, #7, LBB0_1767
LBB0_1766:                              ; %cond.store6172
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1767:                              ; %else6175
	ldr	q0, [sp, #11584]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #192]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2223
; %bb.1768:                             ; %else6180
	ldr	q3, [sp, #3264]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2224
LBB0_1769:                              ; %else6184
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2225
LBB0_1770:                              ; %else6188
	and.16b	v3, v3, v21
	tbnz	w8, #3, LBB0_2226
LBB0_1771:                              ; %else6192
	ldr	q0, [sp, #11600]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2227
LBB0_1772:                              ; %else6196
	ldr	q3, [sp, #160]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2228
LBB0_1773:                              ; %else6200
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2229
LBB0_1774:                              ; %else6204
	tbz	w8, #7, LBB0_1776
LBB0_1775:                              ; %cond.store6205
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1776:                              ; %else6208
	ldr	q0, [sp, #11616]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #144]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2230
; %bb.1777:                             ; %else6213
	ldr	q3, [sp, #3248]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2231
LBB0_1778:                              ; %else6217
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2232
LBB0_1779:                              ; %else6221
	and.16b	v3, v3, v27
	tbnz	w8, #3, LBB0_2233
LBB0_1780:                              ; %else6225
	ldr	q0, [sp, #11632]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2234
LBB0_1781:                              ; %else6229
	ldr	q3, [sp, #112]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2235
LBB0_1782:                              ; %else6233
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2236
LBB0_1783:                              ; %else6237
	tbz	w8, #7, LBB0_1785
LBB0_1784:                              ; %cond.store6238
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1785:                              ; %else6241
	ldr	q0, [sp, #11648]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #96]                   ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2237
; %bb.1786:                             ; %else6246
	ldr	q3, [sp, #3232]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2238
LBB0_1787:                              ; %else6250
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2239
LBB0_1788:                              ; %else6254
	and.16b	v3, v3, v22
	tbnz	w8, #3, LBB0_2240
LBB0_1789:                              ; %else6258
	ldr	q0, [sp, #11664]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2241
LBB0_1790:                              ; %else6262
	ldr	q3, [sp, #64]                   ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2242
LBB0_1791:                              ; %else6266
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2243
LBB0_1792:                              ; %else6270
	tbz	w8, #7, LBB0_1794
LBB0_1793:                              ; %cond.store6271
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1794:                              ; %else6274
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	fdiv.4s	v0, v0, v15
	fmov	w9, s5
	and	w8, w9, #0xff
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #48]                   ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2244
; %bb.1795:                             ; %else6279
	ldr	q3, [sp, #3216]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbnz	w8, #1, LBB0_2245
LBB0_1796:                              ; %else6283
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2246
LBB0_1797:                              ; %else6287
	and.16b	v3, v3, v28
	tbnz	w8, #3, LBB0_2247
LBB0_1798:                              ; %else6291
	ldr	q0, [sp, #11696]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2248
LBB0_1799:                              ; %else6295
	ldr	q3, [sp, #16]                   ; 16-byte Reload
	and.16b	v3, v10, v3
	tbnz	w8, #5, LBB0_2249
LBB0_1800:                              ; %else6299
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2250
LBB0_1801:                              ; %else6303
	tbz	w8, #7, LBB0_1803
LBB0_1802:                              ; %cond.store6304
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1803:                              ; %common.ret
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #3808
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_1804:                              ; %cond.store
	fmov	x9, d1
	str	s0, [x9]
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1228
LBB0_1805:                              ; %cond.store4208
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1229
LBB0_1806:                              ; %cond.store4211
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v6
	tbz	w8, #3, LBB0_1230
LBB0_1807:                              ; %cond.store4214
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9680]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1231
LBB0_1808:                              ; %cond.store4217
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v3, v7
	tbz	w8, #5, LBB0_1232
LBB0_1809:                              ; %cond.store4220
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1233
LBB0_1810:                              ; %cond.store4223
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1234
	b	LBB0_1235
LBB0_1811:                              ; %cond.store4230
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v16
	tbz	w8, #1, LBB0_1237
LBB0_1812:                              ; %cond.store4234
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1238
LBB0_1813:                              ; %cond.store4238
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v17
	tbz	w8, #3, LBB0_1239
LBB0_1814:                              ; %cond.store4242
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9712]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1240
LBB0_1815:                              ; %cond.store4246
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3088]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1241
LBB0_1816:                              ; %cond.store4250
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1242
LBB0_1817:                              ; %cond.store4254
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1243
	b	LBB0_1244
LBB0_1818:                              ; %cond.store4263
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v18
	tbz	w8, #1, LBB0_1246
LBB0_1819:                              ; %cond.store4267
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q6, [sp, #2496]                 ; 16-byte Reload
	tbz	w8, #2, LBB0_1247
LBB0_1820:                              ; %cond.store4271
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v19
	tbz	w8, #3, LBB0_1248
LBB0_1821:                              ; %cond.store4275
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9744]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q7, [sp, #2448]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1249
LBB0_1822:                              ; %cond.store4279
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1250
LBB0_1823:                              ; %cond.store4283
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1251
LBB0_1824:                              ; %cond.store4287
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1252
	b	LBB0_1253
LBB0_1825:                              ; %cond.store4296
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v20
	tbz	w8, #1, LBB0_1255
LBB0_1826:                              ; %cond.store4300
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q16, [sp, #2400]                ; 16-byte Reload
	tbz	w8, #2, LBB0_1256
LBB0_1827:                              ; %cond.store4304
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v21
	tbz	w8, #3, LBB0_1257
LBB0_1828:                              ; %cond.store4308
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9776]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q17, [sp, #2352]                ; 16-byte Reload
	tbz	w8, #4, LBB0_1258
LBB0_1829:                              ; %cond.store4312
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2960]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1259
LBB0_1830:                              ; %cond.store4316
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1260
LBB0_1831:                              ; %cond.store4320
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1261
	b	LBB0_1262
LBB0_1832:                              ; %cond.store4329
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v22
	tbz	w8, #1, LBB0_1264
LBB0_1833:                              ; %cond.store4333
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q18, [sp, #2304]                ; 16-byte Reload
	tbz	w8, #2, LBB0_1265
LBB0_1834:                              ; %cond.store4337
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v23
	tbz	w8, #3, LBB0_1266
LBB0_1835:                              ; %cond.store4341
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9808]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q19, [sp, #2256]                ; 16-byte Reload
	tbz	w8, #4, LBB0_1267
LBB0_1836:                              ; %cond.store4345
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1268
LBB0_1837:                              ; %cond.store4349
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1269
LBB0_1838:                              ; %cond.store4353
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1270
	b	LBB0_1271
LBB0_1839:                              ; %cond.store4362
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v24
	tbz	w8, #1, LBB0_1273
LBB0_1840:                              ; %cond.store4366
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q20, [sp, #2208]                ; 16-byte Reload
	tbz	w8, #2, LBB0_1274
LBB0_1841:                              ; %cond.store4370
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v25
	tbz	w8, #3, LBB0_1275
LBB0_1842:                              ; %cond.store4374
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9840]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1276
LBB0_1843:                              ; %cond.store4378
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2832]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1277
LBB0_1844:                              ; %cond.store4382
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1278
LBB0_1845:                              ; %cond.store4386
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1279
	b	LBB0_1280
LBB0_1846:                              ; %cond.store4395
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v26
	tbz	w8, #1, LBB0_1282
LBB0_1847:                              ; %cond.store4399
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q21, [sp, #2160]                ; 16-byte Reload
	tbz	w8, #2, LBB0_1283
LBB0_1848:                              ; %cond.store4403
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2784]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1284
LBB0_1849:                              ; %cond.store4407
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9872]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1285
LBB0_1850:                              ; %cond.store4411
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2768]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1286
LBB0_1851:                              ; %cond.store4415
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1287
LBB0_1852:                              ; %cond.store4419
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1288
	b	LBB0_1289
LBB0_1853:                              ; %cond.store4428
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v27
	tbz	w8, #1, LBB0_1291
LBB0_1854:                              ; %cond.store4432
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q22, [sp, #2112]                ; 16-byte Reload
	tbz	w8, #2, LBB0_1292
LBB0_1855:                              ; %cond.store4436
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v28
	tbz	w8, #3, LBB0_1293
LBB0_1856:                              ; %cond.store4440
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9904]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q23, [sp, #2064]                ; 16-byte Reload
	ldr	q28, [sp, #1104]                ; 16-byte Reload
	tbz	w8, #4, LBB0_1294
LBB0_1857:                              ; %cond.store4444
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2704]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1295
LBB0_1858:                              ; %cond.store4448
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1296
LBB0_1859:                              ; %cond.store4452
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1297
	b	LBB0_1298
LBB0_1860:                              ; %cond.store4461
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v29
	tbz	w8, #1, LBB0_1300
LBB0_1861:                              ; %cond.store4465
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q24, [sp, #2016]                ; 16-byte Reload
	ldr	q29, [sp, #1056]                ; 16-byte Reload
	tbz	w8, #2, LBB0_1301
LBB0_1862:                              ; %cond.store4469
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v31
	tbz	w8, #3, LBB0_1302
LBB0_1863:                              ; %cond.store4473
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9936]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1303
LBB0_1864:                              ; %cond.store4477
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2640]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1304
LBB0_1865:                              ; %cond.store4481
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1305
LBB0_1866:                              ; %cond.store4485
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1306
	b	LBB0_1307
LBB0_1867:                              ; %cond.store4494
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v8
	tbz	w8, #1, LBB0_1309
LBB0_1868:                              ; %cond.store4498
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q25, [sp, #1920]                ; 16-byte Reload
	ldr	q31, [sp, #960]                 ; 16-byte Reload
	tbz	w8, #2, LBB0_1310
LBB0_1869:                              ; %cond.store4502
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2592]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1311
LBB0_1870:                              ; %cond.store4506
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9952]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1312
LBB0_1871:                              ; %cond.store4510
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2576]                 ; 16-byte Reload
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1313
LBB0_1872:                              ; %cond.store4514
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1314
LBB0_1873:                              ; %cond.store4518
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1315
	b	LBB0_1316
LBB0_1874:                              ; %cond.store4527
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v3, v9
	tbz	w8, #1, LBB0_1318
LBB0_1875:                              ; %cond.store4531
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	ldr	q26, [sp, #1872]                ; 16-byte Reload
	ldr	q8, [sp, #912]                  ; 16-byte Reload
	tbz	w8, #2, LBB0_1319
LBB0_1876:                              ; %cond.store4535
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v10
	tbnz	w8, #3, LBB0_1320
	b	LBB0_1321
LBB0_1877:                              ; %cond.store4543
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1323
LBB0_1878:                              ; %cond.store4547
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1324
LBB0_1879:                              ; %cond.store4551
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1325
	b	LBB0_1326
LBB0_1880:                              ; %cond.store4560
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4080]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1328
LBB0_1881:                              ; %cond.store4564
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1329
LBB0_1882:                              ; %cond.store4568
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v6
	tbz	w8, #3, LBB0_1330
LBB0_1883:                              ; %cond.store4572
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10032]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1331
LBB0_1884:                              ; %cond.store4576
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2480]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1332
LBB0_1885:                              ; %cond.store4580
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1333
LBB0_1886:                              ; %cond.store4584
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1334
	b	LBB0_1335
LBB0_1887:                              ; %cond.store4593
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4064]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1337
LBB0_1888:                              ; %cond.store4597
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1338
LBB0_1889:                              ; %cond.store4601
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v7
	tbz	w8, #3, LBB0_1339
LBB0_1890:                              ; %cond.store4605
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10064]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1340
LBB0_1891:                              ; %cond.store4609
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1341
LBB0_1892:                              ; %cond.store4613
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1342
LBB0_1893:                              ; %cond.store4617
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1343
	b	LBB0_1344
LBB0_1894:                              ; %cond.store4626
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4048]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1346
LBB0_1895:                              ; %cond.store4630
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1347
LBB0_1896:                              ; %cond.store4634
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v16
	tbz	w8, #3, LBB0_1348
LBB0_1897:                              ; %cond.store4638
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10096]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1349
LBB0_1898:                              ; %cond.store4642
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2384]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1350
LBB0_1899:                              ; %cond.store4646
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1351
LBB0_1900:                              ; %cond.store4650
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1352
	b	LBB0_1353
LBB0_1901:                              ; %cond.store4659
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4032]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1355
LBB0_1902:                              ; %cond.store4663
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1356
LBB0_1903:                              ; %cond.store4667
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v17
	tbz	w8, #3, LBB0_1357
LBB0_1904:                              ; %cond.store4671
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10128]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1358
LBB0_1905:                              ; %cond.store4675
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2336]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1359
LBB0_1906:                              ; %cond.store4679
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1360
LBB0_1907:                              ; %cond.store4683
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1361
	b	LBB0_1362
LBB0_1908:                              ; %cond.store4692
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4016]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1364
LBB0_1909:                              ; %cond.store4696
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1365
LBB0_1910:                              ; %cond.store4700
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v18
	tbz	w8, #3, LBB0_1366
LBB0_1911:                              ; %cond.store4704
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10160]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q6, [sp, #1536]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1367
LBB0_1912:                              ; %cond.store4708
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2288]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1368
LBB0_1913:                              ; %cond.store4712
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1369
LBB0_1914:                              ; %cond.store4716
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1370
	b	LBB0_1371
LBB0_1915:                              ; %cond.store4725
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4000]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1373
LBB0_1916:                              ; %cond.store4729
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1374
LBB0_1917:                              ; %cond.store4733
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v19
	tbz	w8, #3, LBB0_1375
LBB0_1918:                              ; %cond.store4737
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10240]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q7, [sp, #1488]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1376
LBB0_1919:                              ; %cond.store4741
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2240]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1377
LBB0_1920:                              ; %cond.store4745
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1378
LBB0_1921:                              ; %cond.store4749
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1379
	b	LBB0_1380
LBB0_1922:                              ; %cond.store4758
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3984]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1382
LBB0_1923:                              ; %cond.store4762
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1383
LBB0_1924:                              ; %cond.store4766
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v20
	tbz	w8, #3, LBB0_1384
LBB0_1925:                              ; %cond.store4770
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10304]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q16, [sp, #1440]                ; 16-byte Reload
	tbz	w8, #4, LBB0_1385
LBB0_1926:                              ; %cond.store4774
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1386
LBB0_1927:                              ; %cond.store4778
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1387
LBB0_1928:                              ; %cond.store4782
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1388
	b	LBB0_1389
LBB0_1929:                              ; %cond.store4791
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3968]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1391
LBB0_1930:                              ; %cond.store4795
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1392
LBB0_1931:                              ; %cond.store4799
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v21
	tbz	w8, #3, LBB0_1393
LBB0_1932:                              ; %cond.store4803
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10368]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q17, [sp, #1392]                ; 16-byte Reload
	tbz	w8, #4, LBB0_1394
LBB0_1933:                              ; %cond.store4807
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1395
LBB0_1934:                              ; %cond.store4811
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1396
LBB0_1935:                              ; %cond.store4815
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1397
	b	LBB0_1398
LBB0_1936:                              ; %cond.store4824
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3952]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1400
LBB0_1937:                              ; %cond.store4828
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1401
LBB0_1938:                              ; %cond.store4832
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v22
	tbz	w8, #3, LBB0_1402
LBB0_1939:                              ; %cond.store4836
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10208]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q18, [sp, #1344]                ; 16-byte Reload
	tbz	w8, #4, LBB0_1403
LBB0_1940:                              ; %cond.store4840
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1404
LBB0_1941:                              ; %cond.store4844
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1405
LBB0_1942:                              ; %cond.store4848
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1406
	b	LBB0_1407
LBB0_1943:                              ; %cond.store4857
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3936]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1409
LBB0_1944:                              ; %cond.store4861
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1410
LBB0_1945:                              ; %cond.store4865
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v23
	tbz	w8, #3, LBB0_1411
LBB0_1946:                              ; %cond.store4869
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10272]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q19, [sp, #1296]                ; 16-byte Reload
	tbz	w8, #4, LBB0_1412
LBB0_1947:                              ; %cond.store4873
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1413
LBB0_1948:                              ; %cond.store4877
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1414
LBB0_1949:                              ; %cond.store4881
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1415
	b	LBB0_1416
LBB0_1950:                              ; %cond.store4890
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3920]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1418
LBB0_1951:                              ; %cond.store4894
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1419
LBB0_1952:                              ; %cond.store4898
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v24
	tbz	w8, #3, LBB0_1420
LBB0_1953:                              ; %cond.store4902
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10320]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q20, [sp, #1248]                ; 16-byte Reload
	tbz	w8, #4, LBB0_1421
LBB0_1954:                              ; %cond.store4906
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1422
LBB0_1955:                              ; %cond.store4910
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1423
LBB0_1956:                              ; %cond.store4914
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1424
	b	LBB0_1425
LBB0_1957:                              ; %cond.store4923
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3904]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1427
LBB0_1958:                              ; %cond.store4927
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1428
LBB0_1959:                              ; %cond.store4931
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1429
LBB0_1960:                              ; %cond.store4935
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10384]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1430
LBB0_1961:                              ; %cond.store4939
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1431
LBB0_1962:                              ; %cond.store4943
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1432
LBB0_1963:                              ; %cond.store4947
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1433
	b	LBB0_1434
LBB0_1964:                              ; %cond.store4956
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3888]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1436
LBB0_1965:                              ; %cond.store4960
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1437
LBB0_1966:                              ; %cond.store4964
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v25
	tbz	w8, #3, LBB0_1438
LBB0_1967:                              ; %cond.store4968
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10416]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1439
LBB0_1968:                              ; %cond.store4972
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1440
LBB0_1969:                              ; %cond.store4976
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1441
LBB0_1970:                              ; %cond.store4980
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1442
	b	LBB0_1443
LBB0_1971:                              ; %cond.store4989
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3872]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1445
LBB0_1972:                              ; %cond.store4993
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1446
LBB0_1973:                              ; %cond.store4997
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v26
	tbz	w8, #3, LBB0_1447
LBB0_1974:                              ; %cond.store5001
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10448]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q21, [sp, #1200]                ; 16-byte Reload
	tbz	w8, #4, LBB0_1448
LBB0_1975:                              ; %cond.store5005
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1449
LBB0_1976:                              ; %cond.store5009
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1450
LBB0_1977:                              ; %cond.store5013
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1451
	b	LBB0_1452
LBB0_1978:                              ; %cond.store5022
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3856]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1454
LBB0_1979:                              ; %cond.store5026
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1455
LBB0_1980:                              ; %cond.store5030
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v27
	tbz	w8, #3, LBB0_1456
LBB0_1981:                              ; %cond.store5034
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10480]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q22, [sp, #1152]                ; 16-byte Reload
	ldr	q27, [sp, #128]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1457
LBB0_1982:                              ; %cond.store5038
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1458
LBB0_1983:                              ; %cond.store5042
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1459
LBB0_1984:                              ; %cond.store5046
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1460
	b	LBB0_1461
LBB0_1985:                              ; %cond.store5055
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v4, v4, v3
	tbz	w8, #1, LBB0_1463
LBB0_1986:                              ; %cond.store5059
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1464
LBB0_1987:                              ; %cond.store5063
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v11
	tbz	w8, #3, LBB0_1465
LBB0_1988:                              ; %cond.store5067
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10512]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q23, [sp, #816]                 ; 16-byte Reload
	ldr	q11, [sp, #4128]                ; 16-byte Reload
	tbz	w8, #4, LBB0_1466
LBB0_1989:                              ; %cond.store5071
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1467
LBB0_1990:                              ; %cond.store5075
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1468
LBB0_1991:                              ; %cond.store5079
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1469
	b	LBB0_1470
LBB0_1992:                              ; %cond.store5088
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3824]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1472
LBB0_1993:                              ; %cond.store5092
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1473
LBB0_1994:                              ; %cond.store5096
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v14
	tbz	w8, #3, LBB0_1474
LBB0_1995:                              ; %cond.store5100
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10544]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q24, [sp, #3440]                ; 16-byte Reload
	tbz	w8, #4, LBB0_1475
LBB0_1996:                              ; %cond.store5104
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1476
LBB0_1997:                              ; %cond.store5108
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1477
LBB0_1998:                              ; %cond.store5112
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1478
	b	LBB0_1479
LBB0_1999:                              ; %cond.store5121
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3808]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1481
LBB0_2000:                              ; %cond.store5125
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1482
LBB0_2001:                              ; %cond.store5129
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1483
LBB0_2002:                              ; %cond.store5133
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10576]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1484
LBB0_2003:                              ; %cond.store5137
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1485
LBB0_2004:                              ; %cond.store5141
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1486
LBB0_2005:                              ; %cond.store5145
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1487
	b	LBB0_1488
LBB0_2006:                              ; %cond.store5154
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3792]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1490
LBB0_2007:                              ; %cond.store5158
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1491
LBB0_2008:                              ; %cond.store5162
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #1632]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1492
LBB0_2009:                              ; %cond.store5166
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10608]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q25, [sp, #608]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1493
LBB0_2010:                              ; %cond.store5170
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1616]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1494
LBB0_2011:                              ; %cond.store5174
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1495
LBB0_2012:                              ; %cond.store5178
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1496
	b	LBB0_1497
LBB0_2013:                              ; %cond.store5187
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3776]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1499
LBB0_2014:                              ; %cond.store5191
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1500
LBB0_2015:                              ; %cond.store5195
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #1584]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1501
LBB0_2016:                              ; %cond.store5199
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10640]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q26, [sp, #560]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1502
LBB0_2017:                              ; %cond.store5203
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1568]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1503
LBB0_2018:                              ; %cond.store5207
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1504
LBB0_2019:                              ; %cond.store5211
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1505
	b	LBB0_1506
LBB0_2020:                              ; %cond.store5220
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3760]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1508
LBB0_2021:                              ; %cond.store5224
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1509
LBB0_2022:                              ; %cond.store5228
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v6
	tbz	w8, #3, LBB0_1510
LBB0_2023:                              ; %cond.store5232
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10672]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1511
LBB0_2024:                              ; %cond.store5236
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1520]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1512
LBB0_2025:                              ; %cond.store5240
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1513
LBB0_2026:                              ; %cond.store5244
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1514
	b	LBB0_1515
LBB0_2027:                              ; %cond.store5253
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3744]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1517
LBB0_2028:                              ; %cond.store5257
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1518
LBB0_2029:                              ; %cond.store5261
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v7
	tbz	w8, #3, LBB0_1519
LBB0_2030:                              ; %cond.store5265
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10704]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1520
LBB0_2031:                              ; %cond.store5269
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1472]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1521
LBB0_2032:                              ; %cond.store5273
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1522
LBB0_2033:                              ; %cond.store5277
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1523
	b	LBB0_1524
LBB0_2034:                              ; %cond.store5286
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3728]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1526
LBB0_2035:                              ; %cond.store5290
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1527
LBB0_2036:                              ; %cond.store5294
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v16
	tbz	w8, #3, LBB0_1528
LBB0_2037:                              ; %cond.store5298
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10736]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1529
LBB0_2038:                              ; %cond.store5302
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1424]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1530
LBB0_2039:                              ; %cond.store5306
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1531
LBB0_2040:                              ; %cond.store5310
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1532
	b	LBB0_1533
LBB0_2041:                              ; %cond.store5319
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3712]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1535
LBB0_2042:                              ; %cond.store5323
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1536
LBB0_2043:                              ; %cond.store5327
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v17
	tbz	w8, #3, LBB0_1537
LBB0_2044:                              ; %cond.store5331
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10768]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1538
LBB0_2045:                              ; %cond.store5335
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1376]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1539
LBB0_2046:                              ; %cond.store5339
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1540
LBB0_2047:                              ; %cond.store5343
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1541
	b	LBB0_1542
LBB0_2048:                              ; %cond.store5352
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3696]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1544
LBB0_2049:                              ; %cond.store5356
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1545
LBB0_2050:                              ; %cond.store5360
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v18
	tbz	w8, #3, LBB0_1546
LBB0_2051:                              ; %cond.store5364
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10800]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q6, [sp, #512]                  ; 16-byte Reload
	tbz	w8, #4, LBB0_1547
LBB0_2052:                              ; %cond.store5368
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1328]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1548
LBB0_2053:                              ; %cond.store5372
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1549
LBB0_2054:                              ; %cond.store5376
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1550
	b	LBB0_1551
LBB0_2055:                              ; %cond.store5385
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3680]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1553
LBB0_2056:                              ; %cond.store5389
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1554
LBB0_2057:                              ; %cond.store5393
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v19
	tbz	w8, #3, LBB0_1555
LBB0_2058:                              ; %cond.store5397
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10832]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q7, [sp, #464]                  ; 16-byte Reload
	tbz	w8, #4, LBB0_1556
LBB0_2059:                              ; %cond.store5401
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1280]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1557
LBB0_2060:                              ; %cond.store5405
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1558
LBB0_2061:                              ; %cond.store5409
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1559
	b	LBB0_1560
LBB0_2062:                              ; %cond.store5418
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3664]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1562
LBB0_2063:                              ; %cond.store5422
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1563
LBB0_2064:                              ; %cond.store5426
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v20
	tbz	w8, #3, LBB0_1564
LBB0_2065:                              ; %cond.store5430
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10864]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q16, [sp, #416]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1565
LBB0_2066:                              ; %cond.store5434
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1232]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1566
LBB0_2067:                              ; %cond.store5438
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1567
LBB0_2068:                              ; %cond.store5442
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1568
	b	LBB0_1569
LBB0_2069:                              ; %cond.store5451
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3648]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1571
LBB0_2070:                              ; %cond.store5455
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1572
LBB0_2071:                              ; %cond.store5459
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v21
	tbz	w8, #3, LBB0_1573
LBB0_2072:                              ; %cond.store5463
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10896]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q17, [sp, #368]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1574
LBB0_2073:                              ; %cond.store5467
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1184]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1575
LBB0_2074:                              ; %cond.store5471
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1576
LBB0_2075:                              ; %cond.store5475
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1577
	b	LBB0_1578
LBB0_2076:                              ; %cond.store5484
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3632]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1580
LBB0_2077:                              ; %cond.store5488
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1581
LBB0_2078:                              ; %cond.store5492
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v22
	tbz	w8, #3, LBB0_1582
LBB0_2079:                              ; %cond.store5496
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10928]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q18, [sp, #320]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1583
LBB0_2080:                              ; %cond.store5500
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1136]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1584
LBB0_2081:                              ; %cond.store5504
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1585
LBB0_2082:                              ; %cond.store5508
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1586
	b	LBB0_1587
LBB0_2083:                              ; %cond.store5517
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3616]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1589
LBB0_2084:                              ; %cond.store5521
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1590
LBB0_2085:                              ; %cond.store5525
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v28
	tbz	w8, #3, LBB0_1591
LBB0_2086:                              ; %cond.store5529
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10960]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q22, [sp, #80]                  ; 16-byte Reload
	tbz	w8, #4, LBB0_1592
LBB0_2087:                              ; %cond.store5533
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1088]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1593
LBB0_2088:                              ; %cond.store5537
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1594
LBB0_2089:                              ; %cond.store5541
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1595
	b	LBB0_1596
LBB0_2090:                              ; %cond.store5550
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3600]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1598
LBB0_2091:                              ; %cond.store5554
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1599
LBB0_2092:                              ; %cond.store5558
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v29
	tbz	w8, #3, LBB0_1600
LBB0_2093:                              ; %cond.store5562
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10992]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q28, [sp, #32]                  ; 16-byte Reload
	tbz	w8, #4, LBB0_1601
LBB0_2094:                              ; %cond.store5566
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1040]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1602
LBB0_2095:                              ; %cond.store5570
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1603
LBB0_2096:                              ; %cond.store5574
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1604
	b	LBB0_1605
LBB0_2097:                              ; %cond.store5583
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3584]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1607
LBB0_2098:                              ; %cond.store5587
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1608
LBB0_2099:                              ; %cond.store5591
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #1008]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1609
LBB0_2100:                              ; %cond.store5595
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11024]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1610
LBB0_2101:                              ; %cond.store5599
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #992]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1611
LBB0_2102:                              ; %cond.store5603
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1612
LBB0_2103:                              ; %cond.store5607
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1613
	b	LBB0_1614
LBB0_2104:                              ; %cond.store5616
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3568]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1616
LBB0_2105:                              ; %cond.store5620
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1617
LBB0_2106:                              ; %cond.store5624
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v31
	tbz	w8, #3, LBB0_1618
LBB0_2107:                              ; %cond.store5628
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11056]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1619
LBB0_2108:                              ; %cond.store5632
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #944]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1620
LBB0_2109:                              ; %cond.store5636
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1621
LBB0_2110:                              ; %cond.store5640
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1622
	b	LBB0_1623
LBB0_2111:                              ; %cond.store5649
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3552]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1625
LBB0_2112:                              ; %cond.store5653
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1626
LBB0_2113:                              ; %cond.store5657
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v8
	tbz	w8, #3, LBB0_1627
LBB0_2114:                              ; %cond.store5661
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11088]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1628
LBB0_2115:                              ; %cond.store5665
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #896]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1629
LBB0_2116:                              ; %cond.store5669
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1630
LBB0_2117:                              ; %cond.store5673
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1631
	b	LBB0_1632
LBB0_2118:                              ; %cond.store5682
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3536]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1634
LBB0_2119:                              ; %cond.store5686
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1635
LBB0_2120:                              ; %cond.store5690
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v9
	tbz	w8, #3, LBB0_1636
LBB0_2121:                              ; %cond.store5694
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11120]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1637
LBB0_2122:                              ; %cond.store5698
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #848]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1638
LBB0_2123:                              ; %cond.store5702
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1639
LBB0_2124:                              ; %cond.store5706
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1640
	b	LBB0_1641
LBB0_2125:                              ; %cond.store5715
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3520]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1643
LBB0_2126:                              ; %cond.store5719
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1644
LBB0_2127:                              ; %cond.store5723
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v23
	tbz	w8, #3, LBB0_1645
LBB0_2128:                              ; %cond.store5727
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11152]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q19, [sp, #272]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1646
LBB0_2129:                              ; %cond.store5731
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #800]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1647
LBB0_2130:                              ; %cond.store5735
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1648
LBB0_2131:                              ; %cond.store5739
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1649
	b	LBB0_1650
LBB0_2132:                              ; %cond.store5748
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3504]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1652
LBB0_2133:                              ; %cond.store5752
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1653
LBB0_2134:                              ; %cond.store5756
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #768]                  ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1654
LBB0_2135:                              ; %cond.store5760
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11184]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1655
LBB0_2136:                              ; %cond.store5764
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #752]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1656
LBB0_2137:                              ; %cond.store5768
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1657
LBB0_2138:                              ; %cond.store5772
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1658
	b	LBB0_1659
LBB0_2139:                              ; %cond.store5781
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3488]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1661
LBB0_2140:                              ; %cond.store5785
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1662
LBB0_2141:                              ; %cond.store5789
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3472]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1663
LBB0_2142:                              ; %cond.store5793
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11216]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1664
LBB0_2143:                              ; %cond.store5797
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #720]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1665
LBB0_2144:                              ; %cond.store5801
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1666
LBB0_2145:                              ; %cond.store5805
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1667
	b	LBB0_1668
LBB0_2146:                              ; %cond.store5814
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3456]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1670
LBB0_2147:                              ; %cond.store5818
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1671
LBB0_2148:                              ; %cond.store5822
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v24
	tbz	w8, #3, LBB0_1672
LBB0_2149:                              ; %cond.store5826
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11248]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q20, [sp, #224]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1673
LBB0_2150:                              ; %cond.store5830
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #688]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1674
LBB0_2151:                              ; %cond.store5834
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1675
LBB0_2152:                              ; %cond.store5838
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1676
	b	LBB0_1677
LBB0_2153:                              ; %cond.store5847
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3424]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1679
LBB0_2154:                              ; %cond.store5851
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1680
LBB0_2155:                              ; %cond.store5855
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #656]                  ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1681
LBB0_2156:                              ; %cond.store5859
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11280]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1682
LBB0_2157:                              ; %cond.store5863
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #640]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1683
LBB0_2158:                              ; %cond.store5867
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1684
LBB0_2159:                              ; %cond.store5871
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1685
	b	LBB0_1686
LBB0_2160:                              ; %cond.store5880
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3408]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1688
LBB0_2161:                              ; %cond.store5884
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1689
LBB0_2162:                              ; %cond.store5888
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v25
	tbz	w8, #3, LBB0_1690
LBB0_2163:                              ; %cond.store5892
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11312]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1691
LBB0_2164:                              ; %cond.store5896
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #592]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1692
LBB0_2165:                              ; %cond.store5900
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1693
LBB0_2166:                              ; %cond.store5904
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1694
	b	LBB0_1695
LBB0_2167:                              ; %cond.store5913
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3392]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1697
LBB0_2168:                              ; %cond.store5917
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1698
LBB0_2169:                              ; %cond.store5921
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v26
	tbz	w8, #3, LBB0_1699
LBB0_2170:                              ; %cond.store5925
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11344]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	ldr	q21, [sp, #176]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1700
LBB0_2171:                              ; %cond.store5929
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #544]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1701
LBB0_2172:                              ; %cond.store5933
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1702
LBB0_2173:                              ; %cond.store5937
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1703
	b	LBB0_1704
LBB0_2174:                              ; %cond.store5946
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3376]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1706
LBB0_2175:                              ; %cond.store5950
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1707
LBB0_2176:                              ; %cond.store5954
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v6
	tbz	w8, #3, LBB0_1708
LBB0_2177:                              ; %cond.store5958
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11376]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1709
LBB0_2178:                              ; %cond.store5962
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #496]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1710
LBB0_2179:                              ; %cond.store5966
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1711
LBB0_2180:                              ; %cond.store5970
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1712
	b	LBB0_1713
LBB0_2181:                              ; %cond.store5979
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3360]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1715
LBB0_2182:                              ; %cond.store5983
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1716
LBB0_2183:                              ; %cond.store5987
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v7
	tbz	w8, #3, LBB0_1717
LBB0_2184:                              ; %cond.store5991
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1718
LBB0_2185:                              ; %cond.store5995
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #448]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1719
LBB0_2186:                              ; %cond.store5999
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1720
LBB0_2187:                              ; %cond.store6003
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1721
	b	LBB0_1722
LBB0_2188:                              ; %cond.store6012
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3344]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1724
LBB0_2189:                              ; %cond.store6016
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1725
LBB0_2190:                              ; %cond.store6020
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v16
	tbz	w8, #3, LBB0_1726
LBB0_2191:                              ; %cond.store6024
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1727
LBB0_2192:                              ; %cond.store6028
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #400]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1728
LBB0_2193:                              ; %cond.store6032
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1729
LBB0_2194:                              ; %cond.store6036
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1730
	b	LBB0_1731
LBB0_2195:                              ; %cond.store6045
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3328]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1733
LBB0_2196:                              ; %cond.store6049
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1734
LBB0_2197:                              ; %cond.store6053
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v17
	tbz	w8, #3, LBB0_1735
LBB0_2198:                              ; %cond.store6057
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11472]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1736
LBB0_2199:                              ; %cond.store6061
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #352]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1737
LBB0_2200:                              ; %cond.store6065
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1738
LBB0_2201:                              ; %cond.store6069
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1739
	b	LBB0_1740
LBB0_2202:                              ; %cond.store6078
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3312]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1742
LBB0_2203:                              ; %cond.store6082
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1743
LBB0_2204:                              ; %cond.store6086
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v18
	tbz	w8, #3, LBB0_1744
LBB0_2205:                              ; %cond.store6090
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11504]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1745
LBB0_2206:                              ; %cond.store6094
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #304]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1746
LBB0_2207:                              ; %cond.store6098
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1747
LBB0_2208:                              ; %cond.store6102
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1748
	b	LBB0_1749
LBB0_2209:                              ; %cond.store6111
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3296]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1751
LBB0_2210:                              ; %cond.store6115
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1752
LBB0_2211:                              ; %cond.store6119
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v19
	tbz	w8, #3, LBB0_1753
LBB0_2212:                              ; %cond.store6123
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11536]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1754
LBB0_2213:                              ; %cond.store6127
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #256]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1755
LBB0_2214:                              ; %cond.store6131
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1756
LBB0_2215:                              ; %cond.store6135
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1757
	b	LBB0_1758
LBB0_2216:                              ; %cond.store6144
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3280]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1760
LBB0_2217:                              ; %cond.store6148
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1761
LBB0_2218:                              ; %cond.store6152
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v20
	tbz	w8, #3, LBB0_1762
LBB0_2219:                              ; %cond.store6156
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11568]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1763
LBB0_2220:                              ; %cond.store6160
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #208]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1764
LBB0_2221:                              ; %cond.store6164
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1765
LBB0_2222:                              ; %cond.store6168
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1766
	b	LBB0_1767
LBB0_2223:                              ; %cond.store6177
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3264]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1769
LBB0_2224:                              ; %cond.store6181
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1770
LBB0_2225:                              ; %cond.store6185
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v21
	tbz	w8, #3, LBB0_1771
LBB0_2226:                              ; %cond.store6189
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11600]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1772
LBB0_2227:                              ; %cond.store6193
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #160]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1773
LBB0_2228:                              ; %cond.store6197
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1774
LBB0_2229:                              ; %cond.store6201
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1775
	b	LBB0_1776
LBB0_2230:                              ; %cond.store6210
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3248]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1778
LBB0_2231:                              ; %cond.store6214
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1779
LBB0_2232:                              ; %cond.store6218
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v27
	tbz	w8, #3, LBB0_1780
LBB0_2233:                              ; %cond.store6222
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11632]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1781
LBB0_2234:                              ; %cond.store6226
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #112]                  ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1782
LBB0_2235:                              ; %cond.store6230
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1783
LBB0_2236:                              ; %cond.store6234
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1784
	b	LBB0_1785
LBB0_2237:                              ; %cond.store6243
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3232]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1787
LBB0_2238:                              ; %cond.store6247
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1788
LBB0_2239:                              ; %cond.store6251
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v22
	tbz	w8, #3, LBB0_1789
LBB0_2240:                              ; %cond.store6255
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11664]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1790
LBB0_2241:                              ; %cond.store6259
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #64]                   ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1791
LBB0_2242:                              ; %cond.store6263
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1792
LBB0_2243:                              ; %cond.store6267
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1793
	b	LBB0_1794
LBB0_2244:                              ; %cond.store6276
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3216]                 ; 16-byte Reload
	and.16b	v4, v11, v3
	tbz	w8, #1, LBB0_1796
LBB0_2245:                              ; %cond.store6280
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v13, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1797
LBB0_2246:                              ; %cond.store6284
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v28
	tbz	w8, #3, LBB0_1798
LBB0_2247:                              ; %cond.store6288
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11696]                ; 16-byte Reload
	fdiv.4s	v0, v0, v12
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1799
LBB0_2248:                              ; %cond.store6292
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #16]                   ; 16-byte Reload
	and.16b	v3, v10, v3
	tbz	w8, #5, LBB0_1800
LBB0_2249:                              ; %cond.store6296
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1801
LBB0_2250:                              ; %cond.store6300
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1802
	b	LBB0_1803
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

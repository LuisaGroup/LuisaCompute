; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill31, align 64
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca i64, align 8
  store i64 0, ptr %.slot33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %tile_snapshot.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill42, align 64
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %.spill44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill44, align 64
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca i64, align 8
  store i64 0, ptr %.slot48, align 4
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca i64, align 8
  store i64 0, ptr %.slot50, align 4
  %.slot51 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca i64, align 8
  store i64 0, ptr %.slot52, align 4
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca i64, align 8
  store i64 0, ptr %.slot54, align 4
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca i64, align 8
  store i64 0, ptr %.slot58, align 4
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca i64, align 8
  store i64 0, ptr %.slot60, align 4
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca i64, align 8
  store i64 0, ptr %.slot62, align 4
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca i64, align 8
  store i64 0, ptr %.slot64, align 4
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.slot66 = alloca i64, align 8
  store i64 0, ptr %.slot66, align 4
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.slot68 = alloca i64, align 8
  store i64 0, ptr %.slot68, align 4
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca i64, align 8
  store i64 0, ptr %.slot70, align 4
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca i64, align 8
  store i64 0, ptr %.slot72, align 4
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca i64, align 8
  store i64 0, ptr %.slot74, align 4
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca i64, align 8
  store i64 0, ptr %.slot76, align 4
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.spill78 = alloca i64, align 8
  store i64 0, ptr %.spill78, align 4
  %.spill79 = alloca i1, align 1
  store i1 false, ptr %.spill79, align 1
  %.spill80 = alloca i1, align 1
  store i1 false, ptr %.spill80, align 1
  %.spill81 = alloca i1, align 1
  store i1 false, ptr %.spill81, align 1
  %.spill82 = alloca i1, align 1
  store i1 false, ptr %.spill82, align 1
  %.spill83 = alloca i1, align 1
  store i1 false, ptr %.spill83, align 1
  %.spill84 = alloca i1, align 1
  store i1 false, ptr %.spill84, align 1
  %.spill85 = alloca i1, align 1
  store i1 false, ptr %.spill85, align 1
  %.spill86 = alloca i1, align 1
  store i1 false, ptr %.spill86, align 1
  %.spill87 = alloca i1, align 1
  store i1 false, ptr %.spill87, align 1
  %.spill88 = alloca i1, align 1
  store i1 false, ptr %.spill88, align 1
  %.spill89 = alloca i1, align 1
  store i1 false, ptr %.spill89, align 1
  %.spill90 = alloca i1, align 1
  store i1 false, ptr %.spill90, align 1
  %.spill91 = alloca i1, align 1
  store i1 false, ptr %.spill91, align 1
  %.spill92 = alloca i1, align 1
  store i1 false, ptr %.spill92, align 1
  %.spill93 = alloca i1, align 1
  store i1 false, ptr %.spill93, align 1
  %.spill94 = alloca i1, align 1
  store i1 false, ptr %.spill94, align 1
  %.spill95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill100, align 32
  %.spill101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill103, align 32
  %.spill104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill104, align 32
  %.spill105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.spill106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill106, align 32
  %.spill107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill108, align 32
  %.spill109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill109, align 32
  %.spill110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill110, align 32
  %tile_snapshot.spill111 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill111, align 64
  %.slot112 = alloca i64, align 8
  store i64 0, ptr %.slot112, align 4
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.spill114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill114, align 32
  %.spill115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill115, align 32
  %tile_snapshot.spill116 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill116, align 64
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.slot118 = alloca i64, align 8
  store i64 0, ptr %.slot118, align 4
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %tile_snapshot.spill121 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill121, align 64
  %.slot122 = alloca i64, align 8
  store i64 0, ptr %.slot122, align 4
  %.slot123 = alloca i64, align 8
  store i64 0, ptr %.slot123, align 4
  %.slot124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot124, align 32
  %.slot125 = alloca i64, align 8
  store i64 0, ptr %.slot125, align 4
  %.slot126 = alloca i64, align 8
  store i64 0, ptr %.slot126, align 4
  %.slot127 = alloca i64, align 8
  store i64 0, ptr %.slot127, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert128 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat129 = shufflevector <8 x i32> %.splatinsert128, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat129, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert130 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat131 = shufflevector <8 x i32> %.splatinsert130, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat131, %61
  %64 = mul i32 %52, 1
  %.splatinsert132 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat133 = shufflevector <8 x i32> %.splatinsert132, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat133, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert134 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat135 = shufflevector <8 x i32> %.splatinsert134, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat135, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert136 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat137 = shufflevector <8 x i32> %.splatinsert136, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat137
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  store i64 0, ptr %.spill29, align 4
  %80 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = load <8 x i64>, ptr %.spill30, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill30, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %94 = icmp slt i64 %.state, 80
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load i64, ptr %.spill29, align 4
  %95 = add i64 %.spill.load, 0
  %.spill.load138 = load <8 x i64>, ptr %.spill, align 64
  %96 = add <8 x i64> %.spill.load138, zeroinitializer
  %97 = mul i64 %95, 8
  %.splatinsert139 = insertelement <8 x i64> poison, i64 %97, i64 0
  %.splat140 = shufflevector <8 x i64> %.splatinsert139, <8 x i64> poison, <8 x i32> zeroinitializer
  %98 = add <8 x i64> %.splat140, %96
  %.spill.load141 = load i64, ptr %.spill29, align 4
  %99 = add i64 %.spill.load141, 0
  %100 = mul <8 x i64> %98, splat (i64 1)
  %.splatinsert142 = insertelement <8 x i64> poison, i64 %99, i64 0
  %.splat143 = shufflevector <8 x i64> %.splatinsert142, <8 x i64> poison, <8 x i32> zeroinitializer
  %101 = add <8 x i64> %100, %.splat143
  %.state144 = load i64, ptr %.slot, align 4
  %102 = add i64 0, %.state144
  %103 = mul <8 x i64> %101, splat (i64 80)
  %.splatinsert145 = insertelement <8 x i64> poison, i64 %102, i64 0
  %.splat146 = shufflevector <8 x i64> %.splatinsert145, <8 x i64> poison, <8 x i32> zeroinitializer
  %104 = add <8 x i64> %103, %.splat146
  %105 = extractvalue { ptr, i64 } %29, 0
  %106 = mul <8 x i64> %104, splat (i64 4)
  %107 = getelementptr i8, ptr %105, <8 x i64> %106
  %108 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %107, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state147 = load i64, ptr %.slot, align 4
  %.splatinsert148 = insertelement <8 x i64> poison, i64 %.state147, i64 0
  %.splat149 = shufflevector <8 x i64> %.splatinsert148, <8 x i64> poison, <8 x i32> zeroinitializer
  %111 = mul <8 x i64> %.splat149, splat (i64 32)
  %112 = add <8 x i64> %110, %111
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %109, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %114, 1
  %117 = extractelement <8 x ptr> %115, i32 0
  %118 = extractelement <8 x i64> %116, i32 0
  %119 = sub i64 %118, 0
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %121 = select i1 %120, i64 %119, i64 0
  %private.contiguous.address = getelementptr i8, ptr %117, i64 %121
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %122 = select <8 x i1> %71, <8 x float> %108, <8 x float> %private.contiguous.preserve
  store <8 x float> %122, ptr %private.contiguous.address, align 4
  %.state150 = load i64, ptr %.slot, align 4
  %123 = add i64 %.state150, 1
  store i64 %123, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %71, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %71, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill31, align 64
  %133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 0
  %136 = select <8 x i1> %71, <8 x ptr> %134, <8 x ptr> %135
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %139 = select <8 x i1> %71, <8 x i64> %137, <8 x i64> %138
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  store { <8 x ptr>, <8 x i64> } %141, ptr %tile_snapshot.spill32, align 64
  store i64 0, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state151 = load i64, ptr %.slot33, align 4
  %142 = icmp slt i64 %.state151, 96
  br i1 %142, label %direct.true152, label %direct.false153

direct.schedule.5:                                ; preds = %direct.true152
  %tile_snapshot.spill.load154 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 1
  %.state155 = load i64, ptr %.slot33, align 4
  %.splatinsert156 = insertelement <8 x i64> poison, i64 %.state155, i64 0
  %.splat157 = shufflevector <8 x i64> %.splatinsert156, <8 x i64> poison, <8 x i32> zeroinitializer
  %145 = mul <8 x i64> %.splat157, splat (i64 32)
  %146 = add <8 x i64> %144, %145
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %143, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %148, 1
  %151 = extractelement <8 x ptr> %149, i32 0
  %152 = extractelement <8 x i64> %150, i32 0
  %153 = sub i64 %152, 0
  %154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %155 = select i1 %154, i64 %153, i64 0
  %private.contiguous.address158 = getelementptr i8, ptr %151, i64 %155
  %private.contiguous.preserve159 = load <8 x float>, ptr %private.contiguous.address158, align 4
  %156 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve159
  store <8 x float> %156, ptr %private.contiguous.address158, align 4
  %.state160 = load i64, ptr %.slot33, align 4
  %157 = add i64 %.state160, 1
  store i64 %157, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false153
  store i64 0, ptr %.slot34, align 4
  %158 = load <8 x float>, ptr %.slot35, align 32
  %159 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %158
  store <8 x float> %159, ptr %.slot35, align 32
  %160 = load <8 x float>, ptr %.slot36, align 32
  %161 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %160
  store <8 x float> %161, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.84, %direct.schedule.6
  %.state161 = load i64, ptr %.slot34, align 4
  %162 = icmp slt i64 %.state161, 129
  br i1 %162, label %direct.true162, label %direct.false163

direct.schedule.8:                                ; preds = %direct.true162
  %.state164 = load i64, ptr %.slot34, align 4
  %163 = sdiv i64 %.state164, 1
  %164 = mul i64 %163, 16
  store i64 %164, ptr %.spill37, align 4
  %165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %168 = select <8 x i1> %71, <8 x ptr> %166, <8 x ptr> %167
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %171 = select <8 x i1> %71, <8 x i64> %169, <8 x i64> %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  store { <8 x ptr>, <8 x i64> } %173, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state165 = load i64, ptr %.slot39, align 4
  %174 = icmp slt i64 %.state165, 1280
  br i1 %174, label %direct.true166, label %direct.false167

direct.schedule.10:                               ; preds = %direct.true166
  %.state168 = load i64, ptr %.slot39, align 4
  %175 = srem i64 %.state168, 80
  %.state169 = load i64, ptr %.slot39, align 4
  %176 = sdiv i64 %.state169, 80
  %.spill.load170 = load i64, ptr %.spill29, align 4
  %177 = add i64 %.spill.load170, 0
  %.spill.load171 = load <8 x i64>, ptr %.spill30, align 64
  %178 = add <8 x i64> %.spill.load171, zeroinitializer
  %179 = mul i64 %177, 2
  %.splatinsert172 = insertelement <8 x i64> poison, i64 %179, i64 0
  %.splat173 = shufflevector <8 x i64> %.splatinsert172, <8 x i64> poison, <8 x i32> zeroinitializer
  %180 = add <8 x i64> %.splat173, %178
  %.spill.load174 = load i64, ptr %.spill37, align 4
  %181 = add i64 %.spill.load174, %176
  %182 = mul <8 x i64> %180, splat (i64 2053)
  %.splatinsert175 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat176 = shufflevector <8 x i64> %.splatinsert175, <8 x i64> poison, <8 x i32> zeroinitializer
  %183 = add <8 x i64> %182, %.splat176
  %184 = icmp sge i64 %181, 0
  %185 = and i1 true, %184
  %186 = icmp slt i64 %181, 2053
  %187 = and i1 %185, %186
  %188 = add i64 0, %175
  %189 = mul <8 x i64> %183, splat (i64 80)
  %.splatinsert177 = insertelement <8 x i64> poison, i64 %188, i64 0
  %.splat178 = shufflevector <8 x i64> %.splatinsert177, <8 x i64> poison, <8 x i32> zeroinitializer
  %190 = add <8 x i64> %189, %.splat178
  %191 = load <8 x i64>, ptr %.spill40, align 64
  %192 = select <8 x i1> %71, <8 x i64> %190, <8 x i64> %191
  store <8 x i64> %192, ptr %.spill40, align 64
  br i1 %187, label %direct.true179, label %direct.false180

direct.schedule.11:                               ; preds = %direct.true179
  %.spill.load181 = load <8 x i64>, ptr %.spill40, align 64
  %193 = extractvalue { ptr, i64 } %35, 0
  %194 = mul <8 x i64> %.spill.load181, splat (i64 4)
  %195 = getelementptr i8, ptr %193, <8 x i64> %194
  %196 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %195, <8 x i1> %71, <8 x float> zeroinitializer)
  %197 = load <8 x float>, ptr %.slot41, align 32
  %198 = select <8 x i1> %71, <8 x float> %196, <8 x float> %197
  store <8 x float> %198, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.11, %direct.false180
  %tile_snapshot.spill.load182 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 1
  %.state183 = load i64, ptr %.slot39, align 4
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %.state183, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %201 = mul <8 x i64> %.splat185, splat (i64 32)
  %202 = add <8 x i64> %200, %201
  %203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %199, 0
  %204 = insertvalue { <8 x ptr>, <8 x i64> } %203, <8 x i64> %202, 1
  %.state186 = load <8 x float>, ptr %.slot41, align 32
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %204, 1
  %207 = extractelement <8 x ptr> %205, i32 0
  %208 = extractelement <8 x i64> %206, i32 0
  %209 = sub i64 %208, 0
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %211 = select i1 %210, i64 %209, i64 0
  %private.contiguous.address187 = getelementptr i8, ptr %207, i64 %211
  %private.contiguous.preserve188 = load <8 x float>, ptr %private.contiguous.address187, align 4
  %212 = select <8 x i1> %71, <8 x float> %.state186, <8 x float> %private.contiguous.preserve188
  store <8 x float> %212, ptr %private.contiguous.address187, align 4
  %.state189 = load i64, ptr %.slot39, align 4
  %213 = add i64 %.state189, 1
  store i64 %213, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false167
  %214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %214, 0
  %217 = select <8 x i1> %71, <8 x ptr> %215, <8 x ptr> %216
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %214, 1
  %220 = select <8 x i1> %71, <8 x i64> %218, <8 x i64> %219
  %221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %222 = insertvalue { <8 x ptr>, <8 x i64> } %221, <8 x i64> %220, 1
  store { <8 x ptr>, <8 x i64> } %222, ptr %tile_snapshot.spill42, align 64
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state190 = load i64, ptr %.slot43, align 4
  %223 = icmp slt i64 %.state190, 1536
  br i1 %223, label %direct.true191, label %direct.false192

direct.schedule.15:                               ; preds = %direct.true191
  %.state193 = load i64, ptr %.slot43, align 4
  %224 = srem i64 %.state193, 96
  %.state194 = load i64, ptr %.slot43, align 4
  %225 = sdiv i64 %.state194, 96
  %.spill.load195 = load i64, ptr %.spill29, align 4
  %226 = add i64 %.spill.load195, 0
  %.spill.load196 = load <8 x i64>, ptr %.spill30, align 64
  %227 = add <8 x i64> %.spill.load196, zeroinitializer
  %228 = mul i64 %226, 2
  %.splatinsert197 = insertelement <8 x i64> poison, i64 %228, i64 0
  %.splat198 = shufflevector <8 x i64> %.splatinsert197, <8 x i64> poison, <8 x i32> zeroinitializer
  %229 = add <8 x i64> %.splat198, %227
  %.spill.load199 = load i64, ptr %.spill37, align 4
  %230 = add i64 %.spill.load199, %225
  %231 = mul <8 x i64> %229, splat (i64 2053)
  %.splatinsert200 = insertelement <8 x i64> poison, i64 %230, i64 0
  %.splat201 = shufflevector <8 x i64> %.splatinsert200, <8 x i64> poison, <8 x i32> zeroinitializer
  %232 = add <8 x i64> %231, %.splat201
  %233 = icmp sge i64 %230, 0
  %234 = and i1 true, %233
  %235 = icmp slt i64 %230, 2053
  %236 = and i1 %234, %235
  %237 = add i64 0, %224
  %238 = mul <8 x i64> %232, splat (i64 96)
  %.splatinsert202 = insertelement <8 x i64> poison, i64 %237, i64 0
  %.splat203 = shufflevector <8 x i64> %.splatinsert202, <8 x i64> poison, <8 x i32> zeroinitializer
  %239 = add <8 x i64> %238, %.splat203
  %240 = load <8 x i64>, ptr %.spill44, align 64
  %241 = select <8 x i1> %71, <8 x i64> %239, <8 x i64> %240
  store <8 x i64> %241, ptr %.spill44, align 64
  br i1 %236, label %direct.true204, label %direct.false205

direct.schedule.16:                               ; preds = %direct.true204
  %.spill.load206 = load <8 x i64>, ptr %.spill44, align 64
  %242 = extractvalue { ptr, i64 } %41, 0
  %243 = mul <8 x i64> %.spill.load206, splat (i64 4)
  %244 = getelementptr i8, ptr %242, <8 x i64> %243
  %245 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %244, <8 x i1> %71, <8 x float> zeroinitializer)
  %246 = load <8 x float>, ptr %.slot45, align 32
  %247 = select <8 x i1> %71, <8 x float> %245, <8 x float> %246
  store <8 x float> %247, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.16, %direct.false205
  %tile_snapshot.spill.load207 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load207, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load207, 1
  %.state208 = load i64, ptr %.slot43, align 4
  %.splatinsert209 = insertelement <8 x i64> poison, i64 %.state208, i64 0
  %.splat210 = shufflevector <8 x i64> %.splatinsert209, <8 x i64> poison, <8 x i32> zeroinitializer
  %250 = mul <8 x i64> %.splat210, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %.state211 = load <8 x float>, ptr %.slot45, align 32
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address212 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.preserve213 = load <8 x float>, ptr %private.contiguous.address212, align 4
  %261 = select <8 x i1> %71, <8 x float> %.state211, <8 x float> %private.contiguous.preserve213
  store <8 x float> %261, ptr %private.contiguous.address212, align 4
  %.state214 = load i64, ptr %.slot43, align 4
  %262 = add i64 %.state214, 1
  store i64 %262, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false192
  store i64 0, ptr %.slot46, align 4
  %263 = load <8 x float>, ptr %.slot47, align 32
  %264 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %263
  store <8 x float> %264, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state215 = load i64, ptr %.slot46, align 4
  %265 = icmp slt i64 %.state215, 80
  br i1 %265, label %direct.true216, label %direct.false217

direct.schedule.20:                               ; preds = %direct.true216
  %.state218 = load i64, ptr %.slot46, align 4
  %266 = add i64 0, %.state218
  %tile_snapshot.spill.load219 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load219, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load219, 1
  %.splatinsert220 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat221 = shufflevector <8 x i64> %.splatinsert220, <8 x i64> poison, <8 x i32> zeroinitializer
  %269 = mul <8 x i64> %.splat221, splat (i64 32)
  %270 = add <8 x i64> %268, %269
  %271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %267, 0
  %272 = insertvalue { <8 x ptr>, <8 x i64> } %271, <8 x i64> %270, 1
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %272, 1
  %275 = extractelement <8 x ptr> %273, i32 0
  %276 = extractelement <8 x i64> %274, i32 0
  %277 = sub i64 %276, 0
  %278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %279 = select i1 %278, i64 %277, i64 0
  %private.contiguous.address222 = getelementptr i8, ptr %275, i64 %279
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address222, align 4
  %280 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load223 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load223, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load223, 1
  %.splatinsert224 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat225 = shufflevector <8 x i64> %.splatinsert224, <8 x i64> poison, <8 x i32> zeroinitializer
  %283 = mul <8 x i64> %.splat225, splat (i64 32)
  %284 = add <8 x i64> %282, %283
  %285 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %281, 0
  %286 = insertvalue { <8 x ptr>, <8 x i64> } %285, <8 x i64> %284, 1
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %286, 1
  %289 = extractelement <8 x ptr> %287, i32 0
  %290 = extractelement <8 x i64> %288, i32 0
  %291 = sub i64 %290, 0
  %292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %293 = select i1 %292, i64 %291, i64 0
  %private.contiguous.address226 = getelementptr i8, ptr %289, i64 %293
  %private.contiguous.load227 = load <8 x float>, ptr %private.contiguous.address226, align 4
  %294 = select <8 x i1> %71, <8 x float> %private.contiguous.load227, <8 x float> zeroinitializer
  %295 = fmul <8 x float> %280, %294
  %.state228 = load <8 x float>, ptr %.slot47, align 32
  %296 = fadd <8 x float> %.state228, %295
  %.state229 = load i64, ptr %.slot46, align 4
  %297 = add i64 %.state229, 1
  store i64 %297, ptr %.slot46, align 4
  %298 = load <8 x float>, ptr %.slot47, align 32
  %299 = select <8 x i1> %71, <8 x float> %296, <8 x float> %298
  store <8 x float> %299, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false217
  store i64 0, ptr %.slot48, align 4
  %300 = load <8 x float>, ptr %.slot49, align 32
  %301 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %300
  store <8 x float> %301, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state230 = load i64, ptr %.slot48, align 4
  %302 = icmp slt i64 %.state230, 80
  br i1 %302, label %direct.true231, label %direct.false232

direct.schedule.23:                               ; preds = %direct.true231
  %.state233 = load i64, ptr %.slot48, align 4
  %303 = add i64 0, %.state233
  %tile_snapshot.spill.load234 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 1
  %.splatinsert235 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat236 = shufflevector <8 x i64> %.splatinsert235, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat236, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address237 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load238 = load <8 x float>, ptr %private.contiguous.address237, align 4
  %317 = select <8 x i1> %71, <8 x float> %private.contiguous.load238, <8 x float> zeroinitializer
  %.state239 = load i64, ptr %.slot48, align 4
  %318 = add i64 80, %.state239
  %tile_snapshot.spill.load240 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 0
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 1
  %.splatinsert241 = insertelement <8 x i64> poison, i64 %318, i64 0
  %.splat242 = shufflevector <8 x i64> %.splatinsert241, <8 x i64> poison, <8 x i32> zeroinitializer
  %321 = mul <8 x i64> %.splat242, splat (i64 32)
  %322 = add <8 x i64> %320, %321
  %323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %319, 0
  %324 = insertvalue { <8 x ptr>, <8 x i64> } %323, <8 x i64> %322, 1
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %324, 1
  %327 = extractelement <8 x ptr> %325, i32 0
  %328 = extractelement <8 x i64> %326, i32 0
  %329 = sub i64 %328, 0
  %330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %331 = select i1 %330, i64 %329, i64 0
  %private.contiguous.address243 = getelementptr i8, ptr %327, i64 %331
  %private.contiguous.load244 = load <8 x float>, ptr %private.contiguous.address243, align 4
  %332 = select <8 x i1> %71, <8 x float> %private.contiguous.load244, <8 x float> zeroinitializer
  %333 = fmul <8 x float> %317, %332
  %.state245 = load <8 x float>, ptr %.slot49, align 32
  %334 = fadd <8 x float> %.state245, %333
  %.state246 = load i64, ptr %.slot48, align 4
  %335 = add i64 %.state246, 1
  store i64 %335, ptr %.slot48, align 4
  %336 = load <8 x float>, ptr %.slot49, align 32
  %337 = select <8 x i1> %71, <8 x float> %334, <8 x float> %336
  store <8 x float> %337, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false232
  store i64 0, ptr %.slot50, align 4
  %338 = load <8 x float>, ptr %.slot51, align 32
  %339 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %338
  store <8 x float> %339, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state247 = load i64, ptr %.slot50, align 4
  %340 = icmp slt i64 %.state247, 80
  br i1 %340, label %direct.true248, label %direct.false249

direct.schedule.26:                               ; preds = %direct.true248
  %.state250 = load i64, ptr %.slot50, align 4
  %341 = add i64 0, %.state250
  %tile_snapshot.spill.load251 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 0
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 1
  %.splatinsert252 = insertelement <8 x i64> poison, i64 %341, i64 0
  %.splat253 = shufflevector <8 x i64> %.splatinsert252, <8 x i64> poison, <8 x i32> zeroinitializer
  %344 = mul <8 x i64> %.splat253, splat (i64 32)
  %345 = add <8 x i64> %343, %344
  %346 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %342, 0
  %347 = insertvalue { <8 x ptr>, <8 x i64> } %346, <8 x i64> %345, 1
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %347, 1
  %350 = extractelement <8 x ptr> %348, i32 0
  %351 = extractelement <8 x i64> %349, i32 0
  %352 = sub i64 %351, 0
  %353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %354 = select i1 %353, i64 %352, i64 0
  %private.contiguous.address254 = getelementptr i8, ptr %350, i64 %354
  %private.contiguous.load255 = load <8 x float>, ptr %private.contiguous.address254, align 4
  %355 = select <8 x i1> %71, <8 x float> %private.contiguous.load255, <8 x float> zeroinitializer
  %.state256 = load i64, ptr %.slot50, align 4
  %356 = add i64 160, %.state256
  %tile_snapshot.spill.load257 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 0
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 1
  %.splatinsert258 = insertelement <8 x i64> poison, i64 %356, i64 0
  %.splat259 = shufflevector <8 x i64> %.splatinsert258, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = mul <8 x i64> %.splat259, splat (i64 32)
  %360 = add <8 x i64> %358, %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = extractelement <8 x ptr> %363, i32 0
  %366 = extractelement <8 x i64> %364, i32 0
  %367 = sub i64 %366, 0
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %369 = select i1 %368, i64 %367, i64 0
  %private.contiguous.address260 = getelementptr i8, ptr %365, i64 %369
  %private.contiguous.load261 = load <8 x float>, ptr %private.contiguous.address260, align 4
  %370 = select <8 x i1> %71, <8 x float> %private.contiguous.load261, <8 x float> zeroinitializer
  %371 = fmul <8 x float> %355, %370
  %.state262 = load <8 x float>, ptr %.slot51, align 32
  %372 = fadd <8 x float> %.state262, %371
  %.state263 = load i64, ptr %.slot50, align 4
  %373 = add i64 %.state263, 1
  store i64 %373, ptr %.slot50, align 4
  %374 = load <8 x float>, ptr %.slot51, align 32
  %375 = select <8 x i1> %71, <8 x float> %372, <8 x float> %374
  store <8 x float> %375, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false249
  store i64 0, ptr %.slot52, align 4
  %376 = load <8 x float>, ptr %.slot53, align 32
  %377 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %376
  store <8 x float> %377, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state264 = load i64, ptr %.slot52, align 4
  %378 = icmp slt i64 %.state264, 80
  br i1 %378, label %direct.true265, label %direct.false266

direct.schedule.29:                               ; preds = %direct.true265
  %.state267 = load i64, ptr %.slot52, align 4
  %379 = add i64 0, %.state267
  %tile_snapshot.spill.load268 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load268, 0
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load268, 1
  %.splatinsert269 = insertelement <8 x i64> poison, i64 %379, i64 0
  %.splat270 = shufflevector <8 x i64> %.splatinsert269, <8 x i64> poison, <8 x i32> zeroinitializer
  %382 = mul <8 x i64> %.splat270, splat (i64 32)
  %383 = add <8 x i64> %381, %382
  %384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %380, 0
  %385 = insertvalue { <8 x ptr>, <8 x i64> } %384, <8 x i64> %383, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %385, 1
  %388 = extractelement <8 x ptr> %386, i32 0
  %389 = extractelement <8 x i64> %387, i32 0
  %390 = sub i64 %389, 0
  %391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %392 = select i1 %391, i64 %390, i64 0
  %private.contiguous.address271 = getelementptr i8, ptr %388, i64 %392
  %private.contiguous.load272 = load <8 x float>, ptr %private.contiguous.address271, align 4
  %393 = select <8 x i1> %71, <8 x float> %private.contiguous.load272, <8 x float> zeroinitializer
  %.state273 = load i64, ptr %.slot52, align 4
  %394 = add i64 240, %.state273
  %tile_snapshot.spill.load274 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 0
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 1
  %.splatinsert275 = insertelement <8 x i64> poison, i64 %394, i64 0
  %.splat276 = shufflevector <8 x i64> %.splatinsert275, <8 x i64> poison, <8 x i32> zeroinitializer
  %397 = mul <8 x i64> %.splat276, splat (i64 32)
  %398 = add <8 x i64> %396, %397
  %399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %395, 0
  %400 = insertvalue { <8 x ptr>, <8 x i64> } %399, <8 x i64> %398, 1
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %400, 1
  %403 = extractelement <8 x ptr> %401, i32 0
  %404 = extractelement <8 x i64> %402, i32 0
  %405 = sub i64 %404, 0
  %406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %407 = select i1 %406, i64 %405, i64 0
  %private.contiguous.address277 = getelementptr i8, ptr %403, i64 %407
  %private.contiguous.load278 = load <8 x float>, ptr %private.contiguous.address277, align 4
  %408 = select <8 x i1> %71, <8 x float> %private.contiguous.load278, <8 x float> zeroinitializer
  %409 = fmul <8 x float> %393, %408
  %.state279 = load <8 x float>, ptr %.slot53, align 32
  %410 = fadd <8 x float> %.state279, %409
  %.state280 = load i64, ptr %.slot52, align 4
  %411 = add i64 %.state280, 1
  store i64 %411, ptr %.slot52, align 4
  %412 = load <8 x float>, ptr %.slot53, align 32
  %413 = select <8 x i1> %71, <8 x float> %410, <8 x float> %412
  store <8 x float> %413, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false266
  store i64 0, ptr %.slot54, align 4
  %414 = load <8 x float>, ptr %.slot55, align 32
  %415 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %414
  store <8 x float> %415, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state281 = load i64, ptr %.slot54, align 4
  %416 = icmp slt i64 %.state281, 80
  br i1 %416, label %direct.true282, label %direct.false283

direct.schedule.32:                               ; preds = %direct.true282
  %.state284 = load i64, ptr %.slot54, align 4
  %417 = add i64 0, %.state284
  %tile_snapshot.spill.load285 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 0
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 1
  %.splatinsert286 = insertelement <8 x i64> poison, i64 %417, i64 0
  %.splat287 = shufflevector <8 x i64> %.splatinsert286, <8 x i64> poison, <8 x i32> zeroinitializer
  %420 = mul <8 x i64> %.splat287, splat (i64 32)
  %421 = add <8 x i64> %419, %420
  %422 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %418, 0
  %423 = insertvalue { <8 x ptr>, <8 x i64> } %422, <8 x i64> %421, 1
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %423, 1
  %426 = extractelement <8 x ptr> %424, i32 0
  %427 = extractelement <8 x i64> %425, i32 0
  %428 = sub i64 %427, 0
  %429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %430 = select i1 %429, i64 %428, i64 0
  %private.contiguous.address288 = getelementptr i8, ptr %426, i64 %430
  %private.contiguous.load289 = load <8 x float>, ptr %private.contiguous.address288, align 4
  %431 = select <8 x i1> %71, <8 x float> %private.contiguous.load289, <8 x float> zeroinitializer
  %.state290 = load i64, ptr %.slot54, align 4
  %432 = add i64 320, %.state290
  %tile_snapshot.spill.load291 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load291, 0
  %434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load291, 1
  %.splatinsert292 = insertelement <8 x i64> poison, i64 %432, i64 0
  %.splat293 = shufflevector <8 x i64> %.splatinsert292, <8 x i64> poison, <8 x i32> zeroinitializer
  %435 = mul <8 x i64> %.splat293, splat (i64 32)
  %436 = add <8 x i64> %434, %435
  %437 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %433, 0
  %438 = insertvalue { <8 x ptr>, <8 x i64> } %437, <8 x i64> %436, 1
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %438, 1
  %441 = extractelement <8 x ptr> %439, i32 0
  %442 = extractelement <8 x i64> %440, i32 0
  %443 = sub i64 %442, 0
  %444 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %445 = select i1 %444, i64 %443, i64 0
  %private.contiguous.address294 = getelementptr i8, ptr %441, i64 %445
  %private.contiguous.load295 = load <8 x float>, ptr %private.contiguous.address294, align 4
  %446 = select <8 x i1> %71, <8 x float> %private.contiguous.load295, <8 x float> zeroinitializer
  %447 = fmul <8 x float> %431, %446
  %.state296 = load <8 x float>, ptr %.slot55, align 32
  %448 = fadd <8 x float> %.state296, %447
  %.state297 = load i64, ptr %.slot54, align 4
  %449 = add i64 %.state297, 1
  store i64 %449, ptr %.slot54, align 4
  %450 = load <8 x float>, ptr %.slot55, align 32
  %451 = select <8 x i1> %71, <8 x float> %448, <8 x float> %450
  store <8 x float> %451, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false283
  store i64 0, ptr %.slot56, align 4
  %452 = load <8 x float>, ptr %.slot57, align 32
  %453 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %452
  store <8 x float> %453, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state298 = load i64, ptr %.slot56, align 4
  %454 = icmp slt i64 %.state298, 80
  br i1 %454, label %direct.true299, label %direct.false300

direct.schedule.35:                               ; preds = %direct.true299
  %.state301 = load i64, ptr %.slot56, align 4
  %455 = add i64 0, %.state301
  %tile_snapshot.spill.load302 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %456 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load302, 0
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load302, 1
  %.splatinsert303 = insertelement <8 x i64> poison, i64 %455, i64 0
  %.splat304 = shufflevector <8 x i64> %.splatinsert303, <8 x i64> poison, <8 x i32> zeroinitializer
  %458 = mul <8 x i64> %.splat304, splat (i64 32)
  %459 = add <8 x i64> %457, %458
  %460 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %456, 0
  %461 = insertvalue { <8 x ptr>, <8 x i64> } %460, <8 x i64> %459, 1
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %461, 1
  %464 = extractelement <8 x ptr> %462, i32 0
  %465 = extractelement <8 x i64> %463, i32 0
  %466 = sub i64 %465, 0
  %467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %468 = select i1 %467, i64 %466, i64 0
  %private.contiguous.address305 = getelementptr i8, ptr %464, i64 %468
  %private.contiguous.load306 = load <8 x float>, ptr %private.contiguous.address305, align 4
  %469 = select <8 x i1> %71, <8 x float> %private.contiguous.load306, <8 x float> zeroinitializer
  %.state307 = load i64, ptr %.slot56, align 4
  %470 = add i64 400, %.state307
  %tile_snapshot.spill.load308 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 0
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 1
  %.splatinsert309 = insertelement <8 x i64> poison, i64 %470, i64 0
  %.splat310 = shufflevector <8 x i64> %.splatinsert309, <8 x i64> poison, <8 x i32> zeroinitializer
  %473 = mul <8 x i64> %.splat310, splat (i64 32)
  %474 = add <8 x i64> %472, %473
  %475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %471, 0
  %476 = insertvalue { <8 x ptr>, <8 x i64> } %475, <8 x i64> %474, 1
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %476, 1
  %479 = extractelement <8 x ptr> %477, i32 0
  %480 = extractelement <8 x i64> %478, i32 0
  %481 = sub i64 %480, 0
  %482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %483 = select i1 %482, i64 %481, i64 0
  %private.contiguous.address311 = getelementptr i8, ptr %479, i64 %483
  %private.contiguous.load312 = load <8 x float>, ptr %private.contiguous.address311, align 4
  %484 = select <8 x i1> %71, <8 x float> %private.contiguous.load312, <8 x float> zeroinitializer
  %485 = fmul <8 x float> %469, %484
  %.state313 = load <8 x float>, ptr %.slot57, align 32
  %486 = fadd <8 x float> %.state313, %485
  %.state314 = load i64, ptr %.slot56, align 4
  %487 = add i64 %.state314, 1
  store i64 %487, ptr %.slot56, align 4
  %488 = load <8 x float>, ptr %.slot57, align 32
  %489 = select <8 x i1> %71, <8 x float> %486, <8 x float> %488
  store <8 x float> %489, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false300
  store i64 0, ptr %.slot58, align 4
  %490 = load <8 x float>, ptr %.slot59, align 32
  %491 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %490
  store <8 x float> %491, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state315 = load i64, ptr %.slot58, align 4
  %492 = icmp slt i64 %.state315, 80
  br i1 %492, label %direct.true316, label %direct.false317

direct.schedule.38:                               ; preds = %direct.true316
  %.state318 = load i64, ptr %.slot58, align 4
  %493 = add i64 0, %.state318
  %tile_snapshot.spill.load319 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load319, 0
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load319, 1
  %.splatinsert320 = insertelement <8 x i64> poison, i64 %493, i64 0
  %.splat321 = shufflevector <8 x i64> %.splatinsert320, <8 x i64> poison, <8 x i32> zeroinitializer
  %496 = mul <8 x i64> %.splat321, splat (i64 32)
  %497 = add <8 x i64> %495, %496
  %498 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %494, 0
  %499 = insertvalue { <8 x ptr>, <8 x i64> } %498, <8 x i64> %497, 1
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %499, 1
  %502 = extractelement <8 x ptr> %500, i32 0
  %503 = extractelement <8 x i64> %501, i32 0
  %504 = sub i64 %503, 0
  %505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %506 = select i1 %505, i64 %504, i64 0
  %private.contiguous.address322 = getelementptr i8, ptr %502, i64 %506
  %private.contiguous.load323 = load <8 x float>, ptr %private.contiguous.address322, align 4
  %507 = select <8 x i1> %71, <8 x float> %private.contiguous.load323, <8 x float> zeroinitializer
  %.state324 = load i64, ptr %.slot58, align 4
  %508 = add i64 480, %.state324
  %tile_snapshot.spill.load325 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load325, 0
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load325, 1
  %.splatinsert326 = insertelement <8 x i64> poison, i64 %508, i64 0
  %.splat327 = shufflevector <8 x i64> %.splatinsert326, <8 x i64> poison, <8 x i32> zeroinitializer
  %511 = mul <8 x i64> %.splat327, splat (i64 32)
  %512 = add <8 x i64> %510, %511
  %513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %509, 0
  %514 = insertvalue { <8 x ptr>, <8 x i64> } %513, <8 x i64> %512, 1
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %514, 1
  %517 = extractelement <8 x ptr> %515, i32 0
  %518 = extractelement <8 x i64> %516, i32 0
  %519 = sub i64 %518, 0
  %520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %521 = select i1 %520, i64 %519, i64 0
  %private.contiguous.address328 = getelementptr i8, ptr %517, i64 %521
  %private.contiguous.load329 = load <8 x float>, ptr %private.contiguous.address328, align 4
  %522 = select <8 x i1> %71, <8 x float> %private.contiguous.load329, <8 x float> zeroinitializer
  %523 = fmul <8 x float> %507, %522
  %.state330 = load <8 x float>, ptr %.slot59, align 32
  %524 = fadd <8 x float> %.state330, %523
  %.state331 = load i64, ptr %.slot58, align 4
  %525 = add i64 %.state331, 1
  store i64 %525, ptr %.slot58, align 4
  %526 = load <8 x float>, ptr %.slot59, align 32
  %527 = select <8 x i1> %71, <8 x float> %524, <8 x float> %526
  store <8 x float> %527, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false317
  store i64 0, ptr %.slot60, align 4
  %528 = load <8 x float>, ptr %.slot61, align 32
  %529 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %528
  store <8 x float> %529, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state332 = load i64, ptr %.slot60, align 4
  %530 = icmp slt i64 %.state332, 80
  br i1 %530, label %direct.true333, label %direct.false334

direct.schedule.41:                               ; preds = %direct.true333
  %.state335 = load i64, ptr %.slot60, align 4
  %531 = add i64 0, %.state335
  %tile_snapshot.spill.load336 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load336, 0
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load336, 1
  %.splatinsert337 = insertelement <8 x i64> poison, i64 %531, i64 0
  %.splat338 = shufflevector <8 x i64> %.splatinsert337, <8 x i64> poison, <8 x i32> zeroinitializer
  %534 = mul <8 x i64> %.splat338, splat (i64 32)
  %535 = add <8 x i64> %533, %534
  %536 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %532, 0
  %537 = insertvalue { <8 x ptr>, <8 x i64> } %536, <8 x i64> %535, 1
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %539 = extractvalue { <8 x ptr>, <8 x i64> } %537, 1
  %540 = extractelement <8 x ptr> %538, i32 0
  %541 = extractelement <8 x i64> %539, i32 0
  %542 = sub i64 %541, 0
  %543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %544 = select i1 %543, i64 %542, i64 0
  %private.contiguous.address339 = getelementptr i8, ptr %540, i64 %544
  %private.contiguous.load340 = load <8 x float>, ptr %private.contiguous.address339, align 4
  %545 = select <8 x i1> %71, <8 x float> %private.contiguous.load340, <8 x float> zeroinitializer
  %.state341 = load i64, ptr %.slot60, align 4
  %546 = add i64 560, %.state341
  %tile_snapshot.spill.load342 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load342, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load342, 1
  %.splatinsert343 = insertelement <8 x i64> poison, i64 %546, i64 0
  %.splat344 = shufflevector <8 x i64> %.splatinsert343, <8 x i64> poison, <8 x i32> zeroinitializer
  %549 = mul <8 x i64> %.splat344, splat (i64 32)
  %550 = add <8 x i64> %548, %549
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %547, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = extractelement <8 x ptr> %553, i32 0
  %556 = extractelement <8 x i64> %554, i32 0
  %557 = sub i64 %556, 0
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %559 = select i1 %558, i64 %557, i64 0
  %private.contiguous.address345 = getelementptr i8, ptr %555, i64 %559
  %private.contiguous.load346 = load <8 x float>, ptr %private.contiguous.address345, align 4
  %560 = select <8 x i1> %71, <8 x float> %private.contiguous.load346, <8 x float> zeroinitializer
  %561 = fmul <8 x float> %545, %560
  %.state347 = load <8 x float>, ptr %.slot61, align 32
  %562 = fadd <8 x float> %.state347, %561
  %.state348 = load i64, ptr %.slot60, align 4
  %563 = add i64 %.state348, 1
  store i64 %563, ptr %.slot60, align 4
  %564 = load <8 x float>, ptr %.slot61, align 32
  %565 = select <8 x i1> %71, <8 x float> %562, <8 x float> %564
  store <8 x float> %565, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false334
  store i64 0, ptr %.slot62, align 4
  %566 = load <8 x float>, ptr %.slot63, align 32
  %567 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %566
  store <8 x float> %567, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state349 = load i64, ptr %.slot62, align 4
  %568 = icmp slt i64 %.state349, 80
  br i1 %568, label %direct.true350, label %direct.false351

direct.schedule.44:                               ; preds = %direct.true350
  %.state352 = load i64, ptr %.slot62, align 4
  %569 = add i64 0, %.state352
  %tile_snapshot.spill.load353 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load353, 0
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load353, 1
  %.splatinsert354 = insertelement <8 x i64> poison, i64 %569, i64 0
  %.splat355 = shufflevector <8 x i64> %.splatinsert354, <8 x i64> poison, <8 x i32> zeroinitializer
  %572 = mul <8 x i64> %.splat355, splat (i64 32)
  %573 = add <8 x i64> %571, %572
  %574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %570, 0
  %575 = insertvalue { <8 x ptr>, <8 x i64> } %574, <8 x i64> %573, 1
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %575, 1
  %578 = extractelement <8 x ptr> %576, i32 0
  %579 = extractelement <8 x i64> %577, i32 0
  %580 = sub i64 %579, 0
  %581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %582 = select i1 %581, i64 %580, i64 0
  %private.contiguous.address356 = getelementptr i8, ptr %578, i64 %582
  %private.contiguous.load357 = load <8 x float>, ptr %private.contiguous.address356, align 4
  %583 = select <8 x i1> %71, <8 x float> %private.contiguous.load357, <8 x float> zeroinitializer
  %.state358 = load i64, ptr %.slot62, align 4
  %584 = add i64 640, %.state358
  %tile_snapshot.spill.load359 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load359, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load359, 1
  %.splatinsert360 = insertelement <8 x i64> poison, i64 %584, i64 0
  %.splat361 = shufflevector <8 x i64> %.splatinsert360, <8 x i64> poison, <8 x i32> zeroinitializer
  %587 = mul <8 x i64> %.splat361, splat (i64 32)
  %588 = add <8 x i64> %586, %587
  %589 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %585, 0
  %590 = insertvalue { <8 x ptr>, <8 x i64> } %589, <8 x i64> %588, 1
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %592 = extractvalue { <8 x ptr>, <8 x i64> } %590, 1
  %593 = extractelement <8 x ptr> %591, i32 0
  %594 = extractelement <8 x i64> %592, i32 0
  %595 = sub i64 %594, 0
  %596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %597 = select i1 %596, i64 %595, i64 0
  %private.contiguous.address362 = getelementptr i8, ptr %593, i64 %597
  %private.contiguous.load363 = load <8 x float>, ptr %private.contiguous.address362, align 4
  %598 = select <8 x i1> %71, <8 x float> %private.contiguous.load363, <8 x float> zeroinitializer
  %599 = fmul <8 x float> %583, %598
  %.state364 = load <8 x float>, ptr %.slot63, align 32
  %600 = fadd <8 x float> %.state364, %599
  %.state365 = load i64, ptr %.slot62, align 4
  %601 = add i64 %.state365, 1
  store i64 %601, ptr %.slot62, align 4
  %602 = load <8 x float>, ptr %.slot63, align 32
  %603 = select <8 x i1> %71, <8 x float> %600, <8 x float> %602
  store <8 x float> %603, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false351
  store i64 0, ptr %.slot64, align 4
  %604 = load <8 x float>, ptr %.slot65, align 32
  %605 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %604
  store <8 x float> %605, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state366 = load i64, ptr %.slot64, align 4
  %606 = icmp slt i64 %.state366, 80
  br i1 %606, label %direct.true367, label %direct.false368

direct.schedule.47:                               ; preds = %direct.true367
  %.state369 = load i64, ptr %.slot64, align 4
  %607 = add i64 0, %.state369
  %tile_snapshot.spill.load370 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load370, 0
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load370, 1
  %.splatinsert371 = insertelement <8 x i64> poison, i64 %607, i64 0
  %.splat372 = shufflevector <8 x i64> %.splatinsert371, <8 x i64> poison, <8 x i32> zeroinitializer
  %610 = mul <8 x i64> %.splat372, splat (i64 32)
  %611 = add <8 x i64> %609, %610
  %612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %608, 0
  %613 = insertvalue { <8 x ptr>, <8 x i64> } %612, <8 x i64> %611, 1
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %613, 1
  %616 = extractelement <8 x ptr> %614, i32 0
  %617 = extractelement <8 x i64> %615, i32 0
  %618 = sub i64 %617, 0
  %619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %620 = select i1 %619, i64 %618, i64 0
  %private.contiguous.address373 = getelementptr i8, ptr %616, i64 %620
  %private.contiguous.load374 = load <8 x float>, ptr %private.contiguous.address373, align 4
  %621 = select <8 x i1> %71, <8 x float> %private.contiguous.load374, <8 x float> zeroinitializer
  %.state375 = load i64, ptr %.slot64, align 4
  %622 = add i64 720, %.state375
  %tile_snapshot.spill.load376 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %623 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load376, 0
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load376, 1
  %.splatinsert377 = insertelement <8 x i64> poison, i64 %622, i64 0
  %.splat378 = shufflevector <8 x i64> %.splatinsert377, <8 x i64> poison, <8 x i32> zeroinitializer
  %625 = mul <8 x i64> %.splat378, splat (i64 32)
  %626 = add <8 x i64> %624, %625
  %627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %623, 0
  %628 = insertvalue { <8 x ptr>, <8 x i64> } %627, <8 x i64> %626, 1
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %628, 1
  %631 = extractelement <8 x ptr> %629, i32 0
  %632 = extractelement <8 x i64> %630, i32 0
  %633 = sub i64 %632, 0
  %634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %635 = select i1 %634, i64 %633, i64 0
  %private.contiguous.address379 = getelementptr i8, ptr %631, i64 %635
  %private.contiguous.load380 = load <8 x float>, ptr %private.contiguous.address379, align 4
  %636 = select <8 x i1> %71, <8 x float> %private.contiguous.load380, <8 x float> zeroinitializer
  %637 = fmul <8 x float> %621, %636
  %.state381 = load <8 x float>, ptr %.slot65, align 32
  %638 = fadd <8 x float> %.state381, %637
  %.state382 = load i64, ptr %.slot64, align 4
  %639 = add i64 %.state382, 1
  store i64 %639, ptr %.slot64, align 4
  %640 = load <8 x float>, ptr %.slot65, align 32
  %641 = select <8 x i1> %71, <8 x float> %638, <8 x float> %640
  store <8 x float> %641, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false368
  store i64 0, ptr %.slot66, align 4
  %642 = load <8 x float>, ptr %.slot67, align 32
  %643 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %642
  store <8 x float> %643, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state383 = load i64, ptr %.slot66, align 4
  %644 = icmp slt i64 %.state383, 80
  br i1 %644, label %direct.true384, label %direct.false385

direct.schedule.50:                               ; preds = %direct.true384
  %.state386 = load i64, ptr %.slot66, align 4
  %645 = add i64 0, %.state386
  %tile_snapshot.spill.load387 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load387, 0
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load387, 1
  %.splatinsert388 = insertelement <8 x i64> poison, i64 %645, i64 0
  %.splat389 = shufflevector <8 x i64> %.splatinsert388, <8 x i64> poison, <8 x i32> zeroinitializer
  %648 = mul <8 x i64> %.splat389, splat (i64 32)
  %649 = add <8 x i64> %647, %648
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %646, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = extractelement <8 x ptr> %652, i32 0
  %655 = extractelement <8 x i64> %653, i32 0
  %656 = sub i64 %655, 0
  %657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %658 = select i1 %657, i64 %656, i64 0
  %private.contiguous.address390 = getelementptr i8, ptr %654, i64 %658
  %private.contiguous.load391 = load <8 x float>, ptr %private.contiguous.address390, align 4
  %659 = select <8 x i1> %71, <8 x float> %private.contiguous.load391, <8 x float> zeroinitializer
  %.state392 = load i64, ptr %.slot66, align 4
  %660 = add i64 800, %.state392
  %tile_snapshot.spill.load393 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load393, 0
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load393, 1
  %.splatinsert394 = insertelement <8 x i64> poison, i64 %660, i64 0
  %.splat395 = shufflevector <8 x i64> %.splatinsert394, <8 x i64> poison, <8 x i32> zeroinitializer
  %663 = mul <8 x i64> %.splat395, splat (i64 32)
  %664 = add <8 x i64> %662, %663
  %665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %661, 0
  %666 = insertvalue { <8 x ptr>, <8 x i64> } %665, <8 x i64> %664, 1
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %666, 1
  %669 = extractelement <8 x ptr> %667, i32 0
  %670 = extractelement <8 x i64> %668, i32 0
  %671 = sub i64 %670, 0
  %672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %673 = select i1 %672, i64 %671, i64 0
  %private.contiguous.address396 = getelementptr i8, ptr %669, i64 %673
  %private.contiguous.load397 = load <8 x float>, ptr %private.contiguous.address396, align 4
  %674 = select <8 x i1> %71, <8 x float> %private.contiguous.load397, <8 x float> zeroinitializer
  %675 = fmul <8 x float> %659, %674
  %.state398 = load <8 x float>, ptr %.slot67, align 32
  %676 = fadd <8 x float> %.state398, %675
  %.state399 = load i64, ptr %.slot66, align 4
  %677 = add i64 %.state399, 1
  store i64 %677, ptr %.slot66, align 4
  %678 = load <8 x float>, ptr %.slot67, align 32
  %679 = select <8 x i1> %71, <8 x float> %676, <8 x float> %678
  store <8 x float> %679, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false385
  store i64 0, ptr %.slot68, align 4
  %680 = load <8 x float>, ptr %.slot69, align 32
  %681 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %680
  store <8 x float> %681, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state400 = load i64, ptr %.slot68, align 4
  %682 = icmp slt i64 %.state400, 80
  br i1 %682, label %direct.true401, label %direct.false402

direct.schedule.53:                               ; preds = %direct.true401
  %.state403 = load i64, ptr %.slot68, align 4
  %683 = add i64 0, %.state403
  %tile_snapshot.spill.load404 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load404, 0
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load404, 1
  %.splatinsert405 = insertelement <8 x i64> poison, i64 %683, i64 0
  %.splat406 = shufflevector <8 x i64> %.splatinsert405, <8 x i64> poison, <8 x i32> zeroinitializer
  %686 = mul <8 x i64> %.splat406, splat (i64 32)
  %687 = add <8 x i64> %685, %686
  %688 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %684, 0
  %689 = insertvalue { <8 x ptr>, <8 x i64> } %688, <8 x i64> %687, 1
  %690 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %689, 1
  %692 = extractelement <8 x ptr> %690, i32 0
  %693 = extractelement <8 x i64> %691, i32 0
  %694 = sub i64 %693, 0
  %695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %696 = select i1 %695, i64 %694, i64 0
  %private.contiguous.address407 = getelementptr i8, ptr %692, i64 %696
  %private.contiguous.load408 = load <8 x float>, ptr %private.contiguous.address407, align 4
  %697 = select <8 x i1> %71, <8 x float> %private.contiguous.load408, <8 x float> zeroinitializer
  %.state409 = load i64, ptr %.slot68, align 4
  %698 = add i64 880, %.state409
  %tile_snapshot.spill.load410 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %700 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %.splatinsert411 = insertelement <8 x i64> poison, i64 %698, i64 0
  %.splat412 = shufflevector <8 x i64> %.splatinsert411, <8 x i64> poison, <8 x i32> zeroinitializer
  %701 = mul <8 x i64> %.splat412, splat (i64 32)
  %702 = add <8 x i64> %700, %701
  %703 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %699, 0
  %704 = insertvalue { <8 x ptr>, <8 x i64> } %703, <8 x i64> %702, 1
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %706 = extractvalue { <8 x ptr>, <8 x i64> } %704, 1
  %707 = extractelement <8 x ptr> %705, i32 0
  %708 = extractelement <8 x i64> %706, i32 0
  %709 = sub i64 %708, 0
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %711 = select i1 %710, i64 %709, i64 0
  %private.contiguous.address413 = getelementptr i8, ptr %707, i64 %711
  %private.contiguous.load414 = load <8 x float>, ptr %private.contiguous.address413, align 4
  %712 = select <8 x i1> %71, <8 x float> %private.contiguous.load414, <8 x float> zeroinitializer
  %713 = fmul <8 x float> %697, %712
  %.state415 = load <8 x float>, ptr %.slot69, align 32
  %714 = fadd <8 x float> %.state415, %713
  %.state416 = load i64, ptr %.slot68, align 4
  %715 = add i64 %.state416, 1
  store i64 %715, ptr %.slot68, align 4
  %716 = load <8 x float>, ptr %.slot69, align 32
  %717 = select <8 x i1> %71, <8 x float> %714, <8 x float> %716
  store <8 x float> %717, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false402
  store i64 0, ptr %.slot70, align 4
  %718 = load <8 x float>, ptr %.slot71, align 32
  %719 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %718
  store <8 x float> %719, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state417 = load i64, ptr %.slot70, align 4
  %720 = icmp slt i64 %.state417, 80
  br i1 %720, label %direct.true418, label %direct.false419

direct.schedule.56:                               ; preds = %direct.true418
  %.state420 = load i64, ptr %.slot70, align 4
  %721 = add i64 0, %.state420
  %tile_snapshot.spill.load421 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load421, 0
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load421, 1
  %.splatinsert422 = insertelement <8 x i64> poison, i64 %721, i64 0
  %.splat423 = shufflevector <8 x i64> %.splatinsert422, <8 x i64> poison, <8 x i32> zeroinitializer
  %724 = mul <8 x i64> %.splat423, splat (i64 32)
  %725 = add <8 x i64> %723, %724
  %726 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %722, 0
  %727 = insertvalue { <8 x ptr>, <8 x i64> } %726, <8 x i64> %725, 1
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %727, 1
  %730 = extractelement <8 x ptr> %728, i32 0
  %731 = extractelement <8 x i64> %729, i32 0
  %732 = sub i64 %731, 0
  %733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %734 = select i1 %733, i64 %732, i64 0
  %private.contiguous.address424 = getelementptr i8, ptr %730, i64 %734
  %private.contiguous.load425 = load <8 x float>, ptr %private.contiguous.address424, align 4
  %735 = select <8 x i1> %71, <8 x float> %private.contiguous.load425, <8 x float> zeroinitializer
  %.state426 = load i64, ptr %.slot70, align 4
  %736 = add i64 960, %.state426
  %tile_snapshot.spill.load427 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load427, 0
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load427, 1
  %.splatinsert428 = insertelement <8 x i64> poison, i64 %736, i64 0
  %.splat429 = shufflevector <8 x i64> %.splatinsert428, <8 x i64> poison, <8 x i32> zeroinitializer
  %739 = mul <8 x i64> %.splat429, splat (i64 32)
  %740 = add <8 x i64> %738, %739
  %741 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %737, 0
  %742 = insertvalue { <8 x ptr>, <8 x i64> } %741, <8 x i64> %740, 1
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %742, 1
  %745 = extractelement <8 x ptr> %743, i32 0
  %746 = extractelement <8 x i64> %744, i32 0
  %747 = sub i64 %746, 0
  %748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %749 = select i1 %748, i64 %747, i64 0
  %private.contiguous.address430 = getelementptr i8, ptr %745, i64 %749
  %private.contiguous.load431 = load <8 x float>, ptr %private.contiguous.address430, align 4
  %750 = select <8 x i1> %71, <8 x float> %private.contiguous.load431, <8 x float> zeroinitializer
  %751 = fmul <8 x float> %735, %750
  %.state432 = load <8 x float>, ptr %.slot71, align 32
  %752 = fadd <8 x float> %.state432, %751
  %.state433 = load i64, ptr %.slot70, align 4
  %753 = add i64 %.state433, 1
  store i64 %753, ptr %.slot70, align 4
  %754 = load <8 x float>, ptr %.slot71, align 32
  %755 = select <8 x i1> %71, <8 x float> %752, <8 x float> %754
  store <8 x float> %755, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false419
  store i64 0, ptr %.slot72, align 4
  %756 = load <8 x float>, ptr %.slot73, align 32
  %757 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %756
  store <8 x float> %757, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state434 = load i64, ptr %.slot72, align 4
  %758 = icmp slt i64 %.state434, 80
  br i1 %758, label %direct.true435, label %direct.false436

direct.schedule.59:                               ; preds = %direct.true435
  %.state437 = load i64, ptr %.slot72, align 4
  %759 = add i64 0, %.state437
  %tile_snapshot.spill.load438 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load438, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load438, 1
  %.splatinsert439 = insertelement <8 x i64> poison, i64 %759, i64 0
  %.splat440 = shufflevector <8 x i64> %.splatinsert439, <8 x i64> poison, <8 x i32> zeroinitializer
  %762 = mul <8 x i64> %.splat440, splat (i64 32)
  %763 = add <8 x i64> %761, %762
  %764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %760, 0
  %765 = insertvalue { <8 x ptr>, <8 x i64> } %764, <8 x i64> %763, 1
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %765, 1
  %768 = extractelement <8 x ptr> %766, i32 0
  %769 = extractelement <8 x i64> %767, i32 0
  %770 = sub i64 %769, 0
  %771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %772 = select i1 %771, i64 %770, i64 0
  %private.contiguous.address441 = getelementptr i8, ptr %768, i64 %772
  %private.contiguous.load442 = load <8 x float>, ptr %private.contiguous.address441, align 4
  %773 = select <8 x i1> %71, <8 x float> %private.contiguous.load442, <8 x float> zeroinitializer
  %.state443 = load i64, ptr %.slot72, align 4
  %774 = add i64 1040, %.state443
  %tile_snapshot.spill.load444 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load444, 0
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load444, 1
  %.splatinsert445 = insertelement <8 x i64> poison, i64 %774, i64 0
  %.splat446 = shufflevector <8 x i64> %.splatinsert445, <8 x i64> poison, <8 x i32> zeroinitializer
  %777 = mul <8 x i64> %.splat446, splat (i64 32)
  %778 = add <8 x i64> %776, %777
  %779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %775, 0
  %780 = insertvalue { <8 x ptr>, <8 x i64> } %779, <8 x i64> %778, 1
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %780, 1
  %783 = extractelement <8 x ptr> %781, i32 0
  %784 = extractelement <8 x i64> %782, i32 0
  %785 = sub i64 %784, 0
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %787 = select i1 %786, i64 %785, i64 0
  %private.contiguous.address447 = getelementptr i8, ptr %783, i64 %787
  %private.contiguous.load448 = load <8 x float>, ptr %private.contiguous.address447, align 4
  %788 = select <8 x i1> %71, <8 x float> %private.contiguous.load448, <8 x float> zeroinitializer
  %789 = fmul <8 x float> %773, %788
  %.state449 = load <8 x float>, ptr %.slot73, align 32
  %790 = fadd <8 x float> %.state449, %789
  %.state450 = load i64, ptr %.slot72, align 4
  %791 = add i64 %.state450, 1
  store i64 %791, ptr %.slot72, align 4
  %792 = load <8 x float>, ptr %.slot73, align 32
  %793 = select <8 x i1> %71, <8 x float> %790, <8 x float> %792
  store <8 x float> %793, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false436
  store i64 0, ptr %.slot74, align 4
  %794 = load <8 x float>, ptr %.slot75, align 32
  %795 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %794
  store <8 x float> %795, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state451 = load i64, ptr %.slot74, align 4
  %796 = icmp slt i64 %.state451, 80
  br i1 %796, label %direct.true452, label %direct.false453

direct.schedule.62:                               ; preds = %direct.true452
  %.state454 = load i64, ptr %.slot74, align 4
  %797 = add i64 0, %.state454
  %tile_snapshot.spill.load455 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %.splatinsert456 = insertelement <8 x i64> poison, i64 %797, i64 0
  %.splat457 = shufflevector <8 x i64> %.splatinsert456, <8 x i64> poison, <8 x i32> zeroinitializer
  %800 = mul <8 x i64> %.splat457, splat (i64 32)
  %801 = add <8 x i64> %799, %800
  %802 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %798, 0
  %803 = insertvalue { <8 x ptr>, <8 x i64> } %802, <8 x i64> %801, 1
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %805 = extractvalue { <8 x ptr>, <8 x i64> } %803, 1
  %806 = extractelement <8 x ptr> %804, i32 0
  %807 = extractelement <8 x i64> %805, i32 0
  %808 = sub i64 %807, 0
  %809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %810 = select i1 %809, i64 %808, i64 0
  %private.contiguous.address458 = getelementptr i8, ptr %806, i64 %810
  %private.contiguous.load459 = load <8 x float>, ptr %private.contiguous.address458, align 4
  %811 = select <8 x i1> %71, <8 x float> %private.contiguous.load459, <8 x float> zeroinitializer
  %.state460 = load i64, ptr %.slot74, align 4
  %812 = add i64 1120, %.state460
  %tile_snapshot.spill.load461 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load461, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load461, 1
  %.splatinsert462 = insertelement <8 x i64> poison, i64 %812, i64 0
  %.splat463 = shufflevector <8 x i64> %.splatinsert462, <8 x i64> poison, <8 x i32> zeroinitializer
  %815 = mul <8 x i64> %.splat463, splat (i64 32)
  %816 = add <8 x i64> %814, %815
  %817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %813, 0
  %818 = insertvalue { <8 x ptr>, <8 x i64> } %817, <8 x i64> %816, 1
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %818, 1
  %821 = extractelement <8 x ptr> %819, i32 0
  %822 = extractelement <8 x i64> %820, i32 0
  %823 = sub i64 %822, 0
  %824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %825 = select i1 %824, i64 %823, i64 0
  %private.contiguous.address464 = getelementptr i8, ptr %821, i64 %825
  %private.contiguous.load465 = load <8 x float>, ptr %private.contiguous.address464, align 4
  %826 = select <8 x i1> %71, <8 x float> %private.contiguous.load465, <8 x float> zeroinitializer
  %827 = fmul <8 x float> %811, %826
  %.state466 = load <8 x float>, ptr %.slot75, align 32
  %828 = fadd <8 x float> %.state466, %827
  %.state467 = load i64, ptr %.slot74, align 4
  %829 = add i64 %.state467, 1
  store i64 %829, ptr %.slot74, align 4
  %830 = load <8 x float>, ptr %.slot75, align 32
  %831 = select <8 x i1> %71, <8 x float> %828, <8 x float> %830
  store <8 x float> %831, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false453
  store i64 0, ptr %.slot76, align 4
  %832 = load <8 x float>, ptr %.slot77, align 32
  %833 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %832
  store <8 x float> %833, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state468 = load i64, ptr %.slot76, align 4
  %834 = icmp slt i64 %.state468, 80
  br i1 %834, label %direct.true469, label %direct.false470

direct.schedule.65:                               ; preds = %direct.true469
  %.state471 = load i64, ptr %.slot76, align 4
  %835 = add i64 0, %.state471
  %tile_snapshot.spill.load472 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load472, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load472, 1
  %.splatinsert473 = insertelement <8 x i64> poison, i64 %835, i64 0
  %.splat474 = shufflevector <8 x i64> %.splatinsert473, <8 x i64> poison, <8 x i32> zeroinitializer
  %838 = mul <8 x i64> %.splat474, splat (i64 32)
  %839 = add <8 x i64> %837, %838
  %840 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %836, 0
  %841 = insertvalue { <8 x ptr>, <8 x i64> } %840, <8 x i64> %839, 1
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %841, 1
  %844 = extractelement <8 x ptr> %842, i32 0
  %845 = extractelement <8 x i64> %843, i32 0
  %846 = sub i64 %845, 0
  %847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %848 = select i1 %847, i64 %846, i64 0
  %private.contiguous.address475 = getelementptr i8, ptr %844, i64 %848
  %private.contiguous.load476 = load <8 x float>, ptr %private.contiguous.address475, align 4
  %849 = select <8 x i1> %71, <8 x float> %private.contiguous.load476, <8 x float> zeroinitializer
  %.state477 = load i64, ptr %.slot76, align 4
  %850 = add i64 1200, %.state477
  %tile_snapshot.spill.load478 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 0
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 1
  %.splatinsert479 = insertelement <8 x i64> poison, i64 %850, i64 0
  %.splat480 = shufflevector <8 x i64> %.splatinsert479, <8 x i64> poison, <8 x i32> zeroinitializer
  %853 = mul <8 x i64> %.splat480, splat (i64 32)
  %854 = add <8 x i64> %852, %853
  %855 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %851, 0
  %856 = insertvalue { <8 x ptr>, <8 x i64> } %855, <8 x i64> %854, 1
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %856, 1
  %859 = extractelement <8 x ptr> %857, i32 0
  %860 = extractelement <8 x i64> %858, i32 0
  %861 = sub i64 %860, 0
  %862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %863 = select i1 %862, i64 %861, i64 0
  %private.contiguous.address481 = getelementptr i8, ptr %859, i64 %863
  %private.contiguous.load482 = load <8 x float>, ptr %private.contiguous.address481, align 4
  %864 = select <8 x i1> %71, <8 x float> %private.contiguous.load482, <8 x float> zeroinitializer
  %865 = fmul <8 x float> %849, %864
  %.state483 = load <8 x float>, ptr %.slot77, align 32
  %866 = fadd <8 x float> %.state483, %865
  %.state484 = load i64, ptr %.slot76, align 4
  %867 = add i64 %.state484, 1
  store i64 %867, ptr %.slot76, align 4
  %868 = load <8 x float>, ptr %.slot77, align 32
  %869 = select <8 x i1> %71, <8 x float> %866, <8 x float> %868
  store <8 x float> %869, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false470
  %.state485 = load <8 x float>, ptr %.slot47, align 32
  %870 = fmul <8 x float> %.state485, splat (float 0x3FBC9F25C0000000)
  %.state486 = load <8 x float>, ptr %.slot49, align 32
  %871 = fmul <8 x float> %.state486, splat (float 0x3FBC9F25C0000000)
  %.state487 = load <8 x float>, ptr %.slot51, align 32
  %872 = fmul <8 x float> %.state487, splat (float 0x3FBC9F25C0000000)
  %.state488 = load <8 x float>, ptr %.slot53, align 32
  %873 = fmul <8 x float> %.state488, splat (float 0x3FBC9F25C0000000)
  %.state489 = load <8 x float>, ptr %.slot55, align 32
  %874 = fmul <8 x float> %.state489, splat (float 0x3FBC9F25C0000000)
  %.state490 = load <8 x float>, ptr %.slot57, align 32
  %875 = fmul <8 x float> %.state490, splat (float 0x3FBC9F25C0000000)
  %.state491 = load <8 x float>, ptr %.slot59, align 32
  %876 = fmul <8 x float> %.state491, splat (float 0x3FBC9F25C0000000)
  %.state492 = load <8 x float>, ptr %.slot61, align 32
  %877 = fmul <8 x float> %.state492, splat (float 0x3FBC9F25C0000000)
  %.state493 = load <8 x float>, ptr %.slot63, align 32
  %878 = fmul <8 x float> %.state493, splat (float 0x3FBC9F25C0000000)
  %.state494 = load <8 x float>, ptr %.slot65, align 32
  %879 = fmul <8 x float> %.state494, splat (float 0x3FBC9F25C0000000)
  %.state495 = load <8 x float>, ptr %.slot67, align 32
  %880 = fmul <8 x float> %.state495, splat (float 0x3FBC9F25C0000000)
  %.state496 = load <8 x float>, ptr %.slot69, align 32
  %881 = fmul <8 x float> %.state496, splat (float 0x3FBC9F25C0000000)
  %.state497 = load <8 x float>, ptr %.slot71, align 32
  %882 = fmul <8 x float> %.state497, splat (float 0x3FBC9F25C0000000)
  %.state498 = load <8 x float>, ptr %.slot73, align 32
  %883 = fmul <8 x float> %.state498, splat (float 0x3FBC9F25C0000000)
  %.state499 = load <8 x float>, ptr %.slot75, align 32
  %884 = fmul <8 x float> %.state499, splat (float 0x3FBC9F25C0000000)
  %.state500 = load <8 x float>, ptr %.slot77, align 32
  %885 = fmul <8 x float> %.state500, splat (float 0x3FBC9F25C0000000)
  %.spill.load501 = load i64, ptr %.spill37, align 4
  %886 = add i64 0, %.spill.load501
  %.spill.load502 = load i64, ptr %.spill37, align 4
  %887 = add i64 1, %.spill.load502
  %.spill.load503 = load i64, ptr %.spill37, align 4
  %888 = add i64 2, %.spill.load503
  %.spill.load504 = load i64, ptr %.spill37, align 4
  %889 = add i64 3, %.spill.load504
  %.spill.load505 = load i64, ptr %.spill37, align 4
  %890 = add i64 4, %.spill.load505
  %.spill.load506 = load i64, ptr %.spill37, align 4
  %891 = add i64 5, %.spill.load506
  %.spill.load507 = load i64, ptr %.spill37, align 4
  %892 = add i64 6, %.spill.load507
  %.spill.load508 = load i64, ptr %.spill37, align 4
  %893 = add i64 7, %.spill.load508
  %.spill.load509 = load i64, ptr %.spill37, align 4
  %894 = add i64 8, %.spill.load509
  %.spill.load510 = load i64, ptr %.spill37, align 4
  %895 = add i64 9, %.spill.load510
  %.spill.load511 = load i64, ptr %.spill37, align 4
  %896 = add i64 10, %.spill.load511
  %.spill.load512 = load i64, ptr %.spill37, align 4
  %897 = add i64 11, %.spill.load512
  %.spill.load513 = load i64, ptr %.spill37, align 4
  %898 = add i64 12, %.spill.load513
  %.spill.load514 = load i64, ptr %.spill37, align 4
  %899 = add i64 13, %.spill.load514
  %.spill.load515 = load i64, ptr %.spill37, align 4
  %900 = add i64 14, %.spill.load515
  %.spill.load516 = load i64, ptr %.spill37, align 4
  %901 = add i64 15, %.spill.load516
  %902 = icmp slt i64 %886, 2053
  %903 = icmp slt i64 %887, 2053
  %904 = icmp slt i64 %888, 2053
  %905 = icmp slt i64 %889, 2053
  %906 = icmp slt i64 %890, 2053
  %907 = icmp slt i64 %891, 2053
  %908 = icmp slt i64 %892, 2053
  %909 = icmp slt i64 %893, 2053
  %910 = icmp slt i64 %894, 2053
  %911 = icmp slt i64 %895, 2053
  %912 = icmp slt i64 %896, 2053
  %913 = icmp slt i64 %897, 2053
  %914 = icmp slt i64 %898, 2053
  %915 = icmp slt i64 %899, 2053
  %916 = icmp slt i64 %900, 2053
  %917 = icmp slt i64 %901, 2053
  %.spill.load517 = load i64, ptr %.spill29, align 4
  %918 = add i64 0, %.spill.load517
  store i64 %918, ptr %.spill78, align 4
  %919 = add i64 %918, 2053
  %920 = sub i64 %919, 1
  %921 = icmp sle i64 %886, %920
  %922 = icmp sle i64 %887, %920
  %923 = icmp sle i64 %888, %920
  %924 = icmp sle i64 %889, %920
  %925 = icmp sle i64 %890, %920
  %926 = icmp sle i64 %891, %920
  %927 = icmp sle i64 %892, %920
  %928 = icmp sle i64 %893, %920
  %929 = icmp sle i64 %894, %920
  %930 = icmp sle i64 %895, %920
  %931 = icmp sle i64 %896, %920
  %932 = icmp sle i64 %897, %920
  %933 = icmp sle i64 %898, %920
  %934 = icmp sle i64 %899, %920
  %935 = icmp sle i64 %900, %920
  %936 = icmp sle i64 %901, %920
  %937 = and i1 %902, %921
  store i1 %937, ptr %.spill79, align 1
  %938 = and i1 %903, %922
  store i1 %938, ptr %.spill80, align 1
  %939 = and i1 %904, %923
  store i1 %939, ptr %.spill81, align 1
  %940 = and i1 %905, %924
  store i1 %940, ptr %.spill82, align 1
  %941 = and i1 %906, %925
  store i1 %941, ptr %.spill83, align 1
  %942 = and i1 %907, %926
  store i1 %942, ptr %.spill84, align 1
  %943 = and i1 %908, %927
  store i1 %943, ptr %.spill85, align 1
  %944 = and i1 %909, %928
  store i1 %944, ptr %.spill86, align 1
  %945 = and i1 %910, %929
  store i1 %945, ptr %.spill87, align 1
  %946 = and i1 %911, %930
  store i1 %946, ptr %.spill88, align 1
  %947 = and i1 %912, %931
  store i1 %947, ptr %.spill89, align 1
  %948 = and i1 %913, %932
  store i1 %948, ptr %.spill90, align 1
  %949 = and i1 %914, %933
  store i1 %949, ptr %.spill91, align 1
  %950 = and i1 %915, %934
  store i1 %950, ptr %.spill92, align 1
  %951 = and i1 %916, %935
  store i1 %951, ptr %.spill93, align 1
  %952 = and i1 %917, %936
  store i1 %952, ptr %.spill94, align 1
  %.splatinsert518 = insertelement <8 x i1> poison, i1 %937, i64 0
  %.splat519 = shufflevector <8 x i1> %.splatinsert518, <8 x i1> poison, <8 x i32> zeroinitializer
  %953 = select <8 x i1> %.splat519, <8 x float> %870, <8 x float> splat (float 0xC6293E5940000000)
  %954 = load <8 x float>, ptr %.spill95, align 32
  %955 = select <8 x i1> %71, <8 x float> %953, <8 x float> %954
  store <8 x float> %955, ptr %.spill95, align 32
  %.splatinsert520 = insertelement <8 x i1> poison, i1 %938, i64 0
  %.splat521 = shufflevector <8 x i1> %.splatinsert520, <8 x i1> poison, <8 x i32> zeroinitializer
  %956 = select <8 x i1> %.splat521, <8 x float> %871, <8 x float> splat (float 0xC6293E5940000000)
  %957 = load <8 x float>, ptr %.spill96, align 32
  %958 = select <8 x i1> %71, <8 x float> %956, <8 x float> %957
  store <8 x float> %958, ptr %.spill96, align 32
  %.splatinsert522 = insertelement <8 x i1> poison, i1 %939, i64 0
  %.splat523 = shufflevector <8 x i1> %.splatinsert522, <8 x i1> poison, <8 x i32> zeroinitializer
  %959 = select <8 x i1> %.splat523, <8 x float> %872, <8 x float> splat (float 0xC6293E5940000000)
  %960 = load <8 x float>, ptr %.spill97, align 32
  %961 = select <8 x i1> %71, <8 x float> %959, <8 x float> %960
  store <8 x float> %961, ptr %.spill97, align 32
  %.splatinsert524 = insertelement <8 x i1> poison, i1 %940, i64 0
  %.splat525 = shufflevector <8 x i1> %.splatinsert524, <8 x i1> poison, <8 x i32> zeroinitializer
  %962 = select <8 x i1> %.splat525, <8 x float> %873, <8 x float> splat (float 0xC6293E5940000000)
  %963 = load <8 x float>, ptr %.spill98, align 32
  %964 = select <8 x i1> %71, <8 x float> %962, <8 x float> %963
  store <8 x float> %964, ptr %.spill98, align 32
  %.splatinsert526 = insertelement <8 x i1> poison, i1 %941, i64 0
  %.splat527 = shufflevector <8 x i1> %.splatinsert526, <8 x i1> poison, <8 x i32> zeroinitializer
  %965 = select <8 x i1> %.splat527, <8 x float> %874, <8 x float> splat (float 0xC6293E5940000000)
  %966 = load <8 x float>, ptr %.spill99, align 32
  %967 = select <8 x i1> %71, <8 x float> %965, <8 x float> %966
  store <8 x float> %967, ptr %.spill99, align 32
  %.splatinsert528 = insertelement <8 x i1> poison, i1 %942, i64 0
  %.splat529 = shufflevector <8 x i1> %.splatinsert528, <8 x i1> poison, <8 x i32> zeroinitializer
  %968 = select <8 x i1> %.splat529, <8 x float> %875, <8 x float> splat (float 0xC6293E5940000000)
  %969 = load <8 x float>, ptr %.spill100, align 32
  %970 = select <8 x i1> %71, <8 x float> %968, <8 x float> %969
  store <8 x float> %970, ptr %.spill100, align 32
  %.splatinsert530 = insertelement <8 x i1> poison, i1 %943, i64 0
  %.splat531 = shufflevector <8 x i1> %.splatinsert530, <8 x i1> poison, <8 x i32> zeroinitializer
  %971 = select <8 x i1> %.splat531, <8 x float> %876, <8 x float> splat (float 0xC6293E5940000000)
  %972 = load <8 x float>, ptr %.spill101, align 32
  %973 = select <8 x i1> %71, <8 x float> %971, <8 x float> %972
  store <8 x float> %973, ptr %.spill101, align 32
  %.splatinsert532 = insertelement <8 x i1> poison, i1 %944, i64 0
  %.splat533 = shufflevector <8 x i1> %.splatinsert532, <8 x i1> poison, <8 x i32> zeroinitializer
  %974 = select <8 x i1> %.splat533, <8 x float> %877, <8 x float> splat (float 0xC6293E5940000000)
  %975 = load <8 x float>, ptr %.spill102, align 32
  %976 = select <8 x i1> %71, <8 x float> %974, <8 x float> %975
  store <8 x float> %976, ptr %.spill102, align 32
  %.splatinsert534 = insertelement <8 x i1> poison, i1 %945, i64 0
  %.splat535 = shufflevector <8 x i1> %.splatinsert534, <8 x i1> poison, <8 x i32> zeroinitializer
  %977 = select <8 x i1> %.splat535, <8 x float> %878, <8 x float> splat (float 0xC6293E5940000000)
  %978 = load <8 x float>, ptr %.spill103, align 32
  %979 = select <8 x i1> %71, <8 x float> %977, <8 x float> %978
  store <8 x float> %979, ptr %.spill103, align 32
  %.splatinsert536 = insertelement <8 x i1> poison, i1 %946, i64 0
  %.splat537 = shufflevector <8 x i1> %.splatinsert536, <8 x i1> poison, <8 x i32> zeroinitializer
  %980 = select <8 x i1> %.splat537, <8 x float> %879, <8 x float> splat (float 0xC6293E5940000000)
  %981 = load <8 x float>, ptr %.spill104, align 32
  %982 = select <8 x i1> %71, <8 x float> %980, <8 x float> %981
  store <8 x float> %982, ptr %.spill104, align 32
  %.splatinsert538 = insertelement <8 x i1> poison, i1 %947, i64 0
  %.splat539 = shufflevector <8 x i1> %.splatinsert538, <8 x i1> poison, <8 x i32> zeroinitializer
  %983 = select <8 x i1> %.splat539, <8 x float> %880, <8 x float> splat (float 0xC6293E5940000000)
  %984 = load <8 x float>, ptr %.spill105, align 32
  %985 = select <8 x i1> %71, <8 x float> %983, <8 x float> %984
  store <8 x float> %985, ptr %.spill105, align 32
  %.splatinsert540 = insertelement <8 x i1> poison, i1 %948, i64 0
  %.splat541 = shufflevector <8 x i1> %.splatinsert540, <8 x i1> poison, <8 x i32> zeroinitializer
  %986 = select <8 x i1> %.splat541, <8 x float> %881, <8 x float> splat (float 0xC6293E5940000000)
  %987 = load <8 x float>, ptr %.spill106, align 32
  %988 = select <8 x i1> %71, <8 x float> %986, <8 x float> %987
  store <8 x float> %988, ptr %.spill106, align 32
  %.splatinsert542 = insertelement <8 x i1> poison, i1 %949, i64 0
  %.splat543 = shufflevector <8 x i1> %.splatinsert542, <8 x i1> poison, <8 x i32> zeroinitializer
  %989 = select <8 x i1> %.splat543, <8 x float> %882, <8 x float> splat (float 0xC6293E5940000000)
  %990 = load <8 x float>, ptr %.spill107, align 32
  %991 = select <8 x i1> %71, <8 x float> %989, <8 x float> %990
  store <8 x float> %991, ptr %.spill107, align 32
  %.splatinsert544 = insertelement <8 x i1> poison, i1 %950, i64 0
  %.splat545 = shufflevector <8 x i1> %.splatinsert544, <8 x i1> poison, <8 x i32> zeroinitializer
  %992 = select <8 x i1> %.splat545, <8 x float> %883, <8 x float> splat (float 0xC6293E5940000000)
  %993 = load <8 x float>, ptr %.spill108, align 32
  %994 = select <8 x i1> %71, <8 x float> %992, <8 x float> %993
  store <8 x float> %994, ptr %.spill108, align 32
  %.splatinsert546 = insertelement <8 x i1> poison, i1 %951, i64 0
  %.splat547 = shufflevector <8 x i1> %.splatinsert546, <8 x i1> poison, <8 x i32> zeroinitializer
  %995 = select <8 x i1> %.splat547, <8 x float> %884, <8 x float> splat (float 0xC6293E5940000000)
  %996 = load <8 x float>, ptr %.spill109, align 32
  %997 = select <8 x i1> %71, <8 x float> %995, <8 x float> %996
  store <8 x float> %997, ptr %.spill109, align 32
  %.splatinsert548 = insertelement <8 x i1> poison, i1 %952, i64 0
  %.splat549 = shufflevector <8 x i1> %.splatinsert548, <8 x i1> poison, <8 x i32> zeroinitializer
  %998 = select <8 x i1> %.splat549, <8 x float> %885, <8 x float> splat (float 0xC6293E5940000000)
  %999 = load <8 x float>, ptr %.spill110, align 32
  %1000 = select <8 x i1> %71, <8 x float> %998, <8 x float> %999
  store <8 x float> %1000, ptr %.spill110, align 32
  %1001 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 0
  %1004 = select <8 x i1> %71, <8 x ptr> %1002, <8 x ptr> %1003
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 1
  %1007 = select <8 x i1> %71, <8 x i64> %1005, <8 x i64> %1006
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1004, 0
  %1009 = insertvalue { <8 x ptr>, <8 x i64> } %1008, <8 x i64> %1007, 1
  store { <8 x ptr>, <8 x i64> } %1009, ptr %tile_snapshot.spill111, align 64
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1012 = add <8 x i64> %1011, zeroinitializer
  %1013 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1010, 0
  %1014 = insertvalue { <8 x ptr>, <8 x i64> } %1013, <8 x i64> %1012, 1
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %1014, 1
  %1017 = extractelement <8 x ptr> %1015, i32 0
  %1018 = extractelement <8 x i64> %1016, i32 0
  %1019 = sub i64 %1018, 0
  %1020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1021 = select i1 %1020, i64 %1019, i64 0
  %private.contiguous.address550 = getelementptr i8, ptr %1017, i64 %1021
  %private.contiguous.preserve551 = load <8 x float>, ptr %private.contiguous.address550, align 4
  %1022 = select <8 x i1> %71, <8 x float> %953, <8 x float> %private.contiguous.preserve551
  store <8 x float> %1022, ptr %private.contiguous.address550, align 4
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1025 = add <8 x i64> %1024, splat (i64 32)
  %1026 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1023, 0
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } %1026, <8 x i64> %1025, 1
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1027, 1
  %1030 = extractelement <8 x ptr> %1028, i32 0
  %1031 = extractelement <8 x i64> %1029, i32 0
  %1032 = sub i64 %1031, 0
  %1033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1034 = select i1 %1033, i64 %1032, i64 0
  %private.contiguous.address552 = getelementptr i8, ptr %1030, i64 %1034
  %private.contiguous.preserve553 = load <8 x float>, ptr %private.contiguous.address552, align 4
  %1035 = select <8 x i1> %71, <8 x float> %956, <8 x float> %private.contiguous.preserve553
  store <8 x float> %1035, ptr %private.contiguous.address552, align 4
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1038 = add <8 x i64> %1037, splat (i64 64)
  %1039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1036, 0
  %1040 = insertvalue { <8 x ptr>, <8 x i64> } %1039, <8 x i64> %1038, 1
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %1040, 1
  %1043 = extractelement <8 x ptr> %1041, i32 0
  %1044 = extractelement <8 x i64> %1042, i32 0
  %1045 = sub i64 %1044, 0
  %1046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1047 = select i1 %1046, i64 %1045, i64 0
  %private.contiguous.address554 = getelementptr i8, ptr %1043, i64 %1047
  %private.contiguous.preserve555 = load <8 x float>, ptr %private.contiguous.address554, align 4
  %1048 = select <8 x i1> %71, <8 x float> %959, <8 x float> %private.contiguous.preserve555
  store <8 x float> %1048, ptr %private.contiguous.address554, align 4
  %1049 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1051 = add <8 x i64> %1050, splat (i64 96)
  %1052 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1049, 0
  %1053 = insertvalue { <8 x ptr>, <8 x i64> } %1052, <8 x i64> %1051, 1
  %1054 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %1053, 1
  %1056 = extractelement <8 x ptr> %1054, i32 0
  %1057 = extractelement <8 x i64> %1055, i32 0
  %1058 = sub i64 %1057, 0
  %1059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1060 = select i1 %1059, i64 %1058, i64 0
  %private.contiguous.address556 = getelementptr i8, ptr %1056, i64 %1060
  %private.contiguous.preserve557 = load <8 x float>, ptr %private.contiguous.address556, align 4
  %1061 = select <8 x i1> %71, <8 x float> %962, <8 x float> %private.contiguous.preserve557
  store <8 x float> %1061, ptr %private.contiguous.address556, align 4
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1064 = add <8 x i64> %1063, splat (i64 128)
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1062, 0
  %1066 = insertvalue { <8 x ptr>, <8 x i64> } %1065, <8 x i64> %1064, 1
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %1066, 1
  %1069 = extractelement <8 x ptr> %1067, i32 0
  %1070 = extractelement <8 x i64> %1068, i32 0
  %1071 = sub i64 %1070, 0
  %1072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1073 = select i1 %1072, i64 %1071, i64 0
  %private.contiguous.address558 = getelementptr i8, ptr %1069, i64 %1073
  %private.contiguous.preserve559 = load <8 x float>, ptr %private.contiguous.address558, align 4
  %1074 = select <8 x i1> %71, <8 x float> %965, <8 x float> %private.contiguous.preserve559
  store <8 x float> %1074, ptr %private.contiguous.address558, align 4
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1077 = add <8 x i64> %1076, splat (i64 160)
  %1078 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1075, 0
  %1079 = insertvalue { <8 x ptr>, <8 x i64> } %1078, <8 x i64> %1077, 1
  %1080 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %1079, 1
  %1082 = extractelement <8 x ptr> %1080, i32 0
  %1083 = extractelement <8 x i64> %1081, i32 0
  %1084 = sub i64 %1083, 0
  %1085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1086 = select i1 %1085, i64 %1084, i64 0
  %private.contiguous.address560 = getelementptr i8, ptr %1082, i64 %1086
  %private.contiguous.preserve561 = load <8 x float>, ptr %private.contiguous.address560, align 4
  %1087 = select <8 x i1> %71, <8 x float> %968, <8 x float> %private.contiguous.preserve561
  store <8 x float> %1087, ptr %private.contiguous.address560, align 4
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1090 = add <8 x i64> %1089, splat (i64 192)
  %1091 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1088, 0
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } %1091, <8 x i64> %1090, 1
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %1092, 1
  %1095 = extractelement <8 x ptr> %1093, i32 0
  %1096 = extractelement <8 x i64> %1094, i32 0
  %1097 = sub i64 %1096, 0
  %1098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1099 = select i1 %1098, i64 %1097, i64 0
  %private.contiguous.address562 = getelementptr i8, ptr %1095, i64 %1099
  %private.contiguous.preserve563 = load <8 x float>, ptr %private.contiguous.address562, align 4
  %1100 = select <8 x i1> %71, <8 x float> %971, <8 x float> %private.contiguous.preserve563
  store <8 x float> %1100, ptr %private.contiguous.address562, align 4
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1103 = add <8 x i64> %1102, splat (i64 224)
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1101, 0
  %1105 = insertvalue { <8 x ptr>, <8 x i64> } %1104, <8 x i64> %1103, 1
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %1105, 1
  %1108 = extractelement <8 x ptr> %1106, i32 0
  %1109 = extractelement <8 x i64> %1107, i32 0
  %1110 = sub i64 %1109, 0
  %1111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1112 = select i1 %1111, i64 %1110, i64 0
  %private.contiguous.address564 = getelementptr i8, ptr %1108, i64 %1112
  %private.contiguous.preserve565 = load <8 x float>, ptr %private.contiguous.address564, align 4
  %1113 = select <8 x i1> %71, <8 x float> %974, <8 x float> %private.contiguous.preserve565
  store <8 x float> %1113, ptr %private.contiguous.address564, align 4
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1116 = add <8 x i64> %1115, splat (i64 256)
  %1117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1114, 0
  %1118 = insertvalue { <8 x ptr>, <8 x i64> } %1117, <8 x i64> %1116, 1
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 1
  %1121 = extractelement <8 x ptr> %1119, i32 0
  %1122 = extractelement <8 x i64> %1120, i32 0
  %1123 = sub i64 %1122, 0
  %1124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1125 = select i1 %1124, i64 %1123, i64 0
  %private.contiguous.address566 = getelementptr i8, ptr %1121, i64 %1125
  %private.contiguous.preserve567 = load <8 x float>, ptr %private.contiguous.address566, align 4
  %1126 = select <8 x i1> %71, <8 x float> %977, <8 x float> %private.contiguous.preserve567
  store <8 x float> %1126, ptr %private.contiguous.address566, align 4
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1129 = add <8 x i64> %1128, splat (i64 288)
  %1130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1127, 0
  %1131 = insertvalue { <8 x ptr>, <8 x i64> } %1130, <8 x i64> %1129, 1
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %1131, 1
  %1134 = extractelement <8 x ptr> %1132, i32 0
  %1135 = extractelement <8 x i64> %1133, i32 0
  %1136 = sub i64 %1135, 0
  %1137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1138 = select i1 %1137, i64 %1136, i64 0
  %private.contiguous.address568 = getelementptr i8, ptr %1134, i64 %1138
  %private.contiguous.preserve569 = load <8 x float>, ptr %private.contiguous.address568, align 4
  %1139 = select <8 x i1> %71, <8 x float> %980, <8 x float> %private.contiguous.preserve569
  store <8 x float> %1139, ptr %private.contiguous.address568, align 4
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1142 = add <8 x i64> %1141, splat (i64 320)
  %1143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1140, 0
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } %1143, <8 x i64> %1142, 1
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %1144, 1
  %1147 = extractelement <8 x ptr> %1145, i32 0
  %1148 = extractelement <8 x i64> %1146, i32 0
  %1149 = sub i64 %1148, 0
  %1150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1151 = select i1 %1150, i64 %1149, i64 0
  %private.contiguous.address570 = getelementptr i8, ptr %1147, i64 %1151
  %private.contiguous.preserve571 = load <8 x float>, ptr %private.contiguous.address570, align 4
  %1152 = select <8 x i1> %71, <8 x float> %983, <8 x float> %private.contiguous.preserve571
  store <8 x float> %1152, ptr %private.contiguous.address570, align 4
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1155 = add <8 x i64> %1154, splat (i64 352)
  %1156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1153, 0
  %1157 = insertvalue { <8 x ptr>, <8 x i64> } %1156, <8 x i64> %1155, 1
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %1157, 1
  %1160 = extractelement <8 x ptr> %1158, i32 0
  %1161 = extractelement <8 x i64> %1159, i32 0
  %1162 = sub i64 %1161, 0
  %1163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1164 = select i1 %1163, i64 %1162, i64 0
  %private.contiguous.address572 = getelementptr i8, ptr %1160, i64 %1164
  %private.contiguous.preserve573 = load <8 x float>, ptr %private.contiguous.address572, align 4
  %1165 = select <8 x i1> %71, <8 x float> %986, <8 x float> %private.contiguous.preserve573
  store <8 x float> %1165, ptr %private.contiguous.address572, align 4
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1168 = add <8 x i64> %1167, splat (i64 384)
  %1169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1166, 0
  %1170 = insertvalue { <8 x ptr>, <8 x i64> } %1169, <8 x i64> %1168, 1
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %1170, 1
  %1173 = extractelement <8 x ptr> %1171, i32 0
  %1174 = extractelement <8 x i64> %1172, i32 0
  %1175 = sub i64 %1174, 0
  %1176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1177 = select i1 %1176, i64 %1175, i64 0
  %private.contiguous.address574 = getelementptr i8, ptr %1173, i64 %1177
  %private.contiguous.preserve575 = load <8 x float>, ptr %private.contiguous.address574, align 4
  %1178 = select <8 x i1> %71, <8 x float> %989, <8 x float> %private.contiguous.preserve575
  store <8 x float> %1178, ptr %private.contiguous.address574, align 4
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1181 = add <8 x i64> %1180, splat (i64 416)
  %1182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1179, 0
  %1183 = insertvalue { <8 x ptr>, <8 x i64> } %1182, <8 x i64> %1181, 1
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %1183, 1
  %1186 = extractelement <8 x ptr> %1184, i32 0
  %1187 = extractelement <8 x i64> %1185, i32 0
  %1188 = sub i64 %1187, 0
  %1189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1190 = select i1 %1189, i64 %1188, i64 0
  %private.contiguous.address576 = getelementptr i8, ptr %1186, i64 %1190
  %private.contiguous.preserve577 = load <8 x float>, ptr %private.contiguous.address576, align 4
  %1191 = select <8 x i1> %71, <8 x float> %992, <8 x float> %private.contiguous.preserve577
  store <8 x float> %1191, ptr %private.contiguous.address576, align 4
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1193 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1194 = add <8 x i64> %1193, splat (i64 448)
  %1195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1192, 0
  %1196 = insertvalue { <8 x ptr>, <8 x i64> } %1195, <8 x i64> %1194, 1
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 1
  %1199 = extractelement <8 x ptr> %1197, i32 0
  %1200 = extractelement <8 x i64> %1198, i32 0
  %1201 = sub i64 %1200, 0
  %1202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1203 = select i1 %1202, i64 %1201, i64 0
  %private.contiguous.address578 = getelementptr i8, ptr %1199, i64 %1203
  %private.contiguous.preserve579 = load <8 x float>, ptr %private.contiguous.address578, align 4
  %1204 = select <8 x i1> %71, <8 x float> %995, <8 x float> %private.contiguous.preserve579
  store <8 x float> %1204, ptr %private.contiguous.address578, align 4
  %1205 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1207 = add <8 x i64> %1206, splat (i64 480)
  %1208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1205, 0
  %1209 = insertvalue { <8 x ptr>, <8 x i64> } %1208, <8 x i64> %1207, 1
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1211 = extractvalue { <8 x ptr>, <8 x i64> } %1209, 1
  %1212 = extractelement <8 x ptr> %1210, i32 0
  %1213 = extractelement <8 x i64> %1211, i32 0
  %1214 = sub i64 %1213, 0
  %1215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1216 = select i1 %1215, i64 %1214, i64 0
  %private.contiguous.address580 = getelementptr i8, ptr %1212, i64 %1216
  %private.contiguous.preserve581 = load <8 x float>, ptr %private.contiguous.address580, align 4
  %1217 = select <8 x i1> %71, <8 x float> %998, <8 x float> %private.contiguous.preserve581
  store <8 x float> %1217, ptr %private.contiguous.address580, align 4
  store i64 0, ptr %.slot112, align 4
  %1218 = load <8 x float>, ptr %.slot113, align 32
  %1219 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1218
  store <8 x float> %1219, ptr %.slot113, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state582 = load i64, ptr %.slot112, align 4
  %1220 = icmp slt i64 %.state582, 16
  br i1 %1220, label %direct.true583, label %direct.false584

direct.schedule.68:                               ; preds = %direct.true583
  %.state585 = load i64, ptr %.slot112, align 4
  %1221 = sdiv i64 %.state585, 1
  %.spill.load586 = load i64, ptr %.spill78, align 4
  %1222 = mul i64 %.spill.load586, 1
  %1223 = add i64 %1222, 0
  %1224 = mul i64 %1223, 1
  %1225 = add i64 %1224, 0
  %1226 = mul i64 %1225, 16
  %1227 = add i64 %1226, %1221
  %tile_snapshot.spill.load587 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load587, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load587, 1
  %.splatinsert588 = insertelement <8 x i64> poison, i64 %1227, i64 0
  %.splat589 = shufflevector <8 x i64> %.splatinsert588, <8 x i64> poison, <8 x i32> zeroinitializer
  %1230 = mul <8 x i64> %.splat589, splat (i64 32)
  %1231 = add <8 x i64> %1229, %1230
  %1232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1228, 0
  %1233 = insertvalue { <8 x ptr>, <8 x i64> } %1232, <8 x i64> %1231, 1
  %1234 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1235 = extractvalue { <8 x ptr>, <8 x i64> } %1233, 1
  %1236 = extractelement <8 x ptr> %1234, i32 0
  %1237 = extractelement <8 x i64> %1235, i32 0
  %1238 = sub i64 %1237, 0
  %1239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1240 = select i1 %1239, i64 %1238, i64 0
  %private.contiguous.address590 = getelementptr i8, ptr %1236, i64 %1240
  %private.contiguous.load591 = load <8 x float>, ptr %private.contiguous.address590, align 4
  %1241 = select <8 x i1> %71, <8 x float> %private.contiguous.load591, <8 x float> zeroinitializer
  %.state592 = load <8 x float>, ptr %.slot113, align 32
  %1242 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state592, <8 x float> %1241)
  %.state593 = load i64, ptr %.slot112, align 4
  %1243 = add i64 %.state593, 1
  store i64 %1243, ptr %.slot112, align 4
  %1244 = load <8 x float>, ptr %.slot113, align 32
  %1245 = select <8 x i1> %71, <8 x float> %1242, <8 x float> %1244
  store <8 x float> %1245, ptr %.slot113, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false584
  %.state594 = load <8 x float>, ptr %.slot35, align 32
  %.state595 = load <8 x float>, ptr %.slot113, align 32
  %1246 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state594, <8 x float> %.state595)
  %1247 = load <8 x float>, ptr %.spill114, align 32
  %1248 = select <8 x i1> %71, <8 x float> %1246, <8 x float> %1247
  store <8 x float> %1248, ptr %.spill114, align 32
  %.state596 = load <8 x float>, ptr %.slot35, align 32
  %1249 = fsub <8 x float> %.state596, %1246
  %1250 = select <8 x i1> %71, <8 x float> %1249, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1250)
  %1251 = load <8 x float>, ptr %.spill115, align 32
  %1252 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %1251
  store <8 x float> %1252, ptr %.spill115, align 32
  %.spill.load597 = load <8 x float>, ptr %.spill95, align 32
  %1253 = fsub <8 x float> %.spill.load597, %1246
  %.spill.load598 = load <8 x float>, ptr %.spill96, align 32
  %1254 = fsub <8 x float> %.spill.load598, %1246
  %.spill.load599 = load <8 x float>, ptr %.spill97, align 32
  %1255 = fsub <8 x float> %.spill.load599, %1246
  %.spill.load600 = load <8 x float>, ptr %.spill98, align 32
  %1256 = fsub <8 x float> %.spill.load600, %1246
  %.spill.load601 = load <8 x float>, ptr %.spill99, align 32
  %1257 = fsub <8 x float> %.spill.load601, %1246
  %.spill.load602 = load <8 x float>, ptr %.spill100, align 32
  %1258 = fsub <8 x float> %.spill.load602, %1246
  %.spill.load603 = load <8 x float>, ptr %.spill101, align 32
  %1259 = fsub <8 x float> %.spill.load603, %1246
  %.spill.load604 = load <8 x float>, ptr %.spill102, align 32
  %1260 = fsub <8 x float> %.spill.load604, %1246
  %.spill.load605 = load <8 x float>, ptr %.spill103, align 32
  %1261 = fsub <8 x float> %.spill.load605, %1246
  %.spill.load606 = load <8 x float>, ptr %.spill104, align 32
  %1262 = fsub <8 x float> %.spill.load606, %1246
  %.spill.load607 = load <8 x float>, ptr %.spill105, align 32
  %1263 = fsub <8 x float> %.spill.load607, %1246
  %.spill.load608 = load <8 x float>, ptr %.spill106, align 32
  %1264 = fsub <8 x float> %.spill.load608, %1246
  %.spill.load609 = load <8 x float>, ptr %.spill107, align 32
  %1265 = fsub <8 x float> %.spill.load609, %1246
  %.spill.load610 = load <8 x float>, ptr %.spill108, align 32
  %1266 = fsub <8 x float> %.spill.load610, %1246
  %.spill.load611 = load <8 x float>, ptr %.spill109, align 32
  %1267 = fsub <8 x float> %.spill.load611, %1246
  %.spill.load612 = load <8 x float>, ptr %.spill110, align 32
  %1268 = fsub <8 x float> %.spill.load612, %1246
  %1269 = select <8 x i1> %71, <8 x float> %1253, <8 x float> zeroinitializer
  %native.exp613 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1269)
  %1270 = select <8 x i1> %71, <8 x float> %1254, <8 x float> zeroinitializer
  %native.exp614 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1270)
  %1271 = select <8 x i1> %71, <8 x float> %1255, <8 x float> zeroinitializer
  %native.exp615 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1271)
  %1272 = select <8 x i1> %71, <8 x float> %1256, <8 x float> zeroinitializer
  %native.exp616 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1272)
  %1273 = select <8 x i1> %71, <8 x float> %1257, <8 x float> zeroinitializer
  %native.exp617 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1273)
  %1274 = select <8 x i1> %71, <8 x float> %1258, <8 x float> zeroinitializer
  %native.exp618 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1274)
  %1275 = select <8 x i1> %71, <8 x float> %1259, <8 x float> zeroinitializer
  %native.exp619 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1275)
  %1276 = select <8 x i1> %71, <8 x float> %1260, <8 x float> zeroinitializer
  %native.exp620 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1276)
  %1277 = select <8 x i1> %71, <8 x float> %1261, <8 x float> zeroinitializer
  %native.exp621 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1277)
  %1278 = select <8 x i1> %71, <8 x float> %1262, <8 x float> zeroinitializer
  %native.exp622 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1278)
  %1279 = select <8 x i1> %71, <8 x float> %1263, <8 x float> zeroinitializer
  %native.exp623 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1279)
  %1280 = select <8 x i1> %71, <8 x float> %1264, <8 x float> zeroinitializer
  %native.exp624 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1280)
  %1281 = select <8 x i1> %71, <8 x float> %1265, <8 x float> zeroinitializer
  %native.exp625 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1281)
  %1282 = select <8 x i1> %71, <8 x float> %1266, <8 x float> zeroinitializer
  %native.exp626 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1282)
  %1283 = select <8 x i1> %71, <8 x float> %1267, <8 x float> zeroinitializer
  %native.exp627 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1283)
  %1284 = select <8 x i1> %71, <8 x float> %1268, <8 x float> zeroinitializer
  %native.exp628 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1284)
  %.spill.load629 = load i1, ptr %.spill79, align 1
  %.splatinsert630 = insertelement <8 x i1> poison, i1 %.spill.load629, i64 0
  %.splat631 = shufflevector <8 x i1> %.splatinsert630, <8 x i1> poison, <8 x i32> zeroinitializer
  %1285 = select <8 x i1> %.splat631, <8 x float> %native.exp613, <8 x float> zeroinitializer
  %.spill.load632 = load i1, ptr %.spill80, align 1
  %.splatinsert633 = insertelement <8 x i1> poison, i1 %.spill.load632, i64 0
  %.splat634 = shufflevector <8 x i1> %.splatinsert633, <8 x i1> poison, <8 x i32> zeroinitializer
  %1286 = select <8 x i1> %.splat634, <8 x float> %native.exp614, <8 x float> zeroinitializer
  %.spill.load635 = load i1, ptr %.spill81, align 1
  %.splatinsert636 = insertelement <8 x i1> poison, i1 %.spill.load635, i64 0
  %.splat637 = shufflevector <8 x i1> %.splatinsert636, <8 x i1> poison, <8 x i32> zeroinitializer
  %1287 = select <8 x i1> %.splat637, <8 x float> %native.exp615, <8 x float> zeroinitializer
  %.spill.load638 = load i1, ptr %.spill82, align 1
  %.splatinsert639 = insertelement <8 x i1> poison, i1 %.spill.load638, i64 0
  %.splat640 = shufflevector <8 x i1> %.splatinsert639, <8 x i1> poison, <8 x i32> zeroinitializer
  %1288 = select <8 x i1> %.splat640, <8 x float> %native.exp616, <8 x float> zeroinitializer
  %.spill.load641 = load i1, ptr %.spill83, align 1
  %.splatinsert642 = insertelement <8 x i1> poison, i1 %.spill.load641, i64 0
  %.splat643 = shufflevector <8 x i1> %.splatinsert642, <8 x i1> poison, <8 x i32> zeroinitializer
  %1289 = select <8 x i1> %.splat643, <8 x float> %native.exp617, <8 x float> zeroinitializer
  %.spill.load644 = load i1, ptr %.spill84, align 1
  %.splatinsert645 = insertelement <8 x i1> poison, i1 %.spill.load644, i64 0
  %.splat646 = shufflevector <8 x i1> %.splatinsert645, <8 x i1> poison, <8 x i32> zeroinitializer
  %1290 = select <8 x i1> %.splat646, <8 x float> %native.exp618, <8 x float> zeroinitializer
  %.spill.load647 = load i1, ptr %.spill85, align 1
  %.splatinsert648 = insertelement <8 x i1> poison, i1 %.spill.load647, i64 0
  %.splat649 = shufflevector <8 x i1> %.splatinsert648, <8 x i1> poison, <8 x i32> zeroinitializer
  %1291 = select <8 x i1> %.splat649, <8 x float> %native.exp619, <8 x float> zeroinitializer
  %.spill.load650 = load i1, ptr %.spill86, align 1
  %.splatinsert651 = insertelement <8 x i1> poison, i1 %.spill.load650, i64 0
  %.splat652 = shufflevector <8 x i1> %.splatinsert651, <8 x i1> poison, <8 x i32> zeroinitializer
  %1292 = select <8 x i1> %.splat652, <8 x float> %native.exp620, <8 x float> zeroinitializer
  %.spill.load653 = load i1, ptr %.spill87, align 1
  %.splatinsert654 = insertelement <8 x i1> poison, i1 %.spill.load653, i64 0
  %.splat655 = shufflevector <8 x i1> %.splatinsert654, <8 x i1> poison, <8 x i32> zeroinitializer
  %1293 = select <8 x i1> %.splat655, <8 x float> %native.exp621, <8 x float> zeroinitializer
  %.spill.load656 = load i1, ptr %.spill88, align 1
  %.splatinsert657 = insertelement <8 x i1> poison, i1 %.spill.load656, i64 0
  %.splat658 = shufflevector <8 x i1> %.splatinsert657, <8 x i1> poison, <8 x i32> zeroinitializer
  %1294 = select <8 x i1> %.splat658, <8 x float> %native.exp622, <8 x float> zeroinitializer
  %.spill.load659 = load i1, ptr %.spill89, align 1
  %.splatinsert660 = insertelement <8 x i1> poison, i1 %.spill.load659, i64 0
  %.splat661 = shufflevector <8 x i1> %.splatinsert660, <8 x i1> poison, <8 x i32> zeroinitializer
  %1295 = select <8 x i1> %.splat661, <8 x float> %native.exp623, <8 x float> zeroinitializer
  %.spill.load662 = load i1, ptr %.spill90, align 1
  %.splatinsert663 = insertelement <8 x i1> poison, i1 %.spill.load662, i64 0
  %.splat664 = shufflevector <8 x i1> %.splatinsert663, <8 x i1> poison, <8 x i32> zeroinitializer
  %1296 = select <8 x i1> %.splat664, <8 x float> %native.exp624, <8 x float> zeroinitializer
  %.spill.load665 = load i1, ptr %.spill91, align 1
  %.splatinsert666 = insertelement <8 x i1> poison, i1 %.spill.load665, i64 0
  %.splat667 = shufflevector <8 x i1> %.splatinsert666, <8 x i1> poison, <8 x i32> zeroinitializer
  %1297 = select <8 x i1> %.splat667, <8 x float> %native.exp625, <8 x float> zeroinitializer
  %.spill.load668 = load i1, ptr %.spill92, align 1
  %.splatinsert669 = insertelement <8 x i1> poison, i1 %.spill.load668, i64 0
  %.splat670 = shufflevector <8 x i1> %.splatinsert669, <8 x i1> poison, <8 x i32> zeroinitializer
  %1298 = select <8 x i1> %.splat670, <8 x float> %native.exp626, <8 x float> zeroinitializer
  %.spill.load671 = load i1, ptr %.spill93, align 1
  %.splatinsert672 = insertelement <8 x i1> poison, i1 %.spill.load671, i64 0
  %.splat673 = shufflevector <8 x i1> %.splatinsert672, <8 x i1> poison, <8 x i32> zeroinitializer
  %1299 = select <8 x i1> %.splat673, <8 x float> %native.exp627, <8 x float> zeroinitializer
  %.spill.load674 = load i1, ptr %.spill94, align 1
  %.splatinsert675 = insertelement <8 x i1> poison, i1 %.spill.load674, i64 0
  %.splat676 = shufflevector <8 x i1> %.splatinsert675, <8 x i1> poison, <8 x i32> zeroinitializer
  %1300 = select <8 x i1> %.splat676, <8 x float> %native.exp628, <8 x float> zeroinitializer
  %1301 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1302 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1303 = extractvalue { <8 x ptr>, <8 x i64> } %1301, 0
  %1304 = select <8 x i1> %71, <8 x ptr> %1302, <8 x ptr> %1303
  %1305 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %1301, 1
  %1307 = select <8 x i1> %71, <8 x i64> %1305, <8 x i64> %1306
  %1308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1304, 0
  %1309 = insertvalue { <8 x ptr>, <8 x i64> } %1308, <8 x i64> %1307, 1
  store { <8 x ptr>, <8 x i64> } %1309, ptr %tile_snapshot.spill116, align 64
  %1310 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1312 = add <8 x i64> %1311, zeroinitializer
  %1313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1310, 0
  %1314 = insertvalue { <8 x ptr>, <8 x i64> } %1313, <8 x i64> %1312, 1
  %1315 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1316 = extractvalue { <8 x ptr>, <8 x i64> } %1314, 1
  %1317 = extractelement <8 x ptr> %1315, i32 0
  %1318 = extractelement <8 x i64> %1316, i32 0
  %1319 = sub i64 %1318, 0
  %1320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1321 = select i1 %1320, i64 %1319, i64 0
  %private.contiguous.address677 = getelementptr i8, ptr %1317, i64 %1321
  %private.contiguous.preserve678 = load <8 x float>, ptr %private.contiguous.address677, align 4
  %1322 = select <8 x i1> %71, <8 x float> %1285, <8 x float> %private.contiguous.preserve678
  store <8 x float> %1322, ptr %private.contiguous.address677, align 4
  %1323 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1324 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1325 = add <8 x i64> %1324, splat (i64 32)
  %1326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1323, 0
  %1327 = insertvalue { <8 x ptr>, <8 x i64> } %1326, <8 x i64> %1325, 1
  %1328 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1329 = extractvalue { <8 x ptr>, <8 x i64> } %1327, 1
  %1330 = extractelement <8 x ptr> %1328, i32 0
  %1331 = extractelement <8 x i64> %1329, i32 0
  %1332 = sub i64 %1331, 0
  %1333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1334 = select i1 %1333, i64 %1332, i64 0
  %private.contiguous.address679 = getelementptr i8, ptr %1330, i64 %1334
  %private.contiguous.preserve680 = load <8 x float>, ptr %private.contiguous.address679, align 4
  %1335 = select <8 x i1> %71, <8 x float> %1286, <8 x float> %private.contiguous.preserve680
  store <8 x float> %1335, ptr %private.contiguous.address679, align 4
  %1336 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1338 = add <8 x i64> %1337, splat (i64 64)
  %1339 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1336, 0
  %1340 = insertvalue { <8 x ptr>, <8 x i64> } %1339, <8 x i64> %1338, 1
  %1341 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1342 = extractvalue { <8 x ptr>, <8 x i64> } %1340, 1
  %1343 = extractelement <8 x ptr> %1341, i32 0
  %1344 = extractelement <8 x i64> %1342, i32 0
  %1345 = sub i64 %1344, 0
  %1346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1347 = select i1 %1346, i64 %1345, i64 0
  %private.contiguous.address681 = getelementptr i8, ptr %1343, i64 %1347
  %private.contiguous.preserve682 = load <8 x float>, ptr %private.contiguous.address681, align 4
  %1348 = select <8 x i1> %71, <8 x float> %1287, <8 x float> %private.contiguous.preserve682
  store <8 x float> %1348, ptr %private.contiguous.address681, align 4
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1351 = add <8 x i64> %1350, splat (i64 96)
  %1352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1349, 0
  %1353 = insertvalue { <8 x ptr>, <8 x i64> } %1352, <8 x i64> %1351, 1
  %1354 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %1353, 1
  %1356 = extractelement <8 x ptr> %1354, i32 0
  %1357 = extractelement <8 x i64> %1355, i32 0
  %1358 = sub i64 %1357, 0
  %1359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1360 = select i1 %1359, i64 %1358, i64 0
  %private.contiguous.address683 = getelementptr i8, ptr %1356, i64 %1360
  %private.contiguous.preserve684 = load <8 x float>, ptr %private.contiguous.address683, align 4
  %1361 = select <8 x i1> %71, <8 x float> %1288, <8 x float> %private.contiguous.preserve684
  store <8 x float> %1361, ptr %private.contiguous.address683, align 4
  %1362 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1364 = add <8 x i64> %1363, splat (i64 128)
  %1365 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1362, 0
  %1366 = insertvalue { <8 x ptr>, <8 x i64> } %1365, <8 x i64> %1364, 1
  %1367 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %1366, 1
  %1369 = extractelement <8 x ptr> %1367, i32 0
  %1370 = extractelement <8 x i64> %1368, i32 0
  %1371 = sub i64 %1370, 0
  %1372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1373 = select i1 %1372, i64 %1371, i64 0
  %private.contiguous.address685 = getelementptr i8, ptr %1369, i64 %1373
  %private.contiguous.preserve686 = load <8 x float>, ptr %private.contiguous.address685, align 4
  %1374 = select <8 x i1> %71, <8 x float> %1289, <8 x float> %private.contiguous.preserve686
  store <8 x float> %1374, ptr %private.contiguous.address685, align 4
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1376 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1377 = add <8 x i64> %1376, splat (i64 160)
  %1378 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1375, 0
  %1379 = insertvalue { <8 x ptr>, <8 x i64> } %1378, <8 x i64> %1377, 1
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %1379, 1
  %1382 = extractelement <8 x ptr> %1380, i32 0
  %1383 = extractelement <8 x i64> %1381, i32 0
  %1384 = sub i64 %1383, 0
  %1385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1386 = select i1 %1385, i64 %1384, i64 0
  %private.contiguous.address687 = getelementptr i8, ptr %1382, i64 %1386
  %private.contiguous.preserve688 = load <8 x float>, ptr %private.contiguous.address687, align 4
  %1387 = select <8 x i1> %71, <8 x float> %1290, <8 x float> %private.contiguous.preserve688
  store <8 x float> %1387, ptr %private.contiguous.address687, align 4
  %1388 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1389 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1390 = add <8 x i64> %1389, splat (i64 192)
  %1391 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1388, 0
  %1392 = insertvalue { <8 x ptr>, <8 x i64> } %1391, <8 x i64> %1390, 1
  %1393 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1394 = extractvalue { <8 x ptr>, <8 x i64> } %1392, 1
  %1395 = extractelement <8 x ptr> %1393, i32 0
  %1396 = extractelement <8 x i64> %1394, i32 0
  %1397 = sub i64 %1396, 0
  %1398 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1399 = select i1 %1398, i64 %1397, i64 0
  %private.contiguous.address689 = getelementptr i8, ptr %1395, i64 %1399
  %private.contiguous.preserve690 = load <8 x float>, ptr %private.contiguous.address689, align 4
  %1400 = select <8 x i1> %71, <8 x float> %1291, <8 x float> %private.contiguous.preserve690
  store <8 x float> %1400, ptr %private.contiguous.address689, align 4
  %1401 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1402 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1403 = add <8 x i64> %1402, splat (i64 224)
  %1404 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1401, 0
  %1405 = insertvalue { <8 x ptr>, <8 x i64> } %1404, <8 x i64> %1403, 1
  %1406 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %1405, 1
  %1408 = extractelement <8 x ptr> %1406, i32 0
  %1409 = extractelement <8 x i64> %1407, i32 0
  %1410 = sub i64 %1409, 0
  %1411 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1412 = select i1 %1411, i64 %1410, i64 0
  %private.contiguous.address691 = getelementptr i8, ptr %1408, i64 %1412
  %private.contiguous.preserve692 = load <8 x float>, ptr %private.contiguous.address691, align 4
  %1413 = select <8 x i1> %71, <8 x float> %1292, <8 x float> %private.contiguous.preserve692
  store <8 x float> %1413, ptr %private.contiguous.address691, align 4
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1416 = add <8 x i64> %1415, splat (i64 256)
  %1417 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1414, 0
  %1418 = insertvalue { <8 x ptr>, <8 x i64> } %1417, <8 x i64> %1416, 1
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %1418, 1
  %1421 = extractelement <8 x ptr> %1419, i32 0
  %1422 = extractelement <8 x i64> %1420, i32 0
  %1423 = sub i64 %1422, 0
  %1424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1425 = select i1 %1424, i64 %1423, i64 0
  %private.contiguous.address693 = getelementptr i8, ptr %1421, i64 %1425
  %private.contiguous.preserve694 = load <8 x float>, ptr %private.contiguous.address693, align 4
  %1426 = select <8 x i1> %71, <8 x float> %1293, <8 x float> %private.contiguous.preserve694
  store <8 x float> %1426, ptr %private.contiguous.address693, align 4
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1429 = add <8 x i64> %1428, splat (i64 288)
  %1430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1427, 0
  %1431 = insertvalue { <8 x ptr>, <8 x i64> } %1430, <8 x i64> %1429, 1
  %1432 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %1431, 1
  %1434 = extractelement <8 x ptr> %1432, i32 0
  %1435 = extractelement <8 x i64> %1433, i32 0
  %1436 = sub i64 %1435, 0
  %1437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1438 = select i1 %1437, i64 %1436, i64 0
  %private.contiguous.address695 = getelementptr i8, ptr %1434, i64 %1438
  %private.contiguous.preserve696 = load <8 x float>, ptr %private.contiguous.address695, align 4
  %1439 = select <8 x i1> %71, <8 x float> %1294, <8 x float> %private.contiguous.preserve696
  store <8 x float> %1439, ptr %private.contiguous.address695, align 4
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1442 = add <8 x i64> %1441, splat (i64 320)
  %1443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1440, 0
  %1444 = insertvalue { <8 x ptr>, <8 x i64> } %1443, <8 x i64> %1442, 1
  %1445 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1446 = extractvalue { <8 x ptr>, <8 x i64> } %1444, 1
  %1447 = extractelement <8 x ptr> %1445, i32 0
  %1448 = extractelement <8 x i64> %1446, i32 0
  %1449 = sub i64 %1448, 0
  %1450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1451 = select i1 %1450, i64 %1449, i64 0
  %private.contiguous.address697 = getelementptr i8, ptr %1447, i64 %1451
  %private.contiguous.preserve698 = load <8 x float>, ptr %private.contiguous.address697, align 4
  %1452 = select <8 x i1> %71, <8 x float> %1295, <8 x float> %private.contiguous.preserve698
  store <8 x float> %1452, ptr %private.contiguous.address697, align 4
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1455 = add <8 x i64> %1454, splat (i64 352)
  %1456 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1453, 0
  %1457 = insertvalue { <8 x ptr>, <8 x i64> } %1456, <8 x i64> %1455, 1
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %1457, 1
  %1460 = extractelement <8 x ptr> %1458, i32 0
  %1461 = extractelement <8 x i64> %1459, i32 0
  %1462 = sub i64 %1461, 0
  %1463 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1464 = select i1 %1463, i64 %1462, i64 0
  %private.contiguous.address699 = getelementptr i8, ptr %1460, i64 %1464
  %private.contiguous.preserve700 = load <8 x float>, ptr %private.contiguous.address699, align 4
  %1465 = select <8 x i1> %71, <8 x float> %1296, <8 x float> %private.contiguous.preserve700
  store <8 x float> %1465, ptr %private.contiguous.address699, align 4
  %1466 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1467 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1468 = add <8 x i64> %1467, splat (i64 384)
  %1469 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1466, 0
  %1470 = insertvalue { <8 x ptr>, <8 x i64> } %1469, <8 x i64> %1468, 1
  %1471 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %1470, 1
  %1473 = extractelement <8 x ptr> %1471, i32 0
  %1474 = extractelement <8 x i64> %1472, i32 0
  %1475 = sub i64 %1474, 0
  %1476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1477 = select i1 %1476, i64 %1475, i64 0
  %private.contiguous.address701 = getelementptr i8, ptr %1473, i64 %1477
  %private.contiguous.preserve702 = load <8 x float>, ptr %private.contiguous.address701, align 4
  %1478 = select <8 x i1> %71, <8 x float> %1297, <8 x float> %private.contiguous.preserve702
  store <8 x float> %1478, ptr %private.contiguous.address701, align 4
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1480 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1481 = add <8 x i64> %1480, splat (i64 416)
  %1482 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1479, 0
  %1483 = insertvalue { <8 x ptr>, <8 x i64> } %1482, <8 x i64> %1481, 1
  %1484 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %1483, 1
  %1486 = extractelement <8 x ptr> %1484, i32 0
  %1487 = extractelement <8 x i64> %1485, i32 0
  %1488 = sub i64 %1487, 0
  %1489 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1490 = select i1 %1489, i64 %1488, i64 0
  %private.contiguous.address703 = getelementptr i8, ptr %1486, i64 %1490
  %private.contiguous.preserve704 = load <8 x float>, ptr %private.contiguous.address703, align 4
  %1491 = select <8 x i1> %71, <8 x float> %1298, <8 x float> %private.contiguous.preserve704
  store <8 x float> %1491, ptr %private.contiguous.address703, align 4
  %1492 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1493 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1494 = add <8 x i64> %1493, splat (i64 448)
  %1495 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1492, 0
  %1496 = insertvalue { <8 x ptr>, <8 x i64> } %1495, <8 x i64> %1494, 1
  %1497 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1498 = extractvalue { <8 x ptr>, <8 x i64> } %1496, 1
  %1499 = extractelement <8 x ptr> %1497, i32 0
  %1500 = extractelement <8 x i64> %1498, i32 0
  %1501 = sub i64 %1500, 0
  %1502 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1503 = select i1 %1502, i64 %1501, i64 0
  %private.contiguous.address705 = getelementptr i8, ptr %1499, i64 %1503
  %private.contiguous.preserve706 = load <8 x float>, ptr %private.contiguous.address705, align 4
  %1504 = select <8 x i1> %71, <8 x float> %1299, <8 x float> %private.contiguous.preserve706
  store <8 x float> %1504, ptr %private.contiguous.address705, align 4
  %1505 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1506 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1507 = add <8 x i64> %1506, splat (i64 480)
  %1508 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1505, 0
  %1509 = insertvalue { <8 x ptr>, <8 x i64> } %1508, <8 x i64> %1507, 1
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %1509, 1
  %1512 = extractelement <8 x ptr> %1510, i32 0
  %1513 = extractelement <8 x i64> %1511, i32 0
  %1514 = sub i64 %1513, 0
  %1515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1516 = select i1 %1515, i64 %1514, i64 0
  %private.contiguous.address707 = getelementptr i8, ptr %1512, i64 %1516
  %private.contiguous.preserve708 = load <8 x float>, ptr %private.contiguous.address707, align 4
  %1517 = select <8 x i1> %71, <8 x float> %1300, <8 x float> %private.contiguous.preserve708
  store <8 x float> %1517, ptr %private.contiguous.address707, align 4
  %.state709 = load <8 x float>, ptr %.slot36, align 32
  %1518 = fmul <8 x float> %.state709, %native.exp
  %1519 = load <8 x float>, ptr %.spill117, align 32
  %1520 = select <8 x i1> %71, <8 x float> %1518, <8 x float> %1519
  store <8 x float> %1520, ptr %.spill117, align 32
  store i64 0, ptr %.slot118, align 4
  %1521 = load <8 x float>, ptr %.slot119, align 32
  %1522 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1521
  store <8 x float> %1522, ptr %.slot119, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state710 = load i64, ptr %.slot118, align 4
  %1523 = icmp slt i64 %.state710, 16
  br i1 %1523, label %direct.true711, label %direct.false712

direct.schedule.71:                               ; preds = %direct.true711
  %.state713 = load i64, ptr %.slot118, align 4
  %1524 = sdiv i64 %.state713, 1
  %.spill.load714 = load i64, ptr %.spill78, align 4
  %1525 = mul i64 %.spill.load714, 1
  %1526 = add i64 %1525, 0
  %1527 = mul i64 %1526, 1
  %1528 = add i64 %1527, 0
  %1529 = mul i64 %1528, 16
  %1530 = add i64 %1529, %1524
  %tile_snapshot.spill.load715 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load715, 0
  %1532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load715, 1
  %.splatinsert716 = insertelement <8 x i64> poison, i64 %1530, i64 0
  %.splat717 = shufflevector <8 x i64> %.splatinsert716, <8 x i64> poison, <8 x i32> zeroinitializer
  %1533 = mul <8 x i64> %.splat717, splat (i64 32)
  %1534 = add <8 x i64> %1532, %1533
  %1535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1531, 0
  %1536 = insertvalue { <8 x ptr>, <8 x i64> } %1535, <8 x i64> %1534, 1
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %1536, 1
  %1539 = extractelement <8 x ptr> %1537, i32 0
  %1540 = extractelement <8 x i64> %1538, i32 0
  %1541 = sub i64 %1540, 0
  %1542 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1543 = select i1 %1542, i64 %1541, i64 0
  %private.contiguous.address718 = getelementptr i8, ptr %1539, i64 %1543
  %private.contiguous.load719 = load <8 x float>, ptr %private.contiguous.address718, align 4
  %1544 = select <8 x i1> %71, <8 x float> %private.contiguous.load719, <8 x float> zeroinitializer
  %.state720 = load <8 x float>, ptr %.slot119, align 32
  %1545 = fadd <8 x float> %.state720, %1544
  %.state721 = load i64, ptr %.slot118, align 4
  %1546 = add i64 %.state721, 1
  store i64 %1546, ptr %.slot118, align 4
  %1547 = load <8 x float>, ptr %.slot119, align 32
  %1548 = select <8 x i1> %71, <8 x float> %1545, <8 x float> %1547
  store <8 x float> %1548, ptr %.slot119, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false712
  %.spill.load722 = load <8 x float>, ptr %.spill117, align 32
  %.state723 = load <8 x float>, ptr %.slot119, align 32
  %1549 = fadd <8 x float> %.spill.load722, %.state723
  %1550 = load <8 x float>, ptr %.spill120, align 32
  %1551 = select <8 x i1> %71, <8 x float> %1549, <8 x float> %1550
  store <8 x float> %1551, ptr %.spill120, align 32
  %1552 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1553 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %1552, 0
  %1555 = select <8 x i1> %71, <8 x ptr> %1553, <8 x ptr> %1554
  %1556 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1557 = extractvalue { <8 x ptr>, <8 x i64> } %1552, 1
  %1558 = select <8 x i1> %71, <8 x i64> %1556, <8 x i64> %1557
  %1559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1555, 0
  %1560 = insertvalue { <8 x ptr>, <8 x i64> } %1559, <8 x i64> %1558, 1
  store { <8 x ptr>, <8 x i64> } %1560, ptr %tile_snapshot.spill121, align 64
  store i64 0, ptr %.slot122, align 4
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.77, %direct.schedule.72
  %.state724 = load i64, ptr %.slot122, align 4
  %1561 = icmp slt i64 %.state724, 96
  br i1 %1561, label %direct.true725, label %direct.false726

direct.schedule.74:                               ; preds = %direct.true725
  %.state727 = load i64, ptr %.slot122, align 4
  %1562 = add i64 0, %.state727
  %tile_snapshot.spill.load728 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 0
  %1564 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 1
  %.splatinsert729 = insertelement <8 x i64> poison, i64 %1562, i64 0
  %.splat730 = shufflevector <8 x i64> %.splatinsert729, <8 x i64> poison, <8 x i32> zeroinitializer
  %1565 = mul <8 x i64> %.splat730, splat (i64 32)
  %1566 = add <8 x i64> %1564, %1565
  %1567 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1563, 0
  %1568 = insertvalue { <8 x ptr>, <8 x i64> } %1567, <8 x i64> %1566, 1
  %1569 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1570 = extractvalue { <8 x ptr>, <8 x i64> } %1568, 1
  %1571 = extractelement <8 x ptr> %1569, i32 0
  %1572 = extractelement <8 x i64> %1570, i32 0
  %1573 = sub i64 %1572, 0
  %1574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1575 = select i1 %1574, i64 %1573, i64 0
  %private.contiguous.address731 = getelementptr i8, ptr %1571, i64 %1575
  %private.contiguous.load732 = load <8 x float>, ptr %private.contiguous.address731, align 4
  %1576 = select <8 x i1> %71, <8 x float> %private.contiguous.load732, <8 x float> zeroinitializer
  %.spill.load733 = load <8 x float>, ptr %.spill115, align 32
  %1577 = fmul <8 x float> %1576, %.spill.load733
  store i64 0, ptr %.slot123, align 4
  %1578 = load <8 x float>, ptr %.slot124, align 32
  %1579 = select <8 x i1> %71, <8 x float> %1577, <8 x float> %1578
  store <8 x float> %1579, ptr %.slot124, align 32
  br label %direct.schedule.75

direct.schedule.75:                               ; preds = %direct.schedule.76, %direct.schedule.74
  %.state734 = load i64, ptr %.slot123, align 4
  %1580 = icmp slt i64 %.state734, 16
  br i1 %1580, label %direct.true735, label %direct.false736

direct.schedule.76:                               ; preds = %direct.true735
  %.state737 = load i64, ptr %.slot123, align 4
  %1581 = add i64 0, %.state737
  %tile_snapshot.spill.load738 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load738, 0
  %1583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load738, 1
  %.splatinsert739 = insertelement <8 x i64> poison, i64 %1581, i64 0
  %.splat740 = shufflevector <8 x i64> %.splatinsert739, <8 x i64> poison, <8 x i32> zeroinitializer
  %1584 = mul <8 x i64> %.splat740, splat (i64 32)
  %1585 = add <8 x i64> %1583, %1584
  %1586 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1582, 0
  %1587 = insertvalue { <8 x ptr>, <8 x i64> } %1586, <8 x i64> %1585, 1
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %1587, 1
  %1590 = extractelement <8 x ptr> %1588, i32 0
  %1591 = extractelement <8 x i64> %1589, i32 0
  %1592 = sub i64 %1591, 0
  %1593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1594 = select i1 %1593, i64 %1592, i64 0
  %private.contiguous.address741 = getelementptr i8, ptr %1590, i64 %1594
  %private.contiguous.load742 = load <8 x float>, ptr %private.contiguous.address741, align 4
  %1595 = select <8 x i1> %71, <8 x float> %private.contiguous.load742, <8 x float> zeroinitializer
  %1596 = mul i64 %1581, 96
  %.state743 = load i64, ptr %.slot122, align 4
  %1597 = add i64 %1596, %.state743
  %tile_snapshot.spill.load744 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load744, 0
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load744, 1
  %.splatinsert745 = insertelement <8 x i64> poison, i64 %1597, i64 0
  %.splat746 = shufflevector <8 x i64> %.splatinsert745, <8 x i64> poison, <8 x i32> zeroinitializer
  %1600 = mul <8 x i64> %.splat746, splat (i64 32)
  %1601 = add <8 x i64> %1599, %1600
  %1602 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1598, 0
  %1603 = insertvalue { <8 x ptr>, <8 x i64> } %1602, <8 x i64> %1601, 1
  %1604 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %1603, 1
  %1606 = extractelement <8 x ptr> %1604, i32 0
  %1607 = extractelement <8 x i64> %1605, i32 0
  %1608 = sub i64 %1607, 0
  %1609 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1610 = select i1 %1609, i64 %1608, i64 0
  %private.contiguous.address747 = getelementptr i8, ptr %1606, i64 %1610
  %private.contiguous.load748 = load <8 x float>, ptr %private.contiguous.address747, align 4
  %1611 = select <8 x i1> %71, <8 x float> %private.contiguous.load748, <8 x float> zeroinitializer
  %1612 = fmul <8 x float> %1595, %1611
  %.state749 = load <8 x float>, ptr %.slot124, align 32
  %1613 = fadd <8 x float> %.state749, %1612
  %.state750 = load i64, ptr %.slot123, align 4
  %1614 = add i64 %.state750, 1
  store i64 %1614, ptr %.slot123, align 4
  %1615 = load <8 x float>, ptr %.slot124, align 32
  %1616 = select <8 x i1> %71, <8 x float> %1613, <8 x float> %1615
  store <8 x float> %1616, ptr %.slot124, align 32
  br label %direct.schedule.75

direct.schedule.77:                               ; preds = %direct.false736
  %tile_snapshot.spill.load751 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1617 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load751, 0
  %1618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load751, 1
  %.state752 = load i64, ptr %.slot122, align 4
  %.splatinsert753 = insertelement <8 x i64> poison, i64 %.state752, i64 0
  %.splat754 = shufflevector <8 x i64> %.splatinsert753, <8 x i64> poison, <8 x i32> zeroinitializer
  %1619 = mul <8 x i64> %.splat754, splat (i64 32)
  %1620 = add <8 x i64> %1618, %1619
  %1621 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1617, 0
  %1622 = insertvalue { <8 x ptr>, <8 x i64> } %1621, <8 x i64> %1620, 1
  %.state755 = load <8 x float>, ptr %.slot124, align 32
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %1622, 1
  %1625 = extractelement <8 x ptr> %1623, i32 0
  %1626 = extractelement <8 x i64> %1624, i32 0
  %1627 = sub i64 %1626, 0
  %1628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1629 = select i1 %1628, i64 %1627, i64 0
  %private.contiguous.address756 = getelementptr i8, ptr %1625, i64 %1629
  %private.contiguous.preserve757 = load <8 x float>, ptr %private.contiguous.address756, align 4
  %1630 = select <8 x i1> %71, <8 x float> %.state755, <8 x float> %private.contiguous.preserve757
  store <8 x float> %1630, ptr %private.contiguous.address756, align 4
  %.state758 = load i64, ptr %.slot122, align 4
  %1631 = add i64 %.state758, 1
  store i64 %1631, ptr %.slot122, align 4
  br label %direct.schedule.73

direct.schedule.78:                               ; preds = %direct.false726
  store i64 0, ptr %.slot125, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state759 = load i64, ptr %.slot125, align 4
  %1632 = icmp slt i64 %.state759, 96
  br i1 %1632, label %direct.true760, label %direct.false761

direct.schedule.80:                               ; preds = %direct.true760
  %tile_snapshot.spill.load762 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %1634 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %.state763 = load i64, ptr %.slot125, align 4
  %.splatinsert764 = insertelement <8 x i64> poison, i64 %.state763, i64 0
  %.splat765 = shufflevector <8 x i64> %.splatinsert764, <8 x i64> poison, <8 x i32> zeroinitializer
  %1635 = mul <8 x i64> %.splat765, splat (i64 32)
  %1636 = add <8 x i64> %1634, %1635
  %1637 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1633, 0
  %1638 = insertvalue { <8 x ptr>, <8 x i64> } %1637, <8 x i64> %1636, 1
  %1639 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1640 = extractvalue { <8 x ptr>, <8 x i64> } %1638, 1
  %1641 = extractelement <8 x ptr> %1639, i32 0
  %1642 = extractelement <8 x i64> %1640, i32 0
  %1643 = sub i64 %1642, 0
  %1644 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1645 = select i1 %1644, i64 %1643, i64 0
  %private.contiguous.address766 = getelementptr i8, ptr %1641, i64 %1645
  %private.contiguous.load767 = load <8 x float>, ptr %private.contiguous.address766, align 4
  %1646 = select <8 x i1> %71, <8 x float> %private.contiguous.load767, <8 x float> zeroinitializer
  %tile_snapshot.spill.load768 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 0
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 1
  %.state769 = load i64, ptr %.slot125, align 4
  %.splatinsert770 = insertelement <8 x i64> poison, i64 %.state769, i64 0
  %.splat771 = shufflevector <8 x i64> %.splatinsert770, <8 x i64> poison, <8 x i32> zeroinitializer
  %1649 = mul <8 x i64> %.splat771, splat (i64 32)
  %1650 = add <8 x i64> %1648, %1649
  %1651 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1647, 0
  %1652 = insertvalue { <8 x ptr>, <8 x i64> } %1651, <8 x i64> %1650, 1
  %1653 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1654 = extractvalue { <8 x ptr>, <8 x i64> } %1652, 1
  %1655 = extractelement <8 x ptr> %1653, i32 0
  %1656 = extractelement <8 x i64> %1654, i32 0
  %1657 = sub i64 %1656, 0
  %1658 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1659 = select i1 %1658, i64 %1657, i64 0
  %private.contiguous.address772 = getelementptr i8, ptr %1655, i64 %1659
  %private.contiguous.preserve773 = load <8 x float>, ptr %private.contiguous.address772, align 4
  %1660 = select <8 x i1> %71, <8 x float> %1646, <8 x float> %private.contiguous.preserve773
  store <8 x float> %1660, ptr %private.contiguous.address772, align 4
  %.state774 = load i64, ptr %.slot125, align 4
  %1661 = add i64 %.state774, 1
  store i64 %1661, ptr %.slot125, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false761
  store i64 0, ptr %.slot126, align 4
  br label %direct.schedule.82

direct.schedule.82:                               ; preds = %direct.schedule.83, %direct.schedule.81
  %.state775 = load i64, ptr %.slot126, align 4
  %1662 = icmp slt i64 %.state775, 96
  br i1 %1662, label %direct.true776, label %direct.false777

direct.schedule.83:                               ; preds = %direct.true776
  %tile_snapshot.spill.load778 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load778, 0
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load778, 1
  %.state779 = load i64, ptr %.slot126, align 4
  %.splatinsert780 = insertelement <8 x i64> poison, i64 %.state779, i64 0
  %.splat781 = shufflevector <8 x i64> %.splatinsert780, <8 x i64> poison, <8 x i32> zeroinitializer
  %1665 = mul <8 x i64> %.splat781, splat (i64 32)
  %1666 = add <8 x i64> %1664, %1665
  %1667 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1663, 0
  %1668 = insertvalue { <8 x ptr>, <8 x i64> } %1667, <8 x i64> %1666, 1
  %1669 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1670 = extractvalue { <8 x ptr>, <8 x i64> } %1668, 1
  %1671 = extractelement <8 x ptr> %1669, i32 0
  %1672 = extractelement <8 x i64> %1670, i32 0
  %1673 = sub i64 %1672, 0
  %1674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1675 = select i1 %1674, i64 %1673, i64 0
  %private.contiguous.address782 = getelementptr i8, ptr %1671, i64 %1675
  %private.contiguous.load783 = load <8 x float>, ptr %private.contiguous.address782, align 4
  %1676 = select <8 x i1> %71, <8 x float> %private.contiguous.load783, <8 x float> zeroinitializer
  %tile_snapshot.spill.load784 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1677 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 0
  %1678 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 1
  %.state785 = load i64, ptr %.slot126, align 4
  %.splatinsert786 = insertelement <8 x i64> poison, i64 %.state785, i64 0
  %.splat787 = shufflevector <8 x i64> %.splatinsert786, <8 x i64> poison, <8 x i32> zeroinitializer
  %1679 = mul <8 x i64> %.splat787, splat (i64 32)
  %1680 = add <8 x i64> %1678, %1679
  %1681 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1677, 0
  %1682 = insertvalue { <8 x ptr>, <8 x i64> } %1681, <8 x i64> %1680, 1
  %1683 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1684 = extractvalue { <8 x ptr>, <8 x i64> } %1682, 1
  %1685 = extractelement <8 x ptr> %1683, i32 0
  %1686 = extractelement <8 x i64> %1684, i32 0
  %1687 = sub i64 %1686, 0
  %1688 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1689 = select i1 %1688, i64 %1687, i64 0
  %private.contiguous.address788 = getelementptr i8, ptr %1685, i64 %1689
  %private.contiguous.preserve789 = load <8 x float>, ptr %private.contiguous.address788, align 4
  %1690 = select <8 x i1> %71, <8 x float> %1676, <8 x float> %private.contiguous.preserve789
  store <8 x float> %1690, ptr %private.contiguous.address788, align 4
  %.state790 = load i64, ptr %.slot126, align 4
  %1691 = add i64 %.state790, 1
  store i64 %1691, ptr %.slot126, align 4
  br label %direct.schedule.82

direct.schedule.84:                               ; preds = %direct.false777
  %.state791 = load i64, ptr %.slot34, align 4
  %1692 = add i64 %.state791, 1
  %.spill.load792 = load <8 x float>, ptr %.spill114, align 32
  %.spill.load793 = load <8 x float>, ptr %.spill120, align 32
  store i64 %1692, ptr %.slot34, align 4
  %1693 = load <8 x float>, ptr %.slot35, align 32
  %1694 = select <8 x i1> %71, <8 x float> %.spill.load792, <8 x float> %1693
  store <8 x float> %1694, ptr %.slot35, align 32
  %1695 = load <8 x float>, ptr %.slot36, align 32
  %1696 = select <8 x i1> %71, <8 x float> %.spill.load793, <8 x float> %1695
  store <8 x float> %1696, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.85:                               ; preds = %direct.false163
  store i64 0, ptr %.slot127, align 4
  br label %direct.schedule.86

direct.schedule.86:                               ; preds = %direct.schedule.87, %direct.schedule.85
  %.state794 = load i64, ptr %.slot127, align 4
  %1697 = icmp slt i64 %.state794, 96
  br i1 %1697, label %direct.true795, label %direct.false796

direct.schedule.87:                               ; preds = %direct.true795
  %.spill.load797 = load i64, ptr %.spill29, align 4
  %1698 = add i64 %.spill.load797, 0
  %.spill.load798 = load <8 x i64>, ptr %.spill, align 64
  %1699 = add <8 x i64> %.spill.load798, zeroinitializer
  %1700 = mul i64 %1698, 8
  %.splatinsert799 = insertelement <8 x i64> poison, i64 %1700, i64 0
  %.splat800 = shufflevector <8 x i64> %.splatinsert799, <8 x i64> poison, <8 x i32> zeroinitializer
  %1701 = add <8 x i64> %.splat800, %1699
  %.spill.load801 = load i64, ptr %.spill29, align 4
  %1702 = add i64 %.spill.load801, 0
  %1703 = mul <8 x i64> %1701, splat (i64 1)
  %.splatinsert802 = insertelement <8 x i64> poison, i64 %1702, i64 0
  %.splat803 = shufflevector <8 x i64> %.splatinsert802, <8 x i64> poison, <8 x i32> zeroinitializer
  %1704 = add <8 x i64> %1703, %.splat803
  %.state804 = load i64, ptr %.slot127, align 4
  %1705 = add i64 0, %.state804
  %1706 = mul <8 x i64> %1704, splat (i64 96)
  %.splatinsert805 = insertelement <8 x i64> poison, i64 %1705, i64 0
  %.splat806 = shufflevector <8 x i64> %.splatinsert805, <8 x i64> poison, <8 x i32> zeroinitializer
  %1707 = add <8 x i64> %1706, %.splat806
  %.state807 = load i64, ptr %.slot127, align 4
  %1708 = add i64 0, %.state807
  %tile_snapshot.spill.load808 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load808, 0
  %1710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load808, 1
  %.splatinsert809 = insertelement <8 x i64> poison, i64 %1708, i64 0
  %.splat810 = shufflevector <8 x i64> %.splatinsert809, <8 x i64> poison, <8 x i32> zeroinitializer
  %1711 = mul <8 x i64> %.splat810, splat (i64 32)
  %1712 = add <8 x i64> %1710, %1711
  %1713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1709, 0
  %1714 = insertvalue { <8 x ptr>, <8 x i64> } %1713, <8 x i64> %1712, 1
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1716 = extractvalue { <8 x ptr>, <8 x i64> } %1714, 1
  %1717 = extractelement <8 x ptr> %1715, i32 0
  %1718 = extractelement <8 x i64> %1716, i32 0
  %1719 = sub i64 %1718, 0
  %1720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1721 = select i1 %1720, i64 %1719, i64 0
  %private.contiguous.address811 = getelementptr i8, ptr %1717, i64 %1721
  %private.contiguous.load812 = load <8 x float>, ptr %private.contiguous.address811, align 4
  %1722 = select <8 x i1> %71, <8 x float> %private.contiguous.load812, <8 x float> zeroinitializer
  %.state813 = load <8 x float>, ptr %.slot36, align 32
  %1723 = fdiv <8 x float> %1722, %.state813
  %1724 = extractvalue { ptr, i64 } %47, 0
  %1725 = mul <8 x i64> %1707, splat (i64 4)
  %1726 = getelementptr i8, ptr %1724, <8 x i64> %1725
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1723, <8 x ptr> align 1 %1726, <8 x i1> %71)
  %.state814 = load i64, ptr %.slot127, align 4
  %1727 = add i64 %.state814, 1
  store i64 %1727, ptr %.slot127, align 4
  br label %direct.schedule.86

direct.schedule.88:                               ; preds = %direct.false796
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true152:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false153:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true162:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false163:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.85

direct.true166:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false167:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true179:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false180:                                  ; preds = %direct.schedule.10
  %1728 = load <8 x float>, ptr %.slot41, align 32
  %1729 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1728
  store <8 x float> %1729, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.true191:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false192:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true204:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false205:                                  ; preds = %direct.schedule.15
  %1730 = load <8 x float>, ptr %.slot45, align 32
  %1731 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1730
  store <8 x float> %1731, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.true216:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false217:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true231:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false232:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true248:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false249:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true265:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false266:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true282:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false283:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true299:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false300:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true316:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false317:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true333:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false334:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true350:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false351:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true367:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false368:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true384:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false385:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true401:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false402:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true418:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false419:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true435:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false436:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true452:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false453:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true469:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false470:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true583:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false584:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true711:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false712:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true725:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false726:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.78

direct.true735:                                   ; preds = %direct.schedule.75
  br label %direct.schedule.76

direct.false736:                                  ; preds = %direct.schedule.75
  br label %direct.schedule.77

direct.true760:                                   ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false761:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.81

direct.true776:                                   ; preds = %direct.schedule.82
  br label %direct.schedule.83

direct.false777:                                  ; preds = %direct.schedule.82
  br label %direct.schedule.84

direct.true795:                                   ; preds = %direct.schedule.86
  br label %direct.schedule.87

direct.false796:                                  ; preds = %direct.schedule.86
  br label %direct.schedule.88
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #3 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #4

define internal void @llm_attention.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill31, align 64
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca i64, align 8
  store i64 0, ptr %.slot33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %tile_snapshot.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill42, align 64
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %.spill44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill44, align 64
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca i64, align 8
  store i64 0, ptr %.slot48, align 4
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca i64, align 8
  store i64 0, ptr %.slot50, align 4
  %.slot51 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca i64, align 8
  store i64 0, ptr %.slot52, align 4
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca i64, align 8
  store i64 0, ptr %.slot54, align 4
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca i64, align 8
  store i64 0, ptr %.slot58, align 4
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca i64, align 8
  store i64 0, ptr %.slot60, align 4
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca i64, align 8
  store i64 0, ptr %.slot62, align 4
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca i64, align 8
  store i64 0, ptr %.slot64, align 4
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.slot66 = alloca i64, align 8
  store i64 0, ptr %.slot66, align 4
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.slot68 = alloca i64, align 8
  store i64 0, ptr %.slot68, align 4
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca i64, align 8
  store i64 0, ptr %.slot70, align 4
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca i64, align 8
  store i64 0, ptr %.slot72, align 4
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca i64, align 8
  store i64 0, ptr %.slot74, align 4
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca i64, align 8
  store i64 0, ptr %.slot76, align 4
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.spill78 = alloca i64, align 8
  store i64 0, ptr %.spill78, align 4
  %.spill79 = alloca i1, align 1
  store i1 false, ptr %.spill79, align 1
  %.spill80 = alloca i1, align 1
  store i1 false, ptr %.spill80, align 1
  %.spill81 = alloca i1, align 1
  store i1 false, ptr %.spill81, align 1
  %.spill82 = alloca i1, align 1
  store i1 false, ptr %.spill82, align 1
  %.spill83 = alloca i1, align 1
  store i1 false, ptr %.spill83, align 1
  %.spill84 = alloca i1, align 1
  store i1 false, ptr %.spill84, align 1
  %.spill85 = alloca i1, align 1
  store i1 false, ptr %.spill85, align 1
  %.spill86 = alloca i1, align 1
  store i1 false, ptr %.spill86, align 1
  %.spill87 = alloca i1, align 1
  store i1 false, ptr %.spill87, align 1
  %.spill88 = alloca i1, align 1
  store i1 false, ptr %.spill88, align 1
  %.spill89 = alloca i1, align 1
  store i1 false, ptr %.spill89, align 1
  %.spill90 = alloca i1, align 1
  store i1 false, ptr %.spill90, align 1
  %.spill91 = alloca i1, align 1
  store i1 false, ptr %.spill91, align 1
  %.spill92 = alloca i1, align 1
  store i1 false, ptr %.spill92, align 1
  %.spill93 = alloca i1, align 1
  store i1 false, ptr %.spill93, align 1
  %.spill94 = alloca i1, align 1
  store i1 false, ptr %.spill94, align 1
  %.spill95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill100, align 32
  %.spill101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill103, align 32
  %.spill104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill104, align 32
  %.spill105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.spill106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill106, align 32
  %.spill107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill108, align 32
  %.spill109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill109, align 32
  %.spill110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill110, align 32
  %tile_snapshot.spill111 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill111, align 64
  %.slot112 = alloca i64, align 8
  store i64 0, ptr %.slot112, align 4
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.spill114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill114, align 32
  %.spill115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill115, align 32
  %tile_snapshot.spill116 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill116, align 64
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.slot118 = alloca i64, align 8
  store i64 0, ptr %.slot118, align 4
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %tile_snapshot.spill121 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill121, align 64
  %.slot122 = alloca i64, align 8
  store i64 0, ptr %.slot122, align 4
  %.slot123 = alloca i64, align 8
  store i64 0, ptr %.slot123, align 4
  %.slot124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot124, align 32
  %.slot125 = alloca i64, align 8
  store i64 0, ptr %.slot125, align 4
  %.slot126 = alloca i64, align 8
  store i64 0, ptr %.slot126, align 4
  %.slot127 = alloca i64, align 8
  store i64 0, ptr %.slot127, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert128 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat129 = shufflevector <8 x i32> %.splatinsert128, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat129, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert130 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat131 = shufflevector <8 x i32> %.splatinsert130, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat131, %61
  %64 = mul i32 %52, 1
  %.splatinsert132 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat133 = shufflevector <8 x i32> %.splatinsert132, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat133, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert134 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat135 = shufflevector <8 x i32> %.splatinsert134, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat135, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert136 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat137 = shufflevector <8 x i32> %.splatinsert136, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat137
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  store i64 0, ptr %.spill29, align 4
  %80 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = load <8 x i64>, ptr %.spill30, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill30, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %94 = icmp slt i64 %.state, 80
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load i64, ptr %.spill29, align 4
  %95 = add i64 %.spill.load, 0
  %.spill.load138 = load <8 x i64>, ptr %.spill, align 64
  %96 = add <8 x i64> %.spill.load138, zeroinitializer
  %97 = mul i64 %95, 8
  %.splatinsert139 = insertelement <8 x i64> poison, i64 %97, i64 0
  %.splat140 = shufflevector <8 x i64> %.splatinsert139, <8 x i64> poison, <8 x i32> zeroinitializer
  %98 = add <8 x i64> %.splat140, %96
  %.spill.load141 = load i64, ptr %.spill29, align 4
  %99 = add i64 %.spill.load141, 0
  %100 = mul <8 x i64> %98, splat (i64 1)
  %.splatinsert142 = insertelement <8 x i64> poison, i64 %99, i64 0
  %.splat143 = shufflevector <8 x i64> %.splatinsert142, <8 x i64> poison, <8 x i32> zeroinitializer
  %101 = add <8 x i64> %100, %.splat143
  %.state144 = load i64, ptr %.slot, align 4
  %102 = add i64 0, %.state144
  %103 = mul <8 x i64> %101, splat (i64 80)
  %.splatinsert145 = insertelement <8 x i64> poison, i64 %102, i64 0
  %.splat146 = shufflevector <8 x i64> %.splatinsert145, <8 x i64> poison, <8 x i32> zeroinitializer
  %104 = add <8 x i64> %103, %.splat146
  %105 = extractvalue { ptr, i64 } %29, 0
  %106 = mul <8 x i64> %104, splat (i64 4)
  %107 = getelementptr i8, ptr %105, <8 x i64> %106
  %108 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %107, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state147 = load i64, ptr %.slot, align 4
  %.splatinsert148 = insertelement <8 x i64> poison, i64 %.state147, i64 0
  %.splat149 = shufflevector <8 x i64> %.splatinsert148, <8 x i64> poison, <8 x i32> zeroinitializer
  %111 = mul <8 x i64> %.splat149, splat (i64 32)
  %112 = add <8 x i64> %110, %111
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %109, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %114, 1
  %117 = extractelement <8 x ptr> %115, i32 0
  %118 = extractelement <8 x i64> %116, i32 0
  %119 = sub i64 %118, 0
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %121 = select i1 %120, i64 %119, i64 0
  %private.contiguous.address = getelementptr i8, ptr %117, i64 %121
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %122 = select <8 x i1> %71, <8 x float> %108, <8 x float> %private.contiguous.preserve
  store <8 x float> %122, ptr %private.contiguous.address, align 4
  %.state150 = load i64, ptr %.slot, align 4
  %123 = add i64 %.state150, 1
  store i64 %123, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %71, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %71, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill31, align 64
  %133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 0
  %136 = select <8 x i1> %71, <8 x ptr> %134, <8 x ptr> %135
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %139 = select <8 x i1> %71, <8 x i64> %137, <8 x i64> %138
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  store { <8 x ptr>, <8 x i64> } %141, ptr %tile_snapshot.spill32, align 64
  store i64 0, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state151 = load i64, ptr %.slot33, align 4
  %142 = icmp slt i64 %.state151, 96
  br i1 %142, label %direct.true152, label %direct.false153

direct.schedule.5:                                ; preds = %direct.true152
  %tile_snapshot.spill.load154 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 1
  %.state155 = load i64, ptr %.slot33, align 4
  %.splatinsert156 = insertelement <8 x i64> poison, i64 %.state155, i64 0
  %.splat157 = shufflevector <8 x i64> %.splatinsert156, <8 x i64> poison, <8 x i32> zeroinitializer
  %145 = mul <8 x i64> %.splat157, splat (i64 32)
  %146 = add <8 x i64> %144, %145
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %143, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %148, 1
  %151 = extractelement <8 x ptr> %149, i32 0
  %152 = extractelement <8 x i64> %150, i32 0
  %153 = sub i64 %152, 0
  %154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %155 = select i1 %154, i64 %153, i64 0
  %private.contiguous.address158 = getelementptr i8, ptr %151, i64 %155
  %private.contiguous.preserve159 = load <8 x float>, ptr %private.contiguous.address158, align 4
  %156 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve159
  store <8 x float> %156, ptr %private.contiguous.address158, align 4
  %.state160 = load i64, ptr %.slot33, align 4
  %157 = add i64 %.state160, 1
  store i64 %157, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false153
  store i64 0, ptr %.slot34, align 4
  %158 = load <8 x float>, ptr %.slot35, align 32
  %159 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %158
  store <8 x float> %159, ptr %.slot35, align 32
  %160 = load <8 x float>, ptr %.slot36, align 32
  %161 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %160
  store <8 x float> %161, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.84, %direct.schedule.6
  %.state161 = load i64, ptr %.slot34, align 4
  %162 = icmp slt i64 %.state161, 129
  br i1 %162, label %direct.true162, label %direct.false163

direct.schedule.8:                                ; preds = %direct.true162
  %.state164 = load i64, ptr %.slot34, align 4
  %163 = sdiv i64 %.state164, 1
  %164 = mul i64 %163, 16
  store i64 %164, ptr %.spill37, align 4
  %165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %168 = select <8 x i1> %71, <8 x ptr> %166, <8 x ptr> %167
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %171 = select <8 x i1> %71, <8 x i64> %169, <8 x i64> %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  store { <8 x ptr>, <8 x i64> } %173, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state165 = load i64, ptr %.slot39, align 4
  %174 = icmp slt i64 %.state165, 1280
  br i1 %174, label %direct.true166, label %direct.false167

direct.schedule.10:                               ; preds = %direct.true166
  %.state168 = load i64, ptr %.slot39, align 4
  %175 = srem i64 %.state168, 80
  %.state169 = load i64, ptr %.slot39, align 4
  %176 = sdiv i64 %.state169, 80
  %.spill.load170 = load i64, ptr %.spill29, align 4
  %177 = add i64 %.spill.load170, 0
  %.spill.load171 = load <8 x i64>, ptr %.spill30, align 64
  %178 = add <8 x i64> %.spill.load171, zeroinitializer
  %179 = mul i64 %177, 2
  %.splatinsert172 = insertelement <8 x i64> poison, i64 %179, i64 0
  %.splat173 = shufflevector <8 x i64> %.splatinsert172, <8 x i64> poison, <8 x i32> zeroinitializer
  %180 = add <8 x i64> %.splat173, %178
  %.spill.load174 = load i64, ptr %.spill37, align 4
  %181 = add i64 %.spill.load174, %176
  %182 = mul <8 x i64> %180, splat (i64 2053)
  %.splatinsert175 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat176 = shufflevector <8 x i64> %.splatinsert175, <8 x i64> poison, <8 x i32> zeroinitializer
  %183 = add <8 x i64> %182, %.splat176
  %184 = icmp sge i64 %181, 0
  %185 = and i1 true, %184
  %186 = icmp slt i64 %181, 2053
  %187 = and i1 %185, %186
  %188 = add i64 0, %175
  %189 = mul <8 x i64> %183, splat (i64 80)
  %.splatinsert177 = insertelement <8 x i64> poison, i64 %188, i64 0
  %.splat178 = shufflevector <8 x i64> %.splatinsert177, <8 x i64> poison, <8 x i32> zeroinitializer
  %190 = add <8 x i64> %189, %.splat178
  %191 = load <8 x i64>, ptr %.spill40, align 64
  %192 = select <8 x i1> %71, <8 x i64> %190, <8 x i64> %191
  store <8 x i64> %192, ptr %.spill40, align 64
  br i1 %187, label %direct.true179, label %direct.false180

direct.schedule.11:                               ; preds = %direct.true179
  %.spill.load181 = load <8 x i64>, ptr %.spill40, align 64
  %193 = extractvalue { ptr, i64 } %35, 0
  %194 = mul <8 x i64> %.spill.load181, splat (i64 4)
  %195 = getelementptr i8, ptr %193, <8 x i64> %194
  %196 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %195, <8 x i1> %71, <8 x float> zeroinitializer)
  %197 = load <8 x float>, ptr %.slot41, align 32
  %198 = select <8 x i1> %71, <8 x float> %196, <8 x float> %197
  store <8 x float> %198, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.false180, %direct.schedule.11
  %tile_snapshot.spill.load182 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 1
  %.state183 = load i64, ptr %.slot39, align 4
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %.state183, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %201 = mul <8 x i64> %.splat185, splat (i64 32)
  %202 = add <8 x i64> %200, %201
  %203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %199, 0
  %204 = insertvalue { <8 x ptr>, <8 x i64> } %203, <8 x i64> %202, 1
  %.state186 = load <8 x float>, ptr %.slot41, align 32
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %204, 1
  %207 = extractelement <8 x ptr> %205, i32 0
  %208 = extractelement <8 x i64> %206, i32 0
  %209 = sub i64 %208, 0
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %211 = select i1 %210, i64 %209, i64 0
  %private.contiguous.address187 = getelementptr i8, ptr %207, i64 %211
  %private.contiguous.preserve188 = load <8 x float>, ptr %private.contiguous.address187, align 4
  %212 = select <8 x i1> %71, <8 x float> %.state186, <8 x float> %private.contiguous.preserve188
  store <8 x float> %212, ptr %private.contiguous.address187, align 4
  %.state189 = load i64, ptr %.slot39, align 4
  %213 = add i64 %.state189, 1
  store i64 %213, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false167
  %214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %214, 0
  %217 = select <8 x i1> %71, <8 x ptr> %215, <8 x ptr> %216
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %214, 1
  %220 = select <8 x i1> %71, <8 x i64> %218, <8 x i64> %219
  %221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %222 = insertvalue { <8 x ptr>, <8 x i64> } %221, <8 x i64> %220, 1
  store { <8 x ptr>, <8 x i64> } %222, ptr %tile_snapshot.spill42, align 64
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state190 = load i64, ptr %.slot43, align 4
  %223 = icmp slt i64 %.state190, 1536
  br i1 %223, label %direct.true191, label %direct.false192

direct.schedule.15:                               ; preds = %direct.true191
  %.state193 = load i64, ptr %.slot43, align 4
  %224 = srem i64 %.state193, 96
  %.state194 = load i64, ptr %.slot43, align 4
  %225 = sdiv i64 %.state194, 96
  %.spill.load195 = load i64, ptr %.spill29, align 4
  %226 = add i64 %.spill.load195, 0
  %.spill.load196 = load <8 x i64>, ptr %.spill30, align 64
  %227 = add <8 x i64> %.spill.load196, zeroinitializer
  %228 = mul i64 %226, 2
  %.splatinsert197 = insertelement <8 x i64> poison, i64 %228, i64 0
  %.splat198 = shufflevector <8 x i64> %.splatinsert197, <8 x i64> poison, <8 x i32> zeroinitializer
  %229 = add <8 x i64> %.splat198, %227
  %.spill.load199 = load i64, ptr %.spill37, align 4
  %230 = add i64 %.spill.load199, %225
  %231 = mul <8 x i64> %229, splat (i64 2053)
  %.splatinsert200 = insertelement <8 x i64> poison, i64 %230, i64 0
  %.splat201 = shufflevector <8 x i64> %.splatinsert200, <8 x i64> poison, <8 x i32> zeroinitializer
  %232 = add <8 x i64> %231, %.splat201
  %233 = icmp sge i64 %230, 0
  %234 = and i1 true, %233
  %235 = icmp slt i64 %230, 2053
  %236 = and i1 %234, %235
  %237 = add i64 0, %224
  %238 = mul <8 x i64> %232, splat (i64 96)
  %.splatinsert202 = insertelement <8 x i64> poison, i64 %237, i64 0
  %.splat203 = shufflevector <8 x i64> %.splatinsert202, <8 x i64> poison, <8 x i32> zeroinitializer
  %239 = add <8 x i64> %238, %.splat203
  %240 = load <8 x i64>, ptr %.spill44, align 64
  %241 = select <8 x i1> %71, <8 x i64> %239, <8 x i64> %240
  store <8 x i64> %241, ptr %.spill44, align 64
  br i1 %236, label %direct.true204, label %direct.false205

direct.schedule.16:                               ; preds = %direct.true204
  %.spill.load206 = load <8 x i64>, ptr %.spill44, align 64
  %242 = extractvalue { ptr, i64 } %41, 0
  %243 = mul <8 x i64> %.spill.load206, splat (i64 4)
  %244 = getelementptr i8, ptr %242, <8 x i64> %243
  %245 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %244, <8 x i1> %71, <8 x float> zeroinitializer)
  %246 = load <8 x float>, ptr %.slot45, align 32
  %247 = select <8 x i1> %71, <8 x float> %245, <8 x float> %246
  store <8 x float> %247, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.false205, %direct.schedule.16
  %tile_snapshot.spill.load207 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load207, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load207, 1
  %.state208 = load i64, ptr %.slot43, align 4
  %.splatinsert209 = insertelement <8 x i64> poison, i64 %.state208, i64 0
  %.splat210 = shufflevector <8 x i64> %.splatinsert209, <8 x i64> poison, <8 x i32> zeroinitializer
  %250 = mul <8 x i64> %.splat210, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %.state211 = load <8 x float>, ptr %.slot45, align 32
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address212 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.preserve213 = load <8 x float>, ptr %private.contiguous.address212, align 4
  %261 = select <8 x i1> %71, <8 x float> %.state211, <8 x float> %private.contiguous.preserve213
  store <8 x float> %261, ptr %private.contiguous.address212, align 4
  %.state214 = load i64, ptr %.slot43, align 4
  %262 = add i64 %.state214, 1
  store i64 %262, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false192
  store i64 0, ptr %.slot46, align 4
  %263 = load <8 x float>, ptr %.slot47, align 32
  %264 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %263
  store <8 x float> %264, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state215 = load i64, ptr %.slot46, align 4
  %265 = icmp slt i64 %.state215, 80
  br i1 %265, label %direct.true216, label %direct.false217

direct.schedule.20:                               ; preds = %direct.true216
  %.state218 = load i64, ptr %.slot46, align 4
  %266 = add i64 0, %.state218
  %tile_snapshot.spill.load219 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load219, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load219, 1
  %.splatinsert220 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat221 = shufflevector <8 x i64> %.splatinsert220, <8 x i64> poison, <8 x i32> zeroinitializer
  %269 = mul <8 x i64> %.splat221, splat (i64 32)
  %270 = add <8 x i64> %268, %269
  %271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %267, 0
  %272 = insertvalue { <8 x ptr>, <8 x i64> } %271, <8 x i64> %270, 1
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %272, 1
  %275 = extractelement <8 x ptr> %273, i32 0
  %276 = extractelement <8 x i64> %274, i32 0
  %277 = sub i64 %276, 0
  %278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %279 = select i1 %278, i64 %277, i64 0
  %private.contiguous.address222 = getelementptr i8, ptr %275, i64 %279
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address222, align 4
  %280 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load223 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load223, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load223, 1
  %.splatinsert224 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat225 = shufflevector <8 x i64> %.splatinsert224, <8 x i64> poison, <8 x i32> zeroinitializer
  %283 = mul <8 x i64> %.splat225, splat (i64 32)
  %284 = add <8 x i64> %282, %283
  %285 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %281, 0
  %286 = insertvalue { <8 x ptr>, <8 x i64> } %285, <8 x i64> %284, 1
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %286, 1
  %289 = extractelement <8 x ptr> %287, i32 0
  %290 = extractelement <8 x i64> %288, i32 0
  %291 = sub i64 %290, 0
  %292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %293 = select i1 %292, i64 %291, i64 0
  %private.contiguous.address226 = getelementptr i8, ptr %289, i64 %293
  %private.contiguous.load227 = load <8 x float>, ptr %private.contiguous.address226, align 4
  %294 = select <8 x i1> %71, <8 x float> %private.contiguous.load227, <8 x float> zeroinitializer
  %295 = fmul <8 x float> %280, %294
  %.state228 = load <8 x float>, ptr %.slot47, align 32
  %296 = fadd <8 x float> %.state228, %295
  %.state229 = load i64, ptr %.slot46, align 4
  %297 = add i64 %.state229, 1
  store i64 %297, ptr %.slot46, align 4
  %298 = load <8 x float>, ptr %.slot47, align 32
  %299 = select <8 x i1> %71, <8 x float> %296, <8 x float> %298
  store <8 x float> %299, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false217
  store i64 0, ptr %.slot48, align 4
  %300 = load <8 x float>, ptr %.slot49, align 32
  %301 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %300
  store <8 x float> %301, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state230 = load i64, ptr %.slot48, align 4
  %302 = icmp slt i64 %.state230, 80
  br i1 %302, label %direct.true231, label %direct.false232

direct.schedule.23:                               ; preds = %direct.true231
  %.state233 = load i64, ptr %.slot48, align 4
  %303 = add i64 0, %.state233
  %tile_snapshot.spill.load234 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 1
  %.splatinsert235 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat236 = shufflevector <8 x i64> %.splatinsert235, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat236, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address237 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load238 = load <8 x float>, ptr %private.contiguous.address237, align 4
  %317 = select <8 x i1> %71, <8 x float> %private.contiguous.load238, <8 x float> zeroinitializer
  %.state239 = load i64, ptr %.slot48, align 4
  %318 = add i64 80, %.state239
  %tile_snapshot.spill.load240 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 0
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 1
  %.splatinsert241 = insertelement <8 x i64> poison, i64 %318, i64 0
  %.splat242 = shufflevector <8 x i64> %.splatinsert241, <8 x i64> poison, <8 x i32> zeroinitializer
  %321 = mul <8 x i64> %.splat242, splat (i64 32)
  %322 = add <8 x i64> %320, %321
  %323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %319, 0
  %324 = insertvalue { <8 x ptr>, <8 x i64> } %323, <8 x i64> %322, 1
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %324, 1
  %327 = extractelement <8 x ptr> %325, i32 0
  %328 = extractelement <8 x i64> %326, i32 0
  %329 = sub i64 %328, 0
  %330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %331 = select i1 %330, i64 %329, i64 0
  %private.contiguous.address243 = getelementptr i8, ptr %327, i64 %331
  %private.contiguous.load244 = load <8 x float>, ptr %private.contiguous.address243, align 4
  %332 = select <8 x i1> %71, <8 x float> %private.contiguous.load244, <8 x float> zeroinitializer
  %333 = fmul <8 x float> %317, %332
  %.state245 = load <8 x float>, ptr %.slot49, align 32
  %334 = fadd <8 x float> %.state245, %333
  %.state246 = load i64, ptr %.slot48, align 4
  %335 = add i64 %.state246, 1
  store i64 %335, ptr %.slot48, align 4
  %336 = load <8 x float>, ptr %.slot49, align 32
  %337 = select <8 x i1> %71, <8 x float> %334, <8 x float> %336
  store <8 x float> %337, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false232
  store i64 0, ptr %.slot50, align 4
  %338 = load <8 x float>, ptr %.slot51, align 32
  %339 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %338
  store <8 x float> %339, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state247 = load i64, ptr %.slot50, align 4
  %340 = icmp slt i64 %.state247, 80
  br i1 %340, label %direct.true248, label %direct.false249

direct.schedule.26:                               ; preds = %direct.true248
  %.state250 = load i64, ptr %.slot50, align 4
  %341 = add i64 0, %.state250
  %tile_snapshot.spill.load251 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 0
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 1
  %.splatinsert252 = insertelement <8 x i64> poison, i64 %341, i64 0
  %.splat253 = shufflevector <8 x i64> %.splatinsert252, <8 x i64> poison, <8 x i32> zeroinitializer
  %344 = mul <8 x i64> %.splat253, splat (i64 32)
  %345 = add <8 x i64> %343, %344
  %346 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %342, 0
  %347 = insertvalue { <8 x ptr>, <8 x i64> } %346, <8 x i64> %345, 1
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %347, 1
  %350 = extractelement <8 x ptr> %348, i32 0
  %351 = extractelement <8 x i64> %349, i32 0
  %352 = sub i64 %351, 0
  %353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %354 = select i1 %353, i64 %352, i64 0
  %private.contiguous.address254 = getelementptr i8, ptr %350, i64 %354
  %private.contiguous.load255 = load <8 x float>, ptr %private.contiguous.address254, align 4
  %355 = select <8 x i1> %71, <8 x float> %private.contiguous.load255, <8 x float> zeroinitializer
  %.state256 = load i64, ptr %.slot50, align 4
  %356 = add i64 160, %.state256
  %tile_snapshot.spill.load257 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 0
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 1
  %.splatinsert258 = insertelement <8 x i64> poison, i64 %356, i64 0
  %.splat259 = shufflevector <8 x i64> %.splatinsert258, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = mul <8 x i64> %.splat259, splat (i64 32)
  %360 = add <8 x i64> %358, %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = extractelement <8 x ptr> %363, i32 0
  %366 = extractelement <8 x i64> %364, i32 0
  %367 = sub i64 %366, 0
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %369 = select i1 %368, i64 %367, i64 0
  %private.contiguous.address260 = getelementptr i8, ptr %365, i64 %369
  %private.contiguous.load261 = load <8 x float>, ptr %private.contiguous.address260, align 4
  %370 = select <8 x i1> %71, <8 x float> %private.contiguous.load261, <8 x float> zeroinitializer
  %371 = fmul <8 x float> %355, %370
  %.state262 = load <8 x float>, ptr %.slot51, align 32
  %372 = fadd <8 x float> %.state262, %371
  %.state263 = load i64, ptr %.slot50, align 4
  %373 = add i64 %.state263, 1
  store i64 %373, ptr %.slot50, align 4
  %374 = load <8 x float>, ptr %.slot51, align 32
  %375 = select <8 x i1> %71, <8 x float> %372, <8 x float> %374
  store <8 x float> %375, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false249
  store i64 0, ptr %.slot52, align 4
  %376 = load <8 x float>, ptr %.slot53, align 32
  %377 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %376
  store <8 x float> %377, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state264 = load i64, ptr %.slot52, align 4
  %378 = icmp slt i64 %.state264, 80
  br i1 %378, label %direct.true265, label %direct.false266

direct.schedule.29:                               ; preds = %direct.true265
  %.state267 = load i64, ptr %.slot52, align 4
  %379 = add i64 0, %.state267
  %tile_snapshot.spill.load268 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load268, 0
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load268, 1
  %.splatinsert269 = insertelement <8 x i64> poison, i64 %379, i64 0
  %.splat270 = shufflevector <8 x i64> %.splatinsert269, <8 x i64> poison, <8 x i32> zeroinitializer
  %382 = mul <8 x i64> %.splat270, splat (i64 32)
  %383 = add <8 x i64> %381, %382
  %384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %380, 0
  %385 = insertvalue { <8 x ptr>, <8 x i64> } %384, <8 x i64> %383, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %385, 1
  %388 = extractelement <8 x ptr> %386, i32 0
  %389 = extractelement <8 x i64> %387, i32 0
  %390 = sub i64 %389, 0
  %391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %392 = select i1 %391, i64 %390, i64 0
  %private.contiguous.address271 = getelementptr i8, ptr %388, i64 %392
  %private.contiguous.load272 = load <8 x float>, ptr %private.contiguous.address271, align 4
  %393 = select <8 x i1> %71, <8 x float> %private.contiguous.load272, <8 x float> zeroinitializer
  %.state273 = load i64, ptr %.slot52, align 4
  %394 = add i64 240, %.state273
  %tile_snapshot.spill.load274 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 0
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 1
  %.splatinsert275 = insertelement <8 x i64> poison, i64 %394, i64 0
  %.splat276 = shufflevector <8 x i64> %.splatinsert275, <8 x i64> poison, <8 x i32> zeroinitializer
  %397 = mul <8 x i64> %.splat276, splat (i64 32)
  %398 = add <8 x i64> %396, %397
  %399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %395, 0
  %400 = insertvalue { <8 x ptr>, <8 x i64> } %399, <8 x i64> %398, 1
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %400, 1
  %403 = extractelement <8 x ptr> %401, i32 0
  %404 = extractelement <8 x i64> %402, i32 0
  %405 = sub i64 %404, 0
  %406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %407 = select i1 %406, i64 %405, i64 0
  %private.contiguous.address277 = getelementptr i8, ptr %403, i64 %407
  %private.contiguous.load278 = load <8 x float>, ptr %private.contiguous.address277, align 4
  %408 = select <8 x i1> %71, <8 x float> %private.contiguous.load278, <8 x float> zeroinitializer
  %409 = fmul <8 x float> %393, %408
  %.state279 = load <8 x float>, ptr %.slot53, align 32
  %410 = fadd <8 x float> %.state279, %409
  %.state280 = load i64, ptr %.slot52, align 4
  %411 = add i64 %.state280, 1
  store i64 %411, ptr %.slot52, align 4
  %412 = load <8 x float>, ptr %.slot53, align 32
  %413 = select <8 x i1> %71, <8 x float> %410, <8 x float> %412
  store <8 x float> %413, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false266
  store i64 0, ptr %.slot54, align 4
  %414 = load <8 x float>, ptr %.slot55, align 32
  %415 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %414
  store <8 x float> %415, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state281 = load i64, ptr %.slot54, align 4
  %416 = icmp slt i64 %.state281, 80
  br i1 %416, label %direct.true282, label %direct.false283

direct.schedule.32:                               ; preds = %direct.true282
  %.state284 = load i64, ptr %.slot54, align 4
  %417 = add i64 0, %.state284
  %tile_snapshot.spill.load285 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 0
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 1
  %.splatinsert286 = insertelement <8 x i64> poison, i64 %417, i64 0
  %.splat287 = shufflevector <8 x i64> %.splatinsert286, <8 x i64> poison, <8 x i32> zeroinitializer
  %420 = mul <8 x i64> %.splat287, splat (i64 32)
  %421 = add <8 x i64> %419, %420
  %422 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %418, 0
  %423 = insertvalue { <8 x ptr>, <8 x i64> } %422, <8 x i64> %421, 1
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %423, 1
  %426 = extractelement <8 x ptr> %424, i32 0
  %427 = extractelement <8 x i64> %425, i32 0
  %428 = sub i64 %427, 0
  %429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %430 = select i1 %429, i64 %428, i64 0
  %private.contiguous.address288 = getelementptr i8, ptr %426, i64 %430
  %private.contiguous.load289 = load <8 x float>, ptr %private.contiguous.address288, align 4
  %431 = select <8 x i1> %71, <8 x float> %private.contiguous.load289, <8 x float> zeroinitializer
  %.state290 = load i64, ptr %.slot54, align 4
  %432 = add i64 320, %.state290
  %tile_snapshot.spill.load291 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load291, 0
  %434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load291, 1
  %.splatinsert292 = insertelement <8 x i64> poison, i64 %432, i64 0
  %.splat293 = shufflevector <8 x i64> %.splatinsert292, <8 x i64> poison, <8 x i32> zeroinitializer
  %435 = mul <8 x i64> %.splat293, splat (i64 32)
  %436 = add <8 x i64> %434, %435
  %437 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %433, 0
  %438 = insertvalue { <8 x ptr>, <8 x i64> } %437, <8 x i64> %436, 1
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %438, 1
  %441 = extractelement <8 x ptr> %439, i32 0
  %442 = extractelement <8 x i64> %440, i32 0
  %443 = sub i64 %442, 0
  %444 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %445 = select i1 %444, i64 %443, i64 0
  %private.contiguous.address294 = getelementptr i8, ptr %441, i64 %445
  %private.contiguous.load295 = load <8 x float>, ptr %private.contiguous.address294, align 4
  %446 = select <8 x i1> %71, <8 x float> %private.contiguous.load295, <8 x float> zeroinitializer
  %447 = fmul <8 x float> %431, %446
  %.state296 = load <8 x float>, ptr %.slot55, align 32
  %448 = fadd <8 x float> %.state296, %447
  %.state297 = load i64, ptr %.slot54, align 4
  %449 = add i64 %.state297, 1
  store i64 %449, ptr %.slot54, align 4
  %450 = load <8 x float>, ptr %.slot55, align 32
  %451 = select <8 x i1> %71, <8 x float> %448, <8 x float> %450
  store <8 x float> %451, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false283
  store i64 0, ptr %.slot56, align 4
  %452 = load <8 x float>, ptr %.slot57, align 32
  %453 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %452
  store <8 x float> %453, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state298 = load i64, ptr %.slot56, align 4
  %454 = icmp slt i64 %.state298, 80
  br i1 %454, label %direct.true299, label %direct.false300

direct.schedule.35:                               ; preds = %direct.true299
  %.state301 = load i64, ptr %.slot56, align 4
  %455 = add i64 0, %.state301
  %tile_snapshot.spill.load302 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %456 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load302, 0
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load302, 1
  %.splatinsert303 = insertelement <8 x i64> poison, i64 %455, i64 0
  %.splat304 = shufflevector <8 x i64> %.splatinsert303, <8 x i64> poison, <8 x i32> zeroinitializer
  %458 = mul <8 x i64> %.splat304, splat (i64 32)
  %459 = add <8 x i64> %457, %458
  %460 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %456, 0
  %461 = insertvalue { <8 x ptr>, <8 x i64> } %460, <8 x i64> %459, 1
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %461, 1
  %464 = extractelement <8 x ptr> %462, i32 0
  %465 = extractelement <8 x i64> %463, i32 0
  %466 = sub i64 %465, 0
  %467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %468 = select i1 %467, i64 %466, i64 0
  %private.contiguous.address305 = getelementptr i8, ptr %464, i64 %468
  %private.contiguous.load306 = load <8 x float>, ptr %private.contiguous.address305, align 4
  %469 = select <8 x i1> %71, <8 x float> %private.contiguous.load306, <8 x float> zeroinitializer
  %.state307 = load i64, ptr %.slot56, align 4
  %470 = add i64 400, %.state307
  %tile_snapshot.spill.load308 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 0
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 1
  %.splatinsert309 = insertelement <8 x i64> poison, i64 %470, i64 0
  %.splat310 = shufflevector <8 x i64> %.splatinsert309, <8 x i64> poison, <8 x i32> zeroinitializer
  %473 = mul <8 x i64> %.splat310, splat (i64 32)
  %474 = add <8 x i64> %472, %473
  %475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %471, 0
  %476 = insertvalue { <8 x ptr>, <8 x i64> } %475, <8 x i64> %474, 1
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %476, 1
  %479 = extractelement <8 x ptr> %477, i32 0
  %480 = extractelement <8 x i64> %478, i32 0
  %481 = sub i64 %480, 0
  %482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %483 = select i1 %482, i64 %481, i64 0
  %private.contiguous.address311 = getelementptr i8, ptr %479, i64 %483
  %private.contiguous.load312 = load <8 x float>, ptr %private.contiguous.address311, align 4
  %484 = select <8 x i1> %71, <8 x float> %private.contiguous.load312, <8 x float> zeroinitializer
  %485 = fmul <8 x float> %469, %484
  %.state313 = load <8 x float>, ptr %.slot57, align 32
  %486 = fadd <8 x float> %.state313, %485
  %.state314 = load i64, ptr %.slot56, align 4
  %487 = add i64 %.state314, 1
  store i64 %487, ptr %.slot56, align 4
  %488 = load <8 x float>, ptr %.slot57, align 32
  %489 = select <8 x i1> %71, <8 x float> %486, <8 x float> %488
  store <8 x float> %489, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false300
  store i64 0, ptr %.slot58, align 4
  %490 = load <8 x float>, ptr %.slot59, align 32
  %491 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %490
  store <8 x float> %491, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state315 = load i64, ptr %.slot58, align 4
  %492 = icmp slt i64 %.state315, 80
  br i1 %492, label %direct.true316, label %direct.false317

direct.schedule.38:                               ; preds = %direct.true316
  %.state318 = load i64, ptr %.slot58, align 4
  %493 = add i64 0, %.state318
  %tile_snapshot.spill.load319 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load319, 0
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load319, 1
  %.splatinsert320 = insertelement <8 x i64> poison, i64 %493, i64 0
  %.splat321 = shufflevector <8 x i64> %.splatinsert320, <8 x i64> poison, <8 x i32> zeroinitializer
  %496 = mul <8 x i64> %.splat321, splat (i64 32)
  %497 = add <8 x i64> %495, %496
  %498 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %494, 0
  %499 = insertvalue { <8 x ptr>, <8 x i64> } %498, <8 x i64> %497, 1
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %499, 1
  %502 = extractelement <8 x ptr> %500, i32 0
  %503 = extractelement <8 x i64> %501, i32 0
  %504 = sub i64 %503, 0
  %505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %506 = select i1 %505, i64 %504, i64 0
  %private.contiguous.address322 = getelementptr i8, ptr %502, i64 %506
  %private.contiguous.load323 = load <8 x float>, ptr %private.contiguous.address322, align 4
  %507 = select <8 x i1> %71, <8 x float> %private.contiguous.load323, <8 x float> zeroinitializer
  %.state324 = load i64, ptr %.slot58, align 4
  %508 = add i64 480, %.state324
  %tile_snapshot.spill.load325 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load325, 0
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load325, 1
  %.splatinsert326 = insertelement <8 x i64> poison, i64 %508, i64 0
  %.splat327 = shufflevector <8 x i64> %.splatinsert326, <8 x i64> poison, <8 x i32> zeroinitializer
  %511 = mul <8 x i64> %.splat327, splat (i64 32)
  %512 = add <8 x i64> %510, %511
  %513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %509, 0
  %514 = insertvalue { <8 x ptr>, <8 x i64> } %513, <8 x i64> %512, 1
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %514, 1
  %517 = extractelement <8 x ptr> %515, i32 0
  %518 = extractelement <8 x i64> %516, i32 0
  %519 = sub i64 %518, 0
  %520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %521 = select i1 %520, i64 %519, i64 0
  %private.contiguous.address328 = getelementptr i8, ptr %517, i64 %521
  %private.contiguous.load329 = load <8 x float>, ptr %private.contiguous.address328, align 4
  %522 = select <8 x i1> %71, <8 x float> %private.contiguous.load329, <8 x float> zeroinitializer
  %523 = fmul <8 x float> %507, %522
  %.state330 = load <8 x float>, ptr %.slot59, align 32
  %524 = fadd <8 x float> %.state330, %523
  %.state331 = load i64, ptr %.slot58, align 4
  %525 = add i64 %.state331, 1
  store i64 %525, ptr %.slot58, align 4
  %526 = load <8 x float>, ptr %.slot59, align 32
  %527 = select <8 x i1> %71, <8 x float> %524, <8 x float> %526
  store <8 x float> %527, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false317
  store i64 0, ptr %.slot60, align 4
  %528 = load <8 x float>, ptr %.slot61, align 32
  %529 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %528
  store <8 x float> %529, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state332 = load i64, ptr %.slot60, align 4
  %530 = icmp slt i64 %.state332, 80
  br i1 %530, label %direct.true333, label %direct.false334

direct.schedule.41:                               ; preds = %direct.true333
  %.state335 = load i64, ptr %.slot60, align 4
  %531 = add i64 0, %.state335
  %tile_snapshot.spill.load336 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load336, 0
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load336, 1
  %.splatinsert337 = insertelement <8 x i64> poison, i64 %531, i64 0
  %.splat338 = shufflevector <8 x i64> %.splatinsert337, <8 x i64> poison, <8 x i32> zeroinitializer
  %534 = mul <8 x i64> %.splat338, splat (i64 32)
  %535 = add <8 x i64> %533, %534
  %536 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %532, 0
  %537 = insertvalue { <8 x ptr>, <8 x i64> } %536, <8 x i64> %535, 1
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %539 = extractvalue { <8 x ptr>, <8 x i64> } %537, 1
  %540 = extractelement <8 x ptr> %538, i32 0
  %541 = extractelement <8 x i64> %539, i32 0
  %542 = sub i64 %541, 0
  %543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %544 = select i1 %543, i64 %542, i64 0
  %private.contiguous.address339 = getelementptr i8, ptr %540, i64 %544
  %private.contiguous.load340 = load <8 x float>, ptr %private.contiguous.address339, align 4
  %545 = select <8 x i1> %71, <8 x float> %private.contiguous.load340, <8 x float> zeroinitializer
  %.state341 = load i64, ptr %.slot60, align 4
  %546 = add i64 560, %.state341
  %tile_snapshot.spill.load342 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load342, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load342, 1
  %.splatinsert343 = insertelement <8 x i64> poison, i64 %546, i64 0
  %.splat344 = shufflevector <8 x i64> %.splatinsert343, <8 x i64> poison, <8 x i32> zeroinitializer
  %549 = mul <8 x i64> %.splat344, splat (i64 32)
  %550 = add <8 x i64> %548, %549
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %547, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = extractelement <8 x ptr> %553, i32 0
  %556 = extractelement <8 x i64> %554, i32 0
  %557 = sub i64 %556, 0
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %559 = select i1 %558, i64 %557, i64 0
  %private.contiguous.address345 = getelementptr i8, ptr %555, i64 %559
  %private.contiguous.load346 = load <8 x float>, ptr %private.contiguous.address345, align 4
  %560 = select <8 x i1> %71, <8 x float> %private.contiguous.load346, <8 x float> zeroinitializer
  %561 = fmul <8 x float> %545, %560
  %.state347 = load <8 x float>, ptr %.slot61, align 32
  %562 = fadd <8 x float> %.state347, %561
  %.state348 = load i64, ptr %.slot60, align 4
  %563 = add i64 %.state348, 1
  store i64 %563, ptr %.slot60, align 4
  %564 = load <8 x float>, ptr %.slot61, align 32
  %565 = select <8 x i1> %71, <8 x float> %562, <8 x float> %564
  store <8 x float> %565, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false334
  store i64 0, ptr %.slot62, align 4
  %566 = load <8 x float>, ptr %.slot63, align 32
  %567 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %566
  store <8 x float> %567, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state349 = load i64, ptr %.slot62, align 4
  %568 = icmp slt i64 %.state349, 80
  br i1 %568, label %direct.true350, label %direct.false351

direct.schedule.44:                               ; preds = %direct.true350
  %.state352 = load i64, ptr %.slot62, align 4
  %569 = add i64 0, %.state352
  %tile_snapshot.spill.load353 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load353, 0
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load353, 1
  %.splatinsert354 = insertelement <8 x i64> poison, i64 %569, i64 0
  %.splat355 = shufflevector <8 x i64> %.splatinsert354, <8 x i64> poison, <8 x i32> zeroinitializer
  %572 = mul <8 x i64> %.splat355, splat (i64 32)
  %573 = add <8 x i64> %571, %572
  %574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %570, 0
  %575 = insertvalue { <8 x ptr>, <8 x i64> } %574, <8 x i64> %573, 1
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %575, 1
  %578 = extractelement <8 x ptr> %576, i32 0
  %579 = extractelement <8 x i64> %577, i32 0
  %580 = sub i64 %579, 0
  %581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %582 = select i1 %581, i64 %580, i64 0
  %private.contiguous.address356 = getelementptr i8, ptr %578, i64 %582
  %private.contiguous.load357 = load <8 x float>, ptr %private.contiguous.address356, align 4
  %583 = select <8 x i1> %71, <8 x float> %private.contiguous.load357, <8 x float> zeroinitializer
  %.state358 = load i64, ptr %.slot62, align 4
  %584 = add i64 640, %.state358
  %tile_snapshot.spill.load359 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load359, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load359, 1
  %.splatinsert360 = insertelement <8 x i64> poison, i64 %584, i64 0
  %.splat361 = shufflevector <8 x i64> %.splatinsert360, <8 x i64> poison, <8 x i32> zeroinitializer
  %587 = mul <8 x i64> %.splat361, splat (i64 32)
  %588 = add <8 x i64> %586, %587
  %589 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %585, 0
  %590 = insertvalue { <8 x ptr>, <8 x i64> } %589, <8 x i64> %588, 1
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %592 = extractvalue { <8 x ptr>, <8 x i64> } %590, 1
  %593 = extractelement <8 x ptr> %591, i32 0
  %594 = extractelement <8 x i64> %592, i32 0
  %595 = sub i64 %594, 0
  %596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %597 = select i1 %596, i64 %595, i64 0
  %private.contiguous.address362 = getelementptr i8, ptr %593, i64 %597
  %private.contiguous.load363 = load <8 x float>, ptr %private.contiguous.address362, align 4
  %598 = select <8 x i1> %71, <8 x float> %private.contiguous.load363, <8 x float> zeroinitializer
  %599 = fmul <8 x float> %583, %598
  %.state364 = load <8 x float>, ptr %.slot63, align 32
  %600 = fadd <8 x float> %.state364, %599
  %.state365 = load i64, ptr %.slot62, align 4
  %601 = add i64 %.state365, 1
  store i64 %601, ptr %.slot62, align 4
  %602 = load <8 x float>, ptr %.slot63, align 32
  %603 = select <8 x i1> %71, <8 x float> %600, <8 x float> %602
  store <8 x float> %603, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false351
  store i64 0, ptr %.slot64, align 4
  %604 = load <8 x float>, ptr %.slot65, align 32
  %605 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %604
  store <8 x float> %605, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state366 = load i64, ptr %.slot64, align 4
  %606 = icmp slt i64 %.state366, 80
  br i1 %606, label %direct.true367, label %direct.false368

direct.schedule.47:                               ; preds = %direct.true367
  %.state369 = load i64, ptr %.slot64, align 4
  %607 = add i64 0, %.state369
  %tile_snapshot.spill.load370 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load370, 0
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load370, 1
  %.splatinsert371 = insertelement <8 x i64> poison, i64 %607, i64 0
  %.splat372 = shufflevector <8 x i64> %.splatinsert371, <8 x i64> poison, <8 x i32> zeroinitializer
  %610 = mul <8 x i64> %.splat372, splat (i64 32)
  %611 = add <8 x i64> %609, %610
  %612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %608, 0
  %613 = insertvalue { <8 x ptr>, <8 x i64> } %612, <8 x i64> %611, 1
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %613, 1
  %616 = extractelement <8 x ptr> %614, i32 0
  %617 = extractelement <8 x i64> %615, i32 0
  %618 = sub i64 %617, 0
  %619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %620 = select i1 %619, i64 %618, i64 0
  %private.contiguous.address373 = getelementptr i8, ptr %616, i64 %620
  %private.contiguous.load374 = load <8 x float>, ptr %private.contiguous.address373, align 4
  %621 = select <8 x i1> %71, <8 x float> %private.contiguous.load374, <8 x float> zeroinitializer
  %.state375 = load i64, ptr %.slot64, align 4
  %622 = add i64 720, %.state375
  %tile_snapshot.spill.load376 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %623 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load376, 0
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load376, 1
  %.splatinsert377 = insertelement <8 x i64> poison, i64 %622, i64 0
  %.splat378 = shufflevector <8 x i64> %.splatinsert377, <8 x i64> poison, <8 x i32> zeroinitializer
  %625 = mul <8 x i64> %.splat378, splat (i64 32)
  %626 = add <8 x i64> %624, %625
  %627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %623, 0
  %628 = insertvalue { <8 x ptr>, <8 x i64> } %627, <8 x i64> %626, 1
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %628, 1
  %631 = extractelement <8 x ptr> %629, i32 0
  %632 = extractelement <8 x i64> %630, i32 0
  %633 = sub i64 %632, 0
  %634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %635 = select i1 %634, i64 %633, i64 0
  %private.contiguous.address379 = getelementptr i8, ptr %631, i64 %635
  %private.contiguous.load380 = load <8 x float>, ptr %private.contiguous.address379, align 4
  %636 = select <8 x i1> %71, <8 x float> %private.contiguous.load380, <8 x float> zeroinitializer
  %637 = fmul <8 x float> %621, %636
  %.state381 = load <8 x float>, ptr %.slot65, align 32
  %638 = fadd <8 x float> %.state381, %637
  %.state382 = load i64, ptr %.slot64, align 4
  %639 = add i64 %.state382, 1
  store i64 %639, ptr %.slot64, align 4
  %640 = load <8 x float>, ptr %.slot65, align 32
  %641 = select <8 x i1> %71, <8 x float> %638, <8 x float> %640
  store <8 x float> %641, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false368
  store i64 0, ptr %.slot66, align 4
  %642 = load <8 x float>, ptr %.slot67, align 32
  %643 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %642
  store <8 x float> %643, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state383 = load i64, ptr %.slot66, align 4
  %644 = icmp slt i64 %.state383, 80
  br i1 %644, label %direct.true384, label %direct.false385

direct.schedule.50:                               ; preds = %direct.true384
  %.state386 = load i64, ptr %.slot66, align 4
  %645 = add i64 0, %.state386
  %tile_snapshot.spill.load387 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load387, 0
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load387, 1
  %.splatinsert388 = insertelement <8 x i64> poison, i64 %645, i64 0
  %.splat389 = shufflevector <8 x i64> %.splatinsert388, <8 x i64> poison, <8 x i32> zeroinitializer
  %648 = mul <8 x i64> %.splat389, splat (i64 32)
  %649 = add <8 x i64> %647, %648
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %646, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = extractelement <8 x ptr> %652, i32 0
  %655 = extractelement <8 x i64> %653, i32 0
  %656 = sub i64 %655, 0
  %657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %658 = select i1 %657, i64 %656, i64 0
  %private.contiguous.address390 = getelementptr i8, ptr %654, i64 %658
  %private.contiguous.load391 = load <8 x float>, ptr %private.contiguous.address390, align 4
  %659 = select <8 x i1> %71, <8 x float> %private.contiguous.load391, <8 x float> zeroinitializer
  %.state392 = load i64, ptr %.slot66, align 4
  %660 = add i64 800, %.state392
  %tile_snapshot.spill.load393 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load393, 0
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load393, 1
  %.splatinsert394 = insertelement <8 x i64> poison, i64 %660, i64 0
  %.splat395 = shufflevector <8 x i64> %.splatinsert394, <8 x i64> poison, <8 x i32> zeroinitializer
  %663 = mul <8 x i64> %.splat395, splat (i64 32)
  %664 = add <8 x i64> %662, %663
  %665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %661, 0
  %666 = insertvalue { <8 x ptr>, <8 x i64> } %665, <8 x i64> %664, 1
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %666, 1
  %669 = extractelement <8 x ptr> %667, i32 0
  %670 = extractelement <8 x i64> %668, i32 0
  %671 = sub i64 %670, 0
  %672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %673 = select i1 %672, i64 %671, i64 0
  %private.contiguous.address396 = getelementptr i8, ptr %669, i64 %673
  %private.contiguous.load397 = load <8 x float>, ptr %private.contiguous.address396, align 4
  %674 = select <8 x i1> %71, <8 x float> %private.contiguous.load397, <8 x float> zeroinitializer
  %675 = fmul <8 x float> %659, %674
  %.state398 = load <8 x float>, ptr %.slot67, align 32
  %676 = fadd <8 x float> %.state398, %675
  %.state399 = load i64, ptr %.slot66, align 4
  %677 = add i64 %.state399, 1
  store i64 %677, ptr %.slot66, align 4
  %678 = load <8 x float>, ptr %.slot67, align 32
  %679 = select <8 x i1> %71, <8 x float> %676, <8 x float> %678
  store <8 x float> %679, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false385
  store i64 0, ptr %.slot68, align 4
  %680 = load <8 x float>, ptr %.slot69, align 32
  %681 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %680
  store <8 x float> %681, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state400 = load i64, ptr %.slot68, align 4
  %682 = icmp slt i64 %.state400, 80
  br i1 %682, label %direct.true401, label %direct.false402

direct.schedule.53:                               ; preds = %direct.true401
  %.state403 = load i64, ptr %.slot68, align 4
  %683 = add i64 0, %.state403
  %tile_snapshot.spill.load404 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load404, 0
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load404, 1
  %.splatinsert405 = insertelement <8 x i64> poison, i64 %683, i64 0
  %.splat406 = shufflevector <8 x i64> %.splatinsert405, <8 x i64> poison, <8 x i32> zeroinitializer
  %686 = mul <8 x i64> %.splat406, splat (i64 32)
  %687 = add <8 x i64> %685, %686
  %688 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %684, 0
  %689 = insertvalue { <8 x ptr>, <8 x i64> } %688, <8 x i64> %687, 1
  %690 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %689, 1
  %692 = extractelement <8 x ptr> %690, i32 0
  %693 = extractelement <8 x i64> %691, i32 0
  %694 = sub i64 %693, 0
  %695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %696 = select i1 %695, i64 %694, i64 0
  %private.contiguous.address407 = getelementptr i8, ptr %692, i64 %696
  %private.contiguous.load408 = load <8 x float>, ptr %private.contiguous.address407, align 4
  %697 = select <8 x i1> %71, <8 x float> %private.contiguous.load408, <8 x float> zeroinitializer
  %.state409 = load i64, ptr %.slot68, align 4
  %698 = add i64 880, %.state409
  %tile_snapshot.spill.load410 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %700 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %.splatinsert411 = insertelement <8 x i64> poison, i64 %698, i64 0
  %.splat412 = shufflevector <8 x i64> %.splatinsert411, <8 x i64> poison, <8 x i32> zeroinitializer
  %701 = mul <8 x i64> %.splat412, splat (i64 32)
  %702 = add <8 x i64> %700, %701
  %703 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %699, 0
  %704 = insertvalue { <8 x ptr>, <8 x i64> } %703, <8 x i64> %702, 1
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %706 = extractvalue { <8 x ptr>, <8 x i64> } %704, 1
  %707 = extractelement <8 x ptr> %705, i32 0
  %708 = extractelement <8 x i64> %706, i32 0
  %709 = sub i64 %708, 0
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %711 = select i1 %710, i64 %709, i64 0
  %private.contiguous.address413 = getelementptr i8, ptr %707, i64 %711
  %private.contiguous.load414 = load <8 x float>, ptr %private.contiguous.address413, align 4
  %712 = select <8 x i1> %71, <8 x float> %private.contiguous.load414, <8 x float> zeroinitializer
  %713 = fmul <8 x float> %697, %712
  %.state415 = load <8 x float>, ptr %.slot69, align 32
  %714 = fadd <8 x float> %.state415, %713
  %.state416 = load i64, ptr %.slot68, align 4
  %715 = add i64 %.state416, 1
  store i64 %715, ptr %.slot68, align 4
  %716 = load <8 x float>, ptr %.slot69, align 32
  %717 = select <8 x i1> %71, <8 x float> %714, <8 x float> %716
  store <8 x float> %717, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false402
  store i64 0, ptr %.slot70, align 4
  %718 = load <8 x float>, ptr %.slot71, align 32
  %719 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %718
  store <8 x float> %719, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state417 = load i64, ptr %.slot70, align 4
  %720 = icmp slt i64 %.state417, 80
  br i1 %720, label %direct.true418, label %direct.false419

direct.schedule.56:                               ; preds = %direct.true418
  %.state420 = load i64, ptr %.slot70, align 4
  %721 = add i64 0, %.state420
  %tile_snapshot.spill.load421 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load421, 0
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load421, 1
  %.splatinsert422 = insertelement <8 x i64> poison, i64 %721, i64 0
  %.splat423 = shufflevector <8 x i64> %.splatinsert422, <8 x i64> poison, <8 x i32> zeroinitializer
  %724 = mul <8 x i64> %.splat423, splat (i64 32)
  %725 = add <8 x i64> %723, %724
  %726 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %722, 0
  %727 = insertvalue { <8 x ptr>, <8 x i64> } %726, <8 x i64> %725, 1
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %727, 1
  %730 = extractelement <8 x ptr> %728, i32 0
  %731 = extractelement <8 x i64> %729, i32 0
  %732 = sub i64 %731, 0
  %733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %734 = select i1 %733, i64 %732, i64 0
  %private.contiguous.address424 = getelementptr i8, ptr %730, i64 %734
  %private.contiguous.load425 = load <8 x float>, ptr %private.contiguous.address424, align 4
  %735 = select <8 x i1> %71, <8 x float> %private.contiguous.load425, <8 x float> zeroinitializer
  %.state426 = load i64, ptr %.slot70, align 4
  %736 = add i64 960, %.state426
  %tile_snapshot.spill.load427 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load427, 0
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load427, 1
  %.splatinsert428 = insertelement <8 x i64> poison, i64 %736, i64 0
  %.splat429 = shufflevector <8 x i64> %.splatinsert428, <8 x i64> poison, <8 x i32> zeroinitializer
  %739 = mul <8 x i64> %.splat429, splat (i64 32)
  %740 = add <8 x i64> %738, %739
  %741 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %737, 0
  %742 = insertvalue { <8 x ptr>, <8 x i64> } %741, <8 x i64> %740, 1
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %742, 1
  %745 = extractelement <8 x ptr> %743, i32 0
  %746 = extractelement <8 x i64> %744, i32 0
  %747 = sub i64 %746, 0
  %748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %749 = select i1 %748, i64 %747, i64 0
  %private.contiguous.address430 = getelementptr i8, ptr %745, i64 %749
  %private.contiguous.load431 = load <8 x float>, ptr %private.contiguous.address430, align 4
  %750 = select <8 x i1> %71, <8 x float> %private.contiguous.load431, <8 x float> zeroinitializer
  %751 = fmul <8 x float> %735, %750
  %.state432 = load <8 x float>, ptr %.slot71, align 32
  %752 = fadd <8 x float> %.state432, %751
  %.state433 = load i64, ptr %.slot70, align 4
  %753 = add i64 %.state433, 1
  store i64 %753, ptr %.slot70, align 4
  %754 = load <8 x float>, ptr %.slot71, align 32
  %755 = select <8 x i1> %71, <8 x float> %752, <8 x float> %754
  store <8 x float> %755, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false419
  store i64 0, ptr %.slot72, align 4
  %756 = load <8 x float>, ptr %.slot73, align 32
  %757 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %756
  store <8 x float> %757, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state434 = load i64, ptr %.slot72, align 4
  %758 = icmp slt i64 %.state434, 80
  br i1 %758, label %direct.true435, label %direct.false436

direct.schedule.59:                               ; preds = %direct.true435
  %.state437 = load i64, ptr %.slot72, align 4
  %759 = add i64 0, %.state437
  %tile_snapshot.spill.load438 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load438, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load438, 1
  %.splatinsert439 = insertelement <8 x i64> poison, i64 %759, i64 0
  %.splat440 = shufflevector <8 x i64> %.splatinsert439, <8 x i64> poison, <8 x i32> zeroinitializer
  %762 = mul <8 x i64> %.splat440, splat (i64 32)
  %763 = add <8 x i64> %761, %762
  %764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %760, 0
  %765 = insertvalue { <8 x ptr>, <8 x i64> } %764, <8 x i64> %763, 1
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %765, 1
  %768 = extractelement <8 x ptr> %766, i32 0
  %769 = extractelement <8 x i64> %767, i32 0
  %770 = sub i64 %769, 0
  %771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %772 = select i1 %771, i64 %770, i64 0
  %private.contiguous.address441 = getelementptr i8, ptr %768, i64 %772
  %private.contiguous.load442 = load <8 x float>, ptr %private.contiguous.address441, align 4
  %773 = select <8 x i1> %71, <8 x float> %private.contiguous.load442, <8 x float> zeroinitializer
  %.state443 = load i64, ptr %.slot72, align 4
  %774 = add i64 1040, %.state443
  %tile_snapshot.spill.load444 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load444, 0
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load444, 1
  %.splatinsert445 = insertelement <8 x i64> poison, i64 %774, i64 0
  %.splat446 = shufflevector <8 x i64> %.splatinsert445, <8 x i64> poison, <8 x i32> zeroinitializer
  %777 = mul <8 x i64> %.splat446, splat (i64 32)
  %778 = add <8 x i64> %776, %777
  %779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %775, 0
  %780 = insertvalue { <8 x ptr>, <8 x i64> } %779, <8 x i64> %778, 1
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %780, 1
  %783 = extractelement <8 x ptr> %781, i32 0
  %784 = extractelement <8 x i64> %782, i32 0
  %785 = sub i64 %784, 0
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %787 = select i1 %786, i64 %785, i64 0
  %private.contiguous.address447 = getelementptr i8, ptr %783, i64 %787
  %private.contiguous.load448 = load <8 x float>, ptr %private.contiguous.address447, align 4
  %788 = select <8 x i1> %71, <8 x float> %private.contiguous.load448, <8 x float> zeroinitializer
  %789 = fmul <8 x float> %773, %788
  %.state449 = load <8 x float>, ptr %.slot73, align 32
  %790 = fadd <8 x float> %.state449, %789
  %.state450 = load i64, ptr %.slot72, align 4
  %791 = add i64 %.state450, 1
  store i64 %791, ptr %.slot72, align 4
  %792 = load <8 x float>, ptr %.slot73, align 32
  %793 = select <8 x i1> %71, <8 x float> %790, <8 x float> %792
  store <8 x float> %793, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false436
  store i64 0, ptr %.slot74, align 4
  %794 = load <8 x float>, ptr %.slot75, align 32
  %795 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %794
  store <8 x float> %795, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state451 = load i64, ptr %.slot74, align 4
  %796 = icmp slt i64 %.state451, 80
  br i1 %796, label %direct.true452, label %direct.false453

direct.schedule.62:                               ; preds = %direct.true452
  %.state454 = load i64, ptr %.slot74, align 4
  %797 = add i64 0, %.state454
  %tile_snapshot.spill.load455 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %.splatinsert456 = insertelement <8 x i64> poison, i64 %797, i64 0
  %.splat457 = shufflevector <8 x i64> %.splatinsert456, <8 x i64> poison, <8 x i32> zeroinitializer
  %800 = mul <8 x i64> %.splat457, splat (i64 32)
  %801 = add <8 x i64> %799, %800
  %802 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %798, 0
  %803 = insertvalue { <8 x ptr>, <8 x i64> } %802, <8 x i64> %801, 1
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %805 = extractvalue { <8 x ptr>, <8 x i64> } %803, 1
  %806 = extractelement <8 x ptr> %804, i32 0
  %807 = extractelement <8 x i64> %805, i32 0
  %808 = sub i64 %807, 0
  %809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %810 = select i1 %809, i64 %808, i64 0
  %private.contiguous.address458 = getelementptr i8, ptr %806, i64 %810
  %private.contiguous.load459 = load <8 x float>, ptr %private.contiguous.address458, align 4
  %811 = select <8 x i1> %71, <8 x float> %private.contiguous.load459, <8 x float> zeroinitializer
  %.state460 = load i64, ptr %.slot74, align 4
  %812 = add i64 1120, %.state460
  %tile_snapshot.spill.load461 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load461, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load461, 1
  %.splatinsert462 = insertelement <8 x i64> poison, i64 %812, i64 0
  %.splat463 = shufflevector <8 x i64> %.splatinsert462, <8 x i64> poison, <8 x i32> zeroinitializer
  %815 = mul <8 x i64> %.splat463, splat (i64 32)
  %816 = add <8 x i64> %814, %815
  %817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %813, 0
  %818 = insertvalue { <8 x ptr>, <8 x i64> } %817, <8 x i64> %816, 1
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %818, 1
  %821 = extractelement <8 x ptr> %819, i32 0
  %822 = extractelement <8 x i64> %820, i32 0
  %823 = sub i64 %822, 0
  %824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %825 = select i1 %824, i64 %823, i64 0
  %private.contiguous.address464 = getelementptr i8, ptr %821, i64 %825
  %private.contiguous.load465 = load <8 x float>, ptr %private.contiguous.address464, align 4
  %826 = select <8 x i1> %71, <8 x float> %private.contiguous.load465, <8 x float> zeroinitializer
  %827 = fmul <8 x float> %811, %826
  %.state466 = load <8 x float>, ptr %.slot75, align 32
  %828 = fadd <8 x float> %.state466, %827
  %.state467 = load i64, ptr %.slot74, align 4
  %829 = add i64 %.state467, 1
  store i64 %829, ptr %.slot74, align 4
  %830 = load <8 x float>, ptr %.slot75, align 32
  %831 = select <8 x i1> %71, <8 x float> %828, <8 x float> %830
  store <8 x float> %831, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false453
  store i64 0, ptr %.slot76, align 4
  %832 = load <8 x float>, ptr %.slot77, align 32
  %833 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %832
  store <8 x float> %833, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state468 = load i64, ptr %.slot76, align 4
  %834 = icmp slt i64 %.state468, 80
  br i1 %834, label %direct.true469, label %direct.false470

direct.schedule.65:                               ; preds = %direct.true469
  %.state471 = load i64, ptr %.slot76, align 4
  %835 = add i64 0, %.state471
  %tile_snapshot.spill.load472 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load472, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load472, 1
  %.splatinsert473 = insertelement <8 x i64> poison, i64 %835, i64 0
  %.splat474 = shufflevector <8 x i64> %.splatinsert473, <8 x i64> poison, <8 x i32> zeroinitializer
  %838 = mul <8 x i64> %.splat474, splat (i64 32)
  %839 = add <8 x i64> %837, %838
  %840 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %836, 0
  %841 = insertvalue { <8 x ptr>, <8 x i64> } %840, <8 x i64> %839, 1
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %841, 1
  %844 = extractelement <8 x ptr> %842, i32 0
  %845 = extractelement <8 x i64> %843, i32 0
  %846 = sub i64 %845, 0
  %847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %848 = select i1 %847, i64 %846, i64 0
  %private.contiguous.address475 = getelementptr i8, ptr %844, i64 %848
  %private.contiguous.load476 = load <8 x float>, ptr %private.contiguous.address475, align 4
  %849 = select <8 x i1> %71, <8 x float> %private.contiguous.load476, <8 x float> zeroinitializer
  %.state477 = load i64, ptr %.slot76, align 4
  %850 = add i64 1200, %.state477
  %tile_snapshot.spill.load478 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 0
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 1
  %.splatinsert479 = insertelement <8 x i64> poison, i64 %850, i64 0
  %.splat480 = shufflevector <8 x i64> %.splatinsert479, <8 x i64> poison, <8 x i32> zeroinitializer
  %853 = mul <8 x i64> %.splat480, splat (i64 32)
  %854 = add <8 x i64> %852, %853
  %855 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %851, 0
  %856 = insertvalue { <8 x ptr>, <8 x i64> } %855, <8 x i64> %854, 1
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %856, 1
  %859 = extractelement <8 x ptr> %857, i32 0
  %860 = extractelement <8 x i64> %858, i32 0
  %861 = sub i64 %860, 0
  %862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %863 = select i1 %862, i64 %861, i64 0
  %private.contiguous.address481 = getelementptr i8, ptr %859, i64 %863
  %private.contiguous.load482 = load <8 x float>, ptr %private.contiguous.address481, align 4
  %864 = select <8 x i1> %71, <8 x float> %private.contiguous.load482, <8 x float> zeroinitializer
  %865 = fmul <8 x float> %849, %864
  %.state483 = load <8 x float>, ptr %.slot77, align 32
  %866 = fadd <8 x float> %.state483, %865
  %.state484 = load i64, ptr %.slot76, align 4
  %867 = add i64 %.state484, 1
  store i64 %867, ptr %.slot76, align 4
  %868 = load <8 x float>, ptr %.slot77, align 32
  %869 = select <8 x i1> %71, <8 x float> %866, <8 x float> %868
  store <8 x float> %869, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false470
  %.state485 = load <8 x float>, ptr %.slot47, align 32
  %870 = fmul <8 x float> %.state485, splat (float 0x3FBC9F25C0000000)
  %.state486 = load <8 x float>, ptr %.slot49, align 32
  %871 = fmul <8 x float> %.state486, splat (float 0x3FBC9F25C0000000)
  %.state487 = load <8 x float>, ptr %.slot51, align 32
  %872 = fmul <8 x float> %.state487, splat (float 0x3FBC9F25C0000000)
  %.state488 = load <8 x float>, ptr %.slot53, align 32
  %873 = fmul <8 x float> %.state488, splat (float 0x3FBC9F25C0000000)
  %.state489 = load <8 x float>, ptr %.slot55, align 32
  %874 = fmul <8 x float> %.state489, splat (float 0x3FBC9F25C0000000)
  %.state490 = load <8 x float>, ptr %.slot57, align 32
  %875 = fmul <8 x float> %.state490, splat (float 0x3FBC9F25C0000000)
  %.state491 = load <8 x float>, ptr %.slot59, align 32
  %876 = fmul <8 x float> %.state491, splat (float 0x3FBC9F25C0000000)
  %.state492 = load <8 x float>, ptr %.slot61, align 32
  %877 = fmul <8 x float> %.state492, splat (float 0x3FBC9F25C0000000)
  %.state493 = load <8 x float>, ptr %.slot63, align 32
  %878 = fmul <8 x float> %.state493, splat (float 0x3FBC9F25C0000000)
  %.state494 = load <8 x float>, ptr %.slot65, align 32
  %879 = fmul <8 x float> %.state494, splat (float 0x3FBC9F25C0000000)
  %.state495 = load <8 x float>, ptr %.slot67, align 32
  %880 = fmul <8 x float> %.state495, splat (float 0x3FBC9F25C0000000)
  %.state496 = load <8 x float>, ptr %.slot69, align 32
  %881 = fmul <8 x float> %.state496, splat (float 0x3FBC9F25C0000000)
  %.state497 = load <8 x float>, ptr %.slot71, align 32
  %882 = fmul <8 x float> %.state497, splat (float 0x3FBC9F25C0000000)
  %.state498 = load <8 x float>, ptr %.slot73, align 32
  %883 = fmul <8 x float> %.state498, splat (float 0x3FBC9F25C0000000)
  %.state499 = load <8 x float>, ptr %.slot75, align 32
  %884 = fmul <8 x float> %.state499, splat (float 0x3FBC9F25C0000000)
  %.state500 = load <8 x float>, ptr %.slot77, align 32
  %885 = fmul <8 x float> %.state500, splat (float 0x3FBC9F25C0000000)
  %.spill.load501 = load i64, ptr %.spill37, align 4
  %886 = add i64 0, %.spill.load501
  %.spill.load502 = load i64, ptr %.spill37, align 4
  %887 = add i64 1, %.spill.load502
  %.spill.load503 = load i64, ptr %.spill37, align 4
  %888 = add i64 2, %.spill.load503
  %.spill.load504 = load i64, ptr %.spill37, align 4
  %889 = add i64 3, %.spill.load504
  %.spill.load505 = load i64, ptr %.spill37, align 4
  %890 = add i64 4, %.spill.load505
  %.spill.load506 = load i64, ptr %.spill37, align 4
  %891 = add i64 5, %.spill.load506
  %.spill.load507 = load i64, ptr %.spill37, align 4
  %892 = add i64 6, %.spill.load507
  %.spill.load508 = load i64, ptr %.spill37, align 4
  %893 = add i64 7, %.spill.load508
  %.spill.load509 = load i64, ptr %.spill37, align 4
  %894 = add i64 8, %.spill.load509
  %.spill.load510 = load i64, ptr %.spill37, align 4
  %895 = add i64 9, %.spill.load510
  %.spill.load511 = load i64, ptr %.spill37, align 4
  %896 = add i64 10, %.spill.load511
  %.spill.load512 = load i64, ptr %.spill37, align 4
  %897 = add i64 11, %.spill.load512
  %.spill.load513 = load i64, ptr %.spill37, align 4
  %898 = add i64 12, %.spill.load513
  %.spill.load514 = load i64, ptr %.spill37, align 4
  %899 = add i64 13, %.spill.load514
  %.spill.load515 = load i64, ptr %.spill37, align 4
  %900 = add i64 14, %.spill.load515
  %.spill.load516 = load i64, ptr %.spill37, align 4
  %901 = add i64 15, %.spill.load516
  %902 = icmp slt i64 %886, 2053
  %903 = icmp slt i64 %887, 2053
  %904 = icmp slt i64 %888, 2053
  %905 = icmp slt i64 %889, 2053
  %906 = icmp slt i64 %890, 2053
  %907 = icmp slt i64 %891, 2053
  %908 = icmp slt i64 %892, 2053
  %909 = icmp slt i64 %893, 2053
  %910 = icmp slt i64 %894, 2053
  %911 = icmp slt i64 %895, 2053
  %912 = icmp slt i64 %896, 2053
  %913 = icmp slt i64 %897, 2053
  %914 = icmp slt i64 %898, 2053
  %915 = icmp slt i64 %899, 2053
  %916 = icmp slt i64 %900, 2053
  %917 = icmp slt i64 %901, 2053
  %.spill.load517 = load i64, ptr %.spill29, align 4
  %918 = add i64 0, %.spill.load517
  store i64 %918, ptr %.spill78, align 4
  %919 = add i64 %918, 2053
  %920 = sub i64 %919, 1
  %921 = icmp sle i64 %886, %920
  %922 = icmp sle i64 %887, %920
  %923 = icmp sle i64 %888, %920
  %924 = icmp sle i64 %889, %920
  %925 = icmp sle i64 %890, %920
  %926 = icmp sle i64 %891, %920
  %927 = icmp sle i64 %892, %920
  %928 = icmp sle i64 %893, %920
  %929 = icmp sle i64 %894, %920
  %930 = icmp sle i64 %895, %920
  %931 = icmp sle i64 %896, %920
  %932 = icmp sle i64 %897, %920
  %933 = icmp sle i64 %898, %920
  %934 = icmp sle i64 %899, %920
  %935 = icmp sle i64 %900, %920
  %936 = icmp sle i64 %901, %920
  %937 = and i1 %902, %921
  store i1 %937, ptr %.spill79, align 1
  %938 = and i1 %903, %922
  store i1 %938, ptr %.spill80, align 1
  %939 = and i1 %904, %923
  store i1 %939, ptr %.spill81, align 1
  %940 = and i1 %905, %924
  store i1 %940, ptr %.spill82, align 1
  %941 = and i1 %906, %925
  store i1 %941, ptr %.spill83, align 1
  %942 = and i1 %907, %926
  store i1 %942, ptr %.spill84, align 1
  %943 = and i1 %908, %927
  store i1 %943, ptr %.spill85, align 1
  %944 = and i1 %909, %928
  store i1 %944, ptr %.spill86, align 1
  %945 = and i1 %910, %929
  store i1 %945, ptr %.spill87, align 1
  %946 = and i1 %911, %930
  store i1 %946, ptr %.spill88, align 1
  %947 = and i1 %912, %931
  store i1 %947, ptr %.spill89, align 1
  %948 = and i1 %913, %932
  store i1 %948, ptr %.spill90, align 1
  %949 = and i1 %914, %933
  store i1 %949, ptr %.spill91, align 1
  %950 = and i1 %915, %934
  store i1 %950, ptr %.spill92, align 1
  %951 = and i1 %916, %935
  store i1 %951, ptr %.spill93, align 1
  %952 = and i1 %917, %936
  store i1 %952, ptr %.spill94, align 1
  %.splatinsert518 = insertelement <8 x i1> poison, i1 %937, i64 0
  %.splat519 = shufflevector <8 x i1> %.splatinsert518, <8 x i1> poison, <8 x i32> zeroinitializer
  %953 = select <8 x i1> %.splat519, <8 x float> %870, <8 x float> splat (float 0xC6293E5940000000)
  %954 = load <8 x float>, ptr %.spill95, align 32
  %955 = select <8 x i1> %71, <8 x float> %953, <8 x float> %954
  store <8 x float> %955, ptr %.spill95, align 32
  %.splatinsert520 = insertelement <8 x i1> poison, i1 %938, i64 0
  %.splat521 = shufflevector <8 x i1> %.splatinsert520, <8 x i1> poison, <8 x i32> zeroinitializer
  %956 = select <8 x i1> %.splat521, <8 x float> %871, <8 x float> splat (float 0xC6293E5940000000)
  %957 = load <8 x float>, ptr %.spill96, align 32
  %958 = select <8 x i1> %71, <8 x float> %956, <8 x float> %957
  store <8 x float> %958, ptr %.spill96, align 32
  %.splatinsert522 = insertelement <8 x i1> poison, i1 %939, i64 0
  %.splat523 = shufflevector <8 x i1> %.splatinsert522, <8 x i1> poison, <8 x i32> zeroinitializer
  %959 = select <8 x i1> %.splat523, <8 x float> %872, <8 x float> splat (float 0xC6293E5940000000)
  %960 = load <8 x float>, ptr %.spill97, align 32
  %961 = select <8 x i1> %71, <8 x float> %959, <8 x float> %960
  store <8 x float> %961, ptr %.spill97, align 32
  %.splatinsert524 = insertelement <8 x i1> poison, i1 %940, i64 0
  %.splat525 = shufflevector <8 x i1> %.splatinsert524, <8 x i1> poison, <8 x i32> zeroinitializer
  %962 = select <8 x i1> %.splat525, <8 x float> %873, <8 x float> splat (float 0xC6293E5940000000)
  %963 = load <8 x float>, ptr %.spill98, align 32
  %964 = select <8 x i1> %71, <8 x float> %962, <8 x float> %963
  store <8 x float> %964, ptr %.spill98, align 32
  %.splatinsert526 = insertelement <8 x i1> poison, i1 %941, i64 0
  %.splat527 = shufflevector <8 x i1> %.splatinsert526, <8 x i1> poison, <8 x i32> zeroinitializer
  %965 = select <8 x i1> %.splat527, <8 x float> %874, <8 x float> splat (float 0xC6293E5940000000)
  %966 = load <8 x float>, ptr %.spill99, align 32
  %967 = select <8 x i1> %71, <8 x float> %965, <8 x float> %966
  store <8 x float> %967, ptr %.spill99, align 32
  %.splatinsert528 = insertelement <8 x i1> poison, i1 %942, i64 0
  %.splat529 = shufflevector <8 x i1> %.splatinsert528, <8 x i1> poison, <8 x i32> zeroinitializer
  %968 = select <8 x i1> %.splat529, <8 x float> %875, <8 x float> splat (float 0xC6293E5940000000)
  %969 = load <8 x float>, ptr %.spill100, align 32
  %970 = select <8 x i1> %71, <8 x float> %968, <8 x float> %969
  store <8 x float> %970, ptr %.spill100, align 32
  %.splatinsert530 = insertelement <8 x i1> poison, i1 %943, i64 0
  %.splat531 = shufflevector <8 x i1> %.splatinsert530, <8 x i1> poison, <8 x i32> zeroinitializer
  %971 = select <8 x i1> %.splat531, <8 x float> %876, <8 x float> splat (float 0xC6293E5940000000)
  %972 = load <8 x float>, ptr %.spill101, align 32
  %973 = select <8 x i1> %71, <8 x float> %971, <8 x float> %972
  store <8 x float> %973, ptr %.spill101, align 32
  %.splatinsert532 = insertelement <8 x i1> poison, i1 %944, i64 0
  %.splat533 = shufflevector <8 x i1> %.splatinsert532, <8 x i1> poison, <8 x i32> zeroinitializer
  %974 = select <8 x i1> %.splat533, <8 x float> %877, <8 x float> splat (float 0xC6293E5940000000)
  %975 = load <8 x float>, ptr %.spill102, align 32
  %976 = select <8 x i1> %71, <8 x float> %974, <8 x float> %975
  store <8 x float> %976, ptr %.spill102, align 32
  %.splatinsert534 = insertelement <8 x i1> poison, i1 %945, i64 0
  %.splat535 = shufflevector <8 x i1> %.splatinsert534, <8 x i1> poison, <8 x i32> zeroinitializer
  %977 = select <8 x i1> %.splat535, <8 x float> %878, <8 x float> splat (float 0xC6293E5940000000)
  %978 = load <8 x float>, ptr %.spill103, align 32
  %979 = select <8 x i1> %71, <8 x float> %977, <8 x float> %978
  store <8 x float> %979, ptr %.spill103, align 32
  %.splatinsert536 = insertelement <8 x i1> poison, i1 %946, i64 0
  %.splat537 = shufflevector <8 x i1> %.splatinsert536, <8 x i1> poison, <8 x i32> zeroinitializer
  %980 = select <8 x i1> %.splat537, <8 x float> %879, <8 x float> splat (float 0xC6293E5940000000)
  %981 = load <8 x float>, ptr %.spill104, align 32
  %982 = select <8 x i1> %71, <8 x float> %980, <8 x float> %981
  store <8 x float> %982, ptr %.spill104, align 32
  %.splatinsert538 = insertelement <8 x i1> poison, i1 %947, i64 0
  %.splat539 = shufflevector <8 x i1> %.splatinsert538, <8 x i1> poison, <8 x i32> zeroinitializer
  %983 = select <8 x i1> %.splat539, <8 x float> %880, <8 x float> splat (float 0xC6293E5940000000)
  %984 = load <8 x float>, ptr %.spill105, align 32
  %985 = select <8 x i1> %71, <8 x float> %983, <8 x float> %984
  store <8 x float> %985, ptr %.spill105, align 32
  %.splatinsert540 = insertelement <8 x i1> poison, i1 %948, i64 0
  %.splat541 = shufflevector <8 x i1> %.splatinsert540, <8 x i1> poison, <8 x i32> zeroinitializer
  %986 = select <8 x i1> %.splat541, <8 x float> %881, <8 x float> splat (float 0xC6293E5940000000)
  %987 = load <8 x float>, ptr %.spill106, align 32
  %988 = select <8 x i1> %71, <8 x float> %986, <8 x float> %987
  store <8 x float> %988, ptr %.spill106, align 32
  %.splatinsert542 = insertelement <8 x i1> poison, i1 %949, i64 0
  %.splat543 = shufflevector <8 x i1> %.splatinsert542, <8 x i1> poison, <8 x i32> zeroinitializer
  %989 = select <8 x i1> %.splat543, <8 x float> %882, <8 x float> splat (float 0xC6293E5940000000)
  %990 = load <8 x float>, ptr %.spill107, align 32
  %991 = select <8 x i1> %71, <8 x float> %989, <8 x float> %990
  store <8 x float> %991, ptr %.spill107, align 32
  %.splatinsert544 = insertelement <8 x i1> poison, i1 %950, i64 0
  %.splat545 = shufflevector <8 x i1> %.splatinsert544, <8 x i1> poison, <8 x i32> zeroinitializer
  %992 = select <8 x i1> %.splat545, <8 x float> %883, <8 x float> splat (float 0xC6293E5940000000)
  %993 = load <8 x float>, ptr %.spill108, align 32
  %994 = select <8 x i1> %71, <8 x float> %992, <8 x float> %993
  store <8 x float> %994, ptr %.spill108, align 32
  %.splatinsert546 = insertelement <8 x i1> poison, i1 %951, i64 0
  %.splat547 = shufflevector <8 x i1> %.splatinsert546, <8 x i1> poison, <8 x i32> zeroinitializer
  %995 = select <8 x i1> %.splat547, <8 x float> %884, <8 x float> splat (float 0xC6293E5940000000)
  %996 = load <8 x float>, ptr %.spill109, align 32
  %997 = select <8 x i1> %71, <8 x float> %995, <8 x float> %996
  store <8 x float> %997, ptr %.spill109, align 32
  %.splatinsert548 = insertelement <8 x i1> poison, i1 %952, i64 0
  %.splat549 = shufflevector <8 x i1> %.splatinsert548, <8 x i1> poison, <8 x i32> zeroinitializer
  %998 = select <8 x i1> %.splat549, <8 x float> %885, <8 x float> splat (float 0xC6293E5940000000)
  %999 = load <8 x float>, ptr %.spill110, align 32
  %1000 = select <8 x i1> %71, <8 x float> %998, <8 x float> %999
  store <8 x float> %1000, ptr %.spill110, align 32
  %1001 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 0
  %1004 = select <8 x i1> %71, <8 x ptr> %1002, <8 x ptr> %1003
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 1
  %1007 = select <8 x i1> %71, <8 x i64> %1005, <8 x i64> %1006
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1004, 0
  %1009 = insertvalue { <8 x ptr>, <8 x i64> } %1008, <8 x i64> %1007, 1
  store { <8 x ptr>, <8 x i64> } %1009, ptr %tile_snapshot.spill111, align 64
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1012 = add <8 x i64> %1011, zeroinitializer
  %1013 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1010, 0
  %1014 = insertvalue { <8 x ptr>, <8 x i64> } %1013, <8 x i64> %1012, 1
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %1014, 1
  %1017 = extractelement <8 x ptr> %1015, i32 0
  %1018 = extractelement <8 x i64> %1016, i32 0
  %1019 = sub i64 %1018, 0
  %1020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1021 = select i1 %1020, i64 %1019, i64 0
  %private.contiguous.address550 = getelementptr i8, ptr %1017, i64 %1021
  %private.contiguous.preserve551 = load <8 x float>, ptr %private.contiguous.address550, align 4
  %1022 = select <8 x i1> %71, <8 x float> %953, <8 x float> %private.contiguous.preserve551
  store <8 x float> %1022, ptr %private.contiguous.address550, align 4
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1025 = add <8 x i64> %1024, splat (i64 32)
  %1026 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1023, 0
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } %1026, <8 x i64> %1025, 1
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1027, 1
  %1030 = extractelement <8 x ptr> %1028, i32 0
  %1031 = extractelement <8 x i64> %1029, i32 0
  %1032 = sub i64 %1031, 0
  %1033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1034 = select i1 %1033, i64 %1032, i64 0
  %private.contiguous.address552 = getelementptr i8, ptr %1030, i64 %1034
  %private.contiguous.preserve553 = load <8 x float>, ptr %private.contiguous.address552, align 4
  %1035 = select <8 x i1> %71, <8 x float> %956, <8 x float> %private.contiguous.preserve553
  store <8 x float> %1035, ptr %private.contiguous.address552, align 4
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1038 = add <8 x i64> %1037, splat (i64 64)
  %1039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1036, 0
  %1040 = insertvalue { <8 x ptr>, <8 x i64> } %1039, <8 x i64> %1038, 1
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %1040, 1
  %1043 = extractelement <8 x ptr> %1041, i32 0
  %1044 = extractelement <8 x i64> %1042, i32 0
  %1045 = sub i64 %1044, 0
  %1046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1047 = select i1 %1046, i64 %1045, i64 0
  %private.contiguous.address554 = getelementptr i8, ptr %1043, i64 %1047
  %private.contiguous.preserve555 = load <8 x float>, ptr %private.contiguous.address554, align 4
  %1048 = select <8 x i1> %71, <8 x float> %959, <8 x float> %private.contiguous.preserve555
  store <8 x float> %1048, ptr %private.contiguous.address554, align 4
  %1049 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1051 = add <8 x i64> %1050, splat (i64 96)
  %1052 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1049, 0
  %1053 = insertvalue { <8 x ptr>, <8 x i64> } %1052, <8 x i64> %1051, 1
  %1054 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %1053, 1
  %1056 = extractelement <8 x ptr> %1054, i32 0
  %1057 = extractelement <8 x i64> %1055, i32 0
  %1058 = sub i64 %1057, 0
  %1059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1060 = select i1 %1059, i64 %1058, i64 0
  %private.contiguous.address556 = getelementptr i8, ptr %1056, i64 %1060
  %private.contiguous.preserve557 = load <8 x float>, ptr %private.contiguous.address556, align 4
  %1061 = select <8 x i1> %71, <8 x float> %962, <8 x float> %private.contiguous.preserve557
  store <8 x float> %1061, ptr %private.contiguous.address556, align 4
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1064 = add <8 x i64> %1063, splat (i64 128)
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1062, 0
  %1066 = insertvalue { <8 x ptr>, <8 x i64> } %1065, <8 x i64> %1064, 1
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %1066, 1
  %1069 = extractelement <8 x ptr> %1067, i32 0
  %1070 = extractelement <8 x i64> %1068, i32 0
  %1071 = sub i64 %1070, 0
  %1072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1073 = select i1 %1072, i64 %1071, i64 0
  %private.contiguous.address558 = getelementptr i8, ptr %1069, i64 %1073
  %private.contiguous.preserve559 = load <8 x float>, ptr %private.contiguous.address558, align 4
  %1074 = select <8 x i1> %71, <8 x float> %965, <8 x float> %private.contiguous.preserve559
  store <8 x float> %1074, ptr %private.contiguous.address558, align 4
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1077 = add <8 x i64> %1076, splat (i64 160)
  %1078 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1075, 0
  %1079 = insertvalue { <8 x ptr>, <8 x i64> } %1078, <8 x i64> %1077, 1
  %1080 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %1079, 1
  %1082 = extractelement <8 x ptr> %1080, i32 0
  %1083 = extractelement <8 x i64> %1081, i32 0
  %1084 = sub i64 %1083, 0
  %1085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1086 = select i1 %1085, i64 %1084, i64 0
  %private.contiguous.address560 = getelementptr i8, ptr %1082, i64 %1086
  %private.contiguous.preserve561 = load <8 x float>, ptr %private.contiguous.address560, align 4
  %1087 = select <8 x i1> %71, <8 x float> %968, <8 x float> %private.contiguous.preserve561
  store <8 x float> %1087, ptr %private.contiguous.address560, align 4
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1090 = add <8 x i64> %1089, splat (i64 192)
  %1091 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1088, 0
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } %1091, <8 x i64> %1090, 1
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %1092, 1
  %1095 = extractelement <8 x ptr> %1093, i32 0
  %1096 = extractelement <8 x i64> %1094, i32 0
  %1097 = sub i64 %1096, 0
  %1098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1099 = select i1 %1098, i64 %1097, i64 0
  %private.contiguous.address562 = getelementptr i8, ptr %1095, i64 %1099
  %private.contiguous.preserve563 = load <8 x float>, ptr %private.contiguous.address562, align 4
  %1100 = select <8 x i1> %71, <8 x float> %971, <8 x float> %private.contiguous.preserve563
  store <8 x float> %1100, ptr %private.contiguous.address562, align 4
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1103 = add <8 x i64> %1102, splat (i64 224)
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1101, 0
  %1105 = insertvalue { <8 x ptr>, <8 x i64> } %1104, <8 x i64> %1103, 1
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %1105, 1
  %1108 = extractelement <8 x ptr> %1106, i32 0
  %1109 = extractelement <8 x i64> %1107, i32 0
  %1110 = sub i64 %1109, 0
  %1111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1112 = select i1 %1111, i64 %1110, i64 0
  %private.contiguous.address564 = getelementptr i8, ptr %1108, i64 %1112
  %private.contiguous.preserve565 = load <8 x float>, ptr %private.contiguous.address564, align 4
  %1113 = select <8 x i1> %71, <8 x float> %974, <8 x float> %private.contiguous.preserve565
  store <8 x float> %1113, ptr %private.contiguous.address564, align 4
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1116 = add <8 x i64> %1115, splat (i64 256)
  %1117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1114, 0
  %1118 = insertvalue { <8 x ptr>, <8 x i64> } %1117, <8 x i64> %1116, 1
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 1
  %1121 = extractelement <8 x ptr> %1119, i32 0
  %1122 = extractelement <8 x i64> %1120, i32 0
  %1123 = sub i64 %1122, 0
  %1124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1125 = select i1 %1124, i64 %1123, i64 0
  %private.contiguous.address566 = getelementptr i8, ptr %1121, i64 %1125
  %private.contiguous.preserve567 = load <8 x float>, ptr %private.contiguous.address566, align 4
  %1126 = select <8 x i1> %71, <8 x float> %977, <8 x float> %private.contiguous.preserve567
  store <8 x float> %1126, ptr %private.contiguous.address566, align 4
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1129 = add <8 x i64> %1128, splat (i64 288)
  %1130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1127, 0
  %1131 = insertvalue { <8 x ptr>, <8 x i64> } %1130, <8 x i64> %1129, 1
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %1131, 1
  %1134 = extractelement <8 x ptr> %1132, i32 0
  %1135 = extractelement <8 x i64> %1133, i32 0
  %1136 = sub i64 %1135, 0
  %1137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1138 = select i1 %1137, i64 %1136, i64 0
  %private.contiguous.address568 = getelementptr i8, ptr %1134, i64 %1138
  %private.contiguous.preserve569 = load <8 x float>, ptr %private.contiguous.address568, align 4
  %1139 = select <8 x i1> %71, <8 x float> %980, <8 x float> %private.contiguous.preserve569
  store <8 x float> %1139, ptr %private.contiguous.address568, align 4
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1142 = add <8 x i64> %1141, splat (i64 320)
  %1143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1140, 0
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } %1143, <8 x i64> %1142, 1
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %1144, 1
  %1147 = extractelement <8 x ptr> %1145, i32 0
  %1148 = extractelement <8 x i64> %1146, i32 0
  %1149 = sub i64 %1148, 0
  %1150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1151 = select i1 %1150, i64 %1149, i64 0
  %private.contiguous.address570 = getelementptr i8, ptr %1147, i64 %1151
  %private.contiguous.preserve571 = load <8 x float>, ptr %private.contiguous.address570, align 4
  %1152 = select <8 x i1> %71, <8 x float> %983, <8 x float> %private.contiguous.preserve571
  store <8 x float> %1152, ptr %private.contiguous.address570, align 4
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1155 = add <8 x i64> %1154, splat (i64 352)
  %1156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1153, 0
  %1157 = insertvalue { <8 x ptr>, <8 x i64> } %1156, <8 x i64> %1155, 1
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %1157, 1
  %1160 = extractelement <8 x ptr> %1158, i32 0
  %1161 = extractelement <8 x i64> %1159, i32 0
  %1162 = sub i64 %1161, 0
  %1163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1164 = select i1 %1163, i64 %1162, i64 0
  %private.contiguous.address572 = getelementptr i8, ptr %1160, i64 %1164
  %private.contiguous.preserve573 = load <8 x float>, ptr %private.contiguous.address572, align 4
  %1165 = select <8 x i1> %71, <8 x float> %986, <8 x float> %private.contiguous.preserve573
  store <8 x float> %1165, ptr %private.contiguous.address572, align 4
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1168 = add <8 x i64> %1167, splat (i64 384)
  %1169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1166, 0
  %1170 = insertvalue { <8 x ptr>, <8 x i64> } %1169, <8 x i64> %1168, 1
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %1170, 1
  %1173 = extractelement <8 x ptr> %1171, i32 0
  %1174 = extractelement <8 x i64> %1172, i32 0
  %1175 = sub i64 %1174, 0
  %1176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1177 = select i1 %1176, i64 %1175, i64 0
  %private.contiguous.address574 = getelementptr i8, ptr %1173, i64 %1177
  %private.contiguous.preserve575 = load <8 x float>, ptr %private.contiguous.address574, align 4
  %1178 = select <8 x i1> %71, <8 x float> %989, <8 x float> %private.contiguous.preserve575
  store <8 x float> %1178, ptr %private.contiguous.address574, align 4
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1181 = add <8 x i64> %1180, splat (i64 416)
  %1182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1179, 0
  %1183 = insertvalue { <8 x ptr>, <8 x i64> } %1182, <8 x i64> %1181, 1
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %1183, 1
  %1186 = extractelement <8 x ptr> %1184, i32 0
  %1187 = extractelement <8 x i64> %1185, i32 0
  %1188 = sub i64 %1187, 0
  %1189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1190 = select i1 %1189, i64 %1188, i64 0
  %private.contiguous.address576 = getelementptr i8, ptr %1186, i64 %1190
  %private.contiguous.preserve577 = load <8 x float>, ptr %private.contiguous.address576, align 4
  %1191 = select <8 x i1> %71, <8 x float> %992, <8 x float> %private.contiguous.preserve577
  store <8 x float> %1191, ptr %private.contiguous.address576, align 4
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1193 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1194 = add <8 x i64> %1193, splat (i64 448)
  %1195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1192, 0
  %1196 = insertvalue { <8 x ptr>, <8 x i64> } %1195, <8 x i64> %1194, 1
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 1
  %1199 = extractelement <8 x ptr> %1197, i32 0
  %1200 = extractelement <8 x i64> %1198, i32 0
  %1201 = sub i64 %1200, 0
  %1202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1203 = select i1 %1202, i64 %1201, i64 0
  %private.contiguous.address578 = getelementptr i8, ptr %1199, i64 %1203
  %private.contiguous.preserve579 = load <8 x float>, ptr %private.contiguous.address578, align 4
  %1204 = select <8 x i1> %71, <8 x float> %995, <8 x float> %private.contiguous.preserve579
  store <8 x float> %1204, ptr %private.contiguous.address578, align 4
  %1205 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1207 = add <8 x i64> %1206, splat (i64 480)
  %1208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1205, 0
  %1209 = insertvalue { <8 x ptr>, <8 x i64> } %1208, <8 x i64> %1207, 1
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1211 = extractvalue { <8 x ptr>, <8 x i64> } %1209, 1
  %1212 = extractelement <8 x ptr> %1210, i32 0
  %1213 = extractelement <8 x i64> %1211, i32 0
  %1214 = sub i64 %1213, 0
  %1215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1216 = select i1 %1215, i64 %1214, i64 0
  %private.contiguous.address580 = getelementptr i8, ptr %1212, i64 %1216
  %private.contiguous.preserve581 = load <8 x float>, ptr %private.contiguous.address580, align 4
  %1217 = select <8 x i1> %71, <8 x float> %998, <8 x float> %private.contiguous.preserve581
  store <8 x float> %1217, ptr %private.contiguous.address580, align 4
  store i64 0, ptr %.slot112, align 4
  %1218 = load <8 x float>, ptr %.slot113, align 32
  %1219 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1218
  store <8 x float> %1219, ptr %.slot113, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state582 = load i64, ptr %.slot112, align 4
  %1220 = icmp slt i64 %.state582, 16
  br i1 %1220, label %direct.true583, label %direct.false584

direct.schedule.68:                               ; preds = %direct.true583
  %.state585 = load i64, ptr %.slot112, align 4
  %1221 = sdiv i64 %.state585, 1
  %.spill.load586 = load i64, ptr %.spill78, align 4
  %1222 = mul i64 %.spill.load586, 1
  %1223 = add i64 %1222, 0
  %1224 = mul i64 %1223, 1
  %1225 = add i64 %1224, 0
  %1226 = mul i64 %1225, 16
  %1227 = add i64 %1226, %1221
  %tile_snapshot.spill.load587 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load587, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load587, 1
  %.splatinsert588 = insertelement <8 x i64> poison, i64 %1227, i64 0
  %.splat589 = shufflevector <8 x i64> %.splatinsert588, <8 x i64> poison, <8 x i32> zeroinitializer
  %1230 = mul <8 x i64> %.splat589, splat (i64 32)
  %1231 = add <8 x i64> %1229, %1230
  %1232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1228, 0
  %1233 = insertvalue { <8 x ptr>, <8 x i64> } %1232, <8 x i64> %1231, 1
  %1234 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1235 = extractvalue { <8 x ptr>, <8 x i64> } %1233, 1
  %1236 = extractelement <8 x ptr> %1234, i32 0
  %1237 = extractelement <8 x i64> %1235, i32 0
  %1238 = sub i64 %1237, 0
  %1239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1240 = select i1 %1239, i64 %1238, i64 0
  %private.contiguous.address590 = getelementptr i8, ptr %1236, i64 %1240
  %private.contiguous.load591 = load <8 x float>, ptr %private.contiguous.address590, align 4
  %1241 = select <8 x i1> %71, <8 x float> %private.contiguous.load591, <8 x float> zeroinitializer
  %.state592 = load <8 x float>, ptr %.slot113, align 32
  %1242 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state592, <8 x float> %1241)
  %.state593 = load i64, ptr %.slot112, align 4
  %1243 = add i64 %.state593, 1
  store i64 %1243, ptr %.slot112, align 4
  %1244 = load <8 x float>, ptr %.slot113, align 32
  %1245 = select <8 x i1> %71, <8 x float> %1242, <8 x float> %1244
  store <8 x float> %1245, ptr %.slot113, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false584
  %.state594 = load <8 x float>, ptr %.slot35, align 32
  %.state595 = load <8 x float>, ptr %.slot113, align 32
  %1246 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state594, <8 x float> %.state595)
  %1247 = load <8 x float>, ptr %.spill114, align 32
  %1248 = select <8 x i1> %71, <8 x float> %1246, <8 x float> %1247
  store <8 x float> %1248, ptr %.spill114, align 32
  %.state596 = load <8 x float>, ptr %.slot35, align 32
  %1249 = fsub <8 x float> %.state596, %1246
  %1250 = select <8 x i1> %71, <8 x float> %1249, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1250)
  %1251 = load <8 x float>, ptr %.spill115, align 32
  %1252 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %1251
  store <8 x float> %1252, ptr %.spill115, align 32
  %.spill.load597 = load <8 x float>, ptr %.spill95, align 32
  %1253 = fsub <8 x float> %.spill.load597, %1246
  %.spill.load598 = load <8 x float>, ptr %.spill96, align 32
  %1254 = fsub <8 x float> %.spill.load598, %1246
  %.spill.load599 = load <8 x float>, ptr %.spill97, align 32
  %1255 = fsub <8 x float> %.spill.load599, %1246
  %.spill.load600 = load <8 x float>, ptr %.spill98, align 32
  %1256 = fsub <8 x float> %.spill.load600, %1246
  %.spill.load601 = load <8 x float>, ptr %.spill99, align 32
  %1257 = fsub <8 x float> %.spill.load601, %1246
  %.spill.load602 = load <8 x float>, ptr %.spill100, align 32
  %1258 = fsub <8 x float> %.spill.load602, %1246
  %.spill.load603 = load <8 x float>, ptr %.spill101, align 32
  %1259 = fsub <8 x float> %.spill.load603, %1246
  %.spill.load604 = load <8 x float>, ptr %.spill102, align 32
  %1260 = fsub <8 x float> %.spill.load604, %1246
  %.spill.load605 = load <8 x float>, ptr %.spill103, align 32
  %1261 = fsub <8 x float> %.spill.load605, %1246
  %.spill.load606 = load <8 x float>, ptr %.spill104, align 32
  %1262 = fsub <8 x float> %.spill.load606, %1246
  %.spill.load607 = load <8 x float>, ptr %.spill105, align 32
  %1263 = fsub <8 x float> %.spill.load607, %1246
  %.spill.load608 = load <8 x float>, ptr %.spill106, align 32
  %1264 = fsub <8 x float> %.spill.load608, %1246
  %.spill.load609 = load <8 x float>, ptr %.spill107, align 32
  %1265 = fsub <8 x float> %.spill.load609, %1246
  %.spill.load610 = load <8 x float>, ptr %.spill108, align 32
  %1266 = fsub <8 x float> %.spill.load610, %1246
  %.spill.load611 = load <8 x float>, ptr %.spill109, align 32
  %1267 = fsub <8 x float> %.spill.load611, %1246
  %.spill.load612 = load <8 x float>, ptr %.spill110, align 32
  %1268 = fsub <8 x float> %.spill.load612, %1246
  %1269 = select <8 x i1> %71, <8 x float> %1253, <8 x float> zeroinitializer
  %native.exp613 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1269)
  %1270 = select <8 x i1> %71, <8 x float> %1254, <8 x float> zeroinitializer
  %native.exp614 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1270)
  %1271 = select <8 x i1> %71, <8 x float> %1255, <8 x float> zeroinitializer
  %native.exp615 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1271)
  %1272 = select <8 x i1> %71, <8 x float> %1256, <8 x float> zeroinitializer
  %native.exp616 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1272)
  %1273 = select <8 x i1> %71, <8 x float> %1257, <8 x float> zeroinitializer
  %native.exp617 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1273)
  %1274 = select <8 x i1> %71, <8 x float> %1258, <8 x float> zeroinitializer
  %native.exp618 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1274)
  %1275 = select <8 x i1> %71, <8 x float> %1259, <8 x float> zeroinitializer
  %native.exp619 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1275)
  %1276 = select <8 x i1> %71, <8 x float> %1260, <8 x float> zeroinitializer
  %native.exp620 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1276)
  %1277 = select <8 x i1> %71, <8 x float> %1261, <8 x float> zeroinitializer
  %native.exp621 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1277)
  %1278 = select <8 x i1> %71, <8 x float> %1262, <8 x float> zeroinitializer
  %native.exp622 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1278)
  %1279 = select <8 x i1> %71, <8 x float> %1263, <8 x float> zeroinitializer
  %native.exp623 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1279)
  %1280 = select <8 x i1> %71, <8 x float> %1264, <8 x float> zeroinitializer
  %native.exp624 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1280)
  %1281 = select <8 x i1> %71, <8 x float> %1265, <8 x float> zeroinitializer
  %native.exp625 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1281)
  %1282 = select <8 x i1> %71, <8 x float> %1266, <8 x float> zeroinitializer
  %native.exp626 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1282)
  %1283 = select <8 x i1> %71, <8 x float> %1267, <8 x float> zeroinitializer
  %native.exp627 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1283)
  %1284 = select <8 x i1> %71, <8 x float> %1268, <8 x float> zeroinitializer
  %native.exp628 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1284)
  %.spill.load629 = load i1, ptr %.spill79, align 1
  %.splatinsert630 = insertelement <8 x i1> poison, i1 %.spill.load629, i64 0
  %.splat631 = shufflevector <8 x i1> %.splatinsert630, <8 x i1> poison, <8 x i32> zeroinitializer
  %1285 = select <8 x i1> %.splat631, <8 x float> %native.exp613, <8 x float> zeroinitializer
  %.spill.load632 = load i1, ptr %.spill80, align 1
  %.splatinsert633 = insertelement <8 x i1> poison, i1 %.spill.load632, i64 0
  %.splat634 = shufflevector <8 x i1> %.splatinsert633, <8 x i1> poison, <8 x i32> zeroinitializer
  %1286 = select <8 x i1> %.splat634, <8 x float> %native.exp614, <8 x float> zeroinitializer
  %.spill.load635 = load i1, ptr %.spill81, align 1
  %.splatinsert636 = insertelement <8 x i1> poison, i1 %.spill.load635, i64 0
  %.splat637 = shufflevector <8 x i1> %.splatinsert636, <8 x i1> poison, <8 x i32> zeroinitializer
  %1287 = select <8 x i1> %.splat637, <8 x float> %native.exp615, <8 x float> zeroinitializer
  %.spill.load638 = load i1, ptr %.spill82, align 1
  %.splatinsert639 = insertelement <8 x i1> poison, i1 %.spill.load638, i64 0
  %.splat640 = shufflevector <8 x i1> %.splatinsert639, <8 x i1> poison, <8 x i32> zeroinitializer
  %1288 = select <8 x i1> %.splat640, <8 x float> %native.exp616, <8 x float> zeroinitializer
  %.spill.load641 = load i1, ptr %.spill83, align 1
  %.splatinsert642 = insertelement <8 x i1> poison, i1 %.spill.load641, i64 0
  %.splat643 = shufflevector <8 x i1> %.splatinsert642, <8 x i1> poison, <8 x i32> zeroinitializer
  %1289 = select <8 x i1> %.splat643, <8 x float> %native.exp617, <8 x float> zeroinitializer
  %.spill.load644 = load i1, ptr %.spill84, align 1
  %.splatinsert645 = insertelement <8 x i1> poison, i1 %.spill.load644, i64 0
  %.splat646 = shufflevector <8 x i1> %.splatinsert645, <8 x i1> poison, <8 x i32> zeroinitializer
  %1290 = select <8 x i1> %.splat646, <8 x float> %native.exp618, <8 x float> zeroinitializer
  %.spill.load647 = load i1, ptr %.spill85, align 1
  %.splatinsert648 = insertelement <8 x i1> poison, i1 %.spill.load647, i64 0
  %.splat649 = shufflevector <8 x i1> %.splatinsert648, <8 x i1> poison, <8 x i32> zeroinitializer
  %1291 = select <8 x i1> %.splat649, <8 x float> %native.exp619, <8 x float> zeroinitializer
  %.spill.load650 = load i1, ptr %.spill86, align 1
  %.splatinsert651 = insertelement <8 x i1> poison, i1 %.spill.load650, i64 0
  %.splat652 = shufflevector <8 x i1> %.splatinsert651, <8 x i1> poison, <8 x i32> zeroinitializer
  %1292 = select <8 x i1> %.splat652, <8 x float> %native.exp620, <8 x float> zeroinitializer
  %.spill.load653 = load i1, ptr %.spill87, align 1
  %.splatinsert654 = insertelement <8 x i1> poison, i1 %.spill.load653, i64 0
  %.splat655 = shufflevector <8 x i1> %.splatinsert654, <8 x i1> poison, <8 x i32> zeroinitializer
  %1293 = select <8 x i1> %.splat655, <8 x float> %native.exp621, <8 x float> zeroinitializer
  %.spill.load656 = load i1, ptr %.spill88, align 1
  %.splatinsert657 = insertelement <8 x i1> poison, i1 %.spill.load656, i64 0
  %.splat658 = shufflevector <8 x i1> %.splatinsert657, <8 x i1> poison, <8 x i32> zeroinitializer
  %1294 = select <8 x i1> %.splat658, <8 x float> %native.exp622, <8 x float> zeroinitializer
  %.spill.load659 = load i1, ptr %.spill89, align 1
  %.splatinsert660 = insertelement <8 x i1> poison, i1 %.spill.load659, i64 0
  %.splat661 = shufflevector <8 x i1> %.splatinsert660, <8 x i1> poison, <8 x i32> zeroinitializer
  %1295 = select <8 x i1> %.splat661, <8 x float> %native.exp623, <8 x float> zeroinitializer
  %.spill.load662 = load i1, ptr %.spill90, align 1
  %.splatinsert663 = insertelement <8 x i1> poison, i1 %.spill.load662, i64 0
  %.splat664 = shufflevector <8 x i1> %.splatinsert663, <8 x i1> poison, <8 x i32> zeroinitializer
  %1296 = select <8 x i1> %.splat664, <8 x float> %native.exp624, <8 x float> zeroinitializer
  %.spill.load665 = load i1, ptr %.spill91, align 1
  %.splatinsert666 = insertelement <8 x i1> poison, i1 %.spill.load665, i64 0
  %.splat667 = shufflevector <8 x i1> %.splatinsert666, <8 x i1> poison, <8 x i32> zeroinitializer
  %1297 = select <8 x i1> %.splat667, <8 x float> %native.exp625, <8 x float> zeroinitializer
  %.spill.load668 = load i1, ptr %.spill92, align 1
  %.splatinsert669 = insertelement <8 x i1> poison, i1 %.spill.load668, i64 0
  %.splat670 = shufflevector <8 x i1> %.splatinsert669, <8 x i1> poison, <8 x i32> zeroinitializer
  %1298 = select <8 x i1> %.splat670, <8 x float> %native.exp626, <8 x float> zeroinitializer
  %.spill.load671 = load i1, ptr %.spill93, align 1
  %.splatinsert672 = insertelement <8 x i1> poison, i1 %.spill.load671, i64 0
  %.splat673 = shufflevector <8 x i1> %.splatinsert672, <8 x i1> poison, <8 x i32> zeroinitializer
  %1299 = select <8 x i1> %.splat673, <8 x float> %native.exp627, <8 x float> zeroinitializer
  %.spill.load674 = load i1, ptr %.spill94, align 1
  %.splatinsert675 = insertelement <8 x i1> poison, i1 %.spill.load674, i64 0
  %.splat676 = shufflevector <8 x i1> %.splatinsert675, <8 x i1> poison, <8 x i32> zeroinitializer
  %1300 = select <8 x i1> %.splat676, <8 x float> %native.exp628, <8 x float> zeroinitializer
  %1301 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1302 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1303 = extractvalue { <8 x ptr>, <8 x i64> } %1301, 0
  %1304 = select <8 x i1> %71, <8 x ptr> %1302, <8 x ptr> %1303
  %1305 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %1301, 1
  %1307 = select <8 x i1> %71, <8 x i64> %1305, <8 x i64> %1306
  %1308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1304, 0
  %1309 = insertvalue { <8 x ptr>, <8 x i64> } %1308, <8 x i64> %1307, 1
  store { <8 x ptr>, <8 x i64> } %1309, ptr %tile_snapshot.spill116, align 64
  %1310 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1312 = add <8 x i64> %1311, zeroinitializer
  %1313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1310, 0
  %1314 = insertvalue { <8 x ptr>, <8 x i64> } %1313, <8 x i64> %1312, 1
  %1315 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1316 = extractvalue { <8 x ptr>, <8 x i64> } %1314, 1
  %1317 = extractelement <8 x ptr> %1315, i32 0
  %1318 = extractelement <8 x i64> %1316, i32 0
  %1319 = sub i64 %1318, 0
  %1320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1321 = select i1 %1320, i64 %1319, i64 0
  %private.contiguous.address677 = getelementptr i8, ptr %1317, i64 %1321
  %private.contiguous.preserve678 = load <8 x float>, ptr %private.contiguous.address677, align 4
  %1322 = select <8 x i1> %71, <8 x float> %1285, <8 x float> %private.contiguous.preserve678
  store <8 x float> %1322, ptr %private.contiguous.address677, align 4
  %1323 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1324 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1325 = add <8 x i64> %1324, splat (i64 32)
  %1326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1323, 0
  %1327 = insertvalue { <8 x ptr>, <8 x i64> } %1326, <8 x i64> %1325, 1
  %1328 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1329 = extractvalue { <8 x ptr>, <8 x i64> } %1327, 1
  %1330 = extractelement <8 x ptr> %1328, i32 0
  %1331 = extractelement <8 x i64> %1329, i32 0
  %1332 = sub i64 %1331, 0
  %1333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1334 = select i1 %1333, i64 %1332, i64 0
  %private.contiguous.address679 = getelementptr i8, ptr %1330, i64 %1334
  %private.contiguous.preserve680 = load <8 x float>, ptr %private.contiguous.address679, align 4
  %1335 = select <8 x i1> %71, <8 x float> %1286, <8 x float> %private.contiguous.preserve680
  store <8 x float> %1335, ptr %private.contiguous.address679, align 4
  %1336 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1338 = add <8 x i64> %1337, splat (i64 64)
  %1339 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1336, 0
  %1340 = insertvalue { <8 x ptr>, <8 x i64> } %1339, <8 x i64> %1338, 1
  %1341 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1342 = extractvalue { <8 x ptr>, <8 x i64> } %1340, 1
  %1343 = extractelement <8 x ptr> %1341, i32 0
  %1344 = extractelement <8 x i64> %1342, i32 0
  %1345 = sub i64 %1344, 0
  %1346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1347 = select i1 %1346, i64 %1345, i64 0
  %private.contiguous.address681 = getelementptr i8, ptr %1343, i64 %1347
  %private.contiguous.preserve682 = load <8 x float>, ptr %private.contiguous.address681, align 4
  %1348 = select <8 x i1> %71, <8 x float> %1287, <8 x float> %private.contiguous.preserve682
  store <8 x float> %1348, ptr %private.contiguous.address681, align 4
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1351 = add <8 x i64> %1350, splat (i64 96)
  %1352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1349, 0
  %1353 = insertvalue { <8 x ptr>, <8 x i64> } %1352, <8 x i64> %1351, 1
  %1354 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %1353, 1
  %1356 = extractelement <8 x ptr> %1354, i32 0
  %1357 = extractelement <8 x i64> %1355, i32 0
  %1358 = sub i64 %1357, 0
  %1359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1360 = select i1 %1359, i64 %1358, i64 0
  %private.contiguous.address683 = getelementptr i8, ptr %1356, i64 %1360
  %private.contiguous.preserve684 = load <8 x float>, ptr %private.contiguous.address683, align 4
  %1361 = select <8 x i1> %71, <8 x float> %1288, <8 x float> %private.contiguous.preserve684
  store <8 x float> %1361, ptr %private.contiguous.address683, align 4
  %1362 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1364 = add <8 x i64> %1363, splat (i64 128)
  %1365 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1362, 0
  %1366 = insertvalue { <8 x ptr>, <8 x i64> } %1365, <8 x i64> %1364, 1
  %1367 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %1366, 1
  %1369 = extractelement <8 x ptr> %1367, i32 0
  %1370 = extractelement <8 x i64> %1368, i32 0
  %1371 = sub i64 %1370, 0
  %1372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1373 = select i1 %1372, i64 %1371, i64 0
  %private.contiguous.address685 = getelementptr i8, ptr %1369, i64 %1373
  %private.contiguous.preserve686 = load <8 x float>, ptr %private.contiguous.address685, align 4
  %1374 = select <8 x i1> %71, <8 x float> %1289, <8 x float> %private.contiguous.preserve686
  store <8 x float> %1374, ptr %private.contiguous.address685, align 4
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1376 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1377 = add <8 x i64> %1376, splat (i64 160)
  %1378 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1375, 0
  %1379 = insertvalue { <8 x ptr>, <8 x i64> } %1378, <8 x i64> %1377, 1
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %1379, 1
  %1382 = extractelement <8 x ptr> %1380, i32 0
  %1383 = extractelement <8 x i64> %1381, i32 0
  %1384 = sub i64 %1383, 0
  %1385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1386 = select i1 %1385, i64 %1384, i64 0
  %private.contiguous.address687 = getelementptr i8, ptr %1382, i64 %1386
  %private.contiguous.preserve688 = load <8 x float>, ptr %private.contiguous.address687, align 4
  %1387 = select <8 x i1> %71, <8 x float> %1290, <8 x float> %private.contiguous.preserve688
  store <8 x float> %1387, ptr %private.contiguous.address687, align 4
  %1388 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1389 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1390 = add <8 x i64> %1389, splat (i64 192)
  %1391 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1388, 0
  %1392 = insertvalue { <8 x ptr>, <8 x i64> } %1391, <8 x i64> %1390, 1
  %1393 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1394 = extractvalue { <8 x ptr>, <8 x i64> } %1392, 1
  %1395 = extractelement <8 x ptr> %1393, i32 0
  %1396 = extractelement <8 x i64> %1394, i32 0
  %1397 = sub i64 %1396, 0
  %1398 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1399 = select i1 %1398, i64 %1397, i64 0
  %private.contiguous.address689 = getelementptr i8, ptr %1395, i64 %1399
  %private.contiguous.preserve690 = load <8 x float>, ptr %private.contiguous.address689, align 4
  %1400 = select <8 x i1> %71, <8 x float> %1291, <8 x float> %private.contiguous.preserve690
  store <8 x float> %1400, ptr %private.contiguous.address689, align 4
  %1401 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1402 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1403 = add <8 x i64> %1402, splat (i64 224)
  %1404 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1401, 0
  %1405 = insertvalue { <8 x ptr>, <8 x i64> } %1404, <8 x i64> %1403, 1
  %1406 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %1405, 1
  %1408 = extractelement <8 x ptr> %1406, i32 0
  %1409 = extractelement <8 x i64> %1407, i32 0
  %1410 = sub i64 %1409, 0
  %1411 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1412 = select i1 %1411, i64 %1410, i64 0
  %private.contiguous.address691 = getelementptr i8, ptr %1408, i64 %1412
  %private.contiguous.preserve692 = load <8 x float>, ptr %private.contiguous.address691, align 4
  %1413 = select <8 x i1> %71, <8 x float> %1292, <8 x float> %private.contiguous.preserve692
  store <8 x float> %1413, ptr %private.contiguous.address691, align 4
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1416 = add <8 x i64> %1415, splat (i64 256)
  %1417 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1414, 0
  %1418 = insertvalue { <8 x ptr>, <8 x i64> } %1417, <8 x i64> %1416, 1
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %1418, 1
  %1421 = extractelement <8 x ptr> %1419, i32 0
  %1422 = extractelement <8 x i64> %1420, i32 0
  %1423 = sub i64 %1422, 0
  %1424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1425 = select i1 %1424, i64 %1423, i64 0
  %private.contiguous.address693 = getelementptr i8, ptr %1421, i64 %1425
  %private.contiguous.preserve694 = load <8 x float>, ptr %private.contiguous.address693, align 4
  %1426 = select <8 x i1> %71, <8 x float> %1293, <8 x float> %private.contiguous.preserve694
  store <8 x float> %1426, ptr %private.contiguous.address693, align 4
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1429 = add <8 x i64> %1428, splat (i64 288)
  %1430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1427, 0
  %1431 = insertvalue { <8 x ptr>, <8 x i64> } %1430, <8 x i64> %1429, 1
  %1432 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %1431, 1
  %1434 = extractelement <8 x ptr> %1432, i32 0
  %1435 = extractelement <8 x i64> %1433, i32 0
  %1436 = sub i64 %1435, 0
  %1437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1438 = select i1 %1437, i64 %1436, i64 0
  %private.contiguous.address695 = getelementptr i8, ptr %1434, i64 %1438
  %private.contiguous.preserve696 = load <8 x float>, ptr %private.contiguous.address695, align 4
  %1439 = select <8 x i1> %71, <8 x float> %1294, <8 x float> %private.contiguous.preserve696
  store <8 x float> %1439, ptr %private.contiguous.address695, align 4
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1442 = add <8 x i64> %1441, splat (i64 320)
  %1443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1440, 0
  %1444 = insertvalue { <8 x ptr>, <8 x i64> } %1443, <8 x i64> %1442, 1
  %1445 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1446 = extractvalue { <8 x ptr>, <8 x i64> } %1444, 1
  %1447 = extractelement <8 x ptr> %1445, i32 0
  %1448 = extractelement <8 x i64> %1446, i32 0
  %1449 = sub i64 %1448, 0
  %1450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1451 = select i1 %1450, i64 %1449, i64 0
  %private.contiguous.address697 = getelementptr i8, ptr %1447, i64 %1451
  %private.contiguous.preserve698 = load <8 x float>, ptr %private.contiguous.address697, align 4
  %1452 = select <8 x i1> %71, <8 x float> %1295, <8 x float> %private.contiguous.preserve698
  store <8 x float> %1452, ptr %private.contiguous.address697, align 4
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1455 = add <8 x i64> %1454, splat (i64 352)
  %1456 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1453, 0
  %1457 = insertvalue { <8 x ptr>, <8 x i64> } %1456, <8 x i64> %1455, 1
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %1457, 1
  %1460 = extractelement <8 x ptr> %1458, i32 0
  %1461 = extractelement <8 x i64> %1459, i32 0
  %1462 = sub i64 %1461, 0
  %1463 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1464 = select i1 %1463, i64 %1462, i64 0
  %private.contiguous.address699 = getelementptr i8, ptr %1460, i64 %1464
  %private.contiguous.preserve700 = load <8 x float>, ptr %private.contiguous.address699, align 4
  %1465 = select <8 x i1> %71, <8 x float> %1296, <8 x float> %private.contiguous.preserve700
  store <8 x float> %1465, ptr %private.contiguous.address699, align 4
  %1466 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1467 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1468 = add <8 x i64> %1467, splat (i64 384)
  %1469 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1466, 0
  %1470 = insertvalue { <8 x ptr>, <8 x i64> } %1469, <8 x i64> %1468, 1
  %1471 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %1470, 1
  %1473 = extractelement <8 x ptr> %1471, i32 0
  %1474 = extractelement <8 x i64> %1472, i32 0
  %1475 = sub i64 %1474, 0
  %1476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1477 = select i1 %1476, i64 %1475, i64 0
  %private.contiguous.address701 = getelementptr i8, ptr %1473, i64 %1477
  %private.contiguous.preserve702 = load <8 x float>, ptr %private.contiguous.address701, align 4
  %1478 = select <8 x i1> %71, <8 x float> %1297, <8 x float> %private.contiguous.preserve702
  store <8 x float> %1478, ptr %private.contiguous.address701, align 4
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1480 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1481 = add <8 x i64> %1480, splat (i64 416)
  %1482 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1479, 0
  %1483 = insertvalue { <8 x ptr>, <8 x i64> } %1482, <8 x i64> %1481, 1
  %1484 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %1483, 1
  %1486 = extractelement <8 x ptr> %1484, i32 0
  %1487 = extractelement <8 x i64> %1485, i32 0
  %1488 = sub i64 %1487, 0
  %1489 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1490 = select i1 %1489, i64 %1488, i64 0
  %private.contiguous.address703 = getelementptr i8, ptr %1486, i64 %1490
  %private.contiguous.preserve704 = load <8 x float>, ptr %private.contiguous.address703, align 4
  %1491 = select <8 x i1> %71, <8 x float> %1298, <8 x float> %private.contiguous.preserve704
  store <8 x float> %1491, ptr %private.contiguous.address703, align 4
  %1492 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1493 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1494 = add <8 x i64> %1493, splat (i64 448)
  %1495 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1492, 0
  %1496 = insertvalue { <8 x ptr>, <8 x i64> } %1495, <8 x i64> %1494, 1
  %1497 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1498 = extractvalue { <8 x ptr>, <8 x i64> } %1496, 1
  %1499 = extractelement <8 x ptr> %1497, i32 0
  %1500 = extractelement <8 x i64> %1498, i32 0
  %1501 = sub i64 %1500, 0
  %1502 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1503 = select i1 %1502, i64 %1501, i64 0
  %private.contiguous.address705 = getelementptr i8, ptr %1499, i64 %1503
  %private.contiguous.preserve706 = load <8 x float>, ptr %private.contiguous.address705, align 4
  %1504 = select <8 x i1> %71, <8 x float> %1299, <8 x float> %private.contiguous.preserve706
  store <8 x float> %1504, ptr %private.contiguous.address705, align 4
  %1505 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1506 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1507 = add <8 x i64> %1506, splat (i64 480)
  %1508 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1505, 0
  %1509 = insertvalue { <8 x ptr>, <8 x i64> } %1508, <8 x i64> %1507, 1
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %1509, 1
  %1512 = extractelement <8 x ptr> %1510, i32 0
  %1513 = extractelement <8 x i64> %1511, i32 0
  %1514 = sub i64 %1513, 0
  %1515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1516 = select i1 %1515, i64 %1514, i64 0
  %private.contiguous.address707 = getelementptr i8, ptr %1512, i64 %1516
  %private.contiguous.preserve708 = load <8 x float>, ptr %private.contiguous.address707, align 4
  %1517 = select <8 x i1> %71, <8 x float> %1300, <8 x float> %private.contiguous.preserve708
  store <8 x float> %1517, ptr %private.contiguous.address707, align 4
  %.state709 = load <8 x float>, ptr %.slot36, align 32
  %1518 = fmul <8 x float> %.state709, %native.exp
  %1519 = load <8 x float>, ptr %.spill117, align 32
  %1520 = select <8 x i1> %71, <8 x float> %1518, <8 x float> %1519
  store <8 x float> %1520, ptr %.spill117, align 32
  store i64 0, ptr %.slot118, align 4
  %1521 = load <8 x float>, ptr %.slot119, align 32
  %1522 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1521
  store <8 x float> %1522, ptr %.slot119, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state710 = load i64, ptr %.slot118, align 4
  %1523 = icmp slt i64 %.state710, 16
  br i1 %1523, label %direct.true711, label %direct.false712

direct.schedule.71:                               ; preds = %direct.true711
  %.state713 = load i64, ptr %.slot118, align 4
  %1524 = sdiv i64 %.state713, 1
  %.spill.load714 = load i64, ptr %.spill78, align 4
  %1525 = mul i64 %.spill.load714, 1
  %1526 = add i64 %1525, 0
  %1527 = mul i64 %1526, 1
  %1528 = add i64 %1527, 0
  %1529 = mul i64 %1528, 16
  %1530 = add i64 %1529, %1524
  %tile_snapshot.spill.load715 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load715, 0
  %1532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load715, 1
  %.splatinsert716 = insertelement <8 x i64> poison, i64 %1530, i64 0
  %.splat717 = shufflevector <8 x i64> %.splatinsert716, <8 x i64> poison, <8 x i32> zeroinitializer
  %1533 = mul <8 x i64> %.splat717, splat (i64 32)
  %1534 = add <8 x i64> %1532, %1533
  %1535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1531, 0
  %1536 = insertvalue { <8 x ptr>, <8 x i64> } %1535, <8 x i64> %1534, 1
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %1536, 1
  %1539 = extractelement <8 x ptr> %1537, i32 0
  %1540 = extractelement <8 x i64> %1538, i32 0
  %1541 = sub i64 %1540, 0
  %1542 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1543 = select i1 %1542, i64 %1541, i64 0
  %private.contiguous.address718 = getelementptr i8, ptr %1539, i64 %1543
  %private.contiguous.load719 = load <8 x float>, ptr %private.contiguous.address718, align 4
  %1544 = select <8 x i1> %71, <8 x float> %private.contiguous.load719, <8 x float> zeroinitializer
  %.state720 = load <8 x float>, ptr %.slot119, align 32
  %1545 = fadd <8 x float> %.state720, %1544
  %.state721 = load i64, ptr %.slot118, align 4
  %1546 = add i64 %.state721, 1
  store i64 %1546, ptr %.slot118, align 4
  %1547 = load <8 x float>, ptr %.slot119, align 32
  %1548 = select <8 x i1> %71, <8 x float> %1545, <8 x float> %1547
  store <8 x float> %1548, ptr %.slot119, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false712
  %.spill.load722 = load <8 x float>, ptr %.spill117, align 32
  %.state723 = load <8 x float>, ptr %.slot119, align 32
  %1549 = fadd <8 x float> %.spill.load722, %.state723
  %1550 = load <8 x float>, ptr %.spill120, align 32
  %1551 = select <8 x i1> %71, <8 x float> %1549, <8 x float> %1550
  store <8 x float> %1551, ptr %.spill120, align 32
  %1552 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1553 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %1552, 0
  %1555 = select <8 x i1> %71, <8 x ptr> %1553, <8 x ptr> %1554
  %1556 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1557 = extractvalue { <8 x ptr>, <8 x i64> } %1552, 1
  %1558 = select <8 x i1> %71, <8 x i64> %1556, <8 x i64> %1557
  %1559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1555, 0
  %1560 = insertvalue { <8 x ptr>, <8 x i64> } %1559, <8 x i64> %1558, 1
  store { <8 x ptr>, <8 x i64> } %1560, ptr %tile_snapshot.spill121, align 64
  store i64 0, ptr %.slot122, align 4
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.77, %direct.schedule.72
  %.state724 = load i64, ptr %.slot122, align 4
  %1561 = icmp slt i64 %.state724, 96
  br i1 %1561, label %direct.true725, label %direct.false726

direct.schedule.74:                               ; preds = %direct.true725
  %.state727 = load i64, ptr %.slot122, align 4
  %1562 = add i64 0, %.state727
  %tile_snapshot.spill.load728 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 0
  %1564 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 1
  %.splatinsert729 = insertelement <8 x i64> poison, i64 %1562, i64 0
  %.splat730 = shufflevector <8 x i64> %.splatinsert729, <8 x i64> poison, <8 x i32> zeroinitializer
  %1565 = mul <8 x i64> %.splat730, splat (i64 32)
  %1566 = add <8 x i64> %1564, %1565
  %1567 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1563, 0
  %1568 = insertvalue { <8 x ptr>, <8 x i64> } %1567, <8 x i64> %1566, 1
  %1569 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1570 = extractvalue { <8 x ptr>, <8 x i64> } %1568, 1
  %1571 = extractelement <8 x ptr> %1569, i32 0
  %1572 = extractelement <8 x i64> %1570, i32 0
  %1573 = sub i64 %1572, 0
  %1574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1575 = select i1 %1574, i64 %1573, i64 0
  %private.contiguous.address731 = getelementptr i8, ptr %1571, i64 %1575
  %private.contiguous.load732 = load <8 x float>, ptr %private.contiguous.address731, align 4
  %1576 = select <8 x i1> %71, <8 x float> %private.contiguous.load732, <8 x float> zeroinitializer
  %.spill.load733 = load <8 x float>, ptr %.spill115, align 32
  %1577 = fmul <8 x float> %1576, %.spill.load733
  store i64 0, ptr %.slot123, align 4
  %1578 = load <8 x float>, ptr %.slot124, align 32
  %1579 = select <8 x i1> %71, <8 x float> %1577, <8 x float> %1578
  store <8 x float> %1579, ptr %.slot124, align 32
  br label %direct.schedule.75

direct.schedule.75:                               ; preds = %direct.schedule.76, %direct.schedule.74
  %.state734 = load i64, ptr %.slot123, align 4
  %1580 = icmp slt i64 %.state734, 16
  br i1 %1580, label %direct.true735, label %direct.false736

direct.schedule.76:                               ; preds = %direct.true735
  %.state737 = load i64, ptr %.slot123, align 4
  %1581 = add i64 0, %.state737
  %tile_snapshot.spill.load738 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load738, 0
  %1583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load738, 1
  %.splatinsert739 = insertelement <8 x i64> poison, i64 %1581, i64 0
  %.splat740 = shufflevector <8 x i64> %.splatinsert739, <8 x i64> poison, <8 x i32> zeroinitializer
  %1584 = mul <8 x i64> %.splat740, splat (i64 32)
  %1585 = add <8 x i64> %1583, %1584
  %1586 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1582, 0
  %1587 = insertvalue { <8 x ptr>, <8 x i64> } %1586, <8 x i64> %1585, 1
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %1587, 1
  %1590 = extractelement <8 x ptr> %1588, i32 0
  %1591 = extractelement <8 x i64> %1589, i32 0
  %1592 = sub i64 %1591, 0
  %1593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1594 = select i1 %1593, i64 %1592, i64 0
  %private.contiguous.address741 = getelementptr i8, ptr %1590, i64 %1594
  %private.contiguous.load742 = load <8 x float>, ptr %private.contiguous.address741, align 4
  %1595 = select <8 x i1> %71, <8 x float> %private.contiguous.load742, <8 x float> zeroinitializer
  %1596 = mul i64 %1581, 96
  %.state743 = load i64, ptr %.slot122, align 4
  %1597 = add i64 %1596, %.state743
  %tile_snapshot.spill.load744 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load744, 0
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load744, 1
  %.splatinsert745 = insertelement <8 x i64> poison, i64 %1597, i64 0
  %.splat746 = shufflevector <8 x i64> %.splatinsert745, <8 x i64> poison, <8 x i32> zeroinitializer
  %1600 = mul <8 x i64> %.splat746, splat (i64 32)
  %1601 = add <8 x i64> %1599, %1600
  %1602 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1598, 0
  %1603 = insertvalue { <8 x ptr>, <8 x i64> } %1602, <8 x i64> %1601, 1
  %1604 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %1603, 1
  %1606 = extractelement <8 x ptr> %1604, i32 0
  %1607 = extractelement <8 x i64> %1605, i32 0
  %1608 = sub i64 %1607, 0
  %1609 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1610 = select i1 %1609, i64 %1608, i64 0
  %private.contiguous.address747 = getelementptr i8, ptr %1606, i64 %1610
  %private.contiguous.load748 = load <8 x float>, ptr %private.contiguous.address747, align 4
  %1611 = select <8 x i1> %71, <8 x float> %private.contiguous.load748, <8 x float> zeroinitializer
  %1612 = fmul <8 x float> %1595, %1611
  %.state749 = load <8 x float>, ptr %.slot124, align 32
  %1613 = fadd <8 x float> %.state749, %1612
  %.state750 = load i64, ptr %.slot123, align 4
  %1614 = add i64 %.state750, 1
  store i64 %1614, ptr %.slot123, align 4
  %1615 = load <8 x float>, ptr %.slot124, align 32
  %1616 = select <8 x i1> %71, <8 x float> %1613, <8 x float> %1615
  store <8 x float> %1616, ptr %.slot124, align 32
  br label %direct.schedule.75

direct.schedule.77:                               ; preds = %direct.false736
  %tile_snapshot.spill.load751 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1617 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load751, 0
  %1618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load751, 1
  %.state752 = load i64, ptr %.slot122, align 4
  %.splatinsert753 = insertelement <8 x i64> poison, i64 %.state752, i64 0
  %.splat754 = shufflevector <8 x i64> %.splatinsert753, <8 x i64> poison, <8 x i32> zeroinitializer
  %1619 = mul <8 x i64> %.splat754, splat (i64 32)
  %1620 = add <8 x i64> %1618, %1619
  %1621 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1617, 0
  %1622 = insertvalue { <8 x ptr>, <8 x i64> } %1621, <8 x i64> %1620, 1
  %.state755 = load <8 x float>, ptr %.slot124, align 32
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %1622, 1
  %1625 = extractelement <8 x ptr> %1623, i32 0
  %1626 = extractelement <8 x i64> %1624, i32 0
  %1627 = sub i64 %1626, 0
  %1628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1629 = select i1 %1628, i64 %1627, i64 0
  %private.contiguous.address756 = getelementptr i8, ptr %1625, i64 %1629
  %private.contiguous.preserve757 = load <8 x float>, ptr %private.contiguous.address756, align 4
  %1630 = select <8 x i1> %71, <8 x float> %.state755, <8 x float> %private.contiguous.preserve757
  store <8 x float> %1630, ptr %private.contiguous.address756, align 4
  %.state758 = load i64, ptr %.slot122, align 4
  %1631 = add i64 %.state758, 1
  store i64 %1631, ptr %.slot122, align 4
  br label %direct.schedule.73

direct.schedule.78:                               ; preds = %direct.false726
  store i64 0, ptr %.slot125, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state759 = load i64, ptr %.slot125, align 4
  %1632 = icmp slt i64 %.state759, 96
  br i1 %1632, label %direct.true760, label %direct.false761

direct.schedule.80:                               ; preds = %direct.true760
  %tile_snapshot.spill.load762 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %1634 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %.state763 = load i64, ptr %.slot125, align 4
  %.splatinsert764 = insertelement <8 x i64> poison, i64 %.state763, i64 0
  %.splat765 = shufflevector <8 x i64> %.splatinsert764, <8 x i64> poison, <8 x i32> zeroinitializer
  %1635 = mul <8 x i64> %.splat765, splat (i64 32)
  %1636 = add <8 x i64> %1634, %1635
  %1637 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1633, 0
  %1638 = insertvalue { <8 x ptr>, <8 x i64> } %1637, <8 x i64> %1636, 1
  %1639 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1640 = extractvalue { <8 x ptr>, <8 x i64> } %1638, 1
  %1641 = extractelement <8 x ptr> %1639, i32 0
  %1642 = extractelement <8 x i64> %1640, i32 0
  %1643 = sub i64 %1642, 0
  %1644 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1645 = select i1 %1644, i64 %1643, i64 0
  %private.contiguous.address766 = getelementptr i8, ptr %1641, i64 %1645
  %private.contiguous.load767 = load <8 x float>, ptr %private.contiguous.address766, align 4
  %1646 = select <8 x i1> %71, <8 x float> %private.contiguous.load767, <8 x float> zeroinitializer
  %tile_snapshot.spill.load768 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 0
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 1
  %.state769 = load i64, ptr %.slot125, align 4
  %.splatinsert770 = insertelement <8 x i64> poison, i64 %.state769, i64 0
  %.splat771 = shufflevector <8 x i64> %.splatinsert770, <8 x i64> poison, <8 x i32> zeroinitializer
  %1649 = mul <8 x i64> %.splat771, splat (i64 32)
  %1650 = add <8 x i64> %1648, %1649
  %1651 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1647, 0
  %1652 = insertvalue { <8 x ptr>, <8 x i64> } %1651, <8 x i64> %1650, 1
  %1653 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1654 = extractvalue { <8 x ptr>, <8 x i64> } %1652, 1
  %1655 = extractelement <8 x ptr> %1653, i32 0
  %1656 = extractelement <8 x i64> %1654, i32 0
  %1657 = sub i64 %1656, 0
  %1658 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1659 = select i1 %1658, i64 %1657, i64 0
  %private.contiguous.address772 = getelementptr i8, ptr %1655, i64 %1659
  %private.contiguous.preserve773 = load <8 x float>, ptr %private.contiguous.address772, align 4
  %1660 = select <8 x i1> %71, <8 x float> %1646, <8 x float> %private.contiguous.preserve773
  store <8 x float> %1660, ptr %private.contiguous.address772, align 4
  %.state774 = load i64, ptr %.slot125, align 4
  %1661 = add i64 %.state774, 1
  store i64 %1661, ptr %.slot125, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false761
  store i64 0, ptr %.slot126, align 4
  br label %direct.schedule.82

direct.schedule.82:                               ; preds = %direct.schedule.83, %direct.schedule.81
  %.state775 = load i64, ptr %.slot126, align 4
  %1662 = icmp slt i64 %.state775, 96
  br i1 %1662, label %direct.true776, label %direct.false777

direct.schedule.83:                               ; preds = %direct.true776
  %tile_snapshot.spill.load778 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load778, 0
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load778, 1
  %.state779 = load i64, ptr %.slot126, align 4
  %.splatinsert780 = insertelement <8 x i64> poison, i64 %.state779, i64 0
  %.splat781 = shufflevector <8 x i64> %.splatinsert780, <8 x i64> poison, <8 x i32> zeroinitializer
  %1665 = mul <8 x i64> %.splat781, splat (i64 32)
  %1666 = add <8 x i64> %1664, %1665
  %1667 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1663, 0
  %1668 = insertvalue { <8 x ptr>, <8 x i64> } %1667, <8 x i64> %1666, 1
  %1669 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1670 = extractvalue { <8 x ptr>, <8 x i64> } %1668, 1
  %1671 = extractelement <8 x ptr> %1669, i32 0
  %1672 = extractelement <8 x i64> %1670, i32 0
  %1673 = sub i64 %1672, 0
  %1674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1675 = select i1 %1674, i64 %1673, i64 0
  %private.contiguous.address782 = getelementptr i8, ptr %1671, i64 %1675
  %private.contiguous.load783 = load <8 x float>, ptr %private.contiguous.address782, align 4
  %1676 = select <8 x i1> %71, <8 x float> %private.contiguous.load783, <8 x float> zeroinitializer
  %tile_snapshot.spill.load784 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1677 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 0
  %1678 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 1
  %.state785 = load i64, ptr %.slot126, align 4
  %.splatinsert786 = insertelement <8 x i64> poison, i64 %.state785, i64 0
  %.splat787 = shufflevector <8 x i64> %.splatinsert786, <8 x i64> poison, <8 x i32> zeroinitializer
  %1679 = mul <8 x i64> %.splat787, splat (i64 32)
  %1680 = add <8 x i64> %1678, %1679
  %1681 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1677, 0
  %1682 = insertvalue { <8 x ptr>, <8 x i64> } %1681, <8 x i64> %1680, 1
  %1683 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1684 = extractvalue { <8 x ptr>, <8 x i64> } %1682, 1
  %1685 = extractelement <8 x ptr> %1683, i32 0
  %1686 = extractelement <8 x i64> %1684, i32 0
  %1687 = sub i64 %1686, 0
  %1688 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1689 = select i1 %1688, i64 %1687, i64 0
  %private.contiguous.address788 = getelementptr i8, ptr %1685, i64 %1689
  %private.contiguous.preserve789 = load <8 x float>, ptr %private.contiguous.address788, align 4
  %1690 = select <8 x i1> %71, <8 x float> %1676, <8 x float> %private.contiguous.preserve789
  store <8 x float> %1690, ptr %private.contiguous.address788, align 4
  %.state790 = load i64, ptr %.slot126, align 4
  %1691 = add i64 %.state790, 1
  store i64 %1691, ptr %.slot126, align 4
  br label %direct.schedule.82

direct.schedule.84:                               ; preds = %direct.false777
  %.state791 = load i64, ptr %.slot34, align 4
  %1692 = add i64 %.state791, 1
  %.spill.load792 = load <8 x float>, ptr %.spill114, align 32
  %.spill.load793 = load <8 x float>, ptr %.spill120, align 32
  store i64 %1692, ptr %.slot34, align 4
  %1693 = load <8 x float>, ptr %.slot35, align 32
  %1694 = select <8 x i1> %71, <8 x float> %.spill.load792, <8 x float> %1693
  store <8 x float> %1694, ptr %.slot35, align 32
  %1695 = load <8 x float>, ptr %.slot36, align 32
  %1696 = select <8 x i1> %71, <8 x float> %.spill.load793, <8 x float> %1695
  store <8 x float> %1696, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.85:                               ; preds = %direct.false163
  store i64 0, ptr %.slot127, align 4
  br label %direct.schedule.86

direct.schedule.86:                               ; preds = %direct.schedule.87, %direct.schedule.85
  %.state794 = load i64, ptr %.slot127, align 4
  %1697 = icmp slt i64 %.state794, 96
  br i1 %1697, label %direct.true795, label %direct.false796

direct.schedule.87:                               ; preds = %direct.true795
  %.spill.load797 = load i64, ptr %.spill29, align 4
  %1698 = add i64 %.spill.load797, 0
  %.spill.load798 = load <8 x i64>, ptr %.spill, align 64
  %1699 = add <8 x i64> %.spill.load798, zeroinitializer
  %1700 = mul i64 %1698, 8
  %.splatinsert799 = insertelement <8 x i64> poison, i64 %1700, i64 0
  %.splat800 = shufflevector <8 x i64> %.splatinsert799, <8 x i64> poison, <8 x i32> zeroinitializer
  %1701 = add <8 x i64> %.splat800, %1699
  %.spill.load801 = load i64, ptr %.spill29, align 4
  %1702 = add i64 %.spill.load801, 0
  %1703 = mul <8 x i64> %1701, splat (i64 1)
  %.splatinsert802 = insertelement <8 x i64> poison, i64 %1702, i64 0
  %.splat803 = shufflevector <8 x i64> %.splatinsert802, <8 x i64> poison, <8 x i32> zeroinitializer
  %1704 = add <8 x i64> %1703, %.splat803
  %.state804 = load i64, ptr %.slot127, align 4
  %1705 = add i64 0, %.state804
  %1706 = mul <8 x i64> %1704, splat (i64 96)
  %.splatinsert805 = insertelement <8 x i64> poison, i64 %1705, i64 0
  %.splat806 = shufflevector <8 x i64> %.splatinsert805, <8 x i64> poison, <8 x i32> zeroinitializer
  %1707 = add <8 x i64> %1706, %.splat806
  %.state807 = load i64, ptr %.slot127, align 4
  %1708 = add i64 0, %.state807
  %tile_snapshot.spill.load808 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load808, 0
  %1710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load808, 1
  %.splatinsert809 = insertelement <8 x i64> poison, i64 %1708, i64 0
  %.splat810 = shufflevector <8 x i64> %.splatinsert809, <8 x i64> poison, <8 x i32> zeroinitializer
  %1711 = mul <8 x i64> %.splat810, splat (i64 32)
  %1712 = add <8 x i64> %1710, %1711
  %1713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1709, 0
  %1714 = insertvalue { <8 x ptr>, <8 x i64> } %1713, <8 x i64> %1712, 1
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1716 = extractvalue { <8 x ptr>, <8 x i64> } %1714, 1
  %1717 = extractelement <8 x ptr> %1715, i32 0
  %1718 = extractelement <8 x i64> %1716, i32 0
  %1719 = sub i64 %1718, 0
  %1720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1721 = select i1 %1720, i64 %1719, i64 0
  %private.contiguous.address811 = getelementptr i8, ptr %1717, i64 %1721
  %private.contiguous.load812 = load <8 x float>, ptr %private.contiguous.address811, align 4
  %1722 = select <8 x i1> %71, <8 x float> %private.contiguous.load812, <8 x float> zeroinitializer
  %.state813 = load <8 x float>, ptr %.slot36, align 32
  %1723 = fdiv <8 x float> %1722, %.state813
  %1724 = extractvalue { ptr, i64 } %47, 0
  %1725 = mul <8 x i64> %1707, splat (i64 4)
  %1726 = getelementptr i8, ptr %1724, <8 x i64> %1725
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1723, <8 x ptr> align 1 %1726, <8 x i1> %71)
  %.state814 = load i64, ptr %.slot127, align 4
  %1727 = add i64 %.state814, 1
  store i64 %1727, ptr %.slot127, align 4
  br label %direct.schedule.86

direct.schedule.88:                               ; preds = %direct.false796
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true152:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false153:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true162:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false163:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.85

direct.true166:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false167:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true179:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false180:                                  ; preds = %direct.schedule.10
  %1728 = load <8 x float>, ptr %.slot41, align 32
  %1729 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1728
  store <8 x float> %1729, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.true191:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false192:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true204:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false205:                                  ; preds = %direct.schedule.15
  %1730 = load <8 x float>, ptr %.slot45, align 32
  %1731 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1730
  store <8 x float> %1731, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.true216:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false217:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true231:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false232:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true248:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false249:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true265:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false266:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true282:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false283:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true299:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false300:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true316:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false317:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true333:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false334:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true350:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false351:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true367:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false368:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true384:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false385:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true401:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false402:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true418:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false419:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true435:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false436:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true452:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false453:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true469:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false470:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true583:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false584:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true711:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false712:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true725:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false726:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.78

direct.true735:                                   ; preds = %direct.schedule.75
  br label %direct.schedule.76

direct.false736:                                  ; preds = %direct.schedule.75
  br label %direct.schedule.77

direct.true760:                                   ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false761:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.81

direct.true776:                                   ; preds = %direct.schedule.82
  br label %direct.schedule.83

direct.false777:                                  ; preds = %direct.schedule.82
  br label %direct.schedule.84

direct.true795:                                   ; preds = %direct.schedule.86
  br label %direct.schedule.87

direct.false796:                                  ; preds = %direct.schedule.86
  br label %direct.schedule.88
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(write) }

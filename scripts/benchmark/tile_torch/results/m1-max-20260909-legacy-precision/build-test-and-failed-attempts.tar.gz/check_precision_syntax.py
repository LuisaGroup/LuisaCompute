import hashlib
import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
repo = Path('/Users/mike/CLionProjects/luisa')
report = dict(runs=[])
files = ['src/tile/bridge/xir/lower.cpp', 'src/tile/bridge/tirx/lower.cpp', 'src/tile/bridge/tirx/execution.cpp',
         'src/backends/metal/tile/metal_tile.cpp', 'src/tests/unit/tile/test_tile_types.cpp',
         'src/tests/unit/tile/test_tile_migrated.cpp', 'src/tests/benchmark/benchmark_tile_migrated.cpp']
for i, name in enumerate(files):
    command = ['uv', 'run', '--offline', '--no-project', '--python', '3.13', '--with', 'orjson', 'python',
               repo/'scripts/check_cpp_syntax.py', '--compile-commands-dir', root/'build', '--project-root', root/'source', root/'source'/name]
    record = dict(file=name, argv=list(map(str,command)), started=time.time(), log=f'precision-syntax-{i}.log')
    report['runs'].append(record)
    with (root/record['log']).open('x') as log:
        p = subprocess.run(record['argv'],stdout=log,stderr=subprocess.STDOUT,timeout=90)
    record.update(exit_code=p.returncode, finished=time.time(), log_sha256=hashlib.sha256((root/record['log']).read_bytes()).hexdigest())
    (root/'precision-syntax.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name,p.returncode,flush=True)
report['passed'] = all(r['exit_code'] == 0 for r in report['runs'])
(root/'precision-syntax.json').write_text(json.dumps(report,indent=2)+'\n')

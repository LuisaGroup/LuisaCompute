"""Build/test exact low-precision task overlays, preserving every attempt."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
root = Path('/Users/mike/CLionProjects/luisa')
label = sys.argv[1]
files = list(json.loads((here/'migration-v5.json').read_text())['overlay']) + [
    'include/luisa/tile/types.h', 'include/luisa/tile/ir.h', 'include/luisa/tile/dsl.h',
    'include/luisa/tile/value.h', 'include/luisa/tile/runtime.h',
    'src/tile/bridge/xir/lower.cpp', 'src/tile/bridge/tirx/lower.cpp', 'src/tile/bridge/tirx/execution.cpp', 'src/backends/metal/tile/metal_tile.cpp',
    'src/tests/unit/tile/test_tile_types.cpp']
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
report = dict(label=label, base='2d02721b89980cd9191976c64b05d00b2342a03d',
              overlay={p:sha(root/p) for p in files}, runs=[])
for path in files:
    destination = here/'source'/path
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root/path, destination)
def run(name, args, timeout=600):
    result=dict(name=name,argv=list(map(str,args)),started_unix=time.time(),log=label+'-'+name+'.log')
    report['runs'].append(result)
    with (here/result['log']).open('x') as log:
        try:
            p=subprocess.run(result['argv'],cwd=here,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
            result['exit_code']=p.returncode
        except subprocess.TimeoutExpired:
            result.update(exit_code=None,timed_out=True)
    result.update(finished_unix=time.time(),log_sha256=sha(here/result['log']))
    (here/(label+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(name,result,flush=True)
    return result.get('exit_code') == 0
if not run('build',['cmake','--build',here/'build','--target','test_tile_types','test_tile_migrated','benchmark_tile_migrated','--parallel','4']):
    raise SystemExit(1)
if not run('types',['ctest','--test-dir',here/'build','-R','^test_tile_types(_simd|_metal)?$','--output-on-failure','--parallel','1'],600):
    raise SystemExit(1)
if not run('migration',['ctest','--test-dir',here/'build','-R','^test_tile_migrated(_simd|_metal)?$','--output-on-failure','--parallel','1'],600):
    raise SystemExit(1)

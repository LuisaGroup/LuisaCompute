import hashlib
import json
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
report = dict(source=json.loads((root/'precision-matrix-v1.json').read_text()), runs=[])
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for name, args in [
    ('build', ['cmake', '--build', root/'build', '--parallel', '4']),
    ('xir-simd', ['ctest', '--test-dir', root/'build', '-L', 'unit_xir|unit_simd', '--no-tests=error', '--output-on-failure']),
    ('tile', ['ctest', '--test-dir', root/'build', '-R', '^test_tile_', '--no-tests=error', '--output-on-failure']),
    ('metal-codegen', ['ctest', '--test-dir', root/'build', '-R', '^test_metal_local_codegen$', '--no-tests=error', '--output-on-failure']),
]:
    junit = root/f'precision-matrix-regression-{name}.xml'
    if name != 'build': args += ['--output-junit', junit]
    record = dict(name=name, argv=list(map(str,args)), started_unix=time.time(), log=f'precision-matrix-regression-{name}.log')
    report['runs'].append(record)
    with (root/record['log']).open('x') as log:
        p = subprocess.run(record['argv'], stdout=log, stderr=subprocess.STDOUT, timeout=1200)
    record.update(exit_code=p.returncode, finished_unix=time.time(), log_sha256=sha(root/record['log']))
    if name != 'build':
        cases = list(ET.parse(junit).getroot().iter('testcase'))
        record.update(tests=len(cases), failures=sum(c.find('failure') is not None or c.find('error') is not None for c in cases), skipped=sum(c.find('skipped') is not None for c in cases), junit=junit.name)
    (root/'precision-matrix-regression.json').write_text(json.dumps(report,indent=2)+'\n')
    print(record, flush=True)
    if p.returncode != 0: raise SystemExit(1)
report['passed'] = all(sha(root/'source'/p) == h for p,h in report['source']['overlay'].items())
(root/'precision-matrix-regression.json').write_text(json.dumps(report,indent=2)+'\n')

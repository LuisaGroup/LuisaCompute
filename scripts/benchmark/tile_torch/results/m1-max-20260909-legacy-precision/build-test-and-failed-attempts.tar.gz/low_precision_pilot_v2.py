"""Paired diagnostic migration measurements; retain every attempt and full checks."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
cpu_only = '--cpu-only' in sys.argv
out = root/('low-precision-cpu-replay' if cpu_only else 'low-precision-pilot')
out.mkdir()
binary = root/'build/bin/benchmark_tile_migrated'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
env = {k:v for k,v in os.environ.items() if not k.startswith(('LUISA_','DYLD_'))}
legacy = Path('/tmp/luisa-legacy-tile.5opuYg')
fp16 = Path('/tmp/luisa-legacy-exporter-v2.AoHQLS/fp16.ast.json')
cases = [
    ('metal','gemm_fp16',(512,512,512,16,16,32),fp16,(8192,32)),
    ('metal','cumsum',(1024,256,1,16,16,32),legacy/'cumsum.ast.json',(32768,1)),
    ('metal','cummax',(8192,512,1,16,16,32),legacy/'cummax.ast.json',(262144,1)),
    ('simd','rmsnorm',(2048,256,1,16,16,32),legacy/'rmsnorm.ast.json',(65536,1)),
    ('simd','sum',(8192,512,1,16,16,32),legacy/'sum.ast.json',(262144,1)),
]
report = dict(status='diagnostic_only_not_goal_acceptance', rounds=2, order=['legacy-modern','modern-legacy'],
              source_overlay=json.loads((root/'low-precision-v9.json').read_text())['overlay'],
              binaries={str(p):sha(p) for p in binary.parent.iterdir() if p.name in [binary.name,'libluisa-backend-metal.so','libluisa-backend-simd.so','libluisa-tile-bridge-tirx.dylib','libluisa-tile-bridge-xir.dylib','libluisa-tile.dylib','libluisa-benchmark-metal-timing.dylib']},
              cpu_timing='synchronized host-wall only, NOT native-entry-only', runs=[])
for backend,op,dims,ast,launch in cases:
    if cpu_only and backend != 'simd': continue
    run_env = dict(env)
    if backend == 'metal': run_env['LUISA_TILE_BENCH_METAL_TIMING'] = str(binary.parent/'libluisa-benchmark-metal-timing.dylib')
    for round_id in range(2):
        for route in (['legacy','modern'] if round_id==0 else ['modern','legacy']):
            prefix=out/f'{backend}-{op}-{round_id}-{route}'
            args=[str(binary),backend,op,*map(str,dims), '3','10','50',str(prefix)]
            if route=='legacy': args += [str(ast),*map(str,launch)]
            r=dict(backend=backend,operation=op,round=round_id,route=route,argv=args,log=prefix.name+'.log',started=time.time())
            report['runs'].append(r)
            if route=='legacy': r['ast_sha256']=sha(ast)
            with (out/r['log']).open('x') as log:
                try:
                    p=subprocess.run(args,env=run_env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
                    r['exit_code']=p.returncode
                except subprocess.TimeoutExpired:
                    r.update(exit_code=None,timed_out=True)
            r.update(finished=time.time(),log_sha256=sha(out/r['log']))
            if r.get('exit_code') == 0:
                r['result']=json.loads((out/r['log']).read_text().strip().splitlines()[-1])
                r['artifacts']={p.name:sha(p) for p in out.glob(prefix.name+'.*')}
            (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
            print(backend,op,round_id,route,r.get('exit_code'),r.get('result',{}).get('compile_ms'),flush=True)
assert all(sha(Path(p)) == digest for p,digest in report['binaries'].items())

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [24576 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [24576 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill4 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill4, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill7, align 4
  %tile_snapshot.spill8 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill8, align 64
  %.slot9 = alloca i64, align 8
  store i64 0, ptr %.slot9, align 4
  %.slot10 = alloca i64, align 8
  store i64 0, ptr %.slot10, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat12, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat14, %41
  %44 = mul i32 %32, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat16, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat18, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat20
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = zext <8 x i32> %53 to <8 x i64>
  %55 = select <8 x i1> %51, <8 x i64> %54, <8 x i64> zeroinitializer
  %56 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %57 = sdiv <8 x i64> %55, %56
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %51, <8 x i64> %57, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %61 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %62 = extractvalue { <8 x ptr>, <8 x i64> } %60, 0
  %63 = select <8 x i1> %51, <8 x ptr> %61, <8 x ptr> %62
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %60, 1
  %66 = select <8 x i1> %51, <8 x i64> %64, <8 x i64> %65
  %67 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %63, 0
  %68 = insertvalue { <8 x ptr>, <8 x i64> } %67, <8 x i64> %66, 1
  store { <8 x ptr>, <8 x i64> } %68, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %69 = icmp slt i64 %.state, 768
  br i1 %69, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %70 = add <8 x i64> %.spill.load, zeroinitializer
  %71 = add <8 x i64> zeroinitializer, %70
  %.state21 = load i64, ptr %.slot, align 4
  %72 = add i64 0, %.state21
  %73 = mul <8 x i64> %71, splat (i64 768)
  %.splatinsert22 = insertelement <8 x i64> poison, i64 %72, i64 0
  %.splat23 = shufflevector <8 x i64> %.splatinsert22, <8 x i64> poison, <8 x i32> zeroinitializer
  %74 = add <8 x i64> %73, %.splat23
  %75 = extractvalue { ptr, i64 } %9, 0
  %76 = mul <8 x i64> %74, splat (i64 4)
  %77 = getelementptr i8, ptr %75, <8 x i64> %76
  %78 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %77, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %79 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %80 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state24 = load i64, ptr %.slot, align 4
  %.splatinsert25 = insertelement <8 x i64> poison, i64 %.state24, i64 0
  %.splat26 = shufflevector <8 x i64> %.splatinsert25, <8 x i64> poison, <8 x i32> zeroinitializer
  %81 = mul <8 x i64> %.splat26, splat (i64 32)
  %82 = add <8 x i64> %80, %81
  %83 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %79, 0
  %84 = insertvalue { <8 x ptr>, <8 x i64> } %83, <8 x i64> %82, 1
  %85 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %84, 1
  %87 = extractelement <8 x ptr> %85, i32 0
  %88 = extractelement <8 x i64> %86, i32 0
  %89 = sub i64 %88, 0
  %90 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %91 = select i1 %90, i64 %89, i64 0
  %private.contiguous.address = getelementptr i8, ptr %87, i64 %91
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %92 = select <8 x i1> %51, <8 x float> %78, <8 x float> %private.contiguous.preserve
  store <8 x float> %92, ptr %private.contiguous.address, align 4
  %.state27 = load i64, ptr %.slot, align 4
  %93 = add i64 %.state27, 1
  store i64 %93, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 5.000000e-01, ptr %.spill4, align 4
  store float 0x3FA6E4E260000000, ptr %.spill5, align 4
  store float 0x3FE9884540000000, ptr %.spill6, align 4
  store float 1.000000e+00, ptr %.spill7, align 4
  %94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %94, 0
  %97 = select <8 x i1> %51, <8 x ptr> %95, <8 x ptr> %96
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %94, 1
  %100 = select <8 x i1> %51, <8 x i64> %98, <8 x i64> %99
  %101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %97, 0
  %102 = insertvalue { <8 x ptr>, <8 x i64> } %101, <8 x i64> %100, 1
  store { <8 x ptr>, <8 x i64> } %102, ptr %tile_snapshot.spill8, align 64
  store i64 0, ptr %.slot9, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state28 = load i64, ptr %.slot9, align 4
  %103 = icmp slt i64 %.state28, 768
  br i1 %103, label %direct.true29, label %direct.false30

direct.schedule.5:                                ; preds = %direct.true29
  %.spill.load31 = load <8 x i64>, ptr %.spill, align 64
  %104 = add <8 x i64> %.spill.load31, zeroinitializer
  %105 = add <8 x i64> zeroinitializer, %104
  %.state32 = load i64, ptr %.slot9, align 4
  %106 = add i64 0, %.state32
  %107 = mul <8 x i64> %105, splat (i64 768)
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %106, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %108 = add <8 x i64> %107, %.splat34
  %109 = extractvalue { ptr, i64 } %15, 0
  %110 = mul <8 x i64> %108, splat (i64 4)
  %111 = getelementptr i8, ptr %109, <8 x i64> %110
  %112 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %111, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load35 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %113 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 0
  %114 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 1
  %.state36 = load i64, ptr %.slot9, align 4
  %.splatinsert37 = insertelement <8 x i64> poison, i64 %.state36, i64 0
  %.splat38 = shufflevector <8 x i64> %.splatinsert37, <8 x i64> poison, <8 x i32> zeroinitializer
  %115 = mul <8 x i64> %.splat38, splat (i64 32)
  %116 = add <8 x i64> %114, %115
  %117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %113, 0
  %118 = insertvalue { <8 x ptr>, <8 x i64> } %117, <8 x i64> %116, 1
  %119 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %118, 1
  %121 = extractelement <8 x ptr> %119, i32 0
  %122 = extractelement <8 x i64> %120, i32 0
  %123 = sub i64 %122, 0
  %124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %125 = select i1 %124, i64 %123, i64 0
  %private.contiguous.address39 = getelementptr i8, ptr %121, i64 %125
  %private.contiguous.preserve40 = load <8 x float>, ptr %private.contiguous.address39, align 4
  %126 = select <8 x i1> %51, <8 x float> %112, <8 x float> %private.contiguous.preserve40
  store <8 x float> %126, ptr %private.contiguous.address39, align 4
  %.state41 = load i64, ptr %.slot9, align 4
  %127 = add i64 %.state41, 1
  store i64 %127, ptr %.slot9, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false30
  store i64 0, ptr %.slot10, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state42 = load i64, ptr %.slot10, align 4
  %128 = icmp slt i64 %.state42, 768
  br i1 %128, label %direct.true43, label %direct.false44

direct.schedule.8:                                ; preds = %direct.true43
  %.spill.load45 = load <8 x i64>, ptr %.spill, align 64
  %129 = add <8 x i64> %.spill.load45, zeroinitializer
  %130 = add <8 x i64> zeroinitializer, %129
  %.state46 = load i64, ptr %.slot10, align 4
  %131 = add i64 0, %.state46
  %132 = mul <8 x i64> %130, splat (i64 768)
  %.splatinsert47 = insertelement <8 x i64> poison, i64 %131, i64 0
  %.splat48 = shufflevector <8 x i64> %.splatinsert47, <8 x i64> poison, <8 x i32> zeroinitializer
  %133 = add <8 x i64> %132, %.splat48
  %.state49 = load i64, ptr %.slot10, align 4
  %134 = add i64 0, %.state49
  %135 = add i64 0, %134
  %136 = add i64 0, %135
  %tile_snapshot.spill.load50 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 0
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 1
  %.splatinsert51 = insertelement <8 x i64> poison, i64 %136, i64 0
  %.splat52 = shufflevector <8 x i64> %.splatinsert51, <8 x i64> poison, <8 x i32> zeroinitializer
  %139 = mul <8 x i64> %.splat52, splat (i64 32)
  %140 = add <8 x i64> %138, %139
  %141 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %137, 0
  %142 = insertvalue { <8 x ptr>, <8 x i64> } %141, <8 x i64> %140, 1
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %142, 1
  %145 = extractelement <8 x ptr> %143, i32 0
  %146 = extractelement <8 x i64> %144, i32 0
  %147 = sub i64 %146, 0
  %148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %149 = select i1 %148, i64 %147, i64 0
  %private.contiguous.address53 = getelementptr i8, ptr %145, i64 %149
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address53, align 4
  %150 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load54 = load float, ptr %.spill4, align 4
  %.splatinsert55 = insertelement <8 x float> poison, float %.spill.load54, i64 0
  %.splat56 = shufflevector <8 x float> %.splatinsert55, <8 x float> poison, <8 x i32> zeroinitializer
  %151 = fmul <8 x float> %.splat56, %150
  %152 = add i64 0, %136
  %153 = add i64 0, %152
  %154 = add i64 0, %153
  %tile_snapshot.spill.load57 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 0
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 1
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %154, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = mul <8 x i64> %.splat59, splat (i64 32)
  %158 = add <8 x i64> %156, %157
  %159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %155, 0
  %160 = insertvalue { <8 x ptr>, <8 x i64> } %159, <8 x i64> %158, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %160, 1
  %163 = extractelement <8 x ptr> %161, i32 0
  %164 = extractelement <8 x i64> %162, i32 0
  %165 = sub i64 %164, 0
  %166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %167 = select i1 %166, i64 %165, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %163, i64 %167
  %private.contiguous.load61 = load <8 x float>, ptr %private.contiguous.address60, align 4
  %168 = select <8 x i1> %51, <8 x float> %private.contiguous.load61, <8 x float> zeroinitializer
  %169 = add i64 0, %154
  %170 = add i64 0, %169
  %171 = add i64 0, %170
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %171, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %174 = mul <8 x i64> %.splat64, splat (i64 32)
  %175 = add <8 x i64> %173, %174
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %172, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = extractelement <8 x ptr> %178, i32 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %180, i64 %184
  %private.contiguous.load66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %185 = select <8 x i1> %51, <8 x float> %private.contiguous.load66, <8 x float> zeroinitializer
  %.spill.load67 = load float, ptr %.spill5, align 4
  %.splatinsert68 = insertelement <8 x float> poison, float %.spill.load67, i64 0
  %.splat69 = shufflevector <8 x float> %.splatinsert68, <8 x float> poison, <8 x i32> zeroinitializer
  %186 = fmul <8 x float> %.splat69, %185
  %tile_snapshot.spill.load70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 1
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %170, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %189 = mul <8 x i64> %.splat72, splat (i64 32)
  %190 = add <8 x i64> %188, %189
  %191 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %192 = insertvalue { <8 x ptr>, <8 x i64> } %191, <8 x i64> %190, 1
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %194 = extractvalue { <8 x ptr>, <8 x i64> } %192, 1
  %195 = extractelement <8 x ptr> %193, i32 0
  %196 = extractelement <8 x i64> %194, i32 0
  %197 = sub i64 %196, 0
  %198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %199 = select i1 %198, i64 %197, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %195, i64 %199
  %private.contiguous.load74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %200 = select <8 x i1> %51, <8 x float> %private.contiguous.load74, <8 x float> zeroinitializer
  %201 = fmul <8 x float> %186, %200
  %tile_snapshot.spill.load75 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 1
  %.splatinsert76 = insertelement <8 x i64> poison, i64 %169, i64 0
  %.splat77 = shufflevector <8 x i64> %.splatinsert76, <8 x i64> poison, <8 x i32> zeroinitializer
  %204 = mul <8 x i64> %.splat77, splat (i64 32)
  %205 = add <8 x i64> %203, %204
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %202, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %207, 1
  %210 = extractelement <8 x ptr> %208, i32 0
  %211 = extractelement <8 x i64> %209, i32 0
  %212 = sub i64 %211, 0
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.load79 = load <8 x float>, ptr %private.contiguous.address78, align 4
  %215 = select <8 x i1> %51, <8 x float> %private.contiguous.load79, <8 x float> zeroinitializer
  %216 = fmul <8 x float> %201, %215
  %217 = fadd <8 x float> %168, %216
  %.spill.load80 = load float, ptr %.spill6, align 4
  %.splatinsert81 = insertelement <8 x float> poison, float %.spill.load80, i64 0
  %.splat82 = shufflevector <8 x float> %.splatinsert81, <8 x float> poison, <8 x i32> zeroinitializer
  %218 = fmul <8 x float> %.splat82, %217
  %219 = select <8 x i1> %51, <8 x float> %218, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %219)
  %.spill.load83 = load float, ptr %.spill7, align 4
  %.splatinsert84 = insertelement <8 x float> poison, float %.spill.load83, i64 0
  %.splat85 = shufflevector <8 x float> %.splatinsert84, <8 x float> poison, <8 x i32> zeroinitializer
  %220 = fadd <8 x float> %.splat85, %native.tanh
  %221 = fmul <8 x float> %151, %220
  %tile_snapshot.spill.load86 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 1
  %.splatinsert87 = insertelement <8 x i64> poison, i64 %134, i64 0
  %.splat88 = shufflevector <8 x i64> %.splatinsert87, <8 x i64> poison, <8 x i32> zeroinitializer
  %224 = mul <8 x i64> %.splat88, splat (i64 32)
  %225 = add <8 x i64> %223, %224
  %226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %227 = insertvalue { <8 x ptr>, <8 x i64> } %226, <8 x i64> %225, 1
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %227, 1
  %230 = extractelement <8 x ptr> %228, i32 0
  %231 = extractelement <8 x i64> %229, i32 0
  %232 = sub i64 %231, 0
  %233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %234 = select i1 %233, i64 %232, i64 0
  %private.contiguous.address89 = getelementptr i8, ptr %230, i64 %234
  %private.contiguous.load90 = load <8 x float>, ptr %private.contiguous.address89, align 4
  %235 = select <8 x i1> %51, <8 x float> %private.contiguous.load90, <8 x float> zeroinitializer
  %236 = fadd <8 x float> %221, %235
  %237 = extractvalue { ptr, i64 } %27, 0
  %238 = mul <8 x i64> %133, splat (i64 4)
  %239 = getelementptr i8, ptr %237, <8 x i64> %238
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %236, <8 x ptr> %239, i32 1, <8 x i1> %51)
  %.state91 = load i64, ptr %.slot10, align 4
  %240 = add i64 %.state91, 1
  store i64 %240, ptr %.slot10, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false44
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true29:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false30:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true43:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false44:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %x) #2 {
entry:
  %0 = bitcast <8 x float> %x to <8 x i32>
  %1 = and <8 x i32> %0, splat (i32 2147483647)
  %2 = bitcast <8 x i32> %1 to <8 x float>
  %3 = fcmp contract ole <8 x float> %2, splat (float 1.000000e+00)
  %4 = fmul contract <8 x float> %2, %2
  %5 = fmul contract <8 x float> splat (float 0x3DE6124620000000), %4
  %6 = fadd contract <8 x float> %5, splat (float 0x3E5AE64560000000)
  %7 = fmul contract <8 x float> %6, %4
  %8 = fadd contract <8 x float> %7, splat (float 0x3EC71DE3A0000000)
  %9 = fmul contract <8 x float> %8, %4
  %10 = fadd contract <8 x float> %9, splat (float 0x3F2A01A020000000)
  %11 = fmul contract <8 x float> %10, %4
  %12 = fadd contract <8 x float> %11, splat (float 0x3F81111120000000)
  %13 = fmul contract <8 x float> %12, %4
  %14 = fadd contract <8 x float> %13, splat (float 0x3FC5555560000000)
  %15 = fmul contract <8 x float> %14, %4
  %16 = fadd contract <8 x float> %15, splat (float 1.000000e+00)
  %17 = fmul contract <8 x float> %2, %16
  %18 = fmul contract <8 x float> %2, %2
  %19 = fmul contract <8 x float> splat (float 0x3E21EED8E0000000), %18
  %20 = fadd contract <8 x float> %19, splat (float 0x3E927E4FC0000000)
  %21 = fmul contract <8 x float> %20, %18
  %22 = fadd contract <8 x float> %21, splat (float 0x3EFA01A020000000)
  %23 = fmul contract <8 x float> %22, %18
  %24 = fadd contract <8 x float> %23, splat (float 0x3F56C16C20000000)
  %25 = fmul contract <8 x float> %24, %18
  %26 = fadd contract <8 x float> %25, splat (float 0x3FA5555560000000)
  %27 = fmul contract <8 x float> %26, %18
  %28 = fadd contract <8 x float> %27, splat (float 5.000000e-01)
  %29 = fmul contract <8 x float> %28, %18
  %30 = fadd contract <8 x float> %29, splat (float 1.000000e+00)
  %31 = fdiv contract <8 x float> %17, %30
  %32 = fcmp contract ole <8 x float> %2, splat (float 9.000000e+00)
  %33 = select contract <8 x i1> %32, <8 x float> %2, <8 x float> zeroinitializer
  %exp.half = call contract <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %33)
  %34 = fdiv contract <8 x float> splat (float 2.500000e-01), %exp.half
  %35 = fsub contract <8 x float> %exp.half, %34
  %36 = fadd contract <8 x float> %exp.half, %34
  %37 = fdiv contract <8 x float> %35, %36
  %38 = select contract <8 x i1> %32, <8 x float> %37, <8 x float> splat (float 1.000000e+00)
  %39 = select contract <8 x i1> %3, <8 x float> %31, <8 x float> %38
  %40 = bitcast <8 x float> %39 to <8 x i32>
  %41 = and <8 x i32> %40, splat (i32 2147483647)
  %42 = bitcast <8 x float> %x to <8 x i32>
  %43 = and <8 x i32> %42, splat (i32 -2147483648)
  %44 = or <8 x i32> %41, %43
  %45 = bitcast <8 x i32> %44 to <8 x float>
  %46 = fcmp contract uno <8 x float> %x, %x
  %47 = select contract <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %x) #2 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = sub <8 x i32> %11, splat (i32 1)
  %32 = ashr <8 x i32> %31, splat (i32 1)
  %33 = add <8 x i32> %32, splat (i32 127)
  %34 = shl <8 x i32> %33, splat (i32 23)
  %35 = bitcast <8 x i32> %34 to <8 x float>
  %36 = fmul <8 x float> %30, %35
  %37 = sub <8 x i32> %31, %32
  %38 = add <8 x i32> %37, splat (i32 127)
  %39 = shl <8 x i32> %38, splat (i32 23)
  %40 = bitcast <8 x i32> %39 to <8 x float>
  %41 = fmul <8 x float> %36, %40
  %42 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %43 = select <8 x i1> %42, <8 x float> zeroinitializer, <8 x float> %41
  %44 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %45 = select <8 x i1> %44, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %43
  %46 = fcmp uno <8 x float> %x, %x
  %47 = select <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [24576 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [24576 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill4 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill4, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill7, align 4
  %tile_snapshot.spill8 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill8, align 64
  %.slot9 = alloca i64, align 8
  store i64 0, ptr %.slot9, align 4
  %.slot10 = alloca i64, align 8
  store i64 0, ptr %.slot10, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat12, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat14, %41
  %44 = mul i32 %32, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat16, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat18, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert19 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat20
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = zext <8 x i32> %53 to <8 x i64>
  %55 = select <8 x i1> %51, <8 x i64> %54, <8 x i64> zeroinitializer
  %56 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %57 = sdiv <8 x i64> %55, %56
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %51, <8 x i64> %57, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %61 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %62 = extractvalue { <8 x ptr>, <8 x i64> } %60, 0
  %63 = select <8 x i1> %51, <8 x ptr> %61, <8 x ptr> %62
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %60, 1
  %66 = select <8 x i1> %51, <8 x i64> %64, <8 x i64> %65
  %67 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %63, 0
  %68 = insertvalue { <8 x ptr>, <8 x i64> } %67, <8 x i64> %66, 1
  store { <8 x ptr>, <8 x i64> } %68, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %69 = icmp slt i64 %.state, 768
  br i1 %69, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %70 = add <8 x i64> %.spill.load, zeroinitializer
  %71 = add <8 x i64> zeroinitializer, %70
  %.state21 = load i64, ptr %.slot, align 4
  %72 = add i64 0, %.state21
  %73 = mul <8 x i64> %71, splat (i64 768)
  %.splatinsert22 = insertelement <8 x i64> poison, i64 %72, i64 0
  %.splat23 = shufflevector <8 x i64> %.splatinsert22, <8 x i64> poison, <8 x i32> zeroinitializer
  %74 = add <8 x i64> %73, %.splat23
  %75 = extractvalue { ptr, i64 } %9, 0
  %76 = mul <8 x i64> %74, splat (i64 4)
  %77 = getelementptr i8, ptr %75, <8 x i64> %76
  %78 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %77, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %79 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %80 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state24 = load i64, ptr %.slot, align 4
  %.splatinsert25 = insertelement <8 x i64> poison, i64 %.state24, i64 0
  %.splat26 = shufflevector <8 x i64> %.splatinsert25, <8 x i64> poison, <8 x i32> zeroinitializer
  %81 = mul <8 x i64> %.splat26, splat (i64 32)
  %82 = add <8 x i64> %80, %81
  %83 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %79, 0
  %84 = insertvalue { <8 x ptr>, <8 x i64> } %83, <8 x i64> %82, 1
  %85 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %84, 1
  %87 = extractelement <8 x ptr> %85, i32 0
  %88 = extractelement <8 x i64> %86, i32 0
  %89 = sub i64 %88, 0
  %90 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %91 = select i1 %90, i64 %89, i64 0
  %private.contiguous.address = getelementptr i8, ptr %87, i64 %91
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %92 = select <8 x i1> %51, <8 x float> %78, <8 x float> %private.contiguous.preserve
  store <8 x float> %92, ptr %private.contiguous.address, align 4
  %.state27 = load i64, ptr %.slot, align 4
  %93 = add i64 %.state27, 1
  store i64 %93, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 5.000000e-01, ptr %.spill4, align 4
  store float 0x3FA6E4E260000000, ptr %.spill5, align 4
  store float 0x3FE9884540000000, ptr %.spill6, align 4
  store float 1.000000e+00, ptr %.spill7, align 4
  %94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %94, 0
  %97 = select <8 x i1> %51, <8 x ptr> %95, <8 x ptr> %96
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %94, 1
  %100 = select <8 x i1> %51, <8 x i64> %98, <8 x i64> %99
  %101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %97, 0
  %102 = insertvalue { <8 x ptr>, <8 x i64> } %101, <8 x i64> %100, 1
  store { <8 x ptr>, <8 x i64> } %102, ptr %tile_snapshot.spill8, align 64
  store i64 0, ptr %.slot9, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state28 = load i64, ptr %.slot9, align 4
  %103 = icmp slt i64 %.state28, 768
  br i1 %103, label %direct.true29, label %direct.false30

direct.schedule.5:                                ; preds = %direct.true29
  %.spill.load31 = load <8 x i64>, ptr %.spill, align 64
  %104 = add <8 x i64> %.spill.load31, zeroinitializer
  %105 = add <8 x i64> zeroinitializer, %104
  %.state32 = load i64, ptr %.slot9, align 4
  %106 = add i64 0, %.state32
  %107 = mul <8 x i64> %105, splat (i64 768)
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %106, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %108 = add <8 x i64> %107, %.splat34
  %109 = extractvalue { ptr, i64 } %15, 0
  %110 = mul <8 x i64> %108, splat (i64 4)
  %111 = getelementptr i8, ptr %109, <8 x i64> %110
  %112 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %111, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load35 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %113 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 0
  %114 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 1
  %.state36 = load i64, ptr %.slot9, align 4
  %.splatinsert37 = insertelement <8 x i64> poison, i64 %.state36, i64 0
  %.splat38 = shufflevector <8 x i64> %.splatinsert37, <8 x i64> poison, <8 x i32> zeroinitializer
  %115 = mul <8 x i64> %.splat38, splat (i64 32)
  %116 = add <8 x i64> %114, %115
  %117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %113, 0
  %118 = insertvalue { <8 x ptr>, <8 x i64> } %117, <8 x i64> %116, 1
  %119 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %118, 1
  %121 = extractelement <8 x ptr> %119, i32 0
  %122 = extractelement <8 x i64> %120, i32 0
  %123 = sub i64 %122, 0
  %124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %125 = select i1 %124, i64 %123, i64 0
  %private.contiguous.address39 = getelementptr i8, ptr %121, i64 %125
  %private.contiguous.preserve40 = load <8 x float>, ptr %private.contiguous.address39, align 4
  %126 = select <8 x i1> %51, <8 x float> %112, <8 x float> %private.contiguous.preserve40
  store <8 x float> %126, ptr %private.contiguous.address39, align 4
  %.state41 = load i64, ptr %.slot9, align 4
  %127 = add i64 %.state41, 1
  store i64 %127, ptr %.slot9, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false30
  store i64 0, ptr %.slot10, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state42 = load i64, ptr %.slot10, align 4
  %128 = icmp slt i64 %.state42, 768
  br i1 %128, label %direct.true43, label %direct.false44

direct.schedule.8:                                ; preds = %direct.true43
  %.spill.load45 = load <8 x i64>, ptr %.spill, align 64
  %129 = add <8 x i64> %.spill.load45, zeroinitializer
  %130 = add <8 x i64> zeroinitializer, %129
  %.state46 = load i64, ptr %.slot10, align 4
  %131 = add i64 0, %.state46
  %132 = mul <8 x i64> %130, splat (i64 768)
  %.splatinsert47 = insertelement <8 x i64> poison, i64 %131, i64 0
  %.splat48 = shufflevector <8 x i64> %.splatinsert47, <8 x i64> poison, <8 x i32> zeroinitializer
  %133 = add <8 x i64> %132, %.splat48
  %.state49 = load i64, ptr %.slot10, align 4
  %134 = add i64 0, %.state49
  %135 = add i64 0, %134
  %136 = add i64 0, %135
  %tile_snapshot.spill.load50 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 0
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 1
  %.splatinsert51 = insertelement <8 x i64> poison, i64 %136, i64 0
  %.splat52 = shufflevector <8 x i64> %.splatinsert51, <8 x i64> poison, <8 x i32> zeroinitializer
  %139 = mul <8 x i64> %.splat52, splat (i64 32)
  %140 = add <8 x i64> %138, %139
  %141 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %137, 0
  %142 = insertvalue { <8 x ptr>, <8 x i64> } %141, <8 x i64> %140, 1
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %142, 1
  %145 = extractelement <8 x ptr> %143, i32 0
  %146 = extractelement <8 x i64> %144, i32 0
  %147 = sub i64 %146, 0
  %148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %149 = select i1 %148, i64 %147, i64 0
  %private.contiguous.address53 = getelementptr i8, ptr %145, i64 %149
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address53, align 4
  %150 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load54 = load float, ptr %.spill4, align 4
  %.splatinsert55 = insertelement <8 x float> poison, float %.spill.load54, i64 0
  %.splat56 = shufflevector <8 x float> %.splatinsert55, <8 x float> poison, <8 x i32> zeroinitializer
  %151 = fmul <8 x float> %.splat56, %150
  %152 = add i64 0, %136
  %153 = add i64 0, %152
  %154 = add i64 0, %153
  %tile_snapshot.spill.load57 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 0
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 1
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %154, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = mul <8 x i64> %.splat59, splat (i64 32)
  %158 = add <8 x i64> %156, %157
  %159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %155, 0
  %160 = insertvalue { <8 x ptr>, <8 x i64> } %159, <8 x i64> %158, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %160, 1
  %163 = extractelement <8 x ptr> %161, i32 0
  %164 = extractelement <8 x i64> %162, i32 0
  %165 = sub i64 %164, 0
  %166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %167 = select i1 %166, i64 %165, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %163, i64 %167
  %private.contiguous.load61 = load <8 x float>, ptr %private.contiguous.address60, align 4
  %168 = select <8 x i1> %51, <8 x float> %private.contiguous.load61, <8 x float> zeroinitializer
  %169 = add i64 0, %154
  %170 = add i64 0, %169
  %171 = add i64 0, %170
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %171, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %174 = mul <8 x i64> %.splat64, splat (i64 32)
  %175 = add <8 x i64> %173, %174
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %172, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = extractelement <8 x ptr> %178, i32 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %180, i64 %184
  %private.contiguous.load66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %185 = select <8 x i1> %51, <8 x float> %private.contiguous.load66, <8 x float> zeroinitializer
  %.spill.load67 = load float, ptr %.spill5, align 4
  %.splatinsert68 = insertelement <8 x float> poison, float %.spill.load67, i64 0
  %.splat69 = shufflevector <8 x float> %.splatinsert68, <8 x float> poison, <8 x i32> zeroinitializer
  %186 = fmul <8 x float> %.splat69, %185
  %tile_snapshot.spill.load70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 1
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %170, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %189 = mul <8 x i64> %.splat72, splat (i64 32)
  %190 = add <8 x i64> %188, %189
  %191 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %192 = insertvalue { <8 x ptr>, <8 x i64> } %191, <8 x i64> %190, 1
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %194 = extractvalue { <8 x ptr>, <8 x i64> } %192, 1
  %195 = extractelement <8 x ptr> %193, i32 0
  %196 = extractelement <8 x i64> %194, i32 0
  %197 = sub i64 %196, 0
  %198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %199 = select i1 %198, i64 %197, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %195, i64 %199
  %private.contiguous.load74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %200 = select <8 x i1> %51, <8 x float> %private.contiguous.load74, <8 x float> zeroinitializer
  %201 = fmul <8 x float> %186, %200
  %tile_snapshot.spill.load75 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 1
  %.splatinsert76 = insertelement <8 x i64> poison, i64 %169, i64 0
  %.splat77 = shufflevector <8 x i64> %.splatinsert76, <8 x i64> poison, <8 x i32> zeroinitializer
  %204 = mul <8 x i64> %.splat77, splat (i64 32)
  %205 = add <8 x i64> %203, %204
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %202, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %207, 1
  %210 = extractelement <8 x ptr> %208, i32 0
  %211 = extractelement <8 x i64> %209, i32 0
  %212 = sub i64 %211, 0
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.load79 = load <8 x float>, ptr %private.contiguous.address78, align 4
  %215 = select <8 x i1> %51, <8 x float> %private.contiguous.load79, <8 x float> zeroinitializer
  %216 = fmul <8 x float> %201, %215
  %217 = fadd <8 x float> %168, %216
  %.spill.load80 = load float, ptr %.spill6, align 4
  %.splatinsert81 = insertelement <8 x float> poison, float %.spill.load80, i64 0
  %.splat82 = shufflevector <8 x float> %.splatinsert81, <8 x float> poison, <8 x i32> zeroinitializer
  %218 = fmul <8 x float> %.splat82, %217
  %219 = select <8 x i1> %51, <8 x float> %218, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %219)
  %.spill.load83 = load float, ptr %.spill7, align 4
  %.splatinsert84 = insertelement <8 x float> poison, float %.spill.load83, i64 0
  %.splat85 = shufflevector <8 x float> %.splatinsert84, <8 x float> poison, <8 x i32> zeroinitializer
  %220 = fadd <8 x float> %.splat85, %native.tanh
  %221 = fmul <8 x float> %151, %220
  %tile_snapshot.spill.load86 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 1
  %.splatinsert87 = insertelement <8 x i64> poison, i64 %134, i64 0
  %.splat88 = shufflevector <8 x i64> %.splatinsert87, <8 x i64> poison, <8 x i32> zeroinitializer
  %224 = mul <8 x i64> %.splat88, splat (i64 32)
  %225 = add <8 x i64> %223, %224
  %226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %227 = insertvalue { <8 x ptr>, <8 x i64> } %226, <8 x i64> %225, 1
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %227, 1
  %230 = extractelement <8 x ptr> %228, i32 0
  %231 = extractelement <8 x i64> %229, i32 0
  %232 = sub i64 %231, 0
  %233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %234 = select i1 %233, i64 %232, i64 0
  %private.contiguous.address89 = getelementptr i8, ptr %230, i64 %234
  %private.contiguous.load90 = load <8 x float>, ptr %private.contiguous.address89, align 4
  %235 = select <8 x i1> %51, <8 x float> %private.contiguous.load90, <8 x float> zeroinitializer
  %236 = fadd <8 x float> %221, %235
  %237 = extractvalue { ptr, i64 } %27, 0
  %238 = mul <8 x i64> %133, splat (i64 4)
  %239 = getelementptr i8, ptr %237, <8 x i64> %238
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %236, <8 x ptr> %239, i32 1, <8 x i1> %51)
  %.state91 = load i64, ptr %.slot10, align 4
  %240 = add i64 %.state91, 1
  store i64 %240, ptr %.slot10, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false44
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true29:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false30:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true43:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false44:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }

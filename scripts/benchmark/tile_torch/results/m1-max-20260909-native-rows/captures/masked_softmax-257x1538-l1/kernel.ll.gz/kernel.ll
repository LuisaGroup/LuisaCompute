; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 49216
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 147648
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 1538, i64 3076, i64 4614, i64 6152, i64 7690, i64 9228, i64 10766>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 159952
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 209168
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %.spill19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill19, align 64
  %tile_snapshot.spill20 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill20, align 64
  %.slot21 = alloca i64, align 8
  store i64 0, ptr %.slot21, align 4
  %.spill22 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill22, align 4
  %tile_snapshot.spill23 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill23, align 64
  %.slot24 = alloca i64, align 8
  store i64 0, ptr %.slot24, align 4
  %.spill25 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill25, align 4
  %.spill26 = alloca i64, align 8
  store i64 0, ptr %.spill26, align 4
  %.spill27 = alloca i64, align 8
  store i64 0, ptr %.spill27, align 4
  %.spill28 = alloca i64, align 8
  store i64 0, ptr %.spill28, align 4
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca i64, align 8
  store i64 0, ptr %.spill30, align 4
  %.slot31 = alloca i64, align 8
  store i64 0, ptr %.slot31, align 4
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.spill36 = alloca i64, align 8
  store i64 0, ptr %.spill36, align 4
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %.spill38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill38, align 32
  %.spill39 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill39, align 4
  %tile_snapshot.spill40 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill40, align 64
  %.slot41 = alloca i64, align 8
  store i64 0, ptr %.slot41, align 4
  %.slot42 = alloca i64, align 8
  store i64 0, ptr %.slot42, align 4
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %.spill47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill47, align 32
  %.slot48 = alloca i64, align 8
  store i64 0, ptr %.slot48, align 4
  %15 = getelementptr i8, ptr %argument_buffer, i64 0
  %16 = load ptr, ptr %15, align 16
  %17 = getelementptr i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  %21 = getelementptr i8, ptr %argument_buffer, i64 16
  %22 = load ptr, ptr %21, align 16
  %23 = getelementptr i8, ptr %21, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = insertvalue { ptr, i64 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i64 } %25, i64 %24, 1
  %27 = getelementptr i8, ptr %argument_buffer, i64 32
  %28 = load ptr, ptr %27, align 16
  %29 = getelementptr i8, ptr %27, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { ptr, i64 } poison, ptr %28, 0
  %32 = insertvalue { ptr, i64 } %31, i64 %30, 1
  %33 = getelementptr i8, ptr %argument_buffer, i64 48
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = load i32, ptr %launch_config, align 4
  %40 = getelementptr i8, ptr %launch_config, i64 12
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr i8, ptr %launch_config, i64 4
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %launch_config, i64 16
  %45 = load i32, ptr %44, align 4
  %46 = getelementptr i8, ptr %launch_config, i64 8
  %47 = load i32, ptr %46, align 4
  %48 = getelementptr i8, ptr %launch_config, i64 20
  %49 = load i32, ptr %48, align 4
  %50 = getelementptr i8, ptr %launch_config, i64 36
  %51 = load i32, ptr %50, align 4
  %.splatinsert49 = insertelement <8 x i32> poison, i32 %51, i64 0
  %.splat50 = shufflevector <8 x i32> %.splatinsert49, <8 x i32> poison, <8 x i32> zeroinitializer
  %52 = add <8 x i32> %.splat50, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %53 = mul i32 %39, 32
  %.splatinsert51 = insertelement <8 x i32> poison, i32 %53, i64 0
  %.splat52 = shufflevector <8 x i32> %.splatinsert51, <8 x i32> poison, <8 x i32> zeroinitializer
  %54 = add <8 x i32> %.splat52, %52
  %55 = mul i32 %43, 1
  %.splatinsert53 = insertelement <8 x i32> poison, i32 %55, i64 0
  %.splat54 = shufflevector <8 x i32> %.splatinsert53, <8 x i32> poison, <8 x i32> zeroinitializer
  %56 = add <8 x i32> %.splat54, zeroinitializer
  %57 = mul i32 %47, 1
  %.splatinsert55 = insertelement <8 x i32> poison, i32 %57, i64 0
  %.splat56 = shufflevector <8 x i32> %.splatinsert55, <8 x i32> poison, <8 x i32> zeroinitializer
  %58 = add <8 x i32> %.splat56, zeroinitializer
  %59 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %54, 0
  %60 = insertvalue [3 x <8 x i32>] %59, <8 x i32> %56, 1
  %61 = insertvalue [3 x <8 x i32>] %60, <8 x i32> %58, 2
  %.splatinsert57 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat58 = shufflevector <8 x i32> %.splatinsert57, <8 x i32> poison, <8 x i32> zeroinitializer
  %62 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat58
  %63 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  br i1 %63, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %64 = extractvalue [3 x <8 x i32>] %61, 0
  %65 = zext <8 x i32> %64 to <8 x i64>
  %66 = select <8 x i1> %62, <8 x i64> %65, <8 x i64> zeroinitializer
  %67 = select <8 x i1> %62, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %68 = sdiv <8 x i64> %66, %67
  %69 = load <8 x i64>, ptr %.spill, align 64
  %70 = select <8 x i1> %62, <8 x i64> %68, <8 x i64> %69
  store <8 x i64> %70, ptr %.spill, align 64
  %71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %71, 0
  %74 = select <8 x i1> %62, <8 x ptr> %72, <8 x ptr> %73
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %71, 1
  %77 = select <8 x i1> %62, <8 x i64> %75, <8 x i64> %76
  %78 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %74, 0
  %79 = insertvalue { <8 x ptr>, <8 x i64> } %78, <8 x i64> %77, 1
  store { <8 x ptr>, <8 x i64> } %79, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %80 = icmp slt i64 %.state, 1538
  br i1 %80, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.spill.load, zeroinitializer
  %82 = add <8 x i64> zeroinitializer, %81
  %.state59 = load i64, ptr %.slot, align 4
  %83 = add i64 0, %.state59
  %84 = mul <8 x i64> %82, splat (i64 1538)
  %.splatinsert60 = insertelement <8 x i64> poison, i64 %83, i64 0
  %.splat61 = shufflevector <8 x i64> %.splatinsert60, <8 x i64> poison, <8 x i32> zeroinitializer
  %85 = add <8 x i64> %84, %.splat61
  %86 = extractvalue { ptr, i64 } %20, 0
  %87 = mul <8 x i64> %85, splat (i64 4)
  %88 = getelementptr i8, ptr %86, <8 x i64> %87
  %89 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %88, i32 1, <8 x i1> %62, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state62 = load i64, ptr %.slot, align 4
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %.state62, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %92 = mul <8 x i64> %.splat64, splat (i64 32)
  %93 = add <8 x i64> %91, %92
  %94 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %90, 0
  %95 = insertvalue { <8 x ptr>, <8 x i64> } %94, <8 x i64> %93, 1
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %95, 1
  %98 = extractelement <8 x ptr> %96, i32 0
  %99 = extractelement <8 x i64> %97, i32 0
  %100 = sub i64 %99, 0
  %101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %102 = select i1 %101, i64 %100, i64 0
  %private.contiguous.address = getelementptr i8, ptr %98, i64 %102
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %103 = select <8 x i1> %62, <8 x float> %89, <8 x float> %private.contiguous.preserve
  store <8 x float> %103, ptr %private.contiguous.address, align 4
  %.state65 = load i64, ptr %.slot, align 4
  %104 = add i64 %.state65, 1
  store i64 %104, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %105 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %105, 0
  %108 = select <8 x i1> %62, <8 x ptr> %106, <8 x ptr> %107
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %105, 1
  %111 = select <8 x i1> %62, <8 x i64> %109, <8 x i64> %110
  %112 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %108, 0
  %113 = insertvalue { <8 x ptr>, <8 x i64> } %112, <8 x i64> %111, 1
  store { <8 x ptr>, <8 x i64> } %113, ptr %tile_snapshot.spill17, align 64
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state66 = load i64, ptr %.slot18, align 4
  %114 = icmp slt i64 %.state66, 1538
  br i1 %114, label %direct.true67, label %direct.false68

direct.schedule.5:                                ; preds = %direct.true67
  %tile_snapshot.spill.load69 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 1
  %.state70 = load i64, ptr %.slot18, align 4
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %.state70, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %117 = mul <8 x i64> %.splat72, splat (i64 64)
  %118 = add <8 x i64> %116, %117
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %.state73 = load i64, ptr %.slot18, align 4
  %.splatinsert74 = insertelement <8 x i64> poison, i64 %.state73, i64 0
  %.splat75 = shufflevector <8 x i64> %.splatinsert74, <8 x i64> poison, <8 x i32> zeroinitializer
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address76 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve77 = load <8 x i64>, ptr %private.contiguous.address76, align 8
  %128 = select <8 x i1> %62, <8 x i64> %.splat75, <8 x i64> %private.contiguous.preserve77
  store <8 x i64> %128, ptr %private.contiguous.address76, align 8
  %.state78 = load i64, ptr %.slot18, align 4
  %129 = add i64 %.state78, 1
  store i64 %129, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false68
  %.spill.load79 = load <8 x i64>, ptr %.spill, align 64
  %130 = select <8 x i1> %62, <8 x i64> %.spill.load79, <8 x i64> zeroinitializer
  %131 = select <8 x i1> %62, <8 x i64> splat (i64 1538), <8 x i64> splat (i64 1)
  %132 = srem <8 x i64> %130, %131
  %133 = load <8 x i64>, ptr %.spill19, align 64
  %134 = select <8 x i1> %62, <8 x i64> %132, <8 x i64> %133
  store <8 x i64> %134, ptr %.spill19, align 64
  %135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %135, 0
  %138 = select <8 x i1> %62, <8 x ptr> %136, <8 x ptr> %137
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %135, 1
  %141 = select <8 x i1> %62, <8 x i64> %139, <8 x i64> %140
  %142 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %138, 0
  %143 = insertvalue { <8 x ptr>, <8 x i64> } %142, <8 x i64> %141, 1
  store { <8 x ptr>, <8 x i64> } %143, ptr %tile_snapshot.spill20, align 64
  store i64 0, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state80 = load i64, ptr %.slot21, align 4
  %144 = icmp slt i64 %.state80, 1538
  br i1 %144, label %direct.true81, label %direct.false82

direct.schedule.8:                                ; preds = %direct.true81
  %.state83 = load i64, ptr %.slot21, align 4
  %145 = add i64 0, %.state83
  %tile_snapshot.spill.load84 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load84, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load84, 1
  %.splatinsert85 = insertelement <8 x i64> poison, i64 %145, i64 0
  %.splat86 = shufflevector <8 x i64> %.splatinsert85, <8 x i64> poison, <8 x i32> zeroinitializer
  %148 = mul <8 x i64> %.splat86, splat (i64 64)
  %149 = add <8 x i64> %147, %148
  %150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %146, 0
  %151 = insertvalue { <8 x ptr>, <8 x i64> } %150, <8 x i64> %149, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %154 = extractelement <8 x ptr> %152, i32 0
  %155 = extractelement <8 x i64> %153, i32 0
  %156 = sub i64 %155, 0
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %158 = select i1 %157, i64 %156, i64 0
  %private.contiguous.address87 = getelementptr i8, ptr %154, i64 %158
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address87, align 8
  %159 = select <8 x i1> %62, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load88 = load <8 x i64>, ptr %.spill19, align 64
  %160 = icmp sle <8 x i64> %159, %.spill.load88
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %.state90 = load i64, ptr %.slot21, align 4
  %.splatinsert91 = insertelement <8 x i64> poison, i64 %.state90, i64 0
  %.splat92 = shufflevector <8 x i64> %.splatinsert91, <8 x i64> poison, <8 x i32> zeroinitializer
  %163 = add <8 x i64> %162, %.splat92
  %164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %161, 0
  %165 = insertvalue { <8 x ptr>, <8 x i64> } %164, <8 x i64> %163, 1
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %168 = getelementptr i8, <8 x ptr> %166, <8 x i64> %167
  %169 = zext <8 x i1> %160 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %169, <8 x ptr> %168, i32 1, <8 x i1> %62)
  %.state93 = load i64, ptr %.slot21, align 4
  %170 = add i64 %.state93, 1
  store i64 %170, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false82
  store float 0xC6293E5940000000, ptr %.spill22, align 4
  %171 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 0
  %174 = select <8 x i1> %62, <8 x ptr> %172, <8 x ptr> %173
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %177 = select <8 x i1> %62, <8 x i64> %175, <8 x i64> %176
  %178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %174, 0
  %179 = insertvalue { <8 x ptr>, <8 x i64> } %178, <8 x i64> %177, 1
  store { <8 x ptr>, <8 x i64> } %179, ptr %tile_snapshot.spill23, align 64
  store i64 0, ptr %.slot24, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state94 = load i64, ptr %.slot24, align 4
  %180 = icmp slt i64 %.state94, 1538
  br i1 %180, label %direct.true95, label %direct.false96

direct.schedule.11:                               ; preds = %direct.true95
  %.state97 = load i64, ptr %.slot24, align 4
  %181 = add i64 0, %.state97
  %tile_snapshot.spill.load98 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 1
  %.splatinsert99 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat100 = shufflevector <8 x i64> %.splatinsert99, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = add <8 x i64> %183, %.splat100
  %185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %182, 0
  %186 = insertvalue { <8 x ptr>, <8 x i64> } %185, <8 x i64> %184, 1
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %186, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %186, 1
  %189 = getelementptr i8, <8 x ptr> %187, <8 x i64> %188
  %190 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %189, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %191 = icmp ne <8 x i8> %190, zeroinitializer
  %tile_snapshot.spill.load101 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 1
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %194 = mul <8 x i64> %.splat103, splat (i64 32)
  %195 = add <8 x i64> %193, %194
  %196 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %192, 0
  %197 = insertvalue { <8 x ptr>, <8 x i64> } %196, <8 x i64> %195, 1
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %197, 1
  %200 = extractelement <8 x ptr> %198, i32 0
  %201 = extractelement <8 x i64> %199, i32 0
  %202 = sub i64 %201, 0
  %203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %204 = select i1 %203, i64 %202, i64 0
  %private.contiguous.address104 = getelementptr i8, ptr %200, i64 %204
  %private.contiguous.load105 = load <8 x float>, ptr %private.contiguous.address104, align 4
  %205 = select <8 x i1> %62, <8 x float> %private.contiguous.load105, <8 x float> zeroinitializer
  %.spill.load106 = load float, ptr %.spill22, align 4
  %.splatinsert107 = insertelement <8 x float> poison, float %.spill.load106, i64 0
  %.splat108 = shufflevector <8 x float> %.splatinsert107, <8 x float> poison, <8 x i32> zeroinitializer
  %206 = select <8 x i1> %191, <8 x float> %205, <8 x float> %.splat108
  %tile_snapshot.spill.load109 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 0
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 1
  %.state110 = load i64, ptr %.slot24, align 4
  %.splatinsert111 = insertelement <8 x i64> poison, i64 %.state110, i64 0
  %.splat112 = shufflevector <8 x i64> %.splatinsert111, <8 x i64> poison, <8 x i32> zeroinitializer
  %209 = mul <8 x i64> %.splat112, splat (i64 32)
  %210 = add <8 x i64> %208, %209
  %211 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %207, 0
  %212 = insertvalue { <8 x ptr>, <8 x i64> } %211, <8 x i64> %210, 1
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %212, 1
  %215 = extractelement <8 x ptr> %213, i32 0
  %216 = extractelement <8 x i64> %214, i32 0
  %217 = sub i64 %216, 0
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %219 = select i1 %218, i64 %217, i64 0
  %private.contiguous.address113 = getelementptr i8, ptr %215, i64 %219
  %private.contiguous.preserve114 = load <8 x float>, ptr %private.contiguous.address113, align 4
  %220 = select <8 x i1> %62, <8 x float> %206, <8 x float> %private.contiguous.preserve114
  store <8 x float> %220, ptr %private.contiguous.address113, align 4
  %.state115 = load i64, ptr %.slot24, align 4
  %221 = add i64 %.state115, 1
  store i64 %221, ptr %.slot24, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false96
  store float 0xFFF0000000000000, ptr %.spill25, align 4
  store i64 0, ptr %.spill26, align 4
  store i64 0, ptr %.spill27, align 4
  %tile_snapshot.spill.load116 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 1
  %224 = add <8 x i64> %223, zeroinitializer
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = extractelement <8 x ptr> %227, i32 0
  %230 = extractelement <8 x i64> %228, i32 0
  %231 = sub i64 %230, 0
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %233 = select i1 %232, i64 %231, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %229, i64 %233
  %private.contiguous.load118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %234 = select <8 x i1> %62, <8 x float> %private.contiguous.load118, <8 x float> zeroinitializer
  store i64 1, ptr %.spill28, align 4
  %tile_snapshot.spill.load119 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 1
  %237 = add <8 x i64> %236, splat (i64 32)
  %238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %235, 0
  %239 = insertvalue { <8 x ptr>, <8 x i64> } %238, <8 x i64> %237, 1
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %239, 1
  %242 = extractelement <8 x ptr> %240, i32 0
  %243 = extractelement <8 x i64> %241, i32 0
  %244 = sub i64 %243, 0
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %246 = select i1 %245, i64 %244, i64 0
  %private.contiguous.address120 = getelementptr i8, ptr %242, i64 %246
  %private.contiguous.load121 = load <8 x float>, ptr %private.contiguous.address120, align 4
  %247 = select <8 x i1> %62, <8 x float> %private.contiguous.load121, <8 x float> zeroinitializer
  store i64 2, ptr %.spill29, align 4
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %250 = add <8 x i64> %249, splat (i64 64)
  %251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %252 = insertvalue { <8 x ptr>, <8 x i64> } %251, <8 x i64> %250, 1
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %255 = extractelement <8 x ptr> %253, i32 0
  %256 = extractelement <8 x i64> %254, i32 0
  %257 = sub i64 %256, 0
  %258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %259 = select i1 %258, i64 %257, i64 0
  %private.contiguous.address123 = getelementptr i8, ptr %255, i64 %259
  %private.contiguous.load124 = load <8 x float>, ptr %private.contiguous.address123, align 4
  %260 = select <8 x i1> %62, <8 x float> %private.contiguous.load124, <8 x float> zeroinitializer
  store i64 3, ptr %.spill30, align 4
  %tile_snapshot.spill.load125 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 1
  %263 = add <8 x i64> %262, splat (i64 96)
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = extractelement <8 x ptr> %266, i32 0
  %269 = extractelement <8 x i64> %267, i32 0
  %270 = sub i64 %269, 0
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %272 = select i1 %271, i64 %270, i64 0
  %private.contiguous.address126 = getelementptr i8, ptr %268, i64 %272
  %private.contiguous.load127 = load <8 x float>, ptr %private.contiguous.address126, align 4
  %273 = select <8 x i1> %62, <8 x float> %private.contiguous.load127, <8 x float> zeroinitializer
  store i64 4, ptr %.slot31, align 4
  %274 = load <8 x float>, ptr %.slot32, align 32
  %275 = select <8 x i1> %62, <8 x float> %234, <8 x float> %274
  store <8 x float> %275, ptr %.slot32, align 32
  %276 = load <8 x float>, ptr %.slot33, align 32
  %277 = select <8 x i1> %62, <8 x float> %247, <8 x float> %276
  store <8 x float> %277, ptr %.slot33, align 32
  %278 = load <8 x float>, ptr %.slot34, align 32
  %279 = select <8 x i1> %62, <8 x float> %260, <8 x float> %278
  store <8 x float> %279, ptr %.slot34, align 32
  %280 = load <8 x float>, ptr %.slot35, align 32
  %281 = select <8 x i1> %62, <8 x float> %273, <8 x float> %280
  store <8 x float> %281, ptr %.slot35, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state128 = load i64, ptr %.slot31, align 4
  %282 = icmp slt i64 %.state128, 1536
  br i1 %282, label %direct.true129, label %direct.false130

direct.schedule.14:                               ; preds = %direct.true129
  %.state131 = load i64, ptr %.slot31, align 4
  %283 = add i64 %.state131, 0
  %284 = sdiv i64 %283, 1
  %.spill.load132 = load i64, ptr %.spill26, align 4
  %285 = add i64 %.spill.load132, %284
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %.splatinsert134 = insertelement <8 x i64> poison, i64 %285, i64 0
  %.splat135 = shufflevector <8 x i64> %.splatinsert134, <8 x i64> poison, <8 x i32> zeroinitializer
  %288 = mul <8 x i64> %.splat135, splat (i64 32)
  %289 = add <8 x i64> %287, %288
  %290 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %286, 0
  %291 = insertvalue { <8 x ptr>, <8 x i64> } %290, <8 x i64> %289, 1
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %291, 1
  %294 = extractelement <8 x ptr> %292, i32 0
  %295 = extractelement <8 x i64> %293, i32 0
  %296 = sub i64 %295, 0
  %297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %298 = select i1 %297, i64 %296, i64 0
  %private.contiguous.address136 = getelementptr i8, ptr %294, i64 %298
  %private.contiguous.load137 = load <8 x float>, ptr %private.contiguous.address136, align 4
  %299 = select <8 x i1> %62, <8 x float> %private.contiguous.load137, <8 x float> zeroinitializer
  %.state138 = load <8 x float>, ptr %.slot32, align 32
  %300 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state138, <8 x float> %299)
  %.state139 = load i64, ptr %.slot31, align 4
  %301 = add i64 %.state139, 1
  %302 = sdiv i64 %301, 1
  %.spill.load140 = load i64, ptr %.spill26, align 4
  %303 = add i64 %.spill.load140, %302
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %.splatinsert142 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat143 = shufflevector <8 x i64> %.splatinsert142, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat143, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address144 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load145 = load <8 x float>, ptr %private.contiguous.address144, align 4
  %317 = select <8 x i1> %62, <8 x float> %private.contiguous.load145, <8 x float> zeroinitializer
  %.state146 = load <8 x float>, ptr %.slot33, align 32
  %318 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state146, <8 x float> %317)
  %.state147 = load i64, ptr %.slot31, align 4
  %319 = add i64 %.state147, 2
  %320 = sdiv i64 %319, 1
  %.spill.load148 = load i64, ptr %.spill26, align 4
  %321 = add i64 %.spill.load148, %320
  %tile_snapshot.spill.load149 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 1
  %.splatinsert150 = insertelement <8 x i64> poison, i64 %321, i64 0
  %.splat151 = shufflevector <8 x i64> %.splatinsert150, <8 x i64> poison, <8 x i32> zeroinitializer
  %324 = mul <8 x i64> %.splat151, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address152 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.load153 = load <8 x float>, ptr %private.contiguous.address152, align 4
  %335 = select <8 x i1> %62, <8 x float> %private.contiguous.load153, <8 x float> zeroinitializer
  %.state154 = load <8 x float>, ptr %.slot34, align 32
  %336 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state154, <8 x float> %335)
  %.state155 = load i64, ptr %.slot31, align 4
  %337 = add i64 %.state155, 3
  %338 = sdiv i64 %337, 1
  %.spill.load156 = load i64, ptr %.spill26, align 4
  %339 = add i64 %.spill.load156, %338
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %.splatinsert158 = insertelement <8 x i64> poison, i64 %339, i64 0
  %.splat159 = shufflevector <8 x i64> %.splatinsert158, <8 x i64> poison, <8 x i32> zeroinitializer
  %342 = mul <8 x i64> %.splat159, splat (i64 32)
  %343 = add <8 x i64> %341, %342
  %344 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %340, 0
  %345 = insertvalue { <8 x ptr>, <8 x i64> } %344, <8 x i64> %343, 1
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %345, 1
  %348 = extractelement <8 x ptr> %346, i32 0
  %349 = extractelement <8 x i64> %347, i32 0
  %350 = sub i64 %349, 0
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %352 = select i1 %351, i64 %350, i64 0
  %private.contiguous.address160 = getelementptr i8, ptr %348, i64 %352
  %private.contiguous.load161 = load <8 x float>, ptr %private.contiguous.address160, align 4
  %353 = select <8 x i1> %62, <8 x float> %private.contiguous.load161, <8 x float> zeroinitializer
  %.state162 = load <8 x float>, ptr %.slot35, align 32
  %354 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state162, <8 x float> %353)
  %.state163 = load i64, ptr %.slot31, align 4
  %355 = add i64 %.state163, 4
  store i64 %355, ptr %.slot31, align 4
  %356 = load <8 x float>, ptr %.slot32, align 32
  %357 = select <8 x i1> %62, <8 x float> %300, <8 x float> %356
  store <8 x float> %357, ptr %.slot32, align 32
  %358 = load <8 x float>, ptr %.slot33, align 32
  %359 = select <8 x i1> %62, <8 x float> %318, <8 x float> %358
  store <8 x float> %359, ptr %.slot33, align 32
  %360 = load <8 x float>, ptr %.slot34, align 32
  %361 = select <8 x i1> %62, <8 x float> %336, <8 x float> %360
  store <8 x float> %361, ptr %.slot34, align 32
  %362 = load <8 x float>, ptr %.slot35, align 32
  %363 = select <8 x i1> %62, <8 x float> %354, <8 x float> %362
  store <8 x float> %363, ptr %.slot35, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false130
  %.spill.load164 = load i64, ptr %.spill26, align 4
  %364 = add i64 %.spill.load164, 1536
  store i64 %364, ptr %.spill36, align 4
  %tile_snapshot.spill.load165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %365 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load165, 0
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load165, 1
  %.splatinsert166 = insertelement <8 x i64> poison, i64 %364, i64 0
  %.splat167 = shufflevector <8 x i64> %.splatinsert166, <8 x i64> poison, <8 x i32> zeroinitializer
  %367 = mul <8 x i64> %.splat167, splat (i64 32)
  %368 = add <8 x i64> %366, %367
  %369 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %365, 0
  %370 = insertvalue { <8 x ptr>, <8 x i64> } %369, <8 x i64> %368, 1
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %370, 1
  %373 = extractelement <8 x ptr> %371, i32 0
  %374 = extractelement <8 x i64> %372, i32 0
  %375 = sub i64 %374, 0
  %376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %377 = select i1 %376, i64 %375, i64 0
  %private.contiguous.address168 = getelementptr i8, ptr %373, i64 %377
  %private.contiguous.load169 = load <8 x float>, ptr %private.contiguous.address168, align 4
  %378 = select <8 x i1> %62, <8 x float> %private.contiguous.load169, <8 x float> zeroinitializer
  %.state170 = load <8 x float>, ptr %.slot32, align 32
  %379 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state170, <8 x float> %378)
  %.spill.load171 = load i64, ptr %.spill26, align 4
  %380 = add i64 %.spill.load171, 1537
  store i64 %380, ptr %.spill37, align 4
  %tile_snapshot.spill.load172 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load172, 0
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load172, 1
  %.splatinsert173 = insertelement <8 x i64> poison, i64 %380, i64 0
  %.splat174 = shufflevector <8 x i64> %.splatinsert173, <8 x i64> poison, <8 x i32> zeroinitializer
  %383 = mul <8 x i64> %.splat174, splat (i64 32)
  %384 = add <8 x i64> %382, %383
  %385 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %381, 0
  %386 = insertvalue { <8 x ptr>, <8 x i64> } %385, <8 x i64> %384, 1
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %386, 1
  %389 = extractelement <8 x ptr> %387, i32 0
  %390 = extractelement <8 x i64> %388, i32 0
  %391 = sub i64 %390, 0
  %392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %393 = select i1 %392, i64 %391, i64 0
  %private.contiguous.address175 = getelementptr i8, ptr %389, i64 %393
  %private.contiguous.load176 = load <8 x float>, ptr %private.contiguous.address175, align 4
  %394 = select <8 x i1> %62, <8 x float> %private.contiguous.load176, <8 x float> zeroinitializer
  %.state177 = load <8 x float>, ptr %.slot33, align 32
  %395 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state177, <8 x float> %394)
  %.spill.load178 = load float, ptr %.spill25, align 4
  %.splatinsert179 = insertelement <8 x float> poison, float %.spill.load178, i64 0
  %.splat180 = shufflevector <8 x float> %.splatinsert179, <8 x float> poison, <8 x i32> zeroinitializer
  %396 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.splat180, <8 x float> %379)
  %397 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %396, <8 x float> %395)
  %.state181 = load <8 x float>, ptr %.slot34, align 32
  %398 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %397, <8 x float> %.state181)
  %.state182 = load <8 x float>, ptr %.slot35, align 32
  %399 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %398, <8 x float> %.state182)
  %400 = load <8 x float>, ptr %.spill38, align 32
  %401 = select <8 x i1> %62, <8 x float> %399, <8 x float> %400
  store <8 x float> %401, ptr %.spill38, align 32
  store float 0.000000e+00, ptr %.spill39, align 4
  %402 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %402, 0
  %405 = select <8 x i1> %62, <8 x ptr> %403, <8 x ptr> %404
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %402, 1
  %408 = select <8 x i1> %62, <8 x i64> %406, <8 x i64> %407
  %409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %405, 0
  %410 = insertvalue { <8 x ptr>, <8 x i64> } %409, <8 x i64> %408, 1
  store { <8 x ptr>, <8 x i64> } %410, ptr %tile_snapshot.spill40, align 64
  store i64 0, ptr %.slot41, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state183 = load i64, ptr %.slot41, align 4
  %411 = icmp slt i64 %.state183, 1538
  br i1 %411, label %direct.true184, label %direct.false185

direct.schedule.17:                               ; preds = %direct.true184
  %.state186 = load i64, ptr %.slot41, align 4
  %412 = add i64 0, %.state186
  %tile_snapshot.spill.load187 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %413 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 0
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 1
  %.splatinsert188 = insertelement <8 x i64> poison, i64 %412, i64 0
  %.splat189 = shufflevector <8 x i64> %.splatinsert188, <8 x i64> poison, <8 x i32> zeroinitializer
  %415 = add <8 x i64> %414, %.splat189
  %416 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %413, 0
  %417 = insertvalue { <8 x ptr>, <8 x i64> } %416, <8 x i64> %415, 1
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %417, 0
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %417, 1
  %420 = getelementptr i8, <8 x ptr> %418, <8 x i64> %419
  %421 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %420, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %422 = icmp ne <8 x i8> %421, zeroinitializer
  %423 = add i64 0, %412
  %424 = add i64 0, %423
  %tile_snapshot.spill.load190 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %.splatinsert191 = insertelement <8 x i64> poison, i64 %424, i64 0
  %.splat192 = shufflevector <8 x i64> %.splatinsert191, <8 x i64> poison, <8 x i32> zeroinitializer
  %427 = mul <8 x i64> %.splat192, splat (i64 32)
  %428 = add <8 x i64> %426, %427
  %429 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %425, 0
  %430 = insertvalue { <8 x ptr>, <8 x i64> } %429, <8 x i64> %428, 1
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %430, 1
  %433 = extractelement <8 x ptr> %431, i32 0
  %434 = extractelement <8 x i64> %432, i32 0
  %435 = sub i64 %434, 0
  %436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %437 = select i1 %436, i64 %435, i64 0
  %private.contiguous.address193 = getelementptr i8, ptr %433, i64 %437
  %private.contiguous.load194 = load <8 x float>, ptr %private.contiguous.address193, align 4
  %438 = select <8 x i1> %62, <8 x float> %private.contiguous.load194, <8 x float> zeroinitializer
  %.spill.load195 = load <8 x float>, ptr %.spill38, align 32
  %439 = fsub <8 x float> %438, %.spill.load195
  %440 = select <8 x i1> %62, <8 x float> %439, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %440)
  %.spill.load196 = load float, ptr %.spill39, align 4
  %.splatinsert197 = insertelement <8 x float> poison, float %.spill.load196, i64 0
  %.splat198 = shufflevector <8 x float> %.splatinsert197, <8 x float> poison, <8 x i32> zeroinitializer
  %441 = select <8 x i1> %422, <8 x float> %native.exp, <8 x float> %.splat198
  %tile_snapshot.spill.load199 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load199, 0
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load199, 1
  %.state200 = load i64, ptr %.slot41, align 4
  %.splatinsert201 = insertelement <8 x i64> poison, i64 %.state200, i64 0
  %.splat202 = shufflevector <8 x i64> %.splatinsert201, <8 x i64> poison, <8 x i32> zeroinitializer
  %444 = mul <8 x i64> %.splat202, splat (i64 32)
  %445 = add <8 x i64> %443, %444
  %446 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %442, 0
  %447 = insertvalue { <8 x ptr>, <8 x i64> } %446, <8 x i64> %445, 1
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %447, 1
  %450 = extractelement <8 x ptr> %448, i32 0
  %451 = extractelement <8 x i64> %449, i32 0
  %452 = sub i64 %451, 0
  %453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %454 = select i1 %453, i64 %452, i64 0
  %private.contiguous.address203 = getelementptr i8, ptr %450, i64 %454
  %private.contiguous.preserve204 = load <8 x float>, ptr %private.contiguous.address203, align 4
  %455 = select <8 x i1> %62, <8 x float> %441, <8 x float> %private.contiguous.preserve204
  store <8 x float> %455, ptr %private.contiguous.address203, align 4
  %.state205 = load i64, ptr %.slot41, align 4
  %456 = add i64 %.state205, 1
  store i64 %456, ptr %.slot41, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false185
  %tile_snapshot.spill.load206 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load206, 0
  %458 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load206, 1
  %.spill.load207 = load i64, ptr %.spill27, align 4
  %.splatinsert208 = insertelement <8 x i64> poison, i64 %.spill.load207, i64 0
  %.splat209 = shufflevector <8 x i64> %.splatinsert208, <8 x i64> poison, <8 x i32> zeroinitializer
  %459 = mul <8 x i64> %.splat209, splat (i64 32)
  %460 = add <8 x i64> %458, %459
  %461 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %457, 0
  %462 = insertvalue { <8 x ptr>, <8 x i64> } %461, <8 x i64> %460, 1
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %462, 1
  %465 = extractelement <8 x ptr> %463, i32 0
  %466 = extractelement <8 x i64> %464, i32 0
  %467 = sub i64 %466, 0
  %468 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %469 = select i1 %468, i64 %467, i64 0
  %private.contiguous.address210 = getelementptr i8, ptr %465, i64 %469
  %private.contiguous.load211 = load <8 x float>, ptr %private.contiguous.address210, align 4
  %470 = select <8 x i1> %62, <8 x float> %private.contiguous.load211, <8 x float> zeroinitializer
  %tile_snapshot.spill.load212 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load212, 0
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load212, 1
  %.spill.load213 = load i64, ptr %.spill28, align 4
  %.splatinsert214 = insertelement <8 x i64> poison, i64 %.spill.load213, i64 0
  %.splat215 = shufflevector <8 x i64> %.splatinsert214, <8 x i64> poison, <8 x i32> zeroinitializer
  %473 = mul <8 x i64> %.splat215, splat (i64 32)
  %474 = add <8 x i64> %472, %473
  %475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %471, 0
  %476 = insertvalue { <8 x ptr>, <8 x i64> } %475, <8 x i64> %474, 1
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %476, 1
  %479 = extractelement <8 x ptr> %477, i32 0
  %480 = extractelement <8 x i64> %478, i32 0
  %481 = sub i64 %480, 0
  %482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %483 = select i1 %482, i64 %481, i64 0
  %private.contiguous.address216 = getelementptr i8, ptr %479, i64 %483
  %private.contiguous.load217 = load <8 x float>, ptr %private.contiguous.address216, align 4
  %484 = select <8 x i1> %62, <8 x float> %private.contiguous.load217, <8 x float> zeroinitializer
  %tile_snapshot.spill.load218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 0
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 1
  %.spill.load219 = load i64, ptr %.spill29, align 4
  %.splatinsert220 = insertelement <8 x i64> poison, i64 %.spill.load219, i64 0
  %.splat221 = shufflevector <8 x i64> %.splatinsert220, <8 x i64> poison, <8 x i32> zeroinitializer
  %487 = mul <8 x i64> %.splat221, splat (i64 32)
  %488 = add <8 x i64> %486, %487
  %489 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %485, 0
  %490 = insertvalue { <8 x ptr>, <8 x i64> } %489, <8 x i64> %488, 1
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %490, 1
  %493 = extractelement <8 x ptr> %491, i32 0
  %494 = extractelement <8 x i64> %492, i32 0
  %495 = sub i64 %494, 0
  %496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %497 = select i1 %496, i64 %495, i64 0
  %private.contiguous.address222 = getelementptr i8, ptr %493, i64 %497
  %private.contiguous.load223 = load <8 x float>, ptr %private.contiguous.address222, align 4
  %498 = select <8 x i1> %62, <8 x float> %private.contiguous.load223, <8 x float> zeroinitializer
  %tile_snapshot.spill.load224 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 0
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 1
  %.spill.load225 = load i64, ptr %.spill30, align 4
  %.splatinsert226 = insertelement <8 x i64> poison, i64 %.spill.load225, i64 0
  %.splat227 = shufflevector <8 x i64> %.splatinsert226, <8 x i64> poison, <8 x i32> zeroinitializer
  %501 = mul <8 x i64> %.splat227, splat (i64 32)
  %502 = add <8 x i64> %500, %501
  %503 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %499, 0
  %504 = insertvalue { <8 x ptr>, <8 x i64> } %503, <8 x i64> %502, 1
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %504, 1
  %507 = extractelement <8 x ptr> %505, i32 0
  %508 = extractelement <8 x i64> %506, i32 0
  %509 = sub i64 %508, 0
  %510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %511 = select i1 %510, i64 %509, i64 0
  %private.contiguous.address228 = getelementptr i8, ptr %507, i64 %511
  %private.contiguous.load229 = load <8 x float>, ptr %private.contiguous.address228, align 4
  %512 = select <8 x i1> %62, <8 x float> %private.contiguous.load229, <8 x float> zeroinitializer
  store i64 4, ptr %.slot42, align 4
  %513 = load <8 x float>, ptr %.slot43, align 32
  %514 = select <8 x i1> %62, <8 x float> %470, <8 x float> %513
  store <8 x float> %514, ptr %.slot43, align 32
  %515 = load <8 x float>, ptr %.slot44, align 32
  %516 = select <8 x i1> %62, <8 x float> %484, <8 x float> %515
  store <8 x float> %516, ptr %.slot44, align 32
  %517 = load <8 x float>, ptr %.slot45, align 32
  %518 = select <8 x i1> %62, <8 x float> %498, <8 x float> %517
  store <8 x float> %518, ptr %.slot45, align 32
  %519 = load <8 x float>, ptr %.slot46, align 32
  %520 = select <8 x i1> %62, <8 x float> %512, <8 x float> %519
  store <8 x float> %520, ptr %.slot46, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state230 = load i64, ptr %.slot42, align 4
  %521 = icmp slt i64 %.state230, 1536
  br i1 %521, label %direct.true231, label %direct.false232

direct.schedule.20:                               ; preds = %direct.true231
  %.state233 = load i64, ptr %.slot42, align 4
  %522 = add i64 %.state233, 0
  %523 = sdiv i64 %522, 1
  %.spill.load234 = load i64, ptr %.spill26, align 4
  %524 = add i64 %.spill.load234, %523
  %tile_snapshot.spill.load235 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %525 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 0
  %526 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 1
  %.splatinsert236 = insertelement <8 x i64> poison, i64 %524, i64 0
  %.splat237 = shufflevector <8 x i64> %.splatinsert236, <8 x i64> poison, <8 x i32> zeroinitializer
  %527 = mul <8 x i64> %.splat237, splat (i64 32)
  %528 = add <8 x i64> %526, %527
  %529 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %525, 0
  %530 = insertvalue { <8 x ptr>, <8 x i64> } %529, <8 x i64> %528, 1
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %530, 1
  %533 = extractelement <8 x ptr> %531, i32 0
  %534 = extractelement <8 x i64> %532, i32 0
  %535 = sub i64 %534, 0
  %536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %537 = select i1 %536, i64 %535, i64 0
  %private.contiguous.address238 = getelementptr i8, ptr %533, i64 %537
  %private.contiguous.load239 = load <8 x float>, ptr %private.contiguous.address238, align 4
  %538 = select <8 x i1> %62, <8 x float> %private.contiguous.load239, <8 x float> zeroinitializer
  %.state240 = load <8 x float>, ptr %.slot43, align 32
  %539 = fadd <8 x float> %.state240, %538
  %.state241 = load i64, ptr %.slot42, align 4
  %540 = add i64 %.state241, 1
  %541 = sdiv i64 %540, 1
  %.spill.load242 = load i64, ptr %.spill26, align 4
  %542 = add i64 %.spill.load242, %541
  %tile_snapshot.spill.load243 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %543 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load243, 0
  %544 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load243, 1
  %.splatinsert244 = insertelement <8 x i64> poison, i64 %542, i64 0
  %.splat245 = shufflevector <8 x i64> %.splatinsert244, <8 x i64> poison, <8 x i32> zeroinitializer
  %545 = mul <8 x i64> %.splat245, splat (i64 32)
  %546 = add <8 x i64> %544, %545
  %547 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %543, 0
  %548 = insertvalue { <8 x ptr>, <8 x i64> } %547, <8 x i64> %546, 1
  %549 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %550 = extractvalue { <8 x ptr>, <8 x i64> } %548, 1
  %551 = extractelement <8 x ptr> %549, i32 0
  %552 = extractelement <8 x i64> %550, i32 0
  %553 = sub i64 %552, 0
  %554 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %555 = select i1 %554, i64 %553, i64 0
  %private.contiguous.address246 = getelementptr i8, ptr %551, i64 %555
  %private.contiguous.load247 = load <8 x float>, ptr %private.contiguous.address246, align 4
  %556 = select <8 x i1> %62, <8 x float> %private.contiguous.load247, <8 x float> zeroinitializer
  %.state248 = load <8 x float>, ptr %.slot44, align 32
  %557 = fadd <8 x float> %.state248, %556
  %.state249 = load i64, ptr %.slot42, align 4
  %558 = add i64 %.state249, 2
  %559 = sdiv i64 %558, 1
  %.spill.load250 = load i64, ptr %.spill26, align 4
  %560 = add i64 %.spill.load250, %559
  %tile_snapshot.spill.load251 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 0
  %562 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 1
  %.splatinsert252 = insertelement <8 x i64> poison, i64 %560, i64 0
  %.splat253 = shufflevector <8 x i64> %.splatinsert252, <8 x i64> poison, <8 x i32> zeroinitializer
  %563 = mul <8 x i64> %.splat253, splat (i64 32)
  %564 = add <8 x i64> %562, %563
  %565 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %561, 0
  %566 = insertvalue { <8 x ptr>, <8 x i64> } %565, <8 x i64> %564, 1
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %568 = extractvalue { <8 x ptr>, <8 x i64> } %566, 1
  %569 = extractelement <8 x ptr> %567, i32 0
  %570 = extractelement <8 x i64> %568, i32 0
  %571 = sub i64 %570, 0
  %572 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %573 = select i1 %572, i64 %571, i64 0
  %private.contiguous.address254 = getelementptr i8, ptr %569, i64 %573
  %private.contiguous.load255 = load <8 x float>, ptr %private.contiguous.address254, align 4
  %574 = select <8 x i1> %62, <8 x float> %private.contiguous.load255, <8 x float> zeroinitializer
  %.state256 = load <8 x float>, ptr %.slot45, align 32
  %575 = fadd <8 x float> %.state256, %574
  %.state257 = load i64, ptr %.slot42, align 4
  %576 = add i64 %.state257, 3
  %577 = sdiv i64 %576, 1
  %.spill.load258 = load i64, ptr %.spill26, align 4
  %578 = add i64 %.spill.load258, %577
  %tile_snapshot.spill.load259 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %579 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 0
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 1
  %.splatinsert260 = insertelement <8 x i64> poison, i64 %578, i64 0
  %.splat261 = shufflevector <8 x i64> %.splatinsert260, <8 x i64> poison, <8 x i32> zeroinitializer
  %581 = mul <8 x i64> %.splat261, splat (i64 32)
  %582 = add <8 x i64> %580, %581
  %583 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %579, 0
  %584 = insertvalue { <8 x ptr>, <8 x i64> } %583, <8 x i64> %582, 1
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %584, 1
  %587 = extractelement <8 x ptr> %585, i32 0
  %588 = extractelement <8 x i64> %586, i32 0
  %589 = sub i64 %588, 0
  %590 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %591 = select i1 %590, i64 %589, i64 0
  %private.contiguous.address262 = getelementptr i8, ptr %587, i64 %591
  %private.contiguous.load263 = load <8 x float>, ptr %private.contiguous.address262, align 4
  %592 = select <8 x i1> %62, <8 x float> %private.contiguous.load263, <8 x float> zeroinitializer
  %.state264 = load <8 x float>, ptr %.slot46, align 32
  %593 = fadd <8 x float> %.state264, %592
  %.state265 = load i64, ptr %.slot42, align 4
  %594 = add i64 %.state265, 4
  store i64 %594, ptr %.slot42, align 4
  %595 = load <8 x float>, ptr %.slot43, align 32
  %596 = select <8 x i1> %62, <8 x float> %539, <8 x float> %595
  store <8 x float> %596, ptr %.slot43, align 32
  %597 = load <8 x float>, ptr %.slot44, align 32
  %598 = select <8 x i1> %62, <8 x float> %557, <8 x float> %597
  store <8 x float> %598, ptr %.slot44, align 32
  %599 = load <8 x float>, ptr %.slot45, align 32
  %600 = select <8 x i1> %62, <8 x float> %575, <8 x float> %599
  store <8 x float> %600, ptr %.slot45, align 32
  %601 = load <8 x float>, ptr %.slot46, align 32
  %602 = select <8 x i1> %62, <8 x float> %593, <8 x float> %601
  store <8 x float> %602, ptr %.slot46, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false232
  %tile_snapshot.spill.load266 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %603 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 0
  %604 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 1
  %.spill.load267 = load i64, ptr %.spill36, align 4
  %.splatinsert268 = insertelement <8 x i64> poison, i64 %.spill.load267, i64 0
  %.splat269 = shufflevector <8 x i64> %.splatinsert268, <8 x i64> poison, <8 x i32> zeroinitializer
  %605 = mul <8 x i64> %.splat269, splat (i64 32)
  %606 = add <8 x i64> %604, %605
  %607 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %603, 0
  %608 = insertvalue { <8 x ptr>, <8 x i64> } %607, <8 x i64> %606, 1
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %610 = extractvalue { <8 x ptr>, <8 x i64> } %608, 1
  %611 = extractelement <8 x ptr> %609, i32 0
  %612 = extractelement <8 x i64> %610, i32 0
  %613 = sub i64 %612, 0
  %614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %615 = select i1 %614, i64 %613, i64 0
  %private.contiguous.address270 = getelementptr i8, ptr %611, i64 %615
  %private.contiguous.load271 = load <8 x float>, ptr %private.contiguous.address270, align 4
  %616 = select <8 x i1> %62, <8 x float> %private.contiguous.load271, <8 x float> zeroinitializer
  %.state272 = load <8 x float>, ptr %.slot43, align 32
  %617 = fadd <8 x float> %.state272, %616
  %tile_snapshot.spill.load273 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load273, 0
  %619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load273, 1
  %.spill.load274 = load i64, ptr %.spill37, align 4
  %.splatinsert275 = insertelement <8 x i64> poison, i64 %.spill.load274, i64 0
  %.splat276 = shufflevector <8 x i64> %.splatinsert275, <8 x i64> poison, <8 x i32> zeroinitializer
  %620 = mul <8 x i64> %.splat276, splat (i64 32)
  %621 = add <8 x i64> %619, %620
  %622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %618, 0
  %623 = insertvalue { <8 x ptr>, <8 x i64> } %622, <8 x i64> %621, 1
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %625 = extractvalue { <8 x ptr>, <8 x i64> } %623, 1
  %626 = extractelement <8 x ptr> %624, i32 0
  %627 = extractelement <8 x i64> %625, i32 0
  %628 = sub i64 %627, 0
  %629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %630 = select i1 %629, i64 %628, i64 0
  %private.contiguous.address277 = getelementptr i8, ptr %626, i64 %630
  %private.contiguous.load278 = load <8 x float>, ptr %private.contiguous.address277, align 4
  %631 = select <8 x i1> %62, <8 x float> %private.contiguous.load278, <8 x float> zeroinitializer
  %.state279 = load <8 x float>, ptr %.slot44, align 32
  %632 = fadd <8 x float> %.state279, %631
  %.spill.load280 = load float, ptr %.spill39, align 4
  %.splatinsert281 = insertelement <8 x float> poison, float %.spill.load280, i64 0
  %.splat282 = shufflevector <8 x float> %.splatinsert281, <8 x float> poison, <8 x i32> zeroinitializer
  %633 = fadd <8 x float> %.splat282, %617
  %634 = fadd <8 x float> %633, %632
  %.state283 = load <8 x float>, ptr %.slot45, align 32
  %635 = fadd <8 x float> %634, %.state283
  %.state284 = load <8 x float>, ptr %.slot46, align 32
  %636 = fadd <8 x float> %635, %.state284
  %637 = load <8 x float>, ptr %.spill47, align 32
  %638 = select <8 x i1> %62, <8 x float> %636, <8 x float> %637
  store <8 x float> %638, ptr %.spill47, align 32
  store i64 0, ptr %.slot48, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state285 = load i64, ptr %.slot48, align 4
  %639 = icmp slt i64 %.state285, 1538
  br i1 %639, label %direct.true286, label %direct.false287

direct.schedule.23:                               ; preds = %direct.true286
  %.spill.load288 = load <8 x i64>, ptr %.spill, align 64
  %640 = add <8 x i64> %.spill.load288, zeroinitializer
  %641 = add <8 x i64> zeroinitializer, %640
  %.state289 = load i64, ptr %.slot48, align 4
  %642 = add i64 0, %.state289
  %643 = mul <8 x i64> %641, splat (i64 1538)
  %.splatinsert290 = insertelement <8 x i64> poison, i64 %642, i64 0
  %.splat291 = shufflevector <8 x i64> %.splatinsert290, <8 x i64> poison, <8 x i32> zeroinitializer
  %644 = add <8 x i64> %643, %.splat291
  %.state292 = load i64, ptr %.slot48, align 4
  %645 = add i64 0, %.state292
  %tile_snapshot.spill.load293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 0
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 1
  %.splatinsert294 = insertelement <8 x i64> poison, i64 %645, i64 0
  %.splat295 = shufflevector <8 x i64> %.splatinsert294, <8 x i64> poison, <8 x i32> zeroinitializer
  %648 = mul <8 x i64> %.splat295, splat (i64 32)
  %649 = add <8 x i64> %647, %648
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %646, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = extractelement <8 x ptr> %652, i32 0
  %655 = extractelement <8 x i64> %653, i32 0
  %656 = sub i64 %655, 0
  %657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %658 = select i1 %657, i64 %656, i64 0
  %private.contiguous.address296 = getelementptr i8, ptr %654, i64 %658
  %private.contiguous.load297 = load <8 x float>, ptr %private.contiguous.address296, align 4
  %659 = select <8 x i1> %62, <8 x float> %private.contiguous.load297, <8 x float> zeroinitializer
  %.spill.load298 = load <8 x float>, ptr %.spill47, align 32
  %660 = fdiv <8 x float> %659, %.spill.load298
  %661 = extractvalue { ptr, i64 } %38, 0
  %662 = mul <8 x i64> %644, splat (i64 4)
  %663 = getelementptr i8, ptr %661, <8 x i64> %662
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %660, <8 x ptr> %663, i32 1, <8 x i1> %62)
  %.state299 = load i64, ptr %.slot48, align 4
  %664 = add i64 %.state299, 1
  store i64 %664, ptr %.slot48, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false287
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true67:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false68:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true81:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false82:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true95:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false96:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true129:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false130:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true184:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false185:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true231:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false232:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true286:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false287:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, i32 immarg, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x i8>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #0

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #3 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 49216
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 147648
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 1538, i64 3076, i64 4614, i64 6152, i64 7690, i64 9228, i64 10766>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 159952
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 209168
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %.spill19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill19, align 64
  %tile_snapshot.spill20 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill20, align 64
  %.slot21 = alloca i64, align 8
  store i64 0, ptr %.slot21, align 4
  %.spill22 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill22, align 4
  %tile_snapshot.spill23 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill23, align 64
  %.slot24 = alloca i64, align 8
  store i64 0, ptr %.slot24, align 4
  %.spill25 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill25, align 4
  %.spill26 = alloca i64, align 8
  store i64 0, ptr %.spill26, align 4
  %.spill27 = alloca i64, align 8
  store i64 0, ptr %.spill27, align 4
  %.spill28 = alloca i64, align 8
  store i64 0, ptr %.spill28, align 4
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca i64, align 8
  store i64 0, ptr %.spill30, align 4
  %.slot31 = alloca i64, align 8
  store i64 0, ptr %.slot31, align 4
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.spill36 = alloca i64, align 8
  store i64 0, ptr %.spill36, align 4
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %.spill38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill38, align 32
  %.spill39 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill39, align 4
  %tile_snapshot.spill40 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill40, align 64
  %.slot41 = alloca i64, align 8
  store i64 0, ptr %.slot41, align 4
  %.slot42 = alloca i64, align 8
  store i64 0, ptr %.slot42, align 4
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %.spill47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill47, align 32
  %.slot48 = alloca i64, align 8
  store i64 0, ptr %.slot48, align 4
  %15 = getelementptr i8, ptr %argument_buffer, i64 0
  %16 = load ptr, ptr %15, align 16
  %17 = getelementptr i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  %21 = getelementptr i8, ptr %argument_buffer, i64 16
  %22 = load ptr, ptr %21, align 16
  %23 = getelementptr i8, ptr %21, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = insertvalue { ptr, i64 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i64 } %25, i64 %24, 1
  %27 = getelementptr i8, ptr %argument_buffer, i64 32
  %28 = load ptr, ptr %27, align 16
  %29 = getelementptr i8, ptr %27, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { ptr, i64 } poison, ptr %28, 0
  %32 = insertvalue { ptr, i64 } %31, i64 %30, 1
  %33 = getelementptr i8, ptr %argument_buffer, i64 48
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = load i32, ptr %launch_config, align 4
  %40 = getelementptr i8, ptr %launch_config, i64 12
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr i8, ptr %launch_config, i64 4
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %launch_config, i64 16
  %45 = load i32, ptr %44, align 4
  %46 = getelementptr i8, ptr %launch_config, i64 8
  %47 = load i32, ptr %46, align 4
  %48 = getelementptr i8, ptr %launch_config, i64 20
  %49 = load i32, ptr %48, align 4
  %50 = getelementptr i8, ptr %launch_config, i64 36
  %51 = load i32, ptr %50, align 4
  %.splatinsert49 = insertelement <8 x i32> poison, i32 %51, i64 0
  %.splat50 = shufflevector <8 x i32> %.splatinsert49, <8 x i32> poison, <8 x i32> zeroinitializer
  %52 = add <8 x i32> %.splat50, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %53 = mul i32 %39, 32
  %.splatinsert51 = insertelement <8 x i32> poison, i32 %53, i64 0
  %.splat52 = shufflevector <8 x i32> %.splatinsert51, <8 x i32> poison, <8 x i32> zeroinitializer
  %54 = add <8 x i32> %.splat52, %52
  %55 = mul i32 %43, 1
  %.splatinsert53 = insertelement <8 x i32> poison, i32 %55, i64 0
  %.splat54 = shufflevector <8 x i32> %.splatinsert53, <8 x i32> poison, <8 x i32> zeroinitializer
  %56 = add <8 x i32> %.splat54, zeroinitializer
  %57 = mul i32 %47, 1
  %.splatinsert55 = insertelement <8 x i32> poison, i32 %57, i64 0
  %.splat56 = shufflevector <8 x i32> %.splatinsert55, <8 x i32> poison, <8 x i32> zeroinitializer
  %58 = add <8 x i32> %.splat56, zeroinitializer
  %59 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %54, 0
  %60 = insertvalue [3 x <8 x i32>] %59, <8 x i32> %56, 1
  %61 = insertvalue [3 x <8 x i32>] %60, <8 x i32> %58, 2
  %.splatinsert57 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat58 = shufflevector <8 x i32> %.splatinsert57, <8 x i32> poison, <8 x i32> zeroinitializer
  %62 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat58
  %63 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  br i1 %63, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %64 = extractvalue [3 x <8 x i32>] %61, 0
  %65 = zext <8 x i32> %64 to <8 x i64>
  %66 = select <8 x i1> %62, <8 x i64> %65, <8 x i64> zeroinitializer
  %67 = select <8 x i1> %62, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %68 = sdiv <8 x i64> %66, %67
  %69 = load <8 x i64>, ptr %.spill, align 64
  %70 = select <8 x i1> %62, <8 x i64> %68, <8 x i64> %69
  store <8 x i64> %70, ptr %.spill, align 64
  %71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %71, 0
  %74 = select <8 x i1> %62, <8 x ptr> %72, <8 x ptr> %73
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %71, 1
  %77 = select <8 x i1> %62, <8 x i64> %75, <8 x i64> %76
  %78 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %74, 0
  %79 = insertvalue { <8 x ptr>, <8 x i64> } %78, <8 x i64> %77, 1
  store { <8 x ptr>, <8 x i64> } %79, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %80 = icmp slt i64 %.state, 1538
  br i1 %80, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.spill.load, zeroinitializer
  %82 = add <8 x i64> zeroinitializer, %81
  %.state59 = load i64, ptr %.slot, align 4
  %83 = add i64 0, %.state59
  %84 = mul <8 x i64> %82, splat (i64 1538)
  %.splatinsert60 = insertelement <8 x i64> poison, i64 %83, i64 0
  %.splat61 = shufflevector <8 x i64> %.splatinsert60, <8 x i64> poison, <8 x i32> zeroinitializer
  %85 = add <8 x i64> %84, %.splat61
  %86 = extractvalue { ptr, i64 } %20, 0
  %87 = mul <8 x i64> %85, splat (i64 4)
  %88 = getelementptr i8, ptr %86, <8 x i64> %87
  %89 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %88, i32 1, <8 x i1> %62, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state62 = load i64, ptr %.slot, align 4
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %.state62, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %92 = mul <8 x i64> %.splat64, splat (i64 32)
  %93 = add <8 x i64> %91, %92
  %94 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %90, 0
  %95 = insertvalue { <8 x ptr>, <8 x i64> } %94, <8 x i64> %93, 1
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %95, 1
  %98 = extractelement <8 x ptr> %96, i32 0
  %99 = extractelement <8 x i64> %97, i32 0
  %100 = sub i64 %99, 0
  %101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %102 = select i1 %101, i64 %100, i64 0
  %private.contiguous.address = getelementptr i8, ptr %98, i64 %102
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %103 = select <8 x i1> %62, <8 x float> %89, <8 x float> %private.contiguous.preserve
  store <8 x float> %103, ptr %private.contiguous.address, align 4
  %.state65 = load i64, ptr %.slot, align 4
  %104 = add i64 %.state65, 1
  store i64 %104, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %105 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %105, 0
  %108 = select <8 x i1> %62, <8 x ptr> %106, <8 x ptr> %107
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %105, 1
  %111 = select <8 x i1> %62, <8 x i64> %109, <8 x i64> %110
  %112 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %108, 0
  %113 = insertvalue { <8 x ptr>, <8 x i64> } %112, <8 x i64> %111, 1
  store { <8 x ptr>, <8 x i64> } %113, ptr %tile_snapshot.spill17, align 64
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state66 = load i64, ptr %.slot18, align 4
  %114 = icmp slt i64 %.state66, 1538
  br i1 %114, label %direct.true67, label %direct.false68

direct.schedule.5:                                ; preds = %direct.true67
  %tile_snapshot.spill.load69 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 1
  %.state70 = load i64, ptr %.slot18, align 4
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %.state70, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %117 = mul <8 x i64> %.splat72, splat (i64 64)
  %118 = add <8 x i64> %116, %117
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %.state73 = load i64, ptr %.slot18, align 4
  %.splatinsert74 = insertelement <8 x i64> poison, i64 %.state73, i64 0
  %.splat75 = shufflevector <8 x i64> %.splatinsert74, <8 x i64> poison, <8 x i32> zeroinitializer
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address76 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve77 = load <8 x i64>, ptr %private.contiguous.address76, align 8
  %128 = select <8 x i1> %62, <8 x i64> %.splat75, <8 x i64> %private.contiguous.preserve77
  store <8 x i64> %128, ptr %private.contiguous.address76, align 8
  %.state78 = load i64, ptr %.slot18, align 4
  %129 = add i64 %.state78, 1
  store i64 %129, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false68
  %.spill.load79 = load <8 x i64>, ptr %.spill, align 64
  %130 = select <8 x i1> %62, <8 x i64> %.spill.load79, <8 x i64> zeroinitializer
  %131 = select <8 x i1> %62, <8 x i64> splat (i64 1538), <8 x i64> splat (i64 1)
  %132 = srem <8 x i64> %130, %131
  %133 = load <8 x i64>, ptr %.spill19, align 64
  %134 = select <8 x i1> %62, <8 x i64> %132, <8 x i64> %133
  store <8 x i64> %134, ptr %.spill19, align 64
  %135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %135, 0
  %138 = select <8 x i1> %62, <8 x ptr> %136, <8 x ptr> %137
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %135, 1
  %141 = select <8 x i1> %62, <8 x i64> %139, <8 x i64> %140
  %142 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %138, 0
  %143 = insertvalue { <8 x ptr>, <8 x i64> } %142, <8 x i64> %141, 1
  store { <8 x ptr>, <8 x i64> } %143, ptr %tile_snapshot.spill20, align 64
  store i64 0, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state80 = load i64, ptr %.slot21, align 4
  %144 = icmp slt i64 %.state80, 1538
  br i1 %144, label %direct.true81, label %direct.false82

direct.schedule.8:                                ; preds = %direct.true81
  %.state83 = load i64, ptr %.slot21, align 4
  %145 = add i64 0, %.state83
  %tile_snapshot.spill.load84 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load84, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load84, 1
  %.splatinsert85 = insertelement <8 x i64> poison, i64 %145, i64 0
  %.splat86 = shufflevector <8 x i64> %.splatinsert85, <8 x i64> poison, <8 x i32> zeroinitializer
  %148 = mul <8 x i64> %.splat86, splat (i64 64)
  %149 = add <8 x i64> %147, %148
  %150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %146, 0
  %151 = insertvalue { <8 x ptr>, <8 x i64> } %150, <8 x i64> %149, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %154 = extractelement <8 x ptr> %152, i32 0
  %155 = extractelement <8 x i64> %153, i32 0
  %156 = sub i64 %155, 0
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %158 = select i1 %157, i64 %156, i64 0
  %private.contiguous.address87 = getelementptr i8, ptr %154, i64 %158
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address87, align 8
  %159 = select <8 x i1> %62, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load88 = load <8 x i64>, ptr %.spill19, align 64
  %160 = icmp sle <8 x i64> %159, %.spill.load88
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %.state90 = load i64, ptr %.slot21, align 4
  %.splatinsert91 = insertelement <8 x i64> poison, i64 %.state90, i64 0
  %.splat92 = shufflevector <8 x i64> %.splatinsert91, <8 x i64> poison, <8 x i32> zeroinitializer
  %163 = add <8 x i64> %162, %.splat92
  %164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %161, 0
  %165 = insertvalue { <8 x ptr>, <8 x i64> } %164, <8 x i64> %163, 1
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %168 = getelementptr i8, <8 x ptr> %166, <8 x i64> %167
  %169 = zext <8 x i1> %160 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %169, <8 x ptr> %168, i32 1, <8 x i1> %62)
  %.state93 = load i64, ptr %.slot21, align 4
  %170 = add i64 %.state93, 1
  store i64 %170, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false82
  store float 0xC6293E5940000000, ptr %.spill22, align 4
  %171 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 0
  %174 = select <8 x i1> %62, <8 x ptr> %172, <8 x ptr> %173
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %177 = select <8 x i1> %62, <8 x i64> %175, <8 x i64> %176
  %178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %174, 0
  %179 = insertvalue { <8 x ptr>, <8 x i64> } %178, <8 x i64> %177, 1
  store { <8 x ptr>, <8 x i64> } %179, ptr %tile_snapshot.spill23, align 64
  store i64 0, ptr %.slot24, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state94 = load i64, ptr %.slot24, align 4
  %180 = icmp slt i64 %.state94, 1538
  br i1 %180, label %direct.true95, label %direct.false96

direct.schedule.11:                               ; preds = %direct.true95
  %.state97 = load i64, ptr %.slot24, align 4
  %181 = add i64 0, %.state97
  %tile_snapshot.spill.load98 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 1
  %.splatinsert99 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat100 = shufflevector <8 x i64> %.splatinsert99, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = add <8 x i64> %183, %.splat100
  %185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %182, 0
  %186 = insertvalue { <8 x ptr>, <8 x i64> } %185, <8 x i64> %184, 1
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %186, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %186, 1
  %189 = getelementptr i8, <8 x ptr> %187, <8 x i64> %188
  %190 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %189, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %191 = icmp ne <8 x i8> %190, zeroinitializer
  %tile_snapshot.spill.load101 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 1
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %194 = mul <8 x i64> %.splat103, splat (i64 32)
  %195 = add <8 x i64> %193, %194
  %196 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %192, 0
  %197 = insertvalue { <8 x ptr>, <8 x i64> } %196, <8 x i64> %195, 1
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %197, 1
  %200 = extractelement <8 x ptr> %198, i32 0
  %201 = extractelement <8 x i64> %199, i32 0
  %202 = sub i64 %201, 0
  %203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %204 = select i1 %203, i64 %202, i64 0
  %private.contiguous.address104 = getelementptr i8, ptr %200, i64 %204
  %private.contiguous.load105 = load <8 x float>, ptr %private.contiguous.address104, align 4
  %205 = select <8 x i1> %62, <8 x float> %private.contiguous.load105, <8 x float> zeroinitializer
  %.spill.load106 = load float, ptr %.spill22, align 4
  %.splatinsert107 = insertelement <8 x float> poison, float %.spill.load106, i64 0
  %.splat108 = shufflevector <8 x float> %.splatinsert107, <8 x float> poison, <8 x i32> zeroinitializer
  %206 = select <8 x i1> %191, <8 x float> %205, <8 x float> %.splat108
  %tile_snapshot.spill.load109 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 0
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 1
  %.state110 = load i64, ptr %.slot24, align 4
  %.splatinsert111 = insertelement <8 x i64> poison, i64 %.state110, i64 0
  %.splat112 = shufflevector <8 x i64> %.splatinsert111, <8 x i64> poison, <8 x i32> zeroinitializer
  %209 = mul <8 x i64> %.splat112, splat (i64 32)
  %210 = add <8 x i64> %208, %209
  %211 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %207, 0
  %212 = insertvalue { <8 x ptr>, <8 x i64> } %211, <8 x i64> %210, 1
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %212, 1
  %215 = extractelement <8 x ptr> %213, i32 0
  %216 = extractelement <8 x i64> %214, i32 0
  %217 = sub i64 %216, 0
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %219 = select i1 %218, i64 %217, i64 0
  %private.contiguous.address113 = getelementptr i8, ptr %215, i64 %219
  %private.contiguous.preserve114 = load <8 x float>, ptr %private.contiguous.address113, align 4
  %220 = select <8 x i1> %62, <8 x float> %206, <8 x float> %private.contiguous.preserve114
  store <8 x float> %220, ptr %private.contiguous.address113, align 4
  %.state115 = load i64, ptr %.slot24, align 4
  %221 = add i64 %.state115, 1
  store i64 %221, ptr %.slot24, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false96
  store float 0xFFF0000000000000, ptr %.spill25, align 4
  store i64 0, ptr %.spill26, align 4
  store i64 0, ptr %.spill27, align 4
  %tile_snapshot.spill.load116 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 1
  %224 = add <8 x i64> %223, zeroinitializer
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = extractelement <8 x ptr> %227, i32 0
  %230 = extractelement <8 x i64> %228, i32 0
  %231 = sub i64 %230, 0
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %233 = select i1 %232, i64 %231, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %229, i64 %233
  %private.contiguous.load118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %234 = select <8 x i1> %62, <8 x float> %private.contiguous.load118, <8 x float> zeroinitializer
  store i64 1, ptr %.spill28, align 4
  %tile_snapshot.spill.load119 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 1
  %237 = add <8 x i64> %236, splat (i64 32)
  %238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %235, 0
  %239 = insertvalue { <8 x ptr>, <8 x i64> } %238, <8 x i64> %237, 1
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %239, 1
  %242 = extractelement <8 x ptr> %240, i32 0
  %243 = extractelement <8 x i64> %241, i32 0
  %244 = sub i64 %243, 0
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %246 = select i1 %245, i64 %244, i64 0
  %private.contiguous.address120 = getelementptr i8, ptr %242, i64 %246
  %private.contiguous.load121 = load <8 x float>, ptr %private.contiguous.address120, align 4
  %247 = select <8 x i1> %62, <8 x float> %private.contiguous.load121, <8 x float> zeroinitializer
  store i64 2, ptr %.spill29, align 4
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %250 = add <8 x i64> %249, splat (i64 64)
  %251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %252 = insertvalue { <8 x ptr>, <8 x i64> } %251, <8 x i64> %250, 1
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %255 = extractelement <8 x ptr> %253, i32 0
  %256 = extractelement <8 x i64> %254, i32 0
  %257 = sub i64 %256, 0
  %258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %259 = select i1 %258, i64 %257, i64 0
  %private.contiguous.address123 = getelementptr i8, ptr %255, i64 %259
  %private.contiguous.load124 = load <8 x float>, ptr %private.contiguous.address123, align 4
  %260 = select <8 x i1> %62, <8 x float> %private.contiguous.load124, <8 x float> zeroinitializer
  store i64 3, ptr %.spill30, align 4
  %tile_snapshot.spill.load125 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 1
  %263 = add <8 x i64> %262, splat (i64 96)
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = extractelement <8 x ptr> %266, i32 0
  %269 = extractelement <8 x i64> %267, i32 0
  %270 = sub i64 %269, 0
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %272 = select i1 %271, i64 %270, i64 0
  %private.contiguous.address126 = getelementptr i8, ptr %268, i64 %272
  %private.contiguous.load127 = load <8 x float>, ptr %private.contiguous.address126, align 4
  %273 = select <8 x i1> %62, <8 x float> %private.contiguous.load127, <8 x float> zeroinitializer
  store i64 4, ptr %.slot31, align 4
  %274 = load <8 x float>, ptr %.slot32, align 32
  %275 = select <8 x i1> %62, <8 x float> %234, <8 x float> %274
  store <8 x float> %275, ptr %.slot32, align 32
  %276 = load <8 x float>, ptr %.slot33, align 32
  %277 = select <8 x i1> %62, <8 x float> %247, <8 x float> %276
  store <8 x float> %277, ptr %.slot33, align 32
  %278 = load <8 x float>, ptr %.slot34, align 32
  %279 = select <8 x i1> %62, <8 x float> %260, <8 x float> %278
  store <8 x float> %279, ptr %.slot34, align 32
  %280 = load <8 x float>, ptr %.slot35, align 32
  %281 = select <8 x i1> %62, <8 x float> %273, <8 x float> %280
  store <8 x float> %281, ptr %.slot35, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state128 = load i64, ptr %.slot31, align 4
  %282 = icmp slt i64 %.state128, 1536
  br i1 %282, label %direct.true129, label %direct.false130

direct.schedule.14:                               ; preds = %direct.true129
  %.state131 = load i64, ptr %.slot31, align 4
  %283 = add i64 %.state131, 0
  %284 = sdiv i64 %283, 1
  %.spill.load132 = load i64, ptr %.spill26, align 4
  %285 = add i64 %.spill.load132, %284
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %.splatinsert134 = insertelement <8 x i64> poison, i64 %285, i64 0
  %.splat135 = shufflevector <8 x i64> %.splatinsert134, <8 x i64> poison, <8 x i32> zeroinitializer
  %288 = mul <8 x i64> %.splat135, splat (i64 32)
  %289 = add <8 x i64> %287, %288
  %290 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %286, 0
  %291 = insertvalue { <8 x ptr>, <8 x i64> } %290, <8 x i64> %289, 1
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %291, 1
  %294 = extractelement <8 x ptr> %292, i32 0
  %295 = extractelement <8 x i64> %293, i32 0
  %296 = sub i64 %295, 0
  %297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %298 = select i1 %297, i64 %296, i64 0
  %private.contiguous.address136 = getelementptr i8, ptr %294, i64 %298
  %private.contiguous.load137 = load <8 x float>, ptr %private.contiguous.address136, align 4
  %299 = select <8 x i1> %62, <8 x float> %private.contiguous.load137, <8 x float> zeroinitializer
  %.state138 = load <8 x float>, ptr %.slot32, align 32
  %300 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state138, <8 x float> %299)
  %.state139 = load i64, ptr %.slot31, align 4
  %301 = add i64 %.state139, 1
  %302 = sdiv i64 %301, 1
  %.spill.load140 = load i64, ptr %.spill26, align 4
  %303 = add i64 %.spill.load140, %302
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %.splatinsert142 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat143 = shufflevector <8 x i64> %.splatinsert142, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat143, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address144 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load145 = load <8 x float>, ptr %private.contiguous.address144, align 4
  %317 = select <8 x i1> %62, <8 x float> %private.contiguous.load145, <8 x float> zeroinitializer
  %.state146 = load <8 x float>, ptr %.slot33, align 32
  %318 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state146, <8 x float> %317)
  %.state147 = load i64, ptr %.slot31, align 4
  %319 = add i64 %.state147, 2
  %320 = sdiv i64 %319, 1
  %.spill.load148 = load i64, ptr %.spill26, align 4
  %321 = add i64 %.spill.load148, %320
  %tile_snapshot.spill.load149 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 1
  %.splatinsert150 = insertelement <8 x i64> poison, i64 %321, i64 0
  %.splat151 = shufflevector <8 x i64> %.splatinsert150, <8 x i64> poison, <8 x i32> zeroinitializer
  %324 = mul <8 x i64> %.splat151, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address152 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.load153 = load <8 x float>, ptr %private.contiguous.address152, align 4
  %335 = select <8 x i1> %62, <8 x float> %private.contiguous.load153, <8 x float> zeroinitializer
  %.state154 = load <8 x float>, ptr %.slot34, align 32
  %336 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state154, <8 x float> %335)
  %.state155 = load i64, ptr %.slot31, align 4
  %337 = add i64 %.state155, 3
  %338 = sdiv i64 %337, 1
  %.spill.load156 = load i64, ptr %.spill26, align 4
  %339 = add i64 %.spill.load156, %338
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %.splatinsert158 = insertelement <8 x i64> poison, i64 %339, i64 0
  %.splat159 = shufflevector <8 x i64> %.splatinsert158, <8 x i64> poison, <8 x i32> zeroinitializer
  %342 = mul <8 x i64> %.splat159, splat (i64 32)
  %343 = add <8 x i64> %341, %342
  %344 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %340, 0
  %345 = insertvalue { <8 x ptr>, <8 x i64> } %344, <8 x i64> %343, 1
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %345, 1
  %348 = extractelement <8 x ptr> %346, i32 0
  %349 = extractelement <8 x i64> %347, i32 0
  %350 = sub i64 %349, 0
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %352 = select i1 %351, i64 %350, i64 0
  %private.contiguous.address160 = getelementptr i8, ptr %348, i64 %352
  %private.contiguous.load161 = load <8 x float>, ptr %private.contiguous.address160, align 4
  %353 = select <8 x i1> %62, <8 x float> %private.contiguous.load161, <8 x float> zeroinitializer
  %.state162 = load <8 x float>, ptr %.slot35, align 32
  %354 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state162, <8 x float> %353)
  %.state163 = load i64, ptr %.slot31, align 4
  %355 = add i64 %.state163, 4
  store i64 %355, ptr %.slot31, align 4
  %356 = load <8 x float>, ptr %.slot32, align 32
  %357 = select <8 x i1> %62, <8 x float> %300, <8 x float> %356
  store <8 x float> %357, ptr %.slot32, align 32
  %358 = load <8 x float>, ptr %.slot33, align 32
  %359 = select <8 x i1> %62, <8 x float> %318, <8 x float> %358
  store <8 x float> %359, ptr %.slot33, align 32
  %360 = load <8 x float>, ptr %.slot34, align 32
  %361 = select <8 x i1> %62, <8 x float> %336, <8 x float> %360
  store <8 x float> %361, ptr %.slot34, align 32
  %362 = load <8 x float>, ptr %.slot35, align 32
  %363 = select <8 x i1> %62, <8 x float> %354, <8 x float> %362
  store <8 x float> %363, ptr %.slot35, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false130
  %.spill.load164 = load i64, ptr %.spill26, align 4
  %364 = add i64 %.spill.load164, 1536
  store i64 %364, ptr %.spill36, align 4
  %tile_snapshot.spill.load165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %365 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load165, 0
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load165, 1
  %.splatinsert166 = insertelement <8 x i64> poison, i64 %364, i64 0
  %.splat167 = shufflevector <8 x i64> %.splatinsert166, <8 x i64> poison, <8 x i32> zeroinitializer
  %367 = mul <8 x i64> %.splat167, splat (i64 32)
  %368 = add <8 x i64> %366, %367
  %369 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %365, 0
  %370 = insertvalue { <8 x ptr>, <8 x i64> } %369, <8 x i64> %368, 1
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %370, 1
  %373 = extractelement <8 x ptr> %371, i32 0
  %374 = extractelement <8 x i64> %372, i32 0
  %375 = sub i64 %374, 0
  %376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %377 = select i1 %376, i64 %375, i64 0
  %private.contiguous.address168 = getelementptr i8, ptr %373, i64 %377
  %private.contiguous.load169 = load <8 x float>, ptr %private.contiguous.address168, align 4
  %378 = select <8 x i1> %62, <8 x float> %private.contiguous.load169, <8 x float> zeroinitializer
  %.state170 = load <8 x float>, ptr %.slot32, align 32
  %379 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state170, <8 x float> %378)
  %.spill.load171 = load i64, ptr %.spill26, align 4
  %380 = add i64 %.spill.load171, 1537
  store i64 %380, ptr %.spill37, align 4
  %tile_snapshot.spill.load172 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load172, 0
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load172, 1
  %.splatinsert173 = insertelement <8 x i64> poison, i64 %380, i64 0
  %.splat174 = shufflevector <8 x i64> %.splatinsert173, <8 x i64> poison, <8 x i32> zeroinitializer
  %383 = mul <8 x i64> %.splat174, splat (i64 32)
  %384 = add <8 x i64> %382, %383
  %385 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %381, 0
  %386 = insertvalue { <8 x ptr>, <8 x i64> } %385, <8 x i64> %384, 1
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %386, 1
  %389 = extractelement <8 x ptr> %387, i32 0
  %390 = extractelement <8 x i64> %388, i32 0
  %391 = sub i64 %390, 0
  %392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %393 = select i1 %392, i64 %391, i64 0
  %private.contiguous.address175 = getelementptr i8, ptr %389, i64 %393
  %private.contiguous.load176 = load <8 x float>, ptr %private.contiguous.address175, align 4
  %394 = select <8 x i1> %62, <8 x float> %private.contiguous.load176, <8 x float> zeroinitializer
  %.state177 = load <8 x float>, ptr %.slot33, align 32
  %395 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state177, <8 x float> %394)
  %.spill.load178 = load float, ptr %.spill25, align 4
  %.splatinsert179 = insertelement <8 x float> poison, float %.spill.load178, i64 0
  %.splat180 = shufflevector <8 x float> %.splatinsert179, <8 x float> poison, <8 x i32> zeroinitializer
  %396 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.splat180, <8 x float> %379)
  %397 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %396, <8 x float> %395)
  %.state181 = load <8 x float>, ptr %.slot34, align 32
  %398 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %397, <8 x float> %.state181)
  %.state182 = load <8 x float>, ptr %.slot35, align 32
  %399 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %398, <8 x float> %.state182)
  %400 = load <8 x float>, ptr %.spill38, align 32
  %401 = select <8 x i1> %62, <8 x float> %399, <8 x float> %400
  store <8 x float> %401, ptr %.spill38, align 32
  store float 0.000000e+00, ptr %.spill39, align 4
  %402 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %402, 0
  %405 = select <8 x i1> %62, <8 x ptr> %403, <8 x ptr> %404
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %402, 1
  %408 = select <8 x i1> %62, <8 x i64> %406, <8 x i64> %407
  %409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %405, 0
  %410 = insertvalue { <8 x ptr>, <8 x i64> } %409, <8 x i64> %408, 1
  store { <8 x ptr>, <8 x i64> } %410, ptr %tile_snapshot.spill40, align 64
  store i64 0, ptr %.slot41, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state183 = load i64, ptr %.slot41, align 4
  %411 = icmp slt i64 %.state183, 1538
  br i1 %411, label %direct.true184, label %direct.false185

direct.schedule.17:                               ; preds = %direct.true184
  %.state186 = load i64, ptr %.slot41, align 4
  %412 = add i64 0, %.state186
  %tile_snapshot.spill.load187 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %413 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 0
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 1
  %.splatinsert188 = insertelement <8 x i64> poison, i64 %412, i64 0
  %.splat189 = shufflevector <8 x i64> %.splatinsert188, <8 x i64> poison, <8 x i32> zeroinitializer
  %415 = add <8 x i64> %414, %.splat189
  %416 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %413, 0
  %417 = insertvalue { <8 x ptr>, <8 x i64> } %416, <8 x i64> %415, 1
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %417, 0
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %417, 1
  %420 = getelementptr i8, <8 x ptr> %418, <8 x i64> %419
  %421 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %420, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %422 = icmp ne <8 x i8> %421, zeroinitializer
  %423 = add i64 0, %412
  %424 = add i64 0, %423
  %tile_snapshot.spill.load190 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %.splatinsert191 = insertelement <8 x i64> poison, i64 %424, i64 0
  %.splat192 = shufflevector <8 x i64> %.splatinsert191, <8 x i64> poison, <8 x i32> zeroinitializer
  %427 = mul <8 x i64> %.splat192, splat (i64 32)
  %428 = add <8 x i64> %426, %427
  %429 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %425, 0
  %430 = insertvalue { <8 x ptr>, <8 x i64> } %429, <8 x i64> %428, 1
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %430, 1
  %433 = extractelement <8 x ptr> %431, i32 0
  %434 = extractelement <8 x i64> %432, i32 0
  %435 = sub i64 %434, 0
  %436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %437 = select i1 %436, i64 %435, i64 0
  %private.contiguous.address193 = getelementptr i8, ptr %433, i64 %437
  %private.contiguous.load194 = load <8 x float>, ptr %private.contiguous.address193, align 4
  %438 = select <8 x i1> %62, <8 x float> %private.contiguous.load194, <8 x float> zeroinitializer
  %.spill.load195 = load <8 x float>, ptr %.spill38, align 32
  %439 = fsub <8 x float> %438, %.spill.load195
  %440 = select <8 x i1> %62, <8 x float> %439, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %440)
  %.spill.load196 = load float, ptr %.spill39, align 4
  %.splatinsert197 = insertelement <8 x float> poison, float %.spill.load196, i64 0
  %.splat198 = shufflevector <8 x float> %.splatinsert197, <8 x float> poison, <8 x i32> zeroinitializer
  %441 = select <8 x i1> %422, <8 x float> %native.exp, <8 x float> %.splat198
  %tile_snapshot.spill.load199 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load199, 0
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load199, 1
  %.state200 = load i64, ptr %.slot41, align 4
  %.splatinsert201 = insertelement <8 x i64> poison, i64 %.state200, i64 0
  %.splat202 = shufflevector <8 x i64> %.splatinsert201, <8 x i64> poison, <8 x i32> zeroinitializer
  %444 = mul <8 x i64> %.splat202, splat (i64 32)
  %445 = add <8 x i64> %443, %444
  %446 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %442, 0
  %447 = insertvalue { <8 x ptr>, <8 x i64> } %446, <8 x i64> %445, 1
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %447, 1
  %450 = extractelement <8 x ptr> %448, i32 0
  %451 = extractelement <8 x i64> %449, i32 0
  %452 = sub i64 %451, 0
  %453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %454 = select i1 %453, i64 %452, i64 0
  %private.contiguous.address203 = getelementptr i8, ptr %450, i64 %454
  %private.contiguous.preserve204 = load <8 x float>, ptr %private.contiguous.address203, align 4
  %455 = select <8 x i1> %62, <8 x float> %441, <8 x float> %private.contiguous.preserve204
  store <8 x float> %455, ptr %private.contiguous.address203, align 4
  %.state205 = load i64, ptr %.slot41, align 4
  %456 = add i64 %.state205, 1
  store i64 %456, ptr %.slot41, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false185
  %tile_snapshot.spill.load206 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load206, 0
  %458 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load206, 1
  %.spill.load207 = load i64, ptr %.spill27, align 4
  %.splatinsert208 = insertelement <8 x i64> poison, i64 %.spill.load207, i64 0
  %.splat209 = shufflevector <8 x i64> %.splatinsert208, <8 x i64> poison, <8 x i32> zeroinitializer
  %459 = mul <8 x i64> %.splat209, splat (i64 32)
  %460 = add <8 x i64> %458, %459
  %461 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %457, 0
  %462 = insertvalue { <8 x ptr>, <8 x i64> } %461, <8 x i64> %460, 1
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %462, 1
  %465 = extractelement <8 x ptr> %463, i32 0
  %466 = extractelement <8 x i64> %464, i32 0
  %467 = sub i64 %466, 0
  %468 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %469 = select i1 %468, i64 %467, i64 0
  %private.contiguous.address210 = getelementptr i8, ptr %465, i64 %469
  %private.contiguous.load211 = load <8 x float>, ptr %private.contiguous.address210, align 4
  %470 = select <8 x i1> %62, <8 x float> %private.contiguous.load211, <8 x float> zeroinitializer
  %tile_snapshot.spill.load212 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load212, 0
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load212, 1
  %.spill.load213 = load i64, ptr %.spill28, align 4
  %.splatinsert214 = insertelement <8 x i64> poison, i64 %.spill.load213, i64 0
  %.splat215 = shufflevector <8 x i64> %.splatinsert214, <8 x i64> poison, <8 x i32> zeroinitializer
  %473 = mul <8 x i64> %.splat215, splat (i64 32)
  %474 = add <8 x i64> %472, %473
  %475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %471, 0
  %476 = insertvalue { <8 x ptr>, <8 x i64> } %475, <8 x i64> %474, 1
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %476, 1
  %479 = extractelement <8 x ptr> %477, i32 0
  %480 = extractelement <8 x i64> %478, i32 0
  %481 = sub i64 %480, 0
  %482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %483 = select i1 %482, i64 %481, i64 0
  %private.contiguous.address216 = getelementptr i8, ptr %479, i64 %483
  %private.contiguous.load217 = load <8 x float>, ptr %private.contiguous.address216, align 4
  %484 = select <8 x i1> %62, <8 x float> %private.contiguous.load217, <8 x float> zeroinitializer
  %tile_snapshot.spill.load218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 0
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 1
  %.spill.load219 = load i64, ptr %.spill29, align 4
  %.splatinsert220 = insertelement <8 x i64> poison, i64 %.spill.load219, i64 0
  %.splat221 = shufflevector <8 x i64> %.splatinsert220, <8 x i64> poison, <8 x i32> zeroinitializer
  %487 = mul <8 x i64> %.splat221, splat (i64 32)
  %488 = add <8 x i64> %486, %487
  %489 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %485, 0
  %490 = insertvalue { <8 x ptr>, <8 x i64> } %489, <8 x i64> %488, 1
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %490, 1
  %493 = extractelement <8 x ptr> %491, i32 0
  %494 = extractelement <8 x i64> %492, i32 0
  %495 = sub i64 %494, 0
  %496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %497 = select i1 %496, i64 %495, i64 0
  %private.contiguous.address222 = getelementptr i8, ptr %493, i64 %497
  %private.contiguous.load223 = load <8 x float>, ptr %private.contiguous.address222, align 4
  %498 = select <8 x i1> %62, <8 x float> %private.contiguous.load223, <8 x float> zeroinitializer
  %tile_snapshot.spill.load224 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 0
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 1
  %.spill.load225 = load i64, ptr %.spill30, align 4
  %.splatinsert226 = insertelement <8 x i64> poison, i64 %.spill.load225, i64 0
  %.splat227 = shufflevector <8 x i64> %.splatinsert226, <8 x i64> poison, <8 x i32> zeroinitializer
  %501 = mul <8 x i64> %.splat227, splat (i64 32)
  %502 = add <8 x i64> %500, %501
  %503 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %499, 0
  %504 = insertvalue { <8 x ptr>, <8 x i64> } %503, <8 x i64> %502, 1
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %504, 1
  %507 = extractelement <8 x ptr> %505, i32 0
  %508 = extractelement <8 x i64> %506, i32 0
  %509 = sub i64 %508, 0
  %510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %511 = select i1 %510, i64 %509, i64 0
  %private.contiguous.address228 = getelementptr i8, ptr %507, i64 %511
  %private.contiguous.load229 = load <8 x float>, ptr %private.contiguous.address228, align 4
  %512 = select <8 x i1> %62, <8 x float> %private.contiguous.load229, <8 x float> zeroinitializer
  store i64 4, ptr %.slot42, align 4
  %513 = load <8 x float>, ptr %.slot43, align 32
  %514 = select <8 x i1> %62, <8 x float> %470, <8 x float> %513
  store <8 x float> %514, ptr %.slot43, align 32
  %515 = load <8 x float>, ptr %.slot44, align 32
  %516 = select <8 x i1> %62, <8 x float> %484, <8 x float> %515
  store <8 x float> %516, ptr %.slot44, align 32
  %517 = load <8 x float>, ptr %.slot45, align 32
  %518 = select <8 x i1> %62, <8 x float> %498, <8 x float> %517
  store <8 x float> %518, ptr %.slot45, align 32
  %519 = load <8 x float>, ptr %.slot46, align 32
  %520 = select <8 x i1> %62, <8 x float> %512, <8 x float> %519
  store <8 x float> %520, ptr %.slot46, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state230 = load i64, ptr %.slot42, align 4
  %521 = icmp slt i64 %.state230, 1536
  br i1 %521, label %direct.true231, label %direct.false232

direct.schedule.20:                               ; preds = %direct.true231
  %.state233 = load i64, ptr %.slot42, align 4
  %522 = add i64 %.state233, 0
  %523 = sdiv i64 %522, 1
  %.spill.load234 = load i64, ptr %.spill26, align 4
  %524 = add i64 %.spill.load234, %523
  %tile_snapshot.spill.load235 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %525 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 0
  %526 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 1
  %.splatinsert236 = insertelement <8 x i64> poison, i64 %524, i64 0
  %.splat237 = shufflevector <8 x i64> %.splatinsert236, <8 x i64> poison, <8 x i32> zeroinitializer
  %527 = mul <8 x i64> %.splat237, splat (i64 32)
  %528 = add <8 x i64> %526, %527
  %529 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %525, 0
  %530 = insertvalue { <8 x ptr>, <8 x i64> } %529, <8 x i64> %528, 1
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %530, 1
  %533 = extractelement <8 x ptr> %531, i32 0
  %534 = extractelement <8 x i64> %532, i32 0
  %535 = sub i64 %534, 0
  %536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %537 = select i1 %536, i64 %535, i64 0
  %private.contiguous.address238 = getelementptr i8, ptr %533, i64 %537
  %private.contiguous.load239 = load <8 x float>, ptr %private.contiguous.address238, align 4
  %538 = select <8 x i1> %62, <8 x float> %private.contiguous.load239, <8 x float> zeroinitializer
  %.state240 = load <8 x float>, ptr %.slot43, align 32
  %539 = fadd <8 x float> %.state240, %538
  %.state241 = load i64, ptr %.slot42, align 4
  %540 = add i64 %.state241, 1
  %541 = sdiv i64 %540, 1
  %.spill.load242 = load i64, ptr %.spill26, align 4
  %542 = add i64 %.spill.load242, %541
  %tile_snapshot.spill.load243 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %543 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load243, 0
  %544 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load243, 1
  %.splatinsert244 = insertelement <8 x i64> poison, i64 %542, i64 0
  %.splat245 = shufflevector <8 x i64> %.splatinsert244, <8 x i64> poison, <8 x i32> zeroinitializer
  %545 = mul <8 x i64> %.splat245, splat (i64 32)
  %546 = add <8 x i64> %544, %545
  %547 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %543, 0
  %548 = insertvalue { <8 x ptr>, <8 x i64> } %547, <8 x i64> %546, 1
  %549 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %550 = extractvalue { <8 x ptr>, <8 x i64> } %548, 1
  %551 = extractelement <8 x ptr> %549, i32 0
  %552 = extractelement <8 x i64> %550, i32 0
  %553 = sub i64 %552, 0
  %554 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %555 = select i1 %554, i64 %553, i64 0
  %private.contiguous.address246 = getelementptr i8, ptr %551, i64 %555
  %private.contiguous.load247 = load <8 x float>, ptr %private.contiguous.address246, align 4
  %556 = select <8 x i1> %62, <8 x float> %private.contiguous.load247, <8 x float> zeroinitializer
  %.state248 = load <8 x float>, ptr %.slot44, align 32
  %557 = fadd <8 x float> %.state248, %556
  %.state249 = load i64, ptr %.slot42, align 4
  %558 = add i64 %.state249, 2
  %559 = sdiv i64 %558, 1
  %.spill.load250 = load i64, ptr %.spill26, align 4
  %560 = add i64 %.spill.load250, %559
  %tile_snapshot.spill.load251 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 0
  %562 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 1
  %.splatinsert252 = insertelement <8 x i64> poison, i64 %560, i64 0
  %.splat253 = shufflevector <8 x i64> %.splatinsert252, <8 x i64> poison, <8 x i32> zeroinitializer
  %563 = mul <8 x i64> %.splat253, splat (i64 32)
  %564 = add <8 x i64> %562, %563
  %565 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %561, 0
  %566 = insertvalue { <8 x ptr>, <8 x i64> } %565, <8 x i64> %564, 1
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %568 = extractvalue { <8 x ptr>, <8 x i64> } %566, 1
  %569 = extractelement <8 x ptr> %567, i32 0
  %570 = extractelement <8 x i64> %568, i32 0
  %571 = sub i64 %570, 0
  %572 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %573 = select i1 %572, i64 %571, i64 0
  %private.contiguous.address254 = getelementptr i8, ptr %569, i64 %573
  %private.contiguous.load255 = load <8 x float>, ptr %private.contiguous.address254, align 4
  %574 = select <8 x i1> %62, <8 x float> %private.contiguous.load255, <8 x float> zeroinitializer
  %.state256 = load <8 x float>, ptr %.slot45, align 32
  %575 = fadd <8 x float> %.state256, %574
  %.state257 = load i64, ptr %.slot42, align 4
  %576 = add i64 %.state257, 3
  %577 = sdiv i64 %576, 1
  %.spill.load258 = load i64, ptr %.spill26, align 4
  %578 = add i64 %.spill.load258, %577
  %tile_snapshot.spill.load259 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %579 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 0
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 1
  %.splatinsert260 = insertelement <8 x i64> poison, i64 %578, i64 0
  %.splat261 = shufflevector <8 x i64> %.splatinsert260, <8 x i64> poison, <8 x i32> zeroinitializer
  %581 = mul <8 x i64> %.splat261, splat (i64 32)
  %582 = add <8 x i64> %580, %581
  %583 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %579, 0
  %584 = insertvalue { <8 x ptr>, <8 x i64> } %583, <8 x i64> %582, 1
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %584, 1
  %587 = extractelement <8 x ptr> %585, i32 0
  %588 = extractelement <8 x i64> %586, i32 0
  %589 = sub i64 %588, 0
  %590 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %591 = select i1 %590, i64 %589, i64 0
  %private.contiguous.address262 = getelementptr i8, ptr %587, i64 %591
  %private.contiguous.load263 = load <8 x float>, ptr %private.contiguous.address262, align 4
  %592 = select <8 x i1> %62, <8 x float> %private.contiguous.load263, <8 x float> zeroinitializer
  %.state264 = load <8 x float>, ptr %.slot46, align 32
  %593 = fadd <8 x float> %.state264, %592
  %.state265 = load i64, ptr %.slot42, align 4
  %594 = add i64 %.state265, 4
  store i64 %594, ptr %.slot42, align 4
  %595 = load <8 x float>, ptr %.slot43, align 32
  %596 = select <8 x i1> %62, <8 x float> %539, <8 x float> %595
  store <8 x float> %596, ptr %.slot43, align 32
  %597 = load <8 x float>, ptr %.slot44, align 32
  %598 = select <8 x i1> %62, <8 x float> %557, <8 x float> %597
  store <8 x float> %598, ptr %.slot44, align 32
  %599 = load <8 x float>, ptr %.slot45, align 32
  %600 = select <8 x i1> %62, <8 x float> %575, <8 x float> %599
  store <8 x float> %600, ptr %.slot45, align 32
  %601 = load <8 x float>, ptr %.slot46, align 32
  %602 = select <8 x i1> %62, <8 x float> %593, <8 x float> %601
  store <8 x float> %602, ptr %.slot46, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false232
  %tile_snapshot.spill.load266 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %603 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 0
  %604 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 1
  %.spill.load267 = load i64, ptr %.spill36, align 4
  %.splatinsert268 = insertelement <8 x i64> poison, i64 %.spill.load267, i64 0
  %.splat269 = shufflevector <8 x i64> %.splatinsert268, <8 x i64> poison, <8 x i32> zeroinitializer
  %605 = mul <8 x i64> %.splat269, splat (i64 32)
  %606 = add <8 x i64> %604, %605
  %607 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %603, 0
  %608 = insertvalue { <8 x ptr>, <8 x i64> } %607, <8 x i64> %606, 1
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %610 = extractvalue { <8 x ptr>, <8 x i64> } %608, 1
  %611 = extractelement <8 x ptr> %609, i32 0
  %612 = extractelement <8 x i64> %610, i32 0
  %613 = sub i64 %612, 0
  %614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %615 = select i1 %614, i64 %613, i64 0
  %private.contiguous.address270 = getelementptr i8, ptr %611, i64 %615
  %private.contiguous.load271 = load <8 x float>, ptr %private.contiguous.address270, align 4
  %616 = select <8 x i1> %62, <8 x float> %private.contiguous.load271, <8 x float> zeroinitializer
  %.state272 = load <8 x float>, ptr %.slot43, align 32
  %617 = fadd <8 x float> %.state272, %616
  %tile_snapshot.spill.load273 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load273, 0
  %619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load273, 1
  %.spill.load274 = load i64, ptr %.spill37, align 4
  %.splatinsert275 = insertelement <8 x i64> poison, i64 %.spill.load274, i64 0
  %.splat276 = shufflevector <8 x i64> %.splatinsert275, <8 x i64> poison, <8 x i32> zeroinitializer
  %620 = mul <8 x i64> %.splat276, splat (i64 32)
  %621 = add <8 x i64> %619, %620
  %622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %618, 0
  %623 = insertvalue { <8 x ptr>, <8 x i64> } %622, <8 x i64> %621, 1
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %625 = extractvalue { <8 x ptr>, <8 x i64> } %623, 1
  %626 = extractelement <8 x ptr> %624, i32 0
  %627 = extractelement <8 x i64> %625, i32 0
  %628 = sub i64 %627, 0
  %629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %630 = select i1 %629, i64 %628, i64 0
  %private.contiguous.address277 = getelementptr i8, ptr %626, i64 %630
  %private.contiguous.load278 = load <8 x float>, ptr %private.contiguous.address277, align 4
  %631 = select <8 x i1> %62, <8 x float> %private.contiguous.load278, <8 x float> zeroinitializer
  %.state279 = load <8 x float>, ptr %.slot44, align 32
  %632 = fadd <8 x float> %.state279, %631
  %.spill.load280 = load float, ptr %.spill39, align 4
  %.splatinsert281 = insertelement <8 x float> poison, float %.spill.load280, i64 0
  %.splat282 = shufflevector <8 x float> %.splatinsert281, <8 x float> poison, <8 x i32> zeroinitializer
  %633 = fadd <8 x float> %.splat282, %617
  %634 = fadd <8 x float> %633, %632
  %.state283 = load <8 x float>, ptr %.slot45, align 32
  %635 = fadd <8 x float> %634, %.state283
  %.state284 = load <8 x float>, ptr %.slot46, align 32
  %636 = fadd <8 x float> %635, %.state284
  %637 = load <8 x float>, ptr %.spill47, align 32
  %638 = select <8 x i1> %62, <8 x float> %636, <8 x float> %637
  store <8 x float> %638, ptr %.spill47, align 32
  store i64 0, ptr %.slot48, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state285 = load i64, ptr %.slot48, align 4
  %639 = icmp slt i64 %.state285, 1538
  br i1 %639, label %direct.true286, label %direct.false287

direct.schedule.23:                               ; preds = %direct.true286
  %.spill.load288 = load <8 x i64>, ptr %.spill, align 64
  %640 = add <8 x i64> %.spill.load288, zeroinitializer
  %641 = add <8 x i64> zeroinitializer, %640
  %.state289 = load i64, ptr %.slot48, align 4
  %642 = add i64 0, %.state289
  %643 = mul <8 x i64> %641, splat (i64 1538)
  %.splatinsert290 = insertelement <8 x i64> poison, i64 %642, i64 0
  %.splat291 = shufflevector <8 x i64> %.splatinsert290, <8 x i64> poison, <8 x i32> zeroinitializer
  %644 = add <8 x i64> %643, %.splat291
  %.state292 = load i64, ptr %.slot48, align 4
  %645 = add i64 0, %.state292
  %tile_snapshot.spill.load293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 0
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 1
  %.splatinsert294 = insertelement <8 x i64> poison, i64 %645, i64 0
  %.splat295 = shufflevector <8 x i64> %.splatinsert294, <8 x i64> poison, <8 x i32> zeroinitializer
  %648 = mul <8 x i64> %.splat295, splat (i64 32)
  %649 = add <8 x i64> %647, %648
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %646, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = extractelement <8 x ptr> %652, i32 0
  %655 = extractelement <8 x i64> %653, i32 0
  %656 = sub i64 %655, 0
  %657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %658 = select i1 %657, i64 %656, i64 0
  %private.contiguous.address296 = getelementptr i8, ptr %654, i64 %658
  %private.contiguous.load297 = load <8 x float>, ptr %private.contiguous.address296, align 4
  %659 = select <8 x i1> %62, <8 x float> %private.contiguous.load297, <8 x float> zeroinitializer
  %.spill.load298 = load <8 x float>, ptr %.spill47, align 32
  %660 = fdiv <8 x float> %659, %.spill.load298
  %661 = extractvalue { ptr, i64 } %38, 0
  %662 = mul <8 x i64> %644, splat (i64 4)
  %663 = getelementptr i8, ptr %661, <8 x i64> %662
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %660, <8 x ptr> %663, i32 1, <8 x i1> %62)
  %.state299 = load i64, ptr %.slot48, align 4
  %664 = add i64 %.state299, 1
  store i64 %664, ptr %.slot48, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false287
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true67:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false68:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true81:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false82:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true95:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false96:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true129:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false130:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true184:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false185:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true231:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false232:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true286:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false287:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

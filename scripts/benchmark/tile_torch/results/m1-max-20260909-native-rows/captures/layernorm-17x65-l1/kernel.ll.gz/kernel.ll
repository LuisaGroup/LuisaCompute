; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [2080 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [2080 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [2080 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [2080 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill10 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill10, align 4
  %.spill11 = alloca i64, align 8
  store i64 0, ptr %.spill11, align 4
  %.spill12 = alloca i64, align 8
  store i64 0, ptr %.spill12, align 4
  %.spill13 = alloca i64, align 8
  store i64 0, ptr %.spill13, align 4
  %.spill14 = alloca i64, align 8
  store i64 0, ptr %.spill14, align 4
  %.spill15 = alloca i64, align 8
  store i64 0, ptr %.spill15, align 4
  %.spill16 = alloca i64, align 8
  store i64 0, ptr %.spill16, align 4
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %.slot18 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot18, align 32
  %.slot19 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot19, align 32
  %.slot20 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot20, align 32
  %.slot21 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.spill22 = alloca i64, align 8
  store i64 0, ptr %.spill22, align 4
  %.spill23 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill23, align 4
  %.spill24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill24, align 32
  %tile_snapshot.spill25 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill25, align 64
  %.slot26 = alloca i64, align 8
  store i64 0, ptr %.slot26, align 4
  %.spill27 = alloca i64, align 8
  store i64 0, ptr %.spill27, align 4
  %.slot28 = alloca i64, align 8
  store i64 0, ptr %.slot28, align 4
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.slot30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot30, align 32
  %.slot31 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot31, align 32
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.spill33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill33, align 32
  %tile_snapshot.spill34 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill34, align 64
  %.slot35 = alloca i64, align 8
  store i64 0, ptr %.slot35, align 4
  %.spill36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill36, align 32
  %tile_snapshot.spill37 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill37, align 64
  %.slot38 = alloca i64, align 8
  store i64 0, ptr %.slot38, align 4
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert40 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat41 = shufflevector <8 x i32> %.splatinsert40, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat41, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert42 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat43 = shufflevector <8 x i32> %.splatinsert42, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat43, %45
  %48 = mul i32 %36, 1
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat45, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat47, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat49
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = zext <8 x i32> %57 to <8 x i64>
  %59 = select <8 x i1> %55, <8 x i64> %58, <8 x i64> zeroinitializer
  %60 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %61 = sdiv <8 x i64> %59, %60
  %62 = load <8 x i64>, ptr %.spill, align 64
  %63 = select <8 x i1> %55, <8 x i64> %61, <8 x i64> %62
  store <8 x i64> %63, ptr %.spill, align 64
  %64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %64, 0
  %67 = select <8 x i1> %55, <8 x ptr> %65, <8 x ptr> %66
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %64, 1
  %70 = select <8 x i1> %55, <8 x i64> %68, <8 x i64> %69
  %71 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %67, 0
  %72 = insertvalue { <8 x ptr>, <8 x i64> } %71, <8 x i64> %70, 1
  store { <8 x ptr>, <8 x i64> } %72, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %73 = icmp slt i64 %.state, 65
  br i1 %73, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %74 = add <8 x i64> %.spill.load, zeroinitializer
  %75 = add <8 x i64> zeroinitializer, %74
  %.state50 = load i64, ptr %.slot, align 4
  %76 = add i64 0, %.state50
  %77 = mul <8 x i64> %75, splat (i64 65)
  %.splatinsert51 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat52 = shufflevector <8 x i64> %.splatinsert51, <8 x i64> poison, <8 x i32> zeroinitializer
  %78 = add <8 x i64> %77, %.splat52
  %79 = extractvalue { ptr, i64 } %13, 0
  %80 = mul <8 x i64> %78, splat (i64 4)
  %81 = getelementptr i8, ptr %79, <8 x i64> %80
  %82 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %81, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %83 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %84 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state53 = load i64, ptr %.slot, align 4
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %.state53, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %85 = mul <8 x i64> %.splat55, splat (i64 32)
  %86 = add <8 x i64> %84, %85
  %87 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %83, 0
  %88 = insertvalue { <8 x ptr>, <8 x i64> } %87, <8 x i64> %86, 1
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %88, 1
  %91 = extractelement <8 x ptr> %89, i32 0
  %92 = extractelement <8 x i64> %90, i32 0
  %93 = sub i64 %92, 0
  %94 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %95 = select i1 %94, i64 %93, i64 0
  %private.contiguous.address = getelementptr i8, ptr %91, i64 %95
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %96 = select <8 x i1> %55, <8 x float> %82, <8 x float> %private.contiguous.preserve
  store <8 x float> %96, ptr %private.contiguous.address, align 4
  %.state56 = load i64, ptr %.slot, align 4
  %97 = add i64 %.state56, 1
  store i64 %97, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill10, align 4
  store i64 0, ptr %.spill11, align 4
  store i64 0, ptr %.spill12, align 4
  store i64 0, ptr %.spill13, align 4
  %tile_snapshot.spill.load57 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 0
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 1
  %100 = add <8 x i64> %99, zeroinitializer
  %101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %98, 0
  %102 = insertvalue { <8 x ptr>, <8 x i64> } %101, <8 x i64> %100, 1
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %102, 1
  %105 = extractelement <8 x ptr> %103, i32 0
  %106 = extractelement <8 x i64> %104, i32 0
  %107 = sub i64 %106, 0
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %109 = select i1 %108, i64 %107, i64 0
  %private.contiguous.address58 = getelementptr i8, ptr %105, i64 %109
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address58, align 4
  %110 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  store i64 1, ptr %.spill14, align 4
  %tile_snapshot.spill.load59 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 0
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 1
  %113 = add <8 x i64> %112, splat (i64 32)
  %114 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %111, 0
  %115 = insertvalue { <8 x ptr>, <8 x i64> } %114, <8 x i64> %113, 1
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %115, 1
  %118 = extractelement <8 x ptr> %116, i32 0
  %119 = extractelement <8 x i64> %117, i32 0
  %120 = sub i64 %119, 0
  %121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %122 = select i1 %121, i64 %120, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %118, i64 %122
  %private.contiguous.load61 = load <8 x float>, ptr %private.contiguous.address60, align 4
  %123 = select <8 x i1> %55, <8 x float> %private.contiguous.load61, <8 x float> zeroinitializer
  store i64 2, ptr %.spill15, align 4
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %126 = add <8 x i64> %125, splat (i64 64)
  %127 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %124, 0
  %128 = insertvalue { <8 x ptr>, <8 x i64> } %127, <8 x i64> %126, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %128, 1
  %131 = extractelement <8 x ptr> %129, i32 0
  %132 = extractelement <8 x i64> %130, i32 0
  %133 = sub i64 %132, 0
  %134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %135 = select i1 %134, i64 %133, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %131, i64 %135
  %private.contiguous.load64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %136 = select <8 x i1> %55, <8 x float> %private.contiguous.load64, <8 x float> zeroinitializer
  store i64 3, ptr %.spill16, align 4
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %139 = add <8 x i64> %138, splat (i64 96)
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %137, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %141, 1
  %144 = extractelement <8 x ptr> %142, i32 0
  %145 = extractelement <8 x i64> %143, i32 0
  %146 = sub i64 %145, 0
  %147 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %148 = select i1 %147, i64 %146, i64 0
  %private.contiguous.address66 = getelementptr i8, ptr %144, i64 %148
  %private.contiguous.load67 = load <8 x float>, ptr %private.contiguous.address66, align 4
  %149 = select <8 x i1> %55, <8 x float> %private.contiguous.load67, <8 x float> zeroinitializer
  store i64 4, ptr %.slot17, align 4
  %150 = load <8 x float>, ptr %.slot18, align 32
  %151 = select <8 x i1> %55, <8 x float> %110, <8 x float> %150
  store <8 x float> %151, ptr %.slot18, align 32
  %152 = load <8 x float>, ptr %.slot19, align 32
  %153 = select <8 x i1> %55, <8 x float> %123, <8 x float> %152
  store <8 x float> %153, ptr %.slot19, align 32
  %154 = load <8 x float>, ptr %.slot20, align 32
  %155 = select <8 x i1> %55, <8 x float> %136, <8 x float> %154
  store <8 x float> %155, ptr %.slot20, align 32
  %156 = load <8 x float>, ptr %.slot21, align 32
  %157 = select <8 x i1> %55, <8 x float> %149, <8 x float> %156
  store <8 x float> %157, ptr %.slot21, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state68 = load i64, ptr %.slot17, align 4
  %158 = icmp slt i64 %.state68, 64
  br i1 %158, label %direct.true69, label %direct.false70

direct.schedule.5:                                ; preds = %direct.true69
  %.state71 = load i64, ptr %.slot17, align 4
  %159 = add i64 %.state71, 0
  %160 = sdiv i64 %159, 1
  %.spill.load72 = load i64, ptr %.spill12, align 4
  %161 = add i64 %.spill.load72, %160
  %tile_snapshot.spill.load73 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 0
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 1
  %.splatinsert74 = insertelement <8 x i64> poison, i64 %161, i64 0
  %.splat75 = shufflevector <8 x i64> %.splatinsert74, <8 x i64> poison, <8 x i32> zeroinitializer
  %164 = mul <8 x i64> %.splat75, splat (i64 32)
  %165 = add <8 x i64> %163, %164
  %166 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %162, 0
  %167 = insertvalue { <8 x ptr>, <8 x i64> } %166, <8 x i64> %165, 1
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %167, 1
  %170 = extractelement <8 x ptr> %168, i32 0
  %171 = extractelement <8 x i64> %169, i32 0
  %172 = sub i64 %171, 0
  %173 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %174 = select i1 %173, i64 %172, i64 0
  %private.contiguous.address76 = getelementptr i8, ptr %170, i64 %174
  %private.contiguous.load77 = load <8 x float>, ptr %private.contiguous.address76, align 4
  %175 = select <8 x i1> %55, <8 x float> %private.contiguous.load77, <8 x float> zeroinitializer
  %.state78 = load <8 x float>, ptr %.slot18, align 32
  %176 = fadd <8 x float> %.state78, %175
  %.state79 = load i64, ptr %.slot17, align 4
  %177 = add i64 %.state79, 1
  %178 = sdiv i64 %177, 1
  %.spill.load80 = load i64, ptr %.spill12, align 4
  %179 = add i64 %.spill.load80, %178
  %tile_snapshot.spill.load81 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 0
  %181 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 1
  %.splatinsert82 = insertelement <8 x i64> poison, i64 %179, i64 0
  %.splat83 = shufflevector <8 x i64> %.splatinsert82, <8 x i64> poison, <8 x i32> zeroinitializer
  %182 = mul <8 x i64> %.splat83, splat (i64 32)
  %183 = add <8 x i64> %181, %182
  %184 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %180, 0
  %185 = insertvalue { <8 x ptr>, <8 x i64> } %184, <8 x i64> %183, 1
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %185, 1
  %188 = extractelement <8 x ptr> %186, i32 0
  %189 = extractelement <8 x i64> %187, i32 0
  %190 = sub i64 %189, 0
  %191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %192 = select i1 %191, i64 %190, i64 0
  %private.contiguous.address84 = getelementptr i8, ptr %188, i64 %192
  %private.contiguous.load85 = load <8 x float>, ptr %private.contiguous.address84, align 4
  %193 = select <8 x i1> %55, <8 x float> %private.contiguous.load85, <8 x float> zeroinitializer
  %.state86 = load <8 x float>, ptr %.slot19, align 32
  %194 = fadd <8 x float> %.state86, %193
  %.state87 = load i64, ptr %.slot17, align 4
  %195 = add i64 %.state87, 2
  %196 = sdiv i64 %195, 1
  %.spill.load88 = load i64, ptr %.spill12, align 4
  %197 = add i64 %.spill.load88, %196
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %197, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %200 = mul <8 x i64> %.splat91, splat (i64 32)
  %201 = add <8 x i64> %199, %200
  %202 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %198, 0
  %203 = insertvalue { <8 x ptr>, <8 x i64> } %202, <8 x i64> %201, 1
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %203, 1
  %206 = extractelement <8 x ptr> %204, i32 0
  %207 = extractelement <8 x i64> %205, i32 0
  %208 = sub i64 %207, 0
  %209 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %210 = select i1 %209, i64 %208, i64 0
  %private.contiguous.address92 = getelementptr i8, ptr %206, i64 %210
  %private.contiguous.load93 = load <8 x float>, ptr %private.contiguous.address92, align 4
  %211 = select <8 x i1> %55, <8 x float> %private.contiguous.load93, <8 x float> zeroinitializer
  %.state94 = load <8 x float>, ptr %.slot20, align 32
  %212 = fadd <8 x float> %.state94, %211
  %.state95 = load i64, ptr %.slot17, align 4
  %213 = add i64 %.state95, 3
  %214 = sdiv i64 %213, 1
  %.spill.load96 = load i64, ptr %.spill12, align 4
  %215 = add i64 %.spill.load96, %214
  %tile_snapshot.spill.load97 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 0
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 1
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %215, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %218 = mul <8 x i64> %.splat99, splat (i64 32)
  %219 = add <8 x i64> %217, %218
  %220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %216, 0
  %221 = insertvalue { <8 x ptr>, <8 x i64> } %220, <8 x i64> %219, 1
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %221, 1
  %224 = extractelement <8 x ptr> %222, i32 0
  %225 = extractelement <8 x i64> %223, i32 0
  %226 = sub i64 %225, 0
  %227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %228 = select i1 %227, i64 %226, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %224, i64 %228
  %private.contiguous.load101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %229 = select <8 x i1> %55, <8 x float> %private.contiguous.load101, <8 x float> zeroinitializer
  %.state102 = load <8 x float>, ptr %.slot21, align 32
  %230 = fadd <8 x float> %.state102, %229
  %.state103 = load i64, ptr %.slot17, align 4
  %231 = add i64 %.state103, 4
  store i64 %231, ptr %.slot17, align 4
  %232 = load <8 x float>, ptr %.slot18, align 32
  %233 = select <8 x i1> %55, <8 x float> %176, <8 x float> %232
  store <8 x float> %233, ptr %.slot18, align 32
  %234 = load <8 x float>, ptr %.slot19, align 32
  %235 = select <8 x i1> %55, <8 x float> %194, <8 x float> %234
  store <8 x float> %235, ptr %.slot19, align 32
  %236 = load <8 x float>, ptr %.slot20, align 32
  %237 = select <8 x i1> %55, <8 x float> %212, <8 x float> %236
  store <8 x float> %237, ptr %.slot20, align 32
  %238 = load <8 x float>, ptr %.slot21, align 32
  %239 = select <8 x i1> %55, <8 x float> %230, <8 x float> %238
  store <8 x float> %239, ptr %.slot21, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false70
  %.spill.load104 = load i64, ptr %.spill12, align 4
  %240 = add i64 %.spill.load104, 64
  store i64 %240, ptr %.spill22, align 4
  %tile_snapshot.spill.load105 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load105, 0
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load105, 1
  %.splatinsert106 = insertelement <8 x i64> poison, i64 %240, i64 0
  %.splat107 = shufflevector <8 x i64> %.splatinsert106, <8 x i64> poison, <8 x i32> zeroinitializer
  %243 = mul <8 x i64> %.splat107, splat (i64 32)
  %244 = add <8 x i64> %242, %243
  %245 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %241, 0
  %246 = insertvalue { <8 x ptr>, <8 x i64> } %245, <8 x i64> %244, 1
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %246, 1
  %249 = extractelement <8 x ptr> %247, i32 0
  %250 = extractelement <8 x i64> %248, i32 0
  %251 = sub i64 %250, 0
  %252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %253 = select i1 %252, i64 %251, i64 0
  %private.contiguous.address108 = getelementptr i8, ptr %249, i64 %253
  %private.contiguous.load109 = load <8 x float>, ptr %private.contiguous.address108, align 4
  %254 = select <8 x i1> %55, <8 x float> %private.contiguous.load109, <8 x float> zeroinitializer
  %.state110 = load <8 x float>, ptr %.slot18, align 32
  %255 = fadd <8 x float> %.state110, %254
  %.spill.load111 = load float, ptr %.spill10, align 4
  %.splatinsert112 = insertelement <8 x float> poison, float %.spill.load111, i64 0
  %.splat113 = shufflevector <8 x float> %.splatinsert112, <8 x float> poison, <8 x i32> zeroinitializer
  %256 = fadd <8 x float> %.splat113, %255
  %.state114 = load <8 x float>, ptr %.slot19, align 32
  %257 = fadd <8 x float> %256, %.state114
  %.state115 = load <8 x float>, ptr %.slot20, align 32
  %258 = fadd <8 x float> %257, %.state115
  %.state116 = load <8 x float>, ptr %.slot21, align 32
  %259 = fadd <8 x float> %258, %.state116
  store float 6.500000e+01, ptr %.spill23, align 4
  %260 = fdiv <8 x float> %259, splat (float 6.500000e+01)
  %261 = load <8 x float>, ptr %.spill24, align 32
  %262 = select <8 x i1> %55, <8 x float> %260, <8 x float> %261
  store <8 x float> %262, ptr %.spill24, align 32
  %263 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %263, 0
  %266 = select <8 x i1> %55, <8 x ptr> %264, <8 x ptr> %265
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %263, 1
  %269 = select <8 x i1> %55, <8 x i64> %267, <8 x i64> %268
  %270 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %266, 0
  %271 = insertvalue { <8 x ptr>, <8 x i64> } %270, <8 x i64> %269, 1
  store { <8 x ptr>, <8 x i64> } %271, ptr %tile_snapshot.spill25, align 64
  store i64 0, ptr %.slot26, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state117 = load i64, ptr %.slot26, align 4
  %272 = icmp slt i64 %.state117, 65
  br i1 %272, label %direct.true118, label %direct.false119

direct.schedule.8:                                ; preds = %direct.true118
  %.state120 = load i64, ptr %.slot26, align 4
  %273 = add i64 0, %.state120
  %tile_snapshot.spill.load121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 0
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 1
  %.splatinsert122 = insertelement <8 x i64> poison, i64 %273, i64 0
  %.splat123 = shufflevector <8 x i64> %.splatinsert122, <8 x i64> poison, <8 x i32> zeroinitializer
  %276 = mul <8 x i64> %.splat123, splat (i64 32)
  %277 = add <8 x i64> %275, %276
  %278 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %274, 0
  %279 = insertvalue { <8 x ptr>, <8 x i64> } %278, <8 x i64> %277, 1
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %279, 1
  %282 = extractelement <8 x ptr> %280, i32 0
  %283 = extractelement <8 x i64> %281, i32 0
  %284 = sub i64 %283, 0
  %285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %286 = select i1 %285, i64 %284, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %282, i64 %286
  %private.contiguous.load125 = load <8 x float>, ptr %private.contiguous.address124, align 4
  %287 = select <8 x i1> %55, <8 x float> %private.contiguous.load125, <8 x float> zeroinitializer
  %.spill.load126 = load <8 x float>, ptr %.spill24, align 32
  %288 = fsub <8 x float> %287, %.spill.load126
  %tile_snapshot.spill.load127 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load127, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load127, 1
  %.state128 = load i64, ptr %.slot26, align 4
  %.splatinsert129 = insertelement <8 x i64> poison, i64 %.state128, i64 0
  %.splat130 = shufflevector <8 x i64> %.splatinsert129, <8 x i64> poison, <8 x i32> zeroinitializer
  %291 = mul <8 x i64> %.splat130, splat (i64 32)
  %292 = add <8 x i64> %290, %291
  %293 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %289, 0
  %294 = insertvalue { <8 x ptr>, <8 x i64> } %293, <8 x i64> %292, 1
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %294, 1
  %297 = extractelement <8 x ptr> %295, i32 0
  %298 = extractelement <8 x i64> %296, i32 0
  %299 = sub i64 %298, 0
  %300 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %301 = select i1 %300, i64 %299, i64 0
  %private.contiguous.address131 = getelementptr i8, ptr %297, i64 %301
  %private.contiguous.preserve132 = load <8 x float>, ptr %private.contiguous.address131, align 4
  %302 = select <8 x i1> %55, <8 x float> %288, <8 x float> %private.contiguous.preserve132
  store <8 x float> %302, ptr %private.contiguous.address131, align 4
  %.state133 = load i64, ptr %.slot26, align 4
  %303 = add i64 %.state133, 1
  store i64 %303, ptr %.slot26, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false119
  store i64 0, ptr %.spill27, align 4
  %.spill.load134 = load i64, ptr %.spill13, align 4
  %304 = add i64 0, %.spill.load134
  %tile_snapshot.spill.load135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 0
  %306 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 1
  %.splatinsert136 = insertelement <8 x i64> poison, i64 %304, i64 0
  %.splat137 = shufflevector <8 x i64> %.splatinsert136, <8 x i64> poison, <8 x i32> zeroinitializer
  %307 = mul <8 x i64> %.splat137, splat (i64 32)
  %308 = add <8 x i64> %306, %307
  %309 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %305, 0
  %310 = insertvalue { <8 x ptr>, <8 x i64> } %309, <8 x i64> %308, 1
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %310, 1
  %313 = extractelement <8 x ptr> %311, i32 0
  %314 = extractelement <8 x i64> %312, i32 0
  %315 = sub i64 %314, 0
  %316 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %317 = select i1 %316, i64 %315, i64 0
  %private.contiguous.address138 = getelementptr i8, ptr %313, i64 %317
  %private.contiguous.load139 = load <8 x float>, ptr %private.contiguous.address138, align 4
  %318 = select <8 x i1> %55, <8 x float> %private.contiguous.load139, <8 x float> zeroinitializer
  %319 = fmul <8 x float> %318, %318
  %.spill.load140 = load i64, ptr %.spill14, align 4
  %320 = add i64 0, %.spill.load140
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %.splatinsert142 = insertelement <8 x i64> poison, i64 %320, i64 0
  %.splat143 = shufflevector <8 x i64> %.splatinsert142, <8 x i64> poison, <8 x i32> zeroinitializer
  %323 = mul <8 x i64> %.splat143, splat (i64 32)
  %324 = add <8 x i64> %322, %323
  %325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %321, 0
  %326 = insertvalue { <8 x ptr>, <8 x i64> } %325, <8 x i64> %324, 1
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %326, 1
  %329 = extractelement <8 x ptr> %327, i32 0
  %330 = extractelement <8 x i64> %328, i32 0
  %331 = sub i64 %330, 0
  %332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %333 = select i1 %332, i64 %331, i64 0
  %private.contiguous.address144 = getelementptr i8, ptr %329, i64 %333
  %private.contiguous.load145 = load <8 x float>, ptr %private.contiguous.address144, align 4
  %334 = select <8 x i1> %55, <8 x float> %private.contiguous.load145, <8 x float> zeroinitializer
  %335 = fmul <8 x float> %334, %334
  %.spill.load146 = load i64, ptr %.spill15, align 4
  %336 = add i64 0, %.spill.load146
  %tile_snapshot.spill.load147 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %.splatinsert148 = insertelement <8 x i64> poison, i64 %336, i64 0
  %.splat149 = shufflevector <8 x i64> %.splatinsert148, <8 x i64> poison, <8 x i32> zeroinitializer
  %339 = mul <8 x i64> %.splat149, splat (i64 32)
  %340 = add <8 x i64> %338, %339
  %341 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %337, 0
  %342 = insertvalue { <8 x ptr>, <8 x i64> } %341, <8 x i64> %340, 1
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %342, 1
  %345 = extractelement <8 x ptr> %343, i32 0
  %346 = extractelement <8 x i64> %344, i32 0
  %347 = sub i64 %346, 0
  %348 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %349 = select i1 %348, i64 %347, i64 0
  %private.contiguous.address150 = getelementptr i8, ptr %345, i64 %349
  %private.contiguous.load151 = load <8 x float>, ptr %private.contiguous.address150, align 4
  %350 = select <8 x i1> %55, <8 x float> %private.contiguous.load151, <8 x float> zeroinitializer
  %351 = fmul <8 x float> %350, %350
  %.spill.load152 = load i64, ptr %.spill16, align 4
  %352 = add i64 0, %.spill.load152
  %tile_snapshot.spill.load153 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load153, 0
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load153, 1
  %.splatinsert154 = insertelement <8 x i64> poison, i64 %352, i64 0
  %.splat155 = shufflevector <8 x i64> %.splatinsert154, <8 x i64> poison, <8 x i32> zeroinitializer
  %355 = mul <8 x i64> %.splat155, splat (i64 32)
  %356 = add <8 x i64> %354, %355
  %357 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %353, 0
  %358 = insertvalue { <8 x ptr>, <8 x i64> } %357, <8 x i64> %356, 1
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %358, 1
  %361 = extractelement <8 x ptr> %359, i32 0
  %362 = extractelement <8 x i64> %360, i32 0
  %363 = sub i64 %362, 0
  %364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %365 = select i1 %364, i64 %363, i64 0
  %private.contiguous.address156 = getelementptr i8, ptr %361, i64 %365
  %private.contiguous.load157 = load <8 x float>, ptr %private.contiguous.address156, align 4
  %366 = select <8 x i1> %55, <8 x float> %private.contiguous.load157, <8 x float> zeroinitializer
  %367 = fmul <8 x float> %366, %366
  store i64 4, ptr %.slot28, align 4
  %368 = load <8 x float>, ptr %.slot29, align 32
  %369 = select <8 x i1> %55, <8 x float> %319, <8 x float> %368
  store <8 x float> %369, ptr %.slot29, align 32
  %370 = load <8 x float>, ptr %.slot30, align 32
  %371 = select <8 x i1> %55, <8 x float> %335, <8 x float> %370
  store <8 x float> %371, ptr %.slot30, align 32
  %372 = load <8 x float>, ptr %.slot31, align 32
  %373 = select <8 x i1> %55, <8 x float> %351, <8 x float> %372
  store <8 x float> %373, ptr %.slot31, align 32
  %374 = load <8 x float>, ptr %.slot32, align 32
  %375 = select <8 x i1> %55, <8 x float> %367, <8 x float> %374
  store <8 x float> %375, ptr %.slot32, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state158 = load i64, ptr %.slot28, align 4
  %376 = icmp slt i64 %.state158, 64
  br i1 %376, label %direct.true159, label %direct.false160

direct.schedule.11:                               ; preds = %direct.true159
  %.state161 = load i64, ptr %.slot28, align 4
  %377 = add i64 %.state161, 0
  %378 = sdiv i64 %377, 1
  %.spill.load162 = load i64, ptr %.spill12, align 4
  %379 = add i64 %.spill.load162, %378
  %.spill.load163 = load i64, ptr %.spill27, align 4
  %380 = add i64 %.spill.load163, %379
  %tile_snapshot.spill.load164 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load164, 0
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load164, 1
  %.splatinsert165 = insertelement <8 x i64> poison, i64 %380, i64 0
  %.splat166 = shufflevector <8 x i64> %.splatinsert165, <8 x i64> poison, <8 x i32> zeroinitializer
  %383 = mul <8 x i64> %.splat166, splat (i64 32)
  %384 = add <8 x i64> %382, %383
  %385 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %381, 0
  %386 = insertvalue { <8 x ptr>, <8 x i64> } %385, <8 x i64> %384, 1
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %386, 1
  %389 = extractelement <8 x ptr> %387, i32 0
  %390 = extractelement <8 x i64> %388, i32 0
  %391 = sub i64 %390, 0
  %392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %393 = select i1 %392, i64 %391, i64 0
  %private.contiguous.address167 = getelementptr i8, ptr %389, i64 %393
  %private.contiguous.load168 = load <8 x float>, ptr %private.contiguous.address167, align 4
  %394 = select <8 x i1> %55, <8 x float> %private.contiguous.load168, <8 x float> zeroinitializer
  %395 = fmul <8 x float> %394, %394
  %.state169 = load <8 x float>, ptr %.slot29, align 32
  %396 = fadd <8 x float> %.state169, %395
  %.state170 = load i64, ptr %.slot28, align 4
  %397 = add i64 %.state170, 1
  %398 = sdiv i64 %397, 1
  %.spill.load171 = load i64, ptr %.spill12, align 4
  %399 = add i64 %.spill.load171, %398
  %.spill.load172 = load i64, ptr %.spill27, align 4
  %400 = add i64 %.spill.load172, %399
  %tile_snapshot.spill.load173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 0
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 1
  %.splatinsert174 = insertelement <8 x i64> poison, i64 %400, i64 0
  %.splat175 = shufflevector <8 x i64> %.splatinsert174, <8 x i64> poison, <8 x i32> zeroinitializer
  %403 = mul <8 x i64> %.splat175, splat (i64 32)
  %404 = add <8 x i64> %402, %403
  %405 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %401, 0
  %406 = insertvalue { <8 x ptr>, <8 x i64> } %405, <8 x i64> %404, 1
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %406, 1
  %409 = extractelement <8 x ptr> %407, i32 0
  %410 = extractelement <8 x i64> %408, i32 0
  %411 = sub i64 %410, 0
  %412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %413 = select i1 %412, i64 %411, i64 0
  %private.contiguous.address176 = getelementptr i8, ptr %409, i64 %413
  %private.contiguous.load177 = load <8 x float>, ptr %private.contiguous.address176, align 4
  %414 = select <8 x i1> %55, <8 x float> %private.contiguous.load177, <8 x float> zeroinitializer
  %415 = fmul <8 x float> %414, %414
  %.state178 = load <8 x float>, ptr %.slot30, align 32
  %416 = fadd <8 x float> %.state178, %415
  %.state179 = load i64, ptr %.slot28, align 4
  %417 = add i64 %.state179, 2
  %418 = sdiv i64 %417, 1
  %.spill.load180 = load i64, ptr %.spill12, align 4
  %419 = add i64 %.spill.load180, %418
  %.spill.load181 = load i64, ptr %.spill27, align 4
  %420 = add i64 %.spill.load181, %419
  %tile_snapshot.spill.load182 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 0
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 1
  %.splatinsert183 = insertelement <8 x i64> poison, i64 %420, i64 0
  %.splat184 = shufflevector <8 x i64> %.splatinsert183, <8 x i64> poison, <8 x i32> zeroinitializer
  %423 = mul <8 x i64> %.splat184, splat (i64 32)
  %424 = add <8 x i64> %422, %423
  %425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %421, 0
  %426 = insertvalue { <8 x ptr>, <8 x i64> } %425, <8 x i64> %424, 1
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %426, 1
  %429 = extractelement <8 x ptr> %427, i32 0
  %430 = extractelement <8 x i64> %428, i32 0
  %431 = sub i64 %430, 0
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %433 = select i1 %432, i64 %431, i64 0
  %private.contiguous.address185 = getelementptr i8, ptr %429, i64 %433
  %private.contiguous.load186 = load <8 x float>, ptr %private.contiguous.address185, align 4
  %434 = select <8 x i1> %55, <8 x float> %private.contiguous.load186, <8 x float> zeroinitializer
  %435 = fmul <8 x float> %434, %434
  %.state187 = load <8 x float>, ptr %.slot31, align 32
  %436 = fadd <8 x float> %.state187, %435
  %.state188 = load i64, ptr %.slot28, align 4
  %437 = add i64 %.state188, 3
  %438 = sdiv i64 %437, 1
  %.spill.load189 = load i64, ptr %.spill12, align 4
  %439 = add i64 %.spill.load189, %438
  %.spill.load190 = load i64, ptr %.spill27, align 4
  %440 = add i64 %.spill.load190, %439
  %tile_snapshot.spill.load191 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %.splatinsert192 = insertelement <8 x i64> poison, i64 %440, i64 0
  %.splat193 = shufflevector <8 x i64> %.splatinsert192, <8 x i64> poison, <8 x i32> zeroinitializer
  %443 = mul <8 x i64> %.splat193, splat (i64 32)
  %444 = add <8 x i64> %442, %443
  %445 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %441, 0
  %446 = insertvalue { <8 x ptr>, <8 x i64> } %445, <8 x i64> %444, 1
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %446, 1
  %449 = extractelement <8 x ptr> %447, i32 0
  %450 = extractelement <8 x i64> %448, i32 0
  %451 = sub i64 %450, 0
  %452 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %453 = select i1 %452, i64 %451, i64 0
  %private.contiguous.address194 = getelementptr i8, ptr %449, i64 %453
  %private.contiguous.load195 = load <8 x float>, ptr %private.contiguous.address194, align 4
  %454 = select <8 x i1> %55, <8 x float> %private.contiguous.load195, <8 x float> zeroinitializer
  %455 = fmul <8 x float> %454, %454
  %.state196 = load <8 x float>, ptr %.slot32, align 32
  %456 = fadd <8 x float> %.state196, %455
  %.state197 = load i64, ptr %.slot28, align 4
  %457 = add i64 %.state197, 4
  store i64 %457, ptr %.slot28, align 4
  %458 = load <8 x float>, ptr %.slot29, align 32
  %459 = select <8 x i1> %55, <8 x float> %396, <8 x float> %458
  store <8 x float> %459, ptr %.slot29, align 32
  %460 = load <8 x float>, ptr %.slot30, align 32
  %461 = select <8 x i1> %55, <8 x float> %416, <8 x float> %460
  store <8 x float> %461, ptr %.slot30, align 32
  %462 = load <8 x float>, ptr %.slot31, align 32
  %463 = select <8 x i1> %55, <8 x float> %436, <8 x float> %462
  store <8 x float> %463, ptr %.slot31, align 32
  %464 = load <8 x float>, ptr %.slot32, align 32
  %465 = select <8 x i1> %55, <8 x float> %456, <8 x float> %464
  store <8 x float> %465, ptr %.slot32, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false160
  %.spill.load198 = load i64, ptr %.spill27, align 4
  %.spill.load199 = load i64, ptr %.spill22, align 4
  %466 = add i64 %.spill.load198, %.spill.load199
  %tile_snapshot.spill.load200 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load200, 0
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load200, 1
  %.splatinsert201 = insertelement <8 x i64> poison, i64 %466, i64 0
  %.splat202 = shufflevector <8 x i64> %.splatinsert201, <8 x i64> poison, <8 x i32> zeroinitializer
  %469 = mul <8 x i64> %.splat202, splat (i64 32)
  %470 = add <8 x i64> %468, %469
  %471 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %467, 0
  %472 = insertvalue { <8 x ptr>, <8 x i64> } %471, <8 x i64> %470, 1
  %473 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %472, 1
  %475 = extractelement <8 x ptr> %473, i32 0
  %476 = extractelement <8 x i64> %474, i32 0
  %477 = sub i64 %476, 0
  %478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %479 = select i1 %478, i64 %477, i64 0
  %private.contiguous.address203 = getelementptr i8, ptr %475, i64 %479
  %private.contiguous.load204 = load <8 x float>, ptr %private.contiguous.address203, align 4
  %480 = select <8 x i1> %55, <8 x float> %private.contiguous.load204, <8 x float> zeroinitializer
  %481 = fmul <8 x float> %480, %480
  %.state205 = load <8 x float>, ptr %.slot29, align 32
  %482 = fadd <8 x float> %.state205, %481
  %.spill.load206 = load float, ptr %.spill10, align 4
  %.splatinsert207 = insertelement <8 x float> poison, float %.spill.load206, i64 0
  %.splat208 = shufflevector <8 x float> %.splatinsert207, <8 x float> poison, <8 x i32> zeroinitializer
  %483 = fadd <8 x float> %.splat208, %482
  %.state209 = load <8 x float>, ptr %.slot30, align 32
  %484 = fadd <8 x float> %483, %.state209
  %.state210 = load <8 x float>, ptr %.slot31, align 32
  %485 = fadd <8 x float> %484, %.state210
  %.state211 = load <8 x float>, ptr %.slot32, align 32
  %486 = fadd <8 x float> %485, %.state211
  %.spill.load212 = load float, ptr %.spill23, align 4
  %.splatinsert213 = insertelement <8 x float> poison, float %.spill.load212, i64 0
  %.splat214 = shufflevector <8 x float> %.splatinsert213, <8 x float> poison, <8 x i32> zeroinitializer
  %487 = fdiv <8 x float> %486, %.splat214
  %488 = load <8 x float>, ptr %.spill33, align 32
  %489 = select <8 x i1> %55, <8 x float> %487, <8 x float> %488
  store <8 x float> %489, ptr %.spill33, align 32
  %490 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill34, align 64
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %490, 0
  %493 = select <8 x i1> %55, <8 x ptr> %491, <8 x ptr> %492
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %490, 1
  %496 = select <8 x i1> %55, <8 x i64> %494, <8 x i64> %495
  %497 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %493, 0
  %498 = insertvalue { <8 x ptr>, <8 x i64> } %497, <8 x i64> %496, 1
  store { <8 x ptr>, <8 x i64> } %498, ptr %tile_snapshot.spill34, align 64
  store i64 0, ptr %.slot35, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state215 = load i64, ptr %.slot35, align 4
  %499 = icmp slt i64 %.state215, 65
  br i1 %499, label %direct.true216, label %direct.false217

direct.schedule.14:                               ; preds = %direct.true216
  %.spill.load218 = load i64, ptr %.spill11, align 4
  %500 = add i64 %.spill.load218, 0
  %.state219 = load i64, ptr %.slot35, align 4
  %501 = add i64 0, %.state219
  %502 = mul i64 %500, 65
  %503 = add i64 %502, %501
  %504 = extractvalue { ptr, i64 } %19, 0
  %505 = mul i64 %503, 4
  %506 = getelementptr i8, ptr %504, i64 %505
  %507 = load float, ptr %506, align 4
  %.splatinsert220 = insertelement <8 x float> poison, float %507, i64 0
  %.splat221 = shufflevector <8 x float> %.splatinsert220, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load222 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill34, align 64
  %508 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load222, 0
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load222, 1
  %.state223 = load i64, ptr %.slot35, align 4
  %.splatinsert224 = insertelement <8 x i64> poison, i64 %.state223, i64 0
  %.splat225 = shufflevector <8 x i64> %.splatinsert224, <8 x i64> poison, <8 x i32> zeroinitializer
  %510 = mul <8 x i64> %.splat225, splat (i64 32)
  %511 = add <8 x i64> %509, %510
  %512 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %508, 0
  %513 = insertvalue { <8 x ptr>, <8 x i64> } %512, <8 x i64> %511, 1
  %514 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %513, 1
  %516 = extractelement <8 x ptr> %514, i32 0
  %517 = extractelement <8 x i64> %515, i32 0
  %518 = sub i64 %517, 0
  %519 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %520 = select i1 %519, i64 %518, i64 0
  %private.contiguous.address226 = getelementptr i8, ptr %516, i64 %520
  %private.contiguous.preserve227 = load <8 x float>, ptr %private.contiguous.address226, align 4
  %521 = select <8 x i1> %55, <8 x float> %.splat221, <8 x float> %private.contiguous.preserve227
  store <8 x float> %521, ptr %private.contiguous.address226, align 4
  %.state228 = load i64, ptr %.slot35, align 4
  %522 = add i64 %.state228, 1
  store i64 %522, ptr %.slot35, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false217
  %.spill.load229 = load <8 x float>, ptr %.spill33, align 32
  %523 = fadd <8 x float> %.spill.load229, splat (float 0x3EE4F8B580000000)
  %524 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %523)
  %525 = load <8 x float>, ptr %.spill36, align 32
  %526 = select <8 x i1> %55, <8 x float> %524, <8 x float> %525
  store <8 x float> %526, ptr %.spill36, align 32
  %527 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %527, 0
  %530 = select <8 x i1> %55, <8 x ptr> %528, <8 x ptr> %529
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %527, 1
  %533 = select <8 x i1> %55, <8 x i64> %531, <8 x i64> %532
  %534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %530, 0
  %535 = insertvalue { <8 x ptr>, <8 x i64> } %534, <8 x i64> %533, 1
  store { <8 x ptr>, <8 x i64> } %535, ptr %tile_snapshot.spill37, align 64
  store i64 0, ptr %.slot38, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state230 = load i64, ptr %.slot38, align 4
  %536 = icmp slt i64 %.state230, 65
  br i1 %536, label %direct.true231, label %direct.false232

direct.schedule.17:                               ; preds = %direct.true231
  %.spill.load233 = load i64, ptr %.spill11, align 4
  %537 = add i64 %.spill.load233, 0
  %.state234 = load i64, ptr %.slot38, align 4
  %538 = add i64 0, %.state234
  %539 = mul i64 %537, 65
  %540 = add i64 %539, %538
  %541 = extractvalue { ptr, i64 } %25, 0
  %542 = mul i64 %540, 4
  %543 = getelementptr i8, ptr %541, i64 %542
  %544 = load float, ptr %543, align 4
  %.splatinsert235 = insertelement <8 x float> poison, float %544, i64 0
  %.splat236 = shufflevector <8 x float> %.splatinsert235, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load237 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 0
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 1
  %.state238 = load i64, ptr %.slot38, align 4
  %.splatinsert239 = insertelement <8 x i64> poison, i64 %.state238, i64 0
  %.splat240 = shufflevector <8 x i64> %.splatinsert239, <8 x i64> poison, <8 x i32> zeroinitializer
  %547 = mul <8 x i64> %.splat240, splat (i64 32)
  %548 = add <8 x i64> %546, %547
  %549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %545, 0
  %550 = insertvalue { <8 x ptr>, <8 x i64> } %549, <8 x i64> %548, 1
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %550, 1
  %553 = extractelement <8 x ptr> %551, i32 0
  %554 = extractelement <8 x i64> %552, i32 0
  %555 = sub i64 %554, 0
  %556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %557 = select i1 %556, i64 %555, i64 0
  %private.contiguous.address241 = getelementptr i8, ptr %553, i64 %557
  %private.contiguous.preserve242 = load <8 x float>, ptr %private.contiguous.address241, align 4
  %558 = select <8 x i1> %55, <8 x float> %.splat236, <8 x float> %private.contiguous.preserve242
  store <8 x float> %558, ptr %private.contiguous.address241, align 4
  %.state243 = load i64, ptr %.slot38, align 4
  %559 = add i64 %.state243, 1
  store i64 %559, ptr %.slot38, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false232
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state244 = load i64, ptr %.slot39, align 4
  %560 = icmp slt i64 %.state244, 65
  br i1 %560, label %direct.true245, label %direct.false246

direct.schedule.20:                               ; preds = %direct.true245
  %.spill.load247 = load <8 x i64>, ptr %.spill, align 64
  %561 = add <8 x i64> %.spill.load247, zeroinitializer
  %562 = add <8 x i64> zeroinitializer, %561
  %.state248 = load i64, ptr %.slot39, align 4
  %563 = add i64 0, %.state248
  %564 = mul <8 x i64> %562, splat (i64 65)
  %.splatinsert249 = insertelement <8 x i64> poison, i64 %563, i64 0
  %.splat250 = shufflevector <8 x i64> %.splatinsert249, <8 x i64> poison, <8 x i32> zeroinitializer
  %565 = add <8 x i64> %564, %.splat250
  %.spill.load251 = load i64, ptr %.spill27, align 4
  %.state252 = load i64, ptr %.slot39, align 4
  %566 = add i64 %.spill.load251, %.state252
  %.spill.load253 = load i64, ptr %.spill27, align 4
  %567 = add i64 %.spill.load253, %566
  %.spill.load254 = load i64, ptr %.spill27, align 4
  %568 = add i64 %.spill.load254, %567
  %tile_snapshot.spill.load255 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 0
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 1
  %.splatinsert256 = insertelement <8 x i64> poison, i64 %568, i64 0
  %.splat257 = shufflevector <8 x i64> %.splatinsert256, <8 x i64> poison, <8 x i32> zeroinitializer
  %571 = mul <8 x i64> %.splat257, splat (i64 32)
  %572 = add <8 x i64> %570, %571
  %573 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %569, 0
  %574 = insertvalue { <8 x ptr>, <8 x i64> } %573, <8 x i64> %572, 1
  %575 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %574, 1
  %577 = extractelement <8 x ptr> %575, i32 0
  %578 = extractelement <8 x i64> %576, i32 0
  %579 = sub i64 %578, 0
  %580 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %581 = select i1 %580, i64 %579, i64 0
  %private.contiguous.address258 = getelementptr i8, ptr %577, i64 %581
  %private.contiguous.load259 = load <8 x float>, ptr %private.contiguous.address258, align 4
  %582 = select <8 x i1> %55, <8 x float> %private.contiguous.load259, <8 x float> zeroinitializer
  %.spill.load260 = load <8 x float>, ptr %.spill36, align 32
  %583 = fdiv <8 x float> %582, %.spill.load260
  %tile_snapshot.spill.load261 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill34, align 64
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load261, 0
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load261, 1
  %.splatinsert262 = insertelement <8 x i64> poison, i64 %567, i64 0
  %.splat263 = shufflevector <8 x i64> %.splatinsert262, <8 x i64> poison, <8 x i32> zeroinitializer
  %586 = mul <8 x i64> %.splat263, splat (i64 32)
  %587 = add <8 x i64> %585, %586
  %588 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %584, 0
  %589 = insertvalue { <8 x ptr>, <8 x i64> } %588, <8 x i64> %587, 1
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %589, 1
  %592 = extractelement <8 x ptr> %590, i32 0
  %593 = extractelement <8 x i64> %591, i32 0
  %594 = sub i64 %593, 0
  %595 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %596 = select i1 %595, i64 %594, i64 0
  %private.contiguous.address264 = getelementptr i8, ptr %592, i64 %596
  %private.contiguous.load265 = load <8 x float>, ptr %private.contiguous.address264, align 4
  %597 = select <8 x i1> %55, <8 x float> %private.contiguous.load265, <8 x float> zeroinitializer
  %598 = fmul <8 x float> %583, %597
  %tile_snapshot.spill.load266 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %599 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 0
  %600 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 1
  %.splatinsert267 = insertelement <8 x i64> poison, i64 %566, i64 0
  %.splat268 = shufflevector <8 x i64> %.splatinsert267, <8 x i64> poison, <8 x i32> zeroinitializer
  %601 = mul <8 x i64> %.splat268, splat (i64 32)
  %602 = add <8 x i64> %600, %601
  %603 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %599, 0
  %604 = insertvalue { <8 x ptr>, <8 x i64> } %603, <8 x i64> %602, 1
  %605 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %606 = extractvalue { <8 x ptr>, <8 x i64> } %604, 1
  %607 = extractelement <8 x ptr> %605, i32 0
  %608 = extractelement <8 x i64> %606, i32 0
  %609 = sub i64 %608, 0
  %610 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %611 = select i1 %610, i64 %609, i64 0
  %private.contiguous.address269 = getelementptr i8, ptr %607, i64 %611
  %private.contiguous.load270 = load <8 x float>, ptr %private.contiguous.address269, align 4
  %612 = select <8 x i1> %55, <8 x float> %private.contiguous.load270, <8 x float> zeroinitializer
  %613 = fadd <8 x float> %598, %612
  %614 = extractvalue { ptr, i64 } %31, 0
  %615 = mul <8 x i64> %565, splat (i64 4)
  %616 = getelementptr i8, ptr %614, <8 x i64> %615
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %613, <8 x ptr> %616, i32 1, <8 x i1> %55)
  %.state271 = load i64, ptr %.slot39, align 4
  %617 = add i64 %.state271, 1
  store i64 %617, ptr %.slot39, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false246
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true69:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false70:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true118:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false119:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true159:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false160:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true216:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false217:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true231:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false232:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true245:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false246:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [2080 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [2080 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [2080 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [2080 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill10 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill10, align 4
  %.spill11 = alloca i64, align 8
  store i64 0, ptr %.spill11, align 4
  %.spill12 = alloca i64, align 8
  store i64 0, ptr %.spill12, align 4
  %.spill13 = alloca i64, align 8
  store i64 0, ptr %.spill13, align 4
  %.spill14 = alloca i64, align 8
  store i64 0, ptr %.spill14, align 4
  %.spill15 = alloca i64, align 8
  store i64 0, ptr %.spill15, align 4
  %.spill16 = alloca i64, align 8
  store i64 0, ptr %.spill16, align 4
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %.slot18 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot18, align 32
  %.slot19 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot19, align 32
  %.slot20 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot20, align 32
  %.slot21 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.spill22 = alloca i64, align 8
  store i64 0, ptr %.spill22, align 4
  %.spill23 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill23, align 4
  %.spill24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill24, align 32
  %tile_snapshot.spill25 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill25, align 64
  %.slot26 = alloca i64, align 8
  store i64 0, ptr %.slot26, align 4
  %.spill27 = alloca i64, align 8
  store i64 0, ptr %.spill27, align 4
  %.slot28 = alloca i64, align 8
  store i64 0, ptr %.slot28, align 4
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.slot30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot30, align 32
  %.slot31 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot31, align 32
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.spill33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill33, align 32
  %tile_snapshot.spill34 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill34, align 64
  %.slot35 = alloca i64, align 8
  store i64 0, ptr %.slot35, align 4
  %.spill36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill36, align 32
  %tile_snapshot.spill37 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill37, align 64
  %.slot38 = alloca i64, align 8
  store i64 0, ptr %.slot38, align 4
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert40 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat41 = shufflevector <8 x i32> %.splatinsert40, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat41, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert42 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat43 = shufflevector <8 x i32> %.splatinsert42, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat43, %45
  %48 = mul i32 %36, 1
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat45, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat47, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert48 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat49
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = zext <8 x i32> %57 to <8 x i64>
  %59 = select <8 x i1> %55, <8 x i64> %58, <8 x i64> zeroinitializer
  %60 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %61 = sdiv <8 x i64> %59, %60
  %62 = load <8 x i64>, ptr %.spill, align 64
  %63 = select <8 x i1> %55, <8 x i64> %61, <8 x i64> %62
  store <8 x i64> %63, ptr %.spill, align 64
  %64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %64, 0
  %67 = select <8 x i1> %55, <8 x ptr> %65, <8 x ptr> %66
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %64, 1
  %70 = select <8 x i1> %55, <8 x i64> %68, <8 x i64> %69
  %71 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %67, 0
  %72 = insertvalue { <8 x ptr>, <8 x i64> } %71, <8 x i64> %70, 1
  store { <8 x ptr>, <8 x i64> } %72, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %73 = icmp slt i64 %.state, 65
  br i1 %73, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %74 = add <8 x i64> %.spill.load, zeroinitializer
  %75 = add <8 x i64> zeroinitializer, %74
  %.state50 = load i64, ptr %.slot, align 4
  %76 = add i64 0, %.state50
  %77 = mul <8 x i64> %75, splat (i64 65)
  %.splatinsert51 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat52 = shufflevector <8 x i64> %.splatinsert51, <8 x i64> poison, <8 x i32> zeroinitializer
  %78 = add <8 x i64> %77, %.splat52
  %79 = extractvalue { ptr, i64 } %13, 0
  %80 = mul <8 x i64> %78, splat (i64 4)
  %81 = getelementptr i8, ptr %79, <8 x i64> %80
  %82 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %81, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %83 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %84 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state53 = load i64, ptr %.slot, align 4
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %.state53, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %85 = mul <8 x i64> %.splat55, splat (i64 32)
  %86 = add <8 x i64> %84, %85
  %87 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %83, 0
  %88 = insertvalue { <8 x ptr>, <8 x i64> } %87, <8 x i64> %86, 1
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %88, 1
  %91 = extractelement <8 x ptr> %89, i32 0
  %92 = extractelement <8 x i64> %90, i32 0
  %93 = sub i64 %92, 0
  %94 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %95 = select i1 %94, i64 %93, i64 0
  %private.contiguous.address = getelementptr i8, ptr %91, i64 %95
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %96 = select <8 x i1> %55, <8 x float> %82, <8 x float> %private.contiguous.preserve
  store <8 x float> %96, ptr %private.contiguous.address, align 4
  %.state56 = load i64, ptr %.slot, align 4
  %97 = add i64 %.state56, 1
  store i64 %97, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill10, align 4
  store i64 0, ptr %.spill11, align 4
  store i64 0, ptr %.spill12, align 4
  store i64 0, ptr %.spill13, align 4
  %tile_snapshot.spill.load57 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 0
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 1
  %100 = add <8 x i64> %99, zeroinitializer
  %101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %98, 0
  %102 = insertvalue { <8 x ptr>, <8 x i64> } %101, <8 x i64> %100, 1
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %102, 1
  %105 = extractelement <8 x ptr> %103, i32 0
  %106 = extractelement <8 x i64> %104, i32 0
  %107 = sub i64 %106, 0
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %109 = select i1 %108, i64 %107, i64 0
  %private.contiguous.address58 = getelementptr i8, ptr %105, i64 %109
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address58, align 4
  %110 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  store i64 1, ptr %.spill14, align 4
  %tile_snapshot.spill.load59 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 0
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 1
  %113 = add <8 x i64> %112, splat (i64 32)
  %114 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %111, 0
  %115 = insertvalue { <8 x ptr>, <8 x i64> } %114, <8 x i64> %113, 1
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %115, 1
  %118 = extractelement <8 x ptr> %116, i32 0
  %119 = extractelement <8 x i64> %117, i32 0
  %120 = sub i64 %119, 0
  %121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %122 = select i1 %121, i64 %120, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %118, i64 %122
  %private.contiguous.load61 = load <8 x float>, ptr %private.contiguous.address60, align 4
  %123 = select <8 x i1> %55, <8 x float> %private.contiguous.load61, <8 x float> zeroinitializer
  store i64 2, ptr %.spill15, align 4
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %126 = add <8 x i64> %125, splat (i64 64)
  %127 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %124, 0
  %128 = insertvalue { <8 x ptr>, <8 x i64> } %127, <8 x i64> %126, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %128, 1
  %131 = extractelement <8 x ptr> %129, i32 0
  %132 = extractelement <8 x i64> %130, i32 0
  %133 = sub i64 %132, 0
  %134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %135 = select i1 %134, i64 %133, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %131, i64 %135
  %private.contiguous.load64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %136 = select <8 x i1> %55, <8 x float> %private.contiguous.load64, <8 x float> zeroinitializer
  store i64 3, ptr %.spill16, align 4
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %139 = add <8 x i64> %138, splat (i64 96)
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %137, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %141, 1
  %144 = extractelement <8 x ptr> %142, i32 0
  %145 = extractelement <8 x i64> %143, i32 0
  %146 = sub i64 %145, 0
  %147 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %148 = select i1 %147, i64 %146, i64 0
  %private.contiguous.address66 = getelementptr i8, ptr %144, i64 %148
  %private.contiguous.load67 = load <8 x float>, ptr %private.contiguous.address66, align 4
  %149 = select <8 x i1> %55, <8 x float> %private.contiguous.load67, <8 x float> zeroinitializer
  store i64 4, ptr %.slot17, align 4
  %150 = load <8 x float>, ptr %.slot18, align 32
  %151 = select <8 x i1> %55, <8 x float> %110, <8 x float> %150
  store <8 x float> %151, ptr %.slot18, align 32
  %152 = load <8 x float>, ptr %.slot19, align 32
  %153 = select <8 x i1> %55, <8 x float> %123, <8 x float> %152
  store <8 x float> %153, ptr %.slot19, align 32
  %154 = load <8 x float>, ptr %.slot20, align 32
  %155 = select <8 x i1> %55, <8 x float> %136, <8 x float> %154
  store <8 x float> %155, ptr %.slot20, align 32
  %156 = load <8 x float>, ptr %.slot21, align 32
  %157 = select <8 x i1> %55, <8 x float> %149, <8 x float> %156
  store <8 x float> %157, ptr %.slot21, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state68 = load i64, ptr %.slot17, align 4
  %158 = icmp slt i64 %.state68, 64
  br i1 %158, label %direct.true69, label %direct.false70

direct.schedule.5:                                ; preds = %direct.true69
  %.state71 = load i64, ptr %.slot17, align 4
  %159 = add i64 %.state71, 0
  %160 = sdiv i64 %159, 1
  %.spill.load72 = load i64, ptr %.spill12, align 4
  %161 = add i64 %.spill.load72, %160
  %tile_snapshot.spill.load73 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 0
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 1
  %.splatinsert74 = insertelement <8 x i64> poison, i64 %161, i64 0
  %.splat75 = shufflevector <8 x i64> %.splatinsert74, <8 x i64> poison, <8 x i32> zeroinitializer
  %164 = mul <8 x i64> %.splat75, splat (i64 32)
  %165 = add <8 x i64> %163, %164
  %166 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %162, 0
  %167 = insertvalue { <8 x ptr>, <8 x i64> } %166, <8 x i64> %165, 1
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %167, 1
  %170 = extractelement <8 x ptr> %168, i32 0
  %171 = extractelement <8 x i64> %169, i32 0
  %172 = sub i64 %171, 0
  %173 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %174 = select i1 %173, i64 %172, i64 0
  %private.contiguous.address76 = getelementptr i8, ptr %170, i64 %174
  %private.contiguous.load77 = load <8 x float>, ptr %private.contiguous.address76, align 4
  %175 = select <8 x i1> %55, <8 x float> %private.contiguous.load77, <8 x float> zeroinitializer
  %.state78 = load <8 x float>, ptr %.slot18, align 32
  %176 = fadd <8 x float> %.state78, %175
  %.state79 = load i64, ptr %.slot17, align 4
  %177 = add i64 %.state79, 1
  %178 = sdiv i64 %177, 1
  %.spill.load80 = load i64, ptr %.spill12, align 4
  %179 = add i64 %.spill.load80, %178
  %tile_snapshot.spill.load81 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 0
  %181 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 1
  %.splatinsert82 = insertelement <8 x i64> poison, i64 %179, i64 0
  %.splat83 = shufflevector <8 x i64> %.splatinsert82, <8 x i64> poison, <8 x i32> zeroinitializer
  %182 = mul <8 x i64> %.splat83, splat (i64 32)
  %183 = add <8 x i64> %181, %182
  %184 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %180, 0
  %185 = insertvalue { <8 x ptr>, <8 x i64> } %184, <8 x i64> %183, 1
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %185, 1
  %188 = extractelement <8 x ptr> %186, i32 0
  %189 = extractelement <8 x i64> %187, i32 0
  %190 = sub i64 %189, 0
  %191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %192 = select i1 %191, i64 %190, i64 0
  %private.contiguous.address84 = getelementptr i8, ptr %188, i64 %192
  %private.contiguous.load85 = load <8 x float>, ptr %private.contiguous.address84, align 4
  %193 = select <8 x i1> %55, <8 x float> %private.contiguous.load85, <8 x float> zeroinitializer
  %.state86 = load <8 x float>, ptr %.slot19, align 32
  %194 = fadd <8 x float> %.state86, %193
  %.state87 = load i64, ptr %.slot17, align 4
  %195 = add i64 %.state87, 2
  %196 = sdiv i64 %195, 1
  %.spill.load88 = load i64, ptr %.spill12, align 4
  %197 = add i64 %.spill.load88, %196
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %197, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %200 = mul <8 x i64> %.splat91, splat (i64 32)
  %201 = add <8 x i64> %199, %200
  %202 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %198, 0
  %203 = insertvalue { <8 x ptr>, <8 x i64> } %202, <8 x i64> %201, 1
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %203, 1
  %206 = extractelement <8 x ptr> %204, i32 0
  %207 = extractelement <8 x i64> %205, i32 0
  %208 = sub i64 %207, 0
  %209 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %210 = select i1 %209, i64 %208, i64 0
  %private.contiguous.address92 = getelementptr i8, ptr %206, i64 %210
  %private.contiguous.load93 = load <8 x float>, ptr %private.contiguous.address92, align 4
  %211 = select <8 x i1> %55, <8 x float> %private.contiguous.load93, <8 x float> zeroinitializer
  %.state94 = load <8 x float>, ptr %.slot20, align 32
  %212 = fadd <8 x float> %.state94, %211
  %.state95 = load i64, ptr %.slot17, align 4
  %213 = add i64 %.state95, 3
  %214 = sdiv i64 %213, 1
  %.spill.load96 = load i64, ptr %.spill12, align 4
  %215 = add i64 %.spill.load96, %214
  %tile_snapshot.spill.load97 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 0
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 1
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %215, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %218 = mul <8 x i64> %.splat99, splat (i64 32)
  %219 = add <8 x i64> %217, %218
  %220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %216, 0
  %221 = insertvalue { <8 x ptr>, <8 x i64> } %220, <8 x i64> %219, 1
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %221, 1
  %224 = extractelement <8 x ptr> %222, i32 0
  %225 = extractelement <8 x i64> %223, i32 0
  %226 = sub i64 %225, 0
  %227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %228 = select i1 %227, i64 %226, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %224, i64 %228
  %private.contiguous.load101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %229 = select <8 x i1> %55, <8 x float> %private.contiguous.load101, <8 x float> zeroinitializer
  %.state102 = load <8 x float>, ptr %.slot21, align 32
  %230 = fadd <8 x float> %.state102, %229
  %.state103 = load i64, ptr %.slot17, align 4
  %231 = add i64 %.state103, 4
  store i64 %231, ptr %.slot17, align 4
  %232 = load <8 x float>, ptr %.slot18, align 32
  %233 = select <8 x i1> %55, <8 x float> %176, <8 x float> %232
  store <8 x float> %233, ptr %.slot18, align 32
  %234 = load <8 x float>, ptr %.slot19, align 32
  %235 = select <8 x i1> %55, <8 x float> %194, <8 x float> %234
  store <8 x float> %235, ptr %.slot19, align 32
  %236 = load <8 x float>, ptr %.slot20, align 32
  %237 = select <8 x i1> %55, <8 x float> %212, <8 x float> %236
  store <8 x float> %237, ptr %.slot20, align 32
  %238 = load <8 x float>, ptr %.slot21, align 32
  %239 = select <8 x i1> %55, <8 x float> %230, <8 x float> %238
  store <8 x float> %239, ptr %.slot21, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false70
  %.spill.load104 = load i64, ptr %.spill12, align 4
  %240 = add i64 %.spill.load104, 64
  store i64 %240, ptr %.spill22, align 4
  %tile_snapshot.spill.load105 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load105, 0
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load105, 1
  %.splatinsert106 = insertelement <8 x i64> poison, i64 %240, i64 0
  %.splat107 = shufflevector <8 x i64> %.splatinsert106, <8 x i64> poison, <8 x i32> zeroinitializer
  %243 = mul <8 x i64> %.splat107, splat (i64 32)
  %244 = add <8 x i64> %242, %243
  %245 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %241, 0
  %246 = insertvalue { <8 x ptr>, <8 x i64> } %245, <8 x i64> %244, 1
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %246, 1
  %249 = extractelement <8 x ptr> %247, i32 0
  %250 = extractelement <8 x i64> %248, i32 0
  %251 = sub i64 %250, 0
  %252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %253 = select i1 %252, i64 %251, i64 0
  %private.contiguous.address108 = getelementptr i8, ptr %249, i64 %253
  %private.contiguous.load109 = load <8 x float>, ptr %private.contiguous.address108, align 4
  %254 = select <8 x i1> %55, <8 x float> %private.contiguous.load109, <8 x float> zeroinitializer
  %.state110 = load <8 x float>, ptr %.slot18, align 32
  %255 = fadd <8 x float> %.state110, %254
  %.spill.load111 = load float, ptr %.spill10, align 4
  %.splatinsert112 = insertelement <8 x float> poison, float %.spill.load111, i64 0
  %.splat113 = shufflevector <8 x float> %.splatinsert112, <8 x float> poison, <8 x i32> zeroinitializer
  %256 = fadd <8 x float> %.splat113, %255
  %.state114 = load <8 x float>, ptr %.slot19, align 32
  %257 = fadd <8 x float> %256, %.state114
  %.state115 = load <8 x float>, ptr %.slot20, align 32
  %258 = fadd <8 x float> %257, %.state115
  %.state116 = load <8 x float>, ptr %.slot21, align 32
  %259 = fadd <8 x float> %258, %.state116
  store float 6.500000e+01, ptr %.spill23, align 4
  %260 = fdiv <8 x float> %259, splat (float 6.500000e+01)
  %261 = load <8 x float>, ptr %.spill24, align 32
  %262 = select <8 x i1> %55, <8 x float> %260, <8 x float> %261
  store <8 x float> %262, ptr %.spill24, align 32
  %263 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %263, 0
  %266 = select <8 x i1> %55, <8 x ptr> %264, <8 x ptr> %265
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %263, 1
  %269 = select <8 x i1> %55, <8 x i64> %267, <8 x i64> %268
  %270 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %266, 0
  %271 = insertvalue { <8 x ptr>, <8 x i64> } %270, <8 x i64> %269, 1
  store { <8 x ptr>, <8 x i64> } %271, ptr %tile_snapshot.spill25, align 64
  store i64 0, ptr %.slot26, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state117 = load i64, ptr %.slot26, align 4
  %272 = icmp slt i64 %.state117, 65
  br i1 %272, label %direct.true118, label %direct.false119

direct.schedule.8:                                ; preds = %direct.true118
  %.state120 = load i64, ptr %.slot26, align 4
  %273 = add i64 0, %.state120
  %tile_snapshot.spill.load121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 0
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 1
  %.splatinsert122 = insertelement <8 x i64> poison, i64 %273, i64 0
  %.splat123 = shufflevector <8 x i64> %.splatinsert122, <8 x i64> poison, <8 x i32> zeroinitializer
  %276 = mul <8 x i64> %.splat123, splat (i64 32)
  %277 = add <8 x i64> %275, %276
  %278 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %274, 0
  %279 = insertvalue { <8 x ptr>, <8 x i64> } %278, <8 x i64> %277, 1
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %279, 1
  %282 = extractelement <8 x ptr> %280, i32 0
  %283 = extractelement <8 x i64> %281, i32 0
  %284 = sub i64 %283, 0
  %285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %286 = select i1 %285, i64 %284, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %282, i64 %286
  %private.contiguous.load125 = load <8 x float>, ptr %private.contiguous.address124, align 4
  %287 = select <8 x i1> %55, <8 x float> %private.contiguous.load125, <8 x float> zeroinitializer
  %.spill.load126 = load <8 x float>, ptr %.spill24, align 32
  %288 = fsub <8 x float> %287, %.spill.load126
  %tile_snapshot.spill.load127 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load127, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load127, 1
  %.state128 = load i64, ptr %.slot26, align 4
  %.splatinsert129 = insertelement <8 x i64> poison, i64 %.state128, i64 0
  %.splat130 = shufflevector <8 x i64> %.splatinsert129, <8 x i64> poison, <8 x i32> zeroinitializer
  %291 = mul <8 x i64> %.splat130, splat (i64 32)
  %292 = add <8 x i64> %290, %291
  %293 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %289, 0
  %294 = insertvalue { <8 x ptr>, <8 x i64> } %293, <8 x i64> %292, 1
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %294, 1
  %297 = extractelement <8 x ptr> %295, i32 0
  %298 = extractelement <8 x i64> %296, i32 0
  %299 = sub i64 %298, 0
  %300 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %301 = select i1 %300, i64 %299, i64 0
  %private.contiguous.address131 = getelementptr i8, ptr %297, i64 %301
  %private.contiguous.preserve132 = load <8 x float>, ptr %private.contiguous.address131, align 4
  %302 = select <8 x i1> %55, <8 x float> %288, <8 x float> %private.contiguous.preserve132
  store <8 x float> %302, ptr %private.contiguous.address131, align 4
  %.state133 = load i64, ptr %.slot26, align 4
  %303 = add i64 %.state133, 1
  store i64 %303, ptr %.slot26, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false119
  store i64 0, ptr %.spill27, align 4
  %.spill.load134 = load i64, ptr %.spill13, align 4
  %304 = add i64 0, %.spill.load134
  %tile_snapshot.spill.load135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 0
  %306 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 1
  %.splatinsert136 = insertelement <8 x i64> poison, i64 %304, i64 0
  %.splat137 = shufflevector <8 x i64> %.splatinsert136, <8 x i64> poison, <8 x i32> zeroinitializer
  %307 = mul <8 x i64> %.splat137, splat (i64 32)
  %308 = add <8 x i64> %306, %307
  %309 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %305, 0
  %310 = insertvalue { <8 x ptr>, <8 x i64> } %309, <8 x i64> %308, 1
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %310, 1
  %313 = extractelement <8 x ptr> %311, i32 0
  %314 = extractelement <8 x i64> %312, i32 0
  %315 = sub i64 %314, 0
  %316 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %317 = select i1 %316, i64 %315, i64 0
  %private.contiguous.address138 = getelementptr i8, ptr %313, i64 %317
  %private.contiguous.load139 = load <8 x float>, ptr %private.contiguous.address138, align 4
  %318 = select <8 x i1> %55, <8 x float> %private.contiguous.load139, <8 x float> zeroinitializer
  %319 = fmul <8 x float> %318, %318
  %.spill.load140 = load i64, ptr %.spill14, align 4
  %320 = add i64 0, %.spill.load140
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %.splatinsert142 = insertelement <8 x i64> poison, i64 %320, i64 0
  %.splat143 = shufflevector <8 x i64> %.splatinsert142, <8 x i64> poison, <8 x i32> zeroinitializer
  %323 = mul <8 x i64> %.splat143, splat (i64 32)
  %324 = add <8 x i64> %322, %323
  %325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %321, 0
  %326 = insertvalue { <8 x ptr>, <8 x i64> } %325, <8 x i64> %324, 1
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %326, 1
  %329 = extractelement <8 x ptr> %327, i32 0
  %330 = extractelement <8 x i64> %328, i32 0
  %331 = sub i64 %330, 0
  %332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %333 = select i1 %332, i64 %331, i64 0
  %private.contiguous.address144 = getelementptr i8, ptr %329, i64 %333
  %private.contiguous.load145 = load <8 x float>, ptr %private.contiguous.address144, align 4
  %334 = select <8 x i1> %55, <8 x float> %private.contiguous.load145, <8 x float> zeroinitializer
  %335 = fmul <8 x float> %334, %334
  %.spill.load146 = load i64, ptr %.spill15, align 4
  %336 = add i64 0, %.spill.load146
  %tile_snapshot.spill.load147 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %.splatinsert148 = insertelement <8 x i64> poison, i64 %336, i64 0
  %.splat149 = shufflevector <8 x i64> %.splatinsert148, <8 x i64> poison, <8 x i32> zeroinitializer
  %339 = mul <8 x i64> %.splat149, splat (i64 32)
  %340 = add <8 x i64> %338, %339
  %341 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %337, 0
  %342 = insertvalue { <8 x ptr>, <8 x i64> } %341, <8 x i64> %340, 1
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %342, 1
  %345 = extractelement <8 x ptr> %343, i32 0
  %346 = extractelement <8 x i64> %344, i32 0
  %347 = sub i64 %346, 0
  %348 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %349 = select i1 %348, i64 %347, i64 0
  %private.contiguous.address150 = getelementptr i8, ptr %345, i64 %349
  %private.contiguous.load151 = load <8 x float>, ptr %private.contiguous.address150, align 4
  %350 = select <8 x i1> %55, <8 x float> %private.contiguous.load151, <8 x float> zeroinitializer
  %351 = fmul <8 x float> %350, %350
  %.spill.load152 = load i64, ptr %.spill16, align 4
  %352 = add i64 0, %.spill.load152
  %tile_snapshot.spill.load153 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load153, 0
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load153, 1
  %.splatinsert154 = insertelement <8 x i64> poison, i64 %352, i64 0
  %.splat155 = shufflevector <8 x i64> %.splatinsert154, <8 x i64> poison, <8 x i32> zeroinitializer
  %355 = mul <8 x i64> %.splat155, splat (i64 32)
  %356 = add <8 x i64> %354, %355
  %357 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %353, 0
  %358 = insertvalue { <8 x ptr>, <8 x i64> } %357, <8 x i64> %356, 1
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %358, 1
  %361 = extractelement <8 x ptr> %359, i32 0
  %362 = extractelement <8 x i64> %360, i32 0
  %363 = sub i64 %362, 0
  %364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %365 = select i1 %364, i64 %363, i64 0
  %private.contiguous.address156 = getelementptr i8, ptr %361, i64 %365
  %private.contiguous.load157 = load <8 x float>, ptr %private.contiguous.address156, align 4
  %366 = select <8 x i1> %55, <8 x float> %private.contiguous.load157, <8 x float> zeroinitializer
  %367 = fmul <8 x float> %366, %366
  store i64 4, ptr %.slot28, align 4
  %368 = load <8 x float>, ptr %.slot29, align 32
  %369 = select <8 x i1> %55, <8 x float> %319, <8 x float> %368
  store <8 x float> %369, ptr %.slot29, align 32
  %370 = load <8 x float>, ptr %.slot30, align 32
  %371 = select <8 x i1> %55, <8 x float> %335, <8 x float> %370
  store <8 x float> %371, ptr %.slot30, align 32
  %372 = load <8 x float>, ptr %.slot31, align 32
  %373 = select <8 x i1> %55, <8 x float> %351, <8 x float> %372
  store <8 x float> %373, ptr %.slot31, align 32
  %374 = load <8 x float>, ptr %.slot32, align 32
  %375 = select <8 x i1> %55, <8 x float> %367, <8 x float> %374
  store <8 x float> %375, ptr %.slot32, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state158 = load i64, ptr %.slot28, align 4
  %376 = icmp slt i64 %.state158, 64
  br i1 %376, label %direct.true159, label %direct.false160

direct.schedule.11:                               ; preds = %direct.true159
  %.state161 = load i64, ptr %.slot28, align 4
  %377 = add i64 %.state161, 0
  %378 = sdiv i64 %377, 1
  %.spill.load162 = load i64, ptr %.spill12, align 4
  %379 = add i64 %.spill.load162, %378
  %.spill.load163 = load i64, ptr %.spill27, align 4
  %380 = add i64 %.spill.load163, %379
  %tile_snapshot.spill.load164 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load164, 0
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load164, 1
  %.splatinsert165 = insertelement <8 x i64> poison, i64 %380, i64 0
  %.splat166 = shufflevector <8 x i64> %.splatinsert165, <8 x i64> poison, <8 x i32> zeroinitializer
  %383 = mul <8 x i64> %.splat166, splat (i64 32)
  %384 = add <8 x i64> %382, %383
  %385 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %381, 0
  %386 = insertvalue { <8 x ptr>, <8 x i64> } %385, <8 x i64> %384, 1
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %386, 1
  %389 = extractelement <8 x ptr> %387, i32 0
  %390 = extractelement <8 x i64> %388, i32 0
  %391 = sub i64 %390, 0
  %392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %393 = select i1 %392, i64 %391, i64 0
  %private.contiguous.address167 = getelementptr i8, ptr %389, i64 %393
  %private.contiguous.load168 = load <8 x float>, ptr %private.contiguous.address167, align 4
  %394 = select <8 x i1> %55, <8 x float> %private.contiguous.load168, <8 x float> zeroinitializer
  %395 = fmul <8 x float> %394, %394
  %.state169 = load <8 x float>, ptr %.slot29, align 32
  %396 = fadd <8 x float> %.state169, %395
  %.state170 = load i64, ptr %.slot28, align 4
  %397 = add i64 %.state170, 1
  %398 = sdiv i64 %397, 1
  %.spill.load171 = load i64, ptr %.spill12, align 4
  %399 = add i64 %.spill.load171, %398
  %.spill.load172 = load i64, ptr %.spill27, align 4
  %400 = add i64 %.spill.load172, %399
  %tile_snapshot.spill.load173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 0
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 1
  %.splatinsert174 = insertelement <8 x i64> poison, i64 %400, i64 0
  %.splat175 = shufflevector <8 x i64> %.splatinsert174, <8 x i64> poison, <8 x i32> zeroinitializer
  %403 = mul <8 x i64> %.splat175, splat (i64 32)
  %404 = add <8 x i64> %402, %403
  %405 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %401, 0
  %406 = insertvalue { <8 x ptr>, <8 x i64> } %405, <8 x i64> %404, 1
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %406, 1
  %409 = extractelement <8 x ptr> %407, i32 0
  %410 = extractelement <8 x i64> %408, i32 0
  %411 = sub i64 %410, 0
  %412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %413 = select i1 %412, i64 %411, i64 0
  %private.contiguous.address176 = getelementptr i8, ptr %409, i64 %413
  %private.contiguous.load177 = load <8 x float>, ptr %private.contiguous.address176, align 4
  %414 = select <8 x i1> %55, <8 x float> %private.contiguous.load177, <8 x float> zeroinitializer
  %415 = fmul <8 x float> %414, %414
  %.state178 = load <8 x float>, ptr %.slot30, align 32
  %416 = fadd <8 x float> %.state178, %415
  %.state179 = load i64, ptr %.slot28, align 4
  %417 = add i64 %.state179, 2
  %418 = sdiv i64 %417, 1
  %.spill.load180 = load i64, ptr %.spill12, align 4
  %419 = add i64 %.spill.load180, %418
  %.spill.load181 = load i64, ptr %.spill27, align 4
  %420 = add i64 %.spill.load181, %419
  %tile_snapshot.spill.load182 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 0
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 1
  %.splatinsert183 = insertelement <8 x i64> poison, i64 %420, i64 0
  %.splat184 = shufflevector <8 x i64> %.splatinsert183, <8 x i64> poison, <8 x i32> zeroinitializer
  %423 = mul <8 x i64> %.splat184, splat (i64 32)
  %424 = add <8 x i64> %422, %423
  %425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %421, 0
  %426 = insertvalue { <8 x ptr>, <8 x i64> } %425, <8 x i64> %424, 1
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %426, 1
  %429 = extractelement <8 x ptr> %427, i32 0
  %430 = extractelement <8 x i64> %428, i32 0
  %431 = sub i64 %430, 0
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %433 = select i1 %432, i64 %431, i64 0
  %private.contiguous.address185 = getelementptr i8, ptr %429, i64 %433
  %private.contiguous.load186 = load <8 x float>, ptr %private.contiguous.address185, align 4
  %434 = select <8 x i1> %55, <8 x float> %private.contiguous.load186, <8 x float> zeroinitializer
  %435 = fmul <8 x float> %434, %434
  %.state187 = load <8 x float>, ptr %.slot31, align 32
  %436 = fadd <8 x float> %.state187, %435
  %.state188 = load i64, ptr %.slot28, align 4
  %437 = add i64 %.state188, 3
  %438 = sdiv i64 %437, 1
  %.spill.load189 = load i64, ptr %.spill12, align 4
  %439 = add i64 %.spill.load189, %438
  %.spill.load190 = load i64, ptr %.spill27, align 4
  %440 = add i64 %.spill.load190, %439
  %tile_snapshot.spill.load191 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %.splatinsert192 = insertelement <8 x i64> poison, i64 %440, i64 0
  %.splat193 = shufflevector <8 x i64> %.splatinsert192, <8 x i64> poison, <8 x i32> zeroinitializer
  %443 = mul <8 x i64> %.splat193, splat (i64 32)
  %444 = add <8 x i64> %442, %443
  %445 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %441, 0
  %446 = insertvalue { <8 x ptr>, <8 x i64> } %445, <8 x i64> %444, 1
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %446, 1
  %449 = extractelement <8 x ptr> %447, i32 0
  %450 = extractelement <8 x i64> %448, i32 0
  %451 = sub i64 %450, 0
  %452 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %453 = select i1 %452, i64 %451, i64 0
  %private.contiguous.address194 = getelementptr i8, ptr %449, i64 %453
  %private.contiguous.load195 = load <8 x float>, ptr %private.contiguous.address194, align 4
  %454 = select <8 x i1> %55, <8 x float> %private.contiguous.load195, <8 x float> zeroinitializer
  %455 = fmul <8 x float> %454, %454
  %.state196 = load <8 x float>, ptr %.slot32, align 32
  %456 = fadd <8 x float> %.state196, %455
  %.state197 = load i64, ptr %.slot28, align 4
  %457 = add i64 %.state197, 4
  store i64 %457, ptr %.slot28, align 4
  %458 = load <8 x float>, ptr %.slot29, align 32
  %459 = select <8 x i1> %55, <8 x float> %396, <8 x float> %458
  store <8 x float> %459, ptr %.slot29, align 32
  %460 = load <8 x float>, ptr %.slot30, align 32
  %461 = select <8 x i1> %55, <8 x float> %416, <8 x float> %460
  store <8 x float> %461, ptr %.slot30, align 32
  %462 = load <8 x float>, ptr %.slot31, align 32
  %463 = select <8 x i1> %55, <8 x float> %436, <8 x float> %462
  store <8 x float> %463, ptr %.slot31, align 32
  %464 = load <8 x float>, ptr %.slot32, align 32
  %465 = select <8 x i1> %55, <8 x float> %456, <8 x float> %464
  store <8 x float> %465, ptr %.slot32, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false160
  %.spill.load198 = load i64, ptr %.spill27, align 4
  %.spill.load199 = load i64, ptr %.spill22, align 4
  %466 = add i64 %.spill.load198, %.spill.load199
  %tile_snapshot.spill.load200 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load200, 0
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load200, 1
  %.splatinsert201 = insertelement <8 x i64> poison, i64 %466, i64 0
  %.splat202 = shufflevector <8 x i64> %.splatinsert201, <8 x i64> poison, <8 x i32> zeroinitializer
  %469 = mul <8 x i64> %.splat202, splat (i64 32)
  %470 = add <8 x i64> %468, %469
  %471 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %467, 0
  %472 = insertvalue { <8 x ptr>, <8 x i64> } %471, <8 x i64> %470, 1
  %473 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %472, 1
  %475 = extractelement <8 x ptr> %473, i32 0
  %476 = extractelement <8 x i64> %474, i32 0
  %477 = sub i64 %476, 0
  %478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %479 = select i1 %478, i64 %477, i64 0
  %private.contiguous.address203 = getelementptr i8, ptr %475, i64 %479
  %private.contiguous.load204 = load <8 x float>, ptr %private.contiguous.address203, align 4
  %480 = select <8 x i1> %55, <8 x float> %private.contiguous.load204, <8 x float> zeroinitializer
  %481 = fmul <8 x float> %480, %480
  %.state205 = load <8 x float>, ptr %.slot29, align 32
  %482 = fadd <8 x float> %.state205, %481
  %.spill.load206 = load float, ptr %.spill10, align 4
  %.splatinsert207 = insertelement <8 x float> poison, float %.spill.load206, i64 0
  %.splat208 = shufflevector <8 x float> %.splatinsert207, <8 x float> poison, <8 x i32> zeroinitializer
  %483 = fadd <8 x float> %.splat208, %482
  %.state209 = load <8 x float>, ptr %.slot30, align 32
  %484 = fadd <8 x float> %483, %.state209
  %.state210 = load <8 x float>, ptr %.slot31, align 32
  %485 = fadd <8 x float> %484, %.state210
  %.state211 = load <8 x float>, ptr %.slot32, align 32
  %486 = fadd <8 x float> %485, %.state211
  %.spill.load212 = load float, ptr %.spill23, align 4
  %.splatinsert213 = insertelement <8 x float> poison, float %.spill.load212, i64 0
  %.splat214 = shufflevector <8 x float> %.splatinsert213, <8 x float> poison, <8 x i32> zeroinitializer
  %487 = fdiv <8 x float> %486, %.splat214
  %488 = load <8 x float>, ptr %.spill33, align 32
  %489 = select <8 x i1> %55, <8 x float> %487, <8 x float> %488
  store <8 x float> %489, ptr %.spill33, align 32
  %490 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill34, align 64
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %490, 0
  %493 = select <8 x i1> %55, <8 x ptr> %491, <8 x ptr> %492
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %490, 1
  %496 = select <8 x i1> %55, <8 x i64> %494, <8 x i64> %495
  %497 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %493, 0
  %498 = insertvalue { <8 x ptr>, <8 x i64> } %497, <8 x i64> %496, 1
  store { <8 x ptr>, <8 x i64> } %498, ptr %tile_snapshot.spill34, align 64
  store i64 0, ptr %.slot35, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state215 = load i64, ptr %.slot35, align 4
  %499 = icmp slt i64 %.state215, 65
  br i1 %499, label %direct.true216, label %direct.false217

direct.schedule.14:                               ; preds = %direct.true216
  %.spill.load218 = load i64, ptr %.spill11, align 4
  %500 = add i64 %.spill.load218, 0
  %.state219 = load i64, ptr %.slot35, align 4
  %501 = add i64 0, %.state219
  %502 = mul i64 %500, 65
  %503 = add i64 %502, %501
  %504 = extractvalue { ptr, i64 } %19, 0
  %505 = mul i64 %503, 4
  %506 = getelementptr i8, ptr %504, i64 %505
  %507 = load float, ptr %506, align 4
  %.splatinsert220 = insertelement <8 x float> poison, float %507, i64 0
  %.splat221 = shufflevector <8 x float> %.splatinsert220, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load222 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill34, align 64
  %508 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load222, 0
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load222, 1
  %.state223 = load i64, ptr %.slot35, align 4
  %.splatinsert224 = insertelement <8 x i64> poison, i64 %.state223, i64 0
  %.splat225 = shufflevector <8 x i64> %.splatinsert224, <8 x i64> poison, <8 x i32> zeroinitializer
  %510 = mul <8 x i64> %.splat225, splat (i64 32)
  %511 = add <8 x i64> %509, %510
  %512 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %508, 0
  %513 = insertvalue { <8 x ptr>, <8 x i64> } %512, <8 x i64> %511, 1
  %514 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %513, 1
  %516 = extractelement <8 x ptr> %514, i32 0
  %517 = extractelement <8 x i64> %515, i32 0
  %518 = sub i64 %517, 0
  %519 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %520 = select i1 %519, i64 %518, i64 0
  %private.contiguous.address226 = getelementptr i8, ptr %516, i64 %520
  %private.contiguous.preserve227 = load <8 x float>, ptr %private.contiguous.address226, align 4
  %521 = select <8 x i1> %55, <8 x float> %.splat221, <8 x float> %private.contiguous.preserve227
  store <8 x float> %521, ptr %private.contiguous.address226, align 4
  %.state228 = load i64, ptr %.slot35, align 4
  %522 = add i64 %.state228, 1
  store i64 %522, ptr %.slot35, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false217
  %.spill.load229 = load <8 x float>, ptr %.spill33, align 32
  %523 = fadd <8 x float> %.spill.load229, splat (float 0x3EE4F8B580000000)
  %524 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %523)
  %525 = load <8 x float>, ptr %.spill36, align 32
  %526 = select <8 x i1> %55, <8 x float> %524, <8 x float> %525
  store <8 x float> %526, ptr %.spill36, align 32
  %527 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %527, 0
  %530 = select <8 x i1> %55, <8 x ptr> %528, <8 x ptr> %529
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %527, 1
  %533 = select <8 x i1> %55, <8 x i64> %531, <8 x i64> %532
  %534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %530, 0
  %535 = insertvalue { <8 x ptr>, <8 x i64> } %534, <8 x i64> %533, 1
  store { <8 x ptr>, <8 x i64> } %535, ptr %tile_snapshot.spill37, align 64
  store i64 0, ptr %.slot38, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state230 = load i64, ptr %.slot38, align 4
  %536 = icmp slt i64 %.state230, 65
  br i1 %536, label %direct.true231, label %direct.false232

direct.schedule.17:                               ; preds = %direct.true231
  %.spill.load233 = load i64, ptr %.spill11, align 4
  %537 = add i64 %.spill.load233, 0
  %.state234 = load i64, ptr %.slot38, align 4
  %538 = add i64 0, %.state234
  %539 = mul i64 %537, 65
  %540 = add i64 %539, %538
  %541 = extractvalue { ptr, i64 } %25, 0
  %542 = mul i64 %540, 4
  %543 = getelementptr i8, ptr %541, i64 %542
  %544 = load float, ptr %543, align 4
  %.splatinsert235 = insertelement <8 x float> poison, float %544, i64 0
  %.splat236 = shufflevector <8 x float> %.splatinsert235, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load237 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 0
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 1
  %.state238 = load i64, ptr %.slot38, align 4
  %.splatinsert239 = insertelement <8 x i64> poison, i64 %.state238, i64 0
  %.splat240 = shufflevector <8 x i64> %.splatinsert239, <8 x i64> poison, <8 x i32> zeroinitializer
  %547 = mul <8 x i64> %.splat240, splat (i64 32)
  %548 = add <8 x i64> %546, %547
  %549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %545, 0
  %550 = insertvalue { <8 x ptr>, <8 x i64> } %549, <8 x i64> %548, 1
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %550, 1
  %553 = extractelement <8 x ptr> %551, i32 0
  %554 = extractelement <8 x i64> %552, i32 0
  %555 = sub i64 %554, 0
  %556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %557 = select i1 %556, i64 %555, i64 0
  %private.contiguous.address241 = getelementptr i8, ptr %553, i64 %557
  %private.contiguous.preserve242 = load <8 x float>, ptr %private.contiguous.address241, align 4
  %558 = select <8 x i1> %55, <8 x float> %.splat236, <8 x float> %private.contiguous.preserve242
  store <8 x float> %558, ptr %private.contiguous.address241, align 4
  %.state243 = load i64, ptr %.slot38, align 4
  %559 = add i64 %.state243, 1
  store i64 %559, ptr %.slot38, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false232
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state244 = load i64, ptr %.slot39, align 4
  %560 = icmp slt i64 %.state244, 65
  br i1 %560, label %direct.true245, label %direct.false246

direct.schedule.20:                               ; preds = %direct.true245
  %.spill.load247 = load <8 x i64>, ptr %.spill, align 64
  %561 = add <8 x i64> %.spill.load247, zeroinitializer
  %562 = add <8 x i64> zeroinitializer, %561
  %.state248 = load i64, ptr %.slot39, align 4
  %563 = add i64 0, %.state248
  %564 = mul <8 x i64> %562, splat (i64 65)
  %.splatinsert249 = insertelement <8 x i64> poison, i64 %563, i64 0
  %.splat250 = shufflevector <8 x i64> %.splatinsert249, <8 x i64> poison, <8 x i32> zeroinitializer
  %565 = add <8 x i64> %564, %.splat250
  %.spill.load251 = load i64, ptr %.spill27, align 4
  %.state252 = load i64, ptr %.slot39, align 4
  %566 = add i64 %.spill.load251, %.state252
  %.spill.load253 = load i64, ptr %.spill27, align 4
  %567 = add i64 %.spill.load253, %566
  %.spill.load254 = load i64, ptr %.spill27, align 4
  %568 = add i64 %.spill.load254, %567
  %tile_snapshot.spill.load255 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 0
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 1
  %.splatinsert256 = insertelement <8 x i64> poison, i64 %568, i64 0
  %.splat257 = shufflevector <8 x i64> %.splatinsert256, <8 x i64> poison, <8 x i32> zeroinitializer
  %571 = mul <8 x i64> %.splat257, splat (i64 32)
  %572 = add <8 x i64> %570, %571
  %573 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %569, 0
  %574 = insertvalue { <8 x ptr>, <8 x i64> } %573, <8 x i64> %572, 1
  %575 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %574, 1
  %577 = extractelement <8 x ptr> %575, i32 0
  %578 = extractelement <8 x i64> %576, i32 0
  %579 = sub i64 %578, 0
  %580 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %581 = select i1 %580, i64 %579, i64 0
  %private.contiguous.address258 = getelementptr i8, ptr %577, i64 %581
  %private.contiguous.load259 = load <8 x float>, ptr %private.contiguous.address258, align 4
  %582 = select <8 x i1> %55, <8 x float> %private.contiguous.load259, <8 x float> zeroinitializer
  %.spill.load260 = load <8 x float>, ptr %.spill36, align 32
  %583 = fdiv <8 x float> %582, %.spill.load260
  %tile_snapshot.spill.load261 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill34, align 64
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load261, 0
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load261, 1
  %.splatinsert262 = insertelement <8 x i64> poison, i64 %567, i64 0
  %.splat263 = shufflevector <8 x i64> %.splatinsert262, <8 x i64> poison, <8 x i32> zeroinitializer
  %586 = mul <8 x i64> %.splat263, splat (i64 32)
  %587 = add <8 x i64> %585, %586
  %588 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %584, 0
  %589 = insertvalue { <8 x ptr>, <8 x i64> } %588, <8 x i64> %587, 1
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %589, 1
  %592 = extractelement <8 x ptr> %590, i32 0
  %593 = extractelement <8 x i64> %591, i32 0
  %594 = sub i64 %593, 0
  %595 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %596 = select i1 %595, i64 %594, i64 0
  %private.contiguous.address264 = getelementptr i8, ptr %592, i64 %596
  %private.contiguous.load265 = load <8 x float>, ptr %private.contiguous.address264, align 4
  %597 = select <8 x i1> %55, <8 x float> %private.contiguous.load265, <8 x float> zeroinitializer
  %598 = fmul <8 x float> %583, %597
  %tile_snapshot.spill.load266 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %599 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 0
  %600 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 1
  %.splatinsert267 = insertelement <8 x i64> poison, i64 %566, i64 0
  %.splat268 = shufflevector <8 x i64> %.splatinsert267, <8 x i64> poison, <8 x i32> zeroinitializer
  %601 = mul <8 x i64> %.splat268, splat (i64 32)
  %602 = add <8 x i64> %600, %601
  %603 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %599, 0
  %604 = insertvalue { <8 x ptr>, <8 x i64> } %603, <8 x i64> %602, 1
  %605 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %606 = extractvalue { <8 x ptr>, <8 x i64> } %604, 1
  %607 = extractelement <8 x ptr> %605, i32 0
  %608 = extractelement <8 x i64> %606, i32 0
  %609 = sub i64 %608, 0
  %610 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %611 = select i1 %610, i64 %609, i64 0
  %private.contiguous.address269 = getelementptr i8, ptr %607, i64 %611
  %private.contiguous.load270 = load <8 x float>, ptr %private.contiguous.address269, align 4
  %612 = select <8 x i1> %55, <8 x float> %private.contiguous.load270, <8 x float> zeroinitializer
  %613 = fadd <8 x float> %598, %612
  %614 = extractvalue { ptr, i64 } %31, 0
  %615 = mul <8 x i64> %565, splat (i64 4)
  %616 = getelementptr i8, ptr %614, <8 x i64> %615
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %613, <8 x ptr> %616, i32 1, <8 x i1> %55)
  %.state271 = load i64, ptr %.slot39, align 4
  %617 = add i64 %.state271, 1
  store i64 %617, ptr %.slot39, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false246
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true69:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false70:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true118:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false119:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true159:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false160:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true216:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false217:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true231:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false232:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true245:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false246:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

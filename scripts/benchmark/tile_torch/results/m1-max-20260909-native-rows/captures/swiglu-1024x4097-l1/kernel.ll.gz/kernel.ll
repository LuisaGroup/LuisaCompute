; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 131104
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %tile_snapshot.spill6 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill6, align 64
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca i64, align 8
  store i64 0, ptr %.slot8, align 4
  %6 = getelementptr i8, ptr %argument_buffer, i64 0
  %7 = load ptr, ptr %6, align 16
  %8 = getelementptr i8, ptr %6, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { ptr, i64 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %9, 1
  %12 = getelementptr i8, ptr %argument_buffer, i64 16
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 32
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 48
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = load i32, ptr %launch_config, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 12
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 4
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 16
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 8
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 20
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 36
  %42 = load i32, ptr %41, align 4
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat10, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %44 = mul i32 %30, 32
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat12, %43
  %46 = mul i32 %34, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat14, zeroinitializer
  %48 = mul i32 %38, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat16, zeroinitializer
  %50 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %45, 0
  %51 = insertvalue [3 x <8 x i32>] %50, <8 x i32> %47, 1
  %52 = insertvalue [3 x <8 x i32>] %51, <8 x i32> %49, 2
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat18
  %54 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  br i1 %54, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %55 = extractvalue [3 x <8 x i32>] %52, 0
  %56 = zext <8 x i32> %55 to <8 x i64>
  %57 = select <8 x i1> %53, <8 x i64> %56, <8 x i64> zeroinitializer
  %58 = select <8 x i1> %53, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %59 = sdiv <8 x i64> %57, %58
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %53, <8 x i64> %59, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %63 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %62, 0
  %65 = select <8 x i1> %53, <8 x ptr> %63, <8 x ptr> %64
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %62, 1
  %68 = select <8 x i1> %53, <8 x i64> %66, <8 x i64> %67
  %69 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %65, 0
  %70 = insertvalue { <8 x ptr>, <8 x i64> } %69, <8 x i64> %68, 1
  store { <8 x ptr>, <8 x i64> } %70, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %71 = icmp slt i64 %.state, 4097
  br i1 %71, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %72 = add <8 x i64> %.spill.load, zeroinitializer
  %73 = add <8 x i64> zeroinitializer, %72
  %.state19 = load i64, ptr %.slot, align 4
  %74 = add i64 0, %.state19
  %75 = mul <8 x i64> %73, splat (i64 4097)
  %.splatinsert20 = insertelement <8 x i64> poison, i64 %74, i64 0
  %.splat21 = shufflevector <8 x i64> %.splatinsert20, <8 x i64> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i64> %75, %.splat21
  %77 = extractvalue { ptr, i64 } %11, 0
  %78 = mul <8 x i64> %76, splat (i64 4)
  %79 = getelementptr i8, ptr %77, <8 x i64> %78
  %80 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %79, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %81 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state22 = load i64, ptr %.slot, align 4
  %.splatinsert23 = insertelement <8 x i64> poison, i64 %.state22, i64 0
  %.splat24 = shufflevector <8 x i64> %.splatinsert23, <8 x i64> poison, <8 x i32> zeroinitializer
  %83 = mul <8 x i64> %.splat24, splat (i64 32)
  %84 = add <8 x i64> %82, %83
  %85 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %81, 0
  %86 = insertvalue { <8 x ptr>, <8 x i64> } %85, <8 x i64> %84, 1
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %86, 1
  %89 = extractelement <8 x ptr> %87, i32 0
  %90 = extractelement <8 x i64> %88, i32 0
  %91 = sub i64 %90, 0
  %92 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %93 = select i1 %92, i64 %91, i64 0
  %private.contiguous.address = getelementptr i8, ptr %89, i64 %93
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %94 = select <8 x i1> %53, <8 x float> %80, <8 x float> %private.contiguous.preserve
  store <8 x float> %94, ptr %private.contiguous.address, align 4
  %.state25 = load i64, ptr %.slot, align 4
  %95 = add i64 %.state25, 1
  store i64 %95, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 1.000000e+00, ptr %.spill5, align 4
  %96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %96, 0
  %99 = select <8 x i1> %53, <8 x ptr> %97, <8 x ptr> %98
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %96, 1
  %102 = select <8 x i1> %53, <8 x i64> %100, <8 x i64> %101
  %103 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %99, 0
  %104 = insertvalue { <8 x ptr>, <8 x i64> } %103, <8 x i64> %102, 1
  store { <8 x ptr>, <8 x i64> } %104, ptr %tile_snapshot.spill6, align 64
  store i64 0, ptr %.slot7, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state26 = load i64, ptr %.slot7, align 4
  %105 = icmp slt i64 %.state26, 4097
  br i1 %105, label %direct.true27, label %direct.false28

direct.schedule.5:                                ; preds = %direct.true27
  %.spill.load29 = load <8 x i64>, ptr %.spill, align 64
  %106 = add <8 x i64> %.spill.load29, zeroinitializer
  %107 = add <8 x i64> zeroinitializer, %106
  %.state30 = load i64, ptr %.slot7, align 4
  %108 = add i64 0, %.state30
  %109 = mul <8 x i64> %107, splat (i64 4097)
  %.splatinsert31 = insertelement <8 x i64> poison, i64 %108, i64 0
  %.splat32 = shufflevector <8 x i64> %.splatinsert31, <8 x i64> poison, <8 x i32> zeroinitializer
  %110 = add <8 x i64> %109, %.splat32
  %111 = extractvalue { ptr, i64 } %17, 0
  %112 = mul <8 x i64> %110, splat (i64 4)
  %113 = getelementptr i8, ptr %111, <8 x i64> %112
  %114 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %113, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load33 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load33, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load33, 1
  %.state34 = load i64, ptr %.slot7, align 4
  %.splatinsert35 = insertelement <8 x i64> poison, i64 %.state34, i64 0
  %.splat36 = shufflevector <8 x i64> %.splatinsert35, <8 x i64> poison, <8 x i32> zeroinitializer
  %117 = mul <8 x i64> %.splat36, splat (i64 32)
  %118 = add <8 x i64> %116, %117
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address37 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve38 = load <8 x float>, ptr %private.contiguous.address37, align 4
  %128 = select <8 x i1> %53, <8 x float> %114, <8 x float> %private.contiguous.preserve38
  store <8 x float> %128, ptr %private.contiguous.address37, align 4
  %.state39 = load i64, ptr %.slot7, align 4
  %129 = add i64 %.state39, 1
  store i64 %129, ptr %.slot7, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false28
  store i64 0, ptr %.slot8, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state40 = load i64, ptr %.slot8, align 4
  %130 = icmp slt i64 %.state40, 4097
  br i1 %130, label %direct.true41, label %direct.false42

direct.schedule.8:                                ; preds = %direct.true41
  %.spill.load43 = load <8 x i64>, ptr %.spill, align 64
  %131 = add <8 x i64> %.spill.load43, zeroinitializer
  %132 = add <8 x i64> zeroinitializer, %131
  %.state44 = load i64, ptr %.slot8, align 4
  %133 = add i64 0, %.state44
  %134 = mul <8 x i64> %132, splat (i64 4097)
  %.splatinsert45 = insertelement <8 x i64> poison, i64 %133, i64 0
  %.splat46 = shufflevector <8 x i64> %.splatinsert45, <8 x i64> poison, <8 x i32> zeroinitializer
  %135 = add <8 x i64> %134, %.splat46
  %.state47 = load i64, ptr %.slot8, align 4
  %136 = add i64 0, %.state47
  %137 = add i64 0, %136
  %tile_snapshot.spill.load48 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load48, 0
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load48, 1
  %.splatinsert49 = insertelement <8 x i64> poison, i64 %137, i64 0
  %.splat50 = shufflevector <8 x i64> %.splatinsert49, <8 x i64> poison, <8 x i32> zeroinitializer
  %140 = mul <8 x i64> %.splat50, splat (i64 32)
  %141 = add <8 x i64> %139, %140
  %142 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %138, 0
  %143 = insertvalue { <8 x ptr>, <8 x i64> } %142, <8 x i64> %141, 1
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %143, 1
  %146 = extractelement <8 x ptr> %144, i32 0
  %147 = extractelement <8 x i64> %145, i32 0
  %148 = sub i64 %147, 0
  %149 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %150 = select i1 %149, i64 %148, i64 0
  %private.contiguous.address51 = getelementptr i8, ptr %146, i64 %150
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address51, align 4
  %151 = select <8 x i1> %53, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %152 = add i64 0, %137
  %153 = add i64 0, %152
  %154 = add i64 0, %153
  %tile_snapshot.spill.load52 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 0
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 1
  %.splatinsert53 = insertelement <8 x i64> poison, i64 %154, i64 0
  %.splat54 = shufflevector <8 x i64> %.splatinsert53, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = mul <8 x i64> %.splat54, splat (i64 32)
  %158 = add <8 x i64> %156, %157
  %159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %155, 0
  %160 = insertvalue { <8 x ptr>, <8 x i64> } %159, <8 x i64> %158, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %160, 1
  %163 = extractelement <8 x ptr> %161, i32 0
  %164 = extractelement <8 x i64> %162, i32 0
  %165 = sub i64 %164, 0
  %166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %167 = select i1 %166, i64 %165, i64 0
  %private.contiguous.address55 = getelementptr i8, ptr %163, i64 %167
  %private.contiguous.load56 = load <8 x float>, ptr %private.contiguous.address55, align 4
  %168 = select <8 x i1> %53, <8 x float> %private.contiguous.load56, <8 x float> zeroinitializer
  %169 = fneg <8 x float> %168
  %170 = select <8 x i1> %53, <8 x float> %169, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %170)
  %.spill.load57 = load float, ptr %.spill5, align 4
  %.splatinsert58 = insertelement <8 x float> poison, float %.spill.load57, i64 0
  %.splat59 = shufflevector <8 x float> %.splatinsert58, <8 x float> poison, <8 x i32> zeroinitializer
  %171 = fadd <8 x float> %.splat59, %native.exp
  %172 = fdiv <8 x float> %151, %171
  %tile_snapshot.spill.load60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 1
  %.splatinsert61 = insertelement <8 x i64> poison, i64 %136, i64 0
  %.splat62 = shufflevector <8 x i64> %.splatinsert61, <8 x i64> poison, <8 x i32> zeroinitializer
  %175 = mul <8 x i64> %.splat62, splat (i64 32)
  %176 = add <8 x i64> %174, %175
  %177 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %178 = insertvalue { <8 x ptr>, <8 x i64> } %177, <8 x i64> %176, 1
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %178, 1
  %181 = extractelement <8 x ptr> %179, i32 0
  %182 = extractelement <8 x i64> %180, i32 0
  %183 = sub i64 %182, 0
  %184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %185 = select i1 %184, i64 %183, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %181, i64 %185
  %private.contiguous.load64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %186 = select <8 x i1> %53, <8 x float> %private.contiguous.load64, <8 x float> zeroinitializer
  %187 = fmul <8 x float> %172, %186
  %188 = extractvalue { ptr, i64 } %29, 0
  %189 = mul <8 x i64> %135, splat (i64 4)
  %190 = getelementptr i8, ptr %188, <8 x i64> %189
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %187, <8 x ptr> %190, i32 1, <8 x i1> %53)
  %.state65 = load i64, ptr %.slot8, align 4
  %191 = add i64 %.state65, 1
  store i64 %191, ptr %.slot8, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false42
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true27:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false28:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true41:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false42:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #2 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 131104
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %tile_snapshot.spill6 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill6, align 64
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca i64, align 8
  store i64 0, ptr %.slot8, align 4
  %6 = getelementptr i8, ptr %argument_buffer, i64 0
  %7 = load ptr, ptr %6, align 16
  %8 = getelementptr i8, ptr %6, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { ptr, i64 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %9, 1
  %12 = getelementptr i8, ptr %argument_buffer, i64 16
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 32
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 48
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = load i32, ptr %launch_config, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 12
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 4
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 16
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 8
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 20
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 36
  %42 = load i32, ptr %41, align 4
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat10, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %44 = mul i32 %30, 32
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat12, %43
  %46 = mul i32 %34, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat14, zeroinitializer
  %48 = mul i32 %38, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat16, zeroinitializer
  %50 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %45, 0
  %51 = insertvalue [3 x <8 x i32>] %50, <8 x i32> %47, 1
  %52 = insertvalue [3 x <8 x i32>] %51, <8 x i32> %49, 2
  %.splatinsert17 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat18
  %54 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  br i1 %54, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %55 = extractvalue [3 x <8 x i32>] %52, 0
  %56 = zext <8 x i32> %55 to <8 x i64>
  %57 = select <8 x i1> %53, <8 x i64> %56, <8 x i64> zeroinitializer
  %58 = select <8 x i1> %53, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %59 = sdiv <8 x i64> %57, %58
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %53, <8 x i64> %59, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %63 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %62, 0
  %65 = select <8 x i1> %53, <8 x ptr> %63, <8 x ptr> %64
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %62, 1
  %68 = select <8 x i1> %53, <8 x i64> %66, <8 x i64> %67
  %69 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %65, 0
  %70 = insertvalue { <8 x ptr>, <8 x i64> } %69, <8 x i64> %68, 1
  store { <8 x ptr>, <8 x i64> } %70, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %71 = icmp slt i64 %.state, 4097
  br i1 %71, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %72 = add <8 x i64> %.spill.load, zeroinitializer
  %73 = add <8 x i64> zeroinitializer, %72
  %.state19 = load i64, ptr %.slot, align 4
  %74 = add i64 0, %.state19
  %75 = mul <8 x i64> %73, splat (i64 4097)
  %.splatinsert20 = insertelement <8 x i64> poison, i64 %74, i64 0
  %.splat21 = shufflevector <8 x i64> %.splatinsert20, <8 x i64> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i64> %75, %.splat21
  %77 = extractvalue { ptr, i64 } %11, 0
  %78 = mul <8 x i64> %76, splat (i64 4)
  %79 = getelementptr i8, ptr %77, <8 x i64> %78
  %80 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %79, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %81 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state22 = load i64, ptr %.slot, align 4
  %.splatinsert23 = insertelement <8 x i64> poison, i64 %.state22, i64 0
  %.splat24 = shufflevector <8 x i64> %.splatinsert23, <8 x i64> poison, <8 x i32> zeroinitializer
  %83 = mul <8 x i64> %.splat24, splat (i64 32)
  %84 = add <8 x i64> %82, %83
  %85 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %81, 0
  %86 = insertvalue { <8 x ptr>, <8 x i64> } %85, <8 x i64> %84, 1
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %86, 1
  %89 = extractelement <8 x ptr> %87, i32 0
  %90 = extractelement <8 x i64> %88, i32 0
  %91 = sub i64 %90, 0
  %92 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %93 = select i1 %92, i64 %91, i64 0
  %private.contiguous.address = getelementptr i8, ptr %89, i64 %93
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %94 = select <8 x i1> %53, <8 x float> %80, <8 x float> %private.contiguous.preserve
  store <8 x float> %94, ptr %private.contiguous.address, align 4
  %.state25 = load i64, ptr %.slot, align 4
  %95 = add i64 %.state25, 1
  store i64 %95, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 1.000000e+00, ptr %.spill5, align 4
  %96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %96, 0
  %99 = select <8 x i1> %53, <8 x ptr> %97, <8 x ptr> %98
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %96, 1
  %102 = select <8 x i1> %53, <8 x i64> %100, <8 x i64> %101
  %103 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %99, 0
  %104 = insertvalue { <8 x ptr>, <8 x i64> } %103, <8 x i64> %102, 1
  store { <8 x ptr>, <8 x i64> } %104, ptr %tile_snapshot.spill6, align 64
  store i64 0, ptr %.slot7, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state26 = load i64, ptr %.slot7, align 4
  %105 = icmp slt i64 %.state26, 4097
  br i1 %105, label %direct.true27, label %direct.false28

direct.schedule.5:                                ; preds = %direct.true27
  %.spill.load29 = load <8 x i64>, ptr %.spill, align 64
  %106 = add <8 x i64> %.spill.load29, zeroinitializer
  %107 = add <8 x i64> zeroinitializer, %106
  %.state30 = load i64, ptr %.slot7, align 4
  %108 = add i64 0, %.state30
  %109 = mul <8 x i64> %107, splat (i64 4097)
  %.splatinsert31 = insertelement <8 x i64> poison, i64 %108, i64 0
  %.splat32 = shufflevector <8 x i64> %.splatinsert31, <8 x i64> poison, <8 x i32> zeroinitializer
  %110 = add <8 x i64> %109, %.splat32
  %111 = extractvalue { ptr, i64 } %17, 0
  %112 = mul <8 x i64> %110, splat (i64 4)
  %113 = getelementptr i8, ptr %111, <8 x i64> %112
  %114 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %113, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load33 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load33, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load33, 1
  %.state34 = load i64, ptr %.slot7, align 4
  %.splatinsert35 = insertelement <8 x i64> poison, i64 %.state34, i64 0
  %.splat36 = shufflevector <8 x i64> %.splatinsert35, <8 x i64> poison, <8 x i32> zeroinitializer
  %117 = mul <8 x i64> %.splat36, splat (i64 32)
  %118 = add <8 x i64> %116, %117
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address37 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve38 = load <8 x float>, ptr %private.contiguous.address37, align 4
  %128 = select <8 x i1> %53, <8 x float> %114, <8 x float> %private.contiguous.preserve38
  store <8 x float> %128, ptr %private.contiguous.address37, align 4
  %.state39 = load i64, ptr %.slot7, align 4
  %129 = add i64 %.state39, 1
  store i64 %129, ptr %.slot7, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false28
  store i64 0, ptr %.slot8, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state40 = load i64, ptr %.slot8, align 4
  %130 = icmp slt i64 %.state40, 4097
  br i1 %130, label %direct.true41, label %direct.false42

direct.schedule.8:                                ; preds = %direct.true41
  %.spill.load43 = load <8 x i64>, ptr %.spill, align 64
  %131 = add <8 x i64> %.spill.load43, zeroinitializer
  %132 = add <8 x i64> zeroinitializer, %131
  %.state44 = load i64, ptr %.slot8, align 4
  %133 = add i64 0, %.state44
  %134 = mul <8 x i64> %132, splat (i64 4097)
  %.splatinsert45 = insertelement <8 x i64> poison, i64 %133, i64 0
  %.splat46 = shufflevector <8 x i64> %.splatinsert45, <8 x i64> poison, <8 x i32> zeroinitializer
  %135 = add <8 x i64> %134, %.splat46
  %.state47 = load i64, ptr %.slot8, align 4
  %136 = add i64 0, %.state47
  %137 = add i64 0, %136
  %tile_snapshot.spill.load48 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load48, 0
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load48, 1
  %.splatinsert49 = insertelement <8 x i64> poison, i64 %137, i64 0
  %.splat50 = shufflevector <8 x i64> %.splatinsert49, <8 x i64> poison, <8 x i32> zeroinitializer
  %140 = mul <8 x i64> %.splat50, splat (i64 32)
  %141 = add <8 x i64> %139, %140
  %142 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %138, 0
  %143 = insertvalue { <8 x ptr>, <8 x i64> } %142, <8 x i64> %141, 1
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %143, 1
  %146 = extractelement <8 x ptr> %144, i32 0
  %147 = extractelement <8 x i64> %145, i32 0
  %148 = sub i64 %147, 0
  %149 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %150 = select i1 %149, i64 %148, i64 0
  %private.contiguous.address51 = getelementptr i8, ptr %146, i64 %150
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address51, align 4
  %151 = select <8 x i1> %53, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %152 = add i64 0, %137
  %153 = add i64 0, %152
  %154 = add i64 0, %153
  %tile_snapshot.spill.load52 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 0
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 1
  %.splatinsert53 = insertelement <8 x i64> poison, i64 %154, i64 0
  %.splat54 = shufflevector <8 x i64> %.splatinsert53, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = mul <8 x i64> %.splat54, splat (i64 32)
  %158 = add <8 x i64> %156, %157
  %159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %155, 0
  %160 = insertvalue { <8 x ptr>, <8 x i64> } %159, <8 x i64> %158, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %160, 1
  %163 = extractelement <8 x ptr> %161, i32 0
  %164 = extractelement <8 x i64> %162, i32 0
  %165 = sub i64 %164, 0
  %166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %167 = select i1 %166, i64 %165, i64 0
  %private.contiguous.address55 = getelementptr i8, ptr %163, i64 %167
  %private.contiguous.load56 = load <8 x float>, ptr %private.contiguous.address55, align 4
  %168 = select <8 x i1> %53, <8 x float> %private.contiguous.load56, <8 x float> zeroinitializer
  %169 = fneg <8 x float> %168
  %170 = select <8 x i1> %53, <8 x float> %169, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %170)
  %.spill.load57 = load float, ptr %.spill5, align 4
  %.splatinsert58 = insertelement <8 x float> poison, float %.spill.load57, i64 0
  %.splat59 = shufflevector <8 x float> %.splatinsert58, <8 x float> poison, <8 x i32> zeroinitializer
  %171 = fadd <8 x float> %.splat59, %native.exp
  %172 = fdiv <8 x float> %151, %171
  %tile_snapshot.spill.load60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 1
  %.splatinsert61 = insertelement <8 x i64> poison, i64 %136, i64 0
  %.splat62 = shufflevector <8 x i64> %.splatinsert61, <8 x i64> poison, <8 x i32> zeroinitializer
  %175 = mul <8 x i64> %.splat62, splat (i64 32)
  %176 = add <8 x i64> %174, %175
  %177 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %178 = insertvalue { <8 x ptr>, <8 x i64> } %177, <8 x i64> %176, 1
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %178, 1
  %181 = extractelement <8 x ptr> %179, i32 0
  %182 = extractelement <8 x i64> %180, i32 0
  %183 = sub i64 %182, 0
  %184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %185 = select i1 %184, i64 %183, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %181, i64 %185
  %private.contiguous.load64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %186 = select <8 x i1> %53, <8 x float> %private.contiguous.load64, <8 x float> zeroinitializer
  %187 = fmul <8 x float> %172, %186
  %188 = extractvalue { ptr, i64 } %29, 0
  %189 = mul <8 x i64> %135, splat (i64 4)
  %190 = getelementptr i8, ptr %188, <8 x i64> %189
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %187, <8 x ptr> %190, i32 1, <8 x i1> %53)
  %.state65 = load i64, ptr %.slot8, align 4
  %191 = add i64 %.state65, 1
  store i64 %191, ptr %.slot8, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false42
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true27:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false28:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true41:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false42:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }

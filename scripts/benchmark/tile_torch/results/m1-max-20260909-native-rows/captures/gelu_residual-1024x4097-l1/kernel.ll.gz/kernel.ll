; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 131104
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill7, align 4
  %.spill8 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill8, align 4
  %tile_snapshot.spill9 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill9, align 64
  %.slot10 = alloca i64, align 8
  store i64 0, ptr %.slot10, align 4
  %.slot11 = alloca i64, align 8
  store i64 0, ptr %.slot11, align 4
  %6 = getelementptr i8, ptr %argument_buffer, i64 0
  %7 = load ptr, ptr %6, align 16
  %8 = getelementptr i8, ptr %6, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { ptr, i64 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %9, 1
  %12 = getelementptr i8, ptr %argument_buffer, i64 16
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 32
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 48
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = load i32, ptr %launch_config, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 12
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 4
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 16
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 8
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 20
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 36
  %42 = load i32, ptr %41, align 4
  %.splatinsert12 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat13 = shufflevector <8 x i32> %.splatinsert12, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat13, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %44 = mul i32 %30, 32
  %.splatinsert14 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat15 = shufflevector <8 x i32> %.splatinsert14, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat15, %43
  %46 = mul i32 %34, 1
  %.splatinsert16 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat17 = shufflevector <8 x i32> %.splatinsert16, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat17, zeroinitializer
  %48 = mul i32 %38, 1
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat19, zeroinitializer
  %50 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %45, 0
  %51 = insertvalue [3 x <8 x i32>] %50, <8 x i32> %47, 1
  %52 = insertvalue [3 x <8 x i32>] %51, <8 x i32> %49, 2
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat21
  %54 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  br i1 %54, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %55 = extractvalue [3 x <8 x i32>] %52, 0
  %56 = zext <8 x i32> %55 to <8 x i64>
  %57 = select <8 x i1> %53, <8 x i64> %56, <8 x i64> zeroinitializer
  %58 = select <8 x i1> %53, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %59 = sdiv <8 x i64> %57, %58
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %53, <8 x i64> %59, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %63 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %62, 0
  %65 = select <8 x i1> %53, <8 x ptr> %63, <8 x ptr> %64
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %62, 1
  %68 = select <8 x i1> %53, <8 x i64> %66, <8 x i64> %67
  %69 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %65, 0
  %70 = insertvalue { <8 x ptr>, <8 x i64> } %69, <8 x i64> %68, 1
  store { <8 x ptr>, <8 x i64> } %70, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %71 = icmp slt i64 %.state, 4097
  br i1 %71, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %72 = add <8 x i64> %.spill.load, zeroinitializer
  %73 = add <8 x i64> zeroinitializer, %72
  %.state22 = load i64, ptr %.slot, align 4
  %74 = add i64 0, %.state22
  %75 = mul <8 x i64> %73, splat (i64 4097)
  %.splatinsert23 = insertelement <8 x i64> poison, i64 %74, i64 0
  %.splat24 = shufflevector <8 x i64> %.splatinsert23, <8 x i64> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i64> %75, %.splat24
  %77 = extractvalue { ptr, i64 } %11, 0
  %78 = mul <8 x i64> %76, splat (i64 4)
  %79 = getelementptr i8, ptr %77, <8 x i64> %78
  %80 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %79, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %81 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state25 = load i64, ptr %.slot, align 4
  %.splatinsert26 = insertelement <8 x i64> poison, i64 %.state25, i64 0
  %.splat27 = shufflevector <8 x i64> %.splatinsert26, <8 x i64> poison, <8 x i32> zeroinitializer
  %83 = mul <8 x i64> %.splat27, splat (i64 32)
  %84 = add <8 x i64> %82, %83
  %85 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %81, 0
  %86 = insertvalue { <8 x ptr>, <8 x i64> } %85, <8 x i64> %84, 1
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %86, 1
  %89 = extractelement <8 x ptr> %87, i32 0
  %90 = extractelement <8 x i64> %88, i32 0
  %91 = sub i64 %90, 0
  %92 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %93 = select i1 %92, i64 %91, i64 0
  %private.contiguous.address = getelementptr i8, ptr %89, i64 %93
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %94 = select <8 x i1> %53, <8 x float> %80, <8 x float> %private.contiguous.preserve
  store <8 x float> %94, ptr %private.contiguous.address, align 4
  %.state28 = load i64, ptr %.slot, align 4
  %95 = add i64 %.state28, 1
  store i64 %95, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 5.000000e-01, ptr %.spill5, align 4
  store float 0x3FA6E4E260000000, ptr %.spill6, align 4
  store float 0x3FE9884540000000, ptr %.spill7, align 4
  store float 1.000000e+00, ptr %.spill8, align 4
  %96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill9, align 64
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %96, 0
  %99 = select <8 x i1> %53, <8 x ptr> %97, <8 x ptr> %98
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %96, 1
  %102 = select <8 x i1> %53, <8 x i64> %100, <8 x i64> %101
  %103 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %99, 0
  %104 = insertvalue { <8 x ptr>, <8 x i64> } %103, <8 x i64> %102, 1
  store { <8 x ptr>, <8 x i64> } %104, ptr %tile_snapshot.spill9, align 64
  store i64 0, ptr %.slot10, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state29 = load i64, ptr %.slot10, align 4
  %105 = icmp slt i64 %.state29, 4097
  br i1 %105, label %direct.true30, label %direct.false31

direct.schedule.5:                                ; preds = %direct.true30
  %.spill.load32 = load <8 x i64>, ptr %.spill, align 64
  %106 = add <8 x i64> %.spill.load32, zeroinitializer
  %107 = add <8 x i64> zeroinitializer, %106
  %.state33 = load i64, ptr %.slot10, align 4
  %108 = add i64 0, %.state33
  %109 = mul <8 x i64> %107, splat (i64 4097)
  %.splatinsert34 = insertelement <8 x i64> poison, i64 %108, i64 0
  %.splat35 = shufflevector <8 x i64> %.splatinsert34, <8 x i64> poison, <8 x i32> zeroinitializer
  %110 = add <8 x i64> %109, %.splat35
  %111 = extractvalue { ptr, i64 } %17, 0
  %112 = mul <8 x i64> %110, splat (i64 4)
  %113 = getelementptr i8, ptr %111, <8 x i64> %112
  %114 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %113, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load36 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill9, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 1
  %.state37 = load i64, ptr %.slot10, align 4
  %.splatinsert38 = insertelement <8 x i64> poison, i64 %.state37, i64 0
  %.splat39 = shufflevector <8 x i64> %.splatinsert38, <8 x i64> poison, <8 x i32> zeroinitializer
  %117 = mul <8 x i64> %.splat39, splat (i64 32)
  %118 = add <8 x i64> %116, %117
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address40 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve41 = load <8 x float>, ptr %private.contiguous.address40, align 4
  %128 = select <8 x i1> %53, <8 x float> %114, <8 x float> %private.contiguous.preserve41
  store <8 x float> %128, ptr %private.contiguous.address40, align 4
  %.state42 = load i64, ptr %.slot10, align 4
  %129 = add i64 %.state42, 1
  store i64 %129, ptr %.slot10, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false31
  store i64 0, ptr %.slot11, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state43 = load i64, ptr %.slot11, align 4
  %130 = icmp slt i64 %.state43, 4097
  br i1 %130, label %direct.true44, label %direct.false45

direct.schedule.8:                                ; preds = %direct.true44
  %.spill.load46 = load <8 x i64>, ptr %.spill, align 64
  %131 = add <8 x i64> %.spill.load46, zeroinitializer
  %132 = add <8 x i64> zeroinitializer, %131
  %.state47 = load i64, ptr %.slot11, align 4
  %133 = add i64 0, %.state47
  %134 = mul <8 x i64> %132, splat (i64 4097)
  %.splatinsert48 = insertelement <8 x i64> poison, i64 %133, i64 0
  %.splat49 = shufflevector <8 x i64> %.splatinsert48, <8 x i64> poison, <8 x i32> zeroinitializer
  %135 = add <8 x i64> %134, %.splat49
  %.state50 = load i64, ptr %.slot11, align 4
  %136 = add i64 0, %.state50
  %137 = add i64 0, %136
  %138 = add i64 0, %137
  %tile_snapshot.spill.load51 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load51, 0
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load51, 1
  %.splatinsert52 = insertelement <8 x i64> poison, i64 %138, i64 0
  %.splat53 = shufflevector <8 x i64> %.splatinsert52, <8 x i64> poison, <8 x i32> zeroinitializer
  %141 = mul <8 x i64> %.splat53, splat (i64 32)
  %142 = add <8 x i64> %140, %141
  %143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %139, 0
  %144 = insertvalue { <8 x ptr>, <8 x i64> } %143, <8 x i64> %142, 1
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %144, 1
  %147 = extractelement <8 x ptr> %145, i32 0
  %148 = extractelement <8 x i64> %146, i32 0
  %149 = sub i64 %148, 0
  %150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %151 = select i1 %150, i64 %149, i64 0
  %private.contiguous.address54 = getelementptr i8, ptr %147, i64 %151
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address54, align 4
  %152 = select <8 x i1> %53, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load55 = load float, ptr %.spill5, align 4
  %.splatinsert56 = insertelement <8 x float> poison, float %.spill.load55, i64 0
  %.splat57 = shufflevector <8 x float> %.splatinsert56, <8 x float> poison, <8 x i32> zeroinitializer
  %153 = fmul <8 x float> %.splat57, %152
  %154 = add i64 0, %138
  %155 = add i64 0, %154
  %156 = add i64 0, %155
  %tile_snapshot.spill.load58 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load58, 0
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load58, 1
  %.splatinsert59 = insertelement <8 x i64> poison, i64 %156, i64 0
  %.splat60 = shufflevector <8 x i64> %.splatinsert59, <8 x i64> poison, <8 x i32> zeroinitializer
  %159 = mul <8 x i64> %.splat60, splat (i64 32)
  %160 = add <8 x i64> %158, %159
  %161 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %157, 0
  %162 = insertvalue { <8 x ptr>, <8 x i64> } %161, <8 x i64> %160, 1
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %162, 1
  %165 = extractelement <8 x ptr> %163, i32 0
  %166 = extractelement <8 x i64> %164, i32 0
  %167 = sub i64 %166, 0
  %168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %169 = select i1 %168, i64 %167, i64 0
  %private.contiguous.address61 = getelementptr i8, ptr %165, i64 %169
  %private.contiguous.load62 = load <8 x float>, ptr %private.contiguous.address61, align 4
  %170 = select <8 x i1> %53, <8 x float> %private.contiguous.load62, <8 x float> zeroinitializer
  %171 = add i64 0, %156
  %172 = add i64 0, %171
  %173 = add i64 0, %172
  %tile_snapshot.spill.load63 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load63, 0
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load63, 1
  %.splatinsert64 = insertelement <8 x i64> poison, i64 %173, i64 0
  %.splat65 = shufflevector <8 x i64> %.splatinsert64, <8 x i64> poison, <8 x i32> zeroinitializer
  %176 = mul <8 x i64> %.splat65, splat (i64 32)
  %177 = add <8 x i64> %175, %176
  %178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %174, 0
  %179 = insertvalue { <8 x ptr>, <8 x i64> } %178, <8 x i64> %177, 1
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %181 = extractvalue { <8 x ptr>, <8 x i64> } %179, 1
  %182 = extractelement <8 x ptr> %180, i32 0
  %183 = extractelement <8 x i64> %181, i32 0
  %184 = sub i64 %183, 0
  %185 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %186 = select i1 %185, i64 %184, i64 0
  %private.contiguous.address66 = getelementptr i8, ptr %182, i64 %186
  %private.contiguous.load67 = load <8 x float>, ptr %private.contiguous.address66, align 4
  %187 = select <8 x i1> %53, <8 x float> %private.contiguous.load67, <8 x float> zeroinitializer
  %.spill.load68 = load float, ptr %.spill6, align 4
  %.splatinsert69 = insertelement <8 x float> poison, float %.spill.load68, i64 0
  %.splat70 = shufflevector <8 x float> %.splatinsert69, <8 x float> poison, <8 x i32> zeroinitializer
  %188 = fmul <8 x float> %.splat70, %187
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %172, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %191 = mul <8 x i64> %.splat73, splat (i64 32)
  %192 = add <8 x i64> %190, %191
  %193 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %189, 0
  %194 = insertvalue { <8 x ptr>, <8 x i64> } %193, <8 x i64> %192, 1
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %194, 1
  %197 = extractelement <8 x ptr> %195, i32 0
  %198 = extractelement <8 x i64> %196, i32 0
  %199 = sub i64 %198, 0
  %200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %201 = select i1 %200, i64 %199, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %197, i64 %201
  %private.contiguous.load75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %202 = select <8 x i1> %53, <8 x float> %private.contiguous.load75, <8 x float> zeroinitializer
  %203 = fmul <8 x float> %188, %202
  %tile_snapshot.spill.load76 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 0
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 1
  %.splatinsert77 = insertelement <8 x i64> poison, i64 %171, i64 0
  %.splat78 = shufflevector <8 x i64> %.splatinsert77, <8 x i64> poison, <8 x i32> zeroinitializer
  %206 = mul <8 x i64> %.splat78, splat (i64 32)
  %207 = add <8 x i64> %205, %206
  %208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %204, 0
  %209 = insertvalue { <8 x ptr>, <8 x i64> } %208, <8 x i64> %207, 1
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %209, 1
  %212 = extractelement <8 x ptr> %210, i32 0
  %213 = extractelement <8 x i64> %211, i32 0
  %214 = sub i64 %213, 0
  %215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %216 = select i1 %215, i64 %214, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %212, i64 %216
  %private.contiguous.load80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %217 = select <8 x i1> %53, <8 x float> %private.contiguous.load80, <8 x float> zeroinitializer
  %218 = fmul <8 x float> %203, %217
  %219 = fadd <8 x float> %170, %218
  %.spill.load81 = load float, ptr %.spill7, align 4
  %.splatinsert82 = insertelement <8 x float> poison, float %.spill.load81, i64 0
  %.splat83 = shufflevector <8 x float> %.splatinsert82, <8 x float> poison, <8 x i32> zeroinitializer
  %220 = fmul <8 x float> %.splat83, %219
  %221 = select <8 x i1> %53, <8 x float> %220, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %221)
  %.spill.load84 = load float, ptr %.spill8, align 4
  %.splatinsert85 = insertelement <8 x float> poison, float %.spill.load84, i64 0
  %.splat86 = shufflevector <8 x float> %.splatinsert85, <8 x float> poison, <8 x i32> zeroinitializer
  %222 = fadd <8 x float> %.splat86, %native.tanh
  %223 = fmul <8 x float> %153, %222
  %tile_snapshot.spill.load87 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill9, align 64
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 0
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 1
  %.splatinsert88 = insertelement <8 x i64> poison, i64 %136, i64 0
  %.splat89 = shufflevector <8 x i64> %.splatinsert88, <8 x i64> poison, <8 x i32> zeroinitializer
  %226 = mul <8 x i64> %.splat89, splat (i64 32)
  %227 = add <8 x i64> %225, %226
  %228 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %224, 0
  %229 = insertvalue { <8 x ptr>, <8 x i64> } %228, <8 x i64> %227, 1
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %229, 1
  %232 = extractelement <8 x ptr> %230, i32 0
  %233 = extractelement <8 x i64> %231, i32 0
  %234 = sub i64 %233, 0
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %236 = select i1 %235, i64 %234, i64 0
  %private.contiguous.address90 = getelementptr i8, ptr %232, i64 %236
  %private.contiguous.load91 = load <8 x float>, ptr %private.contiguous.address90, align 4
  %237 = select <8 x i1> %53, <8 x float> %private.contiguous.load91, <8 x float> zeroinitializer
  %238 = fadd <8 x float> %223, %237
  %239 = extractvalue { ptr, i64 } %29, 0
  %240 = mul <8 x i64> %135, splat (i64 4)
  %241 = getelementptr i8, ptr %239, <8 x i64> %240
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %238, <8 x ptr> %241, i32 1, <8 x i1> %53)
  %.state92 = load i64, ptr %.slot11, align 4
  %242 = add i64 %.state92, 1
  store i64 %242, ptr %.slot11, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false45
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true30:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false31:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true44:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false45:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %x) #2 {
entry:
  %0 = bitcast <8 x float> %x to <8 x i32>
  %1 = and <8 x i32> %0, splat (i32 2147483647)
  %2 = bitcast <8 x i32> %1 to <8 x float>
  %3 = fcmp contract ole <8 x float> %2, splat (float 1.000000e+00)
  %4 = fmul contract <8 x float> %2, %2
  %5 = fmul contract <8 x float> splat (float 0x3DE6124620000000), %4
  %6 = fadd contract <8 x float> %5, splat (float 0x3E5AE64560000000)
  %7 = fmul contract <8 x float> %6, %4
  %8 = fadd contract <8 x float> %7, splat (float 0x3EC71DE3A0000000)
  %9 = fmul contract <8 x float> %8, %4
  %10 = fadd contract <8 x float> %9, splat (float 0x3F2A01A020000000)
  %11 = fmul contract <8 x float> %10, %4
  %12 = fadd contract <8 x float> %11, splat (float 0x3F81111120000000)
  %13 = fmul contract <8 x float> %12, %4
  %14 = fadd contract <8 x float> %13, splat (float 0x3FC5555560000000)
  %15 = fmul contract <8 x float> %14, %4
  %16 = fadd contract <8 x float> %15, splat (float 1.000000e+00)
  %17 = fmul contract <8 x float> %2, %16
  %18 = fmul contract <8 x float> %2, %2
  %19 = fmul contract <8 x float> splat (float 0x3E21EED8E0000000), %18
  %20 = fadd contract <8 x float> %19, splat (float 0x3E927E4FC0000000)
  %21 = fmul contract <8 x float> %20, %18
  %22 = fadd contract <8 x float> %21, splat (float 0x3EFA01A020000000)
  %23 = fmul contract <8 x float> %22, %18
  %24 = fadd contract <8 x float> %23, splat (float 0x3F56C16C20000000)
  %25 = fmul contract <8 x float> %24, %18
  %26 = fadd contract <8 x float> %25, splat (float 0x3FA5555560000000)
  %27 = fmul contract <8 x float> %26, %18
  %28 = fadd contract <8 x float> %27, splat (float 5.000000e-01)
  %29 = fmul contract <8 x float> %28, %18
  %30 = fadd contract <8 x float> %29, splat (float 1.000000e+00)
  %31 = fdiv contract <8 x float> %17, %30
  %32 = fcmp contract ole <8 x float> %2, splat (float 9.000000e+00)
  %33 = select contract <8 x i1> %32, <8 x float> %2, <8 x float> zeroinitializer
  %exp.half = call contract <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %33)
  %34 = fdiv contract <8 x float> splat (float 2.500000e-01), %exp.half
  %35 = fsub contract <8 x float> %exp.half, %34
  %36 = fadd contract <8 x float> %exp.half, %34
  %37 = fdiv contract <8 x float> %35, %36
  %38 = select contract <8 x i1> %32, <8 x float> %37, <8 x float> splat (float 1.000000e+00)
  %39 = select contract <8 x i1> %3, <8 x float> %31, <8 x float> %38
  %40 = bitcast <8 x float> %39 to <8 x i32>
  %41 = and <8 x i32> %40, splat (i32 2147483647)
  %42 = bitcast <8 x float> %x to <8 x i32>
  %43 = and <8 x i32> %42, splat (i32 -2147483648)
  %44 = or <8 x i32> %41, %43
  %45 = bitcast <8 x i32> %44 to <8 x float>
  %46 = fcmp contract uno <8 x float> %x, %x
  %47 = select contract <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %x) #2 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = sub <8 x i32> %11, splat (i32 1)
  %32 = ashr <8 x i32> %31, splat (i32 1)
  %33 = add <8 x i32> %32, splat (i32 127)
  %34 = shl <8 x i32> %33, splat (i32 23)
  %35 = bitcast <8 x i32> %34 to <8 x float>
  %36 = fmul <8 x float> %30, %35
  %37 = sub <8 x i32> %31, %32
  %38 = add <8 x i32> %37, splat (i32 127)
  %39 = shl <8 x i32> %38, splat (i32 23)
  %40 = bitcast <8 x i32> %39 to <8 x float>
  %41 = fmul <8 x float> %36, %40
  %42 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %43 = select <8 x i1> %42, <8 x float> zeroinitializer, <8 x float> %41
  %44 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %45 = select <8 x i1> %44, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %43
  %46 = fcmp uno <8 x float> %x, %x
  %47 = select <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 131104
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill7, align 4
  %.spill8 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill8, align 4
  %tile_snapshot.spill9 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill9, align 64
  %.slot10 = alloca i64, align 8
  store i64 0, ptr %.slot10, align 4
  %.slot11 = alloca i64, align 8
  store i64 0, ptr %.slot11, align 4
  %6 = getelementptr i8, ptr %argument_buffer, i64 0
  %7 = load ptr, ptr %6, align 16
  %8 = getelementptr i8, ptr %6, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { ptr, i64 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %9, 1
  %12 = getelementptr i8, ptr %argument_buffer, i64 16
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 32
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 48
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = load i32, ptr %launch_config, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 12
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 4
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 16
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 8
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 20
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 36
  %42 = load i32, ptr %41, align 4
  %.splatinsert12 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat13 = shufflevector <8 x i32> %.splatinsert12, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat13, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %44 = mul i32 %30, 32
  %.splatinsert14 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat15 = shufflevector <8 x i32> %.splatinsert14, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat15, %43
  %46 = mul i32 %34, 1
  %.splatinsert16 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat17 = shufflevector <8 x i32> %.splatinsert16, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat17, zeroinitializer
  %48 = mul i32 %38, 1
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat19, zeroinitializer
  %50 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %45, 0
  %51 = insertvalue [3 x <8 x i32>] %50, <8 x i32> %47, 1
  %52 = insertvalue [3 x <8 x i32>] %51, <8 x i32> %49, 2
  %.splatinsert20 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat21
  %54 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  br i1 %54, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %55 = extractvalue [3 x <8 x i32>] %52, 0
  %56 = zext <8 x i32> %55 to <8 x i64>
  %57 = select <8 x i1> %53, <8 x i64> %56, <8 x i64> zeroinitializer
  %58 = select <8 x i1> %53, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %59 = sdiv <8 x i64> %57, %58
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %53, <8 x i64> %59, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %63 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %62, 0
  %65 = select <8 x i1> %53, <8 x ptr> %63, <8 x ptr> %64
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %62, 1
  %68 = select <8 x i1> %53, <8 x i64> %66, <8 x i64> %67
  %69 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %65, 0
  %70 = insertvalue { <8 x ptr>, <8 x i64> } %69, <8 x i64> %68, 1
  store { <8 x ptr>, <8 x i64> } %70, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %71 = icmp slt i64 %.state, 4097
  br i1 %71, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %72 = add <8 x i64> %.spill.load, zeroinitializer
  %73 = add <8 x i64> zeroinitializer, %72
  %.state22 = load i64, ptr %.slot, align 4
  %74 = add i64 0, %.state22
  %75 = mul <8 x i64> %73, splat (i64 4097)
  %.splatinsert23 = insertelement <8 x i64> poison, i64 %74, i64 0
  %.splat24 = shufflevector <8 x i64> %.splatinsert23, <8 x i64> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i64> %75, %.splat24
  %77 = extractvalue { ptr, i64 } %11, 0
  %78 = mul <8 x i64> %76, splat (i64 4)
  %79 = getelementptr i8, ptr %77, <8 x i64> %78
  %80 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %79, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %81 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state25 = load i64, ptr %.slot, align 4
  %.splatinsert26 = insertelement <8 x i64> poison, i64 %.state25, i64 0
  %.splat27 = shufflevector <8 x i64> %.splatinsert26, <8 x i64> poison, <8 x i32> zeroinitializer
  %83 = mul <8 x i64> %.splat27, splat (i64 32)
  %84 = add <8 x i64> %82, %83
  %85 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %81, 0
  %86 = insertvalue { <8 x ptr>, <8 x i64> } %85, <8 x i64> %84, 1
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %86, 1
  %89 = extractelement <8 x ptr> %87, i32 0
  %90 = extractelement <8 x i64> %88, i32 0
  %91 = sub i64 %90, 0
  %92 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %93 = select i1 %92, i64 %91, i64 0
  %private.contiguous.address = getelementptr i8, ptr %89, i64 %93
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %94 = select <8 x i1> %53, <8 x float> %80, <8 x float> %private.contiguous.preserve
  store <8 x float> %94, ptr %private.contiguous.address, align 4
  %.state28 = load i64, ptr %.slot, align 4
  %95 = add i64 %.state28, 1
  store i64 %95, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 5.000000e-01, ptr %.spill5, align 4
  store float 0x3FA6E4E260000000, ptr %.spill6, align 4
  store float 0x3FE9884540000000, ptr %.spill7, align 4
  store float 1.000000e+00, ptr %.spill8, align 4
  %96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill9, align 64
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %96, 0
  %99 = select <8 x i1> %53, <8 x ptr> %97, <8 x ptr> %98
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %96, 1
  %102 = select <8 x i1> %53, <8 x i64> %100, <8 x i64> %101
  %103 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %99, 0
  %104 = insertvalue { <8 x ptr>, <8 x i64> } %103, <8 x i64> %102, 1
  store { <8 x ptr>, <8 x i64> } %104, ptr %tile_snapshot.spill9, align 64
  store i64 0, ptr %.slot10, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state29 = load i64, ptr %.slot10, align 4
  %105 = icmp slt i64 %.state29, 4097
  br i1 %105, label %direct.true30, label %direct.false31

direct.schedule.5:                                ; preds = %direct.true30
  %.spill.load32 = load <8 x i64>, ptr %.spill, align 64
  %106 = add <8 x i64> %.spill.load32, zeroinitializer
  %107 = add <8 x i64> zeroinitializer, %106
  %.state33 = load i64, ptr %.slot10, align 4
  %108 = add i64 0, %.state33
  %109 = mul <8 x i64> %107, splat (i64 4097)
  %.splatinsert34 = insertelement <8 x i64> poison, i64 %108, i64 0
  %.splat35 = shufflevector <8 x i64> %.splatinsert34, <8 x i64> poison, <8 x i32> zeroinitializer
  %110 = add <8 x i64> %109, %.splat35
  %111 = extractvalue { ptr, i64 } %17, 0
  %112 = mul <8 x i64> %110, splat (i64 4)
  %113 = getelementptr i8, ptr %111, <8 x i64> %112
  %114 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %113, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load36 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill9, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 1
  %.state37 = load i64, ptr %.slot10, align 4
  %.splatinsert38 = insertelement <8 x i64> poison, i64 %.state37, i64 0
  %.splat39 = shufflevector <8 x i64> %.splatinsert38, <8 x i64> poison, <8 x i32> zeroinitializer
  %117 = mul <8 x i64> %.splat39, splat (i64 32)
  %118 = add <8 x i64> %116, %117
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address40 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve41 = load <8 x float>, ptr %private.contiguous.address40, align 4
  %128 = select <8 x i1> %53, <8 x float> %114, <8 x float> %private.contiguous.preserve41
  store <8 x float> %128, ptr %private.contiguous.address40, align 4
  %.state42 = load i64, ptr %.slot10, align 4
  %129 = add i64 %.state42, 1
  store i64 %129, ptr %.slot10, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false31
  store i64 0, ptr %.slot11, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state43 = load i64, ptr %.slot11, align 4
  %130 = icmp slt i64 %.state43, 4097
  br i1 %130, label %direct.true44, label %direct.false45

direct.schedule.8:                                ; preds = %direct.true44
  %.spill.load46 = load <8 x i64>, ptr %.spill, align 64
  %131 = add <8 x i64> %.spill.load46, zeroinitializer
  %132 = add <8 x i64> zeroinitializer, %131
  %.state47 = load i64, ptr %.slot11, align 4
  %133 = add i64 0, %.state47
  %134 = mul <8 x i64> %132, splat (i64 4097)
  %.splatinsert48 = insertelement <8 x i64> poison, i64 %133, i64 0
  %.splat49 = shufflevector <8 x i64> %.splatinsert48, <8 x i64> poison, <8 x i32> zeroinitializer
  %135 = add <8 x i64> %134, %.splat49
  %.state50 = load i64, ptr %.slot11, align 4
  %136 = add i64 0, %.state50
  %137 = add i64 0, %136
  %138 = add i64 0, %137
  %tile_snapshot.spill.load51 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load51, 0
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load51, 1
  %.splatinsert52 = insertelement <8 x i64> poison, i64 %138, i64 0
  %.splat53 = shufflevector <8 x i64> %.splatinsert52, <8 x i64> poison, <8 x i32> zeroinitializer
  %141 = mul <8 x i64> %.splat53, splat (i64 32)
  %142 = add <8 x i64> %140, %141
  %143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %139, 0
  %144 = insertvalue { <8 x ptr>, <8 x i64> } %143, <8 x i64> %142, 1
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %144, 1
  %147 = extractelement <8 x ptr> %145, i32 0
  %148 = extractelement <8 x i64> %146, i32 0
  %149 = sub i64 %148, 0
  %150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %151 = select i1 %150, i64 %149, i64 0
  %private.contiguous.address54 = getelementptr i8, ptr %147, i64 %151
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address54, align 4
  %152 = select <8 x i1> %53, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load55 = load float, ptr %.spill5, align 4
  %.splatinsert56 = insertelement <8 x float> poison, float %.spill.load55, i64 0
  %.splat57 = shufflevector <8 x float> %.splatinsert56, <8 x float> poison, <8 x i32> zeroinitializer
  %153 = fmul <8 x float> %.splat57, %152
  %154 = add i64 0, %138
  %155 = add i64 0, %154
  %156 = add i64 0, %155
  %tile_snapshot.spill.load58 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load58, 0
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load58, 1
  %.splatinsert59 = insertelement <8 x i64> poison, i64 %156, i64 0
  %.splat60 = shufflevector <8 x i64> %.splatinsert59, <8 x i64> poison, <8 x i32> zeroinitializer
  %159 = mul <8 x i64> %.splat60, splat (i64 32)
  %160 = add <8 x i64> %158, %159
  %161 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %157, 0
  %162 = insertvalue { <8 x ptr>, <8 x i64> } %161, <8 x i64> %160, 1
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %162, 1
  %165 = extractelement <8 x ptr> %163, i32 0
  %166 = extractelement <8 x i64> %164, i32 0
  %167 = sub i64 %166, 0
  %168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %169 = select i1 %168, i64 %167, i64 0
  %private.contiguous.address61 = getelementptr i8, ptr %165, i64 %169
  %private.contiguous.load62 = load <8 x float>, ptr %private.contiguous.address61, align 4
  %170 = select <8 x i1> %53, <8 x float> %private.contiguous.load62, <8 x float> zeroinitializer
  %171 = add i64 0, %156
  %172 = add i64 0, %171
  %173 = add i64 0, %172
  %tile_snapshot.spill.load63 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load63, 0
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load63, 1
  %.splatinsert64 = insertelement <8 x i64> poison, i64 %173, i64 0
  %.splat65 = shufflevector <8 x i64> %.splatinsert64, <8 x i64> poison, <8 x i32> zeroinitializer
  %176 = mul <8 x i64> %.splat65, splat (i64 32)
  %177 = add <8 x i64> %175, %176
  %178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %174, 0
  %179 = insertvalue { <8 x ptr>, <8 x i64> } %178, <8 x i64> %177, 1
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %181 = extractvalue { <8 x ptr>, <8 x i64> } %179, 1
  %182 = extractelement <8 x ptr> %180, i32 0
  %183 = extractelement <8 x i64> %181, i32 0
  %184 = sub i64 %183, 0
  %185 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %186 = select i1 %185, i64 %184, i64 0
  %private.contiguous.address66 = getelementptr i8, ptr %182, i64 %186
  %private.contiguous.load67 = load <8 x float>, ptr %private.contiguous.address66, align 4
  %187 = select <8 x i1> %53, <8 x float> %private.contiguous.load67, <8 x float> zeroinitializer
  %.spill.load68 = load float, ptr %.spill6, align 4
  %.splatinsert69 = insertelement <8 x float> poison, float %.spill.load68, i64 0
  %.splat70 = shufflevector <8 x float> %.splatinsert69, <8 x float> poison, <8 x i32> zeroinitializer
  %188 = fmul <8 x float> %.splat70, %187
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %172, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %191 = mul <8 x i64> %.splat73, splat (i64 32)
  %192 = add <8 x i64> %190, %191
  %193 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %189, 0
  %194 = insertvalue { <8 x ptr>, <8 x i64> } %193, <8 x i64> %192, 1
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %194, 1
  %197 = extractelement <8 x ptr> %195, i32 0
  %198 = extractelement <8 x i64> %196, i32 0
  %199 = sub i64 %198, 0
  %200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %201 = select i1 %200, i64 %199, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %197, i64 %201
  %private.contiguous.load75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %202 = select <8 x i1> %53, <8 x float> %private.contiguous.load75, <8 x float> zeroinitializer
  %203 = fmul <8 x float> %188, %202
  %tile_snapshot.spill.load76 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 0
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 1
  %.splatinsert77 = insertelement <8 x i64> poison, i64 %171, i64 0
  %.splat78 = shufflevector <8 x i64> %.splatinsert77, <8 x i64> poison, <8 x i32> zeroinitializer
  %206 = mul <8 x i64> %.splat78, splat (i64 32)
  %207 = add <8 x i64> %205, %206
  %208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %204, 0
  %209 = insertvalue { <8 x ptr>, <8 x i64> } %208, <8 x i64> %207, 1
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %209, 1
  %212 = extractelement <8 x ptr> %210, i32 0
  %213 = extractelement <8 x i64> %211, i32 0
  %214 = sub i64 %213, 0
  %215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %216 = select i1 %215, i64 %214, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %212, i64 %216
  %private.contiguous.load80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %217 = select <8 x i1> %53, <8 x float> %private.contiguous.load80, <8 x float> zeroinitializer
  %218 = fmul <8 x float> %203, %217
  %219 = fadd <8 x float> %170, %218
  %.spill.load81 = load float, ptr %.spill7, align 4
  %.splatinsert82 = insertelement <8 x float> poison, float %.spill.load81, i64 0
  %.splat83 = shufflevector <8 x float> %.splatinsert82, <8 x float> poison, <8 x i32> zeroinitializer
  %220 = fmul <8 x float> %.splat83, %219
  %221 = select <8 x i1> %53, <8 x float> %220, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %221)
  %.spill.load84 = load float, ptr %.spill8, align 4
  %.splatinsert85 = insertelement <8 x float> poison, float %.spill.load84, i64 0
  %.splat86 = shufflevector <8 x float> %.splatinsert85, <8 x float> poison, <8 x i32> zeroinitializer
  %222 = fadd <8 x float> %.splat86, %native.tanh
  %223 = fmul <8 x float> %153, %222
  %tile_snapshot.spill.load87 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill9, align 64
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 0
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 1
  %.splatinsert88 = insertelement <8 x i64> poison, i64 %136, i64 0
  %.splat89 = shufflevector <8 x i64> %.splatinsert88, <8 x i64> poison, <8 x i32> zeroinitializer
  %226 = mul <8 x i64> %.splat89, splat (i64 32)
  %227 = add <8 x i64> %225, %226
  %228 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %224, 0
  %229 = insertvalue { <8 x ptr>, <8 x i64> } %228, <8 x i64> %227, 1
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %229, 1
  %232 = extractelement <8 x ptr> %230, i32 0
  %233 = extractelement <8 x i64> %231, i32 0
  %234 = sub i64 %233, 0
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %236 = select i1 %235, i64 %234, i64 0
  %private.contiguous.address90 = getelementptr i8, ptr %232, i64 %236
  %private.contiguous.load91 = load <8 x float>, ptr %private.contiguous.address90, align 4
  %237 = select <8 x i1> %53, <8 x float> %private.contiguous.load91, <8 x float> zeroinitializer
  %238 = fadd <8 x float> %223, %237
  %239 = extractvalue { ptr, i64 } %29, 0
  %240 = mul <8 x i64> %135, splat (i64 4)
  %241 = getelementptr i8, ptr %239, <8 x i64> %240
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %238, <8 x ptr> %241, i32 1, <8 x i1> %53)
  %.state92 = load i64, ptr %.slot11, align 4
  %242 = add i64 %.state92, 1
  store i64 %242, ptr %.slot11, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false45
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true30:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false31:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true44:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false45:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }

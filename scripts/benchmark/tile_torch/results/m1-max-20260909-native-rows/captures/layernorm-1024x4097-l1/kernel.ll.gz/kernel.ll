; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 131104
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 262208
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 393312
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill13 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill13, align 4
  %.spill14 = alloca i64, align 8
  store i64 0, ptr %.spill14, align 4
  %.spill15 = alloca i64, align 8
  store i64 0, ptr %.spill15, align 4
  %.spill16 = alloca i64, align 8
  store i64 0, ptr %.spill16, align 4
  %.spill17 = alloca i64, align 8
  store i64 0, ptr %.spill17, align 4
  %.spill18 = alloca i64, align 8
  store i64 0, ptr %.spill18, align 4
  %.spill19 = alloca i64, align 8
  store i64 0, ptr %.spill19, align 4
  %.slot20 = alloca i64, align 8
  store i64 0, ptr %.slot20, align 4
  %.slot21 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.slot22 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot22, align 32
  %.slot23 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot23, align 32
  %.slot24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot24, align 32
  %.spill25 = alloca i64, align 8
  store i64 0, ptr %.spill25, align 4
  %.spill26 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill26, align 4
  %.spill27 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill27, align 32
  %tile_snapshot.spill28 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill28, align 64
  %.slot29 = alloca i64, align 8
  store i64 0, ptr %.slot29, align 4
  %.spill30 = alloca i64, align 8
  store i64 0, ptr %.spill30, align 4
  %.slot31 = alloca i64, align 8
  store i64 0, ptr %.slot31, align 4
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.spill36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill36, align 32
  %tile_snapshot.spill37 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill37, align 64
  %.slot38 = alloca i64, align 8
  store i64 0, ptr %.slot38, align 4
  %.spill39 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill39, align 32
  %tile_snapshot.spill40 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill40, align 64
  %.slot41 = alloca i64, align 8
  store i64 0, ptr %.slot41, align 4
  %.slot42 = alloca i64, align 8
  store i64 0, ptr %.slot42, align 4
  %12 = getelementptr i8, ptr %argument_buffer, i64 0
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 16
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 32
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 48
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = load i32, ptr %launch_config, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 12
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 4
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 16
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 8
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 20
  %46 = load i32, ptr %45, align 4
  %47 = getelementptr i8, ptr %launch_config, i64 36
  %48 = load i32, ptr %47, align 4
  %.splatinsert43 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat44 = shufflevector <8 x i32> %.splatinsert43, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat44, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %50 = mul i32 %36, 32
  %.splatinsert45 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat46 = shufflevector <8 x i32> %.splatinsert45, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat46, %49
  %52 = mul i32 %40, 1
  %.splatinsert47 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat48 = shufflevector <8 x i32> %.splatinsert47, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat48, zeroinitializer
  %54 = mul i32 %44, 1
  %.splatinsert49 = insertelement <8 x i32> poison, i32 %54, i64 0
  %.splat50 = shufflevector <8 x i32> %.splatinsert49, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = add <8 x i32> %.splat50, zeroinitializer
  %56 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %51, 0
  %57 = insertvalue [3 x <8 x i32>] %56, <8 x i32> %53, 1
  %58 = insertvalue [3 x <8 x i32>] %57, <8 x i32> %55, 2
  %.splatinsert51 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat52 = shufflevector <8 x i32> %.splatinsert51, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat52
  %60 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  br i1 %60, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %61 = extractvalue [3 x <8 x i32>] %58, 0
  %62 = zext <8 x i32> %61 to <8 x i64>
  %63 = select <8 x i1> %59, <8 x i64> %62, <8 x i64> zeroinitializer
  %64 = select <8 x i1> %59, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %65 = sdiv <8 x i64> %63, %64
  %66 = load <8 x i64>, ptr %.spill, align 64
  %67 = select <8 x i1> %59, <8 x i64> %65, <8 x i64> %66
  store <8 x i64> %67, ptr %.spill, align 64
  %68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %68, 0
  %71 = select <8 x i1> %59, <8 x ptr> %69, <8 x ptr> %70
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %68, 1
  %74 = select <8 x i1> %59, <8 x i64> %72, <8 x i64> %73
  %75 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %71, 0
  %76 = insertvalue { <8 x ptr>, <8 x i64> } %75, <8 x i64> %74, 1
  store { <8 x ptr>, <8 x i64> } %76, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %77 = icmp slt i64 %.state, 4097
  br i1 %77, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %78 = add <8 x i64> %.spill.load, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %.state53 = load i64, ptr %.slot, align 4
  %80 = add i64 0, %.state53
  %81 = mul <8 x i64> %79, splat (i64 4097)
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %82 = add <8 x i64> %81, %.splat55
  %83 = extractvalue { ptr, i64 } %17, 0
  %84 = mul <8 x i64> %82, splat (i64 4)
  %85 = getelementptr i8, ptr %83, <8 x i64> %84
  %86 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %85, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state56 = load i64, ptr %.slot, align 4
  %.splatinsert57 = insertelement <8 x i64> poison, i64 %.state56, i64 0
  %.splat58 = shufflevector <8 x i64> %.splatinsert57, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat58, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %59, <8 x float> %86, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state59 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state59, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill13, align 4
  store i64 0, ptr %.spill14, align 4
  store i64 0, ptr %.spill15, align 4
  store i64 0, ptr %.spill16, align 4
  %tile_snapshot.spill.load60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 1
  %104 = add <8 x i64> %103, zeroinitializer
  %105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %106 = insertvalue { <8 x ptr>, <8 x i64> } %105, <8 x i64> %104, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %106, 1
  %109 = extractelement <8 x ptr> %107, i32 0
  %110 = extractelement <8 x i64> %108, i32 0
  %111 = sub i64 %110, 0
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %113 = select i1 %112, i64 %111, i64 0
  %private.contiguous.address61 = getelementptr i8, ptr %109, i64 %113
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address61, align 4
  %114 = select <8 x i1> %59, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  store i64 1, ptr %.spill17, align 4
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %117 = add <8 x i64> %116, splat (i64 32)
  %118 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %119 = insertvalue { <8 x ptr>, <8 x i64> } %118, <8 x i64> %117, 1
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %119, 1
  %122 = extractelement <8 x ptr> %120, i32 0
  %123 = extractelement <8 x i64> %121, i32 0
  %124 = sub i64 %123, 0
  %125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %126 = select i1 %125, i64 %124, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %122, i64 %126
  %private.contiguous.load64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %127 = select <8 x i1> %59, <8 x float> %private.contiguous.load64, <8 x float> zeroinitializer
  store i64 2, ptr %.spill18, align 4
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %130 = add <8 x i64> %129, splat (i64 64)
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %128, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %135 = extractelement <8 x ptr> %133, i32 0
  %136 = extractelement <8 x i64> %134, i32 0
  %137 = sub i64 %136, 0
  %138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %139 = select i1 %138, i64 %137, i64 0
  %private.contiguous.address66 = getelementptr i8, ptr %135, i64 %139
  %private.contiguous.load67 = load <8 x float>, ptr %private.contiguous.address66, align 4
  %140 = select <8 x i1> %59, <8 x float> %private.contiguous.load67, <8 x float> zeroinitializer
  store i64 3, ptr %.spill19, align 4
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %143 = add <8 x i64> %142, splat (i64 96)
  %144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %141, 0
  %145 = insertvalue { <8 x ptr>, <8 x i64> } %144, <8 x i64> %143, 1
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %148 = extractelement <8 x ptr> %146, i32 0
  %149 = extractelement <8 x i64> %147, i32 0
  %150 = sub i64 %149, 0
  %151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %152 = select i1 %151, i64 %150, i64 0
  %private.contiguous.address69 = getelementptr i8, ptr %148, i64 %152
  %private.contiguous.load70 = load <8 x float>, ptr %private.contiguous.address69, align 4
  %153 = select <8 x i1> %59, <8 x float> %private.contiguous.load70, <8 x float> zeroinitializer
  store i64 4, ptr %.slot20, align 4
  %154 = load <8 x float>, ptr %.slot21, align 32
  %155 = select <8 x i1> %59, <8 x float> %114, <8 x float> %154
  store <8 x float> %155, ptr %.slot21, align 32
  %156 = load <8 x float>, ptr %.slot22, align 32
  %157 = select <8 x i1> %59, <8 x float> %127, <8 x float> %156
  store <8 x float> %157, ptr %.slot22, align 32
  %158 = load <8 x float>, ptr %.slot23, align 32
  %159 = select <8 x i1> %59, <8 x float> %140, <8 x float> %158
  store <8 x float> %159, ptr %.slot23, align 32
  %160 = load <8 x float>, ptr %.slot24, align 32
  %161 = select <8 x i1> %59, <8 x float> %153, <8 x float> %160
  store <8 x float> %161, ptr %.slot24, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state71 = load i64, ptr %.slot20, align 4
  %162 = icmp slt i64 %.state71, 4096
  br i1 %162, label %direct.true72, label %direct.false73

direct.schedule.5:                                ; preds = %direct.true72
  %.state74 = load i64, ptr %.slot20, align 4
  %163 = add i64 %.state74, 0
  %164 = sdiv i64 %163, 1
  %.spill.load75 = load i64, ptr %.spill15, align 4
  %165 = add i64 %.spill.load75, %164
  %tile_snapshot.spill.load76 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 1
  %.splatinsert77 = insertelement <8 x i64> poison, i64 %165, i64 0
  %.splat78 = shufflevector <8 x i64> %.splatinsert77, <8 x i64> poison, <8 x i32> zeroinitializer
  %168 = mul <8 x i64> %.splat78, splat (i64 32)
  %169 = add <8 x i64> %167, %168
  %170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %171 = insertvalue { <8 x ptr>, <8 x i64> } %170, <8 x i64> %169, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %174 = extractelement <8 x ptr> %172, i32 0
  %175 = extractelement <8 x i64> %173, i32 0
  %176 = sub i64 %175, 0
  %177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %178 = select i1 %177, i64 %176, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %174, i64 %178
  %private.contiguous.load80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %179 = select <8 x i1> %59, <8 x float> %private.contiguous.load80, <8 x float> zeroinitializer
  %.state81 = load <8 x float>, ptr %.slot21, align 32
  %180 = fadd <8 x float> %.state81, %179
  %.state82 = load i64, ptr %.slot20, align 4
  %181 = add i64 %.state82, 1
  %182 = sdiv i64 %181, 1
  %.spill.load83 = load i64, ptr %.spill15, align 4
  %183 = add i64 %.spill.load83, %182
  %tile_snapshot.spill.load84 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load84, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load84, 1
  %.splatinsert85 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat86 = shufflevector <8 x i64> %.splatinsert85, <8 x i64> poison, <8 x i32> zeroinitializer
  %186 = mul <8 x i64> %.splat86, splat (i64 32)
  %187 = add <8 x i64> %185, %186
  %188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %184, 0
  %189 = insertvalue { <8 x ptr>, <8 x i64> } %188, <8 x i64> %187, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %189, 1
  %192 = extractelement <8 x ptr> %190, i32 0
  %193 = extractelement <8 x i64> %191, i32 0
  %194 = sub i64 %193, 0
  %195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %196 = select i1 %195, i64 %194, i64 0
  %private.contiguous.address87 = getelementptr i8, ptr %192, i64 %196
  %private.contiguous.load88 = load <8 x float>, ptr %private.contiguous.address87, align 4
  %197 = select <8 x i1> %59, <8 x float> %private.contiguous.load88, <8 x float> zeroinitializer
  %.state89 = load <8 x float>, ptr %.slot22, align 32
  %198 = fadd <8 x float> %.state89, %197
  %.state90 = load i64, ptr %.slot20, align 4
  %199 = add i64 %.state90, 2
  %200 = sdiv i64 %199, 1
  %.spill.load91 = load i64, ptr %.spill15, align 4
  %201 = add i64 %.spill.load91, %200
  %tile_snapshot.spill.load92 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 1
  %.splatinsert93 = insertelement <8 x i64> poison, i64 %201, i64 0
  %.splat94 = shufflevector <8 x i64> %.splatinsert93, <8 x i64> poison, <8 x i32> zeroinitializer
  %204 = mul <8 x i64> %.splat94, splat (i64 32)
  %205 = add <8 x i64> %203, %204
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %202, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %207, 1
  %210 = extractelement <8 x ptr> %208, i32 0
  %211 = extractelement <8 x i64> %209, i32 0
  %212 = sub i64 %211, 0
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address95 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.load96 = load <8 x float>, ptr %private.contiguous.address95, align 4
  %215 = select <8 x i1> %59, <8 x float> %private.contiguous.load96, <8 x float> zeroinitializer
  %.state97 = load <8 x float>, ptr %.slot23, align 32
  %216 = fadd <8 x float> %.state97, %215
  %.state98 = load i64, ptr %.slot20, align 4
  %217 = add i64 %.state98, 3
  %218 = sdiv i64 %217, 1
  %.spill.load99 = load i64, ptr %.spill15, align 4
  %219 = add i64 %.spill.load99, %218
  %tile_snapshot.spill.load100 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 1
  %.splatinsert101 = insertelement <8 x i64> poison, i64 %219, i64 0
  %.splat102 = shufflevector <8 x i64> %.splatinsert101, <8 x i64> poison, <8 x i32> zeroinitializer
  %222 = mul <8 x i64> %.splat102, splat (i64 32)
  %223 = add <8 x i64> %221, %222
  %224 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %220, 0
  %225 = insertvalue { <8 x ptr>, <8 x i64> } %224, <8 x i64> %223, 1
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %225, 1
  %228 = extractelement <8 x ptr> %226, i32 0
  %229 = extractelement <8 x i64> %227, i32 0
  %230 = sub i64 %229, 0
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %232 = select i1 %231, i64 %230, i64 0
  %private.contiguous.address103 = getelementptr i8, ptr %228, i64 %232
  %private.contiguous.load104 = load <8 x float>, ptr %private.contiguous.address103, align 4
  %233 = select <8 x i1> %59, <8 x float> %private.contiguous.load104, <8 x float> zeroinitializer
  %.state105 = load <8 x float>, ptr %.slot24, align 32
  %234 = fadd <8 x float> %.state105, %233
  %.state106 = load i64, ptr %.slot20, align 4
  %235 = add i64 %.state106, 4
  store i64 %235, ptr %.slot20, align 4
  %236 = load <8 x float>, ptr %.slot21, align 32
  %237 = select <8 x i1> %59, <8 x float> %180, <8 x float> %236
  store <8 x float> %237, ptr %.slot21, align 32
  %238 = load <8 x float>, ptr %.slot22, align 32
  %239 = select <8 x i1> %59, <8 x float> %198, <8 x float> %238
  store <8 x float> %239, ptr %.slot22, align 32
  %240 = load <8 x float>, ptr %.slot23, align 32
  %241 = select <8 x i1> %59, <8 x float> %216, <8 x float> %240
  store <8 x float> %241, ptr %.slot23, align 32
  %242 = load <8 x float>, ptr %.slot24, align 32
  %243 = select <8 x i1> %59, <8 x float> %234, <8 x float> %242
  store <8 x float> %243, ptr %.slot24, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false73
  %.spill.load107 = load i64, ptr %.spill15, align 4
  %244 = add i64 %.spill.load107, 4096
  store i64 %244, ptr %.spill25, align 4
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %.splatinsert109 = insertelement <8 x i64> poison, i64 %244, i64 0
  %.splat110 = shufflevector <8 x i64> %.splatinsert109, <8 x i64> poison, <8 x i32> zeroinitializer
  %247 = mul <8 x i64> %.splat110, splat (i64 32)
  %248 = add <8 x i64> %246, %247
  %249 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %245, 0
  %250 = insertvalue { <8 x ptr>, <8 x i64> } %249, <8 x i64> %248, 1
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %250, 1
  %253 = extractelement <8 x ptr> %251, i32 0
  %254 = extractelement <8 x i64> %252, i32 0
  %255 = sub i64 %254, 0
  %256 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %257 = select i1 %256, i64 %255, i64 0
  %private.contiguous.address111 = getelementptr i8, ptr %253, i64 %257
  %private.contiguous.load112 = load <8 x float>, ptr %private.contiguous.address111, align 4
  %258 = select <8 x i1> %59, <8 x float> %private.contiguous.load112, <8 x float> zeroinitializer
  %.state113 = load <8 x float>, ptr %.slot21, align 32
  %259 = fadd <8 x float> %.state113, %258
  %.spill.load114 = load float, ptr %.spill13, align 4
  %.splatinsert115 = insertelement <8 x float> poison, float %.spill.load114, i64 0
  %.splat116 = shufflevector <8 x float> %.splatinsert115, <8 x float> poison, <8 x i32> zeroinitializer
  %260 = fadd <8 x float> %.splat116, %259
  %.state117 = load <8 x float>, ptr %.slot22, align 32
  %261 = fadd <8 x float> %260, %.state117
  %.state118 = load <8 x float>, ptr %.slot23, align 32
  %262 = fadd <8 x float> %261, %.state118
  %.state119 = load <8 x float>, ptr %.slot24, align 32
  %263 = fadd <8 x float> %262, %.state119
  store float 4.097000e+03, ptr %.spill26, align 4
  %264 = fdiv <8 x float> %263, splat (float 4.097000e+03)
  %265 = load <8 x float>, ptr %.spill27, align 32
  %266 = select <8 x i1> %59, <8 x float> %264, <8 x float> %265
  store <8 x float> %266, ptr %.spill27, align 32
  %267 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %267, 0
  %270 = select <8 x i1> %59, <8 x ptr> %268, <8 x ptr> %269
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %267, 1
  %273 = select <8 x i1> %59, <8 x i64> %271, <8 x i64> %272
  %274 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %270, 0
  %275 = insertvalue { <8 x ptr>, <8 x i64> } %274, <8 x i64> %273, 1
  store { <8 x ptr>, <8 x i64> } %275, ptr %tile_snapshot.spill28, align 64
  store i64 0, ptr %.slot29, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state120 = load i64, ptr %.slot29, align 4
  %276 = icmp slt i64 %.state120, 4097
  br i1 %276, label %direct.true121, label %direct.false122

direct.schedule.8:                                ; preds = %direct.true121
  %.state123 = load i64, ptr %.slot29, align 4
  %277 = add i64 0, %.state123
  %tile_snapshot.spill.load124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 0
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 1
  %.splatinsert125 = insertelement <8 x i64> poison, i64 %277, i64 0
  %.splat126 = shufflevector <8 x i64> %.splatinsert125, <8 x i64> poison, <8 x i32> zeroinitializer
  %280 = mul <8 x i64> %.splat126, splat (i64 32)
  %281 = add <8 x i64> %279, %280
  %282 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %278, 0
  %283 = insertvalue { <8 x ptr>, <8 x i64> } %282, <8 x i64> %281, 1
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %283, 1
  %286 = extractelement <8 x ptr> %284, i32 0
  %287 = extractelement <8 x i64> %285, i32 0
  %288 = sub i64 %287, 0
  %289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %290 = select i1 %289, i64 %288, i64 0
  %private.contiguous.address127 = getelementptr i8, ptr %286, i64 %290
  %private.contiguous.load128 = load <8 x float>, ptr %private.contiguous.address127, align 4
  %291 = select <8 x i1> %59, <8 x float> %private.contiguous.load128, <8 x float> zeroinitializer
  %.spill.load129 = load <8 x float>, ptr %.spill27, align 32
  %292 = fsub <8 x float> %291, %.spill.load129
  %tile_snapshot.spill.load130 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 1
  %.state131 = load i64, ptr %.slot29, align 4
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %.state131, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %295 = mul <8 x i64> %.splat133, splat (i64 32)
  %296 = add <8 x i64> %294, %295
  %297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %293, 0
  %298 = insertvalue { <8 x ptr>, <8 x i64> } %297, <8 x i64> %296, 1
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %298, 1
  %301 = extractelement <8 x ptr> %299, i32 0
  %302 = extractelement <8 x i64> %300, i32 0
  %303 = sub i64 %302, 0
  %304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %305 = select i1 %304, i64 %303, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %301, i64 %305
  %private.contiguous.preserve135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %306 = select <8 x i1> %59, <8 x float> %292, <8 x float> %private.contiguous.preserve135
  store <8 x float> %306, ptr %private.contiguous.address134, align 4
  %.state136 = load i64, ptr %.slot29, align 4
  %307 = add i64 %.state136, 1
  store i64 %307, ptr %.slot29, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false122
  store i64 0, ptr %.spill30, align 4
  %.spill.load137 = load i64, ptr %.spill16, align 4
  %308 = add i64 0, %.spill.load137
  %tile_snapshot.spill.load138 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 1
  %.splatinsert139 = insertelement <8 x i64> poison, i64 %308, i64 0
  %.splat140 = shufflevector <8 x i64> %.splatinsert139, <8 x i64> poison, <8 x i32> zeroinitializer
  %311 = mul <8 x i64> %.splat140, splat (i64 32)
  %312 = add <8 x i64> %310, %311
  %313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %309, 0
  %314 = insertvalue { <8 x ptr>, <8 x i64> } %313, <8 x i64> %312, 1
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %314, 1
  %317 = extractelement <8 x ptr> %315, i32 0
  %318 = extractelement <8 x i64> %316, i32 0
  %319 = sub i64 %318, 0
  %320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %321 = select i1 %320, i64 %319, i64 0
  %private.contiguous.address141 = getelementptr i8, ptr %317, i64 %321
  %private.contiguous.load142 = load <8 x float>, ptr %private.contiguous.address141, align 4
  %322 = select <8 x i1> %59, <8 x float> %private.contiguous.load142, <8 x float> zeroinitializer
  %323 = fmul <8 x float> %322, %322
  %.spill.load143 = load i64, ptr %.spill17, align 4
  %324 = add i64 0, %.spill.load143
  %tile_snapshot.spill.load144 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 1
  %.splatinsert145 = insertelement <8 x i64> poison, i64 %324, i64 0
  %.splat146 = shufflevector <8 x i64> %.splatinsert145, <8 x i64> poison, <8 x i32> zeroinitializer
  %327 = mul <8 x i64> %.splat146, splat (i64 32)
  %328 = add <8 x i64> %326, %327
  %329 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %325, 0
  %330 = insertvalue { <8 x ptr>, <8 x i64> } %329, <8 x i64> %328, 1
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %330, 1
  %333 = extractelement <8 x ptr> %331, i32 0
  %334 = extractelement <8 x i64> %332, i32 0
  %335 = sub i64 %334, 0
  %336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %337 = select i1 %336, i64 %335, i64 0
  %private.contiguous.address147 = getelementptr i8, ptr %333, i64 %337
  %private.contiguous.load148 = load <8 x float>, ptr %private.contiguous.address147, align 4
  %338 = select <8 x i1> %59, <8 x float> %private.contiguous.load148, <8 x float> zeroinitializer
  %339 = fmul <8 x float> %338, %338
  %.spill.load149 = load i64, ptr %.spill18, align 4
  %340 = add i64 0, %.spill.load149
  %tile_snapshot.spill.load150 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load150, 0
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load150, 1
  %.splatinsert151 = insertelement <8 x i64> poison, i64 %340, i64 0
  %.splat152 = shufflevector <8 x i64> %.splatinsert151, <8 x i64> poison, <8 x i32> zeroinitializer
  %343 = mul <8 x i64> %.splat152, splat (i64 32)
  %344 = add <8 x i64> %342, %343
  %345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %341, 0
  %346 = insertvalue { <8 x ptr>, <8 x i64> } %345, <8 x i64> %344, 1
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %346, 1
  %349 = extractelement <8 x ptr> %347, i32 0
  %350 = extractelement <8 x i64> %348, i32 0
  %351 = sub i64 %350, 0
  %352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %353 = select i1 %352, i64 %351, i64 0
  %private.contiguous.address153 = getelementptr i8, ptr %349, i64 %353
  %private.contiguous.load154 = load <8 x float>, ptr %private.contiguous.address153, align 4
  %354 = select <8 x i1> %59, <8 x float> %private.contiguous.load154, <8 x float> zeroinitializer
  %355 = fmul <8 x float> %354, %354
  %.spill.load155 = load i64, ptr %.spill19, align 4
  %356 = add i64 0, %.spill.load155
  %tile_snapshot.spill.load156 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 0
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 1
  %.splatinsert157 = insertelement <8 x i64> poison, i64 %356, i64 0
  %.splat158 = shufflevector <8 x i64> %.splatinsert157, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = mul <8 x i64> %.splat158, splat (i64 32)
  %360 = add <8 x i64> %358, %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = extractelement <8 x ptr> %363, i32 0
  %366 = extractelement <8 x i64> %364, i32 0
  %367 = sub i64 %366, 0
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %369 = select i1 %368, i64 %367, i64 0
  %private.contiguous.address159 = getelementptr i8, ptr %365, i64 %369
  %private.contiguous.load160 = load <8 x float>, ptr %private.contiguous.address159, align 4
  %370 = select <8 x i1> %59, <8 x float> %private.contiguous.load160, <8 x float> zeroinitializer
  %371 = fmul <8 x float> %370, %370
  store i64 4, ptr %.slot31, align 4
  %372 = load <8 x float>, ptr %.slot32, align 32
  %373 = select <8 x i1> %59, <8 x float> %323, <8 x float> %372
  store <8 x float> %373, ptr %.slot32, align 32
  %374 = load <8 x float>, ptr %.slot33, align 32
  %375 = select <8 x i1> %59, <8 x float> %339, <8 x float> %374
  store <8 x float> %375, ptr %.slot33, align 32
  %376 = load <8 x float>, ptr %.slot34, align 32
  %377 = select <8 x i1> %59, <8 x float> %355, <8 x float> %376
  store <8 x float> %377, ptr %.slot34, align 32
  %378 = load <8 x float>, ptr %.slot35, align 32
  %379 = select <8 x i1> %59, <8 x float> %371, <8 x float> %378
  store <8 x float> %379, ptr %.slot35, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state161 = load i64, ptr %.slot31, align 4
  %380 = icmp slt i64 %.state161, 4096
  br i1 %380, label %direct.true162, label %direct.false163

direct.schedule.11:                               ; preds = %direct.true162
  %.state164 = load i64, ptr %.slot31, align 4
  %381 = add i64 %.state164, 0
  %382 = sdiv i64 %381, 1
  %.spill.load165 = load i64, ptr %.spill15, align 4
  %383 = add i64 %.spill.load165, %382
  %.spill.load166 = load i64, ptr %.spill30, align 4
  %384 = add i64 %.spill.load166, %383
  %tile_snapshot.spill.load167 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 0
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 1
  %.splatinsert168 = insertelement <8 x i64> poison, i64 %384, i64 0
  %.splat169 = shufflevector <8 x i64> %.splatinsert168, <8 x i64> poison, <8 x i32> zeroinitializer
  %387 = mul <8 x i64> %.splat169, splat (i64 32)
  %388 = add <8 x i64> %386, %387
  %389 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %385, 0
  %390 = insertvalue { <8 x ptr>, <8 x i64> } %389, <8 x i64> %388, 1
  %391 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %390, 1
  %393 = extractelement <8 x ptr> %391, i32 0
  %394 = extractelement <8 x i64> %392, i32 0
  %395 = sub i64 %394, 0
  %396 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %397 = select i1 %396, i64 %395, i64 0
  %private.contiguous.address170 = getelementptr i8, ptr %393, i64 %397
  %private.contiguous.load171 = load <8 x float>, ptr %private.contiguous.address170, align 4
  %398 = select <8 x i1> %59, <8 x float> %private.contiguous.load171, <8 x float> zeroinitializer
  %399 = fmul <8 x float> %398, %398
  %.state172 = load <8 x float>, ptr %.slot32, align 32
  %400 = fadd <8 x float> %.state172, %399
  %.state173 = load i64, ptr %.slot31, align 4
  %401 = add i64 %.state173, 1
  %402 = sdiv i64 %401, 1
  %.spill.load174 = load i64, ptr %.spill15, align 4
  %403 = add i64 %.spill.load174, %402
  %.spill.load175 = load i64, ptr %.spill30, align 4
  %404 = add i64 %.spill.load175, %403
  %tile_snapshot.spill.load176 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 0
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 1
  %.splatinsert177 = insertelement <8 x i64> poison, i64 %404, i64 0
  %.splat178 = shufflevector <8 x i64> %.splatinsert177, <8 x i64> poison, <8 x i32> zeroinitializer
  %407 = mul <8 x i64> %.splat178, splat (i64 32)
  %408 = add <8 x i64> %406, %407
  %409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %405, 0
  %410 = insertvalue { <8 x ptr>, <8 x i64> } %409, <8 x i64> %408, 1
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %410, 1
  %413 = extractelement <8 x ptr> %411, i32 0
  %414 = extractelement <8 x i64> %412, i32 0
  %415 = sub i64 %414, 0
  %416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %417 = select i1 %416, i64 %415, i64 0
  %private.contiguous.address179 = getelementptr i8, ptr %413, i64 %417
  %private.contiguous.load180 = load <8 x float>, ptr %private.contiguous.address179, align 4
  %418 = select <8 x i1> %59, <8 x float> %private.contiguous.load180, <8 x float> zeroinitializer
  %419 = fmul <8 x float> %418, %418
  %.state181 = load <8 x float>, ptr %.slot33, align 32
  %420 = fadd <8 x float> %.state181, %419
  %.state182 = load i64, ptr %.slot31, align 4
  %421 = add i64 %.state182, 2
  %422 = sdiv i64 %421, 1
  %.spill.load183 = load i64, ptr %.spill15, align 4
  %423 = add i64 %.spill.load183, %422
  %.spill.load184 = load i64, ptr %.spill30, align 4
  %424 = add i64 %.spill.load184, %423
  %tile_snapshot.spill.load185 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load185, 0
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load185, 1
  %.splatinsert186 = insertelement <8 x i64> poison, i64 %424, i64 0
  %.splat187 = shufflevector <8 x i64> %.splatinsert186, <8 x i64> poison, <8 x i32> zeroinitializer
  %427 = mul <8 x i64> %.splat187, splat (i64 32)
  %428 = add <8 x i64> %426, %427
  %429 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %425, 0
  %430 = insertvalue { <8 x ptr>, <8 x i64> } %429, <8 x i64> %428, 1
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %430, 1
  %433 = extractelement <8 x ptr> %431, i32 0
  %434 = extractelement <8 x i64> %432, i32 0
  %435 = sub i64 %434, 0
  %436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %437 = select i1 %436, i64 %435, i64 0
  %private.contiguous.address188 = getelementptr i8, ptr %433, i64 %437
  %private.contiguous.load189 = load <8 x float>, ptr %private.contiguous.address188, align 4
  %438 = select <8 x i1> %59, <8 x float> %private.contiguous.load189, <8 x float> zeroinitializer
  %439 = fmul <8 x float> %438, %438
  %.state190 = load <8 x float>, ptr %.slot34, align 32
  %440 = fadd <8 x float> %.state190, %439
  %.state191 = load i64, ptr %.slot31, align 4
  %441 = add i64 %.state191, 3
  %442 = sdiv i64 %441, 1
  %.spill.load192 = load i64, ptr %.spill15, align 4
  %443 = add i64 %.spill.load192, %442
  %.spill.load193 = load i64, ptr %.spill30, align 4
  %444 = add i64 %.spill.load193, %443
  %tile_snapshot.spill.load194 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 1
  %.splatinsert195 = insertelement <8 x i64> poison, i64 %444, i64 0
  %.splat196 = shufflevector <8 x i64> %.splatinsert195, <8 x i64> poison, <8 x i32> zeroinitializer
  %447 = mul <8 x i64> %.splat196, splat (i64 32)
  %448 = add <8 x i64> %446, %447
  %449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %445, 0
  %450 = insertvalue { <8 x ptr>, <8 x i64> } %449, <8 x i64> %448, 1
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %450, 1
  %453 = extractelement <8 x ptr> %451, i32 0
  %454 = extractelement <8 x i64> %452, i32 0
  %455 = sub i64 %454, 0
  %456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %457 = select i1 %456, i64 %455, i64 0
  %private.contiguous.address197 = getelementptr i8, ptr %453, i64 %457
  %private.contiguous.load198 = load <8 x float>, ptr %private.contiguous.address197, align 4
  %458 = select <8 x i1> %59, <8 x float> %private.contiguous.load198, <8 x float> zeroinitializer
  %459 = fmul <8 x float> %458, %458
  %.state199 = load <8 x float>, ptr %.slot35, align 32
  %460 = fadd <8 x float> %.state199, %459
  %.state200 = load i64, ptr %.slot31, align 4
  %461 = add i64 %.state200, 4
  store i64 %461, ptr %.slot31, align 4
  %462 = load <8 x float>, ptr %.slot32, align 32
  %463 = select <8 x i1> %59, <8 x float> %400, <8 x float> %462
  store <8 x float> %463, ptr %.slot32, align 32
  %464 = load <8 x float>, ptr %.slot33, align 32
  %465 = select <8 x i1> %59, <8 x float> %420, <8 x float> %464
  store <8 x float> %465, ptr %.slot33, align 32
  %466 = load <8 x float>, ptr %.slot34, align 32
  %467 = select <8 x i1> %59, <8 x float> %440, <8 x float> %466
  store <8 x float> %467, ptr %.slot34, align 32
  %468 = load <8 x float>, ptr %.slot35, align 32
  %469 = select <8 x i1> %59, <8 x float> %460, <8 x float> %468
  store <8 x float> %469, ptr %.slot35, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false163
  %.spill.load201 = load i64, ptr %.spill30, align 4
  %.spill.load202 = load i64, ptr %.spill25, align 4
  %470 = add i64 %.spill.load201, %.spill.load202
  %tile_snapshot.spill.load203 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load203, 0
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load203, 1
  %.splatinsert204 = insertelement <8 x i64> poison, i64 %470, i64 0
  %.splat205 = shufflevector <8 x i64> %.splatinsert204, <8 x i64> poison, <8 x i32> zeroinitializer
  %473 = mul <8 x i64> %.splat205, splat (i64 32)
  %474 = add <8 x i64> %472, %473
  %475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %471, 0
  %476 = insertvalue { <8 x ptr>, <8 x i64> } %475, <8 x i64> %474, 1
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %476, 1
  %479 = extractelement <8 x ptr> %477, i32 0
  %480 = extractelement <8 x i64> %478, i32 0
  %481 = sub i64 %480, 0
  %482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %483 = select i1 %482, i64 %481, i64 0
  %private.contiguous.address206 = getelementptr i8, ptr %479, i64 %483
  %private.contiguous.load207 = load <8 x float>, ptr %private.contiguous.address206, align 4
  %484 = select <8 x i1> %59, <8 x float> %private.contiguous.load207, <8 x float> zeroinitializer
  %485 = fmul <8 x float> %484, %484
  %.state208 = load <8 x float>, ptr %.slot32, align 32
  %486 = fadd <8 x float> %.state208, %485
  %.spill.load209 = load float, ptr %.spill13, align 4
  %.splatinsert210 = insertelement <8 x float> poison, float %.spill.load209, i64 0
  %.splat211 = shufflevector <8 x float> %.splatinsert210, <8 x float> poison, <8 x i32> zeroinitializer
  %487 = fadd <8 x float> %.splat211, %486
  %.state212 = load <8 x float>, ptr %.slot33, align 32
  %488 = fadd <8 x float> %487, %.state212
  %.state213 = load <8 x float>, ptr %.slot34, align 32
  %489 = fadd <8 x float> %488, %.state213
  %.state214 = load <8 x float>, ptr %.slot35, align 32
  %490 = fadd <8 x float> %489, %.state214
  %.spill.load215 = load float, ptr %.spill26, align 4
  %.splatinsert216 = insertelement <8 x float> poison, float %.spill.load215, i64 0
  %.splat217 = shufflevector <8 x float> %.splatinsert216, <8 x float> poison, <8 x i32> zeroinitializer
  %491 = fdiv <8 x float> %490, %.splat217
  %492 = load <8 x float>, ptr %.spill36, align 32
  %493 = select <8 x i1> %59, <8 x float> %491, <8 x float> %492
  store <8 x float> %493, ptr %.spill36, align 32
  %494 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %494, 0
  %497 = select <8 x i1> %59, <8 x ptr> %495, <8 x ptr> %496
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %494, 1
  %500 = select <8 x i1> %59, <8 x i64> %498, <8 x i64> %499
  %501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %497, 0
  %502 = insertvalue { <8 x ptr>, <8 x i64> } %501, <8 x i64> %500, 1
  store { <8 x ptr>, <8 x i64> } %502, ptr %tile_snapshot.spill37, align 64
  store i64 0, ptr %.slot38, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state218 = load i64, ptr %.slot38, align 4
  %503 = icmp slt i64 %.state218, 4097
  br i1 %503, label %direct.true219, label %direct.false220

direct.schedule.14:                               ; preds = %direct.true219
  %.spill.load221 = load i64, ptr %.spill14, align 4
  %504 = add i64 %.spill.load221, 0
  %.state222 = load i64, ptr %.slot38, align 4
  %505 = add i64 0, %.state222
  %506 = mul i64 %504, 4097
  %507 = add i64 %506, %505
  %508 = extractvalue { ptr, i64 } %23, 0
  %509 = mul i64 %507, 4
  %510 = getelementptr i8, ptr %508, i64 %509
  %511 = load float, ptr %510, align 4
  %.splatinsert223 = insertelement <8 x float> poison, float %511, i64 0
  %.splat224 = shufflevector <8 x float> %.splatinsert223, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 1
  %.state226 = load i64, ptr %.slot38, align 4
  %.splatinsert227 = insertelement <8 x i64> poison, i64 %.state226, i64 0
  %.splat228 = shufflevector <8 x i64> %.splatinsert227, <8 x i64> poison, <8 x i32> zeroinitializer
  %514 = mul <8 x i64> %.splat228, splat (i64 32)
  %515 = add <8 x i64> %513, %514
  %516 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %512, 0
  %517 = insertvalue { <8 x ptr>, <8 x i64> } %516, <8 x i64> %515, 1
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %519 = extractvalue { <8 x ptr>, <8 x i64> } %517, 1
  %520 = extractelement <8 x ptr> %518, i32 0
  %521 = extractelement <8 x i64> %519, i32 0
  %522 = sub i64 %521, 0
  %523 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %524 = select i1 %523, i64 %522, i64 0
  %private.contiguous.address229 = getelementptr i8, ptr %520, i64 %524
  %private.contiguous.preserve230 = load <8 x float>, ptr %private.contiguous.address229, align 4
  %525 = select <8 x i1> %59, <8 x float> %.splat224, <8 x float> %private.contiguous.preserve230
  store <8 x float> %525, ptr %private.contiguous.address229, align 4
  %.state231 = load i64, ptr %.slot38, align 4
  %526 = add i64 %.state231, 1
  store i64 %526, ptr %.slot38, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false220
  %.spill.load232 = load <8 x float>, ptr %.spill36, align 32
  %527 = fadd <8 x float> %.spill.load232, splat (float 0x3EE4F8B580000000)
  %528 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %527)
  %529 = load <8 x float>, ptr %.spill39, align 32
  %530 = select <8 x i1> %59, <8 x float> %528, <8 x float> %529
  store <8 x float> %530, ptr %.spill39, align 32
  %531 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %531, 0
  %534 = select <8 x i1> %59, <8 x ptr> %532, <8 x ptr> %533
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %531, 1
  %537 = select <8 x i1> %59, <8 x i64> %535, <8 x i64> %536
  %538 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %534, 0
  %539 = insertvalue { <8 x ptr>, <8 x i64> } %538, <8 x i64> %537, 1
  store { <8 x ptr>, <8 x i64> } %539, ptr %tile_snapshot.spill40, align 64
  store i64 0, ptr %.slot41, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state233 = load i64, ptr %.slot41, align 4
  %540 = icmp slt i64 %.state233, 4097
  br i1 %540, label %direct.true234, label %direct.false235

direct.schedule.17:                               ; preds = %direct.true234
  %.spill.load236 = load i64, ptr %.spill14, align 4
  %541 = add i64 %.spill.load236, 0
  %.state237 = load i64, ptr %.slot41, align 4
  %542 = add i64 0, %.state237
  %543 = mul i64 %541, 4097
  %544 = add i64 %543, %542
  %545 = extractvalue { ptr, i64 } %29, 0
  %546 = mul i64 %544, 4
  %547 = getelementptr i8, ptr %545, i64 %546
  %548 = load float, ptr %547, align 4
  %.splatinsert238 = insertelement <8 x float> poison, float %548, i64 0
  %.splat239 = shufflevector <8 x float> %.splatinsert238, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load240 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %549 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 0
  %550 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 1
  %.state241 = load i64, ptr %.slot41, align 4
  %.splatinsert242 = insertelement <8 x i64> poison, i64 %.state241, i64 0
  %.splat243 = shufflevector <8 x i64> %.splatinsert242, <8 x i64> poison, <8 x i32> zeroinitializer
  %551 = mul <8 x i64> %.splat243, splat (i64 32)
  %552 = add <8 x i64> %550, %551
  %553 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %549, 0
  %554 = insertvalue { <8 x ptr>, <8 x i64> } %553, <8 x i64> %552, 1
  %555 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %554, 1
  %557 = extractelement <8 x ptr> %555, i32 0
  %558 = extractelement <8 x i64> %556, i32 0
  %559 = sub i64 %558, 0
  %560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %561 = select i1 %560, i64 %559, i64 0
  %private.contiguous.address244 = getelementptr i8, ptr %557, i64 %561
  %private.contiguous.preserve245 = load <8 x float>, ptr %private.contiguous.address244, align 4
  %562 = select <8 x i1> %59, <8 x float> %.splat239, <8 x float> %private.contiguous.preserve245
  store <8 x float> %562, ptr %private.contiguous.address244, align 4
  %.state246 = load i64, ptr %.slot41, align 4
  %563 = add i64 %.state246, 1
  store i64 %563, ptr %.slot41, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false235
  store i64 0, ptr %.slot42, align 4
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state247 = load i64, ptr %.slot42, align 4
  %564 = icmp slt i64 %.state247, 4097
  br i1 %564, label %direct.true248, label %direct.false249

direct.schedule.20:                               ; preds = %direct.true248
  %.spill.load250 = load <8 x i64>, ptr %.spill, align 64
  %565 = add <8 x i64> %.spill.load250, zeroinitializer
  %566 = add <8 x i64> zeroinitializer, %565
  %.state251 = load i64, ptr %.slot42, align 4
  %567 = add i64 0, %.state251
  %568 = mul <8 x i64> %566, splat (i64 4097)
  %.splatinsert252 = insertelement <8 x i64> poison, i64 %567, i64 0
  %.splat253 = shufflevector <8 x i64> %.splatinsert252, <8 x i64> poison, <8 x i32> zeroinitializer
  %569 = add <8 x i64> %568, %.splat253
  %.spill.load254 = load i64, ptr %.spill30, align 4
  %.state255 = load i64, ptr %.slot42, align 4
  %570 = add i64 %.spill.load254, %.state255
  %.spill.load256 = load i64, ptr %.spill30, align 4
  %571 = add i64 %.spill.load256, %570
  %.spill.load257 = load i64, ptr %.spill30, align 4
  %572 = add i64 %.spill.load257, %571
  %tile_snapshot.spill.load258 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load258, 0
  %574 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load258, 1
  %.splatinsert259 = insertelement <8 x i64> poison, i64 %572, i64 0
  %.splat260 = shufflevector <8 x i64> %.splatinsert259, <8 x i64> poison, <8 x i32> zeroinitializer
  %575 = mul <8 x i64> %.splat260, splat (i64 32)
  %576 = add <8 x i64> %574, %575
  %577 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %573, 0
  %578 = insertvalue { <8 x ptr>, <8 x i64> } %577, <8 x i64> %576, 1
  %579 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %578, 1
  %581 = extractelement <8 x ptr> %579, i32 0
  %582 = extractelement <8 x i64> %580, i32 0
  %583 = sub i64 %582, 0
  %584 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %585 = select i1 %584, i64 %583, i64 0
  %private.contiguous.address261 = getelementptr i8, ptr %581, i64 %585
  %private.contiguous.load262 = load <8 x float>, ptr %private.contiguous.address261, align 4
  %586 = select <8 x i1> %59, <8 x float> %private.contiguous.load262, <8 x float> zeroinitializer
  %.spill.load263 = load <8 x float>, ptr %.spill39, align 32
  %587 = fdiv <8 x float> %586, %.spill.load263
  %tile_snapshot.spill.load264 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 0
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 1
  %.splatinsert265 = insertelement <8 x i64> poison, i64 %571, i64 0
  %.splat266 = shufflevector <8 x i64> %.splatinsert265, <8 x i64> poison, <8 x i32> zeroinitializer
  %590 = mul <8 x i64> %.splat266, splat (i64 32)
  %591 = add <8 x i64> %589, %590
  %592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %588, 0
  %593 = insertvalue { <8 x ptr>, <8 x i64> } %592, <8 x i64> %591, 1
  %594 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %595 = extractvalue { <8 x ptr>, <8 x i64> } %593, 1
  %596 = extractelement <8 x ptr> %594, i32 0
  %597 = extractelement <8 x i64> %595, i32 0
  %598 = sub i64 %597, 0
  %599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %600 = select i1 %599, i64 %598, i64 0
  %private.contiguous.address267 = getelementptr i8, ptr %596, i64 %600
  %private.contiguous.load268 = load <8 x float>, ptr %private.contiguous.address267, align 4
  %601 = select <8 x i1> %59, <8 x float> %private.contiguous.load268, <8 x float> zeroinitializer
  %602 = fmul <8 x float> %587, %601
  %tile_snapshot.spill.load269 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %603 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load269, 0
  %604 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load269, 1
  %.splatinsert270 = insertelement <8 x i64> poison, i64 %570, i64 0
  %.splat271 = shufflevector <8 x i64> %.splatinsert270, <8 x i64> poison, <8 x i32> zeroinitializer
  %605 = mul <8 x i64> %.splat271, splat (i64 32)
  %606 = add <8 x i64> %604, %605
  %607 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %603, 0
  %608 = insertvalue { <8 x ptr>, <8 x i64> } %607, <8 x i64> %606, 1
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %610 = extractvalue { <8 x ptr>, <8 x i64> } %608, 1
  %611 = extractelement <8 x ptr> %609, i32 0
  %612 = extractelement <8 x i64> %610, i32 0
  %613 = sub i64 %612, 0
  %614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %615 = select i1 %614, i64 %613, i64 0
  %private.contiguous.address272 = getelementptr i8, ptr %611, i64 %615
  %private.contiguous.load273 = load <8 x float>, ptr %private.contiguous.address272, align 4
  %616 = select <8 x i1> %59, <8 x float> %private.contiguous.load273, <8 x float> zeroinitializer
  %617 = fadd <8 x float> %602, %616
  %618 = extractvalue { ptr, i64 } %35, 0
  %619 = mul <8 x i64> %569, splat (i64 4)
  %620 = getelementptr i8, ptr %618, <8 x i64> %619
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %617, <8 x ptr> %620, i32 1, <8 x i1> %59)
  %.state274 = load i64, ptr %.slot42, align 4
  %621 = add i64 %.state274, 1
  store i64 %621, ptr %.slot42, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false249
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true72:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false73:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true121:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false122:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true162:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false163:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true219:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false220:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true234:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false235:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true248:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false249:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 131104
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 262208
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 393312
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill13 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill13, align 4
  %.spill14 = alloca i64, align 8
  store i64 0, ptr %.spill14, align 4
  %.spill15 = alloca i64, align 8
  store i64 0, ptr %.spill15, align 4
  %.spill16 = alloca i64, align 8
  store i64 0, ptr %.spill16, align 4
  %.spill17 = alloca i64, align 8
  store i64 0, ptr %.spill17, align 4
  %.spill18 = alloca i64, align 8
  store i64 0, ptr %.spill18, align 4
  %.spill19 = alloca i64, align 8
  store i64 0, ptr %.spill19, align 4
  %.slot20 = alloca i64, align 8
  store i64 0, ptr %.slot20, align 4
  %.slot21 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.slot22 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot22, align 32
  %.slot23 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot23, align 32
  %.slot24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot24, align 32
  %.spill25 = alloca i64, align 8
  store i64 0, ptr %.spill25, align 4
  %.spill26 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill26, align 4
  %.spill27 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill27, align 32
  %tile_snapshot.spill28 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill28, align 64
  %.slot29 = alloca i64, align 8
  store i64 0, ptr %.slot29, align 4
  %.spill30 = alloca i64, align 8
  store i64 0, ptr %.spill30, align 4
  %.slot31 = alloca i64, align 8
  store i64 0, ptr %.slot31, align 4
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.spill36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill36, align 32
  %tile_snapshot.spill37 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill37, align 64
  %.slot38 = alloca i64, align 8
  store i64 0, ptr %.slot38, align 4
  %.spill39 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill39, align 32
  %tile_snapshot.spill40 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill40, align 64
  %.slot41 = alloca i64, align 8
  store i64 0, ptr %.slot41, align 4
  %.slot42 = alloca i64, align 8
  store i64 0, ptr %.slot42, align 4
  %12 = getelementptr i8, ptr %argument_buffer, i64 0
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 16
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 32
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 48
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = load i32, ptr %launch_config, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 12
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 4
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 16
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 8
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 20
  %46 = load i32, ptr %45, align 4
  %47 = getelementptr i8, ptr %launch_config, i64 36
  %48 = load i32, ptr %47, align 4
  %.splatinsert43 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat44 = shufflevector <8 x i32> %.splatinsert43, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat44, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %50 = mul i32 %36, 32
  %.splatinsert45 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat46 = shufflevector <8 x i32> %.splatinsert45, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat46, %49
  %52 = mul i32 %40, 1
  %.splatinsert47 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat48 = shufflevector <8 x i32> %.splatinsert47, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat48, zeroinitializer
  %54 = mul i32 %44, 1
  %.splatinsert49 = insertelement <8 x i32> poison, i32 %54, i64 0
  %.splat50 = shufflevector <8 x i32> %.splatinsert49, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = add <8 x i32> %.splat50, zeroinitializer
  %56 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %51, 0
  %57 = insertvalue [3 x <8 x i32>] %56, <8 x i32> %53, 1
  %58 = insertvalue [3 x <8 x i32>] %57, <8 x i32> %55, 2
  %.splatinsert51 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat52 = shufflevector <8 x i32> %.splatinsert51, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat52
  %60 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  br i1 %60, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %61 = extractvalue [3 x <8 x i32>] %58, 0
  %62 = zext <8 x i32> %61 to <8 x i64>
  %63 = select <8 x i1> %59, <8 x i64> %62, <8 x i64> zeroinitializer
  %64 = select <8 x i1> %59, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %65 = sdiv <8 x i64> %63, %64
  %66 = load <8 x i64>, ptr %.spill, align 64
  %67 = select <8 x i1> %59, <8 x i64> %65, <8 x i64> %66
  store <8 x i64> %67, ptr %.spill, align 64
  %68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %68, 0
  %71 = select <8 x i1> %59, <8 x ptr> %69, <8 x ptr> %70
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %68, 1
  %74 = select <8 x i1> %59, <8 x i64> %72, <8 x i64> %73
  %75 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %71, 0
  %76 = insertvalue { <8 x ptr>, <8 x i64> } %75, <8 x i64> %74, 1
  store { <8 x ptr>, <8 x i64> } %76, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %77 = icmp slt i64 %.state, 4097
  br i1 %77, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %78 = add <8 x i64> %.spill.load, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %.state53 = load i64, ptr %.slot, align 4
  %80 = add i64 0, %.state53
  %81 = mul <8 x i64> %79, splat (i64 4097)
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %82 = add <8 x i64> %81, %.splat55
  %83 = extractvalue { ptr, i64 } %17, 0
  %84 = mul <8 x i64> %82, splat (i64 4)
  %85 = getelementptr i8, ptr %83, <8 x i64> %84
  %86 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %85, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state56 = load i64, ptr %.slot, align 4
  %.splatinsert57 = insertelement <8 x i64> poison, i64 %.state56, i64 0
  %.splat58 = shufflevector <8 x i64> %.splatinsert57, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat58, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %59, <8 x float> %86, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state59 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state59, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill13, align 4
  store i64 0, ptr %.spill14, align 4
  store i64 0, ptr %.spill15, align 4
  store i64 0, ptr %.spill16, align 4
  %tile_snapshot.spill.load60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 1
  %104 = add <8 x i64> %103, zeroinitializer
  %105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %106 = insertvalue { <8 x ptr>, <8 x i64> } %105, <8 x i64> %104, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %106, 1
  %109 = extractelement <8 x ptr> %107, i32 0
  %110 = extractelement <8 x i64> %108, i32 0
  %111 = sub i64 %110, 0
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %113 = select i1 %112, i64 %111, i64 0
  %private.contiguous.address61 = getelementptr i8, ptr %109, i64 %113
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address61, align 4
  %114 = select <8 x i1> %59, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  store i64 1, ptr %.spill17, align 4
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %117 = add <8 x i64> %116, splat (i64 32)
  %118 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %119 = insertvalue { <8 x ptr>, <8 x i64> } %118, <8 x i64> %117, 1
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %119, 1
  %122 = extractelement <8 x ptr> %120, i32 0
  %123 = extractelement <8 x i64> %121, i32 0
  %124 = sub i64 %123, 0
  %125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %126 = select i1 %125, i64 %124, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %122, i64 %126
  %private.contiguous.load64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %127 = select <8 x i1> %59, <8 x float> %private.contiguous.load64, <8 x float> zeroinitializer
  store i64 2, ptr %.spill18, align 4
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %130 = add <8 x i64> %129, splat (i64 64)
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %128, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %135 = extractelement <8 x ptr> %133, i32 0
  %136 = extractelement <8 x i64> %134, i32 0
  %137 = sub i64 %136, 0
  %138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %139 = select i1 %138, i64 %137, i64 0
  %private.contiguous.address66 = getelementptr i8, ptr %135, i64 %139
  %private.contiguous.load67 = load <8 x float>, ptr %private.contiguous.address66, align 4
  %140 = select <8 x i1> %59, <8 x float> %private.contiguous.load67, <8 x float> zeroinitializer
  store i64 3, ptr %.spill19, align 4
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %143 = add <8 x i64> %142, splat (i64 96)
  %144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %141, 0
  %145 = insertvalue { <8 x ptr>, <8 x i64> } %144, <8 x i64> %143, 1
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %148 = extractelement <8 x ptr> %146, i32 0
  %149 = extractelement <8 x i64> %147, i32 0
  %150 = sub i64 %149, 0
  %151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %152 = select i1 %151, i64 %150, i64 0
  %private.contiguous.address69 = getelementptr i8, ptr %148, i64 %152
  %private.contiguous.load70 = load <8 x float>, ptr %private.contiguous.address69, align 4
  %153 = select <8 x i1> %59, <8 x float> %private.contiguous.load70, <8 x float> zeroinitializer
  store i64 4, ptr %.slot20, align 4
  %154 = load <8 x float>, ptr %.slot21, align 32
  %155 = select <8 x i1> %59, <8 x float> %114, <8 x float> %154
  store <8 x float> %155, ptr %.slot21, align 32
  %156 = load <8 x float>, ptr %.slot22, align 32
  %157 = select <8 x i1> %59, <8 x float> %127, <8 x float> %156
  store <8 x float> %157, ptr %.slot22, align 32
  %158 = load <8 x float>, ptr %.slot23, align 32
  %159 = select <8 x i1> %59, <8 x float> %140, <8 x float> %158
  store <8 x float> %159, ptr %.slot23, align 32
  %160 = load <8 x float>, ptr %.slot24, align 32
  %161 = select <8 x i1> %59, <8 x float> %153, <8 x float> %160
  store <8 x float> %161, ptr %.slot24, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state71 = load i64, ptr %.slot20, align 4
  %162 = icmp slt i64 %.state71, 4096
  br i1 %162, label %direct.true72, label %direct.false73

direct.schedule.5:                                ; preds = %direct.true72
  %.state74 = load i64, ptr %.slot20, align 4
  %163 = add i64 %.state74, 0
  %164 = sdiv i64 %163, 1
  %.spill.load75 = load i64, ptr %.spill15, align 4
  %165 = add i64 %.spill.load75, %164
  %tile_snapshot.spill.load76 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 1
  %.splatinsert77 = insertelement <8 x i64> poison, i64 %165, i64 0
  %.splat78 = shufflevector <8 x i64> %.splatinsert77, <8 x i64> poison, <8 x i32> zeroinitializer
  %168 = mul <8 x i64> %.splat78, splat (i64 32)
  %169 = add <8 x i64> %167, %168
  %170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %171 = insertvalue { <8 x ptr>, <8 x i64> } %170, <8 x i64> %169, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %174 = extractelement <8 x ptr> %172, i32 0
  %175 = extractelement <8 x i64> %173, i32 0
  %176 = sub i64 %175, 0
  %177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %178 = select i1 %177, i64 %176, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %174, i64 %178
  %private.contiguous.load80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %179 = select <8 x i1> %59, <8 x float> %private.contiguous.load80, <8 x float> zeroinitializer
  %.state81 = load <8 x float>, ptr %.slot21, align 32
  %180 = fadd <8 x float> %.state81, %179
  %.state82 = load i64, ptr %.slot20, align 4
  %181 = add i64 %.state82, 1
  %182 = sdiv i64 %181, 1
  %.spill.load83 = load i64, ptr %.spill15, align 4
  %183 = add i64 %.spill.load83, %182
  %tile_snapshot.spill.load84 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load84, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load84, 1
  %.splatinsert85 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat86 = shufflevector <8 x i64> %.splatinsert85, <8 x i64> poison, <8 x i32> zeroinitializer
  %186 = mul <8 x i64> %.splat86, splat (i64 32)
  %187 = add <8 x i64> %185, %186
  %188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %184, 0
  %189 = insertvalue { <8 x ptr>, <8 x i64> } %188, <8 x i64> %187, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %189, 1
  %192 = extractelement <8 x ptr> %190, i32 0
  %193 = extractelement <8 x i64> %191, i32 0
  %194 = sub i64 %193, 0
  %195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %196 = select i1 %195, i64 %194, i64 0
  %private.contiguous.address87 = getelementptr i8, ptr %192, i64 %196
  %private.contiguous.load88 = load <8 x float>, ptr %private.contiguous.address87, align 4
  %197 = select <8 x i1> %59, <8 x float> %private.contiguous.load88, <8 x float> zeroinitializer
  %.state89 = load <8 x float>, ptr %.slot22, align 32
  %198 = fadd <8 x float> %.state89, %197
  %.state90 = load i64, ptr %.slot20, align 4
  %199 = add i64 %.state90, 2
  %200 = sdiv i64 %199, 1
  %.spill.load91 = load i64, ptr %.spill15, align 4
  %201 = add i64 %.spill.load91, %200
  %tile_snapshot.spill.load92 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 1
  %.splatinsert93 = insertelement <8 x i64> poison, i64 %201, i64 0
  %.splat94 = shufflevector <8 x i64> %.splatinsert93, <8 x i64> poison, <8 x i32> zeroinitializer
  %204 = mul <8 x i64> %.splat94, splat (i64 32)
  %205 = add <8 x i64> %203, %204
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %202, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %207, 1
  %210 = extractelement <8 x ptr> %208, i32 0
  %211 = extractelement <8 x i64> %209, i32 0
  %212 = sub i64 %211, 0
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address95 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.load96 = load <8 x float>, ptr %private.contiguous.address95, align 4
  %215 = select <8 x i1> %59, <8 x float> %private.contiguous.load96, <8 x float> zeroinitializer
  %.state97 = load <8 x float>, ptr %.slot23, align 32
  %216 = fadd <8 x float> %.state97, %215
  %.state98 = load i64, ptr %.slot20, align 4
  %217 = add i64 %.state98, 3
  %218 = sdiv i64 %217, 1
  %.spill.load99 = load i64, ptr %.spill15, align 4
  %219 = add i64 %.spill.load99, %218
  %tile_snapshot.spill.load100 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 1
  %.splatinsert101 = insertelement <8 x i64> poison, i64 %219, i64 0
  %.splat102 = shufflevector <8 x i64> %.splatinsert101, <8 x i64> poison, <8 x i32> zeroinitializer
  %222 = mul <8 x i64> %.splat102, splat (i64 32)
  %223 = add <8 x i64> %221, %222
  %224 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %220, 0
  %225 = insertvalue { <8 x ptr>, <8 x i64> } %224, <8 x i64> %223, 1
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %225, 1
  %228 = extractelement <8 x ptr> %226, i32 0
  %229 = extractelement <8 x i64> %227, i32 0
  %230 = sub i64 %229, 0
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %232 = select i1 %231, i64 %230, i64 0
  %private.contiguous.address103 = getelementptr i8, ptr %228, i64 %232
  %private.contiguous.load104 = load <8 x float>, ptr %private.contiguous.address103, align 4
  %233 = select <8 x i1> %59, <8 x float> %private.contiguous.load104, <8 x float> zeroinitializer
  %.state105 = load <8 x float>, ptr %.slot24, align 32
  %234 = fadd <8 x float> %.state105, %233
  %.state106 = load i64, ptr %.slot20, align 4
  %235 = add i64 %.state106, 4
  store i64 %235, ptr %.slot20, align 4
  %236 = load <8 x float>, ptr %.slot21, align 32
  %237 = select <8 x i1> %59, <8 x float> %180, <8 x float> %236
  store <8 x float> %237, ptr %.slot21, align 32
  %238 = load <8 x float>, ptr %.slot22, align 32
  %239 = select <8 x i1> %59, <8 x float> %198, <8 x float> %238
  store <8 x float> %239, ptr %.slot22, align 32
  %240 = load <8 x float>, ptr %.slot23, align 32
  %241 = select <8 x i1> %59, <8 x float> %216, <8 x float> %240
  store <8 x float> %241, ptr %.slot23, align 32
  %242 = load <8 x float>, ptr %.slot24, align 32
  %243 = select <8 x i1> %59, <8 x float> %234, <8 x float> %242
  store <8 x float> %243, ptr %.slot24, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false73
  %.spill.load107 = load i64, ptr %.spill15, align 4
  %244 = add i64 %.spill.load107, 4096
  store i64 %244, ptr %.spill25, align 4
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %.splatinsert109 = insertelement <8 x i64> poison, i64 %244, i64 0
  %.splat110 = shufflevector <8 x i64> %.splatinsert109, <8 x i64> poison, <8 x i32> zeroinitializer
  %247 = mul <8 x i64> %.splat110, splat (i64 32)
  %248 = add <8 x i64> %246, %247
  %249 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %245, 0
  %250 = insertvalue { <8 x ptr>, <8 x i64> } %249, <8 x i64> %248, 1
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %250, 1
  %253 = extractelement <8 x ptr> %251, i32 0
  %254 = extractelement <8 x i64> %252, i32 0
  %255 = sub i64 %254, 0
  %256 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %257 = select i1 %256, i64 %255, i64 0
  %private.contiguous.address111 = getelementptr i8, ptr %253, i64 %257
  %private.contiguous.load112 = load <8 x float>, ptr %private.contiguous.address111, align 4
  %258 = select <8 x i1> %59, <8 x float> %private.contiguous.load112, <8 x float> zeroinitializer
  %.state113 = load <8 x float>, ptr %.slot21, align 32
  %259 = fadd <8 x float> %.state113, %258
  %.spill.load114 = load float, ptr %.spill13, align 4
  %.splatinsert115 = insertelement <8 x float> poison, float %.spill.load114, i64 0
  %.splat116 = shufflevector <8 x float> %.splatinsert115, <8 x float> poison, <8 x i32> zeroinitializer
  %260 = fadd <8 x float> %.splat116, %259
  %.state117 = load <8 x float>, ptr %.slot22, align 32
  %261 = fadd <8 x float> %260, %.state117
  %.state118 = load <8 x float>, ptr %.slot23, align 32
  %262 = fadd <8 x float> %261, %.state118
  %.state119 = load <8 x float>, ptr %.slot24, align 32
  %263 = fadd <8 x float> %262, %.state119
  store float 4.097000e+03, ptr %.spill26, align 4
  %264 = fdiv <8 x float> %263, splat (float 4.097000e+03)
  %265 = load <8 x float>, ptr %.spill27, align 32
  %266 = select <8 x i1> %59, <8 x float> %264, <8 x float> %265
  store <8 x float> %266, ptr %.spill27, align 32
  %267 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %267, 0
  %270 = select <8 x i1> %59, <8 x ptr> %268, <8 x ptr> %269
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %267, 1
  %273 = select <8 x i1> %59, <8 x i64> %271, <8 x i64> %272
  %274 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %270, 0
  %275 = insertvalue { <8 x ptr>, <8 x i64> } %274, <8 x i64> %273, 1
  store { <8 x ptr>, <8 x i64> } %275, ptr %tile_snapshot.spill28, align 64
  store i64 0, ptr %.slot29, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state120 = load i64, ptr %.slot29, align 4
  %276 = icmp slt i64 %.state120, 4097
  br i1 %276, label %direct.true121, label %direct.false122

direct.schedule.8:                                ; preds = %direct.true121
  %.state123 = load i64, ptr %.slot29, align 4
  %277 = add i64 0, %.state123
  %tile_snapshot.spill.load124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 0
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 1
  %.splatinsert125 = insertelement <8 x i64> poison, i64 %277, i64 0
  %.splat126 = shufflevector <8 x i64> %.splatinsert125, <8 x i64> poison, <8 x i32> zeroinitializer
  %280 = mul <8 x i64> %.splat126, splat (i64 32)
  %281 = add <8 x i64> %279, %280
  %282 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %278, 0
  %283 = insertvalue { <8 x ptr>, <8 x i64> } %282, <8 x i64> %281, 1
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %283, 1
  %286 = extractelement <8 x ptr> %284, i32 0
  %287 = extractelement <8 x i64> %285, i32 0
  %288 = sub i64 %287, 0
  %289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %290 = select i1 %289, i64 %288, i64 0
  %private.contiguous.address127 = getelementptr i8, ptr %286, i64 %290
  %private.contiguous.load128 = load <8 x float>, ptr %private.contiguous.address127, align 4
  %291 = select <8 x i1> %59, <8 x float> %private.contiguous.load128, <8 x float> zeroinitializer
  %.spill.load129 = load <8 x float>, ptr %.spill27, align 32
  %292 = fsub <8 x float> %291, %.spill.load129
  %tile_snapshot.spill.load130 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 1
  %.state131 = load i64, ptr %.slot29, align 4
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %.state131, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %295 = mul <8 x i64> %.splat133, splat (i64 32)
  %296 = add <8 x i64> %294, %295
  %297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %293, 0
  %298 = insertvalue { <8 x ptr>, <8 x i64> } %297, <8 x i64> %296, 1
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %298, 1
  %301 = extractelement <8 x ptr> %299, i32 0
  %302 = extractelement <8 x i64> %300, i32 0
  %303 = sub i64 %302, 0
  %304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %305 = select i1 %304, i64 %303, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %301, i64 %305
  %private.contiguous.preserve135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %306 = select <8 x i1> %59, <8 x float> %292, <8 x float> %private.contiguous.preserve135
  store <8 x float> %306, ptr %private.contiguous.address134, align 4
  %.state136 = load i64, ptr %.slot29, align 4
  %307 = add i64 %.state136, 1
  store i64 %307, ptr %.slot29, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false122
  store i64 0, ptr %.spill30, align 4
  %.spill.load137 = load i64, ptr %.spill16, align 4
  %308 = add i64 0, %.spill.load137
  %tile_snapshot.spill.load138 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 1
  %.splatinsert139 = insertelement <8 x i64> poison, i64 %308, i64 0
  %.splat140 = shufflevector <8 x i64> %.splatinsert139, <8 x i64> poison, <8 x i32> zeroinitializer
  %311 = mul <8 x i64> %.splat140, splat (i64 32)
  %312 = add <8 x i64> %310, %311
  %313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %309, 0
  %314 = insertvalue { <8 x ptr>, <8 x i64> } %313, <8 x i64> %312, 1
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %314, 1
  %317 = extractelement <8 x ptr> %315, i32 0
  %318 = extractelement <8 x i64> %316, i32 0
  %319 = sub i64 %318, 0
  %320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %321 = select i1 %320, i64 %319, i64 0
  %private.contiguous.address141 = getelementptr i8, ptr %317, i64 %321
  %private.contiguous.load142 = load <8 x float>, ptr %private.contiguous.address141, align 4
  %322 = select <8 x i1> %59, <8 x float> %private.contiguous.load142, <8 x float> zeroinitializer
  %323 = fmul <8 x float> %322, %322
  %.spill.load143 = load i64, ptr %.spill17, align 4
  %324 = add i64 0, %.spill.load143
  %tile_snapshot.spill.load144 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 1
  %.splatinsert145 = insertelement <8 x i64> poison, i64 %324, i64 0
  %.splat146 = shufflevector <8 x i64> %.splatinsert145, <8 x i64> poison, <8 x i32> zeroinitializer
  %327 = mul <8 x i64> %.splat146, splat (i64 32)
  %328 = add <8 x i64> %326, %327
  %329 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %325, 0
  %330 = insertvalue { <8 x ptr>, <8 x i64> } %329, <8 x i64> %328, 1
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %330, 1
  %333 = extractelement <8 x ptr> %331, i32 0
  %334 = extractelement <8 x i64> %332, i32 0
  %335 = sub i64 %334, 0
  %336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %337 = select i1 %336, i64 %335, i64 0
  %private.contiguous.address147 = getelementptr i8, ptr %333, i64 %337
  %private.contiguous.load148 = load <8 x float>, ptr %private.contiguous.address147, align 4
  %338 = select <8 x i1> %59, <8 x float> %private.contiguous.load148, <8 x float> zeroinitializer
  %339 = fmul <8 x float> %338, %338
  %.spill.load149 = load i64, ptr %.spill18, align 4
  %340 = add i64 0, %.spill.load149
  %tile_snapshot.spill.load150 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load150, 0
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load150, 1
  %.splatinsert151 = insertelement <8 x i64> poison, i64 %340, i64 0
  %.splat152 = shufflevector <8 x i64> %.splatinsert151, <8 x i64> poison, <8 x i32> zeroinitializer
  %343 = mul <8 x i64> %.splat152, splat (i64 32)
  %344 = add <8 x i64> %342, %343
  %345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %341, 0
  %346 = insertvalue { <8 x ptr>, <8 x i64> } %345, <8 x i64> %344, 1
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %346, 1
  %349 = extractelement <8 x ptr> %347, i32 0
  %350 = extractelement <8 x i64> %348, i32 0
  %351 = sub i64 %350, 0
  %352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %353 = select i1 %352, i64 %351, i64 0
  %private.contiguous.address153 = getelementptr i8, ptr %349, i64 %353
  %private.contiguous.load154 = load <8 x float>, ptr %private.contiguous.address153, align 4
  %354 = select <8 x i1> %59, <8 x float> %private.contiguous.load154, <8 x float> zeroinitializer
  %355 = fmul <8 x float> %354, %354
  %.spill.load155 = load i64, ptr %.spill19, align 4
  %356 = add i64 0, %.spill.load155
  %tile_snapshot.spill.load156 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 0
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 1
  %.splatinsert157 = insertelement <8 x i64> poison, i64 %356, i64 0
  %.splat158 = shufflevector <8 x i64> %.splatinsert157, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = mul <8 x i64> %.splat158, splat (i64 32)
  %360 = add <8 x i64> %358, %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = extractelement <8 x ptr> %363, i32 0
  %366 = extractelement <8 x i64> %364, i32 0
  %367 = sub i64 %366, 0
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %369 = select i1 %368, i64 %367, i64 0
  %private.contiguous.address159 = getelementptr i8, ptr %365, i64 %369
  %private.contiguous.load160 = load <8 x float>, ptr %private.contiguous.address159, align 4
  %370 = select <8 x i1> %59, <8 x float> %private.contiguous.load160, <8 x float> zeroinitializer
  %371 = fmul <8 x float> %370, %370
  store i64 4, ptr %.slot31, align 4
  %372 = load <8 x float>, ptr %.slot32, align 32
  %373 = select <8 x i1> %59, <8 x float> %323, <8 x float> %372
  store <8 x float> %373, ptr %.slot32, align 32
  %374 = load <8 x float>, ptr %.slot33, align 32
  %375 = select <8 x i1> %59, <8 x float> %339, <8 x float> %374
  store <8 x float> %375, ptr %.slot33, align 32
  %376 = load <8 x float>, ptr %.slot34, align 32
  %377 = select <8 x i1> %59, <8 x float> %355, <8 x float> %376
  store <8 x float> %377, ptr %.slot34, align 32
  %378 = load <8 x float>, ptr %.slot35, align 32
  %379 = select <8 x i1> %59, <8 x float> %371, <8 x float> %378
  store <8 x float> %379, ptr %.slot35, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state161 = load i64, ptr %.slot31, align 4
  %380 = icmp slt i64 %.state161, 4096
  br i1 %380, label %direct.true162, label %direct.false163

direct.schedule.11:                               ; preds = %direct.true162
  %.state164 = load i64, ptr %.slot31, align 4
  %381 = add i64 %.state164, 0
  %382 = sdiv i64 %381, 1
  %.spill.load165 = load i64, ptr %.spill15, align 4
  %383 = add i64 %.spill.load165, %382
  %.spill.load166 = load i64, ptr %.spill30, align 4
  %384 = add i64 %.spill.load166, %383
  %tile_snapshot.spill.load167 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 0
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 1
  %.splatinsert168 = insertelement <8 x i64> poison, i64 %384, i64 0
  %.splat169 = shufflevector <8 x i64> %.splatinsert168, <8 x i64> poison, <8 x i32> zeroinitializer
  %387 = mul <8 x i64> %.splat169, splat (i64 32)
  %388 = add <8 x i64> %386, %387
  %389 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %385, 0
  %390 = insertvalue { <8 x ptr>, <8 x i64> } %389, <8 x i64> %388, 1
  %391 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %390, 1
  %393 = extractelement <8 x ptr> %391, i32 0
  %394 = extractelement <8 x i64> %392, i32 0
  %395 = sub i64 %394, 0
  %396 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %397 = select i1 %396, i64 %395, i64 0
  %private.contiguous.address170 = getelementptr i8, ptr %393, i64 %397
  %private.contiguous.load171 = load <8 x float>, ptr %private.contiguous.address170, align 4
  %398 = select <8 x i1> %59, <8 x float> %private.contiguous.load171, <8 x float> zeroinitializer
  %399 = fmul <8 x float> %398, %398
  %.state172 = load <8 x float>, ptr %.slot32, align 32
  %400 = fadd <8 x float> %.state172, %399
  %.state173 = load i64, ptr %.slot31, align 4
  %401 = add i64 %.state173, 1
  %402 = sdiv i64 %401, 1
  %.spill.load174 = load i64, ptr %.spill15, align 4
  %403 = add i64 %.spill.load174, %402
  %.spill.load175 = load i64, ptr %.spill30, align 4
  %404 = add i64 %.spill.load175, %403
  %tile_snapshot.spill.load176 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 0
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 1
  %.splatinsert177 = insertelement <8 x i64> poison, i64 %404, i64 0
  %.splat178 = shufflevector <8 x i64> %.splatinsert177, <8 x i64> poison, <8 x i32> zeroinitializer
  %407 = mul <8 x i64> %.splat178, splat (i64 32)
  %408 = add <8 x i64> %406, %407
  %409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %405, 0
  %410 = insertvalue { <8 x ptr>, <8 x i64> } %409, <8 x i64> %408, 1
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %410, 1
  %413 = extractelement <8 x ptr> %411, i32 0
  %414 = extractelement <8 x i64> %412, i32 0
  %415 = sub i64 %414, 0
  %416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %417 = select i1 %416, i64 %415, i64 0
  %private.contiguous.address179 = getelementptr i8, ptr %413, i64 %417
  %private.contiguous.load180 = load <8 x float>, ptr %private.contiguous.address179, align 4
  %418 = select <8 x i1> %59, <8 x float> %private.contiguous.load180, <8 x float> zeroinitializer
  %419 = fmul <8 x float> %418, %418
  %.state181 = load <8 x float>, ptr %.slot33, align 32
  %420 = fadd <8 x float> %.state181, %419
  %.state182 = load i64, ptr %.slot31, align 4
  %421 = add i64 %.state182, 2
  %422 = sdiv i64 %421, 1
  %.spill.load183 = load i64, ptr %.spill15, align 4
  %423 = add i64 %.spill.load183, %422
  %.spill.load184 = load i64, ptr %.spill30, align 4
  %424 = add i64 %.spill.load184, %423
  %tile_snapshot.spill.load185 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load185, 0
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load185, 1
  %.splatinsert186 = insertelement <8 x i64> poison, i64 %424, i64 0
  %.splat187 = shufflevector <8 x i64> %.splatinsert186, <8 x i64> poison, <8 x i32> zeroinitializer
  %427 = mul <8 x i64> %.splat187, splat (i64 32)
  %428 = add <8 x i64> %426, %427
  %429 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %425, 0
  %430 = insertvalue { <8 x ptr>, <8 x i64> } %429, <8 x i64> %428, 1
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %430, 1
  %433 = extractelement <8 x ptr> %431, i32 0
  %434 = extractelement <8 x i64> %432, i32 0
  %435 = sub i64 %434, 0
  %436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %437 = select i1 %436, i64 %435, i64 0
  %private.contiguous.address188 = getelementptr i8, ptr %433, i64 %437
  %private.contiguous.load189 = load <8 x float>, ptr %private.contiguous.address188, align 4
  %438 = select <8 x i1> %59, <8 x float> %private.contiguous.load189, <8 x float> zeroinitializer
  %439 = fmul <8 x float> %438, %438
  %.state190 = load <8 x float>, ptr %.slot34, align 32
  %440 = fadd <8 x float> %.state190, %439
  %.state191 = load i64, ptr %.slot31, align 4
  %441 = add i64 %.state191, 3
  %442 = sdiv i64 %441, 1
  %.spill.load192 = load i64, ptr %.spill15, align 4
  %443 = add i64 %.spill.load192, %442
  %.spill.load193 = load i64, ptr %.spill30, align 4
  %444 = add i64 %.spill.load193, %443
  %tile_snapshot.spill.load194 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 1
  %.splatinsert195 = insertelement <8 x i64> poison, i64 %444, i64 0
  %.splat196 = shufflevector <8 x i64> %.splatinsert195, <8 x i64> poison, <8 x i32> zeroinitializer
  %447 = mul <8 x i64> %.splat196, splat (i64 32)
  %448 = add <8 x i64> %446, %447
  %449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %445, 0
  %450 = insertvalue { <8 x ptr>, <8 x i64> } %449, <8 x i64> %448, 1
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %450, 1
  %453 = extractelement <8 x ptr> %451, i32 0
  %454 = extractelement <8 x i64> %452, i32 0
  %455 = sub i64 %454, 0
  %456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %457 = select i1 %456, i64 %455, i64 0
  %private.contiguous.address197 = getelementptr i8, ptr %453, i64 %457
  %private.contiguous.load198 = load <8 x float>, ptr %private.contiguous.address197, align 4
  %458 = select <8 x i1> %59, <8 x float> %private.contiguous.load198, <8 x float> zeroinitializer
  %459 = fmul <8 x float> %458, %458
  %.state199 = load <8 x float>, ptr %.slot35, align 32
  %460 = fadd <8 x float> %.state199, %459
  %.state200 = load i64, ptr %.slot31, align 4
  %461 = add i64 %.state200, 4
  store i64 %461, ptr %.slot31, align 4
  %462 = load <8 x float>, ptr %.slot32, align 32
  %463 = select <8 x i1> %59, <8 x float> %400, <8 x float> %462
  store <8 x float> %463, ptr %.slot32, align 32
  %464 = load <8 x float>, ptr %.slot33, align 32
  %465 = select <8 x i1> %59, <8 x float> %420, <8 x float> %464
  store <8 x float> %465, ptr %.slot33, align 32
  %466 = load <8 x float>, ptr %.slot34, align 32
  %467 = select <8 x i1> %59, <8 x float> %440, <8 x float> %466
  store <8 x float> %467, ptr %.slot34, align 32
  %468 = load <8 x float>, ptr %.slot35, align 32
  %469 = select <8 x i1> %59, <8 x float> %460, <8 x float> %468
  store <8 x float> %469, ptr %.slot35, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false163
  %.spill.load201 = load i64, ptr %.spill30, align 4
  %.spill.load202 = load i64, ptr %.spill25, align 4
  %470 = add i64 %.spill.load201, %.spill.load202
  %tile_snapshot.spill.load203 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load203, 0
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load203, 1
  %.splatinsert204 = insertelement <8 x i64> poison, i64 %470, i64 0
  %.splat205 = shufflevector <8 x i64> %.splatinsert204, <8 x i64> poison, <8 x i32> zeroinitializer
  %473 = mul <8 x i64> %.splat205, splat (i64 32)
  %474 = add <8 x i64> %472, %473
  %475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %471, 0
  %476 = insertvalue { <8 x ptr>, <8 x i64> } %475, <8 x i64> %474, 1
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %476, 1
  %479 = extractelement <8 x ptr> %477, i32 0
  %480 = extractelement <8 x i64> %478, i32 0
  %481 = sub i64 %480, 0
  %482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %483 = select i1 %482, i64 %481, i64 0
  %private.contiguous.address206 = getelementptr i8, ptr %479, i64 %483
  %private.contiguous.load207 = load <8 x float>, ptr %private.contiguous.address206, align 4
  %484 = select <8 x i1> %59, <8 x float> %private.contiguous.load207, <8 x float> zeroinitializer
  %485 = fmul <8 x float> %484, %484
  %.state208 = load <8 x float>, ptr %.slot32, align 32
  %486 = fadd <8 x float> %.state208, %485
  %.spill.load209 = load float, ptr %.spill13, align 4
  %.splatinsert210 = insertelement <8 x float> poison, float %.spill.load209, i64 0
  %.splat211 = shufflevector <8 x float> %.splatinsert210, <8 x float> poison, <8 x i32> zeroinitializer
  %487 = fadd <8 x float> %.splat211, %486
  %.state212 = load <8 x float>, ptr %.slot33, align 32
  %488 = fadd <8 x float> %487, %.state212
  %.state213 = load <8 x float>, ptr %.slot34, align 32
  %489 = fadd <8 x float> %488, %.state213
  %.state214 = load <8 x float>, ptr %.slot35, align 32
  %490 = fadd <8 x float> %489, %.state214
  %.spill.load215 = load float, ptr %.spill26, align 4
  %.splatinsert216 = insertelement <8 x float> poison, float %.spill.load215, i64 0
  %.splat217 = shufflevector <8 x float> %.splatinsert216, <8 x float> poison, <8 x i32> zeroinitializer
  %491 = fdiv <8 x float> %490, %.splat217
  %492 = load <8 x float>, ptr %.spill36, align 32
  %493 = select <8 x i1> %59, <8 x float> %491, <8 x float> %492
  store <8 x float> %493, ptr %.spill36, align 32
  %494 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %494, 0
  %497 = select <8 x i1> %59, <8 x ptr> %495, <8 x ptr> %496
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %494, 1
  %500 = select <8 x i1> %59, <8 x i64> %498, <8 x i64> %499
  %501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %497, 0
  %502 = insertvalue { <8 x ptr>, <8 x i64> } %501, <8 x i64> %500, 1
  store { <8 x ptr>, <8 x i64> } %502, ptr %tile_snapshot.spill37, align 64
  store i64 0, ptr %.slot38, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state218 = load i64, ptr %.slot38, align 4
  %503 = icmp slt i64 %.state218, 4097
  br i1 %503, label %direct.true219, label %direct.false220

direct.schedule.14:                               ; preds = %direct.true219
  %.spill.load221 = load i64, ptr %.spill14, align 4
  %504 = add i64 %.spill.load221, 0
  %.state222 = load i64, ptr %.slot38, align 4
  %505 = add i64 0, %.state222
  %506 = mul i64 %504, 4097
  %507 = add i64 %506, %505
  %508 = extractvalue { ptr, i64 } %23, 0
  %509 = mul i64 %507, 4
  %510 = getelementptr i8, ptr %508, i64 %509
  %511 = load float, ptr %510, align 4
  %.splatinsert223 = insertelement <8 x float> poison, float %511, i64 0
  %.splat224 = shufflevector <8 x float> %.splatinsert223, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 1
  %.state226 = load i64, ptr %.slot38, align 4
  %.splatinsert227 = insertelement <8 x i64> poison, i64 %.state226, i64 0
  %.splat228 = shufflevector <8 x i64> %.splatinsert227, <8 x i64> poison, <8 x i32> zeroinitializer
  %514 = mul <8 x i64> %.splat228, splat (i64 32)
  %515 = add <8 x i64> %513, %514
  %516 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %512, 0
  %517 = insertvalue { <8 x ptr>, <8 x i64> } %516, <8 x i64> %515, 1
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %519 = extractvalue { <8 x ptr>, <8 x i64> } %517, 1
  %520 = extractelement <8 x ptr> %518, i32 0
  %521 = extractelement <8 x i64> %519, i32 0
  %522 = sub i64 %521, 0
  %523 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %524 = select i1 %523, i64 %522, i64 0
  %private.contiguous.address229 = getelementptr i8, ptr %520, i64 %524
  %private.contiguous.preserve230 = load <8 x float>, ptr %private.contiguous.address229, align 4
  %525 = select <8 x i1> %59, <8 x float> %.splat224, <8 x float> %private.contiguous.preserve230
  store <8 x float> %525, ptr %private.contiguous.address229, align 4
  %.state231 = load i64, ptr %.slot38, align 4
  %526 = add i64 %.state231, 1
  store i64 %526, ptr %.slot38, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false220
  %.spill.load232 = load <8 x float>, ptr %.spill36, align 32
  %527 = fadd <8 x float> %.spill.load232, splat (float 0x3EE4F8B580000000)
  %528 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %527)
  %529 = load <8 x float>, ptr %.spill39, align 32
  %530 = select <8 x i1> %59, <8 x float> %528, <8 x float> %529
  store <8 x float> %530, ptr %.spill39, align 32
  %531 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %531, 0
  %534 = select <8 x i1> %59, <8 x ptr> %532, <8 x ptr> %533
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %531, 1
  %537 = select <8 x i1> %59, <8 x i64> %535, <8 x i64> %536
  %538 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %534, 0
  %539 = insertvalue { <8 x ptr>, <8 x i64> } %538, <8 x i64> %537, 1
  store { <8 x ptr>, <8 x i64> } %539, ptr %tile_snapshot.spill40, align 64
  store i64 0, ptr %.slot41, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state233 = load i64, ptr %.slot41, align 4
  %540 = icmp slt i64 %.state233, 4097
  br i1 %540, label %direct.true234, label %direct.false235

direct.schedule.17:                               ; preds = %direct.true234
  %.spill.load236 = load i64, ptr %.spill14, align 4
  %541 = add i64 %.spill.load236, 0
  %.state237 = load i64, ptr %.slot41, align 4
  %542 = add i64 0, %.state237
  %543 = mul i64 %541, 4097
  %544 = add i64 %543, %542
  %545 = extractvalue { ptr, i64 } %29, 0
  %546 = mul i64 %544, 4
  %547 = getelementptr i8, ptr %545, i64 %546
  %548 = load float, ptr %547, align 4
  %.splatinsert238 = insertelement <8 x float> poison, float %548, i64 0
  %.splat239 = shufflevector <8 x float> %.splatinsert238, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load240 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %549 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 0
  %550 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 1
  %.state241 = load i64, ptr %.slot41, align 4
  %.splatinsert242 = insertelement <8 x i64> poison, i64 %.state241, i64 0
  %.splat243 = shufflevector <8 x i64> %.splatinsert242, <8 x i64> poison, <8 x i32> zeroinitializer
  %551 = mul <8 x i64> %.splat243, splat (i64 32)
  %552 = add <8 x i64> %550, %551
  %553 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %549, 0
  %554 = insertvalue { <8 x ptr>, <8 x i64> } %553, <8 x i64> %552, 1
  %555 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %554, 1
  %557 = extractelement <8 x ptr> %555, i32 0
  %558 = extractelement <8 x i64> %556, i32 0
  %559 = sub i64 %558, 0
  %560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %561 = select i1 %560, i64 %559, i64 0
  %private.contiguous.address244 = getelementptr i8, ptr %557, i64 %561
  %private.contiguous.preserve245 = load <8 x float>, ptr %private.contiguous.address244, align 4
  %562 = select <8 x i1> %59, <8 x float> %.splat239, <8 x float> %private.contiguous.preserve245
  store <8 x float> %562, ptr %private.contiguous.address244, align 4
  %.state246 = load i64, ptr %.slot41, align 4
  %563 = add i64 %.state246, 1
  store i64 %563, ptr %.slot41, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false235
  store i64 0, ptr %.slot42, align 4
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state247 = load i64, ptr %.slot42, align 4
  %564 = icmp slt i64 %.state247, 4097
  br i1 %564, label %direct.true248, label %direct.false249

direct.schedule.20:                               ; preds = %direct.true248
  %.spill.load250 = load <8 x i64>, ptr %.spill, align 64
  %565 = add <8 x i64> %.spill.load250, zeroinitializer
  %566 = add <8 x i64> zeroinitializer, %565
  %.state251 = load i64, ptr %.slot42, align 4
  %567 = add i64 0, %.state251
  %568 = mul <8 x i64> %566, splat (i64 4097)
  %.splatinsert252 = insertelement <8 x i64> poison, i64 %567, i64 0
  %.splat253 = shufflevector <8 x i64> %.splatinsert252, <8 x i64> poison, <8 x i32> zeroinitializer
  %569 = add <8 x i64> %568, %.splat253
  %.spill.load254 = load i64, ptr %.spill30, align 4
  %.state255 = load i64, ptr %.slot42, align 4
  %570 = add i64 %.spill.load254, %.state255
  %.spill.load256 = load i64, ptr %.spill30, align 4
  %571 = add i64 %.spill.load256, %570
  %.spill.load257 = load i64, ptr %.spill30, align 4
  %572 = add i64 %.spill.load257, %571
  %tile_snapshot.spill.load258 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill28, align 64
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load258, 0
  %574 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load258, 1
  %.splatinsert259 = insertelement <8 x i64> poison, i64 %572, i64 0
  %.splat260 = shufflevector <8 x i64> %.splatinsert259, <8 x i64> poison, <8 x i32> zeroinitializer
  %575 = mul <8 x i64> %.splat260, splat (i64 32)
  %576 = add <8 x i64> %574, %575
  %577 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %573, 0
  %578 = insertvalue { <8 x ptr>, <8 x i64> } %577, <8 x i64> %576, 1
  %579 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %578, 1
  %581 = extractelement <8 x ptr> %579, i32 0
  %582 = extractelement <8 x i64> %580, i32 0
  %583 = sub i64 %582, 0
  %584 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %585 = select i1 %584, i64 %583, i64 0
  %private.contiguous.address261 = getelementptr i8, ptr %581, i64 %585
  %private.contiguous.load262 = load <8 x float>, ptr %private.contiguous.address261, align 4
  %586 = select <8 x i1> %59, <8 x float> %private.contiguous.load262, <8 x float> zeroinitializer
  %.spill.load263 = load <8 x float>, ptr %.spill39, align 32
  %587 = fdiv <8 x float> %586, %.spill.load263
  %tile_snapshot.spill.load264 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 0
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 1
  %.splatinsert265 = insertelement <8 x i64> poison, i64 %571, i64 0
  %.splat266 = shufflevector <8 x i64> %.splatinsert265, <8 x i64> poison, <8 x i32> zeroinitializer
  %590 = mul <8 x i64> %.splat266, splat (i64 32)
  %591 = add <8 x i64> %589, %590
  %592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %588, 0
  %593 = insertvalue { <8 x ptr>, <8 x i64> } %592, <8 x i64> %591, 1
  %594 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %595 = extractvalue { <8 x ptr>, <8 x i64> } %593, 1
  %596 = extractelement <8 x ptr> %594, i32 0
  %597 = extractelement <8 x i64> %595, i32 0
  %598 = sub i64 %597, 0
  %599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %600 = select i1 %599, i64 %598, i64 0
  %private.contiguous.address267 = getelementptr i8, ptr %596, i64 %600
  %private.contiguous.load268 = load <8 x float>, ptr %private.contiguous.address267, align 4
  %601 = select <8 x i1> %59, <8 x float> %private.contiguous.load268, <8 x float> zeroinitializer
  %602 = fmul <8 x float> %587, %601
  %tile_snapshot.spill.load269 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %603 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load269, 0
  %604 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load269, 1
  %.splatinsert270 = insertelement <8 x i64> poison, i64 %570, i64 0
  %.splat271 = shufflevector <8 x i64> %.splatinsert270, <8 x i64> poison, <8 x i32> zeroinitializer
  %605 = mul <8 x i64> %.splat271, splat (i64 32)
  %606 = add <8 x i64> %604, %605
  %607 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %603, 0
  %608 = insertvalue { <8 x ptr>, <8 x i64> } %607, <8 x i64> %606, 1
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %610 = extractvalue { <8 x ptr>, <8 x i64> } %608, 1
  %611 = extractelement <8 x ptr> %609, i32 0
  %612 = extractelement <8 x i64> %610, i32 0
  %613 = sub i64 %612, 0
  %614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %615 = select i1 %614, i64 %613, i64 0
  %private.contiguous.address272 = getelementptr i8, ptr %611, i64 %615
  %private.contiguous.load273 = load <8 x float>, ptr %private.contiguous.address272, align 4
  %616 = select <8 x i1> %59, <8 x float> %private.contiguous.load273, <8 x float> zeroinitializer
  %617 = fadd <8 x float> %602, %616
  %618 = extractvalue { ptr, i64 } %35, 0
  %619 = mul <8 x i64> %569, splat (i64 4)
  %620 = getelementptr i8, ptr %618, <8 x i64> %619
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %617, <8 x ptr> %620, i32 1, <8 x i1> %59)
  %.state274 = load i64, ptr %.slot42, align 4
  %621 = add i64 %.state274, 1
  store i64 %621, ptr %.slot42, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false249
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true72:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false73:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true121:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false122:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true162:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false163:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true219:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false220:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true234:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false235:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true248:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false249:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

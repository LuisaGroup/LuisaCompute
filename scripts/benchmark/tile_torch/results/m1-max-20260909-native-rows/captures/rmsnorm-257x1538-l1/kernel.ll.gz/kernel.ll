; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 49216
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.spill8 = alloca i64, align 8
  store i64 0, ptr %.spill8, align 4
  %.slot9 = alloca i64, align 8
  store i64 0, ptr %.slot9, align 4
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.slot13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot13, align 32
  %.spill14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill14, align 32
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %.spill17 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill17, align 32
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %6 = getelementptr i8, ptr %argument_buffer, i64 0
  %7 = load ptr, ptr %6, align 16
  %8 = getelementptr i8, ptr %6, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { ptr, i64 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %9, 1
  %12 = getelementptr i8, ptr %argument_buffer, i64 16
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 32
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 48
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = load i32, ptr %launch_config, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 12
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 4
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 16
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 8
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 20
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 36
  %42 = load i32, ptr %41, align 4
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat20, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %44 = mul i32 %30, 32
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, %43
  %46 = mul i32 %34, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, zeroinitializer
  %48 = mul i32 %38, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat26, zeroinitializer
  %50 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %45, 0
  %51 = insertvalue [3 x <8 x i32>] %50, <8 x i32> %47, 1
  %52 = insertvalue [3 x <8 x i32>] %51, <8 x i32> %49, 2
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat28
  %54 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  br i1 %54, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %55 = extractvalue [3 x <8 x i32>] %52, 0
  %56 = zext <8 x i32> %55 to <8 x i64>
  %57 = select <8 x i1> %53, <8 x i64> %56, <8 x i64> zeroinitializer
  %58 = select <8 x i1> %53, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %59 = sdiv <8 x i64> %57, %58
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %53, <8 x i64> %59, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %63 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %62, 0
  %65 = select <8 x i1> %53, <8 x ptr> %63, <8 x ptr> %64
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %62, 1
  %68 = select <8 x i1> %53, <8 x i64> %66, <8 x i64> %67
  %69 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %65, 0
  %70 = insertvalue { <8 x ptr>, <8 x i64> } %69, <8 x i64> %68, 1
  store { <8 x ptr>, <8 x i64> } %70, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %71 = icmp slt i64 %.state, 1538
  br i1 %71, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %72 = add <8 x i64> %.spill.load, zeroinitializer
  %73 = add <8 x i64> zeroinitializer, %72
  %.state29 = load i64, ptr %.slot, align 4
  %74 = add i64 0, %.state29
  %75 = mul <8 x i64> %73, splat (i64 1538)
  %.splatinsert30 = insertelement <8 x i64> poison, i64 %74, i64 0
  %.splat31 = shufflevector <8 x i64> %.splatinsert30, <8 x i64> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i64> %75, %.splat31
  %77 = extractvalue { ptr, i64 } %11, 0
  %78 = mul <8 x i64> %76, splat (i64 4)
  %79 = getelementptr i8, ptr %77, <8 x i64> %78
  %80 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %79, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %81 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state32 = load i64, ptr %.slot, align 4
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %.state32, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %83 = mul <8 x i64> %.splat34, splat (i64 32)
  %84 = add <8 x i64> %82, %83
  %85 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %81, 0
  %86 = insertvalue { <8 x ptr>, <8 x i64> } %85, <8 x i64> %84, 1
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %86, 1
  %89 = extractelement <8 x ptr> %87, i32 0
  %90 = extractelement <8 x i64> %88, i32 0
  %91 = sub i64 %90, 0
  %92 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %93 = select i1 %92, i64 %91, i64 0
  %private.contiguous.address = getelementptr i8, ptr %89, i64 %93
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %94 = select <8 x i1> %53, <8 x float> %80, <8 x float> %private.contiguous.preserve
  store <8 x float> %94, ptr %private.contiguous.address, align 4
  %.state35 = load i64, ptr %.slot, align 4
  %95 = add i64 %.state35, 1
  store i64 %95, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  store i64 0, ptr %.spill8, align 4
  %tile_snapshot.spill.load36 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 0
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 1
  %98 = add <8 x i64> %97, zeroinitializer
  %99 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %96, 0
  %100 = insertvalue { <8 x ptr>, <8 x i64> } %99, <8 x i64> %98, 1
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %100, 1
  %103 = extractelement <8 x ptr> %101, i32 0
  %104 = extractelement <8 x i64> %102, i32 0
  %105 = sub i64 %104, 0
  %106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %107 = select i1 %106, i64 %105, i64 0
  %private.contiguous.address37 = getelementptr i8, ptr %103, i64 %107
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address37, align 4
  %108 = select <8 x i1> %53, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %109 = fmul <8 x float> %108, %108
  %tile_snapshot.spill.load38 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load38, 0
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load38, 1
  %112 = add <8 x i64> %111, splat (i64 32)
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %110, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %114, 1
  %117 = extractelement <8 x ptr> %115, i32 0
  %118 = extractelement <8 x i64> %116, i32 0
  %119 = sub i64 %118, 0
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %121 = select i1 %120, i64 %119, i64 0
  %private.contiguous.address39 = getelementptr i8, ptr %117, i64 %121
  %private.contiguous.load40 = load <8 x float>, ptr %private.contiguous.address39, align 4
  %122 = select <8 x i1> %53, <8 x float> %private.contiguous.load40, <8 x float> zeroinitializer
  %123 = fmul <8 x float> %122, %122
  %tile_snapshot.spill.load41 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load41, 0
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load41, 1
  %126 = add <8 x i64> %125, splat (i64 64)
  %127 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %124, 0
  %128 = insertvalue { <8 x ptr>, <8 x i64> } %127, <8 x i64> %126, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %128, 1
  %131 = extractelement <8 x ptr> %129, i32 0
  %132 = extractelement <8 x i64> %130, i32 0
  %133 = sub i64 %132, 0
  %134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %135 = select i1 %134, i64 %133, i64 0
  %private.contiguous.address42 = getelementptr i8, ptr %131, i64 %135
  %private.contiguous.load43 = load <8 x float>, ptr %private.contiguous.address42, align 4
  %136 = select <8 x i1> %53, <8 x float> %private.contiguous.load43, <8 x float> zeroinitializer
  %137 = fmul <8 x float> %136, %136
  %tile_snapshot.spill.load44 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 0
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 1
  %140 = add <8 x i64> %139, splat (i64 96)
  %141 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %138, 0
  %142 = insertvalue { <8 x ptr>, <8 x i64> } %141, <8 x i64> %140, 1
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %142, 1
  %145 = extractelement <8 x ptr> %143, i32 0
  %146 = extractelement <8 x i64> %144, i32 0
  %147 = sub i64 %146, 0
  %148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %149 = select i1 %148, i64 %147, i64 0
  %private.contiguous.address45 = getelementptr i8, ptr %145, i64 %149
  %private.contiguous.load46 = load <8 x float>, ptr %private.contiguous.address45, align 4
  %150 = select <8 x i1> %53, <8 x float> %private.contiguous.load46, <8 x float> zeroinitializer
  %151 = fmul <8 x float> %150, %150
  store i64 4, ptr %.slot9, align 4
  %152 = load <8 x float>, ptr %.slot10, align 32
  %153 = select <8 x i1> %53, <8 x float> %109, <8 x float> %152
  store <8 x float> %153, ptr %.slot10, align 32
  %154 = load <8 x float>, ptr %.slot11, align 32
  %155 = select <8 x i1> %53, <8 x float> %123, <8 x float> %154
  store <8 x float> %155, ptr %.slot11, align 32
  %156 = load <8 x float>, ptr %.slot12, align 32
  %157 = select <8 x i1> %53, <8 x float> %137, <8 x float> %156
  store <8 x float> %157, ptr %.slot12, align 32
  %158 = load <8 x float>, ptr %.slot13, align 32
  %159 = select <8 x i1> %53, <8 x float> %151, <8 x float> %158
  store <8 x float> %159, ptr %.slot13, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state47 = load i64, ptr %.slot9, align 4
  %160 = icmp slt i64 %.state47, 1536
  br i1 %160, label %direct.true48, label %direct.false49

direct.schedule.5:                                ; preds = %direct.true48
  %.state50 = load i64, ptr %.slot9, align 4
  %161 = add i64 %.state50, 0
  %162 = sdiv i64 %161, 1
  %.spill.load51 = load i64, ptr %.spill7, align 4
  %163 = add i64 %.spill.load51, %162
  %.spill.load52 = load i64, ptr %.spill8, align 4
  %164 = add i64 %.spill.load52, %163
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %164, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %167 = mul <8 x i64> %.splat55, splat (i64 32)
  %168 = add <8 x i64> %166, %167
  %169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %165, 0
  %170 = insertvalue { <8 x ptr>, <8 x i64> } %169, <8 x i64> %168, 1
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %170, 1
  %173 = extractelement <8 x ptr> %171, i32 0
  %174 = extractelement <8 x i64> %172, i32 0
  %175 = sub i64 %174, 0
  %176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %177 = select i1 %176, i64 %175, i64 0
  %private.contiguous.address56 = getelementptr i8, ptr %173, i64 %177
  %private.contiguous.load57 = load <8 x float>, ptr %private.contiguous.address56, align 4
  %178 = select <8 x i1> %53, <8 x float> %private.contiguous.load57, <8 x float> zeroinitializer
  %179 = fmul <8 x float> %178, %178
  %.state58 = load <8 x float>, ptr %.slot10, align 32
  %180 = fadd <8 x float> %.state58, %179
  %.state59 = load i64, ptr %.slot9, align 4
  %181 = add i64 %.state59, 1
  %182 = sdiv i64 %181, 1
  %.spill.load60 = load i64, ptr %.spill7, align 4
  %183 = add i64 %.spill.load60, %182
  %.spill.load61 = load i64, ptr %.spill8, align 4
  %184 = add i64 %.spill.load61, %183
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %184, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %187 = mul <8 x i64> %.splat64, splat (i64 32)
  %188 = add <8 x i64> %186, %187
  %189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %185, 0
  %190 = insertvalue { <8 x ptr>, <8 x i64> } %189, <8 x i64> %188, 1
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %190, 1
  %193 = extractelement <8 x ptr> %191, i32 0
  %194 = extractelement <8 x i64> %192, i32 0
  %195 = sub i64 %194, 0
  %196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %197 = select i1 %196, i64 %195, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %193, i64 %197
  %private.contiguous.load66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %198 = select <8 x i1> %53, <8 x float> %private.contiguous.load66, <8 x float> zeroinitializer
  %199 = fmul <8 x float> %198, %198
  %.state67 = load <8 x float>, ptr %.slot11, align 32
  %200 = fadd <8 x float> %.state67, %199
  %.state68 = load i64, ptr %.slot9, align 4
  %201 = add i64 %.state68, 2
  %202 = sdiv i64 %201, 1
  %.spill.load69 = load i64, ptr %.spill7, align 4
  %203 = add i64 %.spill.load69, %202
  %.spill.load70 = load i64, ptr %.spill8, align 4
  %204 = add i64 %.spill.load70, %203
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %204, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %207 = mul <8 x i64> %.splat73, splat (i64 32)
  %208 = add <8 x i64> %206, %207
  %209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %205, 0
  %210 = insertvalue { <8 x ptr>, <8 x i64> } %209, <8 x i64> %208, 1
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %210, 1
  %213 = extractelement <8 x ptr> %211, i32 0
  %214 = extractelement <8 x i64> %212, i32 0
  %215 = sub i64 %214, 0
  %216 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %217 = select i1 %216, i64 %215, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %213, i64 %217
  %private.contiguous.load75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %218 = select <8 x i1> %53, <8 x float> %private.contiguous.load75, <8 x float> zeroinitializer
  %219 = fmul <8 x float> %218, %218
  %.state76 = load <8 x float>, ptr %.slot12, align 32
  %220 = fadd <8 x float> %.state76, %219
  %.state77 = load i64, ptr %.slot9, align 4
  %221 = add i64 %.state77, 3
  %222 = sdiv i64 %221, 1
  %.spill.load78 = load i64, ptr %.spill7, align 4
  %223 = add i64 %.spill.load78, %222
  %.spill.load79 = load i64, ptr %.spill8, align 4
  %224 = add i64 %.spill.load79, %223
  %tile_snapshot.spill.load80 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 1
  %.splatinsert81 = insertelement <8 x i64> poison, i64 %224, i64 0
  %.splat82 = shufflevector <8 x i64> %.splatinsert81, <8 x i64> poison, <8 x i32> zeroinitializer
  %227 = mul <8 x i64> %.splat82, splat (i64 32)
  %228 = add <8 x i64> %226, %227
  %229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %225, 0
  %230 = insertvalue { <8 x ptr>, <8 x i64> } %229, <8 x i64> %228, 1
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %230, 1
  %233 = extractelement <8 x ptr> %231, i32 0
  %234 = extractelement <8 x i64> %232, i32 0
  %235 = sub i64 %234, 0
  %236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %237 = select i1 %236, i64 %235, i64 0
  %private.contiguous.address83 = getelementptr i8, ptr %233, i64 %237
  %private.contiguous.load84 = load <8 x float>, ptr %private.contiguous.address83, align 4
  %238 = select <8 x i1> %53, <8 x float> %private.contiguous.load84, <8 x float> zeroinitializer
  %239 = fmul <8 x float> %238, %238
  %.state85 = load <8 x float>, ptr %.slot13, align 32
  %240 = fadd <8 x float> %.state85, %239
  %.state86 = load i64, ptr %.slot9, align 4
  %241 = add i64 %.state86, 4
  store i64 %241, ptr %.slot9, align 4
  %242 = load <8 x float>, ptr %.slot10, align 32
  %243 = select <8 x i1> %53, <8 x float> %180, <8 x float> %242
  store <8 x float> %243, ptr %.slot10, align 32
  %244 = load <8 x float>, ptr %.slot11, align 32
  %245 = select <8 x i1> %53, <8 x float> %200, <8 x float> %244
  store <8 x float> %245, ptr %.slot11, align 32
  %246 = load <8 x float>, ptr %.slot12, align 32
  %247 = select <8 x i1> %53, <8 x float> %220, <8 x float> %246
  store <8 x float> %247, ptr %.slot12, align 32
  %248 = load <8 x float>, ptr %.slot13, align 32
  %249 = select <8 x i1> %53, <8 x float> %240, <8 x float> %248
  store <8 x float> %249, ptr %.slot13, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false49
  %.spill.load87 = load i64, ptr %.spill7, align 4
  %250 = add i64 %.spill.load87, 1536
  %.spill.load88 = load i64, ptr %.spill8, align 4
  %251 = add i64 %.spill.load88, %250
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %251, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %254 = mul <8 x i64> %.splat91, splat (i64 32)
  %255 = add <8 x i64> %253, %254
  %256 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %252, 0
  %257 = insertvalue { <8 x ptr>, <8 x i64> } %256, <8 x i64> %255, 1
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %257, 1
  %260 = extractelement <8 x ptr> %258, i32 0
  %261 = extractelement <8 x i64> %259, i32 0
  %262 = sub i64 %261, 0
  %263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %264 = select i1 %263, i64 %262, i64 0
  %private.contiguous.address92 = getelementptr i8, ptr %260, i64 %264
  %private.contiguous.load93 = load <8 x float>, ptr %private.contiguous.address92, align 4
  %265 = select <8 x i1> %53, <8 x float> %private.contiguous.load93, <8 x float> zeroinitializer
  %266 = fmul <8 x float> %265, %265
  %.state94 = load <8 x float>, ptr %.slot10, align 32
  %267 = fadd <8 x float> %.state94, %266
  %.spill.load95 = load i64, ptr %.spill7, align 4
  %268 = add i64 %.spill.load95, 1537
  %.spill.load96 = load i64, ptr %.spill8, align 4
  %269 = add i64 %.spill.load96, %268
  %tile_snapshot.spill.load97 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 0
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 1
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %269, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %272 = mul <8 x i64> %.splat99, splat (i64 32)
  %273 = add <8 x i64> %271, %272
  %274 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %270, 0
  %275 = insertvalue { <8 x ptr>, <8 x i64> } %274, <8 x i64> %273, 1
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %275, 1
  %278 = extractelement <8 x ptr> %276, i32 0
  %279 = extractelement <8 x i64> %277, i32 0
  %280 = sub i64 %279, 0
  %281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %282 = select i1 %281, i64 %280, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %278, i64 %282
  %private.contiguous.load101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %283 = select <8 x i1> %53, <8 x float> %private.contiguous.load101, <8 x float> zeroinitializer
  %284 = fmul <8 x float> %283, %283
  %.state102 = load <8 x float>, ptr %.slot11, align 32
  %285 = fadd <8 x float> %.state102, %284
  %.spill.load103 = load float, ptr %.spill5, align 4
  %.splatinsert104 = insertelement <8 x float> poison, float %.spill.load103, i64 0
  %.splat105 = shufflevector <8 x float> %.splatinsert104, <8 x float> poison, <8 x i32> zeroinitializer
  %286 = fadd <8 x float> %.splat105, %267
  %287 = fadd <8 x float> %286, %285
  %.state106 = load <8 x float>, ptr %.slot12, align 32
  %288 = fadd <8 x float> %287, %.state106
  %.state107 = load <8 x float>, ptr %.slot13, align 32
  %289 = fadd <8 x float> %288, %.state107
  %290 = fdiv <8 x float> %289, splat (float 1.538000e+03)
  %291 = load <8 x float>, ptr %.spill14, align 32
  %292 = select <8 x i1> %53, <8 x float> %290, <8 x float> %291
  store <8 x float> %292, ptr %.spill14, align 32
  %293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %293, 0
  %296 = select <8 x i1> %53, <8 x ptr> %294, <8 x ptr> %295
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %298 = extractvalue { <8 x ptr>, <8 x i64> } %293, 1
  %299 = select <8 x i1> %53, <8 x i64> %297, <8 x i64> %298
  %300 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %296, 0
  %301 = insertvalue { <8 x ptr>, <8 x i64> } %300, <8 x i64> %299, 1
  store { <8 x ptr>, <8 x i64> } %301, ptr %tile_snapshot.spill15, align 64
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state108 = load i64, ptr %.slot16, align 4
  %302 = icmp slt i64 %.state108, 1538
  br i1 %302, label %direct.true109, label %direct.false110

direct.schedule.8:                                ; preds = %direct.true109
  %.spill.load111 = load i64, ptr %.spill6, align 4
  %303 = add i64 %.spill.load111, 0
  %.state112 = load i64, ptr %.slot16, align 4
  %304 = add i64 0, %.state112
  %305 = mul i64 %303, 1538
  %306 = add i64 %305, %304
  %307 = extractvalue { ptr, i64 } %17, 0
  %308 = mul i64 %306, 4
  %309 = getelementptr i8, ptr %307, i64 %308
  %310 = load float, ptr %309, align 4
  %.splatinsert113 = insertelement <8 x float> poison, float %310, i64 0
  %.splat114 = shufflevector <8 x float> %.splatinsert113, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load115 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 0
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 1
  %.state116 = load i64, ptr %.slot16, align 4
  %.splatinsert117 = insertelement <8 x i64> poison, i64 %.state116, i64 0
  %.splat118 = shufflevector <8 x i64> %.splatinsert117, <8 x i64> poison, <8 x i32> zeroinitializer
  %313 = mul <8 x i64> %.splat118, splat (i64 32)
  %314 = add <8 x i64> %312, %313
  %315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %311, 0
  %316 = insertvalue { <8 x ptr>, <8 x i64> } %315, <8 x i64> %314, 1
  %317 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %316, 1
  %319 = extractelement <8 x ptr> %317, i32 0
  %320 = extractelement <8 x i64> %318, i32 0
  %321 = sub i64 %320, 0
  %322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %323 = select i1 %322, i64 %321, i64 0
  %private.contiguous.address119 = getelementptr i8, ptr %319, i64 %323
  %private.contiguous.preserve120 = load <8 x float>, ptr %private.contiguous.address119, align 4
  %324 = select <8 x i1> %53, <8 x float> %.splat114, <8 x float> %private.contiguous.preserve120
  store <8 x float> %324, ptr %private.contiguous.address119, align 4
  %.state121 = load i64, ptr %.slot16, align 4
  %325 = add i64 %.state121, 1
  store i64 %325, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false110
  %.spill.load122 = load <8 x float>, ptr %.spill14, align 32
  %326 = fadd <8 x float> %.spill.load122, splat (float 0x3EE4F8B580000000)
  %327 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %326)
  %328 = load <8 x float>, ptr %.spill17, align 32
  %329 = select <8 x i1> %53, <8 x float> %327, <8 x float> %328
  store <8 x float> %329, ptr %.spill17, align 32
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state123 = load i64, ptr %.slot18, align 4
  %330 = icmp slt i64 %.state123, 1538
  br i1 %330, label %direct.true124, label %direct.false125

direct.schedule.11:                               ; preds = %direct.true124
  %.spill.load126 = load <8 x i64>, ptr %.spill, align 64
  %331 = add <8 x i64> %.spill.load126, zeroinitializer
  %332 = add <8 x i64> zeroinitializer, %331
  %.state127 = load i64, ptr %.slot18, align 4
  %333 = add i64 0, %.state127
  %334 = mul <8 x i64> %332, splat (i64 1538)
  %.splatinsert128 = insertelement <8 x i64> poison, i64 %333, i64 0
  %.splat129 = shufflevector <8 x i64> %.splatinsert128, <8 x i64> poison, <8 x i32> zeroinitializer
  %335 = add <8 x i64> %334, %.splat129
  %.spill.load130 = load i64, ptr %.spill8, align 4
  %.state131 = load i64, ptr %.slot18, align 4
  %336 = add i64 %.spill.load130, %.state131
  %.spill.load132 = load i64, ptr %.spill8, align 4
  %337 = add i64 %.spill.load132, %336
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %.splatinsert134 = insertelement <8 x i64> poison, i64 %337, i64 0
  %.splat135 = shufflevector <8 x i64> %.splatinsert134, <8 x i64> poison, <8 x i32> zeroinitializer
  %340 = mul <8 x i64> %.splat135, splat (i64 32)
  %341 = add <8 x i64> %339, %340
  %342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %338, 0
  %343 = insertvalue { <8 x ptr>, <8 x i64> } %342, <8 x i64> %341, 1
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %343, 1
  %346 = extractelement <8 x ptr> %344, i32 0
  %347 = extractelement <8 x i64> %345, i32 0
  %348 = sub i64 %347, 0
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %350 = select i1 %349, i64 %348, i64 0
  %private.contiguous.address136 = getelementptr i8, ptr %346, i64 %350
  %private.contiguous.load137 = load <8 x float>, ptr %private.contiguous.address136, align 4
  %351 = select <8 x i1> %53, <8 x float> %private.contiguous.load137, <8 x float> zeroinitializer
  %.spill.load138 = load <8 x float>, ptr %.spill17, align 32
  %352 = fdiv <8 x float> %351, %.spill.load138
  %tile_snapshot.spill.load139 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 0
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 1
  %.splatinsert140 = insertelement <8 x i64> poison, i64 %336, i64 0
  %.splat141 = shufflevector <8 x i64> %.splatinsert140, <8 x i64> poison, <8 x i32> zeroinitializer
  %355 = mul <8 x i64> %.splat141, splat (i64 32)
  %356 = add <8 x i64> %354, %355
  %357 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %353, 0
  %358 = insertvalue { <8 x ptr>, <8 x i64> } %357, <8 x i64> %356, 1
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %358, 1
  %361 = extractelement <8 x ptr> %359, i32 0
  %362 = extractelement <8 x i64> %360, i32 0
  %363 = sub i64 %362, 0
  %364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %365 = select i1 %364, i64 %363, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %361, i64 %365
  %private.contiguous.load143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %366 = select <8 x i1> %53, <8 x float> %private.contiguous.load143, <8 x float> zeroinitializer
  %367 = fmul <8 x float> %352, %366
  %368 = extractvalue { ptr, i64 } %29, 0
  %369 = mul <8 x i64> %335, splat (i64 4)
  %370 = getelementptr i8, ptr %368, <8 x i64> %369
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %367, <8 x ptr> %370, i32 1, <8 x i1> %53)
  %.state144 = load i64, ptr %.slot18, align 4
  %371 = add i64 %.state144, 1
  store i64 %371, ptr %.slot18, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false125
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true48:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false49:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true109:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false110:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true124:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false125:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 49216
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.spill8 = alloca i64, align 8
  store i64 0, ptr %.spill8, align 4
  %.slot9 = alloca i64, align 8
  store i64 0, ptr %.slot9, align 4
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.slot13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot13, align 32
  %.spill14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill14, align 32
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %.spill17 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill17, align 32
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %6 = getelementptr i8, ptr %argument_buffer, i64 0
  %7 = load ptr, ptr %6, align 16
  %8 = getelementptr i8, ptr %6, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { ptr, i64 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %9, 1
  %12 = getelementptr i8, ptr %argument_buffer, i64 16
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 32
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 48
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = load i32, ptr %launch_config, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 12
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 4
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 16
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 8
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 20
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 36
  %42 = load i32, ptr %41, align 4
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat20, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %44 = mul i32 %30, 32
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, %43
  %46 = mul i32 %34, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, zeroinitializer
  %48 = mul i32 %38, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat26, zeroinitializer
  %50 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %45, 0
  %51 = insertvalue [3 x <8 x i32>] %50, <8 x i32> %47, 1
  %52 = insertvalue [3 x <8 x i32>] %51, <8 x i32> %49, 2
  %.splatinsert27 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat28
  %54 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  br i1 %54, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %55 = extractvalue [3 x <8 x i32>] %52, 0
  %56 = zext <8 x i32> %55 to <8 x i64>
  %57 = select <8 x i1> %53, <8 x i64> %56, <8 x i64> zeroinitializer
  %58 = select <8 x i1> %53, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %59 = sdiv <8 x i64> %57, %58
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %53, <8 x i64> %59, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %63 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %62, 0
  %65 = select <8 x i1> %53, <8 x ptr> %63, <8 x ptr> %64
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %62, 1
  %68 = select <8 x i1> %53, <8 x i64> %66, <8 x i64> %67
  %69 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %65, 0
  %70 = insertvalue { <8 x ptr>, <8 x i64> } %69, <8 x i64> %68, 1
  store { <8 x ptr>, <8 x i64> } %70, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %71 = icmp slt i64 %.state, 1538
  br i1 %71, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %72 = add <8 x i64> %.spill.load, zeroinitializer
  %73 = add <8 x i64> zeroinitializer, %72
  %.state29 = load i64, ptr %.slot, align 4
  %74 = add i64 0, %.state29
  %75 = mul <8 x i64> %73, splat (i64 1538)
  %.splatinsert30 = insertelement <8 x i64> poison, i64 %74, i64 0
  %.splat31 = shufflevector <8 x i64> %.splatinsert30, <8 x i64> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i64> %75, %.splat31
  %77 = extractvalue { ptr, i64 } %11, 0
  %78 = mul <8 x i64> %76, splat (i64 4)
  %79 = getelementptr i8, ptr %77, <8 x i64> %78
  %80 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %79, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %81 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state32 = load i64, ptr %.slot, align 4
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %.state32, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %83 = mul <8 x i64> %.splat34, splat (i64 32)
  %84 = add <8 x i64> %82, %83
  %85 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %81, 0
  %86 = insertvalue { <8 x ptr>, <8 x i64> } %85, <8 x i64> %84, 1
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %86, 1
  %89 = extractelement <8 x ptr> %87, i32 0
  %90 = extractelement <8 x i64> %88, i32 0
  %91 = sub i64 %90, 0
  %92 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %93 = select i1 %92, i64 %91, i64 0
  %private.contiguous.address = getelementptr i8, ptr %89, i64 %93
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %94 = select <8 x i1> %53, <8 x float> %80, <8 x float> %private.contiguous.preserve
  store <8 x float> %94, ptr %private.contiguous.address, align 4
  %.state35 = load i64, ptr %.slot, align 4
  %95 = add i64 %.state35, 1
  store i64 %95, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  store i64 0, ptr %.spill8, align 4
  %tile_snapshot.spill.load36 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 0
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 1
  %98 = add <8 x i64> %97, zeroinitializer
  %99 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %96, 0
  %100 = insertvalue { <8 x ptr>, <8 x i64> } %99, <8 x i64> %98, 1
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %100, 1
  %103 = extractelement <8 x ptr> %101, i32 0
  %104 = extractelement <8 x i64> %102, i32 0
  %105 = sub i64 %104, 0
  %106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %107 = select i1 %106, i64 %105, i64 0
  %private.contiguous.address37 = getelementptr i8, ptr %103, i64 %107
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address37, align 4
  %108 = select <8 x i1> %53, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %109 = fmul <8 x float> %108, %108
  %tile_snapshot.spill.load38 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load38, 0
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load38, 1
  %112 = add <8 x i64> %111, splat (i64 32)
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %110, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %114, 1
  %117 = extractelement <8 x ptr> %115, i32 0
  %118 = extractelement <8 x i64> %116, i32 0
  %119 = sub i64 %118, 0
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %121 = select i1 %120, i64 %119, i64 0
  %private.contiguous.address39 = getelementptr i8, ptr %117, i64 %121
  %private.contiguous.load40 = load <8 x float>, ptr %private.contiguous.address39, align 4
  %122 = select <8 x i1> %53, <8 x float> %private.contiguous.load40, <8 x float> zeroinitializer
  %123 = fmul <8 x float> %122, %122
  %tile_snapshot.spill.load41 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load41, 0
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load41, 1
  %126 = add <8 x i64> %125, splat (i64 64)
  %127 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %124, 0
  %128 = insertvalue { <8 x ptr>, <8 x i64> } %127, <8 x i64> %126, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %128, 1
  %131 = extractelement <8 x ptr> %129, i32 0
  %132 = extractelement <8 x i64> %130, i32 0
  %133 = sub i64 %132, 0
  %134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %135 = select i1 %134, i64 %133, i64 0
  %private.contiguous.address42 = getelementptr i8, ptr %131, i64 %135
  %private.contiguous.load43 = load <8 x float>, ptr %private.contiguous.address42, align 4
  %136 = select <8 x i1> %53, <8 x float> %private.contiguous.load43, <8 x float> zeroinitializer
  %137 = fmul <8 x float> %136, %136
  %tile_snapshot.spill.load44 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 0
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 1
  %140 = add <8 x i64> %139, splat (i64 96)
  %141 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %138, 0
  %142 = insertvalue { <8 x ptr>, <8 x i64> } %141, <8 x i64> %140, 1
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %142, 1
  %145 = extractelement <8 x ptr> %143, i32 0
  %146 = extractelement <8 x i64> %144, i32 0
  %147 = sub i64 %146, 0
  %148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %149 = select i1 %148, i64 %147, i64 0
  %private.contiguous.address45 = getelementptr i8, ptr %145, i64 %149
  %private.contiguous.load46 = load <8 x float>, ptr %private.contiguous.address45, align 4
  %150 = select <8 x i1> %53, <8 x float> %private.contiguous.load46, <8 x float> zeroinitializer
  %151 = fmul <8 x float> %150, %150
  store i64 4, ptr %.slot9, align 4
  %152 = load <8 x float>, ptr %.slot10, align 32
  %153 = select <8 x i1> %53, <8 x float> %109, <8 x float> %152
  store <8 x float> %153, ptr %.slot10, align 32
  %154 = load <8 x float>, ptr %.slot11, align 32
  %155 = select <8 x i1> %53, <8 x float> %123, <8 x float> %154
  store <8 x float> %155, ptr %.slot11, align 32
  %156 = load <8 x float>, ptr %.slot12, align 32
  %157 = select <8 x i1> %53, <8 x float> %137, <8 x float> %156
  store <8 x float> %157, ptr %.slot12, align 32
  %158 = load <8 x float>, ptr %.slot13, align 32
  %159 = select <8 x i1> %53, <8 x float> %151, <8 x float> %158
  store <8 x float> %159, ptr %.slot13, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state47 = load i64, ptr %.slot9, align 4
  %160 = icmp slt i64 %.state47, 1536
  br i1 %160, label %direct.true48, label %direct.false49

direct.schedule.5:                                ; preds = %direct.true48
  %.state50 = load i64, ptr %.slot9, align 4
  %161 = add i64 %.state50, 0
  %162 = sdiv i64 %161, 1
  %.spill.load51 = load i64, ptr %.spill7, align 4
  %163 = add i64 %.spill.load51, %162
  %.spill.load52 = load i64, ptr %.spill8, align 4
  %164 = add i64 %.spill.load52, %163
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %164, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %167 = mul <8 x i64> %.splat55, splat (i64 32)
  %168 = add <8 x i64> %166, %167
  %169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %165, 0
  %170 = insertvalue { <8 x ptr>, <8 x i64> } %169, <8 x i64> %168, 1
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %170, 1
  %173 = extractelement <8 x ptr> %171, i32 0
  %174 = extractelement <8 x i64> %172, i32 0
  %175 = sub i64 %174, 0
  %176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %177 = select i1 %176, i64 %175, i64 0
  %private.contiguous.address56 = getelementptr i8, ptr %173, i64 %177
  %private.contiguous.load57 = load <8 x float>, ptr %private.contiguous.address56, align 4
  %178 = select <8 x i1> %53, <8 x float> %private.contiguous.load57, <8 x float> zeroinitializer
  %179 = fmul <8 x float> %178, %178
  %.state58 = load <8 x float>, ptr %.slot10, align 32
  %180 = fadd <8 x float> %.state58, %179
  %.state59 = load i64, ptr %.slot9, align 4
  %181 = add i64 %.state59, 1
  %182 = sdiv i64 %181, 1
  %.spill.load60 = load i64, ptr %.spill7, align 4
  %183 = add i64 %.spill.load60, %182
  %.spill.load61 = load i64, ptr %.spill8, align 4
  %184 = add i64 %.spill.load61, %183
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %184, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %187 = mul <8 x i64> %.splat64, splat (i64 32)
  %188 = add <8 x i64> %186, %187
  %189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %185, 0
  %190 = insertvalue { <8 x ptr>, <8 x i64> } %189, <8 x i64> %188, 1
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %190, 1
  %193 = extractelement <8 x ptr> %191, i32 0
  %194 = extractelement <8 x i64> %192, i32 0
  %195 = sub i64 %194, 0
  %196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %197 = select i1 %196, i64 %195, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %193, i64 %197
  %private.contiguous.load66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %198 = select <8 x i1> %53, <8 x float> %private.contiguous.load66, <8 x float> zeroinitializer
  %199 = fmul <8 x float> %198, %198
  %.state67 = load <8 x float>, ptr %.slot11, align 32
  %200 = fadd <8 x float> %.state67, %199
  %.state68 = load i64, ptr %.slot9, align 4
  %201 = add i64 %.state68, 2
  %202 = sdiv i64 %201, 1
  %.spill.load69 = load i64, ptr %.spill7, align 4
  %203 = add i64 %.spill.load69, %202
  %.spill.load70 = load i64, ptr %.spill8, align 4
  %204 = add i64 %.spill.load70, %203
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %204, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %207 = mul <8 x i64> %.splat73, splat (i64 32)
  %208 = add <8 x i64> %206, %207
  %209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %205, 0
  %210 = insertvalue { <8 x ptr>, <8 x i64> } %209, <8 x i64> %208, 1
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %210, 1
  %213 = extractelement <8 x ptr> %211, i32 0
  %214 = extractelement <8 x i64> %212, i32 0
  %215 = sub i64 %214, 0
  %216 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %217 = select i1 %216, i64 %215, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %213, i64 %217
  %private.contiguous.load75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %218 = select <8 x i1> %53, <8 x float> %private.contiguous.load75, <8 x float> zeroinitializer
  %219 = fmul <8 x float> %218, %218
  %.state76 = load <8 x float>, ptr %.slot12, align 32
  %220 = fadd <8 x float> %.state76, %219
  %.state77 = load i64, ptr %.slot9, align 4
  %221 = add i64 %.state77, 3
  %222 = sdiv i64 %221, 1
  %.spill.load78 = load i64, ptr %.spill7, align 4
  %223 = add i64 %.spill.load78, %222
  %.spill.load79 = load i64, ptr %.spill8, align 4
  %224 = add i64 %.spill.load79, %223
  %tile_snapshot.spill.load80 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 1
  %.splatinsert81 = insertelement <8 x i64> poison, i64 %224, i64 0
  %.splat82 = shufflevector <8 x i64> %.splatinsert81, <8 x i64> poison, <8 x i32> zeroinitializer
  %227 = mul <8 x i64> %.splat82, splat (i64 32)
  %228 = add <8 x i64> %226, %227
  %229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %225, 0
  %230 = insertvalue { <8 x ptr>, <8 x i64> } %229, <8 x i64> %228, 1
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %230, 1
  %233 = extractelement <8 x ptr> %231, i32 0
  %234 = extractelement <8 x i64> %232, i32 0
  %235 = sub i64 %234, 0
  %236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %237 = select i1 %236, i64 %235, i64 0
  %private.contiguous.address83 = getelementptr i8, ptr %233, i64 %237
  %private.contiguous.load84 = load <8 x float>, ptr %private.contiguous.address83, align 4
  %238 = select <8 x i1> %53, <8 x float> %private.contiguous.load84, <8 x float> zeroinitializer
  %239 = fmul <8 x float> %238, %238
  %.state85 = load <8 x float>, ptr %.slot13, align 32
  %240 = fadd <8 x float> %.state85, %239
  %.state86 = load i64, ptr %.slot9, align 4
  %241 = add i64 %.state86, 4
  store i64 %241, ptr %.slot9, align 4
  %242 = load <8 x float>, ptr %.slot10, align 32
  %243 = select <8 x i1> %53, <8 x float> %180, <8 x float> %242
  store <8 x float> %243, ptr %.slot10, align 32
  %244 = load <8 x float>, ptr %.slot11, align 32
  %245 = select <8 x i1> %53, <8 x float> %200, <8 x float> %244
  store <8 x float> %245, ptr %.slot11, align 32
  %246 = load <8 x float>, ptr %.slot12, align 32
  %247 = select <8 x i1> %53, <8 x float> %220, <8 x float> %246
  store <8 x float> %247, ptr %.slot12, align 32
  %248 = load <8 x float>, ptr %.slot13, align 32
  %249 = select <8 x i1> %53, <8 x float> %240, <8 x float> %248
  store <8 x float> %249, ptr %.slot13, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false49
  %.spill.load87 = load i64, ptr %.spill7, align 4
  %250 = add i64 %.spill.load87, 1536
  %.spill.load88 = load i64, ptr %.spill8, align 4
  %251 = add i64 %.spill.load88, %250
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %251, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %254 = mul <8 x i64> %.splat91, splat (i64 32)
  %255 = add <8 x i64> %253, %254
  %256 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %252, 0
  %257 = insertvalue { <8 x ptr>, <8 x i64> } %256, <8 x i64> %255, 1
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %257, 1
  %260 = extractelement <8 x ptr> %258, i32 0
  %261 = extractelement <8 x i64> %259, i32 0
  %262 = sub i64 %261, 0
  %263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %264 = select i1 %263, i64 %262, i64 0
  %private.contiguous.address92 = getelementptr i8, ptr %260, i64 %264
  %private.contiguous.load93 = load <8 x float>, ptr %private.contiguous.address92, align 4
  %265 = select <8 x i1> %53, <8 x float> %private.contiguous.load93, <8 x float> zeroinitializer
  %266 = fmul <8 x float> %265, %265
  %.state94 = load <8 x float>, ptr %.slot10, align 32
  %267 = fadd <8 x float> %.state94, %266
  %.spill.load95 = load i64, ptr %.spill7, align 4
  %268 = add i64 %.spill.load95, 1537
  %.spill.load96 = load i64, ptr %.spill8, align 4
  %269 = add i64 %.spill.load96, %268
  %tile_snapshot.spill.load97 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 0
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 1
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %269, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %272 = mul <8 x i64> %.splat99, splat (i64 32)
  %273 = add <8 x i64> %271, %272
  %274 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %270, 0
  %275 = insertvalue { <8 x ptr>, <8 x i64> } %274, <8 x i64> %273, 1
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %275, 1
  %278 = extractelement <8 x ptr> %276, i32 0
  %279 = extractelement <8 x i64> %277, i32 0
  %280 = sub i64 %279, 0
  %281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %282 = select i1 %281, i64 %280, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %278, i64 %282
  %private.contiguous.load101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %283 = select <8 x i1> %53, <8 x float> %private.contiguous.load101, <8 x float> zeroinitializer
  %284 = fmul <8 x float> %283, %283
  %.state102 = load <8 x float>, ptr %.slot11, align 32
  %285 = fadd <8 x float> %.state102, %284
  %.spill.load103 = load float, ptr %.spill5, align 4
  %.splatinsert104 = insertelement <8 x float> poison, float %.spill.load103, i64 0
  %.splat105 = shufflevector <8 x float> %.splatinsert104, <8 x float> poison, <8 x i32> zeroinitializer
  %286 = fadd <8 x float> %.splat105, %267
  %287 = fadd <8 x float> %286, %285
  %.state106 = load <8 x float>, ptr %.slot12, align 32
  %288 = fadd <8 x float> %287, %.state106
  %.state107 = load <8 x float>, ptr %.slot13, align 32
  %289 = fadd <8 x float> %288, %.state107
  %290 = fdiv <8 x float> %289, splat (float 1.538000e+03)
  %291 = load <8 x float>, ptr %.spill14, align 32
  %292 = select <8 x i1> %53, <8 x float> %290, <8 x float> %291
  store <8 x float> %292, ptr %.spill14, align 32
  %293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %293, 0
  %296 = select <8 x i1> %53, <8 x ptr> %294, <8 x ptr> %295
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %298 = extractvalue { <8 x ptr>, <8 x i64> } %293, 1
  %299 = select <8 x i1> %53, <8 x i64> %297, <8 x i64> %298
  %300 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %296, 0
  %301 = insertvalue { <8 x ptr>, <8 x i64> } %300, <8 x i64> %299, 1
  store { <8 x ptr>, <8 x i64> } %301, ptr %tile_snapshot.spill15, align 64
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state108 = load i64, ptr %.slot16, align 4
  %302 = icmp slt i64 %.state108, 1538
  br i1 %302, label %direct.true109, label %direct.false110

direct.schedule.8:                                ; preds = %direct.true109
  %.spill.load111 = load i64, ptr %.spill6, align 4
  %303 = add i64 %.spill.load111, 0
  %.state112 = load i64, ptr %.slot16, align 4
  %304 = add i64 0, %.state112
  %305 = mul i64 %303, 1538
  %306 = add i64 %305, %304
  %307 = extractvalue { ptr, i64 } %17, 0
  %308 = mul i64 %306, 4
  %309 = getelementptr i8, ptr %307, i64 %308
  %310 = load float, ptr %309, align 4
  %.splatinsert113 = insertelement <8 x float> poison, float %310, i64 0
  %.splat114 = shufflevector <8 x float> %.splatinsert113, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load115 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 0
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 1
  %.state116 = load i64, ptr %.slot16, align 4
  %.splatinsert117 = insertelement <8 x i64> poison, i64 %.state116, i64 0
  %.splat118 = shufflevector <8 x i64> %.splatinsert117, <8 x i64> poison, <8 x i32> zeroinitializer
  %313 = mul <8 x i64> %.splat118, splat (i64 32)
  %314 = add <8 x i64> %312, %313
  %315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %311, 0
  %316 = insertvalue { <8 x ptr>, <8 x i64> } %315, <8 x i64> %314, 1
  %317 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %316, 1
  %319 = extractelement <8 x ptr> %317, i32 0
  %320 = extractelement <8 x i64> %318, i32 0
  %321 = sub i64 %320, 0
  %322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %323 = select i1 %322, i64 %321, i64 0
  %private.contiguous.address119 = getelementptr i8, ptr %319, i64 %323
  %private.contiguous.preserve120 = load <8 x float>, ptr %private.contiguous.address119, align 4
  %324 = select <8 x i1> %53, <8 x float> %.splat114, <8 x float> %private.contiguous.preserve120
  store <8 x float> %324, ptr %private.contiguous.address119, align 4
  %.state121 = load i64, ptr %.slot16, align 4
  %325 = add i64 %.state121, 1
  store i64 %325, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false110
  %.spill.load122 = load <8 x float>, ptr %.spill14, align 32
  %326 = fadd <8 x float> %.spill.load122, splat (float 0x3EE4F8B580000000)
  %327 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %326)
  %328 = load <8 x float>, ptr %.spill17, align 32
  %329 = select <8 x i1> %53, <8 x float> %327, <8 x float> %328
  store <8 x float> %329, ptr %.spill17, align 32
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state123 = load i64, ptr %.slot18, align 4
  %330 = icmp slt i64 %.state123, 1538
  br i1 %330, label %direct.true124, label %direct.false125

direct.schedule.11:                               ; preds = %direct.true124
  %.spill.load126 = load <8 x i64>, ptr %.spill, align 64
  %331 = add <8 x i64> %.spill.load126, zeroinitializer
  %332 = add <8 x i64> zeroinitializer, %331
  %.state127 = load i64, ptr %.slot18, align 4
  %333 = add i64 0, %.state127
  %334 = mul <8 x i64> %332, splat (i64 1538)
  %.splatinsert128 = insertelement <8 x i64> poison, i64 %333, i64 0
  %.splat129 = shufflevector <8 x i64> %.splatinsert128, <8 x i64> poison, <8 x i32> zeroinitializer
  %335 = add <8 x i64> %334, %.splat129
  %.spill.load130 = load i64, ptr %.spill8, align 4
  %.state131 = load i64, ptr %.slot18, align 4
  %336 = add i64 %.spill.load130, %.state131
  %.spill.load132 = load i64, ptr %.spill8, align 4
  %337 = add i64 %.spill.load132, %336
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %.splatinsert134 = insertelement <8 x i64> poison, i64 %337, i64 0
  %.splat135 = shufflevector <8 x i64> %.splatinsert134, <8 x i64> poison, <8 x i32> zeroinitializer
  %340 = mul <8 x i64> %.splat135, splat (i64 32)
  %341 = add <8 x i64> %339, %340
  %342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %338, 0
  %343 = insertvalue { <8 x ptr>, <8 x i64> } %342, <8 x i64> %341, 1
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %343, 1
  %346 = extractelement <8 x ptr> %344, i32 0
  %347 = extractelement <8 x i64> %345, i32 0
  %348 = sub i64 %347, 0
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %350 = select i1 %349, i64 %348, i64 0
  %private.contiguous.address136 = getelementptr i8, ptr %346, i64 %350
  %private.contiguous.load137 = load <8 x float>, ptr %private.contiguous.address136, align 4
  %351 = select <8 x i1> %53, <8 x float> %private.contiguous.load137, <8 x float> zeroinitializer
  %.spill.load138 = load <8 x float>, ptr %.spill17, align 32
  %352 = fdiv <8 x float> %351, %.spill.load138
  %tile_snapshot.spill.load139 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 0
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 1
  %.splatinsert140 = insertelement <8 x i64> poison, i64 %336, i64 0
  %.splat141 = shufflevector <8 x i64> %.splatinsert140, <8 x i64> poison, <8 x i32> zeroinitializer
  %355 = mul <8 x i64> %.splat141, splat (i64 32)
  %356 = add <8 x i64> %354, %355
  %357 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %353, 0
  %358 = insertvalue { <8 x ptr>, <8 x i64> } %357, <8 x i64> %356, 1
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %358, 1
  %361 = extractelement <8 x ptr> %359, i32 0
  %362 = extractelement <8 x i64> %360, i32 0
  %363 = sub i64 %362, 0
  %364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %365 = select i1 %364, i64 %363, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %361, i64 %365
  %private.contiguous.load143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %366 = select <8 x i1> %53, <8 x float> %private.contiguous.load143, <8 x float> zeroinitializer
  %367 = fmul <8 x float> %352, %366
  %368 = extractvalue { ptr, i64 } %29, 0
  %369 = mul <8 x i64> %335, splat (i64 4)
  %370 = getelementptr i8, ptr %368, <8 x i64> %369
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %367, <8 x ptr> %370, i32 1, <8 x i1> %53)
  %.state144 = load i64, ptr %.slot18, align 4
  %371 = add i64 %.state144, 1
  store i64 %371, ptr %.slot18, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false125
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true48:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false49:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true109:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false110:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true124:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false125:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

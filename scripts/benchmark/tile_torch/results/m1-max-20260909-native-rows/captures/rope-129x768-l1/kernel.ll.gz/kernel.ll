; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [12288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [12288 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [12288 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [12288 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill10 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill10, align 64
  %.slot11 = alloca i64, align 8
  store i64 0, ptr %.slot11, align 4
  %tile_snapshot.spill12 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill12, align 64
  %.slot13 = alloca i64, align 8
  store i64 0, ptr %.slot13, align 4
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca i64, align 8
  store i64 0, ptr %.slot15, align 4
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat19, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat21, %45
  %48 = mul i32 %36, 1
  %.splatinsert22 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat23, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert24 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat25 = shufflevector <8 x i32> %.splatinsert24, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat25, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert26 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat27 = shufflevector <8 x i32> %.splatinsert26, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat27
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = zext <8 x i32> %57 to <8 x i64>
  %59 = select <8 x i1> %55, <8 x i64> %58, <8 x i64> zeroinitializer
  %60 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %61 = sdiv <8 x i64> %59, %60
  %62 = load <8 x i64>, ptr %.spill, align 64
  %63 = select <8 x i1> %55, <8 x i64> %61, <8 x i64> %62
  store <8 x i64> %63, ptr %.spill, align 64
  %64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %64, 0
  %67 = select <8 x i1> %55, <8 x ptr> %65, <8 x ptr> %66
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %64, 1
  %70 = select <8 x i1> %55, <8 x i64> %68, <8 x i64> %69
  %71 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %67, 0
  %72 = insertvalue { <8 x ptr>, <8 x i64> } %71, <8 x i64> %70, 1
  store { <8 x ptr>, <8 x i64> } %72, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %73 = icmp slt i64 %.state, 384
  br i1 %73, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %74 = add <8 x i64> %.spill.load, zeroinitializer
  %75 = add <8 x i64> zeroinitializer, %74
  %.state28 = load i64, ptr %.slot, align 4
  %76 = add i64 0, %.state28
  %77 = mul <8 x i64> %75, splat (i64 768)
  %.splatinsert29 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat30 = shufflevector <8 x i64> %.splatinsert29, <8 x i64> poison, <8 x i32> zeroinitializer
  %78 = add <8 x i64> %77, %.splat30
  %79 = extractvalue { ptr, i64 } %13, 0
  %80 = mul <8 x i64> %78, splat (i64 4)
  %81 = getelementptr i8, ptr %79, <8 x i64> %80
  %82 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %81, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %83 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %84 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state31 = load i64, ptr %.slot, align 4
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %.state31, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %85 = mul <8 x i64> %.splat33, splat (i64 32)
  %86 = add <8 x i64> %84, %85
  %87 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %83, 0
  %88 = insertvalue { <8 x ptr>, <8 x i64> } %87, <8 x i64> %86, 1
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %88, 1
  %91 = extractelement <8 x ptr> %89, i32 0
  %92 = extractelement <8 x i64> %90, i32 0
  %93 = sub i64 %92, 0
  %94 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %95 = select i1 %94, i64 %93, i64 0
  %private.contiguous.address = getelementptr i8, ptr %91, i64 %95
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %96 = select <8 x i1> %55, <8 x float> %82, <8 x float> %private.contiguous.preserve
  store <8 x float> %96, ptr %private.contiguous.address, align 4
  %.state34 = load i64, ptr %.slot, align 4
  %97 = add i64 %.state34, 1
  store i64 %97, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %98 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %98, 0
  %101 = select <8 x i1> %55, <8 x ptr> %99, <8 x ptr> %100
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %98, 1
  %104 = select <8 x i1> %55, <8 x i64> %102, <8 x i64> %103
  %105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %101, 0
  %106 = insertvalue { <8 x ptr>, <8 x i64> } %105, <8 x i64> %104, 1
  store { <8 x ptr>, <8 x i64> } %106, ptr %tile_snapshot.spill10, align 64
  store i64 0, ptr %.slot11, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state35 = load i64, ptr %.slot11, align 4
  %107 = icmp slt i64 %.state35, 384
  br i1 %107, label %direct.true36, label %direct.false37

direct.schedule.5:                                ; preds = %direct.true36
  %.spill.load38 = load <8 x i64>, ptr %.spill, align 64
  %108 = add <8 x i64> %.spill.load38, zeroinitializer
  %109 = add <8 x i64> zeroinitializer, %108
  %.state39 = load i64, ptr %.slot11, align 4
  %110 = add i64 384, %.state39
  %111 = mul <8 x i64> %109, splat (i64 768)
  %.splatinsert40 = insertelement <8 x i64> poison, i64 %110, i64 0
  %.splat41 = shufflevector <8 x i64> %.splatinsert40, <8 x i64> poison, <8 x i32> zeroinitializer
  %112 = add <8 x i64> %111, %.splat41
  %113 = extractvalue { ptr, i64 } %13, 0
  %114 = mul <8 x i64> %112, splat (i64 4)
  %115 = getelementptr i8, ptr %113, <8 x i64> %114
  %116 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %115, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load42 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load42, 0
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load42, 1
  %.state43 = load i64, ptr %.slot11, align 4
  %.splatinsert44 = insertelement <8 x i64> poison, i64 %.state43, i64 0
  %.splat45 = shufflevector <8 x i64> %.splatinsert44, <8 x i64> poison, <8 x i32> zeroinitializer
  %119 = mul <8 x i64> %.splat45, splat (i64 32)
  %120 = add <8 x i64> %118, %119
  %121 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %117, 0
  %122 = insertvalue { <8 x ptr>, <8 x i64> } %121, <8 x i64> %120, 1
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %122, 1
  %125 = extractelement <8 x ptr> %123, i32 0
  %126 = extractelement <8 x i64> %124, i32 0
  %127 = sub i64 %126, 0
  %128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %129 = select i1 %128, i64 %127, i64 0
  %private.contiguous.address46 = getelementptr i8, ptr %125, i64 %129
  %private.contiguous.preserve47 = load <8 x float>, ptr %private.contiguous.address46, align 4
  %130 = select <8 x i1> %55, <8 x float> %116, <8 x float> %private.contiguous.preserve47
  store <8 x float> %130, ptr %private.contiguous.address46, align 4
  %.state48 = load i64, ptr %.slot11, align 4
  %131 = add i64 %.state48, 1
  store i64 %131, ptr %.slot11, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false37
  %132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %132, 0
  %135 = select <8 x i1> %55, <8 x ptr> %133, <8 x ptr> %134
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %138 = select <8 x i1> %55, <8 x i64> %136, <8 x i64> %137
  %139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %135, 0
  %140 = insertvalue { <8 x ptr>, <8 x i64> } %139, <8 x i64> %138, 1
  store { <8 x ptr>, <8 x i64> } %140, ptr %tile_snapshot.spill12, align 64
  store i64 0, ptr %.slot13, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state49 = load i64, ptr %.slot13, align 4
  %141 = icmp slt i64 %.state49, 384
  br i1 %141, label %direct.true50, label %direct.false51

direct.schedule.8:                                ; preds = %direct.true50
  %.spill.load52 = load <8 x i64>, ptr %.spill, align 64
  %142 = add <8 x i64> %.spill.load52, zeroinitializer
  %143 = add <8 x i64> zeroinitializer, %142
  %.state53 = load i64, ptr %.slot13, align 4
  %144 = add i64 0, %.state53
  %145 = mul <8 x i64> %143, splat (i64 384)
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %144, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %146 = add <8 x i64> %145, %.splat55
  %147 = extractvalue { ptr, i64 } %19, 0
  %148 = mul <8 x i64> %146, splat (i64 4)
  %149 = getelementptr i8, ptr %147, <8 x i64> %148
  %150 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %149, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load56 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load56, 0
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load56, 1
  %.state57 = load i64, ptr %.slot13, align 4
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %.state57, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %153 = mul <8 x i64> %.splat59, splat (i64 32)
  %154 = add <8 x i64> %152, %153
  %155 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %151, 0
  %156 = insertvalue { <8 x ptr>, <8 x i64> } %155, <8 x i64> %154, 1
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %156, 1
  %159 = extractelement <8 x ptr> %157, i32 0
  %160 = extractelement <8 x i64> %158, i32 0
  %161 = sub i64 %160, 0
  %162 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %163 = select i1 %162, i64 %161, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %159, i64 %163
  %private.contiguous.preserve61 = load <8 x float>, ptr %private.contiguous.address60, align 4
  %164 = select <8 x i1> %55, <8 x float> %150, <8 x float> %private.contiguous.preserve61
  store <8 x float> %164, ptr %private.contiguous.address60, align 4
  %.state62 = load i64, ptr %.slot13, align 4
  %165 = add i64 %.state62, 1
  store i64 %165, ptr %.slot13, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false51
  %166 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %166, 0
  %169 = select <8 x i1> %55, <8 x ptr> %167, <8 x ptr> %168
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %166, 1
  %172 = select <8 x i1> %55, <8 x i64> %170, <8 x i64> %171
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %169, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  store { <8 x ptr>, <8 x i64> } %174, ptr %tile_snapshot.spill14, align 64
  store i64 0, ptr %.slot15, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state63 = load i64, ptr %.slot15, align 4
  %175 = icmp slt i64 %.state63, 384
  br i1 %175, label %direct.true64, label %direct.false65

direct.schedule.11:                               ; preds = %direct.true64
  %.spill.load66 = load <8 x i64>, ptr %.spill, align 64
  %176 = add <8 x i64> %.spill.load66, zeroinitializer
  %177 = add <8 x i64> zeroinitializer, %176
  %.state67 = load i64, ptr %.slot15, align 4
  %178 = add i64 0, %.state67
  %179 = mul <8 x i64> %177, splat (i64 384)
  %.splatinsert68 = insertelement <8 x i64> poison, i64 %178, i64 0
  %.splat69 = shufflevector <8 x i64> %.splatinsert68, <8 x i64> poison, <8 x i32> zeroinitializer
  %180 = add <8 x i64> %179, %.splat69
  %181 = extractvalue { ptr, i64 } %25, 0
  %182 = mul <8 x i64> %180, splat (i64 4)
  %183 = getelementptr i8, ptr %181, <8 x i64> %182
  %184 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %183, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 0
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 1
  %.state71 = load i64, ptr %.slot15, align 4
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %.state71, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %187 = mul <8 x i64> %.splat73, splat (i64 32)
  %188 = add <8 x i64> %186, %187
  %189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %185, 0
  %190 = insertvalue { <8 x ptr>, <8 x i64> } %189, <8 x i64> %188, 1
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %190, 1
  %193 = extractelement <8 x ptr> %191, i32 0
  %194 = extractelement <8 x i64> %192, i32 0
  %195 = sub i64 %194, 0
  %196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %197 = select i1 %196, i64 %195, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %193, i64 %197
  %private.contiguous.preserve75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %198 = select <8 x i1> %55, <8 x float> %184, <8 x float> %private.contiguous.preserve75
  store <8 x float> %198, ptr %private.contiguous.address74, align 4
  %.state76 = load i64, ptr %.slot15, align 4
  %199 = add i64 %.state76, 1
  store i64 %199, ptr %.slot15, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false65
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state77 = load i64, ptr %.slot16, align 4
  %200 = icmp slt i64 %.state77, 384
  br i1 %200, label %direct.true78, label %direct.false79

direct.schedule.14:                               ; preds = %direct.true78
  %.spill.load80 = load <8 x i64>, ptr %.spill, align 64
  %201 = add <8 x i64> %.spill.load80, zeroinitializer
  %202 = add <8 x i64> zeroinitializer, %201
  %.state81 = load i64, ptr %.slot16, align 4
  %203 = add i64 0, %.state81
  %204 = mul <8 x i64> %202, splat (i64 768)
  %.splatinsert82 = insertelement <8 x i64> poison, i64 %203, i64 0
  %.splat83 = shufflevector <8 x i64> %.splatinsert82, <8 x i64> poison, <8 x i32> zeroinitializer
  %205 = add <8 x i64> %204, %.splat83
  %.state84 = load i64, ptr %.slot16, align 4
  %206 = add i64 0, %.state84
  %207 = add i64 0, %206
  %tile_snapshot.spill.load85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 1
  %.splatinsert86 = insertelement <8 x i64> poison, i64 %207, i64 0
  %.splat87 = shufflevector <8 x i64> %.splatinsert86, <8 x i64> poison, <8 x i32> zeroinitializer
  %210 = mul <8 x i64> %.splat87, splat (i64 32)
  %211 = add <8 x i64> %209, %210
  %212 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %208, 0
  %213 = insertvalue { <8 x ptr>, <8 x i64> } %212, <8 x i64> %211, 1
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %213, 1
  %216 = extractelement <8 x ptr> %214, i32 0
  %217 = extractelement <8 x i64> %215, i32 0
  %218 = sub i64 %217, 0
  %219 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %220 = select i1 %219, i64 %218, i64 0
  %private.contiguous.address88 = getelementptr i8, ptr %216, i64 %220
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address88, align 4
  %221 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %207, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %224 = mul <8 x i64> %.splat91, splat (i64 32)
  %225 = add <8 x i64> %223, %224
  %226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %227 = insertvalue { <8 x ptr>, <8 x i64> } %226, <8 x i64> %225, 1
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %227, 1
  %230 = extractelement <8 x ptr> %228, i32 0
  %231 = extractelement <8 x i64> %229, i32 0
  %232 = sub i64 %231, 0
  %233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %234 = select i1 %233, i64 %232, i64 0
  %private.contiguous.address92 = getelementptr i8, ptr %230, i64 %234
  %private.contiguous.load93 = load <8 x float>, ptr %private.contiguous.address92, align 4
  %235 = select <8 x i1> %55, <8 x float> %private.contiguous.load93, <8 x float> zeroinitializer
  %236 = fmul <8 x float> %221, %235
  %tile_snapshot.spill.load94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 1
  %.splatinsert95 = insertelement <8 x i64> poison, i64 %207, i64 0
  %.splat96 = shufflevector <8 x i64> %.splatinsert95, <8 x i64> poison, <8 x i32> zeroinitializer
  %239 = mul <8 x i64> %.splat96, splat (i64 32)
  %240 = add <8 x i64> %238, %239
  %241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %237, 0
  %242 = insertvalue { <8 x ptr>, <8 x i64> } %241, <8 x i64> %240, 1
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %242, 1
  %245 = extractelement <8 x ptr> %243, i32 0
  %246 = extractelement <8 x i64> %244, i32 0
  %247 = sub i64 %246, 0
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %249 = select i1 %248, i64 %247, i64 0
  %private.contiguous.address97 = getelementptr i8, ptr %245, i64 %249
  %private.contiguous.load98 = load <8 x float>, ptr %private.contiguous.address97, align 4
  %250 = select <8 x i1> %55, <8 x float> %private.contiguous.load98, <8 x float> zeroinitializer
  %tile_snapshot.spill.load99 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 1
  %.splatinsert100 = insertelement <8 x i64> poison, i64 %207, i64 0
  %.splat101 = shufflevector <8 x i64> %.splatinsert100, <8 x i64> poison, <8 x i32> zeroinitializer
  %253 = mul <8 x i64> %.splat101, splat (i64 32)
  %254 = add <8 x i64> %252, %253
  %255 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %251, 0
  %256 = insertvalue { <8 x ptr>, <8 x i64> } %255, <8 x i64> %254, 1
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %256, 1
  %259 = extractelement <8 x ptr> %257, i32 0
  %260 = extractelement <8 x i64> %258, i32 0
  %261 = sub i64 %260, 0
  %262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %263 = select i1 %262, i64 %261, i64 0
  %private.contiguous.address102 = getelementptr i8, ptr %259, i64 %263
  %private.contiguous.load103 = load <8 x float>, ptr %private.contiguous.address102, align 4
  %264 = select <8 x i1> %55, <8 x float> %private.contiguous.load103, <8 x float> zeroinitializer
  %265 = fmul <8 x float> %250, %264
  %266 = fsub <8 x float> %236, %265
  %267 = extractvalue { ptr, i64 } %31, 0
  %268 = mul <8 x i64> %205, splat (i64 4)
  %269 = getelementptr i8, ptr %267, <8 x i64> %268
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %266, <8 x ptr> %269, i32 1, <8 x i1> %55)
  %.state104 = load i64, ptr %.slot16, align 4
  %270 = add i64 %.state104, 1
  store i64 %270, ptr %.slot16, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false79
  store i64 0, ptr %.slot17, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state105 = load i64, ptr %.slot17, align 4
  %271 = icmp slt i64 %.state105, 384
  br i1 %271, label %direct.true106, label %direct.false107

direct.schedule.17:                               ; preds = %direct.true106
  %.spill.load108 = load <8 x i64>, ptr %.spill, align 64
  %272 = add <8 x i64> %.spill.load108, zeroinitializer
  %273 = add <8 x i64> zeroinitializer, %272
  %.state109 = load i64, ptr %.slot17, align 4
  %274 = add i64 384, %.state109
  %275 = mul <8 x i64> %273, splat (i64 768)
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %274, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %276 = add <8 x i64> %275, %.splat111
  %.state112 = load i64, ptr %.slot17, align 4
  %277 = add i64 0, %.state112
  %278 = add i64 0, %277
  %tile_snapshot.spill.load113 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load113, 0
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load113, 1
  %.splatinsert114 = insertelement <8 x i64> poison, i64 %278, i64 0
  %.splat115 = shufflevector <8 x i64> %.splatinsert114, <8 x i64> poison, <8 x i32> zeroinitializer
  %281 = mul <8 x i64> %.splat115, splat (i64 32)
  %282 = add <8 x i64> %280, %281
  %283 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %279, 0
  %284 = insertvalue { <8 x ptr>, <8 x i64> } %283, <8 x i64> %282, 1
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %284, 1
  %287 = extractelement <8 x ptr> %285, i32 0
  %288 = extractelement <8 x i64> %286, i32 0
  %289 = sub i64 %288, 0
  %290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %291 = select i1 %290, i64 %289, i64 0
  %private.contiguous.address116 = getelementptr i8, ptr %287, i64 %291
  %private.contiguous.load117 = load <8 x float>, ptr %private.contiguous.address116, align 4
  %292 = select <8 x i1> %55, <8 x float> %private.contiguous.load117, <8 x float> zeroinitializer
  %tile_snapshot.spill.load118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 1
  %.splatinsert119 = insertelement <8 x i64> poison, i64 %278, i64 0
  %.splat120 = shufflevector <8 x i64> %.splatinsert119, <8 x i64> poison, <8 x i32> zeroinitializer
  %295 = mul <8 x i64> %.splat120, splat (i64 32)
  %296 = add <8 x i64> %294, %295
  %297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %293, 0
  %298 = insertvalue { <8 x ptr>, <8 x i64> } %297, <8 x i64> %296, 1
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %298, 1
  %301 = extractelement <8 x ptr> %299, i32 0
  %302 = extractelement <8 x i64> %300, i32 0
  %303 = sub i64 %302, 0
  %304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %305 = select i1 %304, i64 %303, i64 0
  %private.contiguous.address121 = getelementptr i8, ptr %301, i64 %305
  %private.contiguous.load122 = load <8 x float>, ptr %private.contiguous.address121, align 4
  %306 = select <8 x i1> %55, <8 x float> %private.contiguous.load122, <8 x float> zeroinitializer
  %307 = fmul <8 x float> %292, %306
  %tile_snapshot.spill.load123 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 1
  %.splatinsert124 = insertelement <8 x i64> poison, i64 %278, i64 0
  %.splat125 = shufflevector <8 x i64> %.splatinsert124, <8 x i64> poison, <8 x i32> zeroinitializer
  %310 = mul <8 x i64> %.splat125, splat (i64 32)
  %311 = add <8 x i64> %309, %310
  %312 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %313 = insertvalue { <8 x ptr>, <8 x i64> } %312, <8 x i64> %311, 1
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %316 = extractelement <8 x ptr> %314, i32 0
  %317 = extractelement <8 x i64> %315, i32 0
  %318 = sub i64 %317, 0
  %319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %320 = select i1 %319, i64 %318, i64 0
  %private.contiguous.address126 = getelementptr i8, ptr %316, i64 %320
  %private.contiguous.load127 = load <8 x float>, ptr %private.contiguous.address126, align 4
  %321 = select <8 x i1> %55, <8 x float> %private.contiguous.load127, <8 x float> zeroinitializer
  %tile_snapshot.spill.load128 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load128, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load128, 1
  %.splatinsert129 = insertelement <8 x i64> poison, i64 %278, i64 0
  %.splat130 = shufflevector <8 x i64> %.splatinsert129, <8 x i64> poison, <8 x i32> zeroinitializer
  %324 = mul <8 x i64> %.splat130, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address131 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.load132 = load <8 x float>, ptr %private.contiguous.address131, align 4
  %335 = select <8 x i1> %55, <8 x float> %private.contiguous.load132, <8 x float> zeroinitializer
  %336 = fmul <8 x float> %321, %335
  %337 = fadd <8 x float> %307, %336
  %338 = extractvalue { ptr, i64 } %31, 0
  %339 = mul <8 x i64> %276, splat (i64 4)
  %340 = getelementptr i8, ptr %338, <8 x i64> %339
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %337, <8 x ptr> %340, i32 1, <8 x i1> %55)
  %.state133 = load i64, ptr %.slot17, align 4
  %341 = add i64 %.state133, 1
  store i64 %341, ptr %.slot17, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false107
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true36:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false37:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true50:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false51:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true64:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false65:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true78:                                    ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false79:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true106:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false107:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [12288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [12288 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [12288 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [12288 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill10 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill10, align 64
  %.slot11 = alloca i64, align 8
  store i64 0, ptr %.slot11, align 4
  %tile_snapshot.spill12 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill12, align 64
  %.slot13 = alloca i64, align 8
  store i64 0, ptr %.slot13, align 4
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca i64, align 8
  store i64 0, ptr %.slot15, align 4
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat19, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat21, %45
  %48 = mul i32 %36, 1
  %.splatinsert22 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat23, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert24 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat25 = shufflevector <8 x i32> %.splatinsert24, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat25, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert26 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat27 = shufflevector <8 x i32> %.splatinsert26, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat27
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = zext <8 x i32> %57 to <8 x i64>
  %59 = select <8 x i1> %55, <8 x i64> %58, <8 x i64> zeroinitializer
  %60 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %61 = sdiv <8 x i64> %59, %60
  %62 = load <8 x i64>, ptr %.spill, align 64
  %63 = select <8 x i1> %55, <8 x i64> %61, <8 x i64> %62
  store <8 x i64> %63, ptr %.spill, align 64
  %64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %64, 0
  %67 = select <8 x i1> %55, <8 x ptr> %65, <8 x ptr> %66
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %64, 1
  %70 = select <8 x i1> %55, <8 x i64> %68, <8 x i64> %69
  %71 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %67, 0
  %72 = insertvalue { <8 x ptr>, <8 x i64> } %71, <8 x i64> %70, 1
  store { <8 x ptr>, <8 x i64> } %72, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %73 = icmp slt i64 %.state, 384
  br i1 %73, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %74 = add <8 x i64> %.spill.load, zeroinitializer
  %75 = add <8 x i64> zeroinitializer, %74
  %.state28 = load i64, ptr %.slot, align 4
  %76 = add i64 0, %.state28
  %77 = mul <8 x i64> %75, splat (i64 768)
  %.splatinsert29 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat30 = shufflevector <8 x i64> %.splatinsert29, <8 x i64> poison, <8 x i32> zeroinitializer
  %78 = add <8 x i64> %77, %.splat30
  %79 = extractvalue { ptr, i64 } %13, 0
  %80 = mul <8 x i64> %78, splat (i64 4)
  %81 = getelementptr i8, ptr %79, <8 x i64> %80
  %82 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %81, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %83 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %84 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state31 = load i64, ptr %.slot, align 4
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %.state31, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %85 = mul <8 x i64> %.splat33, splat (i64 32)
  %86 = add <8 x i64> %84, %85
  %87 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %83, 0
  %88 = insertvalue { <8 x ptr>, <8 x i64> } %87, <8 x i64> %86, 1
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %88, 1
  %91 = extractelement <8 x ptr> %89, i32 0
  %92 = extractelement <8 x i64> %90, i32 0
  %93 = sub i64 %92, 0
  %94 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %95 = select i1 %94, i64 %93, i64 0
  %private.contiguous.address = getelementptr i8, ptr %91, i64 %95
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %96 = select <8 x i1> %55, <8 x float> %82, <8 x float> %private.contiguous.preserve
  store <8 x float> %96, ptr %private.contiguous.address, align 4
  %.state34 = load i64, ptr %.slot, align 4
  %97 = add i64 %.state34, 1
  store i64 %97, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %98 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %98, 0
  %101 = select <8 x i1> %55, <8 x ptr> %99, <8 x ptr> %100
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %98, 1
  %104 = select <8 x i1> %55, <8 x i64> %102, <8 x i64> %103
  %105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %101, 0
  %106 = insertvalue { <8 x ptr>, <8 x i64> } %105, <8 x i64> %104, 1
  store { <8 x ptr>, <8 x i64> } %106, ptr %tile_snapshot.spill10, align 64
  store i64 0, ptr %.slot11, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state35 = load i64, ptr %.slot11, align 4
  %107 = icmp slt i64 %.state35, 384
  br i1 %107, label %direct.true36, label %direct.false37

direct.schedule.5:                                ; preds = %direct.true36
  %.spill.load38 = load <8 x i64>, ptr %.spill, align 64
  %108 = add <8 x i64> %.spill.load38, zeroinitializer
  %109 = add <8 x i64> zeroinitializer, %108
  %.state39 = load i64, ptr %.slot11, align 4
  %110 = add i64 384, %.state39
  %111 = mul <8 x i64> %109, splat (i64 768)
  %.splatinsert40 = insertelement <8 x i64> poison, i64 %110, i64 0
  %.splat41 = shufflevector <8 x i64> %.splatinsert40, <8 x i64> poison, <8 x i32> zeroinitializer
  %112 = add <8 x i64> %111, %.splat41
  %113 = extractvalue { ptr, i64 } %13, 0
  %114 = mul <8 x i64> %112, splat (i64 4)
  %115 = getelementptr i8, ptr %113, <8 x i64> %114
  %116 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %115, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load42 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load42, 0
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load42, 1
  %.state43 = load i64, ptr %.slot11, align 4
  %.splatinsert44 = insertelement <8 x i64> poison, i64 %.state43, i64 0
  %.splat45 = shufflevector <8 x i64> %.splatinsert44, <8 x i64> poison, <8 x i32> zeroinitializer
  %119 = mul <8 x i64> %.splat45, splat (i64 32)
  %120 = add <8 x i64> %118, %119
  %121 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %117, 0
  %122 = insertvalue { <8 x ptr>, <8 x i64> } %121, <8 x i64> %120, 1
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %122, 1
  %125 = extractelement <8 x ptr> %123, i32 0
  %126 = extractelement <8 x i64> %124, i32 0
  %127 = sub i64 %126, 0
  %128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %129 = select i1 %128, i64 %127, i64 0
  %private.contiguous.address46 = getelementptr i8, ptr %125, i64 %129
  %private.contiguous.preserve47 = load <8 x float>, ptr %private.contiguous.address46, align 4
  %130 = select <8 x i1> %55, <8 x float> %116, <8 x float> %private.contiguous.preserve47
  store <8 x float> %130, ptr %private.contiguous.address46, align 4
  %.state48 = load i64, ptr %.slot11, align 4
  %131 = add i64 %.state48, 1
  store i64 %131, ptr %.slot11, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false37
  %132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %132, 0
  %135 = select <8 x i1> %55, <8 x ptr> %133, <8 x ptr> %134
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %138 = select <8 x i1> %55, <8 x i64> %136, <8 x i64> %137
  %139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %135, 0
  %140 = insertvalue { <8 x ptr>, <8 x i64> } %139, <8 x i64> %138, 1
  store { <8 x ptr>, <8 x i64> } %140, ptr %tile_snapshot.spill12, align 64
  store i64 0, ptr %.slot13, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state49 = load i64, ptr %.slot13, align 4
  %141 = icmp slt i64 %.state49, 384
  br i1 %141, label %direct.true50, label %direct.false51

direct.schedule.8:                                ; preds = %direct.true50
  %.spill.load52 = load <8 x i64>, ptr %.spill, align 64
  %142 = add <8 x i64> %.spill.load52, zeroinitializer
  %143 = add <8 x i64> zeroinitializer, %142
  %.state53 = load i64, ptr %.slot13, align 4
  %144 = add i64 0, %.state53
  %145 = mul <8 x i64> %143, splat (i64 384)
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %144, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %146 = add <8 x i64> %145, %.splat55
  %147 = extractvalue { ptr, i64 } %19, 0
  %148 = mul <8 x i64> %146, splat (i64 4)
  %149 = getelementptr i8, ptr %147, <8 x i64> %148
  %150 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %149, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load56 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load56, 0
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load56, 1
  %.state57 = load i64, ptr %.slot13, align 4
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %.state57, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %153 = mul <8 x i64> %.splat59, splat (i64 32)
  %154 = add <8 x i64> %152, %153
  %155 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %151, 0
  %156 = insertvalue { <8 x ptr>, <8 x i64> } %155, <8 x i64> %154, 1
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %156, 1
  %159 = extractelement <8 x ptr> %157, i32 0
  %160 = extractelement <8 x i64> %158, i32 0
  %161 = sub i64 %160, 0
  %162 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %163 = select i1 %162, i64 %161, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %159, i64 %163
  %private.contiguous.preserve61 = load <8 x float>, ptr %private.contiguous.address60, align 4
  %164 = select <8 x i1> %55, <8 x float> %150, <8 x float> %private.contiguous.preserve61
  store <8 x float> %164, ptr %private.contiguous.address60, align 4
  %.state62 = load i64, ptr %.slot13, align 4
  %165 = add i64 %.state62, 1
  store i64 %165, ptr %.slot13, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false51
  %166 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %166, 0
  %169 = select <8 x i1> %55, <8 x ptr> %167, <8 x ptr> %168
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %166, 1
  %172 = select <8 x i1> %55, <8 x i64> %170, <8 x i64> %171
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %169, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  store { <8 x ptr>, <8 x i64> } %174, ptr %tile_snapshot.spill14, align 64
  store i64 0, ptr %.slot15, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state63 = load i64, ptr %.slot15, align 4
  %175 = icmp slt i64 %.state63, 384
  br i1 %175, label %direct.true64, label %direct.false65

direct.schedule.11:                               ; preds = %direct.true64
  %.spill.load66 = load <8 x i64>, ptr %.spill, align 64
  %176 = add <8 x i64> %.spill.load66, zeroinitializer
  %177 = add <8 x i64> zeroinitializer, %176
  %.state67 = load i64, ptr %.slot15, align 4
  %178 = add i64 0, %.state67
  %179 = mul <8 x i64> %177, splat (i64 384)
  %.splatinsert68 = insertelement <8 x i64> poison, i64 %178, i64 0
  %.splat69 = shufflevector <8 x i64> %.splatinsert68, <8 x i64> poison, <8 x i32> zeroinitializer
  %180 = add <8 x i64> %179, %.splat69
  %181 = extractvalue { ptr, i64 } %25, 0
  %182 = mul <8 x i64> %180, splat (i64 4)
  %183 = getelementptr i8, ptr %181, <8 x i64> %182
  %184 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %183, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 0
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 1
  %.state71 = load i64, ptr %.slot15, align 4
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %.state71, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %187 = mul <8 x i64> %.splat73, splat (i64 32)
  %188 = add <8 x i64> %186, %187
  %189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %185, 0
  %190 = insertvalue { <8 x ptr>, <8 x i64> } %189, <8 x i64> %188, 1
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %190, 1
  %193 = extractelement <8 x ptr> %191, i32 0
  %194 = extractelement <8 x i64> %192, i32 0
  %195 = sub i64 %194, 0
  %196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %197 = select i1 %196, i64 %195, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %193, i64 %197
  %private.contiguous.preserve75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %198 = select <8 x i1> %55, <8 x float> %184, <8 x float> %private.contiguous.preserve75
  store <8 x float> %198, ptr %private.contiguous.address74, align 4
  %.state76 = load i64, ptr %.slot15, align 4
  %199 = add i64 %.state76, 1
  store i64 %199, ptr %.slot15, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false65
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state77 = load i64, ptr %.slot16, align 4
  %200 = icmp slt i64 %.state77, 384
  br i1 %200, label %direct.true78, label %direct.false79

direct.schedule.14:                               ; preds = %direct.true78
  %.spill.load80 = load <8 x i64>, ptr %.spill, align 64
  %201 = add <8 x i64> %.spill.load80, zeroinitializer
  %202 = add <8 x i64> zeroinitializer, %201
  %.state81 = load i64, ptr %.slot16, align 4
  %203 = add i64 0, %.state81
  %204 = mul <8 x i64> %202, splat (i64 768)
  %.splatinsert82 = insertelement <8 x i64> poison, i64 %203, i64 0
  %.splat83 = shufflevector <8 x i64> %.splatinsert82, <8 x i64> poison, <8 x i32> zeroinitializer
  %205 = add <8 x i64> %204, %.splat83
  %.state84 = load i64, ptr %.slot16, align 4
  %206 = add i64 0, %.state84
  %207 = add i64 0, %206
  %tile_snapshot.spill.load85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 1
  %.splatinsert86 = insertelement <8 x i64> poison, i64 %207, i64 0
  %.splat87 = shufflevector <8 x i64> %.splatinsert86, <8 x i64> poison, <8 x i32> zeroinitializer
  %210 = mul <8 x i64> %.splat87, splat (i64 32)
  %211 = add <8 x i64> %209, %210
  %212 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %208, 0
  %213 = insertvalue { <8 x ptr>, <8 x i64> } %212, <8 x i64> %211, 1
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %213, 1
  %216 = extractelement <8 x ptr> %214, i32 0
  %217 = extractelement <8 x i64> %215, i32 0
  %218 = sub i64 %217, 0
  %219 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %220 = select i1 %219, i64 %218, i64 0
  %private.contiguous.address88 = getelementptr i8, ptr %216, i64 %220
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address88, align 4
  %221 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %207, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %224 = mul <8 x i64> %.splat91, splat (i64 32)
  %225 = add <8 x i64> %223, %224
  %226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %227 = insertvalue { <8 x ptr>, <8 x i64> } %226, <8 x i64> %225, 1
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %227, 1
  %230 = extractelement <8 x ptr> %228, i32 0
  %231 = extractelement <8 x i64> %229, i32 0
  %232 = sub i64 %231, 0
  %233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %234 = select i1 %233, i64 %232, i64 0
  %private.contiguous.address92 = getelementptr i8, ptr %230, i64 %234
  %private.contiguous.load93 = load <8 x float>, ptr %private.contiguous.address92, align 4
  %235 = select <8 x i1> %55, <8 x float> %private.contiguous.load93, <8 x float> zeroinitializer
  %236 = fmul <8 x float> %221, %235
  %tile_snapshot.spill.load94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 1
  %.splatinsert95 = insertelement <8 x i64> poison, i64 %207, i64 0
  %.splat96 = shufflevector <8 x i64> %.splatinsert95, <8 x i64> poison, <8 x i32> zeroinitializer
  %239 = mul <8 x i64> %.splat96, splat (i64 32)
  %240 = add <8 x i64> %238, %239
  %241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %237, 0
  %242 = insertvalue { <8 x ptr>, <8 x i64> } %241, <8 x i64> %240, 1
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %242, 1
  %245 = extractelement <8 x ptr> %243, i32 0
  %246 = extractelement <8 x i64> %244, i32 0
  %247 = sub i64 %246, 0
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %249 = select i1 %248, i64 %247, i64 0
  %private.contiguous.address97 = getelementptr i8, ptr %245, i64 %249
  %private.contiguous.load98 = load <8 x float>, ptr %private.contiguous.address97, align 4
  %250 = select <8 x i1> %55, <8 x float> %private.contiguous.load98, <8 x float> zeroinitializer
  %tile_snapshot.spill.load99 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 1
  %.splatinsert100 = insertelement <8 x i64> poison, i64 %207, i64 0
  %.splat101 = shufflevector <8 x i64> %.splatinsert100, <8 x i64> poison, <8 x i32> zeroinitializer
  %253 = mul <8 x i64> %.splat101, splat (i64 32)
  %254 = add <8 x i64> %252, %253
  %255 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %251, 0
  %256 = insertvalue { <8 x ptr>, <8 x i64> } %255, <8 x i64> %254, 1
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %256, 1
  %259 = extractelement <8 x ptr> %257, i32 0
  %260 = extractelement <8 x i64> %258, i32 0
  %261 = sub i64 %260, 0
  %262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %263 = select i1 %262, i64 %261, i64 0
  %private.contiguous.address102 = getelementptr i8, ptr %259, i64 %263
  %private.contiguous.load103 = load <8 x float>, ptr %private.contiguous.address102, align 4
  %264 = select <8 x i1> %55, <8 x float> %private.contiguous.load103, <8 x float> zeroinitializer
  %265 = fmul <8 x float> %250, %264
  %266 = fsub <8 x float> %236, %265
  %267 = extractvalue { ptr, i64 } %31, 0
  %268 = mul <8 x i64> %205, splat (i64 4)
  %269 = getelementptr i8, ptr %267, <8 x i64> %268
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %266, <8 x ptr> %269, i32 1, <8 x i1> %55)
  %.state104 = load i64, ptr %.slot16, align 4
  %270 = add i64 %.state104, 1
  store i64 %270, ptr %.slot16, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false79
  store i64 0, ptr %.slot17, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state105 = load i64, ptr %.slot17, align 4
  %271 = icmp slt i64 %.state105, 384
  br i1 %271, label %direct.true106, label %direct.false107

direct.schedule.17:                               ; preds = %direct.true106
  %.spill.load108 = load <8 x i64>, ptr %.spill, align 64
  %272 = add <8 x i64> %.spill.load108, zeroinitializer
  %273 = add <8 x i64> zeroinitializer, %272
  %.state109 = load i64, ptr %.slot17, align 4
  %274 = add i64 384, %.state109
  %275 = mul <8 x i64> %273, splat (i64 768)
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %274, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %276 = add <8 x i64> %275, %.splat111
  %.state112 = load i64, ptr %.slot17, align 4
  %277 = add i64 0, %.state112
  %278 = add i64 0, %277
  %tile_snapshot.spill.load113 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load113, 0
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load113, 1
  %.splatinsert114 = insertelement <8 x i64> poison, i64 %278, i64 0
  %.splat115 = shufflevector <8 x i64> %.splatinsert114, <8 x i64> poison, <8 x i32> zeroinitializer
  %281 = mul <8 x i64> %.splat115, splat (i64 32)
  %282 = add <8 x i64> %280, %281
  %283 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %279, 0
  %284 = insertvalue { <8 x ptr>, <8 x i64> } %283, <8 x i64> %282, 1
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %284, 1
  %287 = extractelement <8 x ptr> %285, i32 0
  %288 = extractelement <8 x i64> %286, i32 0
  %289 = sub i64 %288, 0
  %290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %291 = select i1 %290, i64 %289, i64 0
  %private.contiguous.address116 = getelementptr i8, ptr %287, i64 %291
  %private.contiguous.load117 = load <8 x float>, ptr %private.contiguous.address116, align 4
  %292 = select <8 x i1> %55, <8 x float> %private.contiguous.load117, <8 x float> zeroinitializer
  %tile_snapshot.spill.load118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 1
  %.splatinsert119 = insertelement <8 x i64> poison, i64 %278, i64 0
  %.splat120 = shufflevector <8 x i64> %.splatinsert119, <8 x i64> poison, <8 x i32> zeroinitializer
  %295 = mul <8 x i64> %.splat120, splat (i64 32)
  %296 = add <8 x i64> %294, %295
  %297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %293, 0
  %298 = insertvalue { <8 x ptr>, <8 x i64> } %297, <8 x i64> %296, 1
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %298, 1
  %301 = extractelement <8 x ptr> %299, i32 0
  %302 = extractelement <8 x i64> %300, i32 0
  %303 = sub i64 %302, 0
  %304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %305 = select i1 %304, i64 %303, i64 0
  %private.contiguous.address121 = getelementptr i8, ptr %301, i64 %305
  %private.contiguous.load122 = load <8 x float>, ptr %private.contiguous.address121, align 4
  %306 = select <8 x i1> %55, <8 x float> %private.contiguous.load122, <8 x float> zeroinitializer
  %307 = fmul <8 x float> %292, %306
  %tile_snapshot.spill.load123 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 1
  %.splatinsert124 = insertelement <8 x i64> poison, i64 %278, i64 0
  %.splat125 = shufflevector <8 x i64> %.splatinsert124, <8 x i64> poison, <8 x i32> zeroinitializer
  %310 = mul <8 x i64> %.splat125, splat (i64 32)
  %311 = add <8 x i64> %309, %310
  %312 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %313 = insertvalue { <8 x ptr>, <8 x i64> } %312, <8 x i64> %311, 1
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %316 = extractelement <8 x ptr> %314, i32 0
  %317 = extractelement <8 x i64> %315, i32 0
  %318 = sub i64 %317, 0
  %319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %320 = select i1 %319, i64 %318, i64 0
  %private.contiguous.address126 = getelementptr i8, ptr %316, i64 %320
  %private.contiguous.load127 = load <8 x float>, ptr %private.contiguous.address126, align 4
  %321 = select <8 x i1> %55, <8 x float> %private.contiguous.load127, <8 x float> zeroinitializer
  %tile_snapshot.spill.load128 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load128, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load128, 1
  %.splatinsert129 = insertelement <8 x i64> poison, i64 %278, i64 0
  %.splat130 = shufflevector <8 x i64> %.splatinsert129, <8 x i64> poison, <8 x i32> zeroinitializer
  %324 = mul <8 x i64> %.splat130, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address131 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.load132 = load <8 x float>, ptr %private.contiguous.address131, align 4
  %335 = select <8 x i1> %55, <8 x float> %private.contiguous.load132, <8 x float> zeroinitializer
  %336 = fmul <8 x float> %321, %335
  %337 = fadd <8 x float> %307, %336
  %338 = extractvalue { ptr, i64 } %31, 0
  %339 = mul <8 x i64> %276, splat (i64 4)
  %340 = getelementptr i8, ptr %338, <8 x i64> %339
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %337, <8 x ptr> %340, i32 1, <8 x i1> %55)
  %.state133 = load i64, ptr %.slot17, align 4
  %341 = add i64 %.state133, 1
  store i64 %341, ptr %.slot17, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false107
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true36:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false37:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true50:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false51:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true64:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false65:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true78:                                    ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false79:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true106:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false107:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

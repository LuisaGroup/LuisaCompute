; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 24576
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 73728
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 768, i64 1536, i64 2304, i64 3072, i64 3840, i64 4608, i64 5376>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 79872
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 104448
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %.spill19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill19, align 64
  %tile_snapshot.spill20 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill20, align 64
  %.slot21 = alloca i64, align 8
  store i64 0, ptr %.slot21, align 4
  %.spill22 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill22, align 4
  %tile_snapshot.spill23 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill23, align 64
  %.slot24 = alloca i64, align 8
  store i64 0, ptr %.slot24, align 4
  %.spill25 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill25, align 4
  %.spill26 = alloca i64, align 8
  store i64 0, ptr %.spill26, align 4
  %.spill27 = alloca i64, align 8
  store i64 0, ptr %.spill27, align 4
  %.spill28 = alloca i64, align 8
  store i64 0, ptr %.spill28, align 4
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca i64, align 8
  store i64 0, ptr %.spill30, align 4
  %.slot31 = alloca i64, align 8
  store i64 0, ptr %.slot31, align 4
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.spill36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill36, align 32
  %.spill37 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.slot40 = alloca i64, align 8
  store i64 0, ptr %.slot40, align 4
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.spill45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %15 = getelementptr i8, ptr %argument_buffer, i64 0
  %16 = load ptr, ptr %15, align 16
  %17 = getelementptr i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  %21 = getelementptr i8, ptr %argument_buffer, i64 16
  %22 = load ptr, ptr %21, align 16
  %23 = getelementptr i8, ptr %21, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = insertvalue { ptr, i64 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i64 } %25, i64 %24, 1
  %27 = getelementptr i8, ptr %argument_buffer, i64 32
  %28 = load ptr, ptr %27, align 16
  %29 = getelementptr i8, ptr %27, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { ptr, i64 } poison, ptr %28, 0
  %32 = insertvalue { ptr, i64 } %31, i64 %30, 1
  %33 = getelementptr i8, ptr %argument_buffer, i64 48
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = load i32, ptr %launch_config, align 4
  %40 = getelementptr i8, ptr %launch_config, i64 12
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr i8, ptr %launch_config, i64 4
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %launch_config, i64 16
  %45 = load i32, ptr %44, align 4
  %46 = getelementptr i8, ptr %launch_config, i64 8
  %47 = load i32, ptr %46, align 4
  %48 = getelementptr i8, ptr %launch_config, i64 20
  %49 = load i32, ptr %48, align 4
  %50 = getelementptr i8, ptr %launch_config, i64 36
  %51 = load i32, ptr %50, align 4
  %.splatinsert47 = insertelement <8 x i32> poison, i32 %51, i64 0
  %.splat48 = shufflevector <8 x i32> %.splatinsert47, <8 x i32> poison, <8 x i32> zeroinitializer
  %52 = add <8 x i32> %.splat48, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %53 = mul i32 %39, 32
  %.splatinsert49 = insertelement <8 x i32> poison, i32 %53, i64 0
  %.splat50 = shufflevector <8 x i32> %.splatinsert49, <8 x i32> poison, <8 x i32> zeroinitializer
  %54 = add <8 x i32> %.splat50, %52
  %55 = mul i32 %43, 1
  %.splatinsert51 = insertelement <8 x i32> poison, i32 %55, i64 0
  %.splat52 = shufflevector <8 x i32> %.splatinsert51, <8 x i32> poison, <8 x i32> zeroinitializer
  %56 = add <8 x i32> %.splat52, zeroinitializer
  %57 = mul i32 %47, 1
  %.splatinsert53 = insertelement <8 x i32> poison, i32 %57, i64 0
  %.splat54 = shufflevector <8 x i32> %.splatinsert53, <8 x i32> poison, <8 x i32> zeroinitializer
  %58 = add <8 x i32> %.splat54, zeroinitializer
  %59 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %54, 0
  %60 = insertvalue [3 x <8 x i32>] %59, <8 x i32> %56, 1
  %61 = insertvalue [3 x <8 x i32>] %60, <8 x i32> %58, 2
  %.splatinsert55 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat56 = shufflevector <8 x i32> %.splatinsert55, <8 x i32> poison, <8 x i32> zeroinitializer
  %62 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat56
  %63 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  br i1 %63, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %64 = extractvalue [3 x <8 x i32>] %61, 0
  %65 = zext <8 x i32> %64 to <8 x i64>
  %66 = select <8 x i1> %62, <8 x i64> %65, <8 x i64> zeroinitializer
  %67 = select <8 x i1> %62, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %68 = sdiv <8 x i64> %66, %67
  %69 = load <8 x i64>, ptr %.spill, align 64
  %70 = select <8 x i1> %62, <8 x i64> %68, <8 x i64> %69
  store <8 x i64> %70, ptr %.spill, align 64
  %71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %71, 0
  %74 = select <8 x i1> %62, <8 x ptr> %72, <8 x ptr> %73
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %71, 1
  %77 = select <8 x i1> %62, <8 x i64> %75, <8 x i64> %76
  %78 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %74, 0
  %79 = insertvalue { <8 x ptr>, <8 x i64> } %78, <8 x i64> %77, 1
  store { <8 x ptr>, <8 x i64> } %79, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %80 = icmp slt i64 %.state, 768
  br i1 %80, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.spill.load, zeroinitializer
  %82 = add <8 x i64> zeroinitializer, %81
  %.state57 = load i64, ptr %.slot, align 4
  %83 = add i64 0, %.state57
  %84 = mul <8 x i64> %82, splat (i64 768)
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %83, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %85 = add <8 x i64> %84, %.splat59
  %86 = extractvalue { ptr, i64 } %20, 0
  %87 = mul <8 x i64> %85, splat (i64 4)
  %88 = getelementptr i8, ptr %86, <8 x i64> %87
  %89 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %88, i32 1, <8 x i1> %62, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state60 = load i64, ptr %.slot, align 4
  %.splatinsert61 = insertelement <8 x i64> poison, i64 %.state60, i64 0
  %.splat62 = shufflevector <8 x i64> %.splatinsert61, <8 x i64> poison, <8 x i32> zeroinitializer
  %92 = mul <8 x i64> %.splat62, splat (i64 32)
  %93 = add <8 x i64> %91, %92
  %94 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %90, 0
  %95 = insertvalue { <8 x ptr>, <8 x i64> } %94, <8 x i64> %93, 1
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %95, 1
  %98 = extractelement <8 x ptr> %96, i32 0
  %99 = extractelement <8 x i64> %97, i32 0
  %100 = sub i64 %99, 0
  %101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %102 = select i1 %101, i64 %100, i64 0
  %private.contiguous.address = getelementptr i8, ptr %98, i64 %102
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %103 = select <8 x i1> %62, <8 x float> %89, <8 x float> %private.contiguous.preserve
  store <8 x float> %103, ptr %private.contiguous.address, align 4
  %.state63 = load i64, ptr %.slot, align 4
  %104 = add i64 %.state63, 1
  store i64 %104, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %105 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %105, 0
  %108 = select <8 x i1> %62, <8 x ptr> %106, <8 x ptr> %107
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %105, 1
  %111 = select <8 x i1> %62, <8 x i64> %109, <8 x i64> %110
  %112 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %108, 0
  %113 = insertvalue { <8 x ptr>, <8 x i64> } %112, <8 x i64> %111, 1
  store { <8 x ptr>, <8 x i64> } %113, ptr %tile_snapshot.spill17, align 64
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state64 = load i64, ptr %.slot18, align 4
  %114 = icmp slt i64 %.state64, 768
  br i1 %114, label %direct.true65, label %direct.false66

direct.schedule.5:                                ; preds = %direct.true65
  %tile_snapshot.spill.load67 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 1
  %.state68 = load i64, ptr %.slot18, align 4
  %.splatinsert69 = insertelement <8 x i64> poison, i64 %.state68, i64 0
  %.splat70 = shufflevector <8 x i64> %.splatinsert69, <8 x i64> poison, <8 x i32> zeroinitializer
  %117 = mul <8 x i64> %.splat70, splat (i64 64)
  %118 = add <8 x i64> %116, %117
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %.state71 = load i64, ptr %.slot18, align 4
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %.state71, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve75 = load <8 x i64>, ptr %private.contiguous.address74, align 8
  %128 = select <8 x i1> %62, <8 x i64> %.splat73, <8 x i64> %private.contiguous.preserve75
  store <8 x i64> %128, ptr %private.contiguous.address74, align 8
  %.state76 = load i64, ptr %.slot18, align 4
  %129 = add i64 %.state76, 1
  store i64 %129, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false66
  %.spill.load77 = load <8 x i64>, ptr %.spill, align 64
  %130 = select <8 x i1> %62, <8 x i64> %.spill.load77, <8 x i64> zeroinitializer
  %131 = select <8 x i1> %62, <8 x i64> splat (i64 768), <8 x i64> splat (i64 1)
  %132 = srem <8 x i64> %130, %131
  %133 = load <8 x i64>, ptr %.spill19, align 64
  %134 = select <8 x i1> %62, <8 x i64> %132, <8 x i64> %133
  store <8 x i64> %134, ptr %.spill19, align 64
  %135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %135, 0
  %138 = select <8 x i1> %62, <8 x ptr> %136, <8 x ptr> %137
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %135, 1
  %141 = select <8 x i1> %62, <8 x i64> %139, <8 x i64> %140
  %142 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %138, 0
  %143 = insertvalue { <8 x ptr>, <8 x i64> } %142, <8 x i64> %141, 1
  store { <8 x ptr>, <8 x i64> } %143, ptr %tile_snapshot.spill20, align 64
  store i64 0, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state78 = load i64, ptr %.slot21, align 4
  %144 = icmp slt i64 %.state78, 768
  br i1 %144, label %direct.true79, label %direct.false80

direct.schedule.8:                                ; preds = %direct.true79
  %.state81 = load i64, ptr %.slot21, align 4
  %145 = add i64 0, %.state81
  %tile_snapshot.spill.load82 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 1
  %.splatinsert83 = insertelement <8 x i64> poison, i64 %145, i64 0
  %.splat84 = shufflevector <8 x i64> %.splatinsert83, <8 x i64> poison, <8 x i32> zeroinitializer
  %148 = mul <8 x i64> %.splat84, splat (i64 64)
  %149 = add <8 x i64> %147, %148
  %150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %146, 0
  %151 = insertvalue { <8 x ptr>, <8 x i64> } %150, <8 x i64> %149, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %154 = extractelement <8 x ptr> %152, i32 0
  %155 = extractelement <8 x i64> %153, i32 0
  %156 = sub i64 %155, 0
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %158 = select i1 %157, i64 %156, i64 0
  %private.contiguous.address85 = getelementptr i8, ptr %154, i64 %158
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address85, align 8
  %159 = select <8 x i1> %62, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load86 = load <8 x i64>, ptr %.spill19, align 64
  %160 = icmp sle <8 x i64> %159, %.spill.load86
  %tile_snapshot.spill.load87 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 1
  %.state88 = load i64, ptr %.slot21, align 4
  %.splatinsert89 = insertelement <8 x i64> poison, i64 %.state88, i64 0
  %.splat90 = shufflevector <8 x i64> %.splatinsert89, <8 x i64> poison, <8 x i32> zeroinitializer
  %163 = add <8 x i64> %162, %.splat90
  %164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %161, 0
  %165 = insertvalue { <8 x ptr>, <8 x i64> } %164, <8 x i64> %163, 1
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %168 = getelementptr i8, <8 x ptr> %166, <8 x i64> %167
  %169 = zext <8 x i1> %160 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %169, <8 x ptr> %168, i32 1, <8 x i1> %62)
  %.state91 = load i64, ptr %.slot21, align 4
  %170 = add i64 %.state91, 1
  store i64 %170, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false80
  store float 0xC6293E5940000000, ptr %.spill22, align 4
  %171 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 0
  %174 = select <8 x i1> %62, <8 x ptr> %172, <8 x ptr> %173
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %177 = select <8 x i1> %62, <8 x i64> %175, <8 x i64> %176
  %178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %174, 0
  %179 = insertvalue { <8 x ptr>, <8 x i64> } %178, <8 x i64> %177, 1
  store { <8 x ptr>, <8 x i64> } %179, ptr %tile_snapshot.spill23, align 64
  store i64 0, ptr %.slot24, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state92 = load i64, ptr %.slot24, align 4
  %180 = icmp slt i64 %.state92, 768
  br i1 %180, label %direct.true93, label %direct.false94

direct.schedule.11:                               ; preds = %direct.true93
  %.state95 = load i64, ptr %.slot24, align 4
  %181 = add i64 0, %.state95
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.splatinsert97 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat98 = shufflevector <8 x i64> %.splatinsert97, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = add <8 x i64> %183, %.splat98
  %185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %182, 0
  %186 = insertvalue { <8 x ptr>, <8 x i64> } %185, <8 x i64> %184, 1
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %186, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %186, 1
  %189 = getelementptr i8, <8 x ptr> %187, <8 x i64> %188
  %190 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %189, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %191 = icmp ne <8 x i8> %190, zeroinitializer
  %tile_snapshot.spill.load99 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 1
  %.splatinsert100 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat101 = shufflevector <8 x i64> %.splatinsert100, <8 x i64> poison, <8 x i32> zeroinitializer
  %194 = mul <8 x i64> %.splat101, splat (i64 32)
  %195 = add <8 x i64> %193, %194
  %196 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %192, 0
  %197 = insertvalue { <8 x ptr>, <8 x i64> } %196, <8 x i64> %195, 1
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %197, 1
  %200 = extractelement <8 x ptr> %198, i32 0
  %201 = extractelement <8 x i64> %199, i32 0
  %202 = sub i64 %201, 0
  %203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %204 = select i1 %203, i64 %202, i64 0
  %private.contiguous.address102 = getelementptr i8, ptr %200, i64 %204
  %private.contiguous.load103 = load <8 x float>, ptr %private.contiguous.address102, align 4
  %205 = select <8 x i1> %62, <8 x float> %private.contiguous.load103, <8 x float> zeroinitializer
  %.spill.load104 = load float, ptr %.spill22, align 4
  %.splatinsert105 = insertelement <8 x float> poison, float %.spill.load104, i64 0
  %.splat106 = shufflevector <8 x float> %.splatinsert105, <8 x float> poison, <8 x i32> zeroinitializer
  %206 = select <8 x i1> %191, <8 x float> %205, <8 x float> %.splat106
  %tile_snapshot.spill.load107 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 0
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 1
  %.state108 = load i64, ptr %.slot24, align 4
  %.splatinsert109 = insertelement <8 x i64> poison, i64 %.state108, i64 0
  %.splat110 = shufflevector <8 x i64> %.splatinsert109, <8 x i64> poison, <8 x i32> zeroinitializer
  %209 = mul <8 x i64> %.splat110, splat (i64 32)
  %210 = add <8 x i64> %208, %209
  %211 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %207, 0
  %212 = insertvalue { <8 x ptr>, <8 x i64> } %211, <8 x i64> %210, 1
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %212, 1
  %215 = extractelement <8 x ptr> %213, i32 0
  %216 = extractelement <8 x i64> %214, i32 0
  %217 = sub i64 %216, 0
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %219 = select i1 %218, i64 %217, i64 0
  %private.contiguous.address111 = getelementptr i8, ptr %215, i64 %219
  %private.contiguous.preserve112 = load <8 x float>, ptr %private.contiguous.address111, align 4
  %220 = select <8 x i1> %62, <8 x float> %206, <8 x float> %private.contiguous.preserve112
  store <8 x float> %220, ptr %private.contiguous.address111, align 4
  %.state113 = load i64, ptr %.slot24, align 4
  %221 = add i64 %.state113, 1
  store i64 %221, ptr %.slot24, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false94
  store float 0xFFF0000000000000, ptr %.spill25, align 4
  store i64 0, ptr %.spill26, align 4
  store i64 0, ptr %.spill27, align 4
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %224 = add <8 x i64> %223, zeroinitializer
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = extractelement <8 x ptr> %227, i32 0
  %230 = extractelement <8 x i64> %228, i32 0
  %231 = sub i64 %230, 0
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %233 = select i1 %232, i64 %231, i64 0
  %private.contiguous.address115 = getelementptr i8, ptr %229, i64 %233
  %private.contiguous.load116 = load <8 x float>, ptr %private.contiguous.address115, align 4
  %234 = select <8 x i1> %62, <8 x float> %private.contiguous.load116, <8 x float> zeroinitializer
  store i64 1, ptr %.spill28, align 4
  %tile_snapshot.spill.load117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 1
  %237 = add <8 x i64> %236, splat (i64 32)
  %238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %235, 0
  %239 = insertvalue { <8 x ptr>, <8 x i64> } %238, <8 x i64> %237, 1
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %239, 1
  %242 = extractelement <8 x ptr> %240, i32 0
  %243 = extractelement <8 x i64> %241, i32 0
  %244 = sub i64 %243, 0
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %246 = select i1 %245, i64 %244, i64 0
  %private.contiguous.address118 = getelementptr i8, ptr %242, i64 %246
  %private.contiguous.load119 = load <8 x float>, ptr %private.contiguous.address118, align 4
  %247 = select <8 x i1> %62, <8 x float> %private.contiguous.load119, <8 x float> zeroinitializer
  store i64 2, ptr %.spill29, align 4
  %tile_snapshot.spill.load120 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 1
  %250 = add <8 x i64> %249, splat (i64 64)
  %251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %252 = insertvalue { <8 x ptr>, <8 x i64> } %251, <8 x i64> %250, 1
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %255 = extractelement <8 x ptr> %253, i32 0
  %256 = extractelement <8 x i64> %254, i32 0
  %257 = sub i64 %256, 0
  %258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %259 = select i1 %258, i64 %257, i64 0
  %private.contiguous.address121 = getelementptr i8, ptr %255, i64 %259
  %private.contiguous.load122 = load <8 x float>, ptr %private.contiguous.address121, align 4
  %260 = select <8 x i1> %62, <8 x float> %private.contiguous.load122, <8 x float> zeroinitializer
  store i64 3, ptr %.spill30, align 4
  %tile_snapshot.spill.load123 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 1
  %263 = add <8 x i64> %262, splat (i64 96)
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = extractelement <8 x ptr> %266, i32 0
  %269 = extractelement <8 x i64> %267, i32 0
  %270 = sub i64 %269, 0
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %272 = select i1 %271, i64 %270, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %268, i64 %272
  %private.contiguous.load125 = load <8 x float>, ptr %private.contiguous.address124, align 4
  %273 = select <8 x i1> %62, <8 x float> %private.contiguous.load125, <8 x float> zeroinitializer
  store i64 4, ptr %.slot31, align 4
  %274 = load <8 x float>, ptr %.slot32, align 32
  %275 = select <8 x i1> %62, <8 x float> %234, <8 x float> %274
  store <8 x float> %275, ptr %.slot32, align 32
  %276 = load <8 x float>, ptr %.slot33, align 32
  %277 = select <8 x i1> %62, <8 x float> %247, <8 x float> %276
  store <8 x float> %277, ptr %.slot33, align 32
  %278 = load <8 x float>, ptr %.slot34, align 32
  %279 = select <8 x i1> %62, <8 x float> %260, <8 x float> %278
  store <8 x float> %279, ptr %.slot34, align 32
  %280 = load <8 x float>, ptr %.slot35, align 32
  %281 = select <8 x i1> %62, <8 x float> %273, <8 x float> %280
  store <8 x float> %281, ptr %.slot35, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state126 = load i64, ptr %.slot31, align 4
  %282 = icmp slt i64 %.state126, 768
  br i1 %282, label %direct.true127, label %direct.false128

direct.schedule.14:                               ; preds = %direct.true127
  %.state129 = load i64, ptr %.slot31, align 4
  %283 = add i64 %.state129, 0
  %284 = sdiv i64 %283, 1
  %.spill.load130 = load i64, ptr %.spill26, align 4
  %285 = add i64 %.spill.load130, %284
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %285, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %288 = mul <8 x i64> %.splat133, splat (i64 32)
  %289 = add <8 x i64> %287, %288
  %290 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %286, 0
  %291 = insertvalue { <8 x ptr>, <8 x i64> } %290, <8 x i64> %289, 1
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %291, 1
  %294 = extractelement <8 x ptr> %292, i32 0
  %295 = extractelement <8 x i64> %293, i32 0
  %296 = sub i64 %295, 0
  %297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %298 = select i1 %297, i64 %296, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %294, i64 %298
  %private.contiguous.load135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %299 = select <8 x i1> %62, <8 x float> %private.contiguous.load135, <8 x float> zeroinitializer
  %.state136 = load <8 x float>, ptr %.slot32, align 32
  %300 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state136, <8 x float> %299)
  %.state137 = load i64, ptr %.slot31, align 4
  %301 = add i64 %.state137, 1
  %302 = sdiv i64 %301, 1
  %.spill.load138 = load i64, ptr %.spill26, align 4
  %303 = add i64 %.spill.load138, %302
  %tile_snapshot.spill.load139 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 1
  %.splatinsert140 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat141 = shufflevector <8 x i64> %.splatinsert140, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat141, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %317 = select <8 x i1> %62, <8 x float> %private.contiguous.load143, <8 x float> zeroinitializer
  %.state144 = load <8 x float>, ptr %.slot33, align 32
  %318 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state144, <8 x float> %317)
  %.state145 = load i64, ptr %.slot31, align 4
  %319 = add i64 %.state145, 2
  %320 = sdiv i64 %319, 1
  %.spill.load146 = load i64, ptr %.spill26, align 4
  %321 = add i64 %.spill.load146, %320
  %tile_snapshot.spill.load147 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %.splatinsert148 = insertelement <8 x i64> poison, i64 %321, i64 0
  %.splat149 = shufflevector <8 x i64> %.splatinsert148, <8 x i64> poison, <8 x i32> zeroinitializer
  %324 = mul <8 x i64> %.splat149, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address150 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.load151 = load <8 x float>, ptr %private.contiguous.address150, align 4
  %335 = select <8 x i1> %62, <8 x float> %private.contiguous.load151, <8 x float> zeroinitializer
  %.state152 = load <8 x float>, ptr %.slot34, align 32
  %336 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state152, <8 x float> %335)
  %.state153 = load i64, ptr %.slot31, align 4
  %337 = add i64 %.state153, 3
  %338 = sdiv i64 %337, 1
  %.spill.load154 = load i64, ptr %.spill26, align 4
  %339 = add i64 %.spill.load154, %338
  %tile_snapshot.spill.load155 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load155, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load155, 1
  %.splatinsert156 = insertelement <8 x i64> poison, i64 %339, i64 0
  %.splat157 = shufflevector <8 x i64> %.splatinsert156, <8 x i64> poison, <8 x i32> zeroinitializer
  %342 = mul <8 x i64> %.splat157, splat (i64 32)
  %343 = add <8 x i64> %341, %342
  %344 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %340, 0
  %345 = insertvalue { <8 x ptr>, <8 x i64> } %344, <8 x i64> %343, 1
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %345, 1
  %348 = extractelement <8 x ptr> %346, i32 0
  %349 = extractelement <8 x i64> %347, i32 0
  %350 = sub i64 %349, 0
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %352 = select i1 %351, i64 %350, i64 0
  %private.contiguous.address158 = getelementptr i8, ptr %348, i64 %352
  %private.contiguous.load159 = load <8 x float>, ptr %private.contiguous.address158, align 4
  %353 = select <8 x i1> %62, <8 x float> %private.contiguous.load159, <8 x float> zeroinitializer
  %.state160 = load <8 x float>, ptr %.slot35, align 32
  %354 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state160, <8 x float> %353)
  %.state161 = load i64, ptr %.slot31, align 4
  %355 = add i64 %.state161, 4
  store i64 %355, ptr %.slot31, align 4
  %356 = load <8 x float>, ptr %.slot32, align 32
  %357 = select <8 x i1> %62, <8 x float> %300, <8 x float> %356
  store <8 x float> %357, ptr %.slot32, align 32
  %358 = load <8 x float>, ptr %.slot33, align 32
  %359 = select <8 x i1> %62, <8 x float> %318, <8 x float> %358
  store <8 x float> %359, ptr %.slot33, align 32
  %360 = load <8 x float>, ptr %.slot34, align 32
  %361 = select <8 x i1> %62, <8 x float> %336, <8 x float> %360
  store <8 x float> %361, ptr %.slot34, align 32
  %362 = load <8 x float>, ptr %.slot35, align 32
  %363 = select <8 x i1> %62, <8 x float> %354, <8 x float> %362
  store <8 x float> %363, ptr %.slot35, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false128
  %.spill.load162 = load float, ptr %.spill25, align 4
  %.splatinsert163 = insertelement <8 x float> poison, float %.spill.load162, i64 0
  %.splat164 = shufflevector <8 x float> %.splatinsert163, <8 x float> poison, <8 x i32> zeroinitializer
  %.state165 = load <8 x float>, ptr %.slot32, align 32
  %364 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.splat164, <8 x float> %.state165)
  %.state166 = load <8 x float>, ptr %.slot33, align 32
  %365 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %364, <8 x float> %.state166)
  %.state167 = load <8 x float>, ptr %.slot34, align 32
  %366 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %365, <8 x float> %.state167)
  %.state168 = load <8 x float>, ptr %.slot35, align 32
  %367 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %366, <8 x float> %.state168)
  %368 = load <8 x float>, ptr %.spill36, align 32
  %369 = select <8 x i1> %62, <8 x float> %367, <8 x float> %368
  store <8 x float> %369, ptr %.spill36, align 32
  store float 0.000000e+00, ptr %.spill37, align 4
  %370 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %370, 0
  %373 = select <8 x i1> %62, <8 x ptr> %371, <8 x ptr> %372
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %375 = extractvalue { <8 x ptr>, <8 x i64> } %370, 1
  %376 = select <8 x i1> %62, <8 x i64> %374, <8 x i64> %375
  %377 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %373, 0
  %378 = insertvalue { <8 x ptr>, <8 x i64> } %377, <8 x i64> %376, 1
  store { <8 x ptr>, <8 x i64> } %378, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state169 = load i64, ptr %.slot39, align 4
  %379 = icmp slt i64 %.state169, 768
  br i1 %379, label %direct.true170, label %direct.false171

direct.schedule.17:                               ; preds = %direct.true170
  %.state172 = load i64, ptr %.slot39, align 4
  %380 = add i64 0, %.state172
  %tile_snapshot.spill.load173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 0
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 1
  %.splatinsert174 = insertelement <8 x i64> poison, i64 %380, i64 0
  %.splat175 = shufflevector <8 x i64> %.splatinsert174, <8 x i64> poison, <8 x i32> zeroinitializer
  %383 = add <8 x i64> %382, %.splat175
  %384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %381, 0
  %385 = insertvalue { <8 x ptr>, <8 x i64> } %384, <8 x i64> %383, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %385, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %385, 1
  %388 = getelementptr i8, <8 x ptr> %386, <8 x i64> %387
  %389 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %388, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %390 = icmp ne <8 x i8> %389, zeroinitializer
  %391 = add i64 0, %380
  %392 = add i64 0, %391
  %tile_snapshot.spill.load176 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 1
  %.splatinsert177 = insertelement <8 x i64> poison, i64 %392, i64 0
  %.splat178 = shufflevector <8 x i64> %.splatinsert177, <8 x i64> poison, <8 x i32> zeroinitializer
  %395 = mul <8 x i64> %.splat178, splat (i64 32)
  %396 = add <8 x i64> %394, %395
  %397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %393, 0
  %398 = insertvalue { <8 x ptr>, <8 x i64> } %397, <8 x i64> %396, 1
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %398, 1
  %401 = extractelement <8 x ptr> %399, i32 0
  %402 = extractelement <8 x i64> %400, i32 0
  %403 = sub i64 %402, 0
  %404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %405 = select i1 %404, i64 %403, i64 0
  %private.contiguous.address179 = getelementptr i8, ptr %401, i64 %405
  %private.contiguous.load180 = load <8 x float>, ptr %private.contiguous.address179, align 4
  %406 = select <8 x i1> %62, <8 x float> %private.contiguous.load180, <8 x float> zeroinitializer
  %.spill.load181 = load <8 x float>, ptr %.spill36, align 32
  %407 = fsub <8 x float> %406, %.spill.load181
  %408 = select <8 x i1> %62, <8 x float> %407, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %408)
  %.spill.load182 = load float, ptr %.spill37, align 4
  %.splatinsert183 = insertelement <8 x float> poison, float %.spill.load182, i64 0
  %.splat184 = shufflevector <8 x float> %.splatinsert183, <8 x float> poison, <8 x i32> zeroinitializer
  %409 = select <8 x i1> %390, <8 x float> %native.exp, <8 x float> %.splat184
  %tile_snapshot.spill.load185 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load185, 0
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load185, 1
  %.state186 = load i64, ptr %.slot39, align 4
  %.splatinsert187 = insertelement <8 x i64> poison, i64 %.state186, i64 0
  %.splat188 = shufflevector <8 x i64> %.splatinsert187, <8 x i64> poison, <8 x i32> zeroinitializer
  %412 = mul <8 x i64> %.splat188, splat (i64 32)
  %413 = add <8 x i64> %411, %412
  %414 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %410, 0
  %415 = insertvalue { <8 x ptr>, <8 x i64> } %414, <8 x i64> %413, 1
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %415, 1
  %418 = extractelement <8 x ptr> %416, i32 0
  %419 = extractelement <8 x i64> %417, i32 0
  %420 = sub i64 %419, 0
  %421 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %422 = select i1 %421, i64 %420, i64 0
  %private.contiguous.address189 = getelementptr i8, ptr %418, i64 %422
  %private.contiguous.preserve190 = load <8 x float>, ptr %private.contiguous.address189, align 4
  %423 = select <8 x i1> %62, <8 x float> %409, <8 x float> %private.contiguous.preserve190
  store <8 x float> %423, ptr %private.contiguous.address189, align 4
  %.state191 = load i64, ptr %.slot39, align 4
  %424 = add i64 %.state191, 1
  store i64 %424, ptr %.slot39, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false171
  %tile_snapshot.spill.load192 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %.spill.load193 = load i64, ptr %.spill27, align 4
  %.splatinsert194 = insertelement <8 x i64> poison, i64 %.spill.load193, i64 0
  %.splat195 = shufflevector <8 x i64> %.splatinsert194, <8 x i64> poison, <8 x i32> zeroinitializer
  %427 = mul <8 x i64> %.splat195, splat (i64 32)
  %428 = add <8 x i64> %426, %427
  %429 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %425, 0
  %430 = insertvalue { <8 x ptr>, <8 x i64> } %429, <8 x i64> %428, 1
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %430, 1
  %433 = extractelement <8 x ptr> %431, i32 0
  %434 = extractelement <8 x i64> %432, i32 0
  %435 = sub i64 %434, 0
  %436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %437 = select i1 %436, i64 %435, i64 0
  %private.contiguous.address196 = getelementptr i8, ptr %433, i64 %437
  %private.contiguous.load197 = load <8 x float>, ptr %private.contiguous.address196, align 4
  %438 = select <8 x i1> %62, <8 x float> %private.contiguous.load197, <8 x float> zeroinitializer
  %tile_snapshot.spill.load198 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 1
  %.spill.load199 = load i64, ptr %.spill28, align 4
  %.splatinsert200 = insertelement <8 x i64> poison, i64 %.spill.load199, i64 0
  %.splat201 = shufflevector <8 x i64> %.splatinsert200, <8 x i64> poison, <8 x i32> zeroinitializer
  %441 = mul <8 x i64> %.splat201, splat (i64 32)
  %442 = add <8 x i64> %440, %441
  %443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %439, 0
  %444 = insertvalue { <8 x ptr>, <8 x i64> } %443, <8 x i64> %442, 1
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %444, 1
  %447 = extractelement <8 x ptr> %445, i32 0
  %448 = extractelement <8 x i64> %446, i32 0
  %449 = sub i64 %448, 0
  %450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %451 = select i1 %450, i64 %449, i64 0
  %private.contiguous.address202 = getelementptr i8, ptr %447, i64 %451
  %private.contiguous.load203 = load <8 x float>, ptr %private.contiguous.address202, align 4
  %452 = select <8 x i1> %62, <8 x float> %private.contiguous.load203, <8 x float> zeroinitializer
  %tile_snapshot.spill.load204 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load204, 0
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load204, 1
  %.spill.load205 = load i64, ptr %.spill29, align 4
  %.splatinsert206 = insertelement <8 x i64> poison, i64 %.spill.load205, i64 0
  %.splat207 = shufflevector <8 x i64> %.splatinsert206, <8 x i64> poison, <8 x i32> zeroinitializer
  %455 = mul <8 x i64> %.splat207, splat (i64 32)
  %456 = add <8 x i64> %454, %455
  %457 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %453, 0
  %458 = insertvalue { <8 x ptr>, <8 x i64> } %457, <8 x i64> %456, 1
  %459 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %460 = extractvalue { <8 x ptr>, <8 x i64> } %458, 1
  %461 = extractelement <8 x ptr> %459, i32 0
  %462 = extractelement <8 x i64> %460, i32 0
  %463 = sub i64 %462, 0
  %464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %465 = select i1 %464, i64 %463, i64 0
  %private.contiguous.address208 = getelementptr i8, ptr %461, i64 %465
  %private.contiguous.load209 = load <8 x float>, ptr %private.contiguous.address208, align 4
  %466 = select <8 x i1> %62, <8 x float> %private.contiguous.load209, <8 x float> zeroinitializer
  %tile_snapshot.spill.load210 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 0
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 1
  %.spill.load211 = load i64, ptr %.spill30, align 4
  %.splatinsert212 = insertelement <8 x i64> poison, i64 %.spill.load211, i64 0
  %.splat213 = shufflevector <8 x i64> %.splatinsert212, <8 x i64> poison, <8 x i32> zeroinitializer
  %469 = mul <8 x i64> %.splat213, splat (i64 32)
  %470 = add <8 x i64> %468, %469
  %471 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %467, 0
  %472 = insertvalue { <8 x ptr>, <8 x i64> } %471, <8 x i64> %470, 1
  %473 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %472, 1
  %475 = extractelement <8 x ptr> %473, i32 0
  %476 = extractelement <8 x i64> %474, i32 0
  %477 = sub i64 %476, 0
  %478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %479 = select i1 %478, i64 %477, i64 0
  %private.contiguous.address214 = getelementptr i8, ptr %475, i64 %479
  %private.contiguous.load215 = load <8 x float>, ptr %private.contiguous.address214, align 4
  %480 = select <8 x i1> %62, <8 x float> %private.contiguous.load215, <8 x float> zeroinitializer
  store i64 4, ptr %.slot40, align 4
  %481 = load <8 x float>, ptr %.slot41, align 32
  %482 = select <8 x i1> %62, <8 x float> %438, <8 x float> %481
  store <8 x float> %482, ptr %.slot41, align 32
  %483 = load <8 x float>, ptr %.slot42, align 32
  %484 = select <8 x i1> %62, <8 x float> %452, <8 x float> %483
  store <8 x float> %484, ptr %.slot42, align 32
  %485 = load <8 x float>, ptr %.slot43, align 32
  %486 = select <8 x i1> %62, <8 x float> %466, <8 x float> %485
  store <8 x float> %486, ptr %.slot43, align 32
  %487 = load <8 x float>, ptr %.slot44, align 32
  %488 = select <8 x i1> %62, <8 x float> %480, <8 x float> %487
  store <8 x float> %488, ptr %.slot44, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state216 = load i64, ptr %.slot40, align 4
  %489 = icmp slt i64 %.state216, 768
  br i1 %489, label %direct.true217, label %direct.false218

direct.schedule.20:                               ; preds = %direct.true217
  %.state219 = load i64, ptr %.slot40, align 4
  %490 = add i64 %.state219, 0
  %491 = sdiv i64 %490, 1
  %.spill.load220 = load i64, ptr %.spill26, align 4
  %492 = add i64 %.spill.load220, %491
  %tile_snapshot.spill.load221 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %493 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %.splatinsert222 = insertelement <8 x i64> poison, i64 %492, i64 0
  %.splat223 = shufflevector <8 x i64> %.splatinsert222, <8 x i64> poison, <8 x i32> zeroinitializer
  %495 = mul <8 x i64> %.splat223, splat (i64 32)
  %496 = add <8 x i64> %494, %495
  %497 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %493, 0
  %498 = insertvalue { <8 x ptr>, <8 x i64> } %497, <8 x i64> %496, 1
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %498, 1
  %501 = extractelement <8 x ptr> %499, i32 0
  %502 = extractelement <8 x i64> %500, i32 0
  %503 = sub i64 %502, 0
  %504 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %505 = select i1 %504, i64 %503, i64 0
  %private.contiguous.address224 = getelementptr i8, ptr %501, i64 %505
  %private.contiguous.load225 = load <8 x float>, ptr %private.contiguous.address224, align 4
  %506 = select <8 x i1> %62, <8 x float> %private.contiguous.load225, <8 x float> zeroinitializer
  %.state226 = load <8 x float>, ptr %.slot41, align 32
  %507 = fadd <8 x float> %.state226, %506
  %.state227 = load i64, ptr %.slot40, align 4
  %508 = add i64 %.state227, 1
  %509 = sdiv i64 %508, 1
  %.spill.load228 = load i64, ptr %.spill26, align 4
  %510 = add i64 %.spill.load228, %509
  %tile_snapshot.spill.load229 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %511 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 0
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 1
  %.splatinsert230 = insertelement <8 x i64> poison, i64 %510, i64 0
  %.splat231 = shufflevector <8 x i64> %.splatinsert230, <8 x i64> poison, <8 x i32> zeroinitializer
  %513 = mul <8 x i64> %.splat231, splat (i64 32)
  %514 = add <8 x i64> %512, %513
  %515 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %511, 0
  %516 = insertvalue { <8 x ptr>, <8 x i64> } %515, <8 x i64> %514, 1
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %516, 1
  %519 = extractelement <8 x ptr> %517, i32 0
  %520 = extractelement <8 x i64> %518, i32 0
  %521 = sub i64 %520, 0
  %522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %523 = select i1 %522, i64 %521, i64 0
  %private.contiguous.address232 = getelementptr i8, ptr %519, i64 %523
  %private.contiguous.load233 = load <8 x float>, ptr %private.contiguous.address232, align 4
  %524 = select <8 x i1> %62, <8 x float> %private.contiguous.load233, <8 x float> zeroinitializer
  %.state234 = load <8 x float>, ptr %.slot42, align 32
  %525 = fadd <8 x float> %.state234, %524
  %.state235 = load i64, ptr %.slot40, align 4
  %526 = add i64 %.state235, 2
  %527 = sdiv i64 %526, 1
  %.spill.load236 = load i64, ptr %.spill26, align 4
  %528 = add i64 %.spill.load236, %527
  %tile_snapshot.spill.load237 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 1
  %.splatinsert238 = insertelement <8 x i64> poison, i64 %528, i64 0
  %.splat239 = shufflevector <8 x i64> %.splatinsert238, <8 x i64> poison, <8 x i32> zeroinitializer
  %531 = mul <8 x i64> %.splat239, splat (i64 32)
  %532 = add <8 x i64> %530, %531
  %533 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %529, 0
  %534 = insertvalue { <8 x ptr>, <8 x i64> } %533, <8 x i64> %532, 1
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %534, 1
  %537 = extractelement <8 x ptr> %535, i32 0
  %538 = extractelement <8 x i64> %536, i32 0
  %539 = sub i64 %538, 0
  %540 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %541 = select i1 %540, i64 %539, i64 0
  %private.contiguous.address240 = getelementptr i8, ptr %537, i64 %541
  %private.contiguous.load241 = load <8 x float>, ptr %private.contiguous.address240, align 4
  %542 = select <8 x i1> %62, <8 x float> %private.contiguous.load241, <8 x float> zeroinitializer
  %.state242 = load <8 x float>, ptr %.slot43, align 32
  %543 = fadd <8 x float> %.state242, %542
  %.state243 = load i64, ptr %.slot40, align 4
  %544 = add i64 %.state243, 3
  %545 = sdiv i64 %544, 1
  %.spill.load244 = load i64, ptr %.spill26, align 4
  %546 = add i64 %.spill.load244, %545
  %tile_snapshot.spill.load245 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load245, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load245, 1
  %.splatinsert246 = insertelement <8 x i64> poison, i64 %546, i64 0
  %.splat247 = shufflevector <8 x i64> %.splatinsert246, <8 x i64> poison, <8 x i32> zeroinitializer
  %549 = mul <8 x i64> %.splat247, splat (i64 32)
  %550 = add <8 x i64> %548, %549
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %547, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = extractelement <8 x ptr> %553, i32 0
  %556 = extractelement <8 x i64> %554, i32 0
  %557 = sub i64 %556, 0
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %559 = select i1 %558, i64 %557, i64 0
  %private.contiguous.address248 = getelementptr i8, ptr %555, i64 %559
  %private.contiguous.load249 = load <8 x float>, ptr %private.contiguous.address248, align 4
  %560 = select <8 x i1> %62, <8 x float> %private.contiguous.load249, <8 x float> zeroinitializer
  %.state250 = load <8 x float>, ptr %.slot44, align 32
  %561 = fadd <8 x float> %.state250, %560
  %.state251 = load i64, ptr %.slot40, align 4
  %562 = add i64 %.state251, 4
  store i64 %562, ptr %.slot40, align 4
  %563 = load <8 x float>, ptr %.slot41, align 32
  %564 = select <8 x i1> %62, <8 x float> %507, <8 x float> %563
  store <8 x float> %564, ptr %.slot41, align 32
  %565 = load <8 x float>, ptr %.slot42, align 32
  %566 = select <8 x i1> %62, <8 x float> %525, <8 x float> %565
  store <8 x float> %566, ptr %.slot42, align 32
  %567 = load <8 x float>, ptr %.slot43, align 32
  %568 = select <8 x i1> %62, <8 x float> %543, <8 x float> %567
  store <8 x float> %568, ptr %.slot43, align 32
  %569 = load <8 x float>, ptr %.slot44, align 32
  %570 = select <8 x i1> %62, <8 x float> %561, <8 x float> %569
  store <8 x float> %570, ptr %.slot44, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false218
  %.spill.load252 = load float, ptr %.spill37, align 4
  %.splatinsert253 = insertelement <8 x float> poison, float %.spill.load252, i64 0
  %.splat254 = shufflevector <8 x float> %.splatinsert253, <8 x float> poison, <8 x i32> zeroinitializer
  %.state255 = load <8 x float>, ptr %.slot41, align 32
  %571 = fadd <8 x float> %.splat254, %.state255
  %.state256 = load <8 x float>, ptr %.slot42, align 32
  %572 = fadd <8 x float> %571, %.state256
  %.state257 = load <8 x float>, ptr %.slot43, align 32
  %573 = fadd <8 x float> %572, %.state257
  %.state258 = load <8 x float>, ptr %.slot44, align 32
  %574 = fadd <8 x float> %573, %.state258
  %575 = load <8 x float>, ptr %.spill45, align 32
  %576 = select <8 x i1> %62, <8 x float> %574, <8 x float> %575
  store <8 x float> %576, ptr %.spill45, align 32
  store i64 0, ptr %.slot46, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state259 = load i64, ptr %.slot46, align 4
  %577 = icmp slt i64 %.state259, 768
  br i1 %577, label %direct.true260, label %direct.false261

direct.schedule.23:                               ; preds = %direct.true260
  %.spill.load262 = load <8 x i64>, ptr %.spill, align 64
  %578 = add <8 x i64> %.spill.load262, zeroinitializer
  %579 = add <8 x i64> zeroinitializer, %578
  %.state263 = load i64, ptr %.slot46, align 4
  %580 = add i64 0, %.state263
  %581 = mul <8 x i64> %579, splat (i64 768)
  %.splatinsert264 = insertelement <8 x i64> poison, i64 %580, i64 0
  %.splat265 = shufflevector <8 x i64> %.splatinsert264, <8 x i64> poison, <8 x i32> zeroinitializer
  %582 = add <8 x i64> %581, %.splat265
  %.state266 = load i64, ptr %.slot46, align 4
  %583 = add i64 0, %.state266
  %tile_snapshot.spill.load267 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load267, 0
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load267, 1
  %.splatinsert268 = insertelement <8 x i64> poison, i64 %583, i64 0
  %.splat269 = shufflevector <8 x i64> %.splatinsert268, <8 x i64> poison, <8 x i32> zeroinitializer
  %586 = mul <8 x i64> %.splat269, splat (i64 32)
  %587 = add <8 x i64> %585, %586
  %588 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %584, 0
  %589 = insertvalue { <8 x ptr>, <8 x i64> } %588, <8 x i64> %587, 1
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %589, 1
  %592 = extractelement <8 x ptr> %590, i32 0
  %593 = extractelement <8 x i64> %591, i32 0
  %594 = sub i64 %593, 0
  %595 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %596 = select i1 %595, i64 %594, i64 0
  %private.contiguous.address270 = getelementptr i8, ptr %592, i64 %596
  %private.contiguous.load271 = load <8 x float>, ptr %private.contiguous.address270, align 4
  %597 = select <8 x i1> %62, <8 x float> %private.contiguous.load271, <8 x float> zeroinitializer
  %.spill.load272 = load <8 x float>, ptr %.spill45, align 32
  %598 = fdiv <8 x float> %597, %.spill.load272
  %599 = extractvalue { ptr, i64 } %38, 0
  %600 = mul <8 x i64> %582, splat (i64 4)
  %601 = getelementptr i8, ptr %599, <8 x i64> %600
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %598, <8 x ptr> %601, i32 1, <8 x i1> %62)
  %.state273 = load i64, ptr %.slot46, align 4
  %602 = add i64 %.state273, 1
  store i64 %602, ptr %.slot46, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false261
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true65:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false66:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true79:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false80:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true93:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false94:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true127:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false128:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true170:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false171:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true217:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false218:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true260:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false261:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, i32 immarg, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x i8>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #0

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #3 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 24576
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 73728
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 768, i64 1536, i64 2304, i64 3072, i64 3840, i64 4608, i64 5376>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 79872
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 104448
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %.spill19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill19, align 64
  %tile_snapshot.spill20 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill20, align 64
  %.slot21 = alloca i64, align 8
  store i64 0, ptr %.slot21, align 4
  %.spill22 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill22, align 4
  %tile_snapshot.spill23 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill23, align 64
  %.slot24 = alloca i64, align 8
  store i64 0, ptr %.slot24, align 4
  %.spill25 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill25, align 4
  %.spill26 = alloca i64, align 8
  store i64 0, ptr %.spill26, align 4
  %.spill27 = alloca i64, align 8
  store i64 0, ptr %.spill27, align 4
  %.spill28 = alloca i64, align 8
  store i64 0, ptr %.spill28, align 4
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca i64, align 8
  store i64 0, ptr %.spill30, align 4
  %.slot31 = alloca i64, align 8
  store i64 0, ptr %.slot31, align 4
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.spill36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill36, align 32
  %.spill37 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.slot40 = alloca i64, align 8
  store i64 0, ptr %.slot40, align 4
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.spill45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %15 = getelementptr i8, ptr %argument_buffer, i64 0
  %16 = load ptr, ptr %15, align 16
  %17 = getelementptr i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  %21 = getelementptr i8, ptr %argument_buffer, i64 16
  %22 = load ptr, ptr %21, align 16
  %23 = getelementptr i8, ptr %21, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = insertvalue { ptr, i64 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i64 } %25, i64 %24, 1
  %27 = getelementptr i8, ptr %argument_buffer, i64 32
  %28 = load ptr, ptr %27, align 16
  %29 = getelementptr i8, ptr %27, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { ptr, i64 } poison, ptr %28, 0
  %32 = insertvalue { ptr, i64 } %31, i64 %30, 1
  %33 = getelementptr i8, ptr %argument_buffer, i64 48
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = load i32, ptr %launch_config, align 4
  %40 = getelementptr i8, ptr %launch_config, i64 12
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr i8, ptr %launch_config, i64 4
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %launch_config, i64 16
  %45 = load i32, ptr %44, align 4
  %46 = getelementptr i8, ptr %launch_config, i64 8
  %47 = load i32, ptr %46, align 4
  %48 = getelementptr i8, ptr %launch_config, i64 20
  %49 = load i32, ptr %48, align 4
  %50 = getelementptr i8, ptr %launch_config, i64 36
  %51 = load i32, ptr %50, align 4
  %.splatinsert47 = insertelement <8 x i32> poison, i32 %51, i64 0
  %.splat48 = shufflevector <8 x i32> %.splatinsert47, <8 x i32> poison, <8 x i32> zeroinitializer
  %52 = add <8 x i32> %.splat48, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %53 = mul i32 %39, 32
  %.splatinsert49 = insertelement <8 x i32> poison, i32 %53, i64 0
  %.splat50 = shufflevector <8 x i32> %.splatinsert49, <8 x i32> poison, <8 x i32> zeroinitializer
  %54 = add <8 x i32> %.splat50, %52
  %55 = mul i32 %43, 1
  %.splatinsert51 = insertelement <8 x i32> poison, i32 %55, i64 0
  %.splat52 = shufflevector <8 x i32> %.splatinsert51, <8 x i32> poison, <8 x i32> zeroinitializer
  %56 = add <8 x i32> %.splat52, zeroinitializer
  %57 = mul i32 %47, 1
  %.splatinsert53 = insertelement <8 x i32> poison, i32 %57, i64 0
  %.splat54 = shufflevector <8 x i32> %.splatinsert53, <8 x i32> poison, <8 x i32> zeroinitializer
  %58 = add <8 x i32> %.splat54, zeroinitializer
  %59 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %54, 0
  %60 = insertvalue [3 x <8 x i32>] %59, <8 x i32> %56, 1
  %61 = insertvalue [3 x <8 x i32>] %60, <8 x i32> %58, 2
  %.splatinsert55 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat56 = shufflevector <8 x i32> %.splatinsert55, <8 x i32> poison, <8 x i32> zeroinitializer
  %62 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat56
  %63 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  br i1 %63, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %64 = extractvalue [3 x <8 x i32>] %61, 0
  %65 = zext <8 x i32> %64 to <8 x i64>
  %66 = select <8 x i1> %62, <8 x i64> %65, <8 x i64> zeroinitializer
  %67 = select <8 x i1> %62, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %68 = sdiv <8 x i64> %66, %67
  %69 = load <8 x i64>, ptr %.spill, align 64
  %70 = select <8 x i1> %62, <8 x i64> %68, <8 x i64> %69
  store <8 x i64> %70, ptr %.spill, align 64
  %71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %71, 0
  %74 = select <8 x i1> %62, <8 x ptr> %72, <8 x ptr> %73
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %71, 1
  %77 = select <8 x i1> %62, <8 x i64> %75, <8 x i64> %76
  %78 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %74, 0
  %79 = insertvalue { <8 x ptr>, <8 x i64> } %78, <8 x i64> %77, 1
  store { <8 x ptr>, <8 x i64> } %79, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %80 = icmp slt i64 %.state, 768
  br i1 %80, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.spill.load, zeroinitializer
  %82 = add <8 x i64> zeroinitializer, %81
  %.state57 = load i64, ptr %.slot, align 4
  %83 = add i64 0, %.state57
  %84 = mul <8 x i64> %82, splat (i64 768)
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %83, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %85 = add <8 x i64> %84, %.splat59
  %86 = extractvalue { ptr, i64 } %20, 0
  %87 = mul <8 x i64> %85, splat (i64 4)
  %88 = getelementptr i8, ptr %86, <8 x i64> %87
  %89 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %88, i32 1, <8 x i1> %62, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state60 = load i64, ptr %.slot, align 4
  %.splatinsert61 = insertelement <8 x i64> poison, i64 %.state60, i64 0
  %.splat62 = shufflevector <8 x i64> %.splatinsert61, <8 x i64> poison, <8 x i32> zeroinitializer
  %92 = mul <8 x i64> %.splat62, splat (i64 32)
  %93 = add <8 x i64> %91, %92
  %94 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %90, 0
  %95 = insertvalue { <8 x ptr>, <8 x i64> } %94, <8 x i64> %93, 1
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %95, 1
  %98 = extractelement <8 x ptr> %96, i32 0
  %99 = extractelement <8 x i64> %97, i32 0
  %100 = sub i64 %99, 0
  %101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %102 = select i1 %101, i64 %100, i64 0
  %private.contiguous.address = getelementptr i8, ptr %98, i64 %102
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %103 = select <8 x i1> %62, <8 x float> %89, <8 x float> %private.contiguous.preserve
  store <8 x float> %103, ptr %private.contiguous.address, align 4
  %.state63 = load i64, ptr %.slot, align 4
  %104 = add i64 %.state63, 1
  store i64 %104, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %105 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %105, 0
  %108 = select <8 x i1> %62, <8 x ptr> %106, <8 x ptr> %107
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %105, 1
  %111 = select <8 x i1> %62, <8 x i64> %109, <8 x i64> %110
  %112 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %108, 0
  %113 = insertvalue { <8 x ptr>, <8 x i64> } %112, <8 x i64> %111, 1
  store { <8 x ptr>, <8 x i64> } %113, ptr %tile_snapshot.spill17, align 64
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state64 = load i64, ptr %.slot18, align 4
  %114 = icmp slt i64 %.state64, 768
  br i1 %114, label %direct.true65, label %direct.false66

direct.schedule.5:                                ; preds = %direct.true65
  %tile_snapshot.spill.load67 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 1
  %.state68 = load i64, ptr %.slot18, align 4
  %.splatinsert69 = insertelement <8 x i64> poison, i64 %.state68, i64 0
  %.splat70 = shufflevector <8 x i64> %.splatinsert69, <8 x i64> poison, <8 x i32> zeroinitializer
  %117 = mul <8 x i64> %.splat70, splat (i64 64)
  %118 = add <8 x i64> %116, %117
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %.state71 = load i64, ptr %.slot18, align 4
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %.state71, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve75 = load <8 x i64>, ptr %private.contiguous.address74, align 8
  %128 = select <8 x i1> %62, <8 x i64> %.splat73, <8 x i64> %private.contiguous.preserve75
  store <8 x i64> %128, ptr %private.contiguous.address74, align 8
  %.state76 = load i64, ptr %.slot18, align 4
  %129 = add i64 %.state76, 1
  store i64 %129, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false66
  %.spill.load77 = load <8 x i64>, ptr %.spill, align 64
  %130 = select <8 x i1> %62, <8 x i64> %.spill.load77, <8 x i64> zeroinitializer
  %131 = select <8 x i1> %62, <8 x i64> splat (i64 768), <8 x i64> splat (i64 1)
  %132 = srem <8 x i64> %130, %131
  %133 = load <8 x i64>, ptr %.spill19, align 64
  %134 = select <8 x i1> %62, <8 x i64> %132, <8 x i64> %133
  store <8 x i64> %134, ptr %.spill19, align 64
  %135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %135, 0
  %138 = select <8 x i1> %62, <8 x ptr> %136, <8 x ptr> %137
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %135, 1
  %141 = select <8 x i1> %62, <8 x i64> %139, <8 x i64> %140
  %142 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %138, 0
  %143 = insertvalue { <8 x ptr>, <8 x i64> } %142, <8 x i64> %141, 1
  store { <8 x ptr>, <8 x i64> } %143, ptr %tile_snapshot.spill20, align 64
  store i64 0, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state78 = load i64, ptr %.slot21, align 4
  %144 = icmp slt i64 %.state78, 768
  br i1 %144, label %direct.true79, label %direct.false80

direct.schedule.8:                                ; preds = %direct.true79
  %.state81 = load i64, ptr %.slot21, align 4
  %145 = add i64 0, %.state81
  %tile_snapshot.spill.load82 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 1
  %.splatinsert83 = insertelement <8 x i64> poison, i64 %145, i64 0
  %.splat84 = shufflevector <8 x i64> %.splatinsert83, <8 x i64> poison, <8 x i32> zeroinitializer
  %148 = mul <8 x i64> %.splat84, splat (i64 64)
  %149 = add <8 x i64> %147, %148
  %150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %146, 0
  %151 = insertvalue { <8 x ptr>, <8 x i64> } %150, <8 x i64> %149, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %154 = extractelement <8 x ptr> %152, i32 0
  %155 = extractelement <8 x i64> %153, i32 0
  %156 = sub i64 %155, 0
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %158 = select i1 %157, i64 %156, i64 0
  %private.contiguous.address85 = getelementptr i8, ptr %154, i64 %158
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address85, align 8
  %159 = select <8 x i1> %62, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load86 = load <8 x i64>, ptr %.spill19, align 64
  %160 = icmp sle <8 x i64> %159, %.spill.load86
  %tile_snapshot.spill.load87 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 1
  %.state88 = load i64, ptr %.slot21, align 4
  %.splatinsert89 = insertelement <8 x i64> poison, i64 %.state88, i64 0
  %.splat90 = shufflevector <8 x i64> %.splatinsert89, <8 x i64> poison, <8 x i32> zeroinitializer
  %163 = add <8 x i64> %162, %.splat90
  %164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %161, 0
  %165 = insertvalue { <8 x ptr>, <8 x i64> } %164, <8 x i64> %163, 1
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %168 = getelementptr i8, <8 x ptr> %166, <8 x i64> %167
  %169 = zext <8 x i1> %160 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %169, <8 x ptr> %168, i32 1, <8 x i1> %62)
  %.state91 = load i64, ptr %.slot21, align 4
  %170 = add i64 %.state91, 1
  store i64 %170, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false80
  store float 0xC6293E5940000000, ptr %.spill22, align 4
  %171 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 0
  %174 = select <8 x i1> %62, <8 x ptr> %172, <8 x ptr> %173
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %177 = select <8 x i1> %62, <8 x i64> %175, <8 x i64> %176
  %178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %174, 0
  %179 = insertvalue { <8 x ptr>, <8 x i64> } %178, <8 x i64> %177, 1
  store { <8 x ptr>, <8 x i64> } %179, ptr %tile_snapshot.spill23, align 64
  store i64 0, ptr %.slot24, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state92 = load i64, ptr %.slot24, align 4
  %180 = icmp slt i64 %.state92, 768
  br i1 %180, label %direct.true93, label %direct.false94

direct.schedule.11:                               ; preds = %direct.true93
  %.state95 = load i64, ptr %.slot24, align 4
  %181 = add i64 0, %.state95
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.splatinsert97 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat98 = shufflevector <8 x i64> %.splatinsert97, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = add <8 x i64> %183, %.splat98
  %185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %182, 0
  %186 = insertvalue { <8 x ptr>, <8 x i64> } %185, <8 x i64> %184, 1
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %186, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %186, 1
  %189 = getelementptr i8, <8 x ptr> %187, <8 x i64> %188
  %190 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %189, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %191 = icmp ne <8 x i8> %190, zeroinitializer
  %tile_snapshot.spill.load99 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 1
  %.splatinsert100 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat101 = shufflevector <8 x i64> %.splatinsert100, <8 x i64> poison, <8 x i32> zeroinitializer
  %194 = mul <8 x i64> %.splat101, splat (i64 32)
  %195 = add <8 x i64> %193, %194
  %196 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %192, 0
  %197 = insertvalue { <8 x ptr>, <8 x i64> } %196, <8 x i64> %195, 1
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %197, 1
  %200 = extractelement <8 x ptr> %198, i32 0
  %201 = extractelement <8 x i64> %199, i32 0
  %202 = sub i64 %201, 0
  %203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %204 = select i1 %203, i64 %202, i64 0
  %private.contiguous.address102 = getelementptr i8, ptr %200, i64 %204
  %private.contiguous.load103 = load <8 x float>, ptr %private.contiguous.address102, align 4
  %205 = select <8 x i1> %62, <8 x float> %private.contiguous.load103, <8 x float> zeroinitializer
  %.spill.load104 = load float, ptr %.spill22, align 4
  %.splatinsert105 = insertelement <8 x float> poison, float %.spill.load104, i64 0
  %.splat106 = shufflevector <8 x float> %.splatinsert105, <8 x float> poison, <8 x i32> zeroinitializer
  %206 = select <8 x i1> %191, <8 x float> %205, <8 x float> %.splat106
  %tile_snapshot.spill.load107 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 0
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 1
  %.state108 = load i64, ptr %.slot24, align 4
  %.splatinsert109 = insertelement <8 x i64> poison, i64 %.state108, i64 0
  %.splat110 = shufflevector <8 x i64> %.splatinsert109, <8 x i64> poison, <8 x i32> zeroinitializer
  %209 = mul <8 x i64> %.splat110, splat (i64 32)
  %210 = add <8 x i64> %208, %209
  %211 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %207, 0
  %212 = insertvalue { <8 x ptr>, <8 x i64> } %211, <8 x i64> %210, 1
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %212, 1
  %215 = extractelement <8 x ptr> %213, i32 0
  %216 = extractelement <8 x i64> %214, i32 0
  %217 = sub i64 %216, 0
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %219 = select i1 %218, i64 %217, i64 0
  %private.contiguous.address111 = getelementptr i8, ptr %215, i64 %219
  %private.contiguous.preserve112 = load <8 x float>, ptr %private.contiguous.address111, align 4
  %220 = select <8 x i1> %62, <8 x float> %206, <8 x float> %private.contiguous.preserve112
  store <8 x float> %220, ptr %private.contiguous.address111, align 4
  %.state113 = load i64, ptr %.slot24, align 4
  %221 = add i64 %.state113, 1
  store i64 %221, ptr %.slot24, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false94
  store float 0xFFF0000000000000, ptr %.spill25, align 4
  store i64 0, ptr %.spill26, align 4
  store i64 0, ptr %.spill27, align 4
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %224 = add <8 x i64> %223, zeroinitializer
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = extractelement <8 x ptr> %227, i32 0
  %230 = extractelement <8 x i64> %228, i32 0
  %231 = sub i64 %230, 0
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %233 = select i1 %232, i64 %231, i64 0
  %private.contiguous.address115 = getelementptr i8, ptr %229, i64 %233
  %private.contiguous.load116 = load <8 x float>, ptr %private.contiguous.address115, align 4
  %234 = select <8 x i1> %62, <8 x float> %private.contiguous.load116, <8 x float> zeroinitializer
  store i64 1, ptr %.spill28, align 4
  %tile_snapshot.spill.load117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 1
  %237 = add <8 x i64> %236, splat (i64 32)
  %238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %235, 0
  %239 = insertvalue { <8 x ptr>, <8 x i64> } %238, <8 x i64> %237, 1
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %239, 1
  %242 = extractelement <8 x ptr> %240, i32 0
  %243 = extractelement <8 x i64> %241, i32 0
  %244 = sub i64 %243, 0
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %246 = select i1 %245, i64 %244, i64 0
  %private.contiguous.address118 = getelementptr i8, ptr %242, i64 %246
  %private.contiguous.load119 = load <8 x float>, ptr %private.contiguous.address118, align 4
  %247 = select <8 x i1> %62, <8 x float> %private.contiguous.load119, <8 x float> zeroinitializer
  store i64 2, ptr %.spill29, align 4
  %tile_snapshot.spill.load120 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 1
  %250 = add <8 x i64> %249, splat (i64 64)
  %251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %252 = insertvalue { <8 x ptr>, <8 x i64> } %251, <8 x i64> %250, 1
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %255 = extractelement <8 x ptr> %253, i32 0
  %256 = extractelement <8 x i64> %254, i32 0
  %257 = sub i64 %256, 0
  %258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %259 = select i1 %258, i64 %257, i64 0
  %private.contiguous.address121 = getelementptr i8, ptr %255, i64 %259
  %private.contiguous.load122 = load <8 x float>, ptr %private.contiguous.address121, align 4
  %260 = select <8 x i1> %62, <8 x float> %private.contiguous.load122, <8 x float> zeroinitializer
  store i64 3, ptr %.spill30, align 4
  %tile_snapshot.spill.load123 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 1
  %263 = add <8 x i64> %262, splat (i64 96)
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = extractelement <8 x ptr> %266, i32 0
  %269 = extractelement <8 x i64> %267, i32 0
  %270 = sub i64 %269, 0
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %272 = select i1 %271, i64 %270, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %268, i64 %272
  %private.contiguous.load125 = load <8 x float>, ptr %private.contiguous.address124, align 4
  %273 = select <8 x i1> %62, <8 x float> %private.contiguous.load125, <8 x float> zeroinitializer
  store i64 4, ptr %.slot31, align 4
  %274 = load <8 x float>, ptr %.slot32, align 32
  %275 = select <8 x i1> %62, <8 x float> %234, <8 x float> %274
  store <8 x float> %275, ptr %.slot32, align 32
  %276 = load <8 x float>, ptr %.slot33, align 32
  %277 = select <8 x i1> %62, <8 x float> %247, <8 x float> %276
  store <8 x float> %277, ptr %.slot33, align 32
  %278 = load <8 x float>, ptr %.slot34, align 32
  %279 = select <8 x i1> %62, <8 x float> %260, <8 x float> %278
  store <8 x float> %279, ptr %.slot34, align 32
  %280 = load <8 x float>, ptr %.slot35, align 32
  %281 = select <8 x i1> %62, <8 x float> %273, <8 x float> %280
  store <8 x float> %281, ptr %.slot35, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state126 = load i64, ptr %.slot31, align 4
  %282 = icmp slt i64 %.state126, 768
  br i1 %282, label %direct.true127, label %direct.false128

direct.schedule.14:                               ; preds = %direct.true127
  %.state129 = load i64, ptr %.slot31, align 4
  %283 = add i64 %.state129, 0
  %284 = sdiv i64 %283, 1
  %.spill.load130 = load i64, ptr %.spill26, align 4
  %285 = add i64 %.spill.load130, %284
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %285, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %288 = mul <8 x i64> %.splat133, splat (i64 32)
  %289 = add <8 x i64> %287, %288
  %290 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %286, 0
  %291 = insertvalue { <8 x ptr>, <8 x i64> } %290, <8 x i64> %289, 1
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %291, 1
  %294 = extractelement <8 x ptr> %292, i32 0
  %295 = extractelement <8 x i64> %293, i32 0
  %296 = sub i64 %295, 0
  %297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %298 = select i1 %297, i64 %296, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %294, i64 %298
  %private.contiguous.load135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %299 = select <8 x i1> %62, <8 x float> %private.contiguous.load135, <8 x float> zeroinitializer
  %.state136 = load <8 x float>, ptr %.slot32, align 32
  %300 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state136, <8 x float> %299)
  %.state137 = load i64, ptr %.slot31, align 4
  %301 = add i64 %.state137, 1
  %302 = sdiv i64 %301, 1
  %.spill.load138 = load i64, ptr %.spill26, align 4
  %303 = add i64 %.spill.load138, %302
  %tile_snapshot.spill.load139 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 1
  %.splatinsert140 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat141 = shufflevector <8 x i64> %.splatinsert140, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat141, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %317 = select <8 x i1> %62, <8 x float> %private.contiguous.load143, <8 x float> zeroinitializer
  %.state144 = load <8 x float>, ptr %.slot33, align 32
  %318 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state144, <8 x float> %317)
  %.state145 = load i64, ptr %.slot31, align 4
  %319 = add i64 %.state145, 2
  %320 = sdiv i64 %319, 1
  %.spill.load146 = load i64, ptr %.spill26, align 4
  %321 = add i64 %.spill.load146, %320
  %tile_snapshot.spill.load147 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %.splatinsert148 = insertelement <8 x i64> poison, i64 %321, i64 0
  %.splat149 = shufflevector <8 x i64> %.splatinsert148, <8 x i64> poison, <8 x i32> zeroinitializer
  %324 = mul <8 x i64> %.splat149, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address150 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.load151 = load <8 x float>, ptr %private.contiguous.address150, align 4
  %335 = select <8 x i1> %62, <8 x float> %private.contiguous.load151, <8 x float> zeroinitializer
  %.state152 = load <8 x float>, ptr %.slot34, align 32
  %336 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state152, <8 x float> %335)
  %.state153 = load i64, ptr %.slot31, align 4
  %337 = add i64 %.state153, 3
  %338 = sdiv i64 %337, 1
  %.spill.load154 = load i64, ptr %.spill26, align 4
  %339 = add i64 %.spill.load154, %338
  %tile_snapshot.spill.load155 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load155, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load155, 1
  %.splatinsert156 = insertelement <8 x i64> poison, i64 %339, i64 0
  %.splat157 = shufflevector <8 x i64> %.splatinsert156, <8 x i64> poison, <8 x i32> zeroinitializer
  %342 = mul <8 x i64> %.splat157, splat (i64 32)
  %343 = add <8 x i64> %341, %342
  %344 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %340, 0
  %345 = insertvalue { <8 x ptr>, <8 x i64> } %344, <8 x i64> %343, 1
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %345, 1
  %348 = extractelement <8 x ptr> %346, i32 0
  %349 = extractelement <8 x i64> %347, i32 0
  %350 = sub i64 %349, 0
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %352 = select i1 %351, i64 %350, i64 0
  %private.contiguous.address158 = getelementptr i8, ptr %348, i64 %352
  %private.contiguous.load159 = load <8 x float>, ptr %private.contiguous.address158, align 4
  %353 = select <8 x i1> %62, <8 x float> %private.contiguous.load159, <8 x float> zeroinitializer
  %.state160 = load <8 x float>, ptr %.slot35, align 32
  %354 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state160, <8 x float> %353)
  %.state161 = load i64, ptr %.slot31, align 4
  %355 = add i64 %.state161, 4
  store i64 %355, ptr %.slot31, align 4
  %356 = load <8 x float>, ptr %.slot32, align 32
  %357 = select <8 x i1> %62, <8 x float> %300, <8 x float> %356
  store <8 x float> %357, ptr %.slot32, align 32
  %358 = load <8 x float>, ptr %.slot33, align 32
  %359 = select <8 x i1> %62, <8 x float> %318, <8 x float> %358
  store <8 x float> %359, ptr %.slot33, align 32
  %360 = load <8 x float>, ptr %.slot34, align 32
  %361 = select <8 x i1> %62, <8 x float> %336, <8 x float> %360
  store <8 x float> %361, ptr %.slot34, align 32
  %362 = load <8 x float>, ptr %.slot35, align 32
  %363 = select <8 x i1> %62, <8 x float> %354, <8 x float> %362
  store <8 x float> %363, ptr %.slot35, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false128
  %.spill.load162 = load float, ptr %.spill25, align 4
  %.splatinsert163 = insertelement <8 x float> poison, float %.spill.load162, i64 0
  %.splat164 = shufflevector <8 x float> %.splatinsert163, <8 x float> poison, <8 x i32> zeroinitializer
  %.state165 = load <8 x float>, ptr %.slot32, align 32
  %364 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.splat164, <8 x float> %.state165)
  %.state166 = load <8 x float>, ptr %.slot33, align 32
  %365 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %364, <8 x float> %.state166)
  %.state167 = load <8 x float>, ptr %.slot34, align 32
  %366 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %365, <8 x float> %.state167)
  %.state168 = load <8 x float>, ptr %.slot35, align 32
  %367 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %366, <8 x float> %.state168)
  %368 = load <8 x float>, ptr %.spill36, align 32
  %369 = select <8 x i1> %62, <8 x float> %367, <8 x float> %368
  store <8 x float> %369, ptr %.spill36, align 32
  store float 0.000000e+00, ptr %.spill37, align 4
  %370 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %370, 0
  %373 = select <8 x i1> %62, <8 x ptr> %371, <8 x ptr> %372
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %375 = extractvalue { <8 x ptr>, <8 x i64> } %370, 1
  %376 = select <8 x i1> %62, <8 x i64> %374, <8 x i64> %375
  %377 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %373, 0
  %378 = insertvalue { <8 x ptr>, <8 x i64> } %377, <8 x i64> %376, 1
  store { <8 x ptr>, <8 x i64> } %378, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state169 = load i64, ptr %.slot39, align 4
  %379 = icmp slt i64 %.state169, 768
  br i1 %379, label %direct.true170, label %direct.false171

direct.schedule.17:                               ; preds = %direct.true170
  %.state172 = load i64, ptr %.slot39, align 4
  %380 = add i64 0, %.state172
  %tile_snapshot.spill.load173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 0
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 1
  %.splatinsert174 = insertelement <8 x i64> poison, i64 %380, i64 0
  %.splat175 = shufflevector <8 x i64> %.splatinsert174, <8 x i64> poison, <8 x i32> zeroinitializer
  %383 = add <8 x i64> %382, %.splat175
  %384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %381, 0
  %385 = insertvalue { <8 x ptr>, <8 x i64> } %384, <8 x i64> %383, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %385, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %385, 1
  %388 = getelementptr i8, <8 x ptr> %386, <8 x i64> %387
  %389 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %388, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %390 = icmp ne <8 x i8> %389, zeroinitializer
  %391 = add i64 0, %380
  %392 = add i64 0, %391
  %tile_snapshot.spill.load176 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 1
  %.splatinsert177 = insertelement <8 x i64> poison, i64 %392, i64 0
  %.splat178 = shufflevector <8 x i64> %.splatinsert177, <8 x i64> poison, <8 x i32> zeroinitializer
  %395 = mul <8 x i64> %.splat178, splat (i64 32)
  %396 = add <8 x i64> %394, %395
  %397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %393, 0
  %398 = insertvalue { <8 x ptr>, <8 x i64> } %397, <8 x i64> %396, 1
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %398, 1
  %401 = extractelement <8 x ptr> %399, i32 0
  %402 = extractelement <8 x i64> %400, i32 0
  %403 = sub i64 %402, 0
  %404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %405 = select i1 %404, i64 %403, i64 0
  %private.contiguous.address179 = getelementptr i8, ptr %401, i64 %405
  %private.contiguous.load180 = load <8 x float>, ptr %private.contiguous.address179, align 4
  %406 = select <8 x i1> %62, <8 x float> %private.contiguous.load180, <8 x float> zeroinitializer
  %.spill.load181 = load <8 x float>, ptr %.spill36, align 32
  %407 = fsub <8 x float> %406, %.spill.load181
  %408 = select <8 x i1> %62, <8 x float> %407, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %408)
  %.spill.load182 = load float, ptr %.spill37, align 4
  %.splatinsert183 = insertelement <8 x float> poison, float %.spill.load182, i64 0
  %.splat184 = shufflevector <8 x float> %.splatinsert183, <8 x float> poison, <8 x i32> zeroinitializer
  %409 = select <8 x i1> %390, <8 x float> %native.exp, <8 x float> %.splat184
  %tile_snapshot.spill.load185 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load185, 0
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load185, 1
  %.state186 = load i64, ptr %.slot39, align 4
  %.splatinsert187 = insertelement <8 x i64> poison, i64 %.state186, i64 0
  %.splat188 = shufflevector <8 x i64> %.splatinsert187, <8 x i64> poison, <8 x i32> zeroinitializer
  %412 = mul <8 x i64> %.splat188, splat (i64 32)
  %413 = add <8 x i64> %411, %412
  %414 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %410, 0
  %415 = insertvalue { <8 x ptr>, <8 x i64> } %414, <8 x i64> %413, 1
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %415, 1
  %418 = extractelement <8 x ptr> %416, i32 0
  %419 = extractelement <8 x i64> %417, i32 0
  %420 = sub i64 %419, 0
  %421 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %422 = select i1 %421, i64 %420, i64 0
  %private.contiguous.address189 = getelementptr i8, ptr %418, i64 %422
  %private.contiguous.preserve190 = load <8 x float>, ptr %private.contiguous.address189, align 4
  %423 = select <8 x i1> %62, <8 x float> %409, <8 x float> %private.contiguous.preserve190
  store <8 x float> %423, ptr %private.contiguous.address189, align 4
  %.state191 = load i64, ptr %.slot39, align 4
  %424 = add i64 %.state191, 1
  store i64 %424, ptr %.slot39, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false171
  %tile_snapshot.spill.load192 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %.spill.load193 = load i64, ptr %.spill27, align 4
  %.splatinsert194 = insertelement <8 x i64> poison, i64 %.spill.load193, i64 0
  %.splat195 = shufflevector <8 x i64> %.splatinsert194, <8 x i64> poison, <8 x i32> zeroinitializer
  %427 = mul <8 x i64> %.splat195, splat (i64 32)
  %428 = add <8 x i64> %426, %427
  %429 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %425, 0
  %430 = insertvalue { <8 x ptr>, <8 x i64> } %429, <8 x i64> %428, 1
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %430, 1
  %433 = extractelement <8 x ptr> %431, i32 0
  %434 = extractelement <8 x i64> %432, i32 0
  %435 = sub i64 %434, 0
  %436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %437 = select i1 %436, i64 %435, i64 0
  %private.contiguous.address196 = getelementptr i8, ptr %433, i64 %437
  %private.contiguous.load197 = load <8 x float>, ptr %private.contiguous.address196, align 4
  %438 = select <8 x i1> %62, <8 x float> %private.contiguous.load197, <8 x float> zeroinitializer
  %tile_snapshot.spill.load198 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 1
  %.spill.load199 = load i64, ptr %.spill28, align 4
  %.splatinsert200 = insertelement <8 x i64> poison, i64 %.spill.load199, i64 0
  %.splat201 = shufflevector <8 x i64> %.splatinsert200, <8 x i64> poison, <8 x i32> zeroinitializer
  %441 = mul <8 x i64> %.splat201, splat (i64 32)
  %442 = add <8 x i64> %440, %441
  %443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %439, 0
  %444 = insertvalue { <8 x ptr>, <8 x i64> } %443, <8 x i64> %442, 1
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %444, 1
  %447 = extractelement <8 x ptr> %445, i32 0
  %448 = extractelement <8 x i64> %446, i32 0
  %449 = sub i64 %448, 0
  %450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %451 = select i1 %450, i64 %449, i64 0
  %private.contiguous.address202 = getelementptr i8, ptr %447, i64 %451
  %private.contiguous.load203 = load <8 x float>, ptr %private.contiguous.address202, align 4
  %452 = select <8 x i1> %62, <8 x float> %private.contiguous.load203, <8 x float> zeroinitializer
  %tile_snapshot.spill.load204 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load204, 0
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load204, 1
  %.spill.load205 = load i64, ptr %.spill29, align 4
  %.splatinsert206 = insertelement <8 x i64> poison, i64 %.spill.load205, i64 0
  %.splat207 = shufflevector <8 x i64> %.splatinsert206, <8 x i64> poison, <8 x i32> zeroinitializer
  %455 = mul <8 x i64> %.splat207, splat (i64 32)
  %456 = add <8 x i64> %454, %455
  %457 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %453, 0
  %458 = insertvalue { <8 x ptr>, <8 x i64> } %457, <8 x i64> %456, 1
  %459 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %460 = extractvalue { <8 x ptr>, <8 x i64> } %458, 1
  %461 = extractelement <8 x ptr> %459, i32 0
  %462 = extractelement <8 x i64> %460, i32 0
  %463 = sub i64 %462, 0
  %464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %465 = select i1 %464, i64 %463, i64 0
  %private.contiguous.address208 = getelementptr i8, ptr %461, i64 %465
  %private.contiguous.load209 = load <8 x float>, ptr %private.contiguous.address208, align 4
  %466 = select <8 x i1> %62, <8 x float> %private.contiguous.load209, <8 x float> zeroinitializer
  %tile_snapshot.spill.load210 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 0
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 1
  %.spill.load211 = load i64, ptr %.spill30, align 4
  %.splatinsert212 = insertelement <8 x i64> poison, i64 %.spill.load211, i64 0
  %.splat213 = shufflevector <8 x i64> %.splatinsert212, <8 x i64> poison, <8 x i32> zeroinitializer
  %469 = mul <8 x i64> %.splat213, splat (i64 32)
  %470 = add <8 x i64> %468, %469
  %471 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %467, 0
  %472 = insertvalue { <8 x ptr>, <8 x i64> } %471, <8 x i64> %470, 1
  %473 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %472, 1
  %475 = extractelement <8 x ptr> %473, i32 0
  %476 = extractelement <8 x i64> %474, i32 0
  %477 = sub i64 %476, 0
  %478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %479 = select i1 %478, i64 %477, i64 0
  %private.contiguous.address214 = getelementptr i8, ptr %475, i64 %479
  %private.contiguous.load215 = load <8 x float>, ptr %private.contiguous.address214, align 4
  %480 = select <8 x i1> %62, <8 x float> %private.contiguous.load215, <8 x float> zeroinitializer
  store i64 4, ptr %.slot40, align 4
  %481 = load <8 x float>, ptr %.slot41, align 32
  %482 = select <8 x i1> %62, <8 x float> %438, <8 x float> %481
  store <8 x float> %482, ptr %.slot41, align 32
  %483 = load <8 x float>, ptr %.slot42, align 32
  %484 = select <8 x i1> %62, <8 x float> %452, <8 x float> %483
  store <8 x float> %484, ptr %.slot42, align 32
  %485 = load <8 x float>, ptr %.slot43, align 32
  %486 = select <8 x i1> %62, <8 x float> %466, <8 x float> %485
  store <8 x float> %486, ptr %.slot43, align 32
  %487 = load <8 x float>, ptr %.slot44, align 32
  %488 = select <8 x i1> %62, <8 x float> %480, <8 x float> %487
  store <8 x float> %488, ptr %.slot44, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state216 = load i64, ptr %.slot40, align 4
  %489 = icmp slt i64 %.state216, 768
  br i1 %489, label %direct.true217, label %direct.false218

direct.schedule.20:                               ; preds = %direct.true217
  %.state219 = load i64, ptr %.slot40, align 4
  %490 = add i64 %.state219, 0
  %491 = sdiv i64 %490, 1
  %.spill.load220 = load i64, ptr %.spill26, align 4
  %492 = add i64 %.spill.load220, %491
  %tile_snapshot.spill.load221 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %493 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %.splatinsert222 = insertelement <8 x i64> poison, i64 %492, i64 0
  %.splat223 = shufflevector <8 x i64> %.splatinsert222, <8 x i64> poison, <8 x i32> zeroinitializer
  %495 = mul <8 x i64> %.splat223, splat (i64 32)
  %496 = add <8 x i64> %494, %495
  %497 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %493, 0
  %498 = insertvalue { <8 x ptr>, <8 x i64> } %497, <8 x i64> %496, 1
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %498, 1
  %501 = extractelement <8 x ptr> %499, i32 0
  %502 = extractelement <8 x i64> %500, i32 0
  %503 = sub i64 %502, 0
  %504 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %505 = select i1 %504, i64 %503, i64 0
  %private.contiguous.address224 = getelementptr i8, ptr %501, i64 %505
  %private.contiguous.load225 = load <8 x float>, ptr %private.contiguous.address224, align 4
  %506 = select <8 x i1> %62, <8 x float> %private.contiguous.load225, <8 x float> zeroinitializer
  %.state226 = load <8 x float>, ptr %.slot41, align 32
  %507 = fadd <8 x float> %.state226, %506
  %.state227 = load i64, ptr %.slot40, align 4
  %508 = add i64 %.state227, 1
  %509 = sdiv i64 %508, 1
  %.spill.load228 = load i64, ptr %.spill26, align 4
  %510 = add i64 %.spill.load228, %509
  %tile_snapshot.spill.load229 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %511 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 0
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 1
  %.splatinsert230 = insertelement <8 x i64> poison, i64 %510, i64 0
  %.splat231 = shufflevector <8 x i64> %.splatinsert230, <8 x i64> poison, <8 x i32> zeroinitializer
  %513 = mul <8 x i64> %.splat231, splat (i64 32)
  %514 = add <8 x i64> %512, %513
  %515 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %511, 0
  %516 = insertvalue { <8 x ptr>, <8 x i64> } %515, <8 x i64> %514, 1
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %516, 1
  %519 = extractelement <8 x ptr> %517, i32 0
  %520 = extractelement <8 x i64> %518, i32 0
  %521 = sub i64 %520, 0
  %522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %523 = select i1 %522, i64 %521, i64 0
  %private.contiguous.address232 = getelementptr i8, ptr %519, i64 %523
  %private.contiguous.load233 = load <8 x float>, ptr %private.contiguous.address232, align 4
  %524 = select <8 x i1> %62, <8 x float> %private.contiguous.load233, <8 x float> zeroinitializer
  %.state234 = load <8 x float>, ptr %.slot42, align 32
  %525 = fadd <8 x float> %.state234, %524
  %.state235 = load i64, ptr %.slot40, align 4
  %526 = add i64 %.state235, 2
  %527 = sdiv i64 %526, 1
  %.spill.load236 = load i64, ptr %.spill26, align 4
  %528 = add i64 %.spill.load236, %527
  %tile_snapshot.spill.load237 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 1
  %.splatinsert238 = insertelement <8 x i64> poison, i64 %528, i64 0
  %.splat239 = shufflevector <8 x i64> %.splatinsert238, <8 x i64> poison, <8 x i32> zeroinitializer
  %531 = mul <8 x i64> %.splat239, splat (i64 32)
  %532 = add <8 x i64> %530, %531
  %533 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %529, 0
  %534 = insertvalue { <8 x ptr>, <8 x i64> } %533, <8 x i64> %532, 1
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %534, 1
  %537 = extractelement <8 x ptr> %535, i32 0
  %538 = extractelement <8 x i64> %536, i32 0
  %539 = sub i64 %538, 0
  %540 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %541 = select i1 %540, i64 %539, i64 0
  %private.contiguous.address240 = getelementptr i8, ptr %537, i64 %541
  %private.contiguous.load241 = load <8 x float>, ptr %private.contiguous.address240, align 4
  %542 = select <8 x i1> %62, <8 x float> %private.contiguous.load241, <8 x float> zeroinitializer
  %.state242 = load <8 x float>, ptr %.slot43, align 32
  %543 = fadd <8 x float> %.state242, %542
  %.state243 = load i64, ptr %.slot40, align 4
  %544 = add i64 %.state243, 3
  %545 = sdiv i64 %544, 1
  %.spill.load244 = load i64, ptr %.spill26, align 4
  %546 = add i64 %.spill.load244, %545
  %tile_snapshot.spill.load245 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load245, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load245, 1
  %.splatinsert246 = insertelement <8 x i64> poison, i64 %546, i64 0
  %.splat247 = shufflevector <8 x i64> %.splatinsert246, <8 x i64> poison, <8 x i32> zeroinitializer
  %549 = mul <8 x i64> %.splat247, splat (i64 32)
  %550 = add <8 x i64> %548, %549
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %547, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = extractelement <8 x ptr> %553, i32 0
  %556 = extractelement <8 x i64> %554, i32 0
  %557 = sub i64 %556, 0
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %559 = select i1 %558, i64 %557, i64 0
  %private.contiguous.address248 = getelementptr i8, ptr %555, i64 %559
  %private.contiguous.load249 = load <8 x float>, ptr %private.contiguous.address248, align 4
  %560 = select <8 x i1> %62, <8 x float> %private.contiguous.load249, <8 x float> zeroinitializer
  %.state250 = load <8 x float>, ptr %.slot44, align 32
  %561 = fadd <8 x float> %.state250, %560
  %.state251 = load i64, ptr %.slot40, align 4
  %562 = add i64 %.state251, 4
  store i64 %562, ptr %.slot40, align 4
  %563 = load <8 x float>, ptr %.slot41, align 32
  %564 = select <8 x i1> %62, <8 x float> %507, <8 x float> %563
  store <8 x float> %564, ptr %.slot41, align 32
  %565 = load <8 x float>, ptr %.slot42, align 32
  %566 = select <8 x i1> %62, <8 x float> %525, <8 x float> %565
  store <8 x float> %566, ptr %.slot42, align 32
  %567 = load <8 x float>, ptr %.slot43, align 32
  %568 = select <8 x i1> %62, <8 x float> %543, <8 x float> %567
  store <8 x float> %568, ptr %.slot43, align 32
  %569 = load <8 x float>, ptr %.slot44, align 32
  %570 = select <8 x i1> %62, <8 x float> %561, <8 x float> %569
  store <8 x float> %570, ptr %.slot44, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false218
  %.spill.load252 = load float, ptr %.spill37, align 4
  %.splatinsert253 = insertelement <8 x float> poison, float %.spill.load252, i64 0
  %.splat254 = shufflevector <8 x float> %.splatinsert253, <8 x float> poison, <8 x i32> zeroinitializer
  %.state255 = load <8 x float>, ptr %.slot41, align 32
  %571 = fadd <8 x float> %.splat254, %.state255
  %.state256 = load <8 x float>, ptr %.slot42, align 32
  %572 = fadd <8 x float> %571, %.state256
  %.state257 = load <8 x float>, ptr %.slot43, align 32
  %573 = fadd <8 x float> %572, %.state257
  %.state258 = load <8 x float>, ptr %.slot44, align 32
  %574 = fadd <8 x float> %573, %.state258
  %575 = load <8 x float>, ptr %.spill45, align 32
  %576 = select <8 x i1> %62, <8 x float> %574, <8 x float> %575
  store <8 x float> %576, ptr %.spill45, align 32
  store i64 0, ptr %.slot46, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state259 = load i64, ptr %.slot46, align 4
  %577 = icmp slt i64 %.state259, 768
  br i1 %577, label %direct.true260, label %direct.false261

direct.schedule.23:                               ; preds = %direct.true260
  %.spill.load262 = load <8 x i64>, ptr %.spill, align 64
  %578 = add <8 x i64> %.spill.load262, zeroinitializer
  %579 = add <8 x i64> zeroinitializer, %578
  %.state263 = load i64, ptr %.slot46, align 4
  %580 = add i64 0, %.state263
  %581 = mul <8 x i64> %579, splat (i64 768)
  %.splatinsert264 = insertelement <8 x i64> poison, i64 %580, i64 0
  %.splat265 = shufflevector <8 x i64> %.splatinsert264, <8 x i64> poison, <8 x i32> zeroinitializer
  %582 = add <8 x i64> %581, %.splat265
  %.state266 = load i64, ptr %.slot46, align 4
  %583 = add i64 0, %.state266
  %tile_snapshot.spill.load267 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load267, 0
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load267, 1
  %.splatinsert268 = insertelement <8 x i64> poison, i64 %583, i64 0
  %.splat269 = shufflevector <8 x i64> %.splatinsert268, <8 x i64> poison, <8 x i32> zeroinitializer
  %586 = mul <8 x i64> %.splat269, splat (i64 32)
  %587 = add <8 x i64> %585, %586
  %588 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %584, 0
  %589 = insertvalue { <8 x ptr>, <8 x i64> } %588, <8 x i64> %587, 1
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %589, 1
  %592 = extractelement <8 x ptr> %590, i32 0
  %593 = extractelement <8 x i64> %591, i32 0
  %594 = sub i64 %593, 0
  %595 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %596 = select i1 %595, i64 %594, i64 0
  %private.contiguous.address270 = getelementptr i8, ptr %592, i64 %596
  %private.contiguous.load271 = load <8 x float>, ptr %private.contiguous.address270, align 4
  %597 = select <8 x i1> %62, <8 x float> %private.contiguous.load271, <8 x float> zeroinitializer
  %.spill.load272 = load <8 x float>, ptr %.spill45, align 32
  %598 = fdiv <8 x float> %597, %.spill.load272
  %599 = extractvalue { ptr, i64 } %38, 0
  %600 = mul <8 x i64> %582, splat (i64 4)
  %601 = getelementptr i8, ptr %599, <8 x i64> %600
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %598, <8 x ptr> %601, i32 1, <8 x i1> %62)
  %.state273 = load i64, ptr %.slot46, align 4
  %602 = add i64 %.state273, 1
  store i64 %602, ptr %.slot46, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false261
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true65:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false66:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true79:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false80:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true93:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false94:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true127:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false128:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true170:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false171:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true217:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false218:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true260:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false261:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

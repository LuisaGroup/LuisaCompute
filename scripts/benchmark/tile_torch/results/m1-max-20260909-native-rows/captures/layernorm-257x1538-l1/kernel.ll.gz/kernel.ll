; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 49216
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 98432
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 147648
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill13 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill13, align 4
  %.spill14 = alloca i64, align 8
  store i64 0, ptr %.spill14, align 4
  %.spill15 = alloca i64, align 8
  store i64 0, ptr %.spill15, align 4
  %.spill16 = alloca i64, align 8
  store i64 0, ptr %.spill16, align 4
  %.spill17 = alloca i64, align 8
  store i64 0, ptr %.spill17, align 4
  %.spill18 = alloca i64, align 8
  store i64 0, ptr %.spill18, align 4
  %.spill19 = alloca i64, align 8
  store i64 0, ptr %.spill19, align 4
  %.slot20 = alloca i64, align 8
  store i64 0, ptr %.slot20, align 4
  %.slot21 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.slot22 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot22, align 32
  %.slot23 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot23, align 32
  %.slot24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot24, align 32
  %.spill25 = alloca i64, align 8
  store i64 0, ptr %.spill25, align 4
  %.spill26 = alloca i64, align 8
  store i64 0, ptr %.spill26, align 4
  %.spill27 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill27, align 4
  %.spill28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill28, align 32
  %tile_snapshot.spill29 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill29, align 64
  %.slot30 = alloca i64, align 8
  store i64 0, ptr %.slot30, align 4
  %.spill31 = alloca i64, align 8
  store i64 0, ptr %.spill31, align 4
  %.slot32 = alloca i64, align 8
  store i64 0, ptr %.slot32, align 4
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill37, align 32
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.spill40 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill40, align 32
  %tile_snapshot.spill41 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill41, align 64
  %.slot42 = alloca i64, align 8
  store i64 0, ptr %.slot42, align 4
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %12 = getelementptr i8, ptr %argument_buffer, i64 0
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 16
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 32
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 48
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = load i32, ptr %launch_config, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 12
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 4
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 16
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 8
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 20
  %46 = load i32, ptr %45, align 4
  %47 = getelementptr i8, ptr %launch_config, i64 36
  %48 = load i32, ptr %47, align 4
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat45, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %50 = mul i32 %36, 32
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat47, %49
  %52 = mul i32 %40, 1
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat49, zeroinitializer
  %54 = mul i32 %44, 1
  %.splatinsert50 = insertelement <8 x i32> poison, i32 %54, i64 0
  %.splat51 = shufflevector <8 x i32> %.splatinsert50, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = add <8 x i32> %.splat51, zeroinitializer
  %56 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %51, 0
  %57 = insertvalue [3 x <8 x i32>] %56, <8 x i32> %53, 1
  %58 = insertvalue [3 x <8 x i32>] %57, <8 x i32> %55, 2
  %.splatinsert52 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat53 = shufflevector <8 x i32> %.splatinsert52, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat53
  %60 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  br i1 %60, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %61 = extractvalue [3 x <8 x i32>] %58, 0
  %62 = zext <8 x i32> %61 to <8 x i64>
  %63 = select <8 x i1> %59, <8 x i64> %62, <8 x i64> zeroinitializer
  %64 = select <8 x i1> %59, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %65 = sdiv <8 x i64> %63, %64
  %66 = load <8 x i64>, ptr %.spill, align 64
  %67 = select <8 x i1> %59, <8 x i64> %65, <8 x i64> %66
  store <8 x i64> %67, ptr %.spill, align 64
  %68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %68, 0
  %71 = select <8 x i1> %59, <8 x ptr> %69, <8 x ptr> %70
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %68, 1
  %74 = select <8 x i1> %59, <8 x i64> %72, <8 x i64> %73
  %75 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %71, 0
  %76 = insertvalue { <8 x ptr>, <8 x i64> } %75, <8 x i64> %74, 1
  store { <8 x ptr>, <8 x i64> } %76, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %77 = icmp slt i64 %.state, 1538
  br i1 %77, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %78 = add <8 x i64> %.spill.load, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %.state54 = load i64, ptr %.slot, align 4
  %80 = add i64 0, %.state54
  %81 = mul <8 x i64> %79, splat (i64 1538)
  %.splatinsert55 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat56 = shufflevector <8 x i64> %.splatinsert55, <8 x i64> poison, <8 x i32> zeroinitializer
  %82 = add <8 x i64> %81, %.splat56
  %83 = extractvalue { ptr, i64 } %17, 0
  %84 = mul <8 x i64> %82, splat (i64 4)
  %85 = getelementptr i8, ptr %83, <8 x i64> %84
  %86 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %85, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state57 = load i64, ptr %.slot, align 4
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %.state57, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat59, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %59, <8 x float> %86, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state60 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state60, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill13, align 4
  store i64 0, ptr %.spill14, align 4
  store i64 0, ptr %.spill15, align 4
  store i64 0, ptr %.spill16, align 4
  %tile_snapshot.spill.load61 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 1
  %104 = add <8 x i64> %103, zeroinitializer
  %105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %106 = insertvalue { <8 x ptr>, <8 x i64> } %105, <8 x i64> %104, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %106, 1
  %109 = extractelement <8 x ptr> %107, i32 0
  %110 = extractelement <8 x i64> %108, i32 0
  %111 = sub i64 %110, 0
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %113 = select i1 %112, i64 %111, i64 0
  %private.contiguous.address62 = getelementptr i8, ptr %109, i64 %113
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address62, align 4
  %114 = select <8 x i1> %59, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  store i64 1, ptr %.spill17, align 4
  %tile_snapshot.spill.load63 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load63, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load63, 1
  %117 = add <8 x i64> %116, splat (i64 32)
  %118 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %119 = insertvalue { <8 x ptr>, <8 x i64> } %118, <8 x i64> %117, 1
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %119, 1
  %122 = extractelement <8 x ptr> %120, i32 0
  %123 = extractelement <8 x i64> %121, i32 0
  %124 = sub i64 %123, 0
  %125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %126 = select i1 %125, i64 %124, i64 0
  %private.contiguous.address64 = getelementptr i8, ptr %122, i64 %126
  %private.contiguous.load65 = load <8 x float>, ptr %private.contiguous.address64, align 4
  %127 = select <8 x i1> %59, <8 x float> %private.contiguous.load65, <8 x float> zeroinitializer
  store i64 2, ptr %.spill18, align 4
  %tile_snapshot.spill.load66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load66, 0
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load66, 1
  %130 = add <8 x i64> %129, splat (i64 64)
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %128, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %135 = extractelement <8 x ptr> %133, i32 0
  %136 = extractelement <8 x i64> %134, i32 0
  %137 = sub i64 %136, 0
  %138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %139 = select i1 %138, i64 %137, i64 0
  %private.contiguous.address67 = getelementptr i8, ptr %135, i64 %139
  %private.contiguous.load68 = load <8 x float>, ptr %private.contiguous.address67, align 4
  %140 = select <8 x i1> %59, <8 x float> %private.contiguous.load68, <8 x float> zeroinitializer
  store i64 3, ptr %.spill19, align 4
  %tile_snapshot.spill.load69 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 1
  %143 = add <8 x i64> %142, splat (i64 96)
  %144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %141, 0
  %145 = insertvalue { <8 x ptr>, <8 x i64> } %144, <8 x i64> %143, 1
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %148 = extractelement <8 x ptr> %146, i32 0
  %149 = extractelement <8 x i64> %147, i32 0
  %150 = sub i64 %149, 0
  %151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %152 = select i1 %151, i64 %150, i64 0
  %private.contiguous.address70 = getelementptr i8, ptr %148, i64 %152
  %private.contiguous.load71 = load <8 x float>, ptr %private.contiguous.address70, align 4
  %153 = select <8 x i1> %59, <8 x float> %private.contiguous.load71, <8 x float> zeroinitializer
  store i64 4, ptr %.slot20, align 4
  %154 = load <8 x float>, ptr %.slot21, align 32
  %155 = select <8 x i1> %59, <8 x float> %114, <8 x float> %154
  store <8 x float> %155, ptr %.slot21, align 32
  %156 = load <8 x float>, ptr %.slot22, align 32
  %157 = select <8 x i1> %59, <8 x float> %127, <8 x float> %156
  store <8 x float> %157, ptr %.slot22, align 32
  %158 = load <8 x float>, ptr %.slot23, align 32
  %159 = select <8 x i1> %59, <8 x float> %140, <8 x float> %158
  store <8 x float> %159, ptr %.slot23, align 32
  %160 = load <8 x float>, ptr %.slot24, align 32
  %161 = select <8 x i1> %59, <8 x float> %153, <8 x float> %160
  store <8 x float> %161, ptr %.slot24, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state72 = load i64, ptr %.slot20, align 4
  %162 = icmp slt i64 %.state72, 1536
  br i1 %162, label %direct.true73, label %direct.false74

direct.schedule.5:                                ; preds = %direct.true73
  %.state75 = load i64, ptr %.slot20, align 4
  %163 = add i64 %.state75, 0
  %164 = sdiv i64 %163, 1
  %.spill.load76 = load i64, ptr %.spill15, align 4
  %165 = add i64 %.spill.load76, %164
  %tile_snapshot.spill.load77 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load77, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load77, 1
  %.splatinsert78 = insertelement <8 x i64> poison, i64 %165, i64 0
  %.splat79 = shufflevector <8 x i64> %.splatinsert78, <8 x i64> poison, <8 x i32> zeroinitializer
  %168 = mul <8 x i64> %.splat79, splat (i64 32)
  %169 = add <8 x i64> %167, %168
  %170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %171 = insertvalue { <8 x ptr>, <8 x i64> } %170, <8 x i64> %169, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %174 = extractelement <8 x ptr> %172, i32 0
  %175 = extractelement <8 x i64> %173, i32 0
  %176 = sub i64 %175, 0
  %177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %178 = select i1 %177, i64 %176, i64 0
  %private.contiguous.address80 = getelementptr i8, ptr %174, i64 %178
  %private.contiguous.load81 = load <8 x float>, ptr %private.contiguous.address80, align 4
  %179 = select <8 x i1> %59, <8 x float> %private.contiguous.load81, <8 x float> zeroinitializer
  %.state82 = load <8 x float>, ptr %.slot21, align 32
  %180 = fadd <8 x float> %.state82, %179
  %.state83 = load i64, ptr %.slot20, align 4
  %181 = add i64 %.state83, 1
  %182 = sdiv i64 %181, 1
  %.spill.load84 = load i64, ptr %.spill15, align 4
  %183 = add i64 %.spill.load84, %182
  %tile_snapshot.spill.load85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 1
  %.splatinsert86 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat87 = shufflevector <8 x i64> %.splatinsert86, <8 x i64> poison, <8 x i32> zeroinitializer
  %186 = mul <8 x i64> %.splat87, splat (i64 32)
  %187 = add <8 x i64> %185, %186
  %188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %184, 0
  %189 = insertvalue { <8 x ptr>, <8 x i64> } %188, <8 x i64> %187, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %189, 1
  %192 = extractelement <8 x ptr> %190, i32 0
  %193 = extractelement <8 x i64> %191, i32 0
  %194 = sub i64 %193, 0
  %195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %196 = select i1 %195, i64 %194, i64 0
  %private.contiguous.address88 = getelementptr i8, ptr %192, i64 %196
  %private.contiguous.load89 = load <8 x float>, ptr %private.contiguous.address88, align 4
  %197 = select <8 x i1> %59, <8 x float> %private.contiguous.load89, <8 x float> zeroinitializer
  %.state90 = load <8 x float>, ptr %.slot22, align 32
  %198 = fadd <8 x float> %.state90, %197
  %.state91 = load i64, ptr %.slot20, align 4
  %199 = add i64 %.state91, 2
  %200 = sdiv i64 %199, 1
  %.spill.load92 = load i64, ptr %.spill15, align 4
  %201 = add i64 %.spill.load92, %200
  %tile_snapshot.spill.load93 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 1
  %.splatinsert94 = insertelement <8 x i64> poison, i64 %201, i64 0
  %.splat95 = shufflevector <8 x i64> %.splatinsert94, <8 x i64> poison, <8 x i32> zeroinitializer
  %204 = mul <8 x i64> %.splat95, splat (i64 32)
  %205 = add <8 x i64> %203, %204
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %202, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %207, 1
  %210 = extractelement <8 x ptr> %208, i32 0
  %211 = extractelement <8 x i64> %209, i32 0
  %212 = sub i64 %211, 0
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address96 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.load97 = load <8 x float>, ptr %private.contiguous.address96, align 4
  %215 = select <8 x i1> %59, <8 x float> %private.contiguous.load97, <8 x float> zeroinitializer
  %.state98 = load <8 x float>, ptr %.slot23, align 32
  %216 = fadd <8 x float> %.state98, %215
  %.state99 = load i64, ptr %.slot20, align 4
  %217 = add i64 %.state99, 3
  %218 = sdiv i64 %217, 1
  %.spill.load100 = load i64, ptr %.spill15, align 4
  %219 = add i64 %.spill.load100, %218
  %tile_snapshot.spill.load101 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 1
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %219, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %222 = mul <8 x i64> %.splat103, splat (i64 32)
  %223 = add <8 x i64> %221, %222
  %224 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %220, 0
  %225 = insertvalue { <8 x ptr>, <8 x i64> } %224, <8 x i64> %223, 1
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %225, 1
  %228 = extractelement <8 x ptr> %226, i32 0
  %229 = extractelement <8 x i64> %227, i32 0
  %230 = sub i64 %229, 0
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %232 = select i1 %231, i64 %230, i64 0
  %private.contiguous.address104 = getelementptr i8, ptr %228, i64 %232
  %private.contiguous.load105 = load <8 x float>, ptr %private.contiguous.address104, align 4
  %233 = select <8 x i1> %59, <8 x float> %private.contiguous.load105, <8 x float> zeroinitializer
  %.state106 = load <8 x float>, ptr %.slot24, align 32
  %234 = fadd <8 x float> %.state106, %233
  %.state107 = load i64, ptr %.slot20, align 4
  %235 = add i64 %.state107, 4
  store i64 %235, ptr %.slot20, align 4
  %236 = load <8 x float>, ptr %.slot21, align 32
  %237 = select <8 x i1> %59, <8 x float> %180, <8 x float> %236
  store <8 x float> %237, ptr %.slot21, align 32
  %238 = load <8 x float>, ptr %.slot22, align 32
  %239 = select <8 x i1> %59, <8 x float> %198, <8 x float> %238
  store <8 x float> %239, ptr %.slot22, align 32
  %240 = load <8 x float>, ptr %.slot23, align 32
  %241 = select <8 x i1> %59, <8 x float> %216, <8 x float> %240
  store <8 x float> %241, ptr %.slot23, align 32
  %242 = load <8 x float>, ptr %.slot24, align 32
  %243 = select <8 x i1> %59, <8 x float> %234, <8 x float> %242
  store <8 x float> %243, ptr %.slot24, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false74
  %.spill.load108 = load i64, ptr %.spill15, align 4
  %244 = add i64 %.spill.load108, 1536
  store i64 %244, ptr %.spill25, align 4
  %tile_snapshot.spill.load109 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 0
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 1
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %244, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %247 = mul <8 x i64> %.splat111, splat (i64 32)
  %248 = add <8 x i64> %246, %247
  %249 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %245, 0
  %250 = insertvalue { <8 x ptr>, <8 x i64> } %249, <8 x i64> %248, 1
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %250, 1
  %253 = extractelement <8 x ptr> %251, i32 0
  %254 = extractelement <8 x i64> %252, i32 0
  %255 = sub i64 %254, 0
  %256 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %257 = select i1 %256, i64 %255, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %253, i64 %257
  %private.contiguous.load113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %258 = select <8 x i1> %59, <8 x float> %private.contiguous.load113, <8 x float> zeroinitializer
  %.state114 = load <8 x float>, ptr %.slot21, align 32
  %259 = fadd <8 x float> %.state114, %258
  %.spill.load115 = load i64, ptr %.spill15, align 4
  %260 = add i64 %.spill.load115, 1537
  store i64 %260, ptr %.spill26, align 4
  %tile_snapshot.spill.load116 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 1
  %.splatinsert117 = insertelement <8 x i64> poison, i64 %260, i64 0
  %.splat118 = shufflevector <8 x i64> %.splatinsert117, <8 x i64> poison, <8 x i32> zeroinitializer
  %263 = mul <8 x i64> %.splat118, splat (i64 32)
  %264 = add <8 x i64> %262, %263
  %265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %266 = insertvalue { <8 x ptr>, <8 x i64> } %265, <8 x i64> %264, 1
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %266, 1
  %269 = extractelement <8 x ptr> %267, i32 0
  %270 = extractelement <8 x i64> %268, i32 0
  %271 = sub i64 %270, 0
  %272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %273 = select i1 %272, i64 %271, i64 0
  %private.contiguous.address119 = getelementptr i8, ptr %269, i64 %273
  %private.contiguous.load120 = load <8 x float>, ptr %private.contiguous.address119, align 4
  %274 = select <8 x i1> %59, <8 x float> %private.contiguous.load120, <8 x float> zeroinitializer
  %.state121 = load <8 x float>, ptr %.slot22, align 32
  %275 = fadd <8 x float> %.state121, %274
  %.spill.load122 = load float, ptr %.spill13, align 4
  %.splatinsert123 = insertelement <8 x float> poison, float %.spill.load122, i64 0
  %.splat124 = shufflevector <8 x float> %.splatinsert123, <8 x float> poison, <8 x i32> zeroinitializer
  %276 = fadd <8 x float> %.splat124, %259
  %277 = fadd <8 x float> %276, %275
  %.state125 = load <8 x float>, ptr %.slot23, align 32
  %278 = fadd <8 x float> %277, %.state125
  %.state126 = load <8 x float>, ptr %.slot24, align 32
  %279 = fadd <8 x float> %278, %.state126
  store float 1.538000e+03, ptr %.spill27, align 4
  %280 = fdiv <8 x float> %279, splat (float 1.538000e+03)
  %281 = load <8 x float>, ptr %.spill28, align 32
  %282 = select <8 x i1> %59, <8 x float> %280, <8 x float> %281
  store <8 x float> %282, ptr %.spill28, align 32
  %283 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %283, 0
  %286 = select <8 x i1> %59, <8 x ptr> %284, <8 x ptr> %285
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %283, 1
  %289 = select <8 x i1> %59, <8 x i64> %287, <8 x i64> %288
  %290 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %286, 0
  %291 = insertvalue { <8 x ptr>, <8 x i64> } %290, <8 x i64> %289, 1
  store { <8 x ptr>, <8 x i64> } %291, ptr %tile_snapshot.spill29, align 64
  store i64 0, ptr %.slot30, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state127 = load i64, ptr %.slot30, align 4
  %292 = icmp slt i64 %.state127, 1538
  br i1 %292, label %direct.true128, label %direct.false129

direct.schedule.8:                                ; preds = %direct.true128
  %.state130 = load i64, ptr %.slot30, align 4
  %293 = add i64 0, %.state130
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %293, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %296 = mul <8 x i64> %.splat133, splat (i64 32)
  %297 = add <8 x i64> %295, %296
  %298 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %294, 0
  %299 = insertvalue { <8 x ptr>, <8 x i64> } %298, <8 x i64> %297, 1
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %299, 1
  %302 = extractelement <8 x ptr> %300, i32 0
  %303 = extractelement <8 x i64> %301, i32 0
  %304 = sub i64 %303, 0
  %305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %306 = select i1 %305, i64 %304, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %302, i64 %306
  %private.contiguous.load135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %307 = select <8 x i1> %59, <8 x float> %private.contiguous.load135, <8 x float> zeroinitializer
  %.spill.load136 = load <8 x float>, ptr %.spill28, align 32
  %308 = fsub <8 x float> %307, %.spill.load136
  %tile_snapshot.spill.load137 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 1
  %.state138 = load i64, ptr %.slot30, align 4
  %.splatinsert139 = insertelement <8 x i64> poison, i64 %.state138, i64 0
  %.splat140 = shufflevector <8 x i64> %.splatinsert139, <8 x i64> poison, <8 x i32> zeroinitializer
  %311 = mul <8 x i64> %.splat140, splat (i64 32)
  %312 = add <8 x i64> %310, %311
  %313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %309, 0
  %314 = insertvalue { <8 x ptr>, <8 x i64> } %313, <8 x i64> %312, 1
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %314, 1
  %317 = extractelement <8 x ptr> %315, i32 0
  %318 = extractelement <8 x i64> %316, i32 0
  %319 = sub i64 %318, 0
  %320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %321 = select i1 %320, i64 %319, i64 0
  %private.contiguous.address141 = getelementptr i8, ptr %317, i64 %321
  %private.contiguous.preserve142 = load <8 x float>, ptr %private.contiguous.address141, align 4
  %322 = select <8 x i1> %59, <8 x float> %308, <8 x float> %private.contiguous.preserve142
  store <8 x float> %322, ptr %private.contiguous.address141, align 4
  %.state143 = load i64, ptr %.slot30, align 4
  %323 = add i64 %.state143, 1
  store i64 %323, ptr %.slot30, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false129
  store i64 0, ptr %.spill31, align 4
  %.spill.load144 = load i64, ptr %.spill16, align 4
  %324 = add i64 0, %.spill.load144
  %tile_snapshot.spill.load145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load145, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load145, 1
  %.splatinsert146 = insertelement <8 x i64> poison, i64 %324, i64 0
  %.splat147 = shufflevector <8 x i64> %.splatinsert146, <8 x i64> poison, <8 x i32> zeroinitializer
  %327 = mul <8 x i64> %.splat147, splat (i64 32)
  %328 = add <8 x i64> %326, %327
  %329 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %325, 0
  %330 = insertvalue { <8 x ptr>, <8 x i64> } %329, <8 x i64> %328, 1
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %330, 1
  %333 = extractelement <8 x ptr> %331, i32 0
  %334 = extractelement <8 x i64> %332, i32 0
  %335 = sub i64 %334, 0
  %336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %337 = select i1 %336, i64 %335, i64 0
  %private.contiguous.address148 = getelementptr i8, ptr %333, i64 %337
  %private.contiguous.load149 = load <8 x float>, ptr %private.contiguous.address148, align 4
  %338 = select <8 x i1> %59, <8 x float> %private.contiguous.load149, <8 x float> zeroinitializer
  %339 = fmul <8 x float> %338, %338
  %.spill.load150 = load i64, ptr %.spill17, align 4
  %340 = add i64 0, %.spill.load150
  %tile_snapshot.spill.load151 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load151, 0
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load151, 1
  %.splatinsert152 = insertelement <8 x i64> poison, i64 %340, i64 0
  %.splat153 = shufflevector <8 x i64> %.splatinsert152, <8 x i64> poison, <8 x i32> zeroinitializer
  %343 = mul <8 x i64> %.splat153, splat (i64 32)
  %344 = add <8 x i64> %342, %343
  %345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %341, 0
  %346 = insertvalue { <8 x ptr>, <8 x i64> } %345, <8 x i64> %344, 1
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %346, 1
  %349 = extractelement <8 x ptr> %347, i32 0
  %350 = extractelement <8 x i64> %348, i32 0
  %351 = sub i64 %350, 0
  %352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %353 = select i1 %352, i64 %351, i64 0
  %private.contiguous.address154 = getelementptr i8, ptr %349, i64 %353
  %private.contiguous.load155 = load <8 x float>, ptr %private.contiguous.address154, align 4
  %354 = select <8 x i1> %59, <8 x float> %private.contiguous.load155, <8 x float> zeroinitializer
  %355 = fmul <8 x float> %354, %354
  %.spill.load156 = load i64, ptr %.spill18, align 4
  %356 = add i64 0, %.spill.load156
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %.splatinsert158 = insertelement <8 x i64> poison, i64 %356, i64 0
  %.splat159 = shufflevector <8 x i64> %.splatinsert158, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = mul <8 x i64> %.splat159, splat (i64 32)
  %360 = add <8 x i64> %358, %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = extractelement <8 x ptr> %363, i32 0
  %366 = extractelement <8 x i64> %364, i32 0
  %367 = sub i64 %366, 0
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %369 = select i1 %368, i64 %367, i64 0
  %private.contiguous.address160 = getelementptr i8, ptr %365, i64 %369
  %private.contiguous.load161 = load <8 x float>, ptr %private.contiguous.address160, align 4
  %370 = select <8 x i1> %59, <8 x float> %private.contiguous.load161, <8 x float> zeroinitializer
  %371 = fmul <8 x float> %370, %370
  %.spill.load162 = load i64, ptr %.spill19, align 4
  %372 = add i64 0, %.spill.load162
  %tile_snapshot.spill.load163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %.splatinsert164 = insertelement <8 x i64> poison, i64 %372, i64 0
  %.splat165 = shufflevector <8 x i64> %.splatinsert164, <8 x i64> poison, <8 x i32> zeroinitializer
  %375 = mul <8 x i64> %.splat165, splat (i64 32)
  %376 = add <8 x i64> %374, %375
  %377 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %373, 0
  %378 = insertvalue { <8 x ptr>, <8 x i64> } %377, <8 x i64> %376, 1
  %379 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %378, 1
  %381 = extractelement <8 x ptr> %379, i32 0
  %382 = extractelement <8 x i64> %380, i32 0
  %383 = sub i64 %382, 0
  %384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %385 = select i1 %384, i64 %383, i64 0
  %private.contiguous.address166 = getelementptr i8, ptr %381, i64 %385
  %private.contiguous.load167 = load <8 x float>, ptr %private.contiguous.address166, align 4
  %386 = select <8 x i1> %59, <8 x float> %private.contiguous.load167, <8 x float> zeroinitializer
  %387 = fmul <8 x float> %386, %386
  store i64 4, ptr %.slot32, align 4
  %388 = load <8 x float>, ptr %.slot33, align 32
  %389 = select <8 x i1> %59, <8 x float> %339, <8 x float> %388
  store <8 x float> %389, ptr %.slot33, align 32
  %390 = load <8 x float>, ptr %.slot34, align 32
  %391 = select <8 x i1> %59, <8 x float> %355, <8 x float> %390
  store <8 x float> %391, ptr %.slot34, align 32
  %392 = load <8 x float>, ptr %.slot35, align 32
  %393 = select <8 x i1> %59, <8 x float> %371, <8 x float> %392
  store <8 x float> %393, ptr %.slot35, align 32
  %394 = load <8 x float>, ptr %.slot36, align 32
  %395 = select <8 x i1> %59, <8 x float> %387, <8 x float> %394
  store <8 x float> %395, ptr %.slot36, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state168 = load i64, ptr %.slot32, align 4
  %396 = icmp slt i64 %.state168, 1536
  br i1 %396, label %direct.true169, label %direct.false170

direct.schedule.11:                               ; preds = %direct.true169
  %.state171 = load i64, ptr %.slot32, align 4
  %397 = add i64 %.state171, 0
  %398 = sdiv i64 %397, 1
  %.spill.load172 = load i64, ptr %.spill15, align 4
  %399 = add i64 %.spill.load172, %398
  %.spill.load173 = load i64, ptr %.spill31, align 4
  %400 = add i64 %.spill.load173, %399
  %tile_snapshot.spill.load174 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %.splatinsert175 = insertelement <8 x i64> poison, i64 %400, i64 0
  %.splat176 = shufflevector <8 x i64> %.splatinsert175, <8 x i64> poison, <8 x i32> zeroinitializer
  %403 = mul <8 x i64> %.splat176, splat (i64 32)
  %404 = add <8 x i64> %402, %403
  %405 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %401, 0
  %406 = insertvalue { <8 x ptr>, <8 x i64> } %405, <8 x i64> %404, 1
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %406, 1
  %409 = extractelement <8 x ptr> %407, i32 0
  %410 = extractelement <8 x i64> %408, i32 0
  %411 = sub i64 %410, 0
  %412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %413 = select i1 %412, i64 %411, i64 0
  %private.contiguous.address177 = getelementptr i8, ptr %409, i64 %413
  %private.contiguous.load178 = load <8 x float>, ptr %private.contiguous.address177, align 4
  %414 = select <8 x i1> %59, <8 x float> %private.contiguous.load178, <8 x float> zeroinitializer
  %415 = fmul <8 x float> %414, %414
  %.state179 = load <8 x float>, ptr %.slot33, align 32
  %416 = fadd <8 x float> %.state179, %415
  %.state180 = load i64, ptr %.slot32, align 4
  %417 = add i64 %.state180, 1
  %418 = sdiv i64 %417, 1
  %.spill.load181 = load i64, ptr %.spill15, align 4
  %419 = add i64 %.spill.load181, %418
  %.spill.load182 = load i64, ptr %.spill31, align 4
  %420 = add i64 %.spill.load182, %419
  %tile_snapshot.spill.load183 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load183, 0
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load183, 1
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %420, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %423 = mul <8 x i64> %.splat185, splat (i64 32)
  %424 = add <8 x i64> %422, %423
  %425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %421, 0
  %426 = insertvalue { <8 x ptr>, <8 x i64> } %425, <8 x i64> %424, 1
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %426, 1
  %429 = extractelement <8 x ptr> %427, i32 0
  %430 = extractelement <8 x i64> %428, i32 0
  %431 = sub i64 %430, 0
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %433 = select i1 %432, i64 %431, i64 0
  %private.contiguous.address186 = getelementptr i8, ptr %429, i64 %433
  %private.contiguous.load187 = load <8 x float>, ptr %private.contiguous.address186, align 4
  %434 = select <8 x i1> %59, <8 x float> %private.contiguous.load187, <8 x float> zeroinitializer
  %435 = fmul <8 x float> %434, %434
  %.state188 = load <8 x float>, ptr %.slot34, align 32
  %436 = fadd <8 x float> %.state188, %435
  %.state189 = load i64, ptr %.slot32, align 4
  %437 = add i64 %.state189, 2
  %438 = sdiv i64 %437, 1
  %.spill.load190 = load i64, ptr %.spill15, align 4
  %439 = add i64 %.spill.load190, %438
  %.spill.load191 = load i64, ptr %.spill31, align 4
  %440 = add i64 %.spill.load191, %439
  %tile_snapshot.spill.load192 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %.splatinsert193 = insertelement <8 x i64> poison, i64 %440, i64 0
  %.splat194 = shufflevector <8 x i64> %.splatinsert193, <8 x i64> poison, <8 x i32> zeroinitializer
  %443 = mul <8 x i64> %.splat194, splat (i64 32)
  %444 = add <8 x i64> %442, %443
  %445 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %441, 0
  %446 = insertvalue { <8 x ptr>, <8 x i64> } %445, <8 x i64> %444, 1
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %446, 1
  %449 = extractelement <8 x ptr> %447, i32 0
  %450 = extractelement <8 x i64> %448, i32 0
  %451 = sub i64 %450, 0
  %452 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %453 = select i1 %452, i64 %451, i64 0
  %private.contiguous.address195 = getelementptr i8, ptr %449, i64 %453
  %private.contiguous.load196 = load <8 x float>, ptr %private.contiguous.address195, align 4
  %454 = select <8 x i1> %59, <8 x float> %private.contiguous.load196, <8 x float> zeroinitializer
  %455 = fmul <8 x float> %454, %454
  %.state197 = load <8 x float>, ptr %.slot35, align 32
  %456 = fadd <8 x float> %.state197, %455
  %.state198 = load i64, ptr %.slot32, align 4
  %457 = add i64 %.state198, 3
  %458 = sdiv i64 %457, 1
  %.spill.load199 = load i64, ptr %.spill15, align 4
  %459 = add i64 %.spill.load199, %458
  %.spill.load200 = load i64, ptr %.spill31, align 4
  %460 = add i64 %.spill.load200, %459
  %tile_snapshot.spill.load201 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %461 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 0
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 1
  %.splatinsert202 = insertelement <8 x i64> poison, i64 %460, i64 0
  %.splat203 = shufflevector <8 x i64> %.splatinsert202, <8 x i64> poison, <8 x i32> zeroinitializer
  %463 = mul <8 x i64> %.splat203, splat (i64 32)
  %464 = add <8 x i64> %462, %463
  %465 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %461, 0
  %466 = insertvalue { <8 x ptr>, <8 x i64> } %465, <8 x i64> %464, 1
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %466, 1
  %469 = extractelement <8 x ptr> %467, i32 0
  %470 = extractelement <8 x i64> %468, i32 0
  %471 = sub i64 %470, 0
  %472 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %473 = select i1 %472, i64 %471, i64 0
  %private.contiguous.address204 = getelementptr i8, ptr %469, i64 %473
  %private.contiguous.load205 = load <8 x float>, ptr %private.contiguous.address204, align 4
  %474 = select <8 x i1> %59, <8 x float> %private.contiguous.load205, <8 x float> zeroinitializer
  %475 = fmul <8 x float> %474, %474
  %.state206 = load <8 x float>, ptr %.slot36, align 32
  %476 = fadd <8 x float> %.state206, %475
  %.state207 = load i64, ptr %.slot32, align 4
  %477 = add i64 %.state207, 4
  store i64 %477, ptr %.slot32, align 4
  %478 = load <8 x float>, ptr %.slot33, align 32
  %479 = select <8 x i1> %59, <8 x float> %416, <8 x float> %478
  store <8 x float> %479, ptr %.slot33, align 32
  %480 = load <8 x float>, ptr %.slot34, align 32
  %481 = select <8 x i1> %59, <8 x float> %436, <8 x float> %480
  store <8 x float> %481, ptr %.slot34, align 32
  %482 = load <8 x float>, ptr %.slot35, align 32
  %483 = select <8 x i1> %59, <8 x float> %456, <8 x float> %482
  store <8 x float> %483, ptr %.slot35, align 32
  %484 = load <8 x float>, ptr %.slot36, align 32
  %485 = select <8 x i1> %59, <8 x float> %476, <8 x float> %484
  store <8 x float> %485, ptr %.slot36, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false170
  %.spill.load208 = load i64, ptr %.spill31, align 4
  %.spill.load209 = load i64, ptr %.spill25, align 4
  %486 = add i64 %.spill.load208, %.spill.load209
  %tile_snapshot.spill.load210 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %487 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 0
  %488 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 1
  %.splatinsert211 = insertelement <8 x i64> poison, i64 %486, i64 0
  %.splat212 = shufflevector <8 x i64> %.splatinsert211, <8 x i64> poison, <8 x i32> zeroinitializer
  %489 = mul <8 x i64> %.splat212, splat (i64 32)
  %490 = add <8 x i64> %488, %489
  %491 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %487, 0
  %492 = insertvalue { <8 x ptr>, <8 x i64> } %491, <8 x i64> %490, 1
  %493 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %492, 1
  %495 = extractelement <8 x ptr> %493, i32 0
  %496 = extractelement <8 x i64> %494, i32 0
  %497 = sub i64 %496, 0
  %498 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %499 = select i1 %498, i64 %497, i64 0
  %private.contiguous.address213 = getelementptr i8, ptr %495, i64 %499
  %private.contiguous.load214 = load <8 x float>, ptr %private.contiguous.address213, align 4
  %500 = select <8 x i1> %59, <8 x float> %private.contiguous.load214, <8 x float> zeroinitializer
  %501 = fmul <8 x float> %500, %500
  %.state215 = load <8 x float>, ptr %.slot33, align 32
  %502 = fadd <8 x float> %.state215, %501
  %.spill.load216 = load i64, ptr %.spill31, align 4
  %.spill.load217 = load i64, ptr %.spill26, align 4
  %503 = add i64 %.spill.load216, %.spill.load217
  %tile_snapshot.spill.load218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 0
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 1
  %.splatinsert219 = insertelement <8 x i64> poison, i64 %503, i64 0
  %.splat220 = shufflevector <8 x i64> %.splatinsert219, <8 x i64> poison, <8 x i32> zeroinitializer
  %506 = mul <8 x i64> %.splat220, splat (i64 32)
  %507 = add <8 x i64> %505, %506
  %508 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %504, 0
  %509 = insertvalue { <8 x ptr>, <8 x i64> } %508, <8 x i64> %507, 1
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %511 = extractvalue { <8 x ptr>, <8 x i64> } %509, 1
  %512 = extractelement <8 x ptr> %510, i32 0
  %513 = extractelement <8 x i64> %511, i32 0
  %514 = sub i64 %513, 0
  %515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %516 = select i1 %515, i64 %514, i64 0
  %private.contiguous.address221 = getelementptr i8, ptr %512, i64 %516
  %private.contiguous.load222 = load <8 x float>, ptr %private.contiguous.address221, align 4
  %517 = select <8 x i1> %59, <8 x float> %private.contiguous.load222, <8 x float> zeroinitializer
  %518 = fmul <8 x float> %517, %517
  %.state223 = load <8 x float>, ptr %.slot34, align 32
  %519 = fadd <8 x float> %.state223, %518
  %.spill.load224 = load float, ptr %.spill13, align 4
  %.splatinsert225 = insertelement <8 x float> poison, float %.spill.load224, i64 0
  %.splat226 = shufflevector <8 x float> %.splatinsert225, <8 x float> poison, <8 x i32> zeroinitializer
  %520 = fadd <8 x float> %.splat226, %502
  %521 = fadd <8 x float> %520, %519
  %.state227 = load <8 x float>, ptr %.slot35, align 32
  %522 = fadd <8 x float> %521, %.state227
  %.state228 = load <8 x float>, ptr %.slot36, align 32
  %523 = fadd <8 x float> %522, %.state228
  %.spill.load229 = load float, ptr %.spill27, align 4
  %.splatinsert230 = insertelement <8 x float> poison, float %.spill.load229, i64 0
  %.splat231 = shufflevector <8 x float> %.splatinsert230, <8 x float> poison, <8 x i32> zeroinitializer
  %524 = fdiv <8 x float> %523, %.splat231
  %525 = load <8 x float>, ptr %.spill37, align 32
  %526 = select <8 x i1> %59, <8 x float> %524, <8 x float> %525
  store <8 x float> %526, ptr %.spill37, align 32
  %527 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %527, 0
  %530 = select <8 x i1> %59, <8 x ptr> %528, <8 x ptr> %529
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %527, 1
  %533 = select <8 x i1> %59, <8 x i64> %531, <8 x i64> %532
  %534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %530, 0
  %535 = insertvalue { <8 x ptr>, <8 x i64> } %534, <8 x i64> %533, 1
  store { <8 x ptr>, <8 x i64> } %535, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state232 = load i64, ptr %.slot39, align 4
  %536 = icmp slt i64 %.state232, 1538
  br i1 %536, label %direct.true233, label %direct.false234

direct.schedule.14:                               ; preds = %direct.true233
  %.spill.load235 = load i64, ptr %.spill14, align 4
  %537 = add i64 %.spill.load235, 0
  %.state236 = load i64, ptr %.slot39, align 4
  %538 = add i64 0, %.state236
  %539 = mul i64 %537, 1538
  %540 = add i64 %539, %538
  %541 = extractvalue { ptr, i64 } %23, 0
  %542 = mul i64 %540, 4
  %543 = getelementptr i8, ptr %541, i64 %542
  %544 = load float, ptr %543, align 4
  %.splatinsert237 = insertelement <8 x float> poison, float %544, i64 0
  %.splat238 = shufflevector <8 x float> %.splatinsert237, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load239 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 0
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 1
  %.state240 = load i64, ptr %.slot39, align 4
  %.splatinsert241 = insertelement <8 x i64> poison, i64 %.state240, i64 0
  %.splat242 = shufflevector <8 x i64> %.splatinsert241, <8 x i64> poison, <8 x i32> zeroinitializer
  %547 = mul <8 x i64> %.splat242, splat (i64 32)
  %548 = add <8 x i64> %546, %547
  %549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %545, 0
  %550 = insertvalue { <8 x ptr>, <8 x i64> } %549, <8 x i64> %548, 1
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %550, 1
  %553 = extractelement <8 x ptr> %551, i32 0
  %554 = extractelement <8 x i64> %552, i32 0
  %555 = sub i64 %554, 0
  %556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %557 = select i1 %556, i64 %555, i64 0
  %private.contiguous.address243 = getelementptr i8, ptr %553, i64 %557
  %private.contiguous.preserve244 = load <8 x float>, ptr %private.contiguous.address243, align 4
  %558 = select <8 x i1> %59, <8 x float> %.splat238, <8 x float> %private.contiguous.preserve244
  store <8 x float> %558, ptr %private.contiguous.address243, align 4
  %.state245 = load i64, ptr %.slot39, align 4
  %559 = add i64 %.state245, 1
  store i64 %559, ptr %.slot39, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false234
  %.spill.load246 = load <8 x float>, ptr %.spill37, align 32
  %560 = fadd <8 x float> %.spill.load246, splat (float 0x3EE4F8B580000000)
  %561 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %560)
  %562 = load <8 x float>, ptr %.spill40, align 32
  %563 = select <8 x i1> %59, <8 x float> %561, <8 x float> %562
  store <8 x float> %563, ptr %.spill40, align 32
  %564 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %565 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %564, 0
  %567 = select <8 x i1> %59, <8 x ptr> %565, <8 x ptr> %566
  %568 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %564, 1
  %570 = select <8 x i1> %59, <8 x i64> %568, <8 x i64> %569
  %571 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %567, 0
  %572 = insertvalue { <8 x ptr>, <8 x i64> } %571, <8 x i64> %570, 1
  store { <8 x ptr>, <8 x i64> } %572, ptr %tile_snapshot.spill41, align 64
  store i64 0, ptr %.slot42, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state247 = load i64, ptr %.slot42, align 4
  %573 = icmp slt i64 %.state247, 1538
  br i1 %573, label %direct.true248, label %direct.false249

direct.schedule.17:                               ; preds = %direct.true248
  %.spill.load250 = load i64, ptr %.spill14, align 4
  %574 = add i64 %.spill.load250, 0
  %.state251 = load i64, ptr %.slot42, align 4
  %575 = add i64 0, %.state251
  %576 = mul i64 %574, 1538
  %577 = add i64 %576, %575
  %578 = extractvalue { ptr, i64 } %29, 0
  %579 = mul i64 %577, 4
  %580 = getelementptr i8, ptr %578, i64 %579
  %581 = load float, ptr %580, align 4
  %.splatinsert252 = insertelement <8 x float> poison, float %581, i64 0
  %.splat253 = shufflevector <8 x float> %.splatinsert252, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load254 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %.state255 = load i64, ptr %.slot42, align 4
  %.splatinsert256 = insertelement <8 x i64> poison, i64 %.state255, i64 0
  %.splat257 = shufflevector <8 x i64> %.splatinsert256, <8 x i64> poison, <8 x i32> zeroinitializer
  %584 = mul <8 x i64> %.splat257, splat (i64 32)
  %585 = add <8 x i64> %583, %584
  %586 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %582, 0
  %587 = insertvalue { <8 x ptr>, <8 x i64> } %586, <8 x i64> %585, 1
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %587, 1
  %590 = extractelement <8 x ptr> %588, i32 0
  %591 = extractelement <8 x i64> %589, i32 0
  %592 = sub i64 %591, 0
  %593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %594 = select i1 %593, i64 %592, i64 0
  %private.contiguous.address258 = getelementptr i8, ptr %590, i64 %594
  %private.contiguous.preserve259 = load <8 x float>, ptr %private.contiguous.address258, align 4
  %595 = select <8 x i1> %59, <8 x float> %.splat253, <8 x float> %private.contiguous.preserve259
  store <8 x float> %595, ptr %private.contiguous.address258, align 4
  %.state260 = load i64, ptr %.slot42, align 4
  %596 = add i64 %.state260, 1
  store i64 %596, ptr %.slot42, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false249
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state261 = load i64, ptr %.slot43, align 4
  %597 = icmp slt i64 %.state261, 1538
  br i1 %597, label %direct.true262, label %direct.false263

direct.schedule.20:                               ; preds = %direct.true262
  %.spill.load264 = load <8 x i64>, ptr %.spill, align 64
  %598 = add <8 x i64> %.spill.load264, zeroinitializer
  %599 = add <8 x i64> zeroinitializer, %598
  %.state265 = load i64, ptr %.slot43, align 4
  %600 = add i64 0, %.state265
  %601 = mul <8 x i64> %599, splat (i64 1538)
  %.splatinsert266 = insertelement <8 x i64> poison, i64 %600, i64 0
  %.splat267 = shufflevector <8 x i64> %.splatinsert266, <8 x i64> poison, <8 x i32> zeroinitializer
  %602 = add <8 x i64> %601, %.splat267
  %.spill.load268 = load i64, ptr %.spill31, align 4
  %.state269 = load i64, ptr %.slot43, align 4
  %603 = add i64 %.spill.load268, %.state269
  %.spill.load270 = load i64, ptr %.spill31, align 4
  %604 = add i64 %.spill.load270, %603
  %.spill.load271 = load i64, ptr %.spill31, align 4
  %605 = add i64 %.spill.load271, %604
  %tile_snapshot.spill.load272 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %606 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %607 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %.splatinsert273 = insertelement <8 x i64> poison, i64 %605, i64 0
  %.splat274 = shufflevector <8 x i64> %.splatinsert273, <8 x i64> poison, <8 x i32> zeroinitializer
  %608 = mul <8 x i64> %.splat274, splat (i64 32)
  %609 = add <8 x i64> %607, %608
  %610 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %606, 0
  %611 = insertvalue { <8 x ptr>, <8 x i64> } %610, <8 x i64> %609, 1
  %612 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %613 = extractvalue { <8 x ptr>, <8 x i64> } %611, 1
  %614 = extractelement <8 x ptr> %612, i32 0
  %615 = extractelement <8 x i64> %613, i32 0
  %616 = sub i64 %615, 0
  %617 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %618 = select i1 %617, i64 %616, i64 0
  %private.contiguous.address275 = getelementptr i8, ptr %614, i64 %618
  %private.contiguous.load276 = load <8 x float>, ptr %private.contiguous.address275, align 4
  %619 = select <8 x i1> %59, <8 x float> %private.contiguous.load276, <8 x float> zeroinitializer
  %.spill.load277 = load <8 x float>, ptr %.spill40, align 32
  %620 = fdiv <8 x float> %619, %.spill.load277
  %tile_snapshot.spill.load278 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load278, 0
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load278, 1
  %.splatinsert279 = insertelement <8 x i64> poison, i64 %604, i64 0
  %.splat280 = shufflevector <8 x i64> %.splatinsert279, <8 x i64> poison, <8 x i32> zeroinitializer
  %623 = mul <8 x i64> %.splat280, splat (i64 32)
  %624 = add <8 x i64> %622, %623
  %625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %621, 0
  %626 = insertvalue { <8 x ptr>, <8 x i64> } %625, <8 x i64> %624, 1
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %628 = extractvalue { <8 x ptr>, <8 x i64> } %626, 1
  %629 = extractelement <8 x ptr> %627, i32 0
  %630 = extractelement <8 x i64> %628, i32 0
  %631 = sub i64 %630, 0
  %632 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %633 = select i1 %632, i64 %631, i64 0
  %private.contiguous.address281 = getelementptr i8, ptr %629, i64 %633
  %private.contiguous.load282 = load <8 x float>, ptr %private.contiguous.address281, align 4
  %634 = select <8 x i1> %59, <8 x float> %private.contiguous.load282, <8 x float> zeroinitializer
  %635 = fmul <8 x float> %620, %634
  %tile_snapshot.spill.load283 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %636 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load283, 0
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load283, 1
  %.splatinsert284 = insertelement <8 x i64> poison, i64 %603, i64 0
  %.splat285 = shufflevector <8 x i64> %.splatinsert284, <8 x i64> poison, <8 x i32> zeroinitializer
  %638 = mul <8 x i64> %.splat285, splat (i64 32)
  %639 = add <8 x i64> %637, %638
  %640 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %636, 0
  %641 = insertvalue { <8 x ptr>, <8 x i64> } %640, <8 x i64> %639, 1
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %641, 1
  %644 = extractelement <8 x ptr> %642, i32 0
  %645 = extractelement <8 x i64> %643, i32 0
  %646 = sub i64 %645, 0
  %647 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %648 = select i1 %647, i64 %646, i64 0
  %private.contiguous.address286 = getelementptr i8, ptr %644, i64 %648
  %private.contiguous.load287 = load <8 x float>, ptr %private.contiguous.address286, align 4
  %649 = select <8 x i1> %59, <8 x float> %private.contiguous.load287, <8 x float> zeroinitializer
  %650 = fadd <8 x float> %635, %649
  %651 = extractvalue { ptr, i64 } %35, 0
  %652 = mul <8 x i64> %602, splat (i64 4)
  %653 = getelementptr i8, ptr %651, <8 x i64> %652
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %650, <8 x ptr> %653, i32 1, <8 x i1> %59)
  %.state288 = load i64, ptr %.slot43, align 4
  %654 = add i64 %.state288, 1
  store i64 %654, ptr %.slot43, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false263
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true73:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false74:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true128:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false129:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true169:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false170:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true233:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false234:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true248:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false249:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true262:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false263:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 49216
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 98432
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 147648
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill13 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill13, align 4
  %.spill14 = alloca i64, align 8
  store i64 0, ptr %.spill14, align 4
  %.spill15 = alloca i64, align 8
  store i64 0, ptr %.spill15, align 4
  %.spill16 = alloca i64, align 8
  store i64 0, ptr %.spill16, align 4
  %.spill17 = alloca i64, align 8
  store i64 0, ptr %.spill17, align 4
  %.spill18 = alloca i64, align 8
  store i64 0, ptr %.spill18, align 4
  %.spill19 = alloca i64, align 8
  store i64 0, ptr %.spill19, align 4
  %.slot20 = alloca i64, align 8
  store i64 0, ptr %.slot20, align 4
  %.slot21 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.slot22 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot22, align 32
  %.slot23 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot23, align 32
  %.slot24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot24, align 32
  %.spill25 = alloca i64, align 8
  store i64 0, ptr %.spill25, align 4
  %.spill26 = alloca i64, align 8
  store i64 0, ptr %.spill26, align 4
  %.spill27 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill27, align 4
  %.spill28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill28, align 32
  %tile_snapshot.spill29 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill29, align 64
  %.slot30 = alloca i64, align 8
  store i64 0, ptr %.slot30, align 4
  %.spill31 = alloca i64, align 8
  store i64 0, ptr %.spill31, align 4
  %.slot32 = alloca i64, align 8
  store i64 0, ptr %.slot32, align 4
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill37, align 32
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.spill40 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill40, align 32
  %tile_snapshot.spill41 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill41, align 64
  %.slot42 = alloca i64, align 8
  store i64 0, ptr %.slot42, align 4
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %12 = getelementptr i8, ptr %argument_buffer, i64 0
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 16
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 32
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 48
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = load i32, ptr %launch_config, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 12
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 4
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 16
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 8
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 20
  %46 = load i32, ptr %45, align 4
  %47 = getelementptr i8, ptr %launch_config, i64 36
  %48 = load i32, ptr %47, align 4
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat45, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %50 = mul i32 %36, 32
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat47, %49
  %52 = mul i32 %40, 1
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat49, zeroinitializer
  %54 = mul i32 %44, 1
  %.splatinsert50 = insertelement <8 x i32> poison, i32 %54, i64 0
  %.splat51 = shufflevector <8 x i32> %.splatinsert50, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = add <8 x i32> %.splat51, zeroinitializer
  %56 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %51, 0
  %57 = insertvalue [3 x <8 x i32>] %56, <8 x i32> %53, 1
  %58 = insertvalue [3 x <8 x i32>] %57, <8 x i32> %55, 2
  %.splatinsert52 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat53 = shufflevector <8 x i32> %.splatinsert52, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat53
  %60 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  br i1 %60, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %61 = extractvalue [3 x <8 x i32>] %58, 0
  %62 = zext <8 x i32> %61 to <8 x i64>
  %63 = select <8 x i1> %59, <8 x i64> %62, <8 x i64> zeroinitializer
  %64 = select <8 x i1> %59, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %65 = sdiv <8 x i64> %63, %64
  %66 = load <8 x i64>, ptr %.spill, align 64
  %67 = select <8 x i1> %59, <8 x i64> %65, <8 x i64> %66
  store <8 x i64> %67, ptr %.spill, align 64
  %68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %68, 0
  %71 = select <8 x i1> %59, <8 x ptr> %69, <8 x ptr> %70
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %68, 1
  %74 = select <8 x i1> %59, <8 x i64> %72, <8 x i64> %73
  %75 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %71, 0
  %76 = insertvalue { <8 x ptr>, <8 x i64> } %75, <8 x i64> %74, 1
  store { <8 x ptr>, <8 x i64> } %76, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %77 = icmp slt i64 %.state, 1538
  br i1 %77, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %78 = add <8 x i64> %.spill.load, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %.state54 = load i64, ptr %.slot, align 4
  %80 = add i64 0, %.state54
  %81 = mul <8 x i64> %79, splat (i64 1538)
  %.splatinsert55 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat56 = shufflevector <8 x i64> %.splatinsert55, <8 x i64> poison, <8 x i32> zeroinitializer
  %82 = add <8 x i64> %81, %.splat56
  %83 = extractvalue { ptr, i64 } %17, 0
  %84 = mul <8 x i64> %82, splat (i64 4)
  %85 = getelementptr i8, ptr %83, <8 x i64> %84
  %86 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %85, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state57 = load i64, ptr %.slot, align 4
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %.state57, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat59, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %59, <8 x float> %86, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state60 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state60, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill13, align 4
  store i64 0, ptr %.spill14, align 4
  store i64 0, ptr %.spill15, align 4
  store i64 0, ptr %.spill16, align 4
  %tile_snapshot.spill.load61 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 1
  %104 = add <8 x i64> %103, zeroinitializer
  %105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %106 = insertvalue { <8 x ptr>, <8 x i64> } %105, <8 x i64> %104, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %106, 1
  %109 = extractelement <8 x ptr> %107, i32 0
  %110 = extractelement <8 x i64> %108, i32 0
  %111 = sub i64 %110, 0
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %113 = select i1 %112, i64 %111, i64 0
  %private.contiguous.address62 = getelementptr i8, ptr %109, i64 %113
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address62, align 4
  %114 = select <8 x i1> %59, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  store i64 1, ptr %.spill17, align 4
  %tile_snapshot.spill.load63 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load63, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load63, 1
  %117 = add <8 x i64> %116, splat (i64 32)
  %118 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %119 = insertvalue { <8 x ptr>, <8 x i64> } %118, <8 x i64> %117, 1
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %119, 1
  %122 = extractelement <8 x ptr> %120, i32 0
  %123 = extractelement <8 x i64> %121, i32 0
  %124 = sub i64 %123, 0
  %125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %126 = select i1 %125, i64 %124, i64 0
  %private.contiguous.address64 = getelementptr i8, ptr %122, i64 %126
  %private.contiguous.load65 = load <8 x float>, ptr %private.contiguous.address64, align 4
  %127 = select <8 x i1> %59, <8 x float> %private.contiguous.load65, <8 x float> zeroinitializer
  store i64 2, ptr %.spill18, align 4
  %tile_snapshot.spill.load66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load66, 0
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load66, 1
  %130 = add <8 x i64> %129, splat (i64 64)
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %128, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %135 = extractelement <8 x ptr> %133, i32 0
  %136 = extractelement <8 x i64> %134, i32 0
  %137 = sub i64 %136, 0
  %138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %139 = select i1 %138, i64 %137, i64 0
  %private.contiguous.address67 = getelementptr i8, ptr %135, i64 %139
  %private.contiguous.load68 = load <8 x float>, ptr %private.contiguous.address67, align 4
  %140 = select <8 x i1> %59, <8 x float> %private.contiguous.load68, <8 x float> zeroinitializer
  store i64 3, ptr %.spill19, align 4
  %tile_snapshot.spill.load69 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 1
  %143 = add <8 x i64> %142, splat (i64 96)
  %144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %141, 0
  %145 = insertvalue { <8 x ptr>, <8 x i64> } %144, <8 x i64> %143, 1
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %148 = extractelement <8 x ptr> %146, i32 0
  %149 = extractelement <8 x i64> %147, i32 0
  %150 = sub i64 %149, 0
  %151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %152 = select i1 %151, i64 %150, i64 0
  %private.contiguous.address70 = getelementptr i8, ptr %148, i64 %152
  %private.contiguous.load71 = load <8 x float>, ptr %private.contiguous.address70, align 4
  %153 = select <8 x i1> %59, <8 x float> %private.contiguous.load71, <8 x float> zeroinitializer
  store i64 4, ptr %.slot20, align 4
  %154 = load <8 x float>, ptr %.slot21, align 32
  %155 = select <8 x i1> %59, <8 x float> %114, <8 x float> %154
  store <8 x float> %155, ptr %.slot21, align 32
  %156 = load <8 x float>, ptr %.slot22, align 32
  %157 = select <8 x i1> %59, <8 x float> %127, <8 x float> %156
  store <8 x float> %157, ptr %.slot22, align 32
  %158 = load <8 x float>, ptr %.slot23, align 32
  %159 = select <8 x i1> %59, <8 x float> %140, <8 x float> %158
  store <8 x float> %159, ptr %.slot23, align 32
  %160 = load <8 x float>, ptr %.slot24, align 32
  %161 = select <8 x i1> %59, <8 x float> %153, <8 x float> %160
  store <8 x float> %161, ptr %.slot24, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state72 = load i64, ptr %.slot20, align 4
  %162 = icmp slt i64 %.state72, 1536
  br i1 %162, label %direct.true73, label %direct.false74

direct.schedule.5:                                ; preds = %direct.true73
  %.state75 = load i64, ptr %.slot20, align 4
  %163 = add i64 %.state75, 0
  %164 = sdiv i64 %163, 1
  %.spill.load76 = load i64, ptr %.spill15, align 4
  %165 = add i64 %.spill.load76, %164
  %tile_snapshot.spill.load77 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load77, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load77, 1
  %.splatinsert78 = insertelement <8 x i64> poison, i64 %165, i64 0
  %.splat79 = shufflevector <8 x i64> %.splatinsert78, <8 x i64> poison, <8 x i32> zeroinitializer
  %168 = mul <8 x i64> %.splat79, splat (i64 32)
  %169 = add <8 x i64> %167, %168
  %170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %171 = insertvalue { <8 x ptr>, <8 x i64> } %170, <8 x i64> %169, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %174 = extractelement <8 x ptr> %172, i32 0
  %175 = extractelement <8 x i64> %173, i32 0
  %176 = sub i64 %175, 0
  %177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %178 = select i1 %177, i64 %176, i64 0
  %private.contiguous.address80 = getelementptr i8, ptr %174, i64 %178
  %private.contiguous.load81 = load <8 x float>, ptr %private.contiguous.address80, align 4
  %179 = select <8 x i1> %59, <8 x float> %private.contiguous.load81, <8 x float> zeroinitializer
  %.state82 = load <8 x float>, ptr %.slot21, align 32
  %180 = fadd <8 x float> %.state82, %179
  %.state83 = load i64, ptr %.slot20, align 4
  %181 = add i64 %.state83, 1
  %182 = sdiv i64 %181, 1
  %.spill.load84 = load i64, ptr %.spill15, align 4
  %183 = add i64 %.spill.load84, %182
  %tile_snapshot.spill.load85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 1
  %.splatinsert86 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat87 = shufflevector <8 x i64> %.splatinsert86, <8 x i64> poison, <8 x i32> zeroinitializer
  %186 = mul <8 x i64> %.splat87, splat (i64 32)
  %187 = add <8 x i64> %185, %186
  %188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %184, 0
  %189 = insertvalue { <8 x ptr>, <8 x i64> } %188, <8 x i64> %187, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %189, 1
  %192 = extractelement <8 x ptr> %190, i32 0
  %193 = extractelement <8 x i64> %191, i32 0
  %194 = sub i64 %193, 0
  %195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %196 = select i1 %195, i64 %194, i64 0
  %private.contiguous.address88 = getelementptr i8, ptr %192, i64 %196
  %private.contiguous.load89 = load <8 x float>, ptr %private.contiguous.address88, align 4
  %197 = select <8 x i1> %59, <8 x float> %private.contiguous.load89, <8 x float> zeroinitializer
  %.state90 = load <8 x float>, ptr %.slot22, align 32
  %198 = fadd <8 x float> %.state90, %197
  %.state91 = load i64, ptr %.slot20, align 4
  %199 = add i64 %.state91, 2
  %200 = sdiv i64 %199, 1
  %.spill.load92 = load i64, ptr %.spill15, align 4
  %201 = add i64 %.spill.load92, %200
  %tile_snapshot.spill.load93 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 1
  %.splatinsert94 = insertelement <8 x i64> poison, i64 %201, i64 0
  %.splat95 = shufflevector <8 x i64> %.splatinsert94, <8 x i64> poison, <8 x i32> zeroinitializer
  %204 = mul <8 x i64> %.splat95, splat (i64 32)
  %205 = add <8 x i64> %203, %204
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %202, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %207, 1
  %210 = extractelement <8 x ptr> %208, i32 0
  %211 = extractelement <8 x i64> %209, i32 0
  %212 = sub i64 %211, 0
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address96 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.load97 = load <8 x float>, ptr %private.contiguous.address96, align 4
  %215 = select <8 x i1> %59, <8 x float> %private.contiguous.load97, <8 x float> zeroinitializer
  %.state98 = load <8 x float>, ptr %.slot23, align 32
  %216 = fadd <8 x float> %.state98, %215
  %.state99 = load i64, ptr %.slot20, align 4
  %217 = add i64 %.state99, 3
  %218 = sdiv i64 %217, 1
  %.spill.load100 = load i64, ptr %.spill15, align 4
  %219 = add i64 %.spill.load100, %218
  %tile_snapshot.spill.load101 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 1
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %219, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %222 = mul <8 x i64> %.splat103, splat (i64 32)
  %223 = add <8 x i64> %221, %222
  %224 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %220, 0
  %225 = insertvalue { <8 x ptr>, <8 x i64> } %224, <8 x i64> %223, 1
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %225, 1
  %228 = extractelement <8 x ptr> %226, i32 0
  %229 = extractelement <8 x i64> %227, i32 0
  %230 = sub i64 %229, 0
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %232 = select i1 %231, i64 %230, i64 0
  %private.contiguous.address104 = getelementptr i8, ptr %228, i64 %232
  %private.contiguous.load105 = load <8 x float>, ptr %private.contiguous.address104, align 4
  %233 = select <8 x i1> %59, <8 x float> %private.contiguous.load105, <8 x float> zeroinitializer
  %.state106 = load <8 x float>, ptr %.slot24, align 32
  %234 = fadd <8 x float> %.state106, %233
  %.state107 = load i64, ptr %.slot20, align 4
  %235 = add i64 %.state107, 4
  store i64 %235, ptr %.slot20, align 4
  %236 = load <8 x float>, ptr %.slot21, align 32
  %237 = select <8 x i1> %59, <8 x float> %180, <8 x float> %236
  store <8 x float> %237, ptr %.slot21, align 32
  %238 = load <8 x float>, ptr %.slot22, align 32
  %239 = select <8 x i1> %59, <8 x float> %198, <8 x float> %238
  store <8 x float> %239, ptr %.slot22, align 32
  %240 = load <8 x float>, ptr %.slot23, align 32
  %241 = select <8 x i1> %59, <8 x float> %216, <8 x float> %240
  store <8 x float> %241, ptr %.slot23, align 32
  %242 = load <8 x float>, ptr %.slot24, align 32
  %243 = select <8 x i1> %59, <8 x float> %234, <8 x float> %242
  store <8 x float> %243, ptr %.slot24, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false74
  %.spill.load108 = load i64, ptr %.spill15, align 4
  %244 = add i64 %.spill.load108, 1536
  store i64 %244, ptr %.spill25, align 4
  %tile_snapshot.spill.load109 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 0
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 1
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %244, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %247 = mul <8 x i64> %.splat111, splat (i64 32)
  %248 = add <8 x i64> %246, %247
  %249 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %245, 0
  %250 = insertvalue { <8 x ptr>, <8 x i64> } %249, <8 x i64> %248, 1
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %250, 1
  %253 = extractelement <8 x ptr> %251, i32 0
  %254 = extractelement <8 x i64> %252, i32 0
  %255 = sub i64 %254, 0
  %256 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %257 = select i1 %256, i64 %255, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %253, i64 %257
  %private.contiguous.load113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %258 = select <8 x i1> %59, <8 x float> %private.contiguous.load113, <8 x float> zeroinitializer
  %.state114 = load <8 x float>, ptr %.slot21, align 32
  %259 = fadd <8 x float> %.state114, %258
  %.spill.load115 = load i64, ptr %.spill15, align 4
  %260 = add i64 %.spill.load115, 1537
  store i64 %260, ptr %.spill26, align 4
  %tile_snapshot.spill.load116 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 1
  %.splatinsert117 = insertelement <8 x i64> poison, i64 %260, i64 0
  %.splat118 = shufflevector <8 x i64> %.splatinsert117, <8 x i64> poison, <8 x i32> zeroinitializer
  %263 = mul <8 x i64> %.splat118, splat (i64 32)
  %264 = add <8 x i64> %262, %263
  %265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %266 = insertvalue { <8 x ptr>, <8 x i64> } %265, <8 x i64> %264, 1
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %266, 1
  %269 = extractelement <8 x ptr> %267, i32 0
  %270 = extractelement <8 x i64> %268, i32 0
  %271 = sub i64 %270, 0
  %272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %273 = select i1 %272, i64 %271, i64 0
  %private.contiguous.address119 = getelementptr i8, ptr %269, i64 %273
  %private.contiguous.load120 = load <8 x float>, ptr %private.contiguous.address119, align 4
  %274 = select <8 x i1> %59, <8 x float> %private.contiguous.load120, <8 x float> zeroinitializer
  %.state121 = load <8 x float>, ptr %.slot22, align 32
  %275 = fadd <8 x float> %.state121, %274
  %.spill.load122 = load float, ptr %.spill13, align 4
  %.splatinsert123 = insertelement <8 x float> poison, float %.spill.load122, i64 0
  %.splat124 = shufflevector <8 x float> %.splatinsert123, <8 x float> poison, <8 x i32> zeroinitializer
  %276 = fadd <8 x float> %.splat124, %259
  %277 = fadd <8 x float> %276, %275
  %.state125 = load <8 x float>, ptr %.slot23, align 32
  %278 = fadd <8 x float> %277, %.state125
  %.state126 = load <8 x float>, ptr %.slot24, align 32
  %279 = fadd <8 x float> %278, %.state126
  store float 1.538000e+03, ptr %.spill27, align 4
  %280 = fdiv <8 x float> %279, splat (float 1.538000e+03)
  %281 = load <8 x float>, ptr %.spill28, align 32
  %282 = select <8 x i1> %59, <8 x float> %280, <8 x float> %281
  store <8 x float> %282, ptr %.spill28, align 32
  %283 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %283, 0
  %286 = select <8 x i1> %59, <8 x ptr> %284, <8 x ptr> %285
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %283, 1
  %289 = select <8 x i1> %59, <8 x i64> %287, <8 x i64> %288
  %290 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %286, 0
  %291 = insertvalue { <8 x ptr>, <8 x i64> } %290, <8 x i64> %289, 1
  store { <8 x ptr>, <8 x i64> } %291, ptr %tile_snapshot.spill29, align 64
  store i64 0, ptr %.slot30, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state127 = load i64, ptr %.slot30, align 4
  %292 = icmp slt i64 %.state127, 1538
  br i1 %292, label %direct.true128, label %direct.false129

direct.schedule.8:                                ; preds = %direct.true128
  %.state130 = load i64, ptr %.slot30, align 4
  %293 = add i64 0, %.state130
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %293, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %296 = mul <8 x i64> %.splat133, splat (i64 32)
  %297 = add <8 x i64> %295, %296
  %298 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %294, 0
  %299 = insertvalue { <8 x ptr>, <8 x i64> } %298, <8 x i64> %297, 1
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %299, 1
  %302 = extractelement <8 x ptr> %300, i32 0
  %303 = extractelement <8 x i64> %301, i32 0
  %304 = sub i64 %303, 0
  %305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %306 = select i1 %305, i64 %304, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %302, i64 %306
  %private.contiguous.load135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %307 = select <8 x i1> %59, <8 x float> %private.contiguous.load135, <8 x float> zeroinitializer
  %.spill.load136 = load <8 x float>, ptr %.spill28, align 32
  %308 = fsub <8 x float> %307, %.spill.load136
  %tile_snapshot.spill.load137 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 1
  %.state138 = load i64, ptr %.slot30, align 4
  %.splatinsert139 = insertelement <8 x i64> poison, i64 %.state138, i64 0
  %.splat140 = shufflevector <8 x i64> %.splatinsert139, <8 x i64> poison, <8 x i32> zeroinitializer
  %311 = mul <8 x i64> %.splat140, splat (i64 32)
  %312 = add <8 x i64> %310, %311
  %313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %309, 0
  %314 = insertvalue { <8 x ptr>, <8 x i64> } %313, <8 x i64> %312, 1
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %314, 1
  %317 = extractelement <8 x ptr> %315, i32 0
  %318 = extractelement <8 x i64> %316, i32 0
  %319 = sub i64 %318, 0
  %320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %321 = select i1 %320, i64 %319, i64 0
  %private.contiguous.address141 = getelementptr i8, ptr %317, i64 %321
  %private.contiguous.preserve142 = load <8 x float>, ptr %private.contiguous.address141, align 4
  %322 = select <8 x i1> %59, <8 x float> %308, <8 x float> %private.contiguous.preserve142
  store <8 x float> %322, ptr %private.contiguous.address141, align 4
  %.state143 = load i64, ptr %.slot30, align 4
  %323 = add i64 %.state143, 1
  store i64 %323, ptr %.slot30, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false129
  store i64 0, ptr %.spill31, align 4
  %.spill.load144 = load i64, ptr %.spill16, align 4
  %324 = add i64 0, %.spill.load144
  %tile_snapshot.spill.load145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load145, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load145, 1
  %.splatinsert146 = insertelement <8 x i64> poison, i64 %324, i64 0
  %.splat147 = shufflevector <8 x i64> %.splatinsert146, <8 x i64> poison, <8 x i32> zeroinitializer
  %327 = mul <8 x i64> %.splat147, splat (i64 32)
  %328 = add <8 x i64> %326, %327
  %329 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %325, 0
  %330 = insertvalue { <8 x ptr>, <8 x i64> } %329, <8 x i64> %328, 1
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %330, 1
  %333 = extractelement <8 x ptr> %331, i32 0
  %334 = extractelement <8 x i64> %332, i32 0
  %335 = sub i64 %334, 0
  %336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %337 = select i1 %336, i64 %335, i64 0
  %private.contiguous.address148 = getelementptr i8, ptr %333, i64 %337
  %private.contiguous.load149 = load <8 x float>, ptr %private.contiguous.address148, align 4
  %338 = select <8 x i1> %59, <8 x float> %private.contiguous.load149, <8 x float> zeroinitializer
  %339 = fmul <8 x float> %338, %338
  %.spill.load150 = load i64, ptr %.spill17, align 4
  %340 = add i64 0, %.spill.load150
  %tile_snapshot.spill.load151 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load151, 0
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load151, 1
  %.splatinsert152 = insertelement <8 x i64> poison, i64 %340, i64 0
  %.splat153 = shufflevector <8 x i64> %.splatinsert152, <8 x i64> poison, <8 x i32> zeroinitializer
  %343 = mul <8 x i64> %.splat153, splat (i64 32)
  %344 = add <8 x i64> %342, %343
  %345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %341, 0
  %346 = insertvalue { <8 x ptr>, <8 x i64> } %345, <8 x i64> %344, 1
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %346, 1
  %349 = extractelement <8 x ptr> %347, i32 0
  %350 = extractelement <8 x i64> %348, i32 0
  %351 = sub i64 %350, 0
  %352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %353 = select i1 %352, i64 %351, i64 0
  %private.contiguous.address154 = getelementptr i8, ptr %349, i64 %353
  %private.contiguous.load155 = load <8 x float>, ptr %private.contiguous.address154, align 4
  %354 = select <8 x i1> %59, <8 x float> %private.contiguous.load155, <8 x float> zeroinitializer
  %355 = fmul <8 x float> %354, %354
  %.spill.load156 = load i64, ptr %.spill18, align 4
  %356 = add i64 0, %.spill.load156
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %.splatinsert158 = insertelement <8 x i64> poison, i64 %356, i64 0
  %.splat159 = shufflevector <8 x i64> %.splatinsert158, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = mul <8 x i64> %.splat159, splat (i64 32)
  %360 = add <8 x i64> %358, %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = extractelement <8 x ptr> %363, i32 0
  %366 = extractelement <8 x i64> %364, i32 0
  %367 = sub i64 %366, 0
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %369 = select i1 %368, i64 %367, i64 0
  %private.contiguous.address160 = getelementptr i8, ptr %365, i64 %369
  %private.contiguous.load161 = load <8 x float>, ptr %private.contiguous.address160, align 4
  %370 = select <8 x i1> %59, <8 x float> %private.contiguous.load161, <8 x float> zeroinitializer
  %371 = fmul <8 x float> %370, %370
  %.spill.load162 = load i64, ptr %.spill19, align 4
  %372 = add i64 0, %.spill.load162
  %tile_snapshot.spill.load163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %.splatinsert164 = insertelement <8 x i64> poison, i64 %372, i64 0
  %.splat165 = shufflevector <8 x i64> %.splatinsert164, <8 x i64> poison, <8 x i32> zeroinitializer
  %375 = mul <8 x i64> %.splat165, splat (i64 32)
  %376 = add <8 x i64> %374, %375
  %377 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %373, 0
  %378 = insertvalue { <8 x ptr>, <8 x i64> } %377, <8 x i64> %376, 1
  %379 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %378, 1
  %381 = extractelement <8 x ptr> %379, i32 0
  %382 = extractelement <8 x i64> %380, i32 0
  %383 = sub i64 %382, 0
  %384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %385 = select i1 %384, i64 %383, i64 0
  %private.contiguous.address166 = getelementptr i8, ptr %381, i64 %385
  %private.contiguous.load167 = load <8 x float>, ptr %private.contiguous.address166, align 4
  %386 = select <8 x i1> %59, <8 x float> %private.contiguous.load167, <8 x float> zeroinitializer
  %387 = fmul <8 x float> %386, %386
  store i64 4, ptr %.slot32, align 4
  %388 = load <8 x float>, ptr %.slot33, align 32
  %389 = select <8 x i1> %59, <8 x float> %339, <8 x float> %388
  store <8 x float> %389, ptr %.slot33, align 32
  %390 = load <8 x float>, ptr %.slot34, align 32
  %391 = select <8 x i1> %59, <8 x float> %355, <8 x float> %390
  store <8 x float> %391, ptr %.slot34, align 32
  %392 = load <8 x float>, ptr %.slot35, align 32
  %393 = select <8 x i1> %59, <8 x float> %371, <8 x float> %392
  store <8 x float> %393, ptr %.slot35, align 32
  %394 = load <8 x float>, ptr %.slot36, align 32
  %395 = select <8 x i1> %59, <8 x float> %387, <8 x float> %394
  store <8 x float> %395, ptr %.slot36, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state168 = load i64, ptr %.slot32, align 4
  %396 = icmp slt i64 %.state168, 1536
  br i1 %396, label %direct.true169, label %direct.false170

direct.schedule.11:                               ; preds = %direct.true169
  %.state171 = load i64, ptr %.slot32, align 4
  %397 = add i64 %.state171, 0
  %398 = sdiv i64 %397, 1
  %.spill.load172 = load i64, ptr %.spill15, align 4
  %399 = add i64 %.spill.load172, %398
  %.spill.load173 = load i64, ptr %.spill31, align 4
  %400 = add i64 %.spill.load173, %399
  %tile_snapshot.spill.load174 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %.splatinsert175 = insertelement <8 x i64> poison, i64 %400, i64 0
  %.splat176 = shufflevector <8 x i64> %.splatinsert175, <8 x i64> poison, <8 x i32> zeroinitializer
  %403 = mul <8 x i64> %.splat176, splat (i64 32)
  %404 = add <8 x i64> %402, %403
  %405 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %401, 0
  %406 = insertvalue { <8 x ptr>, <8 x i64> } %405, <8 x i64> %404, 1
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %406, 1
  %409 = extractelement <8 x ptr> %407, i32 0
  %410 = extractelement <8 x i64> %408, i32 0
  %411 = sub i64 %410, 0
  %412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %413 = select i1 %412, i64 %411, i64 0
  %private.contiguous.address177 = getelementptr i8, ptr %409, i64 %413
  %private.contiguous.load178 = load <8 x float>, ptr %private.contiguous.address177, align 4
  %414 = select <8 x i1> %59, <8 x float> %private.contiguous.load178, <8 x float> zeroinitializer
  %415 = fmul <8 x float> %414, %414
  %.state179 = load <8 x float>, ptr %.slot33, align 32
  %416 = fadd <8 x float> %.state179, %415
  %.state180 = load i64, ptr %.slot32, align 4
  %417 = add i64 %.state180, 1
  %418 = sdiv i64 %417, 1
  %.spill.load181 = load i64, ptr %.spill15, align 4
  %419 = add i64 %.spill.load181, %418
  %.spill.load182 = load i64, ptr %.spill31, align 4
  %420 = add i64 %.spill.load182, %419
  %tile_snapshot.spill.load183 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load183, 0
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load183, 1
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %420, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %423 = mul <8 x i64> %.splat185, splat (i64 32)
  %424 = add <8 x i64> %422, %423
  %425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %421, 0
  %426 = insertvalue { <8 x ptr>, <8 x i64> } %425, <8 x i64> %424, 1
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %426, 1
  %429 = extractelement <8 x ptr> %427, i32 0
  %430 = extractelement <8 x i64> %428, i32 0
  %431 = sub i64 %430, 0
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %433 = select i1 %432, i64 %431, i64 0
  %private.contiguous.address186 = getelementptr i8, ptr %429, i64 %433
  %private.contiguous.load187 = load <8 x float>, ptr %private.contiguous.address186, align 4
  %434 = select <8 x i1> %59, <8 x float> %private.contiguous.load187, <8 x float> zeroinitializer
  %435 = fmul <8 x float> %434, %434
  %.state188 = load <8 x float>, ptr %.slot34, align 32
  %436 = fadd <8 x float> %.state188, %435
  %.state189 = load i64, ptr %.slot32, align 4
  %437 = add i64 %.state189, 2
  %438 = sdiv i64 %437, 1
  %.spill.load190 = load i64, ptr %.spill15, align 4
  %439 = add i64 %.spill.load190, %438
  %.spill.load191 = load i64, ptr %.spill31, align 4
  %440 = add i64 %.spill.load191, %439
  %tile_snapshot.spill.load192 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %.splatinsert193 = insertelement <8 x i64> poison, i64 %440, i64 0
  %.splat194 = shufflevector <8 x i64> %.splatinsert193, <8 x i64> poison, <8 x i32> zeroinitializer
  %443 = mul <8 x i64> %.splat194, splat (i64 32)
  %444 = add <8 x i64> %442, %443
  %445 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %441, 0
  %446 = insertvalue { <8 x ptr>, <8 x i64> } %445, <8 x i64> %444, 1
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %446, 1
  %449 = extractelement <8 x ptr> %447, i32 0
  %450 = extractelement <8 x i64> %448, i32 0
  %451 = sub i64 %450, 0
  %452 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %453 = select i1 %452, i64 %451, i64 0
  %private.contiguous.address195 = getelementptr i8, ptr %449, i64 %453
  %private.contiguous.load196 = load <8 x float>, ptr %private.contiguous.address195, align 4
  %454 = select <8 x i1> %59, <8 x float> %private.contiguous.load196, <8 x float> zeroinitializer
  %455 = fmul <8 x float> %454, %454
  %.state197 = load <8 x float>, ptr %.slot35, align 32
  %456 = fadd <8 x float> %.state197, %455
  %.state198 = load i64, ptr %.slot32, align 4
  %457 = add i64 %.state198, 3
  %458 = sdiv i64 %457, 1
  %.spill.load199 = load i64, ptr %.spill15, align 4
  %459 = add i64 %.spill.load199, %458
  %.spill.load200 = load i64, ptr %.spill31, align 4
  %460 = add i64 %.spill.load200, %459
  %tile_snapshot.spill.load201 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %461 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 0
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 1
  %.splatinsert202 = insertelement <8 x i64> poison, i64 %460, i64 0
  %.splat203 = shufflevector <8 x i64> %.splatinsert202, <8 x i64> poison, <8 x i32> zeroinitializer
  %463 = mul <8 x i64> %.splat203, splat (i64 32)
  %464 = add <8 x i64> %462, %463
  %465 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %461, 0
  %466 = insertvalue { <8 x ptr>, <8 x i64> } %465, <8 x i64> %464, 1
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %466, 1
  %469 = extractelement <8 x ptr> %467, i32 0
  %470 = extractelement <8 x i64> %468, i32 0
  %471 = sub i64 %470, 0
  %472 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %473 = select i1 %472, i64 %471, i64 0
  %private.contiguous.address204 = getelementptr i8, ptr %469, i64 %473
  %private.contiguous.load205 = load <8 x float>, ptr %private.contiguous.address204, align 4
  %474 = select <8 x i1> %59, <8 x float> %private.contiguous.load205, <8 x float> zeroinitializer
  %475 = fmul <8 x float> %474, %474
  %.state206 = load <8 x float>, ptr %.slot36, align 32
  %476 = fadd <8 x float> %.state206, %475
  %.state207 = load i64, ptr %.slot32, align 4
  %477 = add i64 %.state207, 4
  store i64 %477, ptr %.slot32, align 4
  %478 = load <8 x float>, ptr %.slot33, align 32
  %479 = select <8 x i1> %59, <8 x float> %416, <8 x float> %478
  store <8 x float> %479, ptr %.slot33, align 32
  %480 = load <8 x float>, ptr %.slot34, align 32
  %481 = select <8 x i1> %59, <8 x float> %436, <8 x float> %480
  store <8 x float> %481, ptr %.slot34, align 32
  %482 = load <8 x float>, ptr %.slot35, align 32
  %483 = select <8 x i1> %59, <8 x float> %456, <8 x float> %482
  store <8 x float> %483, ptr %.slot35, align 32
  %484 = load <8 x float>, ptr %.slot36, align 32
  %485 = select <8 x i1> %59, <8 x float> %476, <8 x float> %484
  store <8 x float> %485, ptr %.slot36, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false170
  %.spill.load208 = load i64, ptr %.spill31, align 4
  %.spill.load209 = load i64, ptr %.spill25, align 4
  %486 = add i64 %.spill.load208, %.spill.load209
  %tile_snapshot.spill.load210 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %487 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 0
  %488 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 1
  %.splatinsert211 = insertelement <8 x i64> poison, i64 %486, i64 0
  %.splat212 = shufflevector <8 x i64> %.splatinsert211, <8 x i64> poison, <8 x i32> zeroinitializer
  %489 = mul <8 x i64> %.splat212, splat (i64 32)
  %490 = add <8 x i64> %488, %489
  %491 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %487, 0
  %492 = insertvalue { <8 x ptr>, <8 x i64> } %491, <8 x i64> %490, 1
  %493 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %492, 1
  %495 = extractelement <8 x ptr> %493, i32 0
  %496 = extractelement <8 x i64> %494, i32 0
  %497 = sub i64 %496, 0
  %498 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %499 = select i1 %498, i64 %497, i64 0
  %private.contiguous.address213 = getelementptr i8, ptr %495, i64 %499
  %private.contiguous.load214 = load <8 x float>, ptr %private.contiguous.address213, align 4
  %500 = select <8 x i1> %59, <8 x float> %private.contiguous.load214, <8 x float> zeroinitializer
  %501 = fmul <8 x float> %500, %500
  %.state215 = load <8 x float>, ptr %.slot33, align 32
  %502 = fadd <8 x float> %.state215, %501
  %.spill.load216 = load i64, ptr %.spill31, align 4
  %.spill.load217 = load i64, ptr %.spill26, align 4
  %503 = add i64 %.spill.load216, %.spill.load217
  %tile_snapshot.spill.load218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 0
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 1
  %.splatinsert219 = insertelement <8 x i64> poison, i64 %503, i64 0
  %.splat220 = shufflevector <8 x i64> %.splatinsert219, <8 x i64> poison, <8 x i32> zeroinitializer
  %506 = mul <8 x i64> %.splat220, splat (i64 32)
  %507 = add <8 x i64> %505, %506
  %508 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %504, 0
  %509 = insertvalue { <8 x ptr>, <8 x i64> } %508, <8 x i64> %507, 1
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %511 = extractvalue { <8 x ptr>, <8 x i64> } %509, 1
  %512 = extractelement <8 x ptr> %510, i32 0
  %513 = extractelement <8 x i64> %511, i32 0
  %514 = sub i64 %513, 0
  %515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %516 = select i1 %515, i64 %514, i64 0
  %private.contiguous.address221 = getelementptr i8, ptr %512, i64 %516
  %private.contiguous.load222 = load <8 x float>, ptr %private.contiguous.address221, align 4
  %517 = select <8 x i1> %59, <8 x float> %private.contiguous.load222, <8 x float> zeroinitializer
  %518 = fmul <8 x float> %517, %517
  %.state223 = load <8 x float>, ptr %.slot34, align 32
  %519 = fadd <8 x float> %.state223, %518
  %.spill.load224 = load float, ptr %.spill13, align 4
  %.splatinsert225 = insertelement <8 x float> poison, float %.spill.load224, i64 0
  %.splat226 = shufflevector <8 x float> %.splatinsert225, <8 x float> poison, <8 x i32> zeroinitializer
  %520 = fadd <8 x float> %.splat226, %502
  %521 = fadd <8 x float> %520, %519
  %.state227 = load <8 x float>, ptr %.slot35, align 32
  %522 = fadd <8 x float> %521, %.state227
  %.state228 = load <8 x float>, ptr %.slot36, align 32
  %523 = fadd <8 x float> %522, %.state228
  %.spill.load229 = load float, ptr %.spill27, align 4
  %.splatinsert230 = insertelement <8 x float> poison, float %.spill.load229, i64 0
  %.splat231 = shufflevector <8 x float> %.splatinsert230, <8 x float> poison, <8 x i32> zeroinitializer
  %524 = fdiv <8 x float> %523, %.splat231
  %525 = load <8 x float>, ptr %.spill37, align 32
  %526 = select <8 x i1> %59, <8 x float> %524, <8 x float> %525
  store <8 x float> %526, ptr %.spill37, align 32
  %527 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %527, 0
  %530 = select <8 x i1> %59, <8 x ptr> %528, <8 x ptr> %529
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %527, 1
  %533 = select <8 x i1> %59, <8 x i64> %531, <8 x i64> %532
  %534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %530, 0
  %535 = insertvalue { <8 x ptr>, <8 x i64> } %534, <8 x i64> %533, 1
  store { <8 x ptr>, <8 x i64> } %535, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state232 = load i64, ptr %.slot39, align 4
  %536 = icmp slt i64 %.state232, 1538
  br i1 %536, label %direct.true233, label %direct.false234

direct.schedule.14:                               ; preds = %direct.true233
  %.spill.load235 = load i64, ptr %.spill14, align 4
  %537 = add i64 %.spill.load235, 0
  %.state236 = load i64, ptr %.slot39, align 4
  %538 = add i64 0, %.state236
  %539 = mul i64 %537, 1538
  %540 = add i64 %539, %538
  %541 = extractvalue { ptr, i64 } %23, 0
  %542 = mul i64 %540, 4
  %543 = getelementptr i8, ptr %541, i64 %542
  %544 = load float, ptr %543, align 4
  %.splatinsert237 = insertelement <8 x float> poison, float %544, i64 0
  %.splat238 = shufflevector <8 x float> %.splatinsert237, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load239 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 0
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 1
  %.state240 = load i64, ptr %.slot39, align 4
  %.splatinsert241 = insertelement <8 x i64> poison, i64 %.state240, i64 0
  %.splat242 = shufflevector <8 x i64> %.splatinsert241, <8 x i64> poison, <8 x i32> zeroinitializer
  %547 = mul <8 x i64> %.splat242, splat (i64 32)
  %548 = add <8 x i64> %546, %547
  %549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %545, 0
  %550 = insertvalue { <8 x ptr>, <8 x i64> } %549, <8 x i64> %548, 1
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %550, 1
  %553 = extractelement <8 x ptr> %551, i32 0
  %554 = extractelement <8 x i64> %552, i32 0
  %555 = sub i64 %554, 0
  %556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %557 = select i1 %556, i64 %555, i64 0
  %private.contiguous.address243 = getelementptr i8, ptr %553, i64 %557
  %private.contiguous.preserve244 = load <8 x float>, ptr %private.contiguous.address243, align 4
  %558 = select <8 x i1> %59, <8 x float> %.splat238, <8 x float> %private.contiguous.preserve244
  store <8 x float> %558, ptr %private.contiguous.address243, align 4
  %.state245 = load i64, ptr %.slot39, align 4
  %559 = add i64 %.state245, 1
  store i64 %559, ptr %.slot39, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false234
  %.spill.load246 = load <8 x float>, ptr %.spill37, align 32
  %560 = fadd <8 x float> %.spill.load246, splat (float 0x3EE4F8B580000000)
  %561 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %560)
  %562 = load <8 x float>, ptr %.spill40, align 32
  %563 = select <8 x i1> %59, <8 x float> %561, <8 x float> %562
  store <8 x float> %563, ptr %.spill40, align 32
  %564 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %565 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %564, 0
  %567 = select <8 x i1> %59, <8 x ptr> %565, <8 x ptr> %566
  %568 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %564, 1
  %570 = select <8 x i1> %59, <8 x i64> %568, <8 x i64> %569
  %571 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %567, 0
  %572 = insertvalue { <8 x ptr>, <8 x i64> } %571, <8 x i64> %570, 1
  store { <8 x ptr>, <8 x i64> } %572, ptr %tile_snapshot.spill41, align 64
  store i64 0, ptr %.slot42, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state247 = load i64, ptr %.slot42, align 4
  %573 = icmp slt i64 %.state247, 1538
  br i1 %573, label %direct.true248, label %direct.false249

direct.schedule.17:                               ; preds = %direct.true248
  %.spill.load250 = load i64, ptr %.spill14, align 4
  %574 = add i64 %.spill.load250, 0
  %.state251 = load i64, ptr %.slot42, align 4
  %575 = add i64 0, %.state251
  %576 = mul i64 %574, 1538
  %577 = add i64 %576, %575
  %578 = extractvalue { ptr, i64 } %29, 0
  %579 = mul i64 %577, 4
  %580 = getelementptr i8, ptr %578, i64 %579
  %581 = load float, ptr %580, align 4
  %.splatinsert252 = insertelement <8 x float> poison, float %581, i64 0
  %.splat253 = shufflevector <8 x float> %.splatinsert252, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load254 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %.state255 = load i64, ptr %.slot42, align 4
  %.splatinsert256 = insertelement <8 x i64> poison, i64 %.state255, i64 0
  %.splat257 = shufflevector <8 x i64> %.splatinsert256, <8 x i64> poison, <8 x i32> zeroinitializer
  %584 = mul <8 x i64> %.splat257, splat (i64 32)
  %585 = add <8 x i64> %583, %584
  %586 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %582, 0
  %587 = insertvalue { <8 x ptr>, <8 x i64> } %586, <8 x i64> %585, 1
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %587, 1
  %590 = extractelement <8 x ptr> %588, i32 0
  %591 = extractelement <8 x i64> %589, i32 0
  %592 = sub i64 %591, 0
  %593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %594 = select i1 %593, i64 %592, i64 0
  %private.contiguous.address258 = getelementptr i8, ptr %590, i64 %594
  %private.contiguous.preserve259 = load <8 x float>, ptr %private.contiguous.address258, align 4
  %595 = select <8 x i1> %59, <8 x float> %.splat253, <8 x float> %private.contiguous.preserve259
  store <8 x float> %595, ptr %private.contiguous.address258, align 4
  %.state260 = load i64, ptr %.slot42, align 4
  %596 = add i64 %.state260, 1
  store i64 %596, ptr %.slot42, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false249
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state261 = load i64, ptr %.slot43, align 4
  %597 = icmp slt i64 %.state261, 1538
  br i1 %597, label %direct.true262, label %direct.false263

direct.schedule.20:                               ; preds = %direct.true262
  %.spill.load264 = load <8 x i64>, ptr %.spill, align 64
  %598 = add <8 x i64> %.spill.load264, zeroinitializer
  %599 = add <8 x i64> zeroinitializer, %598
  %.state265 = load i64, ptr %.slot43, align 4
  %600 = add i64 0, %.state265
  %601 = mul <8 x i64> %599, splat (i64 1538)
  %.splatinsert266 = insertelement <8 x i64> poison, i64 %600, i64 0
  %.splat267 = shufflevector <8 x i64> %.splatinsert266, <8 x i64> poison, <8 x i32> zeroinitializer
  %602 = add <8 x i64> %601, %.splat267
  %.spill.load268 = load i64, ptr %.spill31, align 4
  %.state269 = load i64, ptr %.slot43, align 4
  %603 = add i64 %.spill.load268, %.state269
  %.spill.load270 = load i64, ptr %.spill31, align 4
  %604 = add i64 %.spill.load270, %603
  %.spill.load271 = load i64, ptr %.spill31, align 4
  %605 = add i64 %.spill.load271, %604
  %tile_snapshot.spill.load272 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %606 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %607 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %.splatinsert273 = insertelement <8 x i64> poison, i64 %605, i64 0
  %.splat274 = shufflevector <8 x i64> %.splatinsert273, <8 x i64> poison, <8 x i32> zeroinitializer
  %608 = mul <8 x i64> %.splat274, splat (i64 32)
  %609 = add <8 x i64> %607, %608
  %610 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %606, 0
  %611 = insertvalue { <8 x ptr>, <8 x i64> } %610, <8 x i64> %609, 1
  %612 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %613 = extractvalue { <8 x ptr>, <8 x i64> } %611, 1
  %614 = extractelement <8 x ptr> %612, i32 0
  %615 = extractelement <8 x i64> %613, i32 0
  %616 = sub i64 %615, 0
  %617 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %618 = select i1 %617, i64 %616, i64 0
  %private.contiguous.address275 = getelementptr i8, ptr %614, i64 %618
  %private.contiguous.load276 = load <8 x float>, ptr %private.contiguous.address275, align 4
  %619 = select <8 x i1> %59, <8 x float> %private.contiguous.load276, <8 x float> zeroinitializer
  %.spill.load277 = load <8 x float>, ptr %.spill40, align 32
  %620 = fdiv <8 x float> %619, %.spill.load277
  %tile_snapshot.spill.load278 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load278, 0
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load278, 1
  %.splatinsert279 = insertelement <8 x i64> poison, i64 %604, i64 0
  %.splat280 = shufflevector <8 x i64> %.splatinsert279, <8 x i64> poison, <8 x i32> zeroinitializer
  %623 = mul <8 x i64> %.splat280, splat (i64 32)
  %624 = add <8 x i64> %622, %623
  %625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %621, 0
  %626 = insertvalue { <8 x ptr>, <8 x i64> } %625, <8 x i64> %624, 1
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %628 = extractvalue { <8 x ptr>, <8 x i64> } %626, 1
  %629 = extractelement <8 x ptr> %627, i32 0
  %630 = extractelement <8 x i64> %628, i32 0
  %631 = sub i64 %630, 0
  %632 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %633 = select i1 %632, i64 %631, i64 0
  %private.contiguous.address281 = getelementptr i8, ptr %629, i64 %633
  %private.contiguous.load282 = load <8 x float>, ptr %private.contiguous.address281, align 4
  %634 = select <8 x i1> %59, <8 x float> %private.contiguous.load282, <8 x float> zeroinitializer
  %635 = fmul <8 x float> %620, %634
  %tile_snapshot.spill.load283 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %636 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load283, 0
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load283, 1
  %.splatinsert284 = insertelement <8 x i64> poison, i64 %603, i64 0
  %.splat285 = shufflevector <8 x i64> %.splatinsert284, <8 x i64> poison, <8 x i32> zeroinitializer
  %638 = mul <8 x i64> %.splat285, splat (i64 32)
  %639 = add <8 x i64> %637, %638
  %640 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %636, 0
  %641 = insertvalue { <8 x ptr>, <8 x i64> } %640, <8 x i64> %639, 1
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %641, 1
  %644 = extractelement <8 x ptr> %642, i32 0
  %645 = extractelement <8 x i64> %643, i32 0
  %646 = sub i64 %645, 0
  %647 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %648 = select i1 %647, i64 %646, i64 0
  %private.contiguous.address286 = getelementptr i8, ptr %644, i64 %648
  %private.contiguous.load287 = load <8 x float>, ptr %private.contiguous.address286, align 4
  %649 = select <8 x i1> %59, <8 x float> %private.contiguous.load287, <8 x float> zeroinitializer
  %650 = fadd <8 x float> %635, %649
  %651 = extractvalue { ptr, i64 } %35, 0
  %652 = mul <8 x i64> %602, splat (i64 4)
  %653 = getelementptr i8, ptr %651, <8 x i64> %652
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %650, <8 x ptr> %653, i32 1, <8 x i1> %59)
  %.state288 = load i64, ptr %.slot43, align 4
  %654 = add i64 %.state288, 1
  store i64 %654, ptr %.slot43, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false263
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true73:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false74:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true128:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false129:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true169:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false170:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true233:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false234:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true248:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false249:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true262:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false263:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 24576
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 49152
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 73728
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill13 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill13, align 4
  %.spill14 = alloca i64, align 8
  store i64 0, ptr %.spill14, align 4
  %.spill15 = alloca i64, align 8
  store i64 0, ptr %.spill15, align 4
  %.spill16 = alloca i64, align 8
  store i64 0, ptr %.spill16, align 4
  %.spill17 = alloca i64, align 8
  store i64 0, ptr %.spill17, align 4
  %.spill18 = alloca i64, align 8
  store i64 0, ptr %.spill18, align 4
  %.spill19 = alloca i64, align 8
  store i64 0, ptr %.spill19, align 4
  %.slot20 = alloca i64, align 8
  store i64 0, ptr %.slot20, align 4
  %.slot21 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.slot22 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot22, align 32
  %.slot23 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot23, align 32
  %.slot24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot24, align 32
  %.spill25 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill25, align 4
  %.spill26 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill26, align 32
  %tile_snapshot.spill27 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill27, align 64
  %.slot28 = alloca i64, align 8
  store i64 0, ptr %.slot28, align 4
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.slot30 = alloca i64, align 8
  store i64 0, ptr %.slot30, align 4
  %.slot31 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot31, align 32
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.spill35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill35, align 32
  %tile_snapshot.spill36 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill36, align 64
  %.slot37 = alloca i64, align 8
  store i64 0, ptr %.slot37, align 4
  %.spill38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill38, align 32
  %tile_snapshot.spill39 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill39, align 64
  %.slot40 = alloca i64, align 8
  store i64 0, ptr %.slot40, align 4
  %.slot41 = alloca i64, align 8
  store i64 0, ptr %.slot41, align 4
  %12 = getelementptr i8, ptr %argument_buffer, i64 0
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 16
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 32
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 48
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = load i32, ptr %launch_config, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 12
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 4
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 16
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 8
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 20
  %46 = load i32, ptr %45, align 4
  %47 = getelementptr i8, ptr %launch_config, i64 36
  %48 = load i32, ptr %47, align 4
  %.splatinsert42 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat43 = shufflevector <8 x i32> %.splatinsert42, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat43, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %50 = mul i32 %36, 32
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat45, %49
  %52 = mul i32 %40, 1
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat47, zeroinitializer
  %54 = mul i32 %44, 1
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %54, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = add <8 x i32> %.splat49, zeroinitializer
  %56 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %51, 0
  %57 = insertvalue [3 x <8 x i32>] %56, <8 x i32> %53, 1
  %58 = insertvalue [3 x <8 x i32>] %57, <8 x i32> %55, 2
  %.splatinsert50 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat51 = shufflevector <8 x i32> %.splatinsert50, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat51
  %60 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  br i1 %60, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %61 = extractvalue [3 x <8 x i32>] %58, 0
  %62 = zext <8 x i32> %61 to <8 x i64>
  %63 = select <8 x i1> %59, <8 x i64> %62, <8 x i64> zeroinitializer
  %64 = select <8 x i1> %59, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %65 = sdiv <8 x i64> %63, %64
  %66 = load <8 x i64>, ptr %.spill, align 64
  %67 = select <8 x i1> %59, <8 x i64> %65, <8 x i64> %66
  store <8 x i64> %67, ptr %.spill, align 64
  %68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %68, 0
  %71 = select <8 x i1> %59, <8 x ptr> %69, <8 x ptr> %70
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %68, 1
  %74 = select <8 x i1> %59, <8 x i64> %72, <8 x i64> %73
  %75 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %71, 0
  %76 = insertvalue { <8 x ptr>, <8 x i64> } %75, <8 x i64> %74, 1
  store { <8 x ptr>, <8 x i64> } %76, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %77 = icmp slt i64 %.state, 768
  br i1 %77, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %78 = add <8 x i64> %.spill.load, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %.state52 = load i64, ptr %.slot, align 4
  %80 = add i64 0, %.state52
  %81 = mul <8 x i64> %79, splat (i64 768)
  %.splatinsert53 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat54 = shufflevector <8 x i64> %.splatinsert53, <8 x i64> poison, <8 x i32> zeroinitializer
  %82 = add <8 x i64> %81, %.splat54
  %83 = extractvalue { ptr, i64 } %17, 0
  %84 = mul <8 x i64> %82, splat (i64 4)
  %85 = getelementptr i8, ptr %83, <8 x i64> %84
  %86 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %85, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state55 = load i64, ptr %.slot, align 4
  %.splatinsert56 = insertelement <8 x i64> poison, i64 %.state55, i64 0
  %.splat57 = shufflevector <8 x i64> %.splatinsert56, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat57, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %59, <8 x float> %86, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state58 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state58, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill13, align 4
  store i64 0, ptr %.spill14, align 4
  store i64 0, ptr %.spill15, align 4
  store i64 0, ptr %.spill16, align 4
  %tile_snapshot.spill.load59 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 1
  %104 = add <8 x i64> %103, zeroinitializer
  %105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %106 = insertvalue { <8 x ptr>, <8 x i64> } %105, <8 x i64> %104, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %106, 1
  %109 = extractelement <8 x ptr> %107, i32 0
  %110 = extractelement <8 x i64> %108, i32 0
  %111 = sub i64 %110, 0
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %113 = select i1 %112, i64 %111, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %109, i64 %113
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address60, align 4
  %114 = select <8 x i1> %59, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  store i64 1, ptr %.spill17, align 4
  %tile_snapshot.spill.load61 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 1
  %117 = add <8 x i64> %116, splat (i64 32)
  %118 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %119 = insertvalue { <8 x ptr>, <8 x i64> } %118, <8 x i64> %117, 1
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %119, 1
  %122 = extractelement <8 x ptr> %120, i32 0
  %123 = extractelement <8 x i64> %121, i32 0
  %124 = sub i64 %123, 0
  %125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %126 = select i1 %125, i64 %124, i64 0
  %private.contiguous.address62 = getelementptr i8, ptr %122, i64 %126
  %private.contiguous.load63 = load <8 x float>, ptr %private.contiguous.address62, align 4
  %127 = select <8 x i1> %59, <8 x float> %private.contiguous.load63, <8 x float> zeroinitializer
  store i64 2, ptr %.spill18, align 4
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %130 = add <8 x i64> %129, splat (i64 64)
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %128, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %135 = extractelement <8 x ptr> %133, i32 0
  %136 = extractelement <8 x i64> %134, i32 0
  %137 = sub i64 %136, 0
  %138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %139 = select i1 %138, i64 %137, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %135, i64 %139
  %private.contiguous.load66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %140 = select <8 x i1> %59, <8 x float> %private.contiguous.load66, <8 x float> zeroinitializer
  store i64 3, ptr %.spill19, align 4
  %tile_snapshot.spill.load67 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 1
  %143 = add <8 x i64> %142, splat (i64 96)
  %144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %141, 0
  %145 = insertvalue { <8 x ptr>, <8 x i64> } %144, <8 x i64> %143, 1
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %148 = extractelement <8 x ptr> %146, i32 0
  %149 = extractelement <8 x i64> %147, i32 0
  %150 = sub i64 %149, 0
  %151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %152 = select i1 %151, i64 %150, i64 0
  %private.contiguous.address68 = getelementptr i8, ptr %148, i64 %152
  %private.contiguous.load69 = load <8 x float>, ptr %private.contiguous.address68, align 4
  %153 = select <8 x i1> %59, <8 x float> %private.contiguous.load69, <8 x float> zeroinitializer
  store i64 4, ptr %.slot20, align 4
  %154 = load <8 x float>, ptr %.slot21, align 32
  %155 = select <8 x i1> %59, <8 x float> %114, <8 x float> %154
  store <8 x float> %155, ptr %.slot21, align 32
  %156 = load <8 x float>, ptr %.slot22, align 32
  %157 = select <8 x i1> %59, <8 x float> %127, <8 x float> %156
  store <8 x float> %157, ptr %.slot22, align 32
  %158 = load <8 x float>, ptr %.slot23, align 32
  %159 = select <8 x i1> %59, <8 x float> %140, <8 x float> %158
  store <8 x float> %159, ptr %.slot23, align 32
  %160 = load <8 x float>, ptr %.slot24, align 32
  %161 = select <8 x i1> %59, <8 x float> %153, <8 x float> %160
  store <8 x float> %161, ptr %.slot24, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state70 = load i64, ptr %.slot20, align 4
  %162 = icmp slt i64 %.state70, 768
  br i1 %162, label %direct.true71, label %direct.false72

direct.schedule.5:                                ; preds = %direct.true71
  %.state73 = load i64, ptr %.slot20, align 4
  %163 = add i64 %.state73, 0
  %164 = sdiv i64 %163, 1
  %.spill.load74 = load i64, ptr %.spill15, align 4
  %165 = add i64 %.spill.load74, %164
  %tile_snapshot.spill.load75 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 1
  %.splatinsert76 = insertelement <8 x i64> poison, i64 %165, i64 0
  %.splat77 = shufflevector <8 x i64> %.splatinsert76, <8 x i64> poison, <8 x i32> zeroinitializer
  %168 = mul <8 x i64> %.splat77, splat (i64 32)
  %169 = add <8 x i64> %167, %168
  %170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %171 = insertvalue { <8 x ptr>, <8 x i64> } %170, <8 x i64> %169, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %174 = extractelement <8 x ptr> %172, i32 0
  %175 = extractelement <8 x i64> %173, i32 0
  %176 = sub i64 %175, 0
  %177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %178 = select i1 %177, i64 %176, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %174, i64 %178
  %private.contiguous.load79 = load <8 x float>, ptr %private.contiguous.address78, align 4
  %179 = select <8 x i1> %59, <8 x float> %private.contiguous.load79, <8 x float> zeroinitializer
  %.state80 = load <8 x float>, ptr %.slot21, align 32
  %180 = fadd <8 x float> %.state80, %179
  %.state81 = load i64, ptr %.slot20, align 4
  %181 = add i64 %.state81, 1
  %182 = sdiv i64 %181, 1
  %.spill.load82 = load i64, ptr %.spill15, align 4
  %183 = add i64 %.spill.load82, %182
  %tile_snapshot.spill.load83 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 1
  %.splatinsert84 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat85 = shufflevector <8 x i64> %.splatinsert84, <8 x i64> poison, <8 x i32> zeroinitializer
  %186 = mul <8 x i64> %.splat85, splat (i64 32)
  %187 = add <8 x i64> %185, %186
  %188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %184, 0
  %189 = insertvalue { <8 x ptr>, <8 x i64> } %188, <8 x i64> %187, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %189, 1
  %192 = extractelement <8 x ptr> %190, i32 0
  %193 = extractelement <8 x i64> %191, i32 0
  %194 = sub i64 %193, 0
  %195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %196 = select i1 %195, i64 %194, i64 0
  %private.contiguous.address86 = getelementptr i8, ptr %192, i64 %196
  %private.contiguous.load87 = load <8 x float>, ptr %private.contiguous.address86, align 4
  %197 = select <8 x i1> %59, <8 x float> %private.contiguous.load87, <8 x float> zeroinitializer
  %.state88 = load <8 x float>, ptr %.slot22, align 32
  %198 = fadd <8 x float> %.state88, %197
  %.state89 = load i64, ptr %.slot20, align 4
  %199 = add i64 %.state89, 2
  %200 = sdiv i64 %199, 1
  %.spill.load90 = load i64, ptr %.spill15, align 4
  %201 = add i64 %.spill.load90, %200
  %tile_snapshot.spill.load91 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load91, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load91, 1
  %.splatinsert92 = insertelement <8 x i64> poison, i64 %201, i64 0
  %.splat93 = shufflevector <8 x i64> %.splatinsert92, <8 x i64> poison, <8 x i32> zeroinitializer
  %204 = mul <8 x i64> %.splat93, splat (i64 32)
  %205 = add <8 x i64> %203, %204
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %202, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %207, 1
  %210 = extractelement <8 x ptr> %208, i32 0
  %211 = extractelement <8 x i64> %209, i32 0
  %212 = sub i64 %211, 0
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address94 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.load95 = load <8 x float>, ptr %private.contiguous.address94, align 4
  %215 = select <8 x i1> %59, <8 x float> %private.contiguous.load95, <8 x float> zeroinitializer
  %.state96 = load <8 x float>, ptr %.slot23, align 32
  %216 = fadd <8 x float> %.state96, %215
  %.state97 = load i64, ptr %.slot20, align 4
  %217 = add i64 %.state97, 3
  %218 = sdiv i64 %217, 1
  %.spill.load98 = load i64, ptr %.spill15, align 4
  %219 = add i64 %.spill.load98, %218
  %tile_snapshot.spill.load99 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 1
  %.splatinsert100 = insertelement <8 x i64> poison, i64 %219, i64 0
  %.splat101 = shufflevector <8 x i64> %.splatinsert100, <8 x i64> poison, <8 x i32> zeroinitializer
  %222 = mul <8 x i64> %.splat101, splat (i64 32)
  %223 = add <8 x i64> %221, %222
  %224 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %220, 0
  %225 = insertvalue { <8 x ptr>, <8 x i64> } %224, <8 x i64> %223, 1
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %225, 1
  %228 = extractelement <8 x ptr> %226, i32 0
  %229 = extractelement <8 x i64> %227, i32 0
  %230 = sub i64 %229, 0
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %232 = select i1 %231, i64 %230, i64 0
  %private.contiguous.address102 = getelementptr i8, ptr %228, i64 %232
  %private.contiguous.load103 = load <8 x float>, ptr %private.contiguous.address102, align 4
  %233 = select <8 x i1> %59, <8 x float> %private.contiguous.load103, <8 x float> zeroinitializer
  %.state104 = load <8 x float>, ptr %.slot24, align 32
  %234 = fadd <8 x float> %.state104, %233
  %.state105 = load i64, ptr %.slot20, align 4
  %235 = add i64 %.state105, 4
  store i64 %235, ptr %.slot20, align 4
  %236 = load <8 x float>, ptr %.slot21, align 32
  %237 = select <8 x i1> %59, <8 x float> %180, <8 x float> %236
  store <8 x float> %237, ptr %.slot21, align 32
  %238 = load <8 x float>, ptr %.slot22, align 32
  %239 = select <8 x i1> %59, <8 x float> %198, <8 x float> %238
  store <8 x float> %239, ptr %.slot22, align 32
  %240 = load <8 x float>, ptr %.slot23, align 32
  %241 = select <8 x i1> %59, <8 x float> %216, <8 x float> %240
  store <8 x float> %241, ptr %.slot23, align 32
  %242 = load <8 x float>, ptr %.slot24, align 32
  %243 = select <8 x i1> %59, <8 x float> %234, <8 x float> %242
  store <8 x float> %243, ptr %.slot24, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false72
  %.spill.load106 = load float, ptr %.spill13, align 4
  %.splatinsert107 = insertelement <8 x float> poison, float %.spill.load106, i64 0
  %.splat108 = shufflevector <8 x float> %.splatinsert107, <8 x float> poison, <8 x i32> zeroinitializer
  %.state109 = load <8 x float>, ptr %.slot21, align 32
  %244 = fadd <8 x float> %.splat108, %.state109
  %.state110 = load <8 x float>, ptr %.slot22, align 32
  %245 = fadd <8 x float> %244, %.state110
  %.state111 = load <8 x float>, ptr %.slot23, align 32
  %246 = fadd <8 x float> %245, %.state111
  %.state112 = load <8 x float>, ptr %.slot24, align 32
  %247 = fadd <8 x float> %246, %.state112
  store float 7.680000e+02, ptr %.spill25, align 4
  %248 = fdiv <8 x float> %247, splat (float 7.680000e+02)
  %249 = load <8 x float>, ptr %.spill26, align 32
  %250 = select <8 x i1> %59, <8 x float> %248, <8 x float> %249
  store <8 x float> %250, ptr %.spill26, align 32
  %251 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %251, 0
  %254 = select <8 x i1> %59, <8 x ptr> %252, <8 x ptr> %253
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %251, 1
  %257 = select <8 x i1> %59, <8 x i64> %255, <8 x i64> %256
  %258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %254, 0
  %259 = insertvalue { <8 x ptr>, <8 x i64> } %258, <8 x i64> %257, 1
  store { <8 x ptr>, <8 x i64> } %259, ptr %tile_snapshot.spill27, align 64
  store i64 0, ptr %.slot28, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state113 = load i64, ptr %.slot28, align 4
  %260 = icmp slt i64 %.state113, 768
  br i1 %260, label %direct.true114, label %direct.false115

direct.schedule.8:                                ; preds = %direct.true114
  %.state116 = load i64, ptr %.slot28, align 4
  %261 = add i64 0, %.state116
  %tile_snapshot.spill.load117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 0
  %263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 1
  %.splatinsert118 = insertelement <8 x i64> poison, i64 %261, i64 0
  %.splat119 = shufflevector <8 x i64> %.splatinsert118, <8 x i64> poison, <8 x i32> zeroinitializer
  %264 = mul <8 x i64> %.splat119, splat (i64 32)
  %265 = add <8 x i64> %263, %264
  %266 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %262, 0
  %267 = insertvalue { <8 x ptr>, <8 x i64> } %266, <8 x i64> %265, 1
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %267, 1
  %270 = extractelement <8 x ptr> %268, i32 0
  %271 = extractelement <8 x i64> %269, i32 0
  %272 = sub i64 %271, 0
  %273 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %274 = select i1 %273, i64 %272, i64 0
  %private.contiguous.address120 = getelementptr i8, ptr %270, i64 %274
  %private.contiguous.load121 = load <8 x float>, ptr %private.contiguous.address120, align 4
  %275 = select <8 x i1> %59, <8 x float> %private.contiguous.load121, <8 x float> zeroinitializer
  %.spill.load122 = load <8 x float>, ptr %.spill26, align 32
  %276 = fsub <8 x float> %275, %.spill.load122
  %tile_snapshot.spill.load123 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 0
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 1
  %.state124 = load i64, ptr %.slot28, align 4
  %.splatinsert125 = insertelement <8 x i64> poison, i64 %.state124, i64 0
  %.splat126 = shufflevector <8 x i64> %.splatinsert125, <8 x i64> poison, <8 x i32> zeroinitializer
  %279 = mul <8 x i64> %.splat126, splat (i64 32)
  %280 = add <8 x i64> %278, %279
  %281 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %277, 0
  %282 = insertvalue { <8 x ptr>, <8 x i64> } %281, <8 x i64> %280, 1
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %282, 1
  %285 = extractelement <8 x ptr> %283, i32 0
  %286 = extractelement <8 x i64> %284, i32 0
  %287 = sub i64 %286, 0
  %288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %289 = select i1 %288, i64 %287, i64 0
  %private.contiguous.address127 = getelementptr i8, ptr %285, i64 %289
  %private.contiguous.preserve128 = load <8 x float>, ptr %private.contiguous.address127, align 4
  %290 = select <8 x i1> %59, <8 x float> %276, <8 x float> %private.contiguous.preserve128
  store <8 x float> %290, ptr %private.contiguous.address127, align 4
  %.state129 = load i64, ptr %.slot28, align 4
  %291 = add i64 %.state129, 1
  store i64 %291, ptr %.slot28, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false115
  store i64 0, ptr %.spill29, align 4
  %.spill.load130 = load i64, ptr %.spill16, align 4
  %292 = add i64 0, %.spill.load130
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %292, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %295 = mul <8 x i64> %.splat133, splat (i64 32)
  %296 = add <8 x i64> %294, %295
  %297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %293, 0
  %298 = insertvalue { <8 x ptr>, <8 x i64> } %297, <8 x i64> %296, 1
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %298, 1
  %301 = extractelement <8 x ptr> %299, i32 0
  %302 = extractelement <8 x i64> %300, i32 0
  %303 = sub i64 %302, 0
  %304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %305 = select i1 %304, i64 %303, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %301, i64 %305
  %private.contiguous.load135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %306 = select <8 x i1> %59, <8 x float> %private.contiguous.load135, <8 x float> zeroinitializer
  %307 = fmul <8 x float> %306, %306
  %.spill.load136 = load i64, ptr %.spill17, align 4
  %308 = add i64 0, %.spill.load136
  %tile_snapshot.spill.load137 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 1
  %.splatinsert138 = insertelement <8 x i64> poison, i64 %308, i64 0
  %.splat139 = shufflevector <8 x i64> %.splatinsert138, <8 x i64> poison, <8 x i32> zeroinitializer
  %311 = mul <8 x i64> %.splat139, splat (i64 32)
  %312 = add <8 x i64> %310, %311
  %313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %309, 0
  %314 = insertvalue { <8 x ptr>, <8 x i64> } %313, <8 x i64> %312, 1
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %314, 1
  %317 = extractelement <8 x ptr> %315, i32 0
  %318 = extractelement <8 x i64> %316, i32 0
  %319 = sub i64 %318, 0
  %320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %321 = select i1 %320, i64 %319, i64 0
  %private.contiguous.address140 = getelementptr i8, ptr %317, i64 %321
  %private.contiguous.load141 = load <8 x float>, ptr %private.contiguous.address140, align 4
  %322 = select <8 x i1> %59, <8 x float> %private.contiguous.load141, <8 x float> zeroinitializer
  %323 = fmul <8 x float> %322, %322
  %.spill.load142 = load i64, ptr %.spill18, align 4
  %324 = add i64 0, %.spill.load142
  %tile_snapshot.spill.load143 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 1
  %.splatinsert144 = insertelement <8 x i64> poison, i64 %324, i64 0
  %.splat145 = shufflevector <8 x i64> %.splatinsert144, <8 x i64> poison, <8 x i32> zeroinitializer
  %327 = mul <8 x i64> %.splat145, splat (i64 32)
  %328 = add <8 x i64> %326, %327
  %329 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %325, 0
  %330 = insertvalue { <8 x ptr>, <8 x i64> } %329, <8 x i64> %328, 1
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %330, 1
  %333 = extractelement <8 x ptr> %331, i32 0
  %334 = extractelement <8 x i64> %332, i32 0
  %335 = sub i64 %334, 0
  %336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %337 = select i1 %336, i64 %335, i64 0
  %private.contiguous.address146 = getelementptr i8, ptr %333, i64 %337
  %private.contiguous.load147 = load <8 x float>, ptr %private.contiguous.address146, align 4
  %338 = select <8 x i1> %59, <8 x float> %private.contiguous.load147, <8 x float> zeroinitializer
  %339 = fmul <8 x float> %338, %338
  %.spill.load148 = load i64, ptr %.spill19, align 4
  %340 = add i64 0, %.spill.load148
  %tile_snapshot.spill.load149 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 0
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 1
  %.splatinsert150 = insertelement <8 x i64> poison, i64 %340, i64 0
  %.splat151 = shufflevector <8 x i64> %.splatinsert150, <8 x i64> poison, <8 x i32> zeroinitializer
  %343 = mul <8 x i64> %.splat151, splat (i64 32)
  %344 = add <8 x i64> %342, %343
  %345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %341, 0
  %346 = insertvalue { <8 x ptr>, <8 x i64> } %345, <8 x i64> %344, 1
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %346, 1
  %349 = extractelement <8 x ptr> %347, i32 0
  %350 = extractelement <8 x i64> %348, i32 0
  %351 = sub i64 %350, 0
  %352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %353 = select i1 %352, i64 %351, i64 0
  %private.contiguous.address152 = getelementptr i8, ptr %349, i64 %353
  %private.contiguous.load153 = load <8 x float>, ptr %private.contiguous.address152, align 4
  %354 = select <8 x i1> %59, <8 x float> %private.contiguous.load153, <8 x float> zeroinitializer
  %355 = fmul <8 x float> %354, %354
  store i64 4, ptr %.slot30, align 4
  %356 = load <8 x float>, ptr %.slot31, align 32
  %357 = select <8 x i1> %59, <8 x float> %307, <8 x float> %356
  store <8 x float> %357, ptr %.slot31, align 32
  %358 = load <8 x float>, ptr %.slot32, align 32
  %359 = select <8 x i1> %59, <8 x float> %323, <8 x float> %358
  store <8 x float> %359, ptr %.slot32, align 32
  %360 = load <8 x float>, ptr %.slot33, align 32
  %361 = select <8 x i1> %59, <8 x float> %339, <8 x float> %360
  store <8 x float> %361, ptr %.slot33, align 32
  %362 = load <8 x float>, ptr %.slot34, align 32
  %363 = select <8 x i1> %59, <8 x float> %355, <8 x float> %362
  store <8 x float> %363, ptr %.slot34, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state154 = load i64, ptr %.slot30, align 4
  %364 = icmp slt i64 %.state154, 768
  br i1 %364, label %direct.true155, label %direct.false156

direct.schedule.11:                               ; preds = %direct.true155
  %.state157 = load i64, ptr %.slot30, align 4
  %365 = add i64 %.state157, 0
  %366 = sdiv i64 %365, 1
  %.spill.load158 = load i64, ptr %.spill15, align 4
  %367 = add i64 %.spill.load158, %366
  %.spill.load159 = load i64, ptr %.spill29, align 4
  %368 = add i64 %.spill.load159, %367
  %tile_snapshot.spill.load160 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load160, 0
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load160, 1
  %.splatinsert161 = insertelement <8 x i64> poison, i64 %368, i64 0
  %.splat162 = shufflevector <8 x i64> %.splatinsert161, <8 x i64> poison, <8 x i32> zeroinitializer
  %371 = mul <8 x i64> %.splat162, splat (i64 32)
  %372 = add <8 x i64> %370, %371
  %373 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %369, 0
  %374 = insertvalue { <8 x ptr>, <8 x i64> } %373, <8 x i64> %372, 1
  %375 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %376 = extractvalue { <8 x ptr>, <8 x i64> } %374, 1
  %377 = extractelement <8 x ptr> %375, i32 0
  %378 = extractelement <8 x i64> %376, i32 0
  %379 = sub i64 %378, 0
  %380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %381 = select i1 %380, i64 %379, i64 0
  %private.contiguous.address163 = getelementptr i8, ptr %377, i64 %381
  %private.contiguous.load164 = load <8 x float>, ptr %private.contiguous.address163, align 4
  %382 = select <8 x i1> %59, <8 x float> %private.contiguous.load164, <8 x float> zeroinitializer
  %383 = fmul <8 x float> %382, %382
  %.state165 = load <8 x float>, ptr %.slot31, align 32
  %384 = fadd <8 x float> %.state165, %383
  %.state166 = load i64, ptr %.slot30, align 4
  %385 = add i64 %.state166, 1
  %386 = sdiv i64 %385, 1
  %.spill.load167 = load i64, ptr %.spill15, align 4
  %387 = add i64 %.spill.load167, %386
  %.spill.load168 = load i64, ptr %.spill29, align 4
  %388 = add i64 %.spill.load168, %387
  %tile_snapshot.spill.load169 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 0
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 1
  %.splatinsert170 = insertelement <8 x i64> poison, i64 %388, i64 0
  %.splat171 = shufflevector <8 x i64> %.splatinsert170, <8 x i64> poison, <8 x i32> zeroinitializer
  %391 = mul <8 x i64> %.splat171, splat (i64 32)
  %392 = add <8 x i64> %390, %391
  %393 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %389, 0
  %394 = insertvalue { <8 x ptr>, <8 x i64> } %393, <8 x i64> %392, 1
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %394, 1
  %397 = extractelement <8 x ptr> %395, i32 0
  %398 = extractelement <8 x i64> %396, i32 0
  %399 = sub i64 %398, 0
  %400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %401 = select i1 %400, i64 %399, i64 0
  %private.contiguous.address172 = getelementptr i8, ptr %397, i64 %401
  %private.contiguous.load173 = load <8 x float>, ptr %private.contiguous.address172, align 4
  %402 = select <8 x i1> %59, <8 x float> %private.contiguous.load173, <8 x float> zeroinitializer
  %403 = fmul <8 x float> %402, %402
  %.state174 = load <8 x float>, ptr %.slot32, align 32
  %404 = fadd <8 x float> %.state174, %403
  %.state175 = load i64, ptr %.slot30, align 4
  %405 = add i64 %.state175, 2
  %406 = sdiv i64 %405, 1
  %.spill.load176 = load i64, ptr %.spill15, align 4
  %407 = add i64 %.spill.load176, %406
  %.spill.load177 = load i64, ptr %.spill29, align 4
  %408 = add i64 %.spill.load177, %407
  %tile_snapshot.spill.load178 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 1
  %.splatinsert179 = insertelement <8 x i64> poison, i64 %408, i64 0
  %.splat180 = shufflevector <8 x i64> %.splatinsert179, <8 x i64> poison, <8 x i32> zeroinitializer
  %411 = mul <8 x i64> %.splat180, splat (i64 32)
  %412 = add <8 x i64> %410, %411
  %413 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %409, 0
  %414 = insertvalue { <8 x ptr>, <8 x i64> } %413, <8 x i64> %412, 1
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %414, 1
  %417 = extractelement <8 x ptr> %415, i32 0
  %418 = extractelement <8 x i64> %416, i32 0
  %419 = sub i64 %418, 0
  %420 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %421 = select i1 %420, i64 %419, i64 0
  %private.contiguous.address181 = getelementptr i8, ptr %417, i64 %421
  %private.contiguous.load182 = load <8 x float>, ptr %private.contiguous.address181, align 4
  %422 = select <8 x i1> %59, <8 x float> %private.contiguous.load182, <8 x float> zeroinitializer
  %423 = fmul <8 x float> %422, %422
  %.state183 = load <8 x float>, ptr %.slot33, align 32
  %424 = fadd <8 x float> %.state183, %423
  %.state184 = load i64, ptr %.slot30, align 4
  %425 = add i64 %.state184, 3
  %426 = sdiv i64 %425, 1
  %.spill.load185 = load i64, ptr %.spill15, align 4
  %427 = add i64 %.spill.load185, %426
  %.spill.load186 = load i64, ptr %.spill29, align 4
  %428 = add i64 %.spill.load186, %427
  %tile_snapshot.spill.load187 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %429 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 0
  %430 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 1
  %.splatinsert188 = insertelement <8 x i64> poison, i64 %428, i64 0
  %.splat189 = shufflevector <8 x i64> %.splatinsert188, <8 x i64> poison, <8 x i32> zeroinitializer
  %431 = mul <8 x i64> %.splat189, splat (i64 32)
  %432 = add <8 x i64> %430, %431
  %433 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %429, 0
  %434 = insertvalue { <8 x ptr>, <8 x i64> } %433, <8 x i64> %432, 1
  %435 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %434, 1
  %437 = extractelement <8 x ptr> %435, i32 0
  %438 = extractelement <8 x i64> %436, i32 0
  %439 = sub i64 %438, 0
  %440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %441 = select i1 %440, i64 %439, i64 0
  %private.contiguous.address190 = getelementptr i8, ptr %437, i64 %441
  %private.contiguous.load191 = load <8 x float>, ptr %private.contiguous.address190, align 4
  %442 = select <8 x i1> %59, <8 x float> %private.contiguous.load191, <8 x float> zeroinitializer
  %443 = fmul <8 x float> %442, %442
  %.state192 = load <8 x float>, ptr %.slot34, align 32
  %444 = fadd <8 x float> %.state192, %443
  %.state193 = load i64, ptr %.slot30, align 4
  %445 = add i64 %.state193, 4
  store i64 %445, ptr %.slot30, align 4
  %446 = load <8 x float>, ptr %.slot31, align 32
  %447 = select <8 x i1> %59, <8 x float> %384, <8 x float> %446
  store <8 x float> %447, ptr %.slot31, align 32
  %448 = load <8 x float>, ptr %.slot32, align 32
  %449 = select <8 x i1> %59, <8 x float> %404, <8 x float> %448
  store <8 x float> %449, ptr %.slot32, align 32
  %450 = load <8 x float>, ptr %.slot33, align 32
  %451 = select <8 x i1> %59, <8 x float> %424, <8 x float> %450
  store <8 x float> %451, ptr %.slot33, align 32
  %452 = load <8 x float>, ptr %.slot34, align 32
  %453 = select <8 x i1> %59, <8 x float> %444, <8 x float> %452
  store <8 x float> %453, ptr %.slot34, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false156
  %.spill.load194 = load float, ptr %.spill13, align 4
  %.splatinsert195 = insertelement <8 x float> poison, float %.spill.load194, i64 0
  %.splat196 = shufflevector <8 x float> %.splatinsert195, <8 x float> poison, <8 x i32> zeroinitializer
  %.state197 = load <8 x float>, ptr %.slot31, align 32
  %454 = fadd <8 x float> %.splat196, %.state197
  %.state198 = load <8 x float>, ptr %.slot32, align 32
  %455 = fadd <8 x float> %454, %.state198
  %.state199 = load <8 x float>, ptr %.slot33, align 32
  %456 = fadd <8 x float> %455, %.state199
  %.state200 = load <8 x float>, ptr %.slot34, align 32
  %457 = fadd <8 x float> %456, %.state200
  %.spill.load201 = load float, ptr %.spill25, align 4
  %.splatinsert202 = insertelement <8 x float> poison, float %.spill.load201, i64 0
  %.splat203 = shufflevector <8 x float> %.splatinsert202, <8 x float> poison, <8 x i32> zeroinitializer
  %458 = fdiv <8 x float> %457, %.splat203
  %459 = load <8 x float>, ptr %.spill35, align 32
  %460 = select <8 x i1> %59, <8 x float> %458, <8 x float> %459
  store <8 x float> %460, ptr %.spill35, align 32
  %461 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill36, align 64
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %461, 0
  %464 = select <8 x i1> %59, <8 x ptr> %462, <8 x ptr> %463
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %466 = extractvalue { <8 x ptr>, <8 x i64> } %461, 1
  %467 = select <8 x i1> %59, <8 x i64> %465, <8 x i64> %466
  %468 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %464, 0
  %469 = insertvalue { <8 x ptr>, <8 x i64> } %468, <8 x i64> %467, 1
  store { <8 x ptr>, <8 x i64> } %469, ptr %tile_snapshot.spill36, align 64
  store i64 0, ptr %.slot37, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state204 = load i64, ptr %.slot37, align 4
  %470 = icmp slt i64 %.state204, 768
  br i1 %470, label %direct.true205, label %direct.false206

direct.schedule.14:                               ; preds = %direct.true205
  %.spill.load207 = load i64, ptr %.spill14, align 4
  %471 = add i64 %.spill.load207, 0
  %.state208 = load i64, ptr %.slot37, align 4
  %472 = add i64 0, %.state208
  %473 = mul i64 %471, 768
  %474 = add i64 %473, %472
  %475 = extractvalue { ptr, i64 } %23, 0
  %476 = mul i64 %474, 4
  %477 = getelementptr i8, ptr %475, i64 %476
  %478 = load float, ptr %477, align 4
  %.splatinsert209 = insertelement <8 x float> poison, float %478, i64 0
  %.splat210 = shufflevector <8 x float> %.splatinsert209, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load211 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill36, align 64
  %479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 0
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 1
  %.state212 = load i64, ptr %.slot37, align 4
  %.splatinsert213 = insertelement <8 x i64> poison, i64 %.state212, i64 0
  %.splat214 = shufflevector <8 x i64> %.splatinsert213, <8 x i64> poison, <8 x i32> zeroinitializer
  %481 = mul <8 x i64> %.splat214, splat (i64 32)
  %482 = add <8 x i64> %480, %481
  %483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %479, 0
  %484 = insertvalue { <8 x ptr>, <8 x i64> } %483, <8 x i64> %482, 1
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %484, 1
  %487 = extractelement <8 x ptr> %485, i32 0
  %488 = extractelement <8 x i64> %486, i32 0
  %489 = sub i64 %488, 0
  %490 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %491 = select i1 %490, i64 %489, i64 0
  %private.contiguous.address215 = getelementptr i8, ptr %487, i64 %491
  %private.contiguous.preserve216 = load <8 x float>, ptr %private.contiguous.address215, align 4
  %492 = select <8 x i1> %59, <8 x float> %.splat210, <8 x float> %private.contiguous.preserve216
  store <8 x float> %492, ptr %private.contiguous.address215, align 4
  %.state217 = load i64, ptr %.slot37, align 4
  %493 = add i64 %.state217, 1
  store i64 %493, ptr %.slot37, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false206
  %.spill.load218 = load <8 x float>, ptr %.spill35, align 32
  %494 = fadd <8 x float> %.spill.load218, splat (float 0x3EE4F8B580000000)
  %495 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %494)
  %496 = load <8 x float>, ptr %.spill38, align 32
  %497 = select <8 x i1> %59, <8 x float> %495, <8 x float> %496
  store <8 x float> %497, ptr %.spill38, align 32
  %498 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %498, 0
  %501 = select <8 x i1> %59, <8 x ptr> %499, <8 x ptr> %500
  %502 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %503 = extractvalue { <8 x ptr>, <8 x i64> } %498, 1
  %504 = select <8 x i1> %59, <8 x i64> %502, <8 x i64> %503
  %505 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %501, 0
  %506 = insertvalue { <8 x ptr>, <8 x i64> } %505, <8 x i64> %504, 1
  store { <8 x ptr>, <8 x i64> } %506, ptr %tile_snapshot.spill39, align 64
  store i64 0, ptr %.slot40, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state219 = load i64, ptr %.slot40, align 4
  %507 = icmp slt i64 %.state219, 768
  br i1 %507, label %direct.true220, label %direct.false221

direct.schedule.17:                               ; preds = %direct.true220
  %.spill.load222 = load i64, ptr %.spill14, align 4
  %508 = add i64 %.spill.load222, 0
  %.state223 = load i64, ptr %.slot40, align 4
  %509 = add i64 0, %.state223
  %510 = mul i64 %508, 768
  %511 = add i64 %510, %509
  %512 = extractvalue { ptr, i64 } %29, 0
  %513 = mul i64 %511, 4
  %514 = getelementptr i8, ptr %512, i64 %513
  %515 = load float, ptr %514, align 4
  %.splatinsert224 = insertelement <8 x float> poison, float %515, i64 0
  %.splat225 = shufflevector <8 x float> %.splatinsert224, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load226 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load226, 0
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load226, 1
  %.state227 = load i64, ptr %.slot40, align 4
  %.splatinsert228 = insertelement <8 x i64> poison, i64 %.state227, i64 0
  %.splat229 = shufflevector <8 x i64> %.splatinsert228, <8 x i64> poison, <8 x i32> zeroinitializer
  %518 = mul <8 x i64> %.splat229, splat (i64 32)
  %519 = add <8 x i64> %517, %518
  %520 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %516, 0
  %521 = insertvalue { <8 x ptr>, <8 x i64> } %520, <8 x i64> %519, 1
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %521, 1
  %524 = extractelement <8 x ptr> %522, i32 0
  %525 = extractelement <8 x i64> %523, i32 0
  %526 = sub i64 %525, 0
  %527 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %528 = select i1 %527, i64 %526, i64 0
  %private.contiguous.address230 = getelementptr i8, ptr %524, i64 %528
  %private.contiguous.preserve231 = load <8 x float>, ptr %private.contiguous.address230, align 4
  %529 = select <8 x i1> %59, <8 x float> %.splat225, <8 x float> %private.contiguous.preserve231
  store <8 x float> %529, ptr %private.contiguous.address230, align 4
  %.state232 = load i64, ptr %.slot40, align 4
  %530 = add i64 %.state232, 1
  store i64 %530, ptr %.slot40, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false221
  store i64 0, ptr %.slot41, align 4
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state233 = load i64, ptr %.slot41, align 4
  %531 = icmp slt i64 %.state233, 768
  br i1 %531, label %direct.true234, label %direct.false235

direct.schedule.20:                               ; preds = %direct.true234
  %.spill.load236 = load <8 x i64>, ptr %.spill, align 64
  %532 = add <8 x i64> %.spill.load236, zeroinitializer
  %533 = add <8 x i64> zeroinitializer, %532
  %.state237 = load i64, ptr %.slot41, align 4
  %534 = add i64 0, %.state237
  %535 = mul <8 x i64> %533, splat (i64 768)
  %.splatinsert238 = insertelement <8 x i64> poison, i64 %534, i64 0
  %.splat239 = shufflevector <8 x i64> %.splatinsert238, <8 x i64> poison, <8 x i32> zeroinitializer
  %536 = add <8 x i64> %535, %.splat239
  %.spill.load240 = load i64, ptr %.spill29, align 4
  %.state241 = load i64, ptr %.slot41, align 4
  %537 = add i64 %.spill.load240, %.state241
  %.spill.load242 = load i64, ptr %.spill29, align 4
  %538 = add i64 %.spill.load242, %537
  %.spill.load243 = load i64, ptr %.spill29, align 4
  %539 = add i64 %.spill.load243, %538
  %tile_snapshot.spill.load244 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %540 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 0
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 1
  %.splatinsert245 = insertelement <8 x i64> poison, i64 %539, i64 0
  %.splat246 = shufflevector <8 x i64> %.splatinsert245, <8 x i64> poison, <8 x i32> zeroinitializer
  %542 = mul <8 x i64> %.splat246, splat (i64 32)
  %543 = add <8 x i64> %541, %542
  %544 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %540, 0
  %545 = insertvalue { <8 x ptr>, <8 x i64> } %544, <8 x i64> %543, 1
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %545, 1
  %548 = extractelement <8 x ptr> %546, i32 0
  %549 = extractelement <8 x i64> %547, i32 0
  %550 = sub i64 %549, 0
  %551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %552 = select i1 %551, i64 %550, i64 0
  %private.contiguous.address247 = getelementptr i8, ptr %548, i64 %552
  %private.contiguous.load248 = load <8 x float>, ptr %private.contiguous.address247, align 4
  %553 = select <8 x i1> %59, <8 x float> %private.contiguous.load248, <8 x float> zeroinitializer
  %.spill.load249 = load <8 x float>, ptr %.spill38, align 32
  %554 = fdiv <8 x float> %553, %.spill.load249
  %tile_snapshot.spill.load250 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill36, align 64
  %555 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 0
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 1
  %.splatinsert251 = insertelement <8 x i64> poison, i64 %538, i64 0
  %.splat252 = shufflevector <8 x i64> %.splatinsert251, <8 x i64> poison, <8 x i32> zeroinitializer
  %557 = mul <8 x i64> %.splat252, splat (i64 32)
  %558 = add <8 x i64> %556, %557
  %559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %555, 0
  %560 = insertvalue { <8 x ptr>, <8 x i64> } %559, <8 x i64> %558, 1
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %562 = extractvalue { <8 x ptr>, <8 x i64> } %560, 1
  %563 = extractelement <8 x ptr> %561, i32 0
  %564 = extractelement <8 x i64> %562, i32 0
  %565 = sub i64 %564, 0
  %566 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %567 = select i1 %566, i64 %565, i64 0
  %private.contiguous.address253 = getelementptr i8, ptr %563, i64 %567
  %private.contiguous.load254 = load <8 x float>, ptr %private.contiguous.address253, align 4
  %568 = select <8 x i1> %59, <8 x float> %private.contiguous.load254, <8 x float> zeroinitializer
  %569 = fmul <8 x float> %554, %568
  %tile_snapshot.spill.load255 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 0
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 1
  %.splatinsert256 = insertelement <8 x i64> poison, i64 %537, i64 0
  %.splat257 = shufflevector <8 x i64> %.splatinsert256, <8 x i64> poison, <8 x i32> zeroinitializer
  %572 = mul <8 x i64> %.splat257, splat (i64 32)
  %573 = add <8 x i64> %571, %572
  %574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %570, 0
  %575 = insertvalue { <8 x ptr>, <8 x i64> } %574, <8 x i64> %573, 1
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %575, 1
  %578 = extractelement <8 x ptr> %576, i32 0
  %579 = extractelement <8 x i64> %577, i32 0
  %580 = sub i64 %579, 0
  %581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %582 = select i1 %581, i64 %580, i64 0
  %private.contiguous.address258 = getelementptr i8, ptr %578, i64 %582
  %private.contiguous.load259 = load <8 x float>, ptr %private.contiguous.address258, align 4
  %583 = select <8 x i1> %59, <8 x float> %private.contiguous.load259, <8 x float> zeroinitializer
  %584 = fadd <8 x float> %569, %583
  %585 = extractvalue { ptr, i64 } %35, 0
  %586 = mul <8 x i64> %536, splat (i64 4)
  %587 = getelementptr i8, ptr %585, <8 x i64> %586
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %584, <8 x ptr> %587, i32 1, <8 x i1> %59)
  %.state260 = load i64, ptr %.slot41, align 4
  %588 = add i64 %.state260, 1
  store i64 %588, ptr %.slot41, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false235
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true71:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false72:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true114:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false115:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true155:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false156:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true205:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false206:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true220:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false221:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true234:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false235:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 24576
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 49152
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 73728
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill13 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill13, align 4
  %.spill14 = alloca i64, align 8
  store i64 0, ptr %.spill14, align 4
  %.spill15 = alloca i64, align 8
  store i64 0, ptr %.spill15, align 4
  %.spill16 = alloca i64, align 8
  store i64 0, ptr %.spill16, align 4
  %.spill17 = alloca i64, align 8
  store i64 0, ptr %.spill17, align 4
  %.spill18 = alloca i64, align 8
  store i64 0, ptr %.spill18, align 4
  %.spill19 = alloca i64, align 8
  store i64 0, ptr %.spill19, align 4
  %.slot20 = alloca i64, align 8
  store i64 0, ptr %.slot20, align 4
  %.slot21 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.slot22 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot22, align 32
  %.slot23 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot23, align 32
  %.slot24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot24, align 32
  %.spill25 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill25, align 4
  %.spill26 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill26, align 32
  %tile_snapshot.spill27 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill27, align 64
  %.slot28 = alloca i64, align 8
  store i64 0, ptr %.slot28, align 4
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.slot30 = alloca i64, align 8
  store i64 0, ptr %.slot30, align 4
  %.slot31 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot31, align 32
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.spill35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill35, align 32
  %tile_snapshot.spill36 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill36, align 64
  %.slot37 = alloca i64, align 8
  store i64 0, ptr %.slot37, align 4
  %.spill38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill38, align 32
  %tile_snapshot.spill39 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill39, align 64
  %.slot40 = alloca i64, align 8
  store i64 0, ptr %.slot40, align 4
  %.slot41 = alloca i64, align 8
  store i64 0, ptr %.slot41, align 4
  %12 = getelementptr i8, ptr %argument_buffer, i64 0
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 16
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 32
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 48
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = load i32, ptr %launch_config, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 12
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 4
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 16
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 8
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 20
  %46 = load i32, ptr %45, align 4
  %47 = getelementptr i8, ptr %launch_config, i64 36
  %48 = load i32, ptr %47, align 4
  %.splatinsert42 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat43 = shufflevector <8 x i32> %.splatinsert42, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat43, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %50 = mul i32 %36, 32
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat45, %49
  %52 = mul i32 %40, 1
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat47, zeroinitializer
  %54 = mul i32 %44, 1
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %54, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = add <8 x i32> %.splat49, zeroinitializer
  %56 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %51, 0
  %57 = insertvalue [3 x <8 x i32>] %56, <8 x i32> %53, 1
  %58 = insertvalue [3 x <8 x i32>] %57, <8 x i32> %55, 2
  %.splatinsert50 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat51 = shufflevector <8 x i32> %.splatinsert50, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat51
  %60 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  br i1 %60, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %61 = extractvalue [3 x <8 x i32>] %58, 0
  %62 = zext <8 x i32> %61 to <8 x i64>
  %63 = select <8 x i1> %59, <8 x i64> %62, <8 x i64> zeroinitializer
  %64 = select <8 x i1> %59, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %65 = sdiv <8 x i64> %63, %64
  %66 = load <8 x i64>, ptr %.spill, align 64
  %67 = select <8 x i1> %59, <8 x i64> %65, <8 x i64> %66
  store <8 x i64> %67, ptr %.spill, align 64
  %68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %68, 0
  %71 = select <8 x i1> %59, <8 x ptr> %69, <8 x ptr> %70
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %68, 1
  %74 = select <8 x i1> %59, <8 x i64> %72, <8 x i64> %73
  %75 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %71, 0
  %76 = insertvalue { <8 x ptr>, <8 x i64> } %75, <8 x i64> %74, 1
  store { <8 x ptr>, <8 x i64> } %76, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %77 = icmp slt i64 %.state, 768
  br i1 %77, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %78 = add <8 x i64> %.spill.load, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %.state52 = load i64, ptr %.slot, align 4
  %80 = add i64 0, %.state52
  %81 = mul <8 x i64> %79, splat (i64 768)
  %.splatinsert53 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat54 = shufflevector <8 x i64> %.splatinsert53, <8 x i64> poison, <8 x i32> zeroinitializer
  %82 = add <8 x i64> %81, %.splat54
  %83 = extractvalue { ptr, i64 } %17, 0
  %84 = mul <8 x i64> %82, splat (i64 4)
  %85 = getelementptr i8, ptr %83, <8 x i64> %84
  %86 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %85, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state55 = load i64, ptr %.slot, align 4
  %.splatinsert56 = insertelement <8 x i64> poison, i64 %.state55, i64 0
  %.splat57 = shufflevector <8 x i64> %.splatinsert56, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat57, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %59, <8 x float> %86, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state58 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state58, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill13, align 4
  store i64 0, ptr %.spill14, align 4
  store i64 0, ptr %.spill15, align 4
  store i64 0, ptr %.spill16, align 4
  %tile_snapshot.spill.load59 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 1
  %104 = add <8 x i64> %103, zeroinitializer
  %105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %106 = insertvalue { <8 x ptr>, <8 x i64> } %105, <8 x i64> %104, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %106, 1
  %109 = extractelement <8 x ptr> %107, i32 0
  %110 = extractelement <8 x i64> %108, i32 0
  %111 = sub i64 %110, 0
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %113 = select i1 %112, i64 %111, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %109, i64 %113
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address60, align 4
  %114 = select <8 x i1> %59, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  store i64 1, ptr %.spill17, align 4
  %tile_snapshot.spill.load61 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 1
  %117 = add <8 x i64> %116, splat (i64 32)
  %118 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %119 = insertvalue { <8 x ptr>, <8 x i64> } %118, <8 x i64> %117, 1
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %119, 1
  %122 = extractelement <8 x ptr> %120, i32 0
  %123 = extractelement <8 x i64> %121, i32 0
  %124 = sub i64 %123, 0
  %125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %126 = select i1 %125, i64 %124, i64 0
  %private.contiguous.address62 = getelementptr i8, ptr %122, i64 %126
  %private.contiguous.load63 = load <8 x float>, ptr %private.contiguous.address62, align 4
  %127 = select <8 x i1> %59, <8 x float> %private.contiguous.load63, <8 x float> zeroinitializer
  store i64 2, ptr %.spill18, align 4
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %130 = add <8 x i64> %129, splat (i64 64)
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %128, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %135 = extractelement <8 x ptr> %133, i32 0
  %136 = extractelement <8 x i64> %134, i32 0
  %137 = sub i64 %136, 0
  %138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %139 = select i1 %138, i64 %137, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %135, i64 %139
  %private.contiguous.load66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %140 = select <8 x i1> %59, <8 x float> %private.contiguous.load66, <8 x float> zeroinitializer
  store i64 3, ptr %.spill19, align 4
  %tile_snapshot.spill.load67 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 1
  %143 = add <8 x i64> %142, splat (i64 96)
  %144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %141, 0
  %145 = insertvalue { <8 x ptr>, <8 x i64> } %144, <8 x i64> %143, 1
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %148 = extractelement <8 x ptr> %146, i32 0
  %149 = extractelement <8 x i64> %147, i32 0
  %150 = sub i64 %149, 0
  %151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %152 = select i1 %151, i64 %150, i64 0
  %private.contiguous.address68 = getelementptr i8, ptr %148, i64 %152
  %private.contiguous.load69 = load <8 x float>, ptr %private.contiguous.address68, align 4
  %153 = select <8 x i1> %59, <8 x float> %private.contiguous.load69, <8 x float> zeroinitializer
  store i64 4, ptr %.slot20, align 4
  %154 = load <8 x float>, ptr %.slot21, align 32
  %155 = select <8 x i1> %59, <8 x float> %114, <8 x float> %154
  store <8 x float> %155, ptr %.slot21, align 32
  %156 = load <8 x float>, ptr %.slot22, align 32
  %157 = select <8 x i1> %59, <8 x float> %127, <8 x float> %156
  store <8 x float> %157, ptr %.slot22, align 32
  %158 = load <8 x float>, ptr %.slot23, align 32
  %159 = select <8 x i1> %59, <8 x float> %140, <8 x float> %158
  store <8 x float> %159, ptr %.slot23, align 32
  %160 = load <8 x float>, ptr %.slot24, align 32
  %161 = select <8 x i1> %59, <8 x float> %153, <8 x float> %160
  store <8 x float> %161, ptr %.slot24, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state70 = load i64, ptr %.slot20, align 4
  %162 = icmp slt i64 %.state70, 768
  br i1 %162, label %direct.true71, label %direct.false72

direct.schedule.5:                                ; preds = %direct.true71
  %.state73 = load i64, ptr %.slot20, align 4
  %163 = add i64 %.state73, 0
  %164 = sdiv i64 %163, 1
  %.spill.load74 = load i64, ptr %.spill15, align 4
  %165 = add i64 %.spill.load74, %164
  %tile_snapshot.spill.load75 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 1
  %.splatinsert76 = insertelement <8 x i64> poison, i64 %165, i64 0
  %.splat77 = shufflevector <8 x i64> %.splatinsert76, <8 x i64> poison, <8 x i32> zeroinitializer
  %168 = mul <8 x i64> %.splat77, splat (i64 32)
  %169 = add <8 x i64> %167, %168
  %170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %171 = insertvalue { <8 x ptr>, <8 x i64> } %170, <8 x i64> %169, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %174 = extractelement <8 x ptr> %172, i32 0
  %175 = extractelement <8 x i64> %173, i32 0
  %176 = sub i64 %175, 0
  %177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %178 = select i1 %177, i64 %176, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %174, i64 %178
  %private.contiguous.load79 = load <8 x float>, ptr %private.contiguous.address78, align 4
  %179 = select <8 x i1> %59, <8 x float> %private.contiguous.load79, <8 x float> zeroinitializer
  %.state80 = load <8 x float>, ptr %.slot21, align 32
  %180 = fadd <8 x float> %.state80, %179
  %.state81 = load i64, ptr %.slot20, align 4
  %181 = add i64 %.state81, 1
  %182 = sdiv i64 %181, 1
  %.spill.load82 = load i64, ptr %.spill15, align 4
  %183 = add i64 %.spill.load82, %182
  %tile_snapshot.spill.load83 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 1
  %.splatinsert84 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat85 = shufflevector <8 x i64> %.splatinsert84, <8 x i64> poison, <8 x i32> zeroinitializer
  %186 = mul <8 x i64> %.splat85, splat (i64 32)
  %187 = add <8 x i64> %185, %186
  %188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %184, 0
  %189 = insertvalue { <8 x ptr>, <8 x i64> } %188, <8 x i64> %187, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %189, 1
  %192 = extractelement <8 x ptr> %190, i32 0
  %193 = extractelement <8 x i64> %191, i32 0
  %194 = sub i64 %193, 0
  %195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %196 = select i1 %195, i64 %194, i64 0
  %private.contiguous.address86 = getelementptr i8, ptr %192, i64 %196
  %private.contiguous.load87 = load <8 x float>, ptr %private.contiguous.address86, align 4
  %197 = select <8 x i1> %59, <8 x float> %private.contiguous.load87, <8 x float> zeroinitializer
  %.state88 = load <8 x float>, ptr %.slot22, align 32
  %198 = fadd <8 x float> %.state88, %197
  %.state89 = load i64, ptr %.slot20, align 4
  %199 = add i64 %.state89, 2
  %200 = sdiv i64 %199, 1
  %.spill.load90 = load i64, ptr %.spill15, align 4
  %201 = add i64 %.spill.load90, %200
  %tile_snapshot.spill.load91 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load91, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load91, 1
  %.splatinsert92 = insertelement <8 x i64> poison, i64 %201, i64 0
  %.splat93 = shufflevector <8 x i64> %.splatinsert92, <8 x i64> poison, <8 x i32> zeroinitializer
  %204 = mul <8 x i64> %.splat93, splat (i64 32)
  %205 = add <8 x i64> %203, %204
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %202, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %207, 1
  %210 = extractelement <8 x ptr> %208, i32 0
  %211 = extractelement <8 x i64> %209, i32 0
  %212 = sub i64 %211, 0
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address94 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.load95 = load <8 x float>, ptr %private.contiguous.address94, align 4
  %215 = select <8 x i1> %59, <8 x float> %private.contiguous.load95, <8 x float> zeroinitializer
  %.state96 = load <8 x float>, ptr %.slot23, align 32
  %216 = fadd <8 x float> %.state96, %215
  %.state97 = load i64, ptr %.slot20, align 4
  %217 = add i64 %.state97, 3
  %218 = sdiv i64 %217, 1
  %.spill.load98 = load i64, ptr %.spill15, align 4
  %219 = add i64 %.spill.load98, %218
  %tile_snapshot.spill.load99 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 1
  %.splatinsert100 = insertelement <8 x i64> poison, i64 %219, i64 0
  %.splat101 = shufflevector <8 x i64> %.splatinsert100, <8 x i64> poison, <8 x i32> zeroinitializer
  %222 = mul <8 x i64> %.splat101, splat (i64 32)
  %223 = add <8 x i64> %221, %222
  %224 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %220, 0
  %225 = insertvalue { <8 x ptr>, <8 x i64> } %224, <8 x i64> %223, 1
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %225, 1
  %228 = extractelement <8 x ptr> %226, i32 0
  %229 = extractelement <8 x i64> %227, i32 0
  %230 = sub i64 %229, 0
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %232 = select i1 %231, i64 %230, i64 0
  %private.contiguous.address102 = getelementptr i8, ptr %228, i64 %232
  %private.contiguous.load103 = load <8 x float>, ptr %private.contiguous.address102, align 4
  %233 = select <8 x i1> %59, <8 x float> %private.contiguous.load103, <8 x float> zeroinitializer
  %.state104 = load <8 x float>, ptr %.slot24, align 32
  %234 = fadd <8 x float> %.state104, %233
  %.state105 = load i64, ptr %.slot20, align 4
  %235 = add i64 %.state105, 4
  store i64 %235, ptr %.slot20, align 4
  %236 = load <8 x float>, ptr %.slot21, align 32
  %237 = select <8 x i1> %59, <8 x float> %180, <8 x float> %236
  store <8 x float> %237, ptr %.slot21, align 32
  %238 = load <8 x float>, ptr %.slot22, align 32
  %239 = select <8 x i1> %59, <8 x float> %198, <8 x float> %238
  store <8 x float> %239, ptr %.slot22, align 32
  %240 = load <8 x float>, ptr %.slot23, align 32
  %241 = select <8 x i1> %59, <8 x float> %216, <8 x float> %240
  store <8 x float> %241, ptr %.slot23, align 32
  %242 = load <8 x float>, ptr %.slot24, align 32
  %243 = select <8 x i1> %59, <8 x float> %234, <8 x float> %242
  store <8 x float> %243, ptr %.slot24, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false72
  %.spill.load106 = load float, ptr %.spill13, align 4
  %.splatinsert107 = insertelement <8 x float> poison, float %.spill.load106, i64 0
  %.splat108 = shufflevector <8 x float> %.splatinsert107, <8 x float> poison, <8 x i32> zeroinitializer
  %.state109 = load <8 x float>, ptr %.slot21, align 32
  %244 = fadd <8 x float> %.splat108, %.state109
  %.state110 = load <8 x float>, ptr %.slot22, align 32
  %245 = fadd <8 x float> %244, %.state110
  %.state111 = load <8 x float>, ptr %.slot23, align 32
  %246 = fadd <8 x float> %245, %.state111
  %.state112 = load <8 x float>, ptr %.slot24, align 32
  %247 = fadd <8 x float> %246, %.state112
  store float 7.680000e+02, ptr %.spill25, align 4
  %248 = fdiv <8 x float> %247, splat (float 7.680000e+02)
  %249 = load <8 x float>, ptr %.spill26, align 32
  %250 = select <8 x i1> %59, <8 x float> %248, <8 x float> %249
  store <8 x float> %250, ptr %.spill26, align 32
  %251 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %251, 0
  %254 = select <8 x i1> %59, <8 x ptr> %252, <8 x ptr> %253
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %251, 1
  %257 = select <8 x i1> %59, <8 x i64> %255, <8 x i64> %256
  %258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %254, 0
  %259 = insertvalue { <8 x ptr>, <8 x i64> } %258, <8 x i64> %257, 1
  store { <8 x ptr>, <8 x i64> } %259, ptr %tile_snapshot.spill27, align 64
  store i64 0, ptr %.slot28, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state113 = load i64, ptr %.slot28, align 4
  %260 = icmp slt i64 %.state113, 768
  br i1 %260, label %direct.true114, label %direct.false115

direct.schedule.8:                                ; preds = %direct.true114
  %.state116 = load i64, ptr %.slot28, align 4
  %261 = add i64 0, %.state116
  %tile_snapshot.spill.load117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 0
  %263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 1
  %.splatinsert118 = insertelement <8 x i64> poison, i64 %261, i64 0
  %.splat119 = shufflevector <8 x i64> %.splatinsert118, <8 x i64> poison, <8 x i32> zeroinitializer
  %264 = mul <8 x i64> %.splat119, splat (i64 32)
  %265 = add <8 x i64> %263, %264
  %266 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %262, 0
  %267 = insertvalue { <8 x ptr>, <8 x i64> } %266, <8 x i64> %265, 1
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %267, 1
  %270 = extractelement <8 x ptr> %268, i32 0
  %271 = extractelement <8 x i64> %269, i32 0
  %272 = sub i64 %271, 0
  %273 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %274 = select i1 %273, i64 %272, i64 0
  %private.contiguous.address120 = getelementptr i8, ptr %270, i64 %274
  %private.contiguous.load121 = load <8 x float>, ptr %private.contiguous.address120, align 4
  %275 = select <8 x i1> %59, <8 x float> %private.contiguous.load121, <8 x float> zeroinitializer
  %.spill.load122 = load <8 x float>, ptr %.spill26, align 32
  %276 = fsub <8 x float> %275, %.spill.load122
  %tile_snapshot.spill.load123 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 0
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 1
  %.state124 = load i64, ptr %.slot28, align 4
  %.splatinsert125 = insertelement <8 x i64> poison, i64 %.state124, i64 0
  %.splat126 = shufflevector <8 x i64> %.splatinsert125, <8 x i64> poison, <8 x i32> zeroinitializer
  %279 = mul <8 x i64> %.splat126, splat (i64 32)
  %280 = add <8 x i64> %278, %279
  %281 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %277, 0
  %282 = insertvalue { <8 x ptr>, <8 x i64> } %281, <8 x i64> %280, 1
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %282, 1
  %285 = extractelement <8 x ptr> %283, i32 0
  %286 = extractelement <8 x i64> %284, i32 0
  %287 = sub i64 %286, 0
  %288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %289 = select i1 %288, i64 %287, i64 0
  %private.contiguous.address127 = getelementptr i8, ptr %285, i64 %289
  %private.contiguous.preserve128 = load <8 x float>, ptr %private.contiguous.address127, align 4
  %290 = select <8 x i1> %59, <8 x float> %276, <8 x float> %private.contiguous.preserve128
  store <8 x float> %290, ptr %private.contiguous.address127, align 4
  %.state129 = load i64, ptr %.slot28, align 4
  %291 = add i64 %.state129, 1
  store i64 %291, ptr %.slot28, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false115
  store i64 0, ptr %.spill29, align 4
  %.spill.load130 = load i64, ptr %.spill16, align 4
  %292 = add i64 0, %.spill.load130
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %292, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %295 = mul <8 x i64> %.splat133, splat (i64 32)
  %296 = add <8 x i64> %294, %295
  %297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %293, 0
  %298 = insertvalue { <8 x ptr>, <8 x i64> } %297, <8 x i64> %296, 1
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %298, 1
  %301 = extractelement <8 x ptr> %299, i32 0
  %302 = extractelement <8 x i64> %300, i32 0
  %303 = sub i64 %302, 0
  %304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %305 = select i1 %304, i64 %303, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %301, i64 %305
  %private.contiguous.load135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %306 = select <8 x i1> %59, <8 x float> %private.contiguous.load135, <8 x float> zeroinitializer
  %307 = fmul <8 x float> %306, %306
  %.spill.load136 = load i64, ptr %.spill17, align 4
  %308 = add i64 0, %.spill.load136
  %tile_snapshot.spill.load137 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 1
  %.splatinsert138 = insertelement <8 x i64> poison, i64 %308, i64 0
  %.splat139 = shufflevector <8 x i64> %.splatinsert138, <8 x i64> poison, <8 x i32> zeroinitializer
  %311 = mul <8 x i64> %.splat139, splat (i64 32)
  %312 = add <8 x i64> %310, %311
  %313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %309, 0
  %314 = insertvalue { <8 x ptr>, <8 x i64> } %313, <8 x i64> %312, 1
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %314, 1
  %317 = extractelement <8 x ptr> %315, i32 0
  %318 = extractelement <8 x i64> %316, i32 0
  %319 = sub i64 %318, 0
  %320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %321 = select i1 %320, i64 %319, i64 0
  %private.contiguous.address140 = getelementptr i8, ptr %317, i64 %321
  %private.contiguous.load141 = load <8 x float>, ptr %private.contiguous.address140, align 4
  %322 = select <8 x i1> %59, <8 x float> %private.contiguous.load141, <8 x float> zeroinitializer
  %323 = fmul <8 x float> %322, %322
  %.spill.load142 = load i64, ptr %.spill18, align 4
  %324 = add i64 0, %.spill.load142
  %tile_snapshot.spill.load143 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 1
  %.splatinsert144 = insertelement <8 x i64> poison, i64 %324, i64 0
  %.splat145 = shufflevector <8 x i64> %.splatinsert144, <8 x i64> poison, <8 x i32> zeroinitializer
  %327 = mul <8 x i64> %.splat145, splat (i64 32)
  %328 = add <8 x i64> %326, %327
  %329 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %325, 0
  %330 = insertvalue { <8 x ptr>, <8 x i64> } %329, <8 x i64> %328, 1
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %330, 1
  %333 = extractelement <8 x ptr> %331, i32 0
  %334 = extractelement <8 x i64> %332, i32 0
  %335 = sub i64 %334, 0
  %336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %337 = select i1 %336, i64 %335, i64 0
  %private.contiguous.address146 = getelementptr i8, ptr %333, i64 %337
  %private.contiguous.load147 = load <8 x float>, ptr %private.contiguous.address146, align 4
  %338 = select <8 x i1> %59, <8 x float> %private.contiguous.load147, <8 x float> zeroinitializer
  %339 = fmul <8 x float> %338, %338
  %.spill.load148 = load i64, ptr %.spill19, align 4
  %340 = add i64 0, %.spill.load148
  %tile_snapshot.spill.load149 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 0
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 1
  %.splatinsert150 = insertelement <8 x i64> poison, i64 %340, i64 0
  %.splat151 = shufflevector <8 x i64> %.splatinsert150, <8 x i64> poison, <8 x i32> zeroinitializer
  %343 = mul <8 x i64> %.splat151, splat (i64 32)
  %344 = add <8 x i64> %342, %343
  %345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %341, 0
  %346 = insertvalue { <8 x ptr>, <8 x i64> } %345, <8 x i64> %344, 1
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %346, 1
  %349 = extractelement <8 x ptr> %347, i32 0
  %350 = extractelement <8 x i64> %348, i32 0
  %351 = sub i64 %350, 0
  %352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %353 = select i1 %352, i64 %351, i64 0
  %private.contiguous.address152 = getelementptr i8, ptr %349, i64 %353
  %private.contiguous.load153 = load <8 x float>, ptr %private.contiguous.address152, align 4
  %354 = select <8 x i1> %59, <8 x float> %private.contiguous.load153, <8 x float> zeroinitializer
  %355 = fmul <8 x float> %354, %354
  store i64 4, ptr %.slot30, align 4
  %356 = load <8 x float>, ptr %.slot31, align 32
  %357 = select <8 x i1> %59, <8 x float> %307, <8 x float> %356
  store <8 x float> %357, ptr %.slot31, align 32
  %358 = load <8 x float>, ptr %.slot32, align 32
  %359 = select <8 x i1> %59, <8 x float> %323, <8 x float> %358
  store <8 x float> %359, ptr %.slot32, align 32
  %360 = load <8 x float>, ptr %.slot33, align 32
  %361 = select <8 x i1> %59, <8 x float> %339, <8 x float> %360
  store <8 x float> %361, ptr %.slot33, align 32
  %362 = load <8 x float>, ptr %.slot34, align 32
  %363 = select <8 x i1> %59, <8 x float> %355, <8 x float> %362
  store <8 x float> %363, ptr %.slot34, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state154 = load i64, ptr %.slot30, align 4
  %364 = icmp slt i64 %.state154, 768
  br i1 %364, label %direct.true155, label %direct.false156

direct.schedule.11:                               ; preds = %direct.true155
  %.state157 = load i64, ptr %.slot30, align 4
  %365 = add i64 %.state157, 0
  %366 = sdiv i64 %365, 1
  %.spill.load158 = load i64, ptr %.spill15, align 4
  %367 = add i64 %.spill.load158, %366
  %.spill.load159 = load i64, ptr %.spill29, align 4
  %368 = add i64 %.spill.load159, %367
  %tile_snapshot.spill.load160 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load160, 0
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load160, 1
  %.splatinsert161 = insertelement <8 x i64> poison, i64 %368, i64 0
  %.splat162 = shufflevector <8 x i64> %.splatinsert161, <8 x i64> poison, <8 x i32> zeroinitializer
  %371 = mul <8 x i64> %.splat162, splat (i64 32)
  %372 = add <8 x i64> %370, %371
  %373 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %369, 0
  %374 = insertvalue { <8 x ptr>, <8 x i64> } %373, <8 x i64> %372, 1
  %375 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %376 = extractvalue { <8 x ptr>, <8 x i64> } %374, 1
  %377 = extractelement <8 x ptr> %375, i32 0
  %378 = extractelement <8 x i64> %376, i32 0
  %379 = sub i64 %378, 0
  %380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %381 = select i1 %380, i64 %379, i64 0
  %private.contiguous.address163 = getelementptr i8, ptr %377, i64 %381
  %private.contiguous.load164 = load <8 x float>, ptr %private.contiguous.address163, align 4
  %382 = select <8 x i1> %59, <8 x float> %private.contiguous.load164, <8 x float> zeroinitializer
  %383 = fmul <8 x float> %382, %382
  %.state165 = load <8 x float>, ptr %.slot31, align 32
  %384 = fadd <8 x float> %.state165, %383
  %.state166 = load i64, ptr %.slot30, align 4
  %385 = add i64 %.state166, 1
  %386 = sdiv i64 %385, 1
  %.spill.load167 = load i64, ptr %.spill15, align 4
  %387 = add i64 %.spill.load167, %386
  %.spill.load168 = load i64, ptr %.spill29, align 4
  %388 = add i64 %.spill.load168, %387
  %tile_snapshot.spill.load169 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 0
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 1
  %.splatinsert170 = insertelement <8 x i64> poison, i64 %388, i64 0
  %.splat171 = shufflevector <8 x i64> %.splatinsert170, <8 x i64> poison, <8 x i32> zeroinitializer
  %391 = mul <8 x i64> %.splat171, splat (i64 32)
  %392 = add <8 x i64> %390, %391
  %393 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %389, 0
  %394 = insertvalue { <8 x ptr>, <8 x i64> } %393, <8 x i64> %392, 1
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %394, 1
  %397 = extractelement <8 x ptr> %395, i32 0
  %398 = extractelement <8 x i64> %396, i32 0
  %399 = sub i64 %398, 0
  %400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %401 = select i1 %400, i64 %399, i64 0
  %private.contiguous.address172 = getelementptr i8, ptr %397, i64 %401
  %private.contiguous.load173 = load <8 x float>, ptr %private.contiguous.address172, align 4
  %402 = select <8 x i1> %59, <8 x float> %private.contiguous.load173, <8 x float> zeroinitializer
  %403 = fmul <8 x float> %402, %402
  %.state174 = load <8 x float>, ptr %.slot32, align 32
  %404 = fadd <8 x float> %.state174, %403
  %.state175 = load i64, ptr %.slot30, align 4
  %405 = add i64 %.state175, 2
  %406 = sdiv i64 %405, 1
  %.spill.load176 = load i64, ptr %.spill15, align 4
  %407 = add i64 %.spill.load176, %406
  %.spill.load177 = load i64, ptr %.spill29, align 4
  %408 = add i64 %.spill.load177, %407
  %tile_snapshot.spill.load178 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 1
  %.splatinsert179 = insertelement <8 x i64> poison, i64 %408, i64 0
  %.splat180 = shufflevector <8 x i64> %.splatinsert179, <8 x i64> poison, <8 x i32> zeroinitializer
  %411 = mul <8 x i64> %.splat180, splat (i64 32)
  %412 = add <8 x i64> %410, %411
  %413 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %409, 0
  %414 = insertvalue { <8 x ptr>, <8 x i64> } %413, <8 x i64> %412, 1
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %414, 1
  %417 = extractelement <8 x ptr> %415, i32 0
  %418 = extractelement <8 x i64> %416, i32 0
  %419 = sub i64 %418, 0
  %420 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %421 = select i1 %420, i64 %419, i64 0
  %private.contiguous.address181 = getelementptr i8, ptr %417, i64 %421
  %private.contiguous.load182 = load <8 x float>, ptr %private.contiguous.address181, align 4
  %422 = select <8 x i1> %59, <8 x float> %private.contiguous.load182, <8 x float> zeroinitializer
  %423 = fmul <8 x float> %422, %422
  %.state183 = load <8 x float>, ptr %.slot33, align 32
  %424 = fadd <8 x float> %.state183, %423
  %.state184 = load i64, ptr %.slot30, align 4
  %425 = add i64 %.state184, 3
  %426 = sdiv i64 %425, 1
  %.spill.load185 = load i64, ptr %.spill15, align 4
  %427 = add i64 %.spill.load185, %426
  %.spill.load186 = load i64, ptr %.spill29, align 4
  %428 = add i64 %.spill.load186, %427
  %tile_snapshot.spill.load187 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %429 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 0
  %430 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 1
  %.splatinsert188 = insertelement <8 x i64> poison, i64 %428, i64 0
  %.splat189 = shufflevector <8 x i64> %.splatinsert188, <8 x i64> poison, <8 x i32> zeroinitializer
  %431 = mul <8 x i64> %.splat189, splat (i64 32)
  %432 = add <8 x i64> %430, %431
  %433 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %429, 0
  %434 = insertvalue { <8 x ptr>, <8 x i64> } %433, <8 x i64> %432, 1
  %435 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %434, 1
  %437 = extractelement <8 x ptr> %435, i32 0
  %438 = extractelement <8 x i64> %436, i32 0
  %439 = sub i64 %438, 0
  %440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %441 = select i1 %440, i64 %439, i64 0
  %private.contiguous.address190 = getelementptr i8, ptr %437, i64 %441
  %private.contiguous.load191 = load <8 x float>, ptr %private.contiguous.address190, align 4
  %442 = select <8 x i1> %59, <8 x float> %private.contiguous.load191, <8 x float> zeroinitializer
  %443 = fmul <8 x float> %442, %442
  %.state192 = load <8 x float>, ptr %.slot34, align 32
  %444 = fadd <8 x float> %.state192, %443
  %.state193 = load i64, ptr %.slot30, align 4
  %445 = add i64 %.state193, 4
  store i64 %445, ptr %.slot30, align 4
  %446 = load <8 x float>, ptr %.slot31, align 32
  %447 = select <8 x i1> %59, <8 x float> %384, <8 x float> %446
  store <8 x float> %447, ptr %.slot31, align 32
  %448 = load <8 x float>, ptr %.slot32, align 32
  %449 = select <8 x i1> %59, <8 x float> %404, <8 x float> %448
  store <8 x float> %449, ptr %.slot32, align 32
  %450 = load <8 x float>, ptr %.slot33, align 32
  %451 = select <8 x i1> %59, <8 x float> %424, <8 x float> %450
  store <8 x float> %451, ptr %.slot33, align 32
  %452 = load <8 x float>, ptr %.slot34, align 32
  %453 = select <8 x i1> %59, <8 x float> %444, <8 x float> %452
  store <8 x float> %453, ptr %.slot34, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false156
  %.spill.load194 = load float, ptr %.spill13, align 4
  %.splatinsert195 = insertelement <8 x float> poison, float %.spill.load194, i64 0
  %.splat196 = shufflevector <8 x float> %.splatinsert195, <8 x float> poison, <8 x i32> zeroinitializer
  %.state197 = load <8 x float>, ptr %.slot31, align 32
  %454 = fadd <8 x float> %.splat196, %.state197
  %.state198 = load <8 x float>, ptr %.slot32, align 32
  %455 = fadd <8 x float> %454, %.state198
  %.state199 = load <8 x float>, ptr %.slot33, align 32
  %456 = fadd <8 x float> %455, %.state199
  %.state200 = load <8 x float>, ptr %.slot34, align 32
  %457 = fadd <8 x float> %456, %.state200
  %.spill.load201 = load float, ptr %.spill25, align 4
  %.splatinsert202 = insertelement <8 x float> poison, float %.spill.load201, i64 0
  %.splat203 = shufflevector <8 x float> %.splatinsert202, <8 x float> poison, <8 x i32> zeroinitializer
  %458 = fdiv <8 x float> %457, %.splat203
  %459 = load <8 x float>, ptr %.spill35, align 32
  %460 = select <8 x i1> %59, <8 x float> %458, <8 x float> %459
  store <8 x float> %460, ptr %.spill35, align 32
  %461 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill36, align 64
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %461, 0
  %464 = select <8 x i1> %59, <8 x ptr> %462, <8 x ptr> %463
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %466 = extractvalue { <8 x ptr>, <8 x i64> } %461, 1
  %467 = select <8 x i1> %59, <8 x i64> %465, <8 x i64> %466
  %468 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %464, 0
  %469 = insertvalue { <8 x ptr>, <8 x i64> } %468, <8 x i64> %467, 1
  store { <8 x ptr>, <8 x i64> } %469, ptr %tile_snapshot.spill36, align 64
  store i64 0, ptr %.slot37, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state204 = load i64, ptr %.slot37, align 4
  %470 = icmp slt i64 %.state204, 768
  br i1 %470, label %direct.true205, label %direct.false206

direct.schedule.14:                               ; preds = %direct.true205
  %.spill.load207 = load i64, ptr %.spill14, align 4
  %471 = add i64 %.spill.load207, 0
  %.state208 = load i64, ptr %.slot37, align 4
  %472 = add i64 0, %.state208
  %473 = mul i64 %471, 768
  %474 = add i64 %473, %472
  %475 = extractvalue { ptr, i64 } %23, 0
  %476 = mul i64 %474, 4
  %477 = getelementptr i8, ptr %475, i64 %476
  %478 = load float, ptr %477, align 4
  %.splatinsert209 = insertelement <8 x float> poison, float %478, i64 0
  %.splat210 = shufflevector <8 x float> %.splatinsert209, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load211 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill36, align 64
  %479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 0
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 1
  %.state212 = load i64, ptr %.slot37, align 4
  %.splatinsert213 = insertelement <8 x i64> poison, i64 %.state212, i64 0
  %.splat214 = shufflevector <8 x i64> %.splatinsert213, <8 x i64> poison, <8 x i32> zeroinitializer
  %481 = mul <8 x i64> %.splat214, splat (i64 32)
  %482 = add <8 x i64> %480, %481
  %483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %479, 0
  %484 = insertvalue { <8 x ptr>, <8 x i64> } %483, <8 x i64> %482, 1
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %484, 1
  %487 = extractelement <8 x ptr> %485, i32 0
  %488 = extractelement <8 x i64> %486, i32 0
  %489 = sub i64 %488, 0
  %490 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %491 = select i1 %490, i64 %489, i64 0
  %private.contiguous.address215 = getelementptr i8, ptr %487, i64 %491
  %private.contiguous.preserve216 = load <8 x float>, ptr %private.contiguous.address215, align 4
  %492 = select <8 x i1> %59, <8 x float> %.splat210, <8 x float> %private.contiguous.preserve216
  store <8 x float> %492, ptr %private.contiguous.address215, align 4
  %.state217 = load i64, ptr %.slot37, align 4
  %493 = add i64 %.state217, 1
  store i64 %493, ptr %.slot37, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false206
  %.spill.load218 = load <8 x float>, ptr %.spill35, align 32
  %494 = fadd <8 x float> %.spill.load218, splat (float 0x3EE4F8B580000000)
  %495 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %494)
  %496 = load <8 x float>, ptr %.spill38, align 32
  %497 = select <8 x i1> %59, <8 x float> %495, <8 x float> %496
  store <8 x float> %497, ptr %.spill38, align 32
  %498 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %498, 0
  %501 = select <8 x i1> %59, <8 x ptr> %499, <8 x ptr> %500
  %502 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %503 = extractvalue { <8 x ptr>, <8 x i64> } %498, 1
  %504 = select <8 x i1> %59, <8 x i64> %502, <8 x i64> %503
  %505 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %501, 0
  %506 = insertvalue { <8 x ptr>, <8 x i64> } %505, <8 x i64> %504, 1
  store { <8 x ptr>, <8 x i64> } %506, ptr %tile_snapshot.spill39, align 64
  store i64 0, ptr %.slot40, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state219 = load i64, ptr %.slot40, align 4
  %507 = icmp slt i64 %.state219, 768
  br i1 %507, label %direct.true220, label %direct.false221

direct.schedule.17:                               ; preds = %direct.true220
  %.spill.load222 = load i64, ptr %.spill14, align 4
  %508 = add i64 %.spill.load222, 0
  %.state223 = load i64, ptr %.slot40, align 4
  %509 = add i64 0, %.state223
  %510 = mul i64 %508, 768
  %511 = add i64 %510, %509
  %512 = extractvalue { ptr, i64 } %29, 0
  %513 = mul i64 %511, 4
  %514 = getelementptr i8, ptr %512, i64 %513
  %515 = load float, ptr %514, align 4
  %.splatinsert224 = insertelement <8 x float> poison, float %515, i64 0
  %.splat225 = shufflevector <8 x float> %.splatinsert224, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load226 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load226, 0
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load226, 1
  %.state227 = load i64, ptr %.slot40, align 4
  %.splatinsert228 = insertelement <8 x i64> poison, i64 %.state227, i64 0
  %.splat229 = shufflevector <8 x i64> %.splatinsert228, <8 x i64> poison, <8 x i32> zeroinitializer
  %518 = mul <8 x i64> %.splat229, splat (i64 32)
  %519 = add <8 x i64> %517, %518
  %520 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %516, 0
  %521 = insertvalue { <8 x ptr>, <8 x i64> } %520, <8 x i64> %519, 1
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %521, 1
  %524 = extractelement <8 x ptr> %522, i32 0
  %525 = extractelement <8 x i64> %523, i32 0
  %526 = sub i64 %525, 0
  %527 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %528 = select i1 %527, i64 %526, i64 0
  %private.contiguous.address230 = getelementptr i8, ptr %524, i64 %528
  %private.contiguous.preserve231 = load <8 x float>, ptr %private.contiguous.address230, align 4
  %529 = select <8 x i1> %59, <8 x float> %.splat225, <8 x float> %private.contiguous.preserve231
  store <8 x float> %529, ptr %private.contiguous.address230, align 4
  %.state232 = load i64, ptr %.slot40, align 4
  %530 = add i64 %.state232, 1
  store i64 %530, ptr %.slot40, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false221
  store i64 0, ptr %.slot41, align 4
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state233 = load i64, ptr %.slot41, align 4
  %531 = icmp slt i64 %.state233, 768
  br i1 %531, label %direct.true234, label %direct.false235

direct.schedule.20:                               ; preds = %direct.true234
  %.spill.load236 = load <8 x i64>, ptr %.spill, align 64
  %532 = add <8 x i64> %.spill.load236, zeroinitializer
  %533 = add <8 x i64> zeroinitializer, %532
  %.state237 = load i64, ptr %.slot41, align 4
  %534 = add i64 0, %.state237
  %535 = mul <8 x i64> %533, splat (i64 768)
  %.splatinsert238 = insertelement <8 x i64> poison, i64 %534, i64 0
  %.splat239 = shufflevector <8 x i64> %.splatinsert238, <8 x i64> poison, <8 x i32> zeroinitializer
  %536 = add <8 x i64> %535, %.splat239
  %.spill.load240 = load i64, ptr %.spill29, align 4
  %.state241 = load i64, ptr %.slot41, align 4
  %537 = add i64 %.spill.load240, %.state241
  %.spill.load242 = load i64, ptr %.spill29, align 4
  %538 = add i64 %.spill.load242, %537
  %.spill.load243 = load i64, ptr %.spill29, align 4
  %539 = add i64 %.spill.load243, %538
  %tile_snapshot.spill.load244 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %540 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 0
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 1
  %.splatinsert245 = insertelement <8 x i64> poison, i64 %539, i64 0
  %.splat246 = shufflevector <8 x i64> %.splatinsert245, <8 x i64> poison, <8 x i32> zeroinitializer
  %542 = mul <8 x i64> %.splat246, splat (i64 32)
  %543 = add <8 x i64> %541, %542
  %544 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %540, 0
  %545 = insertvalue { <8 x ptr>, <8 x i64> } %544, <8 x i64> %543, 1
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %545, 1
  %548 = extractelement <8 x ptr> %546, i32 0
  %549 = extractelement <8 x i64> %547, i32 0
  %550 = sub i64 %549, 0
  %551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %552 = select i1 %551, i64 %550, i64 0
  %private.contiguous.address247 = getelementptr i8, ptr %548, i64 %552
  %private.contiguous.load248 = load <8 x float>, ptr %private.contiguous.address247, align 4
  %553 = select <8 x i1> %59, <8 x float> %private.contiguous.load248, <8 x float> zeroinitializer
  %.spill.load249 = load <8 x float>, ptr %.spill38, align 32
  %554 = fdiv <8 x float> %553, %.spill.load249
  %tile_snapshot.spill.load250 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill36, align 64
  %555 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 0
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 1
  %.splatinsert251 = insertelement <8 x i64> poison, i64 %538, i64 0
  %.splat252 = shufflevector <8 x i64> %.splatinsert251, <8 x i64> poison, <8 x i32> zeroinitializer
  %557 = mul <8 x i64> %.splat252, splat (i64 32)
  %558 = add <8 x i64> %556, %557
  %559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %555, 0
  %560 = insertvalue { <8 x ptr>, <8 x i64> } %559, <8 x i64> %558, 1
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %562 = extractvalue { <8 x ptr>, <8 x i64> } %560, 1
  %563 = extractelement <8 x ptr> %561, i32 0
  %564 = extractelement <8 x i64> %562, i32 0
  %565 = sub i64 %564, 0
  %566 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %567 = select i1 %566, i64 %565, i64 0
  %private.contiguous.address253 = getelementptr i8, ptr %563, i64 %567
  %private.contiguous.load254 = load <8 x float>, ptr %private.contiguous.address253, align 4
  %568 = select <8 x i1> %59, <8 x float> %private.contiguous.load254, <8 x float> zeroinitializer
  %569 = fmul <8 x float> %554, %568
  %tile_snapshot.spill.load255 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 0
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 1
  %.splatinsert256 = insertelement <8 x i64> poison, i64 %537, i64 0
  %.splat257 = shufflevector <8 x i64> %.splatinsert256, <8 x i64> poison, <8 x i32> zeroinitializer
  %572 = mul <8 x i64> %.splat257, splat (i64 32)
  %573 = add <8 x i64> %571, %572
  %574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %570, 0
  %575 = insertvalue { <8 x ptr>, <8 x i64> } %574, <8 x i64> %573, 1
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %575, 1
  %578 = extractelement <8 x ptr> %576, i32 0
  %579 = extractelement <8 x i64> %577, i32 0
  %580 = sub i64 %579, 0
  %581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %582 = select i1 %581, i64 %580, i64 0
  %private.contiguous.address258 = getelementptr i8, ptr %578, i64 %582
  %private.contiguous.load259 = load <8 x float>, ptr %private.contiguous.address258, align 4
  %583 = select <8 x i1> %59, <8 x float> %private.contiguous.load259, <8 x float> zeroinitializer
  %584 = fadd <8 x float> %569, %583
  %585 = extractvalue { ptr, i64 } %35, 0
  %586 = mul <8 x i64> %536, splat (i64 4)
  %587 = getelementptr i8, ptr %585, <8 x i64> %586
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %584, <8 x ptr> %587, i32 1, <8 x i1> %59)
  %.state260 = load i64, ptr %.slot41, align 4
  %588 = add i64 %.state260, 1
  store i64 %588, ptr %.slot41, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false235
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true71:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false72:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true114:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false115:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true155:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false156:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true205:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false206:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true220:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false221:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true234:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false235:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 24608
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 49216
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 73824
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %.slot19 = alloca i64, align 8
  store i64 0, ptr %.slot19, align 4
  %.slot20 = alloca i64, align 8
  store i64 0, ptr %.slot20, align 4
  %12 = getelementptr i8, ptr %argument_buffer, i64 0
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 16
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 32
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 48
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = load i32, ptr %launch_config, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 12
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 4
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 16
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 8
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 20
  %46 = load i32, ptr %45, align 4
  %47 = getelementptr i8, ptr %launch_config, i64 36
  %48 = load i32, ptr %47, align 4
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat22, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %50 = mul i32 %36, 32
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat24, %49
  %52 = mul i32 %40, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat26, zeroinitializer
  %54 = mul i32 %44, 1
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %54, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = add <8 x i32> %.splat28, zeroinitializer
  %56 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %51, 0
  %57 = insertvalue [3 x <8 x i32>] %56, <8 x i32> %53, 1
  %58 = insertvalue [3 x <8 x i32>] %57, <8 x i32> %55, 2
  %.splatinsert29 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat30 = shufflevector <8 x i32> %.splatinsert29, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat30
  %60 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  br i1 %60, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %61 = extractvalue [3 x <8 x i32>] %58, 0
  %62 = zext <8 x i32> %61 to <8 x i64>
  %63 = select <8 x i1> %59, <8 x i64> %62, <8 x i64> zeroinitializer
  %64 = select <8 x i1> %59, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %65 = sdiv <8 x i64> %63, %64
  %66 = load <8 x i64>, ptr %.spill, align 64
  %67 = select <8 x i1> %59, <8 x i64> %65, <8 x i64> %66
  store <8 x i64> %67, ptr %.spill, align 64
  %68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %68, 0
  %71 = select <8 x i1> %59, <8 x ptr> %69, <8 x ptr> %70
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %68, 1
  %74 = select <8 x i1> %59, <8 x i64> %72, <8 x i64> %73
  %75 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %71, 0
  %76 = insertvalue { <8 x ptr>, <8 x i64> } %75, <8 x i64> %74, 1
  store { <8 x ptr>, <8 x i64> } %76, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %77 = icmp slt i64 %.state, 769
  br i1 %77, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %78 = add <8 x i64> %.spill.load, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %.state31 = load i64, ptr %.slot, align 4
  %80 = add i64 0, %.state31
  %81 = mul <8 x i64> %79, splat (i64 1538)
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %82 = add <8 x i64> %81, %.splat33
  %83 = extractvalue { ptr, i64 } %17, 0
  %84 = mul <8 x i64> %82, splat (i64 4)
  %85 = getelementptr i8, ptr %83, <8 x i64> %84
  %86 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %85, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state34 = load i64, ptr %.slot, align 4
  %.splatinsert35 = insertelement <8 x i64> poison, i64 %.state34, i64 0
  %.splat36 = shufflevector <8 x i64> %.splatinsert35, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat36, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %59, <8 x float> %86, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state37 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state37, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %102, 0
  %105 = select <8 x i1> %59, <8 x ptr> %103, <8 x ptr> %104
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %102, 1
  %108 = select <8 x i1> %59, <8 x i64> %106, <8 x i64> %107
  %109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %105, 0
  %110 = insertvalue { <8 x ptr>, <8 x i64> } %109, <8 x i64> %108, 1
  store { <8 x ptr>, <8 x i64> } %110, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state38 = load i64, ptr %.slot14, align 4
  %111 = icmp slt i64 %.state38, 769
  br i1 %111, label %direct.true39, label %direct.false40

direct.schedule.5:                                ; preds = %direct.true39
  %.spill.load41 = load <8 x i64>, ptr %.spill, align 64
  %112 = add <8 x i64> %.spill.load41, zeroinitializer
  %113 = add <8 x i64> zeroinitializer, %112
  %.state42 = load i64, ptr %.slot14, align 4
  %114 = add i64 769, %.state42
  %115 = mul <8 x i64> %113, splat (i64 1538)
  %.splatinsert43 = insertelement <8 x i64> poison, i64 %114, i64 0
  %.splat44 = shufflevector <8 x i64> %.splatinsert43, <8 x i64> poison, <8 x i32> zeroinitializer
  %116 = add <8 x i64> %115, %.splat44
  %117 = extractvalue { ptr, i64 } %17, 0
  %118 = mul <8 x i64> %116, splat (i64 4)
  %119 = getelementptr i8, ptr %117, <8 x i64> %118
  %120 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %119, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load45 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load45, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load45, 1
  %.state46 = load i64, ptr %.slot14, align 4
  %.splatinsert47 = insertelement <8 x i64> poison, i64 %.state46, i64 0
  %.splat48 = shufflevector <8 x i64> %.splatinsert47, <8 x i64> poison, <8 x i32> zeroinitializer
  %123 = mul <8 x i64> %.splat48, splat (i64 32)
  %124 = add <8 x i64> %122, %123
  %125 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %121, 0
  %126 = insertvalue { <8 x ptr>, <8 x i64> } %125, <8 x i64> %124, 1
  %127 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %126, 1
  %129 = extractelement <8 x ptr> %127, i32 0
  %130 = extractelement <8 x i64> %128, i32 0
  %131 = sub i64 %130, 0
  %132 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %133 = select i1 %132, i64 %131, i64 0
  %private.contiguous.address49 = getelementptr i8, ptr %129, i64 %133
  %private.contiguous.preserve50 = load <8 x float>, ptr %private.contiguous.address49, align 4
  %134 = select <8 x i1> %59, <8 x float> %120, <8 x float> %private.contiguous.preserve50
  store <8 x float> %134, ptr %private.contiguous.address49, align 4
  %.state51 = load i64, ptr %.slot14, align 4
  %135 = add i64 %.state51, 1
  store i64 %135, ptr %.slot14, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false40
  %136 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %136, 0
  %139 = select <8 x i1> %59, <8 x ptr> %137, <8 x ptr> %138
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %136, 1
  %142 = select <8 x i1> %59, <8 x i64> %140, <8 x i64> %141
  %143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %139, 0
  %144 = insertvalue { <8 x ptr>, <8 x i64> } %143, <8 x i64> %142, 1
  store { <8 x ptr>, <8 x i64> } %144, ptr %tile_snapshot.spill15, align 64
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state52 = load i64, ptr %.slot16, align 4
  %145 = icmp slt i64 %.state52, 769
  br i1 %145, label %direct.true53, label %direct.false54

direct.schedule.8:                                ; preds = %direct.true53
  %.spill.load55 = load <8 x i64>, ptr %.spill, align 64
  %146 = add <8 x i64> %.spill.load55, zeroinitializer
  %147 = add <8 x i64> zeroinitializer, %146
  %.state56 = load i64, ptr %.slot16, align 4
  %148 = add i64 0, %.state56
  %149 = mul <8 x i64> %147, splat (i64 769)
  %.splatinsert57 = insertelement <8 x i64> poison, i64 %148, i64 0
  %.splat58 = shufflevector <8 x i64> %.splatinsert57, <8 x i64> poison, <8 x i32> zeroinitializer
  %150 = add <8 x i64> %149, %.splat58
  %151 = extractvalue { ptr, i64 } %23, 0
  %152 = mul <8 x i64> %150, splat (i64 4)
  %153 = getelementptr i8, ptr %151, <8 x i64> %152
  %154 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %153, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load59 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 0
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 1
  %.state60 = load i64, ptr %.slot16, align 4
  %.splatinsert61 = insertelement <8 x i64> poison, i64 %.state60, i64 0
  %.splat62 = shufflevector <8 x i64> %.splatinsert61, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = mul <8 x i64> %.splat62, splat (i64 32)
  %158 = add <8 x i64> %156, %157
  %159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %155, 0
  %160 = insertvalue { <8 x ptr>, <8 x i64> } %159, <8 x i64> %158, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %160, 1
  %163 = extractelement <8 x ptr> %161, i32 0
  %164 = extractelement <8 x i64> %162, i32 0
  %165 = sub i64 %164, 0
  %166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %167 = select i1 %166, i64 %165, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %163, i64 %167
  %private.contiguous.preserve64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %168 = select <8 x i1> %59, <8 x float> %154, <8 x float> %private.contiguous.preserve64
  store <8 x float> %168, ptr %private.contiguous.address63, align 4
  %.state65 = load i64, ptr %.slot16, align 4
  %169 = add i64 %.state65, 1
  store i64 %169, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false54
  %170 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %170, 0
  %173 = select <8 x i1> %59, <8 x ptr> %171, <8 x ptr> %172
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %170, 1
  %176 = select <8 x i1> %59, <8 x i64> %174, <8 x i64> %175
  %177 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %178 = insertvalue { <8 x ptr>, <8 x i64> } %177, <8 x i64> %176, 1
  store { <8 x ptr>, <8 x i64> } %178, ptr %tile_snapshot.spill17, align 64
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state66 = load i64, ptr %.slot18, align 4
  %179 = icmp slt i64 %.state66, 769
  br i1 %179, label %direct.true67, label %direct.false68

direct.schedule.11:                               ; preds = %direct.true67
  %.spill.load69 = load <8 x i64>, ptr %.spill, align 64
  %180 = add <8 x i64> %.spill.load69, zeroinitializer
  %181 = add <8 x i64> zeroinitializer, %180
  %.state70 = load i64, ptr %.slot18, align 4
  %182 = add i64 0, %.state70
  %183 = mul <8 x i64> %181, splat (i64 769)
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %182, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = add <8 x i64> %183, %.splat72
  %185 = extractvalue { ptr, i64 } %29, 0
  %186 = mul <8 x i64> %184, splat (i64 4)
  %187 = getelementptr i8, ptr %185, <8 x i64> %186
  %188 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %187, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load73 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 0
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 1
  %.state74 = load i64, ptr %.slot18, align 4
  %.splatinsert75 = insertelement <8 x i64> poison, i64 %.state74, i64 0
  %.splat76 = shufflevector <8 x i64> %.splatinsert75, <8 x i64> poison, <8 x i32> zeroinitializer
  %191 = mul <8 x i64> %.splat76, splat (i64 32)
  %192 = add <8 x i64> %190, %191
  %193 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %189, 0
  %194 = insertvalue { <8 x ptr>, <8 x i64> } %193, <8 x i64> %192, 1
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %194, 1
  %197 = extractelement <8 x ptr> %195, i32 0
  %198 = extractelement <8 x i64> %196, i32 0
  %199 = sub i64 %198, 0
  %200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %201 = select i1 %200, i64 %199, i64 0
  %private.contiguous.address77 = getelementptr i8, ptr %197, i64 %201
  %private.contiguous.preserve78 = load <8 x float>, ptr %private.contiguous.address77, align 4
  %202 = select <8 x i1> %59, <8 x float> %188, <8 x float> %private.contiguous.preserve78
  store <8 x float> %202, ptr %private.contiguous.address77, align 4
  %.state79 = load i64, ptr %.slot18, align 4
  %203 = add i64 %.state79, 1
  store i64 %203, ptr %.slot18, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false68
  store i64 0, ptr %.slot19, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state80 = load i64, ptr %.slot19, align 4
  %204 = icmp slt i64 %.state80, 769
  br i1 %204, label %direct.true81, label %direct.false82

direct.schedule.14:                               ; preds = %direct.true81
  %.spill.load83 = load <8 x i64>, ptr %.spill, align 64
  %205 = add <8 x i64> %.spill.load83, zeroinitializer
  %206 = add <8 x i64> zeroinitializer, %205
  %.state84 = load i64, ptr %.slot19, align 4
  %207 = add i64 0, %.state84
  %208 = mul <8 x i64> %206, splat (i64 1538)
  %.splatinsert85 = insertelement <8 x i64> poison, i64 %207, i64 0
  %.splat86 = shufflevector <8 x i64> %.splatinsert85, <8 x i64> poison, <8 x i32> zeroinitializer
  %209 = add <8 x i64> %208, %.splat86
  %.state87 = load i64, ptr %.slot19, align 4
  %210 = add i64 0, %.state87
  %211 = add i64 0, %210
  %tile_snapshot.spill.load88 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 0
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 1
  %.splatinsert89 = insertelement <8 x i64> poison, i64 %211, i64 0
  %.splat90 = shufflevector <8 x i64> %.splatinsert89, <8 x i64> poison, <8 x i32> zeroinitializer
  %214 = mul <8 x i64> %.splat90, splat (i64 32)
  %215 = add <8 x i64> %213, %214
  %216 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %212, 0
  %217 = insertvalue { <8 x ptr>, <8 x i64> } %216, <8 x i64> %215, 1
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %217, 1
  %220 = extractelement <8 x ptr> %218, i32 0
  %221 = extractelement <8 x i64> %219, i32 0
  %222 = sub i64 %221, 0
  %223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %224 = select i1 %223, i64 %222, i64 0
  %private.contiguous.address91 = getelementptr i8, ptr %220, i64 %224
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address91, align 4
  %225 = select <8 x i1> %59, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load92 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 1
  %.splatinsert93 = insertelement <8 x i64> poison, i64 %211, i64 0
  %.splat94 = shufflevector <8 x i64> %.splatinsert93, <8 x i64> poison, <8 x i32> zeroinitializer
  %228 = mul <8 x i64> %.splat94, splat (i64 32)
  %229 = add <8 x i64> %227, %228
  %230 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %226, 0
  %231 = insertvalue { <8 x ptr>, <8 x i64> } %230, <8 x i64> %229, 1
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %233 = extractvalue { <8 x ptr>, <8 x i64> } %231, 1
  %234 = extractelement <8 x ptr> %232, i32 0
  %235 = extractelement <8 x i64> %233, i32 0
  %236 = sub i64 %235, 0
  %237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %238 = select i1 %237, i64 %236, i64 0
  %private.contiguous.address95 = getelementptr i8, ptr %234, i64 %238
  %private.contiguous.load96 = load <8 x float>, ptr %private.contiguous.address95, align 4
  %239 = select <8 x i1> %59, <8 x float> %private.contiguous.load96, <8 x float> zeroinitializer
  %240 = fmul <8 x float> %225, %239
  %tile_snapshot.spill.load97 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 0
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 1
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %211, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %243 = mul <8 x i64> %.splat99, splat (i64 32)
  %244 = add <8 x i64> %242, %243
  %245 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %241, 0
  %246 = insertvalue { <8 x ptr>, <8 x i64> } %245, <8 x i64> %244, 1
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %246, 1
  %249 = extractelement <8 x ptr> %247, i32 0
  %250 = extractelement <8 x i64> %248, i32 0
  %251 = sub i64 %250, 0
  %252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %253 = select i1 %252, i64 %251, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %249, i64 %253
  %private.contiguous.load101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %254 = select <8 x i1> %59, <8 x float> %private.contiguous.load101, <8 x float> zeroinitializer
  %tile_snapshot.spill.load102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 0
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 1
  %.splatinsert103 = insertelement <8 x i64> poison, i64 %211, i64 0
  %.splat104 = shufflevector <8 x i64> %.splatinsert103, <8 x i64> poison, <8 x i32> zeroinitializer
  %257 = mul <8 x i64> %.splat104, splat (i64 32)
  %258 = add <8 x i64> %256, %257
  %259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %255, 0
  %260 = insertvalue { <8 x ptr>, <8 x i64> } %259, <8 x i64> %258, 1
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %260, 1
  %263 = extractelement <8 x ptr> %261, i32 0
  %264 = extractelement <8 x i64> %262, i32 0
  %265 = sub i64 %264, 0
  %266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %267 = select i1 %266, i64 %265, i64 0
  %private.contiguous.address105 = getelementptr i8, ptr %263, i64 %267
  %private.contiguous.load106 = load <8 x float>, ptr %private.contiguous.address105, align 4
  %268 = select <8 x i1> %59, <8 x float> %private.contiguous.load106, <8 x float> zeroinitializer
  %269 = fmul <8 x float> %254, %268
  %270 = fsub <8 x float> %240, %269
  %271 = extractvalue { ptr, i64 } %35, 0
  %272 = mul <8 x i64> %209, splat (i64 4)
  %273 = getelementptr i8, ptr %271, <8 x i64> %272
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %270, <8 x ptr> %273, i32 1, <8 x i1> %59)
  %.state107 = load i64, ptr %.slot19, align 4
  %274 = add i64 %.state107, 1
  store i64 %274, ptr %.slot19, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false82
  store i64 0, ptr %.slot20, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state108 = load i64, ptr %.slot20, align 4
  %275 = icmp slt i64 %.state108, 769
  br i1 %275, label %direct.true109, label %direct.false110

direct.schedule.17:                               ; preds = %direct.true109
  %.spill.load111 = load <8 x i64>, ptr %.spill, align 64
  %276 = add <8 x i64> %.spill.load111, zeroinitializer
  %277 = add <8 x i64> zeroinitializer, %276
  %.state112 = load i64, ptr %.slot20, align 4
  %278 = add i64 769, %.state112
  %279 = mul <8 x i64> %277, splat (i64 1538)
  %.splatinsert113 = insertelement <8 x i64> poison, i64 %278, i64 0
  %.splat114 = shufflevector <8 x i64> %.splatinsert113, <8 x i64> poison, <8 x i32> zeroinitializer
  %280 = add <8 x i64> %279, %.splat114
  %.state115 = load i64, ptr %.slot20, align 4
  %281 = add i64 0, %.state115
  %282 = add i64 0, %281
  %tile_snapshot.spill.load116 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 0
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 1
  %.splatinsert117 = insertelement <8 x i64> poison, i64 %282, i64 0
  %.splat118 = shufflevector <8 x i64> %.splatinsert117, <8 x i64> poison, <8 x i32> zeroinitializer
  %285 = mul <8 x i64> %.splat118, splat (i64 32)
  %286 = add <8 x i64> %284, %285
  %287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %283, 0
  %288 = insertvalue { <8 x ptr>, <8 x i64> } %287, <8 x i64> %286, 1
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %288, 1
  %291 = extractelement <8 x ptr> %289, i32 0
  %292 = extractelement <8 x i64> %290, i32 0
  %293 = sub i64 %292, 0
  %294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %295 = select i1 %294, i64 %293, i64 0
  %private.contiguous.address119 = getelementptr i8, ptr %291, i64 %295
  %private.contiguous.load120 = load <8 x float>, ptr %private.contiguous.address119, align 4
  %296 = select <8 x i1> %59, <8 x float> %private.contiguous.load120, <8 x float> zeroinitializer
  %tile_snapshot.spill.load121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 0
  %298 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 1
  %.splatinsert122 = insertelement <8 x i64> poison, i64 %282, i64 0
  %.splat123 = shufflevector <8 x i64> %.splatinsert122, <8 x i64> poison, <8 x i32> zeroinitializer
  %299 = mul <8 x i64> %.splat123, splat (i64 32)
  %300 = add <8 x i64> %298, %299
  %301 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %297, 0
  %302 = insertvalue { <8 x ptr>, <8 x i64> } %301, <8 x i64> %300, 1
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %302, 1
  %305 = extractelement <8 x ptr> %303, i32 0
  %306 = extractelement <8 x i64> %304, i32 0
  %307 = sub i64 %306, 0
  %308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %309 = select i1 %308, i64 %307, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %305, i64 %309
  %private.contiguous.load125 = load <8 x float>, ptr %private.contiguous.address124, align 4
  %310 = select <8 x i1> %59, <8 x float> %private.contiguous.load125, <8 x float> zeroinitializer
  %311 = fmul <8 x float> %296, %310
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %.splatinsert127 = insertelement <8 x i64> poison, i64 %282, i64 0
  %.splat128 = shufflevector <8 x i64> %.splatinsert127, <8 x i64> poison, <8 x i32> zeroinitializer
  %314 = mul <8 x i64> %.splat128, splat (i64 32)
  %315 = add <8 x i64> %313, %314
  %316 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %312, 0
  %317 = insertvalue { <8 x ptr>, <8 x i64> } %316, <8 x i64> %315, 1
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %317, 1
  %320 = extractelement <8 x ptr> %318, i32 0
  %321 = extractelement <8 x i64> %319, i32 0
  %322 = sub i64 %321, 0
  %323 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %324 = select i1 %323, i64 %322, i64 0
  %private.contiguous.address129 = getelementptr i8, ptr %320, i64 %324
  %private.contiguous.load130 = load <8 x float>, ptr %private.contiguous.address129, align 4
  %325 = select <8 x i1> %59, <8 x float> %private.contiguous.load130, <8 x float> zeroinitializer
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %282, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %328 = mul <8 x i64> %.splat133, splat (i64 32)
  %329 = add <8 x i64> %327, %328
  %330 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %326, 0
  %331 = insertvalue { <8 x ptr>, <8 x i64> } %330, <8 x i64> %329, 1
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %331, 1
  %334 = extractelement <8 x ptr> %332, i32 0
  %335 = extractelement <8 x i64> %333, i32 0
  %336 = sub i64 %335, 0
  %337 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %338 = select i1 %337, i64 %336, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %334, i64 %338
  %private.contiguous.load135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %339 = select <8 x i1> %59, <8 x float> %private.contiguous.load135, <8 x float> zeroinitializer
  %340 = fmul <8 x float> %325, %339
  %341 = fadd <8 x float> %311, %340
  %342 = extractvalue { ptr, i64 } %35, 0
  %343 = mul <8 x i64> %280, splat (i64 4)
  %344 = getelementptr i8, ptr %342, <8 x i64> %343
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %341, <8 x ptr> %344, i32 1, <8 x i1> %59)
  %.state136 = load i64, ptr %.slot20, align 4
  %345 = add i64 %.state136, 1
  store i64 %345, ptr %.slot20, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false110
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true39:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false40:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true53:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false54:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true67:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false68:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true81:                                    ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false82:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true109:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false110:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 24608
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 49216
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 73824
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %.slot19 = alloca i64, align 8
  store i64 0, ptr %.slot19, align 4
  %.slot20 = alloca i64, align 8
  store i64 0, ptr %.slot20, align 4
  %12 = getelementptr i8, ptr %argument_buffer, i64 0
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 16
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 32
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 48
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = load i32, ptr %launch_config, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 12
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 4
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 16
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 8
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 20
  %46 = load i32, ptr %45, align 4
  %47 = getelementptr i8, ptr %launch_config, i64 36
  %48 = load i32, ptr %47, align 4
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat22, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %50 = mul i32 %36, 32
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat24, %49
  %52 = mul i32 %40, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat26, zeroinitializer
  %54 = mul i32 %44, 1
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %54, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = add <8 x i32> %.splat28, zeroinitializer
  %56 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %51, 0
  %57 = insertvalue [3 x <8 x i32>] %56, <8 x i32> %53, 1
  %58 = insertvalue [3 x <8 x i32>] %57, <8 x i32> %55, 2
  %.splatinsert29 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat30 = shufflevector <8 x i32> %.splatinsert29, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat30
  %60 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  br i1 %60, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %61 = extractvalue [3 x <8 x i32>] %58, 0
  %62 = zext <8 x i32> %61 to <8 x i64>
  %63 = select <8 x i1> %59, <8 x i64> %62, <8 x i64> zeroinitializer
  %64 = select <8 x i1> %59, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %65 = sdiv <8 x i64> %63, %64
  %66 = load <8 x i64>, ptr %.spill, align 64
  %67 = select <8 x i1> %59, <8 x i64> %65, <8 x i64> %66
  store <8 x i64> %67, ptr %.spill, align 64
  %68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %68, 0
  %71 = select <8 x i1> %59, <8 x ptr> %69, <8 x ptr> %70
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %68, 1
  %74 = select <8 x i1> %59, <8 x i64> %72, <8 x i64> %73
  %75 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %71, 0
  %76 = insertvalue { <8 x ptr>, <8 x i64> } %75, <8 x i64> %74, 1
  store { <8 x ptr>, <8 x i64> } %76, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %77 = icmp slt i64 %.state, 769
  br i1 %77, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %78 = add <8 x i64> %.spill.load, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %.state31 = load i64, ptr %.slot, align 4
  %80 = add i64 0, %.state31
  %81 = mul <8 x i64> %79, splat (i64 1538)
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %82 = add <8 x i64> %81, %.splat33
  %83 = extractvalue { ptr, i64 } %17, 0
  %84 = mul <8 x i64> %82, splat (i64 4)
  %85 = getelementptr i8, ptr %83, <8 x i64> %84
  %86 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %85, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state34 = load i64, ptr %.slot, align 4
  %.splatinsert35 = insertelement <8 x i64> poison, i64 %.state34, i64 0
  %.splat36 = shufflevector <8 x i64> %.splatinsert35, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat36, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %59, <8 x float> %86, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state37 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state37, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %102, 0
  %105 = select <8 x i1> %59, <8 x ptr> %103, <8 x ptr> %104
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %102, 1
  %108 = select <8 x i1> %59, <8 x i64> %106, <8 x i64> %107
  %109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %105, 0
  %110 = insertvalue { <8 x ptr>, <8 x i64> } %109, <8 x i64> %108, 1
  store { <8 x ptr>, <8 x i64> } %110, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state38 = load i64, ptr %.slot14, align 4
  %111 = icmp slt i64 %.state38, 769
  br i1 %111, label %direct.true39, label %direct.false40

direct.schedule.5:                                ; preds = %direct.true39
  %.spill.load41 = load <8 x i64>, ptr %.spill, align 64
  %112 = add <8 x i64> %.spill.load41, zeroinitializer
  %113 = add <8 x i64> zeroinitializer, %112
  %.state42 = load i64, ptr %.slot14, align 4
  %114 = add i64 769, %.state42
  %115 = mul <8 x i64> %113, splat (i64 1538)
  %.splatinsert43 = insertelement <8 x i64> poison, i64 %114, i64 0
  %.splat44 = shufflevector <8 x i64> %.splatinsert43, <8 x i64> poison, <8 x i32> zeroinitializer
  %116 = add <8 x i64> %115, %.splat44
  %117 = extractvalue { ptr, i64 } %17, 0
  %118 = mul <8 x i64> %116, splat (i64 4)
  %119 = getelementptr i8, ptr %117, <8 x i64> %118
  %120 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %119, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load45 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load45, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load45, 1
  %.state46 = load i64, ptr %.slot14, align 4
  %.splatinsert47 = insertelement <8 x i64> poison, i64 %.state46, i64 0
  %.splat48 = shufflevector <8 x i64> %.splatinsert47, <8 x i64> poison, <8 x i32> zeroinitializer
  %123 = mul <8 x i64> %.splat48, splat (i64 32)
  %124 = add <8 x i64> %122, %123
  %125 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %121, 0
  %126 = insertvalue { <8 x ptr>, <8 x i64> } %125, <8 x i64> %124, 1
  %127 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %126, 1
  %129 = extractelement <8 x ptr> %127, i32 0
  %130 = extractelement <8 x i64> %128, i32 0
  %131 = sub i64 %130, 0
  %132 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %133 = select i1 %132, i64 %131, i64 0
  %private.contiguous.address49 = getelementptr i8, ptr %129, i64 %133
  %private.contiguous.preserve50 = load <8 x float>, ptr %private.contiguous.address49, align 4
  %134 = select <8 x i1> %59, <8 x float> %120, <8 x float> %private.contiguous.preserve50
  store <8 x float> %134, ptr %private.contiguous.address49, align 4
  %.state51 = load i64, ptr %.slot14, align 4
  %135 = add i64 %.state51, 1
  store i64 %135, ptr %.slot14, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false40
  %136 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %136, 0
  %139 = select <8 x i1> %59, <8 x ptr> %137, <8 x ptr> %138
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %136, 1
  %142 = select <8 x i1> %59, <8 x i64> %140, <8 x i64> %141
  %143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %139, 0
  %144 = insertvalue { <8 x ptr>, <8 x i64> } %143, <8 x i64> %142, 1
  store { <8 x ptr>, <8 x i64> } %144, ptr %tile_snapshot.spill15, align 64
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state52 = load i64, ptr %.slot16, align 4
  %145 = icmp slt i64 %.state52, 769
  br i1 %145, label %direct.true53, label %direct.false54

direct.schedule.8:                                ; preds = %direct.true53
  %.spill.load55 = load <8 x i64>, ptr %.spill, align 64
  %146 = add <8 x i64> %.spill.load55, zeroinitializer
  %147 = add <8 x i64> zeroinitializer, %146
  %.state56 = load i64, ptr %.slot16, align 4
  %148 = add i64 0, %.state56
  %149 = mul <8 x i64> %147, splat (i64 769)
  %.splatinsert57 = insertelement <8 x i64> poison, i64 %148, i64 0
  %.splat58 = shufflevector <8 x i64> %.splatinsert57, <8 x i64> poison, <8 x i32> zeroinitializer
  %150 = add <8 x i64> %149, %.splat58
  %151 = extractvalue { ptr, i64 } %23, 0
  %152 = mul <8 x i64> %150, splat (i64 4)
  %153 = getelementptr i8, ptr %151, <8 x i64> %152
  %154 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %153, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load59 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 0
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 1
  %.state60 = load i64, ptr %.slot16, align 4
  %.splatinsert61 = insertelement <8 x i64> poison, i64 %.state60, i64 0
  %.splat62 = shufflevector <8 x i64> %.splatinsert61, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = mul <8 x i64> %.splat62, splat (i64 32)
  %158 = add <8 x i64> %156, %157
  %159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %155, 0
  %160 = insertvalue { <8 x ptr>, <8 x i64> } %159, <8 x i64> %158, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %160, 1
  %163 = extractelement <8 x ptr> %161, i32 0
  %164 = extractelement <8 x i64> %162, i32 0
  %165 = sub i64 %164, 0
  %166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %167 = select i1 %166, i64 %165, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %163, i64 %167
  %private.contiguous.preserve64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %168 = select <8 x i1> %59, <8 x float> %154, <8 x float> %private.contiguous.preserve64
  store <8 x float> %168, ptr %private.contiguous.address63, align 4
  %.state65 = load i64, ptr %.slot16, align 4
  %169 = add i64 %.state65, 1
  store i64 %169, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false54
  %170 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %170, 0
  %173 = select <8 x i1> %59, <8 x ptr> %171, <8 x ptr> %172
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %170, 1
  %176 = select <8 x i1> %59, <8 x i64> %174, <8 x i64> %175
  %177 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %178 = insertvalue { <8 x ptr>, <8 x i64> } %177, <8 x i64> %176, 1
  store { <8 x ptr>, <8 x i64> } %178, ptr %tile_snapshot.spill17, align 64
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state66 = load i64, ptr %.slot18, align 4
  %179 = icmp slt i64 %.state66, 769
  br i1 %179, label %direct.true67, label %direct.false68

direct.schedule.11:                               ; preds = %direct.true67
  %.spill.load69 = load <8 x i64>, ptr %.spill, align 64
  %180 = add <8 x i64> %.spill.load69, zeroinitializer
  %181 = add <8 x i64> zeroinitializer, %180
  %.state70 = load i64, ptr %.slot18, align 4
  %182 = add i64 0, %.state70
  %183 = mul <8 x i64> %181, splat (i64 769)
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %182, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = add <8 x i64> %183, %.splat72
  %185 = extractvalue { ptr, i64 } %29, 0
  %186 = mul <8 x i64> %184, splat (i64 4)
  %187 = getelementptr i8, ptr %185, <8 x i64> %186
  %188 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %187, i32 1, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load73 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 0
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 1
  %.state74 = load i64, ptr %.slot18, align 4
  %.splatinsert75 = insertelement <8 x i64> poison, i64 %.state74, i64 0
  %.splat76 = shufflevector <8 x i64> %.splatinsert75, <8 x i64> poison, <8 x i32> zeroinitializer
  %191 = mul <8 x i64> %.splat76, splat (i64 32)
  %192 = add <8 x i64> %190, %191
  %193 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %189, 0
  %194 = insertvalue { <8 x ptr>, <8 x i64> } %193, <8 x i64> %192, 1
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %194, 1
  %197 = extractelement <8 x ptr> %195, i32 0
  %198 = extractelement <8 x i64> %196, i32 0
  %199 = sub i64 %198, 0
  %200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %201 = select i1 %200, i64 %199, i64 0
  %private.contiguous.address77 = getelementptr i8, ptr %197, i64 %201
  %private.contiguous.preserve78 = load <8 x float>, ptr %private.contiguous.address77, align 4
  %202 = select <8 x i1> %59, <8 x float> %188, <8 x float> %private.contiguous.preserve78
  store <8 x float> %202, ptr %private.contiguous.address77, align 4
  %.state79 = load i64, ptr %.slot18, align 4
  %203 = add i64 %.state79, 1
  store i64 %203, ptr %.slot18, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false68
  store i64 0, ptr %.slot19, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state80 = load i64, ptr %.slot19, align 4
  %204 = icmp slt i64 %.state80, 769
  br i1 %204, label %direct.true81, label %direct.false82

direct.schedule.14:                               ; preds = %direct.true81
  %.spill.load83 = load <8 x i64>, ptr %.spill, align 64
  %205 = add <8 x i64> %.spill.load83, zeroinitializer
  %206 = add <8 x i64> zeroinitializer, %205
  %.state84 = load i64, ptr %.slot19, align 4
  %207 = add i64 0, %.state84
  %208 = mul <8 x i64> %206, splat (i64 1538)
  %.splatinsert85 = insertelement <8 x i64> poison, i64 %207, i64 0
  %.splat86 = shufflevector <8 x i64> %.splatinsert85, <8 x i64> poison, <8 x i32> zeroinitializer
  %209 = add <8 x i64> %208, %.splat86
  %.state87 = load i64, ptr %.slot19, align 4
  %210 = add i64 0, %.state87
  %211 = add i64 0, %210
  %tile_snapshot.spill.load88 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 0
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 1
  %.splatinsert89 = insertelement <8 x i64> poison, i64 %211, i64 0
  %.splat90 = shufflevector <8 x i64> %.splatinsert89, <8 x i64> poison, <8 x i32> zeroinitializer
  %214 = mul <8 x i64> %.splat90, splat (i64 32)
  %215 = add <8 x i64> %213, %214
  %216 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %212, 0
  %217 = insertvalue { <8 x ptr>, <8 x i64> } %216, <8 x i64> %215, 1
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %217, 1
  %220 = extractelement <8 x ptr> %218, i32 0
  %221 = extractelement <8 x i64> %219, i32 0
  %222 = sub i64 %221, 0
  %223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %224 = select i1 %223, i64 %222, i64 0
  %private.contiguous.address91 = getelementptr i8, ptr %220, i64 %224
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address91, align 4
  %225 = select <8 x i1> %59, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load92 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 1
  %.splatinsert93 = insertelement <8 x i64> poison, i64 %211, i64 0
  %.splat94 = shufflevector <8 x i64> %.splatinsert93, <8 x i64> poison, <8 x i32> zeroinitializer
  %228 = mul <8 x i64> %.splat94, splat (i64 32)
  %229 = add <8 x i64> %227, %228
  %230 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %226, 0
  %231 = insertvalue { <8 x ptr>, <8 x i64> } %230, <8 x i64> %229, 1
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %233 = extractvalue { <8 x ptr>, <8 x i64> } %231, 1
  %234 = extractelement <8 x ptr> %232, i32 0
  %235 = extractelement <8 x i64> %233, i32 0
  %236 = sub i64 %235, 0
  %237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %238 = select i1 %237, i64 %236, i64 0
  %private.contiguous.address95 = getelementptr i8, ptr %234, i64 %238
  %private.contiguous.load96 = load <8 x float>, ptr %private.contiguous.address95, align 4
  %239 = select <8 x i1> %59, <8 x float> %private.contiguous.load96, <8 x float> zeroinitializer
  %240 = fmul <8 x float> %225, %239
  %tile_snapshot.spill.load97 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 0
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 1
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %211, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %243 = mul <8 x i64> %.splat99, splat (i64 32)
  %244 = add <8 x i64> %242, %243
  %245 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %241, 0
  %246 = insertvalue { <8 x ptr>, <8 x i64> } %245, <8 x i64> %244, 1
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %246, 1
  %249 = extractelement <8 x ptr> %247, i32 0
  %250 = extractelement <8 x i64> %248, i32 0
  %251 = sub i64 %250, 0
  %252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %253 = select i1 %252, i64 %251, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %249, i64 %253
  %private.contiguous.load101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %254 = select <8 x i1> %59, <8 x float> %private.contiguous.load101, <8 x float> zeroinitializer
  %tile_snapshot.spill.load102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 0
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 1
  %.splatinsert103 = insertelement <8 x i64> poison, i64 %211, i64 0
  %.splat104 = shufflevector <8 x i64> %.splatinsert103, <8 x i64> poison, <8 x i32> zeroinitializer
  %257 = mul <8 x i64> %.splat104, splat (i64 32)
  %258 = add <8 x i64> %256, %257
  %259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %255, 0
  %260 = insertvalue { <8 x ptr>, <8 x i64> } %259, <8 x i64> %258, 1
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %260, 1
  %263 = extractelement <8 x ptr> %261, i32 0
  %264 = extractelement <8 x i64> %262, i32 0
  %265 = sub i64 %264, 0
  %266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %267 = select i1 %266, i64 %265, i64 0
  %private.contiguous.address105 = getelementptr i8, ptr %263, i64 %267
  %private.contiguous.load106 = load <8 x float>, ptr %private.contiguous.address105, align 4
  %268 = select <8 x i1> %59, <8 x float> %private.contiguous.load106, <8 x float> zeroinitializer
  %269 = fmul <8 x float> %254, %268
  %270 = fsub <8 x float> %240, %269
  %271 = extractvalue { ptr, i64 } %35, 0
  %272 = mul <8 x i64> %209, splat (i64 4)
  %273 = getelementptr i8, ptr %271, <8 x i64> %272
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %270, <8 x ptr> %273, i32 1, <8 x i1> %59)
  %.state107 = load i64, ptr %.slot19, align 4
  %274 = add i64 %.state107, 1
  store i64 %274, ptr %.slot19, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false82
  store i64 0, ptr %.slot20, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state108 = load i64, ptr %.slot20, align 4
  %275 = icmp slt i64 %.state108, 769
  br i1 %275, label %direct.true109, label %direct.false110

direct.schedule.17:                               ; preds = %direct.true109
  %.spill.load111 = load <8 x i64>, ptr %.spill, align 64
  %276 = add <8 x i64> %.spill.load111, zeroinitializer
  %277 = add <8 x i64> zeroinitializer, %276
  %.state112 = load i64, ptr %.slot20, align 4
  %278 = add i64 769, %.state112
  %279 = mul <8 x i64> %277, splat (i64 1538)
  %.splatinsert113 = insertelement <8 x i64> poison, i64 %278, i64 0
  %.splat114 = shufflevector <8 x i64> %.splatinsert113, <8 x i64> poison, <8 x i32> zeroinitializer
  %280 = add <8 x i64> %279, %.splat114
  %.state115 = load i64, ptr %.slot20, align 4
  %281 = add i64 0, %.state115
  %282 = add i64 0, %281
  %tile_snapshot.spill.load116 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 0
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 1
  %.splatinsert117 = insertelement <8 x i64> poison, i64 %282, i64 0
  %.splat118 = shufflevector <8 x i64> %.splatinsert117, <8 x i64> poison, <8 x i32> zeroinitializer
  %285 = mul <8 x i64> %.splat118, splat (i64 32)
  %286 = add <8 x i64> %284, %285
  %287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %283, 0
  %288 = insertvalue { <8 x ptr>, <8 x i64> } %287, <8 x i64> %286, 1
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %288, 1
  %291 = extractelement <8 x ptr> %289, i32 0
  %292 = extractelement <8 x i64> %290, i32 0
  %293 = sub i64 %292, 0
  %294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %295 = select i1 %294, i64 %293, i64 0
  %private.contiguous.address119 = getelementptr i8, ptr %291, i64 %295
  %private.contiguous.load120 = load <8 x float>, ptr %private.contiguous.address119, align 4
  %296 = select <8 x i1> %59, <8 x float> %private.contiguous.load120, <8 x float> zeroinitializer
  %tile_snapshot.spill.load121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 0
  %298 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 1
  %.splatinsert122 = insertelement <8 x i64> poison, i64 %282, i64 0
  %.splat123 = shufflevector <8 x i64> %.splatinsert122, <8 x i64> poison, <8 x i32> zeroinitializer
  %299 = mul <8 x i64> %.splat123, splat (i64 32)
  %300 = add <8 x i64> %298, %299
  %301 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %297, 0
  %302 = insertvalue { <8 x ptr>, <8 x i64> } %301, <8 x i64> %300, 1
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %302, 1
  %305 = extractelement <8 x ptr> %303, i32 0
  %306 = extractelement <8 x i64> %304, i32 0
  %307 = sub i64 %306, 0
  %308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %309 = select i1 %308, i64 %307, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %305, i64 %309
  %private.contiguous.load125 = load <8 x float>, ptr %private.contiguous.address124, align 4
  %310 = select <8 x i1> %59, <8 x float> %private.contiguous.load125, <8 x float> zeroinitializer
  %311 = fmul <8 x float> %296, %310
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %.splatinsert127 = insertelement <8 x i64> poison, i64 %282, i64 0
  %.splat128 = shufflevector <8 x i64> %.splatinsert127, <8 x i64> poison, <8 x i32> zeroinitializer
  %314 = mul <8 x i64> %.splat128, splat (i64 32)
  %315 = add <8 x i64> %313, %314
  %316 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %312, 0
  %317 = insertvalue { <8 x ptr>, <8 x i64> } %316, <8 x i64> %315, 1
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %317, 1
  %320 = extractelement <8 x ptr> %318, i32 0
  %321 = extractelement <8 x i64> %319, i32 0
  %322 = sub i64 %321, 0
  %323 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %324 = select i1 %323, i64 %322, i64 0
  %private.contiguous.address129 = getelementptr i8, ptr %320, i64 %324
  %private.contiguous.load130 = load <8 x float>, ptr %private.contiguous.address129, align 4
  %325 = select <8 x i1> %59, <8 x float> %private.contiguous.load130, <8 x float> zeroinitializer
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %282, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %328 = mul <8 x i64> %.splat133, splat (i64 32)
  %329 = add <8 x i64> %327, %328
  %330 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %326, 0
  %331 = insertvalue { <8 x ptr>, <8 x i64> } %330, <8 x i64> %329, 1
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %331, 1
  %334 = extractelement <8 x ptr> %332, i32 0
  %335 = extractelement <8 x i64> %333, i32 0
  %336 = sub i64 %335, 0
  %337 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %338 = select i1 %337, i64 %336, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %334, i64 %338
  %private.contiguous.load135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %339 = select <8 x i1> %59, <8 x float> %private.contiguous.load135, <8 x float> zeroinitializer
  %340 = fmul <8 x float> %325, %339
  %341 = fadd <8 x float> %311, %340
  %342 = extractvalue { ptr, i64 } %35, 0
  %343 = mul <8 x i64> %280, splat (i64 4)
  %344 = getelementptr i8, ptr %342, <8 x i64> %343
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %341, <8 x ptr> %344, i32 1, <8 x i1> %59)
  %.state136 = load i64, ptr %.slot20, align 4
  %345 = add i64 %.state136, 1
  store i64 %345, ptr %.slot20, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false110
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true39:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false40:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true53:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false54:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true67:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false68:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true81:                                    ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false82:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true109:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false110:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

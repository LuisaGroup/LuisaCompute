; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 131104
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 393312
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4097, i64 8194, i64 12291, i64 16388, i64 20485, i64 24582, i64 28679>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 426088
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 557192
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %.spill19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill19, align 64
  %tile_snapshot.spill20 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill20, align 64
  %.slot21 = alloca i64, align 8
  store i64 0, ptr %.slot21, align 4
  %.spill22 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill22, align 4
  %tile_snapshot.spill23 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill23, align 64
  %.slot24 = alloca i64, align 8
  store i64 0, ptr %.slot24, align 4
  %.spill25 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill25, align 4
  %.spill26 = alloca i64, align 8
  store i64 0, ptr %.spill26, align 4
  %.spill27 = alloca i64, align 8
  store i64 0, ptr %.spill27, align 4
  %.spill28 = alloca i64, align 8
  store i64 0, ptr %.spill28, align 4
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca i64, align 8
  store i64 0, ptr %.spill30, align 4
  %.slot31 = alloca i64, align 8
  store i64 0, ptr %.slot31, align 4
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.spill36 = alloca i64, align 8
  store i64 0, ptr %.spill36, align 4
  %.spill37 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill37, align 32
  %.spill38 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill38, align 4
  %tile_snapshot.spill39 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill39, align 64
  %.slot40 = alloca i64, align 8
  store i64 0, ptr %.slot40, align 4
  %.slot41 = alloca i64, align 8
  store i64 0, ptr %.slot41, align 4
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.spill46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill46, align 32
  %.slot47 = alloca i64, align 8
  store i64 0, ptr %.slot47, align 4
  %15 = getelementptr i8, ptr %argument_buffer, i64 0
  %16 = load ptr, ptr %15, align 16
  %17 = getelementptr i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  %21 = getelementptr i8, ptr %argument_buffer, i64 16
  %22 = load ptr, ptr %21, align 16
  %23 = getelementptr i8, ptr %21, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = insertvalue { ptr, i64 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i64 } %25, i64 %24, 1
  %27 = getelementptr i8, ptr %argument_buffer, i64 32
  %28 = load ptr, ptr %27, align 16
  %29 = getelementptr i8, ptr %27, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { ptr, i64 } poison, ptr %28, 0
  %32 = insertvalue { ptr, i64 } %31, i64 %30, 1
  %33 = getelementptr i8, ptr %argument_buffer, i64 48
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = load i32, ptr %launch_config, align 4
  %40 = getelementptr i8, ptr %launch_config, i64 12
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr i8, ptr %launch_config, i64 4
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %launch_config, i64 16
  %45 = load i32, ptr %44, align 4
  %46 = getelementptr i8, ptr %launch_config, i64 8
  %47 = load i32, ptr %46, align 4
  %48 = getelementptr i8, ptr %launch_config, i64 20
  %49 = load i32, ptr %48, align 4
  %50 = getelementptr i8, ptr %launch_config, i64 36
  %51 = load i32, ptr %50, align 4
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %51, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %52 = add <8 x i32> %.splat49, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %53 = mul i32 %39, 32
  %.splatinsert50 = insertelement <8 x i32> poison, i32 %53, i64 0
  %.splat51 = shufflevector <8 x i32> %.splatinsert50, <8 x i32> poison, <8 x i32> zeroinitializer
  %54 = add <8 x i32> %.splat51, %52
  %55 = mul i32 %43, 1
  %.splatinsert52 = insertelement <8 x i32> poison, i32 %55, i64 0
  %.splat53 = shufflevector <8 x i32> %.splatinsert52, <8 x i32> poison, <8 x i32> zeroinitializer
  %56 = add <8 x i32> %.splat53, zeroinitializer
  %57 = mul i32 %47, 1
  %.splatinsert54 = insertelement <8 x i32> poison, i32 %57, i64 0
  %.splat55 = shufflevector <8 x i32> %.splatinsert54, <8 x i32> poison, <8 x i32> zeroinitializer
  %58 = add <8 x i32> %.splat55, zeroinitializer
  %59 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %54, 0
  %60 = insertvalue [3 x <8 x i32>] %59, <8 x i32> %56, 1
  %61 = insertvalue [3 x <8 x i32>] %60, <8 x i32> %58, 2
  %.splatinsert56 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat57 = shufflevector <8 x i32> %.splatinsert56, <8 x i32> poison, <8 x i32> zeroinitializer
  %62 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat57
  %63 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  br i1 %63, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %64 = extractvalue [3 x <8 x i32>] %61, 0
  %65 = zext <8 x i32> %64 to <8 x i64>
  %66 = select <8 x i1> %62, <8 x i64> %65, <8 x i64> zeroinitializer
  %67 = select <8 x i1> %62, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %68 = sdiv <8 x i64> %66, %67
  %69 = load <8 x i64>, ptr %.spill, align 64
  %70 = select <8 x i1> %62, <8 x i64> %68, <8 x i64> %69
  store <8 x i64> %70, ptr %.spill, align 64
  %71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %71, 0
  %74 = select <8 x i1> %62, <8 x ptr> %72, <8 x ptr> %73
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %71, 1
  %77 = select <8 x i1> %62, <8 x i64> %75, <8 x i64> %76
  %78 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %74, 0
  %79 = insertvalue { <8 x ptr>, <8 x i64> } %78, <8 x i64> %77, 1
  store { <8 x ptr>, <8 x i64> } %79, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %80 = icmp slt i64 %.state, 4097
  br i1 %80, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.spill.load, zeroinitializer
  %82 = add <8 x i64> zeroinitializer, %81
  %.state58 = load i64, ptr %.slot, align 4
  %83 = add i64 0, %.state58
  %84 = mul <8 x i64> %82, splat (i64 4097)
  %.splatinsert59 = insertelement <8 x i64> poison, i64 %83, i64 0
  %.splat60 = shufflevector <8 x i64> %.splatinsert59, <8 x i64> poison, <8 x i32> zeroinitializer
  %85 = add <8 x i64> %84, %.splat60
  %86 = extractvalue { ptr, i64 } %20, 0
  %87 = mul <8 x i64> %85, splat (i64 4)
  %88 = getelementptr i8, ptr %86, <8 x i64> %87
  %89 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %88, i32 1, <8 x i1> %62, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state61 = load i64, ptr %.slot, align 4
  %.splatinsert62 = insertelement <8 x i64> poison, i64 %.state61, i64 0
  %.splat63 = shufflevector <8 x i64> %.splatinsert62, <8 x i64> poison, <8 x i32> zeroinitializer
  %92 = mul <8 x i64> %.splat63, splat (i64 32)
  %93 = add <8 x i64> %91, %92
  %94 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %90, 0
  %95 = insertvalue { <8 x ptr>, <8 x i64> } %94, <8 x i64> %93, 1
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %95, 1
  %98 = extractelement <8 x ptr> %96, i32 0
  %99 = extractelement <8 x i64> %97, i32 0
  %100 = sub i64 %99, 0
  %101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %102 = select i1 %101, i64 %100, i64 0
  %private.contiguous.address = getelementptr i8, ptr %98, i64 %102
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %103 = select <8 x i1> %62, <8 x float> %89, <8 x float> %private.contiguous.preserve
  store <8 x float> %103, ptr %private.contiguous.address, align 4
  %.state64 = load i64, ptr %.slot, align 4
  %104 = add i64 %.state64, 1
  store i64 %104, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %105 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %105, 0
  %108 = select <8 x i1> %62, <8 x ptr> %106, <8 x ptr> %107
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %105, 1
  %111 = select <8 x i1> %62, <8 x i64> %109, <8 x i64> %110
  %112 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %108, 0
  %113 = insertvalue { <8 x ptr>, <8 x i64> } %112, <8 x i64> %111, 1
  store { <8 x ptr>, <8 x i64> } %113, ptr %tile_snapshot.spill17, align 64
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state65 = load i64, ptr %.slot18, align 4
  %114 = icmp slt i64 %.state65, 4097
  br i1 %114, label %direct.true66, label %direct.false67

direct.schedule.5:                                ; preds = %direct.true66
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %.state69 = load i64, ptr %.slot18, align 4
  %.splatinsert70 = insertelement <8 x i64> poison, i64 %.state69, i64 0
  %.splat71 = shufflevector <8 x i64> %.splatinsert70, <8 x i64> poison, <8 x i32> zeroinitializer
  %117 = mul <8 x i64> %.splat71, splat (i64 64)
  %118 = add <8 x i64> %116, %117
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %.state72 = load i64, ptr %.slot18, align 4
  %.splatinsert73 = insertelement <8 x i64> poison, i64 %.state72, i64 0
  %.splat74 = shufflevector <8 x i64> %.splatinsert73, <8 x i64> poison, <8 x i32> zeroinitializer
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address75 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve76 = load <8 x i64>, ptr %private.contiguous.address75, align 8
  %128 = select <8 x i1> %62, <8 x i64> %.splat74, <8 x i64> %private.contiguous.preserve76
  store <8 x i64> %128, ptr %private.contiguous.address75, align 8
  %.state77 = load i64, ptr %.slot18, align 4
  %129 = add i64 %.state77, 1
  store i64 %129, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false67
  %.spill.load78 = load <8 x i64>, ptr %.spill, align 64
  %130 = select <8 x i1> %62, <8 x i64> %.spill.load78, <8 x i64> zeroinitializer
  %131 = select <8 x i1> %62, <8 x i64> splat (i64 4097), <8 x i64> splat (i64 1)
  %132 = srem <8 x i64> %130, %131
  %133 = load <8 x i64>, ptr %.spill19, align 64
  %134 = select <8 x i1> %62, <8 x i64> %132, <8 x i64> %133
  store <8 x i64> %134, ptr %.spill19, align 64
  %135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %135, 0
  %138 = select <8 x i1> %62, <8 x ptr> %136, <8 x ptr> %137
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %135, 1
  %141 = select <8 x i1> %62, <8 x i64> %139, <8 x i64> %140
  %142 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %138, 0
  %143 = insertvalue { <8 x ptr>, <8 x i64> } %142, <8 x i64> %141, 1
  store { <8 x ptr>, <8 x i64> } %143, ptr %tile_snapshot.spill20, align 64
  store i64 0, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state79 = load i64, ptr %.slot21, align 4
  %144 = icmp slt i64 %.state79, 4097
  br i1 %144, label %direct.true80, label %direct.false81

direct.schedule.8:                                ; preds = %direct.true80
  %.state82 = load i64, ptr %.slot21, align 4
  %145 = add i64 0, %.state82
  %tile_snapshot.spill.load83 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 1
  %.splatinsert84 = insertelement <8 x i64> poison, i64 %145, i64 0
  %.splat85 = shufflevector <8 x i64> %.splatinsert84, <8 x i64> poison, <8 x i32> zeroinitializer
  %148 = mul <8 x i64> %.splat85, splat (i64 64)
  %149 = add <8 x i64> %147, %148
  %150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %146, 0
  %151 = insertvalue { <8 x ptr>, <8 x i64> } %150, <8 x i64> %149, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %154 = extractelement <8 x ptr> %152, i32 0
  %155 = extractelement <8 x i64> %153, i32 0
  %156 = sub i64 %155, 0
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %158 = select i1 %157, i64 %156, i64 0
  %private.contiguous.address86 = getelementptr i8, ptr %154, i64 %158
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address86, align 8
  %159 = select <8 x i1> %62, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load87 = load <8 x i64>, ptr %.spill19, align 64
  %160 = icmp sle <8 x i64> %159, %.spill.load87
  %tile_snapshot.spill.load88 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 1
  %.state89 = load i64, ptr %.slot21, align 4
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %.state89, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %163 = add <8 x i64> %162, %.splat91
  %164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %161, 0
  %165 = insertvalue { <8 x ptr>, <8 x i64> } %164, <8 x i64> %163, 1
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %168 = getelementptr i8, <8 x ptr> %166, <8 x i64> %167
  %169 = zext <8 x i1> %160 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %169, <8 x ptr> %168, i32 1, <8 x i1> %62)
  %.state92 = load i64, ptr %.slot21, align 4
  %170 = add i64 %.state92, 1
  store i64 %170, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false81
  store float 0xC6293E5940000000, ptr %.spill22, align 4
  %171 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 0
  %174 = select <8 x i1> %62, <8 x ptr> %172, <8 x ptr> %173
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %177 = select <8 x i1> %62, <8 x i64> %175, <8 x i64> %176
  %178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %174, 0
  %179 = insertvalue { <8 x ptr>, <8 x i64> } %178, <8 x i64> %177, 1
  store { <8 x ptr>, <8 x i64> } %179, ptr %tile_snapshot.spill23, align 64
  store i64 0, ptr %.slot24, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state93 = load i64, ptr %.slot24, align 4
  %180 = icmp slt i64 %.state93, 4097
  br i1 %180, label %direct.true94, label %direct.false95

direct.schedule.11:                               ; preds = %direct.true94
  %.state96 = load i64, ptr %.slot24, align 4
  %181 = add i64 0, %.state96
  %tile_snapshot.spill.load97 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 1
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = add <8 x i64> %183, %.splat99
  %185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %182, 0
  %186 = insertvalue { <8 x ptr>, <8 x i64> } %185, <8 x i64> %184, 1
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %186, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %186, 1
  %189 = getelementptr i8, <8 x ptr> %187, <8 x i64> %188
  %190 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %189, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %191 = icmp ne <8 x i8> %190, zeroinitializer
  %tile_snapshot.spill.load100 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 1
  %.splatinsert101 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat102 = shufflevector <8 x i64> %.splatinsert101, <8 x i64> poison, <8 x i32> zeroinitializer
  %194 = mul <8 x i64> %.splat102, splat (i64 32)
  %195 = add <8 x i64> %193, %194
  %196 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %192, 0
  %197 = insertvalue { <8 x ptr>, <8 x i64> } %196, <8 x i64> %195, 1
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %197, 1
  %200 = extractelement <8 x ptr> %198, i32 0
  %201 = extractelement <8 x i64> %199, i32 0
  %202 = sub i64 %201, 0
  %203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %204 = select i1 %203, i64 %202, i64 0
  %private.contiguous.address103 = getelementptr i8, ptr %200, i64 %204
  %private.contiguous.load104 = load <8 x float>, ptr %private.contiguous.address103, align 4
  %205 = select <8 x i1> %62, <8 x float> %private.contiguous.load104, <8 x float> zeroinitializer
  %.spill.load105 = load float, ptr %.spill22, align 4
  %.splatinsert106 = insertelement <8 x float> poison, float %.spill.load105, i64 0
  %.splat107 = shufflevector <8 x float> %.splatinsert106, <8 x float> poison, <8 x i32> zeroinitializer
  %206 = select <8 x i1> %191, <8 x float> %205, <8 x float> %.splat107
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %.state109 = load i64, ptr %.slot24, align 4
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %.state109, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %209 = mul <8 x i64> %.splat111, splat (i64 32)
  %210 = add <8 x i64> %208, %209
  %211 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %207, 0
  %212 = insertvalue { <8 x ptr>, <8 x i64> } %211, <8 x i64> %210, 1
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %212, 1
  %215 = extractelement <8 x ptr> %213, i32 0
  %216 = extractelement <8 x i64> %214, i32 0
  %217 = sub i64 %216, 0
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %219 = select i1 %218, i64 %217, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %215, i64 %219
  %private.contiguous.preserve113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %220 = select <8 x i1> %62, <8 x float> %206, <8 x float> %private.contiguous.preserve113
  store <8 x float> %220, ptr %private.contiguous.address112, align 4
  %.state114 = load i64, ptr %.slot24, align 4
  %221 = add i64 %.state114, 1
  store i64 %221, ptr %.slot24, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false95
  store float 0xFFF0000000000000, ptr %.spill25, align 4
  store i64 0, ptr %.spill26, align 4
  store i64 0, ptr %.spill27, align 4
  %tile_snapshot.spill.load115 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 1
  %224 = add <8 x i64> %223, zeroinitializer
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = extractelement <8 x ptr> %227, i32 0
  %230 = extractelement <8 x i64> %228, i32 0
  %231 = sub i64 %230, 0
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %233 = select i1 %232, i64 %231, i64 0
  %private.contiguous.address116 = getelementptr i8, ptr %229, i64 %233
  %private.contiguous.load117 = load <8 x float>, ptr %private.contiguous.address116, align 4
  %234 = select <8 x i1> %62, <8 x float> %private.contiguous.load117, <8 x float> zeroinitializer
  store i64 1, ptr %.spill28, align 4
  %tile_snapshot.spill.load118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 1
  %237 = add <8 x i64> %236, splat (i64 32)
  %238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %235, 0
  %239 = insertvalue { <8 x ptr>, <8 x i64> } %238, <8 x i64> %237, 1
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %239, 1
  %242 = extractelement <8 x ptr> %240, i32 0
  %243 = extractelement <8 x i64> %241, i32 0
  %244 = sub i64 %243, 0
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %246 = select i1 %245, i64 %244, i64 0
  %private.contiguous.address119 = getelementptr i8, ptr %242, i64 %246
  %private.contiguous.load120 = load <8 x float>, ptr %private.contiguous.address119, align 4
  %247 = select <8 x i1> %62, <8 x float> %private.contiguous.load120, <8 x float> zeroinitializer
  store i64 2, ptr %.spill29, align 4
  %tile_snapshot.spill.load121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 1
  %250 = add <8 x i64> %249, splat (i64 64)
  %251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %252 = insertvalue { <8 x ptr>, <8 x i64> } %251, <8 x i64> %250, 1
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %255 = extractelement <8 x ptr> %253, i32 0
  %256 = extractelement <8 x i64> %254, i32 0
  %257 = sub i64 %256, 0
  %258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %259 = select i1 %258, i64 %257, i64 0
  %private.contiguous.address122 = getelementptr i8, ptr %255, i64 %259
  %private.contiguous.load123 = load <8 x float>, ptr %private.contiguous.address122, align 4
  %260 = select <8 x i1> %62, <8 x float> %private.contiguous.load123, <8 x float> zeroinitializer
  store i64 3, ptr %.spill30, align 4
  %tile_snapshot.spill.load124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 1
  %263 = add <8 x i64> %262, splat (i64 96)
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = extractelement <8 x ptr> %266, i32 0
  %269 = extractelement <8 x i64> %267, i32 0
  %270 = sub i64 %269, 0
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %272 = select i1 %271, i64 %270, i64 0
  %private.contiguous.address125 = getelementptr i8, ptr %268, i64 %272
  %private.contiguous.load126 = load <8 x float>, ptr %private.contiguous.address125, align 4
  %273 = select <8 x i1> %62, <8 x float> %private.contiguous.load126, <8 x float> zeroinitializer
  store i64 4, ptr %.slot31, align 4
  %274 = load <8 x float>, ptr %.slot32, align 32
  %275 = select <8 x i1> %62, <8 x float> %234, <8 x float> %274
  store <8 x float> %275, ptr %.slot32, align 32
  %276 = load <8 x float>, ptr %.slot33, align 32
  %277 = select <8 x i1> %62, <8 x float> %247, <8 x float> %276
  store <8 x float> %277, ptr %.slot33, align 32
  %278 = load <8 x float>, ptr %.slot34, align 32
  %279 = select <8 x i1> %62, <8 x float> %260, <8 x float> %278
  store <8 x float> %279, ptr %.slot34, align 32
  %280 = load <8 x float>, ptr %.slot35, align 32
  %281 = select <8 x i1> %62, <8 x float> %273, <8 x float> %280
  store <8 x float> %281, ptr %.slot35, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state127 = load i64, ptr %.slot31, align 4
  %282 = icmp slt i64 %.state127, 4096
  br i1 %282, label %direct.true128, label %direct.false129

direct.schedule.14:                               ; preds = %direct.true128
  %.state130 = load i64, ptr %.slot31, align 4
  %283 = add i64 %.state130, 0
  %284 = sdiv i64 %283, 1
  %.spill.load131 = load i64, ptr %.spill26, align 4
  %285 = add i64 %.spill.load131, %284
  %tile_snapshot.spill.load132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 1
  %.splatinsert133 = insertelement <8 x i64> poison, i64 %285, i64 0
  %.splat134 = shufflevector <8 x i64> %.splatinsert133, <8 x i64> poison, <8 x i32> zeroinitializer
  %288 = mul <8 x i64> %.splat134, splat (i64 32)
  %289 = add <8 x i64> %287, %288
  %290 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %286, 0
  %291 = insertvalue { <8 x ptr>, <8 x i64> } %290, <8 x i64> %289, 1
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %291, 1
  %294 = extractelement <8 x ptr> %292, i32 0
  %295 = extractelement <8 x i64> %293, i32 0
  %296 = sub i64 %295, 0
  %297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %298 = select i1 %297, i64 %296, i64 0
  %private.contiguous.address135 = getelementptr i8, ptr %294, i64 %298
  %private.contiguous.load136 = load <8 x float>, ptr %private.contiguous.address135, align 4
  %299 = select <8 x i1> %62, <8 x float> %private.contiguous.load136, <8 x float> zeroinitializer
  %.state137 = load <8 x float>, ptr %.slot32, align 32
  %300 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state137, <8 x float> %299)
  %.state138 = load i64, ptr %.slot31, align 4
  %301 = add i64 %.state138, 1
  %302 = sdiv i64 %301, 1
  %.spill.load139 = load i64, ptr %.spill26, align 4
  %303 = add i64 %.spill.load139, %302
  %tile_snapshot.spill.load140 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 1
  %.splatinsert141 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat142 = shufflevector <8 x i64> %.splatinsert141, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat142, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address143 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load144 = load <8 x float>, ptr %private.contiguous.address143, align 4
  %317 = select <8 x i1> %62, <8 x float> %private.contiguous.load144, <8 x float> zeroinitializer
  %.state145 = load <8 x float>, ptr %.slot33, align 32
  %318 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state145, <8 x float> %317)
  %.state146 = load i64, ptr %.slot31, align 4
  %319 = add i64 %.state146, 2
  %320 = sdiv i64 %319, 1
  %.spill.load147 = load i64, ptr %.spill26, align 4
  %321 = add i64 %.spill.load147, %320
  %tile_snapshot.spill.load148 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load148, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load148, 1
  %.splatinsert149 = insertelement <8 x i64> poison, i64 %321, i64 0
  %.splat150 = shufflevector <8 x i64> %.splatinsert149, <8 x i64> poison, <8 x i32> zeroinitializer
  %324 = mul <8 x i64> %.splat150, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address151 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.load152 = load <8 x float>, ptr %private.contiguous.address151, align 4
  %335 = select <8 x i1> %62, <8 x float> %private.contiguous.load152, <8 x float> zeroinitializer
  %.state153 = load <8 x float>, ptr %.slot34, align 32
  %336 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state153, <8 x float> %335)
  %.state154 = load i64, ptr %.slot31, align 4
  %337 = add i64 %.state154, 3
  %338 = sdiv i64 %337, 1
  %.spill.load155 = load i64, ptr %.spill26, align 4
  %339 = add i64 %.spill.load155, %338
  %tile_snapshot.spill.load156 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 1
  %.splatinsert157 = insertelement <8 x i64> poison, i64 %339, i64 0
  %.splat158 = shufflevector <8 x i64> %.splatinsert157, <8 x i64> poison, <8 x i32> zeroinitializer
  %342 = mul <8 x i64> %.splat158, splat (i64 32)
  %343 = add <8 x i64> %341, %342
  %344 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %340, 0
  %345 = insertvalue { <8 x ptr>, <8 x i64> } %344, <8 x i64> %343, 1
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %345, 1
  %348 = extractelement <8 x ptr> %346, i32 0
  %349 = extractelement <8 x i64> %347, i32 0
  %350 = sub i64 %349, 0
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %352 = select i1 %351, i64 %350, i64 0
  %private.contiguous.address159 = getelementptr i8, ptr %348, i64 %352
  %private.contiguous.load160 = load <8 x float>, ptr %private.contiguous.address159, align 4
  %353 = select <8 x i1> %62, <8 x float> %private.contiguous.load160, <8 x float> zeroinitializer
  %.state161 = load <8 x float>, ptr %.slot35, align 32
  %354 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state161, <8 x float> %353)
  %.state162 = load i64, ptr %.slot31, align 4
  %355 = add i64 %.state162, 4
  store i64 %355, ptr %.slot31, align 4
  %356 = load <8 x float>, ptr %.slot32, align 32
  %357 = select <8 x i1> %62, <8 x float> %300, <8 x float> %356
  store <8 x float> %357, ptr %.slot32, align 32
  %358 = load <8 x float>, ptr %.slot33, align 32
  %359 = select <8 x i1> %62, <8 x float> %318, <8 x float> %358
  store <8 x float> %359, ptr %.slot33, align 32
  %360 = load <8 x float>, ptr %.slot34, align 32
  %361 = select <8 x i1> %62, <8 x float> %336, <8 x float> %360
  store <8 x float> %361, ptr %.slot34, align 32
  %362 = load <8 x float>, ptr %.slot35, align 32
  %363 = select <8 x i1> %62, <8 x float> %354, <8 x float> %362
  store <8 x float> %363, ptr %.slot35, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false129
  %.spill.load163 = load i64, ptr %.spill26, align 4
  %364 = add i64 %.spill.load163, 4096
  store i64 %364, ptr %.spill36, align 4
  %tile_snapshot.spill.load164 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %365 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load164, 0
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load164, 1
  %.splatinsert165 = insertelement <8 x i64> poison, i64 %364, i64 0
  %.splat166 = shufflevector <8 x i64> %.splatinsert165, <8 x i64> poison, <8 x i32> zeroinitializer
  %367 = mul <8 x i64> %.splat166, splat (i64 32)
  %368 = add <8 x i64> %366, %367
  %369 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %365, 0
  %370 = insertvalue { <8 x ptr>, <8 x i64> } %369, <8 x i64> %368, 1
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %370, 1
  %373 = extractelement <8 x ptr> %371, i32 0
  %374 = extractelement <8 x i64> %372, i32 0
  %375 = sub i64 %374, 0
  %376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %377 = select i1 %376, i64 %375, i64 0
  %private.contiguous.address167 = getelementptr i8, ptr %373, i64 %377
  %private.contiguous.load168 = load <8 x float>, ptr %private.contiguous.address167, align 4
  %378 = select <8 x i1> %62, <8 x float> %private.contiguous.load168, <8 x float> zeroinitializer
  %.state169 = load <8 x float>, ptr %.slot32, align 32
  %379 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state169, <8 x float> %378)
  %.spill.load170 = load float, ptr %.spill25, align 4
  %.splatinsert171 = insertelement <8 x float> poison, float %.spill.load170, i64 0
  %.splat172 = shufflevector <8 x float> %.splatinsert171, <8 x float> poison, <8 x i32> zeroinitializer
  %380 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.splat172, <8 x float> %379)
  %.state173 = load <8 x float>, ptr %.slot33, align 32
  %381 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %380, <8 x float> %.state173)
  %.state174 = load <8 x float>, ptr %.slot34, align 32
  %382 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %381, <8 x float> %.state174)
  %.state175 = load <8 x float>, ptr %.slot35, align 32
  %383 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %382, <8 x float> %.state175)
  %384 = load <8 x float>, ptr %.spill37, align 32
  %385 = select <8 x i1> %62, <8 x float> %383, <8 x float> %384
  store <8 x float> %385, ptr %.spill37, align 32
  store float 0.000000e+00, ptr %.spill38, align 4
  %386 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %386, 0
  %389 = select <8 x i1> %62, <8 x ptr> %387, <8 x ptr> %388
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %391 = extractvalue { <8 x ptr>, <8 x i64> } %386, 1
  %392 = select <8 x i1> %62, <8 x i64> %390, <8 x i64> %391
  %393 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %389, 0
  %394 = insertvalue { <8 x ptr>, <8 x i64> } %393, <8 x i64> %392, 1
  store { <8 x ptr>, <8 x i64> } %394, ptr %tile_snapshot.spill39, align 64
  store i64 0, ptr %.slot40, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state176 = load i64, ptr %.slot40, align 4
  %395 = icmp slt i64 %.state176, 4097
  br i1 %395, label %direct.true177, label %direct.false178

direct.schedule.17:                               ; preds = %direct.true177
  %.state179 = load i64, ptr %.slot40, align 4
  %396 = add i64 0, %.state179
  %tile_snapshot.spill.load180 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %397 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load180, 0
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load180, 1
  %.splatinsert181 = insertelement <8 x i64> poison, i64 %396, i64 0
  %.splat182 = shufflevector <8 x i64> %.splatinsert181, <8 x i64> poison, <8 x i32> zeroinitializer
  %399 = add <8 x i64> %398, %.splat182
  %400 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %397, 0
  %401 = insertvalue { <8 x ptr>, <8 x i64> } %400, <8 x i64> %399, 1
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %401, 0
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %401, 1
  %404 = getelementptr i8, <8 x ptr> %402, <8 x i64> %403
  %405 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %404, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %406 = icmp ne <8 x i8> %405, zeroinitializer
  %407 = add i64 0, %396
  %408 = add i64 0, %407
  %tile_snapshot.spill.load183 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load183, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load183, 1
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %408, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %411 = mul <8 x i64> %.splat185, splat (i64 32)
  %412 = add <8 x i64> %410, %411
  %413 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %409, 0
  %414 = insertvalue { <8 x ptr>, <8 x i64> } %413, <8 x i64> %412, 1
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %414, 1
  %417 = extractelement <8 x ptr> %415, i32 0
  %418 = extractelement <8 x i64> %416, i32 0
  %419 = sub i64 %418, 0
  %420 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %421 = select i1 %420, i64 %419, i64 0
  %private.contiguous.address186 = getelementptr i8, ptr %417, i64 %421
  %private.contiguous.load187 = load <8 x float>, ptr %private.contiguous.address186, align 4
  %422 = select <8 x i1> %62, <8 x float> %private.contiguous.load187, <8 x float> zeroinitializer
  %.spill.load188 = load <8 x float>, ptr %.spill37, align 32
  %423 = fsub <8 x float> %422, %.spill.load188
  %424 = select <8 x i1> %62, <8 x float> %423, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %424)
  %.spill.load189 = load float, ptr %.spill38, align 4
  %.splatinsert190 = insertelement <8 x float> poison, float %.spill.load189, i64 0
  %.splat191 = shufflevector <8 x float> %.splatinsert190, <8 x float> poison, <8 x i32> zeroinitializer
  %425 = select <8 x i1> %406, <8 x float> %native.exp, <8 x float> %.splat191
  %tile_snapshot.spill.load192 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %.state193 = load i64, ptr %.slot40, align 4
  %.splatinsert194 = insertelement <8 x i64> poison, i64 %.state193, i64 0
  %.splat195 = shufflevector <8 x i64> %.splatinsert194, <8 x i64> poison, <8 x i32> zeroinitializer
  %428 = mul <8 x i64> %.splat195, splat (i64 32)
  %429 = add <8 x i64> %427, %428
  %430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %426, 0
  %431 = insertvalue { <8 x ptr>, <8 x i64> } %430, <8 x i64> %429, 1
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %431, 1
  %434 = extractelement <8 x ptr> %432, i32 0
  %435 = extractelement <8 x i64> %433, i32 0
  %436 = sub i64 %435, 0
  %437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %438 = select i1 %437, i64 %436, i64 0
  %private.contiguous.address196 = getelementptr i8, ptr %434, i64 %438
  %private.contiguous.preserve197 = load <8 x float>, ptr %private.contiguous.address196, align 4
  %439 = select <8 x i1> %62, <8 x float> %425, <8 x float> %private.contiguous.preserve197
  store <8 x float> %439, ptr %private.contiguous.address196, align 4
  %.state198 = load i64, ptr %.slot40, align 4
  %440 = add i64 %.state198, 1
  store i64 %440, ptr %.slot40, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false178
  %tile_snapshot.spill.load199 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load199, 0
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load199, 1
  %.spill.load200 = load i64, ptr %.spill27, align 4
  %.splatinsert201 = insertelement <8 x i64> poison, i64 %.spill.load200, i64 0
  %.splat202 = shufflevector <8 x i64> %.splatinsert201, <8 x i64> poison, <8 x i32> zeroinitializer
  %443 = mul <8 x i64> %.splat202, splat (i64 32)
  %444 = add <8 x i64> %442, %443
  %445 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %441, 0
  %446 = insertvalue { <8 x ptr>, <8 x i64> } %445, <8 x i64> %444, 1
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %446, 1
  %449 = extractelement <8 x ptr> %447, i32 0
  %450 = extractelement <8 x i64> %448, i32 0
  %451 = sub i64 %450, 0
  %452 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %453 = select i1 %452, i64 %451, i64 0
  %private.contiguous.address203 = getelementptr i8, ptr %449, i64 %453
  %private.contiguous.load204 = load <8 x float>, ptr %private.contiguous.address203, align 4
  %454 = select <8 x i1> %62, <8 x float> %private.contiguous.load204, <8 x float> zeroinitializer
  %tile_snapshot.spill.load205 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %455 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load205, 0
  %456 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load205, 1
  %.spill.load206 = load i64, ptr %.spill28, align 4
  %.splatinsert207 = insertelement <8 x i64> poison, i64 %.spill.load206, i64 0
  %.splat208 = shufflevector <8 x i64> %.splatinsert207, <8 x i64> poison, <8 x i32> zeroinitializer
  %457 = mul <8 x i64> %.splat208, splat (i64 32)
  %458 = add <8 x i64> %456, %457
  %459 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %455, 0
  %460 = insertvalue { <8 x ptr>, <8 x i64> } %459, <8 x i64> %458, 1
  %461 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %460, 1
  %463 = extractelement <8 x ptr> %461, i32 0
  %464 = extractelement <8 x i64> %462, i32 0
  %465 = sub i64 %464, 0
  %466 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %467 = select i1 %466, i64 %465, i64 0
  %private.contiguous.address209 = getelementptr i8, ptr %463, i64 %467
  %private.contiguous.load210 = load <8 x float>, ptr %private.contiguous.address209, align 4
  %468 = select <8 x i1> %62, <8 x float> %private.contiguous.load210, <8 x float> zeroinitializer
  %tile_snapshot.spill.load211 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 0
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 1
  %.spill.load212 = load i64, ptr %.spill29, align 4
  %.splatinsert213 = insertelement <8 x i64> poison, i64 %.spill.load212, i64 0
  %.splat214 = shufflevector <8 x i64> %.splatinsert213, <8 x i64> poison, <8 x i32> zeroinitializer
  %471 = mul <8 x i64> %.splat214, splat (i64 32)
  %472 = add <8 x i64> %470, %471
  %473 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %469, 0
  %474 = insertvalue { <8 x ptr>, <8 x i64> } %473, <8 x i64> %472, 1
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %474, 1
  %477 = extractelement <8 x ptr> %475, i32 0
  %478 = extractelement <8 x i64> %476, i32 0
  %479 = sub i64 %478, 0
  %480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %481 = select i1 %480, i64 %479, i64 0
  %private.contiguous.address215 = getelementptr i8, ptr %477, i64 %481
  %private.contiguous.load216 = load <8 x float>, ptr %private.contiguous.address215, align 4
  %482 = select <8 x i1> %62, <8 x float> %private.contiguous.load216, <8 x float> zeroinitializer
  %tile_snapshot.spill.load217 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %483 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load217, 0
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load217, 1
  %.spill.load218 = load i64, ptr %.spill30, align 4
  %.splatinsert219 = insertelement <8 x i64> poison, i64 %.spill.load218, i64 0
  %.splat220 = shufflevector <8 x i64> %.splatinsert219, <8 x i64> poison, <8 x i32> zeroinitializer
  %485 = mul <8 x i64> %.splat220, splat (i64 32)
  %486 = add <8 x i64> %484, %485
  %487 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %483, 0
  %488 = insertvalue { <8 x ptr>, <8 x i64> } %487, <8 x i64> %486, 1
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %488, 1
  %491 = extractelement <8 x ptr> %489, i32 0
  %492 = extractelement <8 x i64> %490, i32 0
  %493 = sub i64 %492, 0
  %494 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %495 = select i1 %494, i64 %493, i64 0
  %private.contiguous.address221 = getelementptr i8, ptr %491, i64 %495
  %private.contiguous.load222 = load <8 x float>, ptr %private.contiguous.address221, align 4
  %496 = select <8 x i1> %62, <8 x float> %private.contiguous.load222, <8 x float> zeroinitializer
  store i64 4, ptr %.slot41, align 4
  %497 = load <8 x float>, ptr %.slot42, align 32
  %498 = select <8 x i1> %62, <8 x float> %454, <8 x float> %497
  store <8 x float> %498, ptr %.slot42, align 32
  %499 = load <8 x float>, ptr %.slot43, align 32
  %500 = select <8 x i1> %62, <8 x float> %468, <8 x float> %499
  store <8 x float> %500, ptr %.slot43, align 32
  %501 = load <8 x float>, ptr %.slot44, align 32
  %502 = select <8 x i1> %62, <8 x float> %482, <8 x float> %501
  store <8 x float> %502, ptr %.slot44, align 32
  %503 = load <8 x float>, ptr %.slot45, align 32
  %504 = select <8 x i1> %62, <8 x float> %496, <8 x float> %503
  store <8 x float> %504, ptr %.slot45, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state223 = load i64, ptr %.slot41, align 4
  %505 = icmp slt i64 %.state223, 4096
  br i1 %505, label %direct.true224, label %direct.false225

direct.schedule.20:                               ; preds = %direct.true224
  %.state226 = load i64, ptr %.slot41, align 4
  %506 = add i64 %.state226, 0
  %507 = sdiv i64 %506, 1
  %.spill.load227 = load i64, ptr %.spill26, align 4
  %508 = add i64 %.spill.load227, %507
  %tile_snapshot.spill.load228 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load228, 0
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load228, 1
  %.splatinsert229 = insertelement <8 x i64> poison, i64 %508, i64 0
  %.splat230 = shufflevector <8 x i64> %.splatinsert229, <8 x i64> poison, <8 x i32> zeroinitializer
  %511 = mul <8 x i64> %.splat230, splat (i64 32)
  %512 = add <8 x i64> %510, %511
  %513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %509, 0
  %514 = insertvalue { <8 x ptr>, <8 x i64> } %513, <8 x i64> %512, 1
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %514, 1
  %517 = extractelement <8 x ptr> %515, i32 0
  %518 = extractelement <8 x i64> %516, i32 0
  %519 = sub i64 %518, 0
  %520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %521 = select i1 %520, i64 %519, i64 0
  %private.contiguous.address231 = getelementptr i8, ptr %517, i64 %521
  %private.contiguous.load232 = load <8 x float>, ptr %private.contiguous.address231, align 4
  %522 = select <8 x i1> %62, <8 x float> %private.contiguous.load232, <8 x float> zeroinitializer
  %.state233 = load <8 x float>, ptr %.slot42, align 32
  %523 = fadd <8 x float> %.state233, %522
  %.state234 = load i64, ptr %.slot41, align 4
  %524 = add i64 %.state234, 1
  %525 = sdiv i64 %524, 1
  %.spill.load235 = load i64, ptr %.spill26, align 4
  %526 = add i64 %.spill.load235, %525
  %tile_snapshot.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %527 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 0
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 1
  %.splatinsert237 = insertelement <8 x i64> poison, i64 %526, i64 0
  %.splat238 = shufflevector <8 x i64> %.splatinsert237, <8 x i64> poison, <8 x i32> zeroinitializer
  %529 = mul <8 x i64> %.splat238, splat (i64 32)
  %530 = add <8 x i64> %528, %529
  %531 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %527, 0
  %532 = insertvalue { <8 x ptr>, <8 x i64> } %531, <8 x i64> %530, 1
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %532, 1
  %535 = extractelement <8 x ptr> %533, i32 0
  %536 = extractelement <8 x i64> %534, i32 0
  %537 = sub i64 %536, 0
  %538 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %539 = select i1 %538, i64 %537, i64 0
  %private.contiguous.address239 = getelementptr i8, ptr %535, i64 %539
  %private.contiguous.load240 = load <8 x float>, ptr %private.contiguous.address239, align 4
  %540 = select <8 x i1> %62, <8 x float> %private.contiguous.load240, <8 x float> zeroinitializer
  %.state241 = load <8 x float>, ptr %.slot43, align 32
  %541 = fadd <8 x float> %.state241, %540
  %.state242 = load i64, ptr %.slot41, align 4
  %542 = add i64 %.state242, 2
  %543 = sdiv i64 %542, 1
  %.spill.load243 = load i64, ptr %.spill26, align 4
  %544 = add i64 %.spill.load243, %543
  %tile_snapshot.spill.load244 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 0
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 1
  %.splatinsert245 = insertelement <8 x i64> poison, i64 %544, i64 0
  %.splat246 = shufflevector <8 x i64> %.splatinsert245, <8 x i64> poison, <8 x i32> zeroinitializer
  %547 = mul <8 x i64> %.splat246, splat (i64 32)
  %548 = add <8 x i64> %546, %547
  %549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %545, 0
  %550 = insertvalue { <8 x ptr>, <8 x i64> } %549, <8 x i64> %548, 1
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %550, 1
  %553 = extractelement <8 x ptr> %551, i32 0
  %554 = extractelement <8 x i64> %552, i32 0
  %555 = sub i64 %554, 0
  %556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %557 = select i1 %556, i64 %555, i64 0
  %private.contiguous.address247 = getelementptr i8, ptr %553, i64 %557
  %private.contiguous.load248 = load <8 x float>, ptr %private.contiguous.address247, align 4
  %558 = select <8 x i1> %62, <8 x float> %private.contiguous.load248, <8 x float> zeroinitializer
  %.state249 = load <8 x float>, ptr %.slot44, align 32
  %559 = fadd <8 x float> %.state249, %558
  %.state250 = load i64, ptr %.slot41, align 4
  %560 = add i64 %.state250, 3
  %561 = sdiv i64 %560, 1
  %.spill.load251 = load i64, ptr %.spill26, align 4
  %562 = add i64 %.spill.load251, %561
  %tile_snapshot.spill.load252 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 0
  %564 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 1
  %.splatinsert253 = insertelement <8 x i64> poison, i64 %562, i64 0
  %.splat254 = shufflevector <8 x i64> %.splatinsert253, <8 x i64> poison, <8 x i32> zeroinitializer
  %565 = mul <8 x i64> %.splat254, splat (i64 32)
  %566 = add <8 x i64> %564, %565
  %567 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %563, 0
  %568 = insertvalue { <8 x ptr>, <8 x i64> } %567, <8 x i64> %566, 1
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %568, 1
  %571 = extractelement <8 x ptr> %569, i32 0
  %572 = extractelement <8 x i64> %570, i32 0
  %573 = sub i64 %572, 0
  %574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %575 = select i1 %574, i64 %573, i64 0
  %private.contiguous.address255 = getelementptr i8, ptr %571, i64 %575
  %private.contiguous.load256 = load <8 x float>, ptr %private.contiguous.address255, align 4
  %576 = select <8 x i1> %62, <8 x float> %private.contiguous.load256, <8 x float> zeroinitializer
  %.state257 = load <8 x float>, ptr %.slot45, align 32
  %577 = fadd <8 x float> %.state257, %576
  %.state258 = load i64, ptr %.slot41, align 4
  %578 = add i64 %.state258, 4
  store i64 %578, ptr %.slot41, align 4
  %579 = load <8 x float>, ptr %.slot42, align 32
  %580 = select <8 x i1> %62, <8 x float> %523, <8 x float> %579
  store <8 x float> %580, ptr %.slot42, align 32
  %581 = load <8 x float>, ptr %.slot43, align 32
  %582 = select <8 x i1> %62, <8 x float> %541, <8 x float> %581
  store <8 x float> %582, ptr %.slot43, align 32
  %583 = load <8 x float>, ptr %.slot44, align 32
  %584 = select <8 x i1> %62, <8 x float> %559, <8 x float> %583
  store <8 x float> %584, ptr %.slot44, align 32
  %585 = load <8 x float>, ptr %.slot45, align 32
  %586 = select <8 x i1> %62, <8 x float> %577, <8 x float> %585
  store <8 x float> %586, ptr %.slot45, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false225
  %tile_snapshot.spill.load259 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %587 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 0
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 1
  %.spill.load260 = load i64, ptr %.spill36, align 4
  %.splatinsert261 = insertelement <8 x i64> poison, i64 %.spill.load260, i64 0
  %.splat262 = shufflevector <8 x i64> %.splatinsert261, <8 x i64> poison, <8 x i32> zeroinitializer
  %589 = mul <8 x i64> %.splat262, splat (i64 32)
  %590 = add <8 x i64> %588, %589
  %591 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %587, 0
  %592 = insertvalue { <8 x ptr>, <8 x i64> } %591, <8 x i64> %590, 1
  %593 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %594 = extractvalue { <8 x ptr>, <8 x i64> } %592, 1
  %595 = extractelement <8 x ptr> %593, i32 0
  %596 = extractelement <8 x i64> %594, i32 0
  %597 = sub i64 %596, 0
  %598 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %599 = select i1 %598, i64 %597, i64 0
  %private.contiguous.address263 = getelementptr i8, ptr %595, i64 %599
  %private.contiguous.load264 = load <8 x float>, ptr %private.contiguous.address263, align 4
  %600 = select <8 x i1> %62, <8 x float> %private.contiguous.load264, <8 x float> zeroinitializer
  %.state265 = load <8 x float>, ptr %.slot42, align 32
  %601 = fadd <8 x float> %.state265, %600
  %.spill.load266 = load float, ptr %.spill38, align 4
  %.splatinsert267 = insertelement <8 x float> poison, float %.spill.load266, i64 0
  %.splat268 = shufflevector <8 x float> %.splatinsert267, <8 x float> poison, <8 x i32> zeroinitializer
  %602 = fadd <8 x float> %.splat268, %601
  %.state269 = load <8 x float>, ptr %.slot43, align 32
  %603 = fadd <8 x float> %602, %.state269
  %.state270 = load <8 x float>, ptr %.slot44, align 32
  %604 = fadd <8 x float> %603, %.state270
  %.state271 = load <8 x float>, ptr %.slot45, align 32
  %605 = fadd <8 x float> %604, %.state271
  %606 = load <8 x float>, ptr %.spill46, align 32
  %607 = select <8 x i1> %62, <8 x float> %605, <8 x float> %606
  store <8 x float> %607, ptr %.spill46, align 32
  store i64 0, ptr %.slot47, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state272 = load i64, ptr %.slot47, align 4
  %608 = icmp slt i64 %.state272, 4097
  br i1 %608, label %direct.true273, label %direct.false274

direct.schedule.23:                               ; preds = %direct.true273
  %.spill.load275 = load <8 x i64>, ptr %.spill, align 64
  %609 = add <8 x i64> %.spill.load275, zeroinitializer
  %610 = add <8 x i64> zeroinitializer, %609
  %.state276 = load i64, ptr %.slot47, align 4
  %611 = add i64 0, %.state276
  %612 = mul <8 x i64> %610, splat (i64 4097)
  %.splatinsert277 = insertelement <8 x i64> poison, i64 %611, i64 0
  %.splat278 = shufflevector <8 x i64> %.splatinsert277, <8 x i64> poison, <8 x i32> zeroinitializer
  %613 = add <8 x i64> %612, %.splat278
  %.state279 = load i64, ptr %.slot47, align 4
  %614 = add i64 0, %.state279
  %tile_snapshot.spill.load280 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %.splatinsert281 = insertelement <8 x i64> poison, i64 %614, i64 0
  %.splat282 = shufflevector <8 x i64> %.splatinsert281, <8 x i64> poison, <8 x i32> zeroinitializer
  %617 = mul <8 x i64> %.splat282, splat (i64 32)
  %618 = add <8 x i64> %616, %617
  %619 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %615, 0
  %620 = insertvalue { <8 x ptr>, <8 x i64> } %619, <8 x i64> %618, 1
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %620, 1
  %623 = extractelement <8 x ptr> %621, i32 0
  %624 = extractelement <8 x i64> %622, i32 0
  %625 = sub i64 %624, 0
  %626 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %627 = select i1 %626, i64 %625, i64 0
  %private.contiguous.address283 = getelementptr i8, ptr %623, i64 %627
  %private.contiguous.load284 = load <8 x float>, ptr %private.contiguous.address283, align 4
  %628 = select <8 x i1> %62, <8 x float> %private.contiguous.load284, <8 x float> zeroinitializer
  %.spill.load285 = load <8 x float>, ptr %.spill46, align 32
  %629 = fdiv <8 x float> %628, %.spill.load285
  %630 = extractvalue { ptr, i64 } %38, 0
  %631 = mul <8 x i64> %613, splat (i64 4)
  %632 = getelementptr i8, ptr %630, <8 x i64> %631
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %629, <8 x ptr> %632, i32 1, <8 x i1> %62)
  %.state286 = load i64, ptr %.slot47, align 4
  %633 = add i64 %.state286, 1
  store i64 %633, ptr %.slot47, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false274
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true66:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false67:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true80:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false81:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true94:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false95:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true128:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false129:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true177:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false178:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true224:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false225:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true273:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false274:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, i32 immarg, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x i8>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #0

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #3 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 131104
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 393312
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4097, i64 8194, i64 12291, i64 16388, i64 20485, i64 24582, i64 28679>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 426088
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 557192
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %.spill19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill19, align 64
  %tile_snapshot.spill20 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill20, align 64
  %.slot21 = alloca i64, align 8
  store i64 0, ptr %.slot21, align 4
  %.spill22 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill22, align 4
  %tile_snapshot.spill23 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill23, align 64
  %.slot24 = alloca i64, align 8
  store i64 0, ptr %.slot24, align 4
  %.spill25 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill25, align 4
  %.spill26 = alloca i64, align 8
  store i64 0, ptr %.spill26, align 4
  %.spill27 = alloca i64, align 8
  store i64 0, ptr %.spill27, align 4
  %.spill28 = alloca i64, align 8
  store i64 0, ptr %.spill28, align 4
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca i64, align 8
  store i64 0, ptr %.spill30, align 4
  %.slot31 = alloca i64, align 8
  store i64 0, ptr %.slot31, align 4
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.spill36 = alloca i64, align 8
  store i64 0, ptr %.spill36, align 4
  %.spill37 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill37, align 32
  %.spill38 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill38, align 4
  %tile_snapshot.spill39 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill39, align 64
  %.slot40 = alloca i64, align 8
  store i64 0, ptr %.slot40, align 4
  %.slot41 = alloca i64, align 8
  store i64 0, ptr %.slot41, align 4
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.spill46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill46, align 32
  %.slot47 = alloca i64, align 8
  store i64 0, ptr %.slot47, align 4
  %15 = getelementptr i8, ptr %argument_buffer, i64 0
  %16 = load ptr, ptr %15, align 16
  %17 = getelementptr i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  %21 = getelementptr i8, ptr %argument_buffer, i64 16
  %22 = load ptr, ptr %21, align 16
  %23 = getelementptr i8, ptr %21, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = insertvalue { ptr, i64 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i64 } %25, i64 %24, 1
  %27 = getelementptr i8, ptr %argument_buffer, i64 32
  %28 = load ptr, ptr %27, align 16
  %29 = getelementptr i8, ptr %27, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { ptr, i64 } poison, ptr %28, 0
  %32 = insertvalue { ptr, i64 } %31, i64 %30, 1
  %33 = getelementptr i8, ptr %argument_buffer, i64 48
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = load i32, ptr %launch_config, align 4
  %40 = getelementptr i8, ptr %launch_config, i64 12
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr i8, ptr %launch_config, i64 4
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %launch_config, i64 16
  %45 = load i32, ptr %44, align 4
  %46 = getelementptr i8, ptr %launch_config, i64 8
  %47 = load i32, ptr %46, align 4
  %48 = getelementptr i8, ptr %launch_config, i64 20
  %49 = load i32, ptr %48, align 4
  %50 = getelementptr i8, ptr %launch_config, i64 36
  %51 = load i32, ptr %50, align 4
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %51, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %52 = add <8 x i32> %.splat49, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %53 = mul i32 %39, 32
  %.splatinsert50 = insertelement <8 x i32> poison, i32 %53, i64 0
  %.splat51 = shufflevector <8 x i32> %.splatinsert50, <8 x i32> poison, <8 x i32> zeroinitializer
  %54 = add <8 x i32> %.splat51, %52
  %55 = mul i32 %43, 1
  %.splatinsert52 = insertelement <8 x i32> poison, i32 %55, i64 0
  %.splat53 = shufflevector <8 x i32> %.splatinsert52, <8 x i32> poison, <8 x i32> zeroinitializer
  %56 = add <8 x i32> %.splat53, zeroinitializer
  %57 = mul i32 %47, 1
  %.splatinsert54 = insertelement <8 x i32> poison, i32 %57, i64 0
  %.splat55 = shufflevector <8 x i32> %.splatinsert54, <8 x i32> poison, <8 x i32> zeroinitializer
  %58 = add <8 x i32> %.splat55, zeroinitializer
  %59 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %54, 0
  %60 = insertvalue [3 x <8 x i32>] %59, <8 x i32> %56, 1
  %61 = insertvalue [3 x <8 x i32>] %60, <8 x i32> %58, 2
  %.splatinsert56 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat57 = shufflevector <8 x i32> %.splatinsert56, <8 x i32> poison, <8 x i32> zeroinitializer
  %62 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat57
  %63 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  br i1 %63, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %64 = extractvalue [3 x <8 x i32>] %61, 0
  %65 = zext <8 x i32> %64 to <8 x i64>
  %66 = select <8 x i1> %62, <8 x i64> %65, <8 x i64> zeroinitializer
  %67 = select <8 x i1> %62, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %68 = sdiv <8 x i64> %66, %67
  %69 = load <8 x i64>, ptr %.spill, align 64
  %70 = select <8 x i1> %62, <8 x i64> %68, <8 x i64> %69
  store <8 x i64> %70, ptr %.spill, align 64
  %71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %71, 0
  %74 = select <8 x i1> %62, <8 x ptr> %72, <8 x ptr> %73
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %71, 1
  %77 = select <8 x i1> %62, <8 x i64> %75, <8 x i64> %76
  %78 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %74, 0
  %79 = insertvalue { <8 x ptr>, <8 x i64> } %78, <8 x i64> %77, 1
  store { <8 x ptr>, <8 x i64> } %79, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %80 = icmp slt i64 %.state, 4097
  br i1 %80, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.spill.load, zeroinitializer
  %82 = add <8 x i64> zeroinitializer, %81
  %.state58 = load i64, ptr %.slot, align 4
  %83 = add i64 0, %.state58
  %84 = mul <8 x i64> %82, splat (i64 4097)
  %.splatinsert59 = insertelement <8 x i64> poison, i64 %83, i64 0
  %.splat60 = shufflevector <8 x i64> %.splatinsert59, <8 x i64> poison, <8 x i32> zeroinitializer
  %85 = add <8 x i64> %84, %.splat60
  %86 = extractvalue { ptr, i64 } %20, 0
  %87 = mul <8 x i64> %85, splat (i64 4)
  %88 = getelementptr i8, ptr %86, <8 x i64> %87
  %89 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %88, i32 1, <8 x i1> %62, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state61 = load i64, ptr %.slot, align 4
  %.splatinsert62 = insertelement <8 x i64> poison, i64 %.state61, i64 0
  %.splat63 = shufflevector <8 x i64> %.splatinsert62, <8 x i64> poison, <8 x i32> zeroinitializer
  %92 = mul <8 x i64> %.splat63, splat (i64 32)
  %93 = add <8 x i64> %91, %92
  %94 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %90, 0
  %95 = insertvalue { <8 x ptr>, <8 x i64> } %94, <8 x i64> %93, 1
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %95, 1
  %98 = extractelement <8 x ptr> %96, i32 0
  %99 = extractelement <8 x i64> %97, i32 0
  %100 = sub i64 %99, 0
  %101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %102 = select i1 %101, i64 %100, i64 0
  %private.contiguous.address = getelementptr i8, ptr %98, i64 %102
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %103 = select <8 x i1> %62, <8 x float> %89, <8 x float> %private.contiguous.preserve
  store <8 x float> %103, ptr %private.contiguous.address, align 4
  %.state64 = load i64, ptr %.slot, align 4
  %104 = add i64 %.state64, 1
  store i64 %104, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %105 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %105, 0
  %108 = select <8 x i1> %62, <8 x ptr> %106, <8 x ptr> %107
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %105, 1
  %111 = select <8 x i1> %62, <8 x i64> %109, <8 x i64> %110
  %112 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %108, 0
  %113 = insertvalue { <8 x ptr>, <8 x i64> } %112, <8 x i64> %111, 1
  store { <8 x ptr>, <8 x i64> } %113, ptr %tile_snapshot.spill17, align 64
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state65 = load i64, ptr %.slot18, align 4
  %114 = icmp slt i64 %.state65, 4097
  br i1 %114, label %direct.true66, label %direct.false67

direct.schedule.5:                                ; preds = %direct.true66
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %.state69 = load i64, ptr %.slot18, align 4
  %.splatinsert70 = insertelement <8 x i64> poison, i64 %.state69, i64 0
  %.splat71 = shufflevector <8 x i64> %.splatinsert70, <8 x i64> poison, <8 x i32> zeroinitializer
  %117 = mul <8 x i64> %.splat71, splat (i64 64)
  %118 = add <8 x i64> %116, %117
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %.state72 = load i64, ptr %.slot18, align 4
  %.splatinsert73 = insertelement <8 x i64> poison, i64 %.state72, i64 0
  %.splat74 = shufflevector <8 x i64> %.splatinsert73, <8 x i64> poison, <8 x i32> zeroinitializer
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address75 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve76 = load <8 x i64>, ptr %private.contiguous.address75, align 8
  %128 = select <8 x i1> %62, <8 x i64> %.splat74, <8 x i64> %private.contiguous.preserve76
  store <8 x i64> %128, ptr %private.contiguous.address75, align 8
  %.state77 = load i64, ptr %.slot18, align 4
  %129 = add i64 %.state77, 1
  store i64 %129, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false67
  %.spill.load78 = load <8 x i64>, ptr %.spill, align 64
  %130 = select <8 x i1> %62, <8 x i64> %.spill.load78, <8 x i64> zeroinitializer
  %131 = select <8 x i1> %62, <8 x i64> splat (i64 4097), <8 x i64> splat (i64 1)
  %132 = srem <8 x i64> %130, %131
  %133 = load <8 x i64>, ptr %.spill19, align 64
  %134 = select <8 x i1> %62, <8 x i64> %132, <8 x i64> %133
  store <8 x i64> %134, ptr %.spill19, align 64
  %135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %135, 0
  %138 = select <8 x i1> %62, <8 x ptr> %136, <8 x ptr> %137
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %135, 1
  %141 = select <8 x i1> %62, <8 x i64> %139, <8 x i64> %140
  %142 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %138, 0
  %143 = insertvalue { <8 x ptr>, <8 x i64> } %142, <8 x i64> %141, 1
  store { <8 x ptr>, <8 x i64> } %143, ptr %tile_snapshot.spill20, align 64
  store i64 0, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state79 = load i64, ptr %.slot21, align 4
  %144 = icmp slt i64 %.state79, 4097
  br i1 %144, label %direct.true80, label %direct.false81

direct.schedule.8:                                ; preds = %direct.true80
  %.state82 = load i64, ptr %.slot21, align 4
  %145 = add i64 0, %.state82
  %tile_snapshot.spill.load83 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 1
  %.splatinsert84 = insertelement <8 x i64> poison, i64 %145, i64 0
  %.splat85 = shufflevector <8 x i64> %.splatinsert84, <8 x i64> poison, <8 x i32> zeroinitializer
  %148 = mul <8 x i64> %.splat85, splat (i64 64)
  %149 = add <8 x i64> %147, %148
  %150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %146, 0
  %151 = insertvalue { <8 x ptr>, <8 x i64> } %150, <8 x i64> %149, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %154 = extractelement <8 x ptr> %152, i32 0
  %155 = extractelement <8 x i64> %153, i32 0
  %156 = sub i64 %155, 0
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %158 = select i1 %157, i64 %156, i64 0
  %private.contiguous.address86 = getelementptr i8, ptr %154, i64 %158
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address86, align 8
  %159 = select <8 x i1> %62, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load87 = load <8 x i64>, ptr %.spill19, align 64
  %160 = icmp sle <8 x i64> %159, %.spill.load87
  %tile_snapshot.spill.load88 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 1
  %.state89 = load i64, ptr %.slot21, align 4
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %.state89, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %163 = add <8 x i64> %162, %.splat91
  %164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %161, 0
  %165 = insertvalue { <8 x ptr>, <8 x i64> } %164, <8 x i64> %163, 1
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %168 = getelementptr i8, <8 x ptr> %166, <8 x i64> %167
  %169 = zext <8 x i1> %160 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %169, <8 x ptr> %168, i32 1, <8 x i1> %62)
  %.state92 = load i64, ptr %.slot21, align 4
  %170 = add i64 %.state92, 1
  store i64 %170, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false81
  store float 0xC6293E5940000000, ptr %.spill22, align 4
  %171 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 0
  %174 = select <8 x i1> %62, <8 x ptr> %172, <8 x ptr> %173
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %177 = select <8 x i1> %62, <8 x i64> %175, <8 x i64> %176
  %178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %174, 0
  %179 = insertvalue { <8 x ptr>, <8 x i64> } %178, <8 x i64> %177, 1
  store { <8 x ptr>, <8 x i64> } %179, ptr %tile_snapshot.spill23, align 64
  store i64 0, ptr %.slot24, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state93 = load i64, ptr %.slot24, align 4
  %180 = icmp slt i64 %.state93, 4097
  br i1 %180, label %direct.true94, label %direct.false95

direct.schedule.11:                               ; preds = %direct.true94
  %.state96 = load i64, ptr %.slot24, align 4
  %181 = add i64 0, %.state96
  %tile_snapshot.spill.load97 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 1
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = add <8 x i64> %183, %.splat99
  %185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %182, 0
  %186 = insertvalue { <8 x ptr>, <8 x i64> } %185, <8 x i64> %184, 1
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %186, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %186, 1
  %189 = getelementptr i8, <8 x ptr> %187, <8 x i64> %188
  %190 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %189, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %191 = icmp ne <8 x i8> %190, zeroinitializer
  %tile_snapshot.spill.load100 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 1
  %.splatinsert101 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat102 = shufflevector <8 x i64> %.splatinsert101, <8 x i64> poison, <8 x i32> zeroinitializer
  %194 = mul <8 x i64> %.splat102, splat (i64 32)
  %195 = add <8 x i64> %193, %194
  %196 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %192, 0
  %197 = insertvalue { <8 x ptr>, <8 x i64> } %196, <8 x i64> %195, 1
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %197, 1
  %200 = extractelement <8 x ptr> %198, i32 0
  %201 = extractelement <8 x i64> %199, i32 0
  %202 = sub i64 %201, 0
  %203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %204 = select i1 %203, i64 %202, i64 0
  %private.contiguous.address103 = getelementptr i8, ptr %200, i64 %204
  %private.contiguous.load104 = load <8 x float>, ptr %private.contiguous.address103, align 4
  %205 = select <8 x i1> %62, <8 x float> %private.contiguous.load104, <8 x float> zeroinitializer
  %.spill.load105 = load float, ptr %.spill22, align 4
  %.splatinsert106 = insertelement <8 x float> poison, float %.spill.load105, i64 0
  %.splat107 = shufflevector <8 x float> %.splatinsert106, <8 x float> poison, <8 x i32> zeroinitializer
  %206 = select <8 x i1> %191, <8 x float> %205, <8 x float> %.splat107
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %.state109 = load i64, ptr %.slot24, align 4
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %.state109, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %209 = mul <8 x i64> %.splat111, splat (i64 32)
  %210 = add <8 x i64> %208, %209
  %211 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %207, 0
  %212 = insertvalue { <8 x ptr>, <8 x i64> } %211, <8 x i64> %210, 1
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %212, 1
  %215 = extractelement <8 x ptr> %213, i32 0
  %216 = extractelement <8 x i64> %214, i32 0
  %217 = sub i64 %216, 0
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %219 = select i1 %218, i64 %217, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %215, i64 %219
  %private.contiguous.preserve113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %220 = select <8 x i1> %62, <8 x float> %206, <8 x float> %private.contiguous.preserve113
  store <8 x float> %220, ptr %private.contiguous.address112, align 4
  %.state114 = load i64, ptr %.slot24, align 4
  %221 = add i64 %.state114, 1
  store i64 %221, ptr %.slot24, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false95
  store float 0xFFF0000000000000, ptr %.spill25, align 4
  store i64 0, ptr %.spill26, align 4
  store i64 0, ptr %.spill27, align 4
  %tile_snapshot.spill.load115 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 1
  %224 = add <8 x i64> %223, zeroinitializer
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = extractelement <8 x ptr> %227, i32 0
  %230 = extractelement <8 x i64> %228, i32 0
  %231 = sub i64 %230, 0
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %233 = select i1 %232, i64 %231, i64 0
  %private.contiguous.address116 = getelementptr i8, ptr %229, i64 %233
  %private.contiguous.load117 = load <8 x float>, ptr %private.contiguous.address116, align 4
  %234 = select <8 x i1> %62, <8 x float> %private.contiguous.load117, <8 x float> zeroinitializer
  store i64 1, ptr %.spill28, align 4
  %tile_snapshot.spill.load118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 1
  %237 = add <8 x i64> %236, splat (i64 32)
  %238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %235, 0
  %239 = insertvalue { <8 x ptr>, <8 x i64> } %238, <8 x i64> %237, 1
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %239, 1
  %242 = extractelement <8 x ptr> %240, i32 0
  %243 = extractelement <8 x i64> %241, i32 0
  %244 = sub i64 %243, 0
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %246 = select i1 %245, i64 %244, i64 0
  %private.contiguous.address119 = getelementptr i8, ptr %242, i64 %246
  %private.contiguous.load120 = load <8 x float>, ptr %private.contiguous.address119, align 4
  %247 = select <8 x i1> %62, <8 x float> %private.contiguous.load120, <8 x float> zeroinitializer
  store i64 2, ptr %.spill29, align 4
  %tile_snapshot.spill.load121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 1
  %250 = add <8 x i64> %249, splat (i64 64)
  %251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %252 = insertvalue { <8 x ptr>, <8 x i64> } %251, <8 x i64> %250, 1
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %255 = extractelement <8 x ptr> %253, i32 0
  %256 = extractelement <8 x i64> %254, i32 0
  %257 = sub i64 %256, 0
  %258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %259 = select i1 %258, i64 %257, i64 0
  %private.contiguous.address122 = getelementptr i8, ptr %255, i64 %259
  %private.contiguous.load123 = load <8 x float>, ptr %private.contiguous.address122, align 4
  %260 = select <8 x i1> %62, <8 x float> %private.contiguous.load123, <8 x float> zeroinitializer
  store i64 3, ptr %.spill30, align 4
  %tile_snapshot.spill.load124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 1
  %263 = add <8 x i64> %262, splat (i64 96)
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = extractelement <8 x ptr> %266, i32 0
  %269 = extractelement <8 x i64> %267, i32 0
  %270 = sub i64 %269, 0
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %272 = select i1 %271, i64 %270, i64 0
  %private.contiguous.address125 = getelementptr i8, ptr %268, i64 %272
  %private.contiguous.load126 = load <8 x float>, ptr %private.contiguous.address125, align 4
  %273 = select <8 x i1> %62, <8 x float> %private.contiguous.load126, <8 x float> zeroinitializer
  store i64 4, ptr %.slot31, align 4
  %274 = load <8 x float>, ptr %.slot32, align 32
  %275 = select <8 x i1> %62, <8 x float> %234, <8 x float> %274
  store <8 x float> %275, ptr %.slot32, align 32
  %276 = load <8 x float>, ptr %.slot33, align 32
  %277 = select <8 x i1> %62, <8 x float> %247, <8 x float> %276
  store <8 x float> %277, ptr %.slot33, align 32
  %278 = load <8 x float>, ptr %.slot34, align 32
  %279 = select <8 x i1> %62, <8 x float> %260, <8 x float> %278
  store <8 x float> %279, ptr %.slot34, align 32
  %280 = load <8 x float>, ptr %.slot35, align 32
  %281 = select <8 x i1> %62, <8 x float> %273, <8 x float> %280
  store <8 x float> %281, ptr %.slot35, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state127 = load i64, ptr %.slot31, align 4
  %282 = icmp slt i64 %.state127, 4096
  br i1 %282, label %direct.true128, label %direct.false129

direct.schedule.14:                               ; preds = %direct.true128
  %.state130 = load i64, ptr %.slot31, align 4
  %283 = add i64 %.state130, 0
  %284 = sdiv i64 %283, 1
  %.spill.load131 = load i64, ptr %.spill26, align 4
  %285 = add i64 %.spill.load131, %284
  %tile_snapshot.spill.load132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 1
  %.splatinsert133 = insertelement <8 x i64> poison, i64 %285, i64 0
  %.splat134 = shufflevector <8 x i64> %.splatinsert133, <8 x i64> poison, <8 x i32> zeroinitializer
  %288 = mul <8 x i64> %.splat134, splat (i64 32)
  %289 = add <8 x i64> %287, %288
  %290 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %286, 0
  %291 = insertvalue { <8 x ptr>, <8 x i64> } %290, <8 x i64> %289, 1
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %291, 1
  %294 = extractelement <8 x ptr> %292, i32 0
  %295 = extractelement <8 x i64> %293, i32 0
  %296 = sub i64 %295, 0
  %297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %298 = select i1 %297, i64 %296, i64 0
  %private.contiguous.address135 = getelementptr i8, ptr %294, i64 %298
  %private.contiguous.load136 = load <8 x float>, ptr %private.contiguous.address135, align 4
  %299 = select <8 x i1> %62, <8 x float> %private.contiguous.load136, <8 x float> zeroinitializer
  %.state137 = load <8 x float>, ptr %.slot32, align 32
  %300 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state137, <8 x float> %299)
  %.state138 = load i64, ptr %.slot31, align 4
  %301 = add i64 %.state138, 1
  %302 = sdiv i64 %301, 1
  %.spill.load139 = load i64, ptr %.spill26, align 4
  %303 = add i64 %.spill.load139, %302
  %tile_snapshot.spill.load140 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 1
  %.splatinsert141 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat142 = shufflevector <8 x i64> %.splatinsert141, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat142, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address143 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load144 = load <8 x float>, ptr %private.contiguous.address143, align 4
  %317 = select <8 x i1> %62, <8 x float> %private.contiguous.load144, <8 x float> zeroinitializer
  %.state145 = load <8 x float>, ptr %.slot33, align 32
  %318 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state145, <8 x float> %317)
  %.state146 = load i64, ptr %.slot31, align 4
  %319 = add i64 %.state146, 2
  %320 = sdiv i64 %319, 1
  %.spill.load147 = load i64, ptr %.spill26, align 4
  %321 = add i64 %.spill.load147, %320
  %tile_snapshot.spill.load148 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load148, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load148, 1
  %.splatinsert149 = insertelement <8 x i64> poison, i64 %321, i64 0
  %.splat150 = shufflevector <8 x i64> %.splatinsert149, <8 x i64> poison, <8 x i32> zeroinitializer
  %324 = mul <8 x i64> %.splat150, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address151 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.load152 = load <8 x float>, ptr %private.contiguous.address151, align 4
  %335 = select <8 x i1> %62, <8 x float> %private.contiguous.load152, <8 x float> zeroinitializer
  %.state153 = load <8 x float>, ptr %.slot34, align 32
  %336 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state153, <8 x float> %335)
  %.state154 = load i64, ptr %.slot31, align 4
  %337 = add i64 %.state154, 3
  %338 = sdiv i64 %337, 1
  %.spill.load155 = load i64, ptr %.spill26, align 4
  %339 = add i64 %.spill.load155, %338
  %tile_snapshot.spill.load156 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 1
  %.splatinsert157 = insertelement <8 x i64> poison, i64 %339, i64 0
  %.splat158 = shufflevector <8 x i64> %.splatinsert157, <8 x i64> poison, <8 x i32> zeroinitializer
  %342 = mul <8 x i64> %.splat158, splat (i64 32)
  %343 = add <8 x i64> %341, %342
  %344 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %340, 0
  %345 = insertvalue { <8 x ptr>, <8 x i64> } %344, <8 x i64> %343, 1
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %345, 1
  %348 = extractelement <8 x ptr> %346, i32 0
  %349 = extractelement <8 x i64> %347, i32 0
  %350 = sub i64 %349, 0
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %352 = select i1 %351, i64 %350, i64 0
  %private.contiguous.address159 = getelementptr i8, ptr %348, i64 %352
  %private.contiguous.load160 = load <8 x float>, ptr %private.contiguous.address159, align 4
  %353 = select <8 x i1> %62, <8 x float> %private.contiguous.load160, <8 x float> zeroinitializer
  %.state161 = load <8 x float>, ptr %.slot35, align 32
  %354 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state161, <8 x float> %353)
  %.state162 = load i64, ptr %.slot31, align 4
  %355 = add i64 %.state162, 4
  store i64 %355, ptr %.slot31, align 4
  %356 = load <8 x float>, ptr %.slot32, align 32
  %357 = select <8 x i1> %62, <8 x float> %300, <8 x float> %356
  store <8 x float> %357, ptr %.slot32, align 32
  %358 = load <8 x float>, ptr %.slot33, align 32
  %359 = select <8 x i1> %62, <8 x float> %318, <8 x float> %358
  store <8 x float> %359, ptr %.slot33, align 32
  %360 = load <8 x float>, ptr %.slot34, align 32
  %361 = select <8 x i1> %62, <8 x float> %336, <8 x float> %360
  store <8 x float> %361, ptr %.slot34, align 32
  %362 = load <8 x float>, ptr %.slot35, align 32
  %363 = select <8 x i1> %62, <8 x float> %354, <8 x float> %362
  store <8 x float> %363, ptr %.slot35, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false129
  %.spill.load163 = load i64, ptr %.spill26, align 4
  %364 = add i64 %.spill.load163, 4096
  store i64 %364, ptr %.spill36, align 4
  %tile_snapshot.spill.load164 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %365 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load164, 0
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load164, 1
  %.splatinsert165 = insertelement <8 x i64> poison, i64 %364, i64 0
  %.splat166 = shufflevector <8 x i64> %.splatinsert165, <8 x i64> poison, <8 x i32> zeroinitializer
  %367 = mul <8 x i64> %.splat166, splat (i64 32)
  %368 = add <8 x i64> %366, %367
  %369 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %365, 0
  %370 = insertvalue { <8 x ptr>, <8 x i64> } %369, <8 x i64> %368, 1
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %370, 1
  %373 = extractelement <8 x ptr> %371, i32 0
  %374 = extractelement <8 x i64> %372, i32 0
  %375 = sub i64 %374, 0
  %376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %377 = select i1 %376, i64 %375, i64 0
  %private.contiguous.address167 = getelementptr i8, ptr %373, i64 %377
  %private.contiguous.load168 = load <8 x float>, ptr %private.contiguous.address167, align 4
  %378 = select <8 x i1> %62, <8 x float> %private.contiguous.load168, <8 x float> zeroinitializer
  %.state169 = load <8 x float>, ptr %.slot32, align 32
  %379 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state169, <8 x float> %378)
  %.spill.load170 = load float, ptr %.spill25, align 4
  %.splatinsert171 = insertelement <8 x float> poison, float %.spill.load170, i64 0
  %.splat172 = shufflevector <8 x float> %.splatinsert171, <8 x float> poison, <8 x i32> zeroinitializer
  %380 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.splat172, <8 x float> %379)
  %.state173 = load <8 x float>, ptr %.slot33, align 32
  %381 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %380, <8 x float> %.state173)
  %.state174 = load <8 x float>, ptr %.slot34, align 32
  %382 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %381, <8 x float> %.state174)
  %.state175 = load <8 x float>, ptr %.slot35, align 32
  %383 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %382, <8 x float> %.state175)
  %384 = load <8 x float>, ptr %.spill37, align 32
  %385 = select <8 x i1> %62, <8 x float> %383, <8 x float> %384
  store <8 x float> %385, ptr %.spill37, align 32
  store float 0.000000e+00, ptr %.spill38, align 4
  %386 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %386, 0
  %389 = select <8 x i1> %62, <8 x ptr> %387, <8 x ptr> %388
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %391 = extractvalue { <8 x ptr>, <8 x i64> } %386, 1
  %392 = select <8 x i1> %62, <8 x i64> %390, <8 x i64> %391
  %393 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %389, 0
  %394 = insertvalue { <8 x ptr>, <8 x i64> } %393, <8 x i64> %392, 1
  store { <8 x ptr>, <8 x i64> } %394, ptr %tile_snapshot.spill39, align 64
  store i64 0, ptr %.slot40, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state176 = load i64, ptr %.slot40, align 4
  %395 = icmp slt i64 %.state176, 4097
  br i1 %395, label %direct.true177, label %direct.false178

direct.schedule.17:                               ; preds = %direct.true177
  %.state179 = load i64, ptr %.slot40, align 4
  %396 = add i64 0, %.state179
  %tile_snapshot.spill.load180 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %397 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load180, 0
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load180, 1
  %.splatinsert181 = insertelement <8 x i64> poison, i64 %396, i64 0
  %.splat182 = shufflevector <8 x i64> %.splatinsert181, <8 x i64> poison, <8 x i32> zeroinitializer
  %399 = add <8 x i64> %398, %.splat182
  %400 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %397, 0
  %401 = insertvalue { <8 x ptr>, <8 x i64> } %400, <8 x i64> %399, 1
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %401, 0
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %401, 1
  %404 = getelementptr i8, <8 x ptr> %402, <8 x i64> %403
  %405 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %404, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %406 = icmp ne <8 x i8> %405, zeroinitializer
  %407 = add i64 0, %396
  %408 = add i64 0, %407
  %tile_snapshot.spill.load183 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load183, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load183, 1
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %408, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %411 = mul <8 x i64> %.splat185, splat (i64 32)
  %412 = add <8 x i64> %410, %411
  %413 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %409, 0
  %414 = insertvalue { <8 x ptr>, <8 x i64> } %413, <8 x i64> %412, 1
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %414, 1
  %417 = extractelement <8 x ptr> %415, i32 0
  %418 = extractelement <8 x i64> %416, i32 0
  %419 = sub i64 %418, 0
  %420 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %421 = select i1 %420, i64 %419, i64 0
  %private.contiguous.address186 = getelementptr i8, ptr %417, i64 %421
  %private.contiguous.load187 = load <8 x float>, ptr %private.contiguous.address186, align 4
  %422 = select <8 x i1> %62, <8 x float> %private.contiguous.load187, <8 x float> zeroinitializer
  %.spill.load188 = load <8 x float>, ptr %.spill37, align 32
  %423 = fsub <8 x float> %422, %.spill.load188
  %424 = select <8 x i1> %62, <8 x float> %423, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %424)
  %.spill.load189 = load float, ptr %.spill38, align 4
  %.splatinsert190 = insertelement <8 x float> poison, float %.spill.load189, i64 0
  %.splat191 = shufflevector <8 x float> %.splatinsert190, <8 x float> poison, <8 x i32> zeroinitializer
  %425 = select <8 x i1> %406, <8 x float> %native.exp, <8 x float> %.splat191
  %tile_snapshot.spill.load192 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %.state193 = load i64, ptr %.slot40, align 4
  %.splatinsert194 = insertelement <8 x i64> poison, i64 %.state193, i64 0
  %.splat195 = shufflevector <8 x i64> %.splatinsert194, <8 x i64> poison, <8 x i32> zeroinitializer
  %428 = mul <8 x i64> %.splat195, splat (i64 32)
  %429 = add <8 x i64> %427, %428
  %430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %426, 0
  %431 = insertvalue { <8 x ptr>, <8 x i64> } %430, <8 x i64> %429, 1
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %431, 1
  %434 = extractelement <8 x ptr> %432, i32 0
  %435 = extractelement <8 x i64> %433, i32 0
  %436 = sub i64 %435, 0
  %437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %438 = select i1 %437, i64 %436, i64 0
  %private.contiguous.address196 = getelementptr i8, ptr %434, i64 %438
  %private.contiguous.preserve197 = load <8 x float>, ptr %private.contiguous.address196, align 4
  %439 = select <8 x i1> %62, <8 x float> %425, <8 x float> %private.contiguous.preserve197
  store <8 x float> %439, ptr %private.contiguous.address196, align 4
  %.state198 = load i64, ptr %.slot40, align 4
  %440 = add i64 %.state198, 1
  store i64 %440, ptr %.slot40, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false178
  %tile_snapshot.spill.load199 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load199, 0
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load199, 1
  %.spill.load200 = load i64, ptr %.spill27, align 4
  %.splatinsert201 = insertelement <8 x i64> poison, i64 %.spill.load200, i64 0
  %.splat202 = shufflevector <8 x i64> %.splatinsert201, <8 x i64> poison, <8 x i32> zeroinitializer
  %443 = mul <8 x i64> %.splat202, splat (i64 32)
  %444 = add <8 x i64> %442, %443
  %445 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %441, 0
  %446 = insertvalue { <8 x ptr>, <8 x i64> } %445, <8 x i64> %444, 1
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %446, 1
  %449 = extractelement <8 x ptr> %447, i32 0
  %450 = extractelement <8 x i64> %448, i32 0
  %451 = sub i64 %450, 0
  %452 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %453 = select i1 %452, i64 %451, i64 0
  %private.contiguous.address203 = getelementptr i8, ptr %449, i64 %453
  %private.contiguous.load204 = load <8 x float>, ptr %private.contiguous.address203, align 4
  %454 = select <8 x i1> %62, <8 x float> %private.contiguous.load204, <8 x float> zeroinitializer
  %tile_snapshot.spill.load205 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %455 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load205, 0
  %456 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load205, 1
  %.spill.load206 = load i64, ptr %.spill28, align 4
  %.splatinsert207 = insertelement <8 x i64> poison, i64 %.spill.load206, i64 0
  %.splat208 = shufflevector <8 x i64> %.splatinsert207, <8 x i64> poison, <8 x i32> zeroinitializer
  %457 = mul <8 x i64> %.splat208, splat (i64 32)
  %458 = add <8 x i64> %456, %457
  %459 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %455, 0
  %460 = insertvalue { <8 x ptr>, <8 x i64> } %459, <8 x i64> %458, 1
  %461 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %460, 1
  %463 = extractelement <8 x ptr> %461, i32 0
  %464 = extractelement <8 x i64> %462, i32 0
  %465 = sub i64 %464, 0
  %466 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %467 = select i1 %466, i64 %465, i64 0
  %private.contiguous.address209 = getelementptr i8, ptr %463, i64 %467
  %private.contiguous.load210 = load <8 x float>, ptr %private.contiguous.address209, align 4
  %468 = select <8 x i1> %62, <8 x float> %private.contiguous.load210, <8 x float> zeroinitializer
  %tile_snapshot.spill.load211 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 0
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 1
  %.spill.load212 = load i64, ptr %.spill29, align 4
  %.splatinsert213 = insertelement <8 x i64> poison, i64 %.spill.load212, i64 0
  %.splat214 = shufflevector <8 x i64> %.splatinsert213, <8 x i64> poison, <8 x i32> zeroinitializer
  %471 = mul <8 x i64> %.splat214, splat (i64 32)
  %472 = add <8 x i64> %470, %471
  %473 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %469, 0
  %474 = insertvalue { <8 x ptr>, <8 x i64> } %473, <8 x i64> %472, 1
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %474, 1
  %477 = extractelement <8 x ptr> %475, i32 0
  %478 = extractelement <8 x i64> %476, i32 0
  %479 = sub i64 %478, 0
  %480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %481 = select i1 %480, i64 %479, i64 0
  %private.contiguous.address215 = getelementptr i8, ptr %477, i64 %481
  %private.contiguous.load216 = load <8 x float>, ptr %private.contiguous.address215, align 4
  %482 = select <8 x i1> %62, <8 x float> %private.contiguous.load216, <8 x float> zeroinitializer
  %tile_snapshot.spill.load217 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %483 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load217, 0
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load217, 1
  %.spill.load218 = load i64, ptr %.spill30, align 4
  %.splatinsert219 = insertelement <8 x i64> poison, i64 %.spill.load218, i64 0
  %.splat220 = shufflevector <8 x i64> %.splatinsert219, <8 x i64> poison, <8 x i32> zeroinitializer
  %485 = mul <8 x i64> %.splat220, splat (i64 32)
  %486 = add <8 x i64> %484, %485
  %487 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %483, 0
  %488 = insertvalue { <8 x ptr>, <8 x i64> } %487, <8 x i64> %486, 1
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %488, 1
  %491 = extractelement <8 x ptr> %489, i32 0
  %492 = extractelement <8 x i64> %490, i32 0
  %493 = sub i64 %492, 0
  %494 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %495 = select i1 %494, i64 %493, i64 0
  %private.contiguous.address221 = getelementptr i8, ptr %491, i64 %495
  %private.contiguous.load222 = load <8 x float>, ptr %private.contiguous.address221, align 4
  %496 = select <8 x i1> %62, <8 x float> %private.contiguous.load222, <8 x float> zeroinitializer
  store i64 4, ptr %.slot41, align 4
  %497 = load <8 x float>, ptr %.slot42, align 32
  %498 = select <8 x i1> %62, <8 x float> %454, <8 x float> %497
  store <8 x float> %498, ptr %.slot42, align 32
  %499 = load <8 x float>, ptr %.slot43, align 32
  %500 = select <8 x i1> %62, <8 x float> %468, <8 x float> %499
  store <8 x float> %500, ptr %.slot43, align 32
  %501 = load <8 x float>, ptr %.slot44, align 32
  %502 = select <8 x i1> %62, <8 x float> %482, <8 x float> %501
  store <8 x float> %502, ptr %.slot44, align 32
  %503 = load <8 x float>, ptr %.slot45, align 32
  %504 = select <8 x i1> %62, <8 x float> %496, <8 x float> %503
  store <8 x float> %504, ptr %.slot45, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state223 = load i64, ptr %.slot41, align 4
  %505 = icmp slt i64 %.state223, 4096
  br i1 %505, label %direct.true224, label %direct.false225

direct.schedule.20:                               ; preds = %direct.true224
  %.state226 = load i64, ptr %.slot41, align 4
  %506 = add i64 %.state226, 0
  %507 = sdiv i64 %506, 1
  %.spill.load227 = load i64, ptr %.spill26, align 4
  %508 = add i64 %.spill.load227, %507
  %tile_snapshot.spill.load228 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load228, 0
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load228, 1
  %.splatinsert229 = insertelement <8 x i64> poison, i64 %508, i64 0
  %.splat230 = shufflevector <8 x i64> %.splatinsert229, <8 x i64> poison, <8 x i32> zeroinitializer
  %511 = mul <8 x i64> %.splat230, splat (i64 32)
  %512 = add <8 x i64> %510, %511
  %513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %509, 0
  %514 = insertvalue { <8 x ptr>, <8 x i64> } %513, <8 x i64> %512, 1
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %514, 1
  %517 = extractelement <8 x ptr> %515, i32 0
  %518 = extractelement <8 x i64> %516, i32 0
  %519 = sub i64 %518, 0
  %520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %521 = select i1 %520, i64 %519, i64 0
  %private.contiguous.address231 = getelementptr i8, ptr %517, i64 %521
  %private.contiguous.load232 = load <8 x float>, ptr %private.contiguous.address231, align 4
  %522 = select <8 x i1> %62, <8 x float> %private.contiguous.load232, <8 x float> zeroinitializer
  %.state233 = load <8 x float>, ptr %.slot42, align 32
  %523 = fadd <8 x float> %.state233, %522
  %.state234 = load i64, ptr %.slot41, align 4
  %524 = add i64 %.state234, 1
  %525 = sdiv i64 %524, 1
  %.spill.load235 = load i64, ptr %.spill26, align 4
  %526 = add i64 %.spill.load235, %525
  %tile_snapshot.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %527 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 0
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 1
  %.splatinsert237 = insertelement <8 x i64> poison, i64 %526, i64 0
  %.splat238 = shufflevector <8 x i64> %.splatinsert237, <8 x i64> poison, <8 x i32> zeroinitializer
  %529 = mul <8 x i64> %.splat238, splat (i64 32)
  %530 = add <8 x i64> %528, %529
  %531 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %527, 0
  %532 = insertvalue { <8 x ptr>, <8 x i64> } %531, <8 x i64> %530, 1
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %532, 1
  %535 = extractelement <8 x ptr> %533, i32 0
  %536 = extractelement <8 x i64> %534, i32 0
  %537 = sub i64 %536, 0
  %538 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %539 = select i1 %538, i64 %537, i64 0
  %private.contiguous.address239 = getelementptr i8, ptr %535, i64 %539
  %private.contiguous.load240 = load <8 x float>, ptr %private.contiguous.address239, align 4
  %540 = select <8 x i1> %62, <8 x float> %private.contiguous.load240, <8 x float> zeroinitializer
  %.state241 = load <8 x float>, ptr %.slot43, align 32
  %541 = fadd <8 x float> %.state241, %540
  %.state242 = load i64, ptr %.slot41, align 4
  %542 = add i64 %.state242, 2
  %543 = sdiv i64 %542, 1
  %.spill.load243 = load i64, ptr %.spill26, align 4
  %544 = add i64 %.spill.load243, %543
  %tile_snapshot.spill.load244 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 0
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 1
  %.splatinsert245 = insertelement <8 x i64> poison, i64 %544, i64 0
  %.splat246 = shufflevector <8 x i64> %.splatinsert245, <8 x i64> poison, <8 x i32> zeroinitializer
  %547 = mul <8 x i64> %.splat246, splat (i64 32)
  %548 = add <8 x i64> %546, %547
  %549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %545, 0
  %550 = insertvalue { <8 x ptr>, <8 x i64> } %549, <8 x i64> %548, 1
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %550, 1
  %553 = extractelement <8 x ptr> %551, i32 0
  %554 = extractelement <8 x i64> %552, i32 0
  %555 = sub i64 %554, 0
  %556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %557 = select i1 %556, i64 %555, i64 0
  %private.contiguous.address247 = getelementptr i8, ptr %553, i64 %557
  %private.contiguous.load248 = load <8 x float>, ptr %private.contiguous.address247, align 4
  %558 = select <8 x i1> %62, <8 x float> %private.contiguous.load248, <8 x float> zeroinitializer
  %.state249 = load <8 x float>, ptr %.slot44, align 32
  %559 = fadd <8 x float> %.state249, %558
  %.state250 = load i64, ptr %.slot41, align 4
  %560 = add i64 %.state250, 3
  %561 = sdiv i64 %560, 1
  %.spill.load251 = load i64, ptr %.spill26, align 4
  %562 = add i64 %.spill.load251, %561
  %tile_snapshot.spill.load252 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 0
  %564 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 1
  %.splatinsert253 = insertelement <8 x i64> poison, i64 %562, i64 0
  %.splat254 = shufflevector <8 x i64> %.splatinsert253, <8 x i64> poison, <8 x i32> zeroinitializer
  %565 = mul <8 x i64> %.splat254, splat (i64 32)
  %566 = add <8 x i64> %564, %565
  %567 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %563, 0
  %568 = insertvalue { <8 x ptr>, <8 x i64> } %567, <8 x i64> %566, 1
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %568, 1
  %571 = extractelement <8 x ptr> %569, i32 0
  %572 = extractelement <8 x i64> %570, i32 0
  %573 = sub i64 %572, 0
  %574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %575 = select i1 %574, i64 %573, i64 0
  %private.contiguous.address255 = getelementptr i8, ptr %571, i64 %575
  %private.contiguous.load256 = load <8 x float>, ptr %private.contiguous.address255, align 4
  %576 = select <8 x i1> %62, <8 x float> %private.contiguous.load256, <8 x float> zeroinitializer
  %.state257 = load <8 x float>, ptr %.slot45, align 32
  %577 = fadd <8 x float> %.state257, %576
  %.state258 = load i64, ptr %.slot41, align 4
  %578 = add i64 %.state258, 4
  store i64 %578, ptr %.slot41, align 4
  %579 = load <8 x float>, ptr %.slot42, align 32
  %580 = select <8 x i1> %62, <8 x float> %523, <8 x float> %579
  store <8 x float> %580, ptr %.slot42, align 32
  %581 = load <8 x float>, ptr %.slot43, align 32
  %582 = select <8 x i1> %62, <8 x float> %541, <8 x float> %581
  store <8 x float> %582, ptr %.slot43, align 32
  %583 = load <8 x float>, ptr %.slot44, align 32
  %584 = select <8 x i1> %62, <8 x float> %559, <8 x float> %583
  store <8 x float> %584, ptr %.slot44, align 32
  %585 = load <8 x float>, ptr %.slot45, align 32
  %586 = select <8 x i1> %62, <8 x float> %577, <8 x float> %585
  store <8 x float> %586, ptr %.slot45, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false225
  %tile_snapshot.spill.load259 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %587 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 0
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 1
  %.spill.load260 = load i64, ptr %.spill36, align 4
  %.splatinsert261 = insertelement <8 x i64> poison, i64 %.spill.load260, i64 0
  %.splat262 = shufflevector <8 x i64> %.splatinsert261, <8 x i64> poison, <8 x i32> zeroinitializer
  %589 = mul <8 x i64> %.splat262, splat (i64 32)
  %590 = add <8 x i64> %588, %589
  %591 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %587, 0
  %592 = insertvalue { <8 x ptr>, <8 x i64> } %591, <8 x i64> %590, 1
  %593 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %594 = extractvalue { <8 x ptr>, <8 x i64> } %592, 1
  %595 = extractelement <8 x ptr> %593, i32 0
  %596 = extractelement <8 x i64> %594, i32 0
  %597 = sub i64 %596, 0
  %598 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %599 = select i1 %598, i64 %597, i64 0
  %private.contiguous.address263 = getelementptr i8, ptr %595, i64 %599
  %private.contiguous.load264 = load <8 x float>, ptr %private.contiguous.address263, align 4
  %600 = select <8 x i1> %62, <8 x float> %private.contiguous.load264, <8 x float> zeroinitializer
  %.state265 = load <8 x float>, ptr %.slot42, align 32
  %601 = fadd <8 x float> %.state265, %600
  %.spill.load266 = load float, ptr %.spill38, align 4
  %.splatinsert267 = insertelement <8 x float> poison, float %.spill.load266, i64 0
  %.splat268 = shufflevector <8 x float> %.splatinsert267, <8 x float> poison, <8 x i32> zeroinitializer
  %602 = fadd <8 x float> %.splat268, %601
  %.state269 = load <8 x float>, ptr %.slot43, align 32
  %603 = fadd <8 x float> %602, %.state269
  %.state270 = load <8 x float>, ptr %.slot44, align 32
  %604 = fadd <8 x float> %603, %.state270
  %.state271 = load <8 x float>, ptr %.slot45, align 32
  %605 = fadd <8 x float> %604, %.state271
  %606 = load <8 x float>, ptr %.spill46, align 32
  %607 = select <8 x i1> %62, <8 x float> %605, <8 x float> %606
  store <8 x float> %607, ptr %.spill46, align 32
  store i64 0, ptr %.slot47, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state272 = load i64, ptr %.slot47, align 4
  %608 = icmp slt i64 %.state272, 4097
  br i1 %608, label %direct.true273, label %direct.false274

direct.schedule.23:                               ; preds = %direct.true273
  %.spill.load275 = load <8 x i64>, ptr %.spill, align 64
  %609 = add <8 x i64> %.spill.load275, zeroinitializer
  %610 = add <8 x i64> zeroinitializer, %609
  %.state276 = load i64, ptr %.slot47, align 4
  %611 = add i64 0, %.state276
  %612 = mul <8 x i64> %610, splat (i64 4097)
  %.splatinsert277 = insertelement <8 x i64> poison, i64 %611, i64 0
  %.splat278 = shufflevector <8 x i64> %.splatinsert277, <8 x i64> poison, <8 x i32> zeroinitializer
  %613 = add <8 x i64> %612, %.splat278
  %.state279 = load i64, ptr %.slot47, align 4
  %614 = add i64 0, %.state279
  %tile_snapshot.spill.load280 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %.splatinsert281 = insertelement <8 x i64> poison, i64 %614, i64 0
  %.splat282 = shufflevector <8 x i64> %.splatinsert281, <8 x i64> poison, <8 x i32> zeroinitializer
  %617 = mul <8 x i64> %.splat282, splat (i64 32)
  %618 = add <8 x i64> %616, %617
  %619 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %615, 0
  %620 = insertvalue { <8 x ptr>, <8 x i64> } %619, <8 x i64> %618, 1
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %620, 1
  %623 = extractelement <8 x ptr> %621, i32 0
  %624 = extractelement <8 x i64> %622, i32 0
  %625 = sub i64 %624, 0
  %626 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %627 = select i1 %626, i64 %625, i64 0
  %private.contiguous.address283 = getelementptr i8, ptr %623, i64 %627
  %private.contiguous.load284 = load <8 x float>, ptr %private.contiguous.address283, align 4
  %628 = select <8 x i1> %62, <8 x float> %private.contiguous.load284, <8 x float> zeroinitializer
  %.spill.load285 = load <8 x float>, ptr %.spill46, align 32
  %629 = fdiv <8 x float> %628, %.spill.load285
  %630 = extractvalue { ptr, i64 } %38, 0
  %631 = mul <8 x i64> %613, splat (i64 4)
  %632 = getelementptr i8, ptr %630, <8 x i64> %631
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %629, <8 x ptr> %632, i32 1, <8 x i1> %62)
  %.state286 = load i64, ptr %.slot47, align 4
  %633 = add i64 %.state286, 1
  store i64 %633, ptr %.slot47, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false274
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true66:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false67:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true80:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false81:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true94:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false95:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true128:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false129:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true177:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false178:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true224:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false225:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true273:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false274:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

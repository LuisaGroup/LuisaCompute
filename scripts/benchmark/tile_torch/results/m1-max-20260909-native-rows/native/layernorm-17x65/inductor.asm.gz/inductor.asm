
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/layernorm-17x65/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0x120
     6b4:      	stp	d11, d10, [sp, #0xa0]
     6b8:      	stp	d9, d8, [sp, #0xb0]
     6bc:      	stp	x28, x27, [sp, #0xc0]
     6c0:      	stp	x26, x25, [sp, #0xd0]
     6c4:      	stp	x24, x23, [sp, #0xe0]
     6c8:      	stp	x22, x21, [sp, #0xf0]
     6cc:      	stp	x20, x19, [sp, #0x100]
     6d0:      	stp	x29, x30, [sp, #0x110]
     6d4:      	add	x29, sp, #0x110
     6d8:      	mov	x9, #0x0                ; =0
     6dc:      	str	wzr, [sp, #0x78]
     6e0:      	adrp	x12, 0x4000 <dyld_stub_binder+0x4000>
     6e4:      	ldr	x12, [x12, #0x98]
     6e8:      	add	x8, sp, #0x78
     6ec:      	str	x8, [x12]
     6f0:      	add	x10, x1, #0x80
     6f4:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     6f8:      	ldr	x8, [x8, #0x80]
     6fc:      	movi.2d	v0, #0000000000000000
     700:      	movi.2d	v1, #0000000000000000
     704:      	ldp	q2, q3, [x10, #-0x80]
     708:      	fadd.4s	v2, v2, v0
     70c:      	fadd.4s	v2, v2, v3
     710:      	ldp	q3, q4, [x10, #-0x60]
     714:      	fadd.4s	v2, v2, v3
     718:      	fadd.4s	v2, v2, v4
     71c:      	ldp	q3, q4, [x10, #-0x40]
     720:      	fadd.4s	v2, v2, v3
     724:      	fadd.4s	v2, v2, v4
     728:      	ldp	q3, q4, [x10, #-0x20]
     72c:      	fadd.4s	v2, v2, v3
     730:      	fadd.4s	v2, v2, v4
     734:      	ldp	q3, q4, [x10]
     738:      	fadd.4s	v2, v2, v3
     73c:      	fadd.4s	v2, v2, v4
     740:      	ldp	q3, q4, [x10, #0x20]
     744:      	fadd.4s	v2, v2, v3
     748:      	fadd.4s	v2, v2, v4
     74c:      	ldp	q3, q4, [x10, #0x40]
     750:      	fadd.4s	v2, v2, v3
     754:      	fadd.4s	v2, v2, v4
     758:      	ldp	q3, q4, [x10, #0x60]
     75c:      	fadd.4s	v2, v2, v3
     760:      	fadd.4s	v2, v2, v4
     764:      	ldr	s3, [x10, #0x80]
     768:      	ldr	q4, [x8]
     76c:      	fadd.4s	v3, v2, v3
     770:      	bit.16b	v2, v3, v4
     774:      	dup.2d	v3, v2[1]
     778:      	fadd.4s	v2, v3, v2
     77c:      	faddp.2s	s2, v2
     780:      	fadd	s2, s2, s1
     784:      	str	s2, [x0, x9]
     788:      	add	x9, x9, #0x4
     78c:      	add	x10, x10, #0x104
     790:      	cmp	x9, #0x44
     794:      	b.ne	0x704 <_kernel+0x54>
     798:      	mov	x9, #0x0                ; =0
     79c:      	mov	w10, #0x42820000        ; =1115815936
     7a0:      	dup.4s	v0, w10
     7a4:      	ldp	q1, q2, [x0]
     7a8:      	fdiv.4s	v1, v1, v0
     7ac:      	fdiv.4s	v2, v2, v0
     7b0:      	stp	q1, q2, [x0]
     7b4:      	ldp	q1, q2, [x0, #0x20]
     7b8:      	fdiv.4s	v1, v1, v0
     7bc:      	fdiv.4s	v0, v2, v0
     7c0:      	stp	q1, q0, [x0, #0x20]
     7c4:      	ldr	s0, [x0, #0x40]
     7c8:      	fmov	s1, w10
     7cc:      	fdiv	s0, s0, s1
     7d0:      	str	s0, [x0, #0x40]
     7d4:      	add	x10, x1, #0x80
     7d8:      	movi.2d	v0, #0000000000000000
     7dc:      	add	x11, x0, x9
     7e0:      	ld1r.4s	{ v1 }, [x11]
     7e4:      	ldp	q2, q3, [x10, #-0x80]
     7e8:      	fsub.4s	v2, v2, v1
     7ec:      	fmul.4s	v2, v2, v2
     7f0:      	fsub.4s	v3, v3, v1
     7f4:      	fmul.4s	v3, v3, v3
     7f8:      	fadd.4s	v2, v2, v3
     7fc:      	ldp	q3, q4, [x10, #-0x60]
     800:      	fsub.4s	v3, v3, v1
     804:      	fmul.4s	v3, v3, v3
     808:      	fadd.4s	v2, v2, v3
     80c:      	fsub.4s	v3, v4, v1
     810:      	fmul.4s	v3, v3, v3
     814:      	fadd.4s	v2, v2, v3
     818:      	ldp	q3, q4, [x10, #-0x40]
     81c:      	fsub.4s	v3, v3, v1
     820:      	fmul.4s	v3, v3, v3
     824:      	fadd.4s	v2, v2, v3
     828:      	fsub.4s	v3, v4, v1
     82c:      	fmul.4s	v3, v3, v3
     830:      	fadd.4s	v2, v2, v3
     834:      	ldp	q3, q4, [x10, #-0x20]
     838:      	fsub.4s	v3, v3, v1
     83c:      	fmul.4s	v3, v3, v3
     840:      	fadd.4s	v2, v2, v3
     844:      	fsub.4s	v3, v4, v1
     848:      	fmul.4s	v3, v3, v3
     84c:      	fadd.4s	v2, v2, v3
     850:      	ldp	q3, q4, [x10]
     854:      	fsub.4s	v3, v3, v1
     858:      	fmul.4s	v3, v3, v3
     85c:      	fadd.4s	v2, v2, v3
     860:      	fsub.4s	v3, v4, v1
     864:      	fmul.4s	v3, v3, v3
     868:      	fadd.4s	v2, v2, v3
     86c:      	ldp	q3, q4, [x10, #0x20]
     870:      	fsub.4s	v3, v3, v1
     874:      	fmul.4s	v3, v3, v3
     878:      	fadd.4s	v2, v2, v3
     87c:      	fsub.4s	v3, v4, v1
     880:      	fmul.4s	v3, v3, v3
     884:      	fadd.4s	v2, v2, v3
     888:      	ldp	q3, q4, [x10, #0x40]
     88c:      	fsub.4s	v3, v3, v1
     890:      	fmul.4s	v3, v3, v3
     894:      	fadd.4s	v2, v2, v3
     898:      	fsub.4s	v3, v4, v1
     89c:      	fmul.4s	v3, v3, v3
     8a0:      	fadd.4s	v2, v2, v3
     8a4:      	ldp	q3, q4, [x10, #0x60]
     8a8:      	fsub.4s	v3, v3, v1
     8ac:      	fmul.4s	v3, v3, v3
     8b0:      	fadd.4s	v2, v2, v3
     8b4:      	ldr	q3, [x8]
     8b8:      	fsub.4s	v4, v4, v1
     8bc:      	fmul.4s	v4, v4, v4
     8c0:      	fadd.4s	v2, v2, v4
     8c4:      	ldr	s4, [x10, #0x80]
     8c8:      	fsub.4s	v1, v4, v1
     8cc:      	fmul.4s	v1, v1, v1
     8d0:      	fadd.4s	v1, v2, v1
     8d4:      	bif.16b	v1, v2, v3
     8d8:      	dup.2d	v2, v1[1]
     8dc:      	fadd.4s	v1, v1, v2
     8e0:      	faddp.2s	s1, v1
     8e4:      	fadd	s1, s1, s0
     8e8:      	str	s1, [x4, x9]
     8ec:      	add	x9, x9, #0x4
     8f0:      	add	x10, x10, #0x104
     8f4:      	cmp	x9, #0x44
     8f8:      	b.ne	0x7dc <_kernel+0x12c>
     8fc:      	mov	x20, #0x0               ; =0
     900:      	mov	w8, #0x42820000         ; =1115815936
     904:      	fmov	s8, w8
     908:      	mov	w8, #0xc5ac             ; =50604
     90c:      	movk	w8, #0x3727, lsl #16
     910:      	fmov	s9, w8
     914:      	fmov	s10, #1.00000000
     918:      	mov	x21, x1
     91c:      	mov	x19, x5
     920:      	b	0x978 <_kernel+0x2c8>
     924:      	ldr	s2, [x1, x23, lsl #2]
     928:      	ldr	s3, [x0, x20, lsl #2]
     92c:      	ldr	s0, [x4, x20, lsl #2]
     930:      	ldr	s4, [x2, #0x100]
     934:      	ldr	s5, [x3, #0x100]
     938:      	fdiv	s0, s0, s8
     93c:      	fadd	s1, s0, s9
     940:      	fsqrt	s0, s1
     944:      	fcmp	s0, s0
     948:      	b.vs	0xa44 <_kernel+0x394>
     94c:      	fdiv	s0, s10, s0
     950:      	fsub	s1, s2, s3
     954:      	fmul	s0, s1, s0
     958:      	fmul	s0, s4, s0
     95c:      	fadd	s0, s5, s0
     960:      	str	s0, [x5, x23, lsl #2]
     964:      	add	x20, x20, #0x1
     968:      	add	x19, x19, #0x104
     96c:      	add	x21, x21, #0x104
     970:      	cmp	x20, #0x11
     974:      	b.eq	0xaa8 <_kernel+0x3f8>
     978:      	add	x8, x20, x20, lsl #6
     97c:      	add	x23, x8, #0x40
     980:      	mov	x24, #-0x4              ; =-4
     984:      	lsl	x25, x20, #2
     988:      	mov	x26, x3
     98c:      	mov	x27, x2
     990:      	mov	x28, x21
     994:      	mov	x22, x19
     998:      	cmp	x24, #0x3c
     99c:      	b.eq	0x924 <_kernel+0x274>
     9a0:      	ldr	q4, [x28]
     9a4:      	add	x8, x0, x25
     9a8:      	ldr	s0, [x4, x25]
     9ac:      	ldr	q2, [x27]
     9b0:      	ldr	q3, [x26]
     9b4:      	ld1r.4s	{ v5 }, [x8]
     9b8:      	fdiv	s0, s0, s8
     9bc:      	fadd	s1, s0, s9
     9c0:      	fsqrt	s0, s1
     9c4:      	fcmp	s0, s0
     9c8:      	b.vs	0xa00 <_kernel+0x350>
     9cc:      	fsub.4s	v1, v4, v5
     9d0:      	fdiv	s0, s10, s0
     9d4:      	fmul.4s	v0, v1, v0[0]
     9d8:      	fmul.4s	v0, v2, v0
     9dc:      	fadd.4s	v0, v3, v0
     9e0:      	str	q0, [x22], #0x10
     9e4:      	add	x28, x28, #0x10
     9e8:      	add	x27, x27, #0x10
     9ec:      	add	x26, x26, #0x10
     9f0:      	add	x24, x24, #0x4
     9f4:      	cmp	x24, #0x3d
     9f8:      	b.lo	0x998 <_kernel+0x2e8>
     9fc:      	b	0x964 <_kernel+0x2b4>
     a00:      	mov.16b	v0, v1
     a04:      	stp	x3, x5, [sp, #0x68]
     a08:      	stp	x2, x4, [sp, #0x50]
     a0c:      	str	x1, [sp, #0x60]
     a10:      	str	x0, [sp, #0x48]
     a14:      	stp	q3, q2, [sp, #0x20]
     a18:      	stp	q5, q4, [sp]
     a1c:      	bl	0x1a80 <dyld_stub_binder+0x1a80>
     a20:      	ldp	q5, q4, [sp]
     a24:      	ldp	q3, q2, [sp, #0x20]
     a28:      	adrp	x12, 0x4000 <dyld_stub_binder+0x4000>
     a2c:      	ldr	x12, [x12, #0x98]
     a30:      	ldp	x0, x2, [sp, #0x48]
     a34:      	ldp	x1, x3, [sp, #0x60]
     a38:      	ldr	x4, [sp, #0x58]
     a3c:      	ldr	x5, [sp, #0x70]
     a40:      	b	0x9cc <_kernel+0x31c>
     a44:      	mov.16b	v0, v1
     a48:      	mov	x22, x5
     a4c:      	mov	x26, x4
     a50:      	mov	x24, x3
     a54:      	mov	x27, x2
     a58:      	mov	x25, x1
     a5c:      	mov	x28, x0
     a60:      	str	s2, [sp, #0x70]
     a64:      	str	s3, [sp, #0x60]
     a68:      	str	s4, [sp, #0x68]
     a6c:      	str	s5, [sp, #0x58]
     a70:      	bl	0x1a80 <dyld_stub_binder+0x1a80>
     a74:      	adrp	x12, 0x4000 <dyld_stub_binder+0x4000>
     a78:      	ldr	x12, [x12, #0x98]
     a7c:      	ldr	s5, [sp, #0x58]
     a80:      	ldr	s4, [sp, #0x68]
     a84:      	ldr	s3, [sp, #0x60]
     a88:      	ldr	s2, [sp, #0x70]
     a8c:      	mov	x0, x28
     a90:      	mov	x1, x25
     a94:      	mov	x2, x27
     a98:      	mov	x3, x24
     a9c:      	mov	x4, x26
     aa0:      	mov	x5, x22
     aa4:      	b	0x94c <_kernel+0x29c>
     aa8:      	str	xzr, [x12]
     aac:      	add	x8, sp, #0x78
     ab0:      	ldapr	w8, [x8]
     ab4:      	cbnz	w8, 0xae0 <_kernel+0x430>
     ab8:      	ldp	x29, x30, [sp, #0x110]
     abc:      	ldp	x20, x19, [sp, #0x100]
     ac0:      	ldp	x22, x21, [sp, #0xf0]
     ac4:      	ldp	x24, x23, [sp, #0xe0]
     ac8:      	ldp	x26, x25, [sp, #0xd0]
     acc:      	ldp	x28, x27, [sp, #0xc0]
     ad0:      	ldp	d9, d8, [sp, #0xb0]
     ad4:      	ldp	d11, d10, [sp, #0xa0]
     ad8:      	add	sp, sp, #0x120
     adc:      	ret
     ae0:      	mov	w0, #0x10               ; =16
     ae4:      	bl	0x1a14 <dyld_stub_binder+0x1a14>
     ae8:      	mov	x19, x0
     aec:      	mov	w8, #0x33d              ; =829
     af0:      	str	w8, [sp, #0x7c]
     af4:      	adrp	x0, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x98>
     af8:      	add	x0, x0, #0xd50
     afc:      	adrp	x1, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x98>
     b00:      	add	x1, x1, #0xddc
     b04:      	adrp	x3, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x98>
     b08:      	add	x3, x3, #0xe07
     b0c:      	adrp	x4, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x98>
     b10:      	add	x4, x4, #0xe85
     b14:      	adrp	x2, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x98>
     b18:      	add	x2, x2, #0xe04
     b1c:      	add	x8, sp, #0x80
     b20:      	add	x5, sp, #0x7c
     b24:      	adrp	x7, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x98>
     b28:      	add	x7, x7, #0xe87
     b2c:      	mov	x6, x2
     b30:      	bl	0xba4 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     b34:      	mov	w21, #0x1               ; =1
     b38:      	add	x1, sp, #0x80
     b3c:      	mov	x0, x19
     b40:      	bl	0x1960 <dyld_stub_binder+0x1960>
     b44:      	mov	w21, #0x0               ; =0
     b48:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     b4c:      	ldr	x1, [x1, #0x18]
     b50:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     b54:      	ldr	x2, [x2, #0x8]
     b58:      	mov	x0, x19
     b5c:      	bl	0x1a44 <dyld_stub_binder+0x1a44>
     b60:      	brk	#0x1
     b64:      	mov	x20, x0
     b68:      	ldrsb	w8, [sp, #0x97]
     b6c:      	tbz	w8, #0x1f, 0xb88 <_kernel+0x4d8>
     b70:      	ldr	x0, [sp, #0x80]
     b74:      	ldr	x8, [sp, #0x90]
     b78:      	and	x1, x8, #0x7fffffffffffffff
     b7c:      	bl	0x19fc <dyld_stub_binder+0x19fc>
     b80:      	tbnz	w21, #0x0, 0xb94 <_kernel+0x4e4>
     b84:      	b	0xb9c <_kernel+0x4ec>
     b88:      	cbnz	w21, 0xb94 <_kernel+0x4e4>
     b8c:      	b	0xb9c <_kernel+0x4ec>
     b90:      	mov	x20, x0
     b94:      	mov	x0, x19
     b98:      	bl	0x1a38 <dyld_stub_binder+0x1a38>
     b9c:      	mov	x0, x20
     ba0:      	bl	0x1924 <dyld_stub_binder+0x1924>

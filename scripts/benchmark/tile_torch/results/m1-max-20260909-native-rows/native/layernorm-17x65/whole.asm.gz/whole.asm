
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/layernorm-17x65-l1/object/tile_xir_w8_80747_1788919110592031_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x10]!
       4:      	sub	sp, sp, #0x2, lsl #12   ; =0x2000
       8:      	sub	sp, sp, #0x80
       c:      	mov	x11, #0x0               ; =0
      10:      	ldr	x12, [x0]
      14:      	ldr	x10, [x0, #0x10]
      18:      	ldr	w8, [x1]
      1c:      	ldr	w9, [x1, #0x24]
      20:      	add	w13, w9, w8, lsl #5
      24:      	ldr	x9, [x0, #0x20]
      28:      	ldr	x8, [x0, #0x30]
      2c:      	dup.4s	v0, w13
      30:      	adrp	x13, 0x0 <ltmp0>
      34:      	ldr	q1, [x13]
      38:      	add.4s	v2, v0, v1
      3c:      	adrp	x13, 0x0 <ltmp0>
      40:      	ldr	q1, [x13]
      44:      	add.4s	v3, v0, v1
      48:      	movi.4s	v1, #0x41
      4c:      	umull2.2d	v0, v2, v1
      50:      	umull2.2d	v1, v3, v1
      54:      	movi.2s	v4, #0x41
      58:      	umull.2d	v2, v2, v4
      5c:      	umull.2d	v3, v3, v4
      60:      	dup.2d	v4, x12
      64:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
      68:      	add	x12, x12, #0x860
      6c:      	dup.2d	v5, x11
      70:      	add.2d	v6, v5, v0
      74:      	add.2d	v7, v5, v2
      78:      	add.2d	v16, v5, v1
      7c:      	add.2d	v5, v5, v3
      80:      	shl.2d	v5, v5, #0x2
      84:      	shl.2d	v16, v16, #0x2
      88:      	shl.2d	v7, v7, #0x2
      8c:      	shl.2d	v6, v6, #0x2
      90:      	add.2d	v6, v4, v6
      94:      	add.2d	v7, v4, v7
      98:      	add.2d	v16, v4, v16
      9c:      	add.2d	v5, v4, v5
      a0:      	mov.d	x13, v5[1]
      a4:      	fmov	x14, d5
      a8:      	mov.d	x15, v16[1]
      ac:      	fmov	x16, d16
      b0:      	mov.d	x17, v7[1]
      b4:      	fmov	x0, d7
      b8:      	mov.d	x1, v6[1]
      bc:      	ldr	s5, [x0]
      c0:      	ld1.s	{ v5 }[1], [x17]
      c4:      	fmov	x17, d6
      c8:      	ld1.s	{ v5 }[2], [x17]
      cc:      	ld1.s	{ v5 }[3], [x1]
      d0:      	ldr	s6, [x14]
      d4:      	ld1.s	{ v6 }[1], [x13]
      d8:      	ld1.s	{ v6 }[2], [x16]
      dc:      	ld1.s	{ v6 }[3], [x15]
      e0:      	add	x13, x12, x11, lsl #5
      e4:      	stp	q6, q5, [x13]
      e8:      	add	x11, x11, #0x1
      ec:      	cmp	x11, #0x41
      f0:      	b.ne	0x6c <ltmp0+0x6c>
      f4:      	ldr	q17, [sp, #0x1870]
      f8:      	ldr	q16, [sp, #0x1860]
      fc:      	ldr	q6, [sp, #0x1890]
     100:      	ldr	q5, [sp, #0x1880]
     104:      	ldr	q4, [sp, #0x18b0]
     108:      	ldr	q7, [sp, #0x18a0]
     10c:      	add	x11, sp, #0x1, lsl #12  ; =0x1000
     110:      	add	x11, x11, #0x860
     114:      	add	x11, x11, #0xe0
     118:      	mov	w12, #0x4               ; =4
     11c:      	ldr	q19, [sp, #0x18d0]
     120:      	ldr	q18, [sp, #0x18c0]
     124:      	ldp	q20, q21, [x11, #-0x60]
     128:      	fadd.4s	v17, v17, v21
     12c:      	fadd.4s	v16, v16, v20
     130:      	ldp	q20, q21, [x11, #-0x40]
     134:      	fadd.4s	v6, v6, v21
     138:      	fadd.4s	v5, v5, v20
     13c:      	ldp	q20, q21, [x11, #-0x20]
     140:      	fadd.4s	v4, v4, v21
     144:      	fadd.4s	v7, v7, v20
     148:      	ldp	q20, q21, [x11], #0x80
     14c:      	fadd.4s	v19, v19, v21
     150:      	fadd.4s	v18, v18, v20
     154:      	cmp	x12, #0x3c
     158:      	add	x12, x12, #0x4
     15c:      	b.lo	0x124 <ltmp0+0x124>
     160:      	mov	x11, #0x0               ; =0
     164:      	ldr	q20, [sp, #0x2060]
     168:      	ldr	q21, [sp, #0x2070]
     16c:      	fadd.4s	v17, v17, v21
     170:      	fadd.4s	v16, v16, v20
     174:      	movi.2d	v20, #0000000000000000
     178:      	fadd.4s	v16, v16, v20
     17c:      	fadd.4s	v17, v17, v20
     180:      	fadd.4s	v6, v6, v17
     184:      	fadd.4s	v5, v5, v16
     188:      	fadd.4s	v5, v7, v5
     18c:      	fadd.4s	v4, v4, v6
     190:      	fadd.4s	v6, v19, v4
     194:      	fadd.4s	v4, v18, v5
     198:      	mov	w12, #0x42820000        ; =1115815936
     19c:      	dup.4s	v5, w12
     1a0:      	fdiv.4s	v4, v4, v5
     1a4:      	fdiv.4s	v5, v6, v5
     1a8:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     1ac:      	add	x12, x12, #0x860
     1b0:      	add	x13, sp, #0x1, lsl #12  ; =0x1000
     1b4:      	add	x13, x13, #0x40
     1b8:      	add	x14, x12, x11
     1bc:      	ldp	q7, q6, [x14]
     1c0:      	fsub.4s	v7, v7, v4
     1c4:      	fsub.4s	v6, v6, v5
     1c8:      	add	x14, x13, x11
     1cc:      	stp	q7, q6, [x14]
     1d0:      	add	x11, x11, #0x20
     1d4:      	cmp	x11, #0x820
     1d8:      	b.ne	0x1b8 <ltmp0+0x1b8>
     1dc:      	ldr	q5, [sp, #0x1040]
     1e0:      	ldr	q4, [sp, #0x1050]
     1e4:      	fmul.4s	v4, v4, v4
     1e8:      	fmul.4s	v5, v5, v5
     1ec:      	ldr	q6, [sp, #0x1060]
     1f0:      	ldr	q7, [sp, #0x1070]
     1f4:      	fmul.4s	v7, v7, v7
     1f8:      	fmul.4s	v6, v6, v6
     1fc:      	ldr	q17, [sp, #0x1080]
     200:      	ldr	q16, [sp, #0x1090]
     204:      	fmul.4s	v16, v16, v16
     208:      	fmul.4s	v17, v17, v17
     20c:      	ldr	q18, [sp, #0x10a0]
     210:      	ldr	q19, [sp, #0x10b0]
     214:      	fmul.4s	v19, v19, v19
     218:      	fmul.4s	v18, v18, v18
     21c:      	add	x11, sp, #0x1, lsl #12  ; =0x1000
     220:      	add	x11, x11, #0x40
     224:      	add	x11, x11, #0xe0
     228:      	mov	w12, #0x4               ; =4
     22c:      	ldp	q21, q20, [x11, #-0x60]
     230:      	fmul.4s	v21, v21, v21
     234:      	fmul.4s	v20, v20, v20
     238:      	fadd.4s	v4, v4, v20
     23c:      	fadd.4s	v5, v5, v21
     240:      	ldp	q21, q20, [x11, #-0x40]
     244:      	fmul.4s	v21, v21, v21
     248:      	fmul.4s	v20, v20, v20
     24c:      	fadd.4s	v7, v7, v20
     250:      	fadd.4s	v6, v6, v21
     254:      	ldp	q21, q20, [x11, #-0x20]
     258:      	fmul.4s	v21, v21, v21
     25c:      	fmul.4s	v20, v20, v20
     260:      	fadd.4s	v16, v16, v20
     264:      	fadd.4s	v17, v17, v21
     268:      	ldp	q21, q20, [x11], #0x80
     26c:      	fmul.4s	v21, v21, v21
     270:      	fmul.4s	v20, v20, v20
     274:      	fadd.4s	v19, v19, v20
     278:      	fadd.4s	v18, v18, v21
     27c:      	cmp	x12, #0x3c
     280:      	add	x12, x12, #0x4
     284:      	b.lo	0x22c <ltmp0+0x22c>
     288:      	mov	x11, #0x0               ; =0
     28c:      	ldr	q21, [sp, #0x1850]
     290:      	ldr	q20, [sp, #0x1840]
     294:      	add	x12, sp, #0x820
     298:      	add	x13, x10, x11, lsl #2
     29c:      	ld1r.4s	{ v22 }, [x13]
     2a0:      	add	x13, x12, x11, lsl #5
     2a4:      	stp	q22, q22, [x13]
     2a8:      	add	x11, x11, #0x1
     2ac:      	cmp	x11, #0x41
     2b0:      	b.ne	0x298 <ltmp0+0x298>
     2b4:      	mov	x10, #0x0               ; =0
     2b8:      	mov	x11, sp
     2bc:      	add	x12, x9, x10, lsl #2
     2c0:      	ld1r.4s	{ v22 }, [x12]
     2c4:      	add	x12, x11, x10, lsl #5
     2c8:      	stp	q22, q22, [x12]
     2cc:      	add	x10, x10, #0x1
     2d0:      	cmp	x10, #0x41
     2d4:      	b.ne	0x2bc <ltmp0+0x2bc>
     2d8:      	mov	x9, #0x0                ; =0
     2dc:      	fmul.4s	v21, v21, v21
     2e0:      	fmul.4s	v20, v20, v20
     2e4:      	fadd.4s	v5, v5, v20
     2e8:      	fadd.4s	v4, v4, v21
     2ec:      	fadd.4s	v4, v7, v4
     2f0:      	fadd.4s	v5, v6, v5
     2f4:      	fadd.4s	v5, v17, v5
     2f8:      	fadd.4s	v4, v16, v4
     2fc:      	fadd.4s	v4, v19, v4
     300:      	fadd.4s	v5, v18, v5
     304:      	mov	w10, #0x42820000        ; =1115815936
     308:      	dup.4s	v6, w10
     30c:      	fdiv.4s	v5, v5, v6
     310:      	fdiv.4s	v4, v4, v6
     314:      	mov	w10, #0xc5ac            ; =50604
     318:      	movk	w10, #0x3727, lsl #16
     31c:      	dup.4s	v6, w10
     320:      	fadd.4s	v7, v4, v6
     324:      	fadd.4s	v4, v5, v6
     328:      	fsqrt.4s	v4, v4
     32c:      	fsqrt.4s	v5, v7
     330:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     334:      	add	x10, x10, #0x40
     338:      	add	x11, sp, #0x820
     33c:      	dup.2d	v6, x8
     340:      	mov	x8, sp
     344:      	dup.2d	v7, x9
     348:      	add.2d	v16, v7, v0
     34c:      	add.2d	v17, v7, v2
     350:      	add.2d	v18, v7, v1
     354:      	add.2d	v7, v7, v3
     358:      	lsl	x12, x9, #5
     35c:      	add	x13, x10, x12
     360:      	ldp	q19, q20, [x13]
     364:      	fdiv.4s	v20, v20, v5
     368:      	fdiv.4s	v19, v19, v4
     36c:      	add	x13, x11, x12
     370:      	ldp	q22, q21, [x13]
     374:      	fmul.4s	v19, v19, v22
     378:      	fmul.4s	v20, v20, v21
     37c:      	add	x12, x8, x12
     380:      	ldp	q21, q22, [x12]
     384:      	fadd.4s	v20, v20, v22
     388:      	fadd.4s	v19, v19, v21
     38c:      	shl.2d	v7, v7, #0x2
     390:      	shl.2d	v18, v18, #0x2
     394:      	shl.2d	v17, v17, #0x2
     398:      	shl.2d	v16, v16, #0x2
     39c:      	add.2d	v16, v6, v16
     3a0:      	add.2d	v7, v6, v7
     3a4:      	mov.d	x12, v7[1]
     3a8:      	fmov	x13, d7
     3ac:      	str	s19, [x13]
     3b0:      	st1.s	{ v19 }[1], [x12]
     3b4:      	add.2d	v7, v6, v18
     3b8:      	mov.d	x12, v7[1]
     3bc:      	fmov	x13, d7
     3c0:      	st1.s	{ v19 }[2], [x13]
     3c4:      	add.2d	v7, v6, v17
     3c8:      	st1.s	{ v19 }[3], [x12]
     3cc:      	mov.d	x12, v7[1]
     3d0:      	fmov	x13, d7
     3d4:      	str	s20, [x13]
     3d8:      	st1.s	{ v20 }[1], [x12]
     3dc:      	mov.d	x12, v16[1]
     3e0:      	fmov	x13, d16
     3e4:      	st1.s	{ v20 }[2], [x13]
     3e8:      	st1.s	{ v20 }[3], [x12]
     3ec:      	add	x9, x9, #0x1
     3f0:      	cmp	x9, #0x41
     3f4:      	b.ne	0x344 <ltmp0+0x344>
     3f8:      	add	sp, sp, #0x2, lsl #12   ; =0x2000
     3fc:      	add	sp, sp, #0x80
     400:      	ldp	x28, x27, [sp], #0x10
     404:      	ret

0000000000000408 <_llm_rows.packet_batch.blocks>:
     408:      	stp	d9, d8, [sp, #-0x70]!
     40c:      	stp	x28, x27, [sp, #0x10]
     410:      	stp	x26, x25, [sp, #0x20]
     414:      	stp	x24, x23, [sp, #0x30]
     418:      	stp	x22, x21, [sp, #0x40]
     41c:      	stp	x20, x19, [sp, #0x50]
     420:      	stp	x29, x30, [sp, #0x60]
     424:      	sub	sp, sp, #0x2, lsl #12   ; =0x2000
     428:      	sub	sp, sp, #0x100
     42c:      	str	x0, [sp, #0x70]
     430:      	cbz	w3, 0xb9c <_llm_rows.packet_batch.blocks+0x794>
     434:      	mov	x25, x3
     438:      	mov	x20, x2
     43c:      	mov	w22, #0x0               ; =0
     440:      	add	x23, sp, #0x1, lsl #12  ; =0x1000
     444:      	add	x23, x23, #0xc0
     448:      	ldp	w9, w8, [x2, #0x2c]
     44c:      	stp	w8, w9, [sp, #0x68]
     450:      	ldp	w26, w15, [x2]
     454:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
     458:      	add	x8, x8, #0x8e0
     45c:      	add	x9, x8, #0xe0
     460:      	add	x8, x23, #0xe0
     464:      	stp	x8, x9, [sp, #0x28]
     468:      	movi.2s	v8, #0x41
     46c:      	ldp	w24, w8, [x2, #0x8]
     470:      	str	x8, [sp, #0x60]
     474:      	adrp	x8, 0x0 <ltmp0>
     478:      	ldr	q0, [x8]
     47c:      	str	q0, [sp, #0x50]
     480:      	adrp	x8, 0x0 <ltmp0>
     484:      	ldr	q0, [x8]
     488:      	str	q0, [sp, #0x40]
     48c:      	add	x19, sp, #0x8a0
     490:      	adrp	x8, 0x0 <ltmp0>
     494:      	ldr	q0, [x8]
     498:      	str	q0, [sp, #0x10]
     49c:      	add	x21, sp, #0x80
     4a0:      	str	w3, [sp, #0x3c]
     4a4:      	b	0x4ec <_llm_rows.packet_batch.blocks+0xe4>
     4a8:      	mov	w8, #0x18               ; =24
     4ac:      	str	w8, [x20, #0x24]
     4b0:      	ldr	w25, [sp, #0x3c]
     4b4:      	add	w8, w26, #0x1
     4b8:      	ldp	w10, w9, [sp, #0x68]
     4bc:      	cmp	w8, w9
     4c0:      	cset	w8, eq
     4c4:      	csinc	w26, wzr, w26, eq
     4c8:      	cinc	w9, w15, eq
     4cc:      	cmp	w9, w10
     4d0:      	cset	w10, eq
     4d4:      	ands	w8, w8, w10
     4d8:      	csel	w15, wzr, w9, ne
     4dc:      	add	w24, w24, w8
     4e0:      	add	w22, w22, #0x1
     4e4:      	cmp	w22, w25
     4e8:      	b.eq	0xb9c <_llm_rows.packet_batch.blocks+0x794>
     4ec:      	ubfiz	x8, x26, #5, #32
     4f0:      	ldr	x12, [sp, #0x60]
     4f4:      	cmp	x8, x12
     4f8:      	csel	x9, x8, xzr, ls
     4fc:      	subs	x10, x12, x9
     500:      	cmp	x10, #0x20
     504:      	mov	w11, #0x20              ; =32
     508:      	csel	x10, x10, x11, lo
     50c:      	cmp	x12, x9
     510:      	stp	w26, w15, [x20]
     514:      	str	w24, [x20, #0x8]
     518:      	str	wzr, [x20, #0x24]
     51c:      	ccmp	x8, x12, #0x2, hi
     520:      	csel	x27, x10, xzr, ls
     524:      	cmp	x27, #0x20
     528:      	b.lo	0x584 <_llm_rows.packet_batch.blocks+0x17c>
     52c:      	ldr	x27, [sp, #0x70]
     530:      	mov	x0, x27
     534:      	mov	x1, x20
     538:      	mov	x28, x15
     53c:      	bl	0x53c <_llm_rows.packet_batch.blocks+0x134>
     540:      	mov	w8, #0x8                ; =8
     544:      	str	w8, [x20, #0x24]
     548:      	mov	x0, x27
     54c:      	mov	x1, x20
     550:      	bl	0x550 <_llm_rows.packet_batch.blocks+0x148>
     554:      	mov	w8, #0x10               ; =16
     558:      	str	w8, [x20, #0x24]
     55c:      	mov	x0, x27
     560:      	mov	x1, x20
     564:      	bl	0x564 <_llm_rows.packet_batch.blocks+0x15c>
     568:      	mov	w8, #0x18               ; =24
     56c:      	str	w8, [x20, #0x24]
     570:      	mov	x0, x27
     574:      	mov	x1, x20
     578:      	bl	0x578 <_llm_rows.packet_batch.blocks+0x170>
     57c:      	mov	x15, x28
     580:      	b	0x4b4 <_llm_rows.packet_batch.blocks+0xac>
     584:      	lsr	x25, x27, #3
     588:      	cmp	x27, #0x8
     58c:      	b.lo	0x5e8 <_llm_rows.packet_batch.blocks+0x1e0>
     590:      	str	wzr, [x20, #0x24]
     594:      	ldr	x0, [sp, #0x70]
     598:      	mov	x1, x20
     59c:      	mov	x28, x15
     5a0:      	bl	0x5a0 <_llm_rows.packet_batch.blocks+0x198>
     5a4:      	mov	x15, x28
     5a8:      	cmp	x25, #0x1
     5ac:      	b.eq	0x5e8 <_llm_rows.packet_batch.blocks+0x1e0>
     5b0:      	mov	w8, #0x8                ; =8
     5b4:      	str	w8, [x20, #0x24]
     5b8:      	ldr	x0, [sp, #0x70]
     5bc:      	mov	x1, x20
     5c0:      	bl	0x5c0 <_llm_rows.packet_batch.blocks+0x1b8>
     5c4:      	mov	x15, x28
     5c8:      	cmp	x25, #0x2
     5cc:      	b.eq	0x5e8 <_llm_rows.packet_batch.blocks+0x1e0>
     5d0:      	mov	w8, #0x10               ; =16
     5d4:      	str	w8, [x20, #0x24]
     5d8:      	ldr	x0, [sp, #0x70]
     5dc:      	mov	x1, x20
     5e0:      	bl	0x5e0 <_llm_rows.packet_batch.blocks+0x1d8>
     5e4:      	mov	x15, x28
     5e8:      	and	w8, w27, #0x7
     5ec:      	cbz	w8, 0x4a8 <_llm_rows.packet_batch.blocks+0xa0>
     5f0:      	dup.4s	v1, w8
     5f4:      	ldp	q0, q2, [sp, #0x40]
     5f8:      	cmhi.4s	v0, v1, v0
     5fc:      	cmhi.4s	v1, v1, v2
     600:      	uzp1.8h	v6, v1, v0
     604:      	umaxv.8h	h2, v6
     608:      	fmov	w8, s2
     60c:      	tbz	w8, #0x0, 0x4a8 <_llm_rows.packet_batch.blocks+0xa0>
     610:      	mov	x11, #0x0               ; =0
     614:      	ldr	x13, [sp, #0x70]
     618:      	ldr	x12, [x13]
     61c:      	ldr	x10, [x13, #0x10]
     620:      	ldr	x9, [x13, #0x20]
     624:      	lsl	w8, w25, #3
     628:      	orr	w8, w8, w26, lsl #5
     62c:      	dup.4s	v2, w8
     630:      	ldr	x8, [x13, #0x30]
     634:      	ldp	q4, q3, [sp, #0x40]
     638:      	orr.16b	v3, v2, v3
     63c:      	orr.16b	v2, v2, v4
     640:      	and.16b	v4, v0, v2
     644:      	and.16b	v5, v1, v3
     648:      	movi.4s	v3, #0x41
     64c:      	umull2.2d	v2, v4, v3
     650:      	umull2.2d	v3, v5, v3
     654:      	umull.2d	v4, v4, v8
     658:      	umull.2d	v5, v5, v8
     65c:      	ldr	q7, [sp, #0x10]
     660:      	and.16b	v6, v6, v7
     664:      	addv.8h	h6, v6
     668:      	dup.2d	v7, x12
     66c:      	fmov	w12, s6
     670:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
     674:      	add	x16, x16, #0x8e0
     678:      	b	0x69c <_llm_rows.packet_batch.blocks+0x294>
     67c:      	add	x13, x16, x11, lsl #5
     680:      	ldp	q18, q19, [x13]
     684:      	bif.16b	v17, v19, v0
     688:      	bif.16b	v16, v18, v1
     68c:      	stp	q16, q17, [x13]
     690:      	add	x11, x11, #0x1
     694:      	cmp	x11, #0x41
     698:      	b.eq	0x788 <_llm_rows.packet_batch.blocks+0x380>
     69c:      	dup.2d	v18, x11
     6a0:      	add.2d	v16, v18, v5
     6a4:      	shl.2d	v16, v16, #0x2
     6a8:      	add.2d	v19, v7, v16
     6ac:      	movi.2d	v16, #0000000000000000
     6b0:      	movi.2d	v17, #0000000000000000
     6b4:      	tbnz	w12, #0x0, 0x700 <_llm_rows.packet_batch.blocks+0x2f8>
     6b8:      	and	w13, w12, #0xff
     6bc:      	tbnz	w13, #0x1, 0x710 <_llm_rows.packet_batch.blocks+0x308>
     6c0:      	add.2d	v19, v18, v3
     6c4:      	shl.2d	v19, v19, #0x2
     6c8:      	add.2d	v19, v7, v19
     6cc:      	tbnz	w13, #0x2, 0x728 <_llm_rows.packet_batch.blocks+0x320>
     6d0:      	tbnz	w13, #0x3, 0x734 <_llm_rows.packet_batch.blocks+0x32c>
     6d4:      	add.2d	v19, v18, v4
     6d8:      	shl.2d	v19, v19, #0x2
     6dc:      	add.2d	v19, v7, v19
     6e0:      	tbnz	w13, #0x4, 0x74c <_llm_rows.packet_batch.blocks+0x344>
     6e4:      	tbnz	w13, #0x5, 0x758 <_llm_rows.packet_batch.blocks+0x350>
     6e8:      	add.2d	v18, v18, v2
     6ec:      	shl.2d	v18, v18, #0x2
     6f0:      	add.2d	v18, v7, v18
     6f4:      	tbnz	w13, #0x6, 0x770 <_llm_rows.packet_batch.blocks+0x368>
     6f8:      	tbz	w13, #0x7, 0x67c <_llm_rows.packet_batch.blocks+0x274>
     6fc:      	b	0x77c <_llm_rows.packet_batch.blocks+0x374>
     700:      	fmov	x13, d19
     704:      	ldr	s16, [x13]
     708:      	and	w13, w12, #0xff
     70c:      	tbz	w13, #0x1, 0x6c0 <_llm_rows.packet_batch.blocks+0x2b8>
     710:      	mov.d	x14, v19[1]
     714:      	ld1.s	{ v16 }[1], [x14]
     718:      	add.2d	v19, v18, v3
     71c:      	shl.2d	v19, v19, #0x2
     720:      	add.2d	v19, v7, v19
     724:      	tbz	w13, #0x2, 0x6d0 <_llm_rows.packet_batch.blocks+0x2c8>
     728:      	fmov	x14, d19
     72c:      	ld1.s	{ v16 }[2], [x14]
     730:      	tbz	w13, #0x3, 0x6d4 <_llm_rows.packet_batch.blocks+0x2cc>
     734:      	mov.d	x14, v19[1]
     738:      	ld1.s	{ v16 }[3], [x14]
     73c:      	add.2d	v19, v18, v4
     740:      	shl.2d	v19, v19, #0x2
     744:      	add.2d	v19, v7, v19
     748:      	tbz	w13, #0x4, 0x6e4 <_llm_rows.packet_batch.blocks+0x2dc>
     74c:      	fmov	x14, d19
     750:      	ld1.s	{ v17 }[0], [x14]
     754:      	tbz	w13, #0x5, 0x6e8 <_llm_rows.packet_batch.blocks+0x2e0>
     758:      	mov.d	x14, v19[1]
     75c:      	ld1.s	{ v17 }[1], [x14]
     760:      	add.2d	v18, v18, v2
     764:      	shl.2d	v18, v18, #0x2
     768:      	add.2d	v18, v7, v18
     76c:      	tbz	w13, #0x6, 0x6f8 <_llm_rows.packet_batch.blocks+0x2f0>
     770:      	fmov	x14, d18
     774:      	ld1.s	{ v17 }[2], [x14]
     778:      	tbz	w13, #0x7, 0x67c <_llm_rows.packet_batch.blocks+0x274>
     77c:      	mov.d	x13, v18[1]
     780:      	ld1.s	{ v17 }[3], [x13]
     784:      	b	0x67c <_llm_rows.packet_batch.blocks+0x274>
     788:      	ldr	q7, [x23, #0x820]
     78c:      	ldr	q16, [x23, #0x830]
     790:      	ldr	q17, [x23, #0x840]
     794:      	ldr	q18, [x23, #0x850]
     798:      	ldr	q20, [x23, #0x860]
     79c:      	ldr	q23, [x23, #0x870]
     7a0:      	ldr	q24, [x23, #0x880]
     7a4:      	and.16b	v19, v0, v16
     7a8:      	and.16b	v22, v1, v7
     7ac:      	ldr	q7, [x23, #0x890]
     7b0:      	and.16b	v16, v0, v18
     7b4:      	and.16b	v21, v1, v17
     7b8:      	and.16b	v18, v0, v23
     7bc:      	and.16b	v17, v1, v20
     7c0:      	and.16b	v7, v0, v7
     7c4:      	and.16b	v20, v1, v24
     7c8:      	ldr	x11, [sp, #0x30]
     7cc:      	mov	w12, #0x4               ; =4
     7d0:      	ldp	q24, q23, [x11, #-0x60]
     7d4:      	fadd.4s	v24, v22, v24
     7d8:      	fadd.4s	v23, v19, v23
     7dc:      	ldp	q26, q25, [x11, #-0x40]
     7e0:      	fadd.4s	v26, v21, v26
     7e4:      	fadd.4s	v25, v16, v25
     7e8:      	ldp	q28, q27, [x11, #-0x20]
     7ec:      	fadd.4s	v28, v17, v28
     7f0:      	fadd.4s	v27, v18, v27
     7f4:      	ldp	q30, q29, [x11], #0x80
     7f8:      	fadd.4s	v30, v20, v30
     7fc:      	fadd.4s	v29, v7, v29
     800:      	bit.16b	v19, v23, v0
     804:      	bit.16b	v22, v24, v1
     808:      	bit.16b	v16, v25, v0
     80c:      	bit.16b	v21, v26, v1
     810:      	bit.16b	v18, v27, v0
     814:      	bit.16b	v17, v28, v1
     818:      	bit.16b	v7, v29, v0
     81c:      	bit.16b	v20, v30, v1
     820:      	cmp	x12, #0x3c
     824:      	add	x12, x12, #0x4
     828:      	b.lo	0x7d0 <_llm_rows.packet_batch.blocks+0x3c8>
     82c:      	mov	x11, #0x0               ; =0
     830:      	ldr	q23, [x23, #0x1020]
     834:      	ldr	q24, [x23, #0x1030]
     838:      	and.16b	v24, v0, v24
     83c:      	and.16b	v23, v1, v23
     840:      	fadd.4s	v22, v22, v23
     844:      	fadd.4s	v19, v19, v24
     848:      	movi.2d	v23, #0000000000000000
     84c:      	fadd.4s	v19, v19, v23
     850:      	fadd.4s	v22, v22, v23
     854:      	fadd.4s	v21, v21, v22
     858:      	fadd.4s	v16, v16, v19
     85c:      	fadd.4s	v16, v18, v16
     860:      	fadd.4s	v17, v17, v21
     864:      	fadd.4s	v17, v20, v17
     868:      	fadd.4s	v16, v7, v16
     86c:      	mov	w12, #0x42820000        ; =1115815936
     870:      	dup.4s	v7, w12
     874:      	fdiv.4s	v16, v16, v7
     878:      	fdiv.4s	v17, v17, v7
     87c:      	add	x12, x16, x11
     880:      	ldp	q19, q18, [x12]
     884:      	fsub.4s	v19, v19, v17
     888:      	fsub.4s	v18, v18, v16
     88c:      	add	x12, x23, x11
     890:      	ldp	q20, q21, [x12]
     894:      	bif.16b	v18, v21, v0
     898:      	bif.16b	v19, v20, v1
     89c:      	stp	q19, q18, [x12]
     8a0:      	add	x11, x11, #0x20
     8a4:      	cmp	x11, #0x820
     8a8:      	b.ne	0x87c <_llm_rows.packet_batch.blocks+0x474>
     8ac:      	ldp	q17, q16, [x23]
     8b0:      	fmul.4s	v18, v17, v17
     8b4:      	fmul.4s	v16, v16, v16
     8b8:      	ldp	q19, q17, [x23, #0x20]
     8bc:      	fmul.4s	v19, v19, v19
     8c0:      	fmul.4s	v20, v17, v17
     8c4:      	ldp	q21, q17, [x23, #0x40]
     8c8:      	fmul.4s	v22, v21, v21
     8cc:      	fmul.4s	v24, v17, v17
     8d0:      	ldp	q21, q17, [x23, #0x60]
     8d4:      	fmul.4s	v25, v21, v21
     8d8:      	fmul.4s	v26, v17, v17
     8dc:      	and.16b	v17, v0, v16
     8e0:      	and.16b	v23, v1, v18
     8e4:      	and.16b	v21, v0, v20
     8e8:      	and.16b	v20, v1, v19
     8ec:      	and.16b	v16, v0, v24
     8f0:      	and.16b	v22, v1, v22
     8f4:      	and.16b	v19, v0, v26
     8f8:      	and.16b	v18, v1, v25
     8fc:      	ldr	x11, [sp, #0x28]
     900:      	mov	w12, #0x4               ; =4
     904:      	ldp	q25, q24, [x11, #-0x60]
     908:      	and.16b	v25, v1, v25
     90c:      	and.16b	v24, v0, v24
     910:      	fmul.4s	v24, v24, v24
     914:      	fmul.4s	v25, v25, v25
     918:      	fadd.4s	v25, v23, v25
     91c:      	fadd.4s	v24, v17, v24
     920:      	ldp	q27, q26, [x11, #-0x40]
     924:      	and.16b	v27, v1, v27
     928:      	and.16b	v26, v0, v26
     92c:      	fmul.4s	v26, v26, v26
     930:      	fmul.4s	v27, v27, v27
     934:      	fadd.4s	v27, v20, v27
     938:      	fadd.4s	v26, v21, v26
     93c:      	ldp	q29, q28, [x11, #-0x20]
     940:      	and.16b	v29, v1, v29
     944:      	and.16b	v28, v0, v28
     948:      	fmul.4s	v28, v28, v28
     94c:      	fmul.4s	v29, v29, v29
     950:      	fadd.4s	v29, v22, v29
     954:      	fadd.4s	v28, v16, v28
     958:      	ldp	q31, q30, [x11], #0x80
     95c:      	and.16b	v31, v1, v31
     960:      	and.16b	v30, v0, v30
     964:      	fmul.4s	v30, v30, v30
     968:      	fmul.4s	v31, v31, v31
     96c:      	fadd.4s	v31, v18, v31
     970:      	fadd.4s	v30, v19, v30
     974:      	bit.16b	v17, v24, v0
     978:      	bit.16b	v23, v25, v1
     97c:      	bit.16b	v21, v26, v0
     980:      	bit.16b	v20, v27, v1
     984:      	bit.16b	v16, v28, v0
     988:      	bit.16b	v22, v29, v1
     98c:      	bit.16b	v19, v30, v0
     990:      	bit.16b	v18, v31, v1
     994:      	cmp	x12, #0x3c
     998:      	add	x12, x12, #0x4
     99c:      	b.lo	0x904 <_llm_rows.packet_batch.blocks+0x4fc>
     9a0:      	mov	x11, #0x0               ; =0
     9a4:      	ldr	q24, [x23, #0x810]
     9a8:      	ldr	q25, [x23, #0x800]
     9ac:      	add	x12, x10, x11, lsl #2
     9b0:      	ld1r.4s	{ v26 }, [x12]
     9b4:      	add	x12, x19, x11, lsl #5
     9b8:      	ldp	q27, q28, [x12]
     9bc:      	bit.16b	v28, v26, v0
     9c0:      	bif.16b	v26, v27, v1
     9c4:      	stp	q26, q28, [x12]
     9c8:      	add	x11, x11, #0x1
     9cc:      	cmp	x11, #0x41
     9d0:      	b.ne	0x9ac <_llm_rows.packet_batch.blocks+0x5a4>
     9d4:      	mov	x10, #0x0               ; =0
     9d8:      	add	x11, x9, x10, lsl #2
     9dc:      	ld1r.4s	{ v26 }, [x11]
     9e0:      	add	x11, x21, x10, lsl #5
     9e4:      	ldp	q27, q28, [x11]
     9e8:      	bit.16b	v28, v26, v0
     9ec:      	bif.16b	v26, v27, v1
     9f0:      	stp	q26, q28, [x11]
     9f4:      	add	x10, x10, #0x1
     9f8:      	cmp	x10, #0x41
     9fc:      	b.ne	0x9d8 <_llm_rows.packet_batch.blocks+0x5d0>
     a00:      	mov	x9, #0x0                ; =0
     a04:      	and.16b	v25, v1, v25
     a08:      	and.16b	v24, v0, v24
     a0c:      	fmul.4s	v24, v24, v24
     a10:      	fmul.4s	v25, v25, v25
     a14:      	fadd.4s	v23, v23, v25
     a18:      	fadd.4s	v17, v17, v24
     a1c:      	fadd.4s	v17, v21, v17
     a20:      	fadd.4s	v20, v20, v23
     a24:      	fadd.4s	v20, v22, v20
     a28:      	fadd.4s	v16, v16, v17
     a2c:      	fadd.4s	v16, v19, v16
     a30:      	fadd.4s	v17, v18, v20
     a34:      	fdiv.4s	v17, v17, v7
     a38:      	fdiv.4s	v7, v16, v7
     a3c:      	mov	w10, #0xc5ac            ; =50604
     a40:      	movk	w10, #0x3727, lsl #16
     a44:      	dup.4s	v16, w10
     a48:      	fadd.4s	v7, v7, v16
     a4c:      	fadd.4s	v16, v17, v16
     a50:      	fsqrt.4s	v16, v16
     a54:      	fsqrt.4s	v7, v7
     a58:      	and.16b	v7, v0, v7
     a5c:      	and.16b	v16, v1, v16
     a60:      	b	0xa70 <_llm_rows.packet_batch.blocks+0x668>
     a64:      	add	x9, x9, #0x1
     a68:      	cmp	x9, #0x41
     a6c:      	b.eq	0x4a8 <_llm_rows.packet_batch.blocks+0xa0>
     a70:      	fmov	w10, s6
     a74:      	dup.2d	v17, x9
     a78:      	add.2d	v18, v17, v5
     a7c:      	lsl	x11, x9, #5
     a80:      	add	x12, x23, x11
     a84:      	ldp	q20, q19, [x12]
     a88:      	and.16b	v20, v1, v20
     a8c:      	fdiv.4s	v21, v20, v16
     a90:      	add	x12, x19, x11
     a94:      	ldp	q22, q20, [x12]
     a98:      	and.16b	v22, v1, v22
     a9c:      	fmul.4s	v22, v21, v22
     aa0:      	add	x11, x21, x11
     aa4:      	ldp	q23, q21, [x11]
     aa8:      	and.16b	v23, v1, v23
     aac:      	fadd.4s	v22, v22, v23
     ab0:      	shl.2d	v23, v18, #0x2
     ab4:      	dup.2d	v18, x8
     ab8:      	add.2d	v23, v18, v23
     abc:      	tbnz	w10, #0x0, 0xb28 <_llm_rows.packet_batch.blocks+0x720>
     ac0:      	and	w10, w10, #0xff
     ac4:      	tbnz	w10, #0x1, 0xb38 <_llm_rows.packet_batch.blocks+0x730>
     ac8:      	add.2d	v23, v17, v3
     acc:      	shl.2d	v23, v23, #0x2
     ad0:      	add.2d	v23, v18, v23
     ad4:      	tbnz	w10, #0x2, 0xb50 <_llm_rows.packet_batch.blocks+0x748>
     ad8:      	tbz	w10, #0x3, 0xae4 <_llm_rows.packet_batch.blocks+0x6dc>
     adc:      	mov.d	x11, v23[1]
     ae0:      	st1.s	{ v22 }[3], [x11]
     ae4:      	add.2d	v22, v17, v4
     ae8:      	and.16b	v19, v0, v19
     aec:      	fdiv.4s	v19, v19, v7
     af0:      	and.16b	v20, v0, v20
     af4:      	fmul.4s	v19, v19, v20
     af8:      	and.16b	v20, v0, v21
     afc:      	fadd.4s	v19, v19, v20
     b00:      	shl.2d	v20, v22, #0x2
     b04:      	add.2d	v20, v18, v20
     b08:      	tbnz	w10, #0x4, 0xb60 <_llm_rows.packet_batch.blocks+0x758>
     b0c:      	tbnz	w10, #0x5, 0xb6c <_llm_rows.packet_batch.blocks+0x764>
     b10:      	add.2d	v17, v17, v2
     b14:      	shl.2d	v17, v17, #0x2
     b18:      	add.2d	v17, v18, v17
     b1c:      	tbnz	w10, #0x6, 0xb84 <_llm_rows.packet_batch.blocks+0x77c>
     b20:      	tbz	w10, #0x7, 0xa64 <_llm_rows.packet_batch.blocks+0x65c>
     b24:      	b	0xb90 <_llm_rows.packet_batch.blocks+0x788>
     b28:      	fmov	x11, d23
     b2c:      	str	s22, [x11]
     b30:      	and	w10, w10, #0xff
     b34:      	tbz	w10, #0x1, 0xac8 <_llm_rows.packet_batch.blocks+0x6c0>
     b38:      	mov.d	x11, v23[1]
     b3c:      	st1.s	{ v22 }[1], [x11]
     b40:      	add.2d	v23, v17, v3
     b44:      	shl.2d	v23, v23, #0x2
     b48:      	add.2d	v23, v18, v23
     b4c:      	tbz	w10, #0x2, 0xad8 <_llm_rows.packet_batch.blocks+0x6d0>
     b50:      	fmov	x11, d23
     b54:      	st1.s	{ v22 }[2], [x11]
     b58:      	tbnz	w10, #0x3, 0xadc <_llm_rows.packet_batch.blocks+0x6d4>
     b5c:      	b	0xae4 <_llm_rows.packet_batch.blocks+0x6dc>
     b60:      	fmov	x11, d20
     b64:      	str	s19, [x11]
     b68:      	tbz	w10, #0x5, 0xb10 <_llm_rows.packet_batch.blocks+0x708>
     b6c:      	mov.d	x11, v20[1]
     b70:      	st1.s	{ v19 }[1], [x11]
     b74:      	add.2d	v17, v17, v2
     b78:      	shl.2d	v17, v17, #0x2
     b7c:      	add.2d	v17, v18, v17
     b80:      	tbz	w10, #0x6, 0xb20 <_llm_rows.packet_batch.blocks+0x718>
     b84:      	fmov	x11, d17
     b88:      	st1.s	{ v19 }[2], [x11]
     b8c:      	tbz	w10, #0x7, 0xa64 <_llm_rows.packet_batch.blocks+0x65c>
     b90:      	mov.d	x10, v17[1]
     b94:      	st1.s	{ v19 }[3], [x10]
     b98:      	b	0xa64 <_llm_rows.packet_batch.blocks+0x65c>
     b9c:      	add	sp, sp, #0x2, lsl #12   ; =0x2000
     ba0:      	add	sp, sp, #0x100
     ba4:      	ldp	x29, x30, [sp, #0x60]
     ba8:      	ldp	x20, x19, [sp, #0x50]
     bac:      	ldp	x22, x21, [sp, #0x40]
     bb0:      	ldp	x24, x23, [sp, #0x30]
     bb4:      	ldp	x26, x25, [sp, #0x20]
     bb8:      	ldp	x28, x27, [sp, #0x10]
     bbc:      	ldp	d9, d8, [sp], #0x70
     bc0:      	ret

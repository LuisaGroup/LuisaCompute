
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/layernorm-129x768/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0x110
     6b4:      	stp	d11, d10, [sp, #0x90]
     6b8:      	stp	d9, d8, [sp, #0xa0]
     6bc:      	stp	x28, x27, [sp, #0xb0]
     6c0:      	stp	x26, x25, [sp, #0xc0]
     6c4:      	stp	x24, x23, [sp, #0xd0]
     6c8:      	stp	x22, x21, [sp, #0xe0]
     6cc:      	stp	x20, x19, [sp, #0xf0]
     6d0:      	stp	x29, x30, [sp, #0x100]
     6d4:      	add	x29, sp, #0x100
     6d8:      	mov	x8, #0x0                ; =0
     6dc:      	str	wzr, [sp, #0x68]
     6e0:      	adrp	x19, 0x4000 <dyld_stub_binder+0x4000>
     6e4:      	ldr	x19, [x19, #0x90]
     6e8:      	add	x9, sp, #0x68
     6ec:      	str	x9, [x19]
     6f0:      	movi.2d	v0, #0000000000000000
     6f4:      	mov	x9, x1
     6f8:      	movi.2d	v1, #0000000000000000
     6fc:      	mov	x10, #-0x4              ; =-4
     700:      	mov	x11, x9
     704:      	ldr	q2, [x11], #0x10
     708:      	fadd.4s	v1, v1, v2
     70c:      	add	x10, x10, #0x4
     710:      	cmp	x10, #0x2fc
     714:      	b.lo	0x704 <_kernel+0x54>
     718:      	dup.2d	v2, v1[1]
     71c:      	fadd.4s	v1, v1, v2
     720:      	faddp.2s	s1, v1
     724:      	fadd	s1, s1, s0
     728:      	str	s1, [x0, x8, lsl #2]
     72c:      	add	x8, x8, #0x1
     730:      	add	x9, x9, #0xc00
     734:      	cmp	x8, #0x81
     738:      	b.ne	0x6f8 <_kernel+0x48>
     73c:      	mov	x8, #0x0                ; =0
     740:      	mov	w9, #0x44400000         ; =1145044992
     744:      	dup.4s	v0, w9
     748:      	ldp	q1, q2, [x0]
     74c:      	fdiv.4s	v1, v1, v0
     750:      	fdiv.4s	v2, v2, v0
     754:      	stp	q1, q2, [x0]
     758:      	ldp	q1, q2, [x0, #0x20]
     75c:      	fdiv.4s	v1, v1, v0
     760:      	fdiv.4s	v2, v2, v0
     764:      	stp	q1, q2, [x0, #0x20]
     768:      	ldp	q1, q2, [x0, #0x40]
     76c:      	fdiv.4s	v1, v1, v0
     770:      	fdiv.4s	v2, v2, v0
     774:      	stp	q1, q2, [x0, #0x40]
     778:      	ldp	q1, q2, [x0, #0x60]
     77c:      	fdiv.4s	v1, v1, v0
     780:      	fdiv.4s	v2, v2, v0
     784:      	stp	q1, q2, [x0, #0x60]
     788:      	ldp	q1, q2, [x0, #0x80]
     78c:      	fdiv.4s	v1, v1, v0
     790:      	fdiv.4s	v2, v2, v0
     794:      	stp	q1, q2, [x0, #0x80]
     798:      	ldp	q1, q2, [x0, #0xa0]
     79c:      	fdiv.4s	v1, v1, v0
     7a0:      	fdiv.4s	v2, v2, v0
     7a4:      	stp	q1, q2, [x0, #0xa0]
     7a8:      	ldp	q1, q2, [x0, #0xc0]
     7ac:      	fdiv.4s	v1, v1, v0
     7b0:      	fdiv.4s	v2, v2, v0
     7b4:      	stp	q1, q2, [x0, #0xc0]
     7b8:      	ldp	q1, q2, [x0, #0xe0]
     7bc:      	fdiv.4s	v1, v1, v0
     7c0:      	fdiv.4s	v2, v2, v0
     7c4:      	stp	q1, q2, [x0, #0xe0]
     7c8:      	ldp	q1, q2, [x0, #0x100]
     7cc:      	fdiv.4s	v1, v1, v0
     7d0:      	fdiv.4s	v2, v2, v0
     7d4:      	ldp	q3, q4, [x0, #0x120]
     7d8:      	fdiv.4s	v3, v3, v0
     7dc:      	fdiv.4s	v4, v4, v0
     7e0:      	ldp	q5, q6, [x0, #0x140]
     7e4:      	fdiv.4s	v5, v5, v0
     7e8:      	fdiv.4s	v6, v6, v0
     7ec:      	ldp	q7, q16, [x0, #0x160]
     7f0:      	fdiv.4s	v7, v7, v0
     7f4:      	fdiv.4s	v16, v16, v0
     7f8:      	ldp	q17, q18, [x0, #0x180]
     7fc:      	fdiv.4s	v17, v17, v0
     800:      	fdiv.4s	v18, v18, v0
     804:      	ldp	q19, q20, [x0, #0x1a0]
     808:      	fdiv.4s	v19, v19, v0
     80c:      	fdiv.4s	v20, v20, v0
     810:      	ldp	q21, q22, [x0, #0x1c0]
     814:      	fdiv.4s	v21, v21, v0
     818:      	fdiv.4s	v22, v22, v0
     81c:      	ldp	q23, q24, [x0, #0x1e0]
     820:      	fdiv.4s	v23, v23, v0
     824:      	fdiv.4s	v0, v24, v0
     828:      	stp	q1, q2, [x0, #0x100]
     82c:      	stp	q3, q4, [x0, #0x120]
     830:      	stp	q5, q6, [x0, #0x140]
     834:      	stp	q7, q16, [x0, #0x160]
     838:      	stp	q17, q18, [x0, #0x180]
     83c:      	stp	q19, q20, [x0, #0x1a0]
     840:      	stp	q21, q22, [x0, #0x1c0]
     844:      	fmov	s1, w9
     848:      	stp	q23, q0, [x0, #0x1e0]
     84c:      	ldr	s0, [x0, #0x200]
     850:      	fdiv	s0, s0, s1
     854:      	mov	x9, x1
     858:      	str	s0, [x0, #0x200]
     85c:      	add	x10, x0, x8, lsl #2
     860:      	ld1r.4s	{ v1 }, [x10]
     864:      	movi.2d	v0, #0000000000000000
     868:      	mov	x10, #-0x4              ; =-4
     86c:      	mov	x11, x9
     870:      	ldr	q2, [x11], #0x10
     874:      	fsub.4s	v2, v2, v1
     878:      	fmul.4s	v2, v2, v2
     87c:      	fadd.4s	v0, v0, v2
     880:      	add	x10, x10, #0x4
     884:      	cmp	x10, #0x2fc
     888:      	b.lo	0x870 <_kernel+0x1c0>
     88c:      	dup.2d	v1, v0[1]
     890:      	fadd.4s	v0, v0, v1
     894:      	faddp.2s	s0, v0
     898:      	str	s0, [x4, x8, lsl #2]
     89c:      	add	x8, x8, #0x1
     8a0:      	add	x9, x9, #0xc00
     8a4:      	cmp	x8, #0x81
     8a8:      	b.ne	0x85c <_kernel+0x1ac>
     8ac:      	mov	x20, #0x0               ; =0
     8b0:      	mov	w8, #0x44400000         ; =1145044992
     8b4:      	fmov	s8, w8
     8b8:      	mov	w8, #0xc5ac             ; =50604
     8bc:      	movk	w8, #0x3727, lsl #16
     8c0:      	fmov	s9, w8
     8c4:      	fmov	s10, #1.00000000
     8c8:      	b	0x8e0 <_kernel+0x230>
     8cc:      	add	x20, x20, #0x1
     8d0:      	add	x5, x5, #0xc00
     8d4:      	add	x1, x1, #0xc00
     8d8:      	cmp	x20, #0x81
     8dc:      	b.eq	0x998 <_kernel+0x2e8>
     8e0:      	mov	x21, #-0x4              ; =-4
     8e4:      	lsl	x22, x20, #2
     8e8:      	mov	x23, x1
     8ec:      	mov	x24, x5
     8f0:      	mov	x25, x2
     8f4:      	mov	x26, x3
     8f8:      	ldr	q4, [x23]
     8fc:      	add	x8, x0, x22
     900:      	ldr	s0, [x4, x22]
     904:      	ldr	q2, [x25]
     908:      	ldr	q3, [x26]
     90c:      	ld1r.4s	{ v5 }, [x8]
     910:      	fdiv	s0, s0, s8
     914:      	fadd	s1, s0, s9
     918:      	fsqrt	s0, s1
     91c:      	fcmp	s0, s0
     920:      	b.vs	0x958 <_kernel+0x2a8>
     924:      	fsub.4s	v1, v4, v5
     928:      	fdiv	s0, s10, s0
     92c:      	fmul.4s	v0, v1, v0[0]
     930:      	fmul.4s	v0, v2, v0
     934:      	fadd.4s	v0, v3, v0
     938:      	str	q0, [x24], #0x10
     93c:      	add	x21, x21, #0x4
     940:      	add	x26, x26, #0x10
     944:      	add	x25, x25, #0x10
     948:      	add	x23, x23, #0x10
     94c:      	cmp	x21, #0x2fc
     950:      	b.lo	0x8f8 <_kernel+0x248>
     954:      	b	0x8cc <_kernel+0x21c>
     958:      	mov.16b	v0, v1
     95c:      	stp	x3, x5, [sp, #0x50]
     960:      	mov	x27, x4
     964:      	mov	x28, x2
     968:      	str	x1, [sp, #0x60]
     96c:      	str	x0, [sp, #0x48]
     970:      	stp	q3, q2, [sp, #0x20]
     974:      	stp	q5, q4, [sp]
     978:      	bl	0x1970 <dyld_stub_binder+0x1970>
     97c:      	ldp	q5, q4, [sp]
     980:      	ldp	q3, q2, [sp, #0x20]
     984:      	ldp	x0, x3, [sp, #0x48]
     988:      	ldp	x5, x1, [sp, #0x58]
     98c:      	mov	x2, x28
     990:      	mov	x4, x27
     994:      	b	0x924 <_kernel+0x274>
     998:      	str	xzr, [x19]
     99c:      	add	x8, sp, #0x68
     9a0:      	ldapr	w8, [x8]
     9a4:      	cbnz	w8, 0x9d0 <_kernel+0x320>
     9a8:      	ldp	x29, x30, [sp, #0x100]
     9ac:      	ldp	x20, x19, [sp, #0xf0]
     9b0:      	ldp	x22, x21, [sp, #0xe0]
     9b4:      	ldp	x24, x23, [sp, #0xd0]
     9b8:      	ldp	x26, x25, [sp, #0xc0]
     9bc:      	ldp	x28, x27, [sp, #0xb0]
     9c0:      	ldp	d9, d8, [sp, #0xa0]
     9c4:      	ldp	d11, d10, [sp, #0x90]
     9c8:      	add	sp, sp, #0x110
     9cc:      	ret
     9d0:      	mov	w0, #0x10               ; =16
     9d4:      	bl	0x1904 <dyld_stub_binder+0x1904>
     9d8:      	mov	x19, x0
     9dc:      	mov	w8, #0x33d              ; =829
     9e0:      	str	w8, [sp, #0x6c]
     9e4:      	adrp	x0, 0x1000 <__ZNSt3__120__throw_length_errorB9nqe220108EPKc+0x44>
     9e8:      	add	x0, x0, #0xc40
     9ec:      	adrp	x1, 0x1000 <__ZNSt3__120__throw_length_errorB9nqe220108EPKc+0x44>
     9f0:      	add	x1, x1, #0xccc
     9f4:      	adrp	x3, 0x1000 <__ZNSt3__120__throw_length_errorB9nqe220108EPKc+0x44>
     9f8:      	add	x3, x3, #0xcf7
     9fc:      	adrp	x4, 0x1000 <__ZNSt3__120__throw_length_errorB9nqe220108EPKc+0x44>
     a00:      	add	x4, x4, #0xd75
     a04:      	adrp	x2, 0x1000 <__ZNSt3__120__throw_length_errorB9nqe220108EPKc+0x44>
     a08:      	add	x2, x2, #0xcf4
     a0c:      	add	x8, sp, #0x70
     a10:      	add	x5, sp, #0x6c
     a14:      	adrp	x7, 0x1000 <__ZNSt3__120__throw_length_errorB9nqe220108EPKc+0x44>
     a18:      	add	x7, x7, #0xd77
     a1c:      	mov	x6, x2
     a20:      	bl	0xa94 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     a24:      	mov	w21, #0x1               ; =1
     a28:      	add	x1, sp, #0x70
     a2c:      	mov	x0, x19
     a30:      	bl	0x1850 <dyld_stub_binder+0x1850>
     a34:      	mov	w21, #0x0               ; =0
     a38:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     a3c:      	ldr	x1, [x1, #0x18]
     a40:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     a44:      	ldr	x2, [x2, #0x8]
     a48:      	mov	x0, x19
     a4c:      	bl	0x1934 <dyld_stub_binder+0x1934>
     a50:      	brk	#0x1
     a54:      	mov	x20, x0
     a58:      	ldrsb	w8, [sp, #0x87]
     a5c:      	tbz	w8, #0x1f, 0xa78 <_kernel+0x3c8>
     a60:      	ldr	x0, [sp, #0x70]
     a64:      	ldr	x8, [sp, #0x80]
     a68:      	and	x1, x8, #0x7fffffffffffffff
     a6c:      	bl	0x18ec <dyld_stub_binder+0x18ec>
     a70:      	tbnz	w21, #0x0, 0xa84 <_kernel+0x3d4>
     a74:      	b	0xa8c <_kernel+0x3dc>
     a78:      	cbnz	w21, 0xa84 <_kernel+0x3d4>
     a7c:      	b	0xa8c <_kernel+0x3dc>
     a80:      	mov	x20, x0
     a84:      	mov	x0, x19
     a88:      	bl	0x1928 <dyld_stub_binder+0x1928>
     a8c:      	mov	x0, x20
     a90:      	bl	0x1814 <dyld_stub_binder+0x1814>

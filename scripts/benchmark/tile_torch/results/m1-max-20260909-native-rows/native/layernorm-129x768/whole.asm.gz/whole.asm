
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/layernorm-129x768-l1/object/tile_xir_w8_80749_1788919110977700_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	mov	x12, #0x0               ; =0
       4:      	ldr	x8, [x1, #0x88]
       8:      	ldr	x13, [x0]
       c:      	ldr	x11, [x0, #0x10]
      10:      	ldr	w9, [x1]
      14:      	ldr	w10, [x1, #0x24]
      18:      	add	w14, w10, w9, lsl #5
      1c:      	ldr	x10, [x0, #0x20]
      20:      	ldr	x9, [x0, #0x30]
      24:      	dup.4s	v0, w14
      28:      	adrp	x14, 0x0 <ltmp0>
      2c:      	ldr	q1, [x14]
      30:      	add.4s	v2, v0, v1
      34:      	adrp	x14, 0x0 <ltmp0>
      38:      	ldr	q1, [x14]
      3c:      	add.4s	v3, v0, v1
      40:      	movi.4s	v1, #0x3, lsl #8
      44:      	umull2.2d	v0, v2, v1
      48:      	umull2.2d	v1, v3, v1
      4c:      	movi.2s	v4, #0x3, lsl #8
      50:      	umull.2d	v2, v2, v4
      54:      	umull.2d	v3, v3, v4
      58:      	dup.2d	v4, x13
      5c:      	dup.2d	v5, x12
      60:      	add.2d	v6, v5, v0
      64:      	add.2d	v7, v5, v2
      68:      	add.2d	v16, v5, v1
      6c:      	add.2d	v5, v5, v3
      70:      	shl.2d	v5, v5, #0x2
      74:      	shl.2d	v16, v16, #0x2
      78:      	shl.2d	v7, v7, #0x2
      7c:      	shl.2d	v6, v6, #0x2
      80:      	add.2d	v6, v4, v6
      84:      	add.2d	v7, v4, v7
      88:      	add.2d	v16, v4, v16
      8c:      	add.2d	v5, v4, v5
      90:      	mov.d	x13, v5[1]
      94:      	fmov	x14, d5
      98:      	mov.d	x15, v16[1]
      9c:      	fmov	x16, d16
      a0:      	mov.d	x17, v7[1]
      a4:      	fmov	x0, d7
      a8:      	mov.d	x1, v6[1]
      ac:      	ldr	s5, [x14]
      b0:      	ld1.s	{ v5 }[1], [x13]
      b4:      	fmov	x13, d6
      b8:      	ld1.s	{ v5 }[2], [x16]
      bc:      	ld1.s	{ v5 }[3], [x15]
      c0:      	ldr	s6, [x0]
      c4:      	ld1.s	{ v6 }[1], [x17]
      c8:      	ld1.s	{ v6 }[2], [x13]
      cc:      	ld1.s	{ v6 }[3], [x1]
      d0:      	add	x13, x8, x12, lsl #5
      d4:      	stp	q5, q6, [x13]
      d8:      	add	x12, x12, #0x1
      dc:      	cmp	x12, #0x300
      e0:      	b.ne	0x5c <ltmp0+0x5c>
      e4:      	ldp	q17, q5, [x8]
      e8:      	ldp	q6, q7, [x8, #0x20]
      ec:      	ldp	q16, q4, [x8, #0x40]
      f0:      	add	x12, x8, #0xe0
      f4:      	mov	w13, #0x4               ; =4
      f8:      	ldp	q18, q19, [x8, #0x60]
      fc:      	ldp	q20, q21, [x12, #-0x60]
     100:      	fadd.4s	v5, v5, v21
     104:      	fadd.4s	v17, v17, v20
     108:      	ldp	q20, q21, [x12, #-0x40]
     10c:      	fadd.4s	v7, v7, v21
     110:      	fadd.4s	v6, v6, v20
     114:      	ldp	q20, q21, [x12, #-0x20]
     118:      	fadd.4s	v4, v4, v21
     11c:      	fadd.4s	v16, v16, v20
     120:      	ldp	q20, q21, [x12], #0x80
     124:      	fadd.4s	v19, v19, v21
     128:      	fadd.4s	v18, v18, v20
     12c:      	cmp	x13, #0x2fc
     130:      	add	x13, x13, #0x4
     134:      	b.lo	0xfc <ltmp0+0xfc>
     138:      	movi.2d	v20, #0000000000000000
     13c:      	fadd.4s	v17, v17, v20
     140:      	fadd.4s	v5, v5, v20
     144:      	fadd.4s	v5, v5, v7
     148:      	fadd.4s	v6, v17, v6
     14c:      	fadd.4s	v6, v6, v16
     150:      	fadd.4s	v4, v5, v4
     154:      	fadd.4s	v5, v4, v19
     158:      	fadd.4s	v4, v6, v18
     15c:      	mov	w12, #0x44400000        ; =1145044992
     160:      	dup.4s	v6, w12
     164:      	fdiv.4s	v4, v4, v6
     168:      	fdiv.4s	v5, v5, v6
     16c:      	mov	w12, #0x300             ; =768
     170:      	mov	x13, x8
     174:      	ldp	q7, q6, [x13]
     178:      	fsub.4s	v7, v7, v4
     17c:      	fsub.4s	v6, v6, v5
     180:      	str	q6, [x13, #0x6010]
     184:      	str	q7, [x13, #0x6000]
     188:      	add	x13, x13, #0x20
     18c:      	subs	x12, x12, #0x1
     190:      	b.ne	0x174 <ltmp0+0x174>
     194:      	ldr	q4, [x8, #0x6000]
     198:      	ldr	q5, [x8, #0x6010]
     19c:      	fmul.4s	v5, v5, v5
     1a0:      	fmul.4s	v4, v4, v4
     1a4:      	ldr	q6, [x8, #0x6020]
     1a8:      	ldr	q7, [x8, #0x6030]
     1ac:      	fmul.4s	v7, v7, v7
     1b0:      	fmul.4s	v6, v6, v6
     1b4:      	ldr	q17, [x8, #0x6040]
     1b8:      	ldr	q16, [x8, #0x6050]
     1bc:      	fmul.4s	v16, v16, v16
     1c0:      	fmul.4s	v17, v17, v17
     1c4:      	ldr	q18, [x8, #0x6060]
     1c8:      	ldr	q19, [x8, #0x6070]
     1cc:      	fmul.4s	v19, v19, v19
     1d0:      	fmul.4s	v18, v18, v18
     1d4:      	mov	w12, #0x60e0            ; =24800
     1d8:      	add	x12, x8, x12
     1dc:      	mov	w13, #0x304             ; =772
     1e0:      	ldp	q21, q20, [x12, #-0x60]
     1e4:      	fmul.4s	v21, v21, v21
     1e8:      	fmul.4s	v20, v20, v20
     1ec:      	fadd.4s	v5, v5, v20
     1f0:      	fadd.4s	v4, v4, v21
     1f4:      	ldp	q21, q20, [x12, #-0x40]
     1f8:      	fmul.4s	v21, v21, v21
     1fc:      	fmul.4s	v20, v20, v20
     200:      	fadd.4s	v7, v7, v20
     204:      	fadd.4s	v6, v6, v21
     208:      	ldp	q21, q20, [x12, #-0x20]
     20c:      	fmul.4s	v21, v21, v21
     210:      	fmul.4s	v20, v20, v20
     214:      	fadd.4s	v16, v16, v20
     218:      	fadd.4s	v17, v17, v21
     21c:      	ldp	q21, q20, [x12], #0x80
     220:      	fmul.4s	v21, v21, v21
     224:      	fmul.4s	v20, v20, v20
     228:      	fadd.4s	v19, v19, v20
     22c:      	fadd.4s	v18, v18, v21
     230:      	sub	x14, x13, #0x300
     234:      	add	x13, x13, #0x4
     238:      	cmp	x14, #0x2fc
     23c:      	b.lo	0x1e0 <ltmp0+0x1e0>
     240:      	mov	x12, #0x0               ; =0
     244:      	add	x13, x8, #0xc, lsl #12  ; =0xc000
     248:      	add	x14, x11, x12, lsl #2
     24c:      	ld1r.4s	{ v20 }, [x14]
     250:      	add	x14, x13, x12, lsl #5
     254:      	stp	q20, q20, [x14]
     258:      	add	x12, x12, #0x1
     25c:      	cmp	x12, #0x300
     260:      	b.ne	0x248 <ltmp0+0x248>
     264:      	mov	x11, #0x0               ; =0
     268:      	add	x12, x8, #0x12, lsl #12 ; =0x12000
     26c:      	add	x13, x10, x11, lsl #2
     270:      	ld1r.4s	{ v20 }, [x13]
     274:      	add	x13, x12, x11, lsl #5
     278:      	stp	q20, q20, [x13]
     27c:      	add	x11, x11, #0x1
     280:      	cmp	x11, #0x300
     284:      	b.ne	0x26c <ltmp0+0x26c>
     288:      	fadd.4s	v5, v5, v7
     28c:      	fadd.4s	v4, v4, v6
     290:      	fadd.4s	v4, v4, v17
     294:      	fadd.4s	v5, v5, v16
     298:      	fadd.4s	v5, v5, v19
     29c:      	fadd.4s	v4, v4, v18
     2a0:      	mov	w10, #0x44400000        ; =1145044992
     2a4:      	dup.4s	v6, w10
     2a8:      	fdiv.4s	v4, v4, v6
     2ac:      	fdiv.4s	v5, v5, v6
     2b0:      	mov	w10, #0xc5ac            ; =50604
     2b4:      	movk	w10, #0x3727, lsl #16
     2b8:      	dup.4s	v6, w10
     2bc:      	fadd.4s	v5, v5, v6
     2c0:      	fadd.4s	v4, v4, v6
     2c4:      	fsqrt.4s	v4, v4
     2c8:      	fsqrt.4s	v5, v5
     2cc:      	mov	x10, #-0x300            ; =-768
     2d0:      	dup.2d	v6, x9
     2d4:      	add	x9, x10, #0x300
     2d8:      	dup.2d	v7, x9
     2dc:      	add.2d	v16, v7, v0
     2e0:      	add.2d	v17, v7, v2
     2e4:      	add.2d	v18, v7, v1
     2e8:      	add.2d	v7, v7, v3
     2ec:      	ldr	q19, [x8, #0x6000]
     2f0:      	ldr	q20, [x8, #0x6010]
     2f4:      	fdiv.4s	v20, v20, v5
     2f8:      	fdiv.4s	v19, v19, v4
     2fc:      	ldr	q21, [x8, #0xc010]
     300:      	ldr	q22, [x8, #0xc000]
     304:      	fmul.4s	v19, v19, v22
     308:      	fmul.4s	v20, v20, v21
     30c:      	add	x9, x8, #0x12, lsl #12  ; =0x12000
     310:      	ldp	q21, q22, [x9]
     314:      	fadd.4s	v20, v20, v22
     318:      	fadd.4s	v19, v19, v21
     31c:      	shl.2d	v7, v7, #0x2
     320:      	shl.2d	v18, v18, #0x2
     324:      	shl.2d	v17, v17, #0x2
     328:      	shl.2d	v16, v16, #0x2
     32c:      	add.2d	v16, v6, v16
     330:      	add.2d	v7, v6, v7
     334:      	mov.d	x9, v7[1]
     338:      	fmov	x11, d7
     33c:      	str	s19, [x11]
     340:      	st1.s	{ v19 }[1], [x9]
     344:      	add.2d	v7, v6, v18
     348:      	mov.d	x9, v7[1]
     34c:      	fmov	x11, d7
     350:      	st1.s	{ v19 }[2], [x11]
     354:      	add.2d	v7, v6, v17
     358:      	st1.s	{ v19 }[3], [x9]
     35c:      	mov.d	x9, v7[1]
     360:      	fmov	x11, d7
     364:      	str	s20, [x11]
     368:      	st1.s	{ v20 }[1], [x9]
     36c:      	mov.d	x9, v16[1]
     370:      	fmov	x11, d16
     374:      	st1.s	{ v20 }[2], [x11]
     378:      	st1.s	{ v20 }[3], [x9]
     37c:      	add	x8, x8, #0x20
     380:      	adds	x10, x10, #0x1
     384:      	b.lo	0x2d4 <ltmp0+0x2d4>
     388:      	ret

000000000000038c <_llm_rows.packet_batch.blocks>:
     38c:      	cbz	w3, 0xac8 <_llm_rows.packet_batch.blocks+0x73c>
     390:      	sub	sp, sp, #0xc0
     394:      	stp	d9, d8, [sp, #0x50]
     398:      	stp	x28, x27, [sp, #0x60]
     39c:      	stp	x26, x25, [sp, #0x70]
     3a0:      	stp	x24, x23, [sp, #0x80]
     3a4:      	stp	x22, x21, [sp, #0x90]
     3a8:      	stp	x20, x19, [sp, #0xa0]
     3ac:      	stp	x29, x30, [sp, #0xb0]
     3b0:      	mov	x23, x3
     3b4:      	mov	x20, x2
     3b8:      	mov	x21, x0
     3bc:      	mov	w22, #0x0               ; =0
     3c0:      	ldp	w19, w8, [x2, #0x2c]
     3c4:      	str	w8, [sp, #0x48]
     3c8:      	ldp	w25, w26, [x2]
     3cc:      	adrp	x8, 0x0 <ltmp0>
     3d0:      	ldr	q0, [x8]
     3d4:      	str	q0, [sp, #0x30]
     3d8:      	adrp	x8, 0x0 <ltmp0>
     3dc:      	ldr	q0, [x8]
     3e0:      	str	q0, [sp, #0x20]
     3e4:      	movi.2s	v8, #0x3, lsl #8
     3e8:      	adrp	x8, 0x0 <ltmp0>
     3ec:      	ldr	q0, [x8]
     3f0:      	str	q0, [sp]
     3f4:      	ldp	w27, w28, [x2, #0x8]
     3f8:      	str	w3, [sp, #0x1c]
     3fc:      	b	0x444 <_llm_rows.packet_batch.blocks+0xb8>
     400:      	mov	w8, #0x18               ; =24
     404:      	str	w8, [x20, #0x24]
     408:      	ldr	w23, [sp, #0x1c]
     40c:      	add	w8, w25, #0x1
     410:      	cmp	w8, w19
     414:      	cset	w8, eq
     418:      	csinc	w25, wzr, w25, eq
     41c:      	cinc	w9, w26, eq
     420:      	ldr	w10, [sp, #0x48]
     424:      	cmp	w9, w10
     428:      	cset	w10, eq
     42c:      	ands	w8, w8, w10
     430:      	csel	w26, wzr, w9, ne
     434:      	add	w27, w27, w8
     438:      	add	w22, w22, #0x1
     43c:      	cmp	w22, w23
     440:      	b.eq	0xaa8 <_llm_rows.packet_batch.blocks+0x71c>
     444:      	ubfiz	x8, x25, #5, #32
     448:      	cmp	x8, x28
     44c:      	csel	x9, x8, xzr, ls
     450:      	subs	x10, x28, x9
     454:      	cmp	x10, #0x20
     458:      	mov	w11, #0x20              ; =32
     45c:      	csel	x10, x10, x11, lo
     460:      	cmp	x28, x9
     464:      	stp	w25, w26, [x20]
     468:      	str	w27, [x20, #0x8]
     46c:      	str	wzr, [x20, #0x24]
     470:      	ccmp	x8, x28, #0x2, hi
     474:      	csel	x24, x10, xzr, ls
     478:      	cmp	x24, #0x20
     47c:      	b.lo	0x4cc <_llm_rows.packet_batch.blocks+0x140>
     480:      	mov	x0, x21
     484:      	mov	x1, x20
     488:      	bl	0x488 <_llm_rows.packet_batch.blocks+0xfc>
     48c:      	mov	w8, #0x8                ; =8
     490:      	str	w8, [x20, #0x24]
     494:      	mov	x0, x21
     498:      	mov	x1, x20
     49c:      	bl	0x49c <_llm_rows.packet_batch.blocks+0x110>
     4a0:      	mov	w8, #0x10               ; =16
     4a4:      	str	w8, [x20, #0x24]
     4a8:      	mov	x0, x21
     4ac:      	mov	x1, x20
     4b0:      	bl	0x4b0 <_llm_rows.packet_batch.blocks+0x124>
     4b4:      	mov	w8, #0x18               ; =24
     4b8:      	str	w8, [x20, #0x24]
     4bc:      	mov	x0, x21
     4c0:      	mov	x1, x20
     4c4:      	bl	0x4c4 <_llm_rows.packet_batch.blocks+0x138>
     4c8:      	b	0x40c <_llm_rows.packet_batch.blocks+0x80>
     4cc:      	lsr	x23, x24, #3
     4d0:      	cmp	x24, #0x8
     4d4:      	b.lo	0x520 <_llm_rows.packet_batch.blocks+0x194>
     4d8:      	str	wzr, [x20, #0x24]
     4dc:      	mov	x0, x21
     4e0:      	mov	x1, x20
     4e4:      	bl	0x4e4 <_llm_rows.packet_batch.blocks+0x158>
     4e8:      	cmp	x23, #0x1
     4ec:      	b.eq	0x520 <_llm_rows.packet_batch.blocks+0x194>
     4f0:      	mov	w8, #0x8                ; =8
     4f4:      	str	w8, [x20, #0x24]
     4f8:      	mov	x0, x21
     4fc:      	mov	x1, x20
     500:      	bl	0x500 <_llm_rows.packet_batch.blocks+0x174>
     504:      	cmp	x23, #0x2
     508:      	b.eq	0x520 <_llm_rows.packet_batch.blocks+0x194>
     50c:      	mov	w8, #0x10               ; =16
     510:      	str	w8, [x20, #0x24]
     514:      	mov	x0, x21
     518:      	mov	x1, x20
     51c:      	bl	0x51c <_llm_rows.packet_batch.blocks+0x190>
     520:      	and	w8, w24, #0x7
     524:      	cbz	w8, 0x400 <_llm_rows.packet_batch.blocks+0x74>
     528:      	dup.4s	v1, w8
     52c:      	ldp	q0, q2, [sp, #0x20]
     530:      	cmhi.4s	v0, v1, v0
     534:      	cmhi.4s	v1, v1, v2
     538:      	uzp1.8h	v6, v1, v0
     53c:      	umaxv.8h	h2, v6
     540:      	fmov	w8, s2
     544:      	tbz	w8, #0x0, 0x400 <_llm_rows.packet_batch.blocks+0x74>
     548:      	mov	x14, #0x0               ; =0
     54c:      	ldr	x8, [x20, #0x88]
     550:      	add	x12, x8, #0xc, lsl #12  ; =0xc000
     554:      	add	x10, x8, #0x12, lsl #12 ; =0x12000
     558:      	ldr	x15, [x21]
     55c:      	ldr	x13, [x21, #0x10]
     560:      	ldr	x11, [x21, #0x20]
     564:      	lsl	w9, w23, #3
     568:      	orr	w9, w9, w25, lsl #5
     56c:      	dup.4s	v2, w9
     570:      	ldr	x9, [x21, #0x30]
     574:      	ldp	q4, q3, [sp, #0x20]
     578:      	orr.16b	v3, v2, v3
     57c:      	orr.16b	v2, v2, v4
     580:      	and.16b	v4, v0, v2
     584:      	and.16b	v5, v1, v3
     588:      	movi.4s	v3, #0x3, lsl #8
     58c:      	umull2.2d	v2, v4, v3
     590:      	umull2.2d	v3, v5, v3
     594:      	umull.2d	v4, v4, v8
     598:      	umull.2d	v5, v5, v8
     59c:      	ldr	q7, [sp]
     5a0:      	and.16b	v6, v6, v7
     5a4:      	addv.8h	h6, v6
     5a8:      	dup.2d	v7, x15
     5ac:      	fmov	w15, s6
     5b0:      	b	0x5d4 <_llm_rows.packet_batch.blocks+0x248>
     5b4:      	add	x16, x8, x14, lsl #5
     5b8:      	ldp	q18, q19, [x16]
     5bc:      	bif.16b	v17, v19, v0
     5c0:      	bif.16b	v16, v18, v1
     5c4:      	stp	q16, q17, [x16]
     5c8:      	add	x14, x14, #0x1
     5cc:      	cmp	x14, #0x300
     5d0:      	b.eq	0x6c0 <_llm_rows.packet_batch.blocks+0x334>
     5d4:      	dup.2d	v18, x14
     5d8:      	add.2d	v16, v18, v5
     5dc:      	shl.2d	v16, v16, #0x2
     5e0:      	add.2d	v19, v7, v16
     5e4:      	movi.2d	v16, #0000000000000000
     5e8:      	movi.2d	v17, #0000000000000000
     5ec:      	tbnz	w15, #0x0, 0x638 <_llm_rows.packet_batch.blocks+0x2ac>
     5f0:      	and	w16, w15, #0xff
     5f4:      	tbnz	w16, #0x1, 0x648 <_llm_rows.packet_batch.blocks+0x2bc>
     5f8:      	add.2d	v19, v18, v3
     5fc:      	shl.2d	v19, v19, #0x2
     600:      	add.2d	v19, v7, v19
     604:      	tbnz	w16, #0x2, 0x660 <_llm_rows.packet_batch.blocks+0x2d4>
     608:      	tbnz	w16, #0x3, 0x66c <_llm_rows.packet_batch.blocks+0x2e0>
     60c:      	add.2d	v19, v18, v4
     610:      	shl.2d	v19, v19, #0x2
     614:      	add.2d	v19, v7, v19
     618:      	tbnz	w16, #0x4, 0x684 <_llm_rows.packet_batch.blocks+0x2f8>
     61c:      	tbnz	w16, #0x5, 0x690 <_llm_rows.packet_batch.blocks+0x304>
     620:      	add.2d	v18, v18, v2
     624:      	shl.2d	v18, v18, #0x2
     628:      	add.2d	v18, v7, v18
     62c:      	tbnz	w16, #0x6, 0x6a8 <_llm_rows.packet_batch.blocks+0x31c>
     630:      	tbz	w16, #0x7, 0x5b4 <_llm_rows.packet_batch.blocks+0x228>
     634:      	b	0x6b4 <_llm_rows.packet_batch.blocks+0x328>
     638:      	fmov	x16, d19
     63c:      	ldr	s16, [x16]
     640:      	and	w16, w15, #0xff
     644:      	tbz	w16, #0x1, 0x5f8 <_llm_rows.packet_batch.blocks+0x26c>
     648:      	mov.d	x17, v19[1]
     64c:      	ld1.s	{ v16 }[1], [x17]
     650:      	add.2d	v19, v18, v3
     654:      	shl.2d	v19, v19, #0x2
     658:      	add.2d	v19, v7, v19
     65c:      	tbz	w16, #0x2, 0x608 <_llm_rows.packet_batch.blocks+0x27c>
     660:      	fmov	x17, d19
     664:      	ld1.s	{ v16 }[2], [x17]
     668:      	tbz	w16, #0x3, 0x60c <_llm_rows.packet_batch.blocks+0x280>
     66c:      	mov.d	x17, v19[1]
     670:      	ld1.s	{ v16 }[3], [x17]
     674:      	add.2d	v19, v18, v4
     678:      	shl.2d	v19, v19, #0x2
     67c:      	add.2d	v19, v7, v19
     680:      	tbz	w16, #0x4, 0x61c <_llm_rows.packet_batch.blocks+0x290>
     684:      	fmov	x17, d19
     688:      	ld1.s	{ v17 }[0], [x17]
     68c:      	tbz	w16, #0x5, 0x620 <_llm_rows.packet_batch.blocks+0x294>
     690:      	mov.d	x17, v19[1]
     694:      	ld1.s	{ v17 }[1], [x17]
     698:      	add.2d	v18, v18, v2
     69c:      	shl.2d	v18, v18, #0x2
     6a0:      	add.2d	v18, v7, v18
     6a4:      	tbz	w16, #0x6, 0x630 <_llm_rows.packet_batch.blocks+0x2a4>
     6a8:      	fmov	x17, d18
     6ac:      	ld1.s	{ v17 }[2], [x17]
     6b0:      	tbz	w16, #0x7, 0x5b4 <_llm_rows.packet_batch.blocks+0x228>
     6b4:      	mov.d	x16, v18[1]
     6b8:      	ld1.s	{ v17 }[3], [x16]
     6bc:      	b	0x5b4 <_llm_rows.packet_batch.blocks+0x228>
     6c0:      	ldp	q16, q7, [x8]
     6c4:      	ldp	q18, q19, [x8, #0x20]
     6c8:      	ldp	q22, q23, [x8, #0x40]
     6cc:      	and.16b	v7, v0, v7
     6d0:      	and.16b	v17, v1, v16
     6d4:      	ldp	q24, q25, [x8, #0x60]
     6d8:      	and.16b	v21, v0, v19
     6dc:      	and.16b	v20, v1, v18
     6e0:      	and.16b	v16, v0, v23
     6e4:      	and.16b	v22, v1, v22
     6e8:      	and.16b	v19, v0, v25
     6ec:      	and.16b	v18, v1, v24
     6f0:      	add	x14, x8, #0xe0
     6f4:      	mov	w15, #0x4               ; =4
     6f8:      	ldp	q24, q23, [x14, #-0x60]
     6fc:      	fadd.4s	v24, v17, v24
     700:      	fadd.4s	v23, v7, v23
     704:      	ldp	q26, q25, [x14, #-0x40]
     708:      	fadd.4s	v26, v20, v26
     70c:      	fadd.4s	v25, v21, v25
     710:      	ldp	q28, q27, [x14, #-0x20]
     714:      	fadd.4s	v28, v22, v28
     718:      	fadd.4s	v27, v16, v27
     71c:      	ldp	q30, q29, [x14], #0x80
     720:      	fadd.4s	v30, v18, v30
     724:      	fadd.4s	v29, v19, v29
     728:      	bit.16b	v7, v23, v0
     72c:      	bit.16b	v17, v24, v1
     730:      	bit.16b	v21, v25, v0
     734:      	bit.16b	v20, v26, v1
     738:      	bit.16b	v16, v27, v0
     73c:      	bit.16b	v22, v28, v1
     740:      	bit.16b	v19, v29, v0
     744:      	bit.16b	v18, v30, v1
     748:      	cmp	x15, #0x2fc
     74c:      	add	x15, x15, #0x4
     750:      	b.lo	0x6f8 <_llm_rows.packet_batch.blocks+0x36c>
     754:      	movi.2d	v23, #0000000000000000
     758:      	fadd.4s	v17, v17, v23
     75c:      	fadd.4s	v7, v7, v23
     760:      	fadd.4s	v7, v7, v21
     764:      	fadd.4s	v17, v17, v20
     768:      	fadd.4s	v17, v17, v22
     76c:      	fadd.4s	v7, v7, v16
     770:      	fadd.4s	v19, v7, v19
     774:      	fadd.4s	v16, v17, v18
     778:      	mov	w14, #0x44400000        ; =1145044992
     77c:      	dup.4s	v7, w14
     780:      	fdiv.4s	v16, v16, v7
     784:      	fdiv.4s	v17, v19, v7
     788:      	mov	x14, x8
     78c:      	mov	w15, #0x300             ; =768
     790:      	ldp	q19, q18, [x14]
     794:      	fsub.4s	v19, v19, v16
     798:      	fsub.4s	v18, v18, v17
     79c:      	ldr	q20, [x14, #0x6000]
     7a0:      	ldr	q21, [x14, #0x6010]
     7a4:      	bif.16b	v18, v21, v0
     7a8:      	bif.16b	v19, v20, v1
     7ac:      	str	q19, [x14, #0x6000]
     7b0:      	str	q18, [x14, #0x6010]
     7b4:      	add	x14, x14, #0x20
     7b8:      	subs	x15, x15, #0x1
     7bc:      	b.ne	0x790 <_llm_rows.packet_batch.blocks+0x404>
     7c0:      	ldr	q16, [x8, #0x6010]
     7c4:      	ldr	q17, [x8, #0x6000]
     7c8:      	fmul.4s	v17, v17, v17
     7cc:      	fmul.4s	v16, v16, v16
     7d0:      	ldr	q18, [x8, #0x6030]
     7d4:      	ldr	q19, [x8, #0x6020]
     7d8:      	fmul.4s	v20, v19, v19
     7dc:      	fmul.4s	v18, v18, v18
     7e0:      	ldr	q19, [x8, #0x6050]
     7e4:      	ldr	q21, [x8, #0x6040]
     7e8:      	fmul.4s	v22, v21, v21
     7ec:      	fmul.4s	v21, v19, v19
     7f0:      	ldr	q19, [x8, #0x6070]
     7f4:      	ldr	q23, [x8, #0x6060]
     7f8:      	fmul.4s	v24, v23, v23
     7fc:      	fmul.4s	v25, v19, v19
     800:      	and.16b	v16, v0, v16
     804:      	and.16b	v19, v1, v17
     808:      	and.16b	v18, v0, v18
     80c:      	and.16b	v23, v1, v20
     810:      	and.16b	v21, v0, v21
     814:      	and.16b	v20, v1, v22
     818:      	and.16b	v17, v0, v25
     81c:      	and.16b	v22, v1, v24
     820:      	mov	w14, #0x60e0            ; =24800
     824:      	add	x14, x8, x14
     828:      	mov	w15, #0x304             ; =772
     82c:      	ldp	q25, q24, [x14, #-0x60]
     830:      	and.16b	v25, v1, v25
     834:      	and.16b	v24, v0, v24
     838:      	fmul.4s	v24, v24, v24
     83c:      	fmul.4s	v25, v25, v25
     840:      	fadd.4s	v25, v19, v25
     844:      	fadd.4s	v24, v16, v24
     848:      	ldp	q27, q26, [x14, #-0x40]
     84c:      	and.16b	v27, v1, v27
     850:      	and.16b	v26, v0, v26
     854:      	fmul.4s	v26, v26, v26
     858:      	fmul.4s	v27, v27, v27
     85c:      	fadd.4s	v27, v23, v27
     860:      	fadd.4s	v26, v18, v26
     864:      	ldp	q29, q28, [x14, #-0x20]
     868:      	and.16b	v29, v1, v29
     86c:      	and.16b	v28, v0, v28
     870:      	fmul.4s	v28, v28, v28
     874:      	fmul.4s	v29, v29, v29
     878:      	fadd.4s	v29, v20, v29
     87c:      	fadd.4s	v28, v21, v28
     880:      	ldp	q31, q30, [x14], #0x80
     884:      	and.16b	v31, v1, v31
     888:      	and.16b	v30, v0, v30
     88c:      	fmul.4s	v30, v30, v30
     890:      	fmul.4s	v31, v31, v31
     894:      	fadd.4s	v31, v22, v31
     898:      	fadd.4s	v30, v17, v30
     89c:      	bit.16b	v16, v24, v0
     8a0:      	bit.16b	v19, v25, v1
     8a4:      	bit.16b	v18, v26, v0
     8a8:      	bit.16b	v23, v27, v1
     8ac:      	bit.16b	v21, v28, v0
     8b0:      	bit.16b	v20, v29, v1
     8b4:      	bit.16b	v17, v30, v0
     8b8:      	bit.16b	v22, v31, v1
     8bc:      	sub	x16, x15, #0x300
     8c0:      	add	x15, x15, #0x4
     8c4:      	cmp	x16, #0x2fc
     8c8:      	b.lo	0x82c <_llm_rows.packet_batch.blocks+0x4a0>
     8cc:      	mov	x14, #0x0               ; =0
     8d0:      	add	x15, x13, x14, lsl #2
     8d4:      	ld1r.4s	{ v24 }, [x15]
     8d8:      	add	x15, x12, x14, lsl #5
     8dc:      	ldp	q25, q26, [x15]
     8e0:      	bit.16b	v26, v24, v0
     8e4:      	bif.16b	v24, v25, v1
     8e8:      	stp	q24, q26, [x15]
     8ec:      	add	x14, x14, #0x1
     8f0:      	cmp	x14, #0x300
     8f4:      	b.ne	0x8d0 <_llm_rows.packet_batch.blocks+0x544>
     8f8:      	mov	x12, #0x0               ; =0
     8fc:      	add	x13, x11, x12, lsl #2
     900:      	ld1r.4s	{ v24 }, [x13]
     904:      	add	x13, x10, x12, lsl #5
     908:      	ldp	q25, q26, [x13]
     90c:      	bit.16b	v26, v24, v0
     910:      	bif.16b	v24, v25, v1
     914:      	stp	q24, q26, [x13]
     918:      	add	x12, x12, #0x1
     91c:      	cmp	x12, #0x300
     920:      	b.ne	0x8fc <_llm_rows.packet_batch.blocks+0x570>
     924:      	fadd.4s	v19, v19, v23
     928:      	fadd.4s	v16, v16, v18
     92c:      	fadd.4s	v16, v16, v21
     930:      	fadd.4s	v18, v19, v20
     934:      	fadd.4s	v18, v18, v22
     938:      	fadd.4s	v16, v16, v17
     93c:      	fdiv.4s	v16, v16, v7
     940:      	fdiv.4s	v7, v18, v7
     944:      	mov	w10, #0xc5ac            ; =50604
     948:      	movk	w10, #0x3727, lsl #16
     94c:      	dup.4s	v17, w10
     950:      	fadd.4s	v7, v7, v17
     954:      	fadd.4s	v16, v16, v17
     958:      	fsqrt.4s	v16, v16
     95c:      	fsqrt.4s	v7, v7
     960:      	and.16b	v7, v1, v7
     964:      	and.16b	v16, v0, v16
     968:      	mov	x10, #-0x300            ; =-768
     96c:      	b	0x97c <_llm_rows.packet_batch.blocks+0x5f0>
     970:      	add	x8, x8, #0x20
     974:      	adds	x10, x10, #0x1
     978:      	b.hs	0x400 <_llm_rows.packet_batch.blocks+0x74>
     97c:      	fmov	w11, s6
     980:      	add	x12, x10, #0x300
     984:      	dup.2d	v17, x12
     988:      	add.2d	v18, v17, v5
     98c:      	ldr	q19, [x8, #0x6010]
     990:      	ldr	q20, [x8, #0x6000]
     994:      	and.16b	v20, v1, v20
     998:      	fdiv.4s	v21, v20, v7
     99c:      	ldr	q22, [x8, #0xc000]
     9a0:      	ldr	q20, [x8, #0xc010]
     9a4:      	and.16b	v22, v1, v22
     9a8:      	fmul.4s	v22, v21, v22
     9ac:      	add	x12, x8, #0x12, lsl #12 ; =0x12000
     9b0:      	ldp	q23, q21, [x12]
     9b4:      	and.16b	v23, v1, v23
     9b8:      	fadd.4s	v22, v22, v23
     9bc:      	shl.2d	v23, v18, #0x2
     9c0:      	dup.2d	v18, x9
     9c4:      	add.2d	v23, v18, v23
     9c8:      	tbnz	w11, #0x0, 0xa34 <_llm_rows.packet_batch.blocks+0x6a8>
     9cc:      	and	w11, w11, #0xff
     9d0:      	tbnz	w11, #0x1, 0xa44 <_llm_rows.packet_batch.blocks+0x6b8>
     9d4:      	add.2d	v23, v17, v3
     9d8:      	shl.2d	v23, v23, #0x2
     9dc:      	add.2d	v23, v18, v23
     9e0:      	tbnz	w11, #0x2, 0xa5c <_llm_rows.packet_batch.blocks+0x6d0>
     9e4:      	tbz	w11, #0x3, 0x9f0 <_llm_rows.packet_batch.blocks+0x664>
     9e8:      	mov.d	x12, v23[1]
     9ec:      	st1.s	{ v22 }[3], [x12]
     9f0:      	add.2d	v22, v17, v4
     9f4:      	and.16b	v19, v0, v19
     9f8:      	fdiv.4s	v19, v19, v16
     9fc:      	and.16b	v20, v0, v20
     a00:      	fmul.4s	v19, v19, v20
     a04:      	and.16b	v20, v0, v21
     a08:      	fadd.4s	v19, v19, v20
     a0c:      	shl.2d	v20, v22, #0x2
     a10:      	add.2d	v20, v18, v20
     a14:      	tbnz	w11, #0x4, 0xa6c <_llm_rows.packet_batch.blocks+0x6e0>
     a18:      	tbnz	w11, #0x5, 0xa78 <_llm_rows.packet_batch.blocks+0x6ec>
     a1c:      	add.2d	v17, v17, v2
     a20:      	shl.2d	v17, v17, #0x2
     a24:      	add.2d	v17, v18, v17
     a28:      	tbnz	w11, #0x6, 0xa90 <_llm_rows.packet_batch.blocks+0x704>
     a2c:      	tbz	w11, #0x7, 0x970 <_llm_rows.packet_batch.blocks+0x5e4>
     a30:      	b	0xa9c <_llm_rows.packet_batch.blocks+0x710>
     a34:      	fmov	x12, d23
     a38:      	str	s22, [x12]
     a3c:      	and	w11, w11, #0xff
     a40:      	tbz	w11, #0x1, 0x9d4 <_llm_rows.packet_batch.blocks+0x648>
     a44:      	mov.d	x12, v23[1]
     a48:      	st1.s	{ v22 }[1], [x12]
     a4c:      	add.2d	v23, v17, v3
     a50:      	shl.2d	v23, v23, #0x2
     a54:      	add.2d	v23, v18, v23
     a58:      	tbz	w11, #0x2, 0x9e4 <_llm_rows.packet_batch.blocks+0x658>
     a5c:      	fmov	x12, d23
     a60:      	st1.s	{ v22 }[2], [x12]
     a64:      	tbnz	w11, #0x3, 0x9e8 <_llm_rows.packet_batch.blocks+0x65c>
     a68:      	b	0x9f0 <_llm_rows.packet_batch.blocks+0x664>
     a6c:      	fmov	x12, d20
     a70:      	str	s19, [x12]
     a74:      	tbz	w11, #0x5, 0xa1c <_llm_rows.packet_batch.blocks+0x690>
     a78:      	mov.d	x12, v20[1]
     a7c:      	st1.s	{ v19 }[1], [x12]
     a80:      	add.2d	v17, v17, v2
     a84:      	shl.2d	v17, v17, #0x2
     a88:      	add.2d	v17, v18, v17
     a8c:      	tbz	w11, #0x6, 0xa2c <_llm_rows.packet_batch.blocks+0x6a0>
     a90:      	fmov	x12, d17
     a94:      	st1.s	{ v19 }[2], [x12]
     a98:      	tbz	w11, #0x7, 0x970 <_llm_rows.packet_batch.blocks+0x5e4>
     a9c:      	mov.d	x11, v17[1]
     aa0:      	st1.s	{ v19 }[3], [x11]
     aa4:      	b	0x970 <_llm_rows.packet_batch.blocks+0x5e4>
     aa8:      	ldp	x29, x30, [sp, #0xb0]
     aac:      	ldp	x20, x19, [sp, #0xa0]
     ab0:      	ldp	x22, x21, [sp, #0x90]
     ab4:      	ldp	x24, x23, [sp, #0x80]
     ab8:      	ldp	x26, x25, [sp, #0x70]
     abc:      	ldp	x28, x27, [sp, #0x60]
     ac0:      	ldp	d9, d8, [sp, #0x50]
     ac4:      	add	sp, sp, #0xc0
     ac8:      	ret

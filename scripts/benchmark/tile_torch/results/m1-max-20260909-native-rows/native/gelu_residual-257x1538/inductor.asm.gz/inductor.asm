
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/gelu_residual-257x1538/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0xb0
     6b4:      	stp	d9, d8, [sp, #0x60]
     6b8:      	stp	x24, x23, [sp, #0x70]
     6bc:      	stp	x22, x21, [sp, #0x80]
     6c0:      	stp	x20, x19, [sp, #0x90]
     6c4:      	stp	x29, x30, [sp, #0xa0]
     6c8:      	add	x29, sp, #0xa0
     6cc:      	mov	x19, x2
     6d0:      	mov	x20, x1
     6d4:      	mov	x21, x0
     6d8:      	mov	w23, #0x7fe             ; =2046
     6dc:      	movk	w23, #0x6, lsl #16
     6e0:      	adrp	x22, 0x4000 <dyld_stub_binder+0x4000>
     6e4:      	ldr	x22, [x22, #0x90]
     6e8:      	str	wzr, [sp, #0x40]
     6ec:      	add	x8, sp, #0x40
     6f0:      	str	x8, [x22]
     6f4:      	mov	x24, #-0x4              ; =-4
     6f8:      	mov	w8, #0x2713             ; =10003
     6fc:      	movk	w8, #0x3d37, lsl #16
     700:      	dup.4s	v1, w8
     704:      	mov	w8, #0x422a             ; =16938
     708:      	movk	w8, #0x3f4c, lsl #16
     70c:      	dup.4s	v0, w8
     710:      	stp	q0, q1, [sp]
     714:      	add	x24, x24, #0x4
     718:      	add	x8, x23, #0x2
     71c:      	cmp	x24, x8
     720:      	b.hs	0x7a4 <_kernel+0xf4>
     724:      	ldr	q0, [x21], #0x10
     728:      	ldr	q2, [x20], #0x10
     72c:      	movi.4s	v1, #0x3f, lsl #24
     730:      	fmul.4s	v1, v0, v1
     734:      	stp	q1, q2, [sp, #0x20]
     738:      	fmul.4s	v1, v0, v0
     73c:      	fmul.4s	v1, v0, v1
     740:      	ldr	q2, [sp, #0x10]
     744:      	fmul.4s	v1, v1, v2
     748:      	fadd.4s	v0, v0, v1
     74c:      	ldr	q1, [sp]
     750:      	fmul.4s	v0, v0, v1
     754:      	bl	0x1600 <dyld_stub_binder+0x1600>
     758:      	fmov.4s	v1, #1.00000000
     75c:      	fadd.4s	v0, v0, v1
     760:      	ldp	q2, q1, [sp, #0x20]
     764:      	fmul.4s	v0, v2, v0
     768:      	fadd.4s	v0, v1, v0
     76c:      	str	q0, [x19], #0x10
     770:      	cmp	x24, x23
     774:      	b.lo	0x714 <_kernel+0x64>
     778:      	str	xzr, [x22]
     77c:      	add	x8, sp, #0x40
     780:      	ldapr	w8, [x8]
     784:      	cbnz	w8, 0x810 <_kernel+0x160>
     788:      	ldp	x29, x30, [sp, #0xa0]
     78c:      	ldp	x20, x19, [sp, #0x90]
     790:      	ldp	x22, x21, [sp, #0x80]
     794:      	ldp	x24, x23, [sp, #0x70]
     798:      	ldp	d9, d8, [sp, #0x60]
     79c:      	add	sp, sp, #0xb0
     7a0:      	ret
     7a4:      	ldr	d2, [x21]
     7a8:      	str	q2, [sp, #0x30]
     7ac:      	ldr	d8, [x20]
     7b0:      	fmul.4s	v0, v2, v2
     7b4:      	fmul.4s	v0, v2, v0
     7b8:      	mov	w8, #0x2713             ; =10003
     7bc:      	movk	w8, #0x3d37, lsl #16
     7c0:      	dup.4s	v1, w8
     7c4:      	fmul.4s	v0, v0, v1
     7c8:      	fadd.4s	v0, v2, v0
     7cc:      	mov	w8, #0x422a             ; =16938
     7d0:      	movk	w8, #0x3f4c, lsl #16
     7d4:      	dup.4s	v1, w8
     7d8:      	fmul.4s	v0, v0, v1
     7dc:      	bl	0x1600 <dyld_stub_binder+0x1600>
     7e0:      	movi.2s	v1, #0x3f, lsl #24
     7e4:      	ldr	q2, [sp, #0x30]
     7e8:      	fmul.2s	v1, v2, v1
     7ec:      	fmov.2s	v2, #1.00000000
     7f0:      	fadd.2s	v0, v0, v2
     7f4:      	fmul.2s	v0, v1, v0
     7f8:      	fadd.2s	v0, v8, v0
     7fc:      	str	d0, [x19]
     800:      	str	xzr, [x22]
     804:      	add	x8, sp, #0x40
     808:      	ldapr	w8, [x8]
     80c:      	cbz	w8, 0x788 <_kernel+0xd8>
     810:      	mov	w0, #0x10               ; =16
     814:      	bl	0x16fc <dyld_stub_binder+0x16fc>
     818:      	mov	x19, x0
     81c:      	mov	w8, #0x33d              ; =829
     820:      	str	w8, [sp, #0x44]
     824:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x24>
     828:      	add	x0, x0, #0xa2c
     82c:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x24>
     830:      	add	x1, x1, #0xab8
     834:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x24>
     838:      	add	x3, x3, #0xae3
     83c:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x24>
     840:      	add	x4, x4, #0xb61
     844:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x24>
     848:      	add	x2, x2, #0xae0
     84c:      	add	x8, sp, #0x48
     850:      	add	x5, sp, #0x44
     854:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x24>
     858:      	add	x7, x7, #0xb63
     85c:      	mov	x6, x2
     860:      	bl	0x8d4 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     864:      	mov	w21, #0x1               ; =1
     868:      	add	x1, sp, #0x48
     86c:      	mov	x0, x19
     870:      	bl	0x1648 <dyld_stub_binder+0x1648>
     874:      	mov	w21, #0x0               ; =0
     878:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     87c:      	ldr	x1, [x1, #0x18]
     880:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     884:      	ldr	x2, [x2, #0x8]
     888:      	mov	x0, x19
     88c:      	bl	0x172c <dyld_stub_binder+0x172c>
     890:      	brk	#0x1
     894:      	mov	x20, x0
     898:      	ldrsb	w8, [sp, #0x5f]
     89c:      	tbz	w8, #0x1f, 0x8b8 <_kernel+0x208>
     8a0:      	ldr	x0, [sp, #0x48]
     8a4:      	ldr	x8, [sp, #0x58]
     8a8:      	and	x1, x8, #0x7fffffffffffffff
     8ac:      	bl	0x16e4 <dyld_stub_binder+0x16e4>
     8b0:      	tbnz	w21, #0x0, 0x8c4 <_kernel+0x214>
     8b4:      	b	0x8cc <_kernel+0x21c>
     8b8:      	cbnz	w21, 0x8c4 <_kernel+0x214>
     8bc:      	b	0x8cc <_kernel+0x21c>
     8c0:      	mov	x20, x0
     8c4:      	mov	x0, x19
     8c8:      	bl	0x1720 <dyld_stub_binder+0x1720>
     8cc:      	mov	x0, x20
     8d0:      	bl	0x160c <dyld_stub_binder+0x160c>

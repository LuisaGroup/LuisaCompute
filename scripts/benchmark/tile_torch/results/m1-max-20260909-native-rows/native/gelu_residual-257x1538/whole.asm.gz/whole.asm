
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/gelu_residual-257x1538-l1/object/tile_xir_w8_80779_1788919116892242_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x130
       4:      	stp	d15, d14, [sp, #0xe0]
       8:      	stp	d13, d12, [sp, #0xf0]
       c:      	stp	d11, d10, [sp, #0x100]
      10:      	stp	d9, d8, [sp, #0x110]
      14:      	stp	x28, x27, [sp, #0x120]
      18:      	mov	x10, #0x0               ; =0
      1c:      	ldr	x8, [x1, #0x88]
      20:      	ldr	x12, [x0]
      24:      	ldr	w9, [x1]
      28:      	ldr	w11, [x1, #0x24]
      2c:      	add	w13, w11, w9, lsl #5
      30:      	ldr	x11, [x0, #0x10]
      34:      	ldr	x9, [x0, #0x30]
      38:      	dup.4s	v0, w13
      3c:      	adrp	x13, 0x0 <ltmp0>
      40:      	ldr	q1, [x13]
      44:      	add.4s	v2, v0, v1
      48:      	adrp	x13, 0x0 <ltmp0>
      4c:      	ldr	q1, [x13]
      50:      	add.4s	v3, v0, v1
      54:      	mov	w13, #0x602             ; =1538
      58:      	dup.4s	v4, w13
      5c:      	umull2.2d	v0, v2, v4
      60:      	umull2.2d	v1, v3, v4
      64:      	umull.2d	v2, v2, v4
      68:      	umull.2d	v3, v3, v4
      6c:      	dup.2d	v4, x12
      70:      	dup.2d	v5, x10
      74:      	add.2d	v6, v5, v0
      78:      	add.2d	v7, v5, v2
      7c:      	add.2d	v16, v5, v1
      80:      	add.2d	v5, v5, v3
      84:      	shl.2d	v5, v5, #0x2
      88:      	shl.2d	v16, v16, #0x2
      8c:      	shl.2d	v7, v7, #0x2
      90:      	shl.2d	v6, v6, #0x2
      94:      	add.2d	v6, v4, v6
      98:      	add.2d	v7, v4, v7
      9c:      	add.2d	v16, v4, v16
      a0:      	add.2d	v5, v4, v5
      a4:      	mov.d	x12, v5[1]
      a8:      	fmov	x13, d5
      ac:      	mov.d	x14, v16[1]
      b0:      	fmov	x15, d16
      b4:      	mov.d	x16, v7[1]
      b8:      	fmov	x17, d7
      bc:      	mov.d	x0, v6[1]
      c0:      	ldr	s5, [x13]
      c4:      	ld1.s	{ v5 }[1], [x12]
      c8:      	fmov	x12, d6
      cc:      	ld1.s	{ v5 }[2], [x15]
      d0:      	ld1.s	{ v5 }[3], [x14]
      d4:      	ldr	s6, [x17]
      d8:      	ld1.s	{ v6 }[1], [x16]
      dc:      	ld1.s	{ v6 }[2], [x12]
      e0:      	ld1.s	{ v6 }[3], [x0]
      e4:      	add	x12, x8, x10, lsl #5
      e8:      	stp	q5, q6, [x12]
      ec:      	add	x10, x10, #0x1
      f0:      	cmp	x10, #0x602
      f4:      	b.ne	0x70 <ltmp0+0x70>
      f8:      	mov	x10, #0x0               ; =0
      fc:      	mov	w12, #0xc040            ; =49216
     100:      	add	x12, x8, x12
     104:      	dup.2d	v4, x11
     108:      	dup.2d	v5, x10
     10c:      	add.2d	v6, v5, v0
     110:      	add.2d	v7, v5, v2
     114:      	add.2d	v16, v5, v1
     118:      	add.2d	v5, v5, v3
     11c:      	shl.2d	v5, v5, #0x2
     120:      	shl.2d	v16, v16, #0x2
     124:      	shl.2d	v7, v7, #0x2
     128:      	shl.2d	v6, v6, #0x2
     12c:      	add.2d	v6, v4, v6
     130:      	add.2d	v7, v4, v7
     134:      	add.2d	v16, v4, v16
     138:      	add.2d	v5, v4, v5
     13c:      	mov.d	x11, v5[1]
     140:      	fmov	x13, d5
     144:      	mov.d	x14, v16[1]
     148:      	fmov	x15, d16
     14c:      	mov.d	x16, v7[1]
     150:      	fmov	x17, d7
     154:      	mov.d	x0, v6[1]
     158:      	ldr	s5, [x13]
     15c:      	ld1.s	{ v5 }[1], [x11]
     160:      	fmov	x11, d6
     164:      	ld1.s	{ v5 }[2], [x15]
     168:      	ld1.s	{ v5 }[3], [x14]
     16c:      	ldr	s6, [x17]
     170:      	ld1.s	{ v6 }[1], [x16]
     174:      	ld1.s	{ v6 }[2], [x11]
     178:      	ld1.s	{ v6 }[3], [x0]
     17c:      	add	x11, x12, x10, lsl #5
     180:      	stp	q5, q6, [x11]
     184:      	add	x10, x10, #0x1
     188:      	cmp	x10, #0x602
     18c:      	b.ne	0x108 <ltmp0+0x108>
     190:      	mov	x10, #-0x602            ; =-1538
     194:      	mov	w11, #0x2713            ; =10003
     198:      	movk	w11, #0x3d37, lsl #16
     19c:      	dup.4s	v5, w11
     1a0:      	mov	w11, #0x422a            ; =16938
     1a4:      	movk	w11, #0x3f4c, lsl #16
     1a8:      	dup.4s	v4, w11
     1ac:      	stp	q4, q5, [sp, #0xc0]
     1b0:      	fmov.4s	v18, #1.00000000
     1b4:      	mov	w11, #0x9231            ; =37425
     1b8:      	movk	w11, #0x2f30, lsl #16
     1bc:      	dup.4s	v5, w11
     1c0:      	mov	w11, #0x322b            ; =12843
     1c4:      	movk	w11, #0x32d7, lsl #16
     1c8:      	dup.4s	v4, w11
     1cc:      	stp	q4, q5, [sp, #0xa0]
     1d0:      	mov	w11, #0xef1d            ; =61213
     1d4:      	movk	w11, #0x3638, lsl #16
     1d8:      	dup.4s	v5, w11
     1dc:      	mov	w11, #0xd01             ; =3329
     1e0:      	movk	w11, #0x3950, lsl #16
     1e4:      	dup.4s	v4, w11
     1e8:      	stp	q4, q5, [sp, #0x80]
     1ec:      	mov	w11, #0x8889            ; =34953
     1f0:      	movk	w11, #0x3c08, lsl #16
     1f4:      	dup.4s	v5, w11
     1f8:      	mov	w11, #0xaaab            ; =43691
     1fc:      	movk	w11, #0x3e2a, lsl #16
     200:      	dup.4s	v23, w11
     204:      	mov	w11, #0x76c7            ; =30407
     208:      	movk	w11, #0x310f, lsl #16
     20c:      	dup.4s	v4, w11
     210:      	stp	q4, q5, [sp, #0x60]
     214:      	mov	w11, #0xf27e            ; =62078
     218:      	movk	w11, #0x3493, lsl #16
     21c:      	dup.4s	v5, w11
     220:      	mov	w11, #0xd01             ; =3329
     224:      	movk	w11, #0x37d0, lsl #16
     228:      	dup.4s	v4, w11
     22c:      	stp	q4, q5, [sp, #0x40]
     230:      	mov	w11, #0xb61             ; =2913
     234:      	movk	w11, #0x3ab6, lsl #16
     238:      	dup.4s	v5, w11
     23c:      	mov	w11, #0xaaab            ; =43691
     240:      	movk	w11, #0x3d2a, lsl #16
     244:      	dup.4s	v4, w11
     248:      	stp	q4, q5, [sp, #0x20]
     24c:      	mov	w11, #-0x3d300000       ; =-1026555904
     250:      	dup.4s	v5, w11
     254:      	mov	w11, #0x42c80000        ; =1120403456
     258:      	dup.4s	v28, w11
     25c:      	fmov.4s	v4, #9.00000000
     260:      	stp	q4, q5, [sp]
     264:      	mov	w11, #0xaa3b            ; =43579
     268:      	movk	w11, #0x3fb8, lsl #16
     26c:      	dup.4s	v30, w11
     270:      	mov	w11, #0x7200            ; =29184
     274:      	movk	w11, #0xbf31, lsl #16
     278:      	mov	w12, #0xbe8e            ; =48782
     27c:      	movk	w12, #0xb5bf, lsl #16
     280:      	mov	w13, #0x2bda            ; =11226
     284:      	movk	w13, #0x3950, lsl #16
     288:      	mov	w14, #0x96c9            ; =38601
     28c:      	movk	w14, #0x3ab6, lsl #16
     290:      	mov	w15, #0x88a6            ; =34982
     294:      	movk	w15, #0x3c08, lsl #16
     298:      	mov	w16, #0xaa7a            ; =43642
     29c:      	movk	w16, #0x3d2a, lsl #16
     2a0:      	mvni.4s	v4, #0x7f, msl #16
     2a4:      	fneg.4s	v10, v4
     2a8:      	mvni.4s	v4, #0x3f, msl #16
     2ac:      	fneg.4s	v12, v4
     2b0:      	ldp	q14, q13, [x8]
     2b4:      	ldp	q6, q5, [sp, #0xc0]
     2b8:      	fmul.4s	v4, v13, v5
     2bc:      	fmul.4s	v5, v14, v5
     2c0:      	fmul.4s	v5, v14, v5
     2c4:      	fmul.4s	v4, v13, v4
     2c8:      	fmul.4s	v4, v13, v4
     2cc:      	fmul.4s	v5, v14, v5
     2d0:      	fadd.4s	v5, v14, v5
     2d4:      	fadd.4s	v4, v13, v4
     2d8:      	fmul.4s	v31, v4, v6
     2dc:      	fmul.4s	v15, v5, v6
     2e0:      	fabs.4s	v9, v15
     2e4:      	fabs.4s	v8, v31
     2e8:      	fmul.4s	v16, v31, v31
     2ec:      	fmul.4s	v19, v15, v15
     2f0:      	ldp	q5, q6, [sp, #0xa0]
     2f4:      	mov.16b	v4, v5
     2f8:      	fmla.4s	v4, v16, v6
     2fc:      	fmla.4s	v5, v19, v6
     300:      	ldr	q7, [sp, #0x90]
     304:      	mov.16b	v6, v7
     308:      	fmla.4s	v6, v16, v4
     30c:      	mov.16b	v4, v7
     310:      	fmla.4s	v4, v19, v5
     314:      	ldp	q17, q7, [sp, #0x70]
     318:      	mov.16b	v5, v7
     31c:      	fmla.4s	v5, v16, v6
     320:      	fmla.4s	v7, v19, v4
     324:      	mov.16b	v4, v17
     328:      	mov.16b	v21, v23
     32c:      	fmla.4s	v4, v16, v5
     330:      	mov.16b	v22, v23
     334:      	mov.16b	v20, v18
     338:      	mov.16b	v6, v18
     33c:      	ldp	q25, q24, [sp, #0x50]
     340:      	mov.16b	v5, v25
     344:      	fmla.4s	v5, v19, v24
     348:      	fmla.4s	v17, v19, v7
     34c:      	mov.16b	v7, v25
     350:      	fmla.4s	v7, v16, v24
     354:      	ldr	q24, [sp, #0x40]
     358:      	mov.16b	v11, v24
     35c:      	fmla.4s	v11, v19, v5
     360:      	mov.16b	v5, v24
     364:      	fmla.4s	v21, v16, v4
     368:      	fmla.4s	v5, v16, v7
     36c:      	ldr	q7, [sp, #0x30]
     370:      	mov.16b	v4, v7
     374:      	fmla.4s	v4, v19, v11
     378:      	fmla.4s	v7, v16, v5
     37c:      	fmla.4s	v22, v19, v17
     380:      	ldr	q17, [sp, #0x20]
     384:      	mov.16b	v5, v17
     388:      	fmla.4s	v5, v19, v4
     38c:      	mov.16b	v4, v17
     390:      	fmla.4s	v4, v16, v7
     394:      	movi.4s	v24, #0x3f, lsl #24
     398:      	fmla.4s	v24, v19, v5
     39c:      	movi.4s	v25, #0x3f, lsl #24
     3a0:      	fmla.4s	v25, v16, v4
     3a4:      	ldp	q4, q7, [sp]
     3a8:      	fcmge.4s	v11, v4, v8
     3ac:      	fcmge.4s	v5, v4, v9
     3b0:      	and.16b	v17, v5, v9
     3b4:      	fmla.4s	v20, v16, v21
     3b8:      	and.16b	v4, v11, v8
     3bc:      	fcmge.4s	v21, v4, v7
     3c0:      	fcmge.4s	v27, v17, v7
     3c4:      	fcmge.4s	v26, v28, v4
     3c8:      	fcmge.4s	v29, v28, v17
     3cc:      	mov.16b	v7, v18
     3d0:      	and.16b	v27, v27, v29
     3d4:      	and.16b	v21, v21, v26
     3d8:      	and.16b	v21, v21, v4
     3dc:      	and.16b	v26, v27, v17
     3e0:      	fmul.4s	v27, v26, v30
     3e4:      	fmla.4s	v6, v19, v22
     3e8:      	fmul.4s	v22, v21, v30
     3ec:      	movi.4s	v29, #0x4b, lsl #24
     3f0:      	fadd.4s	v22, v22, v29
     3f4:      	fadd.4s	v27, v27, v29
     3f8:      	movi.4s	v29, #0xcb, lsl #24
     3fc:      	fadd.4s	v27, v27, v29
     400:      	fadd.4s	v22, v22, v29
     404:      	fmla.4s	v7, v19, v24
     408:      	fcvtzs.4s	v19, v22
     40c:      	fcvtzs.4s	v22, v27
     410:      	scvtf.4s	v24, v22
     414:      	dup.4s	v27, w11
     418:      	fmul.4s	v29, v24, v27
     41c:      	fadd.4s	v26, v26, v29
     420:      	scvtf.4s	v29, v19
     424:      	fmul.4s	v27, v29, v27
     428:      	fadd.4s	v21, v21, v27
     42c:      	dup.4s	v27, w12
     430:      	fmul.4s	v24, v24, v27
     434:      	fmul.4s	v27, v29, v27
     438:      	fadd.4s	v21, v21, v27
     43c:      	mov.16b	v27, v18
     440:      	fadd.4s	v24, v26, v24
     444:      	fmla.4s	v27, v16, v25
     448:      	dup.4s	v16, w13
     44c:      	fmul.4s	v25, v24, v16
     450:      	dup.4s	v26, w14
     454:      	fmul.4s	v16, v21, v16
     458:      	fadd.4s	v16, v16, v26
     45c:      	fadd.4s	v25, v25, v26
     460:      	fmul.4s	v25, v24, v25
     464:      	dup.4s	v26, w15
     468:      	fmul.4s	v16, v21, v16
     46c:      	fadd.4s	v16, v16, v26
     470:      	fadd.4s	v25, v25, v26
     474:      	fmul.4s	v25, v24, v25
     478:      	dup.4s	v26, w16
     47c:      	fmul.4s	v16, v21, v16
     480:      	fadd.4s	v16, v16, v26
     484:      	fadd.4s	v25, v25, v26
     488:      	fmul.4s	v20, v8, v20
     48c:      	fmul.4s	v25, v24, v25
     490:      	fmul.4s	v16, v21, v16
     494:      	fadd.4s	v16, v16, v23
     498:      	fadd.4s	v25, v25, v23
     49c:      	fmul.4s	v25, v24, v25
     4a0:      	fmul.4s	v16, v21, v16
     4a4:      	movi.4s	v29, #0x3f, lsl #24
     4a8:      	fadd.4s	v26, v16, v29
     4ac:      	fadd.4s	v25, v25, v29
     4b0:      	fdiv.4s	v16, v20, v27
     4b4:      	fmul.4s	v20, v24, v24
     4b8:      	fmul.4s	v20, v20, v25
     4bc:      	fmul.4s	v25, v21, v21
     4c0:      	fmul.4s	v25, v25, v26
     4c4:      	fmul.4s	v6, v9, v6
     4c8:      	fdiv.4s	v6, v6, v7
     4cc:      	fadd.4s	v7, v21, v25
     4d0:      	fadd.4s	v20, v24, v20
     4d4:      	movi.2d	v25, #0xffffffffffffffff
     4d8:      	add.4s	v21, v22, v25
     4dc:      	sshr.4s	v22, v21, #0x1
     4e0:      	shl.4s	v24, v22, #0x17
     4e4:      	fadd.4s	v20, v20, v18
     4e8:      	add.4s	v24, v24, v18
     4ec:      	fmul.4s	v20, v20, v24
     4f0:      	sub.4s	v21, v21, v22
     4f4:      	shl.4s	v21, v21, #0x17
     4f8:      	add.4s	v21, v21, v18
     4fc:      	fmul.4s	v20, v20, v21
     500:      	fcmgt.4s	v17, v17, v28
     504:      	bsl.16b	v17, v10, v20
     508:      	fmov.4s	v20, #0.25000000
     50c:      	fdiv.4s	v21, v20, v17
     510:      	fsub.4s	v22, v17, v21
     514:      	fadd.4s	v17, v17, v21
     518:      	fdiv.4s	v17, v22, v17
     51c:      	bsl.16b	v5, v17, v18
     520:      	fcmge.4s	v17, v18, v9
     524:      	fadd.4s	v7, v7, v18
     528:      	add.4s	v19, v19, v25
     52c:      	bit.16b	v5, v6, v17
     530:      	sshr.4s	v6, v19, #0x1
     534:      	shl.4s	v17, v6, #0x17
     538:      	add.4s	v17, v17, v18
     53c:      	fmul.4s	v7, v7, v17
     540:      	sub.4s	v6, v19, v6
     544:      	shl.4s	v6, v6, #0x17
     548:      	add.4s	v6, v6, v18
     54c:      	fmul.4s	v6, v7, v6
     550:      	fcmgt.4s	v4, v4, v28
     554:      	bsl.16b	v4, v10, v6
     558:      	fdiv.4s	v6, v20, v4
     55c:      	fsub.4s	v7, v4, v6
     560:      	fadd.4s	v4, v4, v6
     564:      	fdiv.4s	v4, v7, v4
     568:      	bif.16b	v4, v18, v11
     56c:      	fcmge.4s	v6, v18, v8
     570:      	bit.16b	v4, v16, v6
     574:      	add	x17, x10, #0x602
     578:      	dup.2d	v6, x17
     57c:      	mvni.4s	v16, #0x80, lsl #24
     580:      	bif.16b	v4, v31, v16
     584:      	fcmeq.4s	v7, v31, v31
     588:      	fadd.4s	v4, v4, v18
     58c:      	bif.16b	v4, v12, v7
     590:      	add.2d	v7, v6, v0
     594:      	bif.16b	v5, v15, v16
     598:      	fcmeq.4s	v16, v15, v15
     59c:      	fadd.4s	v5, v5, v18
     5a0:      	bif.16b	v5, v12, v16
     5a4:      	add.2d	v16, v6, v2
     5a8:      	fmul.4s	v17, v14, v29
     5ac:      	fmul.4s	v5, v17, v5
     5b0:      	add.2d	v17, v6, v1
     5b4:      	add.2d	v6, v6, v3
     5b8:      	fmul.4s	v19, v13, v29
     5bc:      	fmul.4s	v4, v19, v4
     5c0:      	ldr	q19, [x8, #0xc050]
     5c4:      	fadd.4s	v4, v19, v4
     5c8:      	ldr	q19, [x8, #0xc040]
     5cc:      	shl.2d	v6, v6, #0x2
     5d0:      	shl.2d	v17, v17, #0x2
     5d4:      	fadd.4s	v5, v19, v5
     5d8:      	shl.2d	v16, v16, #0x2
     5dc:      	shl.2d	v7, v7, #0x2
     5e0:      	dup.2d	v19, x9
     5e4:      	add.2d	v7, v19, v7
     5e8:      	add.2d	v16, v19, v16
     5ec:      	add.2d	v17, v19, v17
     5f0:      	add.2d	v6, v19, v6
     5f4:      	mov.d	x17, v6[1]
     5f8:      	mov.d	x0, v17[1]
     5fc:      	fmov	x1, d6
     600:      	fmov	x2, d17
     604:      	mov.d	x3, v16[1]
     608:      	fmov	x4, d16
     60c:      	str	s5, [x1]
     610:      	st1.s	{ v5 }[1], [x17]
     614:      	st1.s	{ v5 }[2], [x2]
     618:      	st1.s	{ v5 }[3], [x0]
     61c:      	mov.d	x17, v7[1]
     620:      	fmov	x0, d7
     624:      	str	s4, [x4]
     628:      	st1.s	{ v4 }[1], [x3]
     62c:      	st1.s	{ v4 }[2], [x0]
     630:      	st1.s	{ v4 }[3], [x17]
     634:      	add	x8, x8, #0x20
     638:      	adds	x10, x10, #0x1
     63c:      	b.lo	0x2b0 <ltmp0+0x2b0>
     640:      	ldp	x28, x27, [sp, #0x120]
     644:      	ldp	d9, d8, [sp, #0x110]
     648:      	ldp	d11, d10, [sp, #0x100]
     64c:      	ldp	d13, d12, [sp, #0xf0]
     650:      	ldp	d15, d14, [sp, #0xe0]
     654:      	add	sp, sp, #0x130
     658:      	ret

000000000000065c <_llm_rows.packet_batch.blocks>:
     65c:      	stp	d15, d14, [sp, #-0xa0]!
     660:      	stp	d13, d12, [sp, #0x10]
     664:      	stp	d11, d10, [sp, #0x20]
     668:      	stp	d9, d8, [sp, #0x30]
     66c:      	stp	x28, x27, [sp, #0x40]
     670:      	stp	x26, x25, [sp, #0x50]
     674:      	stp	x24, x23, [sp, #0x60]
     678:      	stp	x22, x21, [sp, #0x70]
     67c:      	stp	x20, x19, [sp, #0x80]
     680:      	stp	x29, x30, [sp, #0x90]
     684:      	sub	sp, sp, #0x160
     688:      	str	x0, [sp, #0x68]
     68c:      	cbz	w3, 0x1190 <_llm_rows.packet_batch.blocks+0xb34>
     690:      	mov	x23, x3
     694:      	mov	x20, x2
     698:      	mov	w22, #0x0               ; =0
     69c:      	ldp	w9, w8, [x2, #0x2c]
     6a0:      	stp	w8, w9, [sp, #0x60]
     6a4:      	mov	w8, #0x602              ; =1538
     6a8:      	ldp	w27, w26, [x2]
     6ac:      	mov	w16, #0x2713            ; =10003
     6b0:      	movk	w16, #0x3d37, lsl #16
     6b4:      	mov	w17, #0x422a            ; =16938
     6b8:      	movk	w17, #0x3f4c, lsl #16
     6bc:      	mov	w0, #0x9231             ; =37425
     6c0:      	movk	w0, #0x2f30, lsl #16
     6c4:      	ldp	w24, w19, [x2, #0x8]
     6c8:      	mov	w1, #0x322b             ; =12843
     6cc:      	movk	w1, #0x32d7, lsl #16
     6d0:      	adrp	x9, 0x0 <ltmp0>
     6d4:      	ldr	q0, [x9]
     6d8:      	str	q0, [sp, #0x50]
     6dc:      	mov	w2, #0xef1d             ; =61213
     6e0:      	movk	w2, #0x3638, lsl #16
     6e4:      	adrp	x9, 0x0 <ltmp0>
     6e8:      	ldr	q0, [x9]
     6ec:      	str	q0, [sp, #0x40]
     6f0:      	mov	w3, #0xd01              ; =3329
     6f4:      	movk	w3, #0x3950, lsl #16
     6f8:      	dup.4s	v0, w8
     6fc:      	str	q0, [sp, #0x20]
     700:      	mov	w4, #0x8889             ; =34953
     704:      	movk	w4, #0x3c08, lsl #16
     708:      	adrp	x8, 0x0 <ltmp0>
     70c:      	ldr	q0, [x8]
     710:      	str	q0, [sp, #0x10]
     714:      	mov	w5, #0xaaab             ; =43691
     718:      	movk	w5, #0x3e2a, lsl #16
     71c:      	mov	w6, #0x76c7             ; =30407
     720:      	movk	w6, #0x310f, lsl #16
     724:      	mov	w7, #0xf27e             ; =62078
     728:      	movk	w7, #0x3493, lsl #16
     72c:      	mov	w30, #0xd01             ; =3329
     730:      	movk	w30, #0x37d0, lsl #16
     734:      	mvni.4s	v0, #0x7f, msl #16
     738:      	fneg.4s	v1, v0
     73c:      	mvni.4s	v0, #0x3f, msl #16
     740:      	fneg.4s	v0, v0
     744:      	stp	q0, q1, [sp, #0x120]
     748:      	mov	w25, #0x88a6            ; =34982
     74c:      	movk	w25, #0x3c08, lsl #16
     750:      	mov	w28, #0xaa7a            ; =43642
     754:      	movk	w28, #0x3d2a, lsl #16
     758:      	str	w23, [sp, #0x3c]
     75c:      	b	0x7a4 <_llm_rows.packet_batch.blocks+0x148>
     760:      	mov	w8, #0x18               ; =24
     764:      	str	w8, [x20, #0x24]
     768:      	ldr	w23, [sp, #0x3c]
     76c:      	add	w8, w27, #0x1
     770:      	ldp	w10, w9, [sp, #0x60]
     774:      	cmp	w8, w9
     778:      	cset	w8, eq
     77c:      	csinc	w27, wzr, w27, eq
     780:      	cinc	w9, w26, eq
     784:      	cmp	w9, w10
     788:      	cset	w10, eq
     78c:      	ands	w8, w8, w10
     790:      	csel	w26, wzr, w9, ne
     794:      	add	w24, w24, w8
     798:      	add	w22, w22, #0x1
     79c:      	cmp	w22, w23
     7a0:      	b.eq	0x1190 <_llm_rows.packet_batch.blocks+0xb34>
     7a4:      	ubfiz	x8, x27, #5, #32
     7a8:      	cmp	x8, x19
     7ac:      	csel	x9, x8, xzr, ls
     7b0:      	subs	x10, x19, x9
     7b4:      	cmp	x10, #0x20
     7b8:      	mov	w11, #0x20              ; =32
     7bc:      	csel	x10, x10, x11, lo
     7c0:      	cmp	x19, x9
     7c4:      	stp	w27, w26, [x20]
     7c8:      	str	w24, [x20, #0x8]
     7cc:      	str	wzr, [x20, #0x24]
     7d0:      	ccmp	x8, x19, #0x2, hi
     7d4:      	csel	x21, x10, xzr, ls
     7d8:      	cmp	x21, #0x20
     7dc:      	b.lo	0x888 <_llm_rows.packet_batch.blocks+0x22c>
     7e0:      	ldr	x21, [sp, #0x68]
     7e4:      	mov	x0, x21
     7e8:      	mov	x1, x20
     7ec:      	bl	0x7ec <_llm_rows.packet_batch.blocks+0x190>
     7f0:      	mov	w8, #0x8                ; =8
     7f4:      	str	w8, [x20, #0x24]
     7f8:      	mov	x0, x21
     7fc:      	mov	x1, x20
     800:      	bl	0x800 <_llm_rows.packet_batch.blocks+0x1a4>
     804:      	mov	w8, #0x10               ; =16
     808:      	str	w8, [x20, #0x24]
     80c:      	mov	x0, x21
     810:      	mov	x1, x20
     814:      	bl	0x814 <_llm_rows.packet_batch.blocks+0x1b8>
     818:      	mov	w8, #0x18               ; =24
     81c:      	str	w8, [x20, #0x24]
     820:      	mov	x0, x21
     824:      	mov	x1, x20
     828:      	bl	0x828 <_llm_rows.packet_batch.blocks+0x1cc>
     82c:      	mov	w30, #0xd01             ; =3329
     830:      	movk	w30, #0x37d0, lsl #16
     834:      	mov	w7, #0xf27e             ; =62078
     838:      	movk	w7, #0x3493, lsl #16
     83c:      	mov	w6, #0x76c7             ; =30407
     840:      	movk	w6, #0x310f, lsl #16
     844:      	mov	w5, #0xaaab             ; =43691
     848:      	movk	w5, #0x3e2a, lsl #16
     84c:      	mov	w4, #0x8889             ; =34953
     850:      	movk	w4, #0x3c08, lsl #16
     854:      	mov	w3, #0xd01              ; =3329
     858:      	movk	w3, #0x3950, lsl #16
     85c:      	mov	w2, #0xef1d             ; =61213
     860:      	movk	w2, #0x3638, lsl #16
     864:      	mov	w1, #0x322b             ; =12843
     868:      	movk	w1, #0x32d7, lsl #16
     86c:      	mov	w0, #0x9231             ; =37425
     870:      	movk	w0, #0x2f30, lsl #16
     874:      	mov	w17, #0x422a            ; =16938
     878:      	movk	w17, #0x3f4c, lsl #16
     87c:      	mov	w16, #0x2713            ; =10003
     880:      	movk	w16, #0x3d37, lsl #16
     884:      	b	0x76c <_llm_rows.packet_batch.blocks+0x110>
     888:      	lsr	x23, x21, #3
     88c:      	cmp	x21, #0x8
     890:      	b.lo	0x9e4 <_llm_rows.packet_batch.blocks+0x388>
     894:      	str	wzr, [x20, #0x24]
     898:      	ldr	x0, [sp, #0x68]
     89c:      	mov	x1, x20
     8a0:      	bl	0x8a0 <_llm_rows.packet_batch.blocks+0x244>
     8a4:      	mov	w30, #0xd01             ; =3329
     8a8:      	movk	w30, #0x37d0, lsl #16
     8ac:      	mov	w7, #0xf27e             ; =62078
     8b0:      	movk	w7, #0x3493, lsl #16
     8b4:      	mov	w6, #0x76c7             ; =30407
     8b8:      	movk	w6, #0x310f, lsl #16
     8bc:      	mov	w5, #0xaaab             ; =43691
     8c0:      	movk	w5, #0x3e2a, lsl #16
     8c4:      	mov	w4, #0x8889             ; =34953
     8c8:      	movk	w4, #0x3c08, lsl #16
     8cc:      	mov	w3, #0xd01              ; =3329
     8d0:      	movk	w3, #0x3950, lsl #16
     8d4:      	mov	w2, #0xef1d             ; =61213
     8d8:      	movk	w2, #0x3638, lsl #16
     8dc:      	mov	w1, #0x322b             ; =12843
     8e0:      	movk	w1, #0x32d7, lsl #16
     8e4:      	mov	w0, #0x9231             ; =37425
     8e8:      	movk	w0, #0x2f30, lsl #16
     8ec:      	mov	w17, #0x422a            ; =16938
     8f0:      	movk	w17, #0x3f4c, lsl #16
     8f4:      	mov	w16, #0x2713            ; =10003
     8f8:      	movk	w16, #0x3d37, lsl #16
     8fc:      	cmp	x23, #0x1
     900:      	b.eq	0x9e4 <_llm_rows.packet_batch.blocks+0x388>
     904:      	mov	w8, #0x8                ; =8
     908:      	str	w8, [x20, #0x24]
     90c:      	ldr	x0, [sp, #0x68]
     910:      	mov	x1, x20
     914:      	bl	0x914 <_llm_rows.packet_batch.blocks+0x2b8>
     918:      	mov	w30, #0xd01             ; =3329
     91c:      	movk	w30, #0x37d0, lsl #16
     920:      	mov	w7, #0xf27e             ; =62078
     924:      	movk	w7, #0x3493, lsl #16
     928:      	mov	w6, #0x76c7             ; =30407
     92c:      	movk	w6, #0x310f, lsl #16
     930:      	mov	w5, #0xaaab             ; =43691
     934:      	movk	w5, #0x3e2a, lsl #16
     938:      	mov	w4, #0x8889             ; =34953
     93c:      	movk	w4, #0x3c08, lsl #16
     940:      	mov	w3, #0xd01              ; =3329
     944:      	movk	w3, #0x3950, lsl #16
     948:      	mov	w2, #0xef1d             ; =61213
     94c:      	movk	w2, #0x3638, lsl #16
     950:      	mov	w1, #0x322b             ; =12843
     954:      	movk	w1, #0x32d7, lsl #16
     958:      	mov	w0, #0x9231             ; =37425
     95c:      	movk	w0, #0x2f30, lsl #16
     960:      	mov	w17, #0x422a            ; =16938
     964:      	movk	w17, #0x3f4c, lsl #16
     968:      	mov	w16, #0x2713            ; =10003
     96c:      	movk	w16, #0x3d37, lsl #16
     970:      	cmp	x23, #0x2
     974:      	b.eq	0x9e4 <_llm_rows.packet_batch.blocks+0x388>
     978:      	mov	w8, #0x10               ; =16
     97c:      	str	w8, [x20, #0x24]
     980:      	ldr	x0, [sp, #0x68]
     984:      	mov	x1, x20
     988:      	bl	0x988 <_llm_rows.packet_batch.blocks+0x32c>
     98c:      	mov	w30, #0xd01             ; =3329
     990:      	movk	w30, #0x37d0, lsl #16
     994:      	mov	w7, #0xf27e             ; =62078
     998:      	movk	w7, #0x3493, lsl #16
     99c:      	mov	w6, #0x76c7             ; =30407
     9a0:      	movk	w6, #0x310f, lsl #16
     9a4:      	mov	w5, #0xaaab             ; =43691
     9a8:      	movk	w5, #0x3e2a, lsl #16
     9ac:      	mov	w4, #0x8889             ; =34953
     9b0:      	movk	w4, #0x3c08, lsl #16
     9b4:      	mov	w3, #0xd01              ; =3329
     9b8:      	movk	w3, #0x3950, lsl #16
     9bc:      	mov	w2, #0xef1d             ; =61213
     9c0:      	movk	w2, #0x3638, lsl #16
     9c4:      	mov	w1, #0x322b             ; =12843
     9c8:      	movk	w1, #0x32d7, lsl #16
     9cc:      	mov	w0, #0x9231             ; =37425
     9d0:      	movk	w0, #0x2f30, lsl #16
     9d4:      	mov	w17, #0x422a            ; =16938
     9d8:      	movk	w17, #0x3f4c, lsl #16
     9dc:      	mov	w16, #0x2713            ; =10003
     9e0:      	movk	w16, #0x3d37, lsl #16
     9e4:      	and	w8, w21, #0x7
     9e8:      	mov	w21, #0xb61             ; =2913
     9ec:      	movk	w21, #0x3ab6, lsl #16
     9f0:      	cbz	w8, 0x760 <_llm_rows.packet_batch.blocks+0x104>
     9f4:      	dup.4s	v0, w8
     9f8:      	ldp	q2, q1, [sp, #0x40]
     9fc:      	cmhi.4s	v16, v0, v2
     a00:      	cmhi.4s	v5, v0, v1
     a04:      	uzp1.8h	v2, v5, v16
     a08:      	umaxv.8h	h0, v2
     a0c:      	fmov	w8, s0
     a10:      	tbz	w8, #0x0, 0x760 <_llm_rows.packet_batch.blocks+0x104>
     a14:      	mov	x12, #0x0               ; =0
     a18:      	ldr	x8, [x20, #0x88]
     a1c:      	mov	w9, #0xc040             ; =49216
     a20:      	add	x10, x8, x9
     a24:      	ldr	x14, [sp, #0x68]
     a28:      	ldr	x13, [x14]
     a2c:      	ldr	x11, [x14, #0x10]
     a30:      	lsl	w9, w23, #3
     a34:      	orr	w9, w9, w27, lsl #5
     a38:      	dup.4s	v0, w9
     a3c:      	ldr	x9, [x14, #0x30]
     a40:      	ldp	q1, q4, [sp, #0x40]
     a44:      	orr.16b	v3, v0, v4
     a48:      	orr.16b	v0, v0, v1
     a4c:      	and.16b	v0, v16, v0
     a50:      	and.16b	v3, v5, v3
     a54:      	ldr	q1, [sp, #0x20]
     a58:      	umull2.2d	v17, v0, v1
     a5c:      	umull2.2d	v27, v3, v1
     a60:      	umull.2d	v18, v0, v1
     a64:      	umull.2d	v1, v3, v1
     a68:      	ldr	q0, [sp, #0x10]
     a6c:      	and.16b	v0, v2, v0
     a70:      	addv.8h	h0, v0
     a74:      	dup.2d	v7, x13
     a78:      	str	q0, [sp, #0x140]
     a7c:      	fmov	w13, s0
     a80:      	b	0xaa4 <_llm_rows.packet_batch.blocks+0x448>
     a84:      	add	x14, x8, x12, lsl #5
     a88:      	ldp	q0, q4, [x14]
     a8c:      	bif.16b	v3, v4, v16
     a90:      	bit.16b	v0, v2, v5
     a94:      	stp	q0, q3, [x14]
     a98:      	add	x12, x12, #0x1
     a9c:      	cmp	x12, #0x602
     aa0:      	b.eq	0xb90 <_llm_rows.packet_batch.blocks+0x534>
     aa4:      	dup.2d	v6, x12
     aa8:      	add.2d	v0, v6, v1
     aac:      	shl.2d	v0, v0, #0x2
     ab0:      	add.2d	v4, v7, v0
     ab4:      	movi.2d	v2, #0000000000000000
     ab8:      	movi.2d	v3, #0000000000000000
     abc:      	tbnz	w13, #0x0, 0xb08 <_llm_rows.packet_batch.blocks+0x4ac>
     ac0:      	and	w14, w13, #0xff
     ac4:      	tbnz	w14, #0x1, 0xb18 <_llm_rows.packet_batch.blocks+0x4bc>
     ac8:      	add.2d	v0, v6, v27
     acc:      	shl.2d	v0, v0, #0x2
     ad0:      	add.2d	v4, v7, v0
     ad4:      	tbnz	w14, #0x2, 0xb30 <_llm_rows.packet_batch.blocks+0x4d4>
     ad8:      	tbnz	w14, #0x3, 0xb3c <_llm_rows.packet_batch.blocks+0x4e0>
     adc:      	add.2d	v0, v6, v18
     ae0:      	shl.2d	v0, v0, #0x2
     ae4:      	add.2d	v4, v7, v0
     ae8:      	tbnz	w14, #0x4, 0xb54 <_llm_rows.packet_batch.blocks+0x4f8>
     aec:      	tbnz	w14, #0x5, 0xb60 <_llm_rows.packet_batch.blocks+0x504>
     af0:      	add.2d	v0, v6, v17
     af4:      	shl.2d	v0, v0, #0x2
     af8:      	add.2d	v4, v7, v0
     afc:      	tbnz	w14, #0x6, 0xb78 <_llm_rows.packet_batch.blocks+0x51c>
     b00:      	tbz	w14, #0x7, 0xa84 <_llm_rows.packet_batch.blocks+0x428>
     b04:      	b	0xb84 <_llm_rows.packet_batch.blocks+0x528>
     b08:      	fmov	x14, d4
     b0c:      	ldr	s2, [x14]
     b10:      	and	w14, w13, #0xff
     b14:      	tbz	w14, #0x1, 0xac8 <_llm_rows.packet_batch.blocks+0x46c>
     b18:      	mov.d	x15, v4[1]
     b1c:      	ld1.s	{ v2 }[1], [x15]
     b20:      	add.2d	v0, v6, v27
     b24:      	shl.2d	v0, v0, #0x2
     b28:      	add.2d	v4, v7, v0
     b2c:      	tbz	w14, #0x2, 0xad8 <_llm_rows.packet_batch.blocks+0x47c>
     b30:      	fmov	x15, d4
     b34:      	ld1.s	{ v2 }[2], [x15]
     b38:      	tbz	w14, #0x3, 0xadc <_llm_rows.packet_batch.blocks+0x480>
     b3c:      	mov.d	x15, v4[1]
     b40:      	ld1.s	{ v2 }[3], [x15]
     b44:      	add.2d	v0, v6, v18
     b48:      	shl.2d	v0, v0, #0x2
     b4c:      	add.2d	v4, v7, v0
     b50:      	tbz	w14, #0x4, 0xaec <_llm_rows.packet_batch.blocks+0x490>
     b54:      	fmov	x15, d4
     b58:      	ld1.s	{ v3 }[0], [x15]
     b5c:      	tbz	w14, #0x5, 0xaf0 <_llm_rows.packet_batch.blocks+0x494>
     b60:      	mov.d	x15, v4[1]
     b64:      	ld1.s	{ v3 }[1], [x15]
     b68:      	add.2d	v0, v6, v17
     b6c:      	shl.2d	v0, v0, #0x2
     b70:      	add.2d	v4, v7, v0
     b74:      	tbz	w14, #0x6, 0xb00 <_llm_rows.packet_batch.blocks+0x4a4>
     b78:      	fmov	x15, d4
     b7c:      	ld1.s	{ v3 }[2], [x15]
     b80:      	tbz	w14, #0x7, 0xa84 <_llm_rows.packet_batch.blocks+0x428>
     b84:      	mov.d	x14, v4[1]
     b88:      	ld1.s	{ v3 }[3], [x14]
     b8c:      	b	0xa84 <_llm_rows.packet_batch.blocks+0x428>
     b90:      	mov	x12, #0x0               ; =0
     b94:      	b	0xbb8 <_llm_rows.packet_batch.blocks+0x55c>
     b98:      	add	x13, x10, x12, lsl #5
     b9c:      	ldp	q0, q4, [x13]
     ba0:      	bif.16b	v3, v4, v16
     ba4:      	bit.16b	v0, v2, v5
     ba8:      	stp	q0, q3, [x13]
     bac:      	add	x12, x12, #0x1
     bb0:      	cmp	x12, #0x602
     bb4:      	b.eq	0xcb0 <_llm_rows.packet_batch.blocks+0x654>
     bb8:      	ldr	q0, [sp, #0x140]
     bbc:      	fmov	w13, s0
     bc0:      	dup.2d	v6, x12
     bc4:      	add.2d	v0, v6, v1
     bc8:      	shl.2d	v0, v0, #0x2
     bcc:      	dup.2d	v7, x11
     bd0:      	add.2d	v4, v7, v0
     bd4:      	movi.2d	v2, #0000000000000000
     bd8:      	movi.2d	v3, #0000000000000000
     bdc:      	tbnz	w13, #0x0, 0xc28 <_llm_rows.packet_batch.blocks+0x5cc>
     be0:      	and	w13, w13, #0xff
     be4:      	tbnz	w13, #0x1, 0xc38 <_llm_rows.packet_batch.blocks+0x5dc>
     be8:      	add.2d	v0, v6, v27
     bec:      	shl.2d	v0, v0, #0x2
     bf0:      	add.2d	v4, v7, v0
     bf4:      	tbnz	w13, #0x2, 0xc50 <_llm_rows.packet_batch.blocks+0x5f4>
     bf8:      	tbnz	w13, #0x3, 0xc5c <_llm_rows.packet_batch.blocks+0x600>
     bfc:      	add.2d	v0, v6, v18
     c00:      	shl.2d	v0, v0, #0x2
     c04:      	add.2d	v4, v7, v0
     c08:      	tbnz	w13, #0x4, 0xc74 <_llm_rows.packet_batch.blocks+0x618>
     c0c:      	tbnz	w13, #0x5, 0xc80 <_llm_rows.packet_batch.blocks+0x624>
     c10:      	add.2d	v0, v6, v17
     c14:      	shl.2d	v0, v0, #0x2
     c18:      	add.2d	v4, v7, v0
     c1c:      	tbnz	w13, #0x6, 0xc98 <_llm_rows.packet_batch.blocks+0x63c>
     c20:      	tbz	w13, #0x7, 0xb98 <_llm_rows.packet_batch.blocks+0x53c>
     c24:      	b	0xca4 <_llm_rows.packet_batch.blocks+0x648>
     c28:      	fmov	x14, d4
     c2c:      	ldr	s2, [x14]
     c30:      	and	w13, w13, #0xff
     c34:      	tbz	w13, #0x1, 0xbe8 <_llm_rows.packet_batch.blocks+0x58c>
     c38:      	mov.d	x14, v4[1]
     c3c:      	ld1.s	{ v2 }[1], [x14]
     c40:      	add.2d	v0, v6, v27
     c44:      	shl.2d	v0, v0, #0x2
     c48:      	add.2d	v4, v7, v0
     c4c:      	tbz	w13, #0x2, 0xbf8 <_llm_rows.packet_batch.blocks+0x59c>
     c50:      	fmov	x14, d4
     c54:      	ld1.s	{ v2 }[2], [x14]
     c58:      	tbz	w13, #0x3, 0xbfc <_llm_rows.packet_batch.blocks+0x5a0>
     c5c:      	mov.d	x14, v4[1]
     c60:      	ld1.s	{ v2 }[3], [x14]
     c64:      	add.2d	v0, v6, v18
     c68:      	shl.2d	v0, v0, #0x2
     c6c:      	add.2d	v4, v7, v0
     c70:      	tbz	w13, #0x4, 0xc0c <_llm_rows.packet_batch.blocks+0x5b0>
     c74:      	fmov	x14, d4
     c78:      	ld1.s	{ v3 }[0], [x14]
     c7c:      	tbz	w13, #0x5, 0xc10 <_llm_rows.packet_batch.blocks+0x5b4>
     c80:      	mov.d	x14, v4[1]
     c84:      	ld1.s	{ v3 }[1], [x14]
     c88:      	add.2d	v0, v6, v17
     c8c:      	shl.2d	v0, v0, #0x2
     c90:      	add.2d	v4, v7, v0
     c94:      	tbz	w13, #0x6, 0xc20 <_llm_rows.packet_batch.blocks+0x5c4>
     c98:      	fmov	x14, d4
     c9c:      	ld1.s	{ v3 }[2], [x14]
     ca0:      	tbz	w13, #0x7, 0xb98 <_llm_rows.packet_batch.blocks+0x53c>
     ca4:      	mov.d	x13, v4[1]
     ca8:      	ld1.s	{ v3 }[3], [x13]
     cac:      	b	0xb98 <_llm_rows.packet_batch.blocks+0x53c>
     cb0:      	stp	q1, q18, [sp, #0x70]
     cb4:      	mov	x10, #-0x602            ; =-1538
     cb8:      	mov	w13, #0xaaab            ; =43691
     cbc:      	movk	w13, #0x3d2a, lsl #16
     cc0:      	stp	q5, q16, [sp, #0xb0]
     cc4:      	stp	q27, q17, [sp, #0x90]
     cc8:      	b	0xcd8 <_llm_rows.packet_batch.blocks+0x67c>
     ccc:      	add	x8, x8, #0x20
     cd0:      	adds	x10, x10, #0x1
     cd4:      	b.hs	0x760 <_llm_rows.packet_batch.blocks+0x104>
     cd8:      	ldr	q0, [x8]
     cdc:      	and.16b	v3, v5, v0
     ce0:      	dup.4s	v0, w16
     ce4:      	str	q0, [sp, #0x110]
     ce8:      	fmul.4s	v0, v3, v0
     cec:      	fmul.4s	v0, v3, v0
     cf0:      	fmul.4s	v0, v3, v0
     cf4:      	fadd.4s	v0, v3, v0
     cf8:      	dup.4s	v1, w17
     cfc:      	str	q1, [sp, #0x100]
     d00:      	fmul.4s	v0, v0, v1
     d04:      	and.16b	v9, v5, v0
     d08:      	fabs.4s	v23, v9
     d0c:      	fmov.4s	v7, #1.00000000
     d10:      	dup.4s	v1, w0
     d14:      	dup.4s	v20, w1
     d18:      	fmul.4s	v0, v9, v9
     d1c:      	mov.16b	v2, v20
     d20:      	str	q1, [sp, #0xf0]
     d24:      	fmla.4s	v2, v0, v1
     d28:      	dup.4s	v22, w2
     d2c:      	mov.16b	v4, v22
     d30:      	fmla.4s	v4, v0, v2
     d34:      	dup.4s	v24, w3
     d38:      	mov.16b	v2, v24
     d3c:      	dup.4s	v25, w4
     d40:      	fmla.4s	v2, v0, v4
     d44:      	mov.16b	v4, v25
     d48:      	fmla.4s	v4, v0, v2
     d4c:      	dup.4s	v16, w5
     d50:      	mov.16b	v2, v16
     d54:      	fmla.4s	v2, v0, v4
     d58:      	mov.16b	v4, v7
     d5c:      	fmla.4s	v4, v0, v2
     d60:      	fmul.4s	v2, v23, v4
     d64:      	dup.4s	v1, w6
     d68:      	dup.4s	v26, w7
     d6c:      	mov.16b	v4, v26
     d70:      	str	q1, [sp, #0xe0]
     d74:      	fmla.4s	v4, v0, v1
     d78:      	dup.4s	v28, w30
     d7c:      	mov.16b	v27, v5
     d80:      	mov.16b	v5, v28
     d84:      	fmla.4s	v5, v0, v4
     d88:      	dup.4s	v29, w21
     d8c:      	mov.16b	v4, v29
     d90:      	fmla.4s	v4, v0, v5
     d94:      	dup.4s	v30, w13
     d98:      	mov.16b	v5, v30
     d9c:      	fmla.4s	v5, v0, v4
     da0:      	movi.4s	v4, #0x3f, lsl #24
     da4:      	fmla.4s	v4, v0, v5
     da8:      	mov.16b	v5, v7
     dac:      	fmla.4s	v5, v0, v4
     db0:      	fdiv.4s	v0, v2, v5
     db4:      	fmov.4s	v31, #9.00000000
     db8:      	fcmge.4s	v4, v31, v23
     dbc:      	and.16b	v2, v4, v23
     dc0:      	mov	w11, #-0x3d300000       ; =-1026555904
     dc4:      	dup.4s	v8, w11
     dc8:      	fcmge.4s	v5, v2, v8
     dcc:      	mov	w11, #0x42c80000        ; =1120403456
     dd0:      	dup.4s	v17, w11
     dd4:      	fcmge.4s	v6, v17, v2
     dd8:      	and.16b	v5, v5, v6
     ddc:      	and.16b	v5, v5, v2
     de0:      	mov	w11, #0xaa3b            ; =43579
     de4:      	movk	w11, #0x3fb8, lsl #16
     de8:      	dup.4s	v10, w11
     dec:      	fmul.4s	v6, v5, v10
     df0:      	movi.4s	v1, #0x4b, lsl #24
     df4:      	fadd.4s	v6, v6, v1
     df8:      	movi.4s	v1, #0xcb, lsl #24
     dfc:      	fadd.4s	v6, v6, v1
     e00:      	fcvtzs.4s	v1, v6
     e04:      	scvtf.4s	v6, v1
     e08:      	mov	w11, #0x7200            ; =29184
     e0c:      	movk	w11, #0xbf31, lsl #16
     e10:      	dup.4s	v11, w11
     e14:      	fmul.4s	v12, v6, v11
     e18:      	fadd.4s	v5, v5, v12
     e1c:      	mov	w11, #0xbe8e            ; =48782
     e20:      	movk	w11, #0xb5bf, lsl #16
     e24:      	dup.4s	v12, w11
     e28:      	fmul.4s	v6, v6, v12
     e2c:      	mov	w11, #0x2bda            ; =11226
     e30:      	movk	w11, #0x3950, lsl #16
     e34:      	dup.4s	v13, w11
     e38:      	fadd.4s	v5, v5, v6
     e3c:      	fmul.4s	v6, v5, v13
     e40:      	mov	w11, #0x96c9            ; =38601
     e44:      	movk	w11, #0x3ab6, lsl #16
     e48:      	dup.4s	v14, w11
     e4c:      	fadd.4s	v6, v6, v14
     e50:      	fmul.4s	v6, v5, v6
     e54:      	dup.4s	v15, w25
     e58:      	fadd.4s	v6, v6, v15
     e5c:      	fmul.4s	v18, v5, v6
     e60:      	dup.4s	v6, w28
     e64:      	fadd.4s	v18, v18, v6
     e68:      	fmul.4s	v18, v5, v18
     e6c:      	fadd.4s	v18, v18, v16
     e70:      	fmul.4s	v18, v5, v18
     e74:      	movi.4s	v21, #0x3f, lsl #24
     e78:      	fadd.4s	v18, v18, v21
     e7c:      	fmul.4s	v19, v5, v5
     e80:      	fmul.4s	v18, v19, v18
     e84:      	fadd.4s	v5, v5, v18
     e88:      	fadd.4s	v5, v5, v7
     e8c:      	movi.2d	v18, #0xffffffffffffffff
     e90:      	add.4s	v1, v1, v18
     e94:      	sshr.4s	v18, v1, #0x1
     e98:      	shl.4s	v19, v18, #0x17
     e9c:      	add.4s	v19, v19, v7
     ea0:      	fmul.4s	v5, v5, v19
     ea4:      	sub.4s	v1, v1, v18
     ea8:      	shl.4s	v1, v1, #0x17
     eac:      	add.4s	v1, v1, v7
     eb0:      	fmul.4s	v1, v5, v1
     eb4:      	fcmgt.4s	v2, v2, v17
     eb8:      	ldr	q5, [sp, #0x130]
     ebc:      	bit.16b	v1, v5, v2
     ec0:      	fmov.4s	v2, #0.25000000
     ec4:      	fdiv.4s	v5, v2, v1
     ec8:      	fsub.4s	v18, v1, v5
     ecc:      	fadd.4s	v1, v1, v5
     ed0:      	fdiv.4s	v1, v18, v1
     ed4:      	bif.16b	v1, v7, v4
     ed8:      	ldr	q4, [x8, #0x10]
     edc:      	ldr	q5, [sp, #0x140]
     ee0:      	fmov	w11, s5
     ee4:      	add	x12, x10, #0x602
     ee8:      	fcmge.4s	v5, v7, v23
     eec:      	bif.16b	v0, v1, v5
     ef0:      	dup.2d	v23, x12
     ef4:      	ldr	q1, [sp, #0x70]
     ef8:      	add.2d	v1, v23, v1
     efc:      	fmul.4s	v3, v3, v21
     f00:      	mvni.4s	v5, #0x80, lsl #24
     f04:      	bif.16b	v0, v9, v5
     f08:      	fcmeq.4s	v5, v9, v9
     f0c:      	fadd.4s	v0, v0, v7
     f10:      	ldr	q18, [sp, #0x120]
     f14:      	bif.16b	v0, v18, v5
     f18:      	fmul.4s	v0, v3, v0
     f1c:      	ldr	q3, [x8, #0xc050]
     f20:      	str	q3, [sp, #0xd0]
     f24:      	ldr	q5, [x8, #0xc040]
     f28:      	and.16b	v5, v27, v5
     f2c:      	fadd.4s	v5, v5, v0
     f30:      	shl.2d	v0, v1, #0x2
     f34:      	dup.2d	v9, x9
     f38:      	add.2d	v0, v9, v0
     f3c:      	tbnz	w11, #0x0, 0x1114 <_llm_rows.packet_batch.blocks+0xab8>
     f40:      	and	w11, w11, #0xff
     f44:      	ldr	q27, [sp, #0x90]
     f48:      	tbnz	w11, #0x1, 0x1128 <_llm_rows.packet_batch.blocks+0xacc>
     f4c:      	add.2d	v0, v23, v27
     f50:      	shl.2d	v0, v0, #0x2
     f54:      	add.2d	v0, v9, v0
     f58:      	tbnz	w11, #0x2, 0x1140 <_llm_rows.packet_batch.blocks+0xae4>
     f5c:      	tbz	w11, #0x3, 0xf68 <_llm_rows.packet_batch.blocks+0x90c>
     f60:      	mov.d	x12, v0[1]
     f64:      	st1.s	{ v5 }[3], [x12]
     f68:      	ldr	q3, [sp, #0xc0]
     f6c:      	and.16b	v4, v3, v4
     f70:      	ldp	q1, q0, [sp, #0x100]
     f74:      	fmul.4s	v0, v4, v0
     f78:      	fmul.4s	v0, v4, v0
     f7c:      	fmul.4s	v0, v4, v0
     f80:      	fadd.4s	v0, v4, v0
     f84:      	fmul.4s	v0, v0, v1
     f88:      	and.16b	v18, v3, v0
     f8c:      	fmul.4s	v0, v18, v18
     f90:      	ldr	q1, [sp, #0xf0]
     f94:      	fmla.4s	v20, v0, v1
     f98:      	fmla.4s	v22, v0, v20
     f9c:      	fmla.4s	v24, v0, v22
     fa0:      	fmla.4s	v25, v0, v24
     fa4:      	mov.16b	v1, v16
     fa8:      	fmla.4s	v1, v0, v25
     fac:      	mov.16b	v5, v7
     fb0:      	fmla.4s	v5, v0, v1
     fb4:      	ldr	q1, [sp, #0xe0]
     fb8:      	fmla.4s	v26, v0, v1
     fbc:      	fmla.4s	v28, v0, v26
     fc0:      	fmla.4s	v29, v0, v28
     fc4:      	fmla.4s	v30, v0, v29
     fc8:      	movi.4s	v1, #0x3f, lsl #24
     fcc:      	fmla.4s	v1, v0, v30
     fd0:      	mov.16b	v19, v7
     fd4:      	fmla.4s	v19, v0, v1
     fd8:      	fabs.4s	v0, v18
     fdc:      	fmul.4s	v1, v0, v5
     fe0:      	fdiv.4s	v1, v1, v19
     fe4:      	fcmge.4s	v5, v31, v0
     fe8:      	and.16b	v19, v5, v0
     fec:      	fcmge.4s	v20, v19, v8
     ff0:      	fcmge.4s	v21, v17, v19
     ff4:      	and.16b	v20, v20, v21
     ff8:      	and.16b	v20, v20, v19
     ffc:      	fmul.4s	v21, v20, v10
    1000:      	movi.4s	v22, #0x4b, lsl #24
    1004:      	fadd.4s	v21, v21, v22
    1008:      	movi.4s	v22, #0xcb, lsl #24
    100c:      	fadd.4s	v21, v21, v22
    1010:      	fcvtzs.4s	v21, v21
    1014:      	scvtf.4s	v22, v21
    1018:      	fmul.4s	v24, v22, v11
    101c:      	fadd.4s	v20, v20, v24
    1020:      	fmul.4s	v22, v22, v12
    1024:      	fadd.4s	v20, v20, v22
    1028:      	fmul.4s	v22, v20, v13
    102c:      	fadd.4s	v22, v22, v14
    1030:      	fmul.4s	v22, v20, v22
    1034:      	fadd.4s	v22, v22, v15
    1038:      	fmul.4s	v22, v20, v22
    103c:      	fadd.4s	v6, v22, v6
    1040:      	fmul.4s	v6, v20, v6
    1044:      	fadd.4s	v6, v6, v16
    1048:      	fmul.4s	v6, v20, v6
    104c:      	movi.4s	v22, #0x3f, lsl #24
    1050:      	fadd.4s	v6, v6, v22
    1054:      	fmul.4s	v16, v20, v20
    1058:      	fmul.4s	v6, v16, v6
    105c:      	fadd.4s	v6, v20, v6
    1060:      	fadd.4s	v6, v6, v7
    1064:      	movi.2d	v16, #0xffffffffffffffff
    1068:      	add.4s	v16, v21, v16
    106c:      	sshr.4s	v20, v16, #0x1
    1070:      	shl.4s	v21, v20, #0x17
    1074:      	add.4s	v21, v21, v7
    1078:      	fmul.4s	v6, v6, v21
    107c:      	sub.4s	v16, v16, v20
    1080:      	shl.4s	v16, v16, #0x17
    1084:      	add.4s	v16, v16, v7
    1088:      	fmul.4s	v6, v6, v16
    108c:      	fcmgt.4s	v16, v19, v17
    1090:      	ldr	q17, [sp, #0x130]
    1094:      	bit.16b	v6, v17, v16
    1098:      	fdiv.4s	v2, v2, v6
    109c:      	fsub.4s	v16, v6, v2
    10a0:      	fadd.4s	v2, v6, v2
    10a4:      	fdiv.4s	v2, v16, v2
    10a8:      	bif.16b	v2, v7, v5
    10ac:      	fcmge.4s	v0, v7, v0
    10b0:      	bsl.16b	v0, v1, v2
    10b4:      	mvni.4s	v1, #0x80, lsl #24
    10b8:      	bif.16b	v0, v18, v1
    10bc:      	fadd.4s	v0, v0, v7
    10c0:      	fcmeq.4s	v1, v18, v18
    10c4:      	ldr	q2, [sp, #0x120]
    10c8:      	bif.16b	v0, v2, v1
    10cc:      	fmul.4s	v1, v4, v22
    10d0:      	fmul.4s	v0, v1, v0
    10d4:      	ldr	q1, [sp, #0xd0]
    10d8:      	and.16b	v1, v3, v1
    10dc:      	fadd.4s	v2, v1, v0
    10e0:      	ldr	q0, [sp, #0x80]
    10e4:      	add.2d	v0, v23, v0
    10e8:      	shl.2d	v0, v0, #0x2
    10ec:      	add.2d	v0, v9, v0
    10f0:      	tbnz	w11, #0x4, 0x1150 <_llm_rows.packet_batch.blocks+0xaf4>
    10f4:      	ldp	q17, q5, [sp, #0xa0]
    10f8:      	tbnz	w11, #0x5, 0x1160 <_llm_rows.packet_batch.blocks+0xb04>
    10fc:      	add.2d	v0, v23, v17
    1100:      	shl.2d	v0, v0, #0x2
    1104:      	add.2d	v0, v9, v0
    1108:      	tbnz	w11, #0x6, 0x1178 <_llm_rows.packet_batch.blocks+0xb1c>
    110c:      	tbz	w11, #0x7, 0xccc <_llm_rows.packet_batch.blocks+0x670>
    1110:      	b	0x1184 <_llm_rows.packet_batch.blocks+0xb28>
    1114:      	fmov	x12, d0
    1118:      	str	s5, [x12]
    111c:      	and	w11, w11, #0xff
    1120:      	ldr	q27, [sp, #0x90]
    1124:      	tbz	w11, #0x1, 0xf4c <_llm_rows.packet_batch.blocks+0x8f0>
    1128:      	mov.d	x12, v0[1]
    112c:      	st1.s	{ v5 }[1], [x12]
    1130:      	add.2d	v0, v23, v27
    1134:      	shl.2d	v0, v0, #0x2
    1138:      	add.2d	v0, v9, v0
    113c:      	tbz	w11, #0x2, 0xf5c <_llm_rows.packet_batch.blocks+0x900>
    1140:      	fmov	x12, d0
    1144:      	st1.s	{ v5 }[2], [x12]
    1148:      	tbnz	w11, #0x3, 0xf60 <_llm_rows.packet_batch.blocks+0x904>
    114c:      	b	0xf68 <_llm_rows.packet_batch.blocks+0x90c>
    1150:      	fmov	x12, d0
    1154:      	str	s2, [x12]
    1158:      	ldp	q17, q5, [sp, #0xa0]
    115c:      	tbz	w11, #0x5, 0x10fc <_llm_rows.packet_batch.blocks+0xaa0>
    1160:      	mov.d	x12, v0[1]
    1164:      	st1.s	{ v2 }[1], [x12]
    1168:      	add.2d	v0, v23, v17
    116c:      	shl.2d	v0, v0, #0x2
    1170:      	add.2d	v0, v9, v0
    1174:      	tbz	w11, #0x6, 0x110c <_llm_rows.packet_batch.blocks+0xab0>
    1178:      	fmov	x12, d0
    117c:      	st1.s	{ v2 }[2], [x12]
    1180:      	tbz	w11, #0x7, 0xccc <_llm_rows.packet_batch.blocks+0x670>
    1184:      	mov.d	x11, v0[1]
    1188:      	st1.s	{ v2 }[3], [x11]
    118c:      	b	0xccc <_llm_rows.packet_batch.blocks+0x670>
    1190:      	add	sp, sp, #0x160
    1194:      	ldp	x29, x30, [sp, #0x90]
    1198:      	ldp	x20, x19, [sp, #0x80]
    119c:      	ldp	x22, x21, [sp, #0x70]
    11a0:      	ldp	x24, x23, [sp, #0x60]
    11a4:      	ldp	x26, x25, [sp, #0x50]
    11a8:      	ldp	x28, x27, [sp, #0x40]
    11ac:      	ldp	d9, d8, [sp, #0x30]
    11b0:      	ldp	d11, d10, [sp, #0x20]
    11b4:      	ldp	d13, d12, [sp, #0x10]
    11b8:      	ldp	d15, d14, [sp], #0xa0
    11bc:      	ret

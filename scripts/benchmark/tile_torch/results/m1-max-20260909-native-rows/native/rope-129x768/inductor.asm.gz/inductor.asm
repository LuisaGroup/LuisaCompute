
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/rope-129x768/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0x50
     6b4:      	stp	x22, x21, [sp, #0x20]
     6b8:      	stp	x20, x19, [sp, #0x30]
     6bc:      	stp	x29, x30, [sp, #0x40]
     6c0:      	add	x29, sp, #0x40
     6c4:      	mov	x8, #0x0                ; =0
     6c8:      	str	wzr, [sp]
     6cc:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     6d0:      	ldr	x9, [x9, #0x90]
     6d4:      	mov	x10, sp
     6d8:      	str	x10, [x9]
     6dc:      	mov	x10, #-0x4              ; =-4
     6e0:      	mov	x11, x0
     6e4:      	mov	x12, x3
     6e8:      	mov	x13, x4
     6ec:      	mov	x14, x1
     6f0:      	mov	x15, x2
     6f4:      	ldr	q0, [x11]
     6f8:      	ldr	q1, [x14], #0x10
     6fc:      	ldr	q2, [x11, #0x600]
     700:      	ldr	q3, [x15], #0x10
     704:      	fmul.4s	v4, v0, v1
     708:      	fmul.4s	v5, v2, v3
     70c:      	fsub.4s	v4, v4, v5
     710:      	fmul.4s	v0, v0, v3
     714:      	fmul.4s	v1, v1, v2
     718:      	str	q4, [x12], #0x10
     71c:      	fadd.4s	v0, v1, v0
     720:      	str	q0, [x13], #0x10
     724:      	add	x10, x10, #0x4
     728:      	add	x11, x11, #0x10
     72c:      	cmp	x10, #0x17c
     730:      	b.lo	0x6f4 <_kernel+0x44>
     734:      	add	x8, x8, #0x1
     738:      	add	x2, x2, #0x600
     73c:      	add	x1, x1, #0x600
     740:      	add	x4, x4, #0xc00
     744:      	add	x3, x3, #0xc00
     748:      	add	x0, x0, #0xc00
     74c:      	cmp	x8, #0x81
     750:      	b.ne	0x6dc <_kernel+0x2c>
     754:      	str	xzr, [x9]
     758:      	mov	x8, sp
     75c:      	ldapr	w8, [x8]
     760:      	cbnz	w8, 0x778 <_kernel+0xc8>
     764:      	ldp	x29, x30, [sp, #0x40]
     768:      	ldp	x20, x19, [sp, #0x30]
     76c:      	ldp	x22, x21, [sp, #0x20]
     770:      	add	sp, sp, #0x50
     774:      	ret
     778:      	mov	w0, #0x10               ; =16
     77c:      	bl	0x168c <dyld_stub_binder+0x168c>
     780:      	mov	x19, x0
     784:      	mov	w8, #0x33d              ; =829
     788:      	str	w8, [sp, #0x4]
     78c:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xbc>
     790:      	add	x0, x0, #0x9b0
     794:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xbc>
     798:      	add	x1, x1, #0xa3c
     79c:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xbc>
     7a0:      	add	x3, x3, #0xa67
     7a4:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xbc>
     7a8:      	add	x4, x4, #0xae5
     7ac:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xbc>
     7b0:      	add	x2, x2, #0xa64
     7b4:      	add	x8, sp, #0x8
     7b8:      	add	x5, sp, #0x4
     7bc:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xbc>
     7c0:      	add	x7, x7, #0xae7
     7c4:      	mov	x6, x2
     7c8:      	bl	0x83c <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     7cc:      	mov	w21, #0x1               ; =1
     7d0:      	add	x1, sp, #0x8
     7d4:      	mov	x0, x19
     7d8:      	bl	0x15d8 <dyld_stub_binder+0x15d8>
     7dc:      	mov	w21, #0x0               ; =0
     7e0:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     7e4:      	ldr	x1, [x1, #0x18]
     7e8:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     7ec:      	ldr	x2, [x2, #0x8]
     7f0:      	mov	x0, x19
     7f4:      	bl	0x16bc <dyld_stub_binder+0x16bc>
     7f8:      	brk	#0x1
     7fc:      	mov	x20, x0
     800:      	ldrsb	w8, [sp, #0x1f]
     804:      	tbz	w8, #0x1f, 0x820 <_kernel+0x170>
     808:      	ldr	x0, [sp, #0x8]
     80c:      	ldr	x8, [sp, #0x18]
     810:      	and	x1, x8, #0x7fffffffffffffff
     814:      	bl	0x1674 <dyld_stub_binder+0x1674>
     818:      	tbnz	w21, #0x0, 0x82c <_kernel+0x17c>
     81c:      	b	0x834 <_kernel+0x184>
     820:      	cbnz	w21, 0x82c <_kernel+0x17c>
     824:      	b	0x834 <_kernel+0x184>
     828:      	mov	x20, x0
     82c:      	mov	x0, x19
     830:      	bl	0x16b0 <dyld_stub_binder+0x16b0>
     834:      	mov	x0, x20
     838:      	bl	0x159c <dyld_stub_binder+0x159c>

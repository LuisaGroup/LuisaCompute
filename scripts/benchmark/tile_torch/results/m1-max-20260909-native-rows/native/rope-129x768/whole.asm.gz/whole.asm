
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/rope-129x768-l1/object/tile_xir_w8_80787_1788919122413347_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x10]!
       4:      	sub	sp, sp, #0xc, lsl #12   ; =0xc000
       8:      	mov	x11, #0x0               ; =0
       c:      	ldr	x12, [x0]
      10:      	ldr	x10, [x0, #0x10]
      14:      	ldr	w8, [x1]
      18:      	ldr	w9, [x1, #0x24]
      1c:      	add	w13, w9, w8, lsl #5
      20:      	ldr	x9, [x0, #0x20]
      24:      	ldr	x8, [x0, #0x30]
      28:      	dup.4s	v0, w13
      2c:      	adrp	x13, 0x0 <ltmp0>
      30:      	ldr	q1, [x13]
      34:      	add.4s	v3, v0, v1
      38:      	adrp	x13, 0x0 <ltmp0>
      3c:      	ldr	q1, [x13]
      40:      	add.4s	v2, v0, v1
      44:      	ushll2.2d	v4, v2, #0x0
      48:      	ushll2.2d	v5, v3, #0x0
      4c:      	ushll.2d	v6, v2, #0x0
      50:      	ushll.2d	v7, v3, #0x0
      54:      	movi.4s	v1, #0x3, lsl #8
      58:      	umull2.2d	v0, v2, v1
      5c:      	umull2.2d	v1, v3, v1
      60:      	movi.2s	v16, #0x3, lsl #8
      64:      	umull.2d	v2, v2, v16
      68:      	umull.2d	v3, v3, v16
      6c:      	dup.2d	v16, x12
      70:      	add	x12, sp, #0x9, lsl #12  ; =0x9000
      74:      	dup.2d	v17, x11
      78:      	add.2d	v18, v17, v0
      7c:      	add.2d	v19, v17, v2
      80:      	add.2d	v20, v17, v1
      84:      	add.2d	v17, v17, v3
      88:      	shl.2d	v17, v17, #0x2
      8c:      	shl.2d	v20, v20, #0x2
      90:      	shl.2d	v19, v19, #0x2
      94:      	shl.2d	v18, v18, #0x2
      98:      	add.2d	v18, v16, v18
      9c:      	add.2d	v19, v16, v19
      a0:      	add.2d	v20, v16, v20
      a4:      	add.2d	v17, v16, v17
      a8:      	mov.d	x13, v17[1]
      ac:      	fmov	x14, d17
      b0:      	mov.d	x15, v20[1]
      b4:      	fmov	x16, d20
      b8:      	mov.d	x17, v19[1]
      bc:      	fmov	x0, d19
      c0:      	mov.d	x1, v18[1]
      c4:      	ldr	s17, [x0]
      c8:      	ld1.s	{ v17 }[1], [x17]
      cc:      	fmov	x17, d18
      d0:      	ld1.s	{ v17 }[2], [x17]
      d4:      	ld1.s	{ v17 }[3], [x1]
      d8:      	ldr	s18, [x14]
      dc:      	ld1.s	{ v18 }[1], [x13]
      e0:      	ld1.s	{ v18 }[2], [x16]
      e4:      	ld1.s	{ v18 }[3], [x15]
      e8:      	add	x13, x12, x11, lsl #5
      ec:      	stp	q18, q17, [x13]
      f0:      	add	x11, x11, #0x1
      f4:      	cmp	x11, #0x180
      f8:      	b.ne	0x74 <ltmp0+0x74>
      fc:      	add	x11, sp, #0x6, lsl #12  ; =0x6000
     100:      	mov	w12, #0x180             ; =384
     104:      	dup.2d	v17, x12
     108:      	add.2d	v18, v17, v0
     10c:      	add.2d	v19, v17, v2
     110:      	add.2d	v20, v17, v1
     114:      	add.2d	v17, v17, v3
     118:      	shl.2d	v17, v17, #0x2
     11c:      	shl.2d	v20, v20, #0x2
     120:      	shl.2d	v19, v19, #0x2
     124:      	shl.2d	v18, v18, #0x2
     128:      	add.2d	v18, v16, v18
     12c:      	add.2d	v19, v16, v19
     130:      	add.2d	v20, v16, v20
     134:      	add.2d	v17, v16, v17
     138:      	mov.d	x13, v17[1]
     13c:      	fmov	x14, d17
     140:      	mov.d	x15, v20[1]
     144:      	fmov	x16, d20
     148:      	mov.d	x17, v19[1]
     14c:      	fmov	x0, d19
     150:      	mov.d	x1, v18[1]
     154:      	ldr	s17, [x0]
     158:      	ld1.s	{ v17 }[1], [x17]
     15c:      	fmov	x17, d18
     160:      	ld1.s	{ v17 }[2], [x17]
     164:      	ld1.s	{ v17 }[3], [x1]
     168:      	ldr	s18, [x14]
     16c:      	ld1.s	{ v18 }[1], [x13]
     170:      	ld1.s	{ v18 }[2], [x16]
     174:      	ld1.s	{ v18 }[3], [x15]
     178:      	stp	q18, q17, [x11], #0x20
     17c:      	add	x12, x12, #0x1
     180:      	cmp	x12, #0x300
     184:      	b.ne	0x104 <ltmp0+0x104>
     188:      	mov	x11, #0x0               ; =0
     18c:      	mov	w12, #0x180             ; =384
     190:      	dup.2s	v16, w12
     194:      	xtn.2s	v7, v7
     198:      	umull.2d	v7, v7, v16
     19c:      	xtn.2s	v5, v5
     1a0:      	umull.2d	v5, v5, v16
     1a4:      	xtn.2s	v6, v6
     1a8:      	umull.2d	v6, v6, v16
     1ac:      	xtn.2s	v4, v4
     1b0:      	umull.2d	v4, v4, v16
     1b4:      	dup.2d	v16, x10
     1b8:      	add	x10, sp, #0x3, lsl #12  ; =0x3000
     1bc:      	dup.2d	v17, x11
     1c0:      	add.2d	v18, v17, v4
     1c4:      	add.2d	v19, v17, v6
     1c8:      	add.2d	v20, v17, v5
     1cc:      	add.2d	v17, v17, v7
     1d0:      	shl.2d	v17, v17, #0x2
     1d4:      	shl.2d	v20, v20, #0x2
     1d8:      	shl.2d	v19, v19, #0x2
     1dc:      	shl.2d	v18, v18, #0x2
     1e0:      	add.2d	v18, v16, v18
     1e4:      	add.2d	v19, v16, v19
     1e8:      	add.2d	v20, v16, v20
     1ec:      	add.2d	v17, v16, v17
     1f0:      	mov.d	x12, v17[1]
     1f4:      	fmov	x13, d17
     1f8:      	mov.d	x14, v20[1]
     1fc:      	fmov	x15, d20
     200:      	mov.d	x16, v19[1]
     204:      	fmov	x17, d19
     208:      	mov.d	x0, v18[1]
     20c:      	ldr	s17, [x17]
     210:      	ld1.s	{ v17 }[1], [x16]
     214:      	fmov	x16, d18
     218:      	ld1.s	{ v17 }[2], [x16]
     21c:      	ld1.s	{ v17 }[3], [x0]
     220:      	ldr	s18, [x13]
     224:      	ld1.s	{ v18 }[1], [x12]
     228:      	ld1.s	{ v18 }[2], [x15]
     22c:      	ld1.s	{ v18 }[3], [x14]
     230:      	add	x12, x10, x11, lsl #5
     234:      	stp	q18, q17, [x12]
     238:      	add	x11, x11, #0x1
     23c:      	cmp	x11, #0x180
     240:      	b.ne	0x1bc <ltmp0+0x1bc>
     244:      	mov	x10, #0x0               ; =0
     248:      	dup.2d	v16, x9
     24c:      	mov	x9, sp
     250:      	dup.2d	v17, x10
     254:      	add.2d	v18, v17, v4
     258:      	add.2d	v19, v17, v6
     25c:      	add.2d	v20, v17, v5
     260:      	add.2d	v17, v17, v7
     264:      	shl.2d	v17, v17, #0x2
     268:      	shl.2d	v20, v20, #0x2
     26c:      	shl.2d	v19, v19, #0x2
     270:      	shl.2d	v18, v18, #0x2
     274:      	add.2d	v18, v16, v18
     278:      	add.2d	v19, v16, v19
     27c:      	add.2d	v20, v16, v20
     280:      	add.2d	v17, v16, v17
     284:      	mov.d	x11, v17[1]
     288:      	fmov	x12, d17
     28c:      	mov.d	x13, v20[1]
     290:      	fmov	x14, d20
     294:      	mov.d	x15, v19[1]
     298:      	fmov	x16, d19
     29c:      	mov.d	x17, v18[1]
     2a0:      	ldr	s17, [x16]
     2a4:      	ld1.s	{ v17 }[1], [x15]
     2a8:      	fmov	x15, d18
     2ac:      	ld1.s	{ v17 }[2], [x15]
     2b0:      	ld1.s	{ v17 }[3], [x17]
     2b4:      	ldr	s18, [x12]
     2b8:      	ld1.s	{ v18 }[1], [x11]
     2bc:      	ld1.s	{ v18 }[2], [x14]
     2c0:      	ld1.s	{ v18 }[3], [x13]
     2c4:      	add	x11, x9, x10, lsl #5
     2c8:      	stp	q18, q17, [x11]
     2cc:      	add	x10, x10, #0x1
     2d0:      	cmp	x10, #0x180
     2d4:      	b.ne	0x250 <ltmp0+0x250>
     2d8:      	mov	x9, #0x0                ; =0
     2dc:      	add	x10, sp, #0x9, lsl #12  ; =0x9000
     2e0:      	add	x11, sp, #0x3, lsl #12  ; =0x3000
     2e4:      	add	x12, sp, #0x6, lsl #12  ; =0x6000
     2e8:      	dup.2d	v4, x8
     2ec:      	mov	x8, sp
     2f0:      	dup.2d	v5, x9
     2f4:      	add.2d	v6, v5, v0
     2f8:      	add.2d	v7, v5, v2
     2fc:      	add.2d	v16, v5, v1
     300:      	add.2d	v5, v5, v3
     304:      	lsl	x13, x9, #5
     308:      	add	x14, x10, x13
     30c:      	ldp	q18, q17, [x14]
     310:      	add	x14, x11, x13
     314:      	ldp	q20, q19, [x14]
     318:      	fmul.4s	v18, v18, v20
     31c:      	fmul.4s	v17, v17, v19
     320:      	add	x14, x12, x13
     324:      	ldp	q20, q19, [x14]
     328:      	add	x13, x8, x13
     32c:      	ldp	q22, q21, [x13]
     330:      	fmul.4s	v20, v20, v22
     334:      	fmul.4s	v19, v19, v21
     338:      	fsub.4s	v17, v17, v19
     33c:      	fsub.4s	v18, v18, v20
     340:      	shl.2d	v5, v5, #0x2
     344:      	shl.2d	v16, v16, #0x2
     348:      	shl.2d	v7, v7, #0x2
     34c:      	shl.2d	v6, v6, #0x2
     350:      	add.2d	v6, v4, v6
     354:      	add.2d	v5, v4, v5
     358:      	mov.d	x13, v5[1]
     35c:      	fmov	x14, d5
     360:      	str	s18, [x14]
     364:      	st1.s	{ v18 }[1], [x13]
     368:      	add.2d	v5, v4, v16
     36c:      	mov.d	x13, v5[1]
     370:      	fmov	x14, d5
     374:      	st1.s	{ v18 }[2], [x14]
     378:      	add.2d	v5, v4, v7
     37c:      	st1.s	{ v18 }[3], [x13]
     380:      	mov.d	x13, v5[1]
     384:      	fmov	x14, d5
     388:      	str	s17, [x14]
     38c:      	st1.s	{ v17 }[1], [x13]
     390:      	mov.d	x13, v6[1]
     394:      	fmov	x14, d6
     398:      	st1.s	{ v17 }[2], [x14]
     39c:      	st1.s	{ v17 }[3], [x13]
     3a0:      	add	x9, x9, #0x1
     3a4:      	cmp	x9, #0x180
     3a8:      	b.ne	0x2f0 <ltmp0+0x2f0>
     3ac:      	mov	x8, #0x0                ; =0
     3b0:      	add	x9, sp, #0x9, lsl #12   ; =0x9000
     3b4:      	mov	x10, sp
     3b8:      	add	x11, sp, #0x6, lsl #12  ; =0x6000
     3bc:      	add	x12, sp, #0x3, lsl #12  ; =0x3000
     3c0:      	add	x13, x8, #0x180
     3c4:      	dup.2d	v5, x13
     3c8:      	add.2d	v6, v5, v0
     3cc:      	add.2d	v7, v5, v2
     3d0:      	add.2d	v16, v5, v1
     3d4:      	add.2d	v5, v5, v3
     3d8:      	lsl	x13, x8, #5
     3dc:      	add	x14, x9, x13
     3e0:      	ldp	q18, q17, [x14]
     3e4:      	add	x14, x10, x13
     3e8:      	ldp	q20, q19, [x14]
     3ec:      	fmul.4s	v18, v18, v20
     3f0:      	fmul.4s	v17, v17, v19
     3f4:      	add	x14, x11, x13
     3f8:      	ldp	q20, q19, [x14]
     3fc:      	add	x13, x12, x13
     400:      	ldp	q22, q21, [x13]
     404:      	fmul.4s	v20, v20, v22
     408:      	fmul.4s	v19, v19, v21
     40c:      	fadd.4s	v17, v17, v19
     410:      	fadd.4s	v18, v18, v20
     414:      	shl.2d	v5, v5, #0x2
     418:      	shl.2d	v16, v16, #0x2
     41c:      	shl.2d	v7, v7, #0x2
     420:      	shl.2d	v6, v6, #0x2
     424:      	add.2d	v6, v4, v6
     428:      	add.2d	v5, v4, v5
     42c:      	mov.d	x13, v5[1]
     430:      	fmov	x14, d5
     434:      	str	s18, [x14]
     438:      	st1.s	{ v18 }[1], [x13]
     43c:      	add.2d	v5, v4, v16
     440:      	mov.d	x13, v5[1]
     444:      	fmov	x14, d5
     448:      	st1.s	{ v18 }[2], [x14]
     44c:      	add.2d	v5, v4, v7
     450:      	st1.s	{ v18 }[3], [x13]
     454:      	mov.d	x13, v5[1]
     458:      	fmov	x14, d5
     45c:      	str	s17, [x14]
     460:      	st1.s	{ v17 }[1], [x13]
     464:      	mov.d	x13, v6[1]
     468:      	fmov	x14, d6
     46c:      	st1.s	{ v17 }[2], [x14]
     470:      	st1.s	{ v17 }[3], [x13]
     474:      	add	x8, x8, #0x1
     478:      	cmp	x8, #0x180
     47c:      	b.ne	0x3c0 <ltmp0+0x3c0>
     480:      	add	sp, sp, #0xc, lsl #12   ; =0xc000
     484:      	ldp	x28, x27, [sp], #0x10
     488:      	ret

000000000000048c <_llm_rows.packet_batch.blocks>:
     48c:      	stp	d9, d8, [sp, #-0x70]!
     490:      	stp	x28, x27, [sp, #0x10]
     494:      	stp	x26, x25, [sp, #0x20]
     498:      	stp	x24, x23, [sp, #0x30]
     49c:      	stp	x22, x21, [sp, #0x40]
     4a0:      	stp	x20, x19, [sp, #0x50]
     4a4:      	stp	x29, x30, [sp, #0x60]
     4a8:      	sub	sp, sp, #0xc, lsl #12   ; =0xc000
     4ac:      	sub	sp, sp, #0x70
     4b0:      	str	x0, [sp, #0x60]
     4b4:      	cbz	w3, 0xe18 <_llm_rows.packet_batch.blocks+0x98c>
     4b8:      	mov	x21, x3
     4bc:      	mov	x20, x2
     4c0:      	mov	w22, #0x0               ; =0
     4c4:      	ldp	w9, w8, [x2, #0x2c]
     4c8:      	stp	w8, w9, [sp, #0x58]
     4cc:      	ldp	w26, w15, [x2]
     4d0:      	adrp	x8, 0x0 <ltmp0>
     4d4:      	ldr	q0, [x8]
     4d8:      	str	q0, [sp, #0x40]
     4dc:      	adrp	x8, 0x0 <ltmp0>
     4e0:      	ldr	q0, [x8]
     4e4:      	str	q0, [sp, #0x30]
     4e8:      	movi.2s	v8, #0x3, lsl #8
     4ec:      	adrp	x8, 0x0 <ltmp0>
     4f0:      	ldr	q0, [x8]
     4f4:      	str	q0, [sp, #0x10]
     4f8:      	add	x25, sp, #0x9, lsl #12  ; =0x9000
     4fc:      	add	x25, x25, #0x70
     500:      	add	x27, sp, #0x3, lsl #12  ; =0x3000
     504:      	add	x27, x27, #0x70
     508:      	add	x23, sp, #0x70
     50c:      	add	x16, sp, #0x6, lsl #12  ; =0x6000
     510:      	add	x16, x16, #0x70
     514:      	ldp	w19, w8, [x2, #0x8]
     518:      	str	x8, [sp, #0x50]
     51c:      	str	w3, [sp, #0x2c]
     520:      	b	0x568 <_llm_rows.packet_batch.blocks+0xdc>
     524:      	mov	w8, #0x18               ; =24
     528:      	str	w8, [x20, #0x24]
     52c:      	ldr	w21, [sp, #0x2c]
     530:      	add	w8, w26, #0x1
     534:      	ldp	w10, w9, [sp, #0x58]
     538:      	cmp	w8, w9
     53c:      	cset	w8, eq
     540:      	csinc	w26, wzr, w26, eq
     544:      	cinc	w9, w15, eq
     548:      	cmp	w9, w10
     54c:      	cset	w10, eq
     550:      	ands	w8, w8, w10
     554:      	csel	w15, wzr, w9, ne
     558:      	add	w19, w19, w8
     55c:      	add	w22, w22, #0x1
     560:      	cmp	w22, w21
     564:      	b.eq	0xe18 <_llm_rows.packet_batch.blocks+0x98c>
     568:      	ubfiz	x8, x26, #5, #32
     56c:      	ldr	x12, [sp, #0x50]
     570:      	cmp	x8, x12
     574:      	csel	x9, x8, xzr, ls
     578:      	subs	x10, x12, x9
     57c:      	cmp	x10, #0x20
     580:      	mov	w11, #0x20              ; =32
     584:      	csel	x10, x10, x11, lo
     588:      	cmp	x12, x9
     58c:      	stp	w26, w15, [x20]
     590:      	str	w19, [x20, #0x8]
     594:      	str	wzr, [x20, #0x24]
     598:      	ccmp	x8, x12, #0x2, hi
     59c:      	csel	x28, x10, xzr, ls
     5a0:      	cmp	x28, #0x20
     5a4:      	b.lo	0x608 <_llm_rows.packet_batch.blocks+0x17c>
     5a8:      	ldr	x28, [sp, #0x60]
     5ac:      	mov	x0, x28
     5b0:      	mov	x1, x20
     5b4:      	mov	x24, x15
     5b8:      	bl	0x5b8 <_llm_rows.packet_batch.blocks+0x12c>
     5bc:      	mov	w8, #0x8                ; =8
     5c0:      	str	w8, [x20, #0x24]
     5c4:      	mov	x0, x28
     5c8:      	mov	x1, x20
     5cc:      	bl	0x5cc <_llm_rows.packet_batch.blocks+0x140>
     5d0:      	mov	w8, #0x10               ; =16
     5d4:      	str	w8, [x20, #0x24]
     5d8:      	mov	x0, x28
     5dc:      	mov	x1, x20
     5e0:      	bl	0x5e0 <_llm_rows.packet_batch.blocks+0x154>
     5e4:      	mov	w8, #0x18               ; =24
     5e8:      	str	w8, [x20, #0x24]
     5ec:      	mov	x0, x28
     5f0:      	mov	x1, x20
     5f4:      	bl	0x5f4 <_llm_rows.packet_batch.blocks+0x168>
     5f8:      	add	x16, sp, #0x6, lsl #12  ; =0x6000
     5fc:      	add	x16, x16, #0x70
     600:      	mov	x15, x24
     604:      	b	0x530 <_llm_rows.packet_batch.blocks+0xa4>
     608:      	lsr	x21, x28, #3
     60c:      	cmp	x28, #0x8
     610:      	b.lo	0x684 <_llm_rows.packet_batch.blocks+0x1f8>
     614:      	str	wzr, [x20, #0x24]
     618:      	ldr	x0, [sp, #0x60]
     61c:      	mov	x1, x20
     620:      	mov	x24, x15
     624:      	bl	0x624 <_llm_rows.packet_batch.blocks+0x198>
     628:      	add	x16, sp, #0x6, lsl #12  ; =0x6000
     62c:      	add	x16, x16, #0x70
     630:      	mov	x15, x24
     634:      	cmp	x21, #0x1
     638:      	b.eq	0x684 <_llm_rows.packet_batch.blocks+0x1f8>
     63c:      	mov	w8, #0x8                ; =8
     640:      	str	w8, [x20, #0x24]
     644:      	ldr	x0, [sp, #0x60]
     648:      	mov	x1, x20
     64c:      	bl	0x64c <_llm_rows.packet_batch.blocks+0x1c0>
     650:      	add	x16, sp, #0x6, lsl #12  ; =0x6000
     654:      	add	x16, x16, #0x70
     658:      	mov	x15, x24
     65c:      	cmp	x21, #0x2
     660:      	b.eq	0x684 <_llm_rows.packet_batch.blocks+0x1f8>
     664:      	mov	w8, #0x10               ; =16
     668:      	str	w8, [x20, #0x24]
     66c:      	ldr	x0, [sp, #0x60]
     670:      	mov	x1, x20
     674:      	bl	0x674 <_llm_rows.packet_batch.blocks+0x1e8>
     678:      	add	x16, sp, #0x6, lsl #12  ; =0x6000
     67c:      	add	x16, x16, #0x70
     680:      	mov	x15, x24
     684:      	and	w8, w28, #0x7
     688:      	cbz	w8, 0x524 <_llm_rows.packet_batch.blocks+0x98>
     68c:      	dup.4s	v1, w8
     690:      	ldp	q0, q2, [sp, #0x30]
     694:      	cmhi.4s	v0, v1, v0
     698:      	cmhi.4s	v1, v1, v2
     69c:      	uzp1.8h	v6, v1, v0
     6a0:      	umaxv.8h	h2, v6
     6a4:      	fmov	w8, s2
     6a8:      	tbz	w8, #0x0, 0x524 <_llm_rows.packet_batch.blocks+0x98>
     6ac:      	mov	x11, #0x0               ; =0
     6b0:      	ldr	x13, [sp, #0x60]
     6b4:      	ldr	x12, [x13]
     6b8:      	ldr	x10, [x13, #0x10]
     6bc:      	ldr	x9, [x13, #0x20]
     6c0:      	lsl	w8, w21, #3
     6c4:      	orr	w8, w8, w26, lsl #5
     6c8:      	dup.4s	v2, w8
     6cc:      	ldr	x8, [x13, #0x30]
     6d0:      	ldp	q3, q4, [sp, #0x30]
     6d4:      	orr.16b	v3, v2, v3
     6d8:      	orr.16b	v2, v2, v4
     6dc:      	and.16b	v5, v1, v2
     6e0:      	and.16b	v4, v0, v3
     6e4:      	ushll2.2d	v7, v4, #0x0
     6e8:      	ushll2.2d	v16, v5, #0x0
     6ec:      	ushll.2d	v17, v4, #0x0
     6f0:      	ushll.2d	v18, v5, #0x0
     6f4:      	movi.4s	v3, #0x3, lsl #8
     6f8:      	umull2.2d	v2, v4, v3
     6fc:      	umull2.2d	v3, v5, v3
     700:      	umull.2d	v4, v4, v8
     704:      	umull.2d	v5, v5, v8
     708:      	ldr	q19, [sp, #0x10]
     70c:      	and.16b	v6, v6, v19
     710:      	addv.8h	h6, v6
     714:      	dup.2d	v19, x12
     718:      	fmov	w12, s6
     71c:      	b	0x740 <_llm_rows.packet_batch.blocks+0x2b4>
     720:      	add	x13, x25, x11, lsl #5
     724:      	ldp	q22, q23, [x13]
     728:      	bif.16b	v21, v23, v0
     72c:      	bif.16b	v20, v22, v1
     730:      	stp	q20, q21, [x13]
     734:      	add	x11, x11, #0x1
     738:      	cmp	x11, #0x180
     73c:      	b.eq	0x82c <_llm_rows.packet_batch.blocks+0x3a0>
     740:      	dup.2d	v22, x11
     744:      	add.2d	v20, v22, v5
     748:      	shl.2d	v20, v20, #0x2
     74c:      	add.2d	v23, v19, v20
     750:      	movi.2d	v20, #0000000000000000
     754:      	movi.2d	v21, #0000000000000000
     758:      	tbnz	w12, #0x0, 0x7a4 <_llm_rows.packet_batch.blocks+0x318>
     75c:      	and	w13, w12, #0xff
     760:      	tbnz	w13, #0x1, 0x7b4 <_llm_rows.packet_batch.blocks+0x328>
     764:      	add.2d	v23, v22, v3
     768:      	shl.2d	v23, v23, #0x2
     76c:      	add.2d	v23, v19, v23
     770:      	tbnz	w13, #0x2, 0x7cc <_llm_rows.packet_batch.blocks+0x340>
     774:      	tbnz	w13, #0x3, 0x7d8 <_llm_rows.packet_batch.blocks+0x34c>
     778:      	add.2d	v23, v22, v4
     77c:      	shl.2d	v23, v23, #0x2
     780:      	add.2d	v23, v19, v23
     784:      	tbnz	w13, #0x4, 0x7f0 <_llm_rows.packet_batch.blocks+0x364>
     788:      	tbnz	w13, #0x5, 0x7fc <_llm_rows.packet_batch.blocks+0x370>
     78c:      	add.2d	v22, v22, v2
     790:      	shl.2d	v22, v22, #0x2
     794:      	add.2d	v22, v19, v22
     798:      	tbnz	w13, #0x6, 0x814 <_llm_rows.packet_batch.blocks+0x388>
     79c:      	tbz	w13, #0x7, 0x720 <_llm_rows.packet_batch.blocks+0x294>
     7a0:      	b	0x820 <_llm_rows.packet_batch.blocks+0x394>
     7a4:      	fmov	x13, d23
     7a8:      	ldr	s20, [x13]
     7ac:      	and	w13, w12, #0xff
     7b0:      	tbz	w13, #0x1, 0x764 <_llm_rows.packet_batch.blocks+0x2d8>
     7b4:      	mov.d	x14, v23[1]
     7b8:      	ld1.s	{ v20 }[1], [x14]
     7bc:      	add.2d	v23, v22, v3
     7c0:      	shl.2d	v23, v23, #0x2
     7c4:      	add.2d	v23, v19, v23
     7c8:      	tbz	w13, #0x2, 0x774 <_llm_rows.packet_batch.blocks+0x2e8>
     7cc:      	fmov	x14, d23
     7d0:      	ld1.s	{ v20 }[2], [x14]
     7d4:      	tbz	w13, #0x3, 0x778 <_llm_rows.packet_batch.blocks+0x2ec>
     7d8:      	mov.d	x14, v23[1]
     7dc:      	ld1.s	{ v20 }[3], [x14]
     7e0:      	add.2d	v23, v22, v4
     7e4:      	shl.2d	v23, v23, #0x2
     7e8:      	add.2d	v23, v19, v23
     7ec:      	tbz	w13, #0x4, 0x788 <_llm_rows.packet_batch.blocks+0x2fc>
     7f0:      	fmov	x14, d23
     7f4:      	ld1.s	{ v21 }[0], [x14]
     7f8:      	tbz	w13, #0x5, 0x78c <_llm_rows.packet_batch.blocks+0x300>
     7fc:      	mov.d	x14, v23[1]
     800:      	ld1.s	{ v21 }[1], [x14]
     804:      	add.2d	v22, v22, v2
     808:      	shl.2d	v22, v22, #0x2
     80c:      	add.2d	v22, v19, v22
     810:      	tbz	w13, #0x6, 0x79c <_llm_rows.packet_batch.blocks+0x310>
     814:      	fmov	x14, d22
     818:      	ld1.s	{ v21 }[2], [x14]
     81c:      	tbz	w13, #0x7, 0x720 <_llm_rows.packet_batch.blocks+0x294>
     820:      	mov.d	x13, v22[1]
     824:      	ld1.s	{ v21 }[3], [x13]
     828:      	b	0x720 <_llm_rows.packet_batch.blocks+0x294>
     82c:      	add	x11, sp, #0x6, lsl #12  ; =0x6000
     830:      	add	x11, x11, #0x70
     834:      	mov	w12, #0x180             ; =384
     838:      	b	0x858 <_llm_rows.packet_batch.blocks+0x3cc>
     83c:      	ldp	q22, q23, [x11]
     840:      	bif.16b	v21, v23, v0
     844:      	bif.16b	v20, v22, v1
     848:      	stp	q20, q21, [x11], #0x20
     84c:      	add	x12, x12, #0x1
     850:      	cmp	x12, #0x300
     854:      	b.eq	0x948 <_llm_rows.packet_batch.blocks+0x4bc>
     858:      	dup.2d	v22, x12
     85c:      	fmov	w13, s6
     860:      	add.2d	v20, v22, v5
     864:      	shl.2d	v20, v20, #0x2
     868:      	add.2d	v23, v19, v20
     86c:      	movi.2d	v20, #0000000000000000
     870:      	movi.2d	v21, #0000000000000000
     874:      	tbnz	w13, #0x0, 0x8c0 <_llm_rows.packet_batch.blocks+0x434>
     878:      	and	w13, w13, #0xff
     87c:      	tbnz	w13, #0x1, 0x8d0 <_llm_rows.packet_batch.blocks+0x444>
     880:      	add.2d	v23, v22, v3
     884:      	shl.2d	v23, v23, #0x2
     888:      	add.2d	v23, v19, v23
     88c:      	tbnz	w13, #0x2, 0x8e8 <_llm_rows.packet_batch.blocks+0x45c>
     890:      	tbnz	w13, #0x3, 0x8f4 <_llm_rows.packet_batch.blocks+0x468>
     894:      	add.2d	v23, v22, v4
     898:      	shl.2d	v23, v23, #0x2
     89c:      	add.2d	v23, v19, v23
     8a0:      	tbnz	w13, #0x4, 0x90c <_llm_rows.packet_batch.blocks+0x480>
     8a4:      	tbnz	w13, #0x5, 0x918 <_llm_rows.packet_batch.blocks+0x48c>
     8a8:      	add.2d	v22, v22, v2
     8ac:      	shl.2d	v22, v22, #0x2
     8b0:      	add.2d	v22, v19, v22
     8b4:      	tbnz	w13, #0x6, 0x930 <_llm_rows.packet_batch.blocks+0x4a4>
     8b8:      	tbz	w13, #0x7, 0x83c <_llm_rows.packet_batch.blocks+0x3b0>
     8bc:      	b	0x93c <_llm_rows.packet_batch.blocks+0x4b0>
     8c0:      	fmov	x14, d23
     8c4:      	ldr	s20, [x14]
     8c8:      	and	w13, w13, #0xff
     8cc:      	tbz	w13, #0x1, 0x880 <_llm_rows.packet_batch.blocks+0x3f4>
     8d0:      	mov.d	x14, v23[1]
     8d4:      	ld1.s	{ v20 }[1], [x14]
     8d8:      	add.2d	v23, v22, v3
     8dc:      	shl.2d	v23, v23, #0x2
     8e0:      	add.2d	v23, v19, v23
     8e4:      	tbz	w13, #0x2, 0x890 <_llm_rows.packet_batch.blocks+0x404>
     8e8:      	fmov	x14, d23
     8ec:      	ld1.s	{ v20 }[2], [x14]
     8f0:      	tbz	w13, #0x3, 0x894 <_llm_rows.packet_batch.blocks+0x408>
     8f4:      	mov.d	x14, v23[1]
     8f8:      	ld1.s	{ v20 }[3], [x14]
     8fc:      	add.2d	v23, v22, v4
     900:      	shl.2d	v23, v23, #0x2
     904:      	add.2d	v23, v19, v23
     908:      	tbz	w13, #0x4, 0x8a4 <_llm_rows.packet_batch.blocks+0x418>
     90c:      	fmov	x14, d23
     910:      	ld1.s	{ v21 }[0], [x14]
     914:      	tbz	w13, #0x5, 0x8a8 <_llm_rows.packet_batch.blocks+0x41c>
     918:      	mov.d	x14, v23[1]
     91c:      	ld1.s	{ v21 }[1], [x14]
     920:      	add.2d	v22, v22, v2
     924:      	shl.2d	v22, v22, #0x2
     928:      	add.2d	v22, v19, v22
     92c:      	tbz	w13, #0x6, 0x8b8 <_llm_rows.packet_batch.blocks+0x42c>
     930:      	fmov	x14, d22
     934:      	ld1.s	{ v21 }[2], [x14]
     938:      	tbz	w13, #0x7, 0x83c <_llm_rows.packet_batch.blocks+0x3b0>
     93c:      	mov.d	x13, v22[1]
     940:      	ld1.s	{ v21 }[3], [x13]
     944:      	b	0x83c <_llm_rows.packet_batch.blocks+0x3b0>
     948:      	mov	x11, #0x0               ; =0
     94c:      	mov	w12, #0x180             ; =384
     950:      	dup.2s	v19, w12
     954:      	xtn.2s	v18, v18
     958:      	umull.2d	v18, v18, v19
     95c:      	xtn.2s	v16, v16
     960:      	umull.2d	v16, v16, v19
     964:      	xtn.2s	v17, v17
     968:      	umull.2d	v17, v17, v19
     96c:      	xtn.2s	v7, v7
     970:      	umull.2d	v7, v7, v19
     974:      	b	0x998 <_llm_rows.packet_batch.blocks+0x50c>
     978:      	add	x12, x27, x11, lsl #5
     97c:      	ldp	q21, q22, [x12]
     980:      	bif.16b	v20, v22, v0
     984:      	bif.16b	v19, v21, v1
     988:      	stp	q19, q20, [x12]
     98c:      	add	x11, x11, #0x1
     990:      	cmp	x11, #0x180
     994:      	b.eq	0xa8c <_llm_rows.packet_batch.blocks+0x600>
     998:      	fmov	w12, s6
     99c:      	dup.2d	v21, x11
     9a0:      	add.2d	v19, v21, v18
     9a4:      	shl.2d	v19, v19, #0x2
     9a8:      	dup.2d	v22, x10
     9ac:      	add.2d	v23, v22, v19
     9b0:      	movi.2d	v19, #0000000000000000
     9b4:      	movi.2d	v20, #0000000000000000
     9b8:      	tbnz	w12, #0x0, 0xa04 <_llm_rows.packet_batch.blocks+0x578>
     9bc:      	and	w12, w12, #0xff
     9c0:      	tbnz	w12, #0x1, 0xa14 <_llm_rows.packet_batch.blocks+0x588>
     9c4:      	add.2d	v23, v21, v16
     9c8:      	shl.2d	v23, v23, #0x2
     9cc:      	add.2d	v23, v22, v23
     9d0:      	tbnz	w12, #0x2, 0xa2c <_llm_rows.packet_batch.blocks+0x5a0>
     9d4:      	tbnz	w12, #0x3, 0xa38 <_llm_rows.packet_batch.blocks+0x5ac>
     9d8:      	add.2d	v23, v21, v17
     9dc:      	shl.2d	v23, v23, #0x2
     9e0:      	add.2d	v23, v22, v23
     9e4:      	tbnz	w12, #0x4, 0xa50 <_llm_rows.packet_batch.blocks+0x5c4>
     9e8:      	tbnz	w12, #0x5, 0xa5c <_llm_rows.packet_batch.blocks+0x5d0>
     9ec:      	add.2d	v21, v21, v7
     9f0:      	shl.2d	v21, v21, #0x2
     9f4:      	add.2d	v21, v22, v21
     9f8:      	tbnz	w12, #0x6, 0xa74 <_llm_rows.packet_batch.blocks+0x5e8>
     9fc:      	tbz	w12, #0x7, 0x978 <_llm_rows.packet_batch.blocks+0x4ec>
     a00:      	b	0xa80 <_llm_rows.packet_batch.blocks+0x5f4>
     a04:      	fmov	x13, d23
     a08:      	ldr	s19, [x13]
     a0c:      	and	w12, w12, #0xff
     a10:      	tbz	w12, #0x1, 0x9c4 <_llm_rows.packet_batch.blocks+0x538>
     a14:      	mov.d	x13, v23[1]
     a18:      	ld1.s	{ v19 }[1], [x13]
     a1c:      	add.2d	v23, v21, v16
     a20:      	shl.2d	v23, v23, #0x2
     a24:      	add.2d	v23, v22, v23
     a28:      	tbz	w12, #0x2, 0x9d4 <_llm_rows.packet_batch.blocks+0x548>
     a2c:      	fmov	x13, d23
     a30:      	ld1.s	{ v19 }[2], [x13]
     a34:      	tbz	w12, #0x3, 0x9d8 <_llm_rows.packet_batch.blocks+0x54c>
     a38:      	mov.d	x13, v23[1]
     a3c:      	ld1.s	{ v19 }[3], [x13]
     a40:      	add.2d	v23, v21, v17
     a44:      	shl.2d	v23, v23, #0x2
     a48:      	add.2d	v23, v22, v23
     a4c:      	tbz	w12, #0x4, 0x9e8 <_llm_rows.packet_batch.blocks+0x55c>
     a50:      	fmov	x13, d23
     a54:      	ld1.s	{ v20 }[0], [x13]
     a58:      	tbz	w12, #0x5, 0x9ec <_llm_rows.packet_batch.blocks+0x560>
     a5c:      	mov.d	x13, v23[1]
     a60:      	ld1.s	{ v20 }[1], [x13]
     a64:      	add.2d	v21, v21, v7
     a68:      	shl.2d	v21, v21, #0x2
     a6c:      	add.2d	v21, v22, v21
     a70:      	tbz	w12, #0x6, 0x9fc <_llm_rows.packet_batch.blocks+0x570>
     a74:      	fmov	x13, d21
     a78:      	ld1.s	{ v20 }[2], [x13]
     a7c:      	tbz	w12, #0x7, 0x978 <_llm_rows.packet_batch.blocks+0x4ec>
     a80:      	mov.d	x12, v21[1]
     a84:      	ld1.s	{ v20 }[3], [x12]
     a88:      	b	0x978 <_llm_rows.packet_batch.blocks+0x4ec>
     a8c:      	mov	x10, #0x0               ; =0
     a90:      	b	0xab4 <_llm_rows.packet_batch.blocks+0x628>
     a94:      	add	x11, x23, x10, lsl #5
     a98:      	ldp	q21, q22, [x11]
     a9c:      	bif.16b	v20, v22, v0
     aa0:      	bif.16b	v19, v21, v1
     aa4:      	stp	q19, q20, [x11]
     aa8:      	add	x10, x10, #0x1
     aac:      	cmp	x10, #0x180
     ab0:      	b.eq	0xba8 <_llm_rows.packet_batch.blocks+0x71c>
     ab4:      	fmov	w11, s6
     ab8:      	dup.2d	v21, x10
     abc:      	add.2d	v19, v21, v18
     ac0:      	shl.2d	v19, v19, #0x2
     ac4:      	dup.2d	v22, x9
     ac8:      	add.2d	v23, v22, v19
     acc:      	movi.2d	v19, #0000000000000000
     ad0:      	movi.2d	v20, #0000000000000000
     ad4:      	tbnz	w11, #0x0, 0xb20 <_llm_rows.packet_batch.blocks+0x694>
     ad8:      	and	w11, w11, #0xff
     adc:      	tbnz	w11, #0x1, 0xb30 <_llm_rows.packet_batch.blocks+0x6a4>
     ae0:      	add.2d	v23, v21, v16
     ae4:      	shl.2d	v23, v23, #0x2
     ae8:      	add.2d	v23, v22, v23
     aec:      	tbnz	w11, #0x2, 0xb48 <_llm_rows.packet_batch.blocks+0x6bc>
     af0:      	tbnz	w11, #0x3, 0xb54 <_llm_rows.packet_batch.blocks+0x6c8>
     af4:      	add.2d	v23, v21, v17
     af8:      	shl.2d	v23, v23, #0x2
     afc:      	add.2d	v23, v22, v23
     b00:      	tbnz	w11, #0x4, 0xb6c <_llm_rows.packet_batch.blocks+0x6e0>
     b04:      	tbnz	w11, #0x5, 0xb78 <_llm_rows.packet_batch.blocks+0x6ec>
     b08:      	add.2d	v21, v21, v7
     b0c:      	shl.2d	v21, v21, #0x2
     b10:      	add.2d	v21, v22, v21
     b14:      	tbnz	w11, #0x6, 0xb90 <_llm_rows.packet_batch.blocks+0x704>
     b18:      	tbz	w11, #0x7, 0xa94 <_llm_rows.packet_batch.blocks+0x608>
     b1c:      	b	0xb9c <_llm_rows.packet_batch.blocks+0x710>
     b20:      	fmov	x12, d23
     b24:      	ldr	s19, [x12]
     b28:      	and	w11, w11, #0xff
     b2c:      	tbz	w11, #0x1, 0xae0 <_llm_rows.packet_batch.blocks+0x654>
     b30:      	mov.d	x12, v23[1]
     b34:      	ld1.s	{ v19 }[1], [x12]
     b38:      	add.2d	v23, v21, v16
     b3c:      	shl.2d	v23, v23, #0x2
     b40:      	add.2d	v23, v22, v23
     b44:      	tbz	w11, #0x2, 0xaf0 <_llm_rows.packet_batch.blocks+0x664>
     b48:      	fmov	x12, d23
     b4c:      	ld1.s	{ v19 }[2], [x12]
     b50:      	tbz	w11, #0x3, 0xaf4 <_llm_rows.packet_batch.blocks+0x668>
     b54:      	mov.d	x12, v23[1]
     b58:      	ld1.s	{ v19 }[3], [x12]
     b5c:      	add.2d	v23, v21, v17
     b60:      	shl.2d	v23, v23, #0x2
     b64:      	add.2d	v23, v22, v23
     b68:      	tbz	w11, #0x4, 0xb04 <_llm_rows.packet_batch.blocks+0x678>
     b6c:      	fmov	x12, d23
     b70:      	ld1.s	{ v20 }[0], [x12]
     b74:      	tbz	w11, #0x5, 0xb08 <_llm_rows.packet_batch.blocks+0x67c>
     b78:      	mov.d	x12, v23[1]
     b7c:      	ld1.s	{ v20 }[1], [x12]
     b80:      	add.2d	v21, v21, v7
     b84:      	shl.2d	v21, v21, #0x2
     b88:      	add.2d	v21, v22, v21
     b8c:      	tbz	w11, #0x6, 0xb18 <_llm_rows.packet_batch.blocks+0x68c>
     b90:      	fmov	x12, d21
     b94:      	ld1.s	{ v20 }[2], [x12]
     b98:      	tbz	w11, #0x7, 0xa94 <_llm_rows.packet_batch.blocks+0x608>
     b9c:      	mov.d	x11, v21[1]
     ba0:      	ld1.s	{ v20 }[3], [x11]
     ba4:      	b	0xa94 <_llm_rows.packet_batch.blocks+0x608>
     ba8:      	mov	x9, #0x0                ; =0
     bac:      	b	0xbbc <_llm_rows.packet_batch.blocks+0x730>
     bb0:      	add	x9, x9, #0x1
     bb4:      	cmp	x9, #0x180
     bb8:      	b.eq	0xce0 <_llm_rows.packet_batch.blocks+0x854>
     bbc:      	fmov	w10, s6
     bc0:      	dup.2d	v16, x9
     bc4:      	add.2d	v7, v16, v5
     bc8:      	lsl	x11, x9, #5
     bcc:      	add	x12, x25, x11
     bd0:      	ldp	q19, q17, [x12]
     bd4:      	add	x12, x27, x11
     bd8:      	ldp	q20, q18, [x12]
     bdc:      	fmul.4s	v21, v19, v20
     be0:      	add	x12, x16, x11
     be4:      	ldp	q22, q19, [x12]
     be8:      	add	x11, x23, x11
     bec:      	ldp	q23, q20, [x11]
     bf0:      	fmul.4s	v22, v22, v23
     bf4:      	fsub.4s	v21, v21, v22
     bf8:      	and.16b	v21, v1, v21
     bfc:      	shl.2d	v22, v7, #0x2
     c00:      	dup.2d	v7, x8
     c04:      	add.2d	v22, v7, v22
     c08:      	tbnz	w10, #0x0, 0xc6c <_llm_rows.packet_batch.blocks+0x7e0>
     c0c:      	and	w10, w10, #0xff
     c10:      	tbnz	w10, #0x1, 0xc7c <_llm_rows.packet_batch.blocks+0x7f0>
     c14:      	add.2d	v22, v16, v3
     c18:      	shl.2d	v22, v22, #0x2
     c1c:      	add.2d	v22, v7, v22
     c20:      	tbnz	w10, #0x2, 0xc94 <_llm_rows.packet_batch.blocks+0x808>
     c24:      	tbz	w10, #0x3, 0xc30 <_llm_rows.packet_batch.blocks+0x7a4>
     c28:      	mov.d	x11, v22[1]
     c2c:      	st1.s	{ v21 }[3], [x11]
     c30:      	add.2d	v21, v16, v4
     c34:      	fmul.4s	v17, v17, v18
     c38:      	fmul.4s	v18, v19, v20
     c3c:      	fsub.4s	v17, v17, v18
     c40:      	and.16b	v17, v0, v17
     c44:      	shl.2d	v18, v21, #0x2
     c48:      	add.2d	v18, v7, v18
     c4c:      	tbnz	w10, #0x4, 0xca4 <_llm_rows.packet_batch.blocks+0x818>
     c50:      	tbnz	w10, #0x5, 0xcb0 <_llm_rows.packet_batch.blocks+0x824>
     c54:      	add.2d	v16, v16, v2
     c58:      	shl.2d	v16, v16, #0x2
     c5c:      	add.2d	v16, v7, v16
     c60:      	tbnz	w10, #0x6, 0xcc8 <_llm_rows.packet_batch.blocks+0x83c>
     c64:      	tbz	w10, #0x7, 0xbb0 <_llm_rows.packet_batch.blocks+0x724>
     c68:      	b	0xcd4 <_llm_rows.packet_batch.blocks+0x848>
     c6c:      	fmov	x11, d22
     c70:      	str	s21, [x11]
     c74:      	and	w10, w10, #0xff
     c78:      	tbz	w10, #0x1, 0xc14 <_llm_rows.packet_batch.blocks+0x788>
     c7c:      	mov.d	x11, v22[1]
     c80:      	st1.s	{ v21 }[1], [x11]
     c84:      	add.2d	v22, v16, v3
     c88:      	shl.2d	v22, v22, #0x2
     c8c:      	add.2d	v22, v7, v22
     c90:      	tbz	w10, #0x2, 0xc24 <_llm_rows.packet_batch.blocks+0x798>
     c94:      	fmov	x11, d22
     c98:      	st1.s	{ v21 }[2], [x11]
     c9c:      	tbnz	w10, #0x3, 0xc28 <_llm_rows.packet_batch.blocks+0x79c>
     ca0:      	b	0xc30 <_llm_rows.packet_batch.blocks+0x7a4>
     ca4:      	fmov	x11, d18
     ca8:      	str	s17, [x11]
     cac:      	tbz	w10, #0x5, 0xc54 <_llm_rows.packet_batch.blocks+0x7c8>
     cb0:      	mov.d	x11, v18[1]
     cb4:      	st1.s	{ v17 }[1], [x11]
     cb8:      	add.2d	v16, v16, v2
     cbc:      	shl.2d	v16, v16, #0x2
     cc0:      	add.2d	v16, v7, v16
     cc4:      	tbz	w10, #0x6, 0xc64 <_llm_rows.packet_batch.blocks+0x7d8>
     cc8:      	fmov	x11, d16
     ccc:      	st1.s	{ v17 }[2], [x11]
     cd0:      	tbz	w10, #0x7, 0xbb0 <_llm_rows.packet_batch.blocks+0x724>
     cd4:      	mov.d	x10, v16[1]
     cd8:      	st1.s	{ v17 }[3], [x10]
     cdc:      	b	0xbb0 <_llm_rows.packet_batch.blocks+0x724>
     ce0:      	mov	x8, #0x0                ; =0
     ce4:      	b	0xcf4 <_llm_rows.packet_batch.blocks+0x868>
     ce8:      	add	x8, x8, #0x1
     cec:      	cmp	x8, #0x180
     cf0:      	b.eq	0x524 <_llm_rows.packet_batch.blocks+0x98>
     cf4:      	fmov	w9, s6
     cf8:      	add	x10, x8, #0x180
     cfc:      	dup.2d	v16, x10
     d00:      	add.2d	v22, v16, v5
     d04:      	lsl	x10, x8, #5
     d08:      	add	x11, x25, x10
     d0c:      	ldp	q19, q17, [x11]
     d10:      	add	x11, x23, x10
     d14:      	ldp	q20, q18, [x11]
     d18:      	fmul.4s	v21, v19, v20
     d1c:      	add	x11, x16, x10
     d20:      	ldp	q23, q19, [x11]
     d24:      	add	x10, x27, x10
     d28:      	ldp	q24, q20, [x10]
     d2c:      	fmul.4s	v23, v23, v24
     d30:      	fadd.4s	v21, v21, v23
     d34:      	and.16b	v21, v1, v21
     d38:      	shl.2d	v22, v22, #0x2
     d3c:      	add.2d	v22, v7, v22
     d40:      	tbnz	w9, #0x0, 0xda4 <_llm_rows.packet_batch.blocks+0x918>
     d44:      	and	w9, w9, #0xff
     d48:      	tbnz	w9, #0x1, 0xdb4 <_llm_rows.packet_batch.blocks+0x928>
     d4c:      	add.2d	v22, v16, v3
     d50:      	shl.2d	v22, v22, #0x2
     d54:      	add.2d	v22, v7, v22
     d58:      	tbnz	w9, #0x2, 0xdcc <_llm_rows.packet_batch.blocks+0x940>
     d5c:      	tbz	w9, #0x3, 0xd68 <_llm_rows.packet_batch.blocks+0x8dc>
     d60:      	mov.d	x10, v22[1]
     d64:      	st1.s	{ v21 }[3], [x10]
     d68:      	add.2d	v21, v16, v4
     d6c:      	fmul.4s	v17, v17, v18
     d70:      	fmul.4s	v18, v19, v20
     d74:      	fadd.4s	v17, v17, v18
     d78:      	and.16b	v17, v0, v17
     d7c:      	shl.2d	v18, v21, #0x2
     d80:      	add.2d	v18, v7, v18
     d84:      	tbnz	w9, #0x4, 0xddc <_llm_rows.packet_batch.blocks+0x950>
     d88:      	tbnz	w9, #0x5, 0xde8 <_llm_rows.packet_batch.blocks+0x95c>
     d8c:      	add.2d	v16, v16, v2
     d90:      	shl.2d	v16, v16, #0x2
     d94:      	add.2d	v16, v7, v16
     d98:      	tbnz	w9, #0x6, 0xe00 <_llm_rows.packet_batch.blocks+0x974>
     d9c:      	tbz	w9, #0x7, 0xce8 <_llm_rows.packet_batch.blocks+0x85c>
     da0:      	b	0xe0c <_llm_rows.packet_batch.blocks+0x980>
     da4:      	fmov	x10, d22
     da8:      	str	s21, [x10]
     dac:      	and	w9, w9, #0xff
     db0:      	tbz	w9, #0x1, 0xd4c <_llm_rows.packet_batch.blocks+0x8c0>
     db4:      	mov.d	x10, v22[1]
     db8:      	st1.s	{ v21 }[1], [x10]
     dbc:      	add.2d	v22, v16, v3
     dc0:      	shl.2d	v22, v22, #0x2
     dc4:      	add.2d	v22, v7, v22
     dc8:      	tbz	w9, #0x2, 0xd5c <_llm_rows.packet_batch.blocks+0x8d0>
     dcc:      	fmov	x10, d22
     dd0:      	st1.s	{ v21 }[2], [x10]
     dd4:      	tbnz	w9, #0x3, 0xd60 <_llm_rows.packet_batch.blocks+0x8d4>
     dd8:      	b	0xd68 <_llm_rows.packet_batch.blocks+0x8dc>
     ddc:      	fmov	x10, d18
     de0:      	str	s17, [x10]
     de4:      	tbz	w9, #0x5, 0xd8c <_llm_rows.packet_batch.blocks+0x900>
     de8:      	mov.d	x10, v18[1]
     dec:      	st1.s	{ v17 }[1], [x10]
     df0:      	add.2d	v16, v16, v2
     df4:      	shl.2d	v16, v16, #0x2
     df8:      	add.2d	v16, v7, v16
     dfc:      	tbz	w9, #0x6, 0xd9c <_llm_rows.packet_batch.blocks+0x910>
     e00:      	fmov	x10, d16
     e04:      	st1.s	{ v17 }[2], [x10]
     e08:      	tbz	w9, #0x7, 0xce8 <_llm_rows.packet_batch.blocks+0x85c>
     e0c:      	mov.d	x9, v16[1]
     e10:      	st1.s	{ v17 }[3], [x9]
     e14:      	b	0xce8 <_llm_rows.packet_batch.blocks+0x85c>
     e18:      	add	sp, sp, #0xc, lsl #12   ; =0xc000
     e1c:      	add	sp, sp, #0x70
     e20:      	ldp	x29, x30, [sp, #0x60]
     e24:      	ldp	x20, x19, [sp, #0x50]
     e28:      	ldp	x22, x21, [sp, #0x40]
     e2c:      	ldp	x24, x23, [sp, #0x30]
     e30:      	ldp	x26, x25, [sp, #0x20]
     e34:      	ldp	x28, x27, [sp, #0x10]
     e38:      	ldp	d9, d8, [sp], #0x70
     e3c:      	ret

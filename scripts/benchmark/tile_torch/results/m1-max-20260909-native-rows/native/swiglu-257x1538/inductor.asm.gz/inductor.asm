
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/swiglu-257x1538/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0x90
     6b4:      	stp	d9, d8, [sp, #0x40]
     6b8:      	stp	x24, x23, [sp, #0x50]
     6bc:      	stp	x22, x21, [sp, #0x60]
     6c0:      	stp	x20, x19, [sp, #0x70]
     6c4:      	stp	x29, x30, [sp, #0x80]
     6c8:      	add	x29, sp, #0x80
     6cc:      	mov	x19, x2
     6d0:      	mov	x20, x1
     6d4:      	mov	x21, x0
     6d8:      	mov	w23, #0x7fe             ; =2046
     6dc:      	movk	w23, #0x6, lsl #16
     6e0:      	str	wzr, [sp, #0x20]
     6e4:      	adrp	x22, 0x4000 <dyld_stub_binder+0x4000>
     6e8:      	ldr	x22, [x22, #0x90]
     6ec:      	add	x8, sp, #0x20
     6f0:      	str	x8, [x22]
     6f4:      	mov	x24, #-0x4              ; =-4
     6f8:      	add	x24, x24, #0x4
     6fc:      	add	x8, x23, #0x2
     700:      	cmp	x24, x8
     704:      	b.hs	0x768 <_kernel+0xb8>
     708:      	ldr	q1, [x21], #0x10
     70c:      	ldr	q0, [x20], #0x10
     710:      	stp	q1, q0, [sp]
     714:      	fneg.4s	v0, v1
     718:      	bl	0x1594 <dyld_stub_binder+0x1594>
     71c:      	fmov.4s	v1, #1.00000000
     720:      	fadd.4s	v0, v0, v1
     724:      	ldp	q2, q1, [sp]
     728:      	fdiv.4s	v0, v2, v0
     72c:      	fmul.4s	v0, v1, v0
     730:      	str	q0, [x19], #0x10
     734:      	cmp	x24, x23
     738:      	b.lo	0x6f8 <_kernel+0x48>
     73c:      	str	xzr, [x22]
     740:      	add	x8, sp, #0x20
     744:      	ldapr	w8, [x8]
     748:      	cbnz	w8, 0x7a4 <_kernel+0xf4>
     74c:      	ldp	x29, x30, [sp, #0x80]
     750:      	ldp	x20, x19, [sp, #0x70]
     754:      	ldp	x22, x21, [sp, #0x60]
     758:      	ldp	x24, x23, [sp, #0x50]
     75c:      	ldp	d9, d8, [sp, #0x40]
     760:      	add	sp, sp, #0x90
     764:      	ret
     768:      	ldr	d0, [x21]
     76c:      	str	q0, [sp, #0x10]
     770:      	ldr	d8, [x20]
     774:      	fneg.4s	v0, v0
     778:      	bl	0x1594 <dyld_stub_binder+0x1594>
     77c:      	fmov.2s	v1, #1.00000000
     780:      	fadd.2s	v0, v0, v1
     784:      	ldr	q1, [sp, #0x10]
     788:      	fdiv.2s	v0, v1, v0
     78c:      	fmul.2s	v0, v8, v0
     790:      	str	d0, [x19]
     794:      	str	xzr, [x22]
     798:      	add	x8, sp, #0x20
     79c:      	ldapr	w8, [x8]
     7a0:      	cbz	w8, 0x74c <_kernel+0x9c>
     7a4:      	mov	w0, #0x10               ; =16
     7a8:      	bl	0x1690 <dyld_stub_binder+0x1690>
     7ac:      	mov	x19, x0
     7b0:      	mov	w8, #0x33d              ; =829
     7b4:      	str	w8, [sp, #0x24]
     7b8:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x90>
     7bc:      	add	x0, x0, #0x9c0
     7c0:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x90>
     7c4:      	add	x1, x1, #0xa4c
     7c8:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x90>
     7cc:      	add	x3, x3, #0xa77
     7d0:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x90>
     7d4:      	add	x4, x4, #0xaf5
     7d8:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x90>
     7dc:      	add	x2, x2, #0xa74
     7e0:      	add	x8, sp, #0x28
     7e4:      	add	x5, sp, #0x24
     7e8:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x90>
     7ec:      	add	x7, x7, #0xaf7
     7f0:      	mov	x6, x2
     7f4:      	bl	0x868 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     7f8:      	mov	w21, #0x1               ; =1
     7fc:      	add	x1, sp, #0x28
     800:      	mov	x0, x19
     804:      	bl	0x15dc <dyld_stub_binder+0x15dc>
     808:      	mov	w21, #0x0               ; =0
     80c:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     810:      	ldr	x1, [x1, #0x18]
     814:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     818:      	ldr	x2, [x2, #0x8]
     81c:      	mov	x0, x19
     820:      	bl	0x16c0 <dyld_stub_binder+0x16c0>
     824:      	brk	#0x1
     828:      	mov	x20, x0
     82c:      	ldrsb	w8, [sp, #0x3f]
     830:      	tbz	w8, #0x1f, 0x84c <_kernel+0x19c>
     834:      	ldr	x0, [sp, #0x28]
     838:      	ldr	x8, [sp, #0x38]
     83c:      	and	x1, x8, #0x7fffffffffffffff
     840:      	bl	0x1678 <dyld_stub_binder+0x1678>
     844:      	tbnz	w21, #0x0, 0x858 <_kernel+0x1a8>
     848:      	b	0x860 <_kernel+0x1b0>
     84c:      	cbnz	w21, 0x858 <_kernel+0x1a8>
     850:      	b	0x860 <_kernel+0x1b0>
     854:      	mov	x20, x0
     858:      	mov	x0, x19
     85c:      	bl	0x16b4 <dyld_stub_binder+0x16b4>
     860:      	mov	x0, x20
     864:      	bl	0x15a0 <dyld_stub_binder+0x15a0>

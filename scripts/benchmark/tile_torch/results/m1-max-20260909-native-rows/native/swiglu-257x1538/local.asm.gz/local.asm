
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/swiglu-257x1538-l8/object/tile_xir_w8_80772_1788919115239422_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d11, d10, [sp, #-0x70]!
       4:      	stp	d9, d8, [sp, #0x10]
       8:      	stp	x26, x25, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      20:      	sub	sp, sp, #0x50
      24:      	ldr	x22, [x0]
      28:      	ldr	x23, [x0, #0x10]
      2c:      	ldr	x19, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w8, w8, #3
      40:      	fmov	s0, w8
      44:      	ushll.2d	v0, v0, #0x0
      48:      	fmov	x24, d0
      4c:      	mov	w25, #0x1808            ; =6152
      50:      	umaddl	x1, w24, w25, x22
      54:      	mov	w20, #0x1800            ; =6144
      58:      	add	x21, sp, #0x1, lsl #12  ; =0x1000
      5c:      	add	x21, x21, #0x830
      60:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
      64:      	add	x0, x0, #0x830
      68:      	mov	w2, #0x1800             ; =6144
      6c:      	bl	0x6c <ltmp0+0x6c>
      70:      	umaddl	x20, w24, w25, x20
      74:      	add	x8, x22, x20
      78:      	add	x9, x8, #0x4
      7c:      	ldr	s0, [x8]
      80:      	ld1.s	{ v0 }[1], [x9]
      84:      	str	q0, [sp]
      88:      	str	q0, [sp, #0x3030]
      8c:      	umaddl	x1, w24, w25, x23
      90:      	add	x22, sp, #0x10
      94:      	add	x0, sp, #0x10
      98:      	mov	w2, #0x1800             ; =6144
      9c:      	bl	0x9c <ltmp0+0x9c>
      a0:      	mov	x8, #0x0                ; =0
      a4:      	add	x9, x23, x20
      a8:      	ldr	s0, [x9], #0x4
      ac:      	ld1.s	{ v0 }[1], [x9]
      b0:      	str	q0, [sp, #0x1810]
      b4:      	mov	w9, #0x42d00000         ; =1120927744
      b8:      	dup.4s	v2, w9
      bc:      	mov	w9, #-0x3d380000        ; =-1027080192
      c0:      	dup.4s	v3, w9
      c4:      	mov	w9, #0xaa3b             ; =43579
      c8:      	movk	w9, #0x3fb8, lsl #16
      cc:      	dup.4s	v4, w9
      d0:      	umaddl	x9, w24, w25, x19
      d4:      	movi.4s	v5, #0x4b, lsl #24
      d8:      	mvni.4s	v6, #0x80, lsl #24
      dc:      	mov	w10, #0x7200            ; =29184
      e0:      	movk	w10, #0xbf31, lsl #16
      e4:      	dup.4s	v7, w10
      e8:      	mov	w10, #0xbe8e            ; =48782
      ec:      	movk	w10, #0xb5bf, lsl #16
      f0:      	dup.4s	v16, w10
      f4:      	mov	w10, #0x2bda            ; =11226
      f8:      	movk	w10, #0x3950, lsl #16
      fc:      	dup.4s	v17, w10
     100:      	mov	w10, #0x96c9            ; =38601
     104:      	movk	w10, #0x3ab6, lsl #16
     108:      	dup.4s	v18, w10
     10c:      	mov	w10, #0x88a6            ; =34982
     110:      	movk	w10, #0x3c08, lsl #16
     114:      	dup.4s	v19, w10
     118:      	mov	w10, #0xaa7a            ; =43642
     11c:      	movk	w10, #0x3d2a, lsl #16
     120:      	dup.4s	v20, w10
     124:      	mov	w10, #0xaaab            ; =43691
     128:      	movk	w10, #0x3e2a, lsl #16
     12c:      	dup.4s	v21, w10
     130:      	movi.4s	v22, #0x3f, lsl #24
     134:      	fmov.4s	v1, #1.00000000
     138:      	mvni.4s	v23, #0x7f, msl #16
     13c:      	fneg.4s	v23, v23
     140:      	mvni.4s	v24, #0x3f, msl #16
     144:      	fneg.4s	v24, v24
     148:      	lsl	x10, x8, #5
     14c:      	add	x11, x21, x10
     150:      	ldp	q25, q26, [x11]
     154:      	fneg.4s	v27, v26
     158:      	fneg.4s	v28, v25
     15c:      	fcmge.4s	v29, v2, v25
     160:      	fcmge.4s	v30, v2, v26
     164:      	fcmge.4s	v31, v25, v3
     168:      	fcmge.4s	v8, v26, v3
     16c:      	and.16b	v30, v30, v8
     170:      	and.16b	v29, v29, v31
     174:      	and.16b	v28, v29, v28
     178:      	and.16b	v27, v30, v27
     17c:      	fmul.4s	v29, v27, v4
     180:      	fmul.4s	v30, v28, v4
     184:      	mov.16b	v31, v6
     188:      	bsl.16b	v31, v5, v30
     18c:      	mov.16b	v8, v6
     190:      	bsl.16b	v8, v5, v29
     194:      	fadd.4s	v29, v29, v8
     198:      	fadd.4s	v30, v30, v31
     19c:      	fsub.4s	v30, v30, v31
     1a0:      	fsub.4s	v29, v29, v8
     1a4:      	fcvtzs.4s	v29, v29
     1a8:      	fcvtzs.4s	v30, v30
     1ac:      	scvtf.4s	v31, v30
     1b0:      	scvtf.4s	v8, v29
     1b4:      	fmul.4s	v9, v8, v7
     1b8:      	fmul.4s	v10, v31, v7
     1bc:      	fadd.4s	v28, v28, v10
     1c0:      	fadd.4s	v27, v27, v9
     1c4:      	fmul.4s	v31, v31, v16
     1c8:      	fmul.4s	v8, v8, v16
     1cc:      	fadd.4s	v27, v27, v8
     1d0:      	fadd.4s	v28, v28, v31
     1d4:      	fmul.4s	v31, v28, v17
     1d8:      	fmul.4s	v8, v27, v17
     1dc:      	fadd.4s	v8, v8, v18
     1e0:      	fadd.4s	v31, v31, v18
     1e4:      	fmul.4s	v31, v28, v31
     1e8:      	fmul.4s	v8, v27, v8
     1ec:      	fadd.4s	v8, v8, v19
     1f0:      	fadd.4s	v31, v31, v19
     1f4:      	fmul.4s	v31, v28, v31
     1f8:      	fmul.4s	v8, v27, v8
     1fc:      	fadd.4s	v8, v8, v20
     200:      	fadd.4s	v31, v31, v20
     204:      	fmul.4s	v31, v28, v31
     208:      	fmul.4s	v8, v27, v8
     20c:      	fadd.4s	v8, v8, v21
     210:      	fadd.4s	v31, v31, v21
     214:      	fmul.4s	v31, v28, v31
     218:      	fmul.4s	v8, v27, v8
     21c:      	fadd.4s	v8, v8, v22
     220:      	fadd.4s	v31, v31, v22
     224:      	fmul.4s	v9, v27, v27
     228:      	fmul.4s	v10, v28, v28
     22c:      	fmul.4s	v31, v10, v31
     230:      	fmul.4s	v8, v9, v8
     234:      	fadd.4s	v27, v27, v8
     238:      	fadd.4s	v28, v28, v31
     23c:      	sshr.4s	v31, v30, #0x1
     240:      	fadd.4s	v28, v28, v1
     244:      	sshr.4s	v8, v29, #0x1
     248:      	shl.4s	v9, v8, #0x17
     24c:      	shl.4s	v10, v31, #0x17
     250:      	add.4s	v10, v10, v1
     254:      	add.4s	v9, v9, v1
     258:      	fadd.4s	v27, v27, v1
     25c:      	fmul.4s	v27, v27, v9
     260:      	sub.4s	v29, v29, v8
     264:      	sub.4s	v30, v30, v31
     268:      	shl.4s	v30, v30, #0x17
     26c:      	shl.4s	v29, v29, #0x17
     270:      	fmul.4s	v28, v28, v10
     274:      	add.4s	v29, v29, v1
     278:      	add.4s	v30, v30, v1
     27c:      	fmul.4s	v28, v28, v30
     280:      	fmul.4s	v27, v27, v29
     284:      	fcmgt.4s	v29, v26, v2
     288:      	fcmgt.4s	v30, v25, v2
     28c:      	fcmgt.4s	v31, v3, v25
     290:      	fcmgt.4s	v8, v3, v26
     294:      	fcmeq.4s	v9, v26, v26
     298:      	fadd.4s	v27, v27, v1
     29c:      	fadd.4s	v28, v28, v1
     2a0:      	fcmeq.4s	v10, v25, v25
     2a4:      	bit.16b	v28, v1, v30
     2a8:      	bit.16b	v27, v1, v29
     2ac:      	bit.16b	v27, v23, v8
     2b0:      	bit.16b	v28, v23, v31
     2b4:      	bif.16b	v28, v24, v10
     2b8:      	bif.16b	v27, v24, v9
     2bc:      	fdiv.4s	v26, v26, v27
     2c0:      	fdiv.4s	v25, v25, v28
     2c4:      	add	x11, x22, x10
     2c8:      	ldp	q28, q27, [x11]
     2cc:      	fmul.4s	v25, v28, v25
     2d0:      	fmul.4s	v26, v27, v26
     2d4:      	add	x10, x9, x10
     2d8:      	stp	q25, q26, [x10]
     2dc:      	add	x8, x8, #0x1
     2e0:      	cmp	x8, #0xc0
     2e4:      	b.ne	0x148 <ltmp0+0x148>
     2e8:      	movi.2d	v3, #0000000000000000
     2ec:      	movi.2d	v2, #0000000000000000
     2f0:      	ldr	q4, [sp]
     2f4:      	mov.d	v2[0], v4[0]
     2f8:      	fneg.4s	v4, v2
     2fc:      	mov.d	v3[0], v4[0]
     300:      	mov	w8, #-0x3d300000        ; =-1026555904
     304:      	dup.4s	v4, w8
     308:      	mov	w8, #0x42c80000         ; =1120403456
     30c:      	dup.4s	v5, w8
     310:      	fcmge.4s	v6, v3, v4
     314:      	fcmge.4s	v7, v5, v3
     318:      	and.16b	v6, v6, v7
     31c:      	mov	w8, #0xaa3b             ; =43579
     320:      	movk	w8, #0x3fb8, lsl #16
     324:      	dup.4s	v7, w8
     328:      	and.16b	v6, v6, v3
     32c:      	fmul.4s	v7, v6, v7
     330:      	movi.4s	v16, #0x4b, lsl #24
     334:      	mvni.4s	v17, #0x80, lsl #24
     338:      	bif.16b	v16, v7, v17
     33c:      	fadd.4s	v7, v7, v16
     340:      	fsub.4s	v7, v7, v16
     344:      	fcvtzs.4s	v7, v7
     348:      	scvtf.4s	v16, v7
     34c:      	mov	w8, #0x7200             ; =29184
     350:      	movk	w8, #0xbf31, lsl #16
     354:      	dup.4s	v17, w8
     358:      	fmul.4s	v17, v16, v17
     35c:      	fadd.4s	v6, v6, v17
     360:      	mov	w8, #0xbe8e             ; =48782
     364:      	movk	w8, #0xb5bf, lsl #16
     368:      	dup.4s	v17, w8
     36c:      	fmul.4s	v16, v16, v17
     370:      	fadd.4s	v6, v6, v16
     374:      	mov	w8, #0x2bda             ; =11226
     378:      	movk	w8, #0x3950, lsl #16
     37c:      	dup.4s	v16, w8
     380:      	fmul.4s	v16, v6, v16
     384:      	mov	w8, #0x96c9             ; =38601
     388:      	movk	w8, #0x3ab6, lsl #16
     38c:      	dup.4s	v17, w8
     390:      	fadd.4s	v16, v16, v17
     394:      	mov	w8, #0x88a6             ; =34982
     398:      	movk	w8, #0x3c08, lsl #16
     39c:      	dup.4s	v17, w8
     3a0:      	fmul.4s	v16, v6, v16
     3a4:      	fadd.4s	v16, v16, v17
     3a8:      	fmul.4s	v16, v6, v16
     3ac:      	mov	w8, #0xaa7a             ; =43642
     3b0:      	movk	w8, #0x3d2a, lsl #16
     3b4:      	dup.4s	v17, w8
     3b8:      	fadd.4s	v16, v16, v17
     3bc:      	fmul.4s	v16, v6, v16
     3c0:      	mov	w8, #0xaaab             ; =43691
     3c4:      	movk	w8, #0x3e2a, lsl #16
     3c8:      	dup.4s	v17, w8
     3cc:      	fadd.4s	v16, v16, v17
     3d0:      	fmul.4s	v16, v6, v16
     3d4:      	movi.4s	v17, #0x3f, lsl #24
     3d8:      	fadd.4s	v16, v16, v17
     3dc:      	fmul.4s	v17, v6, v6
     3e0:      	fmul.4s	v16, v17, v16
     3e4:      	fadd.4s	v6, v6, v16
     3e8:      	fadd.4s	v6, v6, v1
     3ec:      	sshr.4s	v16, v7, #0x1
     3f0:      	shl.4s	v17, v16, #0x17
     3f4:      	add.4s	v17, v17, v1
     3f8:      	fmul.4s	v6, v6, v17
     3fc:      	sub.4s	v7, v7, v16
     400:      	shl.4s	v7, v7, #0x17
     404:      	add.4s	v7, v7, v1
     408:      	fmul.4s	v6, v6, v7
     40c:      	fcmgt.4s	v4, v4, v3
     410:      	fcmgt.4s	v5, v3, v5
     414:      	fcmeq.4s	v3, v3, v3
     418:      	fadd.4s	v6, v6, v1
     41c:      	bif.16b	v1, v6, v4
     420:      	mvni.4s	v4, #0x7f, msl #16
     424:      	fneg.4s	v4, v4
     428:      	bit.16b	v1, v4, v5
     42c:      	mvni.4s	v4, #0x3f, msl #16
     430:      	fneg.4s	v4, v4
     434:      	bif.16b	v1, v4, v3
     438:      	fdiv.2s	v1, v2, v1
     43c:      	fmul.2s	v0, v1, v0
     440:      	str	d0, [x19, x20]
     444:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     448:      	add	sp, sp, #0x50
     44c:      	ldp	x29, x30, [sp, #0x60]
     450:      	ldp	x20, x19, [sp, #0x50]
     454:      	ldp	x22, x21, [sp, #0x40]
     458:      	ldp	x24, x23, [sp, #0x30]
     45c:      	ldp	x26, x25, [sp, #0x20]
     460:      	ldp	d9, d8, [sp, #0x10]
     464:      	ldp	d11, d10, [sp], #0x70
     468:      	ret

000000000000046c <_llm_rows.packet_batch.blocks>:
     46c:      	stp	d15, d14, [sp, #-0xa0]!
     470:      	stp	d13, d12, [sp, #0x10]
     474:      	stp	d11, d10, [sp, #0x20]
     478:      	stp	d9, d8, [sp, #0x30]
     47c:      	stp	x28, x27, [sp, #0x40]
     480:      	stp	x26, x25, [sp, #0x50]
     484:      	stp	x24, x23, [sp, #0x60]
     488:      	stp	x22, x21, [sp, #0x70]
     48c:      	stp	x20, x19, [sp, #0x80]
     490:      	stp	x29, x30, [sp, #0x90]
     494:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
     498:      	sub	sp, sp, #0x210
     49c:      	str	x0, [sp, #0xc8]
     4a0:      	cbz	w3, 0x10fc <_llm_rows.packet_batch.blocks+0xc90>
     4a4:      	mov	x19, x3
     4a8:      	mov	x20, x2
     4ac:      	mov	w22, #0x0               ; =0
     4b0:      	ldp	w9, w8, [x2, #0x2c]
     4b4:      	stp	w8, w9, [sp, #0xc0]
     4b8:      	add	x27, sp, #0x1, lsl #12  ; =0x1000
     4bc:      	add	x27, x27, #0x9f0
     4c0:      	ldp	w26, w23, [x2]
     4c4:      	adrp	x8, 0x0 <ltmp0>
     4c8:      	ldr	q0, [x8]
     4cc:      	str	q0, [sp, #0x30]
     4d0:      	adrp	x8, 0x0 <ltmp0>
     4d4:      	ldr	q0, [x8]
     4d8:      	str	q0, [sp, #0x20]
     4dc:      	adrp	x8, 0x0 <ltmp0>
     4e0:      	ldr	q0, [x8]
     4e4:      	str	q0, [sp, #0x10]
     4e8:      	add	x28, sp, #0x1d0
     4ec:      	mvni.4s	v0, #0x7f, msl #16
     4f0:      	fneg.4s	v1, v0
     4f4:      	mvni.4s	v0, #0x3f, msl #16
     4f8:      	fneg.4s	v0, v0
     4fc:      	stp	q0, q1, [sp, #0xd0]
     500:      	ldp	w21, w24, [x2, #0x8]
     504:      	mov	w30, #0xaa7a            ; =43642
     508:      	movk	w30, #0x3d2a, lsl #16
     50c:      	str	w3, [sp, #0xbc]
     510:      	b	0x558 <_llm_rows.packet_batch.blocks+0xec>
     514:      	mov	w8, #0x18               ; =24
     518:      	str	w8, [x20, #0x24]
     51c:      	ldr	w19, [sp, #0xbc]
     520:      	add	w8, w26, #0x1
     524:      	ldp	w10, w9, [sp, #0xc0]
     528:      	cmp	w8, w9
     52c:      	cset	w8, eq
     530:      	csinc	w26, wzr, w26, eq
     534:      	cinc	w9, w23, eq
     538:      	cmp	w9, w10
     53c:      	cset	w10, eq
     540:      	ands	w8, w8, w10
     544:      	csel	w23, wzr, w9, ne
     548:      	add	w21, w21, w8
     54c:      	add	w22, w22, #0x1
     550:      	cmp	w22, w19
     554:      	b.eq	0x10fc <_llm_rows.packet_batch.blocks+0xc90>
     558:      	ubfiz	x8, x26, #5, #32
     55c:      	cmp	x8, x24
     560:      	csel	x9, x8, xzr, ls
     564:      	subs	x10, x24, x9
     568:      	cmp	x10, #0x20
     56c:      	mov	w11, #0x20              ; =32
     570:      	csel	x10, x10, x11, lo
     574:      	cmp	x24, x9
     578:      	stp	w26, w23, [x20]
     57c:      	str	w21, [x20, #0x8]
     580:      	str	wzr, [x20, #0x24]
     584:      	ccmp	x8, x24, #0x2, hi
     588:      	csel	x25, x10, xzr, ls
     58c:      	cmp	x25, #0x20
     590:      	b.lo	0x5ec <_llm_rows.packet_batch.blocks+0x180>
     594:      	ldr	x25, [sp, #0xc8]
     598:      	mov	x0, x25
     59c:      	mov	x1, x20
     5a0:      	bl	0x5a0 <_llm_rows.packet_batch.blocks+0x134>
     5a4:      	mov	w8, #0x8                ; =8
     5a8:      	str	w8, [x20, #0x24]
     5ac:      	mov	x0, x25
     5b0:      	mov	x1, x20
     5b4:      	bl	0x5b4 <_llm_rows.packet_batch.blocks+0x148>
     5b8:      	mov	w8, #0x10               ; =16
     5bc:      	str	w8, [x20, #0x24]
     5c0:      	mov	x0, x25
     5c4:      	mov	x1, x20
     5c8:      	bl	0x5c8 <_llm_rows.packet_batch.blocks+0x15c>
     5cc:      	mov	w8, #0x18               ; =24
     5d0:      	str	w8, [x20, #0x24]
     5d4:      	mov	x0, x25
     5d8:      	mov	x1, x20
     5dc:      	bl	0x5dc <_llm_rows.packet_batch.blocks+0x170>
     5e0:      	mov	w30, #0xaa7a            ; =43642
     5e4:      	movk	w30, #0x3d2a, lsl #16
     5e8:      	b	0x520 <_llm_rows.packet_batch.blocks+0xb4>
     5ec:      	lsr	x19, x25, #3
     5f0:      	cmp	x25, #0x8
     5f4:      	b.lo	0x658 <_llm_rows.packet_batch.blocks+0x1ec>
     5f8:      	str	wzr, [x20, #0x24]
     5fc:      	ldr	x0, [sp, #0xc8]
     600:      	mov	x1, x20
     604:      	bl	0x604 <_llm_rows.packet_batch.blocks+0x198>
     608:      	mov	w30, #0xaa7a            ; =43642
     60c:      	movk	w30, #0x3d2a, lsl #16
     610:      	cmp	x19, #0x1
     614:      	b.eq	0x658 <_llm_rows.packet_batch.blocks+0x1ec>
     618:      	mov	w8, #0x8                ; =8
     61c:      	str	w8, [x20, #0x24]
     620:      	ldr	x0, [sp, #0xc8]
     624:      	mov	x1, x20
     628:      	bl	0x628 <_llm_rows.packet_batch.blocks+0x1bc>
     62c:      	mov	w30, #0xaa7a            ; =43642
     630:      	movk	w30, #0x3d2a, lsl #16
     634:      	cmp	x19, #0x2
     638:      	b.eq	0x658 <_llm_rows.packet_batch.blocks+0x1ec>
     63c:      	mov	w8, #0x10               ; =16
     640:      	str	w8, [x20, #0x24]
     644:      	ldr	x0, [sp, #0xc8]
     648:      	mov	x1, x20
     64c:      	bl	0x64c <_llm_rows.packet_batch.blocks+0x1e0>
     650:      	mov	w30, #0xaa7a            ; =43642
     654:      	movk	w30, #0x3d2a, lsl #16
     658:      	and	w8, w25, #0x7
     65c:      	mov	w25, #0xaaab            ; =43691
     660:      	movk	w25, #0x3e2a, lsl #16
     664:      	cbz	w8, 0x514 <_llm_rows.packet_batch.blocks+0xa8>
     668:      	dup.4s	v1, w8
     66c:      	ldp	q0, q2, [sp, #0x20]
     670:      	cmhi.4s	v0, v1, v0
     674:      	cmhi.4s	v1, v1, v2
     678:      	uzp1.8h	v3, v1, v0
     67c:      	umaxv.8h	h2, v3
     680:      	fmov	w8, s2
     684:      	tbz	w8, #0x0, 0x514 <_llm_rows.packet_batch.blocks+0xa8>
     688:      	mov	x9, #0x0                ; =0
     68c:      	ldr	x11, [sp, #0xc8]
     690:      	ldr	x12, [x11]
     694:      	ldr	x10, [x11, #0x10]
     698:      	ubfiz	w8, w26, #2, #27
     69c:      	orr	w8, w8, w19
     6a0:      	dup.4s	v2, w8
     6a4:      	ldr	x8, [x11, #0x30]
     6a8:      	and.16b	v4, v1, v2
     6ac:      	and.16b	v2, v0, v2
     6b0:      	ushll2.2d	v20, v2, #0x0
     6b4:      	ushll2.2d	v18, v4, #0x0
     6b8:      	ushll.2d	v19, v2, #0x0
     6bc:      	ushll.2d	v4, v4, #0x0
     6c0:      	fmov	x11, d4
     6c4:      	mov	w13, #0x1808            ; =6152
     6c8:      	umaddl	x11, w11, w13, x12
     6cc:      	ldr	q2, [sp, #0x10]
     6d0:      	and.16b	v2, v3, v2
     6d4:      	addv.8h	h2, v2
     6d8:      	fmov	w13, s2
     6dc:      	b	0x700 <_llm_rows.packet_batch.blocks+0x294>
     6e0:      	add	x14, x27, x9, lsl #5
     6e4:      	ldp	q7, q16, [x14]
     6e8:      	bif.16b	v6, v16, v0
     6ec:      	bif.16b	v5, v7, v1
     6f0:      	stp	q5, q6, [x14]
     6f4:      	add	x9, x9, #0x1
     6f8:      	cmp	x9, #0xc0
     6fc:      	b.eq	0x794 <_llm_rows.packet_batch.blocks+0x328>
     700:      	add	x14, x11, x9, lsl #5
     704:      	movi.2d	v5, #0000000000000000
     708:      	movi.2d	v6, #0000000000000000
     70c:      	tbnz	w13, #0x0, 0x734 <_llm_rows.packet_batch.blocks+0x2c8>
     710:      	and	w15, w13, #0xff
     714:      	tbnz	w15, #0x1, 0x740 <_llm_rows.packet_batch.blocks+0x2d4>
     718:      	tbnz	w15, #0x2, 0x74c <_llm_rows.packet_batch.blocks+0x2e0>
     71c:      	tbnz	w15, #0x3, 0x758 <_llm_rows.packet_batch.blocks+0x2ec>
     720:      	tbnz	w15, #0x4, 0x764 <_llm_rows.packet_batch.blocks+0x2f8>
     724:      	tbnz	w15, #0x5, 0x770 <_llm_rows.packet_batch.blocks+0x304>
     728:      	tbnz	w15, #0x6, 0x77c <_llm_rows.packet_batch.blocks+0x310>
     72c:      	tbz	w15, #0x7, 0x6e0 <_llm_rows.packet_batch.blocks+0x274>
     730:      	b	0x788 <_llm_rows.packet_batch.blocks+0x31c>
     734:      	ldr	s5, [x14]
     738:      	and	w15, w13, #0xff
     73c:      	tbz	w15, #0x1, 0x718 <_llm_rows.packet_batch.blocks+0x2ac>
     740:      	add	x16, x14, #0x4
     744:      	ld1.s	{ v5 }[1], [x16]
     748:      	tbz	w15, #0x2, 0x71c <_llm_rows.packet_batch.blocks+0x2b0>
     74c:      	add	x16, x14, #0x8
     750:      	ld1.s	{ v5 }[2], [x16]
     754:      	tbz	w15, #0x3, 0x720 <_llm_rows.packet_batch.blocks+0x2b4>
     758:      	add	x16, x14, #0xc
     75c:      	ld1.s	{ v5 }[3], [x16]
     760:      	tbz	w15, #0x4, 0x724 <_llm_rows.packet_batch.blocks+0x2b8>
     764:      	add	x16, x14, #0x10
     768:      	ld1.s	{ v6 }[0], [x16]
     76c:      	tbz	w15, #0x5, 0x728 <_llm_rows.packet_batch.blocks+0x2bc>
     770:      	add	x16, x14, #0x14
     774:      	ld1.s	{ v6 }[1], [x16]
     778:      	tbz	w15, #0x6, 0x72c <_llm_rows.packet_batch.blocks+0x2c0>
     77c:      	add	x16, x14, #0x18
     780:      	ld1.s	{ v6 }[2], [x16]
     784:      	tbz	w15, #0x7, 0x6e0 <_llm_rows.packet_batch.blocks+0x274>
     788:      	add	x14, x14, #0x1c
     78c:      	ld1.s	{ v6 }[3], [x14]
     790:      	b	0x6e0 <_llm_rows.packet_batch.blocks+0x274>
     794:      	xtn.8b	v5, v3
     798:      	sshll.2d	v6, v1, #0x0
     79c:      	movi	d3, #0x0000000000ffff
     7a0:      	and.8b	v3, v5, v3
     7a4:      	adrp	x9, 0x0 <ltmp0>
     7a8:      	ldr	d7, [x9]
     7ac:      	and.8b	v5, v5, v7
     7b0:      	addv.8b	b5, v5
     7b4:      	fmov	w13, s5
     7b8:      	umaxv.8b	b5, v3
     7bc:      	fmov	w9, s5
     7c0:      	rbit	w11, w13
     7c4:      	clz	w11, w11
     7c8:      	tst	w9, #0x1
     7cc:      	csel	w9, w11, wzr, ne
     7d0:      	adrp	x11, 0x0 <ltmp0>
     7d4:      	ldr	q5, [x11]
     7d8:      	mov	w11, #0x600             ; =1536
     7dc:      	dup.2d	v17, x11
     7e0:      	bif.16b	v5, v17, v6
     7e4:      	mov	w11, #0x602             ; =1538
     7e8:      	dup.2s	v21, w11
     7ec:      	xtn.2s	v22, v4
     7f0:      	mov	b4, v3[0]
     7f4:      	mov.b	v4[4], v3[1]
     7f8:      	umlal.2d	v5, v22, v21
     7fc:      	ushll.2d	v4, v4, #0x0
     800:      	shl.2d	v4, v4, #0x3f
     804:      	cmlt.2d	v4, v4, #0
     808:      	str	q5, [sp, #0x90]
     80c:      	and.16b	v4, v4, v5
     810:      	movi.2d	v5, #0000000000000000
     814:      	stp	q5, q5, [sp, #0x1a0]
     818:      	stp	q4, q5, [sp, #0x180]
     81c:      	and	x11, x9, #0x7
     820:      	add	x14, sp, #0x180
     824:      	ldr	x11, [x14, x11, lsl #3]
     828:      	sub	x11, x11, x9
     82c:      	lsl	x11, x11, #2
     830:      	add	x12, x12, x11
     834:      	movi.2d	v4, #0000000000000000
     838:      	tbz	w13, #0x0, 0x840 <_llm_rows.packet_batch.blocks+0x3d4>
     83c:      	ldr	s5, [x12]
     840:      	mov	w1, #-0x3d300000        ; =-1026555904
     844:      	mov	w2, #0x42c80000         ; =1120403456
     848:      	mov	w3, #0xaa3b             ; =43579
     84c:      	movk	w3, #0x3fb8, lsl #16
     850:      	mov	w4, #0x7200             ; =29184
     854:      	movk	w4, #0xbf31, lsl #16
     858:      	mov	w5, #0xbe8e             ; =48782
     85c:      	movk	w5, #0xb5bf, lsl #16
     860:      	mov	w6, #0x2bda             ; =11226
     864:      	movk	w6, #0x3950, lsl #16
     868:      	mov	w7, #0x96c9             ; =38601
     86c:      	movk	w7, #0x3ab6, lsl #16
     870:      	mov	w19, #0x88a6            ; =34982
     874:      	movk	w19, #0x3c08, lsl #16
     878:      	tbnz	w13, #0x1, 0x1008 <_llm_rows.packet_batch.blocks+0xb9c>
     87c:      	tbnz	w13, #0x2, 0x1014 <_llm_rows.packet_batch.blocks+0xba8>
     880:      	tbnz	w13, #0x3, 0x1020 <_llm_rows.packet_batch.blocks+0xbb4>
     884:      	tbnz	w13, #0x4, 0x102c <_llm_rows.packet_batch.blocks+0xbc0>
     888:      	tbnz	w13, #0x5, 0x1038 <_llm_rows.packet_batch.blocks+0xbcc>
     88c:      	tbnz	w13, #0x6, 0x1044 <_llm_rows.packet_batch.blocks+0xbd8>
     890:      	tbz	w13, #0x7, 0x89c <_llm_rows.packet_batch.blocks+0x430>
     894:      	add	x12, x12, #0x1c
     898:      	ld1.s	{ v4 }[3], [x12]
     89c:      	mov	x15, #0x0               ; =0
     8a0:      	sshll2.2d	v7, v0, #0x0
     8a4:      	sshll2.2d	v16, v1, #0x0
     8a8:      	sshll.2d	v23, v0, #0x0
     8ac:      	adrp	x12, 0x0 <ltmp0>
     8b0:      	ldr	q24, [x12]
     8b4:      	mov.16b	v6, v23
     8b8:      	bsl.16b	v6, v24, v17
     8bc:      	adrp	x12, 0x0 <ltmp0>
     8c0:      	ldr	q23, [x12]
     8c4:      	mov.16b	v26, v16
     8c8:      	bsl.16b	v26, v23, v17
     8cc:      	adrp	x12, 0x0 <ltmp0>
     8d0:      	ldr	q23, [x12]
     8d4:      	mov.16b	v27, v7
     8d8:      	bsl.16b	v27, v23, v17
     8dc:      	adrp	x12, 0x0 <ltmp0>
     8e0:      	ldr	q17, [x12]
     8e4:      	mov	w12, #0x1800            ; =6144
     8e8:      	dup.2d	v23, x12
     8ec:      	sshll.2d	v24, v1, #0x0
     8f0:      	bif.16b	v17, v23, v24
     8f4:      	adrp	x12, 0x0 <ltmp0>
     8f8:      	ldr	q24, [x12]
     8fc:      	sshll.2d	v25, v0, #0x0
     900:      	bif.16b	v24, v23, v25
     904:      	adrp	x12, 0x0 <ltmp0>
     908:      	ldr	q25, [x12]
     90c:      	bsl.16b	v16, v25, v23
     910:      	adrp	x12, 0x0 <ltmp0>
     914:      	ldr	q25, [x12]
     918:      	bsl.16b	v7, v25, v23
     91c:      	xtn.2s	v20, v20
     920:      	umlal.2d	v27, v20, v21
     924:      	umull.2d	v20, v22, v21
     928:      	xtn.2s	v18, v18
     92c:      	xtn.2s	v19, v19
     930:      	umlal.2d	v26, v18, v21
     934:      	stp	q27, q26, [sp, #0x50]
     938:      	stp	q24, q7, [sp, #0x160]
     93c:      	stp	q17, q16, [sp, #0x140]
     940:      	and	x12, x9, #0x7
     944:      	add	x14, sp, #0x140
     948:      	ldr	x12, [x14, x12, lsl #3]
     94c:      	umlal.2d	v6, v19, v21
     950:      	stp	q6, q5, [sp, #0x70]
     954:      	sub	x12, x12, x9, lsl #2
     958:      	tst	w13, #0xff
     95c:      	csel	x12, xzr, x12, eq
     960:      	add	x13, x27, x12
     964:      	ldp	q7, q16, [x13]
     968:      	zip2.8b	v17, v3, v0
     96c:      	ushll.4s	v17, v17, #0x0
     970:      	shl.4s	v17, v17, #0x1f
     974:      	cmlt.4s	v17, v17, #0
     978:      	bit.16b	v16, v4, v17
     97c:      	zip1.8b	v17, v3, v0
     980:      	ushll.4s	v17, v17, #0x0
     984:      	shl.4s	v17, v17, #0x1f
     988:      	cmlt.4s	v17, v17, #0
     98c:      	bit.16b	v7, v5, v17
     990:      	stp	q7, q16, [x13]
     994:      	fmov	x13, d20
     998:      	lsl	x13, x13, #2
     99c:      	add	x14, x10, x13
     9a0:      	mov	w16, #0x1               ; =1
     9a4:      	dup.2d	v7, x16
     9a8:      	ushll2.2d	v16, v0, #0x0
     9ac:      	and.16b	v18, v16, v7
     9b0:      	ushll2.2d	v16, v1, #0x0
     9b4:      	and.16b	v19, v16, v7
     9b8:      	ushll.2d	v16, v0, #0x0
     9bc:      	and.16b	v20, v16, v7
     9c0:      	ushll.2d	v16, v1, #0x0
     9c4:      	and.16b	v21, v16, v7
     9c8:      	movi.2d	v22, #0000000000000000
     9cc:      	movi.2d	v23, #0000000000000000
     9d0:      	movi.2d	v24, #0000000000000000
     9d4:      	movi.2d	v25, #0000000000000000
     9d8:      	b	0xa0c <_llm_rows.packet_batch.blocks+0x5a0>
     9dc:      	add	x15, x28, x15
     9e0:      	ldp	q7, q16, [x15]
     9e4:      	bit.16b	v16, v27, v0
     9e8:      	bit.16b	v7, v26, v1
     9ec:      	stp	q7, q16, [x15]
     9f0:      	add.2d	v23, v23, v19
     9f4:      	add.2d	v24, v24, v20
     9f8:      	add.2d	v25, v25, v18
     9fc:      	add.2d	v22, v22, v21
     a00:      	fmov	x15, d22
     a04:      	cmp	x15, #0xc0
     a08:      	b.ge	0xaa8 <_llm_rows.packet_batch.blocks+0x63c>
     a0c:      	fmov	w17, s2
     a10:      	lsl	x15, x15, #5
     a14:      	add	x16, x14, x15
     a18:      	movi.2d	v26, #0000000000000000
     a1c:      	movi.2d	v27, #0000000000000000
     a20:      	tbnz	w17, #0x0, 0xa48 <_llm_rows.packet_batch.blocks+0x5dc>
     a24:      	and	w17, w17, #0xff
     a28:      	tbnz	w17, #0x1, 0xa54 <_llm_rows.packet_batch.blocks+0x5e8>
     a2c:      	tbnz	w17, #0x2, 0xa60 <_llm_rows.packet_batch.blocks+0x5f4>
     a30:      	tbnz	w17, #0x3, 0xa6c <_llm_rows.packet_batch.blocks+0x600>
     a34:      	tbnz	w17, #0x4, 0xa78 <_llm_rows.packet_batch.blocks+0x60c>
     a38:      	tbnz	w17, #0x5, 0xa84 <_llm_rows.packet_batch.blocks+0x618>
     a3c:      	tbnz	w17, #0x6, 0xa90 <_llm_rows.packet_batch.blocks+0x624>
     a40:      	tbz	w17, #0x7, 0x9dc <_llm_rows.packet_batch.blocks+0x570>
     a44:      	b	0xa9c <_llm_rows.packet_batch.blocks+0x630>
     a48:      	ldr	s26, [x16]
     a4c:      	and	w17, w17, #0xff
     a50:      	tbz	w17, #0x1, 0xa2c <_llm_rows.packet_batch.blocks+0x5c0>
     a54:      	add	x0, x16, #0x4
     a58:      	ld1.s	{ v26 }[1], [x0]
     a5c:      	tbz	w17, #0x2, 0xa30 <_llm_rows.packet_batch.blocks+0x5c4>
     a60:      	add	x0, x16, #0x8
     a64:      	ld1.s	{ v26 }[2], [x0]
     a68:      	tbz	w17, #0x3, 0xa34 <_llm_rows.packet_batch.blocks+0x5c8>
     a6c:      	add	x0, x16, #0xc
     a70:      	ld1.s	{ v26 }[3], [x0]
     a74:      	tbz	w17, #0x4, 0xa38 <_llm_rows.packet_batch.blocks+0x5cc>
     a78:      	add	x0, x16, #0x10
     a7c:      	ld1.s	{ v27 }[0], [x0]
     a80:      	tbz	w17, #0x5, 0xa3c <_llm_rows.packet_batch.blocks+0x5d0>
     a84:      	add	x0, x16, #0x14
     a88:      	ld1.s	{ v27 }[1], [x0]
     a8c:      	tbz	w17, #0x6, 0xa40 <_llm_rows.packet_batch.blocks+0x5d4>
     a90:      	add	x0, x16, #0x18
     a94:      	ld1.s	{ v27 }[2], [x0]
     a98:      	tbz	w17, #0x7, 0x9dc <_llm_rows.packet_batch.blocks+0x570>
     a9c:      	add	x16, x16, #0x1c
     aa0:      	ld1.s	{ v27 }[3], [x16]
     aa4:      	b	0x9dc <_llm_rows.packet_batch.blocks+0x570>
     aa8:      	add	x10, x10, x11
     aac:      	adrp	x11, 0x0 <ltmp0>
     ab0:      	ldr	d7, [x11]
     ab4:      	shl.8b	v16, v3, #0x7
     ab8:      	cmlt.8b	v16, v16, #0
     abc:      	and.8b	v7, v16, v7
     ac0:      	addv.8b	b5, v7
     ac4:      	str	d5, [sp, #0x48]
     ac8:      	fmov	w11, s5
     acc:      	movi.2d	v23, #0000000000000000
     ad0:      	movi.2d	v22, #0000000000000000
     ad4:      	tbnz	w11, #0x0, 0x1054 <_llm_rows.packet_batch.blocks+0xbe8>
     ad8:      	tbnz	w11, #0x1, 0x105c <_llm_rows.packet_batch.blocks+0xbf0>
     adc:      	tbnz	w11, #0x2, 0x1068 <_llm_rows.packet_batch.blocks+0xbfc>
     ae0:      	tbnz	w11, #0x3, 0x1074 <_llm_rows.packet_batch.blocks+0xc08>
     ae4:      	tbnz	w11, #0x4, 0x1080 <_llm_rows.packet_batch.blocks+0xc14>
     ae8:      	tbnz	w11, #0x5, 0x108c <_llm_rows.packet_batch.blocks+0xc20>
     aec:      	tbnz	w11, #0x6, 0x1098 <_llm_rows.packet_batch.blocks+0xc2c>
     af0:      	tbz	w11, #0x7, 0xafc <_llm_rows.packet_batch.blocks+0x690>
     af4:      	add	x10, x10, #0x1c
     af8:      	ld1.s	{ v22 }[3], [x10]
     afc:      	str	q4, [sp, #0xa0]
     b00:      	mov	x11, #0x0               ; =0
     b04:      	add	x10, x28, x12
     b08:      	ldp	q7, q16, [x10]
     b0c:      	zip2.8b	v17, v3, v0
     b10:      	ushll.4s	v17, v17, #0x0
     b14:      	shl.4s	v17, v17, #0x1f
     b18:      	cmlt.4s	v17, v17, #0
     b1c:      	bit.16b	v16, v22, v17
     b20:      	zip1.8b	v17, v3, v0
     b24:      	ushll.4s	v17, v17, #0x0
     b28:      	shl.4s	v17, v17, #0x1f
     b2c:      	cmlt.4s	v17, v17, #0
     b30:      	bit.16b	v7, v23, v17
     b34:      	stp	q7, q16, [x10]
     b38:      	add	x10, x8, x13
     b3c:      	movi.2d	v13, #0000000000000000
     b40:      	movi.2d	v14, #0000000000000000
     b44:      	movi.2d	v15, #0000000000000000
     b48:      	movi.2d	v8, #0000000000000000
     b4c:      	b	0xb6c <_llm_rows.packet_batch.blocks+0x700>
     b50:      	add.2d	v14, v14, v19
     b54:      	add.2d	v15, v15, v20
     b58:      	add.2d	v8, v8, v18
     b5c:      	add.2d	v13, v13, v21
     b60:      	fmov	x11, d13
     b64:      	cmp	x11, #0xc0
     b68:      	b.ge	0xdec <_llm_rows.packet_batch.blocks+0x980>
     b6c:      	fmov	w12, s2
     b70:      	lsl	x11, x11, #5
     b74:      	add	x13, x27, x11
     b78:      	ldp	q16, q7, [x13]
     b7c:      	and.16b	v16, v1, v16
     b80:      	fneg.4s	v17, v16
     b84:      	and.16b	v17, v1, v17
     b88:      	dup.4s	v25, w1
     b8c:      	fcmge.4s	v27, v17, v25
     b90:      	dup.4s	v26, w2
     b94:      	fcmge.4s	v28, v26, v17
     b98:      	and.16b	v27, v27, v28
     b9c:      	and.16b	v27, v27, v17
     ba0:      	dup.4s	v28, w3
     ba4:      	fmul.4s	v29, v27, v28
     ba8:      	movi.4s	v4, #0x4b, lsl #24
     bac:      	mvni.4s	v5, #0x80, lsl #24
     bb0:      	mov.16b	v30, v5
     bb4:      	bsl.16b	v30, v4, v29
     bb8:      	fadd.4s	v29, v29, v30
     bbc:      	fsub.4s	v29, v29, v30
     bc0:      	fcvtzs.4s	v5, v29
     bc4:      	dup.4s	v29, w4
     bc8:      	scvtf.4s	v31, v5
     bcc:      	fmul.4s	v30, v31, v29
     bd0:      	fadd.4s	v27, v27, v30
     bd4:      	dup.4s	v30, w5
     bd8:      	fmul.4s	v31, v31, v30
     bdc:      	fadd.4s	v27, v27, v31
     be0:      	dup.4s	v31, w6
     be4:      	fmul.4s	v10, v27, v31
     be8:      	dup.4s	v9, w7
     bec:      	fadd.4s	v10, v10, v9
     bf0:      	fmul.4s	v11, v27, v10
     bf4:      	dup.4s	v10, w19
     bf8:      	fadd.4s	v11, v11, v10
     bfc:      	fmul.4s	v12, v27, v11
     c00:      	dup.4s	v11, w30
     c04:      	fadd.4s	v12, v12, v11
     c08:      	fmul.4s	v24, v27, v12
     c0c:      	dup.4s	v12, w25
     c10:      	fadd.4s	v24, v24, v12
     c14:      	fmul.4s	v24, v27, v24
     c18:      	movi.4s	v4, #0x3f, lsl #24
     c1c:      	fadd.4s	v24, v24, v4
     c20:      	fmul.4s	v6, v27, v27
     c24:      	fmul.4s	v6, v6, v24
     c28:      	fadd.4s	v6, v27, v6
     c2c:      	fmov.4s	v27, #1.00000000
     c30:      	fadd.4s	v6, v6, v27
     c34:      	sshr.4s	v24, v5, #0x1
     c38:      	shl.4s	v4, v24, #0x17
     c3c:      	add.4s	v4, v4, v27
     c40:      	fmul.4s	v4, v6, v4
     c44:      	sub.4s	v5, v5, v24
     c48:      	shl.4s	v5, v5, #0x17
     c4c:      	add.4s	v5, v5, v27
     c50:      	fmul.4s	v4, v4, v5
     c54:      	fcmgt.4s	v5, v25, v17
     c58:      	fcmgt.4s	v6, v17, v26
     c5c:      	fcmeq.4s	v17, v17, v17
     c60:      	fadd.4s	v4, v4, v27
     c64:      	bit.16b	v4, v27, v5
     c68:      	ldr	q5, [sp, #0xe0]
     c6c:      	bit.16b	v4, v5, v6
     c70:      	ldr	q5, [sp, #0xd0]
     c74:      	bif.16b	v4, v5, v17
     c78:      	fdiv.4s	v4, v16, v4
     c7c:      	add	x13, x28, x11
     c80:      	ldp	q5, q16, [x13]
     c84:      	and.16b	v5, v1, v5
     c88:      	fmul.4s	v17, v5, v4
     c8c:      	add	x11, x10, x11
     c90:      	tbnz	w12, #0x0, 0xd98 <_llm_rows.packet_batch.blocks+0x92c>
     c94:      	and	w12, w12, #0xff
     c98:      	tbnz	w12, #0x1, 0xda4 <_llm_rows.packet_batch.blocks+0x938>
     c9c:      	tbnz	w12, #0x2, 0xdb0 <_llm_rows.packet_batch.blocks+0x944>
     ca0:      	tbz	w12, #0x3, 0xcac <_llm_rows.packet_batch.blocks+0x840>
     ca4:      	add	x13, x11, #0xc
     ca8:      	st1.s	{ v17 }[3], [x13]
     cac:      	and.16b	v4, v0, v7
     cb0:      	fneg.4s	v5, v4
     cb4:      	and.16b	v5, v0, v5
     cb8:      	fcmge.4s	v6, v5, v25
     cbc:      	fcmge.4s	v7, v26, v5
     cc0:      	and.16b	v6, v6, v7
     cc4:      	and.16b	v6, v6, v5
     cc8:      	fmul.4s	v7, v6, v28
     ccc:      	movi.4s	v17, #0x4b, lsl #24
     cd0:      	mvni.4s	v24, #0x80, lsl #24
     cd4:      	bif.16b	v17, v7, v24
     cd8:      	fadd.4s	v7, v7, v17
     cdc:      	fsub.4s	v7, v7, v17
     ce0:      	fcvtzs.4s	v7, v7
     ce4:      	scvtf.4s	v17, v7
     ce8:      	fmul.4s	v24, v17, v29
     cec:      	fadd.4s	v6, v6, v24
     cf0:      	fmul.4s	v17, v17, v30
     cf4:      	fadd.4s	v6, v6, v17
     cf8:      	fmul.4s	v17, v6, v31
     cfc:      	fadd.4s	v17, v17, v9
     d00:      	fmul.4s	v17, v6, v17
     d04:      	fadd.4s	v17, v17, v10
     d08:      	fmul.4s	v17, v6, v17
     d0c:      	fadd.4s	v17, v17, v11
     d10:      	fmul.4s	v17, v6, v17
     d14:      	fadd.4s	v17, v17, v12
     d18:      	fmul.4s	v17, v6, v17
     d1c:      	movi.4s	v24, #0x3f, lsl #24
     d20:      	fadd.4s	v17, v17, v24
     d24:      	fmul.4s	v24, v6, v6
     d28:      	fmul.4s	v17, v24, v17
     d2c:      	fadd.4s	v6, v6, v17
     d30:      	fadd.4s	v6, v6, v27
     d34:      	sshr.4s	v17, v7, #0x1
     d38:      	shl.4s	v24, v17, #0x17
     d3c:      	add.4s	v24, v24, v27
     d40:      	fmul.4s	v6, v6, v24
     d44:      	sub.4s	v7, v7, v17
     d48:      	shl.4s	v7, v7, #0x17
     d4c:      	add.4s	v7, v7, v27
     d50:      	fmul.4s	v6, v6, v7
     d54:      	fcmgt.4s	v7, v25, v5
     d58:      	fcmgt.4s	v17, v5, v26
     d5c:      	fcmeq.4s	v5, v5, v5
     d60:      	fadd.4s	v6, v6, v27
     d64:      	bit.16b	v6, v27, v7
     d68:      	ldr	q7, [sp, #0xe0]
     d6c:      	bit.16b	v6, v7, v17
     d70:      	ldr	q7, [sp, #0xd0]
     d74:      	bsl.16b	v5, v6, v7
     d78:      	fdiv.4s	v4, v4, v5
     d7c:      	and.16b	v5, v0, v16
     d80:      	fmul.4s	v7, v5, v4
     d84:      	tbnz	w12, #0x4, 0xdc0 <_llm_rows.packet_batch.blocks+0x954>
     d88:      	tbnz	w12, #0x5, 0xdc8 <_llm_rows.packet_batch.blocks+0x95c>
     d8c:      	tbnz	w12, #0x6, 0xdd4 <_llm_rows.packet_batch.blocks+0x968>
     d90:      	tbz	w12, #0x7, 0xb50 <_llm_rows.packet_batch.blocks+0x6e4>
     d94:      	b	0xde0 <_llm_rows.packet_batch.blocks+0x974>
     d98:      	str	s17, [x11]
     d9c:      	and	w12, w12, #0xff
     da0:      	tbz	w12, #0x1, 0xc9c <_llm_rows.packet_batch.blocks+0x830>
     da4:      	add	x13, x11, #0x4
     da8:      	st1.s	{ v17 }[1], [x13]
     dac:      	tbz	w12, #0x2, 0xca0 <_llm_rows.packet_batch.blocks+0x834>
     db0:      	add	x13, x11, #0x8
     db4:      	st1.s	{ v17 }[2], [x13]
     db8:      	tbnz	w12, #0x3, 0xca4 <_llm_rows.packet_batch.blocks+0x838>
     dbc:      	b	0xcac <_llm_rows.packet_batch.blocks+0x840>
     dc0:      	str	s7, [x11, #0x10]
     dc4:      	tbz	w12, #0x5, 0xd8c <_llm_rows.packet_batch.blocks+0x920>
     dc8:      	add	x13, x11, #0x14
     dcc:      	st1.s	{ v7 }[1], [x13]
     dd0:      	tbz	w12, #0x6, 0xd90 <_llm_rows.packet_batch.blocks+0x924>
     dd4:      	add	x13, x11, #0x18
     dd8:      	st1.s	{ v7 }[2], [x13]
     ddc:      	tbz	w12, #0x7, 0xb50 <_llm_rows.packet_batch.blocks+0x6e4>
     de0:      	add	x11, x11, #0x1c
     de4:      	st1.s	{ v7 }[3], [x11]
     de8:      	b	0xb50 <_llm_rows.packet_batch.blocks+0x6e4>
     dec:      	ldr	q6, [sp, #0x80]
     df0:      	fneg.4s	v0, v6
     df4:      	ldr	d1, [sp, #0x48]
     df8:      	fmov	w10, s1
     dfc:      	zip1.8b	v1, v3, v0
     e00:      	ushll.4s	v1, v1, #0x0
     e04:      	shl.4s	v1, v1, #0x1f
     e08:      	cmlt.4s	v1, v1, #0
     e0c:      	and.16b	v0, v1, v0
     e10:      	fcmge.4s	v1, v0, v25
     e14:      	fcmge.4s	v2, v26, v0
     e18:      	and.16b	v1, v1, v2
     e1c:      	and.16b	v1, v1, v0
     e20:      	fmul.4s	v2, v1, v28
     e24:      	movi.4s	v4, #0x4b, lsl #24
     e28:      	mvni.4s	v5, #0x80, lsl #24
     e2c:      	bif.16b	v4, v2, v5
     e30:      	fadd.4s	v2, v2, v4
     e34:      	fsub.4s	v2, v2, v4
     e38:      	fcvtzs.4s	v2, v2
     e3c:      	scvtf.4s	v4, v2
     e40:      	fmul.4s	v5, v4, v29
     e44:      	fadd.4s	v1, v1, v5
     e48:      	fmul.4s	v4, v4, v30
     e4c:      	fadd.4s	v1, v1, v4
     e50:      	fmul.4s	v4, v1, v31
     e54:      	fadd.4s	v4, v4, v9
     e58:      	fmul.4s	v4, v1, v4
     e5c:      	fadd.4s	v4, v4, v10
     e60:      	fmul.4s	v4, v1, v4
     e64:      	fadd.4s	v4, v4, v11
     e68:      	fmul.4s	v4, v1, v4
     e6c:      	fadd.4s	v4, v4, v12
     e70:      	fmul.4s	v4, v1, v4
     e74:      	movi.4s	v5, #0x3f, lsl #24
     e78:      	fadd.4s	v4, v4, v5
     e7c:      	fmul.4s	v5, v1, v1
     e80:      	fmul.4s	v4, v5, v4
     e84:      	fadd.4s	v1, v1, v4
     e88:      	fadd.4s	v1, v1, v27
     e8c:      	sshr.4s	v4, v2, #0x1
     e90:      	shl.4s	v5, v4, #0x17
     e94:      	add.4s	v5, v5, v27
     e98:      	fmul.4s	v1, v1, v5
     e9c:      	sub.4s	v2, v2, v4
     ea0:      	shl.4s	v2, v2, #0x17
     ea4:      	add.4s	v2, v2, v27
     ea8:      	fmul.4s	v1, v1, v2
     eac:      	fcmgt.4s	v2, v25, v0
     eb0:      	fcmgt.4s	v4, v0, v26
     eb4:      	fcmeq.4s	v0, v0, v0
     eb8:      	fadd.4s	v1, v1, v27
     ebc:      	bit.16b	v1, v27, v2
     ec0:      	ldp	q2, q5, [sp, #0xd0]
     ec4:      	bit.16b	v1, v5, v4
     ec8:      	bsl.16b	v0, v1, v2
     ecc:      	fdiv.4s	v0, v6, v0
     ed0:      	fmul.4s	v0, v0, v23
     ed4:      	ldr	q2, [sp, #0x90]
     ed8:      	ldp	q4, q5, [sp, #0x60]
     edc:      	stp	q2, q4, [sp, #0xf0]
     ee0:      	ldr	q1, [sp, #0x50]
     ee4:      	stp	q5, q1, [sp, #0x110]
     ee8:      	and	x11, x9, #0x7
     eec:      	add	x12, sp, #0xf0
     ef0:      	ldr	x11, [x12, x11, lsl #3]
     ef4:      	sub	x9, x11, x9
     ef8:      	add	x8, x8, x9, lsl #2
     efc:      	tbnz	w10, #0x0, 0x10a8 <_llm_rows.packet_batch.blocks+0xc3c>
     f00:      	ldr	q5, [sp, #0xa0]
     f04:      	tbnz	w10, #0x1, 0x10b4 <_llm_rows.packet_batch.blocks+0xc48>
     f08:      	tbnz	w10, #0x2, 0x10c0 <_llm_rows.packet_batch.blocks+0xc54>
     f0c:      	tbz	w10, #0x3, 0xf18 <_llm_rows.packet_batch.blocks+0xaac>
     f10:      	add	x9, x8, #0xc
     f14:      	st1.s	{ v0 }[3], [x9]
     f18:      	fneg.4s	v0, v5
     f1c:      	zip2.8b	v1, v3, v0
     f20:      	ushll.4s	v1, v1, #0x0
     f24:      	shl.4s	v1, v1, #0x1f
     f28:      	cmlt.4s	v1, v1, #0
     f2c:      	and.16b	v0, v1, v0
     f30:      	fcmge.4s	v1, v0, v25
     f34:      	fcmge.4s	v2, v26, v0
     f38:      	and.16b	v1, v1, v2
     f3c:      	and.16b	v1, v1, v0
     f40:      	fmul.4s	v2, v1, v28
     f44:      	movi.4s	v3, #0x4b, lsl #24
     f48:      	mvni.4s	v4, #0x80, lsl #24
     f4c:      	bif.16b	v3, v2, v4
     f50:      	fadd.4s	v2, v2, v3
     f54:      	fsub.4s	v2, v2, v3
     f58:      	fcvtzs.4s	v2, v2
     f5c:      	scvtf.4s	v3, v2
     f60:      	fmul.4s	v4, v3, v29
     f64:      	fadd.4s	v1, v1, v4
     f68:      	fmul.4s	v3, v3, v30
     f6c:      	fadd.4s	v1, v1, v3
     f70:      	fmul.4s	v3, v1, v31
     f74:      	fadd.4s	v3, v3, v9
     f78:      	fmul.4s	v3, v1, v3
     f7c:      	fadd.4s	v3, v3, v10
     f80:      	fmul.4s	v3, v1, v3
     f84:      	fadd.4s	v3, v3, v11
     f88:      	fmul.4s	v3, v1, v3
     f8c:      	fadd.4s	v3, v3, v12
     f90:      	fmul.4s	v3, v1, v3
     f94:      	movi.4s	v4, #0x3f, lsl #24
     f98:      	fadd.4s	v3, v3, v4
     f9c:      	fmul.4s	v4, v1, v1
     fa0:      	fmul.4s	v3, v4, v3
     fa4:      	fadd.4s	v1, v1, v3
     fa8:      	fadd.4s	v1, v1, v27
     fac:      	sshr.4s	v3, v2, #0x1
     fb0:      	shl.4s	v4, v3, #0x17
     fb4:      	add.4s	v4, v4, v27
     fb8:      	fmul.4s	v1, v1, v4
     fbc:      	sub.4s	v2, v2, v3
     fc0:      	shl.4s	v2, v2, #0x17
     fc4:      	add.4s	v2, v2, v27
     fc8:      	fmul.4s	v1, v1, v2
     fcc:      	fcmgt.4s	v2, v25, v0
     fd0:      	fcmgt.4s	v3, v0, v26
     fd4:      	fcmeq.4s	v0, v0, v0
     fd8:      	fadd.4s	v1, v1, v27
     fdc:      	bit.16b	v1, v27, v2
     fe0:      	ldp	q2, q4, [sp, #0xd0]
     fe4:      	bit.16b	v1, v4, v3
     fe8:      	bsl.16b	v0, v1, v2
     fec:      	fdiv.4s	v0, v5, v0
     ff0:      	fmul.4s	v0, v0, v22
     ff4:      	tbnz	w10, #0x4, 0x10d0 <_llm_rows.packet_batch.blocks+0xc64>
     ff8:      	tbnz	w10, #0x5, 0x10d8 <_llm_rows.packet_batch.blocks+0xc6c>
     ffc:      	tbnz	w10, #0x6, 0x10e4 <_llm_rows.packet_batch.blocks+0xc78>
    1000:      	tbz	w10, #0x7, 0x514 <_llm_rows.packet_batch.blocks+0xa8>
    1004:      	b	0x10f0 <_llm_rows.packet_batch.blocks+0xc84>
    1008:      	add	x14, x12, #0x4
    100c:      	ld1.s	{ v5 }[1], [x14]
    1010:      	tbz	w13, #0x2, 0x880 <_llm_rows.packet_batch.blocks+0x414>
    1014:      	add	x14, x12, #0x8
    1018:      	ld1.s	{ v5 }[2], [x14]
    101c:      	tbz	w13, #0x3, 0x884 <_llm_rows.packet_batch.blocks+0x418>
    1020:      	add	x14, x12, #0xc
    1024:      	ld1.s	{ v5 }[3], [x14]
    1028:      	tbz	w13, #0x4, 0x888 <_llm_rows.packet_batch.blocks+0x41c>
    102c:      	add	x14, x12, #0x10
    1030:      	ld1.s	{ v4 }[0], [x14]
    1034:      	tbz	w13, #0x5, 0x88c <_llm_rows.packet_batch.blocks+0x420>
    1038:      	add	x14, x12, #0x14
    103c:      	ld1.s	{ v4 }[1], [x14]
    1040:      	tbz	w13, #0x6, 0x890 <_llm_rows.packet_batch.blocks+0x424>
    1044:      	add	x14, x12, #0x18
    1048:      	ld1.s	{ v4 }[2], [x14]
    104c:      	tbnz	w13, #0x7, 0x894 <_llm_rows.packet_batch.blocks+0x428>
    1050:      	b	0x89c <_llm_rows.packet_batch.blocks+0x430>
    1054:      	ldr	s23, [x10]
    1058:      	tbz	w11, #0x1, 0xadc <_llm_rows.packet_batch.blocks+0x670>
    105c:      	add	x14, x10, #0x4
    1060:      	ld1.s	{ v23 }[1], [x14]
    1064:      	tbz	w11, #0x2, 0xae0 <_llm_rows.packet_batch.blocks+0x674>
    1068:      	add	x14, x10, #0x8
    106c:      	ld1.s	{ v23 }[2], [x14]
    1070:      	tbz	w11, #0x3, 0xae4 <_llm_rows.packet_batch.blocks+0x678>
    1074:      	add	x14, x10, #0xc
    1078:      	ld1.s	{ v23 }[3], [x14]
    107c:      	tbz	w11, #0x4, 0xae8 <_llm_rows.packet_batch.blocks+0x67c>
    1080:      	add	x14, x10, #0x10
    1084:      	ld1.s	{ v22 }[0], [x14]
    1088:      	tbz	w11, #0x5, 0xaec <_llm_rows.packet_batch.blocks+0x680>
    108c:      	add	x14, x10, #0x14
    1090:      	ld1.s	{ v22 }[1], [x14]
    1094:      	tbz	w11, #0x6, 0xaf0 <_llm_rows.packet_batch.blocks+0x684>
    1098:      	add	x14, x10, #0x18
    109c:      	ld1.s	{ v22 }[2], [x14]
    10a0:      	tbnz	w11, #0x7, 0xaf4 <_llm_rows.packet_batch.blocks+0x688>
    10a4:      	b	0xafc <_llm_rows.packet_batch.blocks+0x690>
    10a8:      	str	s0, [x8]
    10ac:      	ldr	q5, [sp, #0xa0]
    10b0:      	tbz	w10, #0x1, 0xf08 <_llm_rows.packet_batch.blocks+0xa9c>
    10b4:      	add	x9, x8, #0x4
    10b8:      	st1.s	{ v0 }[1], [x9]
    10bc:      	tbz	w10, #0x2, 0xf0c <_llm_rows.packet_batch.blocks+0xaa0>
    10c0:      	add	x9, x8, #0x8
    10c4:      	st1.s	{ v0 }[2], [x9]
    10c8:      	tbnz	w10, #0x3, 0xf10 <_llm_rows.packet_batch.blocks+0xaa4>
    10cc:      	b	0xf18 <_llm_rows.packet_batch.blocks+0xaac>
    10d0:      	str	s0, [x8, #0x10]
    10d4:      	tbz	w10, #0x5, 0xffc <_llm_rows.packet_batch.blocks+0xb90>
    10d8:      	add	x9, x8, #0x14
    10dc:      	st1.s	{ v0 }[1], [x9]
    10e0:      	tbz	w10, #0x6, 0x1000 <_llm_rows.packet_batch.blocks+0xb94>
    10e4:      	add	x9, x8, #0x18
    10e8:      	st1.s	{ v0 }[2], [x9]
    10ec:      	tbz	w10, #0x7, 0x514 <_llm_rows.packet_batch.blocks+0xa8>
    10f0:      	add	x8, x8, #0x1c
    10f4:      	st1.s	{ v0 }[3], [x8]
    10f8:      	b	0x514 <_llm_rows.packet_batch.blocks+0xa8>
    10fc:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    1100:      	add	sp, sp, #0x210
    1104:      	ldp	x29, x30, [sp, #0x90]
    1108:      	ldp	x20, x19, [sp, #0x80]
    110c:      	ldp	x22, x21, [sp, #0x70]
    1110:      	ldp	x24, x23, [sp, #0x60]
    1114:      	ldp	x26, x25, [sp, #0x50]
    1118:      	ldp	x28, x27, [sp, #0x40]
    111c:      	ldp	d9, d8, [sp, #0x30]
    1120:      	ldp	d11, d10, [sp, #0x20]
    1124:      	ldp	d13, d12, [sp, #0x10]
    1128:      	ldp	d15, d14, [sp], #0xa0
    112c:      	ret


/private/tmp/luisa-native-rows.LuX3yX/capture-v3/swiglu-257x1538-l1/object/tile_xir_w8_80771_1788919115094568_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x1864 <ltmp0+0x1864>
       4:      	sub	sp, sp, #0x130
       8:      	stp	d15, d14, [sp, #0x90]
       c:      	stp	d13, d12, [sp, #0xa0]
      10:      	stp	d11, d10, [sp, #0xb0]
      14:      	stp	d9, d8, [sp, #0xc0]
      18:      	stp	x28, x27, [sp, #0xd0]
      1c:      	stp	x26, x25, [sp, #0xe0]
      20:      	stp	x24, x23, [sp, #0xf0]
      24:      	stp	x22, x21, [sp, #0x100]
      28:      	stp	x20, x19, [sp, #0x110]
      2c:      	stp	x29, x30, [sp, #0x120]
      30:      	mov	w8, #0x0                ; =0
      34:      	ldp	w9, w10, [x2, #0x2c]
      38:      	str	w9, [sp, #0xc]
      3c:      	mov	w13, #0x602             ; =1538
      40:      	mov	w14, #0x42d00000        ; =1120927744
      44:      	mov	w15, #-0x3d380000       ; =-1027080192
      48:      	ldp	w7, w19, [x2]
      4c:      	mov	w16, #0xaa3b            ; =43579
      50:      	movk	w16, #0x3fb8, lsl #16
      54:      	movi.4s	v0, #0x4b, lsl #24
      58:      	dup.4s	v1, w13
      5c:      	str	q1, [sp, #0x50]
      60:      	mov	w13, #0x7200            ; =29184
      64:      	movk	w13, #0xbf31, lsl #16
      68:      	adrp	x17, 0x0 <ltmp0>
      6c:      	ldr	q1, [x17]
      70:      	str	q1, [sp, #0x70]
      74:      	mov	w17, #0xbe8e            ; =48782
      78:      	movk	w17, #0xb5bf, lsl #16
      7c:      	dup.4s	v3, w14
      80:      	dup.4s	v4, w15
      84:      	dup.4s	v5, w16
      88:      	dup.4s	v6, w13
      8c:      	dup.4s	v7, w17
      90:      	mvni.4s	v16, #0x80, lsl #24
      94:      	mov	w16, #0x2bda            ; =11226
      98:      	movk	w16, #0x3950, lsl #16
      9c:      	mov	w17, #0x96c9            ; =38601
      a0:      	movk	w17, #0x3ab6, lsl #16
      a4:      	mov	w1, #0x88a6             ; =34982
      a8:      	movk	w1, #0x3c08, lsl #16
      ac:      	mov	w13, #0xaa7a            ; =43642
      b0:      	movk	w13, #0x3d2a, lsl #16
      b4:      	mov	w14, #0xaaab            ; =43691
      b8:      	movk	w14, #0x3e2a, lsl #16
      bc:      	movi.4s	v17, #0x3f, lsl #24
      c0:      	ldp	w20, w15, [x2, #0x8]
      c4:      	mvni.4s	v2, #0x7f, msl #16
      c8:      	dup.4s	v18, w16
      cc:      	dup.4s	v19, w17
      d0:      	fneg.4s	v20, v2
      d4:      	mvni.4s	v2, #0x3f, msl #16
      d8:      	fneg.4s	v21, v2
      dc:      	adrp	x16, 0x0 <ltmp0>
      e0:      	ldr	q1, [x16]
      e4:      	str	q1, [sp, #0x60]
      e8:      	adrp	x16, 0x0 <ltmp0>
      ec:      	dup.4s	v23, w1
      f0:      	mov	w17, #-0x3d300000       ; =-1026555904
      f4:      	mov	w1, #0x42c80000         ; =1120403456
      f8:      	fmov.4s	v26, #1.00000000
      fc:      	b	0x138 <ltmp0+0x138>
     100:      	add	w9, w6, #0x1
     104:      	ldr	w11, [sp, #0xc]
     108:      	cmp	w9, w11
     10c:      	cset	w9, eq
     110:      	csinc	w7, wzr, w6, eq
     114:      	cinc	w11, w5, eq
     118:      	cmp	w11, w10
     11c:      	cset	w12, eq
     120:      	ands	w9, w9, w12
     124:      	csel	w19, wzr, w11, ne
     128:      	add	w20, w4, w9
     12c:      	add	w8, w8, #0x1
     130:      	cmp	w8, w3
     134:      	b.eq	0x1828 <ltmp0+0x1828>
     138:      	mov	x4, x20
     13c:      	mov	x5, x19
     140:      	mov	x6, x7
     144:      	ubfiz	x7, x7, #5, #32
     148:      	cmp	x7, x15
     14c:      	csel	x19, x7, xzr, ls
     150:      	subs	x20, x15, x19
     154:      	cmp	x20, #0x20
     158:      	mov	w9, #0x20               ; =32
     15c:      	csel	x20, x20, x9, lo
     160:      	cmp	x15, x19
     164:      	ccmp	x7, x15, #0x2, hi
     168:      	csel	x7, x20, xzr, ls
     16c:      	dup.4s	v24, w13
     170:      	dup.4s	v25, w14
     174:      	cmp	x7, #0x20
     178:      	b.lo	0xee8 <ltmp0+0xee8>
     17c:      	mov	x19, #0x0               ; =0
     180:      	ldr	x7, [x2, #0x88]
     184:      	ldr	x23, [x0]
     188:      	ldr	x22, [x0, #0x10]
     18c:      	ldr	x21, [x0, #0x30]
     190:      	lsl	w20, w6, #5
     194:      	dup.4s	v2, w20
     198:      	ldr	q1, [sp, #0x70]
     19c:      	orr.16b	v22, v2, v1
     1a0:      	ldr	q1, [sp, #0x60]
     1a4:      	orr.16b	v2, v2, v1
     1a8:      	ldr	q1, [sp, #0x50]
     1ac:      	umull2.2d	v30, v22, v1
     1b0:      	umull2.2d	v31, v2, v1
     1b4:      	umull.2d	v8, v22, v1
     1b8:      	umull.2d	v9, v2, v1
     1bc:      	dup.2d	v27, x23
     1c0:      	dup.2d	v2, x19
     1c4:      	add.2d	v22, v2, v30
     1c8:      	add.2d	v28, v2, v8
     1cc:      	add.2d	v29, v2, v31
     1d0:      	add.2d	v2, v2, v9
     1d4:      	shl.2d	v2, v2, #0x2
     1d8:      	shl.2d	v29, v29, #0x2
     1dc:      	shl.2d	v28, v28, #0x2
     1e0:      	shl.2d	v22, v22, #0x2
     1e4:      	add.2d	v22, v27, v22
     1e8:      	add.2d	v28, v27, v28
     1ec:      	add.2d	v29, v27, v29
     1f0:      	add.2d	v2, v27, v2
     1f4:      	mov.d	x23, v2[1]
     1f8:      	fmov	x24, d2
     1fc:      	mov.d	x25, v29[1]
     200:      	fmov	x26, d29
     204:      	mov.d	x27, v28[1]
     208:      	fmov	x28, d28
     20c:      	mov.d	x30, v22[1]
     210:      	ldr	s2, [x24]
     214:      	ld1.s	{ v2 }[1], [x23]
     218:      	fmov	x23, d22
     21c:      	ld1.s	{ v2 }[2], [x26]
     220:      	ld1.s	{ v2 }[3], [x25]
     224:      	ldr	s22, [x28]
     228:      	ld1.s	{ v22 }[1], [x27]
     22c:      	ld1.s	{ v22 }[2], [x23]
     230:      	ld1.s	{ v22 }[3], [x30]
     234:      	add	x23, x7, x19, lsl #5
     238:      	stp	q2, q22, [x23]
     23c:      	add	x19, x19, #0x1
     240:      	cmp	x19, #0x602
     244:      	b.ne	0x1c0 <ltmp0+0x1c0>
     248:      	mov	x23, #0x0               ; =0
     24c:      	mov	w9, #0xc040             ; =49216
     250:      	add	x19, x7, x9
     254:      	dup.2d	v28, x22
     258:      	dup.2d	v2, x23
     25c:      	add.2d	v22, v2, v30
     260:      	add.2d	v29, v2, v8
     264:      	add.2d	v10, v2, v31
     268:      	add.2d	v2, v2, v9
     26c:      	shl.2d	v2, v2, #0x2
     270:      	shl.2d	v10, v10, #0x2
     274:      	shl.2d	v29, v29, #0x2
     278:      	shl.2d	v22, v22, #0x2
     27c:      	add.2d	v22, v28, v22
     280:      	add.2d	v29, v28, v29
     284:      	add.2d	v10, v28, v10
     288:      	add.2d	v2, v28, v2
     28c:      	mov.d	x22, v2[1]
     290:      	fmov	x24, d2
     294:      	mov.d	x25, v10[1]
     298:      	fmov	x26, d10
     29c:      	mov.d	x27, v29[1]
     2a0:      	fmov	x28, d29
     2a4:      	mov.d	x30, v22[1]
     2a8:      	ldr	s2, [x24]
     2ac:      	ld1.s	{ v2 }[1], [x22]
     2b0:      	fmov	x22, d22
     2b4:      	ld1.s	{ v2 }[2], [x26]
     2b8:      	ld1.s	{ v2 }[3], [x25]
     2bc:      	ldr	s22, [x28]
     2c0:      	ld1.s	{ v22 }[1], [x27]
     2c4:      	ld1.s	{ v22 }[2], [x22]
     2c8:      	ld1.s	{ v22 }[3], [x30]
     2cc:      	add	x22, x19, x23, lsl #5
     2d0:      	stp	q2, q22, [x22]
     2d4:      	add	x23, x23, #0x1
     2d8:      	cmp	x23, #0x602
     2dc:      	b.ne	0x258 <ltmp0+0x258>
     2e0:      	mov	x22, #-0x602            ; =-1538
     2e4:      	mov	x23, x7
     2e8:      	ldp	q10, q29, [x23]
     2ec:      	fneg.4s	v2, v10
     2f0:      	fneg.4s	v22, v29
     2f4:      	fcmge.4s	v11, v3, v29
     2f8:      	fcmge.4s	v12, v3, v10
     2fc:      	fcmge.4s	v13, v29, v4
     300:      	fcmge.4s	v14, v10, v4
     304:      	and.16b	v12, v12, v14
     308:      	and.16b	v11, v11, v13
     30c:      	and.16b	v22, v11, v22
     310:      	and.16b	v2, v12, v2
     314:      	fmul.4s	v11, v2, v5
     318:      	fmul.4s	v12, v22, v5
     31c:      	mov.16b	v13, v16
     320:      	bsl.16b	v13, v0, v12
     324:      	mov.16b	v14, v16
     328:      	bsl.16b	v14, v0, v11
     32c:      	fadd.4s	v11, v11, v14
     330:      	fadd.4s	v12, v12, v13
     334:      	fsub.4s	v12, v12, v13
     338:      	fsub.4s	v11, v11, v14
     33c:      	fcvtzs.4s	v11, v11
     340:      	fcvtzs.4s	v12, v12
     344:      	scvtf.4s	v13, v12
     348:      	scvtf.4s	v14, v11
     34c:      	fmul.4s	v15, v13, v6
     350:      	fadd.4s	v22, v22, v15
     354:      	fmul.4s	v15, v14, v6
     358:      	fadd.4s	v2, v2, v15
     35c:      	fmul.4s	v13, v13, v7
     360:      	fmul.4s	v14, v14, v7
     364:      	fadd.4s	v2, v2, v14
     368:      	fadd.4s	v22, v22, v13
     36c:      	fmul.4s	v13, v22, v18
     370:      	fmul.4s	v14, v2, v18
     374:      	fadd.4s	v14, v14, v19
     378:      	fadd.4s	v13, v13, v19
     37c:      	fmul.4s	v13, v22, v13
     380:      	fmul.4s	v14, v2, v14
     384:      	fadd.4s	v14, v14, v23
     388:      	fadd.4s	v13, v13, v23
     38c:      	fmul.4s	v13, v22, v13
     390:      	fmul.4s	v14, v2, v14
     394:      	fadd.4s	v14, v14, v24
     398:      	fadd.4s	v13, v13, v24
     39c:      	fmul.4s	v13, v22, v13
     3a0:      	fmul.4s	v14, v2, v14
     3a4:      	fadd.4s	v14, v14, v25
     3a8:      	fadd.4s	v13, v13, v25
     3ac:      	fmul.4s	v13, v22, v13
     3b0:      	fmul.4s	v14, v2, v14
     3b4:      	fadd.4s	v14, v14, v17
     3b8:      	fadd.4s	v13, v13, v17
     3bc:      	fmul.4s	v15, v22, v22
     3c0:      	fmul.4s	v13, v15, v13
     3c4:      	fmul.4s	v15, v2, v2
     3c8:      	fmul.4s	v14, v15, v14
     3cc:      	fadd.4s	v2, v2, v14
     3d0:      	fadd.4s	v22, v22, v13
     3d4:      	fadd.4s	v22, v22, v26
     3d8:      	sshr.4s	v13, v11, #0x1
     3dc:      	shl.4s	v14, v13, #0x17
     3e0:      	add.4s	v14, v14, v26
     3e4:      	fadd.4s	v2, v2, v26
     3e8:      	fmul.4s	v2, v2, v14
     3ec:      	sshr.4s	v14, v12, #0x1
     3f0:      	sub.4s	v11, v11, v13
     3f4:      	shl.4s	v13, v14, #0x17
     3f8:      	add.4s	v13, v13, v26
     3fc:      	fmul.4s	v22, v22, v13
     400:      	sub.4s	v12, v12, v14
     404:      	shl.4s	v12, v12, #0x17
     408:      	add.4s	v12, v12, v26
     40c:      	fmul.4s	v22, v22, v12
     410:      	shl.4s	v11, v11, #0x17
     414:      	add	x24, x22, #0x602
     418:      	add.4s	v11, v11, v26
     41c:      	fmul.4s	v2, v2, v11
     420:      	fcmgt.4s	v11, v29, v3
     424:      	fadd.4s	v22, v22, v26
     428:      	bit.16b	v22, v26, v11
     42c:      	fcmgt.4s	v11, v10, v3
     430:      	fadd.4s	v2, v2, v26
     434:      	bit.16b	v2, v26, v11
     438:      	fcmgt.4s	v11, v4, v10
     43c:      	bit.16b	v2, v20, v11
     440:      	fcmgt.4s	v11, v4, v29
     444:      	bit.16b	v22, v20, v11
     448:      	fcmeq.4s	v11, v29, v29
     44c:      	bif.16b	v22, v21, v11
     450:      	fcmeq.4s	v11, v10, v10
     454:      	bif.16b	v2, v21, v11
     458:      	dup.2d	v11, x24
     45c:      	fdiv.4s	v2, v10, v2
     460:      	add.2d	v10, v11, v9
     464:      	fdiv.4s	v22, v29, v22
     468:      	dup.2d	v29, x21
     46c:      	shl.2d	v10, v10, #0x2
     470:      	add.2d	v10, v29, v10
     474:      	mov.d	x24, v10[1]
     478:      	fmov	x25, d10
     47c:      	add.2d	v10, v11, v31
     480:      	shl.2d	v10, v10, #0x2
     484:      	add.2d	v10, v29, v10
     488:      	mov.d	x26, v10[1]
     48c:      	fmov	x27, d10
     490:      	ldr	q10, [x23, #0xc040]
     494:      	fmul.4s	v2, v10, v2
     498:      	ldr	q10, [x23, #0xc050]
     49c:      	str	s2, [x25]
     4a0:      	st1.s	{ v2 }[1], [x24]
     4a4:      	st1.s	{ v2 }[2], [x27]
     4a8:      	fmul.4s	v22, v10, v22
     4ac:      	st1.s	{ v2 }[3], [x26]
     4b0:      	add.2d	v2, v11, v8
     4b4:      	shl.2d	v2, v2, #0x2
     4b8:      	add.2d	v2, v29, v2
     4bc:      	mov.d	x24, v2[1]
     4c0:      	fmov	x25, d2
     4c4:      	add.2d	v2, v11, v30
     4c8:      	shl.2d	v2, v2, #0x2
     4cc:      	add.2d	v2, v29, v2
     4d0:      	mov.d	x26, v2[1]
     4d4:      	fmov	x27, d2
     4d8:      	str	s22, [x25]
     4dc:      	st1.s	{ v22 }[1], [x24]
     4e0:      	st1.s	{ v22 }[2], [x27]
     4e4:      	st1.s	{ v22 }[3], [x26]
     4e8:      	add	x23, x23, #0x20
     4ec:      	adds	x22, x22, #0x1
     4f0:      	b.lo	0x2e8 <ltmp0+0x2e8>
     4f4:      	mov	x21, #0x0               ; =0
     4f8:      	orr	w22, w20, #0x8
     4fc:      	dup.4s	v2, w22
     500:      	ldr	q1, [sp, #0x70]
     504:      	orr.16b	v22, v2, v1
     508:      	ldr	q1, [sp, #0x60]
     50c:      	orr.16b	v2, v2, v1
     510:      	ldr	q1, [sp, #0x50]
     514:      	umull2.2d	v30, v22, v1
     518:      	umull2.2d	v31, v2, v1
     51c:      	umull.2d	v8, v22, v1
     520:      	umull.2d	v9, v2, v1
     524:      	dup.2d	v2, x21
     528:      	add.2d	v22, v2, v30
     52c:      	add.2d	v10, v2, v8
     530:      	add.2d	v11, v2, v31
     534:      	add.2d	v2, v2, v9
     538:      	shl.2d	v2, v2, #0x2
     53c:      	shl.2d	v11, v11, #0x2
     540:      	shl.2d	v10, v10, #0x2
     544:      	shl.2d	v22, v22, #0x2
     548:      	add.2d	v22, v27, v22
     54c:      	add.2d	v10, v27, v10
     550:      	add.2d	v11, v27, v11
     554:      	add.2d	v2, v27, v2
     558:      	mov.d	x22, v2[1]
     55c:      	fmov	x23, d2
     560:      	mov.d	x24, v11[1]
     564:      	fmov	x25, d11
     568:      	mov.d	x26, v10[1]
     56c:      	fmov	x27, d10
     570:      	mov.d	x28, v22[1]
     574:      	ldr	s2, [x23]
     578:      	ld1.s	{ v2 }[1], [x22]
     57c:      	fmov	x22, d22
     580:      	ld1.s	{ v2 }[2], [x25]
     584:      	ld1.s	{ v2 }[3], [x24]
     588:      	ldr	s22, [x27]
     58c:      	ld1.s	{ v22 }[1], [x26]
     590:      	ld1.s	{ v22 }[2], [x22]
     594:      	ld1.s	{ v22 }[3], [x28]
     598:      	add	x22, x7, x21, lsl #5
     59c:      	stp	q2, q22, [x22]
     5a0:      	add	x21, x21, #0x1
     5a4:      	cmp	x21, #0x602
     5a8:      	b.ne	0x524 <ltmp0+0x524>
     5ac:      	mov	x21, #0x0               ; =0
     5b0:      	dup.2d	v2, x21
     5b4:      	add.2d	v22, v2, v30
     5b8:      	add.2d	v10, v2, v8
     5bc:      	add.2d	v11, v2, v31
     5c0:      	add.2d	v2, v2, v9
     5c4:      	shl.2d	v2, v2, #0x2
     5c8:      	shl.2d	v11, v11, #0x2
     5cc:      	shl.2d	v10, v10, #0x2
     5d0:      	shl.2d	v22, v22, #0x2
     5d4:      	add.2d	v22, v28, v22
     5d8:      	add.2d	v10, v28, v10
     5dc:      	add.2d	v11, v28, v11
     5e0:      	add.2d	v2, v28, v2
     5e4:      	mov.d	x22, v2[1]
     5e8:      	fmov	x23, d2
     5ec:      	mov.d	x24, v11[1]
     5f0:      	fmov	x25, d11
     5f4:      	mov.d	x26, v10[1]
     5f8:      	fmov	x27, d10
     5fc:      	mov.d	x28, v22[1]
     600:      	ldr	s2, [x23]
     604:      	ld1.s	{ v2 }[1], [x22]
     608:      	fmov	x22, d22
     60c:      	ld1.s	{ v2 }[2], [x25]
     610:      	ld1.s	{ v2 }[3], [x24]
     614:      	ldr	s22, [x27]
     618:      	ld1.s	{ v22 }[1], [x26]
     61c:      	ld1.s	{ v22 }[2], [x22]
     620:      	ld1.s	{ v22 }[3], [x28]
     624:      	add	x22, x19, x21, lsl #5
     628:      	stp	q2, q22, [x22]
     62c:      	add	x21, x21, #0x1
     630:      	cmp	x21, #0x602
     634:      	b.ne	0x5b0 <ltmp0+0x5b0>
     638:      	mov	x21, #-0x602            ; =-1538
     63c:      	mov	x22, x7
     640:      	ldp	q11, q10, [x22]
     644:      	fneg.4s	v2, v11
     648:      	fneg.4s	v22, v10
     64c:      	fcmge.4s	v12, v3, v10
     650:      	fcmge.4s	v13, v3, v11
     654:      	fcmge.4s	v14, v10, v4
     658:      	fcmge.4s	v15, v11, v4
     65c:      	and.16b	v13, v13, v15
     660:      	and.16b	v12, v12, v14
     664:      	and.16b	v22, v12, v22
     668:      	and.16b	v2, v13, v2
     66c:      	fmul.4s	v12, v2, v5
     670:      	fmul.4s	v13, v22, v5
     674:      	mov.16b	v14, v16
     678:      	bsl.16b	v14, v0, v13
     67c:      	mov.16b	v15, v16
     680:      	bsl.16b	v15, v0, v12
     684:      	fadd.4s	v12, v12, v15
     688:      	fadd.4s	v13, v13, v14
     68c:      	fsub.4s	v13, v13, v14
     690:      	fsub.4s	v12, v12, v15
     694:      	fcvtzs.4s	v12, v12
     698:      	fcvtzs.4s	v13, v13
     69c:      	scvtf.4s	v14, v13
     6a0:      	scvtf.4s	v15, v12
     6a4:      	fmul.4s	v1, v14, v6
     6a8:      	fadd.4s	v1, v22, v1
     6ac:      	fmul.4s	v22, v15, v6
     6b0:      	fadd.4s	v2, v2, v22
     6b4:      	fmul.4s	v22, v14, v7
     6b8:      	fmul.4s	v14, v15, v7
     6bc:      	fadd.4s	v2, v2, v14
     6c0:      	fadd.4s	v1, v1, v22
     6c4:      	fmul.4s	v22, v1, v18
     6c8:      	fmul.4s	v14, v2, v18
     6cc:      	fadd.4s	v14, v14, v19
     6d0:      	fadd.4s	v22, v22, v19
     6d4:      	fmul.4s	v22, v1, v22
     6d8:      	fmul.4s	v14, v2, v14
     6dc:      	fadd.4s	v14, v14, v23
     6e0:      	fadd.4s	v22, v22, v23
     6e4:      	fmul.4s	v22, v1, v22
     6e8:      	fmul.4s	v14, v2, v14
     6ec:      	fadd.4s	v14, v14, v24
     6f0:      	fadd.4s	v22, v22, v24
     6f4:      	fmul.4s	v22, v1, v22
     6f8:      	fmul.4s	v14, v2, v14
     6fc:      	fadd.4s	v14, v14, v25
     700:      	fadd.4s	v22, v22, v25
     704:      	fmul.4s	v22, v1, v22
     708:      	fmul.4s	v14, v2, v14
     70c:      	fadd.4s	v14, v14, v17
     710:      	fadd.4s	v22, v22, v17
     714:      	fmul.4s	v15, v1, v1
     718:      	fmul.4s	v22, v15, v22
     71c:      	fmul.4s	v15, v2, v2
     720:      	fmul.4s	v14, v15, v14
     724:      	fadd.4s	v2, v2, v14
     728:      	fadd.4s	v1, v1, v22
     72c:      	sshr.4s	v22, v13, #0x1
     730:      	sshr.4s	v14, v12, #0x1
     734:      	fadd.4s	v2, v2, v26
     738:      	shl.4s	v15, v14, #0x17
     73c:      	add.4s	v15, v15, v26
     740:      	fmul.4s	v2, v2, v15
     744:      	shl.4s	v15, v22, #0x17
     748:      	add.4s	v15, v15, v26
     74c:      	fadd.4s	v1, v1, v26
     750:      	fmul.4s	v1, v1, v15
     754:      	sub.4s	v12, v12, v14
     758:      	sub.4s	v22, v13, v22
     75c:      	shl.4s	v22, v22, #0x17
     760:      	add.4s	v22, v22, v26
     764:      	fmul.4s	v1, v1, v22
     768:      	shl.4s	v22, v12, #0x17
     76c:      	add.4s	v22, v22, v26
     770:      	fmul.4s	v2, v2, v22
     774:      	fcmgt.4s	v22, v10, v3
     778:      	fadd.4s	v1, v1, v26
     77c:      	bit.16b	v1, v26, v22
     780:      	fcmgt.4s	v22, v11, v3
     784:      	fadd.4s	v2, v2, v26
     788:      	bit.16b	v2, v26, v22
     78c:      	fcmgt.4s	v22, v4, v11
     790:      	bit.16b	v2, v20, v22
     794:      	fcmgt.4s	v22, v4, v10
     798:      	bit.16b	v1, v20, v22
     79c:      	fcmeq.4s	v22, v10, v10
     7a0:      	bif.16b	v1, v21, v22
     7a4:      	fcmeq.4s	v22, v11, v11
     7a8:      	bif.16b	v2, v21, v22
     7ac:      	add	x23, x21, #0x602
     7b0:      	fdiv.4s	v2, v11, v2
     7b4:      	dup.2d	v22, x23
     7b8:      	fdiv.4s	v1, v10, v1
     7bc:      	add.2d	v10, v22, v9
     7c0:      	shl.2d	v10, v10, #0x2
     7c4:      	add.2d	v10, v29, v10
     7c8:      	mov.d	x23, v10[1]
     7cc:      	fmov	x24, d10
     7d0:      	add.2d	v10, v22, v31
     7d4:      	shl.2d	v10, v10, #0x2
     7d8:      	add.2d	v10, v29, v10
     7dc:      	mov.d	x25, v10[1]
     7e0:      	fmov	x26, d10
     7e4:      	ldr	q10, [x22, #0xc040]
     7e8:      	fmul.4s	v2, v10, v2
     7ec:      	ldr	q10, [x22, #0xc050]
     7f0:      	str	s2, [x24]
     7f4:      	st1.s	{ v2 }[1], [x23]
     7f8:      	st1.s	{ v2 }[2], [x26]
     7fc:      	fmul.4s	v1, v10, v1
     800:      	st1.s	{ v2 }[3], [x25]
     804:      	add.2d	v2, v22, v8
     808:      	shl.2d	v2, v2, #0x2
     80c:      	add.2d	v2, v29, v2
     810:      	mov.d	x23, v2[1]
     814:      	fmov	x24, d2
     818:      	add.2d	v2, v22, v30
     81c:      	shl.2d	v2, v2, #0x2
     820:      	add.2d	v2, v29, v2
     824:      	mov.d	x25, v2[1]
     828:      	fmov	x26, d2
     82c:      	str	s1, [x24]
     830:      	st1.s	{ v1 }[1], [x23]
     834:      	st1.s	{ v1 }[2], [x26]
     838:      	st1.s	{ v1 }[3], [x25]
     83c:      	add	x22, x22, #0x20
     840:      	adds	x21, x21, #0x1
     844:      	b.lo	0x640 <ltmp0+0x640>
     848:      	mov	x21, #0x0               ; =0
     84c:      	orr	w22, w20, #0x10
     850:      	dup.4s	v1, w22
     854:      	ldp	q22, q2, [sp, #0x60]
     858:      	orr.16b	v2, v1, v2
     85c:      	orr.16b	v1, v1, v22
     860:      	ldr	q22, [sp, #0x50]
     864:      	umull2.2d	v30, v2, v22
     868:      	umull2.2d	v31, v1, v22
     86c:      	umull.2d	v8, v2, v22
     870:      	umull.2d	v9, v1, v22
     874:      	dup.2d	v1, x21
     878:      	add.2d	v2, v1, v30
     87c:      	add.2d	v22, v1, v8
     880:      	add.2d	v10, v1, v31
     884:      	add.2d	v1, v1, v9
     888:      	shl.2d	v1, v1, #0x2
     88c:      	shl.2d	v10, v10, #0x2
     890:      	shl.2d	v22, v22, #0x2
     894:      	shl.2d	v2, v2, #0x2
     898:      	add.2d	v2, v27, v2
     89c:      	add.2d	v22, v27, v22
     8a0:      	add.2d	v10, v27, v10
     8a4:      	add.2d	v1, v27, v1
     8a8:      	mov.d	x22, v1[1]
     8ac:      	fmov	x23, d1
     8b0:      	mov.d	x24, v10[1]
     8b4:      	fmov	x25, d10
     8b8:      	mov.d	x26, v22[1]
     8bc:      	fmov	x27, d22
     8c0:      	mov.d	x28, v2[1]
     8c4:      	ldr	s1, [x23]
     8c8:      	ld1.s	{ v1 }[1], [x22]
     8cc:      	fmov	x22, d2
     8d0:      	ld1.s	{ v1 }[2], [x25]
     8d4:      	ld1.s	{ v1 }[3], [x24]
     8d8:      	ldr	s2, [x27]
     8dc:      	ld1.s	{ v2 }[1], [x26]
     8e0:      	ld1.s	{ v2 }[2], [x22]
     8e4:      	ld1.s	{ v2 }[3], [x28]
     8e8:      	add	x22, x7, x21, lsl #5
     8ec:      	stp	q1, q2, [x22]
     8f0:      	add	x21, x21, #0x1
     8f4:      	cmp	x21, #0x602
     8f8:      	b.ne	0x874 <ltmp0+0x874>
     8fc:      	mov	x21, #0x0               ; =0
     900:      	dup.2d	v1, x21
     904:      	add.2d	v2, v1, v30
     908:      	add.2d	v22, v1, v8
     90c:      	add.2d	v10, v1, v31
     910:      	add.2d	v1, v1, v9
     914:      	shl.2d	v1, v1, #0x2
     918:      	shl.2d	v10, v10, #0x2
     91c:      	shl.2d	v22, v22, #0x2
     920:      	shl.2d	v2, v2, #0x2
     924:      	add.2d	v2, v28, v2
     928:      	add.2d	v22, v28, v22
     92c:      	add.2d	v10, v28, v10
     930:      	add.2d	v1, v28, v1
     934:      	mov.d	x22, v1[1]
     938:      	fmov	x23, d1
     93c:      	mov.d	x24, v10[1]
     940:      	fmov	x25, d10
     944:      	mov.d	x26, v22[1]
     948:      	fmov	x27, d22
     94c:      	mov.d	x28, v2[1]
     950:      	ldr	s1, [x23]
     954:      	ld1.s	{ v1 }[1], [x22]
     958:      	fmov	x22, d2
     95c:      	ld1.s	{ v1 }[2], [x25]
     960:      	ld1.s	{ v1 }[3], [x24]
     964:      	ldr	s2, [x27]
     968:      	ld1.s	{ v2 }[1], [x26]
     96c:      	ld1.s	{ v2 }[2], [x22]
     970:      	ld1.s	{ v2 }[3], [x28]
     974:      	add	x22, x19, x21, lsl #5
     978:      	stp	q1, q2, [x22]
     97c:      	add	x21, x21, #0x1
     980:      	cmp	x21, #0x602
     984:      	b.ne	0x900 <ltmp0+0x900>
     988:      	mov	x21, #-0x602            ; =-1538
     98c:      	mov	x22, x7
     990:      	ldp	q11, q10, [x22]
     994:      	fneg.4s	v1, v11
     998:      	fneg.4s	v2, v10
     99c:      	fcmge.4s	v22, v3, v10
     9a0:      	fcmge.4s	v12, v3, v11
     9a4:      	fcmge.4s	v13, v10, v4
     9a8:      	fcmge.4s	v14, v11, v4
     9ac:      	and.16b	v12, v12, v14
     9b0:      	and.16b	v22, v22, v13
     9b4:      	and.16b	v2, v22, v2
     9b8:      	and.16b	v1, v12, v1
     9bc:      	fmul.4s	v22, v1, v5
     9c0:      	fmul.4s	v12, v2, v5
     9c4:      	mov.16b	v13, v16
     9c8:      	bsl.16b	v13, v0, v12
     9cc:      	mov.16b	v14, v16
     9d0:      	bsl.16b	v14, v0, v22
     9d4:      	fadd.4s	v22, v22, v14
     9d8:      	fadd.4s	v12, v12, v13
     9dc:      	fsub.4s	v12, v12, v13
     9e0:      	fsub.4s	v22, v22, v14
     9e4:      	fcvtzs.4s	v22, v22
     9e8:      	fcvtzs.4s	v12, v12
     9ec:      	scvtf.4s	v13, v12
     9f0:      	scvtf.4s	v14, v22
     9f4:      	fmul.4s	v15, v13, v6
     9f8:      	fadd.4s	v2, v2, v15
     9fc:      	fmul.4s	v15, v14, v6
     a00:      	fadd.4s	v1, v1, v15
     a04:      	fmul.4s	v13, v13, v7
     a08:      	fmul.4s	v14, v14, v7
     a0c:      	fadd.4s	v1, v1, v14
     a10:      	fadd.4s	v2, v2, v13
     a14:      	fmul.4s	v13, v2, v18
     a18:      	fmul.4s	v14, v1, v18
     a1c:      	fadd.4s	v14, v14, v19
     a20:      	fadd.4s	v13, v13, v19
     a24:      	fmul.4s	v13, v2, v13
     a28:      	fmul.4s	v14, v1, v14
     a2c:      	fadd.4s	v14, v14, v23
     a30:      	fadd.4s	v13, v13, v23
     a34:      	fmul.4s	v13, v2, v13
     a38:      	fmul.4s	v14, v1, v14
     a3c:      	fadd.4s	v14, v14, v24
     a40:      	fadd.4s	v13, v13, v24
     a44:      	fmul.4s	v13, v2, v13
     a48:      	fmul.4s	v14, v1, v14
     a4c:      	fadd.4s	v14, v14, v25
     a50:      	fadd.4s	v13, v13, v25
     a54:      	fmul.4s	v13, v2, v13
     a58:      	fmul.4s	v14, v1, v14
     a5c:      	fadd.4s	v14, v14, v17
     a60:      	fadd.4s	v13, v13, v17
     a64:      	fmul.4s	v15, v2, v2
     a68:      	fmul.4s	v13, v15, v13
     a6c:      	fmul.4s	v15, v1, v1
     a70:      	fmul.4s	v14, v15, v14
     a74:      	fadd.4s	v1, v1, v14
     a78:      	fadd.4s	v2, v2, v13
     a7c:      	sshr.4s	v13, v12, #0x1
     a80:      	sshr.4s	v14, v22, #0x1
     a84:      	fadd.4s	v1, v1, v26
     a88:      	shl.4s	v15, v14, #0x17
     a8c:      	add.4s	v15, v15, v26
     a90:      	fmul.4s	v1, v1, v15
     a94:      	shl.4s	v15, v13, #0x17
     a98:      	add.4s	v15, v15, v26
     a9c:      	fadd.4s	v2, v2, v26
     aa0:      	fmul.4s	v2, v2, v15
     aa4:      	sub.4s	v22, v22, v14
     aa8:      	sub.4s	v12, v12, v13
     aac:      	shl.4s	v12, v12, #0x17
     ab0:      	add.4s	v12, v12, v26
     ab4:      	fmul.4s	v2, v2, v12
     ab8:      	shl.4s	v22, v22, #0x17
     abc:      	add.4s	v22, v22, v26
     ac0:      	fmul.4s	v1, v1, v22
     ac4:      	fcmgt.4s	v22, v10, v3
     ac8:      	fadd.4s	v2, v2, v26
     acc:      	bit.16b	v2, v26, v22
     ad0:      	fcmgt.4s	v22, v11, v3
     ad4:      	fadd.4s	v1, v1, v26
     ad8:      	bit.16b	v1, v26, v22
     adc:      	fcmgt.4s	v22, v4, v11
     ae0:      	bit.16b	v1, v20, v22
     ae4:      	fcmgt.4s	v22, v4, v10
     ae8:      	bit.16b	v2, v20, v22
     aec:      	fcmeq.4s	v22, v10, v10
     af0:      	bif.16b	v2, v21, v22
     af4:      	fcmeq.4s	v22, v11, v11
     af8:      	bif.16b	v1, v21, v22
     afc:      	add	x23, x21, #0x602
     b00:      	fdiv.4s	v1, v11, v1
     b04:      	dup.2d	v22, x23
     b08:      	fdiv.4s	v2, v10, v2
     b0c:      	add.2d	v10, v22, v9
     b10:      	shl.2d	v10, v10, #0x2
     b14:      	add.2d	v10, v29, v10
     b18:      	mov.d	x23, v10[1]
     b1c:      	fmov	x24, d10
     b20:      	add.2d	v10, v22, v31
     b24:      	shl.2d	v10, v10, #0x2
     b28:      	add.2d	v10, v29, v10
     b2c:      	mov.d	x25, v10[1]
     b30:      	fmov	x26, d10
     b34:      	ldr	q10, [x22, #0xc040]
     b38:      	fmul.4s	v1, v10, v1
     b3c:      	ldr	q10, [x22, #0xc050]
     b40:      	str	s1, [x24]
     b44:      	st1.s	{ v1 }[1], [x23]
     b48:      	st1.s	{ v1 }[2], [x26]
     b4c:      	fmul.4s	v2, v10, v2
     b50:      	st1.s	{ v1 }[3], [x25]
     b54:      	add.2d	v1, v22, v8
     b58:      	shl.2d	v1, v1, #0x2
     b5c:      	add.2d	v1, v29, v1
     b60:      	mov.d	x23, v1[1]
     b64:      	fmov	x24, d1
     b68:      	add.2d	v1, v22, v30
     b6c:      	shl.2d	v1, v1, #0x2
     b70:      	add.2d	v1, v29, v1
     b74:      	mov.d	x25, v1[1]
     b78:      	fmov	x26, d1
     b7c:      	str	s2, [x24]
     b80:      	st1.s	{ v2 }[1], [x23]
     b84:      	st1.s	{ v2 }[2], [x26]
     b88:      	st1.s	{ v2 }[3], [x25]
     b8c:      	add	x22, x22, #0x20
     b90:      	adds	x21, x21, #0x1
     b94:      	b.lo	0x990 <ltmp0+0x990>
     b98:      	mov	x21, #0x0               ; =0
     b9c:      	orr	w20, w20, #0x18
     ba0:      	dup.4s	v1, w20
     ba4:      	ldp	q22, q2, [sp, #0x60]
     ba8:      	orr.16b	v2, v1, v2
     bac:      	orr.16b	v1, v1, v22
     bb0:      	ldr	q22, [sp, #0x50]
     bb4:      	umull2.2d	v30, v2, v22
     bb8:      	umull2.2d	v31, v1, v22
     bbc:      	umull.2d	v8, v2, v22
     bc0:      	umull.2d	v9, v1, v22
     bc4:      	dup.2d	v1, x21
     bc8:      	add.2d	v2, v1, v30
     bcc:      	add.2d	v22, v1, v8
     bd0:      	add.2d	v10, v1, v31
     bd4:      	add.2d	v1, v1, v9
     bd8:      	shl.2d	v1, v1, #0x2
     bdc:      	shl.2d	v10, v10, #0x2
     be0:      	shl.2d	v22, v22, #0x2
     be4:      	shl.2d	v2, v2, #0x2
     be8:      	add.2d	v2, v27, v2
     bec:      	add.2d	v22, v27, v22
     bf0:      	add.2d	v10, v27, v10
     bf4:      	add.2d	v1, v27, v1
     bf8:      	mov.d	x20, v1[1]
     bfc:      	fmov	x22, d1
     c00:      	mov.d	x23, v10[1]
     c04:      	fmov	x24, d10
     c08:      	mov.d	x25, v22[1]
     c0c:      	fmov	x26, d22
     c10:      	mov.d	x27, v2[1]
     c14:      	ldr	s1, [x22]
     c18:      	ld1.s	{ v1 }[1], [x20]
     c1c:      	fmov	x20, d2
     c20:      	ld1.s	{ v1 }[2], [x24]
     c24:      	ld1.s	{ v1 }[3], [x23]
     c28:      	ldr	s2, [x26]
     c2c:      	ld1.s	{ v2 }[1], [x25]
     c30:      	ld1.s	{ v2 }[2], [x20]
     c34:      	ld1.s	{ v2 }[3], [x27]
     c38:      	add	x20, x7, x21, lsl #5
     c3c:      	stp	q1, q2, [x20]
     c40:      	add	x21, x21, #0x1
     c44:      	cmp	x21, #0x602
     c48:      	b.ne	0xbc4 <ltmp0+0xbc4>
     c4c:      	mov	x20, #0x0               ; =0
     c50:      	dup.2d	v1, x20
     c54:      	add.2d	v2, v1, v30
     c58:      	add.2d	v22, v1, v8
     c5c:      	add.2d	v27, v1, v31
     c60:      	add.2d	v1, v1, v9
     c64:      	shl.2d	v1, v1, #0x2
     c68:      	shl.2d	v27, v27, #0x2
     c6c:      	shl.2d	v22, v22, #0x2
     c70:      	shl.2d	v2, v2, #0x2
     c74:      	add.2d	v2, v28, v2
     c78:      	add.2d	v22, v28, v22
     c7c:      	add.2d	v27, v28, v27
     c80:      	add.2d	v1, v28, v1
     c84:      	mov.d	x21, v1[1]
     c88:      	fmov	x22, d1
     c8c:      	mov.d	x23, v27[1]
     c90:      	fmov	x24, d27
     c94:      	mov.d	x25, v22[1]
     c98:      	fmov	x26, d22
     c9c:      	mov.d	x27, v2[1]
     ca0:      	ldr	s1, [x22]
     ca4:      	ld1.s	{ v1 }[1], [x21]
     ca8:      	fmov	x21, d2
     cac:      	ld1.s	{ v1 }[2], [x24]
     cb0:      	ld1.s	{ v1 }[3], [x23]
     cb4:      	ldr	s2, [x26]
     cb8:      	ld1.s	{ v2 }[1], [x25]
     cbc:      	ld1.s	{ v2 }[2], [x21]
     cc0:      	ld1.s	{ v2 }[3], [x27]
     cc4:      	add	x21, x19, x20, lsl #5
     cc8:      	stp	q1, q2, [x21]
     ccc:      	add	x20, x20, #0x1
     cd0:      	cmp	x20, #0x602
     cd4:      	b.ne	0xc50 <ltmp0+0xc50>
     cd8:      	mov	x19, #-0x602            ; =-1538
     cdc:      	ldp	q28, q27, [x7]
     ce0:      	fneg.4s	v1, v28
     ce4:      	fneg.4s	v2, v27
     ce8:      	fcmge.4s	v22, v3, v27
     cec:      	fcmge.4s	v10, v3, v28
     cf0:      	fcmge.4s	v11, v27, v4
     cf4:      	fcmge.4s	v12, v28, v4
     cf8:      	and.16b	v10, v10, v12
     cfc:      	and.16b	v22, v22, v11
     d00:      	and.16b	v2, v22, v2
     d04:      	and.16b	v1, v10, v1
     d08:      	fmul.4s	v22, v1, v5
     d0c:      	fmul.4s	v10, v2, v5
     d10:      	mov.16b	v11, v16
     d14:      	bsl.16b	v11, v0, v10
     d18:      	mov.16b	v12, v16
     d1c:      	bsl.16b	v12, v0, v22
     d20:      	fadd.4s	v22, v22, v12
     d24:      	fadd.4s	v10, v10, v11
     d28:      	fsub.4s	v10, v10, v11
     d2c:      	fsub.4s	v22, v22, v12
     d30:      	fcvtzs.4s	v22, v22
     d34:      	fcvtzs.4s	v10, v10
     d38:      	scvtf.4s	v11, v10
     d3c:      	scvtf.4s	v12, v22
     d40:      	fmul.4s	v13, v11, v6
     d44:      	fadd.4s	v2, v2, v13
     d48:      	fmul.4s	v13, v12, v6
     d4c:      	fadd.4s	v1, v1, v13
     d50:      	fmul.4s	v11, v11, v7
     d54:      	fmul.4s	v12, v12, v7
     d58:      	fadd.4s	v1, v1, v12
     d5c:      	fadd.4s	v2, v2, v11
     d60:      	fmul.4s	v11, v2, v18
     d64:      	fmul.4s	v12, v1, v18
     d68:      	fadd.4s	v12, v12, v19
     d6c:      	fadd.4s	v11, v11, v19
     d70:      	fmul.4s	v11, v2, v11
     d74:      	fmul.4s	v12, v1, v12
     d78:      	fadd.4s	v12, v12, v23
     d7c:      	fadd.4s	v11, v11, v23
     d80:      	fmul.4s	v11, v2, v11
     d84:      	fmul.4s	v12, v1, v12
     d88:      	fadd.4s	v12, v12, v24
     d8c:      	fadd.4s	v11, v11, v24
     d90:      	fmul.4s	v11, v2, v11
     d94:      	fmul.4s	v12, v1, v12
     d98:      	fadd.4s	v12, v12, v25
     d9c:      	fadd.4s	v11, v11, v25
     da0:      	fmul.4s	v11, v2, v11
     da4:      	fmul.4s	v12, v1, v12
     da8:      	fadd.4s	v12, v12, v17
     dac:      	fadd.4s	v11, v11, v17
     db0:      	fmul.4s	v13, v2, v2
     db4:      	fmul.4s	v11, v13, v11
     db8:      	fmul.4s	v13, v1, v1
     dbc:      	fmul.4s	v12, v13, v12
     dc0:      	fadd.4s	v1, v1, v12
     dc4:      	fadd.4s	v2, v2, v11
     dc8:      	sshr.4s	v11, v10, #0x1
     dcc:      	sshr.4s	v12, v22, #0x1
     dd0:      	fadd.4s	v1, v1, v26
     dd4:      	shl.4s	v13, v12, #0x17
     dd8:      	add.4s	v13, v13, v26
     ddc:      	fmul.4s	v1, v1, v13
     de0:      	shl.4s	v13, v11, #0x17
     de4:      	add.4s	v13, v13, v26
     de8:      	fadd.4s	v2, v2, v26
     dec:      	fmul.4s	v2, v2, v13
     df0:      	sub.4s	v22, v22, v12
     df4:      	sub.4s	v10, v10, v11
     df8:      	shl.4s	v10, v10, #0x17
     dfc:      	add.4s	v10, v10, v26
     e00:      	fmul.4s	v2, v2, v10
     e04:      	shl.4s	v22, v22, #0x17
     e08:      	add.4s	v22, v22, v26
     e0c:      	fmul.4s	v1, v1, v22
     e10:      	fcmgt.4s	v22, v27, v3
     e14:      	fadd.4s	v2, v2, v26
     e18:      	bit.16b	v2, v26, v22
     e1c:      	fcmgt.4s	v22, v28, v3
     e20:      	fadd.4s	v1, v1, v26
     e24:      	bit.16b	v1, v26, v22
     e28:      	fcmgt.4s	v22, v4, v28
     e2c:      	bit.16b	v1, v20, v22
     e30:      	fcmgt.4s	v22, v4, v27
     e34:      	bit.16b	v2, v20, v22
     e38:      	fcmeq.4s	v22, v27, v27
     e3c:      	bif.16b	v2, v21, v22
     e40:      	fcmeq.4s	v22, v28, v28
     e44:      	bif.16b	v1, v21, v22
     e48:      	add	x20, x19, #0x602
     e4c:      	fdiv.4s	v1, v28, v1
     e50:      	dup.2d	v22, x20
     e54:      	fdiv.4s	v2, v27, v2
     e58:      	add.2d	v27, v22, v9
     e5c:      	shl.2d	v27, v27, #0x2
     e60:      	add.2d	v27, v29, v27
     e64:      	mov.d	x20, v27[1]
     e68:      	fmov	x21, d27
     e6c:      	add.2d	v27, v22, v31
     e70:      	shl.2d	v27, v27, #0x2
     e74:      	add.2d	v27, v29, v27
     e78:      	mov.d	x22, v27[1]
     e7c:      	fmov	x23, d27
     e80:      	ldr	q27, [x7, #0xc040]
     e84:      	fmul.4s	v1, v27, v1
     e88:      	ldr	q27, [x7, #0xc050]
     e8c:      	str	s1, [x21]
     e90:      	st1.s	{ v1 }[1], [x20]
     e94:      	st1.s	{ v1 }[2], [x23]
     e98:      	fmul.4s	v2, v27, v2
     e9c:      	st1.s	{ v1 }[3], [x22]
     ea0:      	add.2d	v1, v22, v8
     ea4:      	shl.2d	v1, v1, #0x2
     ea8:      	add.2d	v1, v29, v1
     eac:      	mov.d	x20, v1[1]
     eb0:      	fmov	x21, d1
     eb4:      	add.2d	v1, v22, v30
     eb8:      	shl.2d	v1, v1, #0x2
     ebc:      	add.2d	v1, v29, v1
     ec0:      	mov.d	x22, v1[1]
     ec4:      	fmov	x23, d1
     ec8:      	str	s2, [x21]
     ecc:      	st1.s	{ v2 }[1], [x20]
     ed0:      	st1.s	{ v2 }[2], [x23]
     ed4:      	st1.s	{ v2 }[3], [x22]
     ed8:      	add	x7, x7, #0x20
     edc:      	adds	x19, x19, #0x1
     ee0:      	b.lo	0xcdc <ltmp0+0xcdc>
     ee4:      	b	0x100 <ltmp0+0x100>
     ee8:      	lsr	x19, x7, #3
     eec:      	cmp	x7, #0x8
     ef0:      	b.lo	0x127c <ltmp0+0x127c>
     ef4:      	mov	w20, #0x0               ; =0
     ef8:      	ldr	x21, [x2, #0x88]
     efc:      	ldr	x22, [x0]
     f00:      	ldr	x23, [x0, #0x10]
     f04:      	ldr	x24, [x0, #0x30]
     f08:      	lsl	w25, w6, #5
     f0c:      	mov	w9, #0xc040             ; =49216
     f10:      	add	x26, x21, x9
     f14:      	mov	x27, #0x0               ; =0
     f18:      	add	w28, w25, w20, lsl #3
     f1c:      	dup.4s	v1, w28
     f20:      	ldp	q22, q2, [sp, #0x60]
     f24:      	orr.16b	v2, v1, v2
     f28:      	orr.16b	v1, v1, v22
     f2c:      	ldr	q22, [sp, #0x50]
     f30:      	umull2.2d	v27, v2, v22
     f34:      	umull2.2d	v28, v1, v22
     f38:      	umull.2d	v29, v2, v22
     f3c:      	umull.2d	v30, v1, v22
     f40:      	dup.2d	v1, x27
     f44:      	add.2d	v2, v1, v27
     f48:      	add.2d	v22, v1, v29
     f4c:      	add.2d	v31, v1, v28
     f50:      	add.2d	v1, v1, v30
     f54:      	shl.2d	v1, v1, #0x2
     f58:      	shl.2d	v31, v31, #0x2
     f5c:      	shl.2d	v22, v22, #0x2
     f60:      	shl.2d	v2, v2, #0x2
     f64:      	dup.2d	v8, x22
     f68:      	add.2d	v2, v8, v2
     f6c:      	add.2d	v22, v8, v22
     f70:      	add.2d	v31, v8, v31
     f74:      	add.2d	v1, v8, v1
     f78:      	mov.d	x28, v1[1]
     f7c:      	fmov	x30, d1
     f80:      	mov.d	x12, v31[1]
     f84:      	fmov	x11, d31
     f88:      	mov.d	x13, v22[1]
     f8c:      	fmov	x14, d22
     f90:      	mov.d	x9, v2[1]
     f94:      	ldr	s1, [x30]
     f98:      	ld1.s	{ v1 }[1], [x28]
     f9c:      	fmov	x28, d2
     fa0:      	ld1.s	{ v1 }[2], [x11]
     fa4:      	ld1.s	{ v1 }[3], [x12]
     fa8:      	ldr	s2, [x14]
     fac:      	ld1.s	{ v2 }[1], [x13]
     fb0:      	ld1.s	{ v2 }[2], [x28]
     fb4:      	ld1.s	{ v2 }[3], [x9]
     fb8:      	add	x9, x21, x27, lsl #5
     fbc:      	stp	q1, q2, [x9]
     fc0:      	add	x27, x27, #0x1
     fc4:      	cmp	x27, #0x602
     fc8:      	b.ne	0xf40 <ltmp0+0xf40>
     fcc:      	mov	x27, #0x0               ; =0
     fd0:      	dup.2d	v1, x27
     fd4:      	add.2d	v2, v1, v27
     fd8:      	add.2d	v22, v1, v29
     fdc:      	add.2d	v31, v1, v28
     fe0:      	add.2d	v1, v1, v30
     fe4:      	shl.2d	v1, v1, #0x2
     fe8:      	shl.2d	v31, v31, #0x2
     fec:      	shl.2d	v22, v22, #0x2
     ff0:      	shl.2d	v2, v2, #0x2
     ff4:      	dup.2d	v8, x23
     ff8:      	add.2d	v2, v8, v2
     ffc:      	add.2d	v22, v8, v22
    1000:      	add.2d	v31, v8, v31
    1004:      	add.2d	v1, v8, v1
    1008:      	mov.d	x9, v1[1]
    100c:      	fmov	x11, d1
    1010:      	mov.d	x12, v31[1]
    1014:      	fmov	x13, d31
    1018:      	mov.d	x14, v22[1]
    101c:      	fmov	x28, d22
    1020:      	mov.d	x30, v2[1]
    1024:      	ldr	s1, [x11]
    1028:      	ld1.s	{ v1 }[1], [x9]
    102c:      	fmov	x9, d2
    1030:      	ld1.s	{ v1 }[2], [x13]
    1034:      	ld1.s	{ v1 }[3], [x12]
    1038:      	ldr	s2, [x28]
    103c:      	ld1.s	{ v2 }[1], [x14]
    1040:      	ld1.s	{ v2 }[2], [x9]
    1044:      	ld1.s	{ v2 }[3], [x30]
    1048:      	add	x9, x26, x27, lsl #5
    104c:      	stp	q1, q2, [x9]
    1050:      	add	x27, x27, #0x1
    1054:      	cmp	x27, #0x602
    1058:      	b.ne	0xfd0 <ltmp0+0xfd0>
    105c:      	mov	x27, #-0x602            ; =-1538
    1060:      	mov	x28, x21
    1064:      	ldp	q8, q31, [x28]
    1068:      	fneg.4s	v1, v8
    106c:      	fneg.4s	v2, v31
    1070:      	fcmge.4s	v22, v3, v31
    1074:      	fcmge.4s	v9, v3, v8
    1078:      	fcmge.4s	v10, v31, v4
    107c:      	fcmge.4s	v11, v8, v4
    1080:      	and.16b	v9, v9, v11
    1084:      	and.16b	v22, v22, v10
    1088:      	and.16b	v2, v22, v2
    108c:      	and.16b	v1, v9, v1
    1090:      	fmul.4s	v22, v1, v5
    1094:      	fmul.4s	v9, v2, v5
    1098:      	mov.16b	v10, v16
    109c:      	bsl.16b	v10, v0, v9
    10a0:      	mov.16b	v11, v16
    10a4:      	bsl.16b	v11, v0, v22
    10a8:      	fadd.4s	v22, v22, v11
    10ac:      	fadd.4s	v9, v9, v10
    10b0:      	fsub.4s	v9, v9, v10
    10b4:      	fsub.4s	v22, v22, v11
    10b8:      	fcvtzs.4s	v22, v22
    10bc:      	fcvtzs.4s	v9, v9
    10c0:      	scvtf.4s	v10, v9
    10c4:      	scvtf.4s	v11, v22
    10c8:      	fmul.4s	v12, v10, v6
    10cc:      	fadd.4s	v2, v2, v12
    10d0:      	fmul.4s	v12, v11, v6
    10d4:      	fadd.4s	v1, v1, v12
    10d8:      	fmul.4s	v10, v10, v7
    10dc:      	fmul.4s	v11, v11, v7
    10e0:      	fadd.4s	v1, v1, v11
    10e4:      	fadd.4s	v2, v2, v10
    10e8:      	fmul.4s	v10, v2, v18
    10ec:      	fmul.4s	v11, v1, v18
    10f0:      	fadd.4s	v11, v11, v19
    10f4:      	fadd.4s	v10, v10, v19
    10f8:      	fmul.4s	v10, v2, v10
    10fc:      	fmul.4s	v11, v1, v11
    1100:      	fadd.4s	v11, v11, v23
    1104:      	fadd.4s	v10, v10, v23
    1108:      	fmul.4s	v10, v2, v10
    110c:      	fmul.4s	v11, v1, v11
    1110:      	fadd.4s	v11, v11, v24
    1114:      	fadd.4s	v10, v10, v24
    1118:      	fmul.4s	v10, v2, v10
    111c:      	fmul.4s	v11, v1, v11
    1120:      	fadd.4s	v11, v11, v25
    1124:      	fadd.4s	v10, v10, v25
    1128:      	fmul.4s	v10, v2, v10
    112c:      	fmul.4s	v11, v1, v11
    1130:      	fadd.4s	v11, v11, v17
    1134:      	fadd.4s	v10, v10, v17
    1138:      	fmul.4s	v12, v2, v2
    113c:      	fmul.4s	v10, v12, v10
    1140:      	fmul.4s	v12, v1, v1
    1144:      	fmul.4s	v11, v12, v11
    1148:      	fadd.4s	v1, v1, v11
    114c:      	fadd.4s	v2, v2, v10
    1150:      	fadd.4s	v2, v2, v26
    1154:      	sshr.4s	v10, v22, #0x1
    1158:      	shl.4s	v11, v10, #0x17
    115c:      	add.4s	v11, v11, v26
    1160:      	fadd.4s	v1, v1, v26
    1164:      	fmul.4s	v1, v1, v11
    1168:      	sshr.4s	v11, v9, #0x1
    116c:      	sub.4s	v22, v22, v10
    1170:      	shl.4s	v10, v11, #0x17
    1174:      	add.4s	v10, v10, v26
    1178:      	fmul.4s	v2, v2, v10
    117c:      	add	x9, x27, #0x602
    1180:      	sub.4s	v9, v9, v11
    1184:      	shl.4s	v9, v9, #0x17
    1188:      	shl.4s	v22, v22, #0x17
    118c:      	dup.2d	v10, x9
    1190:      	add.4s	v22, v22, v26
    1194:      	add.4s	v9, v9, v26
    1198:      	fmul.4s	v2, v2, v9
    119c:      	fmul.4s	v1, v1, v22
    11a0:      	fcmgt.4s	v22, v8, v3
    11a4:      	fcmgt.4s	v9, v31, v3
    11a8:      	fadd.4s	v2, v2, v26
    11ac:      	bit.16b	v2, v26, v9
    11b0:      	fcmgt.4s	v9, v4, v31
    11b4:      	fadd.4s	v1, v1, v26
    11b8:      	bit.16b	v1, v26, v22
    11bc:      	fcmgt.4s	v22, v4, v8
    11c0:      	bit.16b	v1, v20, v22
    11c4:      	fcmeq.4s	v22, v8, v8
    11c8:      	bit.16b	v2, v20, v9
    11cc:      	fcmeq.4s	v9, v31, v31
    11d0:      	bif.16b	v2, v21, v9
    11d4:      	add.2d	v9, v10, v27
    11d8:      	bif.16b	v1, v21, v22
    11dc:      	add.2d	v22, v10, v29
    11e0:      	fdiv.4s	v1, v8, v1
    11e4:      	add.2d	v8, v10, v28
    11e8:      	add.2d	v10, v10, v30
    11ec:      	fdiv.4s	v2, v31, v2
    11f0:      	ldr	q31, [x28, #0xc050]
    11f4:      	fmul.4s	v2, v31, v2
    11f8:      	ldr	q31, [x28, #0xc040]
    11fc:      	shl.2d	v10, v10, #0x2
    1200:      	shl.2d	v8, v8, #0x2
    1204:      	fmul.4s	v1, v31, v1
    1208:      	shl.2d	v22, v22, #0x2
    120c:      	shl.2d	v31, v9, #0x2
    1210:      	dup.2d	v9, x24
    1214:      	add.2d	v31, v9, v31
    1218:      	add.2d	v22, v9, v22
    121c:      	add.2d	v8, v9, v8
    1220:      	add.2d	v9, v9, v10
    1224:      	mov.d	x9, v9[1]
    1228:      	mov.d	x11, v8[1]
    122c:      	fmov	x12, d9
    1230:      	fmov	x13, d8
    1234:      	mov.d	x14, v22[1]
    1238:      	fmov	x30, d22
    123c:      	str	s1, [x12]
    1240:      	st1.s	{ v1 }[1], [x9]
    1244:      	st1.s	{ v1 }[2], [x13]
    1248:      	st1.s	{ v1 }[3], [x11]
    124c:      	mov.d	x9, v31[1]
    1250:      	fmov	x11, d31
    1254:      	str	s2, [x30]
    1258:      	st1.s	{ v2 }[1], [x14]
    125c:      	st1.s	{ v2 }[2], [x11]
    1260:      	st1.s	{ v2 }[3], [x9]
    1264:      	add	x28, x28, #0x20
    1268:      	adds	x27, x27, #0x1
    126c:      	b.lo	0x1064 <ltmp0+0x1064>
    1270:      	add	w20, w20, #0x1
    1274:      	cmp	w20, w19
    1278:      	b.ne	0xf14 <ltmp0+0xf14>
    127c:      	and	w7, w7, #0x7
    1280:      	mov	w13, #0xaa7a            ; =43642
    1284:      	movk	w13, #0x3d2a, lsl #16
    1288:      	mov	w14, #0xaaab            ; =43691
    128c:      	movk	w14, #0x3e2a, lsl #16
    1290:      	cbz	w7, 0x100 <ltmp0+0x100>
    1294:      	dup.4s	v1, w7
    1298:      	ldr	q2, [sp, #0x70]
    129c:      	cmhi.4s	v22, v1, v2
    12a0:      	ldr	q2, [sp, #0x60]
    12a4:      	cmhi.4s	v28, v1, v2
    12a8:      	str	q22, [sp, #0x40]
    12ac:      	uzp1.8h	v10, v28, v22
    12b0:      	umaxv.8h	h1, v10
    12b4:      	fmov	w9, s1
    12b8:      	tbz	w9, #0x0, 0x100 <ltmp0+0x100>
    12bc:      	mov	x22, #0x0               ; =0
    12c0:      	ldr	x7, [x2, #0x88]
    12c4:      	mov	w9, #0xc040             ; =49216
    12c8:      	add	x20, x7, x9
    12cc:      	ldr	x23, [x0]
    12d0:      	ldr	x21, [x0, #0x10]
    12d4:      	lsl	w9, w19, #3
    12d8:      	orr	w9, w9, w6, lsl #5
    12dc:      	dup.4s	v1, w9
    12e0:      	ldr	x19, [x0, #0x30]
    12e4:      	ldp	q2, q22, [sp, #0x60]
    12e8:      	orr.16b	v2, v1, v2
    12ec:      	orr.16b	v1, v1, v22
    12f0:      	ldp	q27, q22, [sp, #0x40]
    12f4:      	and.16b	v1, v27, v1
    12f8:      	and.16b	v2, v28, v2
    12fc:      	umull2.2d	v29, v1, v22
    1300:      	umull2.2d	v31, v2, v22
    1304:      	umull.2d	v30, v1, v22
    1308:      	umull.2d	v22, v2, v22
    130c:      	b	0x1330 <ltmp0+0x1330>
    1310:      	add	x9, x7, x22, lsl #5
    1314:      	ldp	q1, q2, [x9]
    1318:      	bit.16b	v2, v12, v27
    131c:      	bit.16b	v1, v11, v28
    1320:      	stp	q1, q2, [x9]
    1324:      	add	x22, x22, #0x1
    1328:      	cmp	x22, #0x602
    132c:      	b.eq	0x1430 <ltmp0+0x1430>
    1330:      	ldr	q1, [x16]
    1334:      	and.16b	v1, v10, v1
    1338:      	addv.8h	h8, v1
    133c:      	fmov	w24, s8
    1340:      	dup.2d	v13, x22
    1344:      	add.2d	v1, v13, v22
    1348:      	shl.2d	v1, v1, #0x2
    134c:      	dup.2d	v14, x23
    1350:      	add.2d	v2, v14, v1
    1354:      	movi.2d	v11, #0000000000000000
    1358:      	movi.2d	v12, #0000000000000000
    135c:      	tbnz	w24, #0x0, 0x13a8 <ltmp0+0x13a8>
    1360:      	and	w24, w24, #0xff
    1364:      	tbnz	w24, #0x1, 0x13b8 <ltmp0+0x13b8>
    1368:      	add.2d	v1, v13, v31
    136c:      	shl.2d	v1, v1, #0x2
    1370:      	add.2d	v2, v14, v1
    1374:      	tbnz	w24, #0x2, 0x13d0 <ltmp0+0x13d0>
    1378:      	tbnz	w24, #0x3, 0x13dc <ltmp0+0x13dc>
    137c:      	add.2d	v1, v13, v30
    1380:      	shl.2d	v1, v1, #0x2
    1384:      	add.2d	v2, v14, v1
    1388:      	tbnz	w24, #0x4, 0x13f4 <ltmp0+0x13f4>
    138c:      	tbnz	w24, #0x5, 0x1400 <ltmp0+0x1400>
    1390:      	add.2d	v1, v13, v29
    1394:      	shl.2d	v1, v1, #0x2
    1398:      	add.2d	v2, v14, v1
    139c:      	tbnz	w24, #0x6, 0x1418 <ltmp0+0x1418>
    13a0:      	tbz	w24, #0x7, 0x1310 <ltmp0+0x1310>
    13a4:      	b	0x1424 <ltmp0+0x1424>
    13a8:      	fmov	x9, d2
    13ac:      	ldr	s11, [x9]
    13b0:      	and	w24, w24, #0xff
    13b4:      	tbz	w24, #0x1, 0x1368 <ltmp0+0x1368>
    13b8:      	mov.d	x9, v2[1]
    13bc:      	ld1.s	{ v11 }[1], [x9]
    13c0:      	add.2d	v1, v13, v31
    13c4:      	shl.2d	v1, v1, #0x2
    13c8:      	add.2d	v2, v14, v1
    13cc:      	tbz	w24, #0x2, 0x1378 <ltmp0+0x1378>
    13d0:      	fmov	x9, d2
    13d4:      	ld1.s	{ v11 }[2], [x9]
    13d8:      	tbz	w24, #0x3, 0x137c <ltmp0+0x137c>
    13dc:      	mov.d	x9, v2[1]
    13e0:      	ld1.s	{ v11 }[3], [x9]
    13e4:      	add.2d	v1, v13, v30
    13e8:      	shl.2d	v1, v1, #0x2
    13ec:      	add.2d	v2, v14, v1
    13f0:      	tbz	w24, #0x4, 0x138c <ltmp0+0x138c>
    13f4:      	fmov	x9, d2
    13f8:      	ld1.s	{ v12 }[0], [x9]
    13fc:      	tbz	w24, #0x5, 0x1390 <ltmp0+0x1390>
    1400:      	mov.d	x9, v2[1]
    1404:      	ld1.s	{ v12 }[1], [x9]
    1408:      	add.2d	v1, v13, v29
    140c:      	shl.2d	v1, v1, #0x2
    1410:      	add.2d	v2, v14, v1
    1414:      	tbz	w24, #0x6, 0x13a0 <ltmp0+0x13a0>
    1418:      	fmov	x9, d2
    141c:      	ld1.s	{ v12 }[2], [x9]
    1420:      	tbz	w24, #0x7, 0x1310 <ltmp0+0x1310>
    1424:      	mov.d	x9, v2[1]
    1428:      	ld1.s	{ v12 }[3], [x9]
    142c:      	b	0x1310 <ltmp0+0x1310>
    1430:      	mov	x22, #0x0               ; =0
    1434:      	b	0x1458 <ltmp0+0x1458>
    1438:      	add	x9, x20, x22, lsl #5
    143c:      	ldp	q1, q2, [x9]
    1440:      	bit.16b	v2, v11, v27
    1444:      	bit.16b	v1, v10, v28
    1448:      	stp	q1, q2, [x9]
    144c:      	add	x22, x22, #0x1
    1450:      	cmp	x22, #0x602
    1454:      	b.eq	0x154c <ltmp0+0x154c>
    1458:      	fmov	w23, s8
    145c:      	dup.2d	v12, x22
    1460:      	add.2d	v1, v12, v22
    1464:      	shl.2d	v1, v1, #0x2
    1468:      	dup.2d	v13, x21
    146c:      	add.2d	v2, v13, v1
    1470:      	movi.2d	v10, #0000000000000000
    1474:      	movi.2d	v11, #0000000000000000
    1478:      	tbnz	w23, #0x0, 0x14c4 <ltmp0+0x14c4>
    147c:      	and	w23, w23, #0xff
    1480:      	tbnz	w23, #0x1, 0x14d4 <ltmp0+0x14d4>
    1484:      	add.2d	v1, v12, v31
    1488:      	shl.2d	v1, v1, #0x2
    148c:      	add.2d	v2, v13, v1
    1490:      	tbnz	w23, #0x2, 0x14ec <ltmp0+0x14ec>
    1494:      	tbnz	w23, #0x3, 0x14f8 <ltmp0+0x14f8>
    1498:      	add.2d	v1, v12, v30
    149c:      	shl.2d	v1, v1, #0x2
    14a0:      	add.2d	v2, v13, v1
    14a4:      	tbnz	w23, #0x4, 0x1510 <ltmp0+0x1510>
    14a8:      	tbnz	w23, #0x5, 0x151c <ltmp0+0x151c>
    14ac:      	add.2d	v1, v12, v29
    14b0:      	shl.2d	v1, v1, #0x2
    14b4:      	add.2d	v2, v13, v1
    14b8:      	tbnz	w23, #0x6, 0x1534 <ltmp0+0x1534>
    14bc:      	tbz	w23, #0x7, 0x1438 <ltmp0+0x1438>
    14c0:      	b	0x1540 <ltmp0+0x1540>
    14c4:      	fmov	x9, d2
    14c8:      	ldr	s10, [x9]
    14cc:      	and	w23, w23, #0xff
    14d0:      	tbz	w23, #0x1, 0x1484 <ltmp0+0x1484>
    14d4:      	mov.d	x9, v2[1]
    14d8:      	ld1.s	{ v10 }[1], [x9]
    14dc:      	add.2d	v1, v12, v31
    14e0:      	shl.2d	v1, v1, #0x2
    14e4:      	add.2d	v2, v13, v1
    14e8:      	tbz	w23, #0x2, 0x1494 <ltmp0+0x1494>
    14ec:      	fmov	x9, d2
    14f0:      	ld1.s	{ v10 }[2], [x9]
    14f4:      	tbz	w23, #0x3, 0x1498 <ltmp0+0x1498>
    14f8:      	mov.d	x9, v2[1]
    14fc:      	ld1.s	{ v10 }[3], [x9]
    1500:      	add.2d	v1, v12, v30
    1504:      	shl.2d	v1, v1, #0x2
    1508:      	add.2d	v2, v13, v1
    150c:      	tbz	w23, #0x4, 0x14a8 <ltmp0+0x14a8>
    1510:      	fmov	x9, d2
    1514:      	ld1.s	{ v11 }[0], [x9]
    1518:      	tbz	w23, #0x5, 0x14ac <ltmp0+0x14ac>
    151c:      	mov.d	x9, v2[1]
    1520:      	ld1.s	{ v11 }[1], [x9]
    1524:      	add.2d	v1, v12, v29
    1528:      	shl.2d	v1, v1, #0x2
    152c:      	add.2d	v2, v13, v1
    1530:      	tbz	w23, #0x6, 0x14bc <ltmp0+0x14bc>
    1534:      	fmov	x9, d2
    1538:      	ld1.s	{ v11 }[2], [x9]
    153c:      	tbz	w23, #0x7, 0x1438 <ltmp0+0x1438>
    1540:      	mov.d	x9, v2[1]
    1544:      	ld1.s	{ v11 }[3], [x9]
    1548:      	b	0x1438 <ltmp0+0x1438>
    154c:      	stp	q22, q30, [sp, #0x20]
    1550:      	mov	x20, #-0x602            ; =-1538
    1554:      	str	q29, [sp, #0x10]
    1558:      	b	0x156c <ltmp0+0x156c>
    155c:      	add	x7, x7, #0x20
    1560:      	adds	x20, x20, #0x1
    1564:      	ldr	q22, [sp, #0x20]
    1568:      	b.hs	0x100 <ltmp0+0x100>
    156c:      	fmov	w21, s8
    1570:      	add	x9, x20, #0x602
    1574:      	dup.2d	v10, x9
    1578:      	add.2d	v1, v10, v22
    157c:      	ldp	q2, q14, [x7]
    1580:      	and.16b	v2, v28, v2
    1584:      	fneg.4s	v22, v2
    1588:      	and.16b	v22, v28, v22
    158c:      	dup.4s	v11, w17
    1590:      	fcmge.4s	v13, v22, v11
    1594:      	dup.4s	v12, w1
    1598:      	fcmge.4s	v15, v12, v22
    159c:      	and.16b	v13, v13, v15
    15a0:      	and.16b	v13, v13, v22
    15a4:      	fmul.4s	v15, v13, v5
    15a8:      	mov.16b	v29, v16
    15ac:      	bsl.16b	v29, v0, v15
    15b0:      	fadd.4s	v15, v15, v29
    15b4:      	fsub.4s	v29, v15, v29
    15b8:      	fcvtzs.4s	v29, v29
    15bc:      	scvtf.4s	v15, v29
    15c0:      	fmul.4s	v30, v15, v6
    15c4:      	fadd.4s	v30, v13, v30
    15c8:      	fmul.4s	v13, v15, v7
    15cc:      	fadd.4s	v30, v30, v13
    15d0:      	fmul.4s	v13, v30, v18
    15d4:      	fadd.4s	v13, v13, v19
    15d8:      	fmul.4s	v13, v30, v13
    15dc:      	fadd.4s	v13, v13, v23
    15e0:      	fmul.4s	v13, v30, v13
    15e4:      	fadd.4s	v13, v13, v24
    15e8:      	fmul.4s	v13, v30, v13
    15ec:      	fadd.4s	v13, v13, v25
    15f0:      	fmul.4s	v13, v30, v13
    15f4:      	fadd.4s	v13, v13, v17
    15f8:      	fmul.4s	v15, v30, v30
    15fc:      	fmul.4s	v13, v15, v13
    1600:      	fadd.4s	v30, v30, v13
    1604:      	fadd.4s	v30, v30, v26
    1608:      	sshr.4s	v13, v29, #0x1
    160c:      	shl.4s	v15, v13, #0x17
    1610:      	add.4s	v15, v15, v26
    1614:      	fmul.4s	v30, v30, v15
    1618:      	sub.4s	v29, v29, v13
    161c:      	shl.4s	v29, v29, #0x17
    1620:      	add.4s	v29, v29, v26
    1624:      	fmul.4s	v29, v30, v29
    1628:      	fcmgt.4s	v30, v11, v22
    162c:      	fcmgt.4s	v13, v22, v12
    1630:      	fcmeq.4s	v22, v22, v22
    1634:      	fadd.4s	v29, v29, v26
    1638:      	bit.16b	v29, v26, v30
    163c:      	bit.16b	v29, v20, v13
    1640:      	bsl.16b	v22, v29, v21
    1644:      	fdiv.4s	v2, v2, v22
    1648:      	ldr	q15, [x7, #0xc050]
    164c:      	ldr	q22, [x7, #0xc040]
    1650:      	and.16b	v22, v28, v22
    1654:      	fmul.4s	v2, v22, v2
    1658:      	shl.2d	v1, v1, #0x2
    165c:      	dup.2d	v13, x19
    1660:      	add.2d	v22, v13, v1
    1664:      	tbnz	w21, #0x0, 0x179c <ltmp0+0x179c>
    1668:      	and	w21, w21, #0xff
    166c:      	ldr	q29, [sp, #0x30]
    1670:      	tbnz	w21, #0x1, 0x17b0 <ltmp0+0x17b0>
    1674:      	add.2d	v1, v10, v31
    1678:      	shl.2d	v1, v1, #0x2
    167c:      	add.2d	v22, v13, v1
    1680:      	tbnz	w21, #0x2, 0x17c8 <ltmp0+0x17c8>
    1684:      	mov.16b	v27, v28
    1688:      	mov.16b	v9, v31
    168c:      	tbz	w21, #0x3, 0x1698 <ltmp0+0x1698>
    1690:      	mov.d	x9, v22[1]
    1694:      	st1.s	{ v2 }[3], [x9]
    1698:      	add.2d	v1, v10, v29
    169c:      	ldr	q28, [sp, #0x40]
    16a0:      	and.16b	v2, v28, v14
    16a4:      	fneg.4s	v22, v2
    16a8:      	and.16b	v22, v28, v22
    16ac:      	fcmge.4s	v29, v22, v11
    16b0:      	fcmge.4s	v30, v12, v22
    16b4:      	and.16b	v29, v29, v30
    16b8:      	and.16b	v29, v29, v22
    16bc:      	fmul.4s	v30, v29, v5
    16c0:      	mov.16b	v14, v16
    16c4:      	bsl.16b	v14, v0, v30
    16c8:      	fadd.4s	v30, v30, v14
    16cc:      	fsub.4s	v30, v30, v14
    16d0:      	fcvtzs.4s	v30, v30
    16d4:      	scvtf.4s	v14, v30
    16d8:      	fmul.4s	v31, v14, v6
    16dc:      	fadd.4s	v29, v29, v31
    16e0:      	fmul.4s	v31, v14, v7
    16e4:      	fadd.4s	v29, v29, v31
    16e8:      	fmul.4s	v31, v29, v18
    16ec:      	fadd.4s	v31, v31, v19
    16f0:      	fmul.4s	v31, v29, v31
    16f4:      	fadd.4s	v31, v31, v23
    16f8:      	fmul.4s	v31, v29, v31
    16fc:      	fadd.4s	v31, v31, v24
    1700:      	fmul.4s	v31, v29, v31
    1704:      	fadd.4s	v31, v31, v25
    1708:      	fmul.4s	v31, v29, v31
    170c:      	fadd.4s	v31, v31, v17
    1710:      	fmul.4s	v14, v29, v29
    1714:      	fmul.4s	v31, v14, v31
    1718:      	fadd.4s	v29, v29, v31
    171c:      	fadd.4s	v29, v29, v26
    1720:      	sshr.4s	v31, v30, #0x1
    1724:      	shl.4s	v14, v31, #0x17
    1728:      	add.4s	v14, v14, v26
    172c:      	fmul.4s	v29, v29, v14
    1730:      	sub.4s	v30, v30, v31
    1734:      	shl.4s	v30, v30, #0x17
    1738:      	add.4s	v30, v30, v26
    173c:      	fmul.4s	v29, v29, v30
    1740:      	fcmgt.4s	v30, v11, v22
    1744:      	fcmgt.4s	v31, v22, v12
    1748:      	fcmeq.4s	v22, v22, v22
    174c:      	fadd.4s	v29, v29, v26
    1750:      	bit.16b	v29, v26, v30
    1754:      	bit.16b	v29, v20, v31
    1758:      	bsl.16b	v22, v29, v21
    175c:      	fdiv.4s	v2, v2, v22
    1760:      	and.16b	v22, v28, v15
    1764:      	fmul.4s	v2, v22, v2
    1768:      	shl.2d	v1, v1, #0x2
    176c:      	add.2d	v22, v13, v1
    1770:      	tbnz	w21, #0x4, 0x17e0 <ltmp0+0x17e0>
    1774:      	ldr	q29, [sp, #0x10]
    1778:      	mov.16b	v28, v27
    177c:      	tbnz	w21, #0x5, 0x17f4 <ltmp0+0x17f4>
    1780:      	add.2d	v1, v10, v29
    1784:      	shl.2d	v1, v1, #0x2
    1788:      	add.2d	v22, v13, v1
    178c:      	mov.16b	v31, v9
    1790:      	tbnz	w21, #0x6, 0x1810 <ltmp0+0x1810>
    1794:      	tbz	w21, #0x7, 0x155c <ltmp0+0x155c>
    1798:      	b	0x181c <ltmp0+0x181c>
    179c:      	fmov	x9, d22
    17a0:      	str	s2, [x9]
    17a4:      	and	w21, w21, #0xff
    17a8:      	ldr	q29, [sp, #0x30]
    17ac:      	tbz	w21, #0x1, 0x1674 <ltmp0+0x1674>
    17b0:      	mov.d	x9, v22[1]
    17b4:      	st1.s	{ v2 }[1], [x9]
    17b8:      	add.2d	v1, v10, v31
    17bc:      	shl.2d	v1, v1, #0x2
    17c0:      	add.2d	v22, v13, v1
    17c4:      	tbz	w21, #0x2, 0x1684 <ltmp0+0x1684>
    17c8:      	fmov	x9, d22
    17cc:      	st1.s	{ v2 }[2], [x9]
    17d0:      	mov.16b	v27, v28
    17d4:      	mov.16b	v9, v31
    17d8:      	tbnz	w21, #0x3, 0x1690 <ltmp0+0x1690>
    17dc:      	b	0x1698 <ltmp0+0x1698>
    17e0:      	fmov	x9, d22
    17e4:      	str	s2, [x9]
    17e8:      	ldr	q29, [sp, #0x10]
    17ec:      	mov.16b	v28, v27
    17f0:      	tbz	w21, #0x5, 0x1780 <ltmp0+0x1780>
    17f4:      	mov.d	x9, v22[1]
    17f8:      	st1.s	{ v2 }[1], [x9]
    17fc:      	add.2d	v1, v10, v29
    1800:      	shl.2d	v1, v1, #0x2
    1804:      	add.2d	v22, v13, v1
    1808:      	mov.16b	v31, v9
    180c:      	tbz	w21, #0x6, 0x1794 <ltmp0+0x1794>
    1810:      	fmov	x9, d22
    1814:      	st1.s	{ v2 }[2], [x9]
    1818:      	tbz	w21, #0x7, 0x155c <ltmp0+0x155c>
    181c:      	mov.d	x9, v22[1]
    1820:      	st1.s	{ v2 }[3], [x9]
    1824:      	b	0x155c <ltmp0+0x155c>
    1828:      	stp	w6, w5, [x2]
    182c:      	str	w4, [x2, #0x8]
    1830:      	mov	w8, #0x18               ; =24
    1834:      	str	w8, [x2, #0x24]
    1838:      	ldp	x29, x30, [sp, #0x120]
    183c:      	ldp	x20, x19, [sp, #0x110]
    1840:      	ldp	x22, x21, [sp, #0x100]
    1844:      	ldp	x24, x23, [sp, #0xf0]
    1848:      	ldp	x26, x25, [sp, #0xe0]
    184c:      	ldp	x28, x27, [sp, #0xd0]
    1850:      	ldp	d9, d8, [sp, #0xc0]
    1854:      	ldp	d11, d10, [sp, #0xb0]
    1858:      	ldp	d13, d12, [sp, #0xa0]
    185c:      	ldp	d15, d14, [sp, #0x90]
    1860:      	add	sp, sp, #0x130
    1864:      	ret

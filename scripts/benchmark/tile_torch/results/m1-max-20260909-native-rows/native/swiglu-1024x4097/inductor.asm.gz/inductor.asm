
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/swiglu-1024x4097/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0x80
     6b4:      	stp	x24, x23, [sp, #0x40]
     6b8:      	stp	x22, x21, [sp, #0x50]
     6bc:      	stp	x20, x19, [sp, #0x60]
     6c0:      	stp	x29, x30, [sp, #0x70]
     6c4:      	add	x29, sp, #0x70
     6c8:      	mov	x19, x2
     6cc:      	mov	x20, x1
     6d0:      	mov	x21, x0
     6d4:      	adrp	x22, 0x4000 <dyld_stub_binder+0x4000>
     6d8:      	ldr	x22, [x22, #0x90]
     6dc:      	str	wzr, [sp, #0x20]
     6e0:      	add	x8, sp, #0x20
     6e4:      	str	x8, [x22]
     6e8:      	mov	x23, #-0x4              ; =-4
     6ec:      	mov	w24, #0x3fc             ; =1020
     6f0:      	movk	w24, #0x40, lsl #16
     6f4:      	ldr	q1, [x21], #0x10
     6f8:      	ldr	q0, [x20], #0x10
     6fc:      	stp	q1, q0, [sp]
     700:      	fneg.4s	v0, v1
     704:      	bl	0x1678 <dyld_stub_binder+0x1678>
     708:      	fmov.4s	v1, #1.00000000
     70c:      	fadd.4s	v0, v0, v1
     710:      	ldp	q2, q1, [sp]
     714:      	fdiv.4s	v0, v2, v0
     718:      	fmul.4s	v0, v1, v0
     71c:      	str	q0, [x19], #0x10
     720:      	add	x23, x23, #0x4
     724:      	cmp	x23, x24
     728:      	b.lo	0x6f4 <_kernel+0x44>
     72c:      	str	xzr, [x22]
     730:      	add	x8, sp, #0x20
     734:      	ldapr	w8, [x8]
     738:      	cbnz	w8, 0x754 <_kernel+0xa4>
     73c:      	ldp	x29, x30, [sp, #0x70]
     740:      	ldp	x20, x19, [sp, #0x60]
     744:      	ldp	x22, x21, [sp, #0x50]
     748:      	ldp	x24, x23, [sp, #0x40]
     74c:      	add	sp, sp, #0x80
     750:      	ret
     754:      	mov	w0, #0x10               ; =16
     758:      	bl	0x1774 <dyld_stub_binder+0x1774>
     75c:      	mov	x19, x0
     760:      	mov	w8, #0x33d              ; =829
     764:      	str	w8, [sp, #0x24]
     768:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xe0>
     76c:      	add	x0, x0, #0xab8
     770:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xe0>
     774:      	add	x1, x1, #0xb44
     778:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xe0>
     77c:      	add	x3, x3, #0xb6f
     780:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xe0>
     784:      	add	x4, x4, #0xbed
     788:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xe0>
     78c:      	add	x2, x2, #0xb6c
     790:      	add	x8, sp, #0x28
     794:      	add	x5, sp, #0x24
     798:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xe0>
     79c:      	add	x7, x7, #0xbef
     7a0:      	mov	x6, x2
     7a4:      	bl	0x818 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     7a8:      	mov	w21, #0x1               ; =1
     7ac:      	add	x1, sp, #0x28
     7b0:      	mov	x0, x19
     7b4:      	bl	0x16c0 <dyld_stub_binder+0x16c0>
     7b8:      	mov	w21, #0x0               ; =0
     7bc:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     7c0:      	ldr	x1, [x1, #0x18]
     7c4:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     7c8:      	ldr	x2, [x2, #0x8]
     7cc:      	mov	x0, x19
     7d0:      	bl	0x17a4 <dyld_stub_binder+0x17a4>
     7d4:      	brk	#0x1
     7d8:      	mov	x20, x0
     7dc:      	ldrsb	w8, [sp, #0x3f]
     7e0:      	tbz	w8, #0x1f, 0x7fc <_kernel+0x14c>
     7e4:      	ldr	x0, [sp, #0x28]
     7e8:      	ldr	x8, [sp, #0x38]
     7ec:      	and	x1, x8, #0x7fffffffffffffff
     7f0:      	bl	0x175c <dyld_stub_binder+0x175c>
     7f4:      	tbnz	w21, #0x0, 0x808 <_kernel+0x158>
     7f8:      	b	0x810 <_kernel+0x160>
     7fc:      	cbnz	w21, 0x808 <_kernel+0x158>
     800:      	b	0x810 <_kernel+0x160>
     804:      	mov	x20, x0
     808:      	mov	x0, x19
     80c:      	bl	0x1798 <dyld_stub_binder+0x1798>
     810:      	mov	x0, x20
     814:      	bl	0x1684 <dyld_stub_binder+0x1684>

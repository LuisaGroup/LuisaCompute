
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/swiglu-1024x4097-l1/object/tile_xir_w8_80773_1788919115512388_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x186c <ltmp0+0x186c>
       4:      	sub	sp, sp, #0x130
       8:      	stp	d15, d14, [sp, #0x90]
       c:      	stp	d13, d12, [sp, #0xa0]
      10:      	stp	d11, d10, [sp, #0xb0]
      14:      	stp	d9, d8, [sp, #0xc0]
      18:      	stp	x28, x27, [sp, #0xd0]
      1c:      	stp	x26, x25, [sp, #0xe0]
      20:      	stp	x24, x23, [sp, #0xf0]
      24:      	stp	x22, x21, [sp, #0x100]
      28:      	stp	x20, x19, [sp, #0x110]
      2c:      	stp	x29, x30, [sp, #0x120]
      30:      	mov	w8, #0x0                ; =0
      34:      	ldp	w10, w9, [x2, #0x2c]
      38:      	stp	w9, w10, [sp, #0x8]
      3c:      	mov	w12, #0x1001            ; =4097
      40:      	mov	w14, #0x42d00000        ; =1120927744
      44:      	dup.4s	v0, w14
      48:      	mov	w14, #-0x3d380000       ; =-1027080192
      4c:      	dup.4s	v1, w14
      50:      	mov	w14, #0xaa3b            ; =43579
      54:      	movk	w14, #0x3fb8, lsl #16
      58:      	movi.4s	v2, #0x4b, lsl #24
      5c:      	mvni.4s	v3, #0x80, lsl #24
      60:      	ldp	w19, w20, [x2]
      64:      	mov	w15, #0x7200            ; =29184
      68:      	movk	w15, #0xbf31, lsl #16
      6c:      	dup.4s	v4, w14
      70:      	mov	w14, #0xbe8e            ; =48782
      74:      	movk	w14, #0xb5bf, lsl #16
      78:      	adrp	x16, 0x0 <ltmp0>
      7c:      	ldr	q5, [x16]
      80:      	str	q5, [sp, #0x70]
      84:      	dup.4s	v6, w15
      88:      	dup.4s	v7, w14
      8c:      	mov	w17, #0x2bda            ; =11226
      90:      	movk	w17, #0x3950, lsl #16
      94:      	mov	w1, #0x96c9             ; =38601
      98:      	movk	w1, #0x3ab6, lsl #16
      9c:      	mov	w4, #0x88a6             ; =34982
      a0:      	movk	w4, #0x3c08, lsl #16
      a4:      	mov	w14, #0xaa7a            ; =43642
      a8:      	movk	w14, #0x3d2a, lsl #16
      ac:      	mov	w15, #0xaaab            ; =43691
      b0:      	movk	w15, #0x3e2a, lsl #16
      b4:      	movi.4s	v16, #0x3f, lsl #24
      b8:      	ldp	w21, w16, [x2, #0x8]
      bc:      	dup.4s	v5, w12
      c0:      	str	q5, [sp, #0x50]
      c4:      	mvni.4s	v5, #0x7f, msl #16
      c8:      	dup.4s	v18, w17
      cc:      	dup.4s	v19, w1
      d0:      	fneg.4s	v20, v5
      d4:      	mvni.4s	v5, #0x3f, msl #16
      d8:      	fneg.4s	v21, v5
      dc:      	adrp	x17, 0x0 <ltmp0>
      e0:      	ldr	q5, [x17]
      e4:      	str	q5, [sp, #0x60]
      e8:      	adrp	x17, 0x0 <ltmp0>
      ec:      	dup.4s	v23, w4
      f0:      	mov	w1, #-0x3d300000        ; =-1026555904
      f4:      	mov	w4, #0x42c80000         ; =1120403456
      f8:      	fmov.4s	v26, #1.00000000
      fc:      	b	0x138 <ltmp0+0x138>
     100:      	add	w9, w7, #0x1
     104:      	ldp	w11, w10, [sp, #0x8]
     108:      	cmp	w9, w10
     10c:      	cset	w9, eq
     110:      	csinc	w19, wzr, w7, eq
     114:      	cinc	w10, w6, eq
     118:      	cmp	w10, w11
     11c:      	cset	w11, eq
     120:      	ands	w9, w9, w11
     124:      	csel	w20, wzr, w10, ne
     128:      	add	w21, w5, w9
     12c:      	add	w8, w8, #0x1
     130:      	cmp	w8, w3
     134:      	b.eq	0x1830 <ltmp0+0x1830>
     138:      	mov	x5, x21
     13c:      	mov	x6, x20
     140:      	mov	x7, x19
     144:      	ubfiz	x19, x19, #5, #32
     148:      	cmp	x19, x16
     14c:      	csel	x20, x19, xzr, ls
     150:      	subs	x21, x16, x20
     154:      	cmp	x21, #0x20
     158:      	mov	w9, #0x20               ; =32
     15c:      	csel	x21, x21, x9, lo
     160:      	cmp	x16, x20
     164:      	ccmp	x19, x16, #0x2, hi
     168:      	csel	x19, x21, xzr, ls
     16c:      	dup.4s	v24, w14
     170:      	dup.4s	v25, w15
     174:      	cmp	x19, #0x20
     178:      	b.lo	0xee8 <ltmp0+0xee8>
     17c:      	mov	x20, #0x0               ; =0
     180:      	ldr	x19, [x2, #0x88]
     184:      	ldr	x24, [x0]
     188:      	ldr	x23, [x0, #0x10]
     18c:      	ldr	x22, [x0, #0x30]
     190:      	lsl	w21, w7, #5
     194:      	dup.4s	v5, w21
     198:      	ldp	q17, q27, [sp, #0x60]
     19c:      	orr.16b	v22, v5, v27
     1a0:      	orr.16b	v5, v5, v17
     1a4:      	ldr	q17, [sp, #0x50]
     1a8:      	umull2.2d	v30, v22, v17
     1ac:      	umull2.2d	v31, v5, v17
     1b0:      	umull.2d	v8, v22, v17
     1b4:      	umull.2d	v9, v5, v17
     1b8:      	dup.2d	v27, x24
     1bc:      	dup.2d	v5, x20
     1c0:      	add.2d	v22, v5, v30
     1c4:      	add.2d	v28, v5, v8
     1c8:      	add.2d	v29, v5, v31
     1cc:      	add.2d	v5, v5, v9
     1d0:      	shl.2d	v5, v5, #0x2
     1d4:      	shl.2d	v29, v29, #0x2
     1d8:      	shl.2d	v28, v28, #0x2
     1dc:      	shl.2d	v22, v22, #0x2
     1e0:      	add.2d	v22, v27, v22
     1e4:      	add.2d	v28, v27, v28
     1e8:      	add.2d	v29, v27, v29
     1ec:      	add.2d	v5, v27, v5
     1f0:      	mov.d	x24, v5[1]
     1f4:      	fmov	x25, d5
     1f8:      	mov.d	x26, v29[1]
     1fc:      	fmov	x27, d29
     200:      	mov.d	x28, v28[1]
     204:      	fmov	x30, d28
     208:      	mov.d	x13, v22[1]
     20c:      	ldr	s5, [x25]
     210:      	ld1.s	{ v5 }[1], [x24]
     214:      	fmov	x24, d22
     218:      	ld1.s	{ v5 }[2], [x27]
     21c:      	ld1.s	{ v5 }[3], [x26]
     220:      	ldr	s22, [x30]
     224:      	ld1.s	{ v22 }[1], [x28]
     228:      	ld1.s	{ v22 }[2], [x24]
     22c:      	ld1.s	{ v22 }[3], [x13]
     230:      	add	x13, x19, x20, lsl #5
     234:      	stp	q5, q22, [x13]
     238:      	add	x20, x20, #0x1
     23c:      	cmp	x20, x12
     240:      	b.ne	0x1bc <ltmp0+0x1bc>
     244:      	mov	x24, #0x0               ; =0
     248:      	mov	w9, #0x20               ; =32
     24c:      	movk	w9, #0x2, lsl #16
     250:      	add	x20, x19, x9
     254:      	dup.2d	v28, x23
     258:      	dup.2d	v5, x24
     25c:      	add.2d	v22, v5, v30
     260:      	add.2d	v29, v5, v8
     264:      	add.2d	v10, v5, v31
     268:      	add.2d	v5, v5, v9
     26c:      	shl.2d	v5, v5, #0x2
     270:      	shl.2d	v10, v10, #0x2
     274:      	shl.2d	v29, v29, #0x2
     278:      	shl.2d	v22, v22, #0x2
     27c:      	add.2d	v22, v28, v22
     280:      	add.2d	v29, v28, v29
     284:      	add.2d	v10, v28, v10
     288:      	add.2d	v5, v28, v5
     28c:      	mov.d	x13, v5[1]
     290:      	fmov	x23, d5
     294:      	mov.d	x25, v10[1]
     298:      	fmov	x26, d10
     29c:      	mov.d	x27, v29[1]
     2a0:      	fmov	x28, d29
     2a4:      	mov.d	x30, v22[1]
     2a8:      	ldr	s5, [x23]
     2ac:      	ld1.s	{ v5 }[1], [x13]
     2b0:      	fmov	x13, d22
     2b4:      	ld1.s	{ v5 }[2], [x26]
     2b8:      	ld1.s	{ v5 }[3], [x25]
     2bc:      	ldr	s22, [x28]
     2c0:      	ld1.s	{ v22 }[1], [x27]
     2c4:      	ld1.s	{ v22 }[2], [x13]
     2c8:      	ld1.s	{ v22 }[3], [x30]
     2cc:      	add	x13, x20, x24, lsl #5
     2d0:      	stp	q5, q22, [x13]
     2d4:      	add	x24, x24, #0x1
     2d8:      	cmp	x24, x12
     2dc:      	b.ne	0x258 <ltmp0+0x258>
     2e0:      	mov	x23, #0x0               ; =0
     2e4:      	lsl	x24, x23, #5
     2e8:      	add	x13, x19, x24
     2ec:      	ldp	q10, q29, [x13]
     2f0:      	fneg.4s	v5, v10
     2f4:      	fneg.4s	v22, v29
     2f8:      	fcmge.4s	v11, v0, v29
     2fc:      	fcmge.4s	v12, v0, v10
     300:      	fcmge.4s	v13, v29, v1
     304:      	fcmge.4s	v14, v10, v1
     308:      	and.16b	v12, v12, v14
     30c:      	and.16b	v11, v11, v13
     310:      	and.16b	v22, v11, v22
     314:      	and.16b	v5, v12, v5
     318:      	fmul.4s	v11, v5, v4
     31c:      	fmul.4s	v12, v22, v4
     320:      	mov.16b	v13, v3
     324:      	bsl.16b	v13, v2, v12
     328:      	mov.16b	v14, v3
     32c:      	bsl.16b	v14, v2, v11
     330:      	fadd.4s	v11, v11, v14
     334:      	fadd.4s	v12, v12, v13
     338:      	fsub.4s	v12, v12, v13
     33c:      	fsub.4s	v11, v11, v14
     340:      	fcvtzs.4s	v11, v11
     344:      	fcvtzs.4s	v12, v12
     348:      	scvtf.4s	v13, v12
     34c:      	scvtf.4s	v14, v11
     350:      	fmul.4s	v15, v13, v6
     354:      	fadd.4s	v22, v22, v15
     358:      	fmul.4s	v15, v14, v6
     35c:      	fadd.4s	v5, v5, v15
     360:      	fmul.4s	v13, v13, v7
     364:      	fmul.4s	v14, v14, v7
     368:      	fadd.4s	v5, v5, v14
     36c:      	fadd.4s	v22, v22, v13
     370:      	fmul.4s	v13, v22, v18
     374:      	fmul.4s	v14, v5, v18
     378:      	fadd.4s	v14, v14, v19
     37c:      	fadd.4s	v13, v13, v19
     380:      	fmul.4s	v13, v22, v13
     384:      	fmul.4s	v14, v5, v14
     388:      	fadd.4s	v14, v14, v23
     38c:      	fadd.4s	v13, v13, v23
     390:      	fmul.4s	v13, v22, v13
     394:      	fmul.4s	v14, v5, v14
     398:      	fadd.4s	v14, v14, v24
     39c:      	fadd.4s	v13, v13, v24
     3a0:      	fmul.4s	v13, v22, v13
     3a4:      	fmul.4s	v14, v5, v14
     3a8:      	fadd.4s	v14, v14, v25
     3ac:      	fadd.4s	v13, v13, v25
     3b0:      	fmul.4s	v13, v22, v13
     3b4:      	fmul.4s	v14, v5, v14
     3b8:      	fadd.4s	v14, v14, v16
     3bc:      	fadd.4s	v13, v13, v16
     3c0:      	fmul.4s	v15, v22, v22
     3c4:      	fmul.4s	v13, v15, v13
     3c8:      	fmul.4s	v15, v5, v5
     3cc:      	fmul.4s	v14, v15, v14
     3d0:      	fadd.4s	v5, v5, v14
     3d4:      	fadd.4s	v22, v22, v13
     3d8:      	fadd.4s	v22, v22, v26
     3dc:      	sshr.4s	v13, v11, #0x1
     3e0:      	shl.4s	v14, v13, #0x17
     3e4:      	add.4s	v14, v14, v26
     3e8:      	fadd.4s	v5, v5, v26
     3ec:      	fmul.4s	v5, v5, v14
     3f0:      	sshr.4s	v14, v12, #0x1
     3f4:      	sub.4s	v13, v11, v13
     3f8:      	shl.4s	v11, v14, #0x17
     3fc:      	add.4s	v11, v11, v26
     400:      	fmul.4s	v22, v22, v11
     404:      	sub.4s	v11, v12, v14
     408:      	shl.4s	v11, v11, #0x17
     40c:      	add.4s	v11, v11, v26
     410:      	fmul.4s	v22, v22, v11
     414:      	dup.2d	v11, x23
     418:      	shl.4s	v12, v13, #0x17
     41c:      	add.4s	v12, v12, v26
     420:      	fmul.4s	v5, v5, v12
     424:      	fcmgt.4s	v12, v29, v0
     428:      	fadd.4s	v22, v22, v26
     42c:      	bit.16b	v22, v26, v12
     430:      	fcmgt.4s	v12, v10, v0
     434:      	fadd.4s	v5, v5, v26
     438:      	bit.16b	v5, v26, v12
     43c:      	fcmgt.4s	v12, v1, v10
     440:      	bit.16b	v5, v20, v12
     444:      	fcmgt.4s	v12, v1, v29
     448:      	bit.16b	v22, v20, v12
     44c:      	fcmeq.4s	v12, v29, v29
     450:      	bif.16b	v22, v21, v12
     454:      	fcmeq.4s	v12, v10, v10
     458:      	bif.16b	v5, v21, v12
     45c:      	add.2d	v12, v11, v9
     460:      	fdiv.4s	v5, v10, v5
     464:      	fdiv.4s	v22, v29, v22
     468:      	add	x13, x20, x24
     46c:      	ldp	q29, q10, [x13]
     470:      	fmul.4s	v5, v29, v5
     474:      	shl.2d	v12, v12, #0x2
     478:      	dup.2d	v29, x22
     47c:      	add.2d	v12, v29, v12
     480:      	mov.d	x13, v12[1]
     484:      	fmov	x24, d12
     488:      	add.2d	v12, v11, v31
     48c:      	shl.2d	v12, v12, #0x2
     490:      	add.2d	v12, v29, v12
     494:      	mov.d	x25, v12[1]
     498:      	fmov	x26, d12
     49c:      	str	s5, [x24]
     4a0:      	st1.s	{ v5 }[1], [x13]
     4a4:      	st1.s	{ v5 }[2], [x26]
     4a8:      	fmul.4s	v22, v10, v22
     4ac:      	st1.s	{ v5 }[3], [x25]
     4b0:      	add.2d	v5, v11, v8
     4b4:      	shl.2d	v5, v5, #0x2
     4b8:      	add.2d	v5, v29, v5
     4bc:      	mov.d	x13, v5[1]
     4c0:      	fmov	x24, d5
     4c4:      	add.2d	v5, v11, v30
     4c8:      	shl.2d	v5, v5, #0x2
     4cc:      	add.2d	v5, v29, v5
     4d0:      	mov.d	x25, v5[1]
     4d4:      	fmov	x26, d5
     4d8:      	str	s22, [x24]
     4dc:      	st1.s	{ v22 }[1], [x13]
     4e0:      	st1.s	{ v22 }[2], [x26]
     4e4:      	st1.s	{ v22 }[3], [x25]
     4e8:      	add	x23, x23, #0x1
     4ec:      	cmp	x23, x12
     4f0:      	b.ne	0x2e4 <ltmp0+0x2e4>
     4f4:      	mov	x22, #0x0               ; =0
     4f8:      	orr	w13, w21, #0x8
     4fc:      	dup.4s	v5, w13
     500:      	ldp	q17, q30, [sp, #0x60]
     504:      	orr.16b	v22, v5, v30
     508:      	orr.16b	v5, v5, v17
     50c:      	ldr	q17, [sp, #0x50]
     510:      	umull2.2d	v30, v22, v17
     514:      	umull2.2d	v31, v5, v17
     518:      	umull.2d	v8, v22, v17
     51c:      	umull.2d	v9, v5, v17
     520:      	dup.2d	v5, x22
     524:      	add.2d	v22, v5, v30
     528:      	add.2d	v10, v5, v8
     52c:      	add.2d	v11, v5, v31
     530:      	add.2d	v5, v5, v9
     534:      	shl.2d	v5, v5, #0x2
     538:      	shl.2d	v11, v11, #0x2
     53c:      	shl.2d	v10, v10, #0x2
     540:      	shl.2d	v22, v22, #0x2
     544:      	add.2d	v22, v27, v22
     548:      	add.2d	v10, v27, v10
     54c:      	add.2d	v11, v27, v11
     550:      	add.2d	v5, v27, v5
     554:      	mov.d	x13, v5[1]
     558:      	fmov	x23, d5
     55c:      	mov.d	x24, v11[1]
     560:      	fmov	x25, d11
     564:      	mov.d	x26, v10[1]
     568:      	fmov	x27, d10
     56c:      	mov.d	x28, v22[1]
     570:      	ldr	s5, [x23]
     574:      	ld1.s	{ v5 }[1], [x13]
     578:      	fmov	x13, d22
     57c:      	ld1.s	{ v5 }[2], [x25]
     580:      	ld1.s	{ v5 }[3], [x24]
     584:      	ldr	s22, [x27]
     588:      	ld1.s	{ v22 }[1], [x26]
     58c:      	ld1.s	{ v22 }[2], [x13]
     590:      	ld1.s	{ v22 }[3], [x28]
     594:      	add	x13, x19, x22, lsl #5
     598:      	stp	q5, q22, [x13]
     59c:      	add	x22, x22, #0x1
     5a0:      	cmp	x22, x12
     5a4:      	b.ne	0x520 <ltmp0+0x520>
     5a8:      	mov	x22, #0x0               ; =0
     5ac:      	dup.2d	v5, x22
     5b0:      	add.2d	v22, v5, v30
     5b4:      	add.2d	v10, v5, v8
     5b8:      	add.2d	v11, v5, v31
     5bc:      	add.2d	v5, v5, v9
     5c0:      	shl.2d	v5, v5, #0x2
     5c4:      	shl.2d	v11, v11, #0x2
     5c8:      	shl.2d	v10, v10, #0x2
     5cc:      	shl.2d	v22, v22, #0x2
     5d0:      	add.2d	v22, v28, v22
     5d4:      	add.2d	v10, v28, v10
     5d8:      	add.2d	v11, v28, v11
     5dc:      	add.2d	v5, v28, v5
     5e0:      	mov.d	x13, v5[1]
     5e4:      	fmov	x23, d5
     5e8:      	mov.d	x24, v11[1]
     5ec:      	fmov	x25, d11
     5f0:      	mov.d	x26, v10[1]
     5f4:      	fmov	x27, d10
     5f8:      	mov.d	x28, v22[1]
     5fc:      	ldr	s5, [x23]
     600:      	ld1.s	{ v5 }[1], [x13]
     604:      	fmov	x13, d22
     608:      	ld1.s	{ v5 }[2], [x25]
     60c:      	ld1.s	{ v5 }[3], [x24]
     610:      	ldr	s22, [x27]
     614:      	ld1.s	{ v22 }[1], [x26]
     618:      	ld1.s	{ v22 }[2], [x13]
     61c:      	ld1.s	{ v22 }[3], [x28]
     620:      	add	x13, x20, x22, lsl #5
     624:      	stp	q5, q22, [x13]
     628:      	add	x22, x22, #0x1
     62c:      	cmp	x22, x12
     630:      	b.ne	0x5ac <ltmp0+0x5ac>
     634:      	mov	x22, #0x0               ; =0
     638:      	lsl	x23, x22, #5
     63c:      	add	x13, x19, x23
     640:      	ldp	q11, q10, [x13]
     644:      	fneg.4s	v5, v11
     648:      	fneg.4s	v22, v10
     64c:      	fcmge.4s	v12, v0, v10
     650:      	fcmge.4s	v13, v0, v11
     654:      	fcmge.4s	v14, v10, v1
     658:      	fcmge.4s	v15, v11, v1
     65c:      	and.16b	v13, v13, v15
     660:      	and.16b	v12, v12, v14
     664:      	and.16b	v22, v12, v22
     668:      	and.16b	v5, v13, v5
     66c:      	fmul.4s	v12, v5, v4
     670:      	fmul.4s	v13, v22, v4
     674:      	mov.16b	v14, v3
     678:      	bsl.16b	v14, v2, v13
     67c:      	mov.16b	v15, v3
     680:      	bsl.16b	v15, v2, v12
     684:      	fadd.4s	v12, v12, v15
     688:      	fadd.4s	v13, v13, v14
     68c:      	fsub.4s	v13, v13, v14
     690:      	fsub.4s	v12, v12, v15
     694:      	fcvtzs.4s	v12, v12
     698:      	fcvtzs.4s	v13, v13
     69c:      	scvtf.4s	v14, v13
     6a0:      	scvtf.4s	v15, v12
     6a4:      	fmul.4s	v17, v14, v6
     6a8:      	fadd.4s	v17, v22, v17
     6ac:      	fmul.4s	v22, v15, v6
     6b0:      	fadd.4s	v5, v5, v22
     6b4:      	fmul.4s	v22, v14, v7
     6b8:      	fmul.4s	v14, v15, v7
     6bc:      	fadd.4s	v5, v5, v14
     6c0:      	fadd.4s	v17, v17, v22
     6c4:      	fmul.4s	v22, v17, v18
     6c8:      	fmul.4s	v14, v5, v18
     6cc:      	fadd.4s	v14, v14, v19
     6d0:      	fadd.4s	v22, v22, v19
     6d4:      	fmul.4s	v22, v17, v22
     6d8:      	fmul.4s	v14, v5, v14
     6dc:      	fadd.4s	v14, v14, v23
     6e0:      	fadd.4s	v22, v22, v23
     6e4:      	fmul.4s	v22, v17, v22
     6e8:      	fmul.4s	v14, v5, v14
     6ec:      	fadd.4s	v14, v14, v24
     6f0:      	fadd.4s	v22, v22, v24
     6f4:      	fmul.4s	v22, v17, v22
     6f8:      	fmul.4s	v14, v5, v14
     6fc:      	fadd.4s	v14, v14, v25
     700:      	fadd.4s	v22, v22, v25
     704:      	fmul.4s	v22, v17, v22
     708:      	fmul.4s	v14, v5, v14
     70c:      	fadd.4s	v14, v14, v16
     710:      	fadd.4s	v22, v22, v16
     714:      	fmul.4s	v15, v17, v17
     718:      	fmul.4s	v22, v15, v22
     71c:      	fmul.4s	v15, v5, v5
     720:      	fmul.4s	v14, v15, v14
     724:      	fadd.4s	v5, v5, v14
     728:      	fadd.4s	v17, v17, v22
     72c:      	sshr.4s	v22, v13, #0x1
     730:      	sshr.4s	v14, v12, #0x1
     734:      	fadd.4s	v5, v5, v26
     738:      	shl.4s	v15, v14, #0x17
     73c:      	add.4s	v15, v15, v26
     740:      	fmul.4s	v5, v5, v15
     744:      	shl.4s	v15, v22, #0x17
     748:      	add.4s	v15, v15, v26
     74c:      	fadd.4s	v17, v17, v26
     750:      	fmul.4s	v17, v17, v15
     754:      	sub.4s	v14, v12, v14
     758:      	sub.4s	v22, v13, v22
     75c:      	shl.4s	v22, v22, #0x17
     760:      	add.4s	v22, v22, v26
     764:      	fmul.4s	v17, v17, v22
     768:      	dup.2d	v12, x22
     76c:      	shl.4s	v22, v14, #0x17
     770:      	add.4s	v22, v22, v26
     774:      	fmul.4s	v5, v5, v22
     778:      	fcmgt.4s	v22, v10, v0
     77c:      	fadd.4s	v17, v17, v26
     780:      	bit.16b	v17, v26, v22
     784:      	fcmgt.4s	v22, v11, v0
     788:      	fadd.4s	v5, v5, v26
     78c:      	bit.16b	v5, v26, v22
     790:      	fcmgt.4s	v22, v1, v11
     794:      	bit.16b	v5, v20, v22
     798:      	fcmgt.4s	v22, v1, v10
     79c:      	bit.16b	v17, v20, v22
     7a0:      	fcmeq.4s	v22, v10, v10
     7a4:      	bif.16b	v17, v21, v22
     7a8:      	fcmeq.4s	v22, v11, v11
     7ac:      	bif.16b	v5, v21, v22
     7b0:      	fdiv.4s	v5, v11, v5
     7b4:      	fdiv.4s	v17, v10, v17
     7b8:      	add	x13, x20, x23
     7bc:      	ldp	q22, q10, [x13]
     7c0:      	fmul.4s	v5, v22, v5
     7c4:      	add.2d	v22, v12, v9
     7c8:      	shl.2d	v22, v22, #0x2
     7cc:      	add.2d	v22, v29, v22
     7d0:      	mov.d	x13, v22[1]
     7d4:      	fmov	x23, d22
     7d8:      	add.2d	v22, v12, v31
     7dc:      	shl.2d	v22, v22, #0x2
     7e0:      	add.2d	v22, v29, v22
     7e4:      	mov.d	x24, v22[1]
     7e8:      	fmov	x25, d22
     7ec:      	str	s5, [x23]
     7f0:      	st1.s	{ v5 }[1], [x13]
     7f4:      	st1.s	{ v5 }[2], [x25]
     7f8:      	fmul.4s	v17, v10, v17
     7fc:      	st1.s	{ v5 }[3], [x24]
     800:      	add.2d	v5, v12, v8
     804:      	shl.2d	v5, v5, #0x2
     808:      	add.2d	v5, v29, v5
     80c:      	mov.d	x13, v5[1]
     810:      	fmov	x23, d5
     814:      	add.2d	v5, v12, v30
     818:      	shl.2d	v5, v5, #0x2
     81c:      	add.2d	v5, v29, v5
     820:      	mov.d	x24, v5[1]
     824:      	fmov	x25, d5
     828:      	str	s17, [x23]
     82c:      	st1.s	{ v17 }[1], [x13]
     830:      	st1.s	{ v17 }[2], [x25]
     834:      	st1.s	{ v17 }[3], [x24]
     838:      	add	x22, x22, #0x1
     83c:      	cmp	x22, x12
     840:      	b.ne	0x638 <ltmp0+0x638>
     844:      	mov	x22, #0x0               ; =0
     848:      	orr	w13, w21, #0x10
     84c:      	dup.4s	v5, w13
     850:      	ldp	q22, q17, [sp, #0x60]
     854:      	orr.16b	v17, v5, v17
     858:      	orr.16b	v5, v5, v22
     85c:      	ldr	q22, [sp, #0x50]
     860:      	umull2.2d	v30, v17, v22
     864:      	umull2.2d	v31, v5, v22
     868:      	umull.2d	v8, v17, v22
     86c:      	umull.2d	v9, v5, v22
     870:      	dup.2d	v5, x22
     874:      	add.2d	v17, v5, v30
     878:      	add.2d	v22, v5, v8
     87c:      	add.2d	v10, v5, v31
     880:      	add.2d	v5, v5, v9
     884:      	shl.2d	v5, v5, #0x2
     888:      	shl.2d	v10, v10, #0x2
     88c:      	shl.2d	v22, v22, #0x2
     890:      	shl.2d	v17, v17, #0x2
     894:      	add.2d	v17, v27, v17
     898:      	add.2d	v22, v27, v22
     89c:      	add.2d	v10, v27, v10
     8a0:      	add.2d	v5, v27, v5
     8a4:      	mov.d	x13, v5[1]
     8a8:      	fmov	x23, d5
     8ac:      	mov.d	x24, v10[1]
     8b0:      	fmov	x25, d10
     8b4:      	mov.d	x26, v22[1]
     8b8:      	fmov	x27, d22
     8bc:      	mov.d	x28, v17[1]
     8c0:      	ldr	s5, [x23]
     8c4:      	ld1.s	{ v5 }[1], [x13]
     8c8:      	fmov	x13, d17
     8cc:      	ld1.s	{ v5 }[2], [x25]
     8d0:      	ld1.s	{ v5 }[3], [x24]
     8d4:      	ldr	s17, [x27]
     8d8:      	ld1.s	{ v17 }[1], [x26]
     8dc:      	ld1.s	{ v17 }[2], [x13]
     8e0:      	ld1.s	{ v17 }[3], [x28]
     8e4:      	add	x13, x19, x22, lsl #5
     8e8:      	stp	q5, q17, [x13]
     8ec:      	add	x22, x22, #0x1
     8f0:      	cmp	x22, x12
     8f4:      	b.ne	0x870 <ltmp0+0x870>
     8f8:      	mov	x22, #0x0               ; =0
     8fc:      	dup.2d	v5, x22
     900:      	add.2d	v17, v5, v30
     904:      	add.2d	v22, v5, v8
     908:      	add.2d	v10, v5, v31
     90c:      	add.2d	v5, v5, v9
     910:      	shl.2d	v5, v5, #0x2
     914:      	shl.2d	v10, v10, #0x2
     918:      	shl.2d	v22, v22, #0x2
     91c:      	shl.2d	v17, v17, #0x2
     920:      	add.2d	v17, v28, v17
     924:      	add.2d	v22, v28, v22
     928:      	add.2d	v10, v28, v10
     92c:      	add.2d	v5, v28, v5
     930:      	mov.d	x13, v5[1]
     934:      	fmov	x23, d5
     938:      	mov.d	x24, v10[1]
     93c:      	fmov	x25, d10
     940:      	mov.d	x26, v22[1]
     944:      	fmov	x27, d22
     948:      	mov.d	x28, v17[1]
     94c:      	ldr	s5, [x23]
     950:      	ld1.s	{ v5 }[1], [x13]
     954:      	fmov	x13, d17
     958:      	ld1.s	{ v5 }[2], [x25]
     95c:      	ld1.s	{ v5 }[3], [x24]
     960:      	ldr	s17, [x27]
     964:      	ld1.s	{ v17 }[1], [x26]
     968:      	ld1.s	{ v17 }[2], [x13]
     96c:      	ld1.s	{ v17 }[3], [x28]
     970:      	add	x13, x20, x22, lsl #5
     974:      	stp	q5, q17, [x13]
     978:      	add	x22, x22, #0x1
     97c:      	cmp	x22, x12
     980:      	b.ne	0x8fc <ltmp0+0x8fc>
     984:      	mov	x22, #0x0               ; =0
     988:      	lsl	x23, x22, #5
     98c:      	add	x13, x19, x23
     990:      	ldp	q11, q10, [x13]
     994:      	fneg.4s	v5, v11
     998:      	fneg.4s	v17, v10
     99c:      	fcmge.4s	v22, v0, v10
     9a0:      	fcmge.4s	v12, v0, v11
     9a4:      	fcmge.4s	v13, v10, v1
     9a8:      	fcmge.4s	v14, v11, v1
     9ac:      	and.16b	v12, v12, v14
     9b0:      	and.16b	v22, v22, v13
     9b4:      	and.16b	v17, v22, v17
     9b8:      	and.16b	v5, v12, v5
     9bc:      	fmul.4s	v22, v5, v4
     9c0:      	fmul.4s	v12, v17, v4
     9c4:      	mov.16b	v13, v3
     9c8:      	bsl.16b	v13, v2, v12
     9cc:      	mov.16b	v14, v3
     9d0:      	bsl.16b	v14, v2, v22
     9d4:      	fadd.4s	v22, v22, v14
     9d8:      	fadd.4s	v12, v12, v13
     9dc:      	fsub.4s	v12, v12, v13
     9e0:      	fsub.4s	v22, v22, v14
     9e4:      	fcvtzs.4s	v22, v22
     9e8:      	fcvtzs.4s	v12, v12
     9ec:      	scvtf.4s	v13, v12
     9f0:      	scvtf.4s	v14, v22
     9f4:      	fmul.4s	v15, v13, v6
     9f8:      	fadd.4s	v17, v17, v15
     9fc:      	fmul.4s	v15, v14, v6
     a00:      	fadd.4s	v5, v5, v15
     a04:      	fmul.4s	v13, v13, v7
     a08:      	fmul.4s	v14, v14, v7
     a0c:      	fadd.4s	v5, v5, v14
     a10:      	fadd.4s	v17, v17, v13
     a14:      	fmul.4s	v13, v17, v18
     a18:      	fmul.4s	v14, v5, v18
     a1c:      	fadd.4s	v14, v14, v19
     a20:      	fadd.4s	v13, v13, v19
     a24:      	fmul.4s	v13, v17, v13
     a28:      	fmul.4s	v14, v5, v14
     a2c:      	fadd.4s	v14, v14, v23
     a30:      	fadd.4s	v13, v13, v23
     a34:      	fmul.4s	v13, v17, v13
     a38:      	fmul.4s	v14, v5, v14
     a3c:      	fadd.4s	v14, v14, v24
     a40:      	fadd.4s	v13, v13, v24
     a44:      	fmul.4s	v13, v17, v13
     a48:      	fmul.4s	v14, v5, v14
     a4c:      	fadd.4s	v14, v14, v25
     a50:      	fadd.4s	v13, v13, v25
     a54:      	fmul.4s	v13, v17, v13
     a58:      	fmul.4s	v14, v5, v14
     a5c:      	fadd.4s	v14, v14, v16
     a60:      	fadd.4s	v13, v13, v16
     a64:      	fmul.4s	v15, v17, v17
     a68:      	fmul.4s	v13, v15, v13
     a6c:      	fmul.4s	v15, v5, v5
     a70:      	fmul.4s	v14, v15, v14
     a74:      	fadd.4s	v5, v5, v14
     a78:      	fadd.4s	v17, v17, v13
     a7c:      	sshr.4s	v13, v12, #0x1
     a80:      	sshr.4s	v14, v22, #0x1
     a84:      	fadd.4s	v5, v5, v26
     a88:      	shl.4s	v15, v14, #0x17
     a8c:      	add.4s	v15, v15, v26
     a90:      	fmul.4s	v5, v5, v15
     a94:      	shl.4s	v15, v13, #0x17
     a98:      	add.4s	v15, v15, v26
     a9c:      	fadd.4s	v17, v17, v26
     aa0:      	fmul.4s	v17, v17, v15
     aa4:      	sub.4s	v22, v22, v14
     aa8:      	sub.4s	v12, v12, v13
     aac:      	shl.4s	v12, v12, #0x17
     ab0:      	add.4s	v12, v12, v26
     ab4:      	fmul.4s	v17, v17, v12
     ab8:      	dup.2d	v12, x22
     abc:      	shl.4s	v22, v22, #0x17
     ac0:      	add.4s	v22, v22, v26
     ac4:      	fmul.4s	v5, v5, v22
     ac8:      	fcmgt.4s	v22, v10, v0
     acc:      	fadd.4s	v17, v17, v26
     ad0:      	bit.16b	v17, v26, v22
     ad4:      	fcmgt.4s	v22, v11, v0
     ad8:      	fadd.4s	v5, v5, v26
     adc:      	bit.16b	v5, v26, v22
     ae0:      	fcmgt.4s	v22, v1, v11
     ae4:      	bit.16b	v5, v20, v22
     ae8:      	fcmgt.4s	v22, v1, v10
     aec:      	bit.16b	v17, v20, v22
     af0:      	fcmeq.4s	v22, v10, v10
     af4:      	bif.16b	v17, v21, v22
     af8:      	fcmeq.4s	v22, v11, v11
     afc:      	bif.16b	v5, v21, v22
     b00:      	fdiv.4s	v5, v11, v5
     b04:      	fdiv.4s	v17, v10, v17
     b08:      	add	x13, x20, x23
     b0c:      	ldp	q22, q10, [x13]
     b10:      	fmul.4s	v5, v22, v5
     b14:      	add.2d	v22, v12, v9
     b18:      	shl.2d	v22, v22, #0x2
     b1c:      	add.2d	v22, v29, v22
     b20:      	mov.d	x13, v22[1]
     b24:      	fmov	x23, d22
     b28:      	add.2d	v22, v12, v31
     b2c:      	shl.2d	v22, v22, #0x2
     b30:      	add.2d	v22, v29, v22
     b34:      	mov.d	x24, v22[1]
     b38:      	fmov	x25, d22
     b3c:      	str	s5, [x23]
     b40:      	st1.s	{ v5 }[1], [x13]
     b44:      	st1.s	{ v5 }[2], [x25]
     b48:      	fmul.4s	v17, v10, v17
     b4c:      	st1.s	{ v5 }[3], [x24]
     b50:      	add.2d	v5, v12, v8
     b54:      	shl.2d	v5, v5, #0x2
     b58:      	add.2d	v5, v29, v5
     b5c:      	mov.d	x13, v5[1]
     b60:      	fmov	x23, d5
     b64:      	add.2d	v5, v12, v30
     b68:      	shl.2d	v5, v5, #0x2
     b6c:      	add.2d	v5, v29, v5
     b70:      	mov.d	x24, v5[1]
     b74:      	fmov	x25, d5
     b78:      	str	s17, [x23]
     b7c:      	st1.s	{ v17 }[1], [x13]
     b80:      	st1.s	{ v17 }[2], [x25]
     b84:      	st1.s	{ v17 }[3], [x24]
     b88:      	add	x22, x22, #0x1
     b8c:      	cmp	x22, x12
     b90:      	b.ne	0x988 <ltmp0+0x988>
     b94:      	mov	x22, #0x0               ; =0
     b98:      	orr	w13, w21, #0x18
     b9c:      	dup.4s	v5, w13
     ba0:      	ldp	q22, q17, [sp, #0x60]
     ba4:      	orr.16b	v17, v5, v17
     ba8:      	orr.16b	v5, v5, v22
     bac:      	ldr	q22, [sp, #0x50]
     bb0:      	umull2.2d	v30, v17, v22
     bb4:      	umull2.2d	v31, v5, v22
     bb8:      	umull.2d	v8, v17, v22
     bbc:      	umull.2d	v9, v5, v22
     bc0:      	dup.2d	v5, x22
     bc4:      	add.2d	v17, v5, v30
     bc8:      	add.2d	v22, v5, v8
     bcc:      	add.2d	v10, v5, v31
     bd0:      	add.2d	v5, v5, v9
     bd4:      	shl.2d	v5, v5, #0x2
     bd8:      	shl.2d	v10, v10, #0x2
     bdc:      	shl.2d	v22, v22, #0x2
     be0:      	shl.2d	v17, v17, #0x2
     be4:      	add.2d	v17, v27, v17
     be8:      	add.2d	v22, v27, v22
     bec:      	add.2d	v10, v27, v10
     bf0:      	add.2d	v5, v27, v5
     bf4:      	mov.d	x13, v5[1]
     bf8:      	fmov	x21, d5
     bfc:      	mov.d	x23, v10[1]
     c00:      	fmov	x24, d10
     c04:      	mov.d	x25, v22[1]
     c08:      	fmov	x26, d22
     c0c:      	mov.d	x27, v17[1]
     c10:      	ldr	s5, [x21]
     c14:      	ld1.s	{ v5 }[1], [x13]
     c18:      	fmov	x13, d17
     c1c:      	ld1.s	{ v5 }[2], [x24]
     c20:      	ld1.s	{ v5 }[3], [x23]
     c24:      	ldr	s17, [x26]
     c28:      	ld1.s	{ v17 }[1], [x25]
     c2c:      	ld1.s	{ v17 }[2], [x13]
     c30:      	ld1.s	{ v17 }[3], [x27]
     c34:      	add	x13, x19, x22, lsl #5
     c38:      	stp	q5, q17, [x13]
     c3c:      	add	x22, x22, #0x1
     c40:      	cmp	x22, x12
     c44:      	b.ne	0xbc0 <ltmp0+0xbc0>
     c48:      	mov	x21, #0x0               ; =0
     c4c:      	dup.2d	v5, x21
     c50:      	add.2d	v17, v5, v30
     c54:      	add.2d	v22, v5, v8
     c58:      	add.2d	v27, v5, v31
     c5c:      	add.2d	v5, v5, v9
     c60:      	shl.2d	v5, v5, #0x2
     c64:      	shl.2d	v27, v27, #0x2
     c68:      	shl.2d	v22, v22, #0x2
     c6c:      	shl.2d	v17, v17, #0x2
     c70:      	add.2d	v17, v28, v17
     c74:      	add.2d	v22, v28, v22
     c78:      	add.2d	v27, v28, v27
     c7c:      	add.2d	v5, v28, v5
     c80:      	mov.d	x13, v5[1]
     c84:      	fmov	x22, d5
     c88:      	mov.d	x23, v27[1]
     c8c:      	fmov	x24, d27
     c90:      	mov.d	x25, v22[1]
     c94:      	fmov	x26, d22
     c98:      	mov.d	x27, v17[1]
     c9c:      	ldr	s5, [x22]
     ca0:      	ld1.s	{ v5 }[1], [x13]
     ca4:      	fmov	x13, d17
     ca8:      	ld1.s	{ v5 }[2], [x24]
     cac:      	ld1.s	{ v5 }[3], [x23]
     cb0:      	ldr	s17, [x26]
     cb4:      	ld1.s	{ v17 }[1], [x25]
     cb8:      	ld1.s	{ v17 }[2], [x13]
     cbc:      	ld1.s	{ v17 }[3], [x27]
     cc0:      	add	x13, x20, x21, lsl #5
     cc4:      	stp	q5, q17, [x13]
     cc8:      	add	x21, x21, #0x1
     ccc:      	cmp	x21, x12
     cd0:      	b.ne	0xc4c <ltmp0+0xc4c>
     cd4:      	mov	x21, #0x0               ; =0
     cd8:      	lsl	x22, x21, #5
     cdc:      	add	x13, x19, x22
     ce0:      	ldp	q28, q27, [x13]
     ce4:      	fneg.4s	v5, v28
     ce8:      	fneg.4s	v17, v27
     cec:      	fcmge.4s	v22, v0, v27
     cf0:      	fcmge.4s	v10, v0, v28
     cf4:      	fcmge.4s	v11, v27, v1
     cf8:      	fcmge.4s	v12, v28, v1
     cfc:      	and.16b	v10, v10, v12
     d00:      	and.16b	v22, v22, v11
     d04:      	and.16b	v17, v22, v17
     d08:      	and.16b	v5, v10, v5
     d0c:      	fmul.4s	v22, v5, v4
     d10:      	fmul.4s	v10, v17, v4
     d14:      	mov.16b	v11, v3
     d18:      	bsl.16b	v11, v2, v10
     d1c:      	mov.16b	v12, v3
     d20:      	bsl.16b	v12, v2, v22
     d24:      	fadd.4s	v22, v22, v12
     d28:      	fadd.4s	v10, v10, v11
     d2c:      	fsub.4s	v10, v10, v11
     d30:      	fsub.4s	v22, v22, v12
     d34:      	fcvtzs.4s	v22, v22
     d38:      	fcvtzs.4s	v10, v10
     d3c:      	scvtf.4s	v11, v10
     d40:      	scvtf.4s	v12, v22
     d44:      	fmul.4s	v13, v11, v6
     d48:      	fadd.4s	v17, v17, v13
     d4c:      	fmul.4s	v13, v12, v6
     d50:      	fadd.4s	v5, v5, v13
     d54:      	fmul.4s	v11, v11, v7
     d58:      	fmul.4s	v12, v12, v7
     d5c:      	fadd.4s	v5, v5, v12
     d60:      	fadd.4s	v17, v17, v11
     d64:      	fmul.4s	v11, v17, v18
     d68:      	fmul.4s	v12, v5, v18
     d6c:      	fadd.4s	v12, v12, v19
     d70:      	fadd.4s	v11, v11, v19
     d74:      	fmul.4s	v11, v17, v11
     d78:      	fmul.4s	v12, v5, v12
     d7c:      	fadd.4s	v12, v12, v23
     d80:      	fadd.4s	v11, v11, v23
     d84:      	fmul.4s	v11, v17, v11
     d88:      	fmul.4s	v12, v5, v12
     d8c:      	fadd.4s	v12, v12, v24
     d90:      	fadd.4s	v11, v11, v24
     d94:      	fmul.4s	v11, v17, v11
     d98:      	fmul.4s	v12, v5, v12
     d9c:      	fadd.4s	v12, v12, v25
     da0:      	fadd.4s	v11, v11, v25
     da4:      	fmul.4s	v11, v17, v11
     da8:      	fmul.4s	v12, v5, v12
     dac:      	fadd.4s	v12, v12, v16
     db0:      	fadd.4s	v11, v11, v16
     db4:      	fmul.4s	v13, v17, v17
     db8:      	fmul.4s	v11, v13, v11
     dbc:      	fmul.4s	v13, v5, v5
     dc0:      	fmul.4s	v12, v13, v12
     dc4:      	fadd.4s	v5, v5, v12
     dc8:      	fadd.4s	v17, v17, v11
     dcc:      	sshr.4s	v11, v10, #0x1
     dd0:      	sshr.4s	v12, v22, #0x1
     dd4:      	fadd.4s	v5, v5, v26
     dd8:      	shl.4s	v13, v12, #0x17
     ddc:      	add.4s	v13, v13, v26
     de0:      	fmul.4s	v5, v5, v13
     de4:      	shl.4s	v13, v11, #0x17
     de8:      	add.4s	v13, v13, v26
     dec:      	fadd.4s	v17, v17, v26
     df0:      	fmul.4s	v17, v17, v13
     df4:      	sub.4s	v22, v22, v12
     df8:      	sub.4s	v10, v10, v11
     dfc:      	shl.4s	v10, v10, #0x17
     e00:      	add.4s	v10, v10, v26
     e04:      	fmul.4s	v17, v17, v10
     e08:      	dup.2d	v10, x21
     e0c:      	shl.4s	v22, v22, #0x17
     e10:      	add.4s	v22, v22, v26
     e14:      	fmul.4s	v5, v5, v22
     e18:      	fcmgt.4s	v22, v27, v0
     e1c:      	fadd.4s	v17, v17, v26
     e20:      	bit.16b	v17, v26, v22
     e24:      	fcmgt.4s	v22, v28, v0
     e28:      	fadd.4s	v5, v5, v26
     e2c:      	bit.16b	v5, v26, v22
     e30:      	fcmgt.4s	v22, v1, v28
     e34:      	bit.16b	v5, v20, v22
     e38:      	fcmgt.4s	v22, v1, v27
     e3c:      	bit.16b	v17, v20, v22
     e40:      	fcmeq.4s	v22, v27, v27
     e44:      	bif.16b	v17, v21, v22
     e48:      	fcmeq.4s	v22, v28, v28
     e4c:      	bif.16b	v5, v21, v22
     e50:      	fdiv.4s	v5, v28, v5
     e54:      	fdiv.4s	v17, v27, v17
     e58:      	add	x13, x20, x22
     e5c:      	ldp	q22, q27, [x13]
     e60:      	fmul.4s	v5, v22, v5
     e64:      	add.2d	v22, v10, v9
     e68:      	shl.2d	v22, v22, #0x2
     e6c:      	add.2d	v22, v29, v22
     e70:      	mov.d	x13, v22[1]
     e74:      	fmov	x22, d22
     e78:      	add.2d	v22, v10, v31
     e7c:      	shl.2d	v22, v22, #0x2
     e80:      	add.2d	v22, v29, v22
     e84:      	mov.d	x23, v22[1]
     e88:      	fmov	x24, d22
     e8c:      	str	s5, [x22]
     e90:      	st1.s	{ v5 }[1], [x13]
     e94:      	st1.s	{ v5 }[2], [x24]
     e98:      	fmul.4s	v17, v27, v17
     e9c:      	st1.s	{ v5 }[3], [x23]
     ea0:      	add.2d	v5, v10, v8
     ea4:      	shl.2d	v5, v5, #0x2
     ea8:      	add.2d	v5, v29, v5
     eac:      	mov.d	x13, v5[1]
     eb0:      	fmov	x22, d5
     eb4:      	add.2d	v5, v10, v30
     eb8:      	shl.2d	v5, v5, #0x2
     ebc:      	add.2d	v5, v29, v5
     ec0:      	mov.d	x23, v5[1]
     ec4:      	fmov	x24, d5
     ec8:      	str	s17, [x22]
     ecc:      	st1.s	{ v17 }[1], [x13]
     ed0:      	st1.s	{ v17 }[2], [x24]
     ed4:      	st1.s	{ v17 }[3], [x23]
     ed8:      	add	x21, x21, #0x1
     edc:      	cmp	x21, x12
     ee0:      	b.ne	0xcd8 <ltmp0+0xcd8>
     ee4:      	b	0x100 <ltmp0+0x100>
     ee8:      	lsr	x21, x19, #3
     eec:      	cmp	x19, #0x8
     ef0:      	b.lo	0x1280 <ltmp0+0x1280>
     ef4:      	mov	w20, #0x0               ; =0
     ef8:      	ldr	x22, [x2, #0x88]
     efc:      	ldr	x23, [x0]
     f00:      	ldr	x24, [x0, #0x10]
     f04:      	ldr	x25, [x0, #0x30]
     f08:      	lsl	w26, w7, #5
     f0c:      	mov	w9, #0x20               ; =32
     f10:      	movk	w9, #0x2, lsl #16
     f14:      	add	x27, x22, x9
     f18:      	mov	x28, #0x0               ; =0
     f1c:      	add	w13, w26, w20, lsl #3
     f20:      	dup.4s	v5, w13
     f24:      	ldp	q22, q17, [sp, #0x60]
     f28:      	orr.16b	v17, v5, v17
     f2c:      	orr.16b	v5, v5, v22
     f30:      	ldr	q22, [sp, #0x50]
     f34:      	umull2.2d	v27, v17, v22
     f38:      	umull2.2d	v28, v5, v22
     f3c:      	umull.2d	v29, v17, v22
     f40:      	umull.2d	v30, v5, v22
     f44:      	dup.2d	v5, x28
     f48:      	add.2d	v17, v5, v27
     f4c:      	add.2d	v22, v5, v29
     f50:      	add.2d	v31, v5, v28
     f54:      	add.2d	v5, v5, v30
     f58:      	shl.2d	v5, v5, #0x2
     f5c:      	shl.2d	v31, v31, #0x2
     f60:      	shl.2d	v22, v22, #0x2
     f64:      	shl.2d	v17, v17, #0x2
     f68:      	dup.2d	v8, x23
     f6c:      	add.2d	v17, v8, v17
     f70:      	add.2d	v22, v8, v22
     f74:      	add.2d	v31, v8, v31
     f78:      	add.2d	v5, v8, v5
     f7c:      	mov.d	x13, v5[1]
     f80:      	fmov	x30, d5
     f84:      	mov.d	x11, v31[1]
     f88:      	fmov	x14, d31
     f8c:      	mov.d	x15, v22[1]
     f90:      	fmov	x9, d22
     f94:      	mov.d	x10, v17[1]
     f98:      	ldr	s5, [x30]
     f9c:      	ld1.s	{ v5 }[1], [x13]
     fa0:      	fmov	x13, d17
     fa4:      	ld1.s	{ v5 }[2], [x14]
     fa8:      	ld1.s	{ v5 }[3], [x11]
     fac:      	ldr	s17, [x9]
     fb0:      	ld1.s	{ v17 }[1], [x15]
     fb4:      	ld1.s	{ v17 }[2], [x13]
     fb8:      	ld1.s	{ v17 }[3], [x10]
     fbc:      	add	x9, x22, x28, lsl #5
     fc0:      	stp	q5, q17, [x9]
     fc4:      	add	x28, x28, #0x1
     fc8:      	cmp	x28, x12
     fcc:      	b.ne	0xf44 <ltmp0+0xf44>
     fd0:      	mov	x28, #0x0               ; =0
     fd4:      	dup.2d	v5, x28
     fd8:      	add.2d	v17, v5, v27
     fdc:      	add.2d	v22, v5, v29
     fe0:      	add.2d	v31, v5, v28
     fe4:      	add.2d	v5, v5, v30
     fe8:      	shl.2d	v5, v5, #0x2
     fec:      	shl.2d	v31, v31, #0x2
     ff0:      	shl.2d	v22, v22, #0x2
     ff4:      	shl.2d	v17, v17, #0x2
     ff8:      	dup.2d	v8, x24
     ffc:      	add.2d	v17, v8, v17
    1000:      	add.2d	v22, v8, v22
    1004:      	add.2d	v31, v8, v31
    1008:      	add.2d	v5, v8, v5
    100c:      	mov.d	x9, v5[1]
    1010:      	fmov	x10, d5
    1014:      	mov.d	x11, v31[1]
    1018:      	fmov	x13, d31
    101c:      	mov.d	x14, v22[1]
    1020:      	fmov	x15, d22
    1024:      	mov.d	x30, v17[1]
    1028:      	ldr	s5, [x10]
    102c:      	ld1.s	{ v5 }[1], [x9]
    1030:      	fmov	x9, d17
    1034:      	ld1.s	{ v5 }[2], [x13]
    1038:      	ld1.s	{ v5 }[3], [x11]
    103c:      	ldr	s17, [x15]
    1040:      	ld1.s	{ v17 }[1], [x14]
    1044:      	ld1.s	{ v17 }[2], [x9]
    1048:      	ld1.s	{ v17 }[3], [x30]
    104c:      	add	x9, x27, x28, lsl #5
    1050:      	stp	q5, q17, [x9]
    1054:      	add	x28, x28, #0x1
    1058:      	cmp	x28, x12
    105c:      	b.ne	0xfd4 <ltmp0+0xfd4>
    1060:      	mov	x28, #0x0               ; =0
    1064:      	lsl	x30, x28, #5
    1068:      	add	x9, x22, x30
    106c:      	ldp	q8, q31, [x9]
    1070:      	fneg.4s	v5, v8
    1074:      	fneg.4s	v17, v31
    1078:      	fcmge.4s	v22, v0, v31
    107c:      	fcmge.4s	v9, v0, v8
    1080:      	fcmge.4s	v10, v31, v1
    1084:      	fcmge.4s	v11, v8, v1
    1088:      	and.16b	v9, v9, v11
    108c:      	and.16b	v22, v22, v10
    1090:      	and.16b	v17, v22, v17
    1094:      	and.16b	v5, v9, v5
    1098:      	fmul.4s	v22, v5, v4
    109c:      	fmul.4s	v9, v17, v4
    10a0:      	mov.16b	v10, v3
    10a4:      	bsl.16b	v10, v2, v9
    10a8:      	mov.16b	v11, v3
    10ac:      	bsl.16b	v11, v2, v22
    10b0:      	fadd.4s	v22, v22, v11
    10b4:      	fadd.4s	v9, v9, v10
    10b8:      	fsub.4s	v9, v9, v10
    10bc:      	fsub.4s	v22, v22, v11
    10c0:      	fcvtzs.4s	v22, v22
    10c4:      	fcvtzs.4s	v9, v9
    10c8:      	scvtf.4s	v10, v9
    10cc:      	scvtf.4s	v11, v22
    10d0:      	fmul.4s	v12, v10, v6
    10d4:      	fadd.4s	v17, v17, v12
    10d8:      	fmul.4s	v12, v11, v6
    10dc:      	fadd.4s	v5, v5, v12
    10e0:      	fmul.4s	v10, v10, v7
    10e4:      	fmul.4s	v11, v11, v7
    10e8:      	fadd.4s	v5, v5, v11
    10ec:      	fadd.4s	v17, v17, v10
    10f0:      	fmul.4s	v10, v17, v18
    10f4:      	fmul.4s	v11, v5, v18
    10f8:      	fadd.4s	v11, v11, v19
    10fc:      	fadd.4s	v10, v10, v19
    1100:      	fmul.4s	v10, v17, v10
    1104:      	fmul.4s	v11, v5, v11
    1108:      	fadd.4s	v11, v11, v23
    110c:      	fadd.4s	v10, v10, v23
    1110:      	fmul.4s	v10, v17, v10
    1114:      	fmul.4s	v11, v5, v11
    1118:      	fadd.4s	v11, v11, v24
    111c:      	fadd.4s	v10, v10, v24
    1120:      	fmul.4s	v10, v17, v10
    1124:      	fmul.4s	v11, v5, v11
    1128:      	fadd.4s	v11, v11, v25
    112c:      	fadd.4s	v10, v10, v25
    1130:      	fmul.4s	v10, v17, v10
    1134:      	fmul.4s	v11, v5, v11
    1138:      	fadd.4s	v11, v11, v16
    113c:      	fadd.4s	v10, v10, v16
    1140:      	fmul.4s	v12, v17, v17
    1144:      	fmul.4s	v10, v12, v10
    1148:      	fmul.4s	v12, v5, v5
    114c:      	fmul.4s	v11, v12, v11
    1150:      	fadd.4s	v5, v5, v11
    1154:      	fadd.4s	v17, v17, v10
    1158:      	fadd.4s	v17, v17, v26
    115c:      	sshr.4s	v10, v22, #0x1
    1160:      	shl.4s	v11, v10, #0x17
    1164:      	add.4s	v11, v11, v26
    1168:      	fadd.4s	v5, v5, v26
    116c:      	fmul.4s	v5, v5, v11
    1170:      	sshr.4s	v11, v9, #0x1
    1174:      	sub.4s	v22, v22, v10
    1178:      	shl.4s	v10, v11, #0x17
    117c:      	add.4s	v10, v10, v26
    1180:      	fmul.4s	v17, v17, v10
    1184:      	sub.4s	v9, v9, v11
    1188:      	dup.2d	v10, x28
    118c:      	shl.4s	v9, v9, #0x17
    1190:      	add.4s	v9, v9, v26
    1194:      	fmul.4s	v17, v17, v9
    1198:      	add.2d	v9, v10, v27
    119c:      	shl.4s	v22, v22, #0x17
    11a0:      	add.4s	v22, v22, v26
    11a4:      	fmul.4s	v5, v5, v22
    11a8:      	fcmgt.4s	v22, v31, v0
    11ac:      	fadd.4s	v17, v17, v26
    11b0:      	bit.16b	v17, v26, v22
    11b4:      	fcmgt.4s	v22, v8, v0
    11b8:      	fadd.4s	v5, v5, v26
    11bc:      	bit.16b	v5, v26, v22
    11c0:      	fcmgt.4s	v22, v1, v8
    11c4:      	bit.16b	v5, v20, v22
    11c8:      	fcmgt.4s	v22, v1, v31
    11cc:      	bit.16b	v17, v20, v22
    11d0:      	fcmeq.4s	v22, v31, v31
    11d4:      	bif.16b	v17, v21, v22
    11d8:      	fcmeq.4s	v22, v8, v8
    11dc:      	bif.16b	v5, v21, v22
    11e0:      	fdiv.4s	v5, v8, v5
    11e4:      	fdiv.4s	v17, v31, v17
    11e8:      	add	x9, x27, x30
    11ec:      	ldp	q22, q31, [x9]
    11f0:      	add.2d	v8, v10, v29
    11f4:      	fmul.4s	v17, v31, v17
    11f8:      	add.2d	v31, v10, v28
    11fc:      	add.2d	v10, v10, v30
    1200:      	shl.2d	v10, v10, #0x2
    1204:      	shl.2d	v31, v31, #0x2
    1208:      	fmul.4s	v5, v22, v5
    120c:      	shl.2d	v22, v8, #0x2
    1210:      	shl.2d	v8, v9, #0x2
    1214:      	dup.2d	v9, x25
    1218:      	add.2d	v8, v9, v8
    121c:      	add.2d	v22, v9, v22
    1220:      	add.2d	v31, v9, v31
    1224:      	add.2d	v9, v9, v10
    1228:      	mov.d	x9, v9[1]
    122c:      	mov.d	x10, v31[1]
    1230:      	fmov	x11, d9
    1234:      	fmov	x13, d31
    1238:      	mov.d	x14, v22[1]
    123c:      	fmov	x15, d22
    1240:      	str	s5, [x11]
    1244:      	st1.s	{ v5 }[1], [x9]
    1248:      	st1.s	{ v5 }[2], [x13]
    124c:      	st1.s	{ v5 }[3], [x10]
    1250:      	mov.d	x9, v8[1]
    1254:      	fmov	x10, d8
    1258:      	str	s17, [x15]
    125c:      	st1.s	{ v17 }[1], [x14]
    1260:      	st1.s	{ v17 }[2], [x10]
    1264:      	st1.s	{ v17 }[3], [x9]
    1268:      	add	x28, x28, #0x1
    126c:      	cmp	x28, x12
    1270:      	b.ne	0x1064 <ltmp0+0x1064>
    1274:      	add	w20, w20, #0x1
    1278:      	cmp	w20, w21
    127c:      	b.ne	0xf18 <ltmp0+0xf18>
    1280:      	and	w19, w19, #0x7
    1284:      	mov	w14, #0xaa7a            ; =43642
    1288:      	movk	w14, #0x3d2a, lsl #16
    128c:      	mov	w15, #0xaaab            ; =43691
    1290:      	movk	w15, #0x3e2a, lsl #16
    1294:      	cbz	w19, 0x100 <ltmp0+0x100>
    1298:      	dup.4s	v5, w19
    129c:      	ldp	q17, q27, [sp, #0x60]
    12a0:      	cmhi.4s	v22, v5, v27
    12a4:      	cmhi.4s	v28, v5, v17
    12a8:      	str	q22, [sp, #0x40]
    12ac:      	uzp1.8h	v10, v28, v22
    12b0:      	umaxv.8h	h5, v10
    12b4:      	fmov	w9, s5
    12b8:      	tbz	w9, #0x0, 0x100 <ltmp0+0x100>
    12bc:      	mov	x23, #0x0               ; =0
    12c0:      	ldr	x19, [x2, #0x88]
    12c4:      	mov	w9, #0x20               ; =32
    12c8:      	movk	w9, #0x2, lsl #16
    12cc:      	add	x20, x19, x9
    12d0:      	ldr	x24, [x0]
    12d4:      	ldr	x22, [x0, #0x10]
    12d8:      	lsl	w9, w21, #3
    12dc:      	orr	w9, w9, w7, lsl #5
    12e0:      	dup.4s	v5, w9
    12e4:      	ldr	x21, [x0, #0x30]
    12e8:      	ldp	q17, q22, [sp, #0x60]
    12ec:      	orr.16b	v17, v5, v17
    12f0:      	orr.16b	v5, v5, v22
    12f4:      	ldp	q27, q22, [sp, #0x40]
    12f8:      	and.16b	v5, v27, v5
    12fc:      	and.16b	v17, v28, v17
    1300:      	umull2.2d	v29, v5, v22
    1304:      	umull2.2d	v31, v17, v22
    1308:      	umull.2d	v30, v5, v22
    130c:      	umull.2d	v22, v17, v22
    1310:      	b	0x1334 <ltmp0+0x1334>
    1314:      	add	x9, x19, x23, lsl #5
    1318:      	ldp	q5, q17, [x9]
    131c:      	bit.16b	v17, v12, v27
    1320:      	bit.16b	v5, v11, v28
    1324:      	stp	q5, q17, [x9]
    1328:      	add	x23, x23, #0x1
    132c:      	cmp	x23, x12
    1330:      	b.eq	0x1434 <ltmp0+0x1434>
    1334:      	ldr	q5, [x17]
    1338:      	and.16b	v5, v10, v5
    133c:      	addv.8h	h8, v5
    1340:      	fmov	w25, s8
    1344:      	dup.2d	v13, x23
    1348:      	add.2d	v5, v13, v22
    134c:      	shl.2d	v5, v5, #0x2
    1350:      	dup.2d	v14, x24
    1354:      	add.2d	v5, v14, v5
    1358:      	movi.2d	v11, #0000000000000000
    135c:      	movi.2d	v12, #0000000000000000
    1360:      	tbnz	w25, #0x0, 0x13ac <ltmp0+0x13ac>
    1364:      	and	w25, w25, #0xff
    1368:      	tbnz	w25, #0x1, 0x13bc <ltmp0+0x13bc>
    136c:      	add.2d	v5, v13, v31
    1370:      	shl.2d	v5, v5, #0x2
    1374:      	add.2d	v5, v14, v5
    1378:      	tbnz	w25, #0x2, 0x13d4 <ltmp0+0x13d4>
    137c:      	tbnz	w25, #0x3, 0x13e0 <ltmp0+0x13e0>
    1380:      	add.2d	v5, v13, v30
    1384:      	shl.2d	v5, v5, #0x2
    1388:      	add.2d	v5, v14, v5
    138c:      	tbnz	w25, #0x4, 0x13f8 <ltmp0+0x13f8>
    1390:      	tbnz	w25, #0x5, 0x1404 <ltmp0+0x1404>
    1394:      	add.2d	v5, v13, v29
    1398:      	shl.2d	v5, v5, #0x2
    139c:      	add.2d	v5, v14, v5
    13a0:      	tbnz	w25, #0x6, 0x141c <ltmp0+0x141c>
    13a4:      	tbz	w25, #0x7, 0x1314 <ltmp0+0x1314>
    13a8:      	b	0x1428 <ltmp0+0x1428>
    13ac:      	fmov	x9, d5
    13b0:      	ldr	s11, [x9]
    13b4:      	and	w25, w25, #0xff
    13b8:      	tbz	w25, #0x1, 0x136c <ltmp0+0x136c>
    13bc:      	mov.d	x9, v5[1]
    13c0:      	ld1.s	{ v11 }[1], [x9]
    13c4:      	add.2d	v5, v13, v31
    13c8:      	shl.2d	v5, v5, #0x2
    13cc:      	add.2d	v5, v14, v5
    13d0:      	tbz	w25, #0x2, 0x137c <ltmp0+0x137c>
    13d4:      	fmov	x9, d5
    13d8:      	ld1.s	{ v11 }[2], [x9]
    13dc:      	tbz	w25, #0x3, 0x1380 <ltmp0+0x1380>
    13e0:      	mov.d	x9, v5[1]
    13e4:      	ld1.s	{ v11 }[3], [x9]
    13e8:      	add.2d	v5, v13, v30
    13ec:      	shl.2d	v5, v5, #0x2
    13f0:      	add.2d	v5, v14, v5
    13f4:      	tbz	w25, #0x4, 0x1390 <ltmp0+0x1390>
    13f8:      	fmov	x9, d5
    13fc:      	ld1.s	{ v12 }[0], [x9]
    1400:      	tbz	w25, #0x5, 0x1394 <ltmp0+0x1394>
    1404:      	mov.d	x9, v5[1]
    1408:      	ld1.s	{ v12 }[1], [x9]
    140c:      	add.2d	v5, v13, v29
    1410:      	shl.2d	v5, v5, #0x2
    1414:      	add.2d	v5, v14, v5
    1418:      	tbz	w25, #0x6, 0x13a4 <ltmp0+0x13a4>
    141c:      	fmov	x9, d5
    1420:      	ld1.s	{ v12 }[2], [x9]
    1424:      	tbz	w25, #0x7, 0x1314 <ltmp0+0x1314>
    1428:      	mov.d	x9, v5[1]
    142c:      	ld1.s	{ v12 }[3], [x9]
    1430:      	b	0x1314 <ltmp0+0x1314>
    1434:      	mov	x23, #0x0               ; =0
    1438:      	b	0x145c <ltmp0+0x145c>
    143c:      	add	x9, x20, x23, lsl #5
    1440:      	ldp	q5, q17, [x9]
    1444:      	bit.16b	v17, v11, v27
    1448:      	bit.16b	v5, v10, v28
    144c:      	stp	q5, q17, [x9]
    1450:      	add	x23, x23, #0x1
    1454:      	cmp	x23, x12
    1458:      	b.eq	0x1550 <ltmp0+0x1550>
    145c:      	fmov	w24, s8
    1460:      	dup.2d	v12, x23
    1464:      	add.2d	v5, v12, v22
    1468:      	shl.2d	v5, v5, #0x2
    146c:      	dup.2d	v13, x22
    1470:      	add.2d	v5, v13, v5
    1474:      	movi.2d	v10, #0000000000000000
    1478:      	movi.2d	v11, #0000000000000000
    147c:      	tbnz	w24, #0x0, 0x14c8 <ltmp0+0x14c8>
    1480:      	and	w24, w24, #0xff
    1484:      	tbnz	w24, #0x1, 0x14d8 <ltmp0+0x14d8>
    1488:      	add.2d	v5, v12, v31
    148c:      	shl.2d	v5, v5, #0x2
    1490:      	add.2d	v5, v13, v5
    1494:      	tbnz	w24, #0x2, 0x14f0 <ltmp0+0x14f0>
    1498:      	tbnz	w24, #0x3, 0x14fc <ltmp0+0x14fc>
    149c:      	add.2d	v5, v12, v30
    14a0:      	shl.2d	v5, v5, #0x2
    14a4:      	add.2d	v5, v13, v5
    14a8:      	tbnz	w24, #0x4, 0x1514 <ltmp0+0x1514>
    14ac:      	tbnz	w24, #0x5, 0x1520 <ltmp0+0x1520>
    14b0:      	add.2d	v5, v12, v29
    14b4:      	shl.2d	v5, v5, #0x2
    14b8:      	add.2d	v5, v13, v5
    14bc:      	tbnz	w24, #0x6, 0x1538 <ltmp0+0x1538>
    14c0:      	tbz	w24, #0x7, 0x143c <ltmp0+0x143c>
    14c4:      	b	0x1544 <ltmp0+0x1544>
    14c8:      	fmov	x9, d5
    14cc:      	ldr	s10, [x9]
    14d0:      	and	w24, w24, #0xff
    14d4:      	tbz	w24, #0x1, 0x1488 <ltmp0+0x1488>
    14d8:      	mov.d	x9, v5[1]
    14dc:      	ld1.s	{ v10 }[1], [x9]
    14e0:      	add.2d	v5, v12, v31
    14e4:      	shl.2d	v5, v5, #0x2
    14e8:      	add.2d	v5, v13, v5
    14ec:      	tbz	w24, #0x2, 0x1498 <ltmp0+0x1498>
    14f0:      	fmov	x9, d5
    14f4:      	ld1.s	{ v10 }[2], [x9]
    14f8:      	tbz	w24, #0x3, 0x149c <ltmp0+0x149c>
    14fc:      	mov.d	x9, v5[1]
    1500:      	ld1.s	{ v10 }[3], [x9]
    1504:      	add.2d	v5, v12, v30
    1508:      	shl.2d	v5, v5, #0x2
    150c:      	add.2d	v5, v13, v5
    1510:      	tbz	w24, #0x4, 0x14ac <ltmp0+0x14ac>
    1514:      	fmov	x9, d5
    1518:      	ld1.s	{ v11 }[0], [x9]
    151c:      	tbz	w24, #0x5, 0x14b0 <ltmp0+0x14b0>
    1520:      	mov.d	x9, v5[1]
    1524:      	ld1.s	{ v11 }[1], [x9]
    1528:      	add.2d	v5, v12, v29
    152c:      	shl.2d	v5, v5, #0x2
    1530:      	add.2d	v5, v13, v5
    1534:      	tbz	w24, #0x6, 0x14c0 <ltmp0+0x14c0>
    1538:      	fmov	x9, d5
    153c:      	ld1.s	{ v11 }[2], [x9]
    1540:      	tbz	w24, #0x7, 0x143c <ltmp0+0x143c>
    1544:      	mov.d	x9, v5[1]
    1548:      	ld1.s	{ v11 }[3], [x9]
    154c:      	b	0x143c <ltmp0+0x143c>
    1550:      	stp	q22, q30, [sp, #0x20]
    1554:      	mov	x22, #0x0               ; =0
    1558:      	str	q29, [sp, #0x10]
    155c:      	b	0x1570 <ltmp0+0x1570>
    1560:      	add	x22, x22, #0x1
    1564:      	cmp	x22, x12
    1568:      	ldr	q22, [sp, #0x20]
    156c:      	b.eq	0x100 <ltmp0+0x100>
    1570:      	dup.2d	v10, x22
    1574:      	fmov	w23, s8
    1578:      	add.2d	v17, v10, v22
    157c:      	lsl	x9, x22, #5
    1580:      	add	x10, x19, x9
    1584:      	ldp	q5, q14, [x10]
    1588:      	and.16b	v5, v28, v5
    158c:      	fneg.4s	v22, v5
    1590:      	and.16b	v22, v28, v22
    1594:      	dup.4s	v11, w1
    1598:      	fcmge.4s	v13, v22, v11
    159c:      	dup.4s	v12, w4
    15a0:      	fcmge.4s	v15, v12, v22
    15a4:      	and.16b	v13, v13, v15
    15a8:      	and.16b	v13, v13, v22
    15ac:      	fmul.4s	v15, v13, v4
    15b0:      	mov.16b	v29, v3
    15b4:      	bsl.16b	v29, v2, v15
    15b8:      	fadd.4s	v15, v15, v29
    15bc:      	fsub.4s	v29, v15, v29
    15c0:      	fcvtzs.4s	v29, v29
    15c4:      	scvtf.4s	v15, v29
    15c8:      	fmul.4s	v30, v15, v6
    15cc:      	fadd.4s	v30, v13, v30
    15d0:      	fmul.4s	v13, v15, v7
    15d4:      	fadd.4s	v30, v30, v13
    15d8:      	fmul.4s	v13, v30, v18
    15dc:      	fadd.4s	v13, v13, v19
    15e0:      	fmul.4s	v13, v30, v13
    15e4:      	fadd.4s	v13, v13, v23
    15e8:      	fmul.4s	v13, v30, v13
    15ec:      	fadd.4s	v13, v13, v24
    15f0:      	fmul.4s	v13, v30, v13
    15f4:      	fadd.4s	v13, v13, v25
    15f8:      	fmul.4s	v13, v30, v13
    15fc:      	fadd.4s	v13, v13, v16
    1600:      	fmul.4s	v15, v30, v30
    1604:      	fmul.4s	v13, v15, v13
    1608:      	fadd.4s	v30, v30, v13
    160c:      	fadd.4s	v30, v30, v26
    1610:      	sshr.4s	v13, v29, #0x1
    1614:      	shl.4s	v15, v13, #0x17
    1618:      	add.4s	v15, v15, v26
    161c:      	fmul.4s	v30, v30, v15
    1620:      	sub.4s	v29, v29, v13
    1624:      	shl.4s	v29, v29, #0x17
    1628:      	add.4s	v29, v29, v26
    162c:      	fmul.4s	v29, v30, v29
    1630:      	fcmgt.4s	v30, v11, v22
    1634:      	fcmgt.4s	v13, v22, v12
    1638:      	fcmeq.4s	v22, v22, v22
    163c:      	fadd.4s	v29, v29, v26
    1640:      	bit.16b	v29, v26, v30
    1644:      	bit.16b	v29, v20, v13
    1648:      	bsl.16b	v22, v29, v21
    164c:      	fdiv.4s	v5, v5, v22
    1650:      	add	x9, x20, x9
    1654:      	ldp	q22, q15, [x9]
    1658:      	and.16b	v22, v28, v22
    165c:      	fmul.4s	v5, v22, v5
    1660:      	shl.2d	v17, v17, #0x2
    1664:      	dup.2d	v13, x21
    1668:      	add.2d	v22, v13, v17
    166c:      	tbnz	w23, #0x0, 0x17a4 <ltmp0+0x17a4>
    1670:      	and	w23, w23, #0xff
    1674:      	ldr	q29, [sp, #0x30]
    1678:      	tbnz	w23, #0x1, 0x17b8 <ltmp0+0x17b8>
    167c:      	add.2d	v17, v10, v31
    1680:      	shl.2d	v17, v17, #0x2
    1684:      	add.2d	v22, v13, v17
    1688:      	tbnz	w23, #0x2, 0x17d0 <ltmp0+0x17d0>
    168c:      	mov.16b	v27, v28
    1690:      	mov.16b	v9, v31
    1694:      	tbz	w23, #0x3, 0x16a0 <ltmp0+0x16a0>
    1698:      	mov.d	x9, v22[1]
    169c:      	st1.s	{ v5 }[3], [x9]
    16a0:      	add.2d	v17, v10, v29
    16a4:      	ldr	q28, [sp, #0x40]
    16a8:      	and.16b	v5, v28, v14
    16ac:      	fneg.4s	v22, v5
    16b0:      	and.16b	v22, v28, v22
    16b4:      	fcmge.4s	v29, v22, v11
    16b8:      	fcmge.4s	v30, v12, v22
    16bc:      	and.16b	v29, v29, v30
    16c0:      	and.16b	v29, v29, v22
    16c4:      	fmul.4s	v30, v29, v4
    16c8:      	mov.16b	v14, v3
    16cc:      	bsl.16b	v14, v2, v30
    16d0:      	fadd.4s	v30, v30, v14
    16d4:      	fsub.4s	v30, v30, v14
    16d8:      	fcvtzs.4s	v30, v30
    16dc:      	scvtf.4s	v14, v30
    16e0:      	fmul.4s	v31, v14, v6
    16e4:      	fadd.4s	v29, v29, v31
    16e8:      	fmul.4s	v31, v14, v7
    16ec:      	fadd.4s	v29, v29, v31
    16f0:      	fmul.4s	v31, v29, v18
    16f4:      	fadd.4s	v31, v31, v19
    16f8:      	fmul.4s	v31, v29, v31
    16fc:      	fadd.4s	v31, v31, v23
    1700:      	fmul.4s	v31, v29, v31
    1704:      	fadd.4s	v31, v31, v24
    1708:      	fmul.4s	v31, v29, v31
    170c:      	fadd.4s	v31, v31, v25
    1710:      	fmul.4s	v31, v29, v31
    1714:      	fadd.4s	v31, v31, v16
    1718:      	fmul.4s	v14, v29, v29
    171c:      	fmul.4s	v31, v14, v31
    1720:      	fadd.4s	v29, v29, v31
    1724:      	fadd.4s	v29, v29, v26
    1728:      	sshr.4s	v31, v30, #0x1
    172c:      	shl.4s	v14, v31, #0x17
    1730:      	add.4s	v14, v14, v26
    1734:      	fmul.4s	v29, v29, v14
    1738:      	sub.4s	v30, v30, v31
    173c:      	shl.4s	v30, v30, #0x17
    1740:      	add.4s	v30, v30, v26
    1744:      	fmul.4s	v29, v29, v30
    1748:      	fcmgt.4s	v30, v11, v22
    174c:      	fcmgt.4s	v31, v22, v12
    1750:      	fcmeq.4s	v22, v22, v22
    1754:      	fadd.4s	v29, v29, v26
    1758:      	bit.16b	v29, v26, v30
    175c:      	bit.16b	v29, v20, v31
    1760:      	bsl.16b	v22, v29, v21
    1764:      	fdiv.4s	v5, v5, v22
    1768:      	and.16b	v22, v28, v15
    176c:      	fmul.4s	v5, v22, v5
    1770:      	shl.2d	v17, v17, #0x2
    1774:      	add.2d	v22, v13, v17
    1778:      	tbnz	w23, #0x4, 0x17e8 <ltmp0+0x17e8>
    177c:      	ldr	q29, [sp, #0x10]
    1780:      	mov.16b	v28, v27
    1784:      	tbnz	w23, #0x5, 0x17fc <ltmp0+0x17fc>
    1788:      	add.2d	v17, v10, v29
    178c:      	shl.2d	v17, v17, #0x2
    1790:      	add.2d	v22, v13, v17
    1794:      	mov.16b	v31, v9
    1798:      	tbnz	w23, #0x6, 0x1818 <ltmp0+0x1818>
    179c:      	tbz	w23, #0x7, 0x1560 <ltmp0+0x1560>
    17a0:      	b	0x1824 <ltmp0+0x1824>
    17a4:      	fmov	x9, d22
    17a8:      	str	s5, [x9]
    17ac:      	and	w23, w23, #0xff
    17b0:      	ldr	q29, [sp, #0x30]
    17b4:      	tbz	w23, #0x1, 0x167c <ltmp0+0x167c>
    17b8:      	mov.d	x9, v22[1]
    17bc:      	st1.s	{ v5 }[1], [x9]
    17c0:      	add.2d	v17, v10, v31
    17c4:      	shl.2d	v17, v17, #0x2
    17c8:      	add.2d	v22, v13, v17
    17cc:      	tbz	w23, #0x2, 0x168c <ltmp0+0x168c>
    17d0:      	fmov	x9, d22
    17d4:      	st1.s	{ v5 }[2], [x9]
    17d8:      	mov.16b	v27, v28
    17dc:      	mov.16b	v9, v31
    17e0:      	tbnz	w23, #0x3, 0x1698 <ltmp0+0x1698>
    17e4:      	b	0x16a0 <ltmp0+0x16a0>
    17e8:      	fmov	x9, d22
    17ec:      	str	s5, [x9]
    17f0:      	ldr	q29, [sp, #0x10]
    17f4:      	mov.16b	v28, v27
    17f8:      	tbz	w23, #0x5, 0x1788 <ltmp0+0x1788>
    17fc:      	mov.d	x9, v22[1]
    1800:      	st1.s	{ v5 }[1], [x9]
    1804:      	add.2d	v17, v10, v29
    1808:      	shl.2d	v17, v17, #0x2
    180c:      	add.2d	v22, v13, v17
    1810:      	mov.16b	v31, v9
    1814:      	tbz	w23, #0x6, 0x179c <ltmp0+0x179c>
    1818:      	fmov	x9, d22
    181c:      	st1.s	{ v5 }[2], [x9]
    1820:      	tbz	w23, #0x7, 0x1560 <ltmp0+0x1560>
    1824:      	mov.d	x9, v22[1]
    1828:      	st1.s	{ v5 }[3], [x9]
    182c:      	b	0x1560 <ltmp0+0x1560>
    1830:      	stp	w7, w6, [x2]
    1834:      	str	w5, [x2, #0x8]
    1838:      	mov	w8, #0x18               ; =24
    183c:      	str	w8, [x2, #0x24]
    1840:      	ldp	x29, x30, [sp, #0x120]
    1844:      	ldp	x20, x19, [sp, #0x110]
    1848:      	ldp	x22, x21, [sp, #0x100]
    184c:      	ldp	x24, x23, [sp, #0xf0]
    1850:      	ldp	x26, x25, [sp, #0xe0]
    1854:      	ldp	x28, x27, [sp, #0xd0]
    1858:      	ldp	d9, d8, [sp, #0xc0]
    185c:      	ldp	d11, d10, [sp, #0xb0]
    1860:      	ldp	d13, d12, [sp, #0xa0]
    1864:      	ldp	d15, d14, [sp, #0x90]
    1868:      	add	sp, sp, #0x130
    186c:      	ret

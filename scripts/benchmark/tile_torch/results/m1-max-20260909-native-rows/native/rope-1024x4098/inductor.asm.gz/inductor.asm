
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/rope-1024x4098/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0x50
     6b4:      	stp	x22, x21, [sp, #0x20]
     6b8:      	stp	x20, x19, [sp, #0x30]
     6bc:      	stp	x29, x30, [sp, #0x40]
     6c0:      	add	x29, sp, #0x40
     6c4:      	mov	x8, #0x0                ; =0
     6c8:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     6cc:      	ldr	x9, [x9, #0x90]
     6d0:      	str	wzr, [sp]
     6d4:      	mov	x10, sp
     6d8:      	str	x10, [x9]
     6dc:      	mov	w10, #0x2004            ; =8196
     6e0:      	add	x11, x0, x10
     6e4:      	mov	w12, #0x4004            ; =16388
     6e8:      	mov	w13, #0x4008            ; =16392
     6ec:      	mov	x14, x1
     6f0:      	mov	x15, x2
     6f4:      	mov	x16, x0
     6f8:      	mov	x17, x3
     6fc:      	mov	x5, x4
     700:      	add	x19, x8, x8, lsl #11
     704:      	lsl	x6, x19, #1
     708:      	add	x6, x6, #0x800
     70c:      	add	x7, x19, #0x800
     710:      	add	x19, x0, x19, lsl #3
     714:      	add	x19, x19, x12
     718:      	mov	x20, #-0x2000           ; =-8192
     71c:      	mov	x21, #-0x4              ; =-4
     720:      	cbz	x20, 0x7a4 <_kernel+0xf4>
     724:      	add	x22, x16, x20
     728:      	ldr	q0, [x22, #0x2000]
     72c:      	add	x22, x14, x20
     730:      	ldr	q1, [x22, #0x2000]
     734:      	add	x22, x11, x20
     738:      	ldr	q2, [x22, #0x2000]
     73c:      	add	x22, x15, x20
     740:      	ldr	q3, [x22, #0x2000]
     744:      	fmul.4s	v4, v0, v1
     748:      	fmul.4s	v5, v2, v3
     74c:      	fsub.4s	v4, v4, v5
     750:      	fmul.4s	v0, v0, v3
     754:      	fmul.4s	v1, v1, v2
     758:      	fadd.4s	v0, v1, v0
     75c:      	add	x22, x17, x20
     760:      	str	q4, [x22, #0x2000]
     764:      	add	x22, x5, x20
     768:      	str	q0, [x22, #0x2000]
     76c:      	add	x20, x20, #0x10
     770:      	add	x21, x21, #0x4
     774:      	cmp	x21, #0x7fd
     778:      	b.lo	0x720 <_kernel+0x70>
     77c:      	add	x8, x8, #0x1
     780:      	add	x5, x5, x13
     784:      	add	x17, x17, x13
     788:      	add	x16, x16, x13
     78c:      	add	x15, x15, x10
     790:      	add	x14, x14, x10
     794:      	add	x11, x11, x13
     798:      	cmp	x8, #0x400
     79c:      	b.ne	0x700 <_kernel+0x50>
     7a0:      	b	0x7d8 <_kernel+0x128>
     7a4:      	ldr	s0, [x0, x6, lsl #2]
     7a8:      	ldr	s1, [x1, x7, lsl #2]
     7ac:      	ldr	s2, [x2, x7, lsl #2]
     7b0:      	ldr	s3, [x19]
     7b4:      	fmul	s4, s0, s1
     7b8:      	fmul	s5, s3, s2
     7bc:      	fsub	s4, s4, s5
     7c0:      	str	s4, [x3, x6, lsl #2]
     7c4:      	fmul	s0, s0, s2
     7c8:      	fmul	s1, s1, s3
     7cc:      	fadd	s0, s1, s0
     7d0:      	str	s0, [x4, x6, lsl #2]
     7d4:      	b	0x77c <_kernel+0xcc>
     7d8:      	str	xzr, [x9]
     7dc:      	mov	x8, sp
     7e0:      	ldapr	w8, [x8]
     7e4:      	cbnz	w8, 0x7fc <_kernel+0x14c>
     7e8:      	ldp	x29, x30, [sp, #0x40]
     7ec:      	ldp	x20, x19, [sp, #0x30]
     7f0:      	ldp	x22, x21, [sp, #0x20]
     7f4:      	add	sp, sp, #0x50
     7f8:      	ret
     7fc:      	mov	w0, #0x10               ; =16
     800:      	bl	0x1710 <dyld_stub_binder+0x1710>
     804:      	mov	x19, x0
     808:      	mov	w8, #0x33d              ; =829
     80c:      	str	w8, [sp, #0x4]
     810:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     814:      	add	x0, x0, #0xa34
     818:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     81c:      	add	x1, x1, #0xac0
     820:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     824:      	add	x3, x3, #0xaeb
     828:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     82c:      	add	x4, x4, #0xb69
     830:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     834:      	add	x2, x2, #0xae8
     838:      	add	x8, sp, #0x8
     83c:      	add	x5, sp, #0x4
     840:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     844:      	add	x7, x7, #0xb6b
     848:      	mov	x6, x2
     84c:      	bl	0x8c0 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     850:      	mov	w21, #0x1               ; =1
     854:      	add	x1, sp, #0x8
     858:      	mov	x0, x19
     85c:      	bl	0x165c <dyld_stub_binder+0x165c>
     860:      	mov	w21, #0x0               ; =0
     864:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     868:      	ldr	x1, [x1, #0x18]
     86c:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     870:      	ldr	x2, [x2, #0x8]
     874:      	mov	x0, x19
     878:      	bl	0x1740 <dyld_stub_binder+0x1740>
     87c:      	brk	#0x1
     880:      	mov	x20, x0
     884:      	ldrsb	w8, [sp, #0x1f]
     888:      	tbz	w8, #0x1f, 0x8a4 <_kernel+0x1f4>
     88c:      	ldr	x0, [sp, #0x8]
     890:      	ldr	x8, [sp, #0x18]
     894:      	and	x1, x8, #0x7fffffffffffffff
     898:      	bl	0x16f8 <dyld_stub_binder+0x16f8>
     89c:      	tbnz	w21, #0x0, 0x8b0 <_kernel+0x200>
     8a0:      	b	0x8b8 <_kernel+0x208>
     8a4:      	cbnz	w21, 0x8b0 <_kernel+0x200>
     8a8:      	b	0x8b8 <_kernel+0x208>
     8ac:      	mov	x20, x0
     8b0:      	mov	x0, x19
     8b4:      	bl	0x1734 <dyld_stub_binder+0x1734>
     8b8:      	mov	x0, x20
     8bc:      	bl	0x1620 <dyld_stub_binder+0x1620>

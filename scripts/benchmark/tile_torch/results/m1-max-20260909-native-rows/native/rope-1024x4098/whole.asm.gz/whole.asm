
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/rope-1024x4098-l1/object/tile_xir_w8_80791_1788919123028946_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	mov	x11, #0x0               ; =0
       4:      	ldr	x8, [x1, #0x88]
       8:      	ldr	x13, [x0]
       c:      	ldr	x12, [x0, #0x10]
      10:      	ldr	w9, [x1]
      14:      	ldr	w10, [x1, #0x24]
      18:      	add	w14, w10, w9, lsl #5
      1c:      	ldr	x10, [x0, #0x20]
      20:      	ldr	x9, [x0, #0x30]
      24:      	dup.4s	v0, w14
      28:      	adrp	x14, 0x0 <ltmp0>
      2c:      	ldr	q1, [x14]
      30:      	add.4s	v3, v0, v1
      34:      	adrp	x14, 0x0 <ltmp0>
      38:      	ldr	q1, [x14]
      3c:      	add.4s	v2, v0, v1
      40:      	ushll2.2d	v4, v2, #0x0
      44:      	ushll2.2d	v5, v3, #0x0
      48:      	ushll.2d	v6, v2, #0x0
      4c:      	ushll.2d	v7, v3, #0x0
      50:      	mov	w14, #0x1002            ; =4098
      54:      	dup.4s	v16, w14
      58:      	umull2.2d	v0, v2, v16
      5c:      	umull2.2d	v1, v3, v16
      60:      	umull.2d	v2, v2, v16
      64:      	umull.2d	v3, v3, v16
      68:      	dup.2d	v16, x13
      6c:      	dup.2d	v17, x11
      70:      	add.2d	v18, v17, v0
      74:      	add.2d	v19, v17, v2
      78:      	add.2d	v20, v17, v1
      7c:      	add.2d	v17, v17, v3
      80:      	shl.2d	v17, v17, #0x2
      84:      	shl.2d	v20, v20, #0x2
      88:      	shl.2d	v19, v19, #0x2
      8c:      	shl.2d	v18, v18, #0x2
      90:      	add.2d	v18, v16, v18
      94:      	add.2d	v19, v16, v19
      98:      	add.2d	v20, v16, v20
      9c:      	add.2d	v17, v16, v17
      a0:      	mov.d	x13, v17[1]
      a4:      	fmov	x14, d17
      a8:      	mov.d	x15, v20[1]
      ac:      	fmov	x16, d20
      b0:      	mov.d	x17, v19[1]
      b4:      	fmov	x0, d19
      b8:      	mov.d	x1, v18[1]
      bc:      	ldr	s17, [x14]
      c0:      	ld1.s	{ v17 }[1], [x13]
      c4:      	fmov	x13, d18
      c8:      	ld1.s	{ v17 }[2], [x16]
      cc:      	ld1.s	{ v17 }[3], [x15]
      d0:      	ldr	s18, [x0]
      d4:      	ld1.s	{ v18 }[1], [x17]
      d8:      	ld1.s	{ v18 }[2], [x13]
      dc:      	ld1.s	{ v18 }[3], [x1]
      e0:      	add	x13, x8, x11, lsl #5
      e4:      	stp	q17, q18, [x13]
      e8:      	add	x11, x11, #0x1
      ec:      	cmp	x11, #0x801
      f0:      	b.ne	0x6c <ltmp0+0x6c>
      f4:      	mov	x11, #0x0               ; =0
      f8:      	add	x13, x8, #0x10, lsl #12 ; =0x10000
      fc:      	add	x13, x13, #0x20
     100:      	add	x14, x11, #0x801
     104:      	dup.2d	v17, x14
     108:      	add.2d	v18, v17, v0
     10c:      	add.2d	v19, v17, v2
     110:      	add.2d	v20, v17, v1
     114:      	add.2d	v17, v17, v3
     118:      	shl.2d	v17, v17, #0x2
     11c:      	shl.2d	v20, v20, #0x2
     120:      	shl.2d	v19, v19, #0x2
     124:      	shl.2d	v18, v18, #0x2
     128:      	add.2d	v18, v16, v18
     12c:      	add.2d	v19, v16, v19
     130:      	add.2d	v20, v16, v20
     134:      	add.2d	v17, v16, v17
     138:      	mov.d	x14, v17[1]
     13c:      	fmov	x15, d17
     140:      	mov.d	x16, v20[1]
     144:      	fmov	x17, d20
     148:      	mov.d	x0, v19[1]
     14c:      	fmov	x1, d19
     150:      	mov.d	x2, v18[1]
     154:      	ldr	s17, [x15]
     158:      	ld1.s	{ v17 }[1], [x14]
     15c:      	fmov	x14, d18
     160:      	ld1.s	{ v17 }[2], [x17]
     164:      	ld1.s	{ v17 }[3], [x16]
     168:      	ldr	s18, [x1]
     16c:      	ld1.s	{ v18 }[1], [x0]
     170:      	ld1.s	{ v18 }[2], [x14]
     174:      	ld1.s	{ v18 }[3], [x2]
     178:      	add	x14, x13, x11, lsl #5
     17c:      	stp	q17, q18, [x14]
     180:      	add	x11, x11, #0x1
     184:      	cmp	x11, #0x801
     188:      	b.ne	0x100 <ltmp0+0x100>
     18c:      	mov	x13, #0x0               ; =0
     190:      	add	x11, x8, #0x20, lsl #12 ; =0x20000
     194:      	add	x11, x11, #0x40
     198:      	mov	w14, #0x801             ; =2049
     19c:      	dup.2s	v16, w14
     1a0:      	xtn.2s	v7, v7
     1a4:      	umull.2d	v7, v7, v16
     1a8:      	xtn.2s	v5, v5
     1ac:      	umull.2d	v5, v5, v16
     1b0:      	xtn.2s	v6, v6
     1b4:      	umull.2d	v6, v6, v16
     1b8:      	xtn.2s	v4, v4
     1bc:      	umull.2d	v4, v4, v16
     1c0:      	dup.2d	v16, x12
     1c4:      	dup.2d	v17, x13
     1c8:      	add.2d	v18, v17, v4
     1cc:      	add.2d	v19, v17, v6
     1d0:      	add.2d	v20, v17, v5
     1d4:      	add.2d	v17, v17, v7
     1d8:      	shl.2d	v17, v17, #0x2
     1dc:      	shl.2d	v20, v20, #0x2
     1e0:      	shl.2d	v19, v19, #0x2
     1e4:      	shl.2d	v18, v18, #0x2
     1e8:      	add.2d	v18, v16, v18
     1ec:      	add.2d	v19, v16, v19
     1f0:      	add.2d	v20, v16, v20
     1f4:      	add.2d	v17, v16, v17
     1f8:      	mov.d	x12, v17[1]
     1fc:      	fmov	x14, d17
     200:      	mov.d	x15, v20[1]
     204:      	fmov	x16, d20
     208:      	mov.d	x17, v19[1]
     20c:      	fmov	x0, d19
     210:      	mov.d	x1, v18[1]
     214:      	ldr	s17, [x14]
     218:      	ld1.s	{ v17 }[1], [x12]
     21c:      	fmov	x12, d18
     220:      	ld1.s	{ v17 }[2], [x16]
     224:      	ld1.s	{ v17 }[3], [x15]
     228:      	ldr	s18, [x0]
     22c:      	ld1.s	{ v18 }[1], [x17]
     230:      	ld1.s	{ v18 }[2], [x12]
     234:      	ld1.s	{ v18 }[3], [x1]
     238:      	add	x12, x11, x13, lsl #5
     23c:      	stp	q17, q18, [x12]
     240:      	add	x13, x13, #0x1
     244:      	cmp	x13, #0x801
     248:      	b.ne	0x1c4 <ltmp0+0x1c4>
     24c:      	mov	x12, #0x0               ; =0
     250:      	add	x13, x8, #0x30, lsl #12 ; =0x30000
     254:      	add	x13, x13, #0x60
     258:      	dup.2d	v16, x10
     25c:      	dup.2d	v17, x12
     260:      	add.2d	v18, v17, v4
     264:      	add.2d	v19, v17, v6
     268:      	add.2d	v20, v17, v5
     26c:      	add.2d	v17, v17, v7
     270:      	shl.2d	v17, v17, #0x2
     274:      	shl.2d	v20, v20, #0x2
     278:      	shl.2d	v19, v19, #0x2
     27c:      	shl.2d	v18, v18, #0x2
     280:      	add.2d	v18, v16, v18
     284:      	add.2d	v19, v16, v19
     288:      	add.2d	v20, v16, v20
     28c:      	add.2d	v17, v16, v17
     290:      	mov.d	x10, v17[1]
     294:      	fmov	x14, d17
     298:      	mov.d	x15, v20[1]
     29c:      	fmov	x16, d20
     2a0:      	mov.d	x17, v19[1]
     2a4:      	fmov	x0, d19
     2a8:      	mov.d	x1, v18[1]
     2ac:      	ldr	s17, [x14]
     2b0:      	ld1.s	{ v17 }[1], [x10]
     2b4:      	fmov	x10, d18
     2b8:      	ld1.s	{ v17 }[2], [x16]
     2bc:      	ld1.s	{ v17 }[3], [x15]
     2c0:      	ldr	s18, [x0]
     2c4:      	ld1.s	{ v18 }[1], [x17]
     2c8:      	ld1.s	{ v18 }[2], [x10]
     2cc:      	ld1.s	{ v18 }[3], [x1]
     2d0:      	add	x10, x13, x12, lsl #5
     2d4:      	stp	q17, q18, [x10]
     2d8:      	add	x12, x12, #0x1
     2dc:      	cmp	x12, #0x801
     2e0:      	b.ne	0x25c <ltmp0+0x25c>
     2e4:      	mov	x10, #-0x801            ; =-2049
     2e8:      	mov	w12, #0x20              ; =32
     2ec:      	movk	w12, #0x1, lsl #16
     2f0:      	dup.2d	v4, x9
     2f4:      	mov	x9, x8
     2f8:      	add	x13, x10, #0x801
     2fc:      	dup.2d	v5, x13
     300:      	add.2d	v6, v5, v0
     304:      	add.2d	v7, v5, v2
     308:      	add.2d	v16, v5, v1
     30c:      	add.2d	v5, v5, v3
     310:      	ldp	q18, q17, [x9]
     314:      	ldp	q20, q19, [x11]
     318:      	fmul.4s	v18, v18, v20
     31c:      	fmul.4s	v17, v17, v19
     320:      	add	x13, x9, x12
     324:      	ldp	q20, q19, [x13]
     328:      	add	x13, x11, x12
     32c:      	ldp	q22, q21, [x13]
     330:      	fmul.4s	v20, v20, v22
     334:      	fmul.4s	v19, v19, v21
     338:      	fsub.4s	v17, v17, v19
     33c:      	fsub.4s	v18, v18, v20
     340:      	shl.2d	v5, v5, #0x2
     344:      	shl.2d	v16, v16, #0x2
     348:      	shl.2d	v7, v7, #0x2
     34c:      	shl.2d	v6, v6, #0x2
     350:      	add.2d	v16, v4, v16
     354:      	add.2d	v5, v4, v5
     358:      	mov.d	x13, v5[1]
     35c:      	fmov	x14, d5
     360:      	str	s18, [x14]
     364:      	st1.s	{ v18 }[1], [x13]
     368:      	mov.d	x13, v16[1]
     36c:      	add.2d	v5, v4, v7
     370:      	fmov	x14, d16
     374:      	st1.s	{ v18 }[2], [x14]
     378:      	st1.s	{ v18 }[3], [x13]
     37c:      	mov.d	x13, v5[1]
     380:      	fmov	x14, d5
     384:      	str	s17, [x14]
     388:      	st1.s	{ v17 }[1], [x13]
     38c:      	add.2d	v5, v4, v6
     390:      	mov.d	x13, v5[1]
     394:      	fmov	x14, d5
     398:      	st1.s	{ v17 }[2], [x14]
     39c:      	st1.s	{ v17 }[3], [x13]
     3a0:      	add	x11, x11, #0x20
     3a4:      	add	x9, x9, #0x20
     3a8:      	adds	x10, x10, #0x1
     3ac:      	b.lo	0x2f8 <ltmp0+0x2f8>
     3b0:      	mov	w9, #0x801              ; =2049
     3b4:      	mov	w10, #0x60              ; =96
     3b8:      	movk	w10, #0x3, lsl #16
     3bc:      	mov	w11, #0x40              ; =64
     3c0:      	movk	w11, #0x2, lsl #16
     3c4:      	mov	w12, #0x20              ; =32
     3c8:      	movk	w12, #0x1, lsl #16
     3cc:      	mov	w13, #0x1002            ; =4098
     3d0:      	add	x14, x8, x10
     3d4:      	add	x15, x8, x11
     3d8:      	dup.2d	v5, x9
     3dc:      	add.2d	v6, v5, v0
     3e0:      	add.2d	v7, v5, v2
     3e4:      	add.2d	v16, v5, v1
     3e8:      	add.2d	v5, v5, v3
     3ec:      	ldp	q18, q17, [x8]
     3f0:      	ldp	q20, q19, [x14]
     3f4:      	fmul.4s	v18, v18, v20
     3f8:      	fmul.4s	v17, v17, v19
     3fc:      	add	x14, x8, x12
     400:      	ldp	q20, q19, [x14]
     404:      	ldp	q22, q21, [x15]
     408:      	fmul.4s	v20, v20, v22
     40c:      	fmul.4s	v19, v19, v21
     410:      	fadd.4s	v17, v17, v19
     414:      	fadd.4s	v18, v18, v20
     418:      	shl.2d	v5, v5, #0x2
     41c:      	shl.2d	v16, v16, #0x2
     420:      	shl.2d	v7, v7, #0x2
     424:      	shl.2d	v6, v6, #0x2
     428:      	add.2d	v16, v4, v16
     42c:      	add.2d	v5, v4, v5
     430:      	mov.d	x14, v5[1]
     434:      	fmov	x15, d5
     438:      	str	s18, [x15]
     43c:      	st1.s	{ v18 }[1], [x14]
     440:      	mov.d	x14, v16[1]
     444:      	add.2d	v5, v4, v7
     448:      	fmov	x15, d16
     44c:      	st1.s	{ v18 }[2], [x15]
     450:      	st1.s	{ v18 }[3], [x14]
     454:      	mov.d	x14, v5[1]
     458:      	fmov	x15, d5
     45c:      	str	s17, [x15]
     460:      	st1.s	{ v17 }[1], [x14]
     464:      	add.2d	v5, v4, v6
     468:      	mov.d	x14, v5[1]
     46c:      	fmov	x15, d5
     470:      	st1.s	{ v17 }[2], [x15]
     474:      	st1.s	{ v17 }[3], [x14]
     478:      	add	x9, x9, #0x1
     47c:      	add	x8, x8, #0x20
     480:      	cmp	x9, x13
     484:      	b.ne	0x3d0 <ltmp0+0x3d0>
     488:      	ret

000000000000048c <_llm_rows.packet_batch.blocks>:
     48c:      	sub	sp, sp, #0xd0
     490:      	stp	x28, x27, [sp, #0x70]
     494:      	stp	x26, x25, [sp, #0x80]
     498:      	stp	x24, x23, [sp, #0x90]
     49c:      	stp	x22, x21, [sp, #0xa0]
     4a0:      	stp	x20, x19, [sp, #0xb0]
     4a4:      	stp	x29, x30, [sp, #0xc0]
     4a8:      	str	x0, [sp, #0x60]
     4ac:      	cbz	w3, 0xe00 <_llm_rows.packet_batch.blocks+0x974>
     4b0:      	mov	x21, x3
     4b4:      	mov	x20, x2
     4b8:      	mov	w22, #0x0               ; =0
     4bc:      	ldp	w9, w8, [x2, #0x2c]
     4c0:      	stp	w8, w9, [sp, #0x58]
     4c4:      	ldp	w25, w26, [x2]
     4c8:      	ldp	w28, w27, [x2, #0x8]
     4cc:      	mov	w23, #0x20              ; =32
     4d0:      	movk	w23, #0x1, lsl #16
     4d4:      	mov	w1, #0x40               ; =64
     4d8:      	movk	w1, #0x2, lsl #16
     4dc:      	mov	w19, #0x60              ; =96
     4e0:      	movk	w19, #0x3, lsl #16
     4e4:      	adrp	x8, 0x0 <ltmp0>
     4e8:      	ldr	q0, [x8]
     4ec:      	str	q0, [sp, #0x40]
     4f0:      	adrp	x8, 0x0 <ltmp0>
     4f4:      	ldr	q0, [x8]
     4f8:      	str	q0, [sp, #0x30]
     4fc:      	mov	w2, #0x1002             ; =4098
     500:      	adrp	x8, 0x0 <ltmp0>
     504:      	ldr	q1, [x8]
     508:      	dup.4s	v0, w2
     50c:      	stp	q0, q1, [sp]
     510:      	str	w3, [sp, #0x2c]
     514:      	b	0x55c <_llm_rows.packet_batch.blocks+0xd0>
     518:      	mov	w8, #0x18               ; =24
     51c:      	str	w8, [x20, #0x24]
     520:      	ldr	w21, [sp, #0x2c]
     524:      	add	w8, w25, #0x1
     528:      	ldp	w10, w9, [sp, #0x58]
     52c:      	cmp	w8, w9
     530:      	cset	w8, eq
     534:      	csinc	w25, wzr, w25, eq
     538:      	cinc	w9, w26, eq
     53c:      	cmp	w9, w10
     540:      	cset	w10, eq
     544:      	ands	w8, w8, w10
     548:      	csel	w26, wzr, w9, ne
     54c:      	add	w28, w28, w8
     550:      	add	w22, w22, #0x1
     554:      	cmp	w22, w21
     558:      	b.eq	0xe00 <_llm_rows.packet_batch.blocks+0x974>
     55c:      	ubfiz	x8, x25, #5, #32
     560:      	cmp	x8, x27
     564:      	csel	x9, x8, xzr, ls
     568:      	subs	x10, x27, x9
     56c:      	cmp	x10, #0x20
     570:      	mov	w11, #0x20              ; =32
     574:      	csel	x10, x10, x11, lo
     578:      	cmp	x27, x9
     57c:      	stp	w25, w26, [x20]
     580:      	str	w28, [x20, #0x8]
     584:      	str	wzr, [x20, #0x24]
     588:      	ccmp	x8, x27, #0x2, hi
     58c:      	csel	x24, x10, xzr, ls
     590:      	cmp	x24, #0x20
     594:      	b.lo	0x5f4 <_llm_rows.packet_batch.blocks+0x168>
     598:      	ldr	x24, [sp, #0x60]
     59c:      	mov	x0, x24
     5a0:      	mov	x1, x20
     5a4:      	bl	0x5a4 <_llm_rows.packet_batch.blocks+0x118>
     5a8:      	mov	w8, #0x8                ; =8
     5ac:      	str	w8, [x20, #0x24]
     5b0:      	mov	x0, x24
     5b4:      	mov	x1, x20
     5b8:      	bl	0x5b8 <_llm_rows.packet_batch.blocks+0x12c>
     5bc:      	mov	w8, #0x10               ; =16
     5c0:      	str	w8, [x20, #0x24]
     5c4:      	mov	x0, x24
     5c8:      	mov	x1, x20
     5cc:      	bl	0x5cc <_llm_rows.packet_batch.blocks+0x140>
     5d0:      	mov	w8, #0x18               ; =24
     5d4:      	str	w8, [x20, #0x24]
     5d8:      	mov	x0, x24
     5dc:      	mov	x1, x20
     5e0:      	bl	0x5e0 <_llm_rows.packet_batch.blocks+0x154>
     5e4:      	mov	w2, #0x1002             ; =4098
     5e8:      	mov	w1, #0x40               ; =64
     5ec:      	movk	w1, #0x2, lsl #16
     5f0:      	b	0x524 <_llm_rows.packet_batch.blocks+0x98>
     5f4:      	lsr	x21, x24, #3
     5f8:      	cmp	x24, #0x8
     5fc:      	b.lo	0x66c <_llm_rows.packet_batch.blocks+0x1e0>
     600:      	str	wzr, [x20, #0x24]
     604:      	ldr	x0, [sp, #0x60]
     608:      	mov	x1, x20
     60c:      	bl	0x60c <_llm_rows.packet_batch.blocks+0x180>
     610:      	mov	w2, #0x1002             ; =4098
     614:      	mov	w1, #0x40               ; =64
     618:      	movk	w1, #0x2, lsl #16
     61c:      	cmp	x21, #0x1
     620:      	b.eq	0x66c <_llm_rows.packet_batch.blocks+0x1e0>
     624:      	mov	w8, #0x8                ; =8
     628:      	str	w8, [x20, #0x24]
     62c:      	ldr	x0, [sp, #0x60]
     630:      	mov	x1, x20
     634:      	bl	0x634 <_llm_rows.packet_batch.blocks+0x1a8>
     638:      	mov	w2, #0x1002             ; =4098
     63c:      	mov	w1, #0x40               ; =64
     640:      	movk	w1, #0x2, lsl #16
     644:      	cmp	x21, #0x2
     648:      	b.eq	0x66c <_llm_rows.packet_batch.blocks+0x1e0>
     64c:      	mov	w8, #0x10               ; =16
     650:      	str	w8, [x20, #0x24]
     654:      	ldr	x0, [sp, #0x60]
     658:      	mov	x1, x20
     65c:      	bl	0x65c <_llm_rows.packet_batch.blocks+0x1d0>
     660:      	mov	w2, #0x1002             ; =4098
     664:      	mov	w1, #0x40               ; =64
     668:      	movk	w1, #0x2, lsl #16
     66c:      	and	w8, w24, #0x7
     670:      	cbz	w8, 0x518 <_llm_rows.packet_batch.blocks+0x8c>
     674:      	dup.4s	v1, w8
     678:      	ldp	q0, q2, [sp, #0x30]
     67c:      	cmhi.4s	v0, v1, v0
     680:      	cmhi.4s	v1, v1, v2
     684:      	uzp1.8h	v6, v1, v0
     688:      	umaxv.8h	h2, v6
     68c:      	fmov	w8, s2
     690:      	tbz	w8, #0x0, 0x518 <_llm_rows.packet_batch.blocks+0x8c>
     694:      	mov	x15, #0x0               ; =0
     698:      	ldr	x8, [x20, #0x88]
     69c:      	add	x14, x8, x23
     6a0:      	add	x9, x8, x1
     6a4:      	add	x11, x8, x19
     6a8:      	ldr	x17, [sp, #0x60]
     6ac:      	ldr	x16, [x17]
     6b0:      	ldr	x13, [x17, #0x10]
     6b4:      	ldr	x12, [x17, #0x20]
     6b8:      	lsl	w10, w21, #3
     6bc:      	orr	w10, w10, w25, lsl #5
     6c0:      	dup.4s	v2, w10
     6c4:      	ldr	x10, [x17, #0x30]
     6c8:      	ldp	q3, q4, [sp, #0x30]
     6cc:      	orr.16b	v3, v2, v3
     6d0:      	orr.16b	v2, v2, v4
     6d4:      	and.16b	v5, v1, v2
     6d8:      	and.16b	v4, v0, v3
     6dc:      	ushll2.2d	v7, v4, #0x0
     6e0:      	ushll2.2d	v16, v5, #0x0
     6e4:      	ushll.2d	v17, v4, #0x0
     6e8:      	ushll.2d	v18, v5, #0x0
     6ec:      	ldp	q20, q19, [sp]
     6f0:      	umull2.2d	v2, v4, v20
     6f4:      	umull2.2d	v3, v5, v20
     6f8:      	umull.2d	v4, v4, v20
     6fc:      	umull.2d	v5, v5, v20
     700:      	and.16b	v6, v6, v19
     704:      	addv.8h	h6, v6
     708:      	dup.2d	v19, x16
     70c:      	fmov	w16, s6
     710:      	b	0x734 <_llm_rows.packet_batch.blocks+0x2a8>
     714:      	add	x17, x8, x15, lsl #5
     718:      	ldp	q22, q23, [x17]
     71c:      	bif.16b	v21, v23, v0
     720:      	bif.16b	v20, v22, v1
     724:      	stp	q20, q21, [x17]
     728:      	add	x15, x15, #0x1
     72c:      	cmp	x15, #0x801
     730:      	b.eq	0x820 <_llm_rows.packet_batch.blocks+0x394>
     734:      	dup.2d	v22, x15
     738:      	add.2d	v20, v22, v5
     73c:      	shl.2d	v20, v20, #0x2
     740:      	add.2d	v23, v19, v20
     744:      	movi.2d	v20, #0000000000000000
     748:      	movi.2d	v21, #0000000000000000
     74c:      	tbnz	w16, #0x0, 0x798 <_llm_rows.packet_batch.blocks+0x30c>
     750:      	and	w17, w16, #0xff
     754:      	tbnz	w17, #0x1, 0x7a8 <_llm_rows.packet_batch.blocks+0x31c>
     758:      	add.2d	v23, v22, v3
     75c:      	shl.2d	v23, v23, #0x2
     760:      	add.2d	v23, v19, v23
     764:      	tbnz	w17, #0x2, 0x7c0 <_llm_rows.packet_batch.blocks+0x334>
     768:      	tbnz	w17, #0x3, 0x7cc <_llm_rows.packet_batch.blocks+0x340>
     76c:      	add.2d	v23, v22, v4
     770:      	shl.2d	v23, v23, #0x2
     774:      	add.2d	v23, v19, v23
     778:      	tbnz	w17, #0x4, 0x7e4 <_llm_rows.packet_batch.blocks+0x358>
     77c:      	tbnz	w17, #0x5, 0x7f0 <_llm_rows.packet_batch.blocks+0x364>
     780:      	add.2d	v22, v22, v2
     784:      	shl.2d	v22, v22, #0x2
     788:      	add.2d	v22, v19, v22
     78c:      	tbnz	w17, #0x6, 0x808 <_llm_rows.packet_batch.blocks+0x37c>
     790:      	tbz	w17, #0x7, 0x714 <_llm_rows.packet_batch.blocks+0x288>
     794:      	b	0x814 <_llm_rows.packet_batch.blocks+0x388>
     798:      	fmov	x17, d23
     79c:      	ldr	s20, [x17]
     7a0:      	and	w17, w16, #0xff
     7a4:      	tbz	w17, #0x1, 0x758 <_llm_rows.packet_batch.blocks+0x2cc>
     7a8:      	mov.d	x0, v23[1]
     7ac:      	ld1.s	{ v20 }[1], [x0]
     7b0:      	add.2d	v23, v22, v3
     7b4:      	shl.2d	v23, v23, #0x2
     7b8:      	add.2d	v23, v19, v23
     7bc:      	tbz	w17, #0x2, 0x768 <_llm_rows.packet_batch.blocks+0x2dc>
     7c0:      	fmov	x0, d23
     7c4:      	ld1.s	{ v20 }[2], [x0]
     7c8:      	tbz	w17, #0x3, 0x76c <_llm_rows.packet_batch.blocks+0x2e0>
     7cc:      	mov.d	x0, v23[1]
     7d0:      	ld1.s	{ v20 }[3], [x0]
     7d4:      	add.2d	v23, v22, v4
     7d8:      	shl.2d	v23, v23, #0x2
     7dc:      	add.2d	v23, v19, v23
     7e0:      	tbz	w17, #0x4, 0x77c <_llm_rows.packet_batch.blocks+0x2f0>
     7e4:      	fmov	x0, d23
     7e8:      	ld1.s	{ v21 }[0], [x0]
     7ec:      	tbz	w17, #0x5, 0x780 <_llm_rows.packet_batch.blocks+0x2f4>
     7f0:      	mov.d	x0, v23[1]
     7f4:      	ld1.s	{ v21 }[1], [x0]
     7f8:      	add.2d	v22, v22, v2
     7fc:      	shl.2d	v22, v22, #0x2
     800:      	add.2d	v22, v19, v22
     804:      	tbz	w17, #0x6, 0x790 <_llm_rows.packet_batch.blocks+0x304>
     808:      	fmov	x0, d22
     80c:      	ld1.s	{ v21 }[2], [x0]
     810:      	tbz	w17, #0x7, 0x714 <_llm_rows.packet_batch.blocks+0x288>
     814:      	mov.d	x17, v22[1]
     818:      	ld1.s	{ v21 }[3], [x17]
     81c:      	b	0x714 <_llm_rows.packet_batch.blocks+0x288>
     820:      	mov	x15, #0x0               ; =0
     824:      	b	0x848 <_llm_rows.packet_batch.blocks+0x3bc>
     828:      	add	x16, x14, x15, lsl #5
     82c:      	ldp	q22, q23, [x16]
     830:      	bif.16b	v21, v23, v0
     834:      	bif.16b	v20, v22, v1
     838:      	stp	q20, q21, [x16]
     83c:      	add	x15, x15, #0x1
     840:      	cmp	x15, #0x801
     844:      	b.eq	0x93c <_llm_rows.packet_batch.blocks+0x4b0>
     848:      	add	x16, x15, #0x801
     84c:      	dup.2d	v22, x16
     850:      	fmov	w16, s6
     854:      	add.2d	v20, v22, v5
     858:      	shl.2d	v20, v20, #0x2
     85c:      	add.2d	v23, v19, v20
     860:      	movi.2d	v20, #0000000000000000
     864:      	movi.2d	v21, #0000000000000000
     868:      	tbnz	w16, #0x0, 0x8b4 <_llm_rows.packet_batch.blocks+0x428>
     86c:      	and	w16, w16, #0xff
     870:      	tbnz	w16, #0x1, 0x8c4 <_llm_rows.packet_batch.blocks+0x438>
     874:      	add.2d	v23, v22, v3
     878:      	shl.2d	v23, v23, #0x2
     87c:      	add.2d	v23, v19, v23
     880:      	tbnz	w16, #0x2, 0x8dc <_llm_rows.packet_batch.blocks+0x450>
     884:      	tbnz	w16, #0x3, 0x8e8 <_llm_rows.packet_batch.blocks+0x45c>
     888:      	add.2d	v23, v22, v4
     88c:      	shl.2d	v23, v23, #0x2
     890:      	add.2d	v23, v19, v23
     894:      	tbnz	w16, #0x4, 0x900 <_llm_rows.packet_batch.blocks+0x474>
     898:      	tbnz	w16, #0x5, 0x90c <_llm_rows.packet_batch.blocks+0x480>
     89c:      	add.2d	v22, v22, v2
     8a0:      	shl.2d	v22, v22, #0x2
     8a4:      	add.2d	v22, v19, v22
     8a8:      	tbnz	w16, #0x6, 0x924 <_llm_rows.packet_batch.blocks+0x498>
     8ac:      	tbz	w16, #0x7, 0x828 <_llm_rows.packet_batch.blocks+0x39c>
     8b0:      	b	0x930 <_llm_rows.packet_batch.blocks+0x4a4>
     8b4:      	fmov	x17, d23
     8b8:      	ldr	s20, [x17]
     8bc:      	and	w16, w16, #0xff
     8c0:      	tbz	w16, #0x1, 0x874 <_llm_rows.packet_batch.blocks+0x3e8>
     8c4:      	mov.d	x17, v23[1]
     8c8:      	ld1.s	{ v20 }[1], [x17]
     8cc:      	add.2d	v23, v22, v3
     8d0:      	shl.2d	v23, v23, #0x2
     8d4:      	add.2d	v23, v19, v23
     8d8:      	tbz	w16, #0x2, 0x884 <_llm_rows.packet_batch.blocks+0x3f8>
     8dc:      	fmov	x17, d23
     8e0:      	ld1.s	{ v20 }[2], [x17]
     8e4:      	tbz	w16, #0x3, 0x888 <_llm_rows.packet_batch.blocks+0x3fc>
     8e8:      	mov.d	x17, v23[1]
     8ec:      	ld1.s	{ v20 }[3], [x17]
     8f0:      	add.2d	v23, v22, v4
     8f4:      	shl.2d	v23, v23, #0x2
     8f8:      	add.2d	v23, v19, v23
     8fc:      	tbz	w16, #0x4, 0x898 <_llm_rows.packet_batch.blocks+0x40c>
     900:      	fmov	x17, d23
     904:      	ld1.s	{ v21 }[0], [x17]
     908:      	tbz	w16, #0x5, 0x89c <_llm_rows.packet_batch.blocks+0x410>
     90c:      	mov.d	x17, v23[1]
     910:      	ld1.s	{ v21 }[1], [x17]
     914:      	add.2d	v22, v22, v2
     918:      	shl.2d	v22, v22, #0x2
     91c:      	add.2d	v22, v19, v22
     920:      	tbz	w16, #0x6, 0x8ac <_llm_rows.packet_batch.blocks+0x420>
     924:      	fmov	x17, d22
     928:      	ld1.s	{ v21 }[2], [x17]
     92c:      	tbz	w16, #0x7, 0x828 <_llm_rows.packet_batch.blocks+0x39c>
     930:      	mov.d	x16, v22[1]
     934:      	ld1.s	{ v21 }[3], [x16]
     938:      	b	0x828 <_llm_rows.packet_batch.blocks+0x39c>
     93c:      	mov	x14, #0x0               ; =0
     940:      	dup.2s	v19, w15
     944:      	xtn.2s	v18, v18
     948:      	umull.2d	v18, v18, v19
     94c:      	xtn.2s	v16, v16
     950:      	umull.2d	v16, v16, v19
     954:      	xtn.2s	v17, v17
     958:      	umull.2d	v17, v17, v19
     95c:      	xtn.2s	v7, v7
     960:      	umull.2d	v7, v7, v19
     964:      	b	0x988 <_llm_rows.packet_batch.blocks+0x4fc>
     968:      	add	x15, x9, x14, lsl #5
     96c:      	ldp	q21, q22, [x15]
     970:      	bif.16b	v20, v22, v0
     974:      	bif.16b	v19, v21, v1
     978:      	stp	q19, q20, [x15]
     97c:      	add	x14, x14, #0x1
     980:      	cmp	x14, #0x801
     984:      	b.eq	0xa7c <_llm_rows.packet_batch.blocks+0x5f0>
     988:      	fmov	w15, s6
     98c:      	dup.2d	v21, x14
     990:      	add.2d	v19, v21, v18
     994:      	shl.2d	v19, v19, #0x2
     998:      	dup.2d	v22, x13
     99c:      	add.2d	v23, v22, v19
     9a0:      	movi.2d	v19, #0000000000000000
     9a4:      	movi.2d	v20, #0000000000000000
     9a8:      	tbnz	w15, #0x0, 0x9f4 <_llm_rows.packet_batch.blocks+0x568>
     9ac:      	and	w15, w15, #0xff
     9b0:      	tbnz	w15, #0x1, 0xa04 <_llm_rows.packet_batch.blocks+0x578>
     9b4:      	add.2d	v23, v21, v16
     9b8:      	shl.2d	v23, v23, #0x2
     9bc:      	add.2d	v23, v22, v23
     9c0:      	tbnz	w15, #0x2, 0xa1c <_llm_rows.packet_batch.blocks+0x590>
     9c4:      	tbnz	w15, #0x3, 0xa28 <_llm_rows.packet_batch.blocks+0x59c>
     9c8:      	add.2d	v23, v21, v17
     9cc:      	shl.2d	v23, v23, #0x2
     9d0:      	add.2d	v23, v22, v23
     9d4:      	tbnz	w15, #0x4, 0xa40 <_llm_rows.packet_batch.blocks+0x5b4>
     9d8:      	tbnz	w15, #0x5, 0xa4c <_llm_rows.packet_batch.blocks+0x5c0>
     9dc:      	add.2d	v21, v21, v7
     9e0:      	shl.2d	v21, v21, #0x2
     9e4:      	add.2d	v21, v22, v21
     9e8:      	tbnz	w15, #0x6, 0xa64 <_llm_rows.packet_batch.blocks+0x5d8>
     9ec:      	tbz	w15, #0x7, 0x968 <_llm_rows.packet_batch.blocks+0x4dc>
     9f0:      	b	0xa70 <_llm_rows.packet_batch.blocks+0x5e4>
     9f4:      	fmov	x16, d23
     9f8:      	ldr	s19, [x16]
     9fc:      	and	w15, w15, #0xff
     a00:      	tbz	w15, #0x1, 0x9b4 <_llm_rows.packet_batch.blocks+0x528>
     a04:      	mov.d	x16, v23[1]
     a08:      	ld1.s	{ v19 }[1], [x16]
     a0c:      	add.2d	v23, v21, v16
     a10:      	shl.2d	v23, v23, #0x2
     a14:      	add.2d	v23, v22, v23
     a18:      	tbz	w15, #0x2, 0x9c4 <_llm_rows.packet_batch.blocks+0x538>
     a1c:      	fmov	x16, d23
     a20:      	ld1.s	{ v19 }[2], [x16]
     a24:      	tbz	w15, #0x3, 0x9c8 <_llm_rows.packet_batch.blocks+0x53c>
     a28:      	mov.d	x16, v23[1]
     a2c:      	ld1.s	{ v19 }[3], [x16]
     a30:      	add.2d	v23, v21, v17
     a34:      	shl.2d	v23, v23, #0x2
     a38:      	add.2d	v23, v22, v23
     a3c:      	tbz	w15, #0x4, 0x9d8 <_llm_rows.packet_batch.blocks+0x54c>
     a40:      	fmov	x16, d23
     a44:      	ld1.s	{ v20 }[0], [x16]
     a48:      	tbz	w15, #0x5, 0x9dc <_llm_rows.packet_batch.blocks+0x550>
     a4c:      	mov.d	x16, v23[1]
     a50:      	ld1.s	{ v20 }[1], [x16]
     a54:      	add.2d	v21, v21, v7
     a58:      	shl.2d	v21, v21, #0x2
     a5c:      	add.2d	v21, v22, v21
     a60:      	tbz	w15, #0x6, 0x9ec <_llm_rows.packet_batch.blocks+0x560>
     a64:      	fmov	x16, d21
     a68:      	ld1.s	{ v20 }[2], [x16]
     a6c:      	tbz	w15, #0x7, 0x968 <_llm_rows.packet_batch.blocks+0x4dc>
     a70:      	mov.d	x15, v21[1]
     a74:      	ld1.s	{ v20 }[3], [x15]
     a78:      	b	0x968 <_llm_rows.packet_batch.blocks+0x4dc>
     a7c:      	mov	x13, #0x0               ; =0
     a80:      	b	0xaa4 <_llm_rows.packet_batch.blocks+0x618>
     a84:      	add	x14, x11, x13, lsl #5
     a88:      	ldp	q21, q22, [x14]
     a8c:      	bif.16b	v20, v22, v0
     a90:      	bif.16b	v19, v21, v1
     a94:      	stp	q19, q20, [x14]
     a98:      	add	x13, x13, #0x1
     a9c:      	cmp	x13, #0x801
     aa0:      	b.eq	0xb98 <_llm_rows.packet_batch.blocks+0x70c>
     aa4:      	fmov	w14, s6
     aa8:      	dup.2d	v21, x13
     aac:      	add.2d	v19, v21, v18
     ab0:      	shl.2d	v19, v19, #0x2
     ab4:      	dup.2d	v22, x12
     ab8:      	add.2d	v23, v22, v19
     abc:      	movi.2d	v19, #0000000000000000
     ac0:      	movi.2d	v20, #0000000000000000
     ac4:      	tbnz	w14, #0x0, 0xb10 <_llm_rows.packet_batch.blocks+0x684>
     ac8:      	and	w14, w14, #0xff
     acc:      	tbnz	w14, #0x1, 0xb20 <_llm_rows.packet_batch.blocks+0x694>
     ad0:      	add.2d	v23, v21, v16
     ad4:      	shl.2d	v23, v23, #0x2
     ad8:      	add.2d	v23, v22, v23
     adc:      	tbnz	w14, #0x2, 0xb38 <_llm_rows.packet_batch.blocks+0x6ac>
     ae0:      	tbnz	w14, #0x3, 0xb44 <_llm_rows.packet_batch.blocks+0x6b8>
     ae4:      	add.2d	v23, v21, v17
     ae8:      	shl.2d	v23, v23, #0x2
     aec:      	add.2d	v23, v22, v23
     af0:      	tbnz	w14, #0x4, 0xb5c <_llm_rows.packet_batch.blocks+0x6d0>
     af4:      	tbnz	w14, #0x5, 0xb68 <_llm_rows.packet_batch.blocks+0x6dc>
     af8:      	add.2d	v21, v21, v7
     afc:      	shl.2d	v21, v21, #0x2
     b00:      	add.2d	v21, v22, v21
     b04:      	tbnz	w14, #0x6, 0xb80 <_llm_rows.packet_batch.blocks+0x6f4>
     b08:      	tbz	w14, #0x7, 0xa84 <_llm_rows.packet_batch.blocks+0x5f8>
     b0c:      	b	0xb8c <_llm_rows.packet_batch.blocks+0x700>
     b10:      	fmov	x15, d23
     b14:      	ldr	s19, [x15]
     b18:      	and	w14, w14, #0xff
     b1c:      	tbz	w14, #0x1, 0xad0 <_llm_rows.packet_batch.blocks+0x644>
     b20:      	mov.d	x15, v23[1]
     b24:      	ld1.s	{ v19 }[1], [x15]
     b28:      	add.2d	v23, v21, v16
     b2c:      	shl.2d	v23, v23, #0x2
     b30:      	add.2d	v23, v22, v23
     b34:      	tbz	w14, #0x2, 0xae0 <_llm_rows.packet_batch.blocks+0x654>
     b38:      	fmov	x15, d23
     b3c:      	ld1.s	{ v19 }[2], [x15]
     b40:      	tbz	w14, #0x3, 0xae4 <_llm_rows.packet_batch.blocks+0x658>
     b44:      	mov.d	x15, v23[1]
     b48:      	ld1.s	{ v19 }[3], [x15]
     b4c:      	add.2d	v23, v21, v17
     b50:      	shl.2d	v23, v23, #0x2
     b54:      	add.2d	v23, v22, v23
     b58:      	tbz	w14, #0x4, 0xaf4 <_llm_rows.packet_batch.blocks+0x668>
     b5c:      	fmov	x15, d23
     b60:      	ld1.s	{ v20 }[0], [x15]
     b64:      	tbz	w14, #0x5, 0xaf8 <_llm_rows.packet_batch.blocks+0x66c>
     b68:      	mov.d	x15, v23[1]
     b6c:      	ld1.s	{ v20 }[1], [x15]
     b70:      	add.2d	v21, v21, v7
     b74:      	shl.2d	v21, v21, #0x2
     b78:      	add.2d	v21, v22, v21
     b7c:      	tbz	w14, #0x6, 0xb08 <_llm_rows.packet_batch.blocks+0x67c>
     b80:      	fmov	x15, d21
     b84:      	ld1.s	{ v20 }[2], [x15]
     b88:      	tbz	w14, #0x7, 0xa84 <_llm_rows.packet_batch.blocks+0x5f8>
     b8c:      	mov.d	x14, v21[1]
     b90:      	ld1.s	{ v20 }[3], [x14]
     b94:      	b	0xa84 <_llm_rows.packet_batch.blocks+0x5f8>
     b98:      	mov	x11, #-0x801            ; =-2049
     b9c:      	mov	x12, x8
     ba0:      	b	0xbb4 <_llm_rows.packet_batch.blocks+0x728>
     ba4:      	add	x9, x9, #0x20
     ba8:      	add	x12, x12, #0x20
     bac:      	adds	x11, x11, #0x1
     bb0:      	b.hs	0xcd0 <_llm_rows.packet_batch.blocks+0x844>
     bb4:      	fmov	w13, s6
     bb8:      	add	x14, x11, #0x801
     bbc:      	dup.2d	v16, x14
     bc0:      	add.2d	v7, v16, v5
     bc4:      	ldp	q19, q17, [x12]
     bc8:      	ldp	q20, q18, [x9]
     bcc:      	fmul.4s	v21, v19, v20
     bd0:      	add	x14, x12, x23
     bd4:      	ldp	q22, q19, [x14]
     bd8:      	add	x14, x9, x23
     bdc:      	ldp	q23, q20, [x14]
     be0:      	fmul.4s	v22, v22, v23
     be4:      	fsub.4s	v21, v21, v22
     be8:      	and.16b	v21, v1, v21
     bec:      	shl.2d	v22, v7, #0x2
     bf0:      	dup.2d	v7, x10
     bf4:      	add.2d	v22, v7, v22
     bf8:      	tbnz	w13, #0x0, 0xc5c <_llm_rows.packet_batch.blocks+0x7d0>
     bfc:      	and	w13, w13, #0xff
     c00:      	tbnz	w13, #0x1, 0xc6c <_llm_rows.packet_batch.blocks+0x7e0>
     c04:      	add.2d	v22, v16, v3
     c08:      	shl.2d	v22, v22, #0x2
     c0c:      	add.2d	v22, v7, v22
     c10:      	tbnz	w13, #0x2, 0xc84 <_llm_rows.packet_batch.blocks+0x7f8>
     c14:      	tbz	w13, #0x3, 0xc20 <_llm_rows.packet_batch.blocks+0x794>
     c18:      	mov.d	x14, v22[1]
     c1c:      	st1.s	{ v21 }[3], [x14]
     c20:      	add.2d	v21, v16, v4
     c24:      	fmul.4s	v17, v17, v18
     c28:      	fmul.4s	v18, v19, v20
     c2c:      	fsub.4s	v17, v17, v18
     c30:      	and.16b	v17, v0, v17
     c34:      	shl.2d	v18, v21, #0x2
     c38:      	add.2d	v18, v7, v18
     c3c:      	tbnz	w13, #0x4, 0xc94 <_llm_rows.packet_batch.blocks+0x808>
     c40:      	tbnz	w13, #0x5, 0xca0 <_llm_rows.packet_batch.blocks+0x814>
     c44:      	add.2d	v16, v16, v2
     c48:      	shl.2d	v16, v16, #0x2
     c4c:      	add.2d	v16, v7, v16
     c50:      	tbnz	w13, #0x6, 0xcb8 <_llm_rows.packet_batch.blocks+0x82c>
     c54:      	tbz	w13, #0x7, 0xba4 <_llm_rows.packet_batch.blocks+0x718>
     c58:      	b	0xcc4 <_llm_rows.packet_batch.blocks+0x838>
     c5c:      	fmov	x14, d22
     c60:      	str	s21, [x14]
     c64:      	and	w13, w13, #0xff
     c68:      	tbz	w13, #0x1, 0xc04 <_llm_rows.packet_batch.blocks+0x778>
     c6c:      	mov.d	x14, v22[1]
     c70:      	st1.s	{ v21 }[1], [x14]
     c74:      	add.2d	v22, v16, v3
     c78:      	shl.2d	v22, v22, #0x2
     c7c:      	add.2d	v22, v7, v22
     c80:      	tbz	w13, #0x2, 0xc14 <_llm_rows.packet_batch.blocks+0x788>
     c84:      	fmov	x14, d22
     c88:      	st1.s	{ v21 }[2], [x14]
     c8c:      	tbnz	w13, #0x3, 0xc18 <_llm_rows.packet_batch.blocks+0x78c>
     c90:      	b	0xc20 <_llm_rows.packet_batch.blocks+0x794>
     c94:      	fmov	x14, d18
     c98:      	str	s17, [x14]
     c9c:      	tbz	w13, #0x5, 0xc44 <_llm_rows.packet_batch.blocks+0x7b8>
     ca0:      	mov.d	x14, v18[1]
     ca4:      	st1.s	{ v17 }[1], [x14]
     ca8:      	add.2d	v16, v16, v2
     cac:      	shl.2d	v16, v16, #0x2
     cb0:      	add.2d	v16, v7, v16
     cb4:      	tbz	w13, #0x6, 0xc54 <_llm_rows.packet_batch.blocks+0x7c8>
     cb8:      	fmov	x14, d16
     cbc:      	st1.s	{ v17 }[2], [x14]
     cc0:      	tbz	w13, #0x7, 0xba4 <_llm_rows.packet_batch.blocks+0x718>
     cc4:      	mov.d	x13, v16[1]
     cc8:      	st1.s	{ v17 }[3], [x13]
     ccc:      	b	0xba4 <_llm_rows.packet_batch.blocks+0x718>
     cd0:      	mov	w9, #0x801              ; =2049
     cd4:      	b	0xce8 <_llm_rows.packet_batch.blocks+0x85c>
     cd8:      	add	x9, x9, #0x1
     cdc:      	add	x8, x8, #0x20
     ce0:      	cmp	x9, x2
     ce4:      	b.eq	0x518 <_llm_rows.packet_batch.blocks+0x8c>
     ce8:      	add	x11, x8, x19
     cec:      	add	x12, x8, x1
     cf0:      	fmov	w10, s6
     cf4:      	dup.2d	v16, x9
     cf8:      	add.2d	v22, v16, v5
     cfc:      	ldp	q19, q17, [x8]
     d00:      	ldp	q20, q18, [x11]
     d04:      	fmul.4s	v21, v19, v20
     d08:      	add	x11, x8, x23
     d0c:      	ldp	q23, q19, [x11]
     d10:      	ldp	q24, q20, [x12]
     d14:      	fmul.4s	v23, v23, v24
     d18:      	fadd.4s	v21, v21, v23
     d1c:      	and.16b	v21, v1, v21
     d20:      	shl.2d	v22, v22, #0x2
     d24:      	add.2d	v22, v7, v22
     d28:      	tbnz	w10, #0x0, 0xd8c <_llm_rows.packet_batch.blocks+0x900>
     d2c:      	and	w10, w10, #0xff
     d30:      	tbnz	w10, #0x1, 0xd9c <_llm_rows.packet_batch.blocks+0x910>
     d34:      	add.2d	v22, v16, v3
     d38:      	shl.2d	v22, v22, #0x2
     d3c:      	add.2d	v22, v7, v22
     d40:      	tbnz	w10, #0x2, 0xdb4 <_llm_rows.packet_batch.blocks+0x928>
     d44:      	tbz	w10, #0x3, 0xd50 <_llm_rows.packet_batch.blocks+0x8c4>
     d48:      	mov.d	x11, v22[1]
     d4c:      	st1.s	{ v21 }[3], [x11]
     d50:      	add.2d	v21, v16, v4
     d54:      	fmul.4s	v17, v17, v18
     d58:      	fmul.4s	v18, v19, v20
     d5c:      	fadd.4s	v17, v17, v18
     d60:      	and.16b	v17, v0, v17
     d64:      	shl.2d	v18, v21, #0x2
     d68:      	add.2d	v18, v7, v18
     d6c:      	tbnz	w10, #0x4, 0xdc4 <_llm_rows.packet_batch.blocks+0x938>
     d70:      	tbnz	w10, #0x5, 0xdd0 <_llm_rows.packet_batch.blocks+0x944>
     d74:      	add.2d	v16, v16, v2
     d78:      	shl.2d	v16, v16, #0x2
     d7c:      	add.2d	v16, v7, v16
     d80:      	tbnz	w10, #0x6, 0xde8 <_llm_rows.packet_batch.blocks+0x95c>
     d84:      	tbz	w10, #0x7, 0xcd8 <_llm_rows.packet_batch.blocks+0x84c>
     d88:      	b	0xdf4 <_llm_rows.packet_batch.blocks+0x968>
     d8c:      	fmov	x11, d22
     d90:      	str	s21, [x11]
     d94:      	and	w10, w10, #0xff
     d98:      	tbz	w10, #0x1, 0xd34 <_llm_rows.packet_batch.blocks+0x8a8>
     d9c:      	mov.d	x11, v22[1]
     da0:      	st1.s	{ v21 }[1], [x11]
     da4:      	add.2d	v22, v16, v3
     da8:      	shl.2d	v22, v22, #0x2
     dac:      	add.2d	v22, v7, v22
     db0:      	tbz	w10, #0x2, 0xd44 <_llm_rows.packet_batch.blocks+0x8b8>
     db4:      	fmov	x11, d22
     db8:      	st1.s	{ v21 }[2], [x11]
     dbc:      	tbnz	w10, #0x3, 0xd48 <_llm_rows.packet_batch.blocks+0x8bc>
     dc0:      	b	0xd50 <_llm_rows.packet_batch.blocks+0x8c4>
     dc4:      	fmov	x11, d18
     dc8:      	str	s17, [x11]
     dcc:      	tbz	w10, #0x5, 0xd74 <_llm_rows.packet_batch.blocks+0x8e8>
     dd0:      	mov.d	x11, v18[1]
     dd4:      	st1.s	{ v17 }[1], [x11]
     dd8:      	add.2d	v16, v16, v2
     ddc:      	shl.2d	v16, v16, #0x2
     de0:      	add.2d	v16, v7, v16
     de4:      	tbz	w10, #0x6, 0xd84 <_llm_rows.packet_batch.blocks+0x8f8>
     de8:      	fmov	x11, d16
     dec:      	st1.s	{ v17 }[2], [x11]
     df0:      	tbz	w10, #0x7, 0xcd8 <_llm_rows.packet_batch.blocks+0x84c>
     df4:      	mov.d	x10, v16[1]
     df8:      	st1.s	{ v17 }[3], [x10]
     dfc:      	b	0xcd8 <_llm_rows.packet_batch.blocks+0x84c>
     e00:      	ldp	x29, x30, [sp, #0xc0]
     e04:      	ldp	x20, x19, [sp, #0xb0]
     e08:      	ldp	x22, x21, [sp, #0xa0]
     e0c:      	ldp	x24, x23, [sp, #0x90]
     e10:      	ldp	x26, x25, [sp, #0x80]
     e14:      	ldp	x28, x27, [sp, #0x70]
     e18:      	add	sp, sp, #0xd0
     e1c:      	ret


/private/tmp/luisa-native-rows.LuX3yX/capture-v3/swiglu-129x768-l1/object/tile_xir_w8_80769_1788919114830214_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x184c <ltmp0+0x184c>
       4:      	stp	d15, d14, [sp, #-0xa0]!
       8:      	stp	d13, d12, [sp, #0x10]
       c:      	stp	d11, d10, [sp, #0x20]
      10:      	stp	d9, d8, [sp, #0x30]
      14:      	stp	x28, x27, [sp, #0x40]
      18:      	stp	x26, x25, [sp, #0x50]
      1c:      	stp	x24, x23, [sp, #0x60]
      20:      	stp	x22, x21, [sp, #0x70]
      24:      	stp	x20, x19, [sp, #0x80]
      28:      	stp	x29, x30, [sp, #0x90]
      2c:      	sub	sp, sp, #0xc, lsl #12   ; =0xc000
      30:      	sub	sp, sp, #0x80
      34:      	mov	w8, #0x0                ; =0
      38:      	ldp	w9, w10, [x2, #0x2c]
      3c:      	add	x12, sp, #0x6, lsl #12  ; =0x6000
      40:      	add	x12, x12, #0x80
      44:      	mov	w13, #0x42d00000        ; =1120927744
      48:      	dup.4s	v2, w13
      4c:      	add	x13, sp, #0x80
      50:      	mov	w14, #-0x3d380000       ; =-1027080192
      54:      	dup.4s	v3, w14
      58:      	mov	w14, #0xaa3b            ; =43579
      5c:      	movk	w14, #0x3fb8, lsl #16
      60:      	ldp	w19, w20, [x2]
      64:      	movi.4s	v4, #0x4b, lsl #24
      68:      	dup.4s	v5, w14
      6c:      	mvni.4s	v6, #0x80, lsl #24
      70:      	mov	w14, #0x7200            ; =29184
      74:      	movk	w14, #0xbf31, lsl #16
      78:      	dup.4s	v7, w14
      7c:      	mov	w14, #0xbe8e            ; =48782
      80:      	movk	w14, #0xb5bf, lsl #16
      84:      	dup.4s	v16, w14
      88:      	mov	w14, #0x2bda            ; =11226
      8c:      	movk	w14, #0x3950, lsl #16
      90:      	dup.4s	v17, w14
      94:      	mov	w17, #0x96c9            ; =38601
      98:      	movk	w17, #0x3ab6, lsl #16
      9c:      	mov	w1, #0x88a6             ; =34982
      a0:      	movk	w1, #0x3c08, lsl #16
      a4:      	ldp	w21, w15, [x2, #0x8]
      a8:      	str	x2, [sp, #0x8]
      ac:      	mov	w2, #0xaaab             ; =43691
      b0:      	movk	w2, #0x3e2a, lsl #16
      b4:      	dup.4s	v18, w17
      b8:      	movi.4s	v19, #0x3f, lsl #24
      bc:      	adrp	x17, 0x0 <ltmp0>
      c0:      	ldr	q0, [x17]
      c4:      	str	q0, [sp, #0x50]
      c8:      	mvni.4s	v0, #0x7f, msl #16
      cc:      	dup.4s	v21, w1
      d0:      	fneg.4s	v22, v0
      d4:      	adrp	x17, 0x0 <ltmp0>
      d8:      	ldr	q0, [x17]
      dc:      	str	q0, [sp, #0x40]
      e0:      	mvni.4s	v0, #0x3f, msl #16
      e4:      	fneg.4s	v24, v0
      e8:      	adrp	x17, 0x0 <ltmp0>
      ec:      	mov	w1, #-0x3d300000        ; =-1026555904
      f0:      	mov	w4, #0x42c80000         ; =1120403456
      f4:      	fmov.4s	v27, #1.00000000
      f8:      	b	0x130 <ltmp0+0x130>
      fc:      	add	w11, w7, #0x1
     100:      	cmp	w11, w9
     104:      	cset	w11, eq
     108:      	csinc	w19, wzr, w7, eq
     10c:      	cinc	w14, w6, eq
     110:      	cmp	w14, w10
     114:      	cset	w16, eq
     118:      	ands	w11, w11, w16
     11c:      	csel	w20, wzr, w14, ne
     120:      	add	w21, w5, w11
     124:      	add	w8, w8, #0x1
     128:      	cmp	w8, w3
     12c:      	b.eq	0x1808 <ltmp0+0x1808>
     130:      	mov	x5, x21
     134:      	mov	x6, x20
     138:      	mov	x7, x19
     13c:      	ubfiz	x19, x19, #5, #32
     140:      	cmp	x19, x15
     144:      	csel	x20, x19, xzr, ls
     148:      	subs	x21, x15, x20
     14c:      	cmp	x21, #0x20
     150:      	mov	w11, #0x20              ; =32
     154:      	csel	x21, x21, x11, lo
     158:      	cmp	x15, x20
     15c:      	ccmp	x19, x15, #0x2, hi
     160:      	csel	x20, x21, xzr, ls
     164:      	mov	w11, #0xaa7a            ; =43642
     168:      	movk	w11, #0x3d2a, lsl #16
     16c:      	dup.4s	v25, w11
     170:      	dup.4s	v26, w2
     174:      	cmp	x20, #0x20
     178:      	b.lo	0xee8 <ltmp0+0xee8>
     17c:      	mov	x22, #0x0               ; =0
     180:      	ldr	x23, [x0]
     184:      	ldr	x21, [x0, #0x10]
     188:      	ldr	x20, [x0, #0x30]
     18c:      	lsl	w19, w7, #5
     190:      	dup.4s	v0, w19
     194:      	ldp	q20, q1, [sp, #0x40]
     198:      	orr.16b	v1, v0, v1
     19c:      	orr.16b	v0, v0, v20
     1a0:      	movi.4s	v20, #0x3, lsl #8
     1a4:      	umull2.2d	v31, v1, v20
     1a8:      	umull2.2d	v8, v0, v20
     1ac:      	movi.2s	v20, #0x3, lsl #8
     1b0:      	umull.2d	v9, v1, v20
     1b4:      	umull.2d	v10, v0, v20
     1b8:      	dup.2d	v28, x23
     1bc:      	dup.2d	v0, x22
     1c0:      	add.2d	v1, v0, v31
     1c4:      	add.2d	v20, v0, v9
     1c8:      	add.2d	v29, v0, v8
     1cc:      	add.2d	v0, v0, v10
     1d0:      	shl.2d	v0, v0, #0x2
     1d4:      	shl.2d	v29, v29, #0x2
     1d8:      	shl.2d	v20, v20, #0x2
     1dc:      	shl.2d	v1, v1, #0x2
     1e0:      	add.2d	v1, v28, v1
     1e4:      	add.2d	v20, v28, v20
     1e8:      	add.2d	v29, v28, v29
     1ec:      	add.2d	v0, v28, v0
     1f0:      	mov.d	x23, v0[1]
     1f4:      	fmov	x24, d0
     1f8:      	mov.d	x25, v29[1]
     1fc:      	fmov	x26, d29
     200:      	mov.d	x27, v20[1]
     204:      	fmov	x28, d20
     208:      	mov.d	x30, v1[1]
     20c:      	ldr	s0, [x28]
     210:      	ld1.s	{ v0 }[1], [x27]
     214:      	fmov	x27, d1
     218:      	ld1.s	{ v0 }[2], [x27]
     21c:      	ld1.s	{ v0 }[3], [x30]
     220:      	ldr	s1, [x24]
     224:      	ld1.s	{ v1 }[1], [x23]
     228:      	ld1.s	{ v1 }[2], [x26]
     22c:      	ld1.s	{ v1 }[3], [x25]
     230:      	add	x23, x12, x22, lsl #5
     234:      	stp	q1, q0, [x23]
     238:      	add	x22, x22, #0x1
     23c:      	cmp	x22, #0x300
     240:      	b.ne	0x1bc <ltmp0+0x1bc>
     244:      	mov	x22, #0x0               ; =0
     248:      	dup.2d	v29, x21
     24c:      	dup.2d	v0, x22
     250:      	add.2d	v1, v0, v31
     254:      	add.2d	v20, v0, v9
     258:      	add.2d	v30, v0, v8
     25c:      	add.2d	v0, v0, v10
     260:      	shl.2d	v0, v0, #0x2
     264:      	shl.2d	v30, v30, #0x2
     268:      	shl.2d	v20, v20, #0x2
     26c:      	shl.2d	v1, v1, #0x2
     270:      	add.2d	v1, v29, v1
     274:      	add.2d	v20, v29, v20
     278:      	add.2d	v30, v29, v30
     27c:      	add.2d	v0, v29, v0
     280:      	mov.d	x21, v0[1]
     284:      	fmov	x23, d0
     288:      	mov.d	x24, v30[1]
     28c:      	fmov	x25, d30
     290:      	mov.d	x26, v20[1]
     294:      	fmov	x27, d20
     298:      	mov.d	x28, v1[1]
     29c:      	ldr	s0, [x27]
     2a0:      	ld1.s	{ v0 }[1], [x26]
     2a4:      	fmov	x26, d1
     2a8:      	ld1.s	{ v0 }[2], [x26]
     2ac:      	ld1.s	{ v0 }[3], [x28]
     2b0:      	ldr	s1, [x23]
     2b4:      	ld1.s	{ v1 }[1], [x21]
     2b8:      	ld1.s	{ v1 }[2], [x25]
     2bc:      	ld1.s	{ v1 }[3], [x24]
     2c0:      	add	x21, x13, x22, lsl #5
     2c4:      	stp	q1, q0, [x21]
     2c8:      	add	x22, x22, #0x1
     2cc:      	cmp	x22, #0x300
     2d0:      	b.ne	0x24c <ltmp0+0x24c>
     2d4:      	mov	x21, #0x0               ; =0
     2d8:      	lsl	x22, x21, #5
     2dc:      	add	x23, x12, x22
     2e0:      	ldp	q11, q30, [x23]
     2e4:      	fneg.4s	v0, v11
     2e8:      	fneg.4s	v1, v30
     2ec:      	fcmge.4s	v20, v2, v30
     2f0:      	fcmge.4s	v12, v2, v11
     2f4:      	fcmge.4s	v13, v30, v3
     2f8:      	fcmge.4s	v14, v11, v3
     2fc:      	and.16b	v12, v12, v14
     300:      	and.16b	v20, v20, v13
     304:      	and.16b	v1, v20, v1
     308:      	and.16b	v0, v12, v0
     30c:      	fmul.4s	v20, v0, v5
     310:      	fmul.4s	v12, v1, v5
     314:      	mov.16b	v13, v6
     318:      	bsl.16b	v13, v4, v12
     31c:      	mov.16b	v14, v6
     320:      	bsl.16b	v14, v4, v20
     324:      	fadd.4s	v20, v20, v14
     328:      	fadd.4s	v12, v12, v13
     32c:      	fsub.4s	v12, v12, v13
     330:      	fsub.4s	v20, v20, v14
     334:      	fcvtzs.4s	v20, v20
     338:      	fcvtzs.4s	v12, v12
     33c:      	scvtf.4s	v13, v12
     340:      	scvtf.4s	v14, v20
     344:      	fmul.4s	v15, v13, v7
     348:      	fadd.4s	v1, v1, v15
     34c:      	fmul.4s	v15, v14, v7
     350:      	fadd.4s	v0, v0, v15
     354:      	fmul.4s	v13, v13, v16
     358:      	fmul.4s	v14, v14, v16
     35c:      	fadd.4s	v0, v0, v14
     360:      	fadd.4s	v1, v1, v13
     364:      	fmul.4s	v13, v1, v17
     368:      	fmul.4s	v14, v0, v17
     36c:      	fadd.4s	v14, v14, v18
     370:      	fadd.4s	v13, v13, v18
     374:      	fmul.4s	v13, v1, v13
     378:      	fmul.4s	v14, v0, v14
     37c:      	fadd.4s	v14, v14, v21
     380:      	fadd.4s	v13, v13, v21
     384:      	fmul.4s	v13, v1, v13
     388:      	fmul.4s	v14, v0, v14
     38c:      	fadd.4s	v14, v14, v25
     390:      	fadd.4s	v13, v13, v25
     394:      	fmul.4s	v13, v1, v13
     398:      	fmul.4s	v14, v0, v14
     39c:      	fadd.4s	v14, v14, v26
     3a0:      	fadd.4s	v13, v13, v26
     3a4:      	fmul.4s	v13, v1, v13
     3a8:      	fmul.4s	v14, v0, v14
     3ac:      	fadd.4s	v14, v14, v19
     3b0:      	fadd.4s	v13, v13, v19
     3b4:      	fmul.4s	v15, v1, v1
     3b8:      	fmul.4s	v13, v15, v13
     3bc:      	fmul.4s	v15, v0, v0
     3c0:      	fmul.4s	v14, v15, v14
     3c4:      	fadd.4s	v0, v0, v14
     3c8:      	fadd.4s	v1, v1, v13
     3cc:      	fadd.4s	v1, v1, v27
     3d0:      	sshr.4s	v13, v20, #0x1
     3d4:      	shl.4s	v14, v13, #0x17
     3d8:      	add.4s	v14, v14, v27
     3dc:      	fadd.4s	v0, v0, v27
     3e0:      	fmul.4s	v14, v0, v14
     3e4:      	sshr.4s	v0, v12, #0x1
     3e8:      	sub.4s	v20, v20, v13
     3ec:      	shl.4s	v13, v0, #0x17
     3f0:      	add.4s	v13, v13, v27
     3f4:      	fmul.4s	v1, v1, v13
     3f8:      	sub.4s	v0, v12, v0
     3fc:      	shl.4s	v0, v0, #0x17
     400:      	add.4s	v0, v0, v27
     404:      	fmul.4s	v1, v1, v0
     408:      	dup.2d	v0, x21
     40c:      	shl.4s	v20, v20, #0x17
     410:      	add.4s	v20, v20, v27
     414:      	fmul.4s	v20, v14, v20
     418:      	fcmgt.4s	v12, v30, v2
     41c:      	fadd.4s	v1, v1, v27
     420:      	bit.16b	v1, v27, v12
     424:      	fcmgt.4s	v12, v11, v2
     428:      	fadd.4s	v20, v20, v27
     42c:      	bit.16b	v20, v27, v12
     430:      	fcmgt.4s	v12, v3, v11
     434:      	bit.16b	v20, v22, v12
     438:      	fcmgt.4s	v12, v3, v30
     43c:      	bit.16b	v1, v22, v12
     440:      	fcmeq.4s	v12, v30, v30
     444:      	bif.16b	v1, v24, v12
     448:      	fcmeq.4s	v12, v11, v11
     44c:      	bif.16b	v20, v24, v12
     450:      	add.2d	v12, v0, v10
     454:      	fdiv.4s	v20, v11, v20
     458:      	fdiv.4s	v1, v30, v1
     45c:      	add	x22, x13, x22
     460:      	ldp	q30, q11, [x22]
     464:      	fmul.4s	v20, v30, v20
     468:      	shl.2d	v12, v12, #0x2
     46c:      	dup.2d	v30, x20
     470:      	add.2d	v12, v30, v12
     474:      	mov.d	x22, v12[1]
     478:      	fmov	x23, d12
     47c:      	add.2d	v12, v0, v8
     480:      	shl.2d	v12, v12, #0x2
     484:      	add.2d	v12, v30, v12
     488:      	mov.d	x24, v12[1]
     48c:      	fmov	x25, d12
     490:      	str	s20, [x23]
     494:      	st1.s	{ v20 }[1], [x22]
     498:      	st1.s	{ v20 }[2], [x25]
     49c:      	fmul.4s	v1, v11, v1
     4a0:      	st1.s	{ v20 }[3], [x24]
     4a4:      	add.2d	v20, v0, v9
     4a8:      	shl.2d	v20, v20, #0x2
     4ac:      	add.2d	v20, v30, v20
     4b0:      	mov.d	x22, v20[1]
     4b4:      	fmov	x23, d20
     4b8:      	add.2d	v0, v0, v31
     4bc:      	shl.2d	v0, v0, #0x2
     4c0:      	add.2d	v0, v30, v0
     4c4:      	mov.d	x24, v0[1]
     4c8:      	fmov	x25, d0
     4cc:      	str	s1, [x23]
     4d0:      	st1.s	{ v1 }[1], [x22]
     4d4:      	st1.s	{ v1 }[2], [x25]
     4d8:      	st1.s	{ v1 }[3], [x24]
     4dc:      	add	x21, x21, #0x1
     4e0:      	cmp	x21, #0x300
     4e4:      	b.ne	0x2d8 <ltmp0+0x2d8>
     4e8:      	mov	x20, #0x0               ; =0
     4ec:      	orr	w21, w19, #0x8
     4f0:      	dup.4s	v0, w21
     4f4:      	ldp	q20, q1, [sp, #0x40]
     4f8:      	orr.16b	v1, v0, v1
     4fc:      	orr.16b	v0, v0, v20
     500:      	movi.4s	v20, #0x3, lsl #8
     504:      	umull2.2d	v31, v1, v20
     508:      	umull2.2d	v8, v0, v20
     50c:      	movi.2s	v20, #0x3, lsl #8
     510:      	umull.2d	v9, v1, v20
     514:      	umull.2d	v10, v0, v20
     518:      	dup.2d	v0, x20
     51c:      	add.2d	v1, v0, v31
     520:      	add.2d	v20, v0, v9
     524:      	add.2d	v11, v0, v8
     528:      	add.2d	v0, v0, v10
     52c:      	shl.2d	v0, v0, #0x2
     530:      	shl.2d	v11, v11, #0x2
     534:      	shl.2d	v20, v20, #0x2
     538:      	shl.2d	v1, v1, #0x2
     53c:      	add.2d	v1, v28, v1
     540:      	add.2d	v20, v28, v20
     544:      	add.2d	v11, v28, v11
     548:      	add.2d	v0, v28, v0
     54c:      	mov.d	x21, v0[1]
     550:      	fmov	x22, d0
     554:      	mov.d	x23, v11[1]
     558:      	fmov	x24, d11
     55c:      	mov.d	x25, v20[1]
     560:      	fmov	x26, d20
     564:      	mov.d	x27, v1[1]
     568:      	ldr	s0, [x26]
     56c:      	ld1.s	{ v0 }[1], [x25]
     570:      	fmov	x25, d1
     574:      	ld1.s	{ v0 }[2], [x25]
     578:      	ld1.s	{ v0 }[3], [x27]
     57c:      	ldr	s1, [x22]
     580:      	ld1.s	{ v1 }[1], [x21]
     584:      	ld1.s	{ v1 }[2], [x24]
     588:      	ld1.s	{ v1 }[3], [x23]
     58c:      	add	x21, x12, x20, lsl #5
     590:      	stp	q1, q0, [x21]
     594:      	add	x20, x20, #0x1
     598:      	cmp	x20, #0x300
     59c:      	b.ne	0x518 <ltmp0+0x518>
     5a0:      	mov	x20, #0x0               ; =0
     5a4:      	dup.2d	v0, x20
     5a8:      	add.2d	v1, v0, v31
     5ac:      	add.2d	v20, v0, v9
     5b0:      	add.2d	v11, v0, v8
     5b4:      	add.2d	v0, v0, v10
     5b8:      	shl.2d	v0, v0, #0x2
     5bc:      	shl.2d	v11, v11, #0x2
     5c0:      	shl.2d	v20, v20, #0x2
     5c4:      	shl.2d	v1, v1, #0x2
     5c8:      	add.2d	v1, v29, v1
     5cc:      	add.2d	v20, v29, v20
     5d0:      	add.2d	v11, v29, v11
     5d4:      	add.2d	v0, v29, v0
     5d8:      	mov.d	x21, v0[1]
     5dc:      	fmov	x22, d0
     5e0:      	mov.d	x23, v11[1]
     5e4:      	fmov	x24, d11
     5e8:      	mov.d	x25, v20[1]
     5ec:      	fmov	x26, d20
     5f0:      	mov.d	x27, v1[1]
     5f4:      	ldr	s0, [x26]
     5f8:      	ld1.s	{ v0 }[1], [x25]
     5fc:      	fmov	x25, d1
     600:      	ld1.s	{ v0 }[2], [x25]
     604:      	ld1.s	{ v0 }[3], [x27]
     608:      	ldr	s1, [x22]
     60c:      	ld1.s	{ v1 }[1], [x21]
     610:      	ld1.s	{ v1 }[2], [x24]
     614:      	ld1.s	{ v1 }[3], [x23]
     618:      	add	x21, x13, x20, lsl #5
     61c:      	stp	q1, q0, [x21]
     620:      	add	x20, x20, #0x1
     624:      	cmp	x20, #0x300
     628:      	b.ne	0x5a4 <ltmp0+0x5a4>
     62c:      	mov	x20, #0x0               ; =0
     630:      	lsl	x21, x20, #5
     634:      	add	x22, x12, x21
     638:      	ldp	q12, q11, [x22]
     63c:      	fneg.4s	v0, v12
     640:      	fneg.4s	v1, v11
     644:      	fcmge.4s	v20, v2, v11
     648:      	fcmge.4s	v13, v2, v12
     64c:      	fcmge.4s	v14, v11, v3
     650:      	fcmge.4s	v15, v12, v3
     654:      	and.16b	v13, v13, v15
     658:      	and.16b	v20, v20, v14
     65c:      	and.16b	v1, v20, v1
     660:      	and.16b	v0, v13, v0
     664:      	fmul.4s	v20, v0, v5
     668:      	fmul.4s	v13, v1, v5
     66c:      	mov.16b	v14, v6
     670:      	bsl.16b	v14, v4, v13
     674:      	mov.16b	v15, v6
     678:      	bsl.16b	v15, v4, v20
     67c:      	fadd.4s	v20, v20, v15
     680:      	fadd.4s	v13, v13, v14
     684:      	fsub.4s	v13, v13, v14
     688:      	fsub.4s	v20, v20, v15
     68c:      	fcvtzs.4s	v20, v20
     690:      	fcvtzs.4s	v13, v13
     694:      	scvtf.4s	v14, v13
     698:      	scvtf.4s	v15, v20
     69c:      	fmul.4s	v23, v14, v7
     6a0:      	fadd.4s	v1, v1, v23
     6a4:      	fmul.4s	v23, v15, v7
     6a8:      	fadd.4s	v0, v0, v23
     6ac:      	fmul.4s	v23, v14, v16
     6b0:      	fmul.4s	v14, v15, v16
     6b4:      	fadd.4s	v0, v0, v14
     6b8:      	fadd.4s	v1, v1, v23
     6bc:      	fmul.4s	v23, v1, v17
     6c0:      	fmul.4s	v14, v0, v17
     6c4:      	fadd.4s	v14, v14, v18
     6c8:      	fadd.4s	v23, v23, v18
     6cc:      	fmul.4s	v23, v1, v23
     6d0:      	fmul.4s	v14, v0, v14
     6d4:      	fadd.4s	v14, v14, v21
     6d8:      	fadd.4s	v23, v23, v21
     6dc:      	fmul.4s	v23, v1, v23
     6e0:      	fmul.4s	v14, v0, v14
     6e4:      	fadd.4s	v14, v14, v25
     6e8:      	fadd.4s	v23, v23, v25
     6ec:      	fmul.4s	v23, v1, v23
     6f0:      	fmul.4s	v14, v0, v14
     6f4:      	fadd.4s	v14, v14, v26
     6f8:      	fadd.4s	v23, v23, v26
     6fc:      	fmul.4s	v23, v1, v23
     700:      	fmul.4s	v14, v0, v14
     704:      	fadd.4s	v14, v14, v19
     708:      	fadd.4s	v23, v23, v19
     70c:      	fmul.4s	v15, v1, v1
     710:      	fmul.4s	v23, v15, v23
     714:      	fmul.4s	v15, v0, v0
     718:      	fmul.4s	v14, v15, v14
     71c:      	fadd.4s	v0, v0, v14
     720:      	fadd.4s	v1, v1, v23
     724:      	sshr.4s	v23, v13, #0x1
     728:      	sshr.4s	v14, v20, #0x1
     72c:      	fadd.4s	v0, v0, v27
     730:      	shl.4s	v15, v14, #0x17
     734:      	add.4s	v15, v15, v27
     738:      	fmul.4s	v15, v0, v15
     73c:      	shl.4s	v0, v23, #0x17
     740:      	add.4s	v0, v0, v27
     744:      	fadd.4s	v1, v1, v27
     748:      	fmul.4s	v0, v1, v0
     74c:      	sub.4s	v1, v20, v14
     750:      	sub.4s	v20, v13, v23
     754:      	shl.4s	v20, v20, #0x17
     758:      	add.4s	v20, v20, v27
     75c:      	fmul.4s	v20, v0, v20
     760:      	dup.2d	v0, x20
     764:      	shl.4s	v1, v1, #0x17
     768:      	add.4s	v1, v1, v27
     76c:      	fmul.4s	v1, v15, v1
     770:      	fcmgt.4s	v23, v11, v2
     774:      	fadd.4s	v20, v20, v27
     778:      	bit.16b	v20, v27, v23
     77c:      	fcmgt.4s	v23, v12, v2
     780:      	fadd.4s	v1, v1, v27
     784:      	bit.16b	v1, v27, v23
     788:      	fcmgt.4s	v23, v3, v12
     78c:      	bit.16b	v1, v22, v23
     790:      	fcmgt.4s	v23, v3, v11
     794:      	bit.16b	v20, v22, v23
     798:      	fcmeq.4s	v23, v11, v11
     79c:      	bif.16b	v20, v24, v23
     7a0:      	fcmeq.4s	v23, v12, v12
     7a4:      	bif.16b	v1, v24, v23
     7a8:      	fdiv.4s	v1, v12, v1
     7ac:      	fdiv.4s	v20, v11, v20
     7b0:      	add	x21, x13, x21
     7b4:      	ldp	q23, q11, [x21]
     7b8:      	fmul.4s	v1, v23, v1
     7bc:      	add.2d	v23, v0, v10
     7c0:      	shl.2d	v23, v23, #0x2
     7c4:      	add.2d	v23, v30, v23
     7c8:      	mov.d	x21, v23[1]
     7cc:      	fmov	x22, d23
     7d0:      	add.2d	v23, v0, v8
     7d4:      	shl.2d	v23, v23, #0x2
     7d8:      	add.2d	v23, v30, v23
     7dc:      	mov.d	x23, v23[1]
     7e0:      	fmov	x24, d23
     7e4:      	str	s1, [x22]
     7e8:      	st1.s	{ v1 }[1], [x21]
     7ec:      	st1.s	{ v1 }[2], [x24]
     7f0:      	fmul.4s	v20, v11, v20
     7f4:      	st1.s	{ v1 }[3], [x23]
     7f8:      	add.2d	v1, v0, v9
     7fc:      	shl.2d	v1, v1, #0x2
     800:      	add.2d	v1, v30, v1
     804:      	mov.d	x21, v1[1]
     808:      	fmov	x22, d1
     80c:      	add.2d	v0, v0, v31
     810:      	shl.2d	v0, v0, #0x2
     814:      	add.2d	v0, v30, v0
     818:      	mov.d	x23, v0[1]
     81c:      	fmov	x24, d0
     820:      	str	s20, [x22]
     824:      	st1.s	{ v20 }[1], [x21]
     828:      	st1.s	{ v20 }[2], [x24]
     82c:      	st1.s	{ v20 }[3], [x23]
     830:      	add	x20, x20, #0x1
     834:      	cmp	x20, #0x300
     838:      	b.ne	0x630 <ltmp0+0x630>
     83c:      	mov	x20, #0x0               ; =0
     840:      	orr	w21, w19, #0x10
     844:      	dup.4s	v0, w21
     848:      	ldp	q20, q1, [sp, #0x40]
     84c:      	orr.16b	v1, v0, v1
     850:      	orr.16b	v0, v0, v20
     854:      	movi.4s	v20, #0x3, lsl #8
     858:      	umull2.2d	v31, v1, v20
     85c:      	umull2.2d	v8, v0, v20
     860:      	movi.2s	v20, #0x3, lsl #8
     864:      	umull.2d	v9, v1, v20
     868:      	umull.2d	v10, v0, v20
     86c:      	dup.2d	v0, x20
     870:      	add.2d	v1, v0, v31
     874:      	add.2d	v20, v0, v9
     878:      	add.2d	v23, v0, v8
     87c:      	add.2d	v0, v0, v10
     880:      	shl.2d	v0, v0, #0x2
     884:      	shl.2d	v23, v23, #0x2
     888:      	shl.2d	v20, v20, #0x2
     88c:      	shl.2d	v1, v1, #0x2
     890:      	add.2d	v1, v28, v1
     894:      	add.2d	v20, v28, v20
     898:      	add.2d	v23, v28, v23
     89c:      	add.2d	v0, v28, v0
     8a0:      	mov.d	x21, v0[1]
     8a4:      	fmov	x22, d0
     8a8:      	mov.d	x23, v23[1]
     8ac:      	fmov	x24, d23
     8b0:      	mov.d	x25, v20[1]
     8b4:      	fmov	x26, d20
     8b8:      	mov.d	x27, v1[1]
     8bc:      	ldr	s0, [x26]
     8c0:      	ld1.s	{ v0 }[1], [x25]
     8c4:      	fmov	x25, d1
     8c8:      	ld1.s	{ v0 }[2], [x25]
     8cc:      	ld1.s	{ v0 }[3], [x27]
     8d0:      	ldr	s1, [x22]
     8d4:      	ld1.s	{ v1 }[1], [x21]
     8d8:      	ld1.s	{ v1 }[2], [x24]
     8dc:      	ld1.s	{ v1 }[3], [x23]
     8e0:      	add	x21, x12, x20, lsl #5
     8e4:      	stp	q1, q0, [x21]
     8e8:      	add	x20, x20, #0x1
     8ec:      	cmp	x20, #0x300
     8f0:      	b.ne	0x86c <ltmp0+0x86c>
     8f4:      	mov	x20, #0x0               ; =0
     8f8:      	dup.2d	v0, x20
     8fc:      	add.2d	v1, v0, v31
     900:      	add.2d	v20, v0, v9
     904:      	add.2d	v23, v0, v8
     908:      	add.2d	v0, v0, v10
     90c:      	shl.2d	v0, v0, #0x2
     910:      	shl.2d	v23, v23, #0x2
     914:      	shl.2d	v20, v20, #0x2
     918:      	shl.2d	v1, v1, #0x2
     91c:      	add.2d	v1, v29, v1
     920:      	add.2d	v20, v29, v20
     924:      	add.2d	v23, v29, v23
     928:      	add.2d	v0, v29, v0
     92c:      	mov.d	x21, v0[1]
     930:      	fmov	x22, d0
     934:      	mov.d	x23, v23[1]
     938:      	fmov	x24, d23
     93c:      	mov.d	x25, v20[1]
     940:      	fmov	x26, d20
     944:      	mov.d	x27, v1[1]
     948:      	ldr	s0, [x26]
     94c:      	ld1.s	{ v0 }[1], [x25]
     950:      	fmov	x25, d1
     954:      	ld1.s	{ v0 }[2], [x25]
     958:      	ld1.s	{ v0 }[3], [x27]
     95c:      	ldr	s1, [x22]
     960:      	ld1.s	{ v1 }[1], [x21]
     964:      	ld1.s	{ v1 }[2], [x24]
     968:      	ld1.s	{ v1 }[3], [x23]
     96c:      	add	x21, x13, x20, lsl #5
     970:      	stp	q1, q0, [x21]
     974:      	add	x20, x20, #0x1
     978:      	cmp	x20, #0x300
     97c:      	b.ne	0x8f8 <ltmp0+0x8f8>
     980:      	mov	x20, #0x0               ; =0
     984:      	lsl	x21, x20, #5
     988:      	add	x22, x12, x21
     98c:      	ldp	q12, q11, [x22]
     990:      	fneg.4s	v0, v12
     994:      	fneg.4s	v1, v11
     998:      	fcmge.4s	v20, v2, v11
     99c:      	fcmge.4s	v23, v2, v12
     9a0:      	fcmge.4s	v13, v11, v3
     9a4:      	fcmge.4s	v14, v12, v3
     9a8:      	and.16b	v23, v23, v14
     9ac:      	and.16b	v20, v20, v13
     9b0:      	and.16b	v1, v20, v1
     9b4:      	and.16b	v0, v23, v0
     9b8:      	fmul.4s	v20, v0, v5
     9bc:      	fmul.4s	v23, v1, v5
     9c0:      	mov.16b	v13, v6
     9c4:      	bsl.16b	v13, v4, v23
     9c8:      	mov.16b	v14, v6
     9cc:      	bsl.16b	v14, v4, v20
     9d0:      	fadd.4s	v20, v20, v14
     9d4:      	fadd.4s	v23, v23, v13
     9d8:      	fsub.4s	v23, v23, v13
     9dc:      	fsub.4s	v20, v20, v14
     9e0:      	fcvtzs.4s	v20, v20
     9e4:      	fcvtzs.4s	v23, v23
     9e8:      	scvtf.4s	v13, v23
     9ec:      	scvtf.4s	v14, v20
     9f0:      	fmul.4s	v15, v13, v7
     9f4:      	fadd.4s	v1, v1, v15
     9f8:      	fmul.4s	v15, v14, v7
     9fc:      	fadd.4s	v0, v0, v15
     a00:      	fmul.4s	v13, v13, v16
     a04:      	fmul.4s	v14, v14, v16
     a08:      	fadd.4s	v0, v0, v14
     a0c:      	fadd.4s	v1, v1, v13
     a10:      	fmul.4s	v13, v1, v17
     a14:      	fmul.4s	v14, v0, v17
     a18:      	fadd.4s	v14, v14, v18
     a1c:      	fadd.4s	v13, v13, v18
     a20:      	fmul.4s	v13, v1, v13
     a24:      	fmul.4s	v14, v0, v14
     a28:      	fadd.4s	v14, v14, v21
     a2c:      	fadd.4s	v13, v13, v21
     a30:      	fmul.4s	v13, v1, v13
     a34:      	fmul.4s	v14, v0, v14
     a38:      	fadd.4s	v14, v14, v25
     a3c:      	fadd.4s	v13, v13, v25
     a40:      	fmul.4s	v13, v1, v13
     a44:      	fmul.4s	v14, v0, v14
     a48:      	fadd.4s	v14, v14, v26
     a4c:      	fadd.4s	v13, v13, v26
     a50:      	fmul.4s	v13, v1, v13
     a54:      	fmul.4s	v14, v0, v14
     a58:      	fadd.4s	v14, v14, v19
     a5c:      	fadd.4s	v13, v13, v19
     a60:      	fmul.4s	v15, v1, v1
     a64:      	fmul.4s	v13, v15, v13
     a68:      	fmul.4s	v15, v0, v0
     a6c:      	fmul.4s	v14, v15, v14
     a70:      	fadd.4s	v0, v0, v14
     a74:      	fadd.4s	v1, v1, v13
     a78:      	sshr.4s	v13, v23, #0x1
     a7c:      	sshr.4s	v14, v20, #0x1
     a80:      	fadd.4s	v0, v0, v27
     a84:      	shl.4s	v15, v14, #0x17
     a88:      	add.4s	v15, v15, v27
     a8c:      	fmul.4s	v15, v0, v15
     a90:      	shl.4s	v0, v13, #0x17
     a94:      	add.4s	v0, v0, v27
     a98:      	fadd.4s	v1, v1, v27
     a9c:      	fmul.4s	v0, v1, v0
     aa0:      	sub.4s	v1, v20, v14
     aa4:      	sub.4s	v20, v23, v13
     aa8:      	shl.4s	v20, v20, #0x17
     aac:      	add.4s	v20, v20, v27
     ab0:      	fmul.4s	v20, v0, v20
     ab4:      	dup.2d	v0, x20
     ab8:      	shl.4s	v1, v1, #0x17
     abc:      	add.4s	v1, v1, v27
     ac0:      	fmul.4s	v1, v15, v1
     ac4:      	fcmgt.4s	v23, v11, v2
     ac8:      	fadd.4s	v20, v20, v27
     acc:      	bit.16b	v20, v27, v23
     ad0:      	fcmgt.4s	v23, v12, v2
     ad4:      	fadd.4s	v1, v1, v27
     ad8:      	bit.16b	v1, v27, v23
     adc:      	fcmgt.4s	v23, v3, v12
     ae0:      	bit.16b	v1, v22, v23
     ae4:      	fcmgt.4s	v23, v3, v11
     ae8:      	bit.16b	v20, v22, v23
     aec:      	fcmeq.4s	v23, v11, v11
     af0:      	bif.16b	v20, v24, v23
     af4:      	fcmeq.4s	v23, v12, v12
     af8:      	bif.16b	v1, v24, v23
     afc:      	fdiv.4s	v1, v12, v1
     b00:      	fdiv.4s	v20, v11, v20
     b04:      	add	x21, x13, x21
     b08:      	ldp	q23, q11, [x21]
     b0c:      	fmul.4s	v1, v23, v1
     b10:      	add.2d	v23, v0, v10
     b14:      	shl.2d	v23, v23, #0x2
     b18:      	add.2d	v23, v30, v23
     b1c:      	mov.d	x21, v23[1]
     b20:      	fmov	x22, d23
     b24:      	add.2d	v23, v0, v8
     b28:      	shl.2d	v23, v23, #0x2
     b2c:      	add.2d	v23, v30, v23
     b30:      	mov.d	x23, v23[1]
     b34:      	fmov	x24, d23
     b38:      	str	s1, [x22]
     b3c:      	st1.s	{ v1 }[1], [x21]
     b40:      	st1.s	{ v1 }[2], [x24]
     b44:      	fmul.4s	v20, v11, v20
     b48:      	st1.s	{ v1 }[3], [x23]
     b4c:      	add.2d	v1, v0, v9
     b50:      	shl.2d	v1, v1, #0x2
     b54:      	add.2d	v1, v30, v1
     b58:      	mov.d	x21, v1[1]
     b5c:      	fmov	x22, d1
     b60:      	add.2d	v0, v0, v31
     b64:      	shl.2d	v0, v0, #0x2
     b68:      	add.2d	v0, v30, v0
     b6c:      	mov.d	x23, v0[1]
     b70:      	fmov	x24, d0
     b74:      	str	s20, [x22]
     b78:      	st1.s	{ v20 }[1], [x21]
     b7c:      	st1.s	{ v20 }[2], [x24]
     b80:      	st1.s	{ v20 }[3], [x23]
     b84:      	add	x20, x20, #0x1
     b88:      	cmp	x20, #0x300
     b8c:      	b.ne	0x984 <ltmp0+0x984>
     b90:      	mov	x20, #0x0               ; =0
     b94:      	orr	w19, w19, #0x18
     b98:      	dup.4s	v0, w19
     b9c:      	ldp	q20, q1, [sp, #0x40]
     ba0:      	orr.16b	v1, v0, v1
     ba4:      	orr.16b	v0, v0, v20
     ba8:      	movi.4s	v20, #0x3, lsl #8
     bac:      	umull2.2d	v31, v1, v20
     bb0:      	umull2.2d	v8, v0, v20
     bb4:      	movi.2s	v20, #0x3, lsl #8
     bb8:      	umull.2d	v9, v1, v20
     bbc:      	umull.2d	v10, v0, v20
     bc0:      	dup.2d	v0, x20
     bc4:      	add.2d	v1, v0, v31
     bc8:      	add.2d	v20, v0, v9
     bcc:      	add.2d	v23, v0, v8
     bd0:      	add.2d	v0, v0, v10
     bd4:      	shl.2d	v0, v0, #0x2
     bd8:      	shl.2d	v23, v23, #0x2
     bdc:      	shl.2d	v20, v20, #0x2
     be0:      	shl.2d	v1, v1, #0x2
     be4:      	add.2d	v1, v28, v1
     be8:      	add.2d	v20, v28, v20
     bec:      	add.2d	v23, v28, v23
     bf0:      	add.2d	v0, v28, v0
     bf4:      	mov.d	x19, v0[1]
     bf8:      	fmov	x21, d0
     bfc:      	mov.d	x22, v23[1]
     c00:      	fmov	x23, d23
     c04:      	mov.d	x24, v20[1]
     c08:      	fmov	x25, d20
     c0c:      	mov.d	x26, v1[1]
     c10:      	ldr	s0, [x25]
     c14:      	ld1.s	{ v0 }[1], [x24]
     c18:      	fmov	x24, d1
     c1c:      	ld1.s	{ v0 }[2], [x24]
     c20:      	ld1.s	{ v0 }[3], [x26]
     c24:      	ldr	s1, [x21]
     c28:      	ld1.s	{ v1 }[1], [x19]
     c2c:      	ld1.s	{ v1 }[2], [x23]
     c30:      	ld1.s	{ v1 }[3], [x22]
     c34:      	add	x19, x12, x20, lsl #5
     c38:      	stp	q1, q0, [x19]
     c3c:      	add	x20, x20, #0x1
     c40:      	cmp	x20, #0x300
     c44:      	b.ne	0xbc0 <ltmp0+0xbc0>
     c48:      	mov	x19, #0x0               ; =0
     c4c:      	dup.2d	v0, x19
     c50:      	add.2d	v1, v0, v31
     c54:      	add.2d	v20, v0, v9
     c58:      	add.2d	v23, v0, v8
     c5c:      	add.2d	v0, v0, v10
     c60:      	shl.2d	v0, v0, #0x2
     c64:      	shl.2d	v23, v23, #0x2
     c68:      	shl.2d	v20, v20, #0x2
     c6c:      	shl.2d	v1, v1, #0x2
     c70:      	add.2d	v1, v29, v1
     c74:      	add.2d	v20, v29, v20
     c78:      	add.2d	v23, v29, v23
     c7c:      	add.2d	v0, v29, v0
     c80:      	mov.d	x20, v0[1]
     c84:      	fmov	x21, d0
     c88:      	mov.d	x22, v23[1]
     c8c:      	fmov	x23, d23
     c90:      	mov.d	x24, v20[1]
     c94:      	fmov	x25, d20
     c98:      	mov.d	x26, v1[1]
     c9c:      	ldr	s0, [x25]
     ca0:      	ld1.s	{ v0 }[1], [x24]
     ca4:      	fmov	x24, d1
     ca8:      	ld1.s	{ v0 }[2], [x24]
     cac:      	ld1.s	{ v0 }[3], [x26]
     cb0:      	ldr	s1, [x21]
     cb4:      	ld1.s	{ v1 }[1], [x20]
     cb8:      	ld1.s	{ v1 }[2], [x23]
     cbc:      	ld1.s	{ v1 }[3], [x22]
     cc0:      	add	x20, x13, x19, lsl #5
     cc4:      	stp	q1, q0, [x20]
     cc8:      	add	x19, x19, #0x1
     ccc:      	cmp	x19, #0x300
     cd0:      	b.ne	0xc4c <ltmp0+0xc4c>
     cd4:      	mov	x19, #0x0               ; =0
     cd8:      	lsl	x20, x19, #5
     cdc:      	add	x21, x12, x20
     ce0:      	ldp	q29, q28, [x21]
     ce4:      	fneg.4s	v0, v29
     ce8:      	fneg.4s	v1, v28
     cec:      	fcmge.4s	v20, v2, v28
     cf0:      	fcmge.4s	v23, v2, v29
     cf4:      	fcmge.4s	v11, v28, v3
     cf8:      	fcmge.4s	v12, v29, v3
     cfc:      	and.16b	v23, v23, v12
     d00:      	and.16b	v20, v20, v11
     d04:      	and.16b	v1, v20, v1
     d08:      	and.16b	v0, v23, v0
     d0c:      	fmul.4s	v20, v0, v5
     d10:      	fmul.4s	v23, v1, v5
     d14:      	mov.16b	v11, v6
     d18:      	bsl.16b	v11, v4, v23
     d1c:      	mov.16b	v12, v6
     d20:      	bsl.16b	v12, v4, v20
     d24:      	fadd.4s	v20, v20, v12
     d28:      	fadd.4s	v23, v23, v11
     d2c:      	fsub.4s	v23, v23, v11
     d30:      	fsub.4s	v20, v20, v12
     d34:      	fcvtzs.4s	v20, v20
     d38:      	fcvtzs.4s	v23, v23
     d3c:      	scvtf.4s	v11, v23
     d40:      	scvtf.4s	v12, v20
     d44:      	fmul.4s	v13, v11, v7
     d48:      	fadd.4s	v1, v1, v13
     d4c:      	fmul.4s	v13, v12, v7
     d50:      	fadd.4s	v0, v0, v13
     d54:      	fmul.4s	v11, v11, v16
     d58:      	fmul.4s	v12, v12, v16
     d5c:      	fadd.4s	v0, v0, v12
     d60:      	fadd.4s	v1, v1, v11
     d64:      	fmul.4s	v11, v1, v17
     d68:      	fmul.4s	v12, v0, v17
     d6c:      	fadd.4s	v12, v12, v18
     d70:      	fadd.4s	v11, v11, v18
     d74:      	fmul.4s	v11, v1, v11
     d78:      	fmul.4s	v12, v0, v12
     d7c:      	fadd.4s	v12, v12, v21
     d80:      	fadd.4s	v11, v11, v21
     d84:      	fmul.4s	v11, v1, v11
     d88:      	fmul.4s	v12, v0, v12
     d8c:      	fadd.4s	v12, v12, v25
     d90:      	fadd.4s	v11, v11, v25
     d94:      	fmul.4s	v11, v1, v11
     d98:      	fmul.4s	v12, v0, v12
     d9c:      	fadd.4s	v12, v12, v26
     da0:      	fadd.4s	v11, v11, v26
     da4:      	fmul.4s	v11, v1, v11
     da8:      	fmul.4s	v12, v0, v12
     dac:      	fadd.4s	v12, v12, v19
     db0:      	fadd.4s	v11, v11, v19
     db4:      	fmul.4s	v13, v1, v1
     db8:      	fmul.4s	v11, v13, v11
     dbc:      	fmul.4s	v13, v0, v0
     dc0:      	fmul.4s	v12, v13, v12
     dc4:      	fadd.4s	v0, v0, v12
     dc8:      	fadd.4s	v1, v1, v11
     dcc:      	sshr.4s	v11, v23, #0x1
     dd0:      	sshr.4s	v12, v20, #0x1
     dd4:      	fadd.4s	v0, v0, v27
     dd8:      	shl.4s	v13, v12, #0x17
     ddc:      	add.4s	v13, v13, v27
     de0:      	fmul.4s	v13, v0, v13
     de4:      	shl.4s	v0, v11, #0x17
     de8:      	add.4s	v0, v0, v27
     dec:      	fadd.4s	v1, v1, v27
     df0:      	fmul.4s	v0, v1, v0
     df4:      	sub.4s	v1, v20, v12
     df8:      	sub.4s	v20, v23, v11
     dfc:      	shl.4s	v20, v20, #0x17
     e00:      	add.4s	v20, v20, v27
     e04:      	fmul.4s	v20, v0, v20
     e08:      	dup.2d	v0, x19
     e0c:      	shl.4s	v1, v1, #0x17
     e10:      	add.4s	v1, v1, v27
     e14:      	fmul.4s	v1, v13, v1
     e18:      	fcmgt.4s	v23, v28, v2
     e1c:      	fadd.4s	v20, v20, v27
     e20:      	bit.16b	v20, v27, v23
     e24:      	fcmgt.4s	v23, v29, v2
     e28:      	fadd.4s	v1, v1, v27
     e2c:      	bit.16b	v1, v27, v23
     e30:      	fcmgt.4s	v23, v3, v29
     e34:      	bit.16b	v1, v22, v23
     e38:      	fcmgt.4s	v23, v3, v28
     e3c:      	bit.16b	v20, v22, v23
     e40:      	fcmeq.4s	v23, v28, v28
     e44:      	bif.16b	v20, v24, v23
     e48:      	fcmeq.4s	v23, v29, v29
     e4c:      	bif.16b	v1, v24, v23
     e50:      	fdiv.4s	v1, v29, v1
     e54:      	fdiv.4s	v20, v28, v20
     e58:      	add	x20, x13, x20
     e5c:      	ldp	q23, q28, [x20]
     e60:      	fmul.4s	v1, v23, v1
     e64:      	add.2d	v23, v0, v10
     e68:      	shl.2d	v23, v23, #0x2
     e6c:      	add.2d	v23, v30, v23
     e70:      	mov.d	x20, v23[1]
     e74:      	fmov	x21, d23
     e78:      	add.2d	v23, v0, v8
     e7c:      	shl.2d	v23, v23, #0x2
     e80:      	add.2d	v23, v30, v23
     e84:      	mov.d	x22, v23[1]
     e88:      	fmov	x23, d23
     e8c:      	str	s1, [x21]
     e90:      	st1.s	{ v1 }[1], [x20]
     e94:      	st1.s	{ v1 }[2], [x23]
     e98:      	fmul.4s	v20, v28, v20
     e9c:      	st1.s	{ v1 }[3], [x22]
     ea0:      	add.2d	v1, v0, v9
     ea4:      	shl.2d	v1, v1, #0x2
     ea8:      	add.2d	v1, v30, v1
     eac:      	mov.d	x20, v1[1]
     eb0:      	fmov	x21, d1
     eb4:      	add.2d	v0, v0, v31
     eb8:      	shl.2d	v0, v0, #0x2
     ebc:      	add.2d	v0, v30, v0
     ec0:      	mov.d	x22, v0[1]
     ec4:      	fmov	x23, d0
     ec8:      	str	s20, [x21]
     ecc:      	st1.s	{ v20 }[1], [x20]
     ed0:      	st1.s	{ v20 }[2], [x23]
     ed4:      	st1.s	{ v20 }[3], [x22]
     ed8:      	add	x19, x19, #0x1
     edc:      	cmp	x19, #0x300
     ee0:      	b.ne	0xcd8 <ltmp0+0xcd8>
     ee4:      	b	0xfc <ltmp0+0xfc>
     ee8:      	lsr	x19, x20, #3
     eec:      	cmp	x20, #0x8
     ef0:      	b.lo	0x1274 <ltmp0+0x1274>
     ef4:      	mov	w21, #0x0               ; =0
     ef8:      	ldr	x22, [x0]
     efc:      	ldr	x23, [x0, #0x10]
     f00:      	lsl	w24, w7, #5
     f04:      	ldr	x25, [x0, #0x30]
     f08:      	mov	x26, #0x0               ; =0
     f0c:      	add	w27, w24, w21, lsl #3
     f10:      	dup.4s	v0, w27
     f14:      	ldp	q20, q1, [sp, #0x40]
     f18:      	orr.16b	v1, v0, v1
     f1c:      	orr.16b	v0, v0, v20
     f20:      	movi.4s	v20, #0x3, lsl #8
     f24:      	umull2.2d	v28, v1, v20
     f28:      	umull2.2d	v29, v0, v20
     f2c:      	movi.2s	v20, #0x3, lsl #8
     f30:      	umull.2d	v30, v1, v20
     f34:      	umull.2d	v31, v0, v20
     f38:      	dup.2d	v0, x26
     f3c:      	add.2d	v1, v0, v28
     f40:      	add.2d	v20, v0, v30
     f44:      	add.2d	v23, v0, v29
     f48:      	add.2d	v0, v0, v31
     f4c:      	shl.2d	v0, v0, #0x2
     f50:      	shl.2d	v23, v23, #0x2
     f54:      	shl.2d	v20, v20, #0x2
     f58:      	shl.2d	v1, v1, #0x2
     f5c:      	dup.2d	v8, x22
     f60:      	add.2d	v1, v8, v1
     f64:      	add.2d	v20, v8, v20
     f68:      	add.2d	v23, v8, v23
     f6c:      	add.2d	v0, v8, v0
     f70:      	mov.d	x27, v0[1]
     f74:      	fmov	x28, d0
     f78:      	mov.d	x30, v23[1]
     f7c:      	fmov	x11, d23
     f80:      	mov.d	x2, v20[1]
     f84:      	fmov	x14, d20
     f88:      	mov.d	x16, v1[1]
     f8c:      	ldr	s0, [x14]
     f90:      	ld1.s	{ v0 }[1], [x2]
     f94:      	fmov	x14, d1
     f98:      	ld1.s	{ v0 }[2], [x14]
     f9c:      	ld1.s	{ v0 }[3], [x16]
     fa0:      	ldr	s1, [x28]
     fa4:      	ld1.s	{ v1 }[1], [x27]
     fa8:      	ld1.s	{ v1 }[2], [x11]
     fac:      	ld1.s	{ v1 }[3], [x30]
     fb0:      	add	x11, x12, x26, lsl #5
     fb4:      	stp	q1, q0, [x11]
     fb8:      	add	x26, x26, #0x1
     fbc:      	cmp	x26, #0x300
     fc0:      	b.ne	0xf38 <ltmp0+0xf38>
     fc4:      	mov	x26, #0x0               ; =0
     fc8:      	dup.2d	v0, x26
     fcc:      	add.2d	v1, v0, v28
     fd0:      	add.2d	v20, v0, v30
     fd4:      	add.2d	v23, v0, v29
     fd8:      	add.2d	v0, v0, v31
     fdc:      	shl.2d	v0, v0, #0x2
     fe0:      	shl.2d	v23, v23, #0x2
     fe4:      	shl.2d	v20, v20, #0x2
     fe8:      	shl.2d	v1, v1, #0x2
     fec:      	dup.2d	v8, x23
     ff0:      	add.2d	v1, v8, v1
     ff4:      	add.2d	v20, v8, v20
     ff8:      	add.2d	v23, v8, v23
     ffc:      	add.2d	v0, v8, v0
    1000:      	mov.d	x11, v0[1]
    1004:      	fmov	x14, d0
    1008:      	mov.d	x16, v23[1]
    100c:      	fmov	x2, d23
    1010:      	mov.d	x27, v20[1]
    1014:      	fmov	x28, d20
    1018:      	mov.d	x30, v1[1]
    101c:      	ldr	s0, [x28]
    1020:      	ld1.s	{ v0 }[1], [x27]
    1024:      	fmov	x27, d1
    1028:      	ld1.s	{ v0 }[2], [x27]
    102c:      	ld1.s	{ v0 }[3], [x30]
    1030:      	ldr	s1, [x14]
    1034:      	ld1.s	{ v1 }[1], [x11]
    1038:      	ld1.s	{ v1 }[2], [x2]
    103c:      	ld1.s	{ v1 }[3], [x16]
    1040:      	add	x11, x13, x26, lsl #5
    1044:      	stp	q1, q0, [x11]
    1048:      	add	x26, x26, #0x1
    104c:      	cmp	x26, #0x300
    1050:      	b.ne	0xfc8 <ltmp0+0xfc8>
    1054:      	mov	x26, #0x0               ; =0
    1058:      	lsl	x27, x26, #5
    105c:      	add	x11, x12, x27
    1060:      	ldp	q9, q8, [x11]
    1064:      	fneg.4s	v0, v9
    1068:      	fneg.4s	v1, v8
    106c:      	fcmge.4s	v20, v2, v8
    1070:      	fcmge.4s	v23, v2, v9
    1074:      	fcmge.4s	v10, v8, v3
    1078:      	fcmge.4s	v11, v9, v3
    107c:      	and.16b	v23, v23, v11
    1080:      	and.16b	v20, v20, v10
    1084:      	and.16b	v1, v20, v1
    1088:      	and.16b	v0, v23, v0
    108c:      	fmul.4s	v20, v0, v5
    1090:      	fmul.4s	v23, v1, v5
    1094:      	mov.16b	v10, v6
    1098:      	bsl.16b	v10, v4, v23
    109c:      	mov.16b	v11, v6
    10a0:      	bsl.16b	v11, v4, v20
    10a4:      	fadd.4s	v20, v20, v11
    10a8:      	fadd.4s	v23, v23, v10
    10ac:      	fsub.4s	v23, v23, v10
    10b0:      	fsub.4s	v20, v20, v11
    10b4:      	fcvtzs.4s	v20, v20
    10b8:      	fcvtzs.4s	v23, v23
    10bc:      	scvtf.4s	v10, v23
    10c0:      	scvtf.4s	v11, v20
    10c4:      	fmul.4s	v12, v10, v7
    10c8:      	fadd.4s	v1, v1, v12
    10cc:      	fmul.4s	v12, v11, v7
    10d0:      	fadd.4s	v0, v0, v12
    10d4:      	fmul.4s	v10, v10, v16
    10d8:      	fmul.4s	v11, v11, v16
    10dc:      	fadd.4s	v0, v0, v11
    10e0:      	fadd.4s	v1, v1, v10
    10e4:      	fmul.4s	v10, v1, v17
    10e8:      	fmul.4s	v11, v0, v17
    10ec:      	fadd.4s	v11, v11, v18
    10f0:      	fadd.4s	v10, v10, v18
    10f4:      	fmul.4s	v10, v1, v10
    10f8:      	fmul.4s	v11, v0, v11
    10fc:      	fadd.4s	v11, v11, v21
    1100:      	fadd.4s	v10, v10, v21
    1104:      	fmul.4s	v10, v1, v10
    1108:      	fmul.4s	v11, v0, v11
    110c:      	fadd.4s	v11, v11, v25
    1110:      	fadd.4s	v10, v10, v25
    1114:      	fmul.4s	v10, v1, v10
    1118:      	fmul.4s	v11, v0, v11
    111c:      	fadd.4s	v11, v11, v26
    1120:      	fadd.4s	v10, v10, v26
    1124:      	fmul.4s	v10, v1, v10
    1128:      	fmul.4s	v11, v0, v11
    112c:      	fadd.4s	v11, v11, v19
    1130:      	fadd.4s	v10, v10, v19
    1134:      	fmul.4s	v12, v1, v1
    1138:      	fmul.4s	v10, v12, v10
    113c:      	fmul.4s	v12, v0, v0
    1140:      	fmul.4s	v11, v12, v11
    1144:      	fadd.4s	v0, v0, v11
    1148:      	fadd.4s	v1, v1, v10
    114c:      	fadd.4s	v1, v1, v27
    1150:      	sshr.4s	v10, v20, #0x1
    1154:      	shl.4s	v11, v10, #0x17
    1158:      	add.4s	v11, v11, v27
    115c:      	fadd.4s	v0, v0, v27
    1160:      	fmul.4s	v0, v0, v11
    1164:      	sshr.4s	v11, v23, #0x1
    1168:      	sub.4s	v20, v20, v10
    116c:      	shl.4s	v10, v11, #0x17
    1170:      	add.4s	v10, v10, v27
    1174:      	fmul.4s	v1, v1, v10
    1178:      	sub.4s	v23, v23, v11
    117c:      	dup.2d	v10, x26
    1180:      	shl.4s	v23, v23, #0x17
    1184:      	add.4s	v23, v23, v27
    1188:      	fmul.4s	v1, v1, v23
    118c:      	add.2d	v23, v10, v28
    1190:      	shl.4s	v20, v20, #0x17
    1194:      	add.4s	v20, v20, v27
    1198:      	fmul.4s	v0, v0, v20
    119c:      	fcmgt.4s	v20, v8, v2
    11a0:      	fadd.4s	v1, v1, v27
    11a4:      	bit.16b	v1, v27, v20
    11a8:      	fcmgt.4s	v20, v9, v2
    11ac:      	fadd.4s	v0, v0, v27
    11b0:      	bit.16b	v0, v27, v20
    11b4:      	fcmgt.4s	v20, v3, v9
    11b8:      	bit.16b	v0, v22, v20
    11bc:      	fcmgt.4s	v20, v3, v8
    11c0:      	bit.16b	v1, v22, v20
    11c4:      	fcmeq.4s	v20, v8, v8
    11c8:      	bif.16b	v1, v24, v20
    11cc:      	fcmeq.4s	v20, v9, v9
    11d0:      	bif.16b	v0, v24, v20
    11d4:      	fdiv.4s	v0, v9, v0
    11d8:      	fdiv.4s	v1, v8, v1
    11dc:      	add	x11, x13, x27
    11e0:      	ldp	q20, q8, [x11]
    11e4:      	add.2d	v9, v10, v30
    11e8:      	fmul.4s	v1, v8, v1
    11ec:      	add.2d	v8, v10, v29
    11f0:      	add.2d	v10, v10, v31
    11f4:      	shl.2d	v10, v10, #0x2
    11f8:      	shl.2d	v8, v8, #0x2
    11fc:      	fmul.4s	v0, v20, v0
    1200:      	shl.2d	v20, v9, #0x2
    1204:      	shl.2d	v23, v23, #0x2
    1208:      	dup.2d	v9, x25
    120c:      	add.2d	v23, v9, v23
    1210:      	add.2d	v20, v9, v20
    1214:      	add.2d	v8, v9, v8
    1218:      	add.2d	v9, v9, v10
    121c:      	mov.d	x11, v9[1]
    1220:      	mov.d	x14, v8[1]
    1224:      	fmov	x16, d9
    1228:      	fmov	x2, d8
    122c:      	mov.d	x27, v20[1]
    1230:      	fmov	x28, d20
    1234:      	str	s0, [x16]
    1238:      	st1.s	{ v0 }[1], [x11]
    123c:      	st1.s	{ v0 }[2], [x2]
    1240:      	st1.s	{ v0 }[3], [x14]
    1244:      	mov.d	x11, v23[1]
    1248:      	fmov	x14, d23
    124c:      	str	s1, [x28]
    1250:      	st1.s	{ v1 }[1], [x27]
    1254:      	st1.s	{ v1 }[2], [x14]
    1258:      	st1.s	{ v1 }[3], [x11]
    125c:      	add	x26, x26, #0x1
    1260:      	cmp	x26, #0x300
    1264:      	b.ne	0x1058 <ltmp0+0x1058>
    1268:      	add	w21, w21, #0x1
    126c:      	cmp	w21, w19
    1270:      	b.ne	0xf08 <ltmp0+0xf08>
    1274:      	and	w20, w20, #0x7
    1278:      	mov	w2, #0xaaab             ; =43691
    127c:      	movk	w2, #0x3e2a, lsl #16
    1280:      	cbz	w20, 0xfc <ltmp0+0xfc>
    1284:      	dup.4s	v0, w20
    1288:      	ldr	q1, [sp, #0x50]
    128c:      	cmhi.4s	v20, v0, v1
    1290:      	ldr	q1, [sp, #0x40]
    1294:      	cmhi.4s	v9, v0, v1
    1298:      	str	q20, [sp, #0x60]
    129c:      	uzp1.8h	v11, v9, v20
    12a0:      	umaxv.8h	h0, v11
    12a4:      	fmov	w11, s0
    12a8:      	tbz	w11, #0x0, 0xfc <ltmp0+0xfc>
    12ac:      	mov	x21, #0x0               ; =0
    12b0:      	ldr	x22, [x0]
    12b4:      	ldr	x20, [x0, #0x10]
    12b8:      	lsl	w11, w19, #3
    12bc:      	orr	w11, w11, w7, lsl #5
    12c0:      	dup.4s	v0, w11
    12c4:      	ldr	x19, [x0, #0x30]
    12c8:      	ldp	q1, q20, [sp, #0x40]
    12cc:      	orr.16b	v1, v0, v1
    12d0:      	orr.16b	v0, v0, v20
    12d4:      	ldr	q20, [sp, #0x60]
    12d8:      	and.16b	v0, v20, v0
    12dc:      	and.16b	v1, v9, v1
    12e0:      	movi.4s	v20, #0x3, lsl #8
    12e4:      	umull2.2d	v23, v0, v20
    12e8:      	umull2.2d	v10, v1, v20
    12ec:      	movi.2s	v20, #0x3, lsl #8
    12f0:      	umull.2d	v30, v0, v20
    12f4:      	umull.2d	v20, v1, v20
    12f8:      	b	0x1320 <ltmp0+0x1320>
    12fc:      	add	x11, x12, x21, lsl #5
    1300:      	ldp	q0, q1, [x11]
    1304:      	ldr	q28, [sp, #0x60]
    1308:      	bit.16b	v1, v13, v28
    130c:      	bit.16b	v0, v12, v9
    1310:      	stp	q0, q1, [x11]
    1314:      	add	x21, x21, #0x1
    1318:      	cmp	x21, #0x300
    131c:      	b.eq	0x1420 <ltmp0+0x1420>
    1320:      	ldr	q0, [x17]
    1324:      	and.16b	v0, v11, v0
    1328:      	addv.8h	h31, v0
    132c:      	fmov	w23, s31
    1330:      	dup.2d	v14, x21
    1334:      	add.2d	v0, v14, v20
    1338:      	shl.2d	v0, v0, #0x2
    133c:      	dup.2d	v15, x22
    1340:      	add.2d	v0, v15, v0
    1344:      	movi.2d	v12, #0000000000000000
    1348:      	movi.2d	v13, #0000000000000000
    134c:      	tbnz	w23, #0x0, 0x1398 <ltmp0+0x1398>
    1350:      	and	w23, w23, #0xff
    1354:      	tbnz	w23, #0x1, 0x13a8 <ltmp0+0x13a8>
    1358:      	add.2d	v0, v14, v10
    135c:      	shl.2d	v0, v0, #0x2
    1360:      	add.2d	v0, v15, v0
    1364:      	tbnz	w23, #0x2, 0x13c0 <ltmp0+0x13c0>
    1368:      	tbnz	w23, #0x3, 0x13cc <ltmp0+0x13cc>
    136c:      	add.2d	v0, v14, v30
    1370:      	shl.2d	v0, v0, #0x2
    1374:      	add.2d	v0, v15, v0
    1378:      	tbnz	w23, #0x4, 0x13e4 <ltmp0+0x13e4>
    137c:      	tbnz	w23, #0x5, 0x13f0 <ltmp0+0x13f0>
    1380:      	add.2d	v0, v14, v23
    1384:      	shl.2d	v0, v0, #0x2
    1388:      	add.2d	v0, v15, v0
    138c:      	tbnz	w23, #0x6, 0x1408 <ltmp0+0x1408>
    1390:      	tbz	w23, #0x7, 0x12fc <ltmp0+0x12fc>
    1394:      	b	0x1414 <ltmp0+0x1414>
    1398:      	fmov	x11, d0
    139c:      	ldr	s12, [x11]
    13a0:      	and	w23, w23, #0xff
    13a4:      	tbz	w23, #0x1, 0x1358 <ltmp0+0x1358>
    13a8:      	mov.d	x11, v0[1]
    13ac:      	ld1.s	{ v12 }[1], [x11]
    13b0:      	add.2d	v0, v14, v10
    13b4:      	shl.2d	v0, v0, #0x2
    13b8:      	add.2d	v0, v15, v0
    13bc:      	tbz	w23, #0x2, 0x1368 <ltmp0+0x1368>
    13c0:      	fmov	x11, d0
    13c4:      	ld1.s	{ v12 }[2], [x11]
    13c8:      	tbz	w23, #0x3, 0x136c <ltmp0+0x136c>
    13cc:      	mov.d	x11, v0[1]
    13d0:      	ld1.s	{ v12 }[3], [x11]
    13d4:      	add.2d	v0, v14, v30
    13d8:      	shl.2d	v0, v0, #0x2
    13dc:      	add.2d	v0, v15, v0
    13e0:      	tbz	w23, #0x4, 0x137c <ltmp0+0x137c>
    13e4:      	fmov	x11, d0
    13e8:      	ld1.s	{ v13 }[0], [x11]
    13ec:      	tbz	w23, #0x5, 0x1380 <ltmp0+0x1380>
    13f0:      	mov.d	x11, v0[1]
    13f4:      	ld1.s	{ v13 }[1], [x11]
    13f8:      	add.2d	v0, v14, v23
    13fc:      	shl.2d	v0, v0, #0x2
    1400:      	add.2d	v0, v15, v0
    1404:      	tbz	w23, #0x6, 0x1390 <ltmp0+0x1390>
    1408:      	fmov	x11, d0
    140c:      	ld1.s	{ v13 }[2], [x11]
    1410:      	tbz	w23, #0x7, 0x12fc <ltmp0+0x12fc>
    1414:      	mov.d	x11, v0[1]
    1418:      	ld1.s	{ v13 }[3], [x11]
    141c:      	b	0x12fc <ltmp0+0x12fc>
    1420:      	mov	x21, #0x0               ; =0
    1424:      	b	0x144c <ltmp0+0x144c>
    1428:      	add	x11, x13, x21, lsl #5
    142c:      	ldp	q0, q1, [x11]
    1430:      	ldr	q28, [sp, #0x60]
    1434:      	bit.16b	v1, v12, v28
    1438:      	bit.16b	v0, v11, v9
    143c:      	stp	q0, q1, [x11]
    1440:      	add	x21, x21, #0x1
    1444:      	cmp	x21, #0x300
    1448:      	b.eq	0x1540 <ltmp0+0x1540>
    144c:      	fmov	w22, s31
    1450:      	dup.2d	v13, x21
    1454:      	add.2d	v0, v13, v20
    1458:      	shl.2d	v0, v0, #0x2
    145c:      	dup.2d	v14, x20
    1460:      	add.2d	v0, v14, v0
    1464:      	movi.2d	v11, #0000000000000000
    1468:      	movi.2d	v12, #0000000000000000
    146c:      	tbnz	w22, #0x0, 0x14b8 <ltmp0+0x14b8>
    1470:      	and	w22, w22, #0xff
    1474:      	tbnz	w22, #0x1, 0x14c8 <ltmp0+0x14c8>
    1478:      	add.2d	v0, v13, v10
    147c:      	shl.2d	v0, v0, #0x2
    1480:      	add.2d	v0, v14, v0
    1484:      	tbnz	w22, #0x2, 0x14e0 <ltmp0+0x14e0>
    1488:      	tbnz	w22, #0x3, 0x14ec <ltmp0+0x14ec>
    148c:      	add.2d	v0, v13, v30
    1490:      	shl.2d	v0, v0, #0x2
    1494:      	add.2d	v0, v14, v0
    1498:      	tbnz	w22, #0x4, 0x1504 <ltmp0+0x1504>
    149c:      	tbnz	w22, #0x5, 0x1510 <ltmp0+0x1510>
    14a0:      	add.2d	v0, v13, v23
    14a4:      	shl.2d	v0, v0, #0x2
    14a8:      	add.2d	v0, v14, v0
    14ac:      	tbnz	w22, #0x6, 0x1528 <ltmp0+0x1528>
    14b0:      	tbz	w22, #0x7, 0x1428 <ltmp0+0x1428>
    14b4:      	b	0x1534 <ltmp0+0x1534>
    14b8:      	fmov	x11, d0
    14bc:      	ldr	s11, [x11]
    14c0:      	and	w22, w22, #0xff
    14c4:      	tbz	w22, #0x1, 0x1478 <ltmp0+0x1478>
    14c8:      	mov.d	x11, v0[1]
    14cc:      	ld1.s	{ v11 }[1], [x11]
    14d0:      	add.2d	v0, v13, v10
    14d4:      	shl.2d	v0, v0, #0x2
    14d8:      	add.2d	v0, v14, v0
    14dc:      	tbz	w22, #0x2, 0x1488 <ltmp0+0x1488>
    14e0:      	fmov	x11, d0
    14e4:      	ld1.s	{ v11 }[2], [x11]
    14e8:      	tbz	w22, #0x3, 0x148c <ltmp0+0x148c>
    14ec:      	mov.d	x11, v0[1]
    14f0:      	ld1.s	{ v11 }[3], [x11]
    14f4:      	add.2d	v0, v13, v30
    14f8:      	shl.2d	v0, v0, #0x2
    14fc:      	add.2d	v0, v14, v0
    1500:      	tbz	w22, #0x4, 0x149c <ltmp0+0x149c>
    1504:      	fmov	x11, d0
    1508:      	ld1.s	{ v12 }[0], [x11]
    150c:      	tbz	w22, #0x5, 0x14a0 <ltmp0+0x14a0>
    1510:      	mov.d	x11, v0[1]
    1514:      	ld1.s	{ v12 }[1], [x11]
    1518:      	add.2d	v0, v13, v23
    151c:      	shl.2d	v0, v0, #0x2
    1520:      	add.2d	v0, v14, v0
    1524:      	tbz	w22, #0x6, 0x14b0 <ltmp0+0x14b0>
    1528:      	fmov	x11, d0
    152c:      	ld1.s	{ v12 }[2], [x11]
    1530:      	tbz	w22, #0x7, 0x1428 <ltmp0+0x1428>
    1534:      	mov.d	x11, v0[1]
    1538:      	ld1.s	{ v12 }[3], [x11]
    153c:      	b	0x1428 <ltmp0+0x1428>
    1540:      	stp	q23, q30, [sp, #0x20]
    1544:      	mov	x20, #0x0               ; =0
    1548:      	str	q31, [sp, #0x10]
    154c:      	b	0x155c <ltmp0+0x155c>
    1550:      	add	x20, x20, #0x1
    1554:      	cmp	x20, #0x300
    1558:      	b.eq	0xfc <ltmp0+0xfc>
    155c:      	dup.2d	v11, x20
    1560:      	fmov	w21, s31
    1564:      	mov.16b	v28, v20
    1568:      	add.2d	v20, v11, v20
    156c:      	lsl	x11, x20, #5
    1570:      	add	x14, x12, x11
    1574:      	ldp	q0, q15, [x14]
    1578:      	and.16b	v0, v9, v0
    157c:      	fneg.4s	v1, v0
    1580:      	and.16b	v1, v9, v1
    1584:      	dup.4s	v12, w1
    1588:      	fcmge.4s	v23, v1, v12
    158c:      	dup.4s	v13, w4
    1590:      	fcmge.4s	v14, v13, v1
    1594:      	and.16b	v23, v23, v14
    1598:      	and.16b	v23, v23, v1
    159c:      	fmul.4s	v14, v23, v5
    15a0:      	mov.16b	v30, v6
    15a4:      	bsl.16b	v30, v4, v14
    15a8:      	fadd.4s	v14, v14, v30
    15ac:      	fsub.4s	v30, v14, v30
    15b0:      	fcvtzs.4s	v30, v30
    15b4:      	scvtf.4s	v14, v30
    15b8:      	fmul.4s	v31, v14, v7
    15bc:      	fadd.4s	v23, v23, v31
    15c0:      	fmul.4s	v31, v14, v16
    15c4:      	fadd.4s	v23, v23, v31
    15c8:      	fmul.4s	v31, v23, v17
    15cc:      	fadd.4s	v31, v31, v18
    15d0:      	fmul.4s	v31, v23, v31
    15d4:      	fadd.4s	v31, v31, v21
    15d8:      	fmul.4s	v31, v23, v31
    15dc:      	fadd.4s	v31, v31, v25
    15e0:      	fmul.4s	v31, v23, v31
    15e4:      	fadd.4s	v31, v31, v26
    15e8:      	fmul.4s	v31, v23, v31
    15ec:      	fadd.4s	v31, v31, v19
    15f0:      	fmul.4s	v14, v23, v23
    15f4:      	fmul.4s	v31, v14, v31
    15f8:      	fadd.4s	v23, v23, v31
    15fc:      	fadd.4s	v23, v23, v27
    1600:      	sshr.4s	v31, v30, #0x1
    1604:      	shl.4s	v14, v31, #0x17
    1608:      	add.4s	v14, v14, v27
    160c:      	fmul.4s	v23, v23, v14
    1610:      	sub.4s	v30, v30, v31
    1614:      	shl.4s	v30, v30, #0x17
    1618:      	add.4s	v30, v30, v27
    161c:      	fmul.4s	v23, v23, v30
    1620:      	fcmgt.4s	v30, v12, v1
    1624:      	fcmgt.4s	v31, v1, v13
    1628:      	fcmeq.4s	v1, v1, v1
    162c:      	fadd.4s	v23, v23, v27
    1630:      	bit.16b	v23, v27, v30
    1634:      	bit.16b	v23, v22, v31
    1638:      	bsl.16b	v1, v23, v24
    163c:      	fdiv.4s	v1, v0, v1
    1640:      	add	x11, x13, x11
    1644:      	ldp	q23, q0, [x11]
    1648:      	and.16b	v23, v9, v23
    164c:      	fmul.4s	v1, v23, v1
    1650:      	shl.2d	v20, v20, #0x2
    1654:      	dup.2d	v14, x19
    1658:      	add.2d	v20, v14, v20
    165c:      	tbnz	w21, #0x0, 0x1788 <ltmp0+0x1788>
    1660:      	and	w21, w21, #0xff
    1664:      	ldr	q23, [sp, #0x30]
    1668:      	tbnz	w21, #0x1, 0x179c <ltmp0+0x179c>
    166c:      	add.2d	v20, v11, v10
    1670:      	shl.2d	v20, v20, #0x2
    1674:      	add.2d	v20, v14, v20
    1678:      	tbnz	w21, #0x2, 0x17b4 <ltmp0+0x17b4>
    167c:      	tbz	w21, #0x3, 0x1688 <ltmp0+0x1688>
    1680:      	mov.d	x11, v20[1]
    1684:      	st1.s	{ v1 }[3], [x11]
    1688:      	add.2d	v1, v11, v23
    168c:      	ldr	q29, [sp, #0x60]
    1690:      	and.16b	v20, v29, v15
    1694:      	fneg.4s	v23, v20
    1698:      	and.16b	v23, v29, v23
    169c:      	fcmge.4s	v30, v23, v12
    16a0:      	fcmge.4s	v31, v13, v23
    16a4:      	and.16b	v30, v30, v31
    16a8:      	and.16b	v30, v30, v23
    16ac:      	fmul.4s	v31, v30, v5
    16b0:      	mov.16b	v15, v6
    16b4:      	bsl.16b	v15, v4, v31
    16b8:      	fadd.4s	v31, v31, v15
    16bc:      	fsub.4s	v31, v31, v15
    16c0:      	fcvtzs.4s	v31, v31
    16c4:      	scvtf.4s	v15, v31
    16c8:      	fmul.4s	v8, v15, v7
    16cc:      	fadd.4s	v30, v30, v8
    16d0:      	fmul.4s	v8, v15, v16
    16d4:      	fadd.4s	v30, v30, v8
    16d8:      	fmul.4s	v8, v30, v17
    16dc:      	fadd.4s	v8, v8, v18
    16e0:      	fmul.4s	v8, v30, v8
    16e4:      	fadd.4s	v8, v8, v21
    16e8:      	fmul.4s	v8, v30, v8
    16ec:      	fadd.4s	v8, v8, v25
    16f0:      	fmul.4s	v8, v30, v8
    16f4:      	fadd.4s	v8, v8, v26
    16f8:      	fmul.4s	v8, v30, v8
    16fc:      	fadd.4s	v8, v8, v19
    1700:      	fmul.4s	v15, v30, v30
    1704:      	fmul.4s	v8, v15, v8
    1708:      	fadd.4s	v30, v30, v8
    170c:      	fadd.4s	v30, v30, v27
    1710:      	sshr.4s	v8, v31, #0x1
    1714:      	shl.4s	v15, v8, #0x17
    1718:      	add.4s	v15, v15, v27
    171c:      	fmul.4s	v30, v30, v15
    1720:      	sub.4s	v31, v31, v8
    1724:      	shl.4s	v31, v31, #0x17
    1728:      	add.4s	v31, v31, v27
    172c:      	fmul.4s	v30, v30, v31
    1730:      	fcmgt.4s	v31, v12, v23
    1734:      	fcmgt.4s	v8, v23, v13
    1738:      	fcmeq.4s	v23, v23, v23
    173c:      	fadd.4s	v30, v30, v27
    1740:      	bit.16b	v30, v27, v31
    1744:      	bit.16b	v30, v22, v8
    1748:      	bsl.16b	v23, v30, v24
    174c:      	fdiv.4s	v20, v20, v23
    1750:      	and.16b	v0, v29, v0
    1754:      	fmul.4s	v0, v0, v20
    1758:      	shl.2d	v1, v1, #0x2
    175c:      	add.2d	v1, v14, v1
    1760:      	tbnz	w21, #0x4, 0x17c4 <ltmp0+0x17c4>
    1764:      	ldp	q31, q23, [sp, #0x10]
    1768:      	mov.16b	v20, v28
    176c:      	tbnz	w21, #0x5, 0x17d8 <ltmp0+0x17d8>
    1770:      	add.2d	v1, v11, v23
    1774:      	shl.2d	v1, v1, #0x2
    1778:      	add.2d	v1, v14, v1
    177c:      	tbnz	w21, #0x6, 0x17f0 <ltmp0+0x17f0>
    1780:      	tbz	w21, #0x7, 0x1550 <ltmp0+0x1550>
    1784:      	b	0x17fc <ltmp0+0x17fc>
    1788:      	fmov	x11, d20
    178c:      	str	s1, [x11]
    1790:      	and	w21, w21, #0xff
    1794:      	ldr	q23, [sp, #0x30]
    1798:      	tbz	w21, #0x1, 0x166c <ltmp0+0x166c>
    179c:      	mov.d	x11, v20[1]
    17a0:      	st1.s	{ v1 }[1], [x11]
    17a4:      	add.2d	v20, v11, v10
    17a8:      	shl.2d	v20, v20, #0x2
    17ac:      	add.2d	v20, v14, v20
    17b0:      	tbz	w21, #0x2, 0x167c <ltmp0+0x167c>
    17b4:      	fmov	x11, d20
    17b8:      	st1.s	{ v1 }[2], [x11]
    17bc:      	tbnz	w21, #0x3, 0x1680 <ltmp0+0x1680>
    17c0:      	b	0x1688 <ltmp0+0x1688>
    17c4:      	fmov	x11, d1
    17c8:      	str	s0, [x11]
    17cc:      	ldp	q31, q23, [sp, #0x10]
    17d0:      	mov.16b	v20, v28
    17d4:      	tbz	w21, #0x5, 0x1770 <ltmp0+0x1770>
    17d8:      	mov.d	x11, v1[1]
    17dc:      	st1.s	{ v0 }[1], [x11]
    17e0:      	add.2d	v1, v11, v23
    17e4:      	shl.2d	v1, v1, #0x2
    17e8:      	add.2d	v1, v14, v1
    17ec:      	tbz	w21, #0x6, 0x1780 <ltmp0+0x1780>
    17f0:      	fmov	x11, d1
    17f4:      	st1.s	{ v0 }[2], [x11]
    17f8:      	tbz	w21, #0x7, 0x1550 <ltmp0+0x1550>
    17fc:      	mov.d	x11, v1[1]
    1800:      	st1.s	{ v0 }[3], [x11]
    1804:      	b	0x1550 <ltmp0+0x1550>
    1808:      	ldr	x9, [sp, #0x8]
    180c:      	stp	w7, w6, [x9]
    1810:      	str	w5, [x9, #0x8]
    1814:      	mov	w8, #0x18               ; =24
    1818:      	str	w8, [x9, #0x24]
    181c:      	add	sp, sp, #0xc, lsl #12   ; =0xc000
    1820:      	add	sp, sp, #0x80
    1824:      	ldp	x29, x30, [sp, #0x90]
    1828:      	ldp	x20, x19, [sp, #0x80]
    182c:      	ldp	x22, x21, [sp, #0x70]
    1830:      	ldp	x24, x23, [sp, #0x60]
    1834:      	ldp	x26, x25, [sp, #0x50]
    1838:      	ldp	x28, x27, [sp, #0x40]
    183c:      	ldp	d9, d8, [sp, #0x30]
    1840:      	ldp	d11, d10, [sp, #0x20]
    1844:      	ldp	d13, d12, [sp, #0x10]
    1848:      	ldp	d15, d14, [sp], #0xa0
    184c:      	ret

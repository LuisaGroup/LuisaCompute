
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/layernorm-257x1538-l1/object/tile_xir_w8_80751_1788919111239231_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	mov	x12, #0x0               ; =0
       4:      	ldr	x8, [x1, #0x88]
       8:      	ldr	x13, [x0]
       c:      	ldr	x11, [x0, #0x10]
      10:      	ldr	w9, [x1]
      14:      	ldr	w10, [x1, #0x24]
      18:      	add	w14, w10, w9, lsl #5
      1c:      	ldr	x10, [x0, #0x20]
      20:      	ldr	x9, [x0, #0x30]
      24:      	dup.4s	v0, w14
      28:      	adrp	x14, 0x0 <ltmp0>
      2c:      	ldr	q1, [x14]
      30:      	add.4s	v2, v0, v1
      34:      	adrp	x14, 0x0 <ltmp0>
      38:      	ldr	q1, [x14]
      3c:      	add.4s	v3, v0, v1
      40:      	mov	w14, #0x602             ; =1538
      44:      	dup.4s	v4, w14
      48:      	umull2.2d	v0, v2, v4
      4c:      	umull2.2d	v1, v3, v4
      50:      	umull.2d	v2, v2, v4
      54:      	umull.2d	v3, v3, v4
      58:      	dup.2d	v4, x13
      5c:      	dup.2d	v5, x12
      60:      	add.2d	v6, v5, v0
      64:      	add.2d	v7, v5, v2
      68:      	add.2d	v16, v5, v1
      6c:      	add.2d	v5, v5, v3
      70:      	shl.2d	v5, v5, #0x2
      74:      	shl.2d	v16, v16, #0x2
      78:      	shl.2d	v7, v7, #0x2
      7c:      	shl.2d	v6, v6, #0x2
      80:      	add.2d	v6, v4, v6
      84:      	add.2d	v7, v4, v7
      88:      	add.2d	v16, v4, v16
      8c:      	add.2d	v5, v4, v5
      90:      	mov.d	x13, v5[1]
      94:      	fmov	x14, d5
      98:      	mov.d	x15, v16[1]
      9c:      	fmov	x16, d16
      a0:      	mov.d	x17, v7[1]
      a4:      	fmov	x0, d7
      a8:      	mov.d	x1, v6[1]
      ac:      	ldr	s5, [x14]
      b0:      	ld1.s	{ v5 }[1], [x13]
      b4:      	fmov	x13, d6
      b8:      	ld1.s	{ v5 }[2], [x16]
      bc:      	ld1.s	{ v5 }[3], [x15]
      c0:      	ldr	s6, [x0]
      c4:      	ld1.s	{ v6 }[1], [x17]
      c8:      	ld1.s	{ v6 }[2], [x13]
      cc:      	ld1.s	{ v6 }[3], [x1]
      d0:      	add	x13, x8, x12, lsl #5
      d4:      	stp	q5, q6, [x13]
      d8:      	add	x12, x12, #0x1
      dc:      	cmp	x12, #0x602
      e0:      	b.ne	0x5c <ltmp0+0x5c>
      e4:      	ldp	q19, q18, [x8]
      e8:      	ldp	q16, q17, [x8, #0x20]
      ec:      	ldp	q4, q5, [x8, #0x40]
      f0:      	add	x12, x8, #0xe0
      f4:      	mov	w13, #0x4               ; =4
      f8:      	ldp	q7, q6, [x8, #0x60]
      fc:      	ldp	q20, q21, [x12, #-0x60]
     100:      	fadd.4s	v18, v18, v21
     104:      	fadd.4s	v19, v19, v20
     108:      	ldp	q20, q21, [x12, #-0x40]
     10c:      	fadd.4s	v17, v17, v21
     110:      	fadd.4s	v16, v16, v20
     114:      	ldp	q20, q21, [x12, #-0x20]
     118:      	fadd.4s	v5, v5, v21
     11c:      	fadd.4s	v4, v4, v20
     120:      	ldp	q20, q21, [x12], #0x80
     124:      	fadd.4s	v6, v6, v21
     128:      	fadd.4s	v7, v7, v20
     12c:      	cmp	x13, #0x5fc
     130:      	add	x13, x13, #0x4
     134:      	b.lo	0xfc <ltmp0+0xfc>
     138:      	ldr	q20, [x8, #0xc010]
     13c:      	ldr	q21, [x8, #0xc000]
     140:      	fadd.4s	v19, v19, v21
     144:      	fadd.4s	v18, v18, v20
     148:      	ldr	q20, [x8, #0xc020]
     14c:      	ldr	q21, [x8, #0xc030]
     150:      	fadd.4s	v17, v17, v21
     154:      	fadd.4s	v16, v16, v20
     158:      	movi.2d	v20, #0000000000000000
     15c:      	fadd.4s	v18, v18, v20
     160:      	fadd.4s	v19, v19, v20
     164:      	fadd.4s	v16, v19, v16
     168:      	fadd.4s	v17, v18, v17
     16c:      	fadd.4s	v5, v5, v17
     170:      	fadd.4s	v4, v4, v16
     174:      	fadd.4s	v7, v7, v4
     178:      	fadd.4s	v4, v6, v5
     17c:      	mov	w12, #0x4000            ; =16384
     180:      	movk	w12, #0x44c0, lsl #16
     184:      	dup.4s	v5, w12
     188:      	fdiv.4s	v4, v4, v5
     18c:      	fdiv.4s	v5, v7, v5
     190:      	mov	w12, #0x602             ; =1538
     194:      	mov	x13, x8
     198:      	ldp	q7, q6, [x13]
     19c:      	fsub.4s	v7, v7, v5
     1a0:      	fsub.4s	v6, v6, v4
     1a4:      	str	q6, [x13, #0xc050]
     1a8:      	str	q7, [x13, #0xc040]
     1ac:      	add	x13, x13, #0x20
     1b0:      	subs	x12, x12, #0x1
     1b4:      	b.ne	0x198 <ltmp0+0x198>
     1b8:      	ldr	q4, [x8, #0xc040]
     1bc:      	ldr	q5, [x8, #0xc050]
     1c0:      	fmul.4s	v6, v5, v5
     1c4:      	fmul.4s	v17, v4, v4
     1c8:      	ldr	q4, [x8, #0xc060]
     1cc:      	ldr	q5, [x8, #0xc070]
     1d0:      	fmul.4s	v5, v5, v5
     1d4:      	fmul.4s	v16, v4, v4
     1d8:      	ldr	q7, [x8, #0xc080]
     1dc:      	ldr	q4, [x8, #0xc090]
     1e0:      	fmul.4s	v4, v4, v4
     1e4:      	fmul.4s	v7, v7, v7
     1e8:      	ldr	q18, [x8, #0xc0a0]
     1ec:      	ldr	q19, [x8, #0xc0b0]
     1f0:      	fmul.4s	v19, v19, v19
     1f4:      	fmul.4s	v18, v18, v18
     1f8:      	mov	w12, #0xc120            ; =49440
     1fc:      	add	x12, x8, x12
     200:      	mov	w13, #0x606             ; =1542
     204:      	ldp	q21, q20, [x12, #-0x60]
     208:      	fmul.4s	v21, v21, v21
     20c:      	fmul.4s	v20, v20, v20
     210:      	fadd.4s	v6, v6, v20
     214:      	fadd.4s	v17, v17, v21
     218:      	ldp	q21, q20, [x12, #-0x40]
     21c:      	fmul.4s	v21, v21, v21
     220:      	fmul.4s	v20, v20, v20
     224:      	fadd.4s	v5, v5, v20
     228:      	fadd.4s	v16, v16, v21
     22c:      	ldp	q21, q20, [x12, #-0x20]
     230:      	fmul.4s	v21, v21, v21
     234:      	fmul.4s	v20, v20, v20
     238:      	fadd.4s	v4, v4, v20
     23c:      	fadd.4s	v7, v7, v21
     240:      	ldp	q21, q20, [x12], #0x80
     244:      	fmul.4s	v21, v21, v21
     248:      	fmul.4s	v20, v20, v20
     24c:      	fadd.4s	v19, v19, v20
     250:      	fadd.4s	v18, v18, v21
     254:      	sub	x14, x13, #0x602
     258:      	add	x13, x13, #0x4
     25c:      	cmp	x14, #0x5fc
     260:      	b.lo	0x204 <ltmp0+0x204>
     264:      	mov	x12, #0x0               ; =0
     268:      	add	x13, x8, #0x18, lsl #12 ; =0x18000
     26c:      	add	x13, x13, #0x80
     270:      	add	x14, x8, #0x18, lsl #12 ; =0x18000
     274:      	ldp	q20, q21, [x14, #0x40]!
     278:      	add	x14, x8, #0x18, lsl #12 ; =0x18000
     27c:      	ldp	q22, q23, [x14, #0x60]!
     280:      	add	x14, x11, x12, lsl #2
     284:      	ld1r.4s	{ v24 }, [x14]
     288:      	add	x14, x13, x12, lsl #5
     28c:      	stp	q24, q24, [x14]
     290:      	add	x12, x12, #0x1
     294:      	cmp	x12, #0x602
     298:      	b.ne	0x280 <ltmp0+0x280>
     29c:      	mov	x11, #0x0               ; =0
     2a0:      	add	x12, x8, #0x24, lsl #12 ; =0x24000
     2a4:      	add	x12, x12, #0xc0
     2a8:      	add	x13, x10, x11, lsl #2
     2ac:      	ld1r.4s	{ v24 }, [x13]
     2b0:      	add	x13, x12, x11, lsl #5
     2b4:      	stp	q24, q24, [x13]
     2b8:      	add	x11, x11, #0x1
     2bc:      	cmp	x11, #0x602
     2c0:      	b.ne	0x2a8 <ltmp0+0x2a8>
     2c4:      	fmul.4s	v21, v21, v21
     2c8:      	fmul.4s	v20, v20, v20
     2cc:      	fadd.4s	v17, v17, v20
     2d0:      	fadd.4s	v6, v6, v21
     2d4:      	fmul.4s	v20, v23, v23
     2d8:      	fmul.4s	v21, v22, v22
     2dc:      	fadd.4s	v16, v16, v21
     2e0:      	fadd.4s	v5, v5, v20
     2e4:      	fadd.4s	v5, v6, v5
     2e8:      	fadd.4s	v6, v17, v16
     2ec:      	fadd.4s	v6, v7, v6
     2f0:      	fadd.4s	v4, v4, v5
     2f4:      	fadd.4s	v4, v19, v4
     2f8:      	fadd.4s	v5, v18, v6
     2fc:      	mov	w10, #0x4000            ; =16384
     300:      	movk	w10, #0x44c0, lsl #16
     304:      	dup.4s	v6, w10
     308:      	fdiv.4s	v5, v5, v6
     30c:      	fdiv.4s	v4, v4, v6
     310:      	mov	w10, #0xc5ac            ; =50604
     314:      	movk	w10, #0x3727, lsl #16
     318:      	dup.4s	v6, w10
     31c:      	fadd.4s	v7, v4, v6
     320:      	fadd.4s	v4, v5, v6
     324:      	fsqrt.4s	v4, v4
     328:      	fsqrt.4s	v5, v7
     32c:      	mov	x10, #-0x602            ; =-1538
     330:      	mov	w11, #0x8080            ; =32896
     334:      	movk	w11, #0x1, lsl #16
     338:      	mov	w12, #0x40c0            ; =16576
     33c:      	movk	w12, #0x2, lsl #16
     340:      	dup.2d	v6, x9
     344:      	add	x9, x10, #0x602
     348:      	dup.2d	v7, x9
     34c:      	add.2d	v16, v7, v0
     350:      	add.2d	v17, v7, v2
     354:      	add.2d	v18, v7, v1
     358:      	add.2d	v7, v7, v3
     35c:      	ldr	q19, [x8, #0xc040]
     360:      	ldr	q20, [x8, #0xc050]
     364:      	fdiv.4s	v20, v20, v5
     368:      	fdiv.4s	v19, v19, v4
     36c:      	add	x9, x8, x11
     370:      	ldp	q22, q21, [x9]
     374:      	fmul.4s	v19, v19, v22
     378:      	fmul.4s	v20, v20, v21
     37c:      	add	x9, x8, x12
     380:      	ldp	q21, q22, [x9]
     384:      	fadd.4s	v20, v20, v22
     388:      	fadd.4s	v19, v19, v21
     38c:      	shl.2d	v7, v7, #0x2
     390:      	shl.2d	v18, v18, #0x2
     394:      	shl.2d	v17, v17, #0x2
     398:      	shl.2d	v16, v16, #0x2
     39c:      	add.2d	v16, v6, v16
     3a0:      	add.2d	v7, v6, v7
     3a4:      	mov.d	x9, v7[1]
     3a8:      	fmov	x13, d7
     3ac:      	str	s19, [x13]
     3b0:      	st1.s	{ v19 }[1], [x9]
     3b4:      	add.2d	v7, v6, v18
     3b8:      	mov.d	x9, v7[1]
     3bc:      	fmov	x13, d7
     3c0:      	st1.s	{ v19 }[2], [x13]
     3c4:      	add.2d	v7, v6, v17
     3c8:      	st1.s	{ v19 }[3], [x9]
     3cc:      	mov.d	x9, v7[1]
     3d0:      	fmov	x13, d7
     3d4:      	str	s20, [x13]
     3d8:      	st1.s	{ v20 }[1], [x9]
     3dc:      	mov.d	x9, v16[1]
     3e0:      	fmov	x13, d16
     3e4:      	st1.s	{ v20 }[2], [x13]
     3e8:      	st1.s	{ v20 }[3], [x9]
     3ec:      	add	x8, x8, #0x20
     3f0:      	adds	x10, x10, #0x1
     3f4:      	b.lo	0x344 <ltmp0+0x344>
     3f8:      	ret

00000000000003fc <_llm_rows.packet_batch.blocks>:
     3fc:      	sub	sp, sp, #0xd0
     400:      	stp	x28, x27, [sp, #0x70]
     404:      	stp	x26, x25, [sp, #0x80]
     408:      	stp	x24, x23, [sp, #0x90]
     40c:      	stp	x22, x21, [sp, #0xa0]
     410:      	stp	x20, x19, [sp, #0xb0]
     414:      	stp	x29, x30, [sp, #0xc0]
     418:      	str	x0, [sp, #0x60]
     41c:      	cbz	w3, 0xbb8 <_llm_rows.packet_batch.blocks+0x7bc>
     420:      	mov	x19, x3
     424:      	mov	x20, x2
     428:      	mov	w22, #0x0               ; =0
     42c:      	ldp	w9, w8, [x2, #0x2c]
     430:      	stp	w8, w9, [sp, #0x58]
     434:      	ldp	w27, w25, [x2]
     438:      	mov	w26, #0x8080            ; =32896
     43c:      	movk	w26, #0x1, lsl #16
     440:      	mov	w28, #0x40c0            ; =16576
     444:      	movk	w28, #0x2, lsl #16
     448:      	adrp	x8, 0x0 <ltmp0>
     44c:      	ldr	q0, [x8]
     450:      	str	q0, [sp, #0x40]
     454:      	adrp	x8, 0x0 <ltmp0>
     458:      	ldr	q0, [x8]
     45c:      	str	q0, [sp, #0x30]
     460:      	mov	w8, #0x602              ; =1538
     464:      	dup.4s	v0, w8
     468:      	str	q0, [sp, #0x10]
     46c:      	adrp	x8, 0x0 <ltmp0>
     470:      	ldr	q0, [x8]
     474:      	str	q0, [sp]
     478:      	ldp	w23, w24, [x2, #0x8]
     47c:      	str	w3, [sp, #0x2c]
     480:      	b	0x4c8 <_llm_rows.packet_batch.blocks+0xcc>
     484:      	mov	w8, #0x18               ; =24
     488:      	str	w8, [x20, #0x24]
     48c:      	ldr	w19, [sp, #0x2c]
     490:      	add	w8, w27, #0x1
     494:      	ldp	w10, w9, [sp, #0x58]
     498:      	cmp	w8, w9
     49c:      	cset	w8, eq
     4a0:      	csinc	w27, wzr, w27, eq
     4a4:      	cinc	w9, w25, eq
     4a8:      	cmp	w9, w10
     4ac:      	cset	w10, eq
     4b0:      	ands	w8, w8, w10
     4b4:      	csel	w25, wzr, w9, ne
     4b8:      	add	w23, w23, w8
     4bc:      	add	w22, w22, #0x1
     4c0:      	cmp	w22, w19
     4c4:      	b.eq	0xbb8 <_llm_rows.packet_batch.blocks+0x7bc>
     4c8:      	ubfiz	x8, x27, #5, #32
     4cc:      	cmp	x8, x24
     4d0:      	csel	x9, x8, xzr, ls
     4d4:      	subs	x10, x24, x9
     4d8:      	cmp	x10, #0x20
     4dc:      	mov	w11, #0x20              ; =32
     4e0:      	csel	x10, x10, x11, lo
     4e4:      	cmp	x24, x9
     4e8:      	stp	w27, w25, [x20]
     4ec:      	str	w23, [x20, #0x8]
     4f0:      	str	wzr, [x20, #0x24]
     4f4:      	ccmp	x8, x24, #0x2, hi
     4f8:      	csel	x21, x10, xzr, ls
     4fc:      	cmp	x21, #0x20
     500:      	b.lo	0x554 <_llm_rows.packet_batch.blocks+0x158>
     504:      	ldr	x21, [sp, #0x60]
     508:      	mov	x0, x21
     50c:      	mov	x1, x20
     510:      	bl	0x510 <_llm_rows.packet_batch.blocks+0x114>
     514:      	mov	w8, #0x8                ; =8
     518:      	str	w8, [x20, #0x24]
     51c:      	mov	x0, x21
     520:      	mov	x1, x20
     524:      	bl	0x524 <_llm_rows.packet_batch.blocks+0x128>
     528:      	mov	w8, #0x10               ; =16
     52c:      	str	w8, [x20, #0x24]
     530:      	mov	x0, x21
     534:      	mov	x1, x20
     538:      	bl	0x538 <_llm_rows.packet_batch.blocks+0x13c>
     53c:      	mov	w8, #0x18               ; =24
     540:      	str	w8, [x20, #0x24]
     544:      	mov	x0, x21
     548:      	mov	x1, x20
     54c:      	bl	0x54c <_llm_rows.packet_batch.blocks+0x150>
     550:      	b	0x490 <_llm_rows.packet_batch.blocks+0x94>
     554:      	lsr	x19, x21, #3
     558:      	cmp	x21, #0x8
     55c:      	b.lo	0x5a8 <_llm_rows.packet_batch.blocks+0x1ac>
     560:      	str	wzr, [x20, #0x24]
     564:      	ldr	x0, [sp, #0x60]
     568:      	mov	x1, x20
     56c:      	bl	0x56c <_llm_rows.packet_batch.blocks+0x170>
     570:      	cmp	x19, #0x1
     574:      	b.eq	0x5a8 <_llm_rows.packet_batch.blocks+0x1ac>
     578:      	mov	w8, #0x8                ; =8
     57c:      	str	w8, [x20, #0x24]
     580:      	ldr	x0, [sp, #0x60]
     584:      	mov	x1, x20
     588:      	bl	0x588 <_llm_rows.packet_batch.blocks+0x18c>
     58c:      	cmp	x19, #0x2
     590:      	b.eq	0x5a8 <_llm_rows.packet_batch.blocks+0x1ac>
     594:      	mov	w8, #0x10               ; =16
     598:      	str	w8, [x20, #0x24]
     59c:      	ldr	x0, [sp, #0x60]
     5a0:      	mov	x1, x20
     5a4:      	bl	0x5a4 <_llm_rows.packet_batch.blocks+0x1a8>
     5a8:      	and	w8, w21, #0x7
     5ac:      	cbz	w8, 0x484 <_llm_rows.packet_batch.blocks+0x88>
     5b0:      	dup.4s	v1, w8
     5b4:      	ldp	q0, q2, [sp, #0x30]
     5b8:      	cmhi.4s	v0, v1, v0
     5bc:      	cmhi.4s	v1, v1, v2
     5c0:      	uzp1.8h	v6, v1, v0
     5c4:      	umaxv.8h	h2, v6
     5c8:      	fmov	w8, s2
     5cc:      	tbz	w8, #0x0, 0x484 <_llm_rows.packet_batch.blocks+0x88>
     5d0:      	mov	x14, #0x0               ; =0
     5d4:      	ldr	x8, [x20, #0x88]
     5d8:      	add	x12, x8, x26
     5dc:      	add	x10, x8, x28
     5e0:      	ldr	x16, [sp, #0x60]
     5e4:      	ldr	x15, [x16]
     5e8:      	ldr	x13, [x16, #0x10]
     5ec:      	ldr	x11, [x16, #0x20]
     5f0:      	lsl	w9, w19, #3
     5f4:      	orr	w9, w9, w27, lsl #5
     5f8:      	dup.4s	v2, w9
     5fc:      	ldr	x9, [x16, #0x30]
     600:      	ldp	q4, q3, [sp, #0x30]
     604:      	orr.16b	v3, v2, v3
     608:      	orr.16b	v2, v2, v4
     60c:      	and.16b	v4, v0, v2
     610:      	and.16b	v5, v1, v3
     614:      	ldr	q7, [sp, #0x10]
     618:      	umull2.2d	v2, v4, v7
     61c:      	umull2.2d	v3, v5, v7
     620:      	umull.2d	v4, v4, v7
     624:      	umull.2d	v5, v5, v7
     628:      	ldr	q7, [sp]
     62c:      	and.16b	v6, v6, v7
     630:      	addv.8h	h6, v6
     634:      	dup.2d	v7, x15
     638:      	fmov	w15, s6
     63c:      	b	0x660 <_llm_rows.packet_batch.blocks+0x264>
     640:      	add	x16, x8, x14, lsl #5
     644:      	ldp	q18, q19, [x16]
     648:      	bif.16b	v17, v19, v0
     64c:      	bif.16b	v16, v18, v1
     650:      	stp	q16, q17, [x16]
     654:      	add	x14, x14, #0x1
     658:      	cmp	x14, #0x602
     65c:      	b.eq	0x74c <_llm_rows.packet_batch.blocks+0x350>
     660:      	dup.2d	v18, x14
     664:      	add.2d	v16, v18, v5
     668:      	shl.2d	v16, v16, #0x2
     66c:      	add.2d	v19, v7, v16
     670:      	movi.2d	v16, #0000000000000000
     674:      	movi.2d	v17, #0000000000000000
     678:      	tbnz	w15, #0x0, 0x6c4 <_llm_rows.packet_batch.blocks+0x2c8>
     67c:      	and	w16, w15, #0xff
     680:      	tbnz	w16, #0x1, 0x6d4 <_llm_rows.packet_batch.blocks+0x2d8>
     684:      	add.2d	v19, v18, v3
     688:      	shl.2d	v19, v19, #0x2
     68c:      	add.2d	v19, v7, v19
     690:      	tbnz	w16, #0x2, 0x6ec <_llm_rows.packet_batch.blocks+0x2f0>
     694:      	tbnz	w16, #0x3, 0x6f8 <_llm_rows.packet_batch.blocks+0x2fc>
     698:      	add.2d	v19, v18, v4
     69c:      	shl.2d	v19, v19, #0x2
     6a0:      	add.2d	v19, v7, v19
     6a4:      	tbnz	w16, #0x4, 0x710 <_llm_rows.packet_batch.blocks+0x314>
     6a8:      	tbnz	w16, #0x5, 0x71c <_llm_rows.packet_batch.blocks+0x320>
     6ac:      	add.2d	v18, v18, v2
     6b0:      	shl.2d	v18, v18, #0x2
     6b4:      	add.2d	v18, v7, v18
     6b8:      	tbnz	w16, #0x6, 0x734 <_llm_rows.packet_batch.blocks+0x338>
     6bc:      	tbz	w16, #0x7, 0x640 <_llm_rows.packet_batch.blocks+0x244>
     6c0:      	b	0x740 <_llm_rows.packet_batch.blocks+0x344>
     6c4:      	fmov	x16, d19
     6c8:      	ldr	s16, [x16]
     6cc:      	and	w16, w15, #0xff
     6d0:      	tbz	w16, #0x1, 0x684 <_llm_rows.packet_batch.blocks+0x288>
     6d4:      	mov.d	x17, v19[1]
     6d8:      	ld1.s	{ v16 }[1], [x17]
     6dc:      	add.2d	v19, v18, v3
     6e0:      	shl.2d	v19, v19, #0x2
     6e4:      	add.2d	v19, v7, v19
     6e8:      	tbz	w16, #0x2, 0x694 <_llm_rows.packet_batch.blocks+0x298>
     6ec:      	fmov	x17, d19
     6f0:      	ld1.s	{ v16 }[2], [x17]
     6f4:      	tbz	w16, #0x3, 0x698 <_llm_rows.packet_batch.blocks+0x29c>
     6f8:      	mov.d	x17, v19[1]
     6fc:      	ld1.s	{ v16 }[3], [x17]
     700:      	add.2d	v19, v18, v4
     704:      	shl.2d	v19, v19, #0x2
     708:      	add.2d	v19, v7, v19
     70c:      	tbz	w16, #0x4, 0x6a8 <_llm_rows.packet_batch.blocks+0x2ac>
     710:      	fmov	x17, d19
     714:      	ld1.s	{ v17 }[0], [x17]
     718:      	tbz	w16, #0x5, 0x6ac <_llm_rows.packet_batch.blocks+0x2b0>
     71c:      	mov.d	x17, v19[1]
     720:      	ld1.s	{ v17 }[1], [x17]
     724:      	add.2d	v18, v18, v2
     728:      	shl.2d	v18, v18, #0x2
     72c:      	add.2d	v18, v7, v18
     730:      	tbz	w16, #0x6, 0x6bc <_llm_rows.packet_batch.blocks+0x2c0>
     734:      	fmov	x17, d18
     738:      	ld1.s	{ v17 }[2], [x17]
     73c:      	tbz	w16, #0x7, 0x640 <_llm_rows.packet_batch.blocks+0x244>
     740:      	mov.d	x16, v18[1]
     744:      	ld1.s	{ v17 }[3], [x16]
     748:      	b	0x640 <_llm_rows.packet_batch.blocks+0x244>
     74c:      	ldp	q7, q16, [x8]
     750:      	ldp	q17, q18, [x8, #0x20]
     754:      	ldp	q23, q24, [x8, #0x40]
     758:      	and.16b	v21, v0, v16
     75c:      	and.16b	v22, v1, v7
     760:      	ldp	q25, q7, [x8, #0x60]
     764:      	and.16b	v20, v0, v18
     768:      	and.16b	v19, v1, v17
     76c:      	and.16b	v17, v0, v24
     770:      	and.16b	v16, v1, v23
     774:      	and.16b	v7, v0, v7
     778:      	and.16b	v18, v1, v25
     77c:      	add	x14, x8, #0xe0
     780:      	mov	w15, #0x4               ; =4
     784:      	ldp	q24, q23, [x14, #-0x60]
     788:      	fadd.4s	v24, v22, v24
     78c:      	fadd.4s	v23, v21, v23
     790:      	ldp	q26, q25, [x14, #-0x40]
     794:      	fadd.4s	v26, v19, v26
     798:      	fadd.4s	v25, v20, v25
     79c:      	ldp	q28, q27, [x14, #-0x20]
     7a0:      	fadd.4s	v28, v16, v28
     7a4:      	fadd.4s	v27, v17, v27
     7a8:      	ldp	q30, q29, [x14], #0x80
     7ac:      	fadd.4s	v30, v18, v30
     7b0:      	fadd.4s	v29, v7, v29
     7b4:      	bit.16b	v21, v23, v0
     7b8:      	bit.16b	v22, v24, v1
     7bc:      	bit.16b	v20, v25, v0
     7c0:      	bit.16b	v19, v26, v1
     7c4:      	bit.16b	v17, v27, v0
     7c8:      	bit.16b	v16, v28, v1
     7cc:      	bit.16b	v7, v29, v0
     7d0:      	bit.16b	v18, v30, v1
     7d4:      	cmp	x15, #0x5fc
     7d8:      	add	x15, x15, #0x4
     7dc:      	b.lo	0x784 <_llm_rows.packet_batch.blocks+0x388>
     7e0:      	ldr	q23, [x8, #0xc000]
     7e4:      	ldr	q24, [x8, #0xc010]
     7e8:      	and.16b	v24, v0, v24
     7ec:      	and.16b	v23, v1, v23
     7f0:      	fadd.4s	v22, v22, v23
     7f4:      	fadd.4s	v21, v21, v24
     7f8:      	ldr	q23, [x8, #0xc030]
     7fc:      	ldr	q24, [x8, #0xc020]
     800:      	and.16b	v24, v1, v24
     804:      	and.16b	v23, v0, v23
     808:      	fadd.4s	v20, v20, v23
     80c:      	fadd.4s	v19, v19, v24
     810:      	movi.2d	v23, #0000000000000000
     814:      	fadd.4s	v21, v21, v23
     818:      	fadd.4s	v22, v22, v23
     81c:      	fadd.4s	v19, v22, v19
     820:      	fadd.4s	v20, v21, v20
     824:      	fadd.4s	v17, v17, v20
     828:      	fadd.4s	v16, v16, v19
     82c:      	fadd.4s	v18, v18, v16
     830:      	fadd.4s	v16, v7, v17
     834:      	mov	w14, #0x4000            ; =16384
     838:      	movk	w14, #0x44c0, lsl #16
     83c:      	dup.4s	v7, w14
     840:      	fdiv.4s	v16, v16, v7
     844:      	fdiv.4s	v17, v18, v7
     848:      	mov	x14, x8
     84c:      	mov	w15, #0x602             ; =1538
     850:      	ldp	q19, q18, [x14]
     854:      	fsub.4s	v19, v19, v17
     858:      	fsub.4s	v18, v18, v16
     85c:      	ldr	q20, [x14, #0xc040]
     860:      	ldr	q21, [x14, #0xc050]
     864:      	bif.16b	v18, v21, v0
     868:      	bif.16b	v19, v20, v1
     86c:      	str	q19, [x14, #0xc040]
     870:      	str	q18, [x14, #0xc050]
     874:      	add	x14, x14, #0x20
     878:      	subs	x15, x15, #0x1
     87c:      	b.ne	0x850 <_llm_rows.packet_batch.blocks+0x454>
     880:      	ldr	q16, [x8, #0xc050]
     884:      	ldr	q17, [x8, #0xc040]
     888:      	fmul.4s	v17, v17, v17
     88c:      	fmul.4s	v16, v16, v16
     890:      	ldr	q18, [x8, #0xc070]
     894:      	ldr	q19, [x8, #0xc060]
     898:      	fmul.4s	v19, v19, v19
     89c:      	fmul.4s	v18, v18, v18
     8a0:      	ldr	q20, [x8, #0xc090]
     8a4:      	ldr	q21, [x8, #0xc080]
     8a8:      	fmul.4s	v24, v21, v21
     8ac:      	fmul.4s	v25, v20, v20
     8b0:      	ldr	q20, [x8, #0xc0b0]
     8b4:      	ldr	q21, [x8, #0xc0a0]
     8b8:      	fmul.4s	v26, v21, v21
     8bc:      	fmul.4s	v27, v20, v20
     8c0:      	and.16b	v22, v0, v16
     8c4:      	and.16b	v23, v1, v17
     8c8:      	and.16b	v20, v0, v18
     8cc:      	and.16b	v21, v1, v19
     8d0:      	and.16b	v16, v0, v25
     8d4:      	and.16b	v19, v1, v24
     8d8:      	and.16b	v18, v0, v27
     8dc:      	and.16b	v17, v1, v26
     8e0:      	mov	w14, #0xc120            ; =49440
     8e4:      	add	x14, x8, x14
     8e8:      	mov	w15, #0x606             ; =1542
     8ec:      	ldp	q25, q24, [x14, #-0x60]
     8f0:      	and.16b	v25, v1, v25
     8f4:      	and.16b	v24, v0, v24
     8f8:      	fmul.4s	v24, v24, v24
     8fc:      	fmul.4s	v25, v25, v25
     900:      	fadd.4s	v25, v23, v25
     904:      	fadd.4s	v24, v22, v24
     908:      	ldp	q27, q26, [x14, #-0x40]
     90c:      	and.16b	v27, v1, v27
     910:      	and.16b	v26, v0, v26
     914:      	fmul.4s	v26, v26, v26
     918:      	fmul.4s	v27, v27, v27
     91c:      	fadd.4s	v27, v21, v27
     920:      	fadd.4s	v26, v20, v26
     924:      	ldp	q29, q28, [x14, #-0x20]
     928:      	and.16b	v29, v1, v29
     92c:      	and.16b	v28, v0, v28
     930:      	fmul.4s	v28, v28, v28
     934:      	fmul.4s	v29, v29, v29
     938:      	fadd.4s	v29, v19, v29
     93c:      	fadd.4s	v28, v16, v28
     940:      	ldp	q31, q30, [x14], #0x80
     944:      	and.16b	v31, v1, v31
     948:      	and.16b	v30, v0, v30
     94c:      	fmul.4s	v30, v30, v30
     950:      	fmul.4s	v31, v31, v31
     954:      	fadd.4s	v31, v17, v31
     958:      	fadd.4s	v30, v18, v30
     95c:      	bit.16b	v22, v24, v0
     960:      	bit.16b	v23, v25, v1
     964:      	bit.16b	v20, v26, v0
     968:      	bit.16b	v21, v27, v1
     96c:      	bit.16b	v16, v28, v0
     970:      	bit.16b	v19, v29, v1
     974:      	bit.16b	v18, v30, v0
     978:      	bit.16b	v17, v31, v1
     97c:      	sub	x16, x15, #0x602
     980:      	add	x15, x15, #0x4
     984:      	cmp	x16, #0x5fc
     988:      	b.lo	0x8ec <_llm_rows.packet_batch.blocks+0x4f0>
     98c:      	mov	x14, #0x0               ; =0
     990:      	mov	w15, #0x8040            ; =32832
     994:      	movk	w15, #0x1, lsl #16
     998:      	add	x15, x8, x15
     99c:      	ldp	q27, q26, [x15]
     9a0:      	mov	w15, #0x8060            ; =32864
     9a4:      	movk	w15, #0x1, lsl #16
     9a8:      	add	x15, x8, x15
     9ac:      	ldp	q25, q24, [x15]
     9b0:      	add	x15, x13, x14, lsl #2
     9b4:      	ld1r.4s	{ v28 }, [x15]
     9b8:      	add	x15, x12, x14, lsl #5
     9bc:      	ldp	q29, q30, [x15]
     9c0:      	bit.16b	v30, v28, v0
     9c4:      	bif.16b	v28, v29, v1
     9c8:      	stp	q28, q30, [x15]
     9cc:      	add	x14, x14, #0x1
     9d0:      	cmp	x14, #0x602
     9d4:      	b.ne	0x9b0 <_llm_rows.packet_batch.blocks+0x5b4>
     9d8:      	mov	x12, #0x0               ; =0
     9dc:      	add	x13, x11, x12, lsl #2
     9e0:      	ld1r.4s	{ v28 }, [x13]
     9e4:      	add	x13, x10, x12, lsl #5
     9e8:      	ldp	q29, q30, [x13]
     9ec:      	bit.16b	v30, v28, v0
     9f0:      	bif.16b	v28, v29, v1
     9f4:      	stp	q28, q30, [x13]
     9f8:      	add	x12, x12, #0x1
     9fc:      	cmp	x12, #0x602
     a00:      	b.ne	0x9dc <_llm_rows.packet_batch.blocks+0x5e0>
     a04:      	and.16b	v27, v1, v27
     a08:      	and.16b	v26, v0, v26
     a0c:      	fmul.4s	v26, v26, v26
     a10:      	fmul.4s	v27, v27, v27
     a14:      	fadd.4s	v23, v23, v27
     a18:      	fadd.4s	v22, v22, v26
     a1c:      	and.16b	v25, v1, v25
     a20:      	and.16b	v24, v0, v24
     a24:      	fmul.4s	v24, v24, v24
     a28:      	fmul.4s	v25, v25, v25
     a2c:      	fadd.4s	v21, v21, v25
     a30:      	fadd.4s	v20, v20, v24
     a34:      	fadd.4s	v20, v22, v20
     a38:      	fadd.4s	v21, v23, v21
     a3c:      	fadd.4s	v19, v19, v21
     a40:      	fadd.4s	v16, v16, v20
     a44:      	fadd.4s	v16, v18, v16
     a48:      	fadd.4s	v17, v17, v19
     a4c:      	fdiv.4s	v17, v17, v7
     a50:      	fdiv.4s	v7, v16, v7
     a54:      	mov	w10, #0xc5ac            ; =50604
     a58:      	movk	w10, #0x3727, lsl #16
     a5c:      	dup.4s	v16, w10
     a60:      	fadd.4s	v7, v7, v16
     a64:      	fadd.4s	v16, v17, v16
     a68:      	fsqrt.4s	v16, v16
     a6c:      	fsqrt.4s	v7, v7
     a70:      	and.16b	v7, v0, v7
     a74:      	and.16b	v16, v1, v16
     a78:      	mov	x10, #-0x602            ; =-1538
     a7c:      	b	0xa8c <_llm_rows.packet_batch.blocks+0x690>
     a80:      	add	x8, x8, #0x20
     a84:      	adds	x10, x10, #0x1
     a88:      	b.hs	0x484 <_llm_rows.packet_batch.blocks+0x88>
     a8c:      	fmov	w11, s6
     a90:      	add	x12, x10, #0x602
     a94:      	dup.2d	v17, x12
     a98:      	add.2d	v18, v17, v5
     a9c:      	ldr	q19, [x8, #0xc050]
     aa0:      	ldr	q20, [x8, #0xc040]
     aa4:      	and.16b	v20, v1, v20
     aa8:      	fdiv.4s	v21, v20, v16
     aac:      	add	x12, x8, x26
     ab0:      	ldp	q22, q20, [x12]
     ab4:      	and.16b	v22, v1, v22
     ab8:      	fmul.4s	v22, v21, v22
     abc:      	add	x12, x8, x28
     ac0:      	ldp	q23, q21, [x12]
     ac4:      	and.16b	v23, v1, v23
     ac8:      	fadd.4s	v22, v22, v23
     acc:      	shl.2d	v23, v18, #0x2
     ad0:      	dup.2d	v18, x9
     ad4:      	add.2d	v23, v18, v23
     ad8:      	tbnz	w11, #0x0, 0xb44 <_llm_rows.packet_batch.blocks+0x748>
     adc:      	and	w11, w11, #0xff
     ae0:      	tbnz	w11, #0x1, 0xb54 <_llm_rows.packet_batch.blocks+0x758>
     ae4:      	add.2d	v23, v17, v3
     ae8:      	shl.2d	v23, v23, #0x2
     aec:      	add.2d	v23, v18, v23
     af0:      	tbnz	w11, #0x2, 0xb6c <_llm_rows.packet_batch.blocks+0x770>
     af4:      	tbz	w11, #0x3, 0xb00 <_llm_rows.packet_batch.blocks+0x704>
     af8:      	mov.d	x12, v23[1]
     afc:      	st1.s	{ v22 }[3], [x12]
     b00:      	add.2d	v22, v17, v4
     b04:      	and.16b	v19, v0, v19
     b08:      	fdiv.4s	v19, v19, v7
     b0c:      	and.16b	v20, v0, v20
     b10:      	fmul.4s	v19, v19, v20
     b14:      	and.16b	v20, v0, v21
     b18:      	fadd.4s	v19, v19, v20
     b1c:      	shl.2d	v20, v22, #0x2
     b20:      	add.2d	v20, v18, v20
     b24:      	tbnz	w11, #0x4, 0xb7c <_llm_rows.packet_batch.blocks+0x780>
     b28:      	tbnz	w11, #0x5, 0xb88 <_llm_rows.packet_batch.blocks+0x78c>
     b2c:      	add.2d	v17, v17, v2
     b30:      	shl.2d	v17, v17, #0x2
     b34:      	add.2d	v17, v18, v17
     b38:      	tbnz	w11, #0x6, 0xba0 <_llm_rows.packet_batch.blocks+0x7a4>
     b3c:      	tbz	w11, #0x7, 0xa80 <_llm_rows.packet_batch.blocks+0x684>
     b40:      	b	0xbac <_llm_rows.packet_batch.blocks+0x7b0>
     b44:      	fmov	x12, d23
     b48:      	str	s22, [x12]
     b4c:      	and	w11, w11, #0xff
     b50:      	tbz	w11, #0x1, 0xae4 <_llm_rows.packet_batch.blocks+0x6e8>
     b54:      	mov.d	x12, v23[1]
     b58:      	st1.s	{ v22 }[1], [x12]
     b5c:      	add.2d	v23, v17, v3
     b60:      	shl.2d	v23, v23, #0x2
     b64:      	add.2d	v23, v18, v23
     b68:      	tbz	w11, #0x2, 0xaf4 <_llm_rows.packet_batch.blocks+0x6f8>
     b6c:      	fmov	x12, d23
     b70:      	st1.s	{ v22 }[2], [x12]
     b74:      	tbnz	w11, #0x3, 0xaf8 <_llm_rows.packet_batch.blocks+0x6fc>
     b78:      	b	0xb00 <_llm_rows.packet_batch.blocks+0x704>
     b7c:      	fmov	x12, d20
     b80:      	str	s19, [x12]
     b84:      	tbz	w11, #0x5, 0xb2c <_llm_rows.packet_batch.blocks+0x730>
     b88:      	mov.d	x12, v20[1]
     b8c:      	st1.s	{ v19 }[1], [x12]
     b90:      	add.2d	v17, v17, v2
     b94:      	shl.2d	v17, v17, #0x2
     b98:      	add.2d	v17, v18, v17
     b9c:      	tbz	w11, #0x6, 0xb3c <_llm_rows.packet_batch.blocks+0x740>
     ba0:      	fmov	x12, d17
     ba4:      	st1.s	{ v19 }[2], [x12]
     ba8:      	tbz	w11, #0x7, 0xa80 <_llm_rows.packet_batch.blocks+0x684>
     bac:      	mov.d	x11, v17[1]
     bb0:      	st1.s	{ v19 }[3], [x11]
     bb4:      	b	0xa80 <_llm_rows.packet_batch.blocks+0x684>
     bb8:      	ldp	x29, x30, [sp, #0xc0]
     bbc:      	ldp	x20, x19, [sp, #0xb0]
     bc0:      	ldp	x22, x21, [sp, #0xa0]
     bc4:      	ldp	x24, x23, [sp, #0x90]
     bc8:      	ldp	x26, x25, [sp, #0x80]
     bcc:      	ldp	x28, x27, [sp, #0x70]
     bd0:      	add	sp, sp, #0xd0
     bd4:      	ret

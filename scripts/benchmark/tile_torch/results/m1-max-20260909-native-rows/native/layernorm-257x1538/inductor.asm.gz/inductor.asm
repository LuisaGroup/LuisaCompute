
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/layernorm-257x1538/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000750 <_kernel>:
     750:      	sub	sp, sp, #0x190
     754:      	stp	d9, d8, [sp, #0x120]
     758:      	stp	x28, x27, [sp, #0x130]
     75c:      	stp	x26, x25, [sp, #0x140]
     760:      	stp	x24, x23, [sp, #0x150]
     764:      	stp	x22, x21, [sp, #0x160]
     768:      	stp	x20, x19, [sp, #0x170]
     76c:      	stp	x29, x30, [sp, #0x180]
     770:      	add	x29, sp, #0x180
     774:      	str	x5, [sp, #0x68]
     778:      	mov	x20, x4
     77c:      	mov	x21, x3
     780:      	stp	x1, x2, [sp, #0x50]
     784:      	mov	x25, #0x0               ; =0
     788:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     78c:      	ldr	x8, [x8, #0x58]
     790:      	ldr	x8, [x8]
     794:      	stur	x8, [x29, #-0x70]
     798:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     79c:      	ldr	x9, [x9, #0xb0]
     7a0:      	str	wzr, [sp, #0x8c]
     7a4:      	add	x8, sp, #0x8c
     7a8:      	str	x8, [x9]
     7ac:      	adrp	x27, 0x8000 <dyld_stub_binder+0x8000>
     7b0:      	add	x27, x27, #0x260
     7b4:      	mov	w19, #0x1808            ; =6152
     7b8:      	adrp	x24, 0x8000 <dyld_stub_binder+0x8000>
     7bc:      	adrp	x26, 0x8000 <dyld_stub_binder+0x8000>
     7c0:      	adrp	x23, 0x4000 <dyld_stub_binder+0x4000>
     7c4:      	ldr	x23, [x23, #0x88]
     7c8:      	fmov	s8, #1.00000000
     7cc:      	mov	w28, #0x7f800000        ; =2139095040
     7d0:      	movi.2d	v9, #0000000000000000
     7d4:      	str	x0, [sp, #0x48]
     7d8:      	str	x0, [sp, #0x60]
     7dc:      	b	0x868 <_kernel+0x118>
     7e0:      	ldr	d4, [x19]
     7e4:      	ldr	d3, [x28]
     7e8:      	ldr	d2, [x24]
     7ec:      	mov	w8, #0x4000             ; =16384
     7f0:      	movk	w8, #0x44c0, lsl #16
     7f4:      	fmov	s1, w8
     7f8:      	fdiv	s0, s0, s1
     7fc:      	mov	w8, #0xc5ac             ; =50604
     800:      	movk	w8, #0x3727, lsl #16
     804:      	fmov	s1, w8
     808:      	fadd	s1, s0, s1
     80c:      	fsqrt	s0, s1
     810:      	fcmp	s0, s0
     814:      	b.vs	0x12a0 <_kernel+0xb50>
     818:      	dup.2s	v1, v5[0]
     81c:      	fdiv	s0, s8, s0
     820:      	fsub.2s	v1, v4, v1
     824:      	fmul.2s	v0, v1, v0[0]
     828:      	fmul.2s	v0, v3, v0
     82c:      	fadd.2s	v0, v2, v0
     830:      	str	d0, [x22]
     834:      	add	x25, x25, #0x1
     838:      	ldr	x8, [sp, #0x68]
     83c:      	mov	w19, #0x1808            ; =6152
     840:      	add	x8, x8, x19
     844:      	str	x8, [sp, #0x68]
     848:      	ldr	x8, [sp, #0x60]
     84c:      	add	x8, x8, x19
     850:      	str	x8, [sp, #0x60]
     854:      	cmp	x25, #0x101
     858:      	adrp	x24, 0x8000 <dyld_stub_binder+0x8000>
     85c:      	adrp	x26, 0x8000 <dyld_stub_binder+0x8000>
     860:      	mov	w28, #0x7f800000        ; =2139095040
     864:      	b.eq	0x12cc <_kernel+0xb7c>
     868:      	movi.2d	v0, #0000000000000000
     86c:      	stp	q0, q0, [sp, #0xb0]
     870:      	stp	q0, q0, [sp, #0x90]
     874:      	adrp	x8, 0x8000 <dyld_stub_binder+0x8000>
     878:      	add	x8, x8, #0x220
     87c:      	ldaprb	w8, [x8]
     880:      	tbz	w8, #0x0, 0x1190 <_kernel+0xa40>
     884:      	adrp	x8, 0x8000 <dyld_stub_binder+0x8000>
     888:      	add	x8, x8, #0x228
     88c:      	ldaprb	w8, [x8]
     890:      	tbz	w8, #0x0, 0x11ec <_kernel+0xa9c>
     894:      	adrp	x8, 0x8000 <dyld_stub_binder+0x8000>
     898:      	add	x8, x8, #0x230
     89c:      	ldaprb	w8, [x8]
     8a0:      	tbz	w8, #0x0, 0x1244 <_kernel+0xaf4>
     8a4:      	mov	x9, #0x0                ; =0
     8a8:      	mov	x22, #0x0               ; =0
     8ac:      	ldr	x8, [sp, #0x48]
     8b0:      	madd	x8, x25, x19, x8
     8b4:      	movi.2d	v21, #0000000000000000
     8b8:      	movi.2d	v20, #0000000000000000
     8bc:      	movi.2d	v19, #0000000000000000
     8c0:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
     8c4:      	add	x0, x0, #0x278
     8c8:      	b	0x8f4 <_kernel+0x1a4>
     8cc:      	ldr	s2, [x10, x22, lsl #2]
     8d0:      	fmul.4s	v2, v1, v2[0]
     8d4:      	add	x22, x22, #0x1
     8d8:      	fadd.4s	v19, v19, v2
     8dc:      	fsub.4s	v0, v0, v19
     8e0:      	fmul.4s	v0, v1, v0
     8e4:      	fadd.4s	v20, v20, v0
     8e8:      	cmp	x9, #0x5fe
     8ec:      	add	x9, x9, #0x4
     8f0:      	b.hs	0xb10 <_kernel+0x3c0>
     8f4:      	cmp	x9, #0x5ff
     8f8:      	b.hi	0xaa4 <_kernel+0x354>
     8fc:      	lsl	x10, x9, #2
     900:      	ldr	q0, [x8, x10]
     904:      	ldr	x10, [x24, #0x278]
     908:      	cbz	x10, 0xa80 <_kernel+0x330>
     90c:      	cmp	x22, #0x1, lsl #12      ; =0x1000
     910:      	b.ne	0xa80 <_kernel+0x330>
     914:      	ldr	x10, [x26, #0x260]
     918:      	ldr	x11, [x10, #0x30]
     91c:      	cbz	x11, 0x96c <_kernel+0x21c>
     920:      	ldp	q1, q2, [x10]
     924:      	fsub.4s	v3, v19, v1
     928:      	fcmeq.4s	v4, v1, v19
     92c:      	bic.16b	v3, v3, v4
     930:      	ldr	q4, [x10, #0x20]
     934:      	fadd.4s	v5, v21, v4
     938:      	fdiv.4s	v6, v21, v5
     93c:      	fcmeq.4s	v7, v5, #0.0
     940:      	bic.16b	v6, v6, v7
     944:      	fmul.4s	v7, v3, v6
     948:      	fadd.4s	v19, v1, v7
     94c:      	add	x11, x11, #0x1, lsl #12 ; =0x1000
     950:      	fadd.4s	v1, v20, v2
     954:      	fmul.4s	v2, v3, v3
     958:      	fmul.4s	v2, v4, v2
     95c:      	fmul.4s	v2, v2, v6
     960:      	fadd.4s	v20, v1, v2
     964:      	mov.16b	v21, v5
     968:      	b	0x970 <_kernel+0x220>
     96c:      	mov	w11, #0x1000            ; =4096
     970:      	stp	q19, q20, [x10]
     974:      	str	q21, [x10, #0x20]
     978:      	str	x11, [x10, #0x30]
     97c:      	ldp	x11, x10, [x0]
     980:      	add	x14, x10, #0x1
     984:      	str	x14, [x0, #0x8]
     988:      	and	x10, x10, #0x1
     98c:      	movi.2d	v19, #0000000000000000
     990:      	cmp	x11, #0x2
     994:      	ccmp	x10, #0x0, #0x4, hs
     998:      	b.eq	0xa74 <_kernel+0x324>
     99c:      	mov	x10, #0x0               ; =0
     9a0:      	ldr	x11, [x26, #0x260]
     9a4:      	mov	w12, #0x2               ; =2
     9a8:      	mov	x13, x14
     9ac:      	add	x14, x11, x10
     9b0:      	ldr	x15, [x14, #0x70]
     9b4:      	cbz	x15, 0xa14 <_kernel+0x2c4>
     9b8:      	ldr	x16, [x14, #0x30]
     9bc:      	cbz	x16, 0xa24 <_kernel+0x2d4>
     9c0:      	add	x17, x11, x10
     9c4:      	ldr	q2, [x14, #0x40]
     9c8:      	ldp	q1, q3, [x17]
     9cc:      	fsub.4s	v4, v1, v2
     9d0:      	fcmeq.4s	v1, v2, v1
     9d4:      	bic.16b	v4, v4, v1
     9d8:      	ldr	q5, [x17, #0x20]
     9dc:      	ldp	q7, q6, [x17, #0x50]
     9e0:      	fadd.4s	v1, v6, v5
     9e4:      	fdiv.4s	v5, v5, v1
     9e8:      	fcmeq.4s	v16, v1, #0.0
     9ec:      	bic.16b	v5, v5, v16
     9f0:      	fmul.4s	v16, v4, v5
     9f4:      	fadd.4s	v2, v2, v16
     9f8:      	add	x15, x16, x15
     9fc:      	fadd.4s	v3, v7, v3
     a00:      	fmul.4s	v4, v4, v4
     a04:      	fmul.4s	v4, v6, v4
     a08:      	fmul.4s	v4, v4, v5
     a0c:      	fadd.4s	v3, v3, v4
     a10:      	b	0xa30 <_kernel+0x2e0>
     a14:      	ldp	q2, q3, [x14]
     a18:      	ldr	q1, [x14, #0x20]
     a1c:      	ldr	x15, [x14, #0x30]
     a20:      	b	0xa30 <_kernel+0x2e0>
     a24:      	ldr	q2, [x14, #0x40]
     a28:      	add	x16, x11, x10
     a2c:      	ldp	q3, q1, [x16, #0x50]
     a30:      	str	q2, [x14, #0x40]
     a34:      	add	x11, x11, x10
     a38:      	stp	q3, q1, [x11, #0x50]
     a3c:      	str	x15, [x14, #0x70]
     a40:      	ldr	x11, [x27]
     a44:      	add	x14, x11, x10
     a48:      	str	xzr, [x14, #0x30]
     a4c:      	movi.2d	v1, #0000000000000000
     a50:      	stp	q1, q1, [x14, #0x10]
     a54:      	str	q1, [x14]
     a58:      	ldr	x14, [x27, #0x18]
     a5c:      	cmp	x12, x14
     a60:      	b.hs	0xa74 <_kernel+0x324>
     a64:      	lsr	x14, x13, #1
     a68:      	add	x12, x12, #0x1
     a6c:      	add	x10, x10, #0x40
     a70:      	tbz	w13, #0x1, 0x9a8 <_kernel+0x258>
     a74:      	mov	x22, #0x0               ; =0
     a78:      	movi.2d	v20, #0000000000000000
     a7c:      	movi.2d	v21, #0000000000000000
     a80:      	fmov.4s	v1, #1.00000000
     a84:      	fadd.4s	v21, v21, v1
     a88:      	fsub.4s	v1, v0, v19
     a8c:      	ldp	x10, x11, [x23]
     a90:      	sub	x11, x11, x10
     a94:      	cmp	x22, x11, asr #2
     a98:      	b.lo	0x8cc <_kernel+0x17c>
     a9c:      	fdiv.4s	v2, v1, v21
     aa0:      	b	0x8d4 <_kernel+0x184>
     aa4:      	lsl	x9, x9, #2
     aa8:      	ldr	d0, [x8, x9]
     aac:      	str	q0, [sp, #0x70]
     ab0:      	sub	x8, x29, #0xb0
     ab4:      	add	x0, sp, #0x90
     ab8:      	add	x1, sp, #0x70
     abc:      	adrp	x2, 0x8000 <dyld_stub_binder+0x8000>
     ac0:      	add	x2, x2, #0x288
     ac4:      	stp	q20, q19, [sp, #0x20]
     ac8:      	str	q21, [sp, #0x10]
     acc:      	bl	0x160c <__Z15welford_combineIN2at3vec14CPU_CAPABILITY10VectorizedIfEELy4096EE7WelfordIT_ERS7_RS6_P13WelfordHelperIS6_XT0_EE>
     ad0:      	ldp	q21, q20, [sp, #0x10]
     ad4:      	ldr	q19, [sp, #0x30]
     ad8:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     adc:      	ldr	x8, [x8, #0x98]
     ae0:      	ldr	q0, [x8]
     ae4:      	ldp	q1, q2, [x29, #-0xb0]
     ae8:      	ldp	q3, q4, [sp, #0x90]
     aec:      	bif.16b	v1, v3, v0
     af0:      	bif.16b	v2, v4, v0
     af4:      	ldur	q3, [x29, #-0x90]
     af8:      	ldr	q4, [sp, #0xb0]
     afc:      	bsl.16b	v0, v3, v4
     b00:      	ldur	x8, [x29, #-0x80]
     b04:      	stp	q1, q2, [sp, #0x90]
     b08:      	str	q0, [sp, #0xb0]
     b0c:      	str	x8, [sp, #0xc0]
     b10:      	adrp	x8, 0x8000 <dyld_stub_binder+0x8000>
     b14:      	ldr	x9, [x8, #0x250]
     b18:      	cbz	x9, 0xbac <_kernel+0x45c>
     b1c:      	mov	x8, #0x0                ; =0
     b20:      	adrp	x10, 0x8000 <dyld_stub_binder+0x8000>
     b24:      	ldr	x10, [x10, #0x238]
     b28:      	add	x10, x10, #0x8
     b2c:      	movi.2d	v0, #0000000000000000
     b30:      	movi.2d	v1, #0000000000000000
     b34:      	movi.2d	v2, #0000000000000000
     b38:      	b	0xb54 <_kernel+0x404>
     b3c:      	ldp	s2, s1, [x10, #-0x8]
     b40:      	ldr	s0, [x10]
     b44:      	ldr	x8, [x10, #0x8]
     b48:      	add	x10, x10, #0x18
     b4c:      	subs	x9, x9, #0x1
     b50:      	b.eq	0xbbc <_kernel+0x46c>
     b54:      	cbz	x8, 0xb3c <_kernel+0x3ec>
     b58:      	ldr	x11, [x10, #0x8]
     b5c:      	cbz	x11, 0xb48 <_kernel+0x3f8>
     b60:      	ldp	s3, s4, [x10, #-0x8]
     b64:      	fsub	s5, s3, s2
     b68:      	fmov	w12, s2
     b6c:      	and	w12, w12, #0x7fffffff
     b70:      	fcmp	s2, s3
     b74:      	ccmp	w12, w28, #0x0, eq
     b78:      	fcsel	s3, s9, s5, eq
     b7c:      	ldr	s5, [x10]
     b80:      	fmul	s6, s3, s3
     b84:      	fmul	s6, s0, s6
     b88:      	fadd	s0, s0, s5
     b8c:      	add	x8, x11, x8
     b90:      	fdiv	s5, s5, s0
     b94:      	fmul	s3, s3, s5
     b98:      	fadd	s2, s2, s3
     b9c:      	fadd	s1, s1, s4
     ba0:      	fmul	s3, s5, s6
     ba4:      	fadd	s1, s1, s3
     ba8:      	b	0xb48 <_kernel+0x3f8>
     bac:      	mov	x8, #0x0                ; =0
     bb0:      	movi.2d	v0, #0000000000000000
     bb4:      	movi.2d	v1, #0000000000000000
     bb8:      	movi.2d	v2, #0000000000000000
     bbc:      	ldr	x9, [x24, #0x278]
     bc0:      	cbz	x9, 0xc3c <_kernel+0x4ec>
     bc4:      	ldr	x10, [x26, #0x260]
     bc8:      	add	x10, x10, #0x20
     bcc:      	b	0xbe8 <_kernel+0x498>
     bd0:      	ldp	q19, q20, [x10, #-0x20]
     bd4:      	ldr	q21, [x10]
     bd8:      	ldr	x22, [x10, #0x10]
     bdc:      	add	x10, x10, #0x40
     be0:      	subs	x9, x9, #0x1
     be4:      	b.eq	0xc3c <_kernel+0x4ec>
     be8:      	cbz	x22, 0xbd0 <_kernel+0x480>
     bec:      	ldr	x11, [x10, #0x10]
     bf0:      	cbz	x11, 0xbdc <_kernel+0x48c>
     bf4:      	ldp	q3, q4, [x10, #-0x20]
     bf8:      	fsub.4s	v5, v3, v19
     bfc:      	fcmeq.4s	v3, v19, v3
     c00:      	bic.16b	v3, v5, v3
     c04:      	ldr	q5, [x10]
     c08:      	fmul.4s	v6, v3, v3
     c0c:      	fmul.4s	v6, v21, v6
     c10:      	fadd.4s	v21, v21, v5
     c14:      	fdiv.4s	v5, v5, v21
     c18:      	fcmeq.4s	v16, v21, #0.0
     c1c:      	bic.16b	v5, v5, v16
     c20:      	add	x22, x11, x22
     c24:      	fmul.4s	v3, v3, v5
     c28:      	fadd.4s	v19, v19, v3
     c2c:      	fadd.4s	v3, v20, v4
     c30:      	fmul.4s	v4, v6, v5
     c34:      	fadd.4s	v20, v3, v4
     c38:      	b	0xbdc <_kernel+0x48c>
     c3c:      	adrp	x9, 0x8000 <dyld_stub_binder+0x8000>
     c40:      	ldr	x9, [x9, #0x2a0]
     c44:      	cbz	x9, 0xcdc <_kernel+0x58c>
     c48:      	ldr	x10, [sp, #0xc0]
     c4c:      	adrp	x11, 0x8000 <dyld_stub_binder+0x8000>
     c50:      	ldr	x11, [x11, #0x288]
     c54:      	ldp	q4, q5, [sp, #0xa0]
     c58:      	ldr	q3, [sp, #0x90]
     c5c:      	add	x11, x11, #0x20
     c60:      	b	0xc88 <_kernel+0x538>
     c64:      	ldp	q3, q4, [x11, #-0x20]
     c68:      	ldr	q5, [x11]
     c6c:      	ldr	x10, [x11, #0x10]
     c70:      	stp	q3, q4, [sp, #0x90]
     c74:      	str	q5, [sp, #0xb0]
     c78:      	add	x11, x11, #0x40
     c7c:      	str	x10, [sp, #0xc0]
     c80:      	subs	x9, x9, #0x1
     c84:      	b.eq	0xcdc <_kernel+0x58c>
     c88:      	cbz	x10, 0xc64 <_kernel+0x514>
     c8c:      	ldr	x12, [x11, #0x10]
     c90:      	cbz	x12, 0xc70 <_kernel+0x520>
     c94:      	ldp	q6, q7, [x11, #-0x20]
     c98:      	fsub.4s	v16, v6, v3
     c9c:      	fcmeq.4s	v6, v3, v6
     ca0:      	bic.16b	v6, v16, v6
     ca4:      	ldr	q16, [x11]
     ca8:      	fmul.4s	v17, v6, v6
     cac:      	fmul.4s	v17, v5, v17
     cb0:      	fadd.4s	v5, v5, v16
     cb4:      	fdiv.4s	v16, v16, v5
     cb8:      	fcmeq.4s	v18, v5, #0.0
     cbc:      	bic.16b	v16, v16, v18
     cc0:      	add	x10, x12, x10
     cc4:      	fmul.4s	v6, v6, v16
     cc8:      	fadd.4s	v3, v3, v6
     ccc:      	fadd.4s	v4, v4, v7
     cd0:      	fmul.4s	v6, v17, v16
     cd4:      	fadd.4s	v4, v4, v6
     cd8:      	b	0xc70 <_kernel+0x520>
     cdc:      	ldr	x9, [sp, #0xc0]
     ce0:      	cbz	x9, 0xdc0 <_kernel+0x670>
     ce4:      	ldp	q4, q3, [sp, #0x90]
     ce8:      	ldr	q5, [sp, #0xb0]
     cec:      	ucvtf	s7, x9
     cf0:      	dup.4s	v6, v7[0]
     cf4:      	fcmeq.4s	v16, v5, v6
     cf8:      	adrp	x10, 0x2000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x80>
     cfc:      	ldr	q17, [x10, #0xdf0]
     d00:      	and.16b	v16, v16, v17
     d04:      	addv.4s	s16, v16
     d08:      	fmov	w10, s16
     d0c:      	cmp	w10, #0xf
     d10:      	b.ne	0xddc <_kernel+0x68c>
     d14:      	trn2.4s	v5, v3, v3
     d18:      	trn2.4s	v16, v4, v4
     d1c:      	fsub.4s	v17, v16, v4
     d20:      	fcmeq.4s	v16, v4, v16
     d24:      	fadd	s7, s7, s7
     d28:      	dup.4s	v7, v7[0]
     d2c:      	bic.16b	v16, v17, v16
     d30:      	lsl	x9, x9, #1
     d34:      	fdiv.4s	v17, v6, v7
     d38:      	fcmeq.4s	v7, v7, #0.0
     d3c:      	bic.16b	v17, v17, v7
     d40:      	fmul.4s	v7, v16, v17
     d44:      	fadd.4s	v7, v4, v7
     d48:      	fadd.4s	v3, v3, v5
     d4c:      	fmul.4s	v4, v16, v16
     d50:      	fmul.4s	v4, v4, v6[0]
     d54:      	fmul.4s	v4, v4, v17
     d58:      	fadd.4s	v6, v3, v4
     d5c:      	mov.16b	v5, v7
     d60:      	mov.s	v5[0], v7[2]
     d64:      	mov.16b	v3, v6
     d68:      	mov.s	v3[0], v6[2]
     d6c:      	cbz	x9, 0x1098 <_kernel+0x948>
     d70:      	fsub.4s	v4, v5, v7
     d74:      	fcmeq.4s	v5, v7, v5
     d78:      	bic.16b	v16, v4, v5
     d7c:      	ucvtf	s17, x9
     d80:      	dup.4s	v5, v17[0]
     d84:      	fadd	s4, s17, s17
     d88:      	dup.4s	v4, v4[0]
     d8c:      	fdiv.4s	v5, v5, v4
     d90:      	fcmeq.4s	v18, v4, #0.0
     d94:      	bic.16b	v18, v5, v18
     d98:      	fmul.4s	v5, v18, v16
     d9c:      	fadd.4s	v5, v7, v5
     da0:      	fadd.4s	v3, v6, v3
     da4:      	fmul.4s	v6, v16, v16
     da8:      	fmul.4s	v6, v6, v17[0]
     dac:      	fmul.4s	v6, v18, v6
     db0:      	fadd.4s	v3, v3, v6
     db4:      	fcvtzu	x9, s4
     db8:      	cbnz	x8, 0xe84 <_kernel+0x734>
     dbc:      	b	0x10a4 <_kernel+0x954>
     dc0:      	cbnz	x8, 0xec8 <_kernel+0x778>
     dc4:      	movi.2d	v0, #0000000000000000
     dc8:      	cbz	x22, 0x1188 <_kernel+0xa38>
     dcc:      	mov	x8, #0x0                ; =0
     dd0:      	movi.2d	v1, #0000000000000000
     dd4:      	movi.2d	v2, #0000000000000000
     dd8:      	b	0xecc <_kernel+0x77c>
     ddc:      	trn2.4s	v7, v5, v5
     de0:      	trn2.4s	v16, v3, v3
     de4:      	trn2.4s	v6, v4, v4
     de8:      	fsub.4s	v17, v6, v4
     dec:      	fcmeq.4s	v6, v4, v6
     df0:      	bic.16b	v17, v17, v6
     df4:      	fadd.4s	v6, v5, v7
     df8:      	fdiv.4s	v7, v7, v6
     dfc:      	fcmeq.4s	v18, v6, #0.0
     e00:      	bic.16b	v18, v7, v18
     e04:      	fmul.4s	v7, v17, v18
     e08:      	fadd.4s	v7, v4, v7
     e0c:      	fadd.4s	v3, v3, v16
     e10:      	fmul.4s	v4, v17, v17
     e14:      	fmul.4s	v4, v5, v4
     e18:      	fmul.4s	v4, v4, v18
     e1c:      	fadd.4s	v16, v3, v4
     e20:      	mov.16b	v5, v7
     e24:      	mov.s	v5[0], v7[2]
     e28:      	mov.16b	v3, v16
     e2c:      	mov.s	v3[0], v16[2]
     e30:      	mov.16b	v4, v6
     e34:      	mov.s	v4[0], v6[2]
     e38:      	tst	x9, #0x7fffffffffffffff
     e3c:      	b.eq	0xe7c <_kernel+0x72c>
     e40:      	fsub.4s	v17, v5, v7
     e44:      	fcmeq.4s	v5, v7, v5
     e48:      	bic.16b	v17, v17, v5
     e4c:      	fadd.4s	v18, v6, v4
     e50:      	fdiv.4s	v4, v4, v18
     e54:      	fcmeq.4s	v5, v18, #0.0
     e58:      	bic.16b	v4, v4, v5
     e5c:      	fmul.4s	v5, v4, v17
     e60:      	fadd.4s	v5, v7, v5
     e64:      	fadd.4s	v3, v16, v3
     e68:      	fmul.4s	v7, v17, v17
     e6c:      	fmul.4s	v6, v6, v7
     e70:      	fmul.4s	v4, v4, v6
     e74:      	fadd.4s	v3, v3, v4
     e78:      	mov.16b	v4, v18
     e7c:      	fcvtzu	x9, s4
     e80:      	cbz	x8, 0x10a4 <_kernel+0x954>
     e84:      	cbz	x9, 0xec8 <_kernel+0x778>
     e88:      	fsub	s6, s5, s2
     e8c:      	fmov	w10, s2
     e90:      	and	w10, w10, #0x7fffffff
     e94:      	fcmp	s2, s5
     e98:      	ccmp	w10, w28, #0x0, eq
     e9c:      	fcsel	s5, s9, s6, eq
     ea0:      	fmul	s6, s5, s5
     ea4:      	fmul	s6, s0, s6
     ea8:      	fadd	s0, s0, s4
     eac:      	add	x8, x8, x9
     eb0:      	fdiv	s4, s4, s0
     eb4:      	fmul	s5, s4, s5
     eb8:      	fadd	s2, s2, s5
     ebc:      	fadd	s1, s1, s3
     ec0:      	fmul	s3, s4, s6
     ec4:      	fadd	s1, s1, s3
     ec8:      	cbz	x22, 0x10b8 <_kernel+0x968>
     ecc:      	ucvtf	s4, x22
     ed0:      	dup.4s	v3, v4[0]
     ed4:      	fcmeq.4s	v5, v21, v3
     ed8:      	adrp	x9, 0x2000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x80>
     edc:      	ldr	q6, [x9, #0xdf0]
     ee0:      	and.16b	v5, v5, v6
     ee4:      	addv.4s	s5, v5
     ee8:      	fmov	w9, s5
     eec:      	cmp	w9, #0xf
     ef0:      	b.ne	0xf9c <_kernel+0x84c>
     ef4:      	trn2.4s	v5, v20, v20
     ef8:      	trn2.4s	v6, v19, v19
     efc:      	fsub.4s	v7, v6, v19
     f00:      	fcmeq.4s	v6, v19, v6
     f04:      	fadd	s4, s4, s4
     f08:      	dup.4s	v4, v4[0]
     f0c:      	bic.16b	v7, v7, v6
     f10:      	lsl	x9, x22, #1
     f14:      	fdiv.4s	v6, v3, v4
     f18:      	fcmeq.4s	v4, v4, #0.0
     f1c:      	bic.16b	v4, v6, v4
     f20:      	fmul.4s	v6, v7, v4
     f24:      	fadd.4s	v6, v19, v6
     f28:      	fadd.4s	v5, v20, v5
     f2c:      	fmul.4s	v7, v7, v7
     f30:      	fmul.4s	v3, v7, v3[0]
     f34:      	fmul.4s	v3, v3, v4
     f38:      	fadd.4s	v7, v5, v3
     f3c:      	mov.16b	v4, v6
     f40:      	mov.s	v4[0], v6[2]
     f44:      	mov.16b	v3, v7
     f48:      	mov.s	v3[0], v7[2]
     f4c:      	cbz	x9, 0x10c8 <_kernel+0x978>
     f50:      	fsub.4s	v5, v4, v6
     f54:      	fcmeq.4s	v4, v6, v4
     f58:      	bic.16b	v16, v5, v4
     f5c:      	ucvtf	s17, x9
     f60:      	dup.4s	v4, v17[0]
     f64:      	fadd	s5, s17, s17
     f68:      	dup.4s	v5, v5[0]
     f6c:      	fdiv.4s	v4, v4, v5
     f70:      	fcmeq.4s	v18, v5, #0.0
     f74:      	bic.16b	v18, v4, v18
     f78:      	fmul.4s	v4, v18, v16
     f7c:      	fadd.4s	v4, v6, v4
     f80:      	fadd.4s	v3, v7, v3
     f84:      	fmul.4s	v6, v16, v16
     f88:      	fmul.4s	v6, v6, v17[0]
     f8c:      	fmul.4s	v6, v18, v6
     f90:      	fadd.4s	v3, v3, v6
     f94:      	cbnz	x8, 0x1040 <_kernel+0x8f0>
     f98:      	b	0x10d0 <_kernel+0x980>
     f9c:      	trn2.4s	v3, v21, v21
     fa0:      	trn2.4s	v4, v20, v20
     fa4:      	trn2.4s	v5, v19, v19
     fa8:      	fsub.4s	v6, v5, v19
     fac:      	fcmeq.4s	v5, v19, v5
     fb0:      	bic.16b	v5, v6, v5
     fb4:      	fadd.4s	v6, v21, v3
     fb8:      	fdiv.4s	v3, v3, v6
     fbc:      	fcmeq.4s	v7, v6, #0.0
     fc0:      	bic.16b	v3, v3, v7
     fc4:      	fmul.4s	v7, v5, v3
     fc8:      	fadd.4s	v7, v19, v7
     fcc:      	fadd.4s	v4, v20, v4
     fd0:      	fmul.4s	v5, v5, v5
     fd4:      	fmul.4s	v5, v21, v5
     fd8:      	fmul.4s	v3, v5, v3
     fdc:      	fadd.4s	v16, v4, v3
     fe0:      	mov.16b	v4, v7
     fe4:      	mov.s	v4[0], v7[2]
     fe8:      	mov.16b	v3, v16
     fec:      	mov.s	v3[0], v16[2]
     ff0:      	mov.16b	v5, v6
     ff4:      	mov.s	v5[0], v6[2]
     ff8:      	tst	x22, #0x7fffffffffffffff
     ffc:      	b.eq	0x103c <_kernel+0x8ec>
    1000:      	fsub.4s	v17, v4, v7
    1004:      	fcmeq.4s	v4, v7, v4
    1008:      	bic.16b	v17, v17, v4
    100c:      	fadd.4s	v18, v6, v5
    1010:      	fdiv.4s	v4, v5, v18
    1014:      	fcmeq.4s	v5, v18, #0.0
    1018:      	bic.16b	v5, v4, v5
    101c:      	fmul.4s	v4, v5, v17
    1020:      	fadd.4s	v4, v7, v4
    1024:      	fadd.4s	v3, v16, v3
    1028:      	fmul.4s	v7, v17, v17
    102c:      	fmul.4s	v6, v6, v7
    1030:      	fmul.4s	v5, v5, v6
    1034:      	fadd.4s	v3, v3, v5
    1038:      	mov.16b	v5, v18
    103c:      	cbz	x8, 0x10d0 <_kernel+0x980>
    1040:      	fcvtzu	x8, s5
    1044:      	cbz	x8, 0x108c <_kernel+0x93c>
    1048:      	fsub	s6, s4, s2
    104c:      	fmov	w8, s2
    1050:      	and	w8, w8, #0x7fffffff
    1054:      	fcmp	s2, s4
    1058:      	ccmp	w8, w28, #0x0, eq
    105c:      	fcsel	s4, s9, s6, eq
    1060:      	fadd	s6, s0, s5
    1064:      	fdiv	s5, s5, s6
    1068:      	fmul	s6, s5, s4
    106c:      	fmul	s4, s4, s4
    1070:      	fmul	s0, s0, s4
    1074:      	fadd	s2, s2, s6
    1078:      	fadd	s1, s1, s3
    107c:      	fmul	s0, s5, s0
    1080:      	fadd	s3, s1, s0
    1084:      	mov.16b	v0, v2
    1088:      	b	0x10d4 <_kernel+0x984>
    108c:      	mov.16b	v0, v2
    1090:      	mov.16b	v3, v1
    1094:      	b	0x10d4 <_kernel+0x984>
    1098:      	movi.2d	v4, #0000000000000000
    109c:      	fcvtzu	x9, s4
    10a0:      	cbnz	x8, 0xe84 <_kernel+0x734>
    10a4:      	mov.16b	v2, v5
    10a8:      	mov.16b	v1, v3
    10ac:      	mov.16b	v0, v4
    10b0:      	mov	x8, x9
    10b4:      	cbnz	x22, 0xecc <_kernel+0x77c>
    10b8:      	cmp	x8, #0x0
    10bc:      	fcsel	s0, s9, s2, eq
    10c0:      	fcsel	s3, s9, s1, eq
    10c4:      	b	0x10d4 <_kernel+0x984>
    10c8:      	movi.2d	v5, #0000000000000000
    10cc:      	cbnz	x8, 0x1040 <_kernel+0x8f0>
    10d0:      	mov.16b	v0, v4
    10d4:      	str	s0, [x21, x25, lsl #2]
    10d8:      	str	s3, [x20, x25, lsl #2]
    10dc:      	mov	x26, #-0x4              ; =-4
    10e0:      	ldp	x28, x24, [sp, #0x50]
    10e4:      	ldp	x19, x22, [sp, #0x60]
    10e8:      	add	x8, x26, #0x4
    10ec:      	ldr	s0, [x20, x25, lsl #2]
    10f0:      	ldr	s5, [x21, x25, lsl #2]
    10f4:      	cmp	x8, #0x600
    10f8:      	b.hs	0x7e0 <_kernel+0x90>
    10fc:      	ldr	q4, [x19]
    1100:      	ldr	q2, [x28]
    1104:      	ldr	q3, [x24]
    1108:      	mov	w8, #0x4000             ; =16384
    110c:      	movk	w8, #0x44c0, lsl #16
    1110:      	fmov	s1, w8
    1114:      	fdiv	s0, s0, s1
    1118:      	mov	w8, #0xc5ac             ; =50604
    111c:      	movk	w8, #0x3727, lsl #16
    1120:      	fmov	s1, w8
    1124:      	fadd	s1, s0, s1
    1128:      	fsqrt	s0, s1
    112c:      	fcmp	s0, s0
    1130:      	b.vs	0x116c <_kernel+0xa1c>
    1134:      	dup.4s	v1, v5[0]
    1138:      	fsub.4s	v1, v4, v1
    113c:      	fdiv	s0, s8, s0
    1140:      	fmul.4s	v0, v1, v0[0]
    1144:      	fmul.4s	v0, v2, v0
    1148:      	fadd.4s	v0, v3, v0
    114c:      	str	q0, [x22], #0x10
    1150:      	add	x19, x19, #0x10
    1154:      	add	x28, x28, #0x10
    1158:      	add	x24, x24, #0x10
    115c:      	add	x26, x26, #0x4
    1160:      	cmp	x26, #0x5fe
    1164:      	b.lo	0x10e8 <_kernel+0x998>
    1168:      	b	0x834 <_kernel+0xe4>
    116c:      	mov.16b	v0, v1
    1170:      	stp	q2, q5, [sp, #0x20]
    1174:      	stp	q4, q3, [sp]
    1178:      	bl	0x2be0 <dyld_stub_binder+0x2be0>
    117c:      	ldp	q4, q3, [sp]
    1180:      	ldp	q2, q5, [sp, #0x20]
    1184:      	b	0x1134 <_kernel+0x9e4>
    1188:      	movi.2d	v3, #0000000000000000
    118c:      	b	0x10d4 <_kernel+0x984>
    1190:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    1194:      	add	x0, x0, #0x220
    1198:      	bl	0x2b74 <dyld_stub_binder+0x2b74>
    119c:      	cbz	w0, 0x884 <_kernel+0x134>
    11a0:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    11a4:      	add	x0, x0, #0x238
    11a8:      	mov	w1, #0x602              ; =1538
    11ac:      	bl	0x1430 <__ZN13WelfordHelperIfLy4096EEC1Ey>
    11b0:      	adrp	x19, 0x8000 <dyld_stub_binder+0x8000>
    11b4:      	add	x19, x19, #0x220
    11b8:      	add	x1, x19, #0x18
    11bc:      	adrp	x0, 0x1000 <_kernel+0x8b0>
    11c0:      	add	x0, x0, #0x4cc
    11c4:      	adrp	x2, 0x0 <dyld_stub_binder>
    11c8:      	add	x2, x2, #0x0
    11cc:      	bl	0x2b38 <dyld_stub_binder+0x2b38>
    11d0:      	mov	x0, x19
    11d4:      	bl	0x2b80 <dyld_stub_binder+0x2b80>
    11d8:      	mov	w19, #0x1808            ; =6152
    11dc:      	adrp	x24, 0x8000 <dyld_stub_binder+0x8000>
    11e0:      	adrp	x26, 0x8000 <dyld_stub_binder+0x8000>
    11e4:      	mov	w28, #0x7f800000        ; =2139095040
    11e8:      	b	0x884 <_kernel+0x134>
    11ec:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    11f0:      	add	x0, x0, #0x228
    11f4:      	bl	0x2b74 <dyld_stub_binder+0x2b74>
    11f8:      	cbz	w0, 0x894 <_kernel+0x144>
    11fc:      	mov	x0, x27
    1200:      	mov	w1, #0x180              ; =384
    1204:      	bl	0x1508 <__ZN13WelfordHelperIN2at3vec14CPU_CAPABILITY10VectorizedIfEELy4096EEC1Ey>
    1208:      	adrp	x19, 0x8000 <dyld_stub_binder+0x8000>
    120c:      	add	x19, x19, #0x228
    1210:      	add	x1, x19, #0x38
    1214:      	adrp	x0, 0x1000 <_kernel+0x8b0>
    1218:      	add	x0, x0, #0x5d0
    121c:      	adrp	x2, 0x0 <dyld_stub_binder>
    1220:      	add	x2, x2, #0x0
    1224:      	bl	0x2b38 <dyld_stub_binder+0x2b38>
    1228:      	mov	x0, x19
    122c:      	bl	0x2b80 <dyld_stub_binder+0x2b80>
    1230:      	mov	w19, #0x1808            ; =6152
    1234:      	adrp	x24, 0x8000 <dyld_stub_binder+0x8000>
    1238:      	adrp	x26, 0x8000 <dyld_stub_binder+0x8000>
    123c:      	mov	w28, #0x7f800000        ; =2139095040
    1240:      	b	0x894 <_kernel+0x144>
    1244:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    1248:      	add	x0, x0, #0x230
    124c:      	bl	0x2b74 <dyld_stub_binder+0x2b74>
    1250:      	cbz	w0, 0x8a4 <_kernel+0x154>
    1254:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    1258:      	add	x0, x0, #0x288
    125c:      	mov	w1, #0x1                ; =1
    1260:      	bl	0x1508 <__ZN13WelfordHelperIN2at3vec14CPU_CAPABILITY10VectorizedIfEELy4096EEC1Ey>
    1264:      	adrp	x19, 0x8000 <dyld_stub_binder+0x8000>
    1268:      	add	x19, x19, #0x230
    126c:      	add	x1, x19, #0x58
    1270:      	adrp	x0, 0x1000 <_kernel+0x8b0>
    1274:      	add	x0, x0, #0x5d0
    1278:      	adrp	x2, 0x0 <dyld_stub_binder>
    127c:      	add	x2, x2, #0x0
    1280:      	bl	0x2b38 <dyld_stub_binder+0x2b38>
    1284:      	mov	x0, x19
    1288:      	bl	0x2b80 <dyld_stub_binder+0x2b80>
    128c:      	mov	w19, #0x1808            ; =6152
    1290:      	adrp	x24, 0x8000 <dyld_stub_binder+0x8000>
    1294:      	adrp	x26, 0x8000 <dyld_stub_binder+0x8000>
    1298:      	mov	w28, #0x7f800000        ; =2139095040
    129c:      	b	0x8a4 <_kernel+0x154>
    12a0:      	mov.16b	v0, v1
    12a4:      	str	d3, [sp, #0x20]
    12a8:      	str	d2, [sp]
    12ac:      	str	d4, [sp, #0x10]
    12b0:      	str	q5, [sp, #0x30]
    12b4:      	bl	0x2be0 <dyld_stub_binder+0x2be0>
    12b8:      	ldr	q5, [sp, #0x30]
    12bc:      	ldr	d4, [sp, #0x10]
    12c0:      	ldr	d2, [sp]
    12c4:      	ldr	d3, [sp, #0x20]
    12c8:      	b	0x818 <_kernel+0xc8>
    12cc:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
    12d0:      	ldr	x8, [x8, #0xb0]
    12d4:      	str	xzr, [x8]
    12d8:      	add	x8, sp, #0x8c
    12dc:      	ldapr	w8, [x8]
    12e0:      	cbnz	w8, 0x1320 <_kernel+0xbd0>
    12e4:      	ldur	x8, [x29, #-0x70]
    12e8:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
    12ec:      	ldr	x9, [x9, #0x58]
    12f0:      	ldr	x9, [x9]
    12f4:      	cmp	x9, x8
    12f8:      	b.ne	0x13a4 <_kernel+0xc54>
    12fc:      	ldp	x29, x30, [sp, #0x180]
    1300:      	ldp	x20, x19, [sp, #0x170]
    1304:      	ldp	x22, x21, [sp, #0x160]
    1308:      	ldp	x24, x23, [sp, #0x150]
    130c:      	ldp	x26, x25, [sp, #0x140]
    1310:      	ldp	x28, x27, [sp, #0x130]
    1314:      	ldp	d9, d8, [sp, #0x120]
    1318:      	add	sp, sp, #0x190
    131c:      	ret
    1320:      	mov	w0, #0x10               ; =16
    1324:      	bl	0x2b2c <dyld_stub_binder+0x2b2c>
    1328:      	mov	x19, x0
    132c:      	mov	w8, #0x33d              ; =829
    1330:      	str	w8, [sp, #0x90]
    1334:      	adrp	x0, 0x2000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x80>
    1338:      	add	x0, x0, #0xf6f
    133c:      	adrp	x1, 0x2000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x80>
    1340:      	add	x1, x1, #0xffb
    1344:      	adrp	x3, 0x3000 <dyld_stub_binder+0x3000>
    1348:      	add	x3, x3, #0x26
    134c:      	adrp	x4, 0x3000 <dyld_stub_binder+0x3000>
    1350:      	add	x4, x4, #0xa4
    1354:      	adrp	x2, 0x3000 <dyld_stub_binder+0x3000>
    1358:      	add	x2, x2, #0x23
    135c:      	sub	x8, x29, #0xb0
    1360:      	add	x5, sp, #0x90
    1364:      	adrp	x7, 0x3000 <dyld_stub_binder+0x3000>
    1368:      	add	x7, x7, #0xa6
    136c:      	mov	x6, x2
    1370:      	bl	0x1bbc <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
    1374:      	mov	w21, #0x1               ; =1
    1378:      	sub	x1, x29, #0xb0
    137c:      	mov	x0, x19
    1380:      	bl	0x2a78 <dyld_stub_binder+0x2a78>
    1384:      	mov	w21, #0x0               ; =0
    1388:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
    138c:      	ldr	x1, [x1, #0x18]
    1390:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
    1394:      	ldr	x2, [x2, #0x8]
    1398:      	mov	x0, x19
    139c:      	bl	0x2b8c <dyld_stub_binder+0x2b8c>
    13a0:      	brk	#0x1
    13a4:      	bl	0x2ba4 <dyld_stub_binder+0x2ba4>
    13a8:      	mov	x20, x0
    13ac:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    13b0:      	add	x0, x0, #0x230
    13b4:      	bl	0x2b68 <dyld_stub_binder+0x2b68>
    13b8:      	mov	x0, x20
    13bc:      	bl	0x2a3c <dyld_stub_binder+0x2a3c>
    13c0:      	mov	x20, x0
    13c4:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    13c8:      	add	x0, x0, #0x228
    13cc:      	bl	0x2b68 <dyld_stub_binder+0x2b68>
    13d0:      	mov	x0, x20
    13d4:      	bl	0x2a3c <dyld_stub_binder+0x2a3c>
    13d8:      	mov	x20, x0
    13dc:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    13e0:      	add	x0, x0, #0x220
    13e4:      	bl	0x2b68 <dyld_stub_binder+0x2b68>
    13e8:      	mov	x0, x20
    13ec:      	bl	0x2a3c <dyld_stub_binder+0x2a3c>
    13f0:      	mov	x20, x0
    13f4:      	ldursb	w8, [x29, #-0x99]
    13f8:      	tbz	w8, #0x1f, 0x1414 <_kernel+0xcc4>
    13fc:      	ldur	x0, [x29, #-0xb0]
    1400:      	ldur	x8, [x29, #-0xa0]
    1404:      	and	x1, x8, #0x7fffffffffffffff
    1408:      	bl	0x2b14 <dyld_stub_binder+0x2b14>
    140c:      	tbnz	w21, #0x0, 0x1420 <_kernel+0xcd0>
    1410:      	b	0x1428 <_kernel+0xcd8>
    1414:      	cbnz	w21, 0x1420 <_kernel+0xcd0>
    1418:      	b	0x1428 <_kernel+0xcd8>
    141c:      	mov	x20, x0
    1420:      	mov	x0, x19
    1424:      	bl	0x2b5c <dyld_stub_binder+0x2b5c>
    1428:      	mov	x0, x20
    142c:      	bl	0x2a3c <dyld_stub_binder+0x2a3c>

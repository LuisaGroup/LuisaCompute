
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/gelu_residual-129x768/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0xa0
     6b4:      	stp	x24, x23, [sp, #0x60]
     6b8:      	stp	x22, x21, [sp, #0x70]
     6bc:      	stp	x20, x19, [sp, #0x80]
     6c0:      	stp	x29, x30, [sp, #0x90]
     6c4:      	add	x29, sp, #0x90
     6c8:      	mov	x19, x2
     6cc:      	mov	x20, x1
     6d0:      	mov	x21, x0
     6d4:      	str	wzr, [sp, #0x40]
     6d8:      	adrp	x22, 0x4000 <dyld_stub_binder+0x4000>
     6dc:      	ldr	x22, [x22, #0x90]
     6e0:      	add	x8, sp, #0x40
     6e4:      	str	x8, [x22]
     6e8:      	mov	x23, #-0x4              ; =-4
     6ec:      	mov	w8, #0x2713             ; =10003
     6f0:      	movk	w8, #0x3d37, lsl #16
     6f4:      	dup.4s	v1, w8
     6f8:      	mov	w8, #0x422a             ; =16938
     6fc:      	movk	w8, #0x3f4c, lsl #16
     700:      	dup.4s	v0, w8
     704:      	stp	q0, q1, [sp]
     708:      	mov	w24, #0x82fc            ; =33532
     70c:      	movk	w24, #0x1, lsl #16
     710:      	ldr	q0, [x21], #0x10
     714:      	ldr	q2, [x20], #0x10
     718:      	movi.4s	v1, #0x3f, lsl #24
     71c:      	fmul.4s	v1, v0, v1
     720:      	stp	q1, q2, [sp, #0x20]
     724:      	fmul.4s	v1, v0, v0
     728:      	fmul.4s	v1, v0, v1
     72c:      	ldr	q2, [sp, #0x10]
     730:      	fmul.4s	v1, v1, v2
     734:      	fadd.4s	v0, v0, v1
     738:      	ldr	q1, [sp]
     73c:      	fmul.4s	v0, v0, v1
     740:      	bl	0x1580 <dyld_stub_binder+0x1580>
     744:      	fmov.4s	v1, #1.00000000
     748:      	fadd.4s	v0, v0, v1
     74c:      	ldp	q2, q1, [sp, #0x20]
     750:      	fmul.4s	v0, v2, v0
     754:      	fadd.4s	v0, v1, v0
     758:      	str	q0, [x19], #0x10
     75c:      	add	x23, x23, #0x4
     760:      	cmp	x23, x24
     764:      	b.lo	0x710 <_kernel+0x60>
     768:      	str	xzr, [x22]
     76c:      	add	x8, sp, #0x40
     770:      	ldapr	w8, [x8]
     774:      	cbnz	w8, 0x790 <_kernel+0xe0>
     778:      	ldp	x29, x30, [sp, #0x90]
     77c:      	ldp	x20, x19, [sp, #0x80]
     780:      	ldp	x22, x21, [sp, #0x70]
     784:      	ldp	x24, x23, [sp, #0x60]
     788:      	add	sp, sp, #0xa0
     78c:      	ret
     790:      	mov	w0, #0x10               ; =16
     794:      	bl	0x167c <dyld_stub_binder+0x167c>
     798:      	mov	x19, x0
     79c:      	mov	w8, #0x33d              ; =829
     7a0:      	str	w8, [sp, #0x44]
     7a4:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xa4>
     7a8:      	add	x0, x0, #0x9ac
     7ac:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xa4>
     7b0:      	add	x1, x1, #0xa38
     7b4:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xa4>
     7b8:      	add	x3, x3, #0xa63
     7bc:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xa4>
     7c0:      	add	x4, x4, #0xae1
     7c4:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xa4>
     7c8:      	add	x2, x2, #0xa60
     7cc:      	add	x8, sp, #0x48
     7d0:      	add	x5, sp, #0x44
     7d4:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xa4>
     7d8:      	add	x7, x7, #0xae3
     7dc:      	mov	x6, x2
     7e0:      	bl	0x854 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     7e4:      	mov	w21, #0x1               ; =1
     7e8:      	add	x1, sp, #0x48
     7ec:      	mov	x0, x19
     7f0:      	bl	0x15c8 <dyld_stub_binder+0x15c8>
     7f4:      	mov	w21, #0x0               ; =0
     7f8:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     7fc:      	ldr	x1, [x1, #0x18]
     800:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     804:      	ldr	x2, [x2, #0x8]
     808:      	mov	x0, x19
     80c:      	bl	0x16ac <dyld_stub_binder+0x16ac>
     810:      	brk	#0x1
     814:      	mov	x20, x0
     818:      	ldrsb	w8, [sp, #0x5f]
     81c:      	tbz	w8, #0x1f, 0x838 <_kernel+0x188>
     820:      	ldr	x0, [sp, #0x48]
     824:      	ldr	x8, [sp, #0x58]
     828:      	and	x1, x8, #0x7fffffffffffffff
     82c:      	bl	0x1664 <dyld_stub_binder+0x1664>
     830:      	tbnz	w21, #0x0, 0x844 <_kernel+0x194>
     834:      	b	0x84c <_kernel+0x19c>
     838:      	cbnz	w21, 0x844 <_kernel+0x194>
     83c:      	b	0x84c <_kernel+0x19c>
     840:      	mov	x20, x0
     844:      	mov	x0, x19
     848:      	bl	0x16a0 <dyld_stub_binder+0x16a0>
     84c:      	mov	x0, x20
     850:      	bl	0x158c <dyld_stub_binder+0x158c>

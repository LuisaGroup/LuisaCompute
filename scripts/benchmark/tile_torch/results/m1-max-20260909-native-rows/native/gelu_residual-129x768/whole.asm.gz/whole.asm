
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/gelu_residual-129x768-l1/object/tile_xir_w8_80777_1788919116618295_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x50]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	sub	sp, sp, #0xc, lsl #12   ; =0xc000
      18:      	sub	sp, sp, #0xe0
      1c:      	mov	x9, #0x0                ; =0
      20:      	ldr	x11, [x0]
      24:      	ldr	w8, [x1]
      28:      	ldr	w10, [x1, #0x24]
      2c:      	add	w12, w10, w8, lsl #5
      30:      	ldr	x10, [x0, #0x10]
      34:      	ldr	x8, [x0, #0x30]
      38:      	dup.4s	v0, w12
      3c:      	adrp	x12, 0x0 <ltmp0>
      40:      	ldr	q1, [x12]
      44:      	add.4s	v2, v0, v1
      48:      	adrp	x12, 0x0 <ltmp0>
      4c:      	ldr	q1, [x12]
      50:      	add.4s	v3, v0, v1
      54:      	movi.4s	v1, #0x3, lsl #8
      58:      	umull2.2d	v0, v2, v1
      5c:      	umull2.2d	v1, v3, v1
      60:      	movi.2s	v4, #0x3, lsl #8
      64:      	umull.2d	v2, v2, v4
      68:      	umull.2d	v3, v3, v4
      6c:      	dup.2d	v4, x11
      70:      	add	x11, sp, #0x6, lsl #12  ; =0x6000
      74:      	add	x11, x11, #0xe0
      78:      	dup.2d	v5, x9
      7c:      	add.2d	v6, v5, v0
      80:      	add.2d	v7, v5, v2
      84:      	add.2d	v16, v5, v1
      88:      	add.2d	v5, v5, v3
      8c:      	shl.2d	v5, v5, #0x2
      90:      	shl.2d	v16, v16, #0x2
      94:      	shl.2d	v7, v7, #0x2
      98:      	shl.2d	v6, v6, #0x2
      9c:      	add.2d	v6, v4, v6
      a0:      	add.2d	v7, v4, v7
      a4:      	add.2d	v16, v4, v16
      a8:      	add.2d	v5, v4, v5
      ac:      	mov.d	x12, v5[1]
      b0:      	fmov	x13, d5
      b4:      	mov.d	x14, v16[1]
      b8:      	fmov	x15, d16
      bc:      	mov.d	x16, v7[1]
      c0:      	fmov	x17, d7
      c4:      	mov.d	x0, v6[1]
      c8:      	ldr	s5, [x17]
      cc:      	ld1.s	{ v5 }[1], [x16]
      d0:      	fmov	x16, d6
      d4:      	ld1.s	{ v5 }[2], [x16]
      d8:      	ld1.s	{ v5 }[3], [x0]
      dc:      	ldr	s6, [x13]
      e0:      	ld1.s	{ v6 }[1], [x12]
      e4:      	ld1.s	{ v6 }[2], [x15]
      e8:      	ld1.s	{ v6 }[3], [x14]
      ec:      	add	x12, x11, x9, lsl #5
      f0:      	stp	q6, q5, [x12]
      f4:      	add	x9, x9, #0x1
      f8:      	cmp	x9, #0x300
      fc:      	b.ne	0x78 <ltmp0+0x78>
     100:      	mov	x9, #0x0                ; =0
     104:      	dup.2d	v4, x10
     108:      	add	x10, sp, #0xe0
     10c:      	dup.2d	v5, x9
     110:      	add.2d	v6, v5, v0
     114:      	add.2d	v7, v5, v2
     118:      	add.2d	v16, v5, v1
     11c:      	add.2d	v5, v5, v3
     120:      	shl.2d	v5, v5, #0x2
     124:      	shl.2d	v16, v16, #0x2
     128:      	shl.2d	v7, v7, #0x2
     12c:      	shl.2d	v6, v6, #0x2
     130:      	add.2d	v6, v4, v6
     134:      	add.2d	v7, v4, v7
     138:      	add.2d	v16, v4, v16
     13c:      	add.2d	v5, v4, v5
     140:      	mov.d	x11, v5[1]
     144:      	fmov	x12, d5
     148:      	mov.d	x13, v16[1]
     14c:      	fmov	x14, d16
     150:      	mov.d	x15, v7[1]
     154:      	fmov	x16, d7
     158:      	mov.d	x17, v6[1]
     15c:      	ldr	s5, [x16]
     160:      	ld1.s	{ v5 }[1], [x15]
     164:      	fmov	x15, d6
     168:      	ld1.s	{ v5 }[2], [x15]
     16c:      	ld1.s	{ v5 }[3], [x17]
     170:      	ldr	s6, [x12]
     174:      	ld1.s	{ v6 }[1], [x11]
     178:      	ld1.s	{ v6 }[2], [x14]
     17c:      	ld1.s	{ v6 }[3], [x13]
     180:      	add	x11, x10, x9, lsl #5
     184:      	stp	q6, q5, [x11]
     188:      	add	x9, x9, #0x1
     18c:      	cmp	x9, #0x300
     190:      	b.ne	0x10c <ltmp0+0x10c>
     194:      	mov	x9, #0x0                ; =0
     198:      	add	x10, sp, #0x6, lsl #12  ; =0x6000
     19c:      	add	x10, x10, #0xe0
     1a0:      	mov	w11, #0x2713            ; =10003
     1a4:      	movk	w11, #0x3d37, lsl #16
     1a8:      	dup.4s	v5, w11
     1ac:      	mov	w11, #0x422a            ; =16938
     1b0:      	movk	w11, #0x3f4c, lsl #16
     1b4:      	dup.4s	v4, w11
     1b8:      	stp	q4, q5, [sp, #0xc0]
     1bc:      	fmov.4s	v7, #1.00000000
     1c0:      	mov	w11, #0x9231            ; =37425
     1c4:      	movk	w11, #0x2f30, lsl #16
     1c8:      	dup.4s	v5, w11
     1cc:      	mov	w11, #0x322b            ; =12843
     1d0:      	movk	w11, #0x32d7, lsl #16
     1d4:      	dup.4s	v4, w11
     1d8:      	stp	q4, q5, [sp, #0xa0]
     1dc:      	mov	w11, #0xef1d            ; =61213
     1e0:      	movk	w11, #0x3638, lsl #16
     1e4:      	dup.4s	v5, w11
     1e8:      	mov	w11, #0xd01             ; =3329
     1ec:      	movk	w11, #0x3950, lsl #16
     1f0:      	dup.4s	v4, w11
     1f4:      	stp	q4, q5, [sp, #0x80]
     1f8:      	mov	w11, #0x8889            ; =34953
     1fc:      	movk	w11, #0x3c08, lsl #16
     200:      	dup.4s	v5, w11
     204:      	mov	w11, #0xaaab            ; =43691
     208:      	movk	w11, #0x3e2a, lsl #16
     20c:      	dup.4s	v22, w11
     210:      	mov	w11, #0x76c7            ; =30407
     214:      	movk	w11, #0x310f, lsl #16
     218:      	dup.4s	v4, w11
     21c:      	stp	q4, q5, [sp, #0x60]
     220:      	mov	w11, #0xf27e            ; =62078
     224:      	movk	w11, #0x3493, lsl #16
     228:      	dup.4s	v5, w11
     22c:      	mov	w11, #0xd01             ; =3329
     230:      	movk	w11, #0x37d0, lsl #16
     234:      	dup.4s	v4, w11
     238:      	stp	q4, q5, [sp, #0x40]
     23c:      	mov	w11, #0xb61             ; =2913
     240:      	movk	w11, #0x3ab6, lsl #16
     244:      	dup.4s	v5, w11
     248:      	mov	w11, #0xaaab            ; =43691
     24c:      	movk	w11, #0x3d2a, lsl #16
     250:      	dup.4s	v4, w11
     254:      	stp	q4, q5, [sp, #0x20]
     258:      	fmov.4s	v5, #9.00000000
     25c:      	mov	w11, #-0x3d300000       ; =-1026555904
     260:      	dup.4s	v4, w11
     264:      	stp	q4, q5, [sp]
     268:      	mov	w11, #0x42c80000        ; =1120403456
     26c:      	dup.4s	v29, w11
     270:      	mov	w11, #0xaa3b            ; =43579
     274:      	movk	w11, #0x3fb8, lsl #16
     278:      	dup.4s	v30, w11
     27c:      	mov	w11, #0x7200            ; =29184
     280:      	movk	w11, #0xbf31, lsl #16
     284:      	mov	w12, #0xbe8e            ; =48782
     288:      	movk	w12, #0xb5bf, lsl #16
     28c:      	mov	w13, #0x2bda            ; =11226
     290:      	movk	w13, #0x3950, lsl #16
     294:      	mov	w14, #0x96c9            ; =38601
     298:      	movk	w14, #0x3ab6, lsl #16
     29c:      	mov	w15, #0x88a6            ; =34982
     2a0:      	movk	w15, #0x3c08, lsl #16
     2a4:      	mov	w16, #0xaa7a            ; =43642
     2a8:      	movk	w16, #0x3d2a, lsl #16
     2ac:      	mvni.4s	v4, #0x7f, msl #16
     2b0:      	fneg.4s	v10, v4
     2b4:      	mvni.4s	v4, #0x3f, msl #16
     2b8:      	fneg.4s	v12, v4
     2bc:      	add	x17, sp, #0xe0
     2c0:      	lsl	x0, x9, #5
     2c4:      	add	x1, x10, x0
     2c8:      	ldp	q13, q14, [x1]
     2cc:      	ldp	q6, q5, [sp, #0xc0]
     2d0:      	fmul.4s	v4, v14, v5
     2d4:      	fmul.4s	v5, v13, v5
     2d8:      	fmul.4s	v5, v13, v5
     2dc:      	fmul.4s	v4, v14, v4
     2e0:      	fmul.4s	v4, v14, v4
     2e4:      	fmul.4s	v5, v13, v5
     2e8:      	fadd.4s	v5, v13, v5
     2ec:      	fadd.4s	v4, v14, v4
     2f0:      	fmul.4s	v31, v4, v6
     2f4:      	fmul.4s	v15, v5, v6
     2f8:      	fabs.4s	v9, v15
     2fc:      	fabs.4s	v8, v31
     300:      	fmul.4s	v16, v31, v31
     304:      	fmul.4s	v19, v15, v15
     308:      	ldp	q5, q6, [sp, #0xa0]
     30c:      	mov.16b	v4, v5
     310:      	fmla.4s	v4, v16, v6
     314:      	fmla.4s	v5, v19, v6
     318:      	ldr	q17, [sp, #0x90]
     31c:      	mov.16b	v6, v17
     320:      	fmla.4s	v6, v16, v4
     324:      	mov.16b	v4, v17
     328:      	fmla.4s	v4, v19, v5
     32c:      	ldr	q17, [sp, #0x80]
     330:      	mov.16b	v5, v17
     334:      	fmla.4s	v5, v16, v6
     338:      	mov.16b	v6, v17
     33c:      	fmla.4s	v6, v19, v4
     340:      	ldp	q23, q17, [sp, #0x60]
     344:      	mov.16b	v4, v17
     348:      	mov.16b	v20, v22
     34c:      	fmla.4s	v4, v16, v5
     350:      	mov.16b	v21, v22
     354:      	mov.16b	v18, v7
     358:      	mov.16b	v5, v7
     35c:      	ldr	q24, [sp, #0x50]
     360:      	mov.16b	v11, v24
     364:      	fmla.4s	v11, v19, v23
     368:      	fmla.4s	v17, v19, v6
     36c:      	mov.16b	v6, v24
     370:      	fmla.4s	v6, v16, v23
     374:      	ldr	q23, [sp, #0x40]
     378:      	mov.16b	v24, v23
     37c:      	fmla.4s	v24, v19, v11
     380:      	mov.16b	v11, v23
     384:      	fmla.4s	v20, v16, v4
     388:      	fmla.4s	v11, v16, v6
     38c:      	ldp	q23, q6, [sp, #0x20]
     390:      	mov.16b	v4, v6
     394:      	fmla.4s	v4, v19, v24
     398:      	fmla.4s	v6, v16, v11
     39c:      	fmla.4s	v21, v19, v17
     3a0:      	mov.16b	v17, v23
     3a4:      	fmla.4s	v17, v19, v4
     3a8:      	mov.16b	v4, v23
     3ac:      	fmla.4s	v4, v16, v6
     3b0:      	movi.4s	v24, #0x3f, lsl #24
     3b4:      	fmla.4s	v24, v19, v17
     3b8:      	movi.4s	v23, #0x3f, lsl #24
     3bc:      	fmla.4s	v23, v16, v4
     3c0:      	ldr	q4, [sp, #0x10]
     3c4:      	fcmge.4s	v11, v4, v8
     3c8:      	fcmge.4s	v6, v4, v9
     3cc:      	and.16b	v17, v6, v9
     3d0:      	fmla.4s	v18, v16, v20
     3d4:      	and.16b	v4, v11, v8
     3d8:      	ldr	q20, [sp]
     3dc:      	fcmge.4s	v27, v4, v20
     3e0:      	fcmge.4s	v25, v17, v20
     3e4:      	fcmge.4s	v28, v29, v4
     3e8:      	fcmge.4s	v26, v29, v17
     3ec:      	mov.16b	v20, v7
     3f0:      	and.16b	v25, v25, v26
     3f4:      	and.16b	v26, v27, v28
     3f8:      	and.16b	v26, v26, v4
     3fc:      	and.16b	v25, v25, v17
     400:      	fmul.4s	v27, v25, v30
     404:      	fmla.4s	v5, v19, v21
     408:      	fmul.4s	v21, v26, v30
     40c:      	movi.4s	v28, #0x4b, lsl #24
     410:      	fadd.4s	v21, v21, v28
     414:      	fadd.4s	v27, v27, v28
     418:      	movi.4s	v28, #0xcb, lsl #24
     41c:      	fadd.4s	v27, v27, v28
     420:      	fadd.4s	v21, v21, v28
     424:      	fmla.4s	v20, v19, v24
     428:      	fcvtzs.4s	v19, v21
     42c:      	fcvtzs.4s	v21, v27
     430:      	scvtf.4s	v24, v21
     434:      	dup.4s	v27, w11
     438:      	fmul.4s	v28, v24, v27
     43c:      	fadd.4s	v25, v25, v28
     440:      	scvtf.4s	v28, v19
     444:      	fmul.4s	v27, v28, v27
     448:      	fadd.4s	v26, v26, v27
     44c:      	dup.4s	v27, w12
     450:      	fmul.4s	v24, v24, v27
     454:      	fmul.4s	v27, v28, v27
     458:      	fadd.4s	v26, v26, v27
     45c:      	mov.16b	v27, v7
     460:      	fadd.4s	v24, v25, v24
     464:      	fmla.4s	v27, v16, v23
     468:      	dup.4s	v16, w13
     46c:      	fmul.4s	v23, v24, v16
     470:      	dup.4s	v25, w14
     474:      	fmul.4s	v16, v26, v16
     478:      	fadd.4s	v16, v16, v25
     47c:      	fadd.4s	v23, v23, v25
     480:      	fmul.4s	v23, v24, v23
     484:      	dup.4s	v25, w15
     488:      	fmul.4s	v16, v26, v16
     48c:      	fadd.4s	v16, v16, v25
     490:      	fadd.4s	v23, v23, v25
     494:      	fmul.4s	v23, v24, v23
     498:      	dup.4s	v25, w16
     49c:      	fmul.4s	v16, v26, v16
     4a0:      	fadd.4s	v16, v16, v25
     4a4:      	fadd.4s	v23, v23, v25
     4a8:      	fmul.4s	v18, v8, v18
     4ac:      	fmul.4s	v23, v24, v23
     4b0:      	fmul.4s	v16, v26, v16
     4b4:      	fadd.4s	v16, v16, v22
     4b8:      	fadd.4s	v23, v23, v22
     4bc:      	fmul.4s	v23, v24, v23
     4c0:      	fmul.4s	v16, v26, v16
     4c4:      	movi.4s	v28, #0x3f, lsl #24
     4c8:      	fadd.4s	v25, v16, v28
     4cc:      	fadd.4s	v23, v23, v28
     4d0:      	fdiv.4s	v16, v18, v27
     4d4:      	fmul.4s	v18, v24, v24
     4d8:      	fmul.4s	v18, v18, v23
     4dc:      	fmul.4s	v23, v26, v26
     4e0:      	fmul.4s	v23, v23, v25
     4e4:      	fmul.4s	v5, v9, v5
     4e8:      	fdiv.4s	v5, v5, v20
     4ec:      	fadd.4s	v20, v26, v23
     4f0:      	fadd.4s	v18, v24, v18
     4f4:      	movi.2d	v25, #0xffffffffffffffff
     4f8:      	add.4s	v21, v21, v25
     4fc:      	sshr.4s	v23, v21, #0x1
     500:      	shl.4s	v24, v23, #0x17
     504:      	fadd.4s	v18, v18, v7
     508:      	add.4s	v24, v24, v7
     50c:      	fmul.4s	v18, v18, v24
     510:      	sub.4s	v21, v21, v23
     514:      	shl.4s	v21, v21, #0x17
     518:      	add.4s	v21, v21, v7
     51c:      	fmul.4s	v18, v18, v21
     520:      	fcmgt.4s	v17, v17, v29
     524:      	bsl.16b	v17, v10, v18
     528:      	fmov.4s	v18, #0.25000000
     52c:      	fdiv.4s	v21, v18, v17
     530:      	fsub.4s	v23, v17, v21
     534:      	fadd.4s	v17, v17, v21
     538:      	fdiv.4s	v17, v23, v17
     53c:      	bsl.16b	v6, v17, v7
     540:      	fcmge.4s	v17, v7, v9
     544:      	fadd.4s	v20, v20, v7
     548:      	add.4s	v19, v19, v25
     54c:      	bif.16b	v5, v6, v17
     550:      	sshr.4s	v6, v19, #0x1
     554:      	shl.4s	v17, v6, #0x17
     558:      	add.4s	v17, v17, v7
     55c:      	fmul.4s	v17, v20, v17
     560:      	sub.4s	v6, v19, v6
     564:      	shl.4s	v6, v6, #0x17
     568:      	add.4s	v6, v6, v7
     56c:      	fmul.4s	v6, v17, v6
     570:      	fcmgt.4s	v4, v4, v29
     574:      	bsl.16b	v4, v10, v6
     578:      	fdiv.4s	v6, v18, v4
     57c:      	fsub.4s	v17, v4, v6
     580:      	fadd.4s	v4, v4, v6
     584:      	fdiv.4s	v4, v17, v4
     588:      	bif.16b	v4, v7, v11
     58c:      	dup.2d	v6, x9
     590:      	fcmge.4s	v17, v7, v8
     594:      	bit.16b	v4, v16, v17
     598:      	mvni.4s	v19, #0x80, lsl #24
     59c:      	bif.16b	v4, v31, v19
     5a0:      	fcmeq.4s	v16, v31, v31
     5a4:      	fadd.4s	v4, v4, v7
     5a8:      	bif.16b	v4, v12, v16
     5ac:      	add.2d	v16, v6, v0
     5b0:      	fmul.4s	v17, v14, v28
     5b4:      	fmul.4s	v18, v13, v28
     5b8:      	bif.16b	v5, v15, v19
     5bc:      	fcmeq.4s	v19, v15, v15
     5c0:      	fadd.4s	v5, v5, v7
     5c4:      	bif.16b	v5, v12, v19
     5c8:      	fmul.4s	v5, v18, v5
     5cc:      	fmul.4s	v4, v17, v4
     5d0:      	add	x0, x17, x0
     5d4:      	ldp	q17, q18, [x0]
     5d8:      	add.2d	v19, v6, v2
     5dc:      	fadd.4s	v4, v18, v4
     5e0:      	add.2d	v18, v6, v1
     5e4:      	add.2d	v6, v6, v3
     5e8:      	shl.2d	v6, v6, #0x2
     5ec:      	shl.2d	v18, v18, #0x2
     5f0:      	fadd.4s	v5, v17, v5
     5f4:      	shl.2d	v17, v19, #0x2
     5f8:      	shl.2d	v16, v16, #0x2
     5fc:      	dup.2d	v19, x8
     600:      	add.2d	v16, v19, v16
     604:      	add.2d	v17, v19, v17
     608:      	add.2d	v18, v19, v18
     60c:      	add.2d	v6, v19, v6
     610:      	mov.d	x0, v6[1]
     614:      	mov.d	x1, v18[1]
     618:      	fmov	x2, d6
     61c:      	fmov	x3, d18
     620:      	mov.d	x4, v17[1]
     624:      	fmov	x5, d17
     628:      	str	s5, [x2]
     62c:      	st1.s	{ v5 }[1], [x0]
     630:      	st1.s	{ v5 }[2], [x3]
     634:      	st1.s	{ v5 }[3], [x1]
     638:      	mov.d	x0, v16[1]
     63c:      	fmov	x1, d16
     640:      	str	s4, [x5]
     644:      	st1.s	{ v4 }[1], [x4]
     648:      	st1.s	{ v4 }[2], [x1]
     64c:      	st1.s	{ v4 }[3], [x0]
     650:      	add	x9, x9, #0x1
     654:      	cmp	x9, #0x300
     658:      	b.ne	0x2c0 <ltmp0+0x2c0>
     65c:      	add	sp, sp, #0xc, lsl #12   ; =0xc000
     660:      	add	sp, sp, #0xe0
     664:      	ldp	x28, x27, [sp, #0x40]
     668:      	ldp	d9, d8, [sp, #0x30]
     66c:      	ldp	d11, d10, [sp, #0x20]
     670:      	ldp	d13, d12, [sp, #0x10]
     674:      	ldp	d15, d14, [sp], #0x50
     678:      	ret

000000000000067c <_llm_rows.packet_batch.blocks>:
     67c:      	stp	d15, d14, [sp, #-0xa0]!
     680:      	stp	d13, d12, [sp, #0x10]
     684:      	stp	d11, d10, [sp, #0x20]
     688:      	stp	d9, d8, [sp, #0x30]
     68c:      	stp	x28, x27, [sp, #0x40]
     690:      	stp	x26, x25, [sp, #0x50]
     694:      	stp	x24, x23, [sp, #0x60]
     698:      	stp	x22, x21, [sp, #0x70]
     69c:      	stp	x20, x19, [sp, #0x80]
     6a0:      	stp	x29, x30, [sp, #0x90]
     6a4:      	sub	sp, sp, #0xc, lsl #12   ; =0xc000
     6a8:      	sub	sp, sp, #0x150
     6ac:      	str	x0, [sp, #0x58]
     6b0:      	cbz	w3, 0x11f0 <_llm_rows.packet_batch.blocks+0xb74>
     6b4:      	mov	x23, x3
     6b8:      	mov	x20, x2
     6bc:      	mov	w22, #0x0               ; =0
     6c0:      	ldp	w9, w8, [x2, #0x2c]
     6c4:      	stp	w8, w9, [sp, #0x50]
     6c8:      	ldp	w27, w25, [x2]
     6cc:      	add	x26, sp, #0x6, lsl #12  ; =0x6000
     6d0:      	add	x26, x26, #0x150
     6d4:      	add	x28, sp, #0x150
     6d8:      	mov	w14, #0x2713            ; =10003
     6dc:      	movk	w14, #0x3d37, lsl #16
     6e0:      	ldp	w24, w19, [x2, #0x8]
     6e4:      	mov	w15, #0x422a            ; =16938
     6e8:      	movk	w15, #0x3f4c, lsl #16
     6ec:      	adrp	x8, 0x0 <ltmp0>
     6f0:      	ldr	q0, [x8]
     6f4:      	str	q0, [sp, #0x40]
     6f8:      	mov	w16, #0x9231            ; =37425
     6fc:      	movk	w16, #0x2f30, lsl #16
     700:      	adrp	x8, 0x0 <ltmp0>
     704:      	ldr	q0, [x8]
     708:      	str	q0, [sp, #0x30]
     70c:      	mov	w17, #0x322b            ; =12843
     710:      	movk	w17, #0x32d7, lsl #16
     714:      	adrp	x8, 0x0 <ltmp0>
     718:      	ldr	q0, [x8]
     71c:      	str	q0, [sp, #0x10]
     720:      	mov	w0, #0xef1d             ; =61213
     724:      	movk	w0, #0x3638, lsl #16
     728:      	mov	w1, #0xd01              ; =3329
     72c:      	movk	w1, #0x3950, lsl #16
     730:      	mov	w2, #0x8889             ; =34953
     734:      	movk	w2, #0x3c08, lsl #16
     738:      	mov	w3, #0xaaab             ; =43691
     73c:      	movk	w3, #0x3e2a, lsl #16
     740:      	mov	w4, #0x76c7             ; =30407
     744:      	movk	w4, #0x310f, lsl #16
     748:      	mov	w5, #0xf27e             ; =62078
     74c:      	movk	w5, #0x3493, lsl #16
     750:      	mov	w6, #0xd01              ; =3329
     754:      	movk	w6, #0x37d0, lsl #16
     758:      	mov	w7, #0xb61              ; =2913
     75c:      	movk	w7, #0x3ab6, lsl #16
     760:      	mov	w30, #0xaaab            ; =43691
     764:      	movk	w30, #0x3d2a, lsl #16
     768:      	mvni.4s	v0, #0x7f, msl #16
     76c:      	fneg.4s	v1, v0
     770:      	mvni.4s	v0, #0x3f, msl #16
     774:      	fneg.4s	v0, v0
     778:      	stp	q0, q1, [sp, #0x110]
     77c:      	str	w23, [sp, #0x2c]
     780:      	b	0x7c8 <_llm_rows.packet_batch.blocks+0x14c>
     784:      	mov	w8, #0x18               ; =24
     788:      	str	w8, [x20, #0x24]
     78c:      	ldr	w23, [sp, #0x2c]
     790:      	add	w8, w27, #0x1
     794:      	ldp	w10, w9, [sp, #0x50]
     798:      	cmp	w8, w9
     79c:      	cset	w8, eq
     7a0:      	csinc	w27, wzr, w27, eq
     7a4:      	cinc	w9, w25, eq
     7a8:      	cmp	w9, w10
     7ac:      	cset	w10, eq
     7b0:      	ands	w8, w8, w10
     7b4:      	csel	w25, wzr, w9, ne
     7b8:      	add	w24, w24, w8
     7bc:      	add	w22, w22, #0x1
     7c0:      	cmp	w22, w23
     7c4:      	b.eq	0x11f0 <_llm_rows.packet_batch.blocks+0xb74>
     7c8:      	ubfiz	x8, x27, #5, #32
     7cc:      	cmp	x8, x19
     7d0:      	csel	x9, x8, xzr, ls
     7d4:      	subs	x10, x19, x9
     7d8:      	cmp	x10, #0x20
     7dc:      	mov	w11, #0x20              ; =32
     7e0:      	csel	x10, x10, x11, lo
     7e4:      	cmp	x19, x9
     7e8:      	stp	w27, w25, [x20]
     7ec:      	str	w24, [x20, #0x8]
     7f0:      	str	wzr, [x20, #0x24]
     7f4:      	ccmp	x8, x19, #0x2, hi
     7f8:      	csel	x21, x10, xzr, ls
     7fc:      	cmp	x21, #0x20
     800:      	b.lo	0x8bc <_llm_rows.packet_batch.blocks+0x240>
     804:      	ldr	x21, [sp, #0x58]
     808:      	mov	x0, x21
     80c:      	mov	x1, x20
     810:      	bl	0x810 <_llm_rows.packet_batch.blocks+0x194>
     814:      	mov	w8, #0x8                ; =8
     818:      	str	w8, [x20, #0x24]
     81c:      	mov	x0, x21
     820:      	mov	x1, x20
     824:      	bl	0x824 <_llm_rows.packet_batch.blocks+0x1a8>
     828:      	mov	w8, #0x10               ; =16
     82c:      	str	w8, [x20, #0x24]
     830:      	mov	x0, x21
     834:      	mov	x1, x20
     838:      	bl	0x838 <_llm_rows.packet_batch.blocks+0x1bc>
     83c:      	mov	w8, #0x18               ; =24
     840:      	str	w8, [x20, #0x24]
     844:      	mov	x0, x21
     848:      	mov	x1, x20
     84c:      	bl	0x84c <_llm_rows.packet_batch.blocks+0x1d0>
     850:      	mov	w30, #0xaaab            ; =43691
     854:      	movk	w30, #0x3d2a, lsl #16
     858:      	mov	w7, #0xb61              ; =2913
     85c:      	movk	w7, #0x3ab6, lsl #16
     860:      	mov	w6, #0xd01              ; =3329
     864:      	movk	w6, #0x37d0, lsl #16
     868:      	mov	w5, #0xf27e             ; =62078
     86c:      	movk	w5, #0x3493, lsl #16
     870:      	mov	w4, #0x76c7             ; =30407
     874:      	movk	w4, #0x310f, lsl #16
     878:      	mov	w3, #0xaaab             ; =43691
     87c:      	movk	w3, #0x3e2a, lsl #16
     880:      	mov	w2, #0x8889             ; =34953
     884:      	movk	w2, #0x3c08, lsl #16
     888:      	mov	w1, #0xd01              ; =3329
     88c:      	movk	w1, #0x3950, lsl #16
     890:      	mov	w0, #0xef1d             ; =61213
     894:      	movk	w0, #0x3638, lsl #16
     898:      	mov	w17, #0x322b            ; =12843
     89c:      	movk	w17, #0x32d7, lsl #16
     8a0:      	mov	w16, #0x9231            ; =37425
     8a4:      	movk	w16, #0x2f30, lsl #16
     8a8:      	mov	w15, #0x422a            ; =16938
     8ac:      	movk	w15, #0x3f4c, lsl #16
     8b0:      	mov	w14, #0x2713            ; =10003
     8b4:      	movk	w14, #0x3d37, lsl #16
     8b8:      	b	0x790 <_llm_rows.packet_batch.blocks+0x114>
     8bc:      	lsr	x23, x21, #3
     8c0:      	cmp	x21, #0x8
     8c4:      	b.lo	0xa48 <_llm_rows.packet_batch.blocks+0x3cc>
     8c8:      	str	wzr, [x20, #0x24]
     8cc:      	ldr	x0, [sp, #0x58]
     8d0:      	mov	x1, x20
     8d4:      	bl	0x8d4 <_llm_rows.packet_batch.blocks+0x258>
     8d8:      	mov	w30, #0xaaab            ; =43691
     8dc:      	movk	w30, #0x3d2a, lsl #16
     8e0:      	mov	w7, #0xb61              ; =2913
     8e4:      	movk	w7, #0x3ab6, lsl #16
     8e8:      	mov	w6, #0xd01              ; =3329
     8ec:      	movk	w6, #0x37d0, lsl #16
     8f0:      	mov	w5, #0xf27e             ; =62078
     8f4:      	movk	w5, #0x3493, lsl #16
     8f8:      	mov	w4, #0x76c7             ; =30407
     8fc:      	movk	w4, #0x310f, lsl #16
     900:      	mov	w3, #0xaaab             ; =43691
     904:      	movk	w3, #0x3e2a, lsl #16
     908:      	mov	w2, #0x8889             ; =34953
     90c:      	movk	w2, #0x3c08, lsl #16
     910:      	mov	w1, #0xd01              ; =3329
     914:      	movk	w1, #0x3950, lsl #16
     918:      	mov	w0, #0xef1d             ; =61213
     91c:      	movk	w0, #0x3638, lsl #16
     920:      	mov	w17, #0x322b            ; =12843
     924:      	movk	w17, #0x32d7, lsl #16
     928:      	mov	w16, #0x9231            ; =37425
     92c:      	movk	w16, #0x2f30, lsl #16
     930:      	mov	w15, #0x422a            ; =16938
     934:      	movk	w15, #0x3f4c, lsl #16
     938:      	mov	w14, #0x2713            ; =10003
     93c:      	movk	w14, #0x3d37, lsl #16
     940:      	cmp	x23, #0x1
     944:      	b.eq	0xa48 <_llm_rows.packet_batch.blocks+0x3cc>
     948:      	mov	w8, #0x8                ; =8
     94c:      	str	w8, [x20, #0x24]
     950:      	ldr	x0, [sp, #0x58]
     954:      	mov	x1, x20
     958:      	bl	0x958 <_llm_rows.packet_batch.blocks+0x2dc>
     95c:      	mov	w30, #0xaaab            ; =43691
     960:      	movk	w30, #0x3d2a, lsl #16
     964:      	mov	w7, #0xb61              ; =2913
     968:      	movk	w7, #0x3ab6, lsl #16
     96c:      	mov	w6, #0xd01              ; =3329
     970:      	movk	w6, #0x37d0, lsl #16
     974:      	mov	w5, #0xf27e             ; =62078
     978:      	movk	w5, #0x3493, lsl #16
     97c:      	mov	w4, #0x76c7             ; =30407
     980:      	movk	w4, #0x310f, lsl #16
     984:      	mov	w3, #0xaaab             ; =43691
     988:      	movk	w3, #0x3e2a, lsl #16
     98c:      	mov	w2, #0x8889             ; =34953
     990:      	movk	w2, #0x3c08, lsl #16
     994:      	mov	w1, #0xd01              ; =3329
     998:      	movk	w1, #0x3950, lsl #16
     99c:      	mov	w0, #0xef1d             ; =61213
     9a0:      	movk	w0, #0x3638, lsl #16
     9a4:      	mov	w17, #0x322b            ; =12843
     9a8:      	movk	w17, #0x32d7, lsl #16
     9ac:      	mov	w16, #0x9231            ; =37425
     9b0:      	movk	w16, #0x2f30, lsl #16
     9b4:      	mov	w15, #0x422a            ; =16938
     9b8:      	movk	w15, #0x3f4c, lsl #16
     9bc:      	mov	w14, #0x2713            ; =10003
     9c0:      	movk	w14, #0x3d37, lsl #16
     9c4:      	cmp	x23, #0x2
     9c8:      	b.eq	0xa48 <_llm_rows.packet_batch.blocks+0x3cc>
     9cc:      	mov	w8, #0x10               ; =16
     9d0:      	str	w8, [x20, #0x24]
     9d4:      	ldr	x0, [sp, #0x58]
     9d8:      	mov	x1, x20
     9dc:      	bl	0x9dc <_llm_rows.packet_batch.blocks+0x360>
     9e0:      	mov	w30, #0xaaab            ; =43691
     9e4:      	movk	w30, #0x3d2a, lsl #16
     9e8:      	mov	w7, #0xb61              ; =2913
     9ec:      	movk	w7, #0x3ab6, lsl #16
     9f0:      	mov	w6, #0xd01              ; =3329
     9f4:      	movk	w6, #0x37d0, lsl #16
     9f8:      	mov	w5, #0xf27e             ; =62078
     9fc:      	movk	w5, #0x3493, lsl #16
     a00:      	mov	w4, #0x76c7             ; =30407
     a04:      	movk	w4, #0x310f, lsl #16
     a08:      	mov	w3, #0xaaab             ; =43691
     a0c:      	movk	w3, #0x3e2a, lsl #16
     a10:      	mov	w2, #0x8889             ; =34953
     a14:      	movk	w2, #0x3c08, lsl #16
     a18:      	mov	w1, #0xd01              ; =3329
     a1c:      	movk	w1, #0x3950, lsl #16
     a20:      	mov	w0, #0xef1d             ; =61213
     a24:      	movk	w0, #0x3638, lsl #16
     a28:      	mov	w17, #0x322b            ; =12843
     a2c:      	movk	w17, #0x32d7, lsl #16
     a30:      	mov	w16, #0x9231            ; =37425
     a34:      	movk	w16, #0x2f30, lsl #16
     a38:      	mov	w15, #0x422a            ; =16938
     a3c:      	movk	w15, #0x3f4c, lsl #16
     a40:      	mov	w14, #0x2713            ; =10003
     a44:      	movk	w14, #0x3d37, lsl #16
     a48:      	and	w8, w21, #0x7
     a4c:      	mov	w21, #-0x3d300000       ; =-1026555904
     a50:      	cbz	w8, 0x784 <_llm_rows.packet_batch.blocks+0x108>
     a54:      	dup.4s	v0, w8
     a58:      	ldp	q2, q1, [sp, #0x30]
     a5c:      	cmhi.4s	v16, v0, v2
     a60:      	cmhi.4s	v5, v0, v1
     a64:      	uzp1.8h	v2, v5, v16
     a68:      	umaxv.8h	h0, v2
     a6c:      	fmov	w8, s0
     a70:      	tbz	w8, #0x0, 0x784 <_llm_rows.packet_batch.blocks+0x108>
     a74:      	mov	x10, #0x0               ; =0
     a78:      	ldr	x12, [sp, #0x58]
     a7c:      	ldr	x11, [x12]
     a80:      	ldr	x9, [x12, #0x10]
     a84:      	lsl	w8, w23, #3
     a88:      	orr	w8, w8, w27, lsl #5
     a8c:      	dup.4s	v0, w8
     a90:      	ldr	x8, [x12, #0x30]
     a94:      	ldp	q1, q4, [sp, #0x30]
     a98:      	orr.16b	v3, v0, v4
     a9c:      	orr.16b	v0, v0, v1
     aa0:      	and.16b	v0, v16, v0
     aa4:      	and.16b	v3, v5, v3
     aa8:      	movi.4s	v1, #0x3, lsl #8
     aac:      	umull2.2d	v17, v0, v1
     ab0:      	umull2.2d	v27, v3, v1
     ab4:      	movi.2s	v1, #0x3, lsl #8
     ab8:      	umull.2d	v18, v0, v1
     abc:      	umull.2d	v1, v3, v1
     ac0:      	ldr	q0, [sp, #0x10]
     ac4:      	and.16b	v0, v2, v0
     ac8:      	addv.8h	h0, v0
     acc:      	dup.2d	v7, x11
     ad0:      	str	q0, [sp, #0x130]
     ad4:      	fmov	w11, s0
     ad8:      	b	0xafc <_llm_rows.packet_batch.blocks+0x480>
     adc:      	add	x12, x26, x10, lsl #5
     ae0:      	ldp	q0, q4, [x12]
     ae4:      	bif.16b	v3, v4, v16
     ae8:      	bit.16b	v0, v2, v5
     aec:      	stp	q0, q3, [x12]
     af0:      	add	x10, x10, #0x1
     af4:      	cmp	x10, #0x300
     af8:      	b.eq	0xbe8 <_llm_rows.packet_batch.blocks+0x56c>
     afc:      	dup.2d	v6, x10
     b00:      	add.2d	v0, v6, v1
     b04:      	shl.2d	v0, v0, #0x2
     b08:      	add.2d	v4, v7, v0
     b0c:      	movi.2d	v2, #0000000000000000
     b10:      	movi.2d	v3, #0000000000000000
     b14:      	tbnz	w11, #0x0, 0xb60 <_llm_rows.packet_batch.blocks+0x4e4>
     b18:      	and	w12, w11, #0xff
     b1c:      	tbnz	w12, #0x1, 0xb70 <_llm_rows.packet_batch.blocks+0x4f4>
     b20:      	add.2d	v0, v6, v27
     b24:      	shl.2d	v0, v0, #0x2
     b28:      	add.2d	v4, v7, v0
     b2c:      	tbnz	w12, #0x2, 0xb88 <_llm_rows.packet_batch.blocks+0x50c>
     b30:      	tbnz	w12, #0x3, 0xb94 <_llm_rows.packet_batch.blocks+0x518>
     b34:      	add.2d	v0, v6, v18
     b38:      	shl.2d	v0, v0, #0x2
     b3c:      	add.2d	v4, v7, v0
     b40:      	tbnz	w12, #0x4, 0xbac <_llm_rows.packet_batch.blocks+0x530>
     b44:      	tbnz	w12, #0x5, 0xbb8 <_llm_rows.packet_batch.blocks+0x53c>
     b48:      	add.2d	v0, v6, v17
     b4c:      	shl.2d	v0, v0, #0x2
     b50:      	add.2d	v4, v7, v0
     b54:      	tbnz	w12, #0x6, 0xbd0 <_llm_rows.packet_batch.blocks+0x554>
     b58:      	tbz	w12, #0x7, 0xadc <_llm_rows.packet_batch.blocks+0x460>
     b5c:      	b	0xbdc <_llm_rows.packet_batch.blocks+0x560>
     b60:      	fmov	x12, d4
     b64:      	ldr	s2, [x12]
     b68:      	and	w12, w11, #0xff
     b6c:      	tbz	w12, #0x1, 0xb20 <_llm_rows.packet_batch.blocks+0x4a4>
     b70:      	mov.d	x13, v4[1]
     b74:      	ld1.s	{ v2 }[1], [x13]
     b78:      	add.2d	v0, v6, v27
     b7c:      	shl.2d	v0, v0, #0x2
     b80:      	add.2d	v4, v7, v0
     b84:      	tbz	w12, #0x2, 0xb30 <_llm_rows.packet_batch.blocks+0x4b4>
     b88:      	fmov	x13, d4
     b8c:      	ld1.s	{ v2 }[2], [x13]
     b90:      	tbz	w12, #0x3, 0xb34 <_llm_rows.packet_batch.blocks+0x4b8>
     b94:      	mov.d	x13, v4[1]
     b98:      	ld1.s	{ v2 }[3], [x13]
     b9c:      	add.2d	v0, v6, v18
     ba0:      	shl.2d	v0, v0, #0x2
     ba4:      	add.2d	v4, v7, v0
     ba8:      	tbz	w12, #0x4, 0xb44 <_llm_rows.packet_batch.blocks+0x4c8>
     bac:      	fmov	x13, d4
     bb0:      	ld1.s	{ v3 }[0], [x13]
     bb4:      	tbz	w12, #0x5, 0xb48 <_llm_rows.packet_batch.blocks+0x4cc>
     bb8:      	mov.d	x13, v4[1]
     bbc:      	ld1.s	{ v3 }[1], [x13]
     bc0:      	add.2d	v0, v6, v17
     bc4:      	shl.2d	v0, v0, #0x2
     bc8:      	add.2d	v4, v7, v0
     bcc:      	tbz	w12, #0x6, 0xb58 <_llm_rows.packet_batch.blocks+0x4dc>
     bd0:      	fmov	x13, d4
     bd4:      	ld1.s	{ v3 }[2], [x13]
     bd8:      	tbz	w12, #0x7, 0xadc <_llm_rows.packet_batch.blocks+0x460>
     bdc:      	mov.d	x12, v4[1]
     be0:      	ld1.s	{ v3 }[3], [x12]
     be4:      	b	0xadc <_llm_rows.packet_batch.blocks+0x460>
     be8:      	mov	x10, #0x0               ; =0
     bec:      	b	0xc10 <_llm_rows.packet_batch.blocks+0x594>
     bf0:      	add	x11, x28, x10, lsl #5
     bf4:      	ldp	q0, q4, [x11]
     bf8:      	bif.16b	v3, v4, v16
     bfc:      	bit.16b	v0, v2, v5
     c00:      	stp	q0, q3, [x11]
     c04:      	add	x10, x10, #0x1
     c08:      	cmp	x10, #0x300
     c0c:      	b.eq	0xd08 <_llm_rows.packet_batch.blocks+0x68c>
     c10:      	ldr	q0, [sp, #0x130]
     c14:      	fmov	w11, s0
     c18:      	dup.2d	v6, x10
     c1c:      	add.2d	v0, v6, v1
     c20:      	shl.2d	v0, v0, #0x2
     c24:      	dup.2d	v7, x9
     c28:      	add.2d	v4, v7, v0
     c2c:      	movi.2d	v2, #0000000000000000
     c30:      	movi.2d	v3, #0000000000000000
     c34:      	tbnz	w11, #0x0, 0xc80 <_llm_rows.packet_batch.blocks+0x604>
     c38:      	and	w11, w11, #0xff
     c3c:      	tbnz	w11, #0x1, 0xc90 <_llm_rows.packet_batch.blocks+0x614>
     c40:      	add.2d	v0, v6, v27
     c44:      	shl.2d	v0, v0, #0x2
     c48:      	add.2d	v4, v7, v0
     c4c:      	tbnz	w11, #0x2, 0xca8 <_llm_rows.packet_batch.blocks+0x62c>
     c50:      	tbnz	w11, #0x3, 0xcb4 <_llm_rows.packet_batch.blocks+0x638>
     c54:      	add.2d	v0, v6, v18
     c58:      	shl.2d	v0, v0, #0x2
     c5c:      	add.2d	v4, v7, v0
     c60:      	tbnz	w11, #0x4, 0xccc <_llm_rows.packet_batch.blocks+0x650>
     c64:      	tbnz	w11, #0x5, 0xcd8 <_llm_rows.packet_batch.blocks+0x65c>
     c68:      	add.2d	v0, v6, v17
     c6c:      	shl.2d	v0, v0, #0x2
     c70:      	add.2d	v4, v7, v0
     c74:      	tbnz	w11, #0x6, 0xcf0 <_llm_rows.packet_batch.blocks+0x674>
     c78:      	tbz	w11, #0x7, 0xbf0 <_llm_rows.packet_batch.blocks+0x574>
     c7c:      	b	0xcfc <_llm_rows.packet_batch.blocks+0x680>
     c80:      	fmov	x12, d4
     c84:      	ldr	s2, [x12]
     c88:      	and	w11, w11, #0xff
     c8c:      	tbz	w11, #0x1, 0xc40 <_llm_rows.packet_batch.blocks+0x5c4>
     c90:      	mov.d	x12, v4[1]
     c94:      	ld1.s	{ v2 }[1], [x12]
     c98:      	add.2d	v0, v6, v27
     c9c:      	shl.2d	v0, v0, #0x2
     ca0:      	add.2d	v4, v7, v0
     ca4:      	tbz	w11, #0x2, 0xc50 <_llm_rows.packet_batch.blocks+0x5d4>
     ca8:      	fmov	x12, d4
     cac:      	ld1.s	{ v2 }[2], [x12]
     cb0:      	tbz	w11, #0x3, 0xc54 <_llm_rows.packet_batch.blocks+0x5d8>
     cb4:      	mov.d	x12, v4[1]
     cb8:      	ld1.s	{ v2 }[3], [x12]
     cbc:      	add.2d	v0, v6, v18
     cc0:      	shl.2d	v0, v0, #0x2
     cc4:      	add.2d	v4, v7, v0
     cc8:      	tbz	w11, #0x4, 0xc64 <_llm_rows.packet_batch.blocks+0x5e8>
     ccc:      	fmov	x12, d4
     cd0:      	ld1.s	{ v3 }[0], [x12]
     cd4:      	tbz	w11, #0x5, 0xc68 <_llm_rows.packet_batch.blocks+0x5ec>
     cd8:      	mov.d	x12, v4[1]
     cdc:      	ld1.s	{ v3 }[1], [x12]
     ce0:      	add.2d	v0, v6, v17
     ce4:      	shl.2d	v0, v0, #0x2
     ce8:      	add.2d	v4, v7, v0
     cec:      	tbz	w11, #0x6, 0xc78 <_llm_rows.packet_batch.blocks+0x5fc>
     cf0:      	fmov	x12, d4
     cf4:      	ld1.s	{ v3 }[2], [x12]
     cf8:      	tbz	w11, #0x7, 0xbf0 <_llm_rows.packet_batch.blocks+0x574>
     cfc:      	mov.d	x11, v4[1]
     d00:      	ld1.s	{ v3 }[3], [x11]
     d04:      	b	0xbf0 <_llm_rows.packet_batch.blocks+0x574>
     d08:      	stp	q1, q18, [sp, #0x60]
     d0c:      	mov	x9, #0x0                ; =0
     d10:      	stp	q5, q16, [sp, #0xa0]
     d14:      	stp	q27, q17, [sp, #0x80]
     d18:      	b	0xd28 <_llm_rows.packet_batch.blocks+0x6ac>
     d1c:      	add	x9, x9, #0x1
     d20:      	cmp	x9, #0x300
     d24:      	b.eq	0x784 <_llm_rows.packet_batch.blocks+0x108>
     d28:      	lsl	x10, x9, #5
     d2c:      	add	x11, x26, x10
     d30:      	ldr	q0, [x11]
     d34:      	and.16b	v3, v5, v0
     d38:      	dup.4s	v0, w14
     d3c:      	str	q0, [sp, #0x100]
     d40:      	fmul.4s	v0, v3, v0
     d44:      	fmul.4s	v0, v3, v0
     d48:      	fmul.4s	v0, v3, v0
     d4c:      	fadd.4s	v0, v3, v0
     d50:      	dup.4s	v1, w15
     d54:      	str	q1, [sp, #0xf0]
     d58:      	fmul.4s	v0, v0, v1
     d5c:      	and.16b	v10, v5, v0
     d60:      	fabs.4s	v22, v10
     d64:      	fmov.4s	v7, #1.00000000
     d68:      	dup.4s	v1, w16
     d6c:      	dup.4s	v20, w17
     d70:      	fmul.4s	v0, v10, v10
     d74:      	mov.16b	v2, v20
     d78:      	str	q1, [sp, #0xe0]
     d7c:      	fmla.4s	v2, v0, v1
     d80:      	dup.4s	v23, w0
     d84:      	mov.16b	v4, v23
     d88:      	fmla.4s	v4, v0, v2
     d8c:      	dup.4s	v24, w1
     d90:      	mov.16b	v2, v24
     d94:      	dup.4s	v25, w2
     d98:      	fmla.4s	v2, v0, v4
     d9c:      	mov.16b	v4, v25
     da0:      	fmla.4s	v4, v0, v2
     da4:      	dup.4s	v16, w3
     da8:      	mov.16b	v2, v16
     dac:      	fmla.4s	v2, v0, v4
     db0:      	mov.16b	v4, v7
     db4:      	fmla.4s	v4, v0, v2
     db8:      	fmul.4s	v2, v22, v4
     dbc:      	dup.4s	v1, w4
     dc0:      	dup.4s	v26, w5
     dc4:      	mov.16b	v4, v26
     dc8:      	str	q1, [sp, #0xd0]
     dcc:      	fmla.4s	v4, v0, v1
     dd0:      	dup.4s	v28, w6
     dd4:      	mov.16b	v27, v5
     dd8:      	mov.16b	v5, v28
     ddc:      	fmla.4s	v5, v0, v4
     de0:      	dup.4s	v29, w7
     de4:      	mov.16b	v4, v29
     de8:      	fmla.4s	v4, v0, v5
     dec:      	dup.4s	v30, w30
     df0:      	mov.16b	v5, v30
     df4:      	fmla.4s	v5, v0, v4
     df8:      	movi.4s	v4, #0x3f, lsl #24
     dfc:      	fmla.4s	v4, v0, v5
     e00:      	mov.16b	v5, v7
     e04:      	fmla.4s	v5, v0, v4
     e08:      	fdiv.4s	v0, v2, v5
     e0c:      	fmov.4s	v31, #9.00000000
     e10:      	fcmge.4s	v4, v31, v22
     e14:      	and.16b	v2, v4, v22
     e18:      	dup.4s	v9, w21
     e1c:      	fcmge.4s	v5, v2, v9
     e20:      	mov	w12, #0x42c80000        ; =1120403456
     e24:      	dup.4s	v17, w12
     e28:      	fcmge.4s	v6, v17, v2
     e2c:      	and.16b	v5, v5, v6
     e30:      	and.16b	v5, v5, v2
     e34:      	mov	w12, #0xaa3b            ; =43579
     e38:      	movk	w12, #0x3fb8, lsl #16
     e3c:      	dup.4s	v11, w12
     e40:      	fmul.4s	v6, v5, v11
     e44:      	movi.4s	v1, #0x4b, lsl #24
     e48:      	fadd.4s	v6, v6, v1
     e4c:      	movi.4s	v1, #0xcb, lsl #24
     e50:      	fadd.4s	v6, v6, v1
     e54:      	fcvtzs.4s	v1, v6
     e58:      	scvtf.4s	v6, v1
     e5c:      	mov	w12, #0x7200            ; =29184
     e60:      	movk	w12, #0xbf31, lsl #16
     e64:      	dup.4s	v12, w12
     e68:      	fmul.4s	v8, v6, v12
     e6c:      	fadd.4s	v5, v5, v8
     e70:      	mov	w12, #0xbe8e            ; =48782
     e74:      	movk	w12, #0xb5bf, lsl #16
     e78:      	dup.4s	v13, w12
     e7c:      	fmul.4s	v6, v6, v13
     e80:      	mov	w12, #0x2bda            ; =11226
     e84:      	movk	w12, #0x3950, lsl #16
     e88:      	dup.4s	v14, w12
     e8c:      	fadd.4s	v5, v5, v6
     e90:      	fmul.4s	v6, v5, v14
     e94:      	mov	w12, #0x96c9            ; =38601
     e98:      	movk	w12, #0x3ab6, lsl #16
     e9c:      	dup.4s	v15, w12
     ea0:      	fadd.4s	v6, v6, v15
     ea4:      	fmul.4s	v6, v5, v6
     ea8:      	mov	w12, #0x88a6            ; =34982
     eac:      	movk	w12, #0x3c08, lsl #16
     eb0:      	dup.4s	v8, w12
     eb4:      	fadd.4s	v6, v6, v8
     eb8:      	fmul.4s	v18, v5, v6
     ebc:      	mov	w12, #0xaa7a            ; =43642
     ec0:      	movk	w12, #0x3d2a, lsl #16
     ec4:      	dup.4s	v6, w12
     ec8:      	fadd.4s	v18, v18, v6
     ecc:      	fmul.4s	v18, v5, v18
     ed0:      	fadd.4s	v18, v18, v16
     ed4:      	fmul.4s	v18, v5, v18
     ed8:      	movi.4s	v21, #0x3f, lsl #24
     edc:      	fadd.4s	v18, v18, v21
     ee0:      	fmul.4s	v19, v5, v5
     ee4:      	fmul.4s	v18, v19, v18
     ee8:      	fadd.4s	v5, v5, v18
     eec:      	fadd.4s	v5, v5, v7
     ef0:      	movi.2d	v18, #0xffffffffffffffff
     ef4:      	add.4s	v1, v1, v18
     ef8:      	sshr.4s	v18, v1, #0x1
     efc:      	shl.4s	v19, v18, #0x17
     f00:      	add.4s	v19, v19, v7
     f04:      	fmul.4s	v5, v5, v19
     f08:      	sub.4s	v1, v1, v18
     f0c:      	shl.4s	v1, v1, #0x17
     f10:      	add.4s	v1, v1, v7
     f14:      	fmul.4s	v1, v5, v1
     f18:      	fcmgt.4s	v2, v2, v17
     f1c:      	ldr	q5, [sp, #0x120]
     f20:      	bit.16b	v1, v5, v2
     f24:      	fmov.4s	v2, #0.25000000
     f28:      	fdiv.4s	v5, v2, v1
     f2c:      	fsub.4s	v18, v1, v5
     f30:      	fadd.4s	v1, v1, v5
     f34:      	fdiv.4s	v1, v18, v1
     f38:      	bif.16b	v1, v7, v4
     f3c:      	ldr	q4, [x11, #0x10]
     f40:      	ldr	q5, [sp, #0x130]
     f44:      	fmov	w11, s5
     f48:      	fcmge.4s	v5, v7, v22
     f4c:      	bif.16b	v0, v1, v5
     f50:      	dup.2d	v22, x9
     f54:      	ldr	q1, [sp, #0x60]
     f58:      	add.2d	v1, v22, v1
     f5c:      	fmul.4s	v3, v3, v21
     f60:      	mvni.4s	v5, #0x80, lsl #24
     f64:      	bif.16b	v0, v10, v5
     f68:      	fcmeq.4s	v5, v10, v10
     f6c:      	fadd.4s	v0, v0, v7
     f70:      	ldr	q18, [sp, #0x110]
     f74:      	bif.16b	v0, v18, v5
     f78:      	fmul.4s	v0, v3, v0
     f7c:      	add	x10, x28, x10
     f80:      	ldp	q5, q3, [x10]
     f84:      	str	q3, [sp, #0xc0]
     f88:      	and.16b	v5, v27, v5
     f8c:      	fadd.4s	v5, v5, v0
     f90:      	shl.2d	v0, v1, #0x2
     f94:      	dup.2d	v10, x8
     f98:      	add.2d	v0, v10, v0
     f9c:      	tbnz	w11, #0x0, 0x1174 <_llm_rows.packet_batch.blocks+0xaf8>
     fa0:      	and	w10, w11, #0xff
     fa4:      	ldr	q27, [sp, #0x80]
     fa8:      	tbnz	w10, #0x1, 0x1188 <_llm_rows.packet_batch.blocks+0xb0c>
     fac:      	add.2d	v0, v22, v27
     fb0:      	shl.2d	v0, v0, #0x2
     fb4:      	add.2d	v0, v10, v0
     fb8:      	tbnz	w10, #0x2, 0x11a0 <_llm_rows.packet_batch.blocks+0xb24>
     fbc:      	tbz	w10, #0x3, 0xfc8 <_llm_rows.packet_batch.blocks+0x94c>
     fc0:      	mov.d	x11, v0[1]
     fc4:      	st1.s	{ v5 }[3], [x11]
     fc8:      	ldr	q3, [sp, #0xb0]
     fcc:      	and.16b	v4, v3, v4
     fd0:      	ldp	q1, q0, [sp, #0xf0]
     fd4:      	fmul.4s	v0, v4, v0
     fd8:      	fmul.4s	v0, v4, v0
     fdc:      	fmul.4s	v0, v4, v0
     fe0:      	fadd.4s	v0, v4, v0
     fe4:      	fmul.4s	v0, v0, v1
     fe8:      	and.16b	v18, v3, v0
     fec:      	fmul.4s	v0, v18, v18
     ff0:      	ldr	q1, [sp, #0xe0]
     ff4:      	fmla.4s	v20, v0, v1
     ff8:      	fmla.4s	v23, v0, v20
     ffc:      	fmla.4s	v24, v0, v23
    1000:      	fmla.4s	v25, v0, v24
    1004:      	mov.16b	v1, v16
    1008:      	fmla.4s	v1, v0, v25
    100c:      	mov.16b	v5, v7
    1010:      	fmla.4s	v5, v0, v1
    1014:      	ldr	q1, [sp, #0xd0]
    1018:      	fmla.4s	v26, v0, v1
    101c:      	fmla.4s	v28, v0, v26
    1020:      	fmla.4s	v29, v0, v28
    1024:      	fmla.4s	v30, v0, v29
    1028:      	movi.4s	v1, #0x3f, lsl #24
    102c:      	fmla.4s	v1, v0, v30
    1030:      	mov.16b	v19, v7
    1034:      	fmla.4s	v19, v0, v1
    1038:      	fabs.4s	v0, v18
    103c:      	fmul.4s	v1, v0, v5
    1040:      	fdiv.4s	v1, v1, v19
    1044:      	fcmge.4s	v5, v31, v0
    1048:      	and.16b	v19, v5, v0
    104c:      	fcmge.4s	v20, v19, v9
    1050:      	fcmge.4s	v21, v17, v19
    1054:      	and.16b	v20, v20, v21
    1058:      	and.16b	v20, v20, v19
    105c:      	fmul.4s	v21, v20, v11
    1060:      	movi.4s	v23, #0x4b, lsl #24
    1064:      	fadd.4s	v21, v21, v23
    1068:      	movi.4s	v23, #0xcb, lsl #24
    106c:      	fadd.4s	v21, v21, v23
    1070:      	fcvtzs.4s	v21, v21
    1074:      	scvtf.4s	v23, v21
    1078:      	fmul.4s	v24, v23, v12
    107c:      	fadd.4s	v20, v20, v24
    1080:      	fmul.4s	v23, v23, v13
    1084:      	fadd.4s	v20, v20, v23
    1088:      	fmul.4s	v23, v20, v14
    108c:      	fadd.4s	v23, v23, v15
    1090:      	fmul.4s	v23, v20, v23
    1094:      	fadd.4s	v23, v23, v8
    1098:      	fmul.4s	v23, v20, v23
    109c:      	fadd.4s	v6, v23, v6
    10a0:      	fmul.4s	v6, v20, v6
    10a4:      	fadd.4s	v6, v6, v16
    10a8:      	fmul.4s	v6, v20, v6
    10ac:      	movi.4s	v23, #0x3f, lsl #24
    10b0:      	fadd.4s	v6, v6, v23
    10b4:      	fmul.4s	v16, v20, v20
    10b8:      	fmul.4s	v6, v16, v6
    10bc:      	fadd.4s	v6, v20, v6
    10c0:      	fadd.4s	v6, v6, v7
    10c4:      	movi.2d	v16, #0xffffffffffffffff
    10c8:      	add.4s	v16, v21, v16
    10cc:      	sshr.4s	v20, v16, #0x1
    10d0:      	shl.4s	v21, v20, #0x17
    10d4:      	add.4s	v21, v21, v7
    10d8:      	fmul.4s	v6, v6, v21
    10dc:      	sub.4s	v16, v16, v20
    10e0:      	shl.4s	v16, v16, #0x17
    10e4:      	add.4s	v16, v16, v7
    10e8:      	fmul.4s	v6, v6, v16
    10ec:      	fcmgt.4s	v16, v19, v17
    10f0:      	ldr	q17, [sp, #0x120]
    10f4:      	bit.16b	v6, v17, v16
    10f8:      	fdiv.4s	v2, v2, v6
    10fc:      	fsub.4s	v16, v6, v2
    1100:      	fadd.4s	v2, v6, v2
    1104:      	fdiv.4s	v2, v16, v2
    1108:      	bif.16b	v2, v7, v5
    110c:      	fcmge.4s	v0, v7, v0
    1110:      	bsl.16b	v0, v1, v2
    1114:      	mvni.4s	v1, #0x80, lsl #24
    1118:      	bif.16b	v0, v18, v1
    111c:      	fadd.4s	v0, v0, v7
    1120:      	fcmeq.4s	v1, v18, v18
    1124:      	ldr	q2, [sp, #0x110]
    1128:      	bif.16b	v0, v2, v1
    112c:      	fmul.4s	v1, v4, v23
    1130:      	fmul.4s	v0, v1, v0
    1134:      	ldr	q1, [sp, #0xc0]
    1138:      	and.16b	v1, v3, v1
    113c:      	fadd.4s	v2, v1, v0
    1140:      	ldr	q0, [sp, #0x70]
    1144:      	add.2d	v0, v22, v0
    1148:      	shl.2d	v0, v0, #0x2
    114c:      	add.2d	v0, v10, v0
    1150:      	tbnz	w10, #0x4, 0x11b0 <_llm_rows.packet_batch.blocks+0xb34>
    1154:      	ldp	q17, q5, [sp, #0x90]
    1158:      	tbnz	w10, #0x5, 0x11c0 <_llm_rows.packet_batch.blocks+0xb44>
    115c:      	add.2d	v0, v22, v17
    1160:      	shl.2d	v0, v0, #0x2
    1164:      	add.2d	v0, v10, v0
    1168:      	tbnz	w10, #0x6, 0x11d8 <_llm_rows.packet_batch.blocks+0xb5c>
    116c:      	tbz	w10, #0x7, 0xd1c <_llm_rows.packet_batch.blocks+0x6a0>
    1170:      	b	0x11e4 <_llm_rows.packet_batch.blocks+0xb68>
    1174:      	fmov	x10, d0
    1178:      	str	s5, [x10]
    117c:      	and	w10, w11, #0xff
    1180:      	ldr	q27, [sp, #0x80]
    1184:      	tbz	w10, #0x1, 0xfac <_llm_rows.packet_batch.blocks+0x930>
    1188:      	mov.d	x11, v0[1]
    118c:      	st1.s	{ v5 }[1], [x11]
    1190:      	add.2d	v0, v22, v27
    1194:      	shl.2d	v0, v0, #0x2
    1198:      	add.2d	v0, v10, v0
    119c:      	tbz	w10, #0x2, 0xfbc <_llm_rows.packet_batch.blocks+0x940>
    11a0:      	fmov	x11, d0
    11a4:      	st1.s	{ v5 }[2], [x11]
    11a8:      	tbnz	w10, #0x3, 0xfc0 <_llm_rows.packet_batch.blocks+0x944>
    11ac:      	b	0xfc8 <_llm_rows.packet_batch.blocks+0x94c>
    11b0:      	fmov	x11, d0
    11b4:      	str	s2, [x11]
    11b8:      	ldp	q17, q5, [sp, #0x90]
    11bc:      	tbz	w10, #0x5, 0x115c <_llm_rows.packet_batch.blocks+0xae0>
    11c0:      	mov.d	x11, v0[1]
    11c4:      	st1.s	{ v2 }[1], [x11]
    11c8:      	add.2d	v0, v22, v17
    11cc:      	shl.2d	v0, v0, #0x2
    11d0:      	add.2d	v0, v10, v0
    11d4:      	tbz	w10, #0x6, 0x116c <_llm_rows.packet_batch.blocks+0xaf0>
    11d8:      	fmov	x11, d0
    11dc:      	st1.s	{ v2 }[2], [x11]
    11e0:      	tbz	w10, #0x7, 0xd1c <_llm_rows.packet_batch.blocks+0x6a0>
    11e4:      	mov.d	x10, v0[1]
    11e8:      	st1.s	{ v2 }[3], [x10]
    11ec:      	b	0xd1c <_llm_rows.packet_batch.blocks+0x6a0>
    11f0:      	add	sp, sp, #0xc, lsl #12   ; =0xc000
    11f4:      	add	sp, sp, #0x150
    11f8:      	ldp	x29, x30, [sp, #0x90]
    11fc:      	ldp	x20, x19, [sp, #0x80]
    1200:      	ldp	x22, x21, [sp, #0x70]
    1204:      	ldp	x24, x23, [sp, #0x60]
    1208:      	ldp	x26, x25, [sp, #0x50]
    120c:      	ldp	x28, x27, [sp, #0x40]
    1210:      	ldp	d9, d8, [sp, #0x30]
    1214:      	ldp	d11, d10, [sp, #0x20]
    1218:      	ldp	d13, d12, [sp, #0x10]
    121c:      	ldp	d15, d14, [sp], #0xa0
    1220:      	ret


/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/masked_softmax-257x1538/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000700 <_kernel>:
     700:      	sub	sp, sp, #0xf0
     704:      	stp	d9, d8, [sp, #0x80]
     708:      	stp	x28, x27, [sp, #0x90]
     70c:      	stp	x26, x25, [sp, #0xa0]
     710:      	stp	x24, x23, [sp, #0xb0]
     714:      	stp	x22, x21, [sp, #0xc0]
     718:      	stp	x20, x19, [sp, #0xd0]
     71c:      	stp	x29, x30, [sp, #0xe0]
     720:      	add	x29, sp, #0xe0
     724:      	mov	x19, x3
     728:      	mov	x20, x2
     72c:      	mov	x21, x1
     730:      	mov	x22, x0
     734:      	str	wzr, [sp, #0x60]
     738:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     73c:      	ldr	x9, [x9, #0xa8]
     740:      	add	x8, sp, #0x60
     744:      	str	x8, [x9]
     748:      	mov	w25, #0x1808            ; =6152
     74c:      	mov	w0, #0x1808             ; =6152
     750:      	bl	0x18c4 <dyld_stub_binder+0x18c4>
     754:      	mov	x23, x0
     758:      	mov	w1, #0x1808             ; =6152
     75c:      	bl	0x1924 <dyld_stub_binder+0x1924>
     760:      	mov	x26, #0x0               ; =0
     764:      	adrp	x8, 0x1000 <__ZNSt12length_errorC1B9nqe220108EPKc+0xc>
     768:      	ldr	q4, [x8, #0xb10]
     76c:      	mov	w8, #0xf2ca             ; =62154
     770:      	movk	w8, #0xf149, lsl #16
     774:      	dup.4s	v5, w8
     778:      	adrp	x27, 0x4000 <dyld_stub_binder+0x4000>
     77c:      	ldr	x27, [x27, #0x80]
     780:      	movi.2d	v8, #0000000000000000
     784:      	stp	q5, q4, [sp, #0x10]
     788:      	mov	x8, #0x0                ; =0
     78c:      	dup.2d	v6, x26
     790:      	mvni.4s	v0, #0x7f, msl #16
     794:      	mov	x9, x22
     798:      	cmp	x8, #0x5ff
     79c:      	b.hi	0x8ec <_kernel+0x1ec>
     7a0:      	ldr	q1, [x9], #0x10
     7a4:      	dup.2d	v2, x8
     7a8:      	add	x10, x8, #0x2
     7ac:      	dup.2d	v3, x10
     7b0:      	orr.16b	v2, v2, v4
     7b4:      	orr.16b	v3, v3, v4
     7b8:      	cmhs.2d	v2, v6, v2
     7bc:      	cmhs.2d	v3, v6, v3
     7c0:      	cmeq.2d	v2, v2, #0
     7c4:      	cmeq.2d	v3, v3, #0
     7c8:      	uzp1.4s	v2, v2, v3
     7cc:      	bit.16b	v1, v5, v2
     7d0:      	fmax.4s	v0, v0, v1
     7d4:      	cmp	x8, #0x5fe
     7d8:      	add	x8, x8, #0x4
     7dc:      	b.lo	0x798 <_kernel+0x98>
     7e0:      	mov	w8, #-0x800000          ; =-8388608
     7e4:      	fmov	s1, w8
     7e8:      	mov	x28, #0x0               ; =0
     7ec:      	mov	x24, #0x0               ; =0
     7f0:      	ext.16b	v2, v0, v0, #0x8
     7f4:      	fmax.4s	v0, v0, v2
     7f8:      	rev64.4s	v2, v0
     7fc:      	fmax.4s	v0, v0, v2
     800:      	fcmp	s1, s0
     804:      	fcsel	s0, s1, s0, gt
     808:      	str	s0, [x21, x26, lsl #2]
     80c:      	dup.4s	v0, v0[0]
     810:      	stp	q6, q0, [sp, #0x30]
     814:      	ldr	q0, [x27]
     818:      	str	q0, [sp]
     81c:      	movi.2d	v1, #0000000000000000
     820:      	str	q1, [sp, #0x50]
     824:      	cmp	x24, #0x600
     828:      	b.hs	0x8f8 <_kernel+0x1f8>
     82c:      	ldr	q0, [x22, x28]
     830:      	dup.2d	v1, x24
     834:      	orr.16b	v1, v1, v4
     838:      	add	x8, x24, #0x2
     83c:      	dup.2d	v2, x8
     840:      	orr.16b	v2, v2, v4
     844:      	cmhs.2d	v1, v6, v1
     848:      	cmhs.2d	v2, v6, v2
     84c:      	cmeq.2d	v1, v1, #0
     850:      	cmeq.2d	v2, v2, #0
     854:      	uzp1.4s	v1, v1, v2
     858:      	bit.16b	v0, v5, v1
     85c:      	ldr	q1, [sp, #0x40]
     860:      	fsub.4s	v0, v0, v1
     864:      	bl	0x17c8 <dyld_stub_binder+0x17c8>
     868:      	ldp	q4, q6, [sp, #0x20]
     86c:      	ldr	q5, [sp, #0x10]
     870:      	str	q0, [x23, x28]
     874:      	ldr	q1, [sp, #0x50]
     878:      	fadd.4s	v1, v1, v0
     87c:      	add	x28, x28, #0x10
     880:      	cmp	x24, #0x5fe
     884:      	add	x24, x24, #0x4
     888:      	b.lo	0x820 <_kernel+0x120>
     88c:      	mov	x8, #0x0                ; =0
     890:      	dup.2d	v0, v1[1]
     894:      	fadd.4s	v0, v1, v0
     898:      	faddp.2s	s0, v0
     89c:      	fadd	s0, s0, s8
     8a0:      	str	s0, [x20, x26, lsl #2]
     8a4:      	mov	x9, #-0x4               ; =-4
     8a8:      	add	x9, x9, #0x4
     8ac:      	ldr	s0, [x20, x26, lsl #2]
     8b0:      	cmp	x9, #0x600
     8b4:      	b.hs	0x950 <_kernel+0x250>
     8b8:      	ldr	q1, [x23, x8]
     8bc:      	dup.4s	v0, v0[0]
     8c0:      	fdiv.4s	v0, v1, v0
     8c4:      	str	q0, [x19, x8]
     8c8:      	add	x8, x8, #0x10
     8cc:      	cmp	x9, #0x5fe
     8d0:      	b.lo	0x8a8 <_kernel+0x1a8>
     8d4:      	add	x26, x26, #0x1
     8d8:      	add	x22, x22, x25
     8dc:      	add	x19, x19, x25
     8e0:      	cmp	x26, #0x101
     8e4:      	b.ne	0x788 <_kernel+0x88>
     8e8:      	b	0x974 <_kernel+0x274>
     8ec:      	mov	w8, #0xf2ca             ; =62154
     8f0:      	movk	w8, #0xf149, lsl #16
     8f4:      	b	0x7e4 <_kernel+0xe4>
     8f8:      	ldr	d0, [x22, x28]
     8fc:      	dup.2d	v1, x24
     900:      	orr.16b	v1, v1, v4
     904:      	add	x8, x24, #0x2
     908:      	dup.2d	v2, x8
     90c:      	orr.16b	v2, v2, v4
     910:      	cmhs.2d	v1, v6, v1
     914:      	cmhs.2d	v2, v6, v2
     918:      	cmeq.2d	v1, v1, #0
     91c:      	cmeq.2d	v2, v2, #0
     920:      	uzp1.4s	v1, v1, v2
     924:      	bit.16b	v0, v5, v1
     928:      	ldr	q1, [sp, #0x40]
     92c:      	fsub.4s	v0, v0, v1
     930:      	bl	0x17c8 <dyld_stub_binder+0x17c8>
     934:      	ldp	q5, q4, [sp, #0x10]
     938:      	str	d0, [x23, x28]
     93c:      	ldr	q1, [sp, #0x50]
     940:      	fadd.4s	v0, v1, v0
     944:      	ldr	q2, [sp]
     948:      	bit.16b	v1, v0, v2
     94c:      	b	0x88c <_kernel+0x18c>
     950:      	ldr	d1, [x23, x8]
     954:      	dup.2s	v0, v0[0]
     958:      	fdiv.2s	v0, v1, v0
     95c:      	str	d0, [x19, x8]
     960:      	add	x26, x26, #0x1
     964:      	add	x22, x22, x25
     968:      	add	x19, x19, x25
     96c:      	cmp	x26, #0x101
     970:      	b.ne	0x788 <_kernel+0x88>
     974:      	mov	x0, x23
     978:      	bl	0x18ac <dyld_stub_binder+0x18ac>
     97c:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     980:      	ldr	x8, [x8, #0xa8]
     984:      	str	xzr, [x8]
     988:      	add	x8, sp, #0x60
     98c:      	ldapr	w8, [x8]
     990:      	cbnz	w8, 0x9b8 <_kernel+0x2b8>
     994:      	ldp	x29, x30, [sp, #0xe0]
     998:      	ldp	x20, x19, [sp, #0xd0]
     99c:      	ldp	x22, x21, [sp, #0xc0]
     9a0:      	ldp	x24, x23, [sp, #0xb0]
     9a4:      	ldp	x26, x25, [sp, #0xa0]
     9a8:      	ldp	x28, x27, [sp, #0x90]
     9ac:      	ldp	d9, d8, [sp, #0x80]
     9b0:      	add	sp, sp, #0xf0
     9b4:      	ret
     9b8:      	mov	w0, #0x10               ; =16
     9bc:      	bl	0x18dc <dyld_stub_binder+0x18dc>
     9c0:      	mov	x19, x0
     9c4:      	mov	w8, #0x33d              ; =829
     9c8:      	str	w8, [sp, #0x64]
     9cc:      	adrp	x0, 0x1000 <__ZNSt12length_errorC1B9nqe220108EPKc+0xc>
     9d0:      	add	x0, x0, #0xc34
     9d4:      	adrp	x1, 0x1000 <__ZNSt12length_errorC1B9nqe220108EPKc+0xc>
     9d8:      	add	x1, x1, #0xcc0
     9dc:      	adrp	x3, 0x1000 <__ZNSt12length_errorC1B9nqe220108EPKc+0xc>
     9e0:      	add	x3, x3, #0xceb
     9e4:      	adrp	x4, 0x1000 <__ZNSt12length_errorC1B9nqe220108EPKc+0xc>
     9e8:      	add	x4, x4, #0xd69
     9ec:      	adrp	x2, 0x1000 <__ZNSt12length_errorC1B9nqe220108EPKc+0xc>
     9f0:      	add	x2, x2, #0xce8
     9f4:      	add	x8, sp, #0x68
     9f8:      	add	x5, sp, #0x64
     9fc:      	adrp	x7, 0x1000 <__ZNSt12length_errorC1B9nqe220108EPKc+0xc>
     a00:      	add	x7, x7, #0xd6b
     a04:      	mov	x6, x2
     a08:      	bl	0xa8c <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     a0c:      	mov	w21, #0x1               ; =1
     a10:      	add	x1, sp, #0x68
     a14:      	mov	x0, x19
     a18:      	bl	0x1810 <dyld_stub_binder+0x1810>
     a1c:      	mov	w21, #0x0               ; =0
     a20:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     a24:      	ldr	x1, [x1, #0x18]
     a28:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     a2c:      	ldr	x2, [x2, #0x8]
     a30:      	mov	x0, x19
     a34:      	bl	0x190c <dyld_stub_binder+0x190c>
     a38:      	brk	#0x1
     a3c:      	mov	x20, x0
     a40:      	ldrsb	w8, [sp, #0x7f]
     a44:      	tbz	w8, #0x1f, 0xa60 <_kernel+0x360>
     a48:      	ldr	x0, [sp, #0x68]
     a4c:      	ldr	x8, [sp, #0x78]
     a50:      	and	x1, x8, #0x7fffffffffffffff
     a54:      	bl	0x18b8 <dyld_stub_binder+0x18b8>
     a58:      	tbnz	w21, #0x0, 0xa6c <_kernel+0x36c>
     a5c:      	b	0xa74 <_kernel+0x374>
     a60:      	cbnz	w21, 0xa6c <_kernel+0x36c>
     a64:      	b	0xa74 <_kernel+0x374>
     a68:      	mov	x20, x0
     a6c:      	mov	x0, x19
     a70:      	bl	0x1900 <dyld_stub_binder+0x1900>
     a74:      	mov	x0, x20
     a78:      	bl	0x17d4 <dyld_stub_binder+0x17d4>

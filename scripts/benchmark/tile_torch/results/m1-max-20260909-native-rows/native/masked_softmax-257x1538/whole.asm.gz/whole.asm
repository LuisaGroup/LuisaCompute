
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/masked_softmax-257x1538-l1/object/tile_xir_w8_80760_1788919112908293_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x80
       4:      	stp	d15, d14, [sp, #0x40]
       8:      	stp	d13, d12, [sp, #0x50]
       c:      	stp	d11, d10, [sp, #0x60]
      10:      	stp	d9, d8, [sp, #0x70]
      14:      	mov	x14, #0x0               ; =0
      18:      	ldr	x11, [x1, #0x88]
      1c:      	add	x8, x11, #0x3f, lsl #12 ; =0x3f000
      20:      	add	x9, x8, #0x110
      24:      	add	x8, x11, #0x33, lsl #12 ; =0x33000
      28:      	add	x8, x8, #0x110
      2c:      	add	x10, x11, #0x33, lsl #12 ; =0x33000
      30:      	add	x13, x10, #0xd0
      34:      	add	x10, x11, #0x27, lsl #12 ; =0x27000
      38:      	add	x12, x10, #0xd0
      3c:      	ldr	w10, [x1]
      40:      	ldr	w15, [x1, #0x24]
      44:      	add	w15, w15, w10, lsl #5
      48:      	ldr	x16, [x0]
      4c:      	ldr	x10, [x0, #0x30]
      50:      	dup.4s	v0, w15
      54:      	adrp	x15, 0x0 <ltmp0>
      58:      	ldr	q1, [x15]
      5c:      	add.4s	v4, v0, v1
      60:      	adrp	x15, 0x0 <ltmp0>
      64:      	ldr	q1, [x15]
      68:      	add.4s	v5, v0, v1
      6c:      	mov	w15, #0x602             ; =1538
      70:      	dup.4s	v3, w15
      74:      	umull2.2d	v0, v4, v3
      78:      	umull2.2d	v1, v5, v3
      7c:      	umull.2d	v2, v4, v3
      80:      	umull.2d	v3, v5, v3
      84:      	dup.2d	v6, x16
      88:      	dup.2d	v7, x14
      8c:      	add.2d	v16, v7, v0
      90:      	add.2d	v17, v7, v2
      94:      	add.2d	v18, v7, v1
      98:      	add.2d	v7, v7, v3
      9c:      	shl.2d	v7, v7, #0x2
      a0:      	shl.2d	v18, v18, #0x2
      a4:      	shl.2d	v17, v17, #0x2
      a8:      	shl.2d	v16, v16, #0x2
      ac:      	add.2d	v16, v6, v16
      b0:      	add.2d	v17, v6, v17
      b4:      	add.2d	v18, v6, v18
      b8:      	add.2d	v7, v6, v7
      bc:      	mov.d	x15, v7[1]
      c0:      	fmov	x16, d7
      c4:      	mov.d	x17, v18[1]
      c8:      	fmov	x0, d18
      cc:      	mov.d	x1, v17[1]
      d0:      	fmov	x2, d17
      d4:      	mov.d	x3, v16[1]
      d8:      	ldr	s7, [x16]
      dc:      	ld1.s	{ v7 }[1], [x15]
      e0:      	fmov	x15, d16
      e4:      	ld1.s	{ v7 }[2], [x0]
      e8:      	ld1.s	{ v7 }[3], [x17]
      ec:      	ldr	s16, [x2]
      f0:      	ld1.s	{ v16 }[1], [x1]
      f4:      	ld1.s	{ v16 }[2], [x15]
      f8:      	ld1.s	{ v16 }[3], [x3]
      fc:      	add	x15, x11, x14, lsl #5
     100:      	stp	q7, q16, [x15]
     104:      	add	x14, x14, #0x1
     108:      	cmp	x14, #0x602
     10c:      	b.ne	0x88 <ltmp0+0x88>
     110:      	stp	q3, q2, [sp]
     114:      	stp	q1, q0, [sp, #0x20]
     118:      	mov	x15, #0x0               ; =0
     11c:      	mov	w14, #0xc040            ; =49216
     120:      	add	x14, x11, x14
     124:      	dup.2d	v6, x15
     128:      	add	x16, x14, x15, lsl #6
     12c:      	stp	q6, q6, [x16, #0x20]
     130:      	stp	q6, q6, [x16]
     134:      	add	x15, x15, #0x1
     138:      	cmp	x15, #0x602
     13c:      	b.ne	0x124 <ltmp0+0x124>
     140:      	mov	x15, #0x0               ; =0
     144:      	mov	w16, #0xda0d            ; =55821
     148:      	movk	w16, #0xaa71, lsl #16
     14c:      	dup.4s	v6, w16
     150:      	mov	w16, #0x602             ; =1538
     154:      	dup.4s	v7, w16
     158:      	add	x16, x11, #0x24, lsl #12 ; =0x24000
     15c:      	add	x16, x16, #0xc0
     160:      	umull2.2d	v16, v5, v6
     164:      	umull.2d	v17, v5, v6
     168:      	uzp2.4s	v16, v17, v16
     16c:      	ushr.4s	v16, v16, #0xa
     170:      	mls.4s	v5, v16, v7
     174:      	umull2.2d	v16, v4, v6
     178:      	umull.2d	v6, v4, v6
     17c:      	uzp2.4s	v6, v6, v16
     180:      	ushr.4s	v6, v6, #0xa
     184:      	mls.4s	v4, v6, v7
     188:      	ushll2.2d	v17, v4, #0x0
     18c:      	ushll2.2d	v18, v5, #0x0
     190:      	ushll.2d	v19, v4, #0x0
     194:      	ushll.2d	v20, v5, #0x0
     198:      	dup.2d	v4, x16
     19c:      	adrp	x16, 0x0 <ltmp0>
     1a0:      	ldr	q5, [x16]
     1a4:      	adrp	x16, 0x0 <ltmp0>
     1a8:      	ldr	q6, [x16]
     1ac:      	adrp	x16, 0x0 <ltmp0>
     1b0:      	ldr	q7, [x16]
     1b4:      	adrp	x16, 0x0 <ltmp0>
     1b8:      	ldr	q16, [x16]
     1bc:      	movi.8b	v21, #0x1
     1c0:      	dup.2d	v22, x15
     1c4:      	add	x16, x14, x15, lsl #6
     1c8:      	ldp	q24, q23, [x16, #0x20]
     1cc:      	ldp	q25, q26, [x16]
     1d0:      	add.2d	v22, v22, v4
     1d4:      	add.2d	v27, v22, v6
     1d8:      	add.2d	v28, v22, v5
     1dc:      	cmge.2d	v26, v18, v26
     1e0:      	cmge.2d	v25, v20, v25
     1e4:      	uzp1.4s	v25, v25, v26
     1e8:      	cmge.2d	v24, v19, v24
     1ec:      	cmge.2d	v23, v17, v23
     1f0:      	uzp1.4s	v23, v24, v23
     1f4:      	uzp1.8h	v23, v25, v23
     1f8:      	xtn.8b	v23, v23
     1fc:      	and.8b	v23, v23, v21
     200:      	mov.d	x16, v28[1]
     204:      	fmov	x17, d28
     208:      	str	b23, [x17]
     20c:      	st1.b	{ v23 }[1], [x16]
     210:      	mov.d	x16, v27[1]
     214:      	fmov	x17, d27
     218:      	st1.b	{ v23 }[2], [x17]
     21c:      	st1.b	{ v23 }[3], [x16]
     220:      	add.2d	v24, v22, v7
     224:      	mov.d	x16, v24[1]
     228:      	fmov	x17, d24
     22c:      	st1.b	{ v23 }[4], [x17]
     230:      	add.2d	v22, v22, v16
     234:      	st1.b	{ v23 }[5], [x16]
     238:      	mov.d	x16, v22[1]
     23c:      	fmov	x17, d22
     240:      	st1.b	{ v23 }[6], [x17]
     244:      	st1.b	{ v23 }[7], [x16]
     248:      	add	x15, x15, #0x1
     24c:      	cmp	x15, #0x602
     250:      	b.ne	0x1c0 <ltmp0+0x1c0>
     254:      	mov	x14, #0x0               ; =0
     258:      	mov	w15, #0xf2ca            ; =62154
     25c:      	movk	w15, #0xf149, lsl #16
     260:      	dup.4s	v17, w15
     264:      	dup.2d	v18, x14
     268:      	add.2d	v18, v18, v4
     26c:      	add.2d	v19, v18, v16
     270:      	add.2d	v20, v18, v5
     274:      	mov.d	x15, v20[1]
     278:      	add.2d	v21, v18, v7
     27c:      	add.2d	v18, v18, v6
     280:      	fmov	x16, d20
     284:      	mov.d	x17, v18[1]
     288:      	mov.d	x0, v21[1]
     28c:      	fmov	x1, d18
     290:      	ldr	b18, [x16]
     294:      	ld1.b	{ v18 }[1], [x15]
     298:      	mov.d	x15, v19[1]
     29c:      	fmov	x16, d21
     2a0:      	ld1.b	{ v18 }[2], [x1]
     2a4:      	ld1.b	{ v18 }[3], [x17]
     2a8:      	fmov	x17, d19
     2ac:      	ld1.b	{ v18 }[4], [x16]
     2b0:      	ld1.b	{ v18 }[5], [x0]
     2b4:      	ld1.b	{ v18 }[6], [x17]
     2b8:      	ld1.b	{ v18 }[7], [x15]
     2bc:      	cmeq.8b	v18, v18, #0
     2c0:      	sshll.8h	v18, v18, #0x0
     2c4:      	sshll2.4s	v19, v18, #0x0
     2c8:      	sshll.4s	v18, v18, #0x0
     2cc:      	lsl	x15, x14, #5
     2d0:      	add	x16, x11, x15
     2d4:      	ldp	q21, q20, [x16]
     2d8:      	bsl.16b	v18, v17, v21
     2dc:      	bsl.16b	v19, v17, v20
     2e0:      	add	x15, x12, x15
     2e4:      	stp	q18, q19, [x15]
     2e8:      	add	x14, x14, #0x1
     2ec:      	cmp	x14, #0x602
     2f0:      	b.ne	0x264 <ltmp0+0x264>
     2f4:      	mov	x14, #0x0               ; =0
     2f8:      	ldp	q23, q24, [x12]
     2fc:      	ldp	q22, q21, [x12, #0x20]
     300:      	ldp	q18, q17, [x12, #0x40]
     304:      	add	x15, x11, #0x27, lsl #12 ; =0x27000
     308:      	add	x15, x15, #0x190
     30c:      	ldp	q19, q20, [x12, #0x60]
     310:      	add	x16, x15, x14, lsl #5
     314:      	ldp	q25, q26, [x16, #-0x40]
     318:      	fmaxnm.4s	v24, v24, v26
     31c:      	fmaxnm.4s	v23, v23, v25
     320:      	ldp	q25, q26, [x16, #-0x20]
     324:      	fmaxnm.4s	v21, v21, v26
     328:      	fmaxnm.4s	v22, v22, v25
     32c:      	ldp	q25, q26, [x16]
     330:      	fmaxnm.4s	v17, v17, v26
     334:      	fmaxnm.4s	v18, v18, v25
     338:      	ldp	q25, q26, [x16, #0x20]
     33c:      	fmaxnm.4s	v20, v20, v26
     340:      	fmaxnm.4s	v19, v19, v25
     344:      	add	x14, x14, #0x4
     348:      	cmp	x14, #0x5fc
     34c:      	b.lo	0x310 <ltmp0+0x310>
     350:      	ldp	q25, q26, [x13]
     354:      	fmaxnm.4s	v24, v24, v26
     358:      	fmaxnm.4s	v23, v23, v25
     35c:      	ldp	q26, q25, [x13, #0x20]
     360:      	fmaxnm.4s	v22, v22, v26
     364:      	fmaxnm.4s	v21, v21, v25
     368:      	mvni.4s	v9, #0x7f, msl #16
     36c:      	fmaxnm.4s	v23, v23, v9
     370:      	fmaxnm.4s	v24, v24, v9
     374:      	fmaxnm.4s	v21, v24, v21
     378:      	fmaxnm.4s	v22, v23, v22
     37c:      	fmaxnm.4s	v18, v22, v18
     380:      	fmaxnm.4s	v17, v21, v17
     384:      	fmaxnm.4s	v17, v17, v20
     388:      	fmaxnm.4s	v18, v18, v19
     38c:      	mov	x13, #-0x602            ; =-1538
     390:      	mov	w14, #-0x3d300000       ; =-1026555904
     394:      	dup.4s	v19, w14
     398:      	mov	w14, #0x42c80000        ; =1120403456
     39c:      	dup.4s	v20, w14
     3a0:      	mov	w14, #0xaa3b            ; =43579
     3a4:      	movk	w14, #0x3fb8, lsl #16
     3a8:      	dup.4s	v21, w14
     3ac:      	movi.4s	v22, #0x4b, lsl #24
     3b0:      	mov	w14, #0x7200            ; =29184
     3b4:      	movk	w14, #0xbf31, lsl #16
     3b8:      	dup.4s	v23, w14
     3bc:      	mov	w14, #0xbe8e            ; =48782
     3c0:      	movk	w14, #0xb5bf, lsl #16
     3c4:      	dup.4s	v24, w14
     3c8:      	mov	w14, #0x2bda            ; =11226
     3cc:      	movk	w14, #0x3950, lsl #16
     3d0:      	dup.4s	v25, w14
     3d4:      	mov	w14, #0x96c9            ; =38601
     3d8:      	movk	w14, #0x3ab6, lsl #16
     3dc:      	dup.4s	v26, w14
     3e0:      	mov	w14, #0x88a6            ; =34982
     3e4:      	movk	w14, #0x3c08, lsl #16
     3e8:      	dup.4s	v27, w14
     3ec:      	mov	w14, #0xaa7a            ; =43642
     3f0:      	movk	w14, #0x3d2a, lsl #16
     3f4:      	dup.4s	v28, w14
     3f8:      	mov	w14, #0xaaab            ; =43691
     3fc:      	movk	w14, #0x3e2a, lsl #16
     400:      	dup.4s	v29, w14
     404:      	mvni.4s	v30, #0x80, lsl #24
     408:      	movi.4s	v31, #0x3f, lsl #24
     40c:      	fmov.4s	v8, #1.00000000
     410:      	fneg.4s	v9, v9
     414:      	mvni.4s	v10, #0x3f, msl #16
     418:      	fneg.4s	v10, v10
     41c:      	add	x14, x13, #0x602
     420:      	dup.2d	v11, x14
     424:      	add.2d	v11, v11, v4
     428:      	add.2d	v12, v11, v16
     42c:      	add.2d	v13, v11, v7
     430:      	add.2d	v14, v11, v6
     434:      	add.2d	v11, v11, v5
     438:      	mov.d	x14, v11[1]
     43c:      	fmov	x16, d11
     440:      	mov.d	x15, v14[1]
     444:      	fmov	x0, d14
     448:      	mov.d	x17, v13[1]
     44c:      	fmov	x2, d13
     450:      	mov.d	x1, v12[1]
     454:      	fmov	x3, d12
     458:      	ldp	q11, q12, [x12]
     45c:      	fsub.4s	v12, v12, v17
     460:      	fsub.4s	v11, v11, v18
     464:      	fcmge.4s	v13, v11, v19
     468:      	fcmge.4s	v14, v12, v19
     46c:      	fcmge.4s	v15, v20, v11
     470:      	fcmge.4s	v0, v20, v12
     474:      	and.16b	v0, v14, v0
     478:      	and.16b	v13, v13, v15
     47c:      	and.16b	v13, v13, v11
     480:      	and.16b	v0, v0, v12
     484:      	fmul.4s	v14, v0, v21
     488:      	fmul.4s	v15, v13, v21
     48c:      	mov.16b	v1, v30
     490:      	bsl.16b	v1, v22, v15
     494:      	mov.16b	v2, v30
     498:      	bsl.16b	v2, v22, v14
     49c:      	fadd.4s	v14, v14, v2
     4a0:      	fadd.4s	v15, v15, v1
     4a4:      	fsub.4s	v1, v15, v1
     4a8:      	fsub.4s	v2, v14, v2
     4ac:      	fcvtzs.4s	v2, v2
     4b0:      	fcvtzs.4s	v1, v1
     4b4:      	scvtf.4s	v14, v1
     4b8:      	scvtf.4s	v15, v2
     4bc:      	fmul.4s	v3, v14, v23
     4c0:      	fadd.4s	v3, v13, v3
     4c4:      	fmul.4s	v13, v15, v23
     4c8:      	fadd.4s	v0, v0, v13
     4cc:      	fmul.4s	v13, v14, v24
     4d0:      	fmul.4s	v14, v15, v24
     4d4:      	fadd.4s	v0, v0, v14
     4d8:      	fadd.4s	v3, v3, v13
     4dc:      	fmul.4s	v13, v3, v25
     4e0:      	fmul.4s	v14, v0, v25
     4e4:      	fadd.4s	v14, v14, v26
     4e8:      	fadd.4s	v13, v13, v26
     4ec:      	fmul.4s	v13, v3, v13
     4f0:      	fmul.4s	v14, v0, v14
     4f4:      	fadd.4s	v14, v14, v27
     4f8:      	fadd.4s	v13, v13, v27
     4fc:      	fmul.4s	v13, v3, v13
     500:      	fmul.4s	v14, v0, v14
     504:      	fadd.4s	v14, v14, v28
     508:      	fadd.4s	v13, v13, v28
     50c:      	fmul.4s	v13, v3, v13
     510:      	fmul.4s	v14, v0, v14
     514:      	fadd.4s	v14, v14, v29
     518:      	fadd.4s	v13, v13, v29
     51c:      	fmul.4s	v13, v3, v13
     520:      	fmul.4s	v14, v0, v14
     524:      	fadd.4s	v14, v14, v31
     528:      	fadd.4s	v13, v13, v31
     52c:      	fmul.4s	v15, v3, v3
     530:      	fmul.4s	v13, v15, v13
     534:      	fmul.4s	v15, v0, v0
     538:      	fmul.4s	v14, v15, v14
     53c:      	fadd.4s	v0, v0, v14
     540:      	fadd.4s	v3, v3, v13
     544:      	fadd.4s	v3, v3, v8
     548:      	fadd.4s	v0, v0, v8
     54c:      	sshr.4s	v13, v1, #0x1
     550:      	sshr.4s	v14, v2, #0x1
     554:      	shl.4s	v15, v14, #0x17
     558:      	add.4s	v15, v15, v8
     55c:      	fmul.4s	v0, v0, v15
     560:      	shl.4s	v15, v13, #0x17
     564:      	add.4s	v15, v15, v8
     568:      	fmul.4s	v3, v3, v15
     56c:      	sub.4s	v2, v2, v14
     570:      	sub.4s	v1, v1, v13
     574:      	shl.4s	v1, v1, #0x17
     578:      	add.4s	v1, v1, v8
     57c:      	fmul.4s	v1, v3, v1
     580:      	shl.4s	v2, v2, #0x17
     584:      	add.4s	v2, v2, v8
     588:      	fmul.4s	v0, v0, v2
     58c:      	fcmgt.4s	v2, v19, v12
     590:      	bic.16b	v0, v0, v2
     594:      	fcmgt.4s	v2, v19, v11
     598:      	bic.16b	v1, v1, v2
     59c:      	fcmgt.4s	v2, v11, v20
     5a0:      	bit.16b	v1, v9, v2
     5a4:      	fcmgt.4s	v2, v12, v20
     5a8:      	bit.16b	v0, v9, v2
     5ac:      	fcmeq.4s	v2, v12, v12
     5b0:      	bif.16b	v0, v10, v2
     5b4:      	ldr	b2, [x16]
     5b8:      	ld1.b	{ v2 }[1], [x14]
     5bc:      	ld1.b	{ v2 }[2], [x0]
     5c0:      	ld1.b	{ v2 }[3], [x15]
     5c4:      	ld1.b	{ v2 }[4], [x2]
     5c8:      	ld1.b	{ v2 }[5], [x17]
     5cc:      	ld1.b	{ v2 }[6], [x3]
     5d0:      	ld1.b	{ v2 }[7], [x1]
     5d4:      	cmeq.8b	v2, v2, #0
     5d8:      	sshll.8h	v2, v2, #0x0
     5dc:      	fcmeq.4s	v3, v11, v11
     5e0:      	bif.16b	v1, v10, v3
     5e4:      	sshll.4s	v3, v2, #0x0
     5e8:      	bic.16b	v1, v1, v3
     5ec:      	sshll2.4s	v2, v2, #0x0
     5f0:      	bic.16b	v0, v0, v2
     5f4:      	str	q0, [x12, #0xc050]
     5f8:      	str	q1, [x12, #0xc040]
     5fc:      	add	x12, x12, #0x20
     600:      	adds	x13, x13, #0x1
     604:      	b.lo	0x41c <ltmp0+0x41c>
     608:      	mov	x12, #0x0               ; =0
     60c:      	ldp	q18, q19, [x8]
     610:      	ldp	q17, q16, [x8, #0x20]
     614:      	ldp	q5, q4, [x8, #0x40]
     618:      	add	x11, x11, #0x33, lsl #12 ; =0x33000
     61c:      	add	x11, x11, #0x1d0
     620:      	ldp	q6, q7, [x8, #0x60]
     624:      	add	x13, x11, x12, lsl #5
     628:      	ldp	q0, q1, [x13, #-0x40]
     62c:      	fadd.4s	v19, v19, v1
     630:      	fadd.4s	v18, v18, v0
     634:      	ldp	q0, q1, [x13, #-0x20]
     638:      	fadd.4s	v16, v16, v1
     63c:      	fadd.4s	v17, v17, v0
     640:      	ldp	q0, q1, [x13]
     644:      	fadd.4s	v4, v4, v1
     648:      	fadd.4s	v5, v5, v0
     64c:      	ldp	q0, q1, [x13, #0x20]
     650:      	fadd.4s	v7, v7, v1
     654:      	fadd.4s	v6, v6, v0
     658:      	add	x12, x12, #0x4
     65c:      	cmp	x12, #0x5fc
     660:      	b.lo	0x624 <ltmp0+0x624>
     664:      	mov	x11, #0x0               ; =0
     668:      	ldp	q0, q1, [x9]
     66c:      	fadd.4s	v1, v19, v1
     670:      	fadd.4s	v0, v18, v0
     674:      	ldp	q3, q2, [x9, #0x20]
     678:      	fadd.4s	v3, v17, v3
     67c:      	fadd.4s	v2, v16, v2
     680:      	movi.2d	v16, #0000000000000000
     684:      	fadd.4s	v0, v0, v16
     688:      	fadd.4s	v1, v1, v16
     68c:      	fadd.4s	v1, v1, v2
     690:      	fadd.4s	v0, v0, v3
     694:      	fadd.4s	v0, v5, v0
     698:      	fadd.4s	v1, v4, v1
     69c:      	fadd.4s	v4, v7, v1
     6a0:      	fadd.4s	v5, v6, v0
     6a4:      	dup.2d	v6, x10
     6a8:      	ldp	q18, q17, [sp, #0x20]
     6ac:      	ldp	q20, q19, [sp]
     6b0:      	dup.2d	v0, x11
     6b4:      	add.2d	v1, v0, v17
     6b8:      	add.2d	v2, v0, v19
     6bc:      	add.2d	v3, v0, v18
     6c0:      	add.2d	v0, v0, v20
     6c4:      	add	x9, x8, x11, lsl #5
     6c8:      	ldp	q7, q16, [x9]
     6cc:      	fdiv.4s	v16, v16, v4
     6d0:      	fdiv.4s	v7, v7, v5
     6d4:      	shl.2d	v0, v0, #0x2
     6d8:      	shl.2d	v3, v3, #0x2
     6dc:      	shl.2d	v2, v2, #0x2
     6e0:      	shl.2d	v1, v1, #0x2
     6e4:      	add.2d	v1, v6, v1
     6e8:      	add.2d	v0, v6, v0
     6ec:      	mov.d	x9, v0[1]
     6f0:      	fmov	x10, d0
     6f4:      	str	s7, [x10]
     6f8:      	st1.s	{ v7 }[1], [x9]
     6fc:      	add.2d	v0, v6, v3
     700:      	mov.d	x9, v0[1]
     704:      	fmov	x10, d0
     708:      	st1.s	{ v7 }[2], [x10]
     70c:      	add.2d	v0, v6, v2
     710:      	st1.s	{ v7 }[3], [x9]
     714:      	mov.d	x9, v0[1]
     718:      	fmov	x10, d0
     71c:      	str	s16, [x10]
     720:      	st1.s	{ v16 }[1], [x9]
     724:      	mov.d	x9, v1[1]
     728:      	fmov	x10, d1
     72c:      	st1.s	{ v16 }[2], [x10]
     730:      	st1.s	{ v16 }[3], [x9]
     734:      	add	x11, x11, #0x1
     738:      	cmp	x11, #0x602
     73c:      	b.ne	0x6b0 <ltmp0+0x6b0>
     740:      	ldp	d9, d8, [sp, #0x70]
     744:      	ldp	d11, d10, [sp, #0x60]
     748:      	ldp	d13, d12, [sp, #0x50]
     74c:      	ldp	d15, d14, [sp, #0x40]
     750:      	add	sp, sp, #0x80
     754:      	ret

0000000000000758 <_llm_rows.packet_batch.blocks>:
     758:      	sub	sp, sp, #0x130
     75c:      	stp	d15, d14, [sp, #0x90]
     760:      	stp	d13, d12, [sp, #0xa0]
     764:      	stp	d11, d10, [sp, #0xb0]
     768:      	stp	d9, d8, [sp, #0xc0]
     76c:      	stp	x28, x27, [sp, #0xd0]
     770:      	stp	x26, x25, [sp, #0xe0]
     774:      	stp	x24, x23, [sp, #0xf0]
     778:      	stp	x22, x21, [sp, #0x100]
     77c:      	stp	x20, x19, [sp, #0x110]
     780:      	stp	x29, x30, [sp, #0x120]
     784:      	str	x0, [sp, #0x68]
     788:      	cbz	w3, 0x14c4 <_llm_rows.packet_batch.blocks+0xd6c>
     78c:      	mov	x21, x3
     790:      	mov	x20, x2
     794:      	mov	w22, #0x0               ; =0
     798:      	ldp	w9, w8, [x2, #0x2c]
     79c:      	stp	w8, w9, [sp, #0x60]
     7a0:      	ldp	w27, w26, [x2]
     7a4:      	ldp	w25, w28, [x2, #0x8]
     7a8:      	mov	w8, #0x602              ; =1538
     7ac:      	adrp	x9, 0x0 <ltmp0>
     7b0:      	ldr	q0, [x9]
     7b4:      	str	q0, [sp, #0x50]
     7b8:      	adrp	x9, 0x0 <ltmp0>
     7bc:      	ldr	q0, [x9]
     7c0:      	str	q0, [sp, #0x40]
     7c4:      	dup.4s	v0, w8
     7c8:      	str	q0, [sp, #0x20]
     7cc:      	adrp	x8, 0x0 <ltmp0>
     7d0:      	ldr	q0, [x8]
     7d4:      	str	q0, [sp, #0x10]
     7d8:      	movi.8b	v8, #0x1
     7dc:      	mvni.4s	v13, #0x7f, msl #16
     7e0:      	movi.4s	v14, #0x4b, lsl #24
     7e4:      	mvni.4s	v15, #0x80, lsl #24
     7e8:      	mvni.4s	v0, #0x3f, msl #16
     7ec:      	fneg.4s	v0, v0
     7f0:      	str	q0, [sp, #0x70]
     7f4:      	mov	w24, #0xaa7a            ; =43642
     7f8:      	movk	w24, #0x3d2a, lsl #16
     7fc:      	mov	w19, #0xaaab            ; =43691
     800:      	movk	w19, #0x3e2a, lsl #16
     804:      	str	w3, [sp, #0x3c]
     808:      	b	0x850 <_llm_rows.packet_batch.blocks+0xf8>
     80c:      	mov	w8, #0x18               ; =24
     810:      	str	w8, [x20, #0x24]
     814:      	ldr	w21, [sp, #0x3c]
     818:      	add	w8, w27, #0x1
     81c:      	ldp	w10, w9, [sp, #0x60]
     820:      	cmp	w8, w9
     824:      	cset	w8, eq
     828:      	csinc	w27, wzr, w27, eq
     82c:      	cinc	w9, w26, eq
     830:      	cmp	w9, w10
     834:      	cset	w10, eq
     838:      	ands	w8, w8, w10
     83c:      	csel	w26, wzr, w9, ne
     840:      	add	w25, w25, w8
     844:      	add	w22, w22, #0x1
     848:      	cmp	w22, w21
     84c:      	b.eq	0x14c4 <_llm_rows.packet_batch.blocks+0xd6c>
     850:      	ubfiz	x8, x27, #5, #32
     854:      	cmp	x8, x28
     858:      	csel	x9, x8, xzr, ls
     85c:      	subs	x10, x28, x9
     860:      	cmp	x10, #0x20
     864:      	mov	w11, #0x20              ; =32
     868:      	csel	x10, x10, x11, lo
     86c:      	cmp	x28, x9
     870:      	stp	w27, w26, [x20]
     874:      	str	w25, [x20, #0x8]
     878:      	str	wzr, [x20, #0x24]
     87c:      	ccmp	x8, x28, #0x2, hi
     880:      	csel	x23, x10, xzr, ls
     884:      	cmp	x23, #0x20
     888:      	b.lo	0x8e8 <_llm_rows.packet_batch.blocks+0x190>
     88c:      	ldr	x23, [sp, #0x68]
     890:      	mov	x0, x23
     894:      	mov	x1, x20
     898:      	bl	0x898 <_llm_rows.packet_batch.blocks+0x140>
     89c:      	mov	w8, #0x8                ; =8
     8a0:      	str	w8, [x20, #0x24]
     8a4:      	mov	x0, x23
     8a8:      	mov	x1, x20
     8ac:      	bl	0x8ac <_llm_rows.packet_batch.blocks+0x154>
     8b0:      	mov	w8, #0x10               ; =16
     8b4:      	str	w8, [x20, #0x24]
     8b8:      	mov	x0, x23
     8bc:      	mov	x1, x20
     8c0:      	bl	0x8c0 <_llm_rows.packet_batch.blocks+0x168>
     8c4:      	mov	w8, #0x18               ; =24
     8c8:      	str	w8, [x20, #0x24]
     8cc:      	mov	x0, x23
     8d0:      	mov	x1, x20
     8d4:      	bl	0x8d4 <_llm_rows.packet_batch.blocks+0x17c>
     8d8:      	mvni.4s	v15, #0x80, lsl #24
     8dc:      	movi.4s	v14, #0x4b, lsl #24
     8e0:      	mvni.4s	v13, #0x7f, msl #16
     8e4:      	b	0x818 <_llm_rows.packet_batch.blocks+0xc0>
     8e8:      	lsr	x21, x23, #3
     8ec:      	cmp	x23, #0x8
     8f0:      	b.lo	0x960 <_llm_rows.packet_batch.blocks+0x208>
     8f4:      	str	wzr, [x20, #0x24]
     8f8:      	ldr	x0, [sp, #0x68]
     8fc:      	mov	x1, x20
     900:      	bl	0x900 <_llm_rows.packet_batch.blocks+0x1a8>
     904:      	mvni.4s	v15, #0x80, lsl #24
     908:      	movi.4s	v14, #0x4b, lsl #24
     90c:      	mvni.4s	v13, #0x7f, msl #16
     910:      	cmp	x21, #0x1
     914:      	b.eq	0x960 <_llm_rows.packet_batch.blocks+0x208>
     918:      	mov	w8, #0x8                ; =8
     91c:      	str	w8, [x20, #0x24]
     920:      	ldr	x0, [sp, #0x68]
     924:      	mov	x1, x20
     928:      	bl	0x928 <_llm_rows.packet_batch.blocks+0x1d0>
     92c:      	mvni.4s	v15, #0x80, lsl #24
     930:      	movi.4s	v14, #0x4b, lsl #24
     934:      	mvni.4s	v13, #0x7f, msl #16
     938:      	cmp	x21, #0x2
     93c:      	b.eq	0x960 <_llm_rows.packet_batch.blocks+0x208>
     940:      	mov	w8, #0x10               ; =16
     944:      	str	w8, [x20, #0x24]
     948:      	ldr	x0, [sp, #0x68]
     94c:      	mov	x1, x20
     950:      	bl	0x950 <_llm_rows.packet_batch.blocks+0x1f8>
     954:      	mvni.4s	v15, #0x80, lsl #24
     958:      	movi.4s	v14, #0x4b, lsl #24
     95c:      	mvni.4s	v13, #0x7f, msl #16
     960:      	and	w8, w23, #0x7
     964:      	cbz	w8, 0x80c <_llm_rows.packet_batch.blocks+0xb4>
     968:      	dup.4s	v7, w8
     96c:      	ldp	q0, q1, [sp, #0x40]
     970:      	cmhi.4s	v0, v7, v0
     974:      	cmhi.4s	v1, v7, v1
     978:      	uzp1.8h	v6, v1, v0
     97c:      	umaxv.8h	h2, v6
     980:      	fmov	w8, s2
     984:      	tbz	w8, #0x0, 0x80c <_llm_rows.packet_batch.blocks+0xb4>
     988:      	mov	x15, #0x0               ; =0
     98c:      	ldr	x11, [x20, #0x88]
     990:      	mov	w8, #0xf110             ; =61712
     994:      	movk	w8, #0x3, lsl #16
     998:      	add	x10, x11, x8
     99c:      	mov	w8, #0x3110             ; =12560
     9a0:      	movk	w8, #0x3, lsl #16
     9a4:      	add	x8, x11, x8
     9a8:      	mov	w9, #0x30d0             ; =12496
     9ac:      	movk	w9, #0x3, lsl #16
     9b0:      	add	x13, x11, x9
     9b4:      	mov	w9, #0x70d0             ; =28880
     9b8:      	movk	w9, #0x2, lsl #16
     9bc:      	add	x12, x11, x9
     9c0:      	mov	w9, #0xc040             ; =49216
     9c4:      	add	x14, x11, x9
     9c8:      	mov	w9, #0x40c0             ; =16576
     9cc:      	movk	w9, #0x2, lsl #16
     9d0:      	add	x9, x11, x9
     9d4:      	dup.2d	v16, x9
     9d8:      	ldr	x17, [sp, #0x68]
     9dc:      	ldr	x16, [x17]
     9e0:      	lsl	w9, w21, #3
     9e4:      	orr	w9, w9, w27, lsl #5
     9e8:      	dup.4s	v2, w9
     9ec:      	ldr	x9, [x17, #0x30]
     9f0:      	ldp	q4, q3, [sp, #0x40]
     9f4:      	orr.16b	v3, v2, v3
     9f8:      	orr.16b	v2, v2, v4
     9fc:      	and.16b	v17, v0, v2
     a00:      	and.16b	v18, v1, v3
     a04:      	ldp	q19, q5, [sp, #0x10]
     a08:      	umull2.2d	v2, v17, v5
     a0c:      	umull2.2d	v3, v18, v5
     a10:      	umull.2d	v4, v17, v5
     a14:      	umull.2d	v5, v18, v5
     a18:      	and.16b	v6, v6, v19
     a1c:      	addv.8h	h6, v6
     a20:      	dup.2d	v19, x16
     a24:      	fmov	w16, s6
     a28:      	mov	w7, #0xf2ca             ; =62154
     a2c:      	movk	w7, #0xf149, lsl #16
     a30:      	b	0xa54 <_llm_rows.packet_batch.blocks+0x2fc>
     a34:      	add	x17, x11, x15, lsl #5
     a38:      	ldp	q22, q23, [x17]
     a3c:      	bif.16b	v21, v23, v0
     a40:      	bif.16b	v20, v22, v1
     a44:      	stp	q20, q21, [x17]
     a48:      	add	x15, x15, #0x1
     a4c:      	cmp	x15, #0x602
     a50:      	b.eq	0xb40 <_llm_rows.packet_batch.blocks+0x3e8>
     a54:      	dup.2d	v22, x15
     a58:      	add.2d	v20, v22, v5
     a5c:      	shl.2d	v20, v20, #0x2
     a60:      	add.2d	v23, v19, v20
     a64:      	movi.2d	v20, #0000000000000000
     a68:      	movi.2d	v21, #0000000000000000
     a6c:      	tbnz	w16, #0x0, 0xab8 <_llm_rows.packet_batch.blocks+0x360>
     a70:      	and	w17, w16, #0xff
     a74:      	tbnz	w17, #0x1, 0xac8 <_llm_rows.packet_batch.blocks+0x370>
     a78:      	add.2d	v23, v22, v3
     a7c:      	shl.2d	v23, v23, #0x2
     a80:      	add.2d	v23, v19, v23
     a84:      	tbnz	w17, #0x2, 0xae0 <_llm_rows.packet_batch.blocks+0x388>
     a88:      	tbnz	w17, #0x3, 0xaec <_llm_rows.packet_batch.blocks+0x394>
     a8c:      	add.2d	v23, v22, v4
     a90:      	shl.2d	v23, v23, #0x2
     a94:      	add.2d	v23, v19, v23
     a98:      	tbnz	w17, #0x4, 0xb04 <_llm_rows.packet_batch.blocks+0x3ac>
     a9c:      	tbnz	w17, #0x5, 0xb10 <_llm_rows.packet_batch.blocks+0x3b8>
     aa0:      	add.2d	v22, v22, v2
     aa4:      	shl.2d	v22, v22, #0x2
     aa8:      	add.2d	v22, v19, v22
     aac:      	tbnz	w17, #0x6, 0xb28 <_llm_rows.packet_batch.blocks+0x3d0>
     ab0:      	tbz	w17, #0x7, 0xa34 <_llm_rows.packet_batch.blocks+0x2dc>
     ab4:      	b	0xb34 <_llm_rows.packet_batch.blocks+0x3dc>
     ab8:      	fmov	x17, d23
     abc:      	ldr	s20, [x17]
     ac0:      	and	w17, w16, #0xff
     ac4:      	tbz	w17, #0x1, 0xa78 <_llm_rows.packet_batch.blocks+0x320>
     ac8:      	mov.d	x0, v23[1]
     acc:      	ld1.s	{ v20 }[1], [x0]
     ad0:      	add.2d	v23, v22, v3
     ad4:      	shl.2d	v23, v23, #0x2
     ad8:      	add.2d	v23, v19, v23
     adc:      	tbz	w17, #0x2, 0xa88 <_llm_rows.packet_batch.blocks+0x330>
     ae0:      	fmov	x0, d23
     ae4:      	ld1.s	{ v20 }[2], [x0]
     ae8:      	tbz	w17, #0x3, 0xa8c <_llm_rows.packet_batch.blocks+0x334>
     aec:      	mov.d	x0, v23[1]
     af0:      	ld1.s	{ v20 }[3], [x0]
     af4:      	add.2d	v23, v22, v4
     af8:      	shl.2d	v23, v23, #0x2
     afc:      	add.2d	v23, v19, v23
     b00:      	tbz	w17, #0x4, 0xa9c <_llm_rows.packet_batch.blocks+0x344>
     b04:      	fmov	x0, d23
     b08:      	ld1.s	{ v21 }[0], [x0]
     b0c:      	tbz	w17, #0x5, 0xaa0 <_llm_rows.packet_batch.blocks+0x348>
     b10:      	mov.d	x0, v23[1]
     b14:      	ld1.s	{ v21 }[1], [x0]
     b18:      	add.2d	v22, v22, v2
     b1c:      	shl.2d	v22, v22, #0x2
     b20:      	add.2d	v22, v19, v22
     b24:      	tbz	w17, #0x6, 0xab0 <_llm_rows.packet_batch.blocks+0x358>
     b28:      	fmov	x0, d22
     b2c:      	ld1.s	{ v21 }[2], [x0]
     b30:      	tbz	w17, #0x7, 0xa34 <_llm_rows.packet_batch.blocks+0x2dc>
     b34:      	mov.d	x17, v22[1]
     b38:      	ld1.s	{ v21 }[3], [x17]
     b3c:      	b	0xa34 <_llm_rows.packet_batch.blocks+0x2dc>
     b40:      	mov	x15, #0x0               ; =0
     b44:      	sshll2.2d	v24, v0, #0x0
     b48:      	sshll2.2d	v22, v1, #0x0
     b4c:      	sshll.2d	v19, v0, #0x0
     b50:      	sshll.2d	v20, v1, #0x0
     b54:      	dup.2d	v21, x15
     b58:      	add	x16, x14, x15, lsl #6
     b5c:      	ldp	q25, q23, [x16, #0x20]
     b60:      	ldp	q27, q26, [x16]
     b64:      	bsl.16b	v20, v21, v27
     b68:      	bsl.16b	v19, v21, v25
     b6c:      	mov.16b	v25, v22
     b70:      	bsl.16b	v25, v21, v26
     b74:      	bif.16b	v21, v23, v24
     b78:      	stp	q19, q21, [x16, #0x20]
     b7c:      	stp	q20, q25, [x16]
     b80:      	add	x15, x15, #0x1
     b84:      	cmp	x15, #0x602
     b88:      	b.ne	0xb44 <_llm_rows.packet_batch.blocks+0x3ec>
     b8c:      	mov	x15, #0x0               ; =0
     b90:      	sshll.2d	v30, v1, #0x0
     b94:      	sshll.2d	v29, v0, #0x0
     b98:      	ldr	q21, [sp, #0x20]
     b9c:      	and.16b	v19, v0, v21
     ba0:      	mvn.16b	v20, v0
     ba4:      	sub.4s	v19, v19, v20
     ba8:      	and.16b	v20, v1, v21
     bac:      	mvn.16b	v21, v1
     bb0:      	sub.4s	v20, v20, v21
     bb4:      	mov.s	w16, v20[1]
     bb8:      	mov.s	w17, v18[1]
     bbc:      	udiv	w0, w17, w16
     bc0:      	msub	w16, w0, w16, w17
     bc4:      	mov.s	w17, v20[3]
     bc8:      	mov.s	w0, v20[2]
     bcc:      	fmov	w1, s20
     bd0:      	fmov	w2, s18
     bd4:      	udiv	w3, w2, w1
     bd8:      	msub	w1, w3, w1, w2
     bdc:      	mov.s	w2, v18[3]
     be0:      	udiv	w3, w2, w17
     be4:      	msub	w17, w3, w17, w2
     be8:      	mov.s	w2, v18[2]
     bec:      	udiv	w3, w2, w0
     bf0:      	msub	w0, w3, w0, w2
     bf4:      	mov.s	w2, v19[1]
     bf8:      	mov.s	w3, v17[1]
     bfc:      	udiv	w4, w3, w2
     c00:      	msub	w2, w4, w2, w3
     c04:      	mov.s	w3, v19[3]
     c08:      	mov.s	w4, v17[3]
     c0c:      	udiv	w5, w4, w3
     c10:      	msub	w3, w5, w3, w4
     c14:      	mov.s	w4, v19[2]
     c18:      	mov.s	w5, v17[2]
     c1c:      	udiv	w6, w5, w4
     c20:      	msub	w4, w6, w4, w5
     c24:      	fmov	w5, s19
     c28:      	fmov	w6, s17
     c2c:      	fmov	s17, w4
     c30:      	mov.s	v17[1], w3
     c34:      	udiv	w3, w6, w5
     c38:      	msub	w3, w3, w5, w6
     c3c:      	ushll.2d	v19, v17, #0x0
     c40:      	fmov	s17, w3
     c44:      	mov.s	v17[1], w2
     c48:      	ushll.2d	v20, v17, #0x0
     c4c:      	fmov	s17, w0
     c50:      	mov.s	v17[1], w17
     c54:      	fmov	s18, w1
     c58:      	mov.s	v18[1], w16
     c5c:      	ushll.2d	v21, v17, #0x0
     c60:      	ushll.2d	v23, v18, #0x0
     c64:      	and.16b	v25, v24, v16
     c68:      	and.16b	v26, v22, v16
     c6c:      	and.16b	v27, v29, v16
     c70:      	and.16b	v28, v30, v16
     c74:      	adrp	x16, 0x0 <ltmp0>
     c78:      	ldr	q16, [x16]
     c7c:      	and.16b	v24, v24, v16
     c80:      	adrp	x16, 0x0 <ltmp0>
     c84:      	ldr	q16, [x16]
     c88:      	and.16b	v22, v22, v16
     c8c:      	adrp	x16, 0x0 <ltmp0>
     c90:      	ldr	q16, [x16]
     c94:      	and.16b	v29, v29, v16
     c98:      	adrp	x16, 0x0 <ltmp0>
     c9c:      	ldr	q16, [x16]
     ca0:      	and.16b	v30, v30, v16
     ca4:      	ldp	q16, q17, [sp, #0x40]
     ca8:      	cmhs.4s	v16, v16, v7
     cac:      	cmhs.4s	v7, v17, v7
     cb0:      	uzp1.8h	v7, v7, v16
     cb4:      	xtn.8b	v31, v7
     cb8:      	mov	w0, #-0x3d300000        ; =-1026555904
     cbc:      	mov	w1, #0x42c80000         ; =1120403456
     cc0:      	mov	w2, #0xaa3b             ; =43579
     cc4:      	movk	w2, #0x3fb8, lsl #16
     cc8:      	mov	w3, #0x7200             ; =29184
     ccc:      	movk	w3, #0xbf31, lsl #16
     cd0:      	mov	w4, #0xbe8e             ; =48782
     cd4:      	movk	w4, #0xb5bf, lsl #16
     cd8:      	mov	w5, #0x2bda             ; =11226
     cdc:      	movk	w5, #0x3950, lsl #16
     ce0:      	mov	w6, #0x96c9             ; =38601
     ce4:      	movk	w6, #0x3ab6, lsl #16
     ce8:      	mov	w21, #0x88a6            ; =34982
     cec:      	movk	w21, #0x3c08, lsl #16
     cf0:      	b	0xd00 <_llm_rows.packet_batch.blocks+0x5a8>
     cf4:      	add	x15, x15, #0x1
     cf8:      	cmp	x15, #0x602
     cfc:      	b.eq	0xe00 <_llm_rows.packet_batch.blocks+0x6a8>
     d00:      	dup.2d	v9, x15
     d04:      	fmov	w16, s6
     d08:      	add	x17, x14, x15, lsl #6
     d0c:      	ldp	q16, q7, [x17, #0x20]
     d10:      	ldp	q17, q18, [x17]
     d14:      	cmge.2d	v18, v21, v18
     d18:      	cmge.2d	v17, v23, v17
     d1c:      	uzp1.4s	v17, v17, v18
     d20:      	cmge.2d	v16, v20, v16
     d24:      	cmge.2d	v7, v19, v7
     d28:      	uzp1.4s	v7, v16, v7
     d2c:      	uzp1.8h	v7, v17, v7
     d30:      	xtn.8b	v7, v7
     d34:      	orr.8b	v17, v31, v7
     d38:      	add.2d	v7, v28, v30
     d3c:      	add.2d	v16, v7, v9
     d40:      	and.8b	v10, v17, v8
     d44:      	tbnz	w16, #0x0, 0xd84 <_llm_rows.packet_batch.blocks+0x62c>
     d48:      	and	w16, w16, #0xff
     d4c:      	tbnz	w16, #0x1, 0xd94 <_llm_rows.packet_batch.blocks+0x63c>
     d50:      	add.2d	v16, v26, v22
     d54:      	add.2d	v17, v16, v9
     d58:      	tbnz	w16, #0x2, 0xda8 <_llm_rows.packet_batch.blocks+0x650>
     d5c:      	tbnz	w16, #0x3, 0xdb4 <_llm_rows.packet_batch.blocks+0x65c>
     d60:      	add.2d	v17, v27, v29
     d64:      	add.2d	v18, v17, v9
     d68:      	tbnz	w16, #0x4, 0xdc8 <_llm_rows.packet_batch.blocks+0x670>
     d6c:      	tbnz	w16, #0x5, 0xdd4 <_llm_rows.packet_batch.blocks+0x67c>
     d70:      	add.2d	v18, v25, v24
     d74:      	add.2d	v9, v18, v9
     d78:      	tbnz	w16, #0x6, 0xde8 <_llm_rows.packet_batch.blocks+0x690>
     d7c:      	tbz	w16, #0x7, 0xcf4 <_llm_rows.packet_batch.blocks+0x59c>
     d80:      	b	0xdf4 <_llm_rows.packet_batch.blocks+0x69c>
     d84:      	fmov	x17, d16
     d88:      	str	b10, [x17]
     d8c:      	and	w16, w16, #0xff
     d90:      	tbz	w16, #0x1, 0xd50 <_llm_rows.packet_batch.blocks+0x5f8>
     d94:      	mov.d	x17, v16[1]
     d98:      	st1.b	{ v10 }[1], [x17]
     d9c:      	add.2d	v16, v26, v22
     da0:      	add.2d	v17, v16, v9
     da4:      	tbz	w16, #0x2, 0xd5c <_llm_rows.packet_batch.blocks+0x604>
     da8:      	fmov	x17, d17
     dac:      	st1.b	{ v10 }[2], [x17]
     db0:      	tbz	w16, #0x3, 0xd60 <_llm_rows.packet_batch.blocks+0x608>
     db4:      	mov.d	x17, v17[1]
     db8:      	st1.b	{ v10 }[3], [x17]
     dbc:      	add.2d	v17, v27, v29
     dc0:      	add.2d	v18, v17, v9
     dc4:      	tbz	w16, #0x4, 0xd6c <_llm_rows.packet_batch.blocks+0x614>
     dc8:      	fmov	x17, d18
     dcc:      	st1.b	{ v10 }[4], [x17]
     dd0:      	tbz	w16, #0x5, 0xd70 <_llm_rows.packet_batch.blocks+0x618>
     dd4:      	mov.d	x17, v18[1]
     dd8:      	st1.b	{ v10 }[5], [x17]
     ddc:      	add.2d	v18, v25, v24
     de0:      	add.2d	v9, v18, v9
     de4:      	tbz	w16, #0x6, 0xd7c <_llm_rows.packet_batch.blocks+0x624>
     de8:      	fmov	x17, d9
     dec:      	st1.b	{ v10 }[6], [x17]
     df0:      	tbz	w16, #0x7, 0xcf4 <_llm_rows.packet_batch.blocks+0x59c>
     df4:      	mov.d	x16, v9[1]
     df8:      	st1.b	{ v10 }[7], [x16]
     dfc:      	b	0xcf4 <_llm_rows.packet_batch.blocks+0x59c>
     e00:      	mov	x14, #0x0               ; =0
     e04:      	b	0xe58 <_llm_rows.packet_batch.blocks+0x700>
     e08:      	cmeq.8b	v19, v19, #0
     e0c:      	sshll.8h	v19, v19, #0x0
     e10:      	sshll2.4s	v20, v19, #0x0
     e14:      	sshll.4s	v19, v19, #0x0
     e18:      	lsl	x15, x14, #5
     e1c:      	add	x16, x11, x15
     e20:      	ldp	q21, q22, [x16]
     e24:      	and.16b	v22, v0, v22
     e28:      	dup.4s	v23, w7
     e2c:      	and.16b	v21, v1, v21
     e30:      	bsl.16b	v19, v23, v21
     e34:      	bsl.16b	v20, v23, v22
     e38:      	add	x15, x12, x15
     e3c:      	ldp	q21, q22, [x15]
     e40:      	bif.16b	v20, v22, v0
     e44:      	bif.16b	v19, v21, v1
     e48:      	stp	q19, q20, [x15]
     e4c:      	add	x14, x14, #0x1
     e50:      	cmp	x14, #0x602
     e54:      	b.eq	0xf08 <_llm_rows.packet_batch.blocks+0x7b0>
     e58:      	fmov	w15, s6
     e5c:      	dup.2d	v20, x14
     e60:      	add.2d	v21, v7, v20
     e64:      	tbz	w15, #0x0, 0xe7c <_llm_rows.packet_batch.blocks+0x724>
     e68:      	fmov	x16, d21
     e6c:      	ldr	b19, [x16]
     e70:      	and	w15, w15, #0xff
     e74:      	tbnz	w15, #0x1, 0xe88 <_llm_rows.packet_batch.blocks+0x730>
     e78:      	b	0xe90 <_llm_rows.packet_batch.blocks+0x738>
     e7c:      	movi.2d	v19, #0000000000000000
     e80:      	and	w15, w15, #0xff
     e84:      	tbz	w15, #0x1, 0xe90 <_llm_rows.packet_batch.blocks+0x738>
     e88:      	mov.d	x16, v21[1]
     e8c:      	ld1.b	{ v19 }[1], [x16]
     e90:      	add.2d	v21, v16, v20
     e94:      	tbnz	w15, #0x2, 0xeb8 <_llm_rows.packet_batch.blocks+0x760>
     e98:      	tbnz	w15, #0x3, 0xec4 <_llm_rows.packet_batch.blocks+0x76c>
     e9c:      	add.2d	v21, v17, v20
     ea0:      	tbnz	w15, #0x4, 0xed4 <_llm_rows.packet_batch.blocks+0x77c>
     ea4:      	tbnz	w15, #0x5, 0xee0 <_llm_rows.packet_batch.blocks+0x788>
     ea8:      	add.2d	v20, v18, v20
     eac:      	tbnz	w15, #0x6, 0xef0 <_llm_rows.packet_batch.blocks+0x798>
     eb0:      	tbz	w15, #0x7, 0xe08 <_llm_rows.packet_batch.blocks+0x6b0>
     eb4:      	b	0xefc <_llm_rows.packet_batch.blocks+0x7a4>
     eb8:      	fmov	x16, d21
     ebc:      	ld1.b	{ v19 }[2], [x16]
     ec0:      	tbz	w15, #0x3, 0xe9c <_llm_rows.packet_batch.blocks+0x744>
     ec4:      	mov.d	x16, v21[1]
     ec8:      	ld1.b	{ v19 }[3], [x16]
     ecc:      	add.2d	v21, v17, v20
     ed0:      	tbz	w15, #0x4, 0xea4 <_llm_rows.packet_batch.blocks+0x74c>
     ed4:      	fmov	x16, d21
     ed8:      	ld1.b	{ v19 }[4], [x16]
     edc:      	tbz	w15, #0x5, 0xea8 <_llm_rows.packet_batch.blocks+0x750>
     ee0:      	mov.d	x16, v21[1]
     ee4:      	ld1.b	{ v19 }[5], [x16]
     ee8:      	add.2d	v20, v18, v20
     eec:      	tbz	w15, #0x6, 0xeb0 <_llm_rows.packet_batch.blocks+0x758>
     ef0:      	fmov	x16, d20
     ef4:      	ld1.b	{ v19 }[6], [x16]
     ef8:      	tbz	w15, #0x7, 0xe08 <_llm_rows.packet_batch.blocks+0x6b0>
     efc:      	mov.d	x15, v20[1]
     f00:      	ld1.b	{ v19 }[7], [x15]
     f04:      	b	0xe08 <_llm_rows.packet_batch.blocks+0x6b0>
     f08:      	mov	x14, #0x0               ; =0
     f0c:      	ldp	q19, q20, [x12]
     f10:      	ldp	q21, q22, [x12, #0x20]
     f14:      	ldp	q27, q28, [x12, #0x40]
     f18:      	and.16b	v26, v0, v20
     f1c:      	and.16b	v25, v1, v19
     f20:      	ldp	q20, q29, [x12, #0x60]
     f24:      	and.16b	v23, v0, v22
     f28:      	and.16b	v24, v1, v21
     f2c:      	and.16b	v19, v0, v28
     f30:      	and.16b	v22, v1, v27
     f34:      	and.16b	v21, v0, v29
     f38:      	and.16b	v20, v1, v20
     f3c:      	mov	w15, #0x7190            ; =29072
     f40:      	movk	w15, #0x2, lsl #16
     f44:      	add	x15, x11, x15
     f48:      	add	x16, x15, x14, lsl #5
     f4c:      	ldp	q27, q28, [x16, #-0x40]
     f50:      	and.16b	v28, v0, v28
     f54:      	and.16b	v27, v1, v27
     f58:      	fmaxnm.4s	v27, v25, v27
     f5c:      	fmaxnm.4s	v28, v26, v28
     f60:      	ldp	q29, q30, [x16, #-0x20]
     f64:      	and.16b	v30, v0, v30
     f68:      	and.16b	v29, v1, v29
     f6c:      	fmaxnm.4s	v29, v24, v29
     f70:      	fmaxnm.4s	v30, v23, v30
     f74:      	ldp	q31, q9, [x16]
     f78:      	and.16b	v9, v0, v9
     f7c:      	and.16b	v31, v1, v31
     f80:      	fmaxnm.4s	v31, v22, v31
     f84:      	fmaxnm.4s	v9, v19, v9
     f88:      	ldp	q10, q11, [x16, #0x20]
     f8c:      	and.16b	v11, v0, v11
     f90:      	and.16b	v10, v1, v10
     f94:      	fmaxnm.4s	v10, v20, v10
     f98:      	fmaxnm.4s	v11, v21, v11
     f9c:      	bit.16b	v26, v28, v0
     fa0:      	bit.16b	v25, v27, v1
     fa4:      	bit.16b	v23, v30, v0
     fa8:      	bit.16b	v24, v29, v1
     fac:      	bit.16b	v19, v9, v0
     fb0:      	bit.16b	v22, v31, v1
     fb4:      	bit.16b	v21, v11, v0
     fb8:      	bit.16b	v20, v10, v1
     fbc:      	add	x14, x14, #0x4
     fc0:      	cmp	x14, #0x5fc
     fc4:      	b.lo	0xf48 <_llm_rows.packet_batch.blocks+0x7f0>
     fc8:      	ldp	q28, q27, [x13]
     fcc:      	and.16b	v28, v1, v28
     fd0:      	and.16b	v27, v0, v27
     fd4:      	fmaxnm.4s	v26, v26, v27
     fd8:      	fmaxnm.4s	v25, v25, v28
     fdc:      	ldp	q27, q28, [x13, #0x20]
     fe0:      	and.16b	v28, v0, v28
     fe4:      	and.16b	v27, v1, v27
     fe8:      	fmaxnm.4s	v24, v24, v27
     fec:      	fmaxnm.4s	v23, v23, v28
     ff0:      	fmaxnm.4s	v25, v25, v13
     ff4:      	fmaxnm.4s	v26, v26, v13
     ff8:      	fmaxnm.4s	v23, v26, v23
     ffc:      	fmaxnm.4s	v24, v25, v24
    1000:      	fmaxnm.4s	v22, v24, v22
    1004:      	fmaxnm.4s	v19, v23, v19
    1008:      	fmaxnm.4s	v19, v19, v21
    100c:      	fmaxnm.4s	v20, v22, v20
    1010:      	mov	x13, #-0x602            ; =-1538
    1014:      	b	0x11fc <_llm_rows.packet_batch.blocks+0xaa4>
    1018:      	cmeq.8b	v21, v21, #0
    101c:      	sshll.8h	v22, v21, #0x0
    1020:      	sshll2.4s	v21, v22, #0x0
    1024:      	sshll.4s	v22, v22, #0x0
    1028:      	ldp	q24, q23, [x12]
    102c:      	fsub.4s	v24, v24, v20
    1030:      	fsub.4s	v23, v23, v19
    1034:      	and.16b	v23, v0, v23
    1038:      	and.16b	v24, v1, v24
    103c:      	dup.4s	v25, w0
    1040:      	fcmge.4s	v27, v24, v25
    1044:      	fcmge.4s	v28, v23, v25
    1048:      	dup.4s	v26, w1
    104c:      	fcmge.4s	v29, v26, v24
    1050:      	fcmge.4s	v30, v26, v23
    1054:      	and.16b	v28, v28, v30
    1058:      	and.16b	v27, v27, v29
    105c:      	and.16b	v27, v27, v24
    1060:      	and.16b	v28, v28, v23
    1064:      	dup.4s	v29, w2
    1068:      	fmul.4s	v30, v28, v29
    106c:      	fmul.4s	v29, v27, v29
    1070:      	mov.16b	v31, v15
    1074:      	bsl.16b	v31, v14, v29
    1078:      	mov.16b	v9, v15
    107c:      	bsl.16b	v9, v14, v30
    1080:      	fadd.4s	v30, v30, v9
    1084:      	fadd.4s	v29, v29, v31
    1088:      	fsub.4s	v29, v29, v31
    108c:      	fsub.4s	v30, v30, v9
    1090:      	fcvtzs.4s	v30, v30
    1094:      	fcvtzs.4s	v29, v29
    1098:      	scvtf.4s	v31, v29
    109c:      	scvtf.4s	v9, v30
    10a0:      	dup.4s	v10, w3
    10a4:      	fmul.4s	v11, v9, v10
    10a8:      	fmul.4s	v10, v31, v10
    10ac:      	fadd.4s	v27, v27, v10
    10b0:      	fadd.4s	v28, v28, v11
    10b4:      	dup.4s	v10, w4
    10b8:      	fmul.4s	v31, v31, v10
    10bc:      	fmul.4s	v9, v9, v10
    10c0:      	fadd.4s	v28, v28, v9
    10c4:      	fadd.4s	v27, v27, v31
    10c8:      	dup.4s	v31, w5
    10cc:      	fmul.4s	v9, v27, v31
    10d0:      	fmul.4s	v31, v28, v31
    10d4:      	dup.4s	v10, w6
    10d8:      	fadd.4s	v31, v31, v10
    10dc:      	fadd.4s	v9, v9, v10
    10e0:      	fmul.4s	v9, v27, v9
    10e4:      	fmul.4s	v31, v28, v31
    10e8:      	dup.4s	v10, w21
    10ec:      	fadd.4s	v31, v31, v10
    10f0:      	fadd.4s	v9, v9, v10
    10f4:      	fmul.4s	v9, v27, v9
    10f8:      	fmul.4s	v31, v28, v31
    10fc:      	dup.4s	v10, w24
    1100:      	fadd.4s	v31, v31, v10
    1104:      	fadd.4s	v9, v9, v10
    1108:      	fmul.4s	v9, v27, v9
    110c:      	fmul.4s	v31, v28, v31
    1110:      	dup.4s	v10, w19
    1114:      	fadd.4s	v31, v31, v10
    1118:      	fadd.4s	v9, v9, v10
    111c:      	fmul.4s	v9, v27, v9
    1120:      	fmul.4s	v31, v28, v31
    1124:      	movi.4s	v10, #0x3f, lsl #24
    1128:      	fadd.4s	v31, v31, v10
    112c:      	fadd.4s	v9, v9, v10
    1130:      	fmul.4s	v10, v28, v28
    1134:      	fmul.4s	v11, v27, v27
    1138:      	fmul.4s	v9, v11, v9
    113c:      	fmul.4s	v31, v10, v31
    1140:      	fadd.4s	v28, v28, v31
    1144:      	fadd.4s	v27, v27, v9
    1148:      	fmov.4s	v31, #1.00000000
    114c:      	fadd.4s	v27, v27, v31
    1150:      	fadd.4s	v28, v28, v31
    1154:      	sshr.4s	v9, v29, #0x1
    1158:      	sshr.4s	v10, v30, #0x1
    115c:      	shl.4s	v11, v10, #0x17
    1160:      	shl.4s	v12, v9, #0x17
    1164:      	add.4s	v12, v12, v31
    1168:      	add.4s	v11, v11, v31
    116c:      	fmul.4s	v28, v28, v11
    1170:      	fmul.4s	v27, v27, v12
    1174:      	sub.4s	v30, v30, v10
    1178:      	sub.4s	v29, v29, v9
    117c:      	shl.4s	v29, v29, #0x17
    1180:      	shl.4s	v30, v30, #0x17
    1184:      	add.4s	v30, v30, v31
    1188:      	add.4s	v29, v29, v31
    118c:      	fmul.4s	v27, v27, v29
    1190:      	fmul.4s	v28, v28, v30
    1194:      	fcmgt.4s	v29, v25, v23
    1198:      	bic.16b	v28, v28, v29
    119c:      	fcmgt.4s	v25, v25, v24
    11a0:      	bic.16b	v25, v27, v25
    11a4:      	fcmgt.4s	v27, v23, v26
    11a8:      	fcmgt.4s	v26, v24, v26
    11ac:      	fneg.4s	v29, v13
    11b0:      	bit.16b	v25, v29, v26
    11b4:      	mov.16b	v26, v27
    11b8:      	bsl.16b	v26, v29, v28
    11bc:      	fcmeq.4s	v24, v24, v24
    11c0:      	fcmeq.4s	v23, v23, v23
    11c4:      	ldr	q27, [sp, #0x70]
    11c8:      	bsl.16b	v23, v26, v27
    11cc:      	bsl.16b	v24, v25, v27
    11d0:      	bic.16b	v22, v24, v22
    11d4:      	bic.16b	v21, v23, v21
    11d8:      	ldr	q23, [x12, #0xc040]
    11dc:      	ldr	q24, [x12, #0xc050]
    11e0:      	bif.16b	v21, v24, v0
    11e4:      	bif.16b	v22, v23, v1
    11e8:      	str	q22, [x12, #0xc040]
    11ec:      	str	q21, [x12, #0xc050]
    11f0:      	add	x12, x12, #0x20
    11f4:      	adds	x13, x13, #0x1
    11f8:      	b.hs	0x12b0 <_llm_rows.packet_batch.blocks+0xb58>
    11fc:      	fmov	w14, s6
    1200:      	add	x15, x13, #0x602
    1204:      	dup.2d	v22, x15
    1208:      	add.2d	v23, v7, v22
    120c:      	tbz	w14, #0x0, 0x1224 <_llm_rows.packet_batch.blocks+0xacc>
    1210:      	fmov	x15, d23
    1214:      	ldr	b21, [x15]
    1218:      	and	w14, w14, #0xff
    121c:      	tbnz	w14, #0x1, 0x1230 <_llm_rows.packet_batch.blocks+0xad8>
    1220:      	b	0x1238 <_llm_rows.packet_batch.blocks+0xae0>
    1224:      	movi.2d	v21, #0000000000000000
    1228:      	and	w14, w14, #0xff
    122c:      	tbz	w14, #0x1, 0x1238 <_llm_rows.packet_batch.blocks+0xae0>
    1230:      	mov.d	x15, v23[1]
    1234:      	ld1.b	{ v21 }[1], [x15]
    1238:      	add.2d	v23, v16, v22
    123c:      	tbnz	w14, #0x2, 0x1260 <_llm_rows.packet_batch.blocks+0xb08>
    1240:      	tbnz	w14, #0x3, 0x126c <_llm_rows.packet_batch.blocks+0xb14>
    1244:      	add.2d	v23, v17, v22
    1248:      	tbnz	w14, #0x4, 0x127c <_llm_rows.packet_batch.blocks+0xb24>
    124c:      	tbnz	w14, #0x5, 0x1288 <_llm_rows.packet_batch.blocks+0xb30>
    1250:      	add.2d	v22, v18, v22
    1254:      	tbnz	w14, #0x6, 0x1298 <_llm_rows.packet_batch.blocks+0xb40>
    1258:      	tbz	w14, #0x7, 0x1018 <_llm_rows.packet_batch.blocks+0x8c0>
    125c:      	b	0x12a4 <_llm_rows.packet_batch.blocks+0xb4c>
    1260:      	fmov	x15, d23
    1264:      	ld1.b	{ v21 }[2], [x15]
    1268:      	tbz	w14, #0x3, 0x1244 <_llm_rows.packet_batch.blocks+0xaec>
    126c:      	mov.d	x15, v23[1]
    1270:      	ld1.b	{ v21 }[3], [x15]
    1274:      	add.2d	v23, v17, v22
    1278:      	tbz	w14, #0x4, 0x124c <_llm_rows.packet_batch.blocks+0xaf4>
    127c:      	fmov	x15, d23
    1280:      	ld1.b	{ v21 }[4], [x15]
    1284:      	tbz	w14, #0x5, 0x1250 <_llm_rows.packet_batch.blocks+0xaf8>
    1288:      	mov.d	x15, v23[1]
    128c:      	ld1.b	{ v21 }[5], [x15]
    1290:      	add.2d	v22, v18, v22
    1294:      	tbz	w14, #0x6, 0x1258 <_llm_rows.packet_batch.blocks+0xb00>
    1298:      	fmov	x15, d22
    129c:      	ld1.b	{ v21 }[6], [x15]
    12a0:      	tbz	w14, #0x7, 0x1018 <_llm_rows.packet_batch.blocks+0x8c0>
    12a4:      	mov.d	x14, v22[1]
    12a8:      	ld1.b	{ v21 }[7], [x14]
    12ac:      	b	0x1018 <_llm_rows.packet_batch.blocks+0x8c0>
    12b0:      	mov	x12, #0x0               ; =0
    12b4:      	ldp	q7, q16, [x8]
    12b8:      	ldp	q17, q18, [x8, #0x20]
    12bc:      	ldp	q21, q22, [x8, #0x40]
    12c0:      	and.16b	v19, v0, v16
    12c4:      	and.16b	v20, v1, v7
    12c8:      	ldp	q23, q24, [x8, #0x60]
    12cc:      	and.16b	v18, v0, v18
    12d0:      	and.16b	v17, v1, v17
    12d4:      	and.16b	v16, v0, v22
    12d8:      	and.16b	v7, v1, v21
    12dc:      	and.16b	v21, v0, v24
    12e0:      	and.16b	v22, v1, v23
    12e4:      	mov	w13, #0x31d0            ; =12752
    12e8:      	movk	w13, #0x3, lsl #16
    12ec:      	add	x11, x11, x13
    12f0:      	add	x13, x11, x12, lsl #5
    12f4:      	ldp	q24, q23, [x13, #-0x40]
    12f8:      	fadd.4s	v25, v20, v24
    12fc:      	fadd.4s	v26, v19, v23
    1300:      	ldp	q24, q23, [x13, #-0x20]
    1304:      	fadd.4s	v27, v17, v24
    1308:      	fadd.4s	v28, v18, v23
    130c:      	ldp	q24, q23, [x13]
    1310:      	fadd.4s	v29, v7, v24
    1314:      	fadd.4s	v30, v16, v23
    1318:      	ldp	q23, q24, [x13, #0x20]
    131c:      	fadd.4s	v23, v22, v23
    1320:      	fadd.4s	v24, v21, v24
    1324:      	bit.16b	v19, v26, v0
    1328:      	bit.16b	v20, v25, v1
    132c:      	bit.16b	v18, v28, v0
    1330:      	bit.16b	v17, v27, v1
    1334:      	bit.16b	v16, v30, v0
    1338:      	bit.16b	v7, v29, v1
    133c:      	bit.16b	v21, v24, v0
    1340:      	bit.16b	v22, v23, v1
    1344:      	add	x12, x12, #0x4
    1348:      	cmp	x12, #0x5fc
    134c:      	b.lo	0x12f0 <_llm_rows.packet_batch.blocks+0xb98>
    1350:      	mov	x11, #0x0               ; =0
    1354:      	ldp	q21, q22, [x10]
    1358:      	and.16b	v22, v0, v22
    135c:      	and.16b	v21, v1, v21
    1360:      	fadd.4s	v20, v20, v21
    1364:      	fadd.4s	v19, v19, v22
    1368:      	ldp	q22, q21, [x10, #0x20]
    136c:      	and.16b	v22, v1, v22
    1370:      	and.16b	v21, v0, v21
    1374:      	fadd.4s	v18, v18, v21
    1378:      	fadd.4s	v17, v17, v22
    137c:      	movi.2d	v21, #0000000000000000
    1380:      	fadd.4s	v19, v19, v21
    1384:      	fadd.4s	v20, v20, v21
    1388:      	fadd.4s	v17, v20, v17
    138c:      	fadd.4s	v18, v19, v18
    1390:      	fadd.4s	v16, v16, v18
    1394:      	fadd.4s	v7, v7, v17
    1398:      	fadd.4s	v17, v23, v7
    139c:      	fadd.4s	v7, v24, v16
    13a0:      	and.16b	v7, v0, v7
    13a4:      	and.16b	v16, v1, v17
    13a8:      	b	0x13b8 <_llm_rows.packet_batch.blocks+0xc60>
    13ac:      	add	x11, x11, #0x1
    13b0:      	cmp	x11, #0x602
    13b4:      	b.eq	0x80c <_llm_rows.packet_batch.blocks+0xb4>
    13b8:      	fmov	w10, s6
    13bc:      	dup.2d	v17, x11
    13c0:      	add.2d	v18, v17, v5
    13c4:      	add	x12, x8, x11, lsl #5
    13c8:      	ldp	q20, q19, [x12]
    13cc:      	and.16b	v20, v1, v20
    13d0:      	fdiv.4s	v20, v20, v16
    13d4:      	shl.2d	v21, v18, #0x2
    13d8:      	dup.2d	v18, x9
    13dc:      	add.2d	v21, v18, v21
    13e0:      	tbnz	w10, #0x0, 0x1434 <_llm_rows.packet_batch.blocks+0xcdc>
    13e4:      	and	w10, w10, #0xff
    13e8:      	tbnz	w10, #0x1, 0x1444 <_llm_rows.packet_batch.blocks+0xcec>
    13ec:      	add.2d	v21, v17, v3
    13f0:      	shl.2d	v21, v21, #0x2
    13f4:      	add.2d	v21, v18, v21
    13f8:      	tbnz	w10, #0x2, 0x145c <_llm_rows.packet_batch.blocks+0xd04>
    13fc:      	tbnz	w10, #0x3, 0x1468 <_llm_rows.packet_batch.blocks+0xd10>
    1400:      	add.2d	v20, v17, v4
    1404:      	and.16b	v19, v0, v19
    1408:      	fdiv.4s	v19, v19, v7
    140c:      	shl.2d	v20, v20, #0x2
    1410:      	add.2d	v20, v18, v20
    1414:      	tbnz	w10, #0x4, 0x1488 <_llm_rows.packet_batch.blocks+0xd30>
    1418:      	tbnz	w10, #0x5, 0x1494 <_llm_rows.packet_batch.blocks+0xd3c>
    141c:      	add.2d	v17, v17, v2
    1420:      	shl.2d	v17, v17, #0x2
    1424:      	add.2d	v17, v18, v17
    1428:      	tbnz	w10, #0x6, 0x14ac <_llm_rows.packet_batch.blocks+0xd54>
    142c:      	tbz	w10, #0x7, 0x13ac <_llm_rows.packet_batch.blocks+0xc54>
    1430:      	b	0x14b8 <_llm_rows.packet_batch.blocks+0xd60>
    1434:      	fmov	x12, d21
    1438:      	str	s20, [x12]
    143c:      	and	w10, w10, #0xff
    1440:      	tbz	w10, #0x1, 0x13ec <_llm_rows.packet_batch.blocks+0xc94>
    1444:      	mov.d	x12, v21[1]
    1448:      	st1.s	{ v20 }[1], [x12]
    144c:      	add.2d	v21, v17, v3
    1450:      	shl.2d	v21, v21, #0x2
    1454:      	add.2d	v21, v18, v21
    1458:      	tbz	w10, #0x2, 0x13fc <_llm_rows.packet_batch.blocks+0xca4>
    145c:      	fmov	x12, d21
    1460:      	st1.s	{ v20 }[2], [x12]
    1464:      	tbz	w10, #0x3, 0x1400 <_llm_rows.packet_batch.blocks+0xca8>
    1468:      	mov.d	x12, v21[1]
    146c:      	st1.s	{ v20 }[3], [x12]
    1470:      	add.2d	v20, v17, v4
    1474:      	and.16b	v19, v0, v19
    1478:      	fdiv.4s	v19, v19, v7
    147c:      	shl.2d	v20, v20, #0x2
    1480:      	add.2d	v20, v18, v20
    1484:      	tbz	w10, #0x4, 0x1418 <_llm_rows.packet_batch.blocks+0xcc0>
    1488:      	fmov	x12, d20
    148c:      	str	s19, [x12]
    1490:      	tbz	w10, #0x5, 0x141c <_llm_rows.packet_batch.blocks+0xcc4>
    1494:      	mov.d	x12, v20[1]
    1498:      	st1.s	{ v19 }[1], [x12]
    149c:      	add.2d	v17, v17, v2
    14a0:      	shl.2d	v17, v17, #0x2
    14a4:      	add.2d	v17, v18, v17
    14a8:      	tbz	w10, #0x6, 0x142c <_llm_rows.packet_batch.blocks+0xcd4>
    14ac:      	fmov	x12, d17
    14b0:      	st1.s	{ v19 }[2], [x12]
    14b4:      	tbz	w10, #0x7, 0x13ac <_llm_rows.packet_batch.blocks+0xc54>
    14b8:      	mov.d	x10, v17[1]
    14bc:      	st1.s	{ v19 }[3], [x10]
    14c0:      	b	0x13ac <_llm_rows.packet_batch.blocks+0xc54>
    14c4:      	ldp	x29, x30, [sp, #0x120]
    14c8:      	ldp	x20, x19, [sp, #0x110]
    14cc:      	ldp	x22, x21, [sp, #0x100]
    14d0:      	ldp	x24, x23, [sp, #0xf0]
    14d4:      	ldp	x26, x25, [sp, #0xe0]
    14d8:      	ldp	x28, x27, [sp, #0xd0]
    14dc:      	ldp	d9, d8, [sp, #0xc0]
    14e0:      	ldp	d11, d10, [sp, #0xb0]
    14e4:      	ldp	d13, d12, [sp, #0xa0]
    14e8:      	ldp	d15, d14, [sp, #0x90]
    14ec:      	add	sp, sp, #0x130
    14f0:      	ret

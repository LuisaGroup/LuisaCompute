
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/rope-17x66-l8/object/tile_xir_w8_80784_1788919122314305_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x27d4 <ltmp0+0x27d4>
       4:      	stp	d15, d14, [sp, #-0xa0]!
       8:      	stp	d13, d12, [sp, #0x10]
       c:      	stp	d11, d10, [sp, #0x20]
      10:      	stp	d9, d8, [sp, #0x30]
      14:      	stp	x28, x27, [sp, #0x40]
      18:      	stp	x26, x25, [sp, #0x50]
      1c:      	stp	x24, x23, [sp, #0x60]
      20:      	stp	x22, x21, [sp, #0x70]
      24:      	stp	x20, x19, [sp, #0x80]
      28:      	stp	x29, x30, [sp, #0x90]
      2c:      	sub	sp, sp, #0x700
      30:      	mov	w8, #0x0                ; =0
      34:      	mov	w9, #0x20               ; =32
      38:      	mov	w22, #0x18              ; =24
      3c:      	ldp	w12, w13, [x2, #0x2c]
      40:      	ldp	w21, w16, [x2, #0x4]
      44:      	ldr	w6, [x2]
      48:      	mov	w11, #0x40              ; =64
      4c:      	fmov	d0, x11
      50:      	str	q0, [sp, #0x20]
      54:      	mov	w11, #0x60              ; =96
      58:      	fmov	d0, x11
      5c:      	str	q0, [sp, #0x10]
      60:      	add	x24, sp, #0x660
      64:      	add	x25, sp, #0x5c0
      68:      	add	x26, sp, #0x520
      6c:      	add	x27, sp, #0x480
      70:      	b	0x9d0 <ltmp0+0x9d0>
      74:      	ldr	x15, [x0, #0x30]
      78:      	ldr	x17, [x0, #0x20]
      7c:      	ldr	x1, [x0, #0x10]
      80:      	ldr	x4, [x0]
      84:      	ubfiz	w11, w6, #2, #27
      88:      	add	x10, x11, x11, lsl #5
      8c:      	lsl	x14, x10, #3
      90:      	add	x11, x4, x14
      94:      	ldp	q0, q1, [x11]
      98:      	stp	q1, q0, [sp, #0x1c0]
      9c:      	add	x30, x14, #0x20
      a0:      	add	x11, x4, x30
      a4:      	ldp	q9, q23, [x11]
      a8:      	add	x11, x14, #0x40
      ac:      	add	x7, x4, x11
      b0:      	ldp	q30, q7, [x7]
      b4:      	add	x28, x14, #0x60
      b8:      	add	x7, x4, x28
      bc:      	ldp	q28, q3, [x7]
      c0:      	add	x27, x14, #0x80
      c4:      	ldr	s2, [x4, x27]
      c8:      	stp	q3, q2, [sp, #0x240]
      cc:      	add	x26, x14, #0x84
      d0:      	add	x7, x4, x26
      d4:      	ldp	q2, q3, [x7]
      d8:      	stp	q3, q2, [sp, #0x1a0]
      dc:      	add	x23, x14, #0xa4
      e0:      	add	x7, x4, x23
      e4:      	ldp	q10, q26, [x7]
      e8:      	add	x20, x14, #0xc4
      ec:      	add	x7, x4, x20
      f0:      	ldp	q31, q24, [x7]
      f4:      	add	x19, x14, #0xe4
      f8:      	add	x7, x4, x19
      fc:      	ldp	q4, q16, [x7]
     100:      	stp	q4, q16, [sp, #0x210]
     104:      	add	x7, x14, #0x104
     108:      	ldr	s16, [x4, x7]
     10c:      	str	q16, [sp, #0x230]
     110:      	lsl	x10, x10, #2
     114:      	add	x5, x1, x10
     118:      	ldp	q21, q16, [x5]
     11c:      	add	x5, x10, #0x20
     120:      	add	x22, x1, x5
     124:      	ldp	q25, q29, [x22]
     128:      	add	x22, x10, #0x40
     12c:      	add	x24, x1, x22
     130:      	ldp	q20, q27, [x24]
     134:      	stp	q20, q25, [sp, #0x180]
     138:      	add	x24, x10, #0x60
     13c:      	add	x25, x1, x24
     140:      	ldp	q8, q22, [x25]
     144:      	stp	q21, q22, [sp, #0x1e0]
     148:      	add	x25, x10, #0x80
     14c:      	ldr	s22, [x1, x25]
     150:      	str	q22, [sp, #0x200]
     154:      	add	x10, x17, x10
     158:      	ldp	q13, q15, [x10]
     15c:      	add	x10, x17, x5
     160:      	add	x5, x17, x22
     164:      	add	x22, x17, x24
     168:      	fmul.4s	v11, v1, v16
     16c:      	fmul.4s	v12, v0, v21
     170:      	fmul.4s	v14, v2, v13
     174:      	fsub.4s	v1, v12, v14
     178:      	fmul.4s	v12, v3, v15
     17c:      	fsub.4s	v0, v11, v12
     180:      	add	x14, x15, x14
     184:      	ldp	q3, q2, [x10]
     188:      	ldp	q22, q21, [x5]
     18c:      	ldp	q12, q14, [x22]
     190:      	ldr	s11, [x17, x25]
     194:      	stp	q1, q0, [x14]
     198:      	fmul.4s	v0, v9, v25
     19c:      	fmul.4s	v1, v10, v3
     1a0:      	fsub.4s	v0, v0, v1
     1a4:      	fmul.4s	v1, v23, v29
     1a8:      	mov.16b	v25, v23
     1ac:      	fmul.4s	v6, v26, v2
     1b0:      	fsub.4s	v1, v1, v6
     1b4:      	add	x10, x15, x30
     1b8:      	stp	q0, q1, [x10]
     1bc:      	fmul.4s	v0, v30, v20
     1c0:      	fmul.4s	v1, v31, v22
     1c4:      	fsub.4s	v0, v0, v1
     1c8:      	fmul.4s	v1, v7, v27
     1cc:      	mov.16b	v23, v7
     1d0:      	fmul.4s	v6, v24, v21
     1d4:      	fsub.4s	v1, v1, v6
     1d8:      	add	x10, x15, x11
     1dc:      	stp	q0, q1, [x10]
     1e0:      	fmul.4s	v0, v28, v8
     1e4:      	ldp	q20, q5, [sp, #0x210]
     1e8:      	fmul.4s	v1, v20, v12
     1ec:      	fsub.4s	v0, v0, v1
     1f0:      	ldp	q4, q17, [sp, #0x240]
     1f4:      	ldp	q7, q19, [sp, #0x1f0]
     1f8:      	fmul.4s	v1, v4, v7
     1fc:      	fmul.4s	v6, v5, v14
     200:      	fsub.4s	v1, v1, v6
     204:      	add	x10, x15, x28
     208:      	stp	q0, q1, [x10]
     20c:      	fmul.4s	v0, v17, v19
     210:      	ldr	q18, [sp, #0x230]
     214:      	fmul.4s	v1, v18, v11
     218:      	fsub.4s	v0, v0, v1
     21c:      	str	s0, [x15, x27]
     220:      	ldp	q0, q1, [sp, #0x1c0]
     224:      	fmul.4s	v0, v0, v15
     228:      	fmul.4s	v1, v1, v13
     22c:      	ldp	q6, q13, [sp, #0x1a0]
     230:      	fmul.4s	v6, v6, v16
     234:      	ldr	q16, [sp, #0x1e0]
     238:      	fmul.4s	v16, v13, v16
     23c:      	fadd.4s	v1, v16, v1
     240:      	fadd.4s	v0, v6, v0
     244:      	add	x10, x15, x26
     248:      	stp	q1, q0, [x10]
     24c:      	fmul.4s	v0, v25, v2
     250:      	fmul.4s	v1, v9, v3
     254:      	fmul.4s	v2, v26, v29
     258:      	ldr	q3, [sp, #0x190]
     25c:      	fmul.4s	v3, v10, v3
     260:      	fadd.4s	v1, v3, v1
     264:      	fadd.4s	v0, v2, v0
     268:      	add	x10, x15, x23
     26c:      	stp	q1, q0, [x10]
     270:      	fmul.4s	v0, v23, v21
     274:      	fmul.4s	v1, v30, v22
     278:      	fmul.4s	v2, v24, v27
     27c:      	ldr	q3, [sp, #0x180]
     280:      	fmul.4s	v3, v31, v3
     284:      	fadd.4s	v1, v3, v1
     288:      	fadd.4s	v0, v2, v0
     28c:      	add	x10, x15, x20
     290:      	stp	q1, q0, [x10]
     294:      	fmul.4s	v0, v4, v14
     298:      	fmul.4s	v1, v28, v12
     29c:      	fmul.4s	v2, v5, v7
     2a0:      	fmul.4s	v3, v20, v8
     2a4:      	fadd.4s	v1, v3, v1
     2a8:      	fadd.4s	v0, v2, v0
     2ac:      	add	x10, x15, x19
     2b0:      	stp	q1, q0, [x10]
     2b4:      	fmul.4s	v0, v17, v11
     2b8:      	fmul.4s	v1, v18, v19
     2bc:      	fadd.4s	v0, v1, v0
     2c0:      	str	s0, [x15, x7]
     2c4:      	mov	w10, #0x1               ; =1
     2c8:      	bfi	w10, w6, #2, #27
     2cc:      	add	x10, x10, x10, lsl #5
     2d0:      	lsl	x14, x10, #3
     2d4:      	add	x11, x4, x14
     2d8:      	ldp	q2, q1, [x11]
     2dc:      	stp	q1, q2, [sp, #0x1b0]
     2e0:      	add	x28, x14, #0x20
     2e4:      	add	x11, x4, x28
     2e8:      	ldp	q3, q24, [x11]
     2ec:      	str	q3, [sp, #0x1d0]
     2f0:      	add	x11, x14, #0x40
     2f4:      	add	x5, x4, x11
     2f8:      	ldp	q28, q22, [x5]
     2fc:      	add	x30, x14, #0x60
     300:      	add	x5, x4, x30
     304:      	ldp	q4, q0, [x5]
     308:      	stp	q4, q0, [sp, #0x230]
     30c:      	add	x27, x14, #0x80
     310:      	ldr	s0, [x4, x27]
     314:      	str	q0, [sp, #0x250]
     318:      	add	x26, x14, #0x84
     31c:      	add	x5, x4, x26
     320:      	ldp	q19, q20, [x5]
     324:      	stp	q20, q19, [sp, #0x180]
     328:      	add	x23, x14, #0xa4
     32c:      	add	x5, x4, x23
     330:      	ldp	q16, q26, [x5]
     334:      	str	q16, [sp, #0x1a0]
     338:      	add	x20, x14, #0xc4
     33c:      	add	x5, x4, x20
     340:      	ldp	q29, q17, [x5]
     344:      	add	x19, x14, #0xe4
     348:      	add	x5, x4, x19
     34c:      	ldp	q4, q0, [x5]
     350:      	stp	q4, q0, [sp, #0x200]
     354:      	add	x7, x14, #0x104
     358:      	ldr	s0, [x4, x7]
     35c:      	str	q0, [sp, #0x220]
     360:      	lsl	x10, x10, #2
     364:      	add	x5, x1, x10
     368:      	ldp	q25, q31, [x5]
     36c:      	add	x5, x10, #0x20
     370:      	add	x22, x1, x5
     374:      	ldp	q21, q27, [x22]
     378:      	stp	q25, q21, [sp, #0x1e0]
     37c:      	add	x22, x10, #0x40
     380:      	add	x24, x1, x22
     384:      	ldp	q30, q23, [x24]
     388:      	add	x24, x10, #0x60
     38c:      	add	x25, x17, x10
     390:      	ldp	q12, q15, [x25]
     394:      	add	x25, x1, x24
     398:      	add	x10, x10, #0x80
     39c:      	add	x5, x17, x5
     3a0:      	ldp	q9, q10, [x5]
     3a4:      	add	x5, x17, x22
     3a8:      	add	x22, x17, x24
     3ac:      	fmul.4s	v0, v1, v31
     3b0:      	fmul.4s	v1, v2, v25
     3b4:      	fmul.4s	v8, v20, v15
     3b8:      	fmul.4s	v11, v19, v12
     3bc:      	fsub.4s	v1, v1, v11
     3c0:      	fsub.4s	v0, v0, v8
     3c4:      	add	x14, x15, x14
     3c8:      	fmul.4s	v2, v3, v21
     3cc:      	fmul.4s	v3, v16, v9
     3d0:      	fsub.4s	v2, v2, v3
     3d4:      	ldp	q11, q14, [x25]
     3d8:      	ldr	s8, [x1, x10]
     3dc:      	ldp	q19, q3, [x5]
     3e0:      	ldp	q21, q20, [x22]
     3e4:      	ldr	s13, [x17, x10]
     3e8:      	stp	q1, q0, [x14]
     3ec:      	fmul.4s	v0, v24, v27
     3f0:      	fmul.4s	v1, v26, v10
     3f4:      	fsub.4s	v0, v0, v1
     3f8:      	fmul.4s	v1, v28, v30
     3fc:      	fmul.4s	v7, v29, v19
     400:      	fsub.4s	v1, v1, v7
     404:      	fmul.4s	v7, v22, v23
     408:      	mov.16b	v25, v23
     40c:      	fmul.4s	v16, v17, v3
     410:      	mov.16b	v23, v17
     414:      	fsub.4s	v7, v7, v16
     418:      	add	x10, x15, x28
     41c:      	stp	q2, q0, [x10]
     420:      	add	x10, x15, x11
     424:      	stp	q1, q7, [x10]
     428:      	ldp	q18, q4, [sp, #0x230]
     42c:      	fmul.4s	v0, v18, v11
     430:      	ldp	q17, q5, [sp, #0x200]
     434:      	fmul.4s	v1, v17, v21
     438:      	fsub.4s	v0, v0, v1
     43c:      	fmul.4s	v1, v4, v14
     440:      	fmul.4s	v2, v5, v20
     444:      	fsub.4s	v1, v1, v2
     448:      	add	x10, x15, x30
     44c:      	stp	q0, q1, [x10]
     450:      	ldr	q16, [sp, #0x250]
     454:      	fmul.4s	v0, v16, v8
     458:      	ldr	q6, [sp, #0x220]
     45c:      	fmul.4s	v1, v6, v13
     460:      	fsub.4s	v0, v0, v1
     464:      	str	s0, [x15, x27]
     468:      	ldp	q0, q1, [sp, #0x1b0]
     46c:      	fmul.4s	v0, v0, v15
     470:      	fmul.4s	v1, v1, v12
     474:      	ldr	q2, [sp, #0x180]
     478:      	fmul.4s	v2, v2, v31
     47c:      	ldr	q7, [sp, #0x1e0]
     480:      	ldr	q31, [sp, #0x190]
     484:      	fmul.4s	v7, v31, v7
     488:      	fadd.4s	v1, v7, v1
     48c:      	fadd.4s	v0, v2, v0
     490:      	add	x10, x15, x26
     494:      	stp	q1, q0, [x10]
     498:      	fmul.4s	v0, v24, v10
     49c:      	ldr	q1, [sp, #0x1d0]
     4a0:      	fmul.4s	v1, v1, v9
     4a4:      	fmul.4s	v2, v26, v27
     4a8:      	ldr	q7, [sp, #0x1f0]
     4ac:      	ldr	q24, [sp, #0x1a0]
     4b0:      	fmul.4s	v7, v24, v7
     4b4:      	fadd.4s	v1, v7, v1
     4b8:      	fadd.4s	v0, v2, v0
     4bc:      	add	x10, x15, x23
     4c0:      	stp	q1, q0, [x10]
     4c4:      	fmul.4s	v0, v22, v3
     4c8:      	fmul.4s	v1, v28, v19
     4cc:      	fmul.4s	v2, v23, v25
     4d0:      	fmul.4s	v3, v29, v30
     4d4:      	fadd.4s	v1, v3, v1
     4d8:      	fadd.4s	v0, v2, v0
     4dc:      	add	x10, x15, x20
     4e0:      	stp	q1, q0, [x10]
     4e4:      	fmul.4s	v0, v4, v20
     4e8:      	fmul.4s	v1, v18, v21
     4ec:      	fmul.4s	v2, v5, v14
     4f0:      	fmul.4s	v3, v17, v11
     4f4:      	fadd.4s	v1, v3, v1
     4f8:      	fadd.4s	v0, v2, v0
     4fc:      	add	x10, x15, x19
     500:      	stp	q1, q0, [x10]
     504:      	fmul.4s	v0, v16, v13
     508:      	fmul.4s	v1, v6, v8
     50c:      	fadd.4s	v0, v1, v0
     510:      	str	s0, [x15, x7]
     514:      	mov	w10, #0x2               ; =2
     518:      	bfi	w10, w6, #2, #27
     51c:      	add	x10, x10, x10, lsl #5
     520:      	lsl	x30, x10, #3
     524:      	add	x11, x4, x30
     528:      	ldp	q5, q0, [x11]
     52c:      	stp	q0, q5, [sp, #0x240]
     530:      	add	x27, x30, #0x20
     534:      	add	x11, x4, x27
     538:      	ldp	q20, q2, [x11]
     53c:      	str	q2, [sp, #0x220]
     540:      	add	x23, x30, #0x40
     544:      	add	x11, x4, x23
     548:      	ldp	q3, q4, [x11]
     54c:      	add	x26, x30, #0x60
     550:      	add	x11, x4, x26
     554:      	add	x20, x30, #0x84
     558:      	add	x14, x4, x20
     55c:      	ldp	q6, q7, [x14]
     560:      	stp	q7, q6, [sp, #0x1c0]
     564:      	add	x19, x30, #0xa4
     568:      	add	x14, x4, x19
     56c:      	ldp	q18, q19, [x14]
     570:      	stp	q19, q18, [sp, #0x1e0]
     574:      	add	x7, x30, #0xc4
     578:      	add	x14, x4, x7
     57c:      	ldp	q16, q17, [x14]
     580:      	stp	q17, q16, [sp, #0x200]
     584:      	lsl	x14, x10, #2
     588:      	add	x10, x1, x14
     58c:      	ldp	q24, q25, [x10]
     590:      	add	x10, x14, #0x20
     594:      	add	x5, x1, x10
     598:      	ldp	q22, q23, [x5]
     59c:      	add	x5, x14, #0x40
     5a0:      	add	x22, x1, x5
     5a4:      	ldp	q11, q21, [x22]
     5a8:      	str	q11, [sp, #0x230]
     5ac:      	add	x22, x17, x14
     5b0:      	ldp	q27, q29, [x22]
     5b4:      	add	x10, x17, x10
     5b8:      	add	x5, x17, x5
     5bc:      	fmul.4s	v0, v0, v25
     5c0:      	fmul.4s	v8, v5, v24
     5c4:      	ldp	q30, q31, [x10]
     5c8:      	ldp	q26, q28, [x5]
     5cc:      	fmul.4s	v9, v7, v29
     5d0:      	fmul.4s	v10, v6, v27
     5d4:      	fsub.4s	v7, v8, v10
     5d8:      	fsub.4s	v6, v0, v9
     5dc:      	fmul.4s	v0, v2, v23
     5e0:      	fmul.4s	v8, v20, v22
     5e4:      	fmul.4s	v9, v19, v31
     5e8:      	fmul.4s	v10, v18, v30
     5ec:      	fsub.4s	v5, v8, v10
     5f0:      	fsub.4s	v2, v0, v9
     5f4:      	fmul.4s	v1, v4, v21
     5f8:      	mov.16b	v19, v4
     5fc:      	fmul.4s	v8, v3, v11
     600:      	mov.16b	v18, v3
     604:      	fmul.4s	v9, v17, v28
     608:      	fmul.4s	v10, v16, v26
     60c:      	fsub.4s	v17, v8, v10
     610:      	fsub.4s	v16, v1, v9
     614:      	ldp	q8, q9, [x11]
     618:      	add	x10, x30, #0x80
     61c:      	add	x28, x30, #0xe4
     620:      	add	x5, x4, x28
     624:      	add	x11, x30, #0x104
     628:      	add	x22, x14, #0x60
     62c:      	add	x24, x1, x22
     630:      	add	x14, x14, #0x80
     634:      	add	x22, x17, x22
     638:      	add	x25, x15, x30
     63c:      	ldr	s10, [x4, x10]
     640:      	ldp	q13, q14, [x5]
     644:      	ldr	s11, [x4, x11]
     648:      	ldp	q4, q3, [x24]
     64c:      	add	x24, sp, #0x660
     650:      	ldr	s12, [x1, x14]
     654:      	ldp	q1, q0, [x22]
     658:      	ldr	s15, [x17, x14]
     65c:      	stp	q7, q6, [x25]
     660:      	add	x25, sp, #0x5c0
     664:      	add	x14, x15, x27
     668:      	stp	q5, q2, [x14]
     66c:      	fmul.4s	v2, v8, v4
     670:      	fmul.4s	v5, v13, v1
     674:      	fsub.4s	v2, v2, v5
     678:      	fmul.4s	v5, v9, v3
     67c:      	fmul.4s	v6, v14, v0
     680:      	fsub.4s	v5, v5, v6
     684:      	fmul.4s	v6, v10, v12
     688:      	fmul.4s	v7, v11, v15
     68c:      	fsub.4s	v6, v6, v7
     690:      	add	x14, x15, x23
     694:      	stp	q17, q16, [x14]
     698:      	add	x14, x15, x26
     69c:      	stp	q2, q5, [x14]
     6a0:      	str	s6, [x15, x10]
     6a4:      	ldp	q2, q5, [sp, #0x240]
     6a8:      	fmul.4s	v2, v2, v29
     6ac:      	fmul.4s	v5, v5, v27
     6b0:      	ldp	q6, q7, [sp, #0x1c0]
     6b4:      	fmul.4s	v6, v6, v25
     6b8:      	fmul.4s	v7, v7, v24
     6bc:      	fadd.4s	v5, v7, v5
     6c0:      	fadd.4s	v2, v6, v2
     6c4:      	add	x10, x15, x20
     6c8:      	stp	q5, q2, [x10]
     6cc:      	ldp	q16, q2, [sp, #0x210]
     6d0:      	fmul.4s	v2, v2, v31
     6d4:      	fmul.4s	v5, v20, v30
     6d8:      	ldp	q6, q7, [sp, #0x1e0]
     6dc:      	fmul.4s	v6, v6, v23
     6e0:      	fmul.4s	v7, v7, v22
     6e4:      	fadd.4s	v5, v7, v5
     6e8:      	fadd.4s	v2, v6, v2
     6ec:      	add	x10, x15, x19
     6f0:      	stp	q5, q2, [x10]
     6f4:      	fmul.4s	v2, v19, v28
     6f8:      	fmul.4s	v5, v18, v26
     6fc:      	ldr	q6, [sp, #0x200]
     700:      	fmul.4s	v6, v6, v21
     704:      	ldr	q7, [sp, #0x230]
     708:      	fmul.4s	v7, v16, v7
     70c:      	fadd.4s	v5, v7, v5
     710:      	fadd.4s	v2, v6, v2
     714:      	add	x10, x15, x7
     718:      	stp	q5, q2, [x10]
     71c:      	fmul.4s	v0, v9, v0
     720:      	fmul.4s	v1, v8, v1
     724:      	fmul.4s	v2, v14, v3
     728:      	fmul.4s	v3, v13, v4
     72c:      	fadd.4s	v1, v3, v1
     730:      	fadd.4s	v0, v2, v0
     734:      	add	x10, x15, x28
     738:      	stp	q1, q0, [x10]
     73c:      	fmul.4s	v0, v10, v15
     740:      	fmul.4s	v1, v11, v12
     744:      	fadd.4s	v0, v1, v0
     748:      	str	s0, [x15, x11]
     74c:      	mov	w10, #0x3               ; =3
     750:      	bfi	w10, w6, #2, #27
     754:      	add	x10, x10, x10, lsl #5
     758:      	lsl	x27, x10, #3
     75c:      	add	x11, x4, x27
     760:      	ldp	q3, q22, [x11]
     764:      	add	x26, x27, #0x20
     768:      	add	x11, x4, x26
     76c:      	ldp	q6, q7, [x11]
     770:      	stp	q7, q6, [sp, #0x1d0]
     774:      	add	x23, x27, #0x40
     778:      	add	x11, x4, x23
     77c:      	ldp	q0, q5, [x11]
     780:      	stp	q5, q0, [sp, #0x1f0]
     784:      	add	x30, x27, #0x60
     788:      	add	x11, x4, x30
     78c:      	add	x20, x27, #0x84
     790:      	add	x14, x4, x20
     794:      	ldp	q19, q20, [x14]
     798:      	stp	q19, q3, [sp, #0x190]
     79c:      	str	q20, [sp, #0x180]
     7a0:      	add	x19, x27, #0xa4
     7a4:      	add	x14, x4, x19
     7a8:      	ldp	q18, q21, [x14]
     7ac:      	stp	q21, q18, [sp, #0x1b0]
     7b0:      	add	x7, x27, #0xc4
     7b4:      	add	x14, x4, x7
     7b8:      	ldp	q16, q17, [x14]
     7bc:      	stp	q17, q16, [sp, #0x220]
     7c0:      	lsl	x28, x10, #2
     7c4:      	add	x10, x1, x28
     7c8:      	ldp	q24, q25, [x10]
     7cc:      	add	x10, x28, #0x20
     7d0:      	add	x14, x1, x10
     7d4:      	add	x5, x28, #0x40
     7d8:      	add	x22, x1, x5
     7dc:      	ldp	q27, q23, [x14]
     7e0:      	str	q27, [sp, #0x210]
     7e4:      	ldp	q29, q31, [x22]
     7e8:      	stp	q31, q29, [sp, #0x240]
     7ec:      	mov	w22, #0x18              ; =24
     7f0:      	add	x14, x17, x28
     7f4:      	add	x10, x17, x10
     7f8:      	add	x5, x17, x5
     7fc:      	fmul.4s	v1, v22, v25
     800:      	ldp	q11, q4, [x14]
     804:      	fmul.4s	v2, v3, v24
     808:      	fmul.4s	v26, v20, v4
     80c:      	fmul.4s	v3, v19, v11
     810:      	fsub.4s	v20, v2, v3
     814:      	fsub.4s	v19, v1, v26
     818:      	fmul.4s	v1, v7, v23
     81c:      	fmul.4s	v2, v6, v27
     820:      	ldp	q10, q14, [x10]
     824:      	ldp	q27, q30, [x5]
     828:      	fmul.4s	v26, v21, v14
     82c:      	fmul.4s	v28, v18, v10
     830:      	fsub.4s	v18, v2, v28
     834:      	fsub.4s	v7, v1, v26
     838:      	fmul.4s	v1, v5, v31
     83c:      	fmul.4s	v2, v0, v29
     840:      	fmul.4s	v26, v17, v30
     844:      	fmul.4s	v28, v16, v27
     848:      	fsub.4s	v17, v2, v28
     84c:      	fsub.4s	v16, v1, v26
     850:      	ldp	q26, q28, [x11]
     854:      	add	x11, x27, #0xe4
     858:      	add	x10, x4, x11
     85c:      	add	x14, x28, #0x60
     860:      	add	x5, x1, x14
     864:      	add	x14, x17, x14
     868:      	ldp	q29, q31, [x5]
     86c:      	fmul.4s	v2, v26, v29
     870:      	ldp	q8, q9, [x10]
     874:      	ldp	q15, q3, [x14]
     878:      	fmul.4s	v12, v8, v15
     87c:      	fsub.4s	v6, v2, v12
     880:      	fmul.4s	v2, v28, v31
     884:      	fmul.4s	v12, v9, v3
     888:      	fsub.4s	v5, v2, v12
     88c:      	add	x10, x27, #0x80
     890:      	add	x14, x27, #0x104
     894:      	ldr	s12, [x4, x10]
     898:      	add	x5, x28, #0x80
     89c:      	ldr	s13, [x4, x14]
     8a0:      	ldr	s2, [x1, x5]
     8a4:      	fmul.4s	v0, v12, v2
     8a8:      	ldr	s1, [x17, x5]
     8ac:      	fmul.4s	v21, v13, v1
     8b0:      	fsub.4s	v0, v0, v21
     8b4:      	fmul.4s	v4, v22, v4
     8b8:      	add	x17, x15, x27
     8bc:      	add	x27, sp, #0x480
     8c0:      	stp	q20, q19, [x17]
     8c4:      	ldp	q21, q19, [sp, #0x190]
     8c8:      	fmul.4s	v19, v19, v11
     8cc:      	ldr	q20, [sp, #0x180]
     8d0:      	fmul.4s	v20, v20, v25
     8d4:      	fmul.4s	v21, v21, v24
     8d8:      	add	x17, x15, x26
     8dc:      	add	x26, sp, #0x520
     8e0:      	stp	q18, q7, [x17]
     8e4:      	fadd.4s	v7, v21, v19
     8e8:      	fadd.4s	v4, v20, v4
     8ec:      	ldp	q20, q18, [sp, #0x1c0]
     8f0:      	fmul.4s	v18, v18, v14
     8f4:      	add	x17, x15, x23
     8f8:      	stp	q17, q16, [x17]
     8fc:      	ldr	q16, [sp, #0x1e0]
     900:      	fmul.4s	v16, v16, v10
     904:      	ldr	q17, [sp, #0x1b0]
     908:      	fmul.4s	v17, v17, v23
     90c:      	ldr	q19, [sp, #0x210]
     910:      	fmul.4s	v19, v20, v19
     914:      	add	x17, x15, x30
     918:      	stp	q6, q5, [x17]
     91c:      	fadd.4s	v5, v19, v16
     920:      	str	s0, [x15, x10]
     924:      	fadd.4s	v0, v17, v18
     928:      	ldp	q6, q16, [sp, #0x1f0]
     92c:      	fmul.4s	v6, v6, v30
     930:      	fmul.4s	v16, v16, v27
     934:      	add	x10, x15, x20
     938:      	stp	q7, q4, [x10]
     93c:      	ldp	q17, q4, [sp, #0x230]
     940:      	ldr	q7, [sp, #0x220]
     944:      	fmul.4s	v4, v7, v4
     948:      	ldr	q7, [sp, #0x250]
     94c:      	fmul.4s	v7, v17, v7
     950:      	fadd.4s	v7, v7, v16
     954:      	add	x10, x15, x19
     958:      	stp	q5, q0, [x10]
     95c:      	fadd.4s	v0, v4, v6
     960:      	fmul.4s	v3, v28, v3
     964:      	fmul.4s	v4, v26, v15
     968:      	add	x10, x15, x7
     96c:      	stp	q7, q0, [x10]
     970:      	fmul.4s	v0, v9, v31
     974:      	fmul.4s	v5, v8, v29
     978:      	fadd.4s	v4, v5, v4
     97c:      	fadd.4s	v0, v0, v3
     980:      	add	x10, x15, x11
     984:      	stp	q4, q0, [x10]
     988:      	fmul.4s	v0, v12, v1
     98c:      	fmul.4s	v1, v13, v2
     990:      	fadd.4s	v0, v1, v0
     994:      	str	s0, [x15, x14]
     998:      	str	w22, [x2, #0x24]
     99c:      	add	w10, w6, #0x1
     9a0:      	cmp	w10, w12
     9a4:      	cset	w10, eq
     9a8:      	csinc	w6, wzr, w6, eq
     9ac:      	cinc	w11, w21, eq
     9b0:      	cmp	w11, w13
     9b4:      	cset	w14, eq
     9b8:      	ands	w10, w10, w14
     9bc:      	csel	w21, wzr, w11, ne
     9c0:      	add	w16, w16, w10
     9c4:      	add	w8, w8, #0x1
     9c8:      	cmp	w8, w3
     9cc:      	b.eq	0x27a8 <ltmp0+0x27a8>
     9d0:      	ldr	w11, [x2, #0xc]
     9d4:      	ubfiz	x14, x6, #5, #32
     9d8:      	cmp	x14, x11
     9dc:      	csel	x15, x14, xzr, ls
     9e0:      	subs	x17, x11, x15
     9e4:      	cmp	x17, #0x20
     9e8:      	csel	x17, x17, x9, lo
     9ec:      	cmp	x11, x15
     9f0:      	stp	w6, w21, [x2]
     9f4:      	str	w16, [x2, #0x8]
     9f8:      	str	wzr, [x2, #0x24]
     9fc:      	ccmp	x14, x11, #0x2, hi
     a00:      	csel	x17, x17, xzr, ls
     a04:      	cmp	x17, #0x20
     a08:      	b.hs	0x74 <ltmp0+0x74>
     a0c:      	lsr	x15, x17, #3
     a10:      	cmp	x17, #0x8
     a14:      	b.lo	0xc38 <ltmp0+0xc38>
     a18:      	mov	x1, #0x0                ; =0
     a1c:      	ldr	x10, [x0, #0x30]
     a20:      	ldr	x11, [x0, #0x20]
     a24:      	ldr	x14, [x0, #0x10]
     a28:      	ldr	x5, [x0]
     a2c:      	and	x4, x6, #0x7ffffff
     a30:      	add	x20, x4, x4, lsl #5
     a34:      	lsl	x7, x20, #5
     a38:      	add	x4, x10, x7
     a3c:      	add	x7, x5, x7
     a40:      	add	x10, x15, x15, lsl #5
     a44:      	lsl	x19, x10, #3
     a48:      	lsl	x10, x20, #4
     a4c:      	add	x14, x14, x10
     a50:      	add	x20, x14, #0x40
     a54:      	add	x10, x11, x10
     a58:      	add	x30, x10, #0x40
     a5c:      	add	x11, x7, x1
     a60:      	ldp	q18, q19, [x11]
     a64:      	stp	q19, q18, [sp, #0x190]
     a68:      	ldp	q4, q5, [x11, #0x20]
     a6c:      	stp	q5, q4, [sp, #0x1d0]
     a70:      	ldp	q0, q1, [x11, #0x40]
     a74:      	stp	q1, q0, [sp, #0x1f0]
     a78:      	ldur	q12, [x11, #0x84]
     a7c:      	ldur	q22, [x11, #0x94]
     a80:      	ldur	q6, [x11, #0xa4]
     a84:      	ldur	q16, [x11, #0xb4]
     a88:      	stp	q16, q6, [sp, #0x1b0]
     a8c:      	ldur	q2, [x11, #0xc4]
     a90:      	ldur	q3, [x11, #0xd4]
     a94:      	stp	q3, q2, [sp, #0x210]
     a98:      	ldp	q24, q25, [x20, #-0x40]
     a9c:      	ldp	q20, q23, [x20, #-0x20]
     aa0:      	ldp	q7, q17, [x20]
     aa4:      	str	q7, [sp, #0x250]
     aa8:      	stp	q20, q17, [sp, #0x230]
     aac:      	fmul.4s	v26, v19, v25
     ab0:      	fmul.4s	v27, v18, v24
     ab4:      	ldp	q10, q11, [x30, #-0x40]
     ab8:      	fmul.4s	v28, v22, v11
     abc:      	fmul.4s	v29, v12, v10
     ac0:      	fsub.4s	v18, v27, v29
     ac4:      	str	q18, [sp, #0x180]
     ac8:      	ldp	q9, q13, [x30, #-0x20]
     acc:      	fsub.4s	v14, v26, v28
     ad0:      	fmul.4s	v27, v5, v23
     ad4:      	fmul.4s	v28, v4, v20
     ad8:      	ldp	q26, q30, [x30]
     adc:      	fmul.4s	v29, v16, v13
     ae0:      	fmul.4s	v31, v6, v9
     ae4:      	fsub.4s	v15, v28, v31
     ae8:      	fsub.4s	v19, v27, v29
     aec:      	fmul.4s	v27, v1, v17
     af0:      	fmul.4s	v28, v0, v7
     af4:      	fmul.4s	v29, v3, v30
     af8:      	fmul.4s	v31, v2, v26
     afc:      	fsub.4s	v20, v28, v31
     b00:      	fsub.4s	v18, v27, v29
     b04:      	ldp	q28, q8, [x11, #0x60]
     b08:      	ldur	q27, [x11, #0xe4]
     b0c:      	ldp	q29, q31, [x20, #0x20]
     b10:      	fmul.4s	v0, v28, v29
     b14:      	ldp	q4, q3, [x30, #0x20]
     b18:      	fmul.4s	v6, v27, v4
     b1c:      	fsub.4s	v17, v0, v6
     b20:      	ldur	q6, [x11, #0xf4]
     b24:      	fmul.4s	v0, v8, v31
     b28:      	fmul.4s	v16, v6, v3
     b2c:      	fsub.4s	v7, v0, v16
     b30:      	ldr	s16, [x11, #0x80]
     b34:      	ldr	s5, [x20, #0x40]
     b38:      	fmul.4s	v0, v16, v5
     b3c:      	ldr	s2, [x11, #0x104]
     b40:      	ldr	s1, [x30, #0x40]
     b44:      	fmul.4s	v21, v2, v1
     b48:      	fsub.4s	v0, v0, v21
     b4c:      	ldr	q21, [sp, #0x190]
     b50:      	fmul.4s	v21, v21, v11
     b54:      	ldr	q11, [sp, #0x1a0]
     b58:      	fmul.4s	v10, v11, v10
     b5c:      	add	x10, x4, x1
     b60:      	ldr	q11, [sp, #0x180]
     b64:      	stp	q11, q14, [x10]
     b68:      	fmul.4s	v22, v22, v25
     b6c:      	fmul.4s	v24, v12, v24
     b70:      	fadd.4s	v24, v24, v10
     b74:      	stp	q15, q19, [x10, #0x20]
     b78:      	fadd.4s	v19, v22, v21
     b7c:      	ldp	q21, q22, [sp, #0x1d0]
     b80:      	fmul.4s	v21, v21, v13
     b84:      	fmul.4s	v22, v22, v9
     b88:      	stp	q20, q18, [x10, #0x40]
     b8c:      	ldr	q18, [sp, #0x1b0]
     b90:      	fmul.4s	v18, v18, v23
     b94:      	ldr	q20, [sp, #0x230]
     b98:      	ldr	q23, [sp, #0x1c0]
     b9c:      	fmul.4s	v20, v23, v20
     ba0:      	fadd.4s	v20, v20, v22
     ba4:      	stp	q17, q7, [x10, #0x60]
     ba8:      	fadd.4s	v7, v18, v21
     bac:      	ldr	q17, [sp, #0x1f0]
     bb0:      	fmul.4s	v17, v17, v30
     bb4:      	str	s0, [x10, #0x80]
     bb8:      	ldr	q0, [sp, #0x200]
     bbc:      	fmul.4s	v0, v0, v26
     bc0:      	stur	q19, [x10, #0x94]
     bc4:      	ldr	q18, [sp, #0x240]
     bc8:      	ldp	q19, q21, [sp, #0x210]
     bcc:      	fmul.4s	v18, v19, v18
     bd0:      	ldr	q19, [sp, #0x250]
     bd4:      	fmul.4s	v19, v21, v19
     bd8:      	stur	q24, [x10, #0x84]
     bdc:      	fadd.4s	v0, v19, v0
     be0:      	stur	q7, [x10, #0xb4]
     be4:      	fadd.4s	v7, v18, v17
     be8:      	fmul.4s	v3, v8, v3
     bec:      	stur	q20, [x10, #0xa4]
     bf0:      	fmul.4s	v4, v28, v4
     bf4:      	stur	q7, [x10, #0xd4]
     bf8:      	fmul.4s	v6, v6, v31
     bfc:      	fmul.4s	v7, v27, v29
     c00:      	stur	q0, [x10, #0xc4]
     c04:      	fadd.4s	v0, v7, v4
     c08:      	fadd.4s	v3, v6, v3
     c0c:      	fmul.4s	v1, v16, v1
     c10:      	fmul.4s	v2, v2, v5
     c14:      	fadd.4s	v1, v2, v1
     c18:      	stur	q3, [x10, #0xf4]
     c1c:      	stur	q0, [x10, #0xe4]
     c20:      	str	s1, [x10, #0x104]
     c24:      	add	x1, x1, #0x108
     c28:      	add	x20, x20, #0x84
     c2c:      	add	x30, x30, #0x84
     c30:      	cmp	x19, x1
     c34:      	b.ne	0xa5c <ltmp0+0xa5c>
     c38:      	and	w11, w17, #0x7
     c3c:      	cbz	w11, 0x998 <ltmp0+0x998>
     c40:      	dup.4s	v0, w11
     c44:      	adrp	x10, 0x0 <ltmp0>
     c48:      	ldr	q1, [x10]
     c4c:      	adrp	x10, 0x0 <ltmp0>
     c50:      	ldr	q2, [x10]
     c54:      	cmhi.4s	v6, v0, v2
     c58:      	cmhi.4s	v7, v0, v1
     c5c:      	uzp1.8h	v0, v7, v6
     c60:      	umaxv.8h	h1, v0
     c64:      	fmov	w10, s1
     c68:      	tbz	w10, #0x0, 0x998 <ltmp0+0x998>
     c6c:      	adrp	x10, 0x0 <ltmp0>
     c70:      	ldr	q1, [x10]
     c74:      	and.16b	v0, v0, v1
     c78:      	addv.8h	h16, v0
     c7c:      	fmov	w11, s16
     c80:      	ldr	x20, [x0]
     c84:      	ubfiz	w10, w6, #2, #27
     c88:      	orr	w10, w10, w15
     c8c:      	dup.4s	v1, w10
     c90:      	and.16b	v13, v7, v1
     c94:      	movi.2s	v0, #0x42
     c98:      	umull.2d	v18, v13, v0
     c9c:      	fmov	x10, d18
     ca0:      	add	x15, x20, x10, lsl #2
     ca4:      	movi.2d	v0, #0000000000000000
     ca8:      	movi.2d	v2, #0000000000000000
     cac:      	tbnz	w11, #0x0, 0x1d44 <ltmp0+0x1d44>
     cb0:      	and	w11, w11, #0xff
     cb4:      	tbnz	w11, #0x1, 0x1d50 <ltmp0+0x1d50>
     cb8:      	tbnz	w11, #0x2, 0x1d5c <ltmp0+0x1d5c>
     cbc:      	tbnz	w11, #0x3, 0x1d68 <ltmp0+0x1d68>
     cc0:      	tbnz	w11, #0x4, 0x1d74 <ltmp0+0x1d74>
     cc4:      	tbnz	w11, #0x5, 0x1d80 <ltmp0+0x1d80>
     cc8:      	tbnz	w11, #0x6, 0x1d8c <ltmp0+0x1d8c>
     ccc:      	tbz	w11, #0x7, 0xcd8 <ltmp0+0xcd8>
     cd0:      	add	x10, x15, #0x1c
     cd4:      	ld1.s	{ v2 }[3], [x10]
     cd8:      	ldr	x30, [x0, #0x30]
     cdc:      	ldr	x1, [x0, #0x20]
     ce0:      	ldr	x19, [x0, #0x10]
     ce4:      	fmov	w11, s16
     ce8:      	str	q0, [sp, #0x660]
     cec:      	str	q2, [sp, #0x670]
     cf0:      	adrp	x10, 0x0 <ltmp0>
     cf4:      	ldr	q3, [x10]
     cf8:      	add.2d	v0, v18, v3
     cfc:      	str	q0, [sp, #0x180]
     d00:      	fmov	x10, d0
     d04:      	add	x15, x20, x10, lsl #2
     d08:      	movi.2d	v0, #0000000000000000
     d0c:      	movi.2d	v2, #0000000000000000
     d10:      	tbnz	w11, #0x0, 0x1d9c <ltmp0+0x1d9c>
     d14:      	and	w11, w11, #0xff
     d18:      	tbnz	w11, #0x1, 0x1da8 <ltmp0+0x1da8>
     d1c:      	tbnz	w11, #0x2, 0x1db4 <ltmp0+0x1db4>
     d20:      	tbnz	w11, #0x3, 0x1dc0 <ltmp0+0x1dc0>
     d24:      	tbnz	w11, #0x4, 0x1dcc <ltmp0+0x1dcc>
     d28:      	tbnz	w11, #0x5, 0x1dd8 <ltmp0+0x1dd8>
     d2c:      	tbnz	w11, #0x6, 0x1de4 <ltmp0+0x1de4>
     d30:      	tbz	w11, #0x7, 0xd3c <ltmp0+0xd3c>
     d34:      	add	x10, x15, #0x1c
     d38:      	ld1.s	{ v2 }[3], [x10]
     d3c:      	fmov	w11, s16
     d40:      	str	q0, [sp, #0x680]
     d44:      	str	q2, [sp, #0x690]
     d48:      	adrp	x10, 0x0 <ltmp0>
     d4c:      	ldr	q2, [x10]
     d50:      	add.2d	v15, v18, v2
     d54:      	fmov	x10, d15
     d58:      	add	x15, x20, x10, lsl #2
     d5c:      	movi.2d	v0, #0000000000000000
     d60:      	movi.2d	v4, #0000000000000000
     d64:      	tbnz	w11, #0x0, 0x1df4 <ltmp0+0x1df4>
     d68:      	and	w11, w11, #0xff
     d6c:      	tbnz	w11, #0x1, 0x1e00 <ltmp0+0x1e00>
     d70:      	tbnz	w11, #0x2, 0x1e0c <ltmp0+0x1e0c>
     d74:      	tbnz	w11, #0x3, 0x1e18 <ltmp0+0x1e18>
     d78:      	tbnz	w11, #0x4, 0x1e24 <ltmp0+0x1e24>
     d7c:      	tbnz	w11, #0x5, 0x1e30 <ltmp0+0x1e30>
     d80:      	tbnz	w11, #0x6, 0x1e3c <ltmp0+0x1e3c>
     d84:      	tbz	w11, #0x7, 0xd90 <ltmp0+0xd90>
     d88:      	add	x10, x15, #0x1c
     d8c:      	ld1.s	{ v4 }[3], [x10]
     d90:      	fmov	w11, s16
     d94:      	str	q0, [sp, #0x6a0]
     d98:      	str	q4, [sp, #0x6b0]
     d9c:      	adrp	x10, 0x0 <ltmp0>
     da0:      	ldr	q0, [x10]
     da4:      	add.2d	v4, v18, v0
     da8:      	str	q4, [sp, #0x230]
     dac:      	fmov	x10, d4
     db0:      	add	x15, x20, x10, lsl #2
     db4:      	movi.2d	v4, #0000000000000000
     db8:      	movi.2d	v5, #0000000000000000
     dbc:      	tbnz	w11, #0x0, 0x1e4c <ltmp0+0x1e4c>
     dc0:      	and	w11, w11, #0xff
     dc4:      	tbnz	w11, #0x1, 0x1e58 <ltmp0+0x1e58>
     dc8:      	tbnz	w11, #0x2, 0x1e64 <ltmp0+0x1e64>
     dcc:      	tbnz	w11, #0x3, 0x1e70 <ltmp0+0x1e70>
     dd0:      	tbnz	w11, #0x4, 0x1e7c <ltmp0+0x1e7c>
     dd4:      	tbnz	w11, #0x5, 0x1e88 <ltmp0+0x1e88>
     dd8:      	tbnz	w11, #0x6, 0x1e94 <ltmp0+0x1e94>
     ddc:      	tbz	w11, #0x7, 0xde8 <ltmp0+0xde8>
     de0:      	add	x10, x15, #0x1c
     de4:      	ld1.s	{ v5 }[3], [x10]
     de8:      	xtn.4h	v17, v7
     dec:      	uzp1.8b	v19, v17, v0
     df0:      	str	q4, [sp, #0x6c0]
     df4:      	str	q5, [sp, #0x6d0]
     df8:      	movi.2d	v17, #0000000000000000
     dfc:      	mov.b	v17[0], v19[0]
     e00:      	adrp	x10, 0x0 <ltmp0>
     e04:      	ldr	d5, [x10]
     e08:      	and.8b	v4, v17, v5
     e0c:      	addv.8b	b4, v4
     e10:      	fmov	w17, s4
     e14:      	umaxv.8b	b4, v17
     e18:      	fmov	w10, s4
     e1c:      	rbit	w11, w17
     e20:      	clz	w11, w11
     e24:      	tst	w10, #0x1
     e28:      	csel	w15, w11, wzr, ne
     e2c:      	adrp	x11, 0x0 <ltmp0>
     e30:      	ldr	q4, [x11]
     e34:      	add.2d	v4, v18, v4
     e38:      	movi.2d	v20, #0000000000000000
     e3c:      	mov.b	v20[0], v19[0]
     e40:      	ushll.2d	v19, v20, #0x0
     e44:      	shl.2d	v19, v19, #0x3f
     e48:      	cmlt.2d	v19, v19, #0
     e4c:      	and.16b	v4, v19, v4
     e50:      	movi.2d	v19, #0000000000000000
     e54:      	str	q19, [sp, #0x460]
     e58:      	str	q19, [sp, #0x450]
     e5c:      	str	q19, [sp, #0x440]
     e60:      	str	q4, [sp, #0x430]
     e64:      	and	x11, x15, #0x7
     e68:      	add	x14, sp, #0x430
     e6c:      	ldr	x11, [x14, x11, lsl #3]
     e70:      	sub	x11, x11, x15
     e74:      	add	x4, x20, x11, lsl #2
     e78:      	movi.2d	v20, #0000000000000000
     e7c:      	tbnz	w10, #0x0, 0x1ea4 <ltmp0+0x1ea4>
     e80:      	tbnz	w17, #0x1, 0x1eac <ltmp0+0x1eac>
     e84:      	tbnz	w17, #0x2, 0x1eb8 <ltmp0+0x1eb8>
     e88:      	tbnz	w17, #0x3, 0x1ec4 <ltmp0+0x1ec4>
     e8c:      	tbnz	w17, #0x4, 0x1ed0 <ltmp0+0x1ed0>
     e90:      	tbnz	w17, #0x5, 0x1edc <ltmp0+0x1edc>
     e94:      	tbnz	w17, #0x6, 0x1ee8 <ltmp0+0x1ee8>
     e98:      	tbz	w17, #0x7, 0xea4 <ltmp0+0xea4>
     e9c:      	add	x10, x4, #0x1c
     ea0:      	ld1.s	{ v20 }[3], [x10]
     ea4:      	sshll.2d	v8, v7, #0x0
     ea8:      	adrp	x10, 0x0 <ltmp0>
     eac:      	ldr	q4, [x10]
     eb0:      	str	q4, [sp, #0x250]
     eb4:      	and.16b	v4, v8, v4
     eb8:      	and.16b	v28, v8, v18
     ebc:      	fmov	w11, s16
     ec0:      	adrp	x10, 0x0 <ltmp0>
     ec4:      	ldr	q21, [x10]
     ec8:      	adrp	x10, 0x0 <ltmp0>
     ecc:      	ldr	q22, [x10]
     ed0:      	str	q21, [sp, #0x410]
     ed4:      	str	q22, [sp, #0x400]
     ed8:      	adrp	x10, 0x0 <ltmp0>
     edc:      	ldr	q21, [x10]
     ee0:      	adrp	x10, 0x0 <ltmp0>
     ee4:      	ldr	q22, [x10]
     ee8:      	stp	q22, q21, [sp, #0x3e0]
     eec:      	and	x10, x15, #0x7
     ef0:      	add	x14, sp, #0x3e0
     ef4:      	ldr	x10, [x14, x10, lsl #3]
     ef8:      	lsl	x4, x15, #2
     efc:      	sub	x10, x10, x4
     f00:      	tst	w17, #0xff
     f04:      	csel	x7, xzr, x10, eq
     f08:      	add	x10, x24, x7
     f0c:      	ldp	q21, q22, [x10]
     f10:      	zip2.8b	v23, v17, v0
     f14:      	ushll.4s	v23, v23, #0x0
     f18:      	shl.4s	v23, v23, #0x1f
     f1c:      	cmlt.4s	v23, v23, #0
     f20:      	bif.16b	v20, v22, v23
     f24:      	zip1.8b	v22, v17, v0
     f28:      	ushll.4s	v22, v22, #0x0
     f2c:      	shl.4s	v22, v22, #0x1f
     f30:      	cmlt.4s	v22, v22, #0
     f34:      	bif.16b	v19, v21, v22
     f38:      	stp	q19, q20, [x10]
     f3c:      	mov	w10, #0x21              ; =33
     f40:      	dup.2d	v19, x10
     f44:      	add.2d	v22, v28, v19
     f48:      	add.2d	v19, v22, v4
     f4c:      	str	q19, [sp, #0x220]
     f50:      	fmov	x10, d19
     f54:      	add	x23, x20, x10, lsl #2
     f58:      	movi.2d	v19, #0000000000000000
     f5c:      	movi.2d	v21, #0000000000000000
     f60:      	tbnz	w11, #0x0, 0x1ef8 <ltmp0+0x1ef8>
     f64:      	and	w11, w11, #0xff
     f68:      	tbnz	w11, #0x1, 0x1f04 <ltmp0+0x1f04>
     f6c:      	tbnz	w11, #0x2, 0x1f10 <ltmp0+0x1f10>
     f70:      	tbnz	w11, #0x3, 0x1f1c <ltmp0+0x1f1c>
     f74:      	tbnz	w11, #0x4, 0x1f28 <ltmp0+0x1f28>
     f78:      	tbnz	w11, #0x5, 0x1f34 <ltmp0+0x1f34>
     f7c:      	tbnz	w11, #0x6, 0x1f40 <ltmp0+0x1f40>
     f80:      	tbz	w11, #0x7, 0xf8c <ltmp0+0xf8c>
     f84:      	add	x10, x23, #0x1c
     f88:      	ld1.s	{ v21 }[3], [x10]
     f8c:      	sshll.2d	v31, v7, #0x0
     f90:      	and.16b	v20, v31, v3
     f94:      	fmov	w11, s16
     f98:      	str	q19, [sp, #0x5c0]
     f9c:      	str	q21, [sp, #0x5d0]
     fa0:      	add.2d	v3, v22, v20
     fa4:      	str	q3, [sp, #0x200]
     fa8:      	fmov	x10, d3
     fac:      	add	x23, x20, x10, lsl #2
     fb0:      	movi.2d	v3, #0000000000000000
     fb4:      	movi.2d	v21, #0000000000000000
     fb8:      	tbnz	w11, #0x0, 0x1f50 <ltmp0+0x1f50>
     fbc:      	and	w11, w11, #0xff
     fc0:      	tbnz	w11, #0x1, 0x1f5c <ltmp0+0x1f5c>
     fc4:      	tbnz	w11, #0x2, 0x1f68 <ltmp0+0x1f68>
     fc8:      	tbnz	w11, #0x3, 0x1f74 <ltmp0+0x1f74>
     fcc:      	tbnz	w11, #0x4, 0x1f80 <ltmp0+0x1f80>
     fd0:      	tbnz	w11, #0x5, 0x1f8c <ltmp0+0x1f8c>
     fd4:      	tbnz	w11, #0x6, 0x1f98 <ltmp0+0x1f98>
     fd8:      	tbz	w11, #0x7, 0xfe4 <ltmp0+0xfe4>
     fdc:      	add	x10, x23, #0x1c
     fe0:      	ld1.s	{ v21 }[3], [x10]
     fe4:      	sshll.2d	v11, v7, #0x0
     fe8:      	and.16b	v19, v11, v2
     fec:      	fmov	w11, s16
     ff0:      	ldr	q2, [sp, #0x5e0]
     ff4:      	ldr	q23, [sp, #0x5f0]
     ff8:      	bif.16b	v21, v23, v6
     ffc:      	bit.16b	v2, v3, v7
    1000:      	str	q2, [sp, #0x5e0]
    1004:      	str	q21, [sp, #0x5f0]
    1008:      	add.2d	v2, v22, v19
    100c:      	str	q2, [sp, #0x1f0]
    1010:      	fmov	x10, d2
    1014:      	add	x23, x20, x10, lsl #2
    1018:      	movi.2d	v2, #0000000000000000
    101c:      	movi.2d	v3, #0000000000000000
    1020:      	tbnz	w11, #0x0, 0x1fa8 <ltmp0+0x1fa8>
    1024:      	and	w11, w11, #0xff
    1028:      	tbnz	w11, #0x1, 0x1fb4 <ltmp0+0x1fb4>
    102c:      	tbnz	w11, #0x2, 0x1fc0 <ltmp0+0x1fc0>
    1030:      	tbnz	w11, #0x3, 0x1fcc <ltmp0+0x1fcc>
    1034:      	tbnz	w11, #0x4, 0x1fd8 <ltmp0+0x1fd8>
    1038:      	tbnz	w11, #0x5, 0x1fe4 <ltmp0+0x1fe4>
    103c:      	tbnz	w11, #0x6, 0x1ff0 <ltmp0+0x1ff0>
    1040:      	tbz	w11, #0x7, 0x104c <ltmp0+0x104c>
    1044:      	add	x10, x23, #0x1c
    1048:      	ld1.s	{ v3 }[3], [x10]
    104c:      	sshll.2d	v12, v7, #0x0
    1050:      	and.16b	v21, v12, v0
    1054:      	fmov	w11, s16
    1058:      	ldr	q0, [sp, #0x600]
    105c:      	ldr	q23, [sp, #0x610]
    1060:      	bif.16b	v3, v23, v6
    1064:      	bit.16b	v0, v2, v7
    1068:      	str	q0, [sp, #0x600]
    106c:      	str	q3, [sp, #0x610]
    1070:      	add.2d	v0, v22, v21
    1074:      	str	q0, [sp, #0x1e0]
    1078:      	fmov	x10, d0
    107c:      	add	x23, x20, x10, lsl #2
    1080:      	movi.2d	v2, #0000000000000000
    1084:      	movi.2d	v3, #0000000000000000
    1088:      	tbnz	w11, #0x0, 0x2000 <ltmp0+0x2000>
    108c:      	and	w11, w11, #0xff
    1090:      	tbnz	w11, #0x1, 0x200c <ltmp0+0x200c>
    1094:      	tbnz	w11, #0x2, 0x2018 <ltmp0+0x2018>
    1098:      	tbnz	w11, #0x3, 0x2024 <ltmp0+0x2024>
    109c:      	tbnz	w11, #0x4, 0x2030 <ltmp0+0x2030>
    10a0:      	tbnz	w11, #0x5, 0x203c <ltmp0+0x203c>
    10a4:      	tbnz	w11, #0x6, 0x2048 <ltmp0+0x2048>
    10a8:      	tbz	w11, #0x7, 0x10b4 <ltmp0+0x10b4>
    10ac:      	add	x10, x23, #0x1c
    10b0:      	ld1.s	{ v3 }[3], [x10]
    10b4:      	sshll.2d	v29, v6, #0x0
    10b8:      	sshll2.2d	v30, v7, #0x0
    10bc:      	sshll2.2d	v0, v6, #0x0
    10c0:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    10c4:      	ldr	q22, [x10]
    10c8:      	and.16b	v22, v0, v22
    10cc:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    10d0:      	ldr	q23, [x10]
    10d4:      	and.16b	v24, v30, v23
    10d8:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    10dc:      	ldr	q23, [x10]
    10e0:      	and.16b	v25, v29, v23
    10e4:      	and.16b	v26, v6, v1
    10e8:      	movi.2s	v1, #0x42
    10ec:      	umull.2d	v1, v26, v1
    10f0:      	movi.4s	v27, #0x42
    10f4:      	umull2.2d	v23, v13, v27
    10f8:      	umull2.2d	v27, v26, v27
    10fc:      	and.16b	v9, v0, v27
    1100:      	str	q30, [sp, #0x240]
    1104:      	and.16b	v27, v30, v23
    1108:      	str	q29, [sp, #0x190]
    110c:      	and.16b	v29, v29, v1
    1110:      	ldr	q1, [sp, #0x620]
    1114:      	ldr	q23, [sp, #0x630]
    1118:      	bif.16b	v3, v23, v6
    111c:      	bit.16b	v1, v2, v7
    1120:      	str	q1, [sp, #0x620]
    1124:      	str	q3, [sp, #0x630]
    1128:      	add.2d	v1, v4, v28
    112c:      	stp	q9, q27, [sp, #0x160]
    1130:      	add.2d	v2, v24, v27
    1134:      	str	q29, [sp, #0x150]
    1138:      	add.2d	v3, v25, v29
    113c:      	add.2d	v23, v22, v9
    1140:      	mov	w10, #0x41              ; =65
    1144:      	dup.2d	v27, x10
    1148:      	add.2d	v29, v23, v27
    114c:      	add.2d	v23, v3, v27
    1150:      	add.2d	v3, v2, v27
    1154:      	mov	b2, v17[0]
    1158:      	mov.b	v2[4], v17[1]
    115c:      	add.2d	v27, v1, v27
    1160:      	ushll.2d	v1, v2, #0x0
    1164:      	shl.2d	v1, v1, #0x3f
    1168:      	cmlt.2d	v1, v1, #0
    116c:      	stp	q27, q3, [sp, #0x1a0]
    1170:      	and.16b	v1, v1, v27
    1174:      	mov	b2, v17[2]
    1178:      	mov.b	v2[4], v17[3]
    117c:      	ushll.2d	v2, v2, #0x0
    1180:      	shl.2d	v2, v2, #0x3f
    1184:      	cmlt.2d	v2, v2, #0
    1188:      	and.16b	v2, v2, v3
    118c:      	mov	b3, v17[4]
    1190:      	mov.b	v3[4], v17[5]
    1194:      	ushll.2d	v3, v3, #0x0
    1198:      	shl.2d	v3, v3, #0x3f
    119c:      	cmlt.2d	v3, v3, #0
    11a0:      	stp	q23, q29, [sp, #0x1c0]
    11a4:      	and.16b	v3, v3, v23
    11a8:      	mov	b23, v17[6]
    11ac:      	mov.b	v23[4], v17[7]
    11b0:      	ushll.2d	v23, v23, #0x0
    11b4:      	shl.2d	v23, v23, #0x3f
    11b8:      	cmlt.2d	v23, v23, #0
    11bc:      	and.16b	v23, v23, v29
    11c0:      	shl.8b	v27, v17, #0x7
    11c4:      	cmlt.8b	v27, v27, #0
    11c8:      	and.8b	v5, v27, v5
    11cc:      	addv.8b	b14, v5
    11d0:      	fmov	w23, s14
    11d4:      	stp	q3, q23, [sp, #0x3b0]
    11d8:      	stp	q1, q2, [sp, #0x390]
    11dc:      	and	x10, x15, #0x7
    11e0:      	add	x11, sp, #0x390
    11e4:      	ldr	x10, [x11, x10, lsl #3]
    11e8:      	sub	x10, x10, x15
    11ec:      	add	x20, x20, x10, lsl #2
    11f0:      	movi.2d	v1, #0000000000000000
    11f4:      	movi.2d	v2, #0000000000000000
    11f8:      	tbnz	w23, #0x0, 0x2058 <ltmp0+0x2058>
    11fc:      	tbnz	w23, #0x1, 0x2060 <ltmp0+0x2060>
    1200:      	tbnz	w23, #0x2, 0x206c <ltmp0+0x206c>
    1204:      	tbnz	w23, #0x3, 0x2078 <ltmp0+0x2078>
    1208:      	tbnz	w23, #0x4, 0x2084 <ltmp0+0x2084>
    120c:      	tbnz	w23, #0x5, 0x2090 <ltmp0+0x2090>
    1210:      	tbnz	w23, #0x6, 0x209c <ltmp0+0x209c>
    1214:      	str	q28, [sp, #0x210]
    1218:      	tbz	w23, #0x7, 0x1224 <ltmp0+0x1224>
    121c:      	add	x10, x20, #0x1c
    1220:      	ld1.s	{ v2 }[3], [x10]
    1224:      	ushll.2d	v3, v13, #0x0
    1228:      	fmov	w11, s16
    122c:      	sshll.2d	v27, v7, #0x0
    1230:      	add	x10, x25, x7
    1234:      	ldp	q5, q23, [x10]
    1238:      	zip2.8b	v28, v17, v0
    123c:      	ushll.4s	v28, v28, #0x0
    1240:      	shl.4s	v28, v28, #0x1f
    1244:      	cmlt.4s	v28, v28, #0
    1248:      	bif.16b	v2, v23, v28
    124c:      	zip1.8b	v23, v17, v0
    1250:      	ushll.4s	v23, v23, #0x0
    1254:      	shl.4s	v23, v23, #0x1f
    1258:      	cmlt.4s	v23, v23, #0
    125c:      	bif.16b	v1, v5, v23
    1260:      	stp	q1, q2, [x10]
    1264:      	xtn.2s	v1, v3
    1268:      	movi.2s	v2, #0x21
    126c:      	umull.2d	v1, v1, v2
    1270:      	and.16b	v9, v27, v1
    1274:      	add.2d	v30, v9, v4
    1278:      	fmov	x10, d30
    127c:      	add	x20, x19, x10, lsl #2
    1280:      	movi.2d	v1, #0000000000000000
    1284:      	movi.2d	v2, #0000000000000000
    1288:      	tbnz	w11, #0x0, 0x20b0 <ltmp0+0x20b0>
    128c:      	and	w11, w11, #0xff
    1290:      	tbnz	w11, #0x1, 0x20bc <ltmp0+0x20bc>
    1294:      	tbnz	w11, #0x2, 0x20c8 <ltmp0+0x20c8>
    1298:      	tbnz	w11, #0x3, 0x20d4 <ltmp0+0x20d4>
    129c:      	tbnz	w11, #0x4, 0x20e0 <ltmp0+0x20e0>
    12a0:      	tbnz	w11, #0x5, 0x20ec <ltmp0+0x20ec>
    12a4:      	tbnz	w11, #0x6, 0x20f8 <ltmp0+0x20f8>
    12a8:      	tbz	w11, #0x7, 0x12b4 <ltmp0+0x12b4>
    12ac:      	add	x10, x20, #0x1c
    12b0:      	ld1.s	{ v2 }[3], [x10]
    12b4:      	fmov	w11, s16
    12b8:      	ldr	q3, [sp, #0x520]
    12bc:      	ldr	q5, [sp, #0x530]
    12c0:      	bif.16b	v2, v5, v6
    12c4:      	bif.16b	v1, v3, v7
    12c8:      	str	q1, [sp, #0x520]
    12cc:      	str	q2, [sp, #0x530]
    12d0:      	add.2d	v29, v9, v20
    12d4:      	fmov	x10, d29
    12d8:      	add	x20, x19, x10, lsl #2
    12dc:      	movi.2d	v1, #0000000000000000
    12e0:      	movi.2d	v2, #0000000000000000
    12e4:      	tbnz	w11, #0x0, 0x2108 <ltmp0+0x2108>
    12e8:      	and	w11, w11, #0xff
    12ec:      	tbnz	w11, #0x1, 0x2114 <ltmp0+0x2114>
    12f0:      	tbnz	w11, #0x2, 0x2120 <ltmp0+0x2120>
    12f4:      	tbnz	w11, #0x3, 0x212c <ltmp0+0x212c>
    12f8:      	tbnz	w11, #0x4, 0x2138 <ltmp0+0x2138>
    12fc:      	tbnz	w11, #0x5, 0x2144 <ltmp0+0x2144>
    1300:      	tbnz	w11, #0x6, 0x2150 <ltmp0+0x2150>
    1304:      	tbz	w11, #0x7, 0x1310 <ltmp0+0x1310>
    1308:      	add	x10, x20, #0x1c
    130c:      	ld1.s	{ v2 }[3], [x10]
    1310:      	fmov	w11, s16
    1314:      	ldr	q3, [sp, #0x540]
    1318:      	ldr	q5, [sp, #0x550]
    131c:      	bif.16b	v2, v5, v6
    1320:      	bif.16b	v1, v3, v7
    1324:      	str	q1, [sp, #0x540]
    1328:      	str	q2, [sp, #0x550]
    132c:      	add.2d	v28, v9, v19
    1330:      	fmov	x10, d28
    1334:      	add	x20, x19, x10, lsl #2
    1338:      	movi.2d	v1, #0000000000000000
    133c:      	movi.2d	v2, #0000000000000000
    1340:      	tbnz	w11, #0x0, 0x2160 <ltmp0+0x2160>
    1344:      	and	w11, w11, #0xff
    1348:      	tbnz	w11, #0x1, 0x216c <ltmp0+0x216c>
    134c:      	tbnz	w11, #0x2, 0x2178 <ltmp0+0x2178>
    1350:      	tbnz	w11, #0x3, 0x2184 <ltmp0+0x2184>
    1354:      	tbnz	w11, #0x4, 0x2190 <ltmp0+0x2190>
    1358:      	tbnz	w11, #0x5, 0x219c <ltmp0+0x219c>
    135c:      	tbnz	w11, #0x6, 0x21a8 <ltmp0+0x21a8>
    1360:      	tbz	w11, #0x7, 0x136c <ltmp0+0x136c>
    1364:      	add	x10, x20, #0x1c
    1368:      	ld1.s	{ v2 }[3], [x10]
    136c:      	fmov	w11, s16
    1370:      	ldr	q3, [sp, #0x560]
    1374:      	ldr	q5, [sp, #0x570]
    1378:      	bif.16b	v2, v5, v6
    137c:      	bif.16b	v1, v3, v7
    1380:      	str	q1, [sp, #0x560]
    1384:      	str	q2, [sp, #0x570]
    1388:      	add.2d	v20, v9, v21
    138c:      	fmov	x10, d20
    1390:      	add	x20, x19, x10, lsl #2
    1394:      	movi.2d	v1, #0000000000000000
    1398:      	movi.2d	v2, #0000000000000000
    139c:      	tbnz	w11, #0x0, 0x21b8 <ltmp0+0x21b8>
    13a0:      	and	w11, w11, #0xff
    13a4:      	tbnz	w11, #0x1, 0x21c4 <ltmp0+0x21c4>
    13a8:      	tbnz	w11, #0x2, 0x21d0 <ltmp0+0x21d0>
    13ac:      	tbnz	w11, #0x3, 0x21dc <ltmp0+0x21dc>
    13b0:      	tbnz	w11, #0x4, 0x21e8 <ltmp0+0x21e8>
    13b4:      	tbnz	w11, #0x5, 0x21f4 <ltmp0+0x21f4>
    13b8:      	tbnz	w11, #0x6, 0x2200 <ltmp0+0x2200>
    13bc:      	tbz	w11, #0x7, 0x13c8 <ltmp0+0x13c8>
    13c0:      	add	x10, x20, #0x1c
    13c4:      	ld1.s	{ v2 }[3], [x10]
    13c8:      	ushll2.2d	v3, v26, #0x0
    13cc:      	ushll2.2d	v5, v13, #0x0
    13d0:      	dup.2d	v19, x9
    13d4:      	ushll.2d	v21, v26, #0x0
    13d8:      	orr.16b	v25, v25, v19
    13dc:      	orr.16b	v24, v24, v19
    13e0:      	orr.16b	v23, v4, v19
    13e4:      	orr.16b	v26, v22, v19
    13e8:      	sshll.2d	v4, v6, #0x0
    13ec:      	xtn.2s	v5, v5
    13f0:      	movi.2s	v22, #0x21
    13f4:      	umull.2d	v5, v5, v22
    13f8:      	xtn.2s	v19, v21
    13fc:      	umull.2d	v19, v19, v22
    1400:      	xtn.2s	v3, v3
    1404:      	umull.2d	v3, v3, v22
    1408:      	and.16b	v3, v0, v3
    140c:      	and.16b	v4, v4, v19
    1410:      	ldr	q19, [sp, #0x240]
    1414:      	and.16b	v5, v19, v5
    1418:      	ldr	q19, [sp, #0x580]
    141c:      	ldr	q21, [sp, #0x590]
    1420:      	bif.16b	v2, v21, v6
    1424:      	bif.16b	v1, v19, v7
    1428:      	str	q1, [sp, #0x580]
    142c:      	str	q2, [sp, #0x590]
    1430:      	mov.16b	v10, v26
    1434:      	add.2d	v1, v3, v26
    1438:      	stp	q25, q24, [sp, #0x130]
    143c:      	add.2d	v2, v4, v25
    1440:      	add.2d	v3, v5, v24
    1444:      	add.2d	v4, v9, v23
    1448:      	mov.16b	v9, v23
    144c:      	mov	b5, v17[0]
    1450:      	mov.b	v5[4], v17[1]
    1454:      	ushll.2d	v5, v5, #0x0
    1458:      	shl.2d	v5, v5, #0x3f
    145c:      	cmlt.2d	v5, v5, #0
    1460:      	and.16b	v4, v5, v4
    1464:      	mov	b5, v17[2]
    1468:      	mov.b	v5[4], v17[3]
    146c:      	ushll.2d	v5, v5, #0x0
    1470:      	shl.2d	v5, v5, #0x3f
    1474:      	cmlt.2d	v5, v5, #0
    1478:      	and.16b	v3, v5, v3
    147c:      	mov	b5, v17[4]
    1480:      	mov.b	v5[4], v17[5]
    1484:      	ushll.2d	v5, v5, #0x0
    1488:      	shl.2d	v5, v5, #0x3f
    148c:      	cmlt.2d	v5, v5, #0
    1490:      	mov	b19, v17[6]
    1494:      	mov.b	v19[4], v17[7]
    1498:      	and.16b	v2, v5, v2
    149c:      	ushll.2d	v5, v19, #0x0
    14a0:      	shl.2d	v5, v5, #0x3f
    14a4:      	cmlt.2d	v5, v5, #0
    14a8:      	and.16b	v1, v5, v1
    14ac:      	stp	q2, q1, [sp, #0x360]
    14b0:      	stp	q4, q3, [sp, #0x340]
    14b4:      	and	x10, x15, #0x7
    14b8:      	add	x11, sp, #0x340
    14bc:      	ldr	x10, [x11, x10, lsl #3]
    14c0:      	fmov	w23, s14
    14c4:      	sub	x10, x10, x15
    14c8:      	lsl	x20, x10, #2
    14cc:      	add	x19, x19, x20
    14d0:      	movi.2d	v1, #0000000000000000
    14d4:      	movi.2d	v2, #0000000000000000
    14d8:      	tbnz	w23, #0x0, 0x2210 <ltmp0+0x2210>
    14dc:      	tbnz	w23, #0x1, 0x2218 <ltmp0+0x2218>
    14e0:      	tbnz	w23, #0x2, 0x2224 <ltmp0+0x2224>
    14e4:      	tbnz	w23, #0x3, 0x2230 <ltmp0+0x2230>
    14e8:      	tbnz	w23, #0x4, 0x223c <ltmp0+0x223c>
    14ec:      	tbnz	w23, #0x5, 0x2248 <ltmp0+0x2248>
    14f0:      	tbnz	w23, #0x6, 0x2254 <ltmp0+0x2254>
    14f4:      	tbz	w23, #0x7, 0x1500 <ltmp0+0x1500>
    14f8:      	add	x10, x19, #0x1c
    14fc:      	ld1.s	{ v2 }[3], [x10]
    1500:      	and.16b	v3, v27, v30
    1504:      	fmov	w11, s16
    1508:      	add	x10, x26, x7
    150c:      	ldp	q4, q5, [x10]
    1510:      	zip2.8b	v19, v17, v0
    1514:      	ushll.4s	v19, v19, #0x0
    1518:      	shl.4s	v19, v19, #0x1f
    151c:      	cmlt.4s	v19, v19, #0
    1520:      	bif.16b	v2, v5, v19
    1524:      	zip1.8b	v5, v17, v0
    1528:      	ushll.4s	v5, v5, #0x0
    152c:      	shl.4s	v5, v5, #0x1f
    1530:      	cmlt.4s	v5, v5, #0
    1534:      	bif.16b	v1, v4, v5
    1538:      	stp	q1, q2, [x10]
    153c:      	fmov	x10, d3
    1540:      	add	x19, x1, x10, lsl #2
    1544:      	movi.2d	v1, #0000000000000000
    1548:      	movi.2d	v2, #0000000000000000
    154c:      	tbnz	w11, #0x0, 0x2264 <ltmp0+0x2264>
    1550:      	and	w11, w11, #0xff
    1554:      	tbnz	w11, #0x1, 0x2270 <ltmp0+0x2270>
    1558:      	tbnz	w11, #0x2, 0x227c <ltmp0+0x227c>
    155c:      	tbnz	w11, #0x3, 0x2288 <ltmp0+0x2288>
    1560:      	tbnz	w11, #0x4, 0x2294 <ltmp0+0x2294>
    1564:      	tbnz	w11, #0x5, 0x22a0 <ltmp0+0x22a0>
    1568:      	tbnz	w11, #0x6, 0x22ac <ltmp0+0x22ac>
    156c:      	tbz	w11, #0x7, 0x1578 <ltmp0+0x1578>
    1570:      	add	x10, x19, #0x1c
    1574:      	ld1.s	{ v2 }[3], [x10]
    1578:      	sshll.2d	v3, v7, #0x0
    157c:      	and.16b	v3, v3, v29
    1580:      	fmov	w11, s16
    1584:      	ldr	q4, [sp, #0x480]
    1588:      	ldr	q5, [sp, #0x490]
    158c:      	bif.16b	v2, v5, v6
    1590:      	bif.16b	v1, v4, v7
    1594:      	str	q1, [sp, #0x480]
    1598:      	str	q2, [sp, #0x490]
    159c:      	fmov	x10, d3
    15a0:      	add	x19, x1, x10, lsl #2
    15a4:      	movi.2d	v1, #0000000000000000
    15a8:      	movi.2d	v2, #0000000000000000
    15ac:      	tbnz	w11, #0x0, 0x22bc <ltmp0+0x22bc>
    15b0:      	and	w11, w11, #0xff
    15b4:      	tbnz	w11, #0x1, 0x22c8 <ltmp0+0x22c8>
    15b8:      	tbnz	w11, #0x2, 0x22d4 <ltmp0+0x22d4>
    15bc:      	tbnz	w11, #0x3, 0x22e0 <ltmp0+0x22e0>
    15c0:      	tbnz	w11, #0x4, 0x22ec <ltmp0+0x22ec>
    15c4:      	tbnz	w11, #0x5, 0x22f8 <ltmp0+0x22f8>
    15c8:      	tbnz	w11, #0x6, 0x2304 <ltmp0+0x2304>
    15cc:      	tbz	w11, #0x7, 0x15d8 <ltmp0+0x15d8>
    15d0:      	add	x10, x19, #0x1c
    15d4:      	ld1.s	{ v2 }[3], [x10]
    15d8:      	sshll.2d	v3, v7, #0x0
    15dc:      	and.16b	v3, v3, v28
    15e0:      	fmov	w11, s16
    15e4:      	ldr	q4, [sp, #0x4a0]
    15e8:      	ldr	q5, [sp, #0x4b0]
    15ec:      	bif.16b	v2, v5, v6
    15f0:      	bif.16b	v1, v4, v7
    15f4:      	str	q1, [sp, #0x4a0]
    15f8:      	str	q2, [sp, #0x4b0]
    15fc:      	fmov	x10, d3
    1600:      	add	x19, x1, x10, lsl #2
    1604:      	movi.2d	v1, #0000000000000000
    1608:      	movi.2d	v2, #0000000000000000
    160c:      	tbnz	w11, #0x0, 0x2314 <ltmp0+0x2314>
    1610:      	and	w11, w11, #0xff
    1614:      	tbnz	w11, #0x1, 0x2320 <ltmp0+0x2320>
    1618:      	tbnz	w11, #0x2, 0x232c <ltmp0+0x232c>
    161c:      	tbnz	w11, #0x3, 0x2338 <ltmp0+0x2338>
    1620:      	tbnz	w11, #0x4, 0x2344 <ltmp0+0x2344>
    1624:      	tbnz	w11, #0x5, 0x2350 <ltmp0+0x2350>
    1628:      	tbnz	w11, #0x6, 0x235c <ltmp0+0x235c>
    162c:      	tbz	w11, #0x7, 0x1638 <ltmp0+0x1638>
    1630:      	add	x10, x19, #0x1c
    1634:      	ld1.s	{ v2 }[3], [x10]
    1638:      	sshll.2d	v3, v7, #0x0
    163c:      	and.16b	v3, v3, v20
    1640:      	fmov	w11, s16
    1644:      	ldr	q4, [sp, #0x4c0]
    1648:      	ldr	q5, [sp, #0x4d0]
    164c:      	bif.16b	v2, v5, v6
    1650:      	bif.16b	v1, v4, v7
    1654:      	str	q1, [sp, #0x4c0]
    1658:      	str	q2, [sp, #0x4d0]
    165c:      	fmov	x10, d3
    1660:      	add	x19, x1, x10, lsl #2
    1664:      	movi.2d	v1, #0000000000000000
    1668:      	movi.2d	v2, #0000000000000000
    166c:      	tbnz	w11, #0x0, 0x236c <ltmp0+0x236c>
    1670:      	and	w11, w11, #0xff
    1674:      	tbnz	w11, #0x1, 0x2378 <ltmp0+0x2378>
    1678:      	tbnz	w11, #0x2, 0x2384 <ltmp0+0x2384>
    167c:      	tbnz	w11, #0x3, 0x2390 <ltmp0+0x2390>
    1680:      	tbnz	w11, #0x4, 0x239c <ltmp0+0x239c>
    1684:      	tbnz	w11, #0x5, 0x23a8 <ltmp0+0x23a8>
    1688:      	tbnz	w11, #0x6, 0x23b4 <ltmp0+0x23b4>
    168c:      	tbz	w11, #0x7, 0x1698 <ltmp0+0x1698>
    1690:      	add	x10, x19, #0x1c
    1694:      	ld1.s	{ v2 }[3], [x10]
    1698:      	ldr	q3, [sp, #0x4e0]
    169c:      	ldr	q4, [sp, #0x4f0]
    16a0:      	bif.16b	v2, v4, v6
    16a4:      	bif.16b	v1, v3, v7
    16a8:      	str	q1, [sp, #0x4e0]
    16ac:      	str	q2, [sp, #0x4f0]
    16b0:      	add	x1, x1, x20
    16b4:      	fmov	w19, s14
    16b8:      	movi.2d	v1, #0000000000000000
    16bc:      	movi.2d	v2, #0000000000000000
    16c0:      	tbnz	w19, #0x0, 0x23c4 <ltmp0+0x23c4>
    16c4:      	tbnz	w19, #0x1, 0x23cc <ltmp0+0x23cc>
    16c8:      	tbnz	w19, #0x2, 0x23d8 <ltmp0+0x23d8>
    16cc:      	tbnz	w19, #0x3, 0x23e4 <ltmp0+0x23e4>
    16d0:      	tbnz	w19, #0x4, 0x23f0 <ltmp0+0x23f0>
    16d4:      	tbnz	w19, #0x5, 0x23fc <ltmp0+0x23fc>
    16d8:      	tbnz	w19, #0x6, 0x2408 <ltmp0+0x2408>
    16dc:      	tbz	w19, #0x7, 0x16e8 <ltmp0+0x16e8>
    16e0:      	add	x10, x1, #0x1c
    16e4:      	ld1.s	{ v2 }[3], [x10]
    16e8:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    16ec:      	ldr	q3, [x10]
    16f0:      	and.16b	v21, v8, v3
    16f4:      	ldr	q3, [sp, #0x250]
    16f8:      	orr.16b	v3, v18, v3
    16fc:      	and.16b	v4, v8, v3
    1700:      	fmov	w14, s16
    1704:      	add	x10, x27, x7
    1708:      	ldp	q3, q5, [x10]
    170c:      	zip2.8b	v18, v17, v0
    1710:      	ushll.4s	v18, v18, #0x0
    1714:      	shl.4s	v18, v18, #0x1f
    1718:      	cmlt.4s	v18, v18, #0
    171c:      	bif.16b	v2, v5, v18
    1720:      	zip1.8b	v5, v17, v0
    1724:      	ushll.4s	v5, v5, #0x0
    1728:      	shl.4s	v5, v5, #0x1f
    172c:      	cmlt.4s	v5, v5, #0
    1730:      	bif.16b	v1, v3, v5
    1734:      	stp	q1, q2, [x10]
    1738:      	fmov	x10, d21
    173c:      	add	x11, x24, x10
    1740:      	ldp	q3, q1, [x11]
    1744:      	add	x11, x26, x10
    1748:      	ldp	q5, q2, [x11]
    174c:      	str	q3, [sp, #0xa0]
    1750:      	str	q5, [sp, #0x80]
    1754:      	fmul.4s	v3, v3, v5
    1758:      	add	x11, x25, x10
    175c:      	ldp	q5, q18, [x11]
    1760:      	add	x10, x27, x10
    1764:      	ldp	q20, q19, [x10]
    1768:      	stp	q20, q5, [sp, #0x50]
    176c:      	fmul.4s	v5, v5, v20
    1770:      	fsub.4s	v3, v3, v5
    1774:      	and.16b	v3, v7, v3
    1778:      	fmov	x10, d4
    177c:      	add	x11, x30, x10, lsl #2
    1780:      	tbnz	w14, #0x0, 0x2418 <ltmp0+0x2418>
    1784:      	and	w14, w14, #0xff
    1788:      	tbnz	w14, #0x1, 0x2424 <ltmp0+0x2424>
    178c:      	tbnz	w14, #0x2, 0x2430 <ltmp0+0x2430>
    1790:      	tbnz	w14, #0x3, 0x243c <ltmp0+0x243c>
    1794:      	fmul.4s	v3, v1, v2
    1798:      	fmul.4s	v4, v18, v19
    179c:      	fsub.4s	v3, v3, v4
    17a0:      	and.16b	v3, v6, v3
    17a4:      	tbnz	w14, #0x4, 0x2458 <ltmp0+0x2458>
    17a8:      	tbnz	w14, #0x5, 0x2460 <ltmp0+0x2460>
    17ac:      	tbnz	w14, #0x6, 0x246c <ltmp0+0x246c>
    17b0:      	stp	q19, q18, [sp, #0x100]
    17b4:      	str	q1, [sp, #0x120]
    17b8:      	str	d14, [sp, #0x250]
    17bc:      	tbz	w14, #0x7, 0x17c8 <ltmp0+0x17c8>
    17c0:      	add	x10, x11, #0x1c
    17c4:      	st1.s	{ v3 }[3], [x10]
    17c8:      	ldr	q1, [sp, #0x180]
    17cc:      	and.16b	v18, v31, v1
    17d0:      	fmov	d3, x9
    17d4:      	and.16b	v3, v11, v3
    17d8:      	fmov	w14, s16
    17dc:      	fmov	x10, d3
    17e0:      	add	x11, x24, x10
    17e4:      	ldp	q4, q1, [x11]
    17e8:      	add	x11, x26, x10
    17ec:      	ldp	q14, q3, [x11]
    17f0:      	str	q4, [sp, #0x30]
    17f4:      	fmul.4s	v4, v4, v14
    17f8:      	add	x11, x25, x10
    17fc:      	ldp	q5, q20, [x11]
    1800:      	add	x10, x27, x10
    1804:      	ldp	q13, q22, [x10]
    1808:      	fmul.4s	v19, v5, v13
    180c:      	fsub.4s	v4, v4, v19
    1810:      	and.16b	v4, v7, v4
    1814:      	fmov	x10, d18
    1818:      	add	x11, x30, x10, lsl #2
    181c:      	tbnz	w14, #0x0, 0x2488 <ltmp0+0x2488>
    1820:      	and	w14, w14, #0xff
    1824:      	tbnz	w14, #0x1, 0x2494 <ltmp0+0x2494>
    1828:      	tbnz	w14, #0x2, 0x24a0 <ltmp0+0x24a0>
    182c:      	tbnz	w14, #0x3, 0x24ac <ltmp0+0x24ac>
    1830:      	fmul.4s	v4, v1, v3
    1834:      	fmul.4s	v18, v20, v22
    1838:      	fsub.4s	v4, v4, v18
    183c:      	and.16b	v4, v6, v4
    1840:      	tbnz	w14, #0x4, 0x24c8 <ltmp0+0x24c8>
    1844:      	tbnz	w14, #0x5, 0x24d0 <ltmp0+0x24d0>
    1848:      	tbnz	w14, #0x6, 0x24dc <ltmp0+0x24dc>
    184c:      	stp	q22, q20, [sp, #0xd0]
    1850:      	str	q1, [sp, #0x180]
    1854:      	tbz	w14, #0x7, 0x1860 <ltmp0+0x1860>
    1858:      	add	x10, x11, #0x1c
    185c:      	st1.s	{ v4 }[3], [x10]
    1860:      	and.16b	v18, v11, v15
    1864:      	ldr	q1, [sp, #0x20]
    1868:      	and.16b	v4, v12, v1
    186c:      	fmov	w14, s16
    1870:      	fmov	x10, d4
    1874:      	add	x11, x24, x10
    1878:      	ldp	q19, q1, [x11]
    187c:      	add	x11, x26, x10
    1880:      	ldp	q15, q23, [x11]
    1884:      	fmul.4s	v4, v19, v15
    1888:      	add	x11, x25, x10
    188c:      	ldp	q31, q24, [x11]
    1890:      	add	x10, x27, x10
    1894:      	ldp	q20, q25, [x10]
    1898:      	fmul.4s	v22, v31, v20
    189c:      	fsub.4s	v4, v4, v22
    18a0:      	and.16b	v4, v7, v4
    18a4:      	fmov	x10, d18
    18a8:      	add	x11, x30, x10, lsl #2
    18ac:      	tbnz	w14, #0x0, 0x24f4 <ltmp0+0x24f4>
    18b0:      	and	w14, w14, #0xff
    18b4:      	tbnz	w14, #0x1, 0x2500 <ltmp0+0x2500>
    18b8:      	tbnz	w14, #0x2, 0x250c <ltmp0+0x250c>
    18bc:      	tbnz	w14, #0x3, 0x2518 <ltmp0+0x2518>
    18c0:      	fmul.4s	v4, v1, v23
    18c4:      	fmul.4s	v18, v24, v25
    18c8:      	fsub.4s	v4, v4, v18
    18cc:      	and.16b	v4, v6, v4
    18d0:      	tbnz	w14, #0x4, 0x2534 <ltmp0+0x2534>
    18d4:      	tbnz	w14, #0x5, 0x253c <ltmp0+0x253c>
    18d8:      	tbnz	w14, #0x6, 0x2548 <ltmp0+0x2548>
    18dc:      	str	q25, [sp, #0x70]
    18e0:      	str	q24, [sp, #0x90]
    18e4:      	stp	q23, q1, [sp, #0xb0]
    18e8:      	str	q3, [sp, #0xf0]
    18ec:      	tbz	w14, #0x7, 0x18f8 <ltmp0+0x18f8>
    18f0:      	add	x10, x11, #0x1c
    18f4:      	st1.s	{ v4 }[3], [x10]
    18f8:      	mov.16b	v3, v2
    18fc:      	ldr	q1, [sp, #0x230]
    1900:      	and.16b	v24, v12, v1
    1904:      	sshll.2d	v4, v7, #0x0
    1908:      	ldr	q1, [sp, #0x10]
    190c:      	and.16b	v4, v4, v1
    1910:      	fmov	w14, s16
    1914:      	fmov	x10, d4
    1918:      	add	x11, x24, x10
    191c:      	ldp	q22, q1, [x11]
    1920:      	add	x11, x26, x10
    1924:      	ldp	q25, q29, [x11]
    1928:      	fmul.4s	v18, v22, v25
    192c:      	add	x11, x25, x10
    1930:      	ldp	q26, q23, [x11]
    1934:      	add	x10, x27, x10
    1938:      	ldp	q27, q4, [x10]
    193c:      	fmul.4s	v28, v26, v27
    1940:      	fsub.4s	v18, v18, v28
    1944:      	and.16b	v18, v7, v18
    1948:      	fmov	x10, d24
    194c:      	add	x11, x30, x10, lsl #2
    1950:      	tbnz	w14, #0x0, 0x2568 <ltmp0+0x2568>
    1954:      	and	w14, w14, #0xff
    1958:      	ldr	q2, [sp, #0x210]
    195c:      	tbnz	w14, #0x1, 0x2578 <ltmp0+0x2578>
    1960:      	tbnz	w14, #0x2, 0x2584 <ltmp0+0x2584>
    1964:      	tbnz	w14, #0x3, 0x2590 <ltmp0+0x2590>
    1968:      	fmul.4s	v18, v1, v29
    196c:      	fmul.4s	v24, v23, v4
    1970:      	fsub.4s	v18, v18, v24
    1974:      	and.16b	v18, v6, v18
    1978:      	tbnz	w14, #0x4, 0x25ac <ltmp0+0x25ac>
    197c:      	tbnz	w14, #0x5, 0x25b4 <ltmp0+0x25b4>
    1980:      	tbnz	w14, #0x6, 0x25c0 <ltmp0+0x25c0>
    1984:      	str	q29, [sp, #0x40]
    1988:      	str	q1, [sp, #0x230]
    198c:      	tbz	w14, #0x7, 0x1998 <ltmp0+0x1998>
    1990:      	add	x10, x11, #0x1c
    1994:      	st1.s	{ v18 }[3], [x10]
    1998:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    199c:      	ldr	q18, [x10]
    19a0:      	and.16b	v0, v0, v18
    19a4:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    19a8:      	ldr	q18, [x10]
    19ac:      	ldr	q1, [sp, #0x240]
    19b0:      	and.16b	v18, v1, v18
    19b4:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    19b8:      	ldr	q24, [x10]
    19bc:      	ldr	q1, [sp, #0x190]
    19c0:      	and.16b	v24, v1, v24
    19c4:      	ldr	q1, [sp, #0x160]
    19c8:      	add.2d	v10, v1, v10
    19cc:      	ldp	q29, q1, [sp, #0x140]
    19d0:      	ldr	q28, [sp, #0x130]
    19d4:      	add.2d	v1, v1, v28
    19d8:      	ldr	q28, [sp, #0x170]
    19dc:      	add.2d	v11, v28, v29
    19e0:      	add.2d	v2, v2, v9
    19e4:      	stp	q21, q18, [sp, #0x2f0]
    19e8:      	stp	q24, q0, [sp, #0x310]
    19ec:      	ubfiz	x10, x15, #3, #3
    19f0:      	add	x11, sp, #0x2f0
    19f4:      	ldr	x11, [x11, x10]
    19f8:      	orr	x11, x11, #0x80
    19fc:      	sub	x11, x11, x4
    1a00:      	tst	w17, #0xff
    1a04:      	csel	x11, xzr, x11, eq
    1a08:      	add	x14, x24, x11
    1a0c:      	ldp	q28, q0, [x14]
    1a10:      	add	x14, x26, x11
    1a14:      	ldp	q29, q18, [x14]
    1a18:      	fmul.4s	v9, v28, v29
    1a1c:      	add	x14, x25, x11
    1a20:      	ldp	q30, q21, [x14]
    1a24:      	add	x11, x27, x11
    1a28:      	ldp	q8, q24, [x11]
    1a2c:      	fmul.4s	v12, v30, v8
    1a30:      	fsub.4s	v9, v9, v12
    1a34:      	zip1.8b	v12, v17, v0
    1a38:      	ushll.4s	v12, v12, #0x0
    1a3c:      	shl.4s	v12, v12, #0x1f
    1a40:      	cmlt.4s	v12, v12, #0
    1a44:      	and.16b	v9, v12, v9
    1a48:      	ldr	d12, [sp, #0x250]
    1a4c:      	fmov	w11, s12
    1a50:      	stp	q2, q11, [sp, #0x2b0]
    1a54:      	stp	q1, q10, [sp, #0x2d0]
    1a58:      	add	x14, sp, #0x2b0
    1a5c:      	ldr	x10, [x14, x10]
    1a60:      	sub	x10, x10, x15
    1a64:      	add	x14, x30, x10, lsl #2
    1a68:      	tbnz	w11, #0x0, 0x25d8 <ltmp0+0x25d8>
    1a6c:      	tbnz	w11, #0x1, 0x25e0 <ltmp0+0x25e0>
    1a70:      	tbnz	w11, #0x2, 0x25ec <ltmp0+0x25ec>
    1a74:      	tbz	w11, #0x3, 0x1a80 <ltmp0+0x1a80>
    1a78:      	add	x10, x14, #0xc
    1a7c:      	st1.s	{ v9 }[3], [x10]
    1a80:      	fmul.4s	v1, v0, v18
    1a84:      	fmul.4s	v2, v21, v24
    1a88:      	fsub.4s	v1, v1, v2
    1a8c:      	zip2.8b	v2, v17, v0
    1a90:      	ushll.4s	v2, v2, #0x0
    1a94:      	shl.4s	v2, v2, #0x1f
    1a98:      	cmlt.4s	v2, v2, #0
    1a9c:      	and.16b	v9, v2, v1
    1aa0:      	tbnz	w11, #0x4, 0x25fc <ltmp0+0x25fc>
    1aa4:      	tbnz	w11, #0x5, 0x2604 <ltmp0+0x2604>
    1aa8:      	tbnz	w11, #0x6, 0x2610 <ltmp0+0x2610>
    1aac:      	tbz	w11, #0x7, 0x1ab8 <ltmp0+0x1ab8>
    1ab0:      	add	x10, x14, #0x1c
    1ab4:      	st1.s	{ v9 }[3], [x10]
    1ab8:      	sshll.2d	v1, v7, #0x0
    1abc:      	ldr	q2, [sp, #0x220]
    1ac0:      	and.16b	v2, v1, v2
    1ac4:      	fmov	w14, s16
    1ac8:      	ldr	q1, [sp, #0xa0]
    1acc:      	ldp	q9, q10, [sp, #0x50]
    1ad0:      	fmul.4s	v1, v1, v9
    1ad4:      	ldr	q9, [sp, #0x80]
    1ad8:      	fmul.4s	v9, v9, v10
    1adc:      	fadd.4s	v1, v9, v1
    1ae0:      	and.16b	v1, v7, v1
    1ae4:      	fmov	x10, d2
    1ae8:      	add	x11, x30, x10, lsl #2
    1aec:      	tbnz	w14, #0x0, 0x2620 <ltmp0+0x2620>
    1af0:      	and	w14, w14, #0xff
    1af4:      	tbnz	w14, #0x1, 0x262c <ltmp0+0x262c>
    1af8:      	tbnz	w14, #0x2, 0x2638 <ltmp0+0x2638>
    1afc:      	tbz	w14, #0x3, 0x1b08 <ltmp0+0x1b08>
    1b00:      	add	x10, x11, #0xc
    1b04:      	st1.s	{ v1 }[3], [x10]
    1b08:      	ldr	q1, [sp, #0x120]
    1b0c:      	ldr	q2, [sp, #0x100]
    1b10:      	fmul.4s	v1, v1, v2
    1b14:      	ldr	q2, [sp, #0x110]
    1b18:      	fmul.4s	v2, v3, v2
    1b1c:      	fadd.4s	v1, v2, v1
    1b20:      	and.16b	v1, v6, v1
    1b24:      	tbnz	w14, #0x4, 0x2648 <ltmp0+0x2648>
    1b28:      	tbnz	w14, #0x5, 0x2650 <ltmp0+0x2650>
    1b2c:      	tbnz	w14, #0x6, 0x265c <ltmp0+0x265c>
    1b30:      	tbz	w14, #0x7, 0x1b3c <ltmp0+0x1b3c>
    1b34:      	add	x10, x11, #0x1c
    1b38:      	st1.s	{ v1 }[3], [x10]
    1b3c:      	sshll.2d	v1, v7, #0x0
    1b40:      	ldr	q2, [sp, #0x200]
    1b44:      	and.16b	v2, v1, v2
    1b48:      	fmov	w14, s16
    1b4c:      	ldr	q1, [sp, #0x30]
    1b50:      	fmul.4s	v1, v1, v13
    1b54:      	fmul.4s	v3, v14, v5
    1b58:      	fadd.4s	v1, v3, v1
    1b5c:      	and.16b	v1, v7, v1
    1b60:      	fmov	x10, d2
    1b64:      	add	x11, x30, x10, lsl #2
    1b68:      	tbnz	w14, #0x0, 0x266c <ltmp0+0x266c>
    1b6c:      	and	w14, w14, #0xff
    1b70:      	ldr	d5, [sp, #0x250]
    1b74:      	ldr	q2, [sp, #0xf0]
    1b78:      	tbnz	w14, #0x1, 0x2680 <ltmp0+0x2680>
    1b7c:      	tbnz	w14, #0x2, 0x268c <ltmp0+0x268c>
    1b80:      	tbz	w14, #0x3, 0x1b8c <ltmp0+0x1b8c>
    1b84:      	add	x10, x11, #0xc
    1b88:      	st1.s	{ v1 }[3], [x10]
    1b8c:      	ldr	q1, [sp, #0x180]
    1b90:      	ldr	q3, [sp, #0xd0]
    1b94:      	fmul.4s	v1, v1, v3
    1b98:      	ldr	q3, [sp, #0xe0]
    1b9c:      	fmul.4s	v2, v2, v3
    1ba0:      	fadd.4s	v1, v2, v1
    1ba4:      	and.16b	v1, v6, v1
    1ba8:      	tbnz	w14, #0x4, 0x269c <ltmp0+0x269c>
    1bac:      	tbnz	w14, #0x5, 0x26a4 <ltmp0+0x26a4>
    1bb0:      	tbnz	w14, #0x6, 0x26b0 <ltmp0+0x26b0>
    1bb4:      	tbz	w14, #0x7, 0x1bc0 <ltmp0+0x1bc0>
    1bb8:      	add	x10, x11, #0x1c
    1bbc:      	st1.s	{ v1 }[3], [x10]
    1bc0:      	sshll.2d	v1, v7, #0x0
    1bc4:      	ldr	q2, [sp, #0x1f0]
    1bc8:      	and.16b	v2, v1, v2
    1bcc:      	fmov	w14, s16
    1bd0:      	fmul.4s	v1, v19, v20
    1bd4:      	fmul.4s	v3, v15, v31
    1bd8:      	fadd.4s	v1, v3, v1
    1bdc:      	and.16b	v1, v7, v1
    1be0:      	fmov	x10, d2
    1be4:      	add	x11, x30, x10, lsl #2
    1be8:      	tbnz	w14, #0x0, 0x26c0 <ltmp0+0x26c0>
    1bec:      	and	w14, w14, #0xff
    1bf0:      	tbnz	w14, #0x1, 0x26cc <ltmp0+0x26cc>
    1bf4:      	tbnz	w14, #0x2, 0x26d8 <ltmp0+0x26d8>
    1bf8:      	tbz	w14, #0x3, 0x1c04 <ltmp0+0x1c04>
    1bfc:      	add	x10, x11, #0xc
    1c00:      	st1.s	{ v1 }[3], [x10]
    1c04:      	ldr	q1, [sp, #0xc0]
    1c08:      	ldr	q2, [sp, #0x70]
    1c0c:      	fmul.4s	v1, v1, v2
    1c10:      	ldr	q2, [sp, #0xb0]
    1c14:      	ldr	q3, [sp, #0x90]
    1c18:      	fmul.4s	v2, v2, v3
    1c1c:      	fadd.4s	v1, v2, v1
    1c20:      	and.16b	v1, v6, v1
    1c24:      	tbnz	w14, #0x4, 0x26e8 <ltmp0+0x26e8>
    1c28:      	tbnz	w14, #0x5, 0x26f0 <ltmp0+0x26f0>
    1c2c:      	tbnz	w14, #0x6, 0x26fc <ltmp0+0x26fc>
    1c30:      	tbz	w14, #0x7, 0x1c3c <ltmp0+0x1c3c>
    1c34:      	add	x10, x11, #0x1c
    1c38:      	st1.s	{ v1 }[3], [x10]
    1c3c:      	sshll.2d	v1, v7, #0x0
    1c40:      	ldr	q2, [sp, #0x1e0]
    1c44:      	and.16b	v2, v1, v2
    1c48:      	fmov	w14, s16
    1c4c:      	fmul.4s	v1, v22, v27
    1c50:      	fmul.4s	v3, v25, v26
    1c54:      	fadd.4s	v1, v3, v1
    1c58:      	and.16b	v1, v7, v1
    1c5c:      	fmov	x10, d2
    1c60:      	add	x11, x30, x10, lsl #2
    1c64:      	tbnz	w14, #0x0, 0x270c <ltmp0+0x270c>
    1c68:      	and	w14, w14, #0xff
    1c6c:      	tbnz	w14, #0x1, 0x2718 <ltmp0+0x2718>
    1c70:      	tbnz	w14, #0x2, 0x2724 <ltmp0+0x2724>
    1c74:      	tbz	w14, #0x3, 0x1c80 <ltmp0+0x1c80>
    1c78:      	add	x10, x11, #0xc
    1c7c:      	st1.s	{ v1 }[3], [x10]
    1c80:      	ldr	q1, [sp, #0x230]
    1c84:      	fmul.4s	v1, v1, v4
    1c88:      	ldr	q2, [sp, #0x40]
    1c8c:      	fmul.4s	v2, v2, v23
    1c90:      	fadd.4s	v1, v2, v1
    1c94:      	and.16b	v1, v6, v1
    1c98:      	tbnz	w14, #0x4, 0x2734 <ltmp0+0x2734>
    1c9c:      	tbnz	w14, #0x5, 0x273c <ltmp0+0x273c>
    1ca0:      	tbnz	w14, #0x6, 0x2748 <ltmp0+0x2748>
    1ca4:      	tbz	w14, #0x7, 0x1cb0 <ltmp0+0x1cb0>
    1ca8:      	add	x10, x11, #0x1c
    1cac:      	st1.s	{ v1 }[3], [x10]
    1cb0:      	fmul.4s	v1, v28, v8
    1cb4:      	fmul.4s	v2, v29, v30
    1cb8:      	fadd.4s	v1, v2, v1
    1cbc:      	zip1.8b	v2, v17, v0
    1cc0:      	ushll.4s	v2, v2, #0x0
    1cc4:      	shl.4s	v2, v2, #0x1f
    1cc8:      	cmlt.4s	v2, v2, #0
    1ccc:      	and.16b	v1, v2, v1
    1cd0:      	fmov	w11, s5
    1cd4:      	ldp	q3, q2, [sp, #0x1a0]
    1cd8:      	stp	q3, q2, [sp, #0x260]
    1cdc:      	ldp	q3, q2, [sp, #0x1c0]
    1ce0:      	stp	q3, q2, [sp, #0x280]
    1ce4:      	and	x10, x15, #0x7
    1ce8:      	add	x14, sp, #0x260
    1cec:      	ldr	x10, [x14, x10, lsl #3]
    1cf0:      	sub	x10, x10, x15
    1cf4:      	add	x14, x30, x10, lsl #2
    1cf8:      	tbnz	w11, #0x0, 0x2758 <ltmp0+0x2758>
    1cfc:      	tbnz	w11, #0x1, 0x2760 <ltmp0+0x2760>
    1d00:      	tbnz	w11, #0x2, 0x276c <ltmp0+0x276c>
    1d04:      	tbz	w11, #0x3, 0x1d10 <ltmp0+0x1d10>
    1d08:      	add	x10, x14, #0xc
    1d0c:      	st1.s	{ v1 }[3], [x10]
    1d10:      	fmul.4s	v0, v0, v24
    1d14:      	fmul.4s	v1, v18, v21
    1d18:      	fadd.4s	v0, v1, v0
    1d1c:      	zip2.8b	v1, v17, v0
    1d20:      	ushll.4s	v1, v1, #0x0
    1d24:      	shl.4s	v1, v1, #0x1f
    1d28:      	cmlt.4s	v1, v1, #0
    1d2c:      	and.16b	v0, v1, v0
    1d30:      	tbnz	w11, #0x4, 0x277c <ltmp0+0x277c>
    1d34:      	tbnz	w11, #0x5, 0x2784 <ltmp0+0x2784>
    1d38:      	tbnz	w11, #0x6, 0x2790 <ltmp0+0x2790>
    1d3c:      	tbz	w11, #0x7, 0x998 <ltmp0+0x998>
    1d40:      	b	0x279c <ltmp0+0x279c>
    1d44:      	ldr	s0, [x15]
    1d48:      	and	w11, w11, #0xff
    1d4c:      	tbz	w11, #0x1, 0xcb8 <ltmp0+0xcb8>
    1d50:      	add	x10, x15, #0x4
    1d54:      	ld1.s	{ v0 }[1], [x10]
    1d58:      	tbz	w11, #0x2, 0xcbc <ltmp0+0xcbc>
    1d5c:      	add	x10, x15, #0x8
    1d60:      	ld1.s	{ v0 }[2], [x10]
    1d64:      	tbz	w11, #0x3, 0xcc0 <ltmp0+0xcc0>
    1d68:      	add	x10, x15, #0xc
    1d6c:      	ld1.s	{ v0 }[3], [x10]
    1d70:      	tbz	w11, #0x4, 0xcc4 <ltmp0+0xcc4>
    1d74:      	add	x10, x15, #0x10
    1d78:      	ld1.s	{ v2 }[0], [x10]
    1d7c:      	tbz	w11, #0x5, 0xcc8 <ltmp0+0xcc8>
    1d80:      	add	x10, x15, #0x14
    1d84:      	ld1.s	{ v2 }[1], [x10]
    1d88:      	tbz	w11, #0x6, 0xccc <ltmp0+0xccc>
    1d8c:      	add	x10, x15, #0x18
    1d90:      	ld1.s	{ v2 }[2], [x10]
    1d94:      	tbnz	w11, #0x7, 0xcd0 <ltmp0+0xcd0>
    1d98:      	b	0xcd8 <ltmp0+0xcd8>
    1d9c:      	ldr	s0, [x15]
    1da0:      	and	w11, w11, #0xff
    1da4:      	tbz	w11, #0x1, 0xd1c <ltmp0+0xd1c>
    1da8:      	add	x10, x15, #0x4
    1dac:      	ld1.s	{ v0 }[1], [x10]
    1db0:      	tbz	w11, #0x2, 0xd20 <ltmp0+0xd20>
    1db4:      	add	x10, x15, #0x8
    1db8:      	ld1.s	{ v0 }[2], [x10]
    1dbc:      	tbz	w11, #0x3, 0xd24 <ltmp0+0xd24>
    1dc0:      	add	x10, x15, #0xc
    1dc4:      	ld1.s	{ v0 }[3], [x10]
    1dc8:      	tbz	w11, #0x4, 0xd28 <ltmp0+0xd28>
    1dcc:      	add	x10, x15, #0x10
    1dd0:      	ld1.s	{ v2 }[0], [x10]
    1dd4:      	tbz	w11, #0x5, 0xd2c <ltmp0+0xd2c>
    1dd8:      	add	x10, x15, #0x14
    1ddc:      	ld1.s	{ v2 }[1], [x10]
    1de0:      	tbz	w11, #0x6, 0xd30 <ltmp0+0xd30>
    1de4:      	add	x10, x15, #0x18
    1de8:      	ld1.s	{ v2 }[2], [x10]
    1dec:      	tbnz	w11, #0x7, 0xd34 <ltmp0+0xd34>
    1df0:      	b	0xd3c <ltmp0+0xd3c>
    1df4:      	ldr	s0, [x15]
    1df8:      	and	w11, w11, #0xff
    1dfc:      	tbz	w11, #0x1, 0xd70 <ltmp0+0xd70>
    1e00:      	add	x10, x15, #0x4
    1e04:      	ld1.s	{ v0 }[1], [x10]
    1e08:      	tbz	w11, #0x2, 0xd74 <ltmp0+0xd74>
    1e0c:      	add	x10, x15, #0x8
    1e10:      	ld1.s	{ v0 }[2], [x10]
    1e14:      	tbz	w11, #0x3, 0xd78 <ltmp0+0xd78>
    1e18:      	add	x10, x15, #0xc
    1e1c:      	ld1.s	{ v0 }[3], [x10]
    1e20:      	tbz	w11, #0x4, 0xd7c <ltmp0+0xd7c>
    1e24:      	add	x10, x15, #0x10
    1e28:      	ld1.s	{ v4 }[0], [x10]
    1e2c:      	tbz	w11, #0x5, 0xd80 <ltmp0+0xd80>
    1e30:      	add	x10, x15, #0x14
    1e34:      	ld1.s	{ v4 }[1], [x10]
    1e38:      	tbz	w11, #0x6, 0xd84 <ltmp0+0xd84>
    1e3c:      	add	x10, x15, #0x18
    1e40:      	ld1.s	{ v4 }[2], [x10]
    1e44:      	tbnz	w11, #0x7, 0xd88 <ltmp0+0xd88>
    1e48:      	b	0xd90 <ltmp0+0xd90>
    1e4c:      	ldr	s4, [x15]
    1e50:      	and	w11, w11, #0xff
    1e54:      	tbz	w11, #0x1, 0xdc8 <ltmp0+0xdc8>
    1e58:      	add	x10, x15, #0x4
    1e5c:      	ld1.s	{ v4 }[1], [x10]
    1e60:      	tbz	w11, #0x2, 0xdcc <ltmp0+0xdcc>
    1e64:      	add	x10, x15, #0x8
    1e68:      	ld1.s	{ v4 }[2], [x10]
    1e6c:      	tbz	w11, #0x3, 0xdd0 <ltmp0+0xdd0>
    1e70:      	add	x10, x15, #0xc
    1e74:      	ld1.s	{ v4 }[3], [x10]
    1e78:      	tbz	w11, #0x4, 0xdd4 <ltmp0+0xdd4>
    1e7c:      	add	x10, x15, #0x10
    1e80:      	ld1.s	{ v5 }[0], [x10]
    1e84:      	tbz	w11, #0x5, 0xdd8 <ltmp0+0xdd8>
    1e88:      	add	x10, x15, #0x14
    1e8c:      	ld1.s	{ v5 }[1], [x10]
    1e90:      	tbz	w11, #0x6, 0xddc <ltmp0+0xddc>
    1e94:      	add	x10, x15, #0x18
    1e98:      	ld1.s	{ v5 }[2], [x10]
    1e9c:      	tbnz	w11, #0x7, 0xde0 <ltmp0+0xde0>
    1ea0:      	b	0xde8 <ltmp0+0xde8>
    1ea4:      	ldr	s19, [x4]
    1ea8:      	tbz	w17, #0x1, 0xe84 <ltmp0+0xe84>
    1eac:      	add	x10, x4, #0x4
    1eb0:      	ld1.s	{ v19 }[1], [x10]
    1eb4:      	tbz	w17, #0x2, 0xe88 <ltmp0+0xe88>
    1eb8:      	add	x10, x4, #0x8
    1ebc:      	ld1.s	{ v19 }[2], [x10]
    1ec0:      	tbz	w17, #0x3, 0xe8c <ltmp0+0xe8c>
    1ec4:      	add	x10, x4, #0xc
    1ec8:      	ld1.s	{ v19 }[3], [x10]
    1ecc:      	tbz	w17, #0x4, 0xe90 <ltmp0+0xe90>
    1ed0:      	add	x10, x4, #0x10
    1ed4:      	ld1.s	{ v20 }[0], [x10]
    1ed8:      	tbz	w17, #0x5, 0xe94 <ltmp0+0xe94>
    1edc:      	add	x10, x4, #0x14
    1ee0:      	ld1.s	{ v20 }[1], [x10]
    1ee4:      	tbz	w17, #0x6, 0xe98 <ltmp0+0xe98>
    1ee8:      	add	x10, x4, #0x18
    1eec:      	ld1.s	{ v20 }[2], [x10]
    1ef0:      	tbnz	w17, #0x7, 0xe9c <ltmp0+0xe9c>
    1ef4:      	b	0xea4 <ltmp0+0xea4>
    1ef8:      	ldr	s19, [x23]
    1efc:      	and	w11, w11, #0xff
    1f00:      	tbz	w11, #0x1, 0xf6c <ltmp0+0xf6c>
    1f04:      	add	x10, x23, #0x4
    1f08:      	ld1.s	{ v19 }[1], [x10]
    1f0c:      	tbz	w11, #0x2, 0xf70 <ltmp0+0xf70>
    1f10:      	add	x10, x23, #0x8
    1f14:      	ld1.s	{ v19 }[2], [x10]
    1f18:      	tbz	w11, #0x3, 0xf74 <ltmp0+0xf74>
    1f1c:      	add	x10, x23, #0xc
    1f20:      	ld1.s	{ v19 }[3], [x10]
    1f24:      	tbz	w11, #0x4, 0xf78 <ltmp0+0xf78>
    1f28:      	add	x10, x23, #0x10
    1f2c:      	ld1.s	{ v21 }[0], [x10]
    1f30:      	tbz	w11, #0x5, 0xf7c <ltmp0+0xf7c>
    1f34:      	add	x10, x23, #0x14
    1f38:      	ld1.s	{ v21 }[1], [x10]
    1f3c:      	tbz	w11, #0x6, 0xf80 <ltmp0+0xf80>
    1f40:      	add	x10, x23, #0x18
    1f44:      	ld1.s	{ v21 }[2], [x10]
    1f48:      	tbnz	w11, #0x7, 0xf84 <ltmp0+0xf84>
    1f4c:      	b	0xf8c <ltmp0+0xf8c>
    1f50:      	ldr	s3, [x23]
    1f54:      	and	w11, w11, #0xff
    1f58:      	tbz	w11, #0x1, 0xfc4 <ltmp0+0xfc4>
    1f5c:      	add	x10, x23, #0x4
    1f60:      	ld1.s	{ v3 }[1], [x10]
    1f64:      	tbz	w11, #0x2, 0xfc8 <ltmp0+0xfc8>
    1f68:      	add	x10, x23, #0x8
    1f6c:      	ld1.s	{ v3 }[2], [x10]
    1f70:      	tbz	w11, #0x3, 0xfcc <ltmp0+0xfcc>
    1f74:      	add	x10, x23, #0xc
    1f78:      	ld1.s	{ v3 }[3], [x10]
    1f7c:      	tbz	w11, #0x4, 0xfd0 <ltmp0+0xfd0>
    1f80:      	add	x10, x23, #0x10
    1f84:      	ld1.s	{ v21 }[0], [x10]
    1f88:      	tbz	w11, #0x5, 0xfd4 <ltmp0+0xfd4>
    1f8c:      	add	x10, x23, #0x14
    1f90:      	ld1.s	{ v21 }[1], [x10]
    1f94:      	tbz	w11, #0x6, 0xfd8 <ltmp0+0xfd8>
    1f98:      	add	x10, x23, #0x18
    1f9c:      	ld1.s	{ v21 }[2], [x10]
    1fa0:      	tbnz	w11, #0x7, 0xfdc <ltmp0+0xfdc>
    1fa4:      	b	0xfe4 <ltmp0+0xfe4>
    1fa8:      	ldr	s2, [x23]
    1fac:      	and	w11, w11, #0xff
    1fb0:      	tbz	w11, #0x1, 0x102c <ltmp0+0x102c>
    1fb4:      	add	x10, x23, #0x4
    1fb8:      	ld1.s	{ v2 }[1], [x10]
    1fbc:      	tbz	w11, #0x2, 0x1030 <ltmp0+0x1030>
    1fc0:      	add	x10, x23, #0x8
    1fc4:      	ld1.s	{ v2 }[2], [x10]
    1fc8:      	tbz	w11, #0x3, 0x1034 <ltmp0+0x1034>
    1fcc:      	add	x10, x23, #0xc
    1fd0:      	ld1.s	{ v2 }[3], [x10]
    1fd4:      	tbz	w11, #0x4, 0x1038 <ltmp0+0x1038>
    1fd8:      	add	x10, x23, #0x10
    1fdc:      	ld1.s	{ v3 }[0], [x10]
    1fe0:      	tbz	w11, #0x5, 0x103c <ltmp0+0x103c>
    1fe4:      	add	x10, x23, #0x14
    1fe8:      	ld1.s	{ v3 }[1], [x10]
    1fec:      	tbz	w11, #0x6, 0x1040 <ltmp0+0x1040>
    1ff0:      	add	x10, x23, #0x18
    1ff4:      	ld1.s	{ v3 }[2], [x10]
    1ff8:      	tbnz	w11, #0x7, 0x1044 <ltmp0+0x1044>
    1ffc:      	b	0x104c <ltmp0+0x104c>
    2000:      	ldr	s2, [x23]
    2004:      	and	w11, w11, #0xff
    2008:      	tbz	w11, #0x1, 0x1094 <ltmp0+0x1094>
    200c:      	add	x10, x23, #0x4
    2010:      	ld1.s	{ v2 }[1], [x10]
    2014:      	tbz	w11, #0x2, 0x1098 <ltmp0+0x1098>
    2018:      	add	x10, x23, #0x8
    201c:      	ld1.s	{ v2 }[2], [x10]
    2020:      	tbz	w11, #0x3, 0x109c <ltmp0+0x109c>
    2024:      	add	x10, x23, #0xc
    2028:      	ld1.s	{ v2 }[3], [x10]
    202c:      	tbz	w11, #0x4, 0x10a0 <ltmp0+0x10a0>
    2030:      	add	x10, x23, #0x10
    2034:      	ld1.s	{ v3 }[0], [x10]
    2038:      	tbz	w11, #0x5, 0x10a4 <ltmp0+0x10a4>
    203c:      	add	x10, x23, #0x14
    2040:      	ld1.s	{ v3 }[1], [x10]
    2044:      	tbz	w11, #0x6, 0x10a8 <ltmp0+0x10a8>
    2048:      	add	x10, x23, #0x18
    204c:      	ld1.s	{ v3 }[2], [x10]
    2050:      	tbnz	w11, #0x7, 0x10ac <ltmp0+0x10ac>
    2054:      	b	0x10b4 <ltmp0+0x10b4>
    2058:      	ldr	s1, [x20]
    205c:      	tbz	w23, #0x1, 0x1200 <ltmp0+0x1200>
    2060:      	add	x10, x20, #0x4
    2064:      	ld1.s	{ v1 }[1], [x10]
    2068:      	tbz	w23, #0x2, 0x1204 <ltmp0+0x1204>
    206c:      	add	x10, x20, #0x8
    2070:      	ld1.s	{ v1 }[2], [x10]
    2074:      	tbz	w23, #0x3, 0x1208 <ltmp0+0x1208>
    2078:      	add	x10, x20, #0xc
    207c:      	ld1.s	{ v1 }[3], [x10]
    2080:      	tbz	w23, #0x4, 0x120c <ltmp0+0x120c>
    2084:      	add	x10, x20, #0x10
    2088:      	ld1.s	{ v2 }[0], [x10]
    208c:      	tbz	w23, #0x5, 0x1210 <ltmp0+0x1210>
    2090:      	add	x10, x20, #0x14
    2094:      	ld1.s	{ v2 }[1], [x10]
    2098:      	tbz	w23, #0x6, 0x1214 <ltmp0+0x1214>
    209c:      	add	x10, x20, #0x18
    20a0:      	ld1.s	{ v2 }[2], [x10]
    20a4:      	str	q28, [sp, #0x210]
    20a8:      	tbnz	w23, #0x7, 0x121c <ltmp0+0x121c>
    20ac:      	b	0x1224 <ltmp0+0x1224>
    20b0:      	ldr	s1, [x20]
    20b4:      	and	w11, w11, #0xff
    20b8:      	tbz	w11, #0x1, 0x1294 <ltmp0+0x1294>
    20bc:      	add	x10, x20, #0x4
    20c0:      	ld1.s	{ v1 }[1], [x10]
    20c4:      	tbz	w11, #0x2, 0x1298 <ltmp0+0x1298>
    20c8:      	add	x10, x20, #0x8
    20cc:      	ld1.s	{ v1 }[2], [x10]
    20d0:      	tbz	w11, #0x3, 0x129c <ltmp0+0x129c>
    20d4:      	add	x10, x20, #0xc
    20d8:      	ld1.s	{ v1 }[3], [x10]
    20dc:      	tbz	w11, #0x4, 0x12a0 <ltmp0+0x12a0>
    20e0:      	add	x10, x20, #0x10
    20e4:      	ld1.s	{ v2 }[0], [x10]
    20e8:      	tbz	w11, #0x5, 0x12a4 <ltmp0+0x12a4>
    20ec:      	add	x10, x20, #0x14
    20f0:      	ld1.s	{ v2 }[1], [x10]
    20f4:      	tbz	w11, #0x6, 0x12a8 <ltmp0+0x12a8>
    20f8:      	add	x10, x20, #0x18
    20fc:      	ld1.s	{ v2 }[2], [x10]
    2100:      	tbnz	w11, #0x7, 0x12ac <ltmp0+0x12ac>
    2104:      	b	0x12b4 <ltmp0+0x12b4>
    2108:      	ldr	s1, [x20]
    210c:      	and	w11, w11, #0xff
    2110:      	tbz	w11, #0x1, 0x12f0 <ltmp0+0x12f0>
    2114:      	add	x10, x20, #0x4
    2118:      	ld1.s	{ v1 }[1], [x10]
    211c:      	tbz	w11, #0x2, 0x12f4 <ltmp0+0x12f4>
    2120:      	add	x10, x20, #0x8
    2124:      	ld1.s	{ v1 }[2], [x10]
    2128:      	tbz	w11, #0x3, 0x12f8 <ltmp0+0x12f8>
    212c:      	add	x10, x20, #0xc
    2130:      	ld1.s	{ v1 }[3], [x10]
    2134:      	tbz	w11, #0x4, 0x12fc <ltmp0+0x12fc>
    2138:      	add	x10, x20, #0x10
    213c:      	ld1.s	{ v2 }[0], [x10]
    2140:      	tbz	w11, #0x5, 0x1300 <ltmp0+0x1300>
    2144:      	add	x10, x20, #0x14
    2148:      	ld1.s	{ v2 }[1], [x10]
    214c:      	tbz	w11, #0x6, 0x1304 <ltmp0+0x1304>
    2150:      	add	x10, x20, #0x18
    2154:      	ld1.s	{ v2 }[2], [x10]
    2158:      	tbnz	w11, #0x7, 0x1308 <ltmp0+0x1308>
    215c:      	b	0x1310 <ltmp0+0x1310>
    2160:      	ldr	s1, [x20]
    2164:      	and	w11, w11, #0xff
    2168:      	tbz	w11, #0x1, 0x134c <ltmp0+0x134c>
    216c:      	add	x10, x20, #0x4
    2170:      	ld1.s	{ v1 }[1], [x10]
    2174:      	tbz	w11, #0x2, 0x1350 <ltmp0+0x1350>
    2178:      	add	x10, x20, #0x8
    217c:      	ld1.s	{ v1 }[2], [x10]
    2180:      	tbz	w11, #0x3, 0x1354 <ltmp0+0x1354>
    2184:      	add	x10, x20, #0xc
    2188:      	ld1.s	{ v1 }[3], [x10]
    218c:      	tbz	w11, #0x4, 0x1358 <ltmp0+0x1358>
    2190:      	add	x10, x20, #0x10
    2194:      	ld1.s	{ v2 }[0], [x10]
    2198:      	tbz	w11, #0x5, 0x135c <ltmp0+0x135c>
    219c:      	add	x10, x20, #0x14
    21a0:      	ld1.s	{ v2 }[1], [x10]
    21a4:      	tbz	w11, #0x6, 0x1360 <ltmp0+0x1360>
    21a8:      	add	x10, x20, #0x18
    21ac:      	ld1.s	{ v2 }[2], [x10]
    21b0:      	tbnz	w11, #0x7, 0x1364 <ltmp0+0x1364>
    21b4:      	b	0x136c <ltmp0+0x136c>
    21b8:      	ldr	s1, [x20]
    21bc:      	and	w11, w11, #0xff
    21c0:      	tbz	w11, #0x1, 0x13a8 <ltmp0+0x13a8>
    21c4:      	add	x10, x20, #0x4
    21c8:      	ld1.s	{ v1 }[1], [x10]
    21cc:      	tbz	w11, #0x2, 0x13ac <ltmp0+0x13ac>
    21d0:      	add	x10, x20, #0x8
    21d4:      	ld1.s	{ v1 }[2], [x10]
    21d8:      	tbz	w11, #0x3, 0x13b0 <ltmp0+0x13b0>
    21dc:      	add	x10, x20, #0xc
    21e0:      	ld1.s	{ v1 }[3], [x10]
    21e4:      	tbz	w11, #0x4, 0x13b4 <ltmp0+0x13b4>
    21e8:      	add	x10, x20, #0x10
    21ec:      	ld1.s	{ v2 }[0], [x10]
    21f0:      	tbz	w11, #0x5, 0x13b8 <ltmp0+0x13b8>
    21f4:      	add	x10, x20, #0x14
    21f8:      	ld1.s	{ v2 }[1], [x10]
    21fc:      	tbz	w11, #0x6, 0x13bc <ltmp0+0x13bc>
    2200:      	add	x10, x20, #0x18
    2204:      	ld1.s	{ v2 }[2], [x10]
    2208:      	tbnz	w11, #0x7, 0x13c0 <ltmp0+0x13c0>
    220c:      	b	0x13c8 <ltmp0+0x13c8>
    2210:      	ldr	s1, [x19]
    2214:      	tbz	w23, #0x1, 0x14e0 <ltmp0+0x14e0>
    2218:      	add	x10, x19, #0x4
    221c:      	ld1.s	{ v1 }[1], [x10]
    2220:      	tbz	w23, #0x2, 0x14e4 <ltmp0+0x14e4>
    2224:      	add	x10, x19, #0x8
    2228:      	ld1.s	{ v1 }[2], [x10]
    222c:      	tbz	w23, #0x3, 0x14e8 <ltmp0+0x14e8>
    2230:      	add	x10, x19, #0xc
    2234:      	ld1.s	{ v1 }[3], [x10]
    2238:      	tbz	w23, #0x4, 0x14ec <ltmp0+0x14ec>
    223c:      	add	x10, x19, #0x10
    2240:      	ld1.s	{ v2 }[0], [x10]
    2244:      	tbz	w23, #0x5, 0x14f0 <ltmp0+0x14f0>
    2248:      	add	x10, x19, #0x14
    224c:      	ld1.s	{ v2 }[1], [x10]
    2250:      	tbz	w23, #0x6, 0x14f4 <ltmp0+0x14f4>
    2254:      	add	x10, x19, #0x18
    2258:      	ld1.s	{ v2 }[2], [x10]
    225c:      	tbnz	w23, #0x7, 0x14f8 <ltmp0+0x14f8>
    2260:      	b	0x1500 <ltmp0+0x1500>
    2264:      	ldr	s1, [x19]
    2268:      	and	w11, w11, #0xff
    226c:      	tbz	w11, #0x1, 0x1558 <ltmp0+0x1558>
    2270:      	add	x10, x19, #0x4
    2274:      	ld1.s	{ v1 }[1], [x10]
    2278:      	tbz	w11, #0x2, 0x155c <ltmp0+0x155c>
    227c:      	add	x10, x19, #0x8
    2280:      	ld1.s	{ v1 }[2], [x10]
    2284:      	tbz	w11, #0x3, 0x1560 <ltmp0+0x1560>
    2288:      	add	x10, x19, #0xc
    228c:      	ld1.s	{ v1 }[3], [x10]
    2290:      	tbz	w11, #0x4, 0x1564 <ltmp0+0x1564>
    2294:      	add	x10, x19, #0x10
    2298:      	ld1.s	{ v2 }[0], [x10]
    229c:      	tbz	w11, #0x5, 0x1568 <ltmp0+0x1568>
    22a0:      	add	x10, x19, #0x14
    22a4:      	ld1.s	{ v2 }[1], [x10]
    22a8:      	tbz	w11, #0x6, 0x156c <ltmp0+0x156c>
    22ac:      	add	x10, x19, #0x18
    22b0:      	ld1.s	{ v2 }[2], [x10]
    22b4:      	tbnz	w11, #0x7, 0x1570 <ltmp0+0x1570>
    22b8:      	b	0x1578 <ltmp0+0x1578>
    22bc:      	ldr	s1, [x19]
    22c0:      	and	w11, w11, #0xff
    22c4:      	tbz	w11, #0x1, 0x15b8 <ltmp0+0x15b8>
    22c8:      	add	x10, x19, #0x4
    22cc:      	ld1.s	{ v1 }[1], [x10]
    22d0:      	tbz	w11, #0x2, 0x15bc <ltmp0+0x15bc>
    22d4:      	add	x10, x19, #0x8
    22d8:      	ld1.s	{ v1 }[2], [x10]
    22dc:      	tbz	w11, #0x3, 0x15c0 <ltmp0+0x15c0>
    22e0:      	add	x10, x19, #0xc
    22e4:      	ld1.s	{ v1 }[3], [x10]
    22e8:      	tbz	w11, #0x4, 0x15c4 <ltmp0+0x15c4>
    22ec:      	add	x10, x19, #0x10
    22f0:      	ld1.s	{ v2 }[0], [x10]
    22f4:      	tbz	w11, #0x5, 0x15c8 <ltmp0+0x15c8>
    22f8:      	add	x10, x19, #0x14
    22fc:      	ld1.s	{ v2 }[1], [x10]
    2300:      	tbz	w11, #0x6, 0x15cc <ltmp0+0x15cc>
    2304:      	add	x10, x19, #0x18
    2308:      	ld1.s	{ v2 }[2], [x10]
    230c:      	tbnz	w11, #0x7, 0x15d0 <ltmp0+0x15d0>
    2310:      	b	0x15d8 <ltmp0+0x15d8>
    2314:      	ldr	s1, [x19]
    2318:      	and	w11, w11, #0xff
    231c:      	tbz	w11, #0x1, 0x1618 <ltmp0+0x1618>
    2320:      	add	x10, x19, #0x4
    2324:      	ld1.s	{ v1 }[1], [x10]
    2328:      	tbz	w11, #0x2, 0x161c <ltmp0+0x161c>
    232c:      	add	x10, x19, #0x8
    2330:      	ld1.s	{ v1 }[2], [x10]
    2334:      	tbz	w11, #0x3, 0x1620 <ltmp0+0x1620>
    2338:      	add	x10, x19, #0xc
    233c:      	ld1.s	{ v1 }[3], [x10]
    2340:      	tbz	w11, #0x4, 0x1624 <ltmp0+0x1624>
    2344:      	add	x10, x19, #0x10
    2348:      	ld1.s	{ v2 }[0], [x10]
    234c:      	tbz	w11, #0x5, 0x1628 <ltmp0+0x1628>
    2350:      	add	x10, x19, #0x14
    2354:      	ld1.s	{ v2 }[1], [x10]
    2358:      	tbz	w11, #0x6, 0x162c <ltmp0+0x162c>
    235c:      	add	x10, x19, #0x18
    2360:      	ld1.s	{ v2 }[2], [x10]
    2364:      	tbnz	w11, #0x7, 0x1630 <ltmp0+0x1630>
    2368:      	b	0x1638 <ltmp0+0x1638>
    236c:      	ldr	s1, [x19]
    2370:      	and	w11, w11, #0xff
    2374:      	tbz	w11, #0x1, 0x1678 <ltmp0+0x1678>
    2378:      	add	x10, x19, #0x4
    237c:      	ld1.s	{ v1 }[1], [x10]
    2380:      	tbz	w11, #0x2, 0x167c <ltmp0+0x167c>
    2384:      	add	x10, x19, #0x8
    2388:      	ld1.s	{ v1 }[2], [x10]
    238c:      	tbz	w11, #0x3, 0x1680 <ltmp0+0x1680>
    2390:      	add	x10, x19, #0xc
    2394:      	ld1.s	{ v1 }[3], [x10]
    2398:      	tbz	w11, #0x4, 0x1684 <ltmp0+0x1684>
    239c:      	add	x10, x19, #0x10
    23a0:      	ld1.s	{ v2 }[0], [x10]
    23a4:      	tbz	w11, #0x5, 0x1688 <ltmp0+0x1688>
    23a8:      	add	x10, x19, #0x14
    23ac:      	ld1.s	{ v2 }[1], [x10]
    23b0:      	tbz	w11, #0x6, 0x168c <ltmp0+0x168c>
    23b4:      	add	x10, x19, #0x18
    23b8:      	ld1.s	{ v2 }[2], [x10]
    23bc:      	tbnz	w11, #0x7, 0x1690 <ltmp0+0x1690>
    23c0:      	b	0x1698 <ltmp0+0x1698>
    23c4:      	ldr	s1, [x1]
    23c8:      	tbz	w19, #0x1, 0x16c8 <ltmp0+0x16c8>
    23cc:      	add	x10, x1, #0x4
    23d0:      	ld1.s	{ v1 }[1], [x10]
    23d4:      	tbz	w19, #0x2, 0x16cc <ltmp0+0x16cc>
    23d8:      	add	x10, x1, #0x8
    23dc:      	ld1.s	{ v1 }[2], [x10]
    23e0:      	tbz	w19, #0x3, 0x16d0 <ltmp0+0x16d0>
    23e4:      	add	x10, x1, #0xc
    23e8:      	ld1.s	{ v1 }[3], [x10]
    23ec:      	tbz	w19, #0x4, 0x16d4 <ltmp0+0x16d4>
    23f0:      	add	x10, x1, #0x10
    23f4:      	ld1.s	{ v2 }[0], [x10]
    23f8:      	tbz	w19, #0x5, 0x16d8 <ltmp0+0x16d8>
    23fc:      	add	x10, x1, #0x14
    2400:      	ld1.s	{ v2 }[1], [x10]
    2404:      	tbz	w19, #0x6, 0x16dc <ltmp0+0x16dc>
    2408:      	add	x10, x1, #0x18
    240c:      	ld1.s	{ v2 }[2], [x10]
    2410:      	tbnz	w19, #0x7, 0x16e0 <ltmp0+0x16e0>
    2414:      	b	0x16e8 <ltmp0+0x16e8>
    2418:      	str	s3, [x11]
    241c:      	and	w14, w14, #0xff
    2420:      	tbz	w14, #0x1, 0x178c <ltmp0+0x178c>
    2424:      	add	x10, x11, #0x4
    2428:      	st1.s	{ v3 }[1], [x10]
    242c:      	tbz	w14, #0x2, 0x1790 <ltmp0+0x1790>
    2430:      	add	x10, x11, #0x8
    2434:      	st1.s	{ v3 }[2], [x10]
    2438:      	tbz	w14, #0x3, 0x1794 <ltmp0+0x1794>
    243c:      	add	x10, x11, #0xc
    2440:      	st1.s	{ v3 }[3], [x10]
    2444:      	fmul.4s	v3, v1, v2
    2448:      	fmul.4s	v4, v18, v19
    244c:      	fsub.4s	v3, v3, v4
    2450:      	and.16b	v3, v6, v3
    2454:      	tbz	w14, #0x4, 0x17a8 <ltmp0+0x17a8>
    2458:      	str	s3, [x11, #0x10]
    245c:      	tbz	w14, #0x5, 0x17ac <ltmp0+0x17ac>
    2460:      	add	x10, x11, #0x14
    2464:      	st1.s	{ v3 }[1], [x10]
    2468:      	tbz	w14, #0x6, 0x17b0 <ltmp0+0x17b0>
    246c:      	add	x10, x11, #0x18
    2470:      	st1.s	{ v3 }[2], [x10]
    2474:      	stp	q19, q18, [sp, #0x100]
    2478:      	str	q1, [sp, #0x120]
    247c:      	str	d14, [sp, #0x250]
    2480:      	tbnz	w14, #0x7, 0x17c0 <ltmp0+0x17c0>
    2484:      	b	0x17c8 <ltmp0+0x17c8>
    2488:      	str	s4, [x11]
    248c:      	and	w14, w14, #0xff
    2490:      	tbz	w14, #0x1, 0x1828 <ltmp0+0x1828>
    2494:      	add	x10, x11, #0x4
    2498:      	st1.s	{ v4 }[1], [x10]
    249c:      	tbz	w14, #0x2, 0x182c <ltmp0+0x182c>
    24a0:      	add	x10, x11, #0x8
    24a4:      	st1.s	{ v4 }[2], [x10]
    24a8:      	tbz	w14, #0x3, 0x1830 <ltmp0+0x1830>
    24ac:      	add	x10, x11, #0xc
    24b0:      	st1.s	{ v4 }[3], [x10]
    24b4:      	fmul.4s	v4, v1, v3
    24b8:      	fmul.4s	v18, v20, v22
    24bc:      	fsub.4s	v4, v4, v18
    24c0:      	and.16b	v4, v6, v4
    24c4:      	tbz	w14, #0x4, 0x1844 <ltmp0+0x1844>
    24c8:      	str	s4, [x11, #0x10]
    24cc:      	tbz	w14, #0x5, 0x1848 <ltmp0+0x1848>
    24d0:      	add	x10, x11, #0x14
    24d4:      	st1.s	{ v4 }[1], [x10]
    24d8:      	tbz	w14, #0x6, 0x184c <ltmp0+0x184c>
    24dc:      	add	x10, x11, #0x18
    24e0:      	st1.s	{ v4 }[2], [x10]
    24e4:      	stp	q22, q20, [sp, #0xd0]
    24e8:      	str	q1, [sp, #0x180]
    24ec:      	tbnz	w14, #0x7, 0x1858 <ltmp0+0x1858>
    24f0:      	b	0x1860 <ltmp0+0x1860>
    24f4:      	str	s4, [x11]
    24f8:      	and	w14, w14, #0xff
    24fc:      	tbz	w14, #0x1, 0x18b8 <ltmp0+0x18b8>
    2500:      	add	x10, x11, #0x4
    2504:      	st1.s	{ v4 }[1], [x10]
    2508:      	tbz	w14, #0x2, 0x18bc <ltmp0+0x18bc>
    250c:      	add	x10, x11, #0x8
    2510:      	st1.s	{ v4 }[2], [x10]
    2514:      	tbz	w14, #0x3, 0x18c0 <ltmp0+0x18c0>
    2518:      	add	x10, x11, #0xc
    251c:      	st1.s	{ v4 }[3], [x10]
    2520:      	fmul.4s	v4, v1, v23
    2524:      	fmul.4s	v18, v24, v25
    2528:      	fsub.4s	v4, v4, v18
    252c:      	and.16b	v4, v6, v4
    2530:      	tbz	w14, #0x4, 0x18d4 <ltmp0+0x18d4>
    2534:      	str	s4, [x11, #0x10]
    2538:      	tbz	w14, #0x5, 0x18d8 <ltmp0+0x18d8>
    253c:      	add	x10, x11, #0x14
    2540:      	st1.s	{ v4 }[1], [x10]
    2544:      	tbz	w14, #0x6, 0x18dc <ltmp0+0x18dc>
    2548:      	add	x10, x11, #0x18
    254c:      	st1.s	{ v4 }[2], [x10]
    2550:      	str	q25, [sp, #0x70]
    2554:      	str	q24, [sp, #0x90]
    2558:      	stp	q23, q1, [sp, #0xb0]
    255c:      	str	q3, [sp, #0xf0]
    2560:      	tbnz	w14, #0x7, 0x18f0 <ltmp0+0x18f0>
    2564:      	b	0x18f8 <ltmp0+0x18f8>
    2568:      	str	s18, [x11]
    256c:      	and	w14, w14, #0xff
    2570:      	ldr	q2, [sp, #0x210]
    2574:      	tbz	w14, #0x1, 0x1960 <ltmp0+0x1960>
    2578:      	add	x10, x11, #0x4
    257c:      	st1.s	{ v18 }[1], [x10]
    2580:      	tbz	w14, #0x2, 0x1964 <ltmp0+0x1964>
    2584:      	add	x10, x11, #0x8
    2588:      	st1.s	{ v18 }[2], [x10]
    258c:      	tbz	w14, #0x3, 0x1968 <ltmp0+0x1968>
    2590:      	add	x10, x11, #0xc
    2594:      	st1.s	{ v18 }[3], [x10]
    2598:      	fmul.4s	v18, v1, v29
    259c:      	fmul.4s	v24, v23, v4
    25a0:      	fsub.4s	v18, v18, v24
    25a4:      	and.16b	v18, v6, v18
    25a8:      	tbz	w14, #0x4, 0x197c <ltmp0+0x197c>
    25ac:      	str	s18, [x11, #0x10]
    25b0:      	tbz	w14, #0x5, 0x1980 <ltmp0+0x1980>
    25b4:      	add	x10, x11, #0x14
    25b8:      	st1.s	{ v18 }[1], [x10]
    25bc:      	tbz	w14, #0x6, 0x1984 <ltmp0+0x1984>
    25c0:      	add	x10, x11, #0x18
    25c4:      	st1.s	{ v18 }[2], [x10]
    25c8:      	str	q29, [sp, #0x40]
    25cc:      	str	q1, [sp, #0x230]
    25d0:      	tbnz	w14, #0x7, 0x1990 <ltmp0+0x1990>
    25d4:      	b	0x1998 <ltmp0+0x1998>
    25d8:      	str	s9, [x14]
    25dc:      	tbz	w11, #0x1, 0x1a70 <ltmp0+0x1a70>
    25e0:      	add	x10, x14, #0x4
    25e4:      	st1.s	{ v9 }[1], [x10]
    25e8:      	tbz	w11, #0x2, 0x1a74 <ltmp0+0x1a74>
    25ec:      	add	x10, x14, #0x8
    25f0:      	st1.s	{ v9 }[2], [x10]
    25f4:      	tbnz	w11, #0x3, 0x1a78 <ltmp0+0x1a78>
    25f8:      	b	0x1a80 <ltmp0+0x1a80>
    25fc:      	str	s9, [x14, #0x10]
    2600:      	tbz	w11, #0x5, 0x1aa8 <ltmp0+0x1aa8>
    2604:      	add	x10, x14, #0x14
    2608:      	st1.s	{ v9 }[1], [x10]
    260c:      	tbz	w11, #0x6, 0x1aac <ltmp0+0x1aac>
    2610:      	add	x10, x14, #0x18
    2614:      	st1.s	{ v9 }[2], [x10]
    2618:      	tbnz	w11, #0x7, 0x1ab0 <ltmp0+0x1ab0>
    261c:      	b	0x1ab8 <ltmp0+0x1ab8>
    2620:      	str	s1, [x11]
    2624:      	and	w14, w14, #0xff
    2628:      	tbz	w14, #0x1, 0x1af8 <ltmp0+0x1af8>
    262c:      	add	x10, x11, #0x4
    2630:      	st1.s	{ v1 }[1], [x10]
    2634:      	tbz	w14, #0x2, 0x1afc <ltmp0+0x1afc>
    2638:      	add	x10, x11, #0x8
    263c:      	st1.s	{ v1 }[2], [x10]
    2640:      	tbnz	w14, #0x3, 0x1b00 <ltmp0+0x1b00>
    2644:      	b	0x1b08 <ltmp0+0x1b08>
    2648:      	str	s1, [x11, #0x10]
    264c:      	tbz	w14, #0x5, 0x1b2c <ltmp0+0x1b2c>
    2650:      	add	x10, x11, #0x14
    2654:      	st1.s	{ v1 }[1], [x10]
    2658:      	tbz	w14, #0x6, 0x1b30 <ltmp0+0x1b30>
    265c:      	add	x10, x11, #0x18
    2660:      	st1.s	{ v1 }[2], [x10]
    2664:      	tbnz	w14, #0x7, 0x1b34 <ltmp0+0x1b34>
    2668:      	b	0x1b3c <ltmp0+0x1b3c>
    266c:      	str	s1, [x11]
    2670:      	and	w14, w14, #0xff
    2674:      	ldr	d5, [sp, #0x250]
    2678:      	ldr	q2, [sp, #0xf0]
    267c:      	tbz	w14, #0x1, 0x1b7c <ltmp0+0x1b7c>
    2680:      	add	x10, x11, #0x4
    2684:      	st1.s	{ v1 }[1], [x10]
    2688:      	tbz	w14, #0x2, 0x1b80 <ltmp0+0x1b80>
    268c:      	add	x10, x11, #0x8
    2690:      	st1.s	{ v1 }[2], [x10]
    2694:      	tbnz	w14, #0x3, 0x1b84 <ltmp0+0x1b84>
    2698:      	b	0x1b8c <ltmp0+0x1b8c>
    269c:      	str	s1, [x11, #0x10]
    26a0:      	tbz	w14, #0x5, 0x1bb0 <ltmp0+0x1bb0>
    26a4:      	add	x10, x11, #0x14
    26a8:      	st1.s	{ v1 }[1], [x10]
    26ac:      	tbz	w14, #0x6, 0x1bb4 <ltmp0+0x1bb4>
    26b0:      	add	x10, x11, #0x18
    26b4:      	st1.s	{ v1 }[2], [x10]
    26b8:      	tbnz	w14, #0x7, 0x1bb8 <ltmp0+0x1bb8>
    26bc:      	b	0x1bc0 <ltmp0+0x1bc0>
    26c0:      	str	s1, [x11]
    26c4:      	and	w14, w14, #0xff
    26c8:      	tbz	w14, #0x1, 0x1bf4 <ltmp0+0x1bf4>
    26cc:      	add	x10, x11, #0x4
    26d0:      	st1.s	{ v1 }[1], [x10]
    26d4:      	tbz	w14, #0x2, 0x1bf8 <ltmp0+0x1bf8>
    26d8:      	add	x10, x11, #0x8
    26dc:      	st1.s	{ v1 }[2], [x10]
    26e0:      	tbnz	w14, #0x3, 0x1bfc <ltmp0+0x1bfc>
    26e4:      	b	0x1c04 <ltmp0+0x1c04>
    26e8:      	str	s1, [x11, #0x10]
    26ec:      	tbz	w14, #0x5, 0x1c2c <ltmp0+0x1c2c>
    26f0:      	add	x10, x11, #0x14
    26f4:      	st1.s	{ v1 }[1], [x10]
    26f8:      	tbz	w14, #0x6, 0x1c30 <ltmp0+0x1c30>
    26fc:      	add	x10, x11, #0x18
    2700:      	st1.s	{ v1 }[2], [x10]
    2704:      	tbnz	w14, #0x7, 0x1c34 <ltmp0+0x1c34>
    2708:      	b	0x1c3c <ltmp0+0x1c3c>
    270c:      	str	s1, [x11]
    2710:      	and	w14, w14, #0xff
    2714:      	tbz	w14, #0x1, 0x1c70 <ltmp0+0x1c70>
    2718:      	add	x10, x11, #0x4
    271c:      	st1.s	{ v1 }[1], [x10]
    2720:      	tbz	w14, #0x2, 0x1c74 <ltmp0+0x1c74>
    2724:      	add	x10, x11, #0x8
    2728:      	st1.s	{ v1 }[2], [x10]
    272c:      	tbnz	w14, #0x3, 0x1c78 <ltmp0+0x1c78>
    2730:      	b	0x1c80 <ltmp0+0x1c80>
    2734:      	str	s1, [x11, #0x10]
    2738:      	tbz	w14, #0x5, 0x1ca0 <ltmp0+0x1ca0>
    273c:      	add	x10, x11, #0x14
    2740:      	st1.s	{ v1 }[1], [x10]
    2744:      	tbz	w14, #0x6, 0x1ca4 <ltmp0+0x1ca4>
    2748:      	add	x10, x11, #0x18
    274c:      	st1.s	{ v1 }[2], [x10]
    2750:      	tbnz	w14, #0x7, 0x1ca8 <ltmp0+0x1ca8>
    2754:      	b	0x1cb0 <ltmp0+0x1cb0>
    2758:      	str	s1, [x14]
    275c:      	tbz	w11, #0x1, 0x1d00 <ltmp0+0x1d00>
    2760:      	add	x10, x14, #0x4
    2764:      	st1.s	{ v1 }[1], [x10]
    2768:      	tbz	w11, #0x2, 0x1d04 <ltmp0+0x1d04>
    276c:      	add	x10, x14, #0x8
    2770:      	st1.s	{ v1 }[2], [x10]
    2774:      	tbnz	w11, #0x3, 0x1d08 <ltmp0+0x1d08>
    2778:      	b	0x1d10 <ltmp0+0x1d10>
    277c:      	str	s0, [x14, #0x10]
    2780:      	tbz	w11, #0x5, 0x1d38 <ltmp0+0x1d38>
    2784:      	add	x10, x14, #0x14
    2788:      	st1.s	{ v0 }[1], [x10]
    278c:      	tbz	w11, #0x6, 0x1d3c <ltmp0+0x1d3c>
    2790:      	add	x10, x14, #0x18
    2794:      	st1.s	{ v0 }[2], [x10]
    2798:      	tbz	w11, #0x7, 0x998 <ltmp0+0x998>
    279c:      	add	x10, x14, #0x1c
    27a0:      	st1.s	{ v0 }[3], [x10]
    27a4:      	b	0x998 <ltmp0+0x998>
    27a8:      	add	sp, sp, #0x700
    27ac:      	ldp	x29, x30, [sp, #0x90]
    27b0:      	ldp	x20, x19, [sp, #0x80]
    27b4:      	ldp	x22, x21, [sp, #0x70]
    27b8:      	ldp	x24, x23, [sp, #0x60]
    27bc:      	ldp	x26, x25, [sp, #0x50]
    27c0:      	ldp	x28, x27, [sp, #0x40]
    27c4:      	ldp	d9, d8, [sp, #0x30]
    27c8:      	ldp	d11, d10, [sp, #0x20]
    27cc:      	ldp	d13, d12, [sp, #0x10]
    27d0:      	ldp	d15, d14, [sp], #0xa0
    27d4:      	ret


/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/rope-17x66/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0x50
     6b4:      	stp	x22, x21, [sp, #0x20]
     6b8:      	stp	x20, x19, [sp, #0x30]
     6bc:      	stp	x29, x30, [sp, #0x40]
     6c0:      	add	x29, sp, #0x40
     6c4:      	mov	x8, #0x0                ; =0
     6c8:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     6cc:      	ldr	x9, [x9, #0x90]
     6d0:      	str	wzr, [sp]
     6d4:      	mov	x10, sp
     6d8:      	str	x10, [x9]
     6dc:      	add	x10, x2, #0x40
     6e0:      	add	x11, x1, #0x40
     6e4:      	mov	w12, #0x11              ; =17
     6e8:      	add	x15, x0, x8
     6ec:      	add	x14, x3, x8
     6f0:      	add	x13, x4, x8
     6f4:      	ldr	q0, [x15]
     6f8:      	ldur	q1, [x11, #-0x40]
     6fc:      	ldur	q2, [x15, #0x84]
     700:      	ldur	q3, [x10, #-0x40]
     704:      	fmul.4s	v4, v0, v1
     708:      	fmul.4s	v5, v2, v3
     70c:      	fsub.4s	v4, v4, v5
     710:      	fmul.4s	v0, v0, v3
     714:      	fmul.4s	v1, v1, v2
     718:      	fadd.4s	v0, v1, v0
     71c:      	str	q4, [x14]
     720:      	str	q0, [x13]
     724:      	ldr	q0, [x15, #0x10]
     728:      	ldur	q1, [x11, #-0x30]
     72c:      	ldur	q2, [x15, #0x94]
     730:      	ldur	q3, [x10, #-0x30]
     734:      	fmul.4s	v4, v0, v1
     738:      	fmul.4s	v5, v2, v3
     73c:      	fsub.4s	v4, v4, v5
     740:      	fmul.4s	v0, v0, v3
     744:      	fmul.4s	v1, v1, v2
     748:      	fadd.4s	v0, v1, v0
     74c:      	str	q4, [x14, #0x10]
     750:      	str	q0, [x13, #0x10]
     754:      	ldr	q0, [x15, #0x20]
     758:      	ldur	q1, [x11, #-0x20]
     75c:      	ldur	q2, [x15, #0xa4]
     760:      	ldur	q3, [x10, #-0x20]
     764:      	fmul.4s	v4, v0, v1
     768:      	fmul.4s	v5, v2, v3
     76c:      	fsub.4s	v4, v4, v5
     770:      	fmul.4s	v0, v0, v3
     774:      	fmul.4s	v1, v1, v2
     778:      	fadd.4s	v0, v1, v0
     77c:      	str	q4, [x14, #0x20]
     780:      	str	q0, [x13, #0x20]
     784:      	ldr	q0, [x15, #0x30]
     788:      	ldur	q1, [x11, #-0x10]
     78c:      	ldur	q2, [x15, #0xb4]
     790:      	ldur	q3, [x10, #-0x10]
     794:      	fmul.4s	v4, v0, v1
     798:      	fmul.4s	v5, v2, v3
     79c:      	fsub.4s	v4, v4, v5
     7a0:      	fmul.4s	v0, v0, v3
     7a4:      	fmul.4s	v1, v1, v2
     7a8:      	fadd.4s	v0, v1, v0
     7ac:      	str	q4, [x14, #0x30]
     7b0:      	str	q0, [x13, #0x30]
     7b4:      	ldr	q0, [x15, #0x40]
     7b8:      	ldr	q1, [x11]
     7bc:      	ldur	q2, [x15, #0xc4]
     7c0:      	ldr	q3, [x10]
     7c4:      	fmul.4s	v4, v0, v1
     7c8:      	fmul.4s	v5, v2, v3
     7cc:      	fsub.4s	v4, v4, v5
     7d0:      	fmul.4s	v0, v0, v3
     7d4:      	fmul.4s	v1, v1, v2
     7d8:      	fadd.4s	v0, v1, v0
     7dc:      	str	q4, [x14, #0x40]
     7e0:      	str	q0, [x13, #0x40]
     7e4:      	ldr	q0, [x15, #0x50]
     7e8:      	ldr	q1, [x11, #0x10]
     7ec:      	ldur	q2, [x15, #0xd4]
     7f0:      	ldr	q3, [x10, #0x10]
     7f4:      	fmul.4s	v4, v0, v1
     7f8:      	fmul.4s	v5, v2, v3
     7fc:      	fsub.4s	v4, v4, v5
     800:      	fmul.4s	v0, v0, v3
     804:      	fmul.4s	v1, v1, v2
     808:      	fadd.4s	v0, v1, v0
     80c:      	str	q4, [x14, #0x50]
     810:      	str	q0, [x13, #0x50]
     814:      	ldr	q0, [x15, #0x60]
     818:      	ldr	q1, [x11, #0x20]
     81c:      	ldur	q2, [x15, #0xe4]
     820:      	ldr	q3, [x10, #0x20]
     824:      	fmul.4s	v4, v0, v1
     828:      	fmul.4s	v5, v2, v3
     82c:      	fsub.4s	v4, v4, v5
     830:      	fmul.4s	v0, v0, v3
     834:      	fmul.4s	v1, v1, v2
     838:      	fadd.4s	v0, v1, v0
     83c:      	str	q4, [x14, #0x60]
     840:      	str	q0, [x13, #0x60]
     844:      	ldr	q0, [x15, #0x70]
     848:      	ldr	q1, [x11, #0x30]
     84c:      	ldur	q2, [x15, #0xf4]
     850:      	ldr	q3, [x10, #0x30]
     854:      	fmul.4s	v4, v0, v1
     858:      	fmul.4s	v5, v2, v3
     85c:      	fsub.4s	v4, v4, v5
     860:      	fmul.4s	v0, v0, v3
     864:      	fmul.4s	v1, v1, v2
     868:      	fadd.4s	v0, v1, v0
     86c:      	str	q4, [x14, #0x70]
     870:      	str	q0, [x13, #0x70]
     874:      	ldr	s0, [x15, #0x80]
     878:      	ldr	s1, [x11, #0x40]
     87c:      	ldr	s2, [x15, #0x104]
     880:      	ldr	s3, [x10, #0x40]
     884:      	fmul	s4, s0, s1
     888:      	fmul	s5, s2, s3
     88c:      	fsub	s4, s4, s5
     890:      	str	s4, [x14, #0x80]
     894:      	fmul	s0, s0, s3
     898:      	fmul	s1, s1, s2
     89c:      	fadd	s0, s1, s0
     8a0:      	str	s0, [x13, #0x80]
     8a4:      	add	x10, x10, #0x84
     8a8:      	add	x11, x11, #0x84
     8ac:      	add	x8, x8, #0x108
     8b0:      	subs	x12, x12, #0x1
     8b4:      	b.ne	0x6e8 <_kernel+0x38>
     8b8:      	str	xzr, [x9]
     8bc:      	mov	x8, sp
     8c0:      	ldapr	w8, [x8]
     8c4:      	cbnz	w8, 0x8dc <_kernel+0x22c>
     8c8:      	ldp	x29, x30, [sp, #0x40]
     8cc:      	ldp	x20, x19, [sp, #0x30]
     8d0:      	ldp	x22, x21, [sp, #0x20]
     8d4:      	add	sp, sp, #0x50
     8d8:      	ret
     8dc:      	mov	w0, #0x10               ; =16
     8e0:      	bl	0x17f0 <dyld_stub_binder+0x17f0>
     8e4:      	mov	x19, x0
     8e8:      	mov	w8, #0x33d              ; =829
     8ec:      	str	w8, [sp, #0x4]
     8f0:      	adrp	x0, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xc4>
     8f4:      	add	x0, x0, #0xb14
     8f8:      	adrp	x1, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xc4>
     8fc:      	add	x1, x1, #0xba0
     900:      	adrp	x3, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xc4>
     904:      	add	x3, x3, #0xbcb
     908:      	adrp	x4, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xc4>
     90c:      	add	x4, x4, #0xc49
     910:      	adrp	x2, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xc4>
     914:      	add	x2, x2, #0xbc8
     918:      	add	x8, sp, #0x8
     91c:      	add	x5, sp, #0x4
     920:      	adrp	x7, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xc4>
     924:      	add	x7, x7, #0xc4b
     928:      	mov	x6, x2
     92c:      	bl	0x9a0 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     930:      	mov	w21, #0x1               ; =1
     934:      	add	x1, sp, #0x8
     938:      	mov	x0, x19
     93c:      	bl	0x173c <dyld_stub_binder+0x173c>
     940:      	mov	w21, #0x0               ; =0
     944:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     948:      	ldr	x1, [x1, #0x18]
     94c:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     950:      	ldr	x2, [x2, #0x8]
     954:      	mov	x0, x19
     958:      	bl	0x1820 <dyld_stub_binder+0x1820>
     95c:      	brk	#0x1
     960:      	mov	x20, x0
     964:      	ldrsb	w8, [sp, #0x1f]
     968:      	tbz	w8, #0x1f, 0x984 <_kernel+0x2d4>
     96c:      	ldr	x0, [sp, #0x8]
     970:      	ldr	x8, [sp, #0x18]
     974:      	and	x1, x8, #0x7fffffffffffffff
     978:      	bl	0x17d8 <dyld_stub_binder+0x17d8>
     97c:      	tbnz	w21, #0x0, 0x990 <_kernel+0x2e0>
     980:      	b	0x998 <_kernel+0x2e8>
     984:      	cbnz	w21, 0x990 <_kernel+0x2e0>
     988:      	b	0x998 <_kernel+0x2e8>
     98c:      	mov	x20, x0
     990:      	mov	x0, x19
     994:      	bl	0x1814 <dyld_stub_binder+0x1814>
     998:      	mov	x0, x20
     99c:      	bl	0x1700 <dyld_stub_binder+0x1700>

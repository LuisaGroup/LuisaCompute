
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/masked_softmax-1024x4097-l1/object/tile_xir_w8_80763_1788919113439097_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x90
       4:      	stp	d15, d14, [sp, #0x50]
       8:      	stp	d13, d12, [sp, #0x60]
       c:      	stp	d11, d10, [sp, #0x70]
      10:      	stp	d9, d8, [sp, #0x80]
      14:      	mov	x13, #0x0               ; =0
      18:      	ldr	x10, [x1, #0x88]
      1c:      	add	x8, x10, #0xa8, lsl #12 ; =0xa8000
      20:      	add	x8, x8, #0x88
      24:      	add	x9, x10, #0x88, lsl #12 ; =0x88000
      28:      	add	x11, x9, #0x68
      2c:      	add	x9, x10, #0x68, lsl #12 ; =0x68000
      30:      	add	x12, x9, #0x68
      34:      	ldr	w9, [x1]
      38:      	ldr	w14, [x1, #0x24]
      3c:      	add	w14, w14, w9, lsl #5
      40:      	ldr	x15, [x0]
      44:      	ldr	x9, [x0, #0x30]
      48:      	dup.4s	v0, w14
      4c:      	adrp	x14, 0x0 <ltmp0>
      50:      	ldr	q1, [x14]
      54:      	add.4s	v17, v0, v1
      58:      	adrp	x14, 0x0 <ltmp0>
      5c:      	ldr	q1, [x14]
      60:      	add.4s	v18, v0, v1
      64:      	mov	w14, #0x1001            ; =4097
      68:      	dup.4s	v3, w14
      6c:      	umull2.2d	v0, v17, v3
      70:      	umull2.2d	v1, v18, v3
      74:      	umull.2d	v2, v17, v3
      78:      	umull.2d	v3, v18, v3
      7c:      	dup.2d	v4, x15
      80:      	dup.2d	v5, x13
      84:      	add.2d	v6, v5, v0
      88:      	add.2d	v7, v5, v2
      8c:      	add.2d	v16, v5, v1
      90:      	add.2d	v5, v5, v3
      94:      	shl.2d	v5, v5, #0x2
      98:      	shl.2d	v16, v16, #0x2
      9c:      	shl.2d	v7, v7, #0x2
      a0:      	shl.2d	v6, v6, #0x2
      a4:      	add.2d	v6, v4, v6
      a8:      	add.2d	v7, v4, v7
      ac:      	add.2d	v16, v4, v16
      b0:      	add.2d	v5, v4, v5
      b4:      	mov.d	x15, v5[1]
      b8:      	fmov	x16, d5
      bc:      	mov.d	x17, v16[1]
      c0:      	fmov	x0, d16
      c4:      	mov.d	x1, v7[1]
      c8:      	fmov	x2, d7
      cc:      	mov.d	x3, v6[1]
      d0:      	ldr	s5, [x16]
      d4:      	ld1.s	{ v5 }[1], [x15]
      d8:      	fmov	x15, d6
      dc:      	ld1.s	{ v5 }[2], [x0]
      e0:      	ld1.s	{ v5 }[3], [x17]
      e4:      	ldr	s6, [x2]
      e8:      	ld1.s	{ v6 }[1], [x1]
      ec:      	ld1.s	{ v6 }[2], [x15]
      f0:      	ld1.s	{ v6 }[3], [x3]
      f4:      	add	x15, x10, x13, lsl #5
      f8:      	stp	q5, q6, [x15]
      fc:      	add	x13, x13, #0x1
     100:      	cmp	x13, x14
     104:      	b.ne	0x80 <ltmp0+0x80>
     108:      	stp	q3, q2, [sp]
     10c:      	stp	q1, q0, [sp, #0x20]
     110:      	mov	x14, #0x0               ; =0
     114:      	add	x13, x10, #0x20, lsl #12 ; =0x20000
     118:      	add	x13, x13, #0x20
     11c:      	mov	w15, #0x1001            ; =4097
     120:      	dup.2d	v4, x14
     124:      	add	x16, x13, x14, lsl #6
     128:      	stp	q4, q4, [x16, #0x20]
     12c:      	stp	q4, q4, [x16]
     130:      	add	x14, x14, #0x1
     134:      	cmp	x14, x15
     138:      	b.ne	0x120 <ltmp0+0x120>
     13c:      	mov	x14, #0x0               ; =0
     140:      	mov	w15, #0xf001            ; =61441
     144:      	movk	w15, #0xff, lsl #16
     148:      	dup.4s	v19, w15
     14c:      	add	x15, x10, #0x60, lsl #12 ; =0x60000
     150:      	add	x15, x15, #0x60
     154:      	umull2.2d	v5, v18, v19
     158:      	umull.2d	v6, v18, v19
     15c:      	dup.2d	v4, x15
     160:      	uzp2.4s	v20, v6, v5
     164:      	adrp	x15, 0x0 <ltmp0>
     168:      	ldr	q5, [x15]
     16c:      	adrp	x15, 0x0 <ltmp0>
     170:      	ldr	q6, [x15]
     174:      	adrp	x15, 0x0 <ltmp0>
     178:      	ldr	q7, [x15]
     17c:      	adrp	x15, 0x0 <ltmp0>
     180:      	ldr	q16, [x15]
     184:      	mov	w15, #0x1001            ; =4097
     188:      	dup.4s	v21, w15
     18c:      	ushr.4s	v20, v20, #0x4
     190:      	mls.4s	v18, v20, v21
     194:      	umull2.2d	v20, v17, v19
     198:      	umull.2d	v19, v17, v19
     19c:      	uzp2.4s	v19, v19, v20
     1a0:      	ushr.4s	v19, v19, #0x4
     1a4:      	mls.4s	v17, v19, v21
     1a8:      	ushll2.2d	v19, v17, #0x0
     1ac:      	ushll2.2d	v20, v18, #0x0
     1b0:      	ushll.2d	v17, v17, #0x0
     1b4:      	ushll.2d	v18, v18, #0x0
     1b8:      	movi.8b	v21, #0x1
     1bc:      	dup.2d	v22, x14
     1c0:      	add	x16, x13, x14, lsl #6
     1c4:      	ldp	q24, q23, [x16, #0x20]
     1c8:      	ldp	q25, q26, [x16]
     1cc:      	add.2d	v22, v22, v4
     1d0:      	add.2d	v27, v22, v6
     1d4:      	add.2d	v28, v22, v5
     1d8:      	cmge.2d	v26, v20, v26
     1dc:      	cmge.2d	v25, v18, v25
     1e0:      	uzp1.4s	v25, v25, v26
     1e4:      	cmge.2d	v24, v17, v24
     1e8:      	cmge.2d	v23, v19, v23
     1ec:      	uzp1.4s	v23, v24, v23
     1f0:      	uzp1.8h	v23, v25, v23
     1f4:      	xtn.8b	v23, v23
     1f8:      	and.8b	v23, v23, v21
     1fc:      	mov.d	x16, v28[1]
     200:      	fmov	x17, d28
     204:      	str	b23, [x17]
     208:      	st1.b	{ v23 }[1], [x16]
     20c:      	mov.d	x16, v27[1]
     210:      	fmov	x17, d27
     214:      	st1.b	{ v23 }[2], [x17]
     218:      	st1.b	{ v23 }[3], [x16]
     21c:      	add.2d	v24, v22, v7
     220:      	mov.d	x16, v24[1]
     224:      	fmov	x17, d24
     228:      	st1.b	{ v23 }[4], [x17]
     22c:      	add.2d	v22, v22, v16
     230:      	st1.b	{ v23 }[5], [x16]
     234:      	mov.d	x16, v22[1]
     238:      	fmov	x17, d22
     23c:      	st1.b	{ v23 }[6], [x17]
     240:      	st1.b	{ v23 }[7], [x16]
     244:      	add	x14, x14, #0x1
     248:      	cmp	x14, x15
     24c:      	b.ne	0x1bc <ltmp0+0x1bc>
     250:      	mov	x13, #0x0               ; =0
     254:      	mov	w14, #0xf2ca            ; =62154
     258:      	movk	w14, #0xf149, lsl #16
     25c:      	dup.4s	v17, w14
     260:      	mov	w14, #0x1001            ; =4097
     264:      	dup.2d	v18, x13
     268:      	add.2d	v18, v18, v4
     26c:      	add.2d	v19, v18, v16
     270:      	add.2d	v20, v18, v5
     274:      	mov.d	x15, v20[1]
     278:      	add.2d	v21, v18, v7
     27c:      	add.2d	v18, v18, v6
     280:      	fmov	x16, d20
     284:      	mov.d	x17, v18[1]
     288:      	mov.d	x0, v21[1]
     28c:      	fmov	x1, d18
     290:      	ldr	b18, [x16]
     294:      	ld1.b	{ v18 }[1], [x15]
     298:      	mov.d	x15, v19[1]
     29c:      	fmov	x16, d21
     2a0:      	ld1.b	{ v18 }[2], [x1]
     2a4:      	ld1.b	{ v18 }[3], [x17]
     2a8:      	fmov	x17, d19
     2ac:      	ld1.b	{ v18 }[4], [x16]
     2b0:      	ld1.b	{ v18 }[5], [x0]
     2b4:      	ld1.b	{ v18 }[6], [x17]
     2b8:      	ld1.b	{ v18 }[7], [x15]
     2bc:      	cmeq.8b	v18, v18, #0
     2c0:      	sshll.8h	v18, v18, #0x0
     2c4:      	sshll2.4s	v19, v18, #0x0
     2c8:      	sshll.4s	v18, v18, #0x0
     2cc:      	lsl	x15, x13, #5
     2d0:      	add	x16, x10, x15
     2d4:      	ldp	q21, q20, [x16]
     2d8:      	bsl.16b	v18, v17, v21
     2dc:      	bsl.16b	v19, v17, v20
     2e0:      	add	x15, x12, x15
     2e4:      	stp	q18, q19, [x15]
     2e8:      	add	x13, x13, #0x1
     2ec:      	cmp	x13, x14
     2f0:      	b.ne	0x264 <ltmp0+0x264>
     2f4:      	mov	x13, #0x0               ; =0
     2f8:      	ldp	q22, q23, [x12]
     2fc:      	ldp	q18, q19, [x12, #0x20]
     300:      	ldp	q20, q17, [x12, #0x40]
     304:      	add	x14, x10, #0x68, lsl #12 ; =0x68000
     308:      	add	x14, x14, #0x128
     30c:      	ldp	q21, q24, [x12, #0x60]
     310:      	add	x15, x14, x13, lsl #5
     314:      	ldp	q25, q26, [x15, #-0x40]
     318:      	fmaxnm.4s	v23, v23, v26
     31c:      	fmaxnm.4s	v22, v22, v25
     320:      	ldp	q25, q26, [x15, #-0x20]
     324:      	fmaxnm.4s	v19, v19, v26
     328:      	fmaxnm.4s	v18, v18, v25
     32c:      	ldp	q25, q26, [x15]
     330:      	fmaxnm.4s	v17, v17, v26
     334:      	fmaxnm.4s	v20, v20, v25
     338:      	ldp	q25, q26, [x15, #0x20]
     33c:      	fmaxnm.4s	v24, v24, v26
     340:      	fmaxnm.4s	v21, v21, v25
     344:      	add	x13, x13, #0x4
     348:      	cmp	x13, #0xffc
     34c:      	b.lo	0x310 <ltmp0+0x310>
     350:      	mov	x14, #0x0               ; =0
     354:      	add	x13, x11, #0x20
     358:      	ldp	q25, q26, [x11]
     35c:      	fmaxnm.4s	v23, v23, v26
     360:      	fmaxnm.4s	v22, v22, v25
     364:      	mvni.4s	v9, #0x7f, msl #16
     368:      	fmaxnm.4s	v22, v22, v9
     36c:      	fmaxnm.4s	v23, v23, v9
     370:      	fmaxnm.4s	v19, v23, v19
     374:      	fmaxnm.4s	v18, v22, v18
     378:      	fmaxnm.4s	v22, v18, v20
     37c:      	fmaxnm.4s	v17, v19, v17
     380:      	fmaxnm.4s	v0, v17, v24
     384:      	str	q0, [sp, #0x40]
     388:      	mov	w15, #-0x3d300000       ; =-1026555904
     38c:      	dup.4s	v18, w15
     390:      	mov	w15, #0x42c80000        ; =1120403456
     394:      	dup.4s	v19, w15
     398:      	mov	w15, #0xaa3b            ; =43579
     39c:      	movk	w15, #0x3fb8, lsl #16
     3a0:      	dup.4s	v20, w15
     3a4:      	fmaxnm.4s	v21, v22, v21
     3a8:      	movi.4s	v22, #0x4b, lsl #24
     3ac:      	mvni.4s	v23, #0x80, lsl #24
     3b0:      	mov	w15, #0x7200            ; =29184
     3b4:      	movk	w15, #0xbf31, lsl #16
     3b8:      	dup.4s	v24, w15
     3bc:      	mov	w15, #0xbe8e            ; =48782
     3c0:      	movk	w15, #0xb5bf, lsl #16
     3c4:      	dup.4s	v25, w15
     3c8:      	mov	w15, #0x2bda            ; =11226
     3cc:      	movk	w15, #0x3950, lsl #16
     3d0:      	dup.4s	v26, w15
     3d4:      	mov	w15, #0x96c9            ; =38601
     3d8:      	movk	w15, #0x3ab6, lsl #16
     3dc:      	dup.4s	v27, w15
     3e0:      	mov	w15, #0x88a6            ; =34982
     3e4:      	movk	w15, #0x3c08, lsl #16
     3e8:      	dup.4s	v28, w15
     3ec:      	mov	w15, #0xaa7a            ; =43642
     3f0:      	movk	w15, #0x3d2a, lsl #16
     3f4:      	dup.4s	v29, w15
     3f8:      	mov	w15, #0xaaab            ; =43691
     3fc:      	movk	w15, #0x3e2a, lsl #16
     400:      	dup.4s	v30, w15
     404:      	movi.4s	v31, #0x3f, lsl #24
     408:      	fmov.4s	v8, #1.00000000
     40c:      	fneg.4s	v9, v9
     410:      	mvni.4s	v10, #0x3f, msl #16
     414:      	fneg.4s	v10, v10
     418:      	mov	w15, #0x1001            ; =4097
     41c:      	dup.2d	v11, x14
     420:      	add.2d	v13, v11, v4
     424:      	add.2d	v14, v13, v6
     428:      	add.2d	v11, v13, v5
     42c:      	mov.d	x16, v11[1]
     430:      	lsl	x17, x14, #5
     434:      	fmov	x0, d11
     438:      	add	x1, x12, x17
     43c:      	ldp	q11, q12, [x1]
     440:      	ldr	q0, [sp, #0x40]
     444:      	fsub.4s	v12, v12, v0
     448:      	mov.d	x1, v14[1]
     44c:      	fsub.4s	v11, v11, v21
     450:      	fcmge.4s	v15, v11, v18
     454:      	fcmge.4s	v0, v12, v18
     458:      	fcmge.4s	v1, v19, v11
     45c:      	fcmge.4s	v2, v19, v12
     460:      	and.16b	v0, v0, v2
     464:      	and.16b	v1, v15, v1
     468:      	and.16b	v1, v1, v11
     46c:      	and.16b	v0, v0, v12
     470:      	fmul.4s	v2, v0, v20
     474:      	fmul.4s	v15, v1, v20
     478:      	mov.16b	v3, v23
     47c:      	bsl.16b	v3, v22, v15
     480:      	mov.16b	v17, v23
     484:      	bsl.16b	v17, v22, v2
     488:      	fadd.4s	v2, v2, v17
     48c:      	fadd.4s	v15, v15, v3
     490:      	fsub.4s	v3, v15, v3
     494:      	fsub.4s	v2, v2, v17
     498:      	fmov	x5, d14
     49c:      	fcvtzs.4s	v2, v2
     4a0:      	fcvtzs.4s	v3, v3
     4a4:      	scvtf.4s	v17, v3
     4a8:      	scvtf.4s	v14, v2
     4ac:      	fmul.4s	v15, v17, v24
     4b0:      	fadd.4s	v1, v1, v15
     4b4:      	fmul.4s	v15, v14, v24
     4b8:      	fadd.4s	v0, v0, v15
     4bc:      	add.2d	v15, v13, v7
     4c0:      	mov.d	x3, v15[1]
     4c4:      	fmov	x4, d15
     4c8:      	add.2d	v13, v13, v16
     4cc:      	mov.d	x2, v13[1]
     4d0:      	fmul.4s	v17, v17, v25
     4d4:      	fmul.4s	v14, v14, v25
     4d8:      	fadd.4s	v0, v0, v14
     4dc:      	fadd.4s	v1, v1, v17
     4e0:      	fmul.4s	v17, v1, v26
     4e4:      	fmul.4s	v14, v0, v26
     4e8:      	fadd.4s	v14, v14, v27
     4ec:      	fadd.4s	v17, v17, v27
     4f0:      	fmul.4s	v17, v1, v17
     4f4:      	fmul.4s	v14, v0, v14
     4f8:      	fadd.4s	v14, v14, v28
     4fc:      	fadd.4s	v17, v17, v28
     500:      	fmul.4s	v17, v1, v17
     504:      	fmul.4s	v14, v0, v14
     508:      	fadd.4s	v14, v14, v29
     50c:      	fadd.4s	v17, v17, v29
     510:      	fmul.4s	v17, v1, v17
     514:      	fmul.4s	v14, v0, v14
     518:      	fadd.4s	v14, v14, v30
     51c:      	fadd.4s	v17, v17, v30
     520:      	fmov	x6, d13
     524:      	fmul.4s	v17, v1, v17
     528:      	fmul.4s	v13, v0, v14
     52c:      	fadd.4s	v13, v13, v31
     530:      	fadd.4s	v17, v17, v31
     534:      	fmul.4s	v14, v1, v1
     538:      	fmul.4s	v17, v14, v17
     53c:      	fmul.4s	v14, v0, v0
     540:      	fmul.4s	v13, v14, v13
     544:      	fadd.4s	v0, v0, v13
     548:      	fadd.4s	v1, v1, v17
     54c:      	sshr.4s	v17, v3, #0x1
     550:      	fadd.4s	v0, v0, v8
     554:      	sshr.4s	v13, v2, #0x1
     558:      	shl.4s	v14, v13, #0x17
     55c:      	add.4s	v14, v14, v8
     560:      	fmul.4s	v0, v0, v14
     564:      	shl.4s	v14, v17, #0x17
     568:      	fadd.4s	v1, v1, v8
     56c:      	add.4s	v14, v14, v8
     570:      	fmul.4s	v1, v1, v14
     574:      	sub.4s	v2, v2, v13
     578:      	sub.4s	v3, v3, v17
     57c:      	shl.4s	v3, v3, #0x17
     580:      	add.4s	v3, v3, v8
     584:      	fmul.4s	v1, v1, v3
     588:      	ldr	b3, [x0]
     58c:      	ld1.b	{ v3 }[1], [x16]
     590:      	ld1.b	{ v3 }[2], [x5]
     594:      	ld1.b	{ v3 }[3], [x1]
     598:      	shl.4s	v2, v2, #0x17
     59c:      	add.4s	v2, v2, v8
     5a0:      	fmul.4s	v0, v0, v2
     5a4:      	fcmgt.4s	v2, v18, v12
     5a8:      	bic.16b	v0, v0, v2
     5ac:      	fcmgt.4s	v2, v18, v11
     5b0:      	bic.16b	v1, v1, v2
     5b4:      	fcmgt.4s	v2, v11, v19
     5b8:      	bit.16b	v1, v9, v2
     5bc:      	fcmgt.4s	v2, v12, v19
     5c0:      	bit.16b	v0, v9, v2
     5c4:      	ld1.b	{ v3 }[4], [x4]
     5c8:      	ld1.b	{ v3 }[5], [x3]
     5cc:      	fcmeq.4s	v2, v12, v12
     5d0:      	bif.16b	v0, v10, v2
     5d4:      	ld1.b	{ v3 }[6], [x6]
     5d8:      	ld1.b	{ v3 }[7], [x2]
     5dc:      	cmeq.8b	v2, v3, #0
     5e0:      	sshll.8h	v2, v2, #0x0
     5e4:      	fcmeq.4s	v3, v11, v11
     5e8:      	bif.16b	v1, v10, v3
     5ec:      	sshll.4s	v3, v2, #0x0
     5f0:      	bic.16b	v1, v1, v3
     5f4:      	sshll2.4s	v2, v2, #0x0
     5f8:      	bic.16b	v0, v0, v2
     5fc:      	add	x16, x13, x17
     600:      	stp	q1, q0, [x16]
     604:      	add	x14, x14, #0x1
     608:      	cmp	x14, x15
     60c:      	b.ne	0x41c <ltmp0+0x41c>
     610:      	mov	x12, #0x0               ; =0
     614:      	ldp	q16, q17, [x11, #0x20]
     618:      	ldp	q5, q6, [x11, #0x40]
     61c:      	ldp	q7, q4, [x11, #0x60]
     620:      	add	x10, x10, #0x88, lsl #12 ; =0x88000
     624:      	add	x10, x10, #0x148
     628:      	ldp	q18, q19, [x11, #0x80]
     62c:      	add	x11, x10, x12, lsl #5
     630:      	ldp	q0, q1, [x11, #-0x40]
     634:      	fadd.4s	v17, v17, v1
     638:      	fadd.4s	v16, v16, v0
     63c:      	ldp	q0, q1, [x11, #-0x20]
     640:      	fadd.4s	v6, v6, v1
     644:      	fadd.4s	v5, v5, v0
     648:      	ldp	q0, q1, [x11]
     64c:      	fadd.4s	v4, v4, v1
     650:      	fadd.4s	v7, v7, v0
     654:      	ldp	q0, q1, [x11, #0x20]
     658:      	fadd.4s	v19, v19, v1
     65c:      	fadd.4s	v18, v18, v0
     660:      	add	x12, x12, #0x4
     664:      	cmp	x12, #0xffc
     668:      	b.lo	0x62c <ltmp0+0x62c>
     66c:      	mov	x10, #0x0               ; =0
     670:      	ldp	q0, q1, [x8]
     674:      	fadd.4s	v1, v17, v1
     678:      	fadd.4s	v0, v16, v0
     67c:      	movi.2d	v2, #0000000000000000
     680:      	fadd.4s	v0, v0, v2
     684:      	fadd.4s	v1, v1, v2
     688:      	fadd.4s	v1, v6, v1
     68c:      	fadd.4s	v0, v5, v0
     690:      	fadd.4s	v0, v7, v0
     694:      	fadd.4s	v1, v4, v1
     698:      	fadd.4s	v4, v19, v1
     69c:      	fadd.4s	v5, v18, v0
     6a0:      	dup.2d	v6, x9
     6a4:      	mov	w8, #0x1001             ; =4097
     6a8:      	ldp	q18, q17, [sp, #0x20]
     6ac:      	ldp	q20, q19, [sp]
     6b0:      	dup.2d	v0, x10
     6b4:      	add.2d	v1, v0, v17
     6b8:      	add.2d	v2, v0, v19
     6bc:      	add.2d	v3, v0, v18
     6c0:      	add.2d	v0, v0, v20
     6c4:      	add	x9, x13, x10, lsl #5
     6c8:      	ldp	q7, q16, [x9]
     6cc:      	fdiv.4s	v16, v16, v4
     6d0:      	fdiv.4s	v7, v7, v5
     6d4:      	shl.2d	v0, v0, #0x2
     6d8:      	shl.2d	v3, v3, #0x2
     6dc:      	shl.2d	v2, v2, #0x2
     6e0:      	shl.2d	v1, v1, #0x2
     6e4:      	add.2d	v1, v6, v1
     6e8:      	add.2d	v0, v6, v0
     6ec:      	mov.d	x9, v0[1]
     6f0:      	fmov	x11, d0
     6f4:      	str	s7, [x11]
     6f8:      	st1.s	{ v7 }[1], [x9]
     6fc:      	add.2d	v0, v6, v3
     700:      	mov.d	x9, v0[1]
     704:      	fmov	x11, d0
     708:      	st1.s	{ v7 }[2], [x11]
     70c:      	add.2d	v0, v6, v2
     710:      	st1.s	{ v7 }[3], [x9]
     714:      	mov.d	x9, v0[1]
     718:      	fmov	x11, d0
     71c:      	str	s16, [x11]
     720:      	st1.s	{ v16 }[1], [x9]
     724:      	mov.d	x9, v1[1]
     728:      	fmov	x11, d1
     72c:      	st1.s	{ v16 }[2], [x11]
     730:      	st1.s	{ v16 }[3], [x9]
     734:      	add	x10, x10, #0x1
     738:      	cmp	x10, x8
     73c:      	b.ne	0x6b0 <ltmp0+0x6b0>
     740:      	ldp	d9, d8, [sp, #0x80]
     744:      	ldp	d11, d10, [sp, #0x70]
     748:      	ldp	d13, d12, [sp, #0x60]
     74c:      	ldp	d15, d14, [sp, #0x50]
     750:      	add	sp, sp, #0x90
     754:      	ret

0000000000000758 <_llm_rows.packet_batch.blocks>:
     758:      	sub	sp, sp, #0x130
     75c:      	stp	d15, d14, [sp, #0x90]
     760:      	stp	d13, d12, [sp, #0xa0]
     764:      	stp	d11, d10, [sp, #0xb0]
     768:      	stp	d9, d8, [sp, #0xc0]
     76c:      	stp	x28, x27, [sp, #0xd0]
     770:      	stp	x26, x25, [sp, #0xe0]
     774:      	stp	x24, x23, [sp, #0xf0]
     778:      	stp	x22, x21, [sp, #0x100]
     77c:      	stp	x20, x19, [sp, #0x110]
     780:      	stp	x29, x30, [sp, #0x120]
     784:      	str	x0, [sp, #0x68]
     788:      	cbz	w3, 0x14c0 <_llm_rows.packet_batch.blocks+0xd68>
     78c:      	mov	x21, x3
     790:      	mov	x20, x2
     794:      	mov	w22, #0x0               ; =0
     798:      	ldp	w9, w8, [x2, #0x2c]
     79c:      	stp	w8, w9, [sp, #0x60]
     7a0:      	ldp	w27, w26, [x2]
     7a4:      	ldp	w25, w28, [x2, #0x8]
     7a8:      	mov	w23, #0x1001            ; =4097
     7ac:      	adrp	x8, 0x0 <ltmp0>
     7b0:      	ldr	q0, [x8]
     7b4:      	str	q0, [sp, #0x50]
     7b8:      	adrp	x8, 0x0 <ltmp0>
     7bc:      	ldr	q0, [x8]
     7c0:      	str	q0, [sp, #0x40]
     7c4:      	dup.4s	v0, w23
     7c8:      	str	q0, [sp, #0x20]
     7cc:      	adrp	x8, 0x0 <ltmp0>
     7d0:      	ldr	q0, [x8]
     7d4:      	str	q0, [sp, #0x10]
     7d8:      	movi.8b	v8, #0x1
     7dc:      	mvni.4s	v13, #0x7f, msl #16
     7e0:      	movi.4s	v14, #0x4b, lsl #24
     7e4:      	mvni.4s	v15, #0x80, lsl #24
     7e8:      	mvni.4s	v0, #0x3f, msl #16
     7ec:      	fneg.4s	v0, v0
     7f0:      	str	q0, [sp, #0x70]
     7f4:      	mov	w30, #0xaa7a            ; =43642
     7f8:      	movk	w30, #0x3d2a, lsl #16
     7fc:      	mov	w19, #0xaaab            ; =43691
     800:      	movk	w19, #0x3e2a, lsl #16
     804:      	str	w3, [sp, #0x3c]
     808:      	b	0x850 <_llm_rows.packet_batch.blocks+0xf8>
     80c:      	mov	w8, #0x18               ; =24
     810:      	str	w8, [x20, #0x24]
     814:      	ldr	w21, [sp, #0x3c]
     818:      	add	w8, w27, #0x1
     81c:      	ldp	w10, w9, [sp, #0x60]
     820:      	cmp	w8, w9
     824:      	cset	w8, eq
     828:      	csinc	w27, wzr, w27, eq
     82c:      	cinc	w9, w26, eq
     830:      	cmp	w9, w10
     834:      	cset	w10, eq
     838:      	ands	w8, w8, w10
     83c:      	csel	w26, wzr, w9, ne
     840:      	add	w25, w25, w8
     844:      	add	w22, w22, #0x1
     848:      	cmp	w22, w21
     84c:      	b.eq	0x14c0 <_llm_rows.packet_batch.blocks+0xd68>
     850:      	ubfiz	x8, x27, #5, #32
     854:      	cmp	x8, x28
     858:      	csel	x9, x8, xzr, ls
     85c:      	subs	x10, x28, x9
     860:      	cmp	x10, #0x20
     864:      	mov	w11, #0x20              ; =32
     868:      	csel	x10, x10, x11, lo
     86c:      	cmp	x28, x9
     870:      	stp	w27, w26, [x20]
     874:      	str	w25, [x20, #0x8]
     878:      	str	wzr, [x20, #0x24]
     87c:      	ccmp	x8, x28, #0x2, hi
     880:      	csel	x24, x10, xzr, ls
     884:      	cmp	x24, #0x20
     888:      	b.lo	0x8f0 <_llm_rows.packet_batch.blocks+0x198>
     88c:      	ldr	x24, [sp, #0x68]
     890:      	mov	x0, x24
     894:      	mov	x1, x20
     898:      	bl	0x898 <_llm_rows.packet_batch.blocks+0x140>
     89c:      	mov	w8, #0x8                ; =8
     8a0:      	str	w8, [x20, #0x24]
     8a4:      	mov	x0, x24
     8a8:      	mov	x1, x20
     8ac:      	bl	0x8ac <_llm_rows.packet_batch.blocks+0x154>
     8b0:      	mov	w8, #0x10               ; =16
     8b4:      	str	w8, [x20, #0x24]
     8b8:      	mov	x0, x24
     8bc:      	mov	x1, x20
     8c0:      	bl	0x8c0 <_llm_rows.packet_batch.blocks+0x168>
     8c4:      	mov	w8, #0x18               ; =24
     8c8:      	str	w8, [x20, #0x24]
     8cc:      	mov	x0, x24
     8d0:      	mov	x1, x20
     8d4:      	bl	0x8d4 <_llm_rows.packet_batch.blocks+0x17c>
     8d8:      	mov	w30, #0xaa7a            ; =43642
     8dc:      	movk	w30, #0x3d2a, lsl #16
     8e0:      	mvni.4s	v15, #0x80, lsl #24
     8e4:      	movi.4s	v14, #0x4b, lsl #24
     8e8:      	mvni.4s	v13, #0x7f, msl #16
     8ec:      	b	0x818 <_llm_rows.packet_batch.blocks+0xc0>
     8f0:      	lsr	x21, x24, #3
     8f4:      	cmp	x24, #0x8
     8f8:      	b.lo	0x980 <_llm_rows.packet_batch.blocks+0x228>
     8fc:      	str	wzr, [x20, #0x24]
     900:      	ldr	x0, [sp, #0x68]
     904:      	mov	x1, x20
     908:      	bl	0x908 <_llm_rows.packet_batch.blocks+0x1b0>
     90c:      	mov	w30, #0xaa7a            ; =43642
     910:      	movk	w30, #0x3d2a, lsl #16
     914:      	mvni.4s	v15, #0x80, lsl #24
     918:      	movi.4s	v14, #0x4b, lsl #24
     91c:      	mvni.4s	v13, #0x7f, msl #16
     920:      	cmp	x21, #0x1
     924:      	b.eq	0x980 <_llm_rows.packet_batch.blocks+0x228>
     928:      	mov	w8, #0x8                ; =8
     92c:      	str	w8, [x20, #0x24]
     930:      	ldr	x0, [sp, #0x68]
     934:      	mov	x1, x20
     938:      	bl	0x938 <_llm_rows.packet_batch.blocks+0x1e0>
     93c:      	mov	w30, #0xaa7a            ; =43642
     940:      	movk	w30, #0x3d2a, lsl #16
     944:      	mvni.4s	v15, #0x80, lsl #24
     948:      	movi.4s	v14, #0x4b, lsl #24
     94c:      	mvni.4s	v13, #0x7f, msl #16
     950:      	cmp	x21, #0x2
     954:      	b.eq	0x980 <_llm_rows.packet_batch.blocks+0x228>
     958:      	mov	w8, #0x10               ; =16
     95c:      	str	w8, [x20, #0x24]
     960:      	ldr	x0, [sp, #0x68]
     964:      	mov	x1, x20
     968:      	bl	0x968 <_llm_rows.packet_batch.blocks+0x210>
     96c:      	mov	w30, #0xaa7a            ; =43642
     970:      	movk	w30, #0x3d2a, lsl #16
     974:      	mvni.4s	v15, #0x80, lsl #24
     978:      	movi.4s	v14, #0x4b, lsl #24
     97c:      	mvni.4s	v13, #0x7f, msl #16
     980:      	and	w8, w24, #0x7
     984:      	cbz	w8, 0x80c <_llm_rows.packet_batch.blocks+0xb4>
     988:      	dup.4s	v7, w8
     98c:      	ldp	q0, q1, [sp, #0x40]
     990:      	cmhi.4s	v0, v7, v0
     994:      	cmhi.4s	v1, v7, v1
     998:      	uzp1.8h	v6, v1, v0
     99c:      	umaxv.8h	h2, v6
     9a0:      	fmov	w8, s2
     9a4:      	tbz	w8, #0x0, 0x80c <_llm_rows.packet_batch.blocks+0xb4>
     9a8:      	mov	x15, #0x0               ; =0
     9ac:      	ldr	x11, [x20, #0x88]
     9b0:      	mov	w8, #0x8088             ; =32904
     9b4:      	movk	w8, #0xa, lsl #16
     9b8:      	add	x10, x11, x8
     9bc:      	mov	w8, #0x8068             ; =32872
     9c0:      	movk	w8, #0x8, lsl #16
     9c4:      	add	x12, x11, x8
     9c8:      	mov	w8, #0x8068             ; =32872
     9cc:      	movk	w8, #0x6, lsl #16
     9d0:      	add	x13, x11, x8
     9d4:      	mov	w8, #0x20               ; =32
     9d8:      	movk	w8, #0x2, lsl #16
     9dc:      	add	x14, x11, x8
     9e0:      	mov	w8, #0x60               ; =96
     9e4:      	movk	w8, #0x6, lsl #16
     9e8:      	add	x8, x11, x8
     9ec:      	dup.2d	v16, x8
     9f0:      	mov	w8, #0x8088             ; =32904
     9f4:      	movk	w8, #0x8, lsl #16
     9f8:      	add	x8, x11, x8
     9fc:      	ldr	x17, [sp, #0x68]
     a00:      	ldr	x16, [x17]
     a04:      	lsl	w9, w21, #3
     a08:      	orr	w9, w9, w27, lsl #5
     a0c:      	dup.4s	v2, w9
     a10:      	ldr	x9, [x17, #0x30]
     a14:      	ldp	q4, q3, [sp, #0x40]
     a18:      	orr.16b	v3, v2, v3
     a1c:      	orr.16b	v2, v2, v4
     a20:      	and.16b	v17, v0, v2
     a24:      	and.16b	v18, v1, v3
     a28:      	ldp	q19, q5, [sp, #0x10]
     a2c:      	umull2.2d	v2, v17, v5
     a30:      	umull2.2d	v3, v18, v5
     a34:      	umull.2d	v4, v17, v5
     a38:      	umull.2d	v5, v18, v5
     a3c:      	and.16b	v6, v6, v19
     a40:      	addv.8h	h6, v6
     a44:      	dup.2d	v19, x16
     a48:      	fmov	w16, s6
     a4c:      	mov	w7, #0xf2ca             ; =62154
     a50:      	movk	w7, #0xf149, lsl #16
     a54:      	b	0xa78 <_llm_rows.packet_batch.blocks+0x320>
     a58:      	add	x17, x11, x15, lsl #5
     a5c:      	ldp	q22, q23, [x17]
     a60:      	bif.16b	v21, v23, v0
     a64:      	bif.16b	v20, v22, v1
     a68:      	stp	q20, q21, [x17]
     a6c:      	add	x15, x15, #0x1
     a70:      	cmp	x15, x23
     a74:      	b.eq	0xb64 <_llm_rows.packet_batch.blocks+0x40c>
     a78:      	dup.2d	v22, x15
     a7c:      	add.2d	v20, v22, v5
     a80:      	shl.2d	v20, v20, #0x2
     a84:      	add.2d	v23, v19, v20
     a88:      	movi.2d	v20, #0000000000000000
     a8c:      	movi.2d	v21, #0000000000000000
     a90:      	tbnz	w16, #0x0, 0xadc <_llm_rows.packet_batch.blocks+0x384>
     a94:      	and	w17, w16, #0xff
     a98:      	tbnz	w17, #0x1, 0xaec <_llm_rows.packet_batch.blocks+0x394>
     a9c:      	add.2d	v23, v22, v3
     aa0:      	shl.2d	v23, v23, #0x2
     aa4:      	add.2d	v23, v19, v23
     aa8:      	tbnz	w17, #0x2, 0xb04 <_llm_rows.packet_batch.blocks+0x3ac>
     aac:      	tbnz	w17, #0x3, 0xb10 <_llm_rows.packet_batch.blocks+0x3b8>
     ab0:      	add.2d	v23, v22, v4
     ab4:      	shl.2d	v23, v23, #0x2
     ab8:      	add.2d	v23, v19, v23
     abc:      	tbnz	w17, #0x4, 0xb28 <_llm_rows.packet_batch.blocks+0x3d0>
     ac0:      	tbnz	w17, #0x5, 0xb34 <_llm_rows.packet_batch.blocks+0x3dc>
     ac4:      	add.2d	v22, v22, v2
     ac8:      	shl.2d	v22, v22, #0x2
     acc:      	add.2d	v22, v19, v22
     ad0:      	tbnz	w17, #0x6, 0xb4c <_llm_rows.packet_batch.blocks+0x3f4>
     ad4:      	tbz	w17, #0x7, 0xa58 <_llm_rows.packet_batch.blocks+0x300>
     ad8:      	b	0xb58 <_llm_rows.packet_batch.blocks+0x400>
     adc:      	fmov	x17, d23
     ae0:      	ldr	s20, [x17]
     ae4:      	and	w17, w16, #0xff
     ae8:      	tbz	w17, #0x1, 0xa9c <_llm_rows.packet_batch.blocks+0x344>
     aec:      	mov.d	x0, v23[1]
     af0:      	ld1.s	{ v20 }[1], [x0]
     af4:      	add.2d	v23, v22, v3
     af8:      	shl.2d	v23, v23, #0x2
     afc:      	add.2d	v23, v19, v23
     b00:      	tbz	w17, #0x2, 0xaac <_llm_rows.packet_batch.blocks+0x354>
     b04:      	fmov	x0, d23
     b08:      	ld1.s	{ v20 }[2], [x0]
     b0c:      	tbz	w17, #0x3, 0xab0 <_llm_rows.packet_batch.blocks+0x358>
     b10:      	mov.d	x0, v23[1]
     b14:      	ld1.s	{ v20 }[3], [x0]
     b18:      	add.2d	v23, v22, v4
     b1c:      	shl.2d	v23, v23, #0x2
     b20:      	add.2d	v23, v19, v23
     b24:      	tbz	w17, #0x4, 0xac0 <_llm_rows.packet_batch.blocks+0x368>
     b28:      	fmov	x0, d23
     b2c:      	ld1.s	{ v21 }[0], [x0]
     b30:      	tbz	w17, #0x5, 0xac4 <_llm_rows.packet_batch.blocks+0x36c>
     b34:      	mov.d	x0, v23[1]
     b38:      	ld1.s	{ v21 }[1], [x0]
     b3c:      	add.2d	v22, v22, v2
     b40:      	shl.2d	v22, v22, #0x2
     b44:      	add.2d	v22, v19, v22
     b48:      	tbz	w17, #0x6, 0xad4 <_llm_rows.packet_batch.blocks+0x37c>
     b4c:      	fmov	x0, d22
     b50:      	ld1.s	{ v21 }[2], [x0]
     b54:      	tbz	w17, #0x7, 0xa58 <_llm_rows.packet_batch.blocks+0x300>
     b58:      	mov.d	x17, v22[1]
     b5c:      	ld1.s	{ v21 }[3], [x17]
     b60:      	b	0xa58 <_llm_rows.packet_batch.blocks+0x300>
     b64:      	mov	x15, #0x0               ; =0
     b68:      	sshll2.2d	v24, v0, #0x0
     b6c:      	sshll2.2d	v22, v1, #0x0
     b70:      	sshll.2d	v19, v0, #0x0
     b74:      	sshll.2d	v20, v1, #0x0
     b78:      	dup.2d	v21, x15
     b7c:      	add	x16, x14, x15, lsl #6
     b80:      	ldp	q25, q23, [x16, #0x20]
     b84:      	ldp	q27, q26, [x16]
     b88:      	bsl.16b	v20, v21, v27
     b8c:      	bsl.16b	v19, v21, v25
     b90:      	mov.16b	v25, v22
     b94:      	bsl.16b	v25, v21, v26
     b98:      	bif.16b	v21, v23, v24
     b9c:      	stp	q19, q21, [x16, #0x20]
     ba0:      	stp	q20, q25, [x16]
     ba4:      	add	x15, x15, #0x1
     ba8:      	cmp	x15, x23
     bac:      	b.ne	0xb68 <_llm_rows.packet_batch.blocks+0x410>
     bb0:      	mov	x15, #0x0               ; =0
     bb4:      	sshll.2d	v30, v1, #0x0
     bb8:      	sshll.2d	v29, v0, #0x0
     bbc:      	ldr	q21, [sp, #0x20]
     bc0:      	and.16b	v19, v0, v21
     bc4:      	mvn.16b	v20, v0
     bc8:      	sub.4s	v19, v19, v20
     bcc:      	and.16b	v20, v1, v21
     bd0:      	mvn.16b	v21, v1
     bd4:      	sub.4s	v20, v20, v21
     bd8:      	mov.s	w16, v20[1]
     bdc:      	mov.s	w17, v18[1]
     be0:      	udiv	w0, w17, w16
     be4:      	msub	w16, w0, w16, w17
     be8:      	mov.s	w17, v20[3]
     bec:      	mov.s	w0, v20[2]
     bf0:      	fmov	w1, s20
     bf4:      	fmov	w2, s18
     bf8:      	udiv	w3, w2, w1
     bfc:      	msub	w1, w3, w1, w2
     c00:      	mov.s	w2, v18[3]
     c04:      	udiv	w3, w2, w17
     c08:      	msub	w17, w3, w17, w2
     c0c:      	mov.s	w2, v18[2]
     c10:      	udiv	w3, w2, w0
     c14:      	msub	w0, w3, w0, w2
     c18:      	mov.s	w2, v19[1]
     c1c:      	mov.s	w3, v17[1]
     c20:      	udiv	w4, w3, w2
     c24:      	msub	w2, w4, w2, w3
     c28:      	mov.s	w3, v19[3]
     c2c:      	mov.s	w4, v17[3]
     c30:      	udiv	w5, w4, w3
     c34:      	msub	w3, w5, w3, w4
     c38:      	mov.s	w4, v19[2]
     c3c:      	mov.s	w5, v17[2]
     c40:      	udiv	w6, w5, w4
     c44:      	msub	w4, w6, w4, w5
     c48:      	fmov	w5, s19
     c4c:      	fmov	w6, s17
     c50:      	fmov	s17, w4
     c54:      	mov.s	v17[1], w3
     c58:      	udiv	w3, w6, w5
     c5c:      	msub	w3, w3, w5, w6
     c60:      	ushll.2d	v19, v17, #0x0
     c64:      	fmov	s17, w3
     c68:      	mov.s	v17[1], w2
     c6c:      	ushll.2d	v20, v17, #0x0
     c70:      	fmov	s17, w0
     c74:      	mov.s	v17[1], w17
     c78:      	fmov	s18, w1
     c7c:      	mov.s	v18[1], w16
     c80:      	ushll.2d	v21, v17, #0x0
     c84:      	ushll.2d	v23, v18, #0x0
     c88:      	and.16b	v25, v24, v16
     c8c:      	and.16b	v26, v22, v16
     c90:      	and.16b	v27, v29, v16
     c94:      	and.16b	v28, v30, v16
     c98:      	adrp	x16, 0x0 <ltmp0>
     c9c:      	ldr	q16, [x16]
     ca0:      	and.16b	v24, v24, v16
     ca4:      	adrp	x16, 0x0 <ltmp0>
     ca8:      	ldr	q16, [x16]
     cac:      	and.16b	v22, v22, v16
     cb0:      	adrp	x16, 0x0 <ltmp0>
     cb4:      	ldr	q16, [x16]
     cb8:      	and.16b	v29, v29, v16
     cbc:      	adrp	x16, 0x0 <ltmp0>
     cc0:      	ldr	q16, [x16]
     cc4:      	and.16b	v30, v30, v16
     cc8:      	ldp	q16, q17, [sp, #0x40]
     ccc:      	cmhs.4s	v16, v16, v7
     cd0:      	cmhs.4s	v7, v17, v7
     cd4:      	uzp1.8h	v7, v7, v16
     cd8:      	xtn.8b	v31, v7
     cdc:      	mov	w0, #-0x3d300000        ; =-1026555904
     ce0:      	mov	w1, #0x42c80000         ; =1120403456
     ce4:      	mov	w2, #0xaa3b             ; =43579
     ce8:      	movk	w2, #0x3fb8, lsl #16
     cec:      	mov	w3, #0x7200             ; =29184
     cf0:      	movk	w3, #0xbf31, lsl #16
     cf4:      	mov	w4, #0xbe8e             ; =48782
     cf8:      	movk	w4, #0xb5bf, lsl #16
     cfc:      	mov	w5, #0x2bda             ; =11226
     d00:      	movk	w5, #0x3950, lsl #16
     d04:      	mov	w6, #0x96c9             ; =38601
     d08:      	movk	w6, #0x3ab6, lsl #16
     d0c:      	mov	w21, #0x88a6            ; =34982
     d10:      	movk	w21, #0x3c08, lsl #16
     d14:      	b	0xd24 <_llm_rows.packet_batch.blocks+0x5cc>
     d18:      	add	x15, x15, #0x1
     d1c:      	cmp	x15, x23
     d20:      	b.eq	0xe24 <_llm_rows.packet_batch.blocks+0x6cc>
     d24:      	dup.2d	v9, x15
     d28:      	fmov	w16, s6
     d2c:      	add	x17, x14, x15, lsl #6
     d30:      	ldp	q16, q7, [x17, #0x20]
     d34:      	ldp	q17, q18, [x17]
     d38:      	cmge.2d	v18, v21, v18
     d3c:      	cmge.2d	v17, v23, v17
     d40:      	uzp1.4s	v17, v17, v18
     d44:      	cmge.2d	v16, v20, v16
     d48:      	cmge.2d	v7, v19, v7
     d4c:      	uzp1.4s	v7, v16, v7
     d50:      	uzp1.8h	v7, v17, v7
     d54:      	xtn.8b	v7, v7
     d58:      	orr.8b	v17, v31, v7
     d5c:      	add.2d	v7, v28, v30
     d60:      	add.2d	v16, v7, v9
     d64:      	and.8b	v10, v17, v8
     d68:      	tbnz	w16, #0x0, 0xda8 <_llm_rows.packet_batch.blocks+0x650>
     d6c:      	and	w16, w16, #0xff
     d70:      	tbnz	w16, #0x1, 0xdb8 <_llm_rows.packet_batch.blocks+0x660>
     d74:      	add.2d	v16, v26, v22
     d78:      	add.2d	v17, v16, v9
     d7c:      	tbnz	w16, #0x2, 0xdcc <_llm_rows.packet_batch.blocks+0x674>
     d80:      	tbnz	w16, #0x3, 0xdd8 <_llm_rows.packet_batch.blocks+0x680>
     d84:      	add.2d	v17, v27, v29
     d88:      	add.2d	v18, v17, v9
     d8c:      	tbnz	w16, #0x4, 0xdec <_llm_rows.packet_batch.blocks+0x694>
     d90:      	tbnz	w16, #0x5, 0xdf8 <_llm_rows.packet_batch.blocks+0x6a0>
     d94:      	add.2d	v18, v25, v24
     d98:      	add.2d	v9, v18, v9
     d9c:      	tbnz	w16, #0x6, 0xe0c <_llm_rows.packet_batch.blocks+0x6b4>
     da0:      	tbz	w16, #0x7, 0xd18 <_llm_rows.packet_batch.blocks+0x5c0>
     da4:      	b	0xe18 <_llm_rows.packet_batch.blocks+0x6c0>
     da8:      	fmov	x17, d16
     dac:      	str	b10, [x17]
     db0:      	and	w16, w16, #0xff
     db4:      	tbz	w16, #0x1, 0xd74 <_llm_rows.packet_batch.blocks+0x61c>
     db8:      	mov.d	x17, v16[1]
     dbc:      	st1.b	{ v10 }[1], [x17]
     dc0:      	add.2d	v16, v26, v22
     dc4:      	add.2d	v17, v16, v9
     dc8:      	tbz	w16, #0x2, 0xd80 <_llm_rows.packet_batch.blocks+0x628>
     dcc:      	fmov	x17, d17
     dd0:      	st1.b	{ v10 }[2], [x17]
     dd4:      	tbz	w16, #0x3, 0xd84 <_llm_rows.packet_batch.blocks+0x62c>
     dd8:      	mov.d	x17, v17[1]
     ddc:      	st1.b	{ v10 }[3], [x17]
     de0:      	add.2d	v17, v27, v29
     de4:      	add.2d	v18, v17, v9
     de8:      	tbz	w16, #0x4, 0xd90 <_llm_rows.packet_batch.blocks+0x638>
     dec:      	fmov	x17, d18
     df0:      	st1.b	{ v10 }[4], [x17]
     df4:      	tbz	w16, #0x5, 0xd94 <_llm_rows.packet_batch.blocks+0x63c>
     df8:      	mov.d	x17, v18[1]
     dfc:      	st1.b	{ v10 }[5], [x17]
     e00:      	add.2d	v18, v25, v24
     e04:      	add.2d	v9, v18, v9
     e08:      	tbz	w16, #0x6, 0xda0 <_llm_rows.packet_batch.blocks+0x648>
     e0c:      	fmov	x17, d9
     e10:      	st1.b	{ v10 }[6], [x17]
     e14:      	tbz	w16, #0x7, 0xd18 <_llm_rows.packet_batch.blocks+0x5c0>
     e18:      	mov.d	x16, v9[1]
     e1c:      	st1.b	{ v10 }[7], [x16]
     e20:      	b	0xd18 <_llm_rows.packet_batch.blocks+0x5c0>
     e24:      	mov	x14, #0x0               ; =0
     e28:      	b	0xe7c <_llm_rows.packet_batch.blocks+0x724>
     e2c:      	cmeq.8b	v19, v19, #0
     e30:      	sshll.8h	v19, v19, #0x0
     e34:      	sshll2.4s	v20, v19, #0x0
     e38:      	sshll.4s	v19, v19, #0x0
     e3c:      	lsl	x15, x14, #5
     e40:      	add	x16, x11, x15
     e44:      	ldp	q21, q22, [x16]
     e48:      	and.16b	v22, v0, v22
     e4c:      	dup.4s	v23, w7
     e50:      	and.16b	v21, v1, v21
     e54:      	bsl.16b	v19, v23, v21
     e58:      	bsl.16b	v20, v23, v22
     e5c:      	add	x15, x13, x15
     e60:      	ldp	q21, q22, [x15]
     e64:      	bif.16b	v20, v22, v0
     e68:      	bif.16b	v19, v21, v1
     e6c:      	stp	q19, q20, [x15]
     e70:      	add	x14, x14, #0x1
     e74:      	cmp	x14, x23
     e78:      	b.eq	0xf2c <_llm_rows.packet_batch.blocks+0x7d4>
     e7c:      	fmov	w15, s6
     e80:      	dup.2d	v20, x14
     e84:      	add.2d	v21, v7, v20
     e88:      	tbz	w15, #0x0, 0xea0 <_llm_rows.packet_batch.blocks+0x748>
     e8c:      	fmov	x16, d21
     e90:      	ldr	b19, [x16]
     e94:      	and	w15, w15, #0xff
     e98:      	tbnz	w15, #0x1, 0xeac <_llm_rows.packet_batch.blocks+0x754>
     e9c:      	b	0xeb4 <_llm_rows.packet_batch.blocks+0x75c>
     ea0:      	movi.2d	v19, #0000000000000000
     ea4:      	and	w15, w15, #0xff
     ea8:      	tbz	w15, #0x1, 0xeb4 <_llm_rows.packet_batch.blocks+0x75c>
     eac:      	mov.d	x16, v21[1]
     eb0:      	ld1.b	{ v19 }[1], [x16]
     eb4:      	add.2d	v21, v16, v20
     eb8:      	tbnz	w15, #0x2, 0xedc <_llm_rows.packet_batch.blocks+0x784>
     ebc:      	tbnz	w15, #0x3, 0xee8 <_llm_rows.packet_batch.blocks+0x790>
     ec0:      	add.2d	v21, v17, v20
     ec4:      	tbnz	w15, #0x4, 0xef8 <_llm_rows.packet_batch.blocks+0x7a0>
     ec8:      	tbnz	w15, #0x5, 0xf04 <_llm_rows.packet_batch.blocks+0x7ac>
     ecc:      	add.2d	v20, v18, v20
     ed0:      	tbnz	w15, #0x6, 0xf14 <_llm_rows.packet_batch.blocks+0x7bc>
     ed4:      	tbz	w15, #0x7, 0xe2c <_llm_rows.packet_batch.blocks+0x6d4>
     ed8:      	b	0xf20 <_llm_rows.packet_batch.blocks+0x7c8>
     edc:      	fmov	x16, d21
     ee0:      	ld1.b	{ v19 }[2], [x16]
     ee4:      	tbz	w15, #0x3, 0xec0 <_llm_rows.packet_batch.blocks+0x768>
     ee8:      	mov.d	x16, v21[1]
     eec:      	ld1.b	{ v19 }[3], [x16]
     ef0:      	add.2d	v21, v17, v20
     ef4:      	tbz	w15, #0x4, 0xec8 <_llm_rows.packet_batch.blocks+0x770>
     ef8:      	fmov	x16, d21
     efc:      	ld1.b	{ v19 }[4], [x16]
     f00:      	tbz	w15, #0x5, 0xecc <_llm_rows.packet_batch.blocks+0x774>
     f04:      	mov.d	x16, v21[1]
     f08:      	ld1.b	{ v19 }[5], [x16]
     f0c:      	add.2d	v20, v18, v20
     f10:      	tbz	w15, #0x6, 0xed4 <_llm_rows.packet_batch.blocks+0x77c>
     f14:      	fmov	x16, d20
     f18:      	ld1.b	{ v19 }[6], [x16]
     f1c:      	tbz	w15, #0x7, 0xe2c <_llm_rows.packet_batch.blocks+0x6d4>
     f20:      	mov.d	x15, v20[1]
     f24:      	ld1.b	{ v19 }[7], [x15]
     f28:      	b	0xe2c <_llm_rows.packet_batch.blocks+0x6d4>
     f2c:      	mov	x14, #0x0               ; =0
     f30:      	ldp	q19, q20, [x13]
     f34:      	ldp	q21, q22, [x13, #0x20]
     f38:      	ldp	q26, q27, [x13, #0x40]
     f3c:      	and.16b	v25, v0, v20
     f40:      	and.16b	v24, v1, v19
     f44:      	ldp	q20, q28, [x13, #0x60]
     f48:      	and.16b	v23, v0, v22
     f4c:      	and.16b	v22, v1, v21
     f50:      	and.16b	v19, v0, v27
     f54:      	and.16b	v26, v1, v26
     f58:      	and.16b	v21, v0, v28
     f5c:      	and.16b	v20, v1, v20
     f60:      	mov	w15, #0x8128            ; =33064
     f64:      	movk	w15, #0x6, lsl #16
     f68:      	add	x15, x11, x15
     f6c:      	add	x16, x15, x14, lsl #5
     f70:      	ldp	q27, q28, [x16, #-0x40]
     f74:      	and.16b	v28, v0, v28
     f78:      	and.16b	v27, v1, v27
     f7c:      	fmaxnm.4s	v27, v24, v27
     f80:      	fmaxnm.4s	v28, v25, v28
     f84:      	ldp	q29, q30, [x16, #-0x20]
     f88:      	and.16b	v30, v0, v30
     f8c:      	and.16b	v29, v1, v29
     f90:      	fmaxnm.4s	v29, v22, v29
     f94:      	fmaxnm.4s	v30, v23, v30
     f98:      	ldp	q31, q9, [x16]
     f9c:      	and.16b	v9, v0, v9
     fa0:      	and.16b	v31, v1, v31
     fa4:      	fmaxnm.4s	v31, v26, v31
     fa8:      	fmaxnm.4s	v9, v19, v9
     fac:      	ldp	q10, q11, [x16, #0x20]
     fb0:      	and.16b	v11, v0, v11
     fb4:      	and.16b	v10, v1, v10
     fb8:      	fmaxnm.4s	v10, v20, v10
     fbc:      	fmaxnm.4s	v11, v21, v11
     fc0:      	bit.16b	v25, v28, v0
     fc4:      	bit.16b	v24, v27, v1
     fc8:      	bit.16b	v23, v30, v0
     fcc:      	bit.16b	v22, v29, v1
     fd0:      	bit.16b	v19, v9, v0
     fd4:      	bit.16b	v26, v31, v1
     fd8:      	bit.16b	v21, v11, v0
     fdc:      	bit.16b	v20, v10, v1
     fe0:      	add	x14, x14, #0x4
     fe4:      	cmp	x14, #0xffc
     fe8:      	b.lo	0xf6c <_llm_rows.packet_batch.blocks+0x814>
     fec:      	mov	x14, #0x0               ; =0
     ff0:      	ldp	q28, q27, [x12]
     ff4:      	and.16b	v28, v1, v28
     ff8:      	and.16b	v27, v0, v27
     ffc:      	fmaxnm.4s	v25, v25, v27
    1000:      	fmaxnm.4s	v24, v24, v28
    1004:      	fmaxnm.4s	v24, v24, v13
    1008:      	fmaxnm.4s	v25, v25, v13
    100c:      	fmaxnm.4s	v23, v25, v23
    1010:      	fmaxnm.4s	v22, v24, v22
    1014:      	fmaxnm.4s	v22, v22, v26
    1018:      	fmaxnm.4s	v19, v23, v19
    101c:      	fmaxnm.4s	v19, v19, v21
    1020:      	fmaxnm.4s	v20, v22, v20
    1024:      	b	0x1210 <_llm_rows.packet_batch.blocks+0xab8>
    1028:      	cmeq.8b	v21, v21, #0
    102c:      	sshll.8h	v22, v21, #0x0
    1030:      	sshll2.4s	v21, v22, #0x0
    1034:      	sshll.4s	v22, v22, #0x0
    1038:      	lsl	x15, x14, #5
    103c:      	add	x16, x13, x15
    1040:      	ldp	q24, q23, [x16]
    1044:      	fsub.4s	v24, v24, v20
    1048:      	fsub.4s	v23, v23, v19
    104c:      	and.16b	v23, v0, v23
    1050:      	and.16b	v24, v1, v24
    1054:      	dup.4s	v25, w0
    1058:      	fcmge.4s	v27, v24, v25
    105c:      	fcmge.4s	v28, v23, v25
    1060:      	dup.4s	v26, w1
    1064:      	fcmge.4s	v29, v26, v24
    1068:      	fcmge.4s	v30, v26, v23
    106c:      	and.16b	v28, v28, v30
    1070:      	and.16b	v27, v27, v29
    1074:      	and.16b	v27, v27, v24
    1078:      	and.16b	v28, v28, v23
    107c:      	dup.4s	v29, w2
    1080:      	fmul.4s	v30, v28, v29
    1084:      	fmul.4s	v29, v27, v29
    1088:      	mov.16b	v31, v15
    108c:      	bsl.16b	v31, v14, v29
    1090:      	mov.16b	v9, v15
    1094:      	bsl.16b	v9, v14, v30
    1098:      	fadd.4s	v30, v30, v9
    109c:      	fadd.4s	v29, v29, v31
    10a0:      	fsub.4s	v29, v29, v31
    10a4:      	fsub.4s	v30, v30, v9
    10a8:      	fcvtzs.4s	v30, v30
    10ac:      	fcvtzs.4s	v29, v29
    10b0:      	scvtf.4s	v31, v29
    10b4:      	dup.4s	v9, w3
    10b8:      	scvtf.4s	v10, v30
    10bc:      	fmul.4s	v11, v10, v9
    10c0:      	fmul.4s	v9, v31, v9
    10c4:      	fadd.4s	v27, v27, v9
    10c8:      	dup.4s	v9, w4
    10cc:      	fadd.4s	v28, v28, v11
    10d0:      	fmul.4s	v31, v31, v9
    10d4:      	fmul.4s	v9, v10, v9
    10d8:      	fadd.4s	v28, v28, v9
    10dc:      	dup.4s	v9, w5
    10e0:      	fadd.4s	v27, v27, v31
    10e4:      	fmul.4s	v31, v27, v9
    10e8:      	fmul.4s	v9, v28, v9
    10ec:      	dup.4s	v10, w6
    10f0:      	fadd.4s	v9, v9, v10
    10f4:      	fadd.4s	v31, v31, v10
    10f8:      	fmul.4s	v31, v27, v31
    10fc:      	fmul.4s	v9, v28, v9
    1100:      	dup.4s	v10, w21
    1104:      	fadd.4s	v9, v9, v10
    1108:      	fadd.4s	v31, v31, v10
    110c:      	fmul.4s	v31, v27, v31
    1110:      	fmul.4s	v9, v28, v9
    1114:      	dup.4s	v10, w30
    1118:      	fadd.4s	v9, v9, v10
    111c:      	fadd.4s	v31, v31, v10
    1120:      	fmul.4s	v31, v27, v31
    1124:      	fmul.4s	v9, v28, v9
    1128:      	dup.4s	v10, w19
    112c:      	fadd.4s	v9, v9, v10
    1130:      	fadd.4s	v31, v31, v10
    1134:      	fmul.4s	v31, v27, v31
    1138:      	fmul.4s	v9, v28, v9
    113c:      	movi.4s	v10, #0x3f, lsl #24
    1140:      	fadd.4s	v9, v9, v10
    1144:      	fadd.4s	v31, v31, v10
    1148:      	fmul.4s	v10, v28, v28
    114c:      	fmul.4s	v11, v27, v27
    1150:      	fmul.4s	v31, v11, v31
    1154:      	fmul.4s	v9, v10, v9
    1158:      	fadd.4s	v28, v28, v9
    115c:      	fadd.4s	v27, v27, v31
    1160:      	fmov.4s	v31, #1.00000000
    1164:      	fadd.4s	v27, v27, v31
    1168:      	fadd.4s	v28, v28, v31
    116c:      	sshr.4s	v9, v29, #0x1
    1170:      	sshr.4s	v10, v30, #0x1
    1174:      	shl.4s	v11, v10, #0x17
    1178:      	shl.4s	v12, v9, #0x17
    117c:      	add.4s	v12, v12, v31
    1180:      	add.4s	v11, v11, v31
    1184:      	fmul.4s	v28, v28, v11
    1188:      	fmul.4s	v27, v27, v12
    118c:      	sub.4s	v30, v30, v10
    1190:      	sub.4s	v29, v29, v9
    1194:      	shl.4s	v29, v29, #0x17
    1198:      	shl.4s	v30, v30, #0x17
    119c:      	add.4s	v30, v30, v31
    11a0:      	add.4s	v29, v29, v31
    11a4:      	fmul.4s	v27, v27, v29
    11a8:      	fmul.4s	v28, v28, v30
    11ac:      	fcmgt.4s	v29, v25, v23
    11b0:      	bic.16b	v28, v28, v29
    11b4:      	fcmgt.4s	v25, v25, v24
    11b8:      	bic.16b	v25, v27, v25
    11bc:      	fcmgt.4s	v27, v23, v26
    11c0:      	fcmgt.4s	v26, v24, v26
    11c4:      	fneg.4s	v29, v13
    11c8:      	bit.16b	v25, v29, v26
    11cc:      	mov.16b	v26, v27
    11d0:      	bsl.16b	v26, v29, v28
    11d4:      	fcmeq.4s	v24, v24, v24
    11d8:      	fcmeq.4s	v23, v23, v23
    11dc:      	ldr	q27, [sp, #0x70]
    11e0:      	bsl.16b	v23, v26, v27
    11e4:      	bsl.16b	v24, v25, v27
    11e8:      	bic.16b	v22, v24, v22
    11ec:      	bic.16b	v21, v23, v21
    11f0:      	add	x15, x8, x15
    11f4:      	ldp	q23, q24, [x15]
    11f8:      	bif.16b	v21, v24, v0
    11fc:      	bif.16b	v22, v23, v1
    1200:      	stp	q22, q21, [x15]
    1204:      	add	x14, x14, #0x1
    1208:      	cmp	x14, x23
    120c:      	b.eq	0x12c0 <_llm_rows.packet_batch.blocks+0xb68>
    1210:      	fmov	w15, s6
    1214:      	dup.2d	v22, x14
    1218:      	add.2d	v23, v7, v22
    121c:      	tbz	w15, #0x0, 0x1234 <_llm_rows.packet_batch.blocks+0xadc>
    1220:      	fmov	x16, d23
    1224:      	ldr	b21, [x16]
    1228:      	and	w15, w15, #0xff
    122c:      	tbnz	w15, #0x1, 0x1240 <_llm_rows.packet_batch.blocks+0xae8>
    1230:      	b	0x1248 <_llm_rows.packet_batch.blocks+0xaf0>
    1234:      	movi.2d	v21, #0000000000000000
    1238:      	and	w15, w15, #0xff
    123c:      	tbz	w15, #0x1, 0x1248 <_llm_rows.packet_batch.blocks+0xaf0>
    1240:      	mov.d	x16, v23[1]
    1244:      	ld1.b	{ v21 }[1], [x16]
    1248:      	add.2d	v23, v16, v22
    124c:      	tbnz	w15, #0x2, 0x1270 <_llm_rows.packet_batch.blocks+0xb18>
    1250:      	tbnz	w15, #0x3, 0x127c <_llm_rows.packet_batch.blocks+0xb24>
    1254:      	add.2d	v23, v17, v22
    1258:      	tbnz	w15, #0x4, 0x128c <_llm_rows.packet_batch.blocks+0xb34>
    125c:      	tbnz	w15, #0x5, 0x1298 <_llm_rows.packet_batch.blocks+0xb40>
    1260:      	add.2d	v22, v18, v22
    1264:      	tbnz	w15, #0x6, 0x12a8 <_llm_rows.packet_batch.blocks+0xb50>
    1268:      	tbz	w15, #0x7, 0x1028 <_llm_rows.packet_batch.blocks+0x8d0>
    126c:      	b	0x12b4 <_llm_rows.packet_batch.blocks+0xb5c>
    1270:      	fmov	x16, d23
    1274:      	ld1.b	{ v21 }[2], [x16]
    1278:      	tbz	w15, #0x3, 0x1254 <_llm_rows.packet_batch.blocks+0xafc>
    127c:      	mov.d	x16, v23[1]
    1280:      	ld1.b	{ v21 }[3], [x16]
    1284:      	add.2d	v23, v17, v22
    1288:      	tbz	w15, #0x4, 0x125c <_llm_rows.packet_batch.blocks+0xb04>
    128c:      	fmov	x16, d23
    1290:      	ld1.b	{ v21 }[4], [x16]
    1294:      	tbz	w15, #0x5, 0x1260 <_llm_rows.packet_batch.blocks+0xb08>
    1298:      	mov.d	x16, v23[1]
    129c:      	ld1.b	{ v21 }[5], [x16]
    12a0:      	add.2d	v22, v18, v22
    12a4:      	tbz	w15, #0x6, 0x1268 <_llm_rows.packet_batch.blocks+0xb10>
    12a8:      	fmov	x16, d22
    12ac:      	ld1.b	{ v21 }[6], [x16]
    12b0:      	tbz	w15, #0x7, 0x1028 <_llm_rows.packet_batch.blocks+0x8d0>
    12b4:      	mov.d	x15, v22[1]
    12b8:      	ld1.b	{ v21 }[7], [x15]
    12bc:      	b	0x1028 <_llm_rows.packet_batch.blocks+0x8d0>
    12c0:      	mov	x13, #0x0               ; =0
    12c4:      	ldp	q7, q16, [x12, #0x20]
    12c8:      	ldp	q17, q18, [x12, #0x40]
    12cc:      	ldp	q21, q22, [x12, #0x60]
    12d0:      	ldp	q23, q24, [x12, #0x80]
    12d4:      	and.16b	v19, v0, v16
    12d8:      	and.16b	v20, v1, v7
    12dc:      	and.16b	v7, v0, v18
    12e0:      	and.16b	v18, v1, v17
    12e4:      	and.16b	v17, v0, v22
    12e8:      	and.16b	v16, v1, v21
    12ec:      	and.16b	v21, v0, v24
    12f0:      	and.16b	v22, v1, v23
    12f4:      	mov	w12, #0x8148            ; =33096
    12f8:      	movk	w12, #0x8, lsl #16
    12fc:      	add	x11, x11, x12
    1300:      	add	x12, x11, x13, lsl #5
    1304:      	ldp	q24, q23, [x12, #-0x40]
    1308:      	fadd.4s	v25, v20, v24
    130c:      	fadd.4s	v26, v19, v23
    1310:      	ldp	q24, q23, [x12, #-0x20]
    1314:      	fadd.4s	v27, v18, v24
    1318:      	fadd.4s	v28, v7, v23
    131c:      	ldp	q24, q23, [x12]
    1320:      	fadd.4s	v29, v16, v24
    1324:      	fadd.4s	v30, v17, v23
    1328:      	ldp	q23, q24, [x12, #0x20]
    132c:      	fadd.4s	v23, v22, v23
    1330:      	fadd.4s	v24, v21, v24
    1334:      	bit.16b	v19, v26, v0
    1338:      	bit.16b	v20, v25, v1
    133c:      	bit.16b	v7, v28, v0
    1340:      	bit.16b	v18, v27, v1
    1344:      	bit.16b	v17, v30, v0
    1348:      	bit.16b	v16, v29, v1
    134c:      	bit.16b	v21, v24, v0
    1350:      	bit.16b	v22, v23, v1
    1354:      	add	x13, x13, #0x4
    1358:      	cmp	x13, #0xffc
    135c:      	b.lo	0x1300 <_llm_rows.packet_batch.blocks+0xba8>
    1360:      	mov	x11, #0x0               ; =0
    1364:      	ldp	q21, q22, [x10]
    1368:      	and.16b	v22, v0, v22
    136c:      	and.16b	v21, v1, v21
    1370:      	fadd.4s	v20, v20, v21
    1374:      	fadd.4s	v19, v19, v22
    1378:      	movi.2d	v21, #0000000000000000
    137c:      	fadd.4s	v19, v19, v21
    1380:      	fadd.4s	v20, v20, v21
    1384:      	fadd.4s	v18, v18, v20
    1388:      	fadd.4s	v7, v7, v19
    138c:      	fadd.4s	v7, v17, v7
    1390:      	fadd.4s	v16, v16, v18
    1394:      	fadd.4s	v16, v23, v16
    1398:      	fadd.4s	v7, v24, v7
    139c:      	and.16b	v7, v0, v7
    13a0:      	and.16b	v16, v1, v16
    13a4:      	b	0x13b4 <_llm_rows.packet_batch.blocks+0xc5c>
    13a8:      	add	x11, x11, #0x1
    13ac:      	cmp	x11, x23
    13b0:      	b.eq	0x80c <_llm_rows.packet_batch.blocks+0xb4>
    13b4:      	fmov	w10, s6
    13b8:      	dup.2d	v17, x11
    13bc:      	add.2d	v18, v17, v5
    13c0:      	add	x12, x8, x11, lsl #5
    13c4:      	ldp	q20, q19, [x12]
    13c8:      	and.16b	v20, v1, v20
    13cc:      	fdiv.4s	v20, v20, v16
    13d0:      	shl.2d	v21, v18, #0x2
    13d4:      	dup.2d	v18, x9
    13d8:      	add.2d	v21, v18, v21
    13dc:      	tbnz	w10, #0x0, 0x1430 <_llm_rows.packet_batch.blocks+0xcd8>
    13e0:      	and	w10, w10, #0xff
    13e4:      	tbnz	w10, #0x1, 0x1440 <_llm_rows.packet_batch.blocks+0xce8>
    13e8:      	add.2d	v21, v17, v3
    13ec:      	shl.2d	v21, v21, #0x2
    13f0:      	add.2d	v21, v18, v21
    13f4:      	tbnz	w10, #0x2, 0x1458 <_llm_rows.packet_batch.blocks+0xd00>
    13f8:      	tbnz	w10, #0x3, 0x1464 <_llm_rows.packet_batch.blocks+0xd0c>
    13fc:      	add.2d	v20, v17, v4
    1400:      	and.16b	v19, v0, v19
    1404:      	fdiv.4s	v19, v19, v7
    1408:      	shl.2d	v20, v20, #0x2
    140c:      	add.2d	v20, v18, v20
    1410:      	tbnz	w10, #0x4, 0x1484 <_llm_rows.packet_batch.blocks+0xd2c>
    1414:      	tbnz	w10, #0x5, 0x1490 <_llm_rows.packet_batch.blocks+0xd38>
    1418:      	add.2d	v17, v17, v2
    141c:      	shl.2d	v17, v17, #0x2
    1420:      	add.2d	v17, v18, v17
    1424:      	tbnz	w10, #0x6, 0x14a8 <_llm_rows.packet_batch.blocks+0xd50>
    1428:      	tbz	w10, #0x7, 0x13a8 <_llm_rows.packet_batch.blocks+0xc50>
    142c:      	b	0x14b4 <_llm_rows.packet_batch.blocks+0xd5c>
    1430:      	fmov	x12, d21
    1434:      	str	s20, [x12]
    1438:      	and	w10, w10, #0xff
    143c:      	tbz	w10, #0x1, 0x13e8 <_llm_rows.packet_batch.blocks+0xc90>
    1440:      	mov.d	x12, v21[1]
    1444:      	st1.s	{ v20 }[1], [x12]
    1448:      	add.2d	v21, v17, v3
    144c:      	shl.2d	v21, v21, #0x2
    1450:      	add.2d	v21, v18, v21
    1454:      	tbz	w10, #0x2, 0x13f8 <_llm_rows.packet_batch.blocks+0xca0>
    1458:      	fmov	x12, d21
    145c:      	st1.s	{ v20 }[2], [x12]
    1460:      	tbz	w10, #0x3, 0x13fc <_llm_rows.packet_batch.blocks+0xca4>
    1464:      	mov.d	x12, v21[1]
    1468:      	st1.s	{ v20 }[3], [x12]
    146c:      	add.2d	v20, v17, v4
    1470:      	and.16b	v19, v0, v19
    1474:      	fdiv.4s	v19, v19, v7
    1478:      	shl.2d	v20, v20, #0x2
    147c:      	add.2d	v20, v18, v20
    1480:      	tbz	w10, #0x4, 0x1414 <_llm_rows.packet_batch.blocks+0xcbc>
    1484:      	fmov	x12, d20
    1488:      	str	s19, [x12]
    148c:      	tbz	w10, #0x5, 0x1418 <_llm_rows.packet_batch.blocks+0xcc0>
    1490:      	mov.d	x12, v20[1]
    1494:      	st1.s	{ v19 }[1], [x12]
    1498:      	add.2d	v17, v17, v2
    149c:      	shl.2d	v17, v17, #0x2
    14a0:      	add.2d	v17, v18, v17
    14a4:      	tbz	w10, #0x6, 0x1428 <_llm_rows.packet_batch.blocks+0xcd0>
    14a8:      	fmov	x12, d17
    14ac:      	st1.s	{ v19 }[2], [x12]
    14b0:      	tbz	w10, #0x7, 0x13a8 <_llm_rows.packet_batch.blocks+0xc50>
    14b4:      	mov.d	x10, v17[1]
    14b8:      	st1.s	{ v19 }[3], [x10]
    14bc:      	b	0x13a8 <_llm_rows.packet_batch.blocks+0xc50>
    14c0:      	ldp	x29, x30, [sp, #0x120]
    14c4:      	ldp	x20, x19, [sp, #0x110]
    14c8:      	ldp	x22, x21, [sp, #0x100]
    14cc:      	ldp	x24, x23, [sp, #0xf0]
    14d0:      	ldp	x26, x25, [sp, #0xe0]
    14d4:      	ldp	x28, x27, [sp, #0xd0]
    14d8:      	ldp	d9, d8, [sp, #0xc0]
    14dc:      	ldp	d11, d10, [sp, #0xb0]
    14e0:      	ldp	d13, d12, [sp, #0xa0]
    14e4:      	ldp	d15, d14, [sp, #0x90]
    14e8:      	add	sp, sp, #0x130
    14ec:      	ret

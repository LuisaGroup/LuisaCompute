
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/masked_softmax-1024x4097/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000700 <_kernel>:
     700:      	sub	sp, sp, #0x150
     704:      	stp	x28, x27, [sp, #0xf0]
     708:      	stp	x26, x25, [sp, #0x100]
     70c:      	stp	x24, x23, [sp, #0x110]
     710:      	stp	x22, x21, [sp, #0x120]
     714:      	stp	x20, x19, [sp, #0x130]
     718:      	stp	x29, x30, [sp, #0x140]
     71c:      	add	x29, sp, #0x140
     720:      	mov	x20, x3
     724:      	mov	x21, x2
     728:      	mov	x27, x1
     72c:      	mov	x23, x0
     730:      	stur	wzr, [x29, #-0x60]
     734:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     738:      	ldr	x9, [x9, #0xa8]
     73c:      	sub	x8, x29, #0x60
     740:      	str	x8, [x9]
     744:      	mov	w0, #0x4004             ; =16388
     748:      	bl	0x1da0 <dyld_stub_binder+0x1da0>
     74c:      	mov	x19, x0
     750:      	mov	w1, #0x4004             ; =16388
     754:      	bl	0x1e00 <dyld_stub_binder+0x1e00>
     758:      	mov	x26, #0x0               ; =0
     75c:      	adrp	x8, 0x2000 <dyld_stub_binder+0x2000>
     760:      	ldr	q0, [x8]
     764:      	str	q0, [sp, #0x10]
     768:      	adrp	x8, 0x2000 <dyld_stub_binder+0x2000>
     76c:      	ldr	q0, [x8, #0x10]
     770:      	str	q0, [sp]
     774:      	mov	w8, #0xf2ca             ; =62154
     778:      	movk	w8, #0xf149, lsl #16
     77c:      	dup.4s	v0, w8
     780:      	str	q0, [sp, #0x90]
     784:      	adrp	x8, 0x1000 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_+0x24>
     788:      	ldr	q0, [x8, #0xff0]
     78c:      	str	q0, [sp, #0x70]
     790:      	stp	x20, x23, [sp, #0x48]
     794:      	mov	x8, #0x0                ; =0
     798:      	mov	x9, #0x0                ; =0
     79c:      	add	x10, x26, x26, lsl #12
     7a0:      	lsl	x11, x10, #2
     7a4:      	ldr	x10, [sp, #0x50]
     7a8:      	add	x25, x10, x11
     7ac:      	dup.2d	v0, x26
     7b0:      	str	q0, [sp, #0xa0]
     7b4:      	mvni.4s	v0, #0x7f, msl #16
     7b8:      	str	x11, [sp, #0x58]
     7bc:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     7c0:      	b.eq	0xacc <_kernel+0x3cc>
     7c4:      	ldr	q1, [x23, x8]
     7c8:      	dup.2d	v2, x9
     7cc:      	ldr	q4, [sp, #0x70]
     7d0:      	orr.16b	v2, v2, v4
     7d4:      	orr	x10, x9, #0x2
     7d8:      	dup.2d	v3, x10
     7dc:      	orr.16b	v3, v3, v4
     7e0:      	ldr	q4, [sp, #0xa0]
     7e4:      	cmhs.2d	v2, v4, v2
     7e8:      	cmhs.2d	v3, v4, v3
     7ec:      	cmeq.2d	v2, v2, #0
     7f0:      	cmeq.2d	v3, v3, #0
     7f4:      	uzp1.4s	v2, v2, v3
     7f8:      	ldr	q3, [sp, #0x90]
     7fc:      	bit.16b	v1, v3, v2
     800:      	fmax.4s	v0, v0, v1
     804:      	add	x8, x8, #0x10
     808:      	cmp	x9, #0xffd
     80c:      	add	x9, x9, #0x4
     810:      	b.lo	0x7bc <_kernel+0xbc>
     814:      	mov	w8, #-0x800000          ; =-8388608
     818:      	fmov	s1, w8
     81c:      	ext.16b	v2, v0, v0, #0x8
     820:      	fmax.4s	v0, v0, v2
     824:      	rev64.4s	v2, v0
     828:      	fmax.4s	v0, v0, v2
     82c:      	fcmp	s1, s0
     830:      	fcsel	s0, s1, s0, gt
     834:      	str	s0, [x27, x26, lsl #2]
     838:      	movi.2d	v0, #0000000000000000
     83c:      	stp	q0, q0, [x29, #-0x80]
     840:      	stur	q0, [x29, #-0x90]
     844:      	mov	w8, #0x1                ; =1
     848:      	stur	x8, [x29, #-0x78]
     84c:      	stur	wzr, [x29, #-0x5c]
     850:      	sub	x0, x29, #0x90
     854:      	sub	x2, x29, #0x5c
     858:      	mov	w1, #0x1                ; =1
     85c:      	bl	0xc98 <__ZNSt3__16vectorIfNS_9allocatorIfEEE6assignEmRKf>
     860:      	mov	x24, #0x0               ; =0
     864:      	mov	x22, #0x0               ; =0
     868:      	ldr	q0, [sp, #0xa0]
     86c:      	dup.2d	v0, v0[0]
     870:      	str	q0, [sp, #0x20]
     874:      	add	x28, x25, #0x4, lsl #12 ; =0x4000
     878:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     87c:      	ldr	x9, [x9, #0x80]
     880:      	ldr	q0, [x9]
     884:      	str	q0, [sp, #0x30]
     888:      	add	x25, x27, x26, lsl #2
     88c:      	ld1r.4s	{ v0 }, [x25]
     890:      	str	q0, [sp, #0x60]
     894:      	movi.2d	v26, #0000000000000000
     898:      	str	q26, [sp, #0x80]
     89c:      	cmp	x24, #0x4, lsl #12      ; =0x4000
     8a0:      	b.eq	0xad8 <_kernel+0x3d8>
     8a4:      	ldr	q0, [x23, x24]
     8a8:      	dup.2d	v1, x22
     8ac:      	ldr	q3, [sp, #0x70]
     8b0:      	orr.16b	v1, v1, v3
     8b4:      	orr	x8, x22, #0x2
     8b8:      	dup.2d	v2, x8
     8bc:      	orr.16b	v2, v2, v3
     8c0:      	ldr	q3, [sp, #0xa0]
     8c4:      	cmhs.2d	v1, v3, v1
     8c8:      	cmhs.2d	v2, v3, v2
     8cc:      	cmeq.2d	v1, v1, #0
     8d0:      	cmeq.2d	v2, v2, #0
     8d4:      	uzp1.4s	v1, v1, v2
     8d8:      	ldr	q2, [sp, #0x90]
     8dc:      	bit.16b	v0, v2, v1
     8e0:      	ldr	q1, [sp, #0x60]
     8e4:      	fsub.4s	v0, v0, v1
     8e8:      	bl	0x1ca4 <dyld_stub_binder+0x1ca4>
     8ec:      	str	q0, [x19, x24]
     8f0:      	ldr	q26, [sp, #0x80]
     8f4:      	fadd.4s	v26, v0, v26
     8f8:      	add	x24, x24, #0x10
     8fc:      	cmp	x22, #0xffd
     900:      	add	x22, x22, #0x4
     904:      	b.lo	0x898 <_kernel+0x198>
     908:      	movi.2d	v0, #0000000000000000
     90c:      	ldur	x8, [x29, #-0x90]
     910:      	ldur	x9, [x29, #-0x78]
     914:      	ldr	s1, [x8]
     918:      	cmp	x9, #0x2
     91c:      	b.lo	0xa3c <_kernel+0x33c>
     920:      	cmp	x9, #0x5
     924:      	b.hs	0x930 <_kernel+0x230>
     928:      	mov	w12, #0x1               ; =1
     92c:      	b	0xa24 <_kernel+0x324>
     930:      	sub	x10, x9, #0x1
     934:      	cmp	x9, #0x11
     938:      	b.hs	0x944 <_kernel+0x244>
     93c:      	mov	x11, #0x0               ; =0
     940:      	b	0x9e0 <_kernel+0x2e0>
     944:      	and	x12, x10, #0xc
     948:      	and	x11, x10, #0xfffffffffffffff0
     94c:      	add	x13, x8, #0x24
     950:      	and	x14, x10, #0xfffffffffffffff0
     954:      	ldp	q2, q3, [x13, #-0x20]
     958:      	mov	s4, v2[3]
     95c:      	mov	s5, v2[2]
     960:      	mov	s6, v2[1]
     964:      	mov	s7, v3[3]
     968:      	mov	s16, v3[2]
     96c:      	mov	s17, v3[1]
     970:      	ldp	q18, q19, [x13], #0x40
     974:      	mov	s20, v18[3]
     978:      	mov	s21, v18[2]
     97c:      	mov	s22, v18[1]
     980:      	mov	s23, v19[3]
     984:      	mov	s24, v19[2]
     988:      	mov	s25, v19[1]
     98c:      	fadd	s1, s1, s2
     990:      	fadd	s1, s1, s6
     994:      	fadd	s1, s1, s5
     998:      	fadd	s1, s1, s4
     99c:      	fadd	s1, s1, s3
     9a0:      	fadd	s1, s1, s17
     9a4:      	fadd	s1, s1, s16
     9a8:      	fadd	s1, s1, s7
     9ac:      	fadd	s1, s1, s18
     9b0:      	fadd	s1, s1, s22
     9b4:      	fadd	s1, s1, s21
     9b8:      	fadd	s1, s1, s20
     9bc:      	fadd	s1, s1, s19
     9c0:      	fadd	s1, s1, s25
     9c4:      	fadd	s1, s1, s24
     9c8:      	fadd	s1, s1, s23
     9cc:      	subs	x14, x14, #0x10
     9d0:      	b.ne	0x954 <_kernel+0x254>
     9d4:      	cmp	x10, x11
     9d8:      	b.eq	0xa3c <_kernel+0x33c>
     9dc:      	cbz	x12, 0xb50 <_kernel+0x450>
     9e0:      	and	x13, x10, #0xfffffffffffffffc
     9e4:      	orr	x12, x13, #0x1
     9e8:      	add	x14, x8, x11, lsl #2
     9ec:      	add	x14, x14, #0x4
     9f0:      	sub	x11, x11, x13
     9f4:      	ldr	q2, [x14], #0x10
     9f8:      	mov	s3, v2[3]
     9fc:      	mov	s4, v2[2]
     a00:      	mov	s5, v2[1]
     a04:      	fadd	s1, s1, s2
     a08:      	fadd	s1, s1, s5
     a0c:      	fadd	s1, s1, s4
     a10:      	fadd	s1, s1, s3
     a14:      	adds	x11, x11, #0x4
     a18:      	b.ne	0x9f4 <_kernel+0x2f4>
     a1c:      	cmp	x10, x13
     a20:      	b.eq	0xa3c <_kernel+0x33c>
     a24:      	sub	x9, x9, x12
     a28:      	add	x8, x8, x12, lsl #2
     a2c:      	ldr	s2, [x8], #0x4
     a30:      	fadd	s1, s1, s2
     a34:      	subs	x9, x9, #0x1
     a38:      	b.ne	0xa2c <_kernel+0x32c>
     a3c:      	fadd.4s	v0, v26, v0
     a40:      	dup.2d	v2, v0[1]
     a44:      	fadd.4s	v0, v0, v2
     a48:      	faddp.2s	s0, v0
     a4c:      	fadd	s0, s1, s0
     a50:      	str	s0, [x21, x26, lsl #2]
     a54:      	ldur	x0, [x29, #-0x90]
     a58:      	cbz	x0, 0xa6c <_kernel+0x36c>
     a5c:      	stur	x0, [x29, #-0x88]
     a60:      	ldur	x8, [x29, #-0x80]
     a64:      	sub	x1, x8, x0
     a68:      	bl	0x1d94 <dyld_stub_binder+0x1d94>
     a6c:      	mov	x9, #0x0                ; =0
     a70:      	ldr	x8, [sp, #0x48]
     a74:      	ldr	x10, [sp, #0x58]
     a78:      	add	x8, x8, x10
     a7c:      	add	x8, x8, #0x4, lsl #12   ; =0x4000
     a80:      	mov	x10, #-0x4              ; =-4
     a84:      	cmp	x10, #0xffc
     a88:      	b.eq	0xb38 <_kernel+0x438>
     a8c:      	ldr	q0, [x19, x9]
     a90:      	add	x11, x21, x26, lsl #2
     a94:      	ld1r.4s	{ v1 }, [x11]
     a98:      	fdiv.4s	v0, v0, v1
     a9c:      	str	q0, [x20, x9]
     aa0:      	add	x9, x9, #0x10
     aa4:      	add	x10, x10, #0x4
     aa8:      	cmp	x10, #0xffd
     aac:      	b.lo	0xa84 <_kernel+0x384>
     ab0:      	add	x26, x26, #0x1
     ab4:      	mov	w8, #0x4004             ; =16388
     ab8:      	add	x23, x23, x8
     abc:      	add	x20, x20, x8
     ac0:      	cmp	x26, #0x400
     ac4:      	b.ne	0x794 <_kernel+0x94>
     ac8:      	b	0xb58 <_kernel+0x458>
     acc:      	mov	w8, #0xf2ca             ; =62154
     ad0:      	movk	w8, #0xf149, lsl #16
     ad4:      	b	0x818 <_kernel+0x118>
     ad8:      	ldp	q0, q2, [sp, #0x10]
     adc:      	cmhi.2d	v0, v2, v0
     ae0:      	ldr	q1, [sp]
     ae4:      	cmhi.2d	v1, v2, v1
     ae8:      	uzp1.4s	v0, v1, v0
     aec:      	ldr	s1, [x28]
     af0:      	ldr	q2, [sp, #0x90]
     af4:      	bsl.16b	v0, v1, v2
     af8:      	ld1r.4s	{ v1 }, [x25]
     afc:      	fsub.4s	v0, v0, v1
     b00:      	bl	0x1ca4 <dyld_stub_binder+0x1ca4>
     b04:      	add	x8, x19, #0x4, lsl #12  ; =0x4000
     b08:      	str	s0, [x8]
     b0c:      	movi.2d	v1, #0000000000000000
     b10:      	fadd.4s	v0, v0, v1
     b14:      	ldr	q1, [sp, #0x30]
     b18:      	and.16b	v0, v1, v0
     b1c:      	ldr	q26, [sp, #0x80]
     b20:      	ldur	x8, [x29, #-0x90]
     b24:      	ldur	x9, [x29, #-0x78]
     b28:      	ldr	s1, [x8]
     b2c:      	cmp	x9, #0x2
     b30:      	b.hs	0x920 <_kernel+0x220>
     b34:      	b	0xa3c <_kernel+0x33c>
     b38:      	add	x9, x19, #0x4, lsl #12  ; =0x4000
     b3c:      	ldr	s0, [x9]
     b40:      	ldr	s1, [x21, x26, lsl #2]
     b44:      	fdiv	s0, s0, s1
     b48:      	str	s0, [x8]
     b4c:      	b	0xab0 <_kernel+0x3b0>
     b50:      	orr	x12, x11, #0x1
     b54:      	b	0xa24 <_kernel+0x324>
     b58:      	mov	x0, x19
     b5c:      	bl	0x1d88 <dyld_stub_binder+0x1d88>
     b60:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     b64:      	ldr	x8, [x8, #0xa8]
     b68:      	str	xzr, [x8]
     b6c:      	sub	x8, x29, #0x60
     b70:      	ldapr	w8, [x8]
     b74:      	cbnz	w8, 0xb98 <_kernel+0x498>
     b78:      	ldp	x29, x30, [sp, #0x140]
     b7c:      	ldp	x20, x19, [sp, #0x130]
     b80:      	ldp	x22, x21, [sp, #0x120]
     b84:      	ldp	x24, x23, [sp, #0x110]
     b88:      	ldp	x26, x25, [sp, #0x100]
     b8c:      	ldp	x28, x27, [sp, #0xf0]
     b90:      	add	sp, sp, #0x150
     b94:      	ret
     b98:      	mov	w0, #0x10               ; =16
     b9c:      	bl	0x1db8 <dyld_stub_binder+0x1db8>
     ba0:      	mov	x19, x0
     ba4:      	mov	w8, #0x33d              ; =829
     ba8:      	stur	w8, [x29, #-0x5c]
     bac:      	adrp	x0, 0x2000 <dyld_stub_binder+0x2000>
     bb0:      	add	x0, x0, #0x147
     bb4:      	adrp	x1, 0x2000 <dyld_stub_binder+0x2000>
     bb8:      	add	x1, x1, #0x1d3
     bbc:      	adrp	x3, 0x2000 <dyld_stub_binder+0x2000>
     bc0:      	add	x3, x3, #0x1fe
     bc4:      	adrp	x4, 0x2000 <dyld_stub_binder+0x2000>
     bc8:      	add	x4, x4, #0x27c
     bcc:      	adrp	x2, 0x2000 <dyld_stub_binder+0x2000>
     bd0:      	add	x2, x2, #0x1fb
     bd4:      	sub	x8, x29, #0x90
     bd8:      	sub	x5, x29, #0x5c
     bdc:      	adrp	x7, 0x2000 <dyld_stub_binder+0x2000>
     be0:      	add	x7, x7, #0x27e
     be4:      	mov	x6, x2
     be8:      	bl	0xfdc <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     bec:      	mov	w21, #0x1               ; =1
     bf0:      	sub	x1, x29, #0x90
     bf4:      	mov	x0, x19
     bf8:      	bl	0x1cec <dyld_stub_binder+0x1cec>
     bfc:      	mov	w21, #0x0               ; =0
     c00:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     c04:      	ldr	x1, [x1, #0x18]
     c08:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     c0c:      	ldr	x2, [x2, #0x8]
     c10:      	mov	x0, x19
     c14:      	bl	0x1de8 <dyld_stub_binder+0x1de8>
     c18:      	brk	#0x1
     c1c:      	mov	x20, x0
     c20:      	ldursb	w8, [x29, #-0x79]
     c24:      	tbz	w8, #0x1f, 0xc40 <_kernel+0x540>
     c28:      	ldur	x0, [x29, #-0x90]
     c2c:      	ldur	x8, [x29, #-0x80]
     c30:      	and	x1, x8, #0x7fffffffffffffff
     c34:      	bl	0x1d94 <dyld_stub_binder+0x1d94>
     c38:      	tbnz	w21, #0x0, 0xc4c <_kernel+0x54c>
     c3c:      	b	0xc54 <_kernel+0x554>
     c40:      	cbnz	w21, 0xc4c <_kernel+0x54c>
     c44:      	b	0xc54 <_kernel+0x554>
     c48:      	mov	x20, x0
     c4c:      	mov	x0, x19
     c50:      	bl	0x1ddc <dyld_stub_binder+0x1ddc>
     c54:      	mov	x0, x20
     c58:      	bl	0x1cb0 <dyld_stub_binder+0x1cb0>
     c5c:      	mov	x20, x0
     c60:      	ldur	x0, [x29, #-0x90]
     c64:      	cbz	x0, 0xc78 <_kernel+0x578>
     c68:      	stur	x0, [x29, #-0x88]
     c6c:      	ldur	x8, [x29, #-0x80]
     c70:      	sub	x1, x8, x0
     c74:      	bl	0x1d94 <dyld_stub_binder+0x1d94>
     c78:      	mov	x0, x19
     c7c:      	bl	0x1d88 <dyld_stub_binder+0x1d88>
     c80:      	mov	x0, x20
     c84:      	bl	0x1cb0 <dyld_stub_binder+0x1cb0>

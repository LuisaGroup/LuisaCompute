
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/rmsnorm-257x1538-l1/object/tile_xir_w8_80701_1788919109585635_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x11cc <ltmp0+0x11cc>
       4:      	sub	sp, sp, #0x90
       8:      	stp	d11, d10, [sp, #0x10]
       c:      	stp	d9, d8, [sp, #0x20]
      10:      	stp	x28, x27, [sp, #0x30]
      14:      	stp	x26, x25, [sp, #0x40]
      18:      	stp	x24, x23, [sp, #0x50]
      1c:      	stp	x22, x21, [sp, #0x60]
      20:      	stp	x20, x19, [sp, #0x70]
      24:      	stp	x29, x30, [sp, #0x80]
      28:      	mov	w8, #0x0                ; =0
      2c:      	ldp	w9, w10, [x2, #0x2c]
      30:      	ldp	w5, w6, [x2]
      34:      	adrp	x12, 0x0 <ltmp0>
      38:      	ldr	q0, [x12]
      3c:      	adrp	x12, 0x0 <ltmp0>
      40:      	ldr	q1, [x12]
      44:      	mov	w12, #0x602             ; =1538
      48:      	dup.4s	v2, w12
      4c:      	adrp	x15, 0x0 <ltmp0>
      50:      	ldp	w7, w16, [x2, #0x8]
      54:      	b	0x8c <ltmp0+0x8c>
      58:      	add	w11, w4, #0x1
      5c:      	cmp	w11, w9
      60:      	cset	w11, eq
      64:      	csinc	w5, wzr, w4, eq
      68:      	cinc	w12, w1, eq
      6c:      	cmp	w12, w10
      70:      	cset	w13, eq
      74:      	ands	w11, w11, w13
      78:      	csel	w6, wzr, w12, ne
      7c:      	add	w7, w17, w11
      80:      	add	w8, w8, #0x1
      84:      	cmp	w8, w3
      88:      	b.eq	0x1198 <ltmp0+0x1198>
      8c:      	mov	x17, x7
      90:      	mov	x1, x6
      94:      	mov	x4, x5
      98:      	ubfiz	x5, x5, #5, #32
      9c:      	cmp	x5, x16
      a0:      	csel	x6, x5, xzr, ls
      a4:      	subs	x7, x16, x6
      a8:      	cmp	x7, #0x20
      ac:      	mov	w11, #0x20              ; =32
      b0:      	csel	x7, x7, x11, lo
      b4:      	cmp	x16, x6
      b8:      	ccmp	x5, x16, #0x2, hi
      bc:      	csel	x5, x7, xzr, ls
      c0:      	mov	w11, #0x4000            ; =16384
      c4:      	movk	w11, #0x44c0, lsl #16
      c8:      	dup.4s	v4, w11
      cc:      	mov	w11, #0xc5ac            ; =50604
      d0:      	movk	w11, #0x3727, lsl #16
      d4:      	dup.4s	v3, w11
      d8:      	cmp	x5, #0x20
      dc:      	b.lo	0xaa0 <ltmp0+0xaa0>
      e0:      	mov	x7, #0x0                ; =0
      e4:      	ldr	x5, [x2, #0x88]
      e8:      	ldr	x21, [x0]
      ec:      	ldr	x6, [x0, #0x10]
      f0:      	ldr	x20, [x0, #0x30]
      f4:      	lsl	w19, w4, #5
      f8:      	dup.4s	v5, w19
      fc:      	orr.16b	v6, v5, v0
     100:      	orr.16b	v5, v5, v1
     104:      	umull2.2d	v7, v6, v2
     108:      	umull2.2d	v16, v5, v2
     10c:      	umull.2d	v17, v6, v2
     110:      	umull.2d	v18, v5, v2
     114:      	dup.2d	v5, x21
     118:      	dup.2d	v6, x7
     11c:      	add.2d	v19, v6, v7
     120:      	add.2d	v20, v6, v17
     124:      	add.2d	v21, v6, v16
     128:      	add.2d	v6, v6, v18
     12c:      	shl.2d	v6, v6, #0x2
     130:      	shl.2d	v21, v21, #0x2
     134:      	shl.2d	v20, v20, #0x2
     138:      	shl.2d	v19, v19, #0x2
     13c:      	add.2d	v19, v5, v19
     140:      	add.2d	v20, v5, v20
     144:      	add.2d	v21, v5, v21
     148:      	add.2d	v6, v5, v6
     14c:      	mov.d	x21, v6[1]
     150:      	fmov	x22, d6
     154:      	mov.d	x23, v21[1]
     158:      	fmov	x24, d21
     15c:      	mov.d	x25, v20[1]
     160:      	fmov	x26, d20
     164:      	mov.d	x27, v19[1]
     168:      	ldr	s6, [x22]
     16c:      	ld1.s	{ v6 }[1], [x21]
     170:      	fmov	x21, d19
     174:      	ld1.s	{ v6 }[2], [x24]
     178:      	ld1.s	{ v6 }[3], [x23]
     17c:      	ldr	s19, [x26]
     180:      	ld1.s	{ v19 }[1], [x25]
     184:      	ld1.s	{ v19 }[2], [x21]
     188:      	ld1.s	{ v19 }[3], [x27]
     18c:      	add	x21, x5, x7, lsl #5
     190:      	stp	q6, q19, [x21]
     194:      	add	x7, x7, #0x1
     198:      	cmp	x7, #0x602
     19c:      	b.ne	0x118 <ltmp0+0x118>
     1a0:      	mov	x7, #0x0                ; =0
     1a4:      	ldp	q6, q19, [x5]
     1a8:      	fmul.4s	v20, v19, v19
     1ac:      	fmul.4s	v23, v6, v6
     1b0:      	ldp	q6, q19, [x5, #0x20]
     1b4:      	fmul.4s	v19, v19, v19
     1b8:      	fmul.4s	v22, v6, v6
     1bc:      	ldp	q21, q6, [x5, #0x40]
     1c0:      	fmul.4s	v6, v6, v6
     1c4:      	fmul.4s	v21, v21, v21
     1c8:      	ldp	q24, q25, [x5, #0x60]
     1cc:      	fmul.4s	v25, v25, v25
     1d0:      	fmul.4s	v24, v24, v24
     1d4:      	add	x21, x5, x7, lsl #5
     1d8:      	ldp	q27, q26, [x21, #0x80]
     1dc:      	fmul.4s	v27, v27, v27
     1e0:      	fmul.4s	v26, v26, v26
     1e4:      	fadd.4s	v20, v20, v26
     1e8:      	fadd.4s	v23, v23, v27
     1ec:      	ldp	q27, q26, [x21, #0xa0]
     1f0:      	fmul.4s	v27, v27, v27
     1f4:      	fmul.4s	v26, v26, v26
     1f8:      	fadd.4s	v19, v19, v26
     1fc:      	fadd.4s	v22, v22, v27
     200:      	ldp	q27, q26, [x21, #0xc0]
     204:      	fmul.4s	v27, v27, v27
     208:      	fmul.4s	v26, v26, v26
     20c:      	fadd.4s	v6, v6, v26
     210:      	fadd.4s	v21, v21, v27
     214:      	ldp	q27, q26, [x21, #0xe0]
     218:      	fmul.4s	v27, v27, v27
     21c:      	fmul.4s	v26, v26, v26
     220:      	fadd.4s	v25, v25, v26
     224:      	fadd.4s	v24, v24, v27
     228:      	add	x7, x7, #0x4
     22c:      	cmp	x7, #0x5fc
     230:      	b.lo	0x1d4 <ltmp0+0x1d4>
     234:      	mov	w11, #0xc040            ; =49216
     238:      	add	x7, x5, x11
     23c:      	ldr	q28, [x5, #0xc010]
     240:      	ldr	q27, [x5, #0xc000]
     244:      	ldr	q26, [x5, #0xc030]
     248:      	mov	x21, x6
     24c:      	mov	w22, #0x602             ; =1538
     250:      	ldr	q29, [x5, #0xc020]
     254:      	ld1r.4s	{ v30 }, [x21], #4
     258:      	add	x23, x5, x22, lsl #5
     25c:      	stp	q30, q30, [x23]
     260:      	add	x22, x22, #0x1
     264:      	cmp	x22, #0xc04
     268:      	b.ne	0x254 <ltmp0+0x254>
     26c:      	mov	x21, #0x0               ; =0
     270:      	fmul.4s	v28, v28, v28
     274:      	fmul.4s	v27, v27, v27
     278:      	fadd.4s	v23, v23, v27
     27c:      	fadd.4s	v20, v20, v28
     280:      	fmul.4s	v26, v26, v26
     284:      	fmul.4s	v27, v29, v29
     288:      	fadd.4s	v22, v22, v27
     28c:      	fadd.4s	v19, v19, v26
     290:      	fadd.4s	v19, v20, v19
     294:      	fadd.4s	v20, v23, v22
     298:      	fadd.4s	v20, v21, v20
     29c:      	fadd.4s	v6, v6, v19
     2a0:      	fadd.4s	v6, v25, v6
     2a4:      	fadd.4s	v19, v24, v20
     2a8:      	fdiv.4s	v19, v19, v4
     2ac:      	fdiv.4s	v6, v6, v4
     2b0:      	fadd.4s	v6, v6, v3
     2b4:      	fadd.4s	v19, v19, v3
     2b8:      	fsqrt.4s	v19, v19
     2bc:      	fsqrt.4s	v20, v6
     2c0:      	dup.2d	v6, x21
     2c4:      	add.2d	v21, v6, v7
     2c8:      	add.2d	v22, v6, v17
     2cc:      	add.2d	v23, v6, v16
     2d0:      	add.2d	v6, v6, v18
     2d4:      	lsl	x22, x21, #5
     2d8:      	add	x23, x5, x22
     2dc:      	ldp	q25, q24, [x23]
     2e0:      	fdiv.4s	v25, v25, v19
     2e4:      	fdiv.4s	v24, v24, v20
     2e8:      	add	x22, x7, x22
     2ec:      	ldp	q26, q27, [x22]
     2f0:      	fmul.4s	v24, v24, v27
     2f4:      	fmul.4s	v25, v25, v26
     2f8:      	shl.2d	v26, v6, #0x2
     2fc:      	shl.2d	v23, v23, #0x2
     300:      	shl.2d	v22, v22, #0x2
     304:      	shl.2d	v21, v21, #0x2
     308:      	dup.2d	v6, x20
     30c:      	add.2d	v21, v6, v21
     310:      	add.2d	v26, v6, v26
     314:      	mov.d	x22, v26[1]
     318:      	fmov	x23, d26
     31c:      	str	s25, [x23]
     320:      	st1.s	{ v25 }[1], [x22]
     324:      	add.2d	v23, v6, v23
     328:      	mov.d	x22, v23[1]
     32c:      	fmov	x23, d23
     330:      	st1.s	{ v25 }[2], [x23]
     334:      	add.2d	v22, v6, v22
     338:      	st1.s	{ v25 }[3], [x22]
     33c:      	mov.d	x22, v22[1]
     340:      	fmov	x23, d22
     344:      	str	s24, [x23]
     348:      	st1.s	{ v24 }[1], [x22]
     34c:      	mov.d	x22, v21[1]
     350:      	fmov	x23, d21
     354:      	st1.s	{ v24 }[2], [x23]
     358:      	st1.s	{ v24 }[3], [x22]
     35c:      	add	x21, x21, #0x1
     360:      	cmp	x21, #0x602
     364:      	b.ne	0x2c0 <ltmp0+0x2c0>
     368:      	mov	x20, #0x0               ; =0
     36c:      	orr	w21, w19, #0x8
     370:      	dup.4s	v7, w21
     374:      	orr.16b	v17, v7, v0
     378:      	orr.16b	v18, v7, v1
     37c:      	umull2.2d	v7, v17, v2
     380:      	umull2.2d	v16, v18, v2
     384:      	umull.2d	v17, v17, v2
     388:      	umull.2d	v18, v18, v2
     38c:      	dup.2d	v19, x20
     390:      	add.2d	v20, v19, v7
     394:      	add.2d	v21, v19, v17
     398:      	add.2d	v22, v19, v16
     39c:      	add.2d	v19, v19, v18
     3a0:      	shl.2d	v19, v19, #0x2
     3a4:      	shl.2d	v22, v22, #0x2
     3a8:      	shl.2d	v21, v21, #0x2
     3ac:      	shl.2d	v20, v20, #0x2
     3b0:      	add.2d	v20, v5, v20
     3b4:      	add.2d	v21, v5, v21
     3b8:      	add.2d	v22, v5, v22
     3bc:      	add.2d	v19, v5, v19
     3c0:      	mov.d	x21, v19[1]
     3c4:      	fmov	x22, d19
     3c8:      	mov.d	x23, v22[1]
     3cc:      	fmov	x24, d22
     3d0:      	mov.d	x25, v21[1]
     3d4:      	fmov	x26, d21
     3d8:      	mov.d	x27, v20[1]
     3dc:      	ldr	s19, [x22]
     3e0:      	ld1.s	{ v19 }[1], [x21]
     3e4:      	fmov	x21, d20
     3e8:      	ld1.s	{ v19 }[2], [x24]
     3ec:      	ld1.s	{ v19 }[3], [x23]
     3f0:      	ldr	s20, [x26]
     3f4:      	ld1.s	{ v20 }[1], [x25]
     3f8:      	ld1.s	{ v20 }[2], [x21]
     3fc:      	ld1.s	{ v20 }[3], [x27]
     400:      	add	x21, x5, x20, lsl #5
     404:      	stp	q19, q20, [x21]
     408:      	add	x20, x20, #0x1
     40c:      	cmp	x20, #0x602
     410:      	b.ne	0x38c <ltmp0+0x38c>
     414:      	mov	x20, #0x0               ; =0
     418:      	ldp	q19, q20, [x5]
     41c:      	fmul.4s	v21, v20, v20
     420:      	fmul.4s	v24, v19, v19
     424:      	ldp	q19, q20, [x5, #0x20]
     428:      	fmul.4s	v20, v20, v20
     42c:      	fmul.4s	v23, v19, v19
     430:      	ldp	q22, q19, [x5, #0x40]
     434:      	fmul.4s	v19, v19, v19
     438:      	fmul.4s	v22, v22, v22
     43c:      	ldp	q25, q26, [x5, #0x60]
     440:      	fmul.4s	v26, v26, v26
     444:      	fmul.4s	v25, v25, v25
     448:      	add	x21, x5, x20, lsl #5
     44c:      	ldp	q28, q27, [x21, #0x80]
     450:      	fmul.4s	v28, v28, v28
     454:      	fmul.4s	v27, v27, v27
     458:      	fadd.4s	v21, v21, v27
     45c:      	fadd.4s	v24, v24, v28
     460:      	ldp	q28, q27, [x21, #0xa0]
     464:      	fmul.4s	v28, v28, v28
     468:      	fmul.4s	v27, v27, v27
     46c:      	fadd.4s	v20, v20, v27
     470:      	fadd.4s	v23, v23, v28
     474:      	ldp	q28, q27, [x21, #0xc0]
     478:      	fmul.4s	v28, v28, v28
     47c:      	fmul.4s	v27, v27, v27
     480:      	fadd.4s	v19, v19, v27
     484:      	fadd.4s	v22, v22, v28
     488:      	ldp	q28, q27, [x21, #0xe0]
     48c:      	fmul.4s	v28, v28, v28
     490:      	fmul.4s	v27, v27, v27
     494:      	fadd.4s	v26, v26, v27
     498:      	fadd.4s	v25, v25, v28
     49c:      	add	x20, x20, #0x4
     4a0:      	cmp	x20, #0x5fc
     4a4:      	b.lo	0x448 <ltmp0+0x448>
     4a8:      	ldr	q29, [x5, #0xc010]
     4ac:      	ldr	q28, [x5, #0xc000]
     4b0:      	ldr	q27, [x5, #0xc030]
     4b4:      	mov	x20, x6
     4b8:      	mov	w21, #0x602             ; =1538
     4bc:      	ldr	q30, [x5, #0xc020]
     4c0:      	ld1r.4s	{ v31 }, [x20], #4
     4c4:      	add	x22, x5, x21, lsl #5
     4c8:      	stp	q31, q31, [x22]
     4cc:      	add	x21, x21, #0x1
     4d0:      	cmp	x21, #0xc04
     4d4:      	b.ne	0x4c0 <ltmp0+0x4c0>
     4d8:      	mov	x20, #0x0               ; =0
     4dc:      	fmul.4s	v29, v29, v29
     4e0:      	fmul.4s	v28, v28, v28
     4e4:      	fadd.4s	v24, v24, v28
     4e8:      	fadd.4s	v21, v21, v29
     4ec:      	fmul.4s	v27, v27, v27
     4f0:      	fmul.4s	v28, v30, v30
     4f4:      	fadd.4s	v23, v23, v28
     4f8:      	fadd.4s	v20, v20, v27
     4fc:      	fadd.4s	v20, v21, v20
     500:      	fadd.4s	v21, v24, v23
     504:      	fadd.4s	v21, v22, v21
     508:      	fadd.4s	v19, v19, v20
     50c:      	fadd.4s	v19, v26, v19
     510:      	fadd.4s	v20, v25, v21
     514:      	fdiv.4s	v20, v20, v4
     518:      	fdiv.4s	v19, v19, v4
     51c:      	fadd.4s	v21, v19, v3
     520:      	fadd.4s	v19, v20, v3
     524:      	fsqrt.4s	v19, v19
     528:      	fsqrt.4s	v20, v21
     52c:      	dup.2d	v21, x20
     530:      	add.2d	v22, v21, v7
     534:      	add.2d	v23, v21, v17
     538:      	add.2d	v24, v21, v16
     53c:      	add.2d	v21, v21, v18
     540:      	lsl	x21, x20, #5
     544:      	add	x22, x5, x21
     548:      	ldp	q26, q25, [x22]
     54c:      	fdiv.4s	v26, v26, v19
     550:      	fdiv.4s	v25, v25, v20
     554:      	add	x21, x7, x21
     558:      	ldp	q27, q28, [x21]
     55c:      	fmul.4s	v25, v25, v28
     560:      	fmul.4s	v26, v26, v27
     564:      	shl.2d	v21, v21, #0x2
     568:      	shl.2d	v24, v24, #0x2
     56c:      	shl.2d	v23, v23, #0x2
     570:      	shl.2d	v22, v22, #0x2
     574:      	add.2d	v22, v6, v22
     578:      	add.2d	v21, v6, v21
     57c:      	mov.d	x21, v21[1]
     580:      	fmov	x22, d21
     584:      	str	s26, [x22]
     588:      	st1.s	{ v26 }[1], [x21]
     58c:      	add.2d	v21, v6, v24
     590:      	mov.d	x21, v21[1]
     594:      	fmov	x22, d21
     598:      	st1.s	{ v26 }[2], [x22]
     59c:      	add.2d	v21, v6, v23
     5a0:      	st1.s	{ v26 }[3], [x21]
     5a4:      	mov.d	x21, v21[1]
     5a8:      	fmov	x22, d21
     5ac:      	str	s25, [x22]
     5b0:      	st1.s	{ v25 }[1], [x21]
     5b4:      	mov.d	x21, v22[1]
     5b8:      	fmov	x22, d22
     5bc:      	st1.s	{ v25 }[2], [x22]
     5c0:      	st1.s	{ v25 }[3], [x21]
     5c4:      	add	x20, x20, #0x1
     5c8:      	cmp	x20, #0x602
     5cc:      	b.ne	0x52c <ltmp0+0x52c>
     5d0:      	mov	x20, #0x0               ; =0
     5d4:      	orr	w21, w19, #0x10
     5d8:      	dup.4s	v7, w21
     5dc:      	orr.16b	v17, v7, v0
     5e0:      	orr.16b	v18, v7, v1
     5e4:      	umull2.2d	v7, v17, v2
     5e8:      	umull2.2d	v16, v18, v2
     5ec:      	umull.2d	v17, v17, v2
     5f0:      	umull.2d	v18, v18, v2
     5f4:      	dup.2d	v19, x20
     5f8:      	add.2d	v20, v19, v7
     5fc:      	add.2d	v21, v19, v17
     600:      	add.2d	v22, v19, v16
     604:      	add.2d	v19, v19, v18
     608:      	shl.2d	v19, v19, #0x2
     60c:      	shl.2d	v22, v22, #0x2
     610:      	shl.2d	v21, v21, #0x2
     614:      	shl.2d	v20, v20, #0x2
     618:      	add.2d	v20, v5, v20
     61c:      	add.2d	v21, v5, v21
     620:      	add.2d	v22, v5, v22
     624:      	add.2d	v19, v5, v19
     628:      	mov.d	x21, v19[1]
     62c:      	fmov	x22, d19
     630:      	mov.d	x23, v22[1]
     634:      	fmov	x24, d22
     638:      	mov.d	x25, v21[1]
     63c:      	fmov	x26, d21
     640:      	mov.d	x27, v20[1]
     644:      	ldr	s19, [x22]
     648:      	ld1.s	{ v19 }[1], [x21]
     64c:      	fmov	x21, d20
     650:      	ld1.s	{ v19 }[2], [x24]
     654:      	ld1.s	{ v19 }[3], [x23]
     658:      	ldr	s20, [x26]
     65c:      	ld1.s	{ v20 }[1], [x25]
     660:      	ld1.s	{ v20 }[2], [x21]
     664:      	ld1.s	{ v20 }[3], [x27]
     668:      	add	x21, x5, x20, lsl #5
     66c:      	stp	q19, q20, [x21]
     670:      	add	x20, x20, #0x1
     674:      	cmp	x20, #0x602
     678:      	b.ne	0x5f4 <ltmp0+0x5f4>
     67c:      	mov	x20, #0x0               ; =0
     680:      	ldp	q19, q20, [x5]
     684:      	fmul.4s	v21, v20, v20
     688:      	fmul.4s	v24, v19, v19
     68c:      	ldp	q19, q20, [x5, #0x20]
     690:      	fmul.4s	v20, v20, v20
     694:      	fmul.4s	v23, v19, v19
     698:      	ldp	q22, q19, [x5, #0x40]
     69c:      	fmul.4s	v19, v19, v19
     6a0:      	fmul.4s	v22, v22, v22
     6a4:      	ldp	q25, q26, [x5, #0x60]
     6a8:      	fmul.4s	v26, v26, v26
     6ac:      	fmul.4s	v25, v25, v25
     6b0:      	add	x21, x5, x20, lsl #5
     6b4:      	ldp	q28, q27, [x21, #0x80]
     6b8:      	fmul.4s	v28, v28, v28
     6bc:      	fmul.4s	v27, v27, v27
     6c0:      	fadd.4s	v21, v21, v27
     6c4:      	fadd.4s	v24, v24, v28
     6c8:      	ldp	q28, q27, [x21, #0xa0]
     6cc:      	fmul.4s	v28, v28, v28
     6d0:      	fmul.4s	v27, v27, v27
     6d4:      	fadd.4s	v20, v20, v27
     6d8:      	fadd.4s	v23, v23, v28
     6dc:      	ldp	q28, q27, [x21, #0xc0]
     6e0:      	fmul.4s	v28, v28, v28
     6e4:      	fmul.4s	v27, v27, v27
     6e8:      	fadd.4s	v19, v19, v27
     6ec:      	fadd.4s	v22, v22, v28
     6f0:      	ldp	q28, q27, [x21, #0xe0]
     6f4:      	fmul.4s	v28, v28, v28
     6f8:      	fmul.4s	v27, v27, v27
     6fc:      	fadd.4s	v26, v26, v27
     700:      	fadd.4s	v25, v25, v28
     704:      	add	x20, x20, #0x4
     708:      	cmp	x20, #0x5fc
     70c:      	b.lo	0x6b0 <ltmp0+0x6b0>
     710:      	ldr	q29, [x5, #0xc010]
     714:      	ldr	q28, [x5, #0xc000]
     718:      	ldr	q27, [x5, #0xc030]
     71c:      	mov	x20, x6
     720:      	mov	w21, #0x602             ; =1538
     724:      	ldr	q30, [x5, #0xc020]
     728:      	ld1r.4s	{ v31 }, [x20], #4
     72c:      	add	x22, x5, x21, lsl #5
     730:      	stp	q31, q31, [x22]
     734:      	add	x21, x21, #0x1
     738:      	cmp	x21, #0xc04
     73c:      	b.ne	0x728 <ltmp0+0x728>
     740:      	mov	x20, #0x0               ; =0
     744:      	fmul.4s	v29, v29, v29
     748:      	fmul.4s	v28, v28, v28
     74c:      	fadd.4s	v24, v24, v28
     750:      	fadd.4s	v21, v21, v29
     754:      	fmul.4s	v27, v27, v27
     758:      	fmul.4s	v28, v30, v30
     75c:      	fadd.4s	v23, v23, v28
     760:      	fadd.4s	v20, v20, v27
     764:      	fadd.4s	v20, v21, v20
     768:      	fadd.4s	v21, v24, v23
     76c:      	fadd.4s	v21, v22, v21
     770:      	fadd.4s	v19, v19, v20
     774:      	fadd.4s	v19, v26, v19
     778:      	fadd.4s	v20, v25, v21
     77c:      	fdiv.4s	v20, v20, v4
     780:      	fdiv.4s	v19, v19, v4
     784:      	fadd.4s	v21, v19, v3
     788:      	fadd.4s	v19, v20, v3
     78c:      	fsqrt.4s	v19, v19
     790:      	fsqrt.4s	v20, v21
     794:      	dup.2d	v21, x20
     798:      	add.2d	v22, v21, v7
     79c:      	add.2d	v23, v21, v17
     7a0:      	add.2d	v24, v21, v16
     7a4:      	add.2d	v21, v21, v18
     7a8:      	lsl	x21, x20, #5
     7ac:      	add	x22, x5, x21
     7b0:      	ldp	q26, q25, [x22]
     7b4:      	fdiv.4s	v26, v26, v19
     7b8:      	fdiv.4s	v25, v25, v20
     7bc:      	add	x21, x7, x21
     7c0:      	ldp	q27, q28, [x21]
     7c4:      	fmul.4s	v25, v25, v28
     7c8:      	fmul.4s	v26, v26, v27
     7cc:      	shl.2d	v21, v21, #0x2
     7d0:      	shl.2d	v24, v24, #0x2
     7d4:      	shl.2d	v23, v23, #0x2
     7d8:      	shl.2d	v22, v22, #0x2
     7dc:      	add.2d	v22, v6, v22
     7e0:      	add.2d	v21, v6, v21
     7e4:      	mov.d	x21, v21[1]
     7e8:      	fmov	x22, d21
     7ec:      	str	s26, [x22]
     7f0:      	st1.s	{ v26 }[1], [x21]
     7f4:      	add.2d	v21, v6, v24
     7f8:      	mov.d	x21, v21[1]
     7fc:      	fmov	x22, d21
     800:      	st1.s	{ v26 }[2], [x22]
     804:      	add.2d	v21, v6, v23
     808:      	st1.s	{ v26 }[3], [x21]
     80c:      	mov.d	x21, v21[1]
     810:      	fmov	x22, d21
     814:      	str	s25, [x22]
     818:      	st1.s	{ v25 }[1], [x21]
     81c:      	mov.d	x21, v22[1]
     820:      	fmov	x22, d22
     824:      	st1.s	{ v25 }[2], [x22]
     828:      	st1.s	{ v25 }[3], [x21]
     82c:      	add	x20, x20, #0x1
     830:      	cmp	x20, #0x602
     834:      	b.ne	0x794 <ltmp0+0x794>
     838:      	mov	x20, #0x0               ; =0
     83c:      	orr	w19, w19, #0x18
     840:      	dup.4s	v7, w19
     844:      	orr.16b	v17, v7, v0
     848:      	orr.16b	v18, v7, v1
     84c:      	umull2.2d	v7, v17, v2
     850:      	umull2.2d	v16, v18, v2
     854:      	umull.2d	v17, v17, v2
     858:      	umull.2d	v18, v18, v2
     85c:      	dup.2d	v19, x20
     860:      	add.2d	v20, v19, v7
     864:      	add.2d	v21, v19, v17
     868:      	add.2d	v22, v19, v16
     86c:      	add.2d	v19, v19, v18
     870:      	shl.2d	v19, v19, #0x2
     874:      	shl.2d	v22, v22, #0x2
     878:      	shl.2d	v21, v21, #0x2
     87c:      	shl.2d	v20, v20, #0x2
     880:      	add.2d	v20, v5, v20
     884:      	add.2d	v21, v5, v21
     888:      	add.2d	v22, v5, v22
     88c:      	add.2d	v19, v5, v19
     890:      	mov.d	x19, v19[1]
     894:      	fmov	x21, d19
     898:      	mov.d	x22, v22[1]
     89c:      	fmov	x23, d22
     8a0:      	mov.d	x24, v21[1]
     8a4:      	fmov	x25, d21
     8a8:      	mov.d	x26, v20[1]
     8ac:      	ldr	s19, [x21]
     8b0:      	ld1.s	{ v19 }[1], [x19]
     8b4:      	fmov	x19, d20
     8b8:      	ld1.s	{ v19 }[2], [x23]
     8bc:      	ld1.s	{ v19 }[3], [x22]
     8c0:      	ldr	s20, [x25]
     8c4:      	ld1.s	{ v20 }[1], [x24]
     8c8:      	ld1.s	{ v20 }[2], [x19]
     8cc:      	ld1.s	{ v20 }[3], [x26]
     8d0:      	add	x19, x5, x20, lsl #5
     8d4:      	stp	q19, q20, [x19]
     8d8:      	add	x20, x20, #0x1
     8dc:      	cmp	x20, #0x602
     8e0:      	b.ne	0x85c <ltmp0+0x85c>
     8e4:      	ldp	q5, q19, [x5]
     8e8:      	fmul.4s	v20, v19, v19
     8ec:      	fmul.4s	v23, v5, v5
     8f0:      	ldp	q5, q19, [x5, #0x20]
     8f4:      	fmul.4s	v19, v19, v19
     8f8:      	fmul.4s	v22, v5, v5
     8fc:      	ldp	q21, q5, [x5, #0x40]
     900:      	fmul.4s	v5, v5, v5
     904:      	fmul.4s	v21, v21, v21
     908:      	ldp	q24, q25, [x5, #0x60]
     90c:      	fmul.4s	v25, v25, v25
     910:      	fmul.4s	v24, v24, v24
     914:      	add	x19, x5, #0xe0
     918:      	mov	w20, #0x4               ; =4
     91c:      	ldp	q27, q26, [x19, #-0x60]
     920:      	fmul.4s	v27, v27, v27
     924:      	fmul.4s	v26, v26, v26
     928:      	fadd.4s	v20, v20, v26
     92c:      	fadd.4s	v23, v23, v27
     930:      	ldp	q27, q26, [x19, #-0x40]
     934:      	fmul.4s	v27, v27, v27
     938:      	fmul.4s	v26, v26, v26
     93c:      	fadd.4s	v19, v19, v26
     940:      	fadd.4s	v22, v22, v27
     944:      	ldp	q27, q26, [x19, #-0x20]
     948:      	fmul.4s	v27, v27, v27
     94c:      	fmul.4s	v26, v26, v26
     950:      	fadd.4s	v5, v5, v26
     954:      	fadd.4s	v21, v21, v27
     958:      	ldp	q27, q26, [x19], #0x80
     95c:      	fmul.4s	v27, v27, v27
     960:      	fmul.4s	v26, v26, v26
     964:      	fadd.4s	v25, v25, v26
     968:      	fadd.4s	v24, v24, v27
     96c:      	cmp	x20, #0x5fc
     970:      	add	x20, x20, #0x4
     974:      	b.lo	0x91c <ltmp0+0x91c>
     978:      	mov	x19, #0x0               ; =0
     97c:      	ldr	q29, [x5, #0xc010]
     980:      	ldr	q28, [x5, #0xc000]
     984:      	ldr	q27, [x5, #0xc030]
     988:      	ldr	q26, [x5, #0xc020]
     98c:      	add	x20, x6, x19, lsl #2
     990:      	ld1r.4s	{ v30 }, [x20]
     994:      	add	x20, x7, x19, lsl #5
     998:      	stp	q30, q30, [x20]
     99c:      	add	x19, x19, #0x1
     9a0:      	cmp	x19, #0x602
     9a4:      	b.ne	0x98c <ltmp0+0x98c>
     9a8:      	fmul.4s	v29, v29, v29
     9ac:      	fmul.4s	v28, v28, v28
     9b0:      	fadd.4s	v23, v23, v28
     9b4:      	fadd.4s	v20, v20, v29
     9b8:      	fmul.4s	v27, v27, v27
     9bc:      	fmul.4s	v26, v26, v26
     9c0:      	fadd.4s	v22, v22, v26
     9c4:      	fadd.4s	v19, v19, v27
     9c8:      	fadd.4s	v19, v20, v19
     9cc:      	fadd.4s	v20, v23, v22
     9d0:      	fadd.4s	v20, v21, v20
     9d4:      	fadd.4s	v5, v5, v19
     9d8:      	fadd.4s	v5, v25, v5
     9dc:      	fadd.4s	v19, v24, v20
     9e0:      	fdiv.4s	v19, v19, v4
     9e4:      	fdiv.4s	v4, v5, v4
     9e8:      	fadd.4s	v4, v4, v3
     9ec:      	fadd.4s	v3, v19, v3
     9f0:      	fsqrt.4s	v3, v3
     9f4:      	fsqrt.4s	v4, v4
     9f8:      	mov	x6, #-0x602             ; =-1538
     9fc:      	add	x7, x6, #0x602
     a00:      	dup.2d	v5, x7
     a04:      	add.2d	v19, v5, v7
     a08:      	add.2d	v20, v5, v17
     a0c:      	add.2d	v21, v5, v16
     a10:      	add.2d	v5, v5, v18
     a14:      	ldp	q23, q22, [x5]
     a18:      	fdiv.4s	v23, v23, v3
     a1c:      	fdiv.4s	v22, v22, v4
     a20:      	ldr	q24, [x5, #0xc040]
     a24:      	ldr	q25, [x5, #0xc050]
     a28:      	fmul.4s	v22, v22, v25
     a2c:      	fmul.4s	v23, v23, v24
     a30:      	shl.2d	v5, v5, #0x2
     a34:      	shl.2d	v21, v21, #0x2
     a38:      	shl.2d	v20, v20, #0x2
     a3c:      	shl.2d	v19, v19, #0x2
     a40:      	add.2d	v19, v6, v19
     a44:      	add.2d	v5, v6, v5
     a48:      	mov.d	x7, v5[1]
     a4c:      	fmov	x19, d5
     a50:      	str	s23, [x19]
     a54:      	st1.s	{ v23 }[1], [x7]
     a58:      	add.2d	v5, v6, v21
     a5c:      	mov.d	x7, v5[1]
     a60:      	fmov	x19, d5
     a64:      	st1.s	{ v23 }[2], [x19]
     a68:      	add.2d	v5, v6, v20
     a6c:      	st1.s	{ v23 }[3], [x7]
     a70:      	mov.d	x7, v5[1]
     a74:      	fmov	x19, d5
     a78:      	str	s22, [x19]
     a7c:      	st1.s	{ v22 }[1], [x7]
     a80:      	mov.d	x7, v19[1]
     a84:      	fmov	x19, d19
     a88:      	st1.s	{ v22 }[2], [x19]
     a8c:      	st1.s	{ v22 }[3], [x7]
     a90:      	add	x5, x5, #0x20
     a94:      	adds	x6, x6, #0x1
     a98:      	b.lo	0x9fc <ltmp0+0x9fc>
     a9c:      	b	0x58 <ltmp0+0x58>
     aa0:      	lsr	x6, x5, #3
     aa4:      	cmp	x5, #0x8
     aa8:      	b.lo	0xd4c <ltmp0+0xd4c>
     aac:      	mov	w7, #0x0                ; =0
     ab0:      	ldr	x19, [x2, #0x88]
     ab4:      	ldr	x20, [x0]
     ab8:      	ldr	x21, [x0, #0x10]
     abc:      	ldr	x22, [x0, #0x30]
     ac0:      	lsl	w23, w4, #5
     ac4:      	mov	w11, #0xc040            ; =49216
     ac8:      	add	x24, x19, x11
     acc:      	add	x25, x19, #0xe0
     ad0:      	mov	x26, #0x0               ; =0
     ad4:      	add	w27, w23, w7, lsl #3
     ad8:      	dup.4s	v5, w27
     adc:      	orr.16b	v7, v5, v0
     ae0:      	orr.16b	v16, v5, v1
     ae4:      	umull2.2d	v5, v7, v2
     ae8:      	umull2.2d	v6, v16, v2
     aec:      	umull.2d	v7, v7, v2
     af0:      	umull.2d	v16, v16, v2
     af4:      	dup.2d	v17, x26
     af8:      	add.2d	v18, v17, v5
     afc:      	add.2d	v19, v17, v7
     b00:      	add.2d	v20, v17, v6
     b04:      	add.2d	v17, v17, v16
     b08:      	shl.2d	v17, v17, #0x2
     b0c:      	shl.2d	v20, v20, #0x2
     b10:      	shl.2d	v19, v19, #0x2
     b14:      	shl.2d	v18, v18, #0x2
     b18:      	dup.2d	v21, x20
     b1c:      	add.2d	v18, v21, v18
     b20:      	add.2d	v19, v21, v19
     b24:      	add.2d	v20, v21, v20
     b28:      	add.2d	v17, v21, v17
     b2c:      	mov.d	x27, v17[1]
     b30:      	fmov	x28, d17
     b34:      	mov.d	x30, v20[1]
     b38:      	fmov	x12, d20
     b3c:      	mov.d	x11, v19[1]
     b40:      	fmov	x13, d19
     b44:      	mov.d	x14, v18[1]
     b48:      	ldr	s17, [x28]
     b4c:      	ld1.s	{ v17 }[1], [x27]
     b50:      	fmov	x27, d18
     b54:      	ld1.s	{ v17 }[2], [x12]
     b58:      	ld1.s	{ v17 }[3], [x30]
     b5c:      	ldr	s18, [x13]
     b60:      	ld1.s	{ v18 }[1], [x11]
     b64:      	ld1.s	{ v18 }[2], [x27]
     b68:      	ld1.s	{ v18 }[3], [x14]
     b6c:      	add	x11, x19, x26, lsl #5
     b70:      	stp	q17, q18, [x11]
     b74:      	add	x26, x26, #0x1
     b78:      	cmp	x26, #0x602
     b7c:      	b.ne	0xaf4 <ltmp0+0xaf4>
     b80:      	ldp	q17, q18, [x19]
     b84:      	fmul.4s	v19, v18, v18
     b88:      	fmul.4s	v22, v17, v17
     b8c:      	ldp	q17, q18, [x19, #0x20]
     b90:      	fmul.4s	v18, v18, v18
     b94:      	fmul.4s	v21, v17, v17
     b98:      	ldp	q20, q17, [x19, #0x40]
     b9c:      	fmul.4s	v17, v17, v17
     ba0:      	fmul.4s	v20, v20, v20
     ba4:      	ldp	q23, q24, [x19, #0x60]
     ba8:      	fmul.4s	v24, v24, v24
     bac:      	fmul.4s	v23, v23, v23
     bb0:      	mov	x26, x25
     bb4:      	mov	w27, #0x4               ; =4
     bb8:      	ldp	q26, q25, [x26, #-0x60]
     bbc:      	fmul.4s	v26, v26, v26
     bc0:      	fmul.4s	v25, v25, v25
     bc4:      	fadd.4s	v19, v19, v25
     bc8:      	fadd.4s	v22, v22, v26
     bcc:      	ldp	q26, q25, [x26, #-0x40]
     bd0:      	fmul.4s	v26, v26, v26
     bd4:      	fmul.4s	v25, v25, v25
     bd8:      	fadd.4s	v18, v18, v25
     bdc:      	fadd.4s	v21, v21, v26
     be0:      	ldp	q26, q25, [x26, #-0x20]
     be4:      	fmul.4s	v26, v26, v26
     be8:      	fmul.4s	v25, v25, v25
     bec:      	fadd.4s	v17, v17, v25
     bf0:      	fadd.4s	v20, v20, v26
     bf4:      	ldp	q26, q25, [x26], #0x80
     bf8:      	fmul.4s	v26, v26, v26
     bfc:      	fmul.4s	v25, v25, v25
     c00:      	fadd.4s	v24, v24, v25
     c04:      	fadd.4s	v23, v23, v26
     c08:      	cmp	x27, #0x5fc
     c0c:      	add	x27, x27, #0x4
     c10:      	b.lo	0xbb8 <ltmp0+0xbb8>
     c14:      	mov	x26, #0x0               ; =0
     c18:      	ldr	q28, [x19, #0xc010]
     c1c:      	ldr	q27, [x19, #0xc000]
     c20:      	ldr	q26, [x19, #0xc030]
     c24:      	ldr	q25, [x19, #0xc020]
     c28:      	add	x11, x21, x26, lsl #2
     c2c:      	ld1r.4s	{ v29 }, [x11]
     c30:      	add	x11, x24, x26, lsl #5
     c34:      	stp	q29, q29, [x11]
     c38:      	add	x26, x26, #0x1
     c3c:      	cmp	x26, #0x602
     c40:      	b.ne	0xc28 <ltmp0+0xc28>
     c44:      	fmul.4s	v28, v28, v28
     c48:      	fmul.4s	v27, v27, v27
     c4c:      	fadd.4s	v22, v22, v27
     c50:      	fadd.4s	v19, v19, v28
     c54:      	fmul.4s	v26, v26, v26
     c58:      	fmul.4s	v25, v25, v25
     c5c:      	fadd.4s	v21, v21, v25
     c60:      	fadd.4s	v18, v18, v26
     c64:      	fadd.4s	v18, v19, v18
     c68:      	fadd.4s	v19, v22, v21
     c6c:      	fadd.4s	v19, v20, v19
     c70:      	fadd.4s	v17, v17, v18
     c74:      	fadd.4s	v17, v24, v17
     c78:      	fadd.4s	v18, v23, v19
     c7c:      	fdiv.4s	v18, v18, v4
     c80:      	fdiv.4s	v17, v17, v4
     c84:      	fadd.4s	v19, v17, v3
     c88:      	fadd.4s	v17, v18, v3
     c8c:      	fsqrt.4s	v17, v17
     c90:      	fsqrt.4s	v18, v19
     c94:      	mov	x26, #-0x602            ; =-1538
     c98:      	mov	x27, x19
     c9c:      	add	x11, x26, #0x602
     ca0:      	dup.2d	v19, x11
     ca4:      	add.2d	v20, v19, v5
     ca8:      	add.2d	v21, v19, v7
     cac:      	add.2d	v22, v19, v6
     cb0:      	add.2d	v19, v19, v16
     cb4:      	ldp	q24, q23, [x27]
     cb8:      	fdiv.4s	v24, v24, v17
     cbc:      	fdiv.4s	v23, v23, v18
     cc0:      	ldr	q25, [x27, #0xc040]
     cc4:      	ldr	q26, [x27, #0xc050]
     cc8:      	fmul.4s	v23, v23, v26
     ccc:      	fmul.4s	v24, v24, v25
     cd0:      	shl.2d	v19, v19, #0x2
     cd4:      	shl.2d	v22, v22, #0x2
     cd8:      	shl.2d	v21, v21, #0x2
     cdc:      	shl.2d	v20, v20, #0x2
     ce0:      	dup.2d	v25, x22
     ce4:      	add.2d	v20, v25, v20
     ce8:      	add.2d	v19, v25, v19
     cec:      	mov.d	x11, v19[1]
     cf0:      	fmov	x12, d19
     cf4:      	str	s24, [x12]
     cf8:      	st1.s	{ v24 }[1], [x11]
     cfc:      	add.2d	v19, v25, v22
     d00:      	mov.d	x11, v19[1]
     d04:      	fmov	x12, d19
     d08:      	st1.s	{ v24 }[2], [x12]
     d0c:      	add.2d	v19, v25, v21
     d10:      	st1.s	{ v24 }[3], [x11]
     d14:      	mov.d	x11, v19[1]
     d18:      	fmov	x12, d19
     d1c:      	str	s23, [x12]
     d20:      	st1.s	{ v23 }[1], [x11]
     d24:      	mov.d	x11, v20[1]
     d28:      	fmov	x12, d20
     d2c:      	st1.s	{ v23 }[2], [x12]
     d30:      	st1.s	{ v23 }[3], [x11]
     d34:      	add	x27, x27, #0x20
     d38:      	adds	x26, x26, #0x1
     d3c:      	b.lo	0xc9c <ltmp0+0xc9c>
     d40:      	add	w7, w7, #0x1
     d44:      	cmp	w7, w6
     d48:      	b.ne	0xad0 <ltmp0+0xad0>
     d4c:      	and	w5, w5, #0x7
     d50:      	cbz	w5, 0x58 <ltmp0+0x58>
     d54:      	dup.4s	v6, w5
     d58:      	cmhi.4s	v5, v6, v0
     d5c:      	cmhi.4s	v6, v6, v1
     d60:      	uzp1.8h	v20, v6, v5
     d64:      	umaxv.8h	h7, v20
     d68:      	fmov	w11, s7
     d6c:      	tbz	w11, #0x0, 0x58 <ltmp0+0x58>
     d70:      	mov	x20, #0x0               ; =0
     d74:      	ldr	x5, [x2, #0x88]
     d78:      	mov	w11, #0xc040            ; =49216
     d7c:      	add	x7, x5, x11
     d80:      	ldr	x21, [x0]
     d84:      	ldr	x19, [x0, #0x10]
     d88:      	lsl	w11, w6, #3
     d8c:      	orr	w11, w11, w4, lsl #5
     d90:      	dup.4s	v7, w11
     d94:      	ldr	x6, [x0, #0x30]
     d98:      	orr.16b	v16, v7, v1
     d9c:      	orr.16b	v7, v7, v0
     da0:      	and.16b	v17, v5, v7
     da4:      	and.16b	v18, v6, v16
     da8:      	umull2.2d	v7, v17, v2
     dac:      	umull2.2d	v16, v18, v2
     db0:      	umull.2d	v17, v17, v2
     db4:      	umull.2d	v18, v18, v2
     db8:      	b	0xddc <ltmp0+0xddc>
     dbc:      	add	x11, x5, x20, lsl #5
     dc0:      	ldp	q23, q24, [x11]
     dc4:      	bif.16b	v22, v24, v5
     dc8:      	bif.16b	v21, v23, v6
     dcc:      	stp	q21, q22, [x11]
     dd0:      	add	x20, x20, #0x1
     dd4:      	cmp	x20, #0x602
     dd8:      	b.eq	0xedc <ltmp0+0xedc>
     ddc:      	ldr	q19, [x15]
     de0:      	and.16b	v19, v20, v19
     de4:      	addv.8h	h19, v19
     de8:      	fmov	w22, s19
     dec:      	dup.2d	v23, x20
     df0:      	add.2d	v21, v23, v18
     df4:      	shl.2d	v21, v21, #0x2
     df8:      	dup.2d	v24, x21
     dfc:      	add.2d	v25, v24, v21
     e00:      	movi.2d	v21, #0000000000000000
     e04:      	movi.2d	v22, #0000000000000000
     e08:      	tbnz	w22, #0x0, 0xe54 <ltmp0+0xe54>
     e0c:      	and	w22, w22, #0xff
     e10:      	tbnz	w22, #0x1, 0xe64 <ltmp0+0xe64>
     e14:      	add.2d	v25, v23, v16
     e18:      	shl.2d	v25, v25, #0x2
     e1c:      	add.2d	v25, v24, v25
     e20:      	tbnz	w22, #0x2, 0xe7c <ltmp0+0xe7c>
     e24:      	tbnz	w22, #0x3, 0xe88 <ltmp0+0xe88>
     e28:      	add.2d	v25, v23, v17
     e2c:      	shl.2d	v25, v25, #0x2
     e30:      	add.2d	v25, v24, v25
     e34:      	tbnz	w22, #0x4, 0xea0 <ltmp0+0xea0>
     e38:      	tbnz	w22, #0x5, 0xeac <ltmp0+0xeac>
     e3c:      	add.2d	v23, v23, v7
     e40:      	shl.2d	v23, v23, #0x2
     e44:      	add.2d	v23, v24, v23
     e48:      	tbnz	w22, #0x6, 0xec4 <ltmp0+0xec4>
     e4c:      	tbz	w22, #0x7, 0xdbc <ltmp0+0xdbc>
     e50:      	b	0xed0 <ltmp0+0xed0>
     e54:      	fmov	x11, d25
     e58:      	ldr	s21, [x11]
     e5c:      	and	w22, w22, #0xff
     e60:      	tbz	w22, #0x1, 0xe14 <ltmp0+0xe14>
     e64:      	mov.d	x11, v25[1]
     e68:      	ld1.s	{ v21 }[1], [x11]
     e6c:      	add.2d	v25, v23, v16
     e70:      	shl.2d	v25, v25, #0x2
     e74:      	add.2d	v25, v24, v25
     e78:      	tbz	w22, #0x2, 0xe24 <ltmp0+0xe24>
     e7c:      	fmov	x11, d25
     e80:      	ld1.s	{ v21 }[2], [x11]
     e84:      	tbz	w22, #0x3, 0xe28 <ltmp0+0xe28>
     e88:      	mov.d	x11, v25[1]
     e8c:      	ld1.s	{ v21 }[3], [x11]
     e90:      	add.2d	v25, v23, v17
     e94:      	shl.2d	v25, v25, #0x2
     e98:      	add.2d	v25, v24, v25
     e9c:      	tbz	w22, #0x4, 0xe38 <ltmp0+0xe38>
     ea0:      	fmov	x11, d25
     ea4:      	ld1.s	{ v22 }[0], [x11]
     ea8:      	tbz	w22, #0x5, 0xe3c <ltmp0+0xe3c>
     eac:      	mov.d	x11, v25[1]
     eb0:      	ld1.s	{ v22 }[1], [x11]
     eb4:      	add.2d	v23, v23, v7
     eb8:      	shl.2d	v23, v23, #0x2
     ebc:      	add.2d	v23, v24, v23
     ec0:      	tbz	w22, #0x6, 0xe4c <ltmp0+0xe4c>
     ec4:      	fmov	x11, d23
     ec8:      	ld1.s	{ v22 }[2], [x11]
     ecc:      	tbz	w22, #0x7, 0xdbc <ltmp0+0xdbc>
     ed0:      	mov.d	x11, v23[1]
     ed4:      	ld1.s	{ v22 }[3], [x11]
     ed8:      	b	0xdbc <ltmp0+0xdbc>
     edc:      	ldp	q21, q20, [x5]
     ee0:      	fmul.4s	v21, v21, v21
     ee4:      	fmul.4s	v20, v20, v20
     ee8:      	ldp	q23, q22, [x5, #0x20]
     eec:      	fmul.4s	v23, v23, v23
     ef0:      	fmul.4s	v22, v22, v22
     ef4:      	ldp	q25, q24, [x5, #0x40]
     ef8:      	fmul.4s	v28, v25, v25
     efc:      	fmul.4s	v29, v24, v24
     f00:      	ldp	q25, q24, [x5, #0x60]
     f04:      	fmul.4s	v30, v25, v25
     f08:      	fmul.4s	v31, v24, v24
     f0c:      	and.16b	v26, v5, v20
     f10:      	and.16b	v27, v6, v21
     f14:      	and.16b	v24, v5, v22
     f18:      	and.16b	v25, v6, v23
     f1c:      	and.16b	v20, v5, v29
     f20:      	and.16b	v23, v6, v28
     f24:      	and.16b	v22, v5, v31
     f28:      	and.16b	v21, v6, v30
     f2c:      	add	x20, x5, #0xe0
     f30:      	mov	w21, #0x4               ; =4
     f34:      	ldp	q29, q28, [x20, #-0x60]
     f38:      	and.16b	v29, v6, v29
     f3c:      	and.16b	v28, v5, v28
     f40:      	fmul.4s	v28, v28, v28
     f44:      	fmul.4s	v29, v29, v29
     f48:      	fadd.4s	v29, v27, v29
     f4c:      	fadd.4s	v28, v26, v28
     f50:      	ldp	q31, q30, [x20, #-0x40]
     f54:      	and.16b	v31, v6, v31
     f58:      	and.16b	v30, v5, v30
     f5c:      	fmul.4s	v30, v30, v30
     f60:      	fmul.4s	v31, v31, v31
     f64:      	fadd.4s	v31, v25, v31
     f68:      	fadd.4s	v30, v24, v30
     f6c:      	ldp	q9, q8, [x20, #-0x20]
     f70:      	and.16b	v9, v6, v9
     f74:      	and.16b	v8, v5, v8
     f78:      	fmul.4s	v8, v8, v8
     f7c:      	fmul.4s	v9, v9, v9
     f80:      	fadd.4s	v9, v23, v9
     f84:      	fadd.4s	v8, v20, v8
     f88:      	ldp	q11, q10, [x20], #0x80
     f8c:      	and.16b	v11, v6, v11
     f90:      	and.16b	v10, v5, v10
     f94:      	fmul.4s	v10, v10, v10
     f98:      	fmul.4s	v11, v11, v11
     f9c:      	fadd.4s	v11, v21, v11
     fa0:      	fadd.4s	v10, v22, v10
     fa4:      	bit.16b	v26, v28, v5
     fa8:      	bit.16b	v27, v29, v6
     fac:      	bit.16b	v24, v30, v5
     fb0:      	bit.16b	v25, v31, v6
     fb4:      	bit.16b	v20, v8, v5
     fb8:      	bit.16b	v23, v9, v6
     fbc:      	bit.16b	v22, v10, v5
     fc0:      	bit.16b	v21, v11, v6
     fc4:      	cmp	x21, #0x5fc
     fc8:      	add	x21, x21, #0x4
     fcc:      	b.lo	0xf34 <ltmp0+0xf34>
     fd0:      	mov	x20, #0x0               ; =0
     fd4:      	ldr	q30, [x5, #0xc010]
     fd8:      	ldr	q31, [x5, #0xc000]
     fdc:      	ldr	q28, [x5, #0xc030]
     fe0:      	ldr	q29, [x5, #0xc020]
     fe4:      	add	x11, x19, x20, lsl #2
     fe8:      	ld1r.4s	{ v8 }, [x11]
     fec:      	add	x11, x7, x20, lsl #5
     ff0:      	ldp	q9, q10, [x11]
     ff4:      	bit.16b	v10, v8, v5
     ff8:      	bif.16b	v8, v9, v6
     ffc:      	stp	q8, q10, [x11]
    1000:      	add	x20, x20, #0x1
    1004:      	cmp	x20, #0x602
    1008:      	b.ne	0xfe4 <ltmp0+0xfe4>
    100c:      	and.16b	v31, v6, v31
    1010:      	and.16b	v30, v5, v30
    1014:      	fmul.4s	v30, v30, v30
    1018:      	fmul.4s	v31, v31, v31
    101c:      	fadd.4s	v27, v27, v31
    1020:      	fadd.4s	v26, v26, v30
    1024:      	and.16b	v29, v6, v29
    1028:      	and.16b	v28, v5, v28
    102c:      	fmul.4s	v28, v28, v28
    1030:      	fmul.4s	v29, v29, v29
    1034:      	fadd.4s	v25, v25, v29
    1038:      	fadd.4s	v24, v24, v28
    103c:      	fadd.4s	v24, v26, v24
    1040:      	fadd.4s	v25, v27, v25
    1044:      	fadd.4s	v23, v23, v25
    1048:      	fadd.4s	v20, v20, v24
    104c:      	fadd.4s	v20, v22, v20
    1050:      	fadd.4s	v21, v21, v23
    1054:      	fdiv.4s	v21, v21, v4
    1058:      	fdiv.4s	v4, v20, v4
    105c:      	fadd.4s	v4, v4, v3
    1060:      	fadd.4s	v3, v21, v3
    1064:      	fsqrt.4s	v20, v3
    1068:      	fsqrt.4s	v3, v4
    106c:      	and.16b	v3, v5, v3
    1070:      	and.16b	v4, v6, v20
    1074:      	mov	x7, #-0x602             ; =-1538
    1078:      	b	0x1088 <ltmp0+0x1088>
    107c:      	add	x5, x5, #0x20
    1080:      	adds	x7, x7, #0x1
    1084:      	b.hs	0x58 <ltmp0+0x58>
    1088:      	fmov	w19, s19
    108c:      	add	x11, x7, #0x602
    1090:      	dup.2d	v20, x11
    1094:      	add.2d	v21, v20, v18
    1098:      	ldp	q23, q22, [x5]
    109c:      	and.16b	v23, v6, v23
    10a0:      	fdiv.4s	v24, v23, v4
    10a4:      	ldr	q23, [x5, #0xc050]
    10a8:      	ldr	q25, [x5, #0xc040]
    10ac:      	and.16b	v25, v6, v25
    10b0:      	fmul.4s	v24, v24, v25
    10b4:      	shl.2d	v25, v21, #0x2
    10b8:      	dup.2d	v21, x6
    10bc:      	add.2d	v25, v21, v25
    10c0:      	tbnz	w19, #0x0, 0x1124 <ltmp0+0x1124>
    10c4:      	and	w19, w19, #0xff
    10c8:      	tbnz	w19, #0x1, 0x1134 <ltmp0+0x1134>
    10cc:      	add.2d	v25, v20, v16
    10d0:      	shl.2d	v25, v25, #0x2
    10d4:      	add.2d	v25, v21, v25
    10d8:      	tbnz	w19, #0x2, 0x114c <ltmp0+0x114c>
    10dc:      	tbz	w19, #0x3, 0x10e8 <ltmp0+0x10e8>
    10e0:      	mov.d	x11, v25[1]
    10e4:      	st1.s	{ v24 }[3], [x11]
    10e8:      	add.2d	v24, v20, v17
    10ec:      	and.16b	v22, v5, v22
    10f0:      	fdiv.4s	v22, v22, v3
    10f4:      	and.16b	v23, v5, v23
    10f8:      	fmul.4s	v22, v22, v23
    10fc:      	shl.2d	v23, v24, #0x2
    1100:      	add.2d	v23, v21, v23
    1104:      	tbnz	w19, #0x4, 0x115c <ltmp0+0x115c>
    1108:      	tbnz	w19, #0x5, 0x1168 <ltmp0+0x1168>
    110c:      	add.2d	v20, v20, v7
    1110:      	shl.2d	v20, v20, #0x2
    1114:      	add.2d	v20, v21, v20
    1118:      	tbnz	w19, #0x6, 0x1180 <ltmp0+0x1180>
    111c:      	tbz	w19, #0x7, 0x107c <ltmp0+0x107c>
    1120:      	b	0x118c <ltmp0+0x118c>
    1124:      	fmov	x11, d25
    1128:      	str	s24, [x11]
    112c:      	and	w19, w19, #0xff
    1130:      	tbz	w19, #0x1, 0x10cc <ltmp0+0x10cc>
    1134:      	mov.d	x11, v25[1]
    1138:      	st1.s	{ v24 }[1], [x11]
    113c:      	add.2d	v25, v20, v16
    1140:      	shl.2d	v25, v25, #0x2
    1144:      	add.2d	v25, v21, v25
    1148:      	tbz	w19, #0x2, 0x10dc <ltmp0+0x10dc>
    114c:      	fmov	x11, d25
    1150:      	st1.s	{ v24 }[2], [x11]
    1154:      	tbnz	w19, #0x3, 0x10e0 <ltmp0+0x10e0>
    1158:      	b	0x10e8 <ltmp0+0x10e8>
    115c:      	fmov	x11, d23
    1160:      	str	s22, [x11]
    1164:      	tbz	w19, #0x5, 0x110c <ltmp0+0x110c>
    1168:      	mov.d	x11, v23[1]
    116c:      	st1.s	{ v22 }[1], [x11]
    1170:      	add.2d	v20, v20, v7
    1174:      	shl.2d	v20, v20, #0x2
    1178:      	add.2d	v20, v21, v20
    117c:      	tbz	w19, #0x6, 0x111c <ltmp0+0x111c>
    1180:      	fmov	x11, d20
    1184:      	st1.s	{ v22 }[2], [x11]
    1188:      	tbz	w19, #0x7, 0x107c <ltmp0+0x107c>
    118c:      	mov.d	x11, v20[1]
    1190:      	st1.s	{ v22 }[3], [x11]
    1194:      	b	0x107c <ltmp0+0x107c>
    1198:      	stp	w4, w1, [x2]
    119c:      	str	w17, [x2, #0x8]
    11a0:      	mov	w8, #0x18               ; =24
    11a4:      	str	w8, [x2, #0x24]
    11a8:      	ldp	x29, x30, [sp, #0x80]
    11ac:      	ldp	x20, x19, [sp, #0x70]
    11b0:      	ldp	x22, x21, [sp, #0x60]
    11b4:      	ldp	x24, x23, [sp, #0x50]
    11b8:      	ldp	x26, x25, [sp, #0x40]
    11bc:      	ldp	x28, x27, [sp, #0x30]
    11c0:      	ldp	d9, d8, [sp, #0x20]
    11c4:      	ldp	d11, d10, [sp, #0x10]
    11c8:      	add	sp, sp, #0x90
    11cc:      	ret

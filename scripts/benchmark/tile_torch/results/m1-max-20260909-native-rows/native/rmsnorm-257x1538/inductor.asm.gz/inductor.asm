
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/rmsnorm-257x1538/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0xc0
     6b4:      	stp	d11, d10, [sp, #0x40]
     6b8:      	stp	d9, d8, [sp, #0x50]
     6bc:      	stp	x28, x27, [sp, #0x60]
     6c0:      	stp	x26, x25, [sp, #0x70]
     6c4:      	stp	x24, x23, [sp, #0x80]
     6c8:      	stp	x22, x21, [sp, #0x90]
     6cc:      	stp	x20, x19, [sp, #0xa0]
     6d0:      	stp	x29, x30, [sp, #0xb0]
     6d4:      	add	x29, sp, #0xb0
     6d8:      	mov	x19, #0x0               ; =0
     6dc:      	adrp	x20, 0x4000 <dyld_stub_binder+0x4000>
     6e0:      	ldr	x20, [x20, #0x98]
     6e4:      	str	wzr, [sp, #0x20]
     6e8:      	add	x8, sp, #0x20
     6ec:      	str	x8, [x20]
     6f0:      	adrp	x21, 0x4000 <dyld_stub_binder+0x4000>
     6f4:      	ldr	x21, [x21, #0x80]
     6f8:      	movi.2d	v8, #0000000000000000
     6fc:      	mov	w8, #0x4000             ; =16384
     700:      	movk	w8, #0x44c0, lsl #16
     704:      	fmov	s9, w8
     708:      	mov	w8, #0xc5ac             ; =50604
     70c:      	movk	w8, #0x3727, lsl #16
     710:      	fmov	s10, w8
     714:      	fmov	s11, #1.00000000
     718:      	mov	w22, #0x1808            ; =6152
     71c:      	b	0x758 <_kernel+0xa8>
     720:      	ldr	d3, [x0, x23]
     724:      	ldr	d2, [x1, x23]
     728:      	fsqrt	s1, s0
     72c:      	fcmp	s1, s1
     730:      	b.vs	0x83c <_kernel+0x18c>
     734:      	fdiv	s0, s11, s1
     738:      	fmul.2s	v0, v3, v0[0]
     73c:      	fmul.2s	v0, v2, v0
     740:      	str	d0, [x3, x23]
     744:      	add	x19, x19, #0x1
     748:      	add	x0, x0, x22
     74c:      	add	x3, x3, x22
     750:      	cmp	x19, #0x101
     754:      	b.eq	0x878 <_kernel+0x1c8>
     758:      	ldr	q1, [x21]
     75c:      	movi.2d	v0, #0000000000000000
     760:      	mov	x8, #-0x4               ; =-4
     764:      	mov	x9, x0
     768:      	add	x8, x8, #0x4
     76c:      	cmp	x8, #0x600
     770:      	b.hs	0x828 <_kernel+0x178>
     774:      	ldr	q2, [x9], #0x10
     778:      	fmul.4s	v2, v2, v2
     77c:      	fadd.4s	v0, v0, v2
     780:      	cmp	x8, #0x5fe
     784:      	b.lo	0x768 <_kernel+0xb8>
     788:      	mov	x23, #0x0               ; =0
     78c:      	dup.2d	v1, v0[1]
     790:      	fadd.4s	v0, v0, v1
     794:      	faddp.2s	s0, v0
     798:      	fadd	s0, s0, s8
     79c:      	str	s0, [x2, x19, lsl #2]
     7a0:      	mov	x24, #-0x4              ; =-4
     7a4:      	add	x8, x24, #0x4
     7a8:      	ldr	s0, [x2, x19, lsl #2]
     7ac:      	fdiv	s0, s0, s9
     7b0:      	fadd	s0, s0, s10
     7b4:      	cmp	x8, #0x600
     7b8:      	b.hs	0x720 <_kernel+0x70>
     7bc:      	ldr	q2, [x0, x23]
     7c0:      	ldr	q3, [x1, x23]
     7c4:      	fsqrt	s1, s0
     7c8:      	fcmp	s1, s1
     7cc:      	b.vs	0x7f4 <_kernel+0x144>
     7d0:      	fdiv	s0, s11, s1
     7d4:      	fmul.4s	v0, v2, v0[0]
     7d8:      	fmul.4s	v0, v3, v0
     7dc:      	str	q0, [x3, x23]
     7e0:      	add	x23, x23, #0x10
     7e4:      	add	x24, x24, #0x4
     7e8:      	cmp	x24, #0x5fe
     7ec:      	b.lo	0x7a4 <_kernel+0xf4>
     7f0:      	b	0x744 <_kernel+0x94>
     7f4:      	mov	x25, x3
     7f8:      	mov	x27, x2
     7fc:      	mov	x26, x1
     800:      	mov	x28, x0
     804:      	stp	q3, q2, [sp]
     808:      	bl	0x181c <dyld_stub_binder+0x181c>
     80c:      	ldp	q3, q2, [sp]
     810:      	mov	x0, x28
     814:      	mov	x1, x26
     818:      	mov	x2, x27
     81c:      	mov	x3, x25
     820:      	mov.16b	v1, v0
     824:      	b	0x7d0 <_kernel+0x120>
     828:      	ldr	d2, [x9]
     82c:      	fmul.4s	v2, v2, v2
     830:      	fadd.4s	v2, v0, v2
     834:      	bit.16b	v0, v2, v1
     838:      	b	0x788 <_kernel+0xd8>
     83c:      	mov	x24, x3
     840:      	mov	x26, x2
     844:      	mov	x25, x1
     848:      	mov	x27, x0
     84c:      	str	d3, [sp, #0x10]
     850:      	str	d2, [sp]
     854:      	bl	0x181c <dyld_stub_binder+0x181c>
     858:      	ldr	d2, [sp]
     85c:      	ldr	d3, [sp, #0x10]
     860:      	mov	x0, x27
     864:      	mov	x1, x25
     868:      	mov	x2, x26
     86c:      	mov	x3, x24
     870:      	mov.16b	v1, v0
     874:      	b	0x734 <_kernel+0x84>
     878:      	str	xzr, [x20]
     87c:      	add	x8, sp, #0x20
     880:      	ldapr	w8, [x8]
     884:      	cbnz	w8, 0x8b0 <_kernel+0x200>
     888:      	ldp	x29, x30, [sp, #0xb0]
     88c:      	ldp	x20, x19, [sp, #0xa0]
     890:      	ldp	x22, x21, [sp, #0x90]
     894:      	ldp	x24, x23, [sp, #0x80]
     898:      	ldp	x26, x25, [sp, #0x70]
     89c:      	ldp	x28, x27, [sp, #0x60]
     8a0:      	ldp	d9, d8, [sp, #0x50]
     8a4:      	ldp	d11, d10, [sp, #0x40]
     8a8:      	add	sp, sp, #0xc0
     8ac:      	ret
     8b0:      	mov	w0, #0x10               ; =16
     8b4:      	bl	0x17b0 <dyld_stub_binder+0x17b0>
     8b8:      	mov	x19, x0
     8bc:      	mov	w8, #0x33d              ; =829
     8c0:      	str	w8, [sp, #0x24]
     8c4:      	adrp	x0, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf0>
     8c8:      	add	x0, x0, #0xaec
     8cc:      	adrp	x1, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf0>
     8d0:      	add	x1, x1, #0xb78
     8d4:      	adrp	x3, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf0>
     8d8:      	add	x3, x3, #0xba3
     8dc:      	adrp	x4, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf0>
     8e0:      	add	x4, x4, #0xc21
     8e4:      	adrp	x2, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf0>
     8e8:      	add	x2, x2, #0xba0
     8ec:      	add	x8, sp, #0x28
     8f0:      	add	x5, sp, #0x24
     8f4:      	adrp	x7, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf0>
     8f8:      	add	x7, x7, #0xc23
     8fc:      	mov	x6, x2
     900:      	bl	0x974 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     904:      	mov	w21, #0x1               ; =1
     908:      	add	x1, sp, #0x28
     90c:      	mov	x0, x19
     910:      	bl	0x16fc <dyld_stub_binder+0x16fc>
     914:      	mov	w21, #0x0               ; =0
     918:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     91c:      	ldr	x1, [x1, #0x18]
     920:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     924:      	ldr	x2, [x2, #0x8]
     928:      	mov	x0, x19
     92c:      	bl	0x17e0 <dyld_stub_binder+0x17e0>
     930:      	brk	#0x1
     934:      	mov	x20, x0
     938:      	ldrsb	w8, [sp, #0x3f]
     93c:      	tbz	w8, #0x1f, 0x958 <_kernel+0x2a8>
     940:      	ldr	x0, [sp, #0x28]
     944:      	ldr	x8, [sp, #0x38]
     948:      	and	x1, x8, #0x7fffffffffffffff
     94c:      	bl	0x1798 <dyld_stub_binder+0x1798>
     950:      	tbnz	w21, #0x0, 0x964 <_kernel+0x2b4>
     954:      	b	0x96c <_kernel+0x2bc>
     958:      	cbnz	w21, 0x964 <_kernel+0x2b4>
     95c:      	b	0x96c <_kernel+0x2bc>
     960:      	mov	x20, x0
     964:      	mov	x0, x19
     968:      	bl	0x17d4 <dyld_stub_binder+0x17d4>
     96c:      	mov	x0, x20
     970:      	bl	0x16c0 <dyld_stub_binder+0x16c0>

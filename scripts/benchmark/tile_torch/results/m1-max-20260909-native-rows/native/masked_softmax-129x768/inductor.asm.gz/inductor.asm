
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/masked_softmax-129x768/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000700 <_kernel>:
     700:      	sub	sp, sp, #0xe0
     704:      	stp	d9, d8, [sp, #0x70]
     708:      	stp	x28, x27, [sp, #0x80]
     70c:      	stp	x26, x25, [sp, #0x90]
     710:      	stp	x24, x23, [sp, #0xa0]
     714:      	stp	x22, x21, [sp, #0xb0]
     718:      	stp	x20, x19, [sp, #0xc0]
     71c:      	stp	x29, x30, [sp, #0xd0]
     720:      	add	x29, sp, #0xd0
     724:      	mov	x19, x3
     728:      	mov	x20, x2
     72c:      	mov	x21, x1
     730:      	mov	x22, x0
     734:      	str	wzr, [sp, #0x50]
     738:      	adrp	x24, 0x4000 <dyld_stub_binder+0x4000>
     73c:      	ldr	x24, [x24, #0xa0]
     740:      	add	x8, sp, #0x50
     744:      	str	x8, [x24]
     748:      	mov	w0, #0xc00              ; =3072
     74c:      	bl	0x17f4 <dyld_stub_binder+0x17f4>
     750:      	mov	x23, x0
     754:      	mov	w1, #0xc00              ; =3072
     758:      	bl	0x1854 <dyld_stub_binder+0x1854>
     75c:      	mov	x25, #0x0               ; =0
     760:      	adrp	x8, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xb8>
     764:      	ldr	q4, [x8, #0xa40]
     768:      	mov	w8, #0xf2ca             ; =62154
     76c:      	movk	w8, #0xf149, lsl #16
     770:      	dup.4s	v5, w8
     774:      	movi.2d	v8, #0000000000000000
     778:      	stp	q5, q4, [sp]
     77c:      	mov	x9, #0x0                ; =0
     780:      	dup.2d	v6, x25
     784:      	mvni.4s	v0, #0x7f, msl #16
     788:      	mov	x8, x22
     78c:      	ldr	q1, [x8], #0x10
     790:      	dup.2d	v2, x9
     794:      	orr.16b	v2, v2, v4
     798:      	add	x10, x9, #0x2
     79c:      	dup.2d	v3, x10
     7a0:      	orr.16b	v3, v3, v4
     7a4:      	cmhs.2d	v2, v6, v2
     7a8:      	cmhs.2d	v3, v6, v3
     7ac:      	cmeq.2d	v2, v2, #0
     7b0:      	cmeq.2d	v3, v3, #0
     7b4:      	uzp1.4s	v2, v2, v3
     7b8:      	bit.16b	v1, v5, v2
     7bc:      	fmax.4s	v0, v0, v1
     7c0:      	cmp	x9, #0x2fc
     7c4:      	add	x9, x9, #0x4
     7c8:      	b.lo	0x78c <_kernel+0x8c>
     7cc:      	mov	x26, #0x0               ; =0
     7d0:      	mov	x8, #0x0                ; =0
     7d4:      	ext.16b	v1, v0, v0, #0x8
     7d8:      	fmax.4s	v0, v0, v1
     7dc:      	rev64.4s	v1, v0
     7e0:      	fmax.4s	v0, v0, v1
     7e4:      	str	s0, [x21, x25, lsl #2]
     7e8:      	dup.4s	v0, v0[0]
     7ec:      	stp	q0, q6, [sp, #0x20]
     7f0:      	movi.2d	v1, #0000000000000000
     7f4:      	str	q1, [sp, #0x40]
     7f8:      	mov	x27, x8
     7fc:      	ldr	q0, [x22, x26]
     800:      	dup.2d	v1, x8
     804:      	orr.16b	v1, v1, v4
     808:      	add	x8, x8, #0x2
     80c:      	dup.2d	v2, x8
     810:      	orr.16b	v2, v2, v4
     814:      	cmhs.2d	v1, v6, v1
     818:      	cmhs.2d	v2, v6, v2
     81c:      	cmeq.2d	v1, v1, #0
     820:      	cmeq.2d	v2, v2, #0
     824:      	uzp1.4s	v1, v1, v2
     828:      	bit.16b	v0, v5, v1
     82c:      	ldr	q1, [sp, #0x20]
     830:      	fsub.4s	v0, v0, v1
     834:      	bl	0x16f8 <dyld_stub_binder+0x16f8>
     838:      	ldp	q6, q1, [sp, #0x30]
     83c:      	ldp	q5, q4, [sp]
     840:      	str	q0, [x23, x26]
     844:      	fadd.4s	v1, v1, v0
     848:      	add	x26, x26, #0x10
     84c:      	add	x8, x27, #0x4
     850:      	cmp	x27, #0x2fc
     854:      	b.lo	0x7f4 <_kernel+0xf4>
     858:      	mov	x8, #0x0                ; =0
     85c:      	dup.2d	v0, v1[1]
     860:      	fadd.4s	v0, v1, v0
     864:      	faddp.2s	s0, v0
     868:      	fadd	s0, s0, s8
     86c:      	str	s0, [x20, x25, lsl #2]
     870:      	mov	x9, #-0x4               ; =-4
     874:      	add	x10, x20, x25, lsl #2
     878:      	ldr	q0, [x23, x8]
     87c:      	ld1r.4s	{ v1 }, [x10]
     880:      	fdiv.4s	v0, v0, v1
     884:      	str	q0, [x19, x8]
     888:      	add	x9, x9, #0x4
     88c:      	add	x8, x8, #0x10
     890:      	cmp	x9, #0x2fc
     894:      	b.lo	0x878 <_kernel+0x178>
     898:      	add	x25, x25, #0x1
     89c:      	add	x22, x22, #0xc00
     8a0:      	add	x19, x19, #0xc00
     8a4:      	cmp	x25, #0x81
     8a8:      	b.ne	0x77c <_kernel+0x7c>
     8ac:      	mov	x0, x23
     8b0:      	bl	0x17dc <dyld_stub_binder+0x17dc>
     8b4:      	str	xzr, [x24]
     8b8:      	add	x8, sp, #0x50
     8bc:      	ldapr	w8, [x8]
     8c0:      	cbnz	w8, 0x8e8 <_kernel+0x1e8>
     8c4:      	ldp	x29, x30, [sp, #0xd0]
     8c8:      	ldp	x20, x19, [sp, #0xc0]
     8cc:      	ldp	x22, x21, [sp, #0xb0]
     8d0:      	ldp	x24, x23, [sp, #0xa0]
     8d4:      	ldp	x26, x25, [sp, #0x90]
     8d8:      	ldp	x28, x27, [sp, #0x80]
     8dc:      	ldp	d9, d8, [sp, #0x70]
     8e0:      	add	sp, sp, #0xe0
     8e4:      	ret
     8e8:      	mov	w0, #0x10               ; =16
     8ec:      	bl	0x180c <dyld_stub_binder+0x180c>
     8f0:      	mov	x19, x0
     8f4:      	mov	w8, #0x33d              ; =829
     8f8:      	str	w8, [sp, #0x54]
     8fc:      	adrp	x0, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xb8>
     900:      	add	x0, x0, #0xb64
     904:      	adrp	x1, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xb8>
     908:      	add	x1, x1, #0xbf0
     90c:      	adrp	x3, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xb8>
     910:      	add	x3, x3, #0xc1b
     914:      	adrp	x4, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xb8>
     918:      	add	x4, x4, #0xc99
     91c:      	adrp	x2, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xb8>
     920:      	add	x2, x2, #0xc18
     924:      	add	x8, sp, #0x58
     928:      	add	x5, sp, #0x54
     92c:      	adrp	x7, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xb8>
     930:      	add	x7, x7, #0xc9b
     934:      	mov	x6, x2
     938:      	bl	0x9bc <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     93c:      	mov	w21, #0x1               ; =1
     940:      	add	x1, sp, #0x58
     944:      	mov	x0, x19
     948:      	bl	0x1740 <dyld_stub_binder+0x1740>
     94c:      	mov	w21, #0x0               ; =0
     950:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     954:      	ldr	x1, [x1, #0x18]
     958:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     95c:      	ldr	x2, [x2, #0x8]
     960:      	mov	x0, x19
     964:      	bl	0x183c <dyld_stub_binder+0x183c>
     968:      	brk	#0x1
     96c:      	mov	x20, x0
     970:      	ldrsb	w8, [sp, #0x6f]
     974:      	tbz	w8, #0x1f, 0x990 <_kernel+0x290>
     978:      	ldr	x0, [sp, #0x58]
     97c:      	ldr	x8, [sp, #0x68]
     980:      	and	x1, x8, #0x7fffffffffffffff
     984:      	bl	0x17e8 <dyld_stub_binder+0x17e8>
     988:      	tbnz	w21, #0x0, 0x99c <_kernel+0x29c>
     98c:      	b	0x9a4 <_kernel+0x2a4>
     990:      	cbnz	w21, 0x99c <_kernel+0x29c>
     994:      	b	0x9a4 <_kernel+0x2a4>
     998:      	mov	x20, x0
     99c:      	mov	x0, x19
     9a0:      	bl	0x1830 <dyld_stub_binder+0x1830>
     9a4:      	mov	x0, x20
     9a8:      	bl	0x1704 <dyld_stub_binder+0x1704>

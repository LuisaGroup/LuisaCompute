
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/masked_softmax-129x768-l1/object/tile_xir_w8_80758_1788919112589129_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x80
       4:      	stp	d15, d14, [sp, #0x40]
       8:      	stp	d13, d12, [sp, #0x50]
       c:      	stp	d11, d10, [sp, #0x60]
      10:      	stp	d9, d8, [sp, #0x70]
      14:      	mov	x10, #0x0               ; =0
      18:      	ldr	x9, [x1, #0x88]
      1c:      	mov	x11, x9
      20:      	ldr	w8, [x1]
      24:      	ldr	w12, [x1, #0x24]
      28:      	add	w12, w12, w8, lsl #5
      2c:      	ldr	x13, [x0]
      30:      	ldr	x8, [x0, #0x30]
      34:      	dup.4s	v0, w12
      38:      	adrp	x12, 0x0 <ltmp0>
      3c:      	ldr	q1, [x12]
      40:      	add.4s	v4, v0, v1
      44:      	adrp	x12, 0x0 <ltmp0>
      48:      	ldr	q1, [x12]
      4c:      	add.4s	v5, v0, v1
      50:      	movi.4s	v1, #0x3, lsl #8
      54:      	umull2.2d	v0, v4, v1
      58:      	umull2.2d	v1, v5, v1
      5c:      	movi.2s	v3, #0x3, lsl #8
      60:      	umull.2d	v2, v4, v3
      64:      	umull.2d	v3, v5, v3
      68:      	dup.2d	v6, x13
      6c:      	dup.2d	v7, x10
      70:      	add.2d	v16, v7, v0
      74:      	add.2d	v17, v7, v2
      78:      	add.2d	v18, v7, v1
      7c:      	add.2d	v7, v7, v3
      80:      	shl.2d	v7, v7, #0x2
      84:      	shl.2d	v18, v18, #0x2
      88:      	shl.2d	v17, v17, #0x2
      8c:      	shl.2d	v16, v16, #0x2
      90:      	add.2d	v16, v6, v16
      94:      	add.2d	v17, v6, v17
      98:      	add.2d	v18, v6, v18
      9c:      	add.2d	v7, v6, v7
      a0:      	mov.d	x12, v7[1]
      a4:      	fmov	x13, d7
      a8:      	mov.d	x14, v18[1]
      ac:      	fmov	x15, d18
      b0:      	mov.d	x16, v17[1]
      b4:      	fmov	x17, d17
      b8:      	mov.d	x0, v16[1]
      bc:      	ldr	s7, [x13]
      c0:      	ld1.s	{ v7 }[1], [x12]
      c4:      	fmov	x12, d16
      c8:      	ld1.s	{ v7 }[2], [x15]
      cc:      	ld1.s	{ v7 }[3], [x14]
      d0:      	ldr	s16, [x17]
      d4:      	ld1.s	{ v16 }[1], [x16]
      d8:      	ld1.s	{ v16 }[2], [x12]
      dc:      	ld1.s	{ v16 }[3], [x0]
      e0:      	add	x12, x9, x10, lsl #5
      e4:      	stp	q7, q16, [x12]
      e8:      	add	x10, x10, #0x1
      ec:      	cmp	x10, #0x300
      f0:      	b.ne	0x6c <ltmp0+0x6c>
      f4:      	stp	q3, q2, [sp]
      f8:      	stp	q1, q0, [sp, #0x20]
      fc:      	mov	x12, #0x0               ; =0
     100:      	add	x10, x9, #0x6, lsl #12  ; =0x6000
     104:      	dup.2d	v6, x12
     108:      	add	x13, x10, x12, lsl #6
     10c:      	stp	q6, q6, [x13, #0x20]
     110:      	stp	q6, q6, [x13]
     114:      	add	x12, x12, #0x1
     118:      	cmp	x12, #0x300
     11c:      	b.ne	0x104 <ltmp0+0x104>
     120:      	mov	x12, #0x0               ; =0
     124:      	mov	w13, #0xaaab            ; =43691
     128:      	movk	w13, #0xaaaa, lsl #16
     12c:      	dup.4s	v6, w13
     130:      	add	x13, x9, #0x12, lsl #12 ; =0x12000
     134:      	umull2.2d	v7, v5, v6
     138:      	umull.2d	v16, v5, v6
     13c:      	uzp2.4s	v7, v16, v7
     140:      	ushr.4s	v7, v7, #0x9
     144:      	movi.4s	v16, #0x3, lsl #8
     148:      	mls.4s	v5, v7, v16
     14c:      	umull2.2d	v7, v4, v6
     150:      	umull.2d	v6, v4, v6
     154:      	uzp2.4s	v6, v6, v7
     158:      	ushr.4s	v6, v6, #0x9
     15c:      	mls.4s	v4, v6, v16
     160:      	ushll2.2d	v17, v4, #0x0
     164:      	ushll2.2d	v18, v5, #0x0
     168:      	ushll.2d	v19, v4, #0x0
     16c:      	ushll.2d	v20, v5, #0x0
     170:      	dup.2d	v4, x13
     174:      	adrp	x13, 0x0 <ltmp0>
     178:      	ldr	q5, [x13]
     17c:      	adrp	x13, 0x0 <ltmp0>
     180:      	ldr	q6, [x13]
     184:      	adrp	x13, 0x0 <ltmp0>
     188:      	ldr	q7, [x13]
     18c:      	adrp	x13, 0x0 <ltmp0>
     190:      	ldr	q16, [x13]
     194:      	movi.8b	v21, #0x1
     198:      	dup.2d	v22, x12
     19c:      	add	x13, x10, x12, lsl #6
     1a0:      	ldp	q24, q23, [x13, #0x20]
     1a4:      	ldp	q25, q26, [x13]
     1a8:      	add.2d	v22, v22, v4
     1ac:      	add.2d	v27, v22, v6
     1b0:      	add.2d	v28, v22, v5
     1b4:      	cmge.2d	v26, v18, v26
     1b8:      	cmge.2d	v25, v20, v25
     1bc:      	uzp1.4s	v25, v25, v26
     1c0:      	cmge.2d	v24, v19, v24
     1c4:      	cmge.2d	v23, v17, v23
     1c8:      	uzp1.4s	v23, v24, v23
     1cc:      	uzp1.8h	v23, v25, v23
     1d0:      	xtn.8b	v23, v23
     1d4:      	and.8b	v23, v23, v21
     1d8:      	mov.d	x13, v28[1]
     1dc:      	fmov	x14, d28
     1e0:      	str	b23, [x14]
     1e4:      	st1.b	{ v23 }[1], [x13]
     1e8:      	mov.d	x13, v27[1]
     1ec:      	fmov	x14, d27
     1f0:      	st1.b	{ v23 }[2], [x14]
     1f4:      	st1.b	{ v23 }[3], [x13]
     1f8:      	add.2d	v24, v22, v7
     1fc:      	mov.d	x13, v24[1]
     200:      	fmov	x14, d24
     204:      	st1.b	{ v23 }[4], [x14]
     208:      	add.2d	v22, v22, v16
     20c:      	st1.b	{ v23 }[5], [x13]
     210:      	mov.d	x13, v22[1]
     214:      	fmov	x14, d22
     218:      	st1.b	{ v23 }[6], [x14]
     21c:      	st1.b	{ v23 }[7], [x13]
     220:      	add	x12, x12, #0x1
     224:      	cmp	x12, #0x300
     228:      	b.ne	0x198 <ltmp0+0x198>
     22c:      	mov	w12, #0x3800            ; =14336
     230:      	movk	w12, #0x1, lsl #16
     234:      	add	x10, x9, x12
     238:      	mov	x13, #-0x300            ; =-768
     23c:      	mov	w14, #0xf2ca            ; =62154
     240:      	movk	w14, #0xf149, lsl #16
     244:      	dup.4s	v17, w14
     248:      	add	x14, x13, #0x300
     24c:      	dup.2d	v18, x14
     250:      	add.2d	v18, v18, v4
     254:      	add.2d	v19, v18, v16
     258:      	add.2d	v20, v18, v7
     25c:      	add.2d	v21, v18, v6
     260:      	add.2d	v18, v18, v5
     264:      	mov.d	x14, v18[1]
     268:      	mov.d	x15, v21[1]
     26c:      	fmov	x16, d18
     270:      	fmov	x17, d21
     274:      	mov.d	x0, v20[1]
     278:      	mov.d	x1, v19[1]
     27c:      	fmov	x2, d20
     280:      	ldr	b18, [x16]
     284:      	ld1.b	{ v18 }[1], [x14]
     288:      	ld1.b	{ v18 }[2], [x17]
     28c:      	ld1.b	{ v18 }[3], [x15]
     290:      	ld1.b	{ v18 }[4], [x2]
     294:      	ld1.b	{ v18 }[5], [x0]
     298:      	fmov	x14, d19
     29c:      	ld1.b	{ v18 }[6], [x14]
     2a0:      	ld1.b	{ v18 }[7], [x1]
     2a4:      	cmeq.8b	v18, v18, #0
     2a8:      	sshll.8h	v18, v18, #0x0
     2ac:      	sshll2.4s	v19, v18, #0x0
     2b0:      	sshll.4s	v18, v18, #0x0
     2b4:      	ldp	q21, q20, [x11]
     2b8:      	bsl.16b	v18, v17, v21
     2bc:      	bsl.16b	v19, v17, v20
     2c0:      	add	x14, x11, x12
     2c4:      	stp	q18, q19, [x14]
     2c8:      	add	x11, x11, #0x20
     2cc:      	adds	x13, x13, #0x1
     2d0:      	b.lo	0x248 <ltmp0+0x248>
     2d4:      	add	x11, x9, #0x13, lsl #12 ; =0x13000
     2d8:      	add	x11, x11, #0x800
     2dc:      	ldp	q17, q18, [x11]
     2e0:      	add	x11, x9, #0x13, lsl #12 ; =0x13000
     2e4:      	add	x11, x11, #0x820
     2e8:      	ldp	q20, q19, [x11]
     2ec:      	add	x11, x9, #0x13, lsl #12 ; =0x13000
     2f0:      	add	x11, x11, #0x840
     2f4:      	ldp	q21, q22, [x11]
     2f8:      	add	x11, x9, #0x13, lsl #12 ; =0x13000
     2fc:      	add	x12, x11, #0x860
     300:      	add	x11, x9, #0x13, lsl #12 ; =0x13000
     304:      	add	x11, x11, #0x8e0
     308:      	ldp	q24, q23, [x12]
     30c:      	mov	w12, #0x9c4             ; =2500
     310:      	ldp	q25, q26, [x11, #-0x60]
     314:      	fmaxnm.4s	v18, v18, v26
     318:      	fmaxnm.4s	v17, v17, v25
     31c:      	ldp	q25, q26, [x11, #-0x40]
     320:      	fmaxnm.4s	v19, v19, v26
     324:      	fmaxnm.4s	v20, v20, v25
     328:      	ldp	q25, q26, [x11, #-0x20]
     32c:      	fmaxnm.4s	v22, v22, v26
     330:      	fmaxnm.4s	v21, v21, v25
     334:      	ldp	q25, q26, [x11], #0x80
     338:      	fmaxnm.4s	v23, v23, v26
     33c:      	fmaxnm.4s	v24, v24, v25
     340:      	sub	x13, x12, #0x9c0
     344:      	add	x12, x12, #0x4
     348:      	cmp	x13, #0x2fc
     34c:      	b.lo	0x310 <ltmp0+0x310>
     350:      	add	x11, x9, #0x19, lsl #12 ; =0x19000
     354:      	add	x11, x11, #0x800
     358:      	mvni.4s	v9, #0x7f, msl #16
     35c:      	fmaxnm.4s	v18, v18, v9
     360:      	fmaxnm.4s	v17, v17, v9
     364:      	fmaxnm.4s	v17, v17, v20
     368:      	fmaxnm.4s	v18, v18, v19
     36c:      	fmaxnm.4s	v18, v18, v22
     370:      	fmaxnm.4s	v17, v17, v21
     374:      	fmaxnm.4s	v17, v17, v24
     378:      	fmaxnm.4s	v18, v18, v23
     37c:      	mov	x12, #-0x300            ; =-768
     380:      	mov	w13, #-0x3d300000       ; =-1026555904
     384:      	dup.4s	v19, w13
     388:      	mov	w13, #0x42c80000        ; =1120403456
     38c:      	dup.4s	v20, w13
     390:      	mov	w13, #0xaa3b            ; =43579
     394:      	movk	w13, #0x3fb8, lsl #16
     398:      	dup.4s	v21, w13
     39c:      	movi.4s	v22, #0x4b, lsl #24
     3a0:      	mov	w13, #0x7200            ; =29184
     3a4:      	movk	w13, #0xbf31, lsl #16
     3a8:      	dup.4s	v23, w13
     3ac:      	mov	w13, #0xbe8e            ; =48782
     3b0:      	movk	w13, #0xb5bf, lsl #16
     3b4:      	dup.4s	v24, w13
     3b8:      	mov	w13, #0x2bda            ; =11226
     3bc:      	movk	w13, #0x3950, lsl #16
     3c0:      	dup.4s	v25, w13
     3c4:      	mov	w13, #0x96c9            ; =38601
     3c8:      	movk	w13, #0x3ab6, lsl #16
     3cc:      	dup.4s	v26, w13
     3d0:      	mov	w13, #0x88a6            ; =34982
     3d4:      	movk	w13, #0x3c08, lsl #16
     3d8:      	dup.4s	v27, w13
     3dc:      	mov	w13, #0xaa7a            ; =43642
     3e0:      	movk	w13, #0x3d2a, lsl #16
     3e4:      	dup.4s	v28, w13
     3e8:      	mov	w13, #0xaaab            ; =43691
     3ec:      	movk	w13, #0x3e2a, lsl #16
     3f0:      	dup.4s	v29, w13
     3f4:      	mvni.4s	v30, #0x80, lsl #24
     3f8:      	movi.4s	v31, #0x3f, lsl #24
     3fc:      	fmov.4s	v8, #1.00000000
     400:      	fneg.4s	v9, v9
     404:      	mvni.4s	v10, #0x3f, msl #16
     408:      	fneg.4s	v10, v10
     40c:      	add	x13, x12, #0x300
     410:      	dup.2d	v11, x13
     414:      	add.2d	v11, v11, v4
     418:      	add.2d	v12, v11, v16
     41c:      	add.2d	v13, v11, v7
     420:      	add.2d	v14, v11, v6
     424:      	add.2d	v11, v11, v5
     428:      	mov.d	x13, v11[1]
     42c:      	fmov	x15, d11
     430:      	mov.d	x14, v14[1]
     434:      	fmov	x17, d14
     438:      	mov.d	x16, v13[1]
     43c:      	fmov	x1, d13
     440:      	mov.d	x0, v12[1]
     444:      	fmov	x2, d12
     448:      	ldp	q11, q12, [x10]
     44c:      	fsub.4s	v12, v12, v18
     450:      	fsub.4s	v11, v11, v17
     454:      	fcmge.4s	v13, v11, v19
     458:      	fcmge.4s	v14, v12, v19
     45c:      	fcmge.4s	v15, v20, v11
     460:      	fcmge.4s	v0, v20, v12
     464:      	and.16b	v0, v14, v0
     468:      	and.16b	v13, v13, v15
     46c:      	and.16b	v13, v13, v11
     470:      	and.16b	v0, v0, v12
     474:      	fmul.4s	v14, v0, v21
     478:      	fmul.4s	v15, v13, v21
     47c:      	mov.16b	v1, v30
     480:      	bsl.16b	v1, v22, v15
     484:      	mov.16b	v2, v30
     488:      	bsl.16b	v2, v22, v14
     48c:      	fadd.4s	v14, v14, v2
     490:      	fadd.4s	v15, v15, v1
     494:      	fsub.4s	v1, v15, v1
     498:      	fsub.4s	v2, v14, v2
     49c:      	fcvtzs.4s	v2, v2
     4a0:      	fcvtzs.4s	v1, v1
     4a4:      	scvtf.4s	v14, v1
     4a8:      	scvtf.4s	v15, v2
     4ac:      	fmul.4s	v3, v14, v23
     4b0:      	fadd.4s	v3, v13, v3
     4b4:      	fmul.4s	v13, v15, v23
     4b8:      	fadd.4s	v0, v0, v13
     4bc:      	fmul.4s	v13, v14, v24
     4c0:      	fmul.4s	v14, v15, v24
     4c4:      	fadd.4s	v0, v0, v14
     4c8:      	fadd.4s	v3, v3, v13
     4cc:      	fmul.4s	v13, v3, v25
     4d0:      	fmul.4s	v14, v0, v25
     4d4:      	fadd.4s	v14, v14, v26
     4d8:      	fadd.4s	v13, v13, v26
     4dc:      	fmul.4s	v13, v3, v13
     4e0:      	fmul.4s	v14, v0, v14
     4e4:      	fadd.4s	v14, v14, v27
     4e8:      	fadd.4s	v13, v13, v27
     4ec:      	fmul.4s	v13, v3, v13
     4f0:      	fmul.4s	v14, v0, v14
     4f4:      	fadd.4s	v14, v14, v28
     4f8:      	fadd.4s	v13, v13, v28
     4fc:      	fmul.4s	v13, v3, v13
     500:      	fmul.4s	v14, v0, v14
     504:      	fadd.4s	v14, v14, v29
     508:      	fadd.4s	v13, v13, v29
     50c:      	fmul.4s	v13, v3, v13
     510:      	fmul.4s	v14, v0, v14
     514:      	fadd.4s	v14, v14, v31
     518:      	fadd.4s	v13, v13, v31
     51c:      	fmul.4s	v15, v3, v3
     520:      	fmul.4s	v13, v15, v13
     524:      	fmul.4s	v15, v0, v0
     528:      	fmul.4s	v14, v15, v14
     52c:      	fadd.4s	v0, v0, v14
     530:      	fadd.4s	v3, v3, v13
     534:      	fadd.4s	v3, v3, v8
     538:      	fadd.4s	v0, v0, v8
     53c:      	sshr.4s	v13, v1, #0x1
     540:      	sshr.4s	v14, v2, #0x1
     544:      	shl.4s	v15, v14, #0x17
     548:      	add.4s	v15, v15, v8
     54c:      	fmul.4s	v0, v0, v15
     550:      	shl.4s	v15, v13, #0x17
     554:      	add.4s	v15, v15, v8
     558:      	fmul.4s	v3, v3, v15
     55c:      	sub.4s	v2, v2, v14
     560:      	sub.4s	v1, v1, v13
     564:      	shl.4s	v1, v1, #0x17
     568:      	add.4s	v1, v1, v8
     56c:      	fmul.4s	v1, v3, v1
     570:      	shl.4s	v2, v2, #0x17
     574:      	add.4s	v2, v2, v8
     578:      	fmul.4s	v0, v0, v2
     57c:      	fcmgt.4s	v2, v19, v12
     580:      	bic.16b	v0, v0, v2
     584:      	fcmgt.4s	v2, v19, v11
     588:      	bic.16b	v1, v1, v2
     58c:      	fcmgt.4s	v2, v11, v20
     590:      	bit.16b	v1, v9, v2
     594:      	fcmgt.4s	v2, v12, v20
     598:      	bit.16b	v0, v9, v2
     59c:      	fcmeq.4s	v2, v12, v12
     5a0:      	bif.16b	v0, v10, v2
     5a4:      	ldr	b2, [x15]
     5a8:      	ld1.b	{ v2 }[1], [x13]
     5ac:      	ld1.b	{ v2 }[2], [x17]
     5b0:      	ld1.b	{ v2 }[3], [x14]
     5b4:      	ld1.b	{ v2 }[4], [x1]
     5b8:      	ld1.b	{ v2 }[5], [x16]
     5bc:      	ld1.b	{ v2 }[6], [x2]
     5c0:      	ld1.b	{ v2 }[7], [x0]
     5c4:      	cmeq.8b	v2, v2, #0
     5c8:      	sshll.8h	v2, v2, #0x0
     5cc:      	fcmeq.4s	v3, v11, v11
     5d0:      	bif.16b	v1, v10, v3
     5d4:      	sshll.4s	v3, v2, #0x0
     5d8:      	bic.16b	v1, v1, v3
     5dc:      	sshll2.4s	v2, v2, #0x0
     5e0:      	bic.16b	v0, v0, v2
     5e4:      	str	q0, [x10, #0x6010]
     5e8:      	str	q1, [x10, #0x6000]
     5ec:      	add	x10, x10, #0x20
     5f0:      	adds	x12, x12, #0x1
     5f4:      	b.lo	0x40c <ltmp0+0x40c>
     5f8:      	add	x10, x9, #0x19, lsl #12 ; =0x19000
     5fc:      	add	x10, x10, #0x800
     600:      	ldp	q4, q5, [x10]
     604:      	add	x10, x9, #0x19, lsl #12 ; =0x19000
     608:      	add	x10, x10, #0x820
     60c:      	ldp	q7, q6, [x10]
     610:      	add	x10, x9, #0x19, lsl #12 ; =0x19000
     614:      	add	x10, x10, #0x840
     618:      	ldp	q16, q17, [x10]
     61c:      	add	x10, x9, #0x19, lsl #12 ; =0x19000
     620:      	add	x10, x10, #0x860
     624:      	add	x9, x9, #0x19, lsl #12  ; =0x19000
     628:      	add	x9, x9, #0x8e0
     62c:      	ldp	q19, q18, [x10]
     630:      	mov	w10, #0xcc4             ; =3268
     634:      	ldp	q0, q1, [x9, #-0x60]
     638:      	fadd.4s	v5, v5, v1
     63c:      	fadd.4s	v4, v4, v0
     640:      	ldp	q0, q1, [x9, #-0x40]
     644:      	fadd.4s	v6, v6, v1
     648:      	fadd.4s	v7, v7, v0
     64c:      	ldp	q0, q1, [x9, #-0x20]
     650:      	fadd.4s	v17, v17, v1
     654:      	fadd.4s	v16, v16, v0
     658:      	ldp	q0, q1, [x9], #0x80
     65c:      	fadd.4s	v18, v18, v1
     660:      	fadd.4s	v19, v19, v0
     664:      	sub	x12, x10, #0xcc0
     668:      	add	x10, x10, #0x4
     66c:      	cmp	x12, #0x2fc
     670:      	b.lo	0x634 <ltmp0+0x634>
     674:      	mov	x9, #0x0                ; =0
     678:      	movi.2d	v0, #0000000000000000
     67c:      	fadd.4s	v1, v5, v0
     680:      	fadd.4s	v0, v4, v0
     684:      	fadd.4s	v0, v0, v7
     688:      	fadd.4s	v1, v1, v6
     68c:      	fadd.4s	v1, v1, v17
     690:      	fadd.4s	v0, v0, v16
     694:      	fadd.4s	v4, v0, v19
     698:      	fadd.4s	v5, v1, v18
     69c:      	dup.2d	v6, x8
     6a0:      	ldp	q18, q17, [sp, #0x20]
     6a4:      	ldp	q20, q19, [sp]
     6a8:      	dup.2d	v0, x9
     6ac:      	add.2d	v1, v0, v17
     6b0:      	add.2d	v2, v0, v19
     6b4:      	add.2d	v3, v0, v18
     6b8:      	add.2d	v0, v0, v20
     6bc:      	add	x8, x11, x9, lsl #5
     6c0:      	ldp	q7, q16, [x8]
     6c4:      	fdiv.4s	v16, v16, v5
     6c8:      	fdiv.4s	v7, v7, v4
     6cc:      	shl.2d	v0, v0, #0x2
     6d0:      	shl.2d	v3, v3, #0x2
     6d4:      	shl.2d	v2, v2, #0x2
     6d8:      	shl.2d	v1, v1, #0x2
     6dc:      	add.2d	v1, v6, v1
     6e0:      	add.2d	v0, v6, v0
     6e4:      	mov.d	x8, v0[1]
     6e8:      	fmov	x10, d0
     6ec:      	str	s7, [x10]
     6f0:      	st1.s	{ v7 }[1], [x8]
     6f4:      	add.2d	v0, v6, v3
     6f8:      	mov.d	x8, v0[1]
     6fc:      	fmov	x10, d0
     700:      	st1.s	{ v7 }[2], [x10]
     704:      	add.2d	v0, v6, v2
     708:      	st1.s	{ v7 }[3], [x8]
     70c:      	mov.d	x8, v0[1]
     710:      	fmov	x10, d0
     714:      	str	s16, [x10]
     718:      	st1.s	{ v16 }[1], [x8]
     71c:      	mov.d	x8, v1[1]
     720:      	fmov	x10, d1
     724:      	st1.s	{ v16 }[2], [x10]
     728:      	st1.s	{ v16 }[3], [x8]
     72c:      	add	x9, x9, #0x1
     730:      	cmp	x9, #0x300
     734:      	b.ne	0x6a8 <ltmp0+0x6a8>
     738:      	ldp	d9, d8, [sp, #0x70]
     73c:      	ldp	d11, d10, [sp, #0x60]
     740:      	ldp	d13, d12, [sp, #0x50]
     744:      	ldp	d15, d14, [sp, #0x40]
     748:      	add	sp, sp, #0x80
     74c:      	ret

0000000000000750 <_llm_rows.packet_batch.blocks>:
     750:      	sub	sp, sp, #0x120
     754:      	stp	d15, d14, [sp, #0x80]
     758:      	stp	d13, d12, [sp, #0x90]
     75c:      	stp	d11, d10, [sp, #0xa0]
     760:      	stp	d9, d8, [sp, #0xb0]
     764:      	stp	x28, x27, [sp, #0xc0]
     768:      	stp	x26, x25, [sp, #0xd0]
     76c:      	stp	x24, x23, [sp, #0xe0]
     770:      	stp	x22, x21, [sp, #0xf0]
     774:      	stp	x20, x19, [sp, #0x100]
     778:      	stp	x29, x30, [sp, #0x110]
     77c:      	str	x0, [sp, #0x58]
     780:      	cbz	w3, 0x1488 <_llm_rows.packet_batch.blocks+0xd38>
     784:      	mov	x19, x3
     788:      	mov	x20, x2
     78c:      	mov	w22, #0x0               ; =0
     790:      	ldp	w9, w8, [x2, #0x2c]
     794:      	stp	w8, w9, [sp, #0x50]
     798:      	mov	w27, #0x3800            ; =14336
     79c:      	movk	w27, #0x1, lsl #16
     7a0:      	ldp	w26, w25, [x2]
     7a4:      	adrp	x8, 0x0 <ltmp0>
     7a8:      	ldr	q0, [x8]
     7ac:      	str	q0, [sp, #0x40]
     7b0:      	movi.2s	v8, #0x3, lsl #8
     7b4:      	adrp	x8, 0x0 <ltmp0>
     7b8:      	ldr	q0, [x8]
     7bc:      	str	q0, [sp, #0x30]
     7c0:      	adrp	x8, 0x0 <ltmp0>
     7c4:      	ldr	q0, [x8]
     7c8:      	str	q0, [sp, #0x10]
     7cc:      	movi.8b	v9, #0x1
     7d0:      	mvni.4s	v14, #0x7f, msl #16
     7d4:      	movi.4s	v15, #0x4b, lsl #24
     7d8:      	mov	w28, #0xaaab            ; =43691
     7dc:      	movk	w28, #0x3e2a, lsl #16
     7e0:      	mvni.4s	v0, #0x3f, msl #16
     7e4:      	fneg.4s	v0, v0
     7e8:      	str	q0, [sp, #0x60]
     7ec:      	ldp	w23, w24, [x2, #0x8]
     7f0:      	str	w3, [sp, #0x2c]
     7f4:      	b	0x83c <_llm_rows.packet_batch.blocks+0xec>
     7f8:      	mov	w8, #0x18               ; =24
     7fc:      	str	w8, [x20, #0x24]
     800:      	ldr	w19, [sp, #0x2c]
     804:      	add	w8, w26, #0x1
     808:      	ldp	w10, w9, [sp, #0x50]
     80c:      	cmp	w8, w9
     810:      	cset	w8, eq
     814:      	csinc	w26, wzr, w26, eq
     818:      	cinc	w9, w25, eq
     81c:      	cmp	w9, w10
     820:      	cset	w10, eq
     824:      	ands	w8, w8, w10
     828:      	csel	w25, wzr, w9, ne
     82c:      	add	w23, w23, w8
     830:      	add	w22, w22, #0x1
     834:      	cmp	w22, w19
     838:      	b.eq	0x1488 <_llm_rows.packet_batch.blocks+0xd38>
     83c:      	ubfiz	x8, x26, #5, #32
     840:      	cmp	x8, x24
     844:      	csel	x9, x8, xzr, ls
     848:      	subs	x10, x24, x9
     84c:      	cmp	x10, #0x20
     850:      	mov	w11, #0x20              ; =32
     854:      	csel	x10, x10, x11, lo
     858:      	cmp	x24, x9
     85c:      	stp	w26, w25, [x20]
     860:      	str	w23, [x20, #0x8]
     864:      	str	wzr, [x20, #0x24]
     868:      	ccmp	x8, x24, #0x2, hi
     86c:      	csel	x21, x10, xzr, ls
     870:      	cmp	x21, #0x20
     874:      	b.lo	0x8d0 <_llm_rows.packet_batch.blocks+0x180>
     878:      	ldr	x21, [sp, #0x58]
     87c:      	mov	x0, x21
     880:      	mov	x1, x20
     884:      	bl	0x884 <_llm_rows.packet_batch.blocks+0x134>
     888:      	mov	w8, #0x8                ; =8
     88c:      	str	w8, [x20, #0x24]
     890:      	mov	x0, x21
     894:      	mov	x1, x20
     898:      	bl	0x898 <_llm_rows.packet_batch.blocks+0x148>
     89c:      	mov	w8, #0x10               ; =16
     8a0:      	str	w8, [x20, #0x24]
     8a4:      	mov	x0, x21
     8a8:      	mov	x1, x20
     8ac:      	bl	0x8ac <_llm_rows.packet_batch.blocks+0x15c>
     8b0:      	mov	w8, #0x18               ; =24
     8b4:      	str	w8, [x20, #0x24]
     8b8:      	mov	x0, x21
     8bc:      	mov	x1, x20
     8c0:      	bl	0x8c0 <_llm_rows.packet_batch.blocks+0x170>
     8c4:      	movi.4s	v15, #0x4b, lsl #24
     8c8:      	mvni.4s	v14, #0x7f, msl #16
     8cc:      	b	0x804 <_llm_rows.packet_batch.blocks+0xb4>
     8d0:      	lsr	x19, x21, #3
     8d4:      	cmp	x21, #0x8
     8d8:      	b.lo	0x93c <_llm_rows.packet_batch.blocks+0x1ec>
     8dc:      	str	wzr, [x20, #0x24]
     8e0:      	ldr	x0, [sp, #0x58]
     8e4:      	mov	x1, x20
     8e8:      	bl	0x8e8 <_llm_rows.packet_batch.blocks+0x198>
     8ec:      	movi.4s	v15, #0x4b, lsl #24
     8f0:      	mvni.4s	v14, #0x7f, msl #16
     8f4:      	cmp	x19, #0x1
     8f8:      	b.eq	0x93c <_llm_rows.packet_batch.blocks+0x1ec>
     8fc:      	mov	w8, #0x8                ; =8
     900:      	str	w8, [x20, #0x24]
     904:      	ldr	x0, [sp, #0x58]
     908:      	mov	x1, x20
     90c:      	bl	0x90c <_llm_rows.packet_batch.blocks+0x1bc>
     910:      	movi.4s	v15, #0x4b, lsl #24
     914:      	mvni.4s	v14, #0x7f, msl #16
     918:      	cmp	x19, #0x2
     91c:      	b.eq	0x93c <_llm_rows.packet_batch.blocks+0x1ec>
     920:      	mov	w8, #0x10               ; =16
     924:      	str	w8, [x20, #0x24]
     928:      	ldr	x0, [sp, #0x58]
     92c:      	mov	x1, x20
     930:      	bl	0x930 <_llm_rows.packet_batch.blocks+0x1e0>
     934:      	movi.4s	v15, #0x4b, lsl #24
     938:      	mvni.4s	v14, #0x7f, msl #16
     93c:      	and	w8, w21, #0x7
     940:      	cbz	w8, 0x7f8 <_llm_rows.packet_batch.blocks+0xa8>
     944:      	dup.4s	v7, w8
     948:      	ldp	q0, q1, [sp, #0x30]
     94c:      	cmhi.4s	v0, v7, v0
     950:      	cmhi.4s	v1, v7, v1
     954:      	uzp1.8h	v6, v1, v0
     958:      	umaxv.8h	h2, v6
     95c:      	fmov	w8, s2
     960:      	tbz	w8, #0x0, 0x7f8 <_llm_rows.packet_batch.blocks+0xa8>
     964:      	mov	x13, #0x0               ; =0
     968:      	ldr	x10, [x20, #0x88]
     96c:      	add	x12, x10, #0x6, lsl #12 ; =0x6000
     970:      	add	x8, x10, #0x12, lsl #12 ; =0x12000
     974:      	dup.2d	v16, x8
     978:      	add	x11, x10, x27
     97c:      	mov	w8, #0x9800             ; =38912
     980:      	movk	w8, #0x1, lsl #16
     984:      	add	x8, x10, x8
     988:      	ldr	x15, [sp, #0x58]
     98c:      	ldr	x14, [x15]
     990:      	lsl	w9, w19, #3
     994:      	orr	w9, w9, w26, lsl #5
     998:      	dup.4s	v2, w9
     99c:      	ldr	x9, [x15, #0x30]
     9a0:      	ldp	q4, q3, [sp, #0x30]
     9a4:      	orr.16b	v3, v2, v3
     9a8:      	orr.16b	v2, v2, v4
     9ac:      	and.16b	v17, v0, v2
     9b0:      	and.16b	v18, v1, v3
     9b4:      	movi.4s	v3, #0x3, lsl #8
     9b8:      	umull2.2d	v2, v17, v3
     9bc:      	umull2.2d	v3, v18, v3
     9c0:      	umull.2d	v4, v17, v8
     9c4:      	umull.2d	v5, v18, v8
     9c8:      	ldr	q19, [sp, #0x10]
     9cc:      	and.16b	v6, v6, v19
     9d0:      	addv.8h	h6, v6
     9d4:      	dup.2d	v19, x14
     9d8:      	fmov	w14, s6
     9dc:      	mov	w5, #0xf2ca             ; =62154
     9e0:      	movk	w5, #0xf149, lsl #16
     9e4:      	b	0xa08 <_llm_rows.packet_batch.blocks+0x2b8>
     9e8:      	add	x15, x10, x13, lsl #5
     9ec:      	ldp	q22, q23, [x15]
     9f0:      	bif.16b	v21, v23, v0
     9f4:      	bif.16b	v20, v22, v1
     9f8:      	stp	q20, q21, [x15]
     9fc:      	add	x13, x13, #0x1
     a00:      	cmp	x13, #0x300
     a04:      	b.eq	0xaf4 <_llm_rows.packet_batch.blocks+0x3a4>
     a08:      	dup.2d	v22, x13
     a0c:      	add.2d	v20, v22, v5
     a10:      	shl.2d	v20, v20, #0x2
     a14:      	add.2d	v23, v19, v20
     a18:      	movi.2d	v20, #0000000000000000
     a1c:      	movi.2d	v21, #0000000000000000
     a20:      	tbnz	w14, #0x0, 0xa6c <_llm_rows.packet_batch.blocks+0x31c>
     a24:      	and	w15, w14, #0xff
     a28:      	tbnz	w15, #0x1, 0xa7c <_llm_rows.packet_batch.blocks+0x32c>
     a2c:      	add.2d	v23, v22, v3
     a30:      	shl.2d	v23, v23, #0x2
     a34:      	add.2d	v23, v19, v23
     a38:      	tbnz	w15, #0x2, 0xa94 <_llm_rows.packet_batch.blocks+0x344>
     a3c:      	tbnz	w15, #0x3, 0xaa0 <_llm_rows.packet_batch.blocks+0x350>
     a40:      	add.2d	v23, v22, v4
     a44:      	shl.2d	v23, v23, #0x2
     a48:      	add.2d	v23, v19, v23
     a4c:      	tbnz	w15, #0x4, 0xab8 <_llm_rows.packet_batch.blocks+0x368>
     a50:      	tbnz	w15, #0x5, 0xac4 <_llm_rows.packet_batch.blocks+0x374>
     a54:      	add.2d	v22, v22, v2
     a58:      	shl.2d	v22, v22, #0x2
     a5c:      	add.2d	v22, v19, v22
     a60:      	tbnz	w15, #0x6, 0xadc <_llm_rows.packet_batch.blocks+0x38c>
     a64:      	tbz	w15, #0x7, 0x9e8 <_llm_rows.packet_batch.blocks+0x298>
     a68:      	b	0xae8 <_llm_rows.packet_batch.blocks+0x398>
     a6c:      	fmov	x15, d23
     a70:      	ldr	s20, [x15]
     a74:      	and	w15, w14, #0xff
     a78:      	tbz	w15, #0x1, 0xa2c <_llm_rows.packet_batch.blocks+0x2dc>
     a7c:      	mov.d	x16, v23[1]
     a80:      	ld1.s	{ v20 }[1], [x16]
     a84:      	add.2d	v23, v22, v3
     a88:      	shl.2d	v23, v23, #0x2
     a8c:      	add.2d	v23, v19, v23
     a90:      	tbz	w15, #0x2, 0xa3c <_llm_rows.packet_batch.blocks+0x2ec>
     a94:      	fmov	x16, d23
     a98:      	ld1.s	{ v20 }[2], [x16]
     a9c:      	tbz	w15, #0x3, 0xa40 <_llm_rows.packet_batch.blocks+0x2f0>
     aa0:      	mov.d	x16, v23[1]
     aa4:      	ld1.s	{ v20 }[3], [x16]
     aa8:      	add.2d	v23, v22, v4
     aac:      	shl.2d	v23, v23, #0x2
     ab0:      	add.2d	v23, v19, v23
     ab4:      	tbz	w15, #0x4, 0xa50 <_llm_rows.packet_batch.blocks+0x300>
     ab8:      	fmov	x16, d23
     abc:      	ld1.s	{ v21 }[0], [x16]
     ac0:      	tbz	w15, #0x5, 0xa54 <_llm_rows.packet_batch.blocks+0x304>
     ac4:      	mov.d	x16, v23[1]
     ac8:      	ld1.s	{ v21 }[1], [x16]
     acc:      	add.2d	v22, v22, v2
     ad0:      	shl.2d	v22, v22, #0x2
     ad4:      	add.2d	v22, v19, v22
     ad8:      	tbz	w15, #0x6, 0xa64 <_llm_rows.packet_batch.blocks+0x314>
     adc:      	fmov	x16, d22
     ae0:      	ld1.s	{ v21 }[2], [x16]
     ae4:      	tbz	w15, #0x7, 0x9e8 <_llm_rows.packet_batch.blocks+0x298>
     ae8:      	mov.d	x15, v22[1]
     aec:      	ld1.s	{ v21 }[3], [x15]
     af0:      	b	0x9e8 <_llm_rows.packet_batch.blocks+0x298>
     af4:      	mov	x13, #0x0               ; =0
     af8:      	sshll2.2d	v24, v0, #0x0
     afc:      	sshll2.2d	v22, v1, #0x0
     b00:      	sshll.2d	v19, v0, #0x0
     b04:      	sshll.2d	v20, v1, #0x0
     b08:      	dup.2d	v21, x13
     b0c:      	add	x14, x12, x13, lsl #6
     b10:      	ldp	q25, q23, [x14, #0x20]
     b14:      	ldp	q27, q26, [x14]
     b18:      	bsl.16b	v20, v21, v27
     b1c:      	bsl.16b	v19, v21, v25
     b20:      	mov.16b	v25, v22
     b24:      	bsl.16b	v25, v21, v26
     b28:      	bif.16b	v21, v23, v24
     b2c:      	stp	q19, q21, [x14, #0x20]
     b30:      	stp	q20, q25, [x14]
     b34:      	add	x13, x13, #0x1
     b38:      	cmp	x13, #0x300
     b3c:      	b.ne	0xaf8 <_llm_rows.packet_batch.blocks+0x3a8>
     b40:      	mov	x13, #0x0               ; =0
     b44:      	sshll.2d	v30, v1, #0x0
     b48:      	sshll.2d	v29, v0, #0x0
     b4c:      	movi.4s	v21, #0x3, lsl #8
     b50:      	and.16b	v19, v0, v21
     b54:      	mvn.16b	v20, v0
     b58:      	sub.4s	v19, v19, v20
     b5c:      	and.16b	v20, v1, v21
     b60:      	mvn.16b	v21, v1
     b64:      	sub.4s	v20, v20, v21
     b68:      	mov.s	w14, v20[1]
     b6c:      	mov.s	w15, v18[1]
     b70:      	udiv	w16, w15, w14
     b74:      	msub	w14, w16, w14, w15
     b78:      	mov.s	w15, v20[3]
     b7c:      	mov.s	w16, v20[2]
     b80:      	fmov	w17, s20
     b84:      	fmov	w0, s18
     b88:      	udiv	w1, w0, w17
     b8c:      	msub	w17, w1, w17, w0
     b90:      	mov.s	w0, v18[3]
     b94:      	udiv	w1, w0, w15
     b98:      	msub	w15, w1, w15, w0
     b9c:      	mov.s	w0, v18[2]
     ba0:      	udiv	w1, w0, w16
     ba4:      	msub	w16, w1, w16, w0
     ba8:      	mov.s	w0, v19[1]
     bac:      	mov.s	w1, v17[1]
     bb0:      	udiv	w2, w1, w0
     bb4:      	msub	w0, w2, w0, w1
     bb8:      	mov.s	w1, v19[3]
     bbc:      	mov.s	w2, v17[3]
     bc0:      	udiv	w3, w2, w1
     bc4:      	msub	w1, w3, w1, w2
     bc8:      	mov.s	w2, v19[2]
     bcc:      	mov.s	w3, v17[2]
     bd0:      	udiv	w4, w3, w2
     bd4:      	msub	w2, w4, w2, w3
     bd8:      	fmov	w3, s19
     bdc:      	fmov	w4, s17
     be0:      	fmov	s17, w2
     be4:      	mov.s	v17[1], w1
     be8:      	udiv	w1, w4, w3
     bec:      	msub	w1, w1, w3, w4
     bf0:      	ushll.2d	v19, v17, #0x0
     bf4:      	fmov	s17, w1
     bf8:      	mov.s	v17[1], w0
     bfc:      	ushll.2d	v20, v17, #0x0
     c00:      	fmov	s17, w16
     c04:      	mov.s	v17[1], w15
     c08:      	fmov	s18, w17
     c0c:      	mov.s	v18[1], w14
     c10:      	ushll.2d	v21, v17, #0x0
     c14:      	ushll.2d	v23, v18, #0x0
     c18:      	and.16b	v25, v24, v16
     c1c:      	and.16b	v26, v22, v16
     c20:      	and.16b	v27, v29, v16
     c24:      	and.16b	v28, v30, v16
     c28:      	adrp	x14, 0x0 <ltmp0>
     c2c:      	ldr	q16, [x14]
     c30:      	and.16b	v24, v24, v16
     c34:      	adrp	x14, 0x0 <ltmp0>
     c38:      	ldr	q16, [x14]
     c3c:      	and.16b	v22, v22, v16
     c40:      	adrp	x14, 0x0 <ltmp0>
     c44:      	ldr	q16, [x14]
     c48:      	and.16b	v29, v29, v16
     c4c:      	adrp	x14, 0x0 <ltmp0>
     c50:      	ldr	q16, [x14]
     c54:      	and.16b	v30, v30, v16
     c58:      	ldp	q16, q17, [sp, #0x30]
     c5c:      	cmhs.4s	v16, v16, v7
     c60:      	cmhs.4s	v7, v17, v7
     c64:      	uzp1.8h	v7, v7, v16
     c68:      	xtn.8b	v31, v7
     c6c:      	mov	w16, #-0x3d300000       ; =-1026555904
     c70:      	mov	w17, #0x42c80000        ; =1120403456
     c74:      	mov	w0, #0xaa3b             ; =43579
     c78:      	movk	w0, #0x3fb8, lsl #16
     c7c:      	mov	w1, #0x7200             ; =29184
     c80:      	movk	w1, #0xbf31, lsl #16
     c84:      	mov	w2, #0xbe8e             ; =48782
     c88:      	movk	w2, #0xb5bf, lsl #16
     c8c:      	mov	w3, #0x2bda             ; =11226
     c90:      	movk	w3, #0x3950, lsl #16
     c94:      	mov	w4, #0x96c9             ; =38601
     c98:      	movk	w4, #0x3ab6, lsl #16
     c9c:      	mov	w6, #0x88a6             ; =34982
     ca0:      	movk	w6, #0x3c08, lsl #16
     ca4:      	mov	w7, #0xaa7a             ; =43642
     ca8:      	movk	w7, #0x3d2a, lsl #16
     cac:      	b	0xcbc <_llm_rows.packet_batch.blocks+0x56c>
     cb0:      	add	x13, x13, #0x1
     cb4:      	cmp	x13, #0x300
     cb8:      	b.eq	0xdbc <_llm_rows.packet_batch.blocks+0x66c>
     cbc:      	dup.2d	v10, x13
     cc0:      	fmov	w14, s6
     cc4:      	add	x15, x12, x13, lsl #6
     cc8:      	ldp	q16, q7, [x15, #0x20]
     ccc:      	ldp	q17, q18, [x15]
     cd0:      	cmge.2d	v18, v21, v18
     cd4:      	cmge.2d	v17, v23, v17
     cd8:      	uzp1.4s	v17, v17, v18
     cdc:      	cmge.2d	v16, v20, v16
     ce0:      	cmge.2d	v7, v19, v7
     ce4:      	uzp1.4s	v7, v16, v7
     ce8:      	uzp1.8h	v7, v17, v7
     cec:      	xtn.8b	v7, v7
     cf0:      	orr.8b	v17, v31, v7
     cf4:      	add.2d	v7, v28, v30
     cf8:      	add.2d	v16, v7, v10
     cfc:      	and.8b	v11, v17, v9
     d00:      	tbnz	w14, #0x0, 0xd40 <_llm_rows.packet_batch.blocks+0x5f0>
     d04:      	and	w14, w14, #0xff
     d08:      	tbnz	w14, #0x1, 0xd50 <_llm_rows.packet_batch.blocks+0x600>
     d0c:      	add.2d	v16, v26, v22
     d10:      	add.2d	v17, v16, v10
     d14:      	tbnz	w14, #0x2, 0xd64 <_llm_rows.packet_batch.blocks+0x614>
     d18:      	tbnz	w14, #0x3, 0xd70 <_llm_rows.packet_batch.blocks+0x620>
     d1c:      	add.2d	v17, v27, v29
     d20:      	add.2d	v18, v17, v10
     d24:      	tbnz	w14, #0x4, 0xd84 <_llm_rows.packet_batch.blocks+0x634>
     d28:      	tbnz	w14, #0x5, 0xd90 <_llm_rows.packet_batch.blocks+0x640>
     d2c:      	add.2d	v18, v25, v24
     d30:      	add.2d	v10, v18, v10
     d34:      	tbnz	w14, #0x6, 0xda4 <_llm_rows.packet_batch.blocks+0x654>
     d38:      	tbz	w14, #0x7, 0xcb0 <_llm_rows.packet_batch.blocks+0x560>
     d3c:      	b	0xdb0 <_llm_rows.packet_batch.blocks+0x660>
     d40:      	fmov	x15, d16
     d44:      	str	b11, [x15]
     d48:      	and	w14, w14, #0xff
     d4c:      	tbz	w14, #0x1, 0xd0c <_llm_rows.packet_batch.blocks+0x5bc>
     d50:      	mov.d	x15, v16[1]
     d54:      	st1.b	{ v11 }[1], [x15]
     d58:      	add.2d	v16, v26, v22
     d5c:      	add.2d	v17, v16, v10
     d60:      	tbz	w14, #0x2, 0xd18 <_llm_rows.packet_batch.blocks+0x5c8>
     d64:      	fmov	x15, d17
     d68:      	st1.b	{ v11 }[2], [x15]
     d6c:      	tbz	w14, #0x3, 0xd1c <_llm_rows.packet_batch.blocks+0x5cc>
     d70:      	mov.d	x15, v17[1]
     d74:      	st1.b	{ v11 }[3], [x15]
     d78:      	add.2d	v17, v27, v29
     d7c:      	add.2d	v18, v17, v10
     d80:      	tbz	w14, #0x4, 0xd28 <_llm_rows.packet_batch.blocks+0x5d8>
     d84:      	fmov	x15, d18
     d88:      	st1.b	{ v11 }[4], [x15]
     d8c:      	tbz	w14, #0x5, 0xd2c <_llm_rows.packet_batch.blocks+0x5dc>
     d90:      	mov.d	x15, v18[1]
     d94:      	st1.b	{ v11 }[5], [x15]
     d98:      	add.2d	v18, v25, v24
     d9c:      	add.2d	v10, v18, v10
     da0:      	tbz	w14, #0x6, 0xd38 <_llm_rows.packet_batch.blocks+0x5e8>
     da4:      	fmov	x15, d10
     da8:      	st1.b	{ v11 }[6], [x15]
     dac:      	tbz	w14, #0x7, 0xcb0 <_llm_rows.packet_batch.blocks+0x560>
     db0:      	mov.d	x14, v10[1]
     db4:      	st1.b	{ v11 }[7], [x14]
     db8:      	b	0xcb0 <_llm_rows.packet_batch.blocks+0x560>
     dbc:      	mov	x12, #-0x300            ; =-768
     dc0:      	mov	x13, x10
     dc4:      	b	0xe10 <_llm_rows.packet_batch.blocks+0x6c0>
     dc8:      	cmeq.8b	v19, v19, #0
     dcc:      	sshll.8h	v19, v19, #0x0
     dd0:      	sshll.4s	v20, v19, #0x0
     dd4:      	sshll2.4s	v19, v19, #0x0
     dd8:      	ldp	q22, q21, [x13]
     ddc:      	and.16b	v22, v1, v22
     de0:      	dup.4s	v23, w5
     de4:      	and.16b	v21, v0, v21
     de8:      	bsl.16b	v19, v23, v21
     dec:      	bsl.16b	v20, v23, v22
     df0:      	add	x14, x13, x27
     df4:      	ldp	q22, q21, [x14]
     df8:      	bif.16b	v20, v22, v1
     dfc:      	bif.16b	v19, v21, v0
     e00:      	stp	q20, q19, [x14]
     e04:      	add	x13, x13, #0x20
     e08:      	adds	x12, x12, #0x1
     e0c:      	b.hs	0xec4 <_llm_rows.packet_batch.blocks+0x774>
     e10:      	fmov	w14, s6
     e14:      	add	x15, x12, #0x300
     e18:      	dup.2d	v20, x15
     e1c:      	add.2d	v21, v7, v20
     e20:      	tbz	w14, #0x0, 0xe38 <_llm_rows.packet_batch.blocks+0x6e8>
     e24:      	fmov	x15, d21
     e28:      	ldr	b19, [x15]
     e2c:      	and	w14, w14, #0xff
     e30:      	tbnz	w14, #0x1, 0xe44 <_llm_rows.packet_batch.blocks+0x6f4>
     e34:      	b	0xe4c <_llm_rows.packet_batch.blocks+0x6fc>
     e38:      	movi.2d	v19, #0000000000000000
     e3c:      	and	w14, w14, #0xff
     e40:      	tbz	w14, #0x1, 0xe4c <_llm_rows.packet_batch.blocks+0x6fc>
     e44:      	mov.d	x15, v21[1]
     e48:      	ld1.b	{ v19 }[1], [x15]
     e4c:      	add.2d	v21, v16, v20
     e50:      	tbnz	w14, #0x2, 0xe74 <_llm_rows.packet_batch.blocks+0x724>
     e54:      	tbnz	w14, #0x3, 0xe80 <_llm_rows.packet_batch.blocks+0x730>
     e58:      	add.2d	v21, v17, v20
     e5c:      	tbnz	w14, #0x4, 0xe90 <_llm_rows.packet_batch.blocks+0x740>
     e60:      	tbnz	w14, #0x5, 0xe9c <_llm_rows.packet_batch.blocks+0x74c>
     e64:      	add.2d	v20, v18, v20
     e68:      	tbnz	w14, #0x6, 0xeac <_llm_rows.packet_batch.blocks+0x75c>
     e6c:      	tbz	w14, #0x7, 0xdc8 <_llm_rows.packet_batch.blocks+0x678>
     e70:      	b	0xeb8 <_llm_rows.packet_batch.blocks+0x768>
     e74:      	fmov	x15, d21
     e78:      	ld1.b	{ v19 }[2], [x15]
     e7c:      	tbz	w14, #0x3, 0xe58 <_llm_rows.packet_batch.blocks+0x708>
     e80:      	mov.d	x15, v21[1]
     e84:      	ld1.b	{ v19 }[3], [x15]
     e88:      	add.2d	v21, v17, v20
     e8c:      	tbz	w14, #0x4, 0xe60 <_llm_rows.packet_batch.blocks+0x710>
     e90:      	fmov	x15, d21
     e94:      	ld1.b	{ v19 }[4], [x15]
     e98:      	tbz	w14, #0x5, 0xe64 <_llm_rows.packet_batch.blocks+0x714>
     e9c:      	mov.d	x15, v21[1]
     ea0:      	ld1.b	{ v19 }[5], [x15]
     ea4:      	add.2d	v20, v18, v20
     ea8:      	tbz	w14, #0x6, 0xe6c <_llm_rows.packet_batch.blocks+0x71c>
     eac:      	fmov	x15, d20
     eb0:      	ld1.b	{ v19 }[6], [x15]
     eb4:      	tbz	w14, #0x7, 0xdc8 <_llm_rows.packet_batch.blocks+0x678>
     eb8:      	mov.d	x14, v20[1]
     ebc:      	ld1.b	{ v19 }[7], [x14]
     ec0:      	b	0xdc8 <_llm_rows.packet_batch.blocks+0x678>
     ec4:      	add	x12, x10, x27
     ec8:      	ldp	q19, q20, [x12]
     ecc:      	mov	w12, #0x3820            ; =14368
     ed0:      	movk	w12, #0x1, lsl #16
     ed4:      	add	x12, x10, x12
     ed8:      	ldp	q21, q22, [x12]
     edc:      	mov	w12, #0x3840            ; =14400
     ee0:      	movk	w12, #0x1, lsl #16
     ee4:      	add	x12, x10, x12
     ee8:      	ldp	q23, q24, [x12]
     eec:      	mov	w12, #0x3860            ; =14432
     ef0:      	movk	w12, #0x1, lsl #16
     ef4:      	add	x12, x10, x12
     ef8:      	and.16b	v20, v0, v20
     efc:      	and.16b	v19, v1, v19
     f00:      	ldp	q25, q27, [x12]
     f04:      	and.16b	v22, v0, v22
     f08:      	and.16b	v26, v1, v21
     f0c:      	and.16b	v24, v0, v24
     f10:      	and.16b	v23, v1, v23
     f14:      	and.16b	v21, v0, v27
     f18:      	and.16b	v25, v1, v25
     f1c:      	mov	w12, #0x38e0            ; =14560
     f20:      	movk	w12, #0x1, lsl #16
     f24:      	add	x12, x10, x12
     f28:      	mov	w13, #0x9c4             ; =2500
     f2c:      	ldp	q27, q28, [x12, #-0x60]
     f30:      	and.16b	v28, v0, v28
     f34:      	and.16b	v27, v1, v27
     f38:      	fmaxnm.4s	v27, v19, v27
     f3c:      	fmaxnm.4s	v28, v20, v28
     f40:      	ldp	q29, q30, [x12, #-0x40]
     f44:      	and.16b	v30, v0, v30
     f48:      	and.16b	v29, v1, v29
     f4c:      	fmaxnm.4s	v29, v26, v29
     f50:      	fmaxnm.4s	v30, v22, v30
     f54:      	ldp	q31, q10, [x12, #-0x20]
     f58:      	and.16b	v10, v0, v10
     f5c:      	and.16b	v31, v1, v31
     f60:      	fmaxnm.4s	v31, v23, v31
     f64:      	fmaxnm.4s	v10, v24, v10
     f68:      	ldp	q11, q12, [x12], #0x80
     f6c:      	and.16b	v12, v0, v12
     f70:      	and.16b	v11, v1, v11
     f74:      	fmaxnm.4s	v11, v25, v11
     f78:      	fmaxnm.4s	v12, v21, v12
     f7c:      	bit.16b	v20, v28, v0
     f80:      	bit.16b	v19, v27, v1
     f84:      	bit.16b	v22, v30, v0
     f88:      	bit.16b	v26, v29, v1
     f8c:      	bit.16b	v24, v10, v0
     f90:      	bit.16b	v23, v31, v1
     f94:      	bit.16b	v21, v12, v0
     f98:      	bit.16b	v25, v11, v1
     f9c:      	sub	x14, x13, #0x9c0
     fa0:      	add	x13, x13, #0x4
     fa4:      	cmp	x14, #0x2fc
     fa8:      	b.lo	0xf2c <_llm_rows.packet_batch.blocks+0x7dc>
     fac:      	fmaxnm.4s	v20, v20, v14
     fb0:      	fmaxnm.4s	v19, v19, v14
     fb4:      	fmaxnm.4s	v19, v19, v26
     fb8:      	fmaxnm.4s	v20, v20, v22
     fbc:      	fmaxnm.4s	v20, v20, v24
     fc0:      	fmaxnm.4s	v19, v19, v23
     fc4:      	fmaxnm.4s	v19, v19, v25
     fc8:      	fmaxnm.4s	v20, v20, v21
     fcc:      	mov	x12, #-0x300            ; =-768
     fd0:      	b	0x11b8 <_llm_rows.packet_batch.blocks+0xa68>
     fd4:      	cmeq.8b	v21, v21, #0
     fd8:      	sshll.8h	v22, v21, #0x0
     fdc:      	sshll2.4s	v21, v22, #0x0
     fe0:      	sshll.4s	v22, v22, #0x0
     fe4:      	ldp	q24, q23, [x11]
     fe8:      	fsub.4s	v24, v24, v19
     fec:      	fsub.4s	v23, v23, v20
     ff0:      	and.16b	v23, v0, v23
     ff4:      	and.16b	v24, v1, v24
     ff8:      	dup.4s	v25, w16
     ffc:      	fcmge.4s	v27, v24, v25
    1000:      	fcmge.4s	v28, v23, v25
    1004:      	dup.4s	v26, w17
    1008:      	fcmge.4s	v29, v26, v24
    100c:      	fcmge.4s	v30, v26, v23
    1010:      	and.16b	v28, v28, v30
    1014:      	and.16b	v27, v27, v29
    1018:      	and.16b	v27, v27, v24
    101c:      	and.16b	v28, v28, v23
    1020:      	dup.4s	v29, w0
    1024:      	fmul.4s	v30, v28, v29
    1028:      	fmul.4s	v29, v27, v29
    102c:      	mvni.4s	v10, #0x80, lsl #24
    1030:      	mov.16b	v31, v10
    1034:      	bsl.16b	v31, v15, v29
    1038:      	bsl.16b	v10, v15, v30
    103c:      	fadd.4s	v30, v30, v10
    1040:      	fadd.4s	v29, v29, v31
    1044:      	fsub.4s	v29, v29, v31
    1048:      	fsub.4s	v30, v30, v10
    104c:      	fcvtzs.4s	v30, v30
    1050:      	fcvtzs.4s	v29, v29
    1054:      	scvtf.4s	v31, v29
    1058:      	scvtf.4s	v10, v30
    105c:      	dup.4s	v11, w1
    1060:      	fmul.4s	v12, v10, v11
    1064:      	fmul.4s	v11, v31, v11
    1068:      	fadd.4s	v27, v27, v11
    106c:      	fadd.4s	v28, v28, v12
    1070:      	dup.4s	v11, w2
    1074:      	fmul.4s	v31, v31, v11
    1078:      	fmul.4s	v10, v10, v11
    107c:      	fadd.4s	v28, v28, v10
    1080:      	fadd.4s	v27, v27, v31
    1084:      	dup.4s	v31, w3
    1088:      	fmul.4s	v10, v27, v31
    108c:      	fmul.4s	v31, v28, v31
    1090:      	dup.4s	v11, w4
    1094:      	fadd.4s	v31, v31, v11
    1098:      	fadd.4s	v10, v10, v11
    109c:      	fmul.4s	v10, v27, v10
    10a0:      	fmul.4s	v31, v28, v31
    10a4:      	dup.4s	v11, w6
    10a8:      	fadd.4s	v31, v31, v11
    10ac:      	fadd.4s	v10, v10, v11
    10b0:      	fmul.4s	v10, v27, v10
    10b4:      	fmul.4s	v31, v28, v31
    10b8:      	dup.4s	v11, w7
    10bc:      	fadd.4s	v31, v31, v11
    10c0:      	fadd.4s	v10, v10, v11
    10c4:      	fmul.4s	v10, v27, v10
    10c8:      	fmul.4s	v31, v28, v31
    10cc:      	dup.4s	v11, w28
    10d0:      	fadd.4s	v31, v31, v11
    10d4:      	fadd.4s	v10, v10, v11
    10d8:      	fmul.4s	v10, v27, v10
    10dc:      	fmul.4s	v31, v28, v31
    10e0:      	movi.4s	v11, #0x3f, lsl #24
    10e4:      	fadd.4s	v31, v31, v11
    10e8:      	fadd.4s	v10, v10, v11
    10ec:      	fmul.4s	v11, v28, v28
    10f0:      	fmul.4s	v12, v27, v27
    10f4:      	fmul.4s	v10, v12, v10
    10f8:      	fmul.4s	v31, v11, v31
    10fc:      	fadd.4s	v28, v28, v31
    1100:      	fadd.4s	v27, v27, v10
    1104:      	fmov.4s	v31, #1.00000000
    1108:      	fadd.4s	v27, v27, v31
    110c:      	fadd.4s	v28, v28, v31
    1110:      	sshr.4s	v10, v29, #0x1
    1114:      	sshr.4s	v11, v30, #0x1
    1118:      	shl.4s	v12, v11, #0x17
    111c:      	shl.4s	v13, v10, #0x17
    1120:      	add.4s	v13, v13, v31
    1124:      	add.4s	v12, v12, v31
    1128:      	fmul.4s	v28, v28, v12
    112c:      	fmul.4s	v27, v27, v13
    1130:      	sub.4s	v30, v30, v11
    1134:      	sub.4s	v29, v29, v10
    1138:      	shl.4s	v29, v29, #0x17
    113c:      	shl.4s	v30, v30, #0x17
    1140:      	add.4s	v30, v30, v31
    1144:      	add.4s	v29, v29, v31
    1148:      	fmul.4s	v27, v27, v29
    114c:      	fmul.4s	v28, v28, v30
    1150:      	fcmgt.4s	v29, v25, v23
    1154:      	bic.16b	v28, v28, v29
    1158:      	fcmgt.4s	v25, v25, v24
    115c:      	bic.16b	v25, v27, v25
    1160:      	fcmgt.4s	v27, v23, v26
    1164:      	fcmgt.4s	v26, v24, v26
    1168:      	fneg.4s	v29, v14
    116c:      	bit.16b	v25, v29, v26
    1170:      	mov.16b	v26, v27
    1174:      	bsl.16b	v26, v29, v28
    1178:      	fcmeq.4s	v24, v24, v24
    117c:      	fcmeq.4s	v23, v23, v23
    1180:      	ldr	q27, [sp, #0x60]
    1184:      	bsl.16b	v23, v26, v27
    1188:      	bsl.16b	v24, v25, v27
    118c:      	bic.16b	v22, v24, v22
    1190:      	bic.16b	v21, v23, v21
    1194:      	ldr	q23, [x11, #0x6000]
    1198:      	ldr	q24, [x11, #0x6010]
    119c:      	bif.16b	v21, v24, v0
    11a0:      	bif.16b	v22, v23, v1
    11a4:      	str	q22, [x11, #0x6000]
    11a8:      	str	q21, [x11, #0x6010]
    11ac:      	add	x11, x11, #0x20
    11b0:      	adds	x12, x12, #0x1
    11b4:      	b.hs	0x126c <_llm_rows.packet_batch.blocks+0xb1c>
    11b8:      	fmov	w13, s6
    11bc:      	add	x14, x12, #0x300
    11c0:      	dup.2d	v22, x14
    11c4:      	add.2d	v23, v7, v22
    11c8:      	tbz	w13, #0x0, 0x11e0 <_llm_rows.packet_batch.blocks+0xa90>
    11cc:      	fmov	x14, d23
    11d0:      	ldr	b21, [x14]
    11d4:      	and	w13, w13, #0xff
    11d8:      	tbnz	w13, #0x1, 0x11ec <_llm_rows.packet_batch.blocks+0xa9c>
    11dc:      	b	0x11f4 <_llm_rows.packet_batch.blocks+0xaa4>
    11e0:      	movi.2d	v21, #0000000000000000
    11e4:      	and	w13, w13, #0xff
    11e8:      	tbz	w13, #0x1, 0x11f4 <_llm_rows.packet_batch.blocks+0xaa4>
    11ec:      	mov.d	x14, v23[1]
    11f0:      	ld1.b	{ v21 }[1], [x14]
    11f4:      	add.2d	v23, v16, v22
    11f8:      	tbnz	w13, #0x2, 0x121c <_llm_rows.packet_batch.blocks+0xacc>
    11fc:      	tbnz	w13, #0x3, 0x1228 <_llm_rows.packet_batch.blocks+0xad8>
    1200:      	add.2d	v23, v17, v22
    1204:      	tbnz	w13, #0x4, 0x1238 <_llm_rows.packet_batch.blocks+0xae8>
    1208:      	tbnz	w13, #0x5, 0x1244 <_llm_rows.packet_batch.blocks+0xaf4>
    120c:      	add.2d	v22, v18, v22
    1210:      	tbnz	w13, #0x6, 0x1254 <_llm_rows.packet_batch.blocks+0xb04>
    1214:      	tbz	w13, #0x7, 0xfd4 <_llm_rows.packet_batch.blocks+0x884>
    1218:      	b	0x1260 <_llm_rows.packet_batch.blocks+0xb10>
    121c:      	fmov	x14, d23
    1220:      	ld1.b	{ v21 }[2], [x14]
    1224:      	tbz	w13, #0x3, 0x1200 <_llm_rows.packet_batch.blocks+0xab0>
    1228:      	mov.d	x14, v23[1]
    122c:      	ld1.b	{ v21 }[3], [x14]
    1230:      	add.2d	v23, v17, v22
    1234:      	tbz	w13, #0x4, 0x1208 <_llm_rows.packet_batch.blocks+0xab8>
    1238:      	fmov	x14, d23
    123c:      	ld1.b	{ v21 }[4], [x14]
    1240:      	tbz	w13, #0x5, 0x120c <_llm_rows.packet_batch.blocks+0xabc>
    1244:      	mov.d	x14, v23[1]
    1248:      	ld1.b	{ v21 }[5], [x14]
    124c:      	add.2d	v22, v18, v22
    1250:      	tbz	w13, #0x6, 0x1214 <_llm_rows.packet_batch.blocks+0xac4>
    1254:      	fmov	x14, d22
    1258:      	ld1.b	{ v21 }[6], [x14]
    125c:      	tbz	w13, #0x7, 0xfd4 <_llm_rows.packet_batch.blocks+0x884>
    1260:      	mov.d	x13, v22[1]
    1264:      	ld1.b	{ v21 }[7], [x13]
    1268:      	b	0xfd4 <_llm_rows.packet_batch.blocks+0x884>
    126c:      	mov	w11, #0x9800            ; =38912
    1270:      	movk	w11, #0x1, lsl #16
    1274:      	add	x11, x10, x11
    1278:      	ldp	q16, q7, [x11]
    127c:      	mov	w11, #0x9820            ; =38944
    1280:      	movk	w11, #0x1, lsl #16
    1284:      	add	x11, x10, x11
    1288:      	ldp	q18, q19, [x11]
    128c:      	mov	w11, #0x9840            ; =38976
    1290:      	movk	w11, #0x1, lsl #16
    1294:      	add	x11, x10, x11
    1298:      	ldp	q20, q21, [x11]
    129c:      	mov	w11, #0x9860            ; =39008
    12a0:      	movk	w11, #0x1, lsl #16
    12a4:      	add	x11, x10, x11
    12a8:      	and.16b	v7, v0, v7
    12ac:      	and.16b	v17, v1, v16
    12b0:      	ldp	q22, q23, [x11]
    12b4:      	and.16b	v19, v0, v19
    12b8:      	and.16b	v18, v1, v18
    12bc:      	and.16b	v16, v0, v21
    12c0:      	and.16b	v20, v1, v20
    12c4:      	and.16b	v21, v0, v23
    12c8:      	and.16b	v22, v1, v22
    12cc:      	mov	w11, #0x98e0            ; =39136
    12d0:      	movk	w11, #0x1, lsl #16
    12d4:      	add	x10, x10, x11
    12d8:      	mov	w11, #0xcc4             ; =3268
    12dc:      	ldp	q24, q23, [x10, #-0x60]
    12e0:      	fadd.4s	v25, v17, v24
    12e4:      	fadd.4s	v26, v7, v23
    12e8:      	ldp	q24, q23, [x10, #-0x40]
    12ec:      	fadd.4s	v27, v18, v24
    12f0:      	fadd.4s	v28, v19, v23
    12f4:      	ldp	q24, q23, [x10, #-0x20]
    12f8:      	fadd.4s	v29, v20, v24
    12fc:      	fadd.4s	v30, v16, v23
    1300:      	ldp	q23, q24, [x10], #0x80
    1304:      	fadd.4s	v23, v22, v23
    1308:      	fadd.4s	v24, v21, v24
    130c:      	bit.16b	v7, v26, v0
    1310:      	bit.16b	v17, v25, v1
    1314:      	bit.16b	v19, v28, v0
    1318:      	bit.16b	v18, v27, v1
    131c:      	bit.16b	v16, v30, v0
    1320:      	bit.16b	v20, v29, v1
    1324:      	bit.16b	v21, v24, v0
    1328:      	bit.16b	v22, v23, v1
    132c:      	sub	x12, x11, #0xcc0
    1330:      	add	x11, x11, #0x4
    1334:      	cmp	x12, #0x2fc
    1338:      	b.lo	0x12dc <_llm_rows.packet_batch.blocks+0xb8c>
    133c:      	mov	x10, #0x0               ; =0
    1340:      	movi.2d	v21, #0000000000000000
    1344:      	fadd.4s	v17, v17, v21
    1348:      	fadd.4s	v7, v7, v21
    134c:      	fadd.4s	v7, v7, v19
    1350:      	fadd.4s	v17, v17, v18
    1354:      	fadd.4s	v17, v17, v20
    1358:      	fadd.4s	v7, v7, v16
    135c:      	fadd.4s	v16, v24, v7
    1360:      	fadd.4s	v7, v23, v17
    1364:      	and.16b	v7, v1, v7
    1368:      	and.16b	v16, v0, v16
    136c:      	b	0x137c <_llm_rows.packet_batch.blocks+0xc2c>
    1370:      	add	x10, x10, #0x1
    1374:      	cmp	x10, #0x300
    1378:      	b.eq	0x7f8 <_llm_rows.packet_batch.blocks+0xa8>
    137c:      	fmov	w11, s6
    1380:      	dup.2d	v17, x10
    1384:      	add.2d	v18, v17, v5
    1388:      	add	x12, x8, x10, lsl #5
    138c:      	ldp	q20, q19, [x12]
    1390:      	and.16b	v20, v1, v20
    1394:      	fdiv.4s	v20, v20, v7
    1398:      	shl.2d	v21, v18, #0x2
    139c:      	dup.2d	v18, x9
    13a0:      	add.2d	v21, v18, v21
    13a4:      	tbnz	w11, #0x0, 0x13f8 <_llm_rows.packet_batch.blocks+0xca8>
    13a8:      	and	w11, w11, #0xff
    13ac:      	tbnz	w11, #0x1, 0x1408 <_llm_rows.packet_batch.blocks+0xcb8>
    13b0:      	add.2d	v21, v17, v3
    13b4:      	shl.2d	v21, v21, #0x2
    13b8:      	add.2d	v21, v18, v21
    13bc:      	tbnz	w11, #0x2, 0x1420 <_llm_rows.packet_batch.blocks+0xcd0>
    13c0:      	tbnz	w11, #0x3, 0x142c <_llm_rows.packet_batch.blocks+0xcdc>
    13c4:      	add.2d	v20, v17, v4
    13c8:      	and.16b	v19, v0, v19
    13cc:      	fdiv.4s	v19, v19, v16
    13d0:      	shl.2d	v20, v20, #0x2
    13d4:      	add.2d	v20, v18, v20
    13d8:      	tbnz	w11, #0x4, 0x144c <_llm_rows.packet_batch.blocks+0xcfc>
    13dc:      	tbnz	w11, #0x5, 0x1458 <_llm_rows.packet_batch.blocks+0xd08>
    13e0:      	add.2d	v17, v17, v2
    13e4:      	shl.2d	v17, v17, #0x2
    13e8:      	add.2d	v17, v18, v17
    13ec:      	tbnz	w11, #0x6, 0x1470 <_llm_rows.packet_batch.blocks+0xd20>
    13f0:      	tbz	w11, #0x7, 0x1370 <_llm_rows.packet_batch.blocks+0xc20>
    13f4:      	b	0x147c <_llm_rows.packet_batch.blocks+0xd2c>
    13f8:      	fmov	x12, d21
    13fc:      	str	s20, [x12]
    1400:      	and	w11, w11, #0xff
    1404:      	tbz	w11, #0x1, 0x13b0 <_llm_rows.packet_batch.blocks+0xc60>
    1408:      	mov.d	x12, v21[1]
    140c:      	st1.s	{ v20 }[1], [x12]
    1410:      	add.2d	v21, v17, v3
    1414:      	shl.2d	v21, v21, #0x2
    1418:      	add.2d	v21, v18, v21
    141c:      	tbz	w11, #0x2, 0x13c0 <_llm_rows.packet_batch.blocks+0xc70>
    1420:      	fmov	x12, d21
    1424:      	st1.s	{ v20 }[2], [x12]
    1428:      	tbz	w11, #0x3, 0x13c4 <_llm_rows.packet_batch.blocks+0xc74>
    142c:      	mov.d	x12, v21[1]
    1430:      	st1.s	{ v20 }[3], [x12]
    1434:      	add.2d	v20, v17, v4
    1438:      	and.16b	v19, v0, v19
    143c:      	fdiv.4s	v19, v19, v16
    1440:      	shl.2d	v20, v20, #0x2
    1444:      	add.2d	v20, v18, v20
    1448:      	tbz	w11, #0x4, 0x13dc <_llm_rows.packet_batch.blocks+0xc8c>
    144c:      	fmov	x12, d20
    1450:      	str	s19, [x12]
    1454:      	tbz	w11, #0x5, 0x13e0 <_llm_rows.packet_batch.blocks+0xc90>
    1458:      	mov.d	x12, v20[1]
    145c:      	st1.s	{ v19 }[1], [x12]
    1460:      	add.2d	v17, v17, v2
    1464:      	shl.2d	v17, v17, #0x2
    1468:      	add.2d	v17, v18, v17
    146c:      	tbz	w11, #0x6, 0x13f0 <_llm_rows.packet_batch.blocks+0xca0>
    1470:      	fmov	x12, d17
    1474:      	st1.s	{ v19 }[2], [x12]
    1478:      	tbz	w11, #0x7, 0x1370 <_llm_rows.packet_batch.blocks+0xc20>
    147c:      	mov.d	x11, v17[1]
    1480:      	st1.s	{ v19 }[3], [x11]
    1484:      	b	0x1370 <_llm_rows.packet_batch.blocks+0xc20>
    1488:      	ldp	x29, x30, [sp, #0x110]
    148c:      	ldp	x20, x19, [sp, #0x100]
    1490:      	ldp	x22, x21, [sp, #0xf0]
    1494:      	ldp	x24, x23, [sp, #0xe0]
    1498:      	ldp	x26, x25, [sp, #0xd0]
    149c:      	ldp	x28, x27, [sp, #0xc0]
    14a0:      	ldp	d9, d8, [sp, #0xb0]
    14a4:      	ldp	d11, d10, [sp, #0xa0]
    14a8:      	ldp	d13, d12, [sp, #0x90]
    14ac:      	ldp	d15, d14, [sp, #0x80]
    14b0:      	add	sp, sp, #0x120
    14b4:      	ret

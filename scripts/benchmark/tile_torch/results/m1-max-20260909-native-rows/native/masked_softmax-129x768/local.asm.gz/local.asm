
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/masked_softmax-129x768-l8/object/tile_xir_w8_80759_1788919112754326_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x70]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      20:      	sub	sp, sp, #0xf00
      24:      	ldr	x8, [x0]
      28:      	ldr	x19, [x0, #0x30]
      2c:      	ldr	w9, [x1]
      30:      	ldr	w10, [x1, #0x24]
      34:      	add	w9, w10, w9, lsl #5
      38:      	lsr	w21, w9, #3
      3c:      	mov	w9, #0xc00              ; =3072
      40:      	umull	x20, w21, w9
      44:      	umaddl	x1, w21, w9, x8
      48:      	add	x0, sp, #0x3, lsl #12   ; =0x3000
      4c:      	add	x0, x0, #0x300
      50:      	mov	w2, #0xc00              ; =3072
      54:      	bl	0x54 <ltmp0+0x54>
      58:      	mov	x8, #0x0                ; =0
      5c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
      60:      	add	x9, x9, #0xb00
      64:      	adrp	x10, 0x0 <ltmp0>
      68:      	ldr	q0, [x10]
      6c:      	adrp	x10, 0x0 <ltmp0>
      70:      	ldr	q1, [x10]
      74:      	adrp	x10, 0x0 <ltmp0>
      78:      	ldr	q2, [x10]
      7c:      	adrp	x10, 0x0 <ltmp0>
      80:      	ldr	q3, [x10]
      84:      	dup.2d	v4, x8
      88:      	orr.16b	v5, v4, v0
      8c:      	orr.16b	v6, v4, v1
      90:      	orr.16b	v7, v4, v2
      94:      	orr.16b	v4, v4, v3
      98:      	stp	q7, q4, [x9, #0x20]
      9c:      	stp	q5, q6, [x9], #0x40
      a0:      	add	x8, x8, #0x8
      a4:      	cmp	x8, #0x300
      a8:      	b.ne	0x84 <ltmp0+0x84>
      ac:      	mov	x8, #0x0                ; =0
      b0:      	mov	w9, #0xaaab             ; =43691
      b4:      	movk	w9, #0xaaa, lsl #16
      b8:      	umull	x9, w21, w9
      bc:      	lsr	x9, x9, #37
      c0:      	mov	w10, #0x300             ; =768
      c4:      	msub	w9, w9, w10, w21
      c8:      	dup.2s	v0, w9
      cc:      	ushll.2d	v4, v0, #0x0
      d0:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
      d4:      	add	x9, x9, #0xb00
      d8:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
      dc:      	add	x10, x10, #0x800
      e0:      	dup.2d	v5, x10
      e4:      	adrp	x10, 0x0 <ltmp0>
      e8:      	ldr	q0, [x10]
      ec:      	adrp	x10, 0x0 <ltmp0>
      f0:      	ldr	q1, [x10]
      f4:      	adrp	x10, 0x0 <ltmp0>
      f8:      	ldr	q2, [x10]
      fc:      	adrp	x10, 0x0 <ltmp0>
     100:      	ldr	q3, [x10]
     104:      	movi.8b	v6, #0x1
     108:      	dup.2d	v7, x8
     10c:      	add	x10, x9, x8, lsl #6
     110:      	ldp	q17, q16, [x10, #0x20]
     114:      	ldp	q18, q19, [x10]
     118:      	add.2d	v7, v7, v5
     11c:      	add.2d	v20, v7, v1
     120:      	add.2d	v21, v7, v0
     124:      	cmge.2d	v19, v4, v19
     128:      	cmge.2d	v18, v4, v18
     12c:      	uzp1.4s	v18, v18, v19
     130:      	cmge.2d	v17, v4, v17
     134:      	cmge.2d	v16, v4, v16
     138:      	uzp1.4s	v16, v17, v16
     13c:      	uzp1.8h	v16, v18, v16
     140:      	xtn.8b	v16, v16
     144:      	and.8b	v16, v16, v6
     148:      	mov.d	x10, v21[1]
     14c:      	fmov	x11, d21
     150:      	str	b16, [x11]
     154:      	st1.b	{ v16 }[1], [x10]
     158:      	mov.d	x10, v20[1]
     15c:      	fmov	x11, d20
     160:      	st1.b	{ v16 }[2], [x11]
     164:      	st1.b	{ v16 }[3], [x10]
     168:      	add.2d	v17, v7, v2
     16c:      	mov.d	x10, v17[1]
     170:      	fmov	x11, d17
     174:      	st1.b	{ v16 }[4], [x11]
     178:      	add.2d	v7, v7, v3
     17c:      	st1.b	{ v16 }[5], [x10]
     180:      	mov.d	x10, v7[1]
     184:      	fmov	x11, d7
     188:      	st1.b	{ v16 }[6], [x11]
     18c:      	st1.b	{ v16 }[7], [x10]
     190:      	add	x8, x8, #0x1
     194:      	cmp	x8, #0x60
     198:      	b.ne	0x108 <ltmp0+0x108>
     19c:      	mov	x8, #0x0                ; =0
     1a0:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     1a4:      	add	x9, x9, #0x800
     1a8:      	dup.2d	v4, x9
     1ac:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     1b0:      	add	x9, x9, #0x300
     1b4:      	mov	w10, #0xf2ca            ; =62154
     1b8:      	movk	w10, #0xf149, lsl #16
     1bc:      	dup.4s	v5, w10
     1c0:      	add	x10, sp, #0xc00
     1c4:      	dup.2d	v6, x8
     1c8:      	add.2d	v6, v6, v4
     1cc:      	add.2d	v7, v6, v3
     1d0:      	add.2d	v16, v6, v0
     1d4:      	mov.d	x11, v16[1]
     1d8:      	add.2d	v17, v6, v2
     1dc:      	add.2d	v6, v6, v1
     1e0:      	fmov	x12, d16
     1e4:      	mov.d	x13, v6[1]
     1e8:      	mov.d	x14, v17[1]
     1ec:      	fmov	x15, d6
     1f0:      	ldr	b6, [x12]
     1f4:      	ld1.b	{ v6 }[1], [x11]
     1f8:      	mov.d	x11, v7[1]
     1fc:      	fmov	x12, d17
     200:      	ld1.b	{ v6 }[2], [x15]
     204:      	ld1.b	{ v6 }[3], [x13]
     208:      	fmov	x13, d7
     20c:      	ld1.b	{ v6 }[4], [x12]
     210:      	ld1.b	{ v6 }[5], [x14]
     214:      	ld1.b	{ v6 }[6], [x13]
     218:      	ld1.b	{ v6 }[7], [x11]
     21c:      	cmeq.8b	v6, v6, #0
     220:      	sshll.8h	v6, v6, #0x0
     224:      	sshll2.4s	v7, v6, #0x0
     228:      	sshll.4s	v6, v6, #0x0
     22c:      	lsl	x11, x8, #5
     230:      	add	x12, x9, x11
     234:      	ldp	q17, q16, [x12]
     238:      	bsl.16b	v6, v5, v17
     23c:      	bsl.16b	v7, v5, v16
     240:      	add	x11, x10, x11
     244:      	stp	q6, q7, [x11]
     248:      	add	x8, x8, #0x1
     24c:      	cmp	x8, #0x60
     250:      	b.ne	0x1c4 <ltmp0+0x1c4>
     254:      	ldr	q4, [sp, #0xc10]
     258:      	ldr	q6, [sp, #0xc00]
     25c:      	ldr	q5, [sp, #0xc30]
     260:      	ldr	q17, [sp, #0xc20]
     264:      	ldr	q16, [sp, #0xc50]
     268:      	ldr	q7, [sp, #0xc40]
     26c:      	add	x8, sp, #0xc00
     270:      	add	x8, x8, #0xe0
     274:      	mov	w9, #0x4                ; =4
     278:      	ldr	q18, [sp, #0xc70]
     27c:      	ldr	q19, [sp, #0xc60]
     280:      	ldp	q20, q21, [x8, #-0x60]
     284:      	fmaxnm.4s	v4, v4, v21
     288:      	fmaxnm.4s	v6, v6, v20
     28c:      	ldp	q20, q21, [x8, #-0x40]
     290:      	fmaxnm.4s	v5, v5, v21
     294:      	fmaxnm.4s	v17, v17, v20
     298:      	ldp	q20, q21, [x8, #-0x20]
     29c:      	fmaxnm.4s	v16, v16, v21
     2a0:      	fmaxnm.4s	v7, v7, v20
     2a4:      	ldp	q20, q21, [x8], #0x80
     2a8:      	fmaxnm.4s	v18, v18, v21
     2ac:      	fmaxnm.4s	v19, v19, v20
     2b0:      	cmp	x9, #0x5c
     2b4:      	add	x9, x9, #0x4
     2b8:      	b.lo	0x280 <ltmp0+0x280>
     2bc:      	mov	x8, #0x0                ; =0
     2c0:      	fmaxnm.4s	v6, v6, v17
     2c4:      	fmaxnm.4s	v4, v4, v5
     2c8:      	fmaxnm.4s	v4, v4, v16
     2cc:      	fmaxnm.4s	v5, v6, v7
     2d0:      	fmaxnm.4s	v5, v5, v19
     2d4:      	fmaxnm.4s	v4, v4, v18
     2d8:      	rev64.4s	v6, v4
     2dc:      	rev64.4s	v7, v5
     2e0:      	fmaxnm.4s	v5, v5, v7
     2e4:      	fmaxnm.4s	v4, v4, v6
     2e8:      	ext.16b	v6, v4, v4, #0x8
     2ec:      	ext.16b	v7, v5, v5, #0x8
     2f0:      	fmaxnm.4s	v5, v5, v7
     2f4:      	fmaxnm.4s	v4, v4, v6
     2f8:      	fmaxnm.4s	v4, v5, v4
     2fc:      	mov	w9, #-0x800000          ; =-8388608
     300:      	fmov	s5, w9
     304:      	fmaxnm	s4, s4, s5
     308:      	dup.4s	v4, v4[0]
     30c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     310:      	add	x9, x9, #0x800
     314:      	dup.2d	v5, x9
     318:      	mov	w9, #-0x3d300000        ; =-1026555904
     31c:      	dup.4s	v6, w9
     320:      	mov	w9, #0x42c80000         ; =1120403456
     324:      	dup.4s	v7, w9
     328:      	mov	w9, #0xaa3b             ; =43579
     32c:      	movk	w9, #0x3fb8, lsl #16
     330:      	dup.4s	v16, w9
     334:      	add	x9, sp, #0xc00
     338:      	movi.4s	v17, #0x4b, lsl #24
     33c:      	mvni.4s	v18, #0x80, lsl #24
     340:      	mov	w10, #0x7200            ; =29184
     344:      	movk	w10, #0xbf31, lsl #16
     348:      	dup.4s	v19, w10
     34c:      	mov	w10, #0xbe8e            ; =48782
     350:      	movk	w10, #0xb5bf, lsl #16
     354:      	dup.4s	v20, w10
     358:      	mov	w10, #0x2bda            ; =11226
     35c:      	movk	w10, #0x3950, lsl #16
     360:      	dup.4s	v21, w10
     364:      	mov	w10, #0x96c9            ; =38601
     368:      	movk	w10, #0x3ab6, lsl #16
     36c:      	dup.4s	v22, w10
     370:      	mov	w10, #0x88a6            ; =34982
     374:      	movk	w10, #0x3c08, lsl #16
     378:      	dup.4s	v23, w10
     37c:      	mov	w10, #0xaa7a            ; =43642
     380:      	movk	w10, #0x3d2a, lsl #16
     384:      	dup.4s	v24, w10
     388:      	mov	w10, #0xaaab            ; =43691
     38c:      	movk	w10, #0x3e2a, lsl #16
     390:      	dup.4s	v25, w10
     394:      	movi.4s	v26, #0x3f, lsl #24
     398:      	mvni.4s	v27, #0x7f, msl #16
     39c:      	fneg.4s	v27, v27
     3a0:      	mvni.4s	v28, #0x3f, msl #16
     3a4:      	fneg.4s	v28, v28
     3a8:      	mov	x10, sp
     3ac:      	dup.2d	v29, x8
     3b0:      	add.2d	v29, v29, v5
     3b4:      	add.2d	v31, v29, v3
     3b8:      	add.2d	v30, v29, v2
     3bc:      	add.2d	v8, v29, v1
     3c0:      	add.2d	v29, v29, v0
     3c4:      	mov.d	x13, v29[1]
     3c8:      	fmov	x15, d29
     3cc:      	mov.d	x14, v8[1]
     3d0:      	fmov	x16, d8
     3d4:      	mov.d	x11, v30[1]
     3d8:      	fmov	x12, d30
     3dc:      	lsl	x17, x8, #5
     3e0:      	add	x0, x9, x17
     3e4:      	ldp	q29, q30, [x0]
     3e8:      	mov.d	x0, v31[1]
     3ec:      	fsub.4s	v30, v30, v4
     3f0:      	fsub.4s	v29, v29, v4
     3f4:      	fcmge.4s	v8, v29, v6
     3f8:      	fcmge.4s	v9, v30, v6
     3fc:      	fcmge.4s	v10, v7, v29
     400:      	fmov	x1, d31
     404:      	fcmge.4s	v31, v7, v30
     408:      	and.16b	v31, v9, v31
     40c:      	and.16b	v8, v8, v10
     410:      	and.16b	v8, v8, v29
     414:      	and.16b	v31, v31, v30
     418:      	fmul.4s	v9, v31, v16
     41c:      	fmul.4s	v10, v8, v16
     420:      	mov.16b	v11, v18
     424:      	bsl.16b	v11, v17, v10
     428:      	mov.16b	v12, v18
     42c:      	bsl.16b	v12, v17, v9
     430:      	fadd.4s	v9, v9, v12
     434:      	fadd.4s	v10, v10, v11
     438:      	fsub.4s	v10, v10, v11
     43c:      	fsub.4s	v9, v9, v12
     440:      	fcvtzs.4s	v9, v9
     444:      	fcvtzs.4s	v10, v10
     448:      	scvtf.4s	v11, v10
     44c:      	scvtf.4s	v12, v9
     450:      	fmul.4s	v13, v12, v19
     454:      	fmul.4s	v14, v11, v19
     458:      	fadd.4s	v8, v8, v14
     45c:      	fadd.4s	v31, v31, v13
     460:      	fmul.4s	v11, v11, v20
     464:      	fmul.4s	v12, v12, v20
     468:      	fadd.4s	v31, v31, v12
     46c:      	fadd.4s	v8, v8, v11
     470:      	fmul.4s	v11, v8, v21
     474:      	fmul.4s	v12, v31, v21
     478:      	fadd.4s	v12, v12, v22
     47c:      	fadd.4s	v11, v11, v22
     480:      	fmul.4s	v11, v8, v11
     484:      	fmul.4s	v12, v31, v12
     488:      	fadd.4s	v12, v12, v23
     48c:      	fadd.4s	v11, v11, v23
     490:      	fmul.4s	v11, v8, v11
     494:      	fmul.4s	v12, v31, v12
     498:      	fadd.4s	v12, v12, v24
     49c:      	fadd.4s	v11, v11, v24
     4a0:      	fmul.4s	v11, v8, v11
     4a4:      	fmul.4s	v12, v31, v12
     4a8:      	fadd.4s	v12, v12, v25
     4ac:      	fadd.4s	v11, v11, v25
     4b0:      	fmul.4s	v11, v8, v11
     4b4:      	fmul.4s	v12, v31, v12
     4b8:      	fadd.4s	v12, v12, v26
     4bc:      	fadd.4s	v11, v11, v26
     4c0:      	fmul.4s	v13, v31, v31
     4c4:      	fmul.4s	v14, v8, v8
     4c8:      	fmul.4s	v11, v14, v11
     4cc:      	fmul.4s	v12, v13, v12
     4d0:      	fadd.4s	v31, v31, v12
     4d4:      	fadd.4s	v8, v8, v11
     4d8:      	fmov.4s	v11, #1.00000000
     4dc:      	sshr.4s	v12, v10, #0x1
     4e0:      	fadd.4s	v31, v31, v11
     4e4:      	sshr.4s	v13, v9, #0x1
     4e8:      	shl.4s	v14, v13, #0x17
     4ec:      	add.4s	v14, v14, v11
     4f0:      	fmul.4s	v31, v31, v14
     4f4:      	shl.4s	v14, v12, #0x17
     4f8:      	fadd.4s	v8, v8, v11
     4fc:      	add.4s	v14, v14, v11
     500:      	fmul.4s	v8, v8, v14
     504:      	sub.4s	v9, v9, v13
     508:      	sub.4s	v10, v10, v12
     50c:      	shl.4s	v10, v10, #0x17
     510:      	shl.4s	v9, v9, #0x17
     514:      	add.4s	v9, v9, v11
     518:      	add.4s	v10, v10, v11
     51c:      	fmul.4s	v8, v8, v10
     520:      	ldr	b10, [x15]
     524:      	ld1.b	{ v10 }[1], [x13]
     528:      	ld1.b	{ v10 }[2], [x16]
     52c:      	ld1.b	{ v10 }[3], [x14]
     530:      	fmul.4s	v31, v31, v9
     534:      	fcmgt.4s	v9, v6, v30
     538:      	bic.16b	v31, v31, v9
     53c:      	fcmgt.4s	v9, v6, v29
     540:      	bic.16b	v8, v8, v9
     544:      	fcmgt.4s	v9, v29, v7
     548:      	bit.16b	v8, v27, v9
     54c:      	fcmgt.4s	v9, v30, v7
     550:      	bit.16b	v31, v27, v9
     554:      	ld1.b	{ v10 }[4], [x12]
     558:      	ld1.b	{ v10 }[5], [x11]
     55c:      	fcmeq.4s	v30, v30, v30
     560:      	bsl.16b	v30, v31, v28
     564:      	ld1.b	{ v10 }[6], [x1]
     568:      	ld1.b	{ v10 }[7], [x0]
     56c:      	cmeq.8b	v31, v10, #0
     570:      	sshll.8h	v31, v31, #0x0
     574:      	fcmeq.4s	v29, v29, v29
     578:      	bsl.16b	v29, v8, v28
     57c:      	sshll.4s	v8, v31, #0x0
     580:      	bic.16b	v29, v29, v8
     584:      	sshll2.4s	v31, v31, #0x0
     588:      	bic.16b	v30, v30, v31
     58c:      	add	x11, x10, x17
     590:      	stp	q29, q30, [x11]
     594:      	add	x8, x8, #0x1
     598:      	cmp	x8, #0x60
     59c:      	b.ne	0x3ac <ltmp0+0x3ac>
     5a0:      	ldp	q2, q0, [sp]
     5a4:      	ldp	q5, q1, [sp, #0x20]
     5a8:      	ldp	q3, q4, [sp, #0x40]
     5ac:      	mov	x8, sp
     5b0:      	add	x8, x8, #0xe0
     5b4:      	mov	w9, #0x4                ; =4
     5b8:      	ldp	q7, q6, [sp, #0x60]
     5bc:      	ldp	q16, q17, [x8, #-0x60]
     5c0:      	fadd.4s	v0, v0, v17
     5c4:      	fadd.4s	v2, v2, v16
     5c8:      	ldp	q16, q17, [x8, #-0x40]
     5cc:      	fadd.4s	v1, v1, v17
     5d0:      	fadd.4s	v5, v5, v16
     5d4:      	ldp	q16, q17, [x8, #-0x20]
     5d8:      	fadd.4s	v4, v4, v17
     5dc:      	fadd.4s	v3, v3, v16
     5e0:      	ldp	q16, q17, [x8], #0x80
     5e4:      	fadd.4s	v6, v6, v17
     5e8:      	fadd.4s	v7, v7, v16
     5ec:      	cmp	x9, #0x5c
     5f0:      	add	x9, x9, #0x4
     5f4:      	b.lo	0x5bc <ltmp0+0x5bc>
     5f8:      	mov	x8, #0x0                ; =0
     5fc:      	fadd.4s	v2, v2, v5
     600:      	fadd.4s	v0, v0, v1
     604:      	fadd.4s	v0, v0, v4
     608:      	fadd.4s	v1, v2, v3
     60c:      	fadd.4s	v1, v1, v7
     610:      	fadd.4s	v0, v0, v6
     614:      	rev64.4s	v2, v0
     618:      	rev64.4s	v3, v1
     61c:      	fadd.4s	v0, v0, v2
     620:      	dup.4s	v2, v0[2]
     624:      	fadd.4s	v1, v1, v3
     628:      	dup.4s	v3, v1[2]
     62c:      	fadd.4s	v1, v1, v3
     630:      	fadd.4s	v0, v0, v2
     634:      	fadd.4s	v0, v1, v0
     638:      	movi	d1, #0000000000000000
     63c:      	fadd	s0, s0, s1
     640:      	dup.4s	v0, v0[0]
     644:      	add	x9, x19, x20
     648:      	mov	x10, sp
     64c:      	add	x11, x10, x8
     650:      	ldp	q2, q1, [x11]
     654:      	fdiv.4s	v2, v2, v0
     658:      	fdiv.4s	v1, v1, v0
     65c:      	add	x11, x9, x8
     660:      	stp	q2, q1, [x11]
     664:      	add	x8, x8, #0x20
     668:      	cmp	x8, #0xc00
     66c:      	b.ne	0x64c <ltmp0+0x64c>
     670:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     674:      	add	sp, sp, #0xf00
     678:      	ldp	x29, x30, [sp, #0x60]
     67c:      	ldp	x20, x19, [sp, #0x50]
     680:      	ldp	x22, x21, [sp, #0x40]
     684:      	ldp	d9, d8, [sp, #0x30]
     688:      	ldp	d11, d10, [sp, #0x20]
     68c:      	ldp	d13, d12, [sp, #0x10]
     690:      	ldp	d15, d14, [sp], #0x70
     694:      	ret

0000000000000698 <_llm_rows.packet_batch.blocks>:
     698:      	stp	d15, d14, [sp, #-0xa0]!
     69c:      	stp	d13, d12, [sp, #0x10]
     6a0:      	stp	d11, d10, [sp, #0x20]
     6a4:      	stp	d9, d8, [sp, #0x30]
     6a8:      	stp	x28, x27, [sp, #0x40]
     6ac:      	stp	x26, x25, [sp, #0x50]
     6b0:      	stp	x24, x23, [sp, #0x60]
     6b4:      	stp	x22, x21, [sp, #0x70]
     6b8:      	stp	x20, x19, [sp, #0x80]
     6bc:      	stp	x29, x30, [sp, #0x90]
     6c0:      	sub	sp, sp, #0x4, lsl #12   ; =0x4000
     6c4:      	sub	sp, sp, #0x550
     6c8:      	str	x0, [sp, #0xb8]
     6cc:      	cbz	w3, 0x1b68 <_llm_rows.packet_batch.blocks+0x14d0>
     6d0:      	mov	x21, x3
     6d4:      	mov	x20, x2
     6d8:      	mov	w22, #0x0               ; =0
     6dc:      	add	x23, sp, #0x150
     6e0:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
     6e4:      	add	x8, x8, #0xe50
     6e8:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     6ec:      	add	x9, x9, #0x250
     6f0:      	dup.2d	v0, x8
     6f4:      	str	q0, [sp, #0x30]
     6f8:      	add	x10, x9, #0xe0
     6fc:      	add	x8, sp, #0x650
     700:      	add	x8, x8, #0xe0
     704:      	stp	x8, x10, [sp, #0x20]
     708:      	adrp	x8, 0x0 <ltmp0>
     70c:      	ldr	q0, [x8]
     710:      	str	q0, [sp, #0x10]
     714:      	adrp	x8, 0x0 <ltmp0>
     718:      	ldr	q0, [x8]
     71c:      	str	q0, [sp, #0x70]
     720:      	adrp	x8, 0x0 <ltmp0>
     724:      	ldr	q0, [x8]
     728:      	str	q0, [sp, #0x60]
     72c:      	add	x25, sp, #0x3, lsl #12  ; =0x3000
     730:      	add	x25, x25, #0x950
     734:      	adrp	x27, 0x0 <ltmp0>
     738:      	adrp	x15, 0x0 <ltmp0>
     73c:      	adrp	x16, 0x0 <ltmp0>
     740:      	movi.8b	v8, #0x1
     744:      	movi	d9, #0000000000000000
     748:      	movi.4s	v10, #0x4b, lsl #24
     74c:      	mvni.4s	v11, #0x80, lsl #24
     750:      	movi.4s	v12, #0x3f, lsl #24
     754:      	mvni.4s	v0, #0x7f, msl #16
     758:      	fneg.4s	v13, v0
     75c:      	mvni.4s	v0, #0x3f, msl #16
     760:      	fneg.4s	v14, v0
     764:      	ldp	w9, w8, [x2, #0x2c]
     768:      	stp	w8, w9, [sp, #0xb0]
     76c:      	ldp	w19, w17, [x2]
     770:      	ldp	w28, w8, [x2, #0x8]
     774:      	str	x8, [sp, #0xa8]
     778:      	stp	q14, q13, [sp, #0x80]
     77c:      	str	w3, [sp, #0x5c]
     780:      	b	0x7c8 <_llm_rows.packet_batch.blocks+0x130>
     784:      	mov	w8, #0x18               ; =24
     788:      	str	w8, [x20, #0x24]
     78c:      	ldr	w21, [sp, #0x5c]
     790:      	add	w8, w19, #0x1
     794:      	ldp	w10, w9, [sp, #0xb0]
     798:      	cmp	w8, w9
     79c:      	cset	w8, eq
     7a0:      	csinc	w19, wzr, w19, eq
     7a4:      	cinc	w9, w17, eq
     7a8:      	cmp	w9, w10
     7ac:      	cset	w10, eq
     7b0:      	ands	w8, w8, w10
     7b4:      	csel	w17, wzr, w9, ne
     7b8:      	add	w28, w28, w8
     7bc:      	add	w22, w22, #0x1
     7c0:      	cmp	w22, w21
     7c4:      	b.eq	0x1b68 <_llm_rows.packet_batch.blocks+0x14d0>
     7c8:      	mov	x24, x27
     7cc:      	ubfiz	x8, x19, #5, #32
     7d0:      	ldr	x12, [sp, #0xa8]
     7d4:      	cmp	x8, x12
     7d8:      	csel	x9, x8, xzr, ls
     7dc:      	subs	x10, x12, x9
     7e0:      	cmp	x10, #0x20
     7e4:      	mov	w11, #0x20              ; =32
     7e8:      	csel	x10, x10, x11, lo
     7ec:      	cmp	x12, x9
     7f0:      	stp	w19, w17, [x20]
     7f4:      	str	w28, [x20, #0x8]
     7f8:      	str	wzr, [x20, #0x24]
     7fc:      	ccmp	x8, x12, #0x2, hi
     800:      	csel	x27, x10, xzr, ls
     804:      	cmp	x27, #0x20
     808:      	b.lo	0x880 <_llm_rows.packet_batch.blocks+0x1e8>
     80c:      	ldr	x27, [sp, #0xb8]
     810:      	mov	x0, x27
     814:      	mov	x1, x20
     818:      	mov	x26, x17
     81c:      	bl	0x81c <_llm_rows.packet_batch.blocks+0x184>
     820:      	mov	w8, #0x8                ; =8
     824:      	str	w8, [x20, #0x24]
     828:      	mov	x0, x27
     82c:      	mov	x1, x20
     830:      	bl	0x830 <_llm_rows.packet_batch.blocks+0x198>
     834:      	mov	w8, #0x10               ; =16
     838:      	str	w8, [x20, #0x24]
     83c:      	mov	x0, x27
     840:      	mov	x1, x20
     844:      	bl	0x844 <_llm_rows.packet_batch.blocks+0x1ac>
     848:      	mov	w8, #0x18               ; =24
     84c:      	str	w8, [x20, #0x24]
     850:      	mov	x0, x27
     854:      	mov	x1, x20
     858:      	bl	0x858 <_llm_rows.packet_batch.blocks+0x1c0>
     85c:      	mov	x17, x26
     860:      	ldp	q14, q13, [sp, #0x80]
     864:      	movi.4s	v12, #0x3f, lsl #24
     868:      	mvni.4s	v11, #0x80, lsl #24
     86c:      	movi.4s	v10, #0x4b, lsl #24
     870:      	adrp	x16, 0x0 <ltmp0>
     874:      	adrp	x15, 0x0 <ltmp0>
     878:      	mov	x27, x24
     87c:      	b	0x790 <_llm_rows.packet_batch.blocks+0xf8>
     880:      	lsr	x21, x27, #3
     884:      	cmp	x27, #0x8
     888:      	b.lo	0x92c <_llm_rows.packet_batch.blocks+0x294>
     88c:      	str	wzr, [x20, #0x24]
     890:      	ldr	x0, [sp, #0xb8]
     894:      	mov	x1, x20
     898:      	mov	x26, x17
     89c:      	bl	0x89c <_llm_rows.packet_batch.blocks+0x204>
     8a0:      	mov	x17, x26
     8a4:      	ldp	q14, q13, [sp, #0x80]
     8a8:      	movi.4s	v12, #0x3f, lsl #24
     8ac:      	mvni.4s	v11, #0x80, lsl #24
     8b0:      	movi.4s	v10, #0x4b, lsl #24
     8b4:      	adrp	x16, 0x0 <ltmp0>
     8b8:      	adrp	x15, 0x0 <ltmp0>
     8bc:      	cmp	x21, #0x1
     8c0:      	b.eq	0x92c <_llm_rows.packet_batch.blocks+0x294>
     8c4:      	mov	w8, #0x8                ; =8
     8c8:      	str	w8, [x20, #0x24]
     8cc:      	ldr	x0, [sp, #0xb8]
     8d0:      	mov	x1, x20
     8d4:      	bl	0x8d4 <_llm_rows.packet_batch.blocks+0x23c>
     8d8:      	mov	x17, x26
     8dc:      	ldp	q14, q13, [sp, #0x80]
     8e0:      	movi.4s	v12, #0x3f, lsl #24
     8e4:      	mvni.4s	v11, #0x80, lsl #24
     8e8:      	movi.4s	v10, #0x4b, lsl #24
     8ec:      	adrp	x16, 0x0 <ltmp0>
     8f0:      	adrp	x15, 0x0 <ltmp0>
     8f4:      	cmp	x21, #0x2
     8f8:      	b.eq	0x92c <_llm_rows.packet_batch.blocks+0x294>
     8fc:      	mov	w8, #0x10               ; =16
     900:      	str	w8, [x20, #0x24]
     904:      	ldr	x0, [sp, #0xb8]
     908:      	mov	x1, x20
     90c:      	bl	0x90c <_llm_rows.packet_batch.blocks+0x274>
     910:      	mov	x17, x26
     914:      	ldp	q14, q13, [sp, #0x80]
     918:      	movi.4s	v12, #0x3f, lsl #24
     91c:      	mvni.4s	v11, #0x80, lsl #24
     920:      	movi.4s	v10, #0x4b, lsl #24
     924:      	adrp	x16, 0x0 <ltmp0>
     928:      	adrp	x15, 0x0 <ltmp0>
     92c:      	and	w8, w27, #0x7
     930:      	mov	x27, x24
     934:      	add	x24, sp, #0x1, lsl #12  ; =0x1000
     938:      	add	x24, x24, #0x250
     93c:      	add	x26, sp, #0x650
     940:      	cbz	w8, 0x784 <_llm_rows.packet_batch.blocks+0xec>
     944:      	dup.4s	v3, w8
     948:      	ldp	q0, q1, [sp, #0x60]
     94c:      	cmhi.4s	v0, v3, v0
     950:      	cmhi.4s	v1, v3, v1
     954:      	uzp1.8h	v7, v1, v0
     958:      	umaxv.8h	h2, v7
     95c:      	fmov	w8, s2
     960:      	tbz	w8, #0x0, 0x784 <_llm_rows.packet_batch.blocks+0xec>
     964:      	mov	x8, #0x0                ; =0
     968:      	ldr	x11, [sp, #0xb8]
     96c:      	ldr	x9, [x11, #0x30]
     970:      	str	x9, [sp, #0x50]
     974:      	ldr	q2, [sp, #0x10]
     978:      	and.16b	v2, v7, v2
     97c:      	addv.8h	h2, v2
     980:      	fmov	w9, s2
     984:      	and	w10, w9, #0xff
     988:      	ubfiz	w9, w19, #2, #27
     98c:      	orr	w9, w9, w21
     990:      	dup.4s	v5, w9
     994:      	ldr	x9, [x11]
     998:      	and.16b	v4, v1, v5
     99c:      	fmov	w11, s4
     9a0:      	mov	w12, #0xc00             ; =3072
     9a4:      	umull	x13, w11, w12
     9a8:      	str	x13, [sp, #0x48]
     9ac:      	umaddl	x11, w11, w12, x9
     9b0:      	fmov	w12, s2
     9b4:      	b	0x9d8 <_llm_rows.packet_batch.blocks+0x340>
     9b8:      	add	x9, x25, x8
     9bc:      	ldp	q17, q18, [x9]
     9c0:      	bif.16b	v16, v18, v0
     9c4:      	bif.16b	v6, v17, v1
     9c8:      	stp	q6, q16, [x9]
     9cc:      	add	x8, x8, #0x20
     9d0:      	cmp	x8, #0xc00
     9d4:      	b.eq	0xa6c <_llm_rows.packet_batch.blocks+0x3d4>
     9d8:      	add	x13, x11, x8
     9dc:      	movi.2d	v6, #0000000000000000
     9e0:      	movi.2d	v16, #0000000000000000
     9e4:      	tbnz	w12, #0x0, 0xa0c <_llm_rows.packet_batch.blocks+0x374>
     9e8:      	and	w9, w12, #0xff
     9ec:      	tbnz	w9, #0x1, 0xa18 <_llm_rows.packet_batch.blocks+0x380>
     9f0:      	tbnz	w9, #0x2, 0xa24 <_llm_rows.packet_batch.blocks+0x38c>
     9f4:      	tbnz	w9, #0x3, 0xa30 <_llm_rows.packet_batch.blocks+0x398>
     9f8:      	tbnz	w9, #0x4, 0xa3c <_llm_rows.packet_batch.blocks+0x3a4>
     9fc:      	tbnz	w9, #0x5, 0xa48 <_llm_rows.packet_batch.blocks+0x3b0>
     a00:      	tbnz	w9, #0x6, 0xa54 <_llm_rows.packet_batch.blocks+0x3bc>
     a04:      	tbz	w9, #0x7, 0x9b8 <_llm_rows.packet_batch.blocks+0x320>
     a08:      	b	0xa60 <_llm_rows.packet_batch.blocks+0x3c8>
     a0c:      	ldr	s6, [x13]
     a10:      	and	w9, w12, #0xff
     a14:      	tbz	w9, #0x1, 0x9f0 <_llm_rows.packet_batch.blocks+0x358>
     a18:      	add	x14, x13, #0x4
     a1c:      	ld1.s	{ v6 }[1], [x14]
     a20:      	tbz	w9, #0x2, 0x9f4 <_llm_rows.packet_batch.blocks+0x35c>
     a24:      	add	x14, x13, #0x8
     a28:      	ld1.s	{ v6 }[2], [x14]
     a2c:      	tbz	w9, #0x3, 0x9f8 <_llm_rows.packet_batch.blocks+0x360>
     a30:      	add	x14, x13, #0xc
     a34:      	ld1.s	{ v6 }[3], [x14]
     a38:      	tbz	w9, #0x4, 0x9fc <_llm_rows.packet_batch.blocks+0x364>
     a3c:      	add	x14, x13, #0x10
     a40:      	ld1.s	{ v16 }[0], [x14]
     a44:      	tbz	w9, #0x5, 0xa00 <_llm_rows.packet_batch.blocks+0x368>
     a48:      	add	x14, x13, #0x14
     a4c:      	ld1.s	{ v16 }[1], [x14]
     a50:      	tbz	w9, #0x6, 0xa04 <_llm_rows.packet_batch.blocks+0x36c>
     a54:      	add	x14, x13, #0x18
     a58:      	ld1.s	{ v16 }[2], [x14]
     a5c:      	tbz	w9, #0x7, 0x9b8 <_llm_rows.packet_batch.blocks+0x320>
     a60:      	add	x9, x13, #0x1c
     a64:      	ld1.s	{ v16 }[3], [x9]
     a68:      	b	0x9b8 <_llm_rows.packet_batch.blocks+0x320>
     a6c:      	str	w17, [sp, #0x58]
     a70:      	mov	x8, #0x0                ; =0
     a74:      	add	x9, sp, #0x2, lsl #12   ; =0x2000
     a78:      	add	x9, x9, #0x150
     a7c:      	adrp	x11, 0x0 <ltmp0>
     a80:      	sshll2.2d	v18, v0, #0x0
     a84:      	sshll2.2d	v6, v1, #0x0
     a88:      	sshll.2d	v16, v0, #0x0
     a8c:      	dup.2d	v17, x8
     a90:      	sshll.2d	v19, v1, #0x0
     a94:      	ldr	q20, [x11]
     a98:      	orr.16b	v20, v17, v20
     a9c:      	ldr	q21, [x27]
     aa0:      	orr.16b	v21, v17, v21
     aa4:      	ldr	q22, [x15]
     aa8:      	orr.16b	v22, v17, v22
     aac:      	ldr	q23, [x16]
     ab0:      	orr.16b	v17, v17, v23
     ab4:      	ldp	q24, q23, [x9, #0x20]
     ab8:      	ldp	q26, q25, [x9]
     abc:      	bif.16b	v17, v26, v19
     ac0:      	bsl.16b	v16, v22, v24
     ac4:      	mov.16b	v19, v6
     ac8:      	bsl.16b	v19, v21, v25
     acc:      	bif.16b	v20, v23, v18
     ad0:      	stp	q16, q20, [x9, #0x20]
     ad4:      	stp	q17, q19, [x9], #0x40
     ad8:      	add	x8, x8, #0x8
     adc:      	cmp	x8, #0x300
     ae0:      	b.ne	0xa80 <_llm_rows.packet_batch.blocks+0x3e8>
     ae4:      	mov	x8, #0x0                ; =0
     ae8:      	sshll.2d	v27, v1, #0x0
     aec:      	sshll.2d	v26, v0, #0x0
     af0:      	and.16b	v5, v0, v5
     af4:      	movi.4s	v19, #0x3, lsl #8
     af8:      	and.16b	v16, v0, v19
     afc:      	mvn.16b	v17, v0
     b00:      	sub.4s	v16, v16, v17
     b04:      	and.16b	v17, v1, v19
     b08:      	mvn.16b	v19, v1
     b0c:      	sub.4s	v17, v17, v19
     b10:      	mov.s	w9, v17[1]
     b14:      	mov.s	w11, v4[1]
     b18:      	udiv	w12, w11, w9
     b1c:      	msub	w9, w12, w9, w11
     b20:      	mov.s	w11, v17[3]
     b24:      	mov.s	w12, v17[2]
     b28:      	fmov	w13, s17
     b2c:      	fmov	w14, s4
     b30:      	udiv	w15, w14, w13
     b34:      	msub	w13, w15, w13, w14
     b38:      	mov.s	w14, v4[3]
     b3c:      	udiv	w15, w14, w11
     b40:      	msub	w11, w15, w11, w14
     b44:      	mov.s	w14, v4[2]
     b48:      	udiv	w15, w14, w12
     b4c:      	msub	w12, w15, w12, w14
     b50:      	mov.s	w14, v16[1]
     b54:      	mov.s	w15, v5[1]
     b58:      	udiv	w16, w15, w14
     b5c:      	msub	w14, w16, w14, w15
     b60:      	mov.s	w15, v16[3]
     b64:      	mov.s	w16, v5[3]
     b68:      	udiv	w17, w16, w15
     b6c:      	msub	w15, w17, w15, w16
     b70:      	mov.s	w16, v16[2]
     b74:      	mov.s	w17, v5[2]
     b78:      	udiv	w0, w17, w16
     b7c:      	msub	w16, w0, w16, w17
     b80:      	fmov	w17, s16
     b84:      	fmov	w0, s5
     b88:      	fmov	s4, w16
     b8c:      	mov.s	v4[1], w15
     b90:      	udiv	w15, w0, w17
     b94:      	msub	w15, w15, w17, w0
     b98:      	ushll.2d	v16, v4, #0x0
     b9c:      	fmov	s4, w15
     ba0:      	mov.s	v4[1], w14
     ba4:      	ushll.2d	v17, v4, #0x0
     ba8:      	fmov	s4, w12
     bac:      	mov.s	v4[1], w11
     bb0:      	fmov	s5, w13
     bb4:      	mov.s	v5[1], w9
     bb8:      	ushll.2d	v19, v4, #0x0
     bbc:      	ushll.2d	v20, v5, #0x0
     bc0:      	ldr	q4, [sp, #0x30]
     bc4:      	and.16b	v21, v18, v4
     bc8:      	and.16b	v22, v6, v4
     bcc:      	and.16b	v23, v26, v4
     bd0:      	and.16b	v24, v27, v4
     bd4:      	adrp	x9, 0x0 <ltmp0>
     bd8:      	ldr	q4, [x9]
     bdc:      	and.16b	v18, v18, v4
     be0:      	adrp	x9, 0x0 <ltmp0>
     be4:      	ldr	q4, [x9]
     be8:      	and.16b	v25, v6, v4
     bec:      	adrp	x9, 0x0 <ltmp0>
     bf0:      	ldr	q4, [x9]
     bf4:      	and.16b	v26, v26, v4
     bf8:      	adrp	x9, 0x0 <ltmp0>
     bfc:      	ldr	q4, [x9]
     c00:      	and.16b	v27, v27, v4
     c04:      	ldp	q4, q5, [sp, #0x60]
     c08:      	cmhs.4s	v4, v4, v3
     c0c:      	cmhs.4s	v3, v5, v3
     c10:      	uzp1.8h	v3, v3, v4
     c14:      	xtn.8b	v28, v3
     c18:      	add	x12, sp, #0x2, lsl #12  ; =0x2000
     c1c:      	add	x12, x12, #0x150
     c20:      	mov	w13, #0xf2ca            ; =62154
     c24:      	movk	w13, #0xf149, lsl #16
     c28:      	b	0xc38 <_llm_rows.packet_batch.blocks+0x5a0>
     c2c:      	add	x8, x8, #0x1
     c30:      	cmp	x8, #0x60
     c34:      	b.eq	0xd38 <_llm_rows.packet_batch.blocks+0x6a0>
     c38:      	dup.2d	v29, x8
     c3c:      	fmov	w9, s2
     c40:      	add	x11, x12, x8, lsl #6
     c44:      	ldp	q4, q3, [x11, #0x20]
     c48:      	ldp	q5, q6, [x11]
     c4c:      	cmge.2d	v6, v19, v6
     c50:      	cmge.2d	v5, v20, v5
     c54:      	uzp1.4s	v5, v5, v6
     c58:      	cmge.2d	v4, v17, v4
     c5c:      	cmge.2d	v3, v16, v3
     c60:      	uzp1.4s	v3, v4, v3
     c64:      	uzp1.8h	v3, v5, v3
     c68:      	xtn.8b	v3, v3
     c6c:      	orr.8b	v5, v28, v3
     c70:      	add.2d	v3, v24, v27
     c74:      	add.2d	v4, v3, v29
     c78:      	and.8b	v30, v5, v8
     c7c:      	tbnz	w9, #0x0, 0xcbc <_llm_rows.packet_batch.blocks+0x624>
     c80:      	and	w9, w9, #0xff
     c84:      	tbnz	w9, #0x1, 0xccc <_llm_rows.packet_batch.blocks+0x634>
     c88:      	add.2d	v4, v22, v25
     c8c:      	add.2d	v5, v4, v29
     c90:      	tbnz	w9, #0x2, 0xce0 <_llm_rows.packet_batch.blocks+0x648>
     c94:      	tbnz	w9, #0x3, 0xcec <_llm_rows.packet_batch.blocks+0x654>
     c98:      	add.2d	v5, v23, v26
     c9c:      	add.2d	v6, v5, v29
     ca0:      	tbnz	w9, #0x4, 0xd00 <_llm_rows.packet_batch.blocks+0x668>
     ca4:      	tbnz	w9, #0x5, 0xd0c <_llm_rows.packet_batch.blocks+0x674>
     ca8:      	add.2d	v6, v21, v18
     cac:      	add.2d	v29, v6, v29
     cb0:      	tbnz	w9, #0x6, 0xd20 <_llm_rows.packet_batch.blocks+0x688>
     cb4:      	tbz	w9, #0x7, 0xc2c <_llm_rows.packet_batch.blocks+0x594>
     cb8:      	b	0xd2c <_llm_rows.packet_batch.blocks+0x694>
     cbc:      	fmov	x11, d4
     cc0:      	str	b30, [x11]
     cc4:      	and	w9, w9, #0xff
     cc8:      	tbz	w9, #0x1, 0xc88 <_llm_rows.packet_batch.blocks+0x5f0>
     ccc:      	mov.d	x11, v4[1]
     cd0:      	st1.b	{ v30 }[1], [x11]
     cd4:      	add.2d	v4, v22, v25
     cd8:      	add.2d	v5, v4, v29
     cdc:      	tbz	w9, #0x2, 0xc94 <_llm_rows.packet_batch.blocks+0x5fc>
     ce0:      	fmov	x11, d5
     ce4:      	st1.b	{ v30 }[2], [x11]
     ce8:      	tbz	w9, #0x3, 0xc98 <_llm_rows.packet_batch.blocks+0x600>
     cec:      	mov.d	x11, v5[1]
     cf0:      	st1.b	{ v30 }[3], [x11]
     cf4:      	add.2d	v5, v23, v26
     cf8:      	add.2d	v6, v5, v29
     cfc:      	tbz	w9, #0x4, 0xca4 <_llm_rows.packet_batch.blocks+0x60c>
     d00:      	fmov	x11, d6
     d04:      	st1.b	{ v30 }[4], [x11]
     d08:      	tbz	w9, #0x5, 0xca8 <_llm_rows.packet_batch.blocks+0x610>
     d0c:      	mov.d	x11, v6[1]
     d10:      	st1.b	{ v30 }[5], [x11]
     d14:      	add.2d	v6, v21, v18
     d18:      	add.2d	v29, v6, v29
     d1c:      	tbz	w9, #0x6, 0xcb4 <_llm_rows.packet_batch.blocks+0x61c>
     d20:      	fmov	x11, d29
     d24:      	st1.b	{ v30 }[6], [x11]
     d28:      	tbz	w9, #0x7, 0xc2c <_llm_rows.packet_batch.blocks+0x594>
     d2c:      	mov.d	x9, v29[1]
     d30:      	st1.b	{ v30 }[7], [x9]
     d34:      	b	0xc2c <_llm_rows.packet_batch.blocks+0x594>
     d38:      	mov	x8, #0x0                ; =0
     d3c:      	b	0xd90 <_llm_rows.packet_batch.blocks+0x6f8>
     d40:      	cmeq.8b	v16, v16, #0
     d44:      	sshll.8h	v16, v16, #0x0
     d48:      	sshll2.4s	v17, v16, #0x0
     d4c:      	sshll.4s	v16, v16, #0x0
     d50:      	lsl	x9, x8, #5
     d54:      	add	x11, x25, x9
     d58:      	ldp	q18, q19, [x11]
     d5c:      	and.16b	v19, v0, v19
     d60:      	dup.4s	v20, w13
     d64:      	and.16b	v18, v1, v18
     d68:      	bsl.16b	v16, v20, v18
     d6c:      	bsl.16b	v17, v20, v19
     d70:      	add	x9, x24, x9
     d74:      	ldp	q18, q19, [x9]
     d78:      	bif.16b	v17, v19, v0
     d7c:      	bif.16b	v16, v18, v1
     d80:      	stp	q16, q17, [x9]
     d84:      	add	x8, x8, #0x1
     d88:      	cmp	x8, #0x60
     d8c:      	b.eq	0xe40 <_llm_rows.packet_batch.blocks+0x7a8>
     d90:      	fmov	w9, s2
     d94:      	dup.2d	v17, x8
     d98:      	add.2d	v18, v3, v17
     d9c:      	tbz	w9, #0x0, 0xdb4 <_llm_rows.packet_batch.blocks+0x71c>
     da0:      	fmov	x11, d18
     da4:      	ldr	b16, [x11]
     da8:      	and	w9, w9, #0xff
     dac:      	tbnz	w9, #0x1, 0xdc0 <_llm_rows.packet_batch.blocks+0x728>
     db0:      	b	0xdc8 <_llm_rows.packet_batch.blocks+0x730>
     db4:      	movi.2d	v16, #0000000000000000
     db8:      	and	w9, w9, #0xff
     dbc:      	tbz	w9, #0x1, 0xdc8 <_llm_rows.packet_batch.blocks+0x730>
     dc0:      	mov.d	x11, v18[1]
     dc4:      	ld1.b	{ v16 }[1], [x11]
     dc8:      	add.2d	v18, v4, v17
     dcc:      	tbnz	w9, #0x2, 0xdf0 <_llm_rows.packet_batch.blocks+0x758>
     dd0:      	tbnz	w9, #0x3, 0xdfc <_llm_rows.packet_batch.blocks+0x764>
     dd4:      	add.2d	v18, v5, v17
     dd8:      	tbnz	w9, #0x4, 0xe0c <_llm_rows.packet_batch.blocks+0x774>
     ddc:      	tbnz	w9, #0x5, 0xe18 <_llm_rows.packet_batch.blocks+0x780>
     de0:      	add.2d	v17, v6, v17
     de4:      	tbnz	w9, #0x6, 0xe28 <_llm_rows.packet_batch.blocks+0x790>
     de8:      	tbz	w9, #0x7, 0xd40 <_llm_rows.packet_batch.blocks+0x6a8>
     dec:      	b	0xe34 <_llm_rows.packet_batch.blocks+0x79c>
     df0:      	fmov	x11, d18
     df4:      	ld1.b	{ v16 }[2], [x11]
     df8:      	tbz	w9, #0x3, 0xdd4 <_llm_rows.packet_batch.blocks+0x73c>
     dfc:      	mov.d	x11, v18[1]
     e00:      	ld1.b	{ v16 }[3], [x11]
     e04:      	add.2d	v18, v5, v17
     e08:      	tbz	w9, #0x4, 0xddc <_llm_rows.packet_batch.blocks+0x744>
     e0c:      	fmov	x11, d18
     e10:      	ld1.b	{ v16 }[4], [x11]
     e14:      	tbz	w9, #0x5, 0xde0 <_llm_rows.packet_batch.blocks+0x748>
     e18:      	mov.d	x11, v18[1]
     e1c:      	ld1.b	{ v16 }[5], [x11]
     e20:      	add.2d	v17, v6, v17
     e24:      	tbz	w9, #0x6, 0xde8 <_llm_rows.packet_batch.blocks+0x750>
     e28:      	fmov	x11, d17
     e2c:      	ld1.b	{ v16 }[6], [x11]
     e30:      	tbz	w9, #0x7, 0xd40 <_llm_rows.packet_batch.blocks+0x6a8>
     e34:      	mov.d	x9, v17[1]
     e38:      	ld1.b	{ v16 }[7], [x9]
     e3c:      	b	0xd40 <_llm_rows.packet_batch.blocks+0x6a8>
     e40:      	ldr	q16, [x23, #0x1100]
     e44:      	ldr	q17, [x23, #0x1110]
     e48:      	ldr	q18, [x23, #0x1120]
     e4c:      	ldr	q19, [x23, #0x1130]
     e50:      	ldr	q20, [x23, #0x1140]
     e54:      	ldr	q23, [x23, #0x1150]
     e58:      	ldr	q24, [x23, #0x1160]
     e5c:      	and.16b	v17, v0, v17
     e60:      	and.16b	v16, v1, v16
     e64:      	ldr	q25, [x23, #0x1170]
     e68:      	and.16b	v22, v0, v19
     e6c:      	and.16b	v21, v1, v18
     e70:      	and.16b	v18, v0, v23
     e74:      	and.16b	v23, v1, v20
     e78:      	and.16b	v20, v0, v25
     e7c:      	and.16b	v19, v1, v24
     e80:      	ldr	x8, [sp, #0x28]
     e84:      	mov	w9, #0x4                ; =4
     e88:      	ldp	q24, q25, [x8, #-0x60]
     e8c:      	and.16b	v25, v0, v25
     e90:      	and.16b	v24, v1, v24
     e94:      	fmaxnm.4s	v24, v16, v24
     e98:      	fmaxnm.4s	v25, v17, v25
     e9c:      	ldp	q26, q27, [x8, #-0x40]
     ea0:      	and.16b	v27, v0, v27
     ea4:      	and.16b	v26, v1, v26
     ea8:      	fmaxnm.4s	v26, v21, v26
     eac:      	fmaxnm.4s	v27, v22, v27
     eb0:      	ldp	q28, q29, [x8, #-0x20]
     eb4:      	and.16b	v29, v0, v29
     eb8:      	and.16b	v28, v1, v28
     ebc:      	fmaxnm.4s	v28, v23, v28
     ec0:      	fmaxnm.4s	v29, v18, v29
     ec4:      	ldp	q30, q31, [x8], #0x80
     ec8:      	and.16b	v31, v0, v31
     ecc:      	and.16b	v30, v1, v30
     ed0:      	fmaxnm.4s	v30, v19, v30
     ed4:      	fmaxnm.4s	v31, v20, v31
     ed8:      	bit.16b	v17, v25, v0
     edc:      	bit.16b	v16, v24, v1
     ee0:      	bit.16b	v22, v27, v0
     ee4:      	bit.16b	v21, v26, v1
     ee8:      	bit.16b	v18, v29, v0
     eec:      	bit.16b	v23, v28, v1
     ef0:      	bit.16b	v20, v31, v0
     ef4:      	bit.16b	v19, v30, v1
     ef8:      	cmp	x9, #0x5c
     efc:      	add	x9, x9, #0x4
     f00:      	b.lo	0xe88 <_llm_rows.packet_batch.blocks+0x7f0>
     f04:      	mov	x8, #0x0                ; =0
     f08:      	xtn.8b	v7, v7
     f0c:      	fmaxnm.4s	v17, v17, v22
     f10:      	fmaxnm.4s	v16, v16, v21
     f14:      	fmaxnm.4s	v16, v16, v23
     f18:      	fmaxnm.4s	v17, v17, v18
     f1c:      	fmaxnm.4s	v17, v17, v20
     f20:      	fmaxnm.4s	v18, v16, v19
     f24:      	ldp	q19, q16, [sp, #0x60]
     f28:      	and.16b	v16, v1, v16
     f2c:      	and.16b	v19, v0, v19
     f30:      	movi.4s	v20, #0x1
     f34:      	eor.16b	v21, v19, v20
     f38:      	eor.16b	v24, v16, v20
     f3c:      	umov.b	w11, v7[0]
     f40:      	str	q18, [x23, #0x4d0]
     f44:      	ldr	s20, [x23, #0x4d4]
     f48:      	umov.b	w12, v7[1]
     f4c:      	ands	w1, w11, #0x1
     f50:      	tst	w1, w12
     f54:      	fcsel	s20, s20, s9, ne
     f58:      	mov.s	w9, v24[1]
     f5c:      	add	x13, sp, #0x600
     f60:      	orr	x13, x13, x9, lsl #2
     f64:      	add	x14, sp, #0x318
     f68:      	bfxil	x14, x9, #0, #3
     f6c:      	str	d7, [x23, #0x1c8]
     f70:      	ldrb	w9, [x14]
     f74:      	and	w9, w12, w9
     f78:      	str	q18, [x23, #0x4b0]
     f7c:      	str	q17, [x23, #0x4c0]
     f80:      	ldr	s22, [x13]
     f84:      	tst	w9, #0x1
     f88:      	fcsel	s22, s22, s9, ne
     f8c:      	mov.s	w9, v24[2]
     f90:      	add	x13, sp, #0x5e0
     f94:      	orr	x14, x13, x9, lsl #2
     f98:      	add	x13, sp, #0x318
     f9c:      	bfxil	x13, x9, #0, #3
     fa0:      	ldrb	w9, [x13]
     fa4:      	umov.b	w13, v7[2]
     fa8:      	and	w9, w13, w9
     fac:      	str	q18, [x23, #0x490]
     fb0:      	str	q17, [x23, #0x4a0]
     fb4:      	ldr	s23, [x14]
     fb8:      	tst	w9, #0x1
     fbc:      	fcsel	s23, s23, s9, ne
     fc0:      	mov.s	w9, v24[3]
     fc4:      	add	x14, sp, #0x5c0
     fc8:      	orr	x15, x14, x9, lsl #2
     fcc:      	add	x14, sp, #0x318
     fd0:      	bfxil	x14, x9, #0, #3
     fd4:      	ldrb	w9, [x14]
     fd8:      	umov.b	w14, v7[3]
     fdc:      	and	w9, w14, w9
     fe0:      	str	q18, [x23, #0x470]
     fe4:      	str	q17, [x23, #0x480]
     fe8:      	ldr	s24, [x15]
     fec:      	tst	w9, #0x1
     ff0:      	fcsel	s24, s24, s9, ne
     ff4:      	fmov	w9, s21
     ff8:      	add	x15, sp, #0x318
     ffc:      	bfxil	x15, x9, #0, #3
    1000:      	ldrb	w16, [x15]
    1004:      	umov.b	w15, v7[4]
    1008:      	str	q18, [x23, #0x450]
    100c:      	str	q17, [x23, #0x460]
    1010:      	add	x17, sp, #0x5a0
    1014:      	ldr	s25, [x17, w9, uxtw #2]
    1018:      	and	w9, w15, w16
    101c:      	tst	w9, #0x1
    1020:      	fcsel	s25, s25, s9, ne
    1024:      	mov.s	w9, v21[1]
    1028:      	add	x16, sp, #0x318
    102c:      	bfxil	x16, x9, #0, #3
    1030:      	ldrb	w17, [x16]
    1034:      	umov.b	w16, v7[5]
    1038:      	and	w17, w16, w17
    103c:      	str	q18, [x23, #0x430]
    1040:      	str	q17, [x23, #0x440]
    1044:      	add	x0, sp, #0x580
    1048:      	ldr	s26, [x0, w9, uxtw #2]
    104c:      	tst	w17, #0x1
    1050:      	mov.s	w9, v21[2]
    1054:      	fcsel	s26, s26, s9, ne
    1058:      	add	x17, sp, #0x318
    105c:      	bfxil	x17, x9, #0, #3
    1060:      	ldrb	w0, [x17]
    1064:      	umov.b	w17, v7[6]
    1068:      	and	w0, w17, w0
    106c:      	str	q18, [x23, #0x410]
    1070:      	str	q17, [x23, #0x420]
    1074:      	add	x2, sp, #0x560
    1078:      	ldr	s27, [x2, w9, uxtw #2]
    107c:      	tst	w0, #0x1
    1080:      	fcsel	s27, s27, s9, ne
    1084:      	mov.s	w9, v21[3]
    1088:      	add	x0, sp, #0x318
    108c:      	bfxil	x0, x9, #0, #3
    1090:      	ldrb	w2, [x0]
    1094:      	umov.b	w0, v7[7]
    1098:      	stp	q18, q17, [x23, #0x3f0]
    109c:      	add	x3, sp, #0x540
    10a0:      	ldr	s21, [x3, w9, uxtw #2]
    10a4:      	and	w9, w0, w2
    10a8:      	tst	w9, #0x1
    10ac:      	mov.s	v20[1], v22[0]
    10b0:      	mov.s	v20[2], v23[0]
    10b4:      	mov.s	v20[3], v24[0]
    10b8:      	mov.s	v25[1], v26[0]
    10bc:      	mov.s	v25[2], v27[0]
    10c0:      	fcsel	s21, s21, s9, ne
    10c4:      	mov.s	v25[3], v21[0]
    10c8:      	fmaxnm.4s	v17, v17, v25
    10cc:      	fmaxnm.4s	v18, v18, v20
    10d0:      	movi.4s	v20, #0x2
    10d4:      	eor.16b	v21, v19, v20
    10d8:      	eor.16b	v22, v16, v20
    10dc:      	str	q18, [x23, #0x3d0]
    10e0:      	ldr	s19, [x23, #0x3d8]
    10e4:      	tst	w1, w13
    10e8:      	mov.s	w9, v22[1]
    10ec:      	fcsel	s19, s19, s9, ne
    10f0:      	add	x2, sp, #0x500
    10f4:      	orr	x2, x2, x9, lsl #2
    10f8:      	add	x3, sp, #0x318
    10fc:      	bfxil	x3, x9, #0, #3
    1100:      	ldrb	w9, [x3]
    1104:      	and	w9, w12, w9
    1108:      	stp	q18, q17, [x23, #0x3b0]
    110c:      	ldr	s20, [x2]
    1110:      	tst	w9, #0x1
    1114:      	mov.s	w9, v22[2]
    1118:      	fcsel	s20, s20, s9, ne
    111c:      	add	x2, sp, #0x4e0
    1120:      	orr	x2, x2, x9, lsl #2
    1124:      	add	x3, sp, #0x318
    1128:      	bfxil	x3, x9, #0, #3
    112c:      	ldrb	w9, [x3]
    1130:      	and	w9, w13, w9
    1134:      	stp	q18, q17, [x23, #0x390]
    1138:      	ldr	s23, [x2]
    113c:      	tst	w9, #0x1
    1140:      	mov.s	w9, v22[3]
    1144:      	fcsel	s22, s23, s9, ne
    1148:      	add	x2, sp, #0x4c0
    114c:      	orr	x2, x2, x9, lsl #2
    1150:      	add	x3, sp, #0x318
    1154:      	bfxil	x3, x9, #0, #3
    1158:      	ldrb	w9, [x3]
    115c:      	and	w9, w14, w9
    1160:      	stp	q18, q17, [x23, #0x370]
    1164:      	ldr	s23, [x2]
    1168:      	tst	w9, #0x1
    116c:      	fcsel	s23, s23, s9, ne
    1170:      	fmov	w9, s21
    1174:      	add	x2, sp, #0x318
    1178:      	bfxil	x2, x9, #0, #3
    117c:      	ldrb	w2, [x2]
    1180:      	and	w2, w15, w2
    1184:      	stp	q18, q17, [x23, #0x350]
    1188:      	add	x3, sp, #0x4a0
    118c:      	ldr	s24, [x3, w9, uxtw #2]
    1190:      	tst	w2, #0x1
    1194:      	fcsel	s24, s24, s9, ne
    1198:      	mov.s	w9, v21[1]
    119c:      	add	x2, sp, #0x318
    11a0:      	bfxil	x2, x9, #0, #3
    11a4:      	ldrb	w2, [x2]
    11a8:      	and	w2, w16, w2
    11ac:      	stp	q18, q17, [x23, #0x330]
    11b0:      	add	x3, sp, #0x480
    11b4:      	ldr	s25, [x3, w9, uxtw #2]
    11b8:      	tst	w2, #0x1
    11bc:      	fcsel	s25, s25, s9, ne
    11c0:      	mov.s	w9, v21[2]
    11c4:      	add	x2, sp, #0x318
    11c8:      	bfxil	x2, x9, #0, #3
    11cc:      	ldrb	w2, [x2]
    11d0:      	and	w2, w17, w2
    11d4:      	stp	q18, q17, [x23, #0x310]
    11d8:      	add	x3, sp, #0x460
    11dc:      	ldr	s26, [x3, w9, uxtw #2]
    11e0:      	tst	w2, #0x1
    11e4:      	fcsel	s26, s26, s9, ne
    11e8:      	mov.s	w9, v21[3]
    11ec:      	add	x2, sp, #0x318
    11f0:      	bfxil	x2, x9, #0, #3
    11f4:      	ldrb	w2, [x2]
    11f8:      	and	w2, w0, w2
    11fc:      	stp	q18, q17, [x23, #0x2f0]
    1200:      	add	x3, sp, #0x440
    1204:      	ldr	s21, [x3, w9, uxtw #2]
    1208:      	tst	w2, #0x1
    120c:      	fcsel	s21, s21, s9, ne
    1210:      	mov.s	v24[1], v25[0]
    1214:      	mov.s	v24[2], v26[0]
    1218:      	mov.s	v24[3], v21[0]
    121c:      	mov.s	v19[1], v20[0]
    1220:      	mov.s	v19[2], v22[0]
    1224:      	mov.s	v19[3], v23[0]
    1228:      	fmaxnm.4s	v18, v18, v19
    122c:      	fmaxnm.4s	v17, v17, v24
    1230:      	orr.4s	v16, #0x4
    1234:      	str	q17, [x23, #0x2e0]
    1238:      	ldr	s19, [x23, #0x2e0]
    123c:      	tst	w1, w15
    1240:      	fcsel	s19, s19, s9, ne
    1244:      	mov.s	w9, v16[1]
    1248:      	add	x1, sp, #0x318
    124c:      	bfxil	x1, x9, #0, #3
    1250:      	ldrb	w1, [x1]
    1254:      	and	w1, w12, w1
    1258:      	stp	q18, q17, [x23, #0x2b0]
    125c:      	add	x2, sp, #0x400
    1260:      	ldr	s20, [x2, w9, uxtw #2]
    1264:      	tst	w1, #0x1
    1268:      	fcsel	s20, s20, s9, ne
    126c:      	mov.s	w9, v16[2]
    1270:      	add	x1, sp, #0x318
    1274:      	bfxil	x1, x9, #0, #3
    1278:      	ldrb	w1, [x1]
    127c:      	and	w1, w13, w1
    1280:      	stp	q18, q17, [x23, #0x290]
    1284:      	add	x2, sp, #0x3e0
    1288:      	ldr	s21, [x2, w9, uxtw #2]
    128c:      	tst	w1, #0x1
    1290:      	fcsel	s21, s21, s9, ne
    1294:      	mov.s	w9, v16[3]
    1298:      	add	x1, sp, #0x318
    129c:      	bfxil	x1, x9, #0, #3
    12a0:      	ldrb	w1, [x1]
    12a4:      	and	w1, w14, w1
    12a8:      	stp	q18, q17, [x23, #0x270]
    12ac:      	add	x2, sp, #0x3c0
    12b0:      	ldr	s16, [x2, w9, uxtw #2]
    12b4:      	tst	w1, #0x1
    12b8:      	fcsel	s16, s16, s9, ne
    12bc:      	mov.s	v19[1], v20[0]
    12c0:      	mov.s	v19[2], v21[0]
    12c4:      	mov.s	v19[3], v16[0]
    12c8:      	ands	w3, w11, #0x1
    12cc:      	fmaxnm.4s	v16, v18, v19
    12d0:      	fcsel	s17, s16, s9, ne
    12d4:      	and	w1, w12, w11
    12d8:      	tst	w1, #0x1
    12dc:      	fcsel	s18, s16, s9, ne
    12e0:      	and	w2, w13, w11
    12e4:      	tst	w2, #0x1
    12e8:      	fcsel	s19, s16, s9, ne
    12ec:      	and	w4, w14, w11
    12f0:      	tst	w4, #0x1
    12f4:      	fcsel	s20, s16, s9, ne
    12f8:      	and	w5, w15, w11
    12fc:      	tst	w5, #0x1
    1300:      	fcsel	s21, s16, s9, ne
    1304:      	and	w6, w16, w11
    1308:      	tst	w6, #0x1
    130c:      	fcsel	s22, s16, s9, ne
    1310:      	and	w7, w17, w11
    1314:      	tst	w7, #0x1
    1318:      	fcsel	s23, s16, s9, ne
    131c:      	and	w30, w0, w11
    1320:      	tst	w30, #0x1
    1324:      	fcsel	s16, s16, s9, ne
    1328:      	mov.s	v17[1], v18[0]
    132c:      	mov.s	v17[2], v19[0]
    1330:      	mov.s	v17[3], v20[0]
    1334:      	mov.s	v21[1], v22[0]
    1338:      	mov.s	v21[2], v23[0]
    133c:      	mov.s	v21[3], v16[0]
    1340:      	rbit	w9, w10
    1344:      	clz	w10, w9
    1348:      	stp	q17, q21, [x23, #0x1d0]
    134c:      	and	x9, x10, #0x7
    1350:      	add	x21, sp, #0x320
    1354:      	ldr	s16, [x21, x9, lsl #2]
    1358:      	mov	w9, #-0x800000          ; =-8388608
    135c:      	fmov	s17, w9
    1360:      	fmaxnm	s16, s16, s17
    1364:      	dup.4s	v16, v16[0]
    1368:      	b	0x1590 <_llm_rows.packet_batch.blocks+0xef8>
    136c:      	cmeq.8b	v17, v17, #0
    1370:      	sshll.8h	v18, v17, #0x0
    1374:      	sshll2.4s	v17, v18, #0x0
    1378:      	sshll.4s	v18, v18, #0x0
    137c:      	lsl	x9, x8, #5
    1380:      	add	x21, x24, x9
    1384:      	ldp	q20, q19, [x21]
    1388:      	fsub.4s	v20, v20, v16
    138c:      	fsub.4s	v19, v19, v16
    1390:      	and.16b	v19, v0, v19
    1394:      	and.16b	v20, v1, v20
    1398:      	mov	w21, #-0x3d300000       ; =-1026555904
    139c:      	dup.4s	v21, w21
    13a0:      	fcmge.4s	v23, v20, v21
    13a4:      	fcmge.4s	v24, v19, v21
    13a8:      	mov	w21, #0x42c80000        ; =1120403456
    13ac:      	dup.4s	v22, w21
    13b0:      	fcmge.4s	v25, v22, v20
    13b4:      	fcmge.4s	v26, v22, v19
    13b8:      	and.16b	v24, v24, v26
    13bc:      	and.16b	v23, v23, v25
    13c0:      	and.16b	v23, v23, v20
    13c4:      	and.16b	v24, v24, v19
    13c8:      	mov	w21, #0xaa3b            ; =43579
    13cc:      	movk	w21, #0x3fb8, lsl #16
    13d0:      	dup.4s	v25, w21
    13d4:      	fmul.4s	v26, v24, v25
    13d8:      	fmul.4s	v25, v23, v25
    13dc:      	mov.16b	v27, v11
    13e0:      	bsl.16b	v27, v10, v25
    13e4:      	mov.16b	v28, v11
    13e8:      	bsl.16b	v28, v10, v26
    13ec:      	fadd.4s	v26, v26, v28
    13f0:      	fadd.4s	v25, v25, v27
    13f4:      	fsub.4s	v25, v25, v27
    13f8:      	fsub.4s	v26, v26, v28
    13fc:      	fcvtzs.4s	v26, v26
    1400:      	fcvtzs.4s	v25, v25
    1404:      	scvtf.4s	v27, v25
    1408:      	scvtf.4s	v28, v26
    140c:      	mov	w21, #0x7200            ; =29184
    1410:      	movk	w21, #0xbf31, lsl #16
    1414:      	dup.4s	v29, w21
    1418:      	fmul.4s	v30, v28, v29
    141c:      	fmul.4s	v29, v27, v29
    1420:      	fadd.4s	v23, v23, v29
    1424:      	fadd.4s	v24, v24, v30
    1428:      	mov	w21, #0xbe8e            ; =48782
    142c:      	movk	w21, #0xb5bf, lsl #16
    1430:      	dup.4s	v29, w21
    1434:      	fmul.4s	v27, v27, v29
    1438:      	fmul.4s	v28, v28, v29
    143c:      	fadd.4s	v24, v24, v28
    1440:      	fadd.4s	v23, v23, v27
    1444:      	mov	w21, #0x2bda            ; =11226
    1448:      	movk	w21, #0x3950, lsl #16
    144c:      	dup.4s	v27, w21
    1450:      	fmul.4s	v28, v23, v27
    1454:      	fmul.4s	v27, v24, v27
    1458:      	mov	w21, #0x96c9            ; =38601
    145c:      	movk	w21, #0x3ab6, lsl #16
    1460:      	dup.4s	v29, w21
    1464:      	fadd.4s	v27, v27, v29
    1468:      	fadd.4s	v28, v28, v29
    146c:      	fmul.4s	v28, v23, v28
    1470:      	fmul.4s	v27, v24, v27
    1474:      	mov	w21, #0x88a6            ; =34982
    1478:      	movk	w21, #0x3c08, lsl #16
    147c:      	dup.4s	v29, w21
    1480:      	fadd.4s	v27, v27, v29
    1484:      	fadd.4s	v28, v28, v29
    1488:      	fmul.4s	v28, v23, v28
    148c:      	fmul.4s	v27, v24, v27
    1490:      	mov	w21, #0xaa7a            ; =43642
    1494:      	movk	w21, #0x3d2a, lsl #16
    1498:      	dup.4s	v29, w21
    149c:      	fadd.4s	v27, v27, v29
    14a0:      	fadd.4s	v28, v28, v29
    14a4:      	fmul.4s	v28, v23, v28
    14a8:      	fmul.4s	v27, v24, v27
    14ac:      	mov	w21, #0xaaab            ; =43691
    14b0:      	movk	w21, #0x3e2a, lsl #16
    14b4:      	dup.4s	v29, w21
    14b8:      	fadd.4s	v27, v27, v29
    14bc:      	fadd.4s	v28, v28, v29
    14c0:      	fmul.4s	v28, v23, v28
    14c4:      	fmul.4s	v27, v24, v27
    14c8:      	fadd.4s	v27, v27, v12
    14cc:      	fadd.4s	v28, v28, v12
    14d0:      	fmul.4s	v29, v24, v24
    14d4:      	fmul.4s	v30, v23, v23
    14d8:      	fmul.4s	v28, v30, v28
    14dc:      	fmul.4s	v27, v29, v27
    14e0:      	fadd.4s	v24, v24, v27
    14e4:      	fadd.4s	v23, v23, v28
    14e8:      	fmov.4s	v27, #1.00000000
    14ec:      	fadd.4s	v23, v23, v27
    14f0:      	fadd.4s	v24, v24, v27
    14f4:      	sshr.4s	v28, v25, #0x1
    14f8:      	sshr.4s	v29, v26, #0x1
    14fc:      	shl.4s	v30, v29, #0x17
    1500:      	shl.4s	v31, v28, #0x17
    1504:      	add.4s	v31, v31, v27
    1508:      	add.4s	v30, v30, v27
    150c:      	fmul.4s	v24, v24, v30
    1510:      	fmul.4s	v23, v23, v31
    1514:      	sub.4s	v26, v26, v29
    1518:      	sub.4s	v25, v25, v28
    151c:      	shl.4s	v25, v25, #0x17
    1520:      	shl.4s	v26, v26, #0x17
    1524:      	add.4s	v26, v26, v27
    1528:      	add.4s	v25, v25, v27
    152c:      	fmul.4s	v23, v23, v25
    1530:      	fmul.4s	v24, v24, v26
    1534:      	fcmgt.4s	v25, v21, v19
    1538:      	bic.16b	v24, v24, v25
    153c:      	fcmgt.4s	v21, v21, v20
    1540:      	bic.16b	v21, v23, v21
    1544:      	fcmgt.4s	v23, v19, v22
    1548:      	fcmgt.4s	v22, v20, v22
    154c:      	bit.16b	v21, v13, v22
    1550:      	mov.16b	v22, v23
    1554:      	bsl.16b	v22, v13, v24
    1558:      	fcmeq.4s	v20, v20, v20
    155c:      	fcmeq.4s	v19, v19, v19
    1560:      	bsl.16b	v19, v22, v14
    1564:      	bsl.16b	v20, v21, v14
    1568:      	bic.16b	v18, v20, v18
    156c:      	bic.16b	v17, v19, v17
    1570:      	add	x9, x26, x9
    1574:      	ldp	q19, q20, [x9]
    1578:      	bif.16b	v17, v20, v0
    157c:      	bif.16b	v18, v19, v1
    1580:      	stp	q18, q17, [x9]
    1584:      	add	x8, x8, #0x1
    1588:      	cmp	x8, #0x60
    158c:      	b.eq	0x1640 <_llm_rows.packet_batch.blocks+0xfa8>
    1590:      	fmov	w9, s2
    1594:      	dup.2d	v18, x8
    1598:      	add.2d	v19, v3, v18
    159c:      	tbz	w9, #0x0, 0x15b4 <_llm_rows.packet_batch.blocks+0xf1c>
    15a0:      	fmov	x21, d19
    15a4:      	ldr	b17, [x21]
    15a8:      	and	w9, w9, #0xff
    15ac:      	tbnz	w9, #0x1, 0x15c0 <_llm_rows.packet_batch.blocks+0xf28>
    15b0:      	b	0x15c8 <_llm_rows.packet_batch.blocks+0xf30>
    15b4:      	movi.2d	v17, #0000000000000000
    15b8:      	and	w9, w9, #0xff
    15bc:      	tbz	w9, #0x1, 0x15c8 <_llm_rows.packet_batch.blocks+0xf30>
    15c0:      	mov.d	x21, v19[1]
    15c4:      	ld1.b	{ v17 }[1], [x21]
    15c8:      	add.2d	v19, v4, v18
    15cc:      	tbnz	w9, #0x2, 0x15f0 <_llm_rows.packet_batch.blocks+0xf58>
    15d0:      	tbnz	w9, #0x3, 0x15fc <_llm_rows.packet_batch.blocks+0xf64>
    15d4:      	add.2d	v19, v5, v18
    15d8:      	tbnz	w9, #0x4, 0x160c <_llm_rows.packet_batch.blocks+0xf74>
    15dc:      	tbnz	w9, #0x5, 0x1618 <_llm_rows.packet_batch.blocks+0xf80>
    15e0:      	add.2d	v18, v6, v18
    15e4:      	tbnz	w9, #0x6, 0x1628 <_llm_rows.packet_batch.blocks+0xf90>
    15e8:      	tbz	w9, #0x7, 0x136c <_llm_rows.packet_batch.blocks+0xcd4>
    15ec:      	b	0x1634 <_llm_rows.packet_batch.blocks+0xf9c>
    15f0:      	fmov	x21, d19
    15f4:      	ld1.b	{ v17 }[2], [x21]
    15f8:      	tbz	w9, #0x3, 0x15d4 <_llm_rows.packet_batch.blocks+0xf3c>
    15fc:      	mov.d	x21, v19[1]
    1600:      	ld1.b	{ v17 }[3], [x21]
    1604:      	add.2d	v19, v5, v18
    1608:      	tbz	w9, #0x4, 0x15dc <_llm_rows.packet_batch.blocks+0xf44>
    160c:      	fmov	x21, d19
    1610:      	ld1.b	{ v17 }[4], [x21]
    1614:      	tbz	w9, #0x5, 0x15e0 <_llm_rows.packet_batch.blocks+0xf48>
    1618:      	mov.d	x21, v19[1]
    161c:      	ld1.b	{ v17 }[5], [x21]
    1620:      	add.2d	v18, v6, v18
    1624:      	tbz	w9, #0x6, 0x15e8 <_llm_rows.packet_batch.blocks+0xf50>
    1628:      	fmov	x21, d18
    162c:      	ld1.b	{ v17 }[6], [x21]
    1630:      	tbz	w9, #0x7, 0x136c <_llm_rows.packet_batch.blocks+0xcd4>
    1634:      	mov.d	x9, v18[1]
    1638:      	ld1.b	{ v17 }[7], [x9]
    163c:      	b	0x136c <_llm_rows.packet_batch.blocks+0xcd4>
    1640:      	ldr	q3, [x23, #0x500]
    1644:      	ldr	q4, [x23, #0x510]
    1648:      	ldr	q6, [x23, #0x520]
    164c:      	ldr	q16, [x23, #0x530]
    1650:      	ldr	q17, [x23, #0x540]
    1654:      	ldr	q18, [x23, #0x550]
    1658:      	ldr	q22, [x23, #0x560]
    165c:      	and.16b	v5, v0, v4
    1660:      	and.16b	v4, v1, v3
    1664:      	ldr	q3, [x23, #0x570]
    1668:      	and.16b	v20, v0, v16
    166c:      	and.16b	v19, v1, v6
    1670:      	and.16b	v6, v0, v18
    1674:      	and.16b	v21, v1, v17
    1678:      	and.16b	v18, v0, v3
    167c:      	and.16b	v17, v1, v22
    1680:      	ldr	x8, [sp, #0x20]
    1684:      	mov	w9, #0x4                ; =4
    1688:      	ldp	q16, q3, [x8, #-0x60]
    168c:      	fadd.4s	v16, v4, v16
    1690:      	fadd.4s	v3, v5, v3
    1694:      	ldp	q23, q22, [x8, #-0x40]
    1698:      	fadd.4s	v23, v19, v23
    169c:      	fadd.4s	v22, v20, v22
    16a0:      	ldp	q25, q24, [x8, #-0x20]
    16a4:      	fadd.4s	v25, v21, v25
    16a8:      	fadd.4s	v24, v6, v24
    16ac:      	ldp	q27, q26, [x8], #0x80
    16b0:      	fadd.4s	v27, v17, v27
    16b4:      	fadd.4s	v26, v18, v26
    16b8:      	bit.16b	v5, v3, v0
    16bc:      	bit.16b	v4, v16, v1
    16c0:      	bit.16b	v20, v22, v0
    16c4:      	bit.16b	v19, v23, v1
    16c8:      	bit.16b	v6, v24, v0
    16cc:      	bit.16b	v21, v25, v1
    16d0:      	bit.16b	v18, v26, v0
    16d4:      	bit.16b	v17, v27, v1
    16d8:      	cmp	x9, #0x5c
    16dc:      	add	x9, x9, #0x4
    16e0:      	b.lo	0x1688 <_llm_rows.packet_batch.blocks+0xff0>
    16e4:      	mov	x8, #0x0                ; =0
    16e8:      	adrp	x9, 0x1000 <_llm_rows.packet_batch.blocks+0x968>
    16ec:      	ldr	q3, [x9]
    16f0:      	and.16b	v16, v0, v3
    16f4:      	adrp	x9, 0x1000 <_llm_rows.packet_batch.blocks+0x968>
    16f8:      	ldr	q3, [x9]
    16fc:      	and.16b	v22, v1, v3
    1700:      	adrp	x9, 0x1000 <_llm_rows.packet_batch.blocks+0x968>
    1704:      	ldr	q3, [x9]
    1708:      	and.16b	v3, v1, v3
    170c:      	fadd.4s	v5, v5, v20
    1710:      	fadd.4s	v4, v4, v19
    1714:      	fadd.4s	v19, v4, v21
    1718:      	fadd.4s	v4, v5, v6
    171c:      	fadd.4s	v4, v4, v18
    1720:      	fadd.4s	v5, v19, v17
    1724:      	fmov	w9, s22
    1728:      	add	x21, sp, #0xc8
    172c:      	bfxil	x21, x9, #0, #3
    1730:      	str	d7, [sp, #0xc8]
    1734:      	ldrb	w21, [x21]
    1738:      	add	x24, sp, #0x2f0
    173c:      	orr	x9, x24, x9, lsl #2
    1740:      	stp	q5, q4, [x23, #0x1a0]
    1744:      	ldr	s6, [x9]
    1748:      	tst	w3, w21
    174c:      	fcsel	s6, s6, s9, ne
    1750:      	mov.s	w9, v22[1]
    1754:      	add	x21, sp, #0xc8
    1758:      	bfxil	x21, x9, #0, #3
    175c:      	ldrb	w9, [x21]
    1760:      	and	w9, w12, w9
    1764:      	str	q5, [x23, #0x180]
    1768:      	ldr	s7, [x23, #0x180]
    176c:      	tst	w9, #0x1
    1770:      	fcsel	s7, s7, s9, ne
    1774:      	mov.s	w9, v22[2]
    1778:      	add	x21, sp, #0xc8
    177c:      	bfxil	x21, x9, #0, #3
    1780:      	add	x24, sp, #0x2b0
    1784:      	orr	x9, x24, x9, lsl #2
    1788:      	ldrb	w21, [x21]
    178c:      	and	w21, w13, w21
    1790:      	stp	q5, q4, [x23, #0x160]
    1794:      	ldr	s17, [x9]
    1798:      	tst	w21, #0x1
    179c:      	fcsel	s17, s17, s9, ne
    17a0:      	mov.s	w9, v22[3]
    17a4:      	add	x21, sp, #0xc8
    17a8:      	bfxil	x21, x9, #0, #3
    17ac:      	add	x24, sp, #0x290
    17b0:      	orr	x9, x24, x9, lsl #2
    17b4:      	ldrb	w21, [x21]
    17b8:      	and	w21, w14, w21
    17bc:      	stp	q5, q4, [x23, #0x140]
    17c0:      	ldr	s18, [x9]
    17c4:      	tst	w21, #0x1
    17c8:      	fcsel	s18, s18, s9, ne
    17cc:      	fmov	w9, s16
    17d0:      	add	x21, sp, #0xc8
    17d4:      	bfxil	x21, x9, #0, #3
    17d8:      	ldrb	w21, [x21]
    17dc:      	and	w21, w15, w21
    17e0:      	stp	q5, q4, [x23, #0x120]
    17e4:      	add	x24, sp, #0x270
    17e8:      	ldr	s19, [x24, w9, uxtw #2]
    17ec:      	tst	w21, #0x1
    17f0:      	mov.s	w9, v16[1]
    17f4:      	fcsel	s19, s19, s9, ne
    17f8:      	add	x21, sp, #0xc8
    17fc:      	bfxil	x21, x9, #0, #3
    1800:      	ldrb	w21, [x21]
    1804:      	and	w21, w16, w21
    1808:      	stp	q5, q4, [x23, #0x100]
    180c:      	add	x24, sp, #0x250
    1810:      	ldr	s20, [x24, w9, uxtw #2]
    1814:      	tst	w21, #0x1
    1818:      	mov.s	w9, v16[2]
    181c:      	fcsel	s20, s20, s9, ne
    1820:      	add	x21, sp, #0xc8
    1824:      	bfxil	x21, x9, #0, #3
    1828:      	ldrb	w21, [x21]
    182c:      	and	w21, w17, w21
    1830:      	stp	q5, q4, [x23, #0xe0]
    1834:      	add	x24, sp, #0x230
    1838:      	ldr	s21, [x24, w9, uxtw #2]
    183c:      	tst	w21, #0x1
    1840:      	mov.s	w9, v16[3]
    1844:      	fcsel	s16, s21, s9, ne
    1848:      	add	x21, sp, #0xc8
    184c:      	bfxil	x21, x9, #0, #3
    1850:      	ldrb	w21, [x21]
    1854:      	and	w21, w0, w21
    1858:      	stp	q5, q4, [x23, #0xc0]
    185c:      	add	x24, sp, #0x210
    1860:      	ldr	s21, [x24, w9, uxtw #2]
    1864:      	tst	w21, #0x1
    1868:      	mov.s	v6[1], v7[0]
    186c:      	mov.s	v6[2], v17[0]
    1870:      	mov.s	v6[3], v18[0]
    1874:      	mov.s	v19[1], v20[0]
    1878:      	fcsel	s7, s21, s9, ne
    187c:      	mov.s	v19[2], v16[0]
    1880:      	mov.s	v19[3], v7[0]
    1884:      	fadd.4s	v4, v4, v19
    1888:      	fadd.4s	v5, v5, v6
    188c:      	fmov	w9, s3
    1890:      	add	x21, sp, #0xc8
    1894:      	bfxil	x21, x9, #0, #3
    1898:      	ldrb	w21, [x21]
    189c:      	add	x24, sp, #0x1f0
    18a0:      	orr	x9, x24, x9, lsl #2
    18a4:      	stp	q5, q4, [x23, #0xa0]
    18a8:      	ldr	s6, [x9]
    18ac:      	tst	w3, w21
    18b0:      	mov.s	w9, v3[1]
    18b4:      	add	x21, sp, #0xc8
    18b8:      	bfxil	x21, x9, #0, #3
    18bc:      	ldrb	w21, [x21]
    18c0:      	and	w12, w12, w21
    18c4:      	fcsel	s6, s6, s9, ne
    18c8:      	add	x21, sp, #0x1d0
    18cc:      	orr	x9, x21, x9, lsl #2
    18d0:      	stp	q5, q4, [x23, #0x80]
    18d4:      	ldr	s7, [x9]
    18d8:      	tst	w12, #0x1
    18dc:      	mov.s	w9, v3[2]
    18e0:      	add	x12, sp, #0xc8
    18e4:      	bfxil	x12, x9, #0, #3
    18e8:      	adrp	x9, 0x1000 <_llm_rows.packet_batch.blocks+0x968>
    18ec:      	ldr	q16, [x9]
    18f0:      	and.16b	v17, v0, v16
    18f4:      	fcsel	s7, s7, s9, ne
    18f8:      	ldrb	w9, [x12]
    18fc:      	and	w9, w13, w9
    1900:      	str	q5, [x23, #0x60]
    1904:      	ldr	s16, [x23, #0x60]
    1908:      	tst	w9, #0x1
    190c:      	mov.s	w9, v3[3]
    1910:      	fcsel	s3, s16, s9, ne
    1914:      	add	x12, sp, #0xc8
    1918:      	bfxil	x12, x9, #0, #3
    191c:      	add	x13, sp, #0x190
    1920:      	orr	x9, x13, x9, lsl #2
    1924:      	ldrb	w12, [x12]
    1928:      	and	w12, w14, w12
    192c:      	stp	q5, q4, [x23, #0x40]
    1930:      	ldr	s16, [x9]
    1934:      	tst	w12, #0x1
    1938:      	fcsel	s16, s16, s9, ne
    193c:      	fmov	w9, s17
    1940:      	add	x12, sp, #0xc8
    1944:      	bfxil	x12, x9, #0, #3
    1948:      	ldrb	w12, [x12]
    194c:      	and	w12, w15, w12
    1950:      	stp	q5, q4, [x23, #0x20]
    1954:      	add	x13, sp, #0x170
    1958:      	ldr	s18, [x13, w9, uxtw #2]
    195c:      	tst	w12, #0x1
    1960:      	fcsel	s18, s18, s9, ne
    1964:      	mov.s	w9, v17[1]
    1968:      	add	x12, sp, #0xc8
    196c:      	bfxil	x12, x9, #0, #3
    1970:      	ldrb	w12, [x12]
    1974:      	and	w12, w16, w12
    1978:      	stp	q5, q4, [x23]
    197c:      	ldr	s19, [x23, w9, uxtw #2]
    1980:      	tst	w12, #0x1
    1984:      	fcsel	s19, s19, s9, ne
    1988:      	mov.s	w9, v17[2]
    198c:      	add	x12, sp, #0xc8
    1990:      	bfxil	x12, x9, #0, #3
    1994:      	ldrb	w12, [x12]
    1998:      	and	w12, w17, w12
    199c:      	stp	q5, q4, [sp, #0x130]
    19a0:      	add	x13, sp, #0x130
    19a4:      	ldr	s20, [x13, w9, uxtw #2]
    19a8:      	tst	w12, #0x1
    19ac:      	fcsel	s20, s20, s9, ne
    19b0:      	mov.s	w9, v17[3]
    19b4:      	add	x12, sp, #0xc8
    19b8:      	bfxil	x12, x9, #0, #3
    19bc:      	ldrb	w12, [x12]
    19c0:      	and	w12, w0, w12
    19c4:      	stp	q5, q4, [sp, #0x110]
    19c8:      	add	x13, sp, #0x110
    19cc:      	ldr	s17, [x13, w9, uxtw #2]
    19d0:      	tst	w12, #0x1
    19d4:      	fcsel	s17, s17, s9, ne
    19d8:      	mov.s	v18[1], v19[0]
    19dc:      	mov.s	v18[2], v20[0]
    19e0:      	mov.s	v18[3], v17[0]
    19e4:      	mov.s	v6[1], v7[0]
    19e8:      	movi.4s	v7, #0x4
    19ec:      	and.16b	v7, v1, v7
    19f0:      	mov.s	v6[2], v3[0]
    19f4:      	mov.s	v6[3], v16[0]
    19f8:      	fadd.4s	v3, v5, v6
    19fc:      	fadd.4s	v4, v4, v18
    1a00:      	fmov	w9, s7
    1a04:      	add	x12, sp, #0xc8
    1a08:      	orr	x12, x12, x9
    1a0c:      	ldrb	w12, [x12]
    1a10:      	stp	q3, q4, [sp, #0xf0]
    1a14:      	add	x13, sp, #0xf0
    1a18:      	ldr	s4, [x13, w9, uxtw #2]
    1a1c:      	tst	w3, w12
    1a20:      	fcsel	s4, s4, s9, ne
    1a24:      	tst	w11, #0x1
    1a28:      	fadd	s3, s3, s4
    1a2c:      	fcsel	s4, s3, s9, ne
    1a30:      	tst	w1, #0x1
    1a34:      	fcsel	s5, s3, s9, ne
    1a38:      	tst	w2, #0x1
    1a3c:      	fcsel	s6, s3, s9, ne
    1a40:      	tst	w4, #0x1
    1a44:      	fcsel	s7, s3, s9, ne
    1a48:      	tst	w5, #0x1
    1a4c:      	fcsel	s16, s3, s9, ne
    1a50:      	tst	w6, #0x1
    1a54:      	fcsel	s17, s3, s9, ne
    1a58:      	tst	w7, #0x1
    1a5c:      	fcsel	s18, s3, s9, ne
    1a60:      	tst	w30, #0x1
    1a64:      	mov.s	v4[1], v5[0]
    1a68:      	mov.s	v4[2], v6[0]
    1a6c:      	mov.s	v4[3], v7[0]
    1a70:      	mov.s	v16[1], v17[0]
    1a74:      	mov.s	v16[2], v18[0]
    1a78:      	fcsel	s3, s3, s9, ne
    1a7c:      	mov.s	v16[3], v3[0]
    1a80:      	stp	q4, q16, [sp, #0xd0]
    1a84:      	and	x9, x10, #0x7
    1a88:      	add	x10, sp, #0xd0
    1a8c:      	ldr	s3, [x10, x9, lsl #2]
    1a90:      	fadd	s3, s3, s9
    1a94:      	ldp	x10, x9, [sp, #0x48]
    1a98:      	add	x9, x9, x10
    1a9c:      	dup.4s	v3, v3[0]
    1aa0:      	adrp	x15, 0x1000 <_llm_rows.packet_batch.blocks+0x968>
    1aa4:      	adrp	x16, 0x1000 <_llm_rows.packet_batch.blocks+0x968>
    1aa8:      	ldr	w17, [sp, #0x58]
    1aac:      	b	0x1abc <_llm_rows.packet_batch.blocks+0x1424>
    1ab0:      	add	x8, x8, #0x20
    1ab4:      	cmp	x8, #0xc00
    1ab8:      	b.eq	0x784 <_llm_rows.packet_batch.blocks+0xec>
    1abc:      	fmov	w11, s2
    1ac0:      	add	x10, x26, x8
    1ac4:      	ldp	q5, q4, [x10]
    1ac8:      	and.16b	v5, v1, v5
    1acc:      	fdiv.4s	v5, v5, v3
    1ad0:      	add	x10, x9, x8
    1ad4:      	tbnz	w11, #0x0, 0x1b04 <_llm_rows.packet_batch.blocks+0x146c>
    1ad8:      	and	w11, w11, #0xff
    1adc:      	tbnz	w11, #0x1, 0x1b10 <_llm_rows.packet_batch.blocks+0x1478>
    1ae0:      	tbnz	w11, #0x2, 0x1b1c <_llm_rows.packet_batch.blocks+0x1484>
    1ae4:      	tbnz	w11, #0x3, 0x1b28 <_llm_rows.packet_batch.blocks+0x1490>
    1ae8:      	and.16b	v4, v0, v4
    1aec:      	fdiv.4s	v4, v4, v3
    1af0:      	tbnz	w11, #0x4, 0x1b3c <_llm_rows.packet_batch.blocks+0x14a4>
    1af4:      	tbnz	w11, #0x5, 0x1b44 <_llm_rows.packet_batch.blocks+0x14ac>
    1af8:      	tbnz	w11, #0x6, 0x1b50 <_llm_rows.packet_batch.blocks+0x14b8>
    1afc:      	tbz	w11, #0x7, 0x1ab0 <_llm_rows.packet_batch.blocks+0x1418>
    1b00:      	b	0x1b5c <_llm_rows.packet_batch.blocks+0x14c4>
    1b04:      	str	s5, [x10]
    1b08:      	and	w11, w11, #0xff
    1b0c:      	tbz	w11, #0x1, 0x1ae0 <_llm_rows.packet_batch.blocks+0x1448>
    1b10:      	add	x12, x10, #0x4
    1b14:      	st1.s	{ v5 }[1], [x12]
    1b18:      	tbz	w11, #0x2, 0x1ae4 <_llm_rows.packet_batch.blocks+0x144c>
    1b1c:      	add	x12, x10, #0x8
    1b20:      	st1.s	{ v5 }[2], [x12]
    1b24:      	tbz	w11, #0x3, 0x1ae8 <_llm_rows.packet_batch.blocks+0x1450>
    1b28:      	add	x12, x10, #0xc
    1b2c:      	st1.s	{ v5 }[3], [x12]
    1b30:      	and.16b	v4, v0, v4
    1b34:      	fdiv.4s	v4, v4, v3
    1b38:      	tbz	w11, #0x4, 0x1af4 <_llm_rows.packet_batch.blocks+0x145c>
    1b3c:      	str	s4, [x10, #0x10]
    1b40:      	tbz	w11, #0x5, 0x1af8 <_llm_rows.packet_batch.blocks+0x1460>
    1b44:      	add	x12, x10, #0x14
    1b48:      	st1.s	{ v4 }[1], [x12]
    1b4c:      	tbz	w11, #0x6, 0x1afc <_llm_rows.packet_batch.blocks+0x1464>
    1b50:      	add	x12, x10, #0x18
    1b54:      	st1.s	{ v4 }[2], [x12]
    1b58:      	tbz	w11, #0x7, 0x1ab0 <_llm_rows.packet_batch.blocks+0x1418>
    1b5c:      	add	x10, x10, #0x1c
    1b60:      	st1.s	{ v4 }[3], [x10]
    1b64:      	b	0x1ab0 <_llm_rows.packet_batch.blocks+0x1418>
    1b68:      	add	sp, sp, #0x4, lsl #12   ; =0x4000
    1b6c:      	add	sp, sp, #0x550
    1b70:      	ldp	x29, x30, [sp, #0x90]
    1b74:      	ldp	x20, x19, [sp, #0x80]
    1b78:      	ldp	x22, x21, [sp, #0x70]
    1b7c:      	ldp	x24, x23, [sp, #0x60]
    1b80:      	ldp	x26, x25, [sp, #0x50]
    1b84:      	ldp	x28, x27, [sp, #0x40]
    1b88:      	ldp	d9, d8, [sp, #0x30]
    1b8c:      	ldp	d11, d10, [sp, #0x20]
    1b90:      	ldp	d13, d12, [sp, #0x10]
    1b94:      	ldp	d15, d14, [sp], #0xa0
    1b98:      	ret

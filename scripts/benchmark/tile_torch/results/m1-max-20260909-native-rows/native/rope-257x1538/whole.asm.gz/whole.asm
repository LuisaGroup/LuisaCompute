
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/rope-257x1538-l1/object/tile_xir_w8_80789_1788919122638208_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	mov	x12, #0x0               ; =0
       4:      	ldr	x8, [x1, #0x88]
       8:      	ldr	x13, [x0]
       c:      	ldr	x11, [x0, #0x10]
      10:      	ldr	w9, [x1]
      14:      	ldr	w10, [x1, #0x24]
      18:      	add	w14, w10, w9, lsl #5
      1c:      	ldr	x10, [x0, #0x20]
      20:      	ldr	x9, [x0, #0x30]
      24:      	dup.4s	v0, w14
      28:      	adrp	x14, 0x0 <ltmp0>
      2c:      	ldr	q1, [x14]
      30:      	add.4s	v3, v0, v1
      34:      	adrp	x14, 0x0 <ltmp0>
      38:      	ldr	q1, [x14]
      3c:      	add.4s	v2, v0, v1
      40:      	ushll2.2d	v4, v2, #0x0
      44:      	ushll2.2d	v5, v3, #0x0
      48:      	ushll.2d	v6, v2, #0x0
      4c:      	ushll.2d	v7, v3, #0x0
      50:      	mov	w14, #0x602             ; =1538
      54:      	dup.4s	v16, w14
      58:      	umull2.2d	v0, v2, v16
      5c:      	umull2.2d	v1, v3, v16
      60:      	umull.2d	v2, v2, v16
      64:      	umull.2d	v3, v3, v16
      68:      	dup.2d	v16, x13
      6c:      	dup.2d	v17, x12
      70:      	add.2d	v18, v17, v0
      74:      	add.2d	v19, v17, v2
      78:      	add.2d	v20, v17, v1
      7c:      	add.2d	v17, v17, v3
      80:      	shl.2d	v17, v17, #0x2
      84:      	shl.2d	v20, v20, #0x2
      88:      	shl.2d	v19, v19, #0x2
      8c:      	shl.2d	v18, v18, #0x2
      90:      	add.2d	v18, v16, v18
      94:      	add.2d	v19, v16, v19
      98:      	add.2d	v20, v16, v20
      9c:      	add.2d	v17, v16, v17
      a0:      	mov.d	x13, v17[1]
      a4:      	fmov	x14, d17
      a8:      	mov.d	x15, v20[1]
      ac:      	fmov	x16, d20
      b0:      	mov.d	x17, v19[1]
      b4:      	fmov	x0, d19
      b8:      	mov.d	x1, v18[1]
      bc:      	ldr	s17, [x14]
      c0:      	ld1.s	{ v17 }[1], [x13]
      c4:      	fmov	x13, d18
      c8:      	ld1.s	{ v17 }[2], [x16]
      cc:      	ld1.s	{ v17 }[3], [x15]
      d0:      	ldr	s18, [x0]
      d4:      	ld1.s	{ v18 }[1], [x17]
      d8:      	ld1.s	{ v18 }[2], [x13]
      dc:      	ld1.s	{ v18 }[3], [x1]
      e0:      	add	x13, x8, x12, lsl #5
      e4:      	stp	q17, q18, [x13]
      e8:      	add	x12, x12, #0x1
      ec:      	cmp	x12, #0x301
      f0:      	b.ne	0x6c <ltmp0+0x6c>
      f4:      	dup.2d	v17, x12
      f8:      	add.2d	v18, v17, v0
      fc:      	add.2d	v19, v17, v2
     100:      	add.2d	v20, v17, v1
     104:      	add.2d	v17, v17, v3
     108:      	shl.2d	v17, v17, #0x2
     10c:      	shl.2d	v20, v20, #0x2
     110:      	shl.2d	v19, v19, #0x2
     114:      	shl.2d	v18, v18, #0x2
     118:      	add.2d	v18, v16, v18
     11c:      	add.2d	v19, v16, v19
     120:      	add.2d	v20, v16, v20
     124:      	add.2d	v17, v16, v17
     128:      	mov.d	x13, v17[1]
     12c:      	fmov	x14, d17
     130:      	mov.d	x15, v20[1]
     134:      	fmov	x16, d20
     138:      	mov.d	x17, v19[1]
     13c:      	fmov	x0, d19
     140:      	mov.d	x1, v18[1]
     144:      	ldr	s17, [x14]
     148:      	ld1.s	{ v17 }[1], [x13]
     14c:      	fmov	x13, d18
     150:      	ld1.s	{ v17 }[2], [x16]
     154:      	ld1.s	{ v17 }[3], [x15]
     158:      	ldr	s18, [x0]
     15c:      	ld1.s	{ v18 }[1], [x17]
     160:      	ld1.s	{ v18 }[2], [x13]
     164:      	ld1.s	{ v18 }[3], [x1]
     168:      	add	x13, x8, x12, lsl #5
     16c:      	stp	q17, q18, [x13]
     170:      	add	x12, x12, #0x1
     174:      	cmp	x12, #0x602
     178:      	b.ne	0xf4 <ltmp0+0xf4>
     17c:      	mov	x12, #0x0               ; =0
     180:      	mov	w13, #0xc040            ; =49216
     184:      	add	x13, x8, x13
     188:      	mov	w14, #0x301             ; =769
     18c:      	dup.2s	v16, w14
     190:      	xtn.2s	v7, v7
     194:      	umull.2d	v7, v7, v16
     198:      	xtn.2s	v5, v5
     19c:      	umull.2d	v5, v5, v16
     1a0:      	xtn.2s	v6, v6
     1a4:      	umull.2d	v6, v6, v16
     1a8:      	xtn.2s	v4, v4
     1ac:      	umull.2d	v4, v4, v16
     1b0:      	dup.2d	v16, x11
     1b4:      	dup.2d	v17, x12
     1b8:      	add.2d	v18, v17, v4
     1bc:      	add.2d	v19, v17, v6
     1c0:      	add.2d	v20, v17, v5
     1c4:      	add.2d	v17, v17, v7
     1c8:      	shl.2d	v17, v17, #0x2
     1cc:      	shl.2d	v20, v20, #0x2
     1d0:      	shl.2d	v19, v19, #0x2
     1d4:      	shl.2d	v18, v18, #0x2
     1d8:      	add.2d	v18, v16, v18
     1dc:      	add.2d	v19, v16, v19
     1e0:      	add.2d	v20, v16, v20
     1e4:      	add.2d	v17, v16, v17
     1e8:      	mov.d	x11, v17[1]
     1ec:      	fmov	x14, d17
     1f0:      	mov.d	x15, v20[1]
     1f4:      	fmov	x16, d20
     1f8:      	mov.d	x17, v19[1]
     1fc:      	fmov	x0, d19
     200:      	mov.d	x1, v18[1]
     204:      	ldr	s17, [x14]
     208:      	ld1.s	{ v17 }[1], [x11]
     20c:      	fmov	x11, d18
     210:      	ld1.s	{ v17 }[2], [x16]
     214:      	ld1.s	{ v17 }[3], [x15]
     218:      	ldr	s18, [x0]
     21c:      	ld1.s	{ v18 }[1], [x17]
     220:      	ld1.s	{ v18 }[2], [x11]
     224:      	ld1.s	{ v18 }[3], [x1]
     228:      	add	x11, x13, x12, lsl #5
     22c:      	stp	q17, q18, [x11]
     230:      	add	x12, x12, #0x1
     234:      	cmp	x12, #0x301
     238:      	b.ne	0x1b4 <ltmp0+0x1b4>
     23c:      	mov	x11, #0x0               ; =0
     240:      	add	x12, x8, #0x12, lsl #12 ; =0x12000
     244:      	add	x12, x12, #0x60
     248:      	dup.2d	v16, x10
     24c:      	dup.2d	v17, x11
     250:      	add.2d	v18, v17, v4
     254:      	add.2d	v19, v17, v6
     258:      	add.2d	v20, v17, v5
     25c:      	add.2d	v17, v17, v7
     260:      	shl.2d	v17, v17, #0x2
     264:      	shl.2d	v20, v20, #0x2
     268:      	shl.2d	v19, v19, #0x2
     26c:      	shl.2d	v18, v18, #0x2
     270:      	add.2d	v18, v16, v18
     274:      	add.2d	v19, v16, v19
     278:      	add.2d	v20, v16, v20
     27c:      	add.2d	v17, v16, v17
     280:      	mov.d	x10, v17[1]
     284:      	fmov	x13, d17
     288:      	mov.d	x14, v20[1]
     28c:      	fmov	x15, d20
     290:      	mov.d	x16, v19[1]
     294:      	fmov	x17, d19
     298:      	mov.d	x0, v18[1]
     29c:      	ldr	s17, [x13]
     2a0:      	ld1.s	{ v17 }[1], [x10]
     2a4:      	fmov	x10, d18
     2a8:      	ld1.s	{ v17 }[2], [x15]
     2ac:      	ld1.s	{ v17 }[3], [x14]
     2b0:      	ldr	s18, [x17]
     2b4:      	ld1.s	{ v18 }[1], [x16]
     2b8:      	ld1.s	{ v18 }[2], [x10]
     2bc:      	ld1.s	{ v18 }[3], [x0]
     2c0:      	add	x10, x12, x11, lsl #5
     2c4:      	stp	q17, q18, [x10]
     2c8:      	add	x11, x11, #0x1
     2cc:      	cmp	x11, #0x301
     2d0:      	b.ne	0x24c <ltmp0+0x24c>
     2d4:      	mov	x10, #0x0               ; =0
     2d8:      	mov	w11, #0x2060            ; =8288
     2dc:      	movk	w11, #0x1, lsl #16
     2e0:      	dup.2d	v4, x9
     2e4:      	mov	x9, x8
     2e8:      	dup.2d	v5, x10
     2ec:      	add.2d	v6, v5, v0
     2f0:      	add.2d	v7, v5, v2
     2f4:      	add.2d	v16, v5, v1
     2f8:      	add.2d	v5, v5, v3
     2fc:      	ldp	q18, q17, [x9]
     300:      	ldr	q19, [x9, #0xc050]
     304:      	ldr	q20, [x9, #0xc040]
     308:      	fmul.4s	v18, v18, v20
     30c:      	fmul.4s	v17, v17, v19
     310:      	ldr	q19, [x9, #0x6030]
     314:      	ldr	q20, [x9, #0x6020]
     318:      	add	x12, x9, x11
     31c:      	ldp	q22, q21, [x12]
     320:      	fmul.4s	v20, v20, v22
     324:      	fmul.4s	v19, v19, v21
     328:      	fsub.4s	v17, v17, v19
     32c:      	fsub.4s	v18, v18, v20
     330:      	shl.2d	v5, v5, #0x2
     334:      	shl.2d	v16, v16, #0x2
     338:      	shl.2d	v7, v7, #0x2
     33c:      	shl.2d	v6, v6, #0x2
     340:      	add.2d	v16, v4, v16
     344:      	add.2d	v5, v4, v5
     348:      	mov.d	x12, v5[1]
     34c:      	fmov	x13, d5
     350:      	str	s18, [x13]
     354:      	st1.s	{ v18 }[1], [x12]
     358:      	mov.d	x12, v16[1]
     35c:      	add.2d	v5, v4, v7
     360:      	fmov	x13, d16
     364:      	st1.s	{ v18 }[2], [x13]
     368:      	st1.s	{ v18 }[3], [x12]
     36c:      	mov.d	x12, v5[1]
     370:      	fmov	x13, d5
     374:      	str	s17, [x13]
     378:      	st1.s	{ v17 }[1], [x12]
     37c:      	add.2d	v5, v4, v6
     380:      	mov.d	x12, v5[1]
     384:      	fmov	x13, d5
     388:      	st1.s	{ v17 }[2], [x13]
     38c:      	st1.s	{ v17 }[3], [x12]
     390:      	add	x10, x10, #0x1
     394:      	add	x9, x9, #0x20
     398:      	cmp	x10, #0x301
     39c:      	b.ne	0x2e8 <ltmp0+0x2e8>
     3a0:      	mov	w9, #0x301              ; =769
     3a4:      	mov	w10, #0x2060            ; =8288
     3a8:      	movk	w10, #0x1, lsl #16
     3ac:      	dup.2d	v5, x9
     3b0:      	add.2d	v6, v5, v0
     3b4:      	add.2d	v7, v5, v2
     3b8:      	add.2d	v16, v5, v1
     3bc:      	add.2d	v5, v5, v3
     3c0:      	ldp	q18, q17, [x8]
     3c4:      	add	x11, x8, x10
     3c8:      	ldp	q20, q19, [x11]
     3cc:      	fmul.4s	v18, v18, v20
     3d0:      	fmul.4s	v17, v17, v19
     3d4:      	ldr	q19, [x8, #0x6030]
     3d8:      	ldr	q20, [x8, #0x6020]
     3dc:      	ldr	q21, [x8, #0xc050]
     3e0:      	ldr	q22, [x8, #0xc040]
     3e4:      	fmul.4s	v20, v20, v22
     3e8:      	fmul.4s	v19, v19, v21
     3ec:      	fadd.4s	v17, v17, v19
     3f0:      	fadd.4s	v18, v18, v20
     3f4:      	shl.2d	v5, v5, #0x2
     3f8:      	shl.2d	v16, v16, #0x2
     3fc:      	shl.2d	v7, v7, #0x2
     400:      	shl.2d	v6, v6, #0x2
     404:      	add.2d	v16, v4, v16
     408:      	add.2d	v5, v4, v5
     40c:      	mov.d	x11, v5[1]
     410:      	fmov	x12, d5
     414:      	str	s18, [x12]
     418:      	st1.s	{ v18 }[1], [x11]
     41c:      	mov.d	x11, v16[1]
     420:      	add.2d	v5, v4, v7
     424:      	fmov	x12, d16
     428:      	st1.s	{ v18 }[2], [x12]
     42c:      	st1.s	{ v18 }[3], [x11]
     430:      	mov.d	x11, v5[1]
     434:      	fmov	x12, d5
     438:      	str	s17, [x12]
     43c:      	st1.s	{ v17 }[1], [x11]
     440:      	add.2d	v5, v4, v6
     444:      	mov.d	x11, v5[1]
     448:      	fmov	x12, d5
     44c:      	st1.s	{ v17 }[2], [x12]
     450:      	st1.s	{ v17 }[3], [x11]
     454:      	add	x9, x9, #0x1
     458:      	add	x8, x8, #0x20
     45c:      	cmp	x9, #0x602
     460:      	b.ne	0x3ac <ltmp0+0x3ac>
     464:      	ret

0000000000000468 <_llm_rows.packet_batch.blocks>:
     468:      	cbz	w3, 0xdac <_llm_rows.packet_batch.blocks+0x944>
     46c:      	sub	sp, sp, #0xc0
     470:      	stp	x28, x27, [sp, #0x60]
     474:      	stp	x26, x25, [sp, #0x70]
     478:      	stp	x24, x23, [sp, #0x80]
     47c:      	stp	x22, x21, [sp, #0x90]
     480:      	stp	x20, x19, [sp, #0xa0]
     484:      	stp	x29, x30, [sp, #0xb0]
     488:      	mov	x24, x3
     48c:      	mov	x20, x2
     490:      	mov	x21, x0
     494:      	mov	w22, #0x0               ; =0
     498:      	ldp	w9, w8, [x2, #0x2c]
     49c:      	stp	w8, w9, [sp, #0x50]
     4a0:      	ldp	w25, w26, [x2]
     4a4:      	mov	w27, #0x2060            ; =8288
     4a8:      	movk	w27, #0x1, lsl #16
     4ac:      	adrp	x8, 0x0 <ltmp0>
     4b0:      	ldr	q0, [x8]
     4b4:      	str	q0, [sp, #0x40]
     4b8:      	mov	w8, #0x602              ; =1538
     4bc:      	dup.4s	v0, w8
     4c0:      	str	q0, [sp, #0x10]
     4c4:      	adrp	x8, 0x0 <ltmp0>
     4c8:      	ldr	q0, [x8]
     4cc:      	str	q0, [sp, #0x30]
     4d0:      	adrp	x8, 0x0 <ltmp0>
     4d4:      	ldr	q0, [x8]
     4d8:      	str	q0, [sp]
     4dc:      	ldp	w28, w23, [x2, #0x8]
     4e0:      	str	w3, [sp, #0x2c]
     4e4:      	b	0x52c <_llm_rows.packet_batch.blocks+0xc4>
     4e8:      	mov	w8, #0x18               ; =24
     4ec:      	str	w8, [x20, #0x24]
     4f0:      	ldr	w24, [sp, #0x2c]
     4f4:      	add	w8, w25, #0x1
     4f8:      	ldp	w10, w9, [sp, #0x50]
     4fc:      	cmp	w8, w9
     500:      	cset	w8, eq
     504:      	csinc	w25, wzr, w25, eq
     508:      	cinc	w9, w26, eq
     50c:      	cmp	w9, w10
     510:      	cset	w10, eq
     514:      	ands	w8, w8, w10
     518:      	csel	w26, wzr, w9, ne
     51c:      	add	w28, w28, w8
     520:      	add	w22, w22, #0x1
     524:      	cmp	w22, w24
     528:      	b.eq	0xd90 <_llm_rows.packet_batch.blocks+0x928>
     52c:      	ubfiz	x8, x25, #5, #32
     530:      	cmp	x8, x23
     534:      	csel	x9, x8, xzr, ls
     538:      	subs	x10, x23, x9
     53c:      	cmp	x10, #0x20
     540:      	mov	w11, #0x20              ; =32
     544:      	csel	x10, x10, x11, lo
     548:      	cmp	x23, x9
     54c:      	stp	w25, w26, [x20]
     550:      	str	w28, [x20, #0x8]
     554:      	str	wzr, [x20, #0x24]
     558:      	ccmp	x8, x23, #0x2, hi
     55c:      	csel	x19, x10, xzr, ls
     560:      	cmp	x19, #0x20
     564:      	b.lo	0x5b4 <_llm_rows.packet_batch.blocks+0x14c>
     568:      	mov	x0, x21
     56c:      	mov	x1, x20
     570:      	bl	0x570 <_llm_rows.packet_batch.blocks+0x108>
     574:      	mov	w8, #0x8                ; =8
     578:      	str	w8, [x20, #0x24]
     57c:      	mov	x0, x21
     580:      	mov	x1, x20
     584:      	bl	0x584 <_llm_rows.packet_batch.blocks+0x11c>
     588:      	mov	w8, #0x10               ; =16
     58c:      	str	w8, [x20, #0x24]
     590:      	mov	x0, x21
     594:      	mov	x1, x20
     598:      	bl	0x598 <_llm_rows.packet_batch.blocks+0x130>
     59c:      	mov	w8, #0x18               ; =24
     5a0:      	str	w8, [x20, #0x24]
     5a4:      	mov	x0, x21
     5a8:      	mov	x1, x20
     5ac:      	bl	0x5ac <_llm_rows.packet_batch.blocks+0x144>
     5b0:      	b	0x4f4 <_llm_rows.packet_batch.blocks+0x8c>
     5b4:      	lsr	x24, x19, #3
     5b8:      	cmp	x19, #0x8
     5bc:      	b.lo	0x608 <_llm_rows.packet_batch.blocks+0x1a0>
     5c0:      	str	wzr, [x20, #0x24]
     5c4:      	mov	x0, x21
     5c8:      	mov	x1, x20
     5cc:      	bl	0x5cc <_llm_rows.packet_batch.blocks+0x164>
     5d0:      	cmp	x24, #0x1
     5d4:      	b.eq	0x608 <_llm_rows.packet_batch.blocks+0x1a0>
     5d8:      	mov	w8, #0x8                ; =8
     5dc:      	str	w8, [x20, #0x24]
     5e0:      	mov	x0, x21
     5e4:      	mov	x1, x20
     5e8:      	bl	0x5e8 <_llm_rows.packet_batch.blocks+0x180>
     5ec:      	cmp	x24, #0x2
     5f0:      	b.eq	0x608 <_llm_rows.packet_batch.blocks+0x1a0>
     5f4:      	mov	w8, #0x10               ; =16
     5f8:      	str	w8, [x20, #0x24]
     5fc:      	mov	x0, x21
     600:      	mov	x1, x20
     604:      	bl	0x604 <_llm_rows.packet_batch.blocks+0x19c>
     608:      	and	w8, w19, #0x7
     60c:      	cbz	w8, 0x4e8 <_llm_rows.packet_batch.blocks+0x80>
     610:      	dup.4s	v1, w8
     614:      	ldp	q0, q2, [sp, #0x30]
     618:      	cmhi.4s	v0, v1, v0
     61c:      	cmhi.4s	v1, v1, v2
     620:      	uzp1.8h	v6, v1, v0
     624:      	umaxv.8h	h2, v6
     628:      	fmov	w8, s2
     62c:      	tbz	w8, #0x0, 0x4e8 <_llm_rows.packet_batch.blocks+0x80>
     630:      	mov	x14, #0x0               ; =0
     634:      	ldr	x8, [x20, #0x88]
     638:      	mov	w9, #0xc040             ; =49216
     63c:      	add	x12, x8, x9
     640:      	add	x10, x8, x27
     644:      	ldr	x15, [x21]
     648:      	ldr	x13, [x21, #0x10]
     64c:      	ldr	x11, [x21, #0x20]
     650:      	lsl	w9, w24, #3
     654:      	orr	w9, w9, w25, lsl #5
     658:      	dup.4s	v2, w9
     65c:      	ldr	x9, [x21, #0x30]
     660:      	ldp	q3, q4, [sp, #0x30]
     664:      	orr.16b	v3, v2, v3
     668:      	orr.16b	v2, v2, v4
     66c:      	and.16b	v5, v1, v2
     670:      	and.16b	v4, v0, v3
     674:      	ushll2.2d	v7, v4, #0x0
     678:      	ushll2.2d	v16, v5, #0x0
     67c:      	ushll.2d	v17, v4, #0x0
     680:      	ushll.2d	v18, v5, #0x0
     684:      	ldp	q19, q20, [sp]
     688:      	umull2.2d	v2, v4, v20
     68c:      	umull2.2d	v3, v5, v20
     690:      	umull.2d	v4, v4, v20
     694:      	umull.2d	v5, v5, v20
     698:      	and.16b	v6, v6, v19
     69c:      	addv.8h	h6, v6
     6a0:      	dup.2d	v19, x15
     6a4:      	fmov	w15, s6
     6a8:      	b	0x6cc <_llm_rows.packet_batch.blocks+0x264>
     6ac:      	add	x16, x8, x14, lsl #5
     6b0:      	ldp	q22, q23, [x16]
     6b4:      	bif.16b	v21, v23, v0
     6b8:      	bif.16b	v20, v22, v1
     6bc:      	stp	q20, q21, [x16]
     6c0:      	add	x14, x14, #0x1
     6c4:      	cmp	x14, #0x301
     6c8:      	b.eq	0x7d8 <_llm_rows.packet_batch.blocks+0x370>
     6cc:      	dup.2d	v22, x14
     6d0:      	add.2d	v20, v22, v5
     6d4:      	shl.2d	v20, v20, #0x2
     6d8:      	add.2d	v23, v19, v20
     6dc:      	movi.2d	v20, #0000000000000000
     6e0:      	movi.2d	v21, #0000000000000000
     6e4:      	tbnz	w15, #0x0, 0x730 <_llm_rows.packet_batch.blocks+0x2c8>
     6e8:      	and	w16, w15, #0xff
     6ec:      	tbnz	w16, #0x1, 0x740 <_llm_rows.packet_batch.blocks+0x2d8>
     6f0:      	add.2d	v23, v22, v3
     6f4:      	shl.2d	v23, v23, #0x2
     6f8:      	add.2d	v23, v19, v23
     6fc:      	tbnz	w16, #0x2, 0x758 <_llm_rows.packet_batch.blocks+0x2f0>
     700:      	tbnz	w16, #0x3, 0x764 <_llm_rows.packet_batch.blocks+0x2fc>
     704:      	add.2d	v23, v22, v4
     708:      	shl.2d	v23, v23, #0x2
     70c:      	add.2d	v23, v19, v23
     710:      	tbnz	w16, #0x4, 0x77c <_llm_rows.packet_batch.blocks+0x314>
     714:      	tbnz	w16, #0x5, 0x788 <_llm_rows.packet_batch.blocks+0x320>
     718:      	add.2d	v22, v22, v2
     71c:      	shl.2d	v22, v22, #0x2
     720:      	add.2d	v22, v19, v22
     724:      	tbnz	w16, #0x6, 0x7a0 <_llm_rows.packet_batch.blocks+0x338>
     728:      	tbz	w16, #0x7, 0x6ac <_llm_rows.packet_batch.blocks+0x244>
     72c:      	b	0x7ac <_llm_rows.packet_batch.blocks+0x344>
     730:      	fmov	x16, d23
     734:      	ldr	s20, [x16]
     738:      	and	w16, w15, #0xff
     73c:      	tbz	w16, #0x1, 0x6f0 <_llm_rows.packet_batch.blocks+0x288>
     740:      	mov.d	x17, v23[1]
     744:      	ld1.s	{ v20 }[1], [x17]
     748:      	add.2d	v23, v22, v3
     74c:      	shl.2d	v23, v23, #0x2
     750:      	add.2d	v23, v19, v23
     754:      	tbz	w16, #0x2, 0x700 <_llm_rows.packet_batch.blocks+0x298>
     758:      	fmov	x17, d23
     75c:      	ld1.s	{ v20 }[2], [x17]
     760:      	tbz	w16, #0x3, 0x704 <_llm_rows.packet_batch.blocks+0x29c>
     764:      	mov.d	x17, v23[1]
     768:      	ld1.s	{ v20 }[3], [x17]
     76c:      	add.2d	v23, v22, v4
     770:      	shl.2d	v23, v23, #0x2
     774:      	add.2d	v23, v19, v23
     778:      	tbz	w16, #0x4, 0x714 <_llm_rows.packet_batch.blocks+0x2ac>
     77c:      	fmov	x17, d23
     780:      	ld1.s	{ v21 }[0], [x17]
     784:      	tbz	w16, #0x5, 0x718 <_llm_rows.packet_batch.blocks+0x2b0>
     788:      	mov.d	x17, v23[1]
     78c:      	ld1.s	{ v21 }[1], [x17]
     790:      	add.2d	v22, v22, v2
     794:      	shl.2d	v22, v22, #0x2
     798:      	add.2d	v22, v19, v22
     79c:      	tbz	w16, #0x6, 0x728 <_llm_rows.packet_batch.blocks+0x2c0>
     7a0:      	fmov	x17, d22
     7a4:      	ld1.s	{ v21 }[2], [x17]
     7a8:      	tbz	w16, #0x7, 0x6ac <_llm_rows.packet_batch.blocks+0x244>
     7ac:      	mov.d	x16, v22[1]
     7b0:      	ld1.s	{ v21 }[3], [x16]
     7b4:      	b	0x6ac <_llm_rows.packet_batch.blocks+0x244>
     7b8:      	add	x15, x8, x14, lsl #5
     7bc:      	ldp	q22, q23, [x15]
     7c0:      	bif.16b	v21, v23, v0
     7c4:      	bif.16b	v20, v22, v1
     7c8:      	stp	q20, q21, [x15]
     7cc:      	add	x14, x14, #0x1
     7d0:      	cmp	x14, #0x602
     7d4:      	b.eq	0x8c8 <_llm_rows.packet_batch.blocks+0x460>
     7d8:      	dup.2d	v22, x14
     7dc:      	fmov	w15, s6
     7e0:      	add.2d	v20, v22, v5
     7e4:      	shl.2d	v20, v20, #0x2
     7e8:      	add.2d	v23, v19, v20
     7ec:      	movi.2d	v20, #0000000000000000
     7f0:      	movi.2d	v21, #0000000000000000
     7f4:      	tbnz	w15, #0x0, 0x840 <_llm_rows.packet_batch.blocks+0x3d8>
     7f8:      	and	w15, w15, #0xff
     7fc:      	tbnz	w15, #0x1, 0x850 <_llm_rows.packet_batch.blocks+0x3e8>
     800:      	add.2d	v23, v22, v3
     804:      	shl.2d	v23, v23, #0x2
     808:      	add.2d	v23, v19, v23
     80c:      	tbnz	w15, #0x2, 0x868 <_llm_rows.packet_batch.blocks+0x400>
     810:      	tbnz	w15, #0x3, 0x874 <_llm_rows.packet_batch.blocks+0x40c>
     814:      	add.2d	v23, v22, v4
     818:      	shl.2d	v23, v23, #0x2
     81c:      	add.2d	v23, v19, v23
     820:      	tbnz	w15, #0x4, 0x88c <_llm_rows.packet_batch.blocks+0x424>
     824:      	tbnz	w15, #0x5, 0x898 <_llm_rows.packet_batch.blocks+0x430>
     828:      	add.2d	v22, v22, v2
     82c:      	shl.2d	v22, v22, #0x2
     830:      	add.2d	v22, v19, v22
     834:      	tbnz	w15, #0x6, 0x8b0 <_llm_rows.packet_batch.blocks+0x448>
     838:      	tbz	w15, #0x7, 0x7b8 <_llm_rows.packet_batch.blocks+0x350>
     83c:      	b	0x8bc <_llm_rows.packet_batch.blocks+0x454>
     840:      	fmov	x16, d23
     844:      	ldr	s20, [x16]
     848:      	and	w15, w15, #0xff
     84c:      	tbz	w15, #0x1, 0x800 <_llm_rows.packet_batch.blocks+0x398>
     850:      	mov.d	x16, v23[1]
     854:      	ld1.s	{ v20 }[1], [x16]
     858:      	add.2d	v23, v22, v3
     85c:      	shl.2d	v23, v23, #0x2
     860:      	add.2d	v23, v19, v23
     864:      	tbz	w15, #0x2, 0x810 <_llm_rows.packet_batch.blocks+0x3a8>
     868:      	fmov	x16, d23
     86c:      	ld1.s	{ v20 }[2], [x16]
     870:      	tbz	w15, #0x3, 0x814 <_llm_rows.packet_batch.blocks+0x3ac>
     874:      	mov.d	x16, v23[1]
     878:      	ld1.s	{ v20 }[3], [x16]
     87c:      	add.2d	v23, v22, v4
     880:      	shl.2d	v23, v23, #0x2
     884:      	add.2d	v23, v19, v23
     888:      	tbz	w15, #0x4, 0x824 <_llm_rows.packet_batch.blocks+0x3bc>
     88c:      	fmov	x16, d23
     890:      	ld1.s	{ v21 }[0], [x16]
     894:      	tbz	w15, #0x5, 0x828 <_llm_rows.packet_batch.blocks+0x3c0>
     898:      	mov.d	x16, v23[1]
     89c:      	ld1.s	{ v21 }[1], [x16]
     8a0:      	add.2d	v22, v22, v2
     8a4:      	shl.2d	v22, v22, #0x2
     8a8:      	add.2d	v22, v19, v22
     8ac:      	tbz	w15, #0x6, 0x838 <_llm_rows.packet_batch.blocks+0x3d0>
     8b0:      	fmov	x16, d22
     8b4:      	ld1.s	{ v21 }[2], [x16]
     8b8:      	tbz	w15, #0x7, 0x7b8 <_llm_rows.packet_batch.blocks+0x350>
     8bc:      	mov.d	x15, v22[1]
     8c0:      	ld1.s	{ v21 }[3], [x15]
     8c4:      	b	0x7b8 <_llm_rows.packet_batch.blocks+0x350>
     8c8:      	mov	x14, #0x0               ; =0
     8cc:      	mov	w15, #0x301             ; =769
     8d0:      	dup.2s	v19, w15
     8d4:      	xtn.2s	v18, v18
     8d8:      	umull.2d	v18, v18, v19
     8dc:      	xtn.2s	v16, v16
     8e0:      	umull.2d	v16, v16, v19
     8e4:      	xtn.2s	v17, v17
     8e8:      	umull.2d	v17, v17, v19
     8ec:      	xtn.2s	v7, v7
     8f0:      	umull.2d	v7, v7, v19
     8f4:      	b	0x918 <_llm_rows.packet_batch.blocks+0x4b0>
     8f8:      	add	x15, x12, x14, lsl #5
     8fc:      	ldp	q21, q22, [x15]
     900:      	bif.16b	v20, v22, v0
     904:      	bif.16b	v19, v21, v1
     908:      	stp	q19, q20, [x15]
     90c:      	add	x14, x14, #0x1
     910:      	cmp	x14, #0x301
     914:      	b.eq	0xa0c <_llm_rows.packet_batch.blocks+0x5a4>
     918:      	fmov	w15, s6
     91c:      	dup.2d	v21, x14
     920:      	add.2d	v19, v21, v18
     924:      	shl.2d	v19, v19, #0x2
     928:      	dup.2d	v22, x13
     92c:      	add.2d	v23, v22, v19
     930:      	movi.2d	v19, #0000000000000000
     934:      	movi.2d	v20, #0000000000000000
     938:      	tbnz	w15, #0x0, 0x984 <_llm_rows.packet_batch.blocks+0x51c>
     93c:      	and	w15, w15, #0xff
     940:      	tbnz	w15, #0x1, 0x994 <_llm_rows.packet_batch.blocks+0x52c>
     944:      	add.2d	v23, v21, v16
     948:      	shl.2d	v23, v23, #0x2
     94c:      	add.2d	v23, v22, v23
     950:      	tbnz	w15, #0x2, 0x9ac <_llm_rows.packet_batch.blocks+0x544>
     954:      	tbnz	w15, #0x3, 0x9b8 <_llm_rows.packet_batch.blocks+0x550>
     958:      	add.2d	v23, v21, v17
     95c:      	shl.2d	v23, v23, #0x2
     960:      	add.2d	v23, v22, v23
     964:      	tbnz	w15, #0x4, 0x9d0 <_llm_rows.packet_batch.blocks+0x568>
     968:      	tbnz	w15, #0x5, 0x9dc <_llm_rows.packet_batch.blocks+0x574>
     96c:      	add.2d	v21, v21, v7
     970:      	shl.2d	v21, v21, #0x2
     974:      	add.2d	v21, v22, v21
     978:      	tbnz	w15, #0x6, 0x9f4 <_llm_rows.packet_batch.blocks+0x58c>
     97c:      	tbz	w15, #0x7, 0x8f8 <_llm_rows.packet_batch.blocks+0x490>
     980:      	b	0xa00 <_llm_rows.packet_batch.blocks+0x598>
     984:      	fmov	x16, d23
     988:      	ldr	s19, [x16]
     98c:      	and	w15, w15, #0xff
     990:      	tbz	w15, #0x1, 0x944 <_llm_rows.packet_batch.blocks+0x4dc>
     994:      	mov.d	x16, v23[1]
     998:      	ld1.s	{ v19 }[1], [x16]
     99c:      	add.2d	v23, v21, v16
     9a0:      	shl.2d	v23, v23, #0x2
     9a4:      	add.2d	v23, v22, v23
     9a8:      	tbz	w15, #0x2, 0x954 <_llm_rows.packet_batch.blocks+0x4ec>
     9ac:      	fmov	x16, d23
     9b0:      	ld1.s	{ v19 }[2], [x16]
     9b4:      	tbz	w15, #0x3, 0x958 <_llm_rows.packet_batch.blocks+0x4f0>
     9b8:      	mov.d	x16, v23[1]
     9bc:      	ld1.s	{ v19 }[3], [x16]
     9c0:      	add.2d	v23, v21, v17
     9c4:      	shl.2d	v23, v23, #0x2
     9c8:      	add.2d	v23, v22, v23
     9cc:      	tbz	w15, #0x4, 0x968 <_llm_rows.packet_batch.blocks+0x500>
     9d0:      	fmov	x16, d23
     9d4:      	ld1.s	{ v20 }[0], [x16]
     9d8:      	tbz	w15, #0x5, 0x96c <_llm_rows.packet_batch.blocks+0x504>
     9dc:      	mov.d	x16, v23[1]
     9e0:      	ld1.s	{ v20 }[1], [x16]
     9e4:      	add.2d	v21, v21, v7
     9e8:      	shl.2d	v21, v21, #0x2
     9ec:      	add.2d	v21, v22, v21
     9f0:      	tbz	w15, #0x6, 0x97c <_llm_rows.packet_batch.blocks+0x514>
     9f4:      	fmov	x16, d21
     9f8:      	ld1.s	{ v20 }[2], [x16]
     9fc:      	tbz	w15, #0x7, 0x8f8 <_llm_rows.packet_batch.blocks+0x490>
     a00:      	mov.d	x15, v21[1]
     a04:      	ld1.s	{ v20 }[3], [x15]
     a08:      	b	0x8f8 <_llm_rows.packet_batch.blocks+0x490>
     a0c:      	mov	x12, #0x0               ; =0
     a10:      	b	0xa34 <_llm_rows.packet_batch.blocks+0x5cc>
     a14:      	add	x13, x10, x12, lsl #5
     a18:      	ldp	q21, q22, [x13]
     a1c:      	bif.16b	v20, v22, v0
     a20:      	bif.16b	v19, v21, v1
     a24:      	stp	q19, q20, [x13]
     a28:      	add	x12, x12, #0x1
     a2c:      	cmp	x12, #0x301
     a30:      	b.eq	0xb28 <_llm_rows.packet_batch.blocks+0x6c0>
     a34:      	fmov	w13, s6
     a38:      	dup.2d	v21, x12
     a3c:      	add.2d	v19, v21, v18
     a40:      	shl.2d	v19, v19, #0x2
     a44:      	dup.2d	v22, x11
     a48:      	add.2d	v23, v22, v19
     a4c:      	movi.2d	v19, #0000000000000000
     a50:      	movi.2d	v20, #0000000000000000
     a54:      	tbnz	w13, #0x0, 0xaa0 <_llm_rows.packet_batch.blocks+0x638>
     a58:      	and	w13, w13, #0xff
     a5c:      	tbnz	w13, #0x1, 0xab0 <_llm_rows.packet_batch.blocks+0x648>
     a60:      	add.2d	v23, v21, v16
     a64:      	shl.2d	v23, v23, #0x2
     a68:      	add.2d	v23, v22, v23
     a6c:      	tbnz	w13, #0x2, 0xac8 <_llm_rows.packet_batch.blocks+0x660>
     a70:      	tbnz	w13, #0x3, 0xad4 <_llm_rows.packet_batch.blocks+0x66c>
     a74:      	add.2d	v23, v21, v17
     a78:      	shl.2d	v23, v23, #0x2
     a7c:      	add.2d	v23, v22, v23
     a80:      	tbnz	w13, #0x4, 0xaec <_llm_rows.packet_batch.blocks+0x684>
     a84:      	tbnz	w13, #0x5, 0xaf8 <_llm_rows.packet_batch.blocks+0x690>
     a88:      	add.2d	v21, v21, v7
     a8c:      	shl.2d	v21, v21, #0x2
     a90:      	add.2d	v21, v22, v21
     a94:      	tbnz	w13, #0x6, 0xb10 <_llm_rows.packet_batch.blocks+0x6a8>
     a98:      	tbz	w13, #0x7, 0xa14 <_llm_rows.packet_batch.blocks+0x5ac>
     a9c:      	b	0xb1c <_llm_rows.packet_batch.blocks+0x6b4>
     aa0:      	fmov	x14, d23
     aa4:      	ldr	s19, [x14]
     aa8:      	and	w13, w13, #0xff
     aac:      	tbz	w13, #0x1, 0xa60 <_llm_rows.packet_batch.blocks+0x5f8>
     ab0:      	mov.d	x14, v23[1]
     ab4:      	ld1.s	{ v19 }[1], [x14]
     ab8:      	add.2d	v23, v21, v16
     abc:      	shl.2d	v23, v23, #0x2
     ac0:      	add.2d	v23, v22, v23
     ac4:      	tbz	w13, #0x2, 0xa70 <_llm_rows.packet_batch.blocks+0x608>
     ac8:      	fmov	x14, d23
     acc:      	ld1.s	{ v19 }[2], [x14]
     ad0:      	tbz	w13, #0x3, 0xa74 <_llm_rows.packet_batch.blocks+0x60c>
     ad4:      	mov.d	x14, v23[1]
     ad8:      	ld1.s	{ v19 }[3], [x14]
     adc:      	add.2d	v23, v21, v17
     ae0:      	shl.2d	v23, v23, #0x2
     ae4:      	add.2d	v23, v22, v23
     ae8:      	tbz	w13, #0x4, 0xa84 <_llm_rows.packet_batch.blocks+0x61c>
     aec:      	fmov	x14, d23
     af0:      	ld1.s	{ v20 }[0], [x14]
     af4:      	tbz	w13, #0x5, 0xa88 <_llm_rows.packet_batch.blocks+0x620>
     af8:      	mov.d	x14, v23[1]
     afc:      	ld1.s	{ v20 }[1], [x14]
     b00:      	add.2d	v21, v21, v7
     b04:      	shl.2d	v21, v21, #0x2
     b08:      	add.2d	v21, v22, v21
     b0c:      	tbz	w13, #0x6, 0xa98 <_llm_rows.packet_batch.blocks+0x630>
     b10:      	fmov	x14, d21
     b14:      	ld1.s	{ v20 }[2], [x14]
     b18:      	tbz	w13, #0x7, 0xa14 <_llm_rows.packet_batch.blocks+0x5ac>
     b1c:      	mov.d	x13, v21[1]
     b20:      	ld1.s	{ v20 }[3], [x13]
     b24:      	b	0xa14 <_llm_rows.packet_batch.blocks+0x5ac>
     b28:      	mov	x10, #0x0               ; =0
     b2c:      	mov	x11, x8
     b30:      	b	0xb44 <_llm_rows.packet_batch.blocks+0x6dc>
     b34:      	add	x10, x10, #0x1
     b38:      	add	x11, x11, #0x20
     b3c:      	cmp	x10, #0x301
     b40:      	b.eq	0xc60 <_llm_rows.packet_batch.blocks+0x7f8>
     b44:      	fmov	w12, s6
     b48:      	dup.2d	v16, x10
     b4c:      	add.2d	v7, v16, v5
     b50:      	ldp	q19, q17, [x11]
     b54:      	ldr	q20, [x11, #0xc040]
     b58:      	ldr	q18, [x11, #0xc050]
     b5c:      	fmul.4s	v21, v19, v20
     b60:      	ldr	q22, [x11, #0x6020]
     b64:      	ldr	q19, [x11, #0x6030]
     b68:      	add	x13, x11, x27
     b6c:      	ldp	q23, q20, [x13]
     b70:      	fmul.4s	v22, v22, v23
     b74:      	fsub.4s	v21, v21, v22
     b78:      	and.16b	v21, v1, v21
     b7c:      	shl.2d	v22, v7, #0x2
     b80:      	dup.2d	v7, x9
     b84:      	add.2d	v22, v7, v22
     b88:      	tbnz	w12, #0x0, 0xbec <_llm_rows.packet_batch.blocks+0x784>
     b8c:      	and	w12, w12, #0xff
     b90:      	tbnz	w12, #0x1, 0xbfc <_llm_rows.packet_batch.blocks+0x794>
     b94:      	add.2d	v22, v16, v3
     b98:      	shl.2d	v22, v22, #0x2
     b9c:      	add.2d	v22, v7, v22
     ba0:      	tbnz	w12, #0x2, 0xc14 <_llm_rows.packet_batch.blocks+0x7ac>
     ba4:      	tbz	w12, #0x3, 0xbb0 <_llm_rows.packet_batch.blocks+0x748>
     ba8:      	mov.d	x13, v22[1]
     bac:      	st1.s	{ v21 }[3], [x13]
     bb0:      	add.2d	v21, v16, v4
     bb4:      	fmul.4s	v17, v17, v18
     bb8:      	fmul.4s	v18, v19, v20
     bbc:      	fsub.4s	v17, v17, v18
     bc0:      	and.16b	v17, v0, v17
     bc4:      	shl.2d	v18, v21, #0x2
     bc8:      	add.2d	v18, v7, v18
     bcc:      	tbnz	w12, #0x4, 0xc24 <_llm_rows.packet_batch.blocks+0x7bc>
     bd0:      	tbnz	w12, #0x5, 0xc30 <_llm_rows.packet_batch.blocks+0x7c8>
     bd4:      	add.2d	v16, v16, v2
     bd8:      	shl.2d	v16, v16, #0x2
     bdc:      	add.2d	v16, v7, v16
     be0:      	tbnz	w12, #0x6, 0xc48 <_llm_rows.packet_batch.blocks+0x7e0>
     be4:      	tbz	w12, #0x7, 0xb34 <_llm_rows.packet_batch.blocks+0x6cc>
     be8:      	b	0xc54 <_llm_rows.packet_batch.blocks+0x7ec>
     bec:      	fmov	x13, d22
     bf0:      	str	s21, [x13]
     bf4:      	and	w12, w12, #0xff
     bf8:      	tbz	w12, #0x1, 0xb94 <_llm_rows.packet_batch.blocks+0x72c>
     bfc:      	mov.d	x13, v22[1]
     c00:      	st1.s	{ v21 }[1], [x13]
     c04:      	add.2d	v22, v16, v3
     c08:      	shl.2d	v22, v22, #0x2
     c0c:      	add.2d	v22, v7, v22
     c10:      	tbz	w12, #0x2, 0xba4 <_llm_rows.packet_batch.blocks+0x73c>
     c14:      	fmov	x13, d22
     c18:      	st1.s	{ v21 }[2], [x13]
     c1c:      	tbnz	w12, #0x3, 0xba8 <_llm_rows.packet_batch.blocks+0x740>
     c20:      	b	0xbb0 <_llm_rows.packet_batch.blocks+0x748>
     c24:      	fmov	x13, d18
     c28:      	str	s17, [x13]
     c2c:      	tbz	w12, #0x5, 0xbd4 <_llm_rows.packet_batch.blocks+0x76c>
     c30:      	mov.d	x13, v18[1]
     c34:      	st1.s	{ v17 }[1], [x13]
     c38:      	add.2d	v16, v16, v2
     c3c:      	shl.2d	v16, v16, #0x2
     c40:      	add.2d	v16, v7, v16
     c44:      	tbz	w12, #0x6, 0xbe4 <_llm_rows.packet_batch.blocks+0x77c>
     c48:      	fmov	x13, d16
     c4c:      	st1.s	{ v17 }[2], [x13]
     c50:      	tbz	w12, #0x7, 0xb34 <_llm_rows.packet_batch.blocks+0x6cc>
     c54:      	mov.d	x12, v16[1]
     c58:      	st1.s	{ v17 }[3], [x12]
     c5c:      	b	0xb34 <_llm_rows.packet_batch.blocks+0x6cc>
     c60:      	mov	w9, #0x301              ; =769
     c64:      	b	0xc78 <_llm_rows.packet_batch.blocks+0x810>
     c68:      	add	x9, x9, #0x1
     c6c:      	add	x8, x8, #0x20
     c70:      	cmp	x9, #0x602
     c74:      	b.eq	0x4e8 <_llm_rows.packet_batch.blocks+0x80>
     c78:      	fmov	w10, s6
     c7c:      	dup.2d	v16, x9
     c80:      	add.2d	v22, v16, v5
     c84:      	ldp	q19, q17, [x8]
     c88:      	add	x11, x8, x27
     c8c:      	ldp	q20, q18, [x11]
     c90:      	fmul.4s	v21, v19, v20
     c94:      	ldr	q23, [x8, #0x6020]
     c98:      	ldr	q19, [x8, #0x6030]
     c9c:      	ldr	q24, [x8, #0xc040]
     ca0:      	ldr	q20, [x8, #0xc050]
     ca4:      	fmul.4s	v23, v23, v24
     ca8:      	fadd.4s	v21, v21, v23
     cac:      	and.16b	v21, v1, v21
     cb0:      	shl.2d	v22, v22, #0x2
     cb4:      	add.2d	v22, v7, v22
     cb8:      	tbnz	w10, #0x0, 0xd1c <_llm_rows.packet_batch.blocks+0x8b4>
     cbc:      	and	w10, w10, #0xff
     cc0:      	tbnz	w10, #0x1, 0xd2c <_llm_rows.packet_batch.blocks+0x8c4>
     cc4:      	add.2d	v22, v16, v3
     cc8:      	shl.2d	v22, v22, #0x2
     ccc:      	add.2d	v22, v7, v22
     cd0:      	tbnz	w10, #0x2, 0xd44 <_llm_rows.packet_batch.blocks+0x8dc>
     cd4:      	tbz	w10, #0x3, 0xce0 <_llm_rows.packet_batch.blocks+0x878>
     cd8:      	mov.d	x11, v22[1]
     cdc:      	st1.s	{ v21 }[3], [x11]
     ce0:      	add.2d	v21, v16, v4
     ce4:      	fmul.4s	v17, v17, v18
     ce8:      	fmul.4s	v18, v19, v20
     cec:      	fadd.4s	v17, v17, v18
     cf0:      	and.16b	v17, v0, v17
     cf4:      	shl.2d	v18, v21, #0x2
     cf8:      	add.2d	v18, v7, v18
     cfc:      	tbnz	w10, #0x4, 0xd54 <_llm_rows.packet_batch.blocks+0x8ec>
     d00:      	tbnz	w10, #0x5, 0xd60 <_llm_rows.packet_batch.blocks+0x8f8>
     d04:      	add.2d	v16, v16, v2
     d08:      	shl.2d	v16, v16, #0x2
     d0c:      	add.2d	v16, v7, v16
     d10:      	tbnz	w10, #0x6, 0xd78 <_llm_rows.packet_batch.blocks+0x910>
     d14:      	tbz	w10, #0x7, 0xc68 <_llm_rows.packet_batch.blocks+0x800>
     d18:      	b	0xd84 <_llm_rows.packet_batch.blocks+0x91c>
     d1c:      	fmov	x11, d22
     d20:      	str	s21, [x11]
     d24:      	and	w10, w10, #0xff
     d28:      	tbz	w10, #0x1, 0xcc4 <_llm_rows.packet_batch.blocks+0x85c>
     d2c:      	mov.d	x11, v22[1]
     d30:      	st1.s	{ v21 }[1], [x11]
     d34:      	add.2d	v22, v16, v3
     d38:      	shl.2d	v22, v22, #0x2
     d3c:      	add.2d	v22, v7, v22
     d40:      	tbz	w10, #0x2, 0xcd4 <_llm_rows.packet_batch.blocks+0x86c>
     d44:      	fmov	x11, d22
     d48:      	st1.s	{ v21 }[2], [x11]
     d4c:      	tbnz	w10, #0x3, 0xcd8 <_llm_rows.packet_batch.blocks+0x870>
     d50:      	b	0xce0 <_llm_rows.packet_batch.blocks+0x878>
     d54:      	fmov	x11, d18
     d58:      	str	s17, [x11]
     d5c:      	tbz	w10, #0x5, 0xd04 <_llm_rows.packet_batch.blocks+0x89c>
     d60:      	mov.d	x11, v18[1]
     d64:      	st1.s	{ v17 }[1], [x11]
     d68:      	add.2d	v16, v16, v2
     d6c:      	shl.2d	v16, v16, #0x2
     d70:      	add.2d	v16, v7, v16
     d74:      	tbz	w10, #0x6, 0xd14 <_llm_rows.packet_batch.blocks+0x8ac>
     d78:      	fmov	x11, d16
     d7c:      	st1.s	{ v17 }[2], [x11]
     d80:      	tbz	w10, #0x7, 0xc68 <_llm_rows.packet_batch.blocks+0x800>
     d84:      	mov.d	x10, v16[1]
     d88:      	st1.s	{ v17 }[3], [x10]
     d8c:      	b	0xc68 <_llm_rows.packet_batch.blocks+0x800>
     d90:      	ldp	x29, x30, [sp, #0xb0]
     d94:      	ldp	x20, x19, [sp, #0xa0]
     d98:      	ldp	x22, x21, [sp, #0x90]
     d9c:      	ldp	x24, x23, [sp, #0x80]
     da0:      	ldp	x26, x25, [sp, #0x70]
     da4:      	ldp	x28, x27, [sp, #0x60]
     da8:      	add	sp, sp, #0xc0
     dac:      	ret

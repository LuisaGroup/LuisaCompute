
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/rope-257x1538/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0x60
     6b4:      	stp	x24, x23, [sp, #0x20]
     6b8:      	stp	x22, x21, [sp, #0x30]
     6bc:      	stp	x20, x19, [sp, #0x40]
     6c0:      	stp	x29, x30, [sp, #0x50]
     6c4:      	add	x29, sp, #0x50
     6c8:      	mov	x8, #0x0                ; =0
     6cc:      	str	wzr, [sp]
     6d0:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     6d4:      	ldr	x9, [x9, #0x90]
     6d8:      	mov	x10, sp
     6dc:      	str	x10, [x9]
     6e0:      	mov	w10, #0x602             ; =1538
     6e4:      	mov	w11, #0x301             ; =769
     6e8:      	mov	x12, #0x300             ; =768
     6ec:      	mov	w13, #0x1808            ; =6152
     6f0:      	mov	w14, #0x1804            ; =6148
     6f4:      	mov	x15, x1
     6f8:      	mov	x16, x2
     6fc:      	mov	x17, x0
     700:      	mov	x5, x3
     704:      	mov	x6, x4
     708:      	mul	x20, x8, x10
     70c:      	add	x7, x20, #0x300
     710:      	madd	x19, x8, x11, x12
     714:      	add	x20, x0, x20, lsl #2
     718:      	mov	x21, #-0xc00            ; =-3072
     71c:      	mov	x22, #-0x4              ; =-4
     720:      	cbz	x21, 0x79c <_kernel+0xec>
     724:      	add	x23, x17, x21
     728:      	ldr	q0, [x23, #0xc00]
     72c:      	add	x24, x15, x21
     730:      	ldr	q1, [x24, #0xc00]
     734:      	ldr	q2, [x23, x14]
     738:      	add	x23, x16, x21
     73c:      	ldr	q3, [x23, #0xc00]
     740:      	fmul.4s	v4, v0, v1
     744:      	fmul.4s	v5, v2, v3
     748:      	fsub.4s	v4, v4, v5
     74c:      	fmul.4s	v0, v0, v3
     750:      	fmul.4s	v1, v1, v2
     754:      	fadd.4s	v0, v1, v0
     758:      	add	x23, x5, x21
     75c:      	str	q4, [x23, #0xc00]
     760:      	add	x23, x6, x21
     764:      	str	q0, [x23, #0xc00]
     768:      	add	x21, x21, #0x10
     76c:      	add	x22, x22, #0x4
     770:      	cmp	x22, #0x2fd
     774:      	b.lo	0x720 <_kernel+0x70>
     778:      	add	x8, x8, #0x1
     77c:      	add	x6, x6, x13
     780:      	add	x5, x5, x13
     784:      	add	x17, x17, x13
     788:      	add	x16, x16, #0xc04
     78c:      	add	x15, x15, #0xc04
     790:      	cmp	x8, #0x101
     794:      	b.ne	0x708 <_kernel+0x58>
     798:      	b	0x7d0 <_kernel+0x120>
     79c:      	ldr	s0, [x0, x7, lsl #2]
     7a0:      	ldr	s1, [x1, x19, lsl #2]
     7a4:      	ldr	s2, [x2, x19, lsl #2]
     7a8:      	ldr	s3, [x20, #0x1804]
     7ac:      	fmul	s4, s0, s1
     7b0:      	fmul	s5, s3, s2
     7b4:      	fsub	s4, s4, s5
     7b8:      	str	s4, [x3, x7, lsl #2]
     7bc:      	fmul	s0, s0, s2
     7c0:      	fmul	s1, s1, s3
     7c4:      	fadd	s0, s1, s0
     7c8:      	str	s0, [x4, x7, lsl #2]
     7cc:      	b	0x778 <_kernel+0xc8>
     7d0:      	str	xzr, [x9]
     7d4:      	mov	x8, sp
     7d8:      	ldapr	w8, [x8]
     7dc:      	cbnz	w8, 0x7f8 <_kernel+0x148>
     7e0:      	ldp	x29, x30, [sp, #0x50]
     7e4:      	ldp	x20, x19, [sp, #0x40]
     7e8:      	ldp	x22, x21, [sp, #0x30]
     7ec:      	ldp	x24, x23, [sp, #0x20]
     7f0:      	add	sp, sp, #0x60
     7f4:      	ret
     7f8:      	mov	w0, #0x10               ; =16
     7fc:      	bl	0x170c <dyld_stub_binder+0x170c>
     800:      	mov	x19, x0
     804:      	mov	w8, #0x33d              ; =829
     808:      	str	w8, [sp, #0x4]
     80c:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x3c>
     810:      	add	x0, x0, #0xa30
     814:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x3c>
     818:      	add	x1, x1, #0xabc
     81c:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x3c>
     820:      	add	x3, x3, #0xae7
     824:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x3c>
     828:      	add	x4, x4, #0xb65
     82c:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x3c>
     830:      	add	x2, x2, #0xae4
     834:      	add	x8, sp, #0x8
     838:      	add	x5, sp, #0x4
     83c:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x3c>
     840:      	add	x7, x7, #0xb67
     844:      	mov	x6, x2
     848:      	bl	0x8bc <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     84c:      	mov	w21, #0x1               ; =1
     850:      	add	x1, sp, #0x8
     854:      	mov	x0, x19
     858:      	bl	0x1658 <dyld_stub_binder+0x1658>
     85c:      	mov	w21, #0x0               ; =0
     860:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     864:      	ldr	x1, [x1, #0x18]
     868:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     86c:      	ldr	x2, [x2, #0x8]
     870:      	mov	x0, x19
     874:      	bl	0x173c <dyld_stub_binder+0x173c>
     878:      	brk	#0x1
     87c:      	mov	x20, x0
     880:      	ldrsb	w8, [sp, #0x1f]
     884:      	tbz	w8, #0x1f, 0x8a0 <_kernel+0x1f0>
     888:      	ldr	x0, [sp, #0x8]
     88c:      	ldr	x8, [sp, #0x18]
     890:      	and	x1, x8, #0x7fffffffffffffff
     894:      	bl	0x16f4 <dyld_stub_binder+0x16f4>
     898:      	tbnz	w21, #0x0, 0x8ac <_kernel+0x1fc>
     89c:      	b	0x8b4 <_kernel+0x204>
     8a0:      	cbnz	w21, 0x8ac <_kernel+0x1fc>
     8a4:      	b	0x8b4 <_kernel+0x204>
     8a8:      	mov	x20, x0
     8ac:      	mov	x0, x19
     8b0:      	bl	0x1730 <dyld_stub_binder+0x1730>
     8b4:      	mov	x0, x20
     8b8:      	bl	0x161c <dyld_stub_binder+0x161c>

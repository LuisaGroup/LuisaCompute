
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/rmsnorm-17x65/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0xe0
     6b4:      	stp	d11, d10, [sp, #0x60]
     6b8:      	stp	d9, d8, [sp, #0x70]
     6bc:      	stp	x28, x27, [sp, #0x80]
     6c0:      	stp	x26, x25, [sp, #0x90]
     6c4:      	stp	x24, x23, [sp, #0xa0]
     6c8:      	stp	x22, x21, [sp, #0xb0]
     6cc:      	stp	x20, x19, [sp, #0xc0]
     6d0:      	stp	x29, x30, [sp, #0xd0]
     6d4:      	add	x29, sp, #0xd0
     6d8:      	mov	x19, #0x0               ; =0
     6dc:      	str	wzr, [sp, #0x40]
     6e0:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     6e4:      	ldr	x9, [x9, #0x98]
     6e8:      	add	x8, sp, #0x40
     6ec:      	str	x8, [x9]
     6f0:      	mov	w21, #0x104             ; =260
     6f4:      	adrp	x22, 0x4000 <dyld_stub_binder+0x4000>
     6f8:      	ldr	x22, [x22, #0x80]
     6fc:      	movi.2d	v8, #0000000000000000
     700:      	mov	w8, #0x42820000         ; =1115815936
     704:      	fmov	s9, w8
     708:      	mov	w8, #0xc5ac             ; =50604
     70c:      	movk	w8, #0x3727, lsl #16
     710:      	fmov	s10, w8
     714:      	fmov	s11, #1.00000000
     718:      	mov	x23, x0
     71c:      	mov	x20, x3
     720:      	b	0x768 <_kernel+0xb8>
     724:      	ldr	s2, [x0, x25, lsl #2]
     728:      	ldr	s0, [x2, x19, lsl #2]
     72c:      	ldr	s3, [x1, #0x100]
     730:      	fdiv	s0, s0, s9
     734:      	fadd	s1, s0, s10
     738:      	fsqrt	s0, s1
     73c:      	fcmp	s0, s0
     740:      	b.vs	0x8cc <_kernel+0x21c>
     744:      	fdiv	s0, s11, s0
     748:      	fmul	s0, s2, s0
     74c:      	fmul	s0, s3, s0
     750:      	str	s0, [x3, x25, lsl #2]
     754:      	add	x19, x19, #0x1
     758:      	add	x20, x20, #0x104
     75c:      	add	x23, x23, #0x104
     760:      	cmp	x19, #0x11
     764:      	b.eq	0x910 <_kernel+0x260>
     768:      	madd	x8, x19, x21, x0
     76c:      	ldr	q0, [x22]
     770:      	ldp	q1, q2, [x8]
     774:      	fmul.4s	v1, v1, v1
     778:      	fmul.4s	v2, v2, v2
     77c:      	fadd.4s	v1, v1, v2
     780:      	ldp	q2, q3, [x8, #0x20]
     784:      	fmul.4s	v2, v2, v2
     788:      	fadd.4s	v1, v1, v2
     78c:      	fmul.4s	v2, v3, v3
     790:      	fadd.4s	v1, v1, v2
     794:      	ldp	q2, q3, [x8, #0x40]
     798:      	fmul.4s	v2, v2, v2
     79c:      	fadd.4s	v1, v1, v2
     7a0:      	fmul.4s	v2, v3, v3
     7a4:      	fadd.4s	v1, v1, v2
     7a8:      	ldp	q2, q3, [x8, #0x60]
     7ac:      	fmul.4s	v2, v2, v2
     7b0:      	fadd.4s	v1, v1, v2
     7b4:      	fmul.4s	v2, v3, v3
     7b8:      	fadd.4s	v1, v1, v2
     7bc:      	ldp	q2, q3, [x8, #0x80]
     7c0:      	fmul.4s	v2, v2, v2
     7c4:      	fadd.4s	v1, v1, v2
     7c8:      	fmul.4s	v2, v3, v3
     7cc:      	fadd.4s	v1, v1, v2
     7d0:      	ldp	q2, q3, [x8, #0xa0]
     7d4:      	fmul.4s	v2, v2, v2
     7d8:      	fadd.4s	v1, v1, v2
     7dc:      	fmul.4s	v2, v3, v3
     7e0:      	fadd.4s	v1, v1, v2
     7e4:      	ldp	q2, q3, [x8, #0xc0]
     7e8:      	fmul.4s	v2, v2, v2
     7ec:      	fadd.4s	v1, v1, v2
     7f0:      	fmul.4s	v2, v3, v3
     7f4:      	fadd.4s	v1, v1, v2
     7f8:      	ldp	q2, q3, [x8, #0xe0]
     7fc:      	fmul.4s	v2, v2, v2
     800:      	fadd.4s	v1, v1, v2
     804:      	fmul.4s	v2, v3, v3
     808:      	fadd.4s	v1, v1, v2
     80c:      	ldr	s2, [x8, #0x100]
     810:      	fmul	s2, s2, s2
     814:      	movi.2d	v3, #0000000000000000
     818:      	mov.s	v3[0], v2[0]
     81c:      	fadd.4s	v2, v1, v3
     820:      	bsl.16b	v0, v2, v1
     824:      	dup.2d	v1, v0[1]
     828:      	fadd.4s	v0, v1, v0
     82c:      	faddp.2s	s0, v0
     830:      	fadd	s0, s0, s8
     834:      	str	s0, [x2, x19, lsl #2]
     838:      	add	x8, x19, x19, lsl #6
     83c:      	add	x25, x8, #0x40
     840:      	mov	x26, #-0x4              ; =-4
     844:      	mov	x27, x1
     848:      	mov	x28, x23
     84c:      	mov	x24, x20
     850:      	cmp	x26, #0x3c
     854:      	b.eq	0x724 <_kernel+0x74>
     858:      	ldr	s0, [x2, x19, lsl #2]
     85c:      	ldr	q2, [x28]
     860:      	ldr	q3, [x27]
     864:      	fdiv	s0, s0, s9
     868:      	fadd	s1, s0, s10
     86c:      	fsqrt	s0, s1
     870:      	fcmp	s0, s0
     874:      	b.vs	0x8a0 <_kernel+0x1f0>
     878:      	fdiv	s0, s11, s0
     87c:      	fmul.4s	v0, v2, v0[0]
     880:      	fmul.4s	v0, v3, v0
     884:      	str	q0, [x24], #0x10
     888:      	add	x28, x28, #0x10
     88c:      	add	x27, x27, #0x10
     890:      	add	x26, x26, #0x4
     894:      	cmp	x26, #0x3d
     898:      	b.lo	0x850 <_kernel+0x1a0>
     89c:      	b	0x754 <_kernel+0xa4>
     8a0:      	mov.16b	v0, v1
     8a4:      	stp	x1, x3, [sp, #0x30]
     8a8:      	stp	x0, x2, [sp, #0x20]
     8ac:      	stp	q3, q2, [sp]
     8b0:      	bl	0x18b4 <dyld_stub_binder+0x18b4>
     8b4:      	ldp	q3, q2, [sp]
     8b8:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     8bc:      	ldr	x9, [x9, #0x98]
     8c0:      	ldp	x0, x2, [sp, #0x20]
     8c4:      	ldp	x1, x3, [sp, #0x30]
     8c8:      	b	0x878 <_kernel+0x1c8>
     8cc:      	mov.16b	v0, v1
     8d0:      	mov	x24, x3
     8d4:      	mov	x27, x2
     8d8:      	mov	x26, x1
     8dc:      	mov	x28, x0
     8e0:      	str	s2, [sp, #0x38]
     8e4:      	str	s3, [sp, #0x30]
     8e8:      	bl	0x18b4 <dyld_stub_binder+0x18b4>
     8ec:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     8f0:      	ldr	x9, [x9, #0x98]
     8f4:      	ldr	s3, [sp, #0x30]
     8f8:      	ldr	s2, [sp, #0x38]
     8fc:      	mov	x0, x28
     900:      	mov	x1, x26
     904:      	mov	x2, x27
     908:      	mov	x3, x24
     90c:      	b	0x744 <_kernel+0x94>
     910:      	str	xzr, [x9]
     914:      	add	x8, sp, #0x40
     918:      	ldapr	w8, [x8]
     91c:      	cbnz	w8, 0x948 <_kernel+0x298>
     920:      	ldp	x29, x30, [sp, #0xd0]
     924:      	ldp	x20, x19, [sp, #0xc0]
     928:      	ldp	x22, x21, [sp, #0xb0]
     92c:      	ldp	x24, x23, [sp, #0xa0]
     930:      	ldp	x26, x25, [sp, #0x90]
     934:      	ldp	x28, x27, [sp, #0x80]
     938:      	ldp	d9, d8, [sp, #0x70]
     93c:      	ldp	d11, d10, [sp, #0x60]
     940:      	add	sp, sp, #0xe0
     944:      	ret
     948:      	mov	w0, #0x10               ; =16
     94c:      	bl	0x1848 <dyld_stub_binder+0x1848>
     950:      	mov	x19, x0
     954:      	mov	w8, #0x33d              ; =829
     958:      	str	w8, [sp, #0x44]
     95c:      	adrp	x0, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x58>
     960:      	add	x0, x0, #0xb84
     964:      	adrp	x1, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x58>
     968:      	add	x1, x1, #0xc10
     96c:      	adrp	x3, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x58>
     970:      	add	x3, x3, #0xc3b
     974:      	adrp	x4, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x58>
     978:      	add	x4, x4, #0xcb9
     97c:      	adrp	x2, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x58>
     980:      	add	x2, x2, #0xc38
     984:      	add	x8, sp, #0x48
     988:      	add	x5, sp, #0x44
     98c:      	adrp	x7, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x58>
     990:      	add	x7, x7, #0xcbb
     994:      	mov	x6, x2
     998:      	bl	0xa0c <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     99c:      	mov	w21, #0x1               ; =1
     9a0:      	add	x1, sp, #0x48
     9a4:      	mov	x0, x19
     9a8:      	bl	0x1794 <dyld_stub_binder+0x1794>
     9ac:      	mov	w21, #0x0               ; =0
     9b0:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     9b4:      	ldr	x1, [x1, #0x18]
     9b8:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     9bc:      	ldr	x2, [x2, #0x8]
     9c0:      	mov	x0, x19
     9c4:      	bl	0x1878 <dyld_stub_binder+0x1878>
     9c8:      	brk	#0x1
     9cc:      	mov	x20, x0
     9d0:      	ldrsb	w8, [sp, #0x5f]
     9d4:      	tbz	w8, #0x1f, 0x9f0 <_kernel+0x340>
     9d8:      	ldr	x0, [sp, #0x48]
     9dc:      	ldr	x8, [sp, #0x58]
     9e0:      	and	x1, x8, #0x7fffffffffffffff
     9e4:      	bl	0x1830 <dyld_stub_binder+0x1830>
     9e8:      	tbnz	w21, #0x0, 0x9fc <_kernel+0x34c>
     9ec:      	b	0xa04 <_kernel+0x354>
     9f0:      	cbnz	w21, 0x9fc <_kernel+0x34c>
     9f4:      	b	0xa04 <_kernel+0x354>
     9f8:      	mov	x20, x0
     9fc:      	mov	x0, x19
     a00:      	bl	0x186c <dyld_stub_binder+0x186c>
     a04:      	mov	x0, x20
     a08:      	bl	0x1758 <dyld_stub_binder+0x1758>


/private/tmp/luisa-native-rows.LuX3yX/capture-v3/rmsnorm-17x65-l1/object/tile_xir_w8_80688_1788919109050105_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x1138 <ltmp0+0x1138>
       4:      	stp	d13, d12, [sp, #-0x90]!
       8:      	stp	d11, d10, [sp, #0x10]
       c:      	stp	d9, d8, [sp, #0x20]
      10:      	stp	x28, x27, [sp, #0x30]
      14:      	stp	x26, x25, [sp, #0x40]
      18:      	stp	x24, x23, [sp, #0x50]
      1c:      	stp	x22, x21, [sp, #0x60]
      20:      	stp	x20, x19, [sp, #0x70]
      24:      	stp	x29, x30, [sp, #0x80]
      28:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      2c:      	sub	sp, sp, #0x60
      30:      	mov	w8, #0x0                ; =0
      34:      	add	x9, sp, #0x840
      38:      	ldp	w10, w11, [x2, #0x2c]
      3c:      	ldp	w7, w19, [x2]
      40:      	add	x12, x9, #0xe0
      44:      	str	x12, [sp, #0x10]
      48:      	adrp	x14, 0x0 <ltmp0>
      4c:      	ldr	q0, [x14]
      50:      	adrp	x14, 0x0 <ltmp0>
      54:      	ldr	q1, [x14]
      58:      	movi.4s	v2, #0x41
      5c:      	movi.2s	v3, #0x41
      60:      	add	x14, sp, #0x20
      64:      	mov	w15, #0x42820000        ; =1115815936
      68:      	mov	w16, #0xc5ac            ; =50604
      6c:      	movk	w16, #0x3727, lsl #16
      70:      	adrp	x17, 0x0 <ltmp0>
      74:      	ldp	w20, w1, [x2, #0x8]
      78:      	str	x2, [sp, #0x8]
      7c:      	b	0xb4 <ltmp0+0xb4>
      80:      	add	w12, w6, #0x1
      84:      	cmp	w12, w10
      88:      	cset	w12, eq
      8c:      	csinc	w7, wzr, w6, eq
      90:      	cinc	w13, w5, eq
      94:      	cmp	w13, w11
      98:      	cset	w2, eq
      9c:      	ands	w12, w12, w2
      a0:      	csel	w19, wzr, w13, ne
      a4:      	add	w20, w4, w12
      a8:      	add	w8, w8, #0x1
      ac:      	cmp	w8, w3
      b0:      	b.eq	0x10f8 <ltmp0+0x10f8>
      b4:      	mov	x4, x20
      b8:      	mov	x5, x19
      bc:      	mov	x6, x7
      c0:      	ubfiz	x7, x7, #5, #32
      c4:      	cmp	x7, x1
      c8:      	csel	x19, x7, xzr, ls
      cc:      	subs	x20, x1, x19
      d0:      	cmp	x20, #0x20
      d4:      	mov	w12, #0x20              ; =32
      d8:      	csel	x20, x20, x12, lo
      dc:      	cmp	x1, x19
      e0:      	ccmp	x7, x1, #0x2, hi
      e4:      	csel	x19, x20, xzr, ls
      e8:      	dup.4s	v5, w15
      ec:      	dup.4s	v4, w16
      f0:      	cmp	x19, #0x20
      f4:      	b.lo	0xa50 <ltmp0+0xa50>
      f8:      	mov	x21, #0x0               ; =0
      fc:      	ldr	x22, [x0]
     100:      	ldr	x7, [x0, #0x10]
     104:      	ldr	x20, [x0, #0x30]
     108:      	lsl	w19, w6, #5
     10c:      	dup.4s	v6, w19
     110:      	orr.16b	v7, v6, v0
     114:      	orr.16b	v6, v6, v1
     118:      	umull2.2d	v16, v7, v2
     11c:      	umull2.2d	v17, v6, v2
     120:      	umull.2d	v18, v7, v3
     124:      	umull.2d	v19, v6, v3
     128:      	dup.2d	v6, x22
     12c:      	dup.2d	v7, x21
     130:      	add.2d	v20, v7, v16
     134:      	add.2d	v21, v7, v18
     138:      	add.2d	v22, v7, v17
     13c:      	add.2d	v7, v7, v19
     140:      	shl.2d	v7, v7, #0x2
     144:      	shl.2d	v22, v22, #0x2
     148:      	shl.2d	v21, v21, #0x2
     14c:      	shl.2d	v20, v20, #0x2
     150:      	add.2d	v20, v6, v20
     154:      	add.2d	v21, v6, v21
     158:      	add.2d	v22, v6, v22
     15c:      	add.2d	v7, v6, v7
     160:      	mov.d	x22, v7[1]
     164:      	fmov	x23, d7
     168:      	mov.d	x24, v22[1]
     16c:      	fmov	x25, d22
     170:      	mov.d	x26, v21[1]
     174:      	fmov	x27, d21
     178:      	mov.d	x28, v20[1]
     17c:      	ldr	s7, [x27]
     180:      	ld1.s	{ v7 }[1], [x26]
     184:      	fmov	x26, d20
     188:      	ld1.s	{ v7 }[2], [x26]
     18c:      	ld1.s	{ v7 }[3], [x28]
     190:      	ldr	s20, [x23]
     194:      	ld1.s	{ v20 }[1], [x22]
     198:      	ld1.s	{ v20 }[2], [x25]
     19c:      	ld1.s	{ v20 }[3], [x24]
     1a0:      	add	x22, x9, x21, lsl #5
     1a4:      	stp	q20, q7, [x22]
     1a8:      	add	x21, x21, #0x1
     1ac:      	cmp	x21, #0x41
     1b0:      	b.ne	0x12c <ltmp0+0x12c>
     1b4:      	mov	x21, #0x0               ; =0
     1b8:      	ldp	q20, q7, [x9]
     1bc:      	fmul.4s	v7, v7, v7
     1c0:      	fmul.4s	v20, v20, v20
     1c4:      	ldp	q21, q22, [x9, #0x20]
     1c8:      	fmul.4s	v22, v22, v22
     1cc:      	fmul.4s	v21, v21, v21
     1d0:      	ldp	q24, q23, [x9, #0x40]
     1d4:      	fmul.4s	v23, v23, v23
     1d8:      	fmul.4s	v24, v24, v24
     1dc:      	ldp	q25, q26, [x9, #0x60]
     1e0:      	fmul.4s	v26, v26, v26
     1e4:      	fmul.4s	v25, v25, v25
     1e8:      	add	x22, x9, x21, lsl #5
     1ec:      	ldp	q28, q27, [x22, #0x80]
     1f0:      	fmul.4s	v28, v28, v28
     1f4:      	fmul.4s	v27, v27, v27
     1f8:      	fadd.4s	v7, v7, v27
     1fc:      	fadd.4s	v20, v20, v28
     200:      	ldp	q28, q27, [x22, #0xa0]
     204:      	fmul.4s	v28, v28, v28
     208:      	fmul.4s	v27, v27, v27
     20c:      	fadd.4s	v22, v22, v27
     210:      	fadd.4s	v21, v21, v28
     214:      	ldp	q28, q27, [x22, #0xc0]
     218:      	fmul.4s	v28, v28, v28
     21c:      	fmul.4s	v27, v27, v27
     220:      	fadd.4s	v23, v23, v27
     224:      	fadd.4s	v24, v24, v28
     228:      	ldp	q28, q27, [x22, #0xe0]
     22c:      	fmul.4s	v28, v28, v28
     230:      	fmul.4s	v27, v27, v27
     234:      	fadd.4s	v26, v26, v27
     238:      	fadd.4s	v25, v25, v28
     23c:      	add	x21, x21, #0x4
     240:      	cmp	x21, #0x3c
     244:      	b.lo	0x1e8 <ltmp0+0x1e8>
     248:      	mov	x21, #0x0               ; =0
     24c:      	ldr	q28, [x9, #0x810]
     250:      	ldr	q27, [x9, #0x800]
     254:      	add	x22, x7, x21, lsl #2
     258:      	ld1r.4s	{ v29 }, [x22]
     25c:      	add	x22, x14, x21, lsl #5
     260:      	stp	q29, q29, [x22]
     264:      	add	x21, x21, #0x1
     268:      	cmp	x21, #0x41
     26c:      	b.ne	0x254 <ltmp0+0x254>
     270:      	mov	x21, #0x0               ; =0
     274:      	fmul.4s	v28, v28, v28
     278:      	fmul.4s	v27, v27, v27
     27c:      	fadd.4s	v20, v20, v27
     280:      	fadd.4s	v7, v7, v28
     284:      	fadd.4s	v7, v22, v7
     288:      	fadd.4s	v20, v21, v20
     28c:      	fadd.4s	v20, v24, v20
     290:      	fadd.4s	v7, v23, v7
     294:      	fadd.4s	v7, v26, v7
     298:      	fadd.4s	v20, v25, v20
     29c:      	fdiv.4s	v20, v20, v5
     2a0:      	fdiv.4s	v7, v7, v5
     2a4:      	fadd.4s	v7, v7, v4
     2a8:      	fadd.4s	v20, v20, v4
     2ac:      	fsqrt.4s	v20, v20
     2b0:      	fsqrt.4s	v21, v7
     2b4:      	dup.2d	v7, x21
     2b8:      	add.2d	v22, v7, v16
     2bc:      	add.2d	v23, v7, v18
     2c0:      	add.2d	v24, v7, v17
     2c4:      	add.2d	v7, v7, v19
     2c8:      	lsl	x22, x21, #5
     2cc:      	add	x23, x9, x22
     2d0:      	ldp	q26, q25, [x23]
     2d4:      	fdiv.4s	v26, v26, v20
     2d8:      	fdiv.4s	v25, v25, v21
     2dc:      	add	x22, x14, x22
     2e0:      	ldp	q27, q28, [x22]
     2e4:      	fmul.4s	v25, v25, v28
     2e8:      	fmul.4s	v26, v26, v27
     2ec:      	shl.2d	v27, v7, #0x2
     2f0:      	shl.2d	v24, v24, #0x2
     2f4:      	shl.2d	v23, v23, #0x2
     2f8:      	shl.2d	v22, v22, #0x2
     2fc:      	dup.2d	v7, x20
     300:      	add.2d	v22, v7, v22
     304:      	add.2d	v27, v7, v27
     308:      	mov.d	x22, v27[1]
     30c:      	fmov	x23, d27
     310:      	str	s26, [x23]
     314:      	st1.s	{ v26 }[1], [x22]
     318:      	add.2d	v24, v7, v24
     31c:      	mov.d	x22, v24[1]
     320:      	fmov	x23, d24
     324:      	st1.s	{ v26 }[2], [x23]
     328:      	add.2d	v23, v7, v23
     32c:      	st1.s	{ v26 }[3], [x22]
     330:      	mov.d	x22, v23[1]
     334:      	fmov	x23, d23
     338:      	str	s25, [x23]
     33c:      	st1.s	{ v25 }[1], [x22]
     340:      	mov.d	x22, v22[1]
     344:      	fmov	x23, d22
     348:      	st1.s	{ v25 }[2], [x23]
     34c:      	st1.s	{ v25 }[3], [x22]
     350:      	add	x21, x21, #0x1
     354:      	cmp	x21, #0x41
     358:      	b.ne	0x2b4 <ltmp0+0x2b4>
     35c:      	mov	x20, #0x0               ; =0
     360:      	orr	w21, w19, #0x8
     364:      	dup.4s	v16, w21
     368:      	orr.16b	v18, v16, v0
     36c:      	orr.16b	v19, v16, v1
     370:      	umull2.2d	v16, v18, v2
     374:      	umull2.2d	v17, v19, v2
     378:      	umull.2d	v18, v18, v3
     37c:      	umull.2d	v19, v19, v3
     380:      	dup.2d	v20, x20
     384:      	add.2d	v21, v20, v16
     388:      	add.2d	v22, v20, v18
     38c:      	add.2d	v23, v20, v17
     390:      	add.2d	v20, v20, v19
     394:      	shl.2d	v20, v20, #0x2
     398:      	shl.2d	v23, v23, #0x2
     39c:      	shl.2d	v22, v22, #0x2
     3a0:      	shl.2d	v21, v21, #0x2
     3a4:      	add.2d	v21, v6, v21
     3a8:      	add.2d	v22, v6, v22
     3ac:      	add.2d	v23, v6, v23
     3b0:      	add.2d	v20, v6, v20
     3b4:      	mov.d	x21, v20[1]
     3b8:      	fmov	x22, d20
     3bc:      	mov.d	x23, v23[1]
     3c0:      	fmov	x24, d23
     3c4:      	mov.d	x25, v22[1]
     3c8:      	fmov	x26, d22
     3cc:      	mov.d	x27, v21[1]
     3d0:      	ldr	s20, [x26]
     3d4:      	ld1.s	{ v20 }[1], [x25]
     3d8:      	fmov	x25, d21
     3dc:      	ld1.s	{ v20 }[2], [x25]
     3e0:      	ld1.s	{ v20 }[3], [x27]
     3e4:      	ldr	s21, [x22]
     3e8:      	ld1.s	{ v21 }[1], [x21]
     3ec:      	ld1.s	{ v21 }[2], [x24]
     3f0:      	ld1.s	{ v21 }[3], [x23]
     3f4:      	add	x21, x9, x20, lsl #5
     3f8:      	stp	q21, q20, [x21]
     3fc:      	add	x20, x20, #0x1
     400:      	cmp	x20, #0x41
     404:      	b.ne	0x380 <ltmp0+0x380>
     408:      	mov	x20, #0x0               ; =0
     40c:      	ldp	q21, q20, [x9]
     410:      	fmul.4s	v20, v20, v20
     414:      	fmul.4s	v21, v21, v21
     418:      	ldp	q22, q23, [x9, #0x20]
     41c:      	fmul.4s	v23, v23, v23
     420:      	fmul.4s	v22, v22, v22
     424:      	ldp	q25, q24, [x9, #0x40]
     428:      	fmul.4s	v24, v24, v24
     42c:      	fmul.4s	v25, v25, v25
     430:      	ldp	q26, q27, [x9, #0x60]
     434:      	fmul.4s	v27, v27, v27
     438:      	fmul.4s	v26, v26, v26
     43c:      	add	x21, x9, x20, lsl #5
     440:      	ldp	q29, q28, [x21, #0x80]
     444:      	fmul.4s	v29, v29, v29
     448:      	fmul.4s	v28, v28, v28
     44c:      	fadd.4s	v20, v20, v28
     450:      	fadd.4s	v21, v21, v29
     454:      	ldp	q29, q28, [x21, #0xa0]
     458:      	fmul.4s	v29, v29, v29
     45c:      	fmul.4s	v28, v28, v28
     460:      	fadd.4s	v23, v23, v28
     464:      	fadd.4s	v22, v22, v29
     468:      	ldp	q29, q28, [x21, #0xc0]
     46c:      	fmul.4s	v29, v29, v29
     470:      	fmul.4s	v28, v28, v28
     474:      	fadd.4s	v24, v24, v28
     478:      	fadd.4s	v25, v25, v29
     47c:      	ldp	q29, q28, [x21, #0xe0]
     480:      	fmul.4s	v29, v29, v29
     484:      	fmul.4s	v28, v28, v28
     488:      	fadd.4s	v27, v27, v28
     48c:      	fadd.4s	v26, v26, v29
     490:      	add	x20, x20, #0x4
     494:      	cmp	x20, #0x3c
     498:      	b.lo	0x43c <ltmp0+0x43c>
     49c:      	mov	x20, #0x0               ; =0
     4a0:      	ldr	q29, [x9, #0x810]
     4a4:      	ldr	q28, [x9, #0x800]
     4a8:      	add	x21, x7, x20, lsl #2
     4ac:      	ld1r.4s	{ v30 }, [x21]
     4b0:      	add	x21, x14, x20, lsl #5
     4b4:      	stp	q30, q30, [x21]
     4b8:      	add	x20, x20, #0x1
     4bc:      	cmp	x20, #0x41
     4c0:      	b.ne	0x4a8 <ltmp0+0x4a8>
     4c4:      	mov	x20, #0x0               ; =0
     4c8:      	fmul.4s	v29, v29, v29
     4cc:      	fmul.4s	v28, v28, v28
     4d0:      	fadd.4s	v21, v21, v28
     4d4:      	fadd.4s	v20, v20, v29
     4d8:      	fadd.4s	v20, v23, v20
     4dc:      	fadd.4s	v21, v22, v21
     4e0:      	fadd.4s	v21, v25, v21
     4e4:      	fadd.4s	v20, v24, v20
     4e8:      	fadd.4s	v20, v27, v20
     4ec:      	fadd.4s	v21, v26, v21
     4f0:      	fdiv.4s	v21, v21, v5
     4f4:      	fdiv.4s	v20, v20, v5
     4f8:      	fadd.4s	v22, v20, v4
     4fc:      	fadd.4s	v20, v21, v4
     500:      	fsqrt.4s	v20, v20
     504:      	fsqrt.4s	v21, v22
     508:      	dup.2d	v22, x20
     50c:      	add.2d	v23, v22, v16
     510:      	add.2d	v24, v22, v18
     514:      	add.2d	v25, v22, v17
     518:      	add.2d	v22, v22, v19
     51c:      	lsl	x21, x20, #5
     520:      	add	x22, x9, x21
     524:      	ldp	q27, q26, [x22]
     528:      	fdiv.4s	v27, v27, v20
     52c:      	fdiv.4s	v26, v26, v21
     530:      	add	x21, x14, x21
     534:      	ldp	q28, q29, [x21]
     538:      	fmul.4s	v26, v26, v29
     53c:      	fmul.4s	v27, v27, v28
     540:      	shl.2d	v22, v22, #0x2
     544:      	shl.2d	v25, v25, #0x2
     548:      	shl.2d	v24, v24, #0x2
     54c:      	shl.2d	v23, v23, #0x2
     550:      	add.2d	v23, v7, v23
     554:      	add.2d	v22, v7, v22
     558:      	mov.d	x21, v22[1]
     55c:      	fmov	x22, d22
     560:      	str	s27, [x22]
     564:      	st1.s	{ v27 }[1], [x21]
     568:      	add.2d	v22, v7, v25
     56c:      	mov.d	x21, v22[1]
     570:      	fmov	x22, d22
     574:      	st1.s	{ v27 }[2], [x22]
     578:      	add.2d	v22, v7, v24
     57c:      	st1.s	{ v27 }[3], [x21]
     580:      	mov.d	x21, v22[1]
     584:      	fmov	x22, d22
     588:      	str	s26, [x22]
     58c:      	st1.s	{ v26 }[1], [x21]
     590:      	mov.d	x21, v23[1]
     594:      	fmov	x22, d23
     598:      	st1.s	{ v26 }[2], [x22]
     59c:      	st1.s	{ v26 }[3], [x21]
     5a0:      	add	x20, x20, #0x1
     5a4:      	cmp	x20, #0x41
     5a8:      	b.ne	0x508 <ltmp0+0x508>
     5ac:      	mov	x20, #0x0               ; =0
     5b0:      	orr	w21, w19, #0x10
     5b4:      	dup.4s	v16, w21
     5b8:      	orr.16b	v18, v16, v0
     5bc:      	orr.16b	v19, v16, v1
     5c0:      	umull2.2d	v16, v18, v2
     5c4:      	umull2.2d	v17, v19, v2
     5c8:      	umull.2d	v18, v18, v3
     5cc:      	umull.2d	v19, v19, v3
     5d0:      	dup.2d	v20, x20
     5d4:      	add.2d	v21, v20, v16
     5d8:      	add.2d	v22, v20, v18
     5dc:      	add.2d	v23, v20, v17
     5e0:      	add.2d	v20, v20, v19
     5e4:      	shl.2d	v20, v20, #0x2
     5e8:      	shl.2d	v23, v23, #0x2
     5ec:      	shl.2d	v22, v22, #0x2
     5f0:      	shl.2d	v21, v21, #0x2
     5f4:      	add.2d	v21, v6, v21
     5f8:      	add.2d	v22, v6, v22
     5fc:      	add.2d	v23, v6, v23
     600:      	add.2d	v20, v6, v20
     604:      	mov.d	x21, v20[1]
     608:      	fmov	x22, d20
     60c:      	mov.d	x23, v23[1]
     610:      	fmov	x24, d23
     614:      	mov.d	x25, v22[1]
     618:      	fmov	x26, d22
     61c:      	mov.d	x27, v21[1]
     620:      	ldr	s20, [x26]
     624:      	ld1.s	{ v20 }[1], [x25]
     628:      	fmov	x25, d21
     62c:      	ld1.s	{ v20 }[2], [x25]
     630:      	ld1.s	{ v20 }[3], [x27]
     634:      	ldr	s21, [x22]
     638:      	ld1.s	{ v21 }[1], [x21]
     63c:      	ld1.s	{ v21 }[2], [x24]
     640:      	ld1.s	{ v21 }[3], [x23]
     644:      	add	x21, x9, x20, lsl #5
     648:      	stp	q21, q20, [x21]
     64c:      	add	x20, x20, #0x1
     650:      	cmp	x20, #0x41
     654:      	b.ne	0x5d0 <ltmp0+0x5d0>
     658:      	mov	x20, #0x0               ; =0
     65c:      	ldp	q21, q20, [x9]
     660:      	fmul.4s	v20, v20, v20
     664:      	fmul.4s	v21, v21, v21
     668:      	ldp	q22, q23, [x9, #0x20]
     66c:      	fmul.4s	v23, v23, v23
     670:      	fmul.4s	v22, v22, v22
     674:      	ldp	q25, q24, [x9, #0x40]
     678:      	fmul.4s	v24, v24, v24
     67c:      	fmul.4s	v25, v25, v25
     680:      	ldp	q26, q27, [x9, #0x60]
     684:      	fmul.4s	v27, v27, v27
     688:      	fmul.4s	v26, v26, v26
     68c:      	add	x21, x9, x20, lsl #5
     690:      	ldp	q29, q28, [x21, #0x80]
     694:      	fmul.4s	v29, v29, v29
     698:      	fmul.4s	v28, v28, v28
     69c:      	fadd.4s	v20, v20, v28
     6a0:      	fadd.4s	v21, v21, v29
     6a4:      	ldp	q29, q28, [x21, #0xa0]
     6a8:      	fmul.4s	v29, v29, v29
     6ac:      	fmul.4s	v28, v28, v28
     6b0:      	fadd.4s	v23, v23, v28
     6b4:      	fadd.4s	v22, v22, v29
     6b8:      	ldp	q29, q28, [x21, #0xc0]
     6bc:      	fmul.4s	v29, v29, v29
     6c0:      	fmul.4s	v28, v28, v28
     6c4:      	fadd.4s	v24, v24, v28
     6c8:      	fadd.4s	v25, v25, v29
     6cc:      	ldp	q29, q28, [x21, #0xe0]
     6d0:      	fmul.4s	v29, v29, v29
     6d4:      	fmul.4s	v28, v28, v28
     6d8:      	fadd.4s	v27, v27, v28
     6dc:      	fadd.4s	v26, v26, v29
     6e0:      	add	x20, x20, #0x4
     6e4:      	cmp	x20, #0x3c
     6e8:      	b.lo	0x68c <ltmp0+0x68c>
     6ec:      	mov	x20, #0x0               ; =0
     6f0:      	ldr	q29, [x9, #0x810]
     6f4:      	ldr	q28, [x9, #0x800]
     6f8:      	add	x21, x7, x20, lsl #2
     6fc:      	ld1r.4s	{ v30 }, [x21]
     700:      	add	x21, x14, x20, lsl #5
     704:      	stp	q30, q30, [x21]
     708:      	add	x20, x20, #0x1
     70c:      	cmp	x20, #0x41
     710:      	b.ne	0x6f8 <ltmp0+0x6f8>
     714:      	mov	x20, #0x0               ; =0
     718:      	fmul.4s	v29, v29, v29
     71c:      	fmul.4s	v28, v28, v28
     720:      	fadd.4s	v21, v21, v28
     724:      	fadd.4s	v20, v20, v29
     728:      	fadd.4s	v20, v23, v20
     72c:      	fadd.4s	v21, v22, v21
     730:      	fadd.4s	v21, v25, v21
     734:      	fadd.4s	v20, v24, v20
     738:      	fadd.4s	v20, v27, v20
     73c:      	fadd.4s	v21, v26, v21
     740:      	fdiv.4s	v21, v21, v5
     744:      	fdiv.4s	v20, v20, v5
     748:      	fadd.4s	v22, v20, v4
     74c:      	fadd.4s	v20, v21, v4
     750:      	fsqrt.4s	v20, v20
     754:      	fsqrt.4s	v21, v22
     758:      	dup.2d	v22, x20
     75c:      	add.2d	v23, v22, v16
     760:      	add.2d	v24, v22, v18
     764:      	add.2d	v25, v22, v17
     768:      	add.2d	v22, v22, v19
     76c:      	lsl	x21, x20, #5
     770:      	add	x22, x9, x21
     774:      	ldp	q27, q26, [x22]
     778:      	fdiv.4s	v27, v27, v20
     77c:      	fdiv.4s	v26, v26, v21
     780:      	add	x21, x14, x21
     784:      	ldp	q28, q29, [x21]
     788:      	fmul.4s	v26, v26, v29
     78c:      	fmul.4s	v27, v27, v28
     790:      	shl.2d	v22, v22, #0x2
     794:      	shl.2d	v25, v25, #0x2
     798:      	shl.2d	v24, v24, #0x2
     79c:      	shl.2d	v23, v23, #0x2
     7a0:      	add.2d	v23, v7, v23
     7a4:      	add.2d	v22, v7, v22
     7a8:      	mov.d	x21, v22[1]
     7ac:      	fmov	x22, d22
     7b0:      	str	s27, [x22]
     7b4:      	st1.s	{ v27 }[1], [x21]
     7b8:      	add.2d	v22, v7, v25
     7bc:      	mov.d	x21, v22[1]
     7c0:      	fmov	x22, d22
     7c4:      	st1.s	{ v27 }[2], [x22]
     7c8:      	add.2d	v22, v7, v24
     7cc:      	st1.s	{ v27 }[3], [x21]
     7d0:      	mov.d	x21, v22[1]
     7d4:      	fmov	x22, d22
     7d8:      	str	s26, [x22]
     7dc:      	st1.s	{ v26 }[1], [x21]
     7e0:      	mov.d	x21, v23[1]
     7e4:      	fmov	x22, d23
     7e8:      	st1.s	{ v26 }[2], [x22]
     7ec:      	st1.s	{ v26 }[3], [x21]
     7f0:      	add	x20, x20, #0x1
     7f4:      	cmp	x20, #0x41
     7f8:      	b.ne	0x758 <ltmp0+0x758>
     7fc:      	mov	x20, #0x0               ; =0
     800:      	orr	w19, w19, #0x18
     804:      	dup.4s	v16, w19
     808:      	orr.16b	v18, v16, v0
     80c:      	orr.16b	v19, v16, v1
     810:      	umull2.2d	v16, v18, v2
     814:      	umull2.2d	v17, v19, v2
     818:      	umull.2d	v18, v18, v3
     81c:      	umull.2d	v19, v19, v3
     820:      	dup.2d	v20, x20
     824:      	add.2d	v21, v20, v16
     828:      	add.2d	v22, v20, v18
     82c:      	add.2d	v23, v20, v17
     830:      	add.2d	v20, v20, v19
     834:      	shl.2d	v20, v20, #0x2
     838:      	shl.2d	v23, v23, #0x2
     83c:      	shl.2d	v22, v22, #0x2
     840:      	shl.2d	v21, v21, #0x2
     844:      	add.2d	v21, v6, v21
     848:      	add.2d	v22, v6, v22
     84c:      	add.2d	v23, v6, v23
     850:      	add.2d	v20, v6, v20
     854:      	mov.d	x19, v20[1]
     858:      	fmov	x21, d20
     85c:      	mov.d	x22, v23[1]
     860:      	fmov	x23, d23
     864:      	mov.d	x24, v22[1]
     868:      	fmov	x25, d22
     86c:      	mov.d	x26, v21[1]
     870:      	ldr	s20, [x25]
     874:      	ld1.s	{ v20 }[1], [x24]
     878:      	fmov	x24, d21
     87c:      	ld1.s	{ v20 }[2], [x24]
     880:      	ld1.s	{ v20 }[3], [x26]
     884:      	ldr	s21, [x21]
     888:      	ld1.s	{ v21 }[1], [x19]
     88c:      	ld1.s	{ v21 }[2], [x23]
     890:      	ld1.s	{ v21 }[3], [x22]
     894:      	add	x19, x9, x20, lsl #5
     898:      	stp	q21, q20, [x19]
     89c:      	add	x20, x20, #0x1
     8a0:      	cmp	x20, #0x41
     8a4:      	b.ne	0x820 <ltmp0+0x820>
     8a8:      	mov	x19, #0x0               ; =0
     8ac:      	ldp	q20, q6, [x9]
     8b0:      	fmul.4s	v6, v6, v6
     8b4:      	fmul.4s	v20, v20, v20
     8b8:      	ldp	q21, q22, [x9, #0x20]
     8bc:      	fmul.4s	v22, v22, v22
     8c0:      	fmul.4s	v21, v21, v21
     8c4:      	ldp	q24, q23, [x9, #0x40]
     8c8:      	fmul.4s	v23, v23, v23
     8cc:      	fmul.4s	v24, v24, v24
     8d0:      	ldp	q25, q26, [x9, #0x60]
     8d4:      	fmul.4s	v26, v26, v26
     8d8:      	fmul.4s	v25, v25, v25
     8dc:      	add	x20, x9, x19, lsl #5
     8e0:      	ldp	q28, q27, [x20, #0x80]
     8e4:      	fmul.4s	v28, v28, v28
     8e8:      	fmul.4s	v27, v27, v27
     8ec:      	fadd.4s	v6, v6, v27
     8f0:      	fadd.4s	v20, v20, v28
     8f4:      	ldp	q28, q27, [x20, #0xa0]
     8f8:      	fmul.4s	v28, v28, v28
     8fc:      	fmul.4s	v27, v27, v27
     900:      	fadd.4s	v22, v22, v27
     904:      	fadd.4s	v21, v21, v28
     908:      	ldp	q28, q27, [x20, #0xc0]
     90c:      	fmul.4s	v28, v28, v28
     910:      	fmul.4s	v27, v27, v27
     914:      	fadd.4s	v23, v23, v27
     918:      	fadd.4s	v24, v24, v28
     91c:      	ldp	q28, q27, [x20, #0xe0]
     920:      	fmul.4s	v28, v28, v28
     924:      	fmul.4s	v27, v27, v27
     928:      	fadd.4s	v26, v26, v27
     92c:      	fadd.4s	v25, v25, v28
     930:      	add	x19, x19, #0x4
     934:      	cmp	x19, #0x3c
     938:      	b.lo	0x8dc <ltmp0+0x8dc>
     93c:      	mov	x19, #0x0               ; =0
     940:      	ldr	q28, [x9, #0x810]
     944:      	ldr	q27, [x9, #0x800]
     948:      	add	x20, x7, x19, lsl #2
     94c:      	ld1r.4s	{ v29 }, [x20]
     950:      	add	x20, x14, x19, lsl #5
     954:      	stp	q29, q29, [x20]
     958:      	add	x19, x19, #0x1
     95c:      	cmp	x19, #0x41
     960:      	b.ne	0x948 <ltmp0+0x948>
     964:      	mov	x7, #0x0                ; =0
     968:      	fmul.4s	v28, v28, v28
     96c:      	fmul.4s	v27, v27, v27
     970:      	fadd.4s	v20, v20, v27
     974:      	fadd.4s	v6, v6, v28
     978:      	fadd.4s	v6, v22, v6
     97c:      	fadd.4s	v20, v21, v20
     980:      	fadd.4s	v20, v24, v20
     984:      	fadd.4s	v6, v23, v6
     988:      	fadd.4s	v6, v26, v6
     98c:      	fadd.4s	v20, v25, v20
     990:      	fdiv.4s	v20, v20, v5
     994:      	fdiv.4s	v5, v6, v5
     998:      	fadd.4s	v5, v5, v4
     99c:      	fadd.4s	v4, v20, v4
     9a0:      	fsqrt.4s	v4, v4
     9a4:      	fsqrt.4s	v5, v5
     9a8:      	dup.2d	v6, x7
     9ac:      	add.2d	v20, v6, v16
     9b0:      	add.2d	v21, v6, v18
     9b4:      	add.2d	v22, v6, v17
     9b8:      	add.2d	v6, v6, v19
     9bc:      	lsl	x19, x7, #5
     9c0:      	add	x20, x9, x19
     9c4:      	ldp	q24, q23, [x20]
     9c8:      	fdiv.4s	v24, v24, v4
     9cc:      	fdiv.4s	v23, v23, v5
     9d0:      	add	x19, x14, x19
     9d4:      	ldp	q25, q26, [x19]
     9d8:      	fmul.4s	v23, v23, v26
     9dc:      	fmul.4s	v24, v24, v25
     9e0:      	shl.2d	v6, v6, #0x2
     9e4:      	shl.2d	v22, v22, #0x2
     9e8:      	shl.2d	v21, v21, #0x2
     9ec:      	shl.2d	v20, v20, #0x2
     9f0:      	add.2d	v20, v7, v20
     9f4:      	add.2d	v6, v7, v6
     9f8:      	mov.d	x19, v6[1]
     9fc:      	fmov	x20, d6
     a00:      	str	s24, [x20]
     a04:      	st1.s	{ v24 }[1], [x19]
     a08:      	add.2d	v6, v7, v22
     a0c:      	mov.d	x19, v6[1]
     a10:      	fmov	x20, d6
     a14:      	st1.s	{ v24 }[2], [x20]
     a18:      	add.2d	v6, v7, v21
     a1c:      	st1.s	{ v24 }[3], [x19]
     a20:      	mov.d	x19, v6[1]
     a24:      	fmov	x20, d6
     a28:      	str	s23, [x20]
     a2c:      	st1.s	{ v23 }[1], [x19]
     a30:      	mov.d	x19, v20[1]
     a34:      	fmov	x20, d20
     a38:      	st1.s	{ v23 }[2], [x20]
     a3c:      	st1.s	{ v23 }[3], [x19]
     a40:      	add	x7, x7, #0x1
     a44:      	cmp	x7, #0x41
     a48:      	b.ne	0x9a8 <ltmp0+0x9a8>
     a4c:      	b	0x80 <ltmp0+0x80>
     a50:      	lsr	x7, x19, #3
     a54:      	cmp	x19, #0x8
     a58:      	b.lo	0xcd4 <ltmp0+0xcd4>
     a5c:      	mov	w20, #0x0               ; =0
     a60:      	ldr	x21, [x0]
     a64:      	ldr	x22, [x0, #0x10]
     a68:      	lsl	w23, w6, #5
     a6c:      	ldr	x24, [x0, #0x30]
     a70:      	mov	x25, #0x0               ; =0
     a74:      	add	w26, w23, w20, lsl #3
     a78:      	dup.4s	v6, w26
     a7c:      	orr.16b	v16, v6, v0
     a80:      	orr.16b	v17, v6, v1
     a84:      	umull2.2d	v6, v16, v2
     a88:      	umull2.2d	v7, v17, v2
     a8c:      	umull.2d	v16, v16, v3
     a90:      	umull.2d	v17, v17, v3
     a94:      	dup.2d	v18, x25
     a98:      	add.2d	v19, v18, v6
     a9c:      	add.2d	v20, v18, v16
     aa0:      	add.2d	v21, v18, v7
     aa4:      	add.2d	v18, v18, v17
     aa8:      	shl.2d	v18, v18, #0x2
     aac:      	shl.2d	v21, v21, #0x2
     ab0:      	shl.2d	v20, v20, #0x2
     ab4:      	shl.2d	v19, v19, #0x2
     ab8:      	dup.2d	v22, x21
     abc:      	add.2d	v19, v22, v19
     ac0:      	add.2d	v20, v22, v20
     ac4:      	add.2d	v21, v22, v21
     ac8:      	add.2d	v18, v22, v18
     acc:      	mov.d	x26, v18[1]
     ad0:      	fmov	x27, d18
     ad4:      	mov.d	x28, v21[1]
     ad8:      	fmov	x30, d21
     adc:      	mov.d	x12, v20[1]
     ae0:      	fmov	x13, d20
     ae4:      	mov.d	x2, v19[1]
     ae8:      	ldr	s18, [x13]
     aec:      	ld1.s	{ v18 }[1], [x12]
     af0:      	fmov	x12, d19
     af4:      	ld1.s	{ v18 }[2], [x12]
     af8:      	ld1.s	{ v18 }[3], [x2]
     afc:      	ldr	s19, [x27]
     b00:      	ld1.s	{ v19 }[1], [x26]
     b04:      	ld1.s	{ v19 }[2], [x30]
     b08:      	ld1.s	{ v19 }[3], [x28]
     b0c:      	add	x12, x9, x25, lsl #5
     b10:      	stp	q19, q18, [x12]
     b14:      	add	x25, x25, #0x1
     b18:      	cmp	x25, #0x41
     b1c:      	b.ne	0xa94 <ltmp0+0xa94>
     b20:      	mov	x25, #0x0               ; =0
     b24:      	ldp	q19, q18, [x9]
     b28:      	fmul.4s	v18, v18, v18
     b2c:      	fmul.4s	v19, v19, v19
     b30:      	ldp	q20, q21, [x9, #0x20]
     b34:      	fmul.4s	v21, v21, v21
     b38:      	fmul.4s	v20, v20, v20
     b3c:      	ldp	q23, q22, [x9, #0x40]
     b40:      	fmul.4s	v22, v22, v22
     b44:      	fmul.4s	v23, v23, v23
     b48:      	ldp	q24, q25, [x9, #0x60]
     b4c:      	fmul.4s	v25, v25, v25
     b50:      	fmul.4s	v24, v24, v24
     b54:      	add	x12, x9, x25, lsl #5
     b58:      	ldp	q27, q26, [x12, #0x80]
     b5c:      	fmul.4s	v27, v27, v27
     b60:      	fmul.4s	v26, v26, v26
     b64:      	fadd.4s	v18, v18, v26
     b68:      	fadd.4s	v19, v19, v27
     b6c:      	ldp	q27, q26, [x12, #0xa0]
     b70:      	fmul.4s	v27, v27, v27
     b74:      	fmul.4s	v26, v26, v26
     b78:      	fadd.4s	v21, v21, v26
     b7c:      	fadd.4s	v20, v20, v27
     b80:      	ldp	q27, q26, [x12, #0xc0]
     b84:      	fmul.4s	v27, v27, v27
     b88:      	fmul.4s	v26, v26, v26
     b8c:      	fadd.4s	v22, v22, v26
     b90:      	fadd.4s	v23, v23, v27
     b94:      	ldp	q27, q26, [x12, #0xe0]
     b98:      	fmul.4s	v27, v27, v27
     b9c:      	fmul.4s	v26, v26, v26
     ba0:      	fadd.4s	v25, v25, v26
     ba4:      	fadd.4s	v24, v24, v27
     ba8:      	add	x25, x25, #0x4
     bac:      	cmp	x25, #0x3c
     bb0:      	b.lo	0xb54 <ltmp0+0xb54>
     bb4:      	mov	x25, #0x0               ; =0
     bb8:      	ldr	q27, [x9, #0x810]
     bbc:      	ldr	q26, [x9, #0x800]
     bc0:      	add	x12, x22, x25, lsl #2
     bc4:      	ld1r.4s	{ v28 }, [x12]
     bc8:      	add	x12, x14, x25, lsl #5
     bcc:      	stp	q28, q28, [x12]
     bd0:      	add	x25, x25, #0x1
     bd4:      	cmp	x25, #0x41
     bd8:      	b.ne	0xbc0 <ltmp0+0xbc0>
     bdc:      	mov	x25, #0x0               ; =0
     be0:      	fmul.4s	v27, v27, v27
     be4:      	fmul.4s	v26, v26, v26
     be8:      	fadd.4s	v19, v19, v26
     bec:      	fadd.4s	v18, v18, v27
     bf0:      	fadd.4s	v18, v21, v18
     bf4:      	fadd.4s	v19, v20, v19
     bf8:      	fadd.4s	v19, v23, v19
     bfc:      	fadd.4s	v18, v22, v18
     c00:      	fadd.4s	v18, v25, v18
     c04:      	fadd.4s	v19, v24, v19
     c08:      	fdiv.4s	v19, v19, v5
     c0c:      	fdiv.4s	v18, v18, v5
     c10:      	fadd.4s	v20, v18, v4
     c14:      	fadd.4s	v18, v19, v4
     c18:      	fsqrt.4s	v18, v18
     c1c:      	fsqrt.4s	v19, v20
     c20:      	dup.2d	v20, x25
     c24:      	add.2d	v21, v20, v6
     c28:      	add.2d	v22, v20, v16
     c2c:      	add.2d	v23, v20, v7
     c30:      	add.2d	v20, v20, v17
     c34:      	lsl	x12, x25, #5
     c38:      	add	x13, x9, x12
     c3c:      	ldp	q25, q24, [x13]
     c40:      	fdiv.4s	v25, v25, v18
     c44:      	fdiv.4s	v24, v24, v19
     c48:      	add	x12, x14, x12
     c4c:      	ldp	q26, q27, [x12]
     c50:      	fmul.4s	v24, v24, v27
     c54:      	fmul.4s	v25, v25, v26
     c58:      	shl.2d	v20, v20, #0x2
     c5c:      	shl.2d	v23, v23, #0x2
     c60:      	shl.2d	v22, v22, #0x2
     c64:      	shl.2d	v21, v21, #0x2
     c68:      	dup.2d	v26, x24
     c6c:      	add.2d	v21, v26, v21
     c70:      	add.2d	v20, v26, v20
     c74:      	mov.d	x12, v20[1]
     c78:      	fmov	x13, d20
     c7c:      	str	s25, [x13]
     c80:      	st1.s	{ v25 }[1], [x12]
     c84:      	add.2d	v20, v26, v23
     c88:      	mov.d	x12, v20[1]
     c8c:      	fmov	x13, d20
     c90:      	st1.s	{ v25 }[2], [x13]
     c94:      	add.2d	v20, v26, v22
     c98:      	st1.s	{ v25 }[3], [x12]
     c9c:      	mov.d	x12, v20[1]
     ca0:      	fmov	x13, d20
     ca4:      	str	s24, [x13]
     ca8:      	st1.s	{ v24 }[1], [x12]
     cac:      	mov.d	x12, v21[1]
     cb0:      	fmov	x13, d21
     cb4:      	st1.s	{ v24 }[2], [x13]
     cb8:      	st1.s	{ v24 }[3], [x12]
     cbc:      	add	x25, x25, #0x1
     cc0:      	cmp	x25, #0x41
     cc4:      	b.ne	0xc20 <ltmp0+0xc20>
     cc8:      	add	w20, w20, #0x1
     ccc:      	cmp	w20, w7
     cd0:      	b.ne	0xa70 <ltmp0+0xa70>
     cd4:      	and	w19, w19, #0x7
     cd8:      	cbz	w19, 0x80 <ltmp0+0x80>
     cdc:      	dup.4s	v7, w19
     ce0:      	cmhi.4s	v6, v7, v0
     ce4:      	cmhi.4s	v7, v7, v1
     ce8:      	uzp1.8h	v21, v7, v6
     cec:      	umaxv.8h	h16, v21
     cf0:      	fmov	w12, s16
     cf4:      	tbz	w12, #0x0, 0x80 <ltmp0+0x80>
     cf8:      	mov	x20, #0x0               ; =0
     cfc:      	ldr	x21, [x0]
     d00:      	ldr	x19, [x0, #0x10]
     d04:      	lsl	w12, w7, #3
     d08:      	orr	w12, w12, w6, lsl #5
     d0c:      	dup.4s	v16, w12
     d10:      	ldr	x7, [x0, #0x30]
     d14:      	orr.16b	v17, v16, v1
     d18:      	orr.16b	v16, v16, v0
     d1c:      	and.16b	v18, v6, v16
     d20:      	and.16b	v19, v7, v17
     d24:      	umull2.2d	v16, v18, v2
     d28:      	umull2.2d	v17, v19, v2
     d2c:      	umull.2d	v18, v18, v3
     d30:      	umull.2d	v19, v19, v3
     d34:      	b	0xd58 <ltmp0+0xd58>
     d38:      	add	x12, x9, x20, lsl #5
     d3c:      	ldp	q24, q25, [x12]
     d40:      	bif.16b	v23, v25, v6
     d44:      	bif.16b	v22, v24, v7
     d48:      	stp	q22, q23, [x12]
     d4c:      	add	x20, x20, #0x1
     d50:      	cmp	x20, #0x41
     d54:      	b.eq	0xe58 <ltmp0+0xe58>
     d58:      	ldr	q20, [x17]
     d5c:      	and.16b	v20, v21, v20
     d60:      	addv.8h	h20, v20
     d64:      	fmov	w22, s20
     d68:      	dup.2d	v24, x20
     d6c:      	add.2d	v22, v24, v19
     d70:      	shl.2d	v22, v22, #0x2
     d74:      	dup.2d	v25, x21
     d78:      	add.2d	v26, v25, v22
     d7c:      	movi.2d	v22, #0000000000000000
     d80:      	movi.2d	v23, #0000000000000000
     d84:      	tbnz	w22, #0x0, 0xdd0 <ltmp0+0xdd0>
     d88:      	and	w22, w22, #0xff
     d8c:      	tbnz	w22, #0x1, 0xde0 <ltmp0+0xde0>
     d90:      	add.2d	v26, v24, v17
     d94:      	shl.2d	v26, v26, #0x2
     d98:      	add.2d	v26, v25, v26
     d9c:      	tbnz	w22, #0x2, 0xdf8 <ltmp0+0xdf8>
     da0:      	tbnz	w22, #0x3, 0xe04 <ltmp0+0xe04>
     da4:      	add.2d	v26, v24, v18
     da8:      	shl.2d	v26, v26, #0x2
     dac:      	add.2d	v26, v25, v26
     db0:      	tbnz	w22, #0x4, 0xe1c <ltmp0+0xe1c>
     db4:      	tbnz	w22, #0x5, 0xe28 <ltmp0+0xe28>
     db8:      	add.2d	v24, v24, v16
     dbc:      	shl.2d	v24, v24, #0x2
     dc0:      	add.2d	v24, v25, v24
     dc4:      	tbnz	w22, #0x6, 0xe40 <ltmp0+0xe40>
     dc8:      	tbz	w22, #0x7, 0xd38 <ltmp0+0xd38>
     dcc:      	b	0xe4c <ltmp0+0xe4c>
     dd0:      	fmov	x12, d26
     dd4:      	ldr	s22, [x12]
     dd8:      	and	w22, w22, #0xff
     ddc:      	tbz	w22, #0x1, 0xd90 <ltmp0+0xd90>
     de0:      	mov.d	x12, v26[1]
     de4:      	ld1.s	{ v22 }[1], [x12]
     de8:      	add.2d	v26, v24, v17
     dec:      	shl.2d	v26, v26, #0x2
     df0:      	add.2d	v26, v25, v26
     df4:      	tbz	w22, #0x2, 0xda0 <ltmp0+0xda0>
     df8:      	fmov	x12, d26
     dfc:      	ld1.s	{ v22 }[2], [x12]
     e00:      	tbz	w22, #0x3, 0xda4 <ltmp0+0xda4>
     e04:      	mov.d	x12, v26[1]
     e08:      	ld1.s	{ v22 }[3], [x12]
     e0c:      	add.2d	v26, v24, v18
     e10:      	shl.2d	v26, v26, #0x2
     e14:      	add.2d	v26, v25, v26
     e18:      	tbz	w22, #0x4, 0xdb4 <ltmp0+0xdb4>
     e1c:      	fmov	x12, d26
     e20:      	ld1.s	{ v23 }[0], [x12]
     e24:      	tbz	w22, #0x5, 0xdb8 <ltmp0+0xdb8>
     e28:      	mov.d	x12, v26[1]
     e2c:      	ld1.s	{ v23 }[1], [x12]
     e30:      	add.2d	v24, v24, v16
     e34:      	shl.2d	v24, v24, #0x2
     e38:      	add.2d	v24, v25, v24
     e3c:      	tbz	w22, #0x6, 0xdc8 <ltmp0+0xdc8>
     e40:      	fmov	x12, d24
     e44:      	ld1.s	{ v23 }[2], [x12]
     e48:      	tbz	w22, #0x7, 0xd38 <ltmp0+0xd38>
     e4c:      	mov.d	x12, v24[1]
     e50:      	ld1.s	{ v23 }[3], [x12]
     e54:      	b	0xd38 <ltmp0+0xd38>
     e58:      	ldp	q22, q21, [x9]
     e5c:      	fmul.4s	v23, v22, v22
     e60:      	fmul.4s	v21, v21, v21
     e64:      	ldp	q24, q22, [x9, #0x20]
     e68:      	fmul.4s	v24, v24, v24
     e6c:      	fmul.4s	v25, v22, v22
     e70:      	ldp	q26, q22, [x9, #0x40]
     e74:      	fmul.4s	v27, v26, v26
     e78:      	fmul.4s	v29, v22, v22
     e7c:      	ldp	q26, q22, [x9, #0x60]
     e80:      	fmul.4s	v30, v26, v26
     e84:      	fmul.4s	v31, v22, v22
     e88:      	and.16b	v22, v6, v21
     e8c:      	and.16b	v28, v7, v23
     e90:      	and.16b	v26, v6, v25
     e94:      	and.16b	v25, v7, v24
     e98:      	and.16b	v21, v6, v29
     e9c:      	and.16b	v27, v7, v27
     ea0:      	and.16b	v24, v6, v31
     ea4:      	and.16b	v23, v7, v30
     ea8:      	ldr	x20, [sp, #0x10]
     eac:      	mov	w21, #0x4               ; =4
     eb0:      	ldp	q30, q29, [x20, #-0x60]
     eb4:      	and.16b	v30, v7, v30
     eb8:      	and.16b	v29, v6, v29
     ebc:      	fmul.4s	v29, v29, v29
     ec0:      	fmul.4s	v30, v30, v30
     ec4:      	fadd.4s	v30, v28, v30
     ec8:      	fadd.4s	v29, v22, v29
     ecc:      	ldp	q8, q31, [x20, #-0x40]
     ed0:      	and.16b	v8, v7, v8
     ed4:      	and.16b	v31, v6, v31
     ed8:      	fmul.4s	v31, v31, v31
     edc:      	fmul.4s	v8, v8, v8
     ee0:      	fadd.4s	v8, v25, v8
     ee4:      	fadd.4s	v31, v26, v31
     ee8:      	ldp	q10, q9, [x20, #-0x20]
     eec:      	and.16b	v10, v7, v10
     ef0:      	and.16b	v9, v6, v9
     ef4:      	fmul.4s	v9, v9, v9
     ef8:      	fmul.4s	v10, v10, v10
     efc:      	fadd.4s	v10, v27, v10
     f00:      	fadd.4s	v9, v21, v9
     f04:      	ldp	q12, q11, [x20], #0x80
     f08:      	and.16b	v12, v7, v12
     f0c:      	and.16b	v11, v6, v11
     f10:      	fmul.4s	v11, v11, v11
     f14:      	fmul.4s	v12, v12, v12
     f18:      	fadd.4s	v12, v23, v12
     f1c:      	fadd.4s	v11, v24, v11
     f20:      	bit.16b	v22, v29, v6
     f24:      	bit.16b	v28, v30, v7
     f28:      	bit.16b	v26, v31, v6
     f2c:      	bit.16b	v25, v8, v7
     f30:      	bit.16b	v21, v9, v6
     f34:      	bit.16b	v27, v10, v7
     f38:      	bit.16b	v24, v11, v6
     f3c:      	bit.16b	v23, v12, v7
     f40:      	cmp	x21, #0x3c
     f44:      	add	x21, x21, #0x4
     f48:      	b.lo	0xeb0 <ltmp0+0xeb0>
     f4c:      	mov	x20, #0x0               ; =0
     f50:      	ldr	q29, [x9, #0x810]
     f54:      	ldr	q30, [x9, #0x800]
     f58:      	add	x12, x19, x20, lsl #2
     f5c:      	ld1r.4s	{ v31 }, [x12]
     f60:      	add	x12, x14, x20, lsl #5
     f64:      	ldp	q8, q9, [x12]
     f68:      	bit.16b	v9, v31, v6
     f6c:      	bif.16b	v31, v8, v7
     f70:      	stp	q31, q9, [x12]
     f74:      	add	x20, x20, #0x1
     f78:      	cmp	x20, #0x41
     f7c:      	b.ne	0xf58 <ltmp0+0xf58>
     f80:      	mov	x19, #0x0               ; =0
     f84:      	and.16b	v30, v7, v30
     f88:      	and.16b	v29, v6, v29
     f8c:      	fmul.4s	v29, v29, v29
     f90:      	fmul.4s	v30, v30, v30
     f94:      	fadd.4s	v28, v28, v30
     f98:      	fadd.4s	v22, v22, v29
     f9c:      	fadd.4s	v22, v26, v22
     fa0:      	fadd.4s	v25, v25, v28
     fa4:      	fadd.4s	v25, v27, v25
     fa8:      	fadd.4s	v21, v21, v22
     fac:      	fadd.4s	v21, v24, v21
     fb0:      	fadd.4s	v22, v23, v25
     fb4:      	fdiv.4s	v22, v22, v5
     fb8:      	fdiv.4s	v5, v21, v5
     fbc:      	fadd.4s	v5, v5, v4
     fc0:      	fadd.4s	v4, v22, v4
     fc4:      	fsqrt.4s	v21, v4
     fc8:      	fsqrt.4s	v4, v5
     fcc:      	and.16b	v4, v6, v4
     fd0:      	and.16b	v5, v7, v21
     fd4:      	b	0xfe4 <ltmp0+0xfe4>
     fd8:      	add	x19, x19, #0x1
     fdc:      	cmp	x19, #0x41
     fe0:      	b.eq	0x80 <ltmp0+0x80>
     fe4:      	fmov	w20, s20
     fe8:      	dup.2d	v21, x19
     fec:      	add.2d	v22, v21, v19
     ff0:      	lsl	x12, x19, #5
     ff4:      	add	x13, x9, x12
     ff8:      	ldp	q24, q23, [x13]
     ffc:      	and.16b	v24, v7, v24
    1000:      	fdiv.4s	v25, v24, v5
    1004:      	add	x12, x14, x12
    1008:      	ldp	q26, q24, [x12]
    100c:      	and.16b	v26, v7, v26
    1010:      	fmul.4s	v25, v25, v26
    1014:      	shl.2d	v26, v22, #0x2
    1018:      	dup.2d	v22, x7
    101c:      	add.2d	v26, v22, v26
    1020:      	tbnz	w20, #0x0, 0x1084 <ltmp0+0x1084>
    1024:      	and	w20, w20, #0xff
    1028:      	tbnz	w20, #0x1, 0x1094 <ltmp0+0x1094>
    102c:      	add.2d	v26, v21, v17
    1030:      	shl.2d	v26, v26, #0x2
    1034:      	add.2d	v26, v22, v26
    1038:      	tbnz	w20, #0x2, 0x10ac <ltmp0+0x10ac>
    103c:      	tbz	w20, #0x3, 0x1048 <ltmp0+0x1048>
    1040:      	mov.d	x12, v26[1]
    1044:      	st1.s	{ v25 }[3], [x12]
    1048:      	add.2d	v25, v21, v18
    104c:      	and.16b	v23, v6, v23
    1050:      	fdiv.4s	v23, v23, v4
    1054:      	and.16b	v24, v6, v24
    1058:      	fmul.4s	v23, v23, v24
    105c:      	shl.2d	v24, v25, #0x2
    1060:      	add.2d	v24, v22, v24
    1064:      	tbnz	w20, #0x4, 0x10bc <ltmp0+0x10bc>
    1068:      	tbnz	w20, #0x5, 0x10c8 <ltmp0+0x10c8>
    106c:      	add.2d	v21, v21, v16
    1070:      	shl.2d	v21, v21, #0x2
    1074:      	add.2d	v21, v22, v21
    1078:      	tbnz	w20, #0x6, 0x10e0 <ltmp0+0x10e0>
    107c:      	tbz	w20, #0x7, 0xfd8 <ltmp0+0xfd8>
    1080:      	b	0x10ec <ltmp0+0x10ec>
    1084:      	fmov	x12, d26
    1088:      	str	s25, [x12]
    108c:      	and	w20, w20, #0xff
    1090:      	tbz	w20, #0x1, 0x102c <ltmp0+0x102c>
    1094:      	mov.d	x12, v26[1]
    1098:      	st1.s	{ v25 }[1], [x12]
    109c:      	add.2d	v26, v21, v17
    10a0:      	shl.2d	v26, v26, #0x2
    10a4:      	add.2d	v26, v22, v26
    10a8:      	tbz	w20, #0x2, 0x103c <ltmp0+0x103c>
    10ac:      	fmov	x12, d26
    10b0:      	st1.s	{ v25 }[2], [x12]
    10b4:      	tbnz	w20, #0x3, 0x1040 <ltmp0+0x1040>
    10b8:      	b	0x1048 <ltmp0+0x1048>
    10bc:      	fmov	x12, d24
    10c0:      	str	s23, [x12]
    10c4:      	tbz	w20, #0x5, 0x106c <ltmp0+0x106c>
    10c8:      	mov.d	x12, v24[1]
    10cc:      	st1.s	{ v23 }[1], [x12]
    10d0:      	add.2d	v21, v21, v16
    10d4:      	shl.2d	v21, v21, #0x2
    10d8:      	add.2d	v21, v22, v21
    10dc:      	tbz	w20, #0x6, 0x107c <ltmp0+0x107c>
    10e0:      	fmov	x12, d21
    10e4:      	st1.s	{ v23 }[2], [x12]
    10e8:      	tbz	w20, #0x7, 0xfd8 <ltmp0+0xfd8>
    10ec:      	mov.d	x12, v21[1]
    10f0:      	st1.s	{ v23 }[3], [x12]
    10f4:      	b	0xfd8 <ltmp0+0xfd8>
    10f8:      	ldr	x9, [sp, #0x8]
    10fc:      	stp	w6, w5, [x9]
    1100:      	str	w4, [x9, #0x8]
    1104:      	mov	w8, #0x18               ; =24
    1108:      	str	w8, [x9, #0x24]
    110c:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    1110:      	add	sp, sp, #0x60
    1114:      	ldp	x29, x30, [sp, #0x80]
    1118:      	ldp	x20, x19, [sp, #0x70]
    111c:      	ldp	x22, x21, [sp, #0x60]
    1120:      	ldp	x24, x23, [sp, #0x50]
    1124:      	ldp	x26, x25, [sp, #0x40]
    1128:      	ldp	x28, x27, [sp, #0x30]
    112c:      	ldp	d9, d8, [sp, #0x20]
    1130:      	ldp	d11, d10, [sp, #0x10]
    1134:      	ldp	d13, d12, [sp], #0x90
    1138:      	ret


/private/tmp/luisa-native-rows.LuX3yX/capture-v3/gelu_residual-1024x4097-l8/object/tile_xir_w8_80782_1788919118016089_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x90]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x24, x23, [sp, #0x50]
      18:      	stp	x22, x21, [sp, #0x60]
      1c:      	stp	x20, x19, [sp, #0x70]
      20:      	stp	x29, x30, [sp, #0x80]
      24:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      28:      	sub	sp, sp, #0x170
      2c:      	ldr	x22, [x0]
      30:      	ldr	x24, [x0, #0x10]
      34:      	ldr	x19, [x0, #0x30]
      38:      	ldr	w8, [x1]
      3c:      	ldr	w9, [x1, #0x24]
      40:      	add	w8, w9, w8, lsl #5
      44:      	lsr	w8, w8, #3
      48:      	fmov	s0, w8
      4c:      	ushll.2d	v0, v0, #0x0
      50:      	fmov	x8, d0
      54:      	add	x8, x8, x8, lsl #12
      58:      	lsl	x23, x8, #2
      5c:      	add	x21, sp, #0x4, lsl #12  ; =0x4000
      60:      	add	x21, x21, #0x150
      64:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
      68:      	add	x0, x0, #0x150
      6c:      	add	x1, x22, x23
      70:      	mov	w2, #0x4000             ; =16384
      74:      	bl	0x74 <ltmp0+0x74>
      78:      	add	x20, x23, #0x4, lsl #12 ; =0x4000
      7c:      	ldr	s0, [x22, x20]
      80:      	str	q0, [sp]
      84:      	str	q0, [sp, #0x8150]
      88:      	add	x22, sp, #0x130
      8c:      	add	x0, sp, #0x130
      90:      	add	x1, x24, x23
      94:      	mov	w2, #0x4000             ; =16384
      98:      	bl	0x98 <ltmp0+0x98>
      9c:      	mov	x8, #0x0                ; =0
      a0:      	ldr	s0, [x24, x20]
      a4:      	mov	w9, #0x2713             ; =10003
      a8:      	movk	w9, #0x3d37, lsl #16
      ac:      	dup.4s	v2, w9
      b0:      	mov	w9, #0x422a             ; =16938
      b4:      	movk	w9, #0x3f4c, lsl #16
      b8:      	dup.4s	v1, w9
      bc:      	stp	q1, q2, [sp, #0x100]
      c0:      	mov	w9, #0x9231             ; =37425
      c4:      	movk	w9, #0x2f30, lsl #16
      c8:      	dup.4s	v2, w9
      cc:      	mov	w9, #0x322b             ; =12843
      d0:      	movk	w9, #0x32d7, lsl #16
      d4:      	dup.4s	v1, w9
      d8:      	stp	q1, q2, [sp, #0xe0]
      dc:      	mov	w9, #0xef1d             ; =61213
      e0:      	movk	w9, #0x3638, lsl #16
      e4:      	dup.4s	v2, w9
      e8:      	mov	w9, #0xd01              ; =3329
      ec:      	movk	w9, #0x3950, lsl #16
      f0:      	dup.4s	v1, w9
      f4:      	stp	q1, q2, [sp, #0xc0]
      f8:      	mov	w9, #0x8889             ; =34953
      fc:      	movk	w9, #0x3c08, lsl #16
     100:      	dup.4s	v2, w9
     104:      	mov	w9, #0xaaab             ; =43691
     108:      	movk	w9, #0x3e2a, lsl #16
     10c:      	dup.4s	v21, w9
     110:      	mov	w9, #0x76c7             ; =30407
     114:      	movk	w9, #0x310f, lsl #16
     118:      	dup.4s	v1, w9
     11c:      	stp	q1, q2, [sp, #0xa0]
     120:      	mov	w9, #0xf27e             ; =62078
     124:      	movk	w9, #0x3493, lsl #16
     128:      	dup.4s	v2, w9
     12c:      	mov	w9, #0xd01              ; =3329
     130:      	movk	w9, #0x37d0, lsl #16
     134:      	dup.4s	v1, w9
     138:      	stp	q1, q2, [sp, #0x80]
     13c:      	mov	w9, #0xb61              ; =2913
     140:      	movk	w9, #0x3ab6, lsl #16
     144:      	dup.4s	v2, w9
     148:      	mov	w9, #0xaaab             ; =43691
     14c:      	movk	w9, #0x3d2a, lsl #16
     150:      	dup.4s	v1, w9
     154:      	stp	q1, q2, [sp, #0x60]
     158:      	mov	w9, #-0x3d300000        ; =-1026555904
     15c:      	dup.4s	v2, w9
     160:      	mov	w9, #0x42c80000         ; =1120403456
     164:      	dup.4s	v25, w9
     168:      	mov	w9, #0xaa3b             ; =43579
     16c:      	movk	w9, #0x3fb8, lsl #16
     170:      	dup.4s	v1, w9
     174:      	stp	q1, q2, [sp, #0x40]
     178:      	mov	w9, #0x7200             ; =29184
     17c:      	movk	w9, #0xbf31, lsl #16
     180:      	dup.4s	v2, w9
     184:      	mov	w9, #0xbe8e             ; =48782
     188:      	movk	w9, #0xb5bf, lsl #16
     18c:      	dup.4s	v1, w9
     190:      	stp	q1, q2, [sp, #0x20]
     194:      	mov	w9, #0x2bda             ; =11226
     198:      	movk	w9, #0x3950, lsl #16
     19c:      	dup.4s	v29, w9
     1a0:      	mov	w9, #0x96c9             ; =38601
     1a4:      	movk	w9, #0x3ab6, lsl #16
     1a8:      	dup.4s	v30, w9
     1ac:      	mov	w9, #0x88a6             ; =34982
     1b0:      	movk	w9, #0x3c08, lsl #16
     1b4:      	dup.4s	v31, w9
     1b8:      	mov	w9, #0xaa7a             ; =43642
     1bc:      	movk	w9, #0x3d2a, lsl #16
     1c0:      	dup.4s	v8, w9
     1c4:      	add	x9, x19, x23
     1c8:      	str	q0, [sp, #0x10]
     1cc:      	str	q0, [sp, #0x4130]
     1d0:      	movi.4s	v9, #0x3f, lsl #24
     1d4:      	fmov.4s	v19, #1.00000000
     1d8:      	fmov.4s	v0, #9.00000000
     1dc:      	str	q0, [sp, #0x120]
     1e0:      	mvni.4s	v1, #0x7f, msl #16
     1e4:      	fneg.4s	v13, v1
     1e8:      	mvni.4s	v1, #0x3f, msl #16
     1ec:      	fneg.4s	v15, v1
     1f0:      	add	x10, x21, x8
     1f4:      	ldp	q10, q11, [x10]
     1f8:      	ldp	q0, q3, [sp, #0x100]
     1fc:      	fmul.4s	v1, v10, v3
     200:      	fmul.4s	v2, v11, v3
     204:      	fmul.4s	v2, v11, v2
     208:      	fmul.4s	v1, v10, v1
     20c:      	fmul.4s	v1, v10, v1
     210:      	fmul.4s	v2, v11, v2
     214:      	fadd.4s	v2, v11, v2
     218:      	fadd.4s	v1, v10, v1
     21c:      	fmul.4s	v14, v1, v0
     220:      	fmul.4s	v12, v2, v0
     224:      	fabs.4s	v3, v12
     228:      	fabs.4s	v2, v14
     22c:      	fmul.4s	v17, v14, v14
     230:      	ldp	q4, q0, [sp, #0xe0]
     234:      	mov.16b	v1, v4
     238:      	fmul.4s	v20, v12, v12
     23c:      	fmla.4s	v1, v17, v0
     240:      	fmla.4s	v4, v20, v0
     244:      	ldp	q0, q6, [sp, #0xc0]
     248:      	mov.16b	v5, v6
     24c:      	fmla.4s	v5, v17, v1
     250:      	fmla.4s	v6, v20, v4
     254:      	mov.16b	v4, v0
     258:      	fmla.4s	v4, v17, v5
     25c:      	mov.16b	v5, v0
     260:      	ldr	q0, [sp, #0xb0]
     264:      	mov.16b	v7, v0
     268:      	fmla.4s	v5, v20, v6
     26c:      	mov.16b	v6, v0
     270:      	mov.16b	v18, v21
     274:      	mov.16b	v16, v21
     278:      	mov.16b	v1, v19
     27c:      	mov.16b	v26, v19
     280:      	fmla.4s	v7, v17, v4
     284:      	ldp	q22, q0, [sp, #0x90]
     288:      	mov.16b	v4, v22
     28c:      	fmla.4s	v4, v20, v0
     290:      	fmla.4s	v22, v17, v0
     294:      	ldr	q0, [sp, #0x80]
     298:      	mov.16b	v23, v0
     29c:      	fmla.4s	v6, v20, v5
     2a0:      	fmla.4s	v23, v20, v4
     2a4:      	mov.16b	v4, v0
     2a8:      	fmla.4s	v4, v17, v22
     2ac:      	ldp	q22, q0, [sp, #0x60]
     2b0:      	mov.16b	v5, v0
     2b4:      	fmla.4s	v5, v20, v23
     2b8:      	fmla.4s	v18, v17, v7
     2bc:      	mov.16b	v7, v0
     2c0:      	fmla.4s	v7, v17, v4
     2c4:      	mov.16b	v4, v22
     2c8:      	fmla.4s	v4, v20, v5
     2cc:      	fmla.4s	v16, v20, v6
     2d0:      	fmla.4s	v22, v17, v7
     2d4:      	movi.4s	v23, #0x3f, lsl #24
     2d8:      	fmla.4s	v23, v20, v4
     2dc:      	movi.4s	v24, #0x3f, lsl #24
     2e0:      	mov.16b	v6, v19
     2e4:      	fmla.4s	v26, v20, v16
     2e8:      	mov.16b	v0, v19
     2ec:      	ldr	q5, [sp, #0x120]
     2f0:      	fcmge.4s	v4, v5, v2
     2f4:      	fcmge.4s	v5, v5, v3
     2f8:      	and.16b	v7, v5, v3
     2fc:      	and.16b	v16, v4, v2
     300:      	fmla.4s	v6, v20, v23
     304:      	ldr	q23, [sp, #0x50]
     308:      	fcmge.4s	v20, v16, v23
     30c:      	fcmge.4s	v23, v7, v23
     310:      	fcmge.4s	v27, v25, v7
     314:      	and.16b	v23, v23, v27
     318:      	fcmge.4s	v27, v25, v16
     31c:      	fmla.4s	v24, v17, v22
     320:      	and.16b	v20, v20, v27
     324:      	and.16b	v20, v20, v16
     328:      	and.16b	v22, v23, v7
     32c:      	ldr	q27, [sp, #0x40]
     330:      	fmul.4s	v23, v22, v27
     334:      	fmul.4s	v27, v20, v27
     338:      	fmla.4s	v1, v17, v18
     33c:      	movi.4s	v28, #0x4b, lsl #24
     340:      	fadd.4s	v18, v27, v28
     344:      	fadd.4s	v23, v23, v28
     348:      	movi.4s	v27, #0xcb, lsl #24
     34c:      	fadd.4s	v23, v23, v27
     350:      	fadd.4s	v18, v18, v27
     354:      	fcvtzs.4s	v18, v18
     358:      	fmla.4s	v0, v17, v24
     35c:      	fcvtzs.4s	v23, v23
     360:      	scvtf.4s	v17, v23
     364:      	scvtf.4s	v24, v18
     368:      	ldr	q28, [sp, #0x30]
     36c:      	fmul.4s	v27, v17, v28
     370:      	fadd.4s	v22, v22, v27
     374:      	fmul.4s	v27, v24, v28
     378:      	fadd.4s	v20, v20, v27
     37c:      	ldr	q27, [sp, #0x20]
     380:      	fmul.4s	v17, v17, v27
     384:      	fmul.4s	v24, v24, v27
     388:      	fadd.4s	v20, v20, v24
     38c:      	fadd.4s	v22, v22, v17
     390:      	fmul.4s	v17, v22, v29
     394:      	fmul.4s	v24, v20, v29
     398:      	fadd.4s	v24, v24, v30
     39c:      	fadd.4s	v17, v17, v30
     3a0:      	fmul.4s	v17, v22, v17
     3a4:      	fmul.4s	v24, v20, v24
     3a8:      	fmul.4s	v1, v2, v1
     3ac:      	fadd.4s	v24, v24, v31
     3b0:      	fadd.4s	v17, v17, v31
     3b4:      	fmul.4s	v27, v22, v17
     3b8:      	fmul.4s	v17, v20, v24
     3bc:      	fadd.4s	v24, v17, v8
     3c0:      	fdiv.4s	v17, v1, v0
     3c4:      	fadd.4s	v0, v27, v8
     3c8:      	fmul.4s	v0, v22, v0
     3cc:      	fmul.4s	v1, v20, v24
     3d0:      	fadd.4s	v1, v1, v21
     3d4:      	fadd.4s	v0, v0, v21
     3d8:      	fmul.4s	v0, v22, v0
     3dc:      	fmul.4s	v1, v20, v1
     3e0:      	fadd.4s	v1, v1, v9
     3e4:      	fadd.4s	v0, v0, v9
     3e8:      	fmul.4s	v24, v22, v22
     3ec:      	fmul.4s	v0, v24, v0
     3f0:      	fmul.4s	v24, v20, v20
     3f4:      	fmul.4s	v1, v24, v1
     3f8:      	fadd.4s	v1, v20, v1
     3fc:      	fadd.4s	v0, v22, v0
     400:      	fadd.4s	v0, v0, v19
     404:      	movi.2d	v20, #0xffffffffffffffff
     408:      	add.4s	v18, v18, v20
     40c:      	fadd.4s	v1, v1, v19
     410:      	add.4s	v20, v23, v20
     414:      	sshr.4s	v22, v20, #0x1
     418:      	sshr.4s	v23, v18, #0x1
     41c:      	shl.4s	v24, v23, #0x17
     420:      	add.4s	v24, v24, v19
     424:      	fmul.4s	v1, v1, v24
     428:      	shl.4s	v24, v22, #0x17
     42c:      	add.4s	v24, v24, v19
     430:      	fmul.4s	v0, v0, v24
     434:      	sub.4s	v18, v18, v23
     438:      	sub.4s	v20, v20, v22
     43c:      	shl.4s	v20, v20, #0x17
     440:      	add.4s	v20, v20, v19
     444:      	fmul.4s	v0, v0, v20
     448:      	shl.4s	v18, v18, #0x17
     44c:      	add.4s	v18, v18, v19
     450:      	fmul.4s	v1, v1, v18
     454:      	fmul.4s	v18, v3, v26
     458:      	fcmgt.4s	v7, v7, v25
     45c:      	fcmgt.4s	v16, v16, v25
     460:      	bsl.16b	v16, v13, v1
     464:      	bit.16b	v0, v13, v7
     468:      	fmov.4s	v1, #0.25000000
     46c:      	fdiv.4s	v6, v18, v6
     470:      	fdiv.4s	v7, v1, v0
     474:      	fsub.4s	v18, v0, v7
     478:      	fadd.4s	v0, v0, v7
     47c:      	fdiv.4s	v0, v18, v0
     480:      	bif.16b	v0, v19, v5
     484:      	fcmge.4s	v3, v19, v3
     488:      	bit.16b	v0, v6, v3
     48c:      	fdiv.4s	v3, v1, v16
     490:      	fsub.4s	v5, v16, v3
     494:      	fadd.4s	v3, v16, v3
     498:      	fdiv.4s	v3, v5, v3
     49c:      	bif.16b	v3, v19, v4
     4a0:      	fcmge.4s	v2, v19, v2
     4a4:      	bsl.16b	v2, v17, v3
     4a8:      	mvni.4s	v4, #0x80, lsl #24
     4ac:      	bif.16b	v2, v14, v4
     4b0:      	fcmeq.4s	v3, v14, v14
     4b4:      	fadd.4s	v2, v2, v19
     4b8:      	bif.16b	v2, v15, v3
     4bc:      	bif.16b	v0, v12, v4
     4c0:      	fcmeq.4s	v3, v12, v12
     4c4:      	fadd.4s	v0, v0, v19
     4c8:      	bif.16b	v0, v15, v3
     4cc:      	fmul.4s	v3, v11, v9
     4d0:      	fmul.4s	v0, v3, v0
     4d4:      	fmul.4s	v3, v10, v9
     4d8:      	fmul.4s	v2, v3, v2
     4dc:      	add	x10, x22, x8
     4e0:      	ldp	q4, q3, [x10]
     4e4:      	fadd.4s	v2, v4, v2
     4e8:      	fadd.4s	v0, v3, v0
     4ec:      	add	x10, x9, x8
     4f0:      	stp	q2, q0, [x10]
     4f4:      	add	x8, x8, #0x20
     4f8:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     4fc:      	b.ne	0x1f0 <ltmp0+0x1f0>
     500:      	movi.2d	v2, #0000000000000000
     504:      	movi.2d	v0, #0000000000000000
     508:      	ldr	q23, [sp]
     50c:      	mov.s	v0[0], v23[0]
     510:      	mov	w8, #0x2713             ; =10003
     514:      	movk	w8, #0x3d37, lsl #16
     518:      	fmov	s3, w8
     51c:      	fmul.4s	v0, v0, v3
     520:      	fmul.4s	v0, v23, v0
     524:      	fmul.4s	v0, v23, v0
     528:      	fadd.4s	v0, v23, v0
     52c:      	mov	w8, #0x422a             ; =16938
     530:      	movk	w8, #0x3f4c, lsl #16
     534:      	fmov	s3, w8
     538:      	fmul.4s	v0, v0, v3
     53c:      	mov.s	v2[0], v0[0]
     540:      	fabs.4s	v3, v2
     544:      	mov	w8, #0x9231             ; =37425
     548:      	movk	w8, #0x2f30, lsl #16
     54c:      	dup.4s	v0, w8
     550:      	mov	w8, #0x322b             ; =12843
     554:      	movk	w8, #0x32d7, lsl #16
     558:      	dup.4s	v5, w8
     55c:      	fmul.4s	v4, v2, v2
     560:      	fmla.4s	v5, v4, v0
     564:      	mov	w8, #0xef1d             ; =61213
     568:      	movk	w8, #0x3638, lsl #16
     56c:      	dup.4s	v0, w8
     570:      	fmla.4s	v0, v4, v5
     574:      	mov	w8, #0xd01              ; =3329
     578:      	movk	w8, #0x3950, lsl #16
     57c:      	dup.4s	v5, w8
     580:      	mov	w8, #0x8889             ; =34953
     584:      	movk	w8, #0x3c08, lsl #16
     588:      	dup.4s	v16, w8
     58c:      	fmla.4s	v5, v4, v0
     590:      	fmla.4s	v16, v4, v5
     594:      	mov	w8, #0xaaab             ; =43691
     598:      	movk	w8, #0x3e2a, lsl #16
     59c:      	dup.4s	v17, w8
     5a0:      	ldr	q0, [sp, #0x120]
     5a4:      	fcmge.4s	v5, v0, v3
     5a8:      	and.16b	v6, v5, v3
     5ac:      	mov	w8, #-0x3d300000        ; =-1026555904
     5b0:      	dup.4s	v0, w8
     5b4:      	fcmge.4s	v0, v6, v0
     5b8:      	mov	w8, #0x42c80000         ; =1120403456
     5bc:      	dup.4s	v7, w8
     5c0:      	fcmge.4s	v18, v7, v6
     5c4:      	and.16b	v0, v0, v18
     5c8:      	and.16b	v0, v0, v6
     5cc:      	mov	w8, #0xaa3b             ; =43579
     5d0:      	movk	w8, #0x3fb8, lsl #16
     5d4:      	dup.4s	v18, w8
     5d8:      	fmul.4s	v18, v0, v18
     5dc:      	movi.4s	v20, #0x4b, lsl #24
     5e0:      	fadd.4s	v18, v18, v20
     5e4:      	movi.4s	v20, #0xcb, lsl #24
     5e8:      	fadd.4s	v18, v18, v20
     5ec:      	fcvtzs.4s	v18, v18
     5f0:      	scvtf.4s	v20, v18
     5f4:      	mov	w8, #0x7200             ; =29184
     5f8:      	movk	w8, #0xbf31, lsl #16
     5fc:      	dup.4s	v21, w8
     600:      	fmul.4s	v21, v20, v21
     604:      	fadd.4s	v0, v0, v21
     608:      	mov	w8, #0xbe8e             ; =48782
     60c:      	movk	w8, #0xb5bf, lsl #16
     610:      	dup.4s	v21, w8
     614:      	fmul.4s	v20, v20, v21
     618:      	fadd.4s	v0, v0, v20
     61c:      	mov	w8, #0x2bda             ; =11226
     620:      	movk	w8, #0x3950, lsl #16
     624:      	dup.4s	v20, w8
     628:      	fmul.4s	v20, v0, v20
     62c:      	mov	w8, #0x96c9             ; =38601
     630:      	movk	w8, #0x3ab6, lsl #16
     634:      	dup.4s	v21, w8
     638:      	fadd.4s	v20, v20, v21
     63c:      	mov	w8, #0x88a6             ; =34982
     640:      	movk	w8, #0x3c08, lsl #16
     644:      	dup.4s	v21, w8
     648:      	fmul.4s	v20, v0, v20
     64c:      	fadd.4s	v20, v20, v21
     650:      	fmul.4s	v20, v0, v20
     654:      	mov	w8, #0xaa7a             ; =43642
     658:      	movk	w8, #0x3d2a, lsl #16
     65c:      	dup.4s	v21, w8
     660:      	fadd.4s	v20, v20, v21
     664:      	fmul.4s	v20, v0, v20
     668:      	fadd.4s	v20, v20, v17
     66c:      	fmla.4s	v17, v4, v16
     670:      	mov.16b	v16, v19
     674:      	mov	w8, #0x76c7             ; =30407
     678:      	movk	w8, #0x310f, lsl #16
     67c:      	dup.4s	v21, w8
     680:      	mov	w8, #0xf27e             ; =62078
     684:      	movk	w8, #0x3493, lsl #16
     688:      	dup.4s	v22, w8
     68c:      	fmla.4s	v16, v4, v17
     690:      	fmla.4s	v22, v4, v21
     694:      	mov	w8, #0xd01              ; =3329
     698:      	movk	w8, #0x37d0, lsl #16
     69c:      	dup.4s	v17, w8
     6a0:      	fmla.4s	v17, v4, v22
     6a4:      	mov	w8, #0xb61              ; =2913
     6a8:      	movk	w8, #0x3ab6, lsl #16
     6ac:      	dup.4s	v21, w8
     6b0:      	mov	w8, #0xaaab             ; =43691
     6b4:      	movk	w8, #0x3d2a, lsl #16
     6b8:      	dup.4s	v22, w8
     6bc:      	fmla.4s	v21, v4, v17
     6c0:      	fmla.4s	v22, v4, v21
     6c4:      	movi.4s	v17, #0x3f, lsl #24
     6c8:      	fmla.4s	v17, v4, v22
     6cc:      	mov.16b	v21, v19
     6d0:      	fmla.4s	v21, v4, v17
     6d4:      	movi.4s	v4, #0x3f, lsl #24
     6d8:      	fmul.4s	v17, v23, v4
     6dc:      	fcmge.4s	v22, v19, v3
     6e0:      	fmul.4s	v3, v3, v16
     6e4:      	fdiv.4s	v3, v3, v21
     6e8:      	fmul.4s	v16, v0, v20
     6ec:      	fadd.4s	v4, v16, v4
     6f0:      	fmul.4s	v16, v0, v0
     6f4:      	fmul.4s	v4, v16, v4
     6f8:      	fadd.4s	v0, v0, v4
     6fc:      	fadd.4s	v0, v0, v19
     700:      	movi.2d	v4, #0xffffffffffffffff
     704:      	add.4s	v4, v18, v4
     708:      	sshr.4s	v16, v4, #0x1
     70c:      	shl.4s	v18, v16, #0x17
     710:      	add.4s	v18, v18, v19
     714:      	fmul.4s	v0, v0, v18
     718:      	sub.4s	v4, v4, v16
     71c:      	shl.4s	v4, v4, #0x17
     720:      	add.4s	v4, v4, v19
     724:      	fmul.4s	v0, v0, v4
     728:      	fcmgt.4s	v4, v6, v7
     72c:      	mvni.4s	v6, #0x7f, msl #16
     730:      	fneg.4s	v6, v6
     734:      	bit.16b	v0, v6, v4
     738:      	fdiv.4s	v1, v1, v0
     73c:      	fsub.4s	v4, v0, v1
     740:      	fadd.4s	v0, v0, v1
     744:      	fdiv.4s	v0, v4, v0
     748:      	bif.16b	v0, v19, v5
     74c:      	bit.16b	v0, v3, v22
     750:      	mvni.4s	v1, #0x80, lsl #24
     754:      	bif.16b	v0, v2, v1
     758:      	fcmeq.4s	v1, v2, v2
     75c:      	fadd.4s	v0, v0, v19
     760:      	mvni.4s	v2, #0x3f, msl #16
     764:      	fneg.4s	v2, v2
     768:      	bif.16b	v0, v2, v1
     76c:      	fmul.4s	v0, v17, v0
     770:      	ldr	q1, [sp, #0x10]
     774:      	fadd.4s	v0, v0, v1
     778:      	str	s0, [x19, x20]
     77c:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
     780:      	add	sp, sp, #0x170
     784:      	ldp	x29, x30, [sp, #0x80]
     788:      	ldp	x20, x19, [sp, #0x70]
     78c:      	ldp	x22, x21, [sp, #0x60]
     790:      	ldp	x24, x23, [sp, #0x50]
     794:      	ldp	x28, x27, [sp, #0x40]
     798:      	ldp	d9, d8, [sp, #0x30]
     79c:      	ldp	d11, d10, [sp, #0x20]
     7a0:      	ldp	d13, d12, [sp, #0x10]
     7a4:      	ldp	d15, d14, [sp], #0x90
     7a8:      	ret

00000000000007ac <_llm_rows.packet_batch.blocks>:
     7ac:      	stp	d15, d14, [sp, #-0xa0]!
     7b0:      	stp	d13, d12, [sp, #0x10]
     7b4:      	stp	d11, d10, [sp, #0x20]
     7b8:      	stp	d9, d8, [sp, #0x30]
     7bc:      	stp	x28, x27, [sp, #0x40]
     7c0:      	stp	x26, x25, [sp, #0x50]
     7c4:      	stp	x24, x23, [sp, #0x60]
     7c8:      	stp	x22, x21, [sp, #0x70]
     7cc:      	stp	x20, x19, [sp, #0x80]
     7d0:      	stp	x29, x30, [sp, #0x90]
     7d4:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
     7d8:      	sub	sp, sp, #0x340
     7dc:      	str	x0, [sp, #0xf8]
     7e0:      	cbz	w3, 0x1854 <_llm_rows.packet_batch.blocks+0x10a8>
     7e4:      	mov	x23, x3
     7e8:      	mov	x20, x2
     7ec:      	mov	w22, #0x0               ; =0
     7f0:      	ldp	w9, w8, [x2, #0x2c]
     7f4:      	stp	w8, w9, [sp, #0xf0]
     7f8:      	adrp	x8, 0x0 <ltmp0>
     7fc:      	ldr	q0, [x8]
     800:      	str	q0, [sp, #0x30]
     804:      	adrp	x8, 0x0 <ltmp0>
     808:      	ldr	q0, [x8]
     80c:      	str	q0, [sp, #0x20]
     810:      	add	x25, sp, #0x4, lsl #12  ; =0x4000
     814:      	add	x25, x25, #0x320
     818:      	adrp	x8, 0x0 <ltmp0>
     81c:      	ldr	q0, [x8]
     820:      	str	q0, [sp, #0x10]
     824:      	add	x24, sp, #0x300
     828:      	mvni.4s	v0, #0x7f, msl #16
     82c:      	fneg.4s	v1, v0
     830:      	mvni.4s	v0, #0x3f, msl #16
     834:      	fneg.4s	v0, v0
     838:      	stp	q0, q1, [sp, #0x200]
     83c:      	ldp	w28, w21, [x2]
     840:      	mov	w30, #0x76c7            ; =30407
     844:      	movk	w30, #0x310f, lsl #16
     848:      	ldp	w27, w19, [x2, #0x8]
     84c:      	str	w3, [sp, #0xdc]
     850:      	b	0x898 <_llm_rows.packet_batch.blocks+0xec>
     854:      	mov	w8, #0x18               ; =24
     858:      	str	w8, [x20, #0x24]
     85c:      	ldr	w23, [sp, #0xdc]
     860:      	add	w8, w28, #0x1
     864:      	ldp	w10, w9, [sp, #0xf0]
     868:      	cmp	w8, w9
     86c:      	cset	w8, eq
     870:      	csinc	w28, wzr, w28, eq
     874:      	cinc	w9, w21, eq
     878:      	cmp	w9, w10
     87c:      	cset	w10, eq
     880:      	ands	w8, w8, w10
     884:      	csel	w21, wzr, w9, ne
     888:      	add	w27, w27, w8
     88c:      	add	w22, w22, #0x1
     890:      	cmp	w22, w23
     894:      	b.eq	0x1854 <_llm_rows.packet_batch.blocks+0x10a8>
     898:      	ubfiz	x8, x28, #5, #32
     89c:      	cmp	x8, x19
     8a0:      	csel	x9, x8, xzr, ls
     8a4:      	subs	x10, x19, x9
     8a8:      	cmp	x10, #0x20
     8ac:      	mov	w11, #0x20              ; =32
     8b0:      	csel	x10, x10, x11, lo
     8b4:      	cmp	x19, x9
     8b8:      	stp	w28, w21, [x20]
     8bc:      	str	w27, [x20, #0x8]
     8c0:      	str	wzr, [x20, #0x24]
     8c4:      	ccmp	x8, x19, #0x2, hi
     8c8:      	csel	x26, x10, xzr, ls
     8cc:      	cmp	x26, #0x20
     8d0:      	b.lo	0x92c <_llm_rows.packet_batch.blocks+0x180>
     8d4:      	ldr	x26, [sp, #0xf8]
     8d8:      	mov	x0, x26
     8dc:      	mov	x1, x20
     8e0:      	bl	0x8e0 <_llm_rows.packet_batch.blocks+0x134>
     8e4:      	mov	w8, #0x8                ; =8
     8e8:      	str	w8, [x20, #0x24]
     8ec:      	mov	x0, x26
     8f0:      	mov	x1, x20
     8f4:      	bl	0x8f4 <_llm_rows.packet_batch.blocks+0x148>
     8f8:      	mov	w8, #0x10               ; =16
     8fc:      	str	w8, [x20, #0x24]
     900:      	mov	x0, x26
     904:      	mov	x1, x20
     908:      	bl	0x908 <_llm_rows.packet_batch.blocks+0x15c>
     90c:      	mov	w8, #0x18               ; =24
     910:      	str	w8, [x20, #0x24]
     914:      	mov	x0, x26
     918:      	mov	x1, x20
     91c:      	bl	0x91c <_llm_rows.packet_batch.blocks+0x170>
     920:      	mov	w30, #0x76c7            ; =30407
     924:      	movk	w30, #0x310f, lsl #16
     928:      	b	0x860 <_llm_rows.packet_batch.blocks+0xb4>
     92c:      	lsr	x23, x26, #3
     930:      	cmp	x26, #0x8
     934:      	b.lo	0x998 <_llm_rows.packet_batch.blocks+0x1ec>
     938:      	str	wzr, [x20, #0x24]
     93c:      	ldr	x0, [sp, #0xf8]
     940:      	mov	x1, x20
     944:      	bl	0x944 <_llm_rows.packet_batch.blocks+0x198>
     948:      	mov	w30, #0x76c7            ; =30407
     94c:      	movk	w30, #0x310f, lsl #16
     950:      	cmp	x23, #0x1
     954:      	b.eq	0x998 <_llm_rows.packet_batch.blocks+0x1ec>
     958:      	mov	w8, #0x8                ; =8
     95c:      	str	w8, [x20, #0x24]
     960:      	ldr	x0, [sp, #0xf8]
     964:      	mov	x1, x20
     968:      	bl	0x968 <_llm_rows.packet_batch.blocks+0x1bc>
     96c:      	mov	w30, #0x76c7            ; =30407
     970:      	movk	w30, #0x310f, lsl #16
     974:      	cmp	x23, #0x2
     978:      	b.eq	0x998 <_llm_rows.packet_batch.blocks+0x1ec>
     97c:      	mov	w8, #0x10               ; =16
     980:      	str	w8, [x20, #0x24]
     984:      	ldr	x0, [sp, #0xf8]
     988:      	mov	x1, x20
     98c:      	bl	0x98c <_llm_rows.packet_batch.blocks+0x1e0>
     990:      	mov	w30, #0x76c7            ; =30407
     994:      	movk	w30, #0x310f, lsl #16
     998:      	and	w8, w26, #0x7
     99c:      	mov	w26, #0xf27e            ; =62078
     9a0:      	movk	w26, #0x3493, lsl #16
     9a4:      	cbz	w8, 0x854 <_llm_rows.packet_batch.blocks+0xa8>
     9a8:      	dup.4s	v0, w8
     9ac:      	ldp	q2, q1, [sp, #0x20]
     9b0:      	cmhi.4s	v30, v0, v2
     9b4:      	cmhi.4s	v8, v0, v1
     9b8:      	uzp1.8h	v0, v8, v30
     9bc:      	umaxv.8h	h1, v0
     9c0:      	fmov	w8, s1
     9c4:      	tbz	w8, #0x0, 0x854 <_llm_rows.packet_batch.blocks+0xa8>
     9c8:      	mov	x9, #0x0                ; =0
     9cc:      	ldr	x11, [sp, #0xf8]
     9d0:      	ldr	x12, [x11]
     9d4:      	ldr	x10, [x11, #0x10]
     9d8:      	ubfiz	w8, w28, #2, #27
     9dc:      	orr	w8, w8, w23
     9e0:      	dup.4s	v1, w8
     9e4:      	ldr	x8, [x11, #0x30]
     9e8:      	and.16b	v3, v8, v1
     9ec:      	and.16b	v1, v30, v1
     9f0:      	ushll2.2d	v5, v1, #0x0
     9f4:      	ushll2.2d	v2, v3, #0x0
     9f8:      	ushll.2d	v4, v1, #0x0
     9fc:      	ushll.2d	v6, v3, #0x0
     a00:      	fmov	x11, d6
     a04:      	mov	w13, #0x4004            ; =16388
     a08:      	umaddl	x11, w11, w13, x12
     a0c:      	ldr	q1, [sp, #0x10]
     a10:      	and.16b	v0, v0, v1
     a14:      	addv.8h	h0, v0
     a18:      	str	q0, [sp, #0x140]
     a1c:      	fmov	w13, s0
     a20:      	b	0xa44 <_llm_rows.packet_batch.blocks+0x298>
     a24:      	add	x14, x25, x9
     a28:      	ldp	q0, q1, [x14]
     a2c:      	bit.16b	v1, v7, v30
     a30:      	bit.16b	v0, v3, v8
     a34:      	stp	q0, q1, [x14]
     a38:      	add	x9, x9, #0x20
     a3c:      	cmp	x9, #0x4, lsl #12       ; =0x4000
     a40:      	b.eq	0xad8 <_llm_rows.packet_batch.blocks+0x32c>
     a44:      	add	x14, x11, x9
     a48:      	movi.2d	v3, #0000000000000000
     a4c:      	movi.2d	v7, #0000000000000000
     a50:      	tbnz	w13, #0x0, 0xa78 <_llm_rows.packet_batch.blocks+0x2cc>
     a54:      	and	w15, w13, #0xff
     a58:      	tbnz	w15, #0x1, 0xa84 <_llm_rows.packet_batch.blocks+0x2d8>
     a5c:      	tbnz	w15, #0x2, 0xa90 <_llm_rows.packet_batch.blocks+0x2e4>
     a60:      	tbnz	w15, #0x3, 0xa9c <_llm_rows.packet_batch.blocks+0x2f0>
     a64:      	tbnz	w15, #0x4, 0xaa8 <_llm_rows.packet_batch.blocks+0x2fc>
     a68:      	tbnz	w15, #0x5, 0xab4 <_llm_rows.packet_batch.blocks+0x308>
     a6c:      	tbnz	w15, #0x6, 0xac0 <_llm_rows.packet_batch.blocks+0x314>
     a70:      	tbz	w15, #0x7, 0xa24 <_llm_rows.packet_batch.blocks+0x278>
     a74:      	b	0xacc <_llm_rows.packet_batch.blocks+0x320>
     a78:      	ldr	s3, [x14]
     a7c:      	and	w15, w13, #0xff
     a80:      	tbz	w15, #0x1, 0xa5c <_llm_rows.packet_batch.blocks+0x2b0>
     a84:      	add	x16, x14, #0x4
     a88:      	ld1.s	{ v3 }[1], [x16]
     a8c:      	tbz	w15, #0x2, 0xa60 <_llm_rows.packet_batch.blocks+0x2b4>
     a90:      	add	x16, x14, #0x8
     a94:      	ld1.s	{ v3 }[2], [x16]
     a98:      	tbz	w15, #0x3, 0xa64 <_llm_rows.packet_batch.blocks+0x2b8>
     a9c:      	add	x16, x14, #0xc
     aa0:      	ld1.s	{ v3 }[3], [x16]
     aa4:      	tbz	w15, #0x4, 0xa68 <_llm_rows.packet_batch.blocks+0x2bc>
     aa8:      	add	x16, x14, #0x10
     aac:      	ld1.s	{ v7 }[0], [x16]
     ab0:      	tbz	w15, #0x5, 0xa6c <_llm_rows.packet_batch.blocks+0x2c0>
     ab4:      	add	x16, x14, #0x14
     ab8:      	ld1.s	{ v7 }[1], [x16]
     abc:      	tbz	w15, #0x6, 0xa70 <_llm_rows.packet_batch.blocks+0x2c4>
     ac0:      	add	x16, x14, #0x18
     ac4:      	ld1.s	{ v7 }[2], [x16]
     ac8:      	tbz	w15, #0x7, 0xa24 <_llm_rows.packet_batch.blocks+0x278>
     acc:      	add	x14, x14, #0x1c
     ad0:      	ld1.s	{ v7 }[3], [x14]
     ad4:      	b	0xa24 <_llm_rows.packet_batch.blocks+0x278>
     ad8:      	sshll.2d	v0, v8, #0x0
     adc:      	xtn.4h	v1, v8
     ae0:      	uzp1.8b	v1, v1, v0
     ae4:      	movi.2d	v21, #0000000000000000
     ae8:      	mov.b	v21[0], v1[0]
     aec:      	adrp	x9, 0x0 <ltmp0>
     af0:      	ldr	d18, [x9]
     af4:      	and.8b	v3, v21, v18
     af8:      	addv.8b	b3, v3
     afc:      	fmov	w13, s3
     b00:      	umaxv.8b	b3, v21
     b04:      	fmov	w14, s3
     b08:      	rbit	w9, w13
     b0c:      	clz	w9, w9
     b10:      	tst	w14, #0x1
     b14:      	csel	w9, w9, wzr, ne
     b18:      	adrp	x11, 0x0 <ltmp0>
     b1c:      	ldr	q3, [x11]
     b20:      	mov	w11, #0x1000            ; =4096
     b24:      	dup.2d	v7, x11
     b28:      	mov.16b	v16, v0
     b2c:      	bsl.16b	v16, v3, v7
     b30:      	mov	w11, #0x1001            ; =4097
     b34:      	dup.2s	v3, w11
     b38:      	xtn.2s	v6, v6
     b3c:      	movi.2d	v0, #0000000000000000
     b40:      	mov.b	v0[0], v1[0]
     b44:      	umlal.2d	v16, v6, v3
     b48:      	ushll.2d	v0, v0, #0x0
     b4c:      	shl.2d	v0, v0, #0x3f
     b50:      	cmlt.2d	v0, v0, #0
     b54:      	str	q16, [sp, #0xb0]
     b58:      	and.16b	v0, v0, v16
     b5c:      	movi.2d	v1, #0000000000000000
     b60:      	stp	q1, q1, [sp, #0x2d0]
     b64:      	stp	q0, q1, [sp, #0x2b0]
     b68:      	and	x11, x9, #0x7
     b6c:      	add	x15, sp, #0x2b0
     b70:      	ldr	x11, [x15, x11, lsl #3]
     b74:      	sub	x11, x11, x9
     b78:      	lsl	x11, x11, #2
     b7c:      	add	x12, x12, x11
     b80:      	movi.2d	v22, #0000000000000000
     b84:      	movi.2d	v20, #0000000000000000
     b88:      	tbz	w14, #0x0, 0xb90 <_llm_rows.packet_batch.blocks+0x3e4>
     b8c:      	ldr	s22, [x12]
     b90:      	mov	w1, #0x2713             ; =10003
     b94:      	movk	w1, #0x3d37, lsl #16
     b98:      	mov	w2, #0x422a             ; =16938
     b9c:      	movk	w2, #0x3f4c, lsl #16
     ba0:      	mov	w3, #0x9231             ; =37425
     ba4:      	movk	w3, #0x2f30, lsl #16
     ba8:      	mov	w4, #0x322b             ; =12843
     bac:      	movk	w4, #0x32d7, lsl #16
     bb0:      	mov	w5, #0xef1d             ; =61213
     bb4:      	movk	w5, #0x3638, lsl #16
     bb8:      	mov	w6, #0xd01              ; =3329
     bbc:      	movk	w6, #0x3950, lsl #16
     bc0:      	mov	w7, #0x8889             ; =34953
     bc4:      	movk	w7, #0x3c08, lsl #16
     bc8:      	mov	w23, #0xaaab            ; =43691
     bcc:      	movk	w23, #0x3e2a, lsl #16
     bd0:      	tbnz	w13, #0x1, 0x173c <_llm_rows.packet_batch.blocks+0xf90>
     bd4:      	tbnz	w13, #0x2, 0x1748 <_llm_rows.packet_batch.blocks+0xf9c>
     bd8:      	tbnz	w13, #0x3, 0x1754 <_llm_rows.packet_batch.blocks+0xfa8>
     bdc:      	tbnz	w13, #0x4, 0x1760 <_llm_rows.packet_batch.blocks+0xfb4>
     be0:      	tbnz	w13, #0x5, 0x176c <_llm_rows.packet_batch.blocks+0xfc0>
     be4:      	tbnz	w13, #0x6, 0x1778 <_llm_rows.packet_batch.blocks+0xfcc>
     be8:      	tbz	w13, #0x7, 0xbf4 <_llm_rows.packet_batch.blocks+0x448>
     bec:      	add	x12, x12, #0x1c
     bf0:      	ld1.s	{ v20 }[3], [x12]
     bf4:      	mov	x15, #0x0               ; =0
     bf8:      	sshll2.2d	v0, v30, #0x0
     bfc:      	sshll2.2d	v1, v8, #0x0
     c00:      	sshll.2d	v16, v30, #0x0
     c04:      	adrp	x12, 0x0 <ltmp0>
     c08:      	ldr	q17, [x12]
     c0c:      	mov.16b	v23, v16
     c10:      	bsl.16b	v23, v17, v7
     c14:      	adrp	x12, 0x0 <ltmp0>
     c18:      	ldr	q16, [x12]
     c1c:      	mov.16b	v24, v1
     c20:      	bsl.16b	v24, v16, v7
     c24:      	adrp	x12, 0x0 <ltmp0>
     c28:      	ldr	q16, [x12]
     c2c:      	mov.16b	v25, v0
     c30:      	bsl.16b	v25, v16, v7
     c34:      	adrp	x12, 0x0 <ltmp0>
     c38:      	ldr	q7, [x12]
     c3c:      	mov	w12, #0x4000            ; =16384
     c40:      	dup.2d	v16, x12
     c44:      	sshll.2d	v17, v8, #0x0
     c48:      	bif.16b	v7, v16, v17
     c4c:      	adrp	x12, 0x0 <ltmp0>
     c50:      	ldr	q17, [x12]
     c54:      	sshll.2d	v19, v30, #0x0
     c58:      	bif.16b	v17, v16, v19
     c5c:      	adrp	x12, 0x0 <ltmp0>
     c60:      	ldr	q19, [x12]
     c64:      	bsl.16b	v1, v19, v16
     c68:      	adrp	x12, 0x0 <ltmp0>
     c6c:      	ldr	q19, [x12]
     c70:      	bsl.16b	v0, v19, v16
     c74:      	xtn.2s	v5, v5
     c78:      	umlal.2d	v25, v5, v3
     c7c:      	umull.2d	v5, v6, v3
     c80:      	xtn.2s	v2, v2
     c84:      	xtn.2s	v4, v4
     c88:      	umlal.2d	v24, v2, v3
     c8c:      	stp	q25, q24, [sp, #0x70]
     c90:      	stp	q17, q0, [sp, #0x290]
     c94:      	stp	q7, q1, [sp, #0x270]
     c98:      	and	x12, x9, #0x7
     c9c:      	add	x14, sp, #0x270
     ca0:      	ldr	x12, [x14, x12, lsl #3]
     ca4:      	umlal.2d	v23, v4, v3
     ca8:      	str	q23, [sp, #0x90]
     cac:      	sub	x12, x12, x9, lsl #2
     cb0:      	tst	w13, #0xff
     cb4:      	csel	x12, xzr, x12, eq
     cb8:      	add	x13, x25, x12
     cbc:      	ldp	q0, q1, [x13]
     cc0:      	zip2.8b	v2, v21, v0
     cc4:      	ushll.4s	v2, v2, #0x0
     cc8:      	shl.4s	v2, v2, #0x1f
     ccc:      	cmlt.4s	v2, v2, #0
     cd0:      	bit.16b	v1, v20, v2
     cd4:      	zip1.8b	v2, v21, v0
     cd8:      	ushll.4s	v2, v2, #0x0
     cdc:      	shl.4s	v2, v2, #0x1f
     ce0:      	cmlt.4s	v2, v2, #0
     ce4:      	bit.16b	v0, v22, v2
     ce8:      	stp	q0, q1, [x13]
     cec:      	fmov	x13, d5
     cf0:      	lsl	x13, x13, #2
     cf4:      	add	x14, x10, x13
     cf8:      	mov	w16, #0x1               ; =1
     cfc:      	dup.2d	v0, x16
     d00:      	ushll2.2d	v1, v30, #0x0
     d04:      	and.16b	v16, v1, v0
     d08:      	ushll2.2d	v1, v8, #0x0
     d0c:      	and.16b	v17, v1, v0
     d10:      	ushll.2d	v1, v30, #0x0
     d14:      	and.16b	v28, v1, v0
     d18:      	ushll.2d	v1, v8, #0x0
     d1c:      	and.16b	v29, v1, v0
     d20:      	movi.2d	v2, #0000000000000000
     d24:      	movi.2d	v3, #0000000000000000
     d28:      	movi.2d	v4, #0000000000000000
     d2c:      	movi.2d	v5, #0000000000000000
     d30:      	b	0xd64 <_llm_rows.packet_batch.blocks+0x5b8>
     d34:      	add	x15, x24, x15
     d38:      	ldp	q0, q1, [x15]
     d3c:      	bit.16b	v1, v7, v30
     d40:      	bit.16b	v0, v6, v8
     d44:      	stp	q0, q1, [x15]
     d48:      	add.2d	v3, v3, v17
     d4c:      	add.2d	v4, v4, v28
     d50:      	add.2d	v5, v5, v16
     d54:      	add.2d	v2, v2, v29
     d58:      	fmov	x15, d2
     d5c:      	cmp	x15, #0x200
     d60:      	b.ge	0xe04 <_llm_rows.packet_batch.blocks+0x658>
     d64:      	ldr	q0, [sp, #0x140]
     d68:      	fmov	w17, s0
     d6c:      	lsl	x15, x15, #5
     d70:      	add	x16, x14, x15
     d74:      	movi.2d	v6, #0000000000000000
     d78:      	movi.2d	v7, #0000000000000000
     d7c:      	tbnz	w17, #0x0, 0xda4 <_llm_rows.packet_batch.blocks+0x5f8>
     d80:      	and	w17, w17, #0xff
     d84:      	tbnz	w17, #0x1, 0xdb0 <_llm_rows.packet_batch.blocks+0x604>
     d88:      	tbnz	w17, #0x2, 0xdbc <_llm_rows.packet_batch.blocks+0x610>
     d8c:      	tbnz	w17, #0x3, 0xdc8 <_llm_rows.packet_batch.blocks+0x61c>
     d90:      	tbnz	w17, #0x4, 0xdd4 <_llm_rows.packet_batch.blocks+0x628>
     d94:      	tbnz	w17, #0x5, 0xde0 <_llm_rows.packet_batch.blocks+0x634>
     d98:      	tbnz	w17, #0x6, 0xdec <_llm_rows.packet_batch.blocks+0x640>
     d9c:      	tbz	w17, #0x7, 0xd34 <_llm_rows.packet_batch.blocks+0x588>
     da0:      	b	0xdf8 <_llm_rows.packet_batch.blocks+0x64c>
     da4:      	ldr	s6, [x16]
     da8:      	and	w17, w17, #0xff
     dac:      	tbz	w17, #0x1, 0xd88 <_llm_rows.packet_batch.blocks+0x5dc>
     db0:      	add	x0, x16, #0x4
     db4:      	ld1.s	{ v6 }[1], [x0]
     db8:      	tbz	w17, #0x2, 0xd8c <_llm_rows.packet_batch.blocks+0x5e0>
     dbc:      	add	x0, x16, #0x8
     dc0:      	ld1.s	{ v6 }[2], [x0]
     dc4:      	tbz	w17, #0x3, 0xd90 <_llm_rows.packet_batch.blocks+0x5e4>
     dc8:      	add	x0, x16, #0xc
     dcc:      	ld1.s	{ v6 }[3], [x0]
     dd0:      	tbz	w17, #0x4, 0xd94 <_llm_rows.packet_batch.blocks+0x5e8>
     dd4:      	add	x0, x16, #0x10
     dd8:      	ld1.s	{ v7 }[0], [x0]
     ddc:      	tbz	w17, #0x5, 0xd98 <_llm_rows.packet_batch.blocks+0x5ec>
     de0:      	add	x0, x16, #0x14
     de4:      	ld1.s	{ v7 }[1], [x0]
     de8:      	tbz	w17, #0x6, 0xd9c <_llm_rows.packet_batch.blocks+0x5f0>
     dec:      	add	x0, x16, #0x18
     df0:      	ld1.s	{ v7 }[2], [x0]
     df4:      	tbz	w17, #0x7, 0xd34 <_llm_rows.packet_batch.blocks+0x588>
     df8:      	add	x16, x16, #0x1c
     dfc:      	ld1.s	{ v7 }[3], [x16]
     e00:      	b	0xd34 <_llm_rows.packet_batch.blocks+0x588>
     e04:      	add	x10, x10, x11
     e08:      	shl.8b	v0, v21, #0x7
     e0c:      	cmlt.8b	v0, v0, #0
     e10:      	and.8b	v0, v0, v18
     e14:      	addv.8b	b0, v0
     e18:      	str	d0, [sp, #0x48]
     e1c:      	fmov	w11, s0
     e20:      	movi.2d	v4, #0000000000000000
     e24:      	movi.2d	v3, #0000000000000000
     e28:      	tbnz	w11, #0x0, 0x1788 <_llm_rows.packet_batch.blocks+0xfdc>
     e2c:      	mov	w15, #0xb61             ; =2913
     e30:      	movk	w15, #0x3ab6, lsl #16
     e34:      	mov	w16, #0xaaab            ; =43691
     e38:      	movk	w16, #0x3d2a, lsl #16
     e3c:      	mov	w17, #-0x3d300000       ; =-1026555904
     e40:      	tbnz	w11, #0x1, 0x17a4 <_llm_rows.packet_batch.blocks+0xff8>
     e44:      	tbnz	w11, #0x2, 0x17b0 <_llm_rows.packet_batch.blocks+0x1004>
     e48:      	tbnz	w11, #0x3, 0x17bc <_llm_rows.packet_batch.blocks+0x1010>
     e4c:      	tbnz	w11, #0x4, 0x17c8 <_llm_rows.packet_batch.blocks+0x101c>
     e50:      	tbnz	w11, #0x5, 0x17d4 <_llm_rows.packet_batch.blocks+0x1028>
     e54:      	tbnz	w11, #0x6, 0x17e0 <_llm_rows.packet_batch.blocks+0x1034>
     e58:      	mov	w14, #0xd01             ; =3329
     e5c:      	movk	w14, #0x37d0, lsl #16
     e60:      	str	q20, [sp, #0xc0]
     e64:      	str	q22, [sp, #0xa0]
     e68:      	tbz	w11, #0x7, 0xe74 <_llm_rows.packet_batch.blocks+0x6c8>
     e6c:      	add	x10, x10, #0x1c
     e70:      	ld1.s	{ v3 }[3], [x10]
     e74:      	mov	x11, #0x0               ; =0
     e78:      	add	x10, x24, x12
     e7c:      	ldp	q0, q1, [x10]
     e80:      	zip2.8b	v2, v21, v0
     e84:      	ushll.4s	v2, v2, #0x0
     e88:      	shl.4s	v2, v2, #0x1f
     e8c:      	cmlt.4s	v2, v2, #0
     e90:      	stp	q4, q3, [sp, #0x50]
     e94:      	bit.16b	v1, v3, v2
     e98:      	str	q21, [sp, #0xe0]
     e9c:      	zip1.8b	v2, v21, v0
     ea0:      	ushll.4s	v2, v2, #0x0
     ea4:      	shl.4s	v2, v2, #0x1f
     ea8:      	cmlt.4s	v2, v2, #0
     eac:      	bit.16b	v0, v4, v2
     eb0:      	stp	q0, q1, [x10]
     eb4:      	add	x10, x8, x13
     eb8:      	movi.2d	v3, #0000000000000000
     ebc:      	movi.2d	v19, #0000000000000000
     ec0:      	movi.2d	v20, #0000000000000000
     ec4:      	movi.2d	v21, #0000000000000000
     ec8:      	stp	q17, q16, [sp, #0x120]
     ecc:      	stp	q29, q28, [sp, #0x100]
     ed0:      	b	0xef0 <_llm_rows.packet_batch.blocks+0x744>
     ed4:      	add.2d	v19, v19, v17
     ed8:      	add.2d	v20, v20, v28
     edc:      	add.2d	v21, v21, v16
     ee0:      	add.2d	v3, v3, v29
     ee4:      	fmov	x11, d3
     ee8:      	cmp	x11, #0x200
     eec:      	b.ge	0x1394 <_llm_rows.packet_batch.blocks+0xbe8>
     ef0:      	lsl	x11, x11, #5
     ef4:      	add	x12, x25, x11
     ef8:      	ldr	q0, [x12]
     efc:      	and.16b	v22, v8, v0
     f00:      	dup.4s	v0, w1
     f04:      	str	q0, [sp, #0x1c0]
     f08:      	fmul.4s	v0, v22, v0
     f0c:      	fmul.4s	v0, v22, v0
     f10:      	fmul.4s	v0, v22, v0
     f14:      	fadd.4s	v0, v22, v0
     f18:      	dup.4s	v1, w2
     f1c:      	str	q1, [sp, #0x1a0]
     f20:      	fmul.4s	v0, v0, v1
     f24:      	and.16b	v0, v8, v0
     f28:      	fabs.4s	v1, v0
     f2c:      	fmov.4s	v25, #1.00000000
     f30:      	dup.4s	v5, w3
     f34:      	dup.4s	v4, w4
     f38:      	fmul.4s	v2, v0, v0
     f3c:      	stp	q5, q4, [sp, #0x1e0]
     f40:      	fmla.4s	v4, v2, v5
     f44:      	dup.4s	v5, w5
     f48:      	str	q5, [sp, #0x1d0]
     f4c:      	fmla.4s	v5, v2, v4
     f50:      	dup.4s	v4, w6
     f54:      	str	q4, [sp, #0x1b0]
     f58:      	dup.4s	v10, w7
     f5c:      	fmla.4s	v4, v2, v5
     f60:      	mov.16b	v5, v10
     f64:      	fmla.4s	v5, v2, v4
     f68:      	dup.4s	v26, w23
     f6c:      	mov.16b	v4, v26
     f70:      	fmla.4s	v4, v2, v5
     f74:      	mov.16b	v5, v25
     f78:      	fmla.4s	v5, v2, v4
     f7c:      	fmul.4s	v4, v1, v5
     f80:      	dup.4s	v6, w30
     f84:      	dup.4s	v11, w26
     f88:      	mov.16b	v5, v11
     f8c:      	str	q6, [sp, #0x190]
     f90:      	fmla.4s	v5, v2, v6
     f94:      	dup.4s	v13, w14
     f98:      	mov.16b	v6, v13
     f9c:      	fmla.4s	v6, v2, v5
     fa0:      	dup.4s	v14, w15
     fa4:      	mov.16b	v5, v14
     fa8:      	fmla.4s	v5, v2, v6
     fac:      	dup.4s	v15, w16
     fb0:      	mov.16b	v6, v15
     fb4:      	fmla.4s	v6, v2, v5
     fb8:      	movi.4s	v5, #0x3f, lsl #24
     fbc:      	fmla.4s	v5, v2, v6
     fc0:      	mov.16b	v6, v25
     fc4:      	fmla.4s	v6, v2, v5
     fc8:      	fdiv.4s	v29, v4, v6
     fcc:      	fmov.4s	v2, #9.00000000
     fd0:      	str	q2, [sp, #0x180]
     fd4:      	fcmge.4s	v31, v2, v1
     fd8:      	and.16b	v4, v31, v1
     fdc:      	dup.4s	v2, w17
     fe0:      	str	q2, [sp, #0x170]
     fe4:      	fcmge.4s	v2, v4, v2
     fe8:      	mov	w13, #0x42c80000        ; =1120403456
     fec:      	dup.4s	v27, w13
     ff0:      	fcmge.4s	v5, v27, v4
     ff4:      	and.16b	v2, v2, v5
     ff8:      	and.16b	v2, v2, v4
     ffc:      	mov	w13, #0xaa3b            ; =43579
    1000:      	movk	w13, #0x3fb8, lsl #16
    1004:      	dup.4s	v5, w13
    1008:      	str	q5, [sp, #0x160]
    100c:      	fmul.4s	v5, v2, v5
    1010:      	movi.4s	v6, #0x4b, lsl #24
    1014:      	fadd.4s	v5, v5, v6
    1018:      	movi.4s	v6, #0xcb, lsl #24
    101c:      	fadd.4s	v5, v5, v6
    1020:      	fcvtzs.4s	v9, v5
    1024:      	scvtf.4s	v6, v9
    1028:      	mov	w13, #0x7200            ; =29184
    102c:      	movk	w13, #0xbf31, lsl #16
    1030:      	dup.4s	v5, w13
    1034:      	str	q5, [sp, #0x150]
    1038:      	fmul.4s	v18, v6, v5
    103c:      	fadd.4s	v18, v2, v18
    1040:      	mov	w13, #0xbe8e            ; =48782
    1044:      	movk	w13, #0xb5bf, lsl #16
    1048:      	dup.4s	v24, w13
    104c:      	fmul.4s	v6, v6, v24
    1050:      	mov	w13, #0x2bda            ; =11226
    1054:      	movk	w13, #0x3950, lsl #16
    1058:      	dup.4s	v2, w13
    105c:      	fadd.4s	v12, v18, v6
    1060:      	fmul.4s	v6, v12, v2
    1064:      	mov	w13, #0x96c9            ; =38601
    1068:      	movk	w13, #0x3ab6, lsl #16
    106c:      	dup.4s	v18, w13
    1070:      	fadd.4s	v6, v6, v18
    1074:      	fmul.4s	v23, v12, v6
    1078:      	mov	w13, #0x88a6            ; =34982
    107c:      	movk	w13, #0x3c08, lsl #16
    1080:      	dup.4s	v6, w13
    1084:      	fadd.4s	v23, v23, v6
    1088:      	fmul.4s	v7, v12, v23
    108c:      	mov	w13, #0xaa7a            ; =43642
    1090:      	movk	w13, #0x3d2a, lsl #16
    1094:      	dup.4s	v23, w13
    1098:      	fadd.4s	v7, v7, v23
    109c:      	fmul.4s	v7, v12, v7
    10a0:      	fadd.4s	v7, v7, v26
    10a4:      	fmul.4s	v7, v12, v7
    10a8:      	movi.4s	v16, #0x3f, lsl #24
    10ac:      	fadd.4s	v7, v7, v16
    10b0:      	fmul.4s	v28, v12, v12
    10b4:      	fmul.4s	v7, v28, v7
    10b8:      	fadd.4s	v7, v12, v7
    10bc:      	fadd.4s	v7, v7, v25
    10c0:      	movi.2d	v17, #0xffffffffffffffff
    10c4:      	add.4s	v28, v9, v17
    10c8:      	sshr.4s	v9, v28, #0x1
    10cc:      	shl.4s	v12, v9, #0x17
    10d0:      	add.4s	v12, v12, v25
    10d4:      	fmul.4s	v7, v7, v12
    10d8:      	sub.4s	v28, v28, v9
    10dc:      	shl.4s	v28, v28, #0x17
    10e0:      	add.4s	v28, v28, v25
    10e4:      	fmul.4s	v7, v7, v28
    10e8:      	fcmgt.4s	v4, v4, v27
    10ec:      	ldr	q17, [sp, #0x210]
    10f0:      	bit.16b	v7, v17, v4
    10f4:      	fmov.4s	v4, #0.25000000
    10f8:      	fdiv.4s	v28, v4, v7
    10fc:      	fsub.4s	v9, v7, v28
    1100:      	fadd.4s	v7, v7, v28
    1104:      	fdiv.4s	v7, v9, v7
    1108:      	bif.16b	v7, v25, v31
    110c:      	fcmge.4s	v1, v25, v1
    1110:      	bsl.16b	v1, v29, v7
    1114:      	mvni.4s	v7, #0x80, lsl #24
    1118:      	bif.16b	v1, v0, v7
    111c:      	fcmeq.4s	v0, v0, v0
    1120:      	fadd.4s	v1, v1, v25
    1124:      	ldr	q7, [sp, #0x200]
    1128:      	bif.16b	v1, v7, v0
    112c:      	ldr	q0, [x12, #0x10]
    1130:      	fmul.4s	v7, v22, v16
    1134:      	fmul.4s	v1, v7, v1
    1138:      	add	x12, x24, x11
    113c:      	ldp	q7, q22, [x12]
    1140:      	and.16b	v7, v8, v7
    1144:      	fadd.4s	v1, v7, v1
    1148:      	ldr	q5, [sp, #0x140]
    114c:      	fmov	w12, s5
    1150:      	add	x11, x10, x11
    1154:      	tbnz	w12, #0x0, 0x1330 <_llm_rows.packet_batch.blocks+0xb84>
    1158:      	and	w12, w12, #0xff
    115c:      	tbnz	w12, #0x1, 0x133c <_llm_rows.packet_batch.blocks+0xb90>
    1160:      	tbnz	w12, #0x2, 0x1348 <_llm_rows.packet_batch.blocks+0xb9c>
    1164:      	mov.16b	v5, v8
    1168:      	tbz	w12, #0x3, 0x1174 <_llm_rows.packet_batch.blocks+0x9c8>
    116c:      	add	x13, x11, #0xc
    1170:      	st1.s	{ v1 }[3], [x13]
    1174:      	and.16b	v0, v30, v0
    1178:      	ldp	q1, q31, [sp, #0x1c0]
    117c:      	fmul.4s	v1, v0, v1
    1180:      	fmul.4s	v1, v0, v1
    1184:      	fmul.4s	v1, v0, v1
    1188:      	fadd.4s	v1, v0, v1
    118c:      	ldr	q7, [sp, #0x1a0]
    1190:      	fmul.4s	v1, v1, v7
    1194:      	and.16b	v1, v30, v1
    1198:      	fabs.4s	v29, v1
    119c:      	fmul.4s	v7, v1, v1
    11a0:      	ldp	q16, q28, [sp, #0x1e0]
    11a4:      	fmla.4s	v28, v7, v16
    11a8:      	fmla.4s	v31, v7, v28
    11ac:      	ldr	q28, [sp, #0x1b0]
    11b0:      	fmla.4s	v28, v7, v31
    11b4:      	mov.16b	v31, v10
    11b8:      	fmla.4s	v31, v7, v28
    11bc:      	mov.16b	v28, v26
    11c0:      	fmla.4s	v28, v7, v31
    11c4:      	mov.16b	v31, v25
    11c8:      	fmla.4s	v31, v7, v28
    11cc:      	fmul.4s	v28, v29, v31
    11d0:      	mov.16b	v31, v11
    11d4:      	ldp	q16, q17, [sp, #0x180]
    11d8:      	fmla.4s	v31, v7, v17
    11dc:      	mov.16b	v9, v13
    11e0:      	fmla.4s	v9, v7, v31
    11e4:      	mov.16b	v31, v14
    11e8:      	fmla.4s	v31, v7, v9
    11ec:      	mov.16b	v9, v15
    11f0:      	fmla.4s	v9, v7, v31
    11f4:      	movi.4s	v31, #0x3f, lsl #24
    11f8:      	fmla.4s	v31, v7, v9
    11fc:      	mov.16b	v9, v25
    1200:      	fmla.4s	v9, v7, v31
    1204:      	fdiv.4s	v7, v28, v9
    1208:      	fcmge.4s	v28, v16, v29
    120c:      	and.16b	v31, v28, v29
    1210:      	ldp	q16, q17, [sp, #0x160]
    1214:      	fcmge.4s	v9, v31, v17
    1218:      	fcmge.4s	v12, v27, v31
    121c:      	and.16b	v9, v9, v12
    1220:      	and.16b	v9, v9, v31
    1224:      	fmul.4s	v12, v9, v16
    1228:      	movi.4s	v16, #0x4b, lsl #24
    122c:      	fadd.4s	v12, v12, v16
    1230:      	movi.4s	v16, #0xcb, lsl #24
    1234:      	fadd.4s	v12, v12, v16
    1238:      	fcvtzs.4s	v12, v12
    123c:      	scvtf.4s	v16, v12
    1240:      	mov.16b	v8, v30
    1244:      	ldr	q17, [sp, #0x150]
    1248:      	fmul.4s	v30, v16, v17
    124c:      	fadd.4s	v30, v9, v30
    1250:      	fmul.4s	v16, v16, v24
    1254:      	fadd.4s	v16, v30, v16
    1258:      	fmul.4s	v30, v16, v2
    125c:      	fadd.4s	v30, v30, v18
    1260:      	fmul.4s	v30, v16, v30
    1264:      	fadd.4s	v30, v30, v6
    1268:      	fmul.4s	v30, v16, v30
    126c:      	fadd.4s	v30, v30, v23
    1270:      	fmul.4s	v30, v16, v30
    1274:      	fadd.4s	v30, v30, v26
    1278:      	fmul.4s	v30, v16, v30
    127c:      	movi.4s	v17, #0x3f, lsl #24
    1280:      	fadd.4s	v30, v30, v17
    1284:      	fmul.4s	v9, v16, v16
    1288:      	fmul.4s	v30, v9, v30
    128c:      	fadd.4s	v16, v16, v30
    1290:      	fadd.4s	v16, v16, v25
    1294:      	movi.2d	v30, #0xffffffffffffffff
    1298:      	add.4s	v30, v12, v30
    129c:      	sshr.4s	v9, v30, #0x1
    12a0:      	shl.4s	v12, v9, #0x17
    12a4:      	add.4s	v12, v12, v25
    12a8:      	fmul.4s	v16, v16, v12
    12ac:      	sub.4s	v30, v30, v9
    12b0:      	shl.4s	v30, v30, #0x17
    12b4:      	add.4s	v30, v30, v25
    12b8:      	fmul.4s	v16, v16, v30
    12bc:      	fcmgt.4s	v30, v31, v27
    12c0:      	ldr	q31, [sp, #0x210]
    12c4:      	bit.16b	v16, v31, v30
    12c8:      	fdiv.4s	v30, v4, v16
    12cc:      	fsub.4s	v31, v16, v30
    12d0:      	fadd.4s	v16, v16, v30
    12d4:      	mov.16b	v30, v8
    12d8:      	fdiv.4s	v16, v31, v16
    12dc:      	bif.16b	v16, v25, v28
    12e0:      	fcmge.4s	v28, v25, v29
    12e4:      	bif.16b	v7, v16, v28
    12e8:      	mvni.4s	v16, #0x80, lsl #24
    12ec:      	bif.16b	v7, v1, v16
    12f0:      	fcmeq.4s	v1, v1, v1
    12f4:      	fadd.4s	v7, v7, v25
    12f8:      	ldr	q16, [sp, #0x200]
    12fc:      	bsl.16b	v1, v7, v16
    1300:      	fmul.4s	v0, v0, v17
    1304:      	fmul.4s	v0, v0, v1
    1308:      	and.16b	v1, v8, v22
    130c:      	fadd.4s	v0, v1, v0
    1310:      	tbnz	w12, #0x4, 0x135c <_llm_rows.packet_batch.blocks+0xbb0>
    1314:      	mov.16b	v8, v5
    1318:      	ldp	q17, q16, [sp, #0x120]
    131c:      	ldp	q29, q28, [sp, #0x100]
    1320:      	tbnz	w12, #0x5, 0x1370 <_llm_rows.packet_batch.blocks+0xbc4>
    1324:      	tbnz	w12, #0x6, 0x137c <_llm_rows.packet_batch.blocks+0xbd0>
    1328:      	tbz	w12, #0x7, 0xed4 <_llm_rows.packet_batch.blocks+0x728>
    132c:      	b	0x1388 <_llm_rows.packet_batch.blocks+0xbdc>
    1330:      	str	s1, [x11]
    1334:      	and	w12, w12, #0xff
    1338:      	tbz	w12, #0x1, 0x1160 <_llm_rows.packet_batch.blocks+0x9b4>
    133c:      	add	x13, x11, #0x4
    1340:      	st1.s	{ v1 }[1], [x13]
    1344:      	tbz	w12, #0x2, 0x1164 <_llm_rows.packet_batch.blocks+0x9b8>
    1348:      	add	x13, x11, #0x8
    134c:      	st1.s	{ v1 }[2], [x13]
    1350:      	mov.16b	v5, v8
    1354:      	tbnz	w12, #0x3, 0x116c <_llm_rows.packet_batch.blocks+0x9c0>
    1358:      	b	0x1174 <_llm_rows.packet_batch.blocks+0x9c8>
    135c:      	str	s0, [x11, #0x10]
    1360:      	mov.16b	v8, v5
    1364:      	ldp	q17, q16, [sp, #0x120]
    1368:      	ldp	q29, q28, [sp, #0x100]
    136c:      	tbz	w12, #0x5, 0x1324 <_llm_rows.packet_batch.blocks+0xb78>
    1370:      	add	x13, x11, #0x14
    1374:      	st1.s	{ v0 }[1], [x13]
    1378:      	tbz	w12, #0x6, 0x1328 <_llm_rows.packet_batch.blocks+0xb7c>
    137c:      	add	x13, x11, #0x18
    1380:      	st1.s	{ v0 }[2], [x13]
    1384:      	tbz	w12, #0x7, 0xed4 <_llm_rows.packet_batch.blocks+0x728>
    1388:      	add	x11, x11, #0x1c
    138c:      	st1.s	{ v0 }[3], [x11]
    1390:      	b	0xed4 <_llm_rows.packet_batch.blocks+0x728>
    1394:      	ldr	q5, [sp, #0xa0]
    1398:      	ldr	q0, [sp, #0x1c0]
    139c:      	fmul.4s	v0, v5, v0
    13a0:      	fmul.4s	v0, v5, v0
    13a4:      	fmul.4s	v0, v5, v0
    13a8:      	fadd.4s	v0, v5, v0
    13ac:      	ldr	q1, [sp, #0x1a0]
    13b0:      	fmul.4s	v0, v0, v1
    13b4:      	ldr	q1, [sp, #0xe0]
    13b8:      	zip1.8b	v1, v1, v0
    13bc:      	ushll.4s	v1, v1, #0x0
    13c0:      	shl.4s	v1, v1, #0x1f
    13c4:      	cmlt.4s	v1, v1, #0
    13c8:      	and.16b	v0, v1, v0
    13cc:      	fabs.4s	v1, v0
    13d0:      	fmul.4s	v3, v0, v0
    13d4:      	ldp	q16, q7, [sp, #0x1e0]
    13d8:      	fmla.4s	v7, v3, v16
    13dc:      	ldr	q16, [sp, #0x1d0]
    13e0:      	fmla.4s	v16, v3, v7
    13e4:      	ldr	q7, [sp, #0x1b0]
    13e8:      	fmla.4s	v7, v3, v16
    13ec:      	mov.16b	v16, v10
    13f0:      	fmla.4s	v16, v3, v7
    13f4:      	mov.16b	v7, v26
    13f8:      	fmla.4s	v7, v3, v16
    13fc:      	mov.16b	v16, v25
    1400:      	fmla.4s	v16, v3, v7
    1404:      	fmul.4s	v7, v1, v16
    1408:      	mov.16b	v16, v11
    140c:      	ldr	q17, [sp, #0x190]
    1410:      	fmla.4s	v16, v3, v17
    1414:      	mov.16b	v19, v13
    1418:      	fmla.4s	v19, v3, v16
    141c:      	mov.16b	v16, v14
    1420:      	fmla.4s	v16, v3, v19
    1424:      	mov.16b	v19, v15
    1428:      	fmla.4s	v19, v3, v16
    142c:      	movi.4s	v16, #0x3f, lsl #24
    1430:      	fmla.4s	v16, v3, v19
    1434:      	mov.16b	v19, v25
    1438:      	fmla.4s	v19, v3, v16
    143c:      	fdiv.4s	v3, v7, v19
    1440:      	ldp	q17, q7, [sp, #0x170]
    1444:      	fcmge.4s	v7, v7, v1
    1448:      	and.16b	v16, v7, v1
    144c:      	fcmge.4s	v19, v16, v17
    1450:      	fcmge.4s	v20, v27, v16
    1454:      	and.16b	v19, v19, v20
    1458:      	and.16b	v19, v19, v16
    145c:      	ldr	q17, [sp, #0x160]
    1460:      	fmul.4s	v20, v19, v17
    1464:      	movi.4s	v17, #0x4b, lsl #24
    1468:      	fadd.4s	v20, v20, v17
    146c:      	movi.4s	v17, #0xcb, lsl #24
    1470:      	fadd.4s	v20, v20, v17
    1474:      	fcvtzs.4s	v20, v20
    1478:      	scvtf.4s	v21, v20
    147c:      	ldr	q17, [sp, #0x150]
    1480:      	fmul.4s	v22, v21, v17
    1484:      	fadd.4s	v19, v19, v22
    1488:      	fmul.4s	v21, v21, v24
    148c:      	fadd.4s	v19, v19, v21
    1490:      	fmul.4s	v21, v19, v2
    1494:      	fadd.4s	v21, v21, v18
    1498:      	fmul.4s	v21, v19, v21
    149c:      	fadd.4s	v21, v21, v6
    14a0:      	fmul.4s	v21, v19, v21
    14a4:      	fadd.4s	v21, v21, v23
    14a8:      	fmul.4s	v21, v19, v21
    14ac:      	fadd.4s	v21, v21, v26
    14b0:      	fmul.4s	v21, v19, v21
    14b4:      	movi.4s	v17, #0x3f, lsl #24
    14b8:      	fadd.4s	v21, v21, v17
    14bc:      	fmul.4s	v22, v19, v19
    14c0:      	fmul.4s	v21, v22, v21
    14c4:      	fadd.4s	v19, v19, v21
    14c8:      	fadd.4s	v19, v19, v25
    14cc:      	movi.2d	v21, #0xffffffffffffffff
    14d0:      	add.4s	v20, v20, v21
    14d4:      	sshr.4s	v21, v20, #0x1
    14d8:      	shl.4s	v22, v21, #0x17
    14dc:      	add.4s	v22, v22, v25
    14e0:      	fmul.4s	v19, v19, v22
    14e4:      	sub.4s	v20, v20, v21
    14e8:      	shl.4s	v20, v20, #0x17
    14ec:      	add.4s	v20, v20, v25
    14f0:      	fmul.4s	v19, v19, v20
    14f4:      	fcmgt.4s	v16, v16, v27
    14f8:      	ldr	q20, [sp, #0x210]
    14fc:      	bsl.16b	v16, v20, v19
    1500:      	fdiv.4s	v19, v4, v16
    1504:      	fsub.4s	v20, v16, v19
    1508:      	fadd.4s	v16, v16, v19
    150c:      	fdiv.4s	v16, v20, v16
    1510:      	bsl.16b	v7, v16, v25
    1514:      	fcmge.4s	v1, v25, v1
    1518:      	bsl.16b	v1, v3, v7
    151c:      	ldr	d3, [sp, #0x48]
    1520:      	fmov	w10, s3
    1524:      	mvni.4s	v3, #0x80, lsl #24
    1528:      	bif.16b	v1, v0, v3
    152c:      	fcmeq.4s	v0, v0, v0
    1530:      	fadd.4s	v1, v1, v25
    1534:      	ldr	q3, [sp, #0x200]
    1538:      	bsl.16b	v0, v1, v3
    153c:      	fmul.4s	v1, v5, v17
    1540:      	fmul.4s	v0, v1, v0
    1544:      	ldr	q1, [sp, #0x50]
    1548:      	fadd.4s	v0, v0, v1
    154c:      	ldr	q3, [sp, #0xb0]
    1550:      	ldp	q5, q7, [sp, #0x80]
    1554:      	stp	q3, q5, [sp, #0x220]
    1558:      	ldr	q1, [sp, #0x70]
    155c:      	stp	q7, q1, [sp, #0x240]
    1560:      	and	x11, x9, #0x7
    1564:      	add	x12, sp, #0x220
    1568:      	ldr	x11, [x12, x11, lsl #3]
    156c:      	sub	x9, x11, x9
    1570:      	add	x8, x8, x9, lsl #2
    1574:      	tbnz	w10, #0x0, 0x1800 <_llm_rows.packet_batch.blocks+0x1054>
    1578:      	ldr	q21, [sp, #0xc0]
    157c:      	tbnz	w10, #0x1, 0x180c <_llm_rows.packet_batch.blocks+0x1060>
    1580:      	tbnz	w10, #0x2, 0x1818 <_llm_rows.packet_batch.blocks+0x106c>
    1584:      	tbz	w10, #0x3, 0x1590 <_llm_rows.packet_batch.blocks+0xde4>
    1588:      	add	x9, x8, #0xc
    158c:      	st1.s	{ v0 }[3], [x9]
    1590:      	ldr	q0, [sp, #0x1c0]
    1594:      	fmul.4s	v0, v21, v0
    1598:      	fmul.4s	v0, v21, v0
    159c:      	fmul.4s	v0, v21, v0
    15a0:      	fadd.4s	v0, v21, v0
    15a4:      	ldr	q1, [sp, #0x1a0]
    15a8:      	fmul.4s	v0, v0, v1
    15ac:      	ldr	q1, [sp, #0xe0]
    15b0:      	zip2.8b	v1, v1, v0
    15b4:      	ushll.4s	v1, v1, #0x0
    15b8:      	shl.4s	v1, v1, #0x1f
    15bc:      	cmlt.4s	v1, v1, #0
    15c0:      	and.16b	v0, v1, v0
    15c4:      	fmul.4s	v1, v0, v0
    15c8:      	ldp	q5, q3, [sp, #0x1e0]
    15cc:      	fmla.4s	v3, v1, v5
    15d0:      	ldr	q5, [sp, #0x1d0]
    15d4:      	fmla.4s	v5, v1, v3
    15d8:      	ldr	q3, [sp, #0x1b0]
    15dc:      	fmla.4s	v3, v1, v5
    15e0:      	fmla.4s	v10, v1, v3
    15e4:      	mov.16b	v3, v26
    15e8:      	fmla.4s	v3, v1, v10
    15ec:      	mov.16b	v7, v25
    15f0:      	fmla.4s	v7, v1, v3
    15f4:      	ldp	q5, q3, [sp, #0x180]
    15f8:      	fmla.4s	v11, v1, v3
    15fc:      	fmla.4s	v13, v1, v11
    1600:      	fmla.4s	v14, v1, v13
    1604:      	fmla.4s	v15, v1, v14
    1608:      	movi.4s	v3, #0x3f, lsl #24
    160c:      	fmla.4s	v3, v1, v15
    1610:      	mov.16b	v16, v25
    1614:      	fmla.4s	v16, v1, v3
    1618:      	fabs.4s	v1, v0
    161c:      	fmul.4s	v3, v1, v7
    1620:      	fdiv.4s	v3, v3, v16
    1624:      	fcmge.4s	v7, v5, v1
    1628:      	and.16b	v16, v7, v1
    162c:      	ldr	q5, [sp, #0x170]
    1630:      	fcmge.4s	v19, v16, v5
    1634:      	fcmge.4s	v20, v27, v16
    1638:      	and.16b	v19, v19, v20
    163c:      	and.16b	v19, v19, v16
    1640:      	ldr	q5, [sp, #0x160]
    1644:      	fmul.4s	v17, v19, v5
    1648:      	movi.4s	v20, #0x4b, lsl #24
    164c:      	fadd.4s	v17, v17, v20
    1650:      	movi.4s	v20, #0xcb, lsl #24
    1654:      	fadd.4s	v17, v17, v20
    1658:      	fcvtzs.4s	v17, v17
    165c:      	scvtf.4s	v20, v17
    1660:      	ldr	q5, [sp, #0x150]
    1664:      	fmul.4s	v5, v20, v5
    1668:      	fadd.4s	v5, v19, v5
    166c:      	fmul.4s	v19, v20, v24
    1670:      	fadd.4s	v5, v5, v19
    1674:      	fmul.4s	v2, v5, v2
    1678:      	fadd.4s	v2, v2, v18
    167c:      	fmul.4s	v2, v5, v2
    1680:      	fadd.4s	v2, v2, v6
    1684:      	fmul.4s	v2, v5, v2
    1688:      	fadd.4s	v2, v2, v23
    168c:      	fmul.4s	v2, v5, v2
    1690:      	fadd.4s	v2, v2, v26
    1694:      	fmul.4s	v2, v5, v2
    1698:      	movi.4s	v18, #0x3f, lsl #24
    169c:      	fadd.4s	v2, v2, v18
    16a0:      	fmul.4s	v6, v5, v5
    16a4:      	fmul.4s	v2, v6, v2
    16a8:      	fadd.4s	v2, v5, v2
    16ac:      	fadd.4s	v2, v2, v25
    16b0:      	movi.2d	v5, #0xffffffffffffffff
    16b4:      	add.4s	v5, v17, v5
    16b8:      	sshr.4s	v6, v5, #0x1
    16bc:      	shl.4s	v17, v6, #0x17
    16c0:      	add.4s	v17, v17, v25
    16c4:      	fmul.4s	v2, v2, v17
    16c8:      	sub.4s	v5, v5, v6
    16cc:      	shl.4s	v5, v5, #0x17
    16d0:      	add.4s	v5, v5, v25
    16d4:      	fmul.4s	v2, v2, v5
    16d8:      	fcmgt.4s	v5, v16, v27
    16dc:      	ldr	q6, [sp, #0x210]
    16e0:      	bit.16b	v2, v6, v5
    16e4:      	fdiv.4s	v4, v4, v2
    16e8:      	fsub.4s	v5, v2, v4
    16ec:      	fadd.4s	v2, v2, v4
    16f0:      	fdiv.4s	v2, v5, v2
    16f4:      	bif.16b	v2, v25, v7
    16f8:      	fcmge.4s	v1, v25, v1
    16fc:      	bsl.16b	v1, v3, v2
    1700:      	mvni.4s	v2, #0x80, lsl #24
    1704:      	bif.16b	v1, v0, v2
    1708:      	fadd.4s	v1, v1, v25
    170c:      	fcmeq.4s	v0, v0, v0
    1710:      	ldr	q2, [sp, #0x200]
    1714:      	bsl.16b	v0, v1, v2
    1718:      	fmul.4s	v1, v21, v18
    171c:      	fmul.4s	v0, v1, v0
    1720:      	ldr	q1, [sp, #0x60]
    1724:      	fadd.4s	v0, v0, v1
    1728:      	tbnz	w10, #0x4, 0x1828 <_llm_rows.packet_batch.blocks+0x107c>
    172c:      	tbnz	w10, #0x5, 0x1830 <_llm_rows.packet_batch.blocks+0x1084>
    1730:      	tbnz	w10, #0x6, 0x183c <_llm_rows.packet_batch.blocks+0x1090>
    1734:      	tbz	w10, #0x7, 0x854 <_llm_rows.packet_batch.blocks+0xa8>
    1738:      	b	0x1848 <_llm_rows.packet_batch.blocks+0x109c>
    173c:      	add	x14, x12, #0x4
    1740:      	ld1.s	{ v22 }[1], [x14]
    1744:      	tbz	w13, #0x2, 0xbd8 <_llm_rows.packet_batch.blocks+0x42c>
    1748:      	add	x14, x12, #0x8
    174c:      	ld1.s	{ v22 }[2], [x14]
    1750:      	tbz	w13, #0x3, 0xbdc <_llm_rows.packet_batch.blocks+0x430>
    1754:      	add	x14, x12, #0xc
    1758:      	ld1.s	{ v22 }[3], [x14]
    175c:      	tbz	w13, #0x4, 0xbe0 <_llm_rows.packet_batch.blocks+0x434>
    1760:      	add	x14, x12, #0x10
    1764:      	ld1.s	{ v20 }[0], [x14]
    1768:      	tbz	w13, #0x5, 0xbe4 <_llm_rows.packet_batch.blocks+0x438>
    176c:      	add	x14, x12, #0x14
    1770:      	ld1.s	{ v20 }[1], [x14]
    1774:      	tbz	w13, #0x6, 0xbe8 <_llm_rows.packet_batch.blocks+0x43c>
    1778:      	add	x14, x12, #0x18
    177c:      	ld1.s	{ v20 }[2], [x14]
    1780:      	tbnz	w13, #0x7, 0xbec <_llm_rows.packet_batch.blocks+0x440>
    1784:      	b	0xbf4 <_llm_rows.packet_batch.blocks+0x448>
    1788:      	ldr	s4, [x10]
    178c:      	mov	w15, #0xb61             ; =2913
    1790:      	movk	w15, #0x3ab6, lsl #16
    1794:      	mov	w16, #0xaaab            ; =43691
    1798:      	movk	w16, #0x3d2a, lsl #16
    179c:      	mov	w17, #-0x3d300000       ; =-1026555904
    17a0:      	tbz	w11, #0x1, 0xe44 <_llm_rows.packet_batch.blocks+0x698>
    17a4:      	add	x14, x10, #0x4
    17a8:      	ld1.s	{ v4 }[1], [x14]
    17ac:      	tbz	w11, #0x2, 0xe48 <_llm_rows.packet_batch.blocks+0x69c>
    17b0:      	add	x14, x10, #0x8
    17b4:      	ld1.s	{ v4 }[2], [x14]
    17b8:      	tbz	w11, #0x3, 0xe4c <_llm_rows.packet_batch.blocks+0x6a0>
    17bc:      	add	x14, x10, #0xc
    17c0:      	ld1.s	{ v4 }[3], [x14]
    17c4:      	tbz	w11, #0x4, 0xe50 <_llm_rows.packet_batch.blocks+0x6a4>
    17c8:      	add	x14, x10, #0x10
    17cc:      	ld1.s	{ v3 }[0], [x14]
    17d0:      	tbz	w11, #0x5, 0xe54 <_llm_rows.packet_batch.blocks+0x6a8>
    17d4:      	add	x14, x10, #0x14
    17d8:      	ld1.s	{ v3 }[1], [x14]
    17dc:      	tbz	w11, #0x6, 0xe58 <_llm_rows.packet_batch.blocks+0x6ac>
    17e0:      	add	x14, x10, #0x18
    17e4:      	ld1.s	{ v3 }[2], [x14]
    17e8:      	mov	w14, #0xd01             ; =3329
    17ec:      	movk	w14, #0x37d0, lsl #16
    17f0:      	str	q20, [sp, #0xc0]
    17f4:      	str	q22, [sp, #0xa0]
    17f8:      	tbnz	w11, #0x7, 0xe6c <_llm_rows.packet_batch.blocks+0x6c0>
    17fc:      	b	0xe74 <_llm_rows.packet_batch.blocks+0x6c8>
    1800:      	str	s0, [x8]
    1804:      	ldr	q21, [sp, #0xc0]
    1808:      	tbz	w10, #0x1, 0x1580 <_llm_rows.packet_batch.blocks+0xdd4>
    180c:      	add	x9, x8, #0x4
    1810:      	st1.s	{ v0 }[1], [x9]
    1814:      	tbz	w10, #0x2, 0x1584 <_llm_rows.packet_batch.blocks+0xdd8>
    1818:      	add	x9, x8, #0x8
    181c:      	st1.s	{ v0 }[2], [x9]
    1820:      	tbnz	w10, #0x3, 0x1588 <_llm_rows.packet_batch.blocks+0xddc>
    1824:      	b	0x1590 <_llm_rows.packet_batch.blocks+0xde4>
    1828:      	str	s0, [x8, #0x10]
    182c:      	tbz	w10, #0x5, 0x1730 <_llm_rows.packet_batch.blocks+0xf84>
    1830:      	add	x9, x8, #0x14
    1834:      	st1.s	{ v0 }[1], [x9]
    1838:      	tbz	w10, #0x6, 0x1734 <_llm_rows.packet_batch.blocks+0xf88>
    183c:      	add	x9, x8, #0x18
    1840:      	st1.s	{ v0 }[2], [x9]
    1844:      	tbz	w10, #0x7, 0x854 <_llm_rows.packet_batch.blocks+0xa8>
    1848:      	add	x8, x8, #0x1c
    184c:      	st1.s	{ v0 }[3], [x8]
    1850:      	b	0x854 <_llm_rows.packet_batch.blocks+0xa8>
    1854:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    1858:      	add	sp, sp, #0x340
    185c:      	ldp	x29, x30, [sp, #0x90]
    1860:      	ldp	x20, x19, [sp, #0x80]
    1864:      	ldp	x22, x21, [sp, #0x70]
    1868:      	ldp	x24, x23, [sp, #0x60]
    186c:      	ldp	x26, x25, [sp, #0x50]
    1870:      	ldp	x28, x27, [sp, #0x40]
    1874:      	ldp	d9, d8, [sp, #0x30]
    1878:      	ldp	d11, d10, [sp, #0x20]
    187c:      	ldp	d13, d12, [sp, #0x10]
    1880:      	ldp	d15, d14, [sp], #0xa0
    1884:      	ret


/private/tmp/luisa-native-rows.LuX3yX/capture-v3/gelu_residual-1024x4097-l1/object/tile_xir_w8_80781_1788919117336691_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x130
       4:      	stp	d15, d14, [sp, #0xe0]
       8:      	stp	d13, d12, [sp, #0xf0]
       c:      	stp	d11, d10, [sp, #0x100]
      10:      	stp	d9, d8, [sp, #0x110]
      14:      	stp	x28, x27, [sp, #0x120]
      18:      	mov	x10, #0x0               ; =0
      1c:      	ldr	x8, [x1, #0x88]
      20:      	ldr	x13, [x0]
      24:      	ldr	w9, [x1]
      28:      	ldr	w11, [x1, #0x24]
      2c:      	add	w12, w11, w9, lsl #5
      30:      	ldr	x11, [x0, #0x10]
      34:      	ldr	x9, [x0, #0x30]
      38:      	dup.4s	v0, w12
      3c:      	adrp	x12, 0x0 <ltmp0>
      40:      	ldr	q1, [x12]
      44:      	add.4s	v2, v0, v1
      48:      	adrp	x12, 0x0 <ltmp0>
      4c:      	ldr	q1, [x12]
      50:      	add.4s	v3, v0, v1
      54:      	mov	w12, #0x1001            ; =4097
      58:      	dup.4s	v4, w12
      5c:      	umull2.2d	v0, v2, v4
      60:      	umull2.2d	v1, v3, v4
      64:      	umull.2d	v2, v2, v4
      68:      	umull.2d	v3, v3, v4
      6c:      	dup.2d	v4, x13
      70:      	dup.2d	v5, x10
      74:      	add.2d	v6, v5, v0
      78:      	add.2d	v7, v5, v2
      7c:      	add.2d	v16, v5, v1
      80:      	add.2d	v5, v5, v3
      84:      	shl.2d	v5, v5, #0x2
      88:      	shl.2d	v16, v16, #0x2
      8c:      	shl.2d	v7, v7, #0x2
      90:      	shl.2d	v6, v6, #0x2
      94:      	add.2d	v6, v4, v6
      98:      	add.2d	v7, v4, v7
      9c:      	add.2d	v16, v4, v16
      a0:      	add.2d	v5, v4, v5
      a4:      	mov.d	x13, v5[1]
      a8:      	fmov	x14, d5
      ac:      	mov.d	x15, v16[1]
      b0:      	fmov	x16, d16
      b4:      	mov.d	x17, v7[1]
      b8:      	fmov	x0, d7
      bc:      	mov.d	x1, v6[1]
      c0:      	ldr	s5, [x14]
      c4:      	ld1.s	{ v5 }[1], [x13]
      c8:      	fmov	x13, d6
      cc:      	ld1.s	{ v5 }[2], [x16]
      d0:      	ld1.s	{ v5 }[3], [x15]
      d4:      	ldr	s6, [x0]
      d8:      	ld1.s	{ v6 }[1], [x17]
      dc:      	ld1.s	{ v6 }[2], [x13]
      e0:      	ld1.s	{ v6 }[3], [x1]
      e4:      	add	x13, x8, x10, lsl #5
      e8:      	stp	q5, q6, [x13]
      ec:      	add	x10, x10, #0x1
      f0:      	cmp	x10, x12
      f4:      	b.ne	0x70 <ltmp0+0x70>
      f8:      	mov	x12, #0x0               ; =0
      fc:      	add	x10, x8, #0x20, lsl #12 ; =0x20000
     100:      	add	x10, x10, #0x20
     104:      	dup.2d	v4, x11
     108:      	mov	w11, #0x1001            ; =4097
     10c:      	dup.2d	v5, x12
     110:      	add.2d	v6, v5, v0
     114:      	add.2d	v7, v5, v2
     118:      	add.2d	v16, v5, v1
     11c:      	add.2d	v5, v5, v3
     120:      	shl.2d	v5, v5, #0x2
     124:      	shl.2d	v16, v16, #0x2
     128:      	shl.2d	v7, v7, #0x2
     12c:      	shl.2d	v6, v6, #0x2
     130:      	add.2d	v6, v4, v6
     134:      	add.2d	v7, v4, v7
     138:      	add.2d	v16, v4, v16
     13c:      	add.2d	v5, v4, v5
     140:      	mov.d	x13, v5[1]
     144:      	fmov	x14, d5
     148:      	mov.d	x15, v16[1]
     14c:      	fmov	x16, d16
     150:      	mov.d	x17, v7[1]
     154:      	fmov	x0, d7
     158:      	mov.d	x1, v6[1]
     15c:      	ldr	s5, [x14]
     160:      	ld1.s	{ v5 }[1], [x13]
     164:      	fmov	x13, d6
     168:      	ld1.s	{ v5 }[2], [x16]
     16c:      	ld1.s	{ v5 }[3], [x15]
     170:      	ldr	s6, [x0]
     174:      	ld1.s	{ v6 }[1], [x17]
     178:      	ld1.s	{ v6 }[2], [x13]
     17c:      	ld1.s	{ v6 }[3], [x1]
     180:      	add	x13, x10, x12, lsl #5
     184:      	stp	q5, q6, [x13]
     188:      	add	x12, x12, #0x1
     18c:      	cmp	x12, x11
     190:      	b.ne	0x10c <ltmp0+0x10c>
     194:      	mov	x11, #0x0               ; =0
     198:      	mov	w12, #0x2713            ; =10003
     19c:      	movk	w12, #0x3d37, lsl #16
     1a0:      	dup.4s	v5, w12
     1a4:      	mov	w12, #0x422a            ; =16938
     1a8:      	movk	w12, #0x3f4c, lsl #16
     1ac:      	dup.4s	v4, w12
     1b0:      	stp	q4, q5, [sp, #0xc0]
     1b4:      	fmov.4s	v7, #1.00000000
     1b8:      	mov	w12, #0x9231            ; =37425
     1bc:      	movk	w12, #0x2f30, lsl #16
     1c0:      	dup.4s	v5, w12
     1c4:      	mov	w12, #0x322b            ; =12843
     1c8:      	movk	w12, #0x32d7, lsl #16
     1cc:      	dup.4s	v4, w12
     1d0:      	stp	q4, q5, [sp, #0xa0]
     1d4:      	mov	w12, #0xef1d            ; =61213
     1d8:      	movk	w12, #0x3638, lsl #16
     1dc:      	dup.4s	v5, w12
     1e0:      	mov	w12, #0xd01             ; =3329
     1e4:      	movk	w12, #0x3950, lsl #16
     1e8:      	dup.4s	v4, w12
     1ec:      	stp	q4, q5, [sp, #0x80]
     1f0:      	mov	w12, #0x8889            ; =34953
     1f4:      	movk	w12, #0x3c08, lsl #16
     1f8:      	dup.4s	v5, w12
     1fc:      	mov	w12, #0xaaab            ; =43691
     200:      	movk	w12, #0x3e2a, lsl #16
     204:      	dup.4s	v22, w12
     208:      	mov	w12, #0x76c7            ; =30407
     20c:      	movk	w12, #0x310f, lsl #16
     210:      	dup.4s	v4, w12
     214:      	stp	q4, q5, [sp, #0x60]
     218:      	mov	w12, #0xf27e            ; =62078
     21c:      	movk	w12, #0x3493, lsl #16
     220:      	dup.4s	v5, w12
     224:      	mov	w12, #0xd01             ; =3329
     228:      	movk	w12, #0x37d0, lsl #16
     22c:      	dup.4s	v4, w12
     230:      	stp	q4, q5, [sp, #0x40]
     234:      	mov	w12, #0xb61             ; =2913
     238:      	movk	w12, #0x3ab6, lsl #16
     23c:      	dup.4s	v5, w12
     240:      	mov	w12, #0xaaab            ; =43691
     244:      	movk	w12, #0x3d2a, lsl #16
     248:      	dup.4s	v4, w12
     24c:      	stp	q4, q5, [sp, #0x20]
     250:      	fmov.4s	v5, #9.00000000
     254:      	mov	w12, #-0x3d300000       ; =-1026555904
     258:      	dup.4s	v4, w12
     25c:      	stp	q4, q5, [sp]
     260:      	mov	w12, #0x42c80000        ; =1120403456
     264:      	dup.4s	v29, w12
     268:      	mov	w12, #0xaa3b            ; =43579
     26c:      	movk	w12, #0x3fb8, lsl #16
     270:      	dup.4s	v30, w12
     274:      	mov	w12, #0x7200            ; =29184
     278:      	movk	w12, #0xbf31, lsl #16
     27c:      	mov	w13, #0xbe8e            ; =48782
     280:      	movk	w13, #0xb5bf, lsl #16
     284:      	mov	w14, #0x2bda            ; =11226
     288:      	movk	w14, #0x3950, lsl #16
     28c:      	mov	w15, #0x96c9            ; =38601
     290:      	movk	w15, #0x3ab6, lsl #16
     294:      	mov	w16, #0x88a6            ; =34982
     298:      	movk	w16, #0x3c08, lsl #16
     29c:      	mov	w17, #0xaa7a            ; =43642
     2a0:      	movk	w17, #0x3d2a, lsl #16
     2a4:      	mvni.4s	v4, #0x7f, msl #16
     2a8:      	fneg.4s	v10, v4
     2ac:      	mvni.4s	v4, #0x3f, msl #16
     2b0:      	fneg.4s	v12, v4
     2b4:      	mov	w0, #0x1001             ; =4097
     2b8:      	lsl	x1, x11, #5
     2bc:      	add	x2, x8, x1
     2c0:      	ldp	q13, q14, [x2]
     2c4:      	ldp	q6, q5, [sp, #0xc0]
     2c8:      	fmul.4s	v4, v14, v5
     2cc:      	fmul.4s	v5, v13, v5
     2d0:      	fmul.4s	v5, v13, v5
     2d4:      	fmul.4s	v4, v14, v4
     2d8:      	fmul.4s	v4, v14, v4
     2dc:      	fmul.4s	v5, v13, v5
     2e0:      	fadd.4s	v5, v13, v5
     2e4:      	fadd.4s	v4, v14, v4
     2e8:      	fmul.4s	v31, v4, v6
     2ec:      	fmul.4s	v15, v5, v6
     2f0:      	fabs.4s	v9, v15
     2f4:      	fabs.4s	v8, v31
     2f8:      	fmul.4s	v16, v31, v31
     2fc:      	fmul.4s	v19, v15, v15
     300:      	ldp	q5, q6, [sp, #0xa0]
     304:      	mov.16b	v4, v5
     308:      	fmla.4s	v4, v16, v6
     30c:      	fmla.4s	v5, v19, v6
     310:      	ldr	q17, [sp, #0x90]
     314:      	mov.16b	v6, v17
     318:      	fmla.4s	v6, v16, v4
     31c:      	mov.16b	v4, v17
     320:      	fmla.4s	v4, v19, v5
     324:      	ldr	q17, [sp, #0x80]
     328:      	mov.16b	v5, v17
     32c:      	fmla.4s	v5, v16, v6
     330:      	mov.16b	v6, v17
     334:      	fmla.4s	v6, v19, v4
     338:      	ldp	q23, q17, [sp, #0x60]
     33c:      	mov.16b	v4, v17
     340:      	mov.16b	v20, v22
     344:      	fmla.4s	v4, v16, v5
     348:      	mov.16b	v21, v22
     34c:      	mov.16b	v18, v7
     350:      	mov.16b	v5, v7
     354:      	ldr	q24, [sp, #0x50]
     358:      	mov.16b	v11, v24
     35c:      	fmla.4s	v11, v19, v23
     360:      	fmla.4s	v17, v19, v6
     364:      	mov.16b	v6, v24
     368:      	fmla.4s	v6, v16, v23
     36c:      	ldr	q23, [sp, #0x40]
     370:      	mov.16b	v24, v23
     374:      	fmla.4s	v24, v19, v11
     378:      	mov.16b	v11, v23
     37c:      	fmla.4s	v20, v16, v4
     380:      	fmla.4s	v11, v16, v6
     384:      	ldp	q23, q6, [sp, #0x20]
     388:      	mov.16b	v4, v6
     38c:      	fmla.4s	v4, v19, v24
     390:      	fmla.4s	v6, v16, v11
     394:      	fmla.4s	v21, v19, v17
     398:      	mov.16b	v17, v23
     39c:      	fmla.4s	v17, v19, v4
     3a0:      	mov.16b	v4, v23
     3a4:      	fmla.4s	v4, v16, v6
     3a8:      	movi.4s	v24, #0x3f, lsl #24
     3ac:      	fmla.4s	v24, v19, v17
     3b0:      	movi.4s	v23, #0x3f, lsl #24
     3b4:      	fmla.4s	v23, v16, v4
     3b8:      	ldr	q4, [sp, #0x10]
     3bc:      	fcmge.4s	v11, v4, v8
     3c0:      	fcmge.4s	v6, v4, v9
     3c4:      	and.16b	v17, v6, v9
     3c8:      	fmla.4s	v18, v16, v20
     3cc:      	and.16b	v4, v11, v8
     3d0:      	ldr	q20, [sp]
     3d4:      	fcmge.4s	v27, v4, v20
     3d8:      	fcmge.4s	v25, v17, v20
     3dc:      	fcmge.4s	v28, v29, v4
     3e0:      	fcmge.4s	v26, v29, v17
     3e4:      	mov.16b	v20, v7
     3e8:      	and.16b	v25, v25, v26
     3ec:      	and.16b	v26, v27, v28
     3f0:      	and.16b	v26, v26, v4
     3f4:      	and.16b	v25, v25, v17
     3f8:      	fmul.4s	v27, v25, v30
     3fc:      	fmla.4s	v5, v19, v21
     400:      	fmul.4s	v21, v26, v30
     404:      	movi.4s	v28, #0x4b, lsl #24
     408:      	fadd.4s	v21, v21, v28
     40c:      	fadd.4s	v27, v27, v28
     410:      	movi.4s	v28, #0xcb, lsl #24
     414:      	fadd.4s	v27, v27, v28
     418:      	fadd.4s	v21, v21, v28
     41c:      	fmla.4s	v20, v19, v24
     420:      	fcvtzs.4s	v19, v21
     424:      	fcvtzs.4s	v21, v27
     428:      	scvtf.4s	v24, v21
     42c:      	dup.4s	v27, w12
     430:      	fmul.4s	v28, v24, v27
     434:      	fadd.4s	v25, v25, v28
     438:      	scvtf.4s	v28, v19
     43c:      	fmul.4s	v27, v28, v27
     440:      	fadd.4s	v26, v26, v27
     444:      	dup.4s	v27, w13
     448:      	fmul.4s	v24, v24, v27
     44c:      	fmul.4s	v27, v28, v27
     450:      	fadd.4s	v26, v26, v27
     454:      	mov.16b	v27, v7
     458:      	fadd.4s	v24, v25, v24
     45c:      	fmla.4s	v27, v16, v23
     460:      	dup.4s	v16, w14
     464:      	fmul.4s	v23, v24, v16
     468:      	dup.4s	v25, w15
     46c:      	fmul.4s	v16, v26, v16
     470:      	fadd.4s	v16, v16, v25
     474:      	fadd.4s	v23, v23, v25
     478:      	fmul.4s	v23, v24, v23
     47c:      	dup.4s	v25, w16
     480:      	fmul.4s	v16, v26, v16
     484:      	fadd.4s	v16, v16, v25
     488:      	fadd.4s	v23, v23, v25
     48c:      	fmul.4s	v23, v24, v23
     490:      	dup.4s	v25, w17
     494:      	fmul.4s	v16, v26, v16
     498:      	fadd.4s	v16, v16, v25
     49c:      	fadd.4s	v23, v23, v25
     4a0:      	fmul.4s	v18, v8, v18
     4a4:      	fmul.4s	v23, v24, v23
     4a8:      	fmul.4s	v16, v26, v16
     4ac:      	fadd.4s	v16, v16, v22
     4b0:      	fadd.4s	v23, v23, v22
     4b4:      	fmul.4s	v23, v24, v23
     4b8:      	fmul.4s	v16, v26, v16
     4bc:      	movi.4s	v28, #0x3f, lsl #24
     4c0:      	fadd.4s	v25, v16, v28
     4c4:      	fadd.4s	v23, v23, v28
     4c8:      	fdiv.4s	v16, v18, v27
     4cc:      	fmul.4s	v18, v24, v24
     4d0:      	fmul.4s	v18, v18, v23
     4d4:      	fmul.4s	v23, v26, v26
     4d8:      	fmul.4s	v23, v23, v25
     4dc:      	fmul.4s	v5, v9, v5
     4e0:      	fdiv.4s	v5, v5, v20
     4e4:      	fadd.4s	v20, v26, v23
     4e8:      	fadd.4s	v18, v24, v18
     4ec:      	movi.2d	v25, #0xffffffffffffffff
     4f0:      	add.4s	v21, v21, v25
     4f4:      	sshr.4s	v23, v21, #0x1
     4f8:      	shl.4s	v24, v23, #0x17
     4fc:      	fadd.4s	v18, v18, v7
     500:      	add.4s	v24, v24, v7
     504:      	fmul.4s	v18, v18, v24
     508:      	sub.4s	v21, v21, v23
     50c:      	shl.4s	v21, v21, #0x17
     510:      	add.4s	v21, v21, v7
     514:      	fmul.4s	v18, v18, v21
     518:      	fcmgt.4s	v17, v17, v29
     51c:      	bsl.16b	v17, v10, v18
     520:      	fmov.4s	v18, #0.25000000
     524:      	fdiv.4s	v21, v18, v17
     528:      	fsub.4s	v23, v17, v21
     52c:      	fadd.4s	v17, v17, v21
     530:      	fdiv.4s	v17, v23, v17
     534:      	bsl.16b	v6, v17, v7
     538:      	fcmge.4s	v17, v7, v9
     53c:      	fadd.4s	v20, v20, v7
     540:      	add.4s	v19, v19, v25
     544:      	bif.16b	v5, v6, v17
     548:      	sshr.4s	v6, v19, #0x1
     54c:      	shl.4s	v17, v6, #0x17
     550:      	add.4s	v17, v17, v7
     554:      	fmul.4s	v17, v20, v17
     558:      	sub.4s	v6, v19, v6
     55c:      	shl.4s	v6, v6, #0x17
     560:      	add.4s	v6, v6, v7
     564:      	fmul.4s	v6, v17, v6
     568:      	fcmgt.4s	v4, v4, v29
     56c:      	bsl.16b	v4, v10, v6
     570:      	fdiv.4s	v6, v18, v4
     574:      	fsub.4s	v17, v4, v6
     578:      	fadd.4s	v4, v4, v6
     57c:      	fdiv.4s	v4, v17, v4
     580:      	bif.16b	v4, v7, v11
     584:      	dup.2d	v6, x11
     588:      	fcmge.4s	v17, v7, v8
     58c:      	bit.16b	v4, v16, v17
     590:      	mvni.4s	v19, #0x80, lsl #24
     594:      	bif.16b	v4, v31, v19
     598:      	fcmeq.4s	v16, v31, v31
     59c:      	fadd.4s	v4, v4, v7
     5a0:      	bif.16b	v4, v12, v16
     5a4:      	add.2d	v16, v6, v0
     5a8:      	fmul.4s	v17, v14, v28
     5ac:      	fmul.4s	v18, v13, v28
     5b0:      	bif.16b	v5, v15, v19
     5b4:      	fcmeq.4s	v19, v15, v15
     5b8:      	fadd.4s	v5, v5, v7
     5bc:      	bif.16b	v5, v12, v19
     5c0:      	fmul.4s	v5, v18, v5
     5c4:      	fmul.4s	v4, v17, v4
     5c8:      	add	x1, x10, x1
     5cc:      	ldp	q17, q18, [x1]
     5d0:      	add.2d	v19, v6, v2
     5d4:      	fadd.4s	v4, v18, v4
     5d8:      	add.2d	v18, v6, v1
     5dc:      	add.2d	v6, v6, v3
     5e0:      	shl.2d	v6, v6, #0x2
     5e4:      	shl.2d	v18, v18, #0x2
     5e8:      	fadd.4s	v5, v17, v5
     5ec:      	shl.2d	v17, v19, #0x2
     5f0:      	shl.2d	v16, v16, #0x2
     5f4:      	dup.2d	v19, x9
     5f8:      	add.2d	v16, v19, v16
     5fc:      	add.2d	v17, v19, v17
     600:      	add.2d	v18, v19, v18
     604:      	add.2d	v6, v19, v6
     608:      	mov.d	x1, v6[1]
     60c:      	mov.d	x2, v18[1]
     610:      	fmov	x3, d6
     614:      	fmov	x4, d18
     618:      	mov.d	x5, v17[1]
     61c:      	fmov	x6, d17
     620:      	str	s5, [x3]
     624:      	st1.s	{ v5 }[1], [x1]
     628:      	st1.s	{ v5 }[2], [x4]
     62c:      	st1.s	{ v5 }[3], [x2]
     630:      	mov.d	x1, v16[1]
     634:      	fmov	x2, d16
     638:      	str	s4, [x6]
     63c:      	st1.s	{ v4 }[1], [x5]
     640:      	st1.s	{ v4 }[2], [x2]
     644:      	st1.s	{ v4 }[3], [x1]
     648:      	add	x11, x11, #0x1
     64c:      	cmp	x11, x0
     650:      	b.ne	0x2b8 <ltmp0+0x2b8>
     654:      	ldp	x28, x27, [sp, #0x120]
     658:      	ldp	d9, d8, [sp, #0x110]
     65c:      	ldp	d11, d10, [sp, #0x100]
     660:      	ldp	d13, d12, [sp, #0xf0]
     664:      	ldp	d15, d14, [sp, #0xe0]
     668:      	add	sp, sp, #0x130
     66c:      	ret

0000000000000670 <_llm_rows.packet_batch.blocks>:
     670:      	stp	d15, d14, [sp, #-0xa0]!
     674:      	stp	d13, d12, [sp, #0x10]
     678:      	stp	d11, d10, [sp, #0x20]
     67c:      	stp	d9, d8, [sp, #0x30]
     680:      	stp	x28, x27, [sp, #0x40]
     684:      	stp	x26, x25, [sp, #0x50]
     688:      	stp	x24, x23, [sp, #0x60]
     68c:      	stp	x22, x21, [sp, #0x70]
     690:      	stp	x20, x19, [sp, #0x80]
     694:      	stp	x29, x30, [sp, #0x90]
     698:      	sub	sp, sp, #0x160
     69c:      	str	x0, [sp, #0x68]
     6a0:      	cbz	w3, 0x11ac <_llm_rows.packet_batch.blocks+0xb3c>
     6a4:      	mov	x23, x3
     6a8:      	mov	x20, x2
     6ac:      	mov	w22, #0x0               ; =0
     6b0:      	ldp	w9, w8, [x2, #0x2c]
     6b4:      	stp	w8, w9, [sp, #0x60]
     6b8:      	mov	w27, #0x1001            ; =4097
     6bc:      	ldp	w26, w25, [x2]
     6c0:      	mov	w16, #0x2713            ; =10003
     6c4:      	movk	w16, #0x3d37, lsl #16
     6c8:      	mov	w17, #0x422a            ; =16938
     6cc:      	movk	w17, #0x3f4c, lsl #16
     6d0:      	mov	w0, #0x9231             ; =37425
     6d4:      	movk	w0, #0x2f30, lsl #16
     6d8:      	ldp	w19, w21, [x2, #0x8]
     6dc:      	mov	w1, #0x322b             ; =12843
     6e0:      	movk	w1, #0x32d7, lsl #16
     6e4:      	adrp	x8, 0x0 <ltmp0>
     6e8:      	ldr	q0, [x8]
     6ec:      	str	q0, [sp, #0x50]
     6f0:      	mov	w2, #0xef1d             ; =61213
     6f4:      	movk	w2, #0x3638, lsl #16
     6f8:      	adrp	x8, 0x0 <ltmp0>
     6fc:      	ldr	q0, [x8]
     700:      	str	q0, [sp, #0x40]
     704:      	mov	w3, #0xd01              ; =3329
     708:      	movk	w3, #0x3950, lsl #16
     70c:      	dup.4s	v0, w27
     710:      	str	q0, [sp, #0x20]
     714:      	mov	w4, #0x8889             ; =34953
     718:      	movk	w4, #0x3c08, lsl #16
     71c:      	adrp	x8, 0x0 <ltmp0>
     720:      	ldr	q0, [x8]
     724:      	str	q0, [sp, #0x10]
     728:      	mov	w5, #0xaaab             ; =43691
     72c:      	movk	w5, #0x3e2a, lsl #16
     730:      	mov	w6, #0x76c7             ; =30407
     734:      	movk	w6, #0x310f, lsl #16
     738:      	mov	w7, #0xf27e             ; =62078
     73c:      	movk	w7, #0x3493, lsl #16
     740:      	mov	w30, #0xd01             ; =3329
     744:      	movk	w30, #0x37d0, lsl #16
     748:      	mvni.4s	v0, #0x7f, msl #16
     74c:      	fneg.4s	v1, v0
     750:      	mvni.4s	v0, #0x3f, msl #16
     754:      	fneg.4s	v0, v0
     758:      	stp	q0, q1, [sp, #0x120]
     75c:      	mov	w28, #0xaa7a            ; =43642
     760:      	movk	w28, #0x3d2a, lsl #16
     764:      	str	w23, [sp, #0x3c]
     768:      	b	0x7b0 <_llm_rows.packet_batch.blocks+0x140>
     76c:      	mov	w8, #0x18               ; =24
     770:      	str	w8, [x20, #0x24]
     774:      	ldr	w23, [sp, #0x3c]
     778:      	add	w8, w26, #0x1
     77c:      	ldp	w10, w9, [sp, #0x60]
     780:      	cmp	w8, w9
     784:      	cset	w8, eq
     788:      	csinc	w26, wzr, w26, eq
     78c:      	cinc	w9, w25, eq
     790:      	cmp	w9, w10
     794:      	cset	w10, eq
     798:      	ands	w8, w8, w10
     79c:      	csel	w25, wzr, w9, ne
     7a0:      	add	w19, w19, w8
     7a4:      	add	w22, w22, #0x1
     7a8:      	cmp	w22, w23
     7ac:      	b.eq	0x11ac <_llm_rows.packet_batch.blocks+0xb3c>
     7b0:      	ubfiz	x8, x26, #5, #32
     7b4:      	cmp	x8, x21
     7b8:      	csel	x9, x8, xzr, ls
     7bc:      	subs	x10, x21, x9
     7c0:      	cmp	x10, #0x20
     7c4:      	mov	w11, #0x20              ; =32
     7c8:      	csel	x10, x10, x11, lo
     7cc:      	cmp	x21, x9
     7d0:      	stp	w26, w25, [x20]
     7d4:      	str	w19, [x20, #0x8]
     7d8:      	str	wzr, [x20, #0x24]
     7dc:      	ccmp	x8, x21, #0x2, hi
     7e0:      	csel	x24, x10, xzr, ls
     7e4:      	cmp	x24, #0x20
     7e8:      	b.lo	0x894 <_llm_rows.packet_batch.blocks+0x224>
     7ec:      	ldr	x24, [sp, #0x68]
     7f0:      	mov	x0, x24
     7f4:      	mov	x1, x20
     7f8:      	bl	0x7f8 <_llm_rows.packet_batch.blocks+0x188>
     7fc:      	mov	w8, #0x8                ; =8
     800:      	str	w8, [x20, #0x24]
     804:      	mov	x0, x24
     808:      	mov	x1, x20
     80c:      	bl	0x80c <_llm_rows.packet_batch.blocks+0x19c>
     810:      	mov	w8, #0x10               ; =16
     814:      	str	w8, [x20, #0x24]
     818:      	mov	x0, x24
     81c:      	mov	x1, x20
     820:      	bl	0x820 <_llm_rows.packet_batch.blocks+0x1b0>
     824:      	mov	w8, #0x18               ; =24
     828:      	str	w8, [x20, #0x24]
     82c:      	mov	x0, x24
     830:      	mov	x1, x20
     834:      	bl	0x834 <_llm_rows.packet_batch.blocks+0x1c4>
     838:      	mov	w30, #0xd01             ; =3329
     83c:      	movk	w30, #0x37d0, lsl #16
     840:      	mov	w7, #0xf27e             ; =62078
     844:      	movk	w7, #0x3493, lsl #16
     848:      	mov	w6, #0x76c7             ; =30407
     84c:      	movk	w6, #0x310f, lsl #16
     850:      	mov	w5, #0xaaab             ; =43691
     854:      	movk	w5, #0x3e2a, lsl #16
     858:      	mov	w4, #0x8889             ; =34953
     85c:      	movk	w4, #0x3c08, lsl #16
     860:      	mov	w3, #0xd01              ; =3329
     864:      	movk	w3, #0x3950, lsl #16
     868:      	mov	w2, #0xef1d             ; =61213
     86c:      	movk	w2, #0x3638, lsl #16
     870:      	mov	w1, #0x322b             ; =12843
     874:      	movk	w1, #0x32d7, lsl #16
     878:      	mov	w0, #0x9231             ; =37425
     87c:      	movk	w0, #0x2f30, lsl #16
     880:      	mov	w17, #0x422a            ; =16938
     884:      	movk	w17, #0x3f4c, lsl #16
     888:      	mov	w16, #0x2713            ; =10003
     88c:      	movk	w16, #0x3d37, lsl #16
     890:      	b	0x778 <_llm_rows.packet_batch.blocks+0x108>
     894:      	lsr	x23, x24, #3
     898:      	cmp	x24, #0x8
     89c:      	b.lo	0x9f0 <_llm_rows.packet_batch.blocks+0x380>
     8a0:      	str	wzr, [x20, #0x24]
     8a4:      	ldr	x0, [sp, #0x68]
     8a8:      	mov	x1, x20
     8ac:      	bl	0x8ac <_llm_rows.packet_batch.blocks+0x23c>
     8b0:      	mov	w30, #0xd01             ; =3329
     8b4:      	movk	w30, #0x37d0, lsl #16
     8b8:      	mov	w7, #0xf27e             ; =62078
     8bc:      	movk	w7, #0x3493, lsl #16
     8c0:      	mov	w6, #0x76c7             ; =30407
     8c4:      	movk	w6, #0x310f, lsl #16
     8c8:      	mov	w5, #0xaaab             ; =43691
     8cc:      	movk	w5, #0x3e2a, lsl #16
     8d0:      	mov	w4, #0x8889             ; =34953
     8d4:      	movk	w4, #0x3c08, lsl #16
     8d8:      	mov	w3, #0xd01              ; =3329
     8dc:      	movk	w3, #0x3950, lsl #16
     8e0:      	mov	w2, #0xef1d             ; =61213
     8e4:      	movk	w2, #0x3638, lsl #16
     8e8:      	mov	w1, #0x322b             ; =12843
     8ec:      	movk	w1, #0x32d7, lsl #16
     8f0:      	mov	w0, #0x9231             ; =37425
     8f4:      	movk	w0, #0x2f30, lsl #16
     8f8:      	mov	w17, #0x422a            ; =16938
     8fc:      	movk	w17, #0x3f4c, lsl #16
     900:      	mov	w16, #0x2713            ; =10003
     904:      	movk	w16, #0x3d37, lsl #16
     908:      	cmp	x23, #0x1
     90c:      	b.eq	0x9f0 <_llm_rows.packet_batch.blocks+0x380>
     910:      	mov	w8, #0x8                ; =8
     914:      	str	w8, [x20, #0x24]
     918:      	ldr	x0, [sp, #0x68]
     91c:      	mov	x1, x20
     920:      	bl	0x920 <_llm_rows.packet_batch.blocks+0x2b0>
     924:      	mov	w30, #0xd01             ; =3329
     928:      	movk	w30, #0x37d0, lsl #16
     92c:      	mov	w7, #0xf27e             ; =62078
     930:      	movk	w7, #0x3493, lsl #16
     934:      	mov	w6, #0x76c7             ; =30407
     938:      	movk	w6, #0x310f, lsl #16
     93c:      	mov	w5, #0xaaab             ; =43691
     940:      	movk	w5, #0x3e2a, lsl #16
     944:      	mov	w4, #0x8889             ; =34953
     948:      	movk	w4, #0x3c08, lsl #16
     94c:      	mov	w3, #0xd01              ; =3329
     950:      	movk	w3, #0x3950, lsl #16
     954:      	mov	w2, #0xef1d             ; =61213
     958:      	movk	w2, #0x3638, lsl #16
     95c:      	mov	w1, #0x322b             ; =12843
     960:      	movk	w1, #0x32d7, lsl #16
     964:      	mov	w0, #0x9231             ; =37425
     968:      	movk	w0, #0x2f30, lsl #16
     96c:      	mov	w17, #0x422a            ; =16938
     970:      	movk	w17, #0x3f4c, lsl #16
     974:      	mov	w16, #0x2713            ; =10003
     978:      	movk	w16, #0x3d37, lsl #16
     97c:      	cmp	x23, #0x2
     980:      	b.eq	0x9f0 <_llm_rows.packet_batch.blocks+0x380>
     984:      	mov	w8, #0x10               ; =16
     988:      	str	w8, [x20, #0x24]
     98c:      	ldr	x0, [sp, #0x68]
     990:      	mov	x1, x20
     994:      	bl	0x994 <_llm_rows.packet_batch.blocks+0x324>
     998:      	mov	w30, #0xd01             ; =3329
     99c:      	movk	w30, #0x37d0, lsl #16
     9a0:      	mov	w7, #0xf27e             ; =62078
     9a4:      	movk	w7, #0x3493, lsl #16
     9a8:      	mov	w6, #0x76c7             ; =30407
     9ac:      	movk	w6, #0x310f, lsl #16
     9b0:      	mov	w5, #0xaaab             ; =43691
     9b4:      	movk	w5, #0x3e2a, lsl #16
     9b8:      	mov	w4, #0x8889             ; =34953
     9bc:      	movk	w4, #0x3c08, lsl #16
     9c0:      	mov	w3, #0xd01              ; =3329
     9c4:      	movk	w3, #0x3950, lsl #16
     9c8:      	mov	w2, #0xef1d             ; =61213
     9cc:      	movk	w2, #0x3638, lsl #16
     9d0:      	mov	w1, #0x322b             ; =12843
     9d4:      	movk	w1, #0x32d7, lsl #16
     9d8:      	mov	w0, #0x9231             ; =37425
     9dc:      	movk	w0, #0x2f30, lsl #16
     9e0:      	mov	w17, #0x422a            ; =16938
     9e4:      	movk	w17, #0x3f4c, lsl #16
     9e8:      	mov	w16, #0x2713            ; =10003
     9ec:      	movk	w16, #0x3d37, lsl #16
     9f0:      	and	w8, w24, #0x7
     9f4:      	mov	w24, #0xb61             ; =2913
     9f8:      	movk	w24, #0x3ab6, lsl #16
     9fc:      	cbz	w8, 0x76c <_llm_rows.packet_batch.blocks+0xfc>
     a00:      	dup.4s	v0, w8
     a04:      	ldp	q2, q1, [sp, #0x40]
     a08:      	cmhi.4s	v16, v0, v2
     a0c:      	cmhi.4s	v5, v0, v1
     a10:      	uzp1.8h	v2, v5, v16
     a14:      	umaxv.8h	h0, v2
     a18:      	fmov	w8, s0
     a1c:      	tbz	w8, #0x0, 0x76c <_llm_rows.packet_batch.blocks+0xfc>
     a20:      	mov	x12, #0x0               ; =0
     a24:      	ldr	x8, [x20, #0x88]
     a28:      	mov	w9, #0x20               ; =32
     a2c:      	movk	w9, #0x2, lsl #16
     a30:      	add	x9, x8, x9
     a34:      	ldr	x14, [sp, #0x68]
     a38:      	ldr	x13, [x14]
     a3c:      	ldr	x11, [x14, #0x10]
     a40:      	lsl	w10, w23, #3
     a44:      	orr	w10, w10, w26, lsl #5
     a48:      	dup.4s	v0, w10
     a4c:      	ldr	x10, [x14, #0x30]
     a50:      	ldp	q1, q4, [sp, #0x40]
     a54:      	orr.16b	v3, v0, v4
     a58:      	orr.16b	v0, v0, v1
     a5c:      	and.16b	v0, v16, v0
     a60:      	and.16b	v3, v5, v3
     a64:      	ldr	q1, [sp, #0x20]
     a68:      	umull2.2d	v17, v0, v1
     a6c:      	umull2.2d	v27, v3, v1
     a70:      	umull.2d	v18, v0, v1
     a74:      	umull.2d	v1, v3, v1
     a78:      	ldr	q0, [sp, #0x10]
     a7c:      	and.16b	v0, v2, v0
     a80:      	addv.8h	h0, v0
     a84:      	dup.2d	v7, x13
     a88:      	str	q0, [sp, #0x140]
     a8c:      	fmov	w13, s0
     a90:      	b	0xab4 <_llm_rows.packet_batch.blocks+0x444>
     a94:      	add	x14, x8, x12, lsl #5
     a98:      	ldp	q0, q4, [x14]
     a9c:      	bif.16b	v3, v4, v16
     aa0:      	bit.16b	v0, v2, v5
     aa4:      	stp	q0, q3, [x14]
     aa8:      	add	x12, x12, #0x1
     aac:      	cmp	x12, x27
     ab0:      	b.eq	0xba0 <_llm_rows.packet_batch.blocks+0x530>
     ab4:      	dup.2d	v6, x12
     ab8:      	add.2d	v0, v6, v1
     abc:      	shl.2d	v0, v0, #0x2
     ac0:      	add.2d	v4, v7, v0
     ac4:      	movi.2d	v2, #0000000000000000
     ac8:      	movi.2d	v3, #0000000000000000
     acc:      	tbnz	w13, #0x0, 0xb18 <_llm_rows.packet_batch.blocks+0x4a8>
     ad0:      	and	w14, w13, #0xff
     ad4:      	tbnz	w14, #0x1, 0xb28 <_llm_rows.packet_batch.blocks+0x4b8>
     ad8:      	add.2d	v0, v6, v27
     adc:      	shl.2d	v0, v0, #0x2
     ae0:      	add.2d	v4, v7, v0
     ae4:      	tbnz	w14, #0x2, 0xb40 <_llm_rows.packet_batch.blocks+0x4d0>
     ae8:      	tbnz	w14, #0x3, 0xb4c <_llm_rows.packet_batch.blocks+0x4dc>
     aec:      	add.2d	v0, v6, v18
     af0:      	shl.2d	v0, v0, #0x2
     af4:      	add.2d	v4, v7, v0
     af8:      	tbnz	w14, #0x4, 0xb64 <_llm_rows.packet_batch.blocks+0x4f4>
     afc:      	tbnz	w14, #0x5, 0xb70 <_llm_rows.packet_batch.blocks+0x500>
     b00:      	add.2d	v0, v6, v17
     b04:      	shl.2d	v0, v0, #0x2
     b08:      	add.2d	v4, v7, v0
     b0c:      	tbnz	w14, #0x6, 0xb88 <_llm_rows.packet_batch.blocks+0x518>
     b10:      	tbz	w14, #0x7, 0xa94 <_llm_rows.packet_batch.blocks+0x424>
     b14:      	b	0xb94 <_llm_rows.packet_batch.blocks+0x524>
     b18:      	fmov	x14, d4
     b1c:      	ldr	s2, [x14]
     b20:      	and	w14, w13, #0xff
     b24:      	tbz	w14, #0x1, 0xad8 <_llm_rows.packet_batch.blocks+0x468>
     b28:      	mov.d	x15, v4[1]
     b2c:      	ld1.s	{ v2 }[1], [x15]
     b30:      	add.2d	v0, v6, v27
     b34:      	shl.2d	v0, v0, #0x2
     b38:      	add.2d	v4, v7, v0
     b3c:      	tbz	w14, #0x2, 0xae8 <_llm_rows.packet_batch.blocks+0x478>
     b40:      	fmov	x15, d4
     b44:      	ld1.s	{ v2 }[2], [x15]
     b48:      	tbz	w14, #0x3, 0xaec <_llm_rows.packet_batch.blocks+0x47c>
     b4c:      	mov.d	x15, v4[1]
     b50:      	ld1.s	{ v2 }[3], [x15]
     b54:      	add.2d	v0, v6, v18
     b58:      	shl.2d	v0, v0, #0x2
     b5c:      	add.2d	v4, v7, v0
     b60:      	tbz	w14, #0x4, 0xafc <_llm_rows.packet_batch.blocks+0x48c>
     b64:      	fmov	x15, d4
     b68:      	ld1.s	{ v3 }[0], [x15]
     b6c:      	tbz	w14, #0x5, 0xb00 <_llm_rows.packet_batch.blocks+0x490>
     b70:      	mov.d	x15, v4[1]
     b74:      	ld1.s	{ v3 }[1], [x15]
     b78:      	add.2d	v0, v6, v17
     b7c:      	shl.2d	v0, v0, #0x2
     b80:      	add.2d	v4, v7, v0
     b84:      	tbz	w14, #0x6, 0xb10 <_llm_rows.packet_batch.blocks+0x4a0>
     b88:      	fmov	x15, d4
     b8c:      	ld1.s	{ v3 }[2], [x15]
     b90:      	tbz	w14, #0x7, 0xa94 <_llm_rows.packet_batch.blocks+0x424>
     b94:      	mov.d	x14, v4[1]
     b98:      	ld1.s	{ v3 }[3], [x14]
     b9c:      	b	0xa94 <_llm_rows.packet_batch.blocks+0x424>
     ba0:      	mov	x12, #0x0               ; =0
     ba4:      	b	0xbc8 <_llm_rows.packet_batch.blocks+0x558>
     ba8:      	add	x13, x9, x12, lsl #5
     bac:      	ldp	q0, q4, [x13]
     bb0:      	bif.16b	v3, v4, v16
     bb4:      	bit.16b	v0, v2, v5
     bb8:      	stp	q0, q3, [x13]
     bbc:      	add	x12, x12, #0x1
     bc0:      	cmp	x12, x27
     bc4:      	b.eq	0xcc0 <_llm_rows.packet_batch.blocks+0x650>
     bc8:      	ldr	q0, [sp, #0x140]
     bcc:      	fmov	w13, s0
     bd0:      	dup.2d	v6, x12
     bd4:      	add.2d	v0, v6, v1
     bd8:      	shl.2d	v0, v0, #0x2
     bdc:      	dup.2d	v7, x11
     be0:      	add.2d	v4, v7, v0
     be4:      	movi.2d	v2, #0000000000000000
     be8:      	movi.2d	v3, #0000000000000000
     bec:      	tbnz	w13, #0x0, 0xc38 <_llm_rows.packet_batch.blocks+0x5c8>
     bf0:      	and	w13, w13, #0xff
     bf4:      	tbnz	w13, #0x1, 0xc48 <_llm_rows.packet_batch.blocks+0x5d8>
     bf8:      	add.2d	v0, v6, v27
     bfc:      	shl.2d	v0, v0, #0x2
     c00:      	add.2d	v4, v7, v0
     c04:      	tbnz	w13, #0x2, 0xc60 <_llm_rows.packet_batch.blocks+0x5f0>
     c08:      	tbnz	w13, #0x3, 0xc6c <_llm_rows.packet_batch.blocks+0x5fc>
     c0c:      	add.2d	v0, v6, v18
     c10:      	shl.2d	v0, v0, #0x2
     c14:      	add.2d	v4, v7, v0
     c18:      	tbnz	w13, #0x4, 0xc84 <_llm_rows.packet_batch.blocks+0x614>
     c1c:      	tbnz	w13, #0x5, 0xc90 <_llm_rows.packet_batch.blocks+0x620>
     c20:      	add.2d	v0, v6, v17
     c24:      	shl.2d	v0, v0, #0x2
     c28:      	add.2d	v4, v7, v0
     c2c:      	tbnz	w13, #0x6, 0xca8 <_llm_rows.packet_batch.blocks+0x638>
     c30:      	tbz	w13, #0x7, 0xba8 <_llm_rows.packet_batch.blocks+0x538>
     c34:      	b	0xcb4 <_llm_rows.packet_batch.blocks+0x644>
     c38:      	fmov	x14, d4
     c3c:      	ldr	s2, [x14]
     c40:      	and	w13, w13, #0xff
     c44:      	tbz	w13, #0x1, 0xbf8 <_llm_rows.packet_batch.blocks+0x588>
     c48:      	mov.d	x14, v4[1]
     c4c:      	ld1.s	{ v2 }[1], [x14]
     c50:      	add.2d	v0, v6, v27
     c54:      	shl.2d	v0, v0, #0x2
     c58:      	add.2d	v4, v7, v0
     c5c:      	tbz	w13, #0x2, 0xc08 <_llm_rows.packet_batch.blocks+0x598>
     c60:      	fmov	x14, d4
     c64:      	ld1.s	{ v2 }[2], [x14]
     c68:      	tbz	w13, #0x3, 0xc0c <_llm_rows.packet_batch.blocks+0x59c>
     c6c:      	mov.d	x14, v4[1]
     c70:      	ld1.s	{ v2 }[3], [x14]
     c74:      	add.2d	v0, v6, v18
     c78:      	shl.2d	v0, v0, #0x2
     c7c:      	add.2d	v4, v7, v0
     c80:      	tbz	w13, #0x4, 0xc1c <_llm_rows.packet_batch.blocks+0x5ac>
     c84:      	fmov	x14, d4
     c88:      	ld1.s	{ v3 }[0], [x14]
     c8c:      	tbz	w13, #0x5, 0xc20 <_llm_rows.packet_batch.blocks+0x5b0>
     c90:      	mov.d	x14, v4[1]
     c94:      	ld1.s	{ v3 }[1], [x14]
     c98:      	add.2d	v0, v6, v17
     c9c:      	shl.2d	v0, v0, #0x2
     ca0:      	add.2d	v4, v7, v0
     ca4:      	tbz	w13, #0x6, 0xc30 <_llm_rows.packet_batch.blocks+0x5c0>
     ca8:      	fmov	x14, d4
     cac:      	ld1.s	{ v3 }[2], [x14]
     cb0:      	tbz	w13, #0x7, 0xba8 <_llm_rows.packet_batch.blocks+0x538>
     cb4:      	mov.d	x13, v4[1]
     cb8:      	ld1.s	{ v3 }[3], [x13]
     cbc:      	b	0xba8 <_llm_rows.packet_batch.blocks+0x538>
     cc0:      	stp	q1, q18, [sp, #0x70]
     cc4:      	mov	x11, #0x0               ; =0
     cc8:      	stp	q5, q16, [sp, #0xb0]
     ccc:      	stp	q27, q17, [sp, #0x90]
     cd0:      	b	0xce0 <_llm_rows.packet_batch.blocks+0x670>
     cd4:      	add	x11, x11, #0x1
     cd8:      	cmp	x11, x27
     cdc:      	b.eq	0x76c <_llm_rows.packet_batch.blocks+0xfc>
     ce0:      	lsl	x12, x11, #5
     ce4:      	add	x13, x8, x12
     ce8:      	ldr	q0, [x13]
     cec:      	and.16b	v3, v5, v0
     cf0:      	dup.4s	v0, w16
     cf4:      	str	q0, [sp, #0x110]
     cf8:      	fmul.4s	v0, v3, v0
     cfc:      	fmul.4s	v0, v3, v0
     d00:      	fmul.4s	v0, v3, v0
     d04:      	fadd.4s	v0, v3, v0
     d08:      	dup.4s	v1, w17
     d0c:      	str	q1, [sp, #0x100]
     d10:      	fmul.4s	v0, v0, v1
     d14:      	and.16b	v9, v5, v0
     d18:      	fabs.4s	v22, v9
     d1c:      	fmov.4s	v7, #1.00000000
     d20:      	dup.4s	v1, w0
     d24:      	dup.4s	v20, w1
     d28:      	fmul.4s	v0, v9, v9
     d2c:      	mov.16b	v2, v20
     d30:      	str	q1, [sp, #0xf0]
     d34:      	fmla.4s	v2, v0, v1
     d38:      	dup.4s	v23, w2
     d3c:      	mov.16b	v4, v23
     d40:      	fmla.4s	v4, v0, v2
     d44:      	dup.4s	v24, w3
     d48:      	mov.16b	v2, v24
     d4c:      	dup.4s	v25, w4
     d50:      	fmla.4s	v2, v0, v4
     d54:      	mov.16b	v4, v25
     d58:      	fmla.4s	v4, v0, v2
     d5c:      	dup.4s	v16, w5
     d60:      	mov.16b	v2, v16
     d64:      	fmla.4s	v2, v0, v4
     d68:      	mov.16b	v4, v7
     d6c:      	fmla.4s	v4, v0, v2
     d70:      	fmul.4s	v2, v22, v4
     d74:      	dup.4s	v1, w6
     d78:      	dup.4s	v26, w7
     d7c:      	mov.16b	v4, v26
     d80:      	str	q1, [sp, #0xe0]
     d84:      	fmla.4s	v4, v0, v1
     d88:      	dup.4s	v28, w30
     d8c:      	mov.16b	v27, v5
     d90:      	mov.16b	v5, v28
     d94:      	fmla.4s	v5, v0, v4
     d98:      	dup.4s	v29, w24
     d9c:      	mov.16b	v4, v29
     da0:      	fmla.4s	v4, v0, v5
     da4:      	mov	w14, #0xaaab            ; =43691
     da8:      	movk	w14, #0x3d2a, lsl #16
     dac:      	dup.4s	v30, w14
     db0:      	mov.16b	v5, v30
     db4:      	fmla.4s	v5, v0, v4
     db8:      	movi.4s	v4, #0x3f, lsl #24
     dbc:      	fmla.4s	v4, v0, v5
     dc0:      	mov.16b	v5, v7
     dc4:      	fmla.4s	v5, v0, v4
     dc8:      	fdiv.4s	v0, v2, v5
     dcc:      	fmov.4s	v31, #9.00000000
     dd0:      	fcmge.4s	v4, v31, v22
     dd4:      	and.16b	v2, v4, v22
     dd8:      	mov	w14, #-0x3d300000       ; =-1026555904
     ddc:      	dup.4s	v8, w14
     de0:      	fcmge.4s	v5, v2, v8
     de4:      	mov	w14, #0x42c80000        ; =1120403456
     de8:      	dup.4s	v17, w14
     dec:      	fcmge.4s	v6, v17, v2
     df0:      	and.16b	v5, v5, v6
     df4:      	and.16b	v5, v5, v2
     df8:      	mov	w14, #0xaa3b            ; =43579
     dfc:      	movk	w14, #0x3fb8, lsl #16
     e00:      	dup.4s	v10, w14
     e04:      	fmul.4s	v6, v5, v10
     e08:      	movi.4s	v1, #0x4b, lsl #24
     e0c:      	fadd.4s	v6, v6, v1
     e10:      	movi.4s	v1, #0xcb, lsl #24
     e14:      	fadd.4s	v6, v6, v1
     e18:      	fcvtzs.4s	v1, v6
     e1c:      	scvtf.4s	v6, v1
     e20:      	mov	w14, #0x7200            ; =29184
     e24:      	movk	w14, #0xbf31, lsl #16
     e28:      	dup.4s	v11, w14
     e2c:      	fmul.4s	v12, v6, v11
     e30:      	fadd.4s	v5, v5, v12
     e34:      	mov	w14, #0xbe8e            ; =48782
     e38:      	movk	w14, #0xb5bf, lsl #16
     e3c:      	dup.4s	v12, w14
     e40:      	fmul.4s	v6, v6, v12
     e44:      	mov	w14, #0x2bda            ; =11226
     e48:      	movk	w14, #0x3950, lsl #16
     e4c:      	dup.4s	v13, w14
     e50:      	fadd.4s	v5, v5, v6
     e54:      	fmul.4s	v6, v5, v13
     e58:      	mov	w14, #0x96c9            ; =38601
     e5c:      	movk	w14, #0x3ab6, lsl #16
     e60:      	dup.4s	v14, w14
     e64:      	fadd.4s	v6, v6, v14
     e68:      	fmul.4s	v6, v5, v6
     e6c:      	mov	w14, #0x88a6            ; =34982
     e70:      	movk	w14, #0x3c08, lsl #16
     e74:      	dup.4s	v15, w14
     e78:      	fadd.4s	v6, v6, v15
     e7c:      	fmul.4s	v18, v5, v6
     e80:      	dup.4s	v6, w28
     e84:      	fadd.4s	v18, v18, v6
     e88:      	fmul.4s	v18, v5, v18
     e8c:      	fadd.4s	v18, v18, v16
     e90:      	fmul.4s	v18, v5, v18
     e94:      	movi.4s	v21, #0x3f, lsl #24
     e98:      	fadd.4s	v18, v18, v21
     e9c:      	fmul.4s	v19, v5, v5
     ea0:      	fmul.4s	v18, v19, v18
     ea4:      	fadd.4s	v5, v5, v18
     ea8:      	fadd.4s	v5, v5, v7
     eac:      	movi.2d	v18, #0xffffffffffffffff
     eb0:      	add.4s	v1, v1, v18
     eb4:      	sshr.4s	v18, v1, #0x1
     eb8:      	shl.4s	v19, v18, #0x17
     ebc:      	add.4s	v19, v19, v7
     ec0:      	fmul.4s	v5, v5, v19
     ec4:      	sub.4s	v1, v1, v18
     ec8:      	shl.4s	v1, v1, #0x17
     ecc:      	add.4s	v1, v1, v7
     ed0:      	fmul.4s	v1, v5, v1
     ed4:      	fcmgt.4s	v2, v2, v17
     ed8:      	ldr	q5, [sp, #0x130]
     edc:      	bit.16b	v1, v5, v2
     ee0:      	fmov.4s	v2, #0.25000000
     ee4:      	fdiv.4s	v5, v2, v1
     ee8:      	fsub.4s	v18, v1, v5
     eec:      	fadd.4s	v1, v1, v5
     ef0:      	fdiv.4s	v1, v18, v1
     ef4:      	bif.16b	v1, v7, v4
     ef8:      	ldr	q4, [x13, #0x10]
     efc:      	ldr	q5, [sp, #0x140]
     f00:      	fmov	w13, s5
     f04:      	fcmge.4s	v5, v7, v22
     f08:      	bif.16b	v0, v1, v5
     f0c:      	dup.2d	v22, x11
     f10:      	ldr	q1, [sp, #0x70]
     f14:      	add.2d	v1, v22, v1
     f18:      	fmul.4s	v3, v3, v21
     f1c:      	mvni.4s	v5, #0x80, lsl #24
     f20:      	bif.16b	v0, v9, v5
     f24:      	fcmeq.4s	v5, v9, v9
     f28:      	fadd.4s	v0, v0, v7
     f2c:      	ldr	q18, [sp, #0x120]
     f30:      	bif.16b	v0, v18, v5
     f34:      	fmul.4s	v0, v3, v0
     f38:      	add	x12, x9, x12
     f3c:      	ldp	q5, q3, [x12]
     f40:      	str	q3, [sp, #0xd0]
     f44:      	and.16b	v5, v27, v5
     f48:      	fadd.4s	v5, v5, v0
     f4c:      	shl.2d	v0, v1, #0x2
     f50:      	dup.2d	v9, x10
     f54:      	add.2d	v0, v9, v0
     f58:      	tbnz	w13, #0x0, 0x1130 <_llm_rows.packet_batch.blocks+0xac0>
     f5c:      	and	w12, w13, #0xff
     f60:      	ldr	q27, [sp, #0x90]
     f64:      	tbnz	w12, #0x1, 0x1144 <_llm_rows.packet_batch.blocks+0xad4>
     f68:      	add.2d	v0, v22, v27
     f6c:      	shl.2d	v0, v0, #0x2
     f70:      	add.2d	v0, v9, v0
     f74:      	tbnz	w12, #0x2, 0x115c <_llm_rows.packet_batch.blocks+0xaec>
     f78:      	tbz	w12, #0x3, 0xf84 <_llm_rows.packet_batch.blocks+0x914>
     f7c:      	mov.d	x13, v0[1]
     f80:      	st1.s	{ v5 }[3], [x13]
     f84:      	ldr	q3, [sp, #0xc0]
     f88:      	and.16b	v4, v3, v4
     f8c:      	ldp	q1, q0, [sp, #0x100]
     f90:      	fmul.4s	v0, v4, v0
     f94:      	fmul.4s	v0, v4, v0
     f98:      	fmul.4s	v0, v4, v0
     f9c:      	fadd.4s	v0, v4, v0
     fa0:      	fmul.4s	v0, v0, v1
     fa4:      	and.16b	v18, v3, v0
     fa8:      	fmul.4s	v0, v18, v18
     fac:      	ldr	q1, [sp, #0xf0]
     fb0:      	fmla.4s	v20, v0, v1
     fb4:      	fmla.4s	v23, v0, v20
     fb8:      	fmla.4s	v24, v0, v23
     fbc:      	fmla.4s	v25, v0, v24
     fc0:      	mov.16b	v1, v16
     fc4:      	fmla.4s	v1, v0, v25
     fc8:      	mov.16b	v5, v7
     fcc:      	fmla.4s	v5, v0, v1
     fd0:      	ldr	q1, [sp, #0xe0]
     fd4:      	fmla.4s	v26, v0, v1
     fd8:      	fmla.4s	v28, v0, v26
     fdc:      	fmla.4s	v29, v0, v28
     fe0:      	fmla.4s	v30, v0, v29
     fe4:      	movi.4s	v1, #0x3f, lsl #24
     fe8:      	fmla.4s	v1, v0, v30
     fec:      	mov.16b	v19, v7
     ff0:      	fmla.4s	v19, v0, v1
     ff4:      	fabs.4s	v0, v18
     ff8:      	fmul.4s	v1, v0, v5
     ffc:      	fdiv.4s	v1, v1, v19
    1000:      	fcmge.4s	v5, v31, v0
    1004:      	and.16b	v19, v5, v0
    1008:      	fcmge.4s	v20, v19, v8
    100c:      	fcmge.4s	v21, v17, v19
    1010:      	and.16b	v20, v20, v21
    1014:      	and.16b	v20, v20, v19
    1018:      	fmul.4s	v21, v20, v10
    101c:      	movi.4s	v23, #0x4b, lsl #24
    1020:      	fadd.4s	v21, v21, v23
    1024:      	movi.4s	v23, #0xcb, lsl #24
    1028:      	fadd.4s	v21, v21, v23
    102c:      	fcvtzs.4s	v21, v21
    1030:      	scvtf.4s	v23, v21
    1034:      	fmul.4s	v24, v23, v11
    1038:      	fadd.4s	v20, v20, v24
    103c:      	fmul.4s	v23, v23, v12
    1040:      	fadd.4s	v20, v20, v23
    1044:      	fmul.4s	v23, v20, v13
    1048:      	fadd.4s	v23, v23, v14
    104c:      	fmul.4s	v23, v20, v23
    1050:      	fadd.4s	v23, v23, v15
    1054:      	fmul.4s	v23, v20, v23
    1058:      	fadd.4s	v6, v23, v6
    105c:      	fmul.4s	v6, v20, v6
    1060:      	fadd.4s	v6, v6, v16
    1064:      	fmul.4s	v6, v20, v6
    1068:      	movi.4s	v23, #0x3f, lsl #24
    106c:      	fadd.4s	v6, v6, v23
    1070:      	fmul.4s	v16, v20, v20
    1074:      	fmul.4s	v6, v16, v6
    1078:      	fadd.4s	v6, v20, v6
    107c:      	fadd.4s	v6, v6, v7
    1080:      	movi.2d	v16, #0xffffffffffffffff
    1084:      	add.4s	v16, v21, v16
    1088:      	sshr.4s	v20, v16, #0x1
    108c:      	shl.4s	v21, v20, #0x17
    1090:      	add.4s	v21, v21, v7
    1094:      	fmul.4s	v6, v6, v21
    1098:      	sub.4s	v16, v16, v20
    109c:      	shl.4s	v16, v16, #0x17
    10a0:      	add.4s	v16, v16, v7
    10a4:      	fmul.4s	v6, v6, v16
    10a8:      	fcmgt.4s	v16, v19, v17
    10ac:      	ldr	q17, [sp, #0x130]
    10b0:      	bit.16b	v6, v17, v16
    10b4:      	fdiv.4s	v2, v2, v6
    10b8:      	fsub.4s	v16, v6, v2
    10bc:      	fadd.4s	v2, v6, v2
    10c0:      	fdiv.4s	v2, v16, v2
    10c4:      	bif.16b	v2, v7, v5
    10c8:      	fcmge.4s	v0, v7, v0
    10cc:      	bsl.16b	v0, v1, v2
    10d0:      	mvni.4s	v1, #0x80, lsl #24
    10d4:      	bif.16b	v0, v18, v1
    10d8:      	fadd.4s	v0, v0, v7
    10dc:      	fcmeq.4s	v1, v18, v18
    10e0:      	ldr	q2, [sp, #0x120]
    10e4:      	bif.16b	v0, v2, v1
    10e8:      	fmul.4s	v1, v4, v23
    10ec:      	fmul.4s	v0, v1, v0
    10f0:      	ldr	q1, [sp, #0xd0]
    10f4:      	and.16b	v1, v3, v1
    10f8:      	fadd.4s	v2, v1, v0
    10fc:      	ldr	q0, [sp, #0x80]
    1100:      	add.2d	v0, v22, v0
    1104:      	shl.2d	v0, v0, #0x2
    1108:      	add.2d	v0, v9, v0
    110c:      	tbnz	w12, #0x4, 0x116c <_llm_rows.packet_batch.blocks+0xafc>
    1110:      	ldp	q17, q5, [sp, #0xa0]
    1114:      	tbnz	w12, #0x5, 0x117c <_llm_rows.packet_batch.blocks+0xb0c>
    1118:      	add.2d	v0, v22, v17
    111c:      	shl.2d	v0, v0, #0x2
    1120:      	add.2d	v0, v9, v0
    1124:      	tbnz	w12, #0x6, 0x1194 <_llm_rows.packet_batch.blocks+0xb24>
    1128:      	tbz	w12, #0x7, 0xcd4 <_llm_rows.packet_batch.blocks+0x664>
    112c:      	b	0x11a0 <_llm_rows.packet_batch.blocks+0xb30>
    1130:      	fmov	x12, d0
    1134:      	str	s5, [x12]
    1138:      	and	w12, w13, #0xff
    113c:      	ldr	q27, [sp, #0x90]
    1140:      	tbz	w12, #0x1, 0xf68 <_llm_rows.packet_batch.blocks+0x8f8>
    1144:      	mov.d	x13, v0[1]
    1148:      	st1.s	{ v5 }[1], [x13]
    114c:      	add.2d	v0, v22, v27
    1150:      	shl.2d	v0, v0, #0x2
    1154:      	add.2d	v0, v9, v0
    1158:      	tbz	w12, #0x2, 0xf78 <_llm_rows.packet_batch.blocks+0x908>
    115c:      	fmov	x13, d0
    1160:      	st1.s	{ v5 }[2], [x13]
    1164:      	tbnz	w12, #0x3, 0xf7c <_llm_rows.packet_batch.blocks+0x90c>
    1168:      	b	0xf84 <_llm_rows.packet_batch.blocks+0x914>
    116c:      	fmov	x13, d0
    1170:      	str	s2, [x13]
    1174:      	ldp	q17, q5, [sp, #0xa0]
    1178:      	tbz	w12, #0x5, 0x1118 <_llm_rows.packet_batch.blocks+0xaa8>
    117c:      	mov.d	x13, v0[1]
    1180:      	st1.s	{ v2 }[1], [x13]
    1184:      	add.2d	v0, v22, v17
    1188:      	shl.2d	v0, v0, #0x2
    118c:      	add.2d	v0, v9, v0
    1190:      	tbz	w12, #0x6, 0x1128 <_llm_rows.packet_batch.blocks+0xab8>
    1194:      	fmov	x13, d0
    1198:      	st1.s	{ v2 }[2], [x13]
    119c:      	tbz	w12, #0x7, 0xcd4 <_llm_rows.packet_batch.blocks+0x664>
    11a0:      	mov.d	x12, v0[1]
    11a4:      	st1.s	{ v2 }[3], [x12]
    11a8:      	b	0xcd4 <_llm_rows.packet_batch.blocks+0x664>
    11ac:      	add	sp, sp, #0x160
    11b0:      	ldp	x29, x30, [sp, #0x90]
    11b4:      	ldp	x20, x19, [sp, #0x80]
    11b8:      	ldp	x22, x21, [sp, #0x70]
    11bc:      	ldp	x24, x23, [sp, #0x60]
    11c0:      	ldp	x26, x25, [sp, #0x50]
    11c4:      	ldp	x28, x27, [sp, #0x40]
    11c8:      	ldp	d9, d8, [sp, #0x30]
    11cc:      	ldp	d11, d10, [sp, #0x20]
    11d0:      	ldp	d13, d12, [sp, #0x10]
    11d4:      	ldp	d15, d14, [sp], #0xa0
    11d8:      	ret

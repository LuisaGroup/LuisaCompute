
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/masked_softmax-17x65-l1/object/tile_xir_w8_80756_1788919112242094_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x50]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	sub	sp, sp, #0x2, lsl #12   ; =0x2000
      18:      	sub	sp, sp, #0xb00
      1c:      	mov	x9, #0x0                ; =0
      20:      	ldr	w8, [x1]
      24:      	ldr	w10, [x1, #0x24]
      28:      	add	w10, w10, w8, lsl #5
      2c:      	ldr	x11, [x0]
      30:      	ldr	x8, [x0, #0x30]
      34:      	dup.4s	v0, w10
      38:      	adrp	x10, 0x0 <ltmp0>
      3c:      	ldr	q1, [x10]
      40:      	add.4s	v4, v0, v1
      44:      	adrp	x10, 0x0 <ltmp0>
      48:      	ldr	q1, [x10]
      4c:      	add.4s	v5, v0, v1
      50:      	movi.4s	v1, #0x41
      54:      	umull2.2d	v0, v4, v1
      58:      	umull2.2d	v1, v5, v1
      5c:      	movi.2s	v3, #0x41
      60:      	umull.2d	v2, v4, v3
      64:      	umull.2d	v3, v5, v3
      68:      	dup.2d	v6, x11
      6c:      	add	x10, sp, #0x2, lsl #12  ; =0x2000
      70:      	add	x10, x10, #0x2e0
      74:      	dup.2d	v7, x9
      78:      	add.2d	v16, v7, v0
      7c:      	add.2d	v17, v7, v2
      80:      	add.2d	v18, v7, v1
      84:      	add.2d	v7, v7, v3
      88:      	shl.2d	v7, v7, #0x2
      8c:      	shl.2d	v18, v18, #0x2
      90:      	shl.2d	v17, v17, #0x2
      94:      	shl.2d	v16, v16, #0x2
      98:      	add.2d	v16, v6, v16
      9c:      	add.2d	v17, v6, v17
      a0:      	add.2d	v18, v6, v18
      a4:      	add.2d	v7, v6, v7
      a8:      	mov.d	x11, v7[1]
      ac:      	fmov	x12, d7
      b0:      	mov.d	x13, v18[1]
      b4:      	fmov	x14, d18
      b8:      	mov.d	x15, v17[1]
      bc:      	fmov	x16, d17
      c0:      	mov.d	x17, v16[1]
      c4:      	ldr	s7, [x16]
      c8:      	ld1.s	{ v7 }[1], [x15]
      cc:      	fmov	x15, d16
      d0:      	ld1.s	{ v7 }[2], [x15]
      d4:      	ld1.s	{ v7 }[3], [x17]
      d8:      	ldr	s16, [x12]
      dc:      	ld1.s	{ v16 }[1], [x11]
      e0:      	ld1.s	{ v16 }[2], [x14]
      e4:      	ld1.s	{ v16 }[3], [x13]
      e8:      	add	x11, x10, x9, lsl #5
      ec:      	stp	q16, q7, [x11]
      f0:      	add	x9, x9, #0x1
      f4:      	cmp	x9, #0x41
      f8:      	b.ne	0x74 <ltmp0+0x74>
      fc:      	stp	q3, q2, [sp]
     100:      	stp	q1, q0, [sp, #0x20]
     104:      	mov	x9, #0x0                ; =0
     108:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     10c:      	add	x10, x10, #0x2a0
     110:      	dup.2d	v6, x9
     114:      	add	x11, x10, x9, lsl #6
     118:      	stp	q6, q6, [x11, #0x20]
     11c:      	stp	q6, q6, [x11]
     120:      	add	x9, x9, #0x1
     124:      	cmp	x9, #0x41
     128:      	b.ne	0x110 <ltmp0+0x110>
     12c:      	mov	x9, #0x0                ; =0
     130:      	mov	w10, #0xc0fd            ; =49405
     134:      	movk	w10, #0xfc0f, lsl #16
     138:      	dup.4s	v6, w10
     13c:      	umull2.2d	v7, v5, v6
     140:      	umull.2d	v16, v5, v6
     144:      	uzp2.4s	v7, v16, v7
     148:      	ushr.4s	v7, v7, #0x6
     14c:      	movi.4s	v16, #0x41
     150:      	mls.4s	v5, v7, v16
     154:      	umull2.2d	v7, v4, v6
     158:      	umull.2d	v6, v4, v6
     15c:      	uzp2.4s	v6, v6, v7
     160:      	ushr.4s	v6, v6, #0x6
     164:      	mls.4s	v4, v6, v16
     168:      	ushll2.2d	v16, v4, #0x0
     16c:      	ushll2.2d	v17, v5, #0x0
     170:      	ushll.2d	v18, v4, #0x0
     174:      	ushll.2d	v19, v5, #0x0
     178:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     17c:      	add	x10, x10, #0x98
     180:      	dup.2d	v20, x10
     184:      	adrp	x10, 0x0 <ltmp0>
     188:      	ldr	q4, [x10]
     18c:      	adrp	x10, 0x0 <ltmp0>
     190:      	ldr	q5, [x10]
     194:      	adrp	x10, 0x0 <ltmp0>
     198:      	ldr	q6, [x10]
     19c:      	adrp	x10, 0x0 <ltmp0>
     1a0:      	ldr	q7, [x10]
     1a4:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     1a8:      	add	x10, x10, #0x2a0
     1ac:      	movi.8b	v21, #0x1
     1b0:      	dup.2d	v22, x9
     1b4:      	add	x11, x10, x9, lsl #6
     1b8:      	ldp	q24, q23, [x11, #0x20]
     1bc:      	ldp	q25, q26, [x11]
     1c0:      	add.2d	v22, v22, v20
     1c4:      	add.2d	v27, v22, v5
     1c8:      	add.2d	v28, v22, v4
     1cc:      	cmge.2d	v26, v17, v26
     1d0:      	cmge.2d	v25, v19, v25
     1d4:      	uzp1.4s	v25, v25, v26
     1d8:      	cmge.2d	v24, v18, v24
     1dc:      	cmge.2d	v23, v16, v23
     1e0:      	uzp1.4s	v23, v24, v23
     1e4:      	uzp1.8h	v23, v25, v23
     1e8:      	xtn.8b	v23, v23
     1ec:      	and.8b	v23, v23, v21
     1f0:      	mov.d	x11, v28[1]
     1f4:      	fmov	x12, d28
     1f8:      	str	b23, [x12]
     1fc:      	st1.b	{ v23 }[1], [x11]
     200:      	mov.d	x11, v27[1]
     204:      	fmov	x12, d27
     208:      	st1.b	{ v23 }[2], [x12]
     20c:      	st1.b	{ v23 }[3], [x11]
     210:      	add.2d	v24, v22, v6
     214:      	mov.d	x11, v24[1]
     218:      	fmov	x12, d24
     21c:      	st1.b	{ v23 }[4], [x12]
     220:      	add.2d	v22, v22, v7
     224:      	st1.b	{ v23 }[5], [x11]
     228:      	mov.d	x11, v22[1]
     22c:      	fmov	x12, d22
     230:      	st1.b	{ v23 }[6], [x12]
     234:      	st1.b	{ v23 }[7], [x11]
     238:      	add	x9, x9, #0x1
     23c:      	cmp	x9, #0x41
     240:      	b.ne	0x1b0 <ltmp0+0x1b0>
     244:      	mov	x9, #0x0                ; =0
     248:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     24c:      	add	x10, x10, #0x98
     250:      	dup.2d	v16, x10
     254:      	add	x10, sp, #0x2, lsl #12  ; =0x2000
     258:      	add	x10, x10, #0x2e0
     25c:      	mov	w11, #0xf2ca            ; =62154
     260:      	movk	w11, #0xf149, lsl #16
     264:      	dup.4s	v17, w11
     268:      	add	x11, sp, #0x878
     26c:      	dup.2d	v18, x9
     270:      	add.2d	v18, v18, v16
     274:      	add.2d	v19, v18, v7
     278:      	add.2d	v20, v18, v4
     27c:      	mov.d	x12, v20[1]
     280:      	add.2d	v21, v18, v6
     284:      	add.2d	v18, v18, v5
     288:      	fmov	x13, d20
     28c:      	mov.d	x14, v18[1]
     290:      	mov.d	x15, v21[1]
     294:      	fmov	x16, d18
     298:      	ldr	b18, [x13]
     29c:      	ld1.b	{ v18 }[1], [x12]
     2a0:      	mov.d	x12, v19[1]
     2a4:      	fmov	x13, d21
     2a8:      	ld1.b	{ v18 }[2], [x16]
     2ac:      	ld1.b	{ v18 }[3], [x14]
     2b0:      	fmov	x14, d19
     2b4:      	ld1.b	{ v18 }[4], [x13]
     2b8:      	ld1.b	{ v18 }[5], [x15]
     2bc:      	ld1.b	{ v18 }[6], [x14]
     2c0:      	ld1.b	{ v18 }[7], [x12]
     2c4:      	cmeq.8b	v18, v18, #0
     2c8:      	sshll.8h	v18, v18, #0x0
     2cc:      	sshll2.4s	v19, v18, #0x0
     2d0:      	sshll.4s	v18, v18, #0x0
     2d4:      	lsl	x12, x9, #5
     2d8:      	add	x13, x10, x12
     2dc:      	ldp	q21, q20, [x13]
     2e0:      	bsl.16b	v18, v17, v21
     2e4:      	bsl.16b	v19, v17, v20
     2e8:      	add	x12, x11, x12
     2ec:      	stp	q18, q19, [x12]
     2f0:      	add	x9, x9, #0x1
     2f4:      	cmp	x9, #0x41
     2f8:      	b.ne	0x26c <ltmp0+0x26c>
     2fc:      	add	x9, sp, #0x789
     300:      	ldur	q20, [x9, #0xff]
     304:      	add	x9, sp, #0x779
     308:      	ldur	q22, [x9, #0xff]
     30c:      	add	x9, sp, #0x7a9
     310:      	ldur	q16, [x9, #0xff]
     314:      	add	x9, sp, #0x799
     318:      	ldur	q19, [x9, #0xff]
     31c:      	add	x9, sp, #0x7c9
     320:      	ldur	q18, [x9, #0xff]
     324:      	add	x9, sp, #0x7b9
     328:      	ldur	q17, [x9, #0xff]
     32c:      	add	x9, sp, #0x878
     330:      	add	x9, x9, #0xe0
     334:      	mov	w10, #0x4               ; =4
     338:      	add	x11, sp, #0x7e9
     33c:      	ldur	q21, [x11, #0xff]
     340:      	add	x11, sp, #0x7d9
     344:      	ldur	q23, [x11, #0xff]
     348:      	ldp	q24, q25, [x9, #-0x60]
     34c:      	fmaxnm.4s	v20, v20, v25
     350:      	fmaxnm.4s	v22, v22, v24
     354:      	ldp	q24, q25, [x9, #-0x40]
     358:      	fmaxnm.4s	v16, v16, v25
     35c:      	fmaxnm.4s	v19, v19, v24
     360:      	ldp	q24, q25, [x9, #-0x20]
     364:      	fmaxnm.4s	v18, v18, v25
     368:      	fmaxnm.4s	v17, v17, v24
     36c:      	ldp	q24, q25, [x9], #0x80
     370:      	fmaxnm.4s	v21, v21, v25
     374:      	fmaxnm.4s	v23, v23, v24
     378:      	cmp	x10, #0x3c
     37c:      	add	x10, x10, #0x4
     380:      	b.lo	0x348 <ltmp0+0x348>
     384:      	mov	x9, #0x0                ; =0
     388:      	add	x10, sp, #0xf89
     38c:      	ldur	q24, [x10, #0xff]
     390:      	add	x10, sp, #0xf79
     394:      	ldur	q25, [x10, #0xff]
     398:      	fmaxnm.4s	v22, v22, v25
     39c:      	fmaxnm.4s	v20, v20, v24
     3a0:      	mvni.4s	v9, #0x7f, msl #16
     3a4:      	fmaxnm.4s	v20, v20, v9
     3a8:      	fmaxnm.4s	v22, v22, v9
     3ac:      	fmaxnm.4s	v19, v22, v19
     3b0:      	fmaxnm.4s	v16, v20, v16
     3b4:      	fmaxnm.4s	v18, v16, v18
     3b8:      	fmaxnm.4s	v16, v19, v17
     3bc:      	fmaxnm.4s	v0, v16, v23
     3c0:      	str	q0, [sp, #0x40]
     3c4:      	fmaxnm.4s	v17, v18, v21
     3c8:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     3cc:      	add	x10, x10, #0x98
     3d0:      	dup.2d	v18, x10
     3d4:      	mov	w10, #-0x3d300000       ; =-1026555904
     3d8:      	dup.4s	v19, w10
     3dc:      	mov	w10, #0x42c80000        ; =1120403456
     3e0:      	dup.4s	v20, w10
     3e4:      	mov	w10, #0xaa3b            ; =43579
     3e8:      	movk	w10, #0x3fb8, lsl #16
     3ec:      	dup.4s	v21, w10
     3f0:      	add	x10, sp, #0x878
     3f4:      	movi.4s	v22, #0x4b, lsl #24
     3f8:      	mvni.4s	v23, #0x80, lsl #24
     3fc:      	mov	w11, #0x7200            ; =29184
     400:      	movk	w11, #0xbf31, lsl #16
     404:      	dup.4s	v24, w11
     408:      	mov	w11, #0xbe8e            ; =48782
     40c:      	movk	w11, #0xb5bf, lsl #16
     410:      	dup.4s	v25, w11
     414:      	mov	w11, #0x2bda            ; =11226
     418:      	movk	w11, #0x3950, lsl #16
     41c:      	dup.4s	v26, w11
     420:      	mov	w11, #0x96c9            ; =38601
     424:      	movk	w11, #0x3ab6, lsl #16
     428:      	dup.4s	v27, w11
     42c:      	mov	w11, #0x88a6            ; =34982
     430:      	movk	w11, #0x3c08, lsl #16
     434:      	dup.4s	v28, w11
     438:      	mov	w11, #0xaa7a            ; =43642
     43c:      	movk	w11, #0x3d2a, lsl #16
     440:      	dup.4s	v29, w11
     444:      	mov	w11, #0xaaab            ; =43691
     448:      	movk	w11, #0x3e2a, lsl #16
     44c:      	dup.4s	v30, w11
     450:      	movi.4s	v31, #0x3f, lsl #24
     454:      	fmov.4s	v8, #1.00000000
     458:      	fneg.4s	v9, v9
     45c:      	mvni.4s	v10, #0x3f, msl #16
     460:      	fneg.4s	v10, v10
     464:      	add	x11, sp, #0x58
     468:      	dup.2d	v11, x9
     46c:      	add.2d	v13, v11, v18
     470:      	add.2d	v14, v13, v5
     474:      	add.2d	v11, v13, v4
     478:      	mov.d	x12, v11[1]
     47c:      	lsl	x13, x9, #5
     480:      	fmov	x14, d11
     484:      	add	x15, x10, x13
     488:      	ldp	q11, q12, [x15]
     48c:      	fsub.4s	v12, v12, v17
     490:      	mov.d	x15, v14[1]
     494:      	ldr	q0, [sp, #0x40]
     498:      	fsub.4s	v11, v11, v0
     49c:      	fcmge.4s	v15, v11, v19
     4a0:      	fcmge.4s	v0, v12, v19
     4a4:      	fcmge.4s	v1, v20, v11
     4a8:      	fcmge.4s	v2, v20, v12
     4ac:      	and.16b	v0, v0, v2
     4b0:      	and.16b	v1, v15, v1
     4b4:      	and.16b	v1, v1, v11
     4b8:      	and.16b	v0, v0, v12
     4bc:      	fmul.4s	v2, v0, v21
     4c0:      	fmul.4s	v15, v1, v21
     4c4:      	mov.16b	v3, v23
     4c8:      	bsl.16b	v3, v22, v15
     4cc:      	mov.16b	v16, v23
     4d0:      	bsl.16b	v16, v22, v2
     4d4:      	fadd.4s	v2, v2, v16
     4d8:      	fadd.4s	v15, v15, v3
     4dc:      	fsub.4s	v3, v15, v3
     4e0:      	fsub.4s	v2, v2, v16
     4e4:      	fmov	x1, d14
     4e8:      	fcvtzs.4s	v2, v2
     4ec:      	fcvtzs.4s	v3, v3
     4f0:      	scvtf.4s	v16, v3
     4f4:      	scvtf.4s	v14, v2
     4f8:      	fmul.4s	v15, v16, v24
     4fc:      	fadd.4s	v1, v1, v15
     500:      	fmul.4s	v15, v14, v24
     504:      	fadd.4s	v0, v0, v15
     508:      	add.2d	v15, v13, v6
     50c:      	mov.d	x17, v15[1]
     510:      	fmov	x0, d15
     514:      	add.2d	v13, v13, v7
     518:      	mov.d	x16, v13[1]
     51c:      	fmul.4s	v16, v16, v25
     520:      	fmul.4s	v14, v14, v25
     524:      	fadd.4s	v0, v0, v14
     528:      	fadd.4s	v1, v1, v16
     52c:      	fmul.4s	v16, v1, v26
     530:      	fmul.4s	v14, v0, v26
     534:      	fadd.4s	v14, v14, v27
     538:      	fadd.4s	v16, v16, v27
     53c:      	fmul.4s	v16, v1, v16
     540:      	fmul.4s	v14, v0, v14
     544:      	fadd.4s	v14, v14, v28
     548:      	fadd.4s	v16, v16, v28
     54c:      	fmul.4s	v16, v1, v16
     550:      	fmul.4s	v14, v0, v14
     554:      	fadd.4s	v14, v14, v29
     558:      	fadd.4s	v16, v16, v29
     55c:      	fmul.4s	v16, v1, v16
     560:      	fmul.4s	v14, v0, v14
     564:      	fadd.4s	v14, v14, v30
     568:      	fadd.4s	v16, v16, v30
     56c:      	fmov	x2, d13
     570:      	fmul.4s	v16, v1, v16
     574:      	fmul.4s	v13, v0, v14
     578:      	fadd.4s	v13, v13, v31
     57c:      	fadd.4s	v16, v16, v31
     580:      	fmul.4s	v14, v1, v1
     584:      	fmul.4s	v16, v14, v16
     588:      	fmul.4s	v14, v0, v0
     58c:      	fmul.4s	v13, v14, v13
     590:      	fadd.4s	v0, v0, v13
     594:      	fadd.4s	v1, v1, v16
     598:      	sshr.4s	v16, v3, #0x1
     59c:      	fadd.4s	v0, v0, v8
     5a0:      	sshr.4s	v13, v2, #0x1
     5a4:      	shl.4s	v14, v13, #0x17
     5a8:      	add.4s	v14, v14, v8
     5ac:      	fmul.4s	v0, v0, v14
     5b0:      	shl.4s	v14, v16, #0x17
     5b4:      	fadd.4s	v1, v1, v8
     5b8:      	add.4s	v14, v14, v8
     5bc:      	fmul.4s	v1, v1, v14
     5c0:      	sub.4s	v2, v2, v13
     5c4:      	sub.4s	v3, v3, v16
     5c8:      	shl.4s	v3, v3, #0x17
     5cc:      	add.4s	v3, v3, v8
     5d0:      	fmul.4s	v1, v1, v3
     5d4:      	ldr	b3, [x14]
     5d8:      	ld1.b	{ v3 }[1], [x12]
     5dc:      	ld1.b	{ v3 }[2], [x1]
     5e0:      	ld1.b	{ v3 }[3], [x15]
     5e4:      	shl.4s	v2, v2, #0x17
     5e8:      	add.4s	v2, v2, v8
     5ec:      	fmul.4s	v0, v0, v2
     5f0:      	fcmgt.4s	v2, v19, v12
     5f4:      	bic.16b	v0, v0, v2
     5f8:      	fcmgt.4s	v2, v19, v11
     5fc:      	bic.16b	v1, v1, v2
     600:      	fcmgt.4s	v2, v11, v20
     604:      	bit.16b	v1, v9, v2
     608:      	fcmgt.4s	v2, v12, v20
     60c:      	bit.16b	v0, v9, v2
     610:      	ld1.b	{ v3 }[4], [x0]
     614:      	ld1.b	{ v3 }[5], [x17]
     618:      	fcmeq.4s	v2, v12, v12
     61c:      	bif.16b	v0, v10, v2
     620:      	ld1.b	{ v3 }[6], [x2]
     624:      	ld1.b	{ v3 }[7], [x16]
     628:      	cmeq.8b	v2, v3, #0
     62c:      	sshll.8h	v2, v2, #0x0
     630:      	fcmeq.4s	v3, v11, v11
     634:      	bif.16b	v1, v10, v3
     638:      	sshll.4s	v3, v2, #0x0
     63c:      	bic.16b	v1, v1, v3
     640:      	sshll2.4s	v2, v2, #0x0
     644:      	bic.16b	v0, v0, v2
     648:      	add	x12, x11, x13
     64c:      	stp	q1, q0, [x12]
     650:      	add	x9, x9, #0x1
     654:      	cmp	x9, #0x41
     658:      	b.ne	0x468 <ltmp0+0x468>
     65c:      	ldur	q16, [sp, #0x68]
     660:      	ldur	q18, [sp, #0x58]
     664:      	ldur	q4, [sp, #0x88]
     668:      	ldur	q7, [sp, #0x78]
     66c:      	ldur	q6, [sp, #0xa8]
     670:      	ldur	q5, [sp, #0x98]
     674:      	add	x9, sp, #0x58
     678:      	add	x9, x9, #0xe0
     67c:      	mov	w10, #0x4               ; =4
     680:      	ldur	q17, [sp, #0xc8]
     684:      	ldur	q19, [sp, #0xb8]
     688:      	ldp	q0, q1, [x9, #-0x60]
     68c:      	fadd.4s	v16, v16, v1
     690:      	fadd.4s	v18, v18, v0
     694:      	ldp	q0, q1, [x9, #-0x40]
     698:      	fadd.4s	v4, v4, v1
     69c:      	fadd.4s	v7, v7, v0
     6a0:      	ldp	q0, q1, [x9, #-0x20]
     6a4:      	fadd.4s	v6, v6, v1
     6a8:      	fadd.4s	v5, v5, v0
     6ac:      	ldp	q0, q1, [x9], #0x80
     6b0:      	fadd.4s	v17, v17, v1
     6b4:      	fadd.4s	v19, v19, v0
     6b8:      	cmp	x10, #0x3c
     6bc:      	add	x10, x10, #0x4
     6c0:      	b.lo	0x688 <ltmp0+0x688>
     6c4:      	mov	x9, #0x0                ; =0
     6c8:      	add	x10, sp, #0x769
     6cc:      	ldur	q0, [x10, #0xff]
     6d0:      	add	x10, sp, #0x759
     6d4:      	ldur	q1, [x10, #0xff]
     6d8:      	fadd.4s	v1, v18, v1
     6dc:      	fadd.4s	v0, v16, v0
     6e0:      	movi.2d	v2, #0000000000000000
     6e4:      	fadd.4s	v0, v0, v2
     6e8:      	fadd.4s	v1, v1, v2
     6ec:      	fadd.4s	v1, v7, v1
     6f0:      	fadd.4s	v0, v4, v0
     6f4:      	fadd.4s	v0, v6, v0
     6f8:      	fadd.4s	v1, v5, v1
     6fc:      	fadd.4s	v4, v19, v1
     700:      	fadd.4s	v5, v17, v0
     704:      	dup.2d	v6, x8
     708:      	add	x8, sp, #0x58
     70c:      	ldp	q18, q17, [sp, #0x20]
     710:      	ldp	q20, q19, [sp]
     714:      	dup.2d	v0, x9
     718:      	add.2d	v1, v0, v17
     71c:      	add.2d	v2, v0, v19
     720:      	add.2d	v3, v0, v18
     724:      	add.2d	v0, v0, v20
     728:      	add	x10, x8, x9, lsl #5
     72c:      	ldp	q7, q16, [x10]
     730:      	fdiv.4s	v16, v16, v5
     734:      	fdiv.4s	v7, v7, v4
     738:      	shl.2d	v0, v0, #0x2
     73c:      	shl.2d	v3, v3, #0x2
     740:      	shl.2d	v2, v2, #0x2
     744:      	shl.2d	v1, v1, #0x2
     748:      	add.2d	v1, v6, v1
     74c:      	add.2d	v0, v6, v0
     750:      	mov.d	x10, v0[1]
     754:      	fmov	x11, d0
     758:      	str	s7, [x11]
     75c:      	st1.s	{ v7 }[1], [x10]
     760:      	add.2d	v0, v6, v3
     764:      	mov.d	x10, v0[1]
     768:      	fmov	x11, d0
     76c:      	st1.s	{ v7 }[2], [x11]
     770:      	add.2d	v0, v6, v2
     774:      	st1.s	{ v7 }[3], [x10]
     778:      	mov.d	x10, v0[1]
     77c:      	fmov	x11, d0
     780:      	str	s16, [x11]
     784:      	st1.s	{ v16 }[1], [x10]
     788:      	mov.d	x10, v1[1]
     78c:      	fmov	x11, d1
     790:      	st1.s	{ v16 }[2], [x11]
     794:      	st1.s	{ v16 }[3], [x10]
     798:      	add	x9, x9, #0x1
     79c:      	cmp	x9, #0x41
     7a0:      	b.ne	0x714 <ltmp0+0x714>
     7a4:      	add	sp, sp, #0x2, lsl #12   ; =0x2000
     7a8:      	add	sp, sp, #0xb00
     7ac:      	ldp	x28, x27, [sp, #0x40]
     7b0:      	ldp	d9, d8, [sp, #0x30]
     7b4:      	ldp	d11, d10, [sp, #0x20]
     7b8:      	ldp	d13, d12, [sp, #0x10]
     7bc:      	ldp	d15, d14, [sp], #0x50
     7c0:      	ret

00000000000007c4 <_llm_rows.packet_batch.blocks>:
     7c4:      	stp	d15, d14, [sp, #-0xa0]!
     7c8:      	stp	d13, d12, [sp, #0x10]
     7cc:      	stp	d11, d10, [sp, #0x20]
     7d0:      	stp	d9, d8, [sp, #0x30]
     7d4:      	stp	x28, x27, [sp, #0x40]
     7d8:      	stp	x26, x25, [sp, #0x50]
     7dc:      	stp	x24, x23, [sp, #0x60]
     7e0:      	stp	x22, x21, [sp, #0x70]
     7e4:      	stp	x20, x19, [sp, #0x80]
     7e8:      	stp	x29, x30, [sp, #0x90]
     7ec:      	sub	sp, sp, #0x2, lsl #12   ; =0x2000
     7f0:      	sub	sp, sp, #0xb50
     7f4:      	str	x0, [sp, #0x88]
     7f8:      	cbz	w3, 0x151c <_llm_rows.packet_batch.blocks+0xd58>
     7fc:      	mov	x25, x3
     800:      	mov	x20, x2
     804:      	mov	w22, #0x0               ; =0
     808:      	add	x23, sp, #0xa8
     80c:      	ldp	w9, w8, [x2, #0x2c]
     810:      	stp	w8, w9, [sp, #0x80]
     814:      	ldp	w26, w1, [x2]
     818:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
     81c:      	add	x8, x8, #0xe8
     820:      	add	x9, sp, #0x8c8
     824:      	add	x10, x9, #0xe0
     828:      	add	x9, x23, #0xe0
     82c:      	stp	x9, x10, [sp, #0x38]
     830:      	ldp	w24, w9, [x2, #0x8]
     834:      	str	x9, [sp, #0x78]
     838:      	movi.2s	v8, #0x41
     83c:      	dup.2d	v0, x8
     840:      	str	q0, [sp, #0x20]
     844:      	add	x19, sp, #0x2, lsl #12  ; =0x2000
     848:      	add	x19, x19, #0x330
     84c:      	adrp	x8, 0x0 <ltmp0>
     850:      	ldr	q0, [x8]
     854:      	str	q0, [sp, #0x60]
     858:      	add	x21, sp, #0x1, lsl #12  ; =0x1000
     85c:      	add	x21, x21, #0x2f0
     860:      	adrp	x8, 0x0 <ltmp0>
     864:      	ldr	q0, [x8]
     868:      	str	q0, [sp, #0x50]
     86c:      	adrp	x8, 0x0 <ltmp0>
     870:      	ldr	q0, [x8]
     874:      	str	q0, [sp, #0x10]
     878:      	movi.8b	v9, #0x1
     87c:      	mvni.4s	v14, #0x7f, msl #16
     880:      	movi.4s	v15, #0x4b, lsl #24
     884:      	mvni.4s	v0, #0x3f, msl #16
     888:      	fneg.4s	v0, v0
     88c:      	str	q0, [sp, #0x90]
     890:      	str	w3, [sp, #0x4c]
     894:      	b	0x8dc <_llm_rows.packet_batch.blocks+0x118>
     898:      	mov	w8, #0x18               ; =24
     89c:      	str	w8, [x20, #0x24]
     8a0:      	ldr	w25, [sp, #0x4c]
     8a4:      	add	w8, w26, #0x1
     8a8:      	ldp	w10, w9, [sp, #0x80]
     8ac:      	cmp	w8, w9
     8b0:      	cset	w8, eq
     8b4:      	csinc	w26, wzr, w26, eq
     8b8:      	cinc	w9, w1, eq
     8bc:      	cmp	w9, w10
     8c0:      	cset	w10, eq
     8c4:      	ands	w8, w8, w10
     8c8:      	csel	w1, wzr, w9, ne
     8cc:      	add	w24, w24, w8
     8d0:      	add	w22, w22, #0x1
     8d4:      	cmp	w22, w25
     8d8:      	b.eq	0x151c <_llm_rows.packet_batch.blocks+0xd58>
     8dc:      	ubfiz	x8, x26, #5, #32
     8e0:      	ldr	x12, [sp, #0x78]
     8e4:      	cmp	x8, x12
     8e8:      	csel	x9, x8, xzr, ls
     8ec:      	subs	x10, x12, x9
     8f0:      	cmp	x10, #0x20
     8f4:      	mov	w11, #0x20              ; =32
     8f8:      	csel	x10, x10, x11, lo
     8fc:      	cmp	x12, x9
     900:      	stp	w26, w1, [x20]
     904:      	str	w24, [x20, #0x8]
     908:      	str	wzr, [x20, #0x24]
     90c:      	ccmp	x8, x12, #0x2, hi
     910:      	csel	x27, x10, xzr, ls
     914:      	cmp	x27, #0x20
     918:      	b.lo	0x97c <_llm_rows.packet_batch.blocks+0x1b8>
     91c:      	ldr	x27, [sp, #0x88]
     920:      	mov	x0, x27
     924:      	mov	x28, x1
     928:      	mov	x1, x20
     92c:      	bl	0x92c <_llm_rows.packet_batch.blocks+0x168>
     930:      	mov	w8, #0x8                ; =8
     934:      	str	w8, [x20, #0x24]
     938:      	mov	x0, x27
     93c:      	mov	x1, x20
     940:      	bl	0x940 <_llm_rows.packet_batch.blocks+0x17c>
     944:      	mov	w8, #0x10               ; =16
     948:      	str	w8, [x20, #0x24]
     94c:      	mov	x0, x27
     950:      	mov	x1, x20
     954:      	bl	0x954 <_llm_rows.packet_batch.blocks+0x190>
     958:      	mov	w8, #0x18               ; =24
     95c:      	str	w8, [x20, #0x24]
     960:      	mov	x0, x27
     964:      	mov	x1, x20
     968:      	bl	0x968 <_llm_rows.packet_batch.blocks+0x1a4>
     96c:      	movi.4s	v15, #0x4b, lsl #24
     970:      	mvni.4s	v14, #0x7f, msl #16
     974:      	mov	x1, x28
     978:      	b	0x8a4 <_llm_rows.packet_batch.blocks+0xe0>
     97c:      	lsr	x25, x27, #3
     980:      	cmp	x27, #0x8
     984:      	b.lo	0x9f8 <_llm_rows.packet_batch.blocks+0x234>
     988:      	str	wzr, [x20, #0x24]
     98c:      	ldr	x0, [sp, #0x88]
     990:      	mov	x28, x1
     994:      	mov	x1, x20
     998:      	bl	0x998 <_llm_rows.packet_batch.blocks+0x1d4>
     99c:      	movi.4s	v15, #0x4b, lsl #24
     9a0:      	mvni.4s	v14, #0x7f, msl #16
     9a4:      	mov	x1, x28
     9a8:      	cmp	x25, #0x1
     9ac:      	b.eq	0x9f8 <_llm_rows.packet_batch.blocks+0x234>
     9b0:      	mov	w8, #0x8                ; =8
     9b4:      	str	w8, [x20, #0x24]
     9b8:      	ldr	x0, [sp, #0x88]
     9bc:      	mov	x1, x20
     9c0:      	bl	0x9c0 <_llm_rows.packet_batch.blocks+0x1fc>
     9c4:      	movi.4s	v15, #0x4b, lsl #24
     9c8:      	mvni.4s	v14, #0x7f, msl #16
     9cc:      	mov	x1, x28
     9d0:      	cmp	x25, #0x2
     9d4:      	b.eq	0x9f8 <_llm_rows.packet_batch.blocks+0x234>
     9d8:      	mov	w8, #0x10               ; =16
     9dc:      	str	w8, [x20, #0x24]
     9e0:      	ldr	x0, [sp, #0x88]
     9e4:      	mov	x1, x20
     9e8:      	bl	0x9e8 <_llm_rows.packet_batch.blocks+0x224>
     9ec:      	movi.4s	v15, #0x4b, lsl #24
     9f0:      	mvni.4s	v14, #0x7f, msl #16
     9f4:      	mov	x1, x28
     9f8:      	and	w8, w27, #0x7
     9fc:      	cbz	w8, 0x898 <_llm_rows.packet_batch.blocks+0xd4>
     a00:      	dup.4s	v7, w8
     a04:      	ldp	q0, q1, [sp, #0x50]
     a08:      	cmhi.4s	v0, v7, v0
     a0c:      	cmhi.4s	v1, v7, v1
     a10:      	uzp1.8h	v6, v1, v0
     a14:      	umaxv.8h	h2, v6
     a18:      	fmov	w8, s2
     a1c:      	tbz	w8, #0x0, 0x898 <_llm_rows.packet_batch.blocks+0xd4>
     a20:      	mov	x9, #0x0                ; =0
     a24:      	ldr	x11, [sp, #0x88]
     a28:      	ldr	x10, [x11]
     a2c:      	lsl	w8, w25, #3
     a30:      	orr	w8, w8, w26, lsl #5
     a34:      	dup.4s	v2, w8
     a38:      	ldr	x8, [x11, #0x30]
     a3c:      	ldp	q4, q3, [sp, #0x50]
     a40:      	orr.16b	v3, v2, v3
     a44:      	orr.16b	v2, v2, v4
     a48:      	and.16b	v16, v0, v2
     a4c:      	and.16b	v17, v1, v3
     a50:      	movi.4s	v3, #0x41
     a54:      	umull2.2d	v2, v16, v3
     a58:      	umull2.2d	v3, v17, v3
     a5c:      	umull.2d	v4, v16, v8
     a60:      	umull.2d	v5, v17, v8
     a64:      	ldr	q18, [sp, #0x10]
     a68:      	and.16b	v6, v6, v18
     a6c:      	addv.8h	h6, v6
     a70:      	dup.2d	v18, x10
     a74:      	fmov	w10, s6
     a78:      	mov	w3, #0xf2ca             ; =62154
     a7c:      	movk	w3, #0xf149, lsl #16
     a80:      	b	0xaa4 <_llm_rows.packet_batch.blocks+0x2e0>
     a84:      	add	x11, x19, x9, lsl #5
     a88:      	ldp	q21, q22, [x11]
     a8c:      	bif.16b	v20, v22, v0
     a90:      	bif.16b	v19, v21, v1
     a94:      	stp	q19, q20, [x11]
     a98:      	add	x9, x9, #0x1
     a9c:      	cmp	x9, #0x41
     aa0:      	b.eq	0xb90 <_llm_rows.packet_batch.blocks+0x3cc>
     aa4:      	dup.2d	v21, x9
     aa8:      	add.2d	v19, v21, v5
     aac:      	shl.2d	v19, v19, #0x2
     ab0:      	add.2d	v22, v18, v19
     ab4:      	movi.2d	v19, #0000000000000000
     ab8:      	movi.2d	v20, #0000000000000000
     abc:      	tbnz	w10, #0x0, 0xb08 <_llm_rows.packet_batch.blocks+0x344>
     ac0:      	and	w11, w10, #0xff
     ac4:      	tbnz	w11, #0x1, 0xb18 <_llm_rows.packet_batch.blocks+0x354>
     ac8:      	add.2d	v22, v21, v3
     acc:      	shl.2d	v22, v22, #0x2
     ad0:      	add.2d	v22, v18, v22
     ad4:      	tbnz	w11, #0x2, 0xb30 <_llm_rows.packet_batch.blocks+0x36c>
     ad8:      	tbnz	w11, #0x3, 0xb3c <_llm_rows.packet_batch.blocks+0x378>
     adc:      	add.2d	v22, v21, v4
     ae0:      	shl.2d	v22, v22, #0x2
     ae4:      	add.2d	v22, v18, v22
     ae8:      	tbnz	w11, #0x4, 0xb54 <_llm_rows.packet_batch.blocks+0x390>
     aec:      	tbnz	w11, #0x5, 0xb60 <_llm_rows.packet_batch.blocks+0x39c>
     af0:      	add.2d	v21, v21, v2
     af4:      	shl.2d	v21, v21, #0x2
     af8:      	add.2d	v21, v18, v21
     afc:      	tbnz	w11, #0x6, 0xb78 <_llm_rows.packet_batch.blocks+0x3b4>
     b00:      	tbz	w11, #0x7, 0xa84 <_llm_rows.packet_batch.blocks+0x2c0>
     b04:      	b	0xb84 <_llm_rows.packet_batch.blocks+0x3c0>
     b08:      	fmov	x11, d22
     b0c:      	ldr	s19, [x11]
     b10:      	and	w11, w10, #0xff
     b14:      	tbz	w11, #0x1, 0xac8 <_llm_rows.packet_batch.blocks+0x304>
     b18:      	mov.d	x12, v22[1]
     b1c:      	ld1.s	{ v19 }[1], [x12]
     b20:      	add.2d	v22, v21, v3
     b24:      	shl.2d	v22, v22, #0x2
     b28:      	add.2d	v22, v18, v22
     b2c:      	tbz	w11, #0x2, 0xad8 <_llm_rows.packet_batch.blocks+0x314>
     b30:      	fmov	x12, d22
     b34:      	ld1.s	{ v19 }[2], [x12]
     b38:      	tbz	w11, #0x3, 0xadc <_llm_rows.packet_batch.blocks+0x318>
     b3c:      	mov.d	x12, v22[1]
     b40:      	ld1.s	{ v19 }[3], [x12]
     b44:      	add.2d	v22, v21, v4
     b48:      	shl.2d	v22, v22, #0x2
     b4c:      	add.2d	v22, v18, v22
     b50:      	tbz	w11, #0x4, 0xaec <_llm_rows.packet_batch.blocks+0x328>
     b54:      	fmov	x12, d22
     b58:      	ld1.s	{ v20 }[0], [x12]
     b5c:      	tbz	w11, #0x5, 0xaf0 <_llm_rows.packet_batch.blocks+0x32c>
     b60:      	mov.d	x12, v22[1]
     b64:      	ld1.s	{ v20 }[1], [x12]
     b68:      	add.2d	v21, v21, v2
     b6c:      	shl.2d	v21, v21, #0x2
     b70:      	add.2d	v21, v18, v21
     b74:      	tbz	w11, #0x6, 0xb00 <_llm_rows.packet_batch.blocks+0x33c>
     b78:      	fmov	x12, d21
     b7c:      	ld1.s	{ v20 }[2], [x12]
     b80:      	tbz	w11, #0x7, 0xa84 <_llm_rows.packet_batch.blocks+0x2c0>
     b84:      	mov.d	x11, v21[1]
     b88:      	ld1.s	{ v20 }[3], [x11]
     b8c:      	b	0xa84 <_llm_rows.packet_batch.blocks+0x2c0>
     b90:      	mov	x9, #0x0                ; =0
     b94:      	add	x2, sp, #0x8c8
     b98:      	sshll2.2d	v23, v0, #0x0
     b9c:      	sshll2.2d	v18, v1, #0x0
     ba0:      	sshll.2d	v19, v0, #0x0
     ba4:      	sshll.2d	v20, v1, #0x0
     ba8:      	dup.2d	v21, x9
     bac:      	add	x10, x21, x9, lsl #6
     bb0:      	ldp	q24, q22, [x10, #0x20]
     bb4:      	ldp	q26, q25, [x10]
     bb8:      	bsl.16b	v20, v21, v26
     bbc:      	bsl.16b	v19, v21, v24
     bc0:      	mov.16b	v24, v18
     bc4:      	bsl.16b	v24, v21, v25
     bc8:      	bif.16b	v21, v22, v23
     bcc:      	stp	q19, q21, [x10, #0x20]
     bd0:      	stp	q20, q24, [x10]
     bd4:      	add	x9, x9, #0x1
     bd8:      	cmp	x9, #0x41
     bdc:      	b.ne	0xb98 <_llm_rows.packet_batch.blocks+0x3d4>
     be0:      	mov	x9, #0x0                ; =0
     be4:      	sshll.2d	v30, v1, #0x0
     be8:      	sshll.2d	v29, v0, #0x0
     bec:      	movi.4s	v21, #0x41
     bf0:      	and.16b	v19, v0, v21
     bf4:      	mvn.16b	v20, v0
     bf8:      	sub.4s	v19, v19, v20
     bfc:      	and.16b	v20, v1, v21
     c00:      	mvn.16b	v21, v1
     c04:      	sub.4s	v20, v20, v21
     c08:      	mov.s	w10, v20[1]
     c0c:      	mov.s	w11, v17[1]
     c10:      	udiv	w12, w11, w10
     c14:      	msub	w10, w12, w10, w11
     c18:      	mov.s	w11, v20[3]
     c1c:      	mov.s	w12, v20[2]
     c20:      	fmov	w13, s20
     c24:      	fmov	w14, s17
     c28:      	udiv	w15, w14, w13
     c2c:      	msub	w13, w15, w13, w14
     c30:      	mov.s	w14, v17[3]
     c34:      	udiv	w15, w14, w11
     c38:      	msub	w11, w15, w11, w14
     c3c:      	mov.s	w14, v17[2]
     c40:      	udiv	w15, w14, w12
     c44:      	msub	w12, w15, w12, w14
     c48:      	mov.s	w14, v19[1]
     c4c:      	mov.s	w15, v16[1]
     c50:      	udiv	w16, w15, w14
     c54:      	msub	w14, w16, w14, w15
     c58:      	mov.s	w15, v19[3]
     c5c:      	mov.s	w16, v16[3]
     c60:      	udiv	w17, w16, w15
     c64:      	msub	w15, w17, w15, w16
     c68:      	mov.s	w16, v19[2]
     c6c:      	mov.s	w17, v16[2]
     c70:      	udiv	w0, w17, w16
     c74:      	msub	w16, w0, w16, w17
     c78:      	fmov	w17, s19
     c7c:      	fmov	w0, s16
     c80:      	fmov	s16, w16
     c84:      	mov.s	v16[1], w15
     c88:      	udiv	w15, w0, w17
     c8c:      	msub	w15, w15, w17, w0
     c90:      	ushll.2d	v19, v16, #0x0
     c94:      	fmov	s16, w15
     c98:      	mov.s	v16[1], w14
     c9c:      	ushll.2d	v20, v16, #0x0
     ca0:      	fmov	s16, w12
     ca4:      	mov.s	v16[1], w11
     ca8:      	fmov	s17, w13
     cac:      	mov.s	v17[1], w10
     cb0:      	ushll.2d	v21, v16, #0x0
     cb4:      	ushll.2d	v22, v17, #0x0
     cb8:      	ldr	q16, [sp, #0x20]
     cbc:      	and.16b	v24, v23, v16
     cc0:      	and.16b	v25, v18, v16
     cc4:      	and.16b	v26, v29, v16
     cc8:      	and.16b	v27, v30, v16
     ccc:      	adrp	x10, 0x0 <ltmp0>
     cd0:      	ldr	q16, [x10]
     cd4:      	and.16b	v23, v23, v16
     cd8:      	adrp	x10, 0x0 <ltmp0>
     cdc:      	ldr	q16, [x10]
     ce0:      	and.16b	v28, v18, v16
     ce4:      	adrp	x10, 0x0 <ltmp0>
     ce8:      	ldr	q16, [x10]
     cec:      	and.16b	v29, v29, v16
     cf0:      	adrp	x10, 0x0 <ltmp0>
     cf4:      	ldr	q16, [x10]
     cf8:      	and.16b	v30, v30, v16
     cfc:      	ldp	q16, q17, [sp, #0x50]
     d00:      	cmhs.4s	v16, v16, v7
     d04:      	cmhs.4s	v7, v17, v7
     d08:      	uzp1.8h	v7, v7, v16
     d0c:      	xtn.8b	v31, v7
     d10:      	mov	w12, #-0x3d300000       ; =-1026555904
     d14:      	mov	w13, #0x42c80000        ; =1120403456
     d18:      	mov	w14, #0xaa3b            ; =43579
     d1c:      	movk	w14, #0x3fb8, lsl #16
     d20:      	mov	w15, #0x7200            ; =29184
     d24:      	movk	w15, #0xbf31, lsl #16
     d28:      	mov	w16, #0xbe8e            ; =48782
     d2c:      	movk	w16, #0xb5bf, lsl #16
     d30:      	mov	w17, #0x2bda            ; =11226
     d34:      	movk	w17, #0x3950, lsl #16
     d38:      	mov	w0, #0x96c9             ; =38601
     d3c:      	movk	w0, #0x3ab6, lsl #16
     d40:      	mov	w4, #0x88a6             ; =34982
     d44:      	movk	w4, #0x3c08, lsl #16
     d48:      	mov	w5, #0xaa7a             ; =43642
     d4c:      	movk	w5, #0x3d2a, lsl #16
     d50:      	mov	w6, #0xaaab             ; =43691
     d54:      	movk	w6, #0x3e2a, lsl #16
     d58:      	b	0xd68 <_llm_rows.packet_batch.blocks+0x5a4>
     d5c:      	add	x9, x9, #0x1
     d60:      	cmp	x9, #0x41
     d64:      	b.eq	0xe68 <_llm_rows.packet_batch.blocks+0x6a4>
     d68:      	dup.2d	v10, x9
     d6c:      	fmov	w10, s6
     d70:      	add	x11, x21, x9, lsl #6
     d74:      	ldp	q16, q7, [x11, #0x20]
     d78:      	ldp	q17, q18, [x11]
     d7c:      	cmge.2d	v18, v21, v18
     d80:      	cmge.2d	v17, v22, v17
     d84:      	uzp1.4s	v17, v17, v18
     d88:      	cmge.2d	v16, v20, v16
     d8c:      	cmge.2d	v7, v19, v7
     d90:      	uzp1.4s	v7, v16, v7
     d94:      	uzp1.8h	v7, v17, v7
     d98:      	xtn.8b	v7, v7
     d9c:      	orr.8b	v17, v31, v7
     da0:      	add.2d	v7, v27, v30
     da4:      	add.2d	v16, v7, v10
     da8:      	and.8b	v11, v17, v9
     dac:      	tbnz	w10, #0x0, 0xdec <_llm_rows.packet_batch.blocks+0x628>
     db0:      	and	w10, w10, #0xff
     db4:      	tbnz	w10, #0x1, 0xdfc <_llm_rows.packet_batch.blocks+0x638>
     db8:      	add.2d	v16, v25, v28
     dbc:      	add.2d	v17, v16, v10
     dc0:      	tbnz	w10, #0x2, 0xe10 <_llm_rows.packet_batch.blocks+0x64c>
     dc4:      	tbnz	w10, #0x3, 0xe1c <_llm_rows.packet_batch.blocks+0x658>
     dc8:      	add.2d	v17, v26, v29
     dcc:      	add.2d	v18, v17, v10
     dd0:      	tbnz	w10, #0x4, 0xe30 <_llm_rows.packet_batch.blocks+0x66c>
     dd4:      	tbnz	w10, #0x5, 0xe3c <_llm_rows.packet_batch.blocks+0x678>
     dd8:      	add.2d	v18, v24, v23
     ddc:      	add.2d	v10, v18, v10
     de0:      	tbnz	w10, #0x6, 0xe50 <_llm_rows.packet_batch.blocks+0x68c>
     de4:      	tbz	w10, #0x7, 0xd5c <_llm_rows.packet_batch.blocks+0x598>
     de8:      	b	0xe5c <_llm_rows.packet_batch.blocks+0x698>
     dec:      	fmov	x11, d16
     df0:      	str	b11, [x11]
     df4:      	and	w10, w10, #0xff
     df8:      	tbz	w10, #0x1, 0xdb8 <_llm_rows.packet_batch.blocks+0x5f4>
     dfc:      	mov.d	x11, v16[1]
     e00:      	st1.b	{ v11 }[1], [x11]
     e04:      	add.2d	v16, v25, v28
     e08:      	add.2d	v17, v16, v10
     e0c:      	tbz	w10, #0x2, 0xdc4 <_llm_rows.packet_batch.blocks+0x600>
     e10:      	fmov	x11, d17
     e14:      	st1.b	{ v11 }[2], [x11]
     e18:      	tbz	w10, #0x3, 0xdc8 <_llm_rows.packet_batch.blocks+0x604>
     e1c:      	mov.d	x11, v17[1]
     e20:      	st1.b	{ v11 }[3], [x11]
     e24:      	add.2d	v17, v26, v29
     e28:      	add.2d	v18, v17, v10
     e2c:      	tbz	w10, #0x4, 0xdd4 <_llm_rows.packet_batch.blocks+0x610>
     e30:      	fmov	x11, d18
     e34:      	st1.b	{ v11 }[4], [x11]
     e38:      	tbz	w10, #0x5, 0xdd8 <_llm_rows.packet_batch.blocks+0x614>
     e3c:      	mov.d	x11, v18[1]
     e40:      	st1.b	{ v11 }[5], [x11]
     e44:      	add.2d	v18, v24, v23
     e48:      	add.2d	v10, v18, v10
     e4c:      	tbz	w10, #0x6, 0xde4 <_llm_rows.packet_batch.blocks+0x620>
     e50:      	fmov	x11, d10
     e54:      	st1.b	{ v11 }[6], [x11]
     e58:      	tbz	w10, #0x7, 0xd5c <_llm_rows.packet_batch.blocks+0x598>
     e5c:      	mov.d	x10, v10[1]
     e60:      	st1.b	{ v11 }[7], [x10]
     e64:      	b	0xd5c <_llm_rows.packet_batch.blocks+0x598>
     e68:      	mov	x9, #0x0                ; =0
     e6c:      	b	0xec0 <_llm_rows.packet_batch.blocks+0x6fc>
     e70:      	cmeq.8b	v19, v19, #0
     e74:      	sshll.8h	v19, v19, #0x0
     e78:      	sshll2.4s	v20, v19, #0x0
     e7c:      	sshll.4s	v19, v19, #0x0
     e80:      	lsl	x10, x9, #5
     e84:      	add	x11, x19, x10
     e88:      	ldp	q21, q22, [x11]
     e8c:      	and.16b	v22, v0, v22
     e90:      	dup.4s	v23, w3
     e94:      	and.16b	v21, v1, v21
     e98:      	bsl.16b	v19, v23, v21
     e9c:      	bsl.16b	v20, v23, v22
     ea0:      	add	x10, x2, x10
     ea4:      	ldp	q21, q22, [x10]
     ea8:      	bif.16b	v20, v22, v0
     eac:      	bif.16b	v19, v21, v1
     eb0:      	stp	q19, q20, [x10]
     eb4:      	add	x9, x9, #0x1
     eb8:      	cmp	x9, #0x41
     ebc:      	b.eq	0xf70 <_llm_rows.packet_batch.blocks+0x7ac>
     ec0:      	fmov	w10, s6
     ec4:      	dup.2d	v20, x9
     ec8:      	add.2d	v21, v7, v20
     ecc:      	tbz	w10, #0x0, 0xee4 <_llm_rows.packet_batch.blocks+0x720>
     ed0:      	fmov	x11, d21
     ed4:      	ldr	b19, [x11]
     ed8:      	and	w10, w10, #0xff
     edc:      	tbnz	w10, #0x1, 0xef0 <_llm_rows.packet_batch.blocks+0x72c>
     ee0:      	b	0xef8 <_llm_rows.packet_batch.blocks+0x734>
     ee4:      	movi.2d	v19, #0000000000000000
     ee8:      	and	w10, w10, #0xff
     eec:      	tbz	w10, #0x1, 0xef8 <_llm_rows.packet_batch.blocks+0x734>
     ef0:      	mov.d	x11, v21[1]
     ef4:      	ld1.b	{ v19 }[1], [x11]
     ef8:      	add.2d	v21, v16, v20
     efc:      	tbnz	w10, #0x2, 0xf20 <_llm_rows.packet_batch.blocks+0x75c>
     f00:      	tbnz	w10, #0x3, 0xf2c <_llm_rows.packet_batch.blocks+0x768>
     f04:      	add.2d	v21, v17, v20
     f08:      	tbnz	w10, #0x4, 0xf3c <_llm_rows.packet_batch.blocks+0x778>
     f0c:      	tbnz	w10, #0x5, 0xf48 <_llm_rows.packet_batch.blocks+0x784>
     f10:      	add.2d	v20, v18, v20
     f14:      	tbnz	w10, #0x6, 0xf58 <_llm_rows.packet_batch.blocks+0x794>
     f18:      	tbz	w10, #0x7, 0xe70 <_llm_rows.packet_batch.blocks+0x6ac>
     f1c:      	b	0xf64 <_llm_rows.packet_batch.blocks+0x7a0>
     f20:      	fmov	x11, d21
     f24:      	ld1.b	{ v19 }[2], [x11]
     f28:      	tbz	w10, #0x3, 0xf04 <_llm_rows.packet_batch.blocks+0x740>
     f2c:      	mov.d	x11, v21[1]
     f30:      	ld1.b	{ v19 }[3], [x11]
     f34:      	add.2d	v21, v17, v20
     f38:      	tbz	w10, #0x4, 0xf0c <_llm_rows.packet_batch.blocks+0x748>
     f3c:      	fmov	x11, d21
     f40:      	ld1.b	{ v19 }[4], [x11]
     f44:      	tbz	w10, #0x5, 0xf10 <_llm_rows.packet_batch.blocks+0x74c>
     f48:      	mov.d	x11, v21[1]
     f4c:      	ld1.b	{ v19 }[5], [x11]
     f50:      	add.2d	v20, v18, v20
     f54:      	tbz	w10, #0x6, 0xf18 <_llm_rows.packet_batch.blocks+0x754>
     f58:      	fmov	x11, d20
     f5c:      	ld1.b	{ v19 }[6], [x11]
     f60:      	tbz	w10, #0x7, 0xe70 <_llm_rows.packet_batch.blocks+0x6ac>
     f64:      	mov.d	x10, v20[1]
     f68:      	ld1.b	{ v19 }[7], [x10]
     f6c:      	b	0xe70 <_llm_rows.packet_batch.blocks+0x6ac>
     f70:      	ldr	q19, [x23, #0x820]
     f74:      	ldr	q20, [x23, #0x830]
     f78:      	ldr	q21, [x23, #0x840]
     f7c:      	ldr	q22, [x23, #0x850]
     f80:      	ldr	q24, [x23, #0x860]
     f84:      	ldr	q27, [x23, #0x870]
     f88:      	ldr	q28, [x23, #0x880]
     f8c:      	and.16b	v26, v0, v20
     f90:      	and.16b	v25, v1, v19
     f94:      	ldr	q20, [x23, #0x890]
     f98:      	and.16b	v23, v0, v22
     f9c:      	and.16b	v22, v1, v21
     fa0:      	and.16b	v19, v0, v27
     fa4:      	and.16b	v24, v1, v24
     fa8:      	and.16b	v21, v0, v20
     fac:      	and.16b	v20, v1, v28
     fb0:      	ldr	x9, [sp, #0x40]
     fb4:      	mov	w10, #0x4               ; =4
     fb8:      	ldp	q27, q28, [x9, #-0x60]
     fbc:      	and.16b	v28, v0, v28
     fc0:      	and.16b	v27, v1, v27
     fc4:      	fmaxnm.4s	v27, v25, v27
     fc8:      	fmaxnm.4s	v28, v26, v28
     fcc:      	ldp	q29, q30, [x9, #-0x40]
     fd0:      	and.16b	v30, v0, v30
     fd4:      	and.16b	v29, v1, v29
     fd8:      	fmaxnm.4s	v29, v22, v29
     fdc:      	fmaxnm.4s	v30, v23, v30
     fe0:      	ldp	q31, q10, [x9, #-0x20]
     fe4:      	and.16b	v10, v0, v10
     fe8:      	and.16b	v31, v1, v31
     fec:      	fmaxnm.4s	v31, v24, v31
     ff0:      	fmaxnm.4s	v10, v19, v10
     ff4:      	ldp	q11, q12, [x9], #0x80
     ff8:      	and.16b	v12, v0, v12
     ffc:      	and.16b	v11, v1, v11
    1000:      	fmaxnm.4s	v11, v20, v11
    1004:      	fmaxnm.4s	v12, v21, v12
    1008:      	bit.16b	v26, v28, v0
    100c:      	bit.16b	v25, v27, v1
    1010:      	bit.16b	v23, v30, v0
    1014:      	bit.16b	v22, v29, v1
    1018:      	bit.16b	v19, v10, v0
    101c:      	bit.16b	v24, v31, v1
    1020:      	bit.16b	v21, v12, v0
    1024:      	bit.16b	v20, v11, v1
    1028:      	cmp	x10, #0x3c
    102c:      	add	x10, x10, #0x4
    1030:      	b.lo	0xfb8 <_llm_rows.packet_batch.blocks+0x7f4>
    1034:      	mov	x9, #0x0                ; =0
    1038:      	ldr	q27, [x23, #0x1030]
    103c:      	ldr	q28, [x23, #0x1020]
    1040:      	and.16b	v28, v1, v28
    1044:      	and.16b	v27, v0, v27
    1048:      	fmaxnm.4s	v26, v26, v27
    104c:      	fmaxnm.4s	v25, v25, v28
    1050:      	fmaxnm.4s	v25, v25, v14
    1054:      	fmaxnm.4s	v26, v26, v14
    1058:      	fmaxnm.4s	v23, v26, v23
    105c:      	fmaxnm.4s	v22, v25, v22
    1060:      	fmaxnm.4s	v22, v22, v24
    1064:      	fmaxnm.4s	v19, v23, v19
    1068:      	fmaxnm.4s	v19, v19, v21
    106c:      	fmaxnm.4s	v20, v22, v20
    1070:      	b	0x125c <_llm_rows.packet_batch.blocks+0xa98>
    1074:      	cmeq.8b	v21, v21, #0
    1078:      	sshll.8h	v22, v21, #0x0
    107c:      	sshll2.4s	v21, v22, #0x0
    1080:      	sshll.4s	v22, v22, #0x0
    1084:      	lsl	x10, x9, #5
    1088:      	add	x11, x2, x10
    108c:      	ldp	q24, q23, [x11]
    1090:      	fsub.4s	v24, v24, v20
    1094:      	fsub.4s	v23, v23, v19
    1098:      	and.16b	v23, v0, v23
    109c:      	and.16b	v24, v1, v24
    10a0:      	dup.4s	v25, w12
    10a4:      	fcmge.4s	v27, v24, v25
    10a8:      	fcmge.4s	v28, v23, v25
    10ac:      	dup.4s	v26, w13
    10b0:      	fcmge.4s	v29, v26, v24
    10b4:      	fcmge.4s	v30, v26, v23
    10b8:      	and.16b	v28, v28, v30
    10bc:      	and.16b	v27, v27, v29
    10c0:      	and.16b	v27, v27, v24
    10c4:      	and.16b	v28, v28, v23
    10c8:      	dup.4s	v29, w14
    10cc:      	fmul.4s	v30, v28, v29
    10d0:      	fmul.4s	v29, v27, v29
    10d4:      	mvni.4s	v10, #0x80, lsl #24
    10d8:      	mov.16b	v31, v10
    10dc:      	bsl.16b	v31, v15, v29
    10e0:      	bsl.16b	v10, v15, v30
    10e4:      	fadd.4s	v30, v30, v10
    10e8:      	fadd.4s	v29, v29, v31
    10ec:      	fsub.4s	v29, v29, v31
    10f0:      	fsub.4s	v30, v30, v10
    10f4:      	fcvtzs.4s	v30, v30
    10f8:      	fcvtzs.4s	v29, v29
    10fc:      	scvtf.4s	v31, v29
    1100:      	dup.4s	v10, w15
    1104:      	scvtf.4s	v11, v30
    1108:      	fmul.4s	v12, v11, v10
    110c:      	fmul.4s	v10, v31, v10
    1110:      	fadd.4s	v27, v27, v10
    1114:      	dup.4s	v10, w16
    1118:      	fadd.4s	v28, v28, v12
    111c:      	fmul.4s	v31, v31, v10
    1120:      	fmul.4s	v10, v11, v10
    1124:      	fadd.4s	v28, v28, v10
    1128:      	dup.4s	v10, w17
    112c:      	fadd.4s	v27, v27, v31
    1130:      	fmul.4s	v31, v27, v10
    1134:      	fmul.4s	v10, v28, v10
    1138:      	dup.4s	v11, w0
    113c:      	fadd.4s	v10, v10, v11
    1140:      	fadd.4s	v31, v31, v11
    1144:      	fmul.4s	v31, v27, v31
    1148:      	fmul.4s	v10, v28, v10
    114c:      	dup.4s	v11, w4
    1150:      	fadd.4s	v10, v10, v11
    1154:      	fadd.4s	v31, v31, v11
    1158:      	fmul.4s	v31, v27, v31
    115c:      	fmul.4s	v10, v28, v10
    1160:      	dup.4s	v11, w5
    1164:      	fadd.4s	v10, v10, v11
    1168:      	fadd.4s	v31, v31, v11
    116c:      	fmul.4s	v31, v27, v31
    1170:      	fmul.4s	v10, v28, v10
    1174:      	dup.4s	v11, w6
    1178:      	fadd.4s	v10, v10, v11
    117c:      	fadd.4s	v31, v31, v11
    1180:      	fmul.4s	v31, v27, v31
    1184:      	fmul.4s	v10, v28, v10
    1188:      	movi.4s	v11, #0x3f, lsl #24
    118c:      	fadd.4s	v10, v10, v11
    1190:      	fadd.4s	v31, v31, v11
    1194:      	fmul.4s	v11, v28, v28
    1198:      	fmul.4s	v12, v27, v27
    119c:      	fmul.4s	v31, v12, v31
    11a0:      	fmul.4s	v10, v11, v10
    11a4:      	fadd.4s	v28, v28, v10
    11a8:      	fadd.4s	v27, v27, v31
    11ac:      	fmov.4s	v31, #1.00000000
    11b0:      	fadd.4s	v27, v27, v31
    11b4:      	fadd.4s	v28, v28, v31
    11b8:      	sshr.4s	v10, v29, #0x1
    11bc:      	sshr.4s	v11, v30, #0x1
    11c0:      	shl.4s	v12, v11, #0x17
    11c4:      	shl.4s	v13, v10, #0x17
    11c8:      	add.4s	v13, v13, v31
    11cc:      	add.4s	v12, v12, v31
    11d0:      	fmul.4s	v28, v28, v12
    11d4:      	fmul.4s	v27, v27, v13
    11d8:      	sub.4s	v30, v30, v11
    11dc:      	sub.4s	v29, v29, v10
    11e0:      	shl.4s	v29, v29, #0x17
    11e4:      	shl.4s	v30, v30, #0x17
    11e8:      	add.4s	v30, v30, v31
    11ec:      	add.4s	v29, v29, v31
    11f0:      	fmul.4s	v27, v27, v29
    11f4:      	fmul.4s	v28, v28, v30
    11f8:      	fcmgt.4s	v29, v25, v23
    11fc:      	bic.16b	v28, v28, v29
    1200:      	fcmgt.4s	v25, v25, v24
    1204:      	bic.16b	v25, v27, v25
    1208:      	fcmgt.4s	v27, v23, v26
    120c:      	fcmgt.4s	v26, v24, v26
    1210:      	fneg.4s	v29, v14
    1214:      	bit.16b	v25, v29, v26
    1218:      	mov.16b	v26, v27
    121c:      	bsl.16b	v26, v29, v28
    1220:      	fcmeq.4s	v24, v24, v24
    1224:      	fcmeq.4s	v23, v23, v23
    1228:      	ldr	q27, [sp, #0x90]
    122c:      	bsl.16b	v23, v26, v27
    1230:      	bsl.16b	v24, v25, v27
    1234:      	bic.16b	v22, v24, v22
    1238:      	bic.16b	v21, v23, v21
    123c:      	add	x10, x23, x10
    1240:      	ldp	q23, q24, [x10]
    1244:      	bif.16b	v21, v24, v0
    1248:      	bif.16b	v22, v23, v1
    124c:      	stp	q22, q21, [x10]
    1250:      	add	x9, x9, #0x1
    1254:      	cmp	x9, #0x41
    1258:      	b.eq	0x130c <_llm_rows.packet_batch.blocks+0xb48>
    125c:      	fmov	w10, s6
    1260:      	dup.2d	v22, x9
    1264:      	add.2d	v23, v7, v22
    1268:      	tbz	w10, #0x0, 0x1280 <_llm_rows.packet_batch.blocks+0xabc>
    126c:      	fmov	x11, d23
    1270:      	ldr	b21, [x11]
    1274:      	and	w10, w10, #0xff
    1278:      	tbnz	w10, #0x1, 0x128c <_llm_rows.packet_batch.blocks+0xac8>
    127c:      	b	0x1294 <_llm_rows.packet_batch.blocks+0xad0>
    1280:      	movi.2d	v21, #0000000000000000
    1284:      	and	w10, w10, #0xff
    1288:      	tbz	w10, #0x1, 0x1294 <_llm_rows.packet_batch.blocks+0xad0>
    128c:      	mov.d	x11, v23[1]
    1290:      	ld1.b	{ v21 }[1], [x11]
    1294:      	add.2d	v23, v16, v22
    1298:      	tbnz	w10, #0x2, 0x12bc <_llm_rows.packet_batch.blocks+0xaf8>
    129c:      	tbnz	w10, #0x3, 0x12c8 <_llm_rows.packet_batch.blocks+0xb04>
    12a0:      	add.2d	v23, v17, v22
    12a4:      	tbnz	w10, #0x4, 0x12d8 <_llm_rows.packet_batch.blocks+0xb14>
    12a8:      	tbnz	w10, #0x5, 0x12e4 <_llm_rows.packet_batch.blocks+0xb20>
    12ac:      	add.2d	v22, v18, v22
    12b0:      	tbnz	w10, #0x6, 0x12f4 <_llm_rows.packet_batch.blocks+0xb30>
    12b4:      	tbz	w10, #0x7, 0x1074 <_llm_rows.packet_batch.blocks+0x8b0>
    12b8:      	b	0x1300 <_llm_rows.packet_batch.blocks+0xb3c>
    12bc:      	fmov	x11, d23
    12c0:      	ld1.b	{ v21 }[2], [x11]
    12c4:      	tbz	w10, #0x3, 0x12a0 <_llm_rows.packet_batch.blocks+0xadc>
    12c8:      	mov.d	x11, v23[1]
    12cc:      	ld1.b	{ v21 }[3], [x11]
    12d0:      	add.2d	v23, v17, v22
    12d4:      	tbz	w10, #0x4, 0x12a8 <_llm_rows.packet_batch.blocks+0xae4>
    12d8:      	fmov	x11, d23
    12dc:      	ld1.b	{ v21 }[4], [x11]
    12e0:      	tbz	w10, #0x5, 0x12ac <_llm_rows.packet_batch.blocks+0xae8>
    12e4:      	mov.d	x11, v23[1]
    12e8:      	ld1.b	{ v21 }[5], [x11]
    12ec:      	add.2d	v22, v18, v22
    12f0:      	tbz	w10, #0x6, 0x12b4 <_llm_rows.packet_batch.blocks+0xaf0>
    12f4:      	fmov	x11, d22
    12f8:      	ld1.b	{ v21 }[6], [x11]
    12fc:      	tbz	w10, #0x7, 0x1074 <_llm_rows.packet_batch.blocks+0x8b0>
    1300:      	mov.d	x10, v22[1]
    1304:      	ld1.b	{ v21 }[7], [x10]
    1308:      	b	0x1074 <_llm_rows.packet_batch.blocks+0x8b0>
    130c:      	ldur	q7, [sp, #0xa8]
    1310:      	ldur	q16, [sp, #0xb8]
    1314:      	ldur	q17, [sp, #0xc8]
    1318:      	ldur	q18, [sp, #0xd8]
    131c:      	ldur	q21, [sp, #0xe8]
    1320:      	ldur	q22, [sp, #0xf8]
    1324:      	and.16b	v16, v0, v16
    1328:      	and.16b	v20, v1, v7
    132c:      	add	x9, sp, #0x9
    1330:      	ldur	q23, [x9, #0xff]
    1334:      	add	x9, sp, #0x19
    1338:      	ldur	q24, [x9, #0xff]
    133c:      	and.16b	v7, v0, v18
    1340:      	and.16b	v19, v1, v17
    1344:      	and.16b	v18, v0, v22
    1348:      	and.16b	v17, v1, v21
    134c:      	and.16b	v21, v0, v24
    1350:      	and.16b	v22, v1, v23
    1354:      	ldr	x9, [sp, #0x38]
    1358:      	mov	w10, #0x4               ; =4
    135c:      	ldp	q24, q23, [x9, #-0x60]
    1360:      	fadd.4s	v25, v20, v24
    1364:      	fadd.4s	v26, v16, v23
    1368:      	ldp	q24, q23, [x9, #-0x40]
    136c:      	fadd.4s	v27, v19, v24
    1370:      	fadd.4s	v28, v7, v23
    1374:      	ldp	q24, q23, [x9, #-0x20]
    1378:      	fadd.4s	v29, v17, v24
    137c:      	fadd.4s	v30, v18, v23
    1380:      	ldp	q23, q24, [x9], #0x80
    1384:      	fadd.4s	v23, v22, v23
    1388:      	fadd.4s	v24, v21, v24
    138c:      	bit.16b	v16, v26, v0
    1390:      	bit.16b	v20, v25, v1
    1394:      	bit.16b	v7, v28, v0
    1398:      	bit.16b	v19, v27, v1
    139c:      	bit.16b	v18, v30, v0
    13a0:      	bit.16b	v17, v29, v1
    13a4:      	bit.16b	v21, v24, v0
    13a8:      	bit.16b	v22, v23, v1
    13ac:      	cmp	x10, #0x3c
    13b0:      	add	x10, x10, #0x4
    13b4:      	b.lo	0x135c <_llm_rows.packet_batch.blocks+0xb98>
    13b8:      	mov	x9, #0x0                ; =0
    13bc:      	ldr	q21, [x23, #0x800]
    13c0:      	ldr	q22, [x23, #0x810]
    13c4:      	and.16b	v22, v0, v22
    13c8:      	and.16b	v21, v1, v21
    13cc:      	fadd.4s	v20, v20, v21
    13d0:      	fadd.4s	v16, v16, v22
    13d4:      	movi.2d	v21, #0000000000000000
    13d8:      	fadd.4s	v16, v16, v21
    13dc:      	fadd.4s	v20, v20, v21
    13e0:      	fadd.4s	v19, v19, v20
    13e4:      	fadd.4s	v7, v7, v16
    13e8:      	fadd.4s	v7, v18, v7
    13ec:      	fadd.4s	v16, v17, v19
    13f0:      	fadd.4s	v16, v23, v16
    13f4:      	fadd.4s	v7, v24, v7
    13f8:      	and.16b	v7, v0, v7
    13fc:      	and.16b	v16, v1, v16
    1400:      	b	0x1410 <_llm_rows.packet_batch.blocks+0xc4c>
    1404:      	add	x9, x9, #0x1
    1408:      	cmp	x9, #0x41
    140c:      	b.eq	0x898 <_llm_rows.packet_batch.blocks+0xd4>
    1410:      	fmov	w10, s6
    1414:      	dup.2d	v17, x9
    1418:      	add.2d	v18, v17, v5
    141c:      	add	x11, x23, x9, lsl #5
    1420:      	ldp	q20, q19, [x11]
    1424:      	and.16b	v20, v1, v20
    1428:      	fdiv.4s	v20, v20, v16
    142c:      	shl.2d	v21, v18, #0x2
    1430:      	dup.2d	v18, x8
    1434:      	add.2d	v21, v18, v21
    1438:      	tbnz	w10, #0x0, 0x148c <_llm_rows.packet_batch.blocks+0xcc8>
    143c:      	and	w10, w10, #0xff
    1440:      	tbnz	w10, #0x1, 0x149c <_llm_rows.packet_batch.blocks+0xcd8>
    1444:      	add.2d	v21, v17, v3
    1448:      	shl.2d	v21, v21, #0x2
    144c:      	add.2d	v21, v18, v21
    1450:      	tbnz	w10, #0x2, 0x14b4 <_llm_rows.packet_batch.blocks+0xcf0>
    1454:      	tbnz	w10, #0x3, 0x14c0 <_llm_rows.packet_batch.blocks+0xcfc>
    1458:      	add.2d	v20, v17, v4
    145c:      	and.16b	v19, v0, v19
    1460:      	fdiv.4s	v19, v19, v7
    1464:      	shl.2d	v20, v20, #0x2
    1468:      	add.2d	v20, v18, v20
    146c:      	tbnz	w10, #0x4, 0x14e0 <_llm_rows.packet_batch.blocks+0xd1c>
    1470:      	tbnz	w10, #0x5, 0x14ec <_llm_rows.packet_batch.blocks+0xd28>
    1474:      	add.2d	v17, v17, v2
    1478:      	shl.2d	v17, v17, #0x2
    147c:      	add.2d	v17, v18, v17
    1480:      	tbnz	w10, #0x6, 0x1504 <_llm_rows.packet_batch.blocks+0xd40>
    1484:      	tbz	w10, #0x7, 0x1404 <_llm_rows.packet_batch.blocks+0xc40>
    1488:      	b	0x1510 <_llm_rows.packet_batch.blocks+0xd4c>
    148c:      	fmov	x11, d21
    1490:      	str	s20, [x11]
    1494:      	and	w10, w10, #0xff
    1498:      	tbz	w10, #0x1, 0x1444 <_llm_rows.packet_batch.blocks+0xc80>
    149c:      	mov.d	x11, v21[1]
    14a0:      	st1.s	{ v20 }[1], [x11]
    14a4:      	add.2d	v21, v17, v3
    14a8:      	shl.2d	v21, v21, #0x2
    14ac:      	add.2d	v21, v18, v21
    14b0:      	tbz	w10, #0x2, 0x1454 <_llm_rows.packet_batch.blocks+0xc90>
    14b4:      	fmov	x11, d21
    14b8:      	st1.s	{ v20 }[2], [x11]
    14bc:      	tbz	w10, #0x3, 0x1458 <_llm_rows.packet_batch.blocks+0xc94>
    14c0:      	mov.d	x11, v21[1]
    14c4:      	st1.s	{ v20 }[3], [x11]
    14c8:      	add.2d	v20, v17, v4
    14cc:      	and.16b	v19, v0, v19
    14d0:      	fdiv.4s	v19, v19, v7
    14d4:      	shl.2d	v20, v20, #0x2
    14d8:      	add.2d	v20, v18, v20
    14dc:      	tbz	w10, #0x4, 0x1470 <_llm_rows.packet_batch.blocks+0xcac>
    14e0:      	fmov	x11, d20
    14e4:      	str	s19, [x11]
    14e8:      	tbz	w10, #0x5, 0x1474 <_llm_rows.packet_batch.blocks+0xcb0>
    14ec:      	mov.d	x11, v20[1]
    14f0:      	st1.s	{ v19 }[1], [x11]
    14f4:      	add.2d	v17, v17, v2
    14f8:      	shl.2d	v17, v17, #0x2
    14fc:      	add.2d	v17, v18, v17
    1500:      	tbz	w10, #0x6, 0x1484 <_llm_rows.packet_batch.blocks+0xcc0>
    1504:      	fmov	x11, d17
    1508:      	st1.s	{ v19 }[2], [x11]
    150c:      	tbz	w10, #0x7, 0x1404 <_llm_rows.packet_batch.blocks+0xc40>
    1510:      	mov.d	x10, v17[1]
    1514:      	st1.s	{ v19 }[3], [x10]
    1518:      	b	0x1404 <_llm_rows.packet_batch.blocks+0xc40>
    151c:      	add	sp, sp, #0x2, lsl #12   ; =0x2000
    1520:      	add	sp, sp, #0xb50
    1524:      	ldp	x29, x30, [sp, #0x90]
    1528:      	ldp	x20, x19, [sp, #0x80]
    152c:      	ldp	x22, x21, [sp, #0x70]
    1530:      	ldp	x24, x23, [sp, #0x60]
    1534:      	ldp	x26, x25, [sp, #0x50]
    1538:      	ldp	x28, x27, [sp, #0x40]
    153c:      	ldp	d9, d8, [sp, #0x30]
    1540:      	ldp	d11, d10, [sp, #0x20]
    1544:      	ldp	d13, d12, [sp, #0x10]
    1548:      	ldp	d15, d14, [sp], #0xa0
    154c:      	ret

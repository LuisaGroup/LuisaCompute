
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/masked_softmax-17x65/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000700 <_kernel>:
     700:      	sub	sp, sp, #0x140
     704:      	stp	d9, d8, [sp, #0xd0]
     708:      	stp	x28, x27, [sp, #0xe0]
     70c:      	stp	x26, x25, [sp, #0xf0]
     710:      	stp	x24, x23, [sp, #0x100]
     714:      	stp	x22, x21, [sp, #0x110]
     718:      	stp	x20, x19, [sp, #0x120]
     71c:      	stp	x29, x30, [sp, #0x130]
     720:      	add	x29, sp, #0x130
     724:      	str	x3, [sp, #0x48]
     728:      	mov	x20, x2
     72c:      	mov	x21, x1
     730:      	mov	x22, x0
     734:      	stur	wzr, [x29, #-0x88]
     738:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     73c:      	ldr	x9, [x9, #0xa8]
     740:      	sub	x8, x29, #0x88
     744:      	str	x8, [x9]
     748:      	mov	w0, #0x104              ; =260
     74c:      	bl	0x19ac <dyld_stub_binder+0x19ac>
     750:      	mov	x23, x0
     754:      	mov	x25, #0x0               ; =0
     758:      	movi.2d	v0, #0000000000000000
     75c:      	stp	q0, q0, [x0]
     760:      	stp	q0, q0, [x0, #0x20]
     764:      	stp	q0, q0, [x0, #0x40]
     768:      	stp	q0, q0, [x0, #0x60]
     76c:      	stp	q0, q0, [x0, #0x80]
     770:      	stp	q0, q0, [x0, #0xa0]
     774:      	stp	q0, q0, [x0, #0xc0]
     778:      	stp	q0, q0, [x0, #0xe0]
     77c:      	str	wzr, [x0, #0x100]
     780:      	adrp	x8, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xc8>
     784:      	ldr	q0, [x8, #0xbf0]
     788:      	str	q0, [sp, #0x10]
     78c:      	adrp	x8, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xc8>
     790:      	ldr	q0, [x8, #0xc00]
     794:      	str	q0, [sp]
     798:      	mov	w8, #0xf2ca             ; =62154
     79c:      	movk	w8, #0xf149, lsl #16
     7a0:      	dup.4s	v4, w8
     7a4:      	movi.2d	v8, #0000000000000000
     7a8:      	adrp	x8, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xc8>
     7ac:      	ldr	q0, [x8, #0xbe0]
     7b0:      	str	q0, [sp, #0x80]
     7b4:      	mov	x26, x22
     7b8:      	str	q4, [sp, #0x50]
     7bc:      	mov	x8, #0x0                ; =0
     7c0:      	mov	x9, #0x0                ; =0
     7c4:      	add	x10, x25, x25, lsl #6
     7c8:      	lsl	x28, x10, #2
     7cc:      	add	x24, x22, x28
     7d0:      	dup.2d	v6, x25
     7d4:      	mvni.4s	v0, #0x7f, msl #16
     7d8:      	cmp	x8, #0x100
     7dc:      	b.eq	0xa0c <_kernel+0x30c>
     7e0:      	ldr	q1, [x26, x8]
     7e4:      	dup.2d	v2, x9
     7e8:      	ldr	q5, [sp, #0x80]
     7ec:      	orr.16b	v2, v2, v5
     7f0:      	orr	x10, x9, #0x2
     7f4:      	dup.2d	v3, x10
     7f8:      	orr.16b	v3, v3, v5
     7fc:      	cmhs.2d	v2, v6, v2
     800:      	cmhs.2d	v3, v6, v3
     804:      	cmeq.2d	v2, v2, #0
     808:      	cmeq.2d	v3, v3, #0
     80c:      	uzp1.4s	v2, v2, v3
     810:      	bit.16b	v1, v4, v2
     814:      	fmax.4s	v0, v0, v1
     818:      	add	x8, x8, #0x10
     81c:      	cmp	x9, #0x3d
     820:      	add	x9, x9, #0x4
     824:      	b.lo	0x7d8 <_kernel+0xd8>
     828:      	mov	w8, #-0x800000          ; =-8388608
     82c:      	fmov	s1, w8
     830:      	mov	x27, #0x0               ; =0
     834:      	mov	x19, #0x0               ; =0
     838:      	ext.16b	v2, v0, v0, #0x8
     83c:      	fmax.4s	v0, v0, v2
     840:      	rev64.4s	v2, v0
     844:      	fmax.4s	v0, v0, v2
     848:      	fcmp	s1, s0
     84c:      	fcsel	s0, s1, s0, gt
     850:      	str	s0, [x21, x25, lsl #2]
     854:      	dup.4s	v0, v0[0]
     858:      	stp	q6, q0, [sp, #0x60]
     85c:      	dup.2d	v0, v6[0]
     860:      	str	q0, [sp, #0x20]
     864:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     868:      	ldr	x8, [x8, #0x80]
     86c:      	ldr	q0, [x8]
     870:      	str	q0, [sp, #0x30]
     874:      	movi.2d	v1, #0000000000000000
     878:      	str	q1, [sp, #0x90]
     87c:      	cmp	x27, #0x100
     880:      	b.eq	0xa18 <_kernel+0x318>
     884:      	ldr	q0, [x26, x27]
     888:      	dup.2d	v1, x19
     88c:      	ldr	q3, [sp, #0x80]
     890:      	orr.16b	v1, v1, v3
     894:      	orr	x8, x19, #0x2
     898:      	dup.2d	v2, x8
     89c:      	orr.16b	v2, v2, v3
     8a0:      	ldr	q3, [sp, #0x60]
     8a4:      	cmhs.2d	v1, v3, v1
     8a8:      	cmhs.2d	v2, v3, v2
     8ac:      	cmeq.2d	v1, v1, #0
     8b0:      	cmeq.2d	v2, v2, #0
     8b4:      	uzp1.4s	v1, v1, v2
     8b8:      	bit.16b	v0, v4, v1
     8bc:      	ldr	q1, [sp, #0x70]
     8c0:      	fsub.4s	v0, v0, v1
     8c4:      	bl	0x18b0 <dyld_stub_binder+0x18b0>
     8c8:      	ldr	q4, [sp, #0x50]
     8cc:      	str	q0, [x23, x27]
     8d0:      	ldr	q1, [sp, #0x90]
     8d4:      	fadd.4s	v1, v1, v0
     8d8:      	add	x27, x27, #0x10
     8dc:      	cmp	x19, #0x3d
     8e0:      	add	x19, x19, #0x4
     8e4:      	b.lo	0x878 <_kernel+0x178>
     8e8:      	dup.2d	v0, v1[1]
     8ec:      	fadd.4s	v0, v1, v0
     8f0:      	faddp.2s	s0, v0
     8f4:      	fadd	s0, s0, s8
     8f8:      	add	x9, x20, x25, lsl #2
     8fc:      	str	s0, [x9]
     900:      	ldr	x8, [sp, #0x48]
     904:      	add	x8, x8, x28
     908:      	dup.4s	v0, v0[0]
     90c:      	ldp	q1, q2, [x23]
     910:      	fdiv.4s	v0, v1, v0
     914:      	str	q0, [x8]
     918:      	ld1r.4s	{ v0 }, [x9]
     91c:      	fdiv.4s	v0, v2, v0
     920:      	str	q0, [x8, #0x10]
     924:      	ld1r.4s	{ v0 }, [x9]
     928:      	ldp	q1, q2, [x23, #0x20]
     92c:      	fdiv.4s	v0, v1, v0
     930:      	str	q0, [x8, #0x20]
     934:      	ld1r.4s	{ v0 }, [x9]
     938:      	fdiv.4s	v0, v2, v0
     93c:      	str	q0, [x8, #0x30]
     940:      	ld1r.4s	{ v0 }, [x9]
     944:      	ldp	q1, q2, [x23, #0x40]
     948:      	fdiv.4s	v0, v1, v0
     94c:      	str	q0, [x8, #0x40]
     950:      	ld1r.4s	{ v0 }, [x9]
     954:      	fdiv.4s	v0, v2, v0
     958:      	str	q0, [x8, #0x50]
     95c:      	ld1r.4s	{ v0 }, [x9]
     960:      	ldp	q1, q2, [x23, #0x60]
     964:      	fdiv.4s	v0, v1, v0
     968:      	str	q0, [x8, #0x60]
     96c:      	ld1r.4s	{ v0 }, [x9]
     970:      	fdiv.4s	v0, v2, v0
     974:      	str	q0, [x8, #0x70]
     978:      	ld1r.4s	{ v0 }, [x9]
     97c:      	ldp	q1, q2, [x23, #0x80]
     980:      	fdiv.4s	v0, v1, v0
     984:      	str	q0, [x8, #0x80]
     988:      	ld1r.4s	{ v0 }, [x9]
     98c:      	fdiv.4s	v0, v2, v0
     990:      	str	q0, [x8, #0x90]
     994:      	ld1r.4s	{ v0 }, [x9]
     998:      	ldp	q1, q2, [x23, #0xa0]
     99c:      	fdiv.4s	v0, v1, v0
     9a0:      	str	q0, [x8, #0xa0]
     9a4:      	ld1r.4s	{ v0 }, [x9]
     9a8:      	fdiv.4s	v0, v2, v0
     9ac:      	str	q0, [x8, #0xb0]
     9b0:      	ld1r.4s	{ v0 }, [x9]
     9b4:      	ldp	q1, q2, [x23, #0xc0]
     9b8:      	fdiv.4s	v0, v1, v0
     9bc:      	str	q0, [x8, #0xc0]
     9c0:      	ld1r.4s	{ v0 }, [x9]
     9c4:      	fdiv.4s	v0, v2, v0
     9c8:      	str	q0, [x8, #0xd0]
     9cc:      	ld1r.4s	{ v0 }, [x9]
     9d0:      	ldp	q1, q2, [x23, #0xe0]
     9d4:      	fdiv.4s	v0, v1, v0
     9d8:      	str	q0, [x8, #0xe0]
     9dc:      	ld1r.4s	{ v0 }, [x9]
     9e0:      	fdiv.4s	v0, v2, v0
     9e4:      	str	q0, [x8, #0xf0]
     9e8:      	ldr	s0, [x20, x25, lsl #2]
     9ec:      	ldr	s1, [x23, #0x100]
     9f0:      	fdiv	s0, s1, s0
     9f4:      	str	s0, [x8, #0x100]
     9f8:      	add	x25, x25, #0x1
     9fc:      	add	x26, x26, #0x104
     a00:      	cmp	x25, #0x11
     a04:      	b.ne	0x7bc <_kernel+0xbc>
     a08:      	b	0xa5c <_kernel+0x35c>
     a0c:      	mov	w8, #0xf2ca             ; =62154
     a10:      	movk	w8, #0xf149, lsl #16
     a14:      	b	0x82c <_kernel+0x12c>
     a18:      	ldp	q0, q2, [sp, #0x10]
     a1c:      	cmhi.2d	v0, v2, v0
     a20:      	ldr	q1, [sp]
     a24:      	cmhi.2d	v1, v2, v1
     a28:      	uzp1.4s	v0, v1, v0
     a2c:      	ldr	s1, [x24, #0x100]
     a30:      	bsl.16b	v0, v1, v4
     a34:      	ldr	q1, [sp, #0x70]
     a38:      	fsub.4s	v0, v0, v1
     a3c:      	bl	0x18b0 <dyld_stub_binder+0x18b0>
     a40:      	ldr	q4, [sp, #0x50]
     a44:      	str	s0, [x23, #0x100]
     a48:      	ldr	q1, [sp, #0x90]
     a4c:      	fadd.4s	v0, v1, v0
     a50:      	ldr	q2, [sp, #0x30]
     a54:      	bit.16b	v1, v0, v2
     a58:      	b	0x8e8 <_kernel+0x1e8>
     a5c:      	mov	x0, x23
     a60:      	bl	0x1994 <dyld_stub_binder+0x1994>
     a64:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     a68:      	ldr	x8, [x8, #0xa8]
     a6c:      	str	xzr, [x8]
     a70:      	sub	x8, x29, #0x88
     a74:      	ldapr	w8, [x8]
     a78:      	cbnz	w8, 0xaa0 <_kernel+0x3a0>
     a7c:      	ldp	x29, x30, [sp, #0x130]
     a80:      	ldp	x20, x19, [sp, #0x120]
     a84:      	ldp	x22, x21, [sp, #0x110]
     a88:      	ldp	x24, x23, [sp, #0x100]
     a8c:      	ldp	x26, x25, [sp, #0xf0]
     a90:      	ldp	x28, x27, [sp, #0xe0]
     a94:      	ldp	d9, d8, [sp, #0xd0]
     a98:      	add	sp, sp, #0x140
     a9c:      	ret
     aa0:      	mov	w0, #0x10               ; =16
     aa4:      	bl	0x19c4 <dyld_stub_binder+0x19c4>
     aa8:      	mov	x19, x0
     aac:      	mov	w8, #0x33d              ; =829
     ab0:      	stur	w8, [x29, #-0x84]
     ab4:      	adrp	x0, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xc8>
     ab8:      	add	x0, x0, #0xd24
     abc:      	adrp	x1, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xc8>
     ac0:      	add	x1, x1, #0xdb0
     ac4:      	adrp	x3, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xc8>
     ac8:      	add	x3, x3, #0xddb
     acc:      	adrp	x4, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xc8>
     ad0:      	add	x4, x4, #0xe59
     ad4:      	adrp	x2, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xc8>
     ad8:      	add	x2, x2, #0xdd8
     adc:      	sub	x8, x29, #0x80
     ae0:      	sub	x5, x29, #0x84
     ae4:      	adrp	x7, 0x1000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xc8>
     ae8:      	add	x7, x7, #0xe5b
     aec:      	mov	x6, x2
     af0:      	bl	0xb74 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     af4:      	mov	w21, #0x1               ; =1
     af8:      	sub	x1, x29, #0x80
     afc:      	mov	x0, x19
     b00:      	bl	0x18f8 <dyld_stub_binder+0x18f8>
     b04:      	mov	w21, #0x0               ; =0
     b08:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     b0c:      	ldr	x1, [x1, #0x18]
     b10:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     b14:      	ldr	x2, [x2, #0x8]
     b18:      	mov	x0, x19
     b1c:      	bl	0x19f4 <dyld_stub_binder+0x19f4>
     b20:      	brk	#0x1
     b24:      	mov	x20, x0
     b28:      	ldursb	w8, [x29, #-0x69]
     b2c:      	tbz	w8, #0x1f, 0xb48 <_kernel+0x448>
     b30:      	ldur	x0, [x29, #-0x80]
     b34:      	ldur	x8, [x29, #-0x70]
     b38:      	and	x1, x8, #0x7fffffffffffffff
     b3c:      	bl	0x19a0 <dyld_stub_binder+0x19a0>
     b40:      	tbnz	w21, #0x0, 0xb54 <_kernel+0x454>
     b44:      	b	0xb5c <_kernel+0x45c>
     b48:      	cbnz	w21, 0xb54 <_kernel+0x454>
     b4c:      	b	0xb5c <_kernel+0x45c>
     b50:      	mov	x20, x0
     b54:      	mov	x0, x19
     b58:      	bl	0x19e8 <dyld_stub_binder+0x19e8>
     b5c:      	mov	x0, x20
     b60:      	bl	0x18bc <dyld_stub_binder+0x18bc>

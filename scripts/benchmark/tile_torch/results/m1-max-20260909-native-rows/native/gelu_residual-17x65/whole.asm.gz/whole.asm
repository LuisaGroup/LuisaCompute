
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/gelu_residual-17x65-l1/object/tile_xir_w8_80775_1788919116380952_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x50]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      18:      	sub	sp, sp, #0x120
      1c:      	mov	x9, #0x0                ; =0
      20:      	ldr	x11, [x0]
      24:      	ldr	w8, [x1]
      28:      	ldr	w10, [x1, #0x24]
      2c:      	add	w12, w10, w8, lsl #5
      30:      	ldr	x10, [x0, #0x10]
      34:      	ldr	x8, [x0, #0x30]
      38:      	dup.4s	v0, w12
      3c:      	adrp	x12, 0x0 <ltmp0>
      40:      	ldr	q1, [x12]
      44:      	add.4s	v2, v0, v1
      48:      	adrp	x12, 0x0 <ltmp0>
      4c:      	ldr	q1, [x12]
      50:      	add.4s	v3, v0, v1
      54:      	movi.4s	v1, #0x41
      58:      	umull2.2d	v0, v2, v1
      5c:      	umull2.2d	v1, v3, v1
      60:      	movi.2s	v4, #0x41
      64:      	umull.2d	v2, v2, v4
      68:      	umull.2d	v3, v3, v4
      6c:      	dup.2d	v4, x11
      70:      	add	x11, sp, #0x900
      74:      	dup.2d	v5, x9
      78:      	add.2d	v6, v5, v0
      7c:      	add.2d	v7, v5, v2
      80:      	add.2d	v16, v5, v1
      84:      	add.2d	v5, v5, v3
      88:      	shl.2d	v5, v5, #0x2
      8c:      	shl.2d	v16, v16, #0x2
      90:      	shl.2d	v7, v7, #0x2
      94:      	shl.2d	v6, v6, #0x2
      98:      	add.2d	v6, v4, v6
      9c:      	add.2d	v7, v4, v7
      a0:      	add.2d	v16, v4, v16
      a4:      	add.2d	v5, v4, v5
      a8:      	mov.d	x12, v5[1]
      ac:      	fmov	x13, d5
      b0:      	mov.d	x14, v16[1]
      b4:      	fmov	x15, d16
      b8:      	mov.d	x16, v7[1]
      bc:      	fmov	x17, d7
      c0:      	mov.d	x0, v6[1]
      c4:      	ldr	s5, [x17]
      c8:      	ld1.s	{ v5 }[1], [x16]
      cc:      	fmov	x16, d6
      d0:      	ld1.s	{ v5 }[2], [x16]
      d4:      	ld1.s	{ v5 }[3], [x0]
      d8:      	ldr	s6, [x13]
      dc:      	ld1.s	{ v6 }[1], [x12]
      e0:      	ld1.s	{ v6 }[2], [x15]
      e4:      	ld1.s	{ v6 }[3], [x14]
      e8:      	add	x12, x11, x9, lsl #5
      ec:      	stp	q6, q5, [x12]
      f0:      	add	x9, x9, #0x1
      f4:      	cmp	x9, #0x41
      f8:      	b.ne	0x74 <ltmp0+0x74>
      fc:      	mov	x9, #0x0                ; =0
     100:      	dup.2d	v4, x10
     104:      	add	x10, sp, #0xe0
     108:      	dup.2d	v5, x9
     10c:      	add.2d	v6, v5, v0
     110:      	add.2d	v7, v5, v2
     114:      	add.2d	v16, v5, v1
     118:      	add.2d	v5, v5, v3
     11c:      	shl.2d	v5, v5, #0x2
     120:      	shl.2d	v16, v16, #0x2
     124:      	shl.2d	v7, v7, #0x2
     128:      	shl.2d	v6, v6, #0x2
     12c:      	add.2d	v6, v4, v6
     130:      	add.2d	v7, v4, v7
     134:      	add.2d	v16, v4, v16
     138:      	add.2d	v5, v4, v5
     13c:      	mov.d	x11, v5[1]
     140:      	fmov	x12, d5
     144:      	mov.d	x13, v16[1]
     148:      	fmov	x14, d16
     14c:      	mov.d	x15, v7[1]
     150:      	fmov	x16, d7
     154:      	mov.d	x17, v6[1]
     158:      	ldr	s5, [x16]
     15c:      	ld1.s	{ v5 }[1], [x15]
     160:      	fmov	x15, d6
     164:      	ld1.s	{ v5 }[2], [x15]
     168:      	ld1.s	{ v5 }[3], [x17]
     16c:      	ldr	s6, [x12]
     170:      	ld1.s	{ v6 }[1], [x11]
     174:      	ld1.s	{ v6 }[2], [x14]
     178:      	ld1.s	{ v6 }[3], [x13]
     17c:      	add	x11, x10, x9, lsl #5
     180:      	stp	q6, q5, [x11]
     184:      	add	x9, x9, #0x1
     188:      	cmp	x9, #0x41
     18c:      	b.ne	0x108 <ltmp0+0x108>
     190:      	mov	x9, #0x0                ; =0
     194:      	add	x10, sp, #0x900
     198:      	mov	w11, #0x2713            ; =10003
     19c:      	movk	w11, #0x3d37, lsl #16
     1a0:      	dup.4s	v5, w11
     1a4:      	mov	w11, #0x422a            ; =16938
     1a8:      	movk	w11, #0x3f4c, lsl #16
     1ac:      	dup.4s	v4, w11
     1b0:      	stp	q4, q5, [sp, #0xc0]
     1b4:      	fmov.4s	v7, #1.00000000
     1b8:      	mov	w11, #0x9231            ; =37425
     1bc:      	movk	w11, #0x2f30, lsl #16
     1c0:      	dup.4s	v5, w11
     1c4:      	mov	w11, #0x322b            ; =12843
     1c8:      	movk	w11, #0x32d7, lsl #16
     1cc:      	dup.4s	v4, w11
     1d0:      	stp	q4, q5, [sp, #0xa0]
     1d4:      	mov	w11, #0xef1d            ; =61213
     1d8:      	movk	w11, #0x3638, lsl #16
     1dc:      	dup.4s	v5, w11
     1e0:      	mov	w11, #0xd01             ; =3329
     1e4:      	movk	w11, #0x3950, lsl #16
     1e8:      	dup.4s	v4, w11
     1ec:      	stp	q4, q5, [sp, #0x80]
     1f0:      	mov	w11, #0x8889            ; =34953
     1f4:      	movk	w11, #0x3c08, lsl #16
     1f8:      	dup.4s	v5, w11
     1fc:      	mov	w11, #0xaaab            ; =43691
     200:      	movk	w11, #0x3e2a, lsl #16
     204:      	dup.4s	v22, w11
     208:      	mov	w11, #0x76c7            ; =30407
     20c:      	movk	w11, #0x310f, lsl #16
     210:      	dup.4s	v4, w11
     214:      	stp	q4, q5, [sp, #0x60]
     218:      	mov	w11, #0xf27e            ; =62078
     21c:      	movk	w11, #0x3493, lsl #16
     220:      	dup.4s	v5, w11
     224:      	mov	w11, #0xd01             ; =3329
     228:      	movk	w11, #0x37d0, lsl #16
     22c:      	dup.4s	v4, w11
     230:      	stp	q4, q5, [sp, #0x40]
     234:      	mov	w11, #0xb61             ; =2913
     238:      	movk	w11, #0x3ab6, lsl #16
     23c:      	dup.4s	v5, w11
     240:      	mov	w11, #0xaaab            ; =43691
     244:      	movk	w11, #0x3d2a, lsl #16
     248:      	dup.4s	v4, w11
     24c:      	stp	q4, q5, [sp, #0x20]
     250:      	fmov.4s	v5, #9.00000000
     254:      	mov	w11, #-0x3d300000       ; =-1026555904
     258:      	dup.4s	v4, w11
     25c:      	stp	q4, q5, [sp]
     260:      	mov	w11, #0x42c80000        ; =1120403456
     264:      	dup.4s	v29, w11
     268:      	mov	w11, #0xaa3b            ; =43579
     26c:      	movk	w11, #0x3fb8, lsl #16
     270:      	dup.4s	v30, w11
     274:      	mov	w11, #0x7200            ; =29184
     278:      	movk	w11, #0xbf31, lsl #16
     27c:      	mov	w12, #0xbe8e            ; =48782
     280:      	movk	w12, #0xb5bf, lsl #16
     284:      	mov	w13, #0x2bda            ; =11226
     288:      	movk	w13, #0x3950, lsl #16
     28c:      	mov	w14, #0x96c9            ; =38601
     290:      	movk	w14, #0x3ab6, lsl #16
     294:      	mov	w15, #0x88a6            ; =34982
     298:      	movk	w15, #0x3c08, lsl #16
     29c:      	mov	w16, #0xaa7a            ; =43642
     2a0:      	movk	w16, #0x3d2a, lsl #16
     2a4:      	mvni.4s	v4, #0x7f, msl #16
     2a8:      	fneg.4s	v10, v4
     2ac:      	mvni.4s	v4, #0x3f, msl #16
     2b0:      	fneg.4s	v12, v4
     2b4:      	add	x17, sp, #0xe0
     2b8:      	lsl	x0, x9, #5
     2bc:      	add	x1, x10, x0
     2c0:      	ldp	q13, q14, [x1]
     2c4:      	ldp	q6, q5, [sp, #0xc0]
     2c8:      	fmul.4s	v4, v14, v5
     2cc:      	fmul.4s	v5, v13, v5
     2d0:      	fmul.4s	v5, v13, v5
     2d4:      	fmul.4s	v4, v14, v4
     2d8:      	fmul.4s	v4, v14, v4
     2dc:      	fmul.4s	v5, v13, v5
     2e0:      	fadd.4s	v5, v13, v5
     2e4:      	fadd.4s	v4, v14, v4
     2e8:      	fmul.4s	v31, v4, v6
     2ec:      	fmul.4s	v15, v5, v6
     2f0:      	fabs.4s	v9, v15
     2f4:      	fabs.4s	v8, v31
     2f8:      	fmul.4s	v16, v31, v31
     2fc:      	fmul.4s	v19, v15, v15
     300:      	ldp	q5, q6, [sp, #0xa0]
     304:      	mov.16b	v4, v5
     308:      	fmla.4s	v4, v16, v6
     30c:      	fmla.4s	v5, v19, v6
     310:      	ldr	q17, [sp, #0x90]
     314:      	mov.16b	v6, v17
     318:      	fmla.4s	v6, v16, v4
     31c:      	mov.16b	v4, v17
     320:      	fmla.4s	v4, v19, v5
     324:      	ldr	q17, [sp, #0x80]
     328:      	mov.16b	v5, v17
     32c:      	fmla.4s	v5, v16, v6
     330:      	mov.16b	v6, v17
     334:      	fmla.4s	v6, v19, v4
     338:      	ldp	q23, q17, [sp, #0x60]
     33c:      	mov.16b	v4, v17
     340:      	mov.16b	v20, v22
     344:      	fmla.4s	v4, v16, v5
     348:      	mov.16b	v21, v22
     34c:      	mov.16b	v18, v7
     350:      	mov.16b	v5, v7
     354:      	ldr	q24, [sp, #0x50]
     358:      	mov.16b	v11, v24
     35c:      	fmla.4s	v11, v19, v23
     360:      	fmla.4s	v17, v19, v6
     364:      	mov.16b	v6, v24
     368:      	fmla.4s	v6, v16, v23
     36c:      	ldr	q23, [sp, #0x40]
     370:      	mov.16b	v24, v23
     374:      	fmla.4s	v24, v19, v11
     378:      	mov.16b	v11, v23
     37c:      	fmla.4s	v20, v16, v4
     380:      	fmla.4s	v11, v16, v6
     384:      	ldp	q23, q6, [sp, #0x20]
     388:      	mov.16b	v4, v6
     38c:      	fmla.4s	v4, v19, v24
     390:      	fmla.4s	v6, v16, v11
     394:      	fmla.4s	v21, v19, v17
     398:      	mov.16b	v17, v23
     39c:      	fmla.4s	v17, v19, v4
     3a0:      	mov.16b	v4, v23
     3a4:      	fmla.4s	v4, v16, v6
     3a8:      	movi.4s	v24, #0x3f, lsl #24
     3ac:      	fmla.4s	v24, v19, v17
     3b0:      	movi.4s	v23, #0x3f, lsl #24
     3b4:      	fmla.4s	v23, v16, v4
     3b8:      	ldr	q4, [sp, #0x10]
     3bc:      	fcmge.4s	v11, v4, v8
     3c0:      	fcmge.4s	v6, v4, v9
     3c4:      	and.16b	v17, v6, v9
     3c8:      	fmla.4s	v18, v16, v20
     3cc:      	and.16b	v4, v11, v8
     3d0:      	ldr	q20, [sp]
     3d4:      	fcmge.4s	v27, v4, v20
     3d8:      	fcmge.4s	v25, v17, v20
     3dc:      	fcmge.4s	v28, v29, v4
     3e0:      	fcmge.4s	v26, v29, v17
     3e4:      	mov.16b	v20, v7
     3e8:      	and.16b	v25, v25, v26
     3ec:      	and.16b	v26, v27, v28
     3f0:      	and.16b	v26, v26, v4
     3f4:      	and.16b	v25, v25, v17
     3f8:      	fmul.4s	v27, v25, v30
     3fc:      	fmla.4s	v5, v19, v21
     400:      	fmul.4s	v21, v26, v30
     404:      	movi.4s	v28, #0x4b, lsl #24
     408:      	fadd.4s	v21, v21, v28
     40c:      	fadd.4s	v27, v27, v28
     410:      	movi.4s	v28, #0xcb, lsl #24
     414:      	fadd.4s	v27, v27, v28
     418:      	fadd.4s	v21, v21, v28
     41c:      	fmla.4s	v20, v19, v24
     420:      	fcvtzs.4s	v19, v21
     424:      	fcvtzs.4s	v21, v27
     428:      	scvtf.4s	v24, v21
     42c:      	dup.4s	v27, w11
     430:      	fmul.4s	v28, v24, v27
     434:      	fadd.4s	v25, v25, v28
     438:      	scvtf.4s	v28, v19
     43c:      	fmul.4s	v27, v28, v27
     440:      	fadd.4s	v26, v26, v27
     444:      	dup.4s	v27, w12
     448:      	fmul.4s	v24, v24, v27
     44c:      	fmul.4s	v27, v28, v27
     450:      	fadd.4s	v26, v26, v27
     454:      	mov.16b	v27, v7
     458:      	fadd.4s	v24, v25, v24
     45c:      	fmla.4s	v27, v16, v23
     460:      	dup.4s	v16, w13
     464:      	fmul.4s	v23, v24, v16
     468:      	dup.4s	v25, w14
     46c:      	fmul.4s	v16, v26, v16
     470:      	fadd.4s	v16, v16, v25
     474:      	fadd.4s	v23, v23, v25
     478:      	fmul.4s	v23, v24, v23
     47c:      	dup.4s	v25, w15
     480:      	fmul.4s	v16, v26, v16
     484:      	fadd.4s	v16, v16, v25
     488:      	fadd.4s	v23, v23, v25
     48c:      	fmul.4s	v23, v24, v23
     490:      	dup.4s	v25, w16
     494:      	fmul.4s	v16, v26, v16
     498:      	fadd.4s	v16, v16, v25
     49c:      	fadd.4s	v23, v23, v25
     4a0:      	fmul.4s	v18, v8, v18
     4a4:      	fmul.4s	v23, v24, v23
     4a8:      	fmul.4s	v16, v26, v16
     4ac:      	fadd.4s	v16, v16, v22
     4b0:      	fadd.4s	v23, v23, v22
     4b4:      	fmul.4s	v23, v24, v23
     4b8:      	fmul.4s	v16, v26, v16
     4bc:      	movi.4s	v28, #0x3f, lsl #24
     4c0:      	fadd.4s	v25, v16, v28
     4c4:      	fadd.4s	v23, v23, v28
     4c8:      	fdiv.4s	v16, v18, v27
     4cc:      	fmul.4s	v18, v24, v24
     4d0:      	fmul.4s	v18, v18, v23
     4d4:      	fmul.4s	v23, v26, v26
     4d8:      	fmul.4s	v23, v23, v25
     4dc:      	fmul.4s	v5, v9, v5
     4e0:      	fdiv.4s	v5, v5, v20
     4e4:      	fadd.4s	v20, v26, v23
     4e8:      	fadd.4s	v18, v24, v18
     4ec:      	movi.2d	v25, #0xffffffffffffffff
     4f0:      	add.4s	v21, v21, v25
     4f4:      	sshr.4s	v23, v21, #0x1
     4f8:      	shl.4s	v24, v23, #0x17
     4fc:      	fadd.4s	v18, v18, v7
     500:      	add.4s	v24, v24, v7
     504:      	fmul.4s	v18, v18, v24
     508:      	sub.4s	v21, v21, v23
     50c:      	shl.4s	v21, v21, #0x17
     510:      	add.4s	v21, v21, v7
     514:      	fmul.4s	v18, v18, v21
     518:      	fcmgt.4s	v17, v17, v29
     51c:      	bsl.16b	v17, v10, v18
     520:      	fmov.4s	v18, #0.25000000
     524:      	fdiv.4s	v21, v18, v17
     528:      	fsub.4s	v23, v17, v21
     52c:      	fadd.4s	v17, v17, v21
     530:      	fdiv.4s	v17, v23, v17
     534:      	bsl.16b	v6, v17, v7
     538:      	fcmge.4s	v17, v7, v9
     53c:      	fadd.4s	v20, v20, v7
     540:      	add.4s	v19, v19, v25
     544:      	bif.16b	v5, v6, v17
     548:      	sshr.4s	v6, v19, #0x1
     54c:      	shl.4s	v17, v6, #0x17
     550:      	add.4s	v17, v17, v7
     554:      	fmul.4s	v17, v20, v17
     558:      	sub.4s	v6, v19, v6
     55c:      	shl.4s	v6, v6, #0x17
     560:      	add.4s	v6, v6, v7
     564:      	fmul.4s	v6, v17, v6
     568:      	fcmgt.4s	v4, v4, v29
     56c:      	bsl.16b	v4, v10, v6
     570:      	fdiv.4s	v6, v18, v4
     574:      	fsub.4s	v17, v4, v6
     578:      	fadd.4s	v4, v4, v6
     57c:      	fdiv.4s	v4, v17, v4
     580:      	bif.16b	v4, v7, v11
     584:      	dup.2d	v6, x9
     588:      	fcmge.4s	v17, v7, v8
     58c:      	bit.16b	v4, v16, v17
     590:      	mvni.4s	v19, #0x80, lsl #24
     594:      	bif.16b	v4, v31, v19
     598:      	fcmeq.4s	v16, v31, v31
     59c:      	fadd.4s	v4, v4, v7
     5a0:      	bif.16b	v4, v12, v16
     5a4:      	add.2d	v16, v6, v0
     5a8:      	fmul.4s	v17, v14, v28
     5ac:      	fmul.4s	v18, v13, v28
     5b0:      	bif.16b	v5, v15, v19
     5b4:      	fcmeq.4s	v19, v15, v15
     5b8:      	fadd.4s	v5, v5, v7
     5bc:      	bif.16b	v5, v12, v19
     5c0:      	fmul.4s	v5, v18, v5
     5c4:      	fmul.4s	v4, v17, v4
     5c8:      	add	x0, x17, x0
     5cc:      	ldp	q17, q18, [x0]
     5d0:      	add.2d	v19, v6, v2
     5d4:      	fadd.4s	v4, v18, v4
     5d8:      	add.2d	v18, v6, v1
     5dc:      	add.2d	v6, v6, v3
     5e0:      	shl.2d	v6, v6, #0x2
     5e4:      	shl.2d	v18, v18, #0x2
     5e8:      	fadd.4s	v5, v17, v5
     5ec:      	shl.2d	v17, v19, #0x2
     5f0:      	shl.2d	v16, v16, #0x2
     5f4:      	dup.2d	v19, x8
     5f8:      	add.2d	v16, v19, v16
     5fc:      	add.2d	v17, v19, v17
     600:      	add.2d	v18, v19, v18
     604:      	add.2d	v6, v19, v6
     608:      	mov.d	x0, v6[1]
     60c:      	mov.d	x1, v18[1]
     610:      	fmov	x2, d6
     614:      	fmov	x3, d18
     618:      	mov.d	x4, v17[1]
     61c:      	fmov	x5, d17
     620:      	str	s5, [x2]
     624:      	st1.s	{ v5 }[1], [x0]
     628:      	st1.s	{ v5 }[2], [x3]
     62c:      	st1.s	{ v5 }[3], [x1]
     630:      	mov.d	x0, v16[1]
     634:      	fmov	x1, d16
     638:      	str	s4, [x5]
     63c:      	st1.s	{ v4 }[1], [x4]
     640:      	st1.s	{ v4 }[2], [x1]
     644:      	st1.s	{ v4 }[3], [x0]
     648:      	add	x9, x9, #0x1
     64c:      	cmp	x9, #0x41
     650:      	b.ne	0x2b8 <ltmp0+0x2b8>
     654:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     658:      	add	sp, sp, #0x120
     65c:      	ldp	x28, x27, [sp, #0x40]
     660:      	ldp	d9, d8, [sp, #0x30]
     664:      	ldp	d11, d10, [sp, #0x20]
     668:      	ldp	d13, d12, [sp, #0x10]
     66c:      	ldp	d15, d14, [sp], #0x50
     670:      	ret

0000000000000674 <_llm_rows.packet_batch.blocks>:
     674:      	stp	d15, d14, [sp, #-0xa0]!
     678:      	stp	d13, d12, [sp, #0x10]
     67c:      	stp	d11, d10, [sp, #0x20]
     680:      	stp	d9, d8, [sp, #0x30]
     684:      	stp	x28, x27, [sp, #0x40]
     688:      	stp	x26, x25, [sp, #0x50]
     68c:      	stp	x24, x23, [sp, #0x60]
     690:      	stp	x22, x21, [sp, #0x70]
     694:      	stp	x20, x19, [sp, #0x80]
     698:      	stp	x29, x30, [sp, #0x90]
     69c:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
     6a0:      	sub	sp, sp, #0x190
     6a4:      	str	x0, [sp, #0x58]
     6a8:      	cbz	w3, 0x11e4 <_llm_rows.packet_batch.blocks+0xb70>
     6ac:      	mov	x23, x3
     6b0:      	mov	x20, x2
     6b4:      	mov	w22, #0x0               ; =0
     6b8:      	ldp	w9, w8, [x2, #0x2c]
     6bc:      	stp	w8, w9, [sp, #0x50]
     6c0:      	ldp	w27, w25, [x2]
     6c4:      	add	x26, sp, #0x970
     6c8:      	add	x28, sp, #0x150
     6cc:      	mov	w14, #0x2713            ; =10003
     6d0:      	movk	w14, #0x3d37, lsl #16
     6d4:      	ldp	w24, w19, [x2, #0x8]
     6d8:      	mov	w15, #0x422a            ; =16938
     6dc:      	movk	w15, #0x3f4c, lsl #16
     6e0:      	adrp	x8, 0x0 <ltmp0>
     6e4:      	ldr	q0, [x8]
     6e8:      	str	q0, [sp, #0x40]
     6ec:      	mov	w16, #0x9231            ; =37425
     6f0:      	movk	w16, #0x2f30, lsl #16
     6f4:      	adrp	x8, 0x0 <ltmp0>
     6f8:      	ldr	q0, [x8]
     6fc:      	str	q0, [sp, #0x30]
     700:      	mov	w17, #0x322b            ; =12843
     704:      	movk	w17, #0x32d7, lsl #16
     708:      	adrp	x8, 0x0 <ltmp0>
     70c:      	ldr	q0, [x8]
     710:      	str	q0, [sp, #0x10]
     714:      	mov	w0, #0xef1d             ; =61213
     718:      	movk	w0, #0x3638, lsl #16
     71c:      	mov	w1, #0xd01              ; =3329
     720:      	movk	w1, #0x3950, lsl #16
     724:      	mov	w2, #0x8889             ; =34953
     728:      	movk	w2, #0x3c08, lsl #16
     72c:      	mov	w3, #0xaaab             ; =43691
     730:      	movk	w3, #0x3e2a, lsl #16
     734:      	mov	w4, #0x76c7             ; =30407
     738:      	movk	w4, #0x310f, lsl #16
     73c:      	mov	w5, #0xf27e             ; =62078
     740:      	movk	w5, #0x3493, lsl #16
     744:      	mov	w6, #0xd01              ; =3329
     748:      	movk	w6, #0x37d0, lsl #16
     74c:      	mov	w7, #0xb61              ; =2913
     750:      	movk	w7, #0x3ab6, lsl #16
     754:      	mov	w30, #0xaaab            ; =43691
     758:      	movk	w30, #0x3d2a, lsl #16
     75c:      	mvni.4s	v0, #0x7f, msl #16
     760:      	fneg.4s	v1, v0
     764:      	mvni.4s	v0, #0x3f, msl #16
     768:      	fneg.4s	v0, v0
     76c:      	stp	q0, q1, [sp, #0x110]
     770:      	str	w23, [sp, #0x2c]
     774:      	b	0x7bc <_llm_rows.packet_batch.blocks+0x148>
     778:      	mov	w8, #0x18               ; =24
     77c:      	str	w8, [x20, #0x24]
     780:      	ldr	w23, [sp, #0x2c]
     784:      	add	w8, w27, #0x1
     788:      	ldp	w10, w9, [sp, #0x50]
     78c:      	cmp	w8, w9
     790:      	cset	w8, eq
     794:      	csinc	w27, wzr, w27, eq
     798:      	cinc	w9, w25, eq
     79c:      	cmp	w9, w10
     7a0:      	cset	w10, eq
     7a4:      	ands	w8, w8, w10
     7a8:      	csel	w25, wzr, w9, ne
     7ac:      	add	w24, w24, w8
     7b0:      	add	w22, w22, #0x1
     7b4:      	cmp	w22, w23
     7b8:      	b.eq	0x11e4 <_llm_rows.packet_batch.blocks+0xb70>
     7bc:      	ubfiz	x8, x27, #5, #32
     7c0:      	cmp	x8, x19
     7c4:      	csel	x9, x8, xzr, ls
     7c8:      	subs	x10, x19, x9
     7cc:      	cmp	x10, #0x20
     7d0:      	mov	w11, #0x20              ; =32
     7d4:      	csel	x10, x10, x11, lo
     7d8:      	cmp	x19, x9
     7dc:      	stp	w27, w25, [x20]
     7e0:      	str	w24, [x20, #0x8]
     7e4:      	str	wzr, [x20, #0x24]
     7e8:      	ccmp	x8, x19, #0x2, hi
     7ec:      	csel	x21, x10, xzr, ls
     7f0:      	cmp	x21, #0x20
     7f4:      	b.lo	0x8b0 <_llm_rows.packet_batch.blocks+0x23c>
     7f8:      	ldr	x21, [sp, #0x58]
     7fc:      	mov	x0, x21
     800:      	mov	x1, x20
     804:      	bl	0x804 <_llm_rows.packet_batch.blocks+0x190>
     808:      	mov	w8, #0x8                ; =8
     80c:      	str	w8, [x20, #0x24]
     810:      	mov	x0, x21
     814:      	mov	x1, x20
     818:      	bl	0x818 <_llm_rows.packet_batch.blocks+0x1a4>
     81c:      	mov	w8, #0x10               ; =16
     820:      	str	w8, [x20, #0x24]
     824:      	mov	x0, x21
     828:      	mov	x1, x20
     82c:      	bl	0x82c <_llm_rows.packet_batch.blocks+0x1b8>
     830:      	mov	w8, #0x18               ; =24
     834:      	str	w8, [x20, #0x24]
     838:      	mov	x0, x21
     83c:      	mov	x1, x20
     840:      	bl	0x840 <_llm_rows.packet_batch.blocks+0x1cc>
     844:      	mov	w30, #0xaaab            ; =43691
     848:      	movk	w30, #0x3d2a, lsl #16
     84c:      	mov	w7, #0xb61              ; =2913
     850:      	movk	w7, #0x3ab6, lsl #16
     854:      	mov	w6, #0xd01              ; =3329
     858:      	movk	w6, #0x37d0, lsl #16
     85c:      	mov	w5, #0xf27e             ; =62078
     860:      	movk	w5, #0x3493, lsl #16
     864:      	mov	w4, #0x76c7             ; =30407
     868:      	movk	w4, #0x310f, lsl #16
     86c:      	mov	w3, #0xaaab             ; =43691
     870:      	movk	w3, #0x3e2a, lsl #16
     874:      	mov	w2, #0x8889             ; =34953
     878:      	movk	w2, #0x3c08, lsl #16
     87c:      	mov	w1, #0xd01              ; =3329
     880:      	movk	w1, #0x3950, lsl #16
     884:      	mov	w0, #0xef1d             ; =61213
     888:      	movk	w0, #0x3638, lsl #16
     88c:      	mov	w17, #0x322b            ; =12843
     890:      	movk	w17, #0x32d7, lsl #16
     894:      	mov	w16, #0x9231            ; =37425
     898:      	movk	w16, #0x2f30, lsl #16
     89c:      	mov	w15, #0x422a            ; =16938
     8a0:      	movk	w15, #0x3f4c, lsl #16
     8a4:      	mov	w14, #0x2713            ; =10003
     8a8:      	movk	w14, #0x3d37, lsl #16
     8ac:      	b	0x784 <_llm_rows.packet_batch.blocks+0x110>
     8b0:      	lsr	x23, x21, #3
     8b4:      	cmp	x21, #0x8
     8b8:      	b.lo	0xa3c <_llm_rows.packet_batch.blocks+0x3c8>
     8bc:      	str	wzr, [x20, #0x24]
     8c0:      	ldr	x0, [sp, #0x58]
     8c4:      	mov	x1, x20
     8c8:      	bl	0x8c8 <_llm_rows.packet_batch.blocks+0x254>
     8cc:      	mov	w30, #0xaaab            ; =43691
     8d0:      	movk	w30, #0x3d2a, lsl #16
     8d4:      	mov	w7, #0xb61              ; =2913
     8d8:      	movk	w7, #0x3ab6, lsl #16
     8dc:      	mov	w6, #0xd01              ; =3329
     8e0:      	movk	w6, #0x37d0, lsl #16
     8e4:      	mov	w5, #0xf27e             ; =62078
     8e8:      	movk	w5, #0x3493, lsl #16
     8ec:      	mov	w4, #0x76c7             ; =30407
     8f0:      	movk	w4, #0x310f, lsl #16
     8f4:      	mov	w3, #0xaaab             ; =43691
     8f8:      	movk	w3, #0x3e2a, lsl #16
     8fc:      	mov	w2, #0x8889             ; =34953
     900:      	movk	w2, #0x3c08, lsl #16
     904:      	mov	w1, #0xd01              ; =3329
     908:      	movk	w1, #0x3950, lsl #16
     90c:      	mov	w0, #0xef1d             ; =61213
     910:      	movk	w0, #0x3638, lsl #16
     914:      	mov	w17, #0x322b            ; =12843
     918:      	movk	w17, #0x32d7, lsl #16
     91c:      	mov	w16, #0x9231            ; =37425
     920:      	movk	w16, #0x2f30, lsl #16
     924:      	mov	w15, #0x422a            ; =16938
     928:      	movk	w15, #0x3f4c, lsl #16
     92c:      	mov	w14, #0x2713            ; =10003
     930:      	movk	w14, #0x3d37, lsl #16
     934:      	cmp	x23, #0x1
     938:      	b.eq	0xa3c <_llm_rows.packet_batch.blocks+0x3c8>
     93c:      	mov	w8, #0x8                ; =8
     940:      	str	w8, [x20, #0x24]
     944:      	ldr	x0, [sp, #0x58]
     948:      	mov	x1, x20
     94c:      	bl	0x94c <_llm_rows.packet_batch.blocks+0x2d8>
     950:      	mov	w30, #0xaaab            ; =43691
     954:      	movk	w30, #0x3d2a, lsl #16
     958:      	mov	w7, #0xb61              ; =2913
     95c:      	movk	w7, #0x3ab6, lsl #16
     960:      	mov	w6, #0xd01              ; =3329
     964:      	movk	w6, #0x37d0, lsl #16
     968:      	mov	w5, #0xf27e             ; =62078
     96c:      	movk	w5, #0x3493, lsl #16
     970:      	mov	w4, #0x76c7             ; =30407
     974:      	movk	w4, #0x310f, lsl #16
     978:      	mov	w3, #0xaaab             ; =43691
     97c:      	movk	w3, #0x3e2a, lsl #16
     980:      	mov	w2, #0x8889             ; =34953
     984:      	movk	w2, #0x3c08, lsl #16
     988:      	mov	w1, #0xd01              ; =3329
     98c:      	movk	w1, #0x3950, lsl #16
     990:      	mov	w0, #0xef1d             ; =61213
     994:      	movk	w0, #0x3638, lsl #16
     998:      	mov	w17, #0x322b            ; =12843
     99c:      	movk	w17, #0x32d7, lsl #16
     9a0:      	mov	w16, #0x9231            ; =37425
     9a4:      	movk	w16, #0x2f30, lsl #16
     9a8:      	mov	w15, #0x422a            ; =16938
     9ac:      	movk	w15, #0x3f4c, lsl #16
     9b0:      	mov	w14, #0x2713            ; =10003
     9b4:      	movk	w14, #0x3d37, lsl #16
     9b8:      	cmp	x23, #0x2
     9bc:      	b.eq	0xa3c <_llm_rows.packet_batch.blocks+0x3c8>
     9c0:      	mov	w8, #0x10               ; =16
     9c4:      	str	w8, [x20, #0x24]
     9c8:      	ldr	x0, [sp, #0x58]
     9cc:      	mov	x1, x20
     9d0:      	bl	0x9d0 <_llm_rows.packet_batch.blocks+0x35c>
     9d4:      	mov	w30, #0xaaab            ; =43691
     9d8:      	movk	w30, #0x3d2a, lsl #16
     9dc:      	mov	w7, #0xb61              ; =2913
     9e0:      	movk	w7, #0x3ab6, lsl #16
     9e4:      	mov	w6, #0xd01              ; =3329
     9e8:      	movk	w6, #0x37d0, lsl #16
     9ec:      	mov	w5, #0xf27e             ; =62078
     9f0:      	movk	w5, #0x3493, lsl #16
     9f4:      	mov	w4, #0x76c7             ; =30407
     9f8:      	movk	w4, #0x310f, lsl #16
     9fc:      	mov	w3, #0xaaab             ; =43691
     a00:      	movk	w3, #0x3e2a, lsl #16
     a04:      	mov	w2, #0x8889             ; =34953
     a08:      	movk	w2, #0x3c08, lsl #16
     a0c:      	mov	w1, #0xd01              ; =3329
     a10:      	movk	w1, #0x3950, lsl #16
     a14:      	mov	w0, #0xef1d             ; =61213
     a18:      	movk	w0, #0x3638, lsl #16
     a1c:      	mov	w17, #0x322b            ; =12843
     a20:      	movk	w17, #0x32d7, lsl #16
     a24:      	mov	w16, #0x9231            ; =37425
     a28:      	movk	w16, #0x2f30, lsl #16
     a2c:      	mov	w15, #0x422a            ; =16938
     a30:      	movk	w15, #0x3f4c, lsl #16
     a34:      	mov	w14, #0x2713            ; =10003
     a38:      	movk	w14, #0x3d37, lsl #16
     a3c:      	and	w8, w21, #0x7
     a40:      	mov	w21, #-0x3d300000       ; =-1026555904
     a44:      	cbz	w8, 0x778 <_llm_rows.packet_batch.blocks+0x104>
     a48:      	dup.4s	v0, w8
     a4c:      	ldp	q2, q1, [sp, #0x30]
     a50:      	cmhi.4s	v16, v0, v2
     a54:      	cmhi.4s	v5, v0, v1
     a58:      	uzp1.8h	v2, v5, v16
     a5c:      	umaxv.8h	h0, v2
     a60:      	fmov	w8, s0
     a64:      	tbz	w8, #0x0, 0x778 <_llm_rows.packet_batch.blocks+0x104>
     a68:      	mov	x10, #0x0               ; =0
     a6c:      	ldr	x12, [sp, #0x58]
     a70:      	ldr	x11, [x12]
     a74:      	ldr	x9, [x12, #0x10]
     a78:      	lsl	w8, w23, #3
     a7c:      	orr	w8, w8, w27, lsl #5
     a80:      	dup.4s	v0, w8
     a84:      	ldr	x8, [x12, #0x30]
     a88:      	ldp	q1, q4, [sp, #0x30]
     a8c:      	orr.16b	v3, v0, v4
     a90:      	orr.16b	v0, v0, v1
     a94:      	and.16b	v0, v16, v0
     a98:      	and.16b	v3, v5, v3
     a9c:      	movi.4s	v1, #0x41
     aa0:      	umull2.2d	v17, v0, v1
     aa4:      	umull2.2d	v27, v3, v1
     aa8:      	movi.2s	v1, #0x41
     aac:      	umull.2d	v18, v0, v1
     ab0:      	umull.2d	v1, v3, v1
     ab4:      	ldr	q0, [sp, #0x10]
     ab8:      	and.16b	v0, v2, v0
     abc:      	addv.8h	h0, v0
     ac0:      	dup.2d	v7, x11
     ac4:      	str	q0, [sp, #0x130]
     ac8:      	fmov	w11, s0
     acc:      	b	0xaf0 <_llm_rows.packet_batch.blocks+0x47c>
     ad0:      	add	x12, x26, x10, lsl #5
     ad4:      	ldp	q0, q4, [x12]
     ad8:      	bif.16b	v3, v4, v16
     adc:      	bit.16b	v0, v2, v5
     ae0:      	stp	q0, q3, [x12]
     ae4:      	add	x10, x10, #0x1
     ae8:      	cmp	x10, #0x41
     aec:      	b.eq	0xbdc <_llm_rows.packet_batch.blocks+0x568>
     af0:      	dup.2d	v6, x10
     af4:      	add.2d	v0, v6, v1
     af8:      	shl.2d	v0, v0, #0x2
     afc:      	add.2d	v4, v7, v0
     b00:      	movi.2d	v2, #0000000000000000
     b04:      	movi.2d	v3, #0000000000000000
     b08:      	tbnz	w11, #0x0, 0xb54 <_llm_rows.packet_batch.blocks+0x4e0>
     b0c:      	and	w12, w11, #0xff
     b10:      	tbnz	w12, #0x1, 0xb64 <_llm_rows.packet_batch.blocks+0x4f0>
     b14:      	add.2d	v0, v6, v27
     b18:      	shl.2d	v0, v0, #0x2
     b1c:      	add.2d	v4, v7, v0
     b20:      	tbnz	w12, #0x2, 0xb7c <_llm_rows.packet_batch.blocks+0x508>
     b24:      	tbnz	w12, #0x3, 0xb88 <_llm_rows.packet_batch.blocks+0x514>
     b28:      	add.2d	v0, v6, v18
     b2c:      	shl.2d	v0, v0, #0x2
     b30:      	add.2d	v4, v7, v0
     b34:      	tbnz	w12, #0x4, 0xba0 <_llm_rows.packet_batch.blocks+0x52c>
     b38:      	tbnz	w12, #0x5, 0xbac <_llm_rows.packet_batch.blocks+0x538>
     b3c:      	add.2d	v0, v6, v17
     b40:      	shl.2d	v0, v0, #0x2
     b44:      	add.2d	v4, v7, v0
     b48:      	tbnz	w12, #0x6, 0xbc4 <_llm_rows.packet_batch.blocks+0x550>
     b4c:      	tbz	w12, #0x7, 0xad0 <_llm_rows.packet_batch.blocks+0x45c>
     b50:      	b	0xbd0 <_llm_rows.packet_batch.blocks+0x55c>
     b54:      	fmov	x12, d4
     b58:      	ldr	s2, [x12]
     b5c:      	and	w12, w11, #0xff
     b60:      	tbz	w12, #0x1, 0xb14 <_llm_rows.packet_batch.blocks+0x4a0>
     b64:      	mov.d	x13, v4[1]
     b68:      	ld1.s	{ v2 }[1], [x13]
     b6c:      	add.2d	v0, v6, v27
     b70:      	shl.2d	v0, v0, #0x2
     b74:      	add.2d	v4, v7, v0
     b78:      	tbz	w12, #0x2, 0xb24 <_llm_rows.packet_batch.blocks+0x4b0>
     b7c:      	fmov	x13, d4
     b80:      	ld1.s	{ v2 }[2], [x13]
     b84:      	tbz	w12, #0x3, 0xb28 <_llm_rows.packet_batch.blocks+0x4b4>
     b88:      	mov.d	x13, v4[1]
     b8c:      	ld1.s	{ v2 }[3], [x13]
     b90:      	add.2d	v0, v6, v18
     b94:      	shl.2d	v0, v0, #0x2
     b98:      	add.2d	v4, v7, v0
     b9c:      	tbz	w12, #0x4, 0xb38 <_llm_rows.packet_batch.blocks+0x4c4>
     ba0:      	fmov	x13, d4
     ba4:      	ld1.s	{ v3 }[0], [x13]
     ba8:      	tbz	w12, #0x5, 0xb3c <_llm_rows.packet_batch.blocks+0x4c8>
     bac:      	mov.d	x13, v4[1]
     bb0:      	ld1.s	{ v3 }[1], [x13]
     bb4:      	add.2d	v0, v6, v17
     bb8:      	shl.2d	v0, v0, #0x2
     bbc:      	add.2d	v4, v7, v0
     bc0:      	tbz	w12, #0x6, 0xb4c <_llm_rows.packet_batch.blocks+0x4d8>
     bc4:      	fmov	x13, d4
     bc8:      	ld1.s	{ v3 }[2], [x13]
     bcc:      	tbz	w12, #0x7, 0xad0 <_llm_rows.packet_batch.blocks+0x45c>
     bd0:      	mov.d	x12, v4[1]
     bd4:      	ld1.s	{ v3 }[3], [x12]
     bd8:      	b	0xad0 <_llm_rows.packet_batch.blocks+0x45c>
     bdc:      	mov	x10, #0x0               ; =0
     be0:      	b	0xc04 <_llm_rows.packet_batch.blocks+0x590>
     be4:      	add	x11, x28, x10, lsl #5
     be8:      	ldp	q0, q4, [x11]
     bec:      	bif.16b	v3, v4, v16
     bf0:      	bit.16b	v0, v2, v5
     bf4:      	stp	q0, q3, [x11]
     bf8:      	add	x10, x10, #0x1
     bfc:      	cmp	x10, #0x41
     c00:      	b.eq	0xcfc <_llm_rows.packet_batch.blocks+0x688>
     c04:      	ldr	q0, [sp, #0x130]
     c08:      	fmov	w11, s0
     c0c:      	dup.2d	v6, x10
     c10:      	add.2d	v0, v6, v1
     c14:      	shl.2d	v0, v0, #0x2
     c18:      	dup.2d	v7, x9
     c1c:      	add.2d	v4, v7, v0
     c20:      	movi.2d	v2, #0000000000000000
     c24:      	movi.2d	v3, #0000000000000000
     c28:      	tbnz	w11, #0x0, 0xc74 <_llm_rows.packet_batch.blocks+0x600>
     c2c:      	and	w11, w11, #0xff
     c30:      	tbnz	w11, #0x1, 0xc84 <_llm_rows.packet_batch.blocks+0x610>
     c34:      	add.2d	v0, v6, v27
     c38:      	shl.2d	v0, v0, #0x2
     c3c:      	add.2d	v4, v7, v0
     c40:      	tbnz	w11, #0x2, 0xc9c <_llm_rows.packet_batch.blocks+0x628>
     c44:      	tbnz	w11, #0x3, 0xca8 <_llm_rows.packet_batch.blocks+0x634>
     c48:      	add.2d	v0, v6, v18
     c4c:      	shl.2d	v0, v0, #0x2
     c50:      	add.2d	v4, v7, v0
     c54:      	tbnz	w11, #0x4, 0xcc0 <_llm_rows.packet_batch.blocks+0x64c>
     c58:      	tbnz	w11, #0x5, 0xccc <_llm_rows.packet_batch.blocks+0x658>
     c5c:      	add.2d	v0, v6, v17
     c60:      	shl.2d	v0, v0, #0x2
     c64:      	add.2d	v4, v7, v0
     c68:      	tbnz	w11, #0x6, 0xce4 <_llm_rows.packet_batch.blocks+0x670>
     c6c:      	tbz	w11, #0x7, 0xbe4 <_llm_rows.packet_batch.blocks+0x570>
     c70:      	b	0xcf0 <_llm_rows.packet_batch.blocks+0x67c>
     c74:      	fmov	x12, d4
     c78:      	ldr	s2, [x12]
     c7c:      	and	w11, w11, #0xff
     c80:      	tbz	w11, #0x1, 0xc34 <_llm_rows.packet_batch.blocks+0x5c0>
     c84:      	mov.d	x12, v4[1]
     c88:      	ld1.s	{ v2 }[1], [x12]
     c8c:      	add.2d	v0, v6, v27
     c90:      	shl.2d	v0, v0, #0x2
     c94:      	add.2d	v4, v7, v0
     c98:      	tbz	w11, #0x2, 0xc44 <_llm_rows.packet_batch.blocks+0x5d0>
     c9c:      	fmov	x12, d4
     ca0:      	ld1.s	{ v2 }[2], [x12]
     ca4:      	tbz	w11, #0x3, 0xc48 <_llm_rows.packet_batch.blocks+0x5d4>
     ca8:      	mov.d	x12, v4[1]
     cac:      	ld1.s	{ v2 }[3], [x12]
     cb0:      	add.2d	v0, v6, v18
     cb4:      	shl.2d	v0, v0, #0x2
     cb8:      	add.2d	v4, v7, v0
     cbc:      	tbz	w11, #0x4, 0xc58 <_llm_rows.packet_batch.blocks+0x5e4>
     cc0:      	fmov	x12, d4
     cc4:      	ld1.s	{ v3 }[0], [x12]
     cc8:      	tbz	w11, #0x5, 0xc5c <_llm_rows.packet_batch.blocks+0x5e8>
     ccc:      	mov.d	x12, v4[1]
     cd0:      	ld1.s	{ v3 }[1], [x12]
     cd4:      	add.2d	v0, v6, v17
     cd8:      	shl.2d	v0, v0, #0x2
     cdc:      	add.2d	v4, v7, v0
     ce0:      	tbz	w11, #0x6, 0xc6c <_llm_rows.packet_batch.blocks+0x5f8>
     ce4:      	fmov	x12, d4
     ce8:      	ld1.s	{ v3 }[2], [x12]
     cec:      	tbz	w11, #0x7, 0xbe4 <_llm_rows.packet_batch.blocks+0x570>
     cf0:      	mov.d	x11, v4[1]
     cf4:      	ld1.s	{ v3 }[3], [x11]
     cf8:      	b	0xbe4 <_llm_rows.packet_batch.blocks+0x570>
     cfc:      	stp	q1, q18, [sp, #0x60]
     d00:      	mov	x9, #0x0                ; =0
     d04:      	stp	q5, q16, [sp, #0xa0]
     d08:      	stp	q27, q17, [sp, #0x80]
     d0c:      	b	0xd1c <_llm_rows.packet_batch.blocks+0x6a8>
     d10:      	add	x9, x9, #0x1
     d14:      	cmp	x9, #0x41
     d18:      	b.eq	0x778 <_llm_rows.packet_batch.blocks+0x104>
     d1c:      	lsl	x10, x9, #5
     d20:      	add	x11, x26, x10
     d24:      	ldr	q0, [x11]
     d28:      	and.16b	v3, v5, v0
     d2c:      	dup.4s	v0, w14
     d30:      	str	q0, [sp, #0x100]
     d34:      	fmul.4s	v0, v3, v0
     d38:      	fmul.4s	v0, v3, v0
     d3c:      	fmul.4s	v0, v3, v0
     d40:      	fadd.4s	v0, v3, v0
     d44:      	dup.4s	v1, w15
     d48:      	str	q1, [sp, #0xf0]
     d4c:      	fmul.4s	v0, v0, v1
     d50:      	and.16b	v10, v5, v0
     d54:      	fabs.4s	v22, v10
     d58:      	fmov.4s	v7, #1.00000000
     d5c:      	dup.4s	v1, w16
     d60:      	dup.4s	v20, w17
     d64:      	fmul.4s	v0, v10, v10
     d68:      	mov.16b	v2, v20
     d6c:      	str	q1, [sp, #0xe0]
     d70:      	fmla.4s	v2, v0, v1
     d74:      	dup.4s	v23, w0
     d78:      	mov.16b	v4, v23
     d7c:      	fmla.4s	v4, v0, v2
     d80:      	dup.4s	v24, w1
     d84:      	mov.16b	v2, v24
     d88:      	dup.4s	v25, w2
     d8c:      	fmla.4s	v2, v0, v4
     d90:      	mov.16b	v4, v25
     d94:      	fmla.4s	v4, v0, v2
     d98:      	dup.4s	v16, w3
     d9c:      	mov.16b	v2, v16
     da0:      	fmla.4s	v2, v0, v4
     da4:      	mov.16b	v4, v7
     da8:      	fmla.4s	v4, v0, v2
     dac:      	fmul.4s	v2, v22, v4
     db0:      	dup.4s	v1, w4
     db4:      	dup.4s	v26, w5
     db8:      	mov.16b	v4, v26
     dbc:      	str	q1, [sp, #0xd0]
     dc0:      	fmla.4s	v4, v0, v1
     dc4:      	dup.4s	v28, w6
     dc8:      	mov.16b	v27, v5
     dcc:      	mov.16b	v5, v28
     dd0:      	fmla.4s	v5, v0, v4
     dd4:      	dup.4s	v29, w7
     dd8:      	mov.16b	v4, v29
     ddc:      	fmla.4s	v4, v0, v5
     de0:      	dup.4s	v30, w30
     de4:      	mov.16b	v5, v30
     de8:      	fmla.4s	v5, v0, v4
     dec:      	movi.4s	v4, #0x3f, lsl #24
     df0:      	fmla.4s	v4, v0, v5
     df4:      	mov.16b	v5, v7
     df8:      	fmla.4s	v5, v0, v4
     dfc:      	fdiv.4s	v0, v2, v5
     e00:      	fmov.4s	v31, #9.00000000
     e04:      	fcmge.4s	v4, v31, v22
     e08:      	and.16b	v2, v4, v22
     e0c:      	dup.4s	v9, w21
     e10:      	fcmge.4s	v5, v2, v9
     e14:      	mov	w12, #0x42c80000        ; =1120403456
     e18:      	dup.4s	v17, w12
     e1c:      	fcmge.4s	v6, v17, v2
     e20:      	and.16b	v5, v5, v6
     e24:      	and.16b	v5, v5, v2
     e28:      	mov	w12, #0xaa3b            ; =43579
     e2c:      	movk	w12, #0x3fb8, lsl #16
     e30:      	dup.4s	v11, w12
     e34:      	fmul.4s	v6, v5, v11
     e38:      	movi.4s	v1, #0x4b, lsl #24
     e3c:      	fadd.4s	v6, v6, v1
     e40:      	movi.4s	v1, #0xcb, lsl #24
     e44:      	fadd.4s	v6, v6, v1
     e48:      	fcvtzs.4s	v1, v6
     e4c:      	scvtf.4s	v6, v1
     e50:      	mov	w12, #0x7200            ; =29184
     e54:      	movk	w12, #0xbf31, lsl #16
     e58:      	dup.4s	v12, w12
     e5c:      	fmul.4s	v8, v6, v12
     e60:      	fadd.4s	v5, v5, v8
     e64:      	mov	w12, #0xbe8e            ; =48782
     e68:      	movk	w12, #0xb5bf, lsl #16
     e6c:      	dup.4s	v13, w12
     e70:      	fmul.4s	v6, v6, v13
     e74:      	mov	w12, #0x2bda            ; =11226
     e78:      	movk	w12, #0x3950, lsl #16
     e7c:      	dup.4s	v14, w12
     e80:      	fadd.4s	v5, v5, v6
     e84:      	fmul.4s	v6, v5, v14
     e88:      	mov	w12, #0x96c9            ; =38601
     e8c:      	movk	w12, #0x3ab6, lsl #16
     e90:      	dup.4s	v15, w12
     e94:      	fadd.4s	v6, v6, v15
     e98:      	fmul.4s	v6, v5, v6
     e9c:      	mov	w12, #0x88a6            ; =34982
     ea0:      	movk	w12, #0x3c08, lsl #16
     ea4:      	dup.4s	v8, w12
     ea8:      	fadd.4s	v6, v6, v8
     eac:      	fmul.4s	v18, v5, v6
     eb0:      	mov	w12, #0xaa7a            ; =43642
     eb4:      	movk	w12, #0x3d2a, lsl #16
     eb8:      	dup.4s	v6, w12
     ebc:      	fadd.4s	v18, v18, v6
     ec0:      	fmul.4s	v18, v5, v18
     ec4:      	fadd.4s	v18, v18, v16
     ec8:      	fmul.4s	v18, v5, v18
     ecc:      	movi.4s	v21, #0x3f, lsl #24
     ed0:      	fadd.4s	v18, v18, v21
     ed4:      	fmul.4s	v19, v5, v5
     ed8:      	fmul.4s	v18, v19, v18
     edc:      	fadd.4s	v5, v5, v18
     ee0:      	fadd.4s	v5, v5, v7
     ee4:      	movi.2d	v18, #0xffffffffffffffff
     ee8:      	add.4s	v1, v1, v18
     eec:      	sshr.4s	v18, v1, #0x1
     ef0:      	shl.4s	v19, v18, #0x17
     ef4:      	add.4s	v19, v19, v7
     ef8:      	fmul.4s	v5, v5, v19
     efc:      	sub.4s	v1, v1, v18
     f00:      	shl.4s	v1, v1, #0x17
     f04:      	add.4s	v1, v1, v7
     f08:      	fmul.4s	v1, v5, v1
     f0c:      	fcmgt.4s	v2, v2, v17
     f10:      	ldr	q5, [sp, #0x120]
     f14:      	bit.16b	v1, v5, v2
     f18:      	fmov.4s	v2, #0.25000000
     f1c:      	fdiv.4s	v5, v2, v1
     f20:      	fsub.4s	v18, v1, v5
     f24:      	fadd.4s	v1, v1, v5
     f28:      	fdiv.4s	v1, v18, v1
     f2c:      	bif.16b	v1, v7, v4
     f30:      	ldr	q4, [x11, #0x10]
     f34:      	ldr	q5, [sp, #0x130]
     f38:      	fmov	w11, s5
     f3c:      	fcmge.4s	v5, v7, v22
     f40:      	bif.16b	v0, v1, v5
     f44:      	dup.2d	v22, x9
     f48:      	ldr	q1, [sp, #0x60]
     f4c:      	add.2d	v1, v22, v1
     f50:      	fmul.4s	v3, v3, v21
     f54:      	mvni.4s	v5, #0x80, lsl #24
     f58:      	bif.16b	v0, v10, v5
     f5c:      	fcmeq.4s	v5, v10, v10
     f60:      	fadd.4s	v0, v0, v7
     f64:      	ldr	q18, [sp, #0x110]
     f68:      	bif.16b	v0, v18, v5
     f6c:      	fmul.4s	v0, v3, v0
     f70:      	add	x10, x28, x10
     f74:      	ldp	q5, q3, [x10]
     f78:      	str	q3, [sp, #0xc0]
     f7c:      	and.16b	v5, v27, v5
     f80:      	fadd.4s	v5, v5, v0
     f84:      	shl.2d	v0, v1, #0x2
     f88:      	dup.2d	v10, x8
     f8c:      	add.2d	v0, v10, v0
     f90:      	tbnz	w11, #0x0, 0x1168 <_llm_rows.packet_batch.blocks+0xaf4>
     f94:      	and	w10, w11, #0xff
     f98:      	ldr	q27, [sp, #0x80]
     f9c:      	tbnz	w10, #0x1, 0x117c <_llm_rows.packet_batch.blocks+0xb08>
     fa0:      	add.2d	v0, v22, v27
     fa4:      	shl.2d	v0, v0, #0x2
     fa8:      	add.2d	v0, v10, v0
     fac:      	tbnz	w10, #0x2, 0x1194 <_llm_rows.packet_batch.blocks+0xb20>
     fb0:      	tbz	w10, #0x3, 0xfbc <_llm_rows.packet_batch.blocks+0x948>
     fb4:      	mov.d	x11, v0[1]
     fb8:      	st1.s	{ v5 }[3], [x11]
     fbc:      	ldr	q3, [sp, #0xb0]
     fc0:      	and.16b	v4, v3, v4
     fc4:      	ldp	q1, q0, [sp, #0xf0]
     fc8:      	fmul.4s	v0, v4, v0
     fcc:      	fmul.4s	v0, v4, v0
     fd0:      	fmul.4s	v0, v4, v0
     fd4:      	fadd.4s	v0, v4, v0
     fd8:      	fmul.4s	v0, v0, v1
     fdc:      	and.16b	v18, v3, v0
     fe0:      	fmul.4s	v0, v18, v18
     fe4:      	ldr	q1, [sp, #0xe0]
     fe8:      	fmla.4s	v20, v0, v1
     fec:      	fmla.4s	v23, v0, v20
     ff0:      	fmla.4s	v24, v0, v23
     ff4:      	fmla.4s	v25, v0, v24
     ff8:      	mov.16b	v1, v16
     ffc:      	fmla.4s	v1, v0, v25
    1000:      	mov.16b	v5, v7
    1004:      	fmla.4s	v5, v0, v1
    1008:      	ldr	q1, [sp, #0xd0]
    100c:      	fmla.4s	v26, v0, v1
    1010:      	fmla.4s	v28, v0, v26
    1014:      	fmla.4s	v29, v0, v28
    1018:      	fmla.4s	v30, v0, v29
    101c:      	movi.4s	v1, #0x3f, lsl #24
    1020:      	fmla.4s	v1, v0, v30
    1024:      	mov.16b	v19, v7
    1028:      	fmla.4s	v19, v0, v1
    102c:      	fabs.4s	v0, v18
    1030:      	fmul.4s	v1, v0, v5
    1034:      	fdiv.4s	v1, v1, v19
    1038:      	fcmge.4s	v5, v31, v0
    103c:      	and.16b	v19, v5, v0
    1040:      	fcmge.4s	v20, v19, v9
    1044:      	fcmge.4s	v21, v17, v19
    1048:      	and.16b	v20, v20, v21
    104c:      	and.16b	v20, v20, v19
    1050:      	fmul.4s	v21, v20, v11
    1054:      	movi.4s	v23, #0x4b, lsl #24
    1058:      	fadd.4s	v21, v21, v23
    105c:      	movi.4s	v23, #0xcb, lsl #24
    1060:      	fadd.4s	v21, v21, v23
    1064:      	fcvtzs.4s	v21, v21
    1068:      	scvtf.4s	v23, v21
    106c:      	fmul.4s	v24, v23, v12
    1070:      	fadd.4s	v20, v20, v24
    1074:      	fmul.4s	v23, v23, v13
    1078:      	fadd.4s	v20, v20, v23
    107c:      	fmul.4s	v23, v20, v14
    1080:      	fadd.4s	v23, v23, v15
    1084:      	fmul.4s	v23, v20, v23
    1088:      	fadd.4s	v23, v23, v8
    108c:      	fmul.4s	v23, v20, v23
    1090:      	fadd.4s	v6, v23, v6
    1094:      	fmul.4s	v6, v20, v6
    1098:      	fadd.4s	v6, v6, v16
    109c:      	fmul.4s	v6, v20, v6
    10a0:      	movi.4s	v23, #0x3f, lsl #24
    10a4:      	fadd.4s	v6, v6, v23
    10a8:      	fmul.4s	v16, v20, v20
    10ac:      	fmul.4s	v6, v16, v6
    10b0:      	fadd.4s	v6, v20, v6
    10b4:      	fadd.4s	v6, v6, v7
    10b8:      	movi.2d	v16, #0xffffffffffffffff
    10bc:      	add.4s	v16, v21, v16
    10c0:      	sshr.4s	v20, v16, #0x1
    10c4:      	shl.4s	v21, v20, #0x17
    10c8:      	add.4s	v21, v21, v7
    10cc:      	fmul.4s	v6, v6, v21
    10d0:      	sub.4s	v16, v16, v20
    10d4:      	shl.4s	v16, v16, #0x17
    10d8:      	add.4s	v16, v16, v7
    10dc:      	fmul.4s	v6, v6, v16
    10e0:      	fcmgt.4s	v16, v19, v17
    10e4:      	ldr	q17, [sp, #0x120]
    10e8:      	bit.16b	v6, v17, v16
    10ec:      	fdiv.4s	v2, v2, v6
    10f0:      	fsub.4s	v16, v6, v2
    10f4:      	fadd.4s	v2, v6, v2
    10f8:      	fdiv.4s	v2, v16, v2
    10fc:      	bif.16b	v2, v7, v5
    1100:      	fcmge.4s	v0, v7, v0
    1104:      	bsl.16b	v0, v1, v2
    1108:      	mvni.4s	v1, #0x80, lsl #24
    110c:      	bif.16b	v0, v18, v1
    1110:      	fadd.4s	v0, v0, v7
    1114:      	fcmeq.4s	v1, v18, v18
    1118:      	ldr	q2, [sp, #0x110]
    111c:      	bif.16b	v0, v2, v1
    1120:      	fmul.4s	v1, v4, v23
    1124:      	fmul.4s	v0, v1, v0
    1128:      	ldr	q1, [sp, #0xc0]
    112c:      	and.16b	v1, v3, v1
    1130:      	fadd.4s	v2, v1, v0
    1134:      	ldr	q0, [sp, #0x70]
    1138:      	add.2d	v0, v22, v0
    113c:      	shl.2d	v0, v0, #0x2
    1140:      	add.2d	v0, v10, v0
    1144:      	tbnz	w10, #0x4, 0x11a4 <_llm_rows.packet_batch.blocks+0xb30>
    1148:      	ldp	q17, q5, [sp, #0x90]
    114c:      	tbnz	w10, #0x5, 0x11b4 <_llm_rows.packet_batch.blocks+0xb40>
    1150:      	add.2d	v0, v22, v17
    1154:      	shl.2d	v0, v0, #0x2
    1158:      	add.2d	v0, v10, v0
    115c:      	tbnz	w10, #0x6, 0x11cc <_llm_rows.packet_batch.blocks+0xb58>
    1160:      	tbz	w10, #0x7, 0xd10 <_llm_rows.packet_batch.blocks+0x69c>
    1164:      	b	0x11d8 <_llm_rows.packet_batch.blocks+0xb64>
    1168:      	fmov	x10, d0
    116c:      	str	s5, [x10]
    1170:      	and	w10, w11, #0xff
    1174:      	ldr	q27, [sp, #0x80]
    1178:      	tbz	w10, #0x1, 0xfa0 <_llm_rows.packet_batch.blocks+0x92c>
    117c:      	mov.d	x11, v0[1]
    1180:      	st1.s	{ v5 }[1], [x11]
    1184:      	add.2d	v0, v22, v27
    1188:      	shl.2d	v0, v0, #0x2
    118c:      	add.2d	v0, v10, v0
    1190:      	tbz	w10, #0x2, 0xfb0 <_llm_rows.packet_batch.blocks+0x93c>
    1194:      	fmov	x11, d0
    1198:      	st1.s	{ v5 }[2], [x11]
    119c:      	tbnz	w10, #0x3, 0xfb4 <_llm_rows.packet_batch.blocks+0x940>
    11a0:      	b	0xfbc <_llm_rows.packet_batch.blocks+0x948>
    11a4:      	fmov	x11, d0
    11a8:      	str	s2, [x11]
    11ac:      	ldp	q17, q5, [sp, #0x90]
    11b0:      	tbz	w10, #0x5, 0x1150 <_llm_rows.packet_batch.blocks+0xadc>
    11b4:      	mov.d	x11, v0[1]
    11b8:      	st1.s	{ v2 }[1], [x11]
    11bc:      	add.2d	v0, v22, v17
    11c0:      	shl.2d	v0, v0, #0x2
    11c4:      	add.2d	v0, v10, v0
    11c8:      	tbz	w10, #0x6, 0x1160 <_llm_rows.packet_batch.blocks+0xaec>
    11cc:      	fmov	x11, d0
    11d0:      	st1.s	{ v2 }[2], [x11]
    11d4:      	tbz	w10, #0x7, 0xd10 <_llm_rows.packet_batch.blocks+0x69c>
    11d8:      	mov.d	x10, v0[1]
    11dc:      	st1.s	{ v2 }[3], [x10]
    11e0:      	b	0xd10 <_llm_rows.packet_batch.blocks+0x69c>
    11e4:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    11e8:      	add	sp, sp, #0x190
    11ec:      	ldp	x29, x30, [sp, #0x90]
    11f0:      	ldp	x20, x19, [sp, #0x80]
    11f4:      	ldp	x22, x21, [sp, #0x70]
    11f8:      	ldp	x24, x23, [sp, #0x60]
    11fc:      	ldp	x26, x25, [sp, #0x50]
    1200:      	ldp	x28, x27, [sp, #0x40]
    1204:      	ldp	d9, d8, [sp, #0x30]
    1208:      	ldp	d11, d10, [sp, #0x20]
    120c:      	ldp	d13, d12, [sp, #0x10]
    1210:      	ldp	d15, d14, [sp], #0xa0
    1214:      	ret

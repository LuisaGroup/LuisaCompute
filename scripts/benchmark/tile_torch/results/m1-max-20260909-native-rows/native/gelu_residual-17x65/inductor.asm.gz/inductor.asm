
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/gelu_residual-17x65/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0xc0
     6b4:      	stp	d9, d8, [sp, #0x60]
     6b8:      	stp	x26, x25, [sp, #0x70]
     6bc:      	stp	x24, x23, [sp, #0x80]
     6c0:      	stp	x22, x21, [sp, #0x90]
     6c4:      	stp	x20, x19, [sp, #0xa0]
     6c8:      	stp	x29, x30, [sp, #0xb0]
     6cc:      	add	x29, sp, #0xb0
     6d0:      	mov	x19, x2
     6d4:      	mov	x20, x1
     6d8:      	mov	x21, x0
     6dc:      	str	wzr, [sp, #0x40]
     6e0:      	adrp	x22, 0x4000 <dyld_stub_binder+0x4000>
     6e4:      	ldr	x22, [x22, #0x90]
     6e8:      	add	x8, sp, #0x40
     6ec:      	str	x8, [x22]
     6f0:      	mov	x23, #-0x4              ; =-4
     6f4:      	mov	w8, #0x2713             ; =10003
     6f8:      	movk	w8, #0x3d37, lsl #16
     6fc:      	dup.4s	v1, w8
     700:      	mov	w8, #0x422a             ; =16938
     704:      	movk	w8, #0x3f4c, lsl #16
     708:      	dup.4s	v0, w8
     70c:      	stp	q0, q1, [sp]
     710:      	mov	x24, x2
     714:      	mov	x25, x1
     718:      	mov	x26, x0
     71c:      	cmp	x23, #0x44c
     720:      	b.eq	0x7ac <_kernel+0xfc>
     724:      	ldr	q0, [x26], #0x10
     728:      	ldr	q2, [x25], #0x10
     72c:      	movi.4s	v1, #0x3f, lsl #24
     730:      	fmul.4s	v1, v0, v1
     734:      	stp	q1, q2, [sp, #0x20]
     738:      	fmul.4s	v1, v0, v0
     73c:      	fmul.4s	v1, v0, v1
     740:      	ldr	q2, [sp, #0x10]
     744:      	fmul.4s	v1, v1, v2
     748:      	fadd.4s	v0, v0, v1
     74c:      	ldr	q1, [sp]
     750:      	fmul.4s	v0, v0, v1
     754:      	bl	0x1608 <dyld_stub_binder+0x1608>
     758:      	fmov.4s	v1, #1.00000000
     75c:      	fadd.4s	v0, v0, v1
     760:      	ldp	q2, q1, [sp, #0x20]
     764:      	fmul.4s	v0, v2, v0
     768:      	fadd.4s	v0, v1, v0
     76c:      	str	q0, [x24], #0x10
     770:      	add	x23, x23, #0x4
     774:      	cmp	x23, #0x44d
     778:      	b.lo	0x71c <_kernel+0x6c>
     77c:      	str	xzr, [x22]
     780:      	add	x8, sp, #0x40
     784:      	ldapr	w8, [x8]
     788:      	cbnz	w8, 0x818 <_kernel+0x168>
     78c:      	ldp	x29, x30, [sp, #0xb0]
     790:      	ldp	x20, x19, [sp, #0xa0]
     794:      	ldp	x22, x21, [sp, #0x90]
     798:      	ldp	x24, x23, [sp, #0x80]
     79c:      	ldp	x26, x25, [sp, #0x70]
     7a0:      	ldp	d9, d8, [sp, #0x60]
     7a4:      	add	sp, sp, #0xc0
     7a8:      	ret
     7ac:      	ldr	s8, [x21, #0x1140]
     7b0:      	ldr	s9, [x20, #0x1140]
     7b4:      	fmul	s0, s8, s8
     7b8:      	fmul	s0, s8, s0
     7bc:      	mov	w8, #0x2713             ; =10003
     7c0:      	movk	w8, #0x3d37, lsl #16
     7c4:      	fmov	s1, w8
     7c8:      	fmul	s0, s0, s1
     7cc:      	fadd	s0, s8, s0
     7d0:      	mov	w8, #0x422a             ; =16938
     7d4:      	movk	w8, #0x3f4c, lsl #16
     7d8:      	fmov	s1, w8
     7dc:      	fmul	s1, s0, s1
     7e0:      	movi.2d	v0, #0000000000000000
     7e4:      	mov.s	v0[0], v1[0]
     7e8:      	bl	0x1608 <dyld_stub_binder+0x1608>
     7ec:      	fmov	s1, #0.50000000
     7f0:      	fmul	s1, s8, s1
     7f4:      	fmov	s2, #1.00000000
     7f8:      	fadd	s0, s0, s2
     7fc:      	fmul	s0, s1, s0
     800:      	fadd	s0, s9, s0
     804:      	str	s0, [x19, #0x1140]
     808:      	str	xzr, [x22]
     80c:      	add	x8, sp, #0x40
     810:      	ldapr	w8, [x8]
     814:      	cbz	w8, 0x78c <_kernel+0xdc>
     818:      	mov	w0, #0x10               ; =16
     81c:      	bl	0x1704 <dyld_stub_binder+0x1704>
     820:      	mov	x19, x0
     824:      	mov	w8, #0x33d              ; =829
     828:      	str	w8, [sp, #0x44]
     82c:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x1c>
     830:      	add	x0, x0, #0xa34
     834:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x1c>
     838:      	add	x1, x1, #0xac0
     83c:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x1c>
     840:      	add	x3, x3, #0xaeb
     844:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x1c>
     848:      	add	x4, x4, #0xb69
     84c:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x1c>
     850:      	add	x2, x2, #0xae8
     854:      	add	x8, sp, #0x48
     858:      	add	x5, sp, #0x44
     85c:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x1c>
     860:      	add	x7, x7, #0xb6b
     864:      	mov	x6, x2
     868:      	bl	0x8dc <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     86c:      	mov	w21, #0x1               ; =1
     870:      	add	x1, sp, #0x48
     874:      	mov	x0, x19
     878:      	bl	0x1650 <dyld_stub_binder+0x1650>
     87c:      	mov	w21, #0x0               ; =0
     880:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     884:      	ldr	x1, [x1, #0x18]
     888:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     88c:      	ldr	x2, [x2, #0x8]
     890:      	mov	x0, x19
     894:      	bl	0x1734 <dyld_stub_binder+0x1734>
     898:      	brk	#0x1
     89c:      	mov	x20, x0
     8a0:      	ldrsb	w8, [sp, #0x5f]
     8a4:      	tbz	w8, #0x1f, 0x8c0 <_kernel+0x210>
     8a8:      	ldr	x0, [sp, #0x48]
     8ac:      	ldr	x8, [sp, #0x58]
     8b0:      	and	x1, x8, #0x7fffffffffffffff
     8b4:      	bl	0x16ec <dyld_stub_binder+0x16ec>
     8b8:      	tbnz	w21, #0x0, 0x8cc <_kernel+0x21c>
     8bc:      	b	0x8d4 <_kernel+0x224>
     8c0:      	cbnz	w21, 0x8cc <_kernel+0x21c>
     8c4:      	b	0x8d4 <_kernel+0x224>
     8c8:      	mov	x20, x0
     8cc:      	mov	x0, x19
     8d0:      	bl	0x1728 <dyld_stub_binder+0x1728>
     8d4:      	mov	x0, x20
     8d8:      	bl	0x1614 <dyld_stub_binder+0x1614>


/private/tmp/luisa-native-rows.LuX3yX/capture-v3/swiglu-17x65-l1/object/tile_xir_w8_80765_1788919114588061_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x1848 <ltmp0+0x1848>
       4:      	stp	d15, d14, [sp, #-0xa0]!
       8:      	stp	d13, d12, [sp, #0x10]
       c:      	stp	d11, d10, [sp, #0x20]
      10:      	stp	d9, d8, [sp, #0x30]
      14:      	stp	x28, x27, [sp, #0x40]
      18:      	stp	x26, x25, [sp, #0x50]
      1c:      	stp	x24, x23, [sp, #0x60]
      20:      	stp	x22, x21, [sp, #0x70]
      24:      	stp	x20, x19, [sp, #0x80]
      28:      	stp	x29, x30, [sp, #0x90]
      2c:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      30:      	sub	sp, sp, #0xc0
      34:      	mov	w8, #0x0                ; =0
      38:      	ldp	w9, w10, [x2, #0x2c]
      3c:      	add	x12, sp, #0x8a0
      40:      	mov	w13, #0x42d00000        ; =1120927744
      44:      	dup.4s	v2, w13
      48:      	add	x13, sp, #0x80
      4c:      	mov	w14, #-0x3d380000       ; =-1027080192
      50:      	dup.4s	v3, w14
      54:      	mov	w14, #0xaa3b            ; =43579
      58:      	movk	w14, #0x3fb8, lsl #16
      5c:      	ldp	w19, w20, [x2]
      60:      	movi.4s	v4, #0x4b, lsl #24
      64:      	dup.4s	v5, w14
      68:      	mvni.4s	v6, #0x80, lsl #24
      6c:      	mov	w14, #0x7200            ; =29184
      70:      	movk	w14, #0xbf31, lsl #16
      74:      	dup.4s	v7, w14
      78:      	mov	w14, #0xbe8e            ; =48782
      7c:      	movk	w14, #0xb5bf, lsl #16
      80:      	dup.4s	v16, w14
      84:      	mov	w14, #0x2bda            ; =11226
      88:      	movk	w14, #0x3950, lsl #16
      8c:      	dup.4s	v17, w14
      90:      	mov	w17, #0x96c9            ; =38601
      94:      	movk	w17, #0x3ab6, lsl #16
      98:      	mov	w1, #0x88a6             ; =34982
      9c:      	movk	w1, #0x3c08, lsl #16
      a0:      	ldp	w21, w15, [x2, #0x8]
      a4:      	str	x2, [sp, #0x8]
      a8:      	mov	w2, #0xaaab             ; =43691
      ac:      	movk	w2, #0x3e2a, lsl #16
      b0:      	dup.4s	v18, w17
      b4:      	movi.4s	v19, #0x3f, lsl #24
      b8:      	adrp	x17, 0x0 <ltmp0>
      bc:      	ldr	q0, [x17]
      c0:      	str	q0, [sp, #0x50]
      c4:      	mvni.4s	v0, #0x7f, msl #16
      c8:      	dup.4s	v21, w1
      cc:      	fneg.4s	v22, v0
      d0:      	adrp	x17, 0x0 <ltmp0>
      d4:      	ldr	q0, [x17]
      d8:      	str	q0, [sp, #0x40]
      dc:      	mvni.4s	v0, #0x3f, msl #16
      e0:      	fneg.4s	v24, v0
      e4:      	adrp	x17, 0x0 <ltmp0>
      e8:      	mov	w1, #-0x3d300000        ; =-1026555904
      ec:      	mov	w4, #0x42c80000         ; =1120403456
      f0:      	fmov.4s	v27, #1.00000000
      f4:      	b	0x12c <ltmp0+0x12c>
      f8:      	add	w11, w7, #0x1
      fc:      	cmp	w11, w9
     100:      	cset	w11, eq
     104:      	csinc	w19, wzr, w7, eq
     108:      	cinc	w14, w6, eq
     10c:      	cmp	w14, w10
     110:      	cset	w16, eq
     114:      	ands	w11, w11, w16
     118:      	csel	w20, wzr, w14, ne
     11c:      	add	w21, w5, w11
     120:      	add	w8, w8, #0x1
     124:      	cmp	w8, w3
     128:      	b.eq	0x1804 <ltmp0+0x1804>
     12c:      	mov	x5, x21
     130:      	mov	x6, x20
     134:      	mov	x7, x19
     138:      	ubfiz	x19, x19, #5, #32
     13c:      	cmp	x19, x15
     140:      	csel	x20, x19, xzr, ls
     144:      	subs	x21, x15, x20
     148:      	cmp	x21, #0x20
     14c:      	mov	w11, #0x20              ; =32
     150:      	csel	x21, x21, x11, lo
     154:      	cmp	x15, x20
     158:      	ccmp	x19, x15, #0x2, hi
     15c:      	csel	x20, x21, xzr, ls
     160:      	mov	w11, #0xaa7a            ; =43642
     164:      	movk	w11, #0x3d2a, lsl #16
     168:      	dup.4s	v25, w11
     16c:      	dup.4s	v26, w2
     170:      	cmp	x20, #0x20
     174:      	b.lo	0xee4 <ltmp0+0xee4>
     178:      	mov	x22, #0x0               ; =0
     17c:      	ldr	x23, [x0]
     180:      	ldr	x21, [x0, #0x10]
     184:      	ldr	x20, [x0, #0x30]
     188:      	lsl	w19, w7, #5
     18c:      	dup.4s	v0, w19
     190:      	ldp	q20, q1, [sp, #0x40]
     194:      	orr.16b	v1, v0, v1
     198:      	orr.16b	v0, v0, v20
     19c:      	movi.4s	v20, #0x41
     1a0:      	umull2.2d	v31, v1, v20
     1a4:      	umull2.2d	v8, v0, v20
     1a8:      	movi.2s	v20, #0x41
     1ac:      	umull.2d	v9, v1, v20
     1b0:      	umull.2d	v10, v0, v20
     1b4:      	dup.2d	v28, x23
     1b8:      	dup.2d	v0, x22
     1bc:      	add.2d	v1, v0, v31
     1c0:      	add.2d	v20, v0, v9
     1c4:      	add.2d	v29, v0, v8
     1c8:      	add.2d	v0, v0, v10
     1cc:      	shl.2d	v0, v0, #0x2
     1d0:      	shl.2d	v29, v29, #0x2
     1d4:      	shl.2d	v20, v20, #0x2
     1d8:      	shl.2d	v1, v1, #0x2
     1dc:      	add.2d	v1, v28, v1
     1e0:      	add.2d	v20, v28, v20
     1e4:      	add.2d	v29, v28, v29
     1e8:      	add.2d	v0, v28, v0
     1ec:      	mov.d	x23, v0[1]
     1f0:      	fmov	x24, d0
     1f4:      	mov.d	x25, v29[1]
     1f8:      	fmov	x26, d29
     1fc:      	mov.d	x27, v20[1]
     200:      	fmov	x28, d20
     204:      	mov.d	x30, v1[1]
     208:      	ldr	s0, [x28]
     20c:      	ld1.s	{ v0 }[1], [x27]
     210:      	fmov	x27, d1
     214:      	ld1.s	{ v0 }[2], [x27]
     218:      	ld1.s	{ v0 }[3], [x30]
     21c:      	ldr	s1, [x24]
     220:      	ld1.s	{ v1 }[1], [x23]
     224:      	ld1.s	{ v1 }[2], [x26]
     228:      	ld1.s	{ v1 }[3], [x25]
     22c:      	add	x23, x12, x22, lsl #5
     230:      	stp	q1, q0, [x23]
     234:      	add	x22, x22, #0x1
     238:      	cmp	x22, #0x41
     23c:      	b.ne	0x1b8 <ltmp0+0x1b8>
     240:      	mov	x22, #0x0               ; =0
     244:      	dup.2d	v29, x21
     248:      	dup.2d	v0, x22
     24c:      	add.2d	v1, v0, v31
     250:      	add.2d	v20, v0, v9
     254:      	add.2d	v30, v0, v8
     258:      	add.2d	v0, v0, v10
     25c:      	shl.2d	v0, v0, #0x2
     260:      	shl.2d	v30, v30, #0x2
     264:      	shl.2d	v20, v20, #0x2
     268:      	shl.2d	v1, v1, #0x2
     26c:      	add.2d	v1, v29, v1
     270:      	add.2d	v20, v29, v20
     274:      	add.2d	v30, v29, v30
     278:      	add.2d	v0, v29, v0
     27c:      	mov.d	x21, v0[1]
     280:      	fmov	x23, d0
     284:      	mov.d	x24, v30[1]
     288:      	fmov	x25, d30
     28c:      	mov.d	x26, v20[1]
     290:      	fmov	x27, d20
     294:      	mov.d	x28, v1[1]
     298:      	ldr	s0, [x27]
     29c:      	ld1.s	{ v0 }[1], [x26]
     2a0:      	fmov	x26, d1
     2a4:      	ld1.s	{ v0 }[2], [x26]
     2a8:      	ld1.s	{ v0 }[3], [x28]
     2ac:      	ldr	s1, [x23]
     2b0:      	ld1.s	{ v1 }[1], [x21]
     2b4:      	ld1.s	{ v1 }[2], [x25]
     2b8:      	ld1.s	{ v1 }[3], [x24]
     2bc:      	add	x21, x13, x22, lsl #5
     2c0:      	stp	q1, q0, [x21]
     2c4:      	add	x22, x22, #0x1
     2c8:      	cmp	x22, #0x41
     2cc:      	b.ne	0x248 <ltmp0+0x248>
     2d0:      	mov	x21, #0x0               ; =0
     2d4:      	lsl	x22, x21, #5
     2d8:      	add	x23, x12, x22
     2dc:      	ldp	q11, q30, [x23]
     2e0:      	fneg.4s	v0, v11
     2e4:      	fneg.4s	v1, v30
     2e8:      	fcmge.4s	v20, v2, v30
     2ec:      	fcmge.4s	v12, v2, v11
     2f0:      	fcmge.4s	v13, v30, v3
     2f4:      	fcmge.4s	v14, v11, v3
     2f8:      	and.16b	v12, v12, v14
     2fc:      	and.16b	v20, v20, v13
     300:      	and.16b	v1, v20, v1
     304:      	and.16b	v0, v12, v0
     308:      	fmul.4s	v20, v0, v5
     30c:      	fmul.4s	v12, v1, v5
     310:      	mov.16b	v13, v6
     314:      	bsl.16b	v13, v4, v12
     318:      	mov.16b	v14, v6
     31c:      	bsl.16b	v14, v4, v20
     320:      	fadd.4s	v20, v20, v14
     324:      	fadd.4s	v12, v12, v13
     328:      	fsub.4s	v12, v12, v13
     32c:      	fsub.4s	v20, v20, v14
     330:      	fcvtzs.4s	v20, v20
     334:      	fcvtzs.4s	v12, v12
     338:      	scvtf.4s	v13, v12
     33c:      	scvtf.4s	v14, v20
     340:      	fmul.4s	v15, v13, v7
     344:      	fadd.4s	v1, v1, v15
     348:      	fmul.4s	v15, v14, v7
     34c:      	fadd.4s	v0, v0, v15
     350:      	fmul.4s	v13, v13, v16
     354:      	fmul.4s	v14, v14, v16
     358:      	fadd.4s	v0, v0, v14
     35c:      	fadd.4s	v1, v1, v13
     360:      	fmul.4s	v13, v1, v17
     364:      	fmul.4s	v14, v0, v17
     368:      	fadd.4s	v14, v14, v18
     36c:      	fadd.4s	v13, v13, v18
     370:      	fmul.4s	v13, v1, v13
     374:      	fmul.4s	v14, v0, v14
     378:      	fadd.4s	v14, v14, v21
     37c:      	fadd.4s	v13, v13, v21
     380:      	fmul.4s	v13, v1, v13
     384:      	fmul.4s	v14, v0, v14
     388:      	fadd.4s	v14, v14, v25
     38c:      	fadd.4s	v13, v13, v25
     390:      	fmul.4s	v13, v1, v13
     394:      	fmul.4s	v14, v0, v14
     398:      	fadd.4s	v14, v14, v26
     39c:      	fadd.4s	v13, v13, v26
     3a0:      	fmul.4s	v13, v1, v13
     3a4:      	fmul.4s	v14, v0, v14
     3a8:      	fadd.4s	v14, v14, v19
     3ac:      	fadd.4s	v13, v13, v19
     3b0:      	fmul.4s	v15, v1, v1
     3b4:      	fmul.4s	v13, v15, v13
     3b8:      	fmul.4s	v15, v0, v0
     3bc:      	fmul.4s	v14, v15, v14
     3c0:      	fadd.4s	v0, v0, v14
     3c4:      	fadd.4s	v1, v1, v13
     3c8:      	fadd.4s	v1, v1, v27
     3cc:      	sshr.4s	v13, v20, #0x1
     3d0:      	shl.4s	v14, v13, #0x17
     3d4:      	add.4s	v14, v14, v27
     3d8:      	fadd.4s	v0, v0, v27
     3dc:      	fmul.4s	v14, v0, v14
     3e0:      	sshr.4s	v0, v12, #0x1
     3e4:      	sub.4s	v20, v20, v13
     3e8:      	shl.4s	v13, v0, #0x17
     3ec:      	add.4s	v13, v13, v27
     3f0:      	fmul.4s	v1, v1, v13
     3f4:      	sub.4s	v0, v12, v0
     3f8:      	shl.4s	v0, v0, #0x17
     3fc:      	add.4s	v0, v0, v27
     400:      	fmul.4s	v1, v1, v0
     404:      	dup.2d	v0, x21
     408:      	shl.4s	v20, v20, #0x17
     40c:      	add.4s	v20, v20, v27
     410:      	fmul.4s	v20, v14, v20
     414:      	fcmgt.4s	v12, v30, v2
     418:      	fadd.4s	v1, v1, v27
     41c:      	bit.16b	v1, v27, v12
     420:      	fcmgt.4s	v12, v11, v2
     424:      	fadd.4s	v20, v20, v27
     428:      	bit.16b	v20, v27, v12
     42c:      	fcmgt.4s	v12, v3, v11
     430:      	bit.16b	v20, v22, v12
     434:      	fcmgt.4s	v12, v3, v30
     438:      	bit.16b	v1, v22, v12
     43c:      	fcmeq.4s	v12, v30, v30
     440:      	bif.16b	v1, v24, v12
     444:      	fcmeq.4s	v12, v11, v11
     448:      	bif.16b	v20, v24, v12
     44c:      	add.2d	v12, v0, v10
     450:      	fdiv.4s	v20, v11, v20
     454:      	fdiv.4s	v1, v30, v1
     458:      	add	x22, x13, x22
     45c:      	ldp	q30, q11, [x22]
     460:      	fmul.4s	v20, v30, v20
     464:      	shl.2d	v12, v12, #0x2
     468:      	dup.2d	v30, x20
     46c:      	add.2d	v12, v30, v12
     470:      	mov.d	x22, v12[1]
     474:      	fmov	x23, d12
     478:      	add.2d	v12, v0, v8
     47c:      	shl.2d	v12, v12, #0x2
     480:      	add.2d	v12, v30, v12
     484:      	mov.d	x24, v12[1]
     488:      	fmov	x25, d12
     48c:      	str	s20, [x23]
     490:      	st1.s	{ v20 }[1], [x22]
     494:      	st1.s	{ v20 }[2], [x25]
     498:      	fmul.4s	v1, v11, v1
     49c:      	st1.s	{ v20 }[3], [x24]
     4a0:      	add.2d	v20, v0, v9
     4a4:      	shl.2d	v20, v20, #0x2
     4a8:      	add.2d	v20, v30, v20
     4ac:      	mov.d	x22, v20[1]
     4b0:      	fmov	x23, d20
     4b4:      	add.2d	v0, v0, v31
     4b8:      	shl.2d	v0, v0, #0x2
     4bc:      	add.2d	v0, v30, v0
     4c0:      	mov.d	x24, v0[1]
     4c4:      	fmov	x25, d0
     4c8:      	str	s1, [x23]
     4cc:      	st1.s	{ v1 }[1], [x22]
     4d0:      	st1.s	{ v1 }[2], [x25]
     4d4:      	st1.s	{ v1 }[3], [x24]
     4d8:      	add	x21, x21, #0x1
     4dc:      	cmp	x21, #0x41
     4e0:      	b.ne	0x2d4 <ltmp0+0x2d4>
     4e4:      	mov	x20, #0x0               ; =0
     4e8:      	orr	w21, w19, #0x8
     4ec:      	dup.4s	v0, w21
     4f0:      	ldp	q20, q1, [sp, #0x40]
     4f4:      	orr.16b	v1, v0, v1
     4f8:      	orr.16b	v0, v0, v20
     4fc:      	movi.4s	v20, #0x41
     500:      	umull2.2d	v31, v1, v20
     504:      	umull2.2d	v8, v0, v20
     508:      	movi.2s	v20, #0x41
     50c:      	umull.2d	v9, v1, v20
     510:      	umull.2d	v10, v0, v20
     514:      	dup.2d	v0, x20
     518:      	add.2d	v1, v0, v31
     51c:      	add.2d	v20, v0, v9
     520:      	add.2d	v11, v0, v8
     524:      	add.2d	v0, v0, v10
     528:      	shl.2d	v0, v0, #0x2
     52c:      	shl.2d	v11, v11, #0x2
     530:      	shl.2d	v20, v20, #0x2
     534:      	shl.2d	v1, v1, #0x2
     538:      	add.2d	v1, v28, v1
     53c:      	add.2d	v20, v28, v20
     540:      	add.2d	v11, v28, v11
     544:      	add.2d	v0, v28, v0
     548:      	mov.d	x21, v0[1]
     54c:      	fmov	x22, d0
     550:      	mov.d	x23, v11[1]
     554:      	fmov	x24, d11
     558:      	mov.d	x25, v20[1]
     55c:      	fmov	x26, d20
     560:      	mov.d	x27, v1[1]
     564:      	ldr	s0, [x26]
     568:      	ld1.s	{ v0 }[1], [x25]
     56c:      	fmov	x25, d1
     570:      	ld1.s	{ v0 }[2], [x25]
     574:      	ld1.s	{ v0 }[3], [x27]
     578:      	ldr	s1, [x22]
     57c:      	ld1.s	{ v1 }[1], [x21]
     580:      	ld1.s	{ v1 }[2], [x24]
     584:      	ld1.s	{ v1 }[3], [x23]
     588:      	add	x21, x12, x20, lsl #5
     58c:      	stp	q1, q0, [x21]
     590:      	add	x20, x20, #0x1
     594:      	cmp	x20, #0x41
     598:      	b.ne	0x514 <ltmp0+0x514>
     59c:      	mov	x20, #0x0               ; =0
     5a0:      	dup.2d	v0, x20
     5a4:      	add.2d	v1, v0, v31
     5a8:      	add.2d	v20, v0, v9
     5ac:      	add.2d	v11, v0, v8
     5b0:      	add.2d	v0, v0, v10
     5b4:      	shl.2d	v0, v0, #0x2
     5b8:      	shl.2d	v11, v11, #0x2
     5bc:      	shl.2d	v20, v20, #0x2
     5c0:      	shl.2d	v1, v1, #0x2
     5c4:      	add.2d	v1, v29, v1
     5c8:      	add.2d	v20, v29, v20
     5cc:      	add.2d	v11, v29, v11
     5d0:      	add.2d	v0, v29, v0
     5d4:      	mov.d	x21, v0[1]
     5d8:      	fmov	x22, d0
     5dc:      	mov.d	x23, v11[1]
     5e0:      	fmov	x24, d11
     5e4:      	mov.d	x25, v20[1]
     5e8:      	fmov	x26, d20
     5ec:      	mov.d	x27, v1[1]
     5f0:      	ldr	s0, [x26]
     5f4:      	ld1.s	{ v0 }[1], [x25]
     5f8:      	fmov	x25, d1
     5fc:      	ld1.s	{ v0 }[2], [x25]
     600:      	ld1.s	{ v0 }[3], [x27]
     604:      	ldr	s1, [x22]
     608:      	ld1.s	{ v1 }[1], [x21]
     60c:      	ld1.s	{ v1 }[2], [x24]
     610:      	ld1.s	{ v1 }[3], [x23]
     614:      	add	x21, x13, x20, lsl #5
     618:      	stp	q1, q0, [x21]
     61c:      	add	x20, x20, #0x1
     620:      	cmp	x20, #0x41
     624:      	b.ne	0x5a0 <ltmp0+0x5a0>
     628:      	mov	x20, #0x0               ; =0
     62c:      	lsl	x21, x20, #5
     630:      	add	x22, x12, x21
     634:      	ldp	q12, q11, [x22]
     638:      	fneg.4s	v0, v12
     63c:      	fneg.4s	v1, v11
     640:      	fcmge.4s	v20, v2, v11
     644:      	fcmge.4s	v13, v2, v12
     648:      	fcmge.4s	v14, v11, v3
     64c:      	fcmge.4s	v15, v12, v3
     650:      	and.16b	v13, v13, v15
     654:      	and.16b	v20, v20, v14
     658:      	and.16b	v1, v20, v1
     65c:      	and.16b	v0, v13, v0
     660:      	fmul.4s	v20, v0, v5
     664:      	fmul.4s	v13, v1, v5
     668:      	mov.16b	v14, v6
     66c:      	bsl.16b	v14, v4, v13
     670:      	mov.16b	v15, v6
     674:      	bsl.16b	v15, v4, v20
     678:      	fadd.4s	v20, v20, v15
     67c:      	fadd.4s	v13, v13, v14
     680:      	fsub.4s	v13, v13, v14
     684:      	fsub.4s	v20, v20, v15
     688:      	fcvtzs.4s	v20, v20
     68c:      	fcvtzs.4s	v13, v13
     690:      	scvtf.4s	v14, v13
     694:      	scvtf.4s	v15, v20
     698:      	fmul.4s	v23, v14, v7
     69c:      	fadd.4s	v1, v1, v23
     6a0:      	fmul.4s	v23, v15, v7
     6a4:      	fadd.4s	v0, v0, v23
     6a8:      	fmul.4s	v23, v14, v16
     6ac:      	fmul.4s	v14, v15, v16
     6b0:      	fadd.4s	v0, v0, v14
     6b4:      	fadd.4s	v1, v1, v23
     6b8:      	fmul.4s	v23, v1, v17
     6bc:      	fmul.4s	v14, v0, v17
     6c0:      	fadd.4s	v14, v14, v18
     6c4:      	fadd.4s	v23, v23, v18
     6c8:      	fmul.4s	v23, v1, v23
     6cc:      	fmul.4s	v14, v0, v14
     6d0:      	fadd.4s	v14, v14, v21
     6d4:      	fadd.4s	v23, v23, v21
     6d8:      	fmul.4s	v23, v1, v23
     6dc:      	fmul.4s	v14, v0, v14
     6e0:      	fadd.4s	v14, v14, v25
     6e4:      	fadd.4s	v23, v23, v25
     6e8:      	fmul.4s	v23, v1, v23
     6ec:      	fmul.4s	v14, v0, v14
     6f0:      	fadd.4s	v14, v14, v26
     6f4:      	fadd.4s	v23, v23, v26
     6f8:      	fmul.4s	v23, v1, v23
     6fc:      	fmul.4s	v14, v0, v14
     700:      	fadd.4s	v14, v14, v19
     704:      	fadd.4s	v23, v23, v19
     708:      	fmul.4s	v15, v1, v1
     70c:      	fmul.4s	v23, v15, v23
     710:      	fmul.4s	v15, v0, v0
     714:      	fmul.4s	v14, v15, v14
     718:      	fadd.4s	v0, v0, v14
     71c:      	fadd.4s	v1, v1, v23
     720:      	sshr.4s	v23, v13, #0x1
     724:      	sshr.4s	v14, v20, #0x1
     728:      	fadd.4s	v0, v0, v27
     72c:      	shl.4s	v15, v14, #0x17
     730:      	add.4s	v15, v15, v27
     734:      	fmul.4s	v15, v0, v15
     738:      	shl.4s	v0, v23, #0x17
     73c:      	add.4s	v0, v0, v27
     740:      	fadd.4s	v1, v1, v27
     744:      	fmul.4s	v0, v1, v0
     748:      	sub.4s	v1, v20, v14
     74c:      	sub.4s	v20, v13, v23
     750:      	shl.4s	v20, v20, #0x17
     754:      	add.4s	v20, v20, v27
     758:      	fmul.4s	v20, v0, v20
     75c:      	dup.2d	v0, x20
     760:      	shl.4s	v1, v1, #0x17
     764:      	add.4s	v1, v1, v27
     768:      	fmul.4s	v1, v15, v1
     76c:      	fcmgt.4s	v23, v11, v2
     770:      	fadd.4s	v20, v20, v27
     774:      	bit.16b	v20, v27, v23
     778:      	fcmgt.4s	v23, v12, v2
     77c:      	fadd.4s	v1, v1, v27
     780:      	bit.16b	v1, v27, v23
     784:      	fcmgt.4s	v23, v3, v12
     788:      	bit.16b	v1, v22, v23
     78c:      	fcmgt.4s	v23, v3, v11
     790:      	bit.16b	v20, v22, v23
     794:      	fcmeq.4s	v23, v11, v11
     798:      	bif.16b	v20, v24, v23
     79c:      	fcmeq.4s	v23, v12, v12
     7a0:      	bif.16b	v1, v24, v23
     7a4:      	fdiv.4s	v1, v12, v1
     7a8:      	fdiv.4s	v20, v11, v20
     7ac:      	add	x21, x13, x21
     7b0:      	ldp	q23, q11, [x21]
     7b4:      	fmul.4s	v1, v23, v1
     7b8:      	add.2d	v23, v0, v10
     7bc:      	shl.2d	v23, v23, #0x2
     7c0:      	add.2d	v23, v30, v23
     7c4:      	mov.d	x21, v23[1]
     7c8:      	fmov	x22, d23
     7cc:      	add.2d	v23, v0, v8
     7d0:      	shl.2d	v23, v23, #0x2
     7d4:      	add.2d	v23, v30, v23
     7d8:      	mov.d	x23, v23[1]
     7dc:      	fmov	x24, d23
     7e0:      	str	s1, [x22]
     7e4:      	st1.s	{ v1 }[1], [x21]
     7e8:      	st1.s	{ v1 }[2], [x24]
     7ec:      	fmul.4s	v20, v11, v20
     7f0:      	st1.s	{ v1 }[3], [x23]
     7f4:      	add.2d	v1, v0, v9
     7f8:      	shl.2d	v1, v1, #0x2
     7fc:      	add.2d	v1, v30, v1
     800:      	mov.d	x21, v1[1]
     804:      	fmov	x22, d1
     808:      	add.2d	v0, v0, v31
     80c:      	shl.2d	v0, v0, #0x2
     810:      	add.2d	v0, v30, v0
     814:      	mov.d	x23, v0[1]
     818:      	fmov	x24, d0
     81c:      	str	s20, [x22]
     820:      	st1.s	{ v20 }[1], [x21]
     824:      	st1.s	{ v20 }[2], [x24]
     828:      	st1.s	{ v20 }[3], [x23]
     82c:      	add	x20, x20, #0x1
     830:      	cmp	x20, #0x41
     834:      	b.ne	0x62c <ltmp0+0x62c>
     838:      	mov	x20, #0x0               ; =0
     83c:      	orr	w21, w19, #0x10
     840:      	dup.4s	v0, w21
     844:      	ldp	q20, q1, [sp, #0x40]
     848:      	orr.16b	v1, v0, v1
     84c:      	orr.16b	v0, v0, v20
     850:      	movi.4s	v20, #0x41
     854:      	umull2.2d	v31, v1, v20
     858:      	umull2.2d	v8, v0, v20
     85c:      	movi.2s	v20, #0x41
     860:      	umull.2d	v9, v1, v20
     864:      	umull.2d	v10, v0, v20
     868:      	dup.2d	v0, x20
     86c:      	add.2d	v1, v0, v31
     870:      	add.2d	v20, v0, v9
     874:      	add.2d	v23, v0, v8
     878:      	add.2d	v0, v0, v10
     87c:      	shl.2d	v0, v0, #0x2
     880:      	shl.2d	v23, v23, #0x2
     884:      	shl.2d	v20, v20, #0x2
     888:      	shl.2d	v1, v1, #0x2
     88c:      	add.2d	v1, v28, v1
     890:      	add.2d	v20, v28, v20
     894:      	add.2d	v23, v28, v23
     898:      	add.2d	v0, v28, v0
     89c:      	mov.d	x21, v0[1]
     8a0:      	fmov	x22, d0
     8a4:      	mov.d	x23, v23[1]
     8a8:      	fmov	x24, d23
     8ac:      	mov.d	x25, v20[1]
     8b0:      	fmov	x26, d20
     8b4:      	mov.d	x27, v1[1]
     8b8:      	ldr	s0, [x26]
     8bc:      	ld1.s	{ v0 }[1], [x25]
     8c0:      	fmov	x25, d1
     8c4:      	ld1.s	{ v0 }[2], [x25]
     8c8:      	ld1.s	{ v0 }[3], [x27]
     8cc:      	ldr	s1, [x22]
     8d0:      	ld1.s	{ v1 }[1], [x21]
     8d4:      	ld1.s	{ v1 }[2], [x24]
     8d8:      	ld1.s	{ v1 }[3], [x23]
     8dc:      	add	x21, x12, x20, lsl #5
     8e0:      	stp	q1, q0, [x21]
     8e4:      	add	x20, x20, #0x1
     8e8:      	cmp	x20, #0x41
     8ec:      	b.ne	0x868 <ltmp0+0x868>
     8f0:      	mov	x20, #0x0               ; =0
     8f4:      	dup.2d	v0, x20
     8f8:      	add.2d	v1, v0, v31
     8fc:      	add.2d	v20, v0, v9
     900:      	add.2d	v23, v0, v8
     904:      	add.2d	v0, v0, v10
     908:      	shl.2d	v0, v0, #0x2
     90c:      	shl.2d	v23, v23, #0x2
     910:      	shl.2d	v20, v20, #0x2
     914:      	shl.2d	v1, v1, #0x2
     918:      	add.2d	v1, v29, v1
     91c:      	add.2d	v20, v29, v20
     920:      	add.2d	v23, v29, v23
     924:      	add.2d	v0, v29, v0
     928:      	mov.d	x21, v0[1]
     92c:      	fmov	x22, d0
     930:      	mov.d	x23, v23[1]
     934:      	fmov	x24, d23
     938:      	mov.d	x25, v20[1]
     93c:      	fmov	x26, d20
     940:      	mov.d	x27, v1[1]
     944:      	ldr	s0, [x26]
     948:      	ld1.s	{ v0 }[1], [x25]
     94c:      	fmov	x25, d1
     950:      	ld1.s	{ v0 }[2], [x25]
     954:      	ld1.s	{ v0 }[3], [x27]
     958:      	ldr	s1, [x22]
     95c:      	ld1.s	{ v1 }[1], [x21]
     960:      	ld1.s	{ v1 }[2], [x24]
     964:      	ld1.s	{ v1 }[3], [x23]
     968:      	add	x21, x13, x20, lsl #5
     96c:      	stp	q1, q0, [x21]
     970:      	add	x20, x20, #0x1
     974:      	cmp	x20, #0x41
     978:      	b.ne	0x8f4 <ltmp0+0x8f4>
     97c:      	mov	x20, #0x0               ; =0
     980:      	lsl	x21, x20, #5
     984:      	add	x22, x12, x21
     988:      	ldp	q12, q11, [x22]
     98c:      	fneg.4s	v0, v12
     990:      	fneg.4s	v1, v11
     994:      	fcmge.4s	v20, v2, v11
     998:      	fcmge.4s	v23, v2, v12
     99c:      	fcmge.4s	v13, v11, v3
     9a0:      	fcmge.4s	v14, v12, v3
     9a4:      	and.16b	v23, v23, v14
     9a8:      	and.16b	v20, v20, v13
     9ac:      	and.16b	v1, v20, v1
     9b0:      	and.16b	v0, v23, v0
     9b4:      	fmul.4s	v20, v0, v5
     9b8:      	fmul.4s	v23, v1, v5
     9bc:      	mov.16b	v13, v6
     9c0:      	bsl.16b	v13, v4, v23
     9c4:      	mov.16b	v14, v6
     9c8:      	bsl.16b	v14, v4, v20
     9cc:      	fadd.4s	v20, v20, v14
     9d0:      	fadd.4s	v23, v23, v13
     9d4:      	fsub.4s	v23, v23, v13
     9d8:      	fsub.4s	v20, v20, v14
     9dc:      	fcvtzs.4s	v20, v20
     9e0:      	fcvtzs.4s	v23, v23
     9e4:      	scvtf.4s	v13, v23
     9e8:      	scvtf.4s	v14, v20
     9ec:      	fmul.4s	v15, v13, v7
     9f0:      	fadd.4s	v1, v1, v15
     9f4:      	fmul.4s	v15, v14, v7
     9f8:      	fadd.4s	v0, v0, v15
     9fc:      	fmul.4s	v13, v13, v16
     a00:      	fmul.4s	v14, v14, v16
     a04:      	fadd.4s	v0, v0, v14
     a08:      	fadd.4s	v1, v1, v13
     a0c:      	fmul.4s	v13, v1, v17
     a10:      	fmul.4s	v14, v0, v17
     a14:      	fadd.4s	v14, v14, v18
     a18:      	fadd.4s	v13, v13, v18
     a1c:      	fmul.4s	v13, v1, v13
     a20:      	fmul.4s	v14, v0, v14
     a24:      	fadd.4s	v14, v14, v21
     a28:      	fadd.4s	v13, v13, v21
     a2c:      	fmul.4s	v13, v1, v13
     a30:      	fmul.4s	v14, v0, v14
     a34:      	fadd.4s	v14, v14, v25
     a38:      	fadd.4s	v13, v13, v25
     a3c:      	fmul.4s	v13, v1, v13
     a40:      	fmul.4s	v14, v0, v14
     a44:      	fadd.4s	v14, v14, v26
     a48:      	fadd.4s	v13, v13, v26
     a4c:      	fmul.4s	v13, v1, v13
     a50:      	fmul.4s	v14, v0, v14
     a54:      	fadd.4s	v14, v14, v19
     a58:      	fadd.4s	v13, v13, v19
     a5c:      	fmul.4s	v15, v1, v1
     a60:      	fmul.4s	v13, v15, v13
     a64:      	fmul.4s	v15, v0, v0
     a68:      	fmul.4s	v14, v15, v14
     a6c:      	fadd.4s	v0, v0, v14
     a70:      	fadd.4s	v1, v1, v13
     a74:      	sshr.4s	v13, v23, #0x1
     a78:      	sshr.4s	v14, v20, #0x1
     a7c:      	fadd.4s	v0, v0, v27
     a80:      	shl.4s	v15, v14, #0x17
     a84:      	add.4s	v15, v15, v27
     a88:      	fmul.4s	v15, v0, v15
     a8c:      	shl.4s	v0, v13, #0x17
     a90:      	add.4s	v0, v0, v27
     a94:      	fadd.4s	v1, v1, v27
     a98:      	fmul.4s	v0, v1, v0
     a9c:      	sub.4s	v1, v20, v14
     aa0:      	sub.4s	v20, v23, v13
     aa4:      	shl.4s	v20, v20, #0x17
     aa8:      	add.4s	v20, v20, v27
     aac:      	fmul.4s	v20, v0, v20
     ab0:      	dup.2d	v0, x20
     ab4:      	shl.4s	v1, v1, #0x17
     ab8:      	add.4s	v1, v1, v27
     abc:      	fmul.4s	v1, v15, v1
     ac0:      	fcmgt.4s	v23, v11, v2
     ac4:      	fadd.4s	v20, v20, v27
     ac8:      	bit.16b	v20, v27, v23
     acc:      	fcmgt.4s	v23, v12, v2
     ad0:      	fadd.4s	v1, v1, v27
     ad4:      	bit.16b	v1, v27, v23
     ad8:      	fcmgt.4s	v23, v3, v12
     adc:      	bit.16b	v1, v22, v23
     ae0:      	fcmgt.4s	v23, v3, v11
     ae4:      	bit.16b	v20, v22, v23
     ae8:      	fcmeq.4s	v23, v11, v11
     aec:      	bif.16b	v20, v24, v23
     af0:      	fcmeq.4s	v23, v12, v12
     af4:      	bif.16b	v1, v24, v23
     af8:      	fdiv.4s	v1, v12, v1
     afc:      	fdiv.4s	v20, v11, v20
     b00:      	add	x21, x13, x21
     b04:      	ldp	q23, q11, [x21]
     b08:      	fmul.4s	v1, v23, v1
     b0c:      	add.2d	v23, v0, v10
     b10:      	shl.2d	v23, v23, #0x2
     b14:      	add.2d	v23, v30, v23
     b18:      	mov.d	x21, v23[1]
     b1c:      	fmov	x22, d23
     b20:      	add.2d	v23, v0, v8
     b24:      	shl.2d	v23, v23, #0x2
     b28:      	add.2d	v23, v30, v23
     b2c:      	mov.d	x23, v23[1]
     b30:      	fmov	x24, d23
     b34:      	str	s1, [x22]
     b38:      	st1.s	{ v1 }[1], [x21]
     b3c:      	st1.s	{ v1 }[2], [x24]
     b40:      	fmul.4s	v20, v11, v20
     b44:      	st1.s	{ v1 }[3], [x23]
     b48:      	add.2d	v1, v0, v9
     b4c:      	shl.2d	v1, v1, #0x2
     b50:      	add.2d	v1, v30, v1
     b54:      	mov.d	x21, v1[1]
     b58:      	fmov	x22, d1
     b5c:      	add.2d	v0, v0, v31
     b60:      	shl.2d	v0, v0, #0x2
     b64:      	add.2d	v0, v30, v0
     b68:      	mov.d	x23, v0[1]
     b6c:      	fmov	x24, d0
     b70:      	str	s20, [x22]
     b74:      	st1.s	{ v20 }[1], [x21]
     b78:      	st1.s	{ v20 }[2], [x24]
     b7c:      	st1.s	{ v20 }[3], [x23]
     b80:      	add	x20, x20, #0x1
     b84:      	cmp	x20, #0x41
     b88:      	b.ne	0x980 <ltmp0+0x980>
     b8c:      	mov	x20, #0x0               ; =0
     b90:      	orr	w19, w19, #0x18
     b94:      	dup.4s	v0, w19
     b98:      	ldp	q20, q1, [sp, #0x40]
     b9c:      	orr.16b	v1, v0, v1
     ba0:      	orr.16b	v0, v0, v20
     ba4:      	movi.4s	v20, #0x41
     ba8:      	umull2.2d	v31, v1, v20
     bac:      	umull2.2d	v8, v0, v20
     bb0:      	movi.2s	v20, #0x41
     bb4:      	umull.2d	v9, v1, v20
     bb8:      	umull.2d	v10, v0, v20
     bbc:      	dup.2d	v0, x20
     bc0:      	add.2d	v1, v0, v31
     bc4:      	add.2d	v20, v0, v9
     bc8:      	add.2d	v23, v0, v8
     bcc:      	add.2d	v0, v0, v10
     bd0:      	shl.2d	v0, v0, #0x2
     bd4:      	shl.2d	v23, v23, #0x2
     bd8:      	shl.2d	v20, v20, #0x2
     bdc:      	shl.2d	v1, v1, #0x2
     be0:      	add.2d	v1, v28, v1
     be4:      	add.2d	v20, v28, v20
     be8:      	add.2d	v23, v28, v23
     bec:      	add.2d	v0, v28, v0
     bf0:      	mov.d	x19, v0[1]
     bf4:      	fmov	x21, d0
     bf8:      	mov.d	x22, v23[1]
     bfc:      	fmov	x23, d23
     c00:      	mov.d	x24, v20[1]
     c04:      	fmov	x25, d20
     c08:      	mov.d	x26, v1[1]
     c0c:      	ldr	s0, [x25]
     c10:      	ld1.s	{ v0 }[1], [x24]
     c14:      	fmov	x24, d1
     c18:      	ld1.s	{ v0 }[2], [x24]
     c1c:      	ld1.s	{ v0 }[3], [x26]
     c20:      	ldr	s1, [x21]
     c24:      	ld1.s	{ v1 }[1], [x19]
     c28:      	ld1.s	{ v1 }[2], [x23]
     c2c:      	ld1.s	{ v1 }[3], [x22]
     c30:      	add	x19, x12, x20, lsl #5
     c34:      	stp	q1, q0, [x19]
     c38:      	add	x20, x20, #0x1
     c3c:      	cmp	x20, #0x41
     c40:      	b.ne	0xbbc <ltmp0+0xbbc>
     c44:      	mov	x19, #0x0               ; =0
     c48:      	dup.2d	v0, x19
     c4c:      	add.2d	v1, v0, v31
     c50:      	add.2d	v20, v0, v9
     c54:      	add.2d	v23, v0, v8
     c58:      	add.2d	v0, v0, v10
     c5c:      	shl.2d	v0, v0, #0x2
     c60:      	shl.2d	v23, v23, #0x2
     c64:      	shl.2d	v20, v20, #0x2
     c68:      	shl.2d	v1, v1, #0x2
     c6c:      	add.2d	v1, v29, v1
     c70:      	add.2d	v20, v29, v20
     c74:      	add.2d	v23, v29, v23
     c78:      	add.2d	v0, v29, v0
     c7c:      	mov.d	x20, v0[1]
     c80:      	fmov	x21, d0
     c84:      	mov.d	x22, v23[1]
     c88:      	fmov	x23, d23
     c8c:      	mov.d	x24, v20[1]
     c90:      	fmov	x25, d20
     c94:      	mov.d	x26, v1[1]
     c98:      	ldr	s0, [x25]
     c9c:      	ld1.s	{ v0 }[1], [x24]
     ca0:      	fmov	x24, d1
     ca4:      	ld1.s	{ v0 }[2], [x24]
     ca8:      	ld1.s	{ v0 }[3], [x26]
     cac:      	ldr	s1, [x21]
     cb0:      	ld1.s	{ v1 }[1], [x20]
     cb4:      	ld1.s	{ v1 }[2], [x23]
     cb8:      	ld1.s	{ v1 }[3], [x22]
     cbc:      	add	x20, x13, x19, lsl #5
     cc0:      	stp	q1, q0, [x20]
     cc4:      	add	x19, x19, #0x1
     cc8:      	cmp	x19, #0x41
     ccc:      	b.ne	0xc48 <ltmp0+0xc48>
     cd0:      	mov	x19, #0x0               ; =0
     cd4:      	lsl	x20, x19, #5
     cd8:      	add	x21, x12, x20
     cdc:      	ldp	q29, q28, [x21]
     ce0:      	fneg.4s	v0, v29
     ce4:      	fneg.4s	v1, v28
     ce8:      	fcmge.4s	v20, v2, v28
     cec:      	fcmge.4s	v23, v2, v29
     cf0:      	fcmge.4s	v11, v28, v3
     cf4:      	fcmge.4s	v12, v29, v3
     cf8:      	and.16b	v23, v23, v12
     cfc:      	and.16b	v20, v20, v11
     d00:      	and.16b	v1, v20, v1
     d04:      	and.16b	v0, v23, v0
     d08:      	fmul.4s	v20, v0, v5
     d0c:      	fmul.4s	v23, v1, v5
     d10:      	mov.16b	v11, v6
     d14:      	bsl.16b	v11, v4, v23
     d18:      	mov.16b	v12, v6
     d1c:      	bsl.16b	v12, v4, v20
     d20:      	fadd.4s	v20, v20, v12
     d24:      	fadd.4s	v23, v23, v11
     d28:      	fsub.4s	v23, v23, v11
     d2c:      	fsub.4s	v20, v20, v12
     d30:      	fcvtzs.4s	v20, v20
     d34:      	fcvtzs.4s	v23, v23
     d38:      	scvtf.4s	v11, v23
     d3c:      	scvtf.4s	v12, v20
     d40:      	fmul.4s	v13, v11, v7
     d44:      	fadd.4s	v1, v1, v13
     d48:      	fmul.4s	v13, v12, v7
     d4c:      	fadd.4s	v0, v0, v13
     d50:      	fmul.4s	v11, v11, v16
     d54:      	fmul.4s	v12, v12, v16
     d58:      	fadd.4s	v0, v0, v12
     d5c:      	fadd.4s	v1, v1, v11
     d60:      	fmul.4s	v11, v1, v17
     d64:      	fmul.4s	v12, v0, v17
     d68:      	fadd.4s	v12, v12, v18
     d6c:      	fadd.4s	v11, v11, v18
     d70:      	fmul.4s	v11, v1, v11
     d74:      	fmul.4s	v12, v0, v12
     d78:      	fadd.4s	v12, v12, v21
     d7c:      	fadd.4s	v11, v11, v21
     d80:      	fmul.4s	v11, v1, v11
     d84:      	fmul.4s	v12, v0, v12
     d88:      	fadd.4s	v12, v12, v25
     d8c:      	fadd.4s	v11, v11, v25
     d90:      	fmul.4s	v11, v1, v11
     d94:      	fmul.4s	v12, v0, v12
     d98:      	fadd.4s	v12, v12, v26
     d9c:      	fadd.4s	v11, v11, v26
     da0:      	fmul.4s	v11, v1, v11
     da4:      	fmul.4s	v12, v0, v12
     da8:      	fadd.4s	v12, v12, v19
     dac:      	fadd.4s	v11, v11, v19
     db0:      	fmul.4s	v13, v1, v1
     db4:      	fmul.4s	v11, v13, v11
     db8:      	fmul.4s	v13, v0, v0
     dbc:      	fmul.4s	v12, v13, v12
     dc0:      	fadd.4s	v0, v0, v12
     dc4:      	fadd.4s	v1, v1, v11
     dc8:      	sshr.4s	v11, v23, #0x1
     dcc:      	sshr.4s	v12, v20, #0x1
     dd0:      	fadd.4s	v0, v0, v27
     dd4:      	shl.4s	v13, v12, #0x17
     dd8:      	add.4s	v13, v13, v27
     ddc:      	fmul.4s	v13, v0, v13
     de0:      	shl.4s	v0, v11, #0x17
     de4:      	add.4s	v0, v0, v27
     de8:      	fadd.4s	v1, v1, v27
     dec:      	fmul.4s	v0, v1, v0
     df0:      	sub.4s	v1, v20, v12
     df4:      	sub.4s	v20, v23, v11
     df8:      	shl.4s	v20, v20, #0x17
     dfc:      	add.4s	v20, v20, v27
     e00:      	fmul.4s	v20, v0, v20
     e04:      	dup.2d	v0, x19
     e08:      	shl.4s	v1, v1, #0x17
     e0c:      	add.4s	v1, v1, v27
     e10:      	fmul.4s	v1, v13, v1
     e14:      	fcmgt.4s	v23, v28, v2
     e18:      	fadd.4s	v20, v20, v27
     e1c:      	bit.16b	v20, v27, v23
     e20:      	fcmgt.4s	v23, v29, v2
     e24:      	fadd.4s	v1, v1, v27
     e28:      	bit.16b	v1, v27, v23
     e2c:      	fcmgt.4s	v23, v3, v29
     e30:      	bit.16b	v1, v22, v23
     e34:      	fcmgt.4s	v23, v3, v28
     e38:      	bit.16b	v20, v22, v23
     e3c:      	fcmeq.4s	v23, v28, v28
     e40:      	bif.16b	v20, v24, v23
     e44:      	fcmeq.4s	v23, v29, v29
     e48:      	bif.16b	v1, v24, v23
     e4c:      	fdiv.4s	v1, v29, v1
     e50:      	fdiv.4s	v20, v28, v20
     e54:      	add	x20, x13, x20
     e58:      	ldp	q23, q28, [x20]
     e5c:      	fmul.4s	v1, v23, v1
     e60:      	add.2d	v23, v0, v10
     e64:      	shl.2d	v23, v23, #0x2
     e68:      	add.2d	v23, v30, v23
     e6c:      	mov.d	x20, v23[1]
     e70:      	fmov	x21, d23
     e74:      	add.2d	v23, v0, v8
     e78:      	shl.2d	v23, v23, #0x2
     e7c:      	add.2d	v23, v30, v23
     e80:      	mov.d	x22, v23[1]
     e84:      	fmov	x23, d23
     e88:      	str	s1, [x21]
     e8c:      	st1.s	{ v1 }[1], [x20]
     e90:      	st1.s	{ v1 }[2], [x23]
     e94:      	fmul.4s	v20, v28, v20
     e98:      	st1.s	{ v1 }[3], [x22]
     e9c:      	add.2d	v1, v0, v9
     ea0:      	shl.2d	v1, v1, #0x2
     ea4:      	add.2d	v1, v30, v1
     ea8:      	mov.d	x20, v1[1]
     eac:      	fmov	x21, d1
     eb0:      	add.2d	v0, v0, v31
     eb4:      	shl.2d	v0, v0, #0x2
     eb8:      	add.2d	v0, v30, v0
     ebc:      	mov.d	x22, v0[1]
     ec0:      	fmov	x23, d0
     ec4:      	str	s20, [x21]
     ec8:      	st1.s	{ v20 }[1], [x20]
     ecc:      	st1.s	{ v20 }[2], [x23]
     ed0:      	st1.s	{ v20 }[3], [x22]
     ed4:      	add	x19, x19, #0x1
     ed8:      	cmp	x19, #0x41
     edc:      	b.ne	0xcd4 <ltmp0+0xcd4>
     ee0:      	b	0xf8 <ltmp0+0xf8>
     ee4:      	lsr	x19, x20, #3
     ee8:      	cmp	x20, #0x8
     eec:      	b.lo	0x1270 <ltmp0+0x1270>
     ef0:      	mov	w21, #0x0               ; =0
     ef4:      	ldr	x22, [x0]
     ef8:      	ldr	x23, [x0, #0x10]
     efc:      	lsl	w24, w7, #5
     f00:      	ldr	x25, [x0, #0x30]
     f04:      	mov	x26, #0x0               ; =0
     f08:      	add	w27, w24, w21, lsl #3
     f0c:      	dup.4s	v0, w27
     f10:      	ldp	q20, q1, [sp, #0x40]
     f14:      	orr.16b	v1, v0, v1
     f18:      	orr.16b	v0, v0, v20
     f1c:      	movi.4s	v20, #0x41
     f20:      	umull2.2d	v28, v1, v20
     f24:      	umull2.2d	v29, v0, v20
     f28:      	movi.2s	v20, #0x41
     f2c:      	umull.2d	v30, v1, v20
     f30:      	umull.2d	v31, v0, v20
     f34:      	dup.2d	v0, x26
     f38:      	add.2d	v1, v0, v28
     f3c:      	add.2d	v20, v0, v30
     f40:      	add.2d	v23, v0, v29
     f44:      	add.2d	v0, v0, v31
     f48:      	shl.2d	v0, v0, #0x2
     f4c:      	shl.2d	v23, v23, #0x2
     f50:      	shl.2d	v20, v20, #0x2
     f54:      	shl.2d	v1, v1, #0x2
     f58:      	dup.2d	v8, x22
     f5c:      	add.2d	v1, v8, v1
     f60:      	add.2d	v20, v8, v20
     f64:      	add.2d	v23, v8, v23
     f68:      	add.2d	v0, v8, v0
     f6c:      	mov.d	x27, v0[1]
     f70:      	fmov	x28, d0
     f74:      	mov.d	x30, v23[1]
     f78:      	fmov	x11, d23
     f7c:      	mov.d	x2, v20[1]
     f80:      	fmov	x14, d20
     f84:      	mov.d	x16, v1[1]
     f88:      	ldr	s0, [x14]
     f8c:      	ld1.s	{ v0 }[1], [x2]
     f90:      	fmov	x14, d1
     f94:      	ld1.s	{ v0 }[2], [x14]
     f98:      	ld1.s	{ v0 }[3], [x16]
     f9c:      	ldr	s1, [x28]
     fa0:      	ld1.s	{ v1 }[1], [x27]
     fa4:      	ld1.s	{ v1 }[2], [x11]
     fa8:      	ld1.s	{ v1 }[3], [x30]
     fac:      	add	x11, x12, x26, lsl #5
     fb0:      	stp	q1, q0, [x11]
     fb4:      	add	x26, x26, #0x1
     fb8:      	cmp	x26, #0x41
     fbc:      	b.ne	0xf34 <ltmp0+0xf34>
     fc0:      	mov	x26, #0x0               ; =0
     fc4:      	dup.2d	v0, x26
     fc8:      	add.2d	v1, v0, v28
     fcc:      	add.2d	v20, v0, v30
     fd0:      	add.2d	v23, v0, v29
     fd4:      	add.2d	v0, v0, v31
     fd8:      	shl.2d	v0, v0, #0x2
     fdc:      	shl.2d	v23, v23, #0x2
     fe0:      	shl.2d	v20, v20, #0x2
     fe4:      	shl.2d	v1, v1, #0x2
     fe8:      	dup.2d	v8, x23
     fec:      	add.2d	v1, v8, v1
     ff0:      	add.2d	v20, v8, v20
     ff4:      	add.2d	v23, v8, v23
     ff8:      	add.2d	v0, v8, v0
     ffc:      	mov.d	x11, v0[1]
    1000:      	fmov	x14, d0
    1004:      	mov.d	x16, v23[1]
    1008:      	fmov	x2, d23
    100c:      	mov.d	x27, v20[1]
    1010:      	fmov	x28, d20
    1014:      	mov.d	x30, v1[1]
    1018:      	ldr	s0, [x28]
    101c:      	ld1.s	{ v0 }[1], [x27]
    1020:      	fmov	x27, d1
    1024:      	ld1.s	{ v0 }[2], [x27]
    1028:      	ld1.s	{ v0 }[3], [x30]
    102c:      	ldr	s1, [x14]
    1030:      	ld1.s	{ v1 }[1], [x11]
    1034:      	ld1.s	{ v1 }[2], [x2]
    1038:      	ld1.s	{ v1 }[3], [x16]
    103c:      	add	x11, x13, x26, lsl #5
    1040:      	stp	q1, q0, [x11]
    1044:      	add	x26, x26, #0x1
    1048:      	cmp	x26, #0x41
    104c:      	b.ne	0xfc4 <ltmp0+0xfc4>
    1050:      	mov	x26, #0x0               ; =0
    1054:      	lsl	x27, x26, #5
    1058:      	add	x11, x12, x27
    105c:      	ldp	q9, q8, [x11]
    1060:      	fneg.4s	v0, v9
    1064:      	fneg.4s	v1, v8
    1068:      	fcmge.4s	v20, v2, v8
    106c:      	fcmge.4s	v23, v2, v9
    1070:      	fcmge.4s	v10, v8, v3
    1074:      	fcmge.4s	v11, v9, v3
    1078:      	and.16b	v23, v23, v11
    107c:      	and.16b	v20, v20, v10
    1080:      	and.16b	v1, v20, v1
    1084:      	and.16b	v0, v23, v0
    1088:      	fmul.4s	v20, v0, v5
    108c:      	fmul.4s	v23, v1, v5
    1090:      	mov.16b	v10, v6
    1094:      	bsl.16b	v10, v4, v23
    1098:      	mov.16b	v11, v6
    109c:      	bsl.16b	v11, v4, v20
    10a0:      	fadd.4s	v20, v20, v11
    10a4:      	fadd.4s	v23, v23, v10
    10a8:      	fsub.4s	v23, v23, v10
    10ac:      	fsub.4s	v20, v20, v11
    10b0:      	fcvtzs.4s	v20, v20
    10b4:      	fcvtzs.4s	v23, v23
    10b8:      	scvtf.4s	v10, v23
    10bc:      	scvtf.4s	v11, v20
    10c0:      	fmul.4s	v12, v10, v7
    10c4:      	fadd.4s	v1, v1, v12
    10c8:      	fmul.4s	v12, v11, v7
    10cc:      	fadd.4s	v0, v0, v12
    10d0:      	fmul.4s	v10, v10, v16
    10d4:      	fmul.4s	v11, v11, v16
    10d8:      	fadd.4s	v0, v0, v11
    10dc:      	fadd.4s	v1, v1, v10
    10e0:      	fmul.4s	v10, v1, v17
    10e4:      	fmul.4s	v11, v0, v17
    10e8:      	fadd.4s	v11, v11, v18
    10ec:      	fadd.4s	v10, v10, v18
    10f0:      	fmul.4s	v10, v1, v10
    10f4:      	fmul.4s	v11, v0, v11
    10f8:      	fadd.4s	v11, v11, v21
    10fc:      	fadd.4s	v10, v10, v21
    1100:      	fmul.4s	v10, v1, v10
    1104:      	fmul.4s	v11, v0, v11
    1108:      	fadd.4s	v11, v11, v25
    110c:      	fadd.4s	v10, v10, v25
    1110:      	fmul.4s	v10, v1, v10
    1114:      	fmul.4s	v11, v0, v11
    1118:      	fadd.4s	v11, v11, v26
    111c:      	fadd.4s	v10, v10, v26
    1120:      	fmul.4s	v10, v1, v10
    1124:      	fmul.4s	v11, v0, v11
    1128:      	fadd.4s	v11, v11, v19
    112c:      	fadd.4s	v10, v10, v19
    1130:      	fmul.4s	v12, v1, v1
    1134:      	fmul.4s	v10, v12, v10
    1138:      	fmul.4s	v12, v0, v0
    113c:      	fmul.4s	v11, v12, v11
    1140:      	fadd.4s	v0, v0, v11
    1144:      	fadd.4s	v1, v1, v10
    1148:      	fadd.4s	v1, v1, v27
    114c:      	sshr.4s	v10, v20, #0x1
    1150:      	shl.4s	v11, v10, #0x17
    1154:      	add.4s	v11, v11, v27
    1158:      	fadd.4s	v0, v0, v27
    115c:      	fmul.4s	v0, v0, v11
    1160:      	sshr.4s	v11, v23, #0x1
    1164:      	sub.4s	v20, v20, v10
    1168:      	shl.4s	v10, v11, #0x17
    116c:      	add.4s	v10, v10, v27
    1170:      	fmul.4s	v1, v1, v10
    1174:      	sub.4s	v23, v23, v11
    1178:      	dup.2d	v10, x26
    117c:      	shl.4s	v23, v23, #0x17
    1180:      	add.4s	v23, v23, v27
    1184:      	fmul.4s	v1, v1, v23
    1188:      	add.2d	v23, v10, v28
    118c:      	shl.4s	v20, v20, #0x17
    1190:      	add.4s	v20, v20, v27
    1194:      	fmul.4s	v0, v0, v20
    1198:      	fcmgt.4s	v20, v8, v2
    119c:      	fadd.4s	v1, v1, v27
    11a0:      	bit.16b	v1, v27, v20
    11a4:      	fcmgt.4s	v20, v9, v2
    11a8:      	fadd.4s	v0, v0, v27
    11ac:      	bit.16b	v0, v27, v20
    11b0:      	fcmgt.4s	v20, v3, v9
    11b4:      	bit.16b	v0, v22, v20
    11b8:      	fcmgt.4s	v20, v3, v8
    11bc:      	bit.16b	v1, v22, v20
    11c0:      	fcmeq.4s	v20, v8, v8
    11c4:      	bif.16b	v1, v24, v20
    11c8:      	fcmeq.4s	v20, v9, v9
    11cc:      	bif.16b	v0, v24, v20
    11d0:      	fdiv.4s	v0, v9, v0
    11d4:      	fdiv.4s	v1, v8, v1
    11d8:      	add	x11, x13, x27
    11dc:      	ldp	q20, q8, [x11]
    11e0:      	add.2d	v9, v10, v30
    11e4:      	fmul.4s	v1, v8, v1
    11e8:      	add.2d	v8, v10, v29
    11ec:      	add.2d	v10, v10, v31
    11f0:      	shl.2d	v10, v10, #0x2
    11f4:      	shl.2d	v8, v8, #0x2
    11f8:      	fmul.4s	v0, v20, v0
    11fc:      	shl.2d	v20, v9, #0x2
    1200:      	shl.2d	v23, v23, #0x2
    1204:      	dup.2d	v9, x25
    1208:      	add.2d	v23, v9, v23
    120c:      	add.2d	v20, v9, v20
    1210:      	add.2d	v8, v9, v8
    1214:      	add.2d	v9, v9, v10
    1218:      	mov.d	x11, v9[1]
    121c:      	mov.d	x14, v8[1]
    1220:      	fmov	x16, d9
    1224:      	fmov	x2, d8
    1228:      	mov.d	x27, v20[1]
    122c:      	fmov	x28, d20
    1230:      	str	s0, [x16]
    1234:      	st1.s	{ v0 }[1], [x11]
    1238:      	st1.s	{ v0 }[2], [x2]
    123c:      	st1.s	{ v0 }[3], [x14]
    1240:      	mov.d	x11, v23[1]
    1244:      	fmov	x14, d23
    1248:      	str	s1, [x28]
    124c:      	st1.s	{ v1 }[1], [x27]
    1250:      	st1.s	{ v1 }[2], [x14]
    1254:      	st1.s	{ v1 }[3], [x11]
    1258:      	add	x26, x26, #0x1
    125c:      	cmp	x26, #0x41
    1260:      	b.ne	0x1054 <ltmp0+0x1054>
    1264:      	add	w21, w21, #0x1
    1268:      	cmp	w21, w19
    126c:      	b.ne	0xf04 <ltmp0+0xf04>
    1270:      	and	w20, w20, #0x7
    1274:      	mov	w2, #0xaaab             ; =43691
    1278:      	movk	w2, #0x3e2a, lsl #16
    127c:      	cbz	w20, 0xf8 <ltmp0+0xf8>
    1280:      	dup.4s	v0, w20
    1284:      	ldr	q1, [sp, #0x50]
    1288:      	cmhi.4s	v20, v0, v1
    128c:      	ldr	q1, [sp, #0x40]
    1290:      	cmhi.4s	v9, v0, v1
    1294:      	str	q20, [sp, #0x60]
    1298:      	uzp1.8h	v11, v9, v20
    129c:      	umaxv.8h	h0, v11
    12a0:      	fmov	w11, s0
    12a4:      	tbz	w11, #0x0, 0xf8 <ltmp0+0xf8>
    12a8:      	mov	x21, #0x0               ; =0
    12ac:      	ldr	x22, [x0]
    12b0:      	ldr	x20, [x0, #0x10]
    12b4:      	lsl	w11, w19, #3
    12b8:      	orr	w11, w11, w7, lsl #5
    12bc:      	dup.4s	v0, w11
    12c0:      	ldr	x19, [x0, #0x30]
    12c4:      	ldp	q1, q20, [sp, #0x40]
    12c8:      	orr.16b	v1, v0, v1
    12cc:      	orr.16b	v0, v0, v20
    12d0:      	ldr	q20, [sp, #0x60]
    12d4:      	and.16b	v0, v20, v0
    12d8:      	and.16b	v1, v9, v1
    12dc:      	movi.4s	v20, #0x41
    12e0:      	umull2.2d	v23, v0, v20
    12e4:      	umull2.2d	v10, v1, v20
    12e8:      	movi.2s	v20, #0x41
    12ec:      	umull.2d	v30, v0, v20
    12f0:      	umull.2d	v20, v1, v20
    12f4:      	b	0x131c <ltmp0+0x131c>
    12f8:      	add	x11, x12, x21, lsl #5
    12fc:      	ldp	q0, q1, [x11]
    1300:      	ldr	q28, [sp, #0x60]
    1304:      	bit.16b	v1, v13, v28
    1308:      	bit.16b	v0, v12, v9
    130c:      	stp	q0, q1, [x11]
    1310:      	add	x21, x21, #0x1
    1314:      	cmp	x21, #0x41
    1318:      	b.eq	0x141c <ltmp0+0x141c>
    131c:      	ldr	q0, [x17]
    1320:      	and.16b	v0, v11, v0
    1324:      	addv.8h	h31, v0
    1328:      	fmov	w23, s31
    132c:      	dup.2d	v14, x21
    1330:      	add.2d	v0, v14, v20
    1334:      	shl.2d	v0, v0, #0x2
    1338:      	dup.2d	v15, x22
    133c:      	add.2d	v0, v15, v0
    1340:      	movi.2d	v12, #0000000000000000
    1344:      	movi.2d	v13, #0000000000000000
    1348:      	tbnz	w23, #0x0, 0x1394 <ltmp0+0x1394>
    134c:      	and	w23, w23, #0xff
    1350:      	tbnz	w23, #0x1, 0x13a4 <ltmp0+0x13a4>
    1354:      	add.2d	v0, v14, v10
    1358:      	shl.2d	v0, v0, #0x2
    135c:      	add.2d	v0, v15, v0
    1360:      	tbnz	w23, #0x2, 0x13bc <ltmp0+0x13bc>
    1364:      	tbnz	w23, #0x3, 0x13c8 <ltmp0+0x13c8>
    1368:      	add.2d	v0, v14, v30
    136c:      	shl.2d	v0, v0, #0x2
    1370:      	add.2d	v0, v15, v0
    1374:      	tbnz	w23, #0x4, 0x13e0 <ltmp0+0x13e0>
    1378:      	tbnz	w23, #0x5, 0x13ec <ltmp0+0x13ec>
    137c:      	add.2d	v0, v14, v23
    1380:      	shl.2d	v0, v0, #0x2
    1384:      	add.2d	v0, v15, v0
    1388:      	tbnz	w23, #0x6, 0x1404 <ltmp0+0x1404>
    138c:      	tbz	w23, #0x7, 0x12f8 <ltmp0+0x12f8>
    1390:      	b	0x1410 <ltmp0+0x1410>
    1394:      	fmov	x11, d0
    1398:      	ldr	s12, [x11]
    139c:      	and	w23, w23, #0xff
    13a0:      	tbz	w23, #0x1, 0x1354 <ltmp0+0x1354>
    13a4:      	mov.d	x11, v0[1]
    13a8:      	ld1.s	{ v12 }[1], [x11]
    13ac:      	add.2d	v0, v14, v10
    13b0:      	shl.2d	v0, v0, #0x2
    13b4:      	add.2d	v0, v15, v0
    13b8:      	tbz	w23, #0x2, 0x1364 <ltmp0+0x1364>
    13bc:      	fmov	x11, d0
    13c0:      	ld1.s	{ v12 }[2], [x11]
    13c4:      	tbz	w23, #0x3, 0x1368 <ltmp0+0x1368>
    13c8:      	mov.d	x11, v0[1]
    13cc:      	ld1.s	{ v12 }[3], [x11]
    13d0:      	add.2d	v0, v14, v30
    13d4:      	shl.2d	v0, v0, #0x2
    13d8:      	add.2d	v0, v15, v0
    13dc:      	tbz	w23, #0x4, 0x1378 <ltmp0+0x1378>
    13e0:      	fmov	x11, d0
    13e4:      	ld1.s	{ v13 }[0], [x11]
    13e8:      	tbz	w23, #0x5, 0x137c <ltmp0+0x137c>
    13ec:      	mov.d	x11, v0[1]
    13f0:      	ld1.s	{ v13 }[1], [x11]
    13f4:      	add.2d	v0, v14, v23
    13f8:      	shl.2d	v0, v0, #0x2
    13fc:      	add.2d	v0, v15, v0
    1400:      	tbz	w23, #0x6, 0x138c <ltmp0+0x138c>
    1404:      	fmov	x11, d0
    1408:      	ld1.s	{ v13 }[2], [x11]
    140c:      	tbz	w23, #0x7, 0x12f8 <ltmp0+0x12f8>
    1410:      	mov.d	x11, v0[1]
    1414:      	ld1.s	{ v13 }[3], [x11]
    1418:      	b	0x12f8 <ltmp0+0x12f8>
    141c:      	mov	x21, #0x0               ; =0
    1420:      	b	0x1448 <ltmp0+0x1448>
    1424:      	add	x11, x13, x21, lsl #5
    1428:      	ldp	q0, q1, [x11]
    142c:      	ldr	q28, [sp, #0x60]
    1430:      	bit.16b	v1, v12, v28
    1434:      	bit.16b	v0, v11, v9
    1438:      	stp	q0, q1, [x11]
    143c:      	add	x21, x21, #0x1
    1440:      	cmp	x21, #0x41
    1444:      	b.eq	0x153c <ltmp0+0x153c>
    1448:      	fmov	w22, s31
    144c:      	dup.2d	v13, x21
    1450:      	add.2d	v0, v13, v20
    1454:      	shl.2d	v0, v0, #0x2
    1458:      	dup.2d	v14, x20
    145c:      	add.2d	v0, v14, v0
    1460:      	movi.2d	v11, #0000000000000000
    1464:      	movi.2d	v12, #0000000000000000
    1468:      	tbnz	w22, #0x0, 0x14b4 <ltmp0+0x14b4>
    146c:      	and	w22, w22, #0xff
    1470:      	tbnz	w22, #0x1, 0x14c4 <ltmp0+0x14c4>
    1474:      	add.2d	v0, v13, v10
    1478:      	shl.2d	v0, v0, #0x2
    147c:      	add.2d	v0, v14, v0
    1480:      	tbnz	w22, #0x2, 0x14dc <ltmp0+0x14dc>
    1484:      	tbnz	w22, #0x3, 0x14e8 <ltmp0+0x14e8>
    1488:      	add.2d	v0, v13, v30
    148c:      	shl.2d	v0, v0, #0x2
    1490:      	add.2d	v0, v14, v0
    1494:      	tbnz	w22, #0x4, 0x1500 <ltmp0+0x1500>
    1498:      	tbnz	w22, #0x5, 0x150c <ltmp0+0x150c>
    149c:      	add.2d	v0, v13, v23
    14a0:      	shl.2d	v0, v0, #0x2
    14a4:      	add.2d	v0, v14, v0
    14a8:      	tbnz	w22, #0x6, 0x1524 <ltmp0+0x1524>
    14ac:      	tbz	w22, #0x7, 0x1424 <ltmp0+0x1424>
    14b0:      	b	0x1530 <ltmp0+0x1530>
    14b4:      	fmov	x11, d0
    14b8:      	ldr	s11, [x11]
    14bc:      	and	w22, w22, #0xff
    14c0:      	tbz	w22, #0x1, 0x1474 <ltmp0+0x1474>
    14c4:      	mov.d	x11, v0[1]
    14c8:      	ld1.s	{ v11 }[1], [x11]
    14cc:      	add.2d	v0, v13, v10
    14d0:      	shl.2d	v0, v0, #0x2
    14d4:      	add.2d	v0, v14, v0
    14d8:      	tbz	w22, #0x2, 0x1484 <ltmp0+0x1484>
    14dc:      	fmov	x11, d0
    14e0:      	ld1.s	{ v11 }[2], [x11]
    14e4:      	tbz	w22, #0x3, 0x1488 <ltmp0+0x1488>
    14e8:      	mov.d	x11, v0[1]
    14ec:      	ld1.s	{ v11 }[3], [x11]
    14f0:      	add.2d	v0, v13, v30
    14f4:      	shl.2d	v0, v0, #0x2
    14f8:      	add.2d	v0, v14, v0
    14fc:      	tbz	w22, #0x4, 0x1498 <ltmp0+0x1498>
    1500:      	fmov	x11, d0
    1504:      	ld1.s	{ v12 }[0], [x11]
    1508:      	tbz	w22, #0x5, 0x149c <ltmp0+0x149c>
    150c:      	mov.d	x11, v0[1]
    1510:      	ld1.s	{ v12 }[1], [x11]
    1514:      	add.2d	v0, v13, v23
    1518:      	shl.2d	v0, v0, #0x2
    151c:      	add.2d	v0, v14, v0
    1520:      	tbz	w22, #0x6, 0x14ac <ltmp0+0x14ac>
    1524:      	fmov	x11, d0
    1528:      	ld1.s	{ v12 }[2], [x11]
    152c:      	tbz	w22, #0x7, 0x1424 <ltmp0+0x1424>
    1530:      	mov.d	x11, v0[1]
    1534:      	ld1.s	{ v12 }[3], [x11]
    1538:      	b	0x1424 <ltmp0+0x1424>
    153c:      	stp	q23, q30, [sp, #0x20]
    1540:      	mov	x20, #0x0               ; =0
    1544:      	str	q31, [sp, #0x10]
    1548:      	b	0x1558 <ltmp0+0x1558>
    154c:      	add	x20, x20, #0x1
    1550:      	cmp	x20, #0x41
    1554:      	b.eq	0xf8 <ltmp0+0xf8>
    1558:      	dup.2d	v11, x20
    155c:      	fmov	w21, s31
    1560:      	mov.16b	v28, v20
    1564:      	add.2d	v20, v11, v20
    1568:      	lsl	x11, x20, #5
    156c:      	add	x14, x12, x11
    1570:      	ldp	q0, q15, [x14]
    1574:      	and.16b	v0, v9, v0
    1578:      	fneg.4s	v1, v0
    157c:      	and.16b	v1, v9, v1
    1580:      	dup.4s	v12, w1
    1584:      	fcmge.4s	v23, v1, v12
    1588:      	dup.4s	v13, w4
    158c:      	fcmge.4s	v14, v13, v1
    1590:      	and.16b	v23, v23, v14
    1594:      	and.16b	v23, v23, v1
    1598:      	fmul.4s	v14, v23, v5
    159c:      	mov.16b	v30, v6
    15a0:      	bsl.16b	v30, v4, v14
    15a4:      	fadd.4s	v14, v14, v30
    15a8:      	fsub.4s	v30, v14, v30
    15ac:      	fcvtzs.4s	v30, v30
    15b0:      	scvtf.4s	v14, v30
    15b4:      	fmul.4s	v31, v14, v7
    15b8:      	fadd.4s	v23, v23, v31
    15bc:      	fmul.4s	v31, v14, v16
    15c0:      	fadd.4s	v23, v23, v31
    15c4:      	fmul.4s	v31, v23, v17
    15c8:      	fadd.4s	v31, v31, v18
    15cc:      	fmul.4s	v31, v23, v31
    15d0:      	fadd.4s	v31, v31, v21
    15d4:      	fmul.4s	v31, v23, v31
    15d8:      	fadd.4s	v31, v31, v25
    15dc:      	fmul.4s	v31, v23, v31
    15e0:      	fadd.4s	v31, v31, v26
    15e4:      	fmul.4s	v31, v23, v31
    15e8:      	fadd.4s	v31, v31, v19
    15ec:      	fmul.4s	v14, v23, v23
    15f0:      	fmul.4s	v31, v14, v31
    15f4:      	fadd.4s	v23, v23, v31
    15f8:      	fadd.4s	v23, v23, v27
    15fc:      	sshr.4s	v31, v30, #0x1
    1600:      	shl.4s	v14, v31, #0x17
    1604:      	add.4s	v14, v14, v27
    1608:      	fmul.4s	v23, v23, v14
    160c:      	sub.4s	v30, v30, v31
    1610:      	shl.4s	v30, v30, #0x17
    1614:      	add.4s	v30, v30, v27
    1618:      	fmul.4s	v23, v23, v30
    161c:      	fcmgt.4s	v30, v12, v1
    1620:      	fcmgt.4s	v31, v1, v13
    1624:      	fcmeq.4s	v1, v1, v1
    1628:      	fadd.4s	v23, v23, v27
    162c:      	bit.16b	v23, v27, v30
    1630:      	bit.16b	v23, v22, v31
    1634:      	bsl.16b	v1, v23, v24
    1638:      	fdiv.4s	v1, v0, v1
    163c:      	add	x11, x13, x11
    1640:      	ldp	q23, q0, [x11]
    1644:      	and.16b	v23, v9, v23
    1648:      	fmul.4s	v1, v23, v1
    164c:      	shl.2d	v20, v20, #0x2
    1650:      	dup.2d	v14, x19
    1654:      	add.2d	v20, v14, v20
    1658:      	tbnz	w21, #0x0, 0x1784 <ltmp0+0x1784>
    165c:      	and	w21, w21, #0xff
    1660:      	ldr	q23, [sp, #0x30]
    1664:      	tbnz	w21, #0x1, 0x1798 <ltmp0+0x1798>
    1668:      	add.2d	v20, v11, v10
    166c:      	shl.2d	v20, v20, #0x2
    1670:      	add.2d	v20, v14, v20
    1674:      	tbnz	w21, #0x2, 0x17b0 <ltmp0+0x17b0>
    1678:      	tbz	w21, #0x3, 0x1684 <ltmp0+0x1684>
    167c:      	mov.d	x11, v20[1]
    1680:      	st1.s	{ v1 }[3], [x11]
    1684:      	add.2d	v1, v11, v23
    1688:      	ldr	q29, [sp, #0x60]
    168c:      	and.16b	v20, v29, v15
    1690:      	fneg.4s	v23, v20
    1694:      	and.16b	v23, v29, v23
    1698:      	fcmge.4s	v30, v23, v12
    169c:      	fcmge.4s	v31, v13, v23
    16a0:      	and.16b	v30, v30, v31
    16a4:      	and.16b	v30, v30, v23
    16a8:      	fmul.4s	v31, v30, v5
    16ac:      	mov.16b	v15, v6
    16b0:      	bsl.16b	v15, v4, v31
    16b4:      	fadd.4s	v31, v31, v15
    16b8:      	fsub.4s	v31, v31, v15
    16bc:      	fcvtzs.4s	v31, v31
    16c0:      	scvtf.4s	v15, v31
    16c4:      	fmul.4s	v8, v15, v7
    16c8:      	fadd.4s	v30, v30, v8
    16cc:      	fmul.4s	v8, v15, v16
    16d0:      	fadd.4s	v30, v30, v8
    16d4:      	fmul.4s	v8, v30, v17
    16d8:      	fadd.4s	v8, v8, v18
    16dc:      	fmul.4s	v8, v30, v8
    16e0:      	fadd.4s	v8, v8, v21
    16e4:      	fmul.4s	v8, v30, v8
    16e8:      	fadd.4s	v8, v8, v25
    16ec:      	fmul.4s	v8, v30, v8
    16f0:      	fadd.4s	v8, v8, v26
    16f4:      	fmul.4s	v8, v30, v8
    16f8:      	fadd.4s	v8, v8, v19
    16fc:      	fmul.4s	v15, v30, v30
    1700:      	fmul.4s	v8, v15, v8
    1704:      	fadd.4s	v30, v30, v8
    1708:      	fadd.4s	v30, v30, v27
    170c:      	sshr.4s	v8, v31, #0x1
    1710:      	shl.4s	v15, v8, #0x17
    1714:      	add.4s	v15, v15, v27
    1718:      	fmul.4s	v30, v30, v15
    171c:      	sub.4s	v31, v31, v8
    1720:      	shl.4s	v31, v31, #0x17
    1724:      	add.4s	v31, v31, v27
    1728:      	fmul.4s	v30, v30, v31
    172c:      	fcmgt.4s	v31, v12, v23
    1730:      	fcmgt.4s	v8, v23, v13
    1734:      	fcmeq.4s	v23, v23, v23
    1738:      	fadd.4s	v30, v30, v27
    173c:      	bit.16b	v30, v27, v31
    1740:      	bit.16b	v30, v22, v8
    1744:      	bsl.16b	v23, v30, v24
    1748:      	fdiv.4s	v20, v20, v23
    174c:      	and.16b	v0, v29, v0
    1750:      	fmul.4s	v0, v0, v20
    1754:      	shl.2d	v1, v1, #0x2
    1758:      	add.2d	v1, v14, v1
    175c:      	tbnz	w21, #0x4, 0x17c0 <ltmp0+0x17c0>
    1760:      	ldp	q31, q23, [sp, #0x10]
    1764:      	mov.16b	v20, v28
    1768:      	tbnz	w21, #0x5, 0x17d4 <ltmp0+0x17d4>
    176c:      	add.2d	v1, v11, v23
    1770:      	shl.2d	v1, v1, #0x2
    1774:      	add.2d	v1, v14, v1
    1778:      	tbnz	w21, #0x6, 0x17ec <ltmp0+0x17ec>
    177c:      	tbz	w21, #0x7, 0x154c <ltmp0+0x154c>
    1780:      	b	0x17f8 <ltmp0+0x17f8>
    1784:      	fmov	x11, d20
    1788:      	str	s1, [x11]
    178c:      	and	w21, w21, #0xff
    1790:      	ldr	q23, [sp, #0x30]
    1794:      	tbz	w21, #0x1, 0x1668 <ltmp0+0x1668>
    1798:      	mov.d	x11, v20[1]
    179c:      	st1.s	{ v1 }[1], [x11]
    17a0:      	add.2d	v20, v11, v10
    17a4:      	shl.2d	v20, v20, #0x2
    17a8:      	add.2d	v20, v14, v20
    17ac:      	tbz	w21, #0x2, 0x1678 <ltmp0+0x1678>
    17b0:      	fmov	x11, d20
    17b4:      	st1.s	{ v1 }[2], [x11]
    17b8:      	tbnz	w21, #0x3, 0x167c <ltmp0+0x167c>
    17bc:      	b	0x1684 <ltmp0+0x1684>
    17c0:      	fmov	x11, d1
    17c4:      	str	s0, [x11]
    17c8:      	ldp	q31, q23, [sp, #0x10]
    17cc:      	mov.16b	v20, v28
    17d0:      	tbz	w21, #0x5, 0x176c <ltmp0+0x176c>
    17d4:      	mov.d	x11, v1[1]
    17d8:      	st1.s	{ v0 }[1], [x11]
    17dc:      	add.2d	v1, v11, v23
    17e0:      	shl.2d	v1, v1, #0x2
    17e4:      	add.2d	v1, v14, v1
    17e8:      	tbz	w21, #0x6, 0x177c <ltmp0+0x177c>
    17ec:      	fmov	x11, d1
    17f0:      	st1.s	{ v0 }[2], [x11]
    17f4:      	tbz	w21, #0x7, 0x154c <ltmp0+0x154c>
    17f8:      	mov.d	x11, v1[1]
    17fc:      	st1.s	{ v0 }[3], [x11]
    1800:      	b	0x154c <ltmp0+0x154c>
    1804:      	ldr	x9, [sp, #0x8]
    1808:      	stp	w7, w6, [x9]
    180c:      	str	w5, [x9, #0x8]
    1810:      	mov	w8, #0x18               ; =24
    1814:      	str	w8, [x9, #0x24]
    1818:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    181c:      	add	sp, sp, #0xc0
    1820:      	ldp	x29, x30, [sp, #0x90]
    1824:      	ldp	x20, x19, [sp, #0x80]
    1828:      	ldp	x22, x21, [sp, #0x70]
    182c:      	ldp	x24, x23, [sp, #0x60]
    1830:      	ldp	x26, x25, [sp, #0x50]
    1834:      	ldp	x28, x27, [sp, #0x40]
    1838:      	ldp	d9, d8, [sp, #0x30]
    183c:      	ldp	d11, d10, [sp, #0x20]
    1840:      	ldp	d13, d12, [sp, #0x10]
    1844:      	ldp	d15, d14, [sp], #0xa0
    1848:      	ret

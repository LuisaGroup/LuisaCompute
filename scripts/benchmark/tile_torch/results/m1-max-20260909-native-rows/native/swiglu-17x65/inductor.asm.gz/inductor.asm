
/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/swiglu-17x65/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0xa0
     6b4:      	stp	d9, d8, [sp, #0x40]
     6b8:      	stp	x26, x25, [sp, #0x50]
     6bc:      	stp	x24, x23, [sp, #0x60]
     6c0:      	stp	x22, x21, [sp, #0x70]
     6c4:      	stp	x20, x19, [sp, #0x80]
     6c8:      	stp	x29, x30, [sp, #0x90]
     6cc:      	add	x29, sp, #0x90
     6d0:      	mov	x19, x2
     6d4:      	mov	x20, x1
     6d8:      	mov	x21, x0
     6dc:      	str	wzr, [sp, #0x20]
     6e0:      	adrp	x22, 0x4000 <dyld_stub_binder+0x4000>
     6e4:      	ldr	x22, [x22, #0x90]
     6e8:      	add	x8, sp, #0x20
     6ec:      	str	x8, [x22]
     6f0:      	mov	x23, #-0x4              ; =-4
     6f4:      	mov	x24, x2
     6f8:      	mov	x25, x1
     6fc:      	mov	x26, x0
     700:      	cmp	x23, #0x44c
     704:      	b.eq	0x770 <_kernel+0xc0>
     708:      	ldr	q1, [x26], #0x10
     70c:      	ldr	q0, [x25], #0x10
     710:      	stp	q1, q0, [sp]
     714:      	fneg.4s	v0, v1
     718:      	bl	0x159c <dyld_stub_binder+0x159c>
     71c:      	fmov.4s	v1, #1.00000000
     720:      	fadd.4s	v0, v0, v1
     724:      	ldp	q2, q1, [sp]
     728:      	fdiv.4s	v0, v2, v0
     72c:      	fmul.4s	v0, v1, v0
     730:      	str	q0, [x24], #0x10
     734:      	add	x23, x23, #0x4
     738:      	cmp	x23, #0x44d
     73c:      	b.lo	0x700 <_kernel+0x50>
     740:      	str	xzr, [x22]
     744:      	add	x8, sp, #0x20
     748:      	ldapr	w8, [x8]
     74c:      	cbnz	w8, 0x7ac <_kernel+0xfc>
     750:      	ldp	x29, x30, [sp, #0x90]
     754:      	ldp	x20, x19, [sp, #0x80]
     758:      	ldp	x22, x21, [sp, #0x70]
     75c:      	ldp	x24, x23, [sp, #0x60]
     760:      	ldp	x26, x25, [sp, #0x50]
     764:      	ldp	d9, d8, [sp, #0x40]
     768:      	add	sp, sp, #0xa0
     76c:      	ret
     770:      	ldr	s8, [x21, #0x1140]
     774:      	ldr	s9, [x20, #0x1140]
     778:      	fneg	s1, s8
     77c:      	movi.4s	v0, #0x80, lsl #24
     780:      	mov.s	v0[0], v1[0]
     784:      	bl	0x159c <dyld_stub_binder+0x159c>
     788:      	fmov	s1, #1.00000000
     78c:      	fadd	s0, s0, s1
     790:      	fdiv	s0, s8, s0
     794:      	fmul	s0, s9, s0
     798:      	str	s0, [x19, #0x1140]
     79c:      	str	xzr, [x22]
     7a0:      	add	x8, sp, #0x20
     7a4:      	ldapr	w8, [x8]
     7a8:      	cbz	w8, 0x750 <_kernel+0xa0>
     7ac:      	mov	w0, #0x10               ; =16
     7b0:      	bl	0x1698 <dyld_stub_binder+0x1698>
     7b4:      	mov	x19, x0
     7b8:      	mov	w8, #0x33d              ; =829
     7bc:      	str	w8, [sp, #0x24]
     7c0:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x88>
     7c4:      	add	x0, x0, #0x9c8
     7c8:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x88>
     7cc:      	add	x1, x1, #0xa54
     7d0:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x88>
     7d4:      	add	x3, x3, #0xa7f
     7d8:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x88>
     7dc:      	add	x4, x4, #0xafd
     7e0:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x88>
     7e4:      	add	x2, x2, #0xa7c
     7e8:      	add	x8, sp, #0x28
     7ec:      	add	x5, sp, #0x24
     7f0:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x88>
     7f4:      	add	x7, x7, #0xaff
     7f8:      	mov	x6, x2
     7fc:      	bl	0x870 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     800:      	mov	w21, #0x1               ; =1
     804:      	add	x1, sp, #0x28
     808:      	mov	x0, x19
     80c:      	bl	0x15e4 <dyld_stub_binder+0x15e4>
     810:      	mov	w21, #0x0               ; =0
     814:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     818:      	ldr	x1, [x1, #0x18]
     81c:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     820:      	ldr	x2, [x2, #0x8]
     824:      	mov	x0, x19
     828:      	bl	0x16c8 <dyld_stub_binder+0x16c8>
     82c:      	brk	#0x1
     830:      	mov	x20, x0
     834:      	ldrsb	w8, [sp, #0x3f]
     838:      	tbz	w8, #0x1f, 0x854 <_kernel+0x1a4>
     83c:      	ldr	x0, [sp, #0x28]
     840:      	ldr	x8, [sp, #0x38]
     844:      	and	x1, x8, #0x7fffffffffffffff
     848:      	bl	0x1680 <dyld_stub_binder+0x1680>
     84c:      	tbnz	w21, #0x0, 0x860 <_kernel+0x1b0>
     850:      	b	0x868 <_kernel+0x1b8>
     854:      	cbnz	w21, 0x860 <_kernel+0x1b0>
     858:      	b	0x868 <_kernel+0x1b8>
     85c:      	mov	x20, x0
     860:      	mov	x0, x19
     864:      	bl	0x16bc <dyld_stub_binder+0x16bc>
     868:      	mov	x0, x20
     86c:      	bl	0x15a8 <dyld_stub_binder+0x15a8>

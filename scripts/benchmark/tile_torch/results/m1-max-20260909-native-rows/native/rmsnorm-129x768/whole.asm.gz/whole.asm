
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/rmsnorm-129x768-l1/object/tile_xir_w8_80692_1788919109329224_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x10a4 <ltmp0+0x10a4>
       4:      	stp	d13, d12, [sp, #-0x90]!
       8:      	stp	d11, d10, [sp, #0x10]
       c:      	stp	d9, d8, [sp, #0x20]
      10:      	stp	x28, x27, [sp, #0x30]
      14:      	stp	x26, x25, [sp, #0x40]
      18:      	stp	x24, x23, [sp, #0x50]
      1c:      	stp	x22, x21, [sp, #0x60]
      20:      	stp	x20, x19, [sp, #0x70]
      24:      	stp	x29, x30, [sp, #0x80]
      28:      	sub	sp, sp, #0xc, lsl #12   ; =0xc000
      2c:      	sub	sp, sp, #0x20
      30:      	mov	w8, #0x0                ; =0
      34:      	add	x9, sp, #0x6, lsl #12   ; =0x6000
      38:      	add	x9, x9, #0x20
      3c:      	ldp	w10, w11, [x2, #0x2c]
      40:      	ldp	w7, w19, [x2]
      44:      	add	x12, x9, #0xe0
      48:      	str	x12, [sp, #0x10]
      4c:      	adrp	x14, 0x0 <ltmp0>
      50:      	ldr	q0, [x14]
      54:      	adrp	x14, 0x0 <ltmp0>
      58:      	ldr	q1, [x14]
      5c:      	movi.4s	v2, #0x3, lsl #8
      60:      	movi.2s	v3, #0x3, lsl #8
      64:      	add	x14, sp, #0x20
      68:      	mov	w15, #0x44400000        ; =1145044992
      6c:      	mov	w16, #0xc5ac            ; =50604
      70:      	movk	w16, #0x3727, lsl #16
      74:      	adrp	x17, 0x0 <ltmp0>
      78:      	ldp	w20, w1, [x2, #0x8]
      7c:      	str	x2, [sp, #0x8]
      80:      	b	0xb8 <ltmp0+0xb8>
      84:      	add	w12, w6, #0x1
      88:      	cmp	w12, w10
      8c:      	cset	w12, eq
      90:      	csinc	w7, wzr, w6, eq
      94:      	cinc	w13, w5, eq
      98:      	cmp	w13, w11
      9c:      	cset	w2, eq
      a0:      	ands	w12, w12, w2
      a4:      	csel	w19, wzr, w13, ne
      a8:      	add	w20, w4, w12
      ac:      	add	w8, w8, #0x1
      b0:      	cmp	w8, w3
      b4:      	b.eq	0x1064 <ltmp0+0x1064>
      b8:      	mov	x4, x20
      bc:      	mov	x5, x19
      c0:      	mov	x6, x7
      c4:      	ubfiz	x7, x7, #5, #32
      c8:      	cmp	x7, x1
      cc:      	csel	x19, x7, xzr, ls
      d0:      	subs	x20, x1, x19
      d4:      	cmp	x20, #0x20
      d8:      	mov	w12, #0x20              ; =32
      dc:      	csel	x20, x20, x12, lo
      e0:      	cmp	x1, x19
      e4:      	ccmp	x7, x1, #0x2, hi
      e8:      	csel	x19, x20, xzr, ls
      ec:      	dup.4s	v5, w15
      f0:      	dup.4s	v4, w16
      f4:      	cmp	x19, #0x20
      f8:      	b.lo	0x9f4 <ltmp0+0x9f4>
      fc:      	mov	x21, #0x0               ; =0
     100:      	ldr	x22, [x0]
     104:      	ldr	x7, [x0, #0x10]
     108:      	ldr	x20, [x0, #0x30]
     10c:      	lsl	w19, w6, #5
     110:      	dup.4s	v6, w19
     114:      	orr.16b	v7, v6, v0
     118:      	orr.16b	v6, v6, v1
     11c:      	umull2.2d	v16, v7, v2
     120:      	umull2.2d	v17, v6, v2
     124:      	umull.2d	v18, v7, v3
     128:      	umull.2d	v19, v6, v3
     12c:      	dup.2d	v6, x22
     130:      	dup.2d	v7, x21
     134:      	add.2d	v20, v7, v16
     138:      	add.2d	v21, v7, v18
     13c:      	add.2d	v22, v7, v17
     140:      	add.2d	v7, v7, v19
     144:      	shl.2d	v7, v7, #0x2
     148:      	shl.2d	v22, v22, #0x2
     14c:      	shl.2d	v21, v21, #0x2
     150:      	shl.2d	v20, v20, #0x2
     154:      	add.2d	v20, v6, v20
     158:      	add.2d	v21, v6, v21
     15c:      	add.2d	v22, v6, v22
     160:      	add.2d	v7, v6, v7
     164:      	mov.d	x22, v7[1]
     168:      	fmov	x23, d7
     16c:      	mov.d	x24, v22[1]
     170:      	fmov	x25, d22
     174:      	mov.d	x26, v21[1]
     178:      	fmov	x27, d21
     17c:      	mov.d	x28, v20[1]
     180:      	ldr	s7, [x27]
     184:      	ld1.s	{ v7 }[1], [x26]
     188:      	fmov	x26, d20
     18c:      	ld1.s	{ v7 }[2], [x26]
     190:      	ld1.s	{ v7 }[3], [x28]
     194:      	ldr	s20, [x23]
     198:      	ld1.s	{ v20 }[1], [x22]
     19c:      	ld1.s	{ v20 }[2], [x25]
     1a0:      	ld1.s	{ v20 }[3], [x24]
     1a4:      	add	x22, x9, x21, lsl #5
     1a8:      	stp	q20, q7, [x22]
     1ac:      	add	x21, x21, #0x1
     1b0:      	cmp	x21, #0x300
     1b4:      	b.ne	0x130 <ltmp0+0x130>
     1b8:      	mov	x21, #0x0               ; =0
     1bc:      	ldp	q7, q20, [x9]
     1c0:      	fmul.4s	v20, v20, v20
     1c4:      	fmul.4s	v7, v7, v7
     1c8:      	ldp	q21, q22, [x9, #0x20]
     1cc:      	fmul.4s	v22, v22, v22
     1d0:      	fmul.4s	v21, v21, v21
     1d4:      	ldp	q24, q23, [x9, #0x40]
     1d8:      	fmul.4s	v23, v23, v23
     1dc:      	fmul.4s	v24, v24, v24
     1e0:      	ldp	q25, q26, [x9, #0x60]
     1e4:      	fmul.4s	v26, v26, v26
     1e8:      	fmul.4s	v25, v25, v25
     1ec:      	add	x22, x9, x21, lsl #5
     1f0:      	ldp	q28, q27, [x22, #0x80]
     1f4:      	fmul.4s	v28, v28, v28
     1f8:      	fmul.4s	v27, v27, v27
     1fc:      	fadd.4s	v20, v20, v27
     200:      	fadd.4s	v7, v7, v28
     204:      	ldp	q28, q27, [x22, #0xa0]
     208:      	fmul.4s	v28, v28, v28
     20c:      	fmul.4s	v27, v27, v27
     210:      	fadd.4s	v22, v22, v27
     214:      	fadd.4s	v21, v21, v28
     218:      	ldp	q28, q27, [x22, #0xc0]
     21c:      	fmul.4s	v28, v28, v28
     220:      	fmul.4s	v27, v27, v27
     224:      	fadd.4s	v23, v23, v27
     228:      	fadd.4s	v24, v24, v28
     22c:      	ldp	q28, q27, [x22, #0xe0]
     230:      	fmul.4s	v28, v28, v28
     234:      	fmul.4s	v27, v27, v27
     238:      	fadd.4s	v26, v26, v27
     23c:      	fadd.4s	v25, v25, v28
     240:      	add	x21, x21, #0x4
     244:      	cmp	x21, #0x2fc
     248:      	b.lo	0x1ec <ltmp0+0x1ec>
     24c:      	mov	x21, #0x0               ; =0
     250:      	add	x22, x7, x21, lsl #2
     254:      	ld1r.4s	{ v27 }, [x22]
     258:      	add	x22, x14, x21, lsl #5
     25c:      	stp	q27, q27, [x22]
     260:      	add	x21, x21, #0x1
     264:      	cmp	x21, #0x300
     268:      	b.ne	0x250 <ltmp0+0x250>
     26c:      	mov	x21, #0x0               ; =0
     270:      	fadd.4s	v20, v20, v22
     274:      	fadd.4s	v7, v7, v21
     278:      	fadd.4s	v7, v7, v24
     27c:      	fadd.4s	v20, v20, v23
     280:      	fadd.4s	v20, v20, v26
     284:      	fadd.4s	v7, v7, v25
     288:      	fdiv.4s	v7, v7, v5
     28c:      	fdiv.4s	v20, v20, v5
     290:      	fadd.4s	v21, v20, v4
     294:      	fadd.4s	v7, v7, v4
     298:      	fsqrt.4s	v20, v7
     29c:      	fsqrt.4s	v21, v21
     2a0:      	dup.2d	v7, x21
     2a4:      	add.2d	v22, v7, v16
     2a8:      	add.2d	v23, v7, v18
     2ac:      	add.2d	v24, v7, v17
     2b0:      	add.2d	v7, v7, v19
     2b4:      	lsl	x22, x21, #5
     2b8:      	add	x23, x9, x22
     2bc:      	ldp	q26, q25, [x23]
     2c0:      	fdiv.4s	v26, v26, v20
     2c4:      	fdiv.4s	v25, v25, v21
     2c8:      	add	x22, x14, x22
     2cc:      	ldp	q27, q28, [x22]
     2d0:      	fmul.4s	v25, v25, v28
     2d4:      	fmul.4s	v26, v26, v27
     2d8:      	shl.2d	v27, v7, #0x2
     2dc:      	shl.2d	v24, v24, #0x2
     2e0:      	shl.2d	v23, v23, #0x2
     2e4:      	shl.2d	v22, v22, #0x2
     2e8:      	dup.2d	v7, x20
     2ec:      	add.2d	v22, v7, v22
     2f0:      	add.2d	v27, v7, v27
     2f4:      	mov.d	x22, v27[1]
     2f8:      	fmov	x23, d27
     2fc:      	str	s26, [x23]
     300:      	st1.s	{ v26 }[1], [x22]
     304:      	add.2d	v24, v7, v24
     308:      	mov.d	x22, v24[1]
     30c:      	fmov	x23, d24
     310:      	st1.s	{ v26 }[2], [x23]
     314:      	add.2d	v23, v7, v23
     318:      	st1.s	{ v26 }[3], [x22]
     31c:      	mov.d	x22, v23[1]
     320:      	fmov	x23, d23
     324:      	str	s25, [x23]
     328:      	st1.s	{ v25 }[1], [x22]
     32c:      	mov.d	x22, v22[1]
     330:      	fmov	x23, d22
     334:      	st1.s	{ v25 }[2], [x23]
     338:      	st1.s	{ v25 }[3], [x22]
     33c:      	add	x21, x21, #0x1
     340:      	cmp	x21, #0x300
     344:      	b.ne	0x2a0 <ltmp0+0x2a0>
     348:      	mov	x20, #0x0               ; =0
     34c:      	orr	w21, w19, #0x8
     350:      	dup.4s	v16, w21
     354:      	orr.16b	v18, v16, v0
     358:      	orr.16b	v19, v16, v1
     35c:      	umull2.2d	v16, v18, v2
     360:      	umull2.2d	v17, v19, v2
     364:      	umull.2d	v18, v18, v3
     368:      	umull.2d	v19, v19, v3
     36c:      	dup.2d	v20, x20
     370:      	add.2d	v21, v20, v16
     374:      	add.2d	v22, v20, v18
     378:      	add.2d	v23, v20, v17
     37c:      	add.2d	v20, v20, v19
     380:      	shl.2d	v20, v20, #0x2
     384:      	shl.2d	v23, v23, #0x2
     388:      	shl.2d	v22, v22, #0x2
     38c:      	shl.2d	v21, v21, #0x2
     390:      	add.2d	v21, v6, v21
     394:      	add.2d	v22, v6, v22
     398:      	add.2d	v23, v6, v23
     39c:      	add.2d	v20, v6, v20
     3a0:      	mov.d	x21, v20[1]
     3a4:      	fmov	x22, d20
     3a8:      	mov.d	x23, v23[1]
     3ac:      	fmov	x24, d23
     3b0:      	mov.d	x25, v22[1]
     3b4:      	fmov	x26, d22
     3b8:      	mov.d	x27, v21[1]
     3bc:      	ldr	s20, [x26]
     3c0:      	ld1.s	{ v20 }[1], [x25]
     3c4:      	fmov	x25, d21
     3c8:      	ld1.s	{ v20 }[2], [x25]
     3cc:      	ld1.s	{ v20 }[3], [x27]
     3d0:      	ldr	s21, [x22]
     3d4:      	ld1.s	{ v21 }[1], [x21]
     3d8:      	ld1.s	{ v21 }[2], [x24]
     3dc:      	ld1.s	{ v21 }[3], [x23]
     3e0:      	add	x21, x9, x20, lsl #5
     3e4:      	stp	q21, q20, [x21]
     3e8:      	add	x20, x20, #0x1
     3ec:      	cmp	x20, #0x300
     3f0:      	b.ne	0x36c <ltmp0+0x36c>
     3f4:      	mov	x20, #0x0               ; =0
     3f8:      	ldp	q20, q21, [x9]
     3fc:      	fmul.4s	v21, v21, v21
     400:      	fmul.4s	v20, v20, v20
     404:      	ldp	q22, q23, [x9, #0x20]
     408:      	fmul.4s	v23, v23, v23
     40c:      	fmul.4s	v22, v22, v22
     410:      	ldp	q25, q24, [x9, #0x40]
     414:      	fmul.4s	v24, v24, v24
     418:      	fmul.4s	v25, v25, v25
     41c:      	ldp	q26, q27, [x9, #0x60]
     420:      	fmul.4s	v27, v27, v27
     424:      	fmul.4s	v26, v26, v26
     428:      	add	x21, x9, x20, lsl #5
     42c:      	ldp	q29, q28, [x21, #0x80]
     430:      	fmul.4s	v29, v29, v29
     434:      	fmul.4s	v28, v28, v28
     438:      	fadd.4s	v21, v21, v28
     43c:      	fadd.4s	v20, v20, v29
     440:      	ldp	q29, q28, [x21, #0xa0]
     444:      	fmul.4s	v29, v29, v29
     448:      	fmul.4s	v28, v28, v28
     44c:      	fadd.4s	v23, v23, v28
     450:      	fadd.4s	v22, v22, v29
     454:      	ldp	q29, q28, [x21, #0xc0]
     458:      	fmul.4s	v29, v29, v29
     45c:      	fmul.4s	v28, v28, v28
     460:      	fadd.4s	v24, v24, v28
     464:      	fadd.4s	v25, v25, v29
     468:      	ldp	q29, q28, [x21, #0xe0]
     46c:      	fmul.4s	v29, v29, v29
     470:      	fmul.4s	v28, v28, v28
     474:      	fadd.4s	v27, v27, v28
     478:      	fadd.4s	v26, v26, v29
     47c:      	add	x20, x20, #0x4
     480:      	cmp	x20, #0x2fc
     484:      	b.lo	0x428 <ltmp0+0x428>
     488:      	mov	x20, #0x0               ; =0
     48c:      	add	x21, x7, x20, lsl #2
     490:      	ld1r.4s	{ v28 }, [x21]
     494:      	add	x21, x14, x20, lsl #5
     498:      	stp	q28, q28, [x21]
     49c:      	add	x20, x20, #0x1
     4a0:      	cmp	x20, #0x300
     4a4:      	b.ne	0x48c <ltmp0+0x48c>
     4a8:      	mov	x20, #0x0               ; =0
     4ac:      	fadd.4s	v21, v21, v23
     4b0:      	fadd.4s	v20, v20, v22
     4b4:      	fadd.4s	v20, v20, v25
     4b8:      	fadd.4s	v21, v21, v24
     4bc:      	fadd.4s	v21, v21, v27
     4c0:      	fadd.4s	v20, v20, v26
     4c4:      	fdiv.4s	v20, v20, v5
     4c8:      	fdiv.4s	v21, v21, v5
     4cc:      	fadd.4s	v21, v21, v4
     4d0:      	fadd.4s	v20, v20, v4
     4d4:      	fsqrt.4s	v20, v20
     4d8:      	fsqrt.4s	v21, v21
     4dc:      	dup.2d	v22, x20
     4e0:      	add.2d	v23, v22, v16
     4e4:      	add.2d	v24, v22, v18
     4e8:      	add.2d	v25, v22, v17
     4ec:      	add.2d	v22, v22, v19
     4f0:      	lsl	x21, x20, #5
     4f4:      	add	x22, x9, x21
     4f8:      	ldp	q27, q26, [x22]
     4fc:      	fdiv.4s	v27, v27, v20
     500:      	fdiv.4s	v26, v26, v21
     504:      	add	x21, x14, x21
     508:      	ldp	q28, q29, [x21]
     50c:      	fmul.4s	v26, v26, v29
     510:      	fmul.4s	v27, v27, v28
     514:      	shl.2d	v22, v22, #0x2
     518:      	shl.2d	v25, v25, #0x2
     51c:      	shl.2d	v24, v24, #0x2
     520:      	shl.2d	v23, v23, #0x2
     524:      	add.2d	v23, v7, v23
     528:      	add.2d	v22, v7, v22
     52c:      	mov.d	x21, v22[1]
     530:      	fmov	x22, d22
     534:      	str	s27, [x22]
     538:      	st1.s	{ v27 }[1], [x21]
     53c:      	add.2d	v22, v7, v25
     540:      	mov.d	x21, v22[1]
     544:      	fmov	x22, d22
     548:      	st1.s	{ v27 }[2], [x22]
     54c:      	add.2d	v22, v7, v24
     550:      	st1.s	{ v27 }[3], [x21]
     554:      	mov.d	x21, v22[1]
     558:      	fmov	x22, d22
     55c:      	str	s26, [x22]
     560:      	st1.s	{ v26 }[1], [x21]
     564:      	mov.d	x21, v23[1]
     568:      	fmov	x22, d23
     56c:      	st1.s	{ v26 }[2], [x22]
     570:      	st1.s	{ v26 }[3], [x21]
     574:      	add	x20, x20, #0x1
     578:      	cmp	x20, #0x300
     57c:      	b.ne	0x4dc <ltmp0+0x4dc>
     580:      	mov	x20, #0x0               ; =0
     584:      	orr	w21, w19, #0x10
     588:      	dup.4s	v16, w21
     58c:      	orr.16b	v18, v16, v0
     590:      	orr.16b	v19, v16, v1
     594:      	umull2.2d	v16, v18, v2
     598:      	umull2.2d	v17, v19, v2
     59c:      	umull.2d	v18, v18, v3
     5a0:      	umull.2d	v19, v19, v3
     5a4:      	dup.2d	v20, x20
     5a8:      	add.2d	v21, v20, v16
     5ac:      	add.2d	v22, v20, v18
     5b0:      	add.2d	v23, v20, v17
     5b4:      	add.2d	v20, v20, v19
     5b8:      	shl.2d	v20, v20, #0x2
     5bc:      	shl.2d	v23, v23, #0x2
     5c0:      	shl.2d	v22, v22, #0x2
     5c4:      	shl.2d	v21, v21, #0x2
     5c8:      	add.2d	v21, v6, v21
     5cc:      	add.2d	v22, v6, v22
     5d0:      	add.2d	v23, v6, v23
     5d4:      	add.2d	v20, v6, v20
     5d8:      	mov.d	x21, v20[1]
     5dc:      	fmov	x22, d20
     5e0:      	mov.d	x23, v23[1]
     5e4:      	fmov	x24, d23
     5e8:      	mov.d	x25, v22[1]
     5ec:      	fmov	x26, d22
     5f0:      	mov.d	x27, v21[1]
     5f4:      	ldr	s20, [x26]
     5f8:      	ld1.s	{ v20 }[1], [x25]
     5fc:      	fmov	x25, d21
     600:      	ld1.s	{ v20 }[2], [x25]
     604:      	ld1.s	{ v20 }[3], [x27]
     608:      	ldr	s21, [x22]
     60c:      	ld1.s	{ v21 }[1], [x21]
     610:      	ld1.s	{ v21 }[2], [x24]
     614:      	ld1.s	{ v21 }[3], [x23]
     618:      	add	x21, x9, x20, lsl #5
     61c:      	stp	q21, q20, [x21]
     620:      	add	x20, x20, #0x1
     624:      	cmp	x20, #0x300
     628:      	b.ne	0x5a4 <ltmp0+0x5a4>
     62c:      	mov	x20, #0x0               ; =0
     630:      	ldp	q20, q21, [x9]
     634:      	fmul.4s	v21, v21, v21
     638:      	fmul.4s	v20, v20, v20
     63c:      	ldp	q22, q23, [x9, #0x20]
     640:      	fmul.4s	v23, v23, v23
     644:      	fmul.4s	v22, v22, v22
     648:      	ldp	q25, q24, [x9, #0x40]
     64c:      	fmul.4s	v24, v24, v24
     650:      	fmul.4s	v25, v25, v25
     654:      	ldp	q26, q27, [x9, #0x60]
     658:      	fmul.4s	v27, v27, v27
     65c:      	fmul.4s	v26, v26, v26
     660:      	add	x21, x9, x20, lsl #5
     664:      	ldp	q29, q28, [x21, #0x80]
     668:      	fmul.4s	v29, v29, v29
     66c:      	fmul.4s	v28, v28, v28
     670:      	fadd.4s	v21, v21, v28
     674:      	fadd.4s	v20, v20, v29
     678:      	ldp	q29, q28, [x21, #0xa0]
     67c:      	fmul.4s	v29, v29, v29
     680:      	fmul.4s	v28, v28, v28
     684:      	fadd.4s	v23, v23, v28
     688:      	fadd.4s	v22, v22, v29
     68c:      	ldp	q29, q28, [x21, #0xc0]
     690:      	fmul.4s	v29, v29, v29
     694:      	fmul.4s	v28, v28, v28
     698:      	fadd.4s	v24, v24, v28
     69c:      	fadd.4s	v25, v25, v29
     6a0:      	ldp	q29, q28, [x21, #0xe0]
     6a4:      	fmul.4s	v29, v29, v29
     6a8:      	fmul.4s	v28, v28, v28
     6ac:      	fadd.4s	v27, v27, v28
     6b0:      	fadd.4s	v26, v26, v29
     6b4:      	add	x20, x20, #0x4
     6b8:      	cmp	x20, #0x2fc
     6bc:      	b.lo	0x660 <ltmp0+0x660>
     6c0:      	mov	x20, #0x0               ; =0
     6c4:      	add	x21, x7, x20, lsl #2
     6c8:      	ld1r.4s	{ v28 }, [x21]
     6cc:      	add	x21, x14, x20, lsl #5
     6d0:      	stp	q28, q28, [x21]
     6d4:      	add	x20, x20, #0x1
     6d8:      	cmp	x20, #0x300
     6dc:      	b.ne	0x6c4 <ltmp0+0x6c4>
     6e0:      	mov	x20, #0x0               ; =0
     6e4:      	fadd.4s	v21, v21, v23
     6e8:      	fadd.4s	v20, v20, v22
     6ec:      	fadd.4s	v20, v20, v25
     6f0:      	fadd.4s	v21, v21, v24
     6f4:      	fadd.4s	v21, v21, v27
     6f8:      	fadd.4s	v20, v20, v26
     6fc:      	fdiv.4s	v20, v20, v5
     700:      	fdiv.4s	v21, v21, v5
     704:      	fadd.4s	v21, v21, v4
     708:      	fadd.4s	v20, v20, v4
     70c:      	fsqrt.4s	v20, v20
     710:      	fsqrt.4s	v21, v21
     714:      	dup.2d	v22, x20
     718:      	add.2d	v23, v22, v16
     71c:      	add.2d	v24, v22, v18
     720:      	add.2d	v25, v22, v17
     724:      	add.2d	v22, v22, v19
     728:      	lsl	x21, x20, #5
     72c:      	add	x22, x9, x21
     730:      	ldp	q27, q26, [x22]
     734:      	fdiv.4s	v27, v27, v20
     738:      	fdiv.4s	v26, v26, v21
     73c:      	add	x21, x14, x21
     740:      	ldp	q28, q29, [x21]
     744:      	fmul.4s	v26, v26, v29
     748:      	fmul.4s	v27, v27, v28
     74c:      	shl.2d	v22, v22, #0x2
     750:      	shl.2d	v25, v25, #0x2
     754:      	shl.2d	v24, v24, #0x2
     758:      	shl.2d	v23, v23, #0x2
     75c:      	add.2d	v23, v7, v23
     760:      	add.2d	v22, v7, v22
     764:      	mov.d	x21, v22[1]
     768:      	fmov	x22, d22
     76c:      	str	s27, [x22]
     770:      	st1.s	{ v27 }[1], [x21]
     774:      	add.2d	v22, v7, v25
     778:      	mov.d	x21, v22[1]
     77c:      	fmov	x22, d22
     780:      	st1.s	{ v27 }[2], [x22]
     784:      	add.2d	v22, v7, v24
     788:      	st1.s	{ v27 }[3], [x21]
     78c:      	mov.d	x21, v22[1]
     790:      	fmov	x22, d22
     794:      	str	s26, [x22]
     798:      	st1.s	{ v26 }[1], [x21]
     79c:      	mov.d	x21, v23[1]
     7a0:      	fmov	x22, d23
     7a4:      	st1.s	{ v26 }[2], [x22]
     7a8:      	st1.s	{ v26 }[3], [x21]
     7ac:      	add	x20, x20, #0x1
     7b0:      	cmp	x20, #0x300
     7b4:      	b.ne	0x714 <ltmp0+0x714>
     7b8:      	mov	x20, #0x0               ; =0
     7bc:      	orr	w19, w19, #0x18
     7c0:      	dup.4s	v16, w19
     7c4:      	orr.16b	v18, v16, v0
     7c8:      	orr.16b	v19, v16, v1
     7cc:      	umull2.2d	v16, v18, v2
     7d0:      	umull2.2d	v17, v19, v2
     7d4:      	umull.2d	v18, v18, v3
     7d8:      	umull.2d	v19, v19, v3
     7dc:      	dup.2d	v20, x20
     7e0:      	add.2d	v21, v20, v16
     7e4:      	add.2d	v22, v20, v18
     7e8:      	add.2d	v23, v20, v17
     7ec:      	add.2d	v20, v20, v19
     7f0:      	shl.2d	v20, v20, #0x2
     7f4:      	shl.2d	v23, v23, #0x2
     7f8:      	shl.2d	v22, v22, #0x2
     7fc:      	shl.2d	v21, v21, #0x2
     800:      	add.2d	v21, v6, v21
     804:      	add.2d	v22, v6, v22
     808:      	add.2d	v23, v6, v23
     80c:      	add.2d	v20, v6, v20
     810:      	mov.d	x19, v20[1]
     814:      	fmov	x21, d20
     818:      	mov.d	x22, v23[1]
     81c:      	fmov	x23, d23
     820:      	mov.d	x24, v22[1]
     824:      	fmov	x25, d22
     828:      	mov.d	x26, v21[1]
     82c:      	ldr	s20, [x25]
     830:      	ld1.s	{ v20 }[1], [x24]
     834:      	fmov	x24, d21
     838:      	ld1.s	{ v20 }[2], [x24]
     83c:      	ld1.s	{ v20 }[3], [x26]
     840:      	ldr	s21, [x21]
     844:      	ld1.s	{ v21 }[1], [x19]
     848:      	ld1.s	{ v21 }[2], [x23]
     84c:      	ld1.s	{ v21 }[3], [x22]
     850:      	add	x19, x9, x20, lsl #5
     854:      	stp	q21, q20, [x19]
     858:      	add	x20, x20, #0x1
     85c:      	cmp	x20, #0x300
     860:      	b.ne	0x7dc <ltmp0+0x7dc>
     864:      	mov	x19, #0x0               ; =0
     868:      	ldp	q6, q20, [x9]
     86c:      	fmul.4s	v20, v20, v20
     870:      	fmul.4s	v6, v6, v6
     874:      	ldp	q21, q22, [x9, #0x20]
     878:      	fmul.4s	v22, v22, v22
     87c:      	fmul.4s	v21, v21, v21
     880:      	ldp	q24, q23, [x9, #0x40]
     884:      	fmul.4s	v23, v23, v23
     888:      	fmul.4s	v24, v24, v24
     88c:      	ldp	q25, q26, [x9, #0x60]
     890:      	fmul.4s	v26, v26, v26
     894:      	fmul.4s	v25, v25, v25
     898:      	add	x20, x9, x19, lsl #5
     89c:      	ldp	q28, q27, [x20, #0x80]
     8a0:      	fmul.4s	v28, v28, v28
     8a4:      	fmul.4s	v27, v27, v27
     8a8:      	fadd.4s	v20, v20, v27
     8ac:      	fadd.4s	v6, v6, v28
     8b0:      	ldp	q28, q27, [x20, #0xa0]
     8b4:      	fmul.4s	v28, v28, v28
     8b8:      	fmul.4s	v27, v27, v27
     8bc:      	fadd.4s	v22, v22, v27
     8c0:      	fadd.4s	v21, v21, v28
     8c4:      	ldp	q28, q27, [x20, #0xc0]
     8c8:      	fmul.4s	v28, v28, v28
     8cc:      	fmul.4s	v27, v27, v27
     8d0:      	fadd.4s	v23, v23, v27
     8d4:      	fadd.4s	v24, v24, v28
     8d8:      	ldp	q28, q27, [x20, #0xe0]
     8dc:      	fmul.4s	v28, v28, v28
     8e0:      	fmul.4s	v27, v27, v27
     8e4:      	fadd.4s	v26, v26, v27
     8e8:      	fadd.4s	v25, v25, v28
     8ec:      	add	x19, x19, #0x4
     8f0:      	cmp	x19, #0x2fc
     8f4:      	b.lo	0x898 <ltmp0+0x898>
     8f8:      	mov	x19, #0x0               ; =0
     8fc:      	add	x20, x7, x19, lsl #2
     900:      	ld1r.4s	{ v27 }, [x20]
     904:      	add	x20, x14, x19, lsl #5
     908:      	stp	q27, q27, [x20]
     90c:      	add	x19, x19, #0x1
     910:      	cmp	x19, #0x300
     914:      	b.ne	0x8fc <ltmp0+0x8fc>
     918:      	mov	x7, #0x0                ; =0
     91c:      	fadd.4s	v20, v20, v22
     920:      	fadd.4s	v6, v6, v21
     924:      	fadd.4s	v6, v6, v24
     928:      	fadd.4s	v20, v20, v23
     92c:      	fadd.4s	v20, v20, v26
     930:      	fadd.4s	v6, v6, v25
     934:      	fdiv.4s	v6, v6, v5
     938:      	fdiv.4s	v5, v20, v5
     93c:      	fadd.4s	v5, v5, v4
     940:      	fadd.4s	v4, v6, v4
     944:      	fsqrt.4s	v4, v4
     948:      	fsqrt.4s	v5, v5
     94c:      	dup.2d	v6, x7
     950:      	add.2d	v20, v6, v16
     954:      	add.2d	v21, v6, v18
     958:      	add.2d	v22, v6, v17
     95c:      	add.2d	v6, v6, v19
     960:      	lsl	x19, x7, #5
     964:      	add	x20, x9, x19
     968:      	ldp	q24, q23, [x20]
     96c:      	fdiv.4s	v24, v24, v4
     970:      	fdiv.4s	v23, v23, v5
     974:      	add	x19, x14, x19
     978:      	ldp	q25, q26, [x19]
     97c:      	fmul.4s	v23, v23, v26
     980:      	fmul.4s	v24, v24, v25
     984:      	shl.2d	v6, v6, #0x2
     988:      	shl.2d	v22, v22, #0x2
     98c:      	shl.2d	v21, v21, #0x2
     990:      	shl.2d	v20, v20, #0x2
     994:      	add.2d	v20, v7, v20
     998:      	add.2d	v6, v7, v6
     99c:      	mov.d	x19, v6[1]
     9a0:      	fmov	x20, d6
     9a4:      	str	s24, [x20]
     9a8:      	st1.s	{ v24 }[1], [x19]
     9ac:      	add.2d	v6, v7, v22
     9b0:      	mov.d	x19, v6[1]
     9b4:      	fmov	x20, d6
     9b8:      	st1.s	{ v24 }[2], [x20]
     9bc:      	add.2d	v6, v7, v21
     9c0:      	st1.s	{ v24 }[3], [x19]
     9c4:      	mov.d	x19, v6[1]
     9c8:      	fmov	x20, d6
     9cc:      	str	s23, [x20]
     9d0:      	st1.s	{ v23 }[1], [x19]
     9d4:      	mov.d	x19, v20[1]
     9d8:      	fmov	x20, d20
     9dc:      	st1.s	{ v23 }[2], [x20]
     9e0:      	st1.s	{ v23 }[3], [x19]
     9e4:      	add	x7, x7, #0x1
     9e8:      	cmp	x7, #0x300
     9ec:      	b.ne	0x94c <ltmp0+0x94c>
     9f0:      	b	0x84 <ltmp0+0x84>
     9f4:      	lsr	x7, x19, #3
     9f8:      	cmp	x19, #0x8
     9fc:      	b.lo	0xc60 <ltmp0+0xc60>
     a00:      	mov	w20, #0x0               ; =0
     a04:      	ldr	x21, [x0]
     a08:      	ldr	x22, [x0, #0x10]
     a0c:      	lsl	w23, w6, #5
     a10:      	ldr	x24, [x0, #0x30]
     a14:      	mov	x25, #0x0               ; =0
     a18:      	add	w26, w23, w20, lsl #3
     a1c:      	dup.4s	v6, w26
     a20:      	orr.16b	v16, v6, v0
     a24:      	orr.16b	v17, v6, v1
     a28:      	umull2.2d	v6, v16, v2
     a2c:      	umull2.2d	v7, v17, v2
     a30:      	umull.2d	v16, v16, v3
     a34:      	umull.2d	v17, v17, v3
     a38:      	dup.2d	v18, x25
     a3c:      	add.2d	v19, v18, v6
     a40:      	add.2d	v20, v18, v16
     a44:      	add.2d	v21, v18, v7
     a48:      	add.2d	v18, v18, v17
     a4c:      	shl.2d	v18, v18, #0x2
     a50:      	shl.2d	v21, v21, #0x2
     a54:      	shl.2d	v20, v20, #0x2
     a58:      	shl.2d	v19, v19, #0x2
     a5c:      	dup.2d	v22, x21
     a60:      	add.2d	v19, v22, v19
     a64:      	add.2d	v20, v22, v20
     a68:      	add.2d	v21, v22, v21
     a6c:      	add.2d	v18, v22, v18
     a70:      	mov.d	x26, v18[1]
     a74:      	fmov	x27, d18
     a78:      	mov.d	x28, v21[1]
     a7c:      	fmov	x30, d21
     a80:      	mov.d	x12, v20[1]
     a84:      	fmov	x13, d20
     a88:      	mov.d	x2, v19[1]
     a8c:      	ldr	s18, [x13]
     a90:      	ld1.s	{ v18 }[1], [x12]
     a94:      	fmov	x12, d19
     a98:      	ld1.s	{ v18 }[2], [x12]
     a9c:      	ld1.s	{ v18 }[3], [x2]
     aa0:      	ldr	s19, [x27]
     aa4:      	ld1.s	{ v19 }[1], [x26]
     aa8:      	ld1.s	{ v19 }[2], [x30]
     aac:      	ld1.s	{ v19 }[3], [x28]
     ab0:      	add	x12, x9, x25, lsl #5
     ab4:      	stp	q19, q18, [x12]
     ab8:      	add	x25, x25, #0x1
     abc:      	cmp	x25, #0x300
     ac0:      	b.ne	0xa38 <ltmp0+0xa38>
     ac4:      	mov	x25, #0x0               ; =0
     ac8:      	ldp	q18, q19, [x9]
     acc:      	fmul.4s	v19, v19, v19
     ad0:      	fmul.4s	v18, v18, v18
     ad4:      	ldp	q20, q21, [x9, #0x20]
     ad8:      	fmul.4s	v21, v21, v21
     adc:      	fmul.4s	v20, v20, v20
     ae0:      	ldp	q23, q22, [x9, #0x40]
     ae4:      	fmul.4s	v22, v22, v22
     ae8:      	fmul.4s	v23, v23, v23
     aec:      	ldp	q24, q25, [x9, #0x60]
     af0:      	fmul.4s	v25, v25, v25
     af4:      	fmul.4s	v24, v24, v24
     af8:      	add	x12, x9, x25, lsl #5
     afc:      	ldp	q27, q26, [x12, #0x80]
     b00:      	fmul.4s	v27, v27, v27
     b04:      	fmul.4s	v26, v26, v26
     b08:      	fadd.4s	v19, v19, v26
     b0c:      	fadd.4s	v18, v18, v27
     b10:      	ldp	q27, q26, [x12, #0xa0]
     b14:      	fmul.4s	v27, v27, v27
     b18:      	fmul.4s	v26, v26, v26
     b1c:      	fadd.4s	v21, v21, v26
     b20:      	fadd.4s	v20, v20, v27
     b24:      	ldp	q27, q26, [x12, #0xc0]
     b28:      	fmul.4s	v27, v27, v27
     b2c:      	fmul.4s	v26, v26, v26
     b30:      	fadd.4s	v22, v22, v26
     b34:      	fadd.4s	v23, v23, v27
     b38:      	ldp	q27, q26, [x12, #0xe0]
     b3c:      	fmul.4s	v27, v27, v27
     b40:      	fmul.4s	v26, v26, v26
     b44:      	fadd.4s	v25, v25, v26
     b48:      	fadd.4s	v24, v24, v27
     b4c:      	add	x25, x25, #0x4
     b50:      	cmp	x25, #0x2fc
     b54:      	b.lo	0xaf8 <ltmp0+0xaf8>
     b58:      	mov	x25, #0x0               ; =0
     b5c:      	add	x12, x22, x25, lsl #2
     b60:      	ld1r.4s	{ v26 }, [x12]
     b64:      	add	x12, x14, x25, lsl #5
     b68:      	stp	q26, q26, [x12]
     b6c:      	add	x25, x25, #0x1
     b70:      	cmp	x25, #0x300
     b74:      	b.ne	0xb5c <ltmp0+0xb5c>
     b78:      	mov	x25, #0x0               ; =0
     b7c:      	fadd.4s	v19, v19, v21
     b80:      	fadd.4s	v18, v18, v20
     b84:      	fadd.4s	v18, v18, v23
     b88:      	fadd.4s	v19, v19, v22
     b8c:      	fadd.4s	v19, v19, v25
     b90:      	fadd.4s	v18, v18, v24
     b94:      	fdiv.4s	v18, v18, v5
     b98:      	fdiv.4s	v19, v19, v5
     b9c:      	fadd.4s	v19, v19, v4
     ba0:      	fadd.4s	v18, v18, v4
     ba4:      	fsqrt.4s	v18, v18
     ba8:      	fsqrt.4s	v19, v19
     bac:      	dup.2d	v20, x25
     bb0:      	add.2d	v21, v20, v6
     bb4:      	add.2d	v22, v20, v16
     bb8:      	add.2d	v23, v20, v7
     bbc:      	add.2d	v20, v20, v17
     bc0:      	lsl	x12, x25, #5
     bc4:      	add	x13, x9, x12
     bc8:      	ldp	q25, q24, [x13]
     bcc:      	fdiv.4s	v25, v25, v18
     bd0:      	fdiv.4s	v24, v24, v19
     bd4:      	add	x12, x14, x12
     bd8:      	ldp	q26, q27, [x12]
     bdc:      	fmul.4s	v24, v24, v27
     be0:      	fmul.4s	v25, v25, v26
     be4:      	shl.2d	v20, v20, #0x2
     be8:      	shl.2d	v23, v23, #0x2
     bec:      	shl.2d	v22, v22, #0x2
     bf0:      	shl.2d	v21, v21, #0x2
     bf4:      	dup.2d	v26, x24
     bf8:      	add.2d	v21, v26, v21
     bfc:      	add.2d	v20, v26, v20
     c00:      	mov.d	x12, v20[1]
     c04:      	fmov	x13, d20
     c08:      	str	s25, [x13]
     c0c:      	st1.s	{ v25 }[1], [x12]
     c10:      	add.2d	v20, v26, v23
     c14:      	mov.d	x12, v20[1]
     c18:      	fmov	x13, d20
     c1c:      	st1.s	{ v25 }[2], [x13]
     c20:      	add.2d	v20, v26, v22
     c24:      	st1.s	{ v25 }[3], [x12]
     c28:      	mov.d	x12, v20[1]
     c2c:      	fmov	x13, d20
     c30:      	str	s24, [x13]
     c34:      	st1.s	{ v24 }[1], [x12]
     c38:      	mov.d	x12, v21[1]
     c3c:      	fmov	x13, d21
     c40:      	st1.s	{ v24 }[2], [x13]
     c44:      	st1.s	{ v24 }[3], [x12]
     c48:      	add	x25, x25, #0x1
     c4c:      	cmp	x25, #0x300
     c50:      	b.ne	0xbac <ltmp0+0xbac>
     c54:      	add	w20, w20, #0x1
     c58:      	cmp	w20, w7
     c5c:      	b.ne	0xa14 <ltmp0+0xa14>
     c60:      	and	w19, w19, #0x7
     c64:      	cbz	w19, 0x84 <ltmp0+0x84>
     c68:      	dup.4s	v7, w19
     c6c:      	cmhi.4s	v6, v7, v0
     c70:      	cmhi.4s	v7, v7, v1
     c74:      	uzp1.8h	v21, v7, v6
     c78:      	umaxv.8h	h16, v21
     c7c:      	fmov	w12, s16
     c80:      	tbz	w12, #0x0, 0x84 <ltmp0+0x84>
     c84:      	mov	x20, #0x0               ; =0
     c88:      	ldr	x21, [x0]
     c8c:      	ldr	x19, [x0, #0x10]
     c90:      	lsl	w12, w7, #3
     c94:      	orr	w12, w12, w6, lsl #5
     c98:      	dup.4s	v16, w12
     c9c:      	ldr	x7, [x0, #0x30]
     ca0:      	orr.16b	v17, v16, v1
     ca4:      	orr.16b	v16, v16, v0
     ca8:      	and.16b	v18, v6, v16
     cac:      	and.16b	v19, v7, v17
     cb0:      	umull2.2d	v16, v18, v2
     cb4:      	umull2.2d	v17, v19, v2
     cb8:      	umull.2d	v18, v18, v3
     cbc:      	umull.2d	v19, v19, v3
     cc0:      	b	0xce4 <ltmp0+0xce4>
     cc4:      	add	x12, x9, x20, lsl #5
     cc8:      	ldp	q24, q25, [x12]
     ccc:      	bif.16b	v23, v25, v6
     cd0:      	bif.16b	v22, v24, v7
     cd4:      	stp	q22, q23, [x12]
     cd8:      	add	x20, x20, #0x1
     cdc:      	cmp	x20, #0x300
     ce0:      	b.eq	0xde4 <ltmp0+0xde4>
     ce4:      	ldr	q20, [x17]
     ce8:      	and.16b	v20, v21, v20
     cec:      	addv.8h	h20, v20
     cf0:      	fmov	w22, s20
     cf4:      	dup.2d	v24, x20
     cf8:      	add.2d	v22, v24, v19
     cfc:      	shl.2d	v22, v22, #0x2
     d00:      	dup.2d	v25, x21
     d04:      	add.2d	v26, v25, v22
     d08:      	movi.2d	v22, #0000000000000000
     d0c:      	movi.2d	v23, #0000000000000000
     d10:      	tbnz	w22, #0x0, 0xd5c <ltmp0+0xd5c>
     d14:      	and	w22, w22, #0xff
     d18:      	tbnz	w22, #0x1, 0xd6c <ltmp0+0xd6c>
     d1c:      	add.2d	v26, v24, v17
     d20:      	shl.2d	v26, v26, #0x2
     d24:      	add.2d	v26, v25, v26
     d28:      	tbnz	w22, #0x2, 0xd84 <ltmp0+0xd84>
     d2c:      	tbnz	w22, #0x3, 0xd90 <ltmp0+0xd90>
     d30:      	add.2d	v26, v24, v18
     d34:      	shl.2d	v26, v26, #0x2
     d38:      	add.2d	v26, v25, v26
     d3c:      	tbnz	w22, #0x4, 0xda8 <ltmp0+0xda8>
     d40:      	tbnz	w22, #0x5, 0xdb4 <ltmp0+0xdb4>
     d44:      	add.2d	v24, v24, v16
     d48:      	shl.2d	v24, v24, #0x2
     d4c:      	add.2d	v24, v25, v24
     d50:      	tbnz	w22, #0x6, 0xdcc <ltmp0+0xdcc>
     d54:      	tbz	w22, #0x7, 0xcc4 <ltmp0+0xcc4>
     d58:      	b	0xdd8 <ltmp0+0xdd8>
     d5c:      	fmov	x12, d26
     d60:      	ldr	s22, [x12]
     d64:      	and	w22, w22, #0xff
     d68:      	tbz	w22, #0x1, 0xd1c <ltmp0+0xd1c>
     d6c:      	mov.d	x12, v26[1]
     d70:      	ld1.s	{ v22 }[1], [x12]
     d74:      	add.2d	v26, v24, v17
     d78:      	shl.2d	v26, v26, #0x2
     d7c:      	add.2d	v26, v25, v26
     d80:      	tbz	w22, #0x2, 0xd2c <ltmp0+0xd2c>
     d84:      	fmov	x12, d26
     d88:      	ld1.s	{ v22 }[2], [x12]
     d8c:      	tbz	w22, #0x3, 0xd30 <ltmp0+0xd30>
     d90:      	mov.d	x12, v26[1]
     d94:      	ld1.s	{ v22 }[3], [x12]
     d98:      	add.2d	v26, v24, v18
     d9c:      	shl.2d	v26, v26, #0x2
     da0:      	add.2d	v26, v25, v26
     da4:      	tbz	w22, #0x4, 0xd40 <ltmp0+0xd40>
     da8:      	fmov	x12, d26
     dac:      	ld1.s	{ v23 }[0], [x12]
     db0:      	tbz	w22, #0x5, 0xd44 <ltmp0+0xd44>
     db4:      	mov.d	x12, v26[1]
     db8:      	ld1.s	{ v23 }[1], [x12]
     dbc:      	add.2d	v24, v24, v16
     dc0:      	shl.2d	v24, v24, #0x2
     dc4:      	add.2d	v24, v25, v24
     dc8:      	tbz	w22, #0x6, 0xd54 <ltmp0+0xd54>
     dcc:      	fmov	x12, d24
     dd0:      	ld1.s	{ v23 }[2], [x12]
     dd4:      	tbz	w22, #0x7, 0xcc4 <ltmp0+0xcc4>
     dd8:      	mov.d	x12, v24[1]
     ddc:      	ld1.s	{ v23 }[3], [x12]
     de0:      	b	0xcc4 <ltmp0+0xcc4>
     de4:      	ldp	q22, q21, [x9]
     de8:      	fmul.4s	v22, v22, v22
     dec:      	fmul.4s	v21, v21, v21
     df0:      	ldp	q24, q23, [x9, #0x20]
     df4:      	fmul.4s	v25, v24, v24
     df8:      	fmul.4s	v23, v23, v23
     dfc:      	ldp	q26, q24, [x9, #0x40]
     e00:      	fmul.4s	v27, v26, v26
     e04:      	fmul.4s	v26, v24, v24
     e08:      	ldp	q28, q24, [x9, #0x60]
     e0c:      	fmul.4s	v29, v28, v28
     e10:      	fmul.4s	v30, v24, v24
     e14:      	and.16b	v21, v6, v21
     e18:      	and.16b	v24, v7, v22
     e1c:      	and.16b	v23, v6, v23
     e20:      	and.16b	v28, v7, v25
     e24:      	and.16b	v26, v6, v26
     e28:      	and.16b	v25, v7, v27
     e2c:      	and.16b	v22, v6, v30
     e30:      	and.16b	v27, v7, v29
     e34:      	ldr	x20, [sp, #0x10]
     e38:      	mov	w21, #0x4               ; =4
     e3c:      	ldp	q30, q29, [x20, #-0x60]
     e40:      	and.16b	v30, v7, v30
     e44:      	and.16b	v29, v6, v29
     e48:      	fmul.4s	v29, v29, v29
     e4c:      	fmul.4s	v30, v30, v30
     e50:      	fadd.4s	v30, v24, v30
     e54:      	fadd.4s	v29, v21, v29
     e58:      	ldp	q8, q31, [x20, #-0x40]
     e5c:      	and.16b	v8, v7, v8
     e60:      	and.16b	v31, v6, v31
     e64:      	fmul.4s	v31, v31, v31
     e68:      	fmul.4s	v8, v8, v8
     e6c:      	fadd.4s	v8, v28, v8
     e70:      	fadd.4s	v31, v23, v31
     e74:      	ldp	q10, q9, [x20, #-0x20]
     e78:      	and.16b	v10, v7, v10
     e7c:      	and.16b	v9, v6, v9
     e80:      	fmul.4s	v9, v9, v9
     e84:      	fmul.4s	v10, v10, v10
     e88:      	fadd.4s	v10, v25, v10
     e8c:      	fadd.4s	v9, v26, v9
     e90:      	ldp	q12, q11, [x20], #0x80
     e94:      	and.16b	v12, v7, v12
     e98:      	and.16b	v11, v6, v11
     e9c:      	fmul.4s	v11, v11, v11
     ea0:      	fmul.4s	v12, v12, v12
     ea4:      	fadd.4s	v12, v27, v12
     ea8:      	fadd.4s	v11, v22, v11
     eac:      	bit.16b	v21, v29, v6
     eb0:      	bit.16b	v24, v30, v7
     eb4:      	bit.16b	v23, v31, v6
     eb8:      	bit.16b	v28, v8, v7
     ebc:      	bit.16b	v26, v9, v6
     ec0:      	bit.16b	v25, v10, v7
     ec4:      	bit.16b	v22, v11, v6
     ec8:      	bit.16b	v27, v12, v7
     ecc:      	cmp	x21, #0x2fc
     ed0:      	add	x21, x21, #0x4
     ed4:      	b.lo	0xe3c <ltmp0+0xe3c>
     ed8:      	mov	x20, #0x0               ; =0
     edc:      	add	x12, x19, x20, lsl #2
     ee0:      	ld1r.4s	{ v29 }, [x12]
     ee4:      	add	x12, x14, x20, lsl #5
     ee8:      	ldp	q30, q31, [x12]
     eec:      	bit.16b	v31, v29, v6
     ef0:      	bif.16b	v29, v30, v7
     ef4:      	stp	q29, q31, [x12]
     ef8:      	add	x20, x20, #0x1
     efc:      	cmp	x20, #0x300
     f00:      	b.ne	0xedc <ltmp0+0xedc>
     f04:      	mov	x19, #0x0               ; =0
     f08:      	fadd.4s	v24, v24, v28
     f0c:      	fadd.4s	v21, v21, v23
     f10:      	fadd.4s	v21, v21, v26
     f14:      	fadd.4s	v23, v24, v25
     f18:      	fadd.4s	v23, v23, v27
     f1c:      	fadd.4s	v21, v21, v22
     f20:      	fdiv.4s	v21, v21, v5
     f24:      	fdiv.4s	v5, v23, v5
     f28:      	fadd.4s	v5, v5, v4
     f2c:      	fadd.4s	v4, v21, v4
     f30:      	fsqrt.4s	v21, v4
     f34:      	fsqrt.4s	v4, v5
     f38:      	and.16b	v4, v7, v4
     f3c:      	and.16b	v5, v6, v21
     f40:      	b	0xf50 <ltmp0+0xf50>
     f44:      	add	x19, x19, #0x1
     f48:      	cmp	x19, #0x300
     f4c:      	b.eq	0x84 <ltmp0+0x84>
     f50:      	fmov	w20, s20
     f54:      	dup.2d	v21, x19
     f58:      	add.2d	v22, v21, v19
     f5c:      	lsl	x12, x19, #5
     f60:      	add	x13, x9, x12
     f64:      	ldp	q24, q23, [x13]
     f68:      	and.16b	v24, v7, v24
     f6c:      	fdiv.4s	v25, v24, v4
     f70:      	add	x12, x14, x12
     f74:      	ldp	q26, q24, [x12]
     f78:      	and.16b	v26, v7, v26
     f7c:      	fmul.4s	v25, v25, v26
     f80:      	shl.2d	v26, v22, #0x2
     f84:      	dup.2d	v22, x7
     f88:      	add.2d	v26, v22, v26
     f8c:      	tbnz	w20, #0x0, 0xff0 <ltmp0+0xff0>
     f90:      	and	w20, w20, #0xff
     f94:      	tbnz	w20, #0x1, 0x1000 <ltmp0+0x1000>
     f98:      	add.2d	v26, v21, v17
     f9c:      	shl.2d	v26, v26, #0x2
     fa0:      	add.2d	v26, v22, v26
     fa4:      	tbnz	w20, #0x2, 0x1018 <ltmp0+0x1018>
     fa8:      	tbz	w20, #0x3, 0xfb4 <ltmp0+0xfb4>
     fac:      	mov.d	x12, v26[1]
     fb0:      	st1.s	{ v25 }[3], [x12]
     fb4:      	add.2d	v25, v21, v18
     fb8:      	and.16b	v23, v6, v23
     fbc:      	fdiv.4s	v23, v23, v5
     fc0:      	and.16b	v24, v6, v24
     fc4:      	fmul.4s	v23, v23, v24
     fc8:      	shl.2d	v24, v25, #0x2
     fcc:      	add.2d	v24, v22, v24
     fd0:      	tbnz	w20, #0x4, 0x1028 <ltmp0+0x1028>
     fd4:      	tbnz	w20, #0x5, 0x1034 <ltmp0+0x1034>
     fd8:      	add.2d	v21, v21, v16
     fdc:      	shl.2d	v21, v21, #0x2
     fe0:      	add.2d	v21, v22, v21
     fe4:      	tbnz	w20, #0x6, 0x104c <ltmp0+0x104c>
     fe8:      	tbz	w20, #0x7, 0xf44 <ltmp0+0xf44>
     fec:      	b	0x1058 <ltmp0+0x1058>
     ff0:      	fmov	x12, d26
     ff4:      	str	s25, [x12]
     ff8:      	and	w20, w20, #0xff
     ffc:      	tbz	w20, #0x1, 0xf98 <ltmp0+0xf98>
    1000:      	mov.d	x12, v26[1]
    1004:      	st1.s	{ v25 }[1], [x12]
    1008:      	add.2d	v26, v21, v17
    100c:      	shl.2d	v26, v26, #0x2
    1010:      	add.2d	v26, v22, v26
    1014:      	tbz	w20, #0x2, 0xfa8 <ltmp0+0xfa8>
    1018:      	fmov	x12, d26
    101c:      	st1.s	{ v25 }[2], [x12]
    1020:      	tbnz	w20, #0x3, 0xfac <ltmp0+0xfac>
    1024:      	b	0xfb4 <ltmp0+0xfb4>
    1028:      	fmov	x12, d24
    102c:      	str	s23, [x12]
    1030:      	tbz	w20, #0x5, 0xfd8 <ltmp0+0xfd8>
    1034:      	mov.d	x12, v24[1]
    1038:      	st1.s	{ v23 }[1], [x12]
    103c:      	add.2d	v21, v21, v16
    1040:      	shl.2d	v21, v21, #0x2
    1044:      	add.2d	v21, v22, v21
    1048:      	tbz	w20, #0x6, 0xfe8 <ltmp0+0xfe8>
    104c:      	fmov	x12, d21
    1050:      	st1.s	{ v23 }[2], [x12]
    1054:      	tbz	w20, #0x7, 0xf44 <ltmp0+0xf44>
    1058:      	mov.d	x12, v21[1]
    105c:      	st1.s	{ v23 }[3], [x12]
    1060:      	b	0xf44 <ltmp0+0xf44>
    1064:      	ldr	x9, [sp, #0x8]
    1068:      	stp	w6, w5, [x9]
    106c:      	str	w4, [x9, #0x8]
    1070:      	mov	w8, #0x18               ; =24
    1074:      	str	w8, [x9, #0x24]
    1078:      	add	sp, sp, #0xc, lsl #12   ; =0xc000
    107c:      	add	sp, sp, #0x20
    1080:      	ldp	x29, x30, [sp, #0x80]
    1084:      	ldp	x20, x19, [sp, #0x70]
    1088:      	ldp	x22, x21, [sp, #0x60]
    108c:      	ldp	x24, x23, [sp, #0x50]
    1090:      	ldp	x26, x25, [sp, #0x40]
    1094:      	ldp	x28, x27, [sp, #0x30]
    1098:      	ldp	d9, d8, [sp, #0x20]
    109c:      	ldp	d11, d10, [sp, #0x10]
    10a0:      	ldp	d13, d12, [sp], #0x90
    10a4:      	ret


/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/rmsnorm-129x768/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0xb0
     6b4:      	stp	d11, d10, [sp, #0x40]
     6b8:      	stp	d9, d8, [sp, #0x50]
     6bc:      	stp	x26, x25, [sp, #0x60]
     6c0:      	stp	x24, x23, [sp, #0x70]
     6c4:      	stp	x22, x21, [sp, #0x80]
     6c8:      	stp	x20, x19, [sp, #0x90]
     6cc:      	stp	x29, x30, [sp, #0xa0]
     6d0:      	add	x29, sp, #0xa0
     6d4:      	mov	x19, #0x0               ; =0
     6d8:      	str	wzr, [sp, #0x20]
     6dc:      	adrp	x20, 0x4000 <dyld_stub_binder+0x4000>
     6e0:      	ldr	x20, [x20, #0x90]
     6e4:      	add	x8, sp, #0x20
     6e8:      	str	x8, [x20]
     6ec:      	mov	w8, #0x44400000         ; =1145044992
     6f0:      	fmov	s8, w8
     6f4:      	mov	w8, #0xc5ac             ; =50604
     6f8:      	movk	w8, #0x3727, lsl #16
     6fc:      	fmov	s9, w8
     700:      	fmov	s10, #1.00000000
     704:      	b	0x71c <_kernel+0x6c>
     708:      	add	x19, x19, #0x1
     70c:      	add	x0, x0, #0xc00
     710:      	add	x3, x3, #0xc00
     714:      	cmp	x19, #0x81
     718:      	b.eq	0x7d0 <_kernel+0x120>
     71c:      	movi.2d	v0, #0000000000000000
     720:      	mov	x8, #-0x4               ; =-4
     724:      	mov	x9, x0
     728:      	ldr	q1, [x9], #0x10
     72c:      	fmul.4s	v1, v1, v1
     730:      	fadd.4s	v0, v0, v1
     734:      	add	x8, x8, #0x4
     738:      	cmp	x8, #0x2fc
     73c:      	b.lo	0x728 <_kernel+0x78>
     740:      	mov	x21, #0x0               ; =0
     744:      	dup.2d	v1, v0[1]
     748:      	fadd.4s	v0, v0, v1
     74c:      	faddp.2s	s0, v0
     750:      	str	s0, [x2, x19, lsl #2]
     754:      	mov	x22, #-0x4              ; =-4
     758:      	ldr	q2, [x0, x21]
     75c:      	ldr	s0, [x2, x19, lsl #2]
     760:      	ldr	q3, [x1, x21]
     764:      	fdiv	s0, s0, s8
     768:      	fadd	s1, s0, s9
     76c:      	fsqrt	s0, s1
     770:      	fcmp	s0, s0
     774:      	b.vs	0x79c <_kernel+0xec>
     778:      	fdiv	s0, s10, s0
     77c:      	fmul.4s	v0, v2, v0[0]
     780:      	fmul.4s	v0, v3, v0
     784:      	str	q0, [x3, x21]
     788:      	add	x22, x22, #0x4
     78c:      	add	x21, x21, #0x10
     790:      	cmp	x22, #0x2fc
     794:      	b.lo	0x758 <_kernel+0xa8>
     798:      	b	0x708 <_kernel+0x58>
     79c:      	mov.16b	v0, v1
     7a0:      	mov	x23, x3
     7a4:      	mov	x25, x2
     7a8:      	mov	x24, x1
     7ac:      	mov	x26, x0
     7b0:      	stp	q3, q2, [sp]
     7b4:      	bl	0x1770 <dyld_stub_binder+0x1770>
     7b8:      	ldp	q3, q2, [sp]
     7bc:      	mov	x0, x26
     7c0:      	mov	x1, x24
     7c4:      	mov	x2, x25
     7c8:      	mov	x3, x23
     7cc:      	b	0x778 <_kernel+0xc8>
     7d0:      	str	xzr, [x20]
     7d4:      	add	x8, sp, #0x20
     7d8:      	ldapr	w8, [x8]
     7dc:      	cbnz	w8, 0x804 <_kernel+0x154>
     7e0:      	ldp	x29, x30, [sp, #0xa0]
     7e4:      	ldp	x20, x19, [sp, #0x90]
     7e8:      	ldp	x22, x21, [sp, #0x80]
     7ec:      	ldp	x24, x23, [sp, #0x70]
     7f0:      	ldp	x26, x25, [sp, #0x60]
     7f4:      	ldp	d9, d8, [sp, #0x50]
     7f8:      	ldp	d11, d10, [sp, #0x40]
     7fc:      	add	sp, sp, #0xb0
     800:      	ret
     804:      	mov	w0, #0x10               ; =16
     808:      	bl	0x1704 <dyld_stub_binder+0x1704>
     80c:      	mov	x19, x0
     810:      	mov	w8, #0x33d              ; =829
     814:      	str	w8, [sp, #0x24]
     818:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     81c:      	add	x0, x0, #0xa40
     820:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     824:      	add	x1, x1, #0xacc
     828:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     82c:      	add	x3, x3, #0xaf7
     830:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     834:      	add	x4, x4, #0xb75
     838:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     83c:      	add	x2, x2, #0xaf4
     840:      	add	x8, sp, #0x28
     844:      	add	x5, sp, #0x24
     848:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     84c:      	add	x7, x7, #0xb77
     850:      	mov	x6, x2
     854:      	bl	0x8c8 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     858:      	mov	w21, #0x1               ; =1
     85c:      	add	x1, sp, #0x28
     860:      	mov	x0, x19
     864:      	bl	0x1650 <dyld_stub_binder+0x1650>
     868:      	mov	w21, #0x0               ; =0
     86c:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     870:      	ldr	x1, [x1, #0x18]
     874:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     878:      	ldr	x2, [x2, #0x8]
     87c:      	mov	x0, x19
     880:      	bl	0x1734 <dyld_stub_binder+0x1734>
     884:      	brk	#0x1
     888:      	mov	x20, x0
     88c:      	ldrsb	w8, [sp, #0x3f]
     890:      	tbz	w8, #0x1f, 0x8ac <_kernel+0x1fc>
     894:      	ldr	x0, [sp, #0x28]
     898:      	ldr	x8, [sp, #0x38]
     89c:      	and	x1, x8, #0x7fffffffffffffff
     8a0:      	bl	0x16ec <dyld_stub_binder+0x16ec>
     8a4:      	tbnz	w21, #0x0, 0x8b8 <_kernel+0x208>
     8a8:      	b	0x8c0 <_kernel+0x210>
     8ac:      	cbnz	w21, 0x8b8 <_kernel+0x208>
     8b0:      	b	0x8c0 <_kernel+0x210>
     8b4:      	mov	x20, x0
     8b8:      	mov	x0, x19
     8bc:      	bl	0x1728 <dyld_stub_binder+0x1728>
     8c0:      	mov	x0, x20
     8c4:      	bl	0x1614 <dyld_stub_binder+0x1614>

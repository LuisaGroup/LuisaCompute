
/private/tmp/luisa-native-rows.LuX3yX/capture-v3/layernorm-1024x4097-l1/object/tile_xir_w8_80753_1788919111584880_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	mov	x14, #0x0               ; =0
       4:      	ldr	x15, [x1, #0x88]
       8:      	mov	x17, x15
       c:      	add	x8, x15, #0x60, lsl #12 ; =0x60000
      10:      	add	x8, x8, #0x60
      14:      	mov	x10, x8
      18:      	add	x9, x15, #0x40, lsl #12 ; =0x40000
      1c:      	add	x13, x9, #0x20
      20:      	add	x16, x15, #0x20, lsl #12 ; =0x20000
      24:      	ldr	x2, [x0]
      28:      	ldr	x12, [x0, #0x10]
      2c:      	ldr	w9, [x1]
      30:      	ldr	w11, [x1, #0x24]
      34:      	add	w1, w11, w9, lsl #5
      38:      	ldr	x11, [x0, #0x20]
      3c:      	ldr	x9, [x0, #0x30]
      40:      	dup.4s	v0, w1
      44:      	adrp	x0, 0x0 <ltmp0>
      48:      	ldr	q1, [x0]
      4c:      	add.4s	v2, v0, v1
      50:      	adrp	x0, 0x0 <ltmp0>
      54:      	ldr	q1, [x0]
      58:      	add.4s	v3, v0, v1
      5c:      	mov	w0, #0x1001             ; =4097
      60:      	dup.4s	v4, w0
      64:      	umull2.2d	v0, v2, v4
      68:      	umull2.2d	v1, v3, v4
      6c:      	umull.2d	v2, v2, v4
      70:      	umull.2d	v3, v3, v4
      74:      	dup.2d	v4, x2
      78:      	dup.2d	v5, x14
      7c:      	add.2d	v6, v5, v0
      80:      	add.2d	v7, v5, v2
      84:      	add.2d	v16, v5, v1
      88:      	add.2d	v5, v5, v3
      8c:      	shl.2d	v5, v5, #0x2
      90:      	shl.2d	v16, v16, #0x2
      94:      	shl.2d	v7, v7, #0x2
      98:      	shl.2d	v6, v6, #0x2
      9c:      	add.2d	v6, v4, v6
      a0:      	add.2d	v7, v4, v7
      a4:      	add.2d	v16, v4, v16
      a8:      	add.2d	v5, v4, v5
      ac:      	mov.d	x1, v5[1]
      b0:      	fmov	x2, d5
      b4:      	mov.d	x3, v16[1]
      b8:      	fmov	x4, d16
      bc:      	mov.d	x5, v7[1]
      c0:      	fmov	x6, d7
      c4:      	mov.d	x7, v6[1]
      c8:      	ldr	s5, [x2]
      cc:      	ld1.s	{ v5 }[1], [x1]
      d0:      	fmov	x1, d6
      d4:      	ld1.s	{ v5 }[2], [x4]
      d8:      	ld1.s	{ v5 }[3], [x3]
      dc:      	ldr	s6, [x6]
      e0:      	ld1.s	{ v6 }[1], [x5]
      e4:      	ld1.s	{ v6 }[2], [x1]
      e8:      	ld1.s	{ v6 }[3], [x7]
      ec:      	add	x1, x15, x14, lsl #5
      f0:      	stp	q5, q6, [x1]
      f4:      	add	x14, x14, #0x1
      f8:      	cmp	x14, x0
      fc:      	b.ne	0x78 <ltmp0+0x78>
     100:      	ldp	q18, q16, [x17]
     104:      	ldp	q7, q4, [x17, #0x20]
     108:      	ldp	q5, q6, [x17, #0x40]
     10c:      	add	x14, x15, #0xe0
     110:      	mov	w0, #0x4                ; =4
     114:      	ldp	q19, q17, [x17, #0x60]
     118:      	ldp	q20, q21, [x14, #-0x60]
     11c:      	fadd.4s	v16, v16, v21
     120:      	fadd.4s	v18, v18, v20
     124:      	ldp	q20, q21, [x14, #-0x40]
     128:      	fadd.4s	v4, v4, v21
     12c:      	fadd.4s	v7, v7, v20
     130:      	ldp	q20, q21, [x14, #-0x20]
     134:      	fadd.4s	v6, v6, v21
     138:      	fadd.4s	v5, v5, v20
     13c:      	ldp	q20, q21, [x14], #0x80
     140:      	fadd.4s	v17, v17, v21
     144:      	fadd.4s	v19, v19, v20
     148:      	cmp	x0, #0xffc
     14c:      	add	x0, x0, #0x4
     150:      	b.lo	0x118 <ltmp0+0x118>
     154:      	add	x14, x16, #0x20
     158:      	ldp	q21, q20, [x16]
     15c:      	fadd.4s	v18, v18, v21
     160:      	fadd.4s	v16, v16, v20
     164:      	movi.2d	v20, #0000000000000000
     168:      	fadd.4s	v16, v16, v20
     16c:      	fadd.4s	v18, v18, v20
     170:      	fadd.4s	v7, v7, v18
     174:      	fadd.4s	v4, v4, v16
     178:      	fadd.4s	v4, v6, v4
     17c:      	fadd.4s	v5, v5, v7
     180:      	fadd.4s	v5, v19, v5
     184:      	fadd.4s	v4, v17, v4
     188:      	mov	w0, #0x800              ; =2048
     18c:      	movk	w0, #0x4580, lsl #16
     190:      	dup.4s	v6, w0
     194:      	fdiv.4s	v4, v4, v6
     198:      	fdiv.4s	v5, v5, v6
     19c:      	mov	w0, #0x1001             ; =4097
     1a0:      	mov	w1, #0x20               ; =32
     1a4:      	movk	w1, #0x2, lsl #16
     1a8:      	ldp	q7, q6, [x17]
     1ac:      	fsub.4s	v7, v7, v5
     1b0:      	fsub.4s	v6, v6, v4
     1b4:      	add	x2, x17, x1
     1b8:      	stp	q7, q6, [x2]
     1bc:      	add	x17, x17, #0x20
     1c0:      	subs	x0, x0, #0x1
     1c4:      	b.ne	0x1a8 <ltmp0+0x1a8>
     1c8:      	mov	x17, #0x0               ; =0
     1cc:      	ldp	q4, q5, [x16, #0x20]
     1d0:      	ldp	q6, q7, [x16, #0x40]
     1d4:      	ldp	q17, q20, [x16, #0x60]
     1d8:      	ldp	q21, q22, [x16, #0x80]
     1dc:      	fmul.4s	v18, v5, v5
     1e0:      	fmul.4s	v19, v4, v4
     1e4:      	fmul.4s	v16, v7, v7
     1e8:      	fmul.4s	v7, v6, v6
     1ec:      	fmul.4s	v4, v20, v20
     1f0:      	fmul.4s	v17, v17, v17
     1f4:      	fmul.4s	v6, v22, v22
     1f8:      	fmul.4s	v5, v21, v21
     1fc:      	add	x15, x15, #0x20, lsl #12 ; =0x20000
     200:      	add	x15, x15, #0xe0
     204:      	add	x16, x15, x17, lsl #5
     208:      	ldp	q21, q20, [x16, #-0x40]
     20c:      	fmul.4s	v21, v21, v21
     210:      	fmul.4s	v20, v20, v20
     214:      	fadd.4s	v18, v18, v20
     218:      	fadd.4s	v19, v19, v21
     21c:      	ldp	q21, q20, [x16, #-0x20]
     220:      	fmul.4s	v21, v21, v21
     224:      	fmul.4s	v20, v20, v20
     228:      	fadd.4s	v16, v16, v20
     22c:      	fadd.4s	v7, v7, v21
     230:      	ldp	q21, q20, [x16]
     234:      	fmul.4s	v21, v21, v21
     238:      	fmul.4s	v20, v20, v20
     23c:      	fadd.4s	v4, v4, v20
     240:      	fadd.4s	v17, v17, v21
     244:      	ldp	q21, q20, [x16, #0x20]
     248:      	fmul.4s	v21, v21, v21
     24c:      	fmul.4s	v20, v20, v20
     250:      	fadd.4s	v6, v6, v20
     254:      	fadd.4s	v5, v5, v21
     258:      	add	x17, x17, #0x4
     25c:      	cmp	x17, #0xffc
     260:      	b.lo	0x204 <ltmp0+0x204>
     264:      	add	x15, x13, #0x20
     268:      	ldp	q20, q21, [x13]
     26c:      	mov	w13, #0x1001            ; =4097
     270:      	mov	x16, x15
     274:      	ld1r.4s	{ v22 }, [x12], #4
     278:      	stp	q22, q22, [x16], #0x20
     27c:      	subs	x13, x13, #0x1
     280:      	b.ne	0x274 <ltmp0+0x274>
     284:      	mov	w12, #0x1001            ; =4097
     288:      	ld1r.4s	{ v22 }, [x11], #4
     28c:      	stp	q22, q22, [x10], #0x20
     290:      	subs	x12, x12, #0x1
     294:      	b.ne	0x288 <ltmp0+0x288>
     298:      	mov	x10, #0x0               ; =0
     29c:      	fmul.4s	v21, v21, v21
     2a0:      	fmul.4s	v20, v20, v20
     2a4:      	fadd.4s	v19, v19, v20
     2a8:      	fadd.4s	v18, v18, v21
     2ac:      	mov	w11, #0x800             ; =2048
     2b0:      	movk	w11, #0x4580, lsl #16
     2b4:      	dup.4s	v20, w11
     2b8:      	mov	w11, #0xc5ac            ; =50604
     2bc:      	movk	w11, #0x3727, lsl #16
     2c0:      	dup.4s	v21, w11
     2c4:      	fadd.4s	v16, v16, v18
     2c8:      	fadd.4s	v7, v7, v19
     2cc:      	fadd.4s	v7, v17, v7
     2d0:      	fadd.4s	v4, v4, v16
     2d4:      	fadd.4s	v4, v6, v4
     2d8:      	fadd.4s	v5, v5, v7
     2dc:      	fdiv.4s	v5, v5, v20
     2e0:      	fdiv.4s	v4, v4, v20
     2e4:      	fadd.4s	v6, v4, v21
     2e8:      	fadd.4s	v4, v5, v21
     2ec:      	fsqrt.4s	v4, v4
     2f0:      	fsqrt.4s	v5, v6
     2f4:      	dup.2d	v6, x9
     2f8:      	mov	w9, #0x1001             ; =4097
     2fc:      	dup.2d	v7, x10
     300:      	add.2d	v16, v7, v0
     304:      	add.2d	v17, v7, v2
     308:      	add.2d	v18, v7, v1
     30c:      	add.2d	v7, v7, v3
     310:      	lsl	x11, x10, #5
     314:      	add	x12, x14, x11
     318:      	ldp	q19, q20, [x12]
     31c:      	fdiv.4s	v20, v20, v5
     320:      	fdiv.4s	v19, v19, v4
     324:      	add	x12, x15, x11
     328:      	ldp	q22, q21, [x12]
     32c:      	fmul.4s	v19, v19, v22
     330:      	fmul.4s	v20, v20, v21
     334:      	add	x11, x8, x11
     338:      	ldp	q21, q22, [x11]
     33c:      	fadd.4s	v20, v20, v22
     340:      	fadd.4s	v19, v19, v21
     344:      	shl.2d	v7, v7, #0x2
     348:      	shl.2d	v18, v18, #0x2
     34c:      	shl.2d	v17, v17, #0x2
     350:      	shl.2d	v16, v16, #0x2
     354:      	add.2d	v16, v6, v16
     358:      	add.2d	v7, v6, v7
     35c:      	mov.d	x11, v7[1]
     360:      	fmov	x12, d7
     364:      	str	s19, [x12]
     368:      	st1.s	{ v19 }[1], [x11]
     36c:      	add.2d	v7, v6, v18
     370:      	mov.d	x11, v7[1]
     374:      	fmov	x12, d7
     378:      	st1.s	{ v19 }[2], [x12]
     37c:      	add.2d	v7, v6, v17
     380:      	st1.s	{ v19 }[3], [x11]
     384:      	mov.d	x11, v7[1]
     388:      	fmov	x12, d7
     38c:      	str	s20, [x12]
     390:      	st1.s	{ v20 }[1], [x11]
     394:      	mov.d	x11, v16[1]
     398:      	fmov	x12, d16
     39c:      	st1.s	{ v20 }[2], [x12]
     3a0:      	st1.s	{ v20 }[3], [x11]
     3a4:      	add	x10, x10, #0x1
     3a8:      	cmp	x10, x9
     3ac:      	b.ne	0x2fc <ltmp0+0x2fc>
     3b0:      	ret

00000000000003b4 <_llm_rows.packet_batch.blocks>:
     3b4:      	sub	sp, sp, #0xd0
     3b8:      	stp	x28, x27, [sp, #0x70]
     3bc:      	stp	x26, x25, [sp, #0x80]
     3c0:      	stp	x24, x23, [sp, #0x90]
     3c4:      	stp	x22, x21, [sp, #0xa0]
     3c8:      	stp	x20, x19, [sp, #0xb0]
     3cc:      	stp	x29, x30, [sp, #0xc0]
     3d0:      	str	x0, [sp, #0x60]
     3d4:      	cbz	w3, 0xb18 <_llm_rows.packet_batch.blocks+0x764>
     3d8:      	mov	x19, x3
     3dc:      	mov	x20, x2
     3e0:      	mov	w22, #0x0               ; =0
     3e4:      	ldp	w9, w8, [x2, #0x2c]
     3e8:      	stp	w8, w9, [sp, #0x58]
     3ec:      	ldp	w27, w26, [x2]
     3f0:      	ldp	w25, w28, [x2, #0x8]
     3f4:      	mov	w23, #0x20              ; =32
     3f8:      	movk	w23, #0x2, lsl #16
     3fc:      	adrp	x8, 0x0 <ltmp0>
     400:      	ldr	q0, [x8]
     404:      	str	q0, [sp, #0x40]
     408:      	adrp	x8, 0x0 <ltmp0>
     40c:      	ldr	q0, [x8]
     410:      	str	q0, [sp, #0x30]
     414:      	mov	w24, #0x1001            ; =4097
     418:      	adrp	x8, 0x0 <ltmp0>
     41c:      	ldr	q1, [x8]
     420:      	dup.4s	v0, w24
     424:      	stp	q0, q1, [sp]
     428:      	str	w3, [sp, #0x2c]
     42c:      	b	0x474 <_llm_rows.packet_batch.blocks+0xc0>
     430:      	mov	w8, #0x18               ; =24
     434:      	str	w8, [x20, #0x24]
     438:      	ldr	w19, [sp, #0x2c]
     43c:      	add	w8, w27, #0x1
     440:      	ldp	w10, w9, [sp, #0x58]
     444:      	cmp	w8, w9
     448:      	cset	w8, eq
     44c:      	csinc	w27, wzr, w27, eq
     450:      	cinc	w9, w26, eq
     454:      	cmp	w9, w10
     458:      	cset	w10, eq
     45c:      	ands	w8, w8, w10
     460:      	csel	w26, wzr, w9, ne
     464:      	add	w25, w25, w8
     468:      	add	w22, w22, #0x1
     46c:      	cmp	w22, w19
     470:      	b.eq	0xb18 <_llm_rows.packet_batch.blocks+0x764>
     474:      	ubfiz	x8, x27, #5, #32
     478:      	cmp	x8, x28
     47c:      	csel	x9, x8, xzr, ls
     480:      	subs	x10, x28, x9
     484:      	cmp	x10, #0x20
     488:      	mov	w11, #0x20              ; =32
     48c:      	csel	x10, x10, x11, lo
     490:      	cmp	x28, x9
     494:      	stp	w27, w26, [x20]
     498:      	str	w25, [x20, #0x8]
     49c:      	str	wzr, [x20, #0x24]
     4a0:      	ccmp	x8, x28, #0x2, hi
     4a4:      	csel	x21, x10, xzr, ls
     4a8:      	cmp	x21, #0x20
     4ac:      	b.lo	0x500 <_llm_rows.packet_batch.blocks+0x14c>
     4b0:      	ldr	x21, [sp, #0x60]
     4b4:      	mov	x0, x21
     4b8:      	mov	x1, x20
     4bc:      	bl	0x4bc <_llm_rows.packet_batch.blocks+0x108>
     4c0:      	mov	w8, #0x8                ; =8
     4c4:      	str	w8, [x20, #0x24]
     4c8:      	mov	x0, x21
     4cc:      	mov	x1, x20
     4d0:      	bl	0x4d0 <_llm_rows.packet_batch.blocks+0x11c>
     4d4:      	mov	w8, #0x10               ; =16
     4d8:      	str	w8, [x20, #0x24]
     4dc:      	mov	x0, x21
     4e0:      	mov	x1, x20
     4e4:      	bl	0x4e4 <_llm_rows.packet_batch.blocks+0x130>
     4e8:      	mov	w8, #0x18               ; =24
     4ec:      	str	w8, [x20, #0x24]
     4f0:      	mov	x0, x21
     4f4:      	mov	x1, x20
     4f8:      	bl	0x4f8 <_llm_rows.packet_batch.blocks+0x144>
     4fc:      	b	0x43c <_llm_rows.packet_batch.blocks+0x88>
     500:      	lsr	x19, x21, #3
     504:      	cmp	x21, #0x8
     508:      	b.lo	0x554 <_llm_rows.packet_batch.blocks+0x1a0>
     50c:      	str	wzr, [x20, #0x24]
     510:      	ldr	x0, [sp, #0x60]
     514:      	mov	x1, x20
     518:      	bl	0x518 <_llm_rows.packet_batch.blocks+0x164>
     51c:      	cmp	x19, #0x1
     520:      	b.eq	0x554 <_llm_rows.packet_batch.blocks+0x1a0>
     524:      	mov	w8, #0x8                ; =8
     528:      	str	w8, [x20, #0x24]
     52c:      	ldr	x0, [sp, #0x60]
     530:      	mov	x1, x20
     534:      	bl	0x534 <_llm_rows.packet_batch.blocks+0x180>
     538:      	cmp	x19, #0x2
     53c:      	b.eq	0x554 <_llm_rows.packet_batch.blocks+0x1a0>
     540:      	mov	w8, #0x10               ; =16
     544:      	str	w8, [x20, #0x24]
     548:      	ldr	x0, [sp, #0x60]
     54c:      	mov	x1, x20
     550:      	bl	0x550 <_llm_rows.packet_batch.blocks+0x19c>
     554:      	and	w8, w21, #0x7
     558:      	cbz	w8, 0x430 <_llm_rows.packet_batch.blocks+0x7c>
     55c:      	dup.4s	v1, w8
     560:      	ldp	q0, q2, [sp, #0x30]
     564:      	cmhi.4s	v0, v1, v0
     568:      	cmhi.4s	v1, v1, v2
     56c:      	uzp1.8h	v6, v1, v0
     570:      	umaxv.8h	h2, v6
     574:      	fmov	w8, s2
     578:      	tbz	w8, #0x0, 0x430 <_llm_rows.packet_batch.blocks+0x7c>
     57c:      	mov	x17, #0x0               ; =0
     580:      	ldr	x15, [x20, #0x88]
     584:      	mov	w8, #0x60               ; =96
     588:      	movk	w8, #0x6, lsl #16
     58c:      	add	x8, x15, x8
     590:      	mov	w9, #0x20               ; =32
     594:      	movk	w9, #0x4, lsl #16
     598:      	add	x14, x15, x9
     59c:      	add	x16, x15, #0x20, lsl #12 ; =0x20000
     5a0:      	add	x9, x15, x23
     5a4:      	mov	w10, #0x40              ; =64
     5a8:      	movk	w10, #0x4, lsl #16
     5ac:      	add	x10, x15, x10
     5b0:      	ldr	x1, [sp, #0x60]
     5b4:      	ldr	x0, [x1]
     5b8:      	ldr	x13, [x1, #0x10]
     5bc:      	ldr	x12, [x1, #0x20]
     5c0:      	lsl	w11, w19, #3
     5c4:      	orr	w11, w11, w27, lsl #5
     5c8:      	dup.4s	v2, w11
     5cc:      	ldr	x11, [x1, #0x30]
     5d0:      	ldp	q4, q3, [sp, #0x30]
     5d4:      	orr.16b	v3, v2, v3
     5d8:      	orr.16b	v2, v2, v4
     5dc:      	and.16b	v4, v0, v2
     5e0:      	and.16b	v5, v1, v3
     5e4:      	ldr	q7, [sp]
     5e8:      	umull2.2d	v2, v4, v7
     5ec:      	umull2.2d	v3, v5, v7
     5f0:      	umull.2d	v4, v4, v7
     5f4:      	umull.2d	v5, v5, v7
     5f8:      	ldr	q7, [sp, #0x10]
     5fc:      	and.16b	v6, v6, v7
     600:      	addv.8h	h6, v6
     604:      	dup.2d	v7, x0
     608:      	fmov	w0, s6
     60c:      	b	0x630 <_llm_rows.packet_batch.blocks+0x27c>
     610:      	add	x1, x15, x17, lsl #5
     614:      	ldp	q18, q19, [x1]
     618:      	bif.16b	v17, v19, v0
     61c:      	bif.16b	v16, v18, v1
     620:      	stp	q16, q17, [x1]
     624:      	add	x17, x17, #0x1
     628:      	cmp	x17, x24
     62c:      	b.eq	0x71c <_llm_rows.packet_batch.blocks+0x368>
     630:      	dup.2d	v18, x17
     634:      	add.2d	v16, v18, v5
     638:      	shl.2d	v16, v16, #0x2
     63c:      	add.2d	v19, v7, v16
     640:      	movi.2d	v16, #0000000000000000
     644:      	movi.2d	v17, #0000000000000000
     648:      	tbnz	w0, #0x0, 0x694 <_llm_rows.packet_batch.blocks+0x2e0>
     64c:      	and	w1, w0, #0xff
     650:      	tbnz	w1, #0x1, 0x6a4 <_llm_rows.packet_batch.blocks+0x2f0>
     654:      	add.2d	v19, v18, v3
     658:      	shl.2d	v19, v19, #0x2
     65c:      	add.2d	v19, v7, v19
     660:      	tbnz	w1, #0x2, 0x6bc <_llm_rows.packet_batch.blocks+0x308>
     664:      	tbnz	w1, #0x3, 0x6c8 <_llm_rows.packet_batch.blocks+0x314>
     668:      	add.2d	v19, v18, v4
     66c:      	shl.2d	v19, v19, #0x2
     670:      	add.2d	v19, v7, v19
     674:      	tbnz	w1, #0x4, 0x6e0 <_llm_rows.packet_batch.blocks+0x32c>
     678:      	tbnz	w1, #0x5, 0x6ec <_llm_rows.packet_batch.blocks+0x338>
     67c:      	add.2d	v18, v18, v2
     680:      	shl.2d	v18, v18, #0x2
     684:      	add.2d	v18, v7, v18
     688:      	tbnz	w1, #0x6, 0x704 <_llm_rows.packet_batch.blocks+0x350>
     68c:      	tbz	w1, #0x7, 0x610 <_llm_rows.packet_batch.blocks+0x25c>
     690:      	b	0x710 <_llm_rows.packet_batch.blocks+0x35c>
     694:      	fmov	x1, d19
     698:      	ldr	s16, [x1]
     69c:      	and	w1, w0, #0xff
     6a0:      	tbz	w1, #0x1, 0x654 <_llm_rows.packet_batch.blocks+0x2a0>
     6a4:      	mov.d	x2, v19[1]
     6a8:      	ld1.s	{ v16 }[1], [x2]
     6ac:      	add.2d	v19, v18, v3
     6b0:      	shl.2d	v19, v19, #0x2
     6b4:      	add.2d	v19, v7, v19
     6b8:      	tbz	w1, #0x2, 0x664 <_llm_rows.packet_batch.blocks+0x2b0>
     6bc:      	fmov	x2, d19
     6c0:      	ld1.s	{ v16 }[2], [x2]
     6c4:      	tbz	w1, #0x3, 0x668 <_llm_rows.packet_batch.blocks+0x2b4>
     6c8:      	mov.d	x2, v19[1]
     6cc:      	ld1.s	{ v16 }[3], [x2]
     6d0:      	add.2d	v19, v18, v4
     6d4:      	shl.2d	v19, v19, #0x2
     6d8:      	add.2d	v19, v7, v19
     6dc:      	tbz	w1, #0x4, 0x678 <_llm_rows.packet_batch.blocks+0x2c4>
     6e0:      	fmov	x2, d19
     6e4:      	ld1.s	{ v17 }[0], [x2]
     6e8:      	tbz	w1, #0x5, 0x67c <_llm_rows.packet_batch.blocks+0x2c8>
     6ec:      	mov.d	x2, v19[1]
     6f0:      	ld1.s	{ v17 }[1], [x2]
     6f4:      	add.2d	v18, v18, v2
     6f8:      	shl.2d	v18, v18, #0x2
     6fc:      	add.2d	v18, v7, v18
     700:      	tbz	w1, #0x6, 0x68c <_llm_rows.packet_batch.blocks+0x2d8>
     704:      	fmov	x2, d18
     708:      	ld1.s	{ v17 }[2], [x2]
     70c:      	tbz	w1, #0x7, 0x610 <_llm_rows.packet_batch.blocks+0x25c>
     710:      	mov.d	x1, v18[1]
     714:      	ld1.s	{ v17 }[3], [x1]
     718:      	b	0x610 <_llm_rows.packet_batch.blocks+0x25c>
     71c:      	ldp	q7, q16, [x15]
     720:      	ldp	q18, q19, [x15, #0x20]
     724:      	ldp	q20, q23, [x15, #0x40]
     728:      	and.16b	v17, v0, v16
     72c:      	and.16b	v22, v1, v7
     730:      	ldp	q24, q7, [x15, #0x60]
     734:      	and.16b	v16, v0, v19
     738:      	and.16b	v21, v1, v18
     73c:      	and.16b	v19, v0, v23
     740:      	and.16b	v18, v1, v20
     744:      	and.16b	v7, v0, v7
     748:      	and.16b	v20, v1, v24
     74c:      	add	x17, x15, #0xe0
     750:      	mov	w0, #0x4                ; =4
     754:      	ldp	q24, q23, [x17, #-0x60]
     758:      	fadd.4s	v24, v22, v24
     75c:      	fadd.4s	v23, v17, v23
     760:      	ldp	q26, q25, [x17, #-0x40]
     764:      	fadd.4s	v26, v21, v26
     768:      	fadd.4s	v25, v16, v25
     76c:      	ldp	q28, q27, [x17, #-0x20]
     770:      	fadd.4s	v28, v18, v28
     774:      	fadd.4s	v27, v19, v27
     778:      	ldp	q30, q29, [x17], #0x80
     77c:      	fadd.4s	v30, v20, v30
     780:      	fadd.4s	v29, v7, v29
     784:      	bit.16b	v17, v23, v0
     788:      	bit.16b	v22, v24, v1
     78c:      	bit.16b	v16, v25, v0
     790:      	bit.16b	v21, v26, v1
     794:      	bit.16b	v19, v27, v0
     798:      	bit.16b	v18, v28, v1
     79c:      	bit.16b	v7, v29, v0
     7a0:      	bit.16b	v20, v30, v1
     7a4:      	cmp	x0, #0xffc
     7a8:      	add	x0, x0, #0x4
     7ac:      	b.lo	0x754 <_llm_rows.packet_batch.blocks+0x3a0>
     7b0:      	ldp	q23, q24, [x16]
     7b4:      	and.16b	v24, v0, v24
     7b8:      	and.16b	v23, v1, v23
     7bc:      	fadd.4s	v22, v22, v23
     7c0:      	fadd.4s	v17, v17, v24
     7c4:      	movi.2d	v23, #0000000000000000
     7c8:      	fadd.4s	v17, v17, v23
     7cc:      	fadd.4s	v22, v22, v23
     7d0:      	fadd.4s	v21, v21, v22
     7d4:      	fadd.4s	v16, v16, v17
     7d8:      	fadd.4s	v16, v19, v16
     7dc:      	fadd.4s	v17, v18, v21
     7e0:      	fadd.4s	v17, v20, v17
     7e4:      	fadd.4s	v16, v7, v16
     7e8:      	mov	w17, #0x800             ; =2048
     7ec:      	movk	w17, #0x4580, lsl #16
     7f0:      	dup.4s	v7, w17
     7f4:      	fdiv.4s	v16, v16, v7
     7f8:      	fdiv.4s	v17, v17, v7
     7fc:      	mov	x17, x15
     800:      	mov	w0, #0x1001             ; =4097
     804:      	ldp	q19, q18, [x17]
     808:      	fsub.4s	v19, v19, v17
     80c:      	fsub.4s	v18, v18, v16
     810:      	add	x1, x17, x23
     814:      	ldp	q20, q21, [x1]
     818:      	bif.16b	v18, v21, v0
     81c:      	bif.16b	v19, v20, v1
     820:      	stp	q19, q18, [x1]
     824:      	add	x17, x17, #0x20
     828:      	subs	x0, x0, #0x1
     82c:      	b.ne	0x804 <_llm_rows.packet_batch.blocks+0x450>
     830:      	mov	x17, #0x0               ; =0
     834:      	ldp	q17, q16, [x16, #0x20]
     838:      	ldp	q19, q18, [x16, #0x40]
     83c:      	ldp	q21, q20, [x16, #0x60]
     840:      	ldp	q23, q22, [x16, #0x80]
     844:      	fmul.4s	v24, v17, v17
     848:      	fmul.4s	v16, v16, v16
     84c:      	fmul.4s	v19, v19, v19
     850:      	fmul.4s	v18, v18, v18
     854:      	fmul.4s	v25, v21, v21
     858:      	fmul.4s	v26, v20, v20
     85c:      	fmul.4s	v27, v23, v23
     860:      	fmul.4s	v28, v22, v22
     864:      	and.16b	v17, v0, v16
     868:      	and.16b	v23, v1, v24
     86c:      	and.16b	v21, v0, v18
     870:      	and.16b	v20, v1, v19
     874:      	and.16b	v16, v0, v26
     878:      	and.16b	v22, v1, v25
     87c:      	and.16b	v19, v0, v28
     880:      	and.16b	v18, v1, v27
     884:      	mov	w16, #0xe0              ; =224
     888:      	movk	w16, #0x2, lsl #16
     88c:      	add	x15, x15, x16
     890:      	add	x16, x15, x17, lsl #5
     894:      	ldp	q25, q24, [x16, #-0x40]
     898:      	and.16b	v25, v1, v25
     89c:      	and.16b	v24, v0, v24
     8a0:      	fmul.4s	v24, v24, v24
     8a4:      	fmul.4s	v25, v25, v25
     8a8:      	fadd.4s	v25, v23, v25
     8ac:      	fadd.4s	v24, v17, v24
     8b0:      	ldp	q27, q26, [x16, #-0x20]
     8b4:      	and.16b	v27, v1, v27
     8b8:      	and.16b	v26, v0, v26
     8bc:      	fmul.4s	v26, v26, v26
     8c0:      	fmul.4s	v27, v27, v27
     8c4:      	fadd.4s	v27, v20, v27
     8c8:      	fadd.4s	v26, v21, v26
     8cc:      	ldp	q29, q28, [x16]
     8d0:      	and.16b	v29, v1, v29
     8d4:      	and.16b	v28, v0, v28
     8d8:      	fmul.4s	v28, v28, v28
     8dc:      	fmul.4s	v29, v29, v29
     8e0:      	fadd.4s	v29, v22, v29
     8e4:      	fadd.4s	v28, v16, v28
     8e8:      	ldp	q31, q30, [x16, #0x20]
     8ec:      	and.16b	v31, v1, v31
     8f0:      	and.16b	v30, v0, v30
     8f4:      	fmul.4s	v30, v30, v30
     8f8:      	fmul.4s	v31, v31, v31
     8fc:      	fadd.4s	v31, v18, v31
     900:      	fadd.4s	v30, v19, v30
     904:      	bit.16b	v17, v24, v0
     908:      	bit.16b	v23, v25, v1
     90c:      	bit.16b	v21, v26, v0
     910:      	bit.16b	v20, v27, v1
     914:      	bit.16b	v16, v28, v0
     918:      	bit.16b	v22, v29, v1
     91c:      	bit.16b	v19, v30, v0
     920:      	bit.16b	v18, v31, v1
     924:      	add	x17, x17, #0x4
     928:      	cmp	x17, #0xffc
     92c:      	b.lo	0x890 <_llm_rows.packet_batch.blocks+0x4dc>
     930:      	ldp	q25, q24, [x14]
     934:      	mov	x14, x10
     938:      	mov	w15, #0x1001            ; =4097
     93c:      	ld1r.4s	{ v26 }, [x13], #4
     940:      	ldp	q27, q28, [x14]
     944:      	bit.16b	v28, v26, v0
     948:      	bif.16b	v26, v27, v1
     94c:      	stp	q26, q28, [x14], #0x20
     950:      	subs	x15, x15, #0x1
     954:      	b.ne	0x93c <_llm_rows.packet_batch.blocks+0x588>
     958:      	mov	x13, x8
     95c:      	mov	w14, #0x1001            ; =4097
     960:      	ld1r.4s	{ v26 }, [x12], #4
     964:      	ldp	q27, q28, [x13]
     968:      	bit.16b	v28, v26, v0
     96c:      	bif.16b	v26, v27, v1
     970:      	stp	q26, q28, [x13], #0x20
     974:      	subs	x14, x14, #0x1
     978:      	b.ne	0x960 <_llm_rows.packet_batch.blocks+0x5ac>
     97c:      	mov	x12, #0x0               ; =0
     980:      	and.16b	v25, v1, v25
     984:      	and.16b	v24, v0, v24
     988:      	fmul.4s	v24, v24, v24
     98c:      	fmul.4s	v25, v25, v25
     990:      	fadd.4s	v23, v23, v25
     994:      	fadd.4s	v17, v17, v24
     998:      	fadd.4s	v17, v21, v17
     99c:      	fadd.4s	v20, v20, v23
     9a0:      	fadd.4s	v20, v22, v20
     9a4:      	fadd.4s	v16, v16, v17
     9a8:      	fadd.4s	v16, v19, v16
     9ac:      	fadd.4s	v17, v18, v20
     9b0:      	fdiv.4s	v17, v17, v7
     9b4:      	fdiv.4s	v7, v16, v7
     9b8:      	mov	w13, #0xc5ac            ; =50604
     9bc:      	movk	w13, #0x3727, lsl #16
     9c0:      	dup.4s	v16, w13
     9c4:      	fadd.4s	v7, v7, v16
     9c8:      	fadd.4s	v16, v17, v16
     9cc:      	fsqrt.4s	v16, v16
     9d0:      	fsqrt.4s	v7, v7
     9d4:      	and.16b	v7, v0, v7
     9d8:      	and.16b	v16, v1, v16
     9dc:      	b	0x9ec <_llm_rows.packet_batch.blocks+0x638>
     9e0:      	add	x12, x12, #0x1
     9e4:      	cmp	x12, x24
     9e8:      	b.eq	0x430 <_llm_rows.packet_batch.blocks+0x7c>
     9ec:      	fmov	w13, s6
     9f0:      	dup.2d	v17, x12
     9f4:      	add.2d	v18, v17, v5
     9f8:      	lsl	x14, x12, #5
     9fc:      	add	x15, x9, x14
     a00:      	ldp	q20, q19, [x15]
     a04:      	and.16b	v20, v1, v20
     a08:      	fdiv.4s	v21, v20, v16
     a0c:      	add	x15, x10, x14
     a10:      	ldp	q22, q20, [x15]
     a14:      	and.16b	v22, v1, v22
     a18:      	fmul.4s	v22, v21, v22
     a1c:      	add	x14, x8, x14
     a20:      	ldp	q23, q21, [x14]
     a24:      	and.16b	v23, v1, v23
     a28:      	fadd.4s	v22, v22, v23
     a2c:      	shl.2d	v23, v18, #0x2
     a30:      	dup.2d	v18, x11
     a34:      	add.2d	v23, v18, v23
     a38:      	tbnz	w13, #0x0, 0xaa4 <_llm_rows.packet_batch.blocks+0x6f0>
     a3c:      	and	w13, w13, #0xff
     a40:      	tbnz	w13, #0x1, 0xab4 <_llm_rows.packet_batch.blocks+0x700>
     a44:      	add.2d	v23, v17, v3
     a48:      	shl.2d	v23, v23, #0x2
     a4c:      	add.2d	v23, v18, v23
     a50:      	tbnz	w13, #0x2, 0xacc <_llm_rows.packet_batch.blocks+0x718>
     a54:      	tbz	w13, #0x3, 0xa60 <_llm_rows.packet_batch.blocks+0x6ac>
     a58:      	mov.d	x14, v23[1]
     a5c:      	st1.s	{ v22 }[3], [x14]
     a60:      	add.2d	v22, v17, v4
     a64:      	and.16b	v19, v0, v19
     a68:      	fdiv.4s	v19, v19, v7
     a6c:      	and.16b	v20, v0, v20
     a70:      	fmul.4s	v19, v19, v20
     a74:      	and.16b	v20, v0, v21
     a78:      	fadd.4s	v19, v19, v20
     a7c:      	shl.2d	v20, v22, #0x2
     a80:      	add.2d	v20, v18, v20
     a84:      	tbnz	w13, #0x4, 0xadc <_llm_rows.packet_batch.blocks+0x728>
     a88:      	tbnz	w13, #0x5, 0xae8 <_llm_rows.packet_batch.blocks+0x734>
     a8c:      	add.2d	v17, v17, v2
     a90:      	shl.2d	v17, v17, #0x2
     a94:      	add.2d	v17, v18, v17
     a98:      	tbnz	w13, #0x6, 0xb00 <_llm_rows.packet_batch.blocks+0x74c>
     a9c:      	tbz	w13, #0x7, 0x9e0 <_llm_rows.packet_batch.blocks+0x62c>
     aa0:      	b	0xb0c <_llm_rows.packet_batch.blocks+0x758>
     aa4:      	fmov	x14, d23
     aa8:      	str	s22, [x14]
     aac:      	and	w13, w13, #0xff
     ab0:      	tbz	w13, #0x1, 0xa44 <_llm_rows.packet_batch.blocks+0x690>
     ab4:      	mov.d	x14, v23[1]
     ab8:      	st1.s	{ v22 }[1], [x14]
     abc:      	add.2d	v23, v17, v3
     ac0:      	shl.2d	v23, v23, #0x2
     ac4:      	add.2d	v23, v18, v23
     ac8:      	tbz	w13, #0x2, 0xa54 <_llm_rows.packet_batch.blocks+0x6a0>
     acc:      	fmov	x14, d23
     ad0:      	st1.s	{ v22 }[2], [x14]
     ad4:      	tbnz	w13, #0x3, 0xa58 <_llm_rows.packet_batch.blocks+0x6a4>
     ad8:      	b	0xa60 <_llm_rows.packet_batch.blocks+0x6ac>
     adc:      	fmov	x14, d20
     ae0:      	str	s19, [x14]
     ae4:      	tbz	w13, #0x5, 0xa8c <_llm_rows.packet_batch.blocks+0x6d8>
     ae8:      	mov.d	x14, v20[1]
     aec:      	st1.s	{ v19 }[1], [x14]
     af0:      	add.2d	v17, v17, v2
     af4:      	shl.2d	v17, v17, #0x2
     af8:      	add.2d	v17, v18, v17
     afc:      	tbz	w13, #0x6, 0xa9c <_llm_rows.packet_batch.blocks+0x6e8>
     b00:      	fmov	x14, d17
     b04:      	st1.s	{ v19 }[2], [x14]
     b08:      	tbz	w13, #0x7, 0x9e0 <_llm_rows.packet_batch.blocks+0x62c>
     b0c:      	mov.d	x13, v17[1]
     b10:      	st1.s	{ v19 }[3], [x13]
     b14:      	b	0x9e0 <_llm_rows.packet_batch.blocks+0x62c>
     b18:      	ldp	x29, x30, [sp, #0xc0]
     b1c:      	ldp	x20, x19, [sp, #0xb0]
     b20:      	ldp	x22, x21, [sp, #0xa0]
     b24:      	ldp	x24, x23, [sp, #0x90]
     b28:      	ldp	x26, x25, [sp, #0x80]
     b2c:      	ldp	x28, x27, [sp, #0x70]
     b30:      	add	sp, sp, #0xd0
     b34:      	ret


/private/tmp/luisa-native-rows.LuX3yX/prepared-v2/layernorm-1024x4097/inductor.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000750 <_kernel>:
     750:      	sub	sp, sp, #0x1f0
     754:      	stp	d11, d10, [sp, #0x170]
     758:      	stp	d9, d8, [sp, #0x180]
     75c:      	stp	x28, x27, [sp, #0x190]
     760:      	stp	x26, x25, [sp, #0x1a0]
     764:      	stp	x24, x23, [sp, #0x1b0]
     768:      	stp	x22, x21, [sp, #0x1c0]
     76c:      	stp	x20, x19, [sp, #0x1d0]
     770:      	stp	x29, x30, [sp, #0x1e0]
     774:      	add	x29, sp, #0x1e0
     778:      	mov	x20, x4
     77c:      	mov	x21, x3
     780:      	mov	x28, #0x0               ; =0
     784:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     788:      	ldr	x8, [x8, #0x58]
     78c:      	ldr	x8, [x8]
     790:      	stur	x8, [x29, #-0x80]
     794:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     798:      	ldr	x9, [x9, #0xb0]
     79c:      	str	wzr, [sp, #0xdc]
     7a0:      	add	x8, sp, #0xdc
     7a4:      	stp	x1, x2, [sp, #0x68]
     7a8:      	add	x10, x1, #0x4, lsl #12  ; =0x4000
     7ac:      	str	x8, [x9]
     7b0:      	add	x8, x2, #0x4, lsl #12   ; =0x4000
     7b4:      	stp	x8, x10, [sp, #0x50]
     7b8:      	adrp	x26, 0x8000 <dyld_stub_binder+0x8000>
     7bc:      	add	x26, x26, #0x230
     7c0:      	mov	w19, #0x4004            ; =16388
     7c4:      	adrp	x22, 0x8000 <dyld_stub_binder+0x8000>
     7c8:      	mov	w8, #0x800              ; =2048
     7cc:      	movk	w8, #0x4580, lsl #16
     7d0:      	fmov	s8, w8
     7d4:      	mov	w8, #0xc5ac             ; =50604
     7d8:      	movk	w8, #0x3727, lsl #16
     7dc:      	fmov	s9, w8
     7e0:      	fmov	s10, #1.00000000
     7e4:      	adrp	x8, 0x2000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x110>
     7e8:      	ldr	q0, [x8, #0xd60]
     7ec:      	str	q0, [sp, #0x80]
     7f0:      	mov	w25, #0x7f800000        ; =2139095040
     7f4:      	movi.2d	v11, #0000000000000000
     7f8:      	adrp	x27, 0x8000 <dyld_stub_binder+0x8000>
     7fc:      	adrp	x23, 0x4000 <dyld_stub_binder+0x4000>
     800:      	ldr	x23, [x23, #0x88]
     804:      	str	x0, [sp, #0x78]
     808:      	str	x5, [sp, #0x60]
     80c:      	str	x5, [sp, #0x98]
     810:      	b	0x88c <_kernel+0x13c>
     814:      	ldr	x8, [sp, #0x78]
     818:      	ldr	s2, [x8, x10, lsl #2]
     81c:      	ldr	s3, [x21, x28, lsl #2]
     820:      	ldr	s0, [x20, x28, lsl #2]
     824:      	ldp	x8, x9, [sp, #0x50]
     828:      	ldr	s5, [x9]
     82c:      	ldr	s4, [x8]
     830:      	fdiv	s0, s0, s8
     834:      	fadd	s1, s0, s9
     838:      	fsqrt	s0, s1
     83c:      	fcmp	s0, s0
     840:      	b.vs	0x12cc <_kernel+0xb7c>
     844:      	fdiv	s0, s10, s0
     848:      	fsub	s1, s2, s3
     84c:      	fmul	s0, s1, s0
     850:      	fmul	s0, s5, s0
     854:      	fadd	s0, s4, s0
     858:      	ldr	x8, [sp, #0x60]
     85c:      	str	s0, [x8, x10, lsl #2]
     860:      	add	x28, x28, #0x1
     864:      	mov	w19, #0x4004            ; =16388
     868:      	ldr	x8, [sp, #0x98]
     86c:      	add	x8, x8, x19
     870:      	str	x8, [sp, #0x98]
     874:      	add	x0, x0, x19
     878:      	cmp	x28, #0x400
     87c:      	adrp	x22, 0x8000 <dyld_stub_binder+0x8000>
     880:      	mov	w25, #0x7f800000        ; =2139095040
     884:      	adrp	x27, 0x8000 <dyld_stub_binder+0x8000>
     888:      	b.eq	0x1304 <_kernel+0xbb4>
     88c:      	str	x0, [sp, #0x90]
     890:      	movi.2d	v0, #0000000000000000
     894:      	stp	q0, q0, [sp, #0x100]
     898:      	stp	q0, q0, [sp, #0xe0]
     89c:      	stp	q0, q0, [sp, #0xb0]
     8a0:      	mov	w8, #0x1                ; =1
     8a4:      	stp	x8, xzr, [sp, #0xc8]
     8a8:      	stp	xzr, xzr, [x29, #-0xc0]
     8ac:      	stur	xzr, [x29, #-0xb0]
     8b0:      	add	x0, sp, #0xb0
     8b4:      	sub	x2, x29, #0xc0
     8b8:      	mov	w1, #0x1                ; =1
     8bc:      	bl	0x1794 <__ZNSt3__16vectorI7WelfordIfENS_9allocatorIS2_EEE6assignEmRKS2_>
     8c0:      	adrp	x8, 0x8000 <dyld_stub_binder+0x8000>
     8c4:      	add	x8, x8, #0x220
     8c8:      	ldaprb	w8, [x8]
     8cc:      	tbz	w8, #0x0, 0x1218 <_kernel+0xac8>
     8d0:      	adrp	x8, 0x8000 <dyld_stub_binder+0x8000>
     8d4:      	add	x8, x8, #0x228
     8d8:      	ldaprb	w8, [x8]
     8dc:      	tbz	w8, #0x0, 0x1270 <_kernel+0xb20>
     8e0:      	mov	x10, #0x0               ; =0
     8e4:      	mov	x24, #0x0               ; =0
     8e8:      	ldr	x8, [sp, #0x78]
     8ec:      	madd	x8, x28, x19, x8
     8f0:      	add	x9, x8, #0x4, lsl #12   ; =0x4000
     8f4:      	movi.2d	v21, #0000000000000000
     8f8:      	movi.2d	v20, #0000000000000000
     8fc:      	movi.2d	v19, #0000000000000000
     900:      	adrp	x1, 0x8000 <dyld_stub_binder+0x8000>
     904:      	add	x1, x1, #0x248
     908:      	b	0x934 <_kernel+0x1e4>
     90c:      	ldr	s2, [x11, x24, lsl #2]
     910:      	fmul.4s	v2, v1, v2[0]
     914:      	add	x24, x24, #0x1
     918:      	fadd.4s	v19, v19, v2
     91c:      	fsub.4s	v0, v0, v19
     920:      	fmul.4s	v0, v1, v0
     924:      	fadd.4s	v20, v20, v0
     928:      	cmp	x10, #0xffd
     92c:      	add	x10, x10, #0x4
     930:      	b.hs	0xb4c <_kernel+0x3fc>
     934:      	cmp	x10, #0x1, lsl #12      ; =0x1000
     938:      	b.eq	0xae4 <_kernel+0x394>
     93c:      	lsl	x11, x10, #2
     940:      	ldr	q0, [x8, x11]
     944:      	ldr	x11, [x22, #0x248]
     948:      	cbz	x11, 0xac0 <_kernel+0x370>
     94c:      	cmp	x24, #0x1, lsl #12      ; =0x1000
     950:      	b.ne	0xac0 <_kernel+0x370>
     954:      	ldr	x11, [x27, #0x230]
     958:      	ldr	x12, [x11, #0x30]
     95c:      	cbz	x12, 0x9ac <_kernel+0x25c>
     960:      	ldp	q1, q2, [x11]
     964:      	fsub.4s	v3, v19, v1
     968:      	fcmeq.4s	v4, v1, v19
     96c:      	bic.16b	v3, v3, v4
     970:      	ldr	q4, [x11, #0x20]
     974:      	fadd.4s	v5, v21, v4
     978:      	fdiv.4s	v6, v21, v5
     97c:      	fcmeq.4s	v7, v5, #0.0
     980:      	bic.16b	v6, v6, v7
     984:      	fmul.4s	v7, v3, v6
     988:      	fadd.4s	v19, v1, v7
     98c:      	add	x12, x12, #0x1, lsl #12 ; =0x1000
     990:      	fadd.4s	v1, v20, v2
     994:      	fmul.4s	v2, v3, v3
     998:      	fmul.4s	v2, v4, v2
     99c:      	fmul.4s	v2, v2, v6
     9a0:      	fadd.4s	v20, v1, v2
     9a4:      	mov.16b	v21, v5
     9a8:      	b	0x9b0 <_kernel+0x260>
     9ac:      	mov	w12, #0x1000            ; =4096
     9b0:      	stp	q19, q20, [x11]
     9b4:      	str	q21, [x11, #0x20]
     9b8:      	str	x12, [x11, #0x30]
     9bc:      	ldp	x12, x11, [x1]
     9c0:      	add	x15, x11, #0x1
     9c4:      	str	x15, [x1, #0x8]
     9c8:      	and	x11, x11, #0x1
     9cc:      	movi.2d	v19, #0000000000000000
     9d0:      	cmp	x12, #0x2
     9d4:      	ccmp	x11, #0x0, #0x4, hs
     9d8:      	b.eq	0xab4 <_kernel+0x364>
     9dc:      	mov	x11, #0x0               ; =0
     9e0:      	ldr	x12, [x27, #0x230]
     9e4:      	mov	w13, #0x2               ; =2
     9e8:      	mov	x14, x15
     9ec:      	add	x15, x12, x11
     9f0:      	ldr	x16, [x15, #0x70]
     9f4:      	cbz	x16, 0xa54 <_kernel+0x304>
     9f8:      	ldr	x17, [x15, #0x30]
     9fc:      	cbz	x17, 0xa64 <_kernel+0x314>
     a00:      	add	x0, x12, x11
     a04:      	ldr	q2, [x15, #0x40]
     a08:      	ldp	q1, q3, [x0]
     a0c:      	fsub.4s	v4, v1, v2
     a10:      	fcmeq.4s	v1, v2, v1
     a14:      	bic.16b	v4, v4, v1
     a18:      	ldr	q5, [x0, #0x20]
     a1c:      	ldp	q7, q6, [x0, #0x50]
     a20:      	fadd.4s	v1, v6, v5
     a24:      	fdiv.4s	v5, v5, v1
     a28:      	fcmeq.4s	v16, v1, #0.0
     a2c:      	bic.16b	v5, v5, v16
     a30:      	fmul.4s	v16, v4, v5
     a34:      	fadd.4s	v2, v2, v16
     a38:      	add	x16, x17, x16
     a3c:      	fadd.4s	v3, v7, v3
     a40:      	fmul.4s	v4, v4, v4
     a44:      	fmul.4s	v4, v6, v4
     a48:      	fmul.4s	v4, v4, v5
     a4c:      	fadd.4s	v3, v3, v4
     a50:      	b	0xa70 <_kernel+0x320>
     a54:      	ldp	q2, q3, [x15]
     a58:      	ldr	q1, [x15, #0x20]
     a5c:      	ldr	x16, [x15, #0x30]
     a60:      	b	0xa70 <_kernel+0x320>
     a64:      	ldr	q2, [x15, #0x40]
     a68:      	add	x17, x12, x11
     a6c:      	ldp	q3, q1, [x17, #0x50]
     a70:      	str	q2, [x15, #0x40]
     a74:      	add	x12, x12, x11
     a78:      	stp	q3, q1, [x12, #0x50]
     a7c:      	str	x16, [x15, #0x70]
     a80:      	ldr	x12, [x26]
     a84:      	add	x15, x12, x11
     a88:      	str	xzr, [x15, #0x30]
     a8c:      	movi.2d	v1, #0000000000000000
     a90:      	stp	q1, q1, [x15, #0x10]
     a94:      	str	q1, [x15]
     a98:      	ldr	x15, [x26, #0x18]
     a9c:      	cmp	x13, x15
     aa0:      	b.hs	0xab4 <_kernel+0x364>
     aa4:      	lsr	x15, x14, #1
     aa8:      	add	x13, x13, #0x1
     aac:      	add	x11, x11, #0x40
     ab0:      	tbz	w14, #0x1, 0x9e8 <_kernel+0x298>
     ab4:      	mov	x24, #0x0               ; =0
     ab8:      	movi.2d	v20, #0000000000000000
     abc:      	movi.2d	v21, #0000000000000000
     ac0:      	fmov.4s	v1, #1.00000000
     ac4:      	fadd.4s	v21, v21, v1
     ac8:      	fsub.4s	v1, v0, v19
     acc:      	ldp	x11, x12, [x23]
     ad0:      	sub	x12, x12, x11
     ad4:      	cmp	x24, x12, asr #2
     ad8:      	b.lo	0x90c <_kernel+0x1bc>
     adc:      	fdiv.4s	v2, v1, v21
     ae0:      	b	0x914 <_kernel+0x1c4>
     ae4:      	stp	q21, q20, [sp, #0x20]
     ae8:      	str	q19, [sp, #0x40]
     aec:      	ldr	s0, [x9]
     af0:      	str	q0, [sp, #0xa0]
     af4:      	sub	x8, x29, #0xc0
     af8:      	add	x0, sp, #0xe0
     afc:      	add	x1, sp, #0xa0
     b00:      	adrp	x2, 0x8000 <dyld_stub_binder+0x8000>
     b04:      	add	x2, x2, #0x258
     b08:      	bl	0x157c <__Z15welford_combineIN2at3vec14CPU_CAPABILITY10VectorizedIfEELy4096EE7WelfordIT_ERS7_RS6_P13WelfordHelperIS6_XT0_EE>
     b0c:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     b10:      	ldr	x8, [x8, #0x98]
     b14:      	ldr	q0, [x8]
     b18:      	ldp	q1, q2, [x29, #-0xc0]
     b1c:      	ldp	q3, q4, [sp, #0xe0]
     b20:      	bif.16b	v1, v3, v0
     b24:      	bif.16b	v2, v4, v0
     b28:      	ldur	q3, [x29, #-0xa0]
     b2c:      	ldr	q4, [sp, #0x100]
     b30:      	bsl.16b	v0, v3, v4
     b34:      	ldur	x8, [x29, #-0x90]
     b38:      	stp	q1, q2, [sp, #0xe0]
     b3c:      	str	q0, [sp, #0x100]
     b40:      	str	x8, [sp, #0x110]
     b44:      	ldp	q20, q19, [sp, #0x30]
     b48:      	ldr	q21, [sp, #0x20]
     b4c:      	ldr	x9, [sp, #0xc8]
     b50:      	cbz	x9, 0xbe0 <_kernel+0x490>
     b54:      	mov	x8, #0x0                ; =0
     b58:      	ldr	x10, [sp, #0xb0]
     b5c:      	add	x10, x10, #0x8
     b60:      	movi.2d	v0, #0000000000000000
     b64:      	movi.2d	v1, #0000000000000000
     b68:      	movi.2d	v2, #0000000000000000
     b6c:      	b	0xb88 <_kernel+0x438>
     b70:      	ldp	s2, s1, [x10, #-0x8]
     b74:      	ldr	s0, [x10]
     b78:      	ldr	x8, [x10, #0x8]
     b7c:      	add	x10, x10, #0x18
     b80:      	subs	x9, x9, #0x1
     b84:      	b.eq	0xbf0 <_kernel+0x4a0>
     b88:      	cbz	x8, 0xb70 <_kernel+0x420>
     b8c:      	ldr	x11, [x10, #0x8]
     b90:      	cbz	x11, 0xb7c <_kernel+0x42c>
     b94:      	ldp	s3, s4, [x10, #-0x8]
     b98:      	fsub	s5, s3, s2
     b9c:      	fmov	w12, s2
     ba0:      	and	w12, w12, #0x7fffffff
     ba4:      	fcmp	s2, s3
     ba8:      	ccmp	w12, w25, #0x0, eq
     bac:      	fcsel	s3, s11, s5, eq
     bb0:      	ldr	s5, [x10]
     bb4:      	fmul	s6, s3, s3
     bb8:      	fmul	s6, s0, s6
     bbc:      	fadd	s0, s0, s5
     bc0:      	add	x8, x11, x8
     bc4:      	fdiv	s5, s5, s0
     bc8:      	fmul	s3, s3, s5
     bcc:      	fadd	s2, s2, s3
     bd0:      	fadd	s1, s1, s4
     bd4:      	fmul	s3, s5, s6
     bd8:      	fadd	s1, s1, s3
     bdc:      	b	0xb7c <_kernel+0x42c>
     be0:      	mov	x8, #0x0                ; =0
     be4:      	movi.2d	v0, #0000000000000000
     be8:      	movi.2d	v1, #0000000000000000
     bec:      	movi.2d	v2, #0000000000000000
     bf0:      	ldr	x9, [x22, #0x248]
     bf4:      	cbz	x9, 0xc70 <_kernel+0x520>
     bf8:      	ldr	x10, [x27, #0x230]
     bfc:      	add	x10, x10, #0x20
     c00:      	b	0xc1c <_kernel+0x4cc>
     c04:      	ldp	q19, q20, [x10, #-0x20]
     c08:      	ldr	q21, [x10]
     c0c:      	ldr	x24, [x10, #0x10]
     c10:      	add	x10, x10, #0x40
     c14:      	subs	x9, x9, #0x1
     c18:      	b.eq	0xc70 <_kernel+0x520>
     c1c:      	cbz	x24, 0xc04 <_kernel+0x4b4>
     c20:      	ldr	x11, [x10, #0x10]
     c24:      	cbz	x11, 0xc10 <_kernel+0x4c0>
     c28:      	ldp	q3, q4, [x10, #-0x20]
     c2c:      	fsub.4s	v5, v3, v19
     c30:      	fcmeq.4s	v3, v19, v3
     c34:      	bic.16b	v3, v5, v3
     c38:      	ldr	q5, [x10]
     c3c:      	fmul.4s	v6, v3, v3
     c40:      	fmul.4s	v6, v21, v6
     c44:      	fadd.4s	v21, v21, v5
     c48:      	fdiv.4s	v5, v5, v21
     c4c:      	fcmeq.4s	v16, v21, #0.0
     c50:      	bic.16b	v5, v5, v16
     c54:      	add	x24, x11, x24
     c58:      	fmul.4s	v3, v3, v5
     c5c:      	fadd.4s	v19, v19, v3
     c60:      	fadd.4s	v3, v20, v4
     c64:      	fmul.4s	v4, v6, v5
     c68:      	fadd.4s	v20, v3, v4
     c6c:      	b	0xc10 <_kernel+0x4c0>
     c70:      	adrp	x9, 0x8000 <dyld_stub_binder+0x8000>
     c74:      	ldr	x9, [x9, #0x270]
     c78:      	cbz	x9, 0xd10 <_kernel+0x5c0>
     c7c:      	ldr	x10, [sp, #0x110]
     c80:      	adrp	x11, 0x8000 <dyld_stub_binder+0x8000>
     c84:      	ldr	x11, [x11, #0x258]
     c88:      	ldp	q4, q5, [sp, #0xf0]
     c8c:      	ldr	q3, [sp, #0xe0]
     c90:      	add	x11, x11, #0x20
     c94:      	b	0xcbc <_kernel+0x56c>
     c98:      	ldp	q3, q4, [x11, #-0x20]
     c9c:      	ldr	q5, [x11]
     ca0:      	ldr	x10, [x11, #0x10]
     ca4:      	stp	q3, q4, [sp, #0xe0]
     ca8:      	str	q5, [sp, #0x100]
     cac:      	add	x11, x11, #0x40
     cb0:      	str	x10, [sp, #0x110]
     cb4:      	subs	x9, x9, #0x1
     cb8:      	b.eq	0xd10 <_kernel+0x5c0>
     cbc:      	cbz	x10, 0xc98 <_kernel+0x548>
     cc0:      	ldr	x12, [x11, #0x10]
     cc4:      	cbz	x12, 0xca4 <_kernel+0x554>
     cc8:      	ldp	q6, q7, [x11, #-0x20]
     ccc:      	fsub.4s	v16, v6, v3
     cd0:      	fcmeq.4s	v6, v3, v6
     cd4:      	bic.16b	v6, v16, v6
     cd8:      	ldr	q16, [x11]
     cdc:      	fmul.4s	v17, v6, v6
     ce0:      	fmul.4s	v17, v5, v17
     ce4:      	fadd.4s	v5, v5, v16
     ce8:      	fdiv.4s	v16, v16, v5
     cec:      	fcmeq.4s	v18, v5, #0.0
     cf0:      	bic.16b	v16, v16, v18
     cf4:      	add	x10, x12, x10
     cf8:      	fmul.4s	v6, v6, v16
     cfc:      	fadd.4s	v3, v3, v6
     d00:      	fadd.4s	v4, v4, v7
     d04:      	fmul.4s	v6, v17, v16
     d08:      	fadd.4s	v4, v4, v6
     d0c:      	b	0xca4 <_kernel+0x554>
     d10:      	ldr	x9, [sp, #0x110]
     d14:      	cbz	x9, 0xe04 <_kernel+0x6b4>
     d18:      	ldp	q4, q3, [sp, #0xe0]
     d1c:      	ucvtf	s6, x9
     d20:      	dup.4s	v5, v6[0]
     d24:      	ldr	q7, [sp, #0x100]
     d28:      	fcmeq.4s	v16, v7, v5
     d2c:      	ldr	q17, [sp, #0x80]
     d30:      	and.16b	v16, v16, v17
     d34:      	addv.4s	s16, v16
     d38:      	fmov	w10, s16
     d3c:      	cmp	w10, #0xf
     d40:      	b.ne	0xe20 <_kernel+0x6d0>
     d44:      	trn2.4s	v7, v3, v3
     d48:      	trn2.4s	v16, v4, v4
     d4c:      	fsub.4s	v17, v16, v4
     d50:      	fcmeq.4s	v16, v4, v16
     d54:      	fadd	s6, s6, s6
     d58:      	dup.4s	v6, v6[0]
     d5c:      	bic.16b	v16, v17, v16
     d60:      	lsl	x9, x9, #1
     d64:      	fdiv.4s	v17, v5, v6
     d68:      	fcmeq.4s	v6, v6, #0.0
     d6c:      	bic.16b	v17, v17, v6
     d70:      	fmul.4s	v6, v16, v17
     d74:      	fadd.4s	v6, v4, v6
     d78:      	fadd.4s	v3, v3, v7
     d7c:      	fmul.4s	v4, v16, v16
     d80:      	fmul.4s	v4, v4, v5[0]
     d84:      	fmul.4s	v4, v4, v17
     d88:      	fadd.4s	v7, v3, v4
     d8c:      	mov.16b	v5, v6
     d90:      	mov.s	v5[0], v6[2]
     d94:      	mov.16b	v3, v7
     d98:      	mov.s	v3[0], v7[2]
     d9c:      	cbz	x9, 0x11e4 <_kernel+0xa94>
     da0:      	fsub.4s	v4, v5, v6
     da4:      	fcmeq.4s	v5, v6, v5
     da8:      	bic.16b	v16, v4, v5
     dac:      	ucvtf	s17, x9
     db0:      	dup.4s	v5, v17[0]
     db4:      	fadd	s4, s17, s17
     db8:      	dup.4s	v4, v4[0]
     dbc:      	fdiv.4s	v5, v5, v4
     dc0:      	fcmeq.4s	v18, v4, #0.0
     dc4:      	bic.16b	v18, v5, v18
     dc8:      	fmul.4s	v5, v18, v16
     dcc:      	fadd.4s	v5, v6, v5
     dd0:      	fadd.4s	v3, v7, v3
     dd4:      	fmul.4s	v6, v16, v16
     dd8:      	fmul.4s	v6, v6, v17[0]
     ddc:      	fmul.4s	v6, v18, v6
     de0:      	fadd.4s	v3, v3, v6
     de4:      	fcvtzu	x9, s4
     de8:      	cbnz	x8, 0xec8 <_kernel+0x778>
     dec:      	mov.16b	v2, v5
     df0:      	mov.16b	v1, v3
     df4:      	mov.16b	v0, v4
     df8:      	mov	x8, x9
     dfc:      	cbnz	x24, 0xf10 <_kernel+0x7c0>
     e00:      	b	0xff0 <_kernel+0x8a0>
     e04:      	cbnz	x8, 0xf0c <_kernel+0x7bc>
     e08:      	movi.2d	v0, #0000000000000000
     e0c:      	cbz	x24, 0x1200 <_kernel+0xab0>
     e10:      	mov	x8, #0x0                ; =0
     e14:      	movi.2d	v1, #0000000000000000
     e18:      	movi.2d	v2, #0000000000000000
     e1c:      	b	0xf10 <_kernel+0x7c0>
     e20:      	trn2.4s	v5, v7, v7
     e24:      	trn2.4s	v17, v3, v3
     e28:      	trn2.4s	v6, v4, v4
     e2c:      	fsub.4s	v16, v6, v4
     e30:      	fcmeq.4s	v6, v4, v6
     e34:      	bic.16b	v18, v16, v6
     e38:      	fadd.4s	v6, v7, v5
     e3c:      	fdiv.4s	v5, v5, v6
     e40:      	fcmeq.4s	v16, v6, #0.0
     e44:      	bic.16b	v5, v5, v16
     e48:      	fmul.4s	v16, v18, v5
     e4c:      	fadd.4s	v16, v4, v16
     e50:      	fadd.4s	v3, v3, v17
     e54:      	fmul.4s	v4, v18, v18
     e58:      	fmul.4s	v4, v7, v4
     e5c:      	fmul.4s	v4, v4, v5
     e60:      	fadd.4s	v7, v3, v4
     e64:      	mov.16b	v5, v16
     e68:      	mov.s	v5[0], v16[2]
     e6c:      	mov.16b	v3, v7
     e70:      	mov.s	v3[0], v7[2]
     e74:      	mov.16b	v4, v6
     e78:      	mov.s	v4[0], v6[2]
     e7c:      	tst	x9, #0x7fffffffffffffff
     e80:      	b.eq	0xec0 <_kernel+0x770>
     e84:      	fsub.4s	v17, v5, v16
     e88:      	fcmeq.4s	v5, v16, v5
     e8c:      	bic.16b	v17, v17, v5
     e90:      	fadd.4s	v18, v6, v4
     e94:      	fdiv.4s	v4, v4, v18
     e98:      	fcmeq.4s	v5, v18, #0.0
     e9c:      	bic.16b	v4, v4, v5
     ea0:      	fmul.4s	v5, v4, v17
     ea4:      	fadd.4s	v5, v16, v5
     ea8:      	fadd.4s	v3, v7, v3
     eac:      	fmul.4s	v7, v17, v17
     eb0:      	fmul.4s	v6, v6, v7
     eb4:      	fmul.4s	v4, v4, v6
     eb8:      	fadd.4s	v3, v3, v4
     ebc:      	mov.16b	v4, v18
     ec0:      	fcvtzu	x9, s4
     ec4:      	cbz	x8, 0xdec <_kernel+0x69c>
     ec8:      	cbz	x9, 0xf0c <_kernel+0x7bc>
     ecc:      	fsub	s6, s5, s2
     ed0:      	fmov	w10, s2
     ed4:      	and	w10, w10, #0x7fffffff
     ed8:      	fcmp	s2, s5
     edc:      	ccmp	w10, w25, #0x0, eq
     ee0:      	fcsel	s5, s11, s6, eq
     ee4:      	fmul	s6, s5, s5
     ee8:      	fmul	s6, s0, s6
     eec:      	fadd	s0, s0, s4
     ef0:      	add	x8, x8, x9
     ef4:      	fdiv	s4, s4, s0
     ef8:      	fmul	s5, s4, s5
     efc:      	fadd	s2, s2, s5
     f00:      	fadd	s1, s1, s3
     f04:      	fmul	s3, s4, s6
     f08:      	fadd	s1, s1, s3
     f0c:      	cbz	x24, 0xff0 <_kernel+0x8a0>
     f10:      	ucvtf	s4, x24
     f14:      	dup.4s	v3, v4[0]
     f18:      	fcmeq.4s	v5, v21, v3
     f1c:      	ldr	q6, [sp, #0x80]
     f20:      	and.16b	v5, v5, v6
     f24:      	addv.4s	s5, v5
     f28:      	fmov	w9, s5
     f2c:      	cmp	w9, #0xf
     f30:      	b.ne	0x10c8 <_kernel+0x978>
     f34:      	trn2.4s	v5, v20, v20
     f38:      	trn2.4s	v6, v19, v19
     f3c:      	fsub.4s	v7, v6, v19
     f40:      	fcmeq.4s	v6, v19, v6
     f44:      	fadd	s4, s4, s4
     f48:      	dup.4s	v4, v4[0]
     f4c:      	bic.16b	v7, v7, v6
     f50:      	lsl	x9, x24, #1
     f54:      	fdiv.4s	v6, v3, v4
     f58:      	fcmeq.4s	v4, v4, #0.0
     f5c:      	bic.16b	v4, v6, v4
     f60:      	fmul.4s	v6, v7, v4
     f64:      	fadd.4s	v6, v19, v6
     f68:      	fadd.4s	v5, v20, v5
     f6c:      	fmul.4s	v7, v7, v7
     f70:      	fmul.4s	v3, v7, v3[0]
     f74:      	fmul.4s	v3, v3, v4
     f78:      	fadd.4s	v7, v5, v3
     f7c:      	mov.16b	v4, v6
     f80:      	mov.s	v4[0], v6[2]
     f84:      	mov.16b	v3, v7
     f88:      	mov.s	v3[0], v7[2]
     f8c:      	cbz	x9, 0x11f4 <_kernel+0xaa4>
     f90:      	fsub.4s	v5, v4, v6
     f94:      	fcmeq.4s	v4, v6, v4
     f98:      	bic.16b	v16, v5, v4
     f9c:      	ucvtf	s17, x9
     fa0:      	dup.4s	v4, v17[0]
     fa4:      	fadd	s5, s17, s17
     fa8:      	dup.4s	v5, v5[0]
     fac:      	fdiv.4s	v4, v4, v5
     fb0:      	fcmeq.4s	v18, v5, #0.0
     fb4:      	bic.16b	v18, v4, v18
     fb8:      	fmul.4s	v4, v18, v16
     fbc:      	fadd.4s	v4, v6, v4
     fc0:      	fadd.4s	v3, v7, v3
     fc4:      	fmul.4s	v6, v16, v16
     fc8:      	fmul.4s	v6, v6, v17[0]
     fcc:      	fmul.4s	v6, v18, v6
     fd0:      	fadd.4s	v3, v3, v6
     fd4:      	cbnz	x8, 0x116c <_kernel+0xa1c>
     fd8:      	mov.16b	v0, v4
     fdc:      	str	s0, [x21, x28, lsl #2]
     fe0:      	str	s3, [x20, x28, lsl #2]
     fe4:      	ldr	x0, [sp, #0xb0]
     fe8:      	cbnz	x0, 0x100c <_kernel+0x8bc>
     fec:      	b	0x101c <_kernel+0x8cc>
     ff0:      	cmp	x8, #0x0
     ff4:      	fcsel	s0, s11, s2, eq
     ff8:      	fcsel	s3, s11, s1, eq
     ffc:      	str	s0, [x21, x28, lsl #2]
    1000:      	str	s3, [x20, x28, lsl #2]
    1004:      	ldr	x0, [sp, #0xb0]
    1008:      	cbz	x0, 0x101c <_kernel+0x8cc>
    100c:      	str	x0, [sp, #0xb8]
    1010:      	ldr	x8, [sp, #0xc0]
    1014:      	sub	x1, x8, x0
    1018:      	bl	0x2a84 <dyld_stub_binder+0x2a84>
    101c:      	add	x8, x28, x28, lsl #12
    1020:      	add	x10, x8, #0x1, lsl #12  ; =0x1000
    1024:      	mov	x19, #-0x4              ; =-4
    1028:      	ldp	x22, x24, [sp, #0x68]
    102c:      	ldp	x0, x27, [sp, #0x90]
    1030:      	mov	x25, x0
    1034:      	cmp	x19, #0xffc
    1038:      	b.eq	0x814 <_kernel+0xc4>
    103c:      	ldr	q4, [x25]
    1040:      	lsl	x8, x28, #2
    1044:      	add	x9, x21, x8
    1048:      	ldr	s0, [x20, x8]
    104c:      	ldr	q2, [x22]
    1050:      	ldr	q3, [x24]
    1054:      	ld1r.4s	{ v5 }, [x9]
    1058:      	fdiv	s0, s0, s8
    105c:      	fadd	s1, s0, s9
    1060:      	fsqrt	s0, s1
    1064:      	fcmp	s0, s0
    1068:      	b.vs	0x10a0 <_kernel+0x950>
    106c:      	fsub.4s	v1, v4, v5
    1070:      	fdiv	s0, s10, s0
    1074:      	fmul.4s	v0, v1, v0[0]
    1078:      	fmul.4s	v0, v2, v0
    107c:      	fadd.4s	v0, v3, v0
    1080:      	str	q0, [x27], #0x10
    1084:      	add	x25, x25, #0x10
    1088:      	add	x22, x22, #0x10
    108c:      	add	x24, x24, #0x10
    1090:      	add	x19, x19, #0x4
    1094:      	cmp	x19, #0xffd
    1098:      	b.lo	0x1034 <_kernel+0x8e4>
    109c:      	b	0x860 <_kernel+0x110>
    10a0:      	mov.16b	v0, v1
    10a4:      	str	x10, [sp, #0x40]
    10a8:      	stp	q3, q2, [sp, #0x20]
    10ac:      	stp	q5, q4, [sp]
    10b0:      	bl	0x2b50 <dyld_stub_binder+0x2b50>
    10b4:      	ldp	q5, q4, [sp]
    10b8:      	ldp	q3, q2, [sp, #0x20]
    10bc:      	ldr	x10, [sp, #0x40]
    10c0:      	ldr	x0, [sp, #0x90]
    10c4:      	b	0x106c <_kernel+0x91c>
    10c8:      	trn2.4s	v3, v21, v21
    10cc:      	trn2.4s	v4, v20, v20
    10d0:      	trn2.4s	v5, v19, v19
    10d4:      	fsub.4s	v6, v5, v19
    10d8:      	fcmeq.4s	v5, v19, v5
    10dc:      	bic.16b	v5, v6, v5
    10e0:      	fadd.4s	v6, v21, v3
    10e4:      	fdiv.4s	v3, v3, v6
    10e8:      	fcmeq.4s	v7, v6, #0.0
    10ec:      	bic.16b	v3, v3, v7
    10f0:      	fmul.4s	v7, v5, v3
    10f4:      	fadd.4s	v7, v19, v7
    10f8:      	fadd.4s	v4, v20, v4
    10fc:      	fmul.4s	v5, v5, v5
    1100:      	fmul.4s	v5, v21, v5
    1104:      	fmul.4s	v3, v5, v3
    1108:      	fadd.4s	v16, v4, v3
    110c:      	mov.16b	v4, v7
    1110:      	mov.s	v4[0], v7[2]
    1114:      	mov.16b	v3, v16
    1118:      	mov.s	v3[0], v16[2]
    111c:      	mov.16b	v5, v6
    1120:      	mov.s	v5[0], v6[2]
    1124:      	tst	x24, #0x7fffffffffffffff
    1128:      	b.eq	0x1168 <_kernel+0xa18>
    112c:      	fsub.4s	v17, v4, v7
    1130:      	fcmeq.4s	v4, v7, v4
    1134:      	bic.16b	v17, v17, v4
    1138:      	fadd.4s	v18, v6, v5
    113c:      	fdiv.4s	v4, v5, v18
    1140:      	fcmeq.4s	v5, v18, #0.0
    1144:      	bic.16b	v5, v4, v5
    1148:      	fmul.4s	v4, v5, v17
    114c:      	fadd.4s	v4, v7, v4
    1150:      	fadd.4s	v3, v16, v3
    1154:      	fmul.4s	v7, v17, v17
    1158:      	fmul.4s	v6, v6, v7
    115c:      	fmul.4s	v5, v5, v6
    1160:      	fadd.4s	v3, v3, v5
    1164:      	mov.16b	v5, v18
    1168:      	cbz	x8, 0xfd8 <_kernel+0x888>
    116c:      	fcvtzu	x8, s5
    1170:      	cbz	x8, 0x11c8 <_kernel+0xa78>
    1174:      	fsub	s6, s4, s2
    1178:      	fmov	w8, s2
    117c:      	and	w8, w8, #0x7fffffff
    1180:      	fcmp	s2, s4
    1184:      	ccmp	w8, w25, #0x0, eq
    1188:      	fcsel	s4, s11, s6, eq
    118c:      	fadd	s6, s0, s5
    1190:      	fdiv	s5, s5, s6
    1194:      	fmul	s6, s5, s4
    1198:      	fmul	s4, s4, s4
    119c:      	fmul	s0, s0, s4
    11a0:      	fadd	s2, s2, s6
    11a4:      	fadd	s1, s1, s3
    11a8:      	fmul	s0, s5, s0
    11ac:      	fadd	s3, s1, s0
    11b0:      	mov.16b	v0, v2
    11b4:      	str	s0, [x21, x28, lsl #2]
    11b8:      	str	s3, [x20, x28, lsl #2]
    11bc:      	ldr	x0, [sp, #0xb0]
    11c0:      	cbnz	x0, 0x100c <_kernel+0x8bc>
    11c4:      	b	0x101c <_kernel+0x8cc>
    11c8:      	mov.16b	v0, v2
    11cc:      	mov.16b	v3, v1
    11d0:      	str	s0, [x21, x28, lsl #2]
    11d4:      	str	s3, [x20, x28, lsl #2]
    11d8:      	ldr	x0, [sp, #0xb0]
    11dc:      	cbnz	x0, 0x100c <_kernel+0x8bc>
    11e0:      	b	0x101c <_kernel+0x8cc>
    11e4:      	movi.2d	v4, #0000000000000000
    11e8:      	fcvtzu	x9, s4
    11ec:      	cbnz	x8, 0xec8 <_kernel+0x778>
    11f0:      	b	0xdec <_kernel+0x69c>
    11f4:      	movi.2d	v5, #0000000000000000
    11f8:      	cbnz	x8, 0x116c <_kernel+0xa1c>
    11fc:      	b	0xfd8 <_kernel+0x888>
    1200:      	movi.2d	v3, #0000000000000000
    1204:      	str	s0, [x21, x28, lsl #2]
    1208:      	str	s3, [x20, x28, lsl #2]
    120c:      	ldr	x0, [sp, #0xb0]
    1210:      	cbnz	x0, 0x100c <_kernel+0x8bc>
    1214:      	b	0x101c <_kernel+0x8cc>
    1218:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    121c:      	add	x0, x0, #0x220
    1220:      	bl	0x2ae4 <dyld_stub_binder+0x2ae4>
    1224:      	cbz	w0, 0x8d0 <_kernel+0x180>
    1228:      	mov	x0, x26
    122c:      	mov	w1, #0x400              ; =1024
    1230:      	bl	0x1478 <__ZN13WelfordHelperIN2at3vec14CPU_CAPABILITY10VectorizedIfEELy4096EEC1Ey>
    1234:      	adrp	x19, 0x8000 <dyld_stub_binder+0x8000>
    1238:      	add	x19, x19, #0x220
    123c:      	add	x1, x19, #0x10
    1240:      	adrp	x0, 0x1000 <_kernel+0x8b0>
    1244:      	add	x0, x0, #0x540
    1248:      	adrp	x2, 0x0 <dyld_stub_binder>
    124c:      	add	x2, x2, #0x0
    1250:      	bl	0x2aa8 <dyld_stub_binder+0x2aa8>
    1254:      	mov	x0, x19
    1258:      	bl	0x2af0 <dyld_stub_binder+0x2af0>
    125c:      	mov	w19, #0x4004            ; =16388
    1260:      	adrp	x22, 0x8000 <dyld_stub_binder+0x8000>
    1264:      	mov	w25, #0x7f800000        ; =2139095040
    1268:      	adrp	x27, 0x8000 <dyld_stub_binder+0x8000>
    126c:      	b	0x8d0 <_kernel+0x180>
    1270:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    1274:      	add	x0, x0, #0x228
    1278:      	bl	0x2ae4 <dyld_stub_binder+0x2ae4>
    127c:      	cbz	w0, 0x8e0 <_kernel+0x190>
    1280:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    1284:      	add	x0, x0, #0x258
    1288:      	mov	w1, #0x1                ; =1
    128c:      	bl	0x1478 <__ZN13WelfordHelperIN2at3vec14CPU_CAPABILITY10VectorizedIfEELy4096EEC1Ey>
    1290:      	adrp	x19, 0x8000 <dyld_stub_binder+0x8000>
    1294:      	add	x19, x19, #0x228
    1298:      	add	x1, x19, #0x30
    129c:      	adrp	x0, 0x1000 <_kernel+0x8b0>
    12a0:      	add	x0, x0, #0x540
    12a4:      	adrp	x2, 0x0 <dyld_stub_binder>
    12a8:      	add	x2, x2, #0x0
    12ac:      	bl	0x2aa8 <dyld_stub_binder+0x2aa8>
    12b0:      	mov	x0, x19
    12b4:      	bl	0x2af0 <dyld_stub_binder+0x2af0>
    12b8:      	mov	w19, #0x4004            ; =16388
    12bc:      	adrp	x22, 0x8000 <dyld_stub_binder+0x8000>
    12c0:      	mov	w25, #0x7f800000        ; =2139095040
    12c4:      	adrp	x27, 0x8000 <dyld_stub_binder+0x8000>
    12c8:      	b	0x8e0 <_kernel+0x190>
    12cc:      	mov.16b	v0, v1
    12d0:      	str	s2, [sp, #0x40]
    12d4:      	str	s3, [sp, #0x20]
    12d8:      	str	s5, [sp, #0x30]
    12dc:      	str	s4, [sp, #0x10]
    12e0:      	mov	x19, x10
    12e4:      	bl	0x2b50 <dyld_stub_binder+0x2b50>
    12e8:      	mov	x10, x19
    12ec:      	ldr	x0, [sp, #0x90]
    12f0:      	ldr	s4, [sp, #0x10]
    12f4:      	ldr	s5, [sp, #0x30]
    12f8:      	ldr	s3, [sp, #0x20]
    12fc:      	ldr	s2, [sp, #0x40]
    1300:      	b	0x844 <_kernel+0xf4>
    1304:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
    1308:      	ldr	x8, [x8, #0xb0]
    130c:      	str	xzr, [x8]
    1310:      	add	x8, sp, #0xdc
    1314:      	ldapr	w8, [x8]
    1318:      	cbnz	w8, 0x135c <_kernel+0xc0c>
    131c:      	ldur	x8, [x29, #-0x80]
    1320:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
    1324:      	ldr	x9, [x9, #0x58]
    1328:      	ldr	x9, [x9]
    132c:      	cmp	x9, x8
    1330:      	b.ne	0x13e0 <_kernel+0xc90>
    1334:      	ldp	x29, x30, [sp, #0x1e0]
    1338:      	ldp	x20, x19, [sp, #0x1d0]
    133c:      	ldp	x22, x21, [sp, #0x1c0]
    1340:      	ldp	x24, x23, [sp, #0x1b0]
    1344:      	ldp	x26, x25, [sp, #0x1a0]
    1348:      	ldp	x28, x27, [sp, #0x190]
    134c:      	ldp	d9, d8, [sp, #0x180]
    1350:      	ldp	d11, d10, [sp, #0x170]
    1354:      	add	sp, sp, #0x1f0
    1358:      	ret
    135c:      	mov	w0, #0x10               ; =16
    1360:      	bl	0x2a9c <dyld_stub_binder+0x2a9c>
    1364:      	mov	x19, x0
    1368:      	mov	w8, #0x33d              ; =829
    136c:      	str	w8, [sp, #0xe0]
    1370:      	adrp	x0, 0x2000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x110>
    1374:      	add	x0, x0, #0xed3
    1378:      	adrp	x1, 0x2000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x110>
    137c:      	add	x1, x1, #0xf5f
    1380:      	adrp	x3, 0x2000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x110>
    1384:      	add	x3, x3, #0xf8a
    1388:      	adrp	x4, 0x3000 <dyld_stub_binder+0x3000>
    138c:      	add	x4, x4, #0x8
    1390:      	adrp	x2, 0x2000 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x110>
    1394:      	add	x2, x2, #0xf87
    1398:      	sub	x8, x29, #0xc0
    139c:      	add	x5, sp, #0xe0
    13a0:      	adrp	x7, 0x3000 <dyld_stub_binder+0x3000>
    13a4:      	add	x7, x7, #0xa
    13a8:      	mov	x6, x2
    13ac:      	bl	0x1b2c <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
    13b0:      	mov	w21, #0x1               ; =1
    13b4:      	sub	x1, x29, #0xc0
    13b8:      	mov	x0, x19
    13bc:      	bl	0x29e8 <dyld_stub_binder+0x29e8>
    13c0:      	mov	w21, #0x0               ; =0
    13c4:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
    13c8:      	ldr	x1, [x1, #0x18]
    13cc:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
    13d0:      	ldr	x2, [x2, #0x8]
    13d4:      	mov	x0, x19
    13d8:      	bl	0x2afc <dyld_stub_binder+0x2afc>
    13dc:      	brk	#0x1
    13e0:      	bl	0x2b14 <dyld_stub_binder+0x2b14>
    13e4:      	mov	x20, x0
    13e8:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    13ec:      	add	x0, x0, #0x228
    13f0:      	b	0x1400 <_kernel+0xcb0>
    13f4:      	mov	x20, x0
    13f8:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    13fc:      	add	x0, x0, #0x220
    1400:      	bl	0x2ad8 <dyld_stub_binder+0x2ad8>
    1404:      	b	0x1450 <_kernel+0xd00>
    1408:      	mov	x20, x0
    140c:      	ldursb	w8, [x29, #-0xa9]
    1410:      	tbz	w8, #0x1f, 0x142c <_kernel+0xcdc>
    1414:      	ldur	x0, [x29, #-0xc0]
    1418:      	ldur	x8, [x29, #-0xb0]
    141c:      	and	x1, x8, #0x7fffffffffffffff
    1420:      	bl	0x2a84 <dyld_stub_binder+0x2a84>
    1424:      	tbnz	w21, #0x0, 0x1438 <_kernel+0xce8>
    1428:      	b	0x1458 <_kernel+0xd08>
    142c:      	cbnz	w21, 0x1438 <_kernel+0xce8>
    1430:      	b	0x1458 <_kernel+0xd08>
    1434:      	mov	x20, x0
    1438:      	mov	x0, x19
    143c:      	bl	0x2acc <dyld_stub_binder+0x2acc>
    1440:      	mov	x0, x20
    1444:      	bl	0x29ac <dyld_stub_binder+0x29ac>
    1448:      	b	0x144c <_kernel+0xcfc>
    144c:      	mov	x20, x0
    1450:      	ldr	x0, [sp, #0xb0]
    1454:      	cbnz	x0, 0x1460 <_kernel+0xd10>
    1458:      	mov	x0, x20
    145c:      	bl	0x29ac <dyld_stub_binder+0x29ac>
    1460:      	str	x0, [sp, #0xb8]
    1464:      	ldr	x8, [sp, #0xc0]
    1468:      	sub	x1, x8, x0
    146c:      	bl	0x2a84 <dyld_stub_binder+0x2a84>
    1470:      	mov	x0, x20
    1474:      	bl	0x29ac <dyld_stub_binder+0x29ac>


/private/tmp/luisa-native-rows.LuX3yX/capture-v3/rmsnorm-1024x4097-l1/object/tile_xir_w8_80718_1788919109981127_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x90
       4:      	stp	d11, d10, [sp, #0x10]
       8:      	stp	d9, d8, [sp, #0x20]
       c:      	stp	x28, x27, [sp, #0x30]
      10:      	stp	x26, x25, [sp, #0x40]
      14:      	stp	x24, x23, [sp, #0x50]
      18:      	stp	x22, x21, [sp, #0x60]
      1c:      	stp	x20, x19, [sp, #0x70]
      20:      	stp	x29, x30, [sp, #0x80]
      24:      	str	x0, [sp]
      28:      	cbz	w3, 0x1150 <ltmp0+0x1150>
      2c:      	mov	w8, #0x0                ; =0
      30:      	ldp	w13, w15, [x2, #0x2c]
      34:      	ldp	w6, w7, [x2]
      38:      	ldp	w19, w12, [x2, #0x8]
      3c:      	mov	w16, #0x20              ; =32
      40:      	adrp	x11, 0x0 <ltmp0>
      44:      	ldr	q0, [x11]
      48:      	mov	w14, #0x1001            ; =4097
      4c:      	adrp	x11, 0x0 <ltmp0>
      50:      	ldr	q1, [x11]
      54:      	mov	w1, #0x800              ; =2048
      58:      	movk	w1, #0x4580, lsl #16
      5c:      	mov	w4, #0xc5ac             ; =50604
      60:      	movk	w4, #0x3727, lsl #16
      64:      	dup.4s	v2, w14
      68:      	b	0xa0 <ltmp0+0xa0>
      6c:      	add	w9, w5, #0x1
      70:      	cmp	w9, w13
      74:      	cset	w9, eq
      78:      	csinc	w6, wzr, w5, eq
      7c:      	cinc	w10, w0, eq
      80:      	cmp	w10, w15
      84:      	cset	w11, eq
      88:      	ands	w9, w9, w11
      8c:      	csel	w7, wzr, w10, ne
      90:      	add	w19, w30, w9
      94:      	add	w8, w8, #0x1
      98:      	cmp	w8, w3
      9c:      	b.eq	0x1140 <ltmp0+0x1140>
      a0:      	mov	x30, x19
      a4:      	mov	x0, x7
      a8:      	mov	x5, x6
      ac:      	ubfiz	x11, x6, #5, #32
      b0:      	cmp	x11, x12
      b4:      	csel	x6, x11, xzr, ls
      b8:      	subs	x7, x12, x6
      bc:      	cmp	x7, #0x20
      c0:      	csel	x7, x7, x16, lo
      c4:      	cmp	x12, x6
      c8:      	ccmp	x11, x12, #0x2, hi
      cc:      	csel	x6, x7, xzr, ls
      d0:      	dup.4s	v4, w1
      d4:      	dup.4s	v3, w4
      d8:      	cmp	x6, #0x20
      dc:      	b.lo	0xa48 <ltmp0+0xa48>
      e0:      	mov	x20, #0x0               ; =0
      e4:      	ldr	x6, [x2, #0x88]
      e8:      	add	x19, x6, #0x20, lsl #12 ; =0x20000
      ec:      	ldr	x9, [sp]
      f0:      	ldr	x11, [x9]
      f4:      	ldr	x7, [x9, #0x10]
      f8:      	ldr	x22, [x9, #0x30]
      fc:      	dup.2d	v5, x11
     100:      	lsl	w21, w5, #5
     104:      	dup.4s	v6, w21
     108:      	orr.16b	v17, v6, v0
     10c:      	orr.16b	v6, v6, v1
     110:      	umull2.2d	v7, v17, v2
     114:      	umull2.2d	v16, v6, v2
     118:      	umull.2d	v17, v17, v2
     11c:      	umull.2d	v18, v6, v2
     120:      	dup.2d	v6, x20
     124:      	add.2d	v19, v6, v7
     128:      	add.2d	v20, v6, v17
     12c:      	add.2d	v21, v6, v16
     130:      	add.2d	v6, v6, v18
     134:      	shl.2d	v6, v6, #0x2
     138:      	shl.2d	v21, v21, #0x2
     13c:      	shl.2d	v20, v20, #0x2
     140:      	shl.2d	v19, v19, #0x2
     144:      	add.2d	v19, v5, v19
     148:      	add.2d	v20, v5, v20
     14c:      	add.2d	v21, v5, v21
     150:      	add.2d	v6, v5, v6
     154:      	mov.d	x11, v6[1]
     158:      	fmov	x23, d6
     15c:      	mov.d	x24, v21[1]
     160:      	fmov	x25, d21
     164:      	mov.d	x26, v20[1]
     168:      	fmov	x27, d20
     16c:      	mov.d	x28, v19[1]
     170:      	ldr	s6, [x23]
     174:      	ld1.s	{ v6 }[1], [x11]
     178:      	fmov	x11, d19
     17c:      	ld1.s	{ v6 }[2], [x25]
     180:      	ld1.s	{ v6 }[3], [x24]
     184:      	ldr	s19, [x27]
     188:      	ld1.s	{ v19 }[1], [x26]
     18c:      	ld1.s	{ v19 }[2], [x11]
     190:      	ld1.s	{ v19 }[3], [x28]
     194:      	add	x11, x6, x20, lsl #5
     198:      	stp	q6, q19, [x11]
     19c:      	add	x20, x20, #0x1
     1a0:      	cmp	x20, x14
     1a4:      	b.ne	0x120 <ltmp0+0x120>
     1a8:      	mov	x20, #0x0               ; =0
     1ac:      	ldp	q19, q6, [x6]
     1b0:      	fmul.4s	v6, v6, v6
     1b4:      	fmul.4s	v19, v19, v19
     1b8:      	ldp	q20, q21, [x6, #0x20]
     1bc:      	fmul.4s	v21, v21, v21
     1c0:      	fmul.4s	v20, v20, v20
     1c4:      	ldp	q23, q22, [x6, #0x40]
     1c8:      	fmul.4s	v22, v22, v22
     1cc:      	fmul.4s	v23, v23, v23
     1d0:      	ldp	q24, q25, [x6, #0x60]
     1d4:      	fmul.4s	v25, v25, v25
     1d8:      	fmul.4s	v24, v24, v24
     1dc:      	add	x11, x6, x20, lsl #5
     1e0:      	ldp	q27, q26, [x11, #0x80]
     1e4:      	fmul.4s	v27, v27, v27
     1e8:      	fmul.4s	v26, v26, v26
     1ec:      	fadd.4s	v6, v6, v26
     1f0:      	fadd.4s	v19, v19, v27
     1f4:      	ldp	q27, q26, [x11, #0xa0]
     1f8:      	fmul.4s	v27, v27, v27
     1fc:      	fmul.4s	v26, v26, v26
     200:      	fadd.4s	v21, v21, v26
     204:      	fadd.4s	v20, v20, v27
     208:      	ldp	q27, q26, [x11, #0xc0]
     20c:      	fmul.4s	v27, v27, v27
     210:      	fmul.4s	v26, v26, v26
     214:      	fadd.4s	v22, v22, v26
     218:      	fadd.4s	v23, v23, v27
     21c:      	ldp	q27, q26, [x11, #0xe0]
     220:      	fmul.4s	v27, v27, v27
     224:      	fmul.4s	v26, v26, v26
     228:      	fadd.4s	v25, v25, v26
     22c:      	fadd.4s	v24, v24, v27
     230:      	add	x20, x20, #0x4
     234:      	cmp	x20, #0xffc
     238:      	b.lo	0x1dc <ltmp0+0x1dc>
     23c:      	add	x20, x19, #0x20
     240:      	ldp	q26, q27, [x19]
     244:      	mov	x23, x7
     248:      	mov	w24, #0x20              ; =32
     24c:      	movk	w24, #0x2, lsl #16
     250:      	mov	w25, #0x1001            ; =4097
     254:      	ld1r.4s	{ v28 }, [x23], #4
     258:      	add	x11, x6, x24
     25c:      	stp	q28, q28, [x11]
     260:      	add	x24, x24, #0x20
     264:      	subs	x25, x25, #0x1
     268:      	b.ne	0x254 <ltmp0+0x254>
     26c:      	mov	x23, #0x0               ; =0
     270:      	fmul.4s	v27, v27, v27
     274:      	fmul.4s	v26, v26, v26
     278:      	fadd.4s	v19, v19, v26
     27c:      	fadd.4s	v6, v6, v27
     280:      	fadd.4s	v6, v21, v6
     284:      	fadd.4s	v19, v20, v19
     288:      	fadd.4s	v19, v23, v19
     28c:      	fadd.4s	v6, v22, v6
     290:      	fadd.4s	v6, v25, v6
     294:      	fadd.4s	v19, v24, v19
     298:      	fdiv.4s	v19, v19, v4
     29c:      	fdiv.4s	v6, v6, v4
     2a0:      	fadd.4s	v6, v6, v3
     2a4:      	fadd.4s	v19, v19, v3
     2a8:      	fsqrt.4s	v19, v19
     2ac:      	fsqrt.4s	v20, v6
     2b0:      	dup.2d	v6, x23
     2b4:      	add.2d	v21, v6, v7
     2b8:      	add.2d	v22, v6, v17
     2bc:      	add.2d	v23, v6, v16
     2c0:      	add.2d	v6, v6, v18
     2c4:      	lsl	x11, x23, #5
     2c8:      	add	x24, x6, x11
     2cc:      	ldp	q25, q24, [x24]
     2d0:      	fdiv.4s	v25, v25, v19
     2d4:      	fdiv.4s	v24, v24, v20
     2d8:      	add	x11, x20, x11
     2dc:      	ldp	q26, q27, [x11]
     2e0:      	fmul.4s	v24, v24, v27
     2e4:      	fmul.4s	v25, v25, v26
     2e8:      	shl.2d	v26, v6, #0x2
     2ec:      	shl.2d	v23, v23, #0x2
     2f0:      	shl.2d	v22, v22, #0x2
     2f4:      	shl.2d	v21, v21, #0x2
     2f8:      	dup.2d	v6, x22
     2fc:      	add.2d	v21, v6, v21
     300:      	add.2d	v26, v6, v26
     304:      	mov.d	x11, v26[1]
     308:      	fmov	x24, d26
     30c:      	str	s25, [x24]
     310:      	st1.s	{ v25 }[1], [x11]
     314:      	add.2d	v23, v6, v23
     318:      	mov.d	x11, v23[1]
     31c:      	fmov	x24, d23
     320:      	st1.s	{ v25 }[2], [x24]
     324:      	add.2d	v22, v6, v22
     328:      	st1.s	{ v25 }[3], [x11]
     32c:      	mov.d	x11, v22[1]
     330:      	fmov	x24, d22
     334:      	str	s24, [x24]
     338:      	st1.s	{ v24 }[1], [x11]
     33c:      	mov.d	x11, v21[1]
     340:      	fmov	x24, d21
     344:      	st1.s	{ v24 }[2], [x24]
     348:      	st1.s	{ v24 }[3], [x11]
     34c:      	add	x23, x23, #0x1
     350:      	cmp	x23, x14
     354:      	b.ne	0x2b0 <ltmp0+0x2b0>
     358:      	mov	x22, #0x0               ; =0
     35c:      	orr	w11, w21, #0x8
     360:      	dup.4s	v7, w11
     364:      	orr.16b	v17, v7, v0
     368:      	orr.16b	v18, v7, v1
     36c:      	umull2.2d	v7, v17, v2
     370:      	umull2.2d	v16, v18, v2
     374:      	umull.2d	v17, v17, v2
     378:      	umull.2d	v18, v18, v2
     37c:      	dup.2d	v19, x22
     380:      	add.2d	v20, v19, v7
     384:      	add.2d	v21, v19, v17
     388:      	add.2d	v22, v19, v16
     38c:      	add.2d	v19, v19, v18
     390:      	shl.2d	v19, v19, #0x2
     394:      	shl.2d	v22, v22, #0x2
     398:      	shl.2d	v21, v21, #0x2
     39c:      	shl.2d	v20, v20, #0x2
     3a0:      	add.2d	v20, v5, v20
     3a4:      	add.2d	v21, v5, v21
     3a8:      	add.2d	v22, v5, v22
     3ac:      	add.2d	v19, v5, v19
     3b0:      	mov.d	x11, v19[1]
     3b4:      	fmov	x23, d19
     3b8:      	mov.d	x24, v22[1]
     3bc:      	fmov	x25, d22
     3c0:      	mov.d	x26, v21[1]
     3c4:      	fmov	x27, d21
     3c8:      	mov.d	x28, v20[1]
     3cc:      	ldr	s19, [x23]
     3d0:      	ld1.s	{ v19 }[1], [x11]
     3d4:      	fmov	x11, d20
     3d8:      	ld1.s	{ v19 }[2], [x25]
     3dc:      	ld1.s	{ v19 }[3], [x24]
     3e0:      	ldr	s20, [x27]
     3e4:      	ld1.s	{ v20 }[1], [x26]
     3e8:      	ld1.s	{ v20 }[2], [x11]
     3ec:      	ld1.s	{ v20 }[3], [x28]
     3f0:      	add	x11, x6, x22, lsl #5
     3f4:      	stp	q19, q20, [x11]
     3f8:      	add	x22, x22, #0x1
     3fc:      	cmp	x22, x14
     400:      	b.ne	0x37c <ltmp0+0x37c>
     404:      	mov	x22, #0x0               ; =0
     408:      	ldp	q20, q19, [x6]
     40c:      	fmul.4s	v19, v19, v19
     410:      	fmul.4s	v20, v20, v20
     414:      	ldp	q21, q22, [x6, #0x20]
     418:      	fmul.4s	v22, v22, v22
     41c:      	fmul.4s	v21, v21, v21
     420:      	ldp	q24, q23, [x6, #0x40]
     424:      	fmul.4s	v23, v23, v23
     428:      	fmul.4s	v24, v24, v24
     42c:      	ldp	q25, q26, [x6, #0x60]
     430:      	fmul.4s	v26, v26, v26
     434:      	fmul.4s	v25, v25, v25
     438:      	add	x11, x6, x22, lsl #5
     43c:      	ldp	q28, q27, [x11, #0x80]
     440:      	fmul.4s	v28, v28, v28
     444:      	fmul.4s	v27, v27, v27
     448:      	fadd.4s	v19, v19, v27
     44c:      	fadd.4s	v20, v20, v28
     450:      	ldp	q28, q27, [x11, #0xa0]
     454:      	fmul.4s	v28, v28, v28
     458:      	fmul.4s	v27, v27, v27
     45c:      	fadd.4s	v22, v22, v27
     460:      	fadd.4s	v21, v21, v28
     464:      	ldp	q28, q27, [x11, #0xc0]
     468:      	fmul.4s	v28, v28, v28
     46c:      	fmul.4s	v27, v27, v27
     470:      	fadd.4s	v23, v23, v27
     474:      	fadd.4s	v24, v24, v28
     478:      	ldp	q28, q27, [x11, #0xe0]
     47c:      	fmul.4s	v28, v28, v28
     480:      	fmul.4s	v27, v27, v27
     484:      	fadd.4s	v26, v26, v27
     488:      	fadd.4s	v25, v25, v28
     48c:      	add	x22, x22, #0x4
     490:      	cmp	x22, #0xffc
     494:      	b.lo	0x438 <ltmp0+0x438>
     498:      	ldp	q27, q28, [x19]
     49c:      	mov	x22, x7
     4a0:      	mov	w23, #0x20              ; =32
     4a4:      	movk	w23, #0x2, lsl #16
     4a8:      	mov	w24, #0x1001            ; =4097
     4ac:      	ld1r.4s	{ v29 }, [x22], #4
     4b0:      	add	x11, x6, x23
     4b4:      	stp	q29, q29, [x11]
     4b8:      	add	x23, x23, #0x20
     4bc:      	subs	x24, x24, #0x1
     4c0:      	b.ne	0x4ac <ltmp0+0x4ac>
     4c4:      	mov	x22, #0x0               ; =0
     4c8:      	fmul.4s	v28, v28, v28
     4cc:      	fmul.4s	v27, v27, v27
     4d0:      	fadd.4s	v20, v20, v27
     4d4:      	fadd.4s	v19, v19, v28
     4d8:      	fadd.4s	v19, v22, v19
     4dc:      	fadd.4s	v20, v21, v20
     4e0:      	fadd.4s	v20, v24, v20
     4e4:      	fadd.4s	v19, v23, v19
     4e8:      	fadd.4s	v19, v26, v19
     4ec:      	fadd.4s	v20, v25, v20
     4f0:      	fdiv.4s	v20, v20, v4
     4f4:      	fdiv.4s	v19, v19, v4
     4f8:      	fadd.4s	v21, v19, v3
     4fc:      	fadd.4s	v19, v20, v3
     500:      	fsqrt.4s	v19, v19
     504:      	fsqrt.4s	v20, v21
     508:      	dup.2d	v21, x22
     50c:      	add.2d	v22, v21, v7
     510:      	add.2d	v23, v21, v17
     514:      	add.2d	v24, v21, v16
     518:      	add.2d	v21, v21, v18
     51c:      	lsl	x11, x22, #5
     520:      	add	x23, x6, x11
     524:      	ldp	q26, q25, [x23]
     528:      	fdiv.4s	v26, v26, v19
     52c:      	fdiv.4s	v25, v25, v20
     530:      	add	x11, x20, x11
     534:      	ldp	q27, q28, [x11]
     538:      	fmul.4s	v25, v25, v28
     53c:      	fmul.4s	v26, v26, v27
     540:      	shl.2d	v21, v21, #0x2
     544:      	shl.2d	v24, v24, #0x2
     548:      	shl.2d	v23, v23, #0x2
     54c:      	shl.2d	v22, v22, #0x2
     550:      	add.2d	v22, v6, v22
     554:      	add.2d	v21, v6, v21
     558:      	mov.d	x11, v21[1]
     55c:      	fmov	x23, d21
     560:      	str	s26, [x23]
     564:      	st1.s	{ v26 }[1], [x11]
     568:      	add.2d	v21, v6, v24
     56c:      	mov.d	x11, v21[1]
     570:      	fmov	x23, d21
     574:      	st1.s	{ v26 }[2], [x23]
     578:      	add.2d	v21, v6, v23
     57c:      	st1.s	{ v26 }[3], [x11]
     580:      	mov.d	x11, v21[1]
     584:      	fmov	x23, d21
     588:      	str	s25, [x23]
     58c:      	st1.s	{ v25 }[1], [x11]
     590:      	mov.d	x11, v22[1]
     594:      	fmov	x23, d22
     598:      	st1.s	{ v25 }[2], [x23]
     59c:      	st1.s	{ v25 }[3], [x11]
     5a0:      	add	x22, x22, #0x1
     5a4:      	cmp	x22, x14
     5a8:      	b.ne	0x508 <ltmp0+0x508>
     5ac:      	mov	x22, #0x0               ; =0
     5b0:      	orr	w11, w21, #0x10
     5b4:      	dup.4s	v7, w11
     5b8:      	orr.16b	v17, v7, v0
     5bc:      	orr.16b	v18, v7, v1
     5c0:      	umull2.2d	v7, v17, v2
     5c4:      	umull2.2d	v16, v18, v2
     5c8:      	umull.2d	v17, v17, v2
     5cc:      	umull.2d	v18, v18, v2
     5d0:      	dup.2d	v19, x22
     5d4:      	add.2d	v20, v19, v7
     5d8:      	add.2d	v21, v19, v17
     5dc:      	add.2d	v22, v19, v16
     5e0:      	add.2d	v19, v19, v18
     5e4:      	shl.2d	v19, v19, #0x2
     5e8:      	shl.2d	v22, v22, #0x2
     5ec:      	shl.2d	v21, v21, #0x2
     5f0:      	shl.2d	v20, v20, #0x2
     5f4:      	add.2d	v20, v5, v20
     5f8:      	add.2d	v21, v5, v21
     5fc:      	add.2d	v22, v5, v22
     600:      	add.2d	v19, v5, v19
     604:      	mov.d	x11, v19[1]
     608:      	fmov	x23, d19
     60c:      	mov.d	x24, v22[1]
     610:      	fmov	x25, d22
     614:      	mov.d	x26, v21[1]
     618:      	fmov	x27, d21
     61c:      	mov.d	x28, v20[1]
     620:      	ldr	s19, [x23]
     624:      	ld1.s	{ v19 }[1], [x11]
     628:      	fmov	x11, d20
     62c:      	ld1.s	{ v19 }[2], [x25]
     630:      	ld1.s	{ v19 }[3], [x24]
     634:      	ldr	s20, [x27]
     638:      	ld1.s	{ v20 }[1], [x26]
     63c:      	ld1.s	{ v20 }[2], [x11]
     640:      	ld1.s	{ v20 }[3], [x28]
     644:      	add	x11, x6, x22, lsl #5
     648:      	stp	q19, q20, [x11]
     64c:      	add	x22, x22, #0x1
     650:      	cmp	x22, x14
     654:      	b.ne	0x5d0 <ltmp0+0x5d0>
     658:      	mov	x22, #0x0               ; =0
     65c:      	ldp	q20, q19, [x6]
     660:      	fmul.4s	v19, v19, v19
     664:      	fmul.4s	v20, v20, v20
     668:      	ldp	q21, q22, [x6, #0x20]
     66c:      	fmul.4s	v22, v22, v22
     670:      	fmul.4s	v21, v21, v21
     674:      	ldp	q24, q23, [x6, #0x40]
     678:      	fmul.4s	v23, v23, v23
     67c:      	fmul.4s	v24, v24, v24
     680:      	ldp	q25, q26, [x6, #0x60]
     684:      	fmul.4s	v26, v26, v26
     688:      	fmul.4s	v25, v25, v25
     68c:      	add	x11, x6, x22, lsl #5
     690:      	ldp	q28, q27, [x11, #0x80]
     694:      	fmul.4s	v28, v28, v28
     698:      	fmul.4s	v27, v27, v27
     69c:      	fadd.4s	v19, v19, v27
     6a0:      	fadd.4s	v20, v20, v28
     6a4:      	ldp	q28, q27, [x11, #0xa0]
     6a8:      	fmul.4s	v28, v28, v28
     6ac:      	fmul.4s	v27, v27, v27
     6b0:      	fadd.4s	v22, v22, v27
     6b4:      	fadd.4s	v21, v21, v28
     6b8:      	ldp	q28, q27, [x11, #0xc0]
     6bc:      	fmul.4s	v28, v28, v28
     6c0:      	fmul.4s	v27, v27, v27
     6c4:      	fadd.4s	v23, v23, v27
     6c8:      	fadd.4s	v24, v24, v28
     6cc:      	ldp	q28, q27, [x11, #0xe0]
     6d0:      	fmul.4s	v28, v28, v28
     6d4:      	fmul.4s	v27, v27, v27
     6d8:      	fadd.4s	v26, v26, v27
     6dc:      	fadd.4s	v25, v25, v28
     6e0:      	add	x22, x22, #0x4
     6e4:      	cmp	x22, #0xffc
     6e8:      	b.lo	0x68c <ltmp0+0x68c>
     6ec:      	ldp	q27, q28, [x19]
     6f0:      	mov	x22, x7
     6f4:      	mov	w23, #0x20              ; =32
     6f8:      	movk	w23, #0x2, lsl #16
     6fc:      	mov	w24, #0x1001            ; =4097
     700:      	ld1r.4s	{ v29 }, [x22], #4
     704:      	add	x11, x6, x23
     708:      	stp	q29, q29, [x11]
     70c:      	add	x23, x23, #0x20
     710:      	subs	x24, x24, #0x1
     714:      	b.ne	0x700 <ltmp0+0x700>
     718:      	mov	x22, #0x0               ; =0
     71c:      	fmul.4s	v28, v28, v28
     720:      	fmul.4s	v27, v27, v27
     724:      	fadd.4s	v20, v20, v27
     728:      	fadd.4s	v19, v19, v28
     72c:      	fadd.4s	v19, v22, v19
     730:      	fadd.4s	v20, v21, v20
     734:      	fadd.4s	v20, v24, v20
     738:      	fadd.4s	v19, v23, v19
     73c:      	fadd.4s	v19, v26, v19
     740:      	fadd.4s	v20, v25, v20
     744:      	fdiv.4s	v20, v20, v4
     748:      	fdiv.4s	v19, v19, v4
     74c:      	fadd.4s	v21, v19, v3
     750:      	fadd.4s	v19, v20, v3
     754:      	fsqrt.4s	v19, v19
     758:      	fsqrt.4s	v20, v21
     75c:      	dup.2d	v21, x22
     760:      	add.2d	v22, v21, v7
     764:      	add.2d	v23, v21, v17
     768:      	add.2d	v24, v21, v16
     76c:      	add.2d	v21, v21, v18
     770:      	lsl	x11, x22, #5
     774:      	add	x23, x6, x11
     778:      	ldp	q26, q25, [x23]
     77c:      	fdiv.4s	v26, v26, v19
     780:      	fdiv.4s	v25, v25, v20
     784:      	add	x11, x20, x11
     788:      	ldp	q27, q28, [x11]
     78c:      	fmul.4s	v25, v25, v28
     790:      	fmul.4s	v26, v26, v27
     794:      	shl.2d	v21, v21, #0x2
     798:      	shl.2d	v24, v24, #0x2
     79c:      	shl.2d	v23, v23, #0x2
     7a0:      	shl.2d	v22, v22, #0x2
     7a4:      	add.2d	v22, v6, v22
     7a8:      	add.2d	v21, v6, v21
     7ac:      	mov.d	x11, v21[1]
     7b0:      	fmov	x23, d21
     7b4:      	str	s26, [x23]
     7b8:      	st1.s	{ v26 }[1], [x11]
     7bc:      	add.2d	v21, v6, v24
     7c0:      	mov.d	x11, v21[1]
     7c4:      	fmov	x23, d21
     7c8:      	st1.s	{ v26 }[2], [x23]
     7cc:      	add.2d	v21, v6, v23
     7d0:      	st1.s	{ v26 }[3], [x11]
     7d4:      	mov.d	x11, v21[1]
     7d8:      	fmov	x23, d21
     7dc:      	str	s25, [x23]
     7e0:      	st1.s	{ v25 }[1], [x11]
     7e4:      	mov.d	x11, v22[1]
     7e8:      	fmov	x23, d22
     7ec:      	st1.s	{ v25 }[2], [x23]
     7f0:      	st1.s	{ v25 }[3], [x11]
     7f4:      	add	x22, x22, #0x1
     7f8:      	cmp	x22, x14
     7fc:      	b.ne	0x75c <ltmp0+0x75c>
     800:      	mov	x22, #0x0               ; =0
     804:      	orr	w11, w21, #0x18
     808:      	dup.4s	v7, w11
     80c:      	orr.16b	v17, v7, v0
     810:      	orr.16b	v18, v7, v1
     814:      	umull2.2d	v7, v17, v2
     818:      	umull2.2d	v16, v18, v2
     81c:      	umull.2d	v17, v17, v2
     820:      	umull.2d	v18, v18, v2
     824:      	dup.2d	v19, x22
     828:      	add.2d	v20, v19, v7
     82c:      	add.2d	v21, v19, v17
     830:      	add.2d	v22, v19, v16
     834:      	add.2d	v19, v19, v18
     838:      	shl.2d	v19, v19, #0x2
     83c:      	shl.2d	v22, v22, #0x2
     840:      	shl.2d	v21, v21, #0x2
     844:      	shl.2d	v20, v20, #0x2
     848:      	add.2d	v20, v5, v20
     84c:      	add.2d	v21, v5, v21
     850:      	add.2d	v22, v5, v22
     854:      	add.2d	v19, v5, v19
     858:      	mov.d	x11, v19[1]
     85c:      	fmov	x21, d19
     860:      	mov.d	x23, v22[1]
     864:      	fmov	x24, d22
     868:      	mov.d	x25, v21[1]
     86c:      	fmov	x26, d21
     870:      	mov.d	x27, v20[1]
     874:      	ldr	s19, [x21]
     878:      	ld1.s	{ v19 }[1], [x11]
     87c:      	fmov	x11, d20
     880:      	ld1.s	{ v19 }[2], [x24]
     884:      	ld1.s	{ v19 }[3], [x23]
     888:      	ldr	s20, [x26]
     88c:      	ld1.s	{ v20 }[1], [x25]
     890:      	ld1.s	{ v20 }[2], [x11]
     894:      	ld1.s	{ v20 }[3], [x27]
     898:      	add	x11, x6, x22, lsl #5
     89c:      	stp	q19, q20, [x11]
     8a0:      	add	x22, x22, #0x1
     8a4:      	cmp	x22, x14
     8a8:      	b.ne	0x824 <ltmp0+0x824>
     8ac:      	ldp	q19, q5, [x6]
     8b0:      	fmul.4s	v5, v5, v5
     8b4:      	fmul.4s	v19, v19, v19
     8b8:      	ldp	q20, q21, [x6, #0x20]
     8bc:      	fmul.4s	v21, v21, v21
     8c0:      	fmul.4s	v20, v20, v20
     8c4:      	ldp	q23, q22, [x6, #0x40]
     8c8:      	fmul.4s	v22, v22, v22
     8cc:      	fmul.4s	v23, v23, v23
     8d0:      	ldp	q24, q25, [x6, #0x60]
     8d4:      	fmul.4s	v25, v25, v25
     8d8:      	fmul.4s	v24, v24, v24
     8dc:      	add	x21, x6, #0xe0
     8e0:      	mov	w22, #0x4               ; =4
     8e4:      	ldp	q27, q26, [x21, #-0x60]
     8e8:      	fmul.4s	v27, v27, v27
     8ec:      	fmul.4s	v26, v26, v26
     8f0:      	fadd.4s	v5, v5, v26
     8f4:      	fadd.4s	v19, v19, v27
     8f8:      	ldp	q27, q26, [x21, #-0x40]
     8fc:      	fmul.4s	v27, v27, v27
     900:      	fmul.4s	v26, v26, v26
     904:      	fadd.4s	v21, v21, v26
     908:      	fadd.4s	v20, v20, v27
     90c:      	ldp	q27, q26, [x21, #-0x20]
     910:      	fmul.4s	v27, v27, v27
     914:      	fmul.4s	v26, v26, v26
     918:      	fadd.4s	v22, v22, v26
     91c:      	fadd.4s	v23, v23, v27
     920:      	ldp	q27, q26, [x21], #0x80
     924:      	fmul.4s	v27, v27, v27
     928:      	fmul.4s	v26, v26, v26
     92c:      	fadd.4s	v25, v25, v26
     930:      	fadd.4s	v24, v24, v27
     934:      	cmp	x22, #0xffc
     938:      	add	x22, x22, #0x4
     93c:      	b.lo	0x8e4 <ltmp0+0x8e4>
     940:      	ldp	q26, q27, [x19]
     944:      	mov	x19, x20
     948:      	mov	w21, #0x1001            ; =4097
     94c:      	ld1r.4s	{ v28 }, [x7], #4
     950:      	stp	q28, q28, [x19], #0x20
     954:      	subs	x21, x21, #0x1
     958:      	b.ne	0x94c <ltmp0+0x94c>
     95c:      	mov	x7, #0x0                ; =0
     960:      	fmul.4s	v27, v27, v27
     964:      	fmul.4s	v26, v26, v26
     968:      	fadd.4s	v19, v19, v26
     96c:      	fadd.4s	v5, v5, v27
     970:      	fadd.4s	v5, v21, v5
     974:      	fadd.4s	v19, v20, v19
     978:      	fadd.4s	v19, v23, v19
     97c:      	fadd.4s	v5, v22, v5
     980:      	fadd.4s	v5, v25, v5
     984:      	fadd.4s	v19, v24, v19
     988:      	fdiv.4s	v19, v19, v4
     98c:      	fdiv.4s	v4, v5, v4
     990:      	fadd.4s	v4, v4, v3
     994:      	fadd.4s	v3, v19, v3
     998:      	fsqrt.4s	v3, v3
     99c:      	fsqrt.4s	v4, v4
     9a0:      	dup.2d	v5, x7
     9a4:      	add.2d	v19, v5, v7
     9a8:      	add.2d	v20, v5, v17
     9ac:      	add.2d	v21, v5, v16
     9b0:      	add.2d	v5, v5, v18
     9b4:      	lsl	x11, x7, #5
     9b8:      	add	x19, x6, x11
     9bc:      	ldp	q23, q22, [x19]
     9c0:      	fdiv.4s	v23, v23, v3
     9c4:      	fdiv.4s	v22, v22, v4
     9c8:      	add	x11, x20, x11
     9cc:      	ldp	q24, q25, [x11]
     9d0:      	fmul.4s	v22, v22, v25
     9d4:      	fmul.4s	v23, v23, v24
     9d8:      	shl.2d	v5, v5, #0x2
     9dc:      	shl.2d	v21, v21, #0x2
     9e0:      	shl.2d	v20, v20, #0x2
     9e4:      	shl.2d	v19, v19, #0x2
     9e8:      	add.2d	v19, v6, v19
     9ec:      	add.2d	v5, v6, v5
     9f0:      	mov.d	x11, v5[1]
     9f4:      	fmov	x19, d5
     9f8:      	str	s23, [x19]
     9fc:      	st1.s	{ v23 }[1], [x11]
     a00:      	add.2d	v5, v6, v21
     a04:      	mov.d	x11, v5[1]
     a08:      	fmov	x19, d5
     a0c:      	st1.s	{ v23 }[2], [x19]
     a10:      	add.2d	v5, v6, v20
     a14:      	st1.s	{ v23 }[3], [x11]
     a18:      	mov.d	x11, v5[1]
     a1c:      	fmov	x19, d5
     a20:      	str	s22, [x19]
     a24:      	st1.s	{ v22 }[1], [x11]
     a28:      	mov.d	x11, v19[1]
     a2c:      	fmov	x19, d19
     a30:      	st1.s	{ v22 }[2], [x19]
     a34:      	st1.s	{ v22 }[3], [x11]
     a38:      	add	x7, x7, #0x1
     a3c:      	cmp	x7, x14
     a40:      	b.ne	0x9a0 <ltmp0+0x9a0>
     a44:      	b	0x6c <ltmp0+0x6c>
     a48:      	mov	x17, x30
     a4c:      	mov	x4, x15
     a50:      	mov	x1, x13
     a54:      	lsr	x19, x6, #3
     a58:      	cmp	x6, #0x8
     a5c:      	b.lo	0xcec <ltmp0+0xcec>
     a60:      	mov	w7, #0x0                ; =0
     a64:      	ldr	x20, [x2, #0x88]
     a68:      	add	x21, x20, #0x20, lsl #12 ; =0x20000
     a6c:      	ldr	x9, [sp]
     a70:      	ldr	x22, [x9]
     a74:      	ldr	x23, [x9, #0x10]
     a78:      	ldr	x24, [x9, #0x30]
     a7c:      	lsl	w25, w5, #5
     a80:      	mov	w9, #0x20               ; =32
     a84:      	movk	w9, #0x2, lsl #16
     a88:      	add	x26, x20, x9
     a8c:      	add	x27, x20, #0xe0
     a90:      	mov	x28, #0x0               ; =0
     a94:      	add	w11, w25, w7, lsl #3
     a98:      	dup.4s	v5, w11
     a9c:      	orr.16b	v7, v5, v0
     aa0:      	orr.16b	v16, v5, v1
     aa4:      	umull2.2d	v5, v7, v2
     aa8:      	umull2.2d	v6, v16, v2
     aac:      	umull.2d	v7, v7, v2
     ab0:      	umull.2d	v16, v16, v2
     ab4:      	dup.2d	v17, x28
     ab8:      	add.2d	v18, v17, v5
     abc:      	add.2d	v19, v17, v7
     ac0:      	add.2d	v20, v17, v6
     ac4:      	add.2d	v17, v17, v16
     ac8:      	shl.2d	v17, v17, #0x2
     acc:      	shl.2d	v20, v20, #0x2
     ad0:      	shl.2d	v19, v19, #0x2
     ad4:      	shl.2d	v18, v18, #0x2
     ad8:      	dup.2d	v21, x22
     adc:      	add.2d	v18, v21, v18
     ae0:      	add.2d	v19, v21, v19
     ae4:      	add.2d	v20, v21, v20
     ae8:      	add.2d	v17, v21, v17
     aec:      	mov.d	x11, v17[1]
     af0:      	fmov	x30, d17
     af4:      	mov.d	x13, v20[1]
     af8:      	fmov	x15, d20
     afc:      	mov.d	x16, v19[1]
     b00:      	fmov	x9, d19
     b04:      	mov.d	x10, v18[1]
     b08:      	ldr	s17, [x30]
     b0c:      	ld1.s	{ v17 }[1], [x11]
     b10:      	fmov	x11, d18
     b14:      	ld1.s	{ v17 }[2], [x15]
     b18:      	ld1.s	{ v17 }[3], [x13]
     b1c:      	ldr	s18, [x9]
     b20:      	ld1.s	{ v18 }[1], [x16]
     b24:      	ld1.s	{ v18 }[2], [x11]
     b28:      	ld1.s	{ v18 }[3], [x10]
     b2c:      	add	x9, x20, x28, lsl #5
     b30:      	stp	q17, q18, [x9]
     b34:      	add	x28, x28, #0x1
     b38:      	cmp	x28, x14
     b3c:      	b.ne	0xab4 <ltmp0+0xab4>
     b40:      	ldp	q18, q17, [x20]
     b44:      	fmul.4s	v17, v17, v17
     b48:      	fmul.4s	v18, v18, v18
     b4c:      	ldp	q19, q20, [x20, #0x20]
     b50:      	fmul.4s	v20, v20, v20
     b54:      	fmul.4s	v19, v19, v19
     b58:      	ldp	q22, q21, [x20, #0x40]
     b5c:      	fmul.4s	v21, v21, v21
     b60:      	fmul.4s	v22, v22, v22
     b64:      	ldp	q23, q24, [x20, #0x60]
     b68:      	fmul.4s	v24, v24, v24
     b6c:      	fmul.4s	v23, v23, v23
     b70:      	mov	x28, x27
     b74:      	mov	w30, #0x4               ; =4
     b78:      	ldp	q26, q25, [x28, #-0x60]
     b7c:      	fmul.4s	v26, v26, v26
     b80:      	fmul.4s	v25, v25, v25
     b84:      	fadd.4s	v17, v17, v25
     b88:      	fadd.4s	v18, v18, v26
     b8c:      	ldp	q26, q25, [x28, #-0x40]
     b90:      	fmul.4s	v26, v26, v26
     b94:      	fmul.4s	v25, v25, v25
     b98:      	fadd.4s	v20, v20, v25
     b9c:      	fadd.4s	v19, v19, v26
     ba0:      	ldp	q26, q25, [x28, #-0x20]
     ba4:      	fmul.4s	v26, v26, v26
     ba8:      	fmul.4s	v25, v25, v25
     bac:      	fadd.4s	v21, v21, v25
     bb0:      	fadd.4s	v22, v22, v26
     bb4:      	ldp	q26, q25, [x28], #0x80
     bb8:      	fmul.4s	v26, v26, v26
     bbc:      	fmul.4s	v25, v25, v25
     bc0:      	fadd.4s	v24, v24, v25
     bc4:      	fadd.4s	v23, v23, v26
     bc8:      	cmp	x30, #0xffc
     bcc:      	add	x30, x30, #0x4
     bd0:      	b.lo	0xb78 <ltmp0+0xb78>
     bd4:      	ldp	q25, q26, [x21]
     bd8:      	mov	x28, x23
     bdc:      	mov	x30, x26
     be0:      	mov	w11, #0x1001            ; =4097
     be4:      	ld1r.4s	{ v27 }, [x28], #4
     be8:      	stp	q27, q27, [x30], #0x20
     bec:      	subs	x11, x11, #0x1
     bf0:      	b.ne	0xbe4 <ltmp0+0xbe4>
     bf4:      	mov	x28, #0x0               ; =0
     bf8:      	fmul.4s	v26, v26, v26
     bfc:      	fmul.4s	v25, v25, v25
     c00:      	fadd.4s	v18, v18, v25
     c04:      	fadd.4s	v17, v17, v26
     c08:      	fadd.4s	v17, v20, v17
     c0c:      	fadd.4s	v18, v19, v18
     c10:      	fadd.4s	v18, v22, v18
     c14:      	fadd.4s	v17, v21, v17
     c18:      	fadd.4s	v17, v24, v17
     c1c:      	fadd.4s	v18, v23, v18
     c20:      	fdiv.4s	v18, v18, v4
     c24:      	fdiv.4s	v17, v17, v4
     c28:      	fadd.4s	v19, v17, v3
     c2c:      	fadd.4s	v17, v18, v3
     c30:      	fsqrt.4s	v17, v17
     c34:      	fsqrt.4s	v18, v19
     c38:      	dup.2d	v19, x28
     c3c:      	add.2d	v20, v19, v5
     c40:      	add.2d	v21, v19, v7
     c44:      	add.2d	v22, v19, v6
     c48:      	add.2d	v19, v19, v16
     c4c:      	lsl	x9, x28, #5
     c50:      	add	x10, x20, x9
     c54:      	ldp	q24, q23, [x10]
     c58:      	fdiv.4s	v24, v24, v17
     c5c:      	fdiv.4s	v23, v23, v18
     c60:      	add	x9, x26, x9
     c64:      	ldp	q25, q26, [x9]
     c68:      	fmul.4s	v23, v23, v26
     c6c:      	fmul.4s	v24, v24, v25
     c70:      	shl.2d	v19, v19, #0x2
     c74:      	shl.2d	v22, v22, #0x2
     c78:      	shl.2d	v21, v21, #0x2
     c7c:      	shl.2d	v20, v20, #0x2
     c80:      	dup.2d	v25, x24
     c84:      	add.2d	v20, v25, v20
     c88:      	add.2d	v19, v25, v19
     c8c:      	mov.d	x9, v19[1]
     c90:      	fmov	x10, d19
     c94:      	str	s24, [x10]
     c98:      	st1.s	{ v24 }[1], [x9]
     c9c:      	add.2d	v19, v25, v22
     ca0:      	mov.d	x9, v19[1]
     ca4:      	fmov	x10, d19
     ca8:      	st1.s	{ v24 }[2], [x10]
     cac:      	add.2d	v19, v25, v21
     cb0:      	st1.s	{ v24 }[3], [x9]
     cb4:      	mov.d	x9, v19[1]
     cb8:      	fmov	x10, d19
     cbc:      	str	s23, [x10]
     cc0:      	st1.s	{ v23 }[1], [x9]
     cc4:      	mov.d	x9, v20[1]
     cc8:      	fmov	x10, d20
     ccc:      	st1.s	{ v23 }[2], [x10]
     cd0:      	st1.s	{ v23 }[3], [x9]
     cd4:      	add	x28, x28, #0x1
     cd8:      	cmp	x28, x14
     cdc:      	b.ne	0xc38 <ltmp0+0xc38>
     ce0:      	add	w7, w7, #0x1
     ce4:      	cmp	w7, w19
     ce8:      	b.ne	0xa90 <ltmp0+0xa90>
     cec:      	and	w11, w6, #0x7
     cf0:      	mov	x13, x1
     cf4:      	mov	x15, x4
     cf8:      	mov	w16, #0x20              ; =32
     cfc:      	mov	w1, #0x800              ; =2048
     d00:      	movk	w1, #0x4580, lsl #16
     d04:      	mov	w4, #0xc5ac             ; =50604
     d08:      	movk	w4, #0x3727, lsl #16
     d0c:      	mov	x30, x17
     d10:      	cbz	w11, 0x6c <ltmp0+0x6c>
     d14:      	dup.4s	v6, w11
     d18:      	cmhi.4s	v5, v6, v0
     d1c:      	cmhi.4s	v6, v6, v1
     d20:      	uzp1.8h	v20, v6, v5
     d24:      	umaxv.8h	h7, v20
     d28:      	fmov	w9, s7
     d2c:      	tbz	w9, #0x0, 0x6c <ltmp0+0x6c>
     d30:      	mov	x22, #0x0               ; =0
     d34:      	ldr	x6, [x2, #0x88]
     d38:      	add	x21, x6, #0x20, lsl #12 ; =0x20000
     d3c:      	mov	w9, #0x20               ; =32
     d40:      	movk	w9, #0x2, lsl #16
     d44:      	add	x7, x6, x9
     d48:      	ldr	x10, [sp]
     d4c:      	ldr	x23, [x10]
     d50:      	ldr	x20, [x10, #0x10]
     d54:      	lsl	w9, w19, #3
     d58:      	orr	w9, w9, w5, lsl #5
     d5c:      	dup.4s	v7, w9
     d60:      	ldr	x19, [x10, #0x30]
     d64:      	orr.16b	v16, v7, v1
     d68:      	orr.16b	v7, v7, v0
     d6c:      	and.16b	v17, v5, v7
     d70:      	and.16b	v18, v6, v16
     d74:      	umull2.2d	v7, v17, v2
     d78:      	umull2.2d	v16, v18, v2
     d7c:      	umull.2d	v17, v17, v2
     d80:      	umull.2d	v18, v18, v2
     d84:      	adrp	x10, 0x0 <ltmp0>
     d88:      	b	0xdac <ltmp0+0xdac>
     d8c:      	add	x9, x6, x22, lsl #5
     d90:      	ldp	q23, q24, [x9]
     d94:      	bif.16b	v22, v24, v5
     d98:      	bif.16b	v21, v23, v6
     d9c:      	stp	q21, q22, [x9]
     da0:      	add	x22, x22, #0x1
     da4:      	cmp	x22, x14
     da8:      	b.eq	0xeac <ltmp0+0xeac>
     dac:      	ldr	q19, [x10]
     db0:      	and.16b	v19, v20, v19
     db4:      	addv.8h	h19, v19
     db8:      	fmov	w24, s19
     dbc:      	dup.2d	v23, x22
     dc0:      	add.2d	v21, v23, v18
     dc4:      	shl.2d	v21, v21, #0x2
     dc8:      	dup.2d	v24, x23
     dcc:      	add.2d	v25, v24, v21
     dd0:      	movi.2d	v21, #0000000000000000
     dd4:      	movi.2d	v22, #0000000000000000
     dd8:      	tbnz	w24, #0x0, 0xe24 <ltmp0+0xe24>
     ddc:      	and	w24, w24, #0xff
     de0:      	tbnz	w24, #0x1, 0xe34 <ltmp0+0xe34>
     de4:      	add.2d	v25, v23, v16
     de8:      	shl.2d	v25, v25, #0x2
     dec:      	add.2d	v25, v24, v25
     df0:      	tbnz	w24, #0x2, 0xe4c <ltmp0+0xe4c>
     df4:      	tbnz	w24, #0x3, 0xe58 <ltmp0+0xe58>
     df8:      	add.2d	v25, v23, v17
     dfc:      	shl.2d	v25, v25, #0x2
     e00:      	add.2d	v25, v24, v25
     e04:      	tbnz	w24, #0x4, 0xe70 <ltmp0+0xe70>
     e08:      	tbnz	w24, #0x5, 0xe7c <ltmp0+0xe7c>
     e0c:      	add.2d	v23, v23, v7
     e10:      	shl.2d	v23, v23, #0x2
     e14:      	add.2d	v23, v24, v23
     e18:      	tbnz	w24, #0x6, 0xe94 <ltmp0+0xe94>
     e1c:      	tbz	w24, #0x7, 0xd8c <ltmp0+0xd8c>
     e20:      	b	0xea0 <ltmp0+0xea0>
     e24:      	fmov	x9, d25
     e28:      	ldr	s21, [x9]
     e2c:      	and	w24, w24, #0xff
     e30:      	tbz	w24, #0x1, 0xde4 <ltmp0+0xde4>
     e34:      	mov.d	x9, v25[1]
     e38:      	ld1.s	{ v21 }[1], [x9]
     e3c:      	add.2d	v25, v23, v16
     e40:      	shl.2d	v25, v25, #0x2
     e44:      	add.2d	v25, v24, v25
     e48:      	tbz	w24, #0x2, 0xdf4 <ltmp0+0xdf4>
     e4c:      	fmov	x9, d25
     e50:      	ld1.s	{ v21 }[2], [x9]
     e54:      	tbz	w24, #0x3, 0xdf8 <ltmp0+0xdf8>
     e58:      	mov.d	x9, v25[1]
     e5c:      	ld1.s	{ v21 }[3], [x9]
     e60:      	add.2d	v25, v23, v17
     e64:      	shl.2d	v25, v25, #0x2
     e68:      	add.2d	v25, v24, v25
     e6c:      	tbz	w24, #0x4, 0xe08 <ltmp0+0xe08>
     e70:      	fmov	x9, d25
     e74:      	ld1.s	{ v22 }[0], [x9]
     e78:      	tbz	w24, #0x5, 0xe0c <ltmp0+0xe0c>
     e7c:      	mov.d	x9, v25[1]
     e80:      	ld1.s	{ v22 }[1], [x9]
     e84:      	add.2d	v23, v23, v7
     e88:      	shl.2d	v23, v23, #0x2
     e8c:      	add.2d	v23, v24, v23
     e90:      	tbz	w24, #0x6, 0xe1c <ltmp0+0xe1c>
     e94:      	fmov	x9, d23
     e98:      	ld1.s	{ v22 }[2], [x9]
     e9c:      	tbz	w24, #0x7, 0xd8c <ltmp0+0xd8c>
     ea0:      	mov.d	x9, v23[1]
     ea4:      	ld1.s	{ v22 }[3], [x9]
     ea8:      	b	0xd8c <ltmp0+0xd8c>
     eac:      	ldp	q21, q20, [x6]
     eb0:      	fmul.4s	v22, v21, v21
     eb4:      	fmul.4s	v20, v20, v20
     eb8:      	ldp	q23, q21, [x6, #0x20]
     ebc:      	fmul.4s	v23, v23, v23
     ec0:      	fmul.4s	v24, v21, v21
     ec4:      	ldp	q25, q21, [x6, #0x40]
     ec8:      	fmul.4s	v26, v25, v25
     ecc:      	fmul.4s	v28, v21, v21
     ed0:      	ldp	q25, q21, [x6, #0x60]
     ed4:      	fmul.4s	v29, v25, v25
     ed8:      	fmul.4s	v30, v21, v21
     edc:      	and.16b	v21, v5, v20
     ee0:      	and.16b	v27, v6, v22
     ee4:      	and.16b	v25, v5, v24
     ee8:      	and.16b	v24, v6, v23
     eec:      	and.16b	v20, v5, v28
     ef0:      	and.16b	v26, v6, v26
     ef4:      	and.16b	v23, v5, v30
     ef8:      	and.16b	v22, v6, v29
     efc:      	add	x22, x6, #0xe0
     f00:      	mov	w23, #0x4               ; =4
     f04:      	ldp	q29, q28, [x22, #-0x60]
     f08:      	and.16b	v29, v6, v29
     f0c:      	and.16b	v28, v5, v28
     f10:      	fmul.4s	v28, v28, v28
     f14:      	fmul.4s	v29, v29, v29
     f18:      	fadd.4s	v29, v27, v29
     f1c:      	fadd.4s	v28, v21, v28
     f20:      	ldp	q31, q30, [x22, #-0x40]
     f24:      	and.16b	v31, v6, v31
     f28:      	and.16b	v30, v5, v30
     f2c:      	fmul.4s	v30, v30, v30
     f30:      	fmul.4s	v31, v31, v31
     f34:      	fadd.4s	v31, v24, v31
     f38:      	fadd.4s	v30, v25, v30
     f3c:      	ldp	q9, q8, [x22, #-0x20]
     f40:      	and.16b	v9, v6, v9
     f44:      	and.16b	v8, v5, v8
     f48:      	fmul.4s	v8, v8, v8
     f4c:      	fmul.4s	v9, v9, v9
     f50:      	fadd.4s	v9, v26, v9
     f54:      	fadd.4s	v8, v20, v8
     f58:      	ldp	q11, q10, [x22], #0x80
     f5c:      	and.16b	v11, v6, v11
     f60:      	and.16b	v10, v5, v10
     f64:      	fmul.4s	v10, v10, v10
     f68:      	fmul.4s	v11, v11, v11
     f6c:      	fadd.4s	v11, v22, v11
     f70:      	fadd.4s	v10, v23, v10
     f74:      	bit.16b	v21, v28, v5
     f78:      	bit.16b	v27, v29, v6
     f7c:      	bit.16b	v25, v30, v5
     f80:      	bit.16b	v24, v31, v6
     f84:      	bit.16b	v20, v8, v5
     f88:      	bit.16b	v26, v9, v6
     f8c:      	bit.16b	v23, v10, v5
     f90:      	bit.16b	v22, v11, v6
     f94:      	cmp	x23, #0xffc
     f98:      	add	x23, x23, #0x4
     f9c:      	b.lo	0xf04 <ltmp0+0xf04>
     fa0:      	ldp	q29, q28, [x21]
     fa4:      	mov	x21, x7
     fa8:      	mov	w22, #0x1001            ; =4097
     fac:      	ld1r.4s	{ v30 }, [x20], #4
     fb0:      	ldp	q31, q8, [x21]
     fb4:      	bit.16b	v8, v30, v5
     fb8:      	bif.16b	v30, v31, v6
     fbc:      	stp	q30, q8, [x21], #0x20
     fc0:      	subs	x22, x22, #0x1
     fc4:      	b.ne	0xfac <ltmp0+0xfac>
     fc8:      	mov	x20, #0x0               ; =0
     fcc:      	and.16b	v29, v6, v29
     fd0:      	and.16b	v28, v5, v28
     fd4:      	fmul.4s	v28, v28, v28
     fd8:      	fmul.4s	v29, v29, v29
     fdc:      	fadd.4s	v27, v27, v29
     fe0:      	fadd.4s	v21, v21, v28
     fe4:      	fadd.4s	v21, v25, v21
     fe8:      	fadd.4s	v24, v24, v27
     fec:      	fadd.4s	v24, v26, v24
     ff0:      	fadd.4s	v20, v20, v21
     ff4:      	fadd.4s	v20, v23, v20
     ff8:      	fadd.4s	v21, v22, v24
     ffc:      	fdiv.4s	v21, v21, v4
    1000:      	fdiv.4s	v4, v20, v4
    1004:      	fadd.4s	v4, v4, v3
    1008:      	fadd.4s	v3, v21, v3
    100c:      	fsqrt.4s	v20, v3
    1010:      	fsqrt.4s	v3, v4
    1014:      	and.16b	v3, v5, v3
    1018:      	and.16b	v4, v6, v20
    101c:      	b	0x102c <ltmp0+0x102c>
    1020:      	add	x20, x20, #0x1
    1024:      	cmp	x20, x14
    1028:      	b.eq	0x6c <ltmp0+0x6c>
    102c:      	fmov	w21, s19
    1030:      	dup.2d	v20, x20
    1034:      	add.2d	v21, v20, v18
    1038:      	lsl	x9, x20, #5
    103c:      	add	x10, x6, x9
    1040:      	ldp	q23, q22, [x10]
    1044:      	and.16b	v23, v6, v23
    1048:      	fdiv.4s	v24, v23, v4
    104c:      	add	x9, x7, x9
    1050:      	ldp	q25, q23, [x9]
    1054:      	and.16b	v25, v6, v25
    1058:      	fmul.4s	v24, v24, v25
    105c:      	shl.2d	v25, v21, #0x2
    1060:      	dup.2d	v21, x19
    1064:      	add.2d	v25, v21, v25
    1068:      	tbnz	w21, #0x0, 0x10cc <ltmp0+0x10cc>
    106c:      	and	w21, w21, #0xff
    1070:      	tbnz	w21, #0x1, 0x10dc <ltmp0+0x10dc>
    1074:      	add.2d	v25, v20, v16
    1078:      	shl.2d	v25, v25, #0x2
    107c:      	add.2d	v25, v21, v25
    1080:      	tbnz	w21, #0x2, 0x10f4 <ltmp0+0x10f4>
    1084:      	tbz	w21, #0x3, 0x1090 <ltmp0+0x1090>
    1088:      	mov.d	x9, v25[1]
    108c:      	st1.s	{ v24 }[3], [x9]
    1090:      	add.2d	v24, v20, v17
    1094:      	and.16b	v22, v5, v22
    1098:      	fdiv.4s	v22, v22, v3
    109c:      	and.16b	v23, v5, v23
    10a0:      	fmul.4s	v22, v22, v23
    10a4:      	shl.2d	v23, v24, #0x2
    10a8:      	add.2d	v23, v21, v23
    10ac:      	tbnz	w21, #0x4, 0x1104 <ltmp0+0x1104>
    10b0:      	tbnz	w21, #0x5, 0x1110 <ltmp0+0x1110>
    10b4:      	add.2d	v20, v20, v7
    10b8:      	shl.2d	v20, v20, #0x2
    10bc:      	add.2d	v20, v21, v20
    10c0:      	tbnz	w21, #0x6, 0x1128 <ltmp0+0x1128>
    10c4:      	tbz	w21, #0x7, 0x1020 <ltmp0+0x1020>
    10c8:      	b	0x1134 <ltmp0+0x1134>
    10cc:      	fmov	x9, d25
    10d0:      	str	s24, [x9]
    10d4:      	and	w21, w21, #0xff
    10d8:      	tbz	w21, #0x1, 0x1074 <ltmp0+0x1074>
    10dc:      	mov.d	x9, v25[1]
    10e0:      	st1.s	{ v24 }[1], [x9]
    10e4:      	add.2d	v25, v20, v16
    10e8:      	shl.2d	v25, v25, #0x2
    10ec:      	add.2d	v25, v21, v25
    10f0:      	tbz	w21, #0x2, 0x1084 <ltmp0+0x1084>
    10f4:      	fmov	x9, d25
    10f8:      	st1.s	{ v24 }[2], [x9]
    10fc:      	tbnz	w21, #0x3, 0x1088 <ltmp0+0x1088>
    1100:      	b	0x1090 <ltmp0+0x1090>
    1104:      	fmov	x9, d23
    1108:      	str	s22, [x9]
    110c:      	tbz	w21, #0x5, 0x10b4 <ltmp0+0x10b4>
    1110:      	mov.d	x9, v23[1]
    1114:      	st1.s	{ v22 }[1], [x9]
    1118:      	add.2d	v20, v20, v7
    111c:      	shl.2d	v20, v20, #0x2
    1120:      	add.2d	v20, v21, v20
    1124:      	tbz	w21, #0x6, 0x10c4 <ltmp0+0x10c4>
    1128:      	fmov	x9, d20
    112c:      	st1.s	{ v22 }[2], [x9]
    1130:      	tbz	w21, #0x7, 0x1020 <ltmp0+0x1020>
    1134:      	mov.d	x9, v20[1]
    1138:      	st1.s	{ v22 }[3], [x9]
    113c:      	b	0x1020 <ltmp0+0x1020>
    1140:      	stp	w5, w0, [x2]
    1144:      	str	w30, [x2, #0x8]
    1148:      	mov	w8, #0x18               ; =24
    114c:      	str	w8, [x2, #0x24]
    1150:      	ldp	x29, x30, [sp, #0x80]
    1154:      	ldp	x20, x19, [sp, #0x70]
    1158:      	ldp	x22, x21, [sp, #0x60]
    115c:      	ldp	x24, x23, [sp, #0x50]
    1160:      	ldp	x26, x25, [sp, #0x40]
    1164:      	ldp	x28, x27, [sp, #0x30]
    1168:      	ldp	d9, d8, [sp, #0x20]
    116c:      	ldp	d11, d10, [sp, #0x10]
    1170:      	add	sp, sp, #0x90
    1174:      	ret

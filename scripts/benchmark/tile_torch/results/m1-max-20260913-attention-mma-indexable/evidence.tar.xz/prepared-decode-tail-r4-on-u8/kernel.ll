; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill31, align 64
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca i64, align 8
  store i64 0, ptr %.slot33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %tile_snapshot.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill42, align 64
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %.spill44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill44, align 64
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca i64, align 8
  store i64 0, ptr %.slot48, align 4
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca i64, align 8
  store i64 0, ptr %.slot50, align 4
  %.slot51 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca i64, align 8
  store i64 0, ptr %.slot52, align 4
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca i64, align 8
  store i64 0, ptr %.slot54, align 4
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca i64, align 8
  store i64 0, ptr %.slot58, align 4
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca i64, align 8
  store i64 0, ptr %.slot60, align 4
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca i64, align 8
  store i64 0, ptr %.slot62, align 4
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca i64, align 8
  store i64 0, ptr %.slot64, align 4
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.slot66 = alloca i64, align 8
  store i64 0, ptr %.slot66, align 4
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.slot68 = alloca i64, align 8
  store i64 0, ptr %.slot68, align 4
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca i64, align 8
  store i64 0, ptr %.slot70, align 4
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca i64, align 8
  store i64 0, ptr %.slot72, align 4
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca i64, align 8
  store i64 0, ptr %.slot74, align 4
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca i64, align 8
  store i64 0, ptr %.slot76, align 4
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.spill78 = alloca i64, align 8
  store i64 0, ptr %.spill78, align 4
  %.spill79 = alloca i1, align 1
  store i1 false, ptr %.spill79, align 1
  %.spill80 = alloca i1, align 1
  store i1 false, ptr %.spill80, align 1
  %.spill81 = alloca i1, align 1
  store i1 false, ptr %.spill81, align 1
  %.spill82 = alloca i1, align 1
  store i1 false, ptr %.spill82, align 1
  %.spill83 = alloca i1, align 1
  store i1 false, ptr %.spill83, align 1
  %.spill84 = alloca i1, align 1
  store i1 false, ptr %.spill84, align 1
  %.spill85 = alloca i1, align 1
  store i1 false, ptr %.spill85, align 1
  %.spill86 = alloca i1, align 1
  store i1 false, ptr %.spill86, align 1
  %.spill87 = alloca i1, align 1
  store i1 false, ptr %.spill87, align 1
  %.spill88 = alloca i1, align 1
  store i1 false, ptr %.spill88, align 1
  %.spill89 = alloca i1, align 1
  store i1 false, ptr %.spill89, align 1
  %.spill90 = alloca i1, align 1
  store i1 false, ptr %.spill90, align 1
  %.spill91 = alloca i1, align 1
  store i1 false, ptr %.spill91, align 1
  %.spill92 = alloca i1, align 1
  store i1 false, ptr %.spill92, align 1
  %.spill93 = alloca i1, align 1
  store i1 false, ptr %.spill93, align 1
  %.spill94 = alloca i1, align 1
  store i1 false, ptr %.spill94, align 1
  %.spill95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill100, align 32
  %.spill101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill103, align 32
  %.spill104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill104, align 32
  %.spill105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.spill106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill106, align 32
  %.spill107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill108, align 32
  %.spill109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill109, align 32
  %.spill110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill110, align 32
  %tile_snapshot.spill111 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill111, align 64
  %.slot112 = alloca i64, align 8
  store i64 0, ptr %.slot112, align 4
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.spill114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill114, align 32
  %.spill115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill115, align 32
  %tile_snapshot.spill116 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill116, align 64
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.slot118 = alloca i64, align 8
  store i64 0, ptr %.slot118, align 4
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %tile_snapshot.spill121 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill121, align 64
  %.slot122 = alloca i64, align 8
  store i64 0, ptr %.slot122, align 4
  %.spill123 = alloca i64, align 8
  store i64 0, ptr %.spill123, align 4
  %.spill124 = alloca i64, align 8
  store i64 0, ptr %.spill124, align 4
  %.spill125 = alloca i64, align 8
  store i64 0, ptr %.spill125, align 4
  %.spill126 = alloca i64, align 8
  store i64 0, ptr %.spill126, align 4
  %.slot127 = alloca i64, align 8
  store i64 0, ptr %.slot127, align 4
  %.slot128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot128, align 32
  %.slot129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot129, align 32
  %.slot130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot130, align 32
  %.slot131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot131, align 32
  %.slot132 = alloca i64, align 8
  store i64 0, ptr %.slot132, align 4
  %.slot133 = alloca i64, align 8
  store i64 0, ptr %.slot133, align 4
  %.slot134 = alloca i64, align 8
  store i64 0, ptr %.slot134, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert135 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat136 = shufflevector <8 x i32> %.splatinsert135, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat136, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert137 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat138 = shufflevector <8 x i32> %.splatinsert137, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat138, %61
  %64 = mul i32 %52, 1
  %.splatinsert139 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat140 = shufflevector <8 x i32> %.splatinsert139, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat140, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert141 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat142 = shufflevector <8 x i32> %.splatinsert141, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat142, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert143 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat144 = shufflevector <8 x i32> %.splatinsert143, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat144
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  store i64 0, ptr %.spill29, align 4
  %80 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 3), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = load <8 x i64>, ptr %.spill30, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill30, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %94 = icmp slt i64 %.state, 80
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load i64, ptr %.spill29, align 4
  %95 = add i64 %.spill.load, 0
  %.spill.load145 = load <8 x i64>, ptr %.spill, align 64
  %96 = add <8 x i64> %.spill.load145, zeroinitializer
  %97 = mul i64 %95, 6
  %.splatinsert146 = insertelement <8 x i64> poison, i64 %97, i64 0
  %.splat147 = shufflevector <8 x i64> %.splatinsert146, <8 x i64> poison, <8 x i32> zeroinitializer
  %98 = add <8 x i64> %.splat147, %96
  %.spill.load148 = load i64, ptr %.spill29, align 4
  %99 = add i64 %.spill.load148, 0
  %100 = mul <8 x i64> %98, splat (i64 1)
  %.splatinsert149 = insertelement <8 x i64> poison, i64 %99, i64 0
  %.splat150 = shufflevector <8 x i64> %.splatinsert149, <8 x i64> poison, <8 x i32> zeroinitializer
  %101 = add <8 x i64> %100, %.splat150
  %.state151 = load i64, ptr %.slot, align 4
  %102 = add i64 0, %.state151
  %103 = mul <8 x i64> %101, splat (i64 80)
  %.splatinsert152 = insertelement <8 x i64> poison, i64 %102, i64 0
  %.splat153 = shufflevector <8 x i64> %.splatinsert152, <8 x i64> poison, <8 x i32> zeroinitializer
  %104 = add <8 x i64> %103, %.splat153
  %105 = extractvalue { ptr, i64 } %29, 0
  %106 = mul <8 x i64> %104, splat (i64 4)
  %107 = getelementptr i8, ptr %105, <8 x i64> %106
  %108 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %107, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state154 = load i64, ptr %.slot, align 4
  %.splatinsert155 = insertelement <8 x i64> poison, i64 %.state154, i64 0
  %.splat156 = shufflevector <8 x i64> %.splatinsert155, <8 x i64> poison, <8 x i32> zeroinitializer
  %111 = mul <8 x i64> %.splat156, splat (i64 32)
  %112 = add <8 x i64> %110, %111
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %109, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %114, 1
  %117 = extractelement <8 x ptr> %115, i32 0
  %118 = extractelement <8 x i64> %116, i32 0
  %119 = sub i64 %118, 0
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %121 = select i1 %120, i64 %119, i64 0
  %private.contiguous.address = getelementptr i8, ptr %117, i64 %121
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %122 = select <8 x i1> %71, <8 x float> %108, <8 x float> %private.contiguous.preserve
  store <8 x float> %122, ptr %private.contiguous.address, align 4
  %.state157 = load i64, ptr %.slot, align 4
  %123 = add i64 %.state157, 1
  store i64 %123, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %71, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %71, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill31, align 64
  %133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 0
  %136 = select <8 x i1> %71, <8 x ptr> %134, <8 x ptr> %135
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %139 = select <8 x i1> %71, <8 x i64> %137, <8 x i64> %138
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  store { <8 x ptr>, <8 x i64> } %141, ptr %tile_snapshot.spill32, align 64
  store i64 0, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state158 = load i64, ptr %.slot33, align 4
  %142 = icmp slt i64 %.state158, 96
  br i1 %142, label %direct.true159, label %direct.false160

direct.schedule.5:                                ; preds = %direct.true159
  %tile_snapshot.spill.load161 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 1
  %.state162 = load i64, ptr %.slot33, align 4
  %.splatinsert163 = insertelement <8 x i64> poison, i64 %.state162, i64 0
  %.splat164 = shufflevector <8 x i64> %.splatinsert163, <8 x i64> poison, <8 x i32> zeroinitializer
  %145 = mul <8 x i64> %.splat164, splat (i64 32)
  %146 = add <8 x i64> %144, %145
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %143, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %148, 1
  %151 = extractelement <8 x ptr> %149, i32 0
  %152 = extractelement <8 x i64> %150, i32 0
  %153 = sub i64 %152, 0
  %154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %155 = select i1 %154, i64 %153, i64 0
  %private.contiguous.address165 = getelementptr i8, ptr %151, i64 %155
  %private.contiguous.preserve166 = load <8 x float>, ptr %private.contiguous.address165, align 4
  %156 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve166
  store <8 x float> %156, ptr %private.contiguous.address165, align 4
  %.state167 = load i64, ptr %.slot33, align 4
  %157 = add i64 %.state167, 1
  store i64 %157, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false160
  store i64 0, ptr %.slot34, align 4
  %158 = load <8 x float>, ptr %.slot35, align 32
  %159 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %158
  store <8 x float> %159, ptr %.slot35, align 32
  %160 = load <8 x float>, ptr %.slot36, align 32
  %161 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %160
  store <8 x float> %161, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.84, %direct.schedule.6
  %.state168 = load i64, ptr %.slot34, align 4
  %162 = icmp slt i64 %.state168, 129
  br i1 %162, label %direct.true169, label %direct.false170

direct.schedule.8:                                ; preds = %direct.true169
  %.state171 = load i64, ptr %.slot34, align 4
  %163 = sdiv i64 %.state171, 1
  %164 = mul i64 %163, 16
  store i64 %164, ptr %.spill37, align 4
  %165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %168 = select <8 x i1> %71, <8 x ptr> %166, <8 x ptr> %167
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %171 = select <8 x i1> %71, <8 x i64> %169, <8 x i64> %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  store { <8 x ptr>, <8 x i64> } %173, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state172 = load i64, ptr %.slot39, align 4
  %174 = icmp slt i64 %.state172, 1280
  br i1 %174, label %direct.true173, label %direct.false174

direct.schedule.10:                               ; preds = %direct.true173
  %.state175 = load i64, ptr %.slot39, align 4
  %175 = srem i64 %.state175, 80
  %.state176 = load i64, ptr %.slot39, align 4
  %176 = sdiv i64 %.state176, 80
  %.spill.load177 = load i64, ptr %.spill29, align 4
  %177 = add i64 %.spill.load177, 0
  %.spill.load178 = load <8 x i64>, ptr %.spill30, align 64
  %178 = add <8 x i64> %.spill.load178, zeroinitializer
  %179 = mul i64 %177, 2
  %.splatinsert179 = insertelement <8 x i64> poison, i64 %179, i64 0
  %.splat180 = shufflevector <8 x i64> %.splatinsert179, <8 x i64> poison, <8 x i32> zeroinitializer
  %180 = add <8 x i64> %.splat180, %178
  %.spill.load181 = load i64, ptr %.spill37, align 4
  %181 = add i64 %.spill.load181, %176
  %182 = mul <8 x i64> %180, splat (i64 2053)
  %.splatinsert182 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat183 = shufflevector <8 x i64> %.splatinsert182, <8 x i64> poison, <8 x i32> zeroinitializer
  %183 = add <8 x i64> %182, %.splat183
  %184 = icmp sge i64 %181, 0
  %185 = and i1 true, %184
  %186 = icmp slt i64 %181, 2053
  %187 = and i1 %185, %186
  %188 = add i64 0, %175
  %189 = mul <8 x i64> %183, splat (i64 80)
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %188, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %190 = add <8 x i64> %189, %.splat185
  %191 = load <8 x i64>, ptr %.spill40, align 64
  %192 = select <8 x i1> %71, <8 x i64> %190, <8 x i64> %191
  store <8 x i64> %192, ptr %.spill40, align 64
  br i1 %187, label %direct.true186, label %direct.false187

direct.schedule.11:                               ; preds = %direct.true186
  %.spill.load188 = load <8 x i64>, ptr %.spill40, align 64
  %193 = extractvalue { ptr, i64 } %35, 0
  %194 = mul <8 x i64> %.spill.load188, splat (i64 4)
  %195 = getelementptr i8, ptr %193, <8 x i64> %194
  %196 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %195, <8 x i1> %71, <8 x float> zeroinitializer)
  %197 = load <8 x float>, ptr %.slot41, align 32
  %198 = select <8 x i1> %71, <8 x float> %196, <8 x float> %197
  store <8 x float> %198, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.11, %direct.false187
  %tile_snapshot.spill.load189 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %.state190 = load i64, ptr %.slot39, align 4
  %.splatinsert191 = insertelement <8 x i64> poison, i64 %.state190, i64 0
  %.splat192 = shufflevector <8 x i64> %.splatinsert191, <8 x i64> poison, <8 x i32> zeroinitializer
  %201 = mul <8 x i64> %.splat192, splat (i64 32)
  %202 = add <8 x i64> %200, %201
  %203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %199, 0
  %204 = insertvalue { <8 x ptr>, <8 x i64> } %203, <8 x i64> %202, 1
  %.state193 = load <8 x float>, ptr %.slot41, align 32
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %204, 1
  %207 = extractelement <8 x ptr> %205, i32 0
  %208 = extractelement <8 x i64> %206, i32 0
  %209 = sub i64 %208, 0
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %211 = select i1 %210, i64 %209, i64 0
  %private.contiguous.address194 = getelementptr i8, ptr %207, i64 %211
  %private.contiguous.preserve195 = load <8 x float>, ptr %private.contiguous.address194, align 4
  %212 = select <8 x i1> %71, <8 x float> %.state193, <8 x float> %private.contiguous.preserve195
  store <8 x float> %212, ptr %private.contiguous.address194, align 4
  %.state196 = load i64, ptr %.slot39, align 4
  %213 = add i64 %.state196, 1
  store i64 %213, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false174
  %214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %214, 0
  %217 = select <8 x i1> %71, <8 x ptr> %215, <8 x ptr> %216
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %214, 1
  %220 = select <8 x i1> %71, <8 x i64> %218, <8 x i64> %219
  %221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %222 = insertvalue { <8 x ptr>, <8 x i64> } %221, <8 x i64> %220, 1
  store { <8 x ptr>, <8 x i64> } %222, ptr %tile_snapshot.spill42, align 64
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state197 = load i64, ptr %.slot43, align 4
  %223 = icmp slt i64 %.state197, 1536
  br i1 %223, label %direct.true198, label %direct.false199

direct.schedule.15:                               ; preds = %direct.true198
  %.state200 = load i64, ptr %.slot43, align 4
  %224 = srem i64 %.state200, 96
  %.state201 = load i64, ptr %.slot43, align 4
  %225 = sdiv i64 %.state201, 96
  %.spill.load202 = load i64, ptr %.spill29, align 4
  %226 = add i64 %.spill.load202, 0
  %.spill.load203 = load <8 x i64>, ptr %.spill30, align 64
  %227 = add <8 x i64> %.spill.load203, zeroinitializer
  %228 = mul i64 %226, 2
  %.splatinsert204 = insertelement <8 x i64> poison, i64 %228, i64 0
  %.splat205 = shufflevector <8 x i64> %.splatinsert204, <8 x i64> poison, <8 x i32> zeroinitializer
  %229 = add <8 x i64> %.splat205, %227
  %.spill.load206 = load i64, ptr %.spill37, align 4
  %230 = add i64 %.spill.load206, %225
  %231 = mul <8 x i64> %229, splat (i64 2053)
  %.splatinsert207 = insertelement <8 x i64> poison, i64 %230, i64 0
  %.splat208 = shufflevector <8 x i64> %.splatinsert207, <8 x i64> poison, <8 x i32> zeroinitializer
  %232 = add <8 x i64> %231, %.splat208
  %233 = icmp sge i64 %230, 0
  %234 = and i1 true, %233
  %235 = icmp slt i64 %230, 2053
  %236 = and i1 %234, %235
  %237 = add i64 0, %224
  %238 = mul <8 x i64> %232, splat (i64 96)
  %.splatinsert209 = insertelement <8 x i64> poison, i64 %237, i64 0
  %.splat210 = shufflevector <8 x i64> %.splatinsert209, <8 x i64> poison, <8 x i32> zeroinitializer
  %239 = add <8 x i64> %238, %.splat210
  %240 = load <8 x i64>, ptr %.spill44, align 64
  %241 = select <8 x i1> %71, <8 x i64> %239, <8 x i64> %240
  store <8 x i64> %241, ptr %.spill44, align 64
  br i1 %236, label %direct.true211, label %direct.false212

direct.schedule.16:                               ; preds = %direct.true211
  %.spill.load213 = load <8 x i64>, ptr %.spill44, align 64
  %242 = extractvalue { ptr, i64 } %41, 0
  %243 = mul <8 x i64> %.spill.load213, splat (i64 4)
  %244 = getelementptr i8, ptr %242, <8 x i64> %243
  %245 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %244, <8 x i1> %71, <8 x float> zeroinitializer)
  %246 = load <8 x float>, ptr %.slot45, align 32
  %247 = select <8 x i1> %71, <8 x float> %245, <8 x float> %246
  store <8 x float> %247, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.16, %direct.false212
  %tile_snapshot.spill.load214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 1
  %.state215 = load i64, ptr %.slot43, align 4
  %.splatinsert216 = insertelement <8 x i64> poison, i64 %.state215, i64 0
  %.splat217 = shufflevector <8 x i64> %.splatinsert216, <8 x i64> poison, <8 x i32> zeroinitializer
  %250 = mul <8 x i64> %.splat217, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %.state218 = load <8 x float>, ptr %.slot45, align 32
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address219 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.preserve220 = load <8 x float>, ptr %private.contiguous.address219, align 4
  %261 = select <8 x i1> %71, <8 x float> %.state218, <8 x float> %private.contiguous.preserve220
  store <8 x float> %261, ptr %private.contiguous.address219, align 4
  %.state221 = load i64, ptr %.slot43, align 4
  %262 = add i64 %.state221, 1
  store i64 %262, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false199
  store i64 0, ptr %.slot46, align 4
  %263 = load <8 x float>, ptr %.slot47, align 32
  %264 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %263
  store <8 x float> %264, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state222 = load i64, ptr %.slot46, align 4
  %265 = icmp slt i64 %.state222, 80
  br i1 %265, label %direct.true223, label %direct.false224

direct.schedule.20:                               ; preds = %direct.true223
  %.state225 = load i64, ptr %.slot46, align 4
  %266 = add i64 0, %.state225
  %tile_snapshot.spill.load226 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load226, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load226, 1
  %.splatinsert227 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat228 = shufflevector <8 x i64> %.splatinsert227, <8 x i64> poison, <8 x i32> zeroinitializer
  %269 = mul <8 x i64> %.splat228, splat (i64 32)
  %270 = add <8 x i64> %268, %269
  %271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %267, 0
  %272 = insertvalue { <8 x ptr>, <8 x i64> } %271, <8 x i64> %270, 1
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %272, 1
  %275 = extractelement <8 x ptr> %273, i32 0
  %276 = extractelement <8 x i64> %274, i32 0
  %277 = sub i64 %276, 0
  %278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %279 = select i1 %278, i64 %277, i64 0
  %private.contiguous.address229 = getelementptr i8, ptr %275, i64 %279
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address229, align 4
  %280 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load230 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load230, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load230, 1
  %.splatinsert231 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat232 = shufflevector <8 x i64> %.splatinsert231, <8 x i64> poison, <8 x i32> zeroinitializer
  %283 = mul <8 x i64> %.splat232, splat (i64 32)
  %284 = add <8 x i64> %282, %283
  %285 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %281, 0
  %286 = insertvalue { <8 x ptr>, <8 x i64> } %285, <8 x i64> %284, 1
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %286, 1
  %289 = extractelement <8 x ptr> %287, i32 0
  %290 = extractelement <8 x i64> %288, i32 0
  %291 = sub i64 %290, 0
  %292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %293 = select i1 %292, i64 %291, i64 0
  %private.contiguous.address233 = getelementptr i8, ptr %289, i64 %293
  %private.contiguous.load234 = load <8 x float>, ptr %private.contiguous.address233, align 4
  %294 = select <8 x i1> %71, <8 x float> %private.contiguous.load234, <8 x float> zeroinitializer
  %295 = fmul <8 x float> %280, %294
  %.state235 = load <8 x float>, ptr %.slot47, align 32
  %296 = fadd <8 x float> %.state235, %295
  %.state236 = load i64, ptr %.slot46, align 4
  %297 = add i64 %.state236, 1
  store i64 %297, ptr %.slot46, align 4
  %298 = load <8 x float>, ptr %.slot47, align 32
  %299 = select <8 x i1> %71, <8 x float> %296, <8 x float> %298
  store <8 x float> %299, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false224
  store i64 0, ptr %.slot48, align 4
  %300 = load <8 x float>, ptr %.slot49, align 32
  %301 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %300
  store <8 x float> %301, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state237 = load i64, ptr %.slot48, align 4
  %302 = icmp slt i64 %.state237, 80
  br i1 %302, label %direct.true238, label %direct.false239

direct.schedule.23:                               ; preds = %direct.true238
  %.state240 = load i64, ptr %.slot48, align 4
  %303 = add i64 0, %.state240
  %tile_snapshot.spill.load241 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 1
  %.splatinsert242 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat243 = shufflevector <8 x i64> %.splatinsert242, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat243, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address244 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load245 = load <8 x float>, ptr %private.contiguous.address244, align 4
  %317 = select <8 x i1> %71, <8 x float> %private.contiguous.load245, <8 x float> zeroinitializer
  %.state246 = load i64, ptr %.slot48, align 4
  %318 = add i64 80, %.state246
  %tile_snapshot.spill.load247 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 0
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 1
  %.splatinsert248 = insertelement <8 x i64> poison, i64 %318, i64 0
  %.splat249 = shufflevector <8 x i64> %.splatinsert248, <8 x i64> poison, <8 x i32> zeroinitializer
  %321 = mul <8 x i64> %.splat249, splat (i64 32)
  %322 = add <8 x i64> %320, %321
  %323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %319, 0
  %324 = insertvalue { <8 x ptr>, <8 x i64> } %323, <8 x i64> %322, 1
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %324, 1
  %327 = extractelement <8 x ptr> %325, i32 0
  %328 = extractelement <8 x i64> %326, i32 0
  %329 = sub i64 %328, 0
  %330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %331 = select i1 %330, i64 %329, i64 0
  %private.contiguous.address250 = getelementptr i8, ptr %327, i64 %331
  %private.contiguous.load251 = load <8 x float>, ptr %private.contiguous.address250, align 4
  %332 = select <8 x i1> %71, <8 x float> %private.contiguous.load251, <8 x float> zeroinitializer
  %333 = fmul <8 x float> %317, %332
  %.state252 = load <8 x float>, ptr %.slot49, align 32
  %334 = fadd <8 x float> %.state252, %333
  %.state253 = load i64, ptr %.slot48, align 4
  %335 = add i64 %.state253, 1
  store i64 %335, ptr %.slot48, align 4
  %336 = load <8 x float>, ptr %.slot49, align 32
  %337 = select <8 x i1> %71, <8 x float> %334, <8 x float> %336
  store <8 x float> %337, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false239
  store i64 0, ptr %.slot50, align 4
  %338 = load <8 x float>, ptr %.slot51, align 32
  %339 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %338
  store <8 x float> %339, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state254 = load i64, ptr %.slot50, align 4
  %340 = icmp slt i64 %.state254, 80
  br i1 %340, label %direct.true255, label %direct.false256

direct.schedule.26:                               ; preds = %direct.true255
  %.state257 = load i64, ptr %.slot50, align 4
  %341 = add i64 0, %.state257
  %tile_snapshot.spill.load258 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load258, 0
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load258, 1
  %.splatinsert259 = insertelement <8 x i64> poison, i64 %341, i64 0
  %.splat260 = shufflevector <8 x i64> %.splatinsert259, <8 x i64> poison, <8 x i32> zeroinitializer
  %344 = mul <8 x i64> %.splat260, splat (i64 32)
  %345 = add <8 x i64> %343, %344
  %346 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %342, 0
  %347 = insertvalue { <8 x ptr>, <8 x i64> } %346, <8 x i64> %345, 1
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %347, 1
  %350 = extractelement <8 x ptr> %348, i32 0
  %351 = extractelement <8 x i64> %349, i32 0
  %352 = sub i64 %351, 0
  %353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %354 = select i1 %353, i64 %352, i64 0
  %private.contiguous.address261 = getelementptr i8, ptr %350, i64 %354
  %private.contiguous.load262 = load <8 x float>, ptr %private.contiguous.address261, align 4
  %355 = select <8 x i1> %71, <8 x float> %private.contiguous.load262, <8 x float> zeroinitializer
  %.state263 = load i64, ptr %.slot50, align 4
  %356 = add i64 160, %.state263
  %tile_snapshot.spill.load264 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 0
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 1
  %.splatinsert265 = insertelement <8 x i64> poison, i64 %356, i64 0
  %.splat266 = shufflevector <8 x i64> %.splatinsert265, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = mul <8 x i64> %.splat266, splat (i64 32)
  %360 = add <8 x i64> %358, %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = extractelement <8 x ptr> %363, i32 0
  %366 = extractelement <8 x i64> %364, i32 0
  %367 = sub i64 %366, 0
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %369 = select i1 %368, i64 %367, i64 0
  %private.contiguous.address267 = getelementptr i8, ptr %365, i64 %369
  %private.contiguous.load268 = load <8 x float>, ptr %private.contiguous.address267, align 4
  %370 = select <8 x i1> %71, <8 x float> %private.contiguous.load268, <8 x float> zeroinitializer
  %371 = fmul <8 x float> %355, %370
  %.state269 = load <8 x float>, ptr %.slot51, align 32
  %372 = fadd <8 x float> %.state269, %371
  %.state270 = load i64, ptr %.slot50, align 4
  %373 = add i64 %.state270, 1
  store i64 %373, ptr %.slot50, align 4
  %374 = load <8 x float>, ptr %.slot51, align 32
  %375 = select <8 x i1> %71, <8 x float> %372, <8 x float> %374
  store <8 x float> %375, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false256
  store i64 0, ptr %.slot52, align 4
  %376 = load <8 x float>, ptr %.slot53, align 32
  %377 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %376
  store <8 x float> %377, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state271 = load i64, ptr %.slot52, align 4
  %378 = icmp slt i64 %.state271, 80
  br i1 %378, label %direct.true272, label %direct.false273

direct.schedule.29:                               ; preds = %direct.true272
  %.state274 = load i64, ptr %.slot52, align 4
  %379 = add i64 0, %.state274
  %tile_snapshot.spill.load275 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load275, 0
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load275, 1
  %.splatinsert276 = insertelement <8 x i64> poison, i64 %379, i64 0
  %.splat277 = shufflevector <8 x i64> %.splatinsert276, <8 x i64> poison, <8 x i32> zeroinitializer
  %382 = mul <8 x i64> %.splat277, splat (i64 32)
  %383 = add <8 x i64> %381, %382
  %384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %380, 0
  %385 = insertvalue { <8 x ptr>, <8 x i64> } %384, <8 x i64> %383, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %385, 1
  %388 = extractelement <8 x ptr> %386, i32 0
  %389 = extractelement <8 x i64> %387, i32 0
  %390 = sub i64 %389, 0
  %391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %392 = select i1 %391, i64 %390, i64 0
  %private.contiguous.address278 = getelementptr i8, ptr %388, i64 %392
  %private.contiguous.load279 = load <8 x float>, ptr %private.contiguous.address278, align 4
  %393 = select <8 x i1> %71, <8 x float> %private.contiguous.load279, <8 x float> zeroinitializer
  %.state280 = load i64, ptr %.slot52, align 4
  %394 = add i64 240, %.state280
  %tile_snapshot.spill.load281 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %.splatinsert282 = insertelement <8 x i64> poison, i64 %394, i64 0
  %.splat283 = shufflevector <8 x i64> %.splatinsert282, <8 x i64> poison, <8 x i32> zeroinitializer
  %397 = mul <8 x i64> %.splat283, splat (i64 32)
  %398 = add <8 x i64> %396, %397
  %399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %395, 0
  %400 = insertvalue { <8 x ptr>, <8 x i64> } %399, <8 x i64> %398, 1
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %400, 1
  %403 = extractelement <8 x ptr> %401, i32 0
  %404 = extractelement <8 x i64> %402, i32 0
  %405 = sub i64 %404, 0
  %406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %407 = select i1 %406, i64 %405, i64 0
  %private.contiguous.address284 = getelementptr i8, ptr %403, i64 %407
  %private.contiguous.load285 = load <8 x float>, ptr %private.contiguous.address284, align 4
  %408 = select <8 x i1> %71, <8 x float> %private.contiguous.load285, <8 x float> zeroinitializer
  %409 = fmul <8 x float> %393, %408
  %.state286 = load <8 x float>, ptr %.slot53, align 32
  %410 = fadd <8 x float> %.state286, %409
  %.state287 = load i64, ptr %.slot52, align 4
  %411 = add i64 %.state287, 1
  store i64 %411, ptr %.slot52, align 4
  %412 = load <8 x float>, ptr %.slot53, align 32
  %413 = select <8 x i1> %71, <8 x float> %410, <8 x float> %412
  store <8 x float> %413, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false273
  store i64 0, ptr %.slot54, align 4
  %414 = load <8 x float>, ptr %.slot55, align 32
  %415 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %414
  store <8 x float> %415, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state288 = load i64, ptr %.slot54, align 4
  %416 = icmp slt i64 %.state288, 80
  br i1 %416, label %direct.true289, label %direct.false290

direct.schedule.32:                               ; preds = %direct.true289
  %.state291 = load i64, ptr %.slot54, align 4
  %417 = add i64 0, %.state291
  %tile_snapshot.spill.load292 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load292, 0
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load292, 1
  %.splatinsert293 = insertelement <8 x i64> poison, i64 %417, i64 0
  %.splat294 = shufflevector <8 x i64> %.splatinsert293, <8 x i64> poison, <8 x i32> zeroinitializer
  %420 = mul <8 x i64> %.splat294, splat (i64 32)
  %421 = add <8 x i64> %419, %420
  %422 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %418, 0
  %423 = insertvalue { <8 x ptr>, <8 x i64> } %422, <8 x i64> %421, 1
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %423, 1
  %426 = extractelement <8 x ptr> %424, i32 0
  %427 = extractelement <8 x i64> %425, i32 0
  %428 = sub i64 %427, 0
  %429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %430 = select i1 %429, i64 %428, i64 0
  %private.contiguous.address295 = getelementptr i8, ptr %426, i64 %430
  %private.contiguous.load296 = load <8 x float>, ptr %private.contiguous.address295, align 4
  %431 = select <8 x i1> %71, <8 x float> %private.contiguous.load296, <8 x float> zeroinitializer
  %.state297 = load i64, ptr %.slot54, align 4
  %432 = add i64 320, %.state297
  %tile_snapshot.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 0
  %434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 1
  %.splatinsert299 = insertelement <8 x i64> poison, i64 %432, i64 0
  %.splat300 = shufflevector <8 x i64> %.splatinsert299, <8 x i64> poison, <8 x i32> zeroinitializer
  %435 = mul <8 x i64> %.splat300, splat (i64 32)
  %436 = add <8 x i64> %434, %435
  %437 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %433, 0
  %438 = insertvalue { <8 x ptr>, <8 x i64> } %437, <8 x i64> %436, 1
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %438, 1
  %441 = extractelement <8 x ptr> %439, i32 0
  %442 = extractelement <8 x i64> %440, i32 0
  %443 = sub i64 %442, 0
  %444 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %445 = select i1 %444, i64 %443, i64 0
  %private.contiguous.address301 = getelementptr i8, ptr %441, i64 %445
  %private.contiguous.load302 = load <8 x float>, ptr %private.contiguous.address301, align 4
  %446 = select <8 x i1> %71, <8 x float> %private.contiguous.load302, <8 x float> zeroinitializer
  %447 = fmul <8 x float> %431, %446
  %.state303 = load <8 x float>, ptr %.slot55, align 32
  %448 = fadd <8 x float> %.state303, %447
  %.state304 = load i64, ptr %.slot54, align 4
  %449 = add i64 %.state304, 1
  store i64 %449, ptr %.slot54, align 4
  %450 = load <8 x float>, ptr %.slot55, align 32
  %451 = select <8 x i1> %71, <8 x float> %448, <8 x float> %450
  store <8 x float> %451, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false290
  store i64 0, ptr %.slot56, align 4
  %452 = load <8 x float>, ptr %.slot57, align 32
  %453 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %452
  store <8 x float> %453, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state305 = load i64, ptr %.slot56, align 4
  %454 = icmp slt i64 %.state305, 80
  br i1 %454, label %direct.true306, label %direct.false307

direct.schedule.35:                               ; preds = %direct.true306
  %.state308 = load i64, ptr %.slot56, align 4
  %455 = add i64 0, %.state308
  %tile_snapshot.spill.load309 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %456 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load309, 0
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load309, 1
  %.splatinsert310 = insertelement <8 x i64> poison, i64 %455, i64 0
  %.splat311 = shufflevector <8 x i64> %.splatinsert310, <8 x i64> poison, <8 x i32> zeroinitializer
  %458 = mul <8 x i64> %.splat311, splat (i64 32)
  %459 = add <8 x i64> %457, %458
  %460 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %456, 0
  %461 = insertvalue { <8 x ptr>, <8 x i64> } %460, <8 x i64> %459, 1
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %461, 1
  %464 = extractelement <8 x ptr> %462, i32 0
  %465 = extractelement <8 x i64> %463, i32 0
  %466 = sub i64 %465, 0
  %467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %468 = select i1 %467, i64 %466, i64 0
  %private.contiguous.address312 = getelementptr i8, ptr %464, i64 %468
  %private.contiguous.load313 = load <8 x float>, ptr %private.contiguous.address312, align 4
  %469 = select <8 x i1> %71, <8 x float> %private.contiguous.load313, <8 x float> zeroinitializer
  %.state314 = load i64, ptr %.slot56, align 4
  %470 = add i64 400, %.state314
  %tile_snapshot.spill.load315 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 0
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 1
  %.splatinsert316 = insertelement <8 x i64> poison, i64 %470, i64 0
  %.splat317 = shufflevector <8 x i64> %.splatinsert316, <8 x i64> poison, <8 x i32> zeroinitializer
  %473 = mul <8 x i64> %.splat317, splat (i64 32)
  %474 = add <8 x i64> %472, %473
  %475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %471, 0
  %476 = insertvalue { <8 x ptr>, <8 x i64> } %475, <8 x i64> %474, 1
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %476, 1
  %479 = extractelement <8 x ptr> %477, i32 0
  %480 = extractelement <8 x i64> %478, i32 0
  %481 = sub i64 %480, 0
  %482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %483 = select i1 %482, i64 %481, i64 0
  %private.contiguous.address318 = getelementptr i8, ptr %479, i64 %483
  %private.contiguous.load319 = load <8 x float>, ptr %private.contiguous.address318, align 4
  %484 = select <8 x i1> %71, <8 x float> %private.contiguous.load319, <8 x float> zeroinitializer
  %485 = fmul <8 x float> %469, %484
  %.state320 = load <8 x float>, ptr %.slot57, align 32
  %486 = fadd <8 x float> %.state320, %485
  %.state321 = load i64, ptr %.slot56, align 4
  %487 = add i64 %.state321, 1
  store i64 %487, ptr %.slot56, align 4
  %488 = load <8 x float>, ptr %.slot57, align 32
  %489 = select <8 x i1> %71, <8 x float> %486, <8 x float> %488
  store <8 x float> %489, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false307
  store i64 0, ptr %.slot58, align 4
  %490 = load <8 x float>, ptr %.slot59, align 32
  %491 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %490
  store <8 x float> %491, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state322 = load i64, ptr %.slot58, align 4
  %492 = icmp slt i64 %.state322, 80
  br i1 %492, label %direct.true323, label %direct.false324

direct.schedule.38:                               ; preds = %direct.true323
  %.state325 = load i64, ptr %.slot58, align 4
  %493 = add i64 0, %.state325
  %tile_snapshot.spill.load326 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load326, 0
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load326, 1
  %.splatinsert327 = insertelement <8 x i64> poison, i64 %493, i64 0
  %.splat328 = shufflevector <8 x i64> %.splatinsert327, <8 x i64> poison, <8 x i32> zeroinitializer
  %496 = mul <8 x i64> %.splat328, splat (i64 32)
  %497 = add <8 x i64> %495, %496
  %498 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %494, 0
  %499 = insertvalue { <8 x ptr>, <8 x i64> } %498, <8 x i64> %497, 1
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %499, 1
  %502 = extractelement <8 x ptr> %500, i32 0
  %503 = extractelement <8 x i64> %501, i32 0
  %504 = sub i64 %503, 0
  %505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %506 = select i1 %505, i64 %504, i64 0
  %private.contiguous.address329 = getelementptr i8, ptr %502, i64 %506
  %private.contiguous.load330 = load <8 x float>, ptr %private.contiguous.address329, align 4
  %507 = select <8 x i1> %71, <8 x float> %private.contiguous.load330, <8 x float> zeroinitializer
  %.state331 = load i64, ptr %.slot58, align 4
  %508 = add i64 480, %.state331
  %tile_snapshot.spill.load332 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load332, 0
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load332, 1
  %.splatinsert333 = insertelement <8 x i64> poison, i64 %508, i64 0
  %.splat334 = shufflevector <8 x i64> %.splatinsert333, <8 x i64> poison, <8 x i32> zeroinitializer
  %511 = mul <8 x i64> %.splat334, splat (i64 32)
  %512 = add <8 x i64> %510, %511
  %513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %509, 0
  %514 = insertvalue { <8 x ptr>, <8 x i64> } %513, <8 x i64> %512, 1
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %514, 1
  %517 = extractelement <8 x ptr> %515, i32 0
  %518 = extractelement <8 x i64> %516, i32 0
  %519 = sub i64 %518, 0
  %520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %521 = select i1 %520, i64 %519, i64 0
  %private.contiguous.address335 = getelementptr i8, ptr %517, i64 %521
  %private.contiguous.load336 = load <8 x float>, ptr %private.contiguous.address335, align 4
  %522 = select <8 x i1> %71, <8 x float> %private.contiguous.load336, <8 x float> zeroinitializer
  %523 = fmul <8 x float> %507, %522
  %.state337 = load <8 x float>, ptr %.slot59, align 32
  %524 = fadd <8 x float> %.state337, %523
  %.state338 = load i64, ptr %.slot58, align 4
  %525 = add i64 %.state338, 1
  store i64 %525, ptr %.slot58, align 4
  %526 = load <8 x float>, ptr %.slot59, align 32
  %527 = select <8 x i1> %71, <8 x float> %524, <8 x float> %526
  store <8 x float> %527, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false324
  store i64 0, ptr %.slot60, align 4
  %528 = load <8 x float>, ptr %.slot61, align 32
  %529 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %528
  store <8 x float> %529, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state339 = load i64, ptr %.slot60, align 4
  %530 = icmp slt i64 %.state339, 80
  br i1 %530, label %direct.true340, label %direct.false341

direct.schedule.41:                               ; preds = %direct.true340
  %.state342 = load i64, ptr %.slot60, align 4
  %531 = add i64 0, %.state342
  %tile_snapshot.spill.load343 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load343, 0
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load343, 1
  %.splatinsert344 = insertelement <8 x i64> poison, i64 %531, i64 0
  %.splat345 = shufflevector <8 x i64> %.splatinsert344, <8 x i64> poison, <8 x i32> zeroinitializer
  %534 = mul <8 x i64> %.splat345, splat (i64 32)
  %535 = add <8 x i64> %533, %534
  %536 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %532, 0
  %537 = insertvalue { <8 x ptr>, <8 x i64> } %536, <8 x i64> %535, 1
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %539 = extractvalue { <8 x ptr>, <8 x i64> } %537, 1
  %540 = extractelement <8 x ptr> %538, i32 0
  %541 = extractelement <8 x i64> %539, i32 0
  %542 = sub i64 %541, 0
  %543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %544 = select i1 %543, i64 %542, i64 0
  %private.contiguous.address346 = getelementptr i8, ptr %540, i64 %544
  %private.contiguous.load347 = load <8 x float>, ptr %private.contiguous.address346, align 4
  %545 = select <8 x i1> %71, <8 x float> %private.contiguous.load347, <8 x float> zeroinitializer
  %.state348 = load i64, ptr %.slot60, align 4
  %546 = add i64 560, %.state348
  %tile_snapshot.spill.load349 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load349, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load349, 1
  %.splatinsert350 = insertelement <8 x i64> poison, i64 %546, i64 0
  %.splat351 = shufflevector <8 x i64> %.splatinsert350, <8 x i64> poison, <8 x i32> zeroinitializer
  %549 = mul <8 x i64> %.splat351, splat (i64 32)
  %550 = add <8 x i64> %548, %549
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %547, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = extractelement <8 x ptr> %553, i32 0
  %556 = extractelement <8 x i64> %554, i32 0
  %557 = sub i64 %556, 0
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %559 = select i1 %558, i64 %557, i64 0
  %private.contiguous.address352 = getelementptr i8, ptr %555, i64 %559
  %private.contiguous.load353 = load <8 x float>, ptr %private.contiguous.address352, align 4
  %560 = select <8 x i1> %71, <8 x float> %private.contiguous.load353, <8 x float> zeroinitializer
  %561 = fmul <8 x float> %545, %560
  %.state354 = load <8 x float>, ptr %.slot61, align 32
  %562 = fadd <8 x float> %.state354, %561
  %.state355 = load i64, ptr %.slot60, align 4
  %563 = add i64 %.state355, 1
  store i64 %563, ptr %.slot60, align 4
  %564 = load <8 x float>, ptr %.slot61, align 32
  %565 = select <8 x i1> %71, <8 x float> %562, <8 x float> %564
  store <8 x float> %565, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false341
  store i64 0, ptr %.slot62, align 4
  %566 = load <8 x float>, ptr %.slot63, align 32
  %567 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %566
  store <8 x float> %567, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state356 = load i64, ptr %.slot62, align 4
  %568 = icmp slt i64 %.state356, 80
  br i1 %568, label %direct.true357, label %direct.false358

direct.schedule.44:                               ; preds = %direct.true357
  %.state359 = load i64, ptr %.slot62, align 4
  %569 = add i64 0, %.state359
  %tile_snapshot.spill.load360 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load360, 0
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load360, 1
  %.splatinsert361 = insertelement <8 x i64> poison, i64 %569, i64 0
  %.splat362 = shufflevector <8 x i64> %.splatinsert361, <8 x i64> poison, <8 x i32> zeroinitializer
  %572 = mul <8 x i64> %.splat362, splat (i64 32)
  %573 = add <8 x i64> %571, %572
  %574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %570, 0
  %575 = insertvalue { <8 x ptr>, <8 x i64> } %574, <8 x i64> %573, 1
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %575, 1
  %578 = extractelement <8 x ptr> %576, i32 0
  %579 = extractelement <8 x i64> %577, i32 0
  %580 = sub i64 %579, 0
  %581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %582 = select i1 %581, i64 %580, i64 0
  %private.contiguous.address363 = getelementptr i8, ptr %578, i64 %582
  %private.contiguous.load364 = load <8 x float>, ptr %private.contiguous.address363, align 4
  %583 = select <8 x i1> %71, <8 x float> %private.contiguous.load364, <8 x float> zeroinitializer
  %.state365 = load i64, ptr %.slot62, align 4
  %584 = add i64 640, %.state365
  %tile_snapshot.spill.load366 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load366, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load366, 1
  %.splatinsert367 = insertelement <8 x i64> poison, i64 %584, i64 0
  %.splat368 = shufflevector <8 x i64> %.splatinsert367, <8 x i64> poison, <8 x i32> zeroinitializer
  %587 = mul <8 x i64> %.splat368, splat (i64 32)
  %588 = add <8 x i64> %586, %587
  %589 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %585, 0
  %590 = insertvalue { <8 x ptr>, <8 x i64> } %589, <8 x i64> %588, 1
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %592 = extractvalue { <8 x ptr>, <8 x i64> } %590, 1
  %593 = extractelement <8 x ptr> %591, i32 0
  %594 = extractelement <8 x i64> %592, i32 0
  %595 = sub i64 %594, 0
  %596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %597 = select i1 %596, i64 %595, i64 0
  %private.contiguous.address369 = getelementptr i8, ptr %593, i64 %597
  %private.contiguous.load370 = load <8 x float>, ptr %private.contiguous.address369, align 4
  %598 = select <8 x i1> %71, <8 x float> %private.contiguous.load370, <8 x float> zeroinitializer
  %599 = fmul <8 x float> %583, %598
  %.state371 = load <8 x float>, ptr %.slot63, align 32
  %600 = fadd <8 x float> %.state371, %599
  %.state372 = load i64, ptr %.slot62, align 4
  %601 = add i64 %.state372, 1
  store i64 %601, ptr %.slot62, align 4
  %602 = load <8 x float>, ptr %.slot63, align 32
  %603 = select <8 x i1> %71, <8 x float> %600, <8 x float> %602
  store <8 x float> %603, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false358
  store i64 0, ptr %.slot64, align 4
  %604 = load <8 x float>, ptr %.slot65, align 32
  %605 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %604
  store <8 x float> %605, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state373 = load i64, ptr %.slot64, align 4
  %606 = icmp slt i64 %.state373, 80
  br i1 %606, label %direct.true374, label %direct.false375

direct.schedule.47:                               ; preds = %direct.true374
  %.state376 = load i64, ptr %.slot64, align 4
  %607 = add i64 0, %.state376
  %tile_snapshot.spill.load377 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load377, 0
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load377, 1
  %.splatinsert378 = insertelement <8 x i64> poison, i64 %607, i64 0
  %.splat379 = shufflevector <8 x i64> %.splatinsert378, <8 x i64> poison, <8 x i32> zeroinitializer
  %610 = mul <8 x i64> %.splat379, splat (i64 32)
  %611 = add <8 x i64> %609, %610
  %612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %608, 0
  %613 = insertvalue { <8 x ptr>, <8 x i64> } %612, <8 x i64> %611, 1
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %613, 1
  %616 = extractelement <8 x ptr> %614, i32 0
  %617 = extractelement <8 x i64> %615, i32 0
  %618 = sub i64 %617, 0
  %619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %620 = select i1 %619, i64 %618, i64 0
  %private.contiguous.address380 = getelementptr i8, ptr %616, i64 %620
  %private.contiguous.load381 = load <8 x float>, ptr %private.contiguous.address380, align 4
  %621 = select <8 x i1> %71, <8 x float> %private.contiguous.load381, <8 x float> zeroinitializer
  %.state382 = load i64, ptr %.slot64, align 4
  %622 = add i64 720, %.state382
  %tile_snapshot.spill.load383 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %623 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load383, 0
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load383, 1
  %.splatinsert384 = insertelement <8 x i64> poison, i64 %622, i64 0
  %.splat385 = shufflevector <8 x i64> %.splatinsert384, <8 x i64> poison, <8 x i32> zeroinitializer
  %625 = mul <8 x i64> %.splat385, splat (i64 32)
  %626 = add <8 x i64> %624, %625
  %627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %623, 0
  %628 = insertvalue { <8 x ptr>, <8 x i64> } %627, <8 x i64> %626, 1
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %628, 1
  %631 = extractelement <8 x ptr> %629, i32 0
  %632 = extractelement <8 x i64> %630, i32 0
  %633 = sub i64 %632, 0
  %634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %635 = select i1 %634, i64 %633, i64 0
  %private.contiguous.address386 = getelementptr i8, ptr %631, i64 %635
  %private.contiguous.load387 = load <8 x float>, ptr %private.contiguous.address386, align 4
  %636 = select <8 x i1> %71, <8 x float> %private.contiguous.load387, <8 x float> zeroinitializer
  %637 = fmul <8 x float> %621, %636
  %.state388 = load <8 x float>, ptr %.slot65, align 32
  %638 = fadd <8 x float> %.state388, %637
  %.state389 = load i64, ptr %.slot64, align 4
  %639 = add i64 %.state389, 1
  store i64 %639, ptr %.slot64, align 4
  %640 = load <8 x float>, ptr %.slot65, align 32
  %641 = select <8 x i1> %71, <8 x float> %638, <8 x float> %640
  store <8 x float> %641, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false375
  store i64 0, ptr %.slot66, align 4
  %642 = load <8 x float>, ptr %.slot67, align 32
  %643 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %642
  store <8 x float> %643, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state390 = load i64, ptr %.slot66, align 4
  %644 = icmp slt i64 %.state390, 80
  br i1 %644, label %direct.true391, label %direct.false392

direct.schedule.50:                               ; preds = %direct.true391
  %.state393 = load i64, ptr %.slot66, align 4
  %645 = add i64 0, %.state393
  %tile_snapshot.spill.load394 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load394, 0
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load394, 1
  %.splatinsert395 = insertelement <8 x i64> poison, i64 %645, i64 0
  %.splat396 = shufflevector <8 x i64> %.splatinsert395, <8 x i64> poison, <8 x i32> zeroinitializer
  %648 = mul <8 x i64> %.splat396, splat (i64 32)
  %649 = add <8 x i64> %647, %648
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %646, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = extractelement <8 x ptr> %652, i32 0
  %655 = extractelement <8 x i64> %653, i32 0
  %656 = sub i64 %655, 0
  %657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %658 = select i1 %657, i64 %656, i64 0
  %private.contiguous.address397 = getelementptr i8, ptr %654, i64 %658
  %private.contiguous.load398 = load <8 x float>, ptr %private.contiguous.address397, align 4
  %659 = select <8 x i1> %71, <8 x float> %private.contiguous.load398, <8 x float> zeroinitializer
  %.state399 = load i64, ptr %.slot66, align 4
  %660 = add i64 800, %.state399
  %tile_snapshot.spill.load400 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load400, 0
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load400, 1
  %.splatinsert401 = insertelement <8 x i64> poison, i64 %660, i64 0
  %.splat402 = shufflevector <8 x i64> %.splatinsert401, <8 x i64> poison, <8 x i32> zeroinitializer
  %663 = mul <8 x i64> %.splat402, splat (i64 32)
  %664 = add <8 x i64> %662, %663
  %665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %661, 0
  %666 = insertvalue { <8 x ptr>, <8 x i64> } %665, <8 x i64> %664, 1
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %666, 1
  %669 = extractelement <8 x ptr> %667, i32 0
  %670 = extractelement <8 x i64> %668, i32 0
  %671 = sub i64 %670, 0
  %672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %673 = select i1 %672, i64 %671, i64 0
  %private.contiguous.address403 = getelementptr i8, ptr %669, i64 %673
  %private.contiguous.load404 = load <8 x float>, ptr %private.contiguous.address403, align 4
  %674 = select <8 x i1> %71, <8 x float> %private.contiguous.load404, <8 x float> zeroinitializer
  %675 = fmul <8 x float> %659, %674
  %.state405 = load <8 x float>, ptr %.slot67, align 32
  %676 = fadd <8 x float> %.state405, %675
  %.state406 = load i64, ptr %.slot66, align 4
  %677 = add i64 %.state406, 1
  store i64 %677, ptr %.slot66, align 4
  %678 = load <8 x float>, ptr %.slot67, align 32
  %679 = select <8 x i1> %71, <8 x float> %676, <8 x float> %678
  store <8 x float> %679, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false392
  store i64 0, ptr %.slot68, align 4
  %680 = load <8 x float>, ptr %.slot69, align 32
  %681 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %680
  store <8 x float> %681, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state407 = load i64, ptr %.slot68, align 4
  %682 = icmp slt i64 %.state407, 80
  br i1 %682, label %direct.true408, label %direct.false409

direct.schedule.53:                               ; preds = %direct.true408
  %.state410 = load i64, ptr %.slot68, align 4
  %683 = add i64 0, %.state410
  %tile_snapshot.spill.load411 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %.splatinsert412 = insertelement <8 x i64> poison, i64 %683, i64 0
  %.splat413 = shufflevector <8 x i64> %.splatinsert412, <8 x i64> poison, <8 x i32> zeroinitializer
  %686 = mul <8 x i64> %.splat413, splat (i64 32)
  %687 = add <8 x i64> %685, %686
  %688 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %684, 0
  %689 = insertvalue { <8 x ptr>, <8 x i64> } %688, <8 x i64> %687, 1
  %690 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %689, 1
  %692 = extractelement <8 x ptr> %690, i32 0
  %693 = extractelement <8 x i64> %691, i32 0
  %694 = sub i64 %693, 0
  %695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %696 = select i1 %695, i64 %694, i64 0
  %private.contiguous.address414 = getelementptr i8, ptr %692, i64 %696
  %private.contiguous.load415 = load <8 x float>, ptr %private.contiguous.address414, align 4
  %697 = select <8 x i1> %71, <8 x float> %private.contiguous.load415, <8 x float> zeroinitializer
  %.state416 = load i64, ptr %.slot68, align 4
  %698 = add i64 880, %.state416
  %tile_snapshot.spill.load417 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 0
  %700 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 1
  %.splatinsert418 = insertelement <8 x i64> poison, i64 %698, i64 0
  %.splat419 = shufflevector <8 x i64> %.splatinsert418, <8 x i64> poison, <8 x i32> zeroinitializer
  %701 = mul <8 x i64> %.splat419, splat (i64 32)
  %702 = add <8 x i64> %700, %701
  %703 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %699, 0
  %704 = insertvalue { <8 x ptr>, <8 x i64> } %703, <8 x i64> %702, 1
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %706 = extractvalue { <8 x ptr>, <8 x i64> } %704, 1
  %707 = extractelement <8 x ptr> %705, i32 0
  %708 = extractelement <8 x i64> %706, i32 0
  %709 = sub i64 %708, 0
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %711 = select i1 %710, i64 %709, i64 0
  %private.contiguous.address420 = getelementptr i8, ptr %707, i64 %711
  %private.contiguous.load421 = load <8 x float>, ptr %private.contiguous.address420, align 4
  %712 = select <8 x i1> %71, <8 x float> %private.contiguous.load421, <8 x float> zeroinitializer
  %713 = fmul <8 x float> %697, %712
  %.state422 = load <8 x float>, ptr %.slot69, align 32
  %714 = fadd <8 x float> %.state422, %713
  %.state423 = load i64, ptr %.slot68, align 4
  %715 = add i64 %.state423, 1
  store i64 %715, ptr %.slot68, align 4
  %716 = load <8 x float>, ptr %.slot69, align 32
  %717 = select <8 x i1> %71, <8 x float> %714, <8 x float> %716
  store <8 x float> %717, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false409
  store i64 0, ptr %.slot70, align 4
  %718 = load <8 x float>, ptr %.slot71, align 32
  %719 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %718
  store <8 x float> %719, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state424 = load i64, ptr %.slot70, align 4
  %720 = icmp slt i64 %.state424, 80
  br i1 %720, label %direct.true425, label %direct.false426

direct.schedule.56:                               ; preds = %direct.true425
  %.state427 = load i64, ptr %.slot70, align 4
  %721 = add i64 0, %.state427
  %tile_snapshot.spill.load428 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load428, 0
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load428, 1
  %.splatinsert429 = insertelement <8 x i64> poison, i64 %721, i64 0
  %.splat430 = shufflevector <8 x i64> %.splatinsert429, <8 x i64> poison, <8 x i32> zeroinitializer
  %724 = mul <8 x i64> %.splat430, splat (i64 32)
  %725 = add <8 x i64> %723, %724
  %726 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %722, 0
  %727 = insertvalue { <8 x ptr>, <8 x i64> } %726, <8 x i64> %725, 1
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %727, 1
  %730 = extractelement <8 x ptr> %728, i32 0
  %731 = extractelement <8 x i64> %729, i32 0
  %732 = sub i64 %731, 0
  %733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %734 = select i1 %733, i64 %732, i64 0
  %private.contiguous.address431 = getelementptr i8, ptr %730, i64 %734
  %private.contiguous.load432 = load <8 x float>, ptr %private.contiguous.address431, align 4
  %735 = select <8 x i1> %71, <8 x float> %private.contiguous.load432, <8 x float> zeroinitializer
  %.state433 = load i64, ptr %.slot70, align 4
  %736 = add i64 960, %.state433
  %tile_snapshot.spill.load434 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load434, 0
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load434, 1
  %.splatinsert435 = insertelement <8 x i64> poison, i64 %736, i64 0
  %.splat436 = shufflevector <8 x i64> %.splatinsert435, <8 x i64> poison, <8 x i32> zeroinitializer
  %739 = mul <8 x i64> %.splat436, splat (i64 32)
  %740 = add <8 x i64> %738, %739
  %741 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %737, 0
  %742 = insertvalue { <8 x ptr>, <8 x i64> } %741, <8 x i64> %740, 1
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %742, 1
  %745 = extractelement <8 x ptr> %743, i32 0
  %746 = extractelement <8 x i64> %744, i32 0
  %747 = sub i64 %746, 0
  %748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %749 = select i1 %748, i64 %747, i64 0
  %private.contiguous.address437 = getelementptr i8, ptr %745, i64 %749
  %private.contiguous.load438 = load <8 x float>, ptr %private.contiguous.address437, align 4
  %750 = select <8 x i1> %71, <8 x float> %private.contiguous.load438, <8 x float> zeroinitializer
  %751 = fmul <8 x float> %735, %750
  %.state439 = load <8 x float>, ptr %.slot71, align 32
  %752 = fadd <8 x float> %.state439, %751
  %.state440 = load i64, ptr %.slot70, align 4
  %753 = add i64 %.state440, 1
  store i64 %753, ptr %.slot70, align 4
  %754 = load <8 x float>, ptr %.slot71, align 32
  %755 = select <8 x i1> %71, <8 x float> %752, <8 x float> %754
  store <8 x float> %755, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false426
  store i64 0, ptr %.slot72, align 4
  %756 = load <8 x float>, ptr %.slot73, align 32
  %757 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %756
  store <8 x float> %757, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state441 = load i64, ptr %.slot72, align 4
  %758 = icmp slt i64 %.state441, 80
  br i1 %758, label %direct.true442, label %direct.false443

direct.schedule.59:                               ; preds = %direct.true442
  %.state444 = load i64, ptr %.slot72, align 4
  %759 = add i64 0, %.state444
  %tile_snapshot.spill.load445 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load445, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load445, 1
  %.splatinsert446 = insertelement <8 x i64> poison, i64 %759, i64 0
  %.splat447 = shufflevector <8 x i64> %.splatinsert446, <8 x i64> poison, <8 x i32> zeroinitializer
  %762 = mul <8 x i64> %.splat447, splat (i64 32)
  %763 = add <8 x i64> %761, %762
  %764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %760, 0
  %765 = insertvalue { <8 x ptr>, <8 x i64> } %764, <8 x i64> %763, 1
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %765, 1
  %768 = extractelement <8 x ptr> %766, i32 0
  %769 = extractelement <8 x i64> %767, i32 0
  %770 = sub i64 %769, 0
  %771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %772 = select i1 %771, i64 %770, i64 0
  %private.contiguous.address448 = getelementptr i8, ptr %768, i64 %772
  %private.contiguous.load449 = load <8 x float>, ptr %private.contiguous.address448, align 4
  %773 = select <8 x i1> %71, <8 x float> %private.contiguous.load449, <8 x float> zeroinitializer
  %.state450 = load i64, ptr %.slot72, align 4
  %774 = add i64 1040, %.state450
  %tile_snapshot.spill.load451 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load451, 0
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load451, 1
  %.splatinsert452 = insertelement <8 x i64> poison, i64 %774, i64 0
  %.splat453 = shufflevector <8 x i64> %.splatinsert452, <8 x i64> poison, <8 x i32> zeroinitializer
  %777 = mul <8 x i64> %.splat453, splat (i64 32)
  %778 = add <8 x i64> %776, %777
  %779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %775, 0
  %780 = insertvalue { <8 x ptr>, <8 x i64> } %779, <8 x i64> %778, 1
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %780, 1
  %783 = extractelement <8 x ptr> %781, i32 0
  %784 = extractelement <8 x i64> %782, i32 0
  %785 = sub i64 %784, 0
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %787 = select i1 %786, i64 %785, i64 0
  %private.contiguous.address454 = getelementptr i8, ptr %783, i64 %787
  %private.contiguous.load455 = load <8 x float>, ptr %private.contiguous.address454, align 4
  %788 = select <8 x i1> %71, <8 x float> %private.contiguous.load455, <8 x float> zeroinitializer
  %789 = fmul <8 x float> %773, %788
  %.state456 = load <8 x float>, ptr %.slot73, align 32
  %790 = fadd <8 x float> %.state456, %789
  %.state457 = load i64, ptr %.slot72, align 4
  %791 = add i64 %.state457, 1
  store i64 %791, ptr %.slot72, align 4
  %792 = load <8 x float>, ptr %.slot73, align 32
  %793 = select <8 x i1> %71, <8 x float> %790, <8 x float> %792
  store <8 x float> %793, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false443
  store i64 0, ptr %.slot74, align 4
  %794 = load <8 x float>, ptr %.slot75, align 32
  %795 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %794
  store <8 x float> %795, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state458 = load i64, ptr %.slot74, align 4
  %796 = icmp slt i64 %.state458, 80
  br i1 %796, label %direct.true459, label %direct.false460

direct.schedule.62:                               ; preds = %direct.true459
  %.state461 = load i64, ptr %.slot74, align 4
  %797 = add i64 0, %.state461
  %tile_snapshot.spill.load462 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load462, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load462, 1
  %.splatinsert463 = insertelement <8 x i64> poison, i64 %797, i64 0
  %.splat464 = shufflevector <8 x i64> %.splatinsert463, <8 x i64> poison, <8 x i32> zeroinitializer
  %800 = mul <8 x i64> %.splat464, splat (i64 32)
  %801 = add <8 x i64> %799, %800
  %802 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %798, 0
  %803 = insertvalue { <8 x ptr>, <8 x i64> } %802, <8 x i64> %801, 1
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %805 = extractvalue { <8 x ptr>, <8 x i64> } %803, 1
  %806 = extractelement <8 x ptr> %804, i32 0
  %807 = extractelement <8 x i64> %805, i32 0
  %808 = sub i64 %807, 0
  %809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %810 = select i1 %809, i64 %808, i64 0
  %private.contiguous.address465 = getelementptr i8, ptr %806, i64 %810
  %private.contiguous.load466 = load <8 x float>, ptr %private.contiguous.address465, align 4
  %811 = select <8 x i1> %71, <8 x float> %private.contiguous.load466, <8 x float> zeroinitializer
  %.state467 = load i64, ptr %.slot74, align 4
  %812 = add i64 1120, %.state467
  %tile_snapshot.spill.load468 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load468, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load468, 1
  %.splatinsert469 = insertelement <8 x i64> poison, i64 %812, i64 0
  %.splat470 = shufflevector <8 x i64> %.splatinsert469, <8 x i64> poison, <8 x i32> zeroinitializer
  %815 = mul <8 x i64> %.splat470, splat (i64 32)
  %816 = add <8 x i64> %814, %815
  %817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %813, 0
  %818 = insertvalue { <8 x ptr>, <8 x i64> } %817, <8 x i64> %816, 1
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %818, 1
  %821 = extractelement <8 x ptr> %819, i32 0
  %822 = extractelement <8 x i64> %820, i32 0
  %823 = sub i64 %822, 0
  %824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %825 = select i1 %824, i64 %823, i64 0
  %private.contiguous.address471 = getelementptr i8, ptr %821, i64 %825
  %private.contiguous.load472 = load <8 x float>, ptr %private.contiguous.address471, align 4
  %826 = select <8 x i1> %71, <8 x float> %private.contiguous.load472, <8 x float> zeroinitializer
  %827 = fmul <8 x float> %811, %826
  %.state473 = load <8 x float>, ptr %.slot75, align 32
  %828 = fadd <8 x float> %.state473, %827
  %.state474 = load i64, ptr %.slot74, align 4
  %829 = add i64 %.state474, 1
  store i64 %829, ptr %.slot74, align 4
  %830 = load <8 x float>, ptr %.slot75, align 32
  %831 = select <8 x i1> %71, <8 x float> %828, <8 x float> %830
  store <8 x float> %831, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false460
  store i64 0, ptr %.slot76, align 4
  %832 = load <8 x float>, ptr %.slot77, align 32
  %833 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %832
  store <8 x float> %833, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state475 = load i64, ptr %.slot76, align 4
  %834 = icmp slt i64 %.state475, 80
  br i1 %834, label %direct.true476, label %direct.false477

direct.schedule.65:                               ; preds = %direct.true476
  %.state478 = load i64, ptr %.slot76, align 4
  %835 = add i64 0, %.state478
  %tile_snapshot.spill.load479 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load479, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load479, 1
  %.splatinsert480 = insertelement <8 x i64> poison, i64 %835, i64 0
  %.splat481 = shufflevector <8 x i64> %.splatinsert480, <8 x i64> poison, <8 x i32> zeroinitializer
  %838 = mul <8 x i64> %.splat481, splat (i64 32)
  %839 = add <8 x i64> %837, %838
  %840 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %836, 0
  %841 = insertvalue { <8 x ptr>, <8 x i64> } %840, <8 x i64> %839, 1
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %841, 1
  %844 = extractelement <8 x ptr> %842, i32 0
  %845 = extractelement <8 x i64> %843, i32 0
  %846 = sub i64 %845, 0
  %847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %848 = select i1 %847, i64 %846, i64 0
  %private.contiguous.address482 = getelementptr i8, ptr %844, i64 %848
  %private.contiguous.load483 = load <8 x float>, ptr %private.contiguous.address482, align 4
  %849 = select <8 x i1> %71, <8 x float> %private.contiguous.load483, <8 x float> zeroinitializer
  %.state484 = load i64, ptr %.slot76, align 4
  %850 = add i64 1200, %.state484
  %tile_snapshot.spill.load485 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load485, 0
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load485, 1
  %.splatinsert486 = insertelement <8 x i64> poison, i64 %850, i64 0
  %.splat487 = shufflevector <8 x i64> %.splatinsert486, <8 x i64> poison, <8 x i32> zeroinitializer
  %853 = mul <8 x i64> %.splat487, splat (i64 32)
  %854 = add <8 x i64> %852, %853
  %855 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %851, 0
  %856 = insertvalue { <8 x ptr>, <8 x i64> } %855, <8 x i64> %854, 1
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %856, 1
  %859 = extractelement <8 x ptr> %857, i32 0
  %860 = extractelement <8 x i64> %858, i32 0
  %861 = sub i64 %860, 0
  %862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %863 = select i1 %862, i64 %861, i64 0
  %private.contiguous.address488 = getelementptr i8, ptr %859, i64 %863
  %private.contiguous.load489 = load <8 x float>, ptr %private.contiguous.address488, align 4
  %864 = select <8 x i1> %71, <8 x float> %private.contiguous.load489, <8 x float> zeroinitializer
  %865 = fmul <8 x float> %849, %864
  %.state490 = load <8 x float>, ptr %.slot77, align 32
  %866 = fadd <8 x float> %.state490, %865
  %.state491 = load i64, ptr %.slot76, align 4
  %867 = add i64 %.state491, 1
  store i64 %867, ptr %.slot76, align 4
  %868 = load <8 x float>, ptr %.slot77, align 32
  %869 = select <8 x i1> %71, <8 x float> %866, <8 x float> %868
  store <8 x float> %869, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false477
  %.state492 = load <8 x float>, ptr %.slot47, align 32
  %870 = fmul <8 x float> %.state492, splat (float 0x3FBC9F25C0000000)
  %.state493 = load <8 x float>, ptr %.slot49, align 32
  %871 = fmul <8 x float> %.state493, splat (float 0x3FBC9F25C0000000)
  %.state494 = load <8 x float>, ptr %.slot51, align 32
  %872 = fmul <8 x float> %.state494, splat (float 0x3FBC9F25C0000000)
  %.state495 = load <8 x float>, ptr %.slot53, align 32
  %873 = fmul <8 x float> %.state495, splat (float 0x3FBC9F25C0000000)
  %.state496 = load <8 x float>, ptr %.slot55, align 32
  %874 = fmul <8 x float> %.state496, splat (float 0x3FBC9F25C0000000)
  %.state497 = load <8 x float>, ptr %.slot57, align 32
  %875 = fmul <8 x float> %.state497, splat (float 0x3FBC9F25C0000000)
  %.state498 = load <8 x float>, ptr %.slot59, align 32
  %876 = fmul <8 x float> %.state498, splat (float 0x3FBC9F25C0000000)
  %.state499 = load <8 x float>, ptr %.slot61, align 32
  %877 = fmul <8 x float> %.state499, splat (float 0x3FBC9F25C0000000)
  %.state500 = load <8 x float>, ptr %.slot63, align 32
  %878 = fmul <8 x float> %.state500, splat (float 0x3FBC9F25C0000000)
  %.state501 = load <8 x float>, ptr %.slot65, align 32
  %879 = fmul <8 x float> %.state501, splat (float 0x3FBC9F25C0000000)
  %.state502 = load <8 x float>, ptr %.slot67, align 32
  %880 = fmul <8 x float> %.state502, splat (float 0x3FBC9F25C0000000)
  %.state503 = load <8 x float>, ptr %.slot69, align 32
  %881 = fmul <8 x float> %.state503, splat (float 0x3FBC9F25C0000000)
  %.state504 = load <8 x float>, ptr %.slot71, align 32
  %882 = fmul <8 x float> %.state504, splat (float 0x3FBC9F25C0000000)
  %.state505 = load <8 x float>, ptr %.slot73, align 32
  %883 = fmul <8 x float> %.state505, splat (float 0x3FBC9F25C0000000)
  %.state506 = load <8 x float>, ptr %.slot75, align 32
  %884 = fmul <8 x float> %.state506, splat (float 0x3FBC9F25C0000000)
  %.state507 = load <8 x float>, ptr %.slot77, align 32
  %885 = fmul <8 x float> %.state507, splat (float 0x3FBC9F25C0000000)
  %.spill.load508 = load i64, ptr %.spill37, align 4
  %886 = add i64 0, %.spill.load508
  %.spill.load509 = load i64, ptr %.spill37, align 4
  %887 = add i64 1, %.spill.load509
  %.spill.load510 = load i64, ptr %.spill37, align 4
  %888 = add i64 2, %.spill.load510
  %.spill.load511 = load i64, ptr %.spill37, align 4
  %889 = add i64 3, %.spill.load511
  %.spill.load512 = load i64, ptr %.spill37, align 4
  %890 = add i64 4, %.spill.load512
  %.spill.load513 = load i64, ptr %.spill37, align 4
  %891 = add i64 5, %.spill.load513
  %.spill.load514 = load i64, ptr %.spill37, align 4
  %892 = add i64 6, %.spill.load514
  %.spill.load515 = load i64, ptr %.spill37, align 4
  %893 = add i64 7, %.spill.load515
  %.spill.load516 = load i64, ptr %.spill37, align 4
  %894 = add i64 8, %.spill.load516
  %.spill.load517 = load i64, ptr %.spill37, align 4
  %895 = add i64 9, %.spill.load517
  %.spill.load518 = load i64, ptr %.spill37, align 4
  %896 = add i64 10, %.spill.load518
  %.spill.load519 = load i64, ptr %.spill37, align 4
  %897 = add i64 11, %.spill.load519
  %.spill.load520 = load i64, ptr %.spill37, align 4
  %898 = add i64 12, %.spill.load520
  %.spill.load521 = load i64, ptr %.spill37, align 4
  %899 = add i64 13, %.spill.load521
  %.spill.load522 = load i64, ptr %.spill37, align 4
  %900 = add i64 14, %.spill.load522
  %.spill.load523 = load i64, ptr %.spill37, align 4
  %901 = add i64 15, %.spill.load523
  %902 = icmp slt i64 %886, 2053
  %903 = icmp slt i64 %887, 2053
  %904 = icmp slt i64 %888, 2053
  %905 = icmp slt i64 %889, 2053
  %906 = icmp slt i64 %890, 2053
  %907 = icmp slt i64 %891, 2053
  %908 = icmp slt i64 %892, 2053
  %909 = icmp slt i64 %893, 2053
  %910 = icmp slt i64 %894, 2053
  %911 = icmp slt i64 %895, 2053
  %912 = icmp slt i64 %896, 2053
  %913 = icmp slt i64 %897, 2053
  %914 = icmp slt i64 %898, 2053
  %915 = icmp slt i64 %899, 2053
  %916 = icmp slt i64 %900, 2053
  %917 = icmp slt i64 %901, 2053
  %.spill.load524 = load i64, ptr %.spill29, align 4
  %918 = add i64 0, %.spill.load524
  store i64 %918, ptr %.spill78, align 4
  %919 = add i64 %918, 2053
  %920 = sub i64 %919, 1
  %921 = icmp sle i64 %886, %920
  %922 = icmp sle i64 %887, %920
  %923 = icmp sle i64 %888, %920
  %924 = icmp sle i64 %889, %920
  %925 = icmp sle i64 %890, %920
  %926 = icmp sle i64 %891, %920
  %927 = icmp sle i64 %892, %920
  %928 = icmp sle i64 %893, %920
  %929 = icmp sle i64 %894, %920
  %930 = icmp sle i64 %895, %920
  %931 = icmp sle i64 %896, %920
  %932 = icmp sle i64 %897, %920
  %933 = icmp sle i64 %898, %920
  %934 = icmp sle i64 %899, %920
  %935 = icmp sle i64 %900, %920
  %936 = icmp sle i64 %901, %920
  %937 = and i1 %902, %921
  store i1 %937, ptr %.spill79, align 1
  %938 = and i1 %903, %922
  store i1 %938, ptr %.spill80, align 1
  %939 = and i1 %904, %923
  store i1 %939, ptr %.spill81, align 1
  %940 = and i1 %905, %924
  store i1 %940, ptr %.spill82, align 1
  %941 = and i1 %906, %925
  store i1 %941, ptr %.spill83, align 1
  %942 = and i1 %907, %926
  store i1 %942, ptr %.spill84, align 1
  %943 = and i1 %908, %927
  store i1 %943, ptr %.spill85, align 1
  %944 = and i1 %909, %928
  store i1 %944, ptr %.spill86, align 1
  %945 = and i1 %910, %929
  store i1 %945, ptr %.spill87, align 1
  %946 = and i1 %911, %930
  store i1 %946, ptr %.spill88, align 1
  %947 = and i1 %912, %931
  store i1 %947, ptr %.spill89, align 1
  %948 = and i1 %913, %932
  store i1 %948, ptr %.spill90, align 1
  %949 = and i1 %914, %933
  store i1 %949, ptr %.spill91, align 1
  %950 = and i1 %915, %934
  store i1 %950, ptr %.spill92, align 1
  %951 = and i1 %916, %935
  store i1 %951, ptr %.spill93, align 1
  %952 = and i1 %917, %936
  store i1 %952, ptr %.spill94, align 1
  %.splatinsert525 = insertelement <8 x i1> poison, i1 %937, i64 0
  %.splat526 = shufflevector <8 x i1> %.splatinsert525, <8 x i1> poison, <8 x i32> zeroinitializer
  %953 = select <8 x i1> %.splat526, <8 x float> %870, <8 x float> splat (float 0xC6293E5940000000)
  %954 = load <8 x float>, ptr %.spill95, align 32
  %955 = select <8 x i1> %71, <8 x float> %953, <8 x float> %954
  store <8 x float> %955, ptr %.spill95, align 32
  %.splatinsert527 = insertelement <8 x i1> poison, i1 %938, i64 0
  %.splat528 = shufflevector <8 x i1> %.splatinsert527, <8 x i1> poison, <8 x i32> zeroinitializer
  %956 = select <8 x i1> %.splat528, <8 x float> %871, <8 x float> splat (float 0xC6293E5940000000)
  %957 = load <8 x float>, ptr %.spill96, align 32
  %958 = select <8 x i1> %71, <8 x float> %956, <8 x float> %957
  store <8 x float> %958, ptr %.spill96, align 32
  %.splatinsert529 = insertelement <8 x i1> poison, i1 %939, i64 0
  %.splat530 = shufflevector <8 x i1> %.splatinsert529, <8 x i1> poison, <8 x i32> zeroinitializer
  %959 = select <8 x i1> %.splat530, <8 x float> %872, <8 x float> splat (float 0xC6293E5940000000)
  %960 = load <8 x float>, ptr %.spill97, align 32
  %961 = select <8 x i1> %71, <8 x float> %959, <8 x float> %960
  store <8 x float> %961, ptr %.spill97, align 32
  %.splatinsert531 = insertelement <8 x i1> poison, i1 %940, i64 0
  %.splat532 = shufflevector <8 x i1> %.splatinsert531, <8 x i1> poison, <8 x i32> zeroinitializer
  %962 = select <8 x i1> %.splat532, <8 x float> %873, <8 x float> splat (float 0xC6293E5940000000)
  %963 = load <8 x float>, ptr %.spill98, align 32
  %964 = select <8 x i1> %71, <8 x float> %962, <8 x float> %963
  store <8 x float> %964, ptr %.spill98, align 32
  %.splatinsert533 = insertelement <8 x i1> poison, i1 %941, i64 0
  %.splat534 = shufflevector <8 x i1> %.splatinsert533, <8 x i1> poison, <8 x i32> zeroinitializer
  %965 = select <8 x i1> %.splat534, <8 x float> %874, <8 x float> splat (float 0xC6293E5940000000)
  %966 = load <8 x float>, ptr %.spill99, align 32
  %967 = select <8 x i1> %71, <8 x float> %965, <8 x float> %966
  store <8 x float> %967, ptr %.spill99, align 32
  %.splatinsert535 = insertelement <8 x i1> poison, i1 %942, i64 0
  %.splat536 = shufflevector <8 x i1> %.splatinsert535, <8 x i1> poison, <8 x i32> zeroinitializer
  %968 = select <8 x i1> %.splat536, <8 x float> %875, <8 x float> splat (float 0xC6293E5940000000)
  %969 = load <8 x float>, ptr %.spill100, align 32
  %970 = select <8 x i1> %71, <8 x float> %968, <8 x float> %969
  store <8 x float> %970, ptr %.spill100, align 32
  %.splatinsert537 = insertelement <8 x i1> poison, i1 %943, i64 0
  %.splat538 = shufflevector <8 x i1> %.splatinsert537, <8 x i1> poison, <8 x i32> zeroinitializer
  %971 = select <8 x i1> %.splat538, <8 x float> %876, <8 x float> splat (float 0xC6293E5940000000)
  %972 = load <8 x float>, ptr %.spill101, align 32
  %973 = select <8 x i1> %71, <8 x float> %971, <8 x float> %972
  store <8 x float> %973, ptr %.spill101, align 32
  %.splatinsert539 = insertelement <8 x i1> poison, i1 %944, i64 0
  %.splat540 = shufflevector <8 x i1> %.splatinsert539, <8 x i1> poison, <8 x i32> zeroinitializer
  %974 = select <8 x i1> %.splat540, <8 x float> %877, <8 x float> splat (float 0xC6293E5940000000)
  %975 = load <8 x float>, ptr %.spill102, align 32
  %976 = select <8 x i1> %71, <8 x float> %974, <8 x float> %975
  store <8 x float> %976, ptr %.spill102, align 32
  %.splatinsert541 = insertelement <8 x i1> poison, i1 %945, i64 0
  %.splat542 = shufflevector <8 x i1> %.splatinsert541, <8 x i1> poison, <8 x i32> zeroinitializer
  %977 = select <8 x i1> %.splat542, <8 x float> %878, <8 x float> splat (float 0xC6293E5940000000)
  %978 = load <8 x float>, ptr %.spill103, align 32
  %979 = select <8 x i1> %71, <8 x float> %977, <8 x float> %978
  store <8 x float> %979, ptr %.spill103, align 32
  %.splatinsert543 = insertelement <8 x i1> poison, i1 %946, i64 0
  %.splat544 = shufflevector <8 x i1> %.splatinsert543, <8 x i1> poison, <8 x i32> zeroinitializer
  %980 = select <8 x i1> %.splat544, <8 x float> %879, <8 x float> splat (float 0xC6293E5940000000)
  %981 = load <8 x float>, ptr %.spill104, align 32
  %982 = select <8 x i1> %71, <8 x float> %980, <8 x float> %981
  store <8 x float> %982, ptr %.spill104, align 32
  %.splatinsert545 = insertelement <8 x i1> poison, i1 %947, i64 0
  %.splat546 = shufflevector <8 x i1> %.splatinsert545, <8 x i1> poison, <8 x i32> zeroinitializer
  %983 = select <8 x i1> %.splat546, <8 x float> %880, <8 x float> splat (float 0xC6293E5940000000)
  %984 = load <8 x float>, ptr %.spill105, align 32
  %985 = select <8 x i1> %71, <8 x float> %983, <8 x float> %984
  store <8 x float> %985, ptr %.spill105, align 32
  %.splatinsert547 = insertelement <8 x i1> poison, i1 %948, i64 0
  %.splat548 = shufflevector <8 x i1> %.splatinsert547, <8 x i1> poison, <8 x i32> zeroinitializer
  %986 = select <8 x i1> %.splat548, <8 x float> %881, <8 x float> splat (float 0xC6293E5940000000)
  %987 = load <8 x float>, ptr %.spill106, align 32
  %988 = select <8 x i1> %71, <8 x float> %986, <8 x float> %987
  store <8 x float> %988, ptr %.spill106, align 32
  %.splatinsert549 = insertelement <8 x i1> poison, i1 %949, i64 0
  %.splat550 = shufflevector <8 x i1> %.splatinsert549, <8 x i1> poison, <8 x i32> zeroinitializer
  %989 = select <8 x i1> %.splat550, <8 x float> %882, <8 x float> splat (float 0xC6293E5940000000)
  %990 = load <8 x float>, ptr %.spill107, align 32
  %991 = select <8 x i1> %71, <8 x float> %989, <8 x float> %990
  store <8 x float> %991, ptr %.spill107, align 32
  %.splatinsert551 = insertelement <8 x i1> poison, i1 %950, i64 0
  %.splat552 = shufflevector <8 x i1> %.splatinsert551, <8 x i1> poison, <8 x i32> zeroinitializer
  %992 = select <8 x i1> %.splat552, <8 x float> %883, <8 x float> splat (float 0xC6293E5940000000)
  %993 = load <8 x float>, ptr %.spill108, align 32
  %994 = select <8 x i1> %71, <8 x float> %992, <8 x float> %993
  store <8 x float> %994, ptr %.spill108, align 32
  %.splatinsert553 = insertelement <8 x i1> poison, i1 %951, i64 0
  %.splat554 = shufflevector <8 x i1> %.splatinsert553, <8 x i1> poison, <8 x i32> zeroinitializer
  %995 = select <8 x i1> %.splat554, <8 x float> %884, <8 x float> splat (float 0xC6293E5940000000)
  %996 = load <8 x float>, ptr %.spill109, align 32
  %997 = select <8 x i1> %71, <8 x float> %995, <8 x float> %996
  store <8 x float> %997, ptr %.spill109, align 32
  %.splatinsert555 = insertelement <8 x i1> poison, i1 %952, i64 0
  %.splat556 = shufflevector <8 x i1> %.splatinsert555, <8 x i1> poison, <8 x i32> zeroinitializer
  %998 = select <8 x i1> %.splat556, <8 x float> %885, <8 x float> splat (float 0xC6293E5940000000)
  %999 = load <8 x float>, ptr %.spill110, align 32
  %1000 = select <8 x i1> %71, <8 x float> %998, <8 x float> %999
  store <8 x float> %1000, ptr %.spill110, align 32
  %1001 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 0
  %1004 = select <8 x i1> %71, <8 x ptr> %1002, <8 x ptr> %1003
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 1
  %1007 = select <8 x i1> %71, <8 x i64> %1005, <8 x i64> %1006
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1004, 0
  %1009 = insertvalue { <8 x ptr>, <8 x i64> } %1008, <8 x i64> %1007, 1
  store { <8 x ptr>, <8 x i64> } %1009, ptr %tile_snapshot.spill111, align 64
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1012 = add <8 x i64> %1011, zeroinitializer
  %1013 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1010, 0
  %1014 = insertvalue { <8 x ptr>, <8 x i64> } %1013, <8 x i64> %1012, 1
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %1014, 1
  %1017 = extractelement <8 x ptr> %1015, i32 0
  %1018 = extractelement <8 x i64> %1016, i32 0
  %1019 = sub i64 %1018, 0
  %1020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1021 = select i1 %1020, i64 %1019, i64 0
  %private.contiguous.address557 = getelementptr i8, ptr %1017, i64 %1021
  %private.contiguous.preserve558 = load <8 x float>, ptr %private.contiguous.address557, align 4
  %1022 = select <8 x i1> %71, <8 x float> %953, <8 x float> %private.contiguous.preserve558
  store <8 x float> %1022, ptr %private.contiguous.address557, align 4
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1025 = add <8 x i64> %1024, splat (i64 32)
  %1026 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1023, 0
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } %1026, <8 x i64> %1025, 1
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1027, 1
  %1030 = extractelement <8 x ptr> %1028, i32 0
  %1031 = extractelement <8 x i64> %1029, i32 0
  %1032 = sub i64 %1031, 0
  %1033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1034 = select i1 %1033, i64 %1032, i64 0
  %private.contiguous.address559 = getelementptr i8, ptr %1030, i64 %1034
  %private.contiguous.preserve560 = load <8 x float>, ptr %private.contiguous.address559, align 4
  %1035 = select <8 x i1> %71, <8 x float> %956, <8 x float> %private.contiguous.preserve560
  store <8 x float> %1035, ptr %private.contiguous.address559, align 4
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1038 = add <8 x i64> %1037, splat (i64 64)
  %1039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1036, 0
  %1040 = insertvalue { <8 x ptr>, <8 x i64> } %1039, <8 x i64> %1038, 1
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %1040, 1
  %1043 = extractelement <8 x ptr> %1041, i32 0
  %1044 = extractelement <8 x i64> %1042, i32 0
  %1045 = sub i64 %1044, 0
  %1046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1047 = select i1 %1046, i64 %1045, i64 0
  %private.contiguous.address561 = getelementptr i8, ptr %1043, i64 %1047
  %private.contiguous.preserve562 = load <8 x float>, ptr %private.contiguous.address561, align 4
  %1048 = select <8 x i1> %71, <8 x float> %959, <8 x float> %private.contiguous.preserve562
  store <8 x float> %1048, ptr %private.contiguous.address561, align 4
  %1049 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1051 = add <8 x i64> %1050, splat (i64 96)
  %1052 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1049, 0
  %1053 = insertvalue { <8 x ptr>, <8 x i64> } %1052, <8 x i64> %1051, 1
  %1054 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %1053, 1
  %1056 = extractelement <8 x ptr> %1054, i32 0
  %1057 = extractelement <8 x i64> %1055, i32 0
  %1058 = sub i64 %1057, 0
  %1059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1060 = select i1 %1059, i64 %1058, i64 0
  %private.contiguous.address563 = getelementptr i8, ptr %1056, i64 %1060
  %private.contiguous.preserve564 = load <8 x float>, ptr %private.contiguous.address563, align 4
  %1061 = select <8 x i1> %71, <8 x float> %962, <8 x float> %private.contiguous.preserve564
  store <8 x float> %1061, ptr %private.contiguous.address563, align 4
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1064 = add <8 x i64> %1063, splat (i64 128)
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1062, 0
  %1066 = insertvalue { <8 x ptr>, <8 x i64> } %1065, <8 x i64> %1064, 1
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %1066, 1
  %1069 = extractelement <8 x ptr> %1067, i32 0
  %1070 = extractelement <8 x i64> %1068, i32 0
  %1071 = sub i64 %1070, 0
  %1072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1073 = select i1 %1072, i64 %1071, i64 0
  %private.contiguous.address565 = getelementptr i8, ptr %1069, i64 %1073
  %private.contiguous.preserve566 = load <8 x float>, ptr %private.contiguous.address565, align 4
  %1074 = select <8 x i1> %71, <8 x float> %965, <8 x float> %private.contiguous.preserve566
  store <8 x float> %1074, ptr %private.contiguous.address565, align 4
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1077 = add <8 x i64> %1076, splat (i64 160)
  %1078 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1075, 0
  %1079 = insertvalue { <8 x ptr>, <8 x i64> } %1078, <8 x i64> %1077, 1
  %1080 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %1079, 1
  %1082 = extractelement <8 x ptr> %1080, i32 0
  %1083 = extractelement <8 x i64> %1081, i32 0
  %1084 = sub i64 %1083, 0
  %1085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1086 = select i1 %1085, i64 %1084, i64 0
  %private.contiguous.address567 = getelementptr i8, ptr %1082, i64 %1086
  %private.contiguous.preserve568 = load <8 x float>, ptr %private.contiguous.address567, align 4
  %1087 = select <8 x i1> %71, <8 x float> %968, <8 x float> %private.contiguous.preserve568
  store <8 x float> %1087, ptr %private.contiguous.address567, align 4
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1090 = add <8 x i64> %1089, splat (i64 192)
  %1091 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1088, 0
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } %1091, <8 x i64> %1090, 1
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %1092, 1
  %1095 = extractelement <8 x ptr> %1093, i32 0
  %1096 = extractelement <8 x i64> %1094, i32 0
  %1097 = sub i64 %1096, 0
  %1098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1099 = select i1 %1098, i64 %1097, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %1095, i64 %1099
  %private.contiguous.preserve570 = load <8 x float>, ptr %private.contiguous.address569, align 4
  %1100 = select <8 x i1> %71, <8 x float> %971, <8 x float> %private.contiguous.preserve570
  store <8 x float> %1100, ptr %private.contiguous.address569, align 4
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1103 = add <8 x i64> %1102, splat (i64 224)
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1101, 0
  %1105 = insertvalue { <8 x ptr>, <8 x i64> } %1104, <8 x i64> %1103, 1
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %1105, 1
  %1108 = extractelement <8 x ptr> %1106, i32 0
  %1109 = extractelement <8 x i64> %1107, i32 0
  %1110 = sub i64 %1109, 0
  %1111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1112 = select i1 %1111, i64 %1110, i64 0
  %private.contiguous.address571 = getelementptr i8, ptr %1108, i64 %1112
  %private.contiguous.preserve572 = load <8 x float>, ptr %private.contiguous.address571, align 4
  %1113 = select <8 x i1> %71, <8 x float> %974, <8 x float> %private.contiguous.preserve572
  store <8 x float> %1113, ptr %private.contiguous.address571, align 4
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1116 = add <8 x i64> %1115, splat (i64 256)
  %1117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1114, 0
  %1118 = insertvalue { <8 x ptr>, <8 x i64> } %1117, <8 x i64> %1116, 1
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 1
  %1121 = extractelement <8 x ptr> %1119, i32 0
  %1122 = extractelement <8 x i64> %1120, i32 0
  %1123 = sub i64 %1122, 0
  %1124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1125 = select i1 %1124, i64 %1123, i64 0
  %private.contiguous.address573 = getelementptr i8, ptr %1121, i64 %1125
  %private.contiguous.preserve574 = load <8 x float>, ptr %private.contiguous.address573, align 4
  %1126 = select <8 x i1> %71, <8 x float> %977, <8 x float> %private.contiguous.preserve574
  store <8 x float> %1126, ptr %private.contiguous.address573, align 4
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1129 = add <8 x i64> %1128, splat (i64 288)
  %1130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1127, 0
  %1131 = insertvalue { <8 x ptr>, <8 x i64> } %1130, <8 x i64> %1129, 1
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %1131, 1
  %1134 = extractelement <8 x ptr> %1132, i32 0
  %1135 = extractelement <8 x i64> %1133, i32 0
  %1136 = sub i64 %1135, 0
  %1137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1138 = select i1 %1137, i64 %1136, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %1134, i64 %1138
  %private.contiguous.preserve576 = load <8 x float>, ptr %private.contiguous.address575, align 4
  %1139 = select <8 x i1> %71, <8 x float> %980, <8 x float> %private.contiguous.preserve576
  store <8 x float> %1139, ptr %private.contiguous.address575, align 4
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1142 = add <8 x i64> %1141, splat (i64 320)
  %1143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1140, 0
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } %1143, <8 x i64> %1142, 1
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %1144, 1
  %1147 = extractelement <8 x ptr> %1145, i32 0
  %1148 = extractelement <8 x i64> %1146, i32 0
  %1149 = sub i64 %1148, 0
  %1150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1151 = select i1 %1150, i64 %1149, i64 0
  %private.contiguous.address577 = getelementptr i8, ptr %1147, i64 %1151
  %private.contiguous.preserve578 = load <8 x float>, ptr %private.contiguous.address577, align 4
  %1152 = select <8 x i1> %71, <8 x float> %983, <8 x float> %private.contiguous.preserve578
  store <8 x float> %1152, ptr %private.contiguous.address577, align 4
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1155 = add <8 x i64> %1154, splat (i64 352)
  %1156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1153, 0
  %1157 = insertvalue { <8 x ptr>, <8 x i64> } %1156, <8 x i64> %1155, 1
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %1157, 1
  %1160 = extractelement <8 x ptr> %1158, i32 0
  %1161 = extractelement <8 x i64> %1159, i32 0
  %1162 = sub i64 %1161, 0
  %1163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1164 = select i1 %1163, i64 %1162, i64 0
  %private.contiguous.address579 = getelementptr i8, ptr %1160, i64 %1164
  %private.contiguous.preserve580 = load <8 x float>, ptr %private.contiguous.address579, align 4
  %1165 = select <8 x i1> %71, <8 x float> %986, <8 x float> %private.contiguous.preserve580
  store <8 x float> %1165, ptr %private.contiguous.address579, align 4
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1168 = add <8 x i64> %1167, splat (i64 384)
  %1169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1166, 0
  %1170 = insertvalue { <8 x ptr>, <8 x i64> } %1169, <8 x i64> %1168, 1
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %1170, 1
  %1173 = extractelement <8 x ptr> %1171, i32 0
  %1174 = extractelement <8 x i64> %1172, i32 0
  %1175 = sub i64 %1174, 0
  %1176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1177 = select i1 %1176, i64 %1175, i64 0
  %private.contiguous.address581 = getelementptr i8, ptr %1173, i64 %1177
  %private.contiguous.preserve582 = load <8 x float>, ptr %private.contiguous.address581, align 4
  %1178 = select <8 x i1> %71, <8 x float> %989, <8 x float> %private.contiguous.preserve582
  store <8 x float> %1178, ptr %private.contiguous.address581, align 4
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1181 = add <8 x i64> %1180, splat (i64 416)
  %1182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1179, 0
  %1183 = insertvalue { <8 x ptr>, <8 x i64> } %1182, <8 x i64> %1181, 1
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %1183, 1
  %1186 = extractelement <8 x ptr> %1184, i32 0
  %1187 = extractelement <8 x i64> %1185, i32 0
  %1188 = sub i64 %1187, 0
  %1189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1190 = select i1 %1189, i64 %1188, i64 0
  %private.contiguous.address583 = getelementptr i8, ptr %1186, i64 %1190
  %private.contiguous.preserve584 = load <8 x float>, ptr %private.contiguous.address583, align 4
  %1191 = select <8 x i1> %71, <8 x float> %992, <8 x float> %private.contiguous.preserve584
  store <8 x float> %1191, ptr %private.contiguous.address583, align 4
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1193 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1194 = add <8 x i64> %1193, splat (i64 448)
  %1195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1192, 0
  %1196 = insertvalue { <8 x ptr>, <8 x i64> } %1195, <8 x i64> %1194, 1
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 1
  %1199 = extractelement <8 x ptr> %1197, i32 0
  %1200 = extractelement <8 x i64> %1198, i32 0
  %1201 = sub i64 %1200, 0
  %1202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1203 = select i1 %1202, i64 %1201, i64 0
  %private.contiguous.address585 = getelementptr i8, ptr %1199, i64 %1203
  %private.contiguous.preserve586 = load <8 x float>, ptr %private.contiguous.address585, align 4
  %1204 = select <8 x i1> %71, <8 x float> %995, <8 x float> %private.contiguous.preserve586
  store <8 x float> %1204, ptr %private.contiguous.address585, align 4
  %1205 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1207 = add <8 x i64> %1206, splat (i64 480)
  %1208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1205, 0
  %1209 = insertvalue { <8 x ptr>, <8 x i64> } %1208, <8 x i64> %1207, 1
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1211 = extractvalue { <8 x ptr>, <8 x i64> } %1209, 1
  %1212 = extractelement <8 x ptr> %1210, i32 0
  %1213 = extractelement <8 x i64> %1211, i32 0
  %1214 = sub i64 %1213, 0
  %1215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1216 = select i1 %1215, i64 %1214, i64 0
  %private.contiguous.address587 = getelementptr i8, ptr %1212, i64 %1216
  %private.contiguous.preserve588 = load <8 x float>, ptr %private.contiguous.address587, align 4
  %1217 = select <8 x i1> %71, <8 x float> %998, <8 x float> %private.contiguous.preserve588
  store <8 x float> %1217, ptr %private.contiguous.address587, align 4
  store i64 0, ptr %.slot112, align 4
  %1218 = load <8 x float>, ptr %.slot113, align 32
  %1219 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1218
  store <8 x float> %1219, ptr %.slot113, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state589 = load i64, ptr %.slot112, align 4
  %1220 = icmp slt i64 %.state589, 16
  br i1 %1220, label %direct.true590, label %direct.false591

direct.schedule.68:                               ; preds = %direct.true590
  %.state592 = load i64, ptr %.slot112, align 4
  %1221 = sdiv i64 %.state592, 1
  %.spill.load593 = load i64, ptr %.spill78, align 4
  %1222 = mul i64 %.spill.load593, 1
  %1223 = add i64 %1222, 0
  %1224 = mul i64 %1223, 1
  %1225 = add i64 %1224, 0
  %1226 = mul i64 %1225, 16
  %1227 = add i64 %1226, %1221
  %tile_snapshot.spill.load594 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load594, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load594, 1
  %.splatinsert595 = insertelement <8 x i64> poison, i64 %1227, i64 0
  %.splat596 = shufflevector <8 x i64> %.splatinsert595, <8 x i64> poison, <8 x i32> zeroinitializer
  %1230 = mul <8 x i64> %.splat596, splat (i64 32)
  %1231 = add <8 x i64> %1229, %1230
  %1232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1228, 0
  %1233 = insertvalue { <8 x ptr>, <8 x i64> } %1232, <8 x i64> %1231, 1
  %1234 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1235 = extractvalue { <8 x ptr>, <8 x i64> } %1233, 1
  %1236 = extractelement <8 x ptr> %1234, i32 0
  %1237 = extractelement <8 x i64> %1235, i32 0
  %1238 = sub i64 %1237, 0
  %1239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1240 = select i1 %1239, i64 %1238, i64 0
  %private.contiguous.address597 = getelementptr i8, ptr %1236, i64 %1240
  %private.contiguous.load598 = load <8 x float>, ptr %private.contiguous.address597, align 4
  %1241 = select <8 x i1> %71, <8 x float> %private.contiguous.load598, <8 x float> zeroinitializer
  %.state599 = load <8 x float>, ptr %.slot113, align 32
  %1242 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state599, <8 x float> %1241)
  %.state600 = load i64, ptr %.slot112, align 4
  %1243 = add i64 %.state600, 1
  store i64 %1243, ptr %.slot112, align 4
  %1244 = load <8 x float>, ptr %.slot113, align 32
  %1245 = select <8 x i1> %71, <8 x float> %1242, <8 x float> %1244
  store <8 x float> %1245, ptr %.slot113, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false591
  %.state601 = load <8 x float>, ptr %.slot35, align 32
  %.state602 = load <8 x float>, ptr %.slot113, align 32
  %1246 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state601, <8 x float> %.state602)
  %1247 = load <8 x float>, ptr %.spill114, align 32
  %1248 = select <8 x i1> %71, <8 x float> %1246, <8 x float> %1247
  store <8 x float> %1248, ptr %.spill114, align 32
  %.state603 = load <8 x float>, ptr %.slot35, align 32
  %1249 = fsub <8 x float> %.state603, %1246
  %1250 = select <8 x i1> %71, <8 x float> %1249, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1250)
  %1251 = load <8 x float>, ptr %.spill115, align 32
  %1252 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %1251
  store <8 x float> %1252, ptr %.spill115, align 32
  %.spill.load604 = load <8 x float>, ptr %.spill95, align 32
  %1253 = fsub <8 x float> %.spill.load604, %1246
  %.spill.load605 = load <8 x float>, ptr %.spill96, align 32
  %1254 = fsub <8 x float> %.spill.load605, %1246
  %.spill.load606 = load <8 x float>, ptr %.spill97, align 32
  %1255 = fsub <8 x float> %.spill.load606, %1246
  %.spill.load607 = load <8 x float>, ptr %.spill98, align 32
  %1256 = fsub <8 x float> %.spill.load607, %1246
  %.spill.load608 = load <8 x float>, ptr %.spill99, align 32
  %1257 = fsub <8 x float> %.spill.load608, %1246
  %.spill.load609 = load <8 x float>, ptr %.spill100, align 32
  %1258 = fsub <8 x float> %.spill.load609, %1246
  %.spill.load610 = load <8 x float>, ptr %.spill101, align 32
  %1259 = fsub <8 x float> %.spill.load610, %1246
  %.spill.load611 = load <8 x float>, ptr %.spill102, align 32
  %1260 = fsub <8 x float> %.spill.load611, %1246
  %.spill.load612 = load <8 x float>, ptr %.spill103, align 32
  %1261 = fsub <8 x float> %.spill.load612, %1246
  %.spill.load613 = load <8 x float>, ptr %.spill104, align 32
  %1262 = fsub <8 x float> %.spill.load613, %1246
  %.spill.load614 = load <8 x float>, ptr %.spill105, align 32
  %1263 = fsub <8 x float> %.spill.load614, %1246
  %.spill.load615 = load <8 x float>, ptr %.spill106, align 32
  %1264 = fsub <8 x float> %.spill.load615, %1246
  %.spill.load616 = load <8 x float>, ptr %.spill107, align 32
  %1265 = fsub <8 x float> %.spill.load616, %1246
  %.spill.load617 = load <8 x float>, ptr %.spill108, align 32
  %1266 = fsub <8 x float> %.spill.load617, %1246
  %.spill.load618 = load <8 x float>, ptr %.spill109, align 32
  %1267 = fsub <8 x float> %.spill.load618, %1246
  %.spill.load619 = load <8 x float>, ptr %.spill110, align 32
  %1268 = fsub <8 x float> %.spill.load619, %1246
  %1269 = select <8 x i1> %71, <8 x float> %1253, <8 x float> zeroinitializer
  %native.exp620 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1269)
  %1270 = select <8 x i1> %71, <8 x float> %1254, <8 x float> zeroinitializer
  %native.exp621 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1270)
  %1271 = select <8 x i1> %71, <8 x float> %1255, <8 x float> zeroinitializer
  %native.exp622 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1271)
  %1272 = select <8 x i1> %71, <8 x float> %1256, <8 x float> zeroinitializer
  %native.exp623 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1272)
  %1273 = select <8 x i1> %71, <8 x float> %1257, <8 x float> zeroinitializer
  %native.exp624 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1273)
  %1274 = select <8 x i1> %71, <8 x float> %1258, <8 x float> zeroinitializer
  %native.exp625 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1274)
  %1275 = select <8 x i1> %71, <8 x float> %1259, <8 x float> zeroinitializer
  %native.exp626 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1275)
  %1276 = select <8 x i1> %71, <8 x float> %1260, <8 x float> zeroinitializer
  %native.exp627 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1276)
  %1277 = select <8 x i1> %71, <8 x float> %1261, <8 x float> zeroinitializer
  %native.exp628 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1277)
  %1278 = select <8 x i1> %71, <8 x float> %1262, <8 x float> zeroinitializer
  %native.exp629 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1278)
  %1279 = select <8 x i1> %71, <8 x float> %1263, <8 x float> zeroinitializer
  %native.exp630 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1279)
  %1280 = select <8 x i1> %71, <8 x float> %1264, <8 x float> zeroinitializer
  %native.exp631 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1280)
  %1281 = select <8 x i1> %71, <8 x float> %1265, <8 x float> zeroinitializer
  %native.exp632 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1281)
  %1282 = select <8 x i1> %71, <8 x float> %1266, <8 x float> zeroinitializer
  %native.exp633 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1282)
  %1283 = select <8 x i1> %71, <8 x float> %1267, <8 x float> zeroinitializer
  %native.exp634 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1283)
  %1284 = select <8 x i1> %71, <8 x float> %1268, <8 x float> zeroinitializer
  %native.exp635 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1284)
  %.spill.load636 = load i1, ptr %.spill79, align 1
  %.splatinsert637 = insertelement <8 x i1> poison, i1 %.spill.load636, i64 0
  %.splat638 = shufflevector <8 x i1> %.splatinsert637, <8 x i1> poison, <8 x i32> zeroinitializer
  %1285 = select <8 x i1> %.splat638, <8 x float> %native.exp620, <8 x float> zeroinitializer
  %.spill.load639 = load i1, ptr %.spill80, align 1
  %.splatinsert640 = insertelement <8 x i1> poison, i1 %.spill.load639, i64 0
  %.splat641 = shufflevector <8 x i1> %.splatinsert640, <8 x i1> poison, <8 x i32> zeroinitializer
  %1286 = select <8 x i1> %.splat641, <8 x float> %native.exp621, <8 x float> zeroinitializer
  %.spill.load642 = load i1, ptr %.spill81, align 1
  %.splatinsert643 = insertelement <8 x i1> poison, i1 %.spill.load642, i64 0
  %.splat644 = shufflevector <8 x i1> %.splatinsert643, <8 x i1> poison, <8 x i32> zeroinitializer
  %1287 = select <8 x i1> %.splat644, <8 x float> %native.exp622, <8 x float> zeroinitializer
  %.spill.load645 = load i1, ptr %.spill82, align 1
  %.splatinsert646 = insertelement <8 x i1> poison, i1 %.spill.load645, i64 0
  %.splat647 = shufflevector <8 x i1> %.splatinsert646, <8 x i1> poison, <8 x i32> zeroinitializer
  %1288 = select <8 x i1> %.splat647, <8 x float> %native.exp623, <8 x float> zeroinitializer
  %.spill.load648 = load i1, ptr %.spill83, align 1
  %.splatinsert649 = insertelement <8 x i1> poison, i1 %.spill.load648, i64 0
  %.splat650 = shufflevector <8 x i1> %.splatinsert649, <8 x i1> poison, <8 x i32> zeroinitializer
  %1289 = select <8 x i1> %.splat650, <8 x float> %native.exp624, <8 x float> zeroinitializer
  %.spill.load651 = load i1, ptr %.spill84, align 1
  %.splatinsert652 = insertelement <8 x i1> poison, i1 %.spill.load651, i64 0
  %.splat653 = shufflevector <8 x i1> %.splatinsert652, <8 x i1> poison, <8 x i32> zeroinitializer
  %1290 = select <8 x i1> %.splat653, <8 x float> %native.exp625, <8 x float> zeroinitializer
  %.spill.load654 = load i1, ptr %.spill85, align 1
  %.splatinsert655 = insertelement <8 x i1> poison, i1 %.spill.load654, i64 0
  %.splat656 = shufflevector <8 x i1> %.splatinsert655, <8 x i1> poison, <8 x i32> zeroinitializer
  %1291 = select <8 x i1> %.splat656, <8 x float> %native.exp626, <8 x float> zeroinitializer
  %.spill.load657 = load i1, ptr %.spill86, align 1
  %.splatinsert658 = insertelement <8 x i1> poison, i1 %.spill.load657, i64 0
  %.splat659 = shufflevector <8 x i1> %.splatinsert658, <8 x i1> poison, <8 x i32> zeroinitializer
  %1292 = select <8 x i1> %.splat659, <8 x float> %native.exp627, <8 x float> zeroinitializer
  %.spill.load660 = load i1, ptr %.spill87, align 1
  %.splatinsert661 = insertelement <8 x i1> poison, i1 %.spill.load660, i64 0
  %.splat662 = shufflevector <8 x i1> %.splatinsert661, <8 x i1> poison, <8 x i32> zeroinitializer
  %1293 = select <8 x i1> %.splat662, <8 x float> %native.exp628, <8 x float> zeroinitializer
  %.spill.load663 = load i1, ptr %.spill88, align 1
  %.splatinsert664 = insertelement <8 x i1> poison, i1 %.spill.load663, i64 0
  %.splat665 = shufflevector <8 x i1> %.splatinsert664, <8 x i1> poison, <8 x i32> zeroinitializer
  %1294 = select <8 x i1> %.splat665, <8 x float> %native.exp629, <8 x float> zeroinitializer
  %.spill.load666 = load i1, ptr %.spill89, align 1
  %.splatinsert667 = insertelement <8 x i1> poison, i1 %.spill.load666, i64 0
  %.splat668 = shufflevector <8 x i1> %.splatinsert667, <8 x i1> poison, <8 x i32> zeroinitializer
  %1295 = select <8 x i1> %.splat668, <8 x float> %native.exp630, <8 x float> zeroinitializer
  %.spill.load669 = load i1, ptr %.spill90, align 1
  %.splatinsert670 = insertelement <8 x i1> poison, i1 %.spill.load669, i64 0
  %.splat671 = shufflevector <8 x i1> %.splatinsert670, <8 x i1> poison, <8 x i32> zeroinitializer
  %1296 = select <8 x i1> %.splat671, <8 x float> %native.exp631, <8 x float> zeroinitializer
  %.spill.load672 = load i1, ptr %.spill91, align 1
  %.splatinsert673 = insertelement <8 x i1> poison, i1 %.spill.load672, i64 0
  %.splat674 = shufflevector <8 x i1> %.splatinsert673, <8 x i1> poison, <8 x i32> zeroinitializer
  %1297 = select <8 x i1> %.splat674, <8 x float> %native.exp632, <8 x float> zeroinitializer
  %.spill.load675 = load i1, ptr %.spill92, align 1
  %.splatinsert676 = insertelement <8 x i1> poison, i1 %.spill.load675, i64 0
  %.splat677 = shufflevector <8 x i1> %.splatinsert676, <8 x i1> poison, <8 x i32> zeroinitializer
  %1298 = select <8 x i1> %.splat677, <8 x float> %native.exp633, <8 x float> zeroinitializer
  %.spill.load678 = load i1, ptr %.spill93, align 1
  %.splatinsert679 = insertelement <8 x i1> poison, i1 %.spill.load678, i64 0
  %.splat680 = shufflevector <8 x i1> %.splatinsert679, <8 x i1> poison, <8 x i32> zeroinitializer
  %1299 = select <8 x i1> %.splat680, <8 x float> %native.exp634, <8 x float> zeroinitializer
  %.spill.load681 = load i1, ptr %.spill94, align 1
  %.splatinsert682 = insertelement <8 x i1> poison, i1 %.spill.load681, i64 0
  %.splat683 = shufflevector <8 x i1> %.splatinsert682, <8 x i1> poison, <8 x i32> zeroinitializer
  %1300 = select <8 x i1> %.splat683, <8 x float> %native.exp635, <8 x float> zeroinitializer
  %1301 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1302 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1303 = extractvalue { <8 x ptr>, <8 x i64> } %1301, 0
  %1304 = select <8 x i1> %71, <8 x ptr> %1302, <8 x ptr> %1303
  %1305 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %1301, 1
  %1307 = select <8 x i1> %71, <8 x i64> %1305, <8 x i64> %1306
  %1308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1304, 0
  %1309 = insertvalue { <8 x ptr>, <8 x i64> } %1308, <8 x i64> %1307, 1
  store { <8 x ptr>, <8 x i64> } %1309, ptr %tile_snapshot.spill116, align 64
  %1310 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1312 = add <8 x i64> %1311, zeroinitializer
  %1313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1310, 0
  %1314 = insertvalue { <8 x ptr>, <8 x i64> } %1313, <8 x i64> %1312, 1
  %1315 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1316 = extractvalue { <8 x ptr>, <8 x i64> } %1314, 1
  %1317 = extractelement <8 x ptr> %1315, i32 0
  %1318 = extractelement <8 x i64> %1316, i32 0
  %1319 = sub i64 %1318, 0
  %1320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1321 = select i1 %1320, i64 %1319, i64 0
  %private.contiguous.address684 = getelementptr i8, ptr %1317, i64 %1321
  %private.contiguous.preserve685 = load <8 x float>, ptr %private.contiguous.address684, align 4
  %1322 = select <8 x i1> %71, <8 x float> %1285, <8 x float> %private.contiguous.preserve685
  store <8 x float> %1322, ptr %private.contiguous.address684, align 4
  %1323 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1324 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1325 = add <8 x i64> %1324, splat (i64 32)
  %1326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1323, 0
  %1327 = insertvalue { <8 x ptr>, <8 x i64> } %1326, <8 x i64> %1325, 1
  %1328 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1329 = extractvalue { <8 x ptr>, <8 x i64> } %1327, 1
  %1330 = extractelement <8 x ptr> %1328, i32 0
  %1331 = extractelement <8 x i64> %1329, i32 0
  %1332 = sub i64 %1331, 0
  %1333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1334 = select i1 %1333, i64 %1332, i64 0
  %private.contiguous.address686 = getelementptr i8, ptr %1330, i64 %1334
  %private.contiguous.preserve687 = load <8 x float>, ptr %private.contiguous.address686, align 4
  %1335 = select <8 x i1> %71, <8 x float> %1286, <8 x float> %private.contiguous.preserve687
  store <8 x float> %1335, ptr %private.contiguous.address686, align 4
  %1336 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1338 = add <8 x i64> %1337, splat (i64 64)
  %1339 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1336, 0
  %1340 = insertvalue { <8 x ptr>, <8 x i64> } %1339, <8 x i64> %1338, 1
  %1341 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1342 = extractvalue { <8 x ptr>, <8 x i64> } %1340, 1
  %1343 = extractelement <8 x ptr> %1341, i32 0
  %1344 = extractelement <8 x i64> %1342, i32 0
  %1345 = sub i64 %1344, 0
  %1346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1347 = select i1 %1346, i64 %1345, i64 0
  %private.contiguous.address688 = getelementptr i8, ptr %1343, i64 %1347
  %private.contiguous.preserve689 = load <8 x float>, ptr %private.contiguous.address688, align 4
  %1348 = select <8 x i1> %71, <8 x float> %1287, <8 x float> %private.contiguous.preserve689
  store <8 x float> %1348, ptr %private.contiguous.address688, align 4
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1351 = add <8 x i64> %1350, splat (i64 96)
  %1352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1349, 0
  %1353 = insertvalue { <8 x ptr>, <8 x i64> } %1352, <8 x i64> %1351, 1
  %1354 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %1353, 1
  %1356 = extractelement <8 x ptr> %1354, i32 0
  %1357 = extractelement <8 x i64> %1355, i32 0
  %1358 = sub i64 %1357, 0
  %1359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1360 = select i1 %1359, i64 %1358, i64 0
  %private.contiguous.address690 = getelementptr i8, ptr %1356, i64 %1360
  %private.contiguous.preserve691 = load <8 x float>, ptr %private.contiguous.address690, align 4
  %1361 = select <8 x i1> %71, <8 x float> %1288, <8 x float> %private.contiguous.preserve691
  store <8 x float> %1361, ptr %private.contiguous.address690, align 4
  %1362 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1364 = add <8 x i64> %1363, splat (i64 128)
  %1365 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1362, 0
  %1366 = insertvalue { <8 x ptr>, <8 x i64> } %1365, <8 x i64> %1364, 1
  %1367 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %1366, 1
  %1369 = extractelement <8 x ptr> %1367, i32 0
  %1370 = extractelement <8 x i64> %1368, i32 0
  %1371 = sub i64 %1370, 0
  %1372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1373 = select i1 %1372, i64 %1371, i64 0
  %private.contiguous.address692 = getelementptr i8, ptr %1369, i64 %1373
  %private.contiguous.preserve693 = load <8 x float>, ptr %private.contiguous.address692, align 4
  %1374 = select <8 x i1> %71, <8 x float> %1289, <8 x float> %private.contiguous.preserve693
  store <8 x float> %1374, ptr %private.contiguous.address692, align 4
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1376 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1377 = add <8 x i64> %1376, splat (i64 160)
  %1378 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1375, 0
  %1379 = insertvalue { <8 x ptr>, <8 x i64> } %1378, <8 x i64> %1377, 1
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %1379, 1
  %1382 = extractelement <8 x ptr> %1380, i32 0
  %1383 = extractelement <8 x i64> %1381, i32 0
  %1384 = sub i64 %1383, 0
  %1385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1386 = select i1 %1385, i64 %1384, i64 0
  %private.contiguous.address694 = getelementptr i8, ptr %1382, i64 %1386
  %private.contiguous.preserve695 = load <8 x float>, ptr %private.contiguous.address694, align 4
  %1387 = select <8 x i1> %71, <8 x float> %1290, <8 x float> %private.contiguous.preserve695
  store <8 x float> %1387, ptr %private.contiguous.address694, align 4
  %1388 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1389 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1390 = add <8 x i64> %1389, splat (i64 192)
  %1391 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1388, 0
  %1392 = insertvalue { <8 x ptr>, <8 x i64> } %1391, <8 x i64> %1390, 1
  %1393 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1394 = extractvalue { <8 x ptr>, <8 x i64> } %1392, 1
  %1395 = extractelement <8 x ptr> %1393, i32 0
  %1396 = extractelement <8 x i64> %1394, i32 0
  %1397 = sub i64 %1396, 0
  %1398 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1399 = select i1 %1398, i64 %1397, i64 0
  %private.contiguous.address696 = getelementptr i8, ptr %1395, i64 %1399
  %private.contiguous.preserve697 = load <8 x float>, ptr %private.contiguous.address696, align 4
  %1400 = select <8 x i1> %71, <8 x float> %1291, <8 x float> %private.contiguous.preserve697
  store <8 x float> %1400, ptr %private.contiguous.address696, align 4
  %1401 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1402 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1403 = add <8 x i64> %1402, splat (i64 224)
  %1404 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1401, 0
  %1405 = insertvalue { <8 x ptr>, <8 x i64> } %1404, <8 x i64> %1403, 1
  %1406 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %1405, 1
  %1408 = extractelement <8 x ptr> %1406, i32 0
  %1409 = extractelement <8 x i64> %1407, i32 0
  %1410 = sub i64 %1409, 0
  %1411 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1412 = select i1 %1411, i64 %1410, i64 0
  %private.contiguous.address698 = getelementptr i8, ptr %1408, i64 %1412
  %private.contiguous.preserve699 = load <8 x float>, ptr %private.contiguous.address698, align 4
  %1413 = select <8 x i1> %71, <8 x float> %1292, <8 x float> %private.contiguous.preserve699
  store <8 x float> %1413, ptr %private.contiguous.address698, align 4
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1416 = add <8 x i64> %1415, splat (i64 256)
  %1417 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1414, 0
  %1418 = insertvalue { <8 x ptr>, <8 x i64> } %1417, <8 x i64> %1416, 1
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %1418, 1
  %1421 = extractelement <8 x ptr> %1419, i32 0
  %1422 = extractelement <8 x i64> %1420, i32 0
  %1423 = sub i64 %1422, 0
  %1424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1425 = select i1 %1424, i64 %1423, i64 0
  %private.contiguous.address700 = getelementptr i8, ptr %1421, i64 %1425
  %private.contiguous.preserve701 = load <8 x float>, ptr %private.contiguous.address700, align 4
  %1426 = select <8 x i1> %71, <8 x float> %1293, <8 x float> %private.contiguous.preserve701
  store <8 x float> %1426, ptr %private.contiguous.address700, align 4
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1429 = add <8 x i64> %1428, splat (i64 288)
  %1430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1427, 0
  %1431 = insertvalue { <8 x ptr>, <8 x i64> } %1430, <8 x i64> %1429, 1
  %1432 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %1431, 1
  %1434 = extractelement <8 x ptr> %1432, i32 0
  %1435 = extractelement <8 x i64> %1433, i32 0
  %1436 = sub i64 %1435, 0
  %1437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1438 = select i1 %1437, i64 %1436, i64 0
  %private.contiguous.address702 = getelementptr i8, ptr %1434, i64 %1438
  %private.contiguous.preserve703 = load <8 x float>, ptr %private.contiguous.address702, align 4
  %1439 = select <8 x i1> %71, <8 x float> %1294, <8 x float> %private.contiguous.preserve703
  store <8 x float> %1439, ptr %private.contiguous.address702, align 4
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1442 = add <8 x i64> %1441, splat (i64 320)
  %1443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1440, 0
  %1444 = insertvalue { <8 x ptr>, <8 x i64> } %1443, <8 x i64> %1442, 1
  %1445 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1446 = extractvalue { <8 x ptr>, <8 x i64> } %1444, 1
  %1447 = extractelement <8 x ptr> %1445, i32 0
  %1448 = extractelement <8 x i64> %1446, i32 0
  %1449 = sub i64 %1448, 0
  %1450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1451 = select i1 %1450, i64 %1449, i64 0
  %private.contiguous.address704 = getelementptr i8, ptr %1447, i64 %1451
  %private.contiguous.preserve705 = load <8 x float>, ptr %private.contiguous.address704, align 4
  %1452 = select <8 x i1> %71, <8 x float> %1295, <8 x float> %private.contiguous.preserve705
  store <8 x float> %1452, ptr %private.contiguous.address704, align 4
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1455 = add <8 x i64> %1454, splat (i64 352)
  %1456 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1453, 0
  %1457 = insertvalue { <8 x ptr>, <8 x i64> } %1456, <8 x i64> %1455, 1
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %1457, 1
  %1460 = extractelement <8 x ptr> %1458, i32 0
  %1461 = extractelement <8 x i64> %1459, i32 0
  %1462 = sub i64 %1461, 0
  %1463 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1464 = select i1 %1463, i64 %1462, i64 0
  %private.contiguous.address706 = getelementptr i8, ptr %1460, i64 %1464
  %private.contiguous.preserve707 = load <8 x float>, ptr %private.contiguous.address706, align 4
  %1465 = select <8 x i1> %71, <8 x float> %1296, <8 x float> %private.contiguous.preserve707
  store <8 x float> %1465, ptr %private.contiguous.address706, align 4
  %1466 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1467 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1468 = add <8 x i64> %1467, splat (i64 384)
  %1469 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1466, 0
  %1470 = insertvalue { <8 x ptr>, <8 x i64> } %1469, <8 x i64> %1468, 1
  %1471 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %1470, 1
  %1473 = extractelement <8 x ptr> %1471, i32 0
  %1474 = extractelement <8 x i64> %1472, i32 0
  %1475 = sub i64 %1474, 0
  %1476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1477 = select i1 %1476, i64 %1475, i64 0
  %private.contiguous.address708 = getelementptr i8, ptr %1473, i64 %1477
  %private.contiguous.preserve709 = load <8 x float>, ptr %private.contiguous.address708, align 4
  %1478 = select <8 x i1> %71, <8 x float> %1297, <8 x float> %private.contiguous.preserve709
  store <8 x float> %1478, ptr %private.contiguous.address708, align 4
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1480 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1481 = add <8 x i64> %1480, splat (i64 416)
  %1482 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1479, 0
  %1483 = insertvalue { <8 x ptr>, <8 x i64> } %1482, <8 x i64> %1481, 1
  %1484 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %1483, 1
  %1486 = extractelement <8 x ptr> %1484, i32 0
  %1487 = extractelement <8 x i64> %1485, i32 0
  %1488 = sub i64 %1487, 0
  %1489 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1490 = select i1 %1489, i64 %1488, i64 0
  %private.contiguous.address710 = getelementptr i8, ptr %1486, i64 %1490
  %private.contiguous.preserve711 = load <8 x float>, ptr %private.contiguous.address710, align 4
  %1491 = select <8 x i1> %71, <8 x float> %1298, <8 x float> %private.contiguous.preserve711
  store <8 x float> %1491, ptr %private.contiguous.address710, align 4
  %1492 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1493 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1494 = add <8 x i64> %1493, splat (i64 448)
  %1495 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1492, 0
  %1496 = insertvalue { <8 x ptr>, <8 x i64> } %1495, <8 x i64> %1494, 1
  %1497 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1498 = extractvalue { <8 x ptr>, <8 x i64> } %1496, 1
  %1499 = extractelement <8 x ptr> %1497, i32 0
  %1500 = extractelement <8 x i64> %1498, i32 0
  %1501 = sub i64 %1500, 0
  %1502 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1503 = select i1 %1502, i64 %1501, i64 0
  %private.contiguous.address712 = getelementptr i8, ptr %1499, i64 %1503
  %private.contiguous.preserve713 = load <8 x float>, ptr %private.contiguous.address712, align 4
  %1504 = select <8 x i1> %71, <8 x float> %1299, <8 x float> %private.contiguous.preserve713
  store <8 x float> %1504, ptr %private.contiguous.address712, align 4
  %1505 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1506 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1507 = add <8 x i64> %1506, splat (i64 480)
  %1508 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1505, 0
  %1509 = insertvalue { <8 x ptr>, <8 x i64> } %1508, <8 x i64> %1507, 1
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %1509, 1
  %1512 = extractelement <8 x ptr> %1510, i32 0
  %1513 = extractelement <8 x i64> %1511, i32 0
  %1514 = sub i64 %1513, 0
  %1515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1516 = select i1 %1515, i64 %1514, i64 0
  %private.contiguous.address714 = getelementptr i8, ptr %1512, i64 %1516
  %private.contiguous.preserve715 = load <8 x float>, ptr %private.contiguous.address714, align 4
  %1517 = select <8 x i1> %71, <8 x float> %1300, <8 x float> %private.contiguous.preserve715
  store <8 x float> %1517, ptr %private.contiguous.address714, align 4
  %.state716 = load <8 x float>, ptr %.slot36, align 32
  %1518 = fmul <8 x float> %.state716, %native.exp
  %1519 = load <8 x float>, ptr %.spill117, align 32
  %1520 = select <8 x i1> %71, <8 x float> %1518, <8 x float> %1519
  store <8 x float> %1520, ptr %.spill117, align 32
  store i64 0, ptr %.slot118, align 4
  %1521 = load <8 x float>, ptr %.slot119, align 32
  %1522 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1521
  store <8 x float> %1522, ptr %.slot119, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state717 = load i64, ptr %.slot118, align 4
  %1523 = icmp slt i64 %.state717, 16
  br i1 %1523, label %direct.true718, label %direct.false719

direct.schedule.71:                               ; preds = %direct.true718
  %.state720 = load i64, ptr %.slot118, align 4
  %1524 = sdiv i64 %.state720, 1
  %.spill.load721 = load i64, ptr %.spill78, align 4
  %1525 = mul i64 %.spill.load721, 1
  %1526 = add i64 %1525, 0
  %1527 = mul i64 %1526, 1
  %1528 = add i64 %1527, 0
  %1529 = mul i64 %1528, 16
  %1530 = add i64 %1529, %1524
  %tile_snapshot.spill.load722 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load722, 0
  %1532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load722, 1
  %.splatinsert723 = insertelement <8 x i64> poison, i64 %1530, i64 0
  %.splat724 = shufflevector <8 x i64> %.splatinsert723, <8 x i64> poison, <8 x i32> zeroinitializer
  %1533 = mul <8 x i64> %.splat724, splat (i64 32)
  %1534 = add <8 x i64> %1532, %1533
  %1535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1531, 0
  %1536 = insertvalue { <8 x ptr>, <8 x i64> } %1535, <8 x i64> %1534, 1
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %1536, 1
  %1539 = extractelement <8 x ptr> %1537, i32 0
  %1540 = extractelement <8 x i64> %1538, i32 0
  %1541 = sub i64 %1540, 0
  %1542 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1543 = select i1 %1542, i64 %1541, i64 0
  %private.contiguous.address725 = getelementptr i8, ptr %1539, i64 %1543
  %private.contiguous.load726 = load <8 x float>, ptr %private.contiguous.address725, align 4
  %1544 = select <8 x i1> %71, <8 x float> %private.contiguous.load726, <8 x float> zeroinitializer
  %.state727 = load <8 x float>, ptr %.slot119, align 32
  %1545 = fadd <8 x float> %.state727, %1544
  %.state728 = load i64, ptr %.slot118, align 4
  %1546 = add i64 %.state728, 1
  store i64 %1546, ptr %.slot118, align 4
  %1547 = load <8 x float>, ptr %.slot119, align 32
  %1548 = select <8 x i1> %71, <8 x float> %1545, <8 x float> %1547
  store <8 x float> %1548, ptr %.slot119, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false719
  %.spill.load729 = load <8 x float>, ptr %.spill117, align 32
  %.state730 = load <8 x float>, ptr %.slot119, align 32
  %1549 = fadd <8 x float> %.spill.load729, %.state730
  %1550 = load <8 x float>, ptr %.spill120, align 32
  %1551 = select <8 x i1> %71, <8 x float> %1549, <8 x float> %1550
  store <8 x float> %1551, ptr %.spill120, align 32
  %1552 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1553 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %1552, 0
  %1555 = select <8 x i1> %71, <8 x ptr> %1553, <8 x ptr> %1554
  %1556 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1557 = extractvalue { <8 x ptr>, <8 x i64> } %1552, 1
  %1558 = select <8 x i1> %71, <8 x i64> %1556, <8 x i64> %1557
  %1559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1555, 0
  %1560 = insertvalue { <8 x ptr>, <8 x i64> } %1559, <8 x i64> %1558, 1
  store { <8 x ptr>, <8 x i64> } %1560, ptr %tile_snapshot.spill121, align 64
  store i64 0, ptr %.slot122, align 4
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.77, %direct.schedule.72
  %.state731 = load i64, ptr %.slot122, align 4
  %1561 = icmp slt i64 %.state731, 24
  br i1 %1561, label %direct.true732, label %direct.false733

direct.schedule.74:                               ; preds = %direct.true732
  %.state734 = load i64, ptr %.slot122, align 4
  %1562 = mul i64 %.state734, 4
  %1563 = add i64 0, %1562
  %1564 = add i64 %1563, 0
  store i64 %1564, ptr %.spill123, align 4
  %1565 = add i64 0, %1564
  %tile_snapshot.spill.load735 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1566 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load735, 0
  %1567 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load735, 1
  %.splatinsert736 = insertelement <8 x i64> poison, i64 %1565, i64 0
  %.splat737 = shufflevector <8 x i64> %.splatinsert736, <8 x i64> poison, <8 x i32> zeroinitializer
  %1568 = mul <8 x i64> %.splat737, splat (i64 32)
  %1569 = add <8 x i64> %1567, %1568
  %1570 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1566, 0
  %1571 = insertvalue { <8 x ptr>, <8 x i64> } %1570, <8 x i64> %1569, 1
  %1572 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %1571, 1
  %1574 = extractelement <8 x ptr> %1572, i32 0
  %1575 = extractelement <8 x i64> %1573, i32 0
  %1576 = sub i64 %1575, 0
  %1577 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1578 = select i1 %1577, i64 %1576, i64 0
  %private.contiguous.address738 = getelementptr i8, ptr %1574, i64 %1578
  %private.contiguous.load739 = load <8 x float>, ptr %private.contiguous.address738, align 4
  %1579 = select <8 x i1> %71, <8 x float> %private.contiguous.load739, <8 x float> zeroinitializer
  %.spill.load740 = load <8 x float>, ptr %.spill115, align 32
  %1580 = fmul <8 x float> %1579, %.spill.load740
  %1581 = add i64 %1563, 1
  store i64 %1581, ptr %.spill124, align 4
  %1582 = add i64 0, %1581
  %tile_snapshot.spill.load741 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 0
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 1
  %.splatinsert742 = insertelement <8 x i64> poison, i64 %1582, i64 0
  %.splat743 = shufflevector <8 x i64> %.splatinsert742, <8 x i64> poison, <8 x i32> zeroinitializer
  %1585 = mul <8 x i64> %.splat743, splat (i64 32)
  %1586 = add <8 x i64> %1584, %1585
  %1587 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1583, 0
  %1588 = insertvalue { <8 x ptr>, <8 x i64> } %1587, <8 x i64> %1586, 1
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1590 = extractvalue { <8 x ptr>, <8 x i64> } %1588, 1
  %1591 = extractelement <8 x ptr> %1589, i32 0
  %1592 = extractelement <8 x i64> %1590, i32 0
  %1593 = sub i64 %1592, 0
  %1594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1595 = select i1 %1594, i64 %1593, i64 0
  %private.contiguous.address744 = getelementptr i8, ptr %1591, i64 %1595
  %private.contiguous.load745 = load <8 x float>, ptr %private.contiguous.address744, align 4
  %1596 = select <8 x i1> %71, <8 x float> %private.contiguous.load745, <8 x float> zeroinitializer
  %.spill.load746 = load <8 x float>, ptr %.spill115, align 32
  %1597 = fmul <8 x float> %1596, %.spill.load746
  %1598 = add i64 %1563, 2
  store i64 %1598, ptr %.spill125, align 4
  %1599 = add i64 0, %1598
  %tile_snapshot.spill.load747 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1600 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 0
  %1601 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 1
  %.splatinsert748 = insertelement <8 x i64> poison, i64 %1599, i64 0
  %.splat749 = shufflevector <8 x i64> %.splatinsert748, <8 x i64> poison, <8 x i32> zeroinitializer
  %1602 = mul <8 x i64> %.splat749, splat (i64 32)
  %1603 = add <8 x i64> %1601, %1602
  %1604 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1600, 0
  %1605 = insertvalue { <8 x ptr>, <8 x i64> } %1604, <8 x i64> %1603, 1
  %1606 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1607 = extractvalue { <8 x ptr>, <8 x i64> } %1605, 1
  %1608 = extractelement <8 x ptr> %1606, i32 0
  %1609 = extractelement <8 x i64> %1607, i32 0
  %1610 = sub i64 %1609, 0
  %1611 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1612 = select i1 %1611, i64 %1610, i64 0
  %private.contiguous.address750 = getelementptr i8, ptr %1608, i64 %1612
  %private.contiguous.load751 = load <8 x float>, ptr %private.contiguous.address750, align 4
  %1613 = select <8 x i1> %71, <8 x float> %private.contiguous.load751, <8 x float> zeroinitializer
  %.spill.load752 = load <8 x float>, ptr %.spill115, align 32
  %1614 = fmul <8 x float> %1613, %.spill.load752
  %1615 = add i64 %1563, 3
  store i64 %1615, ptr %.spill126, align 4
  %1616 = add i64 0, %1615
  %tile_snapshot.spill.load753 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1617 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load753, 0
  %1618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load753, 1
  %.splatinsert754 = insertelement <8 x i64> poison, i64 %1616, i64 0
  %.splat755 = shufflevector <8 x i64> %.splatinsert754, <8 x i64> poison, <8 x i32> zeroinitializer
  %1619 = mul <8 x i64> %.splat755, splat (i64 32)
  %1620 = add <8 x i64> %1618, %1619
  %1621 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1617, 0
  %1622 = insertvalue { <8 x ptr>, <8 x i64> } %1621, <8 x i64> %1620, 1
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %1622, 1
  %1625 = extractelement <8 x ptr> %1623, i32 0
  %1626 = extractelement <8 x i64> %1624, i32 0
  %1627 = sub i64 %1626, 0
  %1628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1629 = select i1 %1628, i64 %1627, i64 0
  %private.contiguous.address756 = getelementptr i8, ptr %1625, i64 %1629
  %private.contiguous.load757 = load <8 x float>, ptr %private.contiguous.address756, align 4
  %1630 = select <8 x i1> %71, <8 x float> %private.contiguous.load757, <8 x float> zeroinitializer
  %.spill.load758 = load <8 x float>, ptr %.spill115, align 32
  %1631 = fmul <8 x float> %1630, %.spill.load758
  store i64 0, ptr %.slot127, align 4
  %1632 = load <8 x float>, ptr %.slot128, align 32
  %1633 = select <8 x i1> %71, <8 x float> %1580, <8 x float> %1632
  store <8 x float> %1633, ptr %.slot128, align 32
  %1634 = load <8 x float>, ptr %.slot129, align 32
  %1635 = select <8 x i1> %71, <8 x float> %1597, <8 x float> %1634
  store <8 x float> %1635, ptr %.slot129, align 32
  %1636 = load <8 x float>, ptr %.slot130, align 32
  %1637 = select <8 x i1> %71, <8 x float> %1614, <8 x float> %1636
  store <8 x float> %1637, ptr %.slot130, align 32
  %1638 = load <8 x float>, ptr %.slot131, align 32
  %1639 = select <8 x i1> %71, <8 x float> %1631, <8 x float> %1638
  store <8 x float> %1639, ptr %.slot131, align 32
  br label %direct.schedule.75

direct.schedule.75:                               ; preds = %direct.schedule.76, %direct.schedule.74
  %.state759 = load i64, ptr %.slot127, align 4
  %1640 = icmp slt i64 %.state759, 16
  br i1 %1640, label %direct.true760, label %direct.false761

direct.schedule.76:                               ; preds = %direct.true760
  %.state762 = load i64, ptr %.slot127, align 4
  %1641 = add i64 0, %.state762
  %tile_snapshot.spill.load763 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %1643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %.splatinsert764 = insertelement <8 x i64> poison, i64 %1641, i64 0
  %.splat765 = shufflevector <8 x i64> %.splatinsert764, <8 x i64> poison, <8 x i32> zeroinitializer
  %1644 = mul <8 x i64> %.splat765, splat (i64 32)
  %1645 = add <8 x i64> %1643, %1644
  %1646 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1642, 0
  %1647 = insertvalue { <8 x ptr>, <8 x i64> } %1646, <8 x i64> %1645, 1
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1649 = extractvalue { <8 x ptr>, <8 x i64> } %1647, 1
  %1650 = extractelement <8 x ptr> %1648, i32 0
  %1651 = extractelement <8 x i64> %1649, i32 0
  %1652 = sub i64 %1651, 0
  %1653 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1654 = select i1 %1653, i64 %1652, i64 0
  %private.contiguous.address766 = getelementptr i8, ptr %1650, i64 %1654
  %private.contiguous.load767 = load <8 x float>, ptr %private.contiguous.address766, align 4
  %1655 = select <8 x i1> %71, <8 x float> %private.contiguous.load767, <8 x float> zeroinitializer
  %1656 = mul i64 %1641, 96
  %.spill.load768 = load i64, ptr %.spill123, align 4
  %1657 = add i64 %1656, %.spill.load768
  %tile_snapshot.spill.load769 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 0
  %1659 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 1
  %.splatinsert770 = insertelement <8 x i64> poison, i64 %1657, i64 0
  %.splat771 = shufflevector <8 x i64> %.splatinsert770, <8 x i64> poison, <8 x i32> zeroinitializer
  %1660 = mul <8 x i64> %.splat771, splat (i64 32)
  %1661 = add <8 x i64> %1659, %1660
  %1662 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1658, 0
  %1663 = insertvalue { <8 x ptr>, <8 x i64> } %1662, <8 x i64> %1661, 1
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1665 = extractvalue { <8 x ptr>, <8 x i64> } %1663, 1
  %1666 = extractelement <8 x ptr> %1664, i32 0
  %1667 = extractelement <8 x i64> %1665, i32 0
  %1668 = sub i64 %1667, 0
  %1669 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1670 = select i1 %1669, i64 %1668, i64 0
  %private.contiguous.address772 = getelementptr i8, ptr %1666, i64 %1670
  %private.contiguous.load773 = load <8 x float>, ptr %private.contiguous.address772, align 4
  %1671 = select <8 x i1> %71, <8 x float> %private.contiguous.load773, <8 x float> zeroinitializer
  %1672 = fmul <8 x float> %1655, %1671
  %.state774 = load <8 x float>, ptr %.slot128, align 32
  %1673 = fadd <8 x float> %.state774, %1672
  %.spill.load775 = load i64, ptr %.spill124, align 4
  %1674 = add i64 %1656, %.spill.load775
  %tile_snapshot.spill.load776 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1675 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 0
  %1676 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 1
  %.splatinsert777 = insertelement <8 x i64> poison, i64 %1674, i64 0
  %.splat778 = shufflevector <8 x i64> %.splatinsert777, <8 x i64> poison, <8 x i32> zeroinitializer
  %1677 = mul <8 x i64> %.splat778, splat (i64 32)
  %1678 = add <8 x i64> %1676, %1677
  %1679 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1675, 0
  %1680 = insertvalue { <8 x ptr>, <8 x i64> } %1679, <8 x i64> %1678, 1
  %1681 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1682 = extractvalue { <8 x ptr>, <8 x i64> } %1680, 1
  %1683 = extractelement <8 x ptr> %1681, i32 0
  %1684 = extractelement <8 x i64> %1682, i32 0
  %1685 = sub i64 %1684, 0
  %1686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1687 = select i1 %1686, i64 %1685, i64 0
  %private.contiguous.address779 = getelementptr i8, ptr %1683, i64 %1687
  %private.contiguous.load780 = load <8 x float>, ptr %private.contiguous.address779, align 4
  %1688 = select <8 x i1> %71, <8 x float> %private.contiguous.load780, <8 x float> zeroinitializer
  %1689 = fmul <8 x float> %1655, %1688
  %.state781 = load <8 x float>, ptr %.slot129, align 32
  %1690 = fadd <8 x float> %.state781, %1689
  %.spill.load782 = load i64, ptr %.spill125, align 4
  %1691 = add i64 %1656, %.spill.load782
  %tile_snapshot.spill.load783 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load783, 0
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load783, 1
  %.splatinsert784 = insertelement <8 x i64> poison, i64 %1691, i64 0
  %.splat785 = shufflevector <8 x i64> %.splatinsert784, <8 x i64> poison, <8 x i32> zeroinitializer
  %1694 = mul <8 x i64> %.splat785, splat (i64 32)
  %1695 = add <8 x i64> %1693, %1694
  %1696 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1692, 0
  %1697 = insertvalue { <8 x ptr>, <8 x i64> } %1696, <8 x i64> %1695, 1
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %1697, 1
  %1700 = extractelement <8 x ptr> %1698, i32 0
  %1701 = extractelement <8 x i64> %1699, i32 0
  %1702 = sub i64 %1701, 0
  %1703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1704 = select i1 %1703, i64 %1702, i64 0
  %private.contiguous.address786 = getelementptr i8, ptr %1700, i64 %1704
  %private.contiguous.load787 = load <8 x float>, ptr %private.contiguous.address786, align 4
  %1705 = select <8 x i1> %71, <8 x float> %private.contiguous.load787, <8 x float> zeroinitializer
  %1706 = fmul <8 x float> %1655, %1705
  %.state788 = load <8 x float>, ptr %.slot130, align 32
  %1707 = fadd <8 x float> %.state788, %1706
  %.spill.load789 = load i64, ptr %.spill126, align 4
  %1708 = add i64 %1656, %.spill.load789
  %tile_snapshot.spill.load790 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 0
  %1710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 1
  %.splatinsert791 = insertelement <8 x i64> poison, i64 %1708, i64 0
  %.splat792 = shufflevector <8 x i64> %.splatinsert791, <8 x i64> poison, <8 x i32> zeroinitializer
  %1711 = mul <8 x i64> %.splat792, splat (i64 32)
  %1712 = add <8 x i64> %1710, %1711
  %1713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1709, 0
  %1714 = insertvalue { <8 x ptr>, <8 x i64> } %1713, <8 x i64> %1712, 1
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1716 = extractvalue { <8 x ptr>, <8 x i64> } %1714, 1
  %1717 = extractelement <8 x ptr> %1715, i32 0
  %1718 = extractelement <8 x i64> %1716, i32 0
  %1719 = sub i64 %1718, 0
  %1720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1721 = select i1 %1720, i64 %1719, i64 0
  %private.contiguous.address793 = getelementptr i8, ptr %1717, i64 %1721
  %private.contiguous.load794 = load <8 x float>, ptr %private.contiguous.address793, align 4
  %1722 = select <8 x i1> %71, <8 x float> %private.contiguous.load794, <8 x float> zeroinitializer
  %1723 = fmul <8 x float> %1655, %1722
  %.state795 = load <8 x float>, ptr %.slot131, align 32
  %1724 = fadd <8 x float> %.state795, %1723
  %.state796 = load i64, ptr %.slot127, align 4
  %1725 = add i64 %.state796, 1
  store i64 %1725, ptr %.slot127, align 4
  %1726 = load <8 x float>, ptr %.slot128, align 32
  %1727 = select <8 x i1> %71, <8 x float> %1673, <8 x float> %1726
  store <8 x float> %1727, ptr %.slot128, align 32
  %1728 = load <8 x float>, ptr %.slot129, align 32
  %1729 = select <8 x i1> %71, <8 x float> %1690, <8 x float> %1728
  store <8 x float> %1729, ptr %.slot129, align 32
  %1730 = load <8 x float>, ptr %.slot130, align 32
  %1731 = select <8 x i1> %71, <8 x float> %1707, <8 x float> %1730
  store <8 x float> %1731, ptr %.slot130, align 32
  %1732 = load <8 x float>, ptr %.slot131, align 32
  %1733 = select <8 x i1> %71, <8 x float> %1724, <8 x float> %1732
  store <8 x float> %1733, ptr %.slot131, align 32
  br label %direct.schedule.75

direct.schedule.77:                               ; preds = %direct.false761
  %tile_snapshot.spill.load797 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1734 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load797, 0
  %1735 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load797, 1
  %.spill.load798 = load i64, ptr %.spill123, align 4
  %.splatinsert799 = insertelement <8 x i64> poison, i64 %.spill.load798, i64 0
  %.splat800 = shufflevector <8 x i64> %.splatinsert799, <8 x i64> poison, <8 x i32> zeroinitializer
  %1736 = mul <8 x i64> %.splat800, splat (i64 32)
  %1737 = add <8 x i64> %1735, %1736
  %1738 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1734, 0
  %1739 = insertvalue { <8 x ptr>, <8 x i64> } %1738, <8 x i64> %1737, 1
  %.state801 = load <8 x float>, ptr %.slot128, align 32
  %1740 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1741 = extractvalue { <8 x ptr>, <8 x i64> } %1739, 1
  %1742 = extractelement <8 x ptr> %1740, i32 0
  %1743 = extractelement <8 x i64> %1741, i32 0
  %1744 = sub i64 %1743, 0
  %1745 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1746 = select i1 %1745, i64 %1744, i64 0
  %private.contiguous.address802 = getelementptr i8, ptr %1742, i64 %1746
  %private.contiguous.preserve803 = load <8 x float>, ptr %private.contiguous.address802, align 4
  %1747 = select <8 x i1> %71, <8 x float> %.state801, <8 x float> %private.contiguous.preserve803
  store <8 x float> %1747, ptr %private.contiguous.address802, align 4
  %tile_snapshot.spill.load804 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 0
  %1749 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 1
  %.spill.load805 = load i64, ptr %.spill124, align 4
  %.splatinsert806 = insertelement <8 x i64> poison, i64 %.spill.load805, i64 0
  %.splat807 = shufflevector <8 x i64> %.splatinsert806, <8 x i64> poison, <8 x i32> zeroinitializer
  %1750 = mul <8 x i64> %.splat807, splat (i64 32)
  %1751 = add <8 x i64> %1749, %1750
  %1752 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1748, 0
  %1753 = insertvalue { <8 x ptr>, <8 x i64> } %1752, <8 x i64> %1751, 1
  %.state808 = load <8 x float>, ptr %.slot129, align 32
  %1754 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1755 = extractvalue { <8 x ptr>, <8 x i64> } %1753, 1
  %1756 = extractelement <8 x ptr> %1754, i32 0
  %1757 = extractelement <8 x i64> %1755, i32 0
  %1758 = sub i64 %1757, 0
  %1759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1760 = select i1 %1759, i64 %1758, i64 0
  %private.contiguous.address809 = getelementptr i8, ptr %1756, i64 %1760
  %private.contiguous.preserve810 = load <8 x float>, ptr %private.contiguous.address809, align 4
  %1761 = select <8 x i1> %71, <8 x float> %.state808, <8 x float> %private.contiguous.preserve810
  store <8 x float> %1761, ptr %private.contiguous.address809, align 4
  %tile_snapshot.spill.load811 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1762 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load811, 0
  %1763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load811, 1
  %.spill.load812 = load i64, ptr %.spill125, align 4
  %.splatinsert813 = insertelement <8 x i64> poison, i64 %.spill.load812, i64 0
  %.splat814 = shufflevector <8 x i64> %.splatinsert813, <8 x i64> poison, <8 x i32> zeroinitializer
  %1764 = mul <8 x i64> %.splat814, splat (i64 32)
  %1765 = add <8 x i64> %1763, %1764
  %1766 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1762, 0
  %1767 = insertvalue { <8 x ptr>, <8 x i64> } %1766, <8 x i64> %1765, 1
  %.state815 = load <8 x float>, ptr %.slot130, align 32
  %1768 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1769 = extractvalue { <8 x ptr>, <8 x i64> } %1767, 1
  %1770 = extractelement <8 x ptr> %1768, i32 0
  %1771 = extractelement <8 x i64> %1769, i32 0
  %1772 = sub i64 %1771, 0
  %1773 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1774 = select i1 %1773, i64 %1772, i64 0
  %private.contiguous.address816 = getelementptr i8, ptr %1770, i64 %1774
  %private.contiguous.preserve817 = load <8 x float>, ptr %private.contiguous.address816, align 4
  %1775 = select <8 x i1> %71, <8 x float> %.state815, <8 x float> %private.contiguous.preserve817
  store <8 x float> %1775, ptr %private.contiguous.address816, align 4
  %tile_snapshot.spill.load818 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 0
  %1777 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 1
  %.spill.load819 = load i64, ptr %.spill126, align 4
  %.splatinsert820 = insertelement <8 x i64> poison, i64 %.spill.load819, i64 0
  %.splat821 = shufflevector <8 x i64> %.splatinsert820, <8 x i64> poison, <8 x i32> zeroinitializer
  %1778 = mul <8 x i64> %.splat821, splat (i64 32)
  %1779 = add <8 x i64> %1777, %1778
  %1780 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1776, 0
  %1781 = insertvalue { <8 x ptr>, <8 x i64> } %1780, <8 x i64> %1779, 1
  %.state822 = load <8 x float>, ptr %.slot131, align 32
  %1782 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1783 = extractvalue { <8 x ptr>, <8 x i64> } %1781, 1
  %1784 = extractelement <8 x ptr> %1782, i32 0
  %1785 = extractelement <8 x i64> %1783, i32 0
  %1786 = sub i64 %1785, 0
  %1787 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1788 = select i1 %1787, i64 %1786, i64 0
  %private.contiguous.address823 = getelementptr i8, ptr %1784, i64 %1788
  %private.contiguous.preserve824 = load <8 x float>, ptr %private.contiguous.address823, align 4
  %1789 = select <8 x i1> %71, <8 x float> %.state822, <8 x float> %private.contiguous.preserve824
  store <8 x float> %1789, ptr %private.contiguous.address823, align 4
  %.state825 = load i64, ptr %.slot122, align 4
  %1790 = add i64 %.state825, 1
  store i64 %1790, ptr %.slot122, align 4
  br label %direct.schedule.73

direct.schedule.78:                               ; preds = %direct.false733
  store i64 0, ptr %.slot132, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state826 = load i64, ptr %.slot132, align 4
  %1791 = icmp slt i64 %.state826, 96
  br i1 %1791, label %direct.true827, label %direct.false828

direct.schedule.80:                               ; preds = %direct.true827
  %tile_snapshot.spill.load829 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1792 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load829, 0
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load829, 1
  %.state830 = load i64, ptr %.slot132, align 4
  %.splatinsert831 = insertelement <8 x i64> poison, i64 %.state830, i64 0
  %.splat832 = shufflevector <8 x i64> %.splatinsert831, <8 x i64> poison, <8 x i32> zeroinitializer
  %1794 = mul <8 x i64> %.splat832, splat (i64 32)
  %1795 = add <8 x i64> %1793, %1794
  %1796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1792, 0
  %1797 = insertvalue { <8 x ptr>, <8 x i64> } %1796, <8 x i64> %1795, 1
  %1798 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1799 = extractvalue { <8 x ptr>, <8 x i64> } %1797, 1
  %1800 = extractelement <8 x ptr> %1798, i32 0
  %1801 = extractelement <8 x i64> %1799, i32 0
  %1802 = sub i64 %1801, 0
  %1803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1804 = select i1 %1803, i64 %1802, i64 0
  %private.contiguous.address833 = getelementptr i8, ptr %1800, i64 %1804
  %private.contiguous.load834 = load <8 x float>, ptr %private.contiguous.address833, align 4
  %1805 = select <8 x i1> %71, <8 x float> %private.contiguous.load834, <8 x float> zeroinitializer
  %tile_snapshot.spill.load835 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1806 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load835, 0
  %1807 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load835, 1
  %.state836 = load i64, ptr %.slot132, align 4
  %.splatinsert837 = insertelement <8 x i64> poison, i64 %.state836, i64 0
  %.splat838 = shufflevector <8 x i64> %.splatinsert837, <8 x i64> poison, <8 x i32> zeroinitializer
  %1808 = mul <8 x i64> %.splat838, splat (i64 32)
  %1809 = add <8 x i64> %1807, %1808
  %1810 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1806, 0
  %1811 = insertvalue { <8 x ptr>, <8 x i64> } %1810, <8 x i64> %1809, 1
  %1812 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1813 = extractvalue { <8 x ptr>, <8 x i64> } %1811, 1
  %1814 = extractelement <8 x ptr> %1812, i32 0
  %1815 = extractelement <8 x i64> %1813, i32 0
  %1816 = sub i64 %1815, 0
  %1817 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1818 = select i1 %1817, i64 %1816, i64 0
  %private.contiguous.address839 = getelementptr i8, ptr %1814, i64 %1818
  %private.contiguous.preserve840 = load <8 x float>, ptr %private.contiguous.address839, align 4
  %1819 = select <8 x i1> %71, <8 x float> %1805, <8 x float> %private.contiguous.preserve840
  store <8 x float> %1819, ptr %private.contiguous.address839, align 4
  %.state841 = load i64, ptr %.slot132, align 4
  %1820 = add i64 %.state841, 1
  store i64 %1820, ptr %.slot132, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false828
  store i64 0, ptr %.slot133, align 4
  br label %direct.schedule.82

direct.schedule.82:                               ; preds = %direct.schedule.83, %direct.schedule.81
  %.state842 = load i64, ptr %.slot133, align 4
  %1821 = icmp slt i64 %.state842, 96
  br i1 %1821, label %direct.true843, label %direct.false844

direct.schedule.83:                               ; preds = %direct.true843
  %tile_snapshot.spill.load845 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1822 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load845, 0
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load845, 1
  %.state846 = load i64, ptr %.slot133, align 4
  %.splatinsert847 = insertelement <8 x i64> poison, i64 %.state846, i64 0
  %.splat848 = shufflevector <8 x i64> %.splatinsert847, <8 x i64> poison, <8 x i32> zeroinitializer
  %1824 = mul <8 x i64> %.splat848, splat (i64 32)
  %1825 = add <8 x i64> %1823, %1824
  %1826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1822, 0
  %1827 = insertvalue { <8 x ptr>, <8 x i64> } %1826, <8 x i64> %1825, 1
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1829 = extractvalue { <8 x ptr>, <8 x i64> } %1827, 1
  %1830 = extractelement <8 x ptr> %1828, i32 0
  %1831 = extractelement <8 x i64> %1829, i32 0
  %1832 = sub i64 %1831, 0
  %1833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1834 = select i1 %1833, i64 %1832, i64 0
  %private.contiguous.address849 = getelementptr i8, ptr %1830, i64 %1834
  %private.contiguous.load850 = load <8 x float>, ptr %private.contiguous.address849, align 4
  %1835 = select <8 x i1> %71, <8 x float> %private.contiguous.load850, <8 x float> zeroinitializer
  %tile_snapshot.spill.load851 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load851, 0
  %1837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load851, 1
  %.state852 = load i64, ptr %.slot133, align 4
  %.splatinsert853 = insertelement <8 x i64> poison, i64 %.state852, i64 0
  %.splat854 = shufflevector <8 x i64> %.splatinsert853, <8 x i64> poison, <8 x i32> zeroinitializer
  %1838 = mul <8 x i64> %.splat854, splat (i64 32)
  %1839 = add <8 x i64> %1837, %1838
  %1840 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1836, 0
  %1841 = insertvalue { <8 x ptr>, <8 x i64> } %1840, <8 x i64> %1839, 1
  %1842 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1843 = extractvalue { <8 x ptr>, <8 x i64> } %1841, 1
  %1844 = extractelement <8 x ptr> %1842, i32 0
  %1845 = extractelement <8 x i64> %1843, i32 0
  %1846 = sub i64 %1845, 0
  %1847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1848 = select i1 %1847, i64 %1846, i64 0
  %private.contiguous.address855 = getelementptr i8, ptr %1844, i64 %1848
  %private.contiguous.preserve856 = load <8 x float>, ptr %private.contiguous.address855, align 4
  %1849 = select <8 x i1> %71, <8 x float> %1835, <8 x float> %private.contiguous.preserve856
  store <8 x float> %1849, ptr %private.contiguous.address855, align 4
  %.state857 = load i64, ptr %.slot133, align 4
  %1850 = add i64 %.state857, 1
  store i64 %1850, ptr %.slot133, align 4
  br label %direct.schedule.82

direct.schedule.84:                               ; preds = %direct.false844
  %.state858 = load i64, ptr %.slot34, align 4
  %1851 = add i64 %.state858, 1
  %.spill.load859 = load <8 x float>, ptr %.spill114, align 32
  %.spill.load860 = load <8 x float>, ptr %.spill120, align 32
  store i64 %1851, ptr %.slot34, align 4
  %1852 = load <8 x float>, ptr %.slot35, align 32
  %1853 = select <8 x i1> %71, <8 x float> %.spill.load859, <8 x float> %1852
  store <8 x float> %1853, ptr %.slot35, align 32
  %1854 = load <8 x float>, ptr %.slot36, align 32
  %1855 = select <8 x i1> %71, <8 x float> %.spill.load860, <8 x float> %1854
  store <8 x float> %1855, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.85:                               ; preds = %direct.false170
  store i64 0, ptr %.slot134, align 4
  br label %direct.schedule.86

direct.schedule.86:                               ; preds = %direct.schedule.87, %direct.schedule.85
  %.state861 = load i64, ptr %.slot134, align 4
  %1856 = icmp slt i64 %.state861, 96
  br i1 %1856, label %direct.true862, label %direct.false863

direct.schedule.87:                               ; preds = %direct.true862
  %.spill.load864 = load i64, ptr %.spill29, align 4
  %1857 = add i64 %.spill.load864, 0
  %.spill.load865 = load <8 x i64>, ptr %.spill, align 64
  %1858 = add <8 x i64> %.spill.load865, zeroinitializer
  %1859 = mul i64 %1857, 6
  %.splatinsert866 = insertelement <8 x i64> poison, i64 %1859, i64 0
  %.splat867 = shufflevector <8 x i64> %.splatinsert866, <8 x i64> poison, <8 x i32> zeroinitializer
  %1860 = add <8 x i64> %.splat867, %1858
  %.spill.load868 = load i64, ptr %.spill29, align 4
  %1861 = add i64 %.spill.load868, 0
  %1862 = mul <8 x i64> %1860, splat (i64 1)
  %.splatinsert869 = insertelement <8 x i64> poison, i64 %1861, i64 0
  %.splat870 = shufflevector <8 x i64> %.splatinsert869, <8 x i64> poison, <8 x i32> zeroinitializer
  %1863 = add <8 x i64> %1862, %.splat870
  %.state871 = load i64, ptr %.slot134, align 4
  %1864 = add i64 0, %.state871
  %1865 = mul <8 x i64> %1863, splat (i64 96)
  %.splatinsert872 = insertelement <8 x i64> poison, i64 %1864, i64 0
  %.splat873 = shufflevector <8 x i64> %.splatinsert872, <8 x i64> poison, <8 x i32> zeroinitializer
  %1866 = add <8 x i64> %1865, %.splat873
  %.state874 = load i64, ptr %.slot134, align 4
  %1867 = add i64 0, %.state874
  %tile_snapshot.spill.load875 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1868 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load875, 0
  %1869 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load875, 1
  %.splatinsert876 = insertelement <8 x i64> poison, i64 %1867, i64 0
  %.splat877 = shufflevector <8 x i64> %.splatinsert876, <8 x i64> poison, <8 x i32> zeroinitializer
  %1870 = mul <8 x i64> %.splat877, splat (i64 32)
  %1871 = add <8 x i64> %1869, %1870
  %1872 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1868, 0
  %1873 = insertvalue { <8 x ptr>, <8 x i64> } %1872, <8 x i64> %1871, 1
  %1874 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1875 = extractvalue { <8 x ptr>, <8 x i64> } %1873, 1
  %1876 = extractelement <8 x ptr> %1874, i32 0
  %1877 = extractelement <8 x i64> %1875, i32 0
  %1878 = sub i64 %1877, 0
  %1879 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1880 = select i1 %1879, i64 %1878, i64 0
  %private.contiguous.address878 = getelementptr i8, ptr %1876, i64 %1880
  %private.contiguous.load879 = load <8 x float>, ptr %private.contiguous.address878, align 4
  %1881 = select <8 x i1> %71, <8 x float> %private.contiguous.load879, <8 x float> zeroinitializer
  %.state880 = load <8 x float>, ptr %.slot36, align 32
  %1882 = fdiv <8 x float> %1881, %.state880
  %1883 = extractvalue { ptr, i64 } %47, 0
  %1884 = mul <8 x i64> %1866, splat (i64 4)
  %1885 = getelementptr i8, ptr %1883, <8 x i64> %1884
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1882, <8 x ptr> align 1 %1885, <8 x i1> %71)
  %.state881 = load i64, ptr %.slot134, align 4
  %1886 = add i64 %.state881, 1
  store i64 %1886, ptr %.slot134, align 4
  br label %direct.schedule.86

direct.schedule.88:                               ; preds = %direct.false863
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true159:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false160:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true169:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false170:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.85

direct.true173:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false174:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true186:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false187:                                  ; preds = %direct.schedule.10
  %1887 = load <8 x float>, ptr %.slot41, align 32
  %1888 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1887
  store <8 x float> %1888, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.true198:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false199:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true211:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false212:                                  ; preds = %direct.schedule.15
  %1889 = load <8 x float>, ptr %.slot45, align 32
  %1890 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1889
  store <8 x float> %1890, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.true223:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false224:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true238:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false239:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true255:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false256:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true272:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false273:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true289:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false290:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true306:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false307:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true323:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false324:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true340:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false341:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true357:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false358:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true374:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false375:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true391:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false392:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true408:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false409:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true425:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false426:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true442:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false443:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true459:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false460:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true476:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false477:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true590:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false591:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true718:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false719:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true732:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false733:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.78

direct.true760:                                   ; preds = %direct.schedule.75
  br label %direct.schedule.76

direct.false761:                                  ; preds = %direct.schedule.75
  br label %direct.schedule.77

direct.true827:                                   ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false828:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.81

direct.true843:                                   ; preds = %direct.schedule.82
  br label %direct.schedule.83

direct.false844:                                  ; preds = %direct.schedule.82
  br label %direct.schedule.84

direct.true862:                                   ; preds = %direct.schedule.86
  br label %direct.schedule.87

direct.false863:                                  ; preds = %direct.schedule.86
  br label %direct.schedule.88
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #3 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #4

define internal void @llm_attention.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill31, align 64
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca i64, align 8
  store i64 0, ptr %.slot33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %tile_snapshot.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill42, align 64
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %.spill44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill44, align 64
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca i64, align 8
  store i64 0, ptr %.slot48, align 4
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca i64, align 8
  store i64 0, ptr %.slot50, align 4
  %.slot51 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca i64, align 8
  store i64 0, ptr %.slot52, align 4
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca i64, align 8
  store i64 0, ptr %.slot54, align 4
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca i64, align 8
  store i64 0, ptr %.slot58, align 4
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca i64, align 8
  store i64 0, ptr %.slot60, align 4
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca i64, align 8
  store i64 0, ptr %.slot62, align 4
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca i64, align 8
  store i64 0, ptr %.slot64, align 4
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.slot66 = alloca i64, align 8
  store i64 0, ptr %.slot66, align 4
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.slot68 = alloca i64, align 8
  store i64 0, ptr %.slot68, align 4
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca i64, align 8
  store i64 0, ptr %.slot70, align 4
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca i64, align 8
  store i64 0, ptr %.slot72, align 4
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca i64, align 8
  store i64 0, ptr %.slot74, align 4
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca i64, align 8
  store i64 0, ptr %.slot76, align 4
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.spill78 = alloca i64, align 8
  store i64 0, ptr %.spill78, align 4
  %.spill79 = alloca i1, align 1
  store i1 false, ptr %.spill79, align 1
  %.spill80 = alloca i1, align 1
  store i1 false, ptr %.spill80, align 1
  %.spill81 = alloca i1, align 1
  store i1 false, ptr %.spill81, align 1
  %.spill82 = alloca i1, align 1
  store i1 false, ptr %.spill82, align 1
  %.spill83 = alloca i1, align 1
  store i1 false, ptr %.spill83, align 1
  %.spill84 = alloca i1, align 1
  store i1 false, ptr %.spill84, align 1
  %.spill85 = alloca i1, align 1
  store i1 false, ptr %.spill85, align 1
  %.spill86 = alloca i1, align 1
  store i1 false, ptr %.spill86, align 1
  %.spill87 = alloca i1, align 1
  store i1 false, ptr %.spill87, align 1
  %.spill88 = alloca i1, align 1
  store i1 false, ptr %.spill88, align 1
  %.spill89 = alloca i1, align 1
  store i1 false, ptr %.spill89, align 1
  %.spill90 = alloca i1, align 1
  store i1 false, ptr %.spill90, align 1
  %.spill91 = alloca i1, align 1
  store i1 false, ptr %.spill91, align 1
  %.spill92 = alloca i1, align 1
  store i1 false, ptr %.spill92, align 1
  %.spill93 = alloca i1, align 1
  store i1 false, ptr %.spill93, align 1
  %.spill94 = alloca i1, align 1
  store i1 false, ptr %.spill94, align 1
  %.spill95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill100, align 32
  %.spill101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill103, align 32
  %.spill104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill104, align 32
  %.spill105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.spill106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill106, align 32
  %.spill107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill108, align 32
  %.spill109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill109, align 32
  %.spill110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill110, align 32
  %tile_snapshot.spill111 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill111, align 64
  %.slot112 = alloca i64, align 8
  store i64 0, ptr %.slot112, align 4
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.spill114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill114, align 32
  %.spill115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill115, align 32
  %tile_snapshot.spill116 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill116, align 64
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.slot118 = alloca i64, align 8
  store i64 0, ptr %.slot118, align 4
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %tile_snapshot.spill121 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill121, align 64
  %.slot122 = alloca i64, align 8
  store i64 0, ptr %.slot122, align 4
  %.spill123 = alloca i64, align 8
  store i64 0, ptr %.spill123, align 4
  %.spill124 = alloca i64, align 8
  store i64 0, ptr %.spill124, align 4
  %.spill125 = alloca i64, align 8
  store i64 0, ptr %.spill125, align 4
  %.spill126 = alloca i64, align 8
  store i64 0, ptr %.spill126, align 4
  %.slot127 = alloca i64, align 8
  store i64 0, ptr %.slot127, align 4
  %.slot128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot128, align 32
  %.slot129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot129, align 32
  %.slot130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot130, align 32
  %.slot131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot131, align 32
  %.slot132 = alloca i64, align 8
  store i64 0, ptr %.slot132, align 4
  %.slot133 = alloca i64, align 8
  store i64 0, ptr %.slot133, align 4
  %.slot134 = alloca i64, align 8
  store i64 0, ptr %.slot134, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert135 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat136 = shufflevector <8 x i32> %.splatinsert135, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat136, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert137 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat138 = shufflevector <8 x i32> %.splatinsert137, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat138, %61
  %64 = mul i32 %52, 1
  %.splatinsert139 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat140 = shufflevector <8 x i32> %.splatinsert139, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat140, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert141 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat142 = shufflevector <8 x i32> %.splatinsert141, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat142, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert143 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat144 = shufflevector <8 x i32> %.splatinsert143, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat144
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  store i64 0, ptr %.spill29, align 4
  %80 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 3), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = load <8 x i64>, ptr %.spill30, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill30, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %94 = icmp slt i64 %.state, 80
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load i64, ptr %.spill29, align 4
  %95 = add i64 %.spill.load, 0
  %.spill.load145 = load <8 x i64>, ptr %.spill, align 64
  %96 = add <8 x i64> %.spill.load145, zeroinitializer
  %97 = mul i64 %95, 6
  %.splatinsert146 = insertelement <8 x i64> poison, i64 %97, i64 0
  %.splat147 = shufflevector <8 x i64> %.splatinsert146, <8 x i64> poison, <8 x i32> zeroinitializer
  %98 = add <8 x i64> %.splat147, %96
  %.spill.load148 = load i64, ptr %.spill29, align 4
  %99 = add i64 %.spill.load148, 0
  %100 = mul <8 x i64> %98, splat (i64 1)
  %.splatinsert149 = insertelement <8 x i64> poison, i64 %99, i64 0
  %.splat150 = shufflevector <8 x i64> %.splatinsert149, <8 x i64> poison, <8 x i32> zeroinitializer
  %101 = add <8 x i64> %100, %.splat150
  %.state151 = load i64, ptr %.slot, align 4
  %102 = add i64 0, %.state151
  %103 = mul <8 x i64> %101, splat (i64 80)
  %.splatinsert152 = insertelement <8 x i64> poison, i64 %102, i64 0
  %.splat153 = shufflevector <8 x i64> %.splatinsert152, <8 x i64> poison, <8 x i32> zeroinitializer
  %104 = add <8 x i64> %103, %.splat153
  %105 = extractvalue { ptr, i64 } %29, 0
  %106 = mul <8 x i64> %104, splat (i64 4)
  %107 = getelementptr i8, ptr %105, <8 x i64> %106
  %108 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %107, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state154 = load i64, ptr %.slot, align 4
  %.splatinsert155 = insertelement <8 x i64> poison, i64 %.state154, i64 0
  %.splat156 = shufflevector <8 x i64> %.splatinsert155, <8 x i64> poison, <8 x i32> zeroinitializer
  %111 = mul <8 x i64> %.splat156, splat (i64 32)
  %112 = add <8 x i64> %110, %111
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %109, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %114, 1
  %117 = extractelement <8 x ptr> %115, i32 0
  %118 = extractelement <8 x i64> %116, i32 0
  %119 = sub i64 %118, 0
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %121 = select i1 %120, i64 %119, i64 0
  %private.contiguous.address = getelementptr i8, ptr %117, i64 %121
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %122 = select <8 x i1> %71, <8 x float> %108, <8 x float> %private.contiguous.preserve
  store <8 x float> %122, ptr %private.contiguous.address, align 4
  %.state157 = load i64, ptr %.slot, align 4
  %123 = add i64 %.state157, 1
  store i64 %123, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %71, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %71, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill31, align 64
  %133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 0
  %136 = select <8 x i1> %71, <8 x ptr> %134, <8 x ptr> %135
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %139 = select <8 x i1> %71, <8 x i64> %137, <8 x i64> %138
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  store { <8 x ptr>, <8 x i64> } %141, ptr %tile_snapshot.spill32, align 64
  store i64 0, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state158 = load i64, ptr %.slot33, align 4
  %142 = icmp slt i64 %.state158, 96
  br i1 %142, label %direct.true159, label %direct.false160

direct.schedule.5:                                ; preds = %direct.true159
  %tile_snapshot.spill.load161 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 1
  %.state162 = load i64, ptr %.slot33, align 4
  %.splatinsert163 = insertelement <8 x i64> poison, i64 %.state162, i64 0
  %.splat164 = shufflevector <8 x i64> %.splatinsert163, <8 x i64> poison, <8 x i32> zeroinitializer
  %145 = mul <8 x i64> %.splat164, splat (i64 32)
  %146 = add <8 x i64> %144, %145
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %143, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %148, 1
  %151 = extractelement <8 x ptr> %149, i32 0
  %152 = extractelement <8 x i64> %150, i32 0
  %153 = sub i64 %152, 0
  %154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %155 = select i1 %154, i64 %153, i64 0
  %private.contiguous.address165 = getelementptr i8, ptr %151, i64 %155
  %private.contiguous.preserve166 = load <8 x float>, ptr %private.contiguous.address165, align 4
  %156 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve166
  store <8 x float> %156, ptr %private.contiguous.address165, align 4
  %.state167 = load i64, ptr %.slot33, align 4
  %157 = add i64 %.state167, 1
  store i64 %157, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false160
  store i64 0, ptr %.slot34, align 4
  %158 = load <8 x float>, ptr %.slot35, align 32
  %159 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %158
  store <8 x float> %159, ptr %.slot35, align 32
  %160 = load <8 x float>, ptr %.slot36, align 32
  %161 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %160
  store <8 x float> %161, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.84, %direct.schedule.6
  %.state168 = load i64, ptr %.slot34, align 4
  %162 = icmp slt i64 %.state168, 129
  br i1 %162, label %direct.true169, label %direct.false170

direct.schedule.8:                                ; preds = %direct.true169
  %.state171 = load i64, ptr %.slot34, align 4
  %163 = sdiv i64 %.state171, 1
  %164 = mul i64 %163, 16
  store i64 %164, ptr %.spill37, align 4
  %165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %168 = select <8 x i1> %71, <8 x ptr> %166, <8 x ptr> %167
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %171 = select <8 x i1> %71, <8 x i64> %169, <8 x i64> %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  store { <8 x ptr>, <8 x i64> } %173, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state172 = load i64, ptr %.slot39, align 4
  %174 = icmp slt i64 %.state172, 1280
  br i1 %174, label %direct.true173, label %direct.false174

direct.schedule.10:                               ; preds = %direct.true173
  %.state175 = load i64, ptr %.slot39, align 4
  %175 = srem i64 %.state175, 80
  %.state176 = load i64, ptr %.slot39, align 4
  %176 = sdiv i64 %.state176, 80
  %.spill.load177 = load i64, ptr %.spill29, align 4
  %177 = add i64 %.spill.load177, 0
  %.spill.load178 = load <8 x i64>, ptr %.spill30, align 64
  %178 = add <8 x i64> %.spill.load178, zeroinitializer
  %179 = mul i64 %177, 2
  %.splatinsert179 = insertelement <8 x i64> poison, i64 %179, i64 0
  %.splat180 = shufflevector <8 x i64> %.splatinsert179, <8 x i64> poison, <8 x i32> zeroinitializer
  %180 = add <8 x i64> %.splat180, %178
  %.spill.load181 = load i64, ptr %.spill37, align 4
  %181 = add i64 %.spill.load181, %176
  %182 = mul <8 x i64> %180, splat (i64 2053)
  %.splatinsert182 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat183 = shufflevector <8 x i64> %.splatinsert182, <8 x i64> poison, <8 x i32> zeroinitializer
  %183 = add <8 x i64> %182, %.splat183
  %184 = icmp sge i64 %181, 0
  %185 = and i1 true, %184
  %186 = icmp slt i64 %181, 2053
  %187 = and i1 %185, %186
  %188 = add i64 0, %175
  %189 = mul <8 x i64> %183, splat (i64 80)
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %188, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %190 = add <8 x i64> %189, %.splat185
  %191 = load <8 x i64>, ptr %.spill40, align 64
  %192 = select <8 x i1> %71, <8 x i64> %190, <8 x i64> %191
  store <8 x i64> %192, ptr %.spill40, align 64
  br i1 %187, label %direct.true186, label %direct.false187

direct.schedule.11:                               ; preds = %direct.true186
  %.spill.load188 = load <8 x i64>, ptr %.spill40, align 64
  %193 = extractvalue { ptr, i64 } %35, 0
  %194 = mul <8 x i64> %.spill.load188, splat (i64 4)
  %195 = getelementptr i8, ptr %193, <8 x i64> %194
  %196 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %195, <8 x i1> %71, <8 x float> zeroinitializer)
  %197 = load <8 x float>, ptr %.slot41, align 32
  %198 = select <8 x i1> %71, <8 x float> %196, <8 x float> %197
  store <8 x float> %198, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.false187, %direct.schedule.11
  %tile_snapshot.spill.load189 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %.state190 = load i64, ptr %.slot39, align 4
  %.splatinsert191 = insertelement <8 x i64> poison, i64 %.state190, i64 0
  %.splat192 = shufflevector <8 x i64> %.splatinsert191, <8 x i64> poison, <8 x i32> zeroinitializer
  %201 = mul <8 x i64> %.splat192, splat (i64 32)
  %202 = add <8 x i64> %200, %201
  %203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %199, 0
  %204 = insertvalue { <8 x ptr>, <8 x i64> } %203, <8 x i64> %202, 1
  %.state193 = load <8 x float>, ptr %.slot41, align 32
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %204, 1
  %207 = extractelement <8 x ptr> %205, i32 0
  %208 = extractelement <8 x i64> %206, i32 0
  %209 = sub i64 %208, 0
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %211 = select i1 %210, i64 %209, i64 0
  %private.contiguous.address194 = getelementptr i8, ptr %207, i64 %211
  %private.contiguous.preserve195 = load <8 x float>, ptr %private.contiguous.address194, align 4
  %212 = select <8 x i1> %71, <8 x float> %.state193, <8 x float> %private.contiguous.preserve195
  store <8 x float> %212, ptr %private.contiguous.address194, align 4
  %.state196 = load i64, ptr %.slot39, align 4
  %213 = add i64 %.state196, 1
  store i64 %213, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false174
  %214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %214, 0
  %217 = select <8 x i1> %71, <8 x ptr> %215, <8 x ptr> %216
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %214, 1
  %220 = select <8 x i1> %71, <8 x i64> %218, <8 x i64> %219
  %221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %222 = insertvalue { <8 x ptr>, <8 x i64> } %221, <8 x i64> %220, 1
  store { <8 x ptr>, <8 x i64> } %222, ptr %tile_snapshot.spill42, align 64
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state197 = load i64, ptr %.slot43, align 4
  %223 = icmp slt i64 %.state197, 1536
  br i1 %223, label %direct.true198, label %direct.false199

direct.schedule.15:                               ; preds = %direct.true198
  %.state200 = load i64, ptr %.slot43, align 4
  %224 = srem i64 %.state200, 96
  %.state201 = load i64, ptr %.slot43, align 4
  %225 = sdiv i64 %.state201, 96
  %.spill.load202 = load i64, ptr %.spill29, align 4
  %226 = add i64 %.spill.load202, 0
  %.spill.load203 = load <8 x i64>, ptr %.spill30, align 64
  %227 = add <8 x i64> %.spill.load203, zeroinitializer
  %228 = mul i64 %226, 2
  %.splatinsert204 = insertelement <8 x i64> poison, i64 %228, i64 0
  %.splat205 = shufflevector <8 x i64> %.splatinsert204, <8 x i64> poison, <8 x i32> zeroinitializer
  %229 = add <8 x i64> %.splat205, %227
  %.spill.load206 = load i64, ptr %.spill37, align 4
  %230 = add i64 %.spill.load206, %225
  %231 = mul <8 x i64> %229, splat (i64 2053)
  %.splatinsert207 = insertelement <8 x i64> poison, i64 %230, i64 0
  %.splat208 = shufflevector <8 x i64> %.splatinsert207, <8 x i64> poison, <8 x i32> zeroinitializer
  %232 = add <8 x i64> %231, %.splat208
  %233 = icmp sge i64 %230, 0
  %234 = and i1 true, %233
  %235 = icmp slt i64 %230, 2053
  %236 = and i1 %234, %235
  %237 = add i64 0, %224
  %238 = mul <8 x i64> %232, splat (i64 96)
  %.splatinsert209 = insertelement <8 x i64> poison, i64 %237, i64 0
  %.splat210 = shufflevector <8 x i64> %.splatinsert209, <8 x i64> poison, <8 x i32> zeroinitializer
  %239 = add <8 x i64> %238, %.splat210
  %240 = load <8 x i64>, ptr %.spill44, align 64
  %241 = select <8 x i1> %71, <8 x i64> %239, <8 x i64> %240
  store <8 x i64> %241, ptr %.spill44, align 64
  br i1 %236, label %direct.true211, label %direct.false212

direct.schedule.16:                               ; preds = %direct.true211
  %.spill.load213 = load <8 x i64>, ptr %.spill44, align 64
  %242 = extractvalue { ptr, i64 } %41, 0
  %243 = mul <8 x i64> %.spill.load213, splat (i64 4)
  %244 = getelementptr i8, ptr %242, <8 x i64> %243
  %245 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %244, <8 x i1> %71, <8 x float> zeroinitializer)
  %246 = load <8 x float>, ptr %.slot45, align 32
  %247 = select <8 x i1> %71, <8 x float> %245, <8 x float> %246
  store <8 x float> %247, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.false212, %direct.schedule.16
  %tile_snapshot.spill.load214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 1
  %.state215 = load i64, ptr %.slot43, align 4
  %.splatinsert216 = insertelement <8 x i64> poison, i64 %.state215, i64 0
  %.splat217 = shufflevector <8 x i64> %.splatinsert216, <8 x i64> poison, <8 x i32> zeroinitializer
  %250 = mul <8 x i64> %.splat217, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %.state218 = load <8 x float>, ptr %.slot45, align 32
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address219 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.preserve220 = load <8 x float>, ptr %private.contiguous.address219, align 4
  %261 = select <8 x i1> %71, <8 x float> %.state218, <8 x float> %private.contiguous.preserve220
  store <8 x float> %261, ptr %private.contiguous.address219, align 4
  %.state221 = load i64, ptr %.slot43, align 4
  %262 = add i64 %.state221, 1
  store i64 %262, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false199
  store i64 0, ptr %.slot46, align 4
  %263 = load <8 x float>, ptr %.slot47, align 32
  %264 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %263
  store <8 x float> %264, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state222 = load i64, ptr %.slot46, align 4
  %265 = icmp slt i64 %.state222, 80
  br i1 %265, label %direct.true223, label %direct.false224

direct.schedule.20:                               ; preds = %direct.true223
  %.state225 = load i64, ptr %.slot46, align 4
  %266 = add i64 0, %.state225
  %tile_snapshot.spill.load226 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load226, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load226, 1
  %.splatinsert227 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat228 = shufflevector <8 x i64> %.splatinsert227, <8 x i64> poison, <8 x i32> zeroinitializer
  %269 = mul <8 x i64> %.splat228, splat (i64 32)
  %270 = add <8 x i64> %268, %269
  %271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %267, 0
  %272 = insertvalue { <8 x ptr>, <8 x i64> } %271, <8 x i64> %270, 1
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %272, 1
  %275 = extractelement <8 x ptr> %273, i32 0
  %276 = extractelement <8 x i64> %274, i32 0
  %277 = sub i64 %276, 0
  %278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %279 = select i1 %278, i64 %277, i64 0
  %private.contiguous.address229 = getelementptr i8, ptr %275, i64 %279
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address229, align 4
  %280 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load230 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load230, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load230, 1
  %.splatinsert231 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat232 = shufflevector <8 x i64> %.splatinsert231, <8 x i64> poison, <8 x i32> zeroinitializer
  %283 = mul <8 x i64> %.splat232, splat (i64 32)
  %284 = add <8 x i64> %282, %283
  %285 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %281, 0
  %286 = insertvalue { <8 x ptr>, <8 x i64> } %285, <8 x i64> %284, 1
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %286, 1
  %289 = extractelement <8 x ptr> %287, i32 0
  %290 = extractelement <8 x i64> %288, i32 0
  %291 = sub i64 %290, 0
  %292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %293 = select i1 %292, i64 %291, i64 0
  %private.contiguous.address233 = getelementptr i8, ptr %289, i64 %293
  %private.contiguous.load234 = load <8 x float>, ptr %private.contiguous.address233, align 4
  %294 = select <8 x i1> %71, <8 x float> %private.contiguous.load234, <8 x float> zeroinitializer
  %295 = fmul <8 x float> %280, %294
  %.state235 = load <8 x float>, ptr %.slot47, align 32
  %296 = fadd <8 x float> %.state235, %295
  %.state236 = load i64, ptr %.slot46, align 4
  %297 = add i64 %.state236, 1
  store i64 %297, ptr %.slot46, align 4
  %298 = load <8 x float>, ptr %.slot47, align 32
  %299 = select <8 x i1> %71, <8 x float> %296, <8 x float> %298
  store <8 x float> %299, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false224
  store i64 0, ptr %.slot48, align 4
  %300 = load <8 x float>, ptr %.slot49, align 32
  %301 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %300
  store <8 x float> %301, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state237 = load i64, ptr %.slot48, align 4
  %302 = icmp slt i64 %.state237, 80
  br i1 %302, label %direct.true238, label %direct.false239

direct.schedule.23:                               ; preds = %direct.true238
  %.state240 = load i64, ptr %.slot48, align 4
  %303 = add i64 0, %.state240
  %tile_snapshot.spill.load241 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 1
  %.splatinsert242 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat243 = shufflevector <8 x i64> %.splatinsert242, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat243, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address244 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load245 = load <8 x float>, ptr %private.contiguous.address244, align 4
  %317 = select <8 x i1> %71, <8 x float> %private.contiguous.load245, <8 x float> zeroinitializer
  %.state246 = load i64, ptr %.slot48, align 4
  %318 = add i64 80, %.state246
  %tile_snapshot.spill.load247 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 0
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 1
  %.splatinsert248 = insertelement <8 x i64> poison, i64 %318, i64 0
  %.splat249 = shufflevector <8 x i64> %.splatinsert248, <8 x i64> poison, <8 x i32> zeroinitializer
  %321 = mul <8 x i64> %.splat249, splat (i64 32)
  %322 = add <8 x i64> %320, %321
  %323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %319, 0
  %324 = insertvalue { <8 x ptr>, <8 x i64> } %323, <8 x i64> %322, 1
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %324, 1
  %327 = extractelement <8 x ptr> %325, i32 0
  %328 = extractelement <8 x i64> %326, i32 0
  %329 = sub i64 %328, 0
  %330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %331 = select i1 %330, i64 %329, i64 0
  %private.contiguous.address250 = getelementptr i8, ptr %327, i64 %331
  %private.contiguous.load251 = load <8 x float>, ptr %private.contiguous.address250, align 4
  %332 = select <8 x i1> %71, <8 x float> %private.contiguous.load251, <8 x float> zeroinitializer
  %333 = fmul <8 x float> %317, %332
  %.state252 = load <8 x float>, ptr %.slot49, align 32
  %334 = fadd <8 x float> %.state252, %333
  %.state253 = load i64, ptr %.slot48, align 4
  %335 = add i64 %.state253, 1
  store i64 %335, ptr %.slot48, align 4
  %336 = load <8 x float>, ptr %.slot49, align 32
  %337 = select <8 x i1> %71, <8 x float> %334, <8 x float> %336
  store <8 x float> %337, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false239
  store i64 0, ptr %.slot50, align 4
  %338 = load <8 x float>, ptr %.slot51, align 32
  %339 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %338
  store <8 x float> %339, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state254 = load i64, ptr %.slot50, align 4
  %340 = icmp slt i64 %.state254, 80
  br i1 %340, label %direct.true255, label %direct.false256

direct.schedule.26:                               ; preds = %direct.true255
  %.state257 = load i64, ptr %.slot50, align 4
  %341 = add i64 0, %.state257
  %tile_snapshot.spill.load258 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load258, 0
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load258, 1
  %.splatinsert259 = insertelement <8 x i64> poison, i64 %341, i64 0
  %.splat260 = shufflevector <8 x i64> %.splatinsert259, <8 x i64> poison, <8 x i32> zeroinitializer
  %344 = mul <8 x i64> %.splat260, splat (i64 32)
  %345 = add <8 x i64> %343, %344
  %346 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %342, 0
  %347 = insertvalue { <8 x ptr>, <8 x i64> } %346, <8 x i64> %345, 1
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %347, 1
  %350 = extractelement <8 x ptr> %348, i32 0
  %351 = extractelement <8 x i64> %349, i32 0
  %352 = sub i64 %351, 0
  %353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %354 = select i1 %353, i64 %352, i64 0
  %private.contiguous.address261 = getelementptr i8, ptr %350, i64 %354
  %private.contiguous.load262 = load <8 x float>, ptr %private.contiguous.address261, align 4
  %355 = select <8 x i1> %71, <8 x float> %private.contiguous.load262, <8 x float> zeroinitializer
  %.state263 = load i64, ptr %.slot50, align 4
  %356 = add i64 160, %.state263
  %tile_snapshot.spill.load264 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 0
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 1
  %.splatinsert265 = insertelement <8 x i64> poison, i64 %356, i64 0
  %.splat266 = shufflevector <8 x i64> %.splatinsert265, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = mul <8 x i64> %.splat266, splat (i64 32)
  %360 = add <8 x i64> %358, %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = extractelement <8 x ptr> %363, i32 0
  %366 = extractelement <8 x i64> %364, i32 0
  %367 = sub i64 %366, 0
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %369 = select i1 %368, i64 %367, i64 0
  %private.contiguous.address267 = getelementptr i8, ptr %365, i64 %369
  %private.contiguous.load268 = load <8 x float>, ptr %private.contiguous.address267, align 4
  %370 = select <8 x i1> %71, <8 x float> %private.contiguous.load268, <8 x float> zeroinitializer
  %371 = fmul <8 x float> %355, %370
  %.state269 = load <8 x float>, ptr %.slot51, align 32
  %372 = fadd <8 x float> %.state269, %371
  %.state270 = load i64, ptr %.slot50, align 4
  %373 = add i64 %.state270, 1
  store i64 %373, ptr %.slot50, align 4
  %374 = load <8 x float>, ptr %.slot51, align 32
  %375 = select <8 x i1> %71, <8 x float> %372, <8 x float> %374
  store <8 x float> %375, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false256
  store i64 0, ptr %.slot52, align 4
  %376 = load <8 x float>, ptr %.slot53, align 32
  %377 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %376
  store <8 x float> %377, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state271 = load i64, ptr %.slot52, align 4
  %378 = icmp slt i64 %.state271, 80
  br i1 %378, label %direct.true272, label %direct.false273

direct.schedule.29:                               ; preds = %direct.true272
  %.state274 = load i64, ptr %.slot52, align 4
  %379 = add i64 0, %.state274
  %tile_snapshot.spill.load275 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load275, 0
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load275, 1
  %.splatinsert276 = insertelement <8 x i64> poison, i64 %379, i64 0
  %.splat277 = shufflevector <8 x i64> %.splatinsert276, <8 x i64> poison, <8 x i32> zeroinitializer
  %382 = mul <8 x i64> %.splat277, splat (i64 32)
  %383 = add <8 x i64> %381, %382
  %384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %380, 0
  %385 = insertvalue { <8 x ptr>, <8 x i64> } %384, <8 x i64> %383, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %385, 1
  %388 = extractelement <8 x ptr> %386, i32 0
  %389 = extractelement <8 x i64> %387, i32 0
  %390 = sub i64 %389, 0
  %391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %392 = select i1 %391, i64 %390, i64 0
  %private.contiguous.address278 = getelementptr i8, ptr %388, i64 %392
  %private.contiguous.load279 = load <8 x float>, ptr %private.contiguous.address278, align 4
  %393 = select <8 x i1> %71, <8 x float> %private.contiguous.load279, <8 x float> zeroinitializer
  %.state280 = load i64, ptr %.slot52, align 4
  %394 = add i64 240, %.state280
  %tile_snapshot.spill.load281 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %.splatinsert282 = insertelement <8 x i64> poison, i64 %394, i64 0
  %.splat283 = shufflevector <8 x i64> %.splatinsert282, <8 x i64> poison, <8 x i32> zeroinitializer
  %397 = mul <8 x i64> %.splat283, splat (i64 32)
  %398 = add <8 x i64> %396, %397
  %399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %395, 0
  %400 = insertvalue { <8 x ptr>, <8 x i64> } %399, <8 x i64> %398, 1
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %400, 1
  %403 = extractelement <8 x ptr> %401, i32 0
  %404 = extractelement <8 x i64> %402, i32 0
  %405 = sub i64 %404, 0
  %406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %407 = select i1 %406, i64 %405, i64 0
  %private.contiguous.address284 = getelementptr i8, ptr %403, i64 %407
  %private.contiguous.load285 = load <8 x float>, ptr %private.contiguous.address284, align 4
  %408 = select <8 x i1> %71, <8 x float> %private.contiguous.load285, <8 x float> zeroinitializer
  %409 = fmul <8 x float> %393, %408
  %.state286 = load <8 x float>, ptr %.slot53, align 32
  %410 = fadd <8 x float> %.state286, %409
  %.state287 = load i64, ptr %.slot52, align 4
  %411 = add i64 %.state287, 1
  store i64 %411, ptr %.slot52, align 4
  %412 = load <8 x float>, ptr %.slot53, align 32
  %413 = select <8 x i1> %71, <8 x float> %410, <8 x float> %412
  store <8 x float> %413, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false273
  store i64 0, ptr %.slot54, align 4
  %414 = load <8 x float>, ptr %.slot55, align 32
  %415 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %414
  store <8 x float> %415, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state288 = load i64, ptr %.slot54, align 4
  %416 = icmp slt i64 %.state288, 80
  br i1 %416, label %direct.true289, label %direct.false290

direct.schedule.32:                               ; preds = %direct.true289
  %.state291 = load i64, ptr %.slot54, align 4
  %417 = add i64 0, %.state291
  %tile_snapshot.spill.load292 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load292, 0
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load292, 1
  %.splatinsert293 = insertelement <8 x i64> poison, i64 %417, i64 0
  %.splat294 = shufflevector <8 x i64> %.splatinsert293, <8 x i64> poison, <8 x i32> zeroinitializer
  %420 = mul <8 x i64> %.splat294, splat (i64 32)
  %421 = add <8 x i64> %419, %420
  %422 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %418, 0
  %423 = insertvalue { <8 x ptr>, <8 x i64> } %422, <8 x i64> %421, 1
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %423, 1
  %426 = extractelement <8 x ptr> %424, i32 0
  %427 = extractelement <8 x i64> %425, i32 0
  %428 = sub i64 %427, 0
  %429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %430 = select i1 %429, i64 %428, i64 0
  %private.contiguous.address295 = getelementptr i8, ptr %426, i64 %430
  %private.contiguous.load296 = load <8 x float>, ptr %private.contiguous.address295, align 4
  %431 = select <8 x i1> %71, <8 x float> %private.contiguous.load296, <8 x float> zeroinitializer
  %.state297 = load i64, ptr %.slot54, align 4
  %432 = add i64 320, %.state297
  %tile_snapshot.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 0
  %434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 1
  %.splatinsert299 = insertelement <8 x i64> poison, i64 %432, i64 0
  %.splat300 = shufflevector <8 x i64> %.splatinsert299, <8 x i64> poison, <8 x i32> zeroinitializer
  %435 = mul <8 x i64> %.splat300, splat (i64 32)
  %436 = add <8 x i64> %434, %435
  %437 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %433, 0
  %438 = insertvalue { <8 x ptr>, <8 x i64> } %437, <8 x i64> %436, 1
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %438, 1
  %441 = extractelement <8 x ptr> %439, i32 0
  %442 = extractelement <8 x i64> %440, i32 0
  %443 = sub i64 %442, 0
  %444 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %445 = select i1 %444, i64 %443, i64 0
  %private.contiguous.address301 = getelementptr i8, ptr %441, i64 %445
  %private.contiguous.load302 = load <8 x float>, ptr %private.contiguous.address301, align 4
  %446 = select <8 x i1> %71, <8 x float> %private.contiguous.load302, <8 x float> zeroinitializer
  %447 = fmul <8 x float> %431, %446
  %.state303 = load <8 x float>, ptr %.slot55, align 32
  %448 = fadd <8 x float> %.state303, %447
  %.state304 = load i64, ptr %.slot54, align 4
  %449 = add i64 %.state304, 1
  store i64 %449, ptr %.slot54, align 4
  %450 = load <8 x float>, ptr %.slot55, align 32
  %451 = select <8 x i1> %71, <8 x float> %448, <8 x float> %450
  store <8 x float> %451, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false290
  store i64 0, ptr %.slot56, align 4
  %452 = load <8 x float>, ptr %.slot57, align 32
  %453 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %452
  store <8 x float> %453, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state305 = load i64, ptr %.slot56, align 4
  %454 = icmp slt i64 %.state305, 80
  br i1 %454, label %direct.true306, label %direct.false307

direct.schedule.35:                               ; preds = %direct.true306
  %.state308 = load i64, ptr %.slot56, align 4
  %455 = add i64 0, %.state308
  %tile_snapshot.spill.load309 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %456 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load309, 0
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load309, 1
  %.splatinsert310 = insertelement <8 x i64> poison, i64 %455, i64 0
  %.splat311 = shufflevector <8 x i64> %.splatinsert310, <8 x i64> poison, <8 x i32> zeroinitializer
  %458 = mul <8 x i64> %.splat311, splat (i64 32)
  %459 = add <8 x i64> %457, %458
  %460 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %456, 0
  %461 = insertvalue { <8 x ptr>, <8 x i64> } %460, <8 x i64> %459, 1
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %461, 1
  %464 = extractelement <8 x ptr> %462, i32 0
  %465 = extractelement <8 x i64> %463, i32 0
  %466 = sub i64 %465, 0
  %467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %468 = select i1 %467, i64 %466, i64 0
  %private.contiguous.address312 = getelementptr i8, ptr %464, i64 %468
  %private.contiguous.load313 = load <8 x float>, ptr %private.contiguous.address312, align 4
  %469 = select <8 x i1> %71, <8 x float> %private.contiguous.load313, <8 x float> zeroinitializer
  %.state314 = load i64, ptr %.slot56, align 4
  %470 = add i64 400, %.state314
  %tile_snapshot.spill.load315 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 0
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 1
  %.splatinsert316 = insertelement <8 x i64> poison, i64 %470, i64 0
  %.splat317 = shufflevector <8 x i64> %.splatinsert316, <8 x i64> poison, <8 x i32> zeroinitializer
  %473 = mul <8 x i64> %.splat317, splat (i64 32)
  %474 = add <8 x i64> %472, %473
  %475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %471, 0
  %476 = insertvalue { <8 x ptr>, <8 x i64> } %475, <8 x i64> %474, 1
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %476, 1
  %479 = extractelement <8 x ptr> %477, i32 0
  %480 = extractelement <8 x i64> %478, i32 0
  %481 = sub i64 %480, 0
  %482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %483 = select i1 %482, i64 %481, i64 0
  %private.contiguous.address318 = getelementptr i8, ptr %479, i64 %483
  %private.contiguous.load319 = load <8 x float>, ptr %private.contiguous.address318, align 4
  %484 = select <8 x i1> %71, <8 x float> %private.contiguous.load319, <8 x float> zeroinitializer
  %485 = fmul <8 x float> %469, %484
  %.state320 = load <8 x float>, ptr %.slot57, align 32
  %486 = fadd <8 x float> %.state320, %485
  %.state321 = load i64, ptr %.slot56, align 4
  %487 = add i64 %.state321, 1
  store i64 %487, ptr %.slot56, align 4
  %488 = load <8 x float>, ptr %.slot57, align 32
  %489 = select <8 x i1> %71, <8 x float> %486, <8 x float> %488
  store <8 x float> %489, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false307
  store i64 0, ptr %.slot58, align 4
  %490 = load <8 x float>, ptr %.slot59, align 32
  %491 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %490
  store <8 x float> %491, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state322 = load i64, ptr %.slot58, align 4
  %492 = icmp slt i64 %.state322, 80
  br i1 %492, label %direct.true323, label %direct.false324

direct.schedule.38:                               ; preds = %direct.true323
  %.state325 = load i64, ptr %.slot58, align 4
  %493 = add i64 0, %.state325
  %tile_snapshot.spill.load326 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load326, 0
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load326, 1
  %.splatinsert327 = insertelement <8 x i64> poison, i64 %493, i64 0
  %.splat328 = shufflevector <8 x i64> %.splatinsert327, <8 x i64> poison, <8 x i32> zeroinitializer
  %496 = mul <8 x i64> %.splat328, splat (i64 32)
  %497 = add <8 x i64> %495, %496
  %498 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %494, 0
  %499 = insertvalue { <8 x ptr>, <8 x i64> } %498, <8 x i64> %497, 1
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %499, 1
  %502 = extractelement <8 x ptr> %500, i32 0
  %503 = extractelement <8 x i64> %501, i32 0
  %504 = sub i64 %503, 0
  %505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %506 = select i1 %505, i64 %504, i64 0
  %private.contiguous.address329 = getelementptr i8, ptr %502, i64 %506
  %private.contiguous.load330 = load <8 x float>, ptr %private.contiguous.address329, align 4
  %507 = select <8 x i1> %71, <8 x float> %private.contiguous.load330, <8 x float> zeroinitializer
  %.state331 = load i64, ptr %.slot58, align 4
  %508 = add i64 480, %.state331
  %tile_snapshot.spill.load332 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load332, 0
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load332, 1
  %.splatinsert333 = insertelement <8 x i64> poison, i64 %508, i64 0
  %.splat334 = shufflevector <8 x i64> %.splatinsert333, <8 x i64> poison, <8 x i32> zeroinitializer
  %511 = mul <8 x i64> %.splat334, splat (i64 32)
  %512 = add <8 x i64> %510, %511
  %513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %509, 0
  %514 = insertvalue { <8 x ptr>, <8 x i64> } %513, <8 x i64> %512, 1
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %514, 1
  %517 = extractelement <8 x ptr> %515, i32 0
  %518 = extractelement <8 x i64> %516, i32 0
  %519 = sub i64 %518, 0
  %520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %521 = select i1 %520, i64 %519, i64 0
  %private.contiguous.address335 = getelementptr i8, ptr %517, i64 %521
  %private.contiguous.load336 = load <8 x float>, ptr %private.contiguous.address335, align 4
  %522 = select <8 x i1> %71, <8 x float> %private.contiguous.load336, <8 x float> zeroinitializer
  %523 = fmul <8 x float> %507, %522
  %.state337 = load <8 x float>, ptr %.slot59, align 32
  %524 = fadd <8 x float> %.state337, %523
  %.state338 = load i64, ptr %.slot58, align 4
  %525 = add i64 %.state338, 1
  store i64 %525, ptr %.slot58, align 4
  %526 = load <8 x float>, ptr %.slot59, align 32
  %527 = select <8 x i1> %71, <8 x float> %524, <8 x float> %526
  store <8 x float> %527, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false324
  store i64 0, ptr %.slot60, align 4
  %528 = load <8 x float>, ptr %.slot61, align 32
  %529 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %528
  store <8 x float> %529, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state339 = load i64, ptr %.slot60, align 4
  %530 = icmp slt i64 %.state339, 80
  br i1 %530, label %direct.true340, label %direct.false341

direct.schedule.41:                               ; preds = %direct.true340
  %.state342 = load i64, ptr %.slot60, align 4
  %531 = add i64 0, %.state342
  %tile_snapshot.spill.load343 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load343, 0
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load343, 1
  %.splatinsert344 = insertelement <8 x i64> poison, i64 %531, i64 0
  %.splat345 = shufflevector <8 x i64> %.splatinsert344, <8 x i64> poison, <8 x i32> zeroinitializer
  %534 = mul <8 x i64> %.splat345, splat (i64 32)
  %535 = add <8 x i64> %533, %534
  %536 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %532, 0
  %537 = insertvalue { <8 x ptr>, <8 x i64> } %536, <8 x i64> %535, 1
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %539 = extractvalue { <8 x ptr>, <8 x i64> } %537, 1
  %540 = extractelement <8 x ptr> %538, i32 0
  %541 = extractelement <8 x i64> %539, i32 0
  %542 = sub i64 %541, 0
  %543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %544 = select i1 %543, i64 %542, i64 0
  %private.contiguous.address346 = getelementptr i8, ptr %540, i64 %544
  %private.contiguous.load347 = load <8 x float>, ptr %private.contiguous.address346, align 4
  %545 = select <8 x i1> %71, <8 x float> %private.contiguous.load347, <8 x float> zeroinitializer
  %.state348 = load i64, ptr %.slot60, align 4
  %546 = add i64 560, %.state348
  %tile_snapshot.spill.load349 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load349, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load349, 1
  %.splatinsert350 = insertelement <8 x i64> poison, i64 %546, i64 0
  %.splat351 = shufflevector <8 x i64> %.splatinsert350, <8 x i64> poison, <8 x i32> zeroinitializer
  %549 = mul <8 x i64> %.splat351, splat (i64 32)
  %550 = add <8 x i64> %548, %549
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %547, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = extractelement <8 x ptr> %553, i32 0
  %556 = extractelement <8 x i64> %554, i32 0
  %557 = sub i64 %556, 0
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %559 = select i1 %558, i64 %557, i64 0
  %private.contiguous.address352 = getelementptr i8, ptr %555, i64 %559
  %private.contiguous.load353 = load <8 x float>, ptr %private.contiguous.address352, align 4
  %560 = select <8 x i1> %71, <8 x float> %private.contiguous.load353, <8 x float> zeroinitializer
  %561 = fmul <8 x float> %545, %560
  %.state354 = load <8 x float>, ptr %.slot61, align 32
  %562 = fadd <8 x float> %.state354, %561
  %.state355 = load i64, ptr %.slot60, align 4
  %563 = add i64 %.state355, 1
  store i64 %563, ptr %.slot60, align 4
  %564 = load <8 x float>, ptr %.slot61, align 32
  %565 = select <8 x i1> %71, <8 x float> %562, <8 x float> %564
  store <8 x float> %565, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false341
  store i64 0, ptr %.slot62, align 4
  %566 = load <8 x float>, ptr %.slot63, align 32
  %567 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %566
  store <8 x float> %567, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state356 = load i64, ptr %.slot62, align 4
  %568 = icmp slt i64 %.state356, 80
  br i1 %568, label %direct.true357, label %direct.false358

direct.schedule.44:                               ; preds = %direct.true357
  %.state359 = load i64, ptr %.slot62, align 4
  %569 = add i64 0, %.state359
  %tile_snapshot.spill.load360 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load360, 0
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load360, 1
  %.splatinsert361 = insertelement <8 x i64> poison, i64 %569, i64 0
  %.splat362 = shufflevector <8 x i64> %.splatinsert361, <8 x i64> poison, <8 x i32> zeroinitializer
  %572 = mul <8 x i64> %.splat362, splat (i64 32)
  %573 = add <8 x i64> %571, %572
  %574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %570, 0
  %575 = insertvalue { <8 x ptr>, <8 x i64> } %574, <8 x i64> %573, 1
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %575, 1
  %578 = extractelement <8 x ptr> %576, i32 0
  %579 = extractelement <8 x i64> %577, i32 0
  %580 = sub i64 %579, 0
  %581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %582 = select i1 %581, i64 %580, i64 0
  %private.contiguous.address363 = getelementptr i8, ptr %578, i64 %582
  %private.contiguous.load364 = load <8 x float>, ptr %private.contiguous.address363, align 4
  %583 = select <8 x i1> %71, <8 x float> %private.contiguous.load364, <8 x float> zeroinitializer
  %.state365 = load i64, ptr %.slot62, align 4
  %584 = add i64 640, %.state365
  %tile_snapshot.spill.load366 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load366, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load366, 1
  %.splatinsert367 = insertelement <8 x i64> poison, i64 %584, i64 0
  %.splat368 = shufflevector <8 x i64> %.splatinsert367, <8 x i64> poison, <8 x i32> zeroinitializer
  %587 = mul <8 x i64> %.splat368, splat (i64 32)
  %588 = add <8 x i64> %586, %587
  %589 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %585, 0
  %590 = insertvalue { <8 x ptr>, <8 x i64> } %589, <8 x i64> %588, 1
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %592 = extractvalue { <8 x ptr>, <8 x i64> } %590, 1
  %593 = extractelement <8 x ptr> %591, i32 0
  %594 = extractelement <8 x i64> %592, i32 0
  %595 = sub i64 %594, 0
  %596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %597 = select i1 %596, i64 %595, i64 0
  %private.contiguous.address369 = getelementptr i8, ptr %593, i64 %597
  %private.contiguous.load370 = load <8 x float>, ptr %private.contiguous.address369, align 4
  %598 = select <8 x i1> %71, <8 x float> %private.contiguous.load370, <8 x float> zeroinitializer
  %599 = fmul <8 x float> %583, %598
  %.state371 = load <8 x float>, ptr %.slot63, align 32
  %600 = fadd <8 x float> %.state371, %599
  %.state372 = load i64, ptr %.slot62, align 4
  %601 = add i64 %.state372, 1
  store i64 %601, ptr %.slot62, align 4
  %602 = load <8 x float>, ptr %.slot63, align 32
  %603 = select <8 x i1> %71, <8 x float> %600, <8 x float> %602
  store <8 x float> %603, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false358
  store i64 0, ptr %.slot64, align 4
  %604 = load <8 x float>, ptr %.slot65, align 32
  %605 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %604
  store <8 x float> %605, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state373 = load i64, ptr %.slot64, align 4
  %606 = icmp slt i64 %.state373, 80
  br i1 %606, label %direct.true374, label %direct.false375

direct.schedule.47:                               ; preds = %direct.true374
  %.state376 = load i64, ptr %.slot64, align 4
  %607 = add i64 0, %.state376
  %tile_snapshot.spill.load377 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load377, 0
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load377, 1
  %.splatinsert378 = insertelement <8 x i64> poison, i64 %607, i64 0
  %.splat379 = shufflevector <8 x i64> %.splatinsert378, <8 x i64> poison, <8 x i32> zeroinitializer
  %610 = mul <8 x i64> %.splat379, splat (i64 32)
  %611 = add <8 x i64> %609, %610
  %612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %608, 0
  %613 = insertvalue { <8 x ptr>, <8 x i64> } %612, <8 x i64> %611, 1
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %613, 1
  %616 = extractelement <8 x ptr> %614, i32 0
  %617 = extractelement <8 x i64> %615, i32 0
  %618 = sub i64 %617, 0
  %619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %620 = select i1 %619, i64 %618, i64 0
  %private.contiguous.address380 = getelementptr i8, ptr %616, i64 %620
  %private.contiguous.load381 = load <8 x float>, ptr %private.contiguous.address380, align 4
  %621 = select <8 x i1> %71, <8 x float> %private.contiguous.load381, <8 x float> zeroinitializer
  %.state382 = load i64, ptr %.slot64, align 4
  %622 = add i64 720, %.state382
  %tile_snapshot.spill.load383 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %623 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load383, 0
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load383, 1
  %.splatinsert384 = insertelement <8 x i64> poison, i64 %622, i64 0
  %.splat385 = shufflevector <8 x i64> %.splatinsert384, <8 x i64> poison, <8 x i32> zeroinitializer
  %625 = mul <8 x i64> %.splat385, splat (i64 32)
  %626 = add <8 x i64> %624, %625
  %627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %623, 0
  %628 = insertvalue { <8 x ptr>, <8 x i64> } %627, <8 x i64> %626, 1
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %628, 1
  %631 = extractelement <8 x ptr> %629, i32 0
  %632 = extractelement <8 x i64> %630, i32 0
  %633 = sub i64 %632, 0
  %634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %635 = select i1 %634, i64 %633, i64 0
  %private.contiguous.address386 = getelementptr i8, ptr %631, i64 %635
  %private.contiguous.load387 = load <8 x float>, ptr %private.contiguous.address386, align 4
  %636 = select <8 x i1> %71, <8 x float> %private.contiguous.load387, <8 x float> zeroinitializer
  %637 = fmul <8 x float> %621, %636
  %.state388 = load <8 x float>, ptr %.slot65, align 32
  %638 = fadd <8 x float> %.state388, %637
  %.state389 = load i64, ptr %.slot64, align 4
  %639 = add i64 %.state389, 1
  store i64 %639, ptr %.slot64, align 4
  %640 = load <8 x float>, ptr %.slot65, align 32
  %641 = select <8 x i1> %71, <8 x float> %638, <8 x float> %640
  store <8 x float> %641, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false375
  store i64 0, ptr %.slot66, align 4
  %642 = load <8 x float>, ptr %.slot67, align 32
  %643 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %642
  store <8 x float> %643, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state390 = load i64, ptr %.slot66, align 4
  %644 = icmp slt i64 %.state390, 80
  br i1 %644, label %direct.true391, label %direct.false392

direct.schedule.50:                               ; preds = %direct.true391
  %.state393 = load i64, ptr %.slot66, align 4
  %645 = add i64 0, %.state393
  %tile_snapshot.spill.load394 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load394, 0
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load394, 1
  %.splatinsert395 = insertelement <8 x i64> poison, i64 %645, i64 0
  %.splat396 = shufflevector <8 x i64> %.splatinsert395, <8 x i64> poison, <8 x i32> zeroinitializer
  %648 = mul <8 x i64> %.splat396, splat (i64 32)
  %649 = add <8 x i64> %647, %648
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %646, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = extractelement <8 x ptr> %652, i32 0
  %655 = extractelement <8 x i64> %653, i32 0
  %656 = sub i64 %655, 0
  %657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %658 = select i1 %657, i64 %656, i64 0
  %private.contiguous.address397 = getelementptr i8, ptr %654, i64 %658
  %private.contiguous.load398 = load <8 x float>, ptr %private.contiguous.address397, align 4
  %659 = select <8 x i1> %71, <8 x float> %private.contiguous.load398, <8 x float> zeroinitializer
  %.state399 = load i64, ptr %.slot66, align 4
  %660 = add i64 800, %.state399
  %tile_snapshot.spill.load400 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load400, 0
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load400, 1
  %.splatinsert401 = insertelement <8 x i64> poison, i64 %660, i64 0
  %.splat402 = shufflevector <8 x i64> %.splatinsert401, <8 x i64> poison, <8 x i32> zeroinitializer
  %663 = mul <8 x i64> %.splat402, splat (i64 32)
  %664 = add <8 x i64> %662, %663
  %665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %661, 0
  %666 = insertvalue { <8 x ptr>, <8 x i64> } %665, <8 x i64> %664, 1
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %666, 1
  %669 = extractelement <8 x ptr> %667, i32 0
  %670 = extractelement <8 x i64> %668, i32 0
  %671 = sub i64 %670, 0
  %672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %673 = select i1 %672, i64 %671, i64 0
  %private.contiguous.address403 = getelementptr i8, ptr %669, i64 %673
  %private.contiguous.load404 = load <8 x float>, ptr %private.contiguous.address403, align 4
  %674 = select <8 x i1> %71, <8 x float> %private.contiguous.load404, <8 x float> zeroinitializer
  %675 = fmul <8 x float> %659, %674
  %.state405 = load <8 x float>, ptr %.slot67, align 32
  %676 = fadd <8 x float> %.state405, %675
  %.state406 = load i64, ptr %.slot66, align 4
  %677 = add i64 %.state406, 1
  store i64 %677, ptr %.slot66, align 4
  %678 = load <8 x float>, ptr %.slot67, align 32
  %679 = select <8 x i1> %71, <8 x float> %676, <8 x float> %678
  store <8 x float> %679, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false392
  store i64 0, ptr %.slot68, align 4
  %680 = load <8 x float>, ptr %.slot69, align 32
  %681 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %680
  store <8 x float> %681, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state407 = load i64, ptr %.slot68, align 4
  %682 = icmp slt i64 %.state407, 80
  br i1 %682, label %direct.true408, label %direct.false409

direct.schedule.53:                               ; preds = %direct.true408
  %.state410 = load i64, ptr %.slot68, align 4
  %683 = add i64 0, %.state410
  %tile_snapshot.spill.load411 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %.splatinsert412 = insertelement <8 x i64> poison, i64 %683, i64 0
  %.splat413 = shufflevector <8 x i64> %.splatinsert412, <8 x i64> poison, <8 x i32> zeroinitializer
  %686 = mul <8 x i64> %.splat413, splat (i64 32)
  %687 = add <8 x i64> %685, %686
  %688 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %684, 0
  %689 = insertvalue { <8 x ptr>, <8 x i64> } %688, <8 x i64> %687, 1
  %690 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %689, 1
  %692 = extractelement <8 x ptr> %690, i32 0
  %693 = extractelement <8 x i64> %691, i32 0
  %694 = sub i64 %693, 0
  %695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %696 = select i1 %695, i64 %694, i64 0
  %private.contiguous.address414 = getelementptr i8, ptr %692, i64 %696
  %private.contiguous.load415 = load <8 x float>, ptr %private.contiguous.address414, align 4
  %697 = select <8 x i1> %71, <8 x float> %private.contiguous.load415, <8 x float> zeroinitializer
  %.state416 = load i64, ptr %.slot68, align 4
  %698 = add i64 880, %.state416
  %tile_snapshot.spill.load417 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 0
  %700 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 1
  %.splatinsert418 = insertelement <8 x i64> poison, i64 %698, i64 0
  %.splat419 = shufflevector <8 x i64> %.splatinsert418, <8 x i64> poison, <8 x i32> zeroinitializer
  %701 = mul <8 x i64> %.splat419, splat (i64 32)
  %702 = add <8 x i64> %700, %701
  %703 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %699, 0
  %704 = insertvalue { <8 x ptr>, <8 x i64> } %703, <8 x i64> %702, 1
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %706 = extractvalue { <8 x ptr>, <8 x i64> } %704, 1
  %707 = extractelement <8 x ptr> %705, i32 0
  %708 = extractelement <8 x i64> %706, i32 0
  %709 = sub i64 %708, 0
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %711 = select i1 %710, i64 %709, i64 0
  %private.contiguous.address420 = getelementptr i8, ptr %707, i64 %711
  %private.contiguous.load421 = load <8 x float>, ptr %private.contiguous.address420, align 4
  %712 = select <8 x i1> %71, <8 x float> %private.contiguous.load421, <8 x float> zeroinitializer
  %713 = fmul <8 x float> %697, %712
  %.state422 = load <8 x float>, ptr %.slot69, align 32
  %714 = fadd <8 x float> %.state422, %713
  %.state423 = load i64, ptr %.slot68, align 4
  %715 = add i64 %.state423, 1
  store i64 %715, ptr %.slot68, align 4
  %716 = load <8 x float>, ptr %.slot69, align 32
  %717 = select <8 x i1> %71, <8 x float> %714, <8 x float> %716
  store <8 x float> %717, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false409
  store i64 0, ptr %.slot70, align 4
  %718 = load <8 x float>, ptr %.slot71, align 32
  %719 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %718
  store <8 x float> %719, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state424 = load i64, ptr %.slot70, align 4
  %720 = icmp slt i64 %.state424, 80
  br i1 %720, label %direct.true425, label %direct.false426

direct.schedule.56:                               ; preds = %direct.true425
  %.state427 = load i64, ptr %.slot70, align 4
  %721 = add i64 0, %.state427
  %tile_snapshot.spill.load428 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load428, 0
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load428, 1
  %.splatinsert429 = insertelement <8 x i64> poison, i64 %721, i64 0
  %.splat430 = shufflevector <8 x i64> %.splatinsert429, <8 x i64> poison, <8 x i32> zeroinitializer
  %724 = mul <8 x i64> %.splat430, splat (i64 32)
  %725 = add <8 x i64> %723, %724
  %726 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %722, 0
  %727 = insertvalue { <8 x ptr>, <8 x i64> } %726, <8 x i64> %725, 1
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %727, 1
  %730 = extractelement <8 x ptr> %728, i32 0
  %731 = extractelement <8 x i64> %729, i32 0
  %732 = sub i64 %731, 0
  %733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %734 = select i1 %733, i64 %732, i64 0
  %private.contiguous.address431 = getelementptr i8, ptr %730, i64 %734
  %private.contiguous.load432 = load <8 x float>, ptr %private.contiguous.address431, align 4
  %735 = select <8 x i1> %71, <8 x float> %private.contiguous.load432, <8 x float> zeroinitializer
  %.state433 = load i64, ptr %.slot70, align 4
  %736 = add i64 960, %.state433
  %tile_snapshot.spill.load434 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load434, 0
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load434, 1
  %.splatinsert435 = insertelement <8 x i64> poison, i64 %736, i64 0
  %.splat436 = shufflevector <8 x i64> %.splatinsert435, <8 x i64> poison, <8 x i32> zeroinitializer
  %739 = mul <8 x i64> %.splat436, splat (i64 32)
  %740 = add <8 x i64> %738, %739
  %741 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %737, 0
  %742 = insertvalue { <8 x ptr>, <8 x i64> } %741, <8 x i64> %740, 1
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %742, 1
  %745 = extractelement <8 x ptr> %743, i32 0
  %746 = extractelement <8 x i64> %744, i32 0
  %747 = sub i64 %746, 0
  %748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %749 = select i1 %748, i64 %747, i64 0
  %private.contiguous.address437 = getelementptr i8, ptr %745, i64 %749
  %private.contiguous.load438 = load <8 x float>, ptr %private.contiguous.address437, align 4
  %750 = select <8 x i1> %71, <8 x float> %private.contiguous.load438, <8 x float> zeroinitializer
  %751 = fmul <8 x float> %735, %750
  %.state439 = load <8 x float>, ptr %.slot71, align 32
  %752 = fadd <8 x float> %.state439, %751
  %.state440 = load i64, ptr %.slot70, align 4
  %753 = add i64 %.state440, 1
  store i64 %753, ptr %.slot70, align 4
  %754 = load <8 x float>, ptr %.slot71, align 32
  %755 = select <8 x i1> %71, <8 x float> %752, <8 x float> %754
  store <8 x float> %755, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false426
  store i64 0, ptr %.slot72, align 4
  %756 = load <8 x float>, ptr %.slot73, align 32
  %757 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %756
  store <8 x float> %757, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state441 = load i64, ptr %.slot72, align 4
  %758 = icmp slt i64 %.state441, 80
  br i1 %758, label %direct.true442, label %direct.false443

direct.schedule.59:                               ; preds = %direct.true442
  %.state444 = load i64, ptr %.slot72, align 4
  %759 = add i64 0, %.state444
  %tile_snapshot.spill.load445 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load445, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load445, 1
  %.splatinsert446 = insertelement <8 x i64> poison, i64 %759, i64 0
  %.splat447 = shufflevector <8 x i64> %.splatinsert446, <8 x i64> poison, <8 x i32> zeroinitializer
  %762 = mul <8 x i64> %.splat447, splat (i64 32)
  %763 = add <8 x i64> %761, %762
  %764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %760, 0
  %765 = insertvalue { <8 x ptr>, <8 x i64> } %764, <8 x i64> %763, 1
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %765, 1
  %768 = extractelement <8 x ptr> %766, i32 0
  %769 = extractelement <8 x i64> %767, i32 0
  %770 = sub i64 %769, 0
  %771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %772 = select i1 %771, i64 %770, i64 0
  %private.contiguous.address448 = getelementptr i8, ptr %768, i64 %772
  %private.contiguous.load449 = load <8 x float>, ptr %private.contiguous.address448, align 4
  %773 = select <8 x i1> %71, <8 x float> %private.contiguous.load449, <8 x float> zeroinitializer
  %.state450 = load i64, ptr %.slot72, align 4
  %774 = add i64 1040, %.state450
  %tile_snapshot.spill.load451 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load451, 0
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load451, 1
  %.splatinsert452 = insertelement <8 x i64> poison, i64 %774, i64 0
  %.splat453 = shufflevector <8 x i64> %.splatinsert452, <8 x i64> poison, <8 x i32> zeroinitializer
  %777 = mul <8 x i64> %.splat453, splat (i64 32)
  %778 = add <8 x i64> %776, %777
  %779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %775, 0
  %780 = insertvalue { <8 x ptr>, <8 x i64> } %779, <8 x i64> %778, 1
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %780, 1
  %783 = extractelement <8 x ptr> %781, i32 0
  %784 = extractelement <8 x i64> %782, i32 0
  %785 = sub i64 %784, 0
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %787 = select i1 %786, i64 %785, i64 0
  %private.contiguous.address454 = getelementptr i8, ptr %783, i64 %787
  %private.contiguous.load455 = load <8 x float>, ptr %private.contiguous.address454, align 4
  %788 = select <8 x i1> %71, <8 x float> %private.contiguous.load455, <8 x float> zeroinitializer
  %789 = fmul <8 x float> %773, %788
  %.state456 = load <8 x float>, ptr %.slot73, align 32
  %790 = fadd <8 x float> %.state456, %789
  %.state457 = load i64, ptr %.slot72, align 4
  %791 = add i64 %.state457, 1
  store i64 %791, ptr %.slot72, align 4
  %792 = load <8 x float>, ptr %.slot73, align 32
  %793 = select <8 x i1> %71, <8 x float> %790, <8 x float> %792
  store <8 x float> %793, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false443
  store i64 0, ptr %.slot74, align 4
  %794 = load <8 x float>, ptr %.slot75, align 32
  %795 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %794
  store <8 x float> %795, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state458 = load i64, ptr %.slot74, align 4
  %796 = icmp slt i64 %.state458, 80
  br i1 %796, label %direct.true459, label %direct.false460

direct.schedule.62:                               ; preds = %direct.true459
  %.state461 = load i64, ptr %.slot74, align 4
  %797 = add i64 0, %.state461
  %tile_snapshot.spill.load462 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load462, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load462, 1
  %.splatinsert463 = insertelement <8 x i64> poison, i64 %797, i64 0
  %.splat464 = shufflevector <8 x i64> %.splatinsert463, <8 x i64> poison, <8 x i32> zeroinitializer
  %800 = mul <8 x i64> %.splat464, splat (i64 32)
  %801 = add <8 x i64> %799, %800
  %802 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %798, 0
  %803 = insertvalue { <8 x ptr>, <8 x i64> } %802, <8 x i64> %801, 1
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %805 = extractvalue { <8 x ptr>, <8 x i64> } %803, 1
  %806 = extractelement <8 x ptr> %804, i32 0
  %807 = extractelement <8 x i64> %805, i32 0
  %808 = sub i64 %807, 0
  %809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %810 = select i1 %809, i64 %808, i64 0
  %private.contiguous.address465 = getelementptr i8, ptr %806, i64 %810
  %private.contiguous.load466 = load <8 x float>, ptr %private.contiguous.address465, align 4
  %811 = select <8 x i1> %71, <8 x float> %private.contiguous.load466, <8 x float> zeroinitializer
  %.state467 = load i64, ptr %.slot74, align 4
  %812 = add i64 1120, %.state467
  %tile_snapshot.spill.load468 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load468, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load468, 1
  %.splatinsert469 = insertelement <8 x i64> poison, i64 %812, i64 0
  %.splat470 = shufflevector <8 x i64> %.splatinsert469, <8 x i64> poison, <8 x i32> zeroinitializer
  %815 = mul <8 x i64> %.splat470, splat (i64 32)
  %816 = add <8 x i64> %814, %815
  %817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %813, 0
  %818 = insertvalue { <8 x ptr>, <8 x i64> } %817, <8 x i64> %816, 1
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %818, 1
  %821 = extractelement <8 x ptr> %819, i32 0
  %822 = extractelement <8 x i64> %820, i32 0
  %823 = sub i64 %822, 0
  %824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %825 = select i1 %824, i64 %823, i64 0
  %private.contiguous.address471 = getelementptr i8, ptr %821, i64 %825
  %private.contiguous.load472 = load <8 x float>, ptr %private.contiguous.address471, align 4
  %826 = select <8 x i1> %71, <8 x float> %private.contiguous.load472, <8 x float> zeroinitializer
  %827 = fmul <8 x float> %811, %826
  %.state473 = load <8 x float>, ptr %.slot75, align 32
  %828 = fadd <8 x float> %.state473, %827
  %.state474 = load i64, ptr %.slot74, align 4
  %829 = add i64 %.state474, 1
  store i64 %829, ptr %.slot74, align 4
  %830 = load <8 x float>, ptr %.slot75, align 32
  %831 = select <8 x i1> %71, <8 x float> %828, <8 x float> %830
  store <8 x float> %831, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false460
  store i64 0, ptr %.slot76, align 4
  %832 = load <8 x float>, ptr %.slot77, align 32
  %833 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %832
  store <8 x float> %833, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state475 = load i64, ptr %.slot76, align 4
  %834 = icmp slt i64 %.state475, 80
  br i1 %834, label %direct.true476, label %direct.false477

direct.schedule.65:                               ; preds = %direct.true476
  %.state478 = load i64, ptr %.slot76, align 4
  %835 = add i64 0, %.state478
  %tile_snapshot.spill.load479 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load479, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load479, 1
  %.splatinsert480 = insertelement <8 x i64> poison, i64 %835, i64 0
  %.splat481 = shufflevector <8 x i64> %.splatinsert480, <8 x i64> poison, <8 x i32> zeroinitializer
  %838 = mul <8 x i64> %.splat481, splat (i64 32)
  %839 = add <8 x i64> %837, %838
  %840 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %836, 0
  %841 = insertvalue { <8 x ptr>, <8 x i64> } %840, <8 x i64> %839, 1
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %841, 1
  %844 = extractelement <8 x ptr> %842, i32 0
  %845 = extractelement <8 x i64> %843, i32 0
  %846 = sub i64 %845, 0
  %847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %848 = select i1 %847, i64 %846, i64 0
  %private.contiguous.address482 = getelementptr i8, ptr %844, i64 %848
  %private.contiguous.load483 = load <8 x float>, ptr %private.contiguous.address482, align 4
  %849 = select <8 x i1> %71, <8 x float> %private.contiguous.load483, <8 x float> zeroinitializer
  %.state484 = load i64, ptr %.slot76, align 4
  %850 = add i64 1200, %.state484
  %tile_snapshot.spill.load485 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load485, 0
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load485, 1
  %.splatinsert486 = insertelement <8 x i64> poison, i64 %850, i64 0
  %.splat487 = shufflevector <8 x i64> %.splatinsert486, <8 x i64> poison, <8 x i32> zeroinitializer
  %853 = mul <8 x i64> %.splat487, splat (i64 32)
  %854 = add <8 x i64> %852, %853
  %855 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %851, 0
  %856 = insertvalue { <8 x ptr>, <8 x i64> } %855, <8 x i64> %854, 1
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %856, 1
  %859 = extractelement <8 x ptr> %857, i32 0
  %860 = extractelement <8 x i64> %858, i32 0
  %861 = sub i64 %860, 0
  %862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %863 = select i1 %862, i64 %861, i64 0
  %private.contiguous.address488 = getelementptr i8, ptr %859, i64 %863
  %private.contiguous.load489 = load <8 x float>, ptr %private.contiguous.address488, align 4
  %864 = select <8 x i1> %71, <8 x float> %private.contiguous.load489, <8 x float> zeroinitializer
  %865 = fmul <8 x float> %849, %864
  %.state490 = load <8 x float>, ptr %.slot77, align 32
  %866 = fadd <8 x float> %.state490, %865
  %.state491 = load i64, ptr %.slot76, align 4
  %867 = add i64 %.state491, 1
  store i64 %867, ptr %.slot76, align 4
  %868 = load <8 x float>, ptr %.slot77, align 32
  %869 = select <8 x i1> %71, <8 x float> %866, <8 x float> %868
  store <8 x float> %869, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false477
  %.state492 = load <8 x float>, ptr %.slot47, align 32
  %870 = fmul <8 x float> %.state492, splat (float 0x3FBC9F25C0000000)
  %.state493 = load <8 x float>, ptr %.slot49, align 32
  %871 = fmul <8 x float> %.state493, splat (float 0x3FBC9F25C0000000)
  %.state494 = load <8 x float>, ptr %.slot51, align 32
  %872 = fmul <8 x float> %.state494, splat (float 0x3FBC9F25C0000000)
  %.state495 = load <8 x float>, ptr %.slot53, align 32
  %873 = fmul <8 x float> %.state495, splat (float 0x3FBC9F25C0000000)
  %.state496 = load <8 x float>, ptr %.slot55, align 32
  %874 = fmul <8 x float> %.state496, splat (float 0x3FBC9F25C0000000)
  %.state497 = load <8 x float>, ptr %.slot57, align 32
  %875 = fmul <8 x float> %.state497, splat (float 0x3FBC9F25C0000000)
  %.state498 = load <8 x float>, ptr %.slot59, align 32
  %876 = fmul <8 x float> %.state498, splat (float 0x3FBC9F25C0000000)
  %.state499 = load <8 x float>, ptr %.slot61, align 32
  %877 = fmul <8 x float> %.state499, splat (float 0x3FBC9F25C0000000)
  %.state500 = load <8 x float>, ptr %.slot63, align 32
  %878 = fmul <8 x float> %.state500, splat (float 0x3FBC9F25C0000000)
  %.state501 = load <8 x float>, ptr %.slot65, align 32
  %879 = fmul <8 x float> %.state501, splat (float 0x3FBC9F25C0000000)
  %.state502 = load <8 x float>, ptr %.slot67, align 32
  %880 = fmul <8 x float> %.state502, splat (float 0x3FBC9F25C0000000)
  %.state503 = load <8 x float>, ptr %.slot69, align 32
  %881 = fmul <8 x float> %.state503, splat (float 0x3FBC9F25C0000000)
  %.state504 = load <8 x float>, ptr %.slot71, align 32
  %882 = fmul <8 x float> %.state504, splat (float 0x3FBC9F25C0000000)
  %.state505 = load <8 x float>, ptr %.slot73, align 32
  %883 = fmul <8 x float> %.state505, splat (float 0x3FBC9F25C0000000)
  %.state506 = load <8 x float>, ptr %.slot75, align 32
  %884 = fmul <8 x float> %.state506, splat (float 0x3FBC9F25C0000000)
  %.state507 = load <8 x float>, ptr %.slot77, align 32
  %885 = fmul <8 x float> %.state507, splat (float 0x3FBC9F25C0000000)
  %.spill.load508 = load i64, ptr %.spill37, align 4
  %886 = add i64 0, %.spill.load508
  %.spill.load509 = load i64, ptr %.spill37, align 4
  %887 = add i64 1, %.spill.load509
  %.spill.load510 = load i64, ptr %.spill37, align 4
  %888 = add i64 2, %.spill.load510
  %.spill.load511 = load i64, ptr %.spill37, align 4
  %889 = add i64 3, %.spill.load511
  %.spill.load512 = load i64, ptr %.spill37, align 4
  %890 = add i64 4, %.spill.load512
  %.spill.load513 = load i64, ptr %.spill37, align 4
  %891 = add i64 5, %.spill.load513
  %.spill.load514 = load i64, ptr %.spill37, align 4
  %892 = add i64 6, %.spill.load514
  %.spill.load515 = load i64, ptr %.spill37, align 4
  %893 = add i64 7, %.spill.load515
  %.spill.load516 = load i64, ptr %.spill37, align 4
  %894 = add i64 8, %.spill.load516
  %.spill.load517 = load i64, ptr %.spill37, align 4
  %895 = add i64 9, %.spill.load517
  %.spill.load518 = load i64, ptr %.spill37, align 4
  %896 = add i64 10, %.spill.load518
  %.spill.load519 = load i64, ptr %.spill37, align 4
  %897 = add i64 11, %.spill.load519
  %.spill.load520 = load i64, ptr %.spill37, align 4
  %898 = add i64 12, %.spill.load520
  %.spill.load521 = load i64, ptr %.spill37, align 4
  %899 = add i64 13, %.spill.load521
  %.spill.load522 = load i64, ptr %.spill37, align 4
  %900 = add i64 14, %.spill.load522
  %.spill.load523 = load i64, ptr %.spill37, align 4
  %901 = add i64 15, %.spill.load523
  %902 = icmp slt i64 %886, 2053
  %903 = icmp slt i64 %887, 2053
  %904 = icmp slt i64 %888, 2053
  %905 = icmp slt i64 %889, 2053
  %906 = icmp slt i64 %890, 2053
  %907 = icmp slt i64 %891, 2053
  %908 = icmp slt i64 %892, 2053
  %909 = icmp slt i64 %893, 2053
  %910 = icmp slt i64 %894, 2053
  %911 = icmp slt i64 %895, 2053
  %912 = icmp slt i64 %896, 2053
  %913 = icmp slt i64 %897, 2053
  %914 = icmp slt i64 %898, 2053
  %915 = icmp slt i64 %899, 2053
  %916 = icmp slt i64 %900, 2053
  %917 = icmp slt i64 %901, 2053
  %.spill.load524 = load i64, ptr %.spill29, align 4
  %918 = add i64 0, %.spill.load524
  store i64 %918, ptr %.spill78, align 4
  %919 = add i64 %918, 2053
  %920 = sub i64 %919, 1
  %921 = icmp sle i64 %886, %920
  %922 = icmp sle i64 %887, %920
  %923 = icmp sle i64 %888, %920
  %924 = icmp sle i64 %889, %920
  %925 = icmp sle i64 %890, %920
  %926 = icmp sle i64 %891, %920
  %927 = icmp sle i64 %892, %920
  %928 = icmp sle i64 %893, %920
  %929 = icmp sle i64 %894, %920
  %930 = icmp sle i64 %895, %920
  %931 = icmp sle i64 %896, %920
  %932 = icmp sle i64 %897, %920
  %933 = icmp sle i64 %898, %920
  %934 = icmp sle i64 %899, %920
  %935 = icmp sle i64 %900, %920
  %936 = icmp sle i64 %901, %920
  %937 = and i1 %902, %921
  store i1 %937, ptr %.spill79, align 1
  %938 = and i1 %903, %922
  store i1 %938, ptr %.spill80, align 1
  %939 = and i1 %904, %923
  store i1 %939, ptr %.spill81, align 1
  %940 = and i1 %905, %924
  store i1 %940, ptr %.spill82, align 1
  %941 = and i1 %906, %925
  store i1 %941, ptr %.spill83, align 1
  %942 = and i1 %907, %926
  store i1 %942, ptr %.spill84, align 1
  %943 = and i1 %908, %927
  store i1 %943, ptr %.spill85, align 1
  %944 = and i1 %909, %928
  store i1 %944, ptr %.spill86, align 1
  %945 = and i1 %910, %929
  store i1 %945, ptr %.spill87, align 1
  %946 = and i1 %911, %930
  store i1 %946, ptr %.spill88, align 1
  %947 = and i1 %912, %931
  store i1 %947, ptr %.spill89, align 1
  %948 = and i1 %913, %932
  store i1 %948, ptr %.spill90, align 1
  %949 = and i1 %914, %933
  store i1 %949, ptr %.spill91, align 1
  %950 = and i1 %915, %934
  store i1 %950, ptr %.spill92, align 1
  %951 = and i1 %916, %935
  store i1 %951, ptr %.spill93, align 1
  %952 = and i1 %917, %936
  store i1 %952, ptr %.spill94, align 1
  %.splatinsert525 = insertelement <8 x i1> poison, i1 %937, i64 0
  %.splat526 = shufflevector <8 x i1> %.splatinsert525, <8 x i1> poison, <8 x i32> zeroinitializer
  %953 = select <8 x i1> %.splat526, <8 x float> %870, <8 x float> splat (float 0xC6293E5940000000)
  %954 = load <8 x float>, ptr %.spill95, align 32
  %955 = select <8 x i1> %71, <8 x float> %953, <8 x float> %954
  store <8 x float> %955, ptr %.spill95, align 32
  %.splatinsert527 = insertelement <8 x i1> poison, i1 %938, i64 0
  %.splat528 = shufflevector <8 x i1> %.splatinsert527, <8 x i1> poison, <8 x i32> zeroinitializer
  %956 = select <8 x i1> %.splat528, <8 x float> %871, <8 x float> splat (float 0xC6293E5940000000)
  %957 = load <8 x float>, ptr %.spill96, align 32
  %958 = select <8 x i1> %71, <8 x float> %956, <8 x float> %957
  store <8 x float> %958, ptr %.spill96, align 32
  %.splatinsert529 = insertelement <8 x i1> poison, i1 %939, i64 0
  %.splat530 = shufflevector <8 x i1> %.splatinsert529, <8 x i1> poison, <8 x i32> zeroinitializer
  %959 = select <8 x i1> %.splat530, <8 x float> %872, <8 x float> splat (float 0xC6293E5940000000)
  %960 = load <8 x float>, ptr %.spill97, align 32
  %961 = select <8 x i1> %71, <8 x float> %959, <8 x float> %960
  store <8 x float> %961, ptr %.spill97, align 32
  %.splatinsert531 = insertelement <8 x i1> poison, i1 %940, i64 0
  %.splat532 = shufflevector <8 x i1> %.splatinsert531, <8 x i1> poison, <8 x i32> zeroinitializer
  %962 = select <8 x i1> %.splat532, <8 x float> %873, <8 x float> splat (float 0xC6293E5940000000)
  %963 = load <8 x float>, ptr %.spill98, align 32
  %964 = select <8 x i1> %71, <8 x float> %962, <8 x float> %963
  store <8 x float> %964, ptr %.spill98, align 32
  %.splatinsert533 = insertelement <8 x i1> poison, i1 %941, i64 0
  %.splat534 = shufflevector <8 x i1> %.splatinsert533, <8 x i1> poison, <8 x i32> zeroinitializer
  %965 = select <8 x i1> %.splat534, <8 x float> %874, <8 x float> splat (float 0xC6293E5940000000)
  %966 = load <8 x float>, ptr %.spill99, align 32
  %967 = select <8 x i1> %71, <8 x float> %965, <8 x float> %966
  store <8 x float> %967, ptr %.spill99, align 32
  %.splatinsert535 = insertelement <8 x i1> poison, i1 %942, i64 0
  %.splat536 = shufflevector <8 x i1> %.splatinsert535, <8 x i1> poison, <8 x i32> zeroinitializer
  %968 = select <8 x i1> %.splat536, <8 x float> %875, <8 x float> splat (float 0xC6293E5940000000)
  %969 = load <8 x float>, ptr %.spill100, align 32
  %970 = select <8 x i1> %71, <8 x float> %968, <8 x float> %969
  store <8 x float> %970, ptr %.spill100, align 32
  %.splatinsert537 = insertelement <8 x i1> poison, i1 %943, i64 0
  %.splat538 = shufflevector <8 x i1> %.splatinsert537, <8 x i1> poison, <8 x i32> zeroinitializer
  %971 = select <8 x i1> %.splat538, <8 x float> %876, <8 x float> splat (float 0xC6293E5940000000)
  %972 = load <8 x float>, ptr %.spill101, align 32
  %973 = select <8 x i1> %71, <8 x float> %971, <8 x float> %972
  store <8 x float> %973, ptr %.spill101, align 32
  %.splatinsert539 = insertelement <8 x i1> poison, i1 %944, i64 0
  %.splat540 = shufflevector <8 x i1> %.splatinsert539, <8 x i1> poison, <8 x i32> zeroinitializer
  %974 = select <8 x i1> %.splat540, <8 x float> %877, <8 x float> splat (float 0xC6293E5940000000)
  %975 = load <8 x float>, ptr %.spill102, align 32
  %976 = select <8 x i1> %71, <8 x float> %974, <8 x float> %975
  store <8 x float> %976, ptr %.spill102, align 32
  %.splatinsert541 = insertelement <8 x i1> poison, i1 %945, i64 0
  %.splat542 = shufflevector <8 x i1> %.splatinsert541, <8 x i1> poison, <8 x i32> zeroinitializer
  %977 = select <8 x i1> %.splat542, <8 x float> %878, <8 x float> splat (float 0xC6293E5940000000)
  %978 = load <8 x float>, ptr %.spill103, align 32
  %979 = select <8 x i1> %71, <8 x float> %977, <8 x float> %978
  store <8 x float> %979, ptr %.spill103, align 32
  %.splatinsert543 = insertelement <8 x i1> poison, i1 %946, i64 0
  %.splat544 = shufflevector <8 x i1> %.splatinsert543, <8 x i1> poison, <8 x i32> zeroinitializer
  %980 = select <8 x i1> %.splat544, <8 x float> %879, <8 x float> splat (float 0xC6293E5940000000)
  %981 = load <8 x float>, ptr %.spill104, align 32
  %982 = select <8 x i1> %71, <8 x float> %980, <8 x float> %981
  store <8 x float> %982, ptr %.spill104, align 32
  %.splatinsert545 = insertelement <8 x i1> poison, i1 %947, i64 0
  %.splat546 = shufflevector <8 x i1> %.splatinsert545, <8 x i1> poison, <8 x i32> zeroinitializer
  %983 = select <8 x i1> %.splat546, <8 x float> %880, <8 x float> splat (float 0xC6293E5940000000)
  %984 = load <8 x float>, ptr %.spill105, align 32
  %985 = select <8 x i1> %71, <8 x float> %983, <8 x float> %984
  store <8 x float> %985, ptr %.spill105, align 32
  %.splatinsert547 = insertelement <8 x i1> poison, i1 %948, i64 0
  %.splat548 = shufflevector <8 x i1> %.splatinsert547, <8 x i1> poison, <8 x i32> zeroinitializer
  %986 = select <8 x i1> %.splat548, <8 x float> %881, <8 x float> splat (float 0xC6293E5940000000)
  %987 = load <8 x float>, ptr %.spill106, align 32
  %988 = select <8 x i1> %71, <8 x float> %986, <8 x float> %987
  store <8 x float> %988, ptr %.spill106, align 32
  %.splatinsert549 = insertelement <8 x i1> poison, i1 %949, i64 0
  %.splat550 = shufflevector <8 x i1> %.splatinsert549, <8 x i1> poison, <8 x i32> zeroinitializer
  %989 = select <8 x i1> %.splat550, <8 x float> %882, <8 x float> splat (float 0xC6293E5940000000)
  %990 = load <8 x float>, ptr %.spill107, align 32
  %991 = select <8 x i1> %71, <8 x float> %989, <8 x float> %990
  store <8 x float> %991, ptr %.spill107, align 32
  %.splatinsert551 = insertelement <8 x i1> poison, i1 %950, i64 0
  %.splat552 = shufflevector <8 x i1> %.splatinsert551, <8 x i1> poison, <8 x i32> zeroinitializer
  %992 = select <8 x i1> %.splat552, <8 x float> %883, <8 x float> splat (float 0xC6293E5940000000)
  %993 = load <8 x float>, ptr %.spill108, align 32
  %994 = select <8 x i1> %71, <8 x float> %992, <8 x float> %993
  store <8 x float> %994, ptr %.spill108, align 32
  %.splatinsert553 = insertelement <8 x i1> poison, i1 %951, i64 0
  %.splat554 = shufflevector <8 x i1> %.splatinsert553, <8 x i1> poison, <8 x i32> zeroinitializer
  %995 = select <8 x i1> %.splat554, <8 x float> %884, <8 x float> splat (float 0xC6293E5940000000)
  %996 = load <8 x float>, ptr %.spill109, align 32
  %997 = select <8 x i1> %71, <8 x float> %995, <8 x float> %996
  store <8 x float> %997, ptr %.spill109, align 32
  %.splatinsert555 = insertelement <8 x i1> poison, i1 %952, i64 0
  %.splat556 = shufflevector <8 x i1> %.splatinsert555, <8 x i1> poison, <8 x i32> zeroinitializer
  %998 = select <8 x i1> %.splat556, <8 x float> %885, <8 x float> splat (float 0xC6293E5940000000)
  %999 = load <8 x float>, ptr %.spill110, align 32
  %1000 = select <8 x i1> %71, <8 x float> %998, <8 x float> %999
  store <8 x float> %1000, ptr %.spill110, align 32
  %1001 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 0
  %1004 = select <8 x i1> %71, <8 x ptr> %1002, <8 x ptr> %1003
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 1
  %1007 = select <8 x i1> %71, <8 x i64> %1005, <8 x i64> %1006
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1004, 0
  %1009 = insertvalue { <8 x ptr>, <8 x i64> } %1008, <8 x i64> %1007, 1
  store { <8 x ptr>, <8 x i64> } %1009, ptr %tile_snapshot.spill111, align 64
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1012 = add <8 x i64> %1011, zeroinitializer
  %1013 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1010, 0
  %1014 = insertvalue { <8 x ptr>, <8 x i64> } %1013, <8 x i64> %1012, 1
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %1014, 1
  %1017 = extractelement <8 x ptr> %1015, i32 0
  %1018 = extractelement <8 x i64> %1016, i32 0
  %1019 = sub i64 %1018, 0
  %1020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1021 = select i1 %1020, i64 %1019, i64 0
  %private.contiguous.address557 = getelementptr i8, ptr %1017, i64 %1021
  %private.contiguous.preserve558 = load <8 x float>, ptr %private.contiguous.address557, align 4
  %1022 = select <8 x i1> %71, <8 x float> %953, <8 x float> %private.contiguous.preserve558
  store <8 x float> %1022, ptr %private.contiguous.address557, align 4
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1025 = add <8 x i64> %1024, splat (i64 32)
  %1026 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1023, 0
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } %1026, <8 x i64> %1025, 1
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1027, 1
  %1030 = extractelement <8 x ptr> %1028, i32 0
  %1031 = extractelement <8 x i64> %1029, i32 0
  %1032 = sub i64 %1031, 0
  %1033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1034 = select i1 %1033, i64 %1032, i64 0
  %private.contiguous.address559 = getelementptr i8, ptr %1030, i64 %1034
  %private.contiguous.preserve560 = load <8 x float>, ptr %private.contiguous.address559, align 4
  %1035 = select <8 x i1> %71, <8 x float> %956, <8 x float> %private.contiguous.preserve560
  store <8 x float> %1035, ptr %private.contiguous.address559, align 4
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1038 = add <8 x i64> %1037, splat (i64 64)
  %1039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1036, 0
  %1040 = insertvalue { <8 x ptr>, <8 x i64> } %1039, <8 x i64> %1038, 1
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %1040, 1
  %1043 = extractelement <8 x ptr> %1041, i32 0
  %1044 = extractelement <8 x i64> %1042, i32 0
  %1045 = sub i64 %1044, 0
  %1046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1047 = select i1 %1046, i64 %1045, i64 0
  %private.contiguous.address561 = getelementptr i8, ptr %1043, i64 %1047
  %private.contiguous.preserve562 = load <8 x float>, ptr %private.contiguous.address561, align 4
  %1048 = select <8 x i1> %71, <8 x float> %959, <8 x float> %private.contiguous.preserve562
  store <8 x float> %1048, ptr %private.contiguous.address561, align 4
  %1049 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1051 = add <8 x i64> %1050, splat (i64 96)
  %1052 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1049, 0
  %1053 = insertvalue { <8 x ptr>, <8 x i64> } %1052, <8 x i64> %1051, 1
  %1054 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %1053, 1
  %1056 = extractelement <8 x ptr> %1054, i32 0
  %1057 = extractelement <8 x i64> %1055, i32 0
  %1058 = sub i64 %1057, 0
  %1059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1060 = select i1 %1059, i64 %1058, i64 0
  %private.contiguous.address563 = getelementptr i8, ptr %1056, i64 %1060
  %private.contiguous.preserve564 = load <8 x float>, ptr %private.contiguous.address563, align 4
  %1061 = select <8 x i1> %71, <8 x float> %962, <8 x float> %private.contiguous.preserve564
  store <8 x float> %1061, ptr %private.contiguous.address563, align 4
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1064 = add <8 x i64> %1063, splat (i64 128)
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1062, 0
  %1066 = insertvalue { <8 x ptr>, <8 x i64> } %1065, <8 x i64> %1064, 1
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %1066, 1
  %1069 = extractelement <8 x ptr> %1067, i32 0
  %1070 = extractelement <8 x i64> %1068, i32 0
  %1071 = sub i64 %1070, 0
  %1072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1073 = select i1 %1072, i64 %1071, i64 0
  %private.contiguous.address565 = getelementptr i8, ptr %1069, i64 %1073
  %private.contiguous.preserve566 = load <8 x float>, ptr %private.contiguous.address565, align 4
  %1074 = select <8 x i1> %71, <8 x float> %965, <8 x float> %private.contiguous.preserve566
  store <8 x float> %1074, ptr %private.contiguous.address565, align 4
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1077 = add <8 x i64> %1076, splat (i64 160)
  %1078 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1075, 0
  %1079 = insertvalue { <8 x ptr>, <8 x i64> } %1078, <8 x i64> %1077, 1
  %1080 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %1079, 1
  %1082 = extractelement <8 x ptr> %1080, i32 0
  %1083 = extractelement <8 x i64> %1081, i32 0
  %1084 = sub i64 %1083, 0
  %1085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1086 = select i1 %1085, i64 %1084, i64 0
  %private.contiguous.address567 = getelementptr i8, ptr %1082, i64 %1086
  %private.contiguous.preserve568 = load <8 x float>, ptr %private.contiguous.address567, align 4
  %1087 = select <8 x i1> %71, <8 x float> %968, <8 x float> %private.contiguous.preserve568
  store <8 x float> %1087, ptr %private.contiguous.address567, align 4
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1090 = add <8 x i64> %1089, splat (i64 192)
  %1091 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1088, 0
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } %1091, <8 x i64> %1090, 1
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %1092, 1
  %1095 = extractelement <8 x ptr> %1093, i32 0
  %1096 = extractelement <8 x i64> %1094, i32 0
  %1097 = sub i64 %1096, 0
  %1098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1099 = select i1 %1098, i64 %1097, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %1095, i64 %1099
  %private.contiguous.preserve570 = load <8 x float>, ptr %private.contiguous.address569, align 4
  %1100 = select <8 x i1> %71, <8 x float> %971, <8 x float> %private.contiguous.preserve570
  store <8 x float> %1100, ptr %private.contiguous.address569, align 4
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1103 = add <8 x i64> %1102, splat (i64 224)
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1101, 0
  %1105 = insertvalue { <8 x ptr>, <8 x i64> } %1104, <8 x i64> %1103, 1
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %1105, 1
  %1108 = extractelement <8 x ptr> %1106, i32 0
  %1109 = extractelement <8 x i64> %1107, i32 0
  %1110 = sub i64 %1109, 0
  %1111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1112 = select i1 %1111, i64 %1110, i64 0
  %private.contiguous.address571 = getelementptr i8, ptr %1108, i64 %1112
  %private.contiguous.preserve572 = load <8 x float>, ptr %private.contiguous.address571, align 4
  %1113 = select <8 x i1> %71, <8 x float> %974, <8 x float> %private.contiguous.preserve572
  store <8 x float> %1113, ptr %private.contiguous.address571, align 4
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1116 = add <8 x i64> %1115, splat (i64 256)
  %1117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1114, 0
  %1118 = insertvalue { <8 x ptr>, <8 x i64> } %1117, <8 x i64> %1116, 1
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 1
  %1121 = extractelement <8 x ptr> %1119, i32 0
  %1122 = extractelement <8 x i64> %1120, i32 0
  %1123 = sub i64 %1122, 0
  %1124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1125 = select i1 %1124, i64 %1123, i64 0
  %private.contiguous.address573 = getelementptr i8, ptr %1121, i64 %1125
  %private.contiguous.preserve574 = load <8 x float>, ptr %private.contiguous.address573, align 4
  %1126 = select <8 x i1> %71, <8 x float> %977, <8 x float> %private.contiguous.preserve574
  store <8 x float> %1126, ptr %private.contiguous.address573, align 4
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1129 = add <8 x i64> %1128, splat (i64 288)
  %1130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1127, 0
  %1131 = insertvalue { <8 x ptr>, <8 x i64> } %1130, <8 x i64> %1129, 1
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %1131, 1
  %1134 = extractelement <8 x ptr> %1132, i32 0
  %1135 = extractelement <8 x i64> %1133, i32 0
  %1136 = sub i64 %1135, 0
  %1137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1138 = select i1 %1137, i64 %1136, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %1134, i64 %1138
  %private.contiguous.preserve576 = load <8 x float>, ptr %private.contiguous.address575, align 4
  %1139 = select <8 x i1> %71, <8 x float> %980, <8 x float> %private.contiguous.preserve576
  store <8 x float> %1139, ptr %private.contiguous.address575, align 4
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1142 = add <8 x i64> %1141, splat (i64 320)
  %1143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1140, 0
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } %1143, <8 x i64> %1142, 1
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %1144, 1
  %1147 = extractelement <8 x ptr> %1145, i32 0
  %1148 = extractelement <8 x i64> %1146, i32 0
  %1149 = sub i64 %1148, 0
  %1150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1151 = select i1 %1150, i64 %1149, i64 0
  %private.contiguous.address577 = getelementptr i8, ptr %1147, i64 %1151
  %private.contiguous.preserve578 = load <8 x float>, ptr %private.contiguous.address577, align 4
  %1152 = select <8 x i1> %71, <8 x float> %983, <8 x float> %private.contiguous.preserve578
  store <8 x float> %1152, ptr %private.contiguous.address577, align 4
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1155 = add <8 x i64> %1154, splat (i64 352)
  %1156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1153, 0
  %1157 = insertvalue { <8 x ptr>, <8 x i64> } %1156, <8 x i64> %1155, 1
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %1157, 1
  %1160 = extractelement <8 x ptr> %1158, i32 0
  %1161 = extractelement <8 x i64> %1159, i32 0
  %1162 = sub i64 %1161, 0
  %1163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1164 = select i1 %1163, i64 %1162, i64 0
  %private.contiguous.address579 = getelementptr i8, ptr %1160, i64 %1164
  %private.contiguous.preserve580 = load <8 x float>, ptr %private.contiguous.address579, align 4
  %1165 = select <8 x i1> %71, <8 x float> %986, <8 x float> %private.contiguous.preserve580
  store <8 x float> %1165, ptr %private.contiguous.address579, align 4
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1168 = add <8 x i64> %1167, splat (i64 384)
  %1169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1166, 0
  %1170 = insertvalue { <8 x ptr>, <8 x i64> } %1169, <8 x i64> %1168, 1
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %1170, 1
  %1173 = extractelement <8 x ptr> %1171, i32 0
  %1174 = extractelement <8 x i64> %1172, i32 0
  %1175 = sub i64 %1174, 0
  %1176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1177 = select i1 %1176, i64 %1175, i64 0
  %private.contiguous.address581 = getelementptr i8, ptr %1173, i64 %1177
  %private.contiguous.preserve582 = load <8 x float>, ptr %private.contiguous.address581, align 4
  %1178 = select <8 x i1> %71, <8 x float> %989, <8 x float> %private.contiguous.preserve582
  store <8 x float> %1178, ptr %private.contiguous.address581, align 4
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1181 = add <8 x i64> %1180, splat (i64 416)
  %1182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1179, 0
  %1183 = insertvalue { <8 x ptr>, <8 x i64> } %1182, <8 x i64> %1181, 1
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %1183, 1
  %1186 = extractelement <8 x ptr> %1184, i32 0
  %1187 = extractelement <8 x i64> %1185, i32 0
  %1188 = sub i64 %1187, 0
  %1189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1190 = select i1 %1189, i64 %1188, i64 0
  %private.contiguous.address583 = getelementptr i8, ptr %1186, i64 %1190
  %private.contiguous.preserve584 = load <8 x float>, ptr %private.contiguous.address583, align 4
  %1191 = select <8 x i1> %71, <8 x float> %992, <8 x float> %private.contiguous.preserve584
  store <8 x float> %1191, ptr %private.contiguous.address583, align 4
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1193 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1194 = add <8 x i64> %1193, splat (i64 448)
  %1195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1192, 0
  %1196 = insertvalue { <8 x ptr>, <8 x i64> } %1195, <8 x i64> %1194, 1
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 1
  %1199 = extractelement <8 x ptr> %1197, i32 0
  %1200 = extractelement <8 x i64> %1198, i32 0
  %1201 = sub i64 %1200, 0
  %1202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1203 = select i1 %1202, i64 %1201, i64 0
  %private.contiguous.address585 = getelementptr i8, ptr %1199, i64 %1203
  %private.contiguous.preserve586 = load <8 x float>, ptr %private.contiguous.address585, align 4
  %1204 = select <8 x i1> %71, <8 x float> %995, <8 x float> %private.contiguous.preserve586
  store <8 x float> %1204, ptr %private.contiguous.address585, align 4
  %1205 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1207 = add <8 x i64> %1206, splat (i64 480)
  %1208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1205, 0
  %1209 = insertvalue { <8 x ptr>, <8 x i64> } %1208, <8 x i64> %1207, 1
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1211 = extractvalue { <8 x ptr>, <8 x i64> } %1209, 1
  %1212 = extractelement <8 x ptr> %1210, i32 0
  %1213 = extractelement <8 x i64> %1211, i32 0
  %1214 = sub i64 %1213, 0
  %1215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1216 = select i1 %1215, i64 %1214, i64 0
  %private.contiguous.address587 = getelementptr i8, ptr %1212, i64 %1216
  %private.contiguous.preserve588 = load <8 x float>, ptr %private.contiguous.address587, align 4
  %1217 = select <8 x i1> %71, <8 x float> %998, <8 x float> %private.contiguous.preserve588
  store <8 x float> %1217, ptr %private.contiguous.address587, align 4
  store i64 0, ptr %.slot112, align 4
  %1218 = load <8 x float>, ptr %.slot113, align 32
  %1219 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1218
  store <8 x float> %1219, ptr %.slot113, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state589 = load i64, ptr %.slot112, align 4
  %1220 = icmp slt i64 %.state589, 16
  br i1 %1220, label %direct.true590, label %direct.false591

direct.schedule.68:                               ; preds = %direct.true590
  %.state592 = load i64, ptr %.slot112, align 4
  %1221 = sdiv i64 %.state592, 1
  %.spill.load593 = load i64, ptr %.spill78, align 4
  %1222 = mul i64 %.spill.load593, 1
  %1223 = add i64 %1222, 0
  %1224 = mul i64 %1223, 1
  %1225 = add i64 %1224, 0
  %1226 = mul i64 %1225, 16
  %1227 = add i64 %1226, %1221
  %tile_snapshot.spill.load594 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load594, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load594, 1
  %.splatinsert595 = insertelement <8 x i64> poison, i64 %1227, i64 0
  %.splat596 = shufflevector <8 x i64> %.splatinsert595, <8 x i64> poison, <8 x i32> zeroinitializer
  %1230 = mul <8 x i64> %.splat596, splat (i64 32)
  %1231 = add <8 x i64> %1229, %1230
  %1232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1228, 0
  %1233 = insertvalue { <8 x ptr>, <8 x i64> } %1232, <8 x i64> %1231, 1
  %1234 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1235 = extractvalue { <8 x ptr>, <8 x i64> } %1233, 1
  %1236 = extractelement <8 x ptr> %1234, i32 0
  %1237 = extractelement <8 x i64> %1235, i32 0
  %1238 = sub i64 %1237, 0
  %1239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1240 = select i1 %1239, i64 %1238, i64 0
  %private.contiguous.address597 = getelementptr i8, ptr %1236, i64 %1240
  %private.contiguous.load598 = load <8 x float>, ptr %private.contiguous.address597, align 4
  %1241 = select <8 x i1> %71, <8 x float> %private.contiguous.load598, <8 x float> zeroinitializer
  %.state599 = load <8 x float>, ptr %.slot113, align 32
  %1242 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state599, <8 x float> %1241)
  %.state600 = load i64, ptr %.slot112, align 4
  %1243 = add i64 %.state600, 1
  store i64 %1243, ptr %.slot112, align 4
  %1244 = load <8 x float>, ptr %.slot113, align 32
  %1245 = select <8 x i1> %71, <8 x float> %1242, <8 x float> %1244
  store <8 x float> %1245, ptr %.slot113, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false591
  %.state601 = load <8 x float>, ptr %.slot35, align 32
  %.state602 = load <8 x float>, ptr %.slot113, align 32
  %1246 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state601, <8 x float> %.state602)
  %1247 = load <8 x float>, ptr %.spill114, align 32
  %1248 = select <8 x i1> %71, <8 x float> %1246, <8 x float> %1247
  store <8 x float> %1248, ptr %.spill114, align 32
  %.state603 = load <8 x float>, ptr %.slot35, align 32
  %1249 = fsub <8 x float> %.state603, %1246
  %1250 = select <8 x i1> %71, <8 x float> %1249, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1250)
  %1251 = load <8 x float>, ptr %.spill115, align 32
  %1252 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %1251
  store <8 x float> %1252, ptr %.spill115, align 32
  %.spill.load604 = load <8 x float>, ptr %.spill95, align 32
  %1253 = fsub <8 x float> %.spill.load604, %1246
  %.spill.load605 = load <8 x float>, ptr %.spill96, align 32
  %1254 = fsub <8 x float> %.spill.load605, %1246
  %.spill.load606 = load <8 x float>, ptr %.spill97, align 32
  %1255 = fsub <8 x float> %.spill.load606, %1246
  %.spill.load607 = load <8 x float>, ptr %.spill98, align 32
  %1256 = fsub <8 x float> %.spill.load607, %1246
  %.spill.load608 = load <8 x float>, ptr %.spill99, align 32
  %1257 = fsub <8 x float> %.spill.load608, %1246
  %.spill.load609 = load <8 x float>, ptr %.spill100, align 32
  %1258 = fsub <8 x float> %.spill.load609, %1246
  %.spill.load610 = load <8 x float>, ptr %.spill101, align 32
  %1259 = fsub <8 x float> %.spill.load610, %1246
  %.spill.load611 = load <8 x float>, ptr %.spill102, align 32
  %1260 = fsub <8 x float> %.spill.load611, %1246
  %.spill.load612 = load <8 x float>, ptr %.spill103, align 32
  %1261 = fsub <8 x float> %.spill.load612, %1246
  %.spill.load613 = load <8 x float>, ptr %.spill104, align 32
  %1262 = fsub <8 x float> %.spill.load613, %1246
  %.spill.load614 = load <8 x float>, ptr %.spill105, align 32
  %1263 = fsub <8 x float> %.spill.load614, %1246
  %.spill.load615 = load <8 x float>, ptr %.spill106, align 32
  %1264 = fsub <8 x float> %.spill.load615, %1246
  %.spill.load616 = load <8 x float>, ptr %.spill107, align 32
  %1265 = fsub <8 x float> %.spill.load616, %1246
  %.spill.load617 = load <8 x float>, ptr %.spill108, align 32
  %1266 = fsub <8 x float> %.spill.load617, %1246
  %.spill.load618 = load <8 x float>, ptr %.spill109, align 32
  %1267 = fsub <8 x float> %.spill.load618, %1246
  %.spill.load619 = load <8 x float>, ptr %.spill110, align 32
  %1268 = fsub <8 x float> %.spill.load619, %1246
  %1269 = select <8 x i1> %71, <8 x float> %1253, <8 x float> zeroinitializer
  %native.exp620 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1269)
  %1270 = select <8 x i1> %71, <8 x float> %1254, <8 x float> zeroinitializer
  %native.exp621 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1270)
  %1271 = select <8 x i1> %71, <8 x float> %1255, <8 x float> zeroinitializer
  %native.exp622 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1271)
  %1272 = select <8 x i1> %71, <8 x float> %1256, <8 x float> zeroinitializer
  %native.exp623 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1272)
  %1273 = select <8 x i1> %71, <8 x float> %1257, <8 x float> zeroinitializer
  %native.exp624 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1273)
  %1274 = select <8 x i1> %71, <8 x float> %1258, <8 x float> zeroinitializer
  %native.exp625 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1274)
  %1275 = select <8 x i1> %71, <8 x float> %1259, <8 x float> zeroinitializer
  %native.exp626 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1275)
  %1276 = select <8 x i1> %71, <8 x float> %1260, <8 x float> zeroinitializer
  %native.exp627 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1276)
  %1277 = select <8 x i1> %71, <8 x float> %1261, <8 x float> zeroinitializer
  %native.exp628 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1277)
  %1278 = select <8 x i1> %71, <8 x float> %1262, <8 x float> zeroinitializer
  %native.exp629 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1278)
  %1279 = select <8 x i1> %71, <8 x float> %1263, <8 x float> zeroinitializer
  %native.exp630 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1279)
  %1280 = select <8 x i1> %71, <8 x float> %1264, <8 x float> zeroinitializer
  %native.exp631 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1280)
  %1281 = select <8 x i1> %71, <8 x float> %1265, <8 x float> zeroinitializer
  %native.exp632 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1281)
  %1282 = select <8 x i1> %71, <8 x float> %1266, <8 x float> zeroinitializer
  %native.exp633 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1282)
  %1283 = select <8 x i1> %71, <8 x float> %1267, <8 x float> zeroinitializer
  %native.exp634 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1283)
  %1284 = select <8 x i1> %71, <8 x float> %1268, <8 x float> zeroinitializer
  %native.exp635 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1284)
  %.spill.load636 = load i1, ptr %.spill79, align 1
  %.splatinsert637 = insertelement <8 x i1> poison, i1 %.spill.load636, i64 0
  %.splat638 = shufflevector <8 x i1> %.splatinsert637, <8 x i1> poison, <8 x i32> zeroinitializer
  %1285 = select <8 x i1> %.splat638, <8 x float> %native.exp620, <8 x float> zeroinitializer
  %.spill.load639 = load i1, ptr %.spill80, align 1
  %.splatinsert640 = insertelement <8 x i1> poison, i1 %.spill.load639, i64 0
  %.splat641 = shufflevector <8 x i1> %.splatinsert640, <8 x i1> poison, <8 x i32> zeroinitializer
  %1286 = select <8 x i1> %.splat641, <8 x float> %native.exp621, <8 x float> zeroinitializer
  %.spill.load642 = load i1, ptr %.spill81, align 1
  %.splatinsert643 = insertelement <8 x i1> poison, i1 %.spill.load642, i64 0
  %.splat644 = shufflevector <8 x i1> %.splatinsert643, <8 x i1> poison, <8 x i32> zeroinitializer
  %1287 = select <8 x i1> %.splat644, <8 x float> %native.exp622, <8 x float> zeroinitializer
  %.spill.load645 = load i1, ptr %.spill82, align 1
  %.splatinsert646 = insertelement <8 x i1> poison, i1 %.spill.load645, i64 0
  %.splat647 = shufflevector <8 x i1> %.splatinsert646, <8 x i1> poison, <8 x i32> zeroinitializer
  %1288 = select <8 x i1> %.splat647, <8 x float> %native.exp623, <8 x float> zeroinitializer
  %.spill.load648 = load i1, ptr %.spill83, align 1
  %.splatinsert649 = insertelement <8 x i1> poison, i1 %.spill.load648, i64 0
  %.splat650 = shufflevector <8 x i1> %.splatinsert649, <8 x i1> poison, <8 x i32> zeroinitializer
  %1289 = select <8 x i1> %.splat650, <8 x float> %native.exp624, <8 x float> zeroinitializer
  %.spill.load651 = load i1, ptr %.spill84, align 1
  %.splatinsert652 = insertelement <8 x i1> poison, i1 %.spill.load651, i64 0
  %.splat653 = shufflevector <8 x i1> %.splatinsert652, <8 x i1> poison, <8 x i32> zeroinitializer
  %1290 = select <8 x i1> %.splat653, <8 x float> %native.exp625, <8 x float> zeroinitializer
  %.spill.load654 = load i1, ptr %.spill85, align 1
  %.splatinsert655 = insertelement <8 x i1> poison, i1 %.spill.load654, i64 0
  %.splat656 = shufflevector <8 x i1> %.splatinsert655, <8 x i1> poison, <8 x i32> zeroinitializer
  %1291 = select <8 x i1> %.splat656, <8 x float> %native.exp626, <8 x float> zeroinitializer
  %.spill.load657 = load i1, ptr %.spill86, align 1
  %.splatinsert658 = insertelement <8 x i1> poison, i1 %.spill.load657, i64 0
  %.splat659 = shufflevector <8 x i1> %.splatinsert658, <8 x i1> poison, <8 x i32> zeroinitializer
  %1292 = select <8 x i1> %.splat659, <8 x float> %native.exp627, <8 x float> zeroinitializer
  %.spill.load660 = load i1, ptr %.spill87, align 1
  %.splatinsert661 = insertelement <8 x i1> poison, i1 %.spill.load660, i64 0
  %.splat662 = shufflevector <8 x i1> %.splatinsert661, <8 x i1> poison, <8 x i32> zeroinitializer
  %1293 = select <8 x i1> %.splat662, <8 x float> %native.exp628, <8 x float> zeroinitializer
  %.spill.load663 = load i1, ptr %.spill88, align 1
  %.splatinsert664 = insertelement <8 x i1> poison, i1 %.spill.load663, i64 0
  %.splat665 = shufflevector <8 x i1> %.splatinsert664, <8 x i1> poison, <8 x i32> zeroinitializer
  %1294 = select <8 x i1> %.splat665, <8 x float> %native.exp629, <8 x float> zeroinitializer
  %.spill.load666 = load i1, ptr %.spill89, align 1
  %.splatinsert667 = insertelement <8 x i1> poison, i1 %.spill.load666, i64 0
  %.splat668 = shufflevector <8 x i1> %.splatinsert667, <8 x i1> poison, <8 x i32> zeroinitializer
  %1295 = select <8 x i1> %.splat668, <8 x float> %native.exp630, <8 x float> zeroinitializer
  %.spill.load669 = load i1, ptr %.spill90, align 1
  %.splatinsert670 = insertelement <8 x i1> poison, i1 %.spill.load669, i64 0
  %.splat671 = shufflevector <8 x i1> %.splatinsert670, <8 x i1> poison, <8 x i32> zeroinitializer
  %1296 = select <8 x i1> %.splat671, <8 x float> %native.exp631, <8 x float> zeroinitializer
  %.spill.load672 = load i1, ptr %.spill91, align 1
  %.splatinsert673 = insertelement <8 x i1> poison, i1 %.spill.load672, i64 0
  %.splat674 = shufflevector <8 x i1> %.splatinsert673, <8 x i1> poison, <8 x i32> zeroinitializer
  %1297 = select <8 x i1> %.splat674, <8 x float> %native.exp632, <8 x float> zeroinitializer
  %.spill.load675 = load i1, ptr %.spill92, align 1
  %.splatinsert676 = insertelement <8 x i1> poison, i1 %.spill.load675, i64 0
  %.splat677 = shufflevector <8 x i1> %.splatinsert676, <8 x i1> poison, <8 x i32> zeroinitializer
  %1298 = select <8 x i1> %.splat677, <8 x float> %native.exp633, <8 x float> zeroinitializer
  %.spill.load678 = load i1, ptr %.spill93, align 1
  %.splatinsert679 = insertelement <8 x i1> poison, i1 %.spill.load678, i64 0
  %.splat680 = shufflevector <8 x i1> %.splatinsert679, <8 x i1> poison, <8 x i32> zeroinitializer
  %1299 = select <8 x i1> %.splat680, <8 x float> %native.exp634, <8 x float> zeroinitializer
  %.spill.load681 = load i1, ptr %.spill94, align 1
  %.splatinsert682 = insertelement <8 x i1> poison, i1 %.spill.load681, i64 0
  %.splat683 = shufflevector <8 x i1> %.splatinsert682, <8 x i1> poison, <8 x i32> zeroinitializer
  %1300 = select <8 x i1> %.splat683, <8 x float> %native.exp635, <8 x float> zeroinitializer
  %1301 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1302 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1303 = extractvalue { <8 x ptr>, <8 x i64> } %1301, 0
  %1304 = select <8 x i1> %71, <8 x ptr> %1302, <8 x ptr> %1303
  %1305 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %1301, 1
  %1307 = select <8 x i1> %71, <8 x i64> %1305, <8 x i64> %1306
  %1308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1304, 0
  %1309 = insertvalue { <8 x ptr>, <8 x i64> } %1308, <8 x i64> %1307, 1
  store { <8 x ptr>, <8 x i64> } %1309, ptr %tile_snapshot.spill116, align 64
  %1310 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1312 = add <8 x i64> %1311, zeroinitializer
  %1313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1310, 0
  %1314 = insertvalue { <8 x ptr>, <8 x i64> } %1313, <8 x i64> %1312, 1
  %1315 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1316 = extractvalue { <8 x ptr>, <8 x i64> } %1314, 1
  %1317 = extractelement <8 x ptr> %1315, i32 0
  %1318 = extractelement <8 x i64> %1316, i32 0
  %1319 = sub i64 %1318, 0
  %1320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1321 = select i1 %1320, i64 %1319, i64 0
  %private.contiguous.address684 = getelementptr i8, ptr %1317, i64 %1321
  %private.contiguous.preserve685 = load <8 x float>, ptr %private.contiguous.address684, align 4
  %1322 = select <8 x i1> %71, <8 x float> %1285, <8 x float> %private.contiguous.preserve685
  store <8 x float> %1322, ptr %private.contiguous.address684, align 4
  %1323 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1324 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1325 = add <8 x i64> %1324, splat (i64 32)
  %1326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1323, 0
  %1327 = insertvalue { <8 x ptr>, <8 x i64> } %1326, <8 x i64> %1325, 1
  %1328 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1329 = extractvalue { <8 x ptr>, <8 x i64> } %1327, 1
  %1330 = extractelement <8 x ptr> %1328, i32 0
  %1331 = extractelement <8 x i64> %1329, i32 0
  %1332 = sub i64 %1331, 0
  %1333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1334 = select i1 %1333, i64 %1332, i64 0
  %private.contiguous.address686 = getelementptr i8, ptr %1330, i64 %1334
  %private.contiguous.preserve687 = load <8 x float>, ptr %private.contiguous.address686, align 4
  %1335 = select <8 x i1> %71, <8 x float> %1286, <8 x float> %private.contiguous.preserve687
  store <8 x float> %1335, ptr %private.contiguous.address686, align 4
  %1336 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1338 = add <8 x i64> %1337, splat (i64 64)
  %1339 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1336, 0
  %1340 = insertvalue { <8 x ptr>, <8 x i64> } %1339, <8 x i64> %1338, 1
  %1341 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1342 = extractvalue { <8 x ptr>, <8 x i64> } %1340, 1
  %1343 = extractelement <8 x ptr> %1341, i32 0
  %1344 = extractelement <8 x i64> %1342, i32 0
  %1345 = sub i64 %1344, 0
  %1346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1347 = select i1 %1346, i64 %1345, i64 0
  %private.contiguous.address688 = getelementptr i8, ptr %1343, i64 %1347
  %private.contiguous.preserve689 = load <8 x float>, ptr %private.contiguous.address688, align 4
  %1348 = select <8 x i1> %71, <8 x float> %1287, <8 x float> %private.contiguous.preserve689
  store <8 x float> %1348, ptr %private.contiguous.address688, align 4
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1351 = add <8 x i64> %1350, splat (i64 96)
  %1352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1349, 0
  %1353 = insertvalue { <8 x ptr>, <8 x i64> } %1352, <8 x i64> %1351, 1
  %1354 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %1353, 1
  %1356 = extractelement <8 x ptr> %1354, i32 0
  %1357 = extractelement <8 x i64> %1355, i32 0
  %1358 = sub i64 %1357, 0
  %1359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1360 = select i1 %1359, i64 %1358, i64 0
  %private.contiguous.address690 = getelementptr i8, ptr %1356, i64 %1360
  %private.contiguous.preserve691 = load <8 x float>, ptr %private.contiguous.address690, align 4
  %1361 = select <8 x i1> %71, <8 x float> %1288, <8 x float> %private.contiguous.preserve691
  store <8 x float> %1361, ptr %private.contiguous.address690, align 4
  %1362 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1364 = add <8 x i64> %1363, splat (i64 128)
  %1365 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1362, 0
  %1366 = insertvalue { <8 x ptr>, <8 x i64> } %1365, <8 x i64> %1364, 1
  %1367 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %1366, 1
  %1369 = extractelement <8 x ptr> %1367, i32 0
  %1370 = extractelement <8 x i64> %1368, i32 0
  %1371 = sub i64 %1370, 0
  %1372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1373 = select i1 %1372, i64 %1371, i64 0
  %private.contiguous.address692 = getelementptr i8, ptr %1369, i64 %1373
  %private.contiguous.preserve693 = load <8 x float>, ptr %private.contiguous.address692, align 4
  %1374 = select <8 x i1> %71, <8 x float> %1289, <8 x float> %private.contiguous.preserve693
  store <8 x float> %1374, ptr %private.contiguous.address692, align 4
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1376 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1377 = add <8 x i64> %1376, splat (i64 160)
  %1378 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1375, 0
  %1379 = insertvalue { <8 x ptr>, <8 x i64> } %1378, <8 x i64> %1377, 1
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %1379, 1
  %1382 = extractelement <8 x ptr> %1380, i32 0
  %1383 = extractelement <8 x i64> %1381, i32 0
  %1384 = sub i64 %1383, 0
  %1385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1386 = select i1 %1385, i64 %1384, i64 0
  %private.contiguous.address694 = getelementptr i8, ptr %1382, i64 %1386
  %private.contiguous.preserve695 = load <8 x float>, ptr %private.contiguous.address694, align 4
  %1387 = select <8 x i1> %71, <8 x float> %1290, <8 x float> %private.contiguous.preserve695
  store <8 x float> %1387, ptr %private.contiguous.address694, align 4
  %1388 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1389 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1390 = add <8 x i64> %1389, splat (i64 192)
  %1391 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1388, 0
  %1392 = insertvalue { <8 x ptr>, <8 x i64> } %1391, <8 x i64> %1390, 1
  %1393 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1394 = extractvalue { <8 x ptr>, <8 x i64> } %1392, 1
  %1395 = extractelement <8 x ptr> %1393, i32 0
  %1396 = extractelement <8 x i64> %1394, i32 0
  %1397 = sub i64 %1396, 0
  %1398 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1399 = select i1 %1398, i64 %1397, i64 0
  %private.contiguous.address696 = getelementptr i8, ptr %1395, i64 %1399
  %private.contiguous.preserve697 = load <8 x float>, ptr %private.contiguous.address696, align 4
  %1400 = select <8 x i1> %71, <8 x float> %1291, <8 x float> %private.contiguous.preserve697
  store <8 x float> %1400, ptr %private.contiguous.address696, align 4
  %1401 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1402 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1403 = add <8 x i64> %1402, splat (i64 224)
  %1404 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1401, 0
  %1405 = insertvalue { <8 x ptr>, <8 x i64> } %1404, <8 x i64> %1403, 1
  %1406 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %1405, 1
  %1408 = extractelement <8 x ptr> %1406, i32 0
  %1409 = extractelement <8 x i64> %1407, i32 0
  %1410 = sub i64 %1409, 0
  %1411 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1412 = select i1 %1411, i64 %1410, i64 0
  %private.contiguous.address698 = getelementptr i8, ptr %1408, i64 %1412
  %private.contiguous.preserve699 = load <8 x float>, ptr %private.contiguous.address698, align 4
  %1413 = select <8 x i1> %71, <8 x float> %1292, <8 x float> %private.contiguous.preserve699
  store <8 x float> %1413, ptr %private.contiguous.address698, align 4
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1416 = add <8 x i64> %1415, splat (i64 256)
  %1417 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1414, 0
  %1418 = insertvalue { <8 x ptr>, <8 x i64> } %1417, <8 x i64> %1416, 1
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %1418, 1
  %1421 = extractelement <8 x ptr> %1419, i32 0
  %1422 = extractelement <8 x i64> %1420, i32 0
  %1423 = sub i64 %1422, 0
  %1424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1425 = select i1 %1424, i64 %1423, i64 0
  %private.contiguous.address700 = getelementptr i8, ptr %1421, i64 %1425
  %private.contiguous.preserve701 = load <8 x float>, ptr %private.contiguous.address700, align 4
  %1426 = select <8 x i1> %71, <8 x float> %1293, <8 x float> %private.contiguous.preserve701
  store <8 x float> %1426, ptr %private.contiguous.address700, align 4
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1429 = add <8 x i64> %1428, splat (i64 288)
  %1430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1427, 0
  %1431 = insertvalue { <8 x ptr>, <8 x i64> } %1430, <8 x i64> %1429, 1
  %1432 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %1431, 1
  %1434 = extractelement <8 x ptr> %1432, i32 0
  %1435 = extractelement <8 x i64> %1433, i32 0
  %1436 = sub i64 %1435, 0
  %1437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1438 = select i1 %1437, i64 %1436, i64 0
  %private.contiguous.address702 = getelementptr i8, ptr %1434, i64 %1438
  %private.contiguous.preserve703 = load <8 x float>, ptr %private.contiguous.address702, align 4
  %1439 = select <8 x i1> %71, <8 x float> %1294, <8 x float> %private.contiguous.preserve703
  store <8 x float> %1439, ptr %private.contiguous.address702, align 4
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1442 = add <8 x i64> %1441, splat (i64 320)
  %1443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1440, 0
  %1444 = insertvalue { <8 x ptr>, <8 x i64> } %1443, <8 x i64> %1442, 1
  %1445 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1446 = extractvalue { <8 x ptr>, <8 x i64> } %1444, 1
  %1447 = extractelement <8 x ptr> %1445, i32 0
  %1448 = extractelement <8 x i64> %1446, i32 0
  %1449 = sub i64 %1448, 0
  %1450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1451 = select i1 %1450, i64 %1449, i64 0
  %private.contiguous.address704 = getelementptr i8, ptr %1447, i64 %1451
  %private.contiguous.preserve705 = load <8 x float>, ptr %private.contiguous.address704, align 4
  %1452 = select <8 x i1> %71, <8 x float> %1295, <8 x float> %private.contiguous.preserve705
  store <8 x float> %1452, ptr %private.contiguous.address704, align 4
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1455 = add <8 x i64> %1454, splat (i64 352)
  %1456 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1453, 0
  %1457 = insertvalue { <8 x ptr>, <8 x i64> } %1456, <8 x i64> %1455, 1
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %1457, 1
  %1460 = extractelement <8 x ptr> %1458, i32 0
  %1461 = extractelement <8 x i64> %1459, i32 0
  %1462 = sub i64 %1461, 0
  %1463 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1464 = select i1 %1463, i64 %1462, i64 0
  %private.contiguous.address706 = getelementptr i8, ptr %1460, i64 %1464
  %private.contiguous.preserve707 = load <8 x float>, ptr %private.contiguous.address706, align 4
  %1465 = select <8 x i1> %71, <8 x float> %1296, <8 x float> %private.contiguous.preserve707
  store <8 x float> %1465, ptr %private.contiguous.address706, align 4
  %1466 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1467 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1468 = add <8 x i64> %1467, splat (i64 384)
  %1469 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1466, 0
  %1470 = insertvalue { <8 x ptr>, <8 x i64> } %1469, <8 x i64> %1468, 1
  %1471 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %1470, 1
  %1473 = extractelement <8 x ptr> %1471, i32 0
  %1474 = extractelement <8 x i64> %1472, i32 0
  %1475 = sub i64 %1474, 0
  %1476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1477 = select i1 %1476, i64 %1475, i64 0
  %private.contiguous.address708 = getelementptr i8, ptr %1473, i64 %1477
  %private.contiguous.preserve709 = load <8 x float>, ptr %private.contiguous.address708, align 4
  %1478 = select <8 x i1> %71, <8 x float> %1297, <8 x float> %private.contiguous.preserve709
  store <8 x float> %1478, ptr %private.contiguous.address708, align 4
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1480 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1481 = add <8 x i64> %1480, splat (i64 416)
  %1482 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1479, 0
  %1483 = insertvalue { <8 x ptr>, <8 x i64> } %1482, <8 x i64> %1481, 1
  %1484 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %1483, 1
  %1486 = extractelement <8 x ptr> %1484, i32 0
  %1487 = extractelement <8 x i64> %1485, i32 0
  %1488 = sub i64 %1487, 0
  %1489 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1490 = select i1 %1489, i64 %1488, i64 0
  %private.contiguous.address710 = getelementptr i8, ptr %1486, i64 %1490
  %private.contiguous.preserve711 = load <8 x float>, ptr %private.contiguous.address710, align 4
  %1491 = select <8 x i1> %71, <8 x float> %1298, <8 x float> %private.contiguous.preserve711
  store <8 x float> %1491, ptr %private.contiguous.address710, align 4
  %1492 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1493 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1494 = add <8 x i64> %1493, splat (i64 448)
  %1495 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1492, 0
  %1496 = insertvalue { <8 x ptr>, <8 x i64> } %1495, <8 x i64> %1494, 1
  %1497 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1498 = extractvalue { <8 x ptr>, <8 x i64> } %1496, 1
  %1499 = extractelement <8 x ptr> %1497, i32 0
  %1500 = extractelement <8 x i64> %1498, i32 0
  %1501 = sub i64 %1500, 0
  %1502 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1503 = select i1 %1502, i64 %1501, i64 0
  %private.contiguous.address712 = getelementptr i8, ptr %1499, i64 %1503
  %private.contiguous.preserve713 = load <8 x float>, ptr %private.contiguous.address712, align 4
  %1504 = select <8 x i1> %71, <8 x float> %1299, <8 x float> %private.contiguous.preserve713
  store <8 x float> %1504, ptr %private.contiguous.address712, align 4
  %1505 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1506 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1507 = add <8 x i64> %1506, splat (i64 480)
  %1508 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1505, 0
  %1509 = insertvalue { <8 x ptr>, <8 x i64> } %1508, <8 x i64> %1507, 1
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %1509, 1
  %1512 = extractelement <8 x ptr> %1510, i32 0
  %1513 = extractelement <8 x i64> %1511, i32 0
  %1514 = sub i64 %1513, 0
  %1515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1516 = select i1 %1515, i64 %1514, i64 0
  %private.contiguous.address714 = getelementptr i8, ptr %1512, i64 %1516
  %private.contiguous.preserve715 = load <8 x float>, ptr %private.contiguous.address714, align 4
  %1517 = select <8 x i1> %71, <8 x float> %1300, <8 x float> %private.contiguous.preserve715
  store <8 x float> %1517, ptr %private.contiguous.address714, align 4
  %.state716 = load <8 x float>, ptr %.slot36, align 32
  %1518 = fmul <8 x float> %.state716, %native.exp
  %1519 = load <8 x float>, ptr %.spill117, align 32
  %1520 = select <8 x i1> %71, <8 x float> %1518, <8 x float> %1519
  store <8 x float> %1520, ptr %.spill117, align 32
  store i64 0, ptr %.slot118, align 4
  %1521 = load <8 x float>, ptr %.slot119, align 32
  %1522 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1521
  store <8 x float> %1522, ptr %.slot119, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state717 = load i64, ptr %.slot118, align 4
  %1523 = icmp slt i64 %.state717, 16
  br i1 %1523, label %direct.true718, label %direct.false719

direct.schedule.71:                               ; preds = %direct.true718
  %.state720 = load i64, ptr %.slot118, align 4
  %1524 = sdiv i64 %.state720, 1
  %.spill.load721 = load i64, ptr %.spill78, align 4
  %1525 = mul i64 %.spill.load721, 1
  %1526 = add i64 %1525, 0
  %1527 = mul i64 %1526, 1
  %1528 = add i64 %1527, 0
  %1529 = mul i64 %1528, 16
  %1530 = add i64 %1529, %1524
  %tile_snapshot.spill.load722 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load722, 0
  %1532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load722, 1
  %.splatinsert723 = insertelement <8 x i64> poison, i64 %1530, i64 0
  %.splat724 = shufflevector <8 x i64> %.splatinsert723, <8 x i64> poison, <8 x i32> zeroinitializer
  %1533 = mul <8 x i64> %.splat724, splat (i64 32)
  %1534 = add <8 x i64> %1532, %1533
  %1535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1531, 0
  %1536 = insertvalue { <8 x ptr>, <8 x i64> } %1535, <8 x i64> %1534, 1
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %1536, 1
  %1539 = extractelement <8 x ptr> %1537, i32 0
  %1540 = extractelement <8 x i64> %1538, i32 0
  %1541 = sub i64 %1540, 0
  %1542 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1543 = select i1 %1542, i64 %1541, i64 0
  %private.contiguous.address725 = getelementptr i8, ptr %1539, i64 %1543
  %private.contiguous.load726 = load <8 x float>, ptr %private.contiguous.address725, align 4
  %1544 = select <8 x i1> %71, <8 x float> %private.contiguous.load726, <8 x float> zeroinitializer
  %.state727 = load <8 x float>, ptr %.slot119, align 32
  %1545 = fadd <8 x float> %.state727, %1544
  %.state728 = load i64, ptr %.slot118, align 4
  %1546 = add i64 %.state728, 1
  store i64 %1546, ptr %.slot118, align 4
  %1547 = load <8 x float>, ptr %.slot119, align 32
  %1548 = select <8 x i1> %71, <8 x float> %1545, <8 x float> %1547
  store <8 x float> %1548, ptr %.slot119, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false719
  %.spill.load729 = load <8 x float>, ptr %.spill117, align 32
  %.state730 = load <8 x float>, ptr %.slot119, align 32
  %1549 = fadd <8 x float> %.spill.load729, %.state730
  %1550 = load <8 x float>, ptr %.spill120, align 32
  %1551 = select <8 x i1> %71, <8 x float> %1549, <8 x float> %1550
  store <8 x float> %1551, ptr %.spill120, align 32
  %1552 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1553 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %1552, 0
  %1555 = select <8 x i1> %71, <8 x ptr> %1553, <8 x ptr> %1554
  %1556 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1557 = extractvalue { <8 x ptr>, <8 x i64> } %1552, 1
  %1558 = select <8 x i1> %71, <8 x i64> %1556, <8 x i64> %1557
  %1559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1555, 0
  %1560 = insertvalue { <8 x ptr>, <8 x i64> } %1559, <8 x i64> %1558, 1
  store { <8 x ptr>, <8 x i64> } %1560, ptr %tile_snapshot.spill121, align 64
  store i64 0, ptr %.slot122, align 4
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.77, %direct.schedule.72
  %.state731 = load i64, ptr %.slot122, align 4
  %1561 = icmp slt i64 %.state731, 24
  br i1 %1561, label %direct.true732, label %direct.false733

direct.schedule.74:                               ; preds = %direct.true732
  %.state734 = load i64, ptr %.slot122, align 4
  %1562 = mul i64 %.state734, 4
  %1563 = add i64 0, %1562
  %1564 = add i64 %1563, 0
  store i64 %1564, ptr %.spill123, align 4
  %1565 = add i64 0, %1564
  %tile_snapshot.spill.load735 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1566 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load735, 0
  %1567 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load735, 1
  %.splatinsert736 = insertelement <8 x i64> poison, i64 %1565, i64 0
  %.splat737 = shufflevector <8 x i64> %.splatinsert736, <8 x i64> poison, <8 x i32> zeroinitializer
  %1568 = mul <8 x i64> %.splat737, splat (i64 32)
  %1569 = add <8 x i64> %1567, %1568
  %1570 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1566, 0
  %1571 = insertvalue { <8 x ptr>, <8 x i64> } %1570, <8 x i64> %1569, 1
  %1572 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %1571, 1
  %1574 = extractelement <8 x ptr> %1572, i32 0
  %1575 = extractelement <8 x i64> %1573, i32 0
  %1576 = sub i64 %1575, 0
  %1577 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1578 = select i1 %1577, i64 %1576, i64 0
  %private.contiguous.address738 = getelementptr i8, ptr %1574, i64 %1578
  %private.contiguous.load739 = load <8 x float>, ptr %private.contiguous.address738, align 4
  %1579 = select <8 x i1> %71, <8 x float> %private.contiguous.load739, <8 x float> zeroinitializer
  %.spill.load740 = load <8 x float>, ptr %.spill115, align 32
  %1580 = fmul <8 x float> %1579, %.spill.load740
  %1581 = add i64 %1563, 1
  store i64 %1581, ptr %.spill124, align 4
  %1582 = add i64 0, %1581
  %tile_snapshot.spill.load741 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 0
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 1
  %.splatinsert742 = insertelement <8 x i64> poison, i64 %1582, i64 0
  %.splat743 = shufflevector <8 x i64> %.splatinsert742, <8 x i64> poison, <8 x i32> zeroinitializer
  %1585 = mul <8 x i64> %.splat743, splat (i64 32)
  %1586 = add <8 x i64> %1584, %1585
  %1587 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1583, 0
  %1588 = insertvalue { <8 x ptr>, <8 x i64> } %1587, <8 x i64> %1586, 1
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1590 = extractvalue { <8 x ptr>, <8 x i64> } %1588, 1
  %1591 = extractelement <8 x ptr> %1589, i32 0
  %1592 = extractelement <8 x i64> %1590, i32 0
  %1593 = sub i64 %1592, 0
  %1594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1595 = select i1 %1594, i64 %1593, i64 0
  %private.contiguous.address744 = getelementptr i8, ptr %1591, i64 %1595
  %private.contiguous.load745 = load <8 x float>, ptr %private.contiguous.address744, align 4
  %1596 = select <8 x i1> %71, <8 x float> %private.contiguous.load745, <8 x float> zeroinitializer
  %.spill.load746 = load <8 x float>, ptr %.spill115, align 32
  %1597 = fmul <8 x float> %1596, %.spill.load746
  %1598 = add i64 %1563, 2
  store i64 %1598, ptr %.spill125, align 4
  %1599 = add i64 0, %1598
  %tile_snapshot.spill.load747 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1600 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 0
  %1601 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 1
  %.splatinsert748 = insertelement <8 x i64> poison, i64 %1599, i64 0
  %.splat749 = shufflevector <8 x i64> %.splatinsert748, <8 x i64> poison, <8 x i32> zeroinitializer
  %1602 = mul <8 x i64> %.splat749, splat (i64 32)
  %1603 = add <8 x i64> %1601, %1602
  %1604 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1600, 0
  %1605 = insertvalue { <8 x ptr>, <8 x i64> } %1604, <8 x i64> %1603, 1
  %1606 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1607 = extractvalue { <8 x ptr>, <8 x i64> } %1605, 1
  %1608 = extractelement <8 x ptr> %1606, i32 0
  %1609 = extractelement <8 x i64> %1607, i32 0
  %1610 = sub i64 %1609, 0
  %1611 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1612 = select i1 %1611, i64 %1610, i64 0
  %private.contiguous.address750 = getelementptr i8, ptr %1608, i64 %1612
  %private.contiguous.load751 = load <8 x float>, ptr %private.contiguous.address750, align 4
  %1613 = select <8 x i1> %71, <8 x float> %private.contiguous.load751, <8 x float> zeroinitializer
  %.spill.load752 = load <8 x float>, ptr %.spill115, align 32
  %1614 = fmul <8 x float> %1613, %.spill.load752
  %1615 = add i64 %1563, 3
  store i64 %1615, ptr %.spill126, align 4
  %1616 = add i64 0, %1615
  %tile_snapshot.spill.load753 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1617 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load753, 0
  %1618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load753, 1
  %.splatinsert754 = insertelement <8 x i64> poison, i64 %1616, i64 0
  %.splat755 = shufflevector <8 x i64> %.splatinsert754, <8 x i64> poison, <8 x i32> zeroinitializer
  %1619 = mul <8 x i64> %.splat755, splat (i64 32)
  %1620 = add <8 x i64> %1618, %1619
  %1621 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1617, 0
  %1622 = insertvalue { <8 x ptr>, <8 x i64> } %1621, <8 x i64> %1620, 1
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %1622, 1
  %1625 = extractelement <8 x ptr> %1623, i32 0
  %1626 = extractelement <8 x i64> %1624, i32 0
  %1627 = sub i64 %1626, 0
  %1628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1629 = select i1 %1628, i64 %1627, i64 0
  %private.contiguous.address756 = getelementptr i8, ptr %1625, i64 %1629
  %private.contiguous.load757 = load <8 x float>, ptr %private.contiguous.address756, align 4
  %1630 = select <8 x i1> %71, <8 x float> %private.contiguous.load757, <8 x float> zeroinitializer
  %.spill.load758 = load <8 x float>, ptr %.spill115, align 32
  %1631 = fmul <8 x float> %1630, %.spill.load758
  store i64 0, ptr %.slot127, align 4
  %1632 = load <8 x float>, ptr %.slot128, align 32
  %1633 = select <8 x i1> %71, <8 x float> %1580, <8 x float> %1632
  store <8 x float> %1633, ptr %.slot128, align 32
  %1634 = load <8 x float>, ptr %.slot129, align 32
  %1635 = select <8 x i1> %71, <8 x float> %1597, <8 x float> %1634
  store <8 x float> %1635, ptr %.slot129, align 32
  %1636 = load <8 x float>, ptr %.slot130, align 32
  %1637 = select <8 x i1> %71, <8 x float> %1614, <8 x float> %1636
  store <8 x float> %1637, ptr %.slot130, align 32
  %1638 = load <8 x float>, ptr %.slot131, align 32
  %1639 = select <8 x i1> %71, <8 x float> %1631, <8 x float> %1638
  store <8 x float> %1639, ptr %.slot131, align 32
  br label %direct.schedule.75

direct.schedule.75:                               ; preds = %direct.schedule.76, %direct.schedule.74
  %.state759 = load i64, ptr %.slot127, align 4
  %1640 = icmp slt i64 %.state759, 16
  br i1 %1640, label %direct.true760, label %direct.false761

direct.schedule.76:                               ; preds = %direct.true760
  %.state762 = load i64, ptr %.slot127, align 4
  %1641 = add i64 0, %.state762
  %tile_snapshot.spill.load763 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill116, align 64
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %1643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %.splatinsert764 = insertelement <8 x i64> poison, i64 %1641, i64 0
  %.splat765 = shufflevector <8 x i64> %.splatinsert764, <8 x i64> poison, <8 x i32> zeroinitializer
  %1644 = mul <8 x i64> %.splat765, splat (i64 32)
  %1645 = add <8 x i64> %1643, %1644
  %1646 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1642, 0
  %1647 = insertvalue { <8 x ptr>, <8 x i64> } %1646, <8 x i64> %1645, 1
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1649 = extractvalue { <8 x ptr>, <8 x i64> } %1647, 1
  %1650 = extractelement <8 x ptr> %1648, i32 0
  %1651 = extractelement <8 x i64> %1649, i32 0
  %1652 = sub i64 %1651, 0
  %1653 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1654 = select i1 %1653, i64 %1652, i64 0
  %private.contiguous.address766 = getelementptr i8, ptr %1650, i64 %1654
  %private.contiguous.load767 = load <8 x float>, ptr %private.contiguous.address766, align 4
  %1655 = select <8 x i1> %71, <8 x float> %private.contiguous.load767, <8 x float> zeroinitializer
  %1656 = mul i64 %1641, 96
  %.spill.load768 = load i64, ptr %.spill123, align 4
  %1657 = add i64 %1656, %.spill.load768
  %tile_snapshot.spill.load769 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 0
  %1659 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 1
  %.splatinsert770 = insertelement <8 x i64> poison, i64 %1657, i64 0
  %.splat771 = shufflevector <8 x i64> %.splatinsert770, <8 x i64> poison, <8 x i32> zeroinitializer
  %1660 = mul <8 x i64> %.splat771, splat (i64 32)
  %1661 = add <8 x i64> %1659, %1660
  %1662 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1658, 0
  %1663 = insertvalue { <8 x ptr>, <8 x i64> } %1662, <8 x i64> %1661, 1
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1665 = extractvalue { <8 x ptr>, <8 x i64> } %1663, 1
  %1666 = extractelement <8 x ptr> %1664, i32 0
  %1667 = extractelement <8 x i64> %1665, i32 0
  %1668 = sub i64 %1667, 0
  %1669 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1670 = select i1 %1669, i64 %1668, i64 0
  %private.contiguous.address772 = getelementptr i8, ptr %1666, i64 %1670
  %private.contiguous.load773 = load <8 x float>, ptr %private.contiguous.address772, align 4
  %1671 = select <8 x i1> %71, <8 x float> %private.contiguous.load773, <8 x float> zeroinitializer
  %1672 = fmul <8 x float> %1655, %1671
  %.state774 = load <8 x float>, ptr %.slot128, align 32
  %1673 = fadd <8 x float> %.state774, %1672
  %.spill.load775 = load i64, ptr %.spill124, align 4
  %1674 = add i64 %1656, %.spill.load775
  %tile_snapshot.spill.load776 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1675 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 0
  %1676 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 1
  %.splatinsert777 = insertelement <8 x i64> poison, i64 %1674, i64 0
  %.splat778 = shufflevector <8 x i64> %.splatinsert777, <8 x i64> poison, <8 x i32> zeroinitializer
  %1677 = mul <8 x i64> %.splat778, splat (i64 32)
  %1678 = add <8 x i64> %1676, %1677
  %1679 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1675, 0
  %1680 = insertvalue { <8 x ptr>, <8 x i64> } %1679, <8 x i64> %1678, 1
  %1681 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1682 = extractvalue { <8 x ptr>, <8 x i64> } %1680, 1
  %1683 = extractelement <8 x ptr> %1681, i32 0
  %1684 = extractelement <8 x i64> %1682, i32 0
  %1685 = sub i64 %1684, 0
  %1686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1687 = select i1 %1686, i64 %1685, i64 0
  %private.contiguous.address779 = getelementptr i8, ptr %1683, i64 %1687
  %private.contiguous.load780 = load <8 x float>, ptr %private.contiguous.address779, align 4
  %1688 = select <8 x i1> %71, <8 x float> %private.contiguous.load780, <8 x float> zeroinitializer
  %1689 = fmul <8 x float> %1655, %1688
  %.state781 = load <8 x float>, ptr %.slot129, align 32
  %1690 = fadd <8 x float> %.state781, %1689
  %.spill.load782 = load i64, ptr %.spill125, align 4
  %1691 = add i64 %1656, %.spill.load782
  %tile_snapshot.spill.load783 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load783, 0
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load783, 1
  %.splatinsert784 = insertelement <8 x i64> poison, i64 %1691, i64 0
  %.splat785 = shufflevector <8 x i64> %.splatinsert784, <8 x i64> poison, <8 x i32> zeroinitializer
  %1694 = mul <8 x i64> %.splat785, splat (i64 32)
  %1695 = add <8 x i64> %1693, %1694
  %1696 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1692, 0
  %1697 = insertvalue { <8 x ptr>, <8 x i64> } %1696, <8 x i64> %1695, 1
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %1697, 1
  %1700 = extractelement <8 x ptr> %1698, i32 0
  %1701 = extractelement <8 x i64> %1699, i32 0
  %1702 = sub i64 %1701, 0
  %1703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1704 = select i1 %1703, i64 %1702, i64 0
  %private.contiguous.address786 = getelementptr i8, ptr %1700, i64 %1704
  %private.contiguous.load787 = load <8 x float>, ptr %private.contiguous.address786, align 4
  %1705 = select <8 x i1> %71, <8 x float> %private.contiguous.load787, <8 x float> zeroinitializer
  %1706 = fmul <8 x float> %1655, %1705
  %.state788 = load <8 x float>, ptr %.slot130, align 32
  %1707 = fadd <8 x float> %.state788, %1706
  %.spill.load789 = load i64, ptr %.spill126, align 4
  %1708 = add i64 %1656, %.spill.load789
  %tile_snapshot.spill.load790 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 0
  %1710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 1
  %.splatinsert791 = insertelement <8 x i64> poison, i64 %1708, i64 0
  %.splat792 = shufflevector <8 x i64> %.splatinsert791, <8 x i64> poison, <8 x i32> zeroinitializer
  %1711 = mul <8 x i64> %.splat792, splat (i64 32)
  %1712 = add <8 x i64> %1710, %1711
  %1713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1709, 0
  %1714 = insertvalue { <8 x ptr>, <8 x i64> } %1713, <8 x i64> %1712, 1
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1716 = extractvalue { <8 x ptr>, <8 x i64> } %1714, 1
  %1717 = extractelement <8 x ptr> %1715, i32 0
  %1718 = extractelement <8 x i64> %1716, i32 0
  %1719 = sub i64 %1718, 0
  %1720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1721 = select i1 %1720, i64 %1719, i64 0
  %private.contiguous.address793 = getelementptr i8, ptr %1717, i64 %1721
  %private.contiguous.load794 = load <8 x float>, ptr %private.contiguous.address793, align 4
  %1722 = select <8 x i1> %71, <8 x float> %private.contiguous.load794, <8 x float> zeroinitializer
  %1723 = fmul <8 x float> %1655, %1722
  %.state795 = load <8 x float>, ptr %.slot131, align 32
  %1724 = fadd <8 x float> %.state795, %1723
  %.state796 = load i64, ptr %.slot127, align 4
  %1725 = add i64 %.state796, 1
  store i64 %1725, ptr %.slot127, align 4
  %1726 = load <8 x float>, ptr %.slot128, align 32
  %1727 = select <8 x i1> %71, <8 x float> %1673, <8 x float> %1726
  store <8 x float> %1727, ptr %.slot128, align 32
  %1728 = load <8 x float>, ptr %.slot129, align 32
  %1729 = select <8 x i1> %71, <8 x float> %1690, <8 x float> %1728
  store <8 x float> %1729, ptr %.slot129, align 32
  %1730 = load <8 x float>, ptr %.slot130, align 32
  %1731 = select <8 x i1> %71, <8 x float> %1707, <8 x float> %1730
  store <8 x float> %1731, ptr %.slot130, align 32
  %1732 = load <8 x float>, ptr %.slot131, align 32
  %1733 = select <8 x i1> %71, <8 x float> %1724, <8 x float> %1732
  store <8 x float> %1733, ptr %.slot131, align 32
  br label %direct.schedule.75

direct.schedule.77:                               ; preds = %direct.false761
  %tile_snapshot.spill.load797 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1734 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load797, 0
  %1735 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load797, 1
  %.spill.load798 = load i64, ptr %.spill123, align 4
  %.splatinsert799 = insertelement <8 x i64> poison, i64 %.spill.load798, i64 0
  %.splat800 = shufflevector <8 x i64> %.splatinsert799, <8 x i64> poison, <8 x i32> zeroinitializer
  %1736 = mul <8 x i64> %.splat800, splat (i64 32)
  %1737 = add <8 x i64> %1735, %1736
  %1738 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1734, 0
  %1739 = insertvalue { <8 x ptr>, <8 x i64> } %1738, <8 x i64> %1737, 1
  %.state801 = load <8 x float>, ptr %.slot128, align 32
  %1740 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1741 = extractvalue { <8 x ptr>, <8 x i64> } %1739, 1
  %1742 = extractelement <8 x ptr> %1740, i32 0
  %1743 = extractelement <8 x i64> %1741, i32 0
  %1744 = sub i64 %1743, 0
  %1745 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1746 = select i1 %1745, i64 %1744, i64 0
  %private.contiguous.address802 = getelementptr i8, ptr %1742, i64 %1746
  %private.contiguous.preserve803 = load <8 x float>, ptr %private.contiguous.address802, align 4
  %1747 = select <8 x i1> %71, <8 x float> %.state801, <8 x float> %private.contiguous.preserve803
  store <8 x float> %1747, ptr %private.contiguous.address802, align 4
  %tile_snapshot.spill.load804 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 0
  %1749 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 1
  %.spill.load805 = load i64, ptr %.spill124, align 4
  %.splatinsert806 = insertelement <8 x i64> poison, i64 %.spill.load805, i64 0
  %.splat807 = shufflevector <8 x i64> %.splatinsert806, <8 x i64> poison, <8 x i32> zeroinitializer
  %1750 = mul <8 x i64> %.splat807, splat (i64 32)
  %1751 = add <8 x i64> %1749, %1750
  %1752 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1748, 0
  %1753 = insertvalue { <8 x ptr>, <8 x i64> } %1752, <8 x i64> %1751, 1
  %.state808 = load <8 x float>, ptr %.slot129, align 32
  %1754 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1755 = extractvalue { <8 x ptr>, <8 x i64> } %1753, 1
  %1756 = extractelement <8 x ptr> %1754, i32 0
  %1757 = extractelement <8 x i64> %1755, i32 0
  %1758 = sub i64 %1757, 0
  %1759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1760 = select i1 %1759, i64 %1758, i64 0
  %private.contiguous.address809 = getelementptr i8, ptr %1756, i64 %1760
  %private.contiguous.preserve810 = load <8 x float>, ptr %private.contiguous.address809, align 4
  %1761 = select <8 x i1> %71, <8 x float> %.state808, <8 x float> %private.contiguous.preserve810
  store <8 x float> %1761, ptr %private.contiguous.address809, align 4
  %tile_snapshot.spill.load811 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1762 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load811, 0
  %1763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load811, 1
  %.spill.load812 = load i64, ptr %.spill125, align 4
  %.splatinsert813 = insertelement <8 x i64> poison, i64 %.spill.load812, i64 0
  %.splat814 = shufflevector <8 x i64> %.splatinsert813, <8 x i64> poison, <8 x i32> zeroinitializer
  %1764 = mul <8 x i64> %.splat814, splat (i64 32)
  %1765 = add <8 x i64> %1763, %1764
  %1766 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1762, 0
  %1767 = insertvalue { <8 x ptr>, <8 x i64> } %1766, <8 x i64> %1765, 1
  %.state815 = load <8 x float>, ptr %.slot130, align 32
  %1768 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1769 = extractvalue { <8 x ptr>, <8 x i64> } %1767, 1
  %1770 = extractelement <8 x ptr> %1768, i32 0
  %1771 = extractelement <8 x i64> %1769, i32 0
  %1772 = sub i64 %1771, 0
  %1773 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1774 = select i1 %1773, i64 %1772, i64 0
  %private.contiguous.address816 = getelementptr i8, ptr %1770, i64 %1774
  %private.contiguous.preserve817 = load <8 x float>, ptr %private.contiguous.address816, align 4
  %1775 = select <8 x i1> %71, <8 x float> %.state815, <8 x float> %private.contiguous.preserve817
  store <8 x float> %1775, ptr %private.contiguous.address816, align 4
  %tile_snapshot.spill.load818 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 0
  %1777 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 1
  %.spill.load819 = load i64, ptr %.spill126, align 4
  %.splatinsert820 = insertelement <8 x i64> poison, i64 %.spill.load819, i64 0
  %.splat821 = shufflevector <8 x i64> %.splatinsert820, <8 x i64> poison, <8 x i32> zeroinitializer
  %1778 = mul <8 x i64> %.splat821, splat (i64 32)
  %1779 = add <8 x i64> %1777, %1778
  %1780 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1776, 0
  %1781 = insertvalue { <8 x ptr>, <8 x i64> } %1780, <8 x i64> %1779, 1
  %.state822 = load <8 x float>, ptr %.slot131, align 32
  %1782 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1783 = extractvalue { <8 x ptr>, <8 x i64> } %1781, 1
  %1784 = extractelement <8 x ptr> %1782, i32 0
  %1785 = extractelement <8 x i64> %1783, i32 0
  %1786 = sub i64 %1785, 0
  %1787 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1788 = select i1 %1787, i64 %1786, i64 0
  %private.contiguous.address823 = getelementptr i8, ptr %1784, i64 %1788
  %private.contiguous.preserve824 = load <8 x float>, ptr %private.contiguous.address823, align 4
  %1789 = select <8 x i1> %71, <8 x float> %.state822, <8 x float> %private.contiguous.preserve824
  store <8 x float> %1789, ptr %private.contiguous.address823, align 4
  %.state825 = load i64, ptr %.slot122, align 4
  %1790 = add i64 %.state825, 1
  store i64 %1790, ptr %.slot122, align 4
  br label %direct.schedule.73

direct.schedule.78:                               ; preds = %direct.false733
  store i64 0, ptr %.slot132, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state826 = load i64, ptr %.slot132, align 4
  %1791 = icmp slt i64 %.state826, 96
  br i1 %1791, label %direct.true827, label %direct.false828

direct.schedule.80:                               ; preds = %direct.true827
  %tile_snapshot.spill.load829 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill121, align 64
  %1792 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load829, 0
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load829, 1
  %.state830 = load i64, ptr %.slot132, align 4
  %.splatinsert831 = insertelement <8 x i64> poison, i64 %.state830, i64 0
  %.splat832 = shufflevector <8 x i64> %.splatinsert831, <8 x i64> poison, <8 x i32> zeroinitializer
  %1794 = mul <8 x i64> %.splat832, splat (i64 32)
  %1795 = add <8 x i64> %1793, %1794
  %1796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1792, 0
  %1797 = insertvalue { <8 x ptr>, <8 x i64> } %1796, <8 x i64> %1795, 1
  %1798 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1799 = extractvalue { <8 x ptr>, <8 x i64> } %1797, 1
  %1800 = extractelement <8 x ptr> %1798, i32 0
  %1801 = extractelement <8 x i64> %1799, i32 0
  %1802 = sub i64 %1801, 0
  %1803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1804 = select i1 %1803, i64 %1802, i64 0
  %private.contiguous.address833 = getelementptr i8, ptr %1800, i64 %1804
  %private.contiguous.load834 = load <8 x float>, ptr %private.contiguous.address833, align 4
  %1805 = select <8 x i1> %71, <8 x float> %private.contiguous.load834, <8 x float> zeroinitializer
  %tile_snapshot.spill.load835 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1806 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load835, 0
  %1807 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load835, 1
  %.state836 = load i64, ptr %.slot132, align 4
  %.splatinsert837 = insertelement <8 x i64> poison, i64 %.state836, i64 0
  %.splat838 = shufflevector <8 x i64> %.splatinsert837, <8 x i64> poison, <8 x i32> zeroinitializer
  %1808 = mul <8 x i64> %.splat838, splat (i64 32)
  %1809 = add <8 x i64> %1807, %1808
  %1810 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1806, 0
  %1811 = insertvalue { <8 x ptr>, <8 x i64> } %1810, <8 x i64> %1809, 1
  %1812 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1813 = extractvalue { <8 x ptr>, <8 x i64> } %1811, 1
  %1814 = extractelement <8 x ptr> %1812, i32 0
  %1815 = extractelement <8 x i64> %1813, i32 0
  %1816 = sub i64 %1815, 0
  %1817 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1818 = select i1 %1817, i64 %1816, i64 0
  %private.contiguous.address839 = getelementptr i8, ptr %1814, i64 %1818
  %private.contiguous.preserve840 = load <8 x float>, ptr %private.contiguous.address839, align 4
  %1819 = select <8 x i1> %71, <8 x float> %1805, <8 x float> %private.contiguous.preserve840
  store <8 x float> %1819, ptr %private.contiguous.address839, align 4
  %.state841 = load i64, ptr %.slot132, align 4
  %1820 = add i64 %.state841, 1
  store i64 %1820, ptr %.slot132, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false828
  store i64 0, ptr %.slot133, align 4
  br label %direct.schedule.82

direct.schedule.82:                               ; preds = %direct.schedule.83, %direct.schedule.81
  %.state842 = load i64, ptr %.slot133, align 4
  %1821 = icmp slt i64 %.state842, 96
  br i1 %1821, label %direct.true843, label %direct.false844

direct.schedule.83:                               ; preds = %direct.true843
  %tile_snapshot.spill.load845 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1822 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load845, 0
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load845, 1
  %.state846 = load i64, ptr %.slot133, align 4
  %.splatinsert847 = insertelement <8 x i64> poison, i64 %.state846, i64 0
  %.splat848 = shufflevector <8 x i64> %.splatinsert847, <8 x i64> poison, <8 x i32> zeroinitializer
  %1824 = mul <8 x i64> %.splat848, splat (i64 32)
  %1825 = add <8 x i64> %1823, %1824
  %1826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1822, 0
  %1827 = insertvalue { <8 x ptr>, <8 x i64> } %1826, <8 x i64> %1825, 1
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1829 = extractvalue { <8 x ptr>, <8 x i64> } %1827, 1
  %1830 = extractelement <8 x ptr> %1828, i32 0
  %1831 = extractelement <8 x i64> %1829, i32 0
  %1832 = sub i64 %1831, 0
  %1833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1834 = select i1 %1833, i64 %1832, i64 0
  %private.contiguous.address849 = getelementptr i8, ptr %1830, i64 %1834
  %private.contiguous.load850 = load <8 x float>, ptr %private.contiguous.address849, align 4
  %1835 = select <8 x i1> %71, <8 x float> %private.contiguous.load850, <8 x float> zeroinitializer
  %tile_snapshot.spill.load851 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load851, 0
  %1837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load851, 1
  %.state852 = load i64, ptr %.slot133, align 4
  %.splatinsert853 = insertelement <8 x i64> poison, i64 %.state852, i64 0
  %.splat854 = shufflevector <8 x i64> %.splatinsert853, <8 x i64> poison, <8 x i32> zeroinitializer
  %1838 = mul <8 x i64> %.splat854, splat (i64 32)
  %1839 = add <8 x i64> %1837, %1838
  %1840 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1836, 0
  %1841 = insertvalue { <8 x ptr>, <8 x i64> } %1840, <8 x i64> %1839, 1
  %1842 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1843 = extractvalue { <8 x ptr>, <8 x i64> } %1841, 1
  %1844 = extractelement <8 x ptr> %1842, i32 0
  %1845 = extractelement <8 x i64> %1843, i32 0
  %1846 = sub i64 %1845, 0
  %1847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1848 = select i1 %1847, i64 %1846, i64 0
  %private.contiguous.address855 = getelementptr i8, ptr %1844, i64 %1848
  %private.contiguous.preserve856 = load <8 x float>, ptr %private.contiguous.address855, align 4
  %1849 = select <8 x i1> %71, <8 x float> %1835, <8 x float> %private.contiguous.preserve856
  store <8 x float> %1849, ptr %private.contiguous.address855, align 4
  %.state857 = load i64, ptr %.slot133, align 4
  %1850 = add i64 %.state857, 1
  store i64 %1850, ptr %.slot133, align 4
  br label %direct.schedule.82

direct.schedule.84:                               ; preds = %direct.false844
  %.state858 = load i64, ptr %.slot34, align 4
  %1851 = add i64 %.state858, 1
  %.spill.load859 = load <8 x float>, ptr %.spill114, align 32
  %.spill.load860 = load <8 x float>, ptr %.spill120, align 32
  store i64 %1851, ptr %.slot34, align 4
  %1852 = load <8 x float>, ptr %.slot35, align 32
  %1853 = select <8 x i1> %71, <8 x float> %.spill.load859, <8 x float> %1852
  store <8 x float> %1853, ptr %.slot35, align 32
  %1854 = load <8 x float>, ptr %.slot36, align 32
  %1855 = select <8 x i1> %71, <8 x float> %.spill.load860, <8 x float> %1854
  store <8 x float> %1855, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.85:                               ; preds = %direct.false170
  store i64 0, ptr %.slot134, align 4
  br label %direct.schedule.86

direct.schedule.86:                               ; preds = %direct.schedule.87, %direct.schedule.85
  %.state861 = load i64, ptr %.slot134, align 4
  %1856 = icmp slt i64 %.state861, 96
  br i1 %1856, label %direct.true862, label %direct.false863

direct.schedule.87:                               ; preds = %direct.true862
  %.spill.load864 = load i64, ptr %.spill29, align 4
  %1857 = add i64 %.spill.load864, 0
  %.spill.load865 = load <8 x i64>, ptr %.spill, align 64
  %1858 = add <8 x i64> %.spill.load865, zeroinitializer
  %1859 = mul i64 %1857, 6
  %.splatinsert866 = insertelement <8 x i64> poison, i64 %1859, i64 0
  %.splat867 = shufflevector <8 x i64> %.splatinsert866, <8 x i64> poison, <8 x i32> zeroinitializer
  %1860 = add <8 x i64> %.splat867, %1858
  %.spill.load868 = load i64, ptr %.spill29, align 4
  %1861 = add i64 %.spill.load868, 0
  %1862 = mul <8 x i64> %1860, splat (i64 1)
  %.splatinsert869 = insertelement <8 x i64> poison, i64 %1861, i64 0
  %.splat870 = shufflevector <8 x i64> %.splatinsert869, <8 x i64> poison, <8 x i32> zeroinitializer
  %1863 = add <8 x i64> %1862, %.splat870
  %.state871 = load i64, ptr %.slot134, align 4
  %1864 = add i64 0, %.state871
  %1865 = mul <8 x i64> %1863, splat (i64 96)
  %.splatinsert872 = insertelement <8 x i64> poison, i64 %1864, i64 0
  %.splat873 = shufflevector <8 x i64> %.splatinsert872, <8 x i64> poison, <8 x i32> zeroinitializer
  %1866 = add <8 x i64> %1865, %.splat873
  %.state874 = load i64, ptr %.slot134, align 4
  %1867 = add i64 0, %.state874
  %tile_snapshot.spill.load875 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1868 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load875, 0
  %1869 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load875, 1
  %.splatinsert876 = insertelement <8 x i64> poison, i64 %1867, i64 0
  %.splat877 = shufflevector <8 x i64> %.splatinsert876, <8 x i64> poison, <8 x i32> zeroinitializer
  %1870 = mul <8 x i64> %.splat877, splat (i64 32)
  %1871 = add <8 x i64> %1869, %1870
  %1872 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1868, 0
  %1873 = insertvalue { <8 x ptr>, <8 x i64> } %1872, <8 x i64> %1871, 1
  %1874 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1875 = extractvalue { <8 x ptr>, <8 x i64> } %1873, 1
  %1876 = extractelement <8 x ptr> %1874, i32 0
  %1877 = extractelement <8 x i64> %1875, i32 0
  %1878 = sub i64 %1877, 0
  %1879 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1880 = select i1 %1879, i64 %1878, i64 0
  %private.contiguous.address878 = getelementptr i8, ptr %1876, i64 %1880
  %private.contiguous.load879 = load <8 x float>, ptr %private.contiguous.address878, align 4
  %1881 = select <8 x i1> %71, <8 x float> %private.contiguous.load879, <8 x float> zeroinitializer
  %.state880 = load <8 x float>, ptr %.slot36, align 32
  %1882 = fdiv <8 x float> %1881, %.state880
  %1883 = extractvalue { ptr, i64 } %47, 0
  %1884 = mul <8 x i64> %1866, splat (i64 4)
  %1885 = getelementptr i8, ptr %1883, <8 x i64> %1884
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1882, <8 x ptr> align 1 %1885, <8 x i1> %71)
  %.state881 = load i64, ptr %.slot134, align 4
  %1886 = add i64 %.state881, 1
  store i64 %1886, ptr %.slot134, align 4
  br label %direct.schedule.86

direct.schedule.88:                               ; preds = %direct.false863
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true159:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false160:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true169:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false170:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.85

direct.true173:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false174:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true186:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false187:                                  ; preds = %direct.schedule.10
  %1887 = load <8 x float>, ptr %.slot41, align 32
  %1888 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1887
  store <8 x float> %1888, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.true198:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false199:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true211:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false212:                                  ; preds = %direct.schedule.15
  %1889 = load <8 x float>, ptr %.slot45, align 32
  %1890 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1889
  store <8 x float> %1890, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.true223:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false224:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true238:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false239:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true255:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false256:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true272:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false273:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true289:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false290:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true306:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false307:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true323:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false324:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true340:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false341:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true357:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false358:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true374:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false375:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true391:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false392:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true408:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false409:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true425:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false426:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true442:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false443:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true459:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false460:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true476:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false477:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true590:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false591:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true718:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false719:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true732:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false733:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.78

direct.true760:                                   ; preds = %direct.schedule.75
  br label %direct.schedule.76

direct.false761:                                  ; preds = %direct.schedule.75
  br label %direct.schedule.77

direct.true827:                                   ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false828:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.81

direct.true843:                                   ; preds = %direct.schedule.82
  br label %direct.schedule.83

direct.false844:                                  ; preds = %direct.schedule.82
  br label %direct.schedule.84

direct.true862:                                   ; preds = %direct.schedule.86
  br label %direct.schedule.87

direct.false863:                                  ; preds = %direct.schedule.86
  br label %direct.schedule.88
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(write) }

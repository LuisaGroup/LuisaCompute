	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	dup.4s	v2, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v2, v4
	cmhi.4s	v1, v2, v3
	uzp1.8h	v17, v1, v0
	umaxv.8h	h5, v17
	fmov	w8, s5
	tbz	w8, #0, LBB0_122
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2784
	mov	x9, #0                          ; =0x0
	ldr	x10, [x1, #136]
	add	x8, x10, #2560
	mov	w11, #5632                      ; =0x1600
	add	x11, x10, x11
	mov	w12, #8704                      ; =0x2200
	add	x12, x10, x12
	mov	w13, #49664                     ; =0xc200
	add	x13, x10, x13
	add	x14, x10, #24, lsl #12          ; =98304
	add	x14, x14, #512
	add	x15, x10, #24, lsl #12          ; =98304
	add	x15, x15, #1024
	add	x16, x10, #24, lsl #12          ; =98304
	add	x16, x16, #1536
	ldr	x2, [x0]
	ldr	x17, [x0, #16]
	ldr	w3, [x1]
	ldr	w1, [x1, #36]
	add	w3, w1, w3, lsl #5
	ldr	x1, [x0, #32]
	ldr	x0, [x0, #48]
	str	x0, [sp, #88]                   ; 8-byte Spill
	dup.4s	v5, w3
	add.4s	v6, v5, v4
	add.4s	v5, v5, v3
	and.16b	v16, v1, v5
	and.16b	v7, v0, v6
	ushll2.2d	v22, v7, #0
	ushll2.2d	v23, v16, #0
	ushll.2d	v24, v7, #0
	ushll.2d	v25, v16, #0
	movi.4s	v6, #80
	umull2.2d	v5, v7, v6
	umull2.2d	v6, v16, v6
	movi.2s	v18, #80
	umull.2d	v7, v7, v18
	umull.2d	v16, v16, v18
Lloh4:
	adrp	x0, lCPI0_2@PAGE
Lloh5:
	ldr	q18, [x0, lCPI0_2@PAGEOFF]
	and.16b	v17, v17, v18
	addv.8h	h17, v17
	str	q17, [sp, #2432]                ; 16-byte Spill
	fmov	w0, s17
	dup.2d	v17, x2
	b	LBB0_3
LBB0_2:                                 ; %else211
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x10, x9, lsl #5
	ldp	q20, q21, [x2]
	bif.16b	v19, v21, v0
	bif.16b	v18, v20, v1
	stp	q18, q19, [x2]
	add	x9, x9, #1
	cmp	x9, #80
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v20, x9
	add.2d	v18, v20, v16
	shl.2d	v18, v18, #2
	add.2d	v21, v17, v18
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w0, #0, LBB0_11
; %bb.4:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d21
	ldr	s18, [x2]
	and	w2, w0, #0xff
	tbnz	w2, #1, LBB0_12
LBB0_5:                                 ; %else193
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v21, v20, v6
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbz	w2, #2, LBB0_13
LBB0_6:                                 ; %cond.load195
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x3, d21
	ld1.s	{ v18 }[2], [x3]
	tbnz	w2, #3, LBB0_14
LBB0_7:                                 ; %else199
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v21, v20, v7
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbz	w2, #4, LBB0_15
LBB0_8:                                 ; %cond.load201
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x3, d21
	ld1.s	{ v19 }[0], [x3]
	tbnz	w2, #5, LBB0_16
LBB0_9:                                 ; %else205
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v20, v20, v5
	shl.2d	v20, v20, #2
	add.2d	v20, v17, v20
	tbz	w2, #6, LBB0_17
LBB0_10:                                ; %cond.load207
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x3, d20
	ld1.s	{ v19 }[2], [x3]
	tbz	w2, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w2, w0, #0xff
	tbz	w2, #1, LBB0_5
LBB0_12:                                ; %cond.load192
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x3, v21[1]
	ld1.s	{ v18 }[1], [x3]
	add.2d	v21, v20, v6
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbnz	w2, #2, LBB0_6
LBB0_13:                                ; %else196
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w2, #3, LBB0_7
LBB0_14:                                ; %cond.load198
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x3, v21[1]
	ld1.s	{ v18 }[3], [x3]
	add.2d	v21, v20, v7
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbnz	w2, #4, LBB0_8
LBB0_15:                                ; %else202
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w2, #5, LBB0_9
LBB0_16:                                ; %cond.load204
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x3, v21[1]
	ld1.s	{ v19 }[1], [x3]
	add.2d	v20, v20, v5
	shl.2d	v20, v20, #2
	add.2d	v20, v17, v20
	tbnz	w2, #6, LBB0_10
LBB0_17:                                ; %else208
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w2, #7, LBB0_2
LBB0_18:                                ; %cond.load210
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v20[1]
	ld1.s	{ v19 }[3], [x2]
	b	LBB0_2
LBB0_19:                                ; %direct.true159.preheader
	mov	x9, #0                          ; =0x0
	cmhs.4s	v4, v4, v2
	cmhs.4s	v5, v3, v2
LBB0_20:                                ; %direct.true159
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, x8, x9
	ldp	q2, q3, [x0]
	and.16b	v3, v4, v3
	and.16b	v2, v5, v2
	stp	q2, q3, [x0]
	add	x9, x9, #32
	cmp	x9, #3072
	b.ne	LBB0_20
; %bb.21:                               ; %direct.false160
	str	q5, [sp, #2352]                 ; 16-byte Spill
	str	q4, [sp, #2144]                 ; 16-byte Spill
	mov	x0, #0                          ; =0x0
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	sshll2.2d	v19, v1, #0
	sshll2.2d	v16, v0, #0
	str	q16, [sp, #2736]                ; 16-byte Spill
	stp	q25, q24, [sp, #16]             ; 32-byte Folded Spill
	ushr.2d	v4, v25, #2
	stp	q23, q22, [sp, #48]             ; 32-byte Folded Spill
	ushr.2d	v5, v23, #2
	ushr.2d	v6, v24, #2
	ushr.2d	v7, v22, #2
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q17, [x9, lCPI0_6@PAGEOFF]
	str	q17, [sp, #1744]                ; 16-byte Spill
	and.16b	v17, v2, v17
	str	q17, [sp, #2464]                ; 16-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v17, w9
	and.16b	v18, v0, v17
	str	q18, [sp, #2192]                ; 16-byte Spill
	mov.d	x9, v7[1]
	mov	w2, #2053                       ; =0x805
	mul	x9, x9, x2
	fmov	x3, d7
	mul	x3, x3, x2
	fmov	d7, x3
	mov.d	v7[1], x9
	mov.d	x9, v6[1]
	mul	x9, x9, x2
	fmov	x3, d6
	mul	x3, x3, x2
	fmov	d6, x3
	mov.d	v6[1], x9
	str	q17, [sp, #320]                 ; 16-byte Spill
	and.16b	v17, v1, v17
	str	q17, [sp, #2176]                ; 16-byte Spill
	mov.d	x9, v5[1]
	mul	x9, x9, x2
	fmov	x3, d5
	mul	x3, x3, x2
	fmov	d5, x3
	mov.d	v5[1], x9
	mov.d	x9, v4[1]
	mul	x9, x9, x2
	fmov	x3, d4
	mul	x2, x3, x2
	fmov	d4, x2
	mov.d	v4[1], x9
	and.16b	v2, v2, v4
	str	q2, [sp, #2720]                 ; 16-byte Spill
	str	q19, [sp, #2752]                ; 16-byte Spill
	and.16b	v2, v19, v5
	str	q2, [sp, #2704]                 ; 16-byte Spill
	and.16b	v2, v3, v6
	str	q2, [sp, #2688]                 ; 16-byte Spill
	and.16b	v2, v16, v7
	str	q2, [sp, #2672]                 ; 16-byte Spill
	mov	w9, #49760                      ; =0xc260
	add	x9, x10, x9
	str	x9, [sp, #312]                  ; 8-byte Spill
Lloh8:
	adrp	x9, lCPI0_3@PAGE
Lloh9:
	ldr	q2, [x9, lCPI0_3@PAGEOFF]
	str	q2, [sp, #1728]                 ; 16-byte Spill
Lloh10:
	adrp	x9, lCPI0_4@PAGE
Lloh11:
	ldr	q2, [x9, lCPI0_4@PAGEOFF]
	str	q2, [sp, #1712]                 ; 16-byte Spill
Lloh12:
	adrp	x9, lCPI0_5@PAGE
Lloh13:
	ldr	q2, [x9, lCPI0_5@PAGEOFF]
	str	q2, [sp, #1696]                 ; 16-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #512
	str	x9, [sp, #304]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #544
	str	x9, [sp, #296]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #576
	str	x9, [sp, #288]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #608
	str	x9, [sp, #280]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #640
	str	x9, [sp, #272]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #672
	str	x9, [sp, #264]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #704
	str	x9, [sp, #256]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #736
	str	x9, [sp, #248]                  ; 8-byte Spill
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	str	q2, [sp, #224]                  ; 16-byte Spill
	movi.2d	v14, #0000000000000000
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #768
	str	x9, [sp, #216]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	movi.2d	v15, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	add	x9, x9, #800
	str	x9, [sp, #208]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #832
	str	x9, [sp, #200]                  ; 8-byte Spill
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v28, #0000000000000000
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #864
	str	x9, [sp, #192]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	movi.2d	v8, #0000000000000000
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #2448]                 ; 16-byte Spill
	str	q2, [sp, #1680]                 ; 16-byte Spill
	add	x9, x9, #896
	str	x9, [sp, #184]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #928
	str	x9, [sp, #176]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #960
	str	x9, [sp, #168]                  ; 8-byte Spill
	str	q2, [sp, #1664]                 ; 16-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #992
	str	x9, [sp, #160]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1024
	str	x9, [sp, #152]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1056
	str	x9, [sp, #144]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1088
	str	x9, [sp, #136]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1120
	str	x9, [sp, #128]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1152
	str	x9, [sp, #120]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1184
	str	x9, [sp, #112]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1216
	str	x9, [sp, #104]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1248
	str	x9, [sp, #96]                   ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x20, x9, #1280
	add	x9, x10, #24, lsl #12           ; =98304
	add	x21, x9, #1312
	add	x9, x10, #24, lsl #12           ; =98304
	add	x22, x9, #1344
	add	x9, x10, #24, lsl #12           ; =98304
	add	x23, x9, #1376
	add	x9, x10, #24, lsl #12           ; =98304
	add	x24, x9, #1408
	add	x9, x10, #24, lsl #12           ; =98304
	add	x25, x9, #1440
	add	x9, x10, #24, lsl #12           ; =98304
	add	x26, x9, #1472
	add	x9, x10, #24, lsl #12           ; =98304
	add	x27, x9, #1504
	mov	w28, #52429                     ; =0xcccd
	mov	w30, #80                        ; =0x50
	mov	w9, #43691                      ; =0xaaab
	mov	w2, #96                         ; =0x60
	str	q2, [sp, #1648]                 ; 16-byte Spill
	str	q2, [sp, #1632]                 ; 16-byte Spill
	str	q2, [sp, #1616]                 ; 16-byte Spill
	str	q2, [sp, #1600]                 ; 16-byte Spill
	str	q2, [sp, #1584]                 ; 16-byte Spill
	str	q2, [sp, #2128]                 ; 16-byte Spill
	str	q2, [sp, #2112]                 ; 16-byte Spill
	str	q2, [sp, #2096]                 ; 16-byte Spill
	str	q2, [sp, #2080]                 ; 16-byte Spill
	movi.2d	v23, #0000000000000000
	str	q2, [sp, #2064]                 ; 16-byte Spill
	movi.2d	v29, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	str	q2, [sp, #2048]                 ; 16-byte Spill
	movi.2d	v30, #0000000000000000
	str	q2, [sp, #2032]                 ; 16-byte Spill
	movi.2d	v31, #0000000000000000
	str	q2, [sp, #2016]                 ; 16-byte Spill
	movi.2d	v7, #0000000000000000
	str	q2, [sp, #2000]                 ; 16-byte Spill
	movi.2d	v13, #0000000000000000
	str	q2, [sp, #1984]                 ; 16-byte Spill
	movi.2d	v16, #0000000000000000
	str	q2, [sp, #1968]                 ; 16-byte Spill
	movi.2d	v9, #0000000000000000
	str	q2, [sp, #1952]                 ; 16-byte Spill
	movi.2d	v10, #0000000000000000
	str	q2, [sp, #1936]                 ; 16-byte Spill
	movi.2d	v11, #0000000000000000
	str	q2, [sp, #1920]                 ; 16-byte Spill
	movi.2d	v21, #0000000000000000
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #2656]                ; 16-byte Spill
	str	q17, [sp, #2640]                ; 16-byte Spill
	str	q17, [sp, #2624]                ; 16-byte Spill
	str	q17, [sp, #2608]                ; 16-byte Spill
	str	q17, [sp, #2592]                ; 16-byte Spill
	str	q17, [sp, #2576]                ; 16-byte Spill
	str	q17, [sp, #2560]                ; 16-byte Spill
	str	q17, [sp, #2544]                ; 16-byte Spill
	str	q17, [sp, #2528]                ; 16-byte Spill
	str	q17, [sp, #2512]                ; 16-byte Spill
	str	q17, [sp, #2496]                ; 16-byte Spill
	str	q17, [sp, #2480]                ; 16-byte Spill
	str	q17, [sp, #1568]                ; 16-byte Spill
	str	q17, [sp, #1552]                ; 16-byte Spill
	str	q17, [sp, #1536]                ; 16-byte Spill
	str	q17, [sp, #1520]                ; 16-byte Spill
	movi.2d	v20, #0000000000000000
	movi.2d	v22, #0000000000000000
LBB0_22:                                ; %direct.true169
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;     Child Loop BB0_65 Depth 2
                                        ;     Child Loop BB0_67 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_71 Depth 2
                                        ;     Child Loop BB0_73 Depth 2
                                        ;     Child Loop BB0_75 Depth 2
                                        ;     Child Loop BB0_77 Depth 2
                                        ;     Child Loop BB0_79 Depth 2
                                        ;     Child Loop BB0_81 Depth 2
                                        ;     Child Loop BB0_83 Depth 2
                                        ;     Child Loop BB0_85 Depth 2
                                        ;     Child Loop BB0_87 Depth 2
                                        ;     Child Loop BB0_89 Depth 2
                                        ;     Child Loop BB0_91 Depth 2
                                        ;     Child Loop BB0_93 Depth 2
                                        ;     Child Loop BB0_95 Depth 2
                                        ;       Child Loop BB0_96 Depth 3
                                        ;     Child Loop BB0_99 Depth 2
                                        ;     Child Loop BB0_101 Depth 2
	str	q25, [sp, #2224]                ; 16-byte Spill
	str	q24, [sp, #2240]                ; 16-byte Spill
	str	q23, [sp, #2256]                ; 16-byte Spill
	str	q22, [sp, #1488]                ; 16-byte Spill
	str	q20, [sp, #1504]                ; 16-byte Spill
	mov	x4, #0                          ; =0x0
	lsl	x3, x0, #4
	b	LBB0_24
LBB0_23:                                ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_24 Depth=2
	str	q23, [sp, #2480]                ; 16-byte Spill
	str	q20, [sp, #2496]                ; 16-byte Spill
	str	q19, [sp, #2512]                ; 16-byte Spill
	str	q18, [sp, #2528]                ; 16-byte Spill
	ldr	q17, [sp, #2544]                ; 16-byte Reload
	bit.16b	v17, v24, v0
	str	q17, [sp, #2544]                ; 16-byte Spill
	ldr	q17, [sp, #2560]                ; 16-byte Reload
	bit.16b	v17, v12, v1
	str	q17, [sp, #2560]                ; 16-byte Spill
	add	x5, x12, x4, lsl #5
	ldp	q17, q18, [x5]
	bit.16b	v18, v24, v0
	bit.16b	v17, v12, v1
	stp	q17, q18, [x5]
	add	x4, x4, #1
	cmp	x4, #1280
	b.eq	LBB0_41
LBB0_24:                                ; %direct.true173
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w5, w4, #0xffff
	mul	w5, w5, w28
	lsr	w6, w5, #22
	add	x5, x3, x6
	dup.2d	v17, x5
	ldr	q18, [sp, #2704]                ; 16-byte Reload
	add.2d	v18, v17, v18
	ldr	q19, [sp, #2688]                ; 16-byte Reload
	add.2d	v19, v17, v19
	ldr	q20, [sp, #2672]                ; 16-byte Reload
	add.2d	v20, v17, v20
	mov.d	x7, v20[1]
	fmov	x19, d20
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	fmov	d20, x19
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	mov.d	v20[1], x7
	mov.d	x7, v19[1]
	fmov	x19, d19
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	fmov	d19, x19
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	mov.d	v19[1], x7
	mov.d	x7, v18[1]
	ldr	q22, [sp, #2720]                ; 16-byte Reload
	add.2d	v17, v17, v22
	fmov	x19, d18
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	fmov	d18, x19
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	mov.d	v18[1], x7
	mov.d	x7, v17[1]
	fmov	x19, d17
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	fmov	d17, x19
	sshll.2d	v22, v1, #0
	msub	w6, w6, w30, w4
	and	x6, x6, #0xffff
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	mov.d	v17[1], x7
	dup.2d	v23, x6
	sshll.2d	v24, v0, #0
	add.2d	v17, v17, v23
	add.2d	v18, v18, v23
	add.2d	v19, v19, v23
	add.2d	v20, v20, v23
	ldr	q23, [sp, #2480]                ; 16-byte Reload
	ldr	q25, [sp, #2736]                ; 16-byte Reload
	bit.16b	v23, v20, v25
	ldr	q20, [sp, #2496]                ; 16-byte Reload
	bit.16b	v20, v19, v24
	ldr	q19, [sp, #2512]                ; 16-byte Reload
	ldr	q24, [sp, #2752]                ; 16-byte Reload
	bit.16b	v19, v18, v24
	ldr	q18, [sp, #2528]                ; 16-byte Reload
	bit.16b	v18, v17, v22
	movi.2d	v12, #0000000000000000
	movi.2d	v24, #0000000000000000
	cmp	x5, #2052
	b.hi	LBB0_23
; %bb.25:                               ; %direct.true186
                                        ;   in Loop: Header=BB0_24 Depth=2
	ldr	q17, [sp, #2432]                ; 16-byte Reload
	fmov	w5, s17
	shl.2d	v17, v18, #2
	dup.2d	v25, x17
	add.2d	v17, v25, v17
	tbz	w5, #0, LBB0_33
; %bb.26:                               ; %cond.load214
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x6, d17
	ldr	s12, [x6]
	and	w5, w5, #0xff
	tbnz	w5, #1, LBB0_34
LBB0_27:                                ; %else224
                                        ;   in Loop: Header=BB0_24 Depth=2
	shl.2d	v17, v19, #2
	add.2d	v17, v25, v17
	tbz	w5, #2, LBB0_35
LBB0_28:                                ; %cond.load226
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x6, d17
	ld1.s	{ v12 }[2], [x6]
	tbnz	w5, #3, LBB0_36
LBB0_29:                                ; %else236
                                        ;   in Loop: Header=BB0_24 Depth=2
	shl.2d	v17, v20, #2
	add.2d	v17, v25, v17
	tbz	w5, #4, LBB0_37
LBB0_30:                                ; %cond.load238
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x6, d17
	ld1.s	{ v24 }[0], [x6]
	tbnz	w5, #5, LBB0_38
LBB0_31:                                ; %else248
                                        ;   in Loop: Header=BB0_24 Depth=2
	shl.2d	v17, v23, #2
	add.2d	v17, v25, v17
	tbz	w5, #6, LBB0_39
LBB0_32:                                ; %cond.load250
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x6, d17
	ld1.s	{ v24 }[2], [x6]
	tbz	w5, #7, LBB0_23
	b	LBB0_40
LBB0_33:                                ; %else218
                                        ;   in Loop: Header=BB0_24 Depth=2
	and	w5, w5, #0xff
	tbz	w5, #1, LBB0_27
LBB0_34:                                ; %cond.load220
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x6, v17[1]
	ld1.s	{ v12 }[1], [x6]
	shl.2d	v17, v19, #2
	add.2d	v17, v25, v17
	tbnz	w5, #2, LBB0_28
LBB0_35:                                ; %else230
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w5, #3, LBB0_29
LBB0_36:                                ; %cond.load232
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x6, v17[1]
	ld1.s	{ v12 }[3], [x6]
	shl.2d	v17, v20, #2
	add.2d	v17, v25, v17
	tbnz	w5, #4, LBB0_30
LBB0_37:                                ; %else242
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w5, #5, LBB0_31
LBB0_38:                                ; %cond.load244
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x6, v17[1]
	ld1.s	{ v24 }[1], [x6]
	shl.2d	v17, v23, #2
	add.2d	v17, v25, v17
	tbnz	w5, #6, LBB0_32
LBB0_39:                                ; %else254
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w5, #7, LBB0_23
LBB0_40:                                ; %cond.load256
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x5, v17[1]
	ld1.s	{ v24 }[3], [x5]
	b	LBB0_23
LBB0_41:                                ; %direct.true198.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x4, #0                          ; =0x0
	b	LBB0_43
LBB0_42:                                ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_43 Depth=2
	str	q23, [sp, #2576]                ; 16-byte Spill
	str	q20, [sp, #2592]                ; 16-byte Spill
	str	q19, [sp, #2608]                ; 16-byte Spill
	str	q18, [sp, #2624]                ; 16-byte Spill
	ldr	q17, [sp, #2640]                ; 16-byte Reload
	bit.16b	v17, v24, v0
	str	q17, [sp, #2640]                ; 16-byte Spill
	ldr	q17, [sp, #2656]                ; 16-byte Reload
	bit.16b	v17, v12, v1
	str	q17, [sp, #2656]                ; 16-byte Spill
	add	x5, x13, x4, lsl #5
	ldp	q17, q18, [x5]
	bit.16b	v18, v24, v0
	bit.16b	v17, v12, v1
	stp	q17, q18, [x5]
	add	x4, x4, #1
	cmp	x4, #1536
	b.eq	LBB0_60
LBB0_43:                                ; %direct.true198
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w5, w4, #0xffff
	mul	w5, w5, w9
	lsr	w6, w5, #22
	add	x5, x3, x6
	dup.2d	v17, x5
	ldr	q18, [sp, #2704]                ; 16-byte Reload
	add.2d	v18, v17, v18
	ldr	q19, [sp, #2688]                ; 16-byte Reload
	add.2d	v19, v17, v19
	ldr	q20, [sp, #2672]                ; 16-byte Reload
	add.2d	v20, v17, v20
	mov.d	x7, v20[1]
	fmov	x19, d20
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	fmov	d20, x19
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	mov.d	v20[1], x7
	mov.d	x7, v19[1]
	fmov	x19, d19
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	fmov	d19, x19
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	mov.d	v19[1], x7
	mov.d	x7, v18[1]
	ldr	q22, [sp, #2720]                ; 16-byte Reload
	add.2d	v17, v17, v22
	fmov	x19, d18
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	fmov	d18, x19
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	mov.d	v18[1], x7
	mov.d	x7, v17[1]
	fmov	x19, d17
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	fmov	d17, x19
	sshll.2d	v22, v1, #0
	msub	w6, w6, w2, w4
	and	x6, x6, #0xffff
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	mov.d	v17[1], x7
	dup.2d	v23, x6
	sshll.2d	v24, v0, #0
	add.2d	v17, v17, v23
	add.2d	v18, v18, v23
	add.2d	v19, v19, v23
	add.2d	v20, v20, v23
	ldr	q23, [sp, #2576]                ; 16-byte Reload
	ldr	q25, [sp, #2736]                ; 16-byte Reload
	bit.16b	v23, v20, v25
	ldr	q20, [sp, #2592]                ; 16-byte Reload
	bit.16b	v20, v19, v24
	ldr	q19, [sp, #2608]                ; 16-byte Reload
	ldr	q24, [sp, #2752]                ; 16-byte Reload
	bit.16b	v19, v18, v24
	ldr	q18, [sp, #2624]                ; 16-byte Reload
	bit.16b	v18, v17, v22
	movi.2d	v12, #0000000000000000
	movi.2d	v24, #0000000000000000
	cmp	x5, #2053
	b.hs	LBB0_42
; %bb.44:                               ; %direct.true211
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q17, [sp, #2432]                ; 16-byte Reload
	fmov	w5, s17
	shl.2d	v17, v18, #2
	dup.2d	v25, x1
	add.2d	v17, v25, v17
	tbz	w5, #0, LBB0_52
; %bb.45:                               ; %cond.load263
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x6, d17
	ldr	s12, [x6]
	and	w5, w5, #0xff
	tbnz	w5, #1, LBB0_53
LBB0_46:                                ; %else273
                                        ;   in Loop: Header=BB0_43 Depth=2
	shl.2d	v17, v19, #2
	add.2d	v17, v25, v17
	tbz	w5, #2, LBB0_54
LBB0_47:                                ; %cond.load275
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x6, d17
	ld1.s	{ v12 }[2], [x6]
	tbnz	w5, #3, LBB0_55
LBB0_48:                                ; %else285
                                        ;   in Loop: Header=BB0_43 Depth=2
	shl.2d	v17, v20, #2
	add.2d	v17, v25, v17
	tbz	w5, #4, LBB0_56
LBB0_49:                                ; %cond.load287
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x6, d17
	ld1.s	{ v24 }[0], [x6]
	tbnz	w5, #5, LBB0_57
LBB0_50:                                ; %else297
                                        ;   in Loop: Header=BB0_43 Depth=2
	shl.2d	v17, v23, #2
	add.2d	v17, v25, v17
	tbz	w5, #6, LBB0_58
LBB0_51:                                ; %cond.load299
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x6, d17
	ld1.s	{ v24 }[2], [x6]
	tbz	w5, #7, LBB0_42
	b	LBB0_59
LBB0_52:                                ; %else267
                                        ;   in Loop: Header=BB0_43 Depth=2
	and	w5, w5, #0xff
	tbz	w5, #1, LBB0_46
LBB0_53:                                ; %cond.load269
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x6, v17[1]
	ld1.s	{ v12 }[1], [x6]
	shl.2d	v17, v19, #2
	add.2d	v17, v25, v17
	tbnz	w5, #2, LBB0_47
LBB0_54:                                ; %else279
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w5, #3, LBB0_48
LBB0_55:                                ; %cond.load281
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x6, v17[1]
	ld1.s	{ v12 }[3], [x6]
	shl.2d	v17, v20, #2
	add.2d	v17, v25, v17
	tbnz	w5, #4, LBB0_49
LBB0_56:                                ; %else291
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w5, #5, LBB0_50
LBB0_57:                                ; %cond.load293
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x6, v17[1]
	ld1.s	{ v24 }[1], [x6]
	shl.2d	v17, v23, #2
	add.2d	v17, v25, v17
	tbnz	w5, #6, LBB0_51
LBB0_58:                                ; %else303
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w5, #7, LBB0_42
LBB0_59:                                ; %cond.load305
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x5, v17[1]
	ld1.s	{ v24 }[3], [x5]
	b	LBB0_42
LBB0_60:                                ; %direct.false199
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x3, #0                          ; =0x0
	sshll.2d	v17, v1, #0
	sshll.2d	v18, v0, #0
	ldr	q19, [sp, #1728]                ; 16-byte Reload
	ldr	q20, [sp, #1520]                ; 16-byte Reload
	ldr	q22, [sp, #2736]                ; 16-byte Reload
	bit.16b	v20, v19, v22
	str	q20, [sp, #1520]                ; 16-byte Spill
	ldr	q19, [sp, #1712]                ; 16-byte Reload
	ldr	q20, [sp, #1552]                ; 16-byte Reload
	ldr	q22, [sp, #2752]                ; 16-byte Reload
	bit.16b	v20, v19, v22
	str	q20, [sp, #1552]                ; 16-byte Spill
	ldr	q19, [sp, #1696]                ; 16-byte Reload
	ldr	q20, [sp, #1536]                ; 16-byte Reload
	bit.16b	v20, v19, v18
	str	q20, [sp, #1536]                ; 16-byte Spill
	ldr	q18, [sp, #1744]                ; 16-byte Reload
	ldr	q22, [sp, #1568]                ; 16-byte Reload
	bit.16b	v22, v18, v17
	bic.16b	v2, v2, v0
	bic.16b	v21, v21, v1
	ldr	q23, [sp, #2464]                ; 16-byte Reload
LBB0_61:                                ; %direct.true223
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d17, x3
	orr.16b	v18, v17, v23
	fmov	x4, d18
	add	x4, x10, x4
	ldp	q18, q19, [x4]
	orr.16b	v17, v17, v22
	fmov	x4, d17
	add	x4, x12, x4
	ldp	q17, q20, [x4]
	fmul.4s	v19, v19, v20
	fmul.4s	v17, v18, v17
	fadd.4s	v17, v21, v17
	fadd.4s	v18, v2, v19
	bit.16b	v2, v18, v0
	bit.16b	v21, v17, v1
	add	x3, x3, #32
	cmp	x3, #2560
	b.ne	LBB0_61
; %bb.62:                               ; %direct.false224
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q22, [sp, #1568]                ; 16-byte Spill
	ldr	q24, [sp, #1920]                ; 16-byte Reload
	ldr	q17, [sp, #2144]                ; 16-byte Reload
	and.16b	v24, v17, v24
	ldr	q17, [sp, #2352]                ; 16-byte Reload
	and.16b	v11, v17, v11
	mov	x3, x10
	mov	w4, #80                         ; =0x50
	ldr	q22, [sp, #1600]                ; 16-byte Reload
	ldr	q23, [sp, #1936]                ; 16-byte Reload
LBB0_63:                                ; %direct.true238
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #11264]
	ldr	q20, [x3, #11280]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v11, v17
	fadd.4s	v18, v24, v18
	bit.16b	v24, v18, v0
	bit.16b	v11, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_63
; %bb.64:                               ; %direct.false239
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q24, [sp, #1920]                ; 16-byte Spill
	str	q11, [sp, #1456]                ; 16-byte Spill
	ldr	q17, [sp, #2144]                ; 16-byte Reload
	and.16b	v23, v17, v23
	ldr	q17, [sp, #2352]                ; 16-byte Reload
	and.16b	v10, v17, v10
	mov	x3, x10
	mov	w4, #80                         ; =0x50
	ldr	q11, [sp, #2128]                ; 16-byte Reload
	ldr	q24, [sp, #2112]                ; 16-byte Reload
	ldr	q25, [sp, #2096]                ; 16-byte Reload
	ldr	q12, [sp, #2080]                ; 16-byte Reload
LBB0_65:                                ; %direct.true255
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #13824]
	ldr	q20, [x3, #13840]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v10, v17
	fadd.4s	v18, v23, v18
	bit.16b	v23, v18, v0
	bit.16b	v10, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_65
; %bb.66:                               ; %direct.false256
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q23, [sp, #1936]                ; 16-byte Spill
	str	q10, [sp, #1472]                ; 16-byte Spill
	ldr	q10, [sp, #1952]                ; 16-byte Reload
	ldr	q23, [sp, #2144]                ; 16-byte Reload
	and.16b	v10, v23, v10
	ldr	q17, [sp, #2352]                ; 16-byte Reload
	and.16b	v9, v17, v9
	mov	x3, x10
	mov	w4, #80                         ; =0x50
LBB0_67:                                ; %direct.true272
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #16384]
	ldr	q20, [x3, #16400]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v9, v17
	fadd.4s	v18, v10, v18
	bit.16b	v10, v18, v0
	bit.16b	v9, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_67
; %bb.68:                               ; %direct.false273
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q10, [sp, #1952]                ; 16-byte Spill
	str	q9, [sp, #1776]                 ; 16-byte Spill
	ldr	q9, [sp, #1968]                 ; 16-byte Reload
	and.16b	v9, v23, v9
	ldr	q17, [sp, #2352]                ; 16-byte Reload
	and.16b	v16, v17, v16
	mov	x3, x10
	mov	w4, #80                         ; =0x50
LBB0_69:                                ; %direct.true289
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #18944]
	ldr	q20, [x3, #18960]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v16, v17
	fadd.4s	v18, v9, v18
	bit.16b	v9, v18, v0
	bit.16b	v16, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_69
; %bb.70:                               ; %direct.false290
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q9, [sp, #1968]                 ; 16-byte Spill
	str	q16, [sp, #1792]                ; 16-byte Spill
	ldr	q16, [sp, #1984]                ; 16-byte Reload
	and.16b	v16, v23, v16
	ldr	q17, [sp, #2352]                ; 16-byte Reload
	and.16b	v13, v17, v13
	mov	x3, x10
	mov	w4, #80                         ; =0x50
	ldr	q10, [sp, #1472]                ; 16-byte Reload
LBB0_71:                                ; %direct.true306
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #21504]
	ldr	q20, [x3, #21520]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v13, v17
	fadd.4s	v18, v16, v18
	bit.16b	v16, v18, v0
	bit.16b	v13, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_71
; %bb.72:                               ; %direct.false307
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q16, [sp, #1984]                ; 16-byte Spill
	str	q13, [sp, #1808]                ; 16-byte Spill
	ldr	q13, [sp, #2000]                ; 16-byte Reload
	and.16b	v13, v23, v13
	ldr	q16, [sp, #2352]                ; 16-byte Reload
	and.16b	v7, v16, v7
	mov	x3, x10
	mov	w4, #80                         ; =0x50
	ldr	q9, [sp, #1776]                 ; 16-byte Reload
LBB0_73:                                ; %direct.true323
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #24064]
	ldr	q20, [x3, #24080]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v7, v17
	fadd.4s	v18, v13, v18
	bit.16b	v13, v18, v0
	bit.16b	v7, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_73
; %bb.74:                               ; %direct.false324
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q13, [sp, #2000]                ; 16-byte Spill
	str	q7, [sp, #1824]                 ; 16-byte Spill
	ldr	q7, [sp, #2016]                 ; 16-byte Reload
	and.16b	v7, v23, v7
	ldr	q16, [sp, #2352]                ; 16-byte Reload
	and.16b	v31, v16, v31
	mov	x3, x10
	mov	w4, #80                         ; =0x50
	ldr	q16, [sp, #1792]                ; 16-byte Reload
LBB0_75:                                ; %direct.true340
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #26624]
	ldr	q20, [x3, #26640]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v31, v17
	fadd.4s	v18, v7, v18
	bit.16b	v7, v18, v0
	bit.16b	v31, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_75
; %bb.76:                               ; %direct.false341
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q7, [sp, #2016]                 ; 16-byte Spill
	str	q31, [sp, #1840]                ; 16-byte Spill
	ldr	q31, [sp, #2032]                ; 16-byte Reload
	and.16b	v31, v23, v31
	ldr	q7, [sp, #2352]                 ; 16-byte Reload
	and.16b	v30, v7, v30
	mov	x3, x10
	mov	w4, #80                         ; =0x50
LBB0_77:                                ; %direct.true357
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #29184]
	ldr	q20, [x3, #29200]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v30, v17
	fadd.4s	v18, v31, v18
	bit.16b	v31, v18, v0
	bit.16b	v30, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_77
; %bb.78:                               ; %direct.false358
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q31, [sp, #2032]                ; 16-byte Spill
	str	q30, [sp, #1856]                ; 16-byte Spill
	ldr	q30, [sp, #2048]                ; 16-byte Reload
	and.16b	v30, v23, v30
	ldr	q7, [sp, #2352]                 ; 16-byte Reload
	and.16b	v26, v7, v26
	mov	x3, x10
	mov	w4, #80                         ; =0x50
	ldr	q7, [sp, #1824]                 ; 16-byte Reload
LBB0_79:                                ; %direct.true374
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #31744]
	ldr	q20, [x3, #31760]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v26, v17
	fadd.4s	v18, v30, v18
	bit.16b	v30, v18, v0
	bit.16b	v26, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_79
; %bb.80:                               ; %direct.false375
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q30, [sp, #2048]                ; 16-byte Spill
	str	q26, [sp, #1872]                ; 16-byte Spill
	ldr	q26, [sp, #2224]                ; 16-byte Reload
	and.16b	v26, v23, v26
	ldr	q17, [sp, #2352]                ; 16-byte Reload
	and.16b	v27, v17, v27
	mov	x3, x10
	mov	w4, #80                         ; =0x50
LBB0_81:                                ; %direct.true391
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #34304]
	ldr	q20, [x3, #34320]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v27, v17
	fadd.4s	v18, v26, v18
	bit.16b	v26, v18, v0
	bit.16b	v27, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_81
; %bb.82:                               ; %direct.false392
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q26, [sp, #2224]                ; 16-byte Spill
	str	q27, [sp, #1888]                ; 16-byte Spill
	ldr	q27, [sp, #2240]                ; 16-byte Reload
	and.16b	v27, v23, v27
	ldr	q26, [sp, #2352]                ; 16-byte Reload
	and.16b	v29, v26, v29
	mov	x3, x10
	mov	w4, #80                         ; =0x50
LBB0_83:                                ; %direct.true408
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #36864]
	ldr	q20, [x3, #36880]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v29, v17
	fadd.4s	v18, v27, v18
	bit.16b	v27, v18, v0
	bit.16b	v29, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_83
; %bb.84:                               ; %direct.false409
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q27, [sp, #2240]                ; 16-byte Spill
	str	q29, [sp, #1904]                ; 16-byte Spill
	ldr	q29, [sp, #2064]                ; 16-byte Reload
	and.16b	v29, v23, v29
	ldr	q27, [sp, #2256]                ; 16-byte Reload
	and.16b	v27, v26, v27
	mov	x3, x10
	mov	w4, #80                         ; =0x50
LBB0_85:                                ; %direct.true425
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #39424]
	ldr	q20, [x3, #39440]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v27, v17
	fadd.4s	v18, v29, v18
	bit.16b	v29, v18, v0
	bit.16b	v27, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_85
; %bb.86:                               ; %direct.false426
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q29, [sp, #2064]                ; 16-byte Spill
	str	q27, [sp, #2256]                ; 16-byte Spill
	and.16b	v12, v23, v12
	and.16b	v25, v26, v25
	mov	x3, x10
	mov	w4, #80                         ; =0x50
LBB0_87:                                ; %direct.true442
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #41984]
	ldr	q20, [x3, #42000]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v25, v17
	fadd.4s	v18, v12, v18
	bit.16b	v12, v18, v0
	bit.16b	v25, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_87
; %bb.88:                               ; %direct.false443
                                        ;   in Loop: Header=BB0_22 Depth=1
	and.16b	v24, v23, v24
	and.16b	v11, v26, v11
	mov	x3, x10
	mov	w4, #80                         ; =0x50
	ldr	q29, [sp, #2048]                ; 16-byte Reload
	ldr	q27, [sp, #2032]                ; 16-byte Reload
LBB0_89:                                ; %direct.true459
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #44544]
	ldr	q20, [x3, #44560]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v11, v17
	fadd.4s	v18, v24, v18
	bit.16b	v24, v18, v0
	bit.16b	v11, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_89
; %bb.90:                               ; %direct.false460
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q12, [sp, #2080]                ; 16-byte Spill
	str	q25, [sp, #2096]                ; 16-byte Spill
	str	q24, [sp, #2112]                ; 16-byte Spill
	str	q11, [sp, #2128]                ; 16-byte Spill
	ldr	q26, [sp, #1584]                ; 16-byte Reload
	and.16b	v26, v23, v26
	ldr	q17, [sp, #2352]                ; 16-byte Reload
	and.16b	v22, v17, v22
	mov	x3, x10
	mov	w4, #80                         ; =0x50
LBB0_91:                                ; %direct.true476
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q18, [x3]
	ldr	q19, [x3, #47104]
	ldr	q20, [x3, #47120]
	fmul.4s	v18, v18, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v22, v17
	fadd.4s	v18, v26, v18
	bit.16b	v26, v18, v0
	bit.16b	v22, v17, v1
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_91
; %bb.92:                               ; %direct.false477
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x3, #0                          ; =0x0
	mov	w4, #63790                      ; =0xf92e
	movk	w4, #15844, lsl #16
	dup.4s	v12, w4
	cmp	x0, #128
	cset	w4, lo
	dup.4h	v24, w4
	str	q21, [sp, #512]                 ; 16-byte Spill
	fmul.4s	v23, v21, v12
	str	q2, [sp, #336]                  ; 16-byte Spill
	fmul.4s	v21, v2, v12
	ldp	x5, x6, [sp, #296]              ; 16-byte Folded Reload
	ldp	q17, q18, [x6]
	ldr	q11, [sp, #1456]                ; 16-byte Reload
	fmul.4s	v20, v11, v12
	ldr	q19, [sp, #1920]                ; 16-byte Reload
	fmul.4s	v19, v19, v12
	str	q21, [sp, #2416]                ; 16-byte Spill
	bit.16b	v18, v21, v0
	str	q23, [sp, #2400]                ; 16-byte Spill
	bit.16b	v17, v23, v1
	stp	q17, q18, [x6]
	fmul.4s	v25, v10, v12
	ldr	q17, [sp, #1936]                ; 16-byte Reload
	fmul.4s	v23, v17, v12
	fmul.4s	v13, v9, v12
	ldr	q17, [sp, #1952]                ; 16-byte Reload
	fmul.4s	v31, v17, v12
	ldp	q17, q18, [x5]
	fmul.4s	v21, v16, v12
	str	q19, [sp, #1760]                ; 16-byte Spill
	bit.16b	v18, v19, v0
	str	q20, [sp, #1360]                ; 16-byte Spill
	bit.16b	v17, v20, v1
	stp	q17, q18, [x5]
	ldr	q16, [sp, #1968]                ; 16-byte Reload
	fmul.4s	v30, v16, v12
	ldr	q16, [sp, #1984]                ; 16-byte Reload
	fmul.4s	v17, v16, v12
	ldr	q16, [sp, #1808]                ; 16-byte Reload
	fmul.4s	v18, v16, v12
	ldp	x5, x7, [sp, #280]              ; 16-byte Folded Reload
	ldp	q19, q20, [x7]
	mov.16b	v2, v22
	ldr	q22, [sp, #2000]                ; 16-byte Reload
	fmul.4s	v22, v22, v12
	str	q23, [sp, #1280]                ; 16-byte Spill
	bit.16b	v20, v23, v0
	str	q25, [sp, #1264]                ; 16-byte Spill
	bit.16b	v19, v25, v1
	stp	q19, q20, [x7]
	fmul.4s	v19, v7, v12
	ldr	q7, [sp, #2016]                 ; 16-byte Reload
	fmul.4s	v20, v7, v12
	ldr	q7, [sp, #1840]                 ; 16-byte Reload
	fmul.4s	v23, v7, v12
	mov.16b	v9, v26
	ldp	q25, q26, [x5]
	fmul.4s	v27, v27, v12
	str	q31, [sp, #1184]                ; 16-byte Spill
	bit.16b	v26, v31, v0
	str	q13, [sp, #1168]                ; 16-byte Spill
	bit.16b	v25, v13, v1
	stp	q25, q26, [x5]
	ldr	q7, [sp, #1856]                 ; 16-byte Reload
	fmul.4s	v25, v7, v12
	ldr	q26, [sp, #1872]                ; 16-byte Reload
	fmul.4s	v26, v26, v12
	fmul.4s	v29, v29, v12
	ldr	x5, [sp, #272]                  ; 8-byte Reload
	ldp	q31, q13, [x5]
	ushll.4s	v24, v24, #0
	str	q30, [sp, #1088]                ; 16-byte Spill
	bit.16b	v13, v30, v0
	str	q21, [sp, #1072]                ; 16-byte Spill
	bit.16b	v31, v21, v1
	stp	q31, q13, [x5]
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	ldr	q13, [sp, #320]                 ; 16-byte Reload
	mov.16b	v7, v24
	bsl.16b	v7, v18, v13
	ldr	x5, [sp, #264]                  ; 8-byte Reload
	ldp	q18, q31, [x5]
	mov.16b	v16, v24
	bsl.16b	v16, v17, v13
	stp	q16, q7, [sp, #976]             ; 32-byte Folded Spill
	mov.16b	v17, v0
	bsl.16b	v17, v16, v31
	bit.16b	v18, v7, v1
	stp	q18, q17, [x5]
	ldr	q17, [sp, #1888]                ; 16-byte Reload
	fmul.4s	v17, v17, v12
	ldr	q18, [sp, #2224]                ; 16-byte Reload
	fmul.4s	v18, v18, v12
	mov.16b	v7, v24
	bsl.16b	v7, v19, v13
	ldr	x5, [sp, #256]                  ; 8-byte Reload
	ldp	q19, q31, [x5]
	mov.16b	v16, v24
	bsl.16b	v16, v22, v13
	stp	q16, q7, [sp, #880]             ; 32-byte Folded Spill
	mov.16b	v22, v0
	bsl.16b	v22, v16, v31
	bit.16b	v19, v7, v1
	stp	q19, q22, [x5]
	ldr	q19, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v19, v19, v12
	ldr	q22, [sp, #2240]                ; 16-byte Reload
	fmul.4s	v22, v22, v12
	mov.16b	v7, v24
	bsl.16b	v7, v23, v13
	ldr	x5, [sp, #248]                  ; 8-byte Reload
	ldp	q23, q31, [x5]
	mov.16b	v16, v24
	bsl.16b	v16, v20, v13
	stp	q16, q7, [sp, #784]             ; 32-byte Folded Spill
	mov.16b	v20, v0
	bsl.16b	v20, v16, v31
	bit.16b	v23, v7, v1
	stp	q23, q20, [x5]
	ldr	q20, [sp, #2256]                ; 16-byte Reload
	fmul.4s	v20, v20, v12
	ldr	q23, [sp, #2064]                ; 16-byte Reload
	fmul.4s	v23, v23, v12
	mov.16b	v7, v24
	bsl.16b	v7, v25, v13
	ldr	x5, [sp, #216]                  ; 8-byte Reload
	ldp	q25, q31, [x5]
	mov.16b	v16, v24
	bsl.16b	v16, v27, v13
	stp	q16, q7, [sp, #688]             ; 32-byte Folded Spill
	mov.16b	v27, v0
	bsl.16b	v27, v16, v31
	bit.16b	v25, v7, v1
	stp	q25, q27, [x5]
	ldr	q25, [sp, #2080]                ; 16-byte Reload
	fmul.4s	v25, v25, v12
	ldr	q27, [sp, #2096]                ; 16-byte Reload
	fmul.4s	v27, v27, v12
	mov.16b	v7, v24
	bsl.16b	v7, v29, v13
	ldr	x5, [sp, #208]                  ; 8-byte Reload
	ldp	q31, q29, [x5]
	mov.16b	v16, v24
	bsl.16b	v16, v26, v13
	stp	q16, q7, [sp, #720]             ; 32-byte Folded Spill
	mov.16b	v26, v1
	bsl.16b	v26, v16, v31
	bit.16b	v29, v7, v0
	stp	q26, q29, [x5]
	mov.16b	v7, v24
	bsl.16b	v7, v18, v13
	mov.16b	v16, v24
	bsl.16b	v16, v17, v13
	bif.16b	v22, v13, v24
	ldr	x5, [sp, #200]                  ; 8-byte Reload
	ldp	q18, q17, [x5]
	bif.16b	v19, v13, v24
	stp	q16, q7, [sp, #816]             ; 32-byte Folded Spill
	bit.16b	v18, v16, v1
	bit.16b	v17, v7, v0
	stp	q18, q17, [x5]
	mov.16b	v7, v24
	bsl.16b	v7, v23, v13
	mov.16b	v16, v24
	bsl.16b	v16, v20, v13
	ldr	x5, [sp, #192]                  ; 8-byte Reload
	ldp	q18, q17, [x5]
	stp	q19, q22, [sp, #912]            ; 32-byte Folded Spill
	bit.16b	v18, v19, v1
	bit.16b	v17, v22, v0
	stp	q18, q17, [x5]
	ldr	x5, [sp, #184]                  ; 8-byte Reload
	ldp	q18, q17, [x5]
	stp	q16, q7, [sp, #1008]            ; 32-byte Folded Spill
	bit.16b	v18, v16, v1
	bit.16b	v17, v7, v0
	stp	q18, q17, [x5]
	ldr	q17, [sp, #2128]                ; 16-byte Reload
	fmul.4s	v17, v17, v12
	ldr	q18, [sp, #2112]                ; 16-byte Reload
	fmul.4s	v18, v18, v12
	str	q2, [sp, #1600]                 ; 16-byte Spill
	fmul.4s	v19, v2, v12
	str	q9, [sp, #1584]                 ; 16-byte Spill
	fmul.4s	v20, v9, v12
	mov.16b	v26, v24
	bsl.16b	v26, v27, v13
	bif.16b	v25, v13, v24
	mov.16b	v22, v24
	bsl.16b	v22, v18, v13
	mov.16b	v23, v24
	bsl.16b	v23, v17, v13
	mov.16b	v7, v24
	bsl.16b	v7, v20, v13
	mov.16b	v16, v24
	bsl.16b	v16, v19, v13
	ldr	x5, [sp, #176]                  ; 8-byte Reload
	ldp	q18, q17, [x5]
	str	q25, [sp, #1104]                ; 16-byte Spill
	bit.16b	v17, v25, v0
	str	q26, [sp, #1120]                ; 16-byte Spill
	bit.16b	v18, v26, v1
	stp	q18, q17, [x5]
	ldr	x5, [sp, #168]                  ; 8-byte Reload
	ldp	q17, q18, [x5]
	str	q23, [sp, #1200]                ; 16-byte Spill
	bit.16b	v17, v23, v1
	str	q22, [sp, #1216]                ; 16-byte Spill
	bit.16b	v18, v22, v0
	stp	q17, q18, [x5]
	ldr	x5, [sp, #160]                  ; 8-byte Reload
	ldp	q17, q18, [x5]
	str	q16, [sp, #1296]                ; 16-byte Spill
	bit.16b	v17, v16, v1
	str	q7, [sp, #1312]                 ; 16-byte Spill
	bit.16b	v18, v7, v0
	stp	q17, q18, [x5]
	mvni.4s	v17, #127, msl #16
	ldr	q20, [sp, #1616]                ; 16-byte Reload
	bit.16b	v20, v17, v0
	ldr	q19, [sp, #1632]                ; 16-byte Reload
	bit.16b	v19, v17, v1
	dup.8b	v7, w4
	str	d7, [sp, #1440]                 ; 8-byte Spill
LBB0_93:                                ; %direct.true590
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x4, x14, x3
	ldp	q17, q18, [x4]
	and.16b	v18, v0, v18
	and.16b	v17, v1, v17
	fmaxnm.4s	v17, v19, v17
	fmaxnm.4s	v18, v20, v18
	bit.16b	v20, v18, v0
	bit.16b	v19, v17, v1
	add	x3, x3, #32
	cmp	x3, #512
	b.ne	LBB0_93
; %bb.94:                               ; %direct.false591
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x3, #0                          ; =0x0
	ldr	q17, [sp, #1728]                ; 16-byte Reload
	ldr	q18, [sp, #1648]                ; 16-byte Reload
	ldr	q7, [sp, #2736]                 ; 16-byte Reload
	bit.16b	v18, v17, v7
	str	q18, [sp, #1648]                ; 16-byte Spill
	ldr	q7, [sp, #1712]                 ; 16-byte Reload
	ldr	q17, [sp, #1680]                ; 16-byte Reload
	ldr	q16, [sp, #2752]                ; 16-byte Reload
	bit.16b	v17, v7, v16
	str	q17, [sp, #1680]                ; 16-byte Spill
	str	q19, [sp, #1632]                ; 16-byte Spill
	ldr	q7, [sp, #2176]                 ; 16-byte Reload
	fmaxnm.4s	v7, v7, v19
	str	q7, [sp, #2304]                 ; 16-byte Spill
	ldr	q16, [sp, #2400]                ; 16-byte Reload
	fsub.4s	v17, v16, v7
	and.16b	v13, v1, v17
	mov	w4, #-1026555904                ; =0xc2d00000
	dup.4s	v23, w4
	fcmge.4s	v17, v13, v23
	mov	w4, #1120403456                 ; =0x42c80000
	dup.4s	v7, w4
	fcmge.4s	v18, v7, v13
	and.16b	v17, v17, v18
	str	q20, [sp, #1616]                ; 16-byte Spill
	ldr	q16, [sp, #2192]                ; 16-byte Reload
	fmaxnm.4s	v16, v16, v20
	str	q16, [sp, #2272]                ; 16-byte Spill
	ldr	q18, [sp, #2416]                ; 16-byte Reload
	fsub.4s	v18, v18, v16
	and.16b	v26, v0, v18
	fcmge.4s	v18, v26, v23
	fcmge.4s	v19, v7, v26
	and.16b	v18, v18, v19
	and.16b	v18, v18, v26
	mov	w4, #43579                      ; =0xaa3b
	movk	w4, #16312, lsl #16
	dup.4s	v16, w4
	fmul.4s	v19, v18, v16
	movi.4s	v22, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v20, v24
	bsl.16b	v20, v22, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v13
	fmul.4s	v20, v17, v16
	bif.16b	v22, v20, v24
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	mov	w4, #29184                      ; =0x7200
	movk	w4, #16177, lsl #16
	dup.4s	v27, w4
	fmul.4s	v22, v19, v27
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v25, v20
	scvtf.4s	v20, v25
	fmul.4s	v22, v20, v27
	fsub.4s	v17, v17, v22
	mov	w4, #48782                      ; =0xbe8e
	movk	w4, #13759, lsl #16
	dup.4s	v29, w4
	fmul.4s	v20, v20, v29
	fsub.4s	v17, v17, v20
	fmul.4s	v19, v19, v29
	fsub.4s	v18, v18, v19
	mov	w4, #11226                      ; =0x2bda
	movk	w4, #14672, lsl #16
	dup.4s	v30, w4
	fmul.4s	v19, v18, v30
	mov	w4, #38601                      ; =0x96c9
	movk	w4, #15030, lsl #16
	dup.4s	v12, w4
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	mov	w4, #34982                      ; =0x88a6
	movk	w4, #15368, lsl #16
	dup.4s	v2, w4
	fadd.4s	v19, v19, v2
	mov	w4, #43642                      ; =0xaa7a
	movk	w4, #15658, lsl #16
	dup.4s	v21, w4
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v18, v19
	mov	w4, #43691                      ; =0xaaab
	movk	w4, #15914, lsl #16
	dup.4s	v9, w4
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v18, v19
	movi.4s	v20, #63, lsl #24
	fadd.4s	v19, v19, v20
	movi.4s	v22, #63, lsl #24
	fmul.4s	v20, v18, v18
	fmul.4s	v19, v20, v19
	fmul.4s	v20, v17, v30
	fadd.4s	v20, v20, v12
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v2
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v22
	fmul.4s	v22, v17, v17
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v18, v18, v19
	fmov.4s	v31, #1.00000000
	fadd.4s	v17, v17, v31
	sshr.4s	v19, v25, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v31
	fmul.4s	v17, v17, v20
	fadd.4s	v18, v18, v31
	sshr.4s	v20, v24, #1
	shl.4s	v22, v20, #23
	add.4s	v22, v22, v31
	fmul.4s	v18, v18, v22
	sub.4s	v19, v25, v19
	sub.4s	v20, v24, v20
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v31
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v31
	fmul.4s	v17, v17, v19
	str	q13, [sp, #1376]                ; 16-byte Spill
	fcmgt.4s	v19, v23, v13
	bic.16b	v17, v17, v19
	str	q26, [sp, #1424]                ; 16-byte Spill
	fcmgt.4s	v19, v23, v26
	mov.16b	v25, v23
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v26, v7
	mvni.4s	v20, #127, msl #16
	fneg.4s	v26, v20
	bit.16b	v18, v26, v19
	str	q18, [sp, #1408]                ; 16-byte Spill
	fcmgt.4s	v18, v13, v7
	bit.16b	v17, v26, v18
	str	q17, [sp, #1392]                ; 16-byte Spill
	ldr	q17, [sp, #1360]                ; 16-byte Reload
	ldr	q18, [sp, #2304]                ; 16-byte Reload
	fsub.4s	v17, v17, v18
	and.16b	v31, v1, v17
	fcmge.4s	v17, v31, v23
	fcmge.4s	v18, v7, v31
	and.16b	v17, v17, v18
	ldr	q18, [sp, #1760]                ; 16-byte Reload
	ldr	q19, [sp, #2272]                ; 16-byte Reload
	fsub.4s	v18, v18, v19
	and.16b	v20, v0, v18
	str	q20, [sp, #1760]                ; 16-byte Spill
	fcmge.4s	v18, v20, v23
	fcmge.4s	v19, v7, v20
	and.16b	v18, v18, v19
	and.16b	v18, v18, v20
	str	q16, [sp, #2400]                ; 16-byte Spill
	fmul.4s	v19, v18, v16
	mvni.4s	v22, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v20, v22
	bsl.16b	v20, v23, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v31
	fmul.4s	v20, v17, v16
	bsl.16b	v22, v23, v20
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	str	q27, [sp, #2416]                ; 16-byte Spill
	fmul.4s	v22, v19, v27
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v27
	fsub.4s	v17, v17, v23
	str	q29, [sp, #2368]                ; 16-byte Spill
	fmul.4s	v22, v22, v29
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v29
	fsub.4s	v18, v18, v19
	mov.16b	v29, v30
	fmul.4s	v19, v18, v30
	str	q12, [sp, #2208]                ; 16-byte Spill
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v19, v18, v19
	str	q21, [sp, #2336]                ; 16-byte Spill
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v18, v19
	movi.4s	v23, #63, lsl #24
	fadd.4s	v19, v19, v23
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v30
	fadd.4s	v22, v22, v12
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v2
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v21
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v9
	mov.16b	v30, v9
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fmov.4s	v27, #1.00000000
	fadd.4s	v17, v17, v27
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v27
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v27
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v27
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v27
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v27
	fmov.4s	v13, #1.00000000
	fmul.4s	v17, v17, v19
	str	q31, [sp, #1328]                ; 16-byte Spill
	fcmgt.4s	v19, v25, v31
	bic.16b	v17, v17, v19
	ldr	q20, [sp, #1760]                ; 16-byte Reload
	fcmgt.4s	v19, v25, v20
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v20, v7
	str	q26, [sp, #2384]                ; 16-byte Spill
	bit.16b	v18, v26, v19
	str	q18, [sp, #1360]                ; 16-byte Spill
	fcmgt.4s	v18, v31, v7
	bit.16b	v17, v26, v18
	str	q17, [sp, #1344]                ; 16-byte Spill
	ldr	q12, [sp, #2304]                ; 16-byte Reload
	ldr	q16, [sp, #1264]                ; 16-byte Reload
	fsub.4s	v17, v16, v12
	and.16b	v16, v1, v17
	fcmge.4s	v17, v16, v25
	fcmge.4s	v18, v7, v16
	and.16b	v17, v17, v18
	ldr	q18, [sp, #1280]                ; 16-byte Reload
	ldr	q21, [sp, #2272]                ; 16-byte Reload
	fsub.4s	v18, v18, v21
	and.16b	v26, v0, v18
	fcmge.4s	v18, v26, v25
	fcmge.4s	v19, v7, v26
	and.16b	v18, v18, v19
	and.16b	v18, v18, v26
	ldr	q24, [sp, #2400]                ; 16-byte Reload
	fmul.4s	v19, v18, v24
	movi.4s	v22, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	mov.16b	v20, v23
	bsl.16b	v20, v22, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v16
	fmul.4s	v20, v17, v24
	bif.16b	v22, v20, v23
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q23, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v22, v19, v23
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v23
	fsub.4s	v17, v17, v23
	ldr	q9, [sp, #2368]                 ; 16-byte Reload
	fmul.4s	v22, v22, v9
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v9
	fsub.4s	v18, v18, v19
	mov.16b	v27, v29
	str	q29, [sp, #2160]                ; 16-byte Spill
	fmul.4s	v19, v18, v29
	ldr	q29, [sp, #2208]                ; 16-byte Reload
	fadd.4s	v19, v19, v29
	fmul.4s	v19, v18, v19
	mov.16b	v31, v2
	fadd.4s	v19, v19, v2
	fmul.4s	v19, v18, v19
	ldr	q2, [sp, #2336]                 ; 16-byte Reload
	fadd.4s	v19, v19, v2
	fmul.4s	v19, v18, v19
	str	q30, [sp, #2320]                ; 16-byte Spill
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v18, v19
	movi.4s	v23, #63, lsl #24
	fadd.4s	v19, v19, v23
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v27
	fadd.4s	v22, v22, v29
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v2
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	str	q16, [sp, #1232]                ; 16-byte Spill
	fcmgt.4s	v19, v25, v16
	bic.16b	v17, v17, v19
	str	q26, [sp, #1264]                ; 16-byte Spill
	fcmgt.4s	v19, v25, v26
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v26, v7
	ldr	q2, [sp, #2384]                 ; 16-byte Reload
	bit.16b	v18, v2, v19
	str	q18, [sp, #1280]                ; 16-byte Spill
	fcmgt.4s	v18, v16, v7
	mov.16b	v16, v18
	bsl.16b	v16, v2, v17
	str	q16, [sp, #1248]                ; 16-byte Spill
	ldr	q16, [sp, #1168]                ; 16-byte Reload
	fsub.4s	v17, v16, v12
	mov.16b	v30, v12
	and.16b	v27, v1, v17
	fcmge.4s	v17, v27, v25
	fcmge.4s	v18, v7, v27
	and.16b	v17, v17, v18
	mov.16b	v12, v21
	ldr	q16, [sp, #1184]                ; 16-byte Reload
	fsub.4s	v18, v16, v21
	and.16b	v29, v0, v18
	fcmge.4s	v18, v29, v25
	fcmge.4s	v19, v7, v29
	and.16b	v18, v18, v19
	and.16b	v18, v18, v29
	ldr	q2, [sp, #2400]                 ; 16-byte Reload
	fmul.4s	v19, v18, v2
	mvni.4s	v16, #128, lsl #24
	movi.4s	v22, #75, lsl #24
	mov.16b	v20, v16
	bsl.16b	v20, v22, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v27
	fmul.4s	v20, v17, v2
	bif.16b	v22, v20, v16
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q2, [sp, #2416]                 ; 16-byte Reload
	fmul.4s	v22, v19, v2
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v2
	fsub.4s	v17, v17, v23
	mov.16b	v26, v9
	fmul.4s	v22, v22, v9
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v9
	fsub.4s	v18, v18, v19
	ldr	q9, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v19, v18, v9
	ldr	q2, [sp, #2208]                 ; 16-byte Reload
	fadd.4s	v19, v19, v2
	fmul.4s	v19, v18, v19
	str	q31, [sp, #2288]                ; 16-byte Spill
	fadd.4s	v19, v19, v31
	fmul.4s	v19, v18, v19
	ldr	q21, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v18, v19
	ldr	q16, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v19, v19, v16
	fmul.4s	v19, v18, v19
	movi.4s	v23, #63, lsl #24
	fadd.4s	v19, v19, v23
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v9
	fadd.4s	v22, v22, v2
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v21
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	str	q27, [sp, #1136]                ; 16-byte Spill
	fcmgt.4s	v19, v25, v27
	bic.16b	v17, v17, v19
	str	q29, [sp, #1168]                ; 16-byte Spill
	fcmgt.4s	v19, v25, v29
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v29, v7
	ldr	q20, [sp, #2384]                ; 16-byte Reload
	mov.16b	v16, v19
	bsl.16b	v16, v20, v18
	str	q16, [sp, #1184]                ; 16-byte Spill
	fcmgt.4s	v18, v27, v7
	mov.16b	v16, v18
	bsl.16b	v16, v20, v17
	str	q16, [sp, #1152]                ; 16-byte Spill
	ldr	q16, [sp, #1072]                ; 16-byte Reload
	fsub.4s	v17, v16, v30
	mov.16b	v9, v30
	and.16b	v29, v1, v17
	fcmge.4s	v17, v29, v25
	fcmge.4s	v18, v7, v29
	and.16b	v17, v17, v18
	ldr	q16, [sp, #1088]                ; 16-byte Reload
	fsub.4s	v18, v16, v12
	mov.16b	v31, v12
	and.16b	v12, v0, v18
	fcmge.4s	v18, v12, v25
	fcmge.4s	v19, v7, v12
	and.16b	v18, v18, v19
	and.16b	v18, v18, v12
	ldr	q21, [sp, #2400]                ; 16-byte Reload
	fmul.4s	v19, v18, v21
	movi.4s	v16, #75, lsl #24
	mvni.4s	v22, #128, lsl #24
	mov.16b	v20, v22
	bsl.16b	v20, v16, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v29
	fmul.4s	v20, v17, v21
	bsl.16b	v22, v16, v20
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q16, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v22, v19, v16
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v16
	fsub.4s	v17, v17, v23
	fmul.4s	v22, v22, v26
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v26
	fsub.4s	v18, v18, v19
	ldr	q21, [sp, #2160]                ; 16-byte Reload
	fmul.4s	v19, v18, v21
	mov.16b	v30, v2
	fadd.4s	v19, v19, v2
	fmul.4s	v19, v18, v19
	ldr	q27, [sp, #2288]                ; 16-byte Reload
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v18, v19
	ldr	q23, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v18, v19
	ldr	q16, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v19, v19, v16
	fmul.4s	v19, v18, v19
	movi.4s	v2, #63, lsl #24
	fadd.4s	v19, v19, v2
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v21
	fadd.4s	v22, v22, v30
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v27
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v2
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	str	q29, [sp, #1040]                ; 16-byte Spill
	fcmgt.4s	v19, v25, v29
	bic.16b	v17, v17, v19
	str	q12, [sp, #1072]                ; 16-byte Spill
	fcmgt.4s	v19, v25, v12
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v12, v7
	ldr	q2, [sp, #2384]                 ; 16-byte Reload
	mov.16b	v16, v19
	bsl.16b	v16, v2, v18
	str	q16, [sp, #1088]                ; 16-byte Spill
	fcmgt.4s	v18, v29, v7
	mov.16b	v16, v18
	bsl.16b	v16, v2, v17
	str	q16, [sp, #1056]                ; 16-byte Spill
	ldr	q16, [sp, #976]                 ; 16-byte Reload
	fsub.4s	v17, v16, v31
	mov.16b	v2, v31
	and.16b	v29, v0, v17
	fcmge.4s	v17, v29, v25
	fcmge.4s	v18, v7, v29
	and.16b	v17, v17, v18
	mov.16b	v16, v9
	ldr	q18, [sp, #992]                 ; 16-byte Reload
	fsub.4s	v18, v18, v9
	and.16b	v26, v1, v18
	fcmge.4s	v18, v26, v25
	fcmge.4s	v19, v7, v26
	and.16b	v18, v18, v19
	and.16b	v18, v18, v26
	ldr	q24, [sp, #2400]                ; 16-byte Reload
	fmul.4s	v19, v18, v24
	mvni.4s	v22, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v20, v22
	bsl.16b	v20, v23, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v29
	fmul.4s	v20, v17, v24
	bsl.16b	v22, v23, v20
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q23, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v22, v19, v23
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v23
	fsub.4s	v17, v17, v23
	ldr	q23, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v22, v22, v23
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v23
	fsub.4s	v18, v18, v19
	fmul.4s	v19, v18, v21
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v18, v19
	ldr	q23, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v18, v19
	ldr	q12, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	movi.4s	v31, #63, lsl #24
	fadd.4s	v19, v19, v31
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v21
	fadd.4s	v22, v22, v30
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v27
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v31
	movi.4s	v9, #63, lsl #24
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	fcmgt.4s	v19, v25, v29
	bic.16b	v17, v17, v19
	fcmgt.4s	v19, v25, v26
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v26, v7
	ldr	q20, [sp, #2384]                ; 16-byte Reload
	bit.16b	v18, v20, v19
	stp	q26, q18, [sp, #976]            ; 32-byte Folded Spill
	fcmgt.4s	v18, v29, v7
	bit.16b	v17, v20, v18
	stp	q29, q17, [sp, #944]            ; 32-byte Folded Spill
	mov.16b	v29, v2
	ldr	q17, [sp, #880]                 ; 16-byte Reload
	fsub.4s	v17, v17, v2
	and.16b	v26, v0, v17
	fcmge.4s	v17, v26, v25
	fcmge.4s	v18, v7, v26
	and.16b	v17, v17, v18
	ldr	q18, [sp, #896]                 ; 16-byte Reload
	fsub.4s	v18, v18, v16
	and.16b	v16, v1, v18
	fcmge.4s	v18, v16, v25
	fcmge.4s	v19, v7, v16
	and.16b	v18, v18, v19
	and.16b	v18, v18, v16
	ldr	q2, [sp, #2400]                 ; 16-byte Reload
	fmul.4s	v19, v18, v2
	movi.4s	v22, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	mov.16b	v20, v23
	bsl.16b	v20, v22, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v26
	fmul.4s	v20, v17, v2
	bif.16b	v22, v20, v23
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q2, [sp, #2416]                 ; 16-byte Reload
	fmul.4s	v22, v19, v2
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v2
	fsub.4s	v17, v17, v23
	ldr	q2, [sp, #2368]                 ; 16-byte Reload
	fmul.4s	v22, v22, v2
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v2
	fsub.4s	v18, v18, v19
	mov.16b	v31, v21
	fmul.4s	v19, v18, v21
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v18, v19
	ldr	q2, [sp, #2336]                 ; 16-byte Reload
	fadd.4s	v19, v19, v2
	fmul.4s	v19, v18, v19
	mov.16b	v23, v12
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v21
	fadd.4s	v22, v22, v30
	mov.16b	v12, v30
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v27
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v2
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v9
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	fcmgt.4s	v19, v25, v26
	bic.16b	v17, v17, v19
	str	q16, [sp, #880]                 ; 16-byte Spill
	fcmgt.4s	v19, v25, v16
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v16, v7
	ldr	q9, [sp, #2384]                 ; 16-byte Reload
	mov.16b	v16, v19
	bsl.16b	v16, v9, v18
	str	q16, [sp, #896]                 ; 16-byte Spill
	fcmgt.4s	v18, v26, v7
	mov.16b	v16, v18
	bsl.16b	v16, v9, v17
	stp	q26, q16, [sp, #848]            ; 32-byte Folded Spill
	ldr	q16, [sp, #784]                 ; 16-byte Reload
	fsub.4s	v17, v16, v29
	mov.16b	v30, v29
	and.16b	v16, v0, v17
	fcmge.4s	v17, v16, v25
	fcmge.4s	v18, v7, v16
	and.16b	v17, v17, v18
	ldr	q18, [sp, #800]                 ; 16-byte Reload
	ldr	q21, [sp, #2304]                ; 16-byte Reload
	fsub.4s	v18, v18, v21
	and.16b	v29, v1, v18
	fcmge.4s	v18, v29, v25
	fcmge.4s	v19, v7, v29
	and.16b	v18, v18, v19
	and.16b	v18, v18, v29
	ldr	q24, [sp, #2400]                ; 16-byte Reload
	fmul.4s	v19, v18, v24
	mvni.4s	v22, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v20, v22
	bsl.16b	v20, v23, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v16
	fmul.4s	v20, v17, v24
	bsl.16b	v22, v23, v20
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q23, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v22, v19, v23
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v23
	fsub.4s	v17, v17, v23
	ldr	q23, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v22, v22, v23
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v23
	fsub.4s	v18, v18, v19
	fmul.4s	v19, v18, v31
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	mov.16b	v26, v27
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v2
	fmul.4s	v19, v18, v19
	ldr	q27, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v18, v19
	movi.4s	v23, #63, lsl #24
	fadd.4s	v19, v19, v23
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v31
	fadd.4s	v22, v22, v12
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v26
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v2
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v27
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	str	q16, [sp, #752]                 ; 16-byte Spill
	fcmgt.4s	v19, v25, v16
	bic.16b	v17, v17, v19
	fcmgt.4s	v19, v25, v29
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v29, v7
	bit.16b	v18, v9, v19
	stp	q29, q18, [sp, #784]            ; 32-byte Folded Spill
	fcmgt.4s	v18, v16, v7
	mov.16b	v16, v18
	bsl.16b	v16, v9, v17
	str	q16, [sp, #768]                 ; 16-byte Spill
	ldr	q16, [sp, #688]                 ; 16-byte Reload
	fsub.4s	v17, v16, v30
	mov.16b	v9, v30
	and.16b	v26, v0, v17
	fcmge.4s	v17, v26, v25
	fcmge.4s	v18, v7, v26
	and.16b	v17, v17, v18
	mov.16b	v16, v21
	ldr	q18, [sp, #704]                 ; 16-byte Reload
	fsub.4s	v18, v18, v21
	and.16b	v27, v1, v18
	fcmge.4s	v18, v27, v25
	fcmge.4s	v19, v7, v27
	and.16b	v18, v18, v19
	and.16b	v18, v18, v27
	ldr	q2, [sp, #2400]                 ; 16-byte Reload
	fmul.4s	v19, v18, v2
	movi.4s	v23, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v20, v24
	bsl.16b	v20, v23, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v26
	fmul.4s	v20, v17, v2
	mov.16b	v22, v24
	bsl.16b	v22, v23, v20
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q30, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v22, v19, v30
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v30
	fsub.4s	v17, v17, v23
	ldr	q2, [sp, #2368]                 ; 16-byte Reload
	fmul.4s	v22, v22, v2
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v2
	fsub.4s	v18, v18, v19
	mov.16b	v29, v31
	fmul.4s	v19, v18, v31
	mov.16b	v2, v12
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	ldr	q12, [sp, #2288]                ; 16-byte Reload
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	ldr	q21, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v18, v19
	ldr	q31, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v19, v19, v31
	fmul.4s	v19, v18, v19
	movi.4s	v23, #63, lsl #24
	fadd.4s	v19, v19, v23
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v29
	fadd.4s	v22, v22, v2
	mov.16b	v29, v2
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v21
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	stp	q27, q26, [sp, #656]            ; 32-byte Folded Spill
	fcmgt.4s	v19, v25, v26
	bic.16b	v17, v17, v19
	fcmgt.4s	v19, v25, v27
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v27, v7
	ldr	q2, [sp, #2384]                 ; 16-byte Reload
	bit.16b	v18, v2, v19
	str	q18, [sp, #704]                 ; 16-byte Spill
	fcmgt.4s	v18, v26, v7
	bit.16b	v17, v2, v18
	str	q17, [sp, #688]                 ; 16-byte Spill
	ldr	q17, [sp, #720]                 ; 16-byte Reload
	fsub.4s	v17, v17, v16
	and.16b	v27, v1, v17
	fcmge.4s	v17, v27, v25
	fcmge.4s	v18, v7, v27
	and.16b	v17, v17, v18
	mov.16b	v26, v9
	ldr	q16, [sp, #736]                 ; 16-byte Reload
	fsub.4s	v18, v16, v9
	and.16b	v16, v0, v18
	fcmge.4s	v18, v16, v25
	fcmge.4s	v19, v7, v16
	and.16b	v18, v18, v19
	and.16b	v18, v18, v16
	ldr	q9, [sp, #2400]                 ; 16-byte Reload
	fmul.4s	v19, v18, v9
	mvni.4s	v22, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v20, v22
	bsl.16b	v20, v23, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v27
	fmul.4s	v20, v17, v9
	bsl.16b	v22, v23, v20
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	fmul.4s	v22, v19, v30
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v30
	fsub.4s	v17, v17, v23
	ldr	q2, [sp, #2368]                 ; 16-byte Reload
	fmul.4s	v22, v22, v2
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v2
	fsub.4s	v18, v18, v19
	ldr	q2, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v19, v18, v2
	mov.16b	v30, v29
	fadd.4s	v19, v19, v29
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v31
	fmul.4s	v19, v18, v19
	movi.4s	v23, #63, lsl #24
	fadd.4s	v19, v19, v23
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v2
	fadd.4s	v22, v22, v29
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v21
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	fcmgt.4s	v19, v25, v27
	bic.16b	v17, v17, v19
	str	q16, [sp, #720]                 ; 16-byte Spill
	fcmgt.4s	v19, v25, v16
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v16, v7
	ldr	q20, [sp, #2384]                ; 16-byte Reload
	mov.16b	v16, v19
	bsl.16b	v16, v20, v18
	str	q16, [sp, #736]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v7
	mov.16b	v16, v18
	bsl.16b	v16, v20, v17
	stp	q27, q16, [sp, #624]            ; 32-byte Folded Spill
	ldp	q19, q16, [sp, #816]            ; 32-byte Folded Reload
	ldr	q29, [sp, #2304]                ; 16-byte Reload
	fsub.4s	v17, v19, v29
	and.16b	v27, v1, v17
	fcmge.4s	v17, v27, v25
	fcmge.4s	v18, v7, v27
	and.16b	v17, v17, v18
	fsub.4s	v18, v16, v26
	and.16b	v26, v0, v18
	fcmge.4s	v18, v26, v25
	fcmge.4s	v19, v7, v26
	and.16b	v18, v18, v19
	and.16b	v18, v18, v26
	fmul.4s	v19, v18, v9
	movi.4s	v16, #75, lsl #24
	mvni.4s	v22, #128, lsl #24
	mov.16b	v20, v22
	bsl.16b	v20, v16, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v27
	fmul.4s	v20, v17, v9
	bsl.16b	v22, v16, v20
	mvni.4s	v9, #128, lsl #24
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q16, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v22, v19, v16
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v16
	fsub.4s	v17, v17, v23
	ldr	q16, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v22, v22, v16
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v16
	fsub.4s	v18, v18, v19
	fmul.4s	v19, v18, v2
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v18, v19
	mov.16b	v23, v31
	fadd.4s	v19, v19, v31
	fmul.4s	v19, v18, v19
	movi.4s	v16, #63, lsl #24
	fadd.4s	v19, v19, v16
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v2
	fadd.4s	v22, v22, v30
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v21
	mov.16b	v31, v21
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	fcmgt.4s	v19, v25, v27
	bic.16b	v17, v17, v19
	fcmgt.4s	v19, v25, v26
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v26, v7
	ldr	q20, [sp, #2384]                ; 16-byte Reload
	mov.16b	v16, v19
	bsl.16b	v16, v20, v18
	stp	q26, q16, [sp, #816]            ; 32-byte Folded Spill
	fcmgt.4s	v18, v27, v7
	mov.16b	v16, v18
	bsl.16b	v16, v20, v17
	stp	q27, q16, [sp, #592]            ; 32-byte Folded Spill
	ldp	q19, q16, [sp, #912]            ; 32-byte Folded Reload
	mov.16b	v27, v29
	fsub.4s	v17, v19, v29
	and.16b	v26, v1, v17
	fcmge.4s	v17, v26, v25
	fcmge.4s	v18, v7, v26
	and.16b	v17, v17, v18
	ldr	q29, [sp, #2272]                ; 16-byte Reload
	fsub.4s	v18, v16, v29
	and.16b	v16, v0, v18
	fcmge.4s	v18, v16, v25
	fcmge.4s	v19, v7, v16
	and.16b	v18, v18, v19
	and.16b	v18, v18, v16
	ldr	q21, [sp, #2400]                ; 16-byte Reload
	fmul.4s	v19, v18, v21
	movi.4s	v22, #75, lsl #24
	mov.16b	v20, v9
	bsl.16b	v20, v22, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v26
	fmul.4s	v20, v17, v21
	bif.16b	v22, v20, v9
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q21, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v22, v19, v21
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v21
	fsub.4s	v17, v17, v23
	ldr	q21, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v22, v22, v21
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v21
	fsub.4s	v18, v18, v19
	fmul.4s	v19, v18, v2
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v18, v19
	mov.16b	v23, v12
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v31
	fmul.4s	v19, v18, v19
	ldr	q21, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v18, v19
	movi.4s	v9, #63, lsl #24
	fadd.4s	v19, v19, v9
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v2
	fadd.4s	v22, v22, v30
	mov.16b	v12, v30
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v21
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v9
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	fcmgt.4s	v19, v25, v26
	bic.16b	v17, v17, v19
	str	q16, [sp, #912]                 ; 16-byte Spill
	fcmgt.4s	v19, v25, v16
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v16, v7
	ldr	q16, [sp, #2384]                ; 16-byte Reload
	bit.16b	v18, v16, v19
	str	q18, [sp, #928]                 ; 16-byte Spill
	fcmgt.4s	v18, v26, v7
	bit.16b	v17, v16, v18
	stp	q26, q17, [sp, #560]            ; 32-byte Folded Spill
	ldp	q19, q16, [sp, #1008]           ; 32-byte Folded Reload
	fsub.4s	v17, v19, v27
	mov.16b	v9, v27
	and.16b	v26, v1, v17
	fcmge.4s	v17, v26, v25
	fcmge.4s	v18, v7, v26
	and.16b	v17, v17, v18
	mov.16b	v30, v29
	fsub.4s	v18, v16, v29
	and.16b	v29, v0, v18
	fcmge.4s	v18, v29, v25
	fcmge.4s	v19, v7, v29
	and.16b	v18, v18, v19
	and.16b	v18, v18, v29
	ldr	q21, [sp, #2400]                ; 16-byte Reload
	fmul.4s	v19, v18, v21
	movi.4s	v16, #75, lsl #24
	mvni.4s	v22, #128, lsl #24
	mov.16b	v20, v22
	bsl.16b	v20, v16, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v26
	fmul.4s	v20, v17, v21
	bsl.16b	v22, v16, v20
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q16, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v22, v19, v16
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v16
	fsub.4s	v17, v17, v23
	ldr	q16, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v22, v22, v16
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v16
	fsub.4s	v18, v18, v19
	fmul.4s	v19, v18, v2
	mov.16b	v23, v12
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	ldr	q27, [sp, #2288]                ; 16-byte Reload
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v31
	fmul.4s	v19, v18, v19
	ldr	q12, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	movi.4s	v16, #63, lsl #24
	fadd.4s	v19, v19, v16
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v2
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v27
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	fcmgt.4s	v19, v25, v26
	bic.16b	v17, v17, v19
	fcmgt.4s	v19, v25, v29
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v29, v7
	ldr	q20, [sp, #2384]                ; 16-byte Reload
	mov.16b	v16, v19
	bsl.16b	v16, v20, v18
	stp	q29, q16, [sp, #1008]           ; 32-byte Folded Spill
	fcmgt.4s	v18, v26, v7
	mov.16b	v16, v18
	bsl.16b	v16, v20, v17
	stp	q26, q16, [sp, #528]            ; 32-byte Folded Spill
	ldr	q16, [sp, #1104]                ; 16-byte Reload
	fsub.4s	v17, v16, v30
	mov.16b	v31, v30
	and.16b	v26, v0, v17
	fcmge.4s	v17, v26, v25
	fcmge.4s	v18, v7, v26
	and.16b	v17, v17, v18
	ldr	q16, [sp, #1120]                ; 16-byte Reload
	mov.16b	v21, v9
	fsub.4s	v18, v16, v9
	and.16b	v27, v1, v18
	fcmge.4s	v18, v27, v25
	fcmge.4s	v19, v7, v27
	and.16b	v18, v18, v19
	and.16b	v18, v18, v27
	ldr	q16, [sp, #2400]                ; 16-byte Reload
	fmul.4s	v19, v18, v16
	mvni.4s	v22, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v20, v22
	bsl.16b	v20, v23, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v26
	fmul.4s	v20, v17, v16
	bsl.16b	v22, v23, v20
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q16, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v22, v19, v16
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v16
	fsub.4s	v17, v17, v23
	ldr	q16, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v22, v22, v16
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v16
	fsub.4s	v18, v18, v19
	fmul.4s	v19, v18, v2
	ldr	q29, [sp, #2208]                ; 16-byte Reload
	fadd.4s	v19, v19, v29
	fmul.4s	v19, v18, v19
	ldr	q30, [sp, #2288]                ; 16-byte Reload
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v18, v19
	ldr	q23, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	movi.4s	v9, #63, lsl #24
	fadd.4s	v19, v19, v9
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v2
	fadd.4s	v22, v22, v29
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v9
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	fcmgt.4s	v19, v25, v26
	bic.16b	v17, v17, v19
	str	q27, [sp, #1104]                ; 16-byte Spill
	fcmgt.4s	v19, v25, v27
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v27, v7
	ldr	q20, [sp, #2384]                ; 16-byte Reload
	mov.16b	v16, v19
	bsl.16b	v16, v20, v18
	str	q16, [sp, #1120]                ; 16-byte Spill
	fcmgt.4s	v18, v26, v7
	mov.16b	v16, v18
	bsl.16b	v16, v20, v17
	stp	q26, q16, [sp, #480]            ; 32-byte Folded Spill
	ldr	q16, [sp, #1200]                ; 16-byte Reload
	fsub.4s	v17, v16, v21
	and.16b	v21, v1, v17
	fcmge.4s	v17, v21, v25
	fcmge.4s	v18, v7, v21
	and.16b	v17, v17, v18
	ldr	q16, [sp, #1216]                ; 16-byte Reload
	mov.16b	v30, v31
	fsub.4s	v18, v16, v31
	and.16b	v29, v0, v18
	fcmge.4s	v18, v29, v25
	fcmge.4s	v19, v7, v29
	and.16b	v18, v18, v19
	and.16b	v18, v18, v29
	ldr	q23, [sp, #2400]                ; 16-byte Reload
	fmul.4s	v19, v18, v23
	movi.4s	v16, #75, lsl #24
	mvni.4s	v22, #128, lsl #24
	mov.16b	v20, v22
	bsl.16b	v20, v16, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v21
	fmul.4s	v20, v17, v23
	bsl.16b	v22, v16, v20
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q16, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v22, v19, v16
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v16
	fsub.4s	v17, v17, v23
	ldr	q16, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v22, v22, v16
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v16
	fsub.4s	v18, v18, v19
	fmul.4s	v19, v18, v2
	ldr	q31, [sp, #2208]                ; 16-byte Reload
	fadd.4s	v19, v19, v31
	fmul.4s	v19, v18, v19
	ldr	q27, [sp, #2288]                ; 16-byte Reload
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v18, v19
	ldr	q26, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	movi.4s	v23, #63, lsl #24
	fadd.4s	v19, v19, v23
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v2
	fadd.4s	v22, v22, v31
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v27
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v26
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	fcmgt.4s	v19, v25, v21
	bic.16b	v17, v17, v19
	str	q29, [sp, #1200]                ; 16-byte Spill
	fcmgt.4s	v19, v25, v29
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v29, v7
	ldr	q20, [sp, #2384]                ; 16-byte Reload
	mov.16b	v16, v19
	bsl.16b	v16, v20, v18
	str	q16, [sp, #1216]                ; 16-byte Spill
	fcmgt.4s	v18, v21, v7
	mov.16b	v16, v18
	bsl.16b	v16, v20, v17
	stp	q21, q16, [sp, #448]            ; 32-byte Folded Spill
	ldr	q16, [sp, #1296]                ; 16-byte Reload
	ldr	q21, [sp, #2304]                ; 16-byte Reload
	fsub.4s	v17, v16, v21
	and.16b	v26, v1, v17
	fcmge.4s	v17, v26, v25
	fcmge.4s	v18, v7, v26
	and.16b	v17, v17, v18
	ldr	q16, [sp, #1312]                ; 16-byte Reload
	fsub.4s	v18, v16, v30
	and.16b	v27, v0, v18
	fcmge.4s	v18, v27, v25
	fcmge.4s	v19, v7, v27
	and.16b	v18, v18, v19
	and.16b	v18, v18, v27
	ldr	q23, [sp, #2400]                ; 16-byte Reload
	fmul.4s	v19, v18, v23
	mvni.4s	v16, #128, lsl #24
	movi.4s	v22, #75, lsl #24
	mov.16b	v20, v16
	bsl.16b	v20, v22, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v26
	fmul.4s	v20, v17, v23
	bif.16b	v22, v20, v16
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v24, v19
	scvtf.4s	v19, v24
	ldr	q16, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v22, v19, v16
	fsub.4s	v18, v18, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v16
	fsub.4s	v17, v17, v23
	ldr	q16, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v22, v22, v16
	fsub.4s	v17, v17, v22
	fmul.4s	v19, v19, v16
	fsub.4s	v18, v18, v19
	fmul.4s	v19, v18, v2
	fadd.4s	v19, v19, v31
	fmul.4s	v19, v18, v19
	ldr	q29, [sp, #2288]                ; 16-byte Reload
	fadd.4s	v19, v19, v29
	fmul.4s	v19, v18, v19
	ldr	q23, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v22, v18, v18
	fmul.4s	v19, v22, v19
	fmul.4s	v22, v17, v2
	fadd.4s	v22, v22, v31
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v29
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v22, v17, v22
	fadd.4s	v22, v22, v9
	fmul.4s	v23, v17, v17
	fmul.4s	v22, v23, v22
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v13
	sshr.4s	v19, v20, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v13
	fmul.4s	v17, v17, v22
	fadd.4s	v18, v18, v13
	sshr.4s	v22, v24, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v18, v18, v23
	sub.4s	v19, v20, v19
	sub.4s	v20, v24, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v18, v18, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	mov.16b	v20, v26
	str	q26, [sp, #416]                 ; 16-byte Spill
	fcmgt.4s	v19, v25, v26
	bic.16b	v17, v17, v19
	str	q27, [sp, #1296]                ; 16-byte Spill
	fcmgt.4s	v19, v25, v27
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v27, v7
	ldr	q26, [sp, #2384]                ; 16-byte Reload
	bit.16b	v18, v26, v19
	str	q18, [sp, #1312]                ; 16-byte Spill
	fcmgt.4s	v18, v20, v7
	bit.16b	v17, v26, v18
	str	q17, [sp, #432]                 ; 16-byte Spill
	ldr	q17, [sp, #2176]                ; 16-byte Reload
	fsub.4s	v17, v17, v21
	and.16b	v21, v1, v17
	fcmge.4s	v17, v21, v25
	fcmge.4s	v18, v7, v21
	and.16b	v17, v17, v18
	ldr	q18, [sp, #2192]                ; 16-byte Reload
	ldr	q19, [sp, #2272]                ; 16-byte Reload
	fsub.4s	v18, v18, v19
	and.16b	v27, v0, v18
	fcmge.4s	v18, v27, v25
	fcmge.4s	v19, v7, v27
	and.16b	v18, v18, v19
	and.16b	v18, v18, v27
	ldr	q24, [sp, #2400]                ; 16-byte Reload
	fmul.4s	v19, v18, v24
	movi.4s	v22, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	mov.16b	v20, v23
	bsl.16b	v20, v22, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v21
	fmul.4s	v20, v17, v24
	bif.16b	v22, v20, v23
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v19, v19
	scvtf.4s	v22, v19
	ldr	q24, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v23, v22, v24
	fsub.4s	v18, v18, v23
	fcvtzs.4s	v20, v20
	scvtf.4s	v23, v20
	fmul.4s	v24, v23, v24
	fsub.4s	v17, v17, v24
	fmul.4s	v22, v22, v16
	fmul.4s	v23, v23, v16
	fsub.4s	v17, v17, v23
	fsub.4s	v18, v18, v22
	fmul.4s	v22, v18, v2
	fmul.4s	v23, v17, v2
	fadd.4s	v23, v23, v31
	fadd.4s	v22, v22, v31
	fmul.4s	v22, v18, v22
	fmul.4s	v23, v17, v23
	fadd.4s	v23, v23, v29
	fadd.4s	v22, v22, v29
	fmul.4s	v22, v18, v22
	fmul.4s	v23, v17, v23
	ldr	q16, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v23, v23, v16
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v18, v22
	fmul.4s	v23, v17, v23
	fadd.4s	v23, v23, v12
	fadd.4s	v22, v22, v12
	fmul.4s	v22, v18, v22
	movi.4s	v16, #63, lsl #24
	fadd.4s	v22, v22, v16
	fmul.4s	v24, v18, v18
	fmul.4s	v22, v24, v22
	fmul.4s	v23, v17, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v24, v17, v17
	fmul.4s	v23, v24, v23
	fadd.4s	v17, v17, v23
	fadd.4s	v18, v18, v22
	fadd.4s	v17, v17, v13
	sshr.4s	v22, v20, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v17, v17, v23
	fadd.4s	v18, v18, v13
	sshr.4s	v23, v19, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v18, v18, v24
	sub.4s	v20, v20, v22
	sub.4s	v19, v19, v23
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v18, v18, v19
	shl.4s	v19, v20, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	fcmgt.4s	v19, v25, v21
	bic.16b	v17, v17, v19
	fcmgt.4s	v19, v25, v27
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v27, v7
	mov.16b	v16, v19
	bsl.16b	v16, v26, v18
	stp	q27, q16, [sp, #384]            ; 32-byte Folded Spill
	fcmgt.4s	v18, v21, v7
	mov.16b	v7, v18
	bsl.16b	v7, v26, v17
	stp	q21, q7, [sp, #352]             ; 32-byte Folded Spill
	ldr	q7, [sp, #1376]                 ; 16-byte Reload
	fcmeq.4s	v17, v7, v7
	ldr	q7, [sp, #224]                  ; 16-byte Reload
	ldr	q16, [sp, #1392]                ; 16-byte Reload
	mov.16b	v12, v17
	bsl.16b	v12, v16, v7
	ldr	q16, [sp, #1424]                ; 16-byte Reload
	fcmeq.4s	v17, v16, v16
	ldr	q16, [sp, #1408]                ; 16-byte Reload
	mov.16b	v9, v17
	bsl.16b	v9, v16, v7
	ldr	q16, [sp, #1328]                ; 16-byte Reload
	fcmeq.4s	v17, v16, v16
	ldr	q16, [sp, #1344]                ; 16-byte Reload
	mov.16b	v2, v17
	bsl.16b	v2, v16, v7
	str	q2, [sp, #2416]                 ; 16-byte Spill
	ldr	q16, [sp, #1760]                ; 16-byte Reload
	fcmeq.4s	v17, v16, v16
	ldr	q16, [sp, #1360]                ; 16-byte Reload
	mov.16b	v2, v17
	bsl.16b	v2, v16, v7
	str	q2, [sp, #2400]                 ; 16-byte Spill
	ldr	q16, [sp, #1232]                ; 16-byte Reload
	fcmeq.4s	v17, v16, v16
	ldr	q16, [sp, #1248]                ; 16-byte Reload
	mov.16b	v2, v17
	bsl.16b	v2, v16, v7
	str	q2, [sp, #2384]                 ; 16-byte Spill
	ldr	q16, [sp, #1264]                ; 16-byte Reload
	fcmeq.4s	v17, v16, v16
	ldr	q16, [sp, #1280]                ; 16-byte Reload
	mov.16b	v2, v17
	bsl.16b	v2, v16, v7
	str	q2, [sp, #2368]                 ; 16-byte Spill
	ldr	q16, [sp, #1136]                ; 16-byte Reload
	fcmeq.4s	v17, v16, v16
	ldr	q16, [sp, #1152]                ; 16-byte Reload
	mov.16b	v2, v17
	bsl.16b	v2, v16, v7
	str	q2, [sp, #2336]                 ; 16-byte Spill
	ldr	q16, [sp, #1168]                ; 16-byte Reload
	fcmeq.4s	v17, v16, v16
	ldr	q16, [sp, #1184]                ; 16-byte Reload
	mov.16b	v2, v17
	bsl.16b	v2, v16, v7
	str	q2, [sp, #2320]                 ; 16-byte Spill
	ldr	q16, [sp, #1040]                ; 16-byte Reload
	fcmeq.4s	v17, v16, v16
	ldr	q16, [sp, #1056]                ; 16-byte Reload
	mov.16b	v2, v17
	bsl.16b	v2, v16, v7
	str	q2, [sp, #2288]                 ; 16-byte Spill
	ldr	q16, [sp, #1072]                ; 16-byte Reload
	fcmeq.4s	v17, v16, v16
	ldr	q16, [sp, #1088]                ; 16-byte Reload
	mov.16b	v2, v17
	bsl.16b	v2, v16, v7
	str	q2, [sp, #2208]                 ; 16-byte Spill
	ldp	q2, q16, [sp, #944]             ; 32-byte Folded Reload
	fcmeq.4s	v17, v2, v2
	bsl.16b	v17, v16, v7
	ldp	q19, q16, [sp, #976]            ; 32-byte Folded Reload
	fcmeq.4s	v18, v19, v19
	bsl.16b	v18, v16, v7
	ldp	q20, q16, [sp, #848]            ; 32-byte Folded Reload
	fcmeq.4s	v19, v20, v20
	bsl.16b	v19, v16, v7
	ldp	q22, q16, [sp, #880]            ; 32-byte Folded Reload
	fcmeq.4s	v20, v22, v22
	bsl.16b	v20, v16, v7
	ldp	q23, q16, [sp, #752]            ; 32-byte Folded Reload
	fcmeq.4s	v22, v23, v23
	mov.16b	v25, v22
	bsl.16b	v25, v16, v7
	ldp	q22, q16, [sp, #784]            ; 32-byte Folded Reload
	fcmeq.4s	v23, v22, v22
	bsl.16b	v23, v16, v7
	ldp	q26, q16, [sp, #672]            ; 32-byte Folded Reload
	fcmeq.4s	v24, v26, v26
	mov.16b	v27, v24
	bsl.16b	v27, v16, v7
	ldr	q16, [sp, #656]                 ; 16-byte Reload
	fcmeq.4s	v24, v16, v16
	ldr	q16, [sp, #704]                 ; 16-byte Reload
	mov.16b	v30, v24
	bsl.16b	v30, v16, v7
	ldp	q31, q16, [sp, #624]            ; 32-byte Folded Reload
	fcmeq.4s	v24, v31, v31
	mov.16b	v2, v24
	bsl.16b	v2, v16, v7
	str	q2, [sp, #2160]                 ; 16-byte Spill
	ldp	q2, q16, [sp, #720]             ; 32-byte Folded Reload
	fcmeq.4s	v24, v2, v2
	bsl.16b	v24, v16, v7
	ldr	q16, [sp, #592]                 ; 16-byte Reload
	fcmeq.4s	v26, v16, v16
	ldr	q16, [sp, #608]                 ; 16-byte Reload
	mov.16b	v2, v26
	bsl.16b	v2, v16, v7
	str	q2, [sp, #1344]                 ; 16-byte Spill
	ldp	q2, q16, [sp, #816]             ; 32-byte Folded Reload
	fcmeq.4s	v26, v2, v2
	mov.16b	v13, v26
	bsl.16b	v13, v16, v7
	ldp	q26, q16, [sp, #560]            ; 32-byte Folded Reload
	fcmeq.4s	v31, v26, v26
	mov.16b	v2, v31
	bsl.16b	v2, v16, v7
	str	q2, [sp, #1408]                 ; 16-byte Spill
	ldp	q2, q16, [sp, #912]             ; 32-byte Folded Reload
	fcmeq.4s	v31, v2, v2
	mov.16b	v2, v31
	bsl.16b	v2, v16, v7
	str	q2, [sp, #1376]                 ; 16-byte Spill
	ldp	q2, q16, [sp, #528]             ; 32-byte Folded Reload
	fcmeq.4s	v31, v2, v2
	mov.16b	v2, v31
	bsl.16b	v2, v16, v7
	str	q2, [sp, #1392]                 ; 16-byte Spill
	ldp	q2, q16, [sp, #1008]            ; 32-byte Folded Reload
	fcmeq.4s	v31, v2, v2
	mov.16b	v2, v31
	bsl.16b	v2, v16, v7
	str	q2, [sp, #1424]                 ; 16-byte Spill
	ldp	q2, q16, [sp, #480]             ; 32-byte Folded Reload
	fcmeq.4s	v31, v2, v2
	mov.16b	v2, v31
	bsl.16b	v2, v16, v7
	str	q2, [sp, #1328]                 ; 16-byte Spill
	ldr	q16, [sp, #1104]                ; 16-byte Reload
	fcmeq.4s	v31, v16, v16
	ldr	q16, [sp, #1120]                ; 16-byte Reload
	mov.16b	v2, v31
	bsl.16b	v2, v16, v7
	str	q2, [sp, #1360]                 ; 16-byte Spill
	ldp	q2, q16, [sp, #448]             ; 32-byte Folded Reload
	fcmeq.4s	v31, v2, v2
	mov.16b	v2, v31
	bsl.16b	v2, v16, v7
	str	q2, [sp, #1232]                 ; 16-byte Spill
	ldr	q16, [sp, #1200]                ; 16-byte Reload
	fcmeq.4s	v31, v16, v16
	ldr	q16, [sp, #1216]                ; 16-byte Reload
	mov.16b	v2, v31
	bsl.16b	v2, v16, v7
	str	q2, [sp, #1264]                 ; 16-byte Spill
	ldp	q2, q16, [sp, #416]             ; 32-byte Folded Reload
	fcmeq.4s	v31, v2, v2
	mov.16b	v2, v31
	bsl.16b	v2, v16, v7
	str	q2, [sp, #1168]                 ; 16-byte Spill
	ldr	q16, [sp, #1296]                ; 16-byte Reload
	fcmeq.4s	v31, v16, v16
	ldr	q16, [sp, #1312]                ; 16-byte Reload
	bif.16b	v16, v7, v31
	str	q16, [sp, #1200]                ; 16-byte Spill
	ldr	d16, [sp, #1440]                ; 8-byte Reload
	zip1.8b	v31, v16, v0
	ushll.4s	v31, v31, #0
	shl.4s	v31, v31, #31
	cmlt.4s	v31, v31, #0
	and.16b	v31, v31, v18
	zip2.8b	v18, v16, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	and.16b	v21, v18, v17
	zip1.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v26, v17, v20
	zip2.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v22, v17, v19
	zip1.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v29, v17, v23
	zip2.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v23, v17, v25
	zip1.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v2, v17, v30
	zip2.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v25, v17, v27
	zip2.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v24, v17, v24
	zip1.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #2160]                ; 16-byte Reload
	and.16b	v20, v17, v18
	zip2.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v13, v17, v13
	ldp	x4, x5, [sp, #144]              ; 16-byte Folded Reload
	ldp	q18, q17, [x5]
	str	q9, [sp, #1760]                 ; 16-byte Spill
	bit.16b	v17, v9, v0
	str	q12, [sp, #2160]                ; 16-byte Spill
	bit.16b	v18, v12, v1
	stp	q18, q17, [x5]
	zip1.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #1344]                ; 16-byte Reload
	and.16b	v27, v17, v18
	ldr	q17, [x4, #16]
	ldr	q18, [sp, #2400]                ; 16-byte Reload
	bit.16b	v17, v18, v0
	ldr	q18, [x4]
	ldr	q19, [sp, #2416]                ; 16-byte Reload
	bit.16b	v18, v19, v1
	stp	q18, q17, [x4]
	zip2.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #1376]                ; 16-byte Reload
	and.16b	v30, v17, v18
	ldp	x4, x6, [sp, #128]              ; 16-byte Folded Reload
	ldr	q17, [x6, #16]
	ldr	q18, [sp, #2368]                ; 16-byte Reload
	bit.16b	v17, v18, v0
	ldr	q18, [x6]
	ldr	q19, [sp, #2384]                ; 16-byte Reload
	bit.16b	v18, v19, v1
	stp	q18, q17, [x6]
	zip1.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #1408]                ; 16-byte Reload
	and.16b	v12, v17, v18
	ldr	q17, [x4, #16]
	ldr	q18, [sp, #2320]                ; 16-byte Reload
	bit.16b	v17, v18, v0
	ldr	q18, [x4]
	ldr	q19, [sp, #2336]                ; 16-byte Reload
	bit.16b	v18, v19, v1
	stp	q18, q17, [x4]
	ldp	x4, x7, [sp, #112]              ; 16-byte Folded Reload
	ldr	q17, [x7, #16]
	ldr	q18, [sp, #2208]                ; 16-byte Reload
	bit.16b	v17, v18, v0
	ldr	q18, [x7]
	ldr	q19, [sp, #2288]                ; 16-byte Reload
	bit.16b	v18, v19, v1
	stp	q18, q17, [x7]
	zip2.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #1424]                ; 16-byte Reload
	and.16b	v19, v17, v18
	ldp	q18, q17, [x4]
	str	q21, [sp, #1408]                ; 16-byte Spill
	bit.16b	v17, v21, v0
	str	q31, [sp, #1424]                ; 16-byte Spill
	bit.16b	v18, v31, v1
	stp	q18, q17, [x4]
	zip1.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #1392]                ; 16-byte Reload
	and.16b	v21, v17, v18
	ldr	x4, [sp, #104]                  ; 8-byte Reload
	ldp	q18, q17, [x4]
	str	q22, [sp, #1376]                ; 16-byte Spill
	bit.16b	v17, v22, v0
	str	q26, [sp, #1392]                ; 16-byte Spill
	bit.16b	v18, v26, v1
	stp	q18, q17, [x4]
	zip1.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #1360]                ; 16-byte Reload
	and.16b	v22, v17, v18
	ldr	x4, [sp, #96]                   ; 8-byte Reload
	ldp	q18, q17, [x4]
	str	q23, [sp, #1344]                ; 16-byte Spill
	bit.16b	v17, v23, v0
	str	q29, [sp, #1360]                ; 16-byte Spill
	bit.16b	v18, v29, v1
	stp	q18, q17, [x4]
	zip2.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #1328]                ; 16-byte Reload
	and.16b	v23, v17, v18
	ldp	q18, q17, [x20]
	str	q25, [sp, #1312]                ; 16-byte Spill
	bit.16b	v17, v25, v0
	str	q2, [sp, #1328]                 ; 16-byte Spill
	bit.16b	v18, v2, v1
	stp	q18, q17, [x20]
	ldp	q17, q18, [x21]
	str	q20, [sp, #1280]                ; 16-byte Spill
	bit.16b	v17, v20, v1
	str	q24, [sp, #1296]                ; 16-byte Spill
	bit.16b	v18, v24, v0
	stp	q17, q18, [x21]
	zip2.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #1264]                ; 16-byte Reload
	and.16b	v20, v17, v18
	ldp	q17, q18, [x22]
	str	q27, [sp, #1248]                ; 16-byte Spill
	bit.16b	v17, v27, v1
	str	q13, [sp, #1264]                ; 16-byte Spill
	bit.16b	v18, v13, v0
	stp	q17, q18, [x22]
	zip1.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #1232]                ; 16-byte Reload
	and.16b	v24, v17, v18
	ldp	q17, q18, [x23]
	str	q12, [sp, #1216]                ; 16-byte Spill
	bit.16b	v17, v12, v1
	str	q30, [sp, #1232]                ; 16-byte Spill
	bit.16b	v18, v30, v0
	stp	q17, q18, [x23]
	zip2.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #1200]                ; 16-byte Reload
	and.16b	v25, v17, v18
	ldp	q17, q18, [x24]
	str	q21, [sp, #1184]                ; 16-byte Spill
	bit.16b	v17, v21, v1
	str	q19, [sp, #1200]                ; 16-byte Spill
	bit.16b	v18, v19, v0
	stp	q17, q18, [x24]
	zip1.8b	v17, v16, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q2, [sp, #1168]                 ; 16-byte Reload
	and.16b	v16, v17, v2
	ldp	q18, q17, [x25]
	str	q23, [sp, #1168]                ; 16-byte Spill
	bit.16b	v17, v23, v0
	str	q22, [sp, #1440]                ; 16-byte Spill
	bit.16b	v18, v22, v1
	stp	q18, q17, [x25]
	ldp	q17, q18, [x26]
	str	q24, [sp, #1136]                ; 16-byte Spill
	bit.16b	v17, v24, v1
	str	q20, [sp, #1152]                ; 16-byte Spill
	bit.16b	v18, v20, v0
	stp	q17, q18, [x26]
	ldp	q17, q18, [x27]
	str	q16, [sp, #1104]                ; 16-byte Spill
	bit.16b	v17, v16, v1
	str	q25, [sp, #1120]                ; 16-byte Spill
	bit.16b	v18, v25, v0
	stp	q17, q18, [x27]
	ldp	q2, q16, [sp, #352]             ; 32-byte Folded Reload
	fcmeq.4s	v17, v2, v2
	mov.16b	v13, v17
	bsl.16b	v13, v16, v7
	ldp	q18, q16, [sp, #384]            ; 32-byte Folded Reload
	fcmeq.4s	v17, v18, v18
	mov.16b	v12, v17
	bsl.16b	v12, v16, v7
	sshll.2d	v17, v0, #0
	ldr	q7, [sp, #1696]                 ; 16-byte Reload
	ldr	q18, [sp, #1664]                ; 16-byte Reload
	bit.16b	v18, v7, v17
	str	q18, [sp, #1664]                ; 16-byte Spill
	sshll.2d	v17, v1, #0
	ldr	q7, [sp, #1744]                 ; 16-byte Reload
	ldr	q30, [sp, #2448]                ; 16-byte Reload
	bit.16b	v30, v7, v17
	ldr	x6, [sp, #312]                  ; 8-byte Reload
	ldr	q16, [sp, #1792]                ; 16-byte Reload
	ldr	q21, [sp, #512]                 ; 16-byte Reload
	str	q30, [sp, #2448]                ; 16-byte Spill
LBB0_95:                                ; %direct.true732
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_96 Depth 3
	mov	x5, #0                          ; =0x0
	lsl	x4, x3, #7
	dup.2d	v24, x4
	ldr	q7, [sp, #2464]                 ; 16-byte Reload
	orr.16b	v17, v24, v7
	fmov	x4, d17
	add	x4, x8, x4
	ldp	q18, q17, [x4]
	fmul.4s	v18, v13, v18
	fmul.4s	v17, v12, v17
	mov	w4, #32                         ; =0x20
	bfi	x4, x3, #7, #57
	dup.2d	v25, x4
	orr.16b	v19, v25, v7
	fmov	x4, d19
	add	x4, x8, x4
	ldp	q20, q19, [x4]
	fmul.4s	v20, v13, v20
	fmul.4s	v19, v12, v19
	mov	w4, #64                         ; =0x40
	bfi	x4, x3, #7, #57
	dup.2d	v26, x4
	orr.16b	v22, v26, v7
	fmov	x4, d22
	add	x4, x8, x4
	ldp	q23, q22, [x4]
	fmul.4s	v23, v13, v23
	fmul.4s	v22, v12, v22
	mov	w4, #96                         ; =0x60
	bfi	x4, x3, #7, #57
	dup.2d	v27, x4
	orr.16b	v29, v27, v7
	fmov	x4, d29
	add	x4, x8, x4
	ldp	q31, q29, [x4]
	fmul.4s	v31, v13, v31
	fmul.4s	v29, v12, v29
	bit.16b	v8, v17, v0
	bit.16b	v28, v18, v1
	bit.16b	v6, v19, v0
	bit.16b	v5, v20, v1
	bit.16b	v4, v22, v0
	bit.16b	v3, v23, v1
	bit.16b	v15, v29, v0
	bit.16b	v14, v31, v1
	mov	x4, x6
LBB0_96:                                ; %direct.true760
                                        ;   Parent Loop BB0_22 Depth=1
                                        ;     Parent Loop BB0_95 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x7, x15, x5
	ldp	q18, q17, [x7]
	and.16b	v20, v1, v18
	and.16b	v17, v0, v17
	ldp	q19, q18, [x4, #-96]
	and.16b	v19, v1, v19
	and.16b	v18, v0, v18
	fmul.4s	v18, v17, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v31, v28, v19
	fadd.4s	v19, v8, v18
	ldp	q22, q18, [x4, #-64]
	and.16b	v22, v1, v22
	and.16b	v18, v0, v18
	fmul.4s	v18, v17, v18
	fmul.4s	v22, v20, v22
	fadd.4s	v29, v5, v22
	fadd.4s	v23, v6, v18
	ldp	q22, q18, [x4, #-32]
	and.16b	v22, v1, v22
	and.16b	v18, v0, v18
	fmul.4s	v30, v17, v18
	fmul.4s	v18, v20, v22
	fadd.4s	v18, v3, v18
	fadd.4s	v22, v4, v30
	ldp	q7, q30, [x4]
	and.16b	v7, v1, v7
	and.16b	v30, v0, v30
	fmul.4s	v30, v17, v30
	fmul.4s	v7, v20, v7
	fadd.4s	v17, v14, v7
	fadd.4s	v20, v15, v30
	bit.16b	v8, v19, v0
	bit.16b	v28, v31, v1
	bit.16b	v6, v23, v0
	bit.16b	v5, v29, v1
	bit.16b	v4, v22, v0
	bit.16b	v3, v18, v1
	bit.16b	v15, v20, v0
	bit.16b	v14, v17, v1
	add	x5, x5, #32
	add	x4, x4, #3072
	cmp	x5, #512
	b.ne	LBB0_96
; %bb.97:                               ; %direct.false761
                                        ;   in Loop: Header=BB0_95 Depth=2
	ldr	q30, [sp, #2448]                ; 16-byte Reload
	orr.16b	v7, v24, v30
	fmov	x4, d7
	add	x4, x16, x4
	ldp	q7, q24, [x4]
	bif.16b	v19, v24, v0
	bit.16b	v7, v31, v1
	stp	q7, q19, [x4]
	orr.16b	v7, v25, v30
	fmov	x4, d7
	add	x4, x16, x4
	ldp	q7, q19, [x4]
	bit.16b	v19, v23, v0
	bit.16b	v7, v29, v1
	stp	q7, q19, [x4]
	orr.16b	v7, v26, v30
	fmov	x4, d7
	add	x4, x16, x4
	ldp	q7, q19, [x4]
	bit.16b	v19, v22, v0
	bit.16b	v7, v18, v1
	stp	q7, q19, [x4]
	orr.16b	v7, v27, v30
	fmov	x4, d7
	add	x4, x16, x4
	ldp	q7, q18, [x4]
	bit.16b	v18, v20, v0
	bit.16b	v7, v17, v1
	stp	q7, q18, [x4]
	add	x3, x3, #1
	add	x6, x6, #128
	cmp	x3, #24
	b.ne	LBB0_95
; %bb.98:                               ; %direct.true827.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x3, #0                          ; =0x0
	ldr	q20, [sp, #2464]                ; 16-byte Reload
LBB0_99:                                ; %direct.true827
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d7, x3
	orr.16b	v17, v7, v30
	fmov	x4, d17
	add	x4, x16, x4
	ldp	q17, q18, [x4]
	orr.16b	v7, v7, v20
	fmov	x4, d7
	add	x4, x11, x4
	ldp	q7, q19, [x4]
	bif.16b	v18, v19, v0
	bit.16b	v7, v17, v1
	stp	q7, q18, [x4]
	add	x3, x3, #32
	cmp	x3, #3072
	b.ne	LBB0_99
; %bb.100:                              ; %direct.true843.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x3, x10
	mov	w4, #96                         ; =0x60
	ldr	q20, [sp, #1504]                ; 16-byte Reload
	ldr	q22, [sp, #1488]                ; 16-byte Reload
	ldr	q23, [sp, #2256]                ; 16-byte Reload
	ldr	q29, [sp, #1904]                ; 16-byte Reload
	ldr	q24, [sp, #2240]                ; 16-byte Reload
	ldr	q27, [sp, #1888]                ; 16-byte Reload
	ldr	q25, [sp, #2224]                ; 16-byte Reload
	ldr	q26, [sp, #1872]                ; 16-byte Reload
	ldr	q31, [sp, #1840]                ; 16-byte Reload
	ldr	q2, [sp, #336]                  ; 16-byte Reload
	ldr	q9, [sp, #1776]                 ; 16-byte Reload
LBB0_101:                               ; %direct.true843
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q7, [x3, #5632]
	ldr	q17, [x3, #5648]
	ldr	q18, [x3, #2560]
	ldr	q19, [x3, #2576]
	bif.16b	v17, v19, v0
	bif.16b	v7, v18, v1
	str	q7, [x3, #2560]
	str	q17, [x3, #2576]
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_101
; %bb.102:                              ; %direct.false844
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q7, [sp, #2192]                 ; 16-byte Reload
	ldr	q17, [sp, #2272]                ; 16-byte Reload
	bit.16b	v7, v17, v0
	str	q7, [sp, #2192]                 ; 16-byte Spill
	ldr	q7, [sp, #2176]                 ; 16-byte Reload
	ldr	q17, [sp, #2304]                ; 16-byte Reload
	bit.16b	v7, v17, v1
	str	q7, [sp, #2176]                 ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	ldr	q7, [sp, #2160]                 ; 16-byte Reload
	fadd.4s	v7, v7, v17
	ldr	q18, [sp, #2416]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1760]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #2400]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #2368]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #2384]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #2208]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #2288]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1424]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1408]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #1376]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #1392]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1360]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1344]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #1312]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #1328]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1280]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1296]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #1264]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #1248]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1216]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1232]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #1200]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #1184]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1440]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1168]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #1152]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #1136]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1104]                ; 16-byte Reload
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #1120]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	fmul.4s	v18, v20, v13
	fmul.4s	v19, v22, v12
	fadd.4s	v17, v19, v17
	fadd.4s	v7, v18, v7
	bit.16b	v20, v7, v1
	bit.16b	v22, v17, v0
	add	x0, x0, #1
	cmp	x0, #129
	ldr	q30, [sp, #1856]                ; 16-byte Reload
	ldr	q7, [sp, #1824]                 ; 16-byte Reload
	ldr	q13, [sp, #1808]                ; 16-byte Reload
	b.ne	LBB0_22
; %bb.103:                              ; %direct.schedule.86.preheader
	mov	x9, #0                          ; =0x0
	ldp	q2, q4, [sp, #16]               ; 32-byte Folded Reload
	xtn.2s	v2, v2
	movi.2s	v5, #96
	umull.2d	v2, v2, v5
	ldp	q3, q6, [sp, #48]               ; 32-byte Folded Reload
	xtn.2s	v3, v3
	umull.2d	v3, v3, v5
	xtn.2s	v4, v4
	umull.2d	v4, v4, v5
	xtn.2s	v6, v6
	umull.2d	v5, v6, v5
	ldr	x12, [sp, #88]                  ; 8-byte Reload
	b	LBB0_105
LBB0_104:                               ; %else334
                                        ;   in Loop: Header=BB0_105 Depth=1
	add	x9, x9, #1
	cmp	x9, #96
	b.eq	LBB0_121
LBB0_105:                               ; %direct.true862
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q6, [sp, #2432]                 ; 16-byte Reload
	fmov	w10, s6
	dup.2d	v6, x9
	add.2d	v7, v6, v2
	add	x11, x8, x9, lsl #5
	ldp	q17, q16, [x11]
	and.16b	v17, v1, v17
	fdiv.4s	v17, v17, v20
	shl.2d	v18, v7, #2
	dup.2d	v7, x12
	add.2d	v18, v7, v18
	tbz	w10, #0, LBB0_113
; %bb.106:                              ; %cond.store
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x11, d18
	str	s17, [x11]
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_114
LBB0_107:                               ; %else316
                                        ;   in Loop: Header=BB0_105 Depth=1
	add.2d	v18, v6, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v7, v18
	tbz	w10, #2, LBB0_115
LBB0_108:                               ; %cond.store317
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x11, d18
	st1.s	{ v17 }[2], [x11]
	tbnz	w10, #3, LBB0_116
LBB0_109:                               ; %else322
                                        ;   in Loop: Header=BB0_105 Depth=1
	add.2d	v17, v6, v4
	and.16b	v16, v0, v16
	fdiv.4s	v16, v16, v22
	shl.2d	v17, v17, #2
	add.2d	v17, v7, v17
	tbz	w10, #4, LBB0_117
LBB0_110:                               ; %cond.store323
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x11, d17
	str	s16, [x11]
	tbnz	w10, #5, LBB0_118
LBB0_111:                               ; %else328
                                        ;   in Loop: Header=BB0_105 Depth=1
	add.2d	v6, v6, v5
	shl.2d	v6, v6, #2
	add.2d	v6, v7, v6
	tbz	w10, #6, LBB0_119
LBB0_112:                               ; %cond.store329
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x11, d6
	st1.s	{ v16 }[2], [x11]
	tbz	w10, #7, LBB0_104
	b	LBB0_120
LBB0_113:                               ; %else313
                                        ;   in Loop: Header=BB0_105 Depth=1
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_107
LBB0_114:                               ; %cond.store314
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x11, v18[1]
	st1.s	{ v17 }[1], [x11]
	add.2d	v18, v6, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v7, v18
	tbnz	w10, #2, LBB0_108
LBB0_115:                               ; %else319
                                        ;   in Loop: Header=BB0_105 Depth=1
	tbz	w10, #3, LBB0_109
LBB0_116:                               ; %cond.store320
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x11, v18[1]
	st1.s	{ v17 }[3], [x11]
	add.2d	v17, v6, v4
	and.16b	v16, v0, v16
	fdiv.4s	v16, v16, v22
	shl.2d	v17, v17, #2
	add.2d	v17, v7, v17
	tbnz	w10, #4, LBB0_110
LBB0_117:                               ; %else325
                                        ;   in Loop: Header=BB0_105 Depth=1
	tbz	w10, #5, LBB0_111
LBB0_118:                               ; %cond.store326
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x11, v17[1]
	st1.s	{ v16 }[1], [x11]
	add.2d	v6, v6, v5
	shl.2d	v6, v6, #2
	add.2d	v6, v7, v6
	tbnz	w10, #6, LBB0_112
LBB0_119:                               ; %else331
                                        ;   in Loop: Header=BB0_105 Depth=1
	tbz	w10, #7, LBB0_104
LBB0_120:                               ; %cond.store332
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x10, v6[1]
	st1.s	{ v16 }[3], [x10]
	b	LBB0_104
LBB0_121:
	add	sp, sp, #2784
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_122:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

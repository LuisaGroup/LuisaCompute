# Native MMA 候选：实际生成代码与配对结果复核

范围：审阅本目录冻结的 12 captures、6 份 replay `results.json`、`prepared-*/kernel.ll`、保存的符号检查输出和 prepared metadata。竞争 replay 结束且主任务明确许可后，补充了 MHA off/on 对象的只读符号、重定位和有界反汇编。未修改源码、重建、执行 native kernel、新增计时或 profile。这里不是对全部最终机器码或运行时 loader 的完整认证。

## 结论

typed MMA 确实到达实际 capture 的私有 LLVM 向量 helper，不是仅记录了开关，也不是调用外部 BLAS/runtime callback。但六组中五组变慢，本轮不能默认启用。`batch-gqa-q4` 有稳定改善；其余负结果均保留。存储、向量方向、局部循环结构、重结合顺序和部分 full-packet 准入一起变化，不能把结果归因于单一因素。

## 代码证据

- 每个 `on/kernel.ll` 都有且仅有两个 `define private void @llm_attention.strided_mma...`。第一个是 QK：输出循环逐 score，沿 D 读取 `<4 x float>`，首批真实乘积初始化向量，再作向量 MUL/ADD 和显式水平加法树。不是用额外 `+0` 初始化，符合仅允许重结合、不允许忽略 signed zero 的约束。
- 第二个是 PV：沿 Dv 输出分组四列，P 标量广播，V 四个连续元素加载；累加器从 seed 四元素加载，按 KV tile 的 16 个贡献依次 MUL→ADD，最后连续写四元素。各输出 K 顺序不变。
- 每个 QK helper 静态有 2 处 `<4 x float>` FMul、1 处 FAdd；每个 PV helper 有 1 处 FMul、1 处 FAdd。所有 helper 均无 `fast/reassoc/contract/nsz/nnan/ninf/afn/arcp` 数值标志；属性是 `nounwind willreturn "fp-contract"="off"`，没有 `alwaysinline`。模块中另一个带 `alwaysinline` 的 native-math helper 属于已有数学函数，不应误算为 MMA 强制内联。
- 六个 on 模块均没有间接 `call`、`llvm.fma` 或 `llvm.fmuladd`。保存的 actual object `imports.stdout` 与 `prepared.json.imports` 一致：MHA、prefill-q4、batch-GQA 为空；GQA-D80、long-KV、prefill-q8 仅 `_bzero`、`_memcpy`。因此准确表述是“没有新增 MMA/runtime callback/BLAS import”，不是“所有对象完全零 import”。所有 exports 只有对应 native packet batch entry。
- prepared manifest 记录的 `kernel.o` hash 与原 capture `.o` hash 六组一致；link command 输入是该 `.o`，不是重新从 `.ll` 编译。本次只比较记录的身份，没有重新 hash 全部文件，也不把它当作 live loader attestation。
- 调用端按 active mask 逐 program lane 分支，提取 `{<8 x ptr>, <8 x i64>}` 的同一 lane base/offset，形成四个实际指针调用私有 helper；seed 和 output 是不同快照句柄。MHA 例见 `prepared-decode-mha-d64-on/kernel.ll:3790` 附近的 `mma.active` 与 `mma.continue`。这不是跨八个 program 的贡献维 collective。
- global `interleaved_private_arrays` 的非零计数来自其余数组，不能推出 MMA 参数交错。MHA 的 MMA 参数具有完整每-lane 数组跨度，如 Q 256 字节、K 4096 字节、QK seed/output 64 字节；符合完整本地快照的调用约束。
- 所有本轮 D/Dv 都是四的倍数；这六组 capture 不独立覆盖 helper 的 D/Dv 向量尾部或 K=0。ragged KV/query 的输入 masking 存在，但不能替代上述 helper 边界测试；相关数值覆盖来自主任务另行完成的 CTests。

QK / PV 的实际静态循环边界：

| case | QK 输出数 | QK 首批后向量迭代 | PV 行 × 四列组 × K |
|---|---:|---:|---:|
| decode-mha-d64 | 16 | 15 | 1 × 16 × 16 |
| decode-gqa-d80 | 16 | 19 | 1 × 24 × 16 |
| decode-long-kv | 16 | 31 | 1 × 32 × 16 |
| prefill-q4 | 64 | 7 | 4 × 8 × 16 |
| prefill-q8 | 128 | 7 | 8 × 12 × 16 |
| batch-gqa-q4 | 64 | 9 | 4 × 12 × 16 |

## 配对数值复核

指标为 `single_thread_native_entry_host_wall_us`，不是多线程 Luisa dispatch 总时间，也不是 Torch/MPS 端到端比较。每组 3 cycles × ABBA = 12 visits、每 visit 7 samples；本次从全部 504 个 samples 重算 visit 中位数与 36 个配对比，和保存的 summary 一致。两对分别为每 cycle 的 position1/0、position2/3。

所有 72 visits 的记录均 `valid=true`、returncode=0、guards passed、inputs unchanged；这里验证记录和统计，未再次独立计算 FP64 oracle 或逐文件读取输出浮点数。

| case | off 中位数 µs | on 中位数 µs | 六对 on/off 中位数 | 六对范围 |
|---|---:|---:|---:|---:|
| decode-mha-d64 | 1034.232 | 1593.974 | 1.523590 | 1.457029–1.592998 |
| decode-gqa-d80 | 1920.786 | 2789.068 | 1.451535 | 1.427266–1.472129 |
| decode-long-kv | 15214.875 | 24403.062 | 1.603683 | 1.576182–1.606891 |
| prefill-q4 | 123.800 | 176.118 | 1.421003 | 1.406352–1.435925 |
| prefill-q8 | 461.137 | 489.758 | 1.061930 | 1.042598–1.084038 |
| batch-gqa-q4 | 3194.094 | 2368.216 | 0.741710 | 0.740832–0.747243 |

off/on 中位数列是各 variant 六次 visit 中位数的中位数，配对比列不是这两列直接相除；比值大于 1 表示回退。

## 资源与不能忽略的共同变化

所有组 root order 与 blocks_per_task 在 off/on 间一致。前 3 组 root order `[0,2,1]`，后 3 组 `[0,1,2]`，blocks_per_task 都为 0。

| case | snapshot 字节/worker off→on | 分配数 off→on | workspace 字节 off→on | 实际 full-packet 定义 off→on |
|---|---:|---:|---:|---:|
| decode-mha-d64 | 8320→9216 | 4→9 | 66560→73728 | 0→0 |
| decode-gqa-d80 | 12864→13376 | 8→11 | 102912→107008 | 1→1 |
| decode-long-kv | 18560→19200 | 8→11 | 148480→153600 | 1→1 |
| prefill-q4 | 6688→7712 | 10→13 | 0→0 | 0→0 |
| prefill-q8 | 12720→14768 | 16→18 | 101760→118144 | 0→1 |
| batch-gqa-q4 | 9120→10400 | 10→13 | 72960→83200 | 0→0 |

实际 full-packet 数来自 `.ll` 中 `define ... .full_packet(...)` 的计数，和 metadata 一致，不能用 requested P=true 代替。prefill-q8 还多了 3786 条 cloned-instruction 计数，且对象新增了 libc imports，因此不是单纯 MMA 实现 A/B。其余 on clone 数为 GQA-D80/long-KV 各 2369，另外三组为 0。snapshot 字节是容量，不等同于动态访存流量；workspace=0 表示走栈资源，不是没有数组。

## 对回退来源的判断与后续候选

确证的结构变化：旧 lowering 可在 packet 维度生成八个 program 的 SIMD 算术，并用 R4/2D 输出分组复用操作数；新 helper 按 program lane 发起独立调用，其内部四路向量用于 D 或 Dv。QK helper 的外层仍逐 score，因此每个 score 的 D 循环都显式加载 Q；它没有保留此前四输出共用 Q 的寄存器分组。此外 native 参数/结果需要显式快照，MHA 恰在小 SSA 边界，新增五块分配。不能仅凭这些事实量化每项对 52% 回退的贡献。

另一个确定的信息丢失点：验证器已证明 output 与所有输入不重叠，但捕获的优化前 helper 四个形参仍是普通 `ptr`，没有显式将 output `noalias` 事实传给 LLVM。一个很小且通用的后续候选是给 output 加 `noalias`，并保持三输入可相互 alias；`readonly` 输入、`writeonly` 输出也有语义依据。不过 O2/内联可能恢复部分事实，下面的 MHA 对象已经证实 helper 被内联。因此这只是未验证候选，不能断言缺少 noalias 导致实际回退，更不能声称加上它会提速。

另一候选是把贡献维向量化与有限输出寄存器分组组合，而不是每个 score 单独 reduce；需要纳入寄存器预算、保留 math permission，并与保留 packet 维度向量化的路径比较。当前模型对 native MMA cost 明确 `unmodeled`，不能仅以向量指令出现或几何匹配就断定其更快。

## 补充：MHA actual object 有界反汇编

只读命令为 LLVM 22.1.8 的 `llvm-nm --defined-only`、`llvm-objdump --reloc`、`llvm-objdump --disassemble --no-show-raw-insn`；循环片段用 `--start-address`/`--stop-address` 截取。精简片段见 `machine-review-excerpts.txt`。五组完整命令收据为 `machine-review-{on-qk,off-qk,on-text-symbols,on-calls,on-branch-relocations}.receipt.json`，各配同名 `.stdout`/`.stderr`；记录 argv、时间、returncode 和输出 SHA256。符号/调用/重定位三条收据明确包含 `rg` 过滤，保存的是该完整管道输出，不冒充完整对象反汇编。五条 returncode 均为 0，十个输出文件的 hash 已逐个复核。

- MHA on 的 text symbols 只有地址 0 的 `_llm_attention` 和 `0x1d340` 的 `_llm_attention.packet_batch.blocks`（以及同地址临时 label），不存在 strided-MMA 函数。全部 12 处 BL 都在 wrapper，BRANCH26 relocation 全部指向 `_llm_attention`；body `[0,0x1d340)` 内无 BL/BLR。故此对象没有保留 MMA helper 调用，不能把回退解释为 helper call 开销。
- on 对象 `0xa7fc–0xa8e8` 是 16-score 的循环。Q 固定基址 x3 的八个 `ldp q*,q*`（偏移 0 至 `0xe0`）在循环内重复执行；K 的 x24 每轮增加 `0x100`。分支 `0xa8e8 → 0xa7fc` 证明 Q 每 score 重新加载的结构在 O2 后仍在。这里有真实 `fmul.4s` 和 `fadd.4s`，且随后开始下一 program lane 的对应循环（`0xa918`，Q 基址 x6）。
- off 对象 `0x3004–0x307c` 明确复用 Q 的 v11/v0：四组 FMul 都用同一对寄存器，另一个操作数来自相隔 `0x800` 的 K-score 数据。下一 feature 才在 `0x308c/0x3094` 更换 Q 向量。这个片段与 R4 输出分组复用吻合，是 actual code 行为，不只是 lowering 设计预期。
- 此对象中可证实的是“向量指令已生成、helper 已内联、Q 复用结构发生变化”。尚不能从这个片段量化重复加载、快照、寄存器压力或 cache 对 1.52359 时间比各自贡献多少。未逐一反汇编其余五组，也未将其最终指令行为从 MHA 外推。

仍未确认：完整寄存器 spill 归属、cache 行为及各 phase 的耗时占比。未发现已读证据中的确定数值/ABI blocker，但负性能结果本身已足以阻止默认启用。

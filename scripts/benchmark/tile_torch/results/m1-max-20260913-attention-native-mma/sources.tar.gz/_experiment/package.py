"""Package frozen evidence; do not run until audit and all report writers stop.

Usage: python3 -B package.py RAW_ROOT EXISTING_REPORT_DIR [EXACT_TABLE_FILENAME]
An explicitly named table is required, not silently optional. All raw tables
and audit-attempt logs remain in evidence regardless of top-level table choice.
No execution/build/replay occurs. Failures leave partial outputs; never delete
or overwrite them automatically. Redirect packaging stdout outside RAW_ROOT.
"""
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import tarfile
import time

RAW = Path('/tmp/luisa-attention-native-mma.DImNTO').resolve()
REPORT = Path('/Users/mike/CLionProjects/luisa/scripts/benchmark/tile_torch/results/m1-max-20260913-attention-native-mma').resolve()
CACHE_DIRS = {'__pycache__', '.cache', '.pytest_cache', '.mypy_cache'}
TRANSIENT = {'evidence.tar.xz', 'SHA256SUMS', 'package-inventory.json',
             'package.log', 'package.stdout', 'package.stderr'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def regular(path):
    require(not path.is_symlink() and stat.S_ISREG(path.stat().st_mode), 'nonregular file: ' + str(path))
    return path


def digest(path):
    with regular(path).open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def safe_name(name):
    path = PurePosixPath(name)
    require(name and not path.is_absolute() and '..' not in path.parts and
            '\\' not in name and '\x00' not in name, 'unsafe archive name: ' + name)
    return name


def inventory(root):
    included, excluded = {}, []
    for path in sorted(root.rglob('*')):
        mode = path.lstat().st_mode
        require(not path.is_symlink() and (stat.S_ISDIR(mode) or stat.S_ISREG(mode)), 'unsafe raw member: ' + str(path))
        if stat.S_ISDIR(mode):
            continue
        name = safe_name(path.relative_to(root).as_posix())
        if any(part in CACHE_DIRS for part in path.relative_to(root).parts) or \
                path.suffix in ('.pyc', '.pyo') or path.name == '.DS_Store' or \
                name in TRANSIENT or name == 'sources.tar.gz':
            excluded.append(name)
            continue
        require(name not in included, 'duplicate raw member: ' + name)
        included[name] = dict(bytes=path.stat().st_size, sha256=digest(path))
    return included, excluded


def copy_exclusive(source, target):
    with regular(source).open('rb') as input_file, target.open('xb') as output_file:
        shutil.copyfileobj(input_file, output_file, length=1024 * 1024)
    require(digest(source) == digest(target), 'copy mismatch: ' + str(source))


def main():
    require(len(sys.argv) in (3, 4), __doc__)
    root, report = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    require(root == RAW and report == REPORT, 'this script admits only the exact declared raw/report roots')
    require(root.is_dir() and report.is_dir(), 'both directories must already exist')
    require({path.name for path in report.iterdir()} == {'notes.md'}, 'report must contain only notes.md; refusing overwrite')
    notes_hash = digest(report / 'notes.md')
    top_files = ['sources.tar.gz', 'provenance.json', 'audit.py', 'audit.json']
    if len(sys.argv) == 4:
        table = safe_name(sys.argv[3])
        require(PurePosixPath(table).name == table and table not in top_files and
                table not in TRANSIENT and table != 'notes.md', 'table must be a distinct root-level filename')
        top_files.append(table)
    for name in top_files:
        regular(root / name)
    audit = json.loads((root / 'audit.json').read_bytes())
    require(audit.get('status') == 'passed', 'a passed frozen audit is required')
    captures = json.loads(regular(root / 'captures.json').read_bytes())
    replays = json.loads(regular(root / 'replays.json').read_bytes())
    require(captures.get('status') == replays.get('status') == 'complete', 'capture/replay matrix is incomplete')
    require(len(captures['cases']) == len(replays['experiments']) == 6, 'expected all six declared cases')
    require(all(row['status'] == 'OK' for row in (*captures['cases'], *replays['experiments'])),
            'matrix includes Error/NotRun entries')
    require([r['case'] for r in captures['cases']] == [r['case'] for r in replays['experiments']],
            'capture/replay case inventories differ')
    source_hash = digest(root / 'sources.tar.gz')
    provenance = json.loads((root / 'provenance.json').read_bytes())
    require(provenance['source_archive_sha256'] == source_hash, 'frozen source archive identity mismatch')
    plan_hash = digest(root / 'plan.json')
    plan = json.loads(regular(root / 'plan.json').read_bytes())
    require(provenance['plan_sha256'] == captures['plan_sha256'] == replays['plan_sha256'] == plan_hash,
            'source/capture/replay plan identities differ')
    require([r['case'] for r in captures['cases']] == [r['case'] for r in plan['controls']['cases']],
            'completed cases differ from the predeclared plan')
    starts = []
    for row in captures['cases']:
        require(len(row['variants']) == 2, 'capture pair incomplete')
        require([v['label'] for v in row['variants']] ==
                [row['case'] + '-' + v['name'] for v in plan['controls']['variants']],
                'capture variants differ from the predeclared plan')
        for variant in row['variants']:
            label = safe_name(variant['label'])
            require(PurePosixPath(label).name == label, 'capture label must be one root-level name')
            command = json.loads(regular(root / label / 'capture.command.json').read_bytes())
            starts.append(command['started'])
    require(len(starts) == 12 and provenance['frozen_unix'] <= min(starts), 'source was not frozen before first capture')
    # No links/devices/directories are needed in the source archive produced by
    # freeze.py; inspect names and types before copying it as an opaque artifact.
    with tarfile.open(root / 'sources.tar.gz', 'r:gz') as archive:
        members = archive.getmembers()
        require(len({m.name for m in members}) == len(members), 'duplicate source archive members')
        for member in members:
            safe_name(member.name)
            require(member.isfile(), 'nonregular source archive member: ' + member.name)
    started = time.time()
    before, excluded = inventory(root)
    for name in top_files:
        copy_exclusive(root / name, report / name)
    evidence = report / 'evidence.tar.xz'
    with evidence.open('xb') as output:
        with tarfile.open(fileobj=output, mode='w:xz', preset=9) as archive:
            for name, record in sorted(before.items()):
                source = regular(root / name)
                info = tarfile.TarInfo(safe_name(root.name + '/' + name))
                info.size, info.mtime = record['bytes'], int(source.stat().st_mtime)
                info.mode = stat.S_IMODE(source.stat().st_mode) & 0o777
                with source.open('rb') as input_file:
                    archive.addfile(info, input_file)
    after, excluded_after = inventory(root)
    require(before == after and excluded == excluded_after, 'raw evidence changed while packaging')
    require(digest(root / 'sources.tar.gz') == source_hash, 'source archive changed while packaging')
    require(digest(report / 'notes.md') == notes_hash, 'report changed while packaging')
    metadata = dict(format='attention-native-mma-package-v1', started_unix=started,
                    finished_unix=time.time(), raw_root=str(root), report_root=str(report),
                    evidence_archive_sha256=digest(evidence), evidence_members=before,
                    regular_file_count=len(before), excluded_raw_paths=excluded,
                    separate_source_archive_sha256=source_hash, top_level_copies=top_files,
                    notes_sha256=notes_hash, compression='xz preset 9; sorted regular-file tar members',
                    reconstruction='Extract evidence.tar.xz, then copy the top-level sources.tar.gz into ' + root.name + '/ before running extracted audit.py.',
                    boundary='Byte/inventory packaging checks only; no native code, build, timing or loader-closure validation.')
    with (report / 'package-inventory.json').open('x') as output:
        json.dump(metadata, output, indent=2, allow_nan=False)
        output.write('\n')
    expected = {*top_files, 'notes.md', 'evidence.tar.xz', 'package-inventory.json'}
    require({p.name for p in report.iterdir()} == expected, 'unexpected report directory change')
    hashes = {name: digest(report / name) for name in sorted(expected)}
    with (report / 'SHA256SUMS').open('x') as output:
        for name, value in hashes.items():
            output.write(value + '  ' + name + '\n')
    print(json.dumps(dict(status='packaged', regular_files=len(before),
                          evidence_bytes=evidence.stat().st_size, evidence_sha256=hashes['evidence.tar.xz'],
                          source_bytes=(report / 'sources.tar.gz').stat().st_size,
                          checksums=len(hashes), report=str(report)), indent=2))


if __name__ == '__main__':
    main()

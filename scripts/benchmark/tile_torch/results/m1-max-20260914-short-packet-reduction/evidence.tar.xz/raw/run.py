"""Retained build/test receipts for short-domain packet reduction work."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent
SELECTED = Path('/Users/mike/.cache/luisa-tile/metal-short-reduce.rq8Wsn/source')
BUILD = SELECTED.parent / 'build'
BASE = Path('/Users/mike/.cache/luisa-tile/metal-next.6pECu2/source')
OVERLAYS = [
    'src/tile/bridge/xir/lower.cpp',
    'src/tile/bridge/xir/representation.h',
    'src/tile/bridge/xir/planner.cpp',
    'src/tile/bridge/xir/program_team.h',
    'src/tests/CMakeLists.txt',
    'src/tests/common/tile_packet_reduction_test_utils.h',
    'src/tests/unit/tile/bridge/test_xir_program_team.cpp',
    'src/tests/unit/tile/bridge/test_xir_target_info.cpp',
    'src/tests/unit/tile/bridge/test_xir_runtime.cpp',
    'src/tests/unit/tile/bridge/test_xir_metal.cpp',
]


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2, allow_nan=False)
        stream.write('\n')


def run(name, command, timeout=1800, native=False):
    directory = OUT / name
    directory.mkdir()
    env = {k: v for k, v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_', 'DYLD_'))}
    env.update(OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', PYTORCH_ENABLE_MPS_FALLBACK='0')
    receipt = dict(command=command, cwd=str(SELECTED), started=time.time(), timeout_seconds=timeout,
                   native=native, harness_sha256=digest(__file__),
                   source_sha256={p: digest(SELECTED / p) for p in OVERLAYS},
                   environment={k: v for k, v in env.items() if k.startswith(('LUISA_', 'MTL_', 'DYLD_', 'OMP_', 'VECLIB_', 'PYTORCH_'))})
    save(directory / 'command.json', receipt)
    process = subprocess.Popen(command, cwd=SELECTED, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    try:
        stdout, stderr = process.communicate(timeout=timeout)
    except BaseException as error:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        stdout, stderr = process.communicate()
        receipt.update(interrupted=str(error), timed_out=isinstance(error, subprocess.TimeoutExpired))
    (directory / 'stdout.txt').write_bytes(stdout)
    (directory / 'stderr.txt').write_bytes(stderr)
    receipt.update(finished=time.time(), exit_code=process.returncode, stdout_sha256=digest(directory / 'stdout.txt'),
                   stderr_sha256=digest(directory / 'stderr.txt'))
    save(directory / 'result.json', receipt)
    print(json.dumps(receipt), flush=True)
    if process.returncode != 0 or 'interrupted' in receipt:
        print(stderr.decode(errors='replace')[-8000:], flush=True)
        print(stdout.decode(errors='replace')[-8000:], flush=True)
        raise SystemExit(1)


def main():
    mode = sys.argv[1]
    if mode == 'freeze':
        import shutil
        for relative in OVERLAYS:
            source, destination = ROOT / relative, SELECTED / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
        exports = json.loads(Path('/tmp/luisa-metal-block-mapping.eI6JXf/source-export.json').read_text())
        save(OUT / ('source-' + sys.argv[2] + '.json'), dict(
            baseline=exports, base_source=str(BASE), selected_source=str(SELECTED),
            overlay_sha256={p: digest(SELECTED / p) for p in OVERLAYS},
            repository_head=subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
            note='Cloned exact pinned baseline; explicit owned overlays only. Protected root WIP excluded.'))
    elif mode == 'configure':
        run('configure', ['cmake', '-S', str(SELECTED), '-B', str(BUILD), '-G', 'Ninja',
            '-DCMAKE_BUILD_TYPE=RelWithDebInfo', '-DCMAKE_C_COMPILER=/usr/bin/cc', '-DCMAKE_CXX_COMPILER=/usr/bin/c++',
            '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DCMAKE_OSX_DEPLOYMENT_TARGET=13',
            '-DLUISA_COMPUTE_ENABLE_GUI=OFF', '-DLUISA_COMPUTE_ENABLE_CUDA=OFF', '-DLUISA_COMPUTE_ENABLE_DX=OFF',
            '-DLUISA_COMPUTE_ENABLE_VULKAN=OFF', '-DLUISA_COMPUTE_ENABLE_FALLBACK=OFF',
            '-DLUISA_COMPUTE_ENABLE_METAL=ON', '-DLUISA_COMPUTE_ENABLE_METAL4=ON', '-DLUISA_COMPUTE_ENABLE_SIMD=ON',
            '-DLUISA_COMPUTE_BUILD_TESTS=ON', '-DLUISA_COMPUTE_ENABLE_TILE_TIRX_BRIDGE=ON',
            '-DLLVM_DIR=/opt/homebrew/opt/llvm@22/lib/cmake/llvm',
            '-DLUISA_COMPUTE_TVM_INCLUDE_DIR=/Users/mike/.cache/luisa-tile/tvm-pinned.9TMqn1/include',
            '-DLUISA_COMPUTE_TVM_FFI_INCLUDE_DIR=/Users/mike/.cache/luisa-tile/tvm-pinned.9TMqn1/3rdparty/tvm-ffi/include',
            '-DLUISA_COMPUTE_TVM_LIBRARY_DIR=/Users/mike/.cache/luisa-tile/tvm-fragment-build.0ToXYr/lib',
            '-DLUISA_COMPUTE_TVM_FFI_LIBRARY_DIR=/Users/mike/.cache/luisa-tile/tvm-fragment-build.0ToXYr/lib'], 300)
    elif mode == 'build':
        run('build-' + sys.argv[2], ['cmake', '--build', str(BUILD), '-j', '6'])
    elif mode == 'command':
        run(sys.argv[2], sys.argv[3:], 600)
    else:
        raise ValueError(mode)


if __name__ == '__main__':
    main()

"""Read-only Mach-O dependency inspection; never loads or executes a native image."""

import json
from pathlib import Path
import subprocess
import time


ROOT = Path(__file__).resolve().parent
BASE = Path('/Users/mike/.cache/luisa-tile/metal-next.6pECu2/build')
CANDIDATE = Path('/Users/mike/.cache/luisa-tile/metal-short-reduce.rq8Wsn/build')
TVM = Path('/Users/mike/.cache/luisa-tile/tvm-fragment-build.0ToXYr/lib')
IMAGES = {
    'baseline_test': BASE / 'bin/test_tile_xir_runtime',
    'candidate_test_after_no_tirx_reconfigure': CANDIDATE / 'bin/test_tile_xir_runtime',
    'baseline_simd_backend': BASE / 'bin/libluisa-backend-simd.so',
    'candidate_simd_backend': CANDIDATE / 'bin/libluisa-backend-simd.so',
    'tvm_compiler': TVM / 'libtvm_compiler.dylib',
}


def main():
    destination = ROOT / 'linkage-inspection.json'
    if destination.exists():
        raise SystemExit('Refusing to overwrite an earlier inspection')
    output = {
        'started': time.time(),
        'boundary': 'Static dependency commands only, after the candidate was rebuilt with in-process TIRx comparison OFF. Not a dyld symbol-resolution trace, binary hash attestation, or execution result.',
        'commands': {},
        'configuration': {},
    }
    for label, image in IMAGES.items():
        command = ['/usr/bin/otool', '-L', str(image)]
        result = subprocess.run(command, capture_output=True, text=True, check=False)
        output['commands'][label] = {
            'command': command,
            'exit_code': result.returncode,
            'stdout': result.stdout,
            'stderr': result.stderr,
        }
        if result.returncode != 0:
            output['inspection_error'] = True
    for label, build in [('baseline', BASE), ('candidate', CANDIDATE)]:
        cache = build / 'CMakeCache.txt'
        output['configuration'][label] = {
            'path': str(cache),
            'selected_lines': [line for line in cache.read_text().splitlines()
                               if line.startswith(('LUISA_COMPUTE_TILE_XIR_TEST_TIRX_COMPARISON:', 'LLVM_DIR:'))],
        }
    output['finished'] = time.time()
    with destination.open('x') as stream:
        json.dump(output, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'output': str(destination), 'commands': len(output['commands']),
                      'all_exit_zero': not output.get('inspection_error', False)}))


if __name__ == '__main__':
    main()

# Short common-axis reduction：测试边界复核草稿

本记录只复核已经运行的收据，不执行 native/build。它不是全套通过声明，也不含性能结论。原始失败记录不得覆盖。

## 源码身份

基线来自 `source-initial.json` 内嵌、且 `isolated-host-plan.json` 引用的原始 `source-export.json`：主仓库提交 `b21d33053793fba9aae8953861c1a9c66deb049f` 加逐一固定的递归子模块。候选是在这份导出上叠加 10 个明确的 owned 文件，不等于当时工作树 HEAD `cecf781922a513cb75fd3216e5c3abade1d29cb9` 的完整导出。`source-initial.json` 与 `source-namespace-fix.json` 分别保留初始、修复后的 overlay 哈希。

`isolated-host-results.json` 和 `postbuild3-host/isolated-host-results.json` 都记录 baseline artifacts 未变。其基线 `test_tile_xir` SHA256 是 `7a027ea3a0c15d611432804bbd66be238dddda281ba6c16d3eb482c2f676901d`。通用 run.py 写在 baseline command receipt 中的 `source_sha256` 是当前候选上下文，不是旧二进制的编译来源；必须用独立 baseline export 与 artifact 指纹解释，不能倒置。

## 当前已核实的门禁

| 门禁 | 原始结果 | 可支持的结论 |
|---|---|---|
| `build-full-1` | exit -9；timed_out=false | 初次构建未完成，保留；不能只凭 -9 断言 OOM 或编译错误 |
| `build-full-2` | exit 0 | namespace 修复后的完整选定构建完成 |
| `build-full-3` | exit 0 | 关闭 in-process TIRx comparison 后的完整选定构建完成 |
| `host-scoped-tests-final` | 2/2 CTests；24580 assertions / 21 target-info tests；338525 assertions / 7 program-team tests | 新 host admission/resource/model 覆盖通过 |
| 原 `test_tile_xir` 20 个 case 逐例执行，两轮均一致 | 18 pass；2 个 -6 | 不是 20/20；下面两个既有 recoverable-contract 缺口单独记录 |
| `metal-tests` 全套 | 240.05 s CTest timeout | 全套未完成；不能标为通过，也不能据此宣称 GPU hang |
| `metal-short` 定向短规约 | exit 0；96 assertions；6 registered、1 executed、5 filtered | 当前新增 Metal4 短规约 seeds/snapshots 这一项定向覆盖通过，不是运行了 6 项 |
| `simd-tests`、`simd-short` 初次候选 | LLVM AnalysisManager segfault | 初次 SIMD 不能标通过 |
| `baseline-simd-root` | 相同 LLVM AnalysisManager segfault，exit -11 | 崩溃可在未叠加本次短规约改动的基线复现 |
| `simd-tests-final`：关闭 TIRx in-process comparison 后的 SIMD 最终重测 | exit 0；5195002 assertions / 26 tests；CTest 94.79 s | 当前选定配置下整套 SIMD runtime 测试通过；初次崩溃仍保留 |

## 精确限定的两条既有 host 失败

只有下面两个命名 case、candidate 与 baseline 同时 exit -6、并且错误正文精确为 `XIR realization exceeds its static SSA expansion budget; choose smaller Tiles` 时，才符合这次已复核的既有错误边界：

1. `tile_xir_large_tiles_have_bounded_code_and_eager_load_snapshots`：全展开诊断 `max_unrolled_tile_elements=0`、`max_expanded_values=256` 本应返回失败结果，在 `_charge` 达到预算时 abort。
2. `tile_xir_expansion_budget_is_fail_closed`：`max_expanded_values=8` 本应返回含 expansion-budget error 且无 module 的失败结果，实际也在 `_charge` abort。

对应证据是 `host-isolated-14/17` 与 `baseline-isolated-14/17`；重建后全部 20 case 再跑的证据在 `postbuild3-host/`。这不是允许任意 SIGABRT 的白名单。`resources.h` 的现有 admission 能预先检查 snapshot 容量/recipe 深度，但没有可靠的完整 SSA emission charge 预检；potential-work estimate 不等于展开计数的安全上界。彻底修复需要共享 expansion plan 或显式错误传播，不应靠扩大预算、删除 error-return 断言或改为 death test 来掩盖。

## SIMD LLVM 链接诊断

初始 runtime test 直接依赖 TIRx/TVM；SIMD backend 使用 LLVM 22.1.8，TVM compiler 使用 LLVM 21.1.8。基线与候选 stderr 同时出现 `TVMFFISegFaultHandler`、`llvm::AnalysisManager<llvm::Module>::getResultImpl`、`PassManager::run`，并在 Tile compile 中崩溃。它与仓库 `src/tests/CMakeLists.txt` 已注明的 incompatible LLVM weak-symbol coalescing 风险一致，但静态链接本身不证明具体哪个符号被 interpose。

现有选项 `LUISA_COMPUTE_TILE_XIR_TEST_TIRX_COMPARISON=OFF` 只拆开 runtime/LLM 测试进程中的比较依赖，不关闭 TIRx bridge 的独立测试，也不删除独立数值 oracle。`configure-no-tirx-comparison` 和 `build-full-3` 保留此调整；随后 `simd-tests-final` 全部通过。`linkage-inspection.json` 记录 5 条 exit-zero 的静态检查：基线 runtime 仍直接依赖 TIRx/TVM，重建后的候选 runtime 不再含这些依赖，两个 SIMD backend 仍依赖 LLVM 22，而 TVM compiler 依赖 LLVM 21。该配置干预及后续成功加强了链接冲突的诊断，但仍不能确认具体弱符号的动态解析归属。它是调整后候选与未变基线的静态依赖检查，不能冒充调整前候选二进制的指纹，也不冒充动态加载闭包或实际符号解析记录。

## 后续填写条件

SIMD 已按真实终态结果补齐；Metal 最终整体结果及后续性能仍由主线程完成并追加，不以定向通过替代整体超时。编译/正确性门禁时间不是纯 kernel 性能，不进入 benchmark 速度表。完整证据包按 `archive-manifest-draft.json` 选材；此稿未执行打包或宣称可重建完整动态依赖闭包。

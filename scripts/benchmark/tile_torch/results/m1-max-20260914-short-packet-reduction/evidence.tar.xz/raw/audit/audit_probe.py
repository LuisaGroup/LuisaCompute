"""Bounded offline audit: no native imports, builds, captures or timing runs.

Metrics are independently recomputed from raw ticks, command-buffer intervals
and host samples. Only the existing independent FP64 mathematical reference is
reused; producer expected tensors and aggregate metric calculations are not.
"""
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
import time

import numpy as np

RAW = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
HELPERS = Path('/Users/mike/CLionProjects/luisa/scripts/benchmark/tile_torch')
sys.path.insert(0, str(HELPERS))
from compare_llm import gpu_failure_diagnostics, reference, shapes_for

CASES = [(f'{op}-4096x{width}', op, [4096, width])
         for op in ('rmsnorm', 'masked_softmax') for width in (7, 31, 65)]
ORDER = [1, 32, 32, 1] * 2
LABELS = ('instrumented_dispatch_ns', 'feedback_only_command_buffer_ns_per_dispatch',
          'host_wall_us_per_dispatch')
METRICS = [f'{phase}_{label}' for phase in ('throughput', 'latency') for label in LABELS]


def need(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def same_number(a, b, message):
    need(math.isfinite(a) and math.isfinite(b) and math.isclose(a, b, rel_tol=2e-12, abs_tol=1e-7), message)


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def samples_from_payload(payload, lanes, expected_checksum):
    timing = payload['device_timing']
    need(timing['scope'] == 'instrumented_dispatch_intervals' and timing['zero_overhead_kernel_time'] is False
         and timing['host_samples_instrumented'] is False and timing['repetitions'] == 16, 'timing boundary')
    need(timing['control']['encoder_instrumentation'] is False and timing['control']['repetitions'] == 16,
         'control timing boundary')
    frequency = timing['capabilities']['timestamp_frequency_hz']
    need(frequency > 0 and timing['capabilities']['timestamp_heap'] is True, 'timestamp capability')
    values, ids = {}, set()
    for phase, expected_count in (('throughput', 16), ('latency', 1)):
        for counters, owner, label in ((True, timing, LABELS[0]), (False, timing['control'], LABELS[1])):
            records = owner[phase]
            need(len(records) == 3, 'sample cardinality')
            extracted = []
            for sample in records:
                need(sample['sample_id'] not in ids, 'duplicate sample id')
                ids.add(sample['sample_id'])
                need(sample['error'] == '' and sample['overflow'] is False
                     and sample['dispatch_timestamps_enabled'] is counters
                     and sample['timestamp_frequency_hz'] == (frequency if counters else 0), 'sample status/mode')
                dispatches = sample['dispatches']
                need(len(dispatches) == expected_count, 'dispatch denominator')
                buffers = {item['ordinal']: item for item in sample['command_buffers']}
                need(len(buffers) == len(sample['command_buffers']), 'duplicate command buffer')
                elapsed, owners, ordinals = [], {}, set()
                for dispatch in dispatches:
                    need(dispatch['ordinal'] not in ordinals, 'duplicate dispatch ordinal')
                    ordinals.add(dispatch['ordinal'])
                    owner_id = dispatch['command_buffer_ordinal']
                    need(owner_id in buffers, 'missing command-buffer owner')
                    owners[owner_id] = owners.get(owner_id, 0) + 1
                    need(dispatch['dispatch_size'] == [4096 * lanes, 1, 1]
                         and dispatch['block_size'] == [256, 1, 1]
                         and dispatch['shader_checksum'] == expected_checksum, 'physical shader/geometry drift')
                    if counters:
                        need(dispatch['valid'] is True and 0 < dispatch['begin_ticks'] < dispatch['end_ticks'],
                             'invalid hardware ticks')
                        value = (dispatch['end_ticks'] - dispatch['begin_ticks']) * 1e9 / frequency
                        same_number(value, dispatch['elapsed_ns'], 'tick conversion mismatch')
                        elapsed.append(value)
                    else:
                        need(dispatch['valid'] is False and dispatch['begin_ticks'] == dispatch['end_ticks']
                             == dispatch['elapsed_ns'] == 0, 'feedback control has instrumentation')
                gpu_interval = 0.0
                for ordinal, buffer in buffers.items():
                    count = buffer['dispatch_count']
                    need(count == owners.get(ordinal, 0) and buffer['contains_non_dispatch_work'] is False,
                         'buffer accounting/non-dispatch work')
                    if count:
                        need(buffer['valid'] is True and 0 < buffer['gpu_begin_seconds'] < buffer['gpu_end_seconds'],
                             'invalid feedback interval')
                        gpu_interval += (buffer['gpu_end_seconds'] - buffer['gpu_begin_seconds']) * 1e9
                extracted.append(statistics.median(elapsed) if counters else gpu_interval / expected_count)
            values[f'{phase}_{label}'] = extracted
        values[f'{phase}_{LABELS[2]}'] = payload[f'{phase}_us']
    need(len(ids) == 12 and set(values) == set(METRICS), 'metric/sample-id coverage')
    for values_for_metric in values.values():
        need(len(values_for_metric) == 3 and all(math.isfinite(x) and x > 0 for x in values_for_metric),
             'nonpositive/nonfinite time sample')
    return values


def main():
    started = time.time()
    plan, result, reported = [read(RAW / name) for name in ('probe-plan.json', 'probe-results.json', 'probe-pairs.json')]
    after = read(RAW / 'probe-fingerprints-after.json')
    need(result['status'] == 'complete' and len(result['rows']) == 48 and result['fingerprints_unchanged']
         and reported['cohort_complete'] and reported['fingerprint_valid'], 'cohort incomplete')
    need(plan['cases'] == [[name, op, dims] for name, op, dims in CASES] and plan['local_lanes_order'] == ORDER
         and plan['samples'] == 3 and plan['repetitions'] == 16 and plan['block_size'] == 256, 'predeclared cohort')
    expected_fp = plan['fingerprints_before']
    need(after['unchanged'] is True and after['fingerprints_after'] == expected_fp, 'before/after provenance changed')
    current_fp = {kind: {path: sha(path) for path in entries} for kind, entries in expected_fp.items()}
    need(current_fp == expected_fp, 'source/artifact/gate changed since timing')
    checked, input_identity, output_identity, shader_identity, metrics = [], {}, {}, {}, {}
    evidence = {str(RAW / name): sha(RAW / name) for name in
                ('probe-plan.json', 'probe-results.json', 'probe-pairs.json', 'probe-fingerprints-after.json')}
    previous_finish = plan['started']
    for row_index, row in enumerate(result['rows']):
        case, op, dims = CASES[row_index // 8]
        position, lanes = row_index % 8, ORDER[row_index % 8]
        need((row['case'], row['position'], row['operation'], row['dimensions'], row['actual_local_lanes'])
             == (case, position, op, dims, lanes), 'visit order/case identity')
        folder = RAW / f'probe-{case}-{position:02d}-lanes{lanes}'
        cohort = folder / 'cohort'
        need(Path(row['result']).resolve() == (cohort / 'results.json').resolve(), 'visit path')
        outer, outer_command = read(folder / 'result.json'), read(folder / 'command.json')
        need(outer['status'] == 'passed' and outer['exit_code'] == 0 and not outer.get('timed_out')
             and previous_finish <= outer['started'] <= outer['finished'] <= result['finished'], 'outer status/serial chronology')
        need(outer['command'] == outer_command['command'] and outer['probe_sha256'] == sha(RAW / 'probe.py'),
             'outer command/driver identity')
        for path, value in outer['logs_sha256'].items():
            need(sha(path) == value, 'outer log changed')
        previous_finish = outer['finished']
        report = read(cohort / 'results.json')
        need(report['cohort_valid'] and report['gpu_diagnostics_valid'] and report['artifacts_unchanged']
             and report['artifacts_before'] == report['artifacts_after'] and len(report['results']) == 1,
             'helper provenance/status')
        for path, receipt in report['artifacts_before'].items():
            need(expected_fp['artifact_sha256'].get(path) == receipt['sha256'], 'helper artifact differs from cohort freeze')
        visit = report['results'][0]
        need(visit['status'] == 'OK' and visit['valid'] and visit['exit_code'] == 0
             and visit['operation'] == op and visit['dimensions'] == dims
             and visit['actual_local_lanes'] == visit['requested_local_lanes'] == lanes
             and visit['actual_block_size'] == visit['requested_block_size'] == 256, 'native visit identity/status')
        payload_path, stderr_path = cohort / visit['stdout'], cohort / visit['stderr']
        payload = read(payload_path)
        need(not gpu_failure_diagnostics(payload_path.read_bytes(), stderr_path.read_bytes()), 'GPU diagnostic')
        need(payload['implementation'] == 'tile_xir_metal4' and payload['backend'] == 'metal4'
             and payload['operation'] == op and payload['dimensions'] == dims
             and payload['precision'] == 'fp32' and payload['fast_math'] is False and payload['relaxed_precision'] is False
             and payload['repetition_policy'] == 'fixed' and payload['repetitions'] == 16
             and payload['dispatch'] == row['dispatch'] == [4096 * lanes, 1, 1], 'payload math/dispatch contract')
        need(row['threadgroups'] == 4096 * lanes // 256 and row['block_size'] == 256, 'threadgroup geometry')
        correctness = payload['correctness']
        need(correctness == row['correctness'] == visit['correctness'] and correctness['checks'] == 2
             and correctness['elements_per_check'] == math.prod(dims) and correctness['guard_elements_per_check'] == 34
             and correctness['atol'] == correctness['rtol'] == 5e-5, 'producer full-check/guard evidence')
        tensor = Path(visit['command'][-1])
        input_shapes, output_shape = shapes_for(op, dims)
        paths = [tensor, *[Path(str(tensor) + f'.input{i}.f32') for i in range(3)]]
        need(set(map(str, paths)) == set(visit['tensor_receipts']) and row['tensor_receipts'] == visit['tensor_receipts'],
             'tensor receipt completeness')
        arrays, receipts = [], []
        for path, shape in zip(paths, [output_shape, *input_shapes]):
            receipt = visit['tensor_receipts'][str(path)]
            need(path.stat().st_size == receipt['bytes'] == math.prod(shape) * 4 and sha(path) == receipt['sha256'],
                 'full tensor size/hash mismatch')
            array = np.fromfile(path, dtype=np.float32).reshape(shape)
            need(np.isfinite(array).all(), 'nonfinite tensor')
            arrays.append(array)
            receipts.append(receipt['sha256'])
        need(input_identity.setdefault(case, receipts[1:]) == receipts[1:], 'cross-visit input mathematical mismatch')
        need(output_identity.setdefault((case, lanes), receipts[0]) == receipts[0], 'same-arm output bit mismatch')
        checksum = payload['device_timing']['throughput'][0]['dispatches'][0]['shader_checksum']
        need(shader_identity.setdefault((case, lanes), checksum) == checksum == row['shader_checksum'], 'same-arm shader mismatch')
        expected = reference(op, dims, arrays[1:])
        difference = np.abs(arrays[0].astype(np.float64) - expected)
        need(np.all(difference <= 5e-5 + 5e-5 * np.abs(expected)), 'full independent FP64 mismatch')
        same_number(float(difference.max()), visit['independent_correctness']['max_abs_error'], 'oracle maximum mismatch')
        values = samples_from_payload(payload, lanes, checksum)
        medians = {}
        for metric, values_for_metric in values.items():
            median = statistics.median(values_for_metric)
            for aggregate in (row['metrics'][metric], visit['metrics'][metric]):
                need(len(aggregate['samples']) == 3, 'aggregate sample length')
                for a, b in zip(values_for_metric, aggregate['samples']):
                    same_number(a, b, 'raw sample/aggregate mismatch')
                same_number(median, aggregate['median'], 'visit median mismatch')
            medians[metric] = median
        metrics[(case, position)] = medians
        checked.append(dict(case=case, position=position, lanes=lanes, elements=expected.size,
                            independent_max_abs_error=float(difference.max()), metric_samples=values, medians=medians,
                            producer_guard_checks=correctness['checks'], guard_elements_per_check=34))
        evidence.update({str(path): sha(path) for path in (payload_path, stderr_path, cohort / 'results.json',
                                                        folder / 'result.json', folder / 'command.json')})
    pairs, summary = [], []
    for case, _, _ in CASES:
        ratios_by_metric = {metric: [] for metric in METRICS}
        for first in (0, 2, 4, 6):
            a, b = (first, first + 1) if ORDER[first] == 1 else (first + 1, first)
            ratios = {metric: metrics[(case, b)][metric] / metrics[(case, a)][metric] for metric in METRICS}
            recorded = reported['pairs'][len(pairs)]
            need(recorded['case'] == case and recorded['positions'] == [first, first + 1]
                 and recorded['visit_order'] == ORDER[first:first + 2], 'pair identity/order')
            for metric, ratio in ratios.items():
                same_number(ratio, recorded['metric_ratios_local32_over_local1'][metric], 'pair ratio mismatch')
                ratios_by_metric[metric].append(ratio)
            pairs.append(dict(case=case, positions=[first, first + 1], ratios=ratios))
        for metric, ratios in ratios_by_metric.items():
            unit = 'us' if metric.endswith('_us_per_dispatch') else 'ns'
            entry = dict(case=case, metric=metric, original_metric_unit=unit, paired_ratios=ratios,
                         pair_count=4, median_ratio=statistics.median(ratios), min_ratio=min(ratios), max_ratio=max(ratios))
            target = reported['summary'][len(summary)]
            for key in ('case', 'metric', 'original_metric_unit', 'pair_count'):
                need(entry[key] == target[key], 'summary identity/unit')
            for key in ('median_ratio', 'min_ratio', 'max_ratio'):
                same_number(entry[key], target[key], 'summary reduction mismatch')
            for a, b in zip(entry['paired_ratios'], target['paired_ratios']):
                same_number(a, b, 'summary pair list mismatch')
            entry['all_four_pairs_below_one'] = all(value < 1 for value in ratios)
            entry['all_four_pairs_above_one'] = all(value > 1 for value in ratios)
            entry['local1_visit_median_us'] = statistics.median(metrics[(case, p)][metric] for p in range(8) if ORDER[p] == 1) / (1000 if unit == 'ns' else 1)
            entry['local32_visit_median_us'] = statistics.median(metrics[(case, p)][metric] for p in range(8) if ORDER[p] == 32) / (1000 if unit == 'ns' else 1)
            summary.append(entry)
    need(len(pairs) == len(reported['pairs']) == 24 and len(summary) == len(reported['summary']) == 36, 'pair/summary completeness')
    save(OUT / 'audit-result.json', dict(status='passed', started=started, finished=time.time(),
        audit_script_sha256=sha(__file__), python=sys.executable, numpy=np.__version__, visits=48,
        tensor_files=192, oracle_elements=sum(row['elements'] for row in checked),
        raw_metric_samples=864, adjacent_pairs=24, metric_summaries=36,
        provenance_files=sum(map(len, expected_fp.values())), provenance_current_unchanged=True,
        visits_checked=checked, pairs=pairs, summary=summary, evidence_sha256=evidence,
        limits=['No native execution, performance rerun or source modification.',
                'FP64 mathematical oracle reused from existing helper, independent of producer expected output.',
                'Guard data are not exported. Audit validates producer two-pass/34-guard receipts, not raw guard bytes.',
                'Same candidate binary: local32 versus local1; not a before/after compiler or MPS/Torch comparison.',
                'Four descriptive adjacent pairs, no statistical confidence or winner-selection claim.',
                'Instrumented dispatch intervals are not zero-overhead pure kernel time; feedback includes command-buffer scope.']))
    for case, _, _ in CASES:
        print(case, {item['metric']: round(item['median_ratio'], 4) for item in summary if item['case'] == case}, flush=True)
    print('OFFLINE AUDIT PASSED: 48 visits, 192 tensors, 864 samples, 24 pairs, 36 summaries', flush=True)


if __name__ == '__main__':
    main()

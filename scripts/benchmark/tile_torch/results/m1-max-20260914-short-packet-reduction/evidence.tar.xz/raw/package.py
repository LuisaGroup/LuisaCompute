"""Package already completed short-packet evidence; never build or run a kernel.

Run only after every raw writer and native process has stopped. The raw tree is
read-only. Failed attempts remain evidence, not a reason to relabel a gate pass.
Only ten receipt-bound overlays are copied, not the whole working tree. Native
artifacts are final file fingerprints, not a dynamic-loader closure attestation.
"""

import argparse
import hashlib
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import tarfile
import time


DEFAULT_RAW = Path(__file__).resolve().parent
DEFAULT_OUTPUT = Path('/Users/mike/CLionProjects/luisa/scripts/benchmark/tile_torch/results/m1-max-20260914-short-packet-reduction')
EXCLUDED_DIRS = {'__pycache__', '.venv', 'venv', '.git'}
COMPILED_SUFFIXES = {'.pyc', '.pyo', '.o', '.obj', '.a', '.so', '.dylib', '.dll', '.exe', '.metallib', '.air', '.bc', '.bin'}
OVERLAYS = {
    'src/tests/CMakeLists.txt',
    'src/tests/common/tile_packet_reduction_test_utils.h',
    'src/tests/unit/tile/bridge/test_xir_metal.cpp',
    'src/tests/unit/tile/bridge/test_xir_program_team.cpp',
    'src/tests/unit/tile/bridge/test_xir_runtime.cpp',
    'src/tests/unit/tile/bridge/test_xir_target_info.cpp',
    'src/tile/bridge/xir/lower.cpp',
    'src/tile/bridge/xir/planner.cpp',
    'src/tile/bridge/xir/program_team.h',
    'src/tile/bridge/xir/representation.h',
}
SUITES = ('test_tile_xir', 'test_tile_xir_target_info', 'test_tile_xir_program_team',
          'test_tile_xir_runtime', 'test_tile_xir_metal')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def fingerprint(path, *, allow_symlink=False):
    require(path.is_file() and (allow_symlink or not path.is_symlink()), 'not a regular file: ' + str(path))
    with path.open('rb') as stream:
        return {'bytes': path.stat().st_size, 'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def collect_raw(root):
    files, excluded = {}, []
    for directory, dirs, names in os.walk(root, followlinks=False):
        parent = Path(directory)
        kept = []
        for name in sorted(dirs):
            path = parent / name
            if name in EXCLUDED_DIRS:
                excluded.append({'path': path.relative_to(root).as_posix(), 'reason': 'generated/cache/environment directory'})
            else:
                require(not path.is_symlink(), 'directory symlink in raw: ' + str(path))
                kept.append(name)
        dirs[:] = kept
        for name in sorted(names):
            path = parent / name
            relative = path.relative_to(root).as_posix()
            require(not path.is_symlink(), 'file symlink in raw: ' + str(path))
            if path.suffix.lower() in COMPILED_SUFFIXES:
                excluded.append({'path': relative, 'reason': 'compiled artifact', 'fingerprint': fingerprint(path)})
                continue
            require(not name.startswith('evidence.tar'), 'do not recursively package an earlier evidence archive')
            files[relative] = fingerprint(path)
    return files, excluded


def completed_receipts(raw, files):
    receipts = []
    for relative in sorted(files):
        if Path(relative).name != 'command.json':
            continue
        folder = (raw / relative).parent
        command, result_path = read(folder / 'command.json'), folder / 'result.json'
        require(result_path.is_file(), 'unfinished command: ' + relative)
        result = read(result_path)
        require('exit_code' in result and 'finished' in result, 'no terminal result: ' + str(result_path))
        require(result['finished'] >= command['started'], 'invalid command chronology')
        require(result.get('command') == command.get('command'), 'command/result argv differs')
        for channel in ('stdout', 'stderr'):
            key = channel + '_sha256'
            if key in result:
                require(fingerprint(folder / (channel + '.txt'))['sha256'] == result[key], 'changed command log')
        for original, expected in result.get('logs_sha256', {}).items():
            path = Path(original).resolve(strict=True)
            require(path.is_relative_to(raw), 'log receipt outside raw')
            require(fingerprint(path)['sha256'] == expected, 'changed probe log')
        receipts.append({'directory': folder.relative_to(raw).as_posix(), 'exit_code': result['exit_code'],
                         'timed_out': result.get('timed_out', False), 'status': result.get('status'),
                         'validation': 'terminal receipt, not a pass classification'})
    require(receipts, 'no completed command receipts')
    return receipts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw', type=Path, default=DEFAULT_RAW)
    parser.add_argument('--output', type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument('--source-receipt', default='source-namespace-fix.json')
    parser.add_argument('--probe-output', type=Path,
                        help='Optional completed probe directory under raw (use . for raw itself); no probe execution.')
    parser.add_argument('--writers-stopped', action='store_true', required=True,
                        help='Operator confirmation that native work and all raw/source writers are stopped.')
    args = parser.parse_args()
    started = time.time()
    raw = args.raw.resolve(strict=True)
    output = args.output.resolve()
    require(not output.is_relative_to(raw) and not raw.is_relative_to(output), 'raw/output must be disjoint')
    output.mkdir(parents=True, exist_ok=True)
    outputs = ('evidence.tar.xz', 'package-inventory.json', 'package-receipt.json', 'SHA256SUMS')
    require(all(not (output / name).exists() for name in outputs), 'refuse to overwrite an earlier packaging attempt')
    receipt_path = (raw / args.source_receipt).resolve(strict=True)
    require(receipt_path.is_relative_to(raw), 'source receipt escapes raw')
    source = read(receipt_path)
    require(set(source['overlay_sha256']) == OVERLAYS, 'expected exactly ten final overlays')
    selected = Path(source['selected_source']).resolve(strict=True)
    build = selected.parent / 'build'
    files, excluded = collect_raw(raw)
    receipts = completed_receipts(raw, files)
    members = {'raw/' + name: (raw / name, info) for name, info in files.items()}

    def add(name, path, expected_sha=None):
        require(name not in members and '..' not in PurePosixPath(name).parts and not name.startswith('/'), 'duplicate/unsafe member')
        info = fingerprint(path)
        require(expected_sha is None or info['sha256'] == expected_sha, 'source/tensor changed: ' + str(path))
        members[name] = (path, info)
        return info

    for relative, expected in sorted(source['overlay_sha256'].items()):
        path = selected / relative
        require(path.resolve(strict=True).is_relative_to(selected), 'overlay escapes selected source')
        add('sources/selected/' + relative, path, expected)
    cache_info = add('configuration/final-CMakeCache.txt', build / 'CMakeCache.txt')
    cache = (build / 'CMakeCache.txt').read_text()
    require('LUISA_COMPUTE_TILE_XIR_TEST_TIRX_COMPARISON:BOOL=OFF' in cache and
            'LUISA_COMPUTE_ENABLE_TILE_TIRX_BRIDGE:BOOL=ON' in cache, 'unexpected final test-linkage configuration')
    baseline_plan = read(raw / 'isolated-host-plan.json')
    export = Path(baseline_plan['baseline_export_receipt'])
    require(read(export) == source['baseline'], 'original and embedded baseline export differ')
    add('provenance/baseline-source-export.json', export)

    # Only exact tensor receipt paths below each explicitly named tensor root.
    # This never searches /tmp for old tensors and also retains failed cohorts.
    tensor_members, unavailable_tensors = {}, []
    for relative in sorted(files):
        if Path(relative).name != 'results.json':
            continue
        cohort = read(raw / relative)
        if not isinstance(cohort, dict) or 'temporary_tensor_root' not in cohort:
            continue
        root_declared = Path(cohort['temporary_tensor_root'])
        root_resolved = root_declared.resolve()
        for index, row in enumerate(cohort.get('results', [])):
            for original, expected in sorted(row.get('tensor_receipts', {}).items()):
                path = Path(original)
                if expected is None:
                    unavailable_tensors.append({'cohort': relative, 'row': index, 'original': original,
                                                'status': 'no tensor receipt; retained failure, not validated'})
                    continue
                require(path.is_relative_to(root_declared) and path.resolve(strict=True).is_relative_to(root_resolved),
                        'tensor escapes declared root')
                name = 'tensors/' + str(Path(relative).parent) + '/' + str(index) + '/' + path.relative_to(root_declared).as_posix()
                info = add(name, path, expected['sha256'])
                require(info['bytes'] == expected['bytes'], 'tensor byte count changed')
                tensor_members[name] = {'original': original, **info}

    probe = {'status': 'not_requested', 'note': 'All raw files are retained; no performance-completeness claim.'}
    if args.probe_output is not None:
        folder = (raw / args.probe_output).resolve(strict=True)
        require(folder.is_relative_to(raw), 'probe output must be below raw')
        plan, result = read(folder / 'probe-plan.json'), read(folder / 'probe-results.json')
        require(result['status'] == 'complete' and result['fingerprints_unchanged'] is True and
                len(result['rows']) == plan['visits'], 'probe is not complete')
        require(not (folder / 'probe-failure.json').exists(), 'failure receipt prevents complete-probe claim')
        after = read(folder / 'probe-fingerprints-after.json')
        require(after['unchanged'] is True and after['fingerprints_after'] == plan['fingerprints_before'], 'probe fingerprints differ')
        require(plan['source_receipt']['overlay_sha256'] == source['overlay_sha256'] and
                Path(plan['selected_source']).resolve() == selected, 'probe used different selected overlays')
        for original, expected in plan['fingerprints_before']['artifact_sha256'].items():
            require(fingerprint(Path(original), allow_symlink=True)['sha256'] == expected, 'frozen probe artifact changed')
            path = Path(original)
            if path.suffix == '.py' and not path.resolve().is_relative_to(raw):
                require(path.name in ('metal4_timing.py', 'compare_llm.py', 'run.py', 'repeat.py'), 'unexpected external probe helper')
                add('sources/probe-helpers/' + path.name, path, expected)
        probe = {'status': 'complete_as_recorded', 'directory': folder.relative_to(raw).as_posix(),
                 'visits': len(result['rows']), 'boundary': 'Packaging checks identity/completeness, not an independent numerical or statistical audit.'}

    # Final binaries and selected-bin runtime-library superset: no binary bytes
    # enter the archive. Historic fingerprints remain in their original logs.
    artifact_paths = [build / 'bin' / name for name in SUITES]
    if args.probe_output is not None:
        artifact_paths.append(build / 'bin/benchmark_tile_xir')
    artifact_paths += [path for path in (build / 'bin').iterdir()
                       if path.is_file() and path.suffix in ('.dylib', '.so', '.dll')]
    artifacts = {str(path): fingerprint(path, allow_symlink=True) for path in sorted(set(artifact_paths))}
    expected_members = {name: info for name, (_, info) in members.items()}
    filters = [{'id': lzma.FILTER_LZMA2, 'preset': 0, 'dict_size': 128 * 1024 * 1024}]
    archive_path = output / 'evidence.tar.xz'
    with archive_path.open('xb') as destination:
        with lzma.LZMAFile(destination, 'w', filters=filters) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                for name, (path, info) in sorted(members.items()):
                    entry = tarfile.TarInfo(name)
                    entry.size, entry.mode = info['bytes'], 0o644
                    with path.open('rb') as stream:
                        archive.addfile(entry, stream)
    require(collect_raw(raw) == (files, excluded), 'raw changed during packaging; preserve failed archive')
    for path, info in members.values():
        require(fingerprint(path) == info, 'archive input changed during packaging')
    for original, info in artifacts.items():
        require(fingerprint(Path(original), allow_symlink=True) == info, 'final artifact changed during packaging')
    actual = {}
    with tarfile.open(archive_path, 'r:xz') as archive:
        for entry in archive:
            path = PurePosixPath(entry.name)
            require(entry.isfile() and not path.is_absolute() and '..' not in path.parts and entry.name not in actual,
                    'unsafe/duplicate archive member')
            with archive.extractfile(entry) as stream:
                actual[entry.name] = {'bytes': entry.size, 'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}
    require(actual == expected_members, 'complete archive readback differs')
    archive_info = fingerprint(archive_path)
    manifest = {'schema': 'short-packet-reduction-evidence-v1', 'raw_root': str(raw),
                'selected_source': str(selected), 'source_receipt': str(receipt_path),
                'source_context_head_not_full_build': source['repository_head'],
                'baseline_exports': source['baseline'], 'overlay_count': len(OVERLAYS),
                'members': expected_members, 'member_count': len(members), 'raw_member_count': len(files),
                'excluded_raw': excluded, 'tensor_members': tensor_members,
                'unavailable_tensor_receipts': unavailable_tensors, 'terminal_receipts': receipts,
                'final_CMakeCache': cache_info, 'final_artifact_fingerprints': artifacts,
                'artifact_scope': 'Final five test-suite binaries, optional measured benchmark, and a selected-bin shared-library/plugin superset. Not observed loader closure; historic binary identities remain receipt data.',
                'probe': probe, 'archive': archive_info, 'raw_unchanged': True, 'full_readback_verified': True,
                'compression': {'codec': 'lzma2', 'preset': 0, 'dictionary_bytes': 128 * 1024 * 1024, 'threads': 1},
                'boundary': 'All completed raw failures retained, including parser/validation failures that are not themselves GPU failures. Ten final overlays plus receipt-bound probe helpers when applicable; not a full source/dependency rebuild. No build, native execution, numerical oracle, or benchmark rerun during packaging. Existing report-directory prose is outside the archive but included in top-level checksums.'}
    save(output / 'package-inventory.json', manifest)
    save(output / 'package-receipt.json', {'status': 'passed', 'started': started, 'finished': time.time(),
         'archive': archive_info, 'members': len(members), 'raw_members': len(files),
         'tensor_members': len(tensor_members), 'overlay_files': len(OVERLAYS),
         'full_readback_verified': True, 'raw_unchanged': True})
    with (output / 'SHA256SUMS').open('x') as stream:
        for path in sorted(output.iterdir()):
            if path.is_file() and path.name != 'SHA256SUMS':
                stream.write(fingerprint(path)['sha256'] + '  ' + path.name + '\n')
    print(json.dumps({'status': 'packaged', 'output': str(output), 'archive': archive_info,
                      'members': len(members), 'tensors': len(tensor_members), 'probe': probe}))


if __name__ == '__main__':
    main()

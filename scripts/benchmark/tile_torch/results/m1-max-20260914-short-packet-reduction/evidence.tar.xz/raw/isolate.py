"""Run the existing XIR host cases separately; retain budget aborts verbatim."""
import re
import time
from run import OUT, SELECTED, BUILD, BASE, run, save, digest

source = SELECTED / 'src/tests/unit/tile/bridge/test_xir.cpp'
names = re.findall(r'^\s*"([^"]+)"_test =', source.read_text(), re.MULTILINE)
assert len(names) == len(set(names)) == 20
baseline_bin = BASE.parent / 'build/bin'
baseline_files = [p for p in baseline_bin.iterdir() if p.is_file() and
                  (p.name == 'test_tile_xir' or p.suffix in ('.dylib', '.so'))]
baseline_before = {str(p): digest(p) for p in baseline_files}
save(OUT / 'isolated-host-plan.json', dict(started=time.time(), tests=names,
    selected_source_sha256=digest(source), baseline_artifacts_sha256=baseline_before,
    baseline_export_receipt='/tmp/luisa-metal-block-mapping.eI6JXf/source-export.json',
    boundary='Every original case is executed. Failures are retained and reproduced with the untouched baseline; '
             'run.py source_sha256 describes the current selected context, not the provenance of an older executable.'))
rows = []
for index, name in enumerate(names):
    folder = f'host-isolated-{index:02d}'
    try:
        run(folder, [str(BUILD / 'bin/test_tile_xir'), name], 120)
    except SystemExit:
        pass
    import json
    receipt = json.loads((OUT / folder / 'result.json').read_text())
    if 'interrupted' in receipt:
        raise RuntimeError(f'{name}: isolated check interrupted; do not continue')
    row = dict(name=name, result=folder + '/result.json', exit_code=receipt['exit_code'])
    if receipt['exit_code'] != 0:
        baseline = f'baseline-isolated-{index:02d}'
        try:
            run(baseline, [str(baseline_bin / 'test_tile_xir'), name], 120)
        except SystemExit:
            pass
        other = json.loads((OUT / baseline / 'result.json').read_text())
        if 'interrupted' in other:
            raise RuntimeError(f'{name}: baseline check interrupted')
        row.update(baseline_result=baseline + '/result.json', baseline_exit_code=other['exit_code'])
    rows.append(row)
baseline_after = {str(p): digest(p) for p in baseline_files}
save(OUT / 'isolated-host-results.json', dict(finished=time.time(), cases=rows,
    baseline_artifacts_unchanged=baseline_before == baseline_after,
    baseline_artifacts_sha256=baseline_after,
    passed=sum(row['exit_code'] == 0 for row in rows), failed=sum(row['exit_code'] != 0 for row in rows)))

"""Fixed short-row reduction comparison; prepare only until root authorizes GPU use.

Run under an external ``caffeinate -di`` after the named full build and all
three named test receipts pass. This driver never builds, tests, tunes, retries,
or selects a winner. It invokes the unmodified metal4_timing.py serially.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import signal
import statistics
import subprocess
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent
SELECTED = Path('/Users/mike/.cache/luisa-tile/metal-short-reduce.rq8Wsn/source')
BUILD = SELECTED.parent / 'build'
BINARY = BUILD / 'bin/benchmark_tile_xir'
HELPERS = ROOT / 'scripts/benchmark/tile_torch'
CASES = [(f'{op}-4096x{width}', op, (4096, width))
         for op in ('rmsnorm', 'masked_softmax') for width in (7, 31, 65)]
ORDER = [1, 32, 32, 1] * 2
BLOCK, SAMPLES, REPETITIONS = 256, 3, 16
METRICS = {
    f'{phase}_{name}': unit
    for phase in ('throughput', 'latency')
    for name, unit in (
        ('instrumented_dispatch_ns', 'ns'),
        ('feedback_only_command_buffer_ns_per_dispatch', 'ns'),
        ('host_wall_us_per_dispatch', 'us'))
}
HOST_BUDGET_FAILURES = {
    14: 'tile_xir_large_tiles_have_bounded_code_and_eager_load_snapshots',
    17: 'tile_xir_expansion_budget_is_fail_closed',
}
HOST_BUDGET_ERROR = 'XIR realization exceeds its static SSA expansion budget; choose smaller Tiles'
BASELINE = Path('/Users/mike/.cache/luisa-tile/metal-next.6pECu2')
METAL_SUITES = [
    'tile_xir_metal4_llm_ragged_rows_and_packet_mapping',
    'tile_xir_metal4_short_packet_reductions_seeds_and_snapshots',
    'tile_xir_metal4_packet_fill_is_a_valid_contribution',
    'tile_xir_metal4_bounded_wide_reduction_tails',
    'tile_xir_metal4_rope_complete_program_mapping',
    'tile_xir_metal4_resource_budget_rejects_fixed_and_admits_auto',
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    """Exclusive receipts: reruns must use a separately predeclared directory."""
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def fingerprint(paths):
    return {str(path): sha(path) for path in sorted(set(paths))}


def field(realization, name):
    values = re.findall(r'(?:^|;)\s*' + re.escape(name) + r'=([^;]+)', realization)
    require(len(values) == 1, f'expected exactly one realization field {name}')
    return values[0]


def run(name, command, timeout):
    """Retain stdout/stderr even if spawn, parsing, timeout or GPU work fails."""
    folder = OUT / name
    folder.mkdir()
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(('LUISA_', 'MTL_', 'DYLD_'))}
    env.update(PYTORCH_ENABLE_MPS_FALLBACK='0', OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
    receipt = dict(command=command, cwd=str(SELECTED), started=time.time(),
                   timeout_seconds=timeout, probe_sha256=sha(__file__),
                   removed_environment={key: value for key, value in os.environ.items()
                                        if key.startswith(('LUISA_', 'MTL_', 'DYLD_'))},
                   declared_environment={key: env[key] for key in
                                         ('PYTORCH_ENABLE_MPS_FALLBACK', 'OMP_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')})
    save(folder / 'command.json', receipt)
    process = None
    try:
        with (folder / 'stdout.txt').open('xb') as stdout, (folder / 'stderr.txt').open('xb') as stderr:
            process = subprocess.Popen(command, cwd=SELECTED, env=env, stdout=stdout,
                                       stderr=stderr, start_new_session=True)
            try:
                code = process.wait(timeout=timeout)
            except BaseException:
                # The immutable helper starts its native child in another
                # session. Give its KeyboardInterrupt handler a chance to kill
                # that group and retain the native receipts before escalation.
                try:
                    os.killpg(process.pid, signal.SIGINT)
                except ProcessLookupError:
                    pass
                receipt['cleanup_signal'] = 'SIGINT'
                try:
                    process.wait(timeout=15)
                except BaseException:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    process.wait()
                    receipt['cleanup_escalated'] = True
                receipt['queue_health'] = 'Not established after interruption; root must inspect before further GPU work.'
                raise
        require(code == 0, f'{name}: process exited {code}')
        receipt.update(status='passed', exit_code=code)
    except BaseException as error:
        receipt.update(status='failed', error=f'{type(error).__name__}: {error}',
                       exit_code=process.returncode if process is not None else None,
                       timed_out=isinstance(error, subprocess.TimeoutExpired))
        raise
    finally:
        receipt.update(finished=time.time(),
                       logs_sha256=fingerprint(path for path in
                                               (folder / 'stdout.txt', folder / 'stderr.txt') if path.exists()))
        save(folder / 'result.json', receipt)
    return (folder / 'stdout.txt').read_text()


def retained_receipt(path, role, overlays, expected_exit):
    path = path.resolve()
    require(path.is_relative_to(OUT) and path.name == 'result.json', f'{role}: expected a retained local result.json')
    result = json.loads(path.read_text())
    command = json.loads((path.parent / 'command.json').read_text())
    require(result.get('exit_code') == expected_exit and 'interrupted' not in result and not result.get('timed_out'),
            f'{role}: unexpected exit status or interrupted receipt')
    require(result.get('source_sha256') == overlays == command.get('source_sha256'),
            f'{role}: receipt was not run against the frozen overlay')
    require(result.get('command') == command.get('command') and result.get('cwd') == str(SELECTED),
            f'{role}: command/cwd receipt mismatch')
    require(isinstance(result.get('finished'), (int, float)) and
            result['finished'] >= result['started'], f'{role}: incomplete receipt')
    for channel in ('stdout', 'stderr'):
        require(sha(path.parent / f'{channel}.txt') == result[f'{channel}_sha256'],
                f'{role}: retained {channel} changed')
    return dict(path=str(path), receipt=result,
                files_sha256=fingerprint(path.parent / name for name in
                                         ('command.json', 'result.json', 'stdout.txt', 'stderr.txt')))


def validate_gate(path, role, overlays, *, scoped_host=False):
    gate = retained_receipt(path, role, overlays, 0)
    result = gate['receipt']
    path = Path(gate['path'])
    cmd = result['command']
    if role == 'full_build':
        require(len(cmd) >= 3 and Path(cmd[0]).name == 'cmake' and cmd[1:3] == ['--build', str(BUILD)]
                and '--target' not in cmd, 'full_build: must be a complete selected-tree build')
    else:
        expression, count = {
            'host_test': ('^test_tile_xir_(target_info|program_team)$', 2) if scoped_host else
                         ('^test_tile_xir(_target_info|_program_team)?$', 3),
            'metal_test': ('^test_tile_xir_metal$', 1),
            'simd_test': ('^test_tile_xir_runtime$', 1),
        }[role]
        require(Path(cmd[0]).name == 'ctest' and '--test-dir' in cmd and
                cmd[cmd.index('--test-dir') + 1] == str(BUILD) and '-R' in cmd and
                cmd[cmd.index('-R') + 1] == expression and '-V' in cmd and '--output-on-failure' in cmd,
                f'{role}: wrong predeclared CTest command')
        require(re.search(r'^100% tests passed(?:, 0 tests failed)? out of ' + str(count) + r'$',
                          (path.parent / 'stdout.txt').read_text(), re.MULTILINE),
                f'{role}: missing complete CTest success summary')
    gpu_diagnostics = None
    if role == 'metal_test':
        sys.path.insert(0, str(HELPERS))
        from compare_llm import gpu_failure_diagnostics
        gpu_diagnostics = gpu_failure_diagnostics((path.parent / 'stdout.txt').read_bytes(),
                                                  (path.parent / 'stderr.txt').read_bytes())
        require(not gpu_diagnostics, 'metal_test: GPU failure diagnostic despite process success')
    gate['gpu_failure_diagnostics'] = gpu_diagnostics
    return gate


def validate_host_amendment(overlays, source, full_build_finished):
    """Narrow, explicit pre-timing amendment; never label the full suite passed.

    Only two exact host code-expansion aborts are accepted, each independently
    reproduced by the unchanged baseline. Numeric/GPU failures are not waived.
    """
    isolated = OUT / 'postbuild3-host'
    inventory_path = isolated / 'isolated-host-plan.json'
    results_path = isolated / 'isolated-host-results.json'
    inventory = json.loads(inventory_path.read_text())
    results = json.loads(results_path.read_text())
    test_source = SELECTED / 'src/tests/unit/tile/bridge/test_xir.cpp'
    names = re.findall(r'^\s*"([^"]+)"_test =', test_source.read_text(), re.MULTILINE)
    require(len(names) == len(set(names)) == 20 and inventory['tests'] == names,
            'host amendment: original 20-name inventory mismatch')
    require(sha(test_source) == inventory['selected_source_sha256'] ==
            sha(BASELINE / 'source/src/tests/unit/tile/bridge/test_xir.cpp'),
            'host amendment: original test source was changed')
    require(inventory['started'] >= full_build_finished and results['finished'] >= inventory['started'],
            'host amendment: isolated tests must follow full build')
    require([row['name'] for row in results['cases']] == names and results['passed'] == 18 and results['failed'] == 2,
            'host amendment: missing, extra or unexpected isolated outcomes')
    baseline = inventory['baseline_artifacts_sha256']
    require(results['baseline_artifacts_unchanged'] is True and results['baseline_artifacts_sha256'] == baseline,
            'host amendment: baseline changed during reproductions')
    require(str(BASELINE / 'build/bin/test_tile_xir') in baseline and baseline and
            all(Path(path).is_relative_to(BASELINE / 'build/bin') for path in baseline),
            'host amendment: wrong baseline artifact paths')
    require(fingerprint(Path(path) for path in baseline) == baseline,
            'host amendment: baseline artifacts no longer match reproduction fingerprints')
    export_path = Path(inventory['baseline_export_receipt'])
    require(export_path == Path('/tmp/luisa-metal-block-mapping.eI6JXf/source-export.json') and
            json.loads(export_path.read_text()) == source['baseline'],
            'host amendment: baseline recursive export provenance mismatch')
    files = fingerprint([inventory_path, results_path, OUT / 'isolate.py', test_source,
                         BASELINE / 'source/src/tests/unit/tile/bridge/test_xir.cpp', export_path])
    files.update(baseline)
    original = retained_receipt(OUT / 'host-tests/result.json', 'original_full_host_failure', overlays, 8)
    require(original['receipt']['command'] == ['ctest', '--test-dir', str(BUILD), '-V',
            '--output-on-failure', '-R', '^test_tile_xir(_target_info|_program_team)?$'],
            'host amendment: wrong original full-host command')
    text = (OUT / 'host-tests/stdout.txt').read_text()
    require('67% tests passed, 1 tests failed out of 3' in text and
            re.search(r'test_tile_xir \(Subprocess aborted\)', text) and HOST_BUDGET_ERROR in text,
            'host amendment: original full-host failure changed')
    # This original failure is deliberately retained from build2. The actual
    # replacement gate is the complete postbuild3 inventory checked above.
    files.update(original['files_sha256'])
    checked = []
    for index, row in enumerate(results['cases']):
        name = names[index]
        expected = -6 if index in HOST_BUDGET_FAILURES else 0
        require(row['exit_code'] == expected and row['result'] == f'host-isolated-{index:02d}/result.json',
                f'host amendment: wrong outcome/path for {name}')
        if expected == -6:
            require(name == HOST_BUDGET_FAILURES[index] and row['baseline_exit_code'] == -6 and
                    row['baseline_result'] == f'baseline-isolated-{index:02d}/result.json',
                    f'host amendment: missing exact baseline reproduction for {name}')
        else:
            require('baseline_result' not in row, f'host amendment: unexpected waived case {name}')
        receipts = []
        for key, executable in [('result', BUILD / 'bin/test_tile_xir')] + (
                [('baseline_result', BASELINE / 'build/bin/test_tile_xir')] if expected == -6 else []):
            gate = retained_receipt(isolated / row[key], f'{name}:{key}', overlays, expected)
            receipt = gate['receipt']
            require(receipt['command'] == [str(executable), name] and
                    inventory['started'] <= receipt['started'] <= receipt['finished'] <= results['finished'],
                    f'host amendment: incorrect isolated command/time for {name}')
            text = '\n'.join((Path(gate['path']).parent / f'{channel}.txt').read_text()
                             for channel in ('stdout', 'stderr'))
            plain = re.sub(r'\x1b\[[0-9;]*m', '', text)
            errors = re.findall(r'\[error\]\s*([^\r\n]+)', plain)
            require('FAILED' not in plain, f'host amendment: assertion failure is not waived for {name}')
            if expected == -6:
                require(errors == [HOST_BUDGET_ERROR] and 'all tests passed' not in plain,
                        f'host amendment: only the exact budget SIGABRT is permitted for {name}')
            else:
                require(not errors and re.search(r"Suite 'global': all tests passed \([1-9][0-9]* asserts in 20 tests\)", plain)
                        and '19 tests skipped' in plain,
                        f'host amendment: missing positive isolated assertions for {name}')
            files.update(gate['files_sha256'])
            receipts.append(gate)
        checked.append(dict(name=name, status='KnownPreexistingHostBudgetAbort' if expected else 'Passed',
                            receipts=receipts))
    return dict(kind='explicit_pre_timing_host_gate_amendment', full_host_suite_passed=False,
                original_requirement='Full 3-suite host CTest pass', original_failure=original,
                original_failure_role='Retained pre-build3 diagnostic, not a post-build3 success receipt',
                replacement_requirement='Scoped target_info/program_team CTest pass plus all 20 original host tests '
                                        'individually checked: 18 pass, exactly 2 matching baseline budget SIGABRTs.',
                numerical_failures_waived=False, known_error=HOST_BUDGET_ERROR, checked=checked,
                baseline_provenance='Baseline executable/dependencies are bound by before/after reproduction hashes '
                                    'and pinned export receipt. run.py source_sha256 records the new selected cwd '
                                    'context, not the source provenance of the executed older binary.',
                files_sha256=files)


def validate_metal_amendment(original_path, overlays, full_build):
    """All six actual suites must pass; the aggregate CTest timeout stays failed."""
    isolated = OUT / 'metal-isolated-final-v4'
    plan_path = isolated / 'isolated-metal-plan.json'
    results_path = isolated / 'isolated-metal-results.json'
    plan = json.loads(plan_path.read_text())
    results = json.loads(results_path.read_text())
    source_path = SELECTED / 'src/tests/unit/tile/bridge/test_xir_metal.cpp'
    driver_path = OUT / 'metal_isolate_v4.py'
    binary = BUILD / 'bin/test_tile_xir_metal'
    cache = BUILD / 'CMakeCache.txt'
    expected_commands = [[str(binary), 'metal4', name, '--success'] for name in METAL_SUITES]
    require(plan['tests'] == METAL_SUITES ==
            re.findall(r'^\s*"([^"]+)"_test =', source_path.read_text(), re.MULTILINE),
            'Metal amendment: missing or changed six-suite source inventory')
    require(plan['source_sha256'] == overlays and plan['selected_source_sha256'] == sha(source_path) and
            plan['driver_sha256'] == sha(driver_path) and plan['runner_sha256'] == sha(OUT / 'run.py') and
            plan['gpu_diagnostic_helper_sha256'] == sha(HELPERS / 'compare_llm.py'),
            'Metal amendment: source/driver/helper fingerprints changed')
    require(Path(plan['full_build_result']).resolve() == Path(full_build['path']) and
            plan['full_build_sha256'] == sha(full_build['path']) and
            plan['full_build_finished'] == full_build['receipt']['finished'] <= plan['started'] and
            results['started'] == plan['started'] <= results['finished'],
            'Metal amendment: tests must follow the exact final full build')
    require(plan['binary'] == str(binary) and plan['binary_sha256'] == sha(binary) and
            plan['cmake_cache_sha256'] == sha(cache), 'Metal amendment: executable or configuration changed')
    require(plan['commands'] == expected_commands and plan['cwd'] == str(SELECTED) and
            plan['timeout_seconds_per_case'] == 600 and plan['serial'] is True and plan['retries'] == 0,
            'Metal amendment: wrong exact filters/backend/timeout or retry policy')
    require(results['plan_sha256'] == sha(plan_path) and results['complete'] is True and
            results['passed'] == 6 and results['failed'] == 0 and results['not_run'] == [] and results['error'] is None and
            [row['name'] for row in results['cases']] == METAL_SUITES and
            plan['full_metal_ctest_passed'] is False and results['full_metal_ctest_passed'] is False,
            'Metal amendment: all six isolated suites must pass; no numerical exceptions or dropped cases')
    require(original_path.resolve() == (OUT / 'metal-tests/result.json').resolve() ==
            Path(plan['original_ctest_result']).resolve() and plan['original_ctest_sha256'] == sha(original_path),
            'Metal amendment: wrong retained aggregate failure')
    original = retained_receipt(original_path, 'original_full_metal_timeout', overlays, 8)
    require(original['receipt']['command'] == ['ctest', '--test-dir', str(BUILD), '-V',
            '--output-on-failure', '-R', '^test_tile_xir_metal$'], 'Metal amendment: wrong aggregate command')
    original_stdout = original_path.parent / 'stdout.txt'
    require('0% tests passed, 1 tests failed out of 1' in original_stdout.read_text() and
            'test_tile_xir_metal (Timeout)' in original_stdout.read_text(),
            'Metal amendment: expected the retained aggregate CTest timeout, not another failure')
    # Import only the frozen driver's host-side summary parser; its main/native
    # runner is not invoked. This is the same strict parser used at capture time.
    spec = importlib.util.spec_from_file_location('short_reduction_metal_gate', driver_path)
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    require(driver.NAMES == METAL_SUITES, 'Metal amendment: summary parser inventory drift')
    sys.path.insert(0, str(HELPERS))
    from compare_llm import gpu_failure_diagnostics
    original_diagnostics = gpu_failure_diagnostics(original_stdout.read_bytes(),
                                                   (original_path.parent / 'stderr.txt').read_bytes())
    require(not original_diagnostics, 'Metal amendment: aggregate GPU faults are not waived by this timeout amendment')
    files = fingerprint([plan_path, results_path, source_path, driver_path, OUT / 'run.py',
                         HELPERS / 'compare_llm.py', binary, cache])
    files.update(original['files_sha256'])
    checked, previous_finished = [], plan['started']
    for index, row in enumerate(results['cases']):
        folder = isolated / f'metal-isolated-{index:02d}'
        require(Path(row['result']).resolve() == (folder / 'result.json').resolve() and
                row['status'] == 'passed' and row['exit_code'] == 0 and row['timed_out'] is False and
                not row['gpu_failure_diagnostics'] and 'execution_error' not in row and 'validation_error' not in row,
                f"Metal amendment: failed or wrong per-suite result for {row['name']}")
        gate = retained_receipt(folder / 'result.json', row['name'], overlays, 0)
        receipt = gate['receipt']
        require(receipt['command'] == expected_commands[index] and receipt['native'] is True and
                receipt['timeout_seconds'] == 600 and
                previous_finished <= receipt['started'] <= receipt['finished'] <= results['finished'],
                f"Metal amendment: exact command/serial chronology mismatch for {row['name']}")
        require(row['result_sha256'] == sha(folder / 'result.json') and
                json.loads((folder / 'validation.json').read_text()) == row,
                f"Metal amendment: validation receipt drift for {row['name']}")
        stdout, stderr = (folder / 'stdout.txt').read_bytes(), (folder / 'stderr.txt').read_bytes()
        require(not gpu_failure_diagnostics(stdout, stderr),
                f"Metal amendment: GPU fault despite zero exit code in {row['name']}")
        summary = driver.validate_summary(stdout.decode(errors='replace'), row['name'])
        require(row['summary'] == summary, f"Metal amendment: positive named assertions missing for {row['name']}")
        previous_finished = receipt['finished']
        files.update(gate['files_sha256'])
        files.update(fingerprint([folder / 'validation.json']))
        checked.append(dict(name=row['name'], summary=summary, receipt=gate))
    # Parser-only failed attempts are diagnostics, not pieces of the final
    # validation gate. V4 reran every suite; no successful rows are stitched.
    parser_diagnostics = []
    parser_attempts = [
        ('metal-isolated-final', 'metal_isolate_v1.py', 1,
         'ValueError: missing/duplicate/reordered named test outcome; --success is required'),
        ('metal-isolated-final-v2', 'metal_isolate_v2.py', 6,
         'ValueError: missing/duplicate/reordered named test outcome; --success is required'),
        ('metal-isolated-final-v3', 'metal_isolate_v3.py', 1,
         'ValueError: missing unique positive-assertion six-registered-test success summary'),
    ]
    for directory, old_driver_name, count, expected_error in parser_attempts:
        old_folder = OUT / directory
        old_plan_path = old_folder / 'isolated-metal-plan.json'
        old_results_path = old_folder / 'isolated-metal-results.json'
        old_plan = json.loads(old_plan_path.read_text())
        old_results = json.loads(old_results_path.read_text())
        require(old_results['complete'] is False and old_results['error'] == expected_error and
                len(old_results['cases']) == count and old_results['failed'] == 1 and
                old_results['not_run'] == METAL_SUITES[count:] and old_results['finished'] <= plan['started'],
                f'Metal amendment: unexpected historical parser outcome in {directory}')
        require(old_results['plan_sha256'] == sha(old_plan_path) and old_plan['tests'] == METAL_SUITES and
                old_plan['source_sha256'] == overlays and old_plan['binary_sha256'] == plan['binary_sha256'] and
                old_plan['cmake_cache_sha256'] == plan['cmake_cache_sha256'] and
                old_plan['driver_sha256'] == sha(OUT / old_driver_name),
                f'Metal amendment: historical parser provenance drift in {directory}')
        corrections = []
        for index, old_row in enumerate(old_results['cases']):
            old_case = old_folder / f'metal-isolated-{index:02d}'
            require(old_row['name'] == METAL_SUITES[index] and old_row['exit_code'] == 0 and
                    old_row['timed_out'] is False and not old_row['gpu_failure_diagnostics'] and
                    old_row['result_sha256'] == sha(old_case / 'result.json') and
                    json.loads((old_case / 'validation.json').read_text()) == old_row,
                    f'Metal amendment: historical native failure is not a parser waiver in {directory}')
            old_gate = retained_receipt(old_case / 'result.json', f'{directory}:{old_row["name"]}', overlays, 0)
            require(old_gate['receipt']['command'] == expected_commands[index],
                    f'Metal amendment: historical native filter changed in {directory}')
            old_stdout, old_stderr = (old_case / 'stdout.txt').read_bytes(), (old_case / 'stderr.txt').read_bytes()
            require(not gpu_failure_diagnostics(old_stdout, old_stderr),
                    f'Metal amendment: historical GPU fault is not a parser waiver in {directory}')
            correction = driver.validate_summary(old_stdout.decode(errors='replace'), old_row['name'])
            corrections.append(dict(name=old_row['name'], original_status=old_row['status'],
                                    v4_read_only_summary=correction))
            files.update(old_gate['files_sha256'])
            files.update(fingerprint([old_case / 'validation.json']))
        files.update(fingerprint([old_plan_path, old_results_path, OUT / old_driver_name]))
        parser_diagnostics.append(dict(directory=str(old_folder), original_results=old_results,
            classification='Retained parser-validation failure; native processes exited zero with positive '
                           'assertions and no GPU diagnostics. Not part of the final six-suite pass gate.',
            read_only_reparse=corrections))
    return dict(kind='explicit_pre_timing_isolated_metal_gate_amendment', path=str(results_path.resolve()),
                receipt=results, full_metal_ctest_passed=False, original_failure=original,
                original_requirement='Full aggregate Metal CTest pass within its 240-second limit',
                replacement_requirement='All six unchanged suites pass individually after the final full build; '
                                        'exact Metal4 filter, positive named assertions, 600-second per-suite limit, '
                                        'same frozen executable/configuration/source, no GPU diagnostics.',
                numerical_failures_waived=False, checked=checked, parser_attempt_diagnostics=parser_diagnostics,
                files_sha256=files)


def verify_caffeinate():
    ancestors, pid = [], os.getpid()
    for index in range(32):
        text = run(f'power-ancestor-{index:02d}', ['/bin/ps', '-p', str(pid), '-o', 'ppid=', '-o', 'command='], 5)
        values = text.strip().split(maxsplit=1)
        require(len(values) == 2, f'cannot inspect process ancestor {pid}')
        ancestors.append(dict(pid=pid, ppid=int(values[0]), command=values[1]))
        pid = int(values[0])
        if pid <= 1:
            break
    # macOS can exec the utility in caffeinate's original process and keep the
    # assertion monitor as a child. Accept either that direct child or a wrapper
    # ancestor, never an unrelated machine-wide caffeinate assertion.
    candidates = []
    pids = run('power-caffeinate-pids', ['/usr/bin/pgrep', '-x', 'caffeinate'], 5)
    for value in pids.split():
        candidate = int(value)
        text = run(f'power-caffeinate-{candidate}',
                   ['/bin/ps', '-p', str(candidate), '-o', 'ppid=', '-o', 'command='], 5)
        parent, command = text.strip().split(maxsplit=1)
        candidates.append(dict(pid=candidate, ppid=int(parent), command=command))
    assertions = run('power-assertions', ['/usr/bin/pmset', '-g', 'assertions'], 5)
    ancestor_ids = {entry['pid'] for entry in ancestors}
    attached = [entry for entry in candidates if entry['pid'] in ancestor_ids or entry['ppid'] == os.getpid()]
    active = [entry for entry in attached if any(
        re.search(r'pid\s+' + str(entry['pid']) + r'\(caffeinate\)', line) and
        'PreventUserIdleSystemSleep' in line for line in assertions.splitlines())]
    require(active, 'run this driver directly under external caffeinate -di; no attached active -i assertion found')
    return dict(ancestors=ancestors, caffeinate_candidates=candidates, attached_active_caffeinate=active,
                required_assertion='PreventUserIdleSystemSleep (-i); no synthetic user activity (-u) required',
                external_caffeinate_verified=True,
                assertions_receipt='power-assertions/result.json')


def pairs_for(rows):
    """Four predeclared, nonoverlapping adjacent pairs per case; never re-pair."""
    indexed = {(row['case'], row['position']): row for row in rows}
    pairs = []
    for case, _, _ in CASES:
        for first in range(0, len(ORDER), 2):
            if (case, first) not in indexed or (case, first + 1) not in indexed:
                continue
            left, right = indexed[case, first], indexed[case, first + 1]
            a, b = (left, right) if left['actual_local_lanes'] == 1 else (right, left)
            require((a['actual_local_lanes'], b['actual_local_lanes']) == (1, 32), 'invalid adjacent pair')
            pairs.append(dict(case=case, positions=[first, first + 1],
                              visit_order=[left['actual_local_lanes'], right['actual_local_lanes']],
                              metric_ratios_local32_over_local1={
                                  name: b['metrics'][name]['median'] / a['metrics'][name]['median'] for name in METRICS}))
    return pairs


def pair_report(rows, complete, fingerprint_valid):
    pairs = pairs_for(rows)
    summary = []
    for case, _, _ in CASES:
        selected = [pair for pair in pairs if pair['case'] == case]
        if not selected:
            continue
        for metric, unit in METRICS.items():
            ratios = [pair['metric_ratios_local32_over_local1'][metric] for pair in selected]
            summary.append(dict(case=case, metric=metric, original_metric_unit=unit,
                                paired_ratios=ratios, pair_count=len(ratios),
                                median_ratio=statistics.median(ratios), min_ratio=min(ratios), max_ratio=max(ratios)))
    return dict(cohort_complete=complete, fingerprint_valid=fingerprint_valid, pairs=pairs, summary=summary,
                ratio_definition='candidate local32 visit median / baseline local1 visit median; <1 means local32 lower time',
                inference='Descriptive complete adjacent pairs only; no winner selection, confidence interval or tuning. '
                          'Partial-cohort pairs are retained diagnostics, not a complete-cohort claim.',
                timing_boundary='Six metrics stay separate: throughput/latency × instrumented dispatch interval, '
                                'feedback-only command-buffer GPU time per dispatch, synchronized host wall per dispatch. '
                                'Instrumented dispatch intervals are not pure zero-overhead kernel times.')


def parse_arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-receipt', type=Path, default=OUT / 'source-namespace-fix.json')
    parser.add_argument('--accept-known-host-budget-aborts', action='store_true',
                        help='explicit pre-timing amendment for exactly 2 baseline-reproduced host budget aborts; '
                             'uses the final scoped-host default; no numeric failures waived')
    parser.add_argument('--accept-isolated-metal-suites', action='store_true',
                        help='explicitly replace the failed aggregate Metal timeout gate with all six retained '
                             'post-build3 individual suite passes; the aggregate CTest remains failed')
    for role, folder in (('full-build', 'build-full-3'), ('host-test', 'host-scoped-tests-final'),
                         ('metal-test', 'metal-tests'), ('simd-test', 'simd-tests-final')):
        parser.add_argument(f'--{role}-receipt', type=Path, default=OUT / folder / 'result.json')
    return parser.parse_args()


def main():
    args = parse_arguments()
    require(not any((OUT / name).exists() for name in
                    ('probe-plan.json', 'probe-results.json', 'probe-pairs.json', 'probe-failure.json')),
            'this predeclared cohort directory already contains probe results; never overwrite or retry it')
    rows, matching_inputs, same_arm_outputs, same_arm_structures, same_arm_checksums = [], {}, {}, {}, {}
    fixed_settings = {}
    before, source_paths, artifact_paths = None, [], []
    case, position = None, None
    try:
        source = json.loads(args.source_receipt.read_text())
        require(source['selected_source'] == str(SELECTED), 'wrong selected source receipt')
        overlays = source['overlay_sha256']
        require(overlays and all(sha(SELECTED / path) == value for path, value in overlays.items()),
                'selected overlay differs from source freeze')
        gates = {role: validate_gate(getattr(args, role + '_receipt'), role, overlays,
                                    scoped_host=args.accept_known_host_budget_aborts)
                 for role in ('full_build', 'host_test', 'simd_test')}
        gates['metal_test'] = (validate_metal_amendment(args.metal_test_receipt, overlays, gates['full_build'])
                               if args.accept_isolated_metal_suites else
                               validate_gate(args.metal_test_receipt, 'metal_test', overlays))
        host_amendment = (validate_host_amendment(overlays, source, gates['full_build']['receipt']['finished'])
                          if args.accept_known_host_budget_aborts else None)
        configure = retained_receipt(OUT / 'configure-no-tirx-comparison/result.json',
                                     'test_linkage_configuration', overlays, 0)
        require(configure['receipt']['command'] == ['cmake', '-S', str(SELECTED), '-B', str(BUILD),
                '-DLUISA_COMPUTE_TILE_XIR_TEST_TIRX_COMPARISON=OFF'] and
                configure['receipt']['finished'] <= gates['full_build']['receipt']['started'],
                'final build must follow the explicitly retained test-linkage reconfiguration')
        cache = (BUILD / 'CMakeCache.txt').read_text()
        require('LUISA_COMPUTE_TILE_XIR_TEST_TIRX_COMPARISON:BOOL=OFF' in cache and
                'LUISA_COMPUTE_ENABLE_TILE_TIRX_BRIDGE:BOOL=ON' in cache,
                'expected isolated XIR tests with the standalone TIRx bridge still enabled')
        prior_build = validate_gate(OUT / 'build-full-2/result.json', 'full_build', overlays)
        require(len({gate['path'] for gate in gates.values()}) == 4, 'the four gates must be distinct named receipts')
        require(BINARY.is_file() and os.access(BINARY, os.X_OK), 'new selected benchmark is not executable')
        require(all(gates[role]['receipt']['started'] >= gates['full_build']['receipt']['finished']
                    for role in ('host_test', 'metal_test', 'simd_test')), 'tests must follow the named full build')
        # First-party source contents, including headers and tests, not just overlays.
        # External recursive exports remain identified by the pinned source receipt.
        source_paths = [path for name in ('src', 'include', 'cmake') for path in (SELECTED / name).rglob('*')
                        if path.is_file() and not path.is_relative_to(SELECTED / 'src/ext')]
        source_paths += [SELECTED / 'CMakeLists.txt', args.source_receipt.resolve(), OUT / 'run.py']
        artifact_paths = [path for path in (BUILD / 'bin').iterdir() if path.is_file() and
                          (path.suffix in ('.dylib', '.so', '.dll') or path == BINARY)]
        artifact_paths += [Path(__file__).resolve(), Path(sys.executable).resolve(), *[HELPERS / name for name in
                           ('metal4_timing.py', 'compare_llm.py', 'run.py', 'repeat.py')],
                           *[BUILD / name for name in ('CMakeCache.txt', 'compile_commands.json', 'build.ninja')]]
        for gate in gates.values():
            artifact_paths += [Path(path) for path in gate['files_sha256']]
        artifact_paths += [Path(path) for gate in (configure, prior_build) for path in gate['files_sha256']]
        if host_amendment is not None:
            artifact_paths += [Path(path) for path in host_amendment['files_sha256']]
        before = dict(source_sha256=fingerprint(source_paths), artifact_sha256=fingerprint(artifact_paths))
        power = verify_caffeinate()
        save(OUT / 'probe-plan.json', dict(started=time.time(), selected_source=str(SELECTED), binary=str(BINARY),
            source_receipt=source, gates=gates, fingerprints_before=before, power=power,
            host_gate_amendment=host_amendment, full_host_suite_passed=host_amendment is None,
            full_metal_ctest_passed=not args.accept_isolated_metal_suites,
            test_linkage_configuration=configure, prior_full_build_diagnostic=prior_build,
            test_linkage_scope='Existing in-process XIR-test TIRx comparison is disabled to isolate LLVM versions; '
                               'standalone TIRx bridge remains enabled. Both measured arms use the same final binary.',
            source_fingerprint_scope='First-party src excluding src/ext, include, cmake and top-level CMake; '
                                     'external submodules use pinned recursive export identities in source_receipt.',
            cases=CASES, local_lanes_order=ORDER, visits=48, samples=SAMPLES, repetitions=REPETITIONS,
            block_size=BLOCK, math='FP32, fast_math=false, relaxed_precision=false',
            timing='Six independent throughput/latency metrics; no pure zero-overhead kernel-time claim.',
            validation='Every visit: full exported input/output SHA receipts, independent NumPy FP64 reference, '
                       'producer full-output/guard validation; same inputs across arms; bitwise output stability '
                       'only within one lanes arm. Cross-arm unordered reduction reassociation is allowed.',
            pairing='Two ABBA cycles per case: adjacent (0,1),(2,3),(4,5),(6,7), candidate local32/baseline local1 ratio.',
            freeze='No build, source edit, concurrent benchmark, retry, candidate search or old-baseline mutation.'))
        for case, operation, dimensions in CASES:
            for position, lanes in enumerate(ORDER):
                tag = f'probe-{case}-{position:02d}-lanes{lanes}'
                output = OUT / tag / 'cohort'
                command = [sys.executable, str(HELPERS / 'metal4_timing.py'), '--binary', str(BINARY),
                           '--case', operation + ':' + ','.join(map(str, dimensions)), '--attention-block', '1', '1',
                           '--local-lanes', str(lanes), '--block-size', str(BLOCK), '--rounds', '1',
                           '--samples', str(SAMPLES), '--repetitions', str(REPETITIONS), '--timeout', '60',
                           '--output', str(output)]
                run(tag, command, 90)
                report = json.loads((output / 'results.json').read_text())
                require(report['cohort_valid'] and report['artifacts_unchanged'] and len(report['results']) == 1,
                        f'{tag}: helper cohort failed')
                row = report['results'][0]
                require(row['valid'] and row['status'] == 'OK' and row['actual_local_lanes'] == lanes and
                        row['requested_local_lanes'] == lanes, f'{tag}: wrong local lane realization')
                require(row['operation'] == operation and row['dimensions'] == list(dimensions),
                        f'{tag}: wrong case identity')
                require(row['requested_block_size'] == BLOCK == row['actual_block_size'], f'{tag}: wrong block')
                payload = json.loads((output / row['stdout']).read_text())
                dispatch = [dimensions[0] * lanes, 1, 1]
                require(payload['dispatch'] == dispatch, f'{tag}: expected rows * lanes dispatch')
                require(payload['fast_math'] is False and payload['relaxed_precision'] is False and
                        payload['precision'] == 'fp32', f'{tag}: numerical mode changed')
                sample = payload['device_timing']['throughput'][0]['dispatches'][0]
                require(sample['block_size'] == [BLOCK, 1, 1], f'{tag}: wrong actual block geometry')
                key = case, lanes
                require(same_arm_checksums.setdefault(key, sample['shader_checksum']) == sample['shader_checksum'],
                        f'{tag}: same-arm shader checksum changed')
                require(same_arm_structures.setdefault(key, row['realization']) == row['realization'],
                        f'{tag}: same-arm realization changed')
                require(field(row['realization'], 'local_lanes') == str(lanes), f'{tag}: wrong realization lanes')
                # These are fixed policy inputs, not per-arm resource/cost or
                # optimization-result counters, which may legitimately differ.
                settings = {name: field(row['realization'], name) for name in
                            ('max_unrolled_tile_elements', 'max_unrolled_region_work',
                             'unordered_reduction_partitions', 'fast_math', 'ordered_reduction', 'strict_mma')}
                order = re.findall(r'; root order (\[[^]]*\])', row['realization'])
                require(len(order) == 1, f'{tag}: missing root order')
                settings['root_order'] = order[0]
                require(fixed_settings.setdefault(case, settings) == settings,
                        f'{tag}: fixed policy settings changed across lanes arms')
                tensor = row['command'][-1]
                tensor_hashes = {path: receipt['sha256'] for path, receipt in row['tensor_receipts'].items()}
                require(all(sha(path) == value for path, value in tensor_hashes.items()), f'{tag}: export changed')
                inputs = [tensor_hashes[tensor + f'.input{i}.f32'] for i in range(3)]
                require(matching_inputs.setdefault(case, inputs) == inputs, f'{tag}: inputs changed between visits')
                require(same_arm_outputs.setdefault(key, tensor_hashes[tensor]) == tensor_hashes[tensor],
                        f'{tag}: same-arm output is not bitwise repeatable')
                require(set(row['metrics']) == set(METRICS), f'{tag}: unexpected timing metrics')
                for metric in row['metrics'].values():
                    require(len(metric['samples']) == SAMPLES and math.isfinite(metric['median']) and
                            metric['median'] > 0, f'{tag}: invalid metric')
                rows.append(dict(case=case, position=position, operation=operation, dimensions=dimensions,
                    actual_local_lanes=lanes, block_size=BLOCK, dispatch=dispatch,
                    threadgroups=math.ceil(dispatch[0] / BLOCK), result=str(output / 'results.json'),
                    realization=row['realization'], shader_checksum=sample['shader_checksum'],
                    correctness=row['correctness'], independent_correctness=row['independent_correctness'],
                    tensor_receipts=row['tensor_receipts'], metrics=row['metrics']))
                save(OUT / tag / 'validated.json', rows[-1])
                print(json.dumps(dict(case=case, position=position, lanes=lanes,
                                      completed_visits=len(rows), expected_visits=48)), flush=True)
        after = dict(source_sha256=fingerprint(source_paths), artifact_sha256=fingerprint(artifact_paths))
        unchanged = after == before
        save(OUT / 'probe-fingerprints-after.json', dict(fingerprints_after=after, unchanged=unchanged))
        require(unchanged, 'source/build/helper/gate fingerprints changed during cohort')
        require(len(rows) == 48, 'incomplete cohort')
        save(OUT / 'probe-pairs.json', pair_report(rows, True, True))
        save(OUT / 'probe-results.json', dict(status='complete', finished=time.time(), rows=rows,
                                             fingerprints_unchanged=True, pairs='probe-pairs.json',
                                             full_host_suite_passed=host_amendment is None,
                                             full_metal_ctest_passed=not args.accept_isolated_metal_suites,
                                             host_gate_amendment='probe-plan.json:host_gate_amendment'))
    except BaseException as error:
        after, fingerprint_error = None, None
        if before is not None:
            try:
                after = dict(source_sha256=fingerprint(source_paths), artifact_sha256=fingerprint(artifact_paths))
            except BaseException as changed:
                fingerprint_error = f'{type(changed).__name__}: {changed}'
        save(OUT / 'probe-failure.json', dict(status='incomplete', finished=time.time(), case=case, position=position,
            error=f'{type(error).__name__}: {error}', completed_rows=rows, fingerprints_after=after,
            fingerprint_error=fingerprint_error,
            pairing=pair_report(rows, False, before is not None and after == before),
            boundary='Stop on first error; all subprocess/native helper logs and full tensor exports are retained. '
                     'No retry, survivor-based winner selection or implicit repair. After interruption, timeout or '
                     'GPU diagnostics, queue/process health is not established; root must inspect before further GPU work.'))
        raise


if __name__ == '__main__':
    main()

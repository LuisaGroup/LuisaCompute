"""Run all six frozen Metal suites serially, never masking a prior failure.

Prepared only: root owns execution after the selected full build and GPU health
check. Each suite gets 600 seconds; any fault, crash, timeout or invalid summary
stops this cohort. The old aggregate CTest timeout remains a failed receipt.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import sys
import time

RAW = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('metal_receipt_runner', RAW / 'run.py')
RUNNER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUNNER)
HELPERS = RUNNER.ROOT / 'scripts/benchmark/tile_torch'
sys.path.insert(0, str(HELPERS))
from compare_llm import gpu_failure_diagnostics

NAMES = [
    'tile_xir_metal4_llm_ragged_rows_and_packet_mapping',
    'tile_xir_metal4_short_packet_reductions_seeds_and_snapshots',
    'tile_xir_metal4_packet_fill_is_a_valid_contribution',
    'tile_xir_metal4_bounded_wide_reduction_tails',
    'tile_xir_metal4_rope_complete_program_mapping',
    'tile_xir_metal4_resource_budget_rejects_fixed_and_admits_auto',
]
INVENTORY_REGEX = r'^\s*"([^"]+)"_test ='
TIMEOUT = 600
ANSI = re.compile(r'\x1b\[[0-9;]*m')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text())


def validate_summary(stdout, name):
    """This vendored UT counts filtered skips in its six registered tests."""
    text = ANSI.sub('', stdout)
    summaries = re.findall(r"Suite 'global': all tests passed \((\d+) asserts in (\d+) tests\)", text)
    require(len(summaries) == 1 and int(summaries[0][0]) > 0 and int(summaries[0][1]) == len(NAMES),
            'missing unique positive-assertion six-registered-test success summary')
    require(re.findall(r'^(\d+) tests skipped$', text, re.MULTILINE) == ['5'],
            'expected exactly five filtered-out tests')
    outcomes = re.findall(r'^Running(?: test)?\s+"([^"]+)"\.\.\.\s+(PASSED|SKIPPED)(?=\s|Suite \'global\':|$)', text, re.MULTILINE)
    require(len(outcomes) == len(NAMES) and [item[0] for item in outcomes] == NAMES,
            'missing/duplicate/reordered named test outcome; --success is required')
    require(outcomes == [(item, 'PASSED' if item == name else 'SKIPPED') for item in NAMES],
            'exactly the requested test must pass and every other test must be filtered out')
    require(not re.search(r'\bFAILED\b|Unexpected exception|early abort for test', text),
            'assertion/exception failure in retained output')
    return dict(assertions=int(summaries[0][0]), registered_tests=len(NAMES),
                filtered_out_tests=5, executed_tests=1, passed_tests=1)


def check_build(path, sources):
    result = load(path)
    command = load(path.parent / 'command.json')
    argv = result.get('command', [])
    require(result.get('exit_code') == 0 and not result.get('timed_out') and 'interrupted' not in result,
            'selected full build failed or was interrupted')
    require(argv == command.get('command') and len(argv) >= 3 and Path(argv[0]).name == 'cmake'
            and argv[1:3] == ['--build', str(RUNNER.BUILD)] and '--target' not in argv,
            'full-build gate must be a complete selected-tree build')
    require(result.get('cwd') == command.get('cwd') == str(RUNNER.SELECTED), 'full-build cwd mismatch')
    require(result.get('source_sha256') == command.get('source_sha256') == sources,
            'selected overlay differs from completed full build')
    require(result.get('harness_sha256') == command.get('harness_sha256') == RUNNER.digest(RAW / 'run.py'),
            'build receipt runner changed')
    require(result.get('finished', 0) >= result.get('started', float('inf')) and result['finished'] <= time.time(),
            'full-build receipt has no completed chronology')
    for channel in ('stdout', 'stderr'):
        require(RUNNER.digest(path.parent / f'{channel}.txt') == result.get(f'{channel}_sha256'),
                f'full-build {channel} receipt changed')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-receipt', type=Path, default=RAW / 'build-full-3/result.json')
    parser.add_argument('--output-dir', type=Path, default=RAW / 'metal-isolated-final')
    args = parser.parse_args()
    output = args.output_dir.resolve()
    require(output.is_relative_to(RAW) and output != RAW, 'use a fresh child directory of this raw cohort')
    require(not output.exists(), 'exclusive output directory already exists; no implicit retry/overwrite')
    source = RUNNER.SELECTED / 'src/tests/unit/tile/bridge/test_xir_metal.cpp'
    names = re.findall(INVENTORY_REGEX, source.read_text(), re.MULTILINE)
    require(names == NAMES and len(set(names)) == 6, 'frozen six-suite source inventory changed')
    sources = {path: RUNNER.digest(RUNNER.SELECTED / path) for path in RUNNER.OVERLAYS}
    build_path = args.build_receipt.resolve()
    require(build_path.is_relative_to(RAW) and build_path.name == 'result.json', 'build gate must be retained locally')
    build = check_build(build_path, sources)
    cache = RUNNER.BUILD / 'CMakeCache.txt'
    require(re.findall(r'^LUISA_COMPUTE_TILE_XIR_TEST_TIRX_COMPARISON:BOOL=(.*)$', cache.read_text(), re.MULTILINE)
            == ['OFF'], 'in-process TIRx comparison must be disabled in this selected configuration')
    binary = RUNNER.BUILD / 'bin/test_tile_xir_metal'
    output.mkdir()
    RUNNER.OUT = output
    started = time.time()
    plan = dict(started=started, tests=NAMES, inventory_regex=INVENTORY_REGEX,
                timeout_seconds_per_case=TIMEOUT, serial=True, retries=0,
                selected_source_sha256=RUNNER.digest(source), source_sha256=sources,
                driver_sha256=RUNNER.digest(__file__), runner_sha256=RUNNER.digest(RAW / 'run.py'),
                gpu_diagnostic_helper_sha256=RUNNER.digest(HELPERS / 'compare_llm.py'),
                full_build_result=str(build_path), full_build_sha256=RUNNER.digest(build_path),
                full_build_finished=build['finished'], binary=str(binary), binary_sha256=RUNNER.digest(binary),
                cmake_cache_sha256=RUNNER.digest(cache), cwd=str(RUNNER.SELECTED),
                commands=[[str(binary), 'metal4', name, '--success'] for name in NAMES],
                original_ctest_result=str(RAW / 'metal-tests/result.json'),
                original_ctest_sha256=RUNNER.digest(RAW / 'metal-tests/result.json'),
                full_metal_ctest_passed=False,
                scope='All six frozen test registrations, no dropped subcases. Per-suite filtered execution '
                      'after the aggregate 240-second CTest timeout; not a performance measurement.',
                safety='Stop on any failure. Process cleanup does not establish GPU queue health; '
                       'root inspection is required before any subsequent native work.')
    RUNNER.save(output / 'isolated-metal-plan.json', plan)
    rows = []
    failure = None
    try:
        for index, name in enumerate(NAMES):
            folder = output / f'metal-isolated-{index:02d}'
            row = dict(name=name, result=str(folder / 'result.json'), status='Error')
            rows.append(row)
            try:
                RUNNER.run(folder.name, plan['commands'][index], TIMEOUT, native=True)
            except BaseException as error:
                row['execution_error'] = f'{type(error).__name__}: {error}'
            require((folder / 'result.json').is_file(), 'native process did not produce a completion receipt')
            result = load(folder / 'result.json')
            stdout = (folder / 'stdout.txt').read_bytes()
            stderr = (folder / 'stderr.txt').read_bytes()
            row.update(exit_code=result.get('exit_code'), timed_out=result.get('timed_out', False),
                       gpu_failure_diagnostics=gpu_failure_diagnostics(stdout, stderr),
                       result_sha256=RUNNER.digest(folder / 'result.json'))
            require(result.get('command') == plan['commands'][index] and result.get('cwd') == str(RUNNER.SELECTED)
                    and result.get('timeout_seconds') == TIMEOUT and result.get('native') is True,
                    'native command receipt drift')
            require(result.get('source_sha256') == sources and result.get('started', 0) >= build['finished'],
                    'source or full-build chronology drift')
            require(result.get('exit_code') == 0 and not row['timed_out'] and 'interrupted' not in result
                    and 'execution_error' not in row, 'native test crashed, timed out or was interrupted')
            require(not row['gpu_failure_diagnostics'], 'GPU fault diagnostic despite possible zero exit status')
            row['summary'] = validate_summary(stdout.decode(errors='replace'), name)
            row['status'] = 'passed'
            RUNNER.save(folder / 'validation.json', row)
        require(RUNNER.digest(binary) == plan['binary_sha256'] and RUNNER.digest(cache) == plan['cmake_cache_sha256']
                and {path: RUNNER.digest(RUNNER.SELECTED / path) for path in RUNNER.OVERLAYS} == sources,
                'selected executable/configuration/sources changed during isolated validation')
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        if rows and rows[-1]['status'] != 'passed':
            rows[-1]['validation_error'] = failure
            rows[-1]['queue_health'] = 'Unestablished; stop and require root inspection before further GPU work.'
            validation = Path(rows[-1]['result']).parent / 'validation.json'
            if not validation.exists():
                RUNNER.save(validation, rows[-1])
    finally:
        RUNNER.save(output / 'isolated-metal-results.json', dict(
            started=started, finished=time.time(), plan_sha256=RUNNER.digest(output / 'isolated-metal-plan.json'),
            cases=rows, passed=sum(row['status'] == 'passed' for row in rows),
            failed=sum(row['status'] != 'passed' for row in rows), not_run=NAMES[len(rows):], error=failure,
            complete=failure is None and len(rows) == len(NAMES), full_metal_ctest_passed=False))
    if failure is not None:
        raise SystemExit(failure)


if __name__ == '__main__':
    main()

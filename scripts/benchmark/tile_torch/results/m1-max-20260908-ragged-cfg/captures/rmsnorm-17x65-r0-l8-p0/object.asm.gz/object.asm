
/tmp/luisa-ragged-cfg.pbUI2k/capture/rmsnorm-17x65-r0-l8-p0/object/tile_xir_w8_72041_1788863216614377_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      2c:      	sub	sp, sp, #0x540
      30:      	fmov	s1, wzr
      34:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
      38:      	add	x8, x8, #0x4e8
      3c:      	str	wzr, [sp, #0x153c]
      40:      	stur	wzr, [x8, #0x51]
      44:      	stur	xzr, [x8, #0x34]
      48:      	stur	xzr, [x8, #0x44]
      4c:      	stur	xzr, [x8, #0x3c]
      50:      	stur	xzr, [x8, #0x14]
      54:      	stur	xzr, [x8, #0x24]
      58:      	stur	xzr, [x8, #0x1c]
      5c:      	str	xzr, [sp, #0x14f0]
      60:      	str	xzr, [sp, #0x14e8]
      64:      	ldr	x6, [x0]
      68:      	ldr	x7, [x0, #0x10]
      6c:      	ldr	x3, [x0, #0x30]
      70:      	ldr	w9, [x1]
      74:      	ldr	w11, [x1, #0x24]
      78:      	dup.4s	v0, w2
      7c:      	adrp	x10, 0x0 <ltmp0>
      80:      	ldr	q2, [x10]
      84:      	adrp	x10, 0x0 <ltmp0>
      88:      	ldr	q3, [x10]
      8c:      	cmhi.4s	v3, v0, v3
      90:      	cmhi.4s	v0, v0, v2
      94:      	uzp1.8h	v2, v0, v3
      98:      	xtn.8b	v12, v2
      9c:      	adrp	x10, 0x0 <ltmp0>
      a0:      	ldr	q3, [x10]
      a4:      	and.16b	v3, v2, v3
      a8:      	addv.8h	h3, v3
      ac:      	fmov	w10, s3
      b0:      	and	w10, w10, #0xff
      b4:      	fmov	s3, w10
      b8:      	cmeq.8b	v1, v3, v1
      bc:      	umov.b	w10, v1[0]
      c0:      	and	w12, w10, #0x1
      c4:      	fmov	s1, w12
      c8:      	ubfx	w12, w10, #1, #1
      cc:      	mov.b	v1[1], w12
      d0:      	ubfx	w12, w10, #2, #1
      d4:      	mov.b	v1[2], w12
      d8:      	ubfx	w12, w10, #3, #1
      dc:      	mov.b	v1[3], w12
      e0:      	ubfx	w12, w10, #4, #1
      e4:      	mov.b	v1[4], w12
      e8:      	ubfx	w12, w10, #5, #1
      ec:      	mov.b	v1[5], w12
      f0:      	ubfx	w12, w10, #6, #1
      f4:      	mov.b	v1[6], w12
      f8:      	ubfx	w10, w10, #7, #1
      fc:      	mov.b	v1[7], w10
     100:      	movi.8b	v20, #0x1
     104:      	eor.8b	v1, v1, v20
     108:      	and.8b	v1, v1, v12
     10c:      	umaxv.8h	h2, v2
     110:      	fmov	w10, s2
     114:      	shl.8b	v1, v1, #0x7
     118:      	cmlt.8b	v1, v1, #0
     11c:      	adrp	x12, 0x0 <ltmp0>
     120:      	ldr	d2, [x12]
     124:      	and.8b	v1, v1, v2
     128:      	addv.8b	b1, v1
     12c:      	str	b1, [x8, #0x50]
     130:      	str	wzr, [sp, #0x1534]
     134:      	str	wzr, [sp, #0x1518]
     138:      	str	wzr, [sp, #0x1514]
     13c:      	str	wzr, [sp, #0x14f8]
     140:      	tbz	w10, #0x0, 0x53d4 <ltmp0+0x53d4>
     144:      	mov	w10, #0x0               ; =0
     148:      	stp	xzr, xzr, [sp, #0x40]
     14c:      	stp	xzr, xzr, [sp, #0x30]
     150:      	stp	xzr, xzr, [sp, #0x20]
     154:      	stp	xzr, xzr, [sp, #0x10]
     158:      	add	x15, sp, #0x1, lsl #12  ; =0x1000
     15c:      	add	x15, x15, #0x3c8
     160:      	dup.2d	v0, x15
     164:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     168:      	add	x12, x12, #0x2a8
     16c:      	dup.2d	v1, x12
     170:      	stp	q0, q1, [sp, #0x60]
     174:      	add	w9, w11, w9, lsl #5
     178:      	dup.4s	v1, w9
     17c:      	str	q1, [sp, #0x50]
     180:      	movi.2d	v23, #0000000000000000
     184:      	add	x9, x7, #0x100
     188:      	str	x9, [sp, #0x80]
     18c:      	mov	w20, #0x1               ; =1
     190:      	add	x21, sp, #0x1, lsl #12  ; =0x1000
     194:      	add	x21, x21, #0x538
     198:      	add	x22, sp, #0x1, lsl #12  ; =0x1000
     19c:      	add	x22, x22, #0x518
     1a0:      	add	x23, sp, #0x1, lsl #12  ; =0x1000
     1a4:      	add	x23, x23, #0x4f8
     1a8:      	adrp	x24, 0x0 <ltmp0>
     1ac:      	adrp	x25, 0x0 <ltmp0>
     1b0:      	adrp	x30, 0x0 <ltmp0>
     1b4:      	add	x27, sp, #0x1, lsl #12  ; =0x1000
     1b8:      	add	x27, x27, #0x4f0
     1bc:      	movi.2d	v0, #0000000000000000
     1c0:      	str	q0, [sp, #0x3f0]
     1c4:      	str	q0, [sp, #0x420]
     1c8:      	str	q0, [sp, #0x430]
     1cc:      	stp	q0, q0, [sp, #0x320]
     1d0:      	movi.2d	v25, #0000000000000000
     1d4:      	str	q0, [sp, #0x410]
     1d8:      	movi.2d	v14, #0000000000000000
     1dc:      	movi.2d	v22, #0000000000000000
     1e0:      	movi.2d	v1, #0000000000000000
     1e4:      	stp	q1, q1, [sp, #0x1d0]
     1e8:      	stp	q0, q0, [sp, #0x1b0]
     1ec:      	str	q1, [sp, #0x1f0]
     1f0:      	stp	q0, q0, [sp, #0x390]
     1f4:      	stp	q0, q0, [sp, #0x3c0]
     1f8:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     1fc:      	add	x0, x0, #0x180
     200:      	mov	w5, #-0x1               ; =-1
     204:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
     208:      	add	x16, x16, #0x160
     20c:      	add	x4, sp, #0xdf0
     210:      	mov	w19, #0x1               ; =1
     214:      	str	q0, [sp, #0x3b0]
     218:      	stp	q1, q1, [sp, #0xf0]
     21c:      	str	q1, [sp, #0x150]
     220:      	movi.2d	v24, #0000000000000000
     224:      	stp	q1, q1, [sp, #0x210]
     228:      	str	q0, [sp, #0x310]
     22c:      	movi.2d	v18, #0000000000000000
     230:      	stp	q1, q1, [sp, #0x260]
     234:      	movi.2d	v28, #0000000000000000
     238:      	movi.2d	v30, #0000000000000000
     23c:      	movi.2d	v8, #0000000000000000
     240:      	movi.2d	v9, #0000000000000000
     244:      	str	q1, [sp, #0x3e0]
     248:      	movi.2d	v15, #0000000000000000
     24c:      	movi.2d	v31, #0000000000000000
     250:      	movi.2d	v10, #0000000000000000
     254:      	movi.2d	v11, #0000000000000000
     258:      	movi.2d	v29, #0000000000000000
     25c:      	stp	q1, q1, [sp, #0x190]
     260:      	stp	q1, q1, [sp, #0x170]
     264:      	stp	q1, q1, [sp, #0x360]
     268:      	stp	q1, q1, [sp, #0x340]
     26c:      	stp	q1, q1, [sp, #0x240]
     270:      	str	q1, [sp, #0x230]
     274:      	movi.2d	v27, #0000000000000000
     278:      	movi.2d	v13, #0000000000000000
     27c:      	str	q0, [sp, #0x400]
     280:      	movi.2d	v26, #0000000000000000
     284:      	str	q1, [sp, #0x440]
     288:      	str	q1, [sp, #0x450]
     28c:      	str	q1, [sp, #0x460]
     290:      	str	q1, [sp, #0x470]
     294:      	b	0x2b0 <ltmp0+0x2b0>
     298:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     29c:      	add	x0, x0, #0x180
     2a0:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
     2a4:      	add	x16, x16, #0x160
     2a8:      	mov	x19, x26
     2ac:      	cbz	w26, 0x53d4 <ltmp0+0x53d4>
     2b0:      	sub	w26, w19, #0x1
     2b4:      	ldr	w13, [x22, w26, sxtw #2]
     2b8:      	cmp	w13, #0x14
     2bc:      	b.hi	0x541c <ltmp0+0x541c>
     2c0:      	sxtw	x28, w26
     2c4:      	ldrb	w11, [x21, x28]
     2c8:      	and	w12, w11, #0x1
     2cc:      	fmov	s21, w12
     2d0:      	ubfx	w12, w11, #1, #1
     2d4:      	mov.b	v21[1], w12
     2d8:      	ubfx	w12, w11, #2, #1
     2dc:      	mov.b	v21[2], w12
     2e0:      	ubfx	w12, w11, #3, #1
     2e4:      	mov.b	v21[3], w12
     2e8:      	ubfx	w12, w11, #4, #1
     2ec:      	mov.b	v21[4], w12
     2f0:      	ubfx	w12, w11, #5, #1
     2f4:      	mov.b	v21[5], w12
     2f8:      	ubfx	w12, w11, #6, #1
     2fc:      	mov.b	v21[6], w12
     300:      	lsr	w11, w11, #7
     304:      	mov.b	v21[7], w11
     308:      	ldr	w12, [x23, w26, sxtw #2]
     30c:      	adrp	x9, 0x0 <ltmp0>
     310:      	add	x9, x9, #0x0
     314:      	adr	x11, 0x324 <ltmp0+0x324>
     318:      	ldrh	w14, [x9, x13, lsl #1]
     31c:      	add	x11, x11, x14, lsl #2
     320:      	br	x11
     324:      	shl.8b	v1, v21, #0x7
     328:      	cmlt.8b	v1, v1, #0
     32c:      	umaxv.8b	b1, v1
     330:      	fmov	w11, s1
     334:      	mov	b1, v21[6]
     338:      	mov.b	v1[4], v21[7]
     33c:      	ushll.2d	v1, v1, #0x0
     340:      	shl.2d	v1, v1, #0x3f
     344:      	cmlt.2d	v1, v1, #0
     348:      	adrp	x9, 0x0 <ltmp0>
     34c:      	ldr	q3, [x9]
     350:      	bit.16b	v26, v3, v1
     354:      	mov	b3, v21[4]
     358:      	mov.b	v3[4], v21[5]
     35c:      	ushll.2d	v3, v3, #0x0
     360:      	shl.2d	v3, v3, #0x3f
     364:      	cmlt.2d	v3, v3, #0
     368:      	adrp	x9, 0x0 <ltmp0>
     36c:      	ldr	q4, [x9]
     370:      	mov	b6, v21[2]
     374:      	mov.b	v6[4], v21[3]
     378:      	ldr	q0, [sp, #0x400]
     37c:      	bit.16b	v0, v4, v3
     380:      	str	q0, [sp, #0x400]
     384:      	ushll.2d	v4, v6, #0x0
     388:      	shl.2d	v4, v4, #0x3f
     38c:      	cmlt.2d	v4, v4, #0
     390:      	adrp	x9, 0x0 <ltmp0>
     394:      	ldr	q6, [x9]
     398:      	bit.16b	v13, v6, v4
     39c:      	mov	b6, v21[0]
     3a0:      	mov.b	v6[4], v21[1]
     3a4:      	ushll.2d	v6, v6, #0x0
     3a8:      	shl.2d	v6, v6, #0x3f
     3ac:      	cmlt.2d	v6, v6, #0
     3b0:      	adrp	x9, 0x0 <ltmp0>
     3b4:      	ldr	q7, [x9]
     3b8:      	bit.16b	v27, v7, v6
     3bc:      	zip1.8b	v7, v21, v0
     3c0:      	ushll.4s	v7, v7, #0x0
     3c4:      	shl.4s	v7, v7, #0x1f
     3c8:      	cmlt.4s	v7, v7, #0
     3cc:      	ldr	q19, [sp, #0x50]
     3d0:      	and.16b	v16, v7, v19
     3d4:      	zip2.8b	v17, v21, v0
     3d8:      	ushll.4s	v17, v17, #0x0
     3dc:      	shl.4s	v17, v17, #0x1f
     3e0:      	cmlt.4s	v17, v17, #0
     3e4:      	and.16b	v19, v17, v19
     3e8:      	movi.4s	v20, #0x3
     3ec:      	and.16b	v7, v7, v20
     3f0:      	and.16b	v17, v17, v20
     3f4:      	neg.4s	v17, v17
     3f8:      	ushl.4s	v17, v19, v17
     3fc:      	neg.4s	v7, v7
     400:      	ushl.4s	v7, v16, v7
     404:      	ushll.2d	v16, v7, #0x0
     408:      	ushll2.2d	v7, v7, #0x0
     40c:      	ushll.2d	v19, v17, #0x0
     410:      	ushll2.2d	v17, v17, #0x0
     414:      	ldr	q20, [sp, #0x230]
     418:      	bit.16b	v20, v17, v1
     41c:      	ldr	q17, [sp, #0x240]
     420:      	bit.16b	v17, v19, v3
     424:      	stp	q20, q17, [sp, #0x230]
     428:      	ldr	q17, [sp, #0x250]
     42c:      	bit.16b	v17, v7, v4
     430:      	ldr	q7, [sp, #0x260]
     434:      	bit.16b	v7, v16, v6
     438:      	stp	q17, q7, [sp, #0x250]
     43c:      	ldr	q7, [sp, #0x60]
     440:      	ldr	q16, [sp, #0x170]
     444:      	bit.16b	v16, v7, v1
     448:      	str	q16, [sp, #0x170]
     44c:      	ldr	q16, [sp, #0x180]
     450:      	bit.16b	v16, v7, v3
     454:      	str	q16, [sp, #0x180]
     458:      	ldr	q16, [sp, #0x190]
     45c:      	bit.16b	v16, v7, v4
     460:      	str	q16, [sp, #0x190]
     464:      	ldr	q16, [sp, #0x1a0]
     468:      	bit.16b	v16, v7, v6
     46c:      	str	q16, [sp, #0x1a0]
     470:      	ldr	q7, [x24]
     474:      	ldr	q16, [sp, #0x340]
     478:      	bit.16b	v16, v7, v1
     47c:      	str	q16, [sp, #0x340]
     480:      	ldr	q7, [x25]
     484:      	ldr	q16, [sp, #0x350]
     488:      	bit.16b	v16, v7, v3
     48c:      	str	q16, [sp, #0x350]
     490:      	ldr	q7, [x30]
     494:      	ldr	q16, [sp, #0x360]
     498:      	bit.16b	v16, v7, v4
     49c:      	str	q16, [sp, #0x360]
     4a0:      	adrp	x9, 0x0 <ltmp0>
     4a4:      	ldr	q7, [x9]
     4a8:      	ldr	q16, [sp, #0x370]
     4ac:      	bit.16b	v16, v7, v6
     4b0:      	str	q16, [sp, #0x370]
     4b4:      	bic.16b	v29, v29, v1
     4b8:      	bic.16b	v11, v11, v3
     4bc:      	bic.16b	v10, v10, v4
     4c0:      	bic.16b	v31, v31, v6
     4c4:      	movi.8b	v20, #0x1
     4c8:      	tbnz	w11, #0x0, 0x5c4 <ltmp0+0x5c4>
     4cc:      	b	0x2a8 <ltmp0+0x2a8>
     4d0:      	shl.8b	v1, v21, #0x7
     4d4:      	cmlt.8b	v1, v1, #0
     4d8:      	and.8b	v1, v1, v2
     4dc:      	addv.8b	b1, v1
     4e0:      	fmov	w11, s1
     4e4:      	b	0x1cfc <ltmp0+0x1cfc>
     4e8:      	shl.8b	v1, v21, #0x7
     4ec:      	cmlt.8b	v1, v1, #0
     4f0:      	and.8b	v1, v1, v2
     4f4:      	addv.8b	b1, v1
     4f8:      	fmov	w11, s1
     4fc:      	b	0xac4 <ltmp0+0xac4>
     500:      	shl.8b	v1, v21, #0x7
     504:      	cmlt.8b	v1, v1, #0
     508:      	and.8b	v3, v1, v2
     50c:      	addv.8b	b3, v3
     510:      	fmov	w11, s3
     514:      	rbit	w11, w11
     518:      	clz	w11, w11
     51c:      	umaxv.8b	b1, v1
     520:      	fmov	w13, s1
     524:      	eor	w1, w13, #0x1
     528:      	tst	w13, #0x1
     52c:      	csel	w14, w11, wzr, ne
     530:      	b	0x624 <ltmp0+0x624>
     534:      	shl.8b	v1, v21, #0x7
     538:      	cmlt.8b	v1, v1, #0
     53c:      	umaxv.8b	b1, v1
     540:      	fmov	w11, s1
     544:      	eor	w11, w11, #0x1
     548:      	b	0x1290 <ltmp0+0x1290>
     54c:      	shl.8b	v1, v21, #0x7
     550:      	cmlt.8b	v1, v1, #0
     554:      	and.8b	v1, v1, v2
     558:      	addv.8b	b1, v1
     55c:      	fmov	w11, s1
     560:      	b	0x2a24 <ltmp0+0x2a24>
     564:      	shl.8b	v1, v21, #0x7
     568:      	cmlt.8b	v1, v1, #0
     56c:      	and.8b	v1, v1, v2
     570:      	addv.8b	b1, v1
     574:      	fmov	w11, s1
     578:      	b	0x3f28 <ltmp0+0x3f28>
     57c:      	shl.8b	v1, v21, #0x7
     580:      	cmlt.8b	v1, v1, #0
     584:      	and.8b	v1, v1, v2
     588:      	addv.8b	b1, v1
     58c:      	fmov	w11, s1
     590:      	b	0x83c <ltmp0+0x83c>
     594:      	shl.8b	v1, v21, #0x7
     598:      	cmlt.8b	v1, v1, #0
     59c:      	and.8b	v1, v1, v2
     5a0:      	addv.8b	b1, v1
     5a4:      	fmov	w11, s1
     5a8:      	b	0x3050 <ltmp0+0x3050>
     5ac:      	shl.8b	v1, v21, #0x7
     5b0:      	cmlt.8b	v1, v1, #0
     5b4:      	and.8b	v1, v1, v2
     5b8:      	addv.8b	b1, v1
     5bc:      	fmov	w11, s1
     5c0:      	b	0x372c <ltmp0+0x372c>
     5c4:      	shl.8b	v1, v21, #0x7
     5c8:      	cmlt.8b	v1, v1, #0
     5cc:      	and.8b	v3, v1, v2
     5d0:      	addv.8b	b3, v3
     5d4:      	fmov	w11, s3
     5d8:      	umaxv.8b	b1, v1
     5dc:      	fmov	w13, s1
     5e0:      	rbit	w14, w11
     5e4:      	clz	w14, w14
     5e8:      	tst	w13, #0x1
     5ec:      	csel	w13, w14, wzr, ne
     5f0:      	str	q31, [sp, #0x1260]
     5f4:      	str	q10, [sp, #0x1270]
     5f8:      	str	q11, [sp, #0x1280]
     5fc:      	str	q29, [sp, #0x1290]
     600:      	and	x13, x13, #0x7
     604:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     608:      	add	x9, x9, #0x260
     60c:      	ldr	x13, [x9, x13, lsl #3]
     610:      	cmp	x13, #0x8
     614:      	b.ge	0x834 <ltmp0+0x834>
     618:      	tst	w11, #0xff
     61c:      	b.eq	0x2a8 <ltmp0+0x2a8>
     620:      	mov	w1, #0x0                ; =0
     624:      	str	q31, [sp, #0x540]
     628:      	str	q10, [sp, #0x550]
     62c:      	str	q11, [sp, #0x560]
     630:      	str	q29, [sp, #0x570]
     634:      	mov	w13, w14
     638:      	ubfiz	x17, x13, #3, #3
     63c:      	add	x9, sp, #0x540
     640:      	ldr	x11, [x9, x17]
     644:      	lsl	x2, x11, #3
     648:      	dup.2d	v1, x2
     64c:      	add.2d	v3, v1, v27
     650:      	add.2d	v4, v1, v13
     654:      	ldr	q0, [sp, #0x400]
     658:      	add.2d	v6, v1, v0
     65c:      	ldp	q7, q0, [sp, #0x250]
     660:      	str	q0, [sp, #0x4c0]
     664:      	str	q7, [sp, #0x4d0]
     668:      	ldp	q7, q0, [sp, #0x230]
     66c:      	str	q0, [sp, #0x4e0]
     670:      	str	q7, [sp, #0x4f0]
     674:      	add	x9, sp, #0x4c0
     678:      	ldr	x2, [x9, x17]
     67c:      	add.2d	v1, v1, v26
     680:      	add	x2, x2, x2, lsl #6
     684:      	str	q1, [sp, #0x530]
     688:      	str	q6, [sp, #0x520]
     68c:      	str	q4, [sp, #0x510]
     690:      	str	q3, [sp, #0x500]
     694:      	add	x9, sp, #0x500
     698:      	ldr	x17, [x9, x17]
     69c:      	sub	x2, x2, x13
     6a0:      	add	x17, x2, x17
     6a4:      	add	x17, x6, x17, lsl #2
     6a8:      	shl.8b	v1, v21, #0x7
     6ac:      	cmlt.8b	v1, v1, #0
     6b0:      	and.8b	v1, v1, v2
     6b4:      	addv.8b	b1, v1
     6b8:      	fmov	w2, s1
     6bc:      	movi.2d	v1, #0000000000000000
     6c0:      	movi.2d	v3, #0000000000000000
     6c4:      	tbz	w2, #0x0, 0x708 <ltmp0+0x708>
     6c8:      	ldr	s1, [x17]
     6cc:      	tbnz	w2, #0x1, 0x70c <ltmp0+0x70c>
     6d0:      	tbz	w2, #0x2, 0x718 <ltmp0+0x718>
     6d4:      	add	x4, x17, #0x8
     6d8:      	ld1.s	{ v1 }[2], [x4]
     6dc:      	tbnz	w2, #0x3, 0x71c <ltmp0+0x71c>
     6e0:      	tbz	w2, #0x4, 0x728 <ltmp0+0x728>
     6e4:      	add	x4, x17, #0x10
     6e8:      	ld1.s	{ v3 }[0], [x4]
     6ec:      	tbnz	w2, #0x5, 0x72c <ltmp0+0x72c>
     6f0:      	tbz	w2, #0x6, 0x738 <ltmp0+0x738>
     6f4:      	add	x4, x17, #0x18
     6f8:      	ld1.s	{ v3 }[2], [x4]
     6fc:      	add	x4, sp, #0xdf0
     700:      	tbnz	w2, #0x7, 0x740 <ltmp0+0x740>
     704:      	b	0x748 <ltmp0+0x748>
     708:      	tbz	w2, #0x1, 0x6d0 <ltmp0+0x6d0>
     70c:      	add	x4, x17, #0x4
     710:      	ld1.s	{ v1 }[1], [x4]
     714:      	tbnz	w2, #0x2, 0x6d4 <ltmp0+0x6d4>
     718:      	tbz	w2, #0x3, 0x6e0 <ltmp0+0x6e0>
     71c:      	add	x4, x17, #0xc
     720:      	ld1.s	{ v1 }[3], [x4]
     724:      	tbnz	w2, #0x4, 0x6e4 <ltmp0+0x6e4>
     728:      	tbz	w2, #0x5, 0x6f0 <ltmp0+0x6f0>
     72c:      	add	x4, x17, #0x14
     730:      	ld1.s	{ v3 }[1], [x4]
     734:      	tbnz	w2, #0x6, 0x6f4 <ltmp0+0x6f4>
     738:      	add	x4, sp, #0xdf0
     73c:      	tbz	w2, #0x7, 0x748 <ltmp0+0x748>
     740:      	add	x17, x17, #0x1c
     744:      	ld1.s	{ v3 }[3], [x17]
     748:      	lsl	x17, x11, #5
     74c:      	dup.2d	v4, x17
     750:      	ldp	q6, q17, [sp, #0x340]
     754:      	add.2d	v6, v4, v6
     758:      	ldp	q16, q7, [sp, #0x360]
     75c:      	add.2d	v7, v4, v7
     760:      	add.2d	v16, v4, v16
     764:      	add.2d	v4, v4, v17
     768:      	str	q16, [sp, #0x490]
     76c:      	str	q7, [sp, #0x480]
     770:      	str	q4, [sp, #0x4a0]
     774:      	str	q6, [sp, #0x4b0]
     778:      	and	x14, x14, #0x7
     77c:      	add	x9, sp, #0x480
     780:      	ldr	x14, [x9, x14, lsl #3]
     784:      	sub	x14, x14, x13, lsl #2
     788:      	ands	w13, w1, #0x1
     78c:      	csel	x14, xzr, x14, ne
     790:      	add	x14, x15, x14
     794:      	ldp	q4, q6, [x14]
     798:      	zip2.8b	v7, v21, v0
     79c:      	ushll.4s	v7, v7, #0x0
     7a0:      	shl.4s	v7, v7, #0x1f
     7a4:      	cmlt.4s	v7, v7, #0
     7a8:      	bif.16b	v3, v6, v7
     7ac:      	zip1.8b	v6, v21, v0
     7b0:      	ushll.4s	v6, v6, #0x0
     7b4:      	shl.4s	v6, v6, #0x1f
     7b8:      	cmlt.4s	v6, v6, #0
     7bc:      	bif.16b	v1, v4, v6
     7c0:      	stp	q1, q3, [x14]
     7c4:      	add	x11, x11, #0x1
     7c8:      	dup.2d	v1, x11
     7cc:      	mov	b3, v21[6]
     7d0:      	mov.b	v3[4], v21[7]
     7d4:      	ushll.2d	v3, v3, #0x0
     7d8:      	shl.2d	v3, v3, #0x3f
     7dc:      	cmlt.2d	v3, v3, #0
     7e0:      	bit.16b	v29, v1, v3
     7e4:      	mov	b3, v21[4]
     7e8:      	mov.b	v3[4], v21[5]
     7ec:      	ushll.2d	v3, v3, #0x0
     7f0:      	shl.2d	v3, v3, #0x3f
     7f4:      	cmlt.2d	v3, v3, #0
     7f8:      	mov	b4, v21[2]
     7fc:      	mov.b	v4[4], v21[3]
     800:      	bit.16b	v11, v1, v3
     804:      	ushll.2d	v3, v4, #0x0
     808:      	shl.2d	v3, v3, #0x3f
     80c:      	cmlt.2d	v3, v3, #0
     810:      	bit.16b	v10, v1, v3
     814:      	mov	b3, v21[0]
     818:      	mov.b	v3[4], v21[1]
     81c:      	ushll.2d	v3, v3, #0x0
     820:      	shl.2d	v3, v3, #0x3f
     824:      	cmlt.2d	v3, v3, #0
     828:      	bit.16b	v31, v1, v3
     82c:      	cbnz	w13, 0x2a8 <ltmp0+0x2a8>
     830:      	b	0x5c4 <ltmp0+0x5c4>
     834:      	tst	w11, #0xff
     838:      	b.eq	0x2a8 <ltmp0+0x2a8>
     83c:      	cmle.2d	v1, v27, #0
     840:      	cmle.2d	v3, v13, #0
     844:      	uzp1.4s	v1, v1, v3
     848:      	ldr	q0, [sp, #0x400]
     84c:      	cmle.2d	v3, v0, #0
     850:      	cmle.2d	v4, v26, #0
     854:      	uzp1.4s	v3, v3, v4
     858:      	uzp1.8h	v1, v1, v3
     85c:      	xtn.8b	v1, v1
     860:      	shl.8b	v3, v21, #0x7
     864:      	cmlt.8b	v3, v3, #0
     868:      	bit.8b	v15, v1, v3
     86c:      	and.8b	v1, v21, v1
     870:      	shl.8b	v1, v1, #0x7
     874:      	cmlt.8b	v3, v1, #0
     878:      	and.8b	v1, v3, v2
     87c:      	addv.8b	b1, v1
     880:      	umaxv.8b	b3, v3
     884:      	fmov	w13, s3
     888:      	tbz	w13, #0x0, 0xab0 <ltmp0+0xab0>
     88c:      	dup.2d	v3, x20
     890:      	cmge.2d	v4, v13, v3
     894:      	cmge.2d	v6, v27, v3
     898:      	uzp1.4s	v4, v6, v4
     89c:      	ldr	q0, [sp, #0x400]
     8a0:      	cmge.2d	v6, v0, v3
     8a4:      	cmge.2d	v3, v26, v3
     8a8:      	uzp1.4s	v3, v6, v3
     8ac:      	uzp1.8h	v3, v4, v3
     8b0:      	xtn.8b	v3, v3
     8b4:      	and.8b	v3, v21, v3
     8b8:      	shl.8b	v3, v3, #0x7
     8bc:      	cmlt.8b	v3, v3, #0
     8c0:      	and.8b	v3, v3, v2
     8c4:      	addv.8b	b3, v3
     8c8:      	fmov	w13, s3
     8cc:      	tst	w13, #0xff
     8d0:      	b.eq	0xab0 <ltmp0+0xab0>
     8d4:      	subs	w11, w12, #0x1
     8d8:      	csel	w11, wzr, w11, lo
     8dc:      	and	w13, w10, #0xff
     8e0:      	lsr	w14, w13, w11
     8e4:      	tst	w14, #0x1
     8e8:      	ldr	q4, [sp, #0x460]
     8ec:      	str	q4, [sp, #0x600]
     8f0:      	ldr	q4, [sp, #0x470]
     8f4:      	str	q4, [sp, #0x610]
     8f8:      	and	x11, x11, #0x7
     8fc:      	add	x9, sp, #0x600
     900:      	ldr	w11, [x9, x11, lsl #2]
     904:      	ccmp	w12, #0x0, #0x4, ne
     908:      	ccmp	w11, #0x0, #0x0, ne
     90c:      	cset	w11, ne
     910:      	cmp	w13, #0xff
     914:      	b.ne	0x91c <ltmp0+0x91c>
     918:      	tbnz	w11, #0x0, 0x541c <ltmp0+0x541c>
     91c:      	mvn	w13, w10
     920:      	rbit	w13, w13
     924:      	clz	w13, w13
     928:      	mov	w9, #0xff               ; =255
     92c:      	bics	wzr, w9, w10
     930:      	csel	w13, wzr, w13, eq
     934:      	ubfiz	x14, x13, #2, #3
     938:      	lsl	w17, w20, w13
     93c:      	ldr	q5, [sp, #0x460]
     940:      	str	q5, [sp, #0x5e0]
     944:      	ldr	q4, [sp, #0x470]
     948:      	str	q4, [sp, #0x5f0]
     94c:      	add	x9, sp, #0x5e0
     950:      	ldr	w1, [x9, x14]
     954:      	cmp	w11, #0x0
     958:      	csel	w11, w17, wzr, ne
     95c:      	csel	w17, wzr, w1, ne
     960:      	str	q5, [sp, #0x5c0]
     964:      	str	q4, [sp, #0x5d0]
     968:      	add	x9, sp, #0x5c0
     96c:      	str	w17, [x9, x14]
     970:      	ldr	q4, [sp, #0x5d0]
     974:      	str	q4, [sp, #0x470]
     978:      	ldr	q4, [sp, #0x5c0]
     97c:      	str	q4, [sp, #0x460]
     980:      	ldr	q5, [sp, #0x440]
     984:      	str	q5, [sp, #0x5a0]
     988:      	ldr	q4, [sp, #0x450]
     98c:      	str	q4, [sp, #0x5b0]
     990:      	add	x9, sp, #0x5a0
     994:      	ldr	w17, [x9, x14]
     998:      	csel	w17, w12, w17, ne
     99c:      	str	q5, [sp, #0x580]
     9a0:      	str	q4, [sp, #0x590]
     9a4:      	add	x9, sp, #0x580
     9a8:      	str	w17, [x9, x14]
     9ac:      	ldrb	w14, [x27, x13]
     9b0:      	and	w17, w14, #0x1
     9b4:      	fmov	s4, w17
     9b8:      	ubfx	w17, w14, #1, #1
     9bc:      	mov.b	v4[1], w17
     9c0:      	ubfx	w17, w14, #2, #1
     9c4:      	mov.b	v4[2], w17
     9c8:      	ubfx	w17, w14, #3, #1
     9cc:      	mov.b	v4[3], w17
     9d0:      	ubfx	w17, w14, #4, #1
     9d4:      	mov.b	v4[4], w17
     9d8:      	ubfx	w17, w14, #5, #1
     9dc:      	mov.b	v4[5], w17
     9e0:      	ubfx	w17, w14, #6, #1
     9e4:      	mov.b	v4[6], w17
     9e8:      	ldr	q5, [sp, #0x590]
     9ec:      	str	q5, [sp, #0x450]
     9f0:      	ldr	q5, [sp, #0x580]
     9f4:      	str	q5, [sp, #0x440]
     9f8:      	lsr	w14, w14, #7
     9fc:      	mov.b	v4[7], w14
     a00:      	ldrb	w14, [x8, x13]
     a04:      	and	w17, w14, #0x1
     a08:      	fmov	s6, w17
     a0c:      	ubfx	w17, w14, #1, #1
     a10:      	mov.b	v6[1], w17
     a14:      	ubfx	w17, w14, #2, #1
     a18:      	mov.b	v6[2], w17
     a1c:      	ubfx	w17, w14, #3, #1
     a20:      	mov.b	v6[3], w17
     a24:      	ubfx	w17, w14, #4, #1
     a28:      	mov.b	v6[4], w17
     a2c:      	ubfx	w17, w14, #5, #1
     a30:      	mov.b	v6[5], w17
     a34:      	ubfx	w17, w14, #6, #1
     a38:      	mov.b	v6[6], w17
     a3c:      	lsr	w14, w14, #7
     a40:      	mov.b	v6[7], w14
     a44:      	csetm	w14, ne
     a48:      	dup.8b	v7, w14
     a4c:      	bit.8b	v4, v21, v7
     a50:      	shl.8b	v4, v4, #0x7
     a54:      	cmlt.8b	v4, v4, #0
     a58:      	and.8b	v4, v4, v2
     a5c:      	addv.8b	b4, v4
     a60:      	str	b4, [x27, x13]
     a64:      	bic.8b	v4, v6, v7
     a68:      	shl.8b	v4, v4, #0x7
     a6c:      	cmlt.8b	v4, v4, #0
     a70:      	and.8b	v4, v4, v2
     a74:      	addv.8b	b4, v4
     a78:      	str	b4, [x8, x13]
     a7c:      	csinc	w12, w12, w13, eq
     a80:      	cmp	w26, #0x8
     a84:      	b.hs	0x541c <ltmp0+0x541c>
     a88:      	str	b1, [x21, x28]
     a8c:      	mov	w9, #0x4                ; =4
     a90:      	str	w9, [x22, x28, lsl #2]
     a94:      	str	w12, [x23, x28, lsl #2]
     a98:      	cmp	w19, #0x8
     a9c:      	b.hs	0x541c <ltmp0+0x541c>
     aa0:      	str	b3, [x21, w19, uxtw]
     aa4:      	orr	w10, w11, w10
     aa8:      	mov	w9, #0x5                ; =5
     aac:      	b	0xfe8 <ltmp0+0xfe8>
     ab0:      	fmov	w13, s1
     ab4:      	tst	w13, #0xff
     ab8:      	b.eq	0xfd4 <ltmp0+0xfd4>
     abc:      	tst	w11, #0xff
     ac0:      	b.eq	0x2a8 <ltmp0+0x2a8>
     ac4:      	rbit	w13, w11
     ac8:      	clz	w13, w13
     acc:      	tst	w11, #0xff
     ad0:      	csel	w13, wzr, w13, eq
     ad4:      	ldp	q1, q0, [sp, #0x250]
     ad8:      	str	q0, [sp, #0x1220]
     adc:      	str	q1, [sp, #0x1230]
     ae0:      	ldp	q1, q0, [sp, #0x230]
     ae4:      	str	q0, [sp, #0x1240]
     ae8:      	str	q1, [sp, #0x1250]
     aec:      	ubfiz	x14, x13, #3, #3
     af0:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     af4:      	add	x9, x9, #0x220
     af8:      	ldr	x17, [x9, x14]
     afc:      	str	q27, [sp, #0x11e0]
     b00:      	str	q13, [sp, #0x11f0]
     b04:      	ldr	q0, [sp, #0x400]
     b08:      	str	q0, [sp, #0x1200]
     b0c:      	str	q26, [sp, #0x1210]
     b10:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     b14:      	add	x9, x9, #0x1e0
     b18:      	ldr	x14, [x9, x14]
     b1c:      	add	x17, x17, x17, lsl #6
     b20:      	sub	x14, x14, x13
     b24:      	add	x14, x14, x17
     b28:      	add	x14, x6, x14, lsl #2
     b2c:      	add	x14, x14, #0x100
     b30:      	shl.8b	v1, v21, #0x7
     b34:      	cmlt.8b	v1, v1, #0
     b38:      	and.8b	v1, v1, v2
     b3c:      	addv.8b	b1, v1
     b40:      	fmov	w17, s1
     b44:      	movi.2d	v1, #0000000000000000
     b48:      	movi.2d	v3, #0000000000000000
     b4c:      	tbz	w17, #0x0, 0xb8c <ltmp0+0xb8c>
     b50:      	ldr	s1, [x14]
     b54:      	tbnz	w17, #0x1, 0xb90 <ltmp0+0xb90>
     b58:      	tbz	w17, #0x2, 0xb9c <ltmp0+0xb9c>
     b5c:      	add	x1, x14, #0x8
     b60:      	ld1.s	{ v1 }[2], [x1]
     b64:      	tbnz	w17, #0x3, 0xba0 <ltmp0+0xba0>
     b68:      	tbz	w17, #0x4, 0xbac <ltmp0+0xbac>
     b6c:      	add	x1, x14, #0x10
     b70:      	ld1.s	{ v3 }[0], [x1]
     b74:      	tbnz	w17, #0x5, 0xbb0 <ltmp0+0xbb0>
     b78:      	tbz	w17, #0x6, 0xbbc <ltmp0+0xbbc>
     b7c:      	add	x1, x14, #0x18
     b80:      	ld1.s	{ v3 }[2], [x1]
     b84:      	tbnz	w17, #0x7, 0xbc0 <ltmp0+0xbc0>
     b88:      	b	0xbc8 <ltmp0+0xbc8>
     b8c:      	tbz	w17, #0x1, 0xb58 <ltmp0+0xb58>
     b90:      	add	x1, x14, #0x4
     b94:      	ld1.s	{ v1 }[1], [x1]
     b98:      	tbnz	w17, #0x2, 0xb5c <ltmp0+0xb5c>
     b9c:      	tbz	w17, #0x3, 0xb68 <ltmp0+0xb68>
     ba0:      	add	x1, x14, #0xc
     ba4:      	ld1.s	{ v1 }[3], [x1]
     ba8:      	tbnz	w17, #0x4, 0xb6c <ltmp0+0xb6c>
     bac:      	tbz	w17, #0x5, 0xb78 <ltmp0+0xb78>
     bb0:      	add	x1, x14, #0x14
     bb4:      	ld1.s	{ v3 }[1], [x1]
     bb8:      	tbnz	w17, #0x6, 0xb7c <ltmp0+0xb7c>
     bbc:      	tbz	w17, #0x7, 0xbc8 <ltmp0+0xbc8>
     bc0:      	add	x14, x14, #0x1c
     bc4:      	ld1.s	{ v3 }[3], [x14]
     bc8:      	ldp	q4, q0, [sp, #0x360]
     bcc:      	str	q0, [sp, #0x11a0]
     bd0:      	str	q4, [sp, #0x11b0]
     bd4:      	ldp	q4, q0, [sp, #0x340]
     bd8:      	str	q0, [sp, #0x11c0]
     bdc:      	str	q4, [sp, #0x11d0]
     be0:      	and	x14, x13, #0x7
     be4:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     be8:      	add	x9, x9, #0x1a0
     bec:      	ldr	x14, [x9, x14, lsl #3]
     bf0:      	sub	x13, x14, x13, lsl #2
     bf4:      	add	x13, x13, #0x100
     bf8:      	ands	w11, w11, #0xff
     bfc:      	csel	x13, xzr, x13, eq
     c00:      	add	x13, x15, x13
     c04:      	ldp	q4, q6, [x13]
     c08:      	zip2.8b	v7, v21, v0
     c0c:      	ushll.4s	v7, v7, #0x0
     c10:      	shl.4s	v7, v7, #0x1f
     c14:      	cmlt.4s	v7, v7, #0
     c18:      	bif.16b	v3, v6, v7
     c1c:      	zip1.8b	v6, v21, v0
     c20:      	ushll.4s	v6, v6, #0x0
     c24:      	shl.4s	v6, v6, #0x1f
     c28:      	cmlt.4s	v6, v6, #0
     c2c:      	bif.16b	v1, v4, v6
     c30:      	stp	q1, q3, [x13]
     c34:      	cbz	w11, 0x2a8 <ltmp0+0x2a8>
     c38:      	cbz	w12, 0xe00 <ltmp0+0xe00>
     c3c:      	mov	w11, #0x0               ; =0
     c40:      	shl.8b	v1, v21, #0x7
     c44:      	cmlt.8b	v1, v1, #0
     c48:      	and.8b	v3, v1, v2
     c4c:      	addv.8b	b3, v3
     c50:      	fmov	w13, s3
     c54:      	umaxv.8b	b1, v1
     c58:      	fmov	w2, s1
     c5c:      	sub	w14, w12, #0x1
     c60:      	tst	w13, #0xff
     c64:      	csel	w14, w14, wzr, ne
     c68:      	lsl	w17, w20, w14
     c6c:      	and	w13, w17, w10
     c70:      	tst	w13, #0xff
     c74:      	cset	w4, ne
     c78:      	ldr	q1, [sp, #0x460]
     c7c:      	str	q1, [sp, #0x1180]
     c80:      	ldr	q1, [sp, #0x470]
     c84:      	str	q1, [sp, #0x1190]
     c88:      	ubfiz	x13, x14, #2, #3
     c8c:      	ldr	w1, [x0, x13]
     c90:      	cmp	w1, #0x0
     c94:      	cset	w1, eq
     c98:      	and	w2, w4, w2
     c9c:      	ldrb	w4, [x27, w14, sxtw]
     ca0:      	and	w5, w4, #0x1
     ca4:      	fmov	s1, w5
     ca8:      	ubfx	w5, w4, #1, #1
     cac:      	mov.b	v1[1], w5
     cb0:      	ubfx	w5, w4, #2, #1
     cb4:      	mov.b	v1[2], w5
     cb8:      	ubfx	w5, w4, #3, #1
     cbc:      	mov.b	v1[3], w5
     cc0:      	ubfx	w5, w4, #4, #1
     cc4:      	mov.b	v1[4], w5
     cc8:      	ubfx	w5, w4, #5, #1
     ccc:      	mov.b	v1[5], w5
     cd0:      	ubfx	w5, w4, #6, #1
     cd4:      	mov.b	v1[6], w5
     cd8:      	lsr	w4, w4, #7
     cdc:      	mov.b	v1[7], w4
     ce0:      	ldrb	w4, [x8, w14, sxtw]
     ce4:      	and	w5, w4, #0x1
     ce8:      	fmov	s3, w5
     cec:      	ubfx	w5, w4, #1, #1
     cf0:      	mov.b	v3[1], w5
     cf4:      	ubfx	w5, w4, #2, #1
     cf8:      	mov.b	v3[2], w5
     cfc:      	ubfx	w5, w4, #3, #1
     d00:      	mov.b	v3[3], w5
     d04:      	ubfx	w5, w4, #4, #1
     d08:      	mov.b	v3[4], w5
     d0c:      	ubfx	w5, w4, #5, #1
     d10:      	mov.b	v3[5], w5
     d14:      	ubfx	w5, w4, #6, #1
     d18:      	mov.b	v3[6], w5
     d1c:      	lsr	w4, w4, #7
     d20:      	mov.b	v3[7], w4
     d24:      	orr.8b	v4, v21, v3
     d28:      	and.8b	v6, v12, v1
     d2c:      	eor.8b	v6, v6, v4
     d30:      	shl.8b	v6, v6, #0x7
     d34:      	cmlt.8b	v6, v6, #0
     d38:      	umaxv.8b	b6, v6
     d3c:      	fmov	w4, s6
     d40:      	ands	w1, w2, w1
     d44:      	csetm	w2, ne
     d48:      	bics	w4, w1, w4
     d4c:      	csetm	w5, ne
     d50:      	dup.8b	v6, w5
     d54:      	mov	w5, #-0x1               ; =-1
     d58:      	dup.8b	v7, w2
     d5c:      	bic.8b	v16, v4, v6
     d60:      	bit.8b	v3, v16, v7
     d64:      	shl.8b	v3, v3, #0x7
     d68:      	cmlt.8b	v3, v3, #0
     d6c:      	and.8b	v3, v3, v2
     d70:      	addv.8b	b3, v3
     d74:      	str	b3, [x8, w14, sxtw]
     d78:      	bic.8b	v1, v1, v6
     d7c:      	shl.8b	v1, v1, #0x7
     d80:      	cmlt.8b	v1, v1, #0
     d84:      	and.8b	v1, v1, v2
     d88:      	addv.8b	b1, v1
     d8c:      	str	b1, [x27, w14, sxtw]
     d90:      	csinv	w14, w5, w17, eq
     d94:      	dup.8b	v1, w1
     d98:      	and	w10, w14, w10
     d9c:      	shl.8b	v1, v1, #0x7
     da0:      	cmlt.8b	v1, v1, #0
     da4:      	dup.8b	v3, w4
     da8:      	and.8b	v3, v3, v4
     dac:      	ldr	q4, [sp, #0x440]
     db0:      	str	q4, [sp, #0x1160]
     db4:      	ldr	q4, [sp, #0x450]
     db8:      	str	q4, [sp, #0x1170]
     dbc:      	ldr	w13, [x16, x13]
     dc0:      	csel	w12, w13, w12, ne
     dc4:      	bit.8b	v21, v3, v1
     dc8:      	shl.8b	v1, v21, #0x7
     dcc:      	cmlt.8b	v1, v1, #0
     dd0:      	and.8b	v1, v1, v2
     dd4:      	addv.8b	b1, v1
     dd8:      	fmov	w13, s1
     ddc:      	cmp	w1, #0x1
     de0:      	b.ne	0xe14 <ltmp0+0xe14>
     de4:      	cmp	w12, #0x0
     de8:      	ccmp	w11, #0x6, #0x2, ne
     dec:      	b.hi	0xe14 <ltmp0+0xe14>
     df0:      	add	w11, w11, #0x1
     df4:      	tst	w13, #0xff
     df8:      	b.ne	0xc40 <ltmp0+0xc40>
     dfc:      	b	0xe14 <ltmp0+0xe14>
     e00:      	shl.8b	v1, v21, #0x7
     e04:      	cmlt.8b	v1, v1, #0
     e08:      	and.8b	v1, v1, v2
     e0c:      	addv.8b	b1, v1
     e10:      	fmov	w13, s1
     e14:      	tst	w13, #0xff
     e18:      	b.eq	0xfe0 <ltmp0+0xfe0>
     e1c:      	rbit	w11, w13
     e20:      	clz	w11, w11
     e24:      	ldp	q1, q0, [sp, #0x360]
     e28:      	str	q0, [sp, #0x1120]
     e2c:      	str	q1, [sp, #0x1130]
     e30:      	ldp	q1, q0, [sp, #0x340]
     e34:      	str	q0, [sp, #0x1140]
     e38:      	str	q1, [sp, #0x1150]
     e3c:      	and	x13, x11, #0x7
     e40:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     e44:      	add	x9, x9, #0x120
     e48:      	ldr	x13, [x9, x13, lsl #3]
     e4c:      	lsl	w11, w11, #2
     e50:      	sub	x11, x13, x11
     e54:      	add	x11, x15, x11
     e58:      	ldp	q1, q3, [x11]
     e5c:      	mov.16b	v0, v8
     e60:      	mov.16b	v8, v18
     e64:      	mov.16b	v18, v0
     e68:      	mov.16b	v5, v15
     e6c:      	mov.16b	v15, v10
     e70:      	mov.16b	v0, v26
     e74:      	mov.16b	v10, v29
     e78:      	mov.16b	v29, v11
     e7c:      	fmul.4s	v11, v1, v1
     e80:      	fmul.4s	v26, v3, v3
     e84:      	ldp	q4, q6, [x11, #0x20]
     e88:      	fmul.4s	v4, v4, v4
     e8c:      	fmul.4s	v6, v6, v6
     e90:      	ldp	q7, q16, [x11, #0x40]
     e94:      	fmul.4s	v7, v7, v7
     e98:      	fmul.4s	v16, v16, v16
     e9c:      	ldp	q19, q17, [x11, #0x60]
     ea0:      	fmul.4s	v19, v19, v19
     ea4:      	fmul.4s	v17, v17, v17
     ea8:      	str	q5, [sp, #0x200]
     eac:      	str	q27, [sp, #0x380]
     eb0:      	stp	q24, q14, [sp, #0x2f0]
     eb4:      	mov	b20, v21[6]
     eb8:      	mov.b	v20[4], v21[7]
     ebc:      	ushll.2d	v20, v20, #0x0
     ec0:      	shl.2d	v20, v20, #0x3f
     ec4:      	cmlt.2d	v20, v20, #0
     ec8:      	mov	w9, #0x4                ; =4
     ecc:      	mov.16b	v5, v23
     ed0:      	dup.2d	v23, x9
     ed4:      	mov.16b	v24, v0
     ed8:      	mov.16b	v0, v15
     edc:      	ldr	q15, [sp, #0x3e0]
     ee0:      	bit.16b	v15, v23, v20
     ee4:      	str	q15, [sp, #0x3e0]
     ee8:      	mov.16b	v1, v8
     eec:      	mov	b20, v21[4]
     ef0:      	mov.b	v20[4], v21[5]
     ef4:      	ushll.2d	v20, v20, #0x0
     ef8:      	shl.2d	v20, v20, #0x3f
     efc:      	cmlt.2d	v20, v20, #0
     f00:      	bit.16b	v9, v23, v20
     f04:      	mov	b20, v21[2]
     f08:      	mov.b	v20[4], v21[3]
     f0c:      	ushll.2d	v20, v20, #0x0
     f10:      	shl.2d	v20, v20, #0x3f
     f14:      	cmlt.2d	v20, v20, #0
     f18:      	mov.16b	v8, v20
     f1c:      	bsl.16b	v8, v23, v18
     f20:      	mov	b20, v21[0]
     f24:      	mov.b	v20[4], v21[1]
     f28:      	ushll.2d	v20, v20, #0x0
     f2c:      	shl.2d	v20, v20, #0x3f
     f30:      	cmlt.2d	v20, v20, #0
     f34:      	bit.16b	v30, v23, v20
     f38:      	zip1.8b	v20, v21, v0
     f3c:      	ushll.4s	v20, v20, #0x0
     f40:      	shl.4s	v20, v20, #0x1f
     f44:      	cmlt.4s	v20, v20, #0
     f48:      	zip2.8b	v23, v21, v0
     f4c:      	ushll.4s	v23, v23, #0x0
     f50:      	shl.4s	v23, v23, #0x1f
     f54:      	cmlt.4s	v23, v23, #0
     f58:      	bit.16b	v28, v26, v23
     f5c:      	ldr	q3, [sp, #0x270]
     f60:      	bit.16b	v3, v11, v20
     f64:      	mov.16b	v11, v29
     f68:      	mov.16b	v29, v10
     f6c:      	mov.16b	v26, v24
     f70:      	mov.16b	v10, v0
     f74:      	str	q3, [sp, #0x270]
     f78:      	mov.16b	v18, v23
     f7c:      	bsl.16b	v18, v6, v1
     f80:      	ldr	q0, [sp, #0x3a0]
     f84:      	bit.16b	v0, v4, v20
     f88:      	str	q0, [sp, #0x3a0]
     f8c:      	ldr	q0, [sp, #0x1b0]
     f90:      	bit.16b	v0, v16, v23
     f94:      	str	q0, [sp, #0x1b0]
     f98:      	ldp	q14, q0, [sp, #0x300]
     f9c:      	bit.16b	v0, v7, v20
     fa0:      	str	q0, [sp, #0x310]
     fa4:      	ldr	q1, [sp, #0x220]
     fa8:      	bit.16b	v1, v17, v23
     fac:      	str	q1, [sp, #0x220]
     fb0:      	mov.16b	v23, v5
     fb4:      	ldp	q15, q1, [sp, #0x200]
     fb8:      	bit.16b	v1, v19, v20
     fbc:      	movi.8b	v20, #0x1
     fc0:      	str	q1, [sp, #0x210]
     fc4:      	ldr	q24, [sp, #0x2f0]
     fc8:      	ldr	q27, [sp, #0x380]
     fcc:      	add	x4, sp, #0xdf0
     fd0:      	b	0xff8 <ltmp0+0xff8>
     fd4:      	tst	w11, #0xff
     fd8:      	b.ne	0xc38 <ltmp0+0xc38>
     fdc:      	b	0x2a8 <ltmp0+0x2a8>
     fe0:      	add	x4, sp, #0xdf0
     fe4:      	b	0x2a8 <ltmp0+0x2a8>
     fe8:      	str	w9, [x22, w19, uxtw #2]
     fec:      	add	w26, w19, #0x1
     ff0:      	str	w12, [x23, w19, uxtw #2]
     ff4:      	b	0x2a8 <ltmp0+0x2a8>
     ff8:      	shl.8b	v1, v21, #0x7
     ffc:      	cmlt.8b	v1, v1, #0
    1000:      	and.8b	v1, v1, v2
    1004:      	addv.8b	b1, v1
    1008:      	fmov	w13, s1
    100c:      	mov	w9, #0x8                ; =8
    1010:      	dup.2d	v3, x9
    1014:      	cmgt.2d	v1, v3, v8
    1018:      	cmgt.2d	v4, v3, v30
    101c:      	uzp1.4s	v1, v4, v1
    1020:      	cmgt.2d	v4, v3, v9
    1024:      	ldr	q5, [sp, #0x3e0]
    1028:      	cmgt.2d	v6, v3, v5
    102c:      	uzp1.4s	v4, v4, v6
    1030:      	uzp1.8h	v1, v1, v4
    1034:      	xtn.8b	v1, v1
    1038:      	and.8b	v1, v21, v1
    103c:      	shl.8b	v1, v1, #0x7
    1040:      	cmlt.8b	v4, v1, #0
    1044:      	and.8b	v1, v4, v2
    1048:      	addv.8b	b1, v1
    104c:      	fmov	w11, s1
    1050:      	umaxv.8b	b4, v4
    1054:      	fmov	w14, s4
    1058:      	tbz	w14, #0x0, 0x127c <ltmp0+0x127c>
    105c:      	cmge.2d	v4, v8, v3
    1060:      	cmge.2d	v6, v30, v3
    1064:      	uzp1.4s	v4, v6, v4
    1068:      	cmge.2d	v6, v9, v3
    106c:      	cmge.2d	v3, v5, v3
    1070:      	uzp1.4s	v3, v6, v3
    1074:      	uzp1.8h	v3, v4, v3
    1078:      	xtn.8b	v3, v3
    107c:      	and.8b	v3, v21, v3
    1080:      	shl.8b	v3, v3, #0x7
    1084:      	cmlt.8b	v3, v3, #0
    1088:      	and.8b	v3, v3, v2
    108c:      	addv.8b	b3, v3
    1090:      	fmov	w14, s3
    1094:      	tst	w14, #0xff
    1098:      	b.eq	0x127c <ltmp0+0x127c>
    109c:      	subs	w11, w12, #0x1
    10a0:      	csel	w11, wzr, w11, lo
    10a4:      	and	w13, w10, #0xff
    10a8:      	lsr	w14, w13, w11
    10ac:      	tst	w14, #0x1
    10b0:      	ldr	q4, [sp, #0x460]
    10b4:      	str	q4, [sp, #0x6a0]
    10b8:      	ldr	q4, [sp, #0x470]
    10bc:      	str	q4, [sp, #0x6b0]
    10c0:      	and	x11, x11, #0x7
    10c4:      	add	x9, sp, #0x6a0
    10c8:      	ldr	w11, [x9, x11, lsl #2]
    10cc:      	ccmp	w12, #0x0, #0x4, ne
    10d0:      	ccmp	w11, #0x1, #0x0, ne
    10d4:      	cset	w11, ne
    10d8:      	cmp	w13, #0xff
    10dc:      	b.ne	0x10e4 <ltmp0+0x10e4>
    10e0:      	tbnz	w11, #0x0, 0x541c <ltmp0+0x541c>
    10e4:      	mvn	w13, w10
    10e8:      	rbit	w13, w13
    10ec:      	clz	w13, w13
    10f0:      	mov	w9, #0xff               ; =255
    10f4:      	bics	wzr, w9, w10
    10f8:      	csel	w13, wzr, w13, eq
    10fc:      	ubfiz	x14, x13, #2, #3
    1100:      	lsl	w17, w20, w13
    1104:      	ldr	q5, [sp, #0x460]
    1108:      	str	q5, [sp, #0x680]
    110c:      	ldr	q4, [sp, #0x470]
    1110:      	str	q4, [sp, #0x690]
    1114:      	add	x9, sp, #0x680
    1118:      	ldr	w1, [x9, x14]
    111c:      	cmp	w11, #0x0
    1120:      	csel	w11, w17, wzr, ne
    1124:      	csinc	w17, w1, wzr, eq
    1128:      	str	q5, [sp, #0x660]
    112c:      	str	q4, [sp, #0x670]
    1130:      	add	x9, sp, #0x660
    1134:      	str	w17, [x9, x14]
    1138:      	ldr	q4, [sp, #0x670]
    113c:      	str	q4, [sp, #0x470]
    1140:      	ldr	q4, [sp, #0x660]
    1144:      	str	q4, [sp, #0x460]
    1148:      	ldr	q5, [sp, #0x440]
    114c:      	str	q5, [sp, #0x640]
    1150:      	ldr	q4, [sp, #0x450]
    1154:      	str	q4, [sp, #0x650]
    1158:      	add	x9, sp, #0x640
    115c:      	ldr	w17, [x9, x14]
    1160:      	csel	w17, w12, w17, ne
    1164:      	str	q5, [sp, #0x620]
    1168:      	str	q4, [sp, #0x630]
    116c:      	add	x9, sp, #0x620
    1170:      	str	w17, [x9, x14]
    1174:      	ldrb	w14, [x27, x13]
    1178:      	and	w17, w14, #0x1
    117c:      	fmov	s4, w17
    1180:      	ubfx	w17, w14, #1, #1
    1184:      	mov.b	v4[1], w17
    1188:      	ubfx	w17, w14, #2, #1
    118c:      	mov.b	v4[2], w17
    1190:      	ubfx	w17, w14, #3, #1
    1194:      	mov.b	v4[3], w17
    1198:      	ubfx	w17, w14, #4, #1
    119c:      	mov.b	v4[4], w17
    11a0:      	ubfx	w17, w14, #5, #1
    11a4:      	mov.b	v4[5], w17
    11a8:      	ubfx	w17, w14, #6, #1
    11ac:      	mov.b	v4[6], w17
    11b0:      	ldr	q5, [sp, #0x630]
    11b4:      	str	q5, [sp, #0x450]
    11b8:      	ldr	q5, [sp, #0x620]
    11bc:      	str	q5, [sp, #0x440]
    11c0:      	lsr	w14, w14, #7
    11c4:      	mov.b	v4[7], w14
    11c8:      	ldrb	w14, [x8, x13]
    11cc:      	and	w17, w14, #0x1
    11d0:      	fmov	s6, w17
    11d4:      	ubfx	w17, w14, #1, #1
    11d8:      	mov.b	v6[1], w17
    11dc:      	ubfx	w17, w14, #2, #1
    11e0:      	mov.b	v6[2], w17
    11e4:      	ubfx	w17, w14, #3, #1
    11e8:      	mov.b	v6[3], w17
    11ec:      	ubfx	w17, w14, #4, #1
    11f0:      	mov.b	v6[4], w17
    11f4:      	ubfx	w17, w14, #5, #1
    11f8:      	mov.b	v6[5], w17
    11fc:      	ubfx	w17, w14, #6, #1
    1200:      	mov.b	v6[6], w17
    1204:      	lsr	w14, w14, #7
    1208:      	mov.b	v6[7], w14
    120c:      	csetm	w14, ne
    1210:      	dup.8b	v7, w14
    1214:      	bit.8b	v4, v21, v7
    1218:      	shl.8b	v4, v4, #0x7
    121c:      	cmlt.8b	v4, v4, #0
    1220:      	and.8b	v4, v4, v2
    1224:      	addv.8b	b4, v4
    1228:      	str	b4, [x27, x13]
    122c:      	bic.8b	v4, v6, v7
    1230:      	shl.8b	v4, v4, #0x7
    1234:      	cmlt.8b	v4, v4, #0
    1238:      	and.8b	v4, v4, v2
    123c:      	addv.8b	b4, v4
    1240:      	str	b4, [x8, x13]
    1244:      	csinc	w12, w12, w13, eq
    1248:      	cmp	w26, #0x8
    124c:      	b.hs	0x541c <ltmp0+0x541c>
    1250:      	str	b1, [x21, x28]
    1254:      	mov	w9, #0x7                ; =7
    1258:      	str	w9, [x22, x28, lsl #2]
    125c:      	str	w12, [x23, x28, lsl #2]
    1260:      	cmp	w19, #0x8
    1264:      	b.hs	0x541c <ltmp0+0x541c>
    1268:      	str	b3, [x21, w19, uxtw]
    126c:      	orr	w10, w11, w10
    1270:      	mov	w9, #0x8                ; =8
    1274:      	str	w9, [x22, w19, uxtw #2]
    1278:      	b	0xfec <ltmp0+0xfec>
    127c:      	tst	w11, #0xff
    1280:      	b.eq	0x1890 <ltmp0+0x1890>
    1284:      	tst	w13, #0xff
    1288:      	b.eq	0x2a8 <ltmp0+0x2a8>
    128c:      	mov	w11, #0x0               ; =0
    1290:      	mov.16b	v1, v29
    1294:      	mov.16b	v29, v25
    1298:      	mov.16b	v5, v18
    129c:      	str	q31, [sp, #0xb0]
    12a0:      	stp	q22, q24, [sp, #0x2e0]
    12a4:      	str	q10, [sp, #0x90]
    12a8:      	str	q15, [sp, #0x200]
    12ac:      	str	d12, [sp, #0x298]
    12b0:      	str	q23, [sp, #0x2c0]
    12b4:      	str	q1, [sp, #0x280]
    12b8:      	ldp	q0, q12, [sp, #0x390]
    12bc:      	str	q30, [sp, #0xe0]
    12c0:      	shl.2d	v1, v30, #0x5
    12c4:      	shl.2d	v6, v8, #0x5
    12c8:      	shl.2d	v3, v9, #0x5
    12cc:      	ldr	q4, [sp, #0x3e0]
    12d0:      	shl.2d	v4, v4, #0x5
    12d4:      	ldr	q7, [sp, #0x340]
    12d8:      	add.2d	v4, v4, v7
    12dc:      	ldr	q7, [sp, #0x350]
    12e0:      	add.2d	v3, v3, v7
    12e4:      	ldr	q7, [sp, #0x360]
    12e8:      	add.2d	v16, v6, v7
    12ec:      	ldr	q6, [sp, #0x370]
    12f0:      	add.2d	v17, v1, v6
    12f4:      	ldp	q1, q22, [sp, #0x1a0]
    12f8:      	add.2d	v25, v1, v17
    12fc:      	ldp	q1, q6, [sp, #0x180]
    1300:      	add.2d	v23, v6, v16
    1304:      	add.2d	v20, v1, v3
    1308:      	ldr	q1, [sp, #0x170]
    130c:      	add.2d	v6, v1, v4
    1310:      	shl.8b	v1, v21, #0x7
    1314:      	cmlt.8b	v1, v1, #0
    1318:      	and.8b	v1, v1, v2
    131c:      	addv.8b	b7, v1
    1320:      	fmov	w13, s7
    1324:      	movi.2d	v1, #0000000000000000
    1328:      	movi.2d	v19, #0000000000000000
    132c:      	str	q14, [sp, #0x300]
    1330:      	str	q29, [sp, #0x2d0]
    1334:      	stp	q27, q0, [sp, #0x380]
    1338:      	stp	q8, q9, [sp, #0xc0]
    133c:      	str	q11, [sp, #0xa0]
    1340:      	stp	q26, q13, [sp, #0x2a0]
    1344:      	str	q28, [sp, #0x160]
    1348:      	tbz	w13, #0x0, 0x139c <ltmp0+0x139c>
    134c:      	fmov	x14, d25
    1350:      	ldr	s1, [x14]
    1354:      	tbnz	w13, #0x1, 0x13a0 <ltmp0+0x13a0>
    1358:      	tbz	w13, #0x2, 0x13ac <ltmp0+0x13ac>
    135c:      	fmov	x14, d23
    1360:      	ld1.s	{ v1 }[2], [x14]
    1364:      	tbnz	w13, #0x3, 0x13b0 <ltmp0+0x13b0>
    1368:      	ldr	q23, [sp, #0x270]
    136c:      	tbz	w13, #0x4, 0x13c0 <ltmp0+0x13c0>
    1370:      	ldr	q8, [sp, #0x430]
    1374:      	ldr	q18, [sp, #0x420]
    1378:      	ldp	q11, q26, [sp, #0x3c0]
    137c:      	ldr	q24, [sp, #0x410]
    1380:      	fmov	x14, d20
    1384:      	ld1.s	{ v19 }[0], [x14]
    1388:      	mov.16b	v10, v23
    138c:      	mov.16b	v13, v12
    1390:      	ldr	q27, [sp, #0x310]
    1394:      	tbnz	w13, #0x5, 0x13e0 <ltmp0+0x13e0>
    1398:      	b	0x13e8 <ltmp0+0x13e8>
    139c:      	tbz	w13, #0x1, 0x1358 <ltmp0+0x1358>
    13a0:      	mov.d	x14, v25[1]
    13a4:      	ld1.s	{ v1 }[1], [x14]
    13a8:      	tbnz	w13, #0x2, 0x135c <ltmp0+0x135c>
    13ac:      	tbz	w13, #0x3, 0x1368 <ltmp0+0x1368>
    13b0:      	mov.d	x14, v23[1]
    13b4:      	ld1.s	{ v1 }[3], [x14]
    13b8:      	ldr	q23, [sp, #0x270]
    13bc:      	tbnz	w13, #0x4, 0x1370 <ltmp0+0x1370>
    13c0:      	ldr	q8, [sp, #0x430]
    13c4:      	ldr	q18, [sp, #0x420]
    13c8:      	ldp	q11, q26, [sp, #0x3c0]
    13cc:      	ldr	q24, [sp, #0x410]
    13d0:      	mov.16b	v10, v23
    13d4:      	mov.16b	v13, v12
    13d8:      	ldr	q27, [sp, #0x310]
    13dc:      	tbz	w13, #0x5, 0x13e8 <ltmp0+0x13e8>
    13e0:      	mov.d	x14, v20[1]
    13e4:      	ld1.s	{ v19 }[1], [x14]
    13e8:      	ldr	q20, [sp, #0x3e0]
    13ec:      	str	q20, [sp, #0x3e0]
    13f0:      	tbz	w13, #0x6, 0x1404 <ltmp0+0x1404>
    13f4:      	fmov	x14, d6
    13f8:      	ld1.s	{ v19 }[2], [x14]
    13fc:      	tbnz	w13, #0x7, 0x1408 <ltmp0+0x1408>
    1400:      	b	0x1410 <ltmp0+0x1410>
    1404:      	tbz	w13, #0x7, 0x1410 <ltmp0+0x1410>
    1408:      	mov.d	x13, v6[1]
    140c:      	ld1.s	{ v19 }[3], [x13]
    1410:      	fmul.4s	v6, v19, v19
    1414:      	fmul.4s	v1, v1, v1
    1418:      	fadd.4s	v0, v10, v1
    141c:      	ldr	q1, [sp, #0x160]
    1420:      	fadd.4s	v1, v1, v6
    1424:      	stp	q1, q0, [sp, #0x130]
    1428:      	ldp	q0, q1, [sp, #0x170]
    142c:      	add.2d	v23, v4, v0
    1430:      	add.2d	v3, v3, v1
    1434:      	ldp	q1, q0, [sp, #0x190]
    1438:      	add.2d	v4, v17, v0
    143c:      	add.2d	v20, v16, v1
    1440:      	mov	w9, #0x20               ; =32
    1444:      	dup.2d	v16, x9
    1448:      	add.2d	v25, v20, v16
    144c:      	add.2d	v31, v4, v16
    1450:      	add.2d	v30, v3, v16
    1454:      	add.2d	v19, v23, v16
    1458:      	fmov	w13, s7
    145c:      	movi.2d	v16, #0000000000000000
    1460:      	movi.2d	v17, #0000000000000000
    1464:      	ldr	d1, [sp, #0x298]
    1468:      	tbz	w13, #0x0, 0x14cc <ltmp0+0x14cc>
    146c:      	fmov	x14, d31
    1470:      	ldr	s16, [x14]
    1474:      	tbnz	w13, #0x1, 0x14d0 <ltmp0+0x14d0>
    1478:      	str	q8, [sp, #0x430]
    147c:      	tbz	w13, #0x2, 0x14e0 <ltmp0+0x14e0>
    1480:      	fmov	x14, d25
    1484:      	ld1.s	{ v16 }[2], [x14]
    1488:      	str	q18, [sp, #0x420]
    148c:      	tbnz	w13, #0x3, 0x14e8 <ltmp0+0x14e8>
    1490:      	ldr	q12, [sp, #0x330]
    1494:      	tbz	w13, #0x4, 0x14f8 <ltmp0+0x14f8>
    1498:      	fmov	x14, d30
    149c:      	ld1.s	{ v17 }[0], [x14]
    14a0:      	stp	q11, q26, [sp, #0x3c0]
    14a4:      	str	q24, [sp, #0x410]
    14a8:      	tbnz	w13, #0x5, 0x1504 <ltmp0+0x1504>
    14ac:      	tbz	w13, #0x6, 0x1510 <ltmp0+0x1510>
    14b0:      	fmov	x14, d19
    14b4:      	ld1.s	{ v17 }[2], [x14]
    14b8:      	ldr	q15, [sp, #0x320]
    14bc:      	stp	q15, q12, [sp, #0x320]
    14c0:      	tbnz	w13, #0x7, 0x151c <ltmp0+0x151c>
    14c4:      	ldr	q8, [sp, #0x280]
    14c8:      	b	0x1528 <ltmp0+0x1528>
    14cc:      	tbz	w13, #0x1, 0x1478 <ltmp0+0x1478>
    14d0:      	mov.d	x14, v31[1]
    14d4:      	ld1.s	{ v16 }[1], [x14]
    14d8:      	str	q8, [sp, #0x430]
    14dc:      	tbnz	w13, #0x2, 0x1480 <ltmp0+0x1480>
    14e0:      	str	q18, [sp, #0x420]
    14e4:      	tbz	w13, #0x3, 0x1490 <ltmp0+0x1490>
    14e8:      	mov.d	x14, v25[1]
    14ec:      	ld1.s	{ v16 }[3], [x14]
    14f0:      	ldr	q12, [sp, #0x330]
    14f4:      	tbnz	w13, #0x4, 0x1498 <ltmp0+0x1498>
    14f8:      	stp	q11, q26, [sp, #0x3c0]
    14fc:      	str	q24, [sp, #0x410]
    1500:      	tbz	w13, #0x5, 0x14ac <ltmp0+0x14ac>
    1504:      	mov.d	x14, v30[1]
    1508:      	ld1.s	{ v17 }[1], [x14]
    150c:      	tbnz	w13, #0x6, 0x14b0 <ltmp0+0x14b0>
    1510:      	ldr	q15, [sp, #0x320]
    1514:      	stp	q15, q12, [sp, #0x320]
    1518:      	tbz	w13, #0x7, 0x14c4 <ltmp0+0x14c4>
    151c:      	ldr	q8, [sp, #0x280]
    1520:      	mov.d	x13, v19[1]
    1524:      	ld1.s	{ v17 }[3], [x13]
    1528:      	fmul.4s	v17, v17, v17
    152c:      	fmul.4s	v16, v16, v16
    1530:      	fadd.4s	v0, v13, v16
    1534:      	fadd.4s	v6, v5, v17
    1538:      	stp	q6, q0, [sp, #0x110]
    153c:      	mov	w9, #0x40               ; =64
    1540:      	dup.2d	v16, x9
    1544:      	add.2d	v31, v20, v16
    1548:      	add.2d	v12, v4, v16
    154c:      	add.2d	v25, v3, v16
    1550:      	add.2d	v30, v23, v16
    1554:      	fmov	w13, s7
    1558:      	movi.2d	v16, #0000000000000000
    155c:      	movi.2d	v17, #0000000000000000
    1560:      	tbz	w13, #0x0, 0x15a4 <ltmp0+0x15a4>
    1564:      	fmov	x14, d12
    1568:      	ldr	s16, [x14]
    156c:      	tbnz	w13, #0x1, 0x15a8 <ltmp0+0x15a8>
    1570:      	tbz	w13, #0x2, 0x15b4 <ltmp0+0x15b4>
    1574:      	fmov	x14, d31
    1578:      	ld1.s	{ v16 }[2], [x14]
    157c:      	tbnz	w13, #0x3, 0x15b8 <ltmp0+0x15b8>
    1580:      	tbz	w13, #0x4, 0x15c4 <ltmp0+0x15c4>
    1584:      	fmov	x14, d25
    1588:      	ld1.s	{ v17 }[0], [x14]
    158c:      	tbnz	w13, #0x5, 0x15c8 <ltmp0+0x15c8>
    1590:      	tbz	w13, #0x6, 0x15d4 <ltmp0+0x15d4>
    1594:      	fmov	x14, d30
    1598:      	ld1.s	{ v17 }[2], [x14]
    159c:      	tbnz	w13, #0x7, 0x15d8 <ltmp0+0x15d8>
    15a0:      	b	0x15e0 <ltmp0+0x15e0>
    15a4:      	tbz	w13, #0x1, 0x1570 <ltmp0+0x1570>
    15a8:      	mov.d	x14, v12[1]
    15ac:      	ld1.s	{ v16 }[1], [x14]
    15b0:      	tbnz	w13, #0x2, 0x1574 <ltmp0+0x1574>
    15b4:      	tbz	w13, #0x3, 0x1580 <ltmp0+0x1580>
    15b8:      	mov.d	x14, v31[1]
    15bc:      	ld1.s	{ v16 }[3], [x14]
    15c0:      	tbnz	w13, #0x4, 0x1584 <ltmp0+0x1584>
    15c4:      	tbz	w13, #0x5, 0x1590 <ltmp0+0x1590>
    15c8:      	mov.d	x14, v25[1]
    15cc:      	ld1.s	{ v17 }[1], [x14]
    15d0:      	tbnz	w13, #0x6, 0x1594 <ltmp0+0x1594>
    15d4:      	tbz	w13, #0x7, 0x15e0 <ltmp0+0x15e0>
    15d8:      	mov.d	x13, v30[1]
    15dc:      	ld1.s	{ v17 }[3], [x13]
    15e0:      	fmul.4s	v17, v17, v17
    15e4:      	fmul.4s	v16, v16, v16
    15e8:      	fadd.4s	v16, v27, v16
    15ec:      	fadd.4s	v17, v22, v17
    15f0:      	mov	w9, #0x60               ; =96
    15f4:      	dup.2d	v12, x9
    15f8:      	add.2d	v30, v20, v12
    15fc:      	add.2d	v31, v4, v12
    1600:      	add.2d	v25, v3, v12
    1604:      	add.2d	v20, v23, v12
    1608:      	fmov	w13, s7
    160c:      	movi.2d	v3, #0000000000000000
    1610:      	movi.2d	v4, #0000000000000000
    1614:      	tbz	w13, #0x0, 0x1658 <ltmp0+0x1658>
    1618:      	fmov	x14, d31
    161c:      	ldr	s3, [x14]
    1620:      	tbnz	w13, #0x1, 0x165c <ltmp0+0x165c>
    1624:      	ldr	q0, [sp, #0x3b0]
    1628:      	ldr	q19, [sp, #0x200]
    162c:      	fmov	d12, d1
    1630:      	ldr	q6, [sp, #0x90]
    1634:      	tbz	w13, #0x2, 0x1678 <ltmp0+0x1678>
    1638:      	fmov	x14, d30
    163c:      	ld1.s	{ v3 }[2], [x14]
    1640:      	ldr	q9, [sp, #0x2f0]
    1644:      	ldr	q23, [sp, #0x3e0]
    1648:      	ldr	q26, [sp, #0x210]
    164c:      	ldr	q31, [sp, #0xb0]
    1650:      	tbnz	w13, #0x3, 0x168c <ltmp0+0x168c>
    1654:      	b	0x1694 <ltmp0+0x1694>
    1658:      	tbz	w13, #0x1, 0x1624 <ltmp0+0x1624>
    165c:      	mov.d	x14, v31[1]
    1660:      	ld1.s	{ v3 }[1], [x14]
    1664:      	ldr	q0, [sp, #0x3b0]
    1668:      	ldr	q19, [sp, #0x200]
    166c:      	fmov	d12, d1
    1670:      	ldr	q6, [sp, #0x90]
    1674:      	tbnz	w13, #0x2, 0x1638 <ltmp0+0x1638>
    1678:      	ldr	q9, [sp, #0x2f0]
    167c:      	ldr	q23, [sp, #0x3e0]
    1680:      	ldr	q26, [sp, #0x210]
    1684:      	ldr	q31, [sp, #0xb0]
    1688:      	tbz	w13, #0x3, 0x1694 <ltmp0+0x1694>
    168c:      	mov.d	x14, v30[1]
    1690:      	ld1.s	{ v3 }[3], [x14]
    1694:      	ldr	q1, [sp, #0x220]
    1698:      	mov.16b	v18, v27
    169c:      	mov.16b	v14, v22
    16a0:      	mov.16b	v22, v13
    16a4:      	mov.16b	v24, v5
    16a8:      	mov.16b	v11, v10
    16ac:      	ldr	q28, [sp, #0x160]
    16b0:      	ldp	q7, q5, [sp, #0xc0]
    16b4:      	tbz	w13, #0x4, 0x16ec <ltmp0+0x16ec>
    16b8:      	fmov	x14, d25
    16bc:      	ld1.s	{ v4 }[0], [x14]
    16c0:      	ldr	q29, [sp, #0x380]
    16c4:      	ldp	q10, q13, [sp, #0x2a0]
    16c8:      	ldr	q15, [sp, #0x400]
    16cc:      	mov.16b	v27, v7
    16d0:      	tbnz	w13, #0x5, 0x1700 <ltmp0+0x1700>
    16d4:      	ldr	q30, [sp, #0xe0]
    16d8:      	tbz	w13, #0x6, 0x1710 <ltmp0+0x1710>
    16dc:      	fmov	x14, d20
    16e0:      	ld1.s	{ v4 }[2], [x14]
    16e4:      	tbnz	w13, #0x7, 0x1714 <ltmp0+0x1714>
    16e8:      	b	0x171c <ltmp0+0x171c>
    16ec:      	ldr	q29, [sp, #0x380]
    16f0:      	ldp	q10, q13, [sp, #0x2a0]
    16f4:      	ldr	q15, [sp, #0x400]
    16f8:      	mov.16b	v27, v7
    16fc:      	tbz	w13, #0x5, 0x16d4 <ltmp0+0x16d4>
    1700:      	mov.d	x14, v25[1]
    1704:      	ld1.s	{ v4 }[1], [x14]
    1708:      	ldr	q30, [sp, #0xe0]
    170c:      	tbnz	w13, #0x6, 0x16dc <ltmp0+0x16dc>
    1710:      	tbz	w13, #0x7, 0x171c <ltmp0+0x171c>
    1714:      	mov.d	x13, v20[1]
    1718:      	ld1.s	{ v4 }[3], [x13]
    171c:      	fmul.4s	v4, v4, v4
    1720:      	fmul.4s	v3, v3, v3
    1724:      	fadd.4s	v3, v26, v3
    1728:      	mov	w9, #0x4                ; =4
    172c:      	dup.2d	v7, x9
    1730:      	mov	b20, v21[6]
    1734:      	mov.b	v20[4], v21[7]
    1738:      	ushll.2d	v20, v20, #0x0
    173c:      	shl.2d	v20, v20, #0x3f
    1740:      	cmlt.2d	v20, v20, #0
    1744:      	and.16b	v20, v20, v7
    1748:      	add.2d	v23, v23, v20
    174c:      	str	q23, [sp, #0x3e0]
    1750:      	mov	b20, v21[4]
    1754:      	mov.b	v20[4], v21[5]
    1758:      	ushll.2d	v20, v20, #0x0
    175c:      	shl.2d	v20, v20, #0x3f
    1760:      	cmlt.2d	v20, v20, #0
    1764:      	and.16b	v20, v20, v7
    1768:      	add.2d	v5, v5, v20
    176c:      	mov	b20, v21[2]
    1770:      	mov.b	v20[4], v21[3]
    1774:      	fadd.4s	v4, v1, v4
    1778:      	ushll.2d	v20, v20, #0x0
    177c:      	shl.2d	v20, v20, #0x3f
    1780:      	cmlt.2d	v20, v20, #0
    1784:      	and.16b	v20, v20, v7
    1788:      	add.2d	v27, v27, v20
    178c:      	mov	b20, v21[0]
    1790:      	mov.b	v20[4], v21[1]
    1794:      	ushll.2d	v20, v20, #0x0
    1798:      	shl.2d	v20, v20, #0x3f
    179c:      	cmlt.2d	v20, v20, #0
    17a0:      	and.16b	v7, v20, v7
    17a4:      	add.2d	v30, v30, v7
    17a8:      	zip1.8b	v7, v21, v0
    17ac:      	ushll.4s	v7, v7, #0x0
    17b0:      	shl.4s	v7, v7, #0x1f
    17b4:      	cmlt.4s	v7, v7, #0
    17b8:      	zip2.8b	v20, v21, v0
    17bc:      	ushll.4s	v20, v20, #0x0
    17c0:      	shl.4s	v20, v20, #0x1f
    17c4:      	cmlt.4s	v20, v20, #0
    17c8:      	ldp	q25, q23, [sp, #0x130]
    17cc:      	bit.16b	v28, v25, v20
    17d0:      	bit.16b	v11, v23, v7
    17d4:      	str	q11, [sp, #0x270]
    17d8:      	ldp	q25, q23, [sp, #0x110]
    17dc:      	bit.16b	v24, v25, v20
    17e0:      	bit.16b	v22, v23, v7
    17e4:      	stp	q22, q0, [sp, #0x3a0]
    17e8:      	bit.16b	v14, v17, v20
    17ec:      	str	q14, [sp, #0x1b0]
    17f0:      	bit.16b	v18, v16, v7
    17f4:      	str	q18, [sp, #0x310]
    17f8:      	bit.16b	v1, v4, v20
    17fc:      	bit.16b	v26, v3, v7
    1800:      	stp	q26, q1, [sp, #0x210]
    1804:      	str	q15, [sp, #0x400]
    1808:      	movi.8b	v20, #0x1
    180c:      	tbz	w11, #0x0, 0x1850 <ltmp0+0x1850>
    1810:      	ldp	q23, q25, [sp, #0x2c0]
    1814:      	ldr	q14, [sp, #0x300]
    1818:      	ldr	q22, [sp, #0x2e0]
    181c:      	ldr	q11, [sp, #0xa0]
    1820:      	mov.16b	v3, v8
    1824:      	mov.16b	v0, v9
    1828:      	mov.16b	v9, v5
    182c:      	mov.16b	v15, v19
    1830:      	mov.16b	v8, v27
    1834:      	mov.16b	v18, v24
    1838:      	mov.16b	v24, v0
    183c:      	mov.16b	v26, v10
    1840:      	mov.16b	v10, v6
    1844:      	mov.16b	v27, v29
    1848:      	mov.16b	v29, v3
    184c:      	b	0x2a8 <ltmp0+0x2a8>
    1850:      	ldp	q23, q25, [sp, #0x2c0]
    1854:      	ldr	q14, [sp, #0x300]
    1858:      	ldr	q22, [sp, #0x2e0]
    185c:      	ldr	q11, [sp, #0xa0]
    1860:      	mov.16b	v3, v8
    1864:      	mov.16b	v0, v9
    1868:      	mov.16b	v9, v5
    186c:      	mov.16b	v15, v19
    1870:      	mov.16b	v8, v27
    1874:      	mov.16b	v18, v24
    1878:      	mov.16b	v24, v0
    187c:      	mov.16b	v26, v10
    1880:      	mov.16b	v10, v6
    1884:      	mov.16b	v27, v29
    1888:      	mov.16b	v29, v3
    188c:      	b	0xff8 <ltmp0+0xff8>
    1890:      	tst	w13, #0xff
    1894:      	b.eq	0x2a8 <ltmp0+0x2a8>
    1898:      	cbz	w12, 0x1a70 <ltmp0+0x1a70>
    189c:      	mov	w13, #0x0               ; =0
    18a0:      	shl.8b	v1, v21, #0x7
    18a4:      	cmlt.8b	v1, v1, #0
    18a8:      	and.8b	v3, v1, v2
    18ac:      	addv.8b	b3, v3
    18b0:      	fmov	w11, s3
    18b4:      	umaxv.8b	b1, v1
    18b8:      	fmov	w2, s1
    18bc:      	sub	w14, w12, #0x1
    18c0:      	tst	w11, #0xff
    18c4:      	csel	w14, w14, wzr, ne
    18c8:      	lsl	w17, w20, w14
    18cc:      	and	w11, w17, w10
    18d0:      	tst	w11, #0xff
    18d4:      	cset	w4, ne
    18d8:      	ldr	q1, [sp, #0x460]
    18dc:      	str	q1, [sp, #0x1100]
    18e0:      	ldr	q1, [sp, #0x470]
    18e4:      	str	q1, [sp, #0x1110]
    18e8:      	ubfiz	x11, x14, #2, #3
    18ec:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    18f0:      	add	x9, x9, #0x100
    18f4:      	ldr	w1, [x9, x11]
    18f8:      	cmp	w1, #0x1
    18fc:      	cset	w1, eq
    1900:      	and	w2, w4, w2
    1904:      	ldrb	w4, [x27, w14, sxtw]
    1908:      	and	w5, w4, #0x1
    190c:      	fmov	s1, w5
    1910:      	ubfx	w5, w4, #1, #1
    1914:      	mov.b	v1[1], w5
    1918:      	ubfx	w5, w4, #2, #1
    191c:      	mov.b	v1[2], w5
    1920:      	ubfx	w5, w4, #3, #1
    1924:      	mov.b	v1[3], w5
    1928:      	ubfx	w5, w4, #4, #1
    192c:      	mov.b	v1[4], w5
    1930:      	ubfx	w5, w4, #5, #1
    1934:      	mov.b	v1[5], w5
    1938:      	ubfx	w5, w4, #6, #1
    193c:      	mov.b	v1[6], w5
    1940:      	lsr	w4, w4, #7
    1944:      	mov.b	v1[7], w4
    1948:      	ldrb	w4, [x8, w14, sxtw]
    194c:      	and	w5, w4, #0x1
    1950:      	fmov	s3, w5
    1954:      	ubfx	w5, w4, #1, #1
    1958:      	mov.b	v3[1], w5
    195c:      	ubfx	w5, w4, #2, #1
    1960:      	mov.b	v3[2], w5
    1964:      	ubfx	w5, w4, #3, #1
    1968:      	mov.b	v3[3], w5
    196c:      	ubfx	w5, w4, #4, #1
    1970:      	mov.b	v3[4], w5
    1974:      	ubfx	w5, w4, #5, #1
    1978:      	mov.b	v3[5], w5
    197c:      	ubfx	w5, w4, #6, #1
    1980:      	mov.b	v3[6], w5
    1984:      	lsr	w4, w4, #7
    1988:      	mov.b	v3[7], w4
    198c:      	orr.8b	v4, v21, v3
    1990:      	and.8b	v6, v12, v1
    1994:      	eor.8b	v6, v6, v4
    1998:      	shl.8b	v6, v6, #0x7
    199c:      	cmlt.8b	v6, v6, #0
    19a0:      	umaxv.8b	b6, v6
    19a4:      	fmov	w4, s6
    19a8:      	ands	w1, w2, w1
    19ac:      	csetm	w2, ne
    19b0:      	bics	w4, w1, w4
    19b4:      	csetm	w5, ne
    19b8:      	dup.8b	v6, w5
    19bc:      	mov	w5, #-0x1               ; =-1
    19c0:      	dup.8b	v7, w2
    19c4:      	bic.8b	v16, v4, v6
    19c8:      	bit.8b	v3, v16, v7
    19cc:      	shl.8b	v3, v3, #0x7
    19d0:      	cmlt.8b	v3, v3, #0
    19d4:      	and.8b	v3, v3, v2
    19d8:      	addv.8b	b3, v3
    19dc:      	str	b3, [x8, w14, sxtw]
    19e0:      	bic.8b	v1, v1, v6
    19e4:      	shl.8b	v1, v1, #0x7
    19e8:      	cmlt.8b	v1, v1, #0
    19ec:      	and.8b	v1, v1, v2
    19f0:      	addv.8b	b1, v1
    19f4:      	str	b1, [x27, w14, sxtw]
    19f8:      	csinv	w14, w5, w17, eq
    19fc:      	dup.8b	v1, w1
    1a00:      	and	w10, w14, w10
    1a04:      	shl.8b	v1, v1, #0x7
    1a08:      	cmlt.8b	v1, v1, #0
    1a0c:      	dup.8b	v3, w4
    1a10:      	and.8b	v3, v3, v4
    1a14:      	ldr	q4, [sp, #0x440]
    1a18:      	str	q4, [sp, #0x10e0]
    1a1c:      	ldr	q4, [sp, #0x450]
    1a20:      	str	q4, [sp, #0x10f0]
    1a24:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    1a28:      	add	x9, x9, #0xe0
    1a2c:      	ldr	w11, [x9, x11]
    1a30:      	csel	w12, w11, w12, ne
    1a34:      	bit.8b	v21, v3, v1
    1a38:      	shl.8b	v1, v21, #0x7
    1a3c:      	cmlt.8b	v1, v1, #0
    1a40:      	and.8b	v1, v1, v2
    1a44:      	addv.8b	b1, v1
    1a48:      	fmov	w11, s1
    1a4c:      	cmp	w1, #0x1
    1a50:      	b.ne	0x1a84 <ltmp0+0x1a84>
    1a54:      	cmp	w12, #0x0
    1a58:      	ccmp	w13, #0x6, #0x2, ne
    1a5c:      	b.hi	0x1a84 <ltmp0+0x1a84>
    1a60:      	add	w13, w13, #0x1
    1a64:      	tst	w11, #0xff
    1a68:      	b.ne	0x18a0 <ltmp0+0x18a0>
    1a6c:      	b	0x1a84 <ltmp0+0x1a84>
    1a70:      	shl.8b	v1, v21, #0x7
    1a74:      	cmlt.8b	v1, v1, #0
    1a78:      	and.8b	v1, v1, v2
    1a7c:      	addv.8b	b1, v1
    1a80:      	fmov	w11, s1
    1a84:      	tst	w11, #0xff
    1a88:      	b.eq	0xfe0 <ltmp0+0xfe0>
    1a8c:      	and.8b	v1, v15, v21
    1a90:      	shl.8b	v1, v1, #0x7
    1a94:      	cmlt.8b	v1, v1, #0
    1a98:      	and.8b	v3, v1, v2
    1a9c:      	addv.8b	b4, v3
    1aa0:      	umaxv.8b	b1, v1
    1aa4:      	fmov	w13, s1
    1aa8:      	add	x4, sp, #0xdf0
    1aac:      	tbz	w13, #0x0, 0x1cf0 <ltmp0+0x1cf0>
    1ab0:      	bic.8b	v3, v21, v15
    1ab4:      	shl.8b	v1, v3, #0x7
    1ab8:      	cmlt.8b	v1, v1, #0
    1abc:      	and.8b	v1, v1, v2
    1ac0:      	addv.8b	b1, v1
    1ac4:      	fmov	w13, s1
    1ac8:      	tst	w13, #0xff
    1acc:      	b.eq	0x1cf0 <ltmp0+0x1cf0>
    1ad0:      	subs	w11, w12, #0x1
    1ad4:      	csel	w11, wzr, w11, lo
    1ad8:      	and	w13, w10, #0xff
    1adc:      	lsr	w14, w13, w11
    1ae0:      	tst	w14, #0x1
    1ae4:      	ldr	q5, [sp, #0x460]
    1ae8:      	str	q5, [sp, #0x740]
    1aec:      	ldr	q5, [sp, #0x470]
    1af0:      	str	q5, [sp, #0x750]
    1af4:      	and	x11, x11, #0x7
    1af8:      	add	x9, sp, #0x740
    1afc:      	ldr	w11, [x9, x11, lsl #2]
    1b00:      	ccmp	w12, #0x0, #0x4, ne
    1b04:      	ccmp	w11, #0x2, #0x0, ne
    1b08:      	cset	w11, ne
    1b0c:      	cmp	w13, #0xff
    1b10:      	b.ne	0x1b18 <ltmp0+0x1b18>
    1b14:      	tbnz	w11, #0x0, 0x541c <ltmp0+0x541c>
    1b18:      	mvn	w13, w10
    1b1c:      	rbit	w13, w13
    1b20:      	clz	w13, w13
    1b24:      	mov	w9, #0xff               ; =255
    1b28:      	bics	wzr, w9, w10
    1b2c:      	csel	w13, wzr, w13, eq
    1b30:      	ubfiz	x14, x13, #2, #3
    1b34:      	lsl	w17, w20, w13
    1b38:      	ldr	q6, [sp, #0x460]
    1b3c:      	str	q6, [sp, #0x720]
    1b40:      	ldr	q5, [sp, #0x470]
    1b44:      	str	q5, [sp, #0x730]
    1b48:      	add	x9, sp, #0x720
    1b4c:      	ldr	w1, [x9, x14]
    1b50:      	cmp	w11, #0x0
    1b54:      	csel	w11, w17, wzr, ne
    1b58:      	mov	w9, #0x2                ; =2
    1b5c:      	csel	w17, w9, w1, ne
    1b60:      	str	q6, [sp, #0x700]
    1b64:      	str	q5, [sp, #0x710]
    1b68:      	add	x9, sp, #0x700
    1b6c:      	str	w17, [x9, x14]
    1b70:      	ldr	q5, [sp, #0x710]
    1b74:      	str	q5, [sp, #0x470]
    1b78:      	ldr	q5, [sp, #0x700]
    1b7c:      	str	q5, [sp, #0x460]
    1b80:      	ldr	q6, [sp, #0x440]
    1b84:      	str	q6, [sp, #0x6e0]
    1b88:      	ldr	q5, [sp, #0x450]
    1b8c:      	str	q5, [sp, #0x6f0]
    1b90:      	add	x9, sp, #0x6e0
    1b94:      	ldr	w17, [x9, x14]
    1b98:      	csel	w17, w12, w17, ne
    1b9c:      	str	q6, [sp, #0x6c0]
    1ba0:      	str	q5, [sp, #0x6d0]
    1ba4:      	add	x9, sp, #0x6c0
    1ba8:      	str	w17, [x9, x14]
    1bac:      	ldrb	w14, [x27, x13]
    1bb0:      	and	w17, w14, #0x1
    1bb4:      	fmov	s6, w17
    1bb8:      	ubfx	w17, w14, #1, #1
    1bbc:      	mov.b	v6[1], w17
    1bc0:      	ubfx	w17, w14, #2, #1
    1bc4:      	mov.b	v6[2], w17
    1bc8:      	ubfx	w17, w14, #3, #1
    1bcc:      	mov.b	v6[3], w17
    1bd0:      	ubfx	w17, w14, #4, #1
    1bd4:      	mov.b	v6[4], w17
    1bd8:      	ubfx	w17, w14, #5, #1
    1bdc:      	mov.b	v6[5], w17
    1be0:      	ubfx	w17, w14, #6, #1
    1be4:      	mov.b	v6[6], w17
    1be8:      	ldr	q5, [sp, #0x6d0]
    1bec:      	str	q5, [sp, #0x450]
    1bf0:      	ldr	q5, [sp, #0x6c0]
    1bf4:      	str	q5, [sp, #0x440]
    1bf8:      	lsr	w14, w14, #7
    1bfc:      	mov.b	v6[7], w14
    1c00:      	ldrb	w14, [x8, x13]
    1c04:      	and	w17, w14, #0x1
    1c08:      	fmov	s7, w17
    1c0c:      	ubfx	w17, w14, #1, #1
    1c10:      	mov.b	v7[1], w17
    1c14:      	ubfx	w17, w14, #2, #1
    1c18:      	mov.b	v7[2], w17
    1c1c:      	ubfx	w17, w14, #3, #1
    1c20:      	mov.b	v7[3], w17
    1c24:      	ubfx	w17, w14, #4, #1
    1c28:      	mov.b	v7[4], w17
    1c2c:      	ubfx	w17, w14, #5, #1
    1c30:      	mov.b	v7[5], w17
    1c34:      	ubfx	w17, w14, #6, #1
    1c38:      	mov.b	v7[6], w17
    1c3c:      	lsr	w14, w14, #7
    1c40:      	mov.b	v7[7], w14
    1c44:      	csetm	w14, ne
    1c48:      	dup.8b	v16, w14
    1c4c:      	bit.8b	v6, v21, v16
    1c50:      	shl.8b	v6, v6, #0x7
    1c54:      	cmlt.8b	v6, v6, #0
    1c58:      	and.8b	v6, v6, v2
    1c5c:      	addv.8b	b6, v6
    1c60:      	str	b6, [x27, x13]
    1c64:      	bic.8b	v6, v7, v16
    1c68:      	shl.8b	v6, v6, #0x7
    1c6c:      	cmlt.8b	v6, v6, #0
    1c70:      	and.8b	v6, v6, v2
    1c74:      	addv.8b	b6, v6
    1c78:      	str	b6, [x8, x13]
    1c7c:      	csinc	w12, w12, w13, eq
    1c80:      	cmp	w26, #0x8
    1c84:      	b.hs	0x541c <ltmp0+0x541c>
    1c88:      	str	b4, [x21, x28]
    1c8c:      	mov	w9, #0x9                ; =9
    1c90:      	str	w9, [x22, x28, lsl #2]
    1c94:      	str	w12, [x23, x28, lsl #2]
    1c98:      	cmp	w19, #0x8
    1c9c:      	b.hs	0x541c <ltmp0+0x541c>
    1ca0:      	orr	w10, w11, w10
    1ca4:      	zip2.8b	v4, v3, v0
    1ca8:      	ushll.4s	v4, v4, #0x0
    1cac:      	shl.4s	v4, v4, #0x1f
    1cb0:      	cmlt.4s	v4, v4, #0
    1cb4:      	bit.16b	v24, v28, v4
    1cb8:      	zip1.8b	v3, v3, v0
    1cbc:      	ushll.4s	v3, v3, #0x0
    1cc0:      	shl.4s	v3, v3, #0x1f
    1cc4:      	cmlt.4s	v3, v3, #0
    1cc8:      	str	b1, [x21, w19, uxtw]
    1ccc:      	ldr	q1, [sp, #0x150]
    1cd0:      	ldr	q4, [sp, #0x270]
    1cd4:      	bit.16b	v1, v4, v3
    1cd8:      	str	q1, [sp, #0x150]
    1cdc:      	mov	w9, #0xa                ; =10
    1ce0:      	str	w9, [x22, w19, uxtw #2]
    1ce4:      	str	w12, [x23, w19, uxtw #2]
    1ce8:      	add	w26, w19, #0x1
    1cec:      	b	0x2a8 <ltmp0+0x2a8>
    1cf0:      	fmov	w13, s4
    1cf4:      	tst	w13, #0xff
    1cf8:      	b.eq	0x1f7c <ltmp0+0x1f7c>
    1cfc:      	rbit	w13, w11
    1d00:      	clz	w13, w13
    1d04:      	tst	w11, #0xff
    1d08:      	csel	w13, wzr, w13, eq
    1d0c:      	ldp	q1, q0, [sp, #0x360]
    1d10:      	str	q0, [sp, #0x10a0]
    1d14:      	str	q1, [sp, #0x10b0]
    1d18:      	ldp	q1, q0, [sp, #0x340]
    1d1c:      	str	q0, [sp, #0x10c0]
    1d20:      	str	q1, [sp, #0x10d0]
    1d24:      	and	x14, x13, #0x7
    1d28:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    1d2c:      	add	x9, x9, #0xa0
    1d30:      	ldr	x14, [x9, x14, lsl #3]
    1d34:      	lsl	w13, w13, #2
    1d38:      	sub	x13, x14, x13
    1d3c:      	ands	w11, w11, #0xff
    1d40:      	add	x13, x13, #0x100
    1d44:      	csel	x13, xzr, x13, eq
    1d48:      	add	x13, x15, x13
    1d4c:      	ldp	q3, q1, [x13]
    1d50:      	zip1.8b	v4, v21, v0
    1d54:      	ushll.4s	v4, v4, #0x0
    1d58:      	shl.4s	v4, v4, #0x1f
    1d5c:      	cmlt.4s	v4, v4, #0
    1d60:      	and.16b	v3, v4, v3
    1d64:      	zip2.8b	v6, v21, v0
    1d68:      	ushll.4s	v6, v6, #0x0
    1d6c:      	shl.4s	v6, v6, #0x1f
    1d70:      	cmlt.4s	v6, v6, #0
    1d74:      	and.16b	v1, v6, v1
    1d78:      	fmul.4s	v1, v1, v1
    1d7c:      	fmul.4s	v3, v3, v3
    1d80:      	ldr	q5, [sp, #0x270]
    1d84:      	fadd.4s	v3, v5, v3
    1d88:      	fadd.4s	v1, v28, v1
    1d8c:      	bit.16b	v24, v1, v6
    1d90:      	ldr	q1, [sp, #0x150]
    1d94:      	bit.16b	v1, v3, v4
    1d98:      	str	q1, [sp, #0x150]
    1d9c:      	cbz	w11, 0x2a8 <ltmp0+0x2a8>
    1da0:      	str	x28, [sp, #0x88]
    1da4:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    1da8:      	add	x16, x16, #0x80
    1dac:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    1db0:      	add	x0, x0, #0x60
    1db4:      	cbz	w12, 0x1fc8 <ltmp0+0x1fc8>
    1db8:      	mov	w13, #0x0               ; =0
    1dbc:      	shl.8b	v1, v21, #0x7
    1dc0:      	cmlt.8b	v1, v1, #0
    1dc4:      	and.8b	v3, v1, v2
    1dc8:      	addv.8b	b3, v3
    1dcc:      	fmov	w11, s3
    1dd0:      	umaxv.8b	b1, v1
    1dd4:      	fmov	w2, s1
    1dd8:      	sub	w14, w12, #0x1
    1ddc:      	tst	w11, #0xff
    1de0:      	csel	w14, w14, wzr, ne
    1de4:      	lsl	w17, w20, w14
    1de8:      	and	w11, w17, w10
    1dec:      	tst	w11, #0xff
    1df0:      	cset	w4, ne
    1df4:      	ldr	q1, [sp, #0x460]
    1df8:      	str	q1, [sp, #0x1080]
    1dfc:      	ldr	q1, [sp, #0x470]
    1e00:      	str	q1, [sp, #0x1090]
    1e04:      	ubfiz	x11, x14, #2, #3
    1e08:      	ldr	w1, [x16, x11]
    1e0c:      	cmp	w1, #0x2
    1e10:      	cset	w1, eq
    1e14:      	and	w2, w4, w2
    1e18:      	ldrb	w4, [x27, w14, sxtw]
    1e1c:      	and	w5, w4, #0x1
    1e20:      	fmov	s1, w5
    1e24:      	ubfx	w5, w4, #1, #1
    1e28:      	mov.b	v1[1], w5
    1e2c:      	ubfx	w5, w4, #2, #1
    1e30:      	mov.b	v1[2], w5
    1e34:      	ubfx	w5, w4, #3, #1
    1e38:      	mov.b	v1[3], w5
    1e3c:      	ubfx	w5, w4, #4, #1
    1e40:      	mov.b	v1[4], w5
    1e44:      	ubfx	w5, w4, #5, #1
    1e48:      	mov.b	v1[5], w5
    1e4c:      	ubfx	w5, w4, #6, #1
    1e50:      	mov.b	v1[6], w5
    1e54:      	lsr	w4, w4, #7
    1e58:      	mov.b	v1[7], w4
    1e5c:      	ldrb	w4, [x8, w14, sxtw]
    1e60:      	and	w5, w4, #0x1
    1e64:      	fmov	s3, w5
    1e68:      	ubfx	w5, w4, #1, #1
    1e6c:      	mov.b	v3[1], w5
    1e70:      	ubfx	w5, w4, #2, #1
    1e74:      	mov.b	v3[2], w5
    1e78:      	ubfx	w5, w4, #3, #1
    1e7c:      	mov.b	v3[3], w5
    1e80:      	ubfx	w5, w4, #4, #1
    1e84:      	mov.b	v3[4], w5
    1e88:      	ubfx	w5, w4, #5, #1
    1e8c:      	mov.b	v3[5], w5
    1e90:      	ubfx	w5, w4, #6, #1
    1e94:      	mov.b	v3[6], w5
    1e98:      	lsr	w4, w4, #7
    1e9c:      	mov.b	v3[7], w4
    1ea0:      	orr.8b	v4, v21, v3
    1ea4:      	and.8b	v6, v12, v1
    1ea8:      	eor.8b	v6, v6, v4
    1eac:      	shl.8b	v6, v6, #0x7
    1eb0:      	cmlt.8b	v6, v6, #0
    1eb4:      	umaxv.8b	b6, v6
    1eb8:      	fmov	w4, s6
    1ebc:      	ands	w1, w2, w1
    1ec0:      	csetm	w2, ne
    1ec4:      	bics	w4, w1, w4
    1ec8:      	csetm	w5, ne
    1ecc:      	dup.8b	v6, w5
    1ed0:      	dup.8b	v7, w2
    1ed4:      	bic.8b	v16, v4, v6
    1ed8:      	bit.8b	v3, v16, v7
    1edc:      	shl.8b	v3, v3, #0x7
    1ee0:      	cmlt.8b	v3, v3, #0
    1ee4:      	and.8b	v3, v3, v2
    1ee8:      	addv.8b	b3, v3
    1eec:      	str	b3, [x8, w14, sxtw]
    1ef0:      	bic.8b	v1, v1, v6
    1ef4:      	shl.8b	v1, v1, #0x7
    1ef8:      	cmlt.8b	v1, v1, #0
    1efc:      	and.8b	v1, v1, v2
    1f00:      	addv.8b	b1, v1
    1f04:      	str	b1, [x27, w14, sxtw]
    1f08:      	mov	w9, #-0x1               ; =-1
    1f0c:      	csinv	w14, w9, w17, eq
    1f10:      	dup.8b	v1, w1
    1f14:      	and	w10, w14, w10
    1f18:      	shl.8b	v1, v1, #0x7
    1f1c:      	cmlt.8b	v1, v1, #0
    1f20:      	dup.8b	v3, w4
    1f24:      	and.8b	v3, v3, v4
    1f28:      	ldr	q4, [sp, #0x440]
    1f2c:      	str	q4, [sp, #0x1060]
    1f30:      	ldr	q4, [sp, #0x450]
    1f34:      	str	q4, [sp, #0x1070]
    1f38:      	ldr	w11, [x0, x11]
    1f3c:      	csel	w12, w11, w12, ne
    1f40:      	bit.8b	v21, v3, v1
    1f44:      	shl.8b	v1, v21, #0x7
    1f48:      	cmlt.8b	v1, v1, #0
    1f4c:      	and.8b	v1, v1, v2
    1f50:      	addv.8b	b1, v1
    1f54:      	fmov	w11, s1
    1f58:      	cmp	w1, #0x1
    1f5c:      	b.ne	0x1fdc <ltmp0+0x1fdc>
    1f60:      	cmp	w12, #0x0
    1f64:      	ccmp	w13, #0x6, #0x2, ne
    1f68:      	b.hi	0x1fdc <ltmp0+0x1fdc>
    1f6c:      	add	w13, w13, #0x1
    1f70:      	tst	w11, #0xff
    1f74:      	b.ne	0x1dbc <ltmp0+0x1dbc>
    1f78:      	b	0x1fdc <ltmp0+0x1fdc>
    1f7c:      	zip2.8b	v1, v21, v0
    1f80:      	ushll.4s	v1, v1, #0x0
    1f84:      	shl.4s	v1, v1, #0x1f
    1f88:      	cmlt.4s	v1, v1, #0
    1f8c:      	bit.16b	v24, v28, v1
    1f90:      	zip1.8b	v1, v21, v0
    1f94:      	ushll.4s	v1, v1, #0x0
    1f98:      	shl.4s	v1, v1, #0x1f
    1f9c:      	cmlt.4s	v1, v1, #0
    1fa0:      	ldr	q3, [sp, #0x150]
    1fa4:      	ldr	q4, [sp, #0x270]
    1fa8:      	bit.16b	v3, v4, v1
    1fac:      	str	q3, [sp, #0x150]
    1fb0:      	str	x28, [sp, #0x88]
    1fb4:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    1fb8:      	add	x16, x16, #0x80
    1fbc:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    1fc0:      	add	x0, x0, #0x60
    1fc4:      	cbnz	w12, 0x1db8 <ltmp0+0x1db8>
    1fc8:      	shl.8b	v1, v21, #0x7
    1fcc:      	cmlt.8b	v1, v1, #0
    1fd0:      	and.8b	v1, v1, v2
    1fd4:      	addv.8b	b1, v1
    1fd8:      	fmov	w11, s1
    1fdc:      	tst	w11, #0xff
    1fe0:      	b.eq	0x2760 <ltmp0+0x2760>
    1fe4:      	mov.16b	v19, v18
    1fe8:      	fadd.4s	v1, v18, v24
    1fec:      	ldr	q3, [sp, #0x150]
    1ff0:      	ldr	q0, [sp, #0x3a0]
    1ff4:      	fadd.4s	v3, v0, v3
    1ff8:      	ldr	q0, [sp, #0x310]
    1ffc:      	fadd.4s	v3, v0, v3
    2000:      	ldr	q0, [sp, #0x1b0]
    2004:      	fadd.4s	v1, v0, v1
    2008:      	ldr	q4, [sp, #0x220]
    200c:      	fadd.4s	v6, v4, v1
    2010:      	ldr	q1, [sp, #0x210]
    2014:      	fadd.4s	v7, v1, v3
    2018:      	uzp1.4s	v18, v27, v13
    201c:      	ldr	q0, [sp, #0x400]
    2020:      	uzp1.4s	v5, v0, v26
    2024:      	movi.4s	v4, #0x1
    2028:      	eor.16b	v3, v18, v4
    202c:      	mov.s	w13, v3[1]
    2030:      	eor.16b	v4, v5, v4
    2034:      	mov.s	w17, v3[2]
    2038:      	mov.s	w2, v3[3]
    203c:      	fmov	w14, s3
    2040:      	cmp	w14, #0x8
    2044:      	csel	w14, w14, wzr, lo
    2048:      	cset	w4, lo
    204c:      	and	x5, x14, #0x7
    2050:      	add	x1, sp, #0xe18
    2054:      	bfxil	x1, x14, #0, #3
    2058:      	str	d21, [sp, #0xe18]
    205c:      	ldrb	w14, [x1]
    2060:      	umov.b	w15, v21[0]
    2064:      	str	w15, [sp, #0x300]
    2068:      	and	w14, w4, w14
    206c:      	str	q7, [sp, #0xfc0]
    2070:      	str	q6, [sp, #0xfd0]
    2074:      	add	x9, sp, #0xfc0
    2078:      	ldr	s3, [x9, x5, lsl #2]
    207c:      	ands	w23, w15, #0x1
    2080:      	tst	w23, w14
    2084:      	str	q23, [sp, #0x2c0]
    2088:      	movi	d23, #0000000000000000
    208c:      	fcsel	s3, s3, s23, ne
    2090:      	cmp	w13, #0x8
    2094:      	csel	w13, w13, wzr, lo
    2098:      	cset	w4, lo
    209c:      	and	x5, x13, #0x7
    20a0:      	add	x14, sp, #0xe18
    20a4:      	bfxil	x14, x13, #0, #3
    20a8:      	ldrb	w13, [x14]
    20ac:      	umov.b	w14, v21[1]
    20b0:      	str	w14, [sp, #0x2f0]
    20b4:      	and	w13, w4, w13
    20b8:      	str	q7, [sp, #0xfa0]
    20bc:      	str	q6, [sp, #0xfb0]
    20c0:      	add	x9, sp, #0xfa0
    20c4:      	ldr	s16, [x9, x5, lsl #2]
    20c8:      	mov	x15, x3
    20cc:      	mov	x3, x7
    20d0:      	ands	w7, w14, #0x1
    20d4:      	tst	w7, w13
    20d8:      	fcsel	s17, s16, s23, ne
    20dc:      	cmp	w17, #0x8
    20e0:      	csel	w13, w17, wzr, lo
    20e4:      	cset	w17, lo
    20e8:      	and	x4, x13, #0x7
    20ec:      	add	x5, sp, #0xe18
    20f0:      	bfxil	x5, x13, #0, #3
    20f4:      	ldrb	w13, [x5]
    20f8:      	umov.b	w5, v21[2]
    20fc:      	str	q7, [sp, #0xf80]
    2100:      	str	q6, [sp, #0xf90]
    2104:      	add	x9, sp, #0xf80
    2108:      	ldr	s16, [x9, x4, lsl #2]
    210c:      	and	w13, w17, w13
    2110:      	mov	x14, x6
    2114:      	ands	w6, w5, #0x1
    2118:      	tst	w6, w13
    211c:      	fcsel	s16, s16, s23, ne
    2120:      	cmp	w2, #0x8
    2124:      	csel	w17, w2, wzr, lo
    2128:      	cset	w13, lo
    212c:      	and	x4, x17, #0x7
    2130:      	add	x2, sp, #0xe18
    2134:      	bfxil	x2, x17, #0, #3
    2138:      	umov.b	w1, v21[3]
    213c:      	ldrb	w20, [x2]
    2140:      	mov.s	w2, v4[1]
    2144:      	mov.s	w17, v4[2]
    2148:      	str	q7, [sp, #0xf60]
    214c:      	str	q6, [sp, #0xf70]
    2150:      	mov.s	w24, v4[3]
    2154:      	fmov	w21, s4
    2158:      	add	x9, sp, #0xf60
    215c:      	ldr	s4, [x9, x4, lsl #2]
    2160:      	and	w13, w13, w20
    2164:      	ands	w4, w1, #0x1
    2168:      	tst	w4, w13
    216c:      	fcsel	s20, s4, s23, ne
    2170:      	cmp	w21, #0x8
    2174:      	csel	w13, w21, wzr, lo
    2178:      	cset	w20, lo
    217c:      	and	x21, x13, #0x7
    2180:      	add	x22, sp, #0xe18
    2184:      	bfxil	x22, x13, #0, #3
    2188:      	umov.b	w30, v21[4]
    218c:      	ldrb	w13, [x22]
    2190:      	and	w20, w20, w13
    2194:      	str	q7, [sp, #0x1040]
    2198:      	str	q6, [sp, #0x1050]
    219c:      	mov.s	v3[1], v17[0]
    21a0:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    21a4:      	add	x9, x9, #0x40
    21a8:      	ldr	s4, [x9, x21, lsl #2]
    21ac:      	ands	w13, w30, #0x1
    21b0:      	tst	w13, w20
    21b4:      	fcsel	s4, s4, s23, ne
    21b8:      	cmp	w2, #0x8
    21bc:      	csel	w2, w2, wzr, lo
    21c0:      	cset	w20, lo
    21c4:      	and	x21, x2, #0x7
    21c8:      	add	x22, sp, #0xe18
    21cc:      	bfxil	x22, x2, #0, #3
    21d0:      	ldrb	w2, [x22]
    21d4:      	umov.b	w22, v21[5]
    21d8:      	and	w2, w20, w2
    21dc:      	mov.s	v3[2], v16[0]
    21e0:      	str	q7, [sp, #0x1020]
    21e4:      	str	q6, [sp, #0x1030]
    21e8:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    21ec:      	add	x9, x9, #0x20
    21f0:      	ldr	s16, [x9, x21, lsl #2]
    21f4:      	ands	w21, w22, #0x1
    21f8:      	tst	w21, w2
    21fc:      	fcsel	s16, s16, s23, ne
    2200:      	cmp	w17, #0x8
    2204:      	csel	w17, w17, wzr, lo
    2208:      	cset	w2, lo
    220c:      	mov	x28, x25
    2210:      	and	x25, x17, #0x7
    2214:      	add	x20, sp, #0xe18
    2218:      	bfxil	x20, x17, #0, #3
    221c:      	ldrb	w17, [x20]
    2220:      	umov.b	w20, v21[6]
    2224:      	and	w17, w2, w17
    2228:      	str	q7, [sp, #0x1000]
    222c:      	str	q6, [sp, #0x1010]
    2230:      	mov.s	v3[3], v20[0]
    2234:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    2238:      	ldr	s17, [x9, x25, lsl #2]
    223c:      	ands	w2, w20, #0x1
    2240:      	tst	w2, w17
    2244:      	fcsel	s17, s17, s23, ne
    2248:      	cmp	w24, #0x8
    224c:      	csel	w17, w24, wzr, lo
    2250:      	cset	w24, lo
    2254:      	and	x25, x17, #0x7
    2258:      	add	x16, sp, #0xe18
    225c:      	bfxil	x16, x17, #0, #3
    2260:      	ldrb	w16, [x16]
    2264:      	umov.b	w17, v21[7]
    2268:      	and	w16, w24, w16
    226c:      	str	q7, [sp, #0xfe0]
    2270:      	str	q6, [sp, #0xff0]
    2274:      	mov.s	v4[1], v16[0]
    2278:      	add	x9, sp, #0xfe0
    227c:      	ldr	s16, [x9, x25, lsl #2]
    2280:      	ands	w24, w17, #0x1
    2284:      	tst	w24, w16
    2288:      	fcsel	s20, s16, s23, ne
    228c:      	stp	q25, q22, [sp, #0x2d0]
    2290:      	stp	q26, q13, [sp, #0x2a0]
    2294:      	str	q27, [sp, #0x380]
    2298:      	str	d12, [sp, #0x298]
    229c:      	str	q19, [sp, #0x160]
    22a0:      	str	q29, [sp, #0x280]
    22a4:      	mov.16b	v0, v24
    22a8:      	mov.16b	v24, v9
    22ac:      	str	q15, [sp, #0x200]
    22b0:      	ldr	q13, [sp, #0x3c0]
    22b4:      	ldr	q9, [sp, #0x390]
    22b8:      	movi.4s	v19, #0x2
    22bc:      	eor.16b	v16, v18, v19
    22c0:      	mov.s	w16, v16[1]
    22c4:      	fmov	w25, s16
    22c8:      	cmp	w25, #0x8
    22cc:      	csel	w25, w25, wzr, lo
    22d0:      	cset	w0, lo
    22d4:      	add	x9, sp, #0xe18
    22d8:      	bfxil	x9, x25, #0, #3
    22dc:      	ldrb	w9, [x9]
    22e0:      	and	w9, w0, w9
    22e4:      	mov.s	v4[2], v17[0]
    22e8:      	mov.s	v4[3], v20[0]
    22ec:      	fadd.4s	v4, v6, v4
    22f0:      	fadd.4s	v3, v7, v3
    22f4:      	and	x0, x25, #0x7
    22f8:      	mov	x25, x28
    22fc:      	str	q3, [sp, #0xf40]
    2300:      	str	q4, [sp, #0xf50]
    2304:      	add	x28, sp, #0xf40
    2308:      	ldr	s6, [x28, x0, lsl #2]
    230c:      	tst	w23, w9
    2310:      	fcsel	s6, s6, s23, ne
    2314:      	cmp	w16, #0x8
    2318:      	csel	w9, w16, wzr, lo
    231c:      	cset	w16, lo
    2320:      	add	x0, sp, #0xe18
    2324:      	bfxil	x0, x9, #0, #3
    2328:      	ldrb	w0, [x0]
    232c:      	and	w16, w16, w0
    2330:      	and	x9, x9, #0x7
    2334:      	str	q3, [sp, #0xf20]
    2338:      	str	q4, [sp, #0xf30]
    233c:      	add	x0, sp, #0xf20
    2340:      	ldr	s7, [x0, x9, lsl #2]
    2344:      	mov.s	w9, v16[2]
    2348:      	tst	w7, w16
    234c:      	mov	x7, x3
    2350:      	mov	x3, x15
    2354:      	add	x15, sp, #0x1, lsl #12  ; =0x1000
    2358:      	add	x15, x15, #0x3c8
    235c:      	fcsel	s7, s7, s23, ne
    2360:      	cmp	w9, #0x8
    2364:      	csel	w9, w9, wzr, lo
    2368:      	cset	w16, lo
    236c:      	add	x0, sp, #0xe18
    2370:      	bfxil	x0, x9, #0, #3
    2374:      	ldrb	w0, [x0]
    2378:      	and	w16, w16, w0
    237c:      	and	x9, x9, #0x7
    2380:      	str	q3, [sp, #0xf00]
    2384:      	str	q4, [sp, #0xf10]
    2388:      	add	x0, sp, #0xf00
    238c:      	ldr	s17, [x0, x9, lsl #2]
    2390:      	mov.s	w9, v16[3]
    2394:      	tst	w6, w16
    2398:      	mov	x6, x14
    239c:      	fcsel	s16, s17, s23, ne
    23a0:      	cmp	w9, #0x8
    23a4:      	csel	w9, w9, wzr, lo
    23a8:      	cset	w16, lo
    23ac:      	add	x0, sp, #0xe18
    23b0:      	bfxil	x0, x9, #0, #3
    23b4:      	ldrb	w0, [x0]
    23b8:      	and	w16, w16, w0
    23bc:      	eor.16b	v19, v5, v19
    23c0:      	mov.16b	v17, v9
    23c4:      	mov.16b	v20, v0
    23c8:      	ldr	q29, [sp, #0x1c0]
    23cc:      	ldr	q0, [sp, #0x3b0]
    23d0:      	mov.16b	v9, v8
    23d4:      	mov.16b	v27, v17
    23d8:      	mov.16b	v5, v13
    23dc:      	ldr	q18, [sp, #0x280]
    23e0:      	ldr	q15, [sp, #0x160]
    23e4:      	ldr	d12, [sp, #0x298]
    23e8:      	ldp	q25, q22, [sp, #0x2d0]
    23ec:      	ldr	q8, [sp, #0x380]
    23f0:      	ldp	q26, q13, [sp, #0x2a0]
    23f4:      	and	x9, x9, #0x7
    23f8:      	str	q3, [sp, #0xee0]
    23fc:      	str	q4, [sp, #0xef0]
    2400:      	add	x14, sp, #0xee0
    2404:      	ldr	s1, [x14, x9, lsl #2]
    2408:      	tst	w4, w16
    240c:      	fcsel	s1, s1, s23, ne
    2410:      	fmov	w9, s19
    2414:      	cmp	w9, #0x8
    2418:      	csel	w9, w9, wzr, lo
    241c:      	cset	w16, lo
    2420:      	add	x0, sp, #0xe18
    2424:      	bfxil	x0, x9, #0, #3
    2428:      	ldrb	w0, [x0]
    242c:      	and	w16, w16, w0
    2430:      	mov.s	w0, v19[1]
    2434:      	and	x9, x9, #0x7
    2438:      	str	q3, [sp, #0xec0]
    243c:      	str	q4, [sp, #0xed0]
    2440:      	add	x14, sp, #0xec0
    2444:      	ldr	s17, [x14, x9, lsl #2]
    2448:      	mov.s	w9, v19[2]
    244c:      	tst	w13, w16
    2450:      	fcsel	s17, s17, s23, ne
    2454:      	cmp	w0, #0x8
    2458:      	csel	w13, w0, wzr, lo
    245c:      	cset	w16, lo
    2460:      	add	x0, sp, #0xe18
    2464:      	bfxil	x0, x13, #0, #3
    2468:      	ldrb	w0, [x0]
    246c:      	and	w16, w16, w0
    2470:      	mov.s	w0, v19[3]
    2474:      	and	x13, x13, #0x7
    2478:      	str	q3, [sp, #0xea0]
    247c:      	str	q4, [sp, #0xeb0]
    2480:      	add	x14, sp, #0xea0
    2484:      	ldr	s19, [x14, x13, lsl #2]
    2488:      	tst	w21, w16
    248c:      	add	x21, sp, #0x1, lsl #12  ; =0x1000
    2490:      	add	x21, x21, #0x538
    2494:      	fcsel	s19, s19, s23, ne
    2498:      	cmp	w9, #0x8
    249c:      	csel	w9, w9, wzr, lo
    24a0:      	cset	w13, lo
    24a4:      	add	x16, sp, #0xe18
    24a8:      	bfxil	x16, x9, #0, #3
    24ac:      	ldrb	w16, [x16]
    24b0:      	and	w13, w13, w16
    24b4:      	and	x9, x9, #0x7
    24b8:      	str	q3, [sp, #0xe80]
    24bc:      	str	q4, [sp, #0xe90]
    24c0:      	mov.s	v17[1], v19[0]
    24c4:      	add	x14, sp, #0xe80
    24c8:      	ldr	s19, [x14, x9, lsl #2]
    24cc:      	tst	w2, w13
    24d0:      	fcsel	s19, s19, s23, ne
    24d4:      	mov.s	v17[2], v19[0]
    24d8:      	xtn.2s	v19, v8
    24dc:      	cmp	w0, #0x8
    24e0:      	csel	w9, w0, wzr, lo
    24e4:      	cset	w13, lo
    24e8:      	add	x16, sp, #0xe18
    24ec:      	bfxil	x16, x9, #0, #3
    24f0:      	and	x9, x9, #0x7
    24f4:      	ldrb	w16, [x16]
    24f8:      	and	w13, w13, w16
    24fc:      	str	q3, [sp, #0xe60]
    2500:      	str	q4, [sp, #0xe70]
    2504:      	fmov	w16, s19
    2508:      	add	x14, sp, #0xe60
    250c:      	ldr	s19, [x14, x9, lsl #2]
    2510:      	tst	w24, w13
    2514:      	adrp	x24, 0x2000 <ltmp0+0x2000>
    2518:      	fcsel	s19, s19, s23, ne
    251c:      	eor	w9, w16, #0x4
    2520:      	cmp	w16, #0x8
    2524:      	csel	w9, w9, wzr, lo
    2528:      	cset	w13, lo
    252c:      	add	x16, sp, #0xe18
    2530:      	bfxil	x16, x9, #0, #3
    2534:      	ldrb	w16, [x16]
    2538:      	and	w13, w13, w16
    253c:      	mov.s	v17[3], v19[0]
    2540:      	mov.s	v6[1], v7[0]
    2544:      	mov.s	v6[2], v16[0]
    2548:      	tst	w23, w13
    254c:      	add	x23, sp, #0x1, lsl #12  ; =0x1000
    2550:      	add	x23, x23, #0x4f8
    2554:      	mov.s	v6[3], v1[0]
    2558:      	fadd.4s	v1, v3, v6
    255c:      	fadd.4s	v3, v4, v17
    2560:      	and	x9, x9, #0x7
    2564:      	str	q3, [sp, #0xe50]
    2568:      	str	q1, [sp, #0xe40]
    256c:      	add	x13, sp, #0xe40
    2570:      	ldr	s3, [x13, x9, lsl #2]
    2574:      	fcsel	s3, s3, s23, ne
    2578:      	ldr	w9, [sp, #0x300]
    257c:      	tst	w9, #0x1
    2580:      	fadd	s1, s1, s3
    2584:      	fcsel	s1, s1, s23, ne
    2588:      	ldr	w9, [sp, #0x2f0]
    258c:      	tst	w9, #0x1
    2590:      	fcsel	s3, s1, s23, ne
    2594:      	tst	w5, #0x1
    2598:      	fcsel	s4, s1, s23, ne
    259c:      	tst	w1, #0x1
    25a0:      	fcsel	s6, s1, s23, ne
    25a4:      	tst	w30, #0x1
    25a8:      	adrp	x30, 0x2000 <ltmp0+0x2000>
    25ac:      	fcsel	s7, s1, s23, ne
    25b0:      	tst	w22, #0x1
    25b4:      	fcsel	s16, s1, s23, ne
    25b8:      	tst	w20, #0x1
    25bc:      	mov	w20, #0x1               ; =1
    25c0:      	fcsel	s17, s1, s23, ne
    25c4:      	tst	w17, #0x1
    25c8:      	fcsel	s19, s1, s23, ne
    25cc:      	mov.s	v1[1], v3[0]
    25d0:      	mov.s	v1[2], v4[0]
    25d4:      	mov.s	v1[3], v6[0]
    25d8:      	rbit	w9, w11
    25dc:      	clz	w9, w9
    25e0:      	mov.s	v7[1], v16[0]
    25e4:      	mov.s	v7[2], v17[0]
    25e8:      	mov.s	v7[3], v19[0]
    25ec:      	str	q7, [sp, #0xe30]
    25f0:      	str	q1, [sp, #0xe20]
    25f4:      	and	x9, x9, #0x7
    25f8:      	add	x11, sp, #0xe20
    25fc:      	ldr	s1, [x11, x9, lsl #2]
    2600:      	fadd	s1, s1, s23
    2604:      	ldr	q23, [sp, #0x2c0]
    2608:      	mov	w9, #0x42820000         ; =1115815936
    260c:      	fmov	s3, w9
    2610:      	fdiv	s1, s1, s3
    2614:      	dup.4s	v1, v1[0]
    2618:      	zip2.8b	v3, v21, v0
    261c:      	ushll.4s	v3, v3, #0x0
    2620:      	shl.4s	v3, v3, #0x1f
    2624:      	cmlt.4s	v3, v3, #0
    2628:      	ldr	q4, [sp, #0xf0]
    262c:      	bit.16b	v4, v1, v3
    2630:      	str	q4, [sp, #0xf0]
    2634:      	zip1.8b	v3, v21, v0
    2638:      	ushll.4s	v3, v3, #0x0
    263c:      	shl.4s	v3, v3, #0x1f
    2640:      	cmlt.4s	v3, v3, #0
    2644:      	ldr	q4, [sp, #0x100]
    2648:      	bit.16b	v4, v1, v3
    264c:      	str	q4, [sp, #0x100]
    2650:      	mov	b1, v21[6]
    2654:      	mov.b	v1[4], v21[7]
    2658:      	ushll.2d	v1, v1, #0x0
    265c:      	shl.2d	v1, v1, #0x3f
    2660:      	cmlt.2d	v1, v1, #0
    2664:      	mov	b3, v21[4]
    2668:      	mov.b	v3[4], v21[5]
    266c:      	ushll.2d	v3, v3, #0x0
    2670:      	shl.2d	v3, v3, #0x3f
    2674:      	cmlt.2d	v3, v3, #0
    2678:      	mov	b4, v21[2]
    267c:      	mov.b	v4[4], v21[3]
    2680:      	ushll.2d	v4, v4, #0x0
    2684:      	shl.2d	v4, v4, #0x3f
    2688:      	cmlt.2d	v4, v4, #0
    268c:      	mov	b6, v21[0]
    2690:      	mov.b	v6[4], v21[1]
    2694:      	ushll.2d	v6, v6, #0x0
    2698:      	shl.2d	v6, v6, #0x3f
    269c:      	cmlt.2d	v6, v6, #0
    26a0:      	ldr	q7, [x24]
    26a4:      	bit.16b	v0, v7, v1
    26a8:      	str	q0, [sp, #0x3b0]
    26ac:      	ldr	q7, [x25]
    26b0:      	ldr	q0, [sp, #0x3d0]
    26b4:      	bit.16b	v0, v7, v3
    26b8:      	str	q0, [sp, #0x3d0]
    26bc:      	ldr	q7, [x30]
    26c0:      	bit.16b	v5, v7, v4
    26c4:      	str	q5, [sp, #0x3c0]
    26c8:      	adrp	x9, 0x2000 <ltmp0+0x2000>
    26cc:      	ldr	q7, [x9]
    26d0:      	bit.16b	v27, v7, v6
    26d4:      	str	q27, [sp, #0x390]
    26d8:      	mov.16b	v27, v8
    26dc:      	mov.16b	v8, v9
    26e0:      	mov.16b	v9, v24
    26e4:      	mov.16b	v24, v20
    26e8:      	movi.8b	v20, #0x1
    26ec:      	ldr	q7, [sp, #0x70]
    26f0:      	ldr	q5, [sp, #0x1f0]
    26f4:      	bit.16b	v5, v7, v1
    26f8:      	bic.16b	v22, v22, v1
    26fc:      	ldr	q1, [sp, #0x1d0]
    2700:      	bit.16b	v1, v7, v3
    2704:      	bic.16b	v14, v14, v3
    2708:      	bit.16b	v29, v7, v4
    270c:      	stp	q29, q1, [sp, #0x1c0]
    2710:      	mov.16b	v29, v18
    2714:      	mov.16b	v18, v15
    2718:      	ldr	q15, [sp, #0x200]
    271c:      	ldr	q0, [sp, #0x410]
    2720:      	bic.16b	v0, v0, v4
    2724:      	str	q0, [sp, #0x410]
    2728:      	ldr	q1, [sp, #0x1e0]
    272c:      	bit.16b	v1, v7, v6
    2730:      	stp	q1, q5, [sp, #0x1e0]
    2734:      	bic.16b	v25, v25, v6
    2738:      	add	x22, sp, #0x1, lsl #12  ; =0x1000
    273c:      	add	x22, x22, #0x518
    2740:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    2744:      	add	x0, x0, #0x180
    2748:      	mov	w5, #-0x1               ; =-1
    274c:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    2750:      	add	x16, x16, #0x160
    2754:      	add	x4, sp, #0xdf0
    2758:      	ldr	x28, [sp, #0x88]
    275c:      	b	0x2784 <ltmp0+0x2784>
    2760:      	add	x22, sp, #0x1, lsl #12  ; =0x1000
    2764:      	add	x22, x22, #0x518
    2768:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    276c:      	add	x0, x0, #0x180
    2770:      	mov	w5, #-0x1               ; =-1
    2774:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    2778:      	add	x16, x16, #0x160
    277c:      	add	x4, sp, #0xdf0
    2780:      	b	0x2a8 <ltmp0+0x2a8>
    2784:      	shl.8b	v1, v21, #0x7
    2788:      	cmlt.8b	v1, v1, #0
    278c:      	and.8b	v1, v1, v2
    2790:      	addv.8b	b1, v1
    2794:      	fmov	w11, s1
    2798:      	mov	w9, #0x8                ; =8
    279c:      	dup.2d	v3, x9
    27a0:      	ldr	q0, [sp, #0x410]
    27a4:      	cmgt.2d	v1, v3, v0
    27a8:      	cmgt.2d	v4, v3, v25
    27ac:      	uzp1.4s	v1, v4, v1
    27b0:      	cmgt.2d	v4, v3, v14
    27b4:      	cmgt.2d	v6, v3, v22
    27b8:      	uzp1.4s	v4, v4, v6
    27bc:      	uzp1.8h	v1, v1, v4
    27c0:      	xtn.8b	v1, v1
    27c4:      	and.8b	v1, v21, v1
    27c8:      	shl.8b	v1, v1, #0x7
    27cc:      	cmlt.8b	v4, v1, #0
    27d0:      	and.8b	v1, v4, v2
    27d4:      	addv.8b	b1, v1
    27d8:      	fmov	w13, s1
    27dc:      	umaxv.8b	b4, v4
    27e0:      	fmov	w14, s4
    27e4:      	tbz	w14, #0x0, 0x2a14 <ltmp0+0x2a14>
    27e8:      	ldr	q0, [sp, #0x410]
    27ec:      	cmge.2d	v4, v0, v3
    27f0:      	cmge.2d	v6, v25, v3
    27f4:      	uzp1.4s	v4, v6, v4
    27f8:      	cmge.2d	v6, v14, v3
    27fc:      	cmge.2d	v3, v22, v3
    2800:      	uzp1.4s	v3, v6, v3
    2804:      	uzp1.8h	v3, v4, v3
    2808:      	xtn.8b	v3, v3
    280c:      	and.8b	v3, v21, v3
    2810:      	shl.8b	v3, v3, #0x7
    2814:      	cmlt.8b	v3, v3, #0
    2818:      	and.8b	v3, v3, v2
    281c:      	addv.8b	b3, v3
    2820:      	fmov	w14, s3
    2824:      	tst	w14, #0xff
    2828:      	b.eq	0x2a14 <ltmp0+0x2a14>
    282c:      	subs	w9, w12, #0x1
    2830:      	csel	w9, wzr, w9, lo
    2834:      	and	w13, w10, #0xff
    2838:      	lsr	w11, w13, w9
    283c:      	tst	w11, #0x1
    2840:      	ldr	q4, [sp, #0x460]
    2844:      	str	q4, [sp, #0x7e0]
    2848:      	ldr	q4, [sp, #0x470]
    284c:      	str	q4, [sp, #0x7f0]
    2850:      	and	x9, x9, #0x7
    2854:      	add	x11, sp, #0x7e0
    2858:      	ldr	w9, [x11, x9, lsl #2]
    285c:      	ccmp	w12, #0x0, #0x4, ne
    2860:      	ccmp	w9, #0x3, #0x0, ne
    2864:      	cset	w11, ne
    2868:      	cmp	w13, #0xff
    286c:      	b.ne	0x2874 <ltmp0+0x2874>
    2870:      	tbnz	w11, #0x0, 0x541c <ltmp0+0x541c>
    2874:      	mvn	w9, w10
    2878:      	rbit	w9, w9
    287c:      	clz	w9, w9
    2880:      	mov	w13, #0xff              ; =255
    2884:      	bics	wzr, w13, w10
    2888:      	csel	w13, wzr, w9, eq
    288c:      	ubfiz	x9, x13, #2, #3
    2890:      	lsl	w14, w20, w13
    2894:      	ldr	q5, [sp, #0x460]
    2898:      	str	q5, [sp, #0x7c0]
    289c:      	ldr	q4, [sp, #0x470]
    28a0:      	str	q4, [sp, #0x7d0]
    28a4:      	add	x16, sp, #0x7c0
    28a8:      	ldr	w16, [x16, x9]
    28ac:      	cmp	w11, #0x0
    28b0:      	csel	w11, w14, wzr, ne
    28b4:      	mov	w14, #0x3               ; =3
    28b8:      	csel	w14, w14, w16, ne
    28bc:      	str	q5, [sp, #0x7a0]
    28c0:      	str	q4, [sp, #0x7b0]
    28c4:      	add	x16, sp, #0x7a0
    28c8:      	str	w14, [x16, x9]
    28cc:      	ldr	q4, [sp, #0x7b0]
    28d0:      	str	q4, [sp, #0x470]
    28d4:      	ldr	q4, [sp, #0x7a0]
    28d8:      	str	q4, [sp, #0x460]
    28dc:      	ldr	q5, [sp, #0x440]
    28e0:      	str	q5, [sp, #0x780]
    28e4:      	ldr	q4, [sp, #0x450]
    28e8:      	str	q4, [sp, #0x790]
    28ec:      	add	x14, sp, #0x780
    28f0:      	ldr	w14, [x14, x9]
    28f4:      	csel	w14, w12, w14, ne
    28f8:      	str	q5, [sp, #0x760]
    28fc:      	str	q4, [sp, #0x770]
    2900:      	add	x16, sp, #0x760
    2904:      	str	w14, [x16, x9]
    2908:      	ldrb	w9, [x27, x13]
    290c:      	and	w14, w9, #0x1
    2910:      	fmov	s4, w14
    2914:      	ubfx	w14, w9, #1, #1
    2918:      	mov.b	v4[1], w14
    291c:      	ubfx	w14, w9, #2, #1
    2920:      	mov.b	v4[2], w14
    2924:      	ubfx	w14, w9, #3, #1
    2928:      	mov.b	v4[3], w14
    292c:      	ubfx	w14, w9, #4, #1
    2930:      	mov.b	v4[4], w14
    2934:      	ubfx	w14, w9, #5, #1
    2938:      	mov.b	v4[5], w14
    293c:      	ubfx	w14, w9, #6, #1
    2940:      	mov.b	v4[6], w14
    2944:      	ldr	q5, [sp, #0x770]
    2948:      	str	q5, [sp, #0x450]
    294c:      	ldr	q5, [sp, #0x760]
    2950:      	str	q5, [sp, #0x440]
    2954:      	lsr	w9, w9, #7
    2958:      	mov.b	v4[7], w9
    295c:      	ldrb	w9, [x8, x13]
    2960:      	and	w14, w9, #0x1
    2964:      	fmov	s6, w14
    2968:      	ubfx	w14, w9, #1, #1
    296c:      	mov.b	v6[1], w14
    2970:      	ubfx	w14, w9, #2, #1
    2974:      	mov.b	v6[2], w14
    2978:      	ubfx	w14, w9, #3, #1
    297c:      	mov.b	v6[3], w14
    2980:      	ubfx	w14, w9, #4, #1
    2984:      	mov.b	v6[4], w14
    2988:      	ubfx	w14, w9, #5, #1
    298c:      	mov.b	v6[5], w14
    2990:      	ubfx	w14, w9, #6, #1
    2994:      	mov.b	v6[6], w14
    2998:      	lsr	w9, w9, #7
    299c:      	mov.b	v6[7], w9
    29a0:      	csetm	w9, ne
    29a4:      	dup.8b	v7, w9
    29a8:      	bit.8b	v4, v21, v7
    29ac:      	shl.8b	v4, v4, #0x7
    29b0:      	cmlt.8b	v4, v4, #0
    29b4:      	and.8b	v4, v4, v2
    29b8:      	addv.8b	b4, v4
    29bc:      	str	b4, [x27, x13]
    29c0:      	bic.8b	v4, v6, v7
    29c4:      	shl.8b	v4, v4, #0x7
    29c8:      	cmlt.8b	v4, v4, #0
    29cc:      	and.8b	v4, v4, v2
    29d0:      	addv.8b	b4, v4
    29d4:      	str	b4, [x8, x13]
    29d8:      	csinc	w12, w12, w13, eq
    29dc:      	cmp	w26, #0x8
    29e0:      	b.hs	0x541c <ltmp0+0x541c>
    29e4:      	str	b1, [x21, x28]
    29e8:      	mov	w9, #0xc                ; =12
    29ec:      	str	w9, [x22, x28, lsl #2]
    29f0:      	str	w12, [x23, x28, lsl #2]
    29f4:      	cmp	w19, #0x8
    29f8:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    29fc:      	add	x16, x16, #0x160
    2a00:      	b.hs	0x541c <ltmp0+0x541c>
    2a04:      	str	b3, [x21, w19, uxtw]
    2a08:      	orr	w10, w11, w10
    2a0c:      	mov	w9, #0xd                ; =13
    2a10:      	b	0xfe8 <ltmp0+0xfe8>
    2a14:      	tst	w13, #0xff
    2a18:      	b.eq	0x2c20 <ltmp0+0x2c20>
    2a1c:      	tst	w11, #0xff
    2a20:      	b.eq	0x2a8 <ltmp0+0x2a8>
    2a24:      	rbit	w13, w11
    2a28:      	clz	w13, w13
    2a2c:      	tst	w11, #0xff
    2a30:      	csel	w13, wzr, w13, eq
    2a34:      	str	q25, [sp, #0x840]
    2a38:      	ldr	q0, [sp, #0x410]
    2a3c:      	str	q0, [sp, #0x850]
    2a40:      	str	q14, [sp, #0x860]
    2a44:      	str	q22, [sp, #0x870]
    2a48:      	ubfiz	x14, x13, #3, #3
    2a4c:      	add	x9, sp, #0x840
    2a50:      	ldr	x17, [x9, x14]
    2a54:      	str	q27, [sp, #0x800]
    2a58:      	str	q13, [sp, #0x810]
    2a5c:      	ldr	q0, [sp, #0x400]
    2a60:      	str	q0, [sp, #0x820]
    2a64:      	str	q26, [sp, #0x830]
    2a68:      	add	x9, sp, #0x800
    2a6c:      	ldr	x14, [x9, x14]
    2a70:      	sub	x13, x14, x13
    2a74:      	add	x14, x7, x17, lsl #5
    2a78:      	add	x13, x14, x13, lsl #2
    2a7c:      	shl.8b	v1, v21, #0x7
    2a80:      	cmlt.8b	v1, v1, #0
    2a84:      	and.8b	v1, v1, v2
    2a88:      	addv.8b	b4, v1
    2a8c:      	fmov	w14, s4
    2a90:      	movi.2d	v3, #0000000000000000
    2a94:      	movi.2d	v1, #0000000000000000
    2a98:      	tbz	w14, #0x0, 0x2ad8 <ltmp0+0x2ad8>
    2a9c:      	ldr	s3, [x13]
    2aa0:      	tbnz	w14, #0x1, 0x2adc <ltmp0+0x2adc>
    2aa4:      	tbz	w14, #0x2, 0x2ae8 <ltmp0+0x2ae8>
    2aa8:      	add	x17, x13, #0x8
    2aac:      	ld1.s	{ v3 }[2], [x17]
    2ab0:      	tbnz	w14, #0x3, 0x2aec <ltmp0+0x2aec>
    2ab4:      	tbz	w14, #0x4, 0x2af8 <ltmp0+0x2af8>
    2ab8:      	add	x17, x13, #0x10
    2abc:      	ld1.s	{ v1 }[0], [x17]
    2ac0:      	tbnz	w14, #0x5, 0x2afc <ltmp0+0x2afc>
    2ac4:      	tbz	w14, #0x6, 0x2b08 <ltmp0+0x2b08>
    2ac8:      	add	x17, x13, #0x18
    2acc:      	ld1.s	{ v1 }[2], [x17]
    2ad0:      	tbnz	w14, #0x7, 0x2b0c <ltmp0+0x2b0c>
    2ad4:      	b	0x2b14 <ltmp0+0x2b14>
    2ad8:      	tbz	w14, #0x1, 0x2aa4 <ltmp0+0x2aa4>
    2adc:      	add	x17, x13, #0x4
    2ae0:      	ld1.s	{ v3 }[1], [x17]
    2ae4:      	tbnz	w14, #0x2, 0x2aa8 <ltmp0+0x2aa8>
    2ae8:      	tbz	w14, #0x3, 0x2ab4 <ltmp0+0x2ab4>
    2aec:      	add	x17, x13, #0xc
    2af0:      	ld1.s	{ v3 }[3], [x17]
    2af4:      	tbnz	w14, #0x4, 0x2ab8 <ltmp0+0x2ab8>
    2af8:      	tbz	w14, #0x5, 0x2ac4 <ltmp0+0x2ac4>
    2afc:      	add	x17, x13, #0x14
    2b00:      	ld1.s	{ v1 }[1], [x17]
    2b04:      	tbnz	w14, #0x6, 0x2ac8 <ltmp0+0x2ac8>
    2b08:      	tbz	w14, #0x7, 0x2b14 <ltmp0+0x2b14>
    2b0c:      	add	x13, x13, #0x1c
    2b10:      	ld1.s	{ v1 }[3], [x13]
    2b14:      	shl.2d	v6, v25, #0x5
    2b18:      	ldr	q0, [sp, #0x410]
    2b1c:      	shl.2d	v7, v0, #0x5
    2b20:      	shl.2d	v17, v14, #0x5
    2b24:      	shl.2d	v19, v22, #0x5
    2b28:      	ldr	q5, [sp, #0x1e0]
    2b2c:      	ldr	q0, [sp, #0x390]
    2b30:      	add.2d	v16, v5, v0
    2b34:      	add.2d	v16, v16, v6
    2b38:      	ldr	q0, [sp, #0x3c0]
    2b3c:      	ldr	q5, [sp, #0x1c0]
    2b40:      	add.2d	v6, v5, v0
    2b44:      	add.2d	v7, v6, v7
    2b48:      	ldr	q5, [sp, #0x1d0]
    2b4c:      	ldr	q0, [sp, #0x3d0]
    2b50:      	add.2d	v6, v5, v0
    2b54:      	add.2d	v6, v6, v17
    2b58:      	ldr	q5, [sp, #0x1f0]
    2b5c:      	ldr	q0, [sp, #0x3b0]
    2b60:      	add.2d	v17, v5, v0
    2b64:      	fmov	w13, s4
    2b68:      	add.2d	v4, v17, v19
    2b6c:      	tbz	w13, #0x0, 0x2bb0 <ltmp0+0x2bb0>
    2b70:      	fmov	x14, d16
    2b74:      	str	s3, [x14]
    2b78:      	tbnz	w13, #0x1, 0x2bb4 <ltmp0+0x2bb4>
    2b7c:      	tbz	w13, #0x2, 0x2bc0 <ltmp0+0x2bc0>
    2b80:      	fmov	x14, d7
    2b84:      	st1.s	{ v3 }[2], [x14]
    2b88:      	tbnz	w13, #0x3, 0x2bc4 <ltmp0+0x2bc4>
    2b8c:      	tbz	w13, #0x4, 0x2bd0 <ltmp0+0x2bd0>
    2b90:      	fmov	x14, d6
    2b94:      	str	s1, [x14]
    2b98:      	tbnz	w13, #0x5, 0x2bd4 <ltmp0+0x2bd4>
    2b9c:      	tbz	w13, #0x6, 0x2be0 <ltmp0+0x2be0>
    2ba0:      	fmov	x14, d4
    2ba4:      	st1.s	{ v1 }[2], [x14]
    2ba8:      	tbnz	w13, #0x7, 0x2be4 <ltmp0+0x2be4>
    2bac:      	b	0x2bec <ltmp0+0x2bec>
    2bb0:      	tbz	w13, #0x1, 0x2b7c <ltmp0+0x2b7c>
    2bb4:      	mov.d	x14, v16[1]
    2bb8:      	st1.s	{ v3 }[1], [x14]
    2bbc:      	tbnz	w13, #0x2, 0x2b80 <ltmp0+0x2b80>
    2bc0:      	tbz	w13, #0x3, 0x2b8c <ltmp0+0x2b8c>
    2bc4:      	mov.d	x14, v7[1]
    2bc8:      	st1.s	{ v3 }[3], [x14]
    2bcc:      	tbnz	w13, #0x4, 0x2b90 <ltmp0+0x2b90>
    2bd0:      	tbz	w13, #0x5, 0x2b9c <ltmp0+0x2b9c>
    2bd4:      	mov.d	x14, v6[1]
    2bd8:      	st1.s	{ v1 }[1], [x14]
    2bdc:      	tbnz	w13, #0x6, 0x2ba0 <ltmp0+0x2ba0>
    2be0:      	tbz	w13, #0x7, 0x2bec <ltmp0+0x2bec>
    2be4:      	mov.d	x13, v4[1]
    2be8:      	st1.s	{ v1 }[3], [x13]
    2bec:      	and.8b	v1, v21, v20
    2bf0:      	ushll.8h	v1, v1, #0x0
    2bf4:      	ushll.4s	v3, v1, #0x0
    2bf8:      	ushll2.4s	v1, v1, #0x0
    2bfc:      	uaddw2.2d	v22, v22, v1
    2c00:      	uaddw.2d	v14, v14, v1
    2c04:      	ldr	q0, [sp, #0x410]
    2c08:      	uaddw2.2d	v0, v0, v3
    2c0c:      	str	q0, [sp, #0x410]
    2c10:      	uaddw.2d	v25, v25, v3
    2c14:      	tst	w11, #0xff
    2c18:      	b.ne	0x2784 <ltmp0+0x2784>
    2c1c:      	b	0x2a8 <ltmp0+0x2a8>
    2c20:      	tst	w11, #0xff
    2c24:      	b.eq	0x2a8 <ltmp0+0x2a8>
    2c28:      	cbz	w12, 0x2df0 <ltmp0+0x2df0>
    2c2c:      	mov	w13, #0x0               ; =0
    2c30:      	shl.8b	v1, v21, #0x7
    2c34:      	cmlt.8b	v1, v1, #0
    2c38:      	and.8b	v3, v1, v2
    2c3c:      	addv.8b	b3, v3
    2c40:      	fmov	w9, s3
    2c44:      	umaxv.8b	b1, v1
    2c48:      	fmov	w16, s1
    2c4c:      	sub	w11, w12, #0x1
    2c50:      	tst	w9, #0xff
    2c54:      	csel	w14, w11, wzr, ne
    2c58:      	lsl	w17, w20, w14
    2c5c:      	and	w9, w17, w10
    2c60:      	tst	w9, #0xff
    2c64:      	cset	w9, ne
    2c68:      	ldr	q1, [sp, #0x460]
    2c6c:      	str	q1, [sp, #0xdf0]
    2c70:      	ldr	q1, [sp, #0x470]
    2c74:      	str	q1, [sp, #0xe00]
    2c78:      	ubfiz	x11, x14, #2, #3
    2c7c:      	ldr	w0, [x4, x11]
    2c80:      	cmp	w0, #0x3
    2c84:      	cset	w1, eq
    2c88:      	and	w2, w9, w16
    2c8c:      	ldrb	w9, [x27, w14, sxtw]
    2c90:      	and	w16, w9, #0x1
    2c94:      	fmov	s1, w16
    2c98:      	ubfx	w16, w9, #1, #1
    2c9c:      	mov.b	v1[1], w16
    2ca0:      	ubfx	w16, w9, #2, #1
    2ca4:      	mov.b	v1[2], w16
    2ca8:      	ubfx	w16, w9, #3, #1
    2cac:      	mov.b	v1[3], w16
    2cb0:      	ubfx	w16, w9, #4, #1
    2cb4:      	mov.b	v1[4], w16
    2cb8:      	ubfx	w16, w9, #5, #1
    2cbc:      	mov.b	v1[5], w16
    2cc0:      	ubfx	w16, w9, #6, #1
    2cc4:      	mov.b	v1[6], w16
    2cc8:      	lsr	w9, w9, #7
    2ccc:      	mov.b	v1[7], w9
    2cd0:      	ldrb	w9, [x8, w14, sxtw]
    2cd4:      	and	w16, w9, #0x1
    2cd8:      	fmov	s3, w16
    2cdc:      	ubfx	w16, w9, #1, #1
    2ce0:      	mov.b	v3[1], w16
    2ce4:      	ubfx	w16, w9, #2, #1
    2ce8:      	mov.b	v3[2], w16
    2cec:      	ubfx	w16, w9, #3, #1
    2cf0:      	mov.b	v3[3], w16
    2cf4:      	ubfx	w16, w9, #4, #1
    2cf8:      	mov.b	v3[4], w16
    2cfc:      	ubfx	w16, w9, #5, #1
    2d00:      	mov.b	v3[5], w16
    2d04:      	ubfx	w16, w9, #6, #1
    2d08:      	mov.b	v3[6], w16
    2d0c:      	lsr	w9, w9, #7
    2d10:      	mov.b	v3[7], w9
    2d14:      	orr.8b	v4, v21, v3
    2d18:      	and.8b	v6, v12, v1
    2d1c:      	eor.8b	v6, v6, v4
    2d20:      	shl.8b	v6, v6, #0x7
    2d24:      	cmlt.8b	v6, v6, #0
    2d28:      	umaxv.8b	b6, v6
    2d2c:      	fmov	w9, s6
    2d30:      	ands	w16, w2, w1
    2d34:      	csetm	w0, ne
    2d38:      	bics	w9, w16, w9
    2d3c:      	csetm	w1, ne
    2d40:      	dup.8b	v6, w1
    2d44:      	dup.8b	v7, w0
    2d48:      	bic.8b	v16, v4, v6
    2d4c:      	bit.8b	v3, v16, v7
    2d50:      	shl.8b	v3, v3, #0x7
    2d54:      	cmlt.8b	v3, v3, #0
    2d58:      	and.8b	v3, v3, v2
    2d5c:      	addv.8b	b3, v3
    2d60:      	str	b3, [x8, w14, sxtw]
    2d64:      	bic.8b	v1, v1, v6
    2d68:      	shl.8b	v1, v1, #0x7
    2d6c:      	cmlt.8b	v1, v1, #0
    2d70:      	and.8b	v1, v1, v2
    2d74:      	addv.8b	b1, v1
    2d78:      	str	b1, [x27, w14, sxtw]
    2d7c:      	csinv	w14, w5, w17, eq
    2d80:      	dup.8b	v1, w16
    2d84:      	and	w10, w14, w10
    2d88:      	shl.8b	v1, v1, #0x7
    2d8c:      	cmlt.8b	v1, v1, #0
    2d90:      	dup.8b	v3, w9
    2d94:      	and.8b	v3, v3, v4
    2d98:      	ldr	q4, [sp, #0x440]
    2d9c:      	str	q4, [sp, #0xdd0]
    2da0:      	ldr	q4, [sp, #0x450]
    2da4:      	str	q4, [sp, #0xde0]
    2da8:      	add	x9, sp, #0xdd0
    2dac:      	ldr	w9, [x9, x11]
    2db0:      	csel	w12, w9, w12, ne
    2db4:      	bit.8b	v21, v3, v1
    2db8:      	shl.8b	v1, v21, #0x7
    2dbc:      	cmlt.8b	v1, v1, #0
    2dc0:      	and.8b	v1, v1, v2
    2dc4:      	addv.8b	b1, v1
    2dc8:      	fmov	w11, s1
    2dcc:      	cmp	w16, #0x1
    2dd0:      	b.ne	0x2e04 <ltmp0+0x2e04>
    2dd4:      	cmp	w12, #0x0
    2dd8:      	ccmp	w13, #0x6, #0x2, ne
    2ddc:      	b.hi	0x2e04 <ltmp0+0x2e04>
    2de0:      	add	w13, w13, #0x1
    2de4:      	tst	w11, #0xff
    2de8:      	b.ne	0x2c30 <ltmp0+0x2c30>
    2dec:      	b	0x2e04 <ltmp0+0x2e04>
    2df0:      	shl.8b	v1, v21, #0x7
    2df4:      	cmlt.8b	v1, v1, #0
    2df8:      	and.8b	v1, v1, v2
    2dfc:      	addv.8b	b1, v1
    2e00:      	fmov	w11, s1
    2e04:      	tst	w11, #0xff
    2e08:      	b.eq	0x298 <ltmp0+0x298>
    2e0c:      	and.8b	v1, v15, v21
    2e10:      	shl.8b	v1, v1, #0x7
    2e14:      	cmlt.8b	v3, v1, #0
    2e18:      	and.8b	v1, v3, v2
    2e1c:      	addv.8b	b1, v1
    2e20:      	umaxv.8b	b3, v3
    2e24:      	fmov	w9, s3
    2e28:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    2e2c:      	add	x0, x0, #0x180
    2e30:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    2e34:      	add	x16, x16, #0x160
    2e38:      	tbz	w9, #0x0, 0x3044 <ltmp0+0x3044>
    2e3c:      	bic.8b	v3, v21, v15
    2e40:      	shl.8b	v3, v3, #0x7
    2e44:      	cmlt.8b	v3, v3, #0
    2e48:      	and.8b	v3, v3, v2
    2e4c:      	addv.8b	b3, v3
    2e50:      	fmov	w9, s3
    2e54:      	tst	w9, #0xff
    2e58:      	b.eq	0x3044 <ltmp0+0x3044>
    2e5c:      	subs	w9, w12, #0x1
    2e60:      	csel	w9, wzr, w9, lo
    2e64:      	and	w13, w10, #0xff
    2e68:      	lsr	w11, w13, w9
    2e6c:      	tst	w11, #0x1
    2e70:      	ldr	q4, [sp, #0x460]
    2e74:      	str	q4, [sp, #0x900]
    2e78:      	ldr	q4, [sp, #0x470]
    2e7c:      	str	q4, [sp, #0x910]
    2e80:      	and	x9, x9, #0x7
    2e84:      	add	x11, sp, #0x900
    2e88:      	ldr	w9, [x11, x9, lsl #2]
    2e8c:      	ccmp	w12, #0x0, #0x4, ne
    2e90:      	ccmp	w9, #0x4, #0x0, ne
    2e94:      	cset	w11, ne
    2e98:      	cmp	w13, #0xff
    2e9c:      	b.ne	0x2ea4 <ltmp0+0x2ea4>
    2ea0:      	tbnz	w11, #0x0, 0x541c <ltmp0+0x541c>
    2ea4:      	mvn	w9, w10
    2ea8:      	rbit	w9, w9
    2eac:      	clz	w9, w9
    2eb0:      	mov	w13, #0xff              ; =255
    2eb4:      	bics	wzr, w13, w10
    2eb8:      	csel	w13, wzr, w9, eq
    2ebc:      	ubfiz	x9, x13, #2, #3
    2ec0:      	lsl	w14, w20, w13
    2ec4:      	ldr	q5, [sp, #0x460]
    2ec8:      	str	q5, [sp, #0x8e0]
    2ecc:      	ldr	q4, [sp, #0x470]
    2ed0:      	str	q4, [sp, #0x8f0]
    2ed4:      	add	x16, sp, #0x8e0
    2ed8:      	ldr	w16, [x16, x9]
    2edc:      	cmp	w11, #0x0
    2ee0:      	csel	w11, w14, wzr, ne
    2ee4:      	mov	w14, #0x4               ; =4
    2ee8:      	csel	w14, w14, w16, ne
    2eec:      	str	q5, [sp, #0x8c0]
    2ef0:      	str	q4, [sp, #0x8d0]
    2ef4:      	add	x16, sp, #0x8c0
    2ef8:      	str	w14, [x16, x9]
    2efc:      	ldr	q4, [sp, #0x8d0]
    2f00:      	str	q4, [sp, #0x470]
    2f04:      	ldr	q4, [sp, #0x8c0]
    2f08:      	str	q4, [sp, #0x460]
    2f0c:      	ldr	q5, [sp, #0x440]
    2f10:      	str	q5, [sp, #0x8a0]
    2f14:      	ldr	q4, [sp, #0x450]
    2f18:      	str	q4, [sp, #0x8b0]
    2f1c:      	add	x14, sp, #0x8a0
    2f20:      	ldr	w14, [x14, x9]
    2f24:      	csel	w14, w12, w14, ne
    2f28:      	str	q5, [sp, #0x880]
    2f2c:      	str	q4, [sp, #0x890]
    2f30:      	add	x16, sp, #0x880
    2f34:      	str	w14, [x16, x9]
    2f38:      	ldrb	w9, [x27, x13]
    2f3c:      	and	w14, w9, #0x1
    2f40:      	fmov	s4, w14
    2f44:      	ubfx	w14, w9, #1, #1
    2f48:      	mov.b	v4[1], w14
    2f4c:      	ubfx	w14, w9, #2, #1
    2f50:      	mov.b	v4[2], w14
    2f54:      	ubfx	w14, w9, #3, #1
    2f58:      	mov.b	v4[3], w14
    2f5c:      	ubfx	w14, w9, #4, #1
    2f60:      	mov.b	v4[4], w14
    2f64:      	ubfx	w14, w9, #5, #1
    2f68:      	mov.b	v4[5], w14
    2f6c:      	ubfx	w14, w9, #6, #1
    2f70:      	mov.b	v4[6], w14
    2f74:      	ldr	q5, [sp, #0x890]
    2f78:      	str	q5, [sp, #0x450]
    2f7c:      	ldr	q5, [sp, #0x880]
    2f80:      	str	q5, [sp, #0x440]
    2f84:      	lsr	w9, w9, #7
    2f88:      	mov.b	v4[7], w9
    2f8c:      	ldrb	w9, [x8, x13]
    2f90:      	and	w14, w9, #0x1
    2f94:      	fmov	s6, w14
    2f98:      	ubfx	w14, w9, #1, #1
    2f9c:      	mov.b	v6[1], w14
    2fa0:      	ubfx	w14, w9, #2, #1
    2fa4:      	mov.b	v6[2], w14
    2fa8:      	ubfx	w14, w9, #3, #1
    2fac:      	mov.b	v6[3], w14
    2fb0:      	ubfx	w14, w9, #4, #1
    2fb4:      	mov.b	v6[4], w14
    2fb8:      	ubfx	w14, w9, #5, #1
    2fbc:      	mov.b	v6[5], w14
    2fc0:      	ubfx	w14, w9, #6, #1
    2fc4:      	mov.b	v6[6], w14
    2fc8:      	lsr	w9, w9, #7
    2fcc:      	mov.b	v6[7], w9
    2fd0:      	csetm	w9, ne
    2fd4:      	dup.8b	v7, w9
    2fd8:      	bit.8b	v4, v21, v7
    2fdc:      	shl.8b	v4, v4, #0x7
    2fe0:      	cmlt.8b	v4, v4, #0
    2fe4:      	and.8b	v4, v4, v2
    2fe8:      	addv.8b	b4, v4
    2fec:      	str	b4, [x27, x13]
    2ff0:      	bic.8b	v4, v6, v7
    2ff4:      	shl.8b	v4, v4, #0x7
    2ff8:      	cmlt.8b	v4, v4, #0
    2ffc:      	and.8b	v4, v4, v2
    3000:      	addv.8b	b4, v4
    3004:      	str	b4, [x8, x13]
    3008:      	csinc	w12, w12, w13, eq
    300c:      	cmp	w26, #0x8
    3010:      	b.hs	0x541c <ltmp0+0x541c>
    3014:      	str	b1, [x21, x28]
    3018:      	mov	w9, #0xe                ; =14
    301c:      	str	w9, [x22, x28, lsl #2]
    3020:      	str	w12, [x23, x28, lsl #2]
    3024:      	cmp	w19, #0x8
    3028:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    302c:      	add	x16, x16, #0x160
    3030:      	b.hs	0x541c <ltmp0+0x541c>
    3034:      	str	b3, [x21, w19, uxtw]
    3038:      	orr	w10, w11, w10
    303c:      	mov	w9, #0xf                ; =15
    3040:      	b	0xfe8 <ltmp0+0xfe8>
    3044:      	fmov	w9, s1
    3048:      	tst	w9, #0xff
    304c:      	b.eq	0x319c <ltmp0+0x319c>
    3050:      	rbit	w13, w11
    3054:      	clz	w13, w13
    3058:      	tst	w11, #0xff
    305c:      	csel	w13, wzr, w13, eq
    3060:      	str	q27, [sp, #0xd90]
    3064:      	str	q13, [sp, #0xda0]
    3068:      	ldr	q0, [sp, #0x400]
    306c:      	str	q0, [sp, #0xdb0]
    3070:      	str	q26, [sp, #0xdc0]
    3074:      	and	x14, x13, #0x7
    3078:      	add	x9, sp, #0xd90
    307c:      	ldr	x14, [x9, x14, lsl #3]
    3080:      	sub	x14, x14, x13
    3084:      	ldr	x9, [sp, #0x80]
    3088:      	add	x14, x9, x14, lsl #2
    308c:      	shl.8b	v1, v21, #0x7
    3090:      	cmlt.8b	v1, v1, #0
    3094:      	and.8b	v1, v1, v2
    3098:      	addv.8b	b1, v1
    309c:      	fmov	w17, s1
    30a0:      	movi.2d	v1, #0000000000000000
    30a4:      	movi.2d	v3, #0000000000000000
    30a8:      	tbz	w17, #0x0, 0x30e8 <ltmp0+0x30e8>
    30ac:      	ldr	s1, [x14]
    30b0:      	tbnz	w17, #0x1, 0x30ec <ltmp0+0x30ec>
    30b4:      	tbz	w17, #0x2, 0x30f8 <ltmp0+0x30f8>
    30b8:      	add	x1, x14, #0x8
    30bc:      	ld1.s	{ v1 }[2], [x1]
    30c0:      	tbnz	w17, #0x3, 0x30fc <ltmp0+0x30fc>
    30c4:      	tbz	w17, #0x4, 0x3108 <ltmp0+0x3108>
    30c8:      	add	x1, x14, #0x10
    30cc:      	ld1.s	{ v3 }[0], [x1]
    30d0:      	tbnz	w17, #0x5, 0x310c <ltmp0+0x310c>
    30d4:      	tbz	w17, #0x6, 0x3118 <ltmp0+0x3118>
    30d8:      	add	x1, x14, #0x18
    30dc:      	ld1.s	{ v3 }[2], [x1]
    30e0:      	tbnz	w17, #0x7, 0x311c <ltmp0+0x311c>
    30e4:      	b	0x3124 <ltmp0+0x3124>
    30e8:      	tbz	w17, #0x1, 0x30b4 <ltmp0+0x30b4>
    30ec:      	add	x1, x14, #0x4
    30f0:      	ld1.s	{ v1 }[1], [x1]
    30f4:      	tbnz	w17, #0x2, 0x30b8 <ltmp0+0x30b8>
    30f8:      	tbz	w17, #0x3, 0x30c4 <ltmp0+0x30c4>
    30fc:      	add	x1, x14, #0xc
    3100:      	ld1.s	{ v1 }[3], [x1]
    3104:      	tbnz	w17, #0x4, 0x30c8 <ltmp0+0x30c8>
    3108:      	tbz	w17, #0x5, 0x30d4 <ltmp0+0x30d4>
    310c:      	add	x1, x14, #0x14
    3110:      	ld1.s	{ v3 }[1], [x1]
    3114:      	tbnz	w17, #0x6, 0x30d8 <ltmp0+0x30d8>
    3118:      	tbz	w17, #0x7, 0x3124 <ltmp0+0x3124>
    311c:      	add	x14, x14, #0x1c
    3120:      	ld1.s	{ v3 }[3], [x14]
    3124:      	ldr	q0, [sp, #0x390]
    3128:      	str	q0, [sp, #0xd50]
    312c:      	ldp	q4, q0, [sp, #0x3c0]
    3130:      	str	q4, [sp, #0xd60]
    3134:      	str	q0, [sp, #0xd70]
    3138:      	ldr	q0, [sp, #0x3b0]
    313c:      	str	q0, [sp, #0xd80]
    3140:      	and	x14, x13, #0x7
    3144:      	add	x9, sp, #0xd50
    3148:      	ldr	x14, [x9, x14, lsl #3]
    314c:      	sub	x13, x14, x13, lsl #2
    3150:      	add	x13, x13, #0x100
    3154:      	ands	w11, w11, #0xff
    3158:      	csel	x13, xzr, x13, eq
    315c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    3160:      	add	x9, x9, #0x2a8
    3164:      	add	x13, x9, x13
    3168:      	ldp	q4, q6, [x13]
    316c:      	zip2.8b	v7, v21, v0
    3170:      	ushll.4s	v7, v7, #0x0
    3174:      	shl.4s	v7, v7, #0x1f
    3178:      	cmlt.4s	v7, v7, #0
    317c:      	bif.16b	v3, v6, v7
    3180:      	zip1.8b	v6, v21, v0
    3184:      	ushll.4s	v6, v6, #0x0
    3188:      	shl.4s	v6, v6, #0x1f
    318c:      	cmlt.4s	v6, v6, #0
    3190:      	bif.16b	v1, v4, v6
    3194:      	stp	q1, q3, [x13]
    3198:      	cbz	w11, 0x2a8 <ltmp0+0x2a8>
    319c:      	cbz	w12, 0x3368 <ltmp0+0x3368>
    31a0:      	mov	w11, #0x0               ; =0
    31a4:      	shl.8b	v1, v21, #0x7
    31a8:      	cmlt.8b	v1, v1, #0
    31ac:      	and.8b	v3, v1, v2
    31b0:      	addv.8b	b3, v3
    31b4:      	fmov	w9, s3
    31b8:      	umaxv.8b	b1, v1
    31bc:      	fmov	w16, s1
    31c0:      	sub	w13, w12, #0x1
    31c4:      	tst	w9, #0xff
    31c8:      	csel	w14, w13, wzr, ne
    31cc:      	lsl	w17, w20, w14
    31d0:      	and	w9, w17, w10
    31d4:      	tst	w9, #0xff
    31d8:      	cset	w9, ne
    31dc:      	ldr	q1, [sp, #0x460]
    31e0:      	str	q1, [sp, #0xd30]
    31e4:      	ldr	q1, [sp, #0x470]
    31e8:      	str	q1, [sp, #0xd40]
    31ec:      	ubfiz	x13, x14, #2, #3
    31f0:      	add	x0, sp, #0xd30
    31f4:      	ldr	w0, [x0, x13]
    31f8:      	cmp	w0, #0x4
    31fc:      	cset	w1, eq
    3200:      	and	w2, w9, w16
    3204:      	ldrb	w9, [x27, w14, sxtw]
    3208:      	and	w16, w9, #0x1
    320c:      	fmov	s1, w16
    3210:      	ubfx	w16, w9, #1, #1
    3214:      	mov.b	v1[1], w16
    3218:      	ubfx	w16, w9, #2, #1
    321c:      	mov.b	v1[2], w16
    3220:      	ubfx	w16, w9, #3, #1
    3224:      	mov.b	v1[3], w16
    3228:      	ubfx	w16, w9, #4, #1
    322c:      	mov.b	v1[4], w16
    3230:      	ubfx	w16, w9, #5, #1
    3234:      	mov.b	v1[5], w16
    3238:      	ubfx	w16, w9, #6, #1
    323c:      	mov.b	v1[6], w16
    3240:      	lsr	w9, w9, #7
    3244:      	mov.b	v1[7], w9
    3248:      	ldrb	w9, [x8, w14, sxtw]
    324c:      	and	w16, w9, #0x1
    3250:      	fmov	s3, w16
    3254:      	ubfx	w16, w9, #1, #1
    3258:      	mov.b	v3[1], w16
    325c:      	ubfx	w16, w9, #2, #1
    3260:      	mov.b	v3[2], w16
    3264:      	ubfx	w16, w9, #3, #1
    3268:      	mov.b	v3[3], w16
    326c:      	ubfx	w16, w9, #4, #1
    3270:      	mov.b	v3[4], w16
    3274:      	ubfx	w16, w9, #5, #1
    3278:      	mov.b	v3[5], w16
    327c:      	ubfx	w16, w9, #6, #1
    3280:      	mov.b	v3[6], w16
    3284:      	lsr	w9, w9, #7
    3288:      	mov.b	v3[7], w9
    328c:      	orr.8b	v4, v21, v3
    3290:      	and.8b	v6, v12, v1
    3294:      	eor.8b	v6, v6, v4
    3298:      	shl.8b	v6, v6, #0x7
    329c:      	cmlt.8b	v6, v6, #0
    32a0:      	umaxv.8b	b6, v6
    32a4:      	fmov	w9, s6
    32a8:      	ands	w16, w2, w1
    32ac:      	csetm	w0, ne
    32b0:      	bics	w9, w16, w9
    32b4:      	csetm	w1, ne
    32b8:      	dup.8b	v6, w1
    32bc:      	dup.8b	v7, w0
    32c0:      	bic.8b	v16, v4, v6
    32c4:      	bit.8b	v3, v16, v7
    32c8:      	shl.8b	v3, v3, #0x7
    32cc:      	cmlt.8b	v3, v3, #0
    32d0:      	and.8b	v3, v3, v2
    32d4:      	addv.8b	b3, v3
    32d8:      	str	b3, [x8, w14, sxtw]
    32dc:      	bic.8b	v1, v1, v6
    32e0:      	shl.8b	v1, v1, #0x7
    32e4:      	cmlt.8b	v1, v1, #0
    32e8:      	and.8b	v1, v1, v2
    32ec:      	addv.8b	b1, v1
    32f0:      	str	b1, [x27, w14, sxtw]
    32f4:      	csinv	w14, w5, w17, eq
    32f8:      	dup.8b	v1, w16
    32fc:      	and	w10, w14, w10
    3300:      	shl.8b	v1, v1, #0x7
    3304:      	cmlt.8b	v1, v1, #0
    3308:      	dup.8b	v3, w9
    330c:      	and.8b	v3, v3, v4
    3310:      	ldr	q4, [sp, #0x440]
    3314:      	str	q4, [sp, #0xd10]
    3318:      	ldr	q4, [sp, #0x450]
    331c:      	str	q4, [sp, #0xd20]
    3320:      	add	x9, sp, #0xd10
    3324:      	ldr	w9, [x9, x13]
    3328:      	csel	w12, w9, w12, ne
    332c:      	bit.8b	v21, v3, v1
    3330:      	shl.8b	v1, v21, #0x7
    3334:      	cmlt.8b	v1, v1, #0
    3338:      	and.8b	v1, v1, v2
    333c:      	addv.8b	b1, v1
    3340:      	fmov	w13, s1
    3344:      	cmp	w16, #0x1
    3348:      	b.ne	0x337c <ltmp0+0x337c>
    334c:      	cmp	w12, #0x0
    3350:      	ccmp	w11, #0x6, #0x2, ne
    3354:      	b.hi	0x337c <ltmp0+0x337c>
    3358:      	add	w11, w11, #0x1
    335c:      	tst	w13, #0xff
    3360:      	b.ne	0x31a4 <ltmp0+0x31a4>
    3364:      	b	0x337c <ltmp0+0x337c>
    3368:      	shl.8b	v1, v21, #0x7
    336c:      	cmlt.8b	v1, v1, #0
    3370:      	and.8b	v1, v1, v2
    3374:      	addv.8b	b1, v1
    3378:      	fmov	w13, s1
    337c:      	tst	w13, #0xff
    3380:      	b.eq	0x298 <ltmp0+0x298>
    3384:      	rbit	w9, w13
    3388:      	clz	w9, w9
    338c:      	ldp	q1, q0, [sp, #0xf0]
    3390:      	str	q0, [sp, #0xcf0]
    3394:      	str	q1, [sp, #0xd00]
    3398:      	and	x9, x9, #0x7
    339c:      	add	x11, sp, #0xcf0
    33a0:      	ldr	s1, [x11, x9, lsl #2]
    33a4:      	mov	w9, #0xc5ac             ; =50604
    33a8:      	movk	w9, #0x3727, lsl #16
    33ac:      	fmov	s3, w9
    33b0:      	fadd	s1, s1, s3
    33b4:      	fsqrt	s1, s1
    33b8:      	dup.4s	v1, v1[0]
    33bc:      	zip2.8b	v3, v21, v0
    33c0:      	ushll.4s	v3, v3, #0x0
    33c4:      	shl.4s	v3, v3, #0x1f
    33c8:      	cmlt.4s	v3, v3, #0
    33cc:      	ldr	q0, [sp, #0x330]
    33d0:      	bit.16b	v0, v1, v3
    33d4:      	str	q0, [sp, #0x330]
    33d8:      	zip1.8b	v3, v21, v0
    33dc:      	ushll.4s	v3, v3, #0x0
    33e0:      	shl.4s	v3, v3, #0x1f
    33e4:      	cmlt.4s	v3, v3, #0
    33e8:      	ldr	q0, [sp, #0x320]
    33ec:      	bit.16b	v0, v1, v3
    33f0:      	str	q0, [sp, #0x320]
    33f4:      	mov	b1, v21[6]
    33f8:      	mov.b	v1[4], v21[7]
    33fc:      	ushll.2d	v1, v1, #0x0
    3400:      	shl.2d	v1, v1, #0x3f
    3404:      	cmge.2d	v1, v1, #0
    3408:      	ldr	q0, [sp, #0x430]
    340c:      	and.16b	v0, v1, v0
    3410:      	str	q0, [sp, #0x430]
    3414:      	mov	b1, v21[4]
    3418:      	mov.b	v1[4], v21[5]
    341c:      	ushll.2d	v1, v1, #0x0
    3420:      	shl.2d	v1, v1, #0x3f
    3424:      	cmge.2d	v1, v1, #0
    3428:      	mov	b3, v21[2]
    342c:      	mov.b	v3[4], v21[3]
    3430:      	ldr	q0, [sp, #0x420]
    3434:      	and.16b	v0, v1, v0
    3438:      	str	q0, [sp, #0x420]
    343c:      	ushll.2d	v1, v3, #0x0
    3440:      	shl.2d	v1, v1, #0x3f
    3444:      	cmge.2d	v1, v1, #0
    3448:      	ldr	q0, [sp, #0x3f0]
    344c:      	and.16b	v0, v1, v0
    3450:      	str	q0, [sp, #0x3f0]
    3454:      	mov	b1, v21[0]
    3458:      	mov.b	v1[4], v21[1]
    345c:      	ushll.2d	v1, v1, #0x0
    3460:      	shl.2d	v1, v1, #0x3f
    3464:      	cmge.2d	v1, v1, #0
    3468:      	and.16b	v23, v1, v23
    346c:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    3470:      	add	x0, x0, #0x180
    3474:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    3478:      	add	x16, x16, #0x160
    347c:      	shl.8b	v1, v21, #0x7
    3480:      	cmlt.8b	v1, v1, #0
    3484:      	and.8b	v1, v1, v2
    3488:      	addv.8b	b1, v1
    348c:      	fmov	w11, s1
    3490:      	mov	w9, #0x8                ; =8
    3494:      	dup.2d	v3, x9
    3498:      	ldr	q0, [sp, #0x3f0]
    349c:      	cmgt.2d	v1, v3, v0
    34a0:      	cmgt.2d	v4, v3, v23
    34a4:      	uzp1.4s	v1, v4, v1
    34a8:      	ldr	q0, [sp, #0x420]
    34ac:      	cmgt.2d	v4, v3, v0
    34b0:      	ldr	q0, [sp, #0x430]
    34b4:      	cmgt.2d	v6, v3, v0
    34b8:      	uzp1.4s	v4, v4, v6
    34bc:      	uzp1.8h	v1, v1, v4
    34c0:      	xtn.8b	v1, v1
    34c4:      	and.8b	v1, v21, v1
    34c8:      	shl.8b	v1, v1, #0x7
    34cc:      	cmlt.8b	v4, v1, #0
    34d0:      	and.8b	v1, v4, v2
    34d4:      	addv.8b	b1, v1
    34d8:      	fmov	w13, s1
    34dc:      	umaxv.8b	b4, v4
    34e0:      	fmov	w14, s4
    34e4:      	tbz	w14, #0x0, 0x371c <ltmp0+0x371c>
    34e8:      	ldr	q0, [sp, #0x3f0]
    34ec:      	cmge.2d	v4, v0, v3
    34f0:      	cmge.2d	v6, v23, v3
    34f4:      	uzp1.4s	v4, v6, v4
    34f8:      	ldr	q0, [sp, #0x420]
    34fc:      	cmge.2d	v6, v0, v3
    3500:      	ldr	q0, [sp, #0x430]
    3504:      	cmge.2d	v3, v0, v3
    3508:      	uzp1.4s	v3, v6, v3
    350c:      	uzp1.8h	v3, v4, v3
    3510:      	xtn.8b	v3, v3
    3514:      	and.8b	v3, v21, v3
    3518:      	shl.8b	v3, v3, #0x7
    351c:      	cmlt.8b	v3, v3, #0
    3520:      	and.8b	v3, v3, v2
    3524:      	addv.8b	b3, v3
    3528:      	fmov	w14, s3
    352c:      	tst	w14, #0xff
    3530:      	b.eq	0x371c <ltmp0+0x371c>
    3534:      	subs	w9, w12, #0x1
    3538:      	csel	w9, wzr, w9, lo
    353c:      	and	w13, w10, #0xff
    3540:      	lsr	w11, w13, w9
    3544:      	tst	w11, #0x1
    3548:      	ldr	q4, [sp, #0x460]
    354c:      	str	q4, [sp, #0x9a0]
    3550:      	ldr	q4, [sp, #0x470]
    3554:      	str	q4, [sp, #0x9b0]
    3558:      	and	x9, x9, #0x7
    355c:      	add	x11, sp, #0x9a0
    3560:      	ldr	w9, [x11, x9, lsl #2]
    3564:      	ccmp	w12, #0x0, #0x4, ne
    3568:      	ccmp	w9, #0x5, #0x0, ne
    356c:      	cset	w11, ne
    3570:      	cmp	w13, #0xff
    3574:      	b.ne	0x357c <ltmp0+0x357c>
    3578:      	tbnz	w11, #0x0, 0x541c <ltmp0+0x541c>
    357c:      	mvn	w9, w10
    3580:      	rbit	w9, w9
    3584:      	clz	w9, w9
    3588:      	mov	w13, #0xff              ; =255
    358c:      	bics	wzr, w13, w10
    3590:      	csel	w13, wzr, w9, eq
    3594:      	ubfiz	x9, x13, #2, #3
    3598:      	lsl	w14, w20, w13
    359c:      	ldr	q5, [sp, #0x460]
    35a0:      	str	q5, [sp, #0x980]
    35a4:      	ldr	q4, [sp, #0x470]
    35a8:      	str	q4, [sp, #0x990]
    35ac:      	add	x16, sp, #0x980
    35b0:      	ldr	w16, [x16, x9]
    35b4:      	cmp	w11, #0x0
    35b8:      	csel	w11, w14, wzr, ne
    35bc:      	mov	w14, #0x5               ; =5
    35c0:      	csel	w14, w14, w16, ne
    35c4:      	str	q5, [sp, #0x960]
    35c8:      	str	q4, [sp, #0x970]
    35cc:      	add	x16, sp, #0x960
    35d0:      	str	w14, [x16, x9]
    35d4:      	ldr	q4, [sp, #0x970]
    35d8:      	str	q4, [sp, #0x470]
    35dc:      	ldr	q4, [sp, #0x960]
    35e0:      	str	q4, [sp, #0x460]
    35e4:      	ldr	q5, [sp, #0x440]
    35e8:      	str	q5, [sp, #0x940]
    35ec:      	ldr	q4, [sp, #0x450]
    35f0:      	str	q4, [sp, #0x950]
    35f4:      	add	x14, sp, #0x940
    35f8:      	ldr	w14, [x14, x9]
    35fc:      	csel	w14, w12, w14, ne
    3600:      	str	q5, [sp, #0x920]
    3604:      	str	q4, [sp, #0x930]
    3608:      	add	x16, sp, #0x920
    360c:      	str	w14, [x16, x9]
    3610:      	ldrb	w9, [x27, x13]
    3614:      	and	w14, w9, #0x1
    3618:      	fmov	s4, w14
    361c:      	ubfx	w14, w9, #1, #1
    3620:      	mov.b	v4[1], w14
    3624:      	ubfx	w14, w9, #2, #1
    3628:      	mov.b	v4[2], w14
    362c:      	ubfx	w14, w9, #3, #1
    3630:      	mov.b	v4[3], w14
    3634:      	ubfx	w14, w9, #4, #1
    3638:      	mov.b	v4[4], w14
    363c:      	ubfx	w14, w9, #5, #1
    3640:      	mov.b	v4[5], w14
    3644:      	ubfx	w14, w9, #6, #1
    3648:      	mov.b	v4[6], w14
    364c:      	ldr	q5, [sp, #0x930]
    3650:      	str	q5, [sp, #0x450]
    3654:      	ldr	q5, [sp, #0x920]
    3658:      	str	q5, [sp, #0x440]
    365c:      	lsr	w9, w9, #7
    3660:      	mov.b	v4[7], w9
    3664:      	ldrb	w9, [x8, x13]
    3668:      	and	w14, w9, #0x1
    366c:      	fmov	s6, w14
    3670:      	ubfx	w14, w9, #1, #1
    3674:      	mov.b	v6[1], w14
    3678:      	ubfx	w14, w9, #2, #1
    367c:      	mov.b	v6[2], w14
    3680:      	ubfx	w14, w9, #3, #1
    3684:      	mov.b	v6[3], w14
    3688:      	ubfx	w14, w9, #4, #1
    368c:      	mov.b	v6[4], w14
    3690:      	ubfx	w14, w9, #5, #1
    3694:      	mov.b	v6[5], w14
    3698:      	ubfx	w14, w9, #6, #1
    369c:      	mov.b	v6[6], w14
    36a0:      	lsr	w9, w9, #7
    36a4:      	mov.b	v6[7], w9
    36a8:      	csetm	w9, ne
    36ac:      	dup.8b	v7, w9
    36b0:      	bit.8b	v4, v21, v7
    36b4:      	shl.8b	v4, v4, #0x7
    36b8:      	cmlt.8b	v4, v4, #0
    36bc:      	and.8b	v4, v4, v2
    36c0:      	addv.8b	b4, v4
    36c4:      	str	b4, [x27, x13]
    36c8:      	bic.8b	v4, v6, v7
    36cc:      	shl.8b	v4, v4, #0x7
    36d0:      	cmlt.8b	v4, v4, #0
    36d4:      	and.8b	v4, v4, v2
    36d8:      	addv.8b	b4, v4
    36dc:      	str	b4, [x8, x13]
    36e0:      	csinc	w12, w12, w13, eq
    36e4:      	cmp	w26, #0x8
    36e8:      	b.hs	0x541c <ltmp0+0x541c>
    36ec:      	str	b1, [x21, x28]
    36f0:      	mov	w9, #0x11               ; =17
    36f4:      	str	w9, [x22, x28, lsl #2]
    36f8:      	str	w12, [x23, x28, lsl #2]
    36fc:      	cmp	w19, #0x8
    3700:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    3704:      	add	x16, x16, #0x160
    3708:      	b.hs	0x541c <ltmp0+0x541c>
    370c:      	str	b3, [x21, w19, uxtw]
    3710:      	orr	w10, w11, w10
    3714:      	mov	w9, #0x12               ; =18
    3718:      	b	0xfe8 <ltmp0+0xfe8>
    371c:      	tst	w13, #0xff
    3720:      	b.eq	0x3af4 <ltmp0+0x3af4>
    3724:      	tst	w11, #0xff
    3728:      	b.eq	0x2a8 <ltmp0+0x2a8>
    372c:      	str	q18, [sp, #0x160]
    3730:      	str	q29, [sp, #0x280]
    3734:      	str	d12, [sp, #0x298]
    3738:      	stp	q22, q24, [sp, #0x2e0]
    373c:      	ldr	q1, [sp, #0x3f0]
    3740:      	ldr	q5, [sp, #0x420]
    3744:      	str	q14, [sp, #0x300]
    3748:      	stp	q23, q25, [sp, #0x2c0]
    374c:      	str	q27, [sp, #0x380]
    3750:      	stp	q26, q13, [sp, #0x2a0]
    3754:      	mov.16b	v27, v11
    3758:      	mov.16b	v11, v15
    375c:      	mov.16b	v15, v10
    3760:      	ldr	q7, [sp, #0x430]
    3764:      	mov.16b	v0, v8
    3768:      	rbit	w13, w11
    376c:      	clz	w13, w13
    3770:      	tst	w11, #0xff
    3774:      	csel	w14, wzr, w13, eq
    3778:      	shl.2d	v3, v23, #0x5
    377c:      	shl.2d	v4, v1, #0x5
    3780:      	shl.2d	v6, v5, #0x5
    3784:      	shl.2d	v7, v7, #0x5
    3788:      	ldr	q1, [sp, #0x1a0]
    378c:      	ldp	q16, q5, [sp, #0x360]
    3790:      	add.2d	v1, v1, v5
    3794:      	add.2d	v25, v1, v3
    3798:      	ldr	q1, [sp, #0x190]
    379c:      	add.2d	v1, v1, v16
    37a0:      	add.2d	v23, v1, v4
    37a4:      	ldr	q1, [sp, #0x180]
    37a8:      	ldp	q16, q5, [sp, #0x340]
    37ac:      	add.2d	v1, v1, v5
    37b0:      	add.2d	v20, v1, v6
    37b4:      	ldr	q1, [sp, #0x170]
    37b8:      	add.2d	v1, v1, v16
    37bc:      	add.2d	v19, v1, v7
    37c0:      	shl.8b	v1, v21, #0x7
    37c4:      	cmlt.8b	v1, v1, #0
    37c8:      	and.8b	v1, v1, v2
    37cc:      	addv.8b	b1, v1
    37d0:      	fmov	w13, s1
    37d4:      	movi.2d	v17, #0000000000000000
    37d8:      	movi.2d	v16, #0000000000000000
    37dc:      	tbz	w13, #0x0, 0x3818 <ltmp0+0x3818>
    37e0:      	fmov	x17, d25
    37e4:      	ldr	s17, [x17]
    37e8:      	tbnz	w13, #0x1, 0x381c <ltmp0+0x381c>
    37ec:      	tbz	w13, #0x2, 0x3828 <ltmp0+0x3828>
    37f0:      	fmov	x17, d23
    37f4:      	ld1.s	{ v17 }[2], [x17]
    37f8:      	tbnz	w13, #0x3, 0x382c <ltmp0+0x382c>
    37fc:      	tbz	w13, #0x4, 0x3838 <ltmp0+0x3838>
    3800:      	fmov	x17, d20
    3804:      	ld1.s	{ v16 }[0], [x17]
    3808:      	mov.16b	v10, v15
    380c:      	mov.16b	v8, v0
    3810:      	tbnz	w13, #0x5, 0x3844 <ltmp0+0x3844>
    3814:      	b	0x384c <ltmp0+0x384c>
    3818:      	tbz	w13, #0x1, 0x37ec <ltmp0+0x37ec>
    381c:      	mov.d	x17, v25[1]
    3820:      	ld1.s	{ v17 }[1], [x17]
    3824:      	tbnz	w13, #0x2, 0x37f0 <ltmp0+0x37f0>
    3828:      	tbz	w13, #0x3, 0x37fc <ltmp0+0x37fc>
    382c:      	mov.d	x17, v23[1]
    3830:      	ld1.s	{ v17 }[3], [x17]
    3834:      	tbnz	w13, #0x4, 0x3800 <ltmp0+0x3800>
    3838:      	mov.16b	v10, v15
    383c:      	mov.16b	v8, v0
    3840:      	tbz	w13, #0x5, 0x384c <ltmp0+0x384c>
    3844:      	mov.d	x17, v20[1]
    3848:      	ld1.s	{ v16 }[1], [x17]
    384c:      	ldr	q29, [sp, #0x280]
    3850:      	ldr	q0, [sp, #0x3a0]
    3854:      	ldr	q18, [sp, #0x160]
    3858:      	str	q0, [sp, #0x3a0]
    385c:      	mov.16b	v0, v11
    3860:      	ldr	d12, [sp, #0x298]
    3864:      	tbz	w13, #0x6, 0x3870 <ltmp0+0x3870>
    3868:      	fmov	x17, d19
    386c:      	ld1.s	{ v16 }[2], [x17]
    3870:      	ldr	q11, [sp, #0x380]
    3874:      	ldp	q24, q14, [sp, #0x2f0]
    3878:      	ldr	q22, [sp, #0x2e0]
    387c:      	ldr	q13, [sp, #0x2b0]
    3880:      	tbz	w13, #0x7, 0x388c <ltmp0+0x388c>
    3884:      	mov.d	x13, v19[1]
    3888:      	ld1.s	{ v16 }[3], [x13]
    388c:      	ldr	q5, [sp, #0x320]
    3890:      	str	q5, [sp, #0xa80]
    3894:      	ldr	q5, [sp, #0x330]
    3898:      	str	q5, [sp, #0xa90]
    389c:      	and	x13, x14, #0x7
    38a0:      	add	x9, sp, #0xa80
    38a4:      	add	x13, x9, x13, lsl #2
    38a8:      	ld1r.4s	{ v19 }, [x13]
    38ac:      	fdiv.4s	v16, v16, v19
    38b0:      	fdiv.4s	v17, v17, v19
    38b4:      	ldr	q5, [sp, #0x3b0]
    38b8:      	add.2d	v23, v7, v5
    38bc:      	ldp	q5, q7, [sp, #0x3c0]
    38c0:      	add.2d	v6, v6, v7
    38c4:      	add.2d	v4, v4, v5
    38c8:      	ldr	q5, [sp, #0x390]
    38cc:      	add.2d	v3, v3, v5
    38d0:      	ldr	q5, [sp, #0x1e0]
    38d4:      	add.2d	v20, v5, v3
    38d8:      	ldp	q5, q3, [sp, #0x1c0]
    38dc:      	add.2d	v19, v5, v4
    38e0:      	add.2d	v7, v3, v6
    38e4:      	ldr	q3, [sp, #0x1f0]
    38e8:      	add.2d	v6, v3, v23
    38ec:      	fmov	w13, s1
    38f0:      	movi.2d	v3, #0000000000000000
    38f4:      	movi.2d	v4, #0000000000000000
    38f8:      	ldr	q26, [sp, #0x2a0]
    38fc:      	tbz	w13, #0x0, 0x395c <ltmp0+0x395c>
    3900:      	fmov	x17, d20
    3904:      	ldr	s3, [x17]
    3908:      	ldr	q23, [sp, #0x2c0]
    390c:      	tbnz	w13, #0x1, 0x3964 <ltmp0+0x3964>
    3910:      	ldr	q25, [sp, #0x2d0]
    3914:      	movi.8b	v20, #0x1
    3918:      	mov.16b	v5, v11
    391c:      	tbz	w13, #0x2, 0x397c <ltmp0+0x397c>
    3920:      	fmov	x17, d19
    3924:      	ld1.s	{ v3 }[2], [x17]
    3928:      	mov.16b	v15, v0
    392c:      	mov.16b	v11, v27
    3930:      	mov.16b	v27, v5
    3934:      	tbnz	w13, #0x3, 0x398c <ltmp0+0x398c>
    3938:      	tbz	w13, #0x4, 0x3998 <ltmp0+0x3998>
    393c:      	fmov	x17, d7
    3940:      	ld1.s	{ v4 }[0], [x17]
    3944:      	tbnz	w13, #0x5, 0x399c <ltmp0+0x399c>
    3948:      	tbz	w13, #0x6, 0x39a8 <ltmp0+0x39a8>
    394c:      	fmov	x17, d6
    3950:      	ld1.s	{ v4 }[2], [x17]
    3954:      	tbnz	w13, #0x7, 0x39ac <ltmp0+0x39ac>
    3958:      	b	0x39b4 <ltmp0+0x39b4>
    395c:      	ldr	q23, [sp, #0x2c0]
    3960:      	tbz	w13, #0x1, 0x3910 <ltmp0+0x3910>
    3964:      	mov.d	x17, v20[1]
    3968:      	ld1.s	{ v3 }[1], [x17]
    396c:      	ldr	q25, [sp, #0x2d0]
    3970:      	movi.8b	v20, #0x1
    3974:      	mov.16b	v5, v11
    3978:      	tbnz	w13, #0x2, 0x3920 <ltmp0+0x3920>
    397c:      	mov.16b	v15, v0
    3980:      	mov.16b	v11, v27
    3984:      	mov.16b	v27, v5
    3988:      	tbz	w13, #0x3, 0x3938 <ltmp0+0x3938>
    398c:      	mov.d	x17, v19[1]
    3990:      	ld1.s	{ v3 }[3], [x17]
    3994:      	tbnz	w13, #0x4, 0x393c <ltmp0+0x393c>
    3998:      	tbz	w13, #0x5, 0x3948 <ltmp0+0x3948>
    399c:      	mov.d	x17, v7[1]
    39a0:      	ld1.s	{ v4 }[1], [x17]
    39a4:      	tbnz	w13, #0x6, 0x394c <ltmp0+0x394c>
    39a8:      	tbz	w13, #0x7, 0x39b4 <ltmp0+0x39b4>
    39ac:      	mov.d	x13, v6[1]
    39b0:      	ld1.s	{ v4 }[3], [x13]
    39b4:      	fmul.4s	v6, v3, v17
    39b8:      	fmul.4s	v3, v4, v16
    39bc:      	ldp	q4, q0, [sp, #0x250]
    39c0:      	str	q0, [sp, #0xa40]
    39c4:      	str	q4, [sp, #0xa50]
    39c8:      	ldp	q4, q0, [sp, #0x230]
    39cc:      	str	q0, [sp, #0xa60]
    39d0:      	str	q4, [sp, #0xa70]
    39d4:      	ubfiz	x13, x14, #3, #3
    39d8:      	add	x9, sp, #0xa40
    39dc:      	ldr	x17, [x9, x13]
    39e0:      	str	q23, [sp, #0xa00]
    39e4:      	ldr	q0, [sp, #0x3f0]
    39e8:      	str	q0, [sp, #0xa10]
    39ec:      	ldr	q0, [sp, #0x420]
    39f0:      	str	q0, [sp, #0xa20]
    39f4:      	ldr	q0, [sp, #0x430]
    39f8:      	str	q0, [sp, #0xa30]
    39fc:      	add	x9, sp, #0xa00
    3a00:      	ldr	x1, [x9, x13]
    3a04:      	str	q27, [sp, #0x9c0]
    3a08:      	str	q13, [sp, #0x9d0]
    3a0c:      	ldr	q0, [sp, #0x400]
    3a10:      	str	q0, [sp, #0x9e0]
    3a14:      	str	q26, [sp, #0x9f0]
    3a18:      	add	x9, sp, #0x9c0
    3a1c:      	ldr	x13, [x9, x13]
    3a20:      	add	x17, x17, x17, lsl #6
    3a24:      	sub	x13, x13, x14
    3a28:      	add	x13, x13, x17
    3a2c:      	add	x14, x3, x1, lsl #5
    3a30:      	add	x13, x14, x13, lsl #2
    3a34:      	fmov	w14, s1
    3a38:      	tbz	w14, #0x0, 0x3a74 <ltmp0+0x3a74>
    3a3c:      	str	s6, [x13]
    3a40:      	tbnz	w14, #0x1, 0x3a78 <ltmp0+0x3a78>
    3a44:      	tbz	w14, #0x2, 0x3a84 <ltmp0+0x3a84>
    3a48:      	add	x17, x13, #0x8
    3a4c:      	st1.s	{ v6 }[2], [x17]
    3a50:      	tbnz	w14, #0x3, 0x3a88 <ltmp0+0x3a88>
    3a54:      	tbz	w14, #0x4, 0x3a94 <ltmp0+0x3a94>
    3a58:      	str	s3, [x13, #0x10]
    3a5c:      	tbnz	w14, #0x5, 0x3a98 <ltmp0+0x3a98>
    3a60:      	tbz	w14, #0x6, 0x3aa4 <ltmp0+0x3aa4>
    3a64:      	add	x17, x13, #0x18
    3a68:      	st1.s	{ v3 }[2], [x17]
    3a6c:      	tbnz	w14, #0x7, 0x3aa8 <ltmp0+0x3aa8>
    3a70:      	b	0x3ab0 <ltmp0+0x3ab0>
    3a74:      	tbz	w14, #0x1, 0x3a44 <ltmp0+0x3a44>
    3a78:      	add	x17, x13, #0x4
    3a7c:      	st1.s	{ v6 }[1], [x17]
    3a80:      	tbnz	w14, #0x2, 0x3a48 <ltmp0+0x3a48>
    3a84:      	tbz	w14, #0x3, 0x3a54 <ltmp0+0x3a54>
    3a88:      	add	x17, x13, #0xc
    3a8c:      	st1.s	{ v6 }[3], [x17]
    3a90:      	tbnz	w14, #0x4, 0x3a58 <ltmp0+0x3a58>
    3a94:      	tbz	w14, #0x5, 0x3a60 <ltmp0+0x3a60>
    3a98:      	add	x17, x13, #0x14
    3a9c:      	st1.s	{ v3 }[1], [x17]
    3aa0:      	tbnz	w14, #0x6, 0x3a64 <ltmp0+0x3a64>
    3aa4:      	tbz	w14, #0x7, 0x3ab0 <ltmp0+0x3ab0>
    3aa8:      	add	x13, x13, #0x1c
    3aac:      	st1.s	{ v3 }[3], [x13]
    3ab0:      	and.8b	v1, v21, v20
    3ab4:      	ushll.8h	v1, v1, #0x0
    3ab8:      	ushll.4s	v3, v1, #0x0
    3abc:      	ushll2.4s	v1, v1, #0x0
    3ac0:      	ldr	q0, [sp, #0x430]
    3ac4:      	uaddw2.2d	v0, v0, v1
    3ac8:      	str	q0, [sp, #0x430]
    3acc:      	ldr	q0, [sp, #0x420]
    3ad0:      	uaddw.2d	v0, v0, v1
    3ad4:      	str	q0, [sp, #0x420]
    3ad8:      	ldr	q0, [sp, #0x3f0]
    3adc:      	uaddw2.2d	v0, v0, v3
    3ae0:      	str	q0, [sp, #0x3f0]
    3ae4:      	uaddw.2d	v23, v23, v3
    3ae8:      	tst	w11, #0xff
    3aec:      	b.ne	0x347c <ltmp0+0x347c>
    3af0:      	b	0x2a8 <ltmp0+0x2a8>
    3af4:      	tst	w11, #0xff
    3af8:      	b.eq	0x2a8 <ltmp0+0x2a8>
    3afc:      	cbz	w12, 0x3cc8 <ltmp0+0x3cc8>
    3b00:      	mov	w13, #0x0               ; =0
    3b04:      	shl.8b	v1, v21, #0x7
    3b08:      	cmlt.8b	v1, v1, #0
    3b0c:      	and.8b	v3, v1, v2
    3b10:      	addv.8b	b3, v3
    3b14:      	fmov	w9, s3
    3b18:      	umaxv.8b	b1, v1
    3b1c:      	fmov	w16, s1
    3b20:      	sub	w11, w12, #0x1
    3b24:      	tst	w9, #0xff
    3b28:      	csel	w14, w11, wzr, ne
    3b2c:      	lsl	w17, w20, w14
    3b30:      	and	w9, w17, w10
    3b34:      	tst	w9, #0xff
    3b38:      	cset	w9, ne
    3b3c:      	ldr	q1, [sp, #0x460]
    3b40:      	str	q1, [sp, #0xcd0]
    3b44:      	ldr	q1, [sp, #0x470]
    3b48:      	str	q1, [sp, #0xce0]
    3b4c:      	ubfiz	x11, x14, #2, #3
    3b50:      	add	x0, sp, #0xcd0
    3b54:      	ldr	w0, [x0, x11]
    3b58:      	cmp	w0, #0x5
    3b5c:      	cset	w1, eq
    3b60:      	and	w2, w9, w16
    3b64:      	ldrb	w9, [x27, w14, sxtw]
    3b68:      	and	w16, w9, #0x1
    3b6c:      	fmov	s1, w16
    3b70:      	ubfx	w16, w9, #1, #1
    3b74:      	mov.b	v1[1], w16
    3b78:      	ubfx	w16, w9, #2, #1
    3b7c:      	mov.b	v1[2], w16
    3b80:      	ubfx	w16, w9, #3, #1
    3b84:      	mov.b	v1[3], w16
    3b88:      	ubfx	w16, w9, #4, #1
    3b8c:      	mov.b	v1[4], w16
    3b90:      	ubfx	w16, w9, #5, #1
    3b94:      	mov.b	v1[5], w16
    3b98:      	ubfx	w16, w9, #6, #1
    3b9c:      	mov.b	v1[6], w16
    3ba0:      	lsr	w9, w9, #7
    3ba4:      	mov.b	v1[7], w9
    3ba8:      	ldrb	w9, [x8, w14, sxtw]
    3bac:      	and	w16, w9, #0x1
    3bb0:      	fmov	s3, w16
    3bb4:      	ubfx	w16, w9, #1, #1
    3bb8:      	mov.b	v3[1], w16
    3bbc:      	ubfx	w16, w9, #2, #1
    3bc0:      	mov.b	v3[2], w16
    3bc4:      	ubfx	w16, w9, #3, #1
    3bc8:      	mov.b	v3[3], w16
    3bcc:      	ubfx	w16, w9, #4, #1
    3bd0:      	mov.b	v3[4], w16
    3bd4:      	ubfx	w16, w9, #5, #1
    3bd8:      	mov.b	v3[5], w16
    3bdc:      	ubfx	w16, w9, #6, #1
    3be0:      	mov.b	v3[6], w16
    3be4:      	lsr	w9, w9, #7
    3be8:      	mov.b	v3[7], w9
    3bec:      	orr.8b	v4, v21, v3
    3bf0:      	and.8b	v6, v12, v1
    3bf4:      	eor.8b	v6, v6, v4
    3bf8:      	shl.8b	v6, v6, #0x7
    3bfc:      	cmlt.8b	v6, v6, #0
    3c00:      	umaxv.8b	b6, v6
    3c04:      	fmov	w9, s6
    3c08:      	ands	w16, w2, w1
    3c0c:      	csetm	w0, ne
    3c10:      	bics	w9, w16, w9
    3c14:      	csetm	w1, ne
    3c18:      	dup.8b	v6, w1
    3c1c:      	dup.8b	v7, w0
    3c20:      	bic.8b	v16, v4, v6
    3c24:      	bit.8b	v3, v16, v7
    3c28:      	shl.8b	v3, v3, #0x7
    3c2c:      	cmlt.8b	v3, v3, #0
    3c30:      	and.8b	v3, v3, v2
    3c34:      	addv.8b	b3, v3
    3c38:      	str	b3, [x8, w14, sxtw]
    3c3c:      	bic.8b	v1, v1, v6
    3c40:      	shl.8b	v1, v1, #0x7
    3c44:      	cmlt.8b	v1, v1, #0
    3c48:      	and.8b	v1, v1, v2
    3c4c:      	addv.8b	b1, v1
    3c50:      	str	b1, [x27, w14, sxtw]
    3c54:      	csinv	w14, w5, w17, eq
    3c58:      	dup.8b	v1, w16
    3c5c:      	and	w10, w14, w10
    3c60:      	shl.8b	v1, v1, #0x7
    3c64:      	cmlt.8b	v1, v1, #0
    3c68:      	dup.8b	v3, w9
    3c6c:      	and.8b	v3, v3, v4
    3c70:      	ldr	q4, [sp, #0x440]
    3c74:      	str	q4, [sp, #0xcb0]
    3c78:      	ldr	q4, [sp, #0x450]
    3c7c:      	str	q4, [sp, #0xcc0]
    3c80:      	add	x9, sp, #0xcb0
    3c84:      	ldr	w9, [x9, x11]
    3c88:      	csel	w12, w9, w12, ne
    3c8c:      	bit.8b	v21, v3, v1
    3c90:      	shl.8b	v1, v21, #0x7
    3c94:      	cmlt.8b	v1, v1, #0
    3c98:      	and.8b	v1, v1, v2
    3c9c:      	addv.8b	b1, v1
    3ca0:      	fmov	w11, s1
    3ca4:      	cmp	w16, #0x1
    3ca8:      	b.ne	0x3cdc <ltmp0+0x3cdc>
    3cac:      	cmp	w12, #0x0
    3cb0:      	ccmp	w13, #0x6, #0x2, ne
    3cb4:      	b.hi	0x3cdc <ltmp0+0x3cdc>
    3cb8:      	add	w13, w13, #0x1
    3cbc:      	tst	w11, #0xff
    3cc0:      	b.ne	0x3b04 <ltmp0+0x3b04>
    3cc4:      	b	0x3cdc <ltmp0+0x3cdc>
    3cc8:      	shl.8b	v1, v21, #0x7
    3ccc:      	cmlt.8b	v1, v1, #0
    3cd0:      	and.8b	v1, v1, v2
    3cd4:      	addv.8b	b1, v1
    3cd8:      	fmov	w11, s1
    3cdc:      	tst	w11, #0xff
    3ce0:      	b.eq	0x298 <ltmp0+0x298>
    3ce4:      	and.8b	v1, v15, v21
    3ce8:      	shl.8b	v1, v1, #0x7
    3cec:      	cmlt.8b	v3, v1, #0
    3cf0:      	and.8b	v1, v3, v2
    3cf4:      	addv.8b	b1, v1
    3cf8:      	umaxv.8b	b3, v3
    3cfc:      	fmov	w9, s3
    3d00:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    3d04:      	add	x0, x0, #0x180
    3d08:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    3d0c:      	add	x16, x16, #0x160
    3d10:      	tbz	w9, #0x0, 0x3f1c <ltmp0+0x3f1c>
    3d14:      	bic.8b	v3, v21, v15
    3d18:      	shl.8b	v3, v3, #0x7
    3d1c:      	cmlt.8b	v3, v3, #0
    3d20:      	and.8b	v3, v3, v2
    3d24:      	addv.8b	b3, v3
    3d28:      	fmov	w9, s3
    3d2c:      	tst	w9, #0xff
    3d30:      	b.eq	0x3f1c <ltmp0+0x3f1c>
    3d34:      	subs	w9, w12, #0x1
    3d38:      	csel	w9, wzr, w9, lo
    3d3c:      	and	w13, w10, #0xff
    3d40:      	lsr	w11, w13, w9
    3d44:      	tst	w11, #0x1
    3d48:      	ldr	q4, [sp, #0x460]
    3d4c:      	str	q4, [sp, #0xb20]
    3d50:      	ldr	q4, [sp, #0x470]
    3d54:      	str	q4, [sp, #0xb30]
    3d58:      	and	x9, x9, #0x7
    3d5c:      	add	x11, sp, #0xb20
    3d60:      	ldr	w9, [x11, x9, lsl #2]
    3d64:      	ccmp	w12, #0x0, #0x4, ne
    3d68:      	ccmp	w9, #0x6, #0x0, ne
    3d6c:      	cset	w11, ne
    3d70:      	cmp	w13, #0xff
    3d74:      	b.ne	0x3d7c <ltmp0+0x3d7c>
    3d78:      	tbnz	w11, #0x0, 0x541c <ltmp0+0x541c>
    3d7c:      	mvn	w9, w10
    3d80:      	rbit	w9, w9
    3d84:      	clz	w9, w9
    3d88:      	mov	w13, #0xff              ; =255
    3d8c:      	bics	wzr, w13, w10
    3d90:      	csel	w13, wzr, w9, eq
    3d94:      	ubfiz	x9, x13, #2, #3
    3d98:      	lsl	w14, w20, w13
    3d9c:      	ldr	q5, [sp, #0x460]
    3da0:      	str	q5, [sp, #0xb00]
    3da4:      	ldr	q4, [sp, #0x470]
    3da8:      	str	q4, [sp, #0xb10]
    3dac:      	add	x16, sp, #0xb00
    3db0:      	ldr	w16, [x16, x9]
    3db4:      	cmp	w11, #0x0
    3db8:      	csel	w11, w14, wzr, ne
    3dbc:      	mov	w14, #0x6               ; =6
    3dc0:      	csel	w14, w14, w16, ne
    3dc4:      	str	q5, [sp, #0xae0]
    3dc8:      	str	q4, [sp, #0xaf0]
    3dcc:      	add	x16, sp, #0xae0
    3dd0:      	str	w14, [x16, x9]
    3dd4:      	ldr	q4, [sp, #0xaf0]
    3dd8:      	str	q4, [sp, #0x470]
    3ddc:      	ldr	q4, [sp, #0xae0]
    3de0:      	str	q4, [sp, #0x460]
    3de4:      	ldr	q5, [sp, #0x440]
    3de8:      	str	q5, [sp, #0xac0]
    3dec:      	ldr	q4, [sp, #0x450]
    3df0:      	str	q4, [sp, #0xad0]
    3df4:      	add	x14, sp, #0xac0
    3df8:      	ldr	w14, [x14, x9]
    3dfc:      	csel	w14, w12, w14, ne
    3e00:      	str	q5, [sp, #0xaa0]
    3e04:      	str	q4, [sp, #0xab0]
    3e08:      	add	x16, sp, #0xaa0
    3e0c:      	str	w14, [x16, x9]
    3e10:      	ldrb	w9, [x27, x13]
    3e14:      	and	w14, w9, #0x1
    3e18:      	fmov	s4, w14
    3e1c:      	ubfx	w14, w9, #1, #1
    3e20:      	mov.b	v4[1], w14
    3e24:      	ubfx	w14, w9, #2, #1
    3e28:      	mov.b	v4[2], w14
    3e2c:      	ubfx	w14, w9, #3, #1
    3e30:      	mov.b	v4[3], w14
    3e34:      	ubfx	w14, w9, #4, #1
    3e38:      	mov.b	v4[4], w14
    3e3c:      	ubfx	w14, w9, #5, #1
    3e40:      	mov.b	v4[5], w14
    3e44:      	ubfx	w14, w9, #6, #1
    3e48:      	mov.b	v4[6], w14
    3e4c:      	ldr	q5, [sp, #0xab0]
    3e50:      	str	q5, [sp, #0x450]
    3e54:      	ldr	q5, [sp, #0xaa0]
    3e58:      	str	q5, [sp, #0x440]
    3e5c:      	lsr	w9, w9, #7
    3e60:      	mov.b	v4[7], w9
    3e64:      	ldrb	w9, [x8, x13]
    3e68:      	and	w14, w9, #0x1
    3e6c:      	fmov	s6, w14
    3e70:      	ubfx	w14, w9, #1, #1
    3e74:      	mov.b	v6[1], w14
    3e78:      	ubfx	w14, w9, #2, #1
    3e7c:      	mov.b	v6[2], w14
    3e80:      	ubfx	w14, w9, #3, #1
    3e84:      	mov.b	v6[3], w14
    3e88:      	ubfx	w14, w9, #4, #1
    3e8c:      	mov.b	v6[4], w14
    3e90:      	ubfx	w14, w9, #5, #1
    3e94:      	mov.b	v6[5], w14
    3e98:      	ubfx	w14, w9, #6, #1
    3e9c:      	mov.b	v6[6], w14
    3ea0:      	lsr	w9, w9, #7
    3ea4:      	mov.b	v6[7], w9
    3ea8:      	csetm	w9, ne
    3eac:      	dup.8b	v7, w9
    3eb0:      	bit.8b	v4, v21, v7
    3eb4:      	shl.8b	v4, v4, #0x7
    3eb8:      	cmlt.8b	v4, v4, #0
    3ebc:      	and.8b	v4, v4, v2
    3ec0:      	addv.8b	b4, v4
    3ec4:      	str	b4, [x27, x13]
    3ec8:      	bic.8b	v4, v6, v7
    3ecc:      	shl.8b	v4, v4, #0x7
    3ed0:      	cmlt.8b	v4, v4, #0
    3ed4:      	and.8b	v4, v4, v2
    3ed8:      	addv.8b	b4, v4
    3edc:      	str	b4, [x8, x13]
    3ee0:      	csinc	w12, w12, w13, eq
    3ee4:      	cmp	w26, #0x8
    3ee8:      	b.hs	0x541c <ltmp0+0x541c>
    3eec:      	str	b1, [x21, x28]
    3ef0:      	mov	w9, #0x13               ; =19
    3ef4:      	str	w9, [x22, x28, lsl #2]
    3ef8:      	str	w12, [x23, x28, lsl #2]
    3efc:      	cmp	w19, #0x8
    3f00:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    3f04:      	add	x16, x16, #0x160
    3f08:      	b.hs	0x541c <ltmp0+0x541c>
    3f0c:      	str	b3, [x21, w19, uxtw]
    3f10:      	orr	w10, w11, w10
    3f14:      	mov	w9, #0x14               ; =20
    3f18:      	b	0xfe8 <ltmp0+0xfe8>
    3f1c:      	fmov	w9, s1
    3f20:      	tst	w9, #0xff
    3f24:      	b.eq	0x40f8 <ltmp0+0x40f8>
    3f28:      	rbit	w13, w11
    3f2c:      	clz	w13, w13
    3f30:      	tst	w11, #0xff
    3f34:      	csel	w14, wzr, w13, eq
    3f38:      	mov	w9, #0x100              ; =256
    3f3c:      	sub	x17, x9, w14, uxtw #2
    3f40:      	tst	w11, #0xff
    3f44:      	ldp	q1, q0, [sp, #0x360]
    3f48:      	str	q0, [sp, #0xc70]
    3f4c:      	str	q1, [sp, #0xc80]
    3f50:      	ldp	q1, q0, [sp, #0x340]
    3f54:      	str	q0, [sp, #0xc90]
    3f58:      	str	q1, [sp, #0xca0]
    3f5c:      	and	x1, x14, #0x7
    3f60:      	add	x9, sp, #0xc50
    3f64:      	add	x2, x9, x1, lsl #2
    3f68:      	add	x9, sp, #0xc70
    3f6c:      	ldr	x13, [x9, x1, lsl #3]
    3f70:      	add	x13, x17, x13
    3f74:      	csel	x13, xzr, x13, eq
    3f78:      	add	x13, x15, x13
    3f7c:      	ldp	q3, q1, [x13]
    3f80:      	zip1.8b	v4, v21, v0
    3f84:      	ushll.4s	v4, v4, #0x0
    3f88:      	shl.4s	v4, v4, #0x1f
    3f8c:      	cmlt.4s	v6, v4, #0
    3f90:      	and.16b	v4, v6, v3
    3f94:      	shl.8b	v3, v21, #0x7
    3f98:      	cmlt.8b	v3, v3, #0
    3f9c:      	and.8b	v3, v3, v2
    3fa0:      	addv.8b	b3, v3
    3fa4:      	fmov	w13, s3
    3fa8:      	ldp	q5, q0, [sp, #0x320]
    3fac:      	str	q5, [sp, #0xc50]
    3fb0:      	str	q0, [sp, #0xc60]
    3fb4:      	ld1r.4s	{ v3 }, [x2]
    3fb8:      	fdiv.4s	v7, v4, v3
    3fbc:      	ldr	q0, [sp, #0x390]
    3fc0:      	str	q0, [sp, #0xc10]
    3fc4:      	ldp	q4, q0, [sp, #0x3c0]
    3fc8:      	str	q4, [sp, #0xc20]
    3fcc:      	str	q0, [sp, #0xc30]
    3fd0:      	ldr	q0, [sp, #0x3b0]
    3fd4:      	str	q0, [sp, #0xc40]
    3fd8:      	add	x9, sp, #0xc10
    3fdc:      	ldr	x2, [x9, x1, lsl #3]
    3fe0:      	add	x17, x17, x2
    3fe4:      	csel	x17, xzr, x17, eq
    3fe8:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    3fec:      	add	x9, x9, #0x2a8
    3ff0:      	add	x17, x9, x17
    3ff4:      	ldp	q16, q4, [x17]
    3ff8:      	and.16b	v6, v6, v16
    3ffc:      	ldp	q16, q0, [sp, #0x250]
    4000:      	str	q0, [sp, #0xbd0]
    4004:      	str	q16, [sp, #0xbe0]
    4008:      	ldp	q16, q0, [sp, #0x230]
    400c:      	str	q0, [sp, #0xbf0]
    4010:      	str	q16, [sp, #0xc00]
    4014:      	add	x9, sp, #0xbd0
    4018:      	ldr	x17, [x9, x1, lsl #3]
    401c:      	fmul.4s	v6, v7, v6
    4020:      	add	x17, x17, x17, lsl #6
    4024:      	str	q27, [sp, #0xb90]
    4028:      	str	q13, [sp, #0xba0]
    402c:      	ldr	q0, [sp, #0x400]
    4030:      	str	q0, [sp, #0xbb0]
    4034:      	str	q26, [sp, #0xbc0]
    4038:      	add	x9, sp, #0xb90
    403c:      	ldr	x1, [x9, x1, lsl #3]
    4040:      	sub	x14, x1, x14
    4044:      	add	x14, x14, x17
    4048:      	add	x14, x3, x14, lsl #2
    404c:      	add	x14, x14, #0x100
    4050:      	tbz	w13, #0x0, 0x4070 <ltmp0+0x4070>
    4054:      	str	s6, [x14]
    4058:      	tbnz	w13, #0x1, 0x4074 <ltmp0+0x4074>
    405c:      	tbz	w13, #0x2, 0x4080 <ltmp0+0x4080>
    4060:      	add	x17, x14, #0x8
    4064:      	st1.s	{ v6 }[2], [x17]
    4068:      	tbnz	w13, #0x3, 0x4084 <ltmp0+0x4084>
    406c:      	b	0x408c <ltmp0+0x408c>
    4070:      	tbz	w13, #0x1, 0x405c <ltmp0+0x405c>
    4074:      	add	x17, x14, #0x4
    4078:      	st1.s	{ v6 }[1], [x17]
    407c:      	tbnz	w13, #0x2, 0x4060 <ltmp0+0x4060>
    4080:      	tbz	w13, #0x3, 0x408c <ltmp0+0x408c>
    4084:      	add	x17, x14, #0xc
    4088:      	st1.s	{ v6 }[3], [x17]
    408c:      	zip2.8b	v6, v21, v0
    4090:      	ushll.4s	v6, v6, #0x0
    4094:      	shl.4s	v6, v6, #0x1f
    4098:      	cmlt.4s	v6, v6, #0
    409c:      	and.16b	v1, v6, v1
    40a0:      	fdiv.4s	v1, v1, v3
    40a4:      	and.16b	v3, v6, v4
    40a8:      	fmul.4s	v1, v1, v3
    40ac:      	tbz	w13, #0x4, 0x40d4 <ltmp0+0x40d4>
    40b0:      	str	s1, [x14, #0x10]
    40b4:      	tbnz	w13, #0x5, 0x40d8 <ltmp0+0x40d8>
    40b8:      	tbz	w13, #0x6, 0x40e4 <ltmp0+0x40e4>
    40bc:      	add	x17, x14, #0x18
    40c0:      	st1.s	{ v1 }[2], [x17]
    40c4:      	tbnz	w13, #0x7, 0x40e8 <ltmp0+0x40e8>
    40c8:      	tst	w11, #0xff
    40cc:      	b.ne	0x40f8 <ltmp0+0x40f8>
    40d0:      	b	0x2a8 <ltmp0+0x2a8>
    40d4:      	tbz	w13, #0x5, 0x40b8 <ltmp0+0x40b8>
    40d8:      	add	x17, x14, #0x14
    40dc:      	st1.s	{ v1 }[1], [x17]
    40e0:      	tbnz	w13, #0x6, 0x40bc <ltmp0+0x40bc>
    40e4:      	tbz	w13, #0x7, 0x40c8 <ltmp0+0x40c8>
    40e8:      	add	x13, x14, #0x1c
    40ec:      	st1.s	{ v1 }[3], [x13]
    40f0:      	tst	w11, #0xff
    40f4:      	b.eq	0x2a8 <ltmp0+0x2a8>
    40f8:      	cbz	w12, 0x42c4 <ltmp0+0x42c4>
    40fc:      	mov	w11, #0x0               ; =0
    4100:      	shl.8b	v1, v21, #0x7
    4104:      	cmlt.8b	v1, v1, #0
    4108:      	and.8b	v3, v1, v2
    410c:      	addv.8b	b3, v3
    4110:      	fmov	w9, s3
    4114:      	umaxv.8b	b1, v1
    4118:      	fmov	w16, s1
    411c:      	sub	w13, w12, #0x1
    4120:      	tst	w9, #0xff
    4124:      	csel	w14, w13, wzr, ne
    4128:      	lsl	w17, w20, w14
    412c:      	and	w9, w17, w10
    4130:      	tst	w9, #0xff
    4134:      	cset	w9, ne
    4138:      	ldr	q1, [sp, #0x460]
    413c:      	str	q1, [sp, #0xb70]
    4140:      	ldr	q1, [sp, #0x470]
    4144:      	str	q1, [sp, #0xb80]
    4148:      	ubfiz	x13, x14, #2, #3
    414c:      	add	x0, sp, #0xb70
    4150:      	ldr	w0, [x0, x13]
    4154:      	cmp	w0, #0x6
    4158:      	cset	w1, eq
    415c:      	and	w2, w9, w16
    4160:      	ldrb	w9, [x27, w14, sxtw]
    4164:      	and	w16, w9, #0x1
    4168:      	fmov	s1, w16
    416c:      	ubfx	w16, w9, #1, #1
    4170:      	mov.b	v1[1], w16
    4174:      	ubfx	w16, w9, #2, #1
    4178:      	mov.b	v1[2], w16
    417c:      	ubfx	w16, w9, #3, #1
    4180:      	mov.b	v1[3], w16
    4184:      	ubfx	w16, w9, #4, #1
    4188:      	mov.b	v1[4], w16
    418c:      	ubfx	w16, w9, #5, #1
    4190:      	mov.b	v1[5], w16
    4194:      	ubfx	w16, w9, #6, #1
    4198:      	mov.b	v1[6], w16
    419c:      	lsr	w9, w9, #7
    41a0:      	mov.b	v1[7], w9
    41a4:      	ldrb	w9, [x8, w14, sxtw]
    41a8:      	and	w16, w9, #0x1
    41ac:      	fmov	s3, w16
    41b0:      	ubfx	w16, w9, #1, #1
    41b4:      	mov.b	v3[1], w16
    41b8:      	ubfx	w16, w9, #2, #1
    41bc:      	mov.b	v3[2], w16
    41c0:      	ubfx	w16, w9, #3, #1
    41c4:      	mov.b	v3[3], w16
    41c8:      	ubfx	w16, w9, #4, #1
    41cc:      	mov.b	v3[4], w16
    41d0:      	ubfx	w16, w9, #5, #1
    41d4:      	mov.b	v3[5], w16
    41d8:      	ubfx	w16, w9, #6, #1
    41dc:      	mov.b	v3[6], w16
    41e0:      	lsr	w9, w9, #7
    41e4:      	mov.b	v3[7], w9
    41e8:      	orr.8b	v4, v21, v3
    41ec:      	and.8b	v6, v12, v1
    41f0:      	eor.8b	v6, v6, v4
    41f4:      	shl.8b	v6, v6, #0x7
    41f8:      	cmlt.8b	v6, v6, #0
    41fc:      	umaxv.8b	b6, v6
    4200:      	fmov	w9, s6
    4204:      	ands	w16, w2, w1
    4208:      	csetm	w0, ne
    420c:      	bics	w9, w16, w9
    4210:      	csetm	w1, ne
    4214:      	dup.8b	v6, w1
    4218:      	dup.8b	v7, w0
    421c:      	bic.8b	v16, v4, v6
    4220:      	bit.8b	v3, v16, v7
    4224:      	shl.8b	v3, v3, #0x7
    4228:      	cmlt.8b	v3, v3, #0
    422c:      	and.8b	v3, v3, v2
    4230:      	addv.8b	b3, v3
    4234:      	str	b3, [x8, w14, sxtw]
    4238:      	bic.8b	v1, v1, v6
    423c:      	shl.8b	v1, v1, #0x7
    4240:      	cmlt.8b	v1, v1, #0
    4244:      	and.8b	v1, v1, v2
    4248:      	addv.8b	b1, v1
    424c:      	str	b1, [x27, w14, sxtw]
    4250:      	csinv	w14, w5, w17, eq
    4254:      	dup.8b	v1, w16
    4258:      	and	w10, w14, w10
    425c:      	shl.8b	v1, v1, #0x7
    4260:      	cmlt.8b	v1, v1, #0
    4264:      	dup.8b	v3, w9
    4268:      	and.8b	v3, v3, v4
    426c:      	ldr	q4, [sp, #0x440]
    4270:      	str	q4, [sp, #0xb50]
    4274:      	ldr	q4, [sp, #0x450]
    4278:      	str	q4, [sp, #0xb60]
    427c:      	add	x9, sp, #0xb50
    4280:      	ldr	w9, [x9, x13]
    4284:      	csel	w12, w9, w12, ne
    4288:      	bit.8b	v21, v3, v1
    428c:      	shl.8b	v1, v21, #0x7
    4290:      	cmlt.8b	v1, v1, #0
    4294:      	and.8b	v1, v1, v2
    4298:      	addv.8b	b1, v1
    429c:      	fmov	w13, s1
    42a0:      	cmp	w16, #0x1
    42a4:      	b.ne	0x42d8 <ltmp0+0x42d8>
    42a8:      	cmp	w12, #0x0
    42ac:      	ccmp	w11, #0x6, #0x2, ne
    42b0:      	b.hi	0x42d8 <ltmp0+0x42d8>
    42b4:      	add	w11, w11, #0x1
    42b8:      	tst	w13, #0xff
    42bc:      	b.ne	0x4100 <ltmp0+0x4100>
    42c0:      	b	0x42d8 <ltmp0+0x42d8>
    42c4:      	shl.8b	v1, v21, #0x7
    42c8:      	cmlt.8b	v1, v1, #0
    42cc:      	and.8b	v1, v1, v2
    42d0:      	addv.8b	b1, v1
    42d4:      	fmov	w13, s1
    42d8:      	tst	w13, #0xff
    42dc:      	b.eq	0x298 <ltmp0+0x298>
    42e0:      	bic.8b	v12, v12, v21
    42e4:      	tst	w10, #0xff
    42e8:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    42ec:      	add	x0, x0, #0x180
    42f0:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    42f4:      	add	x16, x16, #0x160
    42f8:      	b.eq	0x53cc <ltmp0+0x53cc>
    42fc:      	ldrb	w9, [x8, #0x8]
    4300:      	and	w11, w9, #0x1
    4304:      	fmov	s1, w11
    4308:      	ubfx	w11, w9, #1, #1
    430c:      	mov.b	v1[1], w11
    4310:      	ubfx	w11, w9, #2, #1
    4314:      	mov.b	v1[2], w11
    4318:      	ubfx	w11, w9, #3, #1
    431c:      	mov.b	v1[3], w11
    4320:      	ubfx	w11, w9, #4, #1
    4324:      	mov.b	v1[4], w11
    4328:      	ubfx	w11, w9, #5, #1
    432c:      	mov.b	v1[5], w11
    4330:      	ubfx	w11, w9, #6, #1
    4334:      	mov.b	v1[6], w11
    4338:      	lsr	w9, w9, #7
    433c:      	mov.b	v1[7], w9
    4340:      	ldrb	w9, [x8]
    4344:      	and	w11, w9, #0x1
    4348:      	fmov	s6, w11
    434c:      	ubfx	w11, w9, #1, #1
    4350:      	mov.b	v6[1], w11
    4354:      	ubfx	w11, w9, #2, #1
    4358:      	mov.b	v6[2], w11
    435c:      	ubfx	w11, w9, #3, #1
    4360:      	mov.b	v6[3], w11
    4364:      	ubfx	w11, w9, #4, #1
    4368:      	mov.b	v6[4], w11
    436c:      	ubfx	w11, w9, #5, #1
    4370:      	mov.b	v6[5], w11
    4374:      	ubfx	w11, w9, #6, #1
    4378:      	mov.b	v6[6], w11
    437c:      	lsr	w9, w9, #7
    4380:      	mov.b	v6[7], w9
    4384:      	and.8b	v7, v12, v1
    4388:      	eor.8b	v1, v6, v7
    438c:      	shl.8b	v1, v1, #0x7
    4390:      	cmlt.8b	v3, v1, #0
    4394:      	umaxv.8b	b1, v3
    4398:      	fmov	w9, s1
    439c:      	eor	w9, w9, #0x1
    43a0:      	and	w9, w10, w9
    43a4:      	dup.8b	v1, w9
    43a8:      	and.8b	v1, v1, v6
    43ac:      	shl.8b	v4, v1, #0x7
    43b0:      	cmlt.8b	v4, v4, #0
    43b4:      	and.8b	v4, v4, v2
    43b8:      	addv.8b	b4, v4
    43bc:      	fmov	w12, s4
    43c0:      	tst	w9, #0x1
    43c4:      	csetm	w9, ne
    43c8:      	dup.8b	v16, w9
    43cc:      	bic.8b	v7, v7, v16
    43d0:      	shl.8b	v7, v7, #0x7
    43d4:      	cmlt.8b	v7, v7, #0
    43d8:      	and.8b	v7, v7, v2
    43dc:      	addv.8b	b7, v7
    43e0:      	str	b7, [x8, #0x8]
    43e4:      	bic.8b	v6, v6, v16
    43e8:      	shl.8b	v6, v6, #0x7
    43ec:      	cmlt.8b	v6, v6, #0
    43f0:      	and.8b	v6, v6, v2
    43f4:      	addv.8b	b6, v6
    43f8:      	str	b6, [x8]
    43fc:      	cmp	w26, #0x8
    4400:      	b.lo	0x440c <ltmp0+0x440c>
    4404:      	tst	w12, #0xff
    4408:      	b.ne	0x541c <ltmp0+0x541c>
    440c:      	and.8b	v3, v3, v2
    4410:      	addv.8b	b3, v3
    4414:      	fmov	w9, s3
    4418:      	ldr	d3, [sp, #0x48]
    441c:      	cmeq.8b	v3, v4, v3
    4420:      	mvn.8b	v3, v3
    4424:      	umov.b	w11, v3[0]
    4428:      	sbfx	w13, w11, #0, #1
    442c:      	fmov	s3, w13
    4430:      	sbfx	w13, w11, #1, #1
    4434:      	mov.b	v3[1], w13
    4438:      	sbfx	w13, w11, #2, #1
    443c:      	mov.b	v3[2], w13
    4440:      	sbfx	w13, w11, #3, #1
    4444:      	mov.b	v3[3], w13
    4448:      	sbfx	w13, w11, #4, #1
    444c:      	mov.b	v3[4], w13
    4450:      	sbfx	w13, w11, #5, #1
    4454:      	mov.b	v3[5], w13
    4458:      	sbfx	w13, w11, #6, #1
    445c:      	mov.b	v3[6], w13
    4460:      	sbfx	w11, w11, #7, #1
    4464:      	mov.b	v3[7], w11
    4468:      	and	w11, w10, #0xfffffffe
    446c:      	tst	w9, #0xff
    4470:      	csel	w11, w11, w10, eq
    4474:      	tst	w12, #0xff
    4478:      	csel	x9, x28, xzr, ne
    447c:      	ldrb	w10, [x21, x9]
    4480:      	and	w12, w10, #0x1
    4484:      	fmov	s4, w12
    4488:      	ubfx	w12, w10, #1, #1
    448c:      	mov.b	v4[1], w12
    4490:      	ubfx	w12, w10, #2, #1
    4494:      	mov.b	v4[2], w12
    4498:      	ubfx	w12, w10, #3, #1
    449c:      	mov.b	v4[3], w12
    44a0:      	ubfx	w12, w10, #4, #1
    44a4:      	mov.b	v4[4], w12
    44a8:      	ubfx	w12, w10, #5, #1
    44ac:      	mov.b	v4[5], w12
    44b0:      	ubfx	w12, w10, #6, #1
    44b4:      	mov.b	v4[6], w12
    44b8:      	lsr	w10, w10, #7
    44bc:      	mov.b	v4[7], w10
    44c0:      	bif.8b	v1, v4, v3
    44c4:      	ldr	q3, [sp, #0x460]
    44c8:      	fmov	w10, s3
    44cc:      	adrp	x17, 0x4000 <ltmp0+0x4000>
    44d0:      	add	x17, x17, #0x0
    44d4:      	add	x10, x17, w10, sxtw #2
    44d8:      	ldr	q3, [sp, #0x440]
    44dc:      	fmov	w12, s3
    44e0:      	shl.8b	v1, v1, #0x7
    44e4:      	cmlt.8b	v1, v1, #0
    44e8:      	and.8b	v1, v1, v2
    44ec:      	addv.8b	b1, v1
    44f0:      	str	b1, [x21, x9]
    44f4:      	lsl	x9, x9, #2
    44f8:      	add	x13, x22, x9
    44fc:      	csel	x10, x10, x13, ne
    4500:      	ldr	w10, [x10]
    4504:      	str	w10, [x13]
    4508:      	ldr	w10, [x23, x9]
    450c:      	csel	w10, w12, w10, ne
    4510:      	str	w10, [x23, x9]
    4514:      	csel	w10, w19, w26, ne
    4518:      	and	w9, w11, #0x2
    451c:      	ldrb	w12, [x8, #0x9]
    4520:      	and	w13, w12, #0x1
    4524:      	fmov	s1, w13
    4528:      	ubfx	w13, w12, #1, #1
    452c:      	mov.b	v1[1], w13
    4530:      	ubfx	w13, w12, #2, #1
    4534:      	mov.b	v1[2], w13
    4538:      	ubfx	w13, w12, #3, #1
    453c:      	mov.b	v1[3], w13
    4540:      	ubfx	w13, w12, #4, #1
    4544:      	mov.b	v1[4], w13
    4548:      	ubfx	w13, w12, #5, #1
    454c:      	mov.b	v1[5], w13
    4550:      	ubfx	w13, w12, #6, #1
    4554:      	mov.b	v1[6], w13
    4558:      	lsr	w12, w12, #7
    455c:      	mov.b	v1[7], w12
    4560:      	ldrb	w12, [x8, #0x1]
    4564:      	and	w13, w12, #0x1
    4568:      	fmov	s6, w13
    456c:      	ubfx	w13, w12, #1, #1
    4570:      	mov.b	v6[1], w13
    4574:      	ubfx	w13, w12, #2, #1
    4578:      	mov.b	v6[2], w13
    457c:      	ubfx	w13, w12, #3, #1
    4580:      	mov.b	v6[3], w13
    4584:      	ubfx	w13, w12, #4, #1
    4588:      	mov.b	v6[4], w13
    458c:      	ubfx	w13, w12, #5, #1
    4590:      	mov.b	v6[5], w13
    4594:      	ubfx	w13, w12, #6, #1
    4598:      	mov.b	v6[6], w13
    459c:      	lsr	w12, w12, #7
    45a0:      	mov.b	v6[7], w12
    45a4:      	and.8b	v7, v12, v1
    45a8:      	eor.8b	v1, v6, v7
    45ac:      	shl.8b	v1, v1, #0x7
    45b0:      	cmlt.8b	v3, v1, #0
    45b4:      	umaxv.8b	b1, v3
    45b8:      	fmov	w12, s1
    45bc:      	eor	w12, w12, #0x1
    45c0:      	ands	w9, w12, w9, lsr #1
    45c4:      	dup.8b	v1, w9
    45c8:      	and.8b	v1, v1, v6
    45cc:      	shl.8b	v4, v1, #0x7
    45d0:      	cmlt.8b	v4, v4, #0
    45d4:      	and.8b	v4, v4, v2
    45d8:      	addv.8b	b4, v4
    45dc:      	fmov	w12, s4
    45e0:      	csetm	w9, ne
    45e4:      	dup.8b	v16, w9
    45e8:      	bic.8b	v7, v7, v16
    45ec:      	shl.8b	v7, v7, #0x7
    45f0:      	cmlt.8b	v7, v7, #0
    45f4:      	and.8b	v7, v7, v2
    45f8:      	addv.8b	b7, v7
    45fc:      	stur	b7, [x8, #0x9]
    4600:      	bic.8b	v6, v6, v16
    4604:      	shl.8b	v6, v6, #0x7
    4608:      	cmlt.8b	v6, v6, #0
    460c:      	and.8b	v6, v6, v2
    4610:      	addv.8b	b6, v6
    4614:      	stur	b6, [x8, #0x1]
    4618:      	cmp	w10, #0x8
    461c:      	and	w9, w12, #0xff
    4620:      	ccmp	w9, #0x0, #0x4, hs
    4624:      	b.ne	0x541c <ltmp0+0x541c>
    4628:      	and.8b	v3, v3, v2
    462c:      	ldr	d6, [sp, #0x40]
    4630:      	cmeq.8b	v4, v4, v6
    4634:      	mvn.8b	v4, v4
    4638:      	umov.b	w9, v4[0]
    463c:      	addv.8b	b4, v3
    4640:      	sbfx	w13, w9, #0, #1
    4644:      	fmov	s3, w13
    4648:      	sbfx	w13, w9, #1, #1
    464c:      	mov.b	v3[1], w13
    4650:      	sbfx	w13, w9, #2, #1
    4654:      	mov.b	v3[2], w13
    4658:      	sbfx	w13, w9, #3, #1
    465c:      	mov.b	v3[3], w13
    4660:      	sbfx	w13, w9, #4, #1
    4664:      	mov.b	v3[4], w13
    4668:      	sbfx	w13, w9, #5, #1
    466c:      	mov.b	v3[5], w13
    4670:      	sbfx	w13, w9, #6, #1
    4674:      	mov.b	v3[6], w13
    4678:      	sbfx	w9, w9, #7, #1
    467c:      	mov.b	v3[7], w9
    4680:      	fmov	w9, s4
    4684:      	and	w13, w11, #0xfffffffd
    4688:      	tst	w9, #0xff
    468c:      	csel	w9, w13, w11, eq
    4690:      	sxtw	x11, w10
    4694:      	tst	w12, #0xff
    4698:      	csel	x11, x11, xzr, ne
    469c:      	ldrb	w12, [x21, x11]
    46a0:      	and	w13, w12, #0x1
    46a4:      	fmov	s4, w13
    46a8:      	ubfx	w13, w12, #1, #1
    46ac:      	mov.b	v4[1], w13
    46b0:      	ubfx	w13, w12, #2, #1
    46b4:      	mov.b	v4[2], w13
    46b8:      	ubfx	w13, w12, #3, #1
    46bc:      	mov.b	v4[3], w13
    46c0:      	ubfx	w13, w12, #4, #1
    46c4:      	mov.b	v4[4], w13
    46c8:      	ubfx	w13, w12, #5, #1
    46cc:      	mov.b	v4[5], w13
    46d0:      	ubfx	w13, w12, #6, #1
    46d4:      	mov.b	v4[6], w13
    46d8:      	lsr	w12, w12, #7
    46dc:      	mov.b	v4[7], w12
    46e0:      	bif.8b	v1, v4, v3
    46e4:      	ldr	q3, [sp, #0x460]
    46e8:      	mov.s	w12, v3[1]
    46ec:      	add	x12, x17, w12, sxtw #2
    46f0:      	ldr	q3, [sp, #0x440]
    46f4:      	mov.s	w13, v3[1]
    46f8:      	shl.8b	v1, v1, #0x7
    46fc:      	cmlt.8b	v1, v1, #0
    4700:      	and.8b	v1, v1, v2
    4704:      	addv.8b	b1, v1
    4708:      	str	b1, [x21, x11]
    470c:      	lsl	x11, x11, #2
    4710:      	add	x14, x22, x11
    4714:      	csel	x12, x12, x14, ne
    4718:      	ldr	w12, [x12]
    471c:      	str	w12, [x14]
    4720:      	ldr	w12, [x23, x11]
    4724:      	csel	w12, w13, w12, ne
    4728:      	str	w12, [x23, x11]
    472c:      	cinc	w10, w10, ne
    4730:      	and	w11, w9, #0x4
    4734:      	ldrb	w12, [x8, #0xa]
    4738:      	and	w13, w12, #0x1
    473c:      	fmov	s1, w13
    4740:      	ubfx	w13, w12, #1, #1
    4744:      	mov.b	v1[1], w13
    4748:      	ubfx	w13, w12, #2, #1
    474c:      	mov.b	v1[2], w13
    4750:      	ubfx	w13, w12, #3, #1
    4754:      	mov.b	v1[3], w13
    4758:      	ubfx	w13, w12, #4, #1
    475c:      	mov.b	v1[4], w13
    4760:      	ubfx	w13, w12, #5, #1
    4764:      	mov.b	v1[5], w13
    4768:      	ubfx	w13, w12, #6, #1
    476c:      	mov.b	v1[6], w13
    4770:      	lsr	w12, w12, #7
    4774:      	mov.b	v1[7], w12
    4778:      	ldrb	w12, [x8, #0x2]
    477c:      	and	w13, w12, #0x1
    4780:      	fmov	s6, w13
    4784:      	ubfx	w13, w12, #1, #1
    4788:      	mov.b	v6[1], w13
    478c:      	ubfx	w13, w12, #2, #1
    4790:      	mov.b	v6[2], w13
    4794:      	ubfx	w13, w12, #3, #1
    4798:      	mov.b	v6[3], w13
    479c:      	ubfx	w13, w12, #4, #1
    47a0:      	mov.b	v6[4], w13
    47a4:      	ubfx	w13, w12, #5, #1
    47a8:      	mov.b	v6[5], w13
    47ac:      	ubfx	w13, w12, #6, #1
    47b0:      	mov.b	v6[6], w13
    47b4:      	lsr	w12, w12, #7
    47b8:      	mov.b	v6[7], w12
    47bc:      	and.8b	v7, v12, v1
    47c0:      	eor.8b	v1, v6, v7
    47c4:      	shl.8b	v1, v1, #0x7
    47c8:      	cmlt.8b	v3, v1, #0
    47cc:      	umaxv.8b	b1, v3
    47d0:      	fmov	w12, s1
    47d4:      	eor	w12, w12, #0x1
    47d8:      	ands	w11, w12, w11, lsr #2
    47dc:      	dup.8b	v1, w11
    47e0:      	and.8b	v1, v1, v6
    47e4:      	shl.8b	v4, v1, #0x7
    47e8:      	cmlt.8b	v4, v4, #0
    47ec:      	and.8b	v4, v4, v2
    47f0:      	addv.8b	b4, v4
    47f4:      	fmov	w11, s4
    47f8:      	csetm	w12, ne
    47fc:      	dup.8b	v16, w12
    4800:      	bic.8b	v7, v7, v16
    4804:      	shl.8b	v7, v7, #0x7
    4808:      	cmlt.8b	v7, v7, #0
    480c:      	and.8b	v7, v7, v2
    4810:      	addv.8b	b7, v7
    4814:      	stur	b7, [x8, #0xa]
    4818:      	bic.8b	v6, v6, v16
    481c:      	shl.8b	v6, v6, #0x7
    4820:      	cmlt.8b	v6, v6, #0
    4824:      	and.8b	v6, v6, v2
    4828:      	addv.8b	b6, v6
    482c:      	stur	b6, [x8, #0x2]
    4830:      	cmp	w10, #0x8
    4834:      	and	w12, w11, #0xff
    4838:      	ccmp	w12, #0x0, #0x4, hs
    483c:      	b.ne	0x541c <ltmp0+0x541c>
    4840:      	and.8b	v3, v3, v2
    4844:      	ldr	d6, [sp, #0x38]
    4848:      	cmeq.8b	v4, v4, v6
    484c:      	mvn.8b	v4, v4
    4850:      	umov.b	w12, v4[0]
    4854:      	addv.8b	b4, v3
    4858:      	sbfx	w13, w12, #0, #1
    485c:      	fmov	s3, w13
    4860:      	sbfx	w13, w12, #1, #1
    4864:      	mov.b	v3[1], w13
    4868:      	sbfx	w13, w12, #2, #1
    486c:      	mov.b	v3[2], w13
    4870:      	sbfx	w13, w12, #3, #1
    4874:      	mov.b	v3[3], w13
    4878:      	sbfx	w13, w12, #4, #1
    487c:      	mov.b	v3[4], w13
    4880:      	sbfx	w13, w12, #5, #1
    4884:      	mov.b	v3[5], w13
    4888:      	sbfx	w13, w12, #6, #1
    488c:      	mov.b	v3[6], w13
    4890:      	sbfx	w12, w12, #7, #1
    4894:      	mov.b	v3[7], w12
    4898:      	fmov	w12, s4
    489c:      	and	w13, w9, #0xfffffffb
    48a0:      	tst	w12, #0xff
    48a4:      	csel	w9, w13, w9, eq
    48a8:      	sxtw	x12, w10
    48ac:      	tst	w11, #0xff
    48b0:      	csel	x11, x12, xzr, ne
    48b4:      	ldrb	w12, [x21, x11]
    48b8:      	and	w13, w12, #0x1
    48bc:      	fmov	s4, w13
    48c0:      	ubfx	w13, w12, #1, #1
    48c4:      	mov.b	v4[1], w13
    48c8:      	ubfx	w13, w12, #2, #1
    48cc:      	mov.b	v4[2], w13
    48d0:      	ubfx	w13, w12, #3, #1
    48d4:      	mov.b	v4[3], w13
    48d8:      	ubfx	w13, w12, #4, #1
    48dc:      	mov.b	v4[4], w13
    48e0:      	ubfx	w13, w12, #5, #1
    48e4:      	mov.b	v4[5], w13
    48e8:      	ubfx	w13, w12, #6, #1
    48ec:      	mov.b	v4[6], w13
    48f0:      	lsr	w12, w12, #7
    48f4:      	mov.b	v4[7], w12
    48f8:      	bif.8b	v1, v4, v3
    48fc:      	ldr	q3, [sp, #0x460]
    4900:      	mov.s	w12, v3[2]
    4904:      	add	x12, x17, w12, sxtw #2
    4908:      	ldr	q3, [sp, #0x440]
    490c:      	mov.s	w13, v3[2]
    4910:      	shl.8b	v1, v1, #0x7
    4914:      	cmlt.8b	v1, v1, #0
    4918:      	and.8b	v1, v1, v2
    491c:      	addv.8b	b1, v1
    4920:      	str	b1, [x21, x11]
    4924:      	lsl	x11, x11, #2
    4928:      	add	x14, x22, x11
    492c:      	csel	x12, x12, x14, ne
    4930:      	ldr	w12, [x12]
    4934:      	str	w12, [x14]
    4938:      	ldr	w12, [x23, x11]
    493c:      	csel	w12, w13, w12, ne
    4940:      	str	w12, [x23, x11]
    4944:      	cinc	w10, w10, ne
    4948:      	and	w11, w9, #0x8
    494c:      	ldrb	w12, [x8, #0xb]
    4950:      	and	w13, w12, #0x1
    4954:      	fmov	s1, w13
    4958:      	ubfx	w13, w12, #1, #1
    495c:      	mov.b	v1[1], w13
    4960:      	ubfx	w13, w12, #2, #1
    4964:      	mov.b	v1[2], w13
    4968:      	ubfx	w13, w12, #3, #1
    496c:      	mov.b	v1[3], w13
    4970:      	ubfx	w13, w12, #4, #1
    4974:      	mov.b	v1[4], w13
    4978:      	ubfx	w13, w12, #5, #1
    497c:      	mov.b	v1[5], w13
    4980:      	ubfx	w13, w12, #6, #1
    4984:      	mov.b	v1[6], w13
    4988:      	lsr	w12, w12, #7
    498c:      	mov.b	v1[7], w12
    4990:      	ldrb	w12, [x8, #0x3]
    4994:      	and	w13, w12, #0x1
    4998:      	fmov	s6, w13
    499c:      	ubfx	w13, w12, #1, #1
    49a0:      	mov.b	v6[1], w13
    49a4:      	ubfx	w13, w12, #2, #1
    49a8:      	mov.b	v6[2], w13
    49ac:      	ubfx	w13, w12, #3, #1
    49b0:      	mov.b	v6[3], w13
    49b4:      	ubfx	w13, w12, #4, #1
    49b8:      	mov.b	v6[4], w13
    49bc:      	ubfx	w13, w12, #5, #1
    49c0:      	mov.b	v6[5], w13
    49c4:      	ubfx	w13, w12, #6, #1
    49c8:      	mov.b	v6[6], w13
    49cc:      	lsr	w12, w12, #7
    49d0:      	mov.b	v6[7], w12
    49d4:      	and.8b	v7, v12, v1
    49d8:      	eor.8b	v1, v6, v7
    49dc:      	shl.8b	v1, v1, #0x7
    49e0:      	cmlt.8b	v3, v1, #0
    49e4:      	umaxv.8b	b1, v3
    49e8:      	fmov	w12, s1
    49ec:      	eor	w12, w12, #0x1
    49f0:      	ands	w11, w12, w11, lsr #3
    49f4:      	dup.8b	v1, w11
    49f8:      	and.8b	v1, v1, v6
    49fc:      	shl.8b	v4, v1, #0x7
    4a00:      	cmlt.8b	v4, v4, #0
    4a04:      	and.8b	v4, v4, v2
    4a08:      	addv.8b	b4, v4
    4a0c:      	fmov	w11, s4
    4a10:      	csetm	w12, ne
    4a14:      	dup.8b	v16, w12
    4a18:      	bic.8b	v7, v7, v16
    4a1c:      	shl.8b	v7, v7, #0x7
    4a20:      	cmlt.8b	v7, v7, #0
    4a24:      	and.8b	v7, v7, v2
    4a28:      	addv.8b	b7, v7
    4a2c:      	stur	b7, [x8, #0xb]
    4a30:      	bic.8b	v6, v6, v16
    4a34:      	shl.8b	v6, v6, #0x7
    4a38:      	cmlt.8b	v6, v6, #0
    4a3c:      	and.8b	v6, v6, v2
    4a40:      	addv.8b	b6, v6
    4a44:      	stur	b6, [x8, #0x3]
    4a48:      	cmp	w10, #0x8
    4a4c:      	and	w12, w11, #0xff
    4a50:      	ccmp	w12, #0x0, #0x4, hs
    4a54:      	b.ne	0x541c <ltmp0+0x541c>
    4a58:      	and.8b	v3, v3, v2
    4a5c:      	ldr	d6, [sp, #0x30]
    4a60:      	cmeq.8b	v4, v4, v6
    4a64:      	mvn.8b	v4, v4
    4a68:      	umov.b	w12, v4[0]
    4a6c:      	addv.8b	b4, v3
    4a70:      	sbfx	w13, w12, #0, #1
    4a74:      	fmov	s3, w13
    4a78:      	sbfx	w13, w12, #1, #1
    4a7c:      	mov.b	v3[1], w13
    4a80:      	sbfx	w13, w12, #2, #1
    4a84:      	mov.b	v3[2], w13
    4a88:      	sbfx	w13, w12, #3, #1
    4a8c:      	mov.b	v3[3], w13
    4a90:      	sbfx	w13, w12, #4, #1
    4a94:      	mov.b	v3[4], w13
    4a98:      	sbfx	w13, w12, #5, #1
    4a9c:      	mov.b	v3[5], w13
    4aa0:      	sbfx	w13, w12, #6, #1
    4aa4:      	mov.b	v3[6], w13
    4aa8:      	sbfx	w12, w12, #7, #1
    4aac:      	mov.b	v3[7], w12
    4ab0:      	fmov	w12, s4
    4ab4:      	and	w13, w9, #0xfffffff7
    4ab8:      	tst	w12, #0xff
    4abc:      	csel	w9, w13, w9, eq
    4ac0:      	sxtw	x12, w10
    4ac4:      	tst	w11, #0xff
    4ac8:      	csel	x11, x12, xzr, ne
    4acc:      	ldrb	w12, [x21, x11]
    4ad0:      	and	w13, w12, #0x1
    4ad4:      	fmov	s4, w13
    4ad8:      	ubfx	w13, w12, #1, #1
    4adc:      	mov.b	v4[1], w13
    4ae0:      	ubfx	w13, w12, #2, #1
    4ae4:      	mov.b	v4[2], w13
    4ae8:      	ubfx	w13, w12, #3, #1
    4aec:      	mov.b	v4[3], w13
    4af0:      	ubfx	w13, w12, #4, #1
    4af4:      	mov.b	v4[4], w13
    4af8:      	ubfx	w13, w12, #5, #1
    4afc:      	mov.b	v4[5], w13
    4b00:      	ubfx	w13, w12, #6, #1
    4b04:      	mov.b	v4[6], w13
    4b08:      	lsr	w12, w12, #7
    4b0c:      	mov.b	v4[7], w12
    4b10:      	bif.8b	v1, v4, v3
    4b14:      	ldr	q3, [sp, #0x460]
    4b18:      	mov.s	w12, v3[3]
    4b1c:      	add	x12, x17, w12, sxtw #2
    4b20:      	ldr	q3, [sp, #0x440]
    4b24:      	mov.s	w13, v3[3]
    4b28:      	shl.8b	v1, v1, #0x7
    4b2c:      	cmlt.8b	v1, v1, #0
    4b30:      	and.8b	v1, v1, v2
    4b34:      	addv.8b	b1, v1
    4b38:      	str	b1, [x21, x11]
    4b3c:      	lsl	x11, x11, #2
    4b40:      	add	x14, x22, x11
    4b44:      	csel	x12, x12, x14, ne
    4b48:      	ldr	w12, [x12]
    4b4c:      	str	w12, [x14]
    4b50:      	ldr	w12, [x23, x11]
    4b54:      	csel	w12, w13, w12, ne
    4b58:      	str	w12, [x23, x11]
    4b5c:      	cinc	w11, w10, ne
    4b60:      	and	w10, w9, #0x10
    4b64:      	ldrb	w12, [x8, #0xc]
    4b68:      	and	w13, w12, #0x1
    4b6c:      	fmov	s1, w13
    4b70:      	ubfx	w13, w12, #1, #1
    4b74:      	mov.b	v1[1], w13
    4b78:      	ubfx	w13, w12, #2, #1
    4b7c:      	mov.b	v1[2], w13
    4b80:      	ubfx	w13, w12, #3, #1
    4b84:      	mov.b	v1[3], w13
    4b88:      	ubfx	w13, w12, #4, #1
    4b8c:      	mov.b	v1[4], w13
    4b90:      	ubfx	w13, w12, #5, #1
    4b94:      	mov.b	v1[5], w13
    4b98:      	ubfx	w13, w12, #6, #1
    4b9c:      	mov.b	v1[6], w13
    4ba0:      	lsr	w12, w12, #7
    4ba4:      	mov.b	v1[7], w12
    4ba8:      	ldrb	w12, [x8, #0x4]
    4bac:      	and	w13, w12, #0x1
    4bb0:      	fmov	s6, w13
    4bb4:      	ubfx	w13, w12, #1, #1
    4bb8:      	mov.b	v6[1], w13
    4bbc:      	ubfx	w13, w12, #2, #1
    4bc0:      	mov.b	v6[2], w13
    4bc4:      	ubfx	w13, w12, #3, #1
    4bc8:      	mov.b	v6[3], w13
    4bcc:      	ubfx	w13, w12, #4, #1
    4bd0:      	mov.b	v6[4], w13
    4bd4:      	ubfx	w13, w12, #5, #1
    4bd8:      	mov.b	v6[5], w13
    4bdc:      	ubfx	w13, w12, #6, #1
    4be0:      	mov.b	v6[6], w13
    4be4:      	lsr	w12, w12, #7
    4be8:      	mov.b	v6[7], w12
    4bec:      	and.8b	v7, v12, v1
    4bf0:      	eor.8b	v1, v6, v7
    4bf4:      	shl.8b	v1, v1, #0x7
    4bf8:      	cmlt.8b	v3, v1, #0
    4bfc:      	umaxv.8b	b1, v3
    4c00:      	fmov	w12, s1
    4c04:      	eor	w12, w12, #0x1
    4c08:      	ands	w10, w12, w10, lsr #4
    4c0c:      	dup.8b	v1, w10
    4c10:      	and.8b	v1, v1, v6
    4c14:      	shl.8b	v4, v1, #0x7
    4c18:      	cmlt.8b	v4, v4, #0
    4c1c:      	and.8b	v4, v4, v2
    4c20:      	addv.8b	b4, v4
    4c24:      	fmov	w12, s4
    4c28:      	csetm	w10, ne
    4c2c:      	dup.8b	v16, w10
    4c30:      	bic.8b	v7, v7, v16
    4c34:      	shl.8b	v7, v7, #0x7
    4c38:      	cmlt.8b	v7, v7, #0
    4c3c:      	and.8b	v7, v7, v2
    4c40:      	addv.8b	b7, v7
    4c44:      	stur	b7, [x8, #0xc]
    4c48:      	bic.8b	v6, v6, v16
    4c4c:      	shl.8b	v6, v6, #0x7
    4c50:      	cmlt.8b	v6, v6, #0
    4c54:      	and.8b	v6, v6, v2
    4c58:      	addv.8b	b6, v6
    4c5c:      	stur	b6, [x8, #0x4]
    4c60:      	cmp	w11, #0x8
    4c64:      	and	w10, w12, #0xff
    4c68:      	ccmp	w10, #0x0, #0x4, hs
    4c6c:      	b.ne	0x541c <ltmp0+0x541c>
    4c70:      	and.8b	v3, v3, v2
    4c74:      	addv.8b	b3, v3
    4c78:      	fmov	w10, s3
    4c7c:      	ldr	d3, [sp, #0x28]
    4c80:      	cmeq.8b	v3, v4, v3
    4c84:      	mvn.8b	v3, v3
    4c88:      	umov.b	w13, v3[0]
    4c8c:      	sbfx	w14, w13, #0, #1
    4c90:      	fmov	s3, w14
    4c94:      	sbfx	w14, w13, #1, #1
    4c98:      	mov.b	v3[1], w14
    4c9c:      	sbfx	w14, w13, #2, #1
    4ca0:      	mov.b	v3[2], w14
    4ca4:      	sbfx	w14, w13, #3, #1
    4ca8:      	mov.b	v3[3], w14
    4cac:      	sbfx	w14, w13, #4, #1
    4cb0:      	mov.b	v3[4], w14
    4cb4:      	sbfx	w14, w13, #5, #1
    4cb8:      	mov.b	v3[5], w14
    4cbc:      	sbfx	w14, w13, #6, #1
    4cc0:      	mov.b	v3[6], w14
    4cc4:      	sbfx	w13, w13, #7, #1
    4cc8:      	mov.b	v3[7], w13
    4ccc:      	and	w13, w9, #0xffffffef
    4cd0:      	tst	w10, #0xff
    4cd4:      	csel	w10, w13, w9, eq
    4cd8:      	sxtw	x9, w11
    4cdc:      	tst	w12, #0xff
    4ce0:      	csel	x9, x9, xzr, ne
    4ce4:      	ldrb	w12, [x21, x9]
    4ce8:      	and	w13, w12, #0x1
    4cec:      	fmov	s4, w13
    4cf0:      	ubfx	w13, w12, #1, #1
    4cf4:      	mov.b	v4[1], w13
    4cf8:      	ubfx	w13, w12, #2, #1
    4cfc:      	mov.b	v4[2], w13
    4d00:      	ubfx	w13, w12, #3, #1
    4d04:      	mov.b	v4[3], w13
    4d08:      	ubfx	w13, w12, #4, #1
    4d0c:      	mov.b	v4[4], w13
    4d10:      	ubfx	w13, w12, #5, #1
    4d14:      	mov.b	v4[5], w13
    4d18:      	ubfx	w13, w12, #6, #1
    4d1c:      	mov.b	v4[6], w13
    4d20:      	lsr	w12, w12, #7
    4d24:      	mov.b	v4[7], w12
    4d28:      	bif.8b	v1, v4, v3
    4d2c:      	ldr	q3, [sp, #0x470]
    4d30:      	fmov	w12, s3
    4d34:      	add	x12, x17, w12, sxtw #2
    4d38:      	ldr	q3, [sp, #0x450]
    4d3c:      	fmov	w13, s3
    4d40:      	shl.8b	v1, v1, #0x7
    4d44:      	cmlt.8b	v1, v1, #0
    4d48:      	and.8b	v1, v1, v2
    4d4c:      	addv.8b	b1, v1
    4d50:      	str	b1, [x21, x9]
    4d54:      	lsl	x9, x9, #2
    4d58:      	add	x14, x22, x9
    4d5c:      	csel	x12, x12, x14, ne
    4d60:      	ldr	w12, [x12]
    4d64:      	str	w12, [x14]
    4d68:      	ldr	w12, [x23, x9]
    4d6c:      	csel	w12, w13, w12, ne
    4d70:      	str	w12, [x23, x9]
    4d74:      	cinc	w9, w11, ne
    4d78:      	and	w11, w10, #0x20
    4d7c:      	ldrb	w12, [x8, #0xd]
    4d80:      	and	w13, w12, #0x1
    4d84:      	fmov	s1, w13
    4d88:      	ubfx	w13, w12, #1, #1
    4d8c:      	mov.b	v1[1], w13
    4d90:      	ubfx	w13, w12, #2, #1
    4d94:      	mov.b	v1[2], w13
    4d98:      	ubfx	w13, w12, #3, #1
    4d9c:      	mov.b	v1[3], w13
    4da0:      	ubfx	w13, w12, #4, #1
    4da4:      	mov.b	v1[4], w13
    4da8:      	ubfx	w13, w12, #5, #1
    4dac:      	mov.b	v1[5], w13
    4db0:      	ubfx	w13, w12, #6, #1
    4db4:      	mov.b	v1[6], w13
    4db8:      	lsr	w12, w12, #7
    4dbc:      	mov.b	v1[7], w12
    4dc0:      	ldrb	w12, [x8, #0x5]
    4dc4:      	and	w13, w12, #0x1
    4dc8:      	fmov	s6, w13
    4dcc:      	ubfx	w13, w12, #1, #1
    4dd0:      	mov.b	v6[1], w13
    4dd4:      	ubfx	w13, w12, #2, #1
    4dd8:      	mov.b	v6[2], w13
    4ddc:      	ubfx	w13, w12, #3, #1
    4de0:      	mov.b	v6[3], w13
    4de4:      	ubfx	w13, w12, #4, #1
    4de8:      	mov.b	v6[4], w13
    4dec:      	ubfx	w13, w12, #5, #1
    4df0:      	mov.b	v6[5], w13
    4df4:      	ubfx	w13, w12, #6, #1
    4df8:      	mov.b	v6[6], w13
    4dfc:      	lsr	w12, w12, #7
    4e00:      	mov.b	v6[7], w12
    4e04:      	and.8b	v7, v12, v1
    4e08:      	eor.8b	v1, v6, v7
    4e0c:      	shl.8b	v1, v1, #0x7
    4e10:      	cmlt.8b	v3, v1, #0
    4e14:      	umaxv.8b	b1, v3
    4e18:      	fmov	w12, s1
    4e1c:      	eor	w12, w12, #0x1
    4e20:      	ands	w11, w12, w11, lsr #5
    4e24:      	dup.8b	v1, w11
    4e28:      	and.8b	v1, v1, v6
    4e2c:      	shl.8b	v4, v1, #0x7
    4e30:      	cmlt.8b	v4, v4, #0
    4e34:      	and.8b	v4, v4, v2
    4e38:      	addv.8b	b4, v4
    4e3c:      	fmov	w11, s4
    4e40:      	csetm	w12, ne
    4e44:      	dup.8b	v16, w12
    4e48:      	bic.8b	v7, v7, v16
    4e4c:      	shl.8b	v7, v7, #0x7
    4e50:      	cmlt.8b	v7, v7, #0
    4e54:      	and.8b	v7, v7, v2
    4e58:      	addv.8b	b7, v7
    4e5c:      	stur	b7, [x8, #0xd]
    4e60:      	bic.8b	v6, v6, v16
    4e64:      	shl.8b	v6, v6, #0x7
    4e68:      	cmlt.8b	v6, v6, #0
    4e6c:      	and.8b	v6, v6, v2
    4e70:      	addv.8b	b6, v6
    4e74:      	stur	b6, [x8, #0x5]
    4e78:      	cmp	w9, #0x8
    4e7c:      	and	w12, w11, #0xff
    4e80:      	ccmp	w12, #0x0, #0x4, hs
    4e84:      	b.ne	0x541c <ltmp0+0x541c>
    4e88:      	and.8b	v3, v3, v2
    4e8c:      	addv.8b	b3, v3
    4e90:      	fmov	w12, s3
    4e94:      	ldr	d3, [sp, #0x20]
    4e98:      	cmeq.8b	v3, v4, v3
    4e9c:      	mvn.8b	v3, v3
    4ea0:      	umov.b	w13, v3[0]
    4ea4:      	sbfx	w14, w13, #0, #1
    4ea8:      	fmov	s3, w14
    4eac:      	sbfx	w14, w13, #1, #1
    4eb0:      	mov.b	v3[1], w14
    4eb4:      	sbfx	w14, w13, #2, #1
    4eb8:      	mov.b	v3[2], w14
    4ebc:      	sbfx	w14, w13, #3, #1
    4ec0:      	mov.b	v3[3], w14
    4ec4:      	sbfx	w14, w13, #4, #1
    4ec8:      	mov.b	v3[4], w14
    4ecc:      	sbfx	w14, w13, #5, #1
    4ed0:      	mov.b	v3[5], w14
    4ed4:      	sbfx	w14, w13, #6, #1
    4ed8:      	mov.b	v3[6], w14
    4edc:      	sbfx	w13, w13, #7, #1
    4ee0:      	mov.b	v3[7], w13
    4ee4:      	and	w13, w10, #0xffffffdf
    4ee8:      	tst	w12, #0xff
    4eec:      	csel	w10, w13, w10, eq
    4ef0:      	sxtw	x12, w9
    4ef4:      	tst	w11, #0xff
    4ef8:      	csel	x11, x12, xzr, ne
    4efc:      	ldrb	w12, [x21, x11]
    4f00:      	and	w13, w12, #0x1
    4f04:      	fmov	s4, w13
    4f08:      	ubfx	w13, w12, #1, #1
    4f0c:      	mov.b	v4[1], w13
    4f10:      	ubfx	w13, w12, #2, #1
    4f14:      	mov.b	v4[2], w13
    4f18:      	ubfx	w13, w12, #3, #1
    4f1c:      	mov.b	v4[3], w13
    4f20:      	ubfx	w13, w12, #4, #1
    4f24:      	mov.b	v4[4], w13
    4f28:      	ubfx	w13, w12, #5, #1
    4f2c:      	mov.b	v4[5], w13
    4f30:      	ubfx	w13, w12, #6, #1
    4f34:      	mov.b	v4[6], w13
    4f38:      	lsr	w12, w12, #7
    4f3c:      	mov.b	v4[7], w12
    4f40:      	ldr	q5, [sp, #0x470]
    4f44:      	mov.s	w12, v5[1]
    4f48:      	bif.8b	v1, v4, v3
    4f4c:      	add	x12, x17, w12, sxtw #2
    4f50:      	ldr	q3, [sp, #0x450]
    4f54:      	mov.s	w13, v3[1]
    4f58:      	shl.8b	v1, v1, #0x7
    4f5c:      	cmlt.8b	v1, v1, #0
    4f60:      	and.8b	v1, v1, v2
    4f64:      	addv.8b	b1, v1
    4f68:      	str	b1, [x21, x11]
    4f6c:      	lsl	x11, x11, #2
    4f70:      	add	x14, x22, x11
    4f74:      	csel	x12, x12, x14, ne
    4f78:      	ldr	w12, [x12]
    4f7c:      	str	w12, [x14]
    4f80:      	ldr	w12, [x23, x11]
    4f84:      	csel	w12, w13, w12, ne
    4f88:      	str	w12, [x23, x11]
    4f8c:      	cinc	w9, w9, ne
    4f90:      	ldrb	w11, [x8, #0xe]
    4f94:      	and	w12, w11, #0x1
    4f98:      	fmov	s1, w12
    4f9c:      	ubfx	w12, w11, #1, #1
    4fa0:      	mov.b	v1[1], w12
    4fa4:      	ubfx	w12, w11, #2, #1
    4fa8:      	mov.b	v1[2], w12
    4fac:      	ubfx	w12, w11, #3, #1
    4fb0:      	mov.b	v1[3], w12
    4fb4:      	ubfx	w12, w11, #4, #1
    4fb8:      	mov.b	v1[4], w12
    4fbc:      	ubfx	w12, w11, #5, #1
    4fc0:      	mov.b	v1[5], w12
    4fc4:      	ubfx	w12, w11, #6, #1
    4fc8:      	mov.b	v1[6], w12
    4fcc:      	lsr	w11, w11, #7
    4fd0:      	mov.b	v1[7], w11
    4fd4:      	ldrb	w11, [x8, #0x6]
    4fd8:      	and	w12, w11, #0x1
    4fdc:      	fmov	s6, w12
    4fe0:      	ubfx	w12, w11, #1, #1
    4fe4:      	mov.b	v6[1], w12
    4fe8:      	ubfx	w12, w11, #2, #1
    4fec:      	mov.b	v6[2], w12
    4ff0:      	ubfx	w12, w11, #3, #1
    4ff4:      	mov.b	v6[3], w12
    4ff8:      	ubfx	w12, w11, #4, #1
    4ffc:      	mov.b	v6[4], w12
    5000:      	ubfx	w12, w11, #5, #1
    5004:      	mov.b	v6[5], w12
    5008:      	ubfx	w12, w11, #6, #1
    500c:      	mov.b	v6[6], w12
    5010:      	and	w12, w10, #0x40
    5014:      	lsr	w11, w11, #7
    5018:      	mov.b	v6[7], w11
    501c:      	and.8b	v7, v12, v1
    5020:      	eor.8b	v1, v6, v7
    5024:      	shl.8b	v1, v1, #0x7
    5028:      	cmlt.8b	v3, v1, #0
    502c:      	umaxv.8b	b1, v3
    5030:      	fmov	w11, s1
    5034:      	eor	w11, w11, #0x1
    5038:      	ands	w11, w11, w12, lsr #6
    503c:      	dup.8b	v1, w11
    5040:      	and.8b	v1, v1, v6
    5044:      	shl.8b	v4, v1, #0x7
    5048:      	cmlt.8b	v4, v4, #0
    504c:      	and.8b	v4, v4, v2
    5050:      	addv.8b	b4, v4
    5054:      	fmov	w11, s4
    5058:      	csetm	w12, ne
    505c:      	dup.8b	v16, w12
    5060:      	bic.8b	v7, v7, v16
    5064:      	shl.8b	v7, v7, #0x7
    5068:      	cmlt.8b	v7, v7, #0
    506c:      	and.8b	v7, v7, v2
    5070:      	addv.8b	b7, v7
    5074:      	stur	b7, [x8, #0xe]
    5078:      	bic.8b	v6, v6, v16
    507c:      	shl.8b	v6, v6, #0x7
    5080:      	cmlt.8b	v6, v6, #0
    5084:      	and.8b	v6, v6, v2
    5088:      	addv.8b	b6, v6
    508c:      	stur	b6, [x8, #0x6]
    5090:      	cmp	w9, #0x8
    5094:      	b.lo	0x50a0 <ltmp0+0x50a0>
    5098:      	tst	w11, #0xff
    509c:      	b.ne	0x541c <ltmp0+0x541c>
    50a0:      	and.8b	v3, v3, v2
    50a4:      	ldr	d6, [sp, #0x18]
    50a8:      	cmeq.8b	v4, v4, v6
    50ac:      	mvn.8b	v4, v4
    50b0:      	umov.b	w12, v4[0]
    50b4:      	addv.8b	b4, v3
    50b8:      	sbfx	w13, w12, #0, #1
    50bc:      	fmov	s3, w13
    50c0:      	sbfx	w13, w12, #1, #1
    50c4:      	mov.b	v3[1], w13
    50c8:      	sbfx	w13, w12, #2, #1
    50cc:      	mov.b	v3[2], w13
    50d0:      	sbfx	w13, w12, #3, #1
    50d4:      	mov.b	v3[3], w13
    50d8:      	sbfx	w13, w12, #4, #1
    50dc:      	mov.b	v3[4], w13
    50e0:      	sbfx	w13, w12, #5, #1
    50e4:      	mov.b	v3[5], w13
    50e8:      	sbfx	w13, w12, #6, #1
    50ec:      	mov.b	v3[6], w13
    50f0:      	sbfx	w12, w12, #7, #1
    50f4:      	mov.b	v3[7], w12
    50f8:      	fmov	w12, s4
    50fc:      	and	w13, w10, #0xffffffbf
    5100:      	tst	w12, #0xff
    5104:      	csel	w10, w13, w10, eq
    5108:      	sxtw	x12, w9
    510c:      	tst	w11, #0xff
    5110:      	csel	x11, x12, xzr, ne
    5114:      	ldrb	w12, [x21, x11]
    5118:      	and	w13, w12, #0x1
    511c:      	fmov	s4, w13
    5120:      	ubfx	w13, w12, #1, #1
    5124:      	mov.b	v4[1], w13
    5128:      	ubfx	w13, w12, #2, #1
    512c:      	mov.b	v4[2], w13
    5130:      	ubfx	w13, w12, #3, #1
    5134:      	mov.b	v4[3], w13
    5138:      	ubfx	w13, w12, #4, #1
    513c:      	mov.b	v4[4], w13
    5140:      	ubfx	w13, w12, #5, #1
    5144:      	mov.b	v4[5], w13
    5148:      	ubfx	w13, w12, #6, #1
    514c:      	mov.b	v4[6], w13
    5150:      	lsr	w12, w12, #7
    5154:      	mov.b	v4[7], w12
    5158:      	bif.8b	v1, v4, v3
    515c:      	ldr	q3, [sp, #0x470]
    5160:      	mov.s	w12, v3[2]
    5164:      	add	x12, x17, w12, sxtw #2
    5168:      	ldr	q3, [sp, #0x450]
    516c:      	mov.s	w13, v3[2]
    5170:      	sxtb	w10, w10
    5174:      	shl.8b	v1, v1, #0x7
    5178:      	cmlt.8b	v1, v1, #0
    517c:      	and.8b	v1, v1, v2
    5180:      	addv.8b	b1, v1
    5184:      	str	b1, [x21, x11]
    5188:      	lsl	x11, x11, #2
    518c:      	ldr	w14, [x23, x11]
    5190:      	csel	w13, w13, w14, ne
    5194:      	add	x14, x22, x11
    5198:      	csel	x12, x12, x14, ne
    519c:      	ldr	w12, [x12]
    51a0:      	str	w13, [x23, x11]
    51a4:      	str	w12, [x14]
    51a8:      	cinc	w9, w9, ne
    51ac:      	cmp	w10, #0x0
    51b0:      	ldrb	w11, [x8, #0xf]
    51b4:      	and	w12, w11, #0x1
    51b8:      	fmov	s1, w12
    51bc:      	ubfx	w12, w11, #1, #1
    51c0:      	mov.b	v1[1], w12
    51c4:      	ubfx	w12, w11, #2, #1
    51c8:      	mov.b	v1[2], w12
    51cc:      	ubfx	w12, w11, #3, #1
    51d0:      	mov.b	v1[3], w12
    51d4:      	ubfx	w12, w11, #4, #1
    51d8:      	mov.b	v1[4], w12
    51dc:      	ubfx	w12, w11, #5, #1
    51e0:      	mov.b	v1[5], w12
    51e4:      	ubfx	w12, w11, #6, #1
    51e8:      	mov.b	v1[6], w12
    51ec:      	lsr	w11, w11, #7
    51f0:      	mov.b	v1[7], w11
    51f4:      	ldrb	w11, [x8, #0x7]
    51f8:      	and	w12, w11, #0x1
    51fc:      	fmov	s6, w12
    5200:      	ubfx	w12, w11, #1, #1
    5204:      	mov.b	v6[1], w12
    5208:      	ubfx	w12, w11, #2, #1
    520c:      	mov.b	v6[2], w12
    5210:      	ubfx	w12, w11, #3, #1
    5214:      	mov.b	v6[3], w12
    5218:      	ubfx	w12, w11, #4, #1
    521c:      	mov.b	v6[4], w12
    5220:      	ubfx	w12, w11, #5, #1
    5224:      	mov.b	v6[5], w12
    5228:      	ubfx	w12, w11, #6, #1
    522c:      	mov.b	v6[6], w12
    5230:      	cset	w12, lt
    5234:      	lsr	w11, w11, #7
    5238:      	mov.b	v6[7], w11
    523c:      	and.8b	v7, v12, v1
    5240:      	eor.8b	v1, v6, v7
    5244:      	shl.8b	v1, v1, #0x7
    5248:      	cmlt.8b	v3, v1, #0
    524c:      	umaxv.8b	b1, v3
    5250:      	fmov	w11, s1
    5254:      	eor	w11, w11, #0x1
    5258:      	ands	w11, w12, w11
    525c:      	dup.8b	v1, w11
    5260:      	and.8b	v1, v1, v6
    5264:      	shl.8b	v4, v1, #0x7
    5268:      	cmlt.8b	v4, v4, #0
    526c:      	and.8b	v4, v4, v2
    5270:      	addv.8b	b4, v4
    5274:      	fmov	w11, s4
    5278:      	csetm	w12, ne
    527c:      	dup.8b	v16, w12
    5280:      	bic.8b	v7, v7, v16
    5284:      	shl.8b	v7, v7, #0x7
    5288:      	cmlt.8b	v7, v7, #0
    528c:      	and.8b	v7, v7, v2
    5290:      	addv.8b	b7, v7
    5294:      	stur	b7, [x8, #0xf]
    5298:      	bic.8b	v6, v6, v16
    529c:      	shl.8b	v6, v6, #0x7
    52a0:      	cmlt.8b	v6, v6, #0
    52a4:      	and.8b	v6, v6, v2
    52a8:      	addv.8b	b6, v6
    52ac:      	stur	b6, [x8, #0x7]
    52b0:      	cmp	w9, #0x8
    52b4:      	b.lo	0x52c0 <ltmp0+0x52c0>
    52b8:      	tst	w11, #0xff
    52bc:      	b.ne	0x541c <ltmp0+0x541c>
    52c0:      	and.8b	v3, v3, v2
    52c4:      	addv.8b	b6, v3
    52c8:      	ldr	d3, [sp, #0x10]
    52cc:      	cmeq.8b	v3, v4, v3
    52d0:      	mvn.8b	v3, v3
    52d4:      	umov.b	w12, v3[0]
    52d8:      	sbfx	w13, w12, #0, #1
    52dc:      	fmov	s3, w13
    52e0:      	sbfx	w13, w12, #1, #1
    52e4:      	mov.b	v3[1], w13
    52e8:      	sbfx	w13, w12, #2, #1
    52ec:      	mov.b	v3[2], w13
    52f0:      	sbfx	w13, w12, #3, #1
    52f4:      	mov.b	v3[3], w13
    52f8:      	sbfx	w13, w12, #4, #1
    52fc:      	mov.b	v3[4], w13
    5300:      	sbfx	w13, w12, #5, #1
    5304:      	mov.b	v3[5], w13
    5308:      	sbfx	w13, w12, #6, #1
    530c:      	mov.b	v3[6], w13
    5310:      	fmov	w13, s6
    5314:      	sbfx	w12, w12, #7, #1
    5318:      	mov.b	v3[7], w12
    531c:      	and	w12, w10, #0x7f
    5320:      	tst	w13, #0xff
    5324:      	csel	w10, w12, w10, eq
    5328:      	sxtw	x12, w9
    532c:      	tst	w11, #0xff
    5330:      	csel	x11, x12, xzr, ne
    5334:      	ldrb	w12, [x21, x11]
    5338:      	and	w13, w12, #0x1
    533c:      	fmov	s4, w13
    5340:      	ubfx	w13, w12, #1, #1
    5344:      	mov.b	v4[1], w13
    5348:      	ubfx	w13, w12, #2, #1
    534c:      	mov.b	v4[2], w13
    5350:      	ubfx	w13, w12, #3, #1
    5354:      	mov.b	v4[3], w13
    5358:      	ubfx	w13, w12, #4, #1
    535c:      	mov.b	v4[4], w13
    5360:      	ubfx	w13, w12, #5, #1
    5364:      	mov.b	v4[5], w13
    5368:      	ubfx	w13, w12, #6, #1
    536c:      	mov.b	v4[6], w13
    5370:      	lsr	w12, w12, #7
    5374:      	mov.b	v4[7], w12
    5378:      	bif.8b	v1, v4, v3
    537c:      	ldr	q3, [sp, #0x470]
    5380:      	mov.s	w12, v3[3]
    5384:      	ldr	q3, [sp, #0x450]
    5388:      	mov.s	w13, v3[3]
    538c:      	shl.8b	v1, v1, #0x7
    5390:      	cmlt.8b	v1, v1, #0
    5394:      	and.8b	v1, v1, v2
    5398:      	addv.8b	b1, v1
    539c:      	str	b1, [x21, x11]
    53a0:      	add	x12, x17, w12, sxtw #2
    53a4:      	lsl	x11, x11, #2
    53a8:      	add	x14, x22, x11
    53ac:      	csel	x12, x12, x14, ne
    53b0:      	ldr	w12, [x12]
    53b4:      	str	w12, [x14]
    53b8:      	ldr	w12, [x23, x11]
    53bc:      	csel	w12, w13, w12, ne
    53c0:      	str	w12, [x23, x11]
    53c4:      	cinc	w26, w9, ne
    53c8:      	b	0x2a8 <ltmp0+0x2a8>
    53cc:      	mov	w10, #0x0               ; =0
    53d0:      	b	0x2a8 <ltmp0+0x2a8>
    53d4:      	shl.8b	v0, v12, #0x7
    53d8:      	cmlt.8b	v0, v0, #0
    53dc:      	umaxv.8b	b0, v0
    53e0:      	fmov	w8, s0
    53e4:      	tbnz	w8, #0x0, 0x541c <ltmp0+0x541c>
    53e8:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    53ec:      	add	sp, sp, #0x540
    53f0:      	ldp	x29, x30, [sp, #0x90]
    53f4:      	ldp	x20, x19, [sp, #0x80]
    53f8:      	ldp	x22, x21, [sp, #0x70]
    53fc:      	ldp	x24, x23, [sp, #0x60]
    5400:      	ldp	x26, x25, [sp, #0x50]
    5404:      	ldp	x28, x27, [sp, #0x40]
    5408:      	ldp	d9, d8, [sp, #0x30]
    540c:      	ldp	d11, d10, [sp, #0x20]
    5410:      	ldp	d13, d12, [sp, #0x10]
    5414:      	ldp	d15, d14, [sp], #0xa0
    5418:      	ret
    541c:      	brk	#0x1

0000000000005420 <_llm_rows.packet_batch>:
    5420:      	stp	x26, x25, [sp, #-0x50]!
    5424:      	stp	x24, x23, [sp, #0x10]
    5428:      	stp	x22, x21, [sp, #0x20]
    542c:      	stp	x20, x19, [sp, #0x30]
    5430:      	stp	x29, x30, [sp, #0x40]
    5434:      	mov	x21, x3
    5438:      	mov	x19, x2
    543c:      	mov	x20, x0
    5440:      	ldr	w23, [x2, #0x24]
    5444:      	ldr	w8, [x2]
    5448:      	ldr	w9, [x2, #0xc]
    544c:      	lsl	x8, x8, #5
    5450:      	cmp	x8, x9
    5454:      	csel	x10, x8, xzr, ls
    5458:      	add	x10, x10, x23
    545c:      	subs	x11, x9, x10
    5460:      	mov	w12, #0x20              ; =32
    5464:      	sub	x13, x12, x23
    5468:      	cmp	x11, x13
    546c:      	csel	x11, x11, x13, lo
    5470:      	cmp	x9, x10
    5474:      	ccmp	x23, x12, #0x2, hi
    5478:      	ccmp	x8, x9, #0x2, lo
    547c:      	csel	x8, x11, xzr, ls
    5480:      	cmp	w3, #0x4
    5484:      	b.ne	0x54fc <_llm_rows.packet_batch+0xdc>
    5488:      	cmp	x8, #0x20
    548c:      	b.lo	0x54fc <_llm_rows.packet_batch+0xdc>
    5490:      	mov	x0, x20
    5494:      	mov	x1, x19
    5498:      	mov	w2, #0x8                ; =8
    549c:      	bl	0x549c <_llm_rows.packet_batch+0x7c>
    54a0:      	add	w8, w23, #0x8
    54a4:      	str	w8, [x19, #0x24]
    54a8:      	mov	x0, x20
    54ac:      	mov	x1, x19
    54b0:      	mov	w2, #0x8                ; =8
    54b4:      	bl	0x54b4 <_llm_rows.packet_batch+0x94>
    54b8:      	add	w8, w23, #0x10
    54bc:      	str	w8, [x19, #0x24]
    54c0:      	mov	x0, x20
    54c4:      	mov	x1, x19
    54c8:      	mov	w2, #0x8                ; =8
    54cc:      	bl	0x54cc <_llm_rows.packet_batch+0xac>
    54d0:      	add	w8, w23, #0x18
    54d4:      	str	w8, [x19, #0x24]
    54d8:      	mov	x0, x20
    54dc:      	mov	x1, x19
    54e0:      	mov	w2, #0x8                ; =8
    54e4:      	ldp	x29, x30, [sp, #0x40]
    54e8:      	ldp	x20, x19, [sp, #0x30]
    54ec:      	ldp	x22, x21, [sp, #0x20]
    54f0:      	ldp	x24, x23, [sp, #0x10]
    54f4:      	ldp	x26, x25, [sp], #0x50
    54f8:      	b	0x54f8 <_llm_rows.packet_batch+0xd8>
    54fc:      	ubfiz	x9, x21, #3, #32
    5500:      	cmp	x8, x9
    5504:      	csel	x8, x8, x9, lo
    5508:      	lsr	x24, x8, #3
    550c:      	and	w22, w8, #0x7
    5510:      	cmp	x8, #0x8
    5514:      	b.lo	0x5540 <_llm_rows.packet_batch+0x120>
    5518:      	mov	x25, x24
    551c:      	mov	x26, x23
    5520:      	str	w26, [x19, #0x24]
    5524:      	mov	x0, x20
    5528:      	mov	x1, x19
    552c:      	mov	w2, #0x8                ; =8
    5530:      	bl	0x5530 <_llm_rows.packet_batch+0x110>
    5534:      	add	w26, w26, #0x8
    5538:      	subs	w25, w25, #0x1
    553c:      	b.ne	0x5520 <_llm_rows.packet_batch+0x100>
    5540:      	cbz	w22, 0x555c <_llm_rows.packet_batch+0x13c>
    5544:      	add	w8, w23, w24, lsl #3
    5548:      	str	w8, [x19, #0x24]
    554c:      	mov	x0, x20
    5550:      	mov	x1, x19
    5554:      	mov	x2, x22
    5558:      	bl	0x5558 <_llm_rows.packet_batch+0x138>
    555c:      	lsl	w8, w21, #3
    5560:      	sub	w8, w8, #0x8
    5564:      	cmp	w21, #0x0
    5568:      	csel	w8, wzr, w8, eq
    556c:      	add	w8, w23, w8
    5570:      	str	w8, [x19, #0x24]
    5574:      	ldp	x29, x30, [sp, #0x40]
    5578:      	ldp	x20, x19, [sp, #0x30]
    557c:      	ldp	x22, x21, [sp, #0x20]
    5580:      	ldp	x24, x23, [sp, #0x10]
    5584:      	ldp	x26, x25, [sp], #0x50
    5588:      	ret

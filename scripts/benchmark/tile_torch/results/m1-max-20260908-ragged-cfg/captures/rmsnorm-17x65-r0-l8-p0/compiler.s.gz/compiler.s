	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_4:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_8:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_9:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_10:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_11:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_3:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #1344
	fmov	s1, wzr
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1256
	str	wzr, [sp, #5436]
	stur	wzr, [x8, #81]
	stur	xzr, [x8, #52]
	stur	xzr, [x8, #68]
	stur	xzr, [x8, #60]
	stur	xzr, [x8, #20]
	stur	xzr, [x8, #36]
	stur	xzr, [x8, #28]
	str	xzr, [sp, #5360]
	str	xzr, [sp, #5352]
	ldr	x6, [x0]
	ldr	x7, [x0, #16]
	ldr	x3, [x0, #48]
	ldr	w9, [x1]
	ldr	w11, [x1, #36]
	dup.4s	v0, w2
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x10, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q3, [x10, lCPI0_1@PAGEOFF]
	cmhi.4s	v3, v0, v3
	cmhi.4s	v0, v0, v2
	uzp1.8h	v2, v0, v3
	xtn.8b	v12, v2
Lloh4:
	adrp	x10, lCPI0_2@PAGE
Lloh5:
	ldr	q3, [x10, lCPI0_2@PAGEOFF]
	and.16b	v3, v2, v3
	addv.8h	h3, v3
	fmov	w10, s3
	and	w10, w10, #0xff
	fmov	s3, w10
	cmeq.8b	v1, v3, v1
	umov.b	w10, v1[0]
	and	w12, w10, #0x1
	fmov	s1, w12
	ubfx	w12, w10, #1, #1
	mov.b	v1[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v1[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v1[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v1[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v1[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v1[6], w12
	ubfx	w10, w10, #7, #1
	mov.b	v1[7], w10
	movi.8b	v20, #1
	eor.8b	v1, v1, v20
	and.8b	v1, v1, v12
	umaxv.8h	h2, v2
	fmov	w10, s2
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
Lloh6:
	adrp	x12, lCPI0_3@PAGE
Lloh7:
	ldr	d2, [x12, lCPI0_3@PAGEOFF]
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x8, #80]
	str	wzr, [sp, #5428]
	str	wzr, [sp, #5400]
	str	wzr, [sp, #5396]
	str	wzr, [sp, #5368]
	tbz	w10, #0, LBB0_375
; %bb.1:                                ; %scheduler.dispatch.preheader
	mov	w10, #0                         ; =0x0
	stp	xzr, xzr, [sp, #64]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #48]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #32]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #16]             ; 16-byte Folded Spill
	add	x15, sp, #1, lsl #12            ; =4096
	add	x15, x15, #968
	dup.2d	v0, x15
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #680
	dup.2d	v1, x12
	stp	q0, q1, [sp, #96]               ; 32-byte Folded Spill
	add	w9, w11, w9, lsl #5
	dup.4s	v1, w9
	str	q1, [sp, #80]                   ; 16-byte Folded Spill
	movi.2d	v23, #0000000000000000
	add	x9, x7, #256
	str	x9, [sp, #128]                  ; 8-byte Folded Spill
	mov	w20, #1                         ; =0x1
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #1336
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #1304
	add	x23, sp, #1, lsl #12            ; =4096
	add	x23, x23, #1272
	adrp	x24, lCPI0_8@PAGE
	adrp	x25, lCPI0_9@PAGE
	adrp	x30, lCPI0_10@PAGE
	add	x27, sp, #1, lsl #12            ; =4096
	add	x27, x27, #1264
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #1008]                 ; 16-byte Folded Spill
	str	q0, [sp, #1056]                 ; 16-byte Folded Spill
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	stp	q0, q0, [sp, #800]              ; 32-byte Folded Spill
	movi.2d	v25, #0000000000000000
	str	q0, [sp, #1040]                 ; 16-byte Folded Spill
	movi.2d	v14, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v1, #0000000000000000
	stp	q1, q1, [sp, #464]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #432]              ; 32-byte Folded Spill
	str	q1, [sp, #496]                  ; 16-byte Folded Spill
	stp	q0, q0, [sp, #912]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #960]              ; 32-byte Folded Spill
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #384
	mov	w5, #-1                         ; =0xffffffff
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #352
	add	x4, sp, #3568
	mov	w19, #1                         ; =0x1
	str	q0, [sp, #944]                  ; 16-byte Folded Spill
	stp	q1, q1, [sp, #240]              ; 32-byte Folded Spill
	str	q1, [sp, #336]                  ; 16-byte Folded Spill
	movi.2d	v24, #0000000000000000
	stp	q1, q1, [sp, #528]              ; 32-byte Folded Spill
	str	q0, [sp, #784]                  ; 16-byte Folded Spill
	movi.2d	v18, #0000000000000000
	stp	q1, q1, [sp, #608]              ; 32-byte Folded Spill
	movi.2d	v28, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	str	q1, [sp, #992]                  ; 16-byte Folded Spill
	movi.2d	v15, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v29, #0000000000000000
	stp	q1, q1, [sp, #400]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #368]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #864]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #832]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #576]              ; 32-byte Folded Spill
	str	q1, [sp, #560]                  ; 16-byte Folded Spill
	movi.2d	v27, #0000000000000000
	movi.2d	v13, #0000000000000000
	str	q0, [sp, #1024]                 ; 16-byte Folded Spill
	movi.2d	v26, #0000000000000000
	str	q1, [sp, #1088]                 ; 16-byte Folded Spill
	str	q1, [sp, #1104]                 ; 16-byte Folded Spill
	str	q1, [sp, #1120]                 ; 16-byte Folded Spill
	str	q1, [sp, #1136]                 ; 16-byte Folded Spill
	b	LBB0_4
LBB0_2:                                 ;   in Loop: Header=BB0_4 Depth=1
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #384
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #352
LBB0_3:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x19, x26
	cbz	w26, LBB0_375
LBB0_4:                                 ; %scheduler.dispatch
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_65 Depth 2
                                        ;     Child Loop BB0_156 Depth 2
                                        ;     Child Loop BB0_172 Depth 2
                                        ;     Child Loop BB0_225 Depth 2
                                        ;     Child Loop BB0_257 Depth 2
                                        ;     Child Loop BB0_324 Depth 2
                                        ;     Child Loop BB0_356 Depth 2
	sub	w26, w19, #1
	ldr	w13, [x22, w26, sxtw #2]
	cmp	w13, #20
	b.hi	LBB0_377
; %bb.5:                                ; %scheduler.dispatch
                                        ;   in Loop: Header=BB0_4 Depth=1
	sxtw	x28, w26
	ldrb	w11, [x21, x28]
	and	w12, w11, #0x1
	fmov	s21, w12
	ubfx	w12, w11, #1, #1
	mov.b	v21[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v21[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v21[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v21[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v21[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v21[6], w12
	lsr	w11, w11, #7
	mov.b	v21[7], w11
	ldr	w12, [x23, w26, sxtw #2]
Lloh8:
	adrp	x9, LJTI0_0@PAGE
Lloh9:
	add	x9, x9, LJTI0_0@PAGEOFF
	adr	x11, LBB0_6
	ldrh	w14, [x9, x13, lsl #1]
	add	x11, x11, x14, lsl #2
	br	x11
LBB0_6:                                 ; %schedule.0
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b1, v1
	fmov	w11, s1
	mov	b1, v21[6]
	mov.b	v1[4], v21[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
Lloh10:
	adrp	x9, lCPI0_4@PAGE
Lloh11:
	ldr	q3, [x9, lCPI0_4@PAGEOFF]
	bit.16b	v26, v3, v1
	mov	b3, v21[4]
	mov.b	v3[4], v21[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
Lloh12:
	adrp	x9, lCPI0_5@PAGE
Lloh13:
	ldr	q4, [x9, lCPI0_5@PAGEOFF]
	mov	b6, v21[2]
	mov.b	v6[4], v21[3]
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	bit.16b	v0, v4, v3
	str	q0, [sp, #1024]                 ; 16-byte Folded Spill
	ushll.2d	v4, v6, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
Lloh14:
	adrp	x9, lCPI0_6@PAGE
Lloh15:
	ldr	q6, [x9, lCPI0_6@PAGEOFF]
	bit.16b	v13, v6, v4
	mov	b6, v21[0]
	mov.b	v6[4], v21[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
Lloh16:
	adrp	x9, lCPI0_7@PAGE
Lloh17:
	ldr	q7, [x9, lCPI0_7@PAGEOFF]
	bit.16b	v27, v7, v6
	zip1.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	ldr	q19, [sp, #80]                  ; 16-byte Folded Reload
	and.16b	v16, v7, v19
	zip2.8b	v17, v21, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v19, v17, v19
	movi.4s	v20, #3
	and.16b	v7, v7, v20
	and.16b	v17, v17, v20
	neg.4s	v17, v17
	ushl.4s	v17, v19, v17
	neg.4s	v7, v7
	ushl.4s	v7, v16, v7
	ushll.2d	v16, v7, #0
	ushll2.2d	v7, v7, #0
	ushll.2d	v19, v17, #0
	ushll2.2d	v17, v17, #0
	ldr	q20, [sp, #560]                 ; 16-byte Folded Reload
	bit.16b	v20, v17, v1
	ldr	q17, [sp, #576]                 ; 16-byte Folded Reload
	bit.16b	v17, v19, v3
	stp	q20, q17, [sp, #560]            ; 32-byte Folded Spill
	ldr	q17, [sp, #592]                 ; 16-byte Folded Reload
	bit.16b	v17, v7, v4
	ldr	q7, [sp, #608]                  ; 16-byte Folded Reload
	bit.16b	v7, v16, v6
	stp	q17, q7, [sp, #592]             ; 32-byte Folded Spill
	ldr	q7, [sp, #96]                   ; 16-byte Folded Reload
	ldr	q16, [sp, #368]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v1
	str	q16, [sp, #368]                 ; 16-byte Folded Spill
	ldr	q16, [sp, #384]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v3
	str	q16, [sp, #384]                 ; 16-byte Folded Spill
	ldr	q16, [sp, #400]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v4
	str	q16, [sp, #400]                 ; 16-byte Folded Spill
	ldr	q16, [sp, #416]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v6
	str	q16, [sp, #416]                 ; 16-byte Folded Spill
	ldr	q7, [x24, lCPI0_8@PAGEOFF]
	ldr	q16, [sp, #832]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v1
	str	q16, [sp, #832]                 ; 16-byte Folded Spill
	ldr	q7, [x25, lCPI0_9@PAGEOFF]
	ldr	q16, [sp, #848]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v3
	str	q16, [sp, #848]                 ; 16-byte Folded Spill
	ldr	q7, [x30, lCPI0_10@PAGEOFF]
	ldr	q16, [sp, #864]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v4
	str	q16, [sp, #864]                 ; 16-byte Folded Spill
Lloh18:
	adrp	x9, lCPI0_11@PAGE
Lloh19:
	ldr	q7, [x9, lCPI0_11@PAGEOFF]
	ldr	q16, [sp, #880]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v6
	str	q16, [sp, #880]                 ; 16-byte Folded Spill
	bic.16b	v29, v29, v1
	bic.16b	v11, v11, v3
	bic.16b	v10, v10, v4
	bic.16b	v31, v31, v6
	movi.8b	v20, #1
	tbnz	w11, #0, LBB0_16
	b	LBB0_3
LBB0_7:                                 ; %scheduler.dispatch.schedule.9_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_169
LBB0_8:                                 ; %scheduler.dispatch.schedule.4_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_46
LBB0_9:                                 ; %schedule.2
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	rbit	w11, w11
	clz	w11, w11
	umaxv.8b	b1, v1
	fmov	w13, s1
	eor	w1, w13, #0x1
	tst	w13, #0x1
	csel	w14, w11, wzr, ne
	b	LBB0_19
LBB0_10:                                ; %scheduler.dispatch.schedule.7_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b1, v1
	fmov	w11, s1
	eor	w11, w11, #0x1
	b	LBB0_85
LBB0_11:                                ; %scheduler.dispatch.schedule.12_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_189
LBB0_12:                                ; %scheduler.dispatch.schedule.19_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_337
LBB0_13:                                ; %scheduler.dispatch.schedule.3_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_37
LBB0_14:                                ; %scheduler.dispatch.schedule.14_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_238
LBB0_15:                                ; %scheduler.dispatch.schedule.17_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_272
LBB0_16:                                ; %schedule.1
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w13, s1
	rbit	w14, w11
	clz	w14, w14
	tst	w13, #0x1
	csel	w13, w14, wzr, ne
	str	q31, [sp, #4704]
	str	q10, [sp, #4720]
	str	q11, [sp, #4736]
	str	q29, [sp, #4752]
	and	x13, x13, #0x7
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #608
	ldr	x13, [x9, x13, lsl #3]
	cmp	x13, #8
	b.ge	LBB0_36
; %bb.17:                               ; %uniform.true
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_3
; %bb.18:                               ;   in Loop: Header=BB0_4 Depth=1
	mov	w1, #0                          ; =0x0
LBB0_19:                                ; %schedule.2.thread
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	q31, [sp, #1344]
	str	q10, [sp, #1360]
	str	q11, [sp, #1376]
	str	q29, [sp, #1392]
	mov	w13, w14
	ubfiz	x17, x13, #3, #3
	add	x9, sp, #1344
	ldr	x11, [x9, x17]
	lsl	x2, x11, #3
	dup.2d	v1, x2
	add.2d	v3, v1, v27
	add.2d	v4, v1, v13
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	add.2d	v6, v1, v0
	ldp	q7, q0, [sp, #592]              ; 32-byte Folded Reload
	str	q0, [sp, #1216]
	str	q7, [sp, #1232]
	ldp	q7, q0, [sp, #560]              ; 32-byte Folded Reload
	str	q0, [sp, #1248]
	str	q7, [sp, #1264]
	add	x9, sp, #1216
	ldr	x2, [x9, x17]
	add.2d	v1, v1, v26
	add	x2, x2, x2, lsl #6
	str	q1, [sp, #1328]
	str	q6, [sp, #1312]
	str	q4, [sp, #1296]
	str	q3, [sp, #1280]
	add	x9, sp, #1280
	ldr	x17, [x9, x17]
	sub	x2, x2, x13
	add	x17, x2, x17
	add	x17, x6, x17, lsl #2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w2, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w2, #0, LBB0_27
; %bb.20:                               ; %cond.load
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s1, [x17]
	tbnz	w2, #1, LBB0_28
LBB0_21:                                ; %else80
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w2, #2, LBB0_29
LBB0_22:                                ; %cond.load82
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x4, x17, #8
	ld1.s	{ v1 }[2], [x4]
	tbnz	w2, #3, LBB0_30
LBB0_23:                                ; %else86
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w2, #4, LBB0_31
LBB0_24:                                ; %cond.load88
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x4, x17, #16
	ld1.s	{ v3 }[0], [x4]
	tbnz	w2, #5, LBB0_32
LBB0_25:                                ; %else92
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w2, #6, LBB0_33
LBB0_26:                                ; %cond.load94
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x4, x17, #24
	ld1.s	{ v3 }[2], [x4]
	add	x4, sp, #3568
	tbnz	w2, #7, LBB0_34
	b	LBB0_35
LBB0_27:                                ; %else
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w2, #1, LBB0_21
LBB0_28:                                ; %cond.load79
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x4, x17, #4
	ld1.s	{ v1 }[1], [x4]
	tbnz	w2, #2, LBB0_22
LBB0_29:                                ; %else83
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w2, #3, LBB0_23
LBB0_30:                                ; %cond.load85
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x4, x17, #12
	ld1.s	{ v1 }[3], [x4]
	tbnz	w2, #4, LBB0_24
LBB0_31:                                ; %else89
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w2, #5, LBB0_25
LBB0_32:                                ; %cond.load91
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x4, x17, #20
	ld1.s	{ v3 }[1], [x4]
	tbnz	w2, #6, LBB0_26
LBB0_33:                                ; %else95
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x4, sp, #3568
	tbz	w2, #7, LBB0_35
LBB0_34:                                ; %cond.load97
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x17, #28
	ld1.s	{ v3 }[3], [x17]
LBB0_35:                                ; %else98
                                        ;   in Loop: Header=BB0_4 Depth=1
	lsl	x17, x11, #5
	dup.2d	v4, x17
	ldp	q6, q17, [sp, #832]             ; 32-byte Folded Reload
	add.2d	v6, v4, v6
	ldp	q16, q7, [sp, #864]             ; 32-byte Folded Reload
	add.2d	v7, v4, v7
	add.2d	v16, v4, v16
	add.2d	v4, v4, v17
	str	q16, [sp, #1168]
	str	q7, [sp, #1152]
	str	q4, [sp, #1184]
	str	q6, [sp, #1200]
	and	x14, x14, #0x7
	add	x9, sp, #1152
	ldr	x14, [x9, x14, lsl #3]
	sub	x14, x14, x13, lsl #2
	ands	w13, w1, #0x1
	csel	x14, xzr, x14, ne
	add	x14, x15, x14
	ldp	q4, q6, [x14]
	zip2.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bif.16b	v3, v6, v7
	zip1.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bif.16b	v1, v4, v6
	stp	q1, q3, [x14]
	add	x11, x11, #1
	dup.2d	v1, x11
	mov	b3, v21[6]
	mov.b	v3[4], v21[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	bit.16b	v29, v1, v3
	mov	b3, v21[4]
	mov.b	v3[4], v21[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	mov	b4, v21[2]
	mov.b	v4[4], v21[3]
	bit.16b	v11, v1, v3
	ushll.2d	v3, v4, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	bit.16b	v10, v1, v3
	mov	b3, v21[0]
	mov.b	v3[4], v21[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	bit.16b	v31, v1, v3
	cbnz	w13, LBB0_3
	b	LBB0_16
LBB0_36:                                ; %uniform.false
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_3
LBB0_37:                                ; %schedule.3
                                        ;   in Loop: Header=BB0_4 Depth=1
	cmle.2d	v1, v27, #0
	cmle.2d	v3, v13, #0
	uzp1.4s	v1, v1, v3
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	cmle.2d	v3, v0, #0
	cmle.2d	v4, v26, #0
	uzp1.4s	v3, v3, v4
	uzp1.8h	v1, v1, v3
	xtn.8b	v1, v1
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	bit.8b	v15, v1, v3
	and.8b	v1, v21, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	and.8b	v1, v3, v2
	addv.8b	b1, v1
	umaxv.8b	b3, v3
	fmov	w13, s3
	tbz	w13, #0, LBB0_44
; %bb.38:                               ; %schedule.3
                                        ;   in Loop: Header=BB0_4 Depth=1
	dup.2d	v3, x20
	cmge.2d	v4, v13, v3
	cmge.2d	v6, v27, v3
	uzp1.4s	v4, v6, v4
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	cmge.2d	v6, v0, v3
	cmge.2d	v3, v26, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v3, v21, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w13, s3
	tst	w13, #0xff
	b.eq	LBB0_44
; %bb.39:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_4 Depth=1
	subs	w11, w12, #1
	csel	w11, wzr, w11, lo
	and	w13, w10, #0xff
	lsr	w14, w13, w11
	tst	w14, #0x1
	ldr	q4, [sp, #1120]                 ; 16-byte Folded Reload
	str	q4, [sp, #1536]
	ldr	q4, [sp, #1136]                 ; 16-byte Folded Reload
	str	q4, [sp, #1552]
	and	x11, x11, #0x7
	add	x9, sp, #1536
	ldr	w11, [x9, x11, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w11, #0, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_41
; %bb.40:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w11, #0, LBB0_377
LBB0_41:                                ; %convergence.overflow.resume
                                        ;   in Loop: Header=BB0_4 Depth=1
	mvn	w13, w10
	rbit	w13, w13
	clz	w13, w13
	mov	w9, #255                        ; =0xff
	bics	wzr, w9, w10
	csel	w13, wzr, w13, eq
	ubfiz	x14, x13, #2, #3
	lsl	w17, w20, w13
	ldr	q5, [sp, #1120]                 ; 16-byte Folded Reload
	str	q5, [sp, #1504]
	ldr	q4, [sp, #1136]                 ; 16-byte Folded Reload
	str	q4, [sp, #1520]
	add	x9, sp, #1504
	ldr	w1, [x9, x14]
	cmp	w11, #0
	csel	w11, w17, wzr, ne
	csel	w17, wzr, w1, ne
	str	q5, [sp, #1472]
	str	q4, [sp, #1488]
	add	x9, sp, #1472
	str	w17, [x9, x14]
	ldr	q4, [sp, #1488]
	str	q4, [sp, #1136]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #1472]
	str	q4, [sp, #1120]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	str	q5, [sp, #1440]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #1456]
	add	x9, sp, #1440
	ldr	w17, [x9, x14]
	csel	w17, w12, w17, ne
	str	q5, [sp, #1408]
	str	q4, [sp, #1424]
	add	x9, sp, #1408
	str	w17, [x9, x14]
	ldrb	w14, [x27, x13]
	and	w17, w14, #0x1
	fmov	s4, w17
	ubfx	w17, w14, #1, #1
	mov.b	v4[1], w17
	ubfx	w17, w14, #2, #1
	mov.b	v4[2], w17
	ubfx	w17, w14, #3, #1
	mov.b	v4[3], w17
	ubfx	w17, w14, #4, #1
	mov.b	v4[4], w17
	ubfx	w17, w14, #5, #1
	mov.b	v4[5], w17
	ubfx	w17, w14, #6, #1
	mov.b	v4[6], w17
	ldr	q5, [sp, #1424]
	str	q5, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1408]
	str	q5, [sp, #1088]                 ; 16-byte Folded Spill
	lsr	w14, w14, #7
	mov.b	v4[7], w14
	ldrb	w14, [x8, x13]
	and	w17, w14, #0x1
	fmov	s6, w17
	ubfx	w17, w14, #1, #1
	mov.b	v6[1], w17
	ubfx	w17, w14, #2, #1
	mov.b	v6[2], w17
	ubfx	w17, w14, #3, #1
	mov.b	v6[3], w17
	ubfx	w17, w14, #4, #1
	mov.b	v6[4], w17
	ubfx	w17, w14, #5, #1
	mov.b	v6[5], w17
	ubfx	w17, w14, #6, #1
	mov.b	v6[6], w17
	lsr	w14, w14, #7
	mov.b	v6[7], w14
	csetm	w14, ne
	dup.8b	v7, w14
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x27, x13]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_377
; %bb.42:                               ; %ready.overflow.resume41
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b1, [x21, x28]
	mov	w9, #4                          ; =0x4
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	b.hs	LBB0_377
; %bb.43:                               ; %ready.overflow.resume43
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b3, [x21, w19, uxtw]
	orr	w10, w11, w10
	mov	w9, #5                          ; =0x5
	b	LBB0_73
LBB0_44:                                ; %varying.coherent
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w13, s1
	tst	w13, #0xff
	b.eq	LBB0_71
; %bb.45:                               ; %varying.coherent.true
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_3
LBB0_46:                                ; %schedule.4
                                        ;   in Loop: Header=BB0_4 Depth=1
	rbit	w13, w11
	clz	w13, w13
	tst	w11, #0xff
	csel	w13, wzr, w13, eq
	ldp	q1, q0, [sp, #592]              ; 32-byte Folded Reload
	str	q0, [sp, #4640]
	str	q1, [sp, #4656]
	ldp	q1, q0, [sp, #560]              ; 32-byte Folded Reload
	str	q0, [sp, #4672]
	str	q1, [sp, #4688]
	ubfiz	x14, x13, #3, #3
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #544
	ldr	x17, [x9, x14]
	str	q27, [sp, #4576]
	str	q13, [sp, #4592]
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	str	q0, [sp, #4608]
	str	q26, [sp, #4624]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #480
	ldr	x14, [x9, x14]
	add	x17, x17, x17, lsl #6
	sub	x14, x14, x13
	add	x14, x14, x17
	add	x14, x6, x14, lsl #2
	add	x14, x14, #256
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w17, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w17, #0, LBB0_54
; %bb.47:                               ; %cond.load101
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s1, [x14]
	tbnz	w17, #1, LBB0_55
LBB0_48:                                ; %else105
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #2, LBB0_56
LBB0_49:                                ; %cond.load107
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x1, x14, #8
	ld1.s	{ v1 }[2], [x1]
	tbnz	w17, #3, LBB0_57
LBB0_50:                                ; %else111
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #4, LBB0_58
LBB0_51:                                ; %cond.load113
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x1, x14, #16
	ld1.s	{ v3 }[0], [x1]
	tbnz	w17, #5, LBB0_59
LBB0_52:                                ; %else117
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #6, LBB0_60
LBB0_53:                                ; %cond.load119
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x1, x14, #24
	ld1.s	{ v3 }[2], [x1]
	tbnz	w17, #7, LBB0_61
	b	LBB0_62
LBB0_54:                                ; %else102
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #1, LBB0_48
LBB0_55:                                ; %cond.load104
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x1, x14, #4
	ld1.s	{ v1 }[1], [x1]
	tbnz	w17, #2, LBB0_49
LBB0_56:                                ; %else108
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #3, LBB0_50
LBB0_57:                                ; %cond.load110
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x1, x14, #12
	ld1.s	{ v1 }[3], [x1]
	tbnz	w17, #4, LBB0_51
LBB0_58:                                ; %else114
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #5, LBB0_52
LBB0_59:                                ; %cond.load116
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x1, x14, #20
	ld1.s	{ v3 }[1], [x1]
	tbnz	w17, #6, LBB0_53
LBB0_60:                                ; %else120
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #7, LBB0_62
LBB0_61:                                ; %cond.load122
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x14, x14, #28
	ld1.s	{ v3 }[3], [x14]
LBB0_62:                                ; %else123
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldp	q4, q0, [sp, #864]              ; 32-byte Folded Reload
	str	q0, [sp, #4512]
	str	q4, [sp, #4528]
	ldp	q4, q0, [sp, #832]              ; 32-byte Folded Reload
	str	q0, [sp, #4544]
	str	q4, [sp, #4560]
	and	x14, x13, #0x7
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #416
	ldr	x14, [x9, x14, lsl #3]
	sub	x13, x14, x13, lsl #2
	add	x13, x13, #256
	ands	w11, w11, #0xff
	csel	x13, xzr, x13, eq
	add	x13, x15, x13
	ldp	q4, q6, [x13]
	zip2.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bif.16b	v3, v6, v7
	zip1.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bif.16b	v1, v4, v6
	stp	q1, q3, [x13]
	cbz	w11, LBB0_3
LBB0_63:                                ; %schedule.5
                                        ;   in Loop: Header=BB0_4 Depth=1
	cbz	w12, LBB0_68
; %bb.64:                               ; %convergence.cascade.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w11, #0                         ; =0x0
LBB0_65:                                ; %convergence.cascade
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w13, s3
	umaxv.8b	b1, v1
	fmov	w2, s1
	sub	w14, w12, #1
	tst	w13, #0xff
	csel	w14, w14, wzr, ne
	lsl	w17, w20, w14
	and	w13, w17, w10
	tst	w13, #0xff
	cset	w4, ne
	ldr	q1, [sp, #1120]                 ; 16-byte Folded Reload
	str	q1, [sp, #4480]
	ldr	q1, [sp, #1136]                 ; 16-byte Folded Reload
	str	q1, [sp, #4496]
	ubfiz	x13, x14, #2, #3
	ldr	w1, [x0, x13]
	cmp	w1, #0
	cset	w1, eq
	and	w2, w4, w2
	ldrb	w4, [x27, w14, sxtw]
	and	w5, w4, #0x1
	fmov	s1, w5
	ubfx	w5, w4, #1, #1
	mov.b	v1[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v1[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v1[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v1[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v1[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v1[6], w5
	lsr	w4, w4, #7
	mov.b	v1[7], w4
	ldrb	w4, [x8, w14, sxtw]
	and	w5, w4, #0x1
	fmov	s3, w5
	ubfx	w5, w4, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v3[6], w5
	lsr	w4, w4, #7
	mov.b	v3[7], w4
	orr.8b	v4, v21, v3
	and.8b	v6, v12, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w4, s6
	ands	w1, w2, w1
	csetm	w2, ne
	bics	w4, w1, w4
	csetm	w5, ne
	dup.8b	v6, w5
	mov	w5, #-1                         ; =0xffffffff
	dup.8b	v7, w2
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	csinv	w14, w5, w17, eq
	dup.8b	v1, w1
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w4
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #4448]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #4464]
	ldr	w13, [x16, x13]
	csel	w12, w13, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
	cmp	w1, #1
	b.ne	LBB0_69
; %bb.66:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_65 Depth=2
	cmp	w12, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_69
; %bb.67:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_65 Depth=2
	add	w11, w11, #1
	tst	w13, #0xff
	b.ne	LBB0_65
	b	LBB0_69
LBB0_68:                                ; %schedule.5.convergence.cascade.exit_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
LBB0_69:                                ; %convergence.cascade.exit
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_72
; %bb.70:                               ; %convergence.target.5.ready
                                        ;   in Loop: Header=BB0_4 Depth=1
	rbit	w11, w13
	clz	w11, w11
	ldp	q1, q0, [sp, #864]              ; 32-byte Folded Reload
	str	q0, [sp, #4384]
	str	q1, [sp, #4400]
	ldp	q1, q0, [sp, #832]              ; 32-byte Folded Reload
	str	q0, [sp, #4416]
	str	q1, [sp, #4432]
	and	x13, x11, #0x7
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #288
	ldr	x13, [x9, x13, lsl #3]
	lsl	w11, w11, #2
	sub	x11, x13, x11
	add	x11, x15, x11
	ldp	q1, q3, [x11]
	mov.16b	v0, v8
	mov.16b	v8, v18
	mov.16b	v18, v0
	mov.16b	v5, v15
	mov.16b	v15, v10
	mov.16b	v0, v26
	mov.16b	v10, v29
	mov.16b	v29, v11
	fmul.4s	v11, v1, v1
	fmul.4s	v26, v3, v3
	ldp	q4, q6, [x11, #32]
	fmul.4s	v4, v4, v4
	fmul.4s	v6, v6, v6
	ldp	q7, q16, [x11, #64]
	fmul.4s	v7, v7, v7
	fmul.4s	v16, v16, v16
	ldp	q19, q17, [x11, #96]
	fmul.4s	v19, v19, v19
	fmul.4s	v17, v17, v17
	str	q5, [sp, #512]                  ; 16-byte Folded Spill
	str	q27, [sp, #896]                 ; 16-byte Folded Spill
	stp	q24, q14, [sp, #752]            ; 32-byte Folded Spill
	mov	b20, v21[6]
	mov.b	v20[4], v21[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	mov	w9, #4                          ; =0x4
	mov.16b	v5, v23
	dup.2d	v23, x9
	mov.16b	v24, v0
	mov.16b	v0, v15
	ldr	q15, [sp, #992]                 ; 16-byte Folded Reload
	bit.16b	v15, v23, v20
	str	q15, [sp, #992]                 ; 16-byte Folded Spill
	mov.16b	v1, v8
	mov	b20, v21[4]
	mov.b	v20[4], v21[5]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	bit.16b	v9, v23, v20
	mov	b20, v21[2]
	mov.b	v20[4], v21[3]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	mov.16b	v8, v20
	bsl.16b	v8, v23, v18
	mov	b20, v21[0]
	mov.b	v20[4], v21[1]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	bit.16b	v30, v23, v20
	zip1.8b	v20, v21, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmlt.4s	v20, v20, #0
	zip2.8b	v23, v21, v0
	ushll.4s	v23, v23, #0
	shl.4s	v23, v23, #31
	cmlt.4s	v23, v23, #0
	bit.16b	v28, v26, v23
	ldr	q3, [sp, #624]                  ; 16-byte Folded Reload
	bit.16b	v3, v11, v20
	mov.16b	v11, v29
	mov.16b	v29, v10
	mov.16b	v26, v24
	mov.16b	v10, v0
	str	q3, [sp, #624]                  ; 16-byte Folded Spill
	mov.16b	v18, v23
	bsl.16b	v18, v6, v1
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	bit.16b	v0, v4, v20
	str	q0, [sp, #928]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #432]                  ; 16-byte Folded Reload
	bit.16b	v0, v16, v23
	str	q0, [sp, #432]                  ; 16-byte Folded Spill
	ldp	q14, q0, [sp, #768]             ; 32-byte Folded Reload
	bit.16b	v0, v7, v20
	str	q0, [sp, #784]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #544]                  ; 16-byte Folded Reload
	bit.16b	v1, v17, v23
	str	q1, [sp, #544]                  ; 16-byte Folded Spill
	mov.16b	v23, v5
	ldp	q15, q1, [sp, #512]             ; 32-byte Folded Reload
	bit.16b	v1, v19, v20
	movi.8b	v20, #1
	str	q1, [sp, #528]                  ; 16-byte Folded Spill
	ldr	q24, [sp, #752]                 ; 16-byte Folded Reload
	ldr	q27, [sp, #896]                 ; 16-byte Folded Reload
	add	x4, sp, #3568
	b	LBB0_75
LBB0_71:                                ; %varying.coherent.false
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.ne	LBB0_63
	b	LBB0_3
LBB0_72:                                ;   in Loop: Header=BB0_4 Depth=1
	add	x4, sp, #3568
	b	LBB0_3
LBB0_73:                                ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	w9, [x22, w19, uxtw #2]
LBB0_74:                                ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	w26, w19, #1
	str	w12, [x23, w19, uxtw #2]
	b	LBB0_3
LBB0_75:                                ; %schedule.6
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
	mov	w9, #8                          ; =0x8
	dup.2d	v3, x9
	cmgt.2d	v1, v3, v8
	cmgt.2d	v4, v3, v30
	uzp1.4s	v1, v4, v1
	cmgt.2d	v4, v3, v9
	ldr	q5, [sp, #992]                  ; 16-byte Folded Reload
	cmgt.2d	v6, v3, v5
	uzp1.4s	v4, v4, v6
	uzp1.8h	v1, v1, v4
	xtn.8b	v1, v1
	and.8b	v1, v21, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v4, v1, #0
	and.8b	v1, v4, v2
	addv.8b	b1, v1
	fmov	w11, s1
	umaxv.8b	b4, v4
	fmov	w14, s4
	tbz	w14, #0, LBB0_82
; %bb.76:                               ; %schedule.6
                                        ;   in Loop: Header=BB0_4 Depth=1
	cmge.2d	v4, v8, v3
	cmge.2d	v6, v30, v3
	uzp1.4s	v4, v6, v4
	cmge.2d	v6, v9, v3
	cmge.2d	v3, v5, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v3, v21, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w14, s3
	tst	w14, #0xff
	b.eq	LBB0_82
; %bb.77:                               ; %varying.divergent69
                                        ;   in Loop: Header=BB0_4 Depth=1
	subs	w11, w12, #1
	csel	w11, wzr, w11, lo
	and	w13, w10, #0xff
	lsr	w14, w13, w11
	tst	w14, #0x1
	ldr	q4, [sp, #1120]                 ; 16-byte Folded Reload
	str	q4, [sp, #1696]
	ldr	q4, [sp, #1136]                 ; 16-byte Folded Reload
	str	q4, [sp, #1712]
	and	x11, x11, #0x7
	add	x9, sp, #1696
	ldr	w11, [x9, x11, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w11, #1, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_79
; %bb.78:                               ; %varying.divergent69
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w11, #0, LBB0_377
LBB0_79:                                ; %convergence.overflow.resume72
                                        ;   in Loop: Header=BB0_4 Depth=1
	mvn	w13, w10
	rbit	w13, w13
	clz	w13, w13
	mov	w9, #255                        ; =0xff
	bics	wzr, w9, w10
	csel	w13, wzr, w13, eq
	ubfiz	x14, x13, #2, #3
	lsl	w17, w20, w13
	ldr	q5, [sp, #1120]                 ; 16-byte Folded Reload
	str	q5, [sp, #1664]
	ldr	q4, [sp, #1136]                 ; 16-byte Folded Reload
	str	q4, [sp, #1680]
	add	x9, sp, #1664
	ldr	w1, [x9, x14]
	cmp	w11, #0
	csel	w11, w17, wzr, ne
	csinc	w17, w1, wzr, eq
	str	q5, [sp, #1632]
	str	q4, [sp, #1648]
	add	x9, sp, #1632
	str	w17, [x9, x14]
	ldr	q4, [sp, #1648]
	str	q4, [sp, #1136]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #1632]
	str	q4, [sp, #1120]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	str	q5, [sp, #1600]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #1616]
	add	x9, sp, #1600
	ldr	w17, [x9, x14]
	csel	w17, w12, w17, ne
	str	q5, [sp, #1568]
	str	q4, [sp, #1584]
	add	x9, sp, #1568
	str	w17, [x9, x14]
	ldrb	w14, [x27, x13]
	and	w17, w14, #0x1
	fmov	s4, w17
	ubfx	w17, w14, #1, #1
	mov.b	v4[1], w17
	ubfx	w17, w14, #2, #1
	mov.b	v4[2], w17
	ubfx	w17, w14, #3, #1
	mov.b	v4[3], w17
	ubfx	w17, w14, #4, #1
	mov.b	v4[4], w17
	ubfx	w17, w14, #5, #1
	mov.b	v4[5], w17
	ubfx	w17, w14, #6, #1
	mov.b	v4[6], w17
	ldr	q5, [sp, #1584]
	str	q5, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1568]
	str	q5, [sp, #1088]                 ; 16-byte Folded Spill
	lsr	w14, w14, #7
	mov.b	v4[7], w14
	ldrb	w14, [x8, x13]
	and	w17, w14, #0x1
	fmov	s6, w17
	ubfx	w17, w14, #1, #1
	mov.b	v6[1], w17
	ubfx	w17, w14, #2, #1
	mov.b	v6[2], w17
	ubfx	w17, w14, #3, #1
	mov.b	v6[3], w17
	ubfx	w17, w14, #4, #1
	mov.b	v6[4], w17
	ubfx	w17, w14, #5, #1
	mov.b	v6[5], w17
	ubfx	w17, w14, #6, #1
	mov.b	v6[6], w17
	lsr	w14, w14, #7
	mov.b	v6[7], w14
	csetm	w14, ne
	dup.8b	v7, w14
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x27, x13]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_377
; %bb.80:                               ; %ready.overflow.resume74
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b1, [x21, x28]
	mov	w9, #7                          ; =0x7
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	b.hs	LBB0_377
; %bb.81:                               ; %ready.overflow.resume76
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b3, [x21, w19, uxtw]
	orr	w10, w11, w10
	mov	w9, #8                          ; =0x8
	str	w9, [x22, w19, uxtw #2]
	b	LBB0_74
LBB0_82:                                ; %varying.coherent70
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_153
; %bb.83:                               ; %varying.coherent.true77
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_3
; %bb.84:                               ;   in Loop: Header=BB0_4 Depth=1
	mov	w11, #0                         ; =0x0
LBB0_85:                                ; %schedule.7
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.16b	v1, v29
	mov.16b	v29, v25
	mov.16b	v5, v18
	str	q31, [sp, #176]                 ; 16-byte Folded Spill
	stp	q22, q24, [sp, #736]            ; 32-byte Folded Spill
	str	q10, [sp, #144]                 ; 16-byte Folded Spill
	str	q15, [sp, #512]                 ; 16-byte Folded Spill
	str	d12, [sp, #664]                 ; 8-byte Folded Spill
	str	q23, [sp, #704]                 ; 16-byte Folded Spill
	str	q1, [sp, #640]                  ; 16-byte Folded Spill
	ldp	q0, q12, [sp, #912]             ; 32-byte Folded Reload
	str	q30, [sp, #224]                 ; 16-byte Folded Spill
	shl.2d	v1, v30, #5
	shl.2d	v6, v8, #5
	shl.2d	v3, v9, #5
	ldr	q4, [sp, #992]                  ; 16-byte Folded Reload
	shl.2d	v4, v4, #5
	ldr	q7, [sp, #832]                  ; 16-byte Folded Reload
	add.2d	v4, v4, v7
	ldr	q7, [sp, #848]                  ; 16-byte Folded Reload
	add.2d	v3, v3, v7
	ldr	q7, [sp, #864]                  ; 16-byte Folded Reload
	add.2d	v16, v6, v7
	ldr	q6, [sp, #880]                  ; 16-byte Folded Reload
	add.2d	v17, v1, v6
	ldp	q1, q22, [sp, #416]             ; 32-byte Folded Reload
	add.2d	v25, v1, v17
	ldp	q1, q6, [sp, #384]              ; 32-byte Folded Reload
	add.2d	v23, v6, v16
	add.2d	v20, v1, v3
	ldr	q1, [sp, #368]                  ; 16-byte Folded Reload
	add.2d	v6, v1, v4
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b7, v1
	fmov	w13, s7
	movi.2d	v1, #0000000000000000
	movi.2d	v19, #0000000000000000
	str	q14, [sp, #768]                 ; 16-byte Folded Spill
	str	q29, [sp, #720]                 ; 16-byte Folded Spill
	stp	q27, q0, [sp, #896]             ; 32-byte Folded Spill
	stp	q8, q9, [sp, #192]              ; 32-byte Folded Spill
	str	q11, [sp, #160]                 ; 16-byte Folded Spill
	stp	q26, q13, [sp, #672]            ; 32-byte Folded Spill
	str	q28, [sp, #352]                 ; 16-byte Folded Spill
	tbz	w13, #0, LBB0_91
; %bb.86:                               ; %cond.load126
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d25
	ldr	s1, [x14]
	tbnz	w13, #1, LBB0_92
LBB0_87:                                ; %else130
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #2, LBB0_93
LBB0_88:                                ; %cond.load132
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d23
	ld1.s	{ v1 }[2], [x14]
	tbnz	w13, #3, LBB0_94
LBB0_89:                                ; %else136
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q23, [sp, #624]                 ; 16-byte Folded Reload
	tbz	w13, #4, LBB0_95
LBB0_90:                                ; %cond.load138
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q8, [sp, #1072]                 ; 16-byte Folded Reload
	ldr	q18, [sp, #1056]                ; 16-byte Folded Reload
	ldp	q11, q26, [sp, #960]            ; 32-byte Folded Reload
	ldr	q24, [sp, #1040]                ; 16-byte Folded Reload
	fmov	x14, d20
	ld1.s	{ v19 }[0], [x14]
	mov.16b	v10, v23
	mov.16b	v13, v12
	ldr	q27, [sp, #784]                 ; 16-byte Folded Reload
	tbnz	w13, #5, LBB0_96
	b	LBB0_97
LBB0_91:                                ; %else127
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #1, LBB0_87
LBB0_92:                                ; %cond.load129
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v25[1]
	ld1.s	{ v1 }[1], [x14]
	tbnz	w13, #2, LBB0_88
LBB0_93:                                ; %else133
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #3, LBB0_89
LBB0_94:                                ; %cond.load135
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v23[1]
	ld1.s	{ v1 }[3], [x14]
	ldr	q23, [sp, #624]                 ; 16-byte Folded Reload
	tbnz	w13, #4, LBB0_90
LBB0_95:                                ;   in Loop: Header=BB0_4 Depth=1
	ldr	q8, [sp, #1072]                 ; 16-byte Folded Reload
	ldr	q18, [sp, #1056]                ; 16-byte Folded Reload
	ldp	q11, q26, [sp, #960]            ; 32-byte Folded Reload
	ldr	q24, [sp, #1040]                ; 16-byte Folded Reload
	mov.16b	v10, v23
	mov.16b	v13, v12
	ldr	q27, [sp, #784]                 ; 16-byte Folded Reload
	tbz	w13, #5, LBB0_97
LBB0_96:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v20[1]
	ld1.s	{ v19 }[1], [x14]
LBB0_97:                                ; %else142
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q20, [sp, #992]                 ; 16-byte Folded Reload
	str	q20, [sp, #992]                 ; 16-byte Folded Spill
	tbz	w13, #6, LBB0_99
; %bb.98:                               ; %cond.load144
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d6
	ld1.s	{ v19 }[2], [x14]
	tbnz	w13, #7, LBB0_100
	b	LBB0_101
LBB0_99:                                ; %else145
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #7, LBB0_101
LBB0_100:                               ; %cond.load147
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x13, v6[1]
	ld1.s	{ v19 }[3], [x13]
LBB0_101:                               ; %else148
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmul.4s	v6, v19, v19
	fmul.4s	v1, v1, v1
	fadd.4s	v0, v10, v1
	ldr	q1, [sp, #352]                  ; 16-byte Folded Reload
	fadd.4s	v1, v1, v6
	stp	q1, q0, [sp, #304]              ; 32-byte Folded Spill
	ldp	q0, q1, [sp, #368]              ; 32-byte Folded Reload
	add.2d	v23, v4, v0
	add.2d	v3, v3, v1
	ldp	q1, q0, [sp, #400]              ; 32-byte Folded Reload
	add.2d	v4, v17, v0
	add.2d	v20, v16, v1
	mov	w9, #32                         ; =0x20
	dup.2d	v16, x9
	add.2d	v25, v20, v16
	add.2d	v31, v4, v16
	add.2d	v30, v3, v16
	add.2d	v19, v23, v16
	fmov	w13, s7
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	ldr	d1, [sp, #664]                  ; 8-byte Folded Reload
	tbz	w13, #0, LBB0_110
; %bb.102:                              ; %cond.load151
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d31
	ldr	s16, [x14]
	tbnz	w13, #1, LBB0_111
LBB0_103:                               ; %else161
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	q8, [sp, #1072]                 ; 16-byte Folded Spill
	tbz	w13, #2, LBB0_112
LBB0_104:                               ; %cond.load163
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d25
	ld1.s	{ v16 }[2], [x14]
	str	q18, [sp, #1056]                ; 16-byte Folded Spill
	tbnz	w13, #3, LBB0_113
LBB0_105:                               ; %else173
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q12, [sp, #816]                 ; 16-byte Folded Reload
	tbz	w13, #4, LBB0_114
LBB0_106:                               ; %cond.load175
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d30
	ld1.s	{ v17 }[0], [x14]
	stp	q11, q26, [sp, #960]            ; 32-byte Folded Spill
	str	q24, [sp, #1040]                ; 16-byte Folded Spill
	tbnz	w13, #5, LBB0_115
LBB0_107:                               ; %else185
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #6, LBB0_116
LBB0_108:                               ; %cond.load187
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d19
	ld1.s	{ v17 }[2], [x14]
	ldr	q15, [sp, #800]                 ; 16-byte Folded Reload
	stp	q15, q12, [sp, #800]            ; 32-byte Folded Spill
	tbnz	w13, #7, LBB0_117
LBB0_109:                               ;   in Loop: Header=BB0_4 Depth=1
	ldr	q8, [sp, #640]                  ; 16-byte Folded Reload
	b	LBB0_118
LBB0_110:                               ; %else155
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #1, LBB0_103
LBB0_111:                               ; %cond.load157
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v31[1]
	ld1.s	{ v16 }[1], [x14]
	str	q8, [sp, #1072]                 ; 16-byte Folded Spill
	tbnz	w13, #2, LBB0_104
LBB0_112:                               ; %else167
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	q18, [sp, #1056]                ; 16-byte Folded Spill
	tbz	w13, #3, LBB0_105
LBB0_113:                               ; %cond.load169
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v25[1]
	ld1.s	{ v16 }[3], [x14]
	ldr	q12, [sp, #816]                 ; 16-byte Folded Reload
	tbnz	w13, #4, LBB0_106
LBB0_114:                               ; %else179
                                        ;   in Loop: Header=BB0_4 Depth=1
	stp	q11, q26, [sp, #960]            ; 32-byte Folded Spill
	str	q24, [sp, #1040]                ; 16-byte Folded Spill
	tbz	w13, #5, LBB0_107
LBB0_115:                               ; %cond.load181
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v30[1]
	ld1.s	{ v17 }[1], [x14]
	tbnz	w13, #6, LBB0_108
LBB0_116:                               ; %else191
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q15, [sp, #800]                 ; 16-byte Folded Reload
	stp	q15, q12, [sp, #800]            ; 32-byte Folded Spill
	tbz	w13, #7, LBB0_109
LBB0_117:                               ; %cond.load193
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q8, [sp, #640]                  ; 16-byte Folded Reload
	mov.d	x13, v19[1]
	ld1.s	{ v17 }[3], [x13]
LBB0_118:                               ; %else197
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmul.4s	v17, v17, v17
	fmul.4s	v16, v16, v16
	fadd.4s	v0, v13, v16
	fadd.4s	v6, v5, v17
	stp	q6, q0, [sp, #272]              ; 32-byte Folded Spill
	mov	w9, #64                         ; =0x40
	dup.2d	v16, x9
	add.2d	v31, v20, v16
	add.2d	v12, v4, v16
	add.2d	v25, v3, v16
	add.2d	v30, v23, v16
	fmov	w13, s7
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w13, #0, LBB0_126
; %bb.119:                              ; %cond.load200
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d12
	ldr	s16, [x14]
	tbnz	w13, #1, LBB0_127
LBB0_120:                               ; %else210
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #2, LBB0_128
LBB0_121:                               ; %cond.load212
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d31
	ld1.s	{ v16 }[2], [x14]
	tbnz	w13, #3, LBB0_129
LBB0_122:                               ; %else222
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #4, LBB0_130
LBB0_123:                               ; %cond.load224
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d25
	ld1.s	{ v17 }[0], [x14]
	tbnz	w13, #5, LBB0_131
LBB0_124:                               ; %else234
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #6, LBB0_132
LBB0_125:                               ; %cond.load236
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d30
	ld1.s	{ v17 }[2], [x14]
	tbnz	w13, #7, LBB0_133
	b	LBB0_134
LBB0_126:                               ; %else204
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #1, LBB0_120
LBB0_127:                               ; %cond.load206
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v12[1]
	ld1.s	{ v16 }[1], [x14]
	tbnz	w13, #2, LBB0_121
LBB0_128:                               ; %else216
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #3, LBB0_122
LBB0_129:                               ; %cond.load218
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v31[1]
	ld1.s	{ v16 }[3], [x14]
	tbnz	w13, #4, LBB0_123
LBB0_130:                               ; %else228
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #5, LBB0_124
LBB0_131:                               ; %cond.load230
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v25[1]
	ld1.s	{ v17 }[1], [x14]
	tbnz	w13, #6, LBB0_125
LBB0_132:                               ; %else240
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #7, LBB0_134
LBB0_133:                               ; %cond.load242
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x13, v30[1]
	ld1.s	{ v17 }[3], [x13]
LBB0_134:                               ; %else246
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmul.4s	v17, v17, v17
	fmul.4s	v16, v16, v16
	fadd.4s	v16, v27, v16
	fadd.4s	v17, v22, v17
	mov	w9, #96                         ; =0x60
	dup.2d	v12, x9
	add.2d	v30, v20, v12
	add.2d	v31, v4, v12
	add.2d	v25, v3, v12
	add.2d	v20, v23, v12
	fmov	w13, s7
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w13, #0, LBB0_138
; %bb.135:                              ; %cond.load249
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d31
	ldr	s3, [x14]
	tbnz	w13, #1, LBB0_139
LBB0_136:                               ; %else259
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	ldr	q19, [sp, #512]                 ; 16-byte Folded Reload
	fmov	d12, d1
	ldr	q6, [sp, #144]                  ; 16-byte Folded Reload
	tbz	w13, #2, LBB0_140
LBB0_137:                               ; %cond.load261
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d30
	ld1.s	{ v3 }[2], [x14]
	ldr	q9, [sp, #752]                  ; 16-byte Folded Reload
	ldr	q23, [sp, #992]                 ; 16-byte Folded Reload
	ldr	q26, [sp, #528]                 ; 16-byte Folded Reload
	ldr	q31, [sp, #176]                 ; 16-byte Folded Reload
	tbnz	w13, #3, LBB0_141
	b	LBB0_142
LBB0_138:                               ; %else253
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #1, LBB0_136
LBB0_139:                               ; %cond.load255
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v31[1]
	ld1.s	{ v3 }[1], [x14]
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	ldr	q19, [sp, #512]                 ; 16-byte Folded Reload
	fmov	d12, d1
	ldr	q6, [sp, #144]                  ; 16-byte Folded Reload
	tbnz	w13, #2, LBB0_137
LBB0_140:                               ; %else265
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q9, [sp, #752]                  ; 16-byte Folded Reload
	ldr	q23, [sp, #992]                 ; 16-byte Folded Reload
	ldr	q26, [sp, #528]                 ; 16-byte Folded Reload
	ldr	q31, [sp, #176]                 ; 16-byte Folded Reload
	tbz	w13, #3, LBB0_142
LBB0_141:                               ; %cond.load267
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v30[1]
	ld1.s	{ v3 }[3], [x14]
LBB0_142:                               ; %else271
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q1, [sp, #544]                  ; 16-byte Folded Reload
	mov.16b	v18, v27
	mov.16b	v14, v22
	mov.16b	v22, v13
	mov.16b	v24, v5
	mov.16b	v11, v10
	ldr	q28, [sp, #352]                 ; 16-byte Folded Reload
	ldp	q7, q5, [sp, #192]              ; 32-byte Folded Reload
	tbz	w13, #4, LBB0_146
; %bb.143:                              ; %cond.load273
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d25
	ld1.s	{ v4 }[0], [x14]
	ldr	q29, [sp, #896]                 ; 16-byte Folded Reload
	ldp	q10, q13, [sp, #672]            ; 32-byte Folded Reload
	ldr	q15, [sp, #1024]                ; 16-byte Folded Reload
	mov.16b	v27, v7
	tbnz	w13, #5, LBB0_147
LBB0_144:                               ; %else283
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q30, [sp, #224]                 ; 16-byte Folded Reload
	tbz	w13, #6, LBB0_148
LBB0_145:                               ; %cond.load285
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d20
	ld1.s	{ v4 }[2], [x14]
	tbnz	w13, #7, LBB0_149
	b	LBB0_150
LBB0_146:                               ; %else277
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q29, [sp, #896]                 ; 16-byte Folded Reload
	ldp	q10, q13, [sp, #672]            ; 32-byte Folded Reload
	ldr	q15, [sp, #1024]                ; 16-byte Folded Reload
	mov.16b	v27, v7
	tbz	w13, #5, LBB0_144
LBB0_147:                               ; %cond.load279
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v25[1]
	ld1.s	{ v4 }[1], [x14]
	ldr	q30, [sp, #224]                 ; 16-byte Folded Reload
	tbnz	w13, #6, LBB0_145
LBB0_148:                               ; %else289
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #7, LBB0_150
LBB0_149:                               ; %cond.load291
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x13, v20[1]
	ld1.s	{ v4 }[3], [x13]
LBB0_150:                               ; %else295
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmul.4s	v4, v4, v4
	fmul.4s	v3, v3, v3
	fadd.4s	v3, v26, v3
	mov	w9, #4                          ; =0x4
	dup.2d	v7, x9
	mov	b20, v21[6]
	mov.b	v20[4], v21[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v20, v20, v7
	add.2d	v23, v23, v20
	str	q23, [sp, #992]                 ; 16-byte Folded Spill
	mov	b20, v21[4]
	mov.b	v20[4], v21[5]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v20, v20, v7
	add.2d	v5, v5, v20
	mov	b20, v21[2]
	mov.b	v20[4], v21[3]
	fadd.4s	v4, v1, v4
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v20, v20, v7
	add.2d	v27, v27, v20
	mov	b20, v21[0]
	mov.b	v20[4], v21[1]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v7, v20, v7
	add.2d	v30, v30, v7
	zip1.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	zip2.8b	v20, v21, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmlt.4s	v20, v20, #0
	ldp	q25, q23, [sp, #304]            ; 32-byte Folded Reload
	bit.16b	v28, v25, v20
	bit.16b	v11, v23, v7
	str	q11, [sp, #624]                 ; 16-byte Folded Spill
	ldp	q25, q23, [sp, #272]            ; 32-byte Folded Reload
	bit.16b	v24, v25, v20
	bit.16b	v22, v23, v7
	stp	q22, q0, [sp, #928]             ; 32-byte Folded Spill
	bit.16b	v14, v17, v20
	str	q14, [sp, #432]                 ; 16-byte Folded Spill
	bit.16b	v18, v16, v7
	str	q18, [sp, #784]                 ; 16-byte Folded Spill
	bit.16b	v1, v4, v20
	bit.16b	v26, v3, v7
	stp	q26, q1, [sp, #528]             ; 32-byte Folded Spill
	str	q15, [sp, #1024]                ; 16-byte Folded Spill
	movi.8b	v20, #1
	tbz	w11, #0, LBB0_152
; %bb.151:                              ;   in Loop: Header=BB0_4 Depth=1
	ldp	q23, q25, [sp, #704]            ; 32-byte Folded Reload
	ldr	q14, [sp, #768]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #736]                 ; 16-byte Folded Reload
	ldr	q11, [sp, #160]                 ; 16-byte Folded Reload
	mov.16b	v3, v8
	mov.16b	v0, v9
	mov.16b	v9, v5
	mov.16b	v15, v19
	mov.16b	v8, v27
	mov.16b	v18, v24
	mov.16b	v24, v0
	mov.16b	v26, v10
	mov.16b	v10, v6
	mov.16b	v27, v29
	mov.16b	v29, v3
	b	LBB0_3
LBB0_152:                               ;   in Loop: Header=BB0_4 Depth=1
	ldp	q23, q25, [sp, #704]            ; 32-byte Folded Reload
	ldr	q14, [sp, #768]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #736]                 ; 16-byte Folded Reload
	ldr	q11, [sp, #160]                 ; 16-byte Folded Reload
	mov.16b	v3, v8
	mov.16b	v0, v9
	mov.16b	v9, v5
	mov.16b	v15, v19
	mov.16b	v8, v27
	mov.16b	v18, v24
	mov.16b	v24, v0
	mov.16b	v26, v10
	mov.16b	v10, v6
	mov.16b	v27, v29
	mov.16b	v29, v3
	b	LBB0_75
LBB0_153:                               ; %varying.coherent.false78
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_3
LBB0_154:                               ; %schedule.8
                                        ;   in Loop: Header=BB0_4 Depth=1
	cbz	w12, LBB0_159
; %bb.155:                              ; %convergence.cascade92.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w13, #0                         ; =0x0
LBB0_156:                               ; %convergence.cascade92
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w2, s1
	sub	w14, w12, #1
	tst	w11, #0xff
	csel	w14, w14, wzr, ne
	lsl	w17, w20, w14
	and	w11, w17, w10
	tst	w11, #0xff
	cset	w4, ne
	ldr	q1, [sp, #1120]                 ; 16-byte Folded Reload
	str	q1, [sp, #4352]
	ldr	q1, [sp, #1136]                 ; 16-byte Folded Reload
	str	q1, [sp, #4368]
	ubfiz	x11, x14, #2, #3
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #256
	ldr	w1, [x9, x11]
	cmp	w1, #1
	cset	w1, eq
	and	w2, w4, w2
	ldrb	w4, [x27, w14, sxtw]
	and	w5, w4, #0x1
	fmov	s1, w5
	ubfx	w5, w4, #1, #1
	mov.b	v1[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v1[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v1[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v1[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v1[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v1[6], w5
	lsr	w4, w4, #7
	mov.b	v1[7], w4
	ldrb	w4, [x8, w14, sxtw]
	and	w5, w4, #0x1
	fmov	s3, w5
	ubfx	w5, w4, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v3[6], w5
	lsr	w4, w4, #7
	mov.b	v3[7], w4
	orr.8b	v4, v21, v3
	and.8b	v6, v12, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w4, s6
	ands	w1, w2, w1
	csetm	w2, ne
	bics	w4, w1, w4
	csetm	w5, ne
	dup.8b	v6, w5
	mov	w5, #-1                         ; =0xffffffff
	dup.8b	v7, w2
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	csinv	w14, w5, w17, eq
	dup.8b	v1, w1
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w4
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #4320]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #4336]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #224
	ldr	w11, [x9, x11]
	csel	w12, w11, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w1, #1
	b.ne	LBB0_160
; %bb.157:                              ; %convergence.cascade92
                                        ;   in Loop: Header=BB0_156 Depth=2
	cmp	w12, #0
	ccmp	w13, #6, #2, ne
	b.hi	LBB0_160
; %bb.158:                              ; %convergence.cascade92
                                        ;   in Loop: Header=BB0_156 Depth=2
	add	w13, w13, #1
	tst	w11, #0xff
	b.ne	LBB0_156
	b	LBB0_160
LBB0_159:                               ; %schedule.8.convergence.cascade.exit93_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_160:                               ; %convergence.cascade.exit93
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_72
; %bb.161:                              ; %convergence.target.8.ready
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v1, v15, v21
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b4, v3
	umaxv.8b	b1, v1
	fmov	w13, s1
	add	x4, sp, #3568
	tbz	w13, #0, LBB0_168
; %bb.162:                              ; %convergence.target.8.ready
                                        ;   in Loop: Header=BB0_4 Depth=1
	bic.8b	v3, v21, v15
	shl.8b	v1, v3, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
	tst	w13, #0xff
	b.eq	LBB0_168
; %bb.163:                              ; %varying.divergent110
                                        ;   in Loop: Header=BB0_4 Depth=1
	subs	w11, w12, #1
	csel	w11, wzr, w11, lo
	and	w13, w10, #0xff
	lsr	w14, w13, w11
	tst	w14, #0x1
	ldr	q5, [sp, #1120]                 ; 16-byte Folded Reload
	str	q5, [sp, #1856]
	ldr	q5, [sp, #1136]                 ; 16-byte Folded Reload
	str	q5, [sp, #1872]
	and	x11, x11, #0x7
	add	x9, sp, #1856
	ldr	w11, [x9, x11, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w11, #2, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_165
; %bb.164:                              ; %varying.divergent110
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w11, #0, LBB0_377
LBB0_165:                               ; %convergence.overflow.resume113
                                        ;   in Loop: Header=BB0_4 Depth=1
	mvn	w13, w10
	rbit	w13, w13
	clz	w13, w13
	mov	w9, #255                        ; =0xff
	bics	wzr, w9, w10
	csel	w13, wzr, w13, eq
	ubfiz	x14, x13, #2, #3
	lsl	w17, w20, w13
	ldr	q6, [sp, #1120]                 ; 16-byte Folded Reload
	str	q6, [sp, #1824]
	ldr	q5, [sp, #1136]                 ; 16-byte Folded Reload
	str	q5, [sp, #1840]
	add	x9, sp, #1824
	ldr	w1, [x9, x14]
	cmp	w11, #0
	csel	w11, w17, wzr, ne
	mov	w9, #2                          ; =0x2
	csel	w17, w9, w1, ne
	str	q6, [sp, #1792]
	str	q5, [sp, #1808]
	add	x9, sp, #1792
	str	w17, [x9, x14]
	ldr	q5, [sp, #1808]
	str	q5, [sp, #1136]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1792]
	str	q5, [sp, #1120]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1088]                 ; 16-byte Folded Reload
	str	q6, [sp, #1760]
	ldr	q5, [sp, #1104]                 ; 16-byte Folded Reload
	str	q5, [sp, #1776]
	add	x9, sp, #1760
	ldr	w17, [x9, x14]
	csel	w17, w12, w17, ne
	str	q6, [sp, #1728]
	str	q5, [sp, #1744]
	add	x9, sp, #1728
	str	w17, [x9, x14]
	ldrb	w14, [x27, x13]
	and	w17, w14, #0x1
	fmov	s6, w17
	ubfx	w17, w14, #1, #1
	mov.b	v6[1], w17
	ubfx	w17, w14, #2, #1
	mov.b	v6[2], w17
	ubfx	w17, w14, #3, #1
	mov.b	v6[3], w17
	ubfx	w17, w14, #4, #1
	mov.b	v6[4], w17
	ubfx	w17, w14, #5, #1
	mov.b	v6[5], w17
	ubfx	w17, w14, #6, #1
	mov.b	v6[6], w17
	ldr	q5, [sp, #1744]
	str	q5, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1728]
	str	q5, [sp, #1088]                 ; 16-byte Folded Spill
	lsr	w14, w14, #7
	mov.b	v6[7], w14
	ldrb	w14, [x8, x13]
	and	w17, w14, #0x1
	fmov	s7, w17
	ubfx	w17, w14, #1, #1
	mov.b	v7[1], w17
	ubfx	w17, w14, #2, #1
	mov.b	v7[2], w17
	ubfx	w17, w14, #3, #1
	mov.b	v7[3], w17
	ubfx	w17, w14, #4, #1
	mov.b	v7[4], w17
	ubfx	w17, w14, #5, #1
	mov.b	v7[5], w17
	ubfx	w17, w14, #6, #1
	mov.b	v7[6], w17
	lsr	w14, w14, #7
	mov.b	v7[7], w14
	csetm	w14, ne
	dup.8b	v16, w14
	bit.8b	v6, v21, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	str	b6, [x27, x13]
	bic.8b	v6, v7, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	str	b6, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_377
; %bb.166:                              ; %ready.overflow.resume116
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b4, [x21, x28]
	mov	w9, #9                          ; =0x9
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	b.hs	LBB0_377
; %bb.167:                              ; %ready.overflow.resume118
                                        ;   in Loop: Header=BB0_4 Depth=1
	orr	w10, w11, w10
	zip2.8b	v4, v3, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v24, v28, v4
	zip1.8b	v3, v3, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	str	b1, [x21, w19, uxtw]
	ldr	q1, [sp, #336]                  ; 16-byte Folded Reload
	ldr	q4, [sp, #624]                  ; 16-byte Folded Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #336]                  ; 16-byte Folded Spill
	mov	w9, #10                         ; =0xa
	str	w9, [x22, w19, uxtw #2]
	str	w12, [x23, w19, uxtw #2]
	add	w26, w19, #1
	b	LBB0_3
LBB0_168:                               ; %varying.coherent111
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w13, s4
	tst	w13, #0xff
	b.eq	LBB0_175
LBB0_169:                               ; %schedule.9
                                        ;   in Loop: Header=BB0_4 Depth=1
	rbit	w13, w11
	clz	w13, w13
	tst	w11, #0xff
	csel	w13, wzr, w13, eq
	ldp	q1, q0, [sp, #864]              ; 32-byte Folded Reload
	str	q0, [sp, #4256]
	str	q1, [sp, #4272]
	ldp	q1, q0, [sp, #832]              ; 32-byte Folded Reload
	str	q0, [sp, #4288]
	str	q1, [sp, #4304]
	and	x14, x13, #0x7
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #160
	ldr	x14, [x9, x14, lsl #3]
	lsl	w13, w13, #2
	sub	x13, x14, x13
	ands	w11, w11, #0xff
	add	x13, x13, #256
	csel	x13, xzr, x13, eq
	add	x13, x15, x13
	ldp	q3, q1, [x13]
	zip1.8b	v4, v21, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v3, v4, v3
	zip2.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v1, v6, v1
	fmul.4s	v1, v1, v1
	fmul.4s	v3, v3, v3
	ldr	q5, [sp, #624]                  ; 16-byte Folded Reload
	fadd.4s	v3, v5, v3
	fadd.4s	v1, v28, v1
	bit.16b	v24, v1, v6
	ldr	q1, [sp, #336]                  ; 16-byte Folded Reload
	bit.16b	v1, v3, v4
	str	q1, [sp, #336]                  ; 16-byte Folded Spill
	cbz	w11, LBB0_3
LBB0_170:                               ; %schedule.10
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	x28, [sp, #136]                 ; 8-byte Folded Spill
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #128
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #96
	cbz	w12, LBB0_176
LBB0_171:                               ; %convergence.cascade126.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w13, #0                         ; =0x0
LBB0_172:                               ; %convergence.cascade126
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w2, s1
	sub	w14, w12, #1
	tst	w11, #0xff
	csel	w14, w14, wzr, ne
	lsl	w17, w20, w14
	and	w11, w17, w10
	tst	w11, #0xff
	cset	w4, ne
	ldr	q1, [sp, #1120]                 ; 16-byte Folded Reload
	str	q1, [sp, #4224]
	ldr	q1, [sp, #1136]                 ; 16-byte Folded Reload
	str	q1, [sp, #4240]
	ubfiz	x11, x14, #2, #3
	ldr	w1, [x16, x11]
	cmp	w1, #2
	cset	w1, eq
	and	w2, w4, w2
	ldrb	w4, [x27, w14, sxtw]
	and	w5, w4, #0x1
	fmov	s1, w5
	ubfx	w5, w4, #1, #1
	mov.b	v1[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v1[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v1[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v1[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v1[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v1[6], w5
	lsr	w4, w4, #7
	mov.b	v1[7], w4
	ldrb	w4, [x8, w14, sxtw]
	and	w5, w4, #0x1
	fmov	s3, w5
	ubfx	w5, w4, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v3[6], w5
	lsr	w4, w4, #7
	mov.b	v3[7], w4
	orr.8b	v4, v21, v3
	and.8b	v6, v12, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w4, s6
	ands	w1, w2, w1
	csetm	w2, ne
	bics	w4, w1, w4
	csetm	w5, ne
	dup.8b	v6, w5
	dup.8b	v7, w2
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	mov	w9, #-1                         ; =0xffffffff
	csinv	w14, w9, w17, eq
	dup.8b	v1, w1
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w4
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #4192]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #4208]
	ldr	w11, [x0, x11]
	csel	w12, w11, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w1, #1
	b.ne	LBB0_177
; %bb.173:                              ; %convergence.cascade126
                                        ;   in Loop: Header=BB0_172 Depth=2
	cmp	w12, #0
	ccmp	w13, #6, #2, ne
	b.hi	LBB0_177
; %bb.174:                              ; %convergence.cascade126
                                        ;   in Loop: Header=BB0_172 Depth=2
	add	w13, w13, #1
	tst	w11, #0xff
	b.ne	LBB0_172
	b	LBB0_177
LBB0_175:                               ; %varying.coherent.false120
                                        ;   in Loop: Header=BB0_4 Depth=1
	zip2.8b	v1, v21, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	bit.16b	v24, v28, v1
	zip1.8b	v1, v21, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #336]                  ; 16-byte Folded Reload
	ldr	q4, [sp, #624]                  ; 16-byte Folded Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #336]                  ; 16-byte Folded Spill
	str	x28, [sp, #136]                 ; 8-byte Folded Spill
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #128
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #96
	cbnz	w12, LBB0_171
LBB0_176:                               ; %schedule.10.convergence.cascade.exit127_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_177:                               ; %convergence.cascade.exit127
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_179
; %bb.178:                              ; %convergence.target.10.ready
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.16b	v19, v18
	fadd.4s	v1, v18, v24
	ldr	q3, [sp, #336]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	fadd.4s	v3, v0, v3
	ldr	q0, [sp, #784]                  ; 16-byte Folded Reload
	fadd.4s	v3, v0, v3
	ldr	q0, [sp, #432]                  ; 16-byte Folded Reload
	fadd.4s	v1, v0, v1
	ldr	q4, [sp, #544]                  ; 16-byte Folded Reload
	fadd.4s	v6, v4, v1
	ldr	q1, [sp, #528]                  ; 16-byte Folded Reload
	fadd.4s	v7, v1, v3
	uzp1.4s	v18, v27, v13
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	uzp1.4s	v5, v0, v26
	movi.4s	v4, #1
	eor.16b	v3, v18, v4
	mov.s	w13, v3[1]
	eor.16b	v4, v5, v4
	mov.s	w17, v3[2]
	mov.s	w2, v3[3]
	fmov	w14, s3
	cmp	w14, #8
	csel	w14, w14, wzr, lo
	cset	w4, lo
	and	x5, x14, #0x7
	add	x1, sp, #3608
	bfxil	x1, x14, #0, #3
	str	d21, [sp, #3608]
	ldrb	w14, [x1]
	umov.b	w15, v21[0]
	str	w15, [sp, #768]                 ; 4-byte Folded Spill
	and	w14, w4, w14
	str	q7, [sp, #4032]
	str	q6, [sp, #4048]
	add	x9, sp, #4032
	ldr	s3, [x9, x5, lsl #2]
	ands	w23, w15, #0x1
	tst	w23, w14
	str	q23, [sp, #704]                 ; 16-byte Folded Spill
	movi	d23, #0000000000000000
	fcsel	s3, s3, s23, ne
	cmp	w13, #8
	csel	w13, w13, wzr, lo
	cset	w4, lo
	and	x5, x13, #0x7
	add	x14, sp, #3608
	bfxil	x14, x13, #0, #3
	ldrb	w13, [x14]
	umov.b	w14, v21[1]
	str	w14, [sp, #752]                 ; 4-byte Folded Spill
	and	w13, w4, w13
	str	q7, [sp, #4000]
	str	q6, [sp, #4016]
	add	x9, sp, #4000
	ldr	s16, [x9, x5, lsl #2]
	mov	x15, x3
	mov	x3, x7
	ands	w7, w14, #0x1
	tst	w7, w13
	fcsel	s17, s16, s23, ne
	cmp	w17, #8
	csel	w13, w17, wzr, lo
	cset	w17, lo
	and	x4, x13, #0x7
	add	x5, sp, #3608
	bfxil	x5, x13, #0, #3
	ldrb	w13, [x5]
	umov.b	w5, v21[2]
	str	q7, [sp, #3968]
	str	q6, [sp, #3984]
	add	x9, sp, #3968
	ldr	s16, [x9, x4, lsl #2]
	and	w13, w17, w13
	mov	x14, x6
	ands	w6, w5, #0x1
	tst	w6, w13
	fcsel	s16, s16, s23, ne
	cmp	w2, #8
	csel	w17, w2, wzr, lo
	cset	w13, lo
	and	x4, x17, #0x7
	add	x2, sp, #3608
	bfxil	x2, x17, #0, #3
	umov.b	w1, v21[3]
	ldrb	w20, [x2]
	mov.s	w2, v4[1]
	mov.s	w17, v4[2]
	str	q7, [sp, #3936]
	str	q6, [sp, #3952]
	mov.s	w24, v4[3]
	fmov	w21, s4
	add	x9, sp, #3936
	ldr	s4, [x9, x4, lsl #2]
	and	w13, w13, w20
	ands	w4, w1, #0x1
	tst	w4, w13
	fcsel	s20, s4, s23, ne
	cmp	w21, #8
	csel	w13, w21, wzr, lo
	cset	w20, lo
	and	x21, x13, #0x7
	add	x22, sp, #3608
	bfxil	x22, x13, #0, #3
	umov.b	w30, v21[4]
	ldrb	w13, [x22]
	and	w20, w20, w13
	str	q7, [sp, #4160]
	str	q6, [sp, #4176]
	mov.s	v3[1], v17[0]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #64
	ldr	s4, [x9, x21, lsl #2]
	ands	w13, w30, #0x1
	tst	w13, w20
	fcsel	s4, s4, s23, ne
	cmp	w2, #8
	csel	w2, w2, wzr, lo
	cset	w20, lo
	and	x21, x2, #0x7
	add	x22, sp, #3608
	bfxil	x22, x2, #0, #3
	ldrb	w2, [x22]
	umov.b	w22, v21[5]
	and	w2, w20, w2
	mov.s	v3[2], v16[0]
	str	q7, [sp, #4128]
	str	q6, [sp, #4144]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #32
	ldr	s16, [x9, x21, lsl #2]
	ands	w21, w22, #0x1
	tst	w21, w2
	fcsel	s16, s16, s23, ne
	cmp	w17, #8
	csel	w17, w17, wzr, lo
	cset	w2, lo
	mov	x28, x25
	and	x25, x17, #0x7
	add	x20, sp, #3608
	bfxil	x20, x17, #0, #3
	ldrb	w17, [x20]
	umov.b	w20, v21[6]
	and	w17, w2, w17
	str	q7, [sp, #4096]
	str	q6, [sp, #4112]
	mov.s	v3[3], v20[0]
	add	x9, sp, #1, lsl #12             ; =4096
	ldr	s17, [x9, x25, lsl #2]
	ands	w2, w20, #0x1
	tst	w2, w17
	fcsel	s17, s17, s23, ne
	cmp	w24, #8
	csel	w17, w24, wzr, lo
	cset	w24, lo
	and	x25, x17, #0x7
	add	x16, sp, #3608
	bfxil	x16, x17, #0, #3
	ldrb	w16, [x16]
	umov.b	w17, v21[7]
	and	w16, w24, w16
	str	q7, [sp, #4064]
	str	q6, [sp, #4080]
	mov.s	v4[1], v16[0]
	add	x9, sp, #4064
	ldr	s16, [x9, x25, lsl #2]
	ands	w24, w17, #0x1
	tst	w24, w16
	fcsel	s20, s16, s23, ne
	stp	q25, q22, [sp, #720]            ; 32-byte Folded Spill
	stp	q26, q13, [sp, #672]            ; 32-byte Folded Spill
	str	q27, [sp, #896]                 ; 16-byte Folded Spill
	str	d12, [sp, #664]                 ; 8-byte Folded Spill
	str	q19, [sp, #352]                 ; 16-byte Folded Spill
	str	q29, [sp, #640]                 ; 16-byte Folded Spill
	mov.16b	v0, v24
	mov.16b	v24, v9
	str	q15, [sp, #512]                 ; 16-byte Folded Spill
	ldr	q13, [sp, #960]                 ; 16-byte Folded Reload
	ldr	q9, [sp, #912]                  ; 16-byte Folded Reload
	movi.4s	v19, #2
	eor.16b	v16, v18, v19
	mov.s	w16, v16[1]
	fmov	w25, s16
	cmp	w25, #8
	csel	w25, w25, wzr, lo
	cset	w0, lo
	add	x9, sp, #3608
	bfxil	x9, x25, #0, #3
	ldrb	w9, [x9]
	and	w9, w0, w9
	mov.s	v4[2], v17[0]
	mov.s	v4[3], v20[0]
	fadd.4s	v4, v6, v4
	fadd.4s	v3, v7, v3
	and	x0, x25, #0x7
	mov	x25, x28
	str	q3, [sp, #3904]
	str	q4, [sp, #3920]
	add	x28, sp, #3904
	ldr	s6, [x28, x0, lsl #2]
	tst	w23, w9
	fcsel	s6, s6, s23, ne
	cmp	w16, #8
	csel	w9, w16, wzr, lo
	cset	w16, lo
	add	x0, sp, #3608
	bfxil	x0, x9, #0, #3
	ldrb	w0, [x0]
	and	w16, w16, w0
	and	x9, x9, #0x7
	str	q3, [sp, #3872]
	str	q4, [sp, #3888]
	add	x0, sp, #3872
	ldr	s7, [x0, x9, lsl #2]
	mov.s	w9, v16[2]
	tst	w7, w16
	mov	x7, x3
	mov	x3, x15
	add	x15, sp, #1, lsl #12            ; =4096
	add	x15, x15, #968
	fcsel	s7, s7, s23, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w16, lo
	add	x0, sp, #3608
	bfxil	x0, x9, #0, #3
	ldrb	w0, [x0]
	and	w16, w16, w0
	and	x9, x9, #0x7
	str	q3, [sp, #3840]
	str	q4, [sp, #3856]
	add	x0, sp, #3840
	ldr	s17, [x0, x9, lsl #2]
	mov.s	w9, v16[3]
	tst	w6, w16
	mov	x6, x14
	fcsel	s16, s17, s23, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w16, lo
	add	x0, sp, #3608
	bfxil	x0, x9, #0, #3
	ldrb	w0, [x0]
	and	w16, w16, w0
	eor.16b	v19, v5, v19
	mov.16b	v17, v9
	mov.16b	v20, v0
	ldr	q29, [sp, #448]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	mov.16b	v9, v8
	mov.16b	v27, v17
	mov.16b	v5, v13
	ldr	q18, [sp, #640]                 ; 16-byte Folded Reload
	ldr	q15, [sp, #352]                 ; 16-byte Folded Reload
	ldr	d12, [sp, #664]                 ; 8-byte Folded Reload
	ldp	q25, q22, [sp, #720]            ; 32-byte Folded Reload
	ldr	q8, [sp, #896]                  ; 16-byte Folded Reload
	ldp	q26, q13, [sp, #672]            ; 32-byte Folded Reload
	and	x9, x9, #0x7
	str	q3, [sp, #3808]
	str	q4, [sp, #3824]
	add	x14, sp, #3808
	ldr	s1, [x14, x9, lsl #2]
	tst	w4, w16
	fcsel	s1, s1, s23, ne
	fmov	w9, s19
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w16, lo
	add	x0, sp, #3608
	bfxil	x0, x9, #0, #3
	ldrb	w0, [x0]
	and	w16, w16, w0
	mov.s	w0, v19[1]
	and	x9, x9, #0x7
	str	q3, [sp, #3776]
	str	q4, [sp, #3792]
	add	x14, sp, #3776
	ldr	s17, [x14, x9, lsl #2]
	mov.s	w9, v19[2]
	tst	w13, w16
	fcsel	s17, s17, s23, ne
	cmp	w0, #8
	csel	w13, w0, wzr, lo
	cset	w16, lo
	add	x0, sp, #3608
	bfxil	x0, x13, #0, #3
	ldrb	w0, [x0]
	and	w16, w16, w0
	mov.s	w0, v19[3]
	and	x13, x13, #0x7
	str	q3, [sp, #3744]
	str	q4, [sp, #3760]
	add	x14, sp, #3744
	ldr	s19, [x14, x13, lsl #2]
	tst	w21, w16
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #1336
	fcsel	s19, s19, s23, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w13, lo
	add	x16, sp, #3608
	bfxil	x16, x9, #0, #3
	ldrb	w16, [x16]
	and	w13, w13, w16
	and	x9, x9, #0x7
	str	q3, [sp, #3712]
	str	q4, [sp, #3728]
	mov.s	v17[1], v19[0]
	add	x14, sp, #3712
	ldr	s19, [x14, x9, lsl #2]
	tst	w2, w13
	fcsel	s19, s19, s23, ne
	mov.s	v17[2], v19[0]
	xtn.2s	v19, v8
	cmp	w0, #8
	csel	w9, w0, wzr, lo
	cset	w13, lo
	add	x16, sp, #3608
	bfxil	x16, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w16, [x16]
	and	w13, w13, w16
	str	q3, [sp, #3680]
	str	q4, [sp, #3696]
	fmov	w16, s19
	add	x14, sp, #3680
	ldr	s19, [x14, x9, lsl #2]
	tst	w24, w13
	adrp	x24, lCPI0_8@PAGE
	fcsel	s19, s19, s23, ne
	eor	w9, w16, #0x4
	cmp	w16, #8
	csel	w9, w9, wzr, lo
	cset	w13, lo
	add	x16, sp, #3608
	bfxil	x16, x9, #0, #3
	ldrb	w16, [x16]
	and	w13, w13, w16
	mov.s	v17[3], v19[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	tst	w23, w13
	add	x23, sp, #1, lsl #12            ; =4096
	add	x23, x23, #1272
	mov.s	v6[3], v1[0]
	fadd.4s	v1, v3, v6
	fadd.4s	v3, v4, v17
	and	x9, x9, #0x7
	str	q3, [sp, #3664]
	str	q1, [sp, #3648]
	add	x13, sp, #3648
	ldr	s3, [x13, x9, lsl #2]
	fcsel	s3, s3, s23, ne
	ldr	w9, [sp, #768]                  ; 4-byte Folded Reload
	tst	w9, #0x1
	fadd	s1, s1, s3
	fcsel	s1, s1, s23, ne
	ldr	w9, [sp, #752]                  ; 4-byte Folded Reload
	tst	w9, #0x1
	fcsel	s3, s1, s23, ne
	tst	w5, #0x1
	fcsel	s4, s1, s23, ne
	tst	w1, #0x1
	fcsel	s6, s1, s23, ne
	tst	w30, #0x1
	adrp	x30, lCPI0_10@PAGE
	fcsel	s7, s1, s23, ne
	tst	w22, #0x1
	fcsel	s16, s1, s23, ne
	tst	w20, #0x1
	mov	w20, #1                         ; =0x1
	fcsel	s17, s1, s23, ne
	tst	w17, #0x1
	fcsel	s19, s1, s23, ne
	mov.s	v1[1], v3[0]
	mov.s	v1[2], v4[0]
	mov.s	v1[3], v6[0]
	rbit	w9, w11
	clz	w9, w9
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v19[0]
	str	q7, [sp, #3632]
	str	q1, [sp, #3616]
	and	x9, x9, #0x7
	add	x11, sp, #3616
	ldr	s1, [x11, x9, lsl #2]
	fadd	s1, s1, s23
	ldr	q23, [sp, #704]                 ; 16-byte Folded Reload
	mov	w9, #1115815936                 ; =0x42820000
	fmov	s3, w9
	fdiv	s1, s1, s3
	dup.4s	v1, v1[0]
	zip2.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #240]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #240]                  ; 16-byte Folded Spill
	zip1.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #256]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #256]                  ; 16-byte Folded Spill
	mov	b1, v21[6]
	mov.b	v1[4], v21[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov	b3, v21[4]
	mov.b	v3[4], v21[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	mov	b4, v21[2]
	mov.b	v4[4], v21[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	mov	b6, v21[0]
	mov.b	v6[4], v21[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	ldr	q7, [x24, lCPI0_8@PAGEOFF]
	bit.16b	v0, v7, v1
	str	q0, [sp, #944]                  ; 16-byte Folded Spill
	ldr	q7, [x25, lCPI0_9@PAGEOFF]
	ldr	q0, [sp, #976]                  ; 16-byte Folded Reload
	bit.16b	v0, v7, v3
	str	q0, [sp, #976]                  ; 16-byte Folded Spill
	ldr	q7, [x30, lCPI0_10@PAGEOFF]
	bit.16b	v5, v7, v4
	str	q5, [sp, #960]                  ; 16-byte Folded Spill
Lloh20:
	adrp	x9, lCPI0_11@PAGE
Lloh21:
	ldr	q7, [x9, lCPI0_11@PAGEOFF]
	bit.16b	v27, v7, v6
	str	q27, [sp, #912]                 ; 16-byte Folded Spill
	mov.16b	v27, v8
	mov.16b	v8, v9
	mov.16b	v9, v24
	mov.16b	v24, v20
	movi.8b	v20, #1
	ldr	q7, [sp, #112]                  ; 16-byte Folded Reload
	ldr	q5, [sp, #496]                  ; 16-byte Folded Reload
	bit.16b	v5, v7, v1
	bic.16b	v22, v22, v1
	ldr	q1, [sp, #464]                  ; 16-byte Folded Reload
	bit.16b	v1, v7, v3
	bic.16b	v14, v14, v3
	bit.16b	v29, v7, v4
	stp	q29, q1, [sp, #448]             ; 32-byte Folded Spill
	mov.16b	v29, v18
	mov.16b	v18, v15
	ldr	q15, [sp, #512]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v4
	str	q0, [sp, #1040]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #480]                  ; 16-byte Folded Reload
	bit.16b	v1, v7, v6
	stp	q1, q5, [sp, #480]              ; 32-byte Folded Spill
	bic.16b	v25, v25, v6
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #1304
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #384
	mov	w5, #-1                         ; =0xffffffff
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #352
	add	x4, sp, #3568
	ldr	x28, [sp, #136]                 ; 8-byte Folded Reload
	b	LBB0_180
LBB0_179:                               ;   in Loop: Header=BB0_4 Depth=1
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #1304
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #384
	mov	w5, #-1                         ; =0xffffffff
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #352
	add	x4, sp, #3568
	b	LBB0_3
LBB0_180:                               ; %schedule.11
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	mov	w9, #8                          ; =0x8
	dup.2d	v3, x9
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	cmgt.2d	v1, v3, v0
	cmgt.2d	v4, v3, v25
	uzp1.4s	v1, v4, v1
	cmgt.2d	v4, v3, v14
	cmgt.2d	v6, v3, v22
	uzp1.4s	v4, v4, v6
	uzp1.8h	v1, v1, v4
	xtn.8b	v1, v1
	and.8b	v1, v21, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v4, v1, #0
	and.8b	v1, v4, v2
	addv.8b	b1, v1
	fmov	w13, s1
	umaxv.8b	b4, v4
	fmov	w14, s4
	tbz	w14, #0, LBB0_187
; %bb.181:                              ; %schedule.11
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	cmge.2d	v4, v0, v3
	cmge.2d	v6, v25, v3
	uzp1.4s	v4, v6, v4
	cmge.2d	v6, v14, v3
	cmge.2d	v3, v22, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v3, v21, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w14, s3
	tst	w14, #0xff
	b.eq	LBB0_187
; %bb.182:                              ; %varying.divergent152
                                        ;   in Loop: Header=BB0_4 Depth=1
	subs	w9, w12, #1
	csel	w9, wzr, w9, lo
	and	w13, w10, #0xff
	lsr	w11, w13, w9
	tst	w11, #0x1
	ldr	q4, [sp, #1120]                 ; 16-byte Folded Reload
	str	q4, [sp, #2016]
	ldr	q4, [sp, #1136]                 ; 16-byte Folded Reload
	str	q4, [sp, #2032]
	and	x9, x9, #0x7
	add	x11, sp, #2016
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w9, #3, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_184
; %bb.183:                              ; %varying.divergent152
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w11, #0, LBB0_377
LBB0_184:                               ; %convergence.overflow.resume155
                                        ;   in Loop: Header=BB0_4 Depth=1
	mvn	w9, w10
	rbit	w9, w9
	clz	w9, w9
	mov	w13, #255                       ; =0xff
	bics	wzr, w13, w10
	csel	w13, wzr, w9, eq
	ubfiz	x9, x13, #2, #3
	lsl	w14, w20, w13
	ldr	q5, [sp, #1120]                 ; 16-byte Folded Reload
	str	q5, [sp, #1984]
	ldr	q4, [sp, #1136]                 ; 16-byte Folded Reload
	str	q4, [sp, #2000]
	add	x16, sp, #1984
	ldr	w16, [x16, x9]
	cmp	w11, #0
	csel	w11, w14, wzr, ne
	mov	w14, #3                         ; =0x3
	csel	w14, w14, w16, ne
	str	q5, [sp, #1952]
	str	q4, [sp, #1968]
	add	x16, sp, #1952
	str	w14, [x16, x9]
	ldr	q4, [sp, #1968]
	str	q4, [sp, #1136]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #1952]
	str	q4, [sp, #1120]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	str	q5, [sp, #1920]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #1936]
	add	x14, sp, #1920
	ldr	w14, [x14, x9]
	csel	w14, w12, w14, ne
	str	q5, [sp, #1888]
	str	q4, [sp, #1904]
	add	x16, sp, #1888
	str	w14, [x16, x9]
	ldrb	w9, [x27, x13]
	and	w14, w9, #0x1
	fmov	s4, w14
	ubfx	w14, w9, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v4[6], w14
	ldr	q5, [sp, #1904]
	str	q5, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1888]
	str	q5, [sp, #1088]                 ; 16-byte Folded Spill
	lsr	w9, w9, #7
	mov.b	v4[7], w9
	ldrb	w9, [x8, x13]
	and	w14, w9, #0x1
	fmov	s6, w14
	ubfx	w14, w9, #1, #1
	mov.b	v6[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v6[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v6[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v6[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v6[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v6[6], w14
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	csetm	w9, ne
	dup.8b	v7, w9
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x27, x13]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_377
; %bb.185:                              ; %ready.overflow.resume157
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b1, [x21, x28]
	mov	w9, #12                         ; =0xc
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #352
	b.hs	LBB0_377
; %bb.186:                              ; %ready.overflow.resume159
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b3, [x21, w19, uxtw]
	orr	w10, w11, w10
	mov	w9, #13                         ; =0xd
	b	LBB0_73
LBB0_187:                               ; %varying.coherent153
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_222
; %bb.188:                              ; %varying.coherent.true160
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_3
LBB0_189:                               ; %schedule.12
                                        ;   in Loop: Header=BB0_4 Depth=1
	rbit	w13, w11
	clz	w13, w13
	tst	w11, #0xff
	csel	w13, wzr, w13, eq
	str	q25, [sp, #2112]
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	str	q0, [sp, #2128]
	str	q14, [sp, #2144]
	str	q22, [sp, #2160]
	ubfiz	x14, x13, #3, #3
	add	x9, sp, #2112
	ldr	x17, [x9, x14]
	str	q27, [sp, #2048]
	str	q13, [sp, #2064]
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	str	q0, [sp, #2080]
	str	q26, [sp, #2096]
	add	x9, sp, #2048
	ldr	x14, [x9, x14]
	sub	x13, x14, x13
	add	x14, x7, x17, lsl #5
	add	x13, x14, x13, lsl #2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b4, v1
	fmov	w14, s4
	movi.2d	v3, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w14, #0, LBB0_197
; %bb.190:                              ; %cond.load298
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s3, [x13]
	tbnz	w14, #1, LBB0_198
LBB0_191:                               ; %else302
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #2, LBB0_199
LBB0_192:                               ; %cond.load304
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x13, #8
	ld1.s	{ v3 }[2], [x17]
	tbnz	w14, #3, LBB0_200
LBB0_193:                               ; %else308
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #4, LBB0_201
LBB0_194:                               ; %cond.load310
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x13, #16
	ld1.s	{ v1 }[0], [x17]
	tbnz	w14, #5, LBB0_202
LBB0_195:                               ; %else314
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #6, LBB0_203
LBB0_196:                               ; %cond.load316
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x13, #24
	ld1.s	{ v1 }[2], [x17]
	tbnz	w14, #7, LBB0_204
	b	LBB0_205
LBB0_197:                               ; %else299
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #1, LBB0_191
LBB0_198:                               ; %cond.load301
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x13, #4
	ld1.s	{ v3 }[1], [x17]
	tbnz	w14, #2, LBB0_192
LBB0_199:                               ; %else305
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #3, LBB0_193
LBB0_200:                               ; %cond.load307
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x13, #12
	ld1.s	{ v3 }[3], [x17]
	tbnz	w14, #4, LBB0_194
LBB0_201:                               ; %else311
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #5, LBB0_195
LBB0_202:                               ; %cond.load313
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x13, #20
	ld1.s	{ v1 }[1], [x17]
	tbnz	w14, #6, LBB0_196
LBB0_203:                               ; %else317
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #7, LBB0_205
LBB0_204:                               ; %cond.load319
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x13, #28
	ld1.s	{ v1 }[3], [x13]
LBB0_205:                               ; %else320
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.2d	v6, v25, #5
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	shl.2d	v7, v0, #5
	shl.2d	v17, v14, #5
	shl.2d	v19, v22, #5
	ldr	q5, [sp, #480]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #912]                  ; 16-byte Folded Reload
	add.2d	v16, v5, v0
	add.2d	v16, v16, v6
	ldr	q0, [sp, #960]                  ; 16-byte Folded Reload
	ldr	q5, [sp, #448]                  ; 16-byte Folded Reload
	add.2d	v6, v5, v0
	add.2d	v7, v6, v7
	ldr	q5, [sp, #464]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #976]                  ; 16-byte Folded Reload
	add.2d	v6, v5, v0
	add.2d	v6, v6, v17
	ldr	q5, [sp, #496]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	add.2d	v17, v5, v0
	fmov	w13, s4
	add.2d	v4, v17, v19
	tbz	w13, #0, LBB0_213
; %bb.206:                              ; %cond.store
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d16
	str	s3, [x14]
	tbnz	w13, #1, LBB0_214
LBB0_207:                               ; %else327
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #2, LBB0_215
LBB0_208:                               ; %cond.store328
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d7
	st1.s	{ v3 }[2], [x14]
	tbnz	w13, #3, LBB0_216
LBB0_209:                               ; %else333
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #4, LBB0_217
LBB0_210:                               ; %cond.store334
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d6
	str	s1, [x14]
	tbnz	w13, #5, LBB0_218
LBB0_211:                               ; %else339
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #6, LBB0_219
LBB0_212:                               ; %cond.store340
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x14, d4
	st1.s	{ v1 }[2], [x14]
	tbnz	w13, #7, LBB0_220
	b	LBB0_221
LBB0_213:                               ; %else324
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #1, LBB0_207
LBB0_214:                               ; %cond.store325
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v16[1]
	st1.s	{ v3 }[1], [x14]
	tbnz	w13, #2, LBB0_208
LBB0_215:                               ; %else330
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #3, LBB0_209
LBB0_216:                               ; %cond.store331
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v7[1]
	st1.s	{ v3 }[3], [x14]
	tbnz	w13, #4, LBB0_210
LBB0_217:                               ; %else336
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #5, LBB0_211
LBB0_218:                               ; %cond.store337
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x14, v6[1]
	st1.s	{ v1 }[1], [x14]
	tbnz	w13, #6, LBB0_212
LBB0_219:                               ; %else342
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #7, LBB0_221
LBB0_220:                               ; %cond.store343
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x13, v4[1]
	st1.s	{ v1 }[3], [x13]
LBB0_221:                               ; %else345
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v1, v21, v20
	ushll.8h	v1, v1, #0
	ushll.4s	v3, v1, #0
	ushll2.4s	v1, v1, #0
	uaddw2.2d	v22, v22, v1
	uaddw.2d	v14, v14, v1
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	uaddw2.2d	v0, v0, v3
	str	q0, [sp, #1040]                 ; 16-byte Folded Spill
	uaddw.2d	v25, v25, v3
	tst	w11, #0xff
	b.ne	LBB0_180
	b	LBB0_3
LBB0_222:                               ; %varying.coherent.false161
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_3
LBB0_223:                               ; %schedule.13
                                        ;   in Loop: Header=BB0_4 Depth=1
	cbz	w12, LBB0_228
; %bb.224:                              ; %convergence.cascade172.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w13, #0                         ; =0x0
LBB0_225:                               ; %convergence.cascade172
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w16, s1
	sub	w11, w12, #1
	tst	w9, #0xff
	csel	w14, w11, wzr, ne
	lsl	w17, w20, w14
	and	w9, w17, w10
	tst	w9, #0xff
	cset	w9, ne
	ldr	q1, [sp, #1120]                 ; 16-byte Folded Reload
	str	q1, [sp, #3568]
	ldr	q1, [sp, #1136]                 ; 16-byte Folded Reload
	str	q1, [sp, #3584]
	ubfiz	x11, x14, #2, #3
	ldr	w0, [x4, x11]
	cmp	w0, #3
	cset	w1, eq
	and	w2, w9, w16
	ldrb	w9, [x27, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s1, w16
	ubfx	w16, w9, #1, #1
	mov.b	v1[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v1[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v1[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v1[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v1[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v1[6], w16
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s3, w16
	ubfx	w16, w9, #1, #1
	mov.b	v3[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v3[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v3[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v3[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v3[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v3[6], w16
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v21, v3
	and.8b	v6, v12, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w9, s6
	ands	w16, w2, w1
	csetm	w0, ne
	bics	w9, w16, w9
	csetm	w1, ne
	dup.8b	v6, w1
	dup.8b	v7, w0
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	csinv	w14, w5, w17, eq
	dup.8b	v1, w16
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #3536]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #3552]
	add	x9, sp, #3536
	ldr	w9, [x9, x11]
	csel	w12, w9, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w16, #1
	b.ne	LBB0_229
; %bb.226:                              ; %convergence.cascade172
                                        ;   in Loop: Header=BB0_225 Depth=2
	cmp	w12, #0
	ccmp	w13, #6, #2, ne
	b.hi	LBB0_229
; %bb.227:                              ; %convergence.cascade172
                                        ;   in Loop: Header=BB0_225 Depth=2
	add	w13, w13, #1
	tst	w11, #0xff
	b.ne	LBB0_225
	b	LBB0_229
LBB0_228:                               ; %schedule.13.convergence.cascade.exit173_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_229:                               ; %convergence.cascade.exit173
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_2
; %bb.230:                              ; %convergence.target.13.ready
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v1, v15, v21
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	and.8b	v1, v3, v2
	addv.8b	b1, v1
	umaxv.8b	b3, v3
	fmov	w9, s3
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #384
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #352
	tbz	w9, #0, LBB0_237
; %bb.231:                              ; %convergence.target.13.ready
                                        ;   in Loop: Header=BB0_4 Depth=1
	bic.8b	v3, v21, v15
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w9, s3
	tst	w9, #0xff
	b.eq	LBB0_237
; %bb.232:                              ; %varying.divergent190
                                        ;   in Loop: Header=BB0_4 Depth=1
	subs	w9, w12, #1
	csel	w9, wzr, w9, lo
	and	w13, w10, #0xff
	lsr	w11, w13, w9
	tst	w11, #0x1
	ldr	q4, [sp, #1120]                 ; 16-byte Folded Reload
	str	q4, [sp, #2304]
	ldr	q4, [sp, #1136]                 ; 16-byte Folded Reload
	str	q4, [sp, #2320]
	and	x9, x9, #0x7
	add	x11, sp, #2304
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w9, #4, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_234
; %bb.233:                              ; %varying.divergent190
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w11, #0, LBB0_377
LBB0_234:                               ; %convergence.overflow.resume193
                                        ;   in Loop: Header=BB0_4 Depth=1
	mvn	w9, w10
	rbit	w9, w9
	clz	w9, w9
	mov	w13, #255                       ; =0xff
	bics	wzr, w13, w10
	csel	w13, wzr, w9, eq
	ubfiz	x9, x13, #2, #3
	lsl	w14, w20, w13
	ldr	q5, [sp, #1120]                 ; 16-byte Folded Reload
	str	q5, [sp, #2272]
	ldr	q4, [sp, #1136]                 ; 16-byte Folded Reload
	str	q4, [sp, #2288]
	add	x16, sp, #2272
	ldr	w16, [x16, x9]
	cmp	w11, #0
	csel	w11, w14, wzr, ne
	mov	w14, #4                         ; =0x4
	csel	w14, w14, w16, ne
	str	q5, [sp, #2240]
	str	q4, [sp, #2256]
	add	x16, sp, #2240
	str	w14, [x16, x9]
	ldr	q4, [sp, #2256]
	str	q4, [sp, #1136]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #2240]
	str	q4, [sp, #1120]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	str	q5, [sp, #2208]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #2224]
	add	x14, sp, #2208
	ldr	w14, [x14, x9]
	csel	w14, w12, w14, ne
	str	q5, [sp, #2176]
	str	q4, [sp, #2192]
	add	x16, sp, #2176
	str	w14, [x16, x9]
	ldrb	w9, [x27, x13]
	and	w14, w9, #0x1
	fmov	s4, w14
	ubfx	w14, w9, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v4[6], w14
	ldr	q5, [sp, #2192]
	str	q5, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #2176]
	str	q5, [sp, #1088]                 ; 16-byte Folded Spill
	lsr	w9, w9, #7
	mov.b	v4[7], w9
	ldrb	w9, [x8, x13]
	and	w14, w9, #0x1
	fmov	s6, w14
	ubfx	w14, w9, #1, #1
	mov.b	v6[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v6[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v6[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v6[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v6[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v6[6], w14
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	csetm	w9, ne
	dup.8b	v7, w9
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x27, x13]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_377
; %bb.235:                              ; %ready.overflow.resume195
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b1, [x21, x28]
	mov	w9, #14                         ; =0xe
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #352
	b.hs	LBB0_377
; %bb.236:                              ; %ready.overflow.resume197
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b3, [x21, w19, uxtw]
	orr	w10, w11, w10
	mov	w9, #15                         ; =0xf
	b	LBB0_73
LBB0_237:                               ; %varying.coherent191
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w9, s1
	tst	w9, #0xff
	b.eq	LBB0_255
LBB0_238:                               ; %schedule.14
                                        ;   in Loop: Header=BB0_4 Depth=1
	rbit	w13, w11
	clz	w13, w13
	tst	w11, #0xff
	csel	w13, wzr, w13, eq
	str	q27, [sp, #3472]
	str	q13, [sp, #3488]
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	str	q0, [sp, #3504]
	str	q26, [sp, #3520]
	and	x14, x13, #0x7
	add	x9, sp, #3472
	ldr	x14, [x9, x14, lsl #3]
	sub	x14, x14, x13
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	add	x14, x9, x14, lsl #2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w17, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w17, #0, LBB0_246
; %bb.239:                              ; %cond.load347
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s1, [x14]
	tbnz	w17, #1, LBB0_247
LBB0_240:                               ; %else351
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #2, LBB0_248
LBB0_241:                               ; %cond.load353
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x1, x14, #8
	ld1.s	{ v1 }[2], [x1]
	tbnz	w17, #3, LBB0_249
LBB0_242:                               ; %else357
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #4, LBB0_250
LBB0_243:                               ; %cond.load359
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x1, x14, #16
	ld1.s	{ v3 }[0], [x1]
	tbnz	w17, #5, LBB0_251
LBB0_244:                               ; %else363
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #6, LBB0_252
LBB0_245:                               ; %cond.load365
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x1, x14, #24
	ld1.s	{ v3 }[2], [x1]
	tbnz	w17, #7, LBB0_253
	b	LBB0_254
LBB0_246:                               ; %else348
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #1, LBB0_240
LBB0_247:                               ; %cond.load350
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x1, x14, #4
	ld1.s	{ v1 }[1], [x1]
	tbnz	w17, #2, LBB0_241
LBB0_248:                               ; %else354
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #3, LBB0_242
LBB0_249:                               ; %cond.load356
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x1, x14, #12
	ld1.s	{ v1 }[3], [x1]
	tbnz	w17, #4, LBB0_243
LBB0_250:                               ; %else360
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #5, LBB0_244
LBB0_251:                               ; %cond.load362
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x1, x14, #20
	ld1.s	{ v3 }[1], [x1]
	tbnz	w17, #6, LBB0_245
LBB0_252:                               ; %else366
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #7, LBB0_254
LBB0_253:                               ; %cond.load368
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x14, x14, #28
	ld1.s	{ v3 }[3], [x14]
LBB0_254:                               ; %else369
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q0, [sp, #912]                  ; 16-byte Folded Reload
	str	q0, [sp, #3408]
	ldp	q4, q0, [sp, #960]              ; 32-byte Folded Reload
	str	q4, [sp, #3424]
	str	q0, [sp, #3440]
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	str	q0, [sp, #3456]
	and	x14, x13, #0x7
	add	x9, sp, #3408
	ldr	x14, [x9, x14, lsl #3]
	sub	x13, x14, x13, lsl #2
	add	x13, x13, #256
	ands	w11, w11, #0xff
	csel	x13, xzr, x13, eq
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #680
	add	x13, x9, x13
	ldp	q4, q6, [x13]
	zip2.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bif.16b	v3, v6, v7
	zip1.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bif.16b	v1, v4, v6
	stp	q1, q3, [x13]
	cbz	w11, LBB0_3
LBB0_255:                               ; %schedule.15
                                        ;   in Loop: Header=BB0_4 Depth=1
	cbz	w12, LBB0_260
; %bb.256:                              ; %convergence.cascade209.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w11, #0                         ; =0x0
LBB0_257:                               ; %convergence.cascade209
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w16, s1
	sub	w13, w12, #1
	tst	w9, #0xff
	csel	w14, w13, wzr, ne
	lsl	w17, w20, w14
	and	w9, w17, w10
	tst	w9, #0xff
	cset	w9, ne
	ldr	q1, [sp, #1120]                 ; 16-byte Folded Reload
	str	q1, [sp, #3376]
	ldr	q1, [sp, #1136]                 ; 16-byte Folded Reload
	str	q1, [sp, #3392]
	ubfiz	x13, x14, #2, #3
	add	x0, sp, #3376
	ldr	w0, [x0, x13]
	cmp	w0, #4
	cset	w1, eq
	and	w2, w9, w16
	ldrb	w9, [x27, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s1, w16
	ubfx	w16, w9, #1, #1
	mov.b	v1[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v1[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v1[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v1[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v1[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v1[6], w16
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s3, w16
	ubfx	w16, w9, #1, #1
	mov.b	v3[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v3[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v3[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v3[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v3[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v3[6], w16
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v21, v3
	and.8b	v6, v12, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w9, s6
	ands	w16, w2, w1
	csetm	w0, ne
	bics	w9, w16, w9
	csetm	w1, ne
	dup.8b	v6, w1
	dup.8b	v7, w0
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	csinv	w14, w5, w17, eq
	dup.8b	v1, w16
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #3344]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #3360]
	add	x9, sp, #3344
	ldr	w9, [x9, x13]
	csel	w12, w9, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
	cmp	w16, #1
	b.ne	LBB0_261
; %bb.258:                              ; %convergence.cascade209
                                        ;   in Loop: Header=BB0_257 Depth=2
	cmp	w12, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_261
; %bb.259:                              ; %convergence.cascade209
                                        ;   in Loop: Header=BB0_257 Depth=2
	add	w11, w11, #1
	tst	w13, #0xff
	b.ne	LBB0_257
	b	LBB0_261
LBB0_260:                               ; %schedule.15.convergence.cascade.exit210_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
LBB0_261:                               ; %convergence.cascade.exit210
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_2
; %bb.262:                              ; %convergence.target.15.ready
                                        ;   in Loop: Header=BB0_4 Depth=1
	rbit	w9, w13
	clz	w9, w9
	ldp	q1, q0, [sp, #240]              ; 32-byte Folded Reload
	str	q0, [sp, #3312]
	str	q1, [sp, #3328]
	and	x9, x9, #0x7
	add	x11, sp, #3312
	ldr	s1, [x11, x9, lsl #2]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s3, w9
	fadd	s1, s1, s3
	fsqrt	s1, s1
	dup.4s	v1, v1[0]
	zip2.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #816]                  ; 16-byte Folded Reload
	bit.16b	v0, v1, v3
	str	q0, [sp, #816]                  ; 16-byte Folded Spill
	zip1.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #800]                  ; 16-byte Folded Reload
	bit.16b	v0, v1, v3
	str	q0, [sp, #800]                  ; 16-byte Folded Spill
	mov	b1, v21[6]
	mov.b	v1[4], v21[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	and.16b	v0, v1, v0
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	mov	b1, v21[4]
	mov.b	v1[4], v21[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	mov	b3, v21[2]
	mov.b	v3[4], v21[3]
	ldr	q0, [sp, #1056]                 ; 16-byte Folded Reload
	and.16b	v0, v1, v0
	str	q0, [sp, #1056]                 ; 16-byte Folded Spill
	ushll.2d	v1, v3, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	and.16b	v0, v1, v0
	str	q0, [sp, #1008]                 ; 16-byte Folded Spill
	mov	b1, v21[0]
	mov.b	v1[4], v21[1]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v23, v1, v23
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #384
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #352
LBB0_263:                               ; %schedule.16
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	mov	w9, #8                          ; =0x8
	dup.2d	v3, x9
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	cmgt.2d	v1, v3, v0
	cmgt.2d	v4, v3, v23
	uzp1.4s	v1, v4, v1
	ldr	q0, [sp, #1056]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v3, v0
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	cmgt.2d	v6, v3, v0
	uzp1.4s	v4, v4, v6
	uzp1.8h	v1, v1, v4
	xtn.8b	v1, v1
	and.8b	v1, v21, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v4, v1, #0
	and.8b	v1, v4, v2
	addv.8b	b1, v1
	fmov	w13, s1
	umaxv.8b	b4, v4
	fmov	w14, s4
	tbz	w14, #0, LBB0_270
; %bb.264:                              ; %schedule.16
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	cmge.2d	v4, v0, v3
	cmge.2d	v6, v23, v3
	uzp1.4s	v4, v6, v4
	ldr	q0, [sp, #1056]                 ; 16-byte Folded Reload
	cmge.2d	v6, v0, v3
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	cmge.2d	v3, v0, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v3, v21, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w14, s3
	tst	w14, #0xff
	b.eq	LBB0_270
; %bb.265:                              ; %varying.divergent230
                                        ;   in Loop: Header=BB0_4 Depth=1
	subs	w9, w12, #1
	csel	w9, wzr, w9, lo
	and	w13, w10, #0xff
	lsr	w11, w13, w9
	tst	w11, #0x1
	ldr	q4, [sp, #1120]                 ; 16-byte Folded Reload
	str	q4, [sp, #2464]
	ldr	q4, [sp, #1136]                 ; 16-byte Folded Reload
	str	q4, [sp, #2480]
	and	x9, x9, #0x7
	add	x11, sp, #2464
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w9, #5, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_267
; %bb.266:                              ; %varying.divergent230
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w11, #0, LBB0_377
LBB0_267:                               ; %convergence.overflow.resume233
                                        ;   in Loop: Header=BB0_4 Depth=1
	mvn	w9, w10
	rbit	w9, w9
	clz	w9, w9
	mov	w13, #255                       ; =0xff
	bics	wzr, w13, w10
	csel	w13, wzr, w9, eq
	ubfiz	x9, x13, #2, #3
	lsl	w14, w20, w13
	ldr	q5, [sp, #1120]                 ; 16-byte Folded Reload
	str	q5, [sp, #2432]
	ldr	q4, [sp, #1136]                 ; 16-byte Folded Reload
	str	q4, [sp, #2448]
	add	x16, sp, #2432
	ldr	w16, [x16, x9]
	cmp	w11, #0
	csel	w11, w14, wzr, ne
	mov	w14, #5                         ; =0x5
	csel	w14, w14, w16, ne
	str	q5, [sp, #2400]
	str	q4, [sp, #2416]
	add	x16, sp, #2400
	str	w14, [x16, x9]
	ldr	q4, [sp, #2416]
	str	q4, [sp, #1136]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #2400]
	str	q4, [sp, #1120]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	str	q5, [sp, #2368]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #2384]
	add	x14, sp, #2368
	ldr	w14, [x14, x9]
	csel	w14, w12, w14, ne
	str	q5, [sp, #2336]
	str	q4, [sp, #2352]
	add	x16, sp, #2336
	str	w14, [x16, x9]
	ldrb	w9, [x27, x13]
	and	w14, w9, #0x1
	fmov	s4, w14
	ubfx	w14, w9, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v4[6], w14
	ldr	q5, [sp, #2352]
	str	q5, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #2336]
	str	q5, [sp, #1088]                 ; 16-byte Folded Spill
	lsr	w9, w9, #7
	mov.b	v4[7], w9
	ldrb	w9, [x8, x13]
	and	w14, w9, #0x1
	fmov	s6, w14
	ubfx	w14, w9, #1, #1
	mov.b	v6[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v6[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v6[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v6[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v6[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v6[6], w14
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	csetm	w9, ne
	dup.8b	v7, w9
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x27, x13]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_377
; %bb.268:                              ; %ready.overflow.resume235
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b1, [x21, x28]
	mov	w9, #17                         ; =0x11
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #352
	b.hs	LBB0_377
; %bb.269:                              ; %ready.overflow.resume237
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b3, [x21, w19, uxtw]
	orr	w10, w11, w10
	mov	w9, #18                         ; =0x12
	b	LBB0_73
LBB0_270:                               ; %varying.coherent231
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_321
; %bb.271:                              ; %varying.coherent.true238
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_3
LBB0_272:                               ; %schedule.17
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	q18, [sp, #352]                 ; 16-byte Folded Spill
	str	q29, [sp, #640]                 ; 16-byte Folded Spill
	str	d12, [sp, #664]                 ; 8-byte Folded Spill
	stp	q22, q24, [sp, #736]            ; 32-byte Folded Spill
	ldr	q1, [sp, #1008]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1056]                 ; 16-byte Folded Reload
	str	q14, [sp, #768]                 ; 16-byte Folded Spill
	stp	q23, q25, [sp, #704]            ; 32-byte Folded Spill
	str	q27, [sp, #896]                 ; 16-byte Folded Spill
	stp	q26, q13, [sp, #672]            ; 32-byte Folded Spill
	mov.16b	v27, v11
	mov.16b	v11, v15
	mov.16b	v15, v10
	ldr	q7, [sp, #1072]                 ; 16-byte Folded Reload
	mov.16b	v0, v8
	rbit	w13, w11
	clz	w13, w13
	tst	w11, #0xff
	csel	w14, wzr, w13, eq
	shl.2d	v3, v23, #5
	shl.2d	v4, v1, #5
	shl.2d	v6, v5, #5
	shl.2d	v7, v7, #5
	ldr	q1, [sp, #416]                  ; 16-byte Folded Reload
	ldp	q16, q5, [sp, #864]             ; 32-byte Folded Reload
	add.2d	v1, v1, v5
	add.2d	v25, v1, v3
	ldr	q1, [sp, #400]                  ; 16-byte Folded Reload
	add.2d	v1, v1, v16
	add.2d	v23, v1, v4
	ldr	q1, [sp, #384]                  ; 16-byte Folded Reload
	ldp	q16, q5, [sp, #832]             ; 32-byte Folded Reload
	add.2d	v1, v1, v5
	add.2d	v20, v1, v6
	ldr	q1, [sp, #368]                  ; 16-byte Folded Reload
	add.2d	v1, v1, v16
	add.2d	v19, v1, v7
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
	movi.2d	v17, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbz	w13, #0, LBB0_278
; %bb.273:                              ; %cond.load372
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x17, d25
	ldr	s17, [x17]
	tbnz	w13, #1, LBB0_279
LBB0_274:                               ; %else382
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #2, LBB0_280
LBB0_275:                               ; %cond.load384
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x17, d23
	ld1.s	{ v17 }[2], [x17]
	tbnz	w13, #3, LBB0_281
LBB0_276:                               ; %else394
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #4, LBB0_282
LBB0_277:                               ; %cond.load396
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x17, d20
	ld1.s	{ v16 }[0], [x17]
	mov.16b	v10, v15
	mov.16b	v8, v0
	tbnz	w13, #5, LBB0_283
	b	LBB0_284
LBB0_278:                               ; %else376
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #1, LBB0_274
LBB0_279:                               ; %cond.load378
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x17, v25[1]
	ld1.s	{ v17 }[1], [x17]
	tbnz	w13, #2, LBB0_275
LBB0_280:                               ; %else388
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #3, LBB0_276
LBB0_281:                               ; %cond.load390
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x17, v23[1]
	ld1.s	{ v17 }[3], [x17]
	tbnz	w13, #4, LBB0_277
LBB0_282:                               ; %else400
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.16b	v10, v15
	mov.16b	v8, v0
	tbz	w13, #5, LBB0_284
LBB0_283:                               ; %cond.load402
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x17, v20[1]
	ld1.s	{ v16 }[1], [x17]
LBB0_284:                               ; %else406
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q29, [sp, #640]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	ldr	q18, [sp, #352]                 ; 16-byte Folded Reload
	str	q0, [sp, #928]                  ; 16-byte Folded Spill
	mov.16b	v0, v11
	ldr	d12, [sp, #664]                 ; 8-byte Folded Reload
	tbz	w13, #6, LBB0_286
; %bb.285:                              ; %cond.load408
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x17, d19
	ld1.s	{ v16 }[2], [x17]
LBB0_286:                               ; %else412
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q11, [sp, #896]                 ; 16-byte Folded Reload
	ldp	q24, q14, [sp, #752]            ; 32-byte Folded Reload
	ldr	q22, [sp, #736]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #688]                 ; 16-byte Folded Reload
	tbz	w13, #7, LBB0_288
; %bb.287:                              ; %cond.load414
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x13, v19[1]
	ld1.s	{ v16 }[3], [x13]
LBB0_288:                               ; %else418
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q5, [sp, #800]                  ; 16-byte Folded Reload
	str	q5, [sp, #2688]
	ldr	q5, [sp, #816]                  ; 16-byte Folded Reload
	str	q5, [sp, #2704]
	and	x13, x14, #0x7
	add	x9, sp, #2688
	add	x13, x9, x13, lsl #2
	ld1r.4s	{ v19 }, [x13]
	fdiv.4s	v16, v16, v19
	fdiv.4s	v17, v17, v19
	ldr	q5, [sp, #944]                  ; 16-byte Folded Reload
	add.2d	v23, v7, v5
	ldp	q5, q7, [sp, #960]              ; 32-byte Folded Reload
	add.2d	v6, v6, v7
	add.2d	v4, v4, v5
	ldr	q5, [sp, #912]                  ; 16-byte Folded Reload
	add.2d	v3, v3, v5
	ldr	q5, [sp, #480]                  ; 16-byte Folded Reload
	add.2d	v20, v5, v3
	ldp	q5, q3, [sp, #448]              ; 32-byte Folded Reload
	add.2d	v19, v5, v4
	add.2d	v7, v3, v6
	ldr	q3, [sp, #496]                  ; 16-byte Folded Reload
	add.2d	v6, v3, v23
	fmov	w13, s1
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	ldr	q26, [sp, #672]                 ; 16-byte Folded Reload
	tbz	w13, #0, LBB0_296
; %bb.289:                              ; %cond.load421
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x17, d20
	ldr	s3, [x17]
	ldr	q23, [sp, #704]                 ; 16-byte Folded Reload
	tbnz	w13, #1, LBB0_297
LBB0_290:                               ; %else431
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	movi.8b	v20, #1
	mov.16b	v5, v11
	tbz	w13, #2, LBB0_298
LBB0_291:                               ; %cond.load433
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x17, d19
	ld1.s	{ v3 }[2], [x17]
	mov.16b	v15, v0
	mov.16b	v11, v27
	mov.16b	v27, v5
	tbnz	w13, #3, LBB0_299
LBB0_292:                               ; %else443
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #4, LBB0_300
LBB0_293:                               ; %cond.load445
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x17, d7
	ld1.s	{ v4 }[0], [x17]
	tbnz	w13, #5, LBB0_301
LBB0_294:                               ; %else455
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #6, LBB0_302
LBB0_295:                               ; %cond.load457
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x17, d6
	ld1.s	{ v4 }[2], [x17]
	tbnz	w13, #7, LBB0_303
	b	LBB0_304
LBB0_296:                               ; %else425
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q23, [sp, #704]                 ; 16-byte Folded Reload
	tbz	w13, #1, LBB0_290
LBB0_297:                               ; %cond.load427
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x17, v20[1]
	ld1.s	{ v3 }[1], [x17]
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	movi.8b	v20, #1
	mov.16b	v5, v11
	tbnz	w13, #2, LBB0_291
LBB0_298:                               ; %else437
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.16b	v15, v0
	mov.16b	v11, v27
	mov.16b	v27, v5
	tbz	w13, #3, LBB0_292
LBB0_299:                               ; %cond.load439
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x17, v19[1]
	ld1.s	{ v3 }[3], [x17]
	tbnz	w13, #4, LBB0_293
LBB0_300:                               ; %else449
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #5, LBB0_294
LBB0_301:                               ; %cond.load451
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x17, v7[1]
	ld1.s	{ v4 }[1], [x17]
	tbnz	w13, #6, LBB0_295
LBB0_302:                               ; %else461
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #7, LBB0_304
LBB0_303:                               ; %cond.load463
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x13, v6[1]
	ld1.s	{ v4 }[3], [x13]
LBB0_304:                               ; %else467
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmul.4s	v6, v3, v17
	fmul.4s	v3, v4, v16
	ldp	q4, q0, [sp, #592]              ; 32-byte Folded Reload
	str	q0, [sp, #2624]
	str	q4, [sp, #2640]
	ldp	q4, q0, [sp, #560]              ; 32-byte Folded Reload
	str	q0, [sp, #2656]
	str	q4, [sp, #2672]
	ubfiz	x13, x14, #3, #3
	add	x9, sp, #2624
	ldr	x17, [x9, x13]
	str	q23, [sp, #2560]
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	str	q0, [sp, #2576]
	ldr	q0, [sp, #1056]                 ; 16-byte Folded Reload
	str	q0, [sp, #2592]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #2608]
	add	x9, sp, #2560
	ldr	x1, [x9, x13]
	str	q27, [sp, #2496]
	str	q13, [sp, #2512]
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	str	q0, [sp, #2528]
	str	q26, [sp, #2544]
	add	x9, sp, #2496
	ldr	x13, [x9, x13]
	add	x17, x17, x17, lsl #6
	sub	x13, x13, x14
	add	x13, x13, x17
	add	x14, x3, x1, lsl #5
	add	x13, x14, x13, lsl #2
	fmov	w14, s1
	tbz	w14, #0, LBB0_312
; %bb.305:                              ; %cond.store470
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s6, [x13]
	tbnz	w14, #1, LBB0_313
LBB0_306:                               ; %else473
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #2, LBB0_314
LBB0_307:                               ; %cond.store474
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x13, #8
	st1.s	{ v6 }[2], [x17]
	tbnz	w14, #3, LBB0_315
LBB0_308:                               ; %else477
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #4, LBB0_316
LBB0_309:                               ; %cond.store478
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s3, [x13, #16]
	tbnz	w14, #5, LBB0_317
LBB0_310:                               ; %else481
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #6, LBB0_318
LBB0_311:                               ; %cond.store482
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x13, #24
	st1.s	{ v3 }[2], [x17]
	tbnz	w14, #7, LBB0_319
	b	LBB0_320
LBB0_312:                               ; %else471
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #1, LBB0_306
LBB0_313:                               ; %cond.store472
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x13, #4
	st1.s	{ v6 }[1], [x17]
	tbnz	w14, #2, LBB0_307
LBB0_314:                               ; %else475
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #3, LBB0_308
LBB0_315:                               ; %cond.store476
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x13, #12
	st1.s	{ v6 }[3], [x17]
	tbnz	w14, #4, LBB0_309
LBB0_316:                               ; %else479
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #5, LBB0_310
LBB0_317:                               ; %cond.store480
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x13, #20
	st1.s	{ v3 }[1], [x17]
	tbnz	w14, #6, LBB0_311
LBB0_318:                               ; %else483
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w14, #7, LBB0_320
LBB0_319:                               ; %cond.store484
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x13, #28
	st1.s	{ v3 }[3], [x13]
LBB0_320:                               ; %else485
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v1, v21, v20
	ushll.8h	v1, v1, #0
	ushll.4s	v3, v1, #0
	ushll2.4s	v1, v1, #0
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	uaddw2.2d	v0, v0, v1
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1056]                 ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v1
	str	q0, [sp, #1056]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	uaddw2.2d	v0, v0, v3
	str	q0, [sp, #1008]                 ; 16-byte Folded Spill
	uaddw.2d	v23, v23, v3
	tst	w11, #0xff
	b.ne	LBB0_263
	b	LBB0_3
LBB0_321:                               ; %varying.coherent.false239
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_3
LBB0_322:                               ; %schedule.18
                                        ;   in Loop: Header=BB0_4 Depth=1
	cbz	w12, LBB0_327
; %bb.323:                              ; %convergence.cascade252.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w13, #0                         ; =0x0
LBB0_324:                               ; %convergence.cascade252
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w16, s1
	sub	w11, w12, #1
	tst	w9, #0xff
	csel	w14, w11, wzr, ne
	lsl	w17, w20, w14
	and	w9, w17, w10
	tst	w9, #0xff
	cset	w9, ne
	ldr	q1, [sp, #1120]                 ; 16-byte Folded Reload
	str	q1, [sp, #3280]
	ldr	q1, [sp, #1136]                 ; 16-byte Folded Reload
	str	q1, [sp, #3296]
	ubfiz	x11, x14, #2, #3
	add	x0, sp, #3280
	ldr	w0, [x0, x11]
	cmp	w0, #5
	cset	w1, eq
	and	w2, w9, w16
	ldrb	w9, [x27, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s1, w16
	ubfx	w16, w9, #1, #1
	mov.b	v1[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v1[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v1[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v1[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v1[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v1[6], w16
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s3, w16
	ubfx	w16, w9, #1, #1
	mov.b	v3[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v3[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v3[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v3[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v3[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v3[6], w16
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v21, v3
	and.8b	v6, v12, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w9, s6
	ands	w16, w2, w1
	csetm	w0, ne
	bics	w9, w16, w9
	csetm	w1, ne
	dup.8b	v6, w1
	dup.8b	v7, w0
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	csinv	w14, w5, w17, eq
	dup.8b	v1, w16
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #3248]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #3264]
	add	x9, sp, #3248
	ldr	w9, [x9, x11]
	csel	w12, w9, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w16, #1
	b.ne	LBB0_328
; %bb.325:                              ; %convergence.cascade252
                                        ;   in Loop: Header=BB0_324 Depth=2
	cmp	w12, #0
	ccmp	w13, #6, #2, ne
	b.hi	LBB0_328
; %bb.326:                              ; %convergence.cascade252
                                        ;   in Loop: Header=BB0_324 Depth=2
	add	w13, w13, #1
	tst	w11, #0xff
	b.ne	LBB0_324
	b	LBB0_328
LBB0_327:                               ; %schedule.18.convergence.cascade.exit253_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_328:                               ; %convergence.cascade.exit253
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_2
; %bb.329:                              ; %convergence.target.18.ready
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v1, v15, v21
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	and.8b	v1, v3, v2
	addv.8b	b1, v1
	umaxv.8b	b3, v3
	fmov	w9, s3
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #384
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #352
	tbz	w9, #0, LBB0_336
; %bb.330:                              ; %convergence.target.18.ready
                                        ;   in Loop: Header=BB0_4 Depth=1
	bic.8b	v3, v21, v15
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w9, s3
	tst	w9, #0xff
	b.eq	LBB0_336
; %bb.331:                              ; %varying.divergent270
                                        ;   in Loop: Header=BB0_4 Depth=1
	subs	w9, w12, #1
	csel	w9, wzr, w9, lo
	and	w13, w10, #0xff
	lsr	w11, w13, w9
	tst	w11, #0x1
	ldr	q4, [sp, #1120]                 ; 16-byte Folded Reload
	str	q4, [sp, #2848]
	ldr	q4, [sp, #1136]                 ; 16-byte Folded Reload
	str	q4, [sp, #2864]
	and	x9, x9, #0x7
	add	x11, sp, #2848
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w9, #6, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_333
; %bb.332:                              ; %varying.divergent270
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w11, #0, LBB0_377
LBB0_333:                               ; %convergence.overflow.resume273
                                        ;   in Loop: Header=BB0_4 Depth=1
	mvn	w9, w10
	rbit	w9, w9
	clz	w9, w9
	mov	w13, #255                       ; =0xff
	bics	wzr, w13, w10
	csel	w13, wzr, w9, eq
	ubfiz	x9, x13, #2, #3
	lsl	w14, w20, w13
	ldr	q5, [sp, #1120]                 ; 16-byte Folded Reload
	str	q5, [sp, #2816]
	ldr	q4, [sp, #1136]                 ; 16-byte Folded Reload
	str	q4, [sp, #2832]
	add	x16, sp, #2816
	ldr	w16, [x16, x9]
	cmp	w11, #0
	csel	w11, w14, wzr, ne
	mov	w14, #6                         ; =0x6
	csel	w14, w14, w16, ne
	str	q5, [sp, #2784]
	str	q4, [sp, #2800]
	add	x16, sp, #2784
	str	w14, [x16, x9]
	ldr	q4, [sp, #2800]
	str	q4, [sp, #1136]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #2784]
	str	q4, [sp, #1120]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	str	q5, [sp, #2752]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #2768]
	add	x14, sp, #2752
	ldr	w14, [x14, x9]
	csel	w14, w12, w14, ne
	str	q5, [sp, #2720]
	str	q4, [sp, #2736]
	add	x16, sp, #2720
	str	w14, [x16, x9]
	ldrb	w9, [x27, x13]
	and	w14, w9, #0x1
	fmov	s4, w14
	ubfx	w14, w9, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v4[6], w14
	ldr	q5, [sp, #2736]
	str	q5, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #2720]
	str	q5, [sp, #1088]                 ; 16-byte Folded Spill
	lsr	w9, w9, #7
	mov.b	v4[7], w9
	ldrb	w9, [x8, x13]
	and	w14, w9, #0x1
	fmov	s6, w14
	ubfx	w14, w9, #1, #1
	mov.b	v6[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v6[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v6[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v6[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v6[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v6[6], w14
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	csetm	w9, ne
	dup.8b	v7, w9
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x27, x13]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_377
; %bb.334:                              ; %ready.overflow.resume275
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b1, [x21, x28]
	mov	w9, #19                         ; =0x13
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #352
	b.hs	LBB0_377
; %bb.335:                              ; %ready.overflow.resume277
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	b3, [x21, w19, uxtw]
	orr	w10, w11, w10
	mov	w9, #20                         ; =0x14
	b	LBB0_73
LBB0_336:                               ; %varying.coherent271
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w9, s1
	tst	w9, #0xff
	b.eq	LBB0_354
LBB0_337:                               ; %schedule.19
                                        ;   in Loop: Header=BB0_4 Depth=1
	rbit	w13, w11
	clz	w13, w13
	tst	w11, #0xff
	csel	w14, wzr, w13, eq
	mov	w9, #256                        ; =0x100
	sub	x17, x9, w14, uxtw #2
	tst	w11, #0xff
	ldp	q1, q0, [sp, #864]              ; 32-byte Folded Reload
	str	q0, [sp, #3184]
	str	q1, [sp, #3200]
	ldp	q1, q0, [sp, #832]              ; 32-byte Folded Reload
	str	q0, [sp, #3216]
	str	q1, [sp, #3232]
	and	x1, x14, #0x7
	add	x9, sp, #3152
	add	x2, x9, x1, lsl #2
	add	x9, sp, #3184
	ldr	x13, [x9, x1, lsl #3]
	add	x13, x17, x13
	csel	x13, xzr, x13, eq
	add	x13, x15, x13
	ldp	q3, q1, [x13]
	zip1.8b	v4, v21, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v6, v4, #0
	and.16b	v4, v6, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w13, s3
	ldp	q5, q0, [sp, #800]              ; 32-byte Folded Reload
	str	q5, [sp, #3152]
	str	q0, [sp, #3168]
	ld1r.4s	{ v3 }, [x2]
	fdiv.4s	v7, v4, v3
	ldr	q0, [sp, #912]                  ; 16-byte Folded Reload
	str	q0, [sp, #3088]
	ldp	q4, q0, [sp, #960]              ; 32-byte Folded Reload
	str	q4, [sp, #3104]
	str	q0, [sp, #3120]
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	str	q0, [sp, #3136]
	add	x9, sp, #3088
	ldr	x2, [x9, x1, lsl #3]
	add	x17, x17, x2
	csel	x17, xzr, x17, eq
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #680
	add	x17, x9, x17
	ldp	q16, q4, [x17]
	and.16b	v6, v6, v16
	ldp	q16, q0, [sp, #592]             ; 32-byte Folded Reload
	str	q0, [sp, #3024]
	str	q16, [sp, #3040]
	ldp	q16, q0, [sp, #560]             ; 32-byte Folded Reload
	str	q0, [sp, #3056]
	str	q16, [sp, #3072]
	add	x9, sp, #3024
	ldr	x17, [x9, x1, lsl #3]
	fmul.4s	v6, v7, v6
	add	x17, x17, x17, lsl #6
	str	q27, [sp, #2960]
	str	q13, [sp, #2976]
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	str	q0, [sp, #2992]
	str	q26, [sp, #3008]
	add	x9, sp, #2960
	ldr	x1, [x9, x1, lsl #3]
	sub	x14, x1, x14
	add	x14, x14, x17
	add	x14, x3, x14, lsl #2
	add	x14, x14, #256
	tbz	w13, #0, LBB0_341
; %bb.338:                              ; %cond.store487
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s6, [x14]
	tbnz	w13, #1, LBB0_342
LBB0_339:                               ; %else490
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #2, LBB0_343
LBB0_340:                               ; %cond.store491
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x14, #8
	st1.s	{ v6 }[2], [x17]
	tbnz	w13, #3, LBB0_344
	b	LBB0_345
LBB0_341:                               ; %else488
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #1, LBB0_339
LBB0_342:                               ; %cond.store489
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x14, #4
	st1.s	{ v6 }[1], [x17]
	tbnz	w13, #2, LBB0_340
LBB0_343:                               ; %else492
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #3, LBB0_345
LBB0_344:                               ; %cond.store493
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x14, #12
	st1.s	{ v6 }[3], [x17]
LBB0_345:                               ; %else494
                                        ;   in Loop: Header=BB0_4 Depth=1
	zip2.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v1, v6, v1
	fdiv.4s	v1, v1, v3
	and.16b	v3, v6, v4
	fmul.4s	v1, v1, v3
	tbz	w13, #4, LBB0_350
; %bb.346:                              ; %cond.store495
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s1, [x14, #16]
	tbnz	w13, #5, LBB0_351
LBB0_347:                               ; %else498
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #6, LBB0_352
LBB0_348:                               ; %cond.store499
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x14, #24
	st1.s	{ v1 }[2], [x17]
	tbnz	w13, #7, LBB0_353
LBB0_349:                               ; %else502
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.ne	LBB0_354
	b	LBB0_3
LBB0_350:                               ; %else496
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #5, LBB0_347
LBB0_351:                               ; %cond.store497
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x14, #20
	st1.s	{ v1 }[1], [x17]
	tbnz	w13, #6, LBB0_348
LBB0_352:                               ; %else500
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #7, LBB0_349
LBB0_353:                               ; %cond.store501
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x14, #28
	st1.s	{ v1 }[3], [x13]
	tst	w11, #0xff
	b.eq	LBB0_3
LBB0_354:                               ; %schedule.20
                                        ;   in Loop: Header=BB0_4 Depth=1
	cbz	w12, LBB0_359
; %bb.355:                              ; %convergence.cascade292.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w11, #0                         ; =0x0
LBB0_356:                               ; %convergence.cascade292
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w16, s1
	sub	w13, w12, #1
	tst	w9, #0xff
	csel	w14, w13, wzr, ne
	lsl	w17, w20, w14
	and	w9, w17, w10
	tst	w9, #0xff
	cset	w9, ne
	ldr	q1, [sp, #1120]                 ; 16-byte Folded Reload
	str	q1, [sp, #2928]
	ldr	q1, [sp, #1136]                 ; 16-byte Folded Reload
	str	q1, [sp, #2944]
	ubfiz	x13, x14, #2, #3
	add	x0, sp, #2928
	ldr	w0, [x0, x13]
	cmp	w0, #6
	cset	w1, eq
	and	w2, w9, w16
	ldrb	w9, [x27, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s1, w16
	ubfx	w16, w9, #1, #1
	mov.b	v1[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v1[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v1[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v1[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v1[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v1[6], w16
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s3, w16
	ubfx	w16, w9, #1, #1
	mov.b	v3[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v3[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v3[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v3[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v3[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v3[6], w16
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v21, v3
	and.8b	v6, v12, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w9, s6
	ands	w16, w2, w1
	csetm	w0, ne
	bics	w9, w16, w9
	csetm	w1, ne
	dup.8b	v6, w1
	dup.8b	v7, w0
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	csinv	w14, w5, w17, eq
	dup.8b	v1, w16
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #2896]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #2912]
	add	x9, sp, #2896
	ldr	w9, [x9, x13]
	csel	w12, w9, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
	cmp	w16, #1
	b.ne	LBB0_360
; %bb.357:                              ; %convergence.cascade292
                                        ;   in Loop: Header=BB0_356 Depth=2
	cmp	w12, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_360
; %bb.358:                              ; %convergence.cascade292
                                        ;   in Loop: Header=BB0_356 Depth=2
	add	w11, w11, #1
	tst	w13, #0xff
	b.ne	LBB0_356
	b	LBB0_360
LBB0_359:                               ; %schedule.20.convergence.cascade.exit293_crit_edge
                                        ;   in Loop: Header=BB0_4 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
LBB0_360:                               ; %convergence.cascade.exit293
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_2
; %bb.361:                              ; %convergence.target.20.ready
                                        ;   in Loop: Header=BB0_4 Depth=1
	bic.8b	v12, v12, v21
	tst	w10, #0xff
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #384
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #352
	b.eq	LBB0_374
; %bb.362:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldrb	w9, [x8, #8]
	and	w11, w9, #0x1
	fmov	s1, w11
	ubfx	w11, w9, #1, #1
	mov.b	v1[1], w11
	ubfx	w11, w9, #2, #1
	mov.b	v1[2], w11
	ubfx	w11, w9, #3, #1
	mov.b	v1[3], w11
	ubfx	w11, w9, #4, #1
	mov.b	v1[4], w11
	ubfx	w11, w9, #5, #1
	mov.b	v1[5], w11
	ubfx	w11, w9, #6, #1
	mov.b	v1[6], w11
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8]
	and	w11, w9, #0x1
	fmov	s6, w11
	ubfx	w11, w9, #1, #1
	mov.b	v6[1], w11
	ubfx	w11, w9, #2, #1
	mov.b	v6[2], w11
	ubfx	w11, w9, #3, #1
	mov.b	v6[3], w11
	ubfx	w11, w9, #4, #1
	mov.b	v6[4], w11
	ubfx	w11, w9, #5, #1
	mov.b	v6[5], w11
	ubfx	w11, w9, #6, #1
	mov.b	v6[6], w11
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	and.8b	v7, v12, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w9, s1
	eor	w9, w9, #0x1
	and	w9, w10, w9
	dup.8b	v1, w9
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w12, s4
	tst	w9, #0x1
	csetm	w9, ne
	dup.8b	v16, w9
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	str	b7, [x8, #8]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	str	b6, [x8]
	cmp	w26, #8
	b.lo	LBB0_364
; %bb.363:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w12, #0xff
	b.ne	LBB0_377
LBB0_364:                               ; %ready.overflow.resume314
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w9, s3
	ldr	d3, [sp, #72]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w11, v3[0]
	sbfx	w13, w11, #0, #1
	fmov	s3, w13
	sbfx	w13, w11, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w11, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w11, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w11, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w11, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w11, #6, #1
	mov.b	v3[6], w13
	sbfx	w11, w11, #7, #1
	mov.b	v3[7], w11
	and	w11, w10, #0xfffffffe
	tst	w9, #0xff
	csel	w11, w11, w10, eq
	tst	w12, #0xff
	csel	x9, x28, xzr, ne
	ldrb	w10, [x21, x9]
	and	w12, w10, #0x1
	fmov	s4, w12
	ubfx	w12, w10, #1, #1
	mov.b	v4[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v4[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v4[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v4[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v4[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v4[6], w12
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1120]                 ; 16-byte Folded Reload
	fmov	w10, s3
Lloh22:
	adrp	x17, l_convergence.targets@PAGE
Lloh23:
	add	x17, x17, l_convergence.targets@PAGEOFF
	add	x10, x17, w10, sxtw #2
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	fmov	w12, s3
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x9]
	lsl	x9, x9, #2
	add	x13, x22, x9
	csel	x10, x10, x13, ne
	ldr	w10, [x10]
	str	w10, [x13]
	ldr	w10, [x23, x9]
	csel	w10, w12, w10, ne
	str	w10, [x23, x9]
	csel	w10, w19, w26, ne
	and	w9, w11, #0x2
	ldrb	w12, [x8, #9]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #1]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v12, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w9, w12, w9, lsr #1
	dup.8b	v1, w9
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w12, s4
	csetm	w9, ne
	dup.8b	v16, w9
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #9]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #1]
	cmp	w10, #8
	and	w9, w12, #0xff
	ccmp	w9, #0, #4, hs
	b.ne	LBB0_377
; %bb.365:                              ; %ready.overflow.resume320
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v3, v3, v2
	ldr	d6, [sp, #64]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v6
	mvn.8b	v4, v4
	umov.b	w9, v4[0]
	addv.8b	b4, v3
	sbfx	w13, w9, #0, #1
	fmov	s3, w13
	sbfx	w13, w9, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w9, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w9, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w9, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w9, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w9, #6, #1
	mov.b	v3[6], w13
	sbfx	w9, w9, #7, #1
	mov.b	v3[7], w9
	fmov	w9, s4
	and	w13, w11, #0xfffffffd
	tst	w9, #0xff
	csel	w9, w13, w11, eq
	sxtw	x11, w10
	tst	w12, #0xff
	csel	x11, x11, xzr, ne
	ldrb	w12, [x21, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1120]                 ; 16-byte Folded Reload
	mov.s	w12, v3[1]
	add	x12, x17, w12, sxtw #2
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	mov.s	w13, v3[1]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x11]
	lsl	x11, x11, #2
	add	x14, x22, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x23, x11]
	csel	w12, w13, w12, ne
	str	w12, [x23, x11]
	cinc	w10, w10, ne
	and	w11, w9, #0x4
	ldrb	w12, [x8, #10]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #2]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v12, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w11, w12, w11, lsr #2
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #10]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #2]
	cmp	w10, #8
	and	w12, w11, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_377
; %bb.366:                              ; %ready.overflow.resume326
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v3, v3, v2
	ldr	d6, [sp, #56]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v6
	mvn.8b	v4, v4
	umov.b	w12, v4[0]
	addv.8b	b4, v3
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	fmov	w12, s4
	and	w13, w9, #0xfffffffb
	tst	w12, #0xff
	csel	w9, w13, w9, eq
	sxtw	x12, w10
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x21, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1120]                 ; 16-byte Folded Reload
	mov.s	w12, v3[2]
	add	x12, x17, w12, sxtw #2
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	mov.s	w13, v3[2]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x11]
	lsl	x11, x11, #2
	add	x14, x22, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x23, x11]
	csel	w12, w13, w12, ne
	str	w12, [x23, x11]
	cinc	w10, w10, ne
	and	w11, w9, #0x8
	ldrb	w12, [x8, #11]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #3]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v12, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w11, w12, w11, lsr #3
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #11]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #3]
	cmp	w10, #8
	and	w12, w11, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_377
; %bb.367:                              ; %ready.overflow.resume332
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v3, v3, v2
	ldr	d6, [sp, #48]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v6
	mvn.8b	v4, v4
	umov.b	w12, v4[0]
	addv.8b	b4, v3
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	fmov	w12, s4
	and	w13, w9, #0xfffffff7
	tst	w12, #0xff
	csel	w9, w13, w9, eq
	sxtw	x12, w10
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x21, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1120]                 ; 16-byte Folded Reload
	mov.s	w12, v3[3]
	add	x12, x17, w12, sxtw #2
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	mov.s	w13, v3[3]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x11]
	lsl	x11, x11, #2
	add	x14, x22, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x23, x11]
	csel	w12, w13, w12, ne
	str	w12, [x23, x11]
	cinc	w11, w10, ne
	and	w10, w9, #0x10
	ldrb	w12, [x8, #12]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #4]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v12, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w10, w12, w10, lsr #4
	dup.8b	v1, w10
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w12, s4
	csetm	w10, ne
	dup.8b	v16, w10
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #12]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #4]
	cmp	w11, #8
	and	w10, w12, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_377
; %bb.368:                              ; %ready.overflow.resume338
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w10, s3
	ldr	d3, [sp, #40]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w13, v3[0]
	sbfx	w14, w13, #0, #1
	fmov	s3, w14
	sbfx	w14, w13, #1, #1
	mov.b	v3[1], w14
	sbfx	w14, w13, #2, #1
	mov.b	v3[2], w14
	sbfx	w14, w13, #3, #1
	mov.b	v3[3], w14
	sbfx	w14, w13, #4, #1
	mov.b	v3[4], w14
	sbfx	w14, w13, #5, #1
	mov.b	v3[5], w14
	sbfx	w14, w13, #6, #1
	mov.b	v3[6], w14
	sbfx	w13, w13, #7, #1
	mov.b	v3[7], w13
	and	w13, w9, #0xffffffef
	tst	w10, #0xff
	csel	w10, w13, w9, eq
	sxtw	x9, w11
	tst	w12, #0xff
	csel	x9, x9, xzr, ne
	ldrb	w12, [x21, x9]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1136]                 ; 16-byte Folded Reload
	fmov	w12, s3
	add	x12, x17, w12, sxtw #2
	ldr	q3, [sp, #1104]                 ; 16-byte Folded Reload
	fmov	w13, s3
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x9]
	lsl	x9, x9, #2
	add	x14, x22, x9
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x23, x9]
	csel	w12, w13, w12, ne
	str	w12, [x23, x9]
	cinc	w9, w11, ne
	and	w11, w10, #0x20
	ldrb	w12, [x8, #13]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #5]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v12, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w11, w12, w11, lsr #5
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #13]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #5]
	cmp	w9, #8
	and	w12, w11, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_377
; %bb.369:                              ; %ready.overflow.resume344
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w12, s3
	ldr	d3, [sp, #32]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w13, v3[0]
	sbfx	w14, w13, #0, #1
	fmov	s3, w14
	sbfx	w14, w13, #1, #1
	mov.b	v3[1], w14
	sbfx	w14, w13, #2, #1
	mov.b	v3[2], w14
	sbfx	w14, w13, #3, #1
	mov.b	v3[3], w14
	sbfx	w14, w13, #4, #1
	mov.b	v3[4], w14
	sbfx	w14, w13, #5, #1
	mov.b	v3[5], w14
	sbfx	w14, w13, #6, #1
	mov.b	v3[6], w14
	sbfx	w13, w13, #7, #1
	mov.b	v3[7], w13
	and	w13, w10, #0xffffffdf
	tst	w12, #0xff
	csel	w10, w13, w10, eq
	sxtw	x12, w9
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x21, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	ldr	q5, [sp, #1136]                 ; 16-byte Folded Reload
	mov.s	w12, v5[1]
	bif.8b	v1, v4, v3
	add	x12, x17, w12, sxtw #2
	ldr	q3, [sp, #1104]                 ; 16-byte Folded Reload
	mov.s	w13, v3[1]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x11]
	lsl	x11, x11, #2
	add	x14, x22, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x23, x11]
	csel	w12, w13, w12, ne
	str	w12, [x23, x11]
	cinc	w9, w9, ne
	ldrb	w11, [x8, #14]
	and	w12, w11, #0x1
	fmov	s1, w12
	ubfx	w12, w11, #1, #1
	mov.b	v1[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v1[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v1[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v1[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v1[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v1[6], w12
	lsr	w11, w11, #7
	mov.b	v1[7], w11
	ldrb	w11, [x8, #6]
	and	w12, w11, #0x1
	fmov	s6, w12
	ubfx	w12, w11, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v6[6], w12
	and	w12, w10, #0x40
	lsr	w11, w11, #7
	mov.b	v6[7], w11
	and.8b	v7, v12, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w11, s1
	eor	w11, w11, #0x1
	ands	w11, w11, w12, lsr #6
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #14]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #6]
	cmp	w9, #8
	b.lo	LBB0_371
; %bb.370:                              ; %ready.overflow.resume344
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.ne	LBB0_377
LBB0_371:                               ; %ready.overflow.resume350
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v3, v3, v2
	ldr	d6, [sp, #24]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v6
	mvn.8b	v4, v4
	umov.b	w12, v4[0]
	addv.8b	b4, v3
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	fmov	w12, s4
	and	w13, w10, #0xffffffbf
	tst	w12, #0xff
	csel	w10, w13, w10, eq
	sxtw	x12, w9
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x21, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1136]                 ; 16-byte Folded Reload
	mov.s	w12, v3[2]
	add	x12, x17, w12, sxtw #2
	ldr	q3, [sp, #1104]                 ; 16-byte Folded Reload
	mov.s	w13, v3[2]
	sxtb	w10, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x11]
	lsl	x11, x11, #2
	ldr	w14, [x23, x11]
	csel	w13, w13, w14, ne
	add	x14, x22, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w13, [x23, x11]
	str	w12, [x14]
	cinc	w9, w9, ne
	cmp	w10, #0
	ldrb	w11, [x8, #15]
	and	w12, w11, #0x1
	fmov	s1, w12
	ubfx	w12, w11, #1, #1
	mov.b	v1[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v1[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v1[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v1[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v1[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v1[6], w12
	lsr	w11, w11, #7
	mov.b	v1[7], w11
	ldrb	w11, [x8, #7]
	and	w12, w11, #0x1
	fmov	s6, w12
	ubfx	w12, w11, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v6[6], w12
	cset	w12, lt
	lsr	w11, w11, #7
	mov.b	v6[7], w11
	and.8b	v7, v12, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w11, s1
	eor	w11, w11, #0x1
	ands	w11, w12, w11
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #15]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #7]
	cmp	w9, #8
	b.lo	LBB0_373
; %bb.372:                              ; %ready.overflow.resume350
                                        ;   in Loop: Header=BB0_4 Depth=1
	tst	w11, #0xff
	b.ne	LBB0_377
LBB0_373:                               ; %ready.overflow.resume356
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b6, v3
	ldr	d3, [sp, #16]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w12, v3[0]
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	fmov	w13, s6
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	and	w12, w10, #0x7f
	tst	w13, #0xff
	csel	w10, w12, w10, eq
	sxtw	x12, w9
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x21, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1136]                 ; 16-byte Folded Reload
	mov.s	w12, v3[3]
	ldr	q3, [sp, #1104]                 ; 16-byte Folded Reload
	mov.s	w13, v3[3]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x11]
	add	x12, x17, w12, sxtw #2
	lsl	x11, x11, #2
	add	x14, x22, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x23, x11]
	csel	w12, w13, w12, ne
	str	w12, [x23, x11]
	cinc	w26, w9, ne
	b	LBB0_3
LBB0_374:                               ;   in Loop: Header=BB0_4 Depth=1
	mov	w10, #0                         ; =0x0
	b	LBB0_3
LBB0_375:                               ; %scheduler.done
	shl.8b	v0, v12, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w8, s0
	tbnz	w8, #0, LBB0_377
; %bb.376:                              ; %scheduler.exit
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #1344
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_377:                               ; %scheduler.stalled
	brk	#0x1
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdd	Lloh22, Lloh23
	.section	__TEXT,__const
	.p2align	1, 0x0
LJTI0_0:
	.short	(LBB0_6-LBB0_6)>>2
	.short	(LBB0_16-LBB0_6)>>2
	.short	(LBB0_9-LBB0_6)>>2
	.short	(LBB0_13-LBB0_6)>>2
	.short	(LBB0_8-LBB0_6)>>2
	.short	(LBB0_63-LBB0_6)>>2
	.short	(LBB0_75-LBB0_6)>>2
	.short	(LBB0_10-LBB0_6)>>2
	.short	(LBB0_154-LBB0_6)>>2
	.short	(LBB0_7-LBB0_6)>>2
	.short	(LBB0_170-LBB0_6)>>2
	.short	(LBB0_180-LBB0_6)>>2
	.short	(LBB0_11-LBB0_6)>>2
	.short	(LBB0_223-LBB0_6)>>2
	.short	(LBB0_14-LBB0_6)>>2
	.short	(LBB0_255-LBB0_6)>>2
	.short	(LBB0_263-LBB0_6)>>2
	.short	(LBB0_15-LBB0_6)>>2
	.short	(LBB0_322-LBB0_6)>>2
	.short	(LBB0_12-LBB0_6)>>2
	.short	(LBB0_354-LBB0_6)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch          ; -- Begin function llm_rows.packet_batch
	.p2align	2
_llm_rows.packet_batch:                 ; @llm_rows.packet_batch
; %bb.0:                                ; %packet.batch.prologue
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x21, x3
	mov	x19, x2
	mov	x20, x0
	ldr	w23, [x2, #36]
	ldr	w8, [x2]
	ldr	w9, [x2, #12]
	lsl	x8, x8, #5
	cmp	x8, x9
	csel	x10, x8, xzr, ls
	add	x10, x10, x23
	subs	x11, x9, x10
	mov	w12, #32                        ; =0x20
	sub	x13, x12, x23
	cmp	x11, x13
	csel	x11, x11, x13, lo
	cmp	x9, x10
	ccmp	x23, x12, #2, hi
	ccmp	x8, x9, #2, lo
	csel	x8, x11, xzr, ls
	cmp	w3, #4
	b.ne	LBB1_3
; %bb.1:                                ; %packet.batch.prologue
	cmp	x8, #32
	b.lo	LBB1_3
; %bb.2:                                ; %packet.batch.full
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w8, w23, #8
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w8, w23, #16
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w8, w23, #24
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	b	_llm_rows
LBB1_3:                                 ; %packet.batch.partial
	ubfiz	x9, x21, #3, #32
	cmp	x8, x9
	csel	x8, x8, x9, lo
	lsr	x24, x8, #3
	and	w22, w8, #0x7
	cmp	x8, #8
	b.lo	LBB1_6
; %bb.4:                                ; %packet.batch.partial.full.loop.preheader
	mov	x25, x24
	mov	x26, x23
LBB1_5:                                 ; %packet.batch.partial.full.loop
                                        ; =>This Inner Loop Header: Depth=1
	str	w26, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w26, w26, #8
	subs	w25, w25, #1
	b.ne	LBB1_5
LBB1_6:                                 ; %packet.batch.tail.check
	cbz	w22, LBB1_8
; %bb.7:                                ; %packet.batch.tail.call
	add	w8, w23, w24, lsl #3
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	x2, x22
	bl	_llm_rows
LBB1_8:                                 ; %packet.batch.partial.finish
	lsl	w8, w21, #3
	sub	w8, w8, #8
	cmp	w21, #0
	csel	w8, wzr, w8, eq
	add	w8, w23, w8
	str	w8, [x19, #36]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @convergence.targets
l_convergence.targets:
	.long	5                               ; 0x5
	.long	8                               ; 0x8
	.long	10                              ; 0xa
	.long	13                              ; 0xd
	.long	15                              ; 0xf
	.long	18                              ; 0x12
	.long	20                              ; 0x14

.subsections_via_symbols

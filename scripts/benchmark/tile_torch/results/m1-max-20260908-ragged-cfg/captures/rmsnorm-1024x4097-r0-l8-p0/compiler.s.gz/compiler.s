	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_4:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_8:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_9:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_10:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_11:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_3:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #9, lsl #12             ; =36864
	sub	sp, sp, #784
	fmov	s1, wzr
	add	x8, sp, #9, lsl #12             ; =36864
	add	x8, x8, #696
	str	wzr, [x8, #84]
	stur	wzr, [x8, #81]
	stur	xzr, [x8, #52]
	stur	xzr, [x8, #68]
	stur	xzr, [x8, #60]
	str	wzr, [x8, #76]
	stur	xzr, [x8, #20]
	stur	xzr, [x8, #36]
	stur	xzr, [x8, #28]
	stp	xzr, xzr, [x8]
	ldr	x6, [x0]
	ldr	x7, [x0, #16]
	ldr	x3, [x0, #48]
	ldr	w9, [x1]
	ldr	w11, [x1, #36]
	dup.4s	v0, w2
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x10, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q3, [x10, lCPI0_1@PAGEOFF]
	cmhi.4s	v3, v0, v3
	cmhi.4s	v0, v0, v2
	uzp1.8h	v2, v0, v3
	xtn.8b	v9, v2
Lloh4:
	adrp	x10, lCPI0_2@PAGE
Lloh5:
	ldr	q3, [x10, lCPI0_2@PAGEOFF]
	and.16b	v3, v2, v3
	addv.8h	h3, v3
	fmov	w10, s3
	and	w10, w10, #0xff
	fmov	s3, w10
	cmeq.8b	v1, v3, v1
	umov.b	w10, v1[0]
	and	w12, w10, #0x1
	fmov	s1, w12
	ubfx	w12, w10, #1, #1
	mov.b	v1[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v1[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v1[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v1[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v1[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v1[6], w12
	ubfx	w10, w10, #7, #1
	mov.b	v1[7], w10
	movi.8b	v20, #1
	eor.8b	v1, v1, v20
	and.8b	v1, v1, v9
	umaxv.8h	h2, v2
	fmov	w10, s2
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
Lloh6:
	adrp	x12, lCPI0_3@PAGE
Lloh7:
	ldr	d2, [x12, lCPI0_3@PAGEOFF]
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x8, #80]
	stp	wzr, wzr, [x8, #44]
	str	wzr, [x8, #16]
	tbz	w10, #0, LBB0_373
; %bb.1:                                ; %scheduler.dispatch.preheader
	mov	w10, #0                         ; =0x0
	stp	xzr, xzr, [sp, #64]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #48]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #32]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #16]             ; 16-byte Folded Spill
	add	x15, sp, #5, lsl #12            ; =20480
	add	x15, x15, #664
	dup.2d	v0, x15
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #632
	dup.2d	v1, x12
	stp	q0, q1, [sp, #96]               ; 32-byte Folded Spill
	add	w9, w11, w9, lsl #5
	dup.4s	v1, w9
	str	q1, [sp, #80]                   ; 16-byte Folded Spill
	movi.2d	v23, #0000000000000000
	add	x9, x7, #4, lsl #12             ; =16384
	str	x9, [sp, #128]                  ; 8-byte Folded Spill
	mov	w20, #1                         ; =0x1
	add	x21, sp, #9, lsl #12            ; =36864
	add	x21, x21, #776
	add	x22, sp, #9, lsl #12            ; =36864
	add	x22, x22, #744
	add	x23, sp, #9, lsl #12            ; =36864
	add	x23, x23, #712
	adrp	x24, lCPI0_8@PAGE
	adrp	x25, lCPI0_9@PAGE
	adrp	x30, lCPI0_10@PAGE
	add	x27, sp, #9, lsl #12            ; =36864
	add	x27, x27, #704
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #1008]             ; 32-byte Folded Spill
	movi.2d	v19, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v1, #0000000000000000
	stp	q0, q1, [sp, #784]              ; 32-byte Folded Spill
	movi.2d	v8, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v12, #0000000000000000
	stp	q1, q1, [sp, #512]              ; 32-byte Folded Spill
	str	q0, [sp, #496]                  ; 16-byte Folded Spill
	stp	q1, q1, [sp, #544]              ; 32-byte Folded Spill
	movi.2d	v15, #0000000000000000
	stp	q1, q1, [sp, #976]              ; 32-byte Folded Spill
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #336
	mov	w5, #-1                         ; =0xffffffff
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #304
	add	x4, sp, #3520
	mov	w19, #1                         ; =0x1
	stp	q1, q0, [sp, #944]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #256]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #320]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #608]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #576]              ; 32-byte Folded Spill
	str	q1, [sp, #768]                  ; 16-byte Folded Spill
	stp	q1, q1, [sp, #816]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #912]              ; 32-byte Folded Spill
	movi.2d	v30, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v10, #0000000000000000
	stp	q1, q1, [sp, #432]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #400]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #864]              ; 32-byte Folded Spill
	str	q1, [sp, #848]                  ; 16-byte Folded Spill
	stp	q1, q1, [sp, #672]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #640]              ; 32-byte Folded Spill
	movi.2d	v22, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	str	q1, [sp, #1040]                 ; 16-byte Folded Spill
	str	q1, [sp, #1056]                 ; 16-byte Folded Spill
	str	q1, [sp, #1072]                 ; 16-byte Folded Spill
	str	q1, [sp, #1088]                 ; 16-byte Folded Spill
	b	LBB0_5
LBB0_2:                                 ; %ready.overflow.resume43
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b3, [x21, w19, uxtw]
	orr	w10, w11, w10
	mov	w9, #5                          ; =0x5
LBB0_3:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	w9, [x22, w19, uxtw #2]
	add	w26, w19, #1
	str	w12, [x23, w19, uxtw #2]
LBB0_4:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	x19, x26
	cbz	w26, LBB0_373
LBB0_5:                                 ; %scheduler.dispatch
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_65 Depth 2
                                        ;     Child Loop BB0_153 Depth 2
                                        ;     Child Loop BB0_169 Depth 2
                                        ;     Child Loop BB0_222 Depth 2
                                        ;     Child Loop BB0_254 Depth 2
                                        ;     Child Loop BB0_322 Depth 2
                                        ;     Child Loop BB0_354 Depth 2
	sub	w26, w19, #1
	ldr	w13, [x22, w26, sxtw #2]
	cmp	w13, #20
	b.hi	LBB0_375
; %bb.6:                                ; %scheduler.dispatch
                                        ;   in Loop: Header=BB0_5 Depth=1
	sxtw	x28, w26
	ldrb	w11, [x21, x28]
	and	w12, w11, #0x1
	fmov	s21, w12
	ubfx	w12, w11, #1, #1
	mov.b	v21[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v21[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v21[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v21[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v21[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v21[6], w12
	lsr	w11, w11, #7
	mov.b	v21[7], w11
	ldr	w12, [x23, w26, sxtw #2]
Lloh8:
	adrp	x9, LJTI0_0@PAGE
Lloh9:
	add	x9, x9, LJTI0_0@PAGEOFF
	adr	x11, LBB0_7
	ldrh	w14, [x9, x13, lsl #1]
	add	x11, x11, x14, lsl #2
	br	x11
LBB0_7:                                 ; %schedule.0
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v0, v19
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b1, v1
	fmov	w11, s1
	mov	b1, v21[6]
	mov.b	v1[4], v21[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
Lloh10:
	adrp	x9, lCPI0_4@PAGE
Lloh11:
	ldr	q3, [x9, lCPI0_4@PAGEOFF]
	bit.16b	v28, v3, v1
	mov	b3, v21[4]
	mov.b	v3[4], v21[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
Lloh12:
	adrp	x9, lCPI0_5@PAGE
Lloh13:
	ldr	q4, [x9, lCPI0_5@PAGEOFF]
	mov	b6, v21[2]
	mov.b	v6[4], v21[3]
	bit.16b	v27, v4, v3
	ushll.2d	v4, v6, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
Lloh14:
	adrp	x9, lCPI0_6@PAGE
Lloh15:
	ldr	q6, [x9, lCPI0_6@PAGEOFF]
	bit.16b	v24, v6, v4
	mov	b6, v21[0]
	mov.b	v6[4], v21[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
Lloh16:
	adrp	x9, lCPI0_7@PAGE
Lloh17:
	ldr	q7, [x9, lCPI0_7@PAGEOFF]
	bit.16b	v22, v7, v6
	zip1.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	ldr	q19, [sp, #80]                  ; 16-byte Folded Reload
	and.16b	v16, v7, v19
	zip2.8b	v17, v21, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v19, v17, v19
	movi.4s	v20, #3
	and.16b	v7, v7, v20
	and.16b	v17, v17, v20
	neg.4s	v17, v17
	ushl.4s	v17, v19, v17
	neg.4s	v7, v7
	ushl.4s	v7, v16, v7
	ushll.2d	v16, v7, #0
	ushll2.2d	v7, v7, #0
	ushll.2d	v19, v17, #0
	ushll2.2d	v17, v17, #0
	ldr	q20, [sp, #640]                 ; 16-byte Folded Reload
	bit.16b	v20, v17, v1
	ldr	q17, [sp, #656]                 ; 16-byte Folded Reload
	bit.16b	v17, v19, v3
	stp	q20, q17, [sp, #640]            ; 32-byte Folded Spill
	ldr	q17, [sp, #672]                 ; 16-byte Folded Reload
	bit.16b	v17, v7, v4
	ldr	q7, [sp, #688]                  ; 16-byte Folded Reload
	bit.16b	v7, v16, v6
	stp	q17, q7, [sp, #672]             ; 32-byte Folded Spill
	ldr	q7, [sp, #96]                   ; 16-byte Folded Reload
	ldr	q16, [sp, #400]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v1
	str	q16, [sp, #400]                 ; 16-byte Folded Spill
	ldr	q16, [sp, #416]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v3
	str	q16, [sp, #416]                 ; 16-byte Folded Spill
	ldr	q16, [sp, #432]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v4
	str	q16, [sp, #432]                 ; 16-byte Folded Spill
	ldr	q16, [sp, #448]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v6
	str	q16, [sp, #448]                 ; 16-byte Folded Spill
	ldr	q7, [x24, lCPI0_8@PAGEOFF]
	ldr	q16, [sp, #832]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v1
	str	q16, [sp, #832]                 ; 16-byte Folded Spill
	ldr	q7, [x25, lCPI0_9@PAGEOFF]
	ldr	q16, [sp, #848]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v3
	str	q16, [sp, #848]                 ; 16-byte Folded Spill
	ldr	q7, [x30, lCPI0_10@PAGEOFF]
	ldr	q16, [sp, #864]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v4
	str	q16, [sp, #864]                 ; 16-byte Folded Spill
Lloh18:
	adrp	x9, lCPI0_11@PAGE
Lloh19:
	ldr	q7, [x9, lCPI0_11@PAGEOFF]
	ldr	q16, [sp, #880]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v6
	str	q16, [sp, #880]                 ; 16-byte Folded Spill
	bic.16b	v10, v10, v1
	bic.16b	v25, v25, v3
	bic.16b	v31, v31, v4
	bic.16b	v14, v14, v6
	mov.16b	v19, v0
	movi.8b	v20, #1
	tbnz	w11, #0, LBB0_17
	b	LBB0_4
LBB0_8:                                 ; %scheduler.dispatch.schedule.9_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_166
LBB0_9:                                 ; %scheduler.dispatch.schedule.4_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_46
LBB0_10:                                ; %schedule.2
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	rbit	w11, w11
	clz	w11, w11
	umaxv.8b	b1, v1
	fmov	w13, s1
	eor	w1, w13, #0x1
	tst	w13, #0x1
	csel	w14, w11, wzr, ne
	b	LBB0_20
LBB0_11:                                ; %scheduler.dispatch.schedule.7_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b1, v1
	fmov	w11, s1
	eor	w11, w11, #0x1
	b	LBB0_83
LBB0_12:                                ; %scheduler.dispatch.schedule.12_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_186
LBB0_13:                                ; %scheduler.dispatch.schedule.19_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_335
LBB0_14:                                ; %scheduler.dispatch.schedule.3_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_38
LBB0_15:                                ; %scheduler.dispatch.schedule.14_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_235
LBB0_16:                                ; %scheduler.dispatch.schedule.17_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_270
LBB0_17:                                ; %schedule.1
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w13, s1
	rbit	w14, w11
	clz	w14, w14
	tst	w13, #0x1
	csel	w13, w14, wzr, ne
	str	q14, [sp, #4656]
	str	q31, [sp, #4672]
	str	q25, [sp, #4688]
	str	q10, [sp, #4704]
	and	x13, x13, #0x7
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #560
	ldr	x13, [x9, x13, lsl #3]
	cmp	x13, #512
	b.ge	LBB0_37
; %bb.18:                               ; %uniform.true
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
; %bb.19:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	w1, #0                          ; =0x0
LBB0_20:                                ; %schedule.2.thread
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	q14, [sp, #1296]
	str	q31, [sp, #1312]
	str	q25, [sp, #1328]
	str	q10, [sp, #1344]
	mov	w13, w14
	ubfiz	x17, x13, #3, #3
	add	x9, sp, #1296
	ldr	x11, [x9, x17]
	lsl	x2, x11, #3
	dup.2d	v1, x2
	add.2d	v3, v1, v22
	add.2d	v4, v1, v24
	add.2d	v6, v1, v27
	ldp	q7, q0, [sp, #672]              ; 32-byte Folded Reload
	str	q0, [sp, #1168]
	str	q7, [sp, #1184]
	ldp	q7, q0, [sp, #640]              ; 32-byte Folded Reload
	str	q0, [sp, #1200]
	str	q7, [sp, #1216]
	add	x9, sp, #1168
	ldr	x2, [x9, x17]
	add.2d	v1, v1, v28
	add	x2, x2, x2, lsl #12
	str	q1, [sp, #1280]
	str	q6, [sp, #1264]
	str	q4, [sp, #1248]
	str	q3, [sp, #1232]
	add	x9, sp, #1232
	ldr	x17, [x9, x17]
	sub	x2, x2, x13
	add	x17, x2, x17
	add	x17, x6, x17, lsl #2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w2, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w2, #0, LBB0_28
; %bb.21:                               ; %cond.load
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s1, [x17]
	tbnz	w2, #1, LBB0_29
LBB0_22:                                ; %else80
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w2, #2, LBB0_30
LBB0_23:                                ; %cond.load82
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x4, x17, #8
	ld1.s	{ v1 }[2], [x4]
	tbnz	w2, #3, LBB0_31
LBB0_24:                                ; %else86
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w2, #4, LBB0_32
LBB0_25:                                ; %cond.load88
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x4, x17, #16
	ld1.s	{ v3 }[0], [x4]
	tbnz	w2, #5, LBB0_33
LBB0_26:                                ; %else92
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w2, #6, LBB0_34
LBB0_27:                                ; %cond.load94
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x4, x17, #24
	ld1.s	{ v3 }[2], [x4]
	add	x4, sp, #3520
	tbnz	w2, #7, LBB0_35
	b	LBB0_36
LBB0_28:                                ; %else
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w2, #1, LBB0_22
LBB0_29:                                ; %cond.load79
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x4, x17, #4
	ld1.s	{ v1 }[1], [x4]
	tbnz	w2, #2, LBB0_23
LBB0_30:                                ; %else83
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w2, #3, LBB0_24
LBB0_31:                                ; %cond.load85
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x4, x17, #12
	ld1.s	{ v1 }[3], [x4]
	tbnz	w2, #4, LBB0_25
LBB0_32:                                ; %else89
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w2, #5, LBB0_26
LBB0_33:                                ; %cond.load91
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x4, x17, #20
	ld1.s	{ v3 }[1], [x4]
	tbnz	w2, #6, LBB0_27
LBB0_34:                                ; %else95
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x4, sp, #3520
	tbz	w2, #7, LBB0_36
LBB0_35:                                ; %cond.load97
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x17, #28
	ld1.s	{ v3 }[3], [x17]
LBB0_36:                                ; %else98
                                        ;   in Loop: Header=BB0_5 Depth=1
	lsl	x17, x11, #5
	dup.2d	v4, x17
	ldp	q6, q17, [sp, #832]             ; 32-byte Folded Reload
	add.2d	v6, v4, v6
	ldp	q16, q7, [sp, #864]             ; 32-byte Folded Reload
	add.2d	v7, v4, v7
	add.2d	v16, v4, v16
	add.2d	v4, v4, v17
	str	q16, [sp, #1120]
	str	q7, [sp, #1104]
	str	q4, [sp, #1136]
	str	q6, [sp, #1152]
	and	x14, x14, #0x7
	add	x9, sp, #1104
	ldr	x14, [x9, x14, lsl #3]
	sub	x14, x14, x13, lsl #2
	ands	w13, w1, #0x1
	csel	x14, xzr, x14, ne
	add	x14, x15, x14
	ldp	q4, q6, [x14]
	zip2.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bif.16b	v3, v6, v7
	zip1.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bif.16b	v1, v4, v6
	stp	q1, q3, [x14]
	add	x11, x11, #1
	dup.2d	v1, x11
	mov	b3, v21[6]
	mov.b	v3[4], v21[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	bit.16b	v10, v1, v3
	mov	b3, v21[4]
	mov.b	v3[4], v21[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	mov	b4, v21[2]
	mov.b	v4[4], v21[3]
	bit.16b	v25, v1, v3
	ushll.2d	v3, v4, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	bit.16b	v31, v1, v3
	mov	b3, v21[0]
	mov.b	v3[4], v21[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	bit.16b	v14, v1, v3
	cbnz	w13, LBB0_4
	b	LBB0_17
LBB0_37:                                ; %uniform.false
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_38:                                ; %schedule.3
                                        ;   in Loop: Header=BB0_5 Depth=1
	cmle.2d	v1, v22, #0
	cmle.2d	v3, v24, #0
	uzp1.4s	v1, v1, v3
	cmle.2d	v3, v27, #0
	cmle.2d	v4, v28, #0
	uzp1.4s	v3, v3, v4
	uzp1.8h	v1, v1, v3
	xtn.8b	v1, v1
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	bit.8b	v11, v1, v3
	and.8b	v1, v21, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	and.8b	v1, v3, v2
	addv.8b	b1, v1
	umaxv.8b	b3, v3
	fmov	w13, s3
	tbz	w13, #0, LBB0_44
; %bb.39:                               ; %schedule.3
                                        ;   in Loop: Header=BB0_5 Depth=1
	dup.2d	v3, x20
	cmge.2d	v4, v24, v3
	cmge.2d	v6, v22, v3
	uzp1.4s	v4, v6, v4
	cmge.2d	v6, v27, v3
	cmge.2d	v3, v28, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v3, v21, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w13, s3
	tst	w13, #0xff
	b.eq	LBB0_44
; %bb.40:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w11, w12, #1
	csel	w11, wzr, w11, lo
	and	w13, w10, #0xff
	lsr	w14, w13, w11
	tst	w14, #0x1
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #1488]
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #1504]
	and	x11, x11, #0x7
	add	x9, sp, #1488
	ldr	w11, [x9, x11, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w11, #0, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_42
; %bb.41:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w11, #0, LBB0_375
LBB0_42:                                ; %convergence.overflow.resume
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w13, w10
	rbit	w13, w13
	clz	w13, w13
	mov	w9, #255                        ; =0xff
	bics	wzr, w9, w10
	csel	w13, wzr, w13, eq
	ubfiz	x14, x13, #2, #3
	lsl	w17, w20, w13
	ldr	q5, [sp, #1072]                 ; 16-byte Folded Reload
	str	q5, [sp, #1456]
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #1472]
	add	x9, sp, #1456
	ldr	w1, [x9, x14]
	cmp	w11, #0
	csel	w11, w17, wzr, ne
	csel	w17, wzr, w1, ne
	str	q5, [sp, #1424]
	str	q4, [sp, #1440]
	add	x9, sp, #1424
	str	w17, [x9, x14]
	ldr	q4, [sp, #1440]
	str	q4, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #1424]
	str	q4, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1040]                 ; 16-byte Folded Reload
	str	q5, [sp, #1392]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #1408]
	add	x9, sp, #1392
	ldr	w17, [x9, x14]
	csel	w17, w12, w17, ne
	str	q5, [sp, #1360]
	str	q4, [sp, #1376]
	add	x9, sp, #1360
	str	w17, [x9, x14]
	ldrb	w14, [x27, x13]
	and	w17, w14, #0x1
	fmov	s4, w17
	ubfx	w17, w14, #1, #1
	mov.b	v4[1], w17
	ubfx	w17, w14, #2, #1
	mov.b	v4[2], w17
	ubfx	w17, w14, #3, #1
	mov.b	v4[3], w17
	ubfx	w17, w14, #4, #1
	mov.b	v4[4], w17
	ubfx	w17, w14, #5, #1
	mov.b	v4[5], w17
	ubfx	w17, w14, #6, #1
	mov.b	v4[6], w17
	ldr	q5, [sp, #1376]
	str	q5, [sp, #1056]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1360]
	str	q5, [sp, #1040]                 ; 16-byte Folded Spill
	lsr	w14, w14, #7
	mov.b	v4[7], w14
	ldrb	w14, [x8, x13]
	and	w17, w14, #0x1
	fmov	s6, w17
	ubfx	w17, w14, #1, #1
	mov.b	v6[1], w17
	ubfx	w17, w14, #2, #1
	mov.b	v6[2], w17
	ubfx	w17, w14, #3, #1
	mov.b	v6[3], w17
	ubfx	w17, w14, #4, #1
	mov.b	v6[4], w17
	ubfx	w17, w14, #5, #1
	mov.b	v6[5], w17
	ubfx	w17, w14, #6, #1
	mov.b	v6[6], w17
	lsr	w14, w14, #7
	mov.b	v6[7], w14
	csetm	w14, ne
	dup.8b	v7, w14
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x27, x13]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_375
; %bb.43:                               ; %ready.overflow.resume41
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b1, [x21, x28]
	mov	w9, #4                          ; =0x4
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	b.lo	LBB0_2
	b	LBB0_375
LBB0_44:                                ; %varying.coherent
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	w13, s1
	tst	w13, #0xff
	b.eq	LBB0_71
; %bb.45:                               ; %varying.coherent.true
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_46:                                ; %schedule.4
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w13, w11
	clz	w13, w13
	tst	w11, #0xff
	csel	w13, wzr, w13, eq
	ldp	q1, q0, [sp, #672]              ; 32-byte Folded Reload
	str	q0, [sp, #4592]
	str	q1, [sp, #4608]
	ldp	q1, q0, [sp, #640]              ; 32-byte Folded Reload
	str	q0, [sp, #4624]
	str	q1, [sp, #4640]
	ubfiz	x14, x13, #3, #3
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #496
	ldr	x17, [x9, x14]
	str	q22, [sp, #4528]
	str	q24, [sp, #4544]
	str	q27, [sp, #4560]
	str	q28, [sp, #4576]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #432
	ldr	x14, [x9, x14]
	add	x17, x17, x17, lsl #12
	sub	x14, x14, x13
	add	x14, x14, x17
	add	x14, x6, x14, lsl #2
	add	x14, x14, #4, lsl #12           ; =16384
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w17, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w17, #0, LBB0_54
; %bb.47:                               ; %cond.load101
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s1, [x14]
	tbnz	w17, #1, LBB0_55
LBB0_48:                                ; %else105
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #2, LBB0_56
LBB0_49:                                ; %cond.load107
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x1, x14, #8
	ld1.s	{ v1 }[2], [x1]
	tbnz	w17, #3, LBB0_57
LBB0_50:                                ; %else111
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #4, LBB0_58
LBB0_51:                                ; %cond.load113
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x1, x14, #16
	ld1.s	{ v3 }[0], [x1]
	tbnz	w17, #5, LBB0_59
LBB0_52:                                ; %else117
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #6, LBB0_60
LBB0_53:                                ; %cond.load119
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x1, x14, #24
	ld1.s	{ v3 }[2], [x1]
	tbnz	w17, #7, LBB0_61
	b	LBB0_62
LBB0_54:                                ; %else102
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #1, LBB0_48
LBB0_55:                                ; %cond.load104
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x1, x14, #4
	ld1.s	{ v1 }[1], [x1]
	tbnz	w17, #2, LBB0_49
LBB0_56:                                ; %else108
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #3, LBB0_50
LBB0_57:                                ; %cond.load110
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x1, x14, #12
	ld1.s	{ v1 }[3], [x1]
	tbnz	w17, #4, LBB0_51
LBB0_58:                                ; %else114
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #5, LBB0_52
LBB0_59:                                ; %cond.load116
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x1, x14, #20
	ld1.s	{ v3 }[1], [x1]
	tbnz	w17, #6, LBB0_53
LBB0_60:                                ; %else120
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #7, LBB0_62
LBB0_61:                                ; %cond.load122
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x14, x14, #28
	ld1.s	{ v3 }[3], [x14]
LBB0_62:                                ; %else123
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldp	q4, q0, [sp, #864]              ; 32-byte Folded Reload
	str	q0, [sp, #4464]
	str	q4, [sp, #4480]
	ldp	q4, q0, [sp, #832]              ; 32-byte Folded Reload
	str	q0, [sp, #4496]
	str	q4, [sp, #4512]
	and	x14, x13, #0x7
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #368
	ldr	x14, [x9, x14, lsl #3]
	sub	x13, x14, x13, lsl #2
	add	x13, x13, #4, lsl #12           ; =16384
	ands	w11, w11, #0xff
	csel	x13, xzr, x13, eq
	add	x13, x15, x13
	ldp	q4, q6, [x13]
	zip2.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bif.16b	v3, v6, v7
	zip1.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bif.16b	v1, v4, v6
	stp	q1, q3, [x13]
	cbz	w11, LBB0_4
LBB0_63:                                ; %schedule.5
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w12, LBB0_68
; %bb.64:                               ; %convergence.cascade.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w11, #0                         ; =0x0
LBB0_65:                                ; %convergence.cascade
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w13, s3
	umaxv.8b	b1, v1
	fmov	w2, s1
	sub	w14, w12, #1
	tst	w13, #0xff
	csel	w14, w14, wzr, ne
	lsl	w17, w20, w14
	and	w13, w17, w10
	tst	w13, #0xff
	cset	w4, ne
	ldr	q1, [sp, #1072]                 ; 16-byte Folded Reload
	str	q1, [sp, #4432]
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #4448]
	ubfiz	x13, x14, #2, #3
	ldr	w1, [x0, x13]
	cmp	w1, #0
	cset	w1, eq
	and	w2, w4, w2
	ldrb	w4, [x27, w14, sxtw]
	and	w5, w4, #0x1
	fmov	s1, w5
	ubfx	w5, w4, #1, #1
	mov.b	v1[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v1[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v1[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v1[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v1[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v1[6], w5
	lsr	w4, w4, #7
	mov.b	v1[7], w4
	ldrb	w4, [x8, w14, sxtw]
	and	w5, w4, #0x1
	fmov	s3, w5
	ubfx	w5, w4, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v3[6], w5
	lsr	w4, w4, #7
	mov.b	v3[7], w4
	orr.8b	v4, v21, v3
	and.8b	v6, v9, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w4, s6
	ands	w1, w2, w1
	csetm	w2, ne
	bics	w4, w1, w4
	csetm	w5, ne
	dup.8b	v6, w5
	mov	w5, #-1                         ; =0xffffffff
	dup.8b	v7, w2
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	csinv	w14, w5, w17, eq
	dup.8b	v1, w1
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w4
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1040]                 ; 16-byte Folded Reload
	str	q4, [sp, #4400]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #4416]
	ldr	w13, [x16, x13]
	csel	w12, w13, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
	cmp	w1, #1
	b.ne	LBB0_69
; %bb.66:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_65 Depth=2
	cmp	w12, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_69
; %bb.67:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_65 Depth=2
	add	w11, w11, #1
	tst	w13, #0xff
	b.ne	LBB0_65
	b	LBB0_69
LBB0_68:                                ; %schedule.5.convergence.cascade.exit_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
LBB0_69:                                ; %convergence.cascade.exit
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_72
; %bb.70:                               ; %convergence.target.5.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w11, w13
	clz	w11, w11
	ldp	q1, q0, [sp, #864]              ; 32-byte Folded Reload
	str	q0, [sp, #4336]
	str	q1, [sp, #4352]
	ldp	q1, q0, [sp, #832]              ; 32-byte Folded Reload
	str	q0, [sp, #4368]
	str	q1, [sp, #4384]
	and	x13, x11, #0x7
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #240
	ldr	x13, [x9, x13, lsl #3]
	lsl	w11, w11, #2
	sub	x11, x13, x11
	add	x11, x15, x11
	ldp	q1, q3, [x11]
	fmul.4s	v29, v1, v1
	fmul.4s	v3, v3, v3
	ldp	q4, q6, [x11, #32]
	fmul.4s	v0, v4, v4
	stp	q0, q24, [sp, #736]             ; 32-byte Folded Spill
	fmul.4s	v6, v6, v6
	ldp	q7, q16, [x11, #64]
	fmul.4s	v7, v7, v7
	fmul.4s	v16, v16, v16
	mov.16b	v24, v19
	ldp	q19, q17, [x11, #96]
	fmul.4s	v19, v19, v19
	fmul.4s	v17, v17, v17
	mov	b20, v21[6]
	mov.b	v20[4], v21[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	mov	w9, #4                          ; =0x4
	mov.16b	v5, v23
	dup.2d	v23, x9
	ldr	q0, [sp, #912]                  ; 16-byte Folded Reload
	bit.16b	v0, v23, v20
	stp	q27, q0, [sp, #896]             ; 32-byte Folded Spill
	mov	b20, v21[4]
	mov.b	v20[4], v21[5]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	fmov	d1, d9
	mov.16b	v0, v31
	mov.16b	v31, v15
	ldr	q15, [sp, #944]                 ; 16-byte Folded Reload
	bit.16b	v15, v23, v20
	str	q15, [sp, #944]                 ; 16-byte Folded Spill
	mov.16b	v15, v31
	mov.16b	v31, v0
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	fmov	d9, d1
	mov	b20, v21[2]
	mov.b	v20[4], v21[3]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	bit.16b	v13, v23, v20
	mov	b20, v21[0]
	mov.b	v20[4], v21[1]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	bit.16b	v30, v23, v20
	zip1.8b	v20, v21, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmlt.4s	v20, v20, #0
	zip2.8b	v23, v21, v0
	ushll.4s	v23, v23, #0
	shl.4s	v23, v23, #31
	cmlt.4s	v23, v23, #0
	bit.16b	v0, v3, v23
	str	q0, [sp, #928]                  ; 16-byte Folded Spill
	ldr	q3, [sp, #816]                  ; 16-byte Folded Reload
	bit.16b	v3, v29, v20
	str	q3, [sp, #816]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #768]                  ; 16-byte Folded Reload
	bit.16b	v1, v6, v23
	str	q1, [sp, #768]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #560]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #736]                  ; 16-byte Folded Reload
	bit.16b	v1, v0, v20
	str	q1, [sp, #560]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #576]                  ; 16-byte Folded Reload
	bit.16b	v1, v16, v23
	str	q1, [sp, #576]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #592]                  ; 16-byte Folded Reload
	bit.16b	v1, v7, v20
	str	q1, [sp, #592]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #624]                  ; 16-byte Folded Reload
	bit.16b	v1, v17, v23
	str	q1, [sp, #624]                  ; 16-byte Folded Spill
	mov.16b	v23, v5
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	bit.16b	v1, v19, v20
	movi.8b	v20, #1
	mov.16b	v19, v24
	ldr	q24, [sp, #752]                 ; 16-byte Folded Reload
	ldr	q27, [sp, #896]                 ; 16-byte Folded Reload
	str	q1, [sp, #608]                  ; 16-byte Folded Spill
	add	x4, sp, #3520
	b	LBB0_73
LBB0_71:                                ; %varying.coherent.false
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.ne	LBB0_63
	b	LBB0_4
LBB0_72:                                ;   in Loop: Header=BB0_5 Depth=1
	add	x4, sp, #3520
	b	LBB0_4
LBB0_73:                                ; %schedule.6
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
	mov	w9, #512                        ; =0x200
	dup.2d	v3, x9
	cmgt.2d	v1, v3, v13
	cmgt.2d	v4, v3, v30
	uzp1.4s	v1, v4, v1
	ldr	q5, [sp, #944]                  ; 16-byte Folded Reload
	cmgt.2d	v4, v3, v5
	ldr	q0, [sp, #912]                  ; 16-byte Folded Reload
	cmgt.2d	v6, v3, v0
	uzp1.4s	v4, v4, v6
	uzp1.8h	v1, v1, v4
	xtn.8b	v1, v1
	and.8b	v1, v21, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v4, v1, #0
	and.8b	v1, v4, v2
	addv.8b	b1, v1
	fmov	w11, s1
	umaxv.8b	b4, v4
	fmov	w14, s4
	tbz	w14, #0, LBB0_80
; %bb.74:                               ; %schedule.6
                                        ;   in Loop: Header=BB0_5 Depth=1
	cmge.2d	v4, v13, v3
	cmge.2d	v6, v30, v3
	uzp1.4s	v4, v6, v4
	cmge.2d	v6, v5, v3
	ldr	q0, [sp, #912]                  ; 16-byte Folded Reload
	cmge.2d	v3, v0, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v3, v21, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w14, s3
	tst	w14, #0xff
	b.eq	LBB0_80
; %bb.75:                               ; %varying.divergent69
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w11, w12, #1
	csel	w11, wzr, w11, lo
	and	w13, w10, #0xff
	lsr	w14, w13, w11
	tst	w14, #0x1
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #1648]
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #1664]
	and	x11, x11, #0x7
	add	x9, sp, #1648
	ldr	w11, [x9, x11, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w11, #1, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_77
; %bb.76:                               ; %varying.divergent69
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w11, #0, LBB0_375
LBB0_77:                                ; %convergence.overflow.resume72
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w13, w10
	rbit	w13, w13
	clz	w13, w13
	mov	w9, #255                        ; =0xff
	bics	wzr, w9, w10
	csel	w13, wzr, w13, eq
	ubfiz	x14, x13, #2, #3
	lsl	w17, w20, w13
	ldr	q5, [sp, #1072]                 ; 16-byte Folded Reload
	str	q5, [sp, #1616]
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #1632]
	add	x9, sp, #1616
	ldr	w1, [x9, x14]
	cmp	w11, #0
	csel	w11, w17, wzr, ne
	csinc	w17, w1, wzr, eq
	str	q5, [sp, #1584]
	str	q4, [sp, #1600]
	add	x9, sp, #1584
	str	w17, [x9, x14]
	ldr	q4, [sp, #1600]
	str	q4, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #1584]
	str	q4, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1040]                 ; 16-byte Folded Reload
	str	q5, [sp, #1552]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #1568]
	add	x9, sp, #1552
	ldr	w17, [x9, x14]
	csel	w17, w12, w17, ne
	str	q5, [sp, #1520]
	str	q4, [sp, #1536]
	add	x9, sp, #1520
	str	w17, [x9, x14]
	ldrb	w14, [x27, x13]
	and	w17, w14, #0x1
	fmov	s4, w17
	ubfx	w17, w14, #1, #1
	mov.b	v4[1], w17
	ubfx	w17, w14, #2, #1
	mov.b	v4[2], w17
	ubfx	w17, w14, #3, #1
	mov.b	v4[3], w17
	ubfx	w17, w14, #4, #1
	mov.b	v4[4], w17
	ubfx	w17, w14, #5, #1
	mov.b	v4[5], w17
	ubfx	w17, w14, #6, #1
	mov.b	v4[6], w17
	ldr	q5, [sp, #1536]
	str	q5, [sp, #1056]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1520]
	str	q5, [sp, #1040]                 ; 16-byte Folded Spill
	lsr	w14, w14, #7
	mov.b	v4[7], w14
	ldrb	w14, [x8, x13]
	and	w17, w14, #0x1
	fmov	s6, w17
	ubfx	w17, w14, #1, #1
	mov.b	v6[1], w17
	ubfx	w17, w14, #2, #1
	mov.b	v6[2], w17
	ubfx	w17, w14, #3, #1
	mov.b	v6[3], w17
	ubfx	w17, w14, #4, #1
	mov.b	v6[4], w17
	ubfx	w17, w14, #5, #1
	mov.b	v6[5], w17
	ubfx	w17, w14, #6, #1
	mov.b	v6[6], w17
	lsr	w14, w14, #7
	mov.b	v6[7], w14
	csetm	w14, ne
	dup.8b	v7, w14
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x27, x13]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_375
; %bb.78:                               ; %ready.overflow.resume74
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b1, [x21, x28]
	mov	w9, #7                          ; =0x7
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	b.hs	LBB0_375
; %bb.79:                               ; %ready.overflow.resume76
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b3, [x21, w19, uxtw]
	orr	w10, w11, w10
	mov	w9, #8                          ; =0x8
	b	LBB0_3
LBB0_80:                                ; %varying.coherent70
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_150
; %bb.81:                               ; %varying.coherent.true77
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_4
; %bb.82:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	w11, #0                         ; =0x0
LBB0_83:                                ; %schedule.7
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v0, v10
	mov.16b	v10, v15
	mov.16b	v15, v19
	stp	q25, q14, [sp, #160]            ; 32-byte Folded Spill
	str	q31, [sp, #144]                 ; 16-byte Folded Spill
	str	q8, [sp, #480]                  ; 16-byte Folded Spill
	ldr	q4, [sp, #944]                  ; 16-byte Folded Reload
	str	q23, [sp, #720]                 ; 16-byte Folded Spill
	str	q30, [sp, #208]                 ; 16-byte Folded Spill
	shl.2d	v1, v30, #5
	shl.2d	v6, v13, #5
	shl.2d	v3, v4, #5
	ldr	q4, [sp, #912]                  ; 16-byte Folded Reload
	shl.2d	v4, v4, #5
	ldp	q5, q7, [sp, #832]              ; 32-byte Folded Reload
	add.2d	v4, v4, v5
	add.2d	v3, v3, v7
	ldr	q7, [sp, #864]                  ; 16-byte Folded Reload
	add.2d	v16, v6, v7
	ldr	q6, [sp, #880]                  ; 16-byte Folded Reload
	add.2d	v17, v1, v6
	ldp	q1, q5, [sp, #432]              ; 32-byte Folded Reload
	add.2d	v25, v5, v17
	add.2d	v23, v1, v16
	ldp	q1, q5, [sp, #400]              ; 32-byte Folded Reload
	add.2d	v20, v5, v3
	add.2d	v6, v1, v4
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b7, v1
	fmov	w13, s7
	movi.2d	v1, #0000000000000000
	movi.2d	v19, #0000000000000000
	stp	q12, q26, [sp, #368]            ; 32-byte Folded Spill
	stp	q10, q15, [sp, #224]            ; 32-byte Folded Spill
	stp	q18, q24, [sp, #736]            ; 32-byte Folded Spill
	str	q13, [sp, #192]                 ; 16-byte Folded Spill
	str	q22, [sp, #464]                 ; 16-byte Folded Spill
	str	q27, [sp, #896]                 ; 16-byte Folded Spill
	str	q28, [sp, #704]                 ; 16-byte Folded Spill
	str	q11, [sp, #352]                 ; 16-byte Folded Spill
	tbz	w13, #0, LBB0_92
; %bb.84:                               ; %cond.load126
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d25
	ldr	s1, [x14]
	tbnz	w13, #1, LBB0_93
LBB0_85:                                ; %else130
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #2, LBB0_94
LBB0_86:                                ; %cond.load132
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d23
	ld1.s	{ v1 }[2], [x14]
	fmov	d11, d9
	tbnz	w13, #3, LBB0_95
LBB0_87:                                ;   in Loop: Header=BB0_5 Depth=1
	ldr	q18, [sp, #1024]                ; 16-byte Folded Reload
	ldr	q23, [sp, #592]                 ; 16-byte Folded Reload
	tbz	w13, #4, LBB0_96
LBB0_88:                                ; %cond.load138
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldp	q8, q13, [sp, #976]             ; 32-byte Folded Reload
	ldr	q29, [sp, #1008]                ; 16-byte Folded Reload
	fmov	x14, d20
	ld1.s	{ v19 }[0], [x14]
	ldp	q5, q24, [sp, #560]             ; 32-byte Folded Reload
	mov.16b	v22, v23
	tbz	w13, #5, LBB0_90
LBB0_89:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v20[1]
	ld1.s	{ v19 }[1], [x14]
LBB0_90:                                ; %else142
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #6, LBB0_97
; %bb.91:                               ; %cond.load144
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d6
	ld1.s	{ v19 }[2], [x14]
	tbnz	w13, #7, LBB0_98
	b	LBB0_99
LBB0_92:                                ; %else127
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #1, LBB0_85
LBB0_93:                                ; %cond.load129
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v25[1]
	ld1.s	{ v1 }[1], [x14]
	tbnz	w13, #2, LBB0_86
LBB0_94:                                ; %else133
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	d11, d9
	tbz	w13, #3, LBB0_87
LBB0_95:                                ; %cond.load135
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q18, [sp, #1024]                ; 16-byte Folded Reload
	mov.d	x14, v23[1]
	ld1.s	{ v1 }[3], [x14]
	ldr	q23, [sp, #592]                 ; 16-byte Folded Reload
	tbnz	w13, #4, LBB0_88
LBB0_96:                                ;   in Loop: Header=BB0_5 Depth=1
	ldp	q8, q13, [sp, #976]             ; 32-byte Folded Reload
	ldr	q29, [sp, #1008]                ; 16-byte Folded Reload
	ldp	q5, q24, [sp, #560]             ; 32-byte Folded Reload
	mov.16b	v22, v23
	tbnz	w13, #5, LBB0_89
	b	LBB0_90
LBB0_97:                                ; %else145
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #7, LBB0_99
LBB0_98:                                ; %cond.load147
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v6[1]
	ld1.s	{ v19 }[3], [x13]
LBB0_99:                                ; %else148
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmul.4s	v6, v19, v19
	fmul.4s	v1, v1, v1
	ldr	q19, [sp, #816]                 ; 16-byte Folded Reload
	fadd.4s	v1, v19, v1
	str	q1, [sp, #592]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #928]                  ; 16-byte Folded Reload
	fadd.4s	v1, v1, v6
	str	q1, [sp, #304]                  ; 16-byte Folded Spill
	ldp	q6, q1, [sp, #400]              ; 32-byte Folded Reload
	add.2d	v23, v4, v6
	add.2d	v3, v3, v1
	ldp	q1, q6, [sp, #432]              ; 32-byte Folded Reload
	add.2d	v4, v17, v6
	add.2d	v20, v16, v1
	mov	w9, #32                         ; =0x20
	dup.2d	v16, x9
	add.2d	v25, v20, v16
	add.2d	v31, v4, v16
	add.2d	v30, v3, v16
	add.2d	v19, v23, v16
	fmov	w13, s7
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w13, #0, LBB0_107
; %bb.100:                              ; %cond.load151
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d31
	ldr	s16, [x14]
	tbnz	w13, #1, LBB0_108
LBB0_101:                               ; %else161
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #2, LBB0_109
LBB0_102:                               ; %cond.load163
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d25
	ld1.s	{ v16 }[2], [x14]
	str	q18, [sp, #1024]                ; 16-byte Folded Spill
	tbnz	w13, #3, LBB0_110
LBB0_103:                               ; %else173
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q12, [sp, #800]                 ; 16-byte Folded Reload
	tbz	w13, #4, LBB0_111
LBB0_104:                               ; %cond.load175
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d30
	ld1.s	{ v17 }[0], [x14]
	stp	q8, q13, [sp, #976]             ; 32-byte Folded Spill
	str	q29, [sp, #1008]                ; 16-byte Folded Spill
	tbnz	w13, #5, LBB0_112
LBB0_105:                               ; %else185
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #6, LBB0_113
LBB0_106:                               ; %cond.load187
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d19
	ld1.s	{ v17 }[2], [x14]
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	fmov	d1, d11
	stp	q15, q12, [sp, #784]            ; 32-byte Folded Spill
	tbnz	w13, #7, LBB0_114
	b	LBB0_115
LBB0_107:                               ; %else155
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #1, LBB0_101
LBB0_108:                               ; %cond.load157
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v31[1]
	ld1.s	{ v16 }[1], [x14]
	tbnz	w13, #2, LBB0_102
LBB0_109:                               ; %else167
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	q18, [sp, #1024]                ; 16-byte Folded Spill
	tbz	w13, #3, LBB0_103
LBB0_110:                               ; %cond.load169
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v25[1]
	ld1.s	{ v16 }[3], [x14]
	ldr	q12, [sp, #800]                 ; 16-byte Folded Reload
	tbnz	w13, #4, LBB0_104
LBB0_111:                               ; %else179
                                        ;   in Loop: Header=BB0_5 Depth=1
	stp	q8, q13, [sp, #976]             ; 32-byte Folded Spill
	str	q29, [sp, #1008]                ; 16-byte Folded Spill
	tbz	w13, #5, LBB0_105
LBB0_112:                               ; %cond.load181
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v30[1]
	ld1.s	{ v17 }[1], [x14]
	tbnz	w13, #6, LBB0_106
LBB0_113:                               ; %else191
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	fmov	d1, d11
	stp	q15, q12, [sp, #784]            ; 32-byte Folded Spill
	tbz	w13, #7, LBB0_115
LBB0_114:                               ; %cond.load193
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v19[1]
	ld1.s	{ v17 }[3], [x13]
LBB0_115:                               ; %else197
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmul.4s	v17, v17, v17
	fmul.4s	v16, v16, v16
	fadd.4s	v6, v5, v16
	str	q6, [sp, #288]                  ; 16-byte Folded Spill
	ldr	q16, [sp, #768]                 ; 16-byte Folded Reload
	fadd.4s	v15, v16, v17
	mov	w9, #64                         ; =0x40
	dup.2d	v16, x9
	add.2d	v31, v20, v16
	add.2d	v12, v4, v16
	add.2d	v25, v3, v16
	add.2d	v30, v23, v16
	fmov	w13, s7
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w13, #0, LBB0_123
; %bb.116:                              ; %cond.load200
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d12
	ldr	s16, [x14]
	tbnz	w13, #1, LBB0_124
LBB0_117:                               ; %else210
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #2, LBB0_125
LBB0_118:                               ; %cond.load212
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d31
	ld1.s	{ v16 }[2], [x14]
	tbnz	w13, #3, LBB0_126
LBB0_119:                               ; %else222
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #4, LBB0_127
LBB0_120:                               ; %cond.load224
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d25
	ld1.s	{ v17 }[0], [x14]
	tbnz	w13, #5, LBB0_128
LBB0_121:                               ; %else234
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #6, LBB0_129
LBB0_122:                               ; %cond.load236
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d30
	ld1.s	{ v17 }[2], [x14]
	tbnz	w13, #7, LBB0_130
	b	LBB0_131
LBB0_123:                               ; %else204
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #1, LBB0_117
LBB0_124:                               ; %cond.load206
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v12[1]
	ld1.s	{ v16 }[1], [x14]
	tbnz	w13, #2, LBB0_118
LBB0_125:                               ; %else216
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #3, LBB0_119
LBB0_126:                               ; %cond.load218
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v31[1]
	ld1.s	{ v16 }[3], [x14]
	tbnz	w13, #4, LBB0_120
LBB0_127:                               ; %else228
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #5, LBB0_121
LBB0_128:                               ; %cond.load230
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v25[1]
	ld1.s	{ v17 }[1], [x14]
	tbnz	w13, #6, LBB0_122
LBB0_129:                               ; %else240
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #7, LBB0_131
LBB0_130:                               ; %cond.load242
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v30[1]
	ld1.s	{ v17 }[3], [x13]
LBB0_131:                               ; %else246
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmul.4s	v17, v17, v17
	fmul.4s	v16, v16, v16
	fadd.4s	v16, v22, v16
	fadd.4s	v17, v24, v17
	mov	w9, #96                         ; =0x60
	dup.2d	v12, x9
	add.2d	v30, v20, v12
	add.2d	v31, v4, v12
	add.2d	v25, v3, v12
	add.2d	v20, v23, v12
	fmov	w13, s7
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w13, #0, LBB0_135
; %bb.132:                              ; %cond.load249
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d31
	ldr	s3, [x14]
	tbnz	w13, #1, LBB0_136
LBB0_133:                               ; %else259
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q11, [sp, #960]                 ; 16-byte Folded Reload
	ldr	q27, [sp, #352]                 ; 16-byte Folded Reload
	fmov	d9, d1
	ldr	q19, [sp, #144]                 ; 16-byte Folded Reload
	tbz	w13, #2, LBB0_137
LBB0_134:                               ; %cond.load261
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d30
	ld1.s	{ v3 }[2], [x14]
	ldr	q13, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	ldr	q10, [sp, #176]                 ; 16-byte Folded Reload
	mov.16b	v12, v0
	tbnz	w13, #3, LBB0_138
	b	LBB0_139
LBB0_135:                               ; %else253
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #1, LBB0_133
LBB0_136:                               ; %cond.load255
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v31[1]
	ld1.s	{ v3 }[1], [x14]
	ldr	q11, [sp, #960]                 ; 16-byte Folded Reload
	ldr	q27, [sp, #352]                 ; 16-byte Folded Reload
	fmov	d9, d1
	ldr	q19, [sp, #144]                 ; 16-byte Folded Reload
	tbnz	w13, #2, LBB0_134
LBB0_137:                               ; %else265
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q13, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	ldr	q10, [sp, #176]                 ; 16-byte Folded Reload
	mov.16b	v12, v0
	tbz	w13, #3, LBB0_139
LBB0_138:                               ; %cond.load267
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v30[1]
	ld1.s	{ v3 }[3], [x14]
LBB0_139:                               ; %else271
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q18, [sp, #624]                 ; 16-byte Folded Reload
	ldr	q28, [sp, #192]                 ; 16-byte Folded Reload
	mov.16b	v23, v22
	mov.16b	v26, v5
	ldr	q5, [sp, #768]                  ; 16-byte Folded Reload
	ldr	q29, [sp, #816]                 ; 16-byte Folded Reload
	ldp	q31, q14, [sp, #928]            ; 32-byte Folded Reload
	tbz	w13, #4, LBB0_143
; %bb.140:                              ; %cond.load273
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d25
	ld1.s	{ v4 }[0], [x14]
	ldr	q22, [sp, #464]                 ; 16-byte Folded Reload
	ldr	q8, [sp, #752]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #896]                  ; 16-byte Folded Reload
	ldr	q6, [sp, #704]                  ; 16-byte Folded Reload
	tbnz	w13, #5, LBB0_144
LBB0_141:                               ; %else283
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q30, [sp, #208]                 ; 16-byte Folded Reload
	tbz	w13, #6, LBB0_145
LBB0_142:                               ; %cond.load285
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d20
	ld1.s	{ v4 }[2], [x14]
	tbnz	w13, #7, LBB0_146
	b	LBB0_147
LBB0_143:                               ; %else277
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q22, [sp, #464]                 ; 16-byte Folded Reload
	ldr	q8, [sp, #752]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #896]                  ; 16-byte Folded Reload
	ldr	q6, [sp, #704]                  ; 16-byte Folded Reload
	tbz	w13, #5, LBB0_141
LBB0_144:                               ; %cond.load279
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v25[1]
	ld1.s	{ v4 }[1], [x14]
	ldr	q30, [sp, #208]                 ; 16-byte Folded Reload
	tbnz	w13, #6, LBB0_142
LBB0_145:                               ; %else289
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #7, LBB0_147
LBB0_146:                               ; %cond.load291
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v20[1]
	ld1.s	{ v4 }[3], [x13]
LBB0_147:                               ; %else295
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmul.4s	v4, v4, v4
	fmul.4s	v3, v3, v3
	fadd.4s	v3, v1, v3
	mov	w9, #4                          ; =0x4
	dup.2d	v7, x9
	mov	b20, v21[6]
	mov.b	v20[4], v21[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v20, v20, v7
	add.2d	v13, v13, v20
	mov	b20, v21[4]
	mov.b	v20[4], v21[5]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v20, v20, v7
	add.2d	v14, v14, v20
	str	q14, [sp, #944]                 ; 16-byte Folded Spill
	mov	b20, v21[2]
	mov.b	v20[4], v21[3]
	fadd.4s	v4, v18, v4
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v20, v20, v7
	add.2d	v28, v28, v20
	mov	b20, v21[0]
	mov.b	v20[4], v21[1]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v7, v20, v7
	add.2d	v30, v30, v7
	zip1.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	zip2.8b	v20, v21, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmlt.4s	v20, v20, #0
	ldr	q25, [sp, #304]                 ; 16-byte Folded Reload
	bit.16b	v31, v25, v20
	ldr	q25, [sp, #592]                 ; 16-byte Folded Reload
	bit.16b	v29, v25, v7
	str	q29, [sp, #816]                 ; 16-byte Folded Spill
	bit.16b	v5, v15, v20
	str	q5, [sp, #768]                  ; 16-byte Folded Spill
	ldr	q5, [sp, #288]                  ; 16-byte Folded Reload
	bit.16b	v26, v5, v7
	bit.16b	v24, v17, v20
	stp	q26, q24, [sp, #560]            ; 32-byte Folded Spill
	bit.16b	v23, v16, v7
	bit.16b	v18, v4, v20
	str	q18, [sp, #624]                 ; 16-byte Folded Spill
	bit.16b	v1, v3, v7
	stp	q23, q1, [sp, #592]             ; 32-byte Folded Spill
	str	q11, [sp, #960]                 ; 16-byte Folded Spill
	stp	q13, q31, [sp, #912]            ; 32-byte Folded Spill
	movi.8b	v20, #1
	tbz	w11, #0, LBB0_149
; %bb.148:                              ;   in Loop: Header=BB0_5 Depth=1
	ldp	q23, q18, [sp, #720]            ; 32-byte Folded Reload
	ldr	q7, [sp, #480]                  ; 16-byte Folded Reload
	ldp	q14, q26, [sp, #368]            ; 32-byte Folded Reload
	ldp	q15, q17, [sp, #224]            ; 32-byte Folded Reload
	ldr	q25, [sp, #160]                 ; 16-byte Folded Reload
	mov.16b	v16, v12
	mov.16b	v12, v14
	mov.16b	v11, v27
	mov.16b	v1, v19
	mov.16b	v19, v17
	mov.16b	v24, v8
	mov.16b	v8, v7
	mov.16b	v13, v28
	mov.16b	v28, v6
	mov.16b	v14, v10
	mov.16b	v27, v0
	mov.16b	v31, v1
	mov.16b	v10, v16
	b	LBB0_4
LBB0_149:                               ;   in Loop: Header=BB0_5 Depth=1
	ldp	q23, q18, [sp, #720]            ; 32-byte Folded Reload
	ldr	q7, [sp, #480]                  ; 16-byte Folded Reload
	ldp	q14, q26, [sp, #368]            ; 32-byte Folded Reload
	ldp	q15, q17, [sp, #224]            ; 32-byte Folded Reload
	ldr	q25, [sp, #160]                 ; 16-byte Folded Reload
	mov.16b	v16, v12
	mov.16b	v12, v14
	mov.16b	v11, v27
	mov.16b	v1, v19
	mov.16b	v19, v17
	mov.16b	v24, v8
	mov.16b	v8, v7
	mov.16b	v13, v28
	mov.16b	v28, v6
	mov.16b	v14, v10
	mov.16b	v27, v0
	mov.16b	v31, v1
	mov.16b	v10, v16
	b	LBB0_73
LBB0_150:                               ; %varying.coherent.false78
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_4
LBB0_151:                               ; %schedule.8
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w12, LBB0_156
; %bb.152:                              ; %convergence.cascade92.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w13, #0                         ; =0x0
LBB0_153:                               ; %convergence.cascade92
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w2, s1
	sub	w14, w12, #1
	tst	w11, #0xff
	csel	w14, w14, wzr, ne
	lsl	w17, w20, w14
	and	w11, w17, w10
	tst	w11, #0xff
	cset	w4, ne
	ldr	q1, [sp, #1072]                 ; 16-byte Folded Reload
	str	q1, [sp, #4304]
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #4320]
	ubfiz	x11, x14, #2, #3
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #208
	ldr	w1, [x9, x11]
	cmp	w1, #1
	cset	w1, eq
	and	w2, w4, w2
	ldrb	w4, [x27, w14, sxtw]
	and	w5, w4, #0x1
	fmov	s1, w5
	ubfx	w5, w4, #1, #1
	mov.b	v1[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v1[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v1[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v1[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v1[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v1[6], w5
	lsr	w4, w4, #7
	mov.b	v1[7], w4
	ldrb	w4, [x8, w14, sxtw]
	and	w5, w4, #0x1
	fmov	s3, w5
	ubfx	w5, w4, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v3[6], w5
	lsr	w4, w4, #7
	mov.b	v3[7], w4
	orr.8b	v4, v21, v3
	and.8b	v6, v9, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w4, s6
	ands	w1, w2, w1
	csetm	w2, ne
	bics	w4, w1, w4
	csetm	w5, ne
	dup.8b	v6, w5
	mov	w5, #-1                         ; =0xffffffff
	dup.8b	v7, w2
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	csinv	w14, w5, w17, eq
	dup.8b	v1, w1
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w4
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1040]                 ; 16-byte Folded Reload
	str	q4, [sp, #4272]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #4288]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #176
	ldr	w11, [x9, x11]
	csel	w12, w11, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w1, #1
	b.ne	LBB0_157
; %bb.154:                              ; %convergence.cascade92
                                        ;   in Loop: Header=BB0_153 Depth=2
	cmp	w12, #0
	ccmp	w13, #6, #2, ne
	b.hi	LBB0_157
; %bb.155:                              ; %convergence.cascade92
                                        ;   in Loop: Header=BB0_153 Depth=2
	add	w13, w13, #1
	tst	w11, #0xff
	b.ne	LBB0_153
	b	LBB0_157
LBB0_156:                               ; %schedule.8.convergence.cascade.exit93_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_157:                               ; %convergence.cascade.exit93
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_72
; %bb.158:                              ; %convergence.target.8.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v1, v11, v21
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b4, v3
	umaxv.8b	b1, v1
	fmov	w13, s1
	add	x4, sp, #3520
	tbz	w13, #0, LBB0_165
; %bb.159:                              ; %convergence.target.8.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v3, v21, v11
	shl.8b	v1, v3, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
	tst	w13, #0xff
	b.eq	LBB0_165
; %bb.160:                              ; %varying.divergent110
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w11, w12, #1
	csel	w11, wzr, w11, lo
	and	w13, w10, #0xff
	lsr	w14, w13, w11
	tst	w14, #0x1
	ldr	q5, [sp, #1072]                 ; 16-byte Folded Reload
	str	q5, [sp, #1808]
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	str	q5, [sp, #1824]
	and	x11, x11, #0x7
	add	x9, sp, #1808
	ldr	w11, [x9, x11, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w11, #2, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_162
; %bb.161:                              ; %varying.divergent110
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w11, #0, LBB0_375
LBB0_162:                               ; %convergence.overflow.resume113
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w13, w10
	rbit	w13, w13
	clz	w13, w13
	mov	w9, #255                        ; =0xff
	bics	wzr, w9, w10
	csel	w13, wzr, w13, eq
	ubfiz	x14, x13, #2, #3
	lsl	w17, w20, w13
	ldr	q6, [sp, #1072]                 ; 16-byte Folded Reload
	str	q6, [sp, #1776]
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	str	q5, [sp, #1792]
	add	x9, sp, #1776
	ldr	w1, [x9, x14]
	cmp	w11, #0
	csel	w11, w17, wzr, ne
	mov	w9, #2                          ; =0x2
	csel	w17, w9, w1, ne
	str	q6, [sp, #1744]
	str	q5, [sp, #1760]
	add	x9, sp, #1744
	str	w17, [x9, x14]
	ldr	q5, [sp, #1760]
	str	q5, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1744]
	str	q5, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1040]                 ; 16-byte Folded Reload
	str	q6, [sp, #1712]
	ldr	q5, [sp, #1056]                 ; 16-byte Folded Reload
	str	q5, [sp, #1728]
	add	x9, sp, #1712
	ldr	w17, [x9, x14]
	csel	w17, w12, w17, ne
	str	q6, [sp, #1680]
	str	q5, [sp, #1696]
	add	x9, sp, #1680
	str	w17, [x9, x14]
	ldrb	w14, [x27, x13]
	and	w17, w14, #0x1
	fmov	s6, w17
	ubfx	w17, w14, #1, #1
	mov.b	v6[1], w17
	ubfx	w17, w14, #2, #1
	mov.b	v6[2], w17
	ubfx	w17, w14, #3, #1
	mov.b	v6[3], w17
	ubfx	w17, w14, #4, #1
	mov.b	v6[4], w17
	ubfx	w17, w14, #5, #1
	mov.b	v6[5], w17
	ubfx	w17, w14, #6, #1
	mov.b	v6[6], w17
	ldr	q5, [sp, #1696]
	str	q5, [sp, #1056]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1680]
	str	q5, [sp, #1040]                 ; 16-byte Folded Spill
	lsr	w14, w14, #7
	mov.b	v6[7], w14
	ldrb	w14, [x8, x13]
	and	w17, w14, #0x1
	fmov	s7, w17
	ubfx	w17, w14, #1, #1
	mov.b	v7[1], w17
	ubfx	w17, w14, #2, #1
	mov.b	v7[2], w17
	ubfx	w17, w14, #3, #1
	mov.b	v7[3], w17
	ubfx	w17, w14, #4, #1
	mov.b	v7[4], w17
	ubfx	w17, w14, #5, #1
	mov.b	v7[5], w17
	ubfx	w17, w14, #6, #1
	mov.b	v7[6], w17
	lsr	w14, w14, #7
	mov.b	v7[7], w14
	csetm	w14, ne
	dup.8b	v16, w14
	bit.8b	v6, v21, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	str	b6, [x27, x13]
	bic.8b	v6, v7, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	str	b6, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_375
; %bb.163:                              ; %ready.overflow.resume116
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b4, [x21, x28]
	mov	w9, #9                          ; =0x9
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	b.hs	LBB0_375
; %bb.164:                              ; %ready.overflow.resume118
                                        ;   in Loop: Header=BB0_5 Depth=1
	orr	w10, w11, w10
	zip2.8b	v4, v3, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q5, [sp, #336]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	bit.16b	v5, v0, v4
	zip1.8b	v3, v3, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	str	b1, [x21, w19, uxtw]
	ldr	q1, [sp, #320]                  ; 16-byte Folded Reload
	ldr	q4, [sp, #816]                  ; 16-byte Folded Reload
	bit.16b	v1, v4, v3
	stp	q1, q5, [sp, #320]              ; 32-byte Folded Spill
	mov	w9, #10                         ; =0xa
	str	w9, [x22, w19, uxtw #2]
	str	w12, [x23, w19, uxtw #2]
	add	w26, w19, #1
	b	LBB0_4
LBB0_165:                               ; %varying.coherent111
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	w13, s4
	tst	w13, #0xff
	b.eq	LBB0_172
LBB0_166:                               ; %schedule.9
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w13, w11
	clz	w13, w13
	tst	w11, #0xff
	csel	w13, wzr, w13, eq
	ldp	q1, q0, [sp, #864]              ; 32-byte Folded Reload
	str	q0, [sp, #4208]
	str	q1, [sp, #4224]
	ldp	q1, q0, [sp, #832]              ; 32-byte Folded Reload
	str	q0, [sp, #4240]
	str	q1, [sp, #4256]
	and	x14, x13, #0x7
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #112
	ldr	x14, [x9, x14, lsl #3]
	lsl	w13, w13, #2
	sub	x13, x14, x13
	ands	w11, w11, #0xff
	add	x13, x13, #4, lsl #12           ; =16384
	csel	x13, xzr, x13, eq
	add	x13, x15, x13
	ldp	q3, q1, [x13]
	zip1.8b	v4, v21, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v3, v4, v3
	zip2.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v1, v6, v1
	fmul.4s	v1, v1, v1
	fmul.4s	v3, v3, v3
	ldr	q5, [sp, #816]                  ; 16-byte Folded Reload
	fadd.4s	v3, v5, v3
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	fadd.4s	v1, v0, v1
	ldr	q5, [sp, #336]                  ; 16-byte Folded Reload
	bit.16b	v5, v1, v6
	ldr	q1, [sp, #320]                  ; 16-byte Folded Reload
	bit.16b	v1, v3, v4
	stp	q1, q5, [sp, #320]              ; 32-byte Folded Spill
	cbz	w11, LBB0_4
LBB0_167:                               ; %schedule.10
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	x28, [sp, #136]                 ; 8-byte Folded Spill
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #80
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #48
	cbz	w12, LBB0_173
LBB0_168:                               ; %convergence.cascade126.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w13, #0                         ; =0x0
LBB0_169:                               ; %convergence.cascade126
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w2, s1
	sub	w14, w12, #1
	tst	w11, #0xff
	csel	w14, w14, wzr, ne
	lsl	w17, w20, w14
	and	w11, w17, w10
	tst	w11, #0xff
	cset	w4, ne
	ldr	q1, [sp, #1072]                 ; 16-byte Folded Reload
	str	q1, [sp, #4176]
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #4192]
	ubfiz	x11, x14, #2, #3
	ldr	w1, [x16, x11]
	cmp	w1, #2
	cset	w1, eq
	and	w2, w4, w2
	ldrb	w4, [x27, w14, sxtw]
	and	w5, w4, #0x1
	fmov	s1, w5
	ubfx	w5, w4, #1, #1
	mov.b	v1[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v1[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v1[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v1[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v1[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v1[6], w5
	lsr	w4, w4, #7
	mov.b	v1[7], w4
	ldrb	w4, [x8, w14, sxtw]
	and	w5, w4, #0x1
	fmov	s3, w5
	ubfx	w5, w4, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v3[6], w5
	lsr	w4, w4, #7
	mov.b	v3[7], w4
	orr.8b	v4, v21, v3
	and.8b	v6, v9, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w4, s6
	ands	w1, w2, w1
	csetm	w2, ne
	bics	w4, w1, w4
	csetm	w5, ne
	dup.8b	v6, w5
	dup.8b	v7, w2
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	mov	w9, #-1                         ; =0xffffffff
	csinv	w14, w9, w17, eq
	dup.8b	v1, w1
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w4
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1040]                 ; 16-byte Folded Reload
	str	q4, [sp, #4144]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #4160]
	ldr	w11, [x0, x11]
	csel	w12, w11, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w1, #1
	b.ne	LBB0_174
; %bb.170:                              ; %convergence.cascade126
                                        ;   in Loop: Header=BB0_169 Depth=2
	cmp	w12, #0
	ccmp	w13, #6, #2, ne
	b.hi	LBB0_174
; %bb.171:                              ; %convergence.cascade126
                                        ;   in Loop: Header=BB0_169 Depth=2
	add	w13, w13, #1
	tst	w11, #0xff
	b.ne	LBB0_169
	b	LBB0_174
LBB0_172:                               ; %varying.coherent.false120
                                        ;   in Loop: Header=BB0_5 Depth=1
	zip2.8b	v1, v21, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #336]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	bit.16b	v3, v0, v1
	str	q3, [sp, #336]                  ; 16-byte Folded Spill
	zip1.8b	v1, v21, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #320]                  ; 16-byte Folded Reload
	ldr	q4, [sp, #816]                  ; 16-byte Folded Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #320]                  ; 16-byte Folded Spill
	str	x28, [sp, #136]                 ; 8-byte Folded Spill
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #80
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #48
	cbnz	w12, LBB0_168
LBB0_173:                               ; %schedule.10.convergence.cascade.exit127_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_174:                               ; %convergence.cascade.exit127
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_176
; %bb.175:                              ; %convergence.target.10.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q1, [sp, #336]                  ; 16-byte Folded Reload
	ldr	q3, [sp, #768]                  ; 16-byte Folded Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #320]                  ; 16-byte Folded Reload
	ldr	q4, [sp, #560]                  ; 16-byte Folded Reload
	fadd.4s	v3, v4, v3
	ldp	q4, q0, [sp, #576]              ; 32-byte Folded Reload
	fadd.4s	v3, v0, v3
	fadd.4s	v1, v4, v1
	ldr	q4, [sp, #624]                  ; 16-byte Folded Reload
	fadd.4s	v6, v4, v1
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	fadd.4s	v7, v1, v3
	mov.16b	v29, v24
	mov.16b	v24, v31
	uzp1.4s	v31, v22, v29
	uzp1.4s	v0, v27, v28
	movi.4s	v4, #1
	eor.16b	v3, v31, v4
	mov.s	w13, v3[1]
	eor.16b	v4, v0, v4
	mov.s	w17, v3[2]
	mov.s	w2, v3[3]
	fmov	w14, s3
	cmp	w14, #8
	csel	w14, w14, wzr, lo
	cset	w4, lo
	and	x5, x14, #0x7
	add	x1, sp, #3560
	bfxil	x1, x14, #0, #3
	str	d21, [sp, #3560]
	ldrb	w14, [x1]
	umov.b	w15, v21[0]
	str	w15, [sp, #752]                 ; 4-byte Folded Spill
	and	w14, w4, w14
	str	q7, [sp, #3984]
	str	q6, [sp, #4000]
	add	x9, sp, #3984
	ldr	s3, [x9, x5, lsl #2]
	ands	w23, w15, #0x1
	tst	w23, w14
	str	q23, [sp, #720]                 ; 16-byte Folded Spill
	movi	d23, #0000000000000000
	fcsel	s3, s3, s23, ne
	cmp	w13, #8
	csel	w13, w13, wzr, lo
	cset	w4, lo
	and	x5, x13, #0x7
	add	x14, sp, #3560
	bfxil	x14, x13, #0, #3
	ldrb	w13, [x14]
	umov.b	w14, v21[1]
	str	w14, [sp, #480]                 ; 4-byte Folded Spill
	and	w13, w4, w13
	str	q7, [sp, #3952]
	str	q6, [sp, #3968]
	add	x9, sp, #3952
	ldr	s16, [x9, x5, lsl #2]
	mov	x15, x3
	mov	x3, x7
	ands	w7, w14, #0x1
	tst	w7, w13
	fcsel	s17, s16, s23, ne
	cmp	w17, #8
	csel	w13, w17, wzr, lo
	cset	w17, lo
	and	x4, x13, #0x7
	add	x5, sp, #3560
	bfxil	x5, x13, #0, #3
	ldrb	w13, [x5]
	umov.b	w5, v21[2]
	str	q7, [sp, #3920]
	str	q6, [sp, #3936]
	add	x9, sp, #3920
	ldr	s16, [x9, x4, lsl #2]
	and	w13, w17, w13
	mov	x14, x6
	ands	w6, w5, #0x1
	tst	w6, w13
	fcsel	s16, s16, s23, ne
	cmp	w2, #8
	csel	w17, w2, wzr, lo
	cset	w13, lo
	and	x4, x17, #0x7
	add	x2, sp, #3560
	bfxil	x2, x17, #0, #3
	umov.b	w1, v21[3]
	ldrb	w20, [x2]
	mov.s	w2, v4[1]
	mov.s	w17, v4[2]
	str	q7, [sp, #3888]
	str	q6, [sp, #3904]
	mov.s	w24, v4[3]
	fmov	w21, s4
	add	x9, sp, #3888
	ldr	s4, [x9, x4, lsl #2]
	and	w13, w13, w20
	ands	w4, w1, #0x1
	tst	w4, w13
	str	q11, [sp, #352]                 ; 16-byte Folded Spill
	fcsel	s20, s4, s23, ne
	cmp	w21, #8
	csel	w13, w21, wzr, lo
	cset	w20, lo
	and	x21, x13, #0x7
	add	x22, sp, #3560
	bfxil	x22, x13, #0, #3
	umov.b	w30, v21[4]
	ldrb	w13, [x22]
	and	w20, w20, w13
	str	q7, [sp, #4112]
	str	q6, [sp, #4128]
	mov.s	v3[1], v17[0]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #16
	ldr	s4, [x9, x21, lsl #2]
	ands	w13, w30, #0x1
	tst	w13, w20
	fcsel	s4, s4, s23, ne
	cmp	w2, #8
	csel	w2, w2, wzr, lo
	cset	w20, lo
	and	x21, x2, #0x7
	add	x22, sp, #3560
	bfxil	x22, x2, #0, #3
	ldrb	w2, [x22]
	umov.b	w22, v21[5]
	and	w2, w20, w2
	mov.s	v3[2], v16[0]
	str	q7, [sp, #4080]
	str	q6, [sp, #4096]
	add	x9, sp, #4080
	ldr	s16, [x9, x21, lsl #2]
	ands	w21, w22, #0x1
	tst	w21, w2
	fcsel	s16, s16, s23, ne
	cmp	w17, #8
	csel	w17, w17, wzr, lo
	cset	w2, lo
	mov	x28, x25
	and	x25, x17, #0x7
	add	x20, sp, #3560
	bfxil	x20, x17, #0, #3
	ldrb	w17, [x20]
	umov.b	w20, v21[6]
	and	w17, w2, w17
	str	q7, [sp, #4048]
	str	q6, [sp, #4064]
	mov.s	v3[3], v20[0]
	add	x9, sp, #4048
	ldr	s17, [x9, x25, lsl #2]
	ands	w2, w20, #0x1
	tst	w2, w17
	fcsel	s17, s17, s23, ne
	cmp	w24, #8
	csel	w17, w24, wzr, lo
	cset	w24, lo
	and	x25, x17, #0x7
	add	x16, sp, #3560
	bfxil	x16, x17, #0, #3
	ldrb	w16, [x16]
	umov.b	w17, v21[7]
	and	w16, w24, w16
	str	q7, [sp, #4016]
	str	q6, [sp, #4032]
	mov.s	v4[1], v16[0]
	add	x9, sp, #4016
	ldr	s16, [x9, x25, lsl #2]
	ands	w24, w17, #0x1
	tst	w24, w16
	fcsel	s20, s16, s23, ne
	str	q28, [sp, #704]                 ; 16-byte Folded Spill
	str	q27, [sp, #896]                 ; 16-byte Folded Spill
	mov.16b	v16, v15
	mov.16b	v28, v22
	stp	q12, q26, [sp, #368]            ; 32-byte Folded Spill
	str	q18, [sp, #736]                 ; 16-byte Folded Spill
	mov.16b	v22, v14
	ldr	q15, [sp, #496]                 ; 16-byte Folded Reload
	mov.16b	v18, v19
	mov.16b	v5, v13
	mov.16b	v1, v8
	mov.16b	v13, v16
	movi.4s	v19, #2
	eor.16b	v16, v31, v19
	mov.s	w16, v16[1]
	fmov	w25, s16
	cmp	w25, #8
	csel	w25, w25, wzr, lo
	cset	w0, lo
	add	x9, sp, #3560
	bfxil	x9, x25, #0, #3
	ldrb	w9, [x9]
	and	w9, w0, w9
	mov.s	v4[2], v17[0]
	mov.s	v4[3], v20[0]
	fadd.4s	v4, v6, v4
	fadd.4s	v3, v7, v3
	and	x0, x25, #0x7
	mov	x25, x28
	str	q3, [sp, #3856]
	str	q4, [sp, #3872]
	add	x28, sp, #3856
	ldr	s6, [x28, x0, lsl #2]
	tst	w23, w9
	fcsel	s6, s6, s23, ne
	cmp	w16, #8
	csel	w9, w16, wzr, lo
	cset	w16, lo
	add	x0, sp, #3560
	bfxil	x0, x9, #0, #3
	ldrb	w0, [x0]
	and	w16, w16, w0
	and	x9, x9, #0x7
	str	q3, [sp, #3824]
	str	q4, [sp, #3840]
	add	x0, sp, #3824
	ldr	s7, [x0, x9, lsl #2]
	mov.s	w9, v16[2]
	tst	w7, w16
	mov	x7, x3
	mov	x3, x15
	add	x15, sp, #5, lsl #12            ; =20480
	add	x15, x15, #664
	fcsel	s7, s7, s23, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w16, lo
	add	x0, sp, #3560
	bfxil	x0, x9, #0, #3
	ldrb	w0, [x0]
	and	w16, w16, w0
	and	x9, x9, #0x7
	str	q3, [sp, #3792]
	str	q4, [sp, #3808]
	add	x0, sp, #3792
	ldr	s17, [x0, x9, lsl #2]
	mov.s	w9, v16[3]
	tst	w6, w16
	mov	x6, x14
	fcsel	s16, s17, s23, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w16, lo
	add	x0, sp, #3560
	bfxil	x0, x9, #0, #3
	ldrb	w0, [x0]
	and	w16, w16, w0
	eor.16b	v19, v0, v19
	mov.16b	v17, v13
	ldr	q8, [sp, #992]                  ; 16-byte Folded Reload
	mov.16b	v13, v5
	mov.16b	v11, v24
	mov.16b	v24, v18
	mov.16b	v31, v15
	ldr	q14, [sp, #960]                 ; 16-byte Folded Reload
	mov.16b	v20, v25
	mov.16b	v25, v1
	ldp	q12, q26, [sp, #368]            ; 32-byte Folded Reload
	ldr	q18, [sp, #736]                 ; 16-byte Folded Reload
	mov.16b	v15, v17
	ldr	q27, [sp, #896]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #704]                  ; 16-byte Folded Reload
	and	x9, x9, #0x7
	str	q3, [sp, #3760]
	str	q4, [sp, #3776]
	add	x14, sp, #3760
	ldr	s1, [x14, x9, lsl #2]
	tst	w4, w16
	fcsel	s1, s1, s23, ne
	fmov	w9, s19
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w16, lo
	add	x0, sp, #3560
	bfxil	x0, x9, #0, #3
	ldrb	w0, [x0]
	and	w16, w16, w0
	mov.s	w0, v19[1]
	and	x9, x9, #0x7
	str	q3, [sp, #3728]
	str	q4, [sp, #3744]
	add	x14, sp, #3728
	ldr	s17, [x14, x9, lsl #2]
	mov.s	w9, v19[2]
	tst	w13, w16
	fcsel	s17, s17, s23, ne
	cmp	w0, #8
	csel	w13, w0, wzr, lo
	cset	w16, lo
	add	x0, sp, #3560
	bfxil	x0, x13, #0, #3
	ldrb	w0, [x0]
	and	w16, w16, w0
	mov.s	w0, v19[3]
	and	x13, x13, #0x7
	str	q3, [sp, #3696]
	str	q4, [sp, #3712]
	add	x14, sp, #3696
	ldr	s19, [x14, x13, lsl #2]
	tst	w21, w16
	add	x21, sp, #9, lsl #12            ; =36864
	add	x21, x21, #776
	fcsel	s19, s19, s23, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w13, lo
	add	x16, sp, #3560
	bfxil	x16, x9, #0, #3
	ldrb	w16, [x16]
	and	w13, w13, w16
	and	x9, x9, #0x7
	str	q3, [sp, #3664]
	str	q4, [sp, #3680]
	mov.s	v17[1], v19[0]
	add	x14, sp, #3664
	ldr	s19, [x14, x9, lsl #2]
	tst	w2, w13
	fcsel	s19, s19, s23, ne
	mov.s	v17[2], v19[0]
	xtn.2s	v19, v28
	cmp	w0, #8
	csel	w9, w0, wzr, lo
	cset	w13, lo
	add	x16, sp, #3560
	bfxil	x16, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w16, [x16]
	and	w13, w13, w16
	str	q3, [sp, #3632]
	str	q4, [sp, #3648]
	fmov	w16, s19
	add	x14, sp, #3632
	ldr	s19, [x14, x9, lsl #2]
	tst	w24, w13
	adrp	x24, lCPI0_8@PAGE
	fcsel	s19, s19, s23, ne
	eor	w9, w16, #0x4
	cmp	w16, #8
	csel	w9, w9, wzr, lo
	cset	w13, lo
	add	x16, sp, #3560
	bfxil	x16, x9, #0, #3
	ldrb	w16, [x16]
	and	w13, w13, w16
	mov.s	v17[3], v19[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	tst	w23, w13
	add	x23, sp, #9, lsl #12            ; =36864
	add	x23, x23, #712
	mov.s	v6[3], v1[0]
	fadd.4s	v1, v3, v6
	fadd.4s	v3, v4, v17
	and	x9, x9, #0x7
	str	q3, [sp, #3616]
	str	q1, [sp, #3600]
	add	x13, sp, #3600
	ldr	s3, [x13, x9, lsl #2]
	fcsel	s3, s3, s23, ne
	ldr	w9, [sp, #752]                  ; 4-byte Folded Reload
	tst	w9, #0x1
	fadd	s1, s1, s3
	fcsel	s1, s1, s23, ne
	ldr	w9, [sp, #480]                  ; 4-byte Folded Reload
	tst	w9, #0x1
	fcsel	s3, s1, s23, ne
	tst	w5, #0x1
	fcsel	s4, s1, s23, ne
	tst	w1, #0x1
	fcsel	s6, s1, s23, ne
	tst	w30, #0x1
	adrp	x30, lCPI0_10@PAGE
	fcsel	s7, s1, s23, ne
	tst	w22, #0x1
	fcsel	s16, s1, s23, ne
	tst	w20, #0x1
	mov	w20, #1                         ; =0x1
	fcsel	s17, s1, s23, ne
	tst	w17, #0x1
	fcsel	s19, s1, s23, ne
	mov.s	v1[1], v3[0]
	mov.s	v1[2], v4[0]
	mov.s	v1[3], v6[0]
	rbit	w9, w11
	clz	w9, w9
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v19[0]
	mov.16b	v19, v24
	mov.16b	v24, v29
	str	q7, [sp, #3584]
	str	q1, [sp, #3568]
	and	x9, x9, #0x7
	add	x11, sp, #3568
	ldr	s1, [x11, x9, lsl #2]
	fadd	s1, s1, s23
	ldr	q23, [sp, #720]                 ; 16-byte Folded Reload
	mov	w9, #2048                       ; =0x800
	movk	w9, #17792, lsl #16
	fmov	s3, w9
	fdiv	s1, s1, s3
	dup.4s	v1, v1[0]
	zip2.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #256]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #256]                  ; 16-byte Folded Spill
	zip1.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #272]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #272]                  ; 16-byte Folded Spill
	mov	b1, v21[6]
	mov.b	v1[4], v21[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov	b3, v21[4]
	mov.b	v3[4], v21[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	mov	b4, v21[2]
	mov.b	v4[4], v21[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	mov	b6, v21[0]
	mov.b	v6[4], v21[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	ldr	q7, [x24, lCPI0_8@PAGEOFF]
	bit.16b	v14, v7, v1
	str	q14, [sp, #960]                 ; 16-byte Folded Spill
	ldr	q7, [x25, lCPI0_9@PAGEOFF]
	bit.16b	v8, v7, v3
	str	q8, [sp, #992]                  ; 16-byte Folded Spill
	mov.16b	v8, v25
	mov.16b	v25, v20
	mov.16b	v14, v22
	mov.16b	v22, v28
	mov.16b	v28, v5
	ldr	q7, [x30, lCPI0_10@PAGEOFF]
	ldr	q5, [sp, #976]                  ; 16-byte Folded Reload
	bit.16b	v5, v7, v4
	str	q5, [sp, #976]                  ; 16-byte Folded Spill
Lloh20:
	adrp	x9, lCPI0_11@PAGE
Lloh21:
	ldr	q7, [x9, lCPI0_11@PAGEOFF]
	bit.16b	v15, v7, v6
	ldr	q7, [sp, #112]                  ; 16-byte Folded Reload
	ldr	q5, [sp, #544]                  ; 16-byte Folded Reload
	bit.16b	v5, v7, v1
	bic.16b	v12, v12, v1
	ldr	q1, [sp, #512]                  ; 16-byte Folded Reload
	bit.16b	v1, v7, v3
	bic.16b	v18, v18, v3
	bit.16b	v31, v7, v4
	stp	q31, q1, [sp, #496]             ; 32-byte Folded Spill
	mov.16b	v31, v11
	ldr	q11, [sp, #352]                 ; 16-byte Folded Reload
	movi.8b	v20, #1
	bic.16b	v8, v8, v4
	ldr	q1, [sp, #528]                  ; 16-byte Folded Reload
	bit.16b	v1, v7, v6
	stp	q1, q5, [sp, #528]              ; 32-byte Folded Spill
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v6
	str	q0, [sp, #1008]                 ; 16-byte Folded Spill
	add	x22, sp, #9, lsl #12            ; =36864
	add	x22, x22, #744
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #336
	mov	w5, #-1                         ; =0xffffffff
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #304
	add	x4, sp, #3520
	ldr	x28, [sp, #136]                 ; 8-byte Folded Reload
	b	LBB0_177
LBB0_176:                               ;   in Loop: Header=BB0_5 Depth=1
	add	x22, sp, #9, lsl #12            ; =36864
	add	x22, x22, #744
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #336
	mov	w5, #-1                         ; =0xffffffff
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #304
	add	x4, sp, #3520
	b	LBB0_4
LBB0_177:                               ; %schedule.11
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	mov	w9, #512                        ; =0x200
	dup.2d	v3, x9
	cmgt.2d	v1, v3, v8
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v3, v0
	uzp1.4s	v1, v4, v1
	cmgt.2d	v4, v3, v18
	cmgt.2d	v6, v3, v12
	uzp1.4s	v4, v4, v6
	uzp1.8h	v1, v1, v4
	xtn.8b	v1, v1
	and.8b	v1, v21, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v4, v1, #0
	and.8b	v1, v4, v2
	addv.8b	b1, v1
	fmov	w13, s1
	umaxv.8b	b4, v4
	fmov	w14, s4
	tbz	w14, #0, LBB0_184
; %bb.178:                              ; %schedule.11
                                        ;   in Loop: Header=BB0_5 Depth=1
	cmge.2d	v4, v8, v3
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	cmge.2d	v6, v0, v3
	uzp1.4s	v4, v6, v4
	cmge.2d	v6, v18, v3
	cmge.2d	v3, v12, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v3, v21, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w14, s3
	tst	w14, #0xff
	b.eq	LBB0_184
; %bb.179:                              ; %varying.divergent152
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w12, #1
	csel	w9, wzr, w9, lo
	and	w13, w10, #0xff
	lsr	w11, w13, w9
	tst	w11, #0x1
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #1968]
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #1984]
	and	x9, x9, #0x7
	add	x11, sp, #1968
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w9, #3, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_181
; %bb.180:                              ; %varying.divergent152
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w11, #0, LBB0_375
LBB0_181:                               ; %convergence.overflow.resume155
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w9, w10
	rbit	w9, w9
	clz	w9, w9
	mov	w13, #255                       ; =0xff
	bics	wzr, w13, w10
	csel	w13, wzr, w9, eq
	ubfiz	x9, x13, #2, #3
	lsl	w14, w20, w13
	ldr	q5, [sp, #1072]                 ; 16-byte Folded Reload
	str	q5, [sp, #1936]
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #1952]
	add	x16, sp, #1936
	ldr	w16, [x16, x9]
	cmp	w11, #0
	csel	w11, w14, wzr, ne
	mov	w14, #3                         ; =0x3
	csel	w14, w14, w16, ne
	str	q5, [sp, #1904]
	str	q4, [sp, #1920]
	add	x16, sp, #1904
	str	w14, [x16, x9]
	ldr	q4, [sp, #1920]
	str	q4, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #1904]
	str	q4, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1040]                 ; 16-byte Folded Reload
	str	q5, [sp, #1872]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #1888]
	add	x14, sp, #1872
	ldr	w14, [x14, x9]
	csel	w14, w12, w14, ne
	str	q5, [sp, #1840]
	str	q4, [sp, #1856]
	add	x16, sp, #1840
	str	w14, [x16, x9]
	ldrb	w9, [x27, x13]
	and	w14, w9, #0x1
	fmov	s4, w14
	ubfx	w14, w9, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v4[6], w14
	ldr	q5, [sp, #1856]
	str	q5, [sp, #1056]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1840]
	str	q5, [sp, #1040]                 ; 16-byte Folded Spill
	lsr	w9, w9, #7
	mov.b	v4[7], w9
	ldrb	w9, [x8, x13]
	and	w14, w9, #0x1
	fmov	s6, w14
	ubfx	w14, w9, #1, #1
	mov.b	v6[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v6[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v6[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v6[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v6[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v6[6], w14
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	csetm	w9, ne
	dup.8b	v7, w9
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x27, x13]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_375
; %bb.182:                              ; %ready.overflow.resume157
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b1, [x21, x28]
	mov	w9, #12                         ; =0xc
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #304
	b.hs	LBB0_375
; %bb.183:                              ; %ready.overflow.resume159
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b3, [x21, w19, uxtw]
	orr	w10, w11, w10
	mov	w9, #13                         ; =0xd
	b	LBB0_3
LBB0_184:                               ; %varying.coherent153
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_219
; %bb.185:                              ; %varying.coherent.true160
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_186:                               ; %schedule.12
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w13, w11
	clz	w13, w13
	tst	w11, #0xff
	csel	w13, wzr, w13, eq
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	str	q0, [sp, #2064]
	str	q8, [sp, #2080]
	str	q18, [sp, #2096]
	str	q12, [sp, #2112]
	ubfiz	x14, x13, #3, #3
	add	x9, sp, #2064
	ldr	x17, [x9, x14]
	str	q22, [sp, #2000]
	str	q24, [sp, #2016]
	str	q27, [sp, #2032]
	str	q28, [sp, #2048]
	add	x9, sp, #2000
	ldr	x14, [x9, x14]
	sub	x13, x14, x13
	add	x14, x7, x17, lsl #5
	add	x13, x14, x13, lsl #2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b4, v1
	fmov	w14, s4
	movi.2d	v3, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w14, #0, LBB0_194
; %bb.187:                              ; %cond.load298
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s3, [x13]
	tbnz	w14, #1, LBB0_195
LBB0_188:                               ; %else302
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #2, LBB0_196
LBB0_189:                               ; %cond.load304
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x13, #8
	ld1.s	{ v3 }[2], [x17]
	tbnz	w14, #3, LBB0_197
LBB0_190:                               ; %else308
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #4, LBB0_198
LBB0_191:                               ; %cond.load310
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x13, #16
	ld1.s	{ v1 }[0], [x17]
	tbnz	w14, #5, LBB0_199
LBB0_192:                               ; %else314
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #6, LBB0_200
LBB0_193:                               ; %cond.load316
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x13, #24
	ld1.s	{ v1 }[2], [x17]
	mov.16b	v0, v19
	tbnz	w14, #7, LBB0_201
	b	LBB0_202
LBB0_194:                               ; %else299
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #1, LBB0_188
LBB0_195:                               ; %cond.load301
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x13, #4
	ld1.s	{ v3 }[1], [x17]
	tbnz	w14, #2, LBB0_189
LBB0_196:                               ; %else305
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #3, LBB0_190
LBB0_197:                               ; %cond.load307
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x13, #12
	ld1.s	{ v3 }[3], [x17]
	tbnz	w14, #4, LBB0_191
LBB0_198:                               ; %else311
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #5, LBB0_192
LBB0_199:                               ; %cond.load313
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x13, #20
	ld1.s	{ v1 }[1], [x17]
	tbnz	w14, #6, LBB0_193
LBB0_200:                               ; %else317
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v0, v19
	tbz	w14, #7, LBB0_202
LBB0_201:                               ; %cond.load319
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x13, x13, #28
	ld1.s	{ v1 }[3], [x13]
LBB0_202:                               ; %else320
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q5, [sp, #1008]                 ; 16-byte Folded Reload
	shl.2d	v6, v5, #5
	shl.2d	v7, v8, #5
	shl.2d	v17, v18, #5
	shl.2d	v19, v12, #5
	ldr	q5, [sp, #528]                  ; 16-byte Folded Reload
	add.2d	v16, v5, v15
	add.2d	v16, v16, v6
	ldr	q5, [sp, #976]                  ; 16-byte Folded Reload
	ldr	q6, [sp, #496]                  ; 16-byte Folded Reload
	add.2d	v6, v6, v5
	add.2d	v7, v6, v7
	ldr	q5, [sp, #512]                  ; 16-byte Folded Reload
	ldr	q6, [sp, #992]                  ; 16-byte Folded Reload
	add.2d	v6, v5, v6
	add.2d	v6, v6, v17
	ldr	q5, [sp, #544]                  ; 16-byte Folded Reload
	ldr	q17, [sp, #960]                 ; 16-byte Folded Reload
	add.2d	v17, v5, v17
	fmov	w13, s4
	add.2d	v4, v17, v19
	tbz	w13, #0, LBB0_210
; %bb.203:                              ; %cond.store
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d16
	str	s3, [x14]
	mov.16b	v19, v0
	tbnz	w13, #1, LBB0_211
LBB0_204:                               ; %else327
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #2, LBB0_212
LBB0_205:                               ; %cond.store328
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d7
	st1.s	{ v3 }[2], [x14]
	tbnz	w13, #3, LBB0_213
LBB0_206:                               ; %else333
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #4, LBB0_214
LBB0_207:                               ; %cond.store334
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d6
	str	s1, [x14]
	tbnz	w13, #5, LBB0_215
LBB0_208:                               ; %else339
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #6, LBB0_216
LBB0_209:                               ; %cond.store340
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x14, d4
	st1.s	{ v1 }[2], [x14]
	tbnz	w13, #7, LBB0_217
	b	LBB0_218
LBB0_210:                               ; %else324
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v19, v0
	tbz	w13, #1, LBB0_204
LBB0_211:                               ; %cond.store325
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v16[1]
	st1.s	{ v3 }[1], [x14]
	tbnz	w13, #2, LBB0_205
LBB0_212:                               ; %else330
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #3, LBB0_206
LBB0_213:                               ; %cond.store331
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v7[1]
	st1.s	{ v3 }[3], [x14]
	tbnz	w13, #4, LBB0_207
LBB0_214:                               ; %else336
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #5, LBB0_208
LBB0_215:                               ; %cond.store337
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x14, v6[1]
	st1.s	{ v1 }[1], [x14]
	tbnz	w13, #6, LBB0_209
LBB0_216:                               ; %else342
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #7, LBB0_218
LBB0_217:                               ; %cond.store343
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v4[1]
	st1.s	{ v1 }[3], [x13]
LBB0_218:                               ; %else345
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v1, v21, v20
	ushll.8h	v1, v1, #0
	ushll.4s	v3, v1, #0
	ushll2.4s	v1, v1, #0
	uaddw2.2d	v12, v12, v1
	uaddw.2d	v18, v18, v1
	uaddw2.2d	v8, v8, v3
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v3
	str	q0, [sp, #1008]                 ; 16-byte Folded Spill
	tst	w11, #0xff
	b.ne	LBB0_177
	b	LBB0_4
LBB0_219:                               ; %varying.coherent.false161
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_220:                               ; %schedule.13
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w12, LBB0_225
; %bb.221:                              ; %convergence.cascade172.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w13, #0                         ; =0x0
LBB0_222:                               ; %convergence.cascade172
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w16, s1
	sub	w11, w12, #1
	tst	w9, #0xff
	csel	w14, w11, wzr, ne
	lsl	w17, w20, w14
	and	w9, w17, w10
	tst	w9, #0xff
	cset	w9, ne
	ldr	q1, [sp, #1072]                 ; 16-byte Folded Reload
	str	q1, [sp, #3520]
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #3536]
	ubfiz	x11, x14, #2, #3
	ldr	w0, [x4, x11]
	cmp	w0, #3
	cset	w1, eq
	and	w2, w9, w16
	ldrb	w9, [x27, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s1, w16
	ubfx	w16, w9, #1, #1
	mov.b	v1[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v1[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v1[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v1[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v1[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v1[6], w16
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s3, w16
	ubfx	w16, w9, #1, #1
	mov.b	v3[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v3[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v3[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v3[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v3[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v3[6], w16
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v21, v3
	and.8b	v6, v9, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w9, s6
	ands	w16, w2, w1
	csetm	w0, ne
	bics	w9, w16, w9
	csetm	w1, ne
	dup.8b	v6, w1
	dup.8b	v7, w0
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	csinv	w14, w5, w17, eq
	dup.8b	v1, w16
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1040]                 ; 16-byte Folded Reload
	str	q4, [sp, #3488]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #3504]
	add	x9, sp, #3488
	ldr	w9, [x9, x11]
	csel	w12, w9, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w16, #1
	b.ne	LBB0_226
; %bb.223:                              ; %convergence.cascade172
                                        ;   in Loop: Header=BB0_222 Depth=2
	cmp	w12, #0
	ccmp	w13, #6, #2, ne
	b.hi	LBB0_226
; %bb.224:                              ; %convergence.cascade172
                                        ;   in Loop: Header=BB0_222 Depth=2
	add	w13, w13, #1
	tst	w11, #0xff
	b.ne	LBB0_222
	b	LBB0_226
LBB0_225:                               ; %schedule.13.convergence.cascade.exit173_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_226:                               ; %convergence.cascade.exit173
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_260
; %bb.227:                              ; %convergence.target.13.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v1, v11, v21
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	and.8b	v1, v3, v2
	addv.8b	b1, v1
	umaxv.8b	b3, v3
	fmov	w9, s3
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #336
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #304
	tbz	w9, #0, LBB0_234
; %bb.228:                              ; %convergence.target.13.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v3, v21, v11
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w9, s3
	tst	w9, #0xff
	b.eq	LBB0_234
; %bb.229:                              ; %varying.divergent190
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w12, #1
	csel	w9, wzr, w9, lo
	and	w13, w10, #0xff
	lsr	w11, w13, w9
	tst	w11, #0x1
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #2256]
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #2272]
	and	x9, x9, #0x7
	add	x11, sp, #2256
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w9, #4, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_231
; %bb.230:                              ; %varying.divergent190
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w11, #0, LBB0_375
LBB0_231:                               ; %convergence.overflow.resume193
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w9, w10
	rbit	w9, w9
	clz	w9, w9
	mov	w13, #255                       ; =0xff
	bics	wzr, w13, w10
	csel	w13, wzr, w9, eq
	ubfiz	x9, x13, #2, #3
	lsl	w14, w20, w13
	ldr	q5, [sp, #1072]                 ; 16-byte Folded Reload
	str	q5, [sp, #2224]
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #2240]
	add	x16, sp, #2224
	ldr	w16, [x16, x9]
	cmp	w11, #0
	csel	w11, w14, wzr, ne
	mov	w14, #4                         ; =0x4
	csel	w14, w14, w16, ne
	str	q5, [sp, #2192]
	str	q4, [sp, #2208]
	add	x16, sp, #2192
	str	w14, [x16, x9]
	ldr	q4, [sp, #2208]
	str	q4, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #2192]
	str	q4, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1040]                 ; 16-byte Folded Reload
	str	q5, [sp, #2160]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #2176]
	add	x14, sp, #2160
	ldr	w14, [x14, x9]
	csel	w14, w12, w14, ne
	str	q5, [sp, #2128]
	str	q4, [sp, #2144]
	add	x16, sp, #2128
	str	w14, [x16, x9]
	ldrb	w9, [x27, x13]
	and	w14, w9, #0x1
	fmov	s4, w14
	ubfx	w14, w9, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v4[6], w14
	ldr	q5, [sp, #2144]
	str	q5, [sp, #1056]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #2128]
	str	q5, [sp, #1040]                 ; 16-byte Folded Spill
	lsr	w9, w9, #7
	mov.b	v4[7], w9
	ldrb	w9, [x8, x13]
	and	w14, w9, #0x1
	fmov	s6, w14
	ubfx	w14, w9, #1, #1
	mov.b	v6[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v6[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v6[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v6[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v6[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v6[6], w14
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	csetm	w9, ne
	dup.8b	v7, w9
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x27, x13]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_375
; %bb.232:                              ; %ready.overflow.resume195
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b1, [x21, x28]
	mov	w9, #14                         ; =0xe
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #304
	b.hs	LBB0_375
; %bb.233:                              ; %ready.overflow.resume197
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b3, [x21, w19, uxtw]
	orr	w10, w11, w10
	mov	w9, #15                         ; =0xf
	b	LBB0_3
LBB0_234:                               ; %varying.coherent191
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	w9, s1
	tst	w9, #0xff
	b.eq	LBB0_252
LBB0_235:                               ; %schedule.14
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w13, w11
	clz	w13, w13
	tst	w11, #0xff
	csel	w13, wzr, w13, eq
	str	q22, [sp, #3424]
	str	q24, [sp, #3440]
	str	q27, [sp, #3456]
	str	q28, [sp, #3472]
	and	x14, x13, #0x7
	add	x9, sp, #3424
	ldr	x14, [x9, x14, lsl #3]
	sub	x14, x14, x13
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	add	x14, x9, x14, lsl #2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w17, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w17, #0, LBB0_243
; %bb.236:                              ; %cond.load347
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s1, [x14]
	tbnz	w17, #1, LBB0_244
LBB0_237:                               ; %else351
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #2, LBB0_245
LBB0_238:                               ; %cond.load353
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x1, x14, #8
	ld1.s	{ v1 }[2], [x1]
	tbnz	w17, #3, LBB0_246
LBB0_239:                               ; %else357
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #4, LBB0_247
LBB0_240:                               ; %cond.load359
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x1, x14, #16
	ld1.s	{ v3 }[0], [x1]
	tbnz	w17, #5, LBB0_248
LBB0_241:                               ; %else363
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #6, LBB0_249
LBB0_242:                               ; %cond.load365
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x1, x14, #24
	ld1.s	{ v3 }[2], [x1]
	tbnz	w17, #7, LBB0_250
	b	LBB0_251
LBB0_243:                               ; %else348
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #1, LBB0_237
LBB0_244:                               ; %cond.load350
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x1, x14, #4
	ld1.s	{ v1 }[1], [x1]
	tbnz	w17, #2, LBB0_238
LBB0_245:                               ; %else354
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #3, LBB0_239
LBB0_246:                               ; %cond.load356
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x1, x14, #12
	ld1.s	{ v1 }[3], [x1]
	tbnz	w17, #4, LBB0_240
LBB0_247:                               ; %else360
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #5, LBB0_241
LBB0_248:                               ; %cond.load362
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x1, x14, #20
	ld1.s	{ v3 }[1], [x1]
	tbnz	w17, #6, LBB0_242
LBB0_249:                               ; %else366
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w17, #7, LBB0_251
LBB0_250:                               ; %cond.load368
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x14, x14, #28
	ld1.s	{ v3 }[3], [x14]
LBB0_251:                               ; %else369
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	q15, [sp, #3360]
	ldp	q0, q4, [sp, #976]              ; 32-byte Folded Reload
	str	q0, [sp, #3376]
	str	q4, [sp, #3392]
	ldr	q0, [sp, #960]                  ; 16-byte Folded Reload
	str	q0, [sp, #3408]
	and	x14, x13, #0x7
	add	x9, sp, #3360
	ldr	x14, [x9, x14, lsl #3]
	sub	x13, x14, x13, lsl #2
	add	x13, x13, #4, lsl #12           ; =16384
	ands	w11, w11, #0xff
	csel	x13, xzr, x13, eq
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #632
	add	x13, x9, x13
	ldp	q4, q6, [x13]
	zip2.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bif.16b	v3, v6, v7
	zip1.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bif.16b	v1, v4, v6
	stp	q1, q3, [x13]
	cbz	w11, LBB0_4
LBB0_252:                               ; %schedule.15
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w12, LBB0_257
; %bb.253:                              ; %convergence.cascade209.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w11, #0                         ; =0x0
LBB0_254:                               ; %convergence.cascade209
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w16, s1
	sub	w13, w12, #1
	tst	w9, #0xff
	csel	w14, w13, wzr, ne
	lsl	w17, w20, w14
	and	w9, w17, w10
	tst	w9, #0xff
	cset	w9, ne
	ldr	q1, [sp, #1072]                 ; 16-byte Folded Reload
	str	q1, [sp, #3328]
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #3344]
	ubfiz	x13, x14, #2, #3
	add	x0, sp, #3328
	ldr	w0, [x0, x13]
	cmp	w0, #4
	cset	w1, eq
	and	w2, w9, w16
	ldrb	w9, [x27, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s1, w16
	ubfx	w16, w9, #1, #1
	mov.b	v1[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v1[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v1[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v1[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v1[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v1[6], w16
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s3, w16
	ubfx	w16, w9, #1, #1
	mov.b	v3[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v3[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v3[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v3[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v3[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v3[6], w16
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v21, v3
	and.8b	v6, v9, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w9, s6
	ands	w16, w2, w1
	csetm	w0, ne
	bics	w9, w16, w9
	csetm	w1, ne
	dup.8b	v6, w1
	dup.8b	v7, w0
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	csinv	w14, w5, w17, eq
	dup.8b	v1, w16
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1040]                 ; 16-byte Folded Reload
	str	q4, [sp, #3296]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #3312]
	add	x9, sp, #3296
	ldr	w9, [x9, x13]
	csel	w12, w9, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
	cmp	w16, #1
	b.ne	LBB0_258
; %bb.255:                              ; %convergence.cascade209
                                        ;   in Loop: Header=BB0_254 Depth=2
	cmp	w12, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_258
; %bb.256:                              ; %convergence.cascade209
                                        ;   in Loop: Header=BB0_254 Depth=2
	add	w11, w11, #1
	tst	w13, #0xff
	b.ne	LBB0_254
	b	LBB0_258
LBB0_257:                               ; %schedule.15.convergence.cascade.exit210_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
LBB0_258:                               ; %convergence.cascade.exit210
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_260
; %bb.259:                              ; %convergence.target.15.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w9, w13
	clz	w9, w9
	ldp	q1, q0, [sp, #256]              ; 32-byte Folded Reload
	str	q0, [sp, #3264]
	str	q1, [sp, #3280]
	and	x9, x9, #0x7
	add	x11, sp, #3264
	ldr	s1, [x11, x9, lsl #2]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s3, w9
	fadd	s1, s1, s3
	fsqrt	s1, s1
	dup.4s	v1, v1[0]
	zip2.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #800]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	zip1.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #784]                  ; 16-byte Folded Reload
	bit.16b	v0, v1, v3
	stp	q0, q4, [sp, #784]              ; 32-byte Folded Spill
	mov	b1, v21[6]
	mov.b	v1[4], v21[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v26, v1, v26
	mov	b1, v21[4]
	mov.b	v1[4], v21[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	mov	b3, v21[2]
	mov.b	v3[4], v21[3]
	and.16b	v19, v1, v19
	ushll.2d	v1, v3, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	and.16b	v0, v1, v0
	str	q0, [sp, #1024]                 ; 16-byte Folded Spill
	mov	b1, v21[0]
	mov.b	v1[4], v21[1]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v23, v1, v23
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #336
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #304
	b	LBB0_261
LBB0_260:                               ;   in Loop: Header=BB0_5 Depth=1
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #336
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #304
	b	LBB0_4
LBB0_261:                               ; %schedule.16
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	mov	w9, #512                        ; =0x200
	dup.2d	v3, x9
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	cmgt.2d	v1, v3, v0
	cmgt.2d	v4, v3, v23
	uzp1.4s	v1, v4, v1
	cmgt.2d	v4, v3, v19
	cmgt.2d	v6, v3, v26
	uzp1.4s	v4, v4, v6
	uzp1.8h	v1, v1, v4
	xtn.8b	v1, v1
	and.8b	v1, v21, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v4, v1, #0
	and.8b	v1, v4, v2
	addv.8b	b1, v1
	fmov	w13, s1
	umaxv.8b	b4, v4
	fmov	w14, s4
	tbz	w14, #0, LBB0_268
; %bb.262:                              ; %schedule.16
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	cmge.2d	v4, v0, v3
	cmge.2d	v6, v23, v3
	uzp1.4s	v4, v6, v4
	cmge.2d	v6, v19, v3
	cmge.2d	v3, v26, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v3, v21, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w14, s3
	tst	w14, #0xff
	b.eq	LBB0_268
; %bb.263:                              ; %varying.divergent230
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w12, #1
	csel	w9, wzr, w9, lo
	and	w13, w10, #0xff
	lsr	w11, w13, w9
	tst	w11, #0x1
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #2416]
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #2432]
	and	x9, x9, #0x7
	add	x11, sp, #2416
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w9, #5, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_265
; %bb.264:                              ; %varying.divergent230
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w11, #0, LBB0_375
LBB0_265:                               ; %convergence.overflow.resume233
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w9, w10
	rbit	w9, w9
	clz	w9, w9
	mov	w13, #255                       ; =0xff
	bics	wzr, w13, w10
	csel	w13, wzr, w9, eq
	ubfiz	x9, x13, #2, #3
	lsl	w14, w20, w13
	ldr	q5, [sp, #1072]                 ; 16-byte Folded Reload
	str	q5, [sp, #2384]
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #2400]
	add	x16, sp, #2384
	ldr	w16, [x16, x9]
	cmp	w11, #0
	csel	w11, w14, wzr, ne
	mov	w14, #5                         ; =0x5
	csel	w14, w14, w16, ne
	str	q5, [sp, #2352]
	str	q4, [sp, #2368]
	add	x16, sp, #2352
	str	w14, [x16, x9]
	ldr	q4, [sp, #2368]
	str	q4, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #2352]
	str	q4, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1040]                 ; 16-byte Folded Reload
	str	q5, [sp, #2320]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #2336]
	add	x14, sp, #2320
	ldr	w14, [x14, x9]
	csel	w14, w12, w14, ne
	str	q5, [sp, #2288]
	str	q4, [sp, #2304]
	add	x16, sp, #2288
	str	w14, [x16, x9]
	ldrb	w9, [x27, x13]
	and	w14, w9, #0x1
	fmov	s4, w14
	ubfx	w14, w9, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v4[6], w14
	ldr	q5, [sp, #2304]
	str	q5, [sp, #1056]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #2288]
	str	q5, [sp, #1040]                 ; 16-byte Folded Spill
	lsr	w9, w9, #7
	mov.b	v4[7], w9
	ldrb	w9, [x8, x13]
	and	w14, w9, #0x1
	fmov	s6, w14
	ubfx	w14, w9, #1, #1
	mov.b	v6[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v6[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v6[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v6[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v6[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v6[6], w14
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	csetm	w9, ne
	dup.8b	v7, w9
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x27, x13]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_375
; %bb.266:                              ; %ready.overflow.resume235
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b1, [x21, x28]
	mov	w9, #17                         ; =0x11
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #304
	b.hs	LBB0_375
; %bb.267:                              ; %ready.overflow.resume237
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b3, [x21, w19, uxtw]
	orr	w10, w11, w10
	mov	w9, #18                         ; =0x12
	b	LBB0_3
LBB0_268:                               ; %varying.coherent231
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_319
; %bb.269:                              ; %varying.coherent.true238
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_270:                               ; %schedule.17
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	q10, [sp, #368]                 ; 16-byte Folded Spill
	str	d9, [sp, #384]                  ; 8-byte Folded Spill
	ldr	q1, [sp, #1024]                 ; 16-byte Folded Reload
	mov.16b	v5, v12
	stp	q22, q8, [sp, #464]             ; 32-byte Folded Spill
	mov.16b	v4, v24
	mov.16b	v24, v15
	stp	q18, q4, [sp, #736]             ; 32-byte Folded Spill
	str	q27, [sp, #896]                 ; 16-byte Folded Spill
	stp	q28, q23, [sp, #704]            ; 32-byte Folded Spill
	mov.16b	v12, v25
	mov.16b	v28, v31
	mov.16b	v10, v14
	ldp	q29, q9, [sp, #928]             ; 32-byte Folded Reload
	mov.16b	v31, v13
	rbit	w13, w11
	clz	w13, w13
	tst	w11, #0xff
	csel	w14, wzr, w13, eq
	shl.2d	v3, v23, #5
	shl.2d	v4, v1, #5
	mov.16b	v18, v19
	shl.2d	v6, v19, #5
	shl.2d	v7, v26, #5
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	ldp	q16, q0, [sp, #864]             ; 32-byte Folded Reload
	add.2d	v1, v1, v0
	add.2d	v25, v1, v3
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	add.2d	v1, v1, v16
	add.2d	v23, v1, v4
	ldr	q1, [sp, #416]                  ; 16-byte Folded Reload
	ldp	q16, q0, [sp, #832]             ; 32-byte Folded Reload
	add.2d	v1, v1, v0
	add.2d	v20, v1, v6
	ldr	q1, [sp, #400]                  ; 16-byte Folded Reload
	add.2d	v1, v1, v16
	add.2d	v19, v1, v7
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
	movi.2d	v17, #0000000000000000
	movi.2d	v16, #0000000000000000
	stp	q29, q9, [sp, #928]             ; 32-byte Folded Spill
	tbz	w13, #0, LBB0_278
; %bb.271:                              ; %cond.load372
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x17, d25
	ldr	s17, [x17]
	tbnz	w13, #1, LBB0_279
LBB0_272:                               ; %else382
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #2, LBB0_280
LBB0_273:                               ; %cond.load384
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x17, d23
	ld1.s	{ v17 }[2], [x17]
	tbnz	w13, #3, LBB0_281
LBB0_274:                               ; %else394
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #4, LBB0_282
LBB0_275:                               ; %cond.load396
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x17, d20
	ld1.s	{ v16 }[0], [x17]
	mov.16b	v13, v5
	tbnz	w13, #5, LBB0_283
LBB0_276:                               ; %else406
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q0, [sp, #368]                  ; 16-byte Folded Reload
	ldr	d9, [sp, #384]                  ; 8-byte Folded Reload
	mov.16b	v15, v18
	tbz	w13, #6, LBB0_284
LBB0_277:                               ; %cond.load408
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x17, d19
	ld1.s	{ v16 }[2], [x17]
	ldp	q14, q8, [sp, #464]             ; 32-byte Folded Reload
	ldp	q18, q25, [sp, #736]            ; 32-byte Folded Reload
	tbnz	w13, #7, LBB0_285
	b	LBB0_286
LBB0_278:                               ; %else376
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #1, LBB0_272
LBB0_279:                               ; %cond.load378
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x17, v25[1]
	ld1.s	{ v17 }[1], [x17]
	tbnz	w13, #2, LBB0_273
LBB0_280:                               ; %else388
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #3, LBB0_274
LBB0_281:                               ; %cond.load390
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x17, v23[1]
	ld1.s	{ v17 }[3], [x17]
	tbnz	w13, #4, LBB0_275
LBB0_282:                               ; %else400
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v13, v5
	tbz	w13, #5, LBB0_276
LBB0_283:                               ; %cond.load402
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x17, v20[1]
	ld1.s	{ v16 }[1], [x17]
	ldr	q0, [sp, #368]                  ; 16-byte Folded Reload
	ldr	d9, [sp, #384]                  ; 8-byte Folded Reload
	mov.16b	v15, v18
	tbnz	w13, #6, LBB0_277
LBB0_284:                               ; %else412
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldp	q14, q8, [sp, #464]             ; 32-byte Folded Reload
	ldp	q18, q25, [sp, #736]            ; 32-byte Folded Reload
	tbz	w13, #7, LBB0_286
LBB0_285:                               ; %cond.load414
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v19[1]
	ld1.s	{ v16 }[3], [x13]
LBB0_286:                               ; %else418
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q27, [sp, #896]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #784]                  ; 16-byte Folded Reload
	str	q5, [sp, #2640]
	ldr	q5, [sp, #800]                  ; 16-byte Folded Reload
	str	q5, [sp, #2656]
	and	x13, x14, #0x7
	add	x9, sp, #2640
	add	x13, x9, x13, lsl #2
	ld1r.4s	{ v19 }, [x13]
	fdiv.4s	v16, v16, v19
	fdiv.4s	v17, v17, v19
	ldr	q5, [sp, #960]                  ; 16-byte Folded Reload
	add.2d	v23, v7, v5
	ldp	q5, q7, [sp, #976]              ; 32-byte Folded Reload
	add.2d	v6, v6, v7
	add.2d	v4, v4, v5
	add.2d	v3, v3, v24
	ldr	q5, [sp, #528]                  ; 16-byte Folded Reload
	add.2d	v20, v5, v3
	ldp	q5, q3, [sp, #496]              ; 32-byte Folded Reload
	add.2d	v19, v5, v4
	add.2d	v7, v3, v6
	ldr	q3, [sp, #544]                  ; 16-byte Folded Reload
	add.2d	v6, v3, v23
	fmov	w13, s1
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	ldr	q5, [sp, #704]                  ; 16-byte Folded Reload
	tbz	w13, #0, LBB0_290
; %bb.287:                              ; %cond.load421
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x17, d20
	ldr	s3, [x17]
	ldr	q23, [sp, #720]                 ; 16-byte Folded Reload
	tbnz	w13, #1, LBB0_291
LBB0_288:                               ; %else431
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v20, v11
	mov.16b	v22, v12
	mov.16b	v12, v13
	tbz	w13, #2, LBB0_292
LBB0_289:                               ; %cond.load433
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x17, d19
	ld1.s	{ v3 }[2], [x17]
	mov.16b	v13, v31
	tbnz	w13, #3, LBB0_293
	b	LBB0_294
LBB0_290:                               ; %else425
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q23, [sp, #720]                 ; 16-byte Folded Reload
	tbz	w13, #1, LBB0_288
LBB0_291:                               ; %cond.load427
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x17, v20[1]
	ld1.s	{ v3 }[1], [x17]
	mov.16b	v20, v11
	mov.16b	v22, v12
	mov.16b	v12, v13
	tbnz	w13, #2, LBB0_289
LBB0_292:                               ; %else437
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v13, v31
	tbz	w13, #3, LBB0_294
LBB0_293:                               ; %cond.load439
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x17, v19[1]
	ld1.s	{ v3 }[3], [x17]
LBB0_294:                               ; %else443
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v11, v10
	mov.16b	v10, v0
	mov.16b	v0, v25
	mov.16b	v19, v15
	mov.16b	v31, v28
	mov.16b	v15, v24
	mov.16b	v28, v5
	mov.16b	v25, v22
	tbz	w13, #4, LBB0_298
; %bb.295:                              ; %cond.load445
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x17, d7
	ld1.s	{ v4 }[0], [x17]
	mov.16b	v22, v14
	mov.16b	v24, v0
	mov.16b	v14, v11
	tbnz	w13, #5, LBB0_299
LBB0_296:                               ; %else455
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v11, v20
	movi.8b	v20, #1
	tbz	w13, #6, LBB0_300
LBB0_297:                               ; %cond.load457
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x17, d6
	ld1.s	{ v4 }[2], [x17]
	tbnz	w13, #7, LBB0_301
	b	LBB0_302
LBB0_298:                               ; %else449
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v22, v14
	mov.16b	v24, v0
	mov.16b	v14, v11
	tbz	w13, #5, LBB0_296
LBB0_299:                               ; %cond.load451
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x17, v7[1]
	ld1.s	{ v4 }[1], [x17]
	mov.16b	v11, v20
	movi.8b	v20, #1
	tbnz	w13, #6, LBB0_297
LBB0_300:                               ; %else461
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #7, LBB0_302
LBB0_301:                               ; %cond.load463
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v6[1]
	ld1.s	{ v4 }[3], [x13]
LBB0_302:                               ; %else467
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmul.4s	v6, v3, v17
	fmul.4s	v3, v4, v16
	ldp	q4, q0, [sp, #672]              ; 32-byte Folded Reload
	str	q0, [sp, #2576]
	str	q4, [sp, #2592]
	ldp	q4, q0, [sp, #640]              ; 32-byte Folded Reload
	str	q0, [sp, #2608]
	str	q4, [sp, #2624]
	ubfiz	x13, x14, #3, #3
	add	x9, sp, #2576
	ldr	x17, [x9, x13]
	str	q23, [sp, #2512]
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	str	q0, [sp, #2528]
	str	q19, [sp, #2544]
	str	q26, [sp, #2560]
	add	x9, sp, #2512
	ldr	x1, [x9, x13]
	str	q22, [sp, #2448]
	str	q24, [sp, #2464]
	str	q27, [sp, #2480]
	str	q28, [sp, #2496]
	add	x9, sp, #2448
	ldr	x13, [x9, x13]
	add	x17, x17, x17, lsl #12
	sub	x13, x13, x14
	add	x13, x13, x17
	add	x14, x3, x1, lsl #5
	add	x13, x14, x13, lsl #2
	fmov	w14, s1
	tbz	w14, #0, LBB0_310
; %bb.303:                              ; %cond.store470
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s6, [x13]
	tbnz	w14, #1, LBB0_311
LBB0_304:                               ; %else473
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #2, LBB0_312
LBB0_305:                               ; %cond.store474
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x13, #8
	st1.s	{ v6 }[2], [x17]
	tbnz	w14, #3, LBB0_313
LBB0_306:                               ; %else477
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #4, LBB0_314
LBB0_307:                               ; %cond.store478
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s3, [x13, #16]
	tbnz	w14, #5, LBB0_315
LBB0_308:                               ; %else481
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #6, LBB0_316
LBB0_309:                               ; %cond.store482
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x13, #24
	st1.s	{ v3 }[2], [x17]
	tbnz	w14, #7, LBB0_317
	b	LBB0_318
LBB0_310:                               ; %else471
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #1, LBB0_304
LBB0_311:                               ; %cond.store472
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x13, #4
	st1.s	{ v6 }[1], [x17]
	tbnz	w14, #2, LBB0_305
LBB0_312:                               ; %else475
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #3, LBB0_306
LBB0_313:                               ; %cond.store476
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x13, #12
	st1.s	{ v6 }[3], [x17]
	tbnz	w14, #4, LBB0_307
LBB0_314:                               ; %else479
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #5, LBB0_308
LBB0_315:                               ; %cond.store480
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x13, #20
	st1.s	{ v3 }[1], [x17]
	tbnz	w14, #6, LBB0_309
LBB0_316:                               ; %else483
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w14, #7, LBB0_318
LBB0_317:                               ; %cond.store484
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x13, x13, #28
	st1.s	{ v3 }[3], [x13]
LBB0_318:                               ; %else485
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v1, v21, v20
	ushll.8h	v1, v1, #0
	ushll.4s	v3, v1, #0
	ushll2.4s	v1, v1, #0
	uaddw2.2d	v26, v26, v1
	uaddw.2d	v19, v19, v1
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	uaddw2.2d	v0, v0, v3
	str	q0, [sp, #1024]                 ; 16-byte Folded Spill
	uaddw.2d	v23, v23, v3
	tst	w11, #0xff
	b.ne	LBB0_261
	b	LBB0_4
LBB0_319:                               ; %varying.coherent.false239
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_320:                               ; %schedule.18
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w12, LBB0_325
; %bb.321:                              ; %convergence.cascade252.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w13, #0                         ; =0x0
LBB0_322:                               ; %convergence.cascade252
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w16, s1
	sub	w11, w12, #1
	tst	w9, #0xff
	csel	w14, w11, wzr, ne
	lsl	w17, w20, w14
	and	w9, w17, w10
	tst	w9, #0xff
	cset	w9, ne
	ldr	q1, [sp, #1072]                 ; 16-byte Folded Reload
	str	q1, [sp, #3232]
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #3248]
	ubfiz	x11, x14, #2, #3
	add	x0, sp, #3232
	ldr	w0, [x0, x11]
	cmp	w0, #5
	cset	w1, eq
	and	w2, w9, w16
	ldrb	w9, [x27, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s1, w16
	ubfx	w16, w9, #1, #1
	mov.b	v1[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v1[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v1[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v1[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v1[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v1[6], w16
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s3, w16
	ubfx	w16, w9, #1, #1
	mov.b	v3[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v3[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v3[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v3[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v3[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v3[6], w16
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v21, v3
	and.8b	v6, v9, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w9, s6
	ands	w16, w2, w1
	csetm	w0, ne
	bics	w9, w16, w9
	csetm	w1, ne
	dup.8b	v6, w1
	dup.8b	v7, w0
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	csinv	w14, w5, w17, eq
	dup.8b	v1, w16
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1040]                 ; 16-byte Folded Reload
	str	q4, [sp, #3200]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #3216]
	add	x9, sp, #3200
	ldr	w9, [x9, x11]
	csel	w12, w9, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w16, #1
	b.ne	LBB0_326
; %bb.323:                              ; %convergence.cascade252
                                        ;   in Loop: Header=BB0_322 Depth=2
	cmp	w12, #0
	ccmp	w13, #6, #2, ne
	b.hi	LBB0_326
; %bb.324:                              ; %convergence.cascade252
                                        ;   in Loop: Header=BB0_322 Depth=2
	add	w13, w13, #1
	tst	w11, #0xff
	b.ne	LBB0_322
	b	LBB0_326
LBB0_325:                               ; %schedule.18.convergence.cascade.exit253_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_326:                               ; %convergence.cascade.exit253
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_260
; %bb.327:                              ; %convergence.target.18.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v1, v11, v21
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	and.8b	v1, v3, v2
	addv.8b	b1, v1
	umaxv.8b	b3, v3
	fmov	w9, s3
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #336
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #304
	tbz	w9, #0, LBB0_334
; %bb.328:                              ; %convergence.target.18.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v3, v21, v11
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w9, s3
	tst	w9, #0xff
	b.eq	LBB0_334
; %bb.329:                              ; %varying.divergent270
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w12, #1
	csel	w9, wzr, w9, lo
	and	w13, w10, #0xff
	lsr	w11, w13, w9
	tst	w11, #0x1
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #2800]
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #2816]
	and	x9, x9, #0x7
	add	x11, sp, #2800
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w12, #0, #4, ne
	ccmp	w9, #6, #0, ne
	cset	w11, ne
	cmp	w13, #255
	b.ne	LBB0_331
; %bb.330:                              ; %varying.divergent270
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w11, #0, LBB0_375
LBB0_331:                               ; %convergence.overflow.resume273
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w9, w10
	rbit	w9, w9
	clz	w9, w9
	mov	w13, #255                       ; =0xff
	bics	wzr, w13, w10
	csel	w13, wzr, w9, eq
	ubfiz	x9, x13, #2, #3
	lsl	w14, w20, w13
	ldr	q5, [sp, #1072]                 ; 16-byte Folded Reload
	str	q5, [sp, #2768]
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #2784]
	add	x16, sp, #2768
	ldr	w16, [x16, x9]
	cmp	w11, #0
	csel	w11, w14, wzr, ne
	mov	w14, #6                         ; =0x6
	csel	w14, w14, w16, ne
	str	q5, [sp, #2736]
	str	q4, [sp, #2752]
	add	x16, sp, #2736
	str	w14, [x16, x9]
	ldr	q4, [sp, #2752]
	str	q4, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #2736]
	str	q4, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1040]                 ; 16-byte Folded Reload
	str	q5, [sp, #2704]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #2720]
	add	x14, sp, #2704
	ldr	w14, [x14, x9]
	csel	w14, w12, w14, ne
	str	q5, [sp, #2672]
	str	q4, [sp, #2688]
	add	x16, sp, #2672
	str	w14, [x16, x9]
	ldrb	w9, [x27, x13]
	and	w14, w9, #0x1
	fmov	s4, w14
	ubfx	w14, w9, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v4[6], w14
	ldr	q5, [sp, #2688]
	str	q5, [sp, #1056]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #2672]
	str	q5, [sp, #1040]                 ; 16-byte Folded Spill
	lsr	w9, w9, #7
	mov.b	v4[7], w9
	ldrb	w9, [x8, x13]
	and	w14, w9, #0x1
	fmov	s6, w14
	ubfx	w14, w9, #1, #1
	mov.b	v6[1], w14
	ubfx	w14, w9, #2, #1
	mov.b	v6[2], w14
	ubfx	w14, w9, #3, #1
	mov.b	v6[3], w14
	ubfx	w14, w9, #4, #1
	mov.b	v6[4], w14
	ubfx	w14, w9, #5, #1
	mov.b	v6[5], w14
	ubfx	w14, w9, #6, #1
	mov.b	v6[6], w14
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	csetm	w9, ne
	dup.8b	v7, w9
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x27, x13]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x13]
	csinc	w12, w12, w13, eq
	cmp	w26, #8
	b.hs	LBB0_375
; %bb.332:                              ; %ready.overflow.resume275
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b1, [x21, x28]
	mov	w9, #19                         ; =0x13
	str	w9, [x22, x28, lsl #2]
	str	w12, [x23, x28, lsl #2]
	cmp	w19, #8
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #304
	b.hs	LBB0_375
; %bb.333:                              ; %ready.overflow.resume277
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b3, [x21, w19, uxtw]
	orr	w10, w11, w10
	mov	w9, #20                         ; =0x14
	b	LBB0_3
LBB0_334:                               ; %varying.coherent271
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	w9, s1
	tst	w9, #0xff
	b.eq	LBB0_352
LBB0_335:                               ; %schedule.19
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w13, w11
	clz	w13, w13
	tst	w11, #0xff
	csel	w14, wzr, w13, eq
	mov	w9, #16384                      ; =0x4000
	sub	x17, x9, w14, uxtw #2
	tst	w11, #0xff
	ldp	q1, q0, [sp, #864]              ; 32-byte Folded Reload
	str	q0, [sp, #3136]
	str	q1, [sp, #3152]
	ldp	q1, q0, [sp, #832]              ; 32-byte Folded Reload
	str	q0, [sp, #3168]
	str	q1, [sp, #3184]
	and	x1, x14, #0x7
	add	x9, sp, #3104
	add	x2, x9, x1, lsl #2
	add	x9, sp, #3136
	ldr	x13, [x9, x1, lsl #3]
	add	x13, x17, x13
	csel	x13, xzr, x13, eq
	add	x13, x15, x13
	ldp	q3, q1, [x13]
	zip1.8b	v4, v21, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v6, v4, #0
	and.16b	v4, v6, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w13, s3
	ldp	q0, q3, [sp, #784]              ; 32-byte Folded Reload
	str	q0, [sp, #3104]
	str	q3, [sp, #3120]
	ld1r.4s	{ v3 }, [x2]
	fdiv.4s	v7, v4, v3
	str	q15, [sp, #3040]
	ldp	q0, q4, [sp, #976]              ; 32-byte Folded Reload
	str	q0, [sp, #3056]
	str	q4, [sp, #3072]
	ldr	q0, [sp, #960]                  ; 16-byte Folded Reload
	str	q0, [sp, #3088]
	add	x9, sp, #3040
	ldr	x2, [x9, x1, lsl #3]
	add	x17, x17, x2
	csel	x17, xzr, x17, eq
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #632
	add	x17, x9, x17
	ldp	q16, q4, [x17]
	and.16b	v6, v6, v16
	ldp	q16, q0, [sp, #672]             ; 32-byte Folded Reload
	str	q0, [sp, #2976]
	str	q16, [sp, #2992]
	ldp	q16, q0, [sp, #640]             ; 32-byte Folded Reload
	str	q0, [sp, #3008]
	str	q16, [sp, #3024]
	add	x9, sp, #2976
	ldr	x17, [x9, x1, lsl #3]
	fmul.4s	v6, v7, v6
	add	x17, x17, x17, lsl #12
	str	q22, [sp, #2912]
	str	q24, [sp, #2928]
	str	q27, [sp, #2944]
	str	q28, [sp, #2960]
	add	x9, sp, #2912
	ldr	x1, [x9, x1, lsl #3]
	sub	x14, x1, x14
	add	x14, x14, x17
	add	x14, x3, x14, lsl #2
	add	x14, x14, #4, lsl #12           ; =16384
	tbz	w13, #0, LBB0_339
; %bb.336:                              ; %cond.store487
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s6, [x14]
	tbnz	w13, #1, LBB0_340
LBB0_337:                               ; %else490
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #2, LBB0_341
LBB0_338:                               ; %cond.store491
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x14, #8
	st1.s	{ v6 }[2], [x17]
	tbnz	w13, #3, LBB0_342
	b	LBB0_343
LBB0_339:                               ; %else488
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #1, LBB0_337
LBB0_340:                               ; %cond.store489
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x14, #4
	st1.s	{ v6 }[1], [x17]
	tbnz	w13, #2, LBB0_338
LBB0_341:                               ; %else492
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #3, LBB0_343
LBB0_342:                               ; %cond.store493
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x14, #12
	st1.s	{ v6 }[3], [x17]
LBB0_343:                               ; %else494
                                        ;   in Loop: Header=BB0_5 Depth=1
	zip2.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v1, v6, v1
	fdiv.4s	v1, v1, v3
	and.16b	v3, v6, v4
	fmul.4s	v1, v1, v3
	tbz	w13, #4, LBB0_348
; %bb.344:                              ; %cond.store495
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s1, [x14, #16]
	tbnz	w13, #5, LBB0_349
LBB0_345:                               ; %else498
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #6, LBB0_350
LBB0_346:                               ; %cond.store499
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x14, #24
	st1.s	{ v1 }[2], [x17]
	tbnz	w13, #7, LBB0_351
LBB0_347:                               ; %else502
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.ne	LBB0_352
	b	LBB0_4
LBB0_348:                               ; %else496
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #5, LBB0_345
LBB0_349:                               ; %cond.store497
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x14, #20
	st1.s	{ v1 }[1], [x17]
	tbnz	w13, #6, LBB0_346
LBB0_350:                               ; %else500
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #7, LBB0_347
LBB0_351:                               ; %cond.store501
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x13, x14, #28
	st1.s	{ v1 }[3], [x13]
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_352:                               ; %schedule.20
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w12, LBB0_357
; %bb.353:                              ; %convergence.cascade292.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w11, #0                         ; =0x0
LBB0_354:                               ; %convergence.cascade292
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w16, s1
	sub	w13, w12, #1
	tst	w9, #0xff
	csel	w14, w13, wzr, ne
	lsl	w17, w20, w14
	and	w9, w17, w10
	tst	w9, #0xff
	cset	w9, ne
	ldr	q1, [sp, #1072]                 ; 16-byte Folded Reload
	str	q1, [sp, #2880]
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #2896]
	ubfiz	x13, x14, #2, #3
	add	x0, sp, #2880
	ldr	w0, [x0, x13]
	cmp	w0, #6
	cset	w1, eq
	and	w2, w9, w16
	ldrb	w9, [x27, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s1, w16
	ubfx	w16, w9, #1, #1
	mov.b	v1[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v1[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v1[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v1[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v1[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v1[6], w16
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w14, sxtw]
	and	w16, w9, #0x1
	fmov	s3, w16
	ubfx	w16, w9, #1, #1
	mov.b	v3[1], w16
	ubfx	w16, w9, #2, #1
	mov.b	v3[2], w16
	ubfx	w16, w9, #3, #1
	mov.b	v3[3], w16
	ubfx	w16, w9, #4, #1
	mov.b	v3[4], w16
	ubfx	w16, w9, #5, #1
	mov.b	v3[5], w16
	ubfx	w16, w9, #6, #1
	mov.b	v3[6], w16
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v21, v3
	and.8b	v6, v9, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w9, s6
	ands	w16, w2, w1
	csetm	w0, ne
	bics	w9, w16, w9
	csetm	w1, ne
	dup.8b	v6, w1
	dup.8b	v7, w0
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w14, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x27, w14, sxtw]
	csinv	w14, w5, w17, eq
	dup.8b	v1, w16
	and	w10, w14, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1040]                 ; 16-byte Folded Reload
	str	q4, [sp, #2848]
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #2864]
	add	x9, sp, #2848
	ldr	w9, [x9, x13]
	csel	w12, w9, w12, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
	cmp	w16, #1
	b.ne	LBB0_358
; %bb.355:                              ; %convergence.cascade292
                                        ;   in Loop: Header=BB0_354 Depth=2
	cmp	w12, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_358
; %bb.356:                              ; %convergence.cascade292
                                        ;   in Loop: Header=BB0_354 Depth=2
	add	w11, w11, #1
	tst	w13, #0xff
	b.ne	LBB0_354
	b	LBB0_358
LBB0_357:                               ; %schedule.20.convergence.cascade.exit293_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w13, s1
LBB0_358:                               ; %convergence.cascade.exit293
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w13, #0xff
	b.eq	LBB0_260
; %bb.359:                              ; %convergence.target.20.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v9, v9, v21
	tst	w10, #0xff
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #336
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #304
	b.eq	LBB0_372
; %bb.360:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldrb	w9, [x8, #8]
	and	w11, w9, #0x1
	fmov	s1, w11
	ubfx	w11, w9, #1, #1
	mov.b	v1[1], w11
	ubfx	w11, w9, #2, #1
	mov.b	v1[2], w11
	ubfx	w11, w9, #3, #1
	mov.b	v1[3], w11
	ubfx	w11, w9, #4, #1
	mov.b	v1[4], w11
	ubfx	w11, w9, #5, #1
	mov.b	v1[5], w11
	ubfx	w11, w9, #6, #1
	mov.b	v1[6], w11
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8]
	and	w11, w9, #0x1
	fmov	s6, w11
	ubfx	w11, w9, #1, #1
	mov.b	v6[1], w11
	ubfx	w11, w9, #2, #1
	mov.b	v6[2], w11
	ubfx	w11, w9, #3, #1
	mov.b	v6[3], w11
	ubfx	w11, w9, #4, #1
	mov.b	v6[4], w11
	ubfx	w11, w9, #5, #1
	mov.b	v6[5], w11
	ubfx	w11, w9, #6, #1
	mov.b	v6[6], w11
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	and.8b	v7, v9, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w9, s1
	eor	w9, w9, #0x1
	and	w9, w10, w9
	dup.8b	v1, w9
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w12, s4
	tst	w9, #0x1
	csetm	w9, ne
	dup.8b	v16, w9
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	str	b7, [x8, #8]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	str	b6, [x8]
	cmp	w26, #8
	b.lo	LBB0_362
; %bb.361:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w12, #0xff
	b.ne	LBB0_375
LBB0_362:                               ; %ready.overflow.resume314
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w9, s3
	ldr	d3, [sp, #72]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w11, v3[0]
	sbfx	w13, w11, #0, #1
	fmov	s3, w13
	sbfx	w13, w11, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w11, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w11, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w11, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w11, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w11, #6, #1
	mov.b	v3[6], w13
	sbfx	w11, w11, #7, #1
	mov.b	v3[7], w11
	and	w11, w10, #0xfffffffe
	tst	w9, #0xff
	csel	w11, w11, w10, eq
	tst	w12, #0xff
	csel	x9, x28, xzr, ne
	ldrb	w10, [x21, x9]
	and	w12, w10, #0x1
	fmov	s4, w12
	ubfx	w12, w10, #1, #1
	mov.b	v4[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v4[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v4[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v4[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v4[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v4[6], w12
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	fmov	w10, s3
Lloh22:
	adrp	x17, l_convergence.targets@PAGE
Lloh23:
	add	x17, x17, l_convergence.targets@PAGEOFF
	add	x10, x17, w10, sxtw #2
	ldr	q3, [sp, #1040]                 ; 16-byte Folded Reload
	fmov	w12, s3
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x9]
	lsl	x9, x9, #2
	add	x13, x22, x9
	csel	x10, x10, x13, ne
	ldr	w10, [x10]
	str	w10, [x13]
	ldr	w10, [x23, x9]
	csel	w10, w12, w10, ne
	str	w10, [x23, x9]
	csel	w10, w19, w26, ne
	and	w9, w11, #0x2
	ldrb	w12, [x8, #9]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #1]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v9, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w9, w12, w9, lsr #1
	dup.8b	v1, w9
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w12, s4
	csetm	w9, ne
	dup.8b	v16, w9
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #9]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #1]
	cmp	w10, #8
	and	w9, w12, #0xff
	ccmp	w9, #0, #4, hs
	b.ne	LBB0_375
; %bb.363:                              ; %ready.overflow.resume320
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	ldr	d6, [sp, #64]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v6
	mvn.8b	v4, v4
	umov.b	w9, v4[0]
	addv.8b	b4, v3
	sbfx	w13, w9, #0, #1
	fmov	s3, w13
	sbfx	w13, w9, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w9, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w9, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w9, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w9, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w9, #6, #1
	mov.b	v3[6], w13
	sbfx	w9, w9, #7, #1
	mov.b	v3[7], w9
	fmov	w9, s4
	and	w13, w11, #0xfffffffd
	tst	w9, #0xff
	csel	w9, w13, w11, eq
	sxtw	x11, w10
	tst	w12, #0xff
	csel	x11, x11, xzr, ne
	ldrb	w12, [x21, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	mov.s	w12, v3[1]
	add	x12, x17, w12, sxtw #2
	ldr	q3, [sp, #1040]                 ; 16-byte Folded Reload
	mov.s	w13, v3[1]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x11]
	lsl	x11, x11, #2
	add	x14, x22, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x23, x11]
	csel	w12, w13, w12, ne
	str	w12, [x23, x11]
	cinc	w10, w10, ne
	and	w11, w9, #0x4
	ldrb	w12, [x8, #10]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #2]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v9, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w11, w12, w11, lsr #2
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #10]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #2]
	cmp	w10, #8
	and	w12, w11, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_375
; %bb.364:                              ; %ready.overflow.resume326
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	ldr	d6, [sp, #56]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v6
	mvn.8b	v4, v4
	umov.b	w12, v4[0]
	addv.8b	b4, v3
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	fmov	w12, s4
	and	w13, w9, #0xfffffffb
	tst	w12, #0xff
	csel	w9, w13, w9, eq
	sxtw	x12, w10
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x21, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	mov.s	w12, v3[2]
	add	x12, x17, w12, sxtw #2
	ldr	q3, [sp, #1040]                 ; 16-byte Folded Reload
	mov.s	w13, v3[2]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x11]
	lsl	x11, x11, #2
	add	x14, x22, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x23, x11]
	csel	w12, w13, w12, ne
	str	w12, [x23, x11]
	cinc	w10, w10, ne
	and	w11, w9, #0x8
	ldrb	w12, [x8, #11]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #3]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v9, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w11, w12, w11, lsr #3
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #11]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #3]
	cmp	w10, #8
	and	w12, w11, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_375
; %bb.365:                              ; %ready.overflow.resume332
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	ldr	d6, [sp, #48]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v6
	mvn.8b	v4, v4
	umov.b	w12, v4[0]
	addv.8b	b4, v3
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	fmov	w12, s4
	and	w13, w9, #0xfffffff7
	tst	w12, #0xff
	csel	w9, w13, w9, eq
	sxtw	x12, w10
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x21, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	mov.s	w12, v3[3]
	add	x12, x17, w12, sxtw #2
	ldr	q3, [sp, #1040]                 ; 16-byte Folded Reload
	mov.s	w13, v3[3]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x11]
	lsl	x11, x11, #2
	add	x14, x22, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x23, x11]
	csel	w12, w13, w12, ne
	str	w12, [x23, x11]
	cinc	w11, w10, ne
	and	w10, w9, #0x10
	ldrb	w12, [x8, #12]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #4]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v9, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w10, w12, w10, lsr #4
	dup.8b	v1, w10
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w12, s4
	csetm	w10, ne
	dup.8b	v16, w10
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #12]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #4]
	cmp	w11, #8
	and	w10, w12, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_375
; %bb.366:                              ; %ready.overflow.resume338
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w10, s3
	ldr	d3, [sp, #40]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w13, v3[0]
	sbfx	w14, w13, #0, #1
	fmov	s3, w14
	sbfx	w14, w13, #1, #1
	mov.b	v3[1], w14
	sbfx	w14, w13, #2, #1
	mov.b	v3[2], w14
	sbfx	w14, w13, #3, #1
	mov.b	v3[3], w14
	sbfx	w14, w13, #4, #1
	mov.b	v3[4], w14
	sbfx	w14, w13, #5, #1
	mov.b	v3[5], w14
	sbfx	w14, w13, #6, #1
	mov.b	v3[6], w14
	sbfx	w13, w13, #7, #1
	mov.b	v3[7], w13
	and	w13, w9, #0xffffffef
	tst	w10, #0xff
	csel	w10, w13, w9, eq
	sxtw	x9, w11
	tst	w12, #0xff
	csel	x9, x9, xzr, ne
	ldrb	w12, [x21, x9]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	fmov	w12, s3
	add	x12, x17, w12, sxtw #2
	ldr	q3, [sp, #1056]                 ; 16-byte Folded Reload
	fmov	w13, s3
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x9]
	lsl	x9, x9, #2
	add	x14, x22, x9
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x23, x9]
	csel	w12, w13, w12, ne
	str	w12, [x23, x9]
	cinc	w9, w11, ne
	and	w11, w10, #0x20
	ldrb	w12, [x8, #13]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #5]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v9, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w11, w12, w11, lsr #5
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #13]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #5]
	cmp	w9, #8
	and	w12, w11, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_375
; %bb.367:                              ; %ready.overflow.resume344
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w12, s3
	ldr	d3, [sp, #32]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w13, v3[0]
	sbfx	w14, w13, #0, #1
	fmov	s3, w14
	sbfx	w14, w13, #1, #1
	mov.b	v3[1], w14
	sbfx	w14, w13, #2, #1
	mov.b	v3[2], w14
	sbfx	w14, w13, #3, #1
	mov.b	v3[3], w14
	sbfx	w14, w13, #4, #1
	mov.b	v3[4], w14
	sbfx	w14, w13, #5, #1
	mov.b	v3[5], w14
	sbfx	w14, w13, #6, #1
	mov.b	v3[6], w14
	sbfx	w13, w13, #7, #1
	mov.b	v3[7], w13
	and	w13, w10, #0xffffffdf
	tst	w12, #0xff
	csel	w10, w13, w10, eq
	sxtw	x12, w9
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x21, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	mov.s	w12, v5[1]
	bif.8b	v1, v4, v3
	add	x12, x17, w12, sxtw #2
	ldr	q3, [sp, #1056]                 ; 16-byte Folded Reload
	mov.s	w13, v3[1]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x11]
	lsl	x11, x11, #2
	add	x14, x22, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x23, x11]
	csel	w12, w13, w12, ne
	str	w12, [x23, x11]
	cinc	w9, w9, ne
	ldrb	w11, [x8, #14]
	and	w12, w11, #0x1
	fmov	s1, w12
	ubfx	w12, w11, #1, #1
	mov.b	v1[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v1[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v1[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v1[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v1[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v1[6], w12
	lsr	w11, w11, #7
	mov.b	v1[7], w11
	ldrb	w11, [x8, #6]
	and	w12, w11, #0x1
	fmov	s6, w12
	ubfx	w12, w11, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v6[6], w12
	and	w12, w10, #0x40
	lsr	w11, w11, #7
	mov.b	v6[7], w11
	and.8b	v7, v9, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w11, s1
	eor	w11, w11, #0x1
	ands	w11, w11, w12, lsr #6
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #14]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #6]
	cmp	w9, #8
	b.lo	LBB0_369
; %bb.368:                              ; %ready.overflow.resume344
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.ne	LBB0_375
LBB0_369:                               ; %ready.overflow.resume350
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	ldr	d6, [sp, #24]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v6
	mvn.8b	v4, v4
	umov.b	w12, v4[0]
	addv.8b	b4, v3
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	fmov	w12, s4
	and	w13, w10, #0xffffffbf
	tst	w12, #0xff
	csel	w10, w13, w10, eq
	sxtw	x12, w9
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x21, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	mov.s	w12, v3[2]
	add	x12, x17, w12, sxtw #2
	ldr	q3, [sp, #1056]                 ; 16-byte Folded Reload
	mov.s	w13, v3[2]
	sxtb	w10, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x11]
	lsl	x11, x11, #2
	ldr	w14, [x23, x11]
	csel	w13, w13, w14, ne
	add	x14, x22, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w13, [x23, x11]
	str	w12, [x14]
	cinc	w9, w9, ne
	cmp	w10, #0
	ldrb	w11, [x8, #15]
	and	w12, w11, #0x1
	fmov	s1, w12
	ubfx	w12, w11, #1, #1
	mov.b	v1[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v1[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v1[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v1[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v1[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v1[6], w12
	lsr	w11, w11, #7
	mov.b	v1[7], w11
	ldrb	w11, [x8, #7]
	and	w12, w11, #0x1
	fmov	s6, w12
	ubfx	w12, w11, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v6[6], w12
	cset	w12, lt
	lsr	w11, w11, #7
	mov.b	v6[7], w11
	and.8b	v7, v9, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w11, s1
	eor	w11, w11, #0x1
	ands	w11, w12, w11
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #15]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #7]
	cmp	w9, #8
	b.lo	LBB0_371
; %bb.370:                              ; %ready.overflow.resume350
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.ne	LBB0_375
LBB0_371:                               ; %ready.overflow.resume356
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b6, v3
	ldr	d3, [sp, #16]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w12, v3[0]
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	fmov	w13, s6
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	and	w12, w10, #0x7f
	tst	w13, #0xff
	csel	w10, w12, w10, eq
	sxtw	x12, w9
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x21, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	mov.s	w12, v3[3]
	ldr	q3, [sp, #1056]                 ; 16-byte Folded Reload
	mov.s	w13, v3[3]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x11]
	add	x12, x17, w12, sxtw #2
	lsl	x11, x11, #2
	add	x14, x22, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x23, x11]
	csel	w12, w13, w12, ne
	str	w12, [x23, x11]
	cinc	w26, w9, ne
	b	LBB0_4
LBB0_372:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	w10, #0                         ; =0x0
	b	LBB0_4
LBB0_373:                               ; %scheduler.done
	shl.8b	v0, v9, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w8, s0
	tbnz	w8, #0, LBB0_375
; %bb.374:                              ; %scheduler.exit
	add	sp, sp, #9, lsl #12             ; =36864
	add	sp, sp, #784
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_375:                               ; %scheduler.stalled
	brk	#0x1
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdd	Lloh22, Lloh23
	.section	__TEXT,__const
	.p2align	1, 0x0
LJTI0_0:
	.short	(LBB0_7-LBB0_7)>>2
	.short	(LBB0_17-LBB0_7)>>2
	.short	(LBB0_10-LBB0_7)>>2
	.short	(LBB0_14-LBB0_7)>>2
	.short	(LBB0_9-LBB0_7)>>2
	.short	(LBB0_63-LBB0_7)>>2
	.short	(LBB0_73-LBB0_7)>>2
	.short	(LBB0_11-LBB0_7)>>2
	.short	(LBB0_151-LBB0_7)>>2
	.short	(LBB0_8-LBB0_7)>>2
	.short	(LBB0_167-LBB0_7)>>2
	.short	(LBB0_177-LBB0_7)>>2
	.short	(LBB0_12-LBB0_7)>>2
	.short	(LBB0_220-LBB0_7)>>2
	.short	(LBB0_15-LBB0_7)>>2
	.short	(LBB0_252-LBB0_7)>>2
	.short	(LBB0_261-LBB0_7)>>2
	.short	(LBB0_16-LBB0_7)>>2
	.short	(LBB0_320-LBB0_7)>>2
	.short	(LBB0_13-LBB0_7)>>2
	.short	(LBB0_352-LBB0_7)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch          ; -- Begin function llm_rows.packet_batch
	.p2align	2
_llm_rows.packet_batch:                 ; @llm_rows.packet_batch
; %bb.0:                                ; %packet.batch.prologue
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x21, x3
	mov	x19, x2
	mov	x20, x0
	ldr	w23, [x2, #36]
	ldr	w8, [x2]
	ldr	w9, [x2, #12]
	lsl	x8, x8, #5
	cmp	x8, x9
	csel	x10, x8, xzr, ls
	add	x10, x10, x23
	subs	x11, x9, x10
	mov	w12, #32                        ; =0x20
	sub	x13, x12, x23
	cmp	x11, x13
	csel	x11, x11, x13, lo
	cmp	x9, x10
	ccmp	x23, x12, #2, hi
	ccmp	x8, x9, #2, lo
	csel	x8, x11, xzr, ls
	cmp	w3, #4
	b.ne	LBB1_3
; %bb.1:                                ; %packet.batch.prologue
	cmp	x8, #32
	b.lo	LBB1_3
; %bb.2:                                ; %packet.batch.full
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w8, w23, #8
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w8, w23, #16
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w8, w23, #24
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	b	_llm_rows
LBB1_3:                                 ; %packet.batch.partial
	ubfiz	x9, x21, #3, #32
	cmp	x8, x9
	csel	x8, x8, x9, lo
	lsr	x24, x8, #3
	and	w22, w8, #0x7
	cmp	x8, #8
	b.lo	LBB1_6
; %bb.4:                                ; %packet.batch.partial.full.loop.preheader
	mov	x25, x24
	mov	x26, x23
LBB1_5:                                 ; %packet.batch.partial.full.loop
                                        ; =>This Inner Loop Header: Depth=1
	str	w26, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w26, w26, #8
	subs	w25, w25, #1
	b.ne	LBB1_5
LBB1_6:                                 ; %packet.batch.tail.check
	cbz	w22, LBB1_8
; %bb.7:                                ; %packet.batch.tail.call
	add	w8, w23, w24, lsl #3
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	x2, x22
	bl	_llm_rows
LBB1_8:                                 ; %packet.batch.partial.finish
	lsl	w8, w21, #3
	sub	w8, w8, #8
	cmp	w21, #0
	csel	w8, wzr, w8, eq
	add	w8, w23, w8
	str	w8, [x19, #36]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @convergence.targets
l_convergence.targets:
	.long	5                               ; 0x5
	.long	8                               ; 0x8
	.long	10                              ; 0xa
	.long	13                              ; 0xd
	.long	15                              ; 0xf
	.long	18                              ; 0x12
	.long	20                              ; 0x14

.subsections_via_symbols

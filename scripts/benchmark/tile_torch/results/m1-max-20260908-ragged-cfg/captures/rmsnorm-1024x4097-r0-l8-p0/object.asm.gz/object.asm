
/tmp/luisa-ragged-cfg.pbUI2k/capture/rmsnorm-1024x4097-r0-l8-p0/object/tile_xir_w8_72046_1788863218908734_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x9, lsl #12   ; =0x9000
      2c:      	sub	sp, sp, #0x310
      30:      	fmov	s1, wzr
      34:      	add	x8, sp, #0x9, lsl #12   ; =0x9000
      38:      	add	x8, x8, #0x2b8
      3c:      	str	wzr, [x8, #0x54]
      40:      	stur	wzr, [x8, #0x51]
      44:      	stur	xzr, [x8, #0x34]
      48:      	stur	xzr, [x8, #0x44]
      4c:      	stur	xzr, [x8, #0x3c]
      50:      	str	wzr, [x8, #0x4c]
      54:      	stur	xzr, [x8, #0x14]
      58:      	stur	xzr, [x8, #0x24]
      5c:      	stur	xzr, [x8, #0x1c]
      60:      	stp	xzr, xzr, [x8]
      64:      	ldr	x6, [x0]
      68:      	ldr	x7, [x0, #0x10]
      6c:      	ldr	x3, [x0, #0x30]
      70:      	ldr	w9, [x1]
      74:      	ldr	w11, [x1, #0x24]
      78:      	dup.4s	v0, w2
      7c:      	adrp	x10, 0x0 <ltmp0>
      80:      	ldr	q2, [x10]
      84:      	adrp	x10, 0x0 <ltmp0>
      88:      	ldr	q3, [x10]
      8c:      	cmhi.4s	v3, v0, v3
      90:      	cmhi.4s	v0, v0, v2
      94:      	uzp1.8h	v2, v0, v3
      98:      	xtn.8b	v9, v2
      9c:      	adrp	x10, 0x0 <ltmp0>
      a0:      	ldr	q3, [x10]
      a4:      	and.16b	v3, v2, v3
      a8:      	addv.8h	h3, v3
      ac:      	fmov	w10, s3
      b0:      	and	w10, w10, #0xff
      b4:      	fmov	s3, w10
      b8:      	cmeq.8b	v1, v3, v1
      bc:      	umov.b	w10, v1[0]
      c0:      	and	w12, w10, #0x1
      c4:      	fmov	s1, w12
      c8:      	ubfx	w12, w10, #1, #1
      cc:      	mov.b	v1[1], w12
      d0:      	ubfx	w12, w10, #2, #1
      d4:      	mov.b	v1[2], w12
      d8:      	ubfx	w12, w10, #3, #1
      dc:      	mov.b	v1[3], w12
      e0:      	ubfx	w12, w10, #4, #1
      e4:      	mov.b	v1[4], w12
      e8:      	ubfx	w12, w10, #5, #1
      ec:      	mov.b	v1[5], w12
      f0:      	ubfx	w12, w10, #6, #1
      f4:      	mov.b	v1[6], w12
      f8:      	ubfx	w10, w10, #7, #1
      fc:      	mov.b	v1[7], w10
     100:      	movi.8b	v20, #0x1
     104:      	eor.8b	v1, v1, v20
     108:      	and.8b	v1, v1, v9
     10c:      	umaxv.8h	h2, v2
     110:      	fmov	w10, s2
     114:      	shl.8b	v1, v1, #0x7
     118:      	cmlt.8b	v1, v1, #0
     11c:      	adrp	x12, 0x0 <ltmp0>
     120:      	ldr	d2, [x12]
     124:      	and.8b	v1, v1, v2
     128:      	addv.8b	b1, v1
     12c:      	str	b1, [x8, #0x50]
     130:      	stp	wzr, wzr, [x8, #0x2c]
     134:      	str	wzr, [x8, #0x10]
     138:      	tbz	w10, #0x0, 0x53c8 <ltmp0+0x53c8>
     13c:      	mov	w10, #0x0               ; =0
     140:      	stp	xzr, xzr, [sp, #0x40]
     144:      	stp	xzr, xzr, [sp, #0x30]
     148:      	stp	xzr, xzr, [sp, #0x20]
     14c:      	stp	xzr, xzr, [sp, #0x10]
     150:      	add	x15, sp, #0x5, lsl #12  ; =0x5000
     154:      	add	x15, x15, #0x298
     158:      	dup.2d	v0, x15
     15c:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     160:      	add	x12, x12, #0x278
     164:      	dup.2d	v1, x12
     168:      	stp	q0, q1, [sp, #0x60]
     16c:      	add	w9, w11, w9, lsl #5
     170:      	dup.4s	v1, w9
     174:      	str	q1, [sp, #0x50]
     178:      	movi.2d	v23, #0000000000000000
     17c:      	add	x9, x7, #0x4, lsl #12   ; =0x4000
     180:      	str	x9, [sp, #0x80]
     184:      	mov	w20, #0x1               ; =1
     188:      	add	x21, sp, #0x9, lsl #12  ; =0x9000
     18c:      	add	x21, x21, #0x308
     190:      	add	x22, sp, #0x9, lsl #12  ; =0x9000
     194:      	add	x22, x22, #0x2e8
     198:      	add	x23, sp, #0x9, lsl #12  ; =0x9000
     19c:      	add	x23, x23, #0x2c8
     1a0:      	adrp	x24, 0x0 <ltmp0>
     1a4:      	adrp	x25, 0x0 <ltmp0>
     1a8:      	adrp	x30, 0x0 <ltmp0>
     1ac:      	add	x27, sp, #0x9, lsl #12  ; =0x9000
     1b0:      	add	x27, x27, #0x2c0
     1b4:      	movi.2d	v0, #0000000000000000
     1b8:      	stp	q0, q0, [sp, #0x3f0]
     1bc:      	movi.2d	v19, #0000000000000000
     1c0:      	movi.2d	v26, #0000000000000000
     1c4:      	movi.2d	v1, #0000000000000000
     1c8:      	stp	q0, q1, [sp, #0x310]
     1cc:      	movi.2d	v8, #0000000000000000
     1d0:      	movi.2d	v18, #0000000000000000
     1d4:      	movi.2d	v12, #0000000000000000
     1d8:      	stp	q1, q1, [sp, #0x200]
     1dc:      	str	q0, [sp, #0x1f0]
     1e0:      	stp	q1, q1, [sp, #0x220]
     1e4:      	movi.2d	v15, #0000000000000000
     1e8:      	stp	q1, q1, [sp, #0x3d0]
     1ec:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     1f0:      	add	x0, x0, #0x150
     1f4:      	mov	w5, #-0x1               ; =-1
     1f8:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
     1fc:      	add	x16, x16, #0x130
     200:      	add	x4, sp, #0xdc0
     204:      	mov	w19, #0x1               ; =1
     208:      	stp	q1, q0, [sp, #0x3b0]
     20c:      	stp	q1, q1, [sp, #0x100]
     210:      	stp	q1, q1, [sp, #0x140]
     214:      	stp	q1, q1, [sp, #0x260]
     218:      	stp	q1, q1, [sp, #0x240]
     21c:      	str	q1, [sp, #0x300]
     220:      	stp	q1, q1, [sp, #0x330]
     224:      	stp	q0, q0, [sp, #0x390]
     228:      	movi.2d	v30, #0000000000000000
     22c:      	movi.2d	v13, #0000000000000000
     230:      	movi.2d	v11, #0000000000000000
     234:      	movi.2d	v14, #0000000000000000
     238:      	movi.2d	v31, #0000000000000000
     23c:      	movi.2d	v25, #0000000000000000
     240:      	movi.2d	v10, #0000000000000000
     244:      	stp	q1, q1, [sp, #0x1b0]
     248:      	stp	q1, q1, [sp, #0x190]
     24c:      	stp	q1, q1, [sp, #0x360]
     250:      	str	q1, [sp, #0x350]
     254:      	stp	q1, q1, [sp, #0x2a0]
     258:      	stp	q1, q1, [sp, #0x280]
     25c:      	movi.2d	v22, #0000000000000000
     260:      	movi.2d	v24, #0000000000000000
     264:      	movi.2d	v27, #0000000000000000
     268:      	movi.2d	v28, #0000000000000000
     26c:      	str	q1, [sp, #0x410]
     270:      	str	q1, [sp, #0x420]
     274:      	str	q1, [sp, #0x430]
     278:      	str	q1, [sp, #0x440]
     27c:      	b	0x2a0 <ltmp0+0x2a0>
     280:      	str	b3, [x21, w19, uxtw]
     284:      	orr	w10, w11, w10
     288:      	mov	w9, #0x5                ; =5
     28c:      	str	w9, [x22, w19, uxtw #2]
     290:      	add	w26, w19, #0x1
     294:      	str	w12, [x23, w19, uxtw #2]
     298:      	mov	x19, x26
     29c:      	cbz	w26, 0x53c8 <ltmp0+0x53c8>
     2a0:      	sub	w26, w19, #0x1
     2a4:      	ldr	w13, [x22, w26, sxtw #2]
     2a8:      	cmp	w13, #0x14
     2ac:      	b.hi	0x5410 <ltmp0+0x5410>
     2b0:      	sxtw	x28, w26
     2b4:      	ldrb	w11, [x21, x28]
     2b8:      	and	w12, w11, #0x1
     2bc:      	fmov	s21, w12
     2c0:      	ubfx	w12, w11, #1, #1
     2c4:      	mov.b	v21[1], w12
     2c8:      	ubfx	w12, w11, #2, #1
     2cc:      	mov.b	v21[2], w12
     2d0:      	ubfx	w12, w11, #3, #1
     2d4:      	mov.b	v21[3], w12
     2d8:      	ubfx	w12, w11, #4, #1
     2dc:      	mov.b	v21[4], w12
     2e0:      	ubfx	w12, w11, #5, #1
     2e4:      	mov.b	v21[5], w12
     2e8:      	ubfx	w12, w11, #6, #1
     2ec:      	mov.b	v21[6], w12
     2f0:      	lsr	w11, w11, #7
     2f4:      	mov.b	v21[7], w11
     2f8:      	ldr	w12, [x23, w26, sxtw #2]
     2fc:      	adrp	x9, 0x0 <ltmp0>
     300:      	add	x9, x9, #0x0
     304:      	adr	x11, 0x314 <ltmp0+0x314>
     308:      	ldrh	w14, [x9, x13, lsl #1]
     30c:      	add	x11, x11, x14, lsl #2
     310:      	br	x11
     314:      	mov.16b	v0, v19
     318:      	shl.8b	v1, v21, #0x7
     31c:      	cmlt.8b	v1, v1, #0
     320:      	umaxv.8b	b1, v1
     324:      	fmov	w11, s1
     328:      	mov	b1, v21[6]
     32c:      	mov.b	v1[4], v21[7]
     330:      	ushll.2d	v1, v1, #0x0
     334:      	shl.2d	v1, v1, #0x3f
     338:      	cmlt.2d	v1, v1, #0
     33c:      	adrp	x9, 0x0 <ltmp0>
     340:      	ldr	q3, [x9]
     344:      	bit.16b	v28, v3, v1
     348:      	mov	b3, v21[4]
     34c:      	mov.b	v3[4], v21[5]
     350:      	ushll.2d	v3, v3, #0x0
     354:      	shl.2d	v3, v3, #0x3f
     358:      	cmlt.2d	v3, v3, #0
     35c:      	adrp	x9, 0x0 <ltmp0>
     360:      	ldr	q4, [x9]
     364:      	mov	b6, v21[2]
     368:      	mov.b	v6[4], v21[3]
     36c:      	bit.16b	v27, v4, v3
     370:      	ushll.2d	v4, v6, #0x0
     374:      	shl.2d	v4, v4, #0x3f
     378:      	cmlt.2d	v4, v4, #0
     37c:      	adrp	x9, 0x0 <ltmp0>
     380:      	ldr	q6, [x9]
     384:      	bit.16b	v24, v6, v4
     388:      	mov	b6, v21[0]
     38c:      	mov.b	v6[4], v21[1]
     390:      	ushll.2d	v6, v6, #0x0
     394:      	shl.2d	v6, v6, #0x3f
     398:      	cmlt.2d	v6, v6, #0
     39c:      	adrp	x9, 0x0 <ltmp0>
     3a0:      	ldr	q7, [x9]
     3a4:      	bit.16b	v22, v7, v6
     3a8:      	zip1.8b	v7, v21, v0
     3ac:      	ushll.4s	v7, v7, #0x0
     3b0:      	shl.4s	v7, v7, #0x1f
     3b4:      	cmlt.4s	v7, v7, #0
     3b8:      	ldr	q19, [sp, #0x50]
     3bc:      	and.16b	v16, v7, v19
     3c0:      	zip2.8b	v17, v21, v0
     3c4:      	ushll.4s	v17, v17, #0x0
     3c8:      	shl.4s	v17, v17, #0x1f
     3cc:      	cmlt.4s	v17, v17, #0
     3d0:      	and.16b	v19, v17, v19
     3d4:      	movi.4s	v20, #0x3
     3d8:      	and.16b	v7, v7, v20
     3dc:      	and.16b	v17, v17, v20
     3e0:      	neg.4s	v17, v17
     3e4:      	ushl.4s	v17, v19, v17
     3e8:      	neg.4s	v7, v7
     3ec:      	ushl.4s	v7, v16, v7
     3f0:      	ushll.2d	v16, v7, #0x0
     3f4:      	ushll2.2d	v7, v7, #0x0
     3f8:      	ushll.2d	v19, v17, #0x0
     3fc:      	ushll2.2d	v17, v17, #0x0
     400:      	ldr	q20, [sp, #0x280]
     404:      	bit.16b	v20, v17, v1
     408:      	ldr	q17, [sp, #0x290]
     40c:      	bit.16b	v17, v19, v3
     410:      	stp	q20, q17, [sp, #0x280]
     414:      	ldr	q17, [sp, #0x2a0]
     418:      	bit.16b	v17, v7, v4
     41c:      	ldr	q7, [sp, #0x2b0]
     420:      	bit.16b	v7, v16, v6
     424:      	stp	q17, q7, [sp, #0x2a0]
     428:      	ldr	q7, [sp, #0x60]
     42c:      	ldr	q16, [sp, #0x190]
     430:      	bit.16b	v16, v7, v1
     434:      	str	q16, [sp, #0x190]
     438:      	ldr	q16, [sp, #0x1a0]
     43c:      	bit.16b	v16, v7, v3
     440:      	str	q16, [sp, #0x1a0]
     444:      	ldr	q16, [sp, #0x1b0]
     448:      	bit.16b	v16, v7, v4
     44c:      	str	q16, [sp, #0x1b0]
     450:      	ldr	q16, [sp, #0x1c0]
     454:      	bit.16b	v16, v7, v6
     458:      	str	q16, [sp, #0x1c0]
     45c:      	ldr	q7, [x24]
     460:      	ldr	q16, [sp, #0x340]
     464:      	bit.16b	v16, v7, v1
     468:      	str	q16, [sp, #0x340]
     46c:      	ldr	q7, [x25]
     470:      	ldr	q16, [sp, #0x350]
     474:      	bit.16b	v16, v7, v3
     478:      	str	q16, [sp, #0x350]
     47c:      	ldr	q7, [x30]
     480:      	ldr	q16, [sp, #0x360]
     484:      	bit.16b	v16, v7, v4
     488:      	str	q16, [sp, #0x360]
     48c:      	adrp	x9, 0x0 <ltmp0>
     490:      	ldr	q7, [x9]
     494:      	ldr	q16, [sp, #0x370]
     498:      	bit.16b	v16, v7, v6
     49c:      	str	q16, [sp, #0x370]
     4a0:      	bic.16b	v10, v10, v1
     4a4:      	bic.16b	v25, v25, v3
     4a8:      	bic.16b	v31, v31, v4
     4ac:      	bic.16b	v14, v14, v6
     4b0:      	mov.16b	v19, v0
     4b4:      	movi.8b	v20, #0x1
     4b8:      	tbnz	w11, #0x0, 0x5b4 <ltmp0+0x5b4>
     4bc:      	b	0x298 <ltmp0+0x298>
     4c0:      	shl.8b	v1, v21, #0x7
     4c4:      	cmlt.8b	v1, v1, #0
     4c8:      	and.8b	v1, v1, v2
     4cc:      	addv.8b	b1, v1
     4d0:      	fmov	w11, s1
     4d4:      	b	0x1cb8 <ltmp0+0x1cb8>
     4d8:      	shl.8b	v1, v21, #0x7
     4dc:      	cmlt.8b	v1, v1, #0
     4e0:      	and.8b	v1, v1, v2
     4e4:      	addv.8b	b1, v1
     4e8:      	fmov	w11, s1
     4ec:      	b	0xa9c <ltmp0+0xa9c>
     4f0:      	shl.8b	v1, v21, #0x7
     4f4:      	cmlt.8b	v1, v1, #0
     4f8:      	and.8b	v3, v1, v2
     4fc:      	addv.8b	b3, v3
     500:      	fmov	w11, s3
     504:      	rbit	w11, w11
     508:      	clz	w11, w11
     50c:      	umaxv.8b	b1, v1
     510:      	fmov	w13, s1
     514:      	eor	w1, w13, #0x1
     518:      	tst	w13, #0x1
     51c:      	csel	w14, w11, wzr, ne
     520:      	b	0x614 <ltmp0+0x614>
     524:      	shl.8b	v1, v21, #0x7
     528:      	cmlt.8b	v1, v1, #0
     52c:      	umaxv.8b	b1, v1
     530:      	fmov	w11, s1
     534:      	eor	w11, w11, #0x1
     538:      	b	0x1248 <ltmp0+0x1248>
     53c:      	shl.8b	v1, v21, #0x7
     540:      	cmlt.8b	v1, v1, #0
     544:      	and.8b	v1, v1, v2
     548:      	addv.8b	b1, v1
     54c:      	fmov	w11, s1
     550:      	b	0x2a08 <ltmp0+0x2a08>
     554:      	shl.8b	v1, v21, #0x7
     558:      	cmlt.8b	v1, v1, #0
     55c:      	and.8b	v1, v1, v2
     560:      	addv.8b	b1, v1
     564:      	fmov	w11, s1
     568:      	b	0x3f24 <ltmp0+0x3f24>
     56c:      	shl.8b	v1, v21, #0x7
     570:      	cmlt.8b	v1, v1, #0
     574:      	and.8b	v1, v1, v2
     578:      	addv.8b	b1, v1
     57c:      	fmov	w11, s1
     580:      	b	0x828 <ltmp0+0x828>
     584:      	shl.8b	v1, v21, #0x7
     588:      	cmlt.8b	v1, v1, #0
     58c:      	and.8b	v1, v1, v2
     590:      	addv.8b	b1, v1
     594:      	fmov	w11, s1
     598:      	b	0x303c <ltmp0+0x303c>
     59c:      	shl.8b	v1, v21, #0x7
     5a0:      	cmlt.8b	v1, v1, #0
     5a4:      	and.8b	v1, v1, v2
     5a8:      	addv.8b	b1, v1
     5ac:      	fmov	w11, s1
     5b0:      	b	0x3704 <ltmp0+0x3704>
     5b4:      	shl.8b	v1, v21, #0x7
     5b8:      	cmlt.8b	v1, v1, #0
     5bc:      	and.8b	v3, v1, v2
     5c0:      	addv.8b	b3, v3
     5c4:      	fmov	w11, s3
     5c8:      	umaxv.8b	b1, v1
     5cc:      	fmov	w13, s1
     5d0:      	rbit	w14, w11
     5d4:      	clz	w14, w14
     5d8:      	tst	w13, #0x1
     5dc:      	csel	w13, w14, wzr, ne
     5e0:      	str	q14, [sp, #0x1230]
     5e4:      	str	q31, [sp, #0x1240]
     5e8:      	str	q25, [sp, #0x1250]
     5ec:      	str	q10, [sp, #0x1260]
     5f0:      	and	x13, x13, #0x7
     5f4:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     5f8:      	add	x9, x9, #0x230
     5fc:      	ldr	x13, [x9, x13, lsl #3]
     600:      	cmp	x13, #0x200
     604:      	b.ge	0x820 <ltmp0+0x820>
     608:      	tst	w11, #0xff
     60c:      	b.eq	0x298 <ltmp0+0x298>
     610:      	mov	w1, #0x0                ; =0
     614:      	str	q14, [sp, #0x510]
     618:      	str	q31, [sp, #0x520]
     61c:      	str	q25, [sp, #0x530]
     620:      	str	q10, [sp, #0x540]
     624:      	mov	w13, w14
     628:      	ubfiz	x17, x13, #3, #3
     62c:      	add	x9, sp, #0x510
     630:      	ldr	x11, [x9, x17]
     634:      	lsl	x2, x11, #3
     638:      	dup.2d	v1, x2
     63c:      	add.2d	v3, v1, v22
     640:      	add.2d	v4, v1, v24
     644:      	add.2d	v6, v1, v27
     648:      	ldp	q7, q0, [sp, #0x2a0]
     64c:      	str	q0, [sp, #0x490]
     650:      	str	q7, [sp, #0x4a0]
     654:      	ldp	q7, q0, [sp, #0x280]
     658:      	str	q0, [sp, #0x4b0]
     65c:      	str	q7, [sp, #0x4c0]
     660:      	add	x9, sp, #0x490
     664:      	ldr	x2, [x9, x17]
     668:      	add.2d	v1, v1, v28
     66c:      	add	x2, x2, x2, lsl #12
     670:      	str	q1, [sp, #0x500]
     674:      	str	q6, [sp, #0x4f0]
     678:      	str	q4, [sp, #0x4e0]
     67c:      	str	q3, [sp, #0x4d0]
     680:      	add	x9, sp, #0x4d0
     684:      	ldr	x17, [x9, x17]
     688:      	sub	x2, x2, x13
     68c:      	add	x17, x2, x17
     690:      	add	x17, x6, x17, lsl #2
     694:      	shl.8b	v1, v21, #0x7
     698:      	cmlt.8b	v1, v1, #0
     69c:      	and.8b	v1, v1, v2
     6a0:      	addv.8b	b1, v1
     6a4:      	fmov	w2, s1
     6a8:      	movi.2d	v1, #0000000000000000
     6ac:      	movi.2d	v3, #0000000000000000
     6b0:      	tbz	w2, #0x0, 0x6f4 <ltmp0+0x6f4>
     6b4:      	ldr	s1, [x17]
     6b8:      	tbnz	w2, #0x1, 0x6f8 <ltmp0+0x6f8>
     6bc:      	tbz	w2, #0x2, 0x704 <ltmp0+0x704>
     6c0:      	add	x4, x17, #0x8
     6c4:      	ld1.s	{ v1 }[2], [x4]
     6c8:      	tbnz	w2, #0x3, 0x708 <ltmp0+0x708>
     6cc:      	tbz	w2, #0x4, 0x714 <ltmp0+0x714>
     6d0:      	add	x4, x17, #0x10
     6d4:      	ld1.s	{ v3 }[0], [x4]
     6d8:      	tbnz	w2, #0x5, 0x718 <ltmp0+0x718>
     6dc:      	tbz	w2, #0x6, 0x724 <ltmp0+0x724>
     6e0:      	add	x4, x17, #0x18
     6e4:      	ld1.s	{ v3 }[2], [x4]
     6e8:      	add	x4, sp, #0xdc0
     6ec:      	tbnz	w2, #0x7, 0x72c <ltmp0+0x72c>
     6f0:      	b	0x734 <ltmp0+0x734>
     6f4:      	tbz	w2, #0x1, 0x6bc <ltmp0+0x6bc>
     6f8:      	add	x4, x17, #0x4
     6fc:      	ld1.s	{ v1 }[1], [x4]
     700:      	tbnz	w2, #0x2, 0x6c0 <ltmp0+0x6c0>
     704:      	tbz	w2, #0x3, 0x6cc <ltmp0+0x6cc>
     708:      	add	x4, x17, #0xc
     70c:      	ld1.s	{ v1 }[3], [x4]
     710:      	tbnz	w2, #0x4, 0x6d0 <ltmp0+0x6d0>
     714:      	tbz	w2, #0x5, 0x6dc <ltmp0+0x6dc>
     718:      	add	x4, x17, #0x14
     71c:      	ld1.s	{ v3 }[1], [x4]
     720:      	tbnz	w2, #0x6, 0x6e0 <ltmp0+0x6e0>
     724:      	add	x4, sp, #0xdc0
     728:      	tbz	w2, #0x7, 0x734 <ltmp0+0x734>
     72c:      	add	x17, x17, #0x1c
     730:      	ld1.s	{ v3 }[3], [x17]
     734:      	lsl	x17, x11, #5
     738:      	dup.2d	v4, x17
     73c:      	ldp	q6, q17, [sp, #0x340]
     740:      	add.2d	v6, v4, v6
     744:      	ldp	q16, q7, [sp, #0x360]
     748:      	add.2d	v7, v4, v7
     74c:      	add.2d	v16, v4, v16
     750:      	add.2d	v4, v4, v17
     754:      	str	q16, [sp, #0x460]
     758:      	str	q7, [sp, #0x450]
     75c:      	str	q4, [sp, #0x470]
     760:      	str	q6, [sp, #0x480]
     764:      	and	x14, x14, #0x7
     768:      	add	x9, sp, #0x450
     76c:      	ldr	x14, [x9, x14, lsl #3]
     770:      	sub	x14, x14, x13, lsl #2
     774:      	ands	w13, w1, #0x1
     778:      	csel	x14, xzr, x14, ne
     77c:      	add	x14, x15, x14
     780:      	ldp	q4, q6, [x14]
     784:      	zip2.8b	v7, v21, v0
     788:      	ushll.4s	v7, v7, #0x0
     78c:      	shl.4s	v7, v7, #0x1f
     790:      	cmlt.4s	v7, v7, #0
     794:      	bif.16b	v3, v6, v7
     798:      	zip1.8b	v6, v21, v0
     79c:      	ushll.4s	v6, v6, #0x0
     7a0:      	shl.4s	v6, v6, #0x1f
     7a4:      	cmlt.4s	v6, v6, #0
     7a8:      	bif.16b	v1, v4, v6
     7ac:      	stp	q1, q3, [x14]
     7b0:      	add	x11, x11, #0x1
     7b4:      	dup.2d	v1, x11
     7b8:      	mov	b3, v21[6]
     7bc:      	mov.b	v3[4], v21[7]
     7c0:      	ushll.2d	v3, v3, #0x0
     7c4:      	shl.2d	v3, v3, #0x3f
     7c8:      	cmlt.2d	v3, v3, #0
     7cc:      	bit.16b	v10, v1, v3
     7d0:      	mov	b3, v21[4]
     7d4:      	mov.b	v3[4], v21[5]
     7d8:      	ushll.2d	v3, v3, #0x0
     7dc:      	shl.2d	v3, v3, #0x3f
     7e0:      	cmlt.2d	v3, v3, #0
     7e4:      	mov	b4, v21[2]
     7e8:      	mov.b	v4[4], v21[3]
     7ec:      	bit.16b	v25, v1, v3
     7f0:      	ushll.2d	v3, v4, #0x0
     7f4:      	shl.2d	v3, v3, #0x3f
     7f8:      	cmlt.2d	v3, v3, #0
     7fc:      	bit.16b	v31, v1, v3
     800:      	mov	b3, v21[0]
     804:      	mov.b	v3[4], v21[1]
     808:      	ushll.2d	v3, v3, #0x0
     80c:      	shl.2d	v3, v3, #0x3f
     810:      	cmlt.2d	v3, v3, #0
     814:      	bit.16b	v14, v1, v3
     818:      	cbnz	w13, 0x298 <ltmp0+0x298>
     81c:      	b	0x5b4 <ltmp0+0x5b4>
     820:      	tst	w11, #0xff
     824:      	b.eq	0x298 <ltmp0+0x298>
     828:      	cmle.2d	v1, v22, #0
     82c:      	cmle.2d	v3, v24, #0
     830:      	uzp1.4s	v1, v1, v3
     834:      	cmle.2d	v3, v27, #0
     838:      	cmle.2d	v4, v28, #0
     83c:      	uzp1.4s	v3, v3, v4
     840:      	uzp1.8h	v1, v1, v3
     844:      	xtn.8b	v1, v1
     848:      	shl.8b	v3, v21, #0x7
     84c:      	cmlt.8b	v3, v3, #0
     850:      	bit.8b	v11, v1, v3
     854:      	and.8b	v1, v21, v1
     858:      	shl.8b	v1, v1, #0x7
     85c:      	cmlt.8b	v3, v1, #0
     860:      	and.8b	v1, v3, v2
     864:      	addv.8b	b1, v1
     868:      	umaxv.8b	b3, v3
     86c:      	fmov	w13, s3
     870:      	tbz	w13, #0x0, 0xa88 <ltmp0+0xa88>
     874:      	dup.2d	v3, x20
     878:      	cmge.2d	v4, v24, v3
     87c:      	cmge.2d	v6, v22, v3
     880:      	uzp1.4s	v4, v6, v4
     884:      	cmge.2d	v6, v27, v3
     888:      	cmge.2d	v3, v28, v3
     88c:      	uzp1.4s	v3, v6, v3
     890:      	uzp1.8h	v3, v4, v3
     894:      	xtn.8b	v3, v3
     898:      	and.8b	v3, v21, v3
     89c:      	shl.8b	v3, v3, #0x7
     8a0:      	cmlt.8b	v3, v3, #0
     8a4:      	and.8b	v3, v3, v2
     8a8:      	addv.8b	b3, v3
     8ac:      	fmov	w13, s3
     8b0:      	tst	w13, #0xff
     8b4:      	b.eq	0xa88 <ltmp0+0xa88>
     8b8:      	subs	w11, w12, #0x1
     8bc:      	csel	w11, wzr, w11, lo
     8c0:      	and	w13, w10, #0xff
     8c4:      	lsr	w14, w13, w11
     8c8:      	tst	w14, #0x1
     8cc:      	ldr	q4, [sp, #0x430]
     8d0:      	str	q4, [sp, #0x5d0]
     8d4:      	ldr	q4, [sp, #0x440]
     8d8:      	str	q4, [sp, #0x5e0]
     8dc:      	and	x11, x11, #0x7
     8e0:      	add	x9, sp, #0x5d0
     8e4:      	ldr	w11, [x9, x11, lsl #2]
     8e8:      	ccmp	w12, #0x0, #0x4, ne
     8ec:      	ccmp	w11, #0x0, #0x0, ne
     8f0:      	cset	w11, ne
     8f4:      	cmp	w13, #0xff
     8f8:      	b.ne	0x900 <ltmp0+0x900>
     8fc:      	tbnz	w11, #0x0, 0x5410 <ltmp0+0x5410>
     900:      	mvn	w13, w10
     904:      	rbit	w13, w13
     908:      	clz	w13, w13
     90c:      	mov	w9, #0xff               ; =255
     910:      	bics	wzr, w9, w10
     914:      	csel	w13, wzr, w13, eq
     918:      	ubfiz	x14, x13, #2, #3
     91c:      	lsl	w17, w20, w13
     920:      	ldr	q5, [sp, #0x430]
     924:      	str	q5, [sp, #0x5b0]
     928:      	ldr	q4, [sp, #0x440]
     92c:      	str	q4, [sp, #0x5c0]
     930:      	add	x9, sp, #0x5b0
     934:      	ldr	w1, [x9, x14]
     938:      	cmp	w11, #0x0
     93c:      	csel	w11, w17, wzr, ne
     940:      	csel	w17, wzr, w1, ne
     944:      	str	q5, [sp, #0x590]
     948:      	str	q4, [sp, #0x5a0]
     94c:      	add	x9, sp, #0x590
     950:      	str	w17, [x9, x14]
     954:      	ldr	q4, [sp, #0x5a0]
     958:      	str	q4, [sp, #0x440]
     95c:      	ldr	q4, [sp, #0x590]
     960:      	str	q4, [sp, #0x430]
     964:      	ldr	q5, [sp, #0x410]
     968:      	str	q5, [sp, #0x570]
     96c:      	ldr	q4, [sp, #0x420]
     970:      	str	q4, [sp, #0x580]
     974:      	add	x9, sp, #0x570
     978:      	ldr	w17, [x9, x14]
     97c:      	csel	w17, w12, w17, ne
     980:      	str	q5, [sp, #0x550]
     984:      	str	q4, [sp, #0x560]
     988:      	add	x9, sp, #0x550
     98c:      	str	w17, [x9, x14]
     990:      	ldrb	w14, [x27, x13]
     994:      	and	w17, w14, #0x1
     998:      	fmov	s4, w17
     99c:      	ubfx	w17, w14, #1, #1
     9a0:      	mov.b	v4[1], w17
     9a4:      	ubfx	w17, w14, #2, #1
     9a8:      	mov.b	v4[2], w17
     9ac:      	ubfx	w17, w14, #3, #1
     9b0:      	mov.b	v4[3], w17
     9b4:      	ubfx	w17, w14, #4, #1
     9b8:      	mov.b	v4[4], w17
     9bc:      	ubfx	w17, w14, #5, #1
     9c0:      	mov.b	v4[5], w17
     9c4:      	ubfx	w17, w14, #6, #1
     9c8:      	mov.b	v4[6], w17
     9cc:      	ldr	q5, [sp, #0x560]
     9d0:      	str	q5, [sp, #0x420]
     9d4:      	ldr	q5, [sp, #0x550]
     9d8:      	str	q5, [sp, #0x410]
     9dc:      	lsr	w14, w14, #7
     9e0:      	mov.b	v4[7], w14
     9e4:      	ldrb	w14, [x8, x13]
     9e8:      	and	w17, w14, #0x1
     9ec:      	fmov	s6, w17
     9f0:      	ubfx	w17, w14, #1, #1
     9f4:      	mov.b	v6[1], w17
     9f8:      	ubfx	w17, w14, #2, #1
     9fc:      	mov.b	v6[2], w17
     a00:      	ubfx	w17, w14, #3, #1
     a04:      	mov.b	v6[3], w17
     a08:      	ubfx	w17, w14, #4, #1
     a0c:      	mov.b	v6[4], w17
     a10:      	ubfx	w17, w14, #5, #1
     a14:      	mov.b	v6[5], w17
     a18:      	ubfx	w17, w14, #6, #1
     a1c:      	mov.b	v6[6], w17
     a20:      	lsr	w14, w14, #7
     a24:      	mov.b	v6[7], w14
     a28:      	csetm	w14, ne
     a2c:      	dup.8b	v7, w14
     a30:      	bit.8b	v4, v21, v7
     a34:      	shl.8b	v4, v4, #0x7
     a38:      	cmlt.8b	v4, v4, #0
     a3c:      	and.8b	v4, v4, v2
     a40:      	addv.8b	b4, v4
     a44:      	str	b4, [x27, x13]
     a48:      	bic.8b	v4, v6, v7
     a4c:      	shl.8b	v4, v4, #0x7
     a50:      	cmlt.8b	v4, v4, #0
     a54:      	and.8b	v4, v4, v2
     a58:      	addv.8b	b4, v4
     a5c:      	str	b4, [x8, x13]
     a60:      	csinc	w12, w12, w13, eq
     a64:      	cmp	w26, #0x8
     a68:      	b.hs	0x5410 <ltmp0+0x5410>
     a6c:      	str	b1, [x21, x28]
     a70:      	mov	w9, #0x4                ; =4
     a74:      	str	w9, [x22, x28, lsl #2]
     a78:      	str	w12, [x23, x28, lsl #2]
     a7c:      	cmp	w19, #0x8
     a80:      	b.lo	0x280 <ltmp0+0x280>
     a84:      	b	0x5410 <ltmp0+0x5410>
     a88:      	fmov	w13, s1
     a8c:      	tst	w13, #0xff
     a90:      	b.eq	0xf98 <ltmp0+0xf98>
     a94:      	tst	w11, #0xff
     a98:      	b.eq	0x298 <ltmp0+0x298>
     a9c:      	rbit	w13, w11
     aa0:      	clz	w13, w13
     aa4:      	tst	w11, #0xff
     aa8:      	csel	w13, wzr, w13, eq
     aac:      	ldp	q1, q0, [sp, #0x2a0]
     ab0:      	str	q0, [sp, #0x11f0]
     ab4:      	str	q1, [sp, #0x1200]
     ab8:      	ldp	q1, q0, [sp, #0x280]
     abc:      	str	q0, [sp, #0x1210]
     ac0:      	str	q1, [sp, #0x1220]
     ac4:      	ubfiz	x14, x13, #3, #3
     ac8:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     acc:      	add	x9, x9, #0x1f0
     ad0:      	ldr	x17, [x9, x14]
     ad4:      	str	q22, [sp, #0x11b0]
     ad8:      	str	q24, [sp, #0x11c0]
     adc:      	str	q27, [sp, #0x11d0]
     ae0:      	str	q28, [sp, #0x11e0]
     ae4:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     ae8:      	add	x9, x9, #0x1b0
     aec:      	ldr	x14, [x9, x14]
     af0:      	add	x17, x17, x17, lsl #12
     af4:      	sub	x14, x14, x13
     af8:      	add	x14, x14, x17
     afc:      	add	x14, x6, x14, lsl #2
     b00:      	add	x14, x14, #0x4, lsl #12 ; =0x4000
     b04:      	shl.8b	v1, v21, #0x7
     b08:      	cmlt.8b	v1, v1, #0
     b0c:      	and.8b	v1, v1, v2
     b10:      	addv.8b	b1, v1
     b14:      	fmov	w17, s1
     b18:      	movi.2d	v1, #0000000000000000
     b1c:      	movi.2d	v3, #0000000000000000
     b20:      	tbz	w17, #0x0, 0xb60 <ltmp0+0xb60>
     b24:      	ldr	s1, [x14]
     b28:      	tbnz	w17, #0x1, 0xb64 <ltmp0+0xb64>
     b2c:      	tbz	w17, #0x2, 0xb70 <ltmp0+0xb70>
     b30:      	add	x1, x14, #0x8
     b34:      	ld1.s	{ v1 }[2], [x1]
     b38:      	tbnz	w17, #0x3, 0xb74 <ltmp0+0xb74>
     b3c:      	tbz	w17, #0x4, 0xb80 <ltmp0+0xb80>
     b40:      	add	x1, x14, #0x10
     b44:      	ld1.s	{ v3 }[0], [x1]
     b48:      	tbnz	w17, #0x5, 0xb84 <ltmp0+0xb84>
     b4c:      	tbz	w17, #0x6, 0xb90 <ltmp0+0xb90>
     b50:      	add	x1, x14, #0x18
     b54:      	ld1.s	{ v3 }[2], [x1]
     b58:      	tbnz	w17, #0x7, 0xb94 <ltmp0+0xb94>
     b5c:      	b	0xb9c <ltmp0+0xb9c>
     b60:      	tbz	w17, #0x1, 0xb2c <ltmp0+0xb2c>
     b64:      	add	x1, x14, #0x4
     b68:      	ld1.s	{ v1 }[1], [x1]
     b6c:      	tbnz	w17, #0x2, 0xb30 <ltmp0+0xb30>
     b70:      	tbz	w17, #0x3, 0xb3c <ltmp0+0xb3c>
     b74:      	add	x1, x14, #0xc
     b78:      	ld1.s	{ v1 }[3], [x1]
     b7c:      	tbnz	w17, #0x4, 0xb40 <ltmp0+0xb40>
     b80:      	tbz	w17, #0x5, 0xb4c <ltmp0+0xb4c>
     b84:      	add	x1, x14, #0x14
     b88:      	ld1.s	{ v3 }[1], [x1]
     b8c:      	tbnz	w17, #0x6, 0xb50 <ltmp0+0xb50>
     b90:      	tbz	w17, #0x7, 0xb9c <ltmp0+0xb9c>
     b94:      	add	x14, x14, #0x1c
     b98:      	ld1.s	{ v3 }[3], [x14]
     b9c:      	ldp	q4, q0, [sp, #0x360]
     ba0:      	str	q0, [sp, #0x1170]
     ba4:      	str	q4, [sp, #0x1180]
     ba8:      	ldp	q4, q0, [sp, #0x340]
     bac:      	str	q0, [sp, #0x1190]
     bb0:      	str	q4, [sp, #0x11a0]
     bb4:      	and	x14, x13, #0x7
     bb8:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     bbc:      	add	x9, x9, #0x170
     bc0:      	ldr	x14, [x9, x14, lsl #3]
     bc4:      	sub	x13, x14, x13, lsl #2
     bc8:      	add	x13, x13, #0x4, lsl #12 ; =0x4000
     bcc:      	ands	w11, w11, #0xff
     bd0:      	csel	x13, xzr, x13, eq
     bd4:      	add	x13, x15, x13
     bd8:      	ldp	q4, q6, [x13]
     bdc:      	zip2.8b	v7, v21, v0
     be0:      	ushll.4s	v7, v7, #0x0
     be4:      	shl.4s	v7, v7, #0x1f
     be8:      	cmlt.4s	v7, v7, #0
     bec:      	bif.16b	v3, v6, v7
     bf0:      	zip1.8b	v6, v21, v0
     bf4:      	ushll.4s	v6, v6, #0x0
     bf8:      	shl.4s	v6, v6, #0x1f
     bfc:      	cmlt.4s	v6, v6, #0
     c00:      	bif.16b	v1, v4, v6
     c04:      	stp	q1, q3, [x13]
     c08:      	cbz	w11, 0x298 <ltmp0+0x298>
     c0c:      	cbz	w12, 0xdd4 <ltmp0+0xdd4>
     c10:      	mov	w11, #0x0               ; =0
     c14:      	shl.8b	v1, v21, #0x7
     c18:      	cmlt.8b	v1, v1, #0
     c1c:      	and.8b	v3, v1, v2
     c20:      	addv.8b	b3, v3
     c24:      	fmov	w13, s3
     c28:      	umaxv.8b	b1, v1
     c2c:      	fmov	w2, s1
     c30:      	sub	w14, w12, #0x1
     c34:      	tst	w13, #0xff
     c38:      	csel	w14, w14, wzr, ne
     c3c:      	lsl	w17, w20, w14
     c40:      	and	w13, w17, w10
     c44:      	tst	w13, #0xff
     c48:      	cset	w4, ne
     c4c:      	ldr	q1, [sp, #0x430]
     c50:      	str	q1, [sp, #0x1150]
     c54:      	ldr	q1, [sp, #0x440]
     c58:      	str	q1, [sp, #0x1160]
     c5c:      	ubfiz	x13, x14, #2, #3
     c60:      	ldr	w1, [x0, x13]
     c64:      	cmp	w1, #0x0
     c68:      	cset	w1, eq
     c6c:      	and	w2, w4, w2
     c70:      	ldrb	w4, [x27, w14, sxtw]
     c74:      	and	w5, w4, #0x1
     c78:      	fmov	s1, w5
     c7c:      	ubfx	w5, w4, #1, #1
     c80:      	mov.b	v1[1], w5
     c84:      	ubfx	w5, w4, #2, #1
     c88:      	mov.b	v1[2], w5
     c8c:      	ubfx	w5, w4, #3, #1
     c90:      	mov.b	v1[3], w5
     c94:      	ubfx	w5, w4, #4, #1
     c98:      	mov.b	v1[4], w5
     c9c:      	ubfx	w5, w4, #5, #1
     ca0:      	mov.b	v1[5], w5
     ca4:      	ubfx	w5, w4, #6, #1
     ca8:      	mov.b	v1[6], w5
     cac:      	lsr	w4, w4, #7
     cb0:      	mov.b	v1[7], w4
     cb4:      	ldrb	w4, [x8, w14, sxtw]
     cb8:      	and	w5, w4, #0x1
     cbc:      	fmov	s3, w5
     cc0:      	ubfx	w5, w4, #1, #1
     cc4:      	mov.b	v3[1], w5
     cc8:      	ubfx	w5, w4, #2, #1
     ccc:      	mov.b	v3[2], w5
     cd0:      	ubfx	w5, w4, #3, #1
     cd4:      	mov.b	v3[3], w5
     cd8:      	ubfx	w5, w4, #4, #1
     cdc:      	mov.b	v3[4], w5
     ce0:      	ubfx	w5, w4, #5, #1
     ce4:      	mov.b	v3[5], w5
     ce8:      	ubfx	w5, w4, #6, #1
     cec:      	mov.b	v3[6], w5
     cf0:      	lsr	w4, w4, #7
     cf4:      	mov.b	v3[7], w4
     cf8:      	orr.8b	v4, v21, v3
     cfc:      	and.8b	v6, v9, v1
     d00:      	eor.8b	v6, v6, v4
     d04:      	shl.8b	v6, v6, #0x7
     d08:      	cmlt.8b	v6, v6, #0
     d0c:      	umaxv.8b	b6, v6
     d10:      	fmov	w4, s6
     d14:      	ands	w1, w2, w1
     d18:      	csetm	w2, ne
     d1c:      	bics	w4, w1, w4
     d20:      	csetm	w5, ne
     d24:      	dup.8b	v6, w5
     d28:      	mov	w5, #-0x1               ; =-1
     d2c:      	dup.8b	v7, w2
     d30:      	bic.8b	v16, v4, v6
     d34:      	bit.8b	v3, v16, v7
     d38:      	shl.8b	v3, v3, #0x7
     d3c:      	cmlt.8b	v3, v3, #0
     d40:      	and.8b	v3, v3, v2
     d44:      	addv.8b	b3, v3
     d48:      	str	b3, [x8, w14, sxtw]
     d4c:      	bic.8b	v1, v1, v6
     d50:      	shl.8b	v1, v1, #0x7
     d54:      	cmlt.8b	v1, v1, #0
     d58:      	and.8b	v1, v1, v2
     d5c:      	addv.8b	b1, v1
     d60:      	str	b1, [x27, w14, sxtw]
     d64:      	csinv	w14, w5, w17, eq
     d68:      	dup.8b	v1, w1
     d6c:      	and	w10, w14, w10
     d70:      	shl.8b	v1, v1, #0x7
     d74:      	cmlt.8b	v1, v1, #0
     d78:      	dup.8b	v3, w4
     d7c:      	and.8b	v3, v3, v4
     d80:      	ldr	q4, [sp, #0x410]
     d84:      	str	q4, [sp, #0x1130]
     d88:      	ldr	q4, [sp, #0x420]
     d8c:      	str	q4, [sp, #0x1140]
     d90:      	ldr	w13, [x16, x13]
     d94:      	csel	w12, w13, w12, ne
     d98:      	bit.8b	v21, v3, v1
     d9c:      	shl.8b	v1, v21, #0x7
     da0:      	cmlt.8b	v1, v1, #0
     da4:      	and.8b	v1, v1, v2
     da8:      	addv.8b	b1, v1
     dac:      	fmov	w13, s1
     db0:      	cmp	w1, #0x1
     db4:      	b.ne	0xde8 <ltmp0+0xde8>
     db8:      	cmp	w12, #0x0
     dbc:      	ccmp	w11, #0x6, #0x2, ne
     dc0:      	b.hi	0xde8 <ltmp0+0xde8>
     dc4:      	add	w11, w11, #0x1
     dc8:      	tst	w13, #0xff
     dcc:      	b.ne	0xc14 <ltmp0+0xc14>
     dd0:      	b	0xde8 <ltmp0+0xde8>
     dd4:      	shl.8b	v1, v21, #0x7
     dd8:      	cmlt.8b	v1, v1, #0
     ddc:      	and.8b	v1, v1, v2
     de0:      	addv.8b	b1, v1
     de4:      	fmov	w13, s1
     de8:      	tst	w13, #0xff
     dec:      	b.eq	0xfa4 <ltmp0+0xfa4>
     df0:      	rbit	w11, w13
     df4:      	clz	w11, w11
     df8:      	ldp	q1, q0, [sp, #0x360]
     dfc:      	str	q0, [sp, #0x10f0]
     e00:      	str	q1, [sp, #0x1100]
     e04:      	ldp	q1, q0, [sp, #0x340]
     e08:      	str	q0, [sp, #0x1110]
     e0c:      	str	q1, [sp, #0x1120]
     e10:      	and	x13, x11, #0x7
     e14:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     e18:      	add	x9, x9, #0xf0
     e1c:      	ldr	x13, [x9, x13, lsl #3]
     e20:      	lsl	w11, w11, #2
     e24:      	sub	x11, x13, x11
     e28:      	add	x11, x15, x11
     e2c:      	ldp	q1, q3, [x11]
     e30:      	fmul.4s	v29, v1, v1
     e34:      	fmul.4s	v3, v3, v3
     e38:      	ldp	q4, q6, [x11, #0x20]
     e3c:      	fmul.4s	v0, v4, v4
     e40:      	stp	q0, q24, [sp, #0x2e0]
     e44:      	fmul.4s	v6, v6, v6
     e48:      	ldp	q7, q16, [x11, #0x40]
     e4c:      	fmul.4s	v7, v7, v7
     e50:      	fmul.4s	v16, v16, v16
     e54:      	mov.16b	v24, v19
     e58:      	ldp	q19, q17, [x11, #0x60]
     e5c:      	fmul.4s	v19, v19, v19
     e60:      	fmul.4s	v17, v17, v17
     e64:      	mov	b20, v21[6]
     e68:      	mov.b	v20[4], v21[7]
     e6c:      	ushll.2d	v20, v20, #0x0
     e70:      	shl.2d	v20, v20, #0x3f
     e74:      	cmlt.2d	v20, v20, #0
     e78:      	mov	w9, #0x4                ; =4
     e7c:      	mov.16b	v5, v23
     e80:      	dup.2d	v23, x9
     e84:      	ldr	q0, [sp, #0x390]
     e88:      	bit.16b	v0, v23, v20
     e8c:      	stp	q27, q0, [sp, #0x380]
     e90:      	mov	b20, v21[4]
     e94:      	mov.b	v20[4], v21[5]
     e98:      	ushll.2d	v20, v20, #0x0
     e9c:      	shl.2d	v20, v20, #0x3f
     ea0:      	cmlt.2d	v20, v20, #0
     ea4:      	fmov	d1, d9
     ea8:      	mov.16b	v0, v31
     eac:      	mov.16b	v31, v15
     eb0:      	ldr	q15, [sp, #0x3b0]
     eb4:      	bit.16b	v15, v23, v20
     eb8:      	str	q15, [sp, #0x3b0]
     ebc:      	mov.16b	v15, v31
     ec0:      	mov.16b	v31, v0
     ec4:      	ldr	q0, [sp, #0x3a0]
     ec8:      	fmov	d9, d1
     ecc:      	mov	b20, v21[2]
     ed0:      	mov.b	v20[4], v21[3]
     ed4:      	ushll.2d	v20, v20, #0x0
     ed8:      	shl.2d	v20, v20, #0x3f
     edc:      	cmlt.2d	v20, v20, #0
     ee0:      	bit.16b	v13, v23, v20
     ee4:      	mov	b20, v21[0]
     ee8:      	mov.b	v20[4], v21[1]
     eec:      	ushll.2d	v20, v20, #0x0
     ef0:      	shl.2d	v20, v20, #0x3f
     ef4:      	cmlt.2d	v20, v20, #0
     ef8:      	bit.16b	v30, v23, v20
     efc:      	zip1.8b	v20, v21, v0
     f00:      	ushll.4s	v20, v20, #0x0
     f04:      	shl.4s	v20, v20, #0x1f
     f08:      	cmlt.4s	v20, v20, #0
     f0c:      	zip2.8b	v23, v21, v0
     f10:      	ushll.4s	v23, v23, #0x0
     f14:      	shl.4s	v23, v23, #0x1f
     f18:      	cmlt.4s	v23, v23, #0
     f1c:      	bit.16b	v0, v3, v23
     f20:      	str	q0, [sp, #0x3a0]
     f24:      	ldr	q3, [sp, #0x330]
     f28:      	bit.16b	v3, v29, v20
     f2c:      	str	q3, [sp, #0x330]
     f30:      	ldr	q1, [sp, #0x300]
     f34:      	bit.16b	v1, v6, v23
     f38:      	str	q1, [sp, #0x300]
     f3c:      	ldr	q1, [sp, #0x230]
     f40:      	ldr	q0, [sp, #0x2e0]
     f44:      	bit.16b	v1, v0, v20
     f48:      	str	q1, [sp, #0x230]
     f4c:      	ldr	q1, [sp, #0x240]
     f50:      	bit.16b	v1, v16, v23
     f54:      	str	q1, [sp, #0x240]
     f58:      	ldr	q1, [sp, #0x250]
     f5c:      	bit.16b	v1, v7, v20
     f60:      	str	q1, [sp, #0x250]
     f64:      	ldr	q1, [sp, #0x270]
     f68:      	bit.16b	v1, v17, v23
     f6c:      	str	q1, [sp, #0x270]
     f70:      	mov.16b	v23, v5
     f74:      	ldr	q1, [sp, #0x260]
     f78:      	bit.16b	v1, v19, v20
     f7c:      	movi.8b	v20, #0x1
     f80:      	mov.16b	v19, v24
     f84:      	ldr	q24, [sp, #0x2f0]
     f88:      	ldr	q27, [sp, #0x380]
     f8c:      	str	q1, [sp, #0x260]
     f90:      	add	x4, sp, #0xdc0
     f94:      	b	0xfac <ltmp0+0xfac>
     f98:      	tst	w11, #0xff
     f9c:      	b.ne	0xc0c <ltmp0+0xc0c>
     fa0:      	b	0x298 <ltmp0+0x298>
     fa4:      	add	x4, sp, #0xdc0
     fa8:      	b	0x298 <ltmp0+0x298>
     fac:      	shl.8b	v1, v21, #0x7
     fb0:      	cmlt.8b	v1, v1, #0
     fb4:      	and.8b	v1, v1, v2
     fb8:      	addv.8b	b1, v1
     fbc:      	fmov	w13, s1
     fc0:      	mov	w9, #0x200              ; =512
     fc4:      	dup.2d	v3, x9
     fc8:      	cmgt.2d	v1, v3, v13
     fcc:      	cmgt.2d	v4, v3, v30
     fd0:      	uzp1.4s	v1, v4, v1
     fd4:      	ldr	q5, [sp, #0x3b0]
     fd8:      	cmgt.2d	v4, v3, v5
     fdc:      	ldr	q0, [sp, #0x390]
     fe0:      	cmgt.2d	v6, v3, v0
     fe4:      	uzp1.4s	v4, v4, v6
     fe8:      	uzp1.8h	v1, v1, v4
     fec:      	xtn.8b	v1, v1
     ff0:      	and.8b	v1, v21, v1
     ff4:      	shl.8b	v1, v1, #0x7
     ff8:      	cmlt.8b	v4, v1, #0
     ffc:      	and.8b	v1, v4, v2
    1000:      	addv.8b	b1, v1
    1004:      	fmov	w11, s1
    1008:      	umaxv.8b	b4, v4
    100c:      	fmov	w14, s4
    1010:      	tbz	w14, #0x0, 0x1234 <ltmp0+0x1234>
    1014:      	cmge.2d	v4, v13, v3
    1018:      	cmge.2d	v6, v30, v3
    101c:      	uzp1.4s	v4, v6, v4
    1020:      	cmge.2d	v6, v5, v3
    1024:      	ldr	q0, [sp, #0x390]
    1028:      	cmge.2d	v3, v0, v3
    102c:      	uzp1.4s	v3, v6, v3
    1030:      	uzp1.8h	v3, v4, v3
    1034:      	xtn.8b	v3, v3
    1038:      	and.8b	v3, v21, v3
    103c:      	shl.8b	v3, v3, #0x7
    1040:      	cmlt.8b	v3, v3, #0
    1044:      	and.8b	v3, v3, v2
    1048:      	addv.8b	b3, v3
    104c:      	fmov	w14, s3
    1050:      	tst	w14, #0xff
    1054:      	b.eq	0x1234 <ltmp0+0x1234>
    1058:      	subs	w11, w12, #0x1
    105c:      	csel	w11, wzr, w11, lo
    1060:      	and	w13, w10, #0xff
    1064:      	lsr	w14, w13, w11
    1068:      	tst	w14, #0x1
    106c:      	ldr	q4, [sp, #0x430]
    1070:      	str	q4, [sp, #0x670]
    1074:      	ldr	q4, [sp, #0x440]
    1078:      	str	q4, [sp, #0x680]
    107c:      	and	x11, x11, #0x7
    1080:      	add	x9, sp, #0x670
    1084:      	ldr	w11, [x9, x11, lsl #2]
    1088:      	ccmp	w12, #0x0, #0x4, ne
    108c:      	ccmp	w11, #0x1, #0x0, ne
    1090:      	cset	w11, ne
    1094:      	cmp	w13, #0xff
    1098:      	b.ne	0x10a0 <ltmp0+0x10a0>
    109c:      	tbnz	w11, #0x0, 0x5410 <ltmp0+0x5410>
    10a0:      	mvn	w13, w10
    10a4:      	rbit	w13, w13
    10a8:      	clz	w13, w13
    10ac:      	mov	w9, #0xff               ; =255
    10b0:      	bics	wzr, w9, w10
    10b4:      	csel	w13, wzr, w13, eq
    10b8:      	ubfiz	x14, x13, #2, #3
    10bc:      	lsl	w17, w20, w13
    10c0:      	ldr	q5, [sp, #0x430]
    10c4:      	str	q5, [sp, #0x650]
    10c8:      	ldr	q4, [sp, #0x440]
    10cc:      	str	q4, [sp, #0x660]
    10d0:      	add	x9, sp, #0x650
    10d4:      	ldr	w1, [x9, x14]
    10d8:      	cmp	w11, #0x0
    10dc:      	csel	w11, w17, wzr, ne
    10e0:      	csinc	w17, w1, wzr, eq
    10e4:      	str	q5, [sp, #0x630]
    10e8:      	str	q4, [sp, #0x640]
    10ec:      	add	x9, sp, #0x630
    10f0:      	str	w17, [x9, x14]
    10f4:      	ldr	q4, [sp, #0x640]
    10f8:      	str	q4, [sp, #0x440]
    10fc:      	ldr	q4, [sp, #0x630]
    1100:      	str	q4, [sp, #0x430]
    1104:      	ldr	q5, [sp, #0x410]
    1108:      	str	q5, [sp, #0x610]
    110c:      	ldr	q4, [sp, #0x420]
    1110:      	str	q4, [sp, #0x620]
    1114:      	add	x9, sp, #0x610
    1118:      	ldr	w17, [x9, x14]
    111c:      	csel	w17, w12, w17, ne
    1120:      	str	q5, [sp, #0x5f0]
    1124:      	str	q4, [sp, #0x600]
    1128:      	add	x9, sp, #0x5f0
    112c:      	str	w17, [x9, x14]
    1130:      	ldrb	w14, [x27, x13]
    1134:      	and	w17, w14, #0x1
    1138:      	fmov	s4, w17
    113c:      	ubfx	w17, w14, #1, #1
    1140:      	mov.b	v4[1], w17
    1144:      	ubfx	w17, w14, #2, #1
    1148:      	mov.b	v4[2], w17
    114c:      	ubfx	w17, w14, #3, #1
    1150:      	mov.b	v4[3], w17
    1154:      	ubfx	w17, w14, #4, #1
    1158:      	mov.b	v4[4], w17
    115c:      	ubfx	w17, w14, #5, #1
    1160:      	mov.b	v4[5], w17
    1164:      	ubfx	w17, w14, #6, #1
    1168:      	mov.b	v4[6], w17
    116c:      	ldr	q5, [sp, #0x600]
    1170:      	str	q5, [sp, #0x420]
    1174:      	ldr	q5, [sp, #0x5f0]
    1178:      	str	q5, [sp, #0x410]
    117c:      	lsr	w14, w14, #7
    1180:      	mov.b	v4[7], w14
    1184:      	ldrb	w14, [x8, x13]
    1188:      	and	w17, w14, #0x1
    118c:      	fmov	s6, w17
    1190:      	ubfx	w17, w14, #1, #1
    1194:      	mov.b	v6[1], w17
    1198:      	ubfx	w17, w14, #2, #1
    119c:      	mov.b	v6[2], w17
    11a0:      	ubfx	w17, w14, #3, #1
    11a4:      	mov.b	v6[3], w17
    11a8:      	ubfx	w17, w14, #4, #1
    11ac:      	mov.b	v6[4], w17
    11b0:      	ubfx	w17, w14, #5, #1
    11b4:      	mov.b	v6[5], w17
    11b8:      	ubfx	w17, w14, #6, #1
    11bc:      	mov.b	v6[6], w17
    11c0:      	lsr	w14, w14, #7
    11c4:      	mov.b	v6[7], w14
    11c8:      	csetm	w14, ne
    11cc:      	dup.8b	v7, w14
    11d0:      	bit.8b	v4, v21, v7
    11d4:      	shl.8b	v4, v4, #0x7
    11d8:      	cmlt.8b	v4, v4, #0
    11dc:      	and.8b	v4, v4, v2
    11e0:      	addv.8b	b4, v4
    11e4:      	str	b4, [x27, x13]
    11e8:      	bic.8b	v4, v6, v7
    11ec:      	shl.8b	v4, v4, #0x7
    11f0:      	cmlt.8b	v4, v4, #0
    11f4:      	and.8b	v4, v4, v2
    11f8:      	addv.8b	b4, v4
    11fc:      	str	b4, [x8, x13]
    1200:      	csinc	w12, w12, w13, eq
    1204:      	cmp	w26, #0x8
    1208:      	b.hs	0x5410 <ltmp0+0x5410>
    120c:      	str	b1, [x21, x28]
    1210:      	mov	w9, #0x7                ; =7
    1214:      	str	w9, [x22, x28, lsl #2]
    1218:      	str	w12, [x23, x28, lsl #2]
    121c:      	cmp	w19, #0x8
    1220:      	b.hs	0x5410 <ltmp0+0x5410>
    1224:      	str	b3, [x21, w19, uxtw]
    1228:      	orr	w10, w11, w10
    122c:      	mov	w9, #0x8                ; =8
    1230:      	b	0x28c <ltmp0+0x28c>
    1234:      	tst	w11, #0xff
    1238:      	b.eq	0x1844 <ltmp0+0x1844>
    123c:      	tst	w13, #0xff
    1240:      	b.eq	0x298 <ltmp0+0x298>
    1244:      	mov	w11, #0x0               ; =0
    1248:      	mov.16b	v0, v10
    124c:      	mov.16b	v10, v15
    1250:      	mov.16b	v15, v19
    1254:      	stp	q25, q14, [sp, #0xa0]
    1258:      	str	q31, [sp, #0x90]
    125c:      	str	q8, [sp, #0x1e0]
    1260:      	ldr	q4, [sp, #0x3b0]
    1264:      	str	q23, [sp, #0x2d0]
    1268:      	str	q30, [sp, #0xd0]
    126c:      	shl.2d	v1, v30, #0x5
    1270:      	shl.2d	v6, v13, #0x5
    1274:      	shl.2d	v3, v4, #0x5
    1278:      	ldr	q4, [sp, #0x390]
    127c:      	shl.2d	v4, v4, #0x5
    1280:      	ldp	q5, q7, [sp, #0x340]
    1284:      	add.2d	v4, v4, v5
    1288:      	add.2d	v3, v3, v7
    128c:      	ldr	q7, [sp, #0x360]
    1290:      	add.2d	v16, v6, v7
    1294:      	ldr	q6, [sp, #0x370]
    1298:      	add.2d	v17, v1, v6
    129c:      	ldp	q1, q5, [sp, #0x1b0]
    12a0:      	add.2d	v25, v5, v17
    12a4:      	add.2d	v23, v1, v16
    12a8:      	ldp	q1, q5, [sp, #0x190]
    12ac:      	add.2d	v20, v5, v3
    12b0:      	add.2d	v6, v1, v4
    12b4:      	shl.8b	v1, v21, #0x7
    12b8:      	cmlt.8b	v1, v1, #0
    12bc:      	and.8b	v1, v1, v2
    12c0:      	addv.8b	b7, v1
    12c4:      	fmov	w13, s7
    12c8:      	movi.2d	v1, #0000000000000000
    12cc:      	movi.2d	v19, #0000000000000000
    12d0:      	stp	q12, q26, [sp, #0x170]
    12d4:      	stp	q10, q15, [sp, #0xe0]
    12d8:      	stp	q18, q24, [sp, #0x2e0]
    12dc:      	str	q13, [sp, #0xc0]
    12e0:      	str	q22, [sp, #0x1d0]
    12e4:      	str	q27, [sp, #0x380]
    12e8:      	str	q28, [sp, #0x2c0]
    12ec:      	str	q11, [sp, #0x160]
    12f0:      	tbz	w13, #0x0, 0x1358 <ltmp0+0x1358>
    12f4:      	fmov	x14, d25
    12f8:      	ldr	s1, [x14]
    12fc:      	tbnz	w13, #0x1, 0x135c <ltmp0+0x135c>
    1300:      	tbz	w13, #0x2, 0x1368 <ltmp0+0x1368>
    1304:      	fmov	x14, d23
    1308:      	ld1.s	{ v1 }[2], [x14]
    130c:      	fmov	d11, d9
    1310:      	tbnz	w13, #0x3, 0x1370 <ltmp0+0x1370>
    1314:      	ldr	q18, [sp, #0x400]
    1318:      	ldr	q23, [sp, #0x250]
    131c:      	tbz	w13, #0x4, 0x1384 <ltmp0+0x1384>
    1320:      	ldp	q8, q13, [sp, #0x3d0]
    1324:      	ldr	q29, [sp, #0x3f0]
    1328:      	fmov	x14, d20
    132c:      	ld1.s	{ v19 }[0], [x14]
    1330:      	ldp	q5, q24, [sp, #0x230]
    1334:      	mov.16b	v22, v23
    1338:      	tbz	w13, #0x5, 0x1344 <ltmp0+0x1344>
    133c:      	mov.d	x14, v20[1]
    1340:      	ld1.s	{ v19 }[1], [x14]
    1344:      	tbz	w13, #0x6, 0x139c <ltmp0+0x139c>
    1348:      	fmov	x14, d6
    134c:      	ld1.s	{ v19 }[2], [x14]
    1350:      	tbnz	w13, #0x7, 0x13a0 <ltmp0+0x13a0>
    1354:      	b	0x13a8 <ltmp0+0x13a8>
    1358:      	tbz	w13, #0x1, 0x1300 <ltmp0+0x1300>
    135c:      	mov.d	x14, v25[1]
    1360:      	ld1.s	{ v1 }[1], [x14]
    1364:      	tbnz	w13, #0x2, 0x1304 <ltmp0+0x1304>
    1368:      	fmov	d11, d9
    136c:      	tbz	w13, #0x3, 0x1314 <ltmp0+0x1314>
    1370:      	ldr	q18, [sp, #0x400]
    1374:      	mov.d	x14, v23[1]
    1378:      	ld1.s	{ v1 }[3], [x14]
    137c:      	ldr	q23, [sp, #0x250]
    1380:      	tbnz	w13, #0x4, 0x1320 <ltmp0+0x1320>
    1384:      	ldp	q8, q13, [sp, #0x3d0]
    1388:      	ldr	q29, [sp, #0x3f0]
    138c:      	ldp	q5, q24, [sp, #0x230]
    1390:      	mov.16b	v22, v23
    1394:      	tbnz	w13, #0x5, 0x133c <ltmp0+0x133c>
    1398:      	b	0x1344 <ltmp0+0x1344>
    139c:      	tbz	w13, #0x7, 0x13a8 <ltmp0+0x13a8>
    13a0:      	mov.d	x13, v6[1]
    13a4:      	ld1.s	{ v19 }[3], [x13]
    13a8:      	fmul.4s	v6, v19, v19
    13ac:      	fmul.4s	v1, v1, v1
    13b0:      	ldr	q19, [sp, #0x330]
    13b4:      	fadd.4s	v1, v19, v1
    13b8:      	str	q1, [sp, #0x250]
    13bc:      	ldr	q1, [sp, #0x3a0]
    13c0:      	fadd.4s	v1, v1, v6
    13c4:      	str	q1, [sp, #0x130]
    13c8:      	ldp	q6, q1, [sp, #0x190]
    13cc:      	add.2d	v23, v4, v6
    13d0:      	add.2d	v3, v3, v1
    13d4:      	ldp	q1, q6, [sp, #0x1b0]
    13d8:      	add.2d	v4, v17, v6
    13dc:      	add.2d	v20, v16, v1
    13e0:      	mov	w9, #0x20               ; =32
    13e4:      	dup.2d	v16, x9
    13e8:      	add.2d	v25, v20, v16
    13ec:      	add.2d	v31, v4, v16
    13f0:      	add.2d	v30, v3, v16
    13f4:      	add.2d	v19, v23, v16
    13f8:      	fmov	w13, s7
    13fc:      	movi.2d	v16, #0000000000000000
    1400:      	movi.2d	v17, #0000000000000000
    1404:      	tbz	w13, #0x0, 0x1464 <ltmp0+0x1464>
    1408:      	fmov	x14, d31
    140c:      	ldr	s16, [x14]
    1410:      	tbnz	w13, #0x1, 0x1468 <ltmp0+0x1468>
    1414:      	tbz	w13, #0x2, 0x1474 <ltmp0+0x1474>
    1418:      	fmov	x14, d25
    141c:      	ld1.s	{ v16 }[2], [x14]
    1420:      	str	q18, [sp, #0x400]
    1424:      	tbnz	w13, #0x3, 0x147c <ltmp0+0x147c>
    1428:      	ldr	q12, [sp, #0x320]
    142c:      	tbz	w13, #0x4, 0x148c <ltmp0+0x148c>
    1430:      	fmov	x14, d30
    1434:      	ld1.s	{ v17 }[0], [x14]
    1438:      	stp	q8, q13, [sp, #0x3d0]
    143c:      	str	q29, [sp, #0x3f0]
    1440:      	tbnz	w13, #0x5, 0x1498 <ltmp0+0x1498>
    1444:      	tbz	w13, #0x6, 0x14a4 <ltmp0+0x14a4>
    1448:      	fmov	x14, d19
    144c:      	ld1.s	{ v17 }[2], [x14]
    1450:      	ldr	q15, [sp, #0x310]
    1454:      	fmov	d1, d11
    1458:      	stp	q15, q12, [sp, #0x310]
    145c:      	tbnz	w13, #0x7, 0x14b4 <ltmp0+0x14b4>
    1460:      	b	0x14bc <ltmp0+0x14bc>
    1464:      	tbz	w13, #0x1, 0x1414 <ltmp0+0x1414>
    1468:      	mov.d	x14, v31[1]
    146c:      	ld1.s	{ v16 }[1], [x14]
    1470:      	tbnz	w13, #0x2, 0x1418 <ltmp0+0x1418>
    1474:      	str	q18, [sp, #0x400]
    1478:      	tbz	w13, #0x3, 0x1428 <ltmp0+0x1428>
    147c:      	mov.d	x14, v25[1]
    1480:      	ld1.s	{ v16 }[3], [x14]
    1484:      	ldr	q12, [sp, #0x320]
    1488:      	tbnz	w13, #0x4, 0x1430 <ltmp0+0x1430>
    148c:      	stp	q8, q13, [sp, #0x3d0]
    1490:      	str	q29, [sp, #0x3f0]
    1494:      	tbz	w13, #0x5, 0x1444 <ltmp0+0x1444>
    1498:      	mov.d	x14, v30[1]
    149c:      	ld1.s	{ v17 }[1], [x14]
    14a0:      	tbnz	w13, #0x6, 0x1448 <ltmp0+0x1448>
    14a4:      	ldr	q15, [sp, #0x310]
    14a8:      	fmov	d1, d11
    14ac:      	stp	q15, q12, [sp, #0x310]
    14b0:      	tbz	w13, #0x7, 0x14bc <ltmp0+0x14bc>
    14b4:      	mov.d	x13, v19[1]
    14b8:      	ld1.s	{ v17 }[3], [x13]
    14bc:      	fmul.4s	v17, v17, v17
    14c0:      	fmul.4s	v16, v16, v16
    14c4:      	fadd.4s	v6, v5, v16
    14c8:      	str	q6, [sp, #0x120]
    14cc:      	ldr	q16, [sp, #0x300]
    14d0:      	fadd.4s	v15, v16, v17
    14d4:      	mov	w9, #0x40               ; =64
    14d8:      	dup.2d	v16, x9
    14dc:      	add.2d	v31, v20, v16
    14e0:      	add.2d	v12, v4, v16
    14e4:      	add.2d	v25, v3, v16
    14e8:      	add.2d	v30, v23, v16
    14ec:      	fmov	w13, s7
    14f0:      	movi.2d	v16, #0000000000000000
    14f4:      	movi.2d	v17, #0000000000000000
    14f8:      	tbz	w13, #0x0, 0x153c <ltmp0+0x153c>
    14fc:      	fmov	x14, d12
    1500:      	ldr	s16, [x14]
    1504:      	tbnz	w13, #0x1, 0x1540 <ltmp0+0x1540>
    1508:      	tbz	w13, #0x2, 0x154c <ltmp0+0x154c>
    150c:      	fmov	x14, d31
    1510:      	ld1.s	{ v16 }[2], [x14]
    1514:      	tbnz	w13, #0x3, 0x1550 <ltmp0+0x1550>
    1518:      	tbz	w13, #0x4, 0x155c <ltmp0+0x155c>
    151c:      	fmov	x14, d25
    1520:      	ld1.s	{ v17 }[0], [x14]
    1524:      	tbnz	w13, #0x5, 0x1560 <ltmp0+0x1560>
    1528:      	tbz	w13, #0x6, 0x156c <ltmp0+0x156c>
    152c:      	fmov	x14, d30
    1530:      	ld1.s	{ v17 }[2], [x14]
    1534:      	tbnz	w13, #0x7, 0x1570 <ltmp0+0x1570>
    1538:      	b	0x1578 <ltmp0+0x1578>
    153c:      	tbz	w13, #0x1, 0x1508 <ltmp0+0x1508>
    1540:      	mov.d	x14, v12[1]
    1544:      	ld1.s	{ v16 }[1], [x14]
    1548:      	tbnz	w13, #0x2, 0x150c <ltmp0+0x150c>
    154c:      	tbz	w13, #0x3, 0x1518 <ltmp0+0x1518>
    1550:      	mov.d	x14, v31[1]
    1554:      	ld1.s	{ v16 }[3], [x14]
    1558:      	tbnz	w13, #0x4, 0x151c <ltmp0+0x151c>
    155c:      	tbz	w13, #0x5, 0x1528 <ltmp0+0x1528>
    1560:      	mov.d	x14, v25[1]
    1564:      	ld1.s	{ v17 }[1], [x14]
    1568:      	tbnz	w13, #0x6, 0x152c <ltmp0+0x152c>
    156c:      	tbz	w13, #0x7, 0x1578 <ltmp0+0x1578>
    1570:      	mov.d	x13, v30[1]
    1574:      	ld1.s	{ v17 }[3], [x13]
    1578:      	fmul.4s	v17, v17, v17
    157c:      	fmul.4s	v16, v16, v16
    1580:      	fadd.4s	v16, v22, v16
    1584:      	fadd.4s	v17, v24, v17
    1588:      	mov	w9, #0x60               ; =96
    158c:      	dup.2d	v12, x9
    1590:      	add.2d	v30, v20, v12
    1594:      	add.2d	v31, v4, v12
    1598:      	add.2d	v25, v3, v12
    159c:      	add.2d	v20, v23, v12
    15a0:      	fmov	w13, s7
    15a4:      	movi.2d	v3, #0000000000000000
    15a8:      	movi.2d	v4, #0000000000000000
    15ac:      	tbz	w13, #0x0, 0x15f0 <ltmp0+0x15f0>
    15b0:      	fmov	x14, d31
    15b4:      	ldr	s3, [x14]
    15b8:      	tbnz	w13, #0x1, 0x15f4 <ltmp0+0x15f4>
    15bc:      	ldr	q11, [sp, #0x3c0]
    15c0:      	ldr	q27, [sp, #0x160]
    15c4:      	fmov	d9, d1
    15c8:      	ldr	q19, [sp, #0x90]
    15cc:      	tbz	w13, #0x2, 0x1610 <ltmp0+0x1610>
    15d0:      	fmov	x14, d30
    15d4:      	ld1.s	{ v3 }[2], [x14]
    15d8:      	ldr	q13, [sp, #0x390]
    15dc:      	ldr	q1, [sp, #0x260]
    15e0:      	ldr	q10, [sp, #0xb0]
    15e4:      	mov.16b	v12, v0
    15e8:      	tbnz	w13, #0x3, 0x1624 <ltmp0+0x1624>
    15ec:      	b	0x162c <ltmp0+0x162c>
    15f0:      	tbz	w13, #0x1, 0x15bc <ltmp0+0x15bc>
    15f4:      	mov.d	x14, v31[1]
    15f8:      	ld1.s	{ v3 }[1], [x14]
    15fc:      	ldr	q11, [sp, #0x3c0]
    1600:      	ldr	q27, [sp, #0x160]
    1604:      	fmov	d9, d1
    1608:      	ldr	q19, [sp, #0x90]
    160c:      	tbnz	w13, #0x2, 0x15d0 <ltmp0+0x15d0>
    1610:      	ldr	q13, [sp, #0x390]
    1614:      	ldr	q1, [sp, #0x260]
    1618:      	ldr	q10, [sp, #0xb0]
    161c:      	mov.16b	v12, v0
    1620:      	tbz	w13, #0x3, 0x162c <ltmp0+0x162c>
    1624:      	mov.d	x14, v30[1]
    1628:      	ld1.s	{ v3 }[3], [x14]
    162c:      	ldr	q18, [sp, #0x270]
    1630:      	ldr	q28, [sp, #0xc0]
    1634:      	mov.16b	v23, v22
    1638:      	mov.16b	v26, v5
    163c:      	ldr	q5, [sp, #0x300]
    1640:      	ldr	q29, [sp, #0x330]
    1644:      	ldp	q31, q14, [sp, #0x3a0]
    1648:      	tbz	w13, #0x4, 0x1680 <ltmp0+0x1680>
    164c:      	fmov	x14, d25
    1650:      	ld1.s	{ v4 }[0], [x14]
    1654:      	ldr	q22, [sp, #0x1d0]
    1658:      	ldr	q8, [sp, #0x2f0]
    165c:      	ldr	q0, [sp, #0x380]
    1660:      	ldr	q6, [sp, #0x2c0]
    1664:      	tbnz	w13, #0x5, 0x1694 <ltmp0+0x1694>
    1668:      	ldr	q30, [sp, #0xd0]
    166c:      	tbz	w13, #0x6, 0x16a4 <ltmp0+0x16a4>
    1670:      	fmov	x14, d20
    1674:      	ld1.s	{ v4 }[2], [x14]
    1678:      	tbnz	w13, #0x7, 0x16a8 <ltmp0+0x16a8>
    167c:      	b	0x16b0 <ltmp0+0x16b0>
    1680:      	ldr	q22, [sp, #0x1d0]
    1684:      	ldr	q8, [sp, #0x2f0]
    1688:      	ldr	q0, [sp, #0x380]
    168c:      	ldr	q6, [sp, #0x2c0]
    1690:      	tbz	w13, #0x5, 0x1668 <ltmp0+0x1668>
    1694:      	mov.d	x14, v25[1]
    1698:      	ld1.s	{ v4 }[1], [x14]
    169c:      	ldr	q30, [sp, #0xd0]
    16a0:      	tbnz	w13, #0x6, 0x1670 <ltmp0+0x1670>
    16a4:      	tbz	w13, #0x7, 0x16b0 <ltmp0+0x16b0>
    16a8:      	mov.d	x13, v20[1]
    16ac:      	ld1.s	{ v4 }[3], [x13]
    16b0:      	fmul.4s	v4, v4, v4
    16b4:      	fmul.4s	v3, v3, v3
    16b8:      	fadd.4s	v3, v1, v3
    16bc:      	mov	w9, #0x4                ; =4
    16c0:      	dup.2d	v7, x9
    16c4:      	mov	b20, v21[6]
    16c8:      	mov.b	v20[4], v21[7]
    16cc:      	ushll.2d	v20, v20, #0x0
    16d0:      	shl.2d	v20, v20, #0x3f
    16d4:      	cmlt.2d	v20, v20, #0
    16d8:      	and.16b	v20, v20, v7
    16dc:      	add.2d	v13, v13, v20
    16e0:      	mov	b20, v21[4]
    16e4:      	mov.b	v20[4], v21[5]
    16e8:      	ushll.2d	v20, v20, #0x0
    16ec:      	shl.2d	v20, v20, #0x3f
    16f0:      	cmlt.2d	v20, v20, #0
    16f4:      	and.16b	v20, v20, v7
    16f8:      	add.2d	v14, v14, v20
    16fc:      	str	q14, [sp, #0x3b0]
    1700:      	mov	b20, v21[2]
    1704:      	mov.b	v20[4], v21[3]
    1708:      	fadd.4s	v4, v18, v4
    170c:      	ushll.2d	v20, v20, #0x0
    1710:      	shl.2d	v20, v20, #0x3f
    1714:      	cmlt.2d	v20, v20, #0
    1718:      	and.16b	v20, v20, v7
    171c:      	add.2d	v28, v28, v20
    1720:      	mov	b20, v21[0]
    1724:      	mov.b	v20[4], v21[1]
    1728:      	ushll.2d	v20, v20, #0x0
    172c:      	shl.2d	v20, v20, #0x3f
    1730:      	cmlt.2d	v20, v20, #0
    1734:      	and.16b	v7, v20, v7
    1738:      	add.2d	v30, v30, v7
    173c:      	zip1.8b	v7, v21, v0
    1740:      	ushll.4s	v7, v7, #0x0
    1744:      	shl.4s	v7, v7, #0x1f
    1748:      	cmlt.4s	v7, v7, #0
    174c:      	zip2.8b	v20, v21, v0
    1750:      	ushll.4s	v20, v20, #0x0
    1754:      	shl.4s	v20, v20, #0x1f
    1758:      	cmlt.4s	v20, v20, #0
    175c:      	ldr	q25, [sp, #0x130]
    1760:      	bit.16b	v31, v25, v20
    1764:      	ldr	q25, [sp, #0x250]
    1768:      	bit.16b	v29, v25, v7
    176c:      	str	q29, [sp, #0x330]
    1770:      	bit.16b	v5, v15, v20
    1774:      	str	q5, [sp, #0x300]
    1778:      	ldr	q5, [sp, #0x120]
    177c:      	bit.16b	v26, v5, v7
    1780:      	bit.16b	v24, v17, v20
    1784:      	stp	q26, q24, [sp, #0x230]
    1788:      	bit.16b	v23, v16, v7
    178c:      	bit.16b	v18, v4, v20
    1790:      	str	q18, [sp, #0x270]
    1794:      	bit.16b	v1, v3, v7
    1798:      	stp	q23, q1, [sp, #0x250]
    179c:      	str	q11, [sp, #0x3c0]
    17a0:      	stp	q13, q31, [sp, #0x390]
    17a4:      	movi.8b	v20, #0x1
    17a8:      	tbz	w11, #0x0, 0x17f8 <ltmp0+0x17f8>
    17ac:      	ldp	q23, q18, [sp, #0x2d0]
    17b0:      	ldr	q7, [sp, #0x1e0]
    17b4:      	ldp	q14, q26, [sp, #0x170]
    17b8:      	ldp	q15, q17, [sp, #0xe0]
    17bc:      	ldr	q25, [sp, #0xa0]
    17c0:      	mov.16b	v16, v12
    17c4:      	mov.16b	v12, v14
    17c8:      	mov.16b	v11, v27
    17cc:      	mov.16b	v1, v19
    17d0:      	mov.16b	v19, v17
    17d4:      	mov.16b	v24, v8
    17d8:      	mov.16b	v8, v7
    17dc:      	mov.16b	v13, v28
    17e0:      	mov.16b	v28, v6
    17e4:      	mov.16b	v14, v10
    17e8:      	mov.16b	v27, v0
    17ec:      	mov.16b	v31, v1
    17f0:      	mov.16b	v10, v16
    17f4:      	b	0x298 <ltmp0+0x298>
    17f8:      	ldp	q23, q18, [sp, #0x2d0]
    17fc:      	ldr	q7, [sp, #0x1e0]
    1800:      	ldp	q14, q26, [sp, #0x170]
    1804:      	ldp	q15, q17, [sp, #0xe0]
    1808:      	ldr	q25, [sp, #0xa0]
    180c:      	mov.16b	v16, v12
    1810:      	mov.16b	v12, v14
    1814:      	mov.16b	v11, v27
    1818:      	mov.16b	v1, v19
    181c:      	mov.16b	v19, v17
    1820:      	mov.16b	v24, v8
    1824:      	mov.16b	v8, v7
    1828:      	mov.16b	v13, v28
    182c:      	mov.16b	v28, v6
    1830:      	mov.16b	v14, v10
    1834:      	mov.16b	v27, v0
    1838:      	mov.16b	v31, v1
    183c:      	mov.16b	v10, v16
    1840:      	b	0xfac <ltmp0+0xfac>
    1844:      	tst	w13, #0xff
    1848:      	b.eq	0x298 <ltmp0+0x298>
    184c:      	cbz	w12, 0x1a24 <ltmp0+0x1a24>
    1850:      	mov	w13, #0x0               ; =0
    1854:      	shl.8b	v1, v21, #0x7
    1858:      	cmlt.8b	v1, v1, #0
    185c:      	and.8b	v3, v1, v2
    1860:      	addv.8b	b3, v3
    1864:      	fmov	w11, s3
    1868:      	umaxv.8b	b1, v1
    186c:      	fmov	w2, s1
    1870:      	sub	w14, w12, #0x1
    1874:      	tst	w11, #0xff
    1878:      	csel	w14, w14, wzr, ne
    187c:      	lsl	w17, w20, w14
    1880:      	and	w11, w17, w10
    1884:      	tst	w11, #0xff
    1888:      	cset	w4, ne
    188c:      	ldr	q1, [sp, #0x430]
    1890:      	str	q1, [sp, #0x10d0]
    1894:      	ldr	q1, [sp, #0x440]
    1898:      	str	q1, [sp, #0x10e0]
    189c:      	ubfiz	x11, x14, #2, #3
    18a0:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    18a4:      	add	x9, x9, #0xd0
    18a8:      	ldr	w1, [x9, x11]
    18ac:      	cmp	w1, #0x1
    18b0:      	cset	w1, eq
    18b4:      	and	w2, w4, w2
    18b8:      	ldrb	w4, [x27, w14, sxtw]
    18bc:      	and	w5, w4, #0x1
    18c0:      	fmov	s1, w5
    18c4:      	ubfx	w5, w4, #1, #1
    18c8:      	mov.b	v1[1], w5
    18cc:      	ubfx	w5, w4, #2, #1
    18d0:      	mov.b	v1[2], w5
    18d4:      	ubfx	w5, w4, #3, #1
    18d8:      	mov.b	v1[3], w5
    18dc:      	ubfx	w5, w4, #4, #1
    18e0:      	mov.b	v1[4], w5
    18e4:      	ubfx	w5, w4, #5, #1
    18e8:      	mov.b	v1[5], w5
    18ec:      	ubfx	w5, w4, #6, #1
    18f0:      	mov.b	v1[6], w5
    18f4:      	lsr	w4, w4, #7
    18f8:      	mov.b	v1[7], w4
    18fc:      	ldrb	w4, [x8, w14, sxtw]
    1900:      	and	w5, w4, #0x1
    1904:      	fmov	s3, w5
    1908:      	ubfx	w5, w4, #1, #1
    190c:      	mov.b	v3[1], w5
    1910:      	ubfx	w5, w4, #2, #1
    1914:      	mov.b	v3[2], w5
    1918:      	ubfx	w5, w4, #3, #1
    191c:      	mov.b	v3[3], w5
    1920:      	ubfx	w5, w4, #4, #1
    1924:      	mov.b	v3[4], w5
    1928:      	ubfx	w5, w4, #5, #1
    192c:      	mov.b	v3[5], w5
    1930:      	ubfx	w5, w4, #6, #1
    1934:      	mov.b	v3[6], w5
    1938:      	lsr	w4, w4, #7
    193c:      	mov.b	v3[7], w4
    1940:      	orr.8b	v4, v21, v3
    1944:      	and.8b	v6, v9, v1
    1948:      	eor.8b	v6, v6, v4
    194c:      	shl.8b	v6, v6, #0x7
    1950:      	cmlt.8b	v6, v6, #0
    1954:      	umaxv.8b	b6, v6
    1958:      	fmov	w4, s6
    195c:      	ands	w1, w2, w1
    1960:      	csetm	w2, ne
    1964:      	bics	w4, w1, w4
    1968:      	csetm	w5, ne
    196c:      	dup.8b	v6, w5
    1970:      	mov	w5, #-0x1               ; =-1
    1974:      	dup.8b	v7, w2
    1978:      	bic.8b	v16, v4, v6
    197c:      	bit.8b	v3, v16, v7
    1980:      	shl.8b	v3, v3, #0x7
    1984:      	cmlt.8b	v3, v3, #0
    1988:      	and.8b	v3, v3, v2
    198c:      	addv.8b	b3, v3
    1990:      	str	b3, [x8, w14, sxtw]
    1994:      	bic.8b	v1, v1, v6
    1998:      	shl.8b	v1, v1, #0x7
    199c:      	cmlt.8b	v1, v1, #0
    19a0:      	and.8b	v1, v1, v2
    19a4:      	addv.8b	b1, v1
    19a8:      	str	b1, [x27, w14, sxtw]
    19ac:      	csinv	w14, w5, w17, eq
    19b0:      	dup.8b	v1, w1
    19b4:      	and	w10, w14, w10
    19b8:      	shl.8b	v1, v1, #0x7
    19bc:      	cmlt.8b	v1, v1, #0
    19c0:      	dup.8b	v3, w4
    19c4:      	and.8b	v3, v3, v4
    19c8:      	ldr	q4, [sp, #0x410]
    19cc:      	str	q4, [sp, #0x10b0]
    19d0:      	ldr	q4, [sp, #0x420]
    19d4:      	str	q4, [sp, #0x10c0]
    19d8:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    19dc:      	add	x9, x9, #0xb0
    19e0:      	ldr	w11, [x9, x11]
    19e4:      	csel	w12, w11, w12, ne
    19e8:      	bit.8b	v21, v3, v1
    19ec:      	shl.8b	v1, v21, #0x7
    19f0:      	cmlt.8b	v1, v1, #0
    19f4:      	and.8b	v1, v1, v2
    19f8:      	addv.8b	b1, v1
    19fc:      	fmov	w11, s1
    1a00:      	cmp	w1, #0x1
    1a04:      	b.ne	0x1a38 <ltmp0+0x1a38>
    1a08:      	cmp	w12, #0x0
    1a0c:      	ccmp	w13, #0x6, #0x2, ne
    1a10:      	b.hi	0x1a38 <ltmp0+0x1a38>
    1a14:      	add	w13, w13, #0x1
    1a18:      	tst	w11, #0xff
    1a1c:      	b.ne	0x1854 <ltmp0+0x1854>
    1a20:      	b	0x1a38 <ltmp0+0x1a38>
    1a24:      	shl.8b	v1, v21, #0x7
    1a28:      	cmlt.8b	v1, v1, #0
    1a2c:      	and.8b	v1, v1, v2
    1a30:      	addv.8b	b1, v1
    1a34:      	fmov	w11, s1
    1a38:      	tst	w11, #0xff
    1a3c:      	b.eq	0xfa4 <ltmp0+0xfa4>
    1a40:      	and.8b	v1, v11, v21
    1a44:      	shl.8b	v1, v1, #0x7
    1a48:      	cmlt.8b	v1, v1, #0
    1a4c:      	and.8b	v3, v1, v2
    1a50:      	addv.8b	b4, v3
    1a54:      	umaxv.8b	b1, v1
    1a58:      	fmov	w13, s1
    1a5c:      	add	x4, sp, #0xdc0
    1a60:      	tbz	w13, #0x0, 0x1cac <ltmp0+0x1cac>
    1a64:      	bic.8b	v3, v21, v11
    1a68:      	shl.8b	v1, v3, #0x7
    1a6c:      	cmlt.8b	v1, v1, #0
    1a70:      	and.8b	v1, v1, v2
    1a74:      	addv.8b	b1, v1
    1a78:      	fmov	w13, s1
    1a7c:      	tst	w13, #0xff
    1a80:      	b.eq	0x1cac <ltmp0+0x1cac>
    1a84:      	subs	w11, w12, #0x1
    1a88:      	csel	w11, wzr, w11, lo
    1a8c:      	and	w13, w10, #0xff
    1a90:      	lsr	w14, w13, w11
    1a94:      	tst	w14, #0x1
    1a98:      	ldr	q5, [sp, #0x430]
    1a9c:      	str	q5, [sp, #0x710]
    1aa0:      	ldr	q5, [sp, #0x440]
    1aa4:      	str	q5, [sp, #0x720]
    1aa8:      	and	x11, x11, #0x7
    1aac:      	add	x9, sp, #0x710
    1ab0:      	ldr	w11, [x9, x11, lsl #2]
    1ab4:      	ccmp	w12, #0x0, #0x4, ne
    1ab8:      	ccmp	w11, #0x2, #0x0, ne
    1abc:      	cset	w11, ne
    1ac0:      	cmp	w13, #0xff
    1ac4:      	b.ne	0x1acc <ltmp0+0x1acc>
    1ac8:      	tbnz	w11, #0x0, 0x5410 <ltmp0+0x5410>
    1acc:      	mvn	w13, w10
    1ad0:      	rbit	w13, w13
    1ad4:      	clz	w13, w13
    1ad8:      	mov	w9, #0xff               ; =255
    1adc:      	bics	wzr, w9, w10
    1ae0:      	csel	w13, wzr, w13, eq
    1ae4:      	ubfiz	x14, x13, #2, #3
    1ae8:      	lsl	w17, w20, w13
    1aec:      	ldr	q6, [sp, #0x430]
    1af0:      	str	q6, [sp, #0x6f0]
    1af4:      	ldr	q5, [sp, #0x440]
    1af8:      	str	q5, [sp, #0x700]
    1afc:      	add	x9, sp, #0x6f0
    1b00:      	ldr	w1, [x9, x14]
    1b04:      	cmp	w11, #0x0
    1b08:      	csel	w11, w17, wzr, ne
    1b0c:      	mov	w9, #0x2                ; =2
    1b10:      	csel	w17, w9, w1, ne
    1b14:      	str	q6, [sp, #0x6d0]
    1b18:      	str	q5, [sp, #0x6e0]
    1b1c:      	add	x9, sp, #0x6d0
    1b20:      	str	w17, [x9, x14]
    1b24:      	ldr	q5, [sp, #0x6e0]
    1b28:      	str	q5, [sp, #0x440]
    1b2c:      	ldr	q5, [sp, #0x6d0]
    1b30:      	str	q5, [sp, #0x430]
    1b34:      	ldr	q6, [sp, #0x410]
    1b38:      	str	q6, [sp, #0x6b0]
    1b3c:      	ldr	q5, [sp, #0x420]
    1b40:      	str	q5, [sp, #0x6c0]
    1b44:      	add	x9, sp, #0x6b0
    1b48:      	ldr	w17, [x9, x14]
    1b4c:      	csel	w17, w12, w17, ne
    1b50:      	str	q6, [sp, #0x690]
    1b54:      	str	q5, [sp, #0x6a0]
    1b58:      	add	x9, sp, #0x690
    1b5c:      	str	w17, [x9, x14]
    1b60:      	ldrb	w14, [x27, x13]
    1b64:      	and	w17, w14, #0x1
    1b68:      	fmov	s6, w17
    1b6c:      	ubfx	w17, w14, #1, #1
    1b70:      	mov.b	v6[1], w17
    1b74:      	ubfx	w17, w14, #2, #1
    1b78:      	mov.b	v6[2], w17
    1b7c:      	ubfx	w17, w14, #3, #1
    1b80:      	mov.b	v6[3], w17
    1b84:      	ubfx	w17, w14, #4, #1
    1b88:      	mov.b	v6[4], w17
    1b8c:      	ubfx	w17, w14, #5, #1
    1b90:      	mov.b	v6[5], w17
    1b94:      	ubfx	w17, w14, #6, #1
    1b98:      	mov.b	v6[6], w17
    1b9c:      	ldr	q5, [sp, #0x6a0]
    1ba0:      	str	q5, [sp, #0x420]
    1ba4:      	ldr	q5, [sp, #0x690]
    1ba8:      	str	q5, [sp, #0x410]
    1bac:      	lsr	w14, w14, #7
    1bb0:      	mov.b	v6[7], w14
    1bb4:      	ldrb	w14, [x8, x13]
    1bb8:      	and	w17, w14, #0x1
    1bbc:      	fmov	s7, w17
    1bc0:      	ubfx	w17, w14, #1, #1
    1bc4:      	mov.b	v7[1], w17
    1bc8:      	ubfx	w17, w14, #2, #1
    1bcc:      	mov.b	v7[2], w17
    1bd0:      	ubfx	w17, w14, #3, #1
    1bd4:      	mov.b	v7[3], w17
    1bd8:      	ubfx	w17, w14, #4, #1
    1bdc:      	mov.b	v7[4], w17
    1be0:      	ubfx	w17, w14, #5, #1
    1be4:      	mov.b	v7[5], w17
    1be8:      	ubfx	w17, w14, #6, #1
    1bec:      	mov.b	v7[6], w17
    1bf0:      	lsr	w14, w14, #7
    1bf4:      	mov.b	v7[7], w14
    1bf8:      	csetm	w14, ne
    1bfc:      	dup.8b	v16, w14
    1c00:      	bit.8b	v6, v21, v16
    1c04:      	shl.8b	v6, v6, #0x7
    1c08:      	cmlt.8b	v6, v6, #0
    1c0c:      	and.8b	v6, v6, v2
    1c10:      	addv.8b	b6, v6
    1c14:      	str	b6, [x27, x13]
    1c18:      	bic.8b	v6, v7, v16
    1c1c:      	shl.8b	v6, v6, #0x7
    1c20:      	cmlt.8b	v6, v6, #0
    1c24:      	and.8b	v6, v6, v2
    1c28:      	addv.8b	b6, v6
    1c2c:      	str	b6, [x8, x13]
    1c30:      	csinc	w12, w12, w13, eq
    1c34:      	cmp	w26, #0x8
    1c38:      	b.hs	0x5410 <ltmp0+0x5410>
    1c3c:      	str	b4, [x21, x28]
    1c40:      	mov	w9, #0x9                ; =9
    1c44:      	str	w9, [x22, x28, lsl #2]
    1c48:      	str	w12, [x23, x28, lsl #2]
    1c4c:      	cmp	w19, #0x8
    1c50:      	b.hs	0x5410 <ltmp0+0x5410>
    1c54:      	orr	w10, w11, w10
    1c58:      	zip2.8b	v4, v3, v0
    1c5c:      	ushll.4s	v4, v4, #0x0
    1c60:      	shl.4s	v4, v4, #0x1f
    1c64:      	cmlt.4s	v4, v4, #0
    1c68:      	ldr	q5, [sp, #0x150]
    1c6c:      	ldr	q0, [sp, #0x3a0]
    1c70:      	bit.16b	v5, v0, v4
    1c74:      	zip1.8b	v3, v3, v0
    1c78:      	ushll.4s	v3, v3, #0x0
    1c7c:      	shl.4s	v3, v3, #0x1f
    1c80:      	cmlt.4s	v3, v3, #0
    1c84:      	str	b1, [x21, w19, uxtw]
    1c88:      	ldr	q1, [sp, #0x140]
    1c8c:      	ldr	q4, [sp, #0x330]
    1c90:      	bit.16b	v1, v4, v3
    1c94:      	stp	q1, q5, [sp, #0x140]
    1c98:      	mov	w9, #0xa                ; =10
    1c9c:      	str	w9, [x22, w19, uxtw #2]
    1ca0:      	str	w12, [x23, w19, uxtw #2]
    1ca4:      	add	w26, w19, #0x1
    1ca8:      	b	0x298 <ltmp0+0x298>
    1cac:      	fmov	w13, s4
    1cb0:      	tst	w13, #0xff
    1cb4:      	b.eq	0x1f40 <ltmp0+0x1f40>
    1cb8:      	rbit	w13, w11
    1cbc:      	clz	w13, w13
    1cc0:      	tst	w11, #0xff
    1cc4:      	csel	w13, wzr, w13, eq
    1cc8:      	ldp	q1, q0, [sp, #0x360]
    1ccc:      	str	q0, [sp, #0x1070]
    1cd0:      	str	q1, [sp, #0x1080]
    1cd4:      	ldp	q1, q0, [sp, #0x340]
    1cd8:      	str	q0, [sp, #0x1090]
    1cdc:      	str	q1, [sp, #0x10a0]
    1ce0:      	and	x14, x13, #0x7
    1ce4:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    1ce8:      	add	x9, x9, #0x70
    1cec:      	ldr	x14, [x9, x14, lsl #3]
    1cf0:      	lsl	w13, w13, #2
    1cf4:      	sub	x13, x14, x13
    1cf8:      	ands	w11, w11, #0xff
    1cfc:      	add	x13, x13, #0x4, lsl #12 ; =0x4000
    1d00:      	csel	x13, xzr, x13, eq
    1d04:      	add	x13, x15, x13
    1d08:      	ldp	q3, q1, [x13]
    1d0c:      	zip1.8b	v4, v21, v0
    1d10:      	ushll.4s	v4, v4, #0x0
    1d14:      	shl.4s	v4, v4, #0x1f
    1d18:      	cmlt.4s	v4, v4, #0
    1d1c:      	and.16b	v3, v4, v3
    1d20:      	zip2.8b	v6, v21, v0
    1d24:      	ushll.4s	v6, v6, #0x0
    1d28:      	shl.4s	v6, v6, #0x1f
    1d2c:      	cmlt.4s	v6, v6, #0
    1d30:      	and.16b	v1, v6, v1
    1d34:      	fmul.4s	v1, v1, v1
    1d38:      	fmul.4s	v3, v3, v3
    1d3c:      	ldr	q5, [sp, #0x330]
    1d40:      	fadd.4s	v3, v5, v3
    1d44:      	ldr	q0, [sp, #0x3a0]
    1d48:      	fadd.4s	v1, v0, v1
    1d4c:      	ldr	q5, [sp, #0x150]
    1d50:      	bit.16b	v5, v1, v6
    1d54:      	ldr	q1, [sp, #0x140]
    1d58:      	bit.16b	v1, v3, v4
    1d5c:      	stp	q1, q5, [sp, #0x140]
    1d60:      	cbz	w11, 0x298 <ltmp0+0x298>
    1d64:      	str	x28, [sp, #0x88]
    1d68:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    1d6c:      	add	x16, x16, #0x50
    1d70:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    1d74:      	add	x0, x0, #0x30
    1d78:      	cbz	w12, 0x1f98 <ltmp0+0x1f98>
    1d7c:      	mov	w13, #0x0               ; =0
    1d80:      	shl.8b	v1, v21, #0x7
    1d84:      	cmlt.8b	v1, v1, #0
    1d88:      	and.8b	v3, v1, v2
    1d8c:      	addv.8b	b3, v3
    1d90:      	fmov	w11, s3
    1d94:      	umaxv.8b	b1, v1
    1d98:      	fmov	w2, s1
    1d9c:      	sub	w14, w12, #0x1
    1da0:      	tst	w11, #0xff
    1da4:      	csel	w14, w14, wzr, ne
    1da8:      	lsl	w17, w20, w14
    1dac:      	and	w11, w17, w10
    1db0:      	tst	w11, #0xff
    1db4:      	cset	w4, ne
    1db8:      	ldr	q1, [sp, #0x430]
    1dbc:      	str	q1, [sp, #0x1050]
    1dc0:      	ldr	q1, [sp, #0x440]
    1dc4:      	str	q1, [sp, #0x1060]
    1dc8:      	ubfiz	x11, x14, #2, #3
    1dcc:      	ldr	w1, [x16, x11]
    1dd0:      	cmp	w1, #0x2
    1dd4:      	cset	w1, eq
    1dd8:      	and	w2, w4, w2
    1ddc:      	ldrb	w4, [x27, w14, sxtw]
    1de0:      	and	w5, w4, #0x1
    1de4:      	fmov	s1, w5
    1de8:      	ubfx	w5, w4, #1, #1
    1dec:      	mov.b	v1[1], w5
    1df0:      	ubfx	w5, w4, #2, #1
    1df4:      	mov.b	v1[2], w5
    1df8:      	ubfx	w5, w4, #3, #1
    1dfc:      	mov.b	v1[3], w5
    1e00:      	ubfx	w5, w4, #4, #1
    1e04:      	mov.b	v1[4], w5
    1e08:      	ubfx	w5, w4, #5, #1
    1e0c:      	mov.b	v1[5], w5
    1e10:      	ubfx	w5, w4, #6, #1
    1e14:      	mov.b	v1[6], w5
    1e18:      	lsr	w4, w4, #7
    1e1c:      	mov.b	v1[7], w4
    1e20:      	ldrb	w4, [x8, w14, sxtw]
    1e24:      	and	w5, w4, #0x1
    1e28:      	fmov	s3, w5
    1e2c:      	ubfx	w5, w4, #1, #1
    1e30:      	mov.b	v3[1], w5
    1e34:      	ubfx	w5, w4, #2, #1
    1e38:      	mov.b	v3[2], w5
    1e3c:      	ubfx	w5, w4, #3, #1
    1e40:      	mov.b	v3[3], w5
    1e44:      	ubfx	w5, w4, #4, #1
    1e48:      	mov.b	v3[4], w5
    1e4c:      	ubfx	w5, w4, #5, #1
    1e50:      	mov.b	v3[5], w5
    1e54:      	ubfx	w5, w4, #6, #1
    1e58:      	mov.b	v3[6], w5
    1e5c:      	lsr	w4, w4, #7
    1e60:      	mov.b	v3[7], w4
    1e64:      	orr.8b	v4, v21, v3
    1e68:      	and.8b	v6, v9, v1
    1e6c:      	eor.8b	v6, v6, v4
    1e70:      	shl.8b	v6, v6, #0x7
    1e74:      	cmlt.8b	v6, v6, #0
    1e78:      	umaxv.8b	b6, v6
    1e7c:      	fmov	w4, s6
    1e80:      	ands	w1, w2, w1
    1e84:      	csetm	w2, ne
    1e88:      	bics	w4, w1, w4
    1e8c:      	csetm	w5, ne
    1e90:      	dup.8b	v6, w5
    1e94:      	dup.8b	v7, w2
    1e98:      	bic.8b	v16, v4, v6
    1e9c:      	bit.8b	v3, v16, v7
    1ea0:      	shl.8b	v3, v3, #0x7
    1ea4:      	cmlt.8b	v3, v3, #0
    1ea8:      	and.8b	v3, v3, v2
    1eac:      	addv.8b	b3, v3
    1eb0:      	str	b3, [x8, w14, sxtw]
    1eb4:      	bic.8b	v1, v1, v6
    1eb8:      	shl.8b	v1, v1, #0x7
    1ebc:      	cmlt.8b	v1, v1, #0
    1ec0:      	and.8b	v1, v1, v2
    1ec4:      	addv.8b	b1, v1
    1ec8:      	str	b1, [x27, w14, sxtw]
    1ecc:      	mov	w9, #-0x1               ; =-1
    1ed0:      	csinv	w14, w9, w17, eq
    1ed4:      	dup.8b	v1, w1
    1ed8:      	and	w10, w14, w10
    1edc:      	shl.8b	v1, v1, #0x7
    1ee0:      	cmlt.8b	v1, v1, #0
    1ee4:      	dup.8b	v3, w4
    1ee8:      	and.8b	v3, v3, v4
    1eec:      	ldr	q4, [sp, #0x410]
    1ef0:      	str	q4, [sp, #0x1030]
    1ef4:      	ldr	q4, [sp, #0x420]
    1ef8:      	str	q4, [sp, #0x1040]
    1efc:      	ldr	w11, [x0, x11]
    1f00:      	csel	w12, w11, w12, ne
    1f04:      	bit.8b	v21, v3, v1
    1f08:      	shl.8b	v1, v21, #0x7
    1f0c:      	cmlt.8b	v1, v1, #0
    1f10:      	and.8b	v1, v1, v2
    1f14:      	addv.8b	b1, v1
    1f18:      	fmov	w11, s1
    1f1c:      	cmp	w1, #0x1
    1f20:      	b.ne	0x1fac <ltmp0+0x1fac>
    1f24:      	cmp	w12, #0x0
    1f28:      	ccmp	w13, #0x6, #0x2, ne
    1f2c:      	b.hi	0x1fac <ltmp0+0x1fac>
    1f30:      	add	w13, w13, #0x1
    1f34:      	tst	w11, #0xff
    1f38:      	b.ne	0x1d80 <ltmp0+0x1d80>
    1f3c:      	b	0x1fac <ltmp0+0x1fac>
    1f40:      	zip2.8b	v1, v21, v0
    1f44:      	ushll.4s	v1, v1, #0x0
    1f48:      	shl.4s	v1, v1, #0x1f
    1f4c:      	cmlt.4s	v1, v1, #0
    1f50:      	ldr	q3, [sp, #0x150]
    1f54:      	ldr	q0, [sp, #0x3a0]
    1f58:      	bit.16b	v3, v0, v1
    1f5c:      	str	q3, [sp, #0x150]
    1f60:      	zip1.8b	v1, v21, v0
    1f64:      	ushll.4s	v1, v1, #0x0
    1f68:      	shl.4s	v1, v1, #0x1f
    1f6c:      	cmlt.4s	v1, v1, #0
    1f70:      	ldr	q3, [sp, #0x140]
    1f74:      	ldr	q4, [sp, #0x330]
    1f78:      	bit.16b	v3, v4, v1
    1f7c:      	str	q3, [sp, #0x140]
    1f80:      	str	x28, [sp, #0x88]
    1f84:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    1f88:      	add	x16, x16, #0x50
    1f8c:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    1f90:      	add	x0, x0, #0x30
    1f94:      	cbnz	w12, 0x1d7c <ltmp0+0x1d7c>
    1f98:      	shl.8b	v1, v21, #0x7
    1f9c:      	cmlt.8b	v1, v1, #0
    1fa0:      	and.8b	v1, v1, v2
    1fa4:      	addv.8b	b1, v1
    1fa8:      	fmov	w11, s1
    1fac:      	tst	w11, #0xff
    1fb0:      	b.eq	0x2744 <ltmp0+0x2744>
    1fb4:      	ldr	q1, [sp, #0x150]
    1fb8:      	ldr	q3, [sp, #0x300]
    1fbc:      	fadd.4s	v1, v3, v1
    1fc0:      	ldr	q3, [sp, #0x140]
    1fc4:      	ldr	q4, [sp, #0x230]
    1fc8:      	fadd.4s	v3, v4, v3
    1fcc:      	ldp	q4, q0, [sp, #0x240]
    1fd0:      	fadd.4s	v3, v0, v3
    1fd4:      	fadd.4s	v1, v4, v1
    1fd8:      	ldr	q4, [sp, #0x270]
    1fdc:      	fadd.4s	v6, v4, v1
    1fe0:      	ldr	q1, [sp, #0x260]
    1fe4:      	fadd.4s	v7, v1, v3
    1fe8:      	mov.16b	v29, v24
    1fec:      	mov.16b	v24, v31
    1ff0:      	uzp1.4s	v31, v22, v29
    1ff4:      	uzp1.4s	v0, v27, v28
    1ff8:      	movi.4s	v4, #0x1
    1ffc:      	eor.16b	v3, v31, v4
    2000:      	mov.s	w13, v3[1]
    2004:      	eor.16b	v4, v0, v4
    2008:      	mov.s	w17, v3[2]
    200c:      	mov.s	w2, v3[3]
    2010:      	fmov	w14, s3
    2014:      	cmp	w14, #0x8
    2018:      	csel	w14, w14, wzr, lo
    201c:      	cset	w4, lo
    2020:      	and	x5, x14, #0x7
    2024:      	add	x1, sp, #0xde8
    2028:      	bfxil	x1, x14, #0, #3
    202c:      	str	d21, [sp, #0xde8]
    2030:      	ldrb	w14, [x1]
    2034:      	umov.b	w15, v21[0]
    2038:      	str	w15, [sp, #0x2f0]
    203c:      	and	w14, w4, w14
    2040:      	str	q7, [sp, #0xf90]
    2044:      	str	q6, [sp, #0xfa0]
    2048:      	add	x9, sp, #0xf90
    204c:      	ldr	s3, [x9, x5, lsl #2]
    2050:      	ands	w23, w15, #0x1
    2054:      	tst	w23, w14
    2058:      	str	q23, [sp, #0x2d0]
    205c:      	movi	d23, #0000000000000000
    2060:      	fcsel	s3, s3, s23, ne
    2064:      	cmp	w13, #0x8
    2068:      	csel	w13, w13, wzr, lo
    206c:      	cset	w4, lo
    2070:      	and	x5, x13, #0x7
    2074:      	add	x14, sp, #0xde8
    2078:      	bfxil	x14, x13, #0, #3
    207c:      	ldrb	w13, [x14]
    2080:      	umov.b	w14, v21[1]
    2084:      	str	w14, [sp, #0x1e0]
    2088:      	and	w13, w4, w13
    208c:      	str	q7, [sp, #0xf70]
    2090:      	str	q6, [sp, #0xf80]
    2094:      	add	x9, sp, #0xf70
    2098:      	ldr	s16, [x9, x5, lsl #2]
    209c:      	mov	x15, x3
    20a0:      	mov	x3, x7
    20a4:      	ands	w7, w14, #0x1
    20a8:      	tst	w7, w13
    20ac:      	fcsel	s17, s16, s23, ne
    20b0:      	cmp	w17, #0x8
    20b4:      	csel	w13, w17, wzr, lo
    20b8:      	cset	w17, lo
    20bc:      	and	x4, x13, #0x7
    20c0:      	add	x5, sp, #0xde8
    20c4:      	bfxil	x5, x13, #0, #3
    20c8:      	ldrb	w13, [x5]
    20cc:      	umov.b	w5, v21[2]
    20d0:      	str	q7, [sp, #0xf50]
    20d4:      	str	q6, [sp, #0xf60]
    20d8:      	add	x9, sp, #0xf50
    20dc:      	ldr	s16, [x9, x4, lsl #2]
    20e0:      	and	w13, w17, w13
    20e4:      	mov	x14, x6
    20e8:      	ands	w6, w5, #0x1
    20ec:      	tst	w6, w13
    20f0:      	fcsel	s16, s16, s23, ne
    20f4:      	cmp	w2, #0x8
    20f8:      	csel	w17, w2, wzr, lo
    20fc:      	cset	w13, lo
    2100:      	and	x4, x17, #0x7
    2104:      	add	x2, sp, #0xde8
    2108:      	bfxil	x2, x17, #0, #3
    210c:      	umov.b	w1, v21[3]
    2110:      	ldrb	w20, [x2]
    2114:      	mov.s	w2, v4[1]
    2118:      	mov.s	w17, v4[2]
    211c:      	str	q7, [sp, #0xf30]
    2120:      	str	q6, [sp, #0xf40]
    2124:      	mov.s	w24, v4[3]
    2128:      	fmov	w21, s4
    212c:      	add	x9, sp, #0xf30
    2130:      	ldr	s4, [x9, x4, lsl #2]
    2134:      	and	w13, w13, w20
    2138:      	ands	w4, w1, #0x1
    213c:      	tst	w4, w13
    2140:      	str	q11, [sp, #0x160]
    2144:      	fcsel	s20, s4, s23, ne
    2148:      	cmp	w21, #0x8
    214c:      	csel	w13, w21, wzr, lo
    2150:      	cset	w20, lo
    2154:      	and	x21, x13, #0x7
    2158:      	add	x22, sp, #0xde8
    215c:      	bfxil	x22, x13, #0, #3
    2160:      	umov.b	w30, v21[4]
    2164:      	ldrb	w13, [x22]
    2168:      	and	w20, w20, w13
    216c:      	str	q7, [sp, #0x1010]
    2170:      	str	q6, [sp, #0x1020]
    2174:      	mov.s	v3[1], v17[0]
    2178:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    217c:      	add	x9, x9, #0x10
    2180:      	ldr	s4, [x9, x21, lsl #2]
    2184:      	ands	w13, w30, #0x1
    2188:      	tst	w13, w20
    218c:      	fcsel	s4, s4, s23, ne
    2190:      	cmp	w2, #0x8
    2194:      	csel	w2, w2, wzr, lo
    2198:      	cset	w20, lo
    219c:      	and	x21, x2, #0x7
    21a0:      	add	x22, sp, #0xde8
    21a4:      	bfxil	x22, x2, #0, #3
    21a8:      	ldrb	w2, [x22]
    21ac:      	umov.b	w22, v21[5]
    21b0:      	and	w2, w20, w2
    21b4:      	mov.s	v3[2], v16[0]
    21b8:      	str	q7, [sp, #0xff0]
    21bc:      	str	q6, [sp, #0x1000]
    21c0:      	add	x9, sp, #0xff0
    21c4:      	ldr	s16, [x9, x21, lsl #2]
    21c8:      	ands	w21, w22, #0x1
    21cc:      	tst	w21, w2
    21d0:      	fcsel	s16, s16, s23, ne
    21d4:      	cmp	w17, #0x8
    21d8:      	csel	w17, w17, wzr, lo
    21dc:      	cset	w2, lo
    21e0:      	mov	x28, x25
    21e4:      	and	x25, x17, #0x7
    21e8:      	add	x20, sp, #0xde8
    21ec:      	bfxil	x20, x17, #0, #3
    21f0:      	ldrb	w17, [x20]
    21f4:      	umov.b	w20, v21[6]
    21f8:      	and	w17, w2, w17
    21fc:      	str	q7, [sp, #0xfd0]
    2200:      	str	q6, [sp, #0xfe0]
    2204:      	mov.s	v3[3], v20[0]
    2208:      	add	x9, sp, #0xfd0
    220c:      	ldr	s17, [x9, x25, lsl #2]
    2210:      	ands	w2, w20, #0x1
    2214:      	tst	w2, w17
    2218:      	fcsel	s17, s17, s23, ne
    221c:      	cmp	w24, #0x8
    2220:      	csel	w17, w24, wzr, lo
    2224:      	cset	w24, lo
    2228:      	and	x25, x17, #0x7
    222c:      	add	x16, sp, #0xde8
    2230:      	bfxil	x16, x17, #0, #3
    2234:      	ldrb	w16, [x16]
    2238:      	umov.b	w17, v21[7]
    223c:      	and	w16, w24, w16
    2240:      	str	q7, [sp, #0xfb0]
    2244:      	str	q6, [sp, #0xfc0]
    2248:      	mov.s	v4[1], v16[0]
    224c:      	add	x9, sp, #0xfb0
    2250:      	ldr	s16, [x9, x25, lsl #2]
    2254:      	ands	w24, w17, #0x1
    2258:      	tst	w24, w16
    225c:      	fcsel	s20, s16, s23, ne
    2260:      	str	q28, [sp, #0x2c0]
    2264:      	str	q27, [sp, #0x380]
    2268:      	mov.16b	v16, v15
    226c:      	mov.16b	v28, v22
    2270:      	stp	q12, q26, [sp, #0x170]
    2274:      	str	q18, [sp, #0x2e0]
    2278:      	mov.16b	v22, v14
    227c:      	ldr	q15, [sp, #0x1f0]
    2280:      	mov.16b	v18, v19
    2284:      	mov.16b	v5, v13
    2288:      	mov.16b	v1, v8
    228c:      	mov.16b	v13, v16
    2290:      	movi.4s	v19, #0x2
    2294:      	eor.16b	v16, v31, v19
    2298:      	mov.s	w16, v16[1]
    229c:      	fmov	w25, s16
    22a0:      	cmp	w25, #0x8
    22a4:      	csel	w25, w25, wzr, lo
    22a8:      	cset	w0, lo
    22ac:      	add	x9, sp, #0xde8
    22b0:      	bfxil	x9, x25, #0, #3
    22b4:      	ldrb	w9, [x9]
    22b8:      	and	w9, w0, w9
    22bc:      	mov.s	v4[2], v17[0]
    22c0:      	mov.s	v4[3], v20[0]
    22c4:      	fadd.4s	v4, v6, v4
    22c8:      	fadd.4s	v3, v7, v3
    22cc:      	and	x0, x25, #0x7
    22d0:      	mov	x25, x28
    22d4:      	str	q3, [sp, #0xf10]
    22d8:      	str	q4, [sp, #0xf20]
    22dc:      	add	x28, sp, #0xf10
    22e0:      	ldr	s6, [x28, x0, lsl #2]
    22e4:      	tst	w23, w9
    22e8:      	fcsel	s6, s6, s23, ne
    22ec:      	cmp	w16, #0x8
    22f0:      	csel	w9, w16, wzr, lo
    22f4:      	cset	w16, lo
    22f8:      	add	x0, sp, #0xde8
    22fc:      	bfxil	x0, x9, #0, #3
    2300:      	ldrb	w0, [x0]
    2304:      	and	w16, w16, w0
    2308:      	and	x9, x9, #0x7
    230c:      	str	q3, [sp, #0xef0]
    2310:      	str	q4, [sp, #0xf00]
    2314:      	add	x0, sp, #0xef0
    2318:      	ldr	s7, [x0, x9, lsl #2]
    231c:      	mov.s	w9, v16[2]
    2320:      	tst	w7, w16
    2324:      	mov	x7, x3
    2328:      	mov	x3, x15
    232c:      	add	x15, sp, #0x5, lsl #12  ; =0x5000
    2330:      	add	x15, x15, #0x298
    2334:      	fcsel	s7, s7, s23, ne
    2338:      	cmp	w9, #0x8
    233c:      	csel	w9, w9, wzr, lo
    2340:      	cset	w16, lo
    2344:      	add	x0, sp, #0xde8
    2348:      	bfxil	x0, x9, #0, #3
    234c:      	ldrb	w0, [x0]
    2350:      	and	w16, w16, w0
    2354:      	and	x9, x9, #0x7
    2358:      	str	q3, [sp, #0xed0]
    235c:      	str	q4, [sp, #0xee0]
    2360:      	add	x0, sp, #0xed0
    2364:      	ldr	s17, [x0, x9, lsl #2]
    2368:      	mov.s	w9, v16[3]
    236c:      	tst	w6, w16
    2370:      	mov	x6, x14
    2374:      	fcsel	s16, s17, s23, ne
    2378:      	cmp	w9, #0x8
    237c:      	csel	w9, w9, wzr, lo
    2380:      	cset	w16, lo
    2384:      	add	x0, sp, #0xde8
    2388:      	bfxil	x0, x9, #0, #3
    238c:      	ldrb	w0, [x0]
    2390:      	and	w16, w16, w0
    2394:      	eor.16b	v19, v0, v19
    2398:      	mov.16b	v17, v13
    239c:      	ldr	q8, [sp, #0x3e0]
    23a0:      	mov.16b	v13, v5
    23a4:      	mov.16b	v11, v24
    23a8:      	mov.16b	v24, v18
    23ac:      	mov.16b	v31, v15
    23b0:      	ldr	q14, [sp, #0x3c0]
    23b4:      	mov.16b	v20, v25
    23b8:      	mov.16b	v25, v1
    23bc:      	ldp	q12, q26, [sp, #0x170]
    23c0:      	ldr	q18, [sp, #0x2e0]
    23c4:      	mov.16b	v15, v17
    23c8:      	ldr	q27, [sp, #0x380]
    23cc:      	ldr	q5, [sp, #0x2c0]
    23d0:      	and	x9, x9, #0x7
    23d4:      	str	q3, [sp, #0xeb0]
    23d8:      	str	q4, [sp, #0xec0]
    23dc:      	add	x14, sp, #0xeb0
    23e0:      	ldr	s1, [x14, x9, lsl #2]
    23e4:      	tst	w4, w16
    23e8:      	fcsel	s1, s1, s23, ne
    23ec:      	fmov	w9, s19
    23f0:      	cmp	w9, #0x8
    23f4:      	csel	w9, w9, wzr, lo
    23f8:      	cset	w16, lo
    23fc:      	add	x0, sp, #0xde8
    2400:      	bfxil	x0, x9, #0, #3
    2404:      	ldrb	w0, [x0]
    2408:      	and	w16, w16, w0
    240c:      	mov.s	w0, v19[1]
    2410:      	and	x9, x9, #0x7
    2414:      	str	q3, [sp, #0xe90]
    2418:      	str	q4, [sp, #0xea0]
    241c:      	add	x14, sp, #0xe90
    2420:      	ldr	s17, [x14, x9, lsl #2]
    2424:      	mov.s	w9, v19[2]
    2428:      	tst	w13, w16
    242c:      	fcsel	s17, s17, s23, ne
    2430:      	cmp	w0, #0x8
    2434:      	csel	w13, w0, wzr, lo
    2438:      	cset	w16, lo
    243c:      	add	x0, sp, #0xde8
    2440:      	bfxil	x0, x13, #0, #3
    2444:      	ldrb	w0, [x0]
    2448:      	and	w16, w16, w0
    244c:      	mov.s	w0, v19[3]
    2450:      	and	x13, x13, #0x7
    2454:      	str	q3, [sp, #0xe70]
    2458:      	str	q4, [sp, #0xe80]
    245c:      	add	x14, sp, #0xe70
    2460:      	ldr	s19, [x14, x13, lsl #2]
    2464:      	tst	w21, w16
    2468:      	add	x21, sp, #0x9, lsl #12  ; =0x9000
    246c:      	add	x21, x21, #0x308
    2470:      	fcsel	s19, s19, s23, ne
    2474:      	cmp	w9, #0x8
    2478:      	csel	w9, w9, wzr, lo
    247c:      	cset	w13, lo
    2480:      	add	x16, sp, #0xde8
    2484:      	bfxil	x16, x9, #0, #3
    2488:      	ldrb	w16, [x16]
    248c:      	and	w13, w13, w16
    2490:      	and	x9, x9, #0x7
    2494:      	str	q3, [sp, #0xe50]
    2498:      	str	q4, [sp, #0xe60]
    249c:      	mov.s	v17[1], v19[0]
    24a0:      	add	x14, sp, #0xe50
    24a4:      	ldr	s19, [x14, x9, lsl #2]
    24a8:      	tst	w2, w13
    24ac:      	fcsel	s19, s19, s23, ne
    24b0:      	mov.s	v17[2], v19[0]
    24b4:      	xtn.2s	v19, v28
    24b8:      	cmp	w0, #0x8
    24bc:      	csel	w9, w0, wzr, lo
    24c0:      	cset	w13, lo
    24c4:      	add	x16, sp, #0xde8
    24c8:      	bfxil	x16, x9, #0, #3
    24cc:      	and	x9, x9, #0x7
    24d0:      	ldrb	w16, [x16]
    24d4:      	and	w13, w13, w16
    24d8:      	str	q3, [sp, #0xe30]
    24dc:      	str	q4, [sp, #0xe40]
    24e0:      	fmov	w16, s19
    24e4:      	add	x14, sp, #0xe30
    24e8:      	ldr	s19, [x14, x9, lsl #2]
    24ec:      	tst	w24, w13
    24f0:      	adrp	x24, 0x2000 <ltmp0+0x2000>
    24f4:      	fcsel	s19, s19, s23, ne
    24f8:      	eor	w9, w16, #0x4
    24fc:      	cmp	w16, #0x8
    2500:      	csel	w9, w9, wzr, lo
    2504:      	cset	w13, lo
    2508:      	add	x16, sp, #0xde8
    250c:      	bfxil	x16, x9, #0, #3
    2510:      	ldrb	w16, [x16]
    2514:      	and	w13, w13, w16
    2518:      	mov.s	v17[3], v19[0]
    251c:      	mov.s	v6[1], v7[0]
    2520:      	mov.s	v6[2], v16[0]
    2524:      	tst	w23, w13
    2528:      	add	x23, sp, #0x9, lsl #12  ; =0x9000
    252c:      	add	x23, x23, #0x2c8
    2530:      	mov.s	v6[3], v1[0]
    2534:      	fadd.4s	v1, v3, v6
    2538:      	fadd.4s	v3, v4, v17
    253c:      	and	x9, x9, #0x7
    2540:      	str	q3, [sp, #0xe20]
    2544:      	str	q1, [sp, #0xe10]
    2548:      	add	x13, sp, #0xe10
    254c:      	ldr	s3, [x13, x9, lsl #2]
    2550:      	fcsel	s3, s3, s23, ne
    2554:      	ldr	w9, [sp, #0x2f0]
    2558:      	tst	w9, #0x1
    255c:      	fadd	s1, s1, s3
    2560:      	fcsel	s1, s1, s23, ne
    2564:      	ldr	w9, [sp, #0x1e0]
    2568:      	tst	w9, #0x1
    256c:      	fcsel	s3, s1, s23, ne
    2570:      	tst	w5, #0x1
    2574:      	fcsel	s4, s1, s23, ne
    2578:      	tst	w1, #0x1
    257c:      	fcsel	s6, s1, s23, ne
    2580:      	tst	w30, #0x1
    2584:      	adrp	x30, 0x2000 <ltmp0+0x2000>
    2588:      	fcsel	s7, s1, s23, ne
    258c:      	tst	w22, #0x1
    2590:      	fcsel	s16, s1, s23, ne
    2594:      	tst	w20, #0x1
    2598:      	mov	w20, #0x1               ; =1
    259c:      	fcsel	s17, s1, s23, ne
    25a0:      	tst	w17, #0x1
    25a4:      	fcsel	s19, s1, s23, ne
    25a8:      	mov.s	v1[1], v3[0]
    25ac:      	mov.s	v1[2], v4[0]
    25b0:      	mov.s	v1[3], v6[0]
    25b4:      	rbit	w9, w11
    25b8:      	clz	w9, w9
    25bc:      	mov.s	v7[1], v16[0]
    25c0:      	mov.s	v7[2], v17[0]
    25c4:      	mov.s	v7[3], v19[0]
    25c8:      	mov.16b	v19, v24
    25cc:      	mov.16b	v24, v29
    25d0:      	str	q7, [sp, #0xe00]
    25d4:      	str	q1, [sp, #0xdf0]
    25d8:      	and	x9, x9, #0x7
    25dc:      	add	x11, sp, #0xdf0
    25e0:      	ldr	s1, [x11, x9, lsl #2]
    25e4:      	fadd	s1, s1, s23
    25e8:      	ldr	q23, [sp, #0x2d0]
    25ec:      	mov	w9, #0x800              ; =2048
    25f0:      	movk	w9, #0x4580, lsl #16
    25f4:      	fmov	s3, w9
    25f8:      	fdiv	s1, s1, s3
    25fc:      	dup.4s	v1, v1[0]
    2600:      	zip2.8b	v3, v21, v0
    2604:      	ushll.4s	v3, v3, #0x0
    2608:      	shl.4s	v3, v3, #0x1f
    260c:      	cmlt.4s	v3, v3, #0
    2610:      	ldr	q4, [sp, #0x100]
    2614:      	bit.16b	v4, v1, v3
    2618:      	str	q4, [sp, #0x100]
    261c:      	zip1.8b	v3, v21, v0
    2620:      	ushll.4s	v3, v3, #0x0
    2624:      	shl.4s	v3, v3, #0x1f
    2628:      	cmlt.4s	v3, v3, #0
    262c:      	ldr	q4, [sp, #0x110]
    2630:      	bit.16b	v4, v1, v3
    2634:      	str	q4, [sp, #0x110]
    2638:      	mov	b1, v21[6]
    263c:      	mov.b	v1[4], v21[7]
    2640:      	ushll.2d	v1, v1, #0x0
    2644:      	shl.2d	v1, v1, #0x3f
    2648:      	cmlt.2d	v1, v1, #0
    264c:      	mov	b3, v21[4]
    2650:      	mov.b	v3[4], v21[5]
    2654:      	ushll.2d	v3, v3, #0x0
    2658:      	shl.2d	v3, v3, #0x3f
    265c:      	cmlt.2d	v3, v3, #0
    2660:      	mov	b4, v21[2]
    2664:      	mov.b	v4[4], v21[3]
    2668:      	ushll.2d	v4, v4, #0x0
    266c:      	shl.2d	v4, v4, #0x3f
    2670:      	cmlt.2d	v4, v4, #0
    2674:      	mov	b6, v21[0]
    2678:      	mov.b	v6[4], v21[1]
    267c:      	ushll.2d	v6, v6, #0x0
    2680:      	shl.2d	v6, v6, #0x3f
    2684:      	cmlt.2d	v6, v6, #0
    2688:      	ldr	q7, [x24]
    268c:      	bit.16b	v14, v7, v1
    2690:      	str	q14, [sp, #0x3c0]
    2694:      	ldr	q7, [x25]
    2698:      	bit.16b	v8, v7, v3
    269c:      	str	q8, [sp, #0x3e0]
    26a0:      	mov.16b	v8, v25
    26a4:      	mov.16b	v25, v20
    26a8:      	mov.16b	v14, v22
    26ac:      	mov.16b	v22, v28
    26b0:      	mov.16b	v28, v5
    26b4:      	ldr	q7, [x30]
    26b8:      	ldr	q5, [sp, #0x3d0]
    26bc:      	bit.16b	v5, v7, v4
    26c0:      	str	q5, [sp, #0x3d0]
    26c4:      	adrp	x9, 0x2000 <ltmp0+0x2000>
    26c8:      	ldr	q7, [x9]
    26cc:      	bit.16b	v15, v7, v6
    26d0:      	ldr	q7, [sp, #0x70]
    26d4:      	ldr	q5, [sp, #0x220]
    26d8:      	bit.16b	v5, v7, v1
    26dc:      	bic.16b	v12, v12, v1
    26e0:      	ldr	q1, [sp, #0x200]
    26e4:      	bit.16b	v1, v7, v3
    26e8:      	bic.16b	v18, v18, v3
    26ec:      	bit.16b	v31, v7, v4
    26f0:      	stp	q31, q1, [sp, #0x1f0]
    26f4:      	mov.16b	v31, v11
    26f8:      	ldr	q11, [sp, #0x160]
    26fc:      	movi.8b	v20, #0x1
    2700:      	bic.16b	v8, v8, v4
    2704:      	ldr	q1, [sp, #0x210]
    2708:      	bit.16b	v1, v7, v6
    270c:      	stp	q1, q5, [sp, #0x210]
    2710:      	ldr	q0, [sp, #0x3f0]
    2714:      	bic.16b	v0, v0, v6
    2718:      	str	q0, [sp, #0x3f0]
    271c:      	add	x22, sp, #0x9, lsl #12  ; =0x9000
    2720:      	add	x22, x22, #0x2e8
    2724:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    2728:      	add	x0, x0, #0x150
    272c:      	mov	w5, #-0x1               ; =-1
    2730:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    2734:      	add	x16, x16, #0x130
    2738:      	add	x4, sp, #0xdc0
    273c:      	ldr	x28, [sp, #0x88]
    2740:      	b	0x2768 <ltmp0+0x2768>
    2744:      	add	x22, sp, #0x9, lsl #12  ; =0x9000
    2748:      	add	x22, x22, #0x2e8
    274c:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    2750:      	add	x0, x0, #0x150
    2754:      	mov	w5, #-0x1               ; =-1
    2758:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    275c:      	add	x16, x16, #0x130
    2760:      	add	x4, sp, #0xdc0
    2764:      	b	0x298 <ltmp0+0x298>
    2768:      	shl.8b	v1, v21, #0x7
    276c:      	cmlt.8b	v1, v1, #0
    2770:      	and.8b	v1, v1, v2
    2774:      	addv.8b	b1, v1
    2778:      	fmov	w11, s1
    277c:      	mov	w9, #0x200              ; =512
    2780:      	dup.2d	v3, x9
    2784:      	cmgt.2d	v1, v3, v8
    2788:      	ldr	q0, [sp, #0x3f0]
    278c:      	cmgt.2d	v4, v3, v0
    2790:      	uzp1.4s	v1, v4, v1
    2794:      	cmgt.2d	v4, v3, v18
    2798:      	cmgt.2d	v6, v3, v12
    279c:      	uzp1.4s	v4, v4, v6
    27a0:      	uzp1.8h	v1, v1, v4
    27a4:      	xtn.8b	v1, v1
    27a8:      	and.8b	v1, v21, v1
    27ac:      	shl.8b	v1, v1, #0x7
    27b0:      	cmlt.8b	v4, v1, #0
    27b4:      	and.8b	v1, v4, v2
    27b8:      	addv.8b	b1, v1
    27bc:      	fmov	w13, s1
    27c0:      	umaxv.8b	b4, v4
    27c4:      	fmov	w14, s4
    27c8:      	tbz	w14, #0x0, 0x29f8 <ltmp0+0x29f8>
    27cc:      	cmge.2d	v4, v8, v3
    27d0:      	ldr	q0, [sp, #0x3f0]
    27d4:      	cmge.2d	v6, v0, v3
    27d8:      	uzp1.4s	v4, v6, v4
    27dc:      	cmge.2d	v6, v18, v3
    27e0:      	cmge.2d	v3, v12, v3
    27e4:      	uzp1.4s	v3, v6, v3
    27e8:      	uzp1.8h	v3, v4, v3
    27ec:      	xtn.8b	v3, v3
    27f0:      	and.8b	v3, v21, v3
    27f4:      	shl.8b	v3, v3, #0x7
    27f8:      	cmlt.8b	v3, v3, #0
    27fc:      	and.8b	v3, v3, v2
    2800:      	addv.8b	b3, v3
    2804:      	fmov	w14, s3
    2808:      	tst	w14, #0xff
    280c:      	b.eq	0x29f8 <ltmp0+0x29f8>
    2810:      	subs	w9, w12, #0x1
    2814:      	csel	w9, wzr, w9, lo
    2818:      	and	w13, w10, #0xff
    281c:      	lsr	w11, w13, w9
    2820:      	tst	w11, #0x1
    2824:      	ldr	q4, [sp, #0x430]
    2828:      	str	q4, [sp, #0x7b0]
    282c:      	ldr	q4, [sp, #0x440]
    2830:      	str	q4, [sp, #0x7c0]
    2834:      	and	x9, x9, #0x7
    2838:      	add	x11, sp, #0x7b0
    283c:      	ldr	w9, [x11, x9, lsl #2]
    2840:      	ccmp	w12, #0x0, #0x4, ne
    2844:      	ccmp	w9, #0x3, #0x0, ne
    2848:      	cset	w11, ne
    284c:      	cmp	w13, #0xff
    2850:      	b.ne	0x2858 <ltmp0+0x2858>
    2854:      	tbnz	w11, #0x0, 0x5410 <ltmp0+0x5410>
    2858:      	mvn	w9, w10
    285c:      	rbit	w9, w9
    2860:      	clz	w9, w9
    2864:      	mov	w13, #0xff              ; =255
    2868:      	bics	wzr, w13, w10
    286c:      	csel	w13, wzr, w9, eq
    2870:      	ubfiz	x9, x13, #2, #3
    2874:      	lsl	w14, w20, w13
    2878:      	ldr	q5, [sp, #0x430]
    287c:      	str	q5, [sp, #0x790]
    2880:      	ldr	q4, [sp, #0x440]
    2884:      	str	q4, [sp, #0x7a0]
    2888:      	add	x16, sp, #0x790
    288c:      	ldr	w16, [x16, x9]
    2890:      	cmp	w11, #0x0
    2894:      	csel	w11, w14, wzr, ne
    2898:      	mov	w14, #0x3               ; =3
    289c:      	csel	w14, w14, w16, ne
    28a0:      	str	q5, [sp, #0x770]
    28a4:      	str	q4, [sp, #0x780]
    28a8:      	add	x16, sp, #0x770
    28ac:      	str	w14, [x16, x9]
    28b0:      	ldr	q4, [sp, #0x780]
    28b4:      	str	q4, [sp, #0x440]
    28b8:      	ldr	q4, [sp, #0x770]
    28bc:      	str	q4, [sp, #0x430]
    28c0:      	ldr	q5, [sp, #0x410]
    28c4:      	str	q5, [sp, #0x750]
    28c8:      	ldr	q4, [sp, #0x420]
    28cc:      	str	q4, [sp, #0x760]
    28d0:      	add	x14, sp, #0x750
    28d4:      	ldr	w14, [x14, x9]
    28d8:      	csel	w14, w12, w14, ne
    28dc:      	str	q5, [sp, #0x730]
    28e0:      	str	q4, [sp, #0x740]
    28e4:      	add	x16, sp, #0x730
    28e8:      	str	w14, [x16, x9]
    28ec:      	ldrb	w9, [x27, x13]
    28f0:      	and	w14, w9, #0x1
    28f4:      	fmov	s4, w14
    28f8:      	ubfx	w14, w9, #1, #1
    28fc:      	mov.b	v4[1], w14
    2900:      	ubfx	w14, w9, #2, #1
    2904:      	mov.b	v4[2], w14
    2908:      	ubfx	w14, w9, #3, #1
    290c:      	mov.b	v4[3], w14
    2910:      	ubfx	w14, w9, #4, #1
    2914:      	mov.b	v4[4], w14
    2918:      	ubfx	w14, w9, #5, #1
    291c:      	mov.b	v4[5], w14
    2920:      	ubfx	w14, w9, #6, #1
    2924:      	mov.b	v4[6], w14
    2928:      	ldr	q5, [sp, #0x740]
    292c:      	str	q5, [sp, #0x420]
    2930:      	ldr	q5, [sp, #0x730]
    2934:      	str	q5, [sp, #0x410]
    2938:      	lsr	w9, w9, #7
    293c:      	mov.b	v4[7], w9
    2940:      	ldrb	w9, [x8, x13]
    2944:      	and	w14, w9, #0x1
    2948:      	fmov	s6, w14
    294c:      	ubfx	w14, w9, #1, #1
    2950:      	mov.b	v6[1], w14
    2954:      	ubfx	w14, w9, #2, #1
    2958:      	mov.b	v6[2], w14
    295c:      	ubfx	w14, w9, #3, #1
    2960:      	mov.b	v6[3], w14
    2964:      	ubfx	w14, w9, #4, #1
    2968:      	mov.b	v6[4], w14
    296c:      	ubfx	w14, w9, #5, #1
    2970:      	mov.b	v6[5], w14
    2974:      	ubfx	w14, w9, #6, #1
    2978:      	mov.b	v6[6], w14
    297c:      	lsr	w9, w9, #7
    2980:      	mov.b	v6[7], w9
    2984:      	csetm	w9, ne
    2988:      	dup.8b	v7, w9
    298c:      	bit.8b	v4, v21, v7
    2990:      	shl.8b	v4, v4, #0x7
    2994:      	cmlt.8b	v4, v4, #0
    2998:      	and.8b	v4, v4, v2
    299c:      	addv.8b	b4, v4
    29a0:      	str	b4, [x27, x13]
    29a4:      	bic.8b	v4, v6, v7
    29a8:      	shl.8b	v4, v4, #0x7
    29ac:      	cmlt.8b	v4, v4, #0
    29b0:      	and.8b	v4, v4, v2
    29b4:      	addv.8b	b4, v4
    29b8:      	str	b4, [x8, x13]
    29bc:      	csinc	w12, w12, w13, eq
    29c0:      	cmp	w26, #0x8
    29c4:      	b.hs	0x5410 <ltmp0+0x5410>
    29c8:      	str	b1, [x21, x28]
    29cc:      	mov	w9, #0xc                ; =12
    29d0:      	str	w9, [x22, x28, lsl #2]
    29d4:      	str	w12, [x23, x28, lsl #2]
    29d8:      	cmp	w19, #0x8
    29dc:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    29e0:      	add	x16, x16, #0x130
    29e4:      	b.hs	0x5410 <ltmp0+0x5410>
    29e8:      	str	b3, [x21, w19, uxtw]
    29ec:      	orr	w10, w11, w10
    29f0:      	mov	w9, #0xd                ; =13
    29f4:      	b	0x28c <ltmp0+0x28c>
    29f8:      	tst	w13, #0xff
    29fc:      	b.eq	0x2c0c <ltmp0+0x2c0c>
    2a00:      	tst	w11, #0xff
    2a04:      	b.eq	0x298 <ltmp0+0x298>
    2a08:      	rbit	w13, w11
    2a0c:      	clz	w13, w13
    2a10:      	tst	w11, #0xff
    2a14:      	csel	w13, wzr, w13, eq
    2a18:      	ldr	q0, [sp, #0x3f0]
    2a1c:      	str	q0, [sp, #0x810]
    2a20:      	str	q8, [sp, #0x820]
    2a24:      	str	q18, [sp, #0x830]
    2a28:      	str	q12, [sp, #0x840]
    2a2c:      	ubfiz	x14, x13, #3, #3
    2a30:      	add	x9, sp, #0x810
    2a34:      	ldr	x17, [x9, x14]
    2a38:      	str	q22, [sp, #0x7d0]
    2a3c:      	str	q24, [sp, #0x7e0]
    2a40:      	str	q27, [sp, #0x7f0]
    2a44:      	str	q28, [sp, #0x800]
    2a48:      	add	x9, sp, #0x7d0
    2a4c:      	ldr	x14, [x9, x14]
    2a50:      	sub	x13, x14, x13
    2a54:      	add	x14, x7, x17, lsl #5
    2a58:      	add	x13, x14, x13, lsl #2
    2a5c:      	shl.8b	v1, v21, #0x7
    2a60:      	cmlt.8b	v1, v1, #0
    2a64:      	and.8b	v1, v1, v2
    2a68:      	addv.8b	b4, v1
    2a6c:      	fmov	w14, s4
    2a70:      	movi.2d	v3, #0000000000000000
    2a74:      	movi.2d	v1, #0000000000000000
    2a78:      	tbz	w14, #0x0, 0x2abc <ltmp0+0x2abc>
    2a7c:      	ldr	s3, [x13]
    2a80:      	tbnz	w14, #0x1, 0x2ac0 <ltmp0+0x2ac0>
    2a84:      	tbz	w14, #0x2, 0x2acc <ltmp0+0x2acc>
    2a88:      	add	x17, x13, #0x8
    2a8c:      	ld1.s	{ v3 }[2], [x17]
    2a90:      	tbnz	w14, #0x3, 0x2ad0 <ltmp0+0x2ad0>
    2a94:      	tbz	w14, #0x4, 0x2adc <ltmp0+0x2adc>
    2a98:      	add	x17, x13, #0x10
    2a9c:      	ld1.s	{ v1 }[0], [x17]
    2aa0:      	tbnz	w14, #0x5, 0x2ae0 <ltmp0+0x2ae0>
    2aa4:      	tbz	w14, #0x6, 0x2aec <ltmp0+0x2aec>
    2aa8:      	add	x17, x13, #0x18
    2aac:      	ld1.s	{ v1 }[2], [x17]
    2ab0:      	mov.16b	v0, v19
    2ab4:      	tbnz	w14, #0x7, 0x2af4 <ltmp0+0x2af4>
    2ab8:      	b	0x2afc <ltmp0+0x2afc>
    2abc:      	tbz	w14, #0x1, 0x2a84 <ltmp0+0x2a84>
    2ac0:      	add	x17, x13, #0x4
    2ac4:      	ld1.s	{ v3 }[1], [x17]
    2ac8:      	tbnz	w14, #0x2, 0x2a88 <ltmp0+0x2a88>
    2acc:      	tbz	w14, #0x3, 0x2a94 <ltmp0+0x2a94>
    2ad0:      	add	x17, x13, #0xc
    2ad4:      	ld1.s	{ v3 }[3], [x17]
    2ad8:      	tbnz	w14, #0x4, 0x2a98 <ltmp0+0x2a98>
    2adc:      	tbz	w14, #0x5, 0x2aa4 <ltmp0+0x2aa4>
    2ae0:      	add	x17, x13, #0x14
    2ae4:      	ld1.s	{ v1 }[1], [x17]
    2ae8:      	tbnz	w14, #0x6, 0x2aa8 <ltmp0+0x2aa8>
    2aec:      	mov.16b	v0, v19
    2af0:      	tbz	w14, #0x7, 0x2afc <ltmp0+0x2afc>
    2af4:      	add	x13, x13, #0x1c
    2af8:      	ld1.s	{ v1 }[3], [x13]
    2afc:      	ldr	q5, [sp, #0x3f0]
    2b00:      	shl.2d	v6, v5, #0x5
    2b04:      	shl.2d	v7, v8, #0x5
    2b08:      	shl.2d	v17, v18, #0x5
    2b0c:      	shl.2d	v19, v12, #0x5
    2b10:      	ldr	q5, [sp, #0x210]
    2b14:      	add.2d	v16, v5, v15
    2b18:      	add.2d	v16, v16, v6
    2b1c:      	ldr	q5, [sp, #0x3d0]
    2b20:      	ldr	q6, [sp, #0x1f0]
    2b24:      	add.2d	v6, v6, v5
    2b28:      	add.2d	v7, v6, v7
    2b2c:      	ldr	q5, [sp, #0x200]
    2b30:      	ldr	q6, [sp, #0x3e0]
    2b34:      	add.2d	v6, v5, v6
    2b38:      	add.2d	v6, v6, v17
    2b3c:      	ldr	q5, [sp, #0x220]
    2b40:      	ldr	q17, [sp, #0x3c0]
    2b44:      	add.2d	v17, v5, v17
    2b48:      	fmov	w13, s4
    2b4c:      	add.2d	v4, v17, v19
    2b50:      	tbz	w13, #0x0, 0x2b98 <ltmp0+0x2b98>
    2b54:      	fmov	x14, d16
    2b58:      	str	s3, [x14]
    2b5c:      	mov.16b	v19, v0
    2b60:      	tbnz	w13, #0x1, 0x2ba0 <ltmp0+0x2ba0>
    2b64:      	tbz	w13, #0x2, 0x2bac <ltmp0+0x2bac>
    2b68:      	fmov	x14, d7
    2b6c:      	st1.s	{ v3 }[2], [x14]
    2b70:      	tbnz	w13, #0x3, 0x2bb0 <ltmp0+0x2bb0>
    2b74:      	tbz	w13, #0x4, 0x2bbc <ltmp0+0x2bbc>
    2b78:      	fmov	x14, d6
    2b7c:      	str	s1, [x14]
    2b80:      	tbnz	w13, #0x5, 0x2bc0 <ltmp0+0x2bc0>
    2b84:      	tbz	w13, #0x6, 0x2bcc <ltmp0+0x2bcc>
    2b88:      	fmov	x14, d4
    2b8c:      	st1.s	{ v1 }[2], [x14]
    2b90:      	tbnz	w13, #0x7, 0x2bd0 <ltmp0+0x2bd0>
    2b94:      	b	0x2bd8 <ltmp0+0x2bd8>
    2b98:      	mov.16b	v19, v0
    2b9c:      	tbz	w13, #0x1, 0x2b64 <ltmp0+0x2b64>
    2ba0:      	mov.d	x14, v16[1]
    2ba4:      	st1.s	{ v3 }[1], [x14]
    2ba8:      	tbnz	w13, #0x2, 0x2b68 <ltmp0+0x2b68>
    2bac:      	tbz	w13, #0x3, 0x2b74 <ltmp0+0x2b74>
    2bb0:      	mov.d	x14, v7[1]
    2bb4:      	st1.s	{ v3 }[3], [x14]
    2bb8:      	tbnz	w13, #0x4, 0x2b78 <ltmp0+0x2b78>
    2bbc:      	tbz	w13, #0x5, 0x2b84 <ltmp0+0x2b84>
    2bc0:      	mov.d	x14, v6[1]
    2bc4:      	st1.s	{ v1 }[1], [x14]
    2bc8:      	tbnz	w13, #0x6, 0x2b88 <ltmp0+0x2b88>
    2bcc:      	tbz	w13, #0x7, 0x2bd8 <ltmp0+0x2bd8>
    2bd0:      	mov.d	x13, v4[1]
    2bd4:      	st1.s	{ v1 }[3], [x13]
    2bd8:      	and.8b	v1, v21, v20
    2bdc:      	ushll.8h	v1, v1, #0x0
    2be0:      	ushll.4s	v3, v1, #0x0
    2be4:      	ushll2.4s	v1, v1, #0x0
    2be8:      	uaddw2.2d	v12, v12, v1
    2bec:      	uaddw.2d	v18, v18, v1
    2bf0:      	uaddw2.2d	v8, v8, v3
    2bf4:      	ldr	q0, [sp, #0x3f0]
    2bf8:      	uaddw.2d	v0, v0, v3
    2bfc:      	str	q0, [sp, #0x3f0]
    2c00:      	tst	w11, #0xff
    2c04:      	b.ne	0x2768 <ltmp0+0x2768>
    2c08:      	b	0x298 <ltmp0+0x298>
    2c0c:      	tst	w11, #0xff
    2c10:      	b.eq	0x298 <ltmp0+0x298>
    2c14:      	cbz	w12, 0x2ddc <ltmp0+0x2ddc>
    2c18:      	mov	w13, #0x0               ; =0
    2c1c:      	shl.8b	v1, v21, #0x7
    2c20:      	cmlt.8b	v1, v1, #0
    2c24:      	and.8b	v3, v1, v2
    2c28:      	addv.8b	b3, v3
    2c2c:      	fmov	w9, s3
    2c30:      	umaxv.8b	b1, v1
    2c34:      	fmov	w16, s1
    2c38:      	sub	w11, w12, #0x1
    2c3c:      	tst	w9, #0xff
    2c40:      	csel	w14, w11, wzr, ne
    2c44:      	lsl	w17, w20, w14
    2c48:      	and	w9, w17, w10
    2c4c:      	tst	w9, #0xff
    2c50:      	cset	w9, ne
    2c54:      	ldr	q1, [sp, #0x430]
    2c58:      	str	q1, [sp, #0xdc0]
    2c5c:      	ldr	q1, [sp, #0x440]
    2c60:      	str	q1, [sp, #0xdd0]
    2c64:      	ubfiz	x11, x14, #2, #3
    2c68:      	ldr	w0, [x4, x11]
    2c6c:      	cmp	w0, #0x3
    2c70:      	cset	w1, eq
    2c74:      	and	w2, w9, w16
    2c78:      	ldrb	w9, [x27, w14, sxtw]
    2c7c:      	and	w16, w9, #0x1
    2c80:      	fmov	s1, w16
    2c84:      	ubfx	w16, w9, #1, #1
    2c88:      	mov.b	v1[1], w16
    2c8c:      	ubfx	w16, w9, #2, #1
    2c90:      	mov.b	v1[2], w16
    2c94:      	ubfx	w16, w9, #3, #1
    2c98:      	mov.b	v1[3], w16
    2c9c:      	ubfx	w16, w9, #4, #1
    2ca0:      	mov.b	v1[4], w16
    2ca4:      	ubfx	w16, w9, #5, #1
    2ca8:      	mov.b	v1[5], w16
    2cac:      	ubfx	w16, w9, #6, #1
    2cb0:      	mov.b	v1[6], w16
    2cb4:      	lsr	w9, w9, #7
    2cb8:      	mov.b	v1[7], w9
    2cbc:      	ldrb	w9, [x8, w14, sxtw]
    2cc0:      	and	w16, w9, #0x1
    2cc4:      	fmov	s3, w16
    2cc8:      	ubfx	w16, w9, #1, #1
    2ccc:      	mov.b	v3[1], w16
    2cd0:      	ubfx	w16, w9, #2, #1
    2cd4:      	mov.b	v3[2], w16
    2cd8:      	ubfx	w16, w9, #3, #1
    2cdc:      	mov.b	v3[3], w16
    2ce0:      	ubfx	w16, w9, #4, #1
    2ce4:      	mov.b	v3[4], w16
    2ce8:      	ubfx	w16, w9, #5, #1
    2cec:      	mov.b	v3[5], w16
    2cf0:      	ubfx	w16, w9, #6, #1
    2cf4:      	mov.b	v3[6], w16
    2cf8:      	lsr	w9, w9, #7
    2cfc:      	mov.b	v3[7], w9
    2d00:      	orr.8b	v4, v21, v3
    2d04:      	and.8b	v6, v9, v1
    2d08:      	eor.8b	v6, v6, v4
    2d0c:      	shl.8b	v6, v6, #0x7
    2d10:      	cmlt.8b	v6, v6, #0
    2d14:      	umaxv.8b	b6, v6
    2d18:      	fmov	w9, s6
    2d1c:      	ands	w16, w2, w1
    2d20:      	csetm	w0, ne
    2d24:      	bics	w9, w16, w9
    2d28:      	csetm	w1, ne
    2d2c:      	dup.8b	v6, w1
    2d30:      	dup.8b	v7, w0
    2d34:      	bic.8b	v16, v4, v6
    2d38:      	bit.8b	v3, v16, v7
    2d3c:      	shl.8b	v3, v3, #0x7
    2d40:      	cmlt.8b	v3, v3, #0
    2d44:      	and.8b	v3, v3, v2
    2d48:      	addv.8b	b3, v3
    2d4c:      	str	b3, [x8, w14, sxtw]
    2d50:      	bic.8b	v1, v1, v6
    2d54:      	shl.8b	v1, v1, #0x7
    2d58:      	cmlt.8b	v1, v1, #0
    2d5c:      	and.8b	v1, v1, v2
    2d60:      	addv.8b	b1, v1
    2d64:      	str	b1, [x27, w14, sxtw]
    2d68:      	csinv	w14, w5, w17, eq
    2d6c:      	dup.8b	v1, w16
    2d70:      	and	w10, w14, w10
    2d74:      	shl.8b	v1, v1, #0x7
    2d78:      	cmlt.8b	v1, v1, #0
    2d7c:      	dup.8b	v3, w9
    2d80:      	and.8b	v3, v3, v4
    2d84:      	ldr	q4, [sp, #0x410]
    2d88:      	str	q4, [sp, #0xda0]
    2d8c:      	ldr	q4, [sp, #0x420]
    2d90:      	str	q4, [sp, #0xdb0]
    2d94:      	add	x9, sp, #0xda0
    2d98:      	ldr	w9, [x9, x11]
    2d9c:      	csel	w12, w9, w12, ne
    2da0:      	bit.8b	v21, v3, v1
    2da4:      	shl.8b	v1, v21, #0x7
    2da8:      	cmlt.8b	v1, v1, #0
    2dac:      	and.8b	v1, v1, v2
    2db0:      	addv.8b	b1, v1
    2db4:      	fmov	w11, s1
    2db8:      	cmp	w16, #0x1
    2dbc:      	b.ne	0x2df0 <ltmp0+0x2df0>
    2dc0:      	cmp	w12, #0x0
    2dc4:      	ccmp	w13, #0x6, #0x2, ne
    2dc8:      	b.hi	0x2df0 <ltmp0+0x2df0>
    2dcc:      	add	w13, w13, #0x1
    2dd0:      	tst	w11, #0xff
    2dd4:      	b.ne	0x2c1c <ltmp0+0x2c1c>
    2dd8:      	b	0x2df0 <ltmp0+0x2df0>
    2ddc:      	shl.8b	v1, v21, #0x7
    2de0:      	cmlt.8b	v1, v1, #0
    2de4:      	and.8b	v1, v1, v2
    2de8:      	addv.8b	b1, v1
    2dec:      	fmov	w11, s1
    2df0:      	tst	w11, #0xff
    2df4:      	b.eq	0x3450 <ltmp0+0x3450>
    2df8:      	and.8b	v1, v11, v21
    2dfc:      	shl.8b	v1, v1, #0x7
    2e00:      	cmlt.8b	v3, v1, #0
    2e04:      	and.8b	v1, v3, v2
    2e08:      	addv.8b	b1, v1
    2e0c:      	umaxv.8b	b3, v3
    2e10:      	fmov	w9, s3
    2e14:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    2e18:      	add	x0, x0, #0x150
    2e1c:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    2e20:      	add	x16, x16, #0x130
    2e24:      	tbz	w9, #0x0, 0x3030 <ltmp0+0x3030>
    2e28:      	bic.8b	v3, v21, v11
    2e2c:      	shl.8b	v3, v3, #0x7
    2e30:      	cmlt.8b	v3, v3, #0
    2e34:      	and.8b	v3, v3, v2
    2e38:      	addv.8b	b3, v3
    2e3c:      	fmov	w9, s3
    2e40:      	tst	w9, #0xff
    2e44:      	b.eq	0x3030 <ltmp0+0x3030>
    2e48:      	subs	w9, w12, #0x1
    2e4c:      	csel	w9, wzr, w9, lo
    2e50:      	and	w13, w10, #0xff
    2e54:      	lsr	w11, w13, w9
    2e58:      	tst	w11, #0x1
    2e5c:      	ldr	q4, [sp, #0x430]
    2e60:      	str	q4, [sp, #0x8d0]
    2e64:      	ldr	q4, [sp, #0x440]
    2e68:      	str	q4, [sp, #0x8e0]
    2e6c:      	and	x9, x9, #0x7
    2e70:      	add	x11, sp, #0x8d0
    2e74:      	ldr	w9, [x11, x9, lsl #2]
    2e78:      	ccmp	w12, #0x0, #0x4, ne
    2e7c:      	ccmp	w9, #0x4, #0x0, ne
    2e80:      	cset	w11, ne
    2e84:      	cmp	w13, #0xff
    2e88:      	b.ne	0x2e90 <ltmp0+0x2e90>
    2e8c:      	tbnz	w11, #0x0, 0x5410 <ltmp0+0x5410>
    2e90:      	mvn	w9, w10
    2e94:      	rbit	w9, w9
    2e98:      	clz	w9, w9
    2e9c:      	mov	w13, #0xff              ; =255
    2ea0:      	bics	wzr, w13, w10
    2ea4:      	csel	w13, wzr, w9, eq
    2ea8:      	ubfiz	x9, x13, #2, #3
    2eac:      	lsl	w14, w20, w13
    2eb0:      	ldr	q5, [sp, #0x430]
    2eb4:      	str	q5, [sp, #0x8b0]
    2eb8:      	ldr	q4, [sp, #0x440]
    2ebc:      	str	q4, [sp, #0x8c0]
    2ec0:      	add	x16, sp, #0x8b0
    2ec4:      	ldr	w16, [x16, x9]
    2ec8:      	cmp	w11, #0x0
    2ecc:      	csel	w11, w14, wzr, ne
    2ed0:      	mov	w14, #0x4               ; =4
    2ed4:      	csel	w14, w14, w16, ne
    2ed8:      	str	q5, [sp, #0x890]
    2edc:      	str	q4, [sp, #0x8a0]
    2ee0:      	add	x16, sp, #0x890
    2ee4:      	str	w14, [x16, x9]
    2ee8:      	ldr	q4, [sp, #0x8a0]
    2eec:      	str	q4, [sp, #0x440]
    2ef0:      	ldr	q4, [sp, #0x890]
    2ef4:      	str	q4, [sp, #0x430]
    2ef8:      	ldr	q5, [sp, #0x410]
    2efc:      	str	q5, [sp, #0x870]
    2f00:      	ldr	q4, [sp, #0x420]
    2f04:      	str	q4, [sp, #0x880]
    2f08:      	add	x14, sp, #0x870
    2f0c:      	ldr	w14, [x14, x9]
    2f10:      	csel	w14, w12, w14, ne
    2f14:      	str	q5, [sp, #0x850]
    2f18:      	str	q4, [sp, #0x860]
    2f1c:      	add	x16, sp, #0x850
    2f20:      	str	w14, [x16, x9]
    2f24:      	ldrb	w9, [x27, x13]
    2f28:      	and	w14, w9, #0x1
    2f2c:      	fmov	s4, w14
    2f30:      	ubfx	w14, w9, #1, #1
    2f34:      	mov.b	v4[1], w14
    2f38:      	ubfx	w14, w9, #2, #1
    2f3c:      	mov.b	v4[2], w14
    2f40:      	ubfx	w14, w9, #3, #1
    2f44:      	mov.b	v4[3], w14
    2f48:      	ubfx	w14, w9, #4, #1
    2f4c:      	mov.b	v4[4], w14
    2f50:      	ubfx	w14, w9, #5, #1
    2f54:      	mov.b	v4[5], w14
    2f58:      	ubfx	w14, w9, #6, #1
    2f5c:      	mov.b	v4[6], w14
    2f60:      	ldr	q5, [sp, #0x860]
    2f64:      	str	q5, [sp, #0x420]
    2f68:      	ldr	q5, [sp, #0x850]
    2f6c:      	str	q5, [sp, #0x410]
    2f70:      	lsr	w9, w9, #7
    2f74:      	mov.b	v4[7], w9
    2f78:      	ldrb	w9, [x8, x13]
    2f7c:      	and	w14, w9, #0x1
    2f80:      	fmov	s6, w14
    2f84:      	ubfx	w14, w9, #1, #1
    2f88:      	mov.b	v6[1], w14
    2f8c:      	ubfx	w14, w9, #2, #1
    2f90:      	mov.b	v6[2], w14
    2f94:      	ubfx	w14, w9, #3, #1
    2f98:      	mov.b	v6[3], w14
    2f9c:      	ubfx	w14, w9, #4, #1
    2fa0:      	mov.b	v6[4], w14
    2fa4:      	ubfx	w14, w9, #5, #1
    2fa8:      	mov.b	v6[5], w14
    2fac:      	ubfx	w14, w9, #6, #1
    2fb0:      	mov.b	v6[6], w14
    2fb4:      	lsr	w9, w9, #7
    2fb8:      	mov.b	v6[7], w9
    2fbc:      	csetm	w9, ne
    2fc0:      	dup.8b	v7, w9
    2fc4:      	bit.8b	v4, v21, v7
    2fc8:      	shl.8b	v4, v4, #0x7
    2fcc:      	cmlt.8b	v4, v4, #0
    2fd0:      	and.8b	v4, v4, v2
    2fd4:      	addv.8b	b4, v4
    2fd8:      	str	b4, [x27, x13]
    2fdc:      	bic.8b	v4, v6, v7
    2fe0:      	shl.8b	v4, v4, #0x7
    2fe4:      	cmlt.8b	v4, v4, #0
    2fe8:      	and.8b	v4, v4, v2
    2fec:      	addv.8b	b4, v4
    2ff0:      	str	b4, [x8, x13]
    2ff4:      	csinc	w12, w12, w13, eq
    2ff8:      	cmp	w26, #0x8
    2ffc:      	b.hs	0x5410 <ltmp0+0x5410>
    3000:      	str	b1, [x21, x28]
    3004:      	mov	w9, #0xe                ; =14
    3008:      	str	w9, [x22, x28, lsl #2]
    300c:      	str	w12, [x23, x28, lsl #2]
    3010:      	cmp	w19, #0x8
    3014:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    3018:      	add	x16, x16, #0x130
    301c:      	b.hs	0x5410 <ltmp0+0x5410>
    3020:      	str	b3, [x21, w19, uxtw]
    3024:      	orr	w10, w11, w10
    3028:      	mov	w9, #0xf                ; =15
    302c:      	b	0x28c <ltmp0+0x28c>
    3030:      	fmov	w9, s1
    3034:      	tst	w9, #0xff
    3038:      	b.eq	0x3180 <ltmp0+0x3180>
    303c:      	rbit	w13, w11
    3040:      	clz	w13, w13
    3044:      	tst	w11, #0xff
    3048:      	csel	w13, wzr, w13, eq
    304c:      	str	q22, [sp, #0xd60]
    3050:      	str	q24, [sp, #0xd70]
    3054:      	str	q27, [sp, #0xd80]
    3058:      	str	q28, [sp, #0xd90]
    305c:      	and	x14, x13, #0x7
    3060:      	add	x9, sp, #0xd60
    3064:      	ldr	x14, [x9, x14, lsl #3]
    3068:      	sub	x14, x14, x13
    306c:      	ldr	x9, [sp, #0x80]
    3070:      	add	x14, x9, x14, lsl #2
    3074:      	shl.8b	v1, v21, #0x7
    3078:      	cmlt.8b	v1, v1, #0
    307c:      	and.8b	v1, v1, v2
    3080:      	addv.8b	b1, v1
    3084:      	fmov	w17, s1
    3088:      	movi.2d	v1, #0000000000000000
    308c:      	movi.2d	v3, #0000000000000000
    3090:      	tbz	w17, #0x0, 0x30d0 <ltmp0+0x30d0>
    3094:      	ldr	s1, [x14]
    3098:      	tbnz	w17, #0x1, 0x30d4 <ltmp0+0x30d4>
    309c:      	tbz	w17, #0x2, 0x30e0 <ltmp0+0x30e0>
    30a0:      	add	x1, x14, #0x8
    30a4:      	ld1.s	{ v1 }[2], [x1]
    30a8:      	tbnz	w17, #0x3, 0x30e4 <ltmp0+0x30e4>
    30ac:      	tbz	w17, #0x4, 0x30f0 <ltmp0+0x30f0>
    30b0:      	add	x1, x14, #0x10
    30b4:      	ld1.s	{ v3 }[0], [x1]
    30b8:      	tbnz	w17, #0x5, 0x30f4 <ltmp0+0x30f4>
    30bc:      	tbz	w17, #0x6, 0x3100 <ltmp0+0x3100>
    30c0:      	add	x1, x14, #0x18
    30c4:      	ld1.s	{ v3 }[2], [x1]
    30c8:      	tbnz	w17, #0x7, 0x3104 <ltmp0+0x3104>
    30cc:      	b	0x310c <ltmp0+0x310c>
    30d0:      	tbz	w17, #0x1, 0x309c <ltmp0+0x309c>
    30d4:      	add	x1, x14, #0x4
    30d8:      	ld1.s	{ v1 }[1], [x1]
    30dc:      	tbnz	w17, #0x2, 0x30a0 <ltmp0+0x30a0>
    30e0:      	tbz	w17, #0x3, 0x30ac <ltmp0+0x30ac>
    30e4:      	add	x1, x14, #0xc
    30e8:      	ld1.s	{ v1 }[3], [x1]
    30ec:      	tbnz	w17, #0x4, 0x30b0 <ltmp0+0x30b0>
    30f0:      	tbz	w17, #0x5, 0x30bc <ltmp0+0x30bc>
    30f4:      	add	x1, x14, #0x14
    30f8:      	ld1.s	{ v3 }[1], [x1]
    30fc:      	tbnz	w17, #0x6, 0x30c0 <ltmp0+0x30c0>
    3100:      	tbz	w17, #0x7, 0x310c <ltmp0+0x310c>
    3104:      	add	x14, x14, #0x1c
    3108:      	ld1.s	{ v3 }[3], [x14]
    310c:      	str	q15, [sp, #0xd20]
    3110:      	ldp	q0, q4, [sp, #0x3d0]
    3114:      	str	q0, [sp, #0xd30]
    3118:      	str	q4, [sp, #0xd40]
    311c:      	ldr	q0, [sp, #0x3c0]
    3120:      	str	q0, [sp, #0xd50]
    3124:      	and	x14, x13, #0x7
    3128:      	add	x9, sp, #0xd20
    312c:      	ldr	x14, [x9, x14, lsl #3]
    3130:      	sub	x13, x14, x13, lsl #2
    3134:      	add	x13, x13, #0x4, lsl #12 ; =0x4000
    3138:      	ands	w11, w11, #0xff
    313c:      	csel	x13, xzr, x13, eq
    3140:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    3144:      	add	x9, x9, #0x278
    3148:      	add	x13, x9, x13
    314c:      	ldp	q4, q6, [x13]
    3150:      	zip2.8b	v7, v21, v0
    3154:      	ushll.4s	v7, v7, #0x0
    3158:      	shl.4s	v7, v7, #0x1f
    315c:      	cmlt.4s	v7, v7, #0
    3160:      	bif.16b	v3, v6, v7
    3164:      	zip1.8b	v6, v21, v0
    3168:      	ushll.4s	v6, v6, #0x0
    316c:      	shl.4s	v6, v6, #0x1f
    3170:      	cmlt.4s	v6, v6, #0
    3174:      	bif.16b	v1, v4, v6
    3178:      	stp	q1, q3, [x13]
    317c:      	cbz	w11, 0x298 <ltmp0+0x298>
    3180:      	cbz	w12, 0x334c <ltmp0+0x334c>
    3184:      	mov	w11, #0x0               ; =0
    3188:      	shl.8b	v1, v21, #0x7
    318c:      	cmlt.8b	v1, v1, #0
    3190:      	and.8b	v3, v1, v2
    3194:      	addv.8b	b3, v3
    3198:      	fmov	w9, s3
    319c:      	umaxv.8b	b1, v1
    31a0:      	fmov	w16, s1
    31a4:      	sub	w13, w12, #0x1
    31a8:      	tst	w9, #0xff
    31ac:      	csel	w14, w13, wzr, ne
    31b0:      	lsl	w17, w20, w14
    31b4:      	and	w9, w17, w10
    31b8:      	tst	w9, #0xff
    31bc:      	cset	w9, ne
    31c0:      	ldr	q1, [sp, #0x430]
    31c4:      	str	q1, [sp, #0xd00]
    31c8:      	ldr	q1, [sp, #0x440]
    31cc:      	str	q1, [sp, #0xd10]
    31d0:      	ubfiz	x13, x14, #2, #3
    31d4:      	add	x0, sp, #0xd00
    31d8:      	ldr	w0, [x0, x13]
    31dc:      	cmp	w0, #0x4
    31e0:      	cset	w1, eq
    31e4:      	and	w2, w9, w16
    31e8:      	ldrb	w9, [x27, w14, sxtw]
    31ec:      	and	w16, w9, #0x1
    31f0:      	fmov	s1, w16
    31f4:      	ubfx	w16, w9, #1, #1
    31f8:      	mov.b	v1[1], w16
    31fc:      	ubfx	w16, w9, #2, #1
    3200:      	mov.b	v1[2], w16
    3204:      	ubfx	w16, w9, #3, #1
    3208:      	mov.b	v1[3], w16
    320c:      	ubfx	w16, w9, #4, #1
    3210:      	mov.b	v1[4], w16
    3214:      	ubfx	w16, w9, #5, #1
    3218:      	mov.b	v1[5], w16
    321c:      	ubfx	w16, w9, #6, #1
    3220:      	mov.b	v1[6], w16
    3224:      	lsr	w9, w9, #7
    3228:      	mov.b	v1[7], w9
    322c:      	ldrb	w9, [x8, w14, sxtw]
    3230:      	and	w16, w9, #0x1
    3234:      	fmov	s3, w16
    3238:      	ubfx	w16, w9, #1, #1
    323c:      	mov.b	v3[1], w16
    3240:      	ubfx	w16, w9, #2, #1
    3244:      	mov.b	v3[2], w16
    3248:      	ubfx	w16, w9, #3, #1
    324c:      	mov.b	v3[3], w16
    3250:      	ubfx	w16, w9, #4, #1
    3254:      	mov.b	v3[4], w16
    3258:      	ubfx	w16, w9, #5, #1
    325c:      	mov.b	v3[5], w16
    3260:      	ubfx	w16, w9, #6, #1
    3264:      	mov.b	v3[6], w16
    3268:      	lsr	w9, w9, #7
    326c:      	mov.b	v3[7], w9
    3270:      	orr.8b	v4, v21, v3
    3274:      	and.8b	v6, v9, v1
    3278:      	eor.8b	v6, v6, v4
    327c:      	shl.8b	v6, v6, #0x7
    3280:      	cmlt.8b	v6, v6, #0
    3284:      	umaxv.8b	b6, v6
    3288:      	fmov	w9, s6
    328c:      	ands	w16, w2, w1
    3290:      	csetm	w0, ne
    3294:      	bics	w9, w16, w9
    3298:      	csetm	w1, ne
    329c:      	dup.8b	v6, w1
    32a0:      	dup.8b	v7, w0
    32a4:      	bic.8b	v16, v4, v6
    32a8:      	bit.8b	v3, v16, v7
    32ac:      	shl.8b	v3, v3, #0x7
    32b0:      	cmlt.8b	v3, v3, #0
    32b4:      	and.8b	v3, v3, v2
    32b8:      	addv.8b	b3, v3
    32bc:      	str	b3, [x8, w14, sxtw]
    32c0:      	bic.8b	v1, v1, v6
    32c4:      	shl.8b	v1, v1, #0x7
    32c8:      	cmlt.8b	v1, v1, #0
    32cc:      	and.8b	v1, v1, v2
    32d0:      	addv.8b	b1, v1
    32d4:      	str	b1, [x27, w14, sxtw]
    32d8:      	csinv	w14, w5, w17, eq
    32dc:      	dup.8b	v1, w16
    32e0:      	and	w10, w14, w10
    32e4:      	shl.8b	v1, v1, #0x7
    32e8:      	cmlt.8b	v1, v1, #0
    32ec:      	dup.8b	v3, w9
    32f0:      	and.8b	v3, v3, v4
    32f4:      	ldr	q4, [sp, #0x410]
    32f8:      	str	q4, [sp, #0xce0]
    32fc:      	ldr	q4, [sp, #0x420]
    3300:      	str	q4, [sp, #0xcf0]
    3304:      	add	x9, sp, #0xce0
    3308:      	ldr	w9, [x9, x13]
    330c:      	csel	w12, w9, w12, ne
    3310:      	bit.8b	v21, v3, v1
    3314:      	shl.8b	v1, v21, #0x7
    3318:      	cmlt.8b	v1, v1, #0
    331c:      	and.8b	v1, v1, v2
    3320:      	addv.8b	b1, v1
    3324:      	fmov	w13, s1
    3328:      	cmp	w16, #0x1
    332c:      	b.ne	0x3360 <ltmp0+0x3360>
    3330:      	cmp	w12, #0x0
    3334:      	ccmp	w11, #0x6, #0x2, ne
    3338:      	b.hi	0x3360 <ltmp0+0x3360>
    333c:      	add	w11, w11, #0x1
    3340:      	tst	w13, #0xff
    3344:      	b.ne	0x3188 <ltmp0+0x3188>
    3348:      	b	0x3360 <ltmp0+0x3360>
    334c:      	shl.8b	v1, v21, #0x7
    3350:      	cmlt.8b	v1, v1, #0
    3354:      	and.8b	v1, v1, v2
    3358:      	addv.8b	b1, v1
    335c:      	fmov	w13, s1
    3360:      	tst	w13, #0xff
    3364:      	b.eq	0x3450 <ltmp0+0x3450>
    3368:      	rbit	w9, w13
    336c:      	clz	w9, w9
    3370:      	ldp	q1, q0, [sp, #0x100]
    3374:      	str	q0, [sp, #0xcc0]
    3378:      	str	q1, [sp, #0xcd0]
    337c:      	and	x9, x9, #0x7
    3380:      	add	x11, sp, #0xcc0
    3384:      	ldr	s1, [x11, x9, lsl #2]
    3388:      	mov	w9, #0xc5ac             ; =50604
    338c:      	movk	w9, #0x3727, lsl #16
    3390:      	fmov	s3, w9
    3394:      	fadd	s1, s1, s3
    3398:      	fsqrt	s1, s1
    339c:      	dup.4s	v1, v1[0]
    33a0:      	zip2.8b	v3, v21, v0
    33a4:      	ushll.4s	v3, v3, #0x0
    33a8:      	shl.4s	v3, v3, #0x1f
    33ac:      	cmlt.4s	v3, v3, #0
    33b0:      	ldr	q4, [sp, #0x320]
    33b4:      	bit.16b	v4, v1, v3
    33b8:      	zip1.8b	v3, v21, v0
    33bc:      	ushll.4s	v3, v3, #0x0
    33c0:      	shl.4s	v3, v3, #0x1f
    33c4:      	cmlt.4s	v3, v3, #0
    33c8:      	ldr	q0, [sp, #0x310]
    33cc:      	bit.16b	v0, v1, v3
    33d0:      	stp	q0, q4, [sp, #0x310]
    33d4:      	mov	b1, v21[6]
    33d8:      	mov.b	v1[4], v21[7]
    33dc:      	ushll.2d	v1, v1, #0x0
    33e0:      	shl.2d	v1, v1, #0x3f
    33e4:      	cmge.2d	v1, v1, #0
    33e8:      	and.16b	v26, v1, v26
    33ec:      	mov	b1, v21[4]
    33f0:      	mov.b	v1[4], v21[5]
    33f4:      	ushll.2d	v1, v1, #0x0
    33f8:      	shl.2d	v1, v1, #0x3f
    33fc:      	cmge.2d	v1, v1, #0
    3400:      	mov	b3, v21[2]
    3404:      	mov.b	v3[4], v21[3]
    3408:      	and.16b	v19, v1, v19
    340c:      	ushll.2d	v1, v3, #0x0
    3410:      	shl.2d	v1, v1, #0x3f
    3414:      	cmge.2d	v1, v1, #0
    3418:      	ldr	q0, [sp, #0x400]
    341c:      	and.16b	v0, v1, v0
    3420:      	str	q0, [sp, #0x400]
    3424:      	mov	b1, v21[0]
    3428:      	mov.b	v1[4], v21[1]
    342c:      	ushll.2d	v1, v1, #0x0
    3430:      	shl.2d	v1, v1, #0x3f
    3434:      	cmge.2d	v1, v1, #0
    3438:      	and.16b	v23, v1, v23
    343c:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    3440:      	add	x0, x0, #0x150
    3444:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    3448:      	add	x16, x16, #0x130
    344c:      	b	0x3464 <ltmp0+0x3464>
    3450:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    3454:      	add	x0, x0, #0x150
    3458:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    345c:      	add	x16, x16, #0x130
    3460:      	b	0x298 <ltmp0+0x298>
    3464:      	shl.8b	v1, v21, #0x7
    3468:      	cmlt.8b	v1, v1, #0
    346c:      	and.8b	v1, v1, v2
    3470:      	addv.8b	b1, v1
    3474:      	fmov	w11, s1
    3478:      	mov	w9, #0x200              ; =512
    347c:      	dup.2d	v3, x9
    3480:      	ldr	q0, [sp, #0x400]
    3484:      	cmgt.2d	v1, v3, v0
    3488:      	cmgt.2d	v4, v3, v23
    348c:      	uzp1.4s	v1, v4, v1
    3490:      	cmgt.2d	v4, v3, v19
    3494:      	cmgt.2d	v6, v3, v26
    3498:      	uzp1.4s	v4, v4, v6
    349c:      	uzp1.8h	v1, v1, v4
    34a0:      	xtn.8b	v1, v1
    34a4:      	and.8b	v1, v21, v1
    34a8:      	shl.8b	v1, v1, #0x7
    34ac:      	cmlt.8b	v4, v1, #0
    34b0:      	and.8b	v1, v4, v2
    34b4:      	addv.8b	b1, v1
    34b8:      	fmov	w13, s1
    34bc:      	umaxv.8b	b4, v4
    34c0:      	fmov	w14, s4
    34c4:      	tbz	w14, #0x0, 0x36f4 <ltmp0+0x36f4>
    34c8:      	ldr	q0, [sp, #0x400]
    34cc:      	cmge.2d	v4, v0, v3
    34d0:      	cmge.2d	v6, v23, v3
    34d4:      	uzp1.4s	v4, v6, v4
    34d8:      	cmge.2d	v6, v19, v3
    34dc:      	cmge.2d	v3, v26, v3
    34e0:      	uzp1.4s	v3, v6, v3
    34e4:      	uzp1.8h	v3, v4, v3
    34e8:      	xtn.8b	v3, v3
    34ec:      	and.8b	v3, v21, v3
    34f0:      	shl.8b	v3, v3, #0x7
    34f4:      	cmlt.8b	v3, v3, #0
    34f8:      	and.8b	v3, v3, v2
    34fc:      	addv.8b	b3, v3
    3500:      	fmov	w14, s3
    3504:      	tst	w14, #0xff
    3508:      	b.eq	0x36f4 <ltmp0+0x36f4>
    350c:      	subs	w9, w12, #0x1
    3510:      	csel	w9, wzr, w9, lo
    3514:      	and	w13, w10, #0xff
    3518:      	lsr	w11, w13, w9
    351c:      	tst	w11, #0x1
    3520:      	ldr	q4, [sp, #0x430]
    3524:      	str	q4, [sp, #0x970]
    3528:      	ldr	q4, [sp, #0x440]
    352c:      	str	q4, [sp, #0x980]
    3530:      	and	x9, x9, #0x7
    3534:      	add	x11, sp, #0x970
    3538:      	ldr	w9, [x11, x9, lsl #2]
    353c:      	ccmp	w12, #0x0, #0x4, ne
    3540:      	ccmp	w9, #0x5, #0x0, ne
    3544:      	cset	w11, ne
    3548:      	cmp	w13, #0xff
    354c:      	b.ne	0x3554 <ltmp0+0x3554>
    3550:      	tbnz	w11, #0x0, 0x5410 <ltmp0+0x5410>
    3554:      	mvn	w9, w10
    3558:      	rbit	w9, w9
    355c:      	clz	w9, w9
    3560:      	mov	w13, #0xff              ; =255
    3564:      	bics	wzr, w13, w10
    3568:      	csel	w13, wzr, w9, eq
    356c:      	ubfiz	x9, x13, #2, #3
    3570:      	lsl	w14, w20, w13
    3574:      	ldr	q5, [sp, #0x430]
    3578:      	str	q5, [sp, #0x950]
    357c:      	ldr	q4, [sp, #0x440]
    3580:      	str	q4, [sp, #0x960]
    3584:      	add	x16, sp, #0x950
    3588:      	ldr	w16, [x16, x9]
    358c:      	cmp	w11, #0x0
    3590:      	csel	w11, w14, wzr, ne
    3594:      	mov	w14, #0x5               ; =5
    3598:      	csel	w14, w14, w16, ne
    359c:      	str	q5, [sp, #0x930]
    35a0:      	str	q4, [sp, #0x940]
    35a4:      	add	x16, sp, #0x930
    35a8:      	str	w14, [x16, x9]
    35ac:      	ldr	q4, [sp, #0x940]
    35b0:      	str	q4, [sp, #0x440]
    35b4:      	ldr	q4, [sp, #0x930]
    35b8:      	str	q4, [sp, #0x430]
    35bc:      	ldr	q5, [sp, #0x410]
    35c0:      	str	q5, [sp, #0x910]
    35c4:      	ldr	q4, [sp, #0x420]
    35c8:      	str	q4, [sp, #0x920]
    35cc:      	add	x14, sp, #0x910
    35d0:      	ldr	w14, [x14, x9]
    35d4:      	csel	w14, w12, w14, ne
    35d8:      	str	q5, [sp, #0x8f0]
    35dc:      	str	q4, [sp, #0x900]
    35e0:      	add	x16, sp, #0x8f0
    35e4:      	str	w14, [x16, x9]
    35e8:      	ldrb	w9, [x27, x13]
    35ec:      	and	w14, w9, #0x1
    35f0:      	fmov	s4, w14
    35f4:      	ubfx	w14, w9, #1, #1
    35f8:      	mov.b	v4[1], w14
    35fc:      	ubfx	w14, w9, #2, #1
    3600:      	mov.b	v4[2], w14
    3604:      	ubfx	w14, w9, #3, #1
    3608:      	mov.b	v4[3], w14
    360c:      	ubfx	w14, w9, #4, #1
    3610:      	mov.b	v4[4], w14
    3614:      	ubfx	w14, w9, #5, #1
    3618:      	mov.b	v4[5], w14
    361c:      	ubfx	w14, w9, #6, #1
    3620:      	mov.b	v4[6], w14
    3624:      	ldr	q5, [sp, #0x900]
    3628:      	str	q5, [sp, #0x420]
    362c:      	ldr	q5, [sp, #0x8f0]
    3630:      	str	q5, [sp, #0x410]
    3634:      	lsr	w9, w9, #7
    3638:      	mov.b	v4[7], w9
    363c:      	ldrb	w9, [x8, x13]
    3640:      	and	w14, w9, #0x1
    3644:      	fmov	s6, w14
    3648:      	ubfx	w14, w9, #1, #1
    364c:      	mov.b	v6[1], w14
    3650:      	ubfx	w14, w9, #2, #1
    3654:      	mov.b	v6[2], w14
    3658:      	ubfx	w14, w9, #3, #1
    365c:      	mov.b	v6[3], w14
    3660:      	ubfx	w14, w9, #4, #1
    3664:      	mov.b	v6[4], w14
    3668:      	ubfx	w14, w9, #5, #1
    366c:      	mov.b	v6[5], w14
    3670:      	ubfx	w14, w9, #6, #1
    3674:      	mov.b	v6[6], w14
    3678:      	lsr	w9, w9, #7
    367c:      	mov.b	v6[7], w9
    3680:      	csetm	w9, ne
    3684:      	dup.8b	v7, w9
    3688:      	bit.8b	v4, v21, v7
    368c:      	shl.8b	v4, v4, #0x7
    3690:      	cmlt.8b	v4, v4, #0
    3694:      	and.8b	v4, v4, v2
    3698:      	addv.8b	b4, v4
    369c:      	str	b4, [x27, x13]
    36a0:      	bic.8b	v4, v6, v7
    36a4:      	shl.8b	v4, v4, #0x7
    36a8:      	cmlt.8b	v4, v4, #0
    36ac:      	and.8b	v4, v4, v2
    36b0:      	addv.8b	b4, v4
    36b4:      	str	b4, [x8, x13]
    36b8:      	csinc	w12, w12, w13, eq
    36bc:      	cmp	w26, #0x8
    36c0:      	b.hs	0x5410 <ltmp0+0x5410>
    36c4:      	str	b1, [x21, x28]
    36c8:      	mov	w9, #0x11               ; =17
    36cc:      	str	w9, [x22, x28, lsl #2]
    36d0:      	str	w12, [x23, x28, lsl #2]
    36d4:      	cmp	w19, #0x8
    36d8:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    36dc:      	add	x16, x16, #0x130
    36e0:      	b.hs	0x5410 <ltmp0+0x5410>
    36e4:      	str	b3, [x21, w19, uxtw]
    36e8:      	orr	w10, w11, w10
    36ec:      	mov	w9, #0x12               ; =18
    36f0:      	b	0x28c <ltmp0+0x28c>
    36f4:      	tst	w13, #0xff
    36f8:      	b.eq	0x3af0 <ltmp0+0x3af0>
    36fc:      	tst	w11, #0xff
    3700:      	b.eq	0x298 <ltmp0+0x298>
    3704:      	str	q10, [sp, #0x170]
    3708:      	str	d9, [sp, #0x180]
    370c:      	ldr	q1, [sp, #0x400]
    3710:      	mov.16b	v5, v12
    3714:      	stp	q22, q8, [sp, #0x1d0]
    3718:      	mov.16b	v4, v24
    371c:      	mov.16b	v24, v15
    3720:      	stp	q18, q4, [sp, #0x2e0]
    3724:      	str	q27, [sp, #0x380]
    3728:      	stp	q28, q23, [sp, #0x2c0]
    372c:      	mov.16b	v12, v25
    3730:      	mov.16b	v28, v31
    3734:      	mov.16b	v10, v14
    3738:      	ldp	q29, q9, [sp, #0x3a0]
    373c:      	mov.16b	v31, v13
    3740:      	rbit	w13, w11
    3744:      	clz	w13, w13
    3748:      	tst	w11, #0xff
    374c:      	csel	w14, wzr, w13, eq
    3750:      	shl.2d	v3, v23, #0x5
    3754:      	shl.2d	v4, v1, #0x5
    3758:      	mov.16b	v18, v19
    375c:      	shl.2d	v6, v19, #0x5
    3760:      	shl.2d	v7, v26, #0x5
    3764:      	ldr	q1, [sp, #0x1c0]
    3768:      	ldp	q16, q0, [sp, #0x360]
    376c:      	add.2d	v1, v1, v0
    3770:      	add.2d	v25, v1, v3
    3774:      	ldr	q1, [sp, #0x1b0]
    3778:      	add.2d	v1, v1, v16
    377c:      	add.2d	v23, v1, v4
    3780:      	ldr	q1, [sp, #0x1a0]
    3784:      	ldp	q16, q0, [sp, #0x340]
    3788:      	add.2d	v1, v1, v0
    378c:      	add.2d	v20, v1, v6
    3790:      	ldr	q1, [sp, #0x190]
    3794:      	add.2d	v1, v1, v16
    3798:      	add.2d	v19, v1, v7
    379c:      	shl.8b	v1, v21, #0x7
    37a0:      	cmlt.8b	v1, v1, #0
    37a4:      	and.8b	v1, v1, v2
    37a8:      	addv.8b	b1, v1
    37ac:      	fmov	w13, s1
    37b0:      	movi.2d	v17, #0000000000000000
    37b4:      	movi.2d	v16, #0000000000000000
    37b8:      	stp	q29, q9, [sp, #0x3a0]
    37bc:      	tbz	w13, #0x0, 0x3818 <ltmp0+0x3818>
    37c0:      	fmov	x17, d25
    37c4:      	ldr	s17, [x17]
    37c8:      	tbnz	w13, #0x1, 0x381c <ltmp0+0x381c>
    37cc:      	tbz	w13, #0x2, 0x3828 <ltmp0+0x3828>
    37d0:      	fmov	x17, d23
    37d4:      	ld1.s	{ v17 }[2], [x17]
    37d8:      	tbnz	w13, #0x3, 0x382c <ltmp0+0x382c>
    37dc:      	tbz	w13, #0x4, 0x3838 <ltmp0+0x3838>
    37e0:      	fmov	x17, d20
    37e4:      	ld1.s	{ v16 }[0], [x17]
    37e8:      	mov.16b	v13, v5
    37ec:      	tbnz	w13, #0x5, 0x3840 <ltmp0+0x3840>
    37f0:      	ldr	q0, [sp, #0x170]
    37f4:      	ldr	d9, [sp, #0x180]
    37f8:      	mov.16b	v15, v18
    37fc:      	tbz	w13, #0x6, 0x3858 <ltmp0+0x3858>
    3800:      	fmov	x17, d19
    3804:      	ld1.s	{ v16 }[2], [x17]
    3808:      	ldp	q14, q8, [sp, #0x1d0]
    380c:      	ldp	q18, q25, [sp, #0x2e0]
    3810:      	tbnz	w13, #0x7, 0x3864 <ltmp0+0x3864>
    3814:      	b	0x386c <ltmp0+0x386c>
    3818:      	tbz	w13, #0x1, 0x37cc <ltmp0+0x37cc>
    381c:      	mov.d	x17, v25[1]
    3820:      	ld1.s	{ v17 }[1], [x17]
    3824:      	tbnz	w13, #0x2, 0x37d0 <ltmp0+0x37d0>
    3828:      	tbz	w13, #0x3, 0x37dc <ltmp0+0x37dc>
    382c:      	mov.d	x17, v23[1]
    3830:      	ld1.s	{ v17 }[3], [x17]
    3834:      	tbnz	w13, #0x4, 0x37e0 <ltmp0+0x37e0>
    3838:      	mov.16b	v13, v5
    383c:      	tbz	w13, #0x5, 0x37f0 <ltmp0+0x37f0>
    3840:      	mov.d	x17, v20[1]
    3844:      	ld1.s	{ v16 }[1], [x17]
    3848:      	ldr	q0, [sp, #0x170]
    384c:      	ldr	d9, [sp, #0x180]
    3850:      	mov.16b	v15, v18
    3854:      	tbnz	w13, #0x6, 0x3800 <ltmp0+0x3800>
    3858:      	ldp	q14, q8, [sp, #0x1d0]
    385c:      	ldp	q18, q25, [sp, #0x2e0]
    3860:      	tbz	w13, #0x7, 0x386c <ltmp0+0x386c>
    3864:      	mov.d	x13, v19[1]
    3868:      	ld1.s	{ v16 }[3], [x13]
    386c:      	ldr	q27, [sp, #0x380]
    3870:      	ldr	q5, [sp, #0x310]
    3874:      	str	q5, [sp, #0xa50]
    3878:      	ldr	q5, [sp, #0x320]
    387c:      	str	q5, [sp, #0xa60]
    3880:      	and	x13, x14, #0x7
    3884:      	add	x9, sp, #0xa50
    3888:      	add	x13, x9, x13, lsl #2
    388c:      	ld1r.4s	{ v19 }, [x13]
    3890:      	fdiv.4s	v16, v16, v19
    3894:      	fdiv.4s	v17, v17, v19
    3898:      	ldr	q5, [sp, #0x3c0]
    389c:      	add.2d	v23, v7, v5
    38a0:      	ldp	q5, q7, [sp, #0x3d0]
    38a4:      	add.2d	v6, v6, v7
    38a8:      	add.2d	v4, v4, v5
    38ac:      	add.2d	v3, v3, v24
    38b0:      	ldr	q5, [sp, #0x210]
    38b4:      	add.2d	v20, v5, v3
    38b8:      	ldp	q5, q3, [sp, #0x1f0]
    38bc:      	add.2d	v19, v5, v4
    38c0:      	add.2d	v7, v3, v6
    38c4:      	ldr	q3, [sp, #0x220]
    38c8:      	add.2d	v6, v3, v23
    38cc:      	fmov	w13, s1
    38d0:      	movi.2d	v3, #0000000000000000
    38d4:      	movi.2d	v4, #0000000000000000
    38d8:      	ldr	q5, [sp, #0x2c0]
    38dc:      	tbz	w13, #0x0, 0x3914 <ltmp0+0x3914>
    38e0:      	fmov	x17, d20
    38e4:      	ldr	s3, [x17]
    38e8:      	ldr	q23, [sp, #0x2d0]
    38ec:      	tbnz	w13, #0x1, 0x391c <ltmp0+0x391c>
    38f0:      	mov.16b	v20, v11
    38f4:      	mov.16b	v22, v12
    38f8:      	mov.16b	v12, v13
    38fc:      	tbz	w13, #0x2, 0x3934 <ltmp0+0x3934>
    3900:      	fmov	x17, d19
    3904:      	ld1.s	{ v3 }[2], [x17]
    3908:      	mov.16b	v13, v31
    390c:      	tbnz	w13, #0x3, 0x393c <ltmp0+0x393c>
    3910:      	b	0x3944 <ltmp0+0x3944>
    3914:      	ldr	q23, [sp, #0x2d0]
    3918:      	tbz	w13, #0x1, 0x38f0 <ltmp0+0x38f0>
    391c:      	mov.d	x17, v20[1]
    3920:      	ld1.s	{ v3 }[1], [x17]
    3924:      	mov.16b	v20, v11
    3928:      	mov.16b	v22, v12
    392c:      	mov.16b	v12, v13
    3930:      	tbnz	w13, #0x2, 0x3900 <ltmp0+0x3900>
    3934:      	mov.16b	v13, v31
    3938:      	tbz	w13, #0x3, 0x3944 <ltmp0+0x3944>
    393c:      	mov.d	x17, v19[1]
    3940:      	ld1.s	{ v3 }[3], [x17]
    3944:      	mov.16b	v11, v10
    3948:      	mov.16b	v10, v0
    394c:      	mov.16b	v0, v25
    3950:      	mov.16b	v19, v15
    3954:      	mov.16b	v31, v28
    3958:      	mov.16b	v15, v24
    395c:      	mov.16b	v28, v5
    3960:      	mov.16b	v25, v22
    3964:      	tbz	w13, #0x4, 0x399c <ltmp0+0x399c>
    3968:      	fmov	x17, d7
    396c:      	ld1.s	{ v4 }[0], [x17]
    3970:      	mov.16b	v22, v14
    3974:      	mov.16b	v24, v0
    3978:      	mov.16b	v14, v11
    397c:      	tbnz	w13, #0x5, 0x39ac <ltmp0+0x39ac>
    3980:      	mov.16b	v11, v20
    3984:      	movi.8b	v20, #0x1
    3988:      	tbz	w13, #0x6, 0x39c0 <ltmp0+0x39c0>
    398c:      	fmov	x17, d6
    3990:      	ld1.s	{ v4 }[2], [x17]
    3994:      	tbnz	w13, #0x7, 0x39c4 <ltmp0+0x39c4>
    3998:      	b	0x39cc <ltmp0+0x39cc>
    399c:      	mov.16b	v22, v14
    39a0:      	mov.16b	v24, v0
    39a4:      	mov.16b	v14, v11
    39a8:      	tbz	w13, #0x5, 0x3980 <ltmp0+0x3980>
    39ac:      	mov.d	x17, v7[1]
    39b0:      	ld1.s	{ v4 }[1], [x17]
    39b4:      	mov.16b	v11, v20
    39b8:      	movi.8b	v20, #0x1
    39bc:      	tbnz	w13, #0x6, 0x398c <ltmp0+0x398c>
    39c0:      	tbz	w13, #0x7, 0x39cc <ltmp0+0x39cc>
    39c4:      	mov.d	x13, v6[1]
    39c8:      	ld1.s	{ v4 }[3], [x13]
    39cc:      	fmul.4s	v6, v3, v17
    39d0:      	fmul.4s	v3, v4, v16
    39d4:      	ldp	q4, q0, [sp, #0x2a0]
    39d8:      	str	q0, [sp, #0xa10]
    39dc:      	str	q4, [sp, #0xa20]
    39e0:      	ldp	q4, q0, [sp, #0x280]
    39e4:      	str	q0, [sp, #0xa30]
    39e8:      	str	q4, [sp, #0xa40]
    39ec:      	ubfiz	x13, x14, #3, #3
    39f0:      	add	x9, sp, #0xa10
    39f4:      	ldr	x17, [x9, x13]
    39f8:      	str	q23, [sp, #0x9d0]
    39fc:      	ldr	q0, [sp, #0x400]
    3a00:      	str	q0, [sp, #0x9e0]
    3a04:      	str	q19, [sp, #0x9f0]
    3a08:      	str	q26, [sp, #0xa00]
    3a0c:      	add	x9, sp, #0x9d0
    3a10:      	ldr	x1, [x9, x13]
    3a14:      	str	q22, [sp, #0x990]
    3a18:      	str	q24, [sp, #0x9a0]
    3a1c:      	str	q27, [sp, #0x9b0]
    3a20:      	str	q28, [sp, #0x9c0]
    3a24:      	add	x9, sp, #0x990
    3a28:      	ldr	x13, [x9, x13]
    3a2c:      	add	x17, x17, x17, lsl #12
    3a30:      	sub	x13, x13, x14
    3a34:      	add	x13, x13, x17
    3a38:      	add	x14, x3, x1, lsl #5
    3a3c:      	add	x13, x14, x13, lsl #2
    3a40:      	fmov	w14, s1
    3a44:      	tbz	w14, #0x0, 0x3a80 <ltmp0+0x3a80>
    3a48:      	str	s6, [x13]
    3a4c:      	tbnz	w14, #0x1, 0x3a84 <ltmp0+0x3a84>
    3a50:      	tbz	w14, #0x2, 0x3a90 <ltmp0+0x3a90>
    3a54:      	add	x17, x13, #0x8
    3a58:      	st1.s	{ v6 }[2], [x17]
    3a5c:      	tbnz	w14, #0x3, 0x3a94 <ltmp0+0x3a94>
    3a60:      	tbz	w14, #0x4, 0x3aa0 <ltmp0+0x3aa0>
    3a64:      	str	s3, [x13, #0x10]
    3a68:      	tbnz	w14, #0x5, 0x3aa4 <ltmp0+0x3aa4>
    3a6c:      	tbz	w14, #0x6, 0x3ab0 <ltmp0+0x3ab0>
    3a70:      	add	x17, x13, #0x18
    3a74:      	st1.s	{ v3 }[2], [x17]
    3a78:      	tbnz	w14, #0x7, 0x3ab4 <ltmp0+0x3ab4>
    3a7c:      	b	0x3abc <ltmp0+0x3abc>
    3a80:      	tbz	w14, #0x1, 0x3a50 <ltmp0+0x3a50>
    3a84:      	add	x17, x13, #0x4
    3a88:      	st1.s	{ v6 }[1], [x17]
    3a8c:      	tbnz	w14, #0x2, 0x3a54 <ltmp0+0x3a54>
    3a90:      	tbz	w14, #0x3, 0x3a60 <ltmp0+0x3a60>
    3a94:      	add	x17, x13, #0xc
    3a98:      	st1.s	{ v6 }[3], [x17]
    3a9c:      	tbnz	w14, #0x4, 0x3a64 <ltmp0+0x3a64>
    3aa0:      	tbz	w14, #0x5, 0x3a6c <ltmp0+0x3a6c>
    3aa4:      	add	x17, x13, #0x14
    3aa8:      	st1.s	{ v3 }[1], [x17]
    3aac:      	tbnz	w14, #0x6, 0x3a70 <ltmp0+0x3a70>
    3ab0:      	tbz	w14, #0x7, 0x3abc <ltmp0+0x3abc>
    3ab4:      	add	x13, x13, #0x1c
    3ab8:      	st1.s	{ v3 }[3], [x13]
    3abc:      	and.8b	v1, v21, v20
    3ac0:      	ushll.8h	v1, v1, #0x0
    3ac4:      	ushll.4s	v3, v1, #0x0
    3ac8:      	ushll2.4s	v1, v1, #0x0
    3acc:      	uaddw2.2d	v26, v26, v1
    3ad0:      	uaddw.2d	v19, v19, v1
    3ad4:      	ldr	q0, [sp, #0x400]
    3ad8:      	uaddw2.2d	v0, v0, v3
    3adc:      	str	q0, [sp, #0x400]
    3ae0:      	uaddw.2d	v23, v23, v3
    3ae4:      	tst	w11, #0xff
    3ae8:      	b.ne	0x3464 <ltmp0+0x3464>
    3aec:      	b	0x298 <ltmp0+0x298>
    3af0:      	tst	w11, #0xff
    3af4:      	b.eq	0x298 <ltmp0+0x298>
    3af8:      	cbz	w12, 0x3cc4 <ltmp0+0x3cc4>
    3afc:      	mov	w13, #0x0               ; =0
    3b00:      	shl.8b	v1, v21, #0x7
    3b04:      	cmlt.8b	v1, v1, #0
    3b08:      	and.8b	v3, v1, v2
    3b0c:      	addv.8b	b3, v3
    3b10:      	fmov	w9, s3
    3b14:      	umaxv.8b	b1, v1
    3b18:      	fmov	w16, s1
    3b1c:      	sub	w11, w12, #0x1
    3b20:      	tst	w9, #0xff
    3b24:      	csel	w14, w11, wzr, ne
    3b28:      	lsl	w17, w20, w14
    3b2c:      	and	w9, w17, w10
    3b30:      	tst	w9, #0xff
    3b34:      	cset	w9, ne
    3b38:      	ldr	q1, [sp, #0x430]
    3b3c:      	str	q1, [sp, #0xca0]
    3b40:      	ldr	q1, [sp, #0x440]
    3b44:      	str	q1, [sp, #0xcb0]
    3b48:      	ubfiz	x11, x14, #2, #3
    3b4c:      	add	x0, sp, #0xca0
    3b50:      	ldr	w0, [x0, x11]
    3b54:      	cmp	w0, #0x5
    3b58:      	cset	w1, eq
    3b5c:      	and	w2, w9, w16
    3b60:      	ldrb	w9, [x27, w14, sxtw]
    3b64:      	and	w16, w9, #0x1
    3b68:      	fmov	s1, w16
    3b6c:      	ubfx	w16, w9, #1, #1
    3b70:      	mov.b	v1[1], w16
    3b74:      	ubfx	w16, w9, #2, #1
    3b78:      	mov.b	v1[2], w16
    3b7c:      	ubfx	w16, w9, #3, #1
    3b80:      	mov.b	v1[3], w16
    3b84:      	ubfx	w16, w9, #4, #1
    3b88:      	mov.b	v1[4], w16
    3b8c:      	ubfx	w16, w9, #5, #1
    3b90:      	mov.b	v1[5], w16
    3b94:      	ubfx	w16, w9, #6, #1
    3b98:      	mov.b	v1[6], w16
    3b9c:      	lsr	w9, w9, #7
    3ba0:      	mov.b	v1[7], w9
    3ba4:      	ldrb	w9, [x8, w14, sxtw]
    3ba8:      	and	w16, w9, #0x1
    3bac:      	fmov	s3, w16
    3bb0:      	ubfx	w16, w9, #1, #1
    3bb4:      	mov.b	v3[1], w16
    3bb8:      	ubfx	w16, w9, #2, #1
    3bbc:      	mov.b	v3[2], w16
    3bc0:      	ubfx	w16, w9, #3, #1
    3bc4:      	mov.b	v3[3], w16
    3bc8:      	ubfx	w16, w9, #4, #1
    3bcc:      	mov.b	v3[4], w16
    3bd0:      	ubfx	w16, w9, #5, #1
    3bd4:      	mov.b	v3[5], w16
    3bd8:      	ubfx	w16, w9, #6, #1
    3bdc:      	mov.b	v3[6], w16
    3be0:      	lsr	w9, w9, #7
    3be4:      	mov.b	v3[7], w9
    3be8:      	orr.8b	v4, v21, v3
    3bec:      	and.8b	v6, v9, v1
    3bf0:      	eor.8b	v6, v6, v4
    3bf4:      	shl.8b	v6, v6, #0x7
    3bf8:      	cmlt.8b	v6, v6, #0
    3bfc:      	umaxv.8b	b6, v6
    3c00:      	fmov	w9, s6
    3c04:      	ands	w16, w2, w1
    3c08:      	csetm	w0, ne
    3c0c:      	bics	w9, w16, w9
    3c10:      	csetm	w1, ne
    3c14:      	dup.8b	v6, w1
    3c18:      	dup.8b	v7, w0
    3c1c:      	bic.8b	v16, v4, v6
    3c20:      	bit.8b	v3, v16, v7
    3c24:      	shl.8b	v3, v3, #0x7
    3c28:      	cmlt.8b	v3, v3, #0
    3c2c:      	and.8b	v3, v3, v2
    3c30:      	addv.8b	b3, v3
    3c34:      	str	b3, [x8, w14, sxtw]
    3c38:      	bic.8b	v1, v1, v6
    3c3c:      	shl.8b	v1, v1, #0x7
    3c40:      	cmlt.8b	v1, v1, #0
    3c44:      	and.8b	v1, v1, v2
    3c48:      	addv.8b	b1, v1
    3c4c:      	str	b1, [x27, w14, sxtw]
    3c50:      	csinv	w14, w5, w17, eq
    3c54:      	dup.8b	v1, w16
    3c58:      	and	w10, w14, w10
    3c5c:      	shl.8b	v1, v1, #0x7
    3c60:      	cmlt.8b	v1, v1, #0
    3c64:      	dup.8b	v3, w9
    3c68:      	and.8b	v3, v3, v4
    3c6c:      	ldr	q4, [sp, #0x410]
    3c70:      	str	q4, [sp, #0xc80]
    3c74:      	ldr	q4, [sp, #0x420]
    3c78:      	str	q4, [sp, #0xc90]
    3c7c:      	add	x9, sp, #0xc80
    3c80:      	ldr	w9, [x9, x11]
    3c84:      	csel	w12, w9, w12, ne
    3c88:      	bit.8b	v21, v3, v1
    3c8c:      	shl.8b	v1, v21, #0x7
    3c90:      	cmlt.8b	v1, v1, #0
    3c94:      	and.8b	v1, v1, v2
    3c98:      	addv.8b	b1, v1
    3c9c:      	fmov	w11, s1
    3ca0:      	cmp	w16, #0x1
    3ca4:      	b.ne	0x3cd8 <ltmp0+0x3cd8>
    3ca8:      	cmp	w12, #0x0
    3cac:      	ccmp	w13, #0x6, #0x2, ne
    3cb0:      	b.hi	0x3cd8 <ltmp0+0x3cd8>
    3cb4:      	add	w13, w13, #0x1
    3cb8:      	tst	w11, #0xff
    3cbc:      	b.ne	0x3b00 <ltmp0+0x3b00>
    3cc0:      	b	0x3cd8 <ltmp0+0x3cd8>
    3cc4:      	shl.8b	v1, v21, #0x7
    3cc8:      	cmlt.8b	v1, v1, #0
    3ccc:      	and.8b	v1, v1, v2
    3cd0:      	addv.8b	b1, v1
    3cd4:      	fmov	w11, s1
    3cd8:      	tst	w11, #0xff
    3cdc:      	b.eq	0x3450 <ltmp0+0x3450>
    3ce0:      	and.8b	v1, v11, v21
    3ce4:      	shl.8b	v1, v1, #0x7
    3ce8:      	cmlt.8b	v3, v1, #0
    3cec:      	and.8b	v1, v3, v2
    3cf0:      	addv.8b	b1, v1
    3cf4:      	umaxv.8b	b3, v3
    3cf8:      	fmov	w9, s3
    3cfc:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    3d00:      	add	x0, x0, #0x150
    3d04:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    3d08:      	add	x16, x16, #0x130
    3d0c:      	tbz	w9, #0x0, 0x3f18 <ltmp0+0x3f18>
    3d10:      	bic.8b	v3, v21, v11
    3d14:      	shl.8b	v3, v3, #0x7
    3d18:      	cmlt.8b	v3, v3, #0
    3d1c:      	and.8b	v3, v3, v2
    3d20:      	addv.8b	b3, v3
    3d24:      	fmov	w9, s3
    3d28:      	tst	w9, #0xff
    3d2c:      	b.eq	0x3f18 <ltmp0+0x3f18>
    3d30:      	subs	w9, w12, #0x1
    3d34:      	csel	w9, wzr, w9, lo
    3d38:      	and	w13, w10, #0xff
    3d3c:      	lsr	w11, w13, w9
    3d40:      	tst	w11, #0x1
    3d44:      	ldr	q4, [sp, #0x430]
    3d48:      	str	q4, [sp, #0xaf0]
    3d4c:      	ldr	q4, [sp, #0x440]
    3d50:      	str	q4, [sp, #0xb00]
    3d54:      	and	x9, x9, #0x7
    3d58:      	add	x11, sp, #0xaf0
    3d5c:      	ldr	w9, [x11, x9, lsl #2]
    3d60:      	ccmp	w12, #0x0, #0x4, ne
    3d64:      	ccmp	w9, #0x6, #0x0, ne
    3d68:      	cset	w11, ne
    3d6c:      	cmp	w13, #0xff
    3d70:      	b.ne	0x3d78 <ltmp0+0x3d78>
    3d74:      	tbnz	w11, #0x0, 0x5410 <ltmp0+0x5410>
    3d78:      	mvn	w9, w10
    3d7c:      	rbit	w9, w9
    3d80:      	clz	w9, w9
    3d84:      	mov	w13, #0xff              ; =255
    3d88:      	bics	wzr, w13, w10
    3d8c:      	csel	w13, wzr, w9, eq
    3d90:      	ubfiz	x9, x13, #2, #3
    3d94:      	lsl	w14, w20, w13
    3d98:      	ldr	q5, [sp, #0x430]
    3d9c:      	str	q5, [sp, #0xad0]
    3da0:      	ldr	q4, [sp, #0x440]
    3da4:      	str	q4, [sp, #0xae0]
    3da8:      	add	x16, sp, #0xad0
    3dac:      	ldr	w16, [x16, x9]
    3db0:      	cmp	w11, #0x0
    3db4:      	csel	w11, w14, wzr, ne
    3db8:      	mov	w14, #0x6               ; =6
    3dbc:      	csel	w14, w14, w16, ne
    3dc0:      	str	q5, [sp, #0xab0]
    3dc4:      	str	q4, [sp, #0xac0]
    3dc8:      	add	x16, sp, #0xab0
    3dcc:      	str	w14, [x16, x9]
    3dd0:      	ldr	q4, [sp, #0xac0]
    3dd4:      	str	q4, [sp, #0x440]
    3dd8:      	ldr	q4, [sp, #0xab0]
    3ddc:      	str	q4, [sp, #0x430]
    3de0:      	ldr	q5, [sp, #0x410]
    3de4:      	str	q5, [sp, #0xa90]
    3de8:      	ldr	q4, [sp, #0x420]
    3dec:      	str	q4, [sp, #0xaa0]
    3df0:      	add	x14, sp, #0xa90
    3df4:      	ldr	w14, [x14, x9]
    3df8:      	csel	w14, w12, w14, ne
    3dfc:      	str	q5, [sp, #0xa70]
    3e00:      	str	q4, [sp, #0xa80]
    3e04:      	add	x16, sp, #0xa70
    3e08:      	str	w14, [x16, x9]
    3e0c:      	ldrb	w9, [x27, x13]
    3e10:      	and	w14, w9, #0x1
    3e14:      	fmov	s4, w14
    3e18:      	ubfx	w14, w9, #1, #1
    3e1c:      	mov.b	v4[1], w14
    3e20:      	ubfx	w14, w9, #2, #1
    3e24:      	mov.b	v4[2], w14
    3e28:      	ubfx	w14, w9, #3, #1
    3e2c:      	mov.b	v4[3], w14
    3e30:      	ubfx	w14, w9, #4, #1
    3e34:      	mov.b	v4[4], w14
    3e38:      	ubfx	w14, w9, #5, #1
    3e3c:      	mov.b	v4[5], w14
    3e40:      	ubfx	w14, w9, #6, #1
    3e44:      	mov.b	v4[6], w14
    3e48:      	ldr	q5, [sp, #0xa80]
    3e4c:      	str	q5, [sp, #0x420]
    3e50:      	ldr	q5, [sp, #0xa70]
    3e54:      	str	q5, [sp, #0x410]
    3e58:      	lsr	w9, w9, #7
    3e5c:      	mov.b	v4[7], w9
    3e60:      	ldrb	w9, [x8, x13]
    3e64:      	and	w14, w9, #0x1
    3e68:      	fmov	s6, w14
    3e6c:      	ubfx	w14, w9, #1, #1
    3e70:      	mov.b	v6[1], w14
    3e74:      	ubfx	w14, w9, #2, #1
    3e78:      	mov.b	v6[2], w14
    3e7c:      	ubfx	w14, w9, #3, #1
    3e80:      	mov.b	v6[3], w14
    3e84:      	ubfx	w14, w9, #4, #1
    3e88:      	mov.b	v6[4], w14
    3e8c:      	ubfx	w14, w9, #5, #1
    3e90:      	mov.b	v6[5], w14
    3e94:      	ubfx	w14, w9, #6, #1
    3e98:      	mov.b	v6[6], w14
    3e9c:      	lsr	w9, w9, #7
    3ea0:      	mov.b	v6[7], w9
    3ea4:      	csetm	w9, ne
    3ea8:      	dup.8b	v7, w9
    3eac:      	bit.8b	v4, v21, v7
    3eb0:      	shl.8b	v4, v4, #0x7
    3eb4:      	cmlt.8b	v4, v4, #0
    3eb8:      	and.8b	v4, v4, v2
    3ebc:      	addv.8b	b4, v4
    3ec0:      	str	b4, [x27, x13]
    3ec4:      	bic.8b	v4, v6, v7
    3ec8:      	shl.8b	v4, v4, #0x7
    3ecc:      	cmlt.8b	v4, v4, #0
    3ed0:      	and.8b	v4, v4, v2
    3ed4:      	addv.8b	b4, v4
    3ed8:      	str	b4, [x8, x13]
    3edc:      	csinc	w12, w12, w13, eq
    3ee0:      	cmp	w26, #0x8
    3ee4:      	b.hs	0x5410 <ltmp0+0x5410>
    3ee8:      	str	b1, [x21, x28]
    3eec:      	mov	w9, #0x13               ; =19
    3ef0:      	str	w9, [x22, x28, lsl #2]
    3ef4:      	str	w12, [x23, x28, lsl #2]
    3ef8:      	cmp	w19, #0x8
    3efc:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    3f00:      	add	x16, x16, #0x130
    3f04:      	b.hs	0x5410 <ltmp0+0x5410>
    3f08:      	str	b3, [x21, w19, uxtw]
    3f0c:      	orr	w10, w11, w10
    3f10:      	mov	w9, #0x14               ; =20
    3f14:      	b	0x28c <ltmp0+0x28c>
    3f18:      	fmov	w9, s1
    3f1c:      	tst	w9, #0xff
    3f20:      	b.eq	0x40ec <ltmp0+0x40ec>
    3f24:      	rbit	w13, w11
    3f28:      	clz	w13, w13
    3f2c:      	tst	w11, #0xff
    3f30:      	csel	w14, wzr, w13, eq
    3f34:      	mov	w9, #0x4000             ; =16384
    3f38:      	sub	x17, x9, w14, uxtw #2
    3f3c:      	tst	w11, #0xff
    3f40:      	ldp	q1, q0, [sp, #0x360]
    3f44:      	str	q0, [sp, #0xc40]
    3f48:      	str	q1, [sp, #0xc50]
    3f4c:      	ldp	q1, q0, [sp, #0x340]
    3f50:      	str	q0, [sp, #0xc60]
    3f54:      	str	q1, [sp, #0xc70]
    3f58:      	and	x1, x14, #0x7
    3f5c:      	add	x9, sp, #0xc20
    3f60:      	add	x2, x9, x1, lsl #2
    3f64:      	add	x9, sp, #0xc40
    3f68:      	ldr	x13, [x9, x1, lsl #3]
    3f6c:      	add	x13, x17, x13
    3f70:      	csel	x13, xzr, x13, eq
    3f74:      	add	x13, x15, x13
    3f78:      	ldp	q3, q1, [x13]
    3f7c:      	zip1.8b	v4, v21, v0
    3f80:      	ushll.4s	v4, v4, #0x0
    3f84:      	shl.4s	v4, v4, #0x1f
    3f88:      	cmlt.4s	v6, v4, #0
    3f8c:      	and.16b	v4, v6, v3
    3f90:      	shl.8b	v3, v21, #0x7
    3f94:      	cmlt.8b	v3, v3, #0
    3f98:      	and.8b	v3, v3, v2
    3f9c:      	addv.8b	b3, v3
    3fa0:      	fmov	w13, s3
    3fa4:      	ldp	q0, q3, [sp, #0x310]
    3fa8:      	str	q0, [sp, #0xc20]
    3fac:      	str	q3, [sp, #0xc30]
    3fb0:      	ld1r.4s	{ v3 }, [x2]
    3fb4:      	fdiv.4s	v7, v4, v3
    3fb8:      	str	q15, [sp, #0xbe0]
    3fbc:      	ldp	q0, q4, [sp, #0x3d0]
    3fc0:      	str	q0, [sp, #0xbf0]
    3fc4:      	str	q4, [sp, #0xc00]
    3fc8:      	ldr	q0, [sp, #0x3c0]
    3fcc:      	str	q0, [sp, #0xc10]
    3fd0:      	add	x9, sp, #0xbe0
    3fd4:      	ldr	x2, [x9, x1, lsl #3]
    3fd8:      	add	x17, x17, x2
    3fdc:      	csel	x17, xzr, x17, eq
    3fe0:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    3fe4:      	add	x9, x9, #0x278
    3fe8:      	add	x17, x9, x17
    3fec:      	ldp	q16, q4, [x17]
    3ff0:      	and.16b	v6, v6, v16
    3ff4:      	ldp	q16, q0, [sp, #0x2a0]
    3ff8:      	str	q0, [sp, #0xba0]
    3ffc:      	str	q16, [sp, #0xbb0]
    4000:      	ldp	q16, q0, [sp, #0x280]
    4004:      	str	q0, [sp, #0xbc0]
    4008:      	str	q16, [sp, #0xbd0]
    400c:      	add	x9, sp, #0xba0
    4010:      	ldr	x17, [x9, x1, lsl #3]
    4014:      	fmul.4s	v6, v7, v6
    4018:      	add	x17, x17, x17, lsl #12
    401c:      	str	q22, [sp, #0xb60]
    4020:      	str	q24, [sp, #0xb70]
    4024:      	str	q27, [sp, #0xb80]
    4028:      	str	q28, [sp, #0xb90]
    402c:      	add	x9, sp, #0xb60
    4030:      	ldr	x1, [x9, x1, lsl #3]
    4034:      	sub	x14, x1, x14
    4038:      	add	x14, x14, x17
    403c:      	add	x14, x3, x14, lsl #2
    4040:      	add	x14, x14, #0x4, lsl #12 ; =0x4000
    4044:      	tbz	w13, #0x0, 0x4064 <ltmp0+0x4064>
    4048:      	str	s6, [x14]
    404c:      	tbnz	w13, #0x1, 0x4068 <ltmp0+0x4068>
    4050:      	tbz	w13, #0x2, 0x4074 <ltmp0+0x4074>
    4054:      	add	x17, x14, #0x8
    4058:      	st1.s	{ v6 }[2], [x17]
    405c:      	tbnz	w13, #0x3, 0x4078 <ltmp0+0x4078>
    4060:      	b	0x4080 <ltmp0+0x4080>
    4064:      	tbz	w13, #0x1, 0x4050 <ltmp0+0x4050>
    4068:      	add	x17, x14, #0x4
    406c:      	st1.s	{ v6 }[1], [x17]
    4070:      	tbnz	w13, #0x2, 0x4054 <ltmp0+0x4054>
    4074:      	tbz	w13, #0x3, 0x4080 <ltmp0+0x4080>
    4078:      	add	x17, x14, #0xc
    407c:      	st1.s	{ v6 }[3], [x17]
    4080:      	zip2.8b	v6, v21, v0
    4084:      	ushll.4s	v6, v6, #0x0
    4088:      	shl.4s	v6, v6, #0x1f
    408c:      	cmlt.4s	v6, v6, #0
    4090:      	and.16b	v1, v6, v1
    4094:      	fdiv.4s	v1, v1, v3
    4098:      	and.16b	v3, v6, v4
    409c:      	fmul.4s	v1, v1, v3
    40a0:      	tbz	w13, #0x4, 0x40c8 <ltmp0+0x40c8>
    40a4:      	str	s1, [x14, #0x10]
    40a8:      	tbnz	w13, #0x5, 0x40cc <ltmp0+0x40cc>
    40ac:      	tbz	w13, #0x6, 0x40d8 <ltmp0+0x40d8>
    40b0:      	add	x17, x14, #0x18
    40b4:      	st1.s	{ v1 }[2], [x17]
    40b8:      	tbnz	w13, #0x7, 0x40dc <ltmp0+0x40dc>
    40bc:      	tst	w11, #0xff
    40c0:      	b.ne	0x40ec <ltmp0+0x40ec>
    40c4:      	b	0x298 <ltmp0+0x298>
    40c8:      	tbz	w13, #0x5, 0x40ac <ltmp0+0x40ac>
    40cc:      	add	x17, x14, #0x14
    40d0:      	st1.s	{ v1 }[1], [x17]
    40d4:      	tbnz	w13, #0x6, 0x40b0 <ltmp0+0x40b0>
    40d8:      	tbz	w13, #0x7, 0x40bc <ltmp0+0x40bc>
    40dc:      	add	x13, x14, #0x1c
    40e0:      	st1.s	{ v1 }[3], [x13]
    40e4:      	tst	w11, #0xff
    40e8:      	b.eq	0x298 <ltmp0+0x298>
    40ec:      	cbz	w12, 0x42b8 <ltmp0+0x42b8>
    40f0:      	mov	w11, #0x0               ; =0
    40f4:      	shl.8b	v1, v21, #0x7
    40f8:      	cmlt.8b	v1, v1, #0
    40fc:      	and.8b	v3, v1, v2
    4100:      	addv.8b	b3, v3
    4104:      	fmov	w9, s3
    4108:      	umaxv.8b	b1, v1
    410c:      	fmov	w16, s1
    4110:      	sub	w13, w12, #0x1
    4114:      	tst	w9, #0xff
    4118:      	csel	w14, w13, wzr, ne
    411c:      	lsl	w17, w20, w14
    4120:      	and	w9, w17, w10
    4124:      	tst	w9, #0xff
    4128:      	cset	w9, ne
    412c:      	ldr	q1, [sp, #0x430]
    4130:      	str	q1, [sp, #0xb40]
    4134:      	ldr	q1, [sp, #0x440]
    4138:      	str	q1, [sp, #0xb50]
    413c:      	ubfiz	x13, x14, #2, #3
    4140:      	add	x0, sp, #0xb40
    4144:      	ldr	w0, [x0, x13]
    4148:      	cmp	w0, #0x6
    414c:      	cset	w1, eq
    4150:      	and	w2, w9, w16
    4154:      	ldrb	w9, [x27, w14, sxtw]
    4158:      	and	w16, w9, #0x1
    415c:      	fmov	s1, w16
    4160:      	ubfx	w16, w9, #1, #1
    4164:      	mov.b	v1[1], w16
    4168:      	ubfx	w16, w9, #2, #1
    416c:      	mov.b	v1[2], w16
    4170:      	ubfx	w16, w9, #3, #1
    4174:      	mov.b	v1[3], w16
    4178:      	ubfx	w16, w9, #4, #1
    417c:      	mov.b	v1[4], w16
    4180:      	ubfx	w16, w9, #5, #1
    4184:      	mov.b	v1[5], w16
    4188:      	ubfx	w16, w9, #6, #1
    418c:      	mov.b	v1[6], w16
    4190:      	lsr	w9, w9, #7
    4194:      	mov.b	v1[7], w9
    4198:      	ldrb	w9, [x8, w14, sxtw]
    419c:      	and	w16, w9, #0x1
    41a0:      	fmov	s3, w16
    41a4:      	ubfx	w16, w9, #1, #1
    41a8:      	mov.b	v3[1], w16
    41ac:      	ubfx	w16, w9, #2, #1
    41b0:      	mov.b	v3[2], w16
    41b4:      	ubfx	w16, w9, #3, #1
    41b8:      	mov.b	v3[3], w16
    41bc:      	ubfx	w16, w9, #4, #1
    41c0:      	mov.b	v3[4], w16
    41c4:      	ubfx	w16, w9, #5, #1
    41c8:      	mov.b	v3[5], w16
    41cc:      	ubfx	w16, w9, #6, #1
    41d0:      	mov.b	v3[6], w16
    41d4:      	lsr	w9, w9, #7
    41d8:      	mov.b	v3[7], w9
    41dc:      	orr.8b	v4, v21, v3
    41e0:      	and.8b	v6, v9, v1
    41e4:      	eor.8b	v6, v6, v4
    41e8:      	shl.8b	v6, v6, #0x7
    41ec:      	cmlt.8b	v6, v6, #0
    41f0:      	umaxv.8b	b6, v6
    41f4:      	fmov	w9, s6
    41f8:      	ands	w16, w2, w1
    41fc:      	csetm	w0, ne
    4200:      	bics	w9, w16, w9
    4204:      	csetm	w1, ne
    4208:      	dup.8b	v6, w1
    420c:      	dup.8b	v7, w0
    4210:      	bic.8b	v16, v4, v6
    4214:      	bit.8b	v3, v16, v7
    4218:      	shl.8b	v3, v3, #0x7
    421c:      	cmlt.8b	v3, v3, #0
    4220:      	and.8b	v3, v3, v2
    4224:      	addv.8b	b3, v3
    4228:      	str	b3, [x8, w14, sxtw]
    422c:      	bic.8b	v1, v1, v6
    4230:      	shl.8b	v1, v1, #0x7
    4234:      	cmlt.8b	v1, v1, #0
    4238:      	and.8b	v1, v1, v2
    423c:      	addv.8b	b1, v1
    4240:      	str	b1, [x27, w14, sxtw]
    4244:      	csinv	w14, w5, w17, eq
    4248:      	dup.8b	v1, w16
    424c:      	and	w10, w14, w10
    4250:      	shl.8b	v1, v1, #0x7
    4254:      	cmlt.8b	v1, v1, #0
    4258:      	dup.8b	v3, w9
    425c:      	and.8b	v3, v3, v4
    4260:      	ldr	q4, [sp, #0x410]
    4264:      	str	q4, [sp, #0xb20]
    4268:      	ldr	q4, [sp, #0x420]
    426c:      	str	q4, [sp, #0xb30]
    4270:      	add	x9, sp, #0xb20
    4274:      	ldr	w9, [x9, x13]
    4278:      	csel	w12, w9, w12, ne
    427c:      	bit.8b	v21, v3, v1
    4280:      	shl.8b	v1, v21, #0x7
    4284:      	cmlt.8b	v1, v1, #0
    4288:      	and.8b	v1, v1, v2
    428c:      	addv.8b	b1, v1
    4290:      	fmov	w13, s1
    4294:      	cmp	w16, #0x1
    4298:      	b.ne	0x42cc <ltmp0+0x42cc>
    429c:      	cmp	w12, #0x0
    42a0:      	ccmp	w11, #0x6, #0x2, ne
    42a4:      	b.hi	0x42cc <ltmp0+0x42cc>
    42a8:      	add	w11, w11, #0x1
    42ac:      	tst	w13, #0xff
    42b0:      	b.ne	0x40f4 <ltmp0+0x40f4>
    42b4:      	b	0x42cc <ltmp0+0x42cc>
    42b8:      	shl.8b	v1, v21, #0x7
    42bc:      	cmlt.8b	v1, v1, #0
    42c0:      	and.8b	v1, v1, v2
    42c4:      	addv.8b	b1, v1
    42c8:      	fmov	w13, s1
    42cc:      	tst	w13, #0xff
    42d0:      	b.eq	0x3450 <ltmp0+0x3450>
    42d4:      	bic.8b	v9, v9, v21
    42d8:      	tst	w10, #0xff
    42dc:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    42e0:      	add	x0, x0, #0x150
    42e4:      	add	x16, sp, #0x1, lsl #12  ; =0x1000
    42e8:      	add	x16, x16, #0x130
    42ec:      	b.eq	0x53c0 <ltmp0+0x53c0>
    42f0:      	ldrb	w9, [x8, #0x8]
    42f4:      	and	w11, w9, #0x1
    42f8:      	fmov	s1, w11
    42fc:      	ubfx	w11, w9, #1, #1
    4300:      	mov.b	v1[1], w11
    4304:      	ubfx	w11, w9, #2, #1
    4308:      	mov.b	v1[2], w11
    430c:      	ubfx	w11, w9, #3, #1
    4310:      	mov.b	v1[3], w11
    4314:      	ubfx	w11, w9, #4, #1
    4318:      	mov.b	v1[4], w11
    431c:      	ubfx	w11, w9, #5, #1
    4320:      	mov.b	v1[5], w11
    4324:      	ubfx	w11, w9, #6, #1
    4328:      	mov.b	v1[6], w11
    432c:      	lsr	w9, w9, #7
    4330:      	mov.b	v1[7], w9
    4334:      	ldrb	w9, [x8]
    4338:      	and	w11, w9, #0x1
    433c:      	fmov	s6, w11
    4340:      	ubfx	w11, w9, #1, #1
    4344:      	mov.b	v6[1], w11
    4348:      	ubfx	w11, w9, #2, #1
    434c:      	mov.b	v6[2], w11
    4350:      	ubfx	w11, w9, #3, #1
    4354:      	mov.b	v6[3], w11
    4358:      	ubfx	w11, w9, #4, #1
    435c:      	mov.b	v6[4], w11
    4360:      	ubfx	w11, w9, #5, #1
    4364:      	mov.b	v6[5], w11
    4368:      	ubfx	w11, w9, #6, #1
    436c:      	mov.b	v6[6], w11
    4370:      	lsr	w9, w9, #7
    4374:      	mov.b	v6[7], w9
    4378:      	and.8b	v7, v9, v1
    437c:      	eor.8b	v1, v6, v7
    4380:      	shl.8b	v1, v1, #0x7
    4384:      	cmlt.8b	v3, v1, #0
    4388:      	umaxv.8b	b1, v3
    438c:      	fmov	w9, s1
    4390:      	eor	w9, w9, #0x1
    4394:      	and	w9, w10, w9
    4398:      	dup.8b	v1, w9
    439c:      	and.8b	v1, v1, v6
    43a0:      	shl.8b	v4, v1, #0x7
    43a4:      	cmlt.8b	v4, v4, #0
    43a8:      	and.8b	v4, v4, v2
    43ac:      	addv.8b	b4, v4
    43b0:      	fmov	w12, s4
    43b4:      	tst	w9, #0x1
    43b8:      	csetm	w9, ne
    43bc:      	dup.8b	v16, w9
    43c0:      	bic.8b	v7, v7, v16
    43c4:      	shl.8b	v7, v7, #0x7
    43c8:      	cmlt.8b	v7, v7, #0
    43cc:      	and.8b	v7, v7, v2
    43d0:      	addv.8b	b7, v7
    43d4:      	str	b7, [x8, #0x8]
    43d8:      	bic.8b	v6, v6, v16
    43dc:      	shl.8b	v6, v6, #0x7
    43e0:      	cmlt.8b	v6, v6, #0
    43e4:      	and.8b	v6, v6, v2
    43e8:      	addv.8b	b6, v6
    43ec:      	str	b6, [x8]
    43f0:      	cmp	w26, #0x8
    43f4:      	b.lo	0x4400 <ltmp0+0x4400>
    43f8:      	tst	w12, #0xff
    43fc:      	b.ne	0x5410 <ltmp0+0x5410>
    4400:      	and.8b	v3, v3, v2
    4404:      	addv.8b	b3, v3
    4408:      	fmov	w9, s3
    440c:      	ldr	d3, [sp, #0x48]
    4410:      	cmeq.8b	v3, v4, v3
    4414:      	mvn.8b	v3, v3
    4418:      	umov.b	w11, v3[0]
    441c:      	sbfx	w13, w11, #0, #1
    4420:      	fmov	s3, w13
    4424:      	sbfx	w13, w11, #1, #1
    4428:      	mov.b	v3[1], w13
    442c:      	sbfx	w13, w11, #2, #1
    4430:      	mov.b	v3[2], w13
    4434:      	sbfx	w13, w11, #3, #1
    4438:      	mov.b	v3[3], w13
    443c:      	sbfx	w13, w11, #4, #1
    4440:      	mov.b	v3[4], w13
    4444:      	sbfx	w13, w11, #5, #1
    4448:      	mov.b	v3[5], w13
    444c:      	sbfx	w13, w11, #6, #1
    4450:      	mov.b	v3[6], w13
    4454:      	sbfx	w11, w11, #7, #1
    4458:      	mov.b	v3[7], w11
    445c:      	and	w11, w10, #0xfffffffe
    4460:      	tst	w9, #0xff
    4464:      	csel	w11, w11, w10, eq
    4468:      	tst	w12, #0xff
    446c:      	csel	x9, x28, xzr, ne
    4470:      	ldrb	w10, [x21, x9]
    4474:      	and	w12, w10, #0x1
    4478:      	fmov	s4, w12
    447c:      	ubfx	w12, w10, #1, #1
    4480:      	mov.b	v4[1], w12
    4484:      	ubfx	w12, w10, #2, #1
    4488:      	mov.b	v4[2], w12
    448c:      	ubfx	w12, w10, #3, #1
    4490:      	mov.b	v4[3], w12
    4494:      	ubfx	w12, w10, #4, #1
    4498:      	mov.b	v4[4], w12
    449c:      	ubfx	w12, w10, #5, #1
    44a0:      	mov.b	v4[5], w12
    44a4:      	ubfx	w12, w10, #6, #1
    44a8:      	mov.b	v4[6], w12
    44ac:      	lsr	w10, w10, #7
    44b0:      	mov.b	v4[7], w10
    44b4:      	bif.8b	v1, v4, v3
    44b8:      	ldr	q3, [sp, #0x430]
    44bc:      	fmov	w10, s3
    44c0:      	adrp	x17, 0x4000 <ltmp0+0x4000>
    44c4:      	add	x17, x17, #0x0
    44c8:      	add	x10, x17, w10, sxtw #2
    44cc:      	ldr	q3, [sp, #0x410]
    44d0:      	fmov	w12, s3
    44d4:      	shl.8b	v1, v1, #0x7
    44d8:      	cmlt.8b	v1, v1, #0
    44dc:      	and.8b	v1, v1, v2
    44e0:      	addv.8b	b1, v1
    44e4:      	str	b1, [x21, x9]
    44e8:      	lsl	x9, x9, #2
    44ec:      	add	x13, x22, x9
    44f0:      	csel	x10, x10, x13, ne
    44f4:      	ldr	w10, [x10]
    44f8:      	str	w10, [x13]
    44fc:      	ldr	w10, [x23, x9]
    4500:      	csel	w10, w12, w10, ne
    4504:      	str	w10, [x23, x9]
    4508:      	csel	w10, w19, w26, ne
    450c:      	and	w9, w11, #0x2
    4510:      	ldrb	w12, [x8, #0x9]
    4514:      	and	w13, w12, #0x1
    4518:      	fmov	s1, w13
    451c:      	ubfx	w13, w12, #1, #1
    4520:      	mov.b	v1[1], w13
    4524:      	ubfx	w13, w12, #2, #1
    4528:      	mov.b	v1[2], w13
    452c:      	ubfx	w13, w12, #3, #1
    4530:      	mov.b	v1[3], w13
    4534:      	ubfx	w13, w12, #4, #1
    4538:      	mov.b	v1[4], w13
    453c:      	ubfx	w13, w12, #5, #1
    4540:      	mov.b	v1[5], w13
    4544:      	ubfx	w13, w12, #6, #1
    4548:      	mov.b	v1[6], w13
    454c:      	lsr	w12, w12, #7
    4550:      	mov.b	v1[7], w12
    4554:      	ldrb	w12, [x8, #0x1]
    4558:      	and	w13, w12, #0x1
    455c:      	fmov	s6, w13
    4560:      	ubfx	w13, w12, #1, #1
    4564:      	mov.b	v6[1], w13
    4568:      	ubfx	w13, w12, #2, #1
    456c:      	mov.b	v6[2], w13
    4570:      	ubfx	w13, w12, #3, #1
    4574:      	mov.b	v6[3], w13
    4578:      	ubfx	w13, w12, #4, #1
    457c:      	mov.b	v6[4], w13
    4580:      	ubfx	w13, w12, #5, #1
    4584:      	mov.b	v6[5], w13
    4588:      	ubfx	w13, w12, #6, #1
    458c:      	mov.b	v6[6], w13
    4590:      	lsr	w12, w12, #7
    4594:      	mov.b	v6[7], w12
    4598:      	and.8b	v7, v9, v1
    459c:      	eor.8b	v1, v6, v7
    45a0:      	shl.8b	v1, v1, #0x7
    45a4:      	cmlt.8b	v3, v1, #0
    45a8:      	umaxv.8b	b1, v3
    45ac:      	fmov	w12, s1
    45b0:      	eor	w12, w12, #0x1
    45b4:      	ands	w9, w12, w9, lsr #1
    45b8:      	dup.8b	v1, w9
    45bc:      	and.8b	v1, v1, v6
    45c0:      	shl.8b	v4, v1, #0x7
    45c4:      	cmlt.8b	v4, v4, #0
    45c8:      	and.8b	v4, v4, v2
    45cc:      	addv.8b	b4, v4
    45d0:      	fmov	w12, s4
    45d4:      	csetm	w9, ne
    45d8:      	dup.8b	v16, w9
    45dc:      	bic.8b	v7, v7, v16
    45e0:      	shl.8b	v7, v7, #0x7
    45e4:      	cmlt.8b	v7, v7, #0
    45e8:      	and.8b	v7, v7, v2
    45ec:      	addv.8b	b7, v7
    45f0:      	stur	b7, [x8, #0x9]
    45f4:      	bic.8b	v6, v6, v16
    45f8:      	shl.8b	v6, v6, #0x7
    45fc:      	cmlt.8b	v6, v6, #0
    4600:      	and.8b	v6, v6, v2
    4604:      	addv.8b	b6, v6
    4608:      	stur	b6, [x8, #0x1]
    460c:      	cmp	w10, #0x8
    4610:      	and	w9, w12, #0xff
    4614:      	ccmp	w9, #0x0, #0x4, hs
    4618:      	b.ne	0x5410 <ltmp0+0x5410>
    461c:      	and.8b	v3, v3, v2
    4620:      	ldr	d6, [sp, #0x40]
    4624:      	cmeq.8b	v4, v4, v6
    4628:      	mvn.8b	v4, v4
    462c:      	umov.b	w9, v4[0]
    4630:      	addv.8b	b4, v3
    4634:      	sbfx	w13, w9, #0, #1
    4638:      	fmov	s3, w13
    463c:      	sbfx	w13, w9, #1, #1
    4640:      	mov.b	v3[1], w13
    4644:      	sbfx	w13, w9, #2, #1
    4648:      	mov.b	v3[2], w13
    464c:      	sbfx	w13, w9, #3, #1
    4650:      	mov.b	v3[3], w13
    4654:      	sbfx	w13, w9, #4, #1
    4658:      	mov.b	v3[4], w13
    465c:      	sbfx	w13, w9, #5, #1
    4660:      	mov.b	v3[5], w13
    4664:      	sbfx	w13, w9, #6, #1
    4668:      	mov.b	v3[6], w13
    466c:      	sbfx	w9, w9, #7, #1
    4670:      	mov.b	v3[7], w9
    4674:      	fmov	w9, s4
    4678:      	and	w13, w11, #0xfffffffd
    467c:      	tst	w9, #0xff
    4680:      	csel	w9, w13, w11, eq
    4684:      	sxtw	x11, w10
    4688:      	tst	w12, #0xff
    468c:      	csel	x11, x11, xzr, ne
    4690:      	ldrb	w12, [x21, x11]
    4694:      	and	w13, w12, #0x1
    4698:      	fmov	s4, w13
    469c:      	ubfx	w13, w12, #1, #1
    46a0:      	mov.b	v4[1], w13
    46a4:      	ubfx	w13, w12, #2, #1
    46a8:      	mov.b	v4[2], w13
    46ac:      	ubfx	w13, w12, #3, #1
    46b0:      	mov.b	v4[3], w13
    46b4:      	ubfx	w13, w12, #4, #1
    46b8:      	mov.b	v4[4], w13
    46bc:      	ubfx	w13, w12, #5, #1
    46c0:      	mov.b	v4[5], w13
    46c4:      	ubfx	w13, w12, #6, #1
    46c8:      	mov.b	v4[6], w13
    46cc:      	lsr	w12, w12, #7
    46d0:      	mov.b	v4[7], w12
    46d4:      	bif.8b	v1, v4, v3
    46d8:      	ldr	q3, [sp, #0x430]
    46dc:      	mov.s	w12, v3[1]
    46e0:      	add	x12, x17, w12, sxtw #2
    46e4:      	ldr	q3, [sp, #0x410]
    46e8:      	mov.s	w13, v3[1]
    46ec:      	shl.8b	v1, v1, #0x7
    46f0:      	cmlt.8b	v1, v1, #0
    46f4:      	and.8b	v1, v1, v2
    46f8:      	addv.8b	b1, v1
    46fc:      	str	b1, [x21, x11]
    4700:      	lsl	x11, x11, #2
    4704:      	add	x14, x22, x11
    4708:      	csel	x12, x12, x14, ne
    470c:      	ldr	w12, [x12]
    4710:      	str	w12, [x14]
    4714:      	ldr	w12, [x23, x11]
    4718:      	csel	w12, w13, w12, ne
    471c:      	str	w12, [x23, x11]
    4720:      	cinc	w10, w10, ne
    4724:      	and	w11, w9, #0x4
    4728:      	ldrb	w12, [x8, #0xa]
    472c:      	and	w13, w12, #0x1
    4730:      	fmov	s1, w13
    4734:      	ubfx	w13, w12, #1, #1
    4738:      	mov.b	v1[1], w13
    473c:      	ubfx	w13, w12, #2, #1
    4740:      	mov.b	v1[2], w13
    4744:      	ubfx	w13, w12, #3, #1
    4748:      	mov.b	v1[3], w13
    474c:      	ubfx	w13, w12, #4, #1
    4750:      	mov.b	v1[4], w13
    4754:      	ubfx	w13, w12, #5, #1
    4758:      	mov.b	v1[5], w13
    475c:      	ubfx	w13, w12, #6, #1
    4760:      	mov.b	v1[6], w13
    4764:      	lsr	w12, w12, #7
    4768:      	mov.b	v1[7], w12
    476c:      	ldrb	w12, [x8, #0x2]
    4770:      	and	w13, w12, #0x1
    4774:      	fmov	s6, w13
    4778:      	ubfx	w13, w12, #1, #1
    477c:      	mov.b	v6[1], w13
    4780:      	ubfx	w13, w12, #2, #1
    4784:      	mov.b	v6[2], w13
    4788:      	ubfx	w13, w12, #3, #1
    478c:      	mov.b	v6[3], w13
    4790:      	ubfx	w13, w12, #4, #1
    4794:      	mov.b	v6[4], w13
    4798:      	ubfx	w13, w12, #5, #1
    479c:      	mov.b	v6[5], w13
    47a0:      	ubfx	w13, w12, #6, #1
    47a4:      	mov.b	v6[6], w13
    47a8:      	lsr	w12, w12, #7
    47ac:      	mov.b	v6[7], w12
    47b0:      	and.8b	v7, v9, v1
    47b4:      	eor.8b	v1, v6, v7
    47b8:      	shl.8b	v1, v1, #0x7
    47bc:      	cmlt.8b	v3, v1, #0
    47c0:      	umaxv.8b	b1, v3
    47c4:      	fmov	w12, s1
    47c8:      	eor	w12, w12, #0x1
    47cc:      	ands	w11, w12, w11, lsr #2
    47d0:      	dup.8b	v1, w11
    47d4:      	and.8b	v1, v1, v6
    47d8:      	shl.8b	v4, v1, #0x7
    47dc:      	cmlt.8b	v4, v4, #0
    47e0:      	and.8b	v4, v4, v2
    47e4:      	addv.8b	b4, v4
    47e8:      	fmov	w11, s4
    47ec:      	csetm	w12, ne
    47f0:      	dup.8b	v16, w12
    47f4:      	bic.8b	v7, v7, v16
    47f8:      	shl.8b	v7, v7, #0x7
    47fc:      	cmlt.8b	v7, v7, #0
    4800:      	and.8b	v7, v7, v2
    4804:      	addv.8b	b7, v7
    4808:      	stur	b7, [x8, #0xa]
    480c:      	bic.8b	v6, v6, v16
    4810:      	shl.8b	v6, v6, #0x7
    4814:      	cmlt.8b	v6, v6, #0
    4818:      	and.8b	v6, v6, v2
    481c:      	addv.8b	b6, v6
    4820:      	stur	b6, [x8, #0x2]
    4824:      	cmp	w10, #0x8
    4828:      	and	w12, w11, #0xff
    482c:      	ccmp	w12, #0x0, #0x4, hs
    4830:      	b.ne	0x5410 <ltmp0+0x5410>
    4834:      	and.8b	v3, v3, v2
    4838:      	ldr	d6, [sp, #0x38]
    483c:      	cmeq.8b	v4, v4, v6
    4840:      	mvn.8b	v4, v4
    4844:      	umov.b	w12, v4[0]
    4848:      	addv.8b	b4, v3
    484c:      	sbfx	w13, w12, #0, #1
    4850:      	fmov	s3, w13
    4854:      	sbfx	w13, w12, #1, #1
    4858:      	mov.b	v3[1], w13
    485c:      	sbfx	w13, w12, #2, #1
    4860:      	mov.b	v3[2], w13
    4864:      	sbfx	w13, w12, #3, #1
    4868:      	mov.b	v3[3], w13
    486c:      	sbfx	w13, w12, #4, #1
    4870:      	mov.b	v3[4], w13
    4874:      	sbfx	w13, w12, #5, #1
    4878:      	mov.b	v3[5], w13
    487c:      	sbfx	w13, w12, #6, #1
    4880:      	mov.b	v3[6], w13
    4884:      	sbfx	w12, w12, #7, #1
    4888:      	mov.b	v3[7], w12
    488c:      	fmov	w12, s4
    4890:      	and	w13, w9, #0xfffffffb
    4894:      	tst	w12, #0xff
    4898:      	csel	w9, w13, w9, eq
    489c:      	sxtw	x12, w10
    48a0:      	tst	w11, #0xff
    48a4:      	csel	x11, x12, xzr, ne
    48a8:      	ldrb	w12, [x21, x11]
    48ac:      	and	w13, w12, #0x1
    48b0:      	fmov	s4, w13
    48b4:      	ubfx	w13, w12, #1, #1
    48b8:      	mov.b	v4[1], w13
    48bc:      	ubfx	w13, w12, #2, #1
    48c0:      	mov.b	v4[2], w13
    48c4:      	ubfx	w13, w12, #3, #1
    48c8:      	mov.b	v4[3], w13
    48cc:      	ubfx	w13, w12, #4, #1
    48d0:      	mov.b	v4[4], w13
    48d4:      	ubfx	w13, w12, #5, #1
    48d8:      	mov.b	v4[5], w13
    48dc:      	ubfx	w13, w12, #6, #1
    48e0:      	mov.b	v4[6], w13
    48e4:      	lsr	w12, w12, #7
    48e8:      	mov.b	v4[7], w12
    48ec:      	bif.8b	v1, v4, v3
    48f0:      	ldr	q3, [sp, #0x430]
    48f4:      	mov.s	w12, v3[2]
    48f8:      	add	x12, x17, w12, sxtw #2
    48fc:      	ldr	q3, [sp, #0x410]
    4900:      	mov.s	w13, v3[2]
    4904:      	shl.8b	v1, v1, #0x7
    4908:      	cmlt.8b	v1, v1, #0
    490c:      	and.8b	v1, v1, v2
    4910:      	addv.8b	b1, v1
    4914:      	str	b1, [x21, x11]
    4918:      	lsl	x11, x11, #2
    491c:      	add	x14, x22, x11
    4920:      	csel	x12, x12, x14, ne
    4924:      	ldr	w12, [x12]
    4928:      	str	w12, [x14]
    492c:      	ldr	w12, [x23, x11]
    4930:      	csel	w12, w13, w12, ne
    4934:      	str	w12, [x23, x11]
    4938:      	cinc	w10, w10, ne
    493c:      	and	w11, w9, #0x8
    4940:      	ldrb	w12, [x8, #0xb]
    4944:      	and	w13, w12, #0x1
    4948:      	fmov	s1, w13
    494c:      	ubfx	w13, w12, #1, #1
    4950:      	mov.b	v1[1], w13
    4954:      	ubfx	w13, w12, #2, #1
    4958:      	mov.b	v1[2], w13
    495c:      	ubfx	w13, w12, #3, #1
    4960:      	mov.b	v1[3], w13
    4964:      	ubfx	w13, w12, #4, #1
    4968:      	mov.b	v1[4], w13
    496c:      	ubfx	w13, w12, #5, #1
    4970:      	mov.b	v1[5], w13
    4974:      	ubfx	w13, w12, #6, #1
    4978:      	mov.b	v1[6], w13
    497c:      	lsr	w12, w12, #7
    4980:      	mov.b	v1[7], w12
    4984:      	ldrb	w12, [x8, #0x3]
    4988:      	and	w13, w12, #0x1
    498c:      	fmov	s6, w13
    4990:      	ubfx	w13, w12, #1, #1
    4994:      	mov.b	v6[1], w13
    4998:      	ubfx	w13, w12, #2, #1
    499c:      	mov.b	v6[2], w13
    49a0:      	ubfx	w13, w12, #3, #1
    49a4:      	mov.b	v6[3], w13
    49a8:      	ubfx	w13, w12, #4, #1
    49ac:      	mov.b	v6[4], w13
    49b0:      	ubfx	w13, w12, #5, #1
    49b4:      	mov.b	v6[5], w13
    49b8:      	ubfx	w13, w12, #6, #1
    49bc:      	mov.b	v6[6], w13
    49c0:      	lsr	w12, w12, #7
    49c4:      	mov.b	v6[7], w12
    49c8:      	and.8b	v7, v9, v1
    49cc:      	eor.8b	v1, v6, v7
    49d0:      	shl.8b	v1, v1, #0x7
    49d4:      	cmlt.8b	v3, v1, #0
    49d8:      	umaxv.8b	b1, v3
    49dc:      	fmov	w12, s1
    49e0:      	eor	w12, w12, #0x1
    49e4:      	ands	w11, w12, w11, lsr #3
    49e8:      	dup.8b	v1, w11
    49ec:      	and.8b	v1, v1, v6
    49f0:      	shl.8b	v4, v1, #0x7
    49f4:      	cmlt.8b	v4, v4, #0
    49f8:      	and.8b	v4, v4, v2
    49fc:      	addv.8b	b4, v4
    4a00:      	fmov	w11, s4
    4a04:      	csetm	w12, ne
    4a08:      	dup.8b	v16, w12
    4a0c:      	bic.8b	v7, v7, v16
    4a10:      	shl.8b	v7, v7, #0x7
    4a14:      	cmlt.8b	v7, v7, #0
    4a18:      	and.8b	v7, v7, v2
    4a1c:      	addv.8b	b7, v7
    4a20:      	stur	b7, [x8, #0xb]
    4a24:      	bic.8b	v6, v6, v16
    4a28:      	shl.8b	v6, v6, #0x7
    4a2c:      	cmlt.8b	v6, v6, #0
    4a30:      	and.8b	v6, v6, v2
    4a34:      	addv.8b	b6, v6
    4a38:      	stur	b6, [x8, #0x3]
    4a3c:      	cmp	w10, #0x8
    4a40:      	and	w12, w11, #0xff
    4a44:      	ccmp	w12, #0x0, #0x4, hs
    4a48:      	b.ne	0x5410 <ltmp0+0x5410>
    4a4c:      	and.8b	v3, v3, v2
    4a50:      	ldr	d6, [sp, #0x30]
    4a54:      	cmeq.8b	v4, v4, v6
    4a58:      	mvn.8b	v4, v4
    4a5c:      	umov.b	w12, v4[0]
    4a60:      	addv.8b	b4, v3
    4a64:      	sbfx	w13, w12, #0, #1
    4a68:      	fmov	s3, w13
    4a6c:      	sbfx	w13, w12, #1, #1
    4a70:      	mov.b	v3[1], w13
    4a74:      	sbfx	w13, w12, #2, #1
    4a78:      	mov.b	v3[2], w13
    4a7c:      	sbfx	w13, w12, #3, #1
    4a80:      	mov.b	v3[3], w13
    4a84:      	sbfx	w13, w12, #4, #1
    4a88:      	mov.b	v3[4], w13
    4a8c:      	sbfx	w13, w12, #5, #1
    4a90:      	mov.b	v3[5], w13
    4a94:      	sbfx	w13, w12, #6, #1
    4a98:      	mov.b	v3[6], w13
    4a9c:      	sbfx	w12, w12, #7, #1
    4aa0:      	mov.b	v3[7], w12
    4aa4:      	fmov	w12, s4
    4aa8:      	and	w13, w9, #0xfffffff7
    4aac:      	tst	w12, #0xff
    4ab0:      	csel	w9, w13, w9, eq
    4ab4:      	sxtw	x12, w10
    4ab8:      	tst	w11, #0xff
    4abc:      	csel	x11, x12, xzr, ne
    4ac0:      	ldrb	w12, [x21, x11]
    4ac4:      	and	w13, w12, #0x1
    4ac8:      	fmov	s4, w13
    4acc:      	ubfx	w13, w12, #1, #1
    4ad0:      	mov.b	v4[1], w13
    4ad4:      	ubfx	w13, w12, #2, #1
    4ad8:      	mov.b	v4[2], w13
    4adc:      	ubfx	w13, w12, #3, #1
    4ae0:      	mov.b	v4[3], w13
    4ae4:      	ubfx	w13, w12, #4, #1
    4ae8:      	mov.b	v4[4], w13
    4aec:      	ubfx	w13, w12, #5, #1
    4af0:      	mov.b	v4[5], w13
    4af4:      	ubfx	w13, w12, #6, #1
    4af8:      	mov.b	v4[6], w13
    4afc:      	lsr	w12, w12, #7
    4b00:      	mov.b	v4[7], w12
    4b04:      	bif.8b	v1, v4, v3
    4b08:      	ldr	q3, [sp, #0x430]
    4b0c:      	mov.s	w12, v3[3]
    4b10:      	add	x12, x17, w12, sxtw #2
    4b14:      	ldr	q3, [sp, #0x410]
    4b18:      	mov.s	w13, v3[3]
    4b1c:      	shl.8b	v1, v1, #0x7
    4b20:      	cmlt.8b	v1, v1, #0
    4b24:      	and.8b	v1, v1, v2
    4b28:      	addv.8b	b1, v1
    4b2c:      	str	b1, [x21, x11]
    4b30:      	lsl	x11, x11, #2
    4b34:      	add	x14, x22, x11
    4b38:      	csel	x12, x12, x14, ne
    4b3c:      	ldr	w12, [x12]
    4b40:      	str	w12, [x14]
    4b44:      	ldr	w12, [x23, x11]
    4b48:      	csel	w12, w13, w12, ne
    4b4c:      	str	w12, [x23, x11]
    4b50:      	cinc	w11, w10, ne
    4b54:      	and	w10, w9, #0x10
    4b58:      	ldrb	w12, [x8, #0xc]
    4b5c:      	and	w13, w12, #0x1
    4b60:      	fmov	s1, w13
    4b64:      	ubfx	w13, w12, #1, #1
    4b68:      	mov.b	v1[1], w13
    4b6c:      	ubfx	w13, w12, #2, #1
    4b70:      	mov.b	v1[2], w13
    4b74:      	ubfx	w13, w12, #3, #1
    4b78:      	mov.b	v1[3], w13
    4b7c:      	ubfx	w13, w12, #4, #1
    4b80:      	mov.b	v1[4], w13
    4b84:      	ubfx	w13, w12, #5, #1
    4b88:      	mov.b	v1[5], w13
    4b8c:      	ubfx	w13, w12, #6, #1
    4b90:      	mov.b	v1[6], w13
    4b94:      	lsr	w12, w12, #7
    4b98:      	mov.b	v1[7], w12
    4b9c:      	ldrb	w12, [x8, #0x4]
    4ba0:      	and	w13, w12, #0x1
    4ba4:      	fmov	s6, w13
    4ba8:      	ubfx	w13, w12, #1, #1
    4bac:      	mov.b	v6[1], w13
    4bb0:      	ubfx	w13, w12, #2, #1
    4bb4:      	mov.b	v6[2], w13
    4bb8:      	ubfx	w13, w12, #3, #1
    4bbc:      	mov.b	v6[3], w13
    4bc0:      	ubfx	w13, w12, #4, #1
    4bc4:      	mov.b	v6[4], w13
    4bc8:      	ubfx	w13, w12, #5, #1
    4bcc:      	mov.b	v6[5], w13
    4bd0:      	ubfx	w13, w12, #6, #1
    4bd4:      	mov.b	v6[6], w13
    4bd8:      	lsr	w12, w12, #7
    4bdc:      	mov.b	v6[7], w12
    4be0:      	and.8b	v7, v9, v1
    4be4:      	eor.8b	v1, v6, v7
    4be8:      	shl.8b	v1, v1, #0x7
    4bec:      	cmlt.8b	v3, v1, #0
    4bf0:      	umaxv.8b	b1, v3
    4bf4:      	fmov	w12, s1
    4bf8:      	eor	w12, w12, #0x1
    4bfc:      	ands	w10, w12, w10, lsr #4
    4c00:      	dup.8b	v1, w10
    4c04:      	and.8b	v1, v1, v6
    4c08:      	shl.8b	v4, v1, #0x7
    4c0c:      	cmlt.8b	v4, v4, #0
    4c10:      	and.8b	v4, v4, v2
    4c14:      	addv.8b	b4, v4
    4c18:      	fmov	w12, s4
    4c1c:      	csetm	w10, ne
    4c20:      	dup.8b	v16, w10
    4c24:      	bic.8b	v7, v7, v16
    4c28:      	shl.8b	v7, v7, #0x7
    4c2c:      	cmlt.8b	v7, v7, #0
    4c30:      	and.8b	v7, v7, v2
    4c34:      	addv.8b	b7, v7
    4c38:      	stur	b7, [x8, #0xc]
    4c3c:      	bic.8b	v6, v6, v16
    4c40:      	shl.8b	v6, v6, #0x7
    4c44:      	cmlt.8b	v6, v6, #0
    4c48:      	and.8b	v6, v6, v2
    4c4c:      	addv.8b	b6, v6
    4c50:      	stur	b6, [x8, #0x4]
    4c54:      	cmp	w11, #0x8
    4c58:      	and	w10, w12, #0xff
    4c5c:      	ccmp	w10, #0x0, #0x4, hs
    4c60:      	b.ne	0x5410 <ltmp0+0x5410>
    4c64:      	and.8b	v3, v3, v2
    4c68:      	addv.8b	b3, v3
    4c6c:      	fmov	w10, s3
    4c70:      	ldr	d3, [sp, #0x28]
    4c74:      	cmeq.8b	v3, v4, v3
    4c78:      	mvn.8b	v3, v3
    4c7c:      	umov.b	w13, v3[0]
    4c80:      	sbfx	w14, w13, #0, #1
    4c84:      	fmov	s3, w14
    4c88:      	sbfx	w14, w13, #1, #1
    4c8c:      	mov.b	v3[1], w14
    4c90:      	sbfx	w14, w13, #2, #1
    4c94:      	mov.b	v3[2], w14
    4c98:      	sbfx	w14, w13, #3, #1
    4c9c:      	mov.b	v3[3], w14
    4ca0:      	sbfx	w14, w13, #4, #1
    4ca4:      	mov.b	v3[4], w14
    4ca8:      	sbfx	w14, w13, #5, #1
    4cac:      	mov.b	v3[5], w14
    4cb0:      	sbfx	w14, w13, #6, #1
    4cb4:      	mov.b	v3[6], w14
    4cb8:      	sbfx	w13, w13, #7, #1
    4cbc:      	mov.b	v3[7], w13
    4cc0:      	and	w13, w9, #0xffffffef
    4cc4:      	tst	w10, #0xff
    4cc8:      	csel	w10, w13, w9, eq
    4ccc:      	sxtw	x9, w11
    4cd0:      	tst	w12, #0xff
    4cd4:      	csel	x9, x9, xzr, ne
    4cd8:      	ldrb	w12, [x21, x9]
    4cdc:      	and	w13, w12, #0x1
    4ce0:      	fmov	s4, w13
    4ce4:      	ubfx	w13, w12, #1, #1
    4ce8:      	mov.b	v4[1], w13
    4cec:      	ubfx	w13, w12, #2, #1
    4cf0:      	mov.b	v4[2], w13
    4cf4:      	ubfx	w13, w12, #3, #1
    4cf8:      	mov.b	v4[3], w13
    4cfc:      	ubfx	w13, w12, #4, #1
    4d00:      	mov.b	v4[4], w13
    4d04:      	ubfx	w13, w12, #5, #1
    4d08:      	mov.b	v4[5], w13
    4d0c:      	ubfx	w13, w12, #6, #1
    4d10:      	mov.b	v4[6], w13
    4d14:      	lsr	w12, w12, #7
    4d18:      	mov.b	v4[7], w12
    4d1c:      	bif.8b	v1, v4, v3
    4d20:      	ldr	q3, [sp, #0x440]
    4d24:      	fmov	w12, s3
    4d28:      	add	x12, x17, w12, sxtw #2
    4d2c:      	ldr	q3, [sp, #0x420]
    4d30:      	fmov	w13, s3
    4d34:      	shl.8b	v1, v1, #0x7
    4d38:      	cmlt.8b	v1, v1, #0
    4d3c:      	and.8b	v1, v1, v2
    4d40:      	addv.8b	b1, v1
    4d44:      	str	b1, [x21, x9]
    4d48:      	lsl	x9, x9, #2
    4d4c:      	add	x14, x22, x9
    4d50:      	csel	x12, x12, x14, ne
    4d54:      	ldr	w12, [x12]
    4d58:      	str	w12, [x14]
    4d5c:      	ldr	w12, [x23, x9]
    4d60:      	csel	w12, w13, w12, ne
    4d64:      	str	w12, [x23, x9]
    4d68:      	cinc	w9, w11, ne
    4d6c:      	and	w11, w10, #0x20
    4d70:      	ldrb	w12, [x8, #0xd]
    4d74:      	and	w13, w12, #0x1
    4d78:      	fmov	s1, w13
    4d7c:      	ubfx	w13, w12, #1, #1
    4d80:      	mov.b	v1[1], w13
    4d84:      	ubfx	w13, w12, #2, #1
    4d88:      	mov.b	v1[2], w13
    4d8c:      	ubfx	w13, w12, #3, #1
    4d90:      	mov.b	v1[3], w13
    4d94:      	ubfx	w13, w12, #4, #1
    4d98:      	mov.b	v1[4], w13
    4d9c:      	ubfx	w13, w12, #5, #1
    4da0:      	mov.b	v1[5], w13
    4da4:      	ubfx	w13, w12, #6, #1
    4da8:      	mov.b	v1[6], w13
    4dac:      	lsr	w12, w12, #7
    4db0:      	mov.b	v1[7], w12
    4db4:      	ldrb	w12, [x8, #0x5]
    4db8:      	and	w13, w12, #0x1
    4dbc:      	fmov	s6, w13
    4dc0:      	ubfx	w13, w12, #1, #1
    4dc4:      	mov.b	v6[1], w13
    4dc8:      	ubfx	w13, w12, #2, #1
    4dcc:      	mov.b	v6[2], w13
    4dd0:      	ubfx	w13, w12, #3, #1
    4dd4:      	mov.b	v6[3], w13
    4dd8:      	ubfx	w13, w12, #4, #1
    4ddc:      	mov.b	v6[4], w13
    4de0:      	ubfx	w13, w12, #5, #1
    4de4:      	mov.b	v6[5], w13
    4de8:      	ubfx	w13, w12, #6, #1
    4dec:      	mov.b	v6[6], w13
    4df0:      	lsr	w12, w12, #7
    4df4:      	mov.b	v6[7], w12
    4df8:      	and.8b	v7, v9, v1
    4dfc:      	eor.8b	v1, v6, v7
    4e00:      	shl.8b	v1, v1, #0x7
    4e04:      	cmlt.8b	v3, v1, #0
    4e08:      	umaxv.8b	b1, v3
    4e0c:      	fmov	w12, s1
    4e10:      	eor	w12, w12, #0x1
    4e14:      	ands	w11, w12, w11, lsr #5
    4e18:      	dup.8b	v1, w11
    4e1c:      	and.8b	v1, v1, v6
    4e20:      	shl.8b	v4, v1, #0x7
    4e24:      	cmlt.8b	v4, v4, #0
    4e28:      	and.8b	v4, v4, v2
    4e2c:      	addv.8b	b4, v4
    4e30:      	fmov	w11, s4
    4e34:      	csetm	w12, ne
    4e38:      	dup.8b	v16, w12
    4e3c:      	bic.8b	v7, v7, v16
    4e40:      	shl.8b	v7, v7, #0x7
    4e44:      	cmlt.8b	v7, v7, #0
    4e48:      	and.8b	v7, v7, v2
    4e4c:      	addv.8b	b7, v7
    4e50:      	stur	b7, [x8, #0xd]
    4e54:      	bic.8b	v6, v6, v16
    4e58:      	shl.8b	v6, v6, #0x7
    4e5c:      	cmlt.8b	v6, v6, #0
    4e60:      	and.8b	v6, v6, v2
    4e64:      	addv.8b	b6, v6
    4e68:      	stur	b6, [x8, #0x5]
    4e6c:      	cmp	w9, #0x8
    4e70:      	and	w12, w11, #0xff
    4e74:      	ccmp	w12, #0x0, #0x4, hs
    4e78:      	b.ne	0x5410 <ltmp0+0x5410>
    4e7c:      	and.8b	v3, v3, v2
    4e80:      	addv.8b	b3, v3
    4e84:      	fmov	w12, s3
    4e88:      	ldr	d3, [sp, #0x20]
    4e8c:      	cmeq.8b	v3, v4, v3
    4e90:      	mvn.8b	v3, v3
    4e94:      	umov.b	w13, v3[0]
    4e98:      	sbfx	w14, w13, #0, #1
    4e9c:      	fmov	s3, w14
    4ea0:      	sbfx	w14, w13, #1, #1
    4ea4:      	mov.b	v3[1], w14
    4ea8:      	sbfx	w14, w13, #2, #1
    4eac:      	mov.b	v3[2], w14
    4eb0:      	sbfx	w14, w13, #3, #1
    4eb4:      	mov.b	v3[3], w14
    4eb8:      	sbfx	w14, w13, #4, #1
    4ebc:      	mov.b	v3[4], w14
    4ec0:      	sbfx	w14, w13, #5, #1
    4ec4:      	mov.b	v3[5], w14
    4ec8:      	sbfx	w14, w13, #6, #1
    4ecc:      	mov.b	v3[6], w14
    4ed0:      	sbfx	w13, w13, #7, #1
    4ed4:      	mov.b	v3[7], w13
    4ed8:      	and	w13, w10, #0xffffffdf
    4edc:      	tst	w12, #0xff
    4ee0:      	csel	w10, w13, w10, eq
    4ee4:      	sxtw	x12, w9
    4ee8:      	tst	w11, #0xff
    4eec:      	csel	x11, x12, xzr, ne
    4ef0:      	ldrb	w12, [x21, x11]
    4ef4:      	and	w13, w12, #0x1
    4ef8:      	fmov	s4, w13
    4efc:      	ubfx	w13, w12, #1, #1
    4f00:      	mov.b	v4[1], w13
    4f04:      	ubfx	w13, w12, #2, #1
    4f08:      	mov.b	v4[2], w13
    4f0c:      	ubfx	w13, w12, #3, #1
    4f10:      	mov.b	v4[3], w13
    4f14:      	ubfx	w13, w12, #4, #1
    4f18:      	mov.b	v4[4], w13
    4f1c:      	ubfx	w13, w12, #5, #1
    4f20:      	mov.b	v4[5], w13
    4f24:      	ubfx	w13, w12, #6, #1
    4f28:      	mov.b	v4[6], w13
    4f2c:      	lsr	w12, w12, #7
    4f30:      	mov.b	v4[7], w12
    4f34:      	ldr	q5, [sp, #0x440]
    4f38:      	mov.s	w12, v5[1]
    4f3c:      	bif.8b	v1, v4, v3
    4f40:      	add	x12, x17, w12, sxtw #2
    4f44:      	ldr	q3, [sp, #0x420]
    4f48:      	mov.s	w13, v3[1]
    4f4c:      	shl.8b	v1, v1, #0x7
    4f50:      	cmlt.8b	v1, v1, #0
    4f54:      	and.8b	v1, v1, v2
    4f58:      	addv.8b	b1, v1
    4f5c:      	str	b1, [x21, x11]
    4f60:      	lsl	x11, x11, #2
    4f64:      	add	x14, x22, x11
    4f68:      	csel	x12, x12, x14, ne
    4f6c:      	ldr	w12, [x12]
    4f70:      	str	w12, [x14]
    4f74:      	ldr	w12, [x23, x11]
    4f78:      	csel	w12, w13, w12, ne
    4f7c:      	str	w12, [x23, x11]
    4f80:      	cinc	w9, w9, ne
    4f84:      	ldrb	w11, [x8, #0xe]
    4f88:      	and	w12, w11, #0x1
    4f8c:      	fmov	s1, w12
    4f90:      	ubfx	w12, w11, #1, #1
    4f94:      	mov.b	v1[1], w12
    4f98:      	ubfx	w12, w11, #2, #1
    4f9c:      	mov.b	v1[2], w12
    4fa0:      	ubfx	w12, w11, #3, #1
    4fa4:      	mov.b	v1[3], w12
    4fa8:      	ubfx	w12, w11, #4, #1
    4fac:      	mov.b	v1[4], w12
    4fb0:      	ubfx	w12, w11, #5, #1
    4fb4:      	mov.b	v1[5], w12
    4fb8:      	ubfx	w12, w11, #6, #1
    4fbc:      	mov.b	v1[6], w12
    4fc0:      	lsr	w11, w11, #7
    4fc4:      	mov.b	v1[7], w11
    4fc8:      	ldrb	w11, [x8, #0x6]
    4fcc:      	and	w12, w11, #0x1
    4fd0:      	fmov	s6, w12
    4fd4:      	ubfx	w12, w11, #1, #1
    4fd8:      	mov.b	v6[1], w12
    4fdc:      	ubfx	w12, w11, #2, #1
    4fe0:      	mov.b	v6[2], w12
    4fe4:      	ubfx	w12, w11, #3, #1
    4fe8:      	mov.b	v6[3], w12
    4fec:      	ubfx	w12, w11, #4, #1
    4ff0:      	mov.b	v6[4], w12
    4ff4:      	ubfx	w12, w11, #5, #1
    4ff8:      	mov.b	v6[5], w12
    4ffc:      	ubfx	w12, w11, #6, #1
    5000:      	mov.b	v6[6], w12
    5004:      	and	w12, w10, #0x40
    5008:      	lsr	w11, w11, #7
    500c:      	mov.b	v6[7], w11
    5010:      	and.8b	v7, v9, v1
    5014:      	eor.8b	v1, v6, v7
    5018:      	shl.8b	v1, v1, #0x7
    501c:      	cmlt.8b	v3, v1, #0
    5020:      	umaxv.8b	b1, v3
    5024:      	fmov	w11, s1
    5028:      	eor	w11, w11, #0x1
    502c:      	ands	w11, w11, w12, lsr #6
    5030:      	dup.8b	v1, w11
    5034:      	and.8b	v1, v1, v6
    5038:      	shl.8b	v4, v1, #0x7
    503c:      	cmlt.8b	v4, v4, #0
    5040:      	and.8b	v4, v4, v2
    5044:      	addv.8b	b4, v4
    5048:      	fmov	w11, s4
    504c:      	csetm	w12, ne
    5050:      	dup.8b	v16, w12
    5054:      	bic.8b	v7, v7, v16
    5058:      	shl.8b	v7, v7, #0x7
    505c:      	cmlt.8b	v7, v7, #0
    5060:      	and.8b	v7, v7, v2
    5064:      	addv.8b	b7, v7
    5068:      	stur	b7, [x8, #0xe]
    506c:      	bic.8b	v6, v6, v16
    5070:      	shl.8b	v6, v6, #0x7
    5074:      	cmlt.8b	v6, v6, #0
    5078:      	and.8b	v6, v6, v2
    507c:      	addv.8b	b6, v6
    5080:      	stur	b6, [x8, #0x6]
    5084:      	cmp	w9, #0x8
    5088:      	b.lo	0x5094 <ltmp0+0x5094>
    508c:      	tst	w11, #0xff
    5090:      	b.ne	0x5410 <ltmp0+0x5410>
    5094:      	and.8b	v3, v3, v2
    5098:      	ldr	d6, [sp, #0x18]
    509c:      	cmeq.8b	v4, v4, v6
    50a0:      	mvn.8b	v4, v4
    50a4:      	umov.b	w12, v4[0]
    50a8:      	addv.8b	b4, v3
    50ac:      	sbfx	w13, w12, #0, #1
    50b0:      	fmov	s3, w13
    50b4:      	sbfx	w13, w12, #1, #1
    50b8:      	mov.b	v3[1], w13
    50bc:      	sbfx	w13, w12, #2, #1
    50c0:      	mov.b	v3[2], w13
    50c4:      	sbfx	w13, w12, #3, #1
    50c8:      	mov.b	v3[3], w13
    50cc:      	sbfx	w13, w12, #4, #1
    50d0:      	mov.b	v3[4], w13
    50d4:      	sbfx	w13, w12, #5, #1
    50d8:      	mov.b	v3[5], w13
    50dc:      	sbfx	w13, w12, #6, #1
    50e0:      	mov.b	v3[6], w13
    50e4:      	sbfx	w12, w12, #7, #1
    50e8:      	mov.b	v3[7], w12
    50ec:      	fmov	w12, s4
    50f0:      	and	w13, w10, #0xffffffbf
    50f4:      	tst	w12, #0xff
    50f8:      	csel	w10, w13, w10, eq
    50fc:      	sxtw	x12, w9
    5100:      	tst	w11, #0xff
    5104:      	csel	x11, x12, xzr, ne
    5108:      	ldrb	w12, [x21, x11]
    510c:      	and	w13, w12, #0x1
    5110:      	fmov	s4, w13
    5114:      	ubfx	w13, w12, #1, #1
    5118:      	mov.b	v4[1], w13
    511c:      	ubfx	w13, w12, #2, #1
    5120:      	mov.b	v4[2], w13
    5124:      	ubfx	w13, w12, #3, #1
    5128:      	mov.b	v4[3], w13
    512c:      	ubfx	w13, w12, #4, #1
    5130:      	mov.b	v4[4], w13
    5134:      	ubfx	w13, w12, #5, #1
    5138:      	mov.b	v4[5], w13
    513c:      	ubfx	w13, w12, #6, #1
    5140:      	mov.b	v4[6], w13
    5144:      	lsr	w12, w12, #7
    5148:      	mov.b	v4[7], w12
    514c:      	bif.8b	v1, v4, v3
    5150:      	ldr	q3, [sp, #0x440]
    5154:      	mov.s	w12, v3[2]
    5158:      	add	x12, x17, w12, sxtw #2
    515c:      	ldr	q3, [sp, #0x420]
    5160:      	mov.s	w13, v3[2]
    5164:      	sxtb	w10, w10
    5168:      	shl.8b	v1, v1, #0x7
    516c:      	cmlt.8b	v1, v1, #0
    5170:      	and.8b	v1, v1, v2
    5174:      	addv.8b	b1, v1
    5178:      	str	b1, [x21, x11]
    517c:      	lsl	x11, x11, #2
    5180:      	ldr	w14, [x23, x11]
    5184:      	csel	w13, w13, w14, ne
    5188:      	add	x14, x22, x11
    518c:      	csel	x12, x12, x14, ne
    5190:      	ldr	w12, [x12]
    5194:      	str	w13, [x23, x11]
    5198:      	str	w12, [x14]
    519c:      	cinc	w9, w9, ne
    51a0:      	cmp	w10, #0x0
    51a4:      	ldrb	w11, [x8, #0xf]
    51a8:      	and	w12, w11, #0x1
    51ac:      	fmov	s1, w12
    51b0:      	ubfx	w12, w11, #1, #1
    51b4:      	mov.b	v1[1], w12
    51b8:      	ubfx	w12, w11, #2, #1
    51bc:      	mov.b	v1[2], w12
    51c0:      	ubfx	w12, w11, #3, #1
    51c4:      	mov.b	v1[3], w12
    51c8:      	ubfx	w12, w11, #4, #1
    51cc:      	mov.b	v1[4], w12
    51d0:      	ubfx	w12, w11, #5, #1
    51d4:      	mov.b	v1[5], w12
    51d8:      	ubfx	w12, w11, #6, #1
    51dc:      	mov.b	v1[6], w12
    51e0:      	lsr	w11, w11, #7
    51e4:      	mov.b	v1[7], w11
    51e8:      	ldrb	w11, [x8, #0x7]
    51ec:      	and	w12, w11, #0x1
    51f0:      	fmov	s6, w12
    51f4:      	ubfx	w12, w11, #1, #1
    51f8:      	mov.b	v6[1], w12
    51fc:      	ubfx	w12, w11, #2, #1
    5200:      	mov.b	v6[2], w12
    5204:      	ubfx	w12, w11, #3, #1
    5208:      	mov.b	v6[3], w12
    520c:      	ubfx	w12, w11, #4, #1
    5210:      	mov.b	v6[4], w12
    5214:      	ubfx	w12, w11, #5, #1
    5218:      	mov.b	v6[5], w12
    521c:      	ubfx	w12, w11, #6, #1
    5220:      	mov.b	v6[6], w12
    5224:      	cset	w12, lt
    5228:      	lsr	w11, w11, #7
    522c:      	mov.b	v6[7], w11
    5230:      	and.8b	v7, v9, v1
    5234:      	eor.8b	v1, v6, v7
    5238:      	shl.8b	v1, v1, #0x7
    523c:      	cmlt.8b	v3, v1, #0
    5240:      	umaxv.8b	b1, v3
    5244:      	fmov	w11, s1
    5248:      	eor	w11, w11, #0x1
    524c:      	ands	w11, w12, w11
    5250:      	dup.8b	v1, w11
    5254:      	and.8b	v1, v1, v6
    5258:      	shl.8b	v4, v1, #0x7
    525c:      	cmlt.8b	v4, v4, #0
    5260:      	and.8b	v4, v4, v2
    5264:      	addv.8b	b4, v4
    5268:      	fmov	w11, s4
    526c:      	csetm	w12, ne
    5270:      	dup.8b	v16, w12
    5274:      	bic.8b	v7, v7, v16
    5278:      	shl.8b	v7, v7, #0x7
    527c:      	cmlt.8b	v7, v7, #0
    5280:      	and.8b	v7, v7, v2
    5284:      	addv.8b	b7, v7
    5288:      	stur	b7, [x8, #0xf]
    528c:      	bic.8b	v6, v6, v16
    5290:      	shl.8b	v6, v6, #0x7
    5294:      	cmlt.8b	v6, v6, #0
    5298:      	and.8b	v6, v6, v2
    529c:      	addv.8b	b6, v6
    52a0:      	stur	b6, [x8, #0x7]
    52a4:      	cmp	w9, #0x8
    52a8:      	b.lo	0x52b4 <ltmp0+0x52b4>
    52ac:      	tst	w11, #0xff
    52b0:      	b.ne	0x5410 <ltmp0+0x5410>
    52b4:      	and.8b	v3, v3, v2
    52b8:      	addv.8b	b6, v3
    52bc:      	ldr	d3, [sp, #0x10]
    52c0:      	cmeq.8b	v3, v4, v3
    52c4:      	mvn.8b	v3, v3
    52c8:      	umov.b	w12, v3[0]
    52cc:      	sbfx	w13, w12, #0, #1
    52d0:      	fmov	s3, w13
    52d4:      	sbfx	w13, w12, #1, #1
    52d8:      	mov.b	v3[1], w13
    52dc:      	sbfx	w13, w12, #2, #1
    52e0:      	mov.b	v3[2], w13
    52e4:      	sbfx	w13, w12, #3, #1
    52e8:      	mov.b	v3[3], w13
    52ec:      	sbfx	w13, w12, #4, #1
    52f0:      	mov.b	v3[4], w13
    52f4:      	sbfx	w13, w12, #5, #1
    52f8:      	mov.b	v3[5], w13
    52fc:      	sbfx	w13, w12, #6, #1
    5300:      	mov.b	v3[6], w13
    5304:      	fmov	w13, s6
    5308:      	sbfx	w12, w12, #7, #1
    530c:      	mov.b	v3[7], w12
    5310:      	and	w12, w10, #0x7f
    5314:      	tst	w13, #0xff
    5318:      	csel	w10, w12, w10, eq
    531c:      	sxtw	x12, w9
    5320:      	tst	w11, #0xff
    5324:      	csel	x11, x12, xzr, ne
    5328:      	ldrb	w12, [x21, x11]
    532c:      	and	w13, w12, #0x1
    5330:      	fmov	s4, w13
    5334:      	ubfx	w13, w12, #1, #1
    5338:      	mov.b	v4[1], w13
    533c:      	ubfx	w13, w12, #2, #1
    5340:      	mov.b	v4[2], w13
    5344:      	ubfx	w13, w12, #3, #1
    5348:      	mov.b	v4[3], w13
    534c:      	ubfx	w13, w12, #4, #1
    5350:      	mov.b	v4[4], w13
    5354:      	ubfx	w13, w12, #5, #1
    5358:      	mov.b	v4[5], w13
    535c:      	ubfx	w13, w12, #6, #1
    5360:      	mov.b	v4[6], w13
    5364:      	lsr	w12, w12, #7
    5368:      	mov.b	v4[7], w12
    536c:      	bif.8b	v1, v4, v3
    5370:      	ldr	q3, [sp, #0x440]
    5374:      	mov.s	w12, v3[3]
    5378:      	ldr	q3, [sp, #0x420]
    537c:      	mov.s	w13, v3[3]
    5380:      	shl.8b	v1, v1, #0x7
    5384:      	cmlt.8b	v1, v1, #0
    5388:      	and.8b	v1, v1, v2
    538c:      	addv.8b	b1, v1
    5390:      	str	b1, [x21, x11]
    5394:      	add	x12, x17, w12, sxtw #2
    5398:      	lsl	x11, x11, #2
    539c:      	add	x14, x22, x11
    53a0:      	csel	x12, x12, x14, ne
    53a4:      	ldr	w12, [x12]
    53a8:      	str	w12, [x14]
    53ac:      	ldr	w12, [x23, x11]
    53b0:      	csel	w12, w13, w12, ne
    53b4:      	str	w12, [x23, x11]
    53b8:      	cinc	w26, w9, ne
    53bc:      	b	0x298 <ltmp0+0x298>
    53c0:      	mov	w10, #0x0               ; =0
    53c4:      	b	0x298 <ltmp0+0x298>
    53c8:      	shl.8b	v0, v9, #0x7
    53cc:      	cmlt.8b	v0, v0, #0
    53d0:      	umaxv.8b	b0, v0
    53d4:      	fmov	w8, s0
    53d8:      	tbnz	w8, #0x0, 0x5410 <ltmp0+0x5410>
    53dc:      	add	sp, sp, #0x9, lsl #12   ; =0x9000
    53e0:      	add	sp, sp, #0x310
    53e4:      	ldp	x29, x30, [sp, #0x90]
    53e8:      	ldp	x20, x19, [sp, #0x80]
    53ec:      	ldp	x22, x21, [sp, #0x70]
    53f0:      	ldp	x24, x23, [sp, #0x60]
    53f4:      	ldp	x26, x25, [sp, #0x50]
    53f8:      	ldp	x28, x27, [sp, #0x40]
    53fc:      	ldp	d9, d8, [sp, #0x30]
    5400:      	ldp	d11, d10, [sp, #0x20]
    5404:      	ldp	d13, d12, [sp, #0x10]
    5408:      	ldp	d15, d14, [sp], #0xa0
    540c:      	ret
    5410:      	brk	#0x1

0000000000005414 <_llm_rows.packet_batch>:
    5414:      	stp	x26, x25, [sp, #-0x50]!
    5418:      	stp	x24, x23, [sp, #0x10]
    541c:      	stp	x22, x21, [sp, #0x20]
    5420:      	stp	x20, x19, [sp, #0x30]
    5424:      	stp	x29, x30, [sp, #0x40]
    5428:      	mov	x21, x3
    542c:      	mov	x19, x2
    5430:      	mov	x20, x0
    5434:      	ldr	w23, [x2, #0x24]
    5438:      	ldr	w8, [x2]
    543c:      	ldr	w9, [x2, #0xc]
    5440:      	lsl	x8, x8, #5
    5444:      	cmp	x8, x9
    5448:      	csel	x10, x8, xzr, ls
    544c:      	add	x10, x10, x23
    5450:      	subs	x11, x9, x10
    5454:      	mov	w12, #0x20              ; =32
    5458:      	sub	x13, x12, x23
    545c:      	cmp	x11, x13
    5460:      	csel	x11, x11, x13, lo
    5464:      	cmp	x9, x10
    5468:      	ccmp	x23, x12, #0x2, hi
    546c:      	ccmp	x8, x9, #0x2, lo
    5470:      	csel	x8, x11, xzr, ls
    5474:      	cmp	w3, #0x4
    5478:      	b.ne	0x54f0 <_llm_rows.packet_batch+0xdc>
    547c:      	cmp	x8, #0x20
    5480:      	b.lo	0x54f0 <_llm_rows.packet_batch+0xdc>
    5484:      	mov	x0, x20
    5488:      	mov	x1, x19
    548c:      	mov	w2, #0x8                ; =8
    5490:      	bl	0x5490 <_llm_rows.packet_batch+0x7c>
    5494:      	add	w8, w23, #0x8
    5498:      	str	w8, [x19, #0x24]
    549c:      	mov	x0, x20
    54a0:      	mov	x1, x19
    54a4:      	mov	w2, #0x8                ; =8
    54a8:      	bl	0x54a8 <_llm_rows.packet_batch+0x94>
    54ac:      	add	w8, w23, #0x10
    54b0:      	str	w8, [x19, #0x24]
    54b4:      	mov	x0, x20
    54b8:      	mov	x1, x19
    54bc:      	mov	w2, #0x8                ; =8
    54c0:      	bl	0x54c0 <_llm_rows.packet_batch+0xac>
    54c4:      	add	w8, w23, #0x18
    54c8:      	str	w8, [x19, #0x24]
    54cc:      	mov	x0, x20
    54d0:      	mov	x1, x19
    54d4:      	mov	w2, #0x8                ; =8
    54d8:      	ldp	x29, x30, [sp, #0x40]
    54dc:      	ldp	x20, x19, [sp, #0x30]
    54e0:      	ldp	x22, x21, [sp, #0x20]
    54e4:      	ldp	x24, x23, [sp, #0x10]
    54e8:      	ldp	x26, x25, [sp], #0x50
    54ec:      	b	0x54ec <_llm_rows.packet_batch+0xd8>
    54f0:      	ubfiz	x9, x21, #3, #32
    54f4:      	cmp	x8, x9
    54f8:      	csel	x8, x8, x9, lo
    54fc:      	lsr	x24, x8, #3
    5500:      	and	w22, w8, #0x7
    5504:      	cmp	x8, #0x8
    5508:      	b.lo	0x5534 <_llm_rows.packet_batch+0x120>
    550c:      	mov	x25, x24
    5510:      	mov	x26, x23
    5514:      	str	w26, [x19, #0x24]
    5518:      	mov	x0, x20
    551c:      	mov	x1, x19
    5520:      	mov	w2, #0x8                ; =8
    5524:      	bl	0x5524 <_llm_rows.packet_batch+0x110>
    5528:      	add	w26, w26, #0x8
    552c:      	subs	w25, w25, #0x1
    5530:      	b.ne	0x5514 <_llm_rows.packet_batch+0x100>
    5534:      	cbz	w22, 0x5550 <_llm_rows.packet_batch+0x13c>
    5538:      	add	w8, w23, w24, lsl #3
    553c:      	str	w8, [x19, #0x24]
    5540:      	mov	x0, x20
    5544:      	mov	x1, x19
    5548:      	mov	x2, x22
    554c:      	bl	0x554c <_llm_rows.packet_batch+0x138>
    5550:      	lsl	w8, w21, #3
    5554:      	sub	w8, w8, #0x8
    5558:      	cmp	w21, #0x0
    555c:      	csel	w8, wzr, w8, eq
    5560:      	add	w8, w23, w8
    5564:      	str	w8, [x19, #0x24]
    5568:      	ldp	x29, x30, [sp, #0x40]
    556c:      	ldp	x20, x19, [sp, #0x30]
    5570:      	ldp	x22, x21, [sp, #0x20]
    5574:      	ldp	x24, x23, [sp, #0x10]
    5578:      	ldp	x26, x25, [sp], #0x50
    557c:      	ret

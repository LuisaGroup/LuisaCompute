	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_1:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_2:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	32                              ; 0x20
	.quad	36                              ; 0x24
lCPI0_5:
	.quad	40                              ; 0x28
	.quad	44                              ; 0x2c
lCPI0_6:
	.quad	48                              ; 0x30
	.quad	52                              ; 0x34
lCPI0_7:
	.quad	56                              ; 0x38
	.quad	60                              ; 0x3c
lCPI0_8:
	.quad	64                              ; 0x40
	.quad	68                              ; 0x44
lCPI0_9:
	.quad	72                              ; 0x48
	.quad	76                              ; 0x4c
lCPI0_10:
	.quad	80                              ; 0x50
	.quad	84                              ; 0x54
lCPI0_11:
	.quad	88                              ; 0x58
	.quad	92                              ; 0x5c
lCPI0_12:
	.quad	96                              ; 0x60
	.quad	100                             ; 0x64
lCPI0_13:
	.quad	104                             ; 0x68
	.quad	108                             ; 0x6c
lCPI0_14:
	.quad	112                             ; 0x70
	.quad	116                             ; 0x74
lCPI0_15:
	.quad	120                             ; 0x78
	.quad	124                             ; 0x7c
lCPI0_16:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_17:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_18:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_19:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_20:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_21:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_22:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_23:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
lCPI0_24:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #1440
	str	x0, [sp, #320]                  ; 8-byte Folded Spill
	str	w3, [sp, #344]                  ; 4-byte Folded Spill
	cbz	w3, LBB0_267
; %bb.1:                                ; %block.batch.loop.preheader
	mov	w15, #0                         ; =0x0
	add	x8, sp, #1376
	add	x23, sp, #1, lsl #12            ; =4096
	add	x23, x23, #3456
	dup.2d	v0, x8
	mov	w17, #6152                      ; =0x1808
	mov	w14, #4                         ; =0x4
	adrp	x1, lCPI0_2@PAGE
	dup.2d	v1, x23
	adrp	x16, lCPI0_3@PAGE
	adrp	x4, lCPI0_5@PAGE
	adrp	x5, lCPI0_6@PAGE
	dup.2d	v2, x14
	str	q2, [sp, #304]                  ; 16-byte Folded Spill
	adrp	x6, lCPI0_7@PAGE
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
	adrp	x7, lCPI0_8@PAGE
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_1@PAGEOFF]
	adrp	x19, lCPI0_9@PAGE
	adrp	x20, lCPI0_10@PAGE
	adrp	x21, lCPI0_11@PAGE
	adrp	x22, lCPI0_12@PAGE
	adrp	x10, lCPI0_13@PAGE
	adrp	x24, lCPI0_14@PAGE
	mov	w25, #1                         ; =0x1
	movi	d12, #0000000000000000
	ldp	w9, w8, [x2, #44]
	str	w9, [sp, #340]                  ; 4-byte Folded Spill
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	ldp	w8, w9, [x2]
	ldp	w11, w12, [x2, #8]
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	str	x12, [sp, #328]                 ; 8-byte Folded Spill
	str	q3, [sp, #592]                  ; 16-byte Folded Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w8, w26, #1
	ldr	w9, [sp, #340]                  ; 4-byte Folded Reload
	cmp	w8, w9
	cset	w9, eq
	csinc	w8, wzr, w26, eq
	cinc	w11, w2, eq
	ldr	w12, [sp, #336]                 ; 4-byte Folded Reload
	cmp	w11, w12
	cset	w12, eq
	ands	w12, w9, w12
	csel	w9, wzr, w11, ne
	add	w11, w0, w12
	add	w15, w15, #1
	ldr	w12, [sp, #344]                 ; 4-byte Folded Reload
	cmp	w15, w12
	b.eq	LBB0_266
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_39 Depth 2
                                        ;       Child Loop BB0_40 Depth 3
                                        ;       Child Loop BB0_42 Depth 3
                                        ;       Child Loop BB0_44 Depth 3
                                        ;       Child Loop BB0_46 Depth 3
                                        ;     Child Loop BB0_52 Depth 2
                                        ;     Child Loop BB0_79 Depth 2
                                        ;     Child Loop BB0_145 Depth 2
                                        ;     Child Loop BB0_190 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_15 Depth 2
                                        ;     Child Loop BB0_17 Depth 2
                                        ;     Child Loop BB0_19 Depth 2
                                        ;     Child Loop BB0_21 Depth 2
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_25 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
	mov	x0, x11
	mov	x2, x9
	mov	x26, x8
	ubfiz	x8, x8, #5, #32
	ldr	x13, [sp, #328]                 ; 8-byte Folded Reload
	cmp	x8, x13
	csel	x9, x8, xzr, ls
	subs	x11, x13, x9
	cmp	x11, #32
	mov	w12, #32                        ; =0x20
	csel	x11, x11, x12, lo
	cmp	x13, x9
	ccmp	x8, x13, #2, hi
	csel	x9, x11, xzr, ls
	cmp	x9, #32
	str	w0, [sp, #356]                  ; 4-byte Folded Spill
	str	w2, [sp, #352]                  ; 4-byte Folded Spill
	str	x26, [sp, #360]                 ; 8-byte Folded Spill
	b.lo	LBB0_37
; %bb.4:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	ldr	x8, [sp, #320]                  ; 8-byte Folded Reload
	ldr	x11, [x8]
	ldr	x3, [x8, #16]
	ldr	x8, [x8, #48]
	str	x8, [sp, #608]                  ; 8-byte Folded Spill
	ubfiz	w9, w26, #2, #27
	umull	x8, w9, w17
	str	w9, [sp, #464]                  ; 4-byte Folded Spill
	umaddl	x13, w9, w17, x11
LBB0_5:                                 ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x0, x12, #5
	add	x26, x13, x0
	ldp	q2, q5, [x26]
	add	x0, x23, x0
	stp	q2, q5, [x0]
	add	x12, x12, #1
	cmp	x12, #192
	b.ne	LBB0_5
; %bb.6:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w9, #6144                       ; =0x1800
	add	x13, x8, x9
	str	x11, [sp, #480]                 ; 8-byte Folded Spill
	add	x12, x11, x13
	add	x0, x12, #4
	ldr	s5, [x12]
	ld1.s	{ v5 }[1], [x0]
	ldr	q2, [sp, #13696]
	str	q5, [sp, #672]                  ; 16-byte Folded Spill
	mov.d	v5[1], v2[1]
	str	q5, [sp, #13696]
	ldr	q2, [sp, #7552]
	ldr	q5, [sp, #7568]
	fmul.4s	v5, v5, v5
	fmul.4s	v6, v2, v2
	ldr	q2, [sp, #7584]
	ldr	q7, [sp, #7600]
	fmul.4s	v16, v7, v7
	fmul.4s	v7, v2, v2
	ldr	q2, [sp, #7616]
	ldr	q17, [sp, #7632]
	fmul.4s	v17, v17, v17
	fmul.4s	v18, v2, v2
	ldr	q2, [sp, #7648]
	ldr	q19, [sp, #7664]
	fmul.4s	v10, v19, v19
	fmul.4s	v9, v2, v2
	ldr	q14, [sp, #304]                 ; 16-byte Folded Reload
	mov.16b	v11, v14
	mov.16b	v12, v14
	mov.16b	v13, v14
	adrp	x9, lCPI0_4@PAGE
	adrp	x11, lCPI0_15@PAGE
LBB0_7:                                 ; %direct.true57.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v2, v11, #5
	add.2d	v30, v1, v2
	ldr	q2, [sp, #592]                  ; 16-byte Folded Reload
	add.2d	v21, v30, v2
	mov.d	x12, v21[1]
	shl.2d	v2, v12, #5
	add.2d	v19, v1, v2
	add.2d	v22, v19, v4
	mov.d	x0, v22[1]
	ldr	q27, [x1, lCPI0_2@PAGEOFF]
	shl.2d	v2, v13, #5
	add.2d	v15, v1, v2
	add.2d	v23, v15, v27
	mov.d	x26, v23[1]
	ldr	q20, [x16, lCPI0_3@PAGEOFF]
	shl.2d	v2, v14, #5
	add.2d	v2, v1, v2
	add.2d	v24, v2, v20
	mov.d	x27, v24[1]
	fmov	x28, d21
	ldr	s21, [x28]
	fmov	x28, d22
	fmov	x30, d23
	ld1.s	{ v21 }[1], [x12]
	fmov	x12, d24
	ld1.s	{ v21 }[2], [x28]
	ld1.s	{ v21 }[3], [x0]
	ldr	s22, [x30]
	ld1.s	{ v22 }[1], [x26]
	ld1.s	{ v22 }[2], [x12]
	ld1.s	{ v22 }[3], [x27]
	fmul.4s	v22, v22, v22
	fmul.4s	v21, v21, v21
	fadd.4s	v6, v6, v21
	fadd.4s	v5, v5, v22
	ldr	q23, [x9, lCPI0_4@PAGEOFF]
	ldr	q24, [x4, lCPI0_5@PAGEOFF]
	ldr	q28, [x5, lCPI0_6@PAGEOFF]
	ldr	q29, [x6, lCPI0_7@PAGEOFF]
	add.2d	v21, v2, v29
	add.2d	v22, v15, v28
	add.2d	v25, v19, v24
	add.2d	v26, v30, v23
	mov.d	x12, v26[1]
	fmov	x0, d26
	mov.d	x26, v25[1]
	fmov	x27, d25
	mov.d	x28, v22[1]
	fmov	x30, d22
	mov.d	x2, v21[1]
	ldr	s22, [x0]
	ld1.s	{ v22 }[1], [x12]
	ld1.s	{ v22 }[2], [x27]
	ld1.s	{ v22 }[3], [x26]
	fmov	x12, d21
	ldr	s21, [x30]
	ld1.s	{ v21 }[1], [x28]
	ld1.s	{ v21 }[2], [x12]
	ld1.s	{ v21 }[3], [x2]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	fadd.4s	v7, v7, v22
	fadd.4s	v16, v16, v21
	ldr	q26, [x7, lCPI0_8@PAGEOFF]
	ldr	q25, [x19, lCPI0_9@PAGEOFF]
	ldr	q31, [x20, lCPI0_10@PAGEOFF]
	ldr	q3, [x21, lCPI0_11@PAGEOFF]
	add.2d	v21, v2, v3
	add.2d	v22, v30, v26
	mov.d	x12, v22[1]
	fmov	x0, d22
	add.2d	v22, v19, v25
	mov.d	x2, v22[1]
	fmov	x26, d22
	add.2d	v22, v15, v31
	mov.d	x27, v22[1]
	mov.d	x28, v21[1]
	fmov	x30, d22
	ldr	s22, [x0]
	ld1.s	{ v22 }[1], [x12]
	ld1.s	{ v22 }[2], [x26]
	fmov	x12, d21
	ld1.s	{ v22 }[3], [x2]
	ldr	s21, [x30]
	ld1.s	{ v21 }[1], [x27]
	ld1.s	{ v21 }[2], [x12]
	ld1.s	{ v21 }[3], [x28]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	fadd.4s	v18, v18, v22
	fadd.4s	v17, v17, v21
	ldr	q22, [x22, lCPI0_12@PAGEOFF]
	add.2d	v21, v30, v22
	mov.d	x12, v21[1]
	ldr	q30, [x10, lCPI0_13@PAGEOFF]
	fmov	x0, d21
	ldr	q8, [x24, lCPI0_14@PAGEOFF]
	add.2d	v21, v19, v30
	mov.d	x2, v21[1]
	fmov	x26, d21
	ldr	q19, [x11, lCPI0_15@PAGEOFF]
	add.2d	v2, v2, v19
	add.2d	v21, v15, v8
	mov.d	x27, v21[1]
	fmov	x28, d21
	mov.d	x30, v2[1]
	ldr	s21, [x0]
	ld1.s	{ v21 }[1], [x12]
	fmov	x12, d2
	ld1.s	{ v21 }[2], [x26]
	ld1.s	{ v21 }[3], [x2]
	fmul.4s	v2, v21, v21
	fadd.4s	v9, v9, v2
	ldr	s2, [x28]
	ld1.s	{ v2 }[1], [x27]
	ld1.s	{ v2 }[2], [x12]
	ld1.s	{ v2 }[3], [x30]
	fmul.4s	v2, v2, v2
	fadd.4s	v10, v10, v2
	dup.2d	v2, x14
	add.2d	v13, v13, v2
	add.2d	v12, v12, v2
	add.2d	v14, v14, v2
	add.2d	v11, v11, v2
	fmov	x12, d11
	cmp	x12, #192
	b.lt	LBB0_7
; %bb.8:                                ; %direct.true85.i.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	stp	q3, q31, [sp, #560]             ; 32-byte Folded Spill
	stp	q25, q26, [sp, #624]            ; 32-byte Folded Spill
	str	q19, [sp, #496]                 ; 16-byte Folded Spill
	str	q22, [sp, #544]                 ; 16-byte Folded Spill
	stp	q24, q23, [sp, #688]            ; 32-byte Folded Spill
	mov	x12, #0                         ; =0x0
	movi.2d	v2, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v11, #0000000000000000
	mov.16b	v19, v27
	ldr	q3, [sp, #592]                  ; 16-byte Folded Reload
LBB0_9:                                 ; %direct.true85.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x3, x12, lsl #5
	ldp	q13, q12, [x12]
	shl.2d	v14, v2, #5
	shl.2d	v15, v21, #5
	shl.2d	v23, v22, #5
	shl.2d	v24, v11, #5
	add.2d	v24, v24, v20
	add.2d	v24, v0, v24
	add.2d	v23, v23, v19
	add.2d	v15, v15, v4
	add.2d	v14, v14, v3
	add.2d	v14, v0, v14
	mov.d	x12, v14[1]
	fmov	x0, d14
	str	s13, [x0]
	st1.s	{ v13 }[1], [x12]
	add.2d	v14, v0, v15
	mov.d	x12, v14[1]
	fmov	x0, d14
	st1.s	{ v13 }[2], [x0]
	add.2d	v23, v0, v23
	st1.s	{ v13 }[3], [x12]
	mov.d	x12, v23[1]
	fmov	x0, d23
	str	s12, [x0]
	st1.s	{ v12 }[1], [x12]
	mov.d	x12, v24[1]
	fmov	x0, d24
	st1.s	{ v12 }[2], [x0]
	st1.s	{ v12 }[3], [x12]
	dup.2d	v23, x25
	add.2d	v22, v22, v23
	add.2d	v21, v21, v23
	add.2d	v11, v11, v23
	add.2d	v2, v2, v23
	fmov	x12, d2
	cmp	x12, #192
	b.lt	LBB0_9
; %bb.10:                               ; %direct.false86.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	ldr	q2, [sp, #672]                  ; 16-byte Folded Reload
	fmul.4s	v2, v2, v2
	fadd.4s	v2, v2, v6
	mov.d	v2[1], v6[1]
	fadd.4s	v5, v16, v5
	fadd.4s	v2, v7, v2
	fadd.4s	v2, v18, v2
	fadd.4s	v5, v17, v5
	fadd.4s	v5, v10, v5
	fadd.4s	v2, v9, v2
	rev64.4s	v6, v2
	rev64.4s	v7, v5
	fadd.4s	v5, v5, v7
	fadd.4s	v2, v2, v6
	dup.4s	v6, v2[2]
	dup.4s	v7, v5[2]
	fadd.4s	v5, v5, v7
	fadd.4s	v2, v2, v6
	fadd.4s	v2, v2, v5
	movi	d5, #0000000000000000
	fadd	s2, s2, s5
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s5, w9
	fdiv	s5, s2, s5
	mov	w9, #6148                       ; =0x1804
	add	x0, x3, x9
	ldr	s2, [x3, #6144]
	ld1.s	{ v2 }[1], [x0]
	ldr	q6, [sp, #7520]
	mov.d	v2[1], v6[1]
	mov	w9, #6144                       ; =0x1800
	add	x9, x3, x9
	str	x9, [sp, #448]                  ; 8-byte Folded Spill
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s6, w9
	fadd	s5, s5, s6
	fsqrt	s5, s5
	dup.4s	v6, v5[0]
	str	q2, [sp, #7520]
	ldr	x11, [sp, #608]                 ; 8-byte Folded Reload
	add	x8, x11, x8
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	ldr	q27, [sp, #640]                 ; 16-byte Folded Reload
LBB0_11:                                ; %direct.true109.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v18, #5
	shl.2d	v22, v17, #5
	shl.2d	v23, v16, #5
	shl.2d	v24, v7, #5
	orr.16b	v24, v24, v3
	orr.16b	v23, v23, v4
	orr.16b	v22, v22, v19
	orr.16b	v21, v21, v20
	add.2d	v9, v1, v21
	add.2d	v10, v1, v22
	add.2d	v11, v1, v23
	add.2d	v12, v1, v24
	mov.d	x0, v12[1]
	mov.d	x2, v11[1]
	mov.d	x26, v10[1]
	fmov	x28, d12
	fmov	x30, d10
	mov.d	x9, v9[1]
	fmov	x27, d9
	ldr	s9, [x30]
	ld1.s	{ v9 }[1], [x26]
	ld1.s	{ v9 }[2], [x27]
	ld1.s	{ v9 }[3], [x9]
	fmov	x9, d11
	ldr	s10, [x28]
	ld1.s	{ v10 }[1], [x0]
	ld1.s	{ v10 }[2], [x9]
	ld1.s	{ v10 }[3], [x2]
	fdiv.4s	v10, v10, v6
	fdiv.4s	v9, v9, v6
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v24, v0, v24
	mov.d	x9, v24[1]
	fmov	x0, d24
	mov.d	x2, v23[1]
	mov.d	x26, v22[1]
	mov.d	x27, v21[1]
	fmov	x28, d23
	ldr	s23, [x0]
	ld1.s	{ v23 }[1], [x9]
	ld1.s	{ v23 }[2], [x28]
	fmov	x9, d22
	ld1.s	{ v23 }[3], [x2]
	ldr	s22, [x9]
	ld1.s	{ v22 }[1], [x26]
	fmov	x9, d21
	ld1.s	{ v22 }[2], [x9]
	ld1.s	{ v22 }[3], [x27]
	fmul.4s	v21, v9, v22
	fmul.4s	v22, v10, v23
	add	x9, x8, x12, lsl #5
	stp	q22, q21, [x9]
	dup.2d	v21, x25
	add.2d	v17, v17, v21
	add.2d	v16, v16, v21
	add.2d	v18, v18, v21
	add.2d	v7, v7, v21
	fmov	x12, d7
	cmp	x12, #192
	b.lt	LBB0_11
; %bb.12:                               ; %llm_rows.full_packet.exit.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	stp	q8, q30, [sp, #512]             ; 32-byte Folded Spill
	stp	q29, q28, [sp, #656]            ; 32-byte Folded Spill
	mov	x12, #0                         ; =0x0
	dup.2s	v5, v5[0]
	ldr	d6, [sp, #13696]
	fdiv.2s	v5, v6, v5
	fmul.2s	v2, v2, v5
	str	d2, [x11, x13]
	ldr	w8, [sp, #464]                  ; 4-byte Folded Reload
	orr	w9, w8, #0x1
	umull	x8, w9, w17
	ldr	x2, [sp, #480]                  ; 8-byte Folded Reload
	umaddl	x13, w9, w17, x2
LBB0_13:                                ; %direct.true.i8.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x9, x12, #5
	add	x0, x13, x9
	ldp	q2, q5, [x0]
	add	x9, x23, x9
	stp	q2, q5, [x9]
	add	x12, x12, #1
	cmp	x12, #192
	b.ne	LBB0_13
; %bb.14:                               ; %direct.false.i14.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w9, #6144                       ; =0x1800
	add	x13, x8, x9
	add	x9, x2, x13
	add	x12, x9, #4
	ldr	s5, [x9]
	ld1.s	{ v5 }[1], [x12]
	ldr	q2, [sp, #13696]
	str	q5, [sp, #432]                  ; 16-byte Folded Spill
	mov.d	v5[1], v2[1]
	str	q5, [sp, #13696]
	ldr	q5, [sp, #7552]
	ldr	q2, [sp, #7568]
	fmul.4s	v2, v2, v2
	fmul.4s	v10, v5, v5
	ldr	q5, [sp, #7584]
	ldr	q6, [sp, #7600]
	fmul.4s	v6, v6, v6
	fmul.4s	v5, v5, v5
	ldr	q16, [sp, #7616]
	ldr	q7, [sp, #7632]
	fmul.4s	v7, v7, v7
	fmul.4s	v16, v16, v16
	ldr	q17, [sp, #7648]
	ldr	q18, [sp, #7664]
	fmul.4s	v18, v18, v18
	fmul.4s	v17, v17, v17
	dup.2d	v11, x14
	mov.16b	v12, v11
	mov.16b	v13, v11
	mov.16b	v14, v11
	mov.16b	v30, v27
	ldp	q26, q8, [sp, #560]             ; 32-byte Folded Reload
	ldp	q28, q27, [sp, #528]            ; 32-byte Folded Reload
	ldp	q31, q29, [sp, #496]            ; 32-byte Folded Reload
LBB0_15:                                ; %direct.true57.i26.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v11, #5
	shl.2d	v22, v12, #5
	shl.2d	v23, v13, #5
	shl.2d	v24, v14, #5
	add.2d	v15, v1, v24
	add.2d	v24, v15, v20
	add.2d	v21, v1, v21
	add.2d	v25, v21, v3
	mov.d	x9, v25[1]
	add.2d	v9, v1, v23
	add.2d	v22, v1, v22
	fmov	x12, d25
	add.2d	v23, v22, v4
	mov.d	x0, v23[1]
	fmov	x2, d23
	add.2d	v23, v9, v19
	mov.d	x26, v23[1]
	fmov	x27, d23
	mov.d	x28, v24[1]
	ldr	s23, [x12]
	ld1.s	{ v23 }[1], [x9]
	fmov	x9, d24
	ld1.s	{ v23 }[2], [x2]
	ld1.s	{ v23 }[3], [x0]
	ldr	s24, [x27]
	ld1.s	{ v24 }[1], [x26]
	ld1.s	{ v24 }[2], [x9]
	ld1.s	{ v24 }[3], [x28]
	fmul.4s	v24, v24, v24
	fmul.4s	v23, v23, v23
	fadd.4s	v10, v10, v23
	fadd.4s	v2, v2, v24
	ldr	q23, [sp, #656]                 ; 16-byte Folded Reload
	add.2d	v23, v15, v23
	ldr	q24, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v24, v21, v24
	mov.d	x9, v24[1]
	fmov	x12, d24
	ldr	q24, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v24, v22, v24
	mov.d	x0, v24[1]
	fmov	x2, d24
	ldr	q24, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v24, v9, v24
	mov.d	x26, v24[1]
	mov.d	x27, v23[1]
	fmov	x28, d24
	ldr	s24, [x12]
	ld1.s	{ v24 }[1], [x9]
	ld1.s	{ v24 }[2], [x2]
	fmov	x9, d23
	ld1.s	{ v24 }[3], [x0]
	ldr	s23, [x28]
	ld1.s	{ v23 }[1], [x26]
	ld1.s	{ v23 }[2], [x9]
	ld1.s	{ v23 }[3], [x27]
	fmul.4s	v23, v23, v23
	fmul.4s	v24, v24, v24
	fadd.4s	v5, v5, v24
	fadd.4s	v6, v6, v23
	add.2d	v23, v15, v26
	add.2d	v24, v21, v30
	mov.d	x9, v24[1]
	fmov	x12, d24
	ldr	q24, [sp, #624]                 ; 16-byte Folded Reload
	add.2d	v24, v22, v24
	mov.d	x0, v24[1]
	fmov	x2, d24
	add.2d	v24, v9, v8
	mov.d	x26, v24[1]
	fmov	x27, d24
	mov.d	x28, v23[1]
	ldr	s24, [x12]
	ld1.s	{ v24 }[1], [x9]
	ld1.s	{ v24 }[2], [x2]
	ld1.s	{ v24 }[3], [x0]
	fmov	x9, d23
	fmul.4s	v23, v24, v24
	fadd.4s	v16, v16, v23
	ldr	s23, [x27]
	ld1.s	{ v23 }[1], [x26]
	ld1.s	{ v23 }[2], [x9]
	ld1.s	{ v23 }[3], [x28]
	fmul.4s	v23, v23, v23
	fadd.4s	v7, v7, v23
	add.2d	v22, v22, v28
	add.2d	v21, v21, v27
	mov.d	x9, v21[1]
	mov.d	x12, v22[1]
	fmov	x0, d21
	fmov	x2, d22
	add.2d	v21, v15, v31
	add.2d	v22, v9, v29
	mov.d	x26, v22[1]
	fmov	x27, d22
	mov.d	x28, v21[1]
	ldr	s22, [x0]
	ld1.s	{ v22 }[1], [x9]
	fmov	x9, d21
	ld1.s	{ v22 }[2], [x2]
	ld1.s	{ v22 }[3], [x12]
	fmul.4s	v21, v22, v22
	fadd.4s	v17, v17, v21
	ldr	s21, [x27]
	ld1.s	{ v21 }[1], [x26]
	ld1.s	{ v21 }[2], [x9]
	ld1.s	{ v21 }[3], [x28]
	fmul.4s	v21, v21, v21
	fadd.4s	v18, v18, v21
	dup.2d	v21, x14
	add.2d	v13, v13, v21
	add.2d	v12, v12, v21
	add.2d	v14, v14, v21
	add.2d	v11, v11, v21
	fmov	x9, d11
	cmp	x9, #192
	b.lt	LBB0_15
; %bb.16:                               ; %direct.true85.i33.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v11, #0000000000000000
LBB0_17:                                ; %direct.true85.i33.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x3, x12, lsl #5
	ldp	q24, q23, [x9]
	shl.2d	v25, v21, #5
	shl.2d	v12, v22, #5
	shl.2d	v13, v9, #5
	shl.2d	v14, v11, #5
	add.2d	v14, v14, v20
	add.2d	v14, v0, v14
	add.2d	v13, v13, v19
	add.2d	v12, v12, v4
	add.2d	v25, v25, v3
	add.2d	v25, v0, v25
	mov.d	x9, v25[1]
	fmov	x12, d25
	str	s24, [x12]
	st1.s	{ v24 }[1], [x9]
	add.2d	v25, v0, v12
	mov.d	x9, v25[1]
	fmov	x12, d25
	st1.s	{ v24 }[2], [x12]
	add.2d	v25, v0, v13
	st1.s	{ v24 }[3], [x9]
	mov.d	x9, v25[1]
	fmov	x12, d25
	str	s23, [x12]
	st1.s	{ v23 }[1], [x9]
	mov.d	x9, v14[1]
	fmov	x12, d14
	st1.s	{ v23 }[2], [x12]
	st1.s	{ v23 }[3], [x9]
	dup.2d	v23, x25
	add.2d	v9, v9, v23
	add.2d	v22, v22, v23
	add.2d	v11, v11, v23
	add.2d	v21, v21, v23
	fmov	x12, d21
	cmp	x12, #192
	b.lt	LBB0_17
; %bb.18:                               ; %direct.false86.i37.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x0, #0                          ; =0x0
	ldr	q21, [sp, #432]                 ; 16-byte Folded Reload
	fmul.4s	v21, v21, v21
	fadd.4s	v21, v21, v10
	mov.d	v21[1], v10[1]
	ldr	x12, [sp, #448]                 ; 8-byte Folded Reload
	add	x9, x12, #4
	ldr	s9, [x12]
	ld1.s	{ v9 }[1], [x9]
	fadd.4s	v2, v6, v2
	fadd.4s	v5, v5, v21
	fadd.4s	v5, v16, v5
	fadd.4s	v2, v7, v2
	fadd.4s	v2, v18, v2
	fadd.4s	v5, v17, v5
	rev64.4s	v6, v5
	rev64.4s	v7, v2
	fadd.4s	v2, v2, v7
	fadd.4s	v5, v5, v6
	dup.4s	v6, v5[2]
	dup.4s	v7, v2[2]
	fadd.4s	v2, v2, v7
	fadd.4s	v5, v5, v6
	fadd.4s	v2, v5, v2
	movi	d5, #0000000000000000
	fadd	s2, s2, s5
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s5, w9
	ldr	q6, [sp, #7520]
	mov.d	v9[1], v6[1]
	fdiv	s2, s2, s5
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s5, w9
	fadd	s2, s2, s5
	fsqrt	s2, s2
	dup.4s	v5, v2[0]
	str	q9, [sp, #7520]
	add	x8, x11, x8
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
LBB0_19:                                ; %direct.true109.i45.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v18, v17, #5
	shl.2d	v21, v16, #5
	shl.2d	v22, v7, #5
	shl.2d	v23, v6, #5
	orr.16b	v23, v23, v3
	orr.16b	v22, v22, v4
	orr.16b	v21, v21, v19
	orr.16b	v18, v18, v20
	add.2d	v24, v1, v18
	add.2d	v25, v1, v21
	add.2d	v10, v1, v22
	add.2d	v11, v1, v23
	mov.d	x9, v11[1]
	mov.d	x12, v10[1]
	mov.d	x2, v25[1]
	fmov	x26, d11
	fmov	x27, d25
	mov.d	x28, v24[1]
	fmov	x30, d24
	ldr	s24, [x27]
	ld1.s	{ v24 }[1], [x2]
	ld1.s	{ v24 }[2], [x30]
	ld1.s	{ v24 }[3], [x28]
	fmov	x2, d10
	ldr	s25, [x26]
	ld1.s	{ v25 }[1], [x9]
	ld1.s	{ v25 }[2], [x2]
	ld1.s	{ v25 }[3], [x12]
	fdiv.4s	v25, v25, v5
	fdiv.4s	v24, v24, v5
	add.2d	v18, v0, v18
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	mov.d	x9, v23[1]
	fmov	x12, d23
	mov.d	x2, v22[1]
	mov.d	x26, v21[1]
	mov.d	x27, v18[1]
	fmov	x28, d22
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x9]
	ld1.s	{ v22 }[2], [x28]
	fmov	x9, d21
	ld1.s	{ v22 }[3], [x2]
	ldr	s21, [x9]
	ld1.s	{ v21 }[1], [x26]
	fmov	x9, d18
	ld1.s	{ v21 }[2], [x9]
	ld1.s	{ v21 }[3], [x27]
	fmul.4s	v18, v24, v21
	fmul.4s	v21, v25, v22
	add	x9, x8, x0, lsl #5
	stp	q21, q18, [x9]
	dup.2d	v18, x25
	add.2d	v16, v16, v18
	add.2d	v7, v7, v18
	add.2d	v17, v17, v18
	add.2d	v6, v6, v18
	fmov	x0, d6
	cmp	x0, #192
	b.lt	LBB0_19
; %bb.20:                               ; %llm_rows.full_packet.exit51.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	dup.2s	v2, v2[0]
	ldr	d5, [sp, #13696]
	fdiv.2s	v2, v5, v2
	fmul.2s	v2, v9, v2
	str	d2, [x11, x13]
	ldr	w8, [sp, #464]                  ; 4-byte Folded Reload
	orr	w9, w8, #0x2
	umull	x8, w9, w17
	ldr	x2, [sp, #480]                  ; 8-byte Folded Reload
	umaddl	x13, w9, w17, x2
LBB0_21:                                ; %direct.true.i57.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x9, x12, #5
	add	x0, x13, x9
	ldp	q2, q5, [x0]
	add	x9, x23, x9
	stp	q2, q5, [x9]
	add	x12, x12, #1
	cmp	x12, #192
	b.ne	LBB0_21
; %bb.22:                               ; %direct.false.i63.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w9, #6144                       ; =0x1800
	add	x13, x8, x9
	add	x9, x2, x13
	add	x12, x9, #4
	ldr	s5, [x9]
	ld1.s	{ v5 }[1], [x12]
	ldr	q2, [sp, #13696]
	str	q5, [sp, #432]                  ; 16-byte Folded Spill
	mov.d	v5[1], v2[1]
	str	q5, [sp, #13696]
	ldr	q5, [sp, #7552]
	ldr	q2, [sp, #7568]
	fmul.4s	v2, v2, v2
	fmul.4s	v10, v5, v5
	ldr	q5, [sp, #7584]
	ldr	q6, [sp, #7600]
	fmul.4s	v6, v6, v6
	fmul.4s	v5, v5, v5
	ldr	q16, [sp, #7616]
	ldr	q7, [sp, #7632]
	fmul.4s	v7, v7, v7
	fmul.4s	v16, v16, v16
	ldr	q17, [sp, #7648]
	ldr	q18, [sp, #7664]
	fmul.4s	v18, v18, v18
	fmul.4s	v17, v17, v17
	dup.2d	v11, x14
	mov.16b	v12, v11
	mov.16b	v13, v11
	mov.16b	v14, v11
	ldr	q31, [sp, #624]                 ; 16-byte Folded Reload
	ldp	q26, q8, [sp, #560]             ; 32-byte Folded Reload
	ldp	q28, q27, [sp, #528]            ; 32-byte Folded Reload
	ldp	q30, q29, [sp, #496]            ; 32-byte Folded Reload
LBB0_23:                                ; %direct.true57.i75.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v11, #5
	shl.2d	v22, v12, #5
	shl.2d	v23, v13, #5
	shl.2d	v24, v14, #5
	add.2d	v15, v1, v24
	add.2d	v24, v15, v20
	add.2d	v21, v1, v21
	add.2d	v25, v21, v3
	mov.d	x9, v25[1]
	add.2d	v9, v1, v23
	add.2d	v22, v1, v22
	fmov	x12, d25
	add.2d	v23, v22, v4
	mov.d	x0, v23[1]
	fmov	x2, d23
	add.2d	v23, v9, v19
	mov.d	x26, v23[1]
	fmov	x27, d23
	mov.d	x28, v24[1]
	ldr	s23, [x12]
	ld1.s	{ v23 }[1], [x9]
	fmov	x9, d24
	ld1.s	{ v23 }[2], [x2]
	ld1.s	{ v23 }[3], [x0]
	ldr	s24, [x27]
	ld1.s	{ v24 }[1], [x26]
	ld1.s	{ v24 }[2], [x9]
	ld1.s	{ v24 }[3], [x28]
	fmul.4s	v24, v24, v24
	fmul.4s	v23, v23, v23
	fadd.4s	v10, v10, v23
	fadd.4s	v2, v2, v24
	ldr	q23, [sp, #656]                 ; 16-byte Folded Reload
	add.2d	v23, v15, v23
	ldr	q24, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v24, v21, v24
	mov.d	x9, v24[1]
	fmov	x12, d24
	ldr	q24, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v24, v22, v24
	mov.d	x0, v24[1]
	fmov	x2, d24
	ldr	q24, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v24, v9, v24
	mov.d	x26, v24[1]
	mov.d	x27, v23[1]
	fmov	x28, d24
	ldr	s24, [x12]
	ld1.s	{ v24 }[1], [x9]
	ld1.s	{ v24 }[2], [x2]
	fmov	x9, d23
	ld1.s	{ v24 }[3], [x0]
	ldr	s23, [x28]
	ld1.s	{ v23 }[1], [x26]
	ld1.s	{ v23 }[2], [x9]
	ld1.s	{ v23 }[3], [x27]
	fmul.4s	v23, v23, v23
	fmul.4s	v24, v24, v24
	fadd.4s	v5, v5, v24
	fadd.4s	v6, v6, v23
	add.2d	v23, v15, v26
	ldr	q24, [sp, #640]                 ; 16-byte Folded Reload
	add.2d	v24, v21, v24
	mov.d	x9, v24[1]
	fmov	x12, d24
	add.2d	v24, v22, v31
	mov.d	x0, v24[1]
	fmov	x2, d24
	add.2d	v24, v9, v8
	mov.d	x26, v24[1]
	fmov	x27, d24
	mov.d	x28, v23[1]
	ldr	s24, [x12]
	ld1.s	{ v24 }[1], [x9]
	ld1.s	{ v24 }[2], [x2]
	ld1.s	{ v24 }[3], [x0]
	fmov	x9, d23
	fmul.4s	v23, v24, v24
	fadd.4s	v16, v16, v23
	ldr	s23, [x27]
	ld1.s	{ v23 }[1], [x26]
	ld1.s	{ v23 }[2], [x9]
	ld1.s	{ v23 }[3], [x28]
	fmul.4s	v23, v23, v23
	fadd.4s	v7, v7, v23
	add.2d	v22, v22, v28
	add.2d	v21, v21, v27
	mov.d	x9, v21[1]
	mov.d	x12, v22[1]
	fmov	x0, d21
	fmov	x2, d22
	add.2d	v21, v15, v30
	add.2d	v22, v9, v29
	mov.d	x26, v22[1]
	fmov	x27, d22
	mov.d	x28, v21[1]
	ldr	s22, [x0]
	ld1.s	{ v22 }[1], [x9]
	fmov	x9, d21
	ld1.s	{ v22 }[2], [x2]
	ld1.s	{ v22 }[3], [x12]
	fmul.4s	v21, v22, v22
	fadd.4s	v17, v17, v21
	ldr	s21, [x27]
	ld1.s	{ v21 }[1], [x26]
	ld1.s	{ v21 }[2], [x9]
	ld1.s	{ v21 }[3], [x28]
	fmul.4s	v21, v21, v21
	fadd.4s	v18, v18, v21
	dup.2d	v21, x14
	add.2d	v13, v13, v21
	add.2d	v12, v12, v21
	add.2d	v14, v14, v21
	add.2d	v11, v11, v21
	fmov	x9, d11
	cmp	x9, #192
	b.lt	LBB0_23
; %bb.24:                               ; %direct.true85.i82.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v11, #0000000000000000
LBB0_25:                                ; %direct.true85.i82.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x3, x12, lsl #5
	ldp	q24, q23, [x9]
	shl.2d	v25, v21, #5
	shl.2d	v12, v22, #5
	shl.2d	v13, v9, #5
	shl.2d	v14, v11, #5
	add.2d	v14, v14, v20
	add.2d	v14, v0, v14
	add.2d	v13, v13, v19
	add.2d	v12, v12, v4
	add.2d	v25, v25, v3
	add.2d	v25, v0, v25
	mov.d	x9, v25[1]
	fmov	x12, d25
	str	s24, [x12]
	st1.s	{ v24 }[1], [x9]
	add.2d	v25, v0, v12
	mov.d	x9, v25[1]
	fmov	x12, d25
	st1.s	{ v24 }[2], [x12]
	add.2d	v25, v0, v13
	st1.s	{ v24 }[3], [x9]
	mov.d	x9, v25[1]
	fmov	x12, d25
	str	s23, [x12]
	st1.s	{ v23 }[1], [x9]
	mov.d	x9, v14[1]
	fmov	x12, d14
	st1.s	{ v23 }[2], [x12]
	st1.s	{ v23 }[3], [x9]
	dup.2d	v23, x25
	add.2d	v9, v9, v23
	add.2d	v22, v22, v23
	add.2d	v11, v11, v23
	add.2d	v21, v21, v23
	fmov	x12, d21
	cmp	x12, #192
	b.lt	LBB0_25
; %bb.26:                               ; %direct.false86.i86.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x0, #0                          ; =0x0
	ldr	q21, [sp, #432]                 ; 16-byte Folded Reload
	fmul.4s	v21, v21, v21
	fadd.4s	v21, v21, v10
	mov.d	v21[1], v10[1]
	ldr	x12, [sp, #448]                 ; 8-byte Folded Reload
	add	x9, x12, #4
	ldr	s9, [x12]
	ld1.s	{ v9 }[1], [x9]
	fadd.4s	v2, v6, v2
	fadd.4s	v5, v5, v21
	fadd.4s	v5, v16, v5
	fadd.4s	v2, v7, v2
	fadd.4s	v2, v18, v2
	fadd.4s	v5, v17, v5
	rev64.4s	v6, v5
	rev64.4s	v7, v2
	fadd.4s	v2, v2, v7
	fadd.4s	v5, v5, v6
	dup.4s	v6, v5[2]
	dup.4s	v7, v2[2]
	fadd.4s	v2, v2, v7
	fadd.4s	v5, v5, v6
	fadd.4s	v2, v5, v2
	movi	d5, #0000000000000000
	fadd	s2, s2, s5
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s5, w9
	ldr	q6, [sp, #7520]
	mov.d	v9[1], v6[1]
	fdiv	s2, s2, s5
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s5, w9
	fadd	s2, s2, s5
	fsqrt	s2, s2
	dup.4s	v5, v2[0]
	str	q9, [sp, #7520]
	add	x8, x11, x8
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
LBB0_27:                                ; %direct.true109.i94.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v18, v17, #5
	shl.2d	v21, v16, #5
	shl.2d	v22, v7, #5
	shl.2d	v23, v6, #5
	orr.16b	v23, v23, v3
	orr.16b	v22, v22, v4
	orr.16b	v21, v21, v19
	orr.16b	v18, v18, v20
	add.2d	v24, v1, v18
	add.2d	v25, v1, v21
	add.2d	v10, v1, v22
	add.2d	v11, v1, v23
	mov.d	x9, v11[1]
	mov.d	x12, v10[1]
	mov.d	x2, v25[1]
	fmov	x26, d11
	fmov	x27, d25
	mov.d	x28, v24[1]
	fmov	x30, d24
	ldr	s24, [x27]
	ld1.s	{ v24 }[1], [x2]
	ld1.s	{ v24 }[2], [x30]
	ld1.s	{ v24 }[3], [x28]
	fmov	x2, d10
	ldr	s25, [x26]
	ld1.s	{ v25 }[1], [x9]
	ld1.s	{ v25 }[2], [x2]
	ld1.s	{ v25 }[3], [x12]
	fdiv.4s	v25, v25, v5
	fdiv.4s	v24, v24, v5
	add.2d	v18, v0, v18
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	mov.d	x9, v23[1]
	fmov	x12, d23
	mov.d	x2, v22[1]
	mov.d	x26, v21[1]
	mov.d	x27, v18[1]
	fmov	x28, d22
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x9]
	ld1.s	{ v22 }[2], [x28]
	fmov	x9, d21
	ld1.s	{ v22 }[3], [x2]
	ldr	s21, [x9]
	ld1.s	{ v21 }[1], [x26]
	fmov	x9, d18
	ld1.s	{ v21 }[2], [x9]
	ld1.s	{ v21 }[3], [x27]
	fmul.4s	v18, v24, v21
	fmul.4s	v21, v25, v22
	add	x9, x8, x0, lsl #5
	stp	q21, q18, [x9]
	dup.2d	v18, x25
	add.2d	v16, v16, v18
	add.2d	v7, v7, v18
	add.2d	v17, v17, v18
	add.2d	v6, v6, v18
	fmov	x0, d6
	cmp	x0, #192
	b.lt	LBB0_27
; %bb.28:                               ; %llm_rows.full_packet.exit100.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	dup.2s	v2, v2[0]
	ldr	d5, [sp, #13696]
	fdiv.2s	v2, v5, v2
	fmul.2s	v2, v9, v2
	str	d2, [x11, x13]
	ldr	w8, [sp, #464]                  ; 4-byte Folded Reload
	orr	w9, w8, #0x3
	umull	x8, w9, w17
	ldr	x11, [sp, #480]                 ; 8-byte Folded Reload
	umaddl	x13, w9, w17, x11
LBB0_29:                                ; %direct.true.i106.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x9, x12, #5
	add	x0, x13, x9
	ldp	q2, q5, [x0]
	add	x9, x23, x9
	stp	q2, q5, [x9]
	add	x12, x12, #1
	cmp	x12, #192
	b.ne	LBB0_29
; %bb.30:                               ; %direct.false.i112.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w9, #6144                       ; =0x1800
	add	x13, x8, x9
	add	x9, x11, x13
	add	x11, x9, #4
	ldr	s5, [x9]
	ld1.s	{ v5 }[1], [x11]
	ldr	q2, [sp, #13696]
	str	q5, [sp, #480]                  ; 16-byte Folded Spill
	mov.d	v5[1], v2[1]
	str	q5, [sp, #13696]
	ldr	q2, [sp, #7552]
	ldr	q5, [sp, #7568]
	fmul.4s	v5, v5, v5
	fmul.4s	v6, v2, v2
	ldr	q2, [sp, #7584]
	ldr	q7, [sp, #7600]
	fmul.4s	v16, v7, v7
	fmul.4s	v7, v2, v2
	ldr	q2, [sp, #7616]
	ldr	q17, [sp, #7632]
	fmul.4s	v17, v17, v17
	fmul.4s	v18, v2, v2
	ldr	q2, [sp, #7648]
	ldr	q21, [sp, #7664]
	fmul.4s	v10, v21, v21
	fmul.4s	v9, v2, v2
	dup.2d	v11, x14
	mov.16b	v12, v11
	mov.16b	v13, v11
	mov.16b	v14, v11
	ldr	q31, [sp, #624]                 ; 16-byte Folded Reload
	ldp	q26, q8, [sp, #560]             ; 32-byte Folded Reload
	ldp	q28, q27, [sp, #528]            ; 32-byte Folded Reload
	ldp	q30, q29, [sp, #496]            ; 32-byte Folded Reload
LBB0_31:                                ; %direct.true57.i124.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v2, v11, #5
	shl.2d	v22, v12, #5
	shl.2d	v23, v13, #5
	shl.2d	v21, v14, #5
	add.2d	v15, v1, v21
	add.2d	v24, v15, v20
	add.2d	v21, v1, v2
	add.2d	v25, v21, v3
	mov.d	x9, v25[1]
	add.2d	v2, v1, v23
	add.2d	v22, v1, v22
	fmov	x11, d25
	add.2d	v23, v22, v4
	mov.d	x12, v23[1]
	fmov	x0, d23
	add.2d	v23, v2, v19
	mov.d	x2, v23[1]
	fmov	x26, d23
	mov.d	x27, v24[1]
	ldr	s23, [x11]
	ld1.s	{ v23 }[1], [x9]
	fmov	x9, d24
	ld1.s	{ v23 }[2], [x0]
	ld1.s	{ v23 }[3], [x12]
	ldr	s24, [x26]
	ld1.s	{ v24 }[1], [x2]
	ld1.s	{ v24 }[2], [x9]
	ld1.s	{ v24 }[3], [x27]
	fmul.4s	v24, v24, v24
	fmul.4s	v23, v23, v23
	fadd.4s	v6, v6, v23
	fadd.4s	v5, v5, v24
	ldr	q23, [sp, #656]                 ; 16-byte Folded Reload
	add.2d	v23, v15, v23
	ldr	q24, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v24, v21, v24
	mov.d	x9, v24[1]
	fmov	x11, d24
	ldr	q24, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v24, v22, v24
	mov.d	x12, v24[1]
	fmov	x0, d24
	ldr	q24, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v24, v2, v24
	mov.d	x2, v24[1]
	mov.d	x26, v23[1]
	fmov	x27, d24
	ldr	s24, [x11]
	ld1.s	{ v24 }[1], [x9]
	ld1.s	{ v24 }[2], [x0]
	fmov	x9, d23
	ld1.s	{ v24 }[3], [x12]
	ldr	s23, [x27]
	ld1.s	{ v23 }[1], [x2]
	ld1.s	{ v23 }[2], [x9]
	ld1.s	{ v23 }[3], [x26]
	fmul.4s	v23, v23, v23
	fmul.4s	v24, v24, v24
	fadd.4s	v7, v7, v24
	fadd.4s	v16, v16, v23
	add.2d	v23, v15, v26
	ldr	q24, [sp, #640]                 ; 16-byte Folded Reload
	add.2d	v24, v21, v24
	mov.d	x9, v24[1]
	fmov	x11, d24
	add.2d	v24, v22, v31
	mov.d	x12, v24[1]
	fmov	x0, d24
	add.2d	v24, v2, v8
	mov.d	x2, v24[1]
	fmov	x26, d24
	mov.d	x27, v23[1]
	ldr	s24, [x11]
	ld1.s	{ v24 }[1], [x9]
	ld1.s	{ v24 }[2], [x0]
	ld1.s	{ v24 }[3], [x12]
	fmov	x9, d23
	fmul.4s	v23, v24, v24
	fadd.4s	v18, v18, v23
	ldr	s23, [x26]
	ld1.s	{ v23 }[1], [x2]
	ld1.s	{ v23 }[2], [x9]
	ld1.s	{ v23 }[3], [x27]
	fmul.4s	v23, v23, v23
	fadd.4s	v17, v17, v23
	add.2d	v22, v22, v28
	add.2d	v21, v21, v27
	mov.d	x9, v21[1]
	mov.d	x11, v22[1]
	fmov	x12, d21
	fmov	x0, d22
	add.2d	v21, v15, v30
	add.2d	v2, v2, v29
	mov.d	x2, v2[1]
	fmov	x26, d2
	mov.d	x27, v21[1]
	ldr	s2, [x12]
	ld1.s	{ v2 }[1], [x9]
	fmov	x9, d21
	ld1.s	{ v2 }[2], [x0]
	ld1.s	{ v2 }[3], [x11]
	fmul.4s	v2, v2, v2
	fadd.4s	v9, v9, v2
	ldr	s2, [x26]
	ld1.s	{ v2 }[1], [x2]
	ld1.s	{ v2 }[2], [x9]
	ld1.s	{ v2 }[3], [x27]
	fmul.4s	v2, v2, v2
	fadd.4s	v10, v10, v2
	dup.2d	v2, x14
	add.2d	v13, v13, v2
	add.2d	v12, v12, v2
	add.2d	v14, v14, v2
	add.2d	v11, v11, v2
	fmov	x9, d11
	cmp	x9, #192
	b.lt	LBB0_31
; %bb.32:                               ; %direct.true85.i131.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	movi.2d	v2, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
LBB0_33:                                ; %direct.true85.i131.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x3, x11, lsl #5
	ldp	q25, q24, [x9]
	shl.2d	v26, v2, #5
	shl.2d	v27, v21, #5
	shl.2d	v28, v22, #5
	shl.2d	v29, v23, #5
	add.2d	v29, v29, v20
	add.2d	v29, v0, v29
	add.2d	v28, v28, v19
	add.2d	v27, v27, v4
	add.2d	v26, v26, v3
	add.2d	v26, v0, v26
	mov.d	x9, v26[1]
	fmov	x11, d26
	str	s25, [x11]
	st1.s	{ v25 }[1], [x9]
	add.2d	v26, v0, v27
	mov.d	x9, v26[1]
	fmov	x11, d26
	st1.s	{ v25 }[2], [x11]
	add.2d	v26, v0, v28
	st1.s	{ v25 }[3], [x9]
	mov.d	x9, v26[1]
	fmov	x11, d26
	str	s24, [x11]
	st1.s	{ v24 }[1], [x9]
	mov.d	x9, v29[1]
	fmov	x11, d29
	st1.s	{ v24 }[2], [x11]
	st1.s	{ v24 }[3], [x9]
	dup.2d	v24, x25
	add.2d	v22, v22, v24
	add.2d	v21, v21, v24
	add.2d	v23, v23, v24
	add.2d	v2, v2, v24
	fmov	x11, d2
	cmp	x11, #192
	b.lt	LBB0_33
; %bb.34:                               ; %direct.false86.i135.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	q2, [sp, #480]                  ; 16-byte Folded Reload
	fmul.4s	v2, v2, v2
	fadd.4s	v2, v2, v6
	mov.d	v2[1], v6[1]
	fadd.4s	v5, v16, v5
	fadd.4s	v2, v7, v2
	fadd.4s	v2, v18, v2
	fadd.4s	v5, v17, v5
	fadd.4s	v5, v10, v5
	fadd.4s	v2, v9, v2
	rev64.4s	v6, v2
	rev64.4s	v7, v5
	fadd.4s	v5, v5, v7
	fadd.4s	v2, v2, v6
	dup.4s	v6, v2[2]
	dup.4s	v7, v5[2]
	fadd.4s	v5, v5, v7
	fadd.4s	v2, v2, v6
	fadd.4s	v2, v2, v5
	movi	d12, #0000000000000000
	fadd	s5, s2, s12
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s6, w9
	ldr	x9, [sp, #448]                  ; 8-byte Folded Reload
	ldr	s2, [x9], #4
	ld1.s	{ v2 }[1], [x9]
	ldr	q7, [sp, #7520]
	mov.d	v2[1], v7[1]
	fdiv	s5, s5, s6
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s6, w9
	fadd	s5, s5, s6
	fsqrt	s5, s5
	dup.4s	v6, v5[0]
	str	q2, [sp, #7520]
	ldr	x9, [sp, #608]                  ; 8-byte Folded Reload
	add	x8, x9, x8
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
LBB0_35:                                ; %direct.true109.i143.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v18, #5
	shl.2d	v22, v17, #5
	shl.2d	v23, v16, #5
	shl.2d	v24, v7, #5
	orr.16b	v24, v24, v3
	orr.16b	v23, v23, v4
	orr.16b	v22, v22, v19
	orr.16b	v21, v21, v20
	add.2d	v25, v1, v21
	add.2d	v26, v1, v22
	add.2d	v27, v1, v23
	add.2d	v28, v1, v24
	mov.d	x9, v28[1]
	mov.d	x12, v27[1]
	mov.d	x0, v26[1]
	fmov	x2, d28
	fmov	x3, d26
	mov.d	x26, v25[1]
	fmov	x27, d25
	ldr	s25, [x3]
	ld1.s	{ v25 }[1], [x0]
	ld1.s	{ v25 }[2], [x27]
	ld1.s	{ v25 }[3], [x26]
	fmov	x0, d27
	ldr	s26, [x2]
	ld1.s	{ v26 }[1], [x9]
	ld1.s	{ v26 }[2], [x0]
	ld1.s	{ v26 }[3], [x12]
	fdiv.4s	v26, v26, v6
	fdiv.4s	v25, v25, v6
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v24, v0, v24
	mov.d	x9, v24[1]
	fmov	x12, d24
	mov.d	x0, v23[1]
	mov.d	x2, v22[1]
	mov.d	x3, v21[1]
	fmov	x26, d23
	ldr	s23, [x12]
	ld1.s	{ v23 }[1], [x9]
	ld1.s	{ v23 }[2], [x26]
	fmov	x9, d22
	ld1.s	{ v23 }[3], [x0]
	ldr	s22, [x9]
	ld1.s	{ v22 }[1], [x2]
	fmov	x9, d21
	ld1.s	{ v22 }[2], [x9]
	ld1.s	{ v22 }[3], [x3]
	fmul.4s	v21, v25, v22
	fmul.4s	v22, v26, v23
	add	x9, x8, x11, lsl #5
	stp	q22, q21, [x9]
	dup.2d	v21, x25
	add.2d	v17, v17, v21
	add.2d	v16, v16, v21
	add.2d	v18, v18, v21
	add.2d	v7, v7, v21
	fmov	x11, d7
	cmp	x11, #192
	b.lt	LBB0_35
; %bb.36:                               ; %llm_rows.full_packet.exit149.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.2s	v5, v5[0]
	ldr	d6, [sp, #13696]
	fdiv.2s	v5, v6, v5
	fmul.2s	v2, v2, v5
	ldr	x8, [sp, #608]                  ; 8-byte Folded Reload
	str	d2, [x8, x13]
	ldr	w0, [sp, #356]                  ; 4-byte Folded Reload
	ldr	w2, [sp, #352]                  ; 4-byte Folded Reload
	ldr	x26, [sp, #360]                 ; 8-byte Folded Reload
	b	LBB0_2
LBB0_37:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	w15, [sp, #348]                 ; 4-byte Folded Spill
	lsr	x8, x9, #3
	str	x8, [sp, #688]                  ; 8-byte Folded Spill
	str	x9, [sp, #608]                  ; 8-byte Folded Spill
	cmp	x9, #8
	b.lo	LBB0_48
; %bb.38:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x2, #0                          ; =0x0
	ldr	x8, [sp, #320]                  ; 8-byte Folded Reload
	ldr	x10, [x8]
	ldr	x27, [x8, #16]
	ldr	x13, [x8, #48]
	mov	w8, #6144                       ; =0x1800
	add	x8, x27, x8
	str	x8, [sp, #640]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #360]                  ; 8-byte Folded Reload
	lsl	w9, w8, #2
	str	x9, [sp, #624]                  ; 8-byte Folded Spill
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	and	x8, x8, #0x7ffffff
	mov	w9, #24608                      ; =0x6020
	str	x10, [sp, #672]                 ; 8-byte Folded Spill
	umaddl	x30, w8, w9, x10
	str	x13, [sp, #656]                 ; 8-byte Folded Spill
LBB0_39:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_40 Depth 3
                                        ;       Child Loop BB0_42 Depth 3
                                        ;       Child Loop BB0_44 Depth 3
                                        ;       Child Loop BB0_46 Depth 3
	mov	x20, x6
	mov	x5, x4
	mov	x12, #0                         ; =0x0
	ldr	x8, [sp, #624]                  ; 8-byte Folded Reload
	add	w8, w2, w8
	and	x8, x8, #0x1fffffff
	umull	x8, w8, w17
LBB0_40:                                ; %direct.true.i155.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x13, x12, #5
	add	x11, x30, x13
	ldp	q2, q5, [x11]
	add	x11, x23, x13
	stp	q2, q5, [x11]
	add	x12, x12, #1
	cmp	x12, #192
	b.ne	LBB0_40
; %bb.41:                               ; %direct.false.i161.i
                                        ;   in Loop: Header=BB0_39 Depth=2
	mov	w9, #6144                       ; =0x1800
	add	x10, x8, x9
	ldr	x9, [sp, #672]                  ; 8-byte Folded Reload
	str	x10, [sp, #704]                 ; 8-byte Folded Spill
	add	x11, x9, x10
	add	x12, x11, #4
	ldr	s21, [x11]
	ld1.s	{ v21 }[1], [x12]
	ldr	q2, [sp, #13696]
	mov.16b	v5, v21
	mov.d	v5[1], v2[1]
	str	q5, [sp, #13696]
	ldr	q2, [sp, #7552]
	ldr	q5, [sp, #7568]
	fmul.4s	v6, v5, v5
	fmul.4s	v22, v2, v2
	ldr	q2, [sp, #7584]
	ldr	q5, [sp, #7600]
	fmul.4s	v16, v5, v5
	fmul.4s	v7, v2, v2
	ldr	q2, [sp, #7616]
	ldr	q5, [sp, #7632]
	fmul.4s	v17, v5, v5
	fmul.4s	v18, v2, v2
	ldr	q2, [sp, #7648]
	ldr	q5, [sp, #7664]
	fmul.4s	v20, v5, v5
	fmul.4s	v19, v2, v2
	dup.2d	v23, x14
	mov.16b	v24, v23
	mov.16b	v25, v23
	mov.16b	v26, v23
	adrp	x4, lCPI0_4@PAGE
	mov	x16, x5
	adrp	x6, lCPI0_3@PAGE
	adrp	x7, lCPI0_6@PAGE
	mov	x19, x20
	adrp	x21, lCPI0_8@PAGE
	adrp	x22, lCPI0_9@PAGE
	adrp	x23, lCPI0_10@PAGE
	adrp	x24, lCPI0_11@PAGE
	adrp	x26, lCPI0_12@PAGE
	mov	w13, #4                         ; =0x4
	adrp	x14, lCPI0_13@PAGE
	adrp	x10, lCPI0_14@PAGE
	adrp	x0, lCPI0_15@PAGE
LBB0_42:                                ; %direct.true57.i173.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.2d	v2, v23, #5
	add.2d	v27, v1, v2
	add.2d	v31, v27, v3
	mov.d	x11, v31[1]
	shl.2d	v2, v24, #5
	add.2d	v28, v1, v2
	add.2d	v8, v28, v4
	mov.d	x12, v8[1]
	ldr	q2, [x1, lCPI0_2@PAGEOFF]
	shl.2d	v5, v25, #5
	add.2d	v29, v1, v5
	add.2d	v9, v29, v2
	mov.d	x9, v9[1]
	ldr	q5, [x6, lCPI0_3@PAGEOFF]
	shl.2d	v30, v26, #5
	add.2d	v30, v1, v30
	add.2d	v10, v30, v5
	mov.d	x28, v10[1]
	fmov	x3, d31
	ldr	s31, [x3]
	fmov	x3, d8
	fmov	x17, d9
	ld1.s	{ v31 }[1], [x11]
	fmov	x11, d10
	ld1.s	{ v31 }[2], [x3]
	ld1.s	{ v31 }[3], [x12]
	ldr	s8, [x17]
	ld1.s	{ v8 }[1], [x9]
	ld1.s	{ v8 }[2], [x11]
	ld1.s	{ v8 }[3], [x28]
	fmul.4s	v8, v8, v8
	fmul.4s	v31, v31, v31
	fadd.4s	v22, v22, v31
	fadd.4s	v6, v6, v8
	ldr	q31, [x4, lCPI0_4@PAGEOFF]
	ldr	q8, [x16, lCPI0_5@PAGEOFF]
	ldr	q9, [x7, lCPI0_6@PAGEOFF]
	ldr	q10, [x19, lCPI0_7@PAGEOFF]
	add.2d	v10, v30, v10
	add.2d	v9, v29, v9
	add.2d	v8, v28, v8
	add.2d	v31, v27, v31
	mov.d	x9, v31[1]
	fmov	x11, d31
	mov.d	x12, v8[1]
	fmov	x17, d8
	mov.d	x3, v9[1]
	fmov	x28, d9
	mov.d	x15, v10[1]
	ldr	s31, [x11]
	ld1.s	{ v31 }[1], [x9]
	ld1.s	{ v31 }[2], [x17]
	ld1.s	{ v31 }[3], [x12]
	fmov	x9, d10
	ldr	s8, [x28]
	ld1.s	{ v8 }[1], [x3]
	ld1.s	{ v8 }[2], [x9]
	ld1.s	{ v8 }[3], [x15]
	fmul.4s	v8, v8, v8
	fmul.4s	v31, v31, v31
	fadd.4s	v7, v7, v31
	fadd.4s	v16, v16, v8
	ldr	q31, [x21, lCPI0_8@PAGEOFF]
	ldr	q8, [x22, lCPI0_9@PAGEOFF]
	ldr	q9, [x23, lCPI0_10@PAGEOFF]
	ldr	q10, [x24, lCPI0_11@PAGEOFF]
	add.2d	v10, v30, v10
	add.2d	v9, v29, v9
	add.2d	v8, v28, v8
	add.2d	v31, v27, v31
	mov.d	x9, v31[1]
	mov.d	x11, v8[1]
	fmov	x12, d31
	fmov	x15, d8
	mov.d	x17, v9[1]
	mov.d	x3, v10[1]
	fmov	x28, d9
	ldr	s31, [x12]
	ld1.s	{ v31 }[1], [x9]
	ld1.s	{ v31 }[2], [x15]
	fmov	x9, d10
	ld1.s	{ v31 }[3], [x11]
	ldr	s8, [x28]
	ld1.s	{ v8 }[1], [x17]
	ld1.s	{ v8 }[2], [x9]
	ld1.s	{ v8 }[3], [x3]
	fmul.4s	v8, v8, v8
	fmul.4s	v31, v31, v31
	fadd.4s	v18, v18, v31
	fadd.4s	v17, v17, v8
	ldr	q31, [x26, lCPI0_12@PAGEOFF]
	ldr	q8, [x14, lCPI0_13@PAGEOFF]
	ldr	q9, [x10, lCPI0_14@PAGEOFF]
	ldr	q10, [x0, lCPI0_15@PAGEOFF]
	add.2d	v30, v30, v10
	add.2d	v29, v29, v9
	add.2d	v28, v28, v8
	add.2d	v27, v27, v31
	mov.d	x9, v27[1]
	fmov	x11, d27
	mov.d	x12, v28[1]
	fmov	x15, d28
	mov.d	x17, v29[1]
	fmov	x3, d29
	mov.d	x28, v30[1]
	ldr	s27, [x11]
	ld1.s	{ v27 }[1], [x9]
	fmov	x9, d30
	ld1.s	{ v27 }[2], [x15]
	ld1.s	{ v27 }[3], [x12]
	ldr	s28, [x3]
	ld1.s	{ v28 }[1], [x17]
	ld1.s	{ v28 }[2], [x9]
	ld1.s	{ v28 }[3], [x28]
	fmul.4s	v28, v28, v28
	fmul.4s	v27, v27, v27
	fadd.4s	v19, v19, v27
	fadd.4s	v20, v20, v28
	dup.2d	v27, x13
	add.2d	v25, v25, v27
	add.2d	v24, v24, v27
	add.2d	v26, v26, v27
	add.2d	v23, v23, v27
	fmov	x9, d23
	cmp	x9, #192
	b.lt	LBB0_42
; %bb.43:                               ; %direct.true85.i180.i.preheader
                                        ;   in Loop: Header=BB0_39 Depth=2
	mov	x12, #0                         ; =0x0
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
LBB0_44:                                ; %direct.true85.i180.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x27, x12, lsl #5
	ldp	q28, q27, [x9]
	shl.2d	v29, v23, #5
	shl.2d	v30, v24, #5
	shl.2d	v31, v25, #5
	shl.2d	v8, v26, #5
	add.2d	v8, v8, v5
	add.2d	v8, v0, v8
	add.2d	v31, v31, v2
	add.2d	v30, v30, v4
	add.2d	v29, v29, v3
	add.2d	v29, v0, v29
	mov.d	x9, v29[1]
	fmov	x11, d29
	str	s28, [x11]
	st1.s	{ v28 }[1], [x9]
	add.2d	v29, v0, v30
	mov.d	x9, v29[1]
	fmov	x11, d29
	st1.s	{ v28 }[2], [x11]
	add.2d	v29, v0, v31
	st1.s	{ v28 }[3], [x9]
	mov.d	x9, v29[1]
	fmov	x11, d29
	str	s27, [x11]
	st1.s	{ v27 }[1], [x9]
	mov.d	x9, v8[1]
	fmov	x11, d8
	st1.s	{ v27 }[2], [x11]
	st1.s	{ v27 }[3], [x9]
	dup.2d	v27, x25
	add.2d	v25, v25, v27
	add.2d	v24, v24, v27
	add.2d	v26, v26, v27
	add.2d	v23, v23, v27
	fmov	x12, d23
	cmp	x12, #192
	b.lt	LBB0_44
; %bb.45:                               ; %direct.false86.i184.i
                                        ;   in Loop: Header=BB0_39 Depth=2
	mov	x12, #0                         ; =0x0
	fmul.4s	v21, v21, v21
	fadd.4s	v23, v21, v22
	mov.d	v23[1], v22[1]
	ldr	x10, [sp, #640]                 ; 8-byte Folded Reload
	add	x9, x10, #4
	ldr	s21, [x10]
	ld1.s	{ v21 }[1], [x9]
	fadd.4s	v6, v16, v6
	fadd.4s	v7, v7, v23
	fadd.4s	v7, v18, v7
	fadd.4s	v6, v17, v6
	fadd.4s	v6, v20, v6
	fadd.4s	v7, v19, v7
	rev64.4s	v16, v7
	rev64.4s	v17, v6
	fadd.4s	v6, v6, v17
	fadd.4s	v7, v7, v16
	dup.4s	v16, v7[2]
	dup.4s	v17, v6[2]
	fadd.4s	v6, v6, v17
	fadd.4s	v7, v7, v16
	fadd.4s	v6, v7, v6
	fadd	s6, s6, s12
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s7, w9
	ldr	q16, [sp, #7520]
	mov.d	v21[1], v16[1]
	fdiv	s6, s6, s7
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s7, w9
	fadd	s6, s6, s7
	fsqrt	s6, s6
	dup.4s	v7, v6[0]
	str	q21, [sp, #7520]
	ldr	x13, [sp, #656]                 ; 8-byte Folded Reload
	add	x8, x13, x8
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	mov	x4, x5
	mov	x6, x20
	adrp	x21, lCPI0_11@PAGE
	adrp	x22, lCPI0_12@PAGE
	add	x23, sp, #1, lsl #12            ; =4096
	add	x23, x23, #3456
	mov	w14, #4                         ; =0x4
	adrp	x24, lCPI0_14@PAGE
LBB0_46:                                ; %direct.true109.i192.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.2d	v20, v19, #5
	shl.2d	v22, v18, #5
	shl.2d	v23, v17, #5
	shl.2d	v24, v16, #5
	orr.16b	v24, v24, v3
	orr.16b	v23, v23, v4
	orr.16b	v22, v22, v2
	orr.16b	v20, v20, v5
	add.2d	v25, v1, v20
	add.2d	v26, v1, v22
	add.2d	v27, v1, v23
	add.2d	v28, v1, v24
	mov.d	x9, v28[1]
	mov.d	x11, v27[1]
	mov.d	x15, v26[1]
	fmov	x17, d28
	fmov	x3, d26
	mov.d	x28, v25[1]
	fmov	x1, d25
	ldr	s25, [x3]
	ld1.s	{ v25 }[1], [x15]
	ld1.s	{ v25 }[2], [x1]
	ld1.s	{ v25 }[3], [x28]
	fmov	x15, d27
	ldr	s26, [x17]
	ld1.s	{ v26 }[1], [x9]
	ld1.s	{ v26 }[2], [x15]
	ld1.s	{ v26 }[3], [x11]
	fdiv.4s	v26, v26, v7
	fdiv.4s	v25, v25, v7
	add.2d	v20, v0, v20
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v24, v0, v24
	mov.d	x9, v24[1]
	fmov	x11, d24
	mov.d	x15, v23[1]
	mov.d	x17, v22[1]
	mov.d	x1, v20[1]
	fmov	x3, d23
	ldr	s23, [x11]
	ld1.s	{ v23 }[1], [x9]
	ld1.s	{ v23 }[2], [x3]
	fmov	x9, d22
	ld1.s	{ v23 }[3], [x15]
	ldr	s22, [x9]
	ld1.s	{ v22 }[1], [x17]
	fmov	x9, d20
	ld1.s	{ v22 }[2], [x9]
	ld1.s	{ v22 }[3], [x1]
	fmul.4s	v20, v25, v22
	fmul.4s	v22, v26, v23
	add	x9, x8, x12, lsl #5
	stp	q22, q20, [x9]
	dup.2d	v20, x25
	add.2d	v18, v18, v20
	add.2d	v17, v17, v20
	add.2d	v19, v19, v20
	add.2d	v16, v16, v20
	fmov	x12, d16
	cmp	x12, #192
	b.lt	LBB0_46
; %bb.47:                               ; %llm_rows.full_packet.exit198.i
                                        ;   in Loop: Header=BB0_39 Depth=2
	dup.2s	v2, v6[0]
	ldr	d5, [sp, #13696]
	fdiv.2s	v2, v5, v2
	fmul.2s	v2, v21, v2
	ldr	x8, [sp, #704]                  ; 8-byte Folded Reload
	str	d2, [x13, x8]
	add	x2, x2, #1
	mov	w17, #6152                      ; =0x1808
	add	x30, x30, x17
	ldr	x8, [sp, #688]                  ; 8-byte Folded Reload
	cmp	x2, x8
	adrp	x1, lCPI0_2@PAGE
	b.ne	LBB0_39
LBB0_48:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #608]                  ; 8-byte Folded Reload
	and	w8, w8, #0x7
	ldr	w15, [sp, #348]                 ; 4-byte Folded Reload
	adrp	x16, lCPI0_3@PAGE
	adrp	x5, lCPI0_6@PAGE
	adrp	x7, lCPI0_8@PAGE
	adrp	x19, lCPI0_9@PAGE
	adrp	x20, lCPI0_10@PAGE
	adrp	x10, lCPI0_13@PAGE
	ldr	w0, [sp, #356]                  ; 4-byte Folded Reload
	ldr	w2, [sp, #352]                  ; 4-byte Folded Reload
	ldr	x26, [sp, #360]                 ; 8-byte Folded Reload
	cbz	w8, LBB0_2
; %bb.49:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v2, w8
Lloh4:
	adrp	x8, lCPI0_17@PAGE
Lloh5:
	ldr	q5, [x8, lCPI0_17@PAGEOFF]
Lloh6:
	adrp	x8, lCPI0_18@PAGE
Lloh7:
	ldr	q6, [x8, lCPI0_18@PAGEOFF]
	cmhi.4s	v9, v2, v6
	cmhi.4s	v18, v2, v5
	uzp1.8h	v7, v18, v9
	umaxv.8h	h2, v7
	fmov	w8, s2
	tbz	w8, #0, LBB0_2
; %bb.50:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x13, #0                         ; =0x0
	ldr	x9, [sp, #320]                  ; 8-byte Folded Reload
	ldr	x8, [x9]
	ldr	x11, [x9, #16]
	ldr	x2, [x9, #48]
Lloh8:
	adrp	x9, lCPI0_16@PAGE
Lloh9:
	ldr	q2, [x9, lCPI0_16@PAGEOFF]
	and.16b	v2, v7, v2
	addv.8h	h19, v2
	ubfiz	w9, w26, #2, #27
	ldr	x12, [sp, #688]                 ; 8-byte Folded Reload
	orr	w9, w9, w12
	fmov	w12, s19
	and	w12, w12, #0xff
	str	w12, [sp, #220]                 ; 4-byte Folded Spill
	dup.4s	v2, w9
	and.16b	v16, v18, v2
	and.16b	v6, v9, v2
	ushll2.2d	v2, v6, #0
	ushll2.2d	v5, v16, #0
	ushll.2d	v6, v6, #0
	ushll.2d	v17, v16, #0
	fmov	x9, d17
	umaddl	x9, w9, w17, x8
	b	LBB0_52
LBB0_51:                                ; %else948
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x12, x23, x13, lsl #5
	ldp	q21, q22, [x12]
	bif.16b	v20, v22, v9
	bif.16b	v16, v21, v18
	stp	q16, q20, [x12]
	add	x13, x13, #1
	cmp	x13, #192
	b.eq	LBB0_68
LBB0_52:                                ; %direct.true.i203.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w0, s19
	add	x12, x9, x13, lsl #5
	movi.2d	v16, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w0, #0, LBB0_60
; %bb.53:                               ; %else
                                        ;   in Loop: Header=BB0_52 Depth=2
	and	w0, w0, #0xff
	tbnz	w0, #1, LBB0_61
LBB0_54:                                ; %else930
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w0, #2, LBB0_62
LBB0_55:                                ; %else933
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w0, #3, LBB0_63
LBB0_56:                                ; %else936
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w0, #4, LBB0_64
LBB0_57:                                ; %else939
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w0, #5, LBB0_65
LBB0_58:                                ; %else942
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w0, #6, LBB0_66
LBB0_59:                                ; %else945
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbz	w0, #7, LBB0_51
	b	LBB0_67
LBB0_60:                                ; %cond.load
                                        ;   in Loop: Header=BB0_52 Depth=2
	ldr	s16, [x12]
	and	w0, w0, #0xff
	tbz	w0, #1, LBB0_54
LBB0_61:                                ; %cond.load929
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x12, #4
	ld1.s	{ v16 }[1], [x15]
	tbz	w0, #2, LBB0_55
LBB0_62:                                ; %cond.load932
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x12, #8
	ld1.s	{ v16 }[2], [x15]
	tbz	w0, #3, LBB0_56
LBB0_63:                                ; %cond.load935
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x12, #12
	ld1.s	{ v16 }[3], [x15]
	tbz	w0, #4, LBB0_57
LBB0_64:                                ; %cond.load938
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x12, #16
	ld1.s	{ v20 }[0], [x15]
	tbz	w0, #5, LBB0_58
LBB0_65:                                ; %cond.load941
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x12, #20
	ld1.s	{ v20 }[1], [x15]
	tbz	w0, #6, LBB0_59
LBB0_66:                                ; %cond.load944
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x12, #24
	ld1.s	{ v20 }[2], [x15]
	tbz	w0, #7, LBB0_51
LBB0_67:                                ; %cond.load947
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x12, x12, #28
	ld1.s	{ v20 }[3], [x12]
	b	LBB0_51
LBB0_68:                                ; %direct.true57.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	xtn.8b	v20, v7
	sshll.2d	v7, v18, #0
Lloh10:
	adrp	x9, lCPI0_22@PAGE
Lloh11:
	ldr	q16, [x9, lCPI0_22@PAGEOFF]
	and.16b	v21, v7, v16
	movi	d16, #0x0000000000ffff
	and.8b	v23, v20, v16
Lloh12:
	adrp	x9, lCPI0_23@PAGE
Lloh13:
	ldr	d16, [x9, lCPI0_23@PAGEOFF]
	str	q20, [sp, #160]                 ; 16-byte Folded Spill
	and.8b	v16, v20, v16
	addv.8b	b16, v16
	fmov	w13, s16
	umaxv.8b	b16, v23
	fmov	w9, s16
	rbit	w12, w13
	clz	w12, w12
	tst	w9, #0x1
	csel	w3, w12, wzr, ne
	mov	w12, #1536                      ; =0x600
	dup.2d	v20, x12
	str	q21, [sp, #96]                  ; 16-byte Folded Spill
	orr.16b	v22, v21, v20
	mov	w12, #1538                      ; =0x602
	dup.2s	v16, w12
	xtn.2s	v17, v17
	str	q22, [sp, #176]                 ; 16-byte Folded Spill
	umlal.2d	v22, v17, v16
	mov	b21, v23[0]
	mov.b	v21[4], v23[1]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	str	q22, [sp, #272]                 ; 16-byte Folded Spill
	and.16b	v21, v21, v22
	movi.2d	v22, #0000000000000000
	str	q22, [sp, #1344]
	str	q22, [sp, #1328]
	str	q22, [sp, #1312]
	str	q21, [sp, #1296]
	and	x12, x3, #0x7
	add	x15, sp, #1296
	ldr	x12, [x15, x12, lsl #3]
	sub	x12, x12, x3
	add	x8, x8, x12, lsl #2
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w13, #0, LBB0_247
; %bb.69:                               ; %else952
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #1, LBB0_248
LBB0_70:                                ; %else955
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #2, LBB0_249
LBB0_71:                                ; %else958
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #3, LBB0_250
LBB0_72:                                ; %else961
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #4, LBB0_251
LBB0_73:                                ; %else964
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #5, LBB0_252
LBB0_74:                                ; %else967
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #6, LBB0_253
LBB0_75:                                ; %else970
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w13, #7, LBB0_77
LBB0_76:                                ; %cond.load972
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x8, #28
	ld1.s	{ v29 }[3], [x8]
LBB0_77:                                ; %else973
                                        ;   in Loop: Header=BB0_3 Depth=1
	sshll.2d	v21, v9, #0
	sshll2.2d	v31, v18, #0
	sshll2.2d	v8, v9, #0
Lloh14:
	adrp	x8, lCPI0_19@PAGE
Lloh15:
	ldr	q22, [x8, lCPI0_19@PAGEOFF]
	and.16b	v30, v8, v22
Lloh16:
	adrp	x8, lCPI0_20@PAGE
Lloh17:
	ldr	q22, [x8, lCPI0_20@PAGEOFF]
	and.16b	v27, v31, v22
Lloh18:
	adrp	x8, lCPI0_21@PAGE
Lloh19:
	ldr	q22, [x8, lCPI0_21@PAGEOFF]
	and.16b	v26, v21, v22
	and.16b	v24, v21, v1
	and.16b	v22, v7, v1
	stp	q22, q24, [sp, #688]            ; 32-byte Folded Spill
	ldr	q22, [x16, lCPI0_3@PAGEOFF]
	and.16b	v24, v8, v22
	and.16b	v25, v31, v4
	ldr	q22, [x1, lCPI0_2@PAGEOFF]
	and.16b	v21, v21, v22
	and.16b	v22, v7, v3
	stp	q26, q27, [sp, #16]             ; 32-byte Folded Spill
	orr.16b	v26, v26, v20
	orr.16b	v27, v27, v20
	str	q30, [sp, #48]                  ; 16-byte Folded Spill
	orr.16b	v20, v30, v20
	umull.2d	v7, v17, v16
	str	q7, [sp, #192]                  ; 16-byte Folded Spill
	xtn.2s	v5, v5
	xtn.2s	v6, v6
	xtn.2s	v2, v2
	stp	q26, q20, [sp, #128]            ; 32-byte Folded Spill
	mov.16b	v7, v20
	umlal.2d	v7, v2, v16
	str	q27, [sp, #112]                 ; 16-byte Folded Spill
	mov.16b	v2, v27
	umlal.2d	v2, v5, v16
	stp	q2, q7, [sp, #240]              ; 32-byte Folded Spill
	mov.16b	v2, v26
	umlal.2d	v2, v6, v16
	str	q2, [sp, #224]                  ; 16-byte Folded Spill
	str	q22, [sp, #1232]
	str	q25, [sp, #1248]
	str	q21, [sp, #1264]
	str	q24, [sp, #1280]
	and	x8, x3, #0x7
	add	x12, sp, #1232
	ldr	x8, [x12, x8, lsl #3]
	orr	x8, x8, #0x1800
	sub	x8, x8, x3, lsl #2
	tst	w13, #0xff
	csel	x15, xzr, x8, eq
	add	x8, x23, x15
	ldp	q2, q5, [x8]
	zip2.8b	v6, v23, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	stp	q29, q28, [sp, #64]             ; 32-byte Folded Spill
	bit.16b	v5, v29, v6
	str	q23, [sp, #288]                 ; 16-byte Folded Spill
	zip1.8b	v6, v23, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bit.16b	v2, v28, v6
	stp	q2, q5, [x8]
	mov	w8, #32                         ; =0x20
	dup.2d	v2, x8
	orr.16b	v6, v21, v2
	orr.16b	v5, v25, v2
	stp	q5, q6, [sp, #528]              ; 32-byte Folded Spill
	orr.16b	v5, v22, v2
	orr.16b	v2, v24, v2
	stp	q2, q5, [sp, #496]              ; 32-byte Folded Spill
	mov	w8, #64                         ; =0x40
	dup.2d	v2, x8
	orr.16b	v6, v21, v2
	orr.16b	v5, v25, v2
	stp	q5, q6, [sp, #464]              ; 32-byte Folded Spill
	orr.16b	v5, v22, v2
	orr.16b	v2, v24, v2
	stp	q2, q5, [sp, #432]              ; 32-byte Folded Spill
	mov	w8, #96                         ; =0x60
	dup.2d	v2, x8
	stp	q21, q25, [sp, #624]            ; 32-byte Folded Spill
	orr.16b	v6, v21, v2
	orr.16b	v5, v25, v2
	stp	q5, q6, [sp, #400]              ; 32-byte Folded Spill
	orr.16b	v5, v22, v2
	str	q24, [sp, #656]                 ; 16-byte Folded Spill
	orr.16b	v2, v24, v2
	stp	q2, q5, [sp, #368]              ; 32-byte Folded Spill
	ldr	q2, [sp, #7664]
	ldr	q5, [sp, #7648]
	fmul.4s	v5, v5, v5
	fmul.4s	v2, v2, v2
	and.16b	v14, v9, v2
	and.16b	v21, v18, v5
	ldr	q2, [sp, #7616]
	fmul.4s	v2, v2, v2
	ldr	q5, [sp, #7632]
	fmul.4s	v5, v5, v5
	and.16b	v24, v9, v5
	and.16b	v15, v18, v2
	ldr	q2, [sp, #7584]
	fmul.4s	v2, v2, v2
	ldr	q5, [sp, #7600]
	fmul.4s	v5, v5, v5
	and.16b	v12, v9, v5
	and.16b	v13, v18, v2
	str	q22, [sp, #608]                 ; 16-byte Folded Spill
	fmov	x8, d22
	add	x8, x23, x8
	ldp	q2, q5, [x8]
	fmul.4s	v2, v2, v2
	fmul.4s	v5, v5, v5
	and.16b	v23, v9, v5
	and.16b	v2, v18, v2
	sshll.2d	v5, v9, #0
	dup.2d	v6, x14
	and.16b	v11, v5, v6
	sshll.2d	v5, v18, #0
	and.16b	v20, v5, v6
	and.16b	v16, v8, v6
	and.16b	v17, v31, v6
	stp	q8, q31, [sp, #560]             ; 32-byte Folded Spill
	and.16b	v5, v8, v1
	str	q5, [sp, #672]                  ; 16-byte Folded Spill
	and.16b	v8, v31, v1
	b	LBB0_79
LBB0_78:                                ; %else1169
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmul.4s	v6, v10, v10
	fmul.4s	v5, v22, v22
	fadd.4s	v5, v2, v5
	fadd.4s	v27, v23, v6
	fmul.4s	v6, v29, v29
	fmul.4s	v7, v28, v28
	fadd.4s	v7, v13, v7
	fadd.4s	v6, v12, v6
	fmul.4s	v22, v25, v25
	fmul.4s	v25, v30, v30
	fadd.4s	v25, v15, v25
	fadd.4s	v22, v24, v22
	sshll.2d	v28, v18, #0
	sshll.2d	v29, v9, #0
	fmul.4s	v26, v26, v26
	fmul.4s	v30, v31, v31
	fadd.4s	v30, v14, v30
	fadd.4s	v26, v21, v26
	dup.2d	v31, x14
	ldr	q10, [sp, #560]                 ; 16-byte Folded Reload
	and.16b	v10, v10, v31
	add.2d	v16, v16, v10
	ldr	q10, [sp, #576]                 ; 16-byte Folded Reload
	and.16b	v10, v10, v31
	add.2d	v17, v17, v10
	and.16b	v29, v29, v31
	add.2d	v11, v11, v29
	and.16b	v28, v28, v31
	add.2d	v20, v20, v28
	bit.16b	v23, v27, v9
	bit.16b	v2, v5, v18
	bit.16b	v12, v6, v9
	bit.16b	v13, v7, v18
	bit.16b	v24, v22, v9
	bit.16b	v15, v25, v18
	bit.16b	v21, v26, v18
	bit.16b	v14, v30, v9
	fmov	x8, d20
	cmp	x8, #192
	b.ge	LBB0_143
LBB0_79:                                ; %direct.true57.i218.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w8, s19
	shl.2d	v5, v20, #5
	ldr	q6, [sp, #608]                  ; 16-byte Folded Reload
	orr.16b	v6, v5, v6
	ldr	q7, [sp, #688]                  ; 16-byte Folded Reload
	add.2d	v6, v7, v6
	movi.2d	v22, #0000000000000000
	movi.2d	v10, #0000000000000000
	tbnz	w8, #0, LBB0_114
; %bb.80:                               ; %else980
                                        ;   in Loop: Header=BB0_79 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_115
LBB0_81:                                ; %else986
                                        ;   in Loop: Header=BB0_79 Depth=2
	shl.2d	v6, v17, #5
	ldr	q7, [sp, #640]                  ; 16-byte Folded Reload
	orr.16b	v7, v6, v7
	add.2d	v7, v8, v7
	tbnz	w8, #2, LBB0_116
LBB0_82:                                ; %else992
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #3, LBB0_117
LBB0_83:                                ; %else998
                                        ;   in Loop: Header=BB0_79 Depth=2
	shl.2d	v7, v11, #5
	ldr	q25, [sp, #624]                 ; 16-byte Folded Reload
	orr.16b	v25, v7, v25
	ldr	q26, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v25, v26, v25
	tbnz	w8, #4, LBB0_118
LBB0_84:                                ; %else1004
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #5, LBB0_119
LBB0_85:                                ; %else1010
                                        ;   in Loop: Header=BB0_79 Depth=2
	shl.2d	v27, v16, #5
	ldp	q25, q26, [sp, #656]            ; 32-byte Folded Reload
	orr.16b	v25, v27, v25
	add.2d	v25, v26, v25
	tbnz	w8, #6, LBB0_120
LBB0_86:                                ; %else1016
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbz	w8, #7, LBB0_88
LBB0_87:                                ; %cond.load1018
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x8, v25[1]
	ld1.s	{ v10 }[3], [x8]
LBB0_88:                                ; %else1022
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	w8, s19
	ldr	q25, [sp, #512]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v5
	ldr	q26, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v25, v26, v25
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w8, #0, LBB0_121
; %bb.89:                               ; %else1029
                                        ;   in Loop: Header=BB0_79 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_122
LBB0_90:                                ; %else1035
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q25, [sp, #528]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v6
	add.2d	v25, v8, v25
	tbnz	w8, #2, LBB0_123
LBB0_91:                                ; %else1041
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #3, LBB0_124
LBB0_92:                                ; %else1047
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q25, [sp, #544]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v7
	ldr	q26, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v25, v26, v25
	tbnz	w8, #4, LBB0_125
LBB0_93:                                ; %else1053
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #5, LBB0_126
LBB0_94:                                ; %else1059
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q25, [sp, #496]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v27
	ldr	q26, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v25, v26, v25
	tbnz	w8, #6, LBB0_127
LBB0_95:                                ; %else1065
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbz	w8, #7, LBB0_97
LBB0_96:                                ; %cond.load1067
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x8, v25[1]
	ld1.s	{ v29 }[3], [x8]
LBB0_97:                                ; %else1071
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	w8, s19
	ldr	q25, [sp, #448]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v5
	ldr	q26, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v25
	movi.2d	v30, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbnz	w8, #0, LBB0_128
; %bb.98:                               ; %else1078
                                        ;   in Loop: Header=BB0_79 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_129
LBB0_99:                                ; %else1084
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q26, [sp, #464]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v6
	add.2d	v26, v8, v26
	tbnz	w8, #2, LBB0_130
LBB0_100:                               ; %else1090
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #3, LBB0_131
LBB0_101:                               ; %else1096
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q26, [sp, #480]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v7
	ldr	q31, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v26, v31, v26
	tbnz	w8, #4, LBB0_132
LBB0_102:                               ; %else1102
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #5, LBB0_133
LBB0_103:                               ; %else1108
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q26, [sp, #432]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v27
	ldr	q31, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v26, v31, v26
	tbnz	w8, #6, LBB0_134
LBB0_104:                               ; %else1114
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbz	w8, #7, LBB0_106
LBB0_105:                               ; %cond.load1116
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x8, v26[1]
	ld1.s	{ v25 }[3], [x8]
LBB0_106:                               ; %else1120
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	w8, s19
	ldr	q26, [sp, #384]                 ; 16-byte Folded Reload
	add.2d	v5, v26, v5
	ldr	q26, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v5, v26, v5
	movi.2d	v26, #0000000000000000
	movi.2d	v31, #0000000000000000
	tbnz	w8, #0, LBB0_135
; %bb.107:                              ; %else1127
                                        ;   in Loop: Header=BB0_79 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_136
LBB0_108:                               ; %else1133
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q5, [sp, #400]                  ; 16-byte Folded Reload
	add.2d	v5, v5, v6
	add.2d	v5, v8, v5
	tbnz	w8, #2, LBB0_137
LBB0_109:                               ; %else1139
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #3, LBB0_138
LBB0_110:                               ; %else1145
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q5, [sp, #416]                  ; 16-byte Folded Reload
	add.2d	v5, v5, v7
	ldr	q6, [sp, #704]                  ; 16-byte Folded Reload
	add.2d	v5, v6, v5
	tbnz	w8, #4, LBB0_139
LBB0_111:                               ; %else1151
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #5, LBB0_140
LBB0_112:                               ; %else1157
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q5, [sp, #368]                  ; 16-byte Folded Reload
	add.2d	v5, v5, v27
	ldr	q6, [sp, #672]                  ; 16-byte Folded Reload
	add.2d	v5, v6, v5
	tbnz	w8, #6, LBB0_141
LBB0_113:                               ; %else1163
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbz	w8, #7, LBB0_78
	b	LBB0_142
LBB0_114:                               ; %cond.load976
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d6
	ldr	s22, [x12]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_81
LBB0_115:                               ; %cond.load982
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x12, v6[1]
	ld1.s	{ v22 }[1], [x12]
	shl.2d	v6, v17, #5
	ldr	q7, [sp, #640]                  ; 16-byte Folded Reload
	orr.16b	v7, v6, v7
	add.2d	v7, v8, v7
	tbz	w8, #2, LBB0_82
LBB0_116:                               ; %cond.load988
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d7
	ld1.s	{ v22 }[2], [x12]
	tbz	w8, #3, LBB0_83
LBB0_117:                               ; %cond.load994
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x12, v7[1]
	ld1.s	{ v22 }[3], [x12]
	shl.2d	v7, v11, #5
	ldr	q25, [sp, #624]                 ; 16-byte Folded Reload
	orr.16b	v25, v7, v25
	ldr	q26, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v25, v26, v25
	tbz	w8, #4, LBB0_84
LBB0_118:                               ; %cond.load1000
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d25
	ld1.s	{ v10 }[0], [x12]
	tbz	w8, #5, LBB0_85
LBB0_119:                               ; %cond.load1006
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x12, v25[1]
	ld1.s	{ v10 }[1], [x12]
	shl.2d	v27, v16, #5
	ldp	q25, q26, [sp, #656]            ; 32-byte Folded Reload
	orr.16b	v25, v27, v25
	add.2d	v25, v26, v25
	tbz	w8, #6, LBB0_86
LBB0_120:                               ; %cond.load1012
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d25
	ld1.s	{ v10 }[2], [x12]
	tbnz	w8, #7, LBB0_87
	b	LBB0_88
LBB0_121:                               ; %cond.load1025
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d25
	ldr	s28, [x12]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_90
LBB0_122:                               ; %cond.load1031
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x12, v25[1]
	ld1.s	{ v28 }[1], [x12]
	ldr	q25, [sp, #528]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v6
	add.2d	v25, v8, v25
	tbz	w8, #2, LBB0_91
LBB0_123:                               ; %cond.load1037
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d25
	ld1.s	{ v28 }[2], [x12]
	tbz	w8, #3, LBB0_92
LBB0_124:                               ; %cond.load1043
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x12, v25[1]
	ld1.s	{ v28 }[3], [x12]
	ldr	q25, [sp, #544]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v7
	ldr	q26, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v25, v26, v25
	tbz	w8, #4, LBB0_93
LBB0_125:                               ; %cond.load1049
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d25
	ld1.s	{ v29 }[0], [x12]
	tbz	w8, #5, LBB0_94
LBB0_126:                               ; %cond.load1055
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x12, v25[1]
	ld1.s	{ v29 }[1], [x12]
	ldr	q25, [sp, #496]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v27
	ldr	q26, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v25, v26, v25
	tbz	w8, #6, LBB0_95
LBB0_127:                               ; %cond.load1061
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d25
	ld1.s	{ v29 }[2], [x12]
	tbnz	w8, #7, LBB0_96
	b	LBB0_97
LBB0_128:                               ; %cond.load1074
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d26
	ldr	s30, [x12]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_99
LBB0_129:                               ; %cond.load1080
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x12, v26[1]
	ld1.s	{ v30 }[1], [x12]
	ldr	q26, [sp, #464]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v6
	add.2d	v26, v8, v26
	tbz	w8, #2, LBB0_100
LBB0_130:                               ; %cond.load1086
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d26
	ld1.s	{ v30 }[2], [x12]
	tbz	w8, #3, LBB0_101
LBB0_131:                               ; %cond.load1092
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x12, v26[1]
	ld1.s	{ v30 }[3], [x12]
	ldr	q26, [sp, #480]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v7
	ldr	q31, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v26, v31, v26
	tbz	w8, #4, LBB0_102
LBB0_132:                               ; %cond.load1098
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d26
	ld1.s	{ v25 }[0], [x12]
	tbz	w8, #5, LBB0_103
LBB0_133:                               ; %cond.load1104
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x12, v26[1]
	ld1.s	{ v25 }[1], [x12]
	ldr	q26, [sp, #432]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v27
	ldr	q31, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v26, v31, v26
	tbz	w8, #6, LBB0_104
LBB0_134:                               ; %cond.load1110
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d26
	ld1.s	{ v25 }[2], [x12]
	tbnz	w8, #7, LBB0_105
	b	LBB0_106
LBB0_135:                               ; %cond.load1123
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d5
	ldr	s26, [x12]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_108
LBB0_136:                               ; %cond.load1129
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x12, v5[1]
	ld1.s	{ v26 }[1], [x12]
	ldr	q5, [sp, #400]                  ; 16-byte Folded Reload
	add.2d	v5, v5, v6
	add.2d	v5, v8, v5
	tbz	w8, #2, LBB0_109
LBB0_137:                               ; %cond.load1135
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d5
	ld1.s	{ v26 }[2], [x12]
	tbz	w8, #3, LBB0_110
LBB0_138:                               ; %cond.load1141
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x12, v5[1]
	ld1.s	{ v26 }[3], [x12]
	ldr	q5, [sp, #416]                  ; 16-byte Folded Reload
	add.2d	v5, v5, v7
	ldr	q6, [sp, #704]                  ; 16-byte Folded Reload
	add.2d	v5, v6, v5
	tbz	w8, #4, LBB0_111
LBB0_139:                               ; %cond.load1147
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d5
	ld1.s	{ v31 }[0], [x12]
	tbz	w8, #5, LBB0_112
LBB0_140:                               ; %cond.load1153
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x12, v5[1]
	ld1.s	{ v31 }[1], [x12]
	ldr	q5, [sp, #368]                  ; 16-byte Folded Reload
	add.2d	v5, v5, v27
	ldr	q6, [sp, #672]                  ; 16-byte Folded Reload
	add.2d	v5, v6, v5
	tbz	w8, #6, LBB0_113
LBB0_141:                               ; %cond.load1159
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x12, d5
	ld1.s	{ v31 }[2], [x12]
	tbz	w8, #7, LBB0_78
LBB0_142:                               ; %cond.load1165
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x8, v5[1]
	ld1.s	{ v31 }[3], [x8]
	b	LBB0_78
LBB0_143:                               ; %direct.false58.i219.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	x2, [sp, #544]                  ; 8-byte Folded Spill
	mov	x8, #0                          ; =0x0
	ldr	q6, [sp, #560]                  ; 16-byte Folded Reload
	and.16b	v7, v6, v0
	ldr	q6, [sp, #576]                  ; 16-byte Folded Reload
	and.16b	v16, v6, v0
	sshll.2d	v6, v9, #0
	and.16b	v17, v6, v0
	sshll.2d	v6, v18, #0
	and.16b	v6, v6, v0
	dup.2d	v20, x25
	ushll2.2d	v22, v9, #0
	and.16b	v10, v22, v20
	ushll2.2d	v22, v18, #0
	and.16b	v22, v22, v20
	ushll.2d	v25, v9, #0
	and.16b	v9, v25, v20
	ushll.2d	v18, v18, #0
	and.16b	v18, v18, v20
	movi.2d	v20, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	b	LBB0_145
LBB0_144:                               ; %else1227
                                        ;   in Loop: Header=BB0_145 Depth=2
	add.2d	v25, v25, v22
	add.2d	v28, v28, v9
	add.2d	v29, v29, v10
	add.2d	v20, v20, v18
	fmov	x8, d20
	cmp	x8, #192
	b.ge	LBB0_177
LBB0_145:                               ; %direct.true85.i220.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w12, s19
	add	x8, x11, x8, lsl #5
	movi.2d	v11, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbnz	w12, #0, LBB0_161
; %bb.146:                              ; %else1173
                                        ;   in Loop: Header=BB0_145 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_162
LBB0_147:                               ; %else1176
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w12, #2, LBB0_163
LBB0_148:                               ; %else1179
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w12, #3, LBB0_164
LBB0_149:                               ; %else1182
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w12, #4, LBB0_165
LBB0_150:                               ; %else1185
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w12, #5, LBB0_166
LBB0_151:                               ; %else1188
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w12, #6, LBB0_167
LBB0_152:                               ; %else1191
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w12, #7, LBB0_168
LBB0_153:                               ; %else1194
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	w8, s19
	shl.2d	v26, v20, #5
	ldr	q31, [sp, #608]                 ; 16-byte Folded Reload
	orr.16b	v26, v26, v31
	add.2d	v26, v6, v26
	tbnz	w8, #0, LBB0_169
LBB0_154:                               ; %else1199
                                        ;   in Loop: Header=BB0_145 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_170
LBB0_155:                               ; %else1203
                                        ;   in Loop: Header=BB0_145 Depth=2
	shl.2d	v26, v25, #5
	ldr	q31, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v26, v26, v31
	add.2d	v26, v16, v26
	tbnz	w8, #2, LBB0_171
LBB0_156:                               ; %else1207
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w8, #3, LBB0_172
LBB0_157:                               ; %else1211
                                        ;   in Loop: Header=BB0_145 Depth=2
	shl.2d	v26, v28, #5
	ldr	q31, [sp, #624]                 ; 16-byte Folded Reload
	orr.16b	v26, v26, v31
	add.2d	v26, v17, v26
	tbnz	w8, #4, LBB0_173
LBB0_158:                               ; %else1215
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w8, #5, LBB0_174
LBB0_159:                               ; %else1219
                                        ;   in Loop: Header=BB0_145 Depth=2
	shl.2d	v26, v29, #5
	ldr	q31, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v26, v26, v31
	add.2d	v26, v7, v26
	tbnz	w8, #6, LBB0_175
LBB0_160:                               ; %else1223
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbz	w8, #7, LBB0_144
	b	LBB0_176
LBB0_161:                               ; %cond.load1172
                                        ;   in Loop: Header=BB0_145 Depth=2
	ldr	s11, [x8]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_147
LBB0_162:                               ; %cond.load1175
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x13, x8, #4
	ld1.s	{ v11 }[1], [x13]
	tbz	w12, #2, LBB0_148
LBB0_163:                               ; %cond.load1178
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x13, x8, #8
	ld1.s	{ v11 }[2], [x13]
	tbz	w12, #3, LBB0_149
LBB0_164:                               ; %cond.load1181
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x13, x8, #12
	ld1.s	{ v11 }[3], [x13]
	tbz	w12, #4, LBB0_150
LBB0_165:                               ; %cond.load1184
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x13, x8, #16
	ld1.s	{ v30 }[0], [x13]
	tbz	w12, #5, LBB0_151
LBB0_166:                               ; %cond.load1187
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x13, x8, #20
	ld1.s	{ v30 }[1], [x13]
	tbz	w12, #6, LBB0_152
LBB0_167:                               ; %cond.load1190
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x13, x8, #24
	ld1.s	{ v30 }[2], [x13]
	tbz	w12, #7, LBB0_153
LBB0_168:                               ; %cond.load1193
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x8, x8, #28
	ld1.s	{ v30 }[3], [x8]
	fmov	w8, s19
	shl.2d	v26, v20, #5
	ldr	q31, [sp, #608]                 ; 16-byte Folded Reload
	orr.16b	v26, v26, v31
	add.2d	v26, v6, v26
	tbz	w8, #0, LBB0_154
LBB0_169:                               ; %cond.store
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	x12, d26
	str	s11, [x12]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_155
LBB0_170:                               ; %cond.store1200
                                        ;   in Loop: Header=BB0_145 Depth=2
	mov.d	x12, v26[1]
	st1.s	{ v11 }[1], [x12]
	shl.2d	v26, v25, #5
	ldr	q31, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v26, v26, v31
	add.2d	v26, v16, v26
	tbz	w8, #2, LBB0_156
LBB0_171:                               ; %cond.store1204
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	x12, d26
	st1.s	{ v11 }[2], [x12]
	tbz	w8, #3, LBB0_157
LBB0_172:                               ; %cond.store1208
                                        ;   in Loop: Header=BB0_145 Depth=2
	mov.d	x12, v26[1]
	st1.s	{ v11 }[3], [x12]
	shl.2d	v26, v28, #5
	ldr	q31, [sp, #624]                 ; 16-byte Folded Reload
	orr.16b	v26, v26, v31
	add.2d	v26, v17, v26
	tbz	w8, #4, LBB0_158
LBB0_173:                               ; %cond.store1212
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	x12, d26
	str	s30, [x12]
	tbz	w8, #5, LBB0_159
LBB0_174:                               ; %cond.store1216
                                        ;   in Loop: Header=BB0_145 Depth=2
	mov.d	x12, v26[1]
	st1.s	{ v30 }[1], [x12]
	shl.2d	v26, v29, #5
	ldr	q31, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v26, v26, v31
	add.2d	v26, v7, v26
	tbz	w8, #6, LBB0_160
LBB0_175:                               ; %cond.store1220
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	x12, d26
	st1.s	{ v30 }[2], [x12]
	tbz	w8, #7, LBB0_144
LBB0_176:                               ; %cond.store1224
                                        ;   in Loop: Header=BB0_145 Depth=2
	mov.d	x8, v26[1]
	st1.s	{ v30 }[3], [x8]
	b	LBB0_144
LBB0_177:                               ; %direct.false86.i222.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, x15
	movi	d20, #0xffffffffffff0000
	ldr	q30, [sp, #160]                 ; 16-byte Folded Reload
	and.8b	v20, v30, v20
	ldp	q26, q25, [sp, #64]             ; 32-byte Folded Reload
	fmul.4s	v25, v25, v25
	fmul.4s	v26, v26, v26
	fadd.4s	v23, v26, v23
	fadd.4s	v2, v25, v2
	ldr	q26, [sp, #288]                 ; 16-byte Folded Reload
	zip1.8b	v25, v26, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	and.16b	v2, v25, v2
	zip2.8b	v25, v26, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	and.16b	v23, v25, v23
	zip2.8b	v25, v20, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	bit.16b	v23, v27, v25
	zip1.8b	v20, v20, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmlt.4s	v20, v20, #0
	bit.16b	v2, v5, v20
	fadd.4s	v2, v13, v2
	mov.16b	v13, v26
	fadd.4s	v5, v12, v23
	fadd.4s	v20, v24, v5
	fadd.4s	v2, v15, v2
	fadd.4s	v5, v21, v2
	fadd.4s	v20, v14, v20
	ldr	q2, [sp, #96]                   ; 16-byte Folded Reload
	ldp	q23, q21, [sp, #32]             ; 32-byte Folded Reload
	uzp1.4s	v2, v2, v23
	ldr	q23, [sp, #16]                  ; 16-byte Folded Reload
	uzp1.4s	v21, v23, v21
	movi.4s	v24, #1
	eor.16b	v23, v2, v24
	mov.s	w12, v23[1]
	mov.s	w15, v23[2]
	eor.16b	v26, v21, v24
	mov.s	w17, v23[3]
	fmov	w8, s23
	add	x13, sp, #792
	bfxil	x13, x8, #0, #3
	str	d30, [sp, #792]
	ldrb	w13, [x13]
	and	x0, x8, #0x7
	umov.b	w8, v30[0]
	str	q20, [sp, #1072]
	str	q5, [sp, #1056]
	add	x1, sp, #1056
	ldr	s23, [x1, x0, lsl #2]
	ands	w0, w8, #0x1
	tst	w0, w13
	movi	d12, #0000000000000000
	fcsel	s23, s23, s12, ne
	add	x13, sp, #792
	bfxil	x13, x12, #0, #3
	ldrb	w1, [x13]
	and	x12, x12, #0x7
	umov.b	w13, v30[1]
	str	q20, [sp, #1040]
	str	q5, [sp, #1024]
	add	x2, sp, #1024
	ldr	s24, [x2, x12, lsl #2]
	ands	w12, w13, #0x1
	tst	w12, w1
	fcsel	s24, s24, s12, ne
	add	x12, sp, #792
	bfxil	x12, x15, #0, #3
	ldrb	w12, [x12]
	umov.b	w2, v30[2]
	and	x15, x15, #0x7
	stp	q5, q20, [sp, #992]
	add	x1, sp, #992
	ldr	s25, [x1, x15, lsl #2]
	ands	w15, w2, #0x1
	tst	w15, w12
	fcsel	s25, s25, s12, ne
	add	x12, sp, #792
	bfxil	x12, x17, #0, #3
	ldrb	w15, [x12]
	and	x17, x17, #0x7
	umov.b	w12, v30[3]
	stp	q5, q20, [sp, #960]
	add	x1, sp, #960
	ldr	s27, [x1, x17, lsl #2]
	ands	w17, w12, #0x1
	tst	w17, w15
	mov.s	w15, v26[1]
	mov.s	w17, v26[2]
	fcsel	s27, s27, s12, ne
	mov.s	w1, v26[3]
	fmov	w26, s26
	and	x27, x26, #0x7
	add	x28, sp, #792
	bfxil	x28, x26, #0, #3
	ldrb	w28, [x28]
	umov.b	w26, v30[4]
	and	w28, w26, w28
	str	q20, [sp, #1200]
	str	q5, [sp, #1184]
	add	x30, sp, #1184
	ldr	s26, [x30, x27, lsl #2]
	tst	w28, #0x1
	fcsel	s26, s26, s12, ne
	add	x27, sp, #792
	bfxil	x27, x15, #0, #3
	ldrb	w28, [x27]
	and	x15, x15, #0x7
	umov.b	w27, v30[5]
	str	q20, [sp, #1168]
	str	q5, [sp, #1152]
	add	x30, sp, #1152
	ldr	s28, [x30, x15, lsl #2]
	ands	w15, w27, #0x1
	tst	w15, w28
	fcsel	s28, s28, s12, ne
	add	x15, sp, #792
	bfxil	x15, x17, #0, #3
	ldrb	w15, [x15]
	and	x17, x17, #0x7
	umov.b	w28, v30[6]
	str	q20, [sp, #1136]
	str	q5, [sp, #1120]
	add	x30, sp, #1120
	ldr	s29, [x30, x17, lsl #2]
	ands	w17, w28, #0x1
	tst	w17, w15
	fcsel	s29, s29, s12, ne
	add	x15, sp, #792
	bfxil	x15, x1, #0, #3
	ldrb	w15, [x15]
	umov.b	w30, v30[7]
	and	x17, x1, #0x7
	str	q20, [sp, #1104]
	str	q5, [sp, #1088]
	add	x1, sp, #1088
	ldr	s30, [x1, x17, lsl #2]
	ands	w17, w30, #0x1
	tst	w17, w15
	fcsel	s30, s30, s12, ne
	mov.s	v26[1], v28[0]
	mov.s	v26[2], v29[0]
	mov.s	v26[3], v30[0]
	mov.s	v23[1], v24[0]
	mov.s	v23[2], v25[0]
	mov.s	v23[3], v27[0]
	fadd.4s	v5, v5, v23
	fadd.4s	v20, v20, v26
	movi.4s	v23, #2
	eor.16b	v21, v21, v23
	eor.16b	v2, v2, v23
	fmov	w15, s2
	add	x17, sp, #792
	bfxil	x17, x15, #0, #3
	ldrb	w17, [x17]
	and	x15, x15, #0x7
	stp	q5, q20, [sp, #928]
	add	x1, sp, #928
	ldr	s2, [x1, x15, lsl #2]
	tst	w0, w17
	fcsel	s2, s2, s12, ne
	fmov	w15, s21
	and	x17, x15, #0x7
	add	x1, sp, #792
	bfxil	x1, x15, #0, #3
	ldrb	w15, [x1]
	and	w15, w26, w15
	stp	q5, q20, [sp, #896]
	add	x1, sp, #896
	ldr	s21, [x1, x17, lsl #2]
	tst	w15, #0x1
	fcsel	s21, s21, s12, ne
	fadd.4s	v20, v20, v21
	tst	w0, w26
	fcsel	s20, s20, s12, ne
	ands	w8, w8, #0x1
	fadd.4s	v2, v5, v2
	fadd	s2, s2, s20
	fcsel	s5, s2, s12, ne
	tst	w13, #0x1
	fcsel	s20, s5, s12, ne
	tst	w2, #0x1
	fcsel	s21, s5, s12, ne
	tst	w12, #0x1
	fcsel	s23, s5, s12, ne
	tst	w8, w26
	fcsel	s24, s2, s12, ne
	tst	w27, #0x1
	fcsel	s25, s5, s12, ne
	tst	w28, #0x1
	fcsel	s26, s5, s12, ne
	tst	w30, #0x1
Lloh20:
	adrp	x8, lCPI0_24@PAGE
Lloh21:
	ldr	d2, [x8, lCPI0_24@PAGEOFF]
	shl.8b	v27, v13, #7
	cmlt.8b	v27, v27, #0
	and.8b	v2, v27, v2
	addv.8b	b2, v2
	fmov	w8, s2
	fcsel	s27, s5, s12, ne
	mov.s	v5[1], v20[0]
	mov.s	v5[2], v21[0]
	mov.s	v5[3], v23[0]
	mov.s	v24[1], v25[0]
	mov.s	v24[2], v26[0]
	mov.s	v24[3], v27[0]
	ldr	w12, [sp, #220]                 ; 4-byte Folded Reload
	rbit	w12, w12
	clz	w12, w12
	stp	q5, q24, [sp, #864]
	and	x12, x12, #0x7
	add	x13, sp, #864
	ldr	s5, [x13, x12, lsl #2]
	mov	b20, v13[0]
	mov.b	v20[4], v13[1]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	mov	b21, v13[2]
	mov.b	v21[4], v13[3]
	ldr	q23, [sp, #176]                 ; 16-byte Folded Reload
	and.16b	v20, v20, v23
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	ldp	q23, q24, [sp, #112]            ; 32-byte Folded Reload
	and.16b	v21, v21, v23
	mov	b23, v13[4]
	mov.b	v23[4], v13[5]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	and.16b	v23, v23, v24
	mov	b24, v13[6]
	mov.b	v24[4], v13[7]
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	ldr	q25, [sp, #144]                 ; 16-byte Folded Reload
	and.16b	v24, v24, v25
	stp	q23, q24, [sp, #832]
	stp	q20, q21, [sp, #800]
	mov	x28, x3
	and	x12, x3, #0x7
	add	x13, sp, #800
	ldr	x12, [x13, x12, lsl #3]
	sub	x12, x12, x3
	add	x11, x11, x12, lsl #2
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbz	w8, #0, LBB0_179
; %bb.178:                              ; %cond.load1229
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	s20, [x11]
LBB0_179:                               ; %else1230
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x3, [sp, #544]                  ; 8-byte Folded Reload
	tbz	w8, #1, LBB0_181
; %bb.180:                              ; %cond.load1232
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x11, #4
	ld1.s	{ v20 }[1], [x12]
LBB0_181:                               ; %else1233
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	w15, [sp, #348]                 ; 4-byte Folded Reload
	mov	w17, #6152                      ; =0x1808
	adrp	x1, lCPI0_2@PAGE
	ldr	w0, [sp, #356]                  ; 4-byte Folded Reload
	ldr	w2, [sp, #352]                  ; 4-byte Folded Reload
	ldr	x26, [sp, #360]                 ; 8-byte Folded Reload
	tbnz	w8, #2, LBB0_254
; %bb.182:                              ; %else1236
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #3, LBB0_255
LBB0_183:                               ; %else1239
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #4, LBB0_256
LBB0_184:                               ; %else1242
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #5, LBB0_257
LBB0_185:                               ; %else1245
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #6, LBB0_258
LBB0_186:                               ; %else1248
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #7, LBB0_188
LBB0_187:                               ; %cond.load1250
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x11, #28
	ld1.s	{ v21 }[3], [x8]
LBB0_188:                               ; %else1251
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	fadd	s5, s5, s12
	mov	w8, #16384                      ; =0x4000
	movk	w8, #17600, lsl #16
	fmov	s23, w8
	fdiv	s5, s5, s23
	add	x8, sp, #1376
	add	x8, x8, x9
	ldp	q23, q24, [x8]
	zip2.8b	v25, v13, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	bif.16b	v21, v24, v25
	zip1.8b	v24, v13, v0
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	bif.16b	v20, v23, v24
	stp	q20, q21, [x8]
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s20, w8
	fadd	s5, s5, s20
	fsqrt	s5, s5
	dup.4s	v5, v5[0]
	ldr	q20, [sp, #192]                 ; 16-byte Folded Reload
	fmov	x8, d20
	add	x8, x3, x8, lsl #2
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	b	LBB0_190
LBB0_189:                               ; %else1367
                                        ;   in Loop: Header=BB0_190 Depth=2
	add.2d	v21, v21, v22
	add.2d	v23, v23, v9
	add.2d	v24, v24, v10
	add.2d	v20, v20, v18
	fmov	x11, d20
	cmp	x11, #192
	b.ge	LBB0_238
LBB0_190:                               ; %direct.true109.i229.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w12, s19
	shl.2d	v25, v20, #5
	ldr	q26, [sp, #608]                 ; 16-byte Folded Reload
	orr.16b	v26, v25, v26
	ldr	q25, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v28, v25, v26
	movi.2d	v25, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w12, #0, LBB0_214
; %bb.191:                              ; %else1258
                                        ;   in Loop: Header=BB0_190 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_215
LBB0_192:                               ; %else1264
                                        ;   in Loop: Header=BB0_190 Depth=2
	shl.2d	v28, v21, #5
	ldr	q29, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v29, v28, v29
	add.2d	v28, v8, v29
	tbnz	w12, #2, LBB0_216
LBB0_193:                               ; %else1270
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w12, #3, LBB0_217
LBB0_194:                               ; %else1276
                                        ;   in Loop: Header=BB0_190 Depth=2
	shl.2d	v28, v23, #5
	ldr	q30, [sp, #624]                 ; 16-byte Folded Reload
	orr.16b	v30, v28, v30
	ldr	q28, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v28, v28, v30
	tbnz	w12, #4, LBB0_218
LBB0_195:                               ; %else1282
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w12, #5, LBB0_219
LBB0_196:                               ; %else1288
                                        ;   in Loop: Header=BB0_190 Depth=2
	shl.2d	v28, v24, #5
	ldr	q31, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v31, v28, v31
	ldr	q28, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v28, v28, v31
	tbnz	w12, #6, LBB0_220
LBB0_197:                               ; %else1294
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w12, #7, LBB0_221
LBB0_198:                               ; %else1300
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	w12, s19
	add.2d	v11, v6, v26
	movi.2d	v26, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w12, #0, LBB0_222
LBB0_199:                               ; %else1307
                                        ;   in Loop: Header=BB0_190 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_223
LBB0_200:                               ; %else1313
                                        ;   in Loop: Header=BB0_190 Depth=2
	add.2d	v29, v16, v29
	tbnz	w12, #2, LBB0_224
LBB0_201:                               ; %else1319
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w12, #3, LBB0_225
LBB0_202:                               ; %else1325
                                        ;   in Loop: Header=BB0_190 Depth=2
	add.2d	v29, v17, v30
	tbnz	w12, #4, LBB0_226
LBB0_203:                               ; %else1331
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w12, #5, LBB0_227
LBB0_204:                               ; %else1337
                                        ;   in Loop: Header=BB0_190 Depth=2
	add.2d	v29, v7, v31
	tbnz	w12, #6, LBB0_228
LBB0_205:                               ; %else1343
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w12, #7, LBB0_229
LBB0_206:                               ; %else1349
                                        ;   in Loop: Header=BB0_190 Depth=2
	fdiv.4s	v25, v25, v5
	fmov	w12, s19
	fmul.4s	v25, v25, v26
	add	x11, x8, x11, lsl #5
	tbnz	w12, #0, LBB0_230
LBB0_207:                               ; %else1353
                                        ;   in Loop: Header=BB0_190 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_231
LBB0_208:                               ; %else1355
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w12, #2, LBB0_232
LBB0_209:                               ; %else1357
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w12, #3, LBB0_233
LBB0_210:                               ; %else1359
                                        ;   in Loop: Header=BB0_190 Depth=2
	fdiv.4s	v25, v27, v5
	fmul.4s	v25, v25, v28
	tbnz	w12, #4, LBB0_234
LBB0_211:                               ; %else1361
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w12, #5, LBB0_235
LBB0_212:                               ; %else1363
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w12, #6, LBB0_236
LBB0_213:                               ; %else1365
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbz	w12, #7, LBB0_189
	b	LBB0_237
LBB0_214:                               ; %cond.load1254
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x13, d28
	ldr	s25, [x13]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_192
LBB0_215:                               ; %cond.load1260
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x13, v28[1]
	ld1.s	{ v25 }[1], [x13]
	shl.2d	v28, v21, #5
	ldr	q29, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v29, v28, v29
	add.2d	v28, v8, v29
	tbz	w12, #2, LBB0_193
LBB0_216:                               ; %cond.load1266
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x13, d28
	ld1.s	{ v25 }[2], [x13]
	tbz	w12, #3, LBB0_194
LBB0_217:                               ; %cond.load1272
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x13, v28[1]
	ld1.s	{ v25 }[3], [x13]
	shl.2d	v28, v23, #5
	ldr	q30, [sp, #624]                 ; 16-byte Folded Reload
	orr.16b	v30, v28, v30
	ldr	q28, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v28, v28, v30
	tbz	w12, #4, LBB0_195
LBB0_218:                               ; %cond.load1278
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x13, d28
	ld1.s	{ v27 }[0], [x13]
	tbz	w12, #5, LBB0_196
LBB0_219:                               ; %cond.load1284
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x13, v28[1]
	ld1.s	{ v27 }[1], [x13]
	shl.2d	v28, v24, #5
	ldr	q31, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v31, v28, v31
	ldr	q28, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v28, v28, v31
	tbz	w12, #6, LBB0_197
LBB0_220:                               ; %cond.load1290
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x13, d28
	ld1.s	{ v27 }[2], [x13]
	tbz	w12, #7, LBB0_198
LBB0_221:                               ; %cond.load1296
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x12, v28[1]
	ld1.s	{ v27 }[3], [x12]
	fmov	w12, s19
	add.2d	v11, v6, v26
	movi.2d	v26, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbz	w12, #0, LBB0_199
LBB0_222:                               ; %cond.load1303
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x13, d11
	ldr	s26, [x13]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_200
LBB0_223:                               ; %cond.load1309
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x13, v11[1]
	ld1.s	{ v26 }[1], [x13]
	add.2d	v29, v16, v29
	tbz	w12, #2, LBB0_201
LBB0_224:                               ; %cond.load1315
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x13, d29
	ld1.s	{ v26 }[2], [x13]
	tbz	w12, #3, LBB0_202
LBB0_225:                               ; %cond.load1321
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x13, v29[1]
	ld1.s	{ v26 }[3], [x13]
	add.2d	v29, v17, v30
	tbz	w12, #4, LBB0_203
LBB0_226:                               ; %cond.load1327
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x13, d29
	ld1.s	{ v28 }[0], [x13]
	tbz	w12, #5, LBB0_204
LBB0_227:                               ; %cond.load1333
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x13, v29[1]
	ld1.s	{ v28 }[1], [x13]
	add.2d	v29, v7, v31
	tbz	w12, #6, LBB0_205
LBB0_228:                               ; %cond.load1339
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x13, d29
	ld1.s	{ v28 }[2], [x13]
	tbz	w12, #7, LBB0_206
LBB0_229:                               ; %cond.load1345
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x12, v29[1]
	ld1.s	{ v28 }[3], [x12]
	fdiv.4s	v25, v25, v5
	fmov	w12, s19
	fmul.4s	v25, v25, v26
	add	x11, x8, x11, lsl #5
	tbz	w12, #0, LBB0_207
LBB0_230:                               ; %cond.store1352
                                        ;   in Loop: Header=BB0_190 Depth=2
	str	s25, [x11]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_208
LBB0_231:                               ; %cond.store1354
                                        ;   in Loop: Header=BB0_190 Depth=2
	add	x13, x11, #4
	st1.s	{ v25 }[1], [x13]
	tbz	w12, #2, LBB0_209
LBB0_232:                               ; %cond.store1356
                                        ;   in Loop: Header=BB0_190 Depth=2
	add	x13, x11, #8
	st1.s	{ v25 }[2], [x13]
	tbz	w12, #3, LBB0_210
LBB0_233:                               ; %cond.store1358
                                        ;   in Loop: Header=BB0_190 Depth=2
	add	x13, x11, #12
	st1.s	{ v25 }[3], [x13]
	fdiv.4s	v25, v27, v5
	fmul.4s	v25, v25, v28
	tbz	w12, #4, LBB0_211
LBB0_234:                               ; %cond.store1360
                                        ;   in Loop: Header=BB0_190 Depth=2
	str	s25, [x11, #16]
	tbz	w12, #5, LBB0_212
LBB0_235:                               ; %cond.store1362
                                        ;   in Loop: Header=BB0_190 Depth=2
	add	x13, x11, #20
	st1.s	{ v25 }[1], [x13]
	tbz	w12, #6, LBB0_213
LBB0_236:                               ; %cond.store1364
                                        ;   in Loop: Header=BB0_190 Depth=2
	add	x13, x11, #24
	st1.s	{ v25 }[2], [x13]
	tbz	w12, #7, LBB0_189
LBB0_237:                               ; %cond.store1366
                                        ;   in Loop: Header=BB0_190 Depth=2
	add	x11, x11, #28
	st1.s	{ v25 }[3], [x11]
	b	LBB0_189
LBB0_238:                               ; %direct.false110.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x23, x9
	ldp	q7, q6, [x8]
	zip1.8b	v16, v13, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	and.16b	v7, v16, v7
	fmov	w8, s2
	fdiv.4s	v7, v7, v5
	add	x11, sp, #1376
	add	x11, x11, x9
	ldp	q17, q2, [x11]
	and.16b	v16, v16, v17
	fmul.4s	v7, v7, v16
	ldp	q16, q17, [sp, #256]            ; 32-byte Folded Reload
	ldp	q19, q18, [sp, #224]            ; 32-byte Folded Reload
	stp	q17, q18, [sp, #720]
	stp	q19, q16, [sp, #752]
	and	x11, x28, #0x7
	add	x12, sp, #720
	ldr	x11, [x12, x11, lsl #3]
	sub	x9, x11, x28
	add	x9, x3, x9, lsl #2
	tbnz	w8, #0, LBB0_259
; %bb.239:                              ; %else1370
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #1, LBB0_260
LBB0_240:                               ; %else1372
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #2, LBB0_261
LBB0_241:                               ; %else1374
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #3, LBB0_243
LBB0_242:                               ; %cond.store1375
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #12
	st1.s	{ v7 }[3], [x11]
LBB0_243:                               ; %else1376
                                        ;   in Loop: Header=BB0_3 Depth=1
	zip2.8b	v7, v13, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v6, v7, v6
	fdiv.4s	v5, v6, v5
	and.16b	v2, v7, v2
	fmul.4s	v2, v5, v2
	tbnz	w8, #4, LBB0_262
; %bb.244:                              ; %else1378
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #5, LBB0_263
LBB0_245:                               ; %else1380
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #6, LBB0_264
LBB0_246:                               ; %else1382
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #7, LBB0_2
	b	LBB0_265
LBB0_247:                               ; %cond.load951
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	s28, [x8]
	tbz	w13, #1, LBB0_70
LBB0_248:                               ; %cond.load954
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x8, #4
	ld1.s	{ v28 }[1], [x12]
	tbz	w13, #2, LBB0_71
LBB0_249:                               ; %cond.load957
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x8, #8
	ld1.s	{ v28 }[2], [x12]
	tbz	w13, #3, LBB0_72
LBB0_250:                               ; %cond.load960
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x8, #12
	ld1.s	{ v28 }[3], [x12]
	tbz	w13, #4, LBB0_73
LBB0_251:                               ; %cond.load963
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x8, #16
	ld1.s	{ v29 }[0], [x12]
	tbz	w13, #5, LBB0_74
LBB0_252:                               ; %cond.load966
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x8, #20
	ld1.s	{ v29 }[1], [x12]
	tbz	w13, #6, LBB0_75
LBB0_253:                               ; %cond.load969
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x8, #24
	ld1.s	{ v29 }[2], [x12]
	tbnz	w13, #7, LBB0_76
	b	LBB0_77
LBB0_254:                               ; %cond.load1235
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x11, #8
	ld1.s	{ v20 }[2], [x12]
	tbz	w8, #3, LBB0_183
LBB0_255:                               ; %cond.load1238
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x11, #12
	ld1.s	{ v20 }[3], [x12]
	tbz	w8, #4, LBB0_184
LBB0_256:                               ; %cond.load1241
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x11, #16
	ld1.s	{ v21 }[0], [x12]
	tbz	w8, #5, LBB0_185
LBB0_257:                               ; %cond.load1244
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x11, #20
	ld1.s	{ v21 }[1], [x12]
	tbz	w8, #6, LBB0_186
LBB0_258:                               ; %cond.load1247
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x11, #24
	ld1.s	{ v21 }[2], [x12]
	tbnz	w8, #7, LBB0_187
	b	LBB0_188
LBB0_259:                               ; %cond.store1369
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s7, [x9]
	tbz	w8, #1, LBB0_240
LBB0_260:                               ; %cond.store1371
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #4
	st1.s	{ v7 }[1], [x11]
	tbz	w8, #2, LBB0_241
LBB0_261:                               ; %cond.store1373
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #8
	st1.s	{ v7 }[2], [x11]
	tbnz	w8, #3, LBB0_242
	b	LBB0_243
LBB0_262:                               ; %cond.store1377
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s2, [x9, #16]
	tbz	w8, #5, LBB0_245
LBB0_263:                               ; %cond.store1379
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #20
	st1.s	{ v2 }[1], [x11]
	tbz	w8, #6, LBB0_246
LBB0_264:                               ; %cond.store1381
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #24
	st1.s	{ v2 }[2], [x11]
	tbz	w8, #7, LBB0_2
LBB0_265:                               ; %cond.store1383
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x9, #28
	st1.s	{ v2 }[3], [x8]
	b	LBB0_2
LBB0_266:                               ; %block.batch.exit.loopexit
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	stp	w26, w2, [x9]
	str	w0, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
LBB0_267:                               ; %block.batch.exit
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #1440
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh20, Lloh21
                                        ; -- End function
.subsections_via_symbols

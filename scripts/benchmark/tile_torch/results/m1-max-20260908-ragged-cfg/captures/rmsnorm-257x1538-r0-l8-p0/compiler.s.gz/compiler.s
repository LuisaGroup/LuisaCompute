	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_4:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_8:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_9:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_10:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_11:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_3:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #4, lsl #12             ; =16384
	sub	sp, sp, #800
	fmov	s1, wzr
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #712
	add	x9, sp, #800
	str	wzr, [x9, #16380]
	stur	wzr, [x8, #81]
	stur	xzr, [x8, #52]
	stur	xzr, [x8, #68]
	stur	xzr, [x8, #60]
	stur	xzr, [x8, #20]
	stur	xzr, [x8, #36]
	stur	xzr, [x8, #28]
	str	xzr, [sp, #17104]
	str	xzr, [sp, #17096]
	ldr	x6, [x0]
	ldr	x7, [x0, #16]
	ldr	x19, [x0, #48]
	ldr	w9, [x1]
	ldr	w10, [x1, #36]
	dup.4s	v0, w2
Lloh0:
	adrp	x11, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x11, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x11, lCPI0_1@PAGE
Lloh3:
	ldr	q3, [x11, lCPI0_1@PAGEOFF]
	cmhi.4s	v3, v0, v3
	cmhi.4s	v0, v0, v2
	uzp1.8h	v2, v0, v3
	xtn.8b	v0, v2
Lloh4:
	adrp	x11, lCPI0_2@PAGE
Lloh5:
	ldr	q3, [x11, lCPI0_2@PAGEOFF]
	and.16b	v3, v2, v3
	addv.8h	h3, v3
	fmov	w11, s3
	and	w11, w11, #0xff
	fmov	s3, w11
	cmeq.8b	v1, v3, v1
	umov.b	w11, v1[0]
	and	w12, w11, #0x1
	fmov	s1, w12
	ubfx	w12, w11, #1, #1
	mov.b	v1[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v1[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v1[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v1[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v1[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v1[6], w12
	ubfx	w11, w11, #7, #1
	mov.b	v1[7], w11
	movi.8b	v3, #1
	eor.8b	v1, v1, v3
	and.8b	v1, v1, v0
	umaxv.8h	h2, v2
	fmov	w11, s2
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
Lloh6:
	adrp	x12, lCPI0_3@PAGE
Lloh7:
	ldr	d2, [x12, lCPI0_3@PAGEOFF]
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x8, #80]
	add	x12, sp, #792
	str	wzr, [x12, #16380]
	add	x12, sp, #764
	str	wzr, [x12, #16380]
	add	x12, sp, #760
	str	wzr, [x12, #16380]
	add	x12, sp, #732
	str	wzr, [x12, #16380]
	tbz	w11, #0, LBB0_376
; %bb.1:                                ; %scheduler.dispatch.preheader
	mov	w30, #0                         ; =0x0
	stp	xzr, xzr, [sp, #64]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #48]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #32]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #16]             ; 16-byte Folded Spill
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #2728
	dup.2d	v3, x20
	add	x11, sp, #1, lsl #12            ; =4096
	add	x11, x11, #648
	dup.2d	v1, x11
	stp	q3, q1, [sp, #96]               ; 32-byte Folded Spill
	add	w9, w10, w9, lsl #5
	dup.4s	v1, w9
	str	q1, [sp, #80]                   ; 16-byte Folded Spill
	mov	w9, #6144                       ; =0x1800
	add	x9, x7, x9
	str	x9, [sp, #160]                  ; 8-byte Folded Spill
	movi.2d	v18, #0000000000000000
	mov	w16, #1                         ; =0x1
	add	x23, sp, #4, lsl #12            ; =16384
	add	x23, x23, #792
	add	x25, sp, #4, lsl #12            ; =16384
	add	x25, x25, #760
	add	x26, sp, #4, lsl #12            ; =16384
	add	x26, x26, #728
	adrp	x27, lCPI0_8@PAGE
	add	x28, sp, #4, lsl #12            ; =16384
	add	x28, x28, #720
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #1040]                 ; 16-byte Folded Spill
	movi.2d	v23, #0000000000000000
	movi.2d	v28, #0000000000000000
	str	q1, [sp, #832]                  ; 16-byte Folded Spill
	str	q1, [sp, #304]                  ; 16-byte Folded Spill
	movi.2d	v29, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v27, #0000000000000000
	stp	q1, q1, [sp, #544]              ; 32-byte Folded Spill
	str	q1, [sp, #528]                  ; 16-byte Folded Spill
	stp	q1, q1, [sp, #576]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #960]              ; 32-byte Folded Spill
	movi.2d	v26, #0000000000000000
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #352
	mov	w4, #-1                         ; =0xffffffff
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #320
	mov	w5, #192                        ; =0xc0
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #96
	add	x3, sp, #3536
	mov	w9, #1                          ; =0x1
	str	q1, [sp, #944]                  ; 16-byte Folded Spill
	stp	q1, q1, [sp, #240]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #272]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #608]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #800]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #1008]             ; 32-byte Folded Spill
	stp	q1, q1, [sp, #848]              ; 32-byte Folded Spill
	movi.2d	v22, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v11, #0000000000000000
	str	q1, [sp, #784]                  ; 16-byte Folded Spill
	movi.2d	v15, #0000000000000000
	movi.2d	v19, #0000000000000000
	str	q1, [sp, #992]                  ; 16-byte Folded Spill
	stp	q1, q1, [sp, #416]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #384]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #912]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #880]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #672]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #640]              ; 32-byte Folded Spill
	movi.2d	v24, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v5, #0000000000000000
	str	q1, [sp, #1056]                 ; 16-byte Folded Spill
	str	q1, [sp, #1072]                 ; 16-byte Folded Spill
	str	q1, [sp, #1088]                 ; 16-byte Folded Spill
	str	q1, [sp, #1104]                 ; 16-byte Folded Spill
	stp	x7, x6, [sp, #144]              ; 16-byte Folded Spill
	str	x19, [sp, #136]                 ; 8-byte Folded Spill
	b	LBB0_5
LBB0_2:                                 ; %ready.overflow.resume43
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b3, [x23, w9, uxtw]
	orr	w30, w10, w30
	mov	w10, #5                         ; =0x5
LBB0_3:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	w10, [x25, w9, uxtw #2]
	add	w24, w9, #1
	str	w11, [x26, w9, uxtw #2]
LBB0_4:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	x9, x24
	cbz	w24, LBB0_376
LBB0_5:                                 ; %scheduler.dispatch
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_59 Depth 2
                                        ;     Child Loop BB0_156 Depth 2
                                        ;     Child Loop BB0_172 Depth 2
                                        ;     Child Loop BB0_225 Depth 2
                                        ;     Child Loop BB0_250 Depth 2
                                        ;     Child Loop BB0_325 Depth 2
                                        ;     Child Loop BB0_357 Depth 2
	sub	w24, w9, #1
	ldr	w10, [x25, w24, sxtw #2]
	cmp	w10, #20
	b.hi	LBB0_378
; %bb.6:                                ; %scheduler.dispatch
                                        ;   in Loop: Header=BB0_5 Depth=1
	sxtw	x21, w24
	ldrb	w11, [x23, x21]
	and	w13, w11, #0x1
	fmov	s21, w13
	ubfx	w13, w11, #1, #1
	mov.b	v21[1], w13
	ubfx	w13, w11, #2, #1
	mov.b	v21[2], w13
	ubfx	w13, w11, #3, #1
	mov.b	v21[3], w13
	ubfx	w13, w11, #4, #1
	mov.b	v21[4], w13
	ubfx	w13, w11, #5, #1
	mov.b	v21[5], w13
	ubfx	w13, w11, #6, #1
	mov.b	v21[6], w13
	lsr	w11, w11, #7
	mov.b	v21[7], w11
	ldr	w14, [x26, w24, sxtw #2]
Lloh8:
	adrp	x12, LJTI0_0@PAGE
Lloh9:
	add	x12, x12, LJTI0_0@PAGEOFF
	adr	x11, LBB0_7
	ldrh	w13, [x12, x10, lsl #1]
	add	x11, x11, x13, lsl #2
	br	x11
LBB0_7:                                 ; %schedule.0
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b1, v1
	fmov	w10, s1
	mov	b1, v21[6]
	mov.b	v1[4], v21[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
Lloh10:
	adrp	x11, lCPI0_4@PAGE
Lloh11:
	ldr	q3, [x11, lCPI0_4@PAGEOFF]
	bit.16b	v5, v3, v1
	mov	b3, v21[4]
	mov.b	v3[4], v21[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
Lloh12:
	adrp	x11, lCPI0_5@PAGE
Lloh13:
	ldr	q4, [x11, lCPI0_5@PAGEOFF]
	mov	b6, v21[2]
	mov.b	v6[4], v21[3]
	bit.16b	v31, v4, v3
	ushll.2d	v4, v6, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
Lloh14:
	adrp	x11, lCPI0_6@PAGE
Lloh15:
	ldr	q6, [x11, lCPI0_6@PAGEOFF]
	bit.16b	v14, v6, v4
	mov	b6, v21[0]
	mov.b	v6[4], v21[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
Lloh16:
	adrp	x11, lCPI0_7@PAGE
Lloh17:
	ldr	q7, [x11, lCPI0_7@PAGEOFF]
	mov.16b	v30, v6
	bsl.16b	v30, v7, v24
	zip1.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	mov.16b	v24, v19
	ldr	q19, [sp, #80]                  ; 16-byte Folded Reload
	and.16b	v16, v7, v19
	zip2.8b	v17, v21, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v19, v17, v19
	movi.4s	v20, #3
	and.16b	v7, v7, v20
	and.16b	v17, v17, v20
	neg.4s	v17, v17
	ushl.4s	v17, v19, v17
	neg.4s	v7, v7
	ushl.4s	v7, v16, v7
	ushll.2d	v16, v7, #0
	ushll2.2d	v7, v7, #0
	ushll.2d	v19, v17, #0
	ushll2.2d	v17, v17, #0
	ldr	q20, [sp, #640]                 ; 16-byte Folded Reload
	bit.16b	v20, v17, v1
	ldr	q17, [sp, #656]                 ; 16-byte Folded Reload
	bit.16b	v17, v19, v3
	stp	q20, q17, [sp, #640]            ; 32-byte Folded Spill
	ldr	q17, [sp, #672]                 ; 16-byte Folded Reload
	bit.16b	v17, v7, v4
	ldr	q7, [sp, #688]                  ; 16-byte Folded Reload
	bit.16b	v7, v16, v6
	stp	q17, q7, [sp, #672]             ; 32-byte Folded Spill
	ldr	q7, [sp, #96]                   ; 16-byte Folded Reload
	ldr	q16, [sp, #384]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v1
	str	q16, [sp, #384]                 ; 16-byte Folded Spill
	ldr	q16, [sp, #400]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v3
	str	q16, [sp, #400]                 ; 16-byte Folded Spill
	ldr	q16, [sp, #416]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v4
	str	q16, [sp, #416]                 ; 16-byte Folded Spill
	ldr	q16, [sp, #432]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v6
	str	q16, [sp, #432]                 ; 16-byte Folded Spill
	ldr	q7, [x27, lCPI0_8@PAGEOFF]
	ldr	q16, [sp, #880]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v1
	str	q16, [sp, #880]                 ; 16-byte Folded Spill
Lloh18:
	adrp	x11, lCPI0_9@PAGE
Lloh19:
	ldr	q7, [x11, lCPI0_9@PAGEOFF]
	ldr	q16, [sp, #896]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v3
	str	q16, [sp, #896]                 ; 16-byte Folded Spill
Lloh20:
	adrp	x11, lCPI0_10@PAGE
Lloh21:
	ldr	q7, [x11, lCPI0_10@PAGEOFF]
	ldr	q16, [sp, #912]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v4
	str	q16, [sp, #912]                 ; 16-byte Folded Spill
Lloh22:
	adrp	x11, lCPI0_11@PAGE
Lloh23:
	ldr	q7, [x11, lCPI0_11@PAGEOFF]
	ldr	q16, [sp, #928]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v6
	str	q16, [sp, #928]                 ; 16-byte Folded Spill
	ldr	q7, [sp, #992]                  ; 16-byte Folded Reload
	bic.16b	v7, v7, v1
	str	q7, [sp, #992]                  ; 16-byte Folded Spill
	bic.16b	v19, v24, v3
	bic.16b	v15, v15, v4
	ldr	q1, [sp, #784]                  ; 16-byte Folded Reload
	bic.16b	v1, v1, v6
	str	q1, [sp, #784]                  ; 16-byte Folded Spill
	tbz	w10, #0, LBB0_75
; %bb.8:                                ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v24, v30
	b	LBB0_18
LBB0_9:                                 ; %scheduler.dispatch.schedule.9_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w10, s1
	b	LBB0_169
LBB0_10:                                ; %scheduler.dispatch.schedule.4_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_47
LBB0_11:                                ; %schedule.2
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w10, s3
	rbit	w10, w10
	clz	w10, w10
	umaxv.8b	b1, v1
	fmov	w11, s1
	eor	w3, w11, #0x1
	tst	w11, #0x1
	csel	w10, w10, wzr, ne
	b	LBB0_21
LBB0_12:                                ; %scheduler.dispatch.schedule.7_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b1, v1
	fmov	w10, s1
	eor	w11, w10, #0x1
	b	LBB0_87
LBB0_13:                                ; %scheduler.dispatch.schedule.12_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_189
LBB0_14:                                ; %scheduler.dispatch.schedule.19_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_338
LBB0_15:                                ; %scheduler.dispatch.schedule.3_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_39
LBB0_16:                                ; %scheduler.dispatch.schedule.14_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_238
LBB0_17:                                ; %scheduler.dispatch.schedule.17_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	b	LBB0_273
LBB0_18:                                ; %schedule.1
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w13, s1
	rbit	w10, w11
	clz	w10, w10
	tst	w13, #0x1
	csel	w13, w10, wzr, ne
	ldr	q1, [sp, #784]                  ; 16-byte Folded Reload
	str	q1, [sp, #4672]
	str	q15, [sp, #4688]
	str	q19, [sp, #4704]
	ldr	q1, [sp, #992]                  ; 16-byte Folded Reload
	str	q1, [sp, #4720]
	and	x13, x13, #0x7
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #576
	ldr	x13, [x12, x13, lsl #3]
	cmp	x13, #192
	b.ge	LBB0_38
; %bb.19:                               ; %uniform.true
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_72
; %bb.20:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	w3, #0                          ; =0x0
LBB0_21:                                ; %schedule.2.thread
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q1, [sp, #784]                  ; 16-byte Folded Reload
	str	q1, [sp, #1312]
	str	q15, [sp, #1328]
	str	q19, [sp, #1344]
	ldr	q1, [sp, #992]                  ; 16-byte Folded Reload
	str	q1, [sp, #1360]
	mov	w13, w10
	ubfiz	x15, x13, #3, #3
	add	x11, sp, #1312
	ldr	x11, [x11, x15]
	lsl	x0, x11, #3
	dup.2d	v1, x0
	add.2d	v3, v1, v24
	add.2d	v4, v1, v14
	add.2d	v6, v1, v31
	add.2d	v1, v1, v5
	ldr	q7, [sp, #688]                  ; 16-byte Folded Reload
	str	q7, [sp, #1184]
	ldr	q7, [sp, #672]                  ; 16-byte Folded Reload
	str	q7, [sp, #1200]
	ldr	q7, [sp, #656]                  ; 16-byte Folded Reload
	str	q7, [sp, #1216]
	ldr	q7, [sp, #640]                  ; 16-byte Folded Reload
	str	q7, [sp, #1232]
	add	x12, sp, #1184
	ldr	x0, [x12, x15]
	str	q1, [sp, #1296]
	str	q6, [sp, #1280]
	str	q4, [sp, #1264]
	str	q3, [sp, #1248]
	add	x12, sp, #1248
	ldr	x15, [x12, x15]
	neg	x2, x13
	mov	w12, #1538                      ; =0x602
	madd	x0, x0, x12, x2
	add	x15, x0, x15
	add	x15, x6, x15, lsl #2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w0, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w0, #0, LBB0_31
; %bb.22:                               ; %else
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w0, #1, LBB0_32
LBB0_23:                                ; %else80
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w0, #2, LBB0_33
LBB0_24:                                ; %else83
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w0, #3, LBB0_34
LBB0_25:                                ; %else86
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w0, #4, LBB0_35
LBB0_26:                                ; %else89
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w0, #5, LBB0_36
LBB0_27:                                ; %else92
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w0, #6, LBB0_37
LBB0_28:                                ; %else95
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w0, #7, LBB0_30
LBB0_29:                                ; %cond.load97
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x15, #28
	ld1.s	{ v3 }[3], [x15]
LBB0_30:                                ; %else98
                                        ;   in Loop: Header=BB0_5 Depth=1
	lsl	x15, x11, #5
	dup.2d	v4, x15
	ldp	q6, q17, [sp, #880]             ; 32-byte Folded Reload
	add.2d	v6, v4, v6
	ldp	q16, q7, [sp, #912]             ; 32-byte Folded Reload
	add.2d	v7, v4, v7
	add.2d	v16, v4, v16
	add.2d	v4, v4, v17
	str	q16, [sp, #1136]
	str	q7, [sp, #1120]
	str	q4, [sp, #1152]
	str	q6, [sp, #1168]
	and	x10, x10, #0x7
	add	x12, sp, #1120
	ldr	x10, [x12, x10, lsl #3]
	sub	x13, x10, x13, lsl #2
	ands	w10, w3, #0x1
	csel	x13, xzr, x13, ne
	add	x13, x20, x13
	ldp	q4, q6, [x13]
	zip2.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bif.16b	v3, v6, v7
	zip1.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bif.16b	v1, v4, v6
	stp	q1, q3, [x13]
	add	x11, x11, #1
	dup.2d	v1, x11
	mov	b3, v21[6]
	mov.b	v3[4], v21[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q4, [sp, #992]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #992]                  ; 16-byte Folded Spill
	mov	b3, v21[4]
	mov.b	v3[4], v21[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	mov	b4, v21[2]
	mov.b	v4[4], v21[3]
	bit.16b	v19, v1, v3
	ushll.2d	v3, v4, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	bit.16b	v15, v1, v3
	mov	b3, v21[0]
	mov.b	v3[4], v21[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q4, [sp, #784]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #784]                  ; 16-byte Folded Spill
	add	x3, sp, #3536
	cbnz	w10, LBB0_4
	b	LBB0_18
LBB0_31:                                ; %cond.load
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s1, [x15]
	tbz	w0, #1, LBB0_23
LBB0_32:                                ; %cond.load79
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x2, x15, #4
	ld1.s	{ v1 }[1], [x2]
	tbz	w0, #2, LBB0_24
LBB0_33:                                ; %cond.load82
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x2, x15, #8
	ld1.s	{ v1 }[2], [x2]
	tbz	w0, #3, LBB0_25
LBB0_34:                                ; %cond.load85
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x2, x15, #12
	ld1.s	{ v1 }[3], [x2]
	tbz	w0, #4, LBB0_26
LBB0_35:                                ; %cond.load88
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x2, x15, #16
	ld1.s	{ v3 }[0], [x2]
	tbz	w0, #5, LBB0_27
LBB0_36:                                ; %cond.load91
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x2, x15, #20
	ld1.s	{ v3 }[1], [x2]
	tbz	w0, #6, LBB0_28
LBB0_37:                                ; %cond.load94
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x2, x15, #24
	ld1.s	{ v3 }[2], [x2]
	tbnz	w0, #7, LBB0_29
	b	LBB0_30
LBB0_38:                                ; %uniform.false
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_39:                                ; %schedule.3
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w10, #2                         ; =0x2
	dup.2d	v3, x10
	cmgt.2d	v1, v3, v14
	cmgt.2d	v4, v3, v24
	uzp1.4s	v1, v4, v1
	cmgt.2d	v4, v3, v31
	cmgt.2d	v6, v3, v5
	uzp1.4s	v4, v4, v6
	uzp1.8h	v1, v1, v4
	xtn.8b	v1, v1
	shl.8b	v4, v21, #7
	cmlt.8b	v4, v4, #0
	bit.8b	v11, v1, v4
	and.8b	v1, v21, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v4, v1, #0
	and.8b	v1, v4, v2
	addv.8b	b1, v1
	umaxv.8b	b4, v4
	fmov	w10, s4
	tbz	w10, #0, LBB0_45
; %bb.40:                               ; %schedule.3
                                        ;   in Loop: Header=BB0_5 Depth=1
	cmge.2d	v4, v14, v3
	cmge.2d	v6, v24, v3
	uzp1.4s	v4, v6, v4
	cmge.2d	v6, v31, v3
	cmge.2d	v3, v5, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v3, v21, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w10, s3
	tst	w10, #0xff
	b.eq	LBB0_45
; %bb.41:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w10, w14, #1
	csel	w10, wzr, w10, lo
	and	w11, w30, #0xff
	lsr	w13, w11, w10
	tst	w13, #0x1
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #1504]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #1520]
	and	x10, x10, #0x7
	add	x12, sp, #1504
	ldr	w10, [x12, x10, lsl #2]
	ccmp	w14, #0, #4, ne
	ccmp	w10, #0, #0, ne
	cset	w10, ne
	cmp	w11, #255
	b.ne	LBB0_43
; %bb.42:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #0, LBB0_378
LBB0_43:                                ; %convergence.overflow.resume
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w11, w30
	rbit	w11, w11
	clz	w11, w11
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w30
	csel	w11, wzr, w11, eq
	ubfiz	x13, x11, #2, #3
	lsl	w15, w16, w11
	ldr	q6, [sp, #1088]                 ; 16-byte Folded Reload
	str	q6, [sp, #1472]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #1488]
	add	x12, sp, #1472
	ldr	w0, [x12, x13]
	cmp	w10, #0
	csel	w10, w15, wzr, ne
	csel	w15, wzr, w0, ne
	str	q6, [sp, #1440]
	str	q4, [sp, #1456]
	add	x12, sp, #1440
	str	w15, [x12, x13]
	ldr	q4, [sp, #1456]
	str	q4, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #1440]
	str	q4, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1056]                 ; 16-byte Folded Reload
	str	q6, [sp, #1408]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #1424]
	add	x12, sp, #1408
	ldr	w15, [x12, x13]
	csel	w15, w14, w15, ne
	str	q6, [sp, #1376]
	str	q4, [sp, #1392]
	add	x12, sp, #1376
	str	w15, [x12, x13]
	ldrb	w13, [x28, x11]
	and	w15, w13, #0x1
	fmov	s4, w15
	ubfx	w15, w13, #1, #1
	mov.b	v4[1], w15
	ubfx	w15, w13, #2, #1
	mov.b	v4[2], w15
	ubfx	w15, w13, #3, #1
	mov.b	v4[3], w15
	ubfx	w15, w13, #4, #1
	mov.b	v4[4], w15
	ubfx	w15, w13, #5, #1
	mov.b	v4[5], w15
	ubfx	w15, w13, #6, #1
	mov.b	v4[6], w15
	ldr	q6, [sp, #1392]
	str	q6, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1376]
	str	q6, [sp, #1056]                 ; 16-byte Folded Spill
	lsr	w13, w13, #7
	mov.b	v4[7], w13
	ldrb	w13, [x8, x11]
	and	w15, w13, #0x1
	fmov	s6, w15
	ubfx	w15, w13, #1, #1
	mov.b	v6[1], w15
	ubfx	w15, w13, #2, #1
	mov.b	v6[2], w15
	ubfx	w15, w13, #3, #1
	mov.b	v6[3], w15
	ubfx	w15, w13, #4, #1
	mov.b	v6[4], w15
	ubfx	w15, w13, #5, #1
	mov.b	v6[5], w15
	ubfx	w15, w13, #6, #1
	mov.b	v6[6], w15
	lsr	w13, w13, #7
	mov.b	v6[7], w13
	csetm	w13, ne
	dup.8b	v7, w13
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x28, x11]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x11]
	csinc	w11, w14, w11, eq
	cmp	w24, #8
	b.hs	LBB0_378
; %bb.44:                               ; %ready.overflow.resume41
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b1, [x23, x21]
	mov	w12, #4                         ; =0x4
	str	w12, [x25, x21, lsl #2]
	str	w11, [x26, x21, lsl #2]
	cmp	w9, #8
	b.lo	LBB0_2
	b	LBB0_378
LBB0_45:                                ; %varying.coherent
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	w10, s1
	tst	w10, #0xff
	b.eq	LBB0_73
; %bb.46:                               ; %varying.coherent.true
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_47:                                ; %schedule.4
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w10, w11
	clz	w10, w10
	tst	w11, #0xff
	csel	w10, wzr, w10, eq
	ldp	q1, q3, [sp, #672]              ; 32-byte Folded Reload
	str	q3, [sp, #4608]
	str	q1, [sp, #4624]
	ldp	q1, q3, [sp, #640]              ; 32-byte Folded Reload
	str	q3, [sp, #4640]
	str	q1, [sp, #4656]
	ubfiz	x13, x10, #3, #3
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #512
	ldr	x15, [x12, x13]
	str	q24, [sp, #4544]
	str	q14, [sp, #4560]
	str	q31, [sp, #4576]
	str	q5, [sp, #4592]
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #448
	ldr	x13, [x12, x13]
	sub	x13, x13, x10
	mov	w12, #1538                      ; =0x602
	madd	x13, x15, x12, x13
	add	x13, x6, x13, lsl #2
	mov	w12, #6144                      ; =0x1800
	add	x13, x13, x12
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w15, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w15, #0, LBB0_65
; %bb.48:                               ; %else102
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w15, #1, LBB0_66
LBB0_49:                                ; %else105
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w15, #2, LBB0_67
LBB0_50:                                ; %else108
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w15, #3, LBB0_68
LBB0_51:                                ; %else111
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w15, #4, LBB0_69
LBB0_52:                                ; %else114
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w15, #5, LBB0_70
LBB0_53:                                ; %else117
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w15, #6, LBB0_71
LBB0_54:                                ; %else120
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w15, #7, LBB0_56
LBB0_55:                                ; %cond.load122
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x13, x13, #28
	ld1.s	{ v3 }[3], [x13]
LBB0_56:                                ; %else123
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldp	q4, q6, [sp, #912]              ; 32-byte Folded Reload
	str	q6, [sp, #4480]
	str	q4, [sp, #4496]
	ldp	q4, q6, [sp, #880]              ; 32-byte Folded Reload
	str	q6, [sp, #4512]
	str	q4, [sp, #4528]
	and	x13, x10, #0x7
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #384
	ldr	x13, [x12, x13, lsl #3]
	sub	x10, x13, x10, lsl #2
	mov	w12, #6144                      ; =0x1800
	add	x10, x10, x12
	ands	w11, w11, #0xff
	csel	x10, xzr, x10, eq
	add	x10, x20, x10
	ldp	q4, q6, [x10]
	zip2.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bif.16b	v3, v6, v7
	zip1.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bif.16b	v1, v4, v6
	stp	q1, q3, [x10]
	cbz	w11, LBB0_4
LBB0_57:                                ; %schedule.5
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w14, LBB0_62
; %bb.58:                               ; %convergence.cascade.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w10, #0                         ; =0x0
LBB0_59:                                ; %convergence.cascade
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w2, s1
	sub	w13, w14, #1
	tst	w11, #0xff
	csel	w13, w13, wzr, ne
	lsl	w15, w16, w13
	and	w11, w15, w30
	tst	w11, #0xff
	cset	w3, ne
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #4448]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #4464]
	ubfiz	x11, x13, #2, #3
	ldr	w0, [x17, x11]
	cmp	w0, #0
	cset	w0, eq
	and	w2, w3, w2
	ldrb	w3, [x28, w13, sxtw]
	and	w5, w3, #0x1
	fmov	s1, w5
	ubfx	w5, w3, #1, #1
	mov.b	v1[1], w5
	ubfx	w5, w3, #2, #1
	mov.b	v1[2], w5
	ubfx	w5, w3, #3, #1
	mov.b	v1[3], w5
	ubfx	w5, w3, #4, #1
	mov.b	v1[4], w5
	ubfx	w5, w3, #5, #1
	mov.b	v1[5], w5
	ubfx	w5, w3, #6, #1
	mov.b	v1[6], w5
	lsr	w3, w3, #7
	mov.b	v1[7], w3
	ldrb	w3, [x8, w13, sxtw]
	and	w5, w3, #0x1
	fmov	s3, w5
	ubfx	w5, w3, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w3, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w3, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w3, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w3, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w3, #6, #1
	mov.b	v3[6], w5
	lsr	w3, w3, #7
	mov.b	v3[7], w3
	orr.8b	v4, v21, v3
	and.8b	v6, v0, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w3, s6
	ands	w0, w2, w0
	csetm	w2, ne
	bics	w3, w0, w3
	csetm	w5, ne
	dup.8b	v6, w5
	dup.8b	v7, w2
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w13, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x28, w13, sxtw]
	csinv	w13, w4, w15, eq
	dup.8b	v1, w0
	and	w30, w13, w30
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w3
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #4416]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #4432]
	ldr	w11, [x1, x11]
	csel	w14, w11, w14, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w0, #1
	b.ne	LBB0_63
; %bb.60:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_59 Depth=2
	cmp	w14, #0
	ccmp	w10, #6, #2, ne
	b.hi	LBB0_63
; %bb.61:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_59 Depth=2
	add	w10, w10, #1
	tst	w11, #0xff
	b.ne	LBB0_59
	b	LBB0_63
LBB0_62:                                ; %schedule.5.convergence.cascade.exit_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_63:                                ; %convergence.cascade.exit
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_76
; %bb.64:                               ; %convergence.target.5.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w10, w11
	clz	w10, w10
	ldp	q1, q3, [sp, #912]              ; 32-byte Folded Reload
	str	q3, [sp, #4352]
	str	q1, [sp, #4368]
	ldp	q1, q3, [sp, #880]              ; 32-byte Folded Reload
	str	q3, [sp, #4384]
	str	q1, [sp, #4400]
	and	x11, x10, #0x7
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #256
	ldr	x11, [x12, x11, lsl #3]
	lsl	w10, w10, #2
	sub	x10, x11, x10
	add	x10, x20, x10
	ldp	q1, q3, [x10]
	fmul.4s	v1, v1, v1
	fmul.4s	v3, v3, v3
	ldp	q4, q6, [x10, #32]
	str	q14, [sp, #768]                 ; 16-byte Folded Spill
	fmul.4s	v30, v4, v4
	fmul.4s	v14, v6, v6
	ldp	q7, q16, [x10, #64]
	fmul.4s	v7, v7, v7
	fmul.4s	v8, v16, v16
	str	q19, [sp, #368]                 ; 16-byte Folded Spill
	ldp	q19, q17, [x10, #96]
	mov.16b	v4, v11
	fmul.4s	v11, v19, v19
	fmul.4s	v17, v17, v17
	str	q4, [sp, #352]                  ; 16-byte Folded Spill
	mov	b20, v21[6]
	mov.b	v20[4], v21[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	mov	w10, #4                         ; =0x4
	mov.16b	v19, v12
	fmov	d12, d0
	mov.16b	v6, v24
	mov.16b	v0, v22
	mov.16b	v24, v28
	mov.16b	v28, v5
	mov.16b	v5, v18
	mov.16b	v22, v10
	mov.16b	v10, v0
	mov.16b	v0, v23
	dup.2d	v23, x10
	ldr	q4, [sp, #1024]                 ; 16-byte Folded Reload
	bit.16b	v4, v23, v20
	str	q4, [sp, #1024]                 ; 16-byte Folded Spill
	mov	b20, v21[4]
	mov.b	v20[4], v21[5]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	bit.16b	v9, v23, v20
	mov	b20, v21[2]
	mov.b	v20[4], v21[3]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	bit.16b	v13, v23, v20
	mov	b20, v21[0]
	mov.b	v20[4], v21[1]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	bit.16b	v10, v23, v20
	zip1.8b	v20, v21, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmlt.4s	v20, v20, #0
	zip2.8b	v23, v21, v0
	ushll.4s	v23, v23, #0
	shl.4s	v23, v23, #31
	cmlt.4s	v23, v23, #0
	ldr	q18, [sp, #848]                 ; 16-byte Folded Reload
	bit.16b	v18, v3, v23
	ldr	q3, [sp, #864]                  ; 16-byte Folded Reload
	bit.16b	v3, v1, v20
	stp	q18, q3, [sp, #848]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1008]                 ; 16-byte Folded Reload
	bit.16b	v1, v14, v23
	str	q1, [sp, #1008]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #800]                  ; 16-byte Folded Reload
	bit.16b	v1, v30, v20
	ldr	q14, [sp, #768]                 ; 16-byte Folded Reload
	str	q1, [sp, #800]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #816]                  ; 16-byte Folded Reload
	bit.16b	v1, v8, v23
	str	q1, [sp, #816]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #592]                  ; 16-byte Folded Reload
	bit.16b	v1, v7, v20
	str	q1, [sp, #592]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #624]                  ; 16-byte Folded Reload
	bit.16b	v1, v17, v23
	mov.16b	v23, v0
	mov.16b	v0, v10
	mov.16b	v10, v22
	str	q1, [sp, #624]                  ; 16-byte Folded Spill
	mov.16b	v18, v5
	mov.16b	v5, v28
	mov.16b	v28, v24
	mov.16b	v22, v0
	mov.16b	v24, v6
	fmov	d0, d12
	mov.16b	v12, v19
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	bit.16b	v1, v11, v20
	ldp	q11, q19, [sp, #352]            ; 32-byte Folded Reload
	str	q1, [sp, #608]                  ; 16-byte Folded Spill
	mov	w5, #192                        ; =0xc0
	add	x3, sp, #3536
	b	LBB0_77
LBB0_65:                                ; %cond.load101
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s1, [x13]
	tbz	w15, #1, LBB0_49
LBB0_66:                                ; %cond.load104
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x13, #4
	ld1.s	{ v1 }[1], [x0]
	tbz	w15, #2, LBB0_50
LBB0_67:                                ; %cond.load107
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x13, #8
	ld1.s	{ v1 }[2], [x0]
	tbz	w15, #3, LBB0_51
LBB0_68:                                ; %cond.load110
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x13, #12
	ld1.s	{ v1 }[3], [x0]
	tbz	w15, #4, LBB0_52
LBB0_69:                                ; %cond.load113
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x13, #16
	ld1.s	{ v3 }[0], [x0]
	tbz	w15, #5, LBB0_53
LBB0_70:                                ; %cond.load116
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x13, #20
	ld1.s	{ v3 }[1], [x0]
	tbz	w15, #6, LBB0_54
LBB0_71:                                ; %cond.load119
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x13, #24
	ld1.s	{ v3 }[2], [x0]
	tbnz	w15, #7, LBB0_55
	b	LBB0_56
LBB0_72:                                ;   in Loop: Header=BB0_5 Depth=1
	add	x3, sp, #3536
	b	LBB0_4
LBB0_73:                                ; %varying.coherent.false
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.ne	LBB0_57
	b	LBB0_4
LBB0_74:                                ;   in Loop: Header=BB0_5 Depth=1
	ldp	q18, q29, [sp, #720]            ; 32-byte Folded Reload
	ldp	q10, q12, [sp, #496]            ; 32-byte Folded Reload
	ldr	q27, [sp, #752]                 ; 16-byte Folded Reload
	ldp	q26, q23, [sp, #320]            ; 32-byte Folded Reload
	ldr	q3, [sp, #224]                  ; 16-byte Folded Reload
	ldr	q19, [sp, #368]                 ; 16-byte Folded Reload
	mov.16b	v5, v28
	mov.16b	v28, v3
LBB0_75:                                ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v24, v30
	b	LBB0_4
LBB0_76:                                ;   in Loop: Header=BB0_5 Depth=1
	mov	w5, #192                        ; =0xc0
	add	x3, sp, #3536
	b	LBB0_4
LBB0_77:                                ; %schedule.6
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w10, s1
	dup.2d	v3, x5
	cmgt.2d	v1, v3, v13
	cmgt.2d	v4, v3, v22
	uzp1.4s	v1, v4, v1
	cmgt.2d	v4, v3, v9
	ldr	q6, [sp, #1024]                 ; 16-byte Folded Reload
	cmgt.2d	v6, v3, v6
	uzp1.4s	v4, v4, v6
	uzp1.8h	v1, v1, v4
	xtn.8b	v1, v1
	and.8b	v1, v21, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v4, v1, #0
	and.8b	v1, v4, v2
	addv.8b	b1, v1
	fmov	w11, s1
	umaxv.8b	b4, v4
	fmov	w13, s4
	tbz	w13, #0, LBB0_84
; %bb.78:                               ; %schedule.6
                                        ;   in Loop: Header=BB0_5 Depth=1
	cmge.2d	v4, v13, v3
	cmge.2d	v6, v22, v3
	uzp1.4s	v4, v6, v4
	cmge.2d	v6, v9, v3
	ldr	q7, [sp, #1024]                 ; 16-byte Folded Reload
	cmge.2d	v3, v7, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v3, v21, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w13, s3
	tst	w13, #0xff
	b.eq	LBB0_84
; %bb.79:                               ; %varying.divergent69
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w10, w14, #1
	csel	w10, wzr, w10, lo
	and	w11, w30, #0xff
	lsr	w13, w11, w10
	tst	w13, #0x1
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #1664]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #1680]
	and	x10, x10, #0x7
	add	x12, sp, #1664
	ldr	w10, [x12, x10, lsl #2]
	ccmp	w14, #0, #4, ne
	ccmp	w10, #1, #0, ne
	cset	w10, ne
	cmp	w11, #255
	b.ne	LBB0_81
; %bb.80:                               ; %varying.divergent69
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #0, LBB0_378
LBB0_81:                                ; %convergence.overflow.resume72
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w11, w30
	rbit	w11, w11
	clz	w11, w11
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w30
	csel	w11, wzr, w11, eq
	ubfiz	x13, x11, #2, #3
	lsl	w15, w16, w11
	ldr	q6, [sp, #1088]                 ; 16-byte Folded Reload
	str	q6, [sp, #1632]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #1648]
	add	x12, sp, #1632
	ldr	w0, [x12, x13]
	cmp	w10, #0
	csel	w10, w15, wzr, ne
	csinc	w15, w0, wzr, eq
	str	q6, [sp, #1600]
	str	q4, [sp, #1616]
	add	x12, sp, #1600
	str	w15, [x12, x13]
	ldr	q4, [sp, #1616]
	str	q4, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #1600]
	str	q4, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1056]                 ; 16-byte Folded Reload
	str	q6, [sp, #1568]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #1584]
	add	x12, sp, #1568
	ldr	w15, [x12, x13]
	csel	w15, w14, w15, ne
	str	q6, [sp, #1536]
	str	q4, [sp, #1552]
	add	x12, sp, #1536
	str	w15, [x12, x13]
	ldrb	w13, [x28, x11]
	and	w15, w13, #0x1
	fmov	s4, w15
	ubfx	w15, w13, #1, #1
	mov.b	v4[1], w15
	ubfx	w15, w13, #2, #1
	mov.b	v4[2], w15
	ubfx	w15, w13, #3, #1
	mov.b	v4[3], w15
	ubfx	w15, w13, #4, #1
	mov.b	v4[4], w15
	ubfx	w15, w13, #5, #1
	mov.b	v4[5], w15
	ubfx	w15, w13, #6, #1
	mov.b	v4[6], w15
	ldr	q6, [sp, #1552]
	str	q6, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1536]
	str	q6, [sp, #1056]                 ; 16-byte Folded Spill
	lsr	w13, w13, #7
	mov.b	v4[7], w13
	ldrb	w13, [x8, x11]
	and	w15, w13, #0x1
	fmov	s6, w15
	ubfx	w15, w13, #1, #1
	mov.b	v6[1], w15
	ubfx	w15, w13, #2, #1
	mov.b	v6[2], w15
	ubfx	w15, w13, #3, #1
	mov.b	v6[3], w15
	ubfx	w15, w13, #4, #1
	mov.b	v6[4], w15
	ubfx	w15, w13, #5, #1
	mov.b	v6[5], w15
	ubfx	w15, w13, #6, #1
	mov.b	v6[6], w15
	lsr	w13, w13, #7
	mov.b	v6[7], w13
	csetm	w13, ne
	dup.8b	v7, w13
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x28, x11]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x11]
	csinc	w11, w14, w11, eq
	cmp	w24, #8
	b.hs	LBB0_378
; %bb.82:                               ; %ready.overflow.resume74
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b1, [x23, x21]
	mov	w12, #7                         ; =0x7
	str	w12, [x25, x21, lsl #2]
	str	w11, [x26, x21, lsl #2]
	cmp	w9, #8
	b.hs	LBB0_378
; %bb.83:                               ; %ready.overflow.resume76
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b3, [x23, w9, uxtw]
	orr	w30, w10, w30
	mov	w10, #8                         ; =0x8
	b	LBB0_3
LBB0_84:                                ; %varying.coherent70
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_153
; %bb.85:                               ; %varying.coherent.true77
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
; %bb.86:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	w11, #0                         ; =0x0
LBB0_87:                                ; %schedule.7
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v1, v24
	str	q1, [sp, #480]                  ; 16-byte Folded Spill
	mov.16b	v8, v28
	mov.16b	v1, v11
	mov.16b	v11, v5
	stp	q1, q19, [sp, #352]             ; 32-byte Folded Spill
	str	q23, [sp, #336]                 ; 16-byte Folded Spill
	str	q18, [sp, #720]                 ; 16-byte Folded Spill
	str	q22, [sp, #208]                 ; 16-byte Folded Spill
	shl.2d	v1, v22, #5
	shl.2d	v6, v13, #5
	shl.2d	v3, v9, #5
	ldr	q4, [sp, #1024]                 ; 16-byte Folded Reload
	shl.2d	v4, v4, #5
	ldr	q7, [sp, #880]                  ; 16-byte Folded Reload
	add.2d	v4, v4, v7
	ldr	q7, [sp, #896]                  ; 16-byte Folded Reload
	add.2d	v3, v3, v7
	ldr	q7, [sp, #912]                  ; 16-byte Folded Reload
	add.2d	v16, v6, v7
	ldp	q6, q5, [sp, #928]              ; 32-byte Folded Reload
	add.2d	v17, v1, v6
	ldp	q1, q6, [sp, #416]              ; 32-byte Folded Reload
	add.2d	v25, v6, v17
	add.2d	v23, v1, v16
	ldp	q1, q6, [sp, #384]              ; 32-byte Folded Reload
	add.2d	v20, v6, v3
	add.2d	v6, v1, v4
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	d28, d1
	fmov	w10, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v19, #0000000000000000
	str	q8, [sp, #224]                  ; 16-byte Folded Spill
	stp	q29, q27, [sp, #736]            ; 32-byte Folded Spill
	stp	q10, q12, [sp, #496]            ; 32-byte Folded Spill
	str	q26, [sp, #320]                 ; 16-byte Folded Spill
	stp	q9, q31, [sp, #448]             ; 32-byte Folded Spill
	stp	q15, q13, [sp, #176]            ; 32-byte Folded Spill
	str	q14, [sp, #768]                 ; 16-byte Folded Spill
	str	q11, [sp, #704]                 ; 16-byte Folded Spill
	str	q5, [sp, #944]                  ; 16-byte Folded Spill
	tbnz	w10, #0, LBB0_93
; %bb.88:                               ; %else127
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #1, LBB0_94
LBB0_89:                                ; %else130
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q5, [sp, #1008]                 ; 16-byte Folded Reload
	tbnz	w10, #2, LBB0_95
LBB0_90:                                ; %else133
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #3, LBB0_96
LBB0_91:                                ; %else136
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q23, [sp, #592]                 ; 16-byte Folded Reload
	ldr	q26, [sp, #960]                 ; 16-byte Folded Reload
	fmov	d18, d0
	tbz	w10, #4, LBB0_97
LBB0_92:                                ; %cond.load138
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q8, [sp, #1040]                 ; 16-byte Folded Reload
	mov.16b	v24, v26
	ldp	q26, q0, [sp, #976]             ; 32-byte Folded Reload
	fmov	x13, d20
	ld1.s	{ v19 }[0], [x13]
	str	q5, [sp, #1008]                 ; 16-byte Folded Spill
	mov.16b	v5, v23
	tbnz	w10, #5, LBB0_98
	b	LBB0_99
LBB0_93:                                ; %cond.load126
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d25
	ldr	s1, [x13]
	tbz	w10, #1, LBB0_89
LBB0_94:                                ; %cond.load129
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v25[1]
	ld1.s	{ v1 }[1], [x13]
	ldr	q5, [sp, #1008]                 ; 16-byte Folded Reload
	tbz	w10, #2, LBB0_90
LBB0_95:                                ; %cond.load132
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d23
	ld1.s	{ v1 }[2], [x13]
	tbz	w10, #3, LBB0_91
LBB0_96:                                ; %cond.load135
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v23[1]
	ld1.s	{ v1 }[3], [x13]
	ldr	q23, [sp, #592]                 ; 16-byte Folded Reload
	ldr	q26, [sp, #960]                 ; 16-byte Folded Reload
	fmov	d18, d0
	tbnz	w10, #4, LBB0_92
LBB0_97:                                ;   in Loop: Header=BB0_5 Depth=1
	ldr	q8, [sp, #1040]                 ; 16-byte Folded Reload
	mov.16b	v24, v26
	ldp	q26, q0, [sp, #976]             ; 32-byte Folded Reload
	str	q5, [sp, #1008]                 ; 16-byte Folded Spill
	mov.16b	v5, v23
	tbz	w10, #5, LBB0_99
LBB0_98:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v20[1]
	ld1.s	{ v19 }[1], [x13]
LBB0_99:                                ; %else142
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #6, LBB0_132
; %bb.100:                              ; %else145
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w10, #7, LBB0_102
LBB0_101:                               ; %cond.load147
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v6[1]
	ld1.s	{ v19 }[3], [x10]
LBB0_102:                               ; %else148
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmul.4s	v6, v19, v19
	fmul.4s	v1, v1, v1
	ldr	q19, [sp, #864]                 ; 16-byte Folded Reload
	fadd.4s	v1, v19, v1
	str	q1, [sp, #592]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #848]                  ; 16-byte Folded Reload
	fadd.4s	v6, v1, v6
	ldp	q7, q1, [sp, #384]              ; 32-byte Folded Reload
	add.2d	v23, v4, v7
	add.2d	v3, v3, v1
	ldp	q1, q7, [sp, #416]              ; 32-byte Folded Reload
	add.2d	v4, v17, v7
	add.2d	v20, v16, v1
	mov	w10, #32                        ; =0x20
	dup.2d	v16, x10
	add.2d	v25, v20, v16
	add.2d	v31, v4, v16
	add.2d	v30, v3, v16
	add.2d	v19, v23, v16
	fmov	w10, s28
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w10, #0, LBB0_133
; %bb.103:                              ; %else155
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #1, LBB0_134
LBB0_104:                               ; %else161
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #2, LBB0_135
LBB0_105:                               ; %else167
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	q8, [sp, #1040]                 ; 16-byte Folded Spill
	tbnz	w10, #3, LBB0_136
LBB0_106:                               ; %else173
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #4, LBB0_137
LBB0_107:                               ; %else179
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	q24, [sp, #960]                 ; 16-byte Folded Spill
	tbnz	w10, #5, LBB0_138
LBB0_108:                               ; %else185
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	q26, [sp, #976]                 ; 16-byte Folded Spill
	tbnz	w10, #6, LBB0_139
LBB0_109:                               ; %else191
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q15, [sp, #832]                 ; 16-byte Folded Reload
	fmov	d1, d18
	str	q15, [sp, #832]                 ; 16-byte Folded Spill
	tbz	w10, #7, LBB0_111
LBB0_110:                               ; %cond.load193
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v19[1]
	ld1.s	{ v17 }[3], [x10]
LBB0_111:                               ; %else197
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmul.4s	v17, v17, v17
	fmul.4s	v16, v16, v16
	ldr	q18, [sp, #800]                 ; 16-byte Folded Reload
	fadd.4s	v19, v18, v16
	ldr	q16, [sp, #1008]                ; 16-byte Folded Reload
	fadd.4s	v8, v16, v17
	mov	w10, #64                        ; =0x40
	dup.2d	v16, x10
	add.2d	v31, v20, v16
	add.2d	v12, v4, v16
	add.2d	v25, v3, v16
	add.2d	v30, v23, v16
	fmov	w10, s28
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w10, #0, LBB0_140
; %bb.112:                              ; %else204
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #1, LBB0_141
LBB0_113:                               ; %else210
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #2, LBB0_142
LBB0_114:                               ; %else216
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #3, LBB0_143
LBB0_115:                               ; %else222
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #4, LBB0_144
LBB0_116:                               ; %else228
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #5, LBB0_145
LBB0_117:                               ; %else234
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #6, LBB0_146
LBB0_118:                               ; %else240
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w10, #7, LBB0_120
LBB0_119:                               ; %cond.load242
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v30[1]
	ld1.s	{ v17 }[3], [x10]
LBB0_120:                               ; %else246
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmul.4s	v17, v17, v17
	fmul.4s	v16, v16, v16
	fadd.4s	v16, v5, v16
	ldr	q18, [sp, #816]                 ; 16-byte Folded Reload
	fadd.4s	v17, v18, v17
	mov	w10, #96                        ; =0x60
	dup.2d	v12, x10
	add.2d	v30, v20, v12
	add.2d	v31, v4, v12
	add.2d	v25, v3, v12
	add.2d	v20, v23, v12
	fmov	w10, s28
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w10, #0, LBB0_147
; %bb.121:                              ; %else253
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v12, v0
	tbnz	w10, #1, LBB0_148
LBB0_122:                               ; %else259
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q11, [sp, #352]                 ; 16-byte Folded Reload
	fmov	d0, d1
	ldr	q15, [sp, #176]                 ; 16-byte Folded Reload
	tbnz	w10, #2, LBB0_149
LBB0_123:                               ; %else265
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q31, [sp, #1024]                ; 16-byte Folded Reload
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	tbz	w10, #3, LBB0_125
LBB0_124:                               ; %cond.load267
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v30[1]
	ld1.s	{ v3 }[3], [x13]
LBB0_125:                               ; %else271
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q18, [sp, #624]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #192]                 ; 16-byte Folded Reload
	mov.16b	v23, v5
	ldp	q27, q24, [sp, #800]            ; 32-byte Folded Reload
	ldr	q5, [sp, #1008]                 ; 16-byte Folded Reload
	ldp	q26, q29, [sp, #848]            ; 32-byte Folded Reload
	ldr	q9, [sp, #448]                  ; 16-byte Folded Reload
	tbnz	w10, #4, LBB0_150
; %bb.126:                              ; %else277
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldp	q22, q30, [sp, #464]            ; 32-byte Folded Reload
	ldr	q14, [sp, #768]                 ; 16-byte Folded Reload
	ldr	q28, [sp, #704]                 ; 16-byte Folded Reload
	str	q31, [sp, #1024]                ; 16-byte Folded Spill
	tbnz	w10, #5, LBB0_151
LBB0_127:                               ; %else283
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q10, [sp, #208]                 ; 16-byte Folded Reload
	mov.16b	v31, v22
	tbnz	w10, #6, LBB0_152
LBB0_128:                               ; %else289
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v22, v10
	tbz	w10, #7, LBB0_130
LBB0_129:                               ; %cond.load291
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v20[1]
	ld1.s	{ v4 }[3], [x10]
LBB0_130:                               ; %else295
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmul.4s	v4, v4, v4
	fmul.4s	v3, v3, v3
	fadd.4s	v3, v1, v3
	mov	w10, #4                         ; =0x4
	dup.2d	v7, x10
	mov	b20, v21[6]
	mov.b	v20[4], v21[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v20, v20, v7
	ldr	q25, [sp, #1024]                ; 16-byte Folded Reload
	add.2d	v25, v25, v20
	str	q25, [sp, #1024]                ; 16-byte Folded Spill
	mov	b20, v21[4]
	mov.b	v20[4], v21[5]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v20, v20, v7
	add.2d	v9, v9, v20
	mov	b20, v21[2]
	mov.b	v20[4], v21[3]
	fadd.4s	v4, v18, v4
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v20, v20, v7
	add.2d	v13, v13, v20
	mov	b20, v21[0]
	mov.b	v20[4], v21[1]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v7, v20, v7
	add.2d	v22, v22, v7
	zip1.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	zip2.8b	v20, v21, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmlt.4s	v20, v20, #0
	bit.16b	v26, v6, v20
	ldr	q6, [sp, #592]                  ; 16-byte Folded Reload
	bit.16b	v29, v6, v7
	stp	q26, q29, [sp, #848]            ; 32-byte Folded Spill
	bit.16b	v5, v8, v20
	stp	q12, q5, [sp, #992]             ; 32-byte Folded Spill
	bit.16b	v27, v19, v7
	bit.16b	v24, v17, v20
	stp	q27, q24, [sp, #800]            ; 32-byte Folded Spill
	bit.16b	v23, v16, v7
	bit.16b	v18, v4, v20
	str	q18, [sp, #624]                 ; 16-byte Folded Spill
	bit.16b	v1, v3, v7
	stp	q23, q1, [sp, #592]             ; 32-byte Folded Spill
	tbnz	w11, #0, LBB0_74
; %bb.131:                              ;   in Loop: Header=BB0_5 Depth=1
	ldp	q18, q29, [sp, #720]            ; 32-byte Folded Reload
	ldp	q10, q12, [sp, #496]            ; 32-byte Folded Reload
	ldr	q27, [sp, #752]                 ; 16-byte Folded Reload
	ldp	q26, q23, [sp, #320]            ; 32-byte Folded Reload
	ldr	q3, [sp, #224]                  ; 16-byte Folded Reload
	ldr	q19, [sp, #368]                 ; 16-byte Folded Reload
	mov.16b	v5, v28
	mov.16b	v28, v3
	mov.16b	v24, v30
	b	LBB0_77
LBB0_132:                               ; %cond.load144
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d6
	ld1.s	{ v19 }[2], [x13]
	tbnz	w10, #7, LBB0_101
	b	LBB0_102
LBB0_133:                               ; %cond.load151
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d31
	ldr	s16, [x13]
	tbz	w10, #1, LBB0_104
LBB0_134:                               ; %cond.load157
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v31[1]
	ld1.s	{ v16 }[1], [x13]
	tbz	w10, #2, LBB0_105
LBB0_135:                               ; %cond.load163
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d25
	ld1.s	{ v16 }[2], [x13]
	str	q8, [sp, #1040]                 ; 16-byte Folded Spill
	tbz	w10, #3, LBB0_106
LBB0_136:                               ; %cond.load169
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v25[1]
	ld1.s	{ v16 }[3], [x13]
	tbz	w10, #4, LBB0_107
LBB0_137:                               ; %cond.load175
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d30
	ld1.s	{ v17 }[0], [x13]
	str	q24, [sp, #960]                 ; 16-byte Folded Spill
	tbz	w10, #5, LBB0_108
LBB0_138:                               ; %cond.load181
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v30[1]
	ld1.s	{ v17 }[1], [x13]
	str	q26, [sp, #976]                 ; 16-byte Folded Spill
	tbz	w10, #6, LBB0_109
LBB0_139:                               ; %cond.load187
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d19
	ld1.s	{ v17 }[2], [x13]
	ldr	q15, [sp, #832]                 ; 16-byte Folded Reload
	fmov	d1, d18
	str	q15, [sp, #832]                 ; 16-byte Folded Spill
	tbnz	w10, #7, LBB0_110
	b	LBB0_111
LBB0_140:                               ; %cond.load200
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d12
	ldr	s16, [x13]
	tbz	w10, #1, LBB0_113
LBB0_141:                               ; %cond.load206
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v12[1]
	ld1.s	{ v16 }[1], [x13]
	tbz	w10, #2, LBB0_114
LBB0_142:                               ; %cond.load212
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d31
	ld1.s	{ v16 }[2], [x13]
	tbz	w10, #3, LBB0_115
LBB0_143:                               ; %cond.load218
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v31[1]
	ld1.s	{ v16 }[3], [x13]
	tbz	w10, #4, LBB0_116
LBB0_144:                               ; %cond.load224
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d25
	ld1.s	{ v17 }[0], [x13]
	tbz	w10, #5, LBB0_117
LBB0_145:                               ; %cond.load230
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v25[1]
	ld1.s	{ v17 }[1], [x13]
	tbz	w10, #6, LBB0_118
LBB0_146:                               ; %cond.load236
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d30
	ld1.s	{ v17 }[2], [x13]
	tbnz	w10, #7, LBB0_119
	b	LBB0_120
LBB0_147:                               ; %cond.load249
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d31
	ldr	s3, [x13]
	mov.16b	v12, v0
	tbz	w10, #1, LBB0_122
LBB0_148:                               ; %cond.load255
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v31[1]
	ld1.s	{ v3 }[1], [x13]
	ldr	q11, [sp, #352]                 ; 16-byte Folded Reload
	fmov	d0, d1
	ldr	q15, [sp, #176]                 ; 16-byte Folded Reload
	tbz	w10, #2, LBB0_123
LBB0_149:                               ; %cond.load261
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d30
	ld1.s	{ v3 }[2], [x13]
	ldr	q31, [sp, #1024]                ; 16-byte Folded Reload
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	tbnz	w10, #3, LBB0_124
	b	LBB0_125
LBB0_150:                               ; %cond.load273
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d25
	ld1.s	{ v4 }[0], [x13]
	ldp	q22, q30, [sp, #464]            ; 32-byte Folded Reload
	ldr	q14, [sp, #768]                 ; 16-byte Folded Reload
	ldr	q28, [sp, #704]                 ; 16-byte Folded Reload
	str	q31, [sp, #1024]                ; 16-byte Folded Spill
	tbz	w10, #5, LBB0_127
LBB0_151:                               ; %cond.load279
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v25[1]
	ld1.s	{ v4 }[1], [x13]
	ldr	q10, [sp, #208]                 ; 16-byte Folded Reload
	mov.16b	v31, v22
	tbz	w10, #6, LBB0_128
LBB0_152:                               ; %cond.load285
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d20
	ld1.s	{ v4 }[2], [x13]
	mov.16b	v22, v10
	tbnz	w10, #7, LBB0_129
	b	LBB0_130
LBB0_153:                               ; %varying.coherent.false78
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
LBB0_154:                               ; %schedule.8
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w14, LBB0_159
; %bb.155:                              ; %convergence.cascade92.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w11, #0                         ; =0x0
LBB0_156:                               ; %convergence.cascade92
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w10, s3
	umaxv.8b	b1, v1
	fmov	w2, s1
	sub	w13, w14, #1
	tst	w10, #0xff
	csel	w13, w13, wzr, ne
	lsl	w15, w16, w13
	and	w10, w15, w30
	tst	w10, #0xff
	cset	w3, ne
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #4320]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #4336]
	ubfiz	x10, x13, #2, #3
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #224
	ldr	w0, [x12, x10]
	cmp	w0, #1
	cset	w0, eq
	and	w2, w3, w2
	ldrb	w3, [x28, w13, sxtw]
	and	w5, w3, #0x1
	fmov	s1, w5
	ubfx	w5, w3, #1, #1
	mov.b	v1[1], w5
	ubfx	w5, w3, #2, #1
	mov.b	v1[2], w5
	ubfx	w5, w3, #3, #1
	mov.b	v1[3], w5
	ubfx	w5, w3, #4, #1
	mov.b	v1[4], w5
	ubfx	w5, w3, #5, #1
	mov.b	v1[5], w5
	ubfx	w5, w3, #6, #1
	mov.b	v1[6], w5
	lsr	w3, w3, #7
	mov.b	v1[7], w3
	ldrb	w3, [x8, w13, sxtw]
	and	w5, w3, #0x1
	fmov	s3, w5
	ubfx	w5, w3, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w3, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w3, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w3, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w3, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w3, #6, #1
	mov.b	v3[6], w5
	lsr	w3, w3, #7
	mov.b	v3[7], w3
	orr.8b	v4, v21, v3
	and.8b	v6, v0, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w3, s6
	ands	w0, w2, w0
	csetm	w2, ne
	bics	w3, w0, w3
	csetm	w5, ne
	dup.8b	v6, w5
	dup.8b	v7, w2
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w13, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x28, w13, sxtw]
	csinv	w13, w4, w15, eq
	dup.8b	v1, w0
	and	w30, w13, w30
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w3
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #4288]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #4304]
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #192
	ldr	w10, [x12, x10]
	csel	w14, w10, w14, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w10, s1
	cmp	w0, #1
	b.ne	LBB0_160
; %bb.157:                              ; %convergence.cascade92
                                        ;   in Loop: Header=BB0_156 Depth=2
	cmp	w14, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_160
; %bb.158:                              ; %convergence.cascade92
                                        ;   in Loop: Header=BB0_156 Depth=2
	add	w11, w11, #1
	tst	w10, #0xff
	b.ne	LBB0_156
	b	LBB0_160
LBB0_159:                               ; %schedule.8.convergence.cascade.exit93_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w10, s1
LBB0_160:                               ; %convergence.cascade.exit93
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_76
; %bb.161:                              ; %convergence.target.8.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v1, v11, v21
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b4, v3
	umaxv.8b	b1, v1
	fmov	w11, s1
	mov	w5, #192                        ; =0xc0
	add	x3, sp, #3536
	tbz	w11, #0, LBB0_168
; %bb.162:                              ; %convergence.target.8.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v3, v21, v11
	shl.8b	v1, v3, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	tst	w11, #0xff
	b.eq	LBB0_168
; %bb.163:                              ; %varying.divergent110
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w10, w14, #1
	csel	w10, wzr, w10, lo
	and	w11, w30, #0xff
	lsr	w13, w11, w10
	tst	w13, #0x1
	ldr	q6, [sp, #1088]                 ; 16-byte Folded Reload
	str	q6, [sp, #1824]
	ldr	q6, [sp, #1104]                 ; 16-byte Folded Reload
	str	q6, [sp, #1840]
	and	x10, x10, #0x7
	add	x12, sp, #1824
	ldr	w10, [x12, x10, lsl #2]
	ccmp	w14, #0, #4, ne
	ccmp	w10, #2, #0, ne
	cset	w10, ne
	cmp	w11, #255
	b.ne	LBB0_165
; %bb.164:                              ; %varying.divergent110
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #0, LBB0_378
LBB0_165:                               ; %convergence.overflow.resume113
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w11, w30
	rbit	w11, w11
	clz	w11, w11
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w30
	csel	w11, wzr, w11, eq
	ubfiz	x13, x11, #2, #3
	lsl	w15, w16, w11
	ldr	q7, [sp, #1088]                 ; 16-byte Folded Reload
	str	q7, [sp, #1792]
	ldr	q6, [sp, #1104]                 ; 16-byte Folded Reload
	str	q6, [sp, #1808]
	add	x12, sp, #1792
	ldr	w0, [x12, x13]
	cmp	w10, #0
	csel	w10, w15, wzr, ne
	mov	w12, #2                         ; =0x2
	csel	w15, w12, w0, ne
	str	q7, [sp, #1760]
	str	q6, [sp, #1776]
	add	x12, sp, #1760
	str	w15, [x12, x13]
	ldr	q6, [sp, #1776]
	str	q6, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1760]
	str	q6, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q7, [sp, #1056]                 ; 16-byte Folded Reload
	str	q7, [sp, #1728]
	ldr	q6, [sp, #1072]                 ; 16-byte Folded Reload
	str	q6, [sp, #1744]
	add	x12, sp, #1728
	ldr	w15, [x12, x13]
	csel	w15, w14, w15, ne
	str	q7, [sp, #1696]
	str	q6, [sp, #1712]
	add	x12, sp, #1696
	str	w15, [x12, x13]
	ldrb	w13, [x28, x11]
	and	w15, w13, #0x1
	fmov	s6, w15
	ubfx	w15, w13, #1, #1
	mov.b	v6[1], w15
	ubfx	w15, w13, #2, #1
	mov.b	v6[2], w15
	ubfx	w15, w13, #3, #1
	mov.b	v6[3], w15
	ubfx	w15, w13, #4, #1
	mov.b	v6[4], w15
	ubfx	w15, w13, #5, #1
	mov.b	v6[5], w15
	ubfx	w15, w13, #6, #1
	mov.b	v6[6], w15
	ldr	q7, [sp, #1712]
	str	q7, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q7, [sp, #1696]
	str	q7, [sp, #1056]                 ; 16-byte Folded Spill
	lsr	w13, w13, #7
	mov.b	v6[7], w13
	ldrb	w13, [x8, x11]
	and	w15, w13, #0x1
	fmov	s7, w15
	ubfx	w15, w13, #1, #1
	mov.b	v7[1], w15
	ubfx	w15, w13, #2, #1
	mov.b	v7[2], w15
	ubfx	w15, w13, #3, #1
	mov.b	v7[3], w15
	ubfx	w15, w13, #4, #1
	mov.b	v7[4], w15
	ubfx	w15, w13, #5, #1
	mov.b	v7[5], w15
	ubfx	w15, w13, #6, #1
	mov.b	v7[6], w15
	lsr	w13, w13, #7
	mov.b	v7[7], w13
	csetm	w13, ne
	dup.8b	v16, w13
	bit.8b	v6, v21, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	str	b6, [x28, x11]
	bic.8b	v6, v7, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	str	b6, [x8, x11]
	csinc	w11, w14, w11, eq
	cmp	w24, #8
	b.hs	LBB0_378
; %bb.166:                              ; %ready.overflow.resume116
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b4, [x23, x21]
	mov	w12, #9                         ; =0x9
	str	w12, [x25, x21, lsl #2]
	str	w11, [x26, x21, lsl #2]
	cmp	w9, #8
	b.hs	LBB0_378
; %bb.167:                              ; %ready.overflow.resume118
                                        ;   in Loop: Header=BB0_5 Depth=1
	orr	w30, w10, w30
	zip2.8b	v4, v3, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q6, [sp, #288]                  ; 16-byte Folded Reload
	ldr	q7, [sp, #848]                  ; 16-byte Folded Reload
	bit.16b	v6, v7, v4
	zip1.8b	v3, v3, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	str	b1, [x23, w9, uxtw]
	ldr	q1, [sp, #272]                  ; 16-byte Folded Reload
	ldr	q4, [sp, #864]                  ; 16-byte Folded Reload
	bit.16b	v1, v4, v3
	stp	q1, q6, [sp, #272]              ; 32-byte Folded Spill
	mov	w10, #10                        ; =0xa
	str	w10, [x25, w9, uxtw #2]
	str	w11, [x26, w9, uxtw #2]
	add	w24, w9, #1
	b	LBB0_4
LBB0_168:                               ; %varying.coherent111
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	w11, s4
	tst	w11, #0xff
	b.eq	LBB0_175
LBB0_169:                               ; %schedule.9
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w11, w10
	clz	w11, w11
	tst	w10, #0xff
	csel	w11, wzr, w11, eq
	ldp	q1, q3, [sp, #912]              ; 32-byte Folded Reload
	str	q3, [sp, #4224]
	str	q1, [sp, #4240]
	ldp	q1, q3, [sp, #880]              ; 32-byte Folded Reload
	str	q3, [sp, #4256]
	str	q1, [sp, #4272]
	and	x13, x11, #0x7
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #128
	ldr	x13, [x12, x13, lsl #3]
	lsl	w11, w11, #2
	ands	w10, w10, #0xff
	sub	x11, x13, x11
	mov	w12, #6144                      ; =0x1800
	add	x11, x11, x12
	csel	x11, xzr, x11, eq
	add	x11, x20, x11
	ldp	q3, q1, [x11]
	zip1.8b	v4, v21, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v3, v4, v3
	zip2.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v1, v6, v1
	fmul.4s	v1, v1, v1
	fmul.4s	v3, v3, v3
	ldr	q7, [sp, #864]                  ; 16-byte Folded Reload
	fadd.4s	v3, v7, v3
	ldr	q7, [sp, #848]                  ; 16-byte Folded Reload
	fadd.4s	v1, v7, v1
	ldr	q7, [sp, #288]                  ; 16-byte Folded Reload
	bit.16b	v7, v1, v6
	ldr	q1, [sp, #272]                  ; 16-byte Folded Reload
	bit.16b	v1, v3, v4
	stp	q1, q7, [sp, #272]              ; 32-byte Folded Spill
	cbz	w10, LBB0_4
LBB0_170:                               ; %schedule.10
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	x21, [sp, #168]                 ; 8-byte Folded Spill
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #64
	cbz	w14, LBB0_176
LBB0_171:                               ; %convergence.cascade126.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w10, #0                         ; =0x0
LBB0_172:                               ; %convergence.cascade126
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w2, s1
	sub	w13, w14, #1
	tst	w11, #0xff
	csel	w13, w13, wzr, ne
	lsl	w15, w16, w13
	and	w11, w15, w30
	tst	w11, #0xff
	cset	w3, ne
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #4192]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #4208]
	ubfiz	x11, x13, #2, #3
	ldr	w0, [x22, x11]
	cmp	w0, #2
	cset	w0, eq
	and	w2, w3, w2
	ldrb	w3, [x28, w13, sxtw]
	and	w5, w3, #0x1
	fmov	s1, w5
	ubfx	w5, w3, #1, #1
	mov.b	v1[1], w5
	ubfx	w5, w3, #2, #1
	mov.b	v1[2], w5
	ubfx	w5, w3, #3, #1
	mov.b	v1[3], w5
	ubfx	w5, w3, #4, #1
	mov.b	v1[4], w5
	ubfx	w5, w3, #5, #1
	mov.b	v1[5], w5
	ubfx	w5, w3, #6, #1
	mov.b	v1[6], w5
	lsr	w3, w3, #7
	mov.b	v1[7], w3
	ldrb	w3, [x8, w13, sxtw]
	and	w5, w3, #0x1
	fmov	s3, w5
	ubfx	w5, w3, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w3, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w3, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w3, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w3, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w3, #6, #1
	mov.b	v3[6], w5
	lsr	w3, w3, #7
	mov.b	v3[7], w3
	orr.8b	v4, v21, v3
	and.8b	v6, v0, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w3, s6
	ands	w0, w2, w0
	csetm	w2, ne
	bics	w3, w0, w3
	csetm	w5, ne
	dup.8b	v6, w5
	dup.8b	v7, w2
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w13, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x28, w13, sxtw]
	csinv	w13, w4, w15, eq
	dup.8b	v1, w0
	and	w30, w13, w30
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w3
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #4160]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #4176]
	ldr	w11, [x12, x11]
	csel	w14, w11, w14, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w0, #1
	b.ne	LBB0_177
; %bb.173:                              ; %convergence.cascade126
                                        ;   in Loop: Header=BB0_172 Depth=2
	cmp	w14, #0
	ccmp	w10, #6, #2, ne
	b.hi	LBB0_177
; %bb.174:                              ; %convergence.cascade126
                                        ;   in Loop: Header=BB0_172 Depth=2
	add	w10, w10, #1
	tst	w11, #0xff
	b.ne	LBB0_172
	b	LBB0_177
LBB0_175:                               ; %varying.coherent.false120
                                        ;   in Loop: Header=BB0_5 Depth=1
	zip2.8b	v1, v21, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #288]                  ; 16-byte Folded Reload
	ldp	q6, q4, [sp, #848]              ; 32-byte Folded Reload
	bit.16b	v3, v6, v1
	str	q3, [sp, #288]                  ; 16-byte Folded Spill
	zip1.8b	v1, v21, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #272]                  ; 16-byte Folded Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #272]                  ; 16-byte Folded Spill
	str	x21, [sp, #168]                 ; 8-byte Folded Spill
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #64
	cbnz	w14, LBB0_171
LBB0_176:                               ; %schedule.10.convergence.cascade.exit127_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_177:                               ; %convergence.cascade.exit127
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_179
; %bb.178:                              ; %convergence.target.10.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q1, [sp, #288]                  ; 16-byte Folded Reload
	ldr	q3, [sp, #1008]                 ; 16-byte Folded Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #272]                  ; 16-byte Folded Reload
	ldr	q4, [sp, #800]                  ; 16-byte Folded Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #592]                  ; 16-byte Folded Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #816]                  ; 16-byte Folded Reload
	fadd.4s	v1, v4, v1
	ldr	q4, [sp, #624]                  ; 16-byte Folded Reload
	fadd.4s	v6, v4, v1
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	fadd.4s	v7, v1, v3
	uzp1.4s	v25, v24, v14
	uzp1.4s	v8, v31, v5
	movi.4s	v4, #1
	eor.16b	v3, v25, v4
	mov.s	w10, v3[1]
	eor.16b	v4, v8, v4
	mov.s	w13, v3[2]
	mov.s	w15, v3[3]
	fmov	w0, s3
	cmp	w0, #8
	csel	w0, w0, wzr, lo
	cset	w2, lo
	and	x3, x0, #0x7
	add	x5, sp, #3576
	bfxil	x5, x0, #0, #3
	str	d21, [sp, #3576]
	ldrb	w0, [x5]
	umov.b	w23, v21[0]
	and	w0, w2, w0
	str	q7, [sp, #4000]
	str	q6, [sp, #4016]
	add	x12, sp, #4000
	ldr	s3, [x12, x3, lsl #2]
	ands	w7, w23, #0x1
	tst	w7, w0
	str	q18, [sp, #720]                 ; 16-byte Folded Spill
	str	q23, [sp, #336]                 ; 16-byte Folded Spill
	movi	d23, #0000000000000000
	fcsel	s3, s3, s23, ne
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w0, lo
	and	x2, x10, #0x7
	add	x3, sp, #3576
	bfxil	x3, x10, #0, #3
	ldrb	w3, [x3]
	umov.b	w10, v21[1]
	and	w0, w0, w3
	str	q7, [sp, #3968]
	str	q6, [sp, #3984]
	add	x12, sp, #3968
	ldr	s16, [x12, x2, lsl #2]
	ands	w26, w10, #0x1
	tst	w26, w0
	fcsel	s17, s16, s23, ne
	cmp	w13, #8
	csel	w13, w13, wzr, lo
	cset	w0, lo
	and	x2, x13, #0x7
	add	x3, sp, #3576
	bfxil	x3, x13, #0, #3
	ldrb	w13, [x3]
	umov.b	w19, v21[2]
	str	q7, [sp, #3936]
	str	q6, [sp, #3952]
	add	x12, sp, #3936
	ldr	s16, [x12, x2, lsl #2]
	and	w13, w0, w13
	ands	w20, w19, #0x1
	tst	w20, w13
	fcsel	s16, s16, s23, ne
	cmp	w15, #8
	csel	w13, w15, wzr, lo
	cset	w2, lo
	and	x5, x13, #0x7
	add	x15, sp, #3576
	bfxil	x15, x13, #0, #3
	umov.b	w3, v21[3]
	ldrb	w6, [x15]
	mov.s	w15, v4[1]
	mov.s	w13, v4[2]
	str	q7, [sp, #3904]
	str	q6, [sp, #3920]
	mov.s	w0, v4[3]
	fmov	w21, s4
	add	x12, sp, #3904
	ldr	s4, [x12, x5, lsl #2]
	and	w2, w2, w6
	ands	w5, w3, #0x1
	tst	w5, w2
	fcsel	s20, s4, s23, ne
	cmp	w21, #8
	csel	w2, w21, wzr, lo
	cset	w6, lo
	and	x21, x2, #0x7
	add	x27, sp, #3576
	bfxil	x27, x2, #0, #3
	umov.b	w25, v21[4]
	ldrb	w2, [x27]
	and	w6, w6, w2
	str	q7, [sp, #4128]
	str	q6, [sp, #4144]
	mov.s	v3[1], v17[0]
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #32
	ldr	s4, [x12, x21, lsl #2]
	ands	w2, w25, #0x1
	tst	w2, w6
	fcsel	s4, s4, s23, ne
	cmp	w15, #8
	csel	w15, w15, wzr, lo
	cset	w6, lo
	and	x27, x15, #0x7
	add	x21, sp, #3576
	bfxil	x21, x15, #0, #3
	ldrb	w15, [x21]
	umov.b	w21, v21[5]
	and	w6, w6, w15
	mov.s	v3[2], v16[0]
	str	q7, [sp, #4096]
	str	q6, [sp, #4112]
	add	x12, sp, #1, lsl #12            ; =4096
	ldr	s16, [x12, x27, lsl #2]
	ands	w15, w21, #0x1
	tst	w15, w6
	fcsel	s16, s16, s23, ne
	cmp	w13, #8
	csel	w13, w13, wzr, lo
	cset	w6, lo
	and	x27, x13, #0x7
	add	x22, sp, #3576
	bfxil	x22, x13, #0, #3
	ldrb	w22, [x22]
	umov.b	w13, v21[6]
	and	w22, w6, w22
	str	q7, [sp, #4064]
	str	q6, [sp, #4080]
	mov.s	v3[3], v20[0]
	add	x12, sp, #4064
	ldr	s17, [x12, x27, lsl #2]
	ands	w6, w13, #0x1
	tst	w6, w22
	fcsel	s17, s17, s23, ne
	cmp	w0, #8
	csel	w0, w0, wzr, lo
	cset	w22, lo
	and	x27, x0, #0x7
	add	x17, sp, #3576
	bfxil	x17, x0, #0, #3
	ldrb	w17, [x17]
	umov.b	w0, v21[7]
	and	w17, w22, w17
	str	q7, [sp, #4032]
	str	q6, [sp, #4048]
	mov.s	v4[1], v16[0]
	add	x12, sp, #4032
	ldr	s16, [x12, x27, lsl #2]
	ands	w27, w0, #0x1
	tst	w27, w17
	fcsel	s20, s16, s23, ne
	stp	q29, q27, [sp, #736]            ; 32-byte Folded Spill
	str	q5, [sp, #704]                  ; 16-byte Folded Spill
	str	q26, [sp, #320]                 ; 16-byte Folded Spill
	mov.16b	v27, v24
	mov.16b	v24, v19
	movi.4s	v19, #2
	eor.16b	v16, v25, v19
	mov.s	w17, v16[1]
	fmov	w22, s16
	cmp	w22, #8
	csel	w22, w22, wzr, lo
	cset	w1, lo
	add	x12, sp, #3576
	bfxil	x12, x22, #0, #3
	ldrb	w12, [x12]
	and	w12, w1, w12
	mov.s	v4[2], v17[0]
	mov.s	v4[3], v20[0]
	fadd.4s	v4, v6, v4
	fadd.4s	v3, v7, v3
	and	x1, x22, #0x7
	str	q3, [sp, #3872]
	str	q4, [sp, #3888]
	add	x22, sp, #3872
	ldr	s6, [x22, x1, lsl #2]
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #96
	tst	w7, w12
	fcsel	s6, s6, s23, ne
	cmp	w17, #8
	csel	w12, w17, wzr, lo
	cset	w17, lo
	add	x1, sp, #3576
	bfxil	x1, x12, #0, #3
	ldrb	w1, [x1]
	and	w17, w17, w1
	and	x12, x12, #0x7
	str	q3, [sp, #3840]
	str	q4, [sp, #3856]
	add	x1, sp, #3840
	ldr	s7, [x1, x12, lsl #2]
	mov.s	w12, v16[2]
	tst	w26, w17
	add	x26, sp, #4, lsl #12            ; =16384
	add	x26, x26, #728
	fcsel	s7, s7, s23, ne
	cmp	w12, #8
	csel	w12, w12, wzr, lo
	cset	w17, lo
	add	x1, sp, #3576
	bfxil	x1, x12, #0, #3
	ldrb	w1, [x1]
	and	w17, w17, w1
	and	x12, x12, #0x7
	str	q3, [sp, #3808]
	str	q4, [sp, #3824]
	add	x1, sp, #3808
	ldr	s17, [x1, x12, lsl #2]
	mov.s	w12, v16[3]
	tst	w20, w17
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #2728
	fcsel	s16, s17, s23, ne
	cmp	w12, #8
	csel	w12, w12, wzr, lo
	cset	w17, lo
	add	x1, sp, #3576
	bfxil	x1, x12, #0, #3
	ldrb	w1, [x1]
	and	w17, w17, w1
	eor.16b	v19, v8, v19
	mov.16b	v30, v22
	mov.16b	v5, v13
	mov.16b	v25, v9
	ldp	q8, q20, [sp, #960]             ; 32-byte Folded Reload
	mov.16b	v9, v11
	mov.16b	v11, v24
	ldr	q22, [sp, #528]                 ; 16-byte Folded Reload
	mov.16b	v13, v30
	mov.16b	v24, v27
	ldr	q26, [sp, #320]                 ; 16-byte Folded Reload
	ldp	q29, q27, [sp, #736]            ; 32-byte Folded Reload
	mov.16b	v30, v5
	ldr	q5, [sp, #704]                  ; 16-byte Folded Reload
	and	x12, x12, #0x7
	str	q3, [sp, #3776]
	str	q4, [sp, #3792]
	add	x1, sp, #3776
	ldr	s1, [x1, x12, lsl #2]
	tst	w5, w17
	fcsel	s1, s1, s23, ne
	fmov	w12, s19
	cmp	w12, #8
	csel	w12, w12, wzr, lo
	cset	w17, lo
	add	x1, sp, #3576
	bfxil	x1, x12, #0, #3
	ldrb	w1, [x1]
	and	w17, w17, w1
	mov.s	w1, v19[1]
	and	x12, x12, #0x7
	str	q3, [sp, #3744]
	str	q4, [sp, #3760]
	add	x5, sp, #3744
	ldr	s17, [x5, x12, lsl #2]
	mov.s	w12, v19[2]
	tst	w2, w17
	fcsel	s17, s17, s23, ne
	cmp	w1, #8
	csel	w17, w1, wzr, lo
	cset	w1, lo
	add	x2, sp, #3576
	bfxil	x2, x17, #0, #3
	ldrb	w2, [x2]
	and	w1, w1, w2
	mov.s	w2, v19[3]
	and	x17, x17, #0x7
	str	q3, [sp, #3712]
	str	q4, [sp, #3728]
	add	x5, sp, #3712
	ldr	s19, [x5, x17, lsl #2]
	tst	w15, w1
	fcsel	s19, s19, s23, ne
	cmp	w12, #8
	csel	w12, w12, wzr, lo
	cset	w15, lo
	add	x17, sp, #3576
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	and	w15, w15, w17
	and	x12, x12, #0x7
	str	q3, [sp, #3680]
	str	q4, [sp, #3696]
	mov.s	v17[1], v19[0]
	add	x17, sp, #3680
	ldr	s19, [x17, x12, lsl #2]
	tst	w6, w15
	ldr	x6, [sp, #152]                  ; 8-byte Folded Reload
	fcsel	s19, s19, s23, ne
	mov.s	v17[2], v19[0]
	xtn.2s	v19, v24
	cmp	w2, #8
	csel	w12, w2, wzr, lo
	cset	w15, lo
	add	x17, sp, #3576
	bfxil	x17, x12, #0, #3
	and	x12, x12, #0x7
	ldrb	w17, [x17]
	and	w15, w15, w17
	str	q3, [sp, #3648]
	str	q4, [sp, #3664]
	fmov	w17, s19
	add	x1, sp, #3648
	ldr	s19, [x1, x12, lsl #2]
	tst	w27, w15
	adrp	x27, lCPI0_8@PAGE
	fcsel	s19, s19, s23, ne
	eor	w12, w17, #0x4
	cmp	w17, #8
	csel	w12, w12, wzr, lo
	cset	w15, lo
	add	x17, sp, #3576
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	and	w15, w15, w17
	mov.s	v17[3], v19[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	tst	w7, w15
	mov.s	v6[3], v1[0]
	fadd.4s	v1, v3, v6
	fadd.4s	v3, v4, v17
	and	x12, x12, #0x7
	str	q3, [sp, #3632]
	str	q1, [sp, #3616]
	add	x15, sp, #3616
	ldr	s3, [x15, x12, lsl #2]
	fcsel	s3, s3, s23, ne
	tst	w23, #0x1
	add	x23, sp, #4, lsl #12            ; =16384
	add	x23, x23, #792
	fadd	s1, s1, s3
	fcsel	s1, s1, s23, ne
	tst	w10, #0x1
	fcsel	s3, s1, s23, ne
	tst	w19, #0x1
	ldp	x19, x7, [sp, #136]             ; 16-byte Folded Reload
	fcsel	s4, s1, s23, ne
	tst	w3, #0x1
	fcsel	s6, s1, s23, ne
	tst	w25, #0x1
	fcsel	s7, s1, s23, ne
	tst	w21, #0x1
	fcsel	s16, s1, s23, ne
	tst	w13, #0x1
	fcsel	s17, s1, s23, ne
	tst	w0, #0x1
	fcsel	s19, s1, s23, ne
	mov.s	v1[1], v3[0]
	mov.s	v1[2], v4[0]
	mov.s	v1[3], v6[0]
	rbit	w10, w11
	clz	w10, w10
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v19[0]
	mov.16b	v19, v11
	mov.16b	v11, v9
	mov.16b	v9, v25
	str	q7, [sp, #3600]
	str	q1, [sp, #3584]
	and	x10, x10, #0x7
	add	x11, sp, #3584
	ldr	s1, [x11, x10, lsl #2]
	fadd	s1, s1, s23
	ldr	q23, [sp, #336]                 ; 16-byte Folded Reload
	ldr	q18, [sp, #720]                 ; 16-byte Folded Reload
	mov	w10, #16384                     ; =0x4000
	movk	w10, #17600, lsl #16
	fmov	s3, w10
	fdiv	s1, s1, s3
	dup.4s	v1, v1[0]
	zip2.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #240]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #240]                  ; 16-byte Folded Spill
	zip1.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #256]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #256]                  ; 16-byte Folded Spill
	mov	b1, v21[6]
	mov.b	v1[4], v21[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov	b3, v21[4]
	mov.b	v3[4], v21[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	mov	b4, v21[2]
	mov.b	v4[4], v21[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	mov	b6, v21[0]
	mov.b	v6[4], v21[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	ldr	q7, [x27, lCPI0_8@PAGEOFF]
	ldr	q16, [sp, #944]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v1
	str	q16, [sp, #944]                 ; 16-byte Folded Spill
Lloh24:
	adrp	x10, lCPI0_9@PAGE
Lloh25:
	ldr	q7, [x10, lCPI0_9@PAGEOFF]
	bit.16b	v26, v7, v3
Lloh26:
	adrp	x10, lCPI0_10@PAGE
Lloh27:
	ldr	q7, [x10, lCPI0_10@PAGEOFF]
	bit.16b	v8, v7, v4
	str	q8, [sp, #960]                  ; 16-byte Folded Spill
Lloh28:
	adrp	x10, lCPI0_11@PAGE
Lloh29:
	ldr	q7, [x10, lCPI0_11@PAGEOFF]
	bit.16b	v20, v7, v6
	str	q20, [sp, #976]                 ; 16-byte Folded Spill
	ldr	q7, [sp, #112]                  ; 16-byte Folded Reload
	ldr	q16, [sp, #576]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v1
	bic.16b	v27, v27, v1
	ldr	q1, [sp, #544]                  ; 16-byte Folded Reload
	bit.16b	v1, v7, v3
	bic.16b	v12, v12, v3
	bit.16b	v22, v7, v4
	stp	q22, q1, [sp, #528]             ; 32-byte Folded Spill
	mov.16b	v22, v13
	mov.16b	v13, v30
	bic.16b	v10, v10, v4
	ldr	q1, [sp, #560]                  ; 16-byte Folded Reload
	bit.16b	v1, v7, v6
	stp	q1, q16, [sp, #560]             ; 32-byte Folded Spill
	bic.16b	v29, v29, v6
	add	x25, sp, #4, lsl #12            ; =16384
	add	x25, x25, #760
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #352
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #320
	mov	w5, #192                        ; =0xc0
	add	x3, sp, #3536
	ldr	x21, [sp, #168]                 ; 8-byte Folded Reload
	b	LBB0_180
LBB0_179:                               ;   in Loop: Header=BB0_5 Depth=1
	add	x25, sp, #4, lsl #12            ; =16384
	add	x25, x25, #760
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #352
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #320
	b	LBB0_76
LBB0_180:                               ; %schedule.11
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	dup.2d	v3, x5
	cmgt.2d	v1, v3, v10
	cmgt.2d	v4, v3, v29
	uzp1.4s	v1, v4, v1
	cmgt.2d	v4, v3, v12
	cmgt.2d	v6, v3, v27
	uzp1.4s	v4, v4, v6
	uzp1.8h	v1, v1, v4
	xtn.8b	v1, v1
	and.8b	v1, v21, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v4, v1, #0
	and.8b	v1, v4, v2
	addv.8b	b1, v1
	fmov	w10, s1
	umaxv.8b	b4, v4
	fmov	w13, s4
	tbz	w13, #0, LBB0_187
; %bb.181:                              ; %schedule.11
                                        ;   in Loop: Header=BB0_5 Depth=1
	cmge.2d	v4, v10, v3
	cmge.2d	v6, v29, v3
	uzp1.4s	v4, v6, v4
	cmge.2d	v6, v12, v3
	cmge.2d	v3, v27, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v3, v21, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w13, s3
	tst	w13, #0xff
	b.eq	LBB0_187
; %bb.182:                              ; %varying.divergent152
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w10, w14, #1
	csel	w10, wzr, w10, lo
	and	w11, w30, #0xff
	lsr	w12, w11, w10
	tst	w12, #0x1
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #1984]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #2000]
	and	x10, x10, #0x7
	add	x12, sp, #1984
	ldr	w10, [x12, x10, lsl #2]
	ccmp	w14, #0, #4, ne
	ccmp	w10, #3, #0, ne
	cset	w10, ne
	cmp	w11, #255
	b.ne	LBB0_184
; %bb.183:                              ; %varying.divergent152
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #0, LBB0_378
LBB0_184:                               ; %convergence.overflow.resume155
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w11, w30
	rbit	w11, w11
	clz	w11, w11
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w30
	csel	w11, wzr, w11, eq
	ubfiz	x12, x11, #2, #3
	lsl	w13, w16, w11
	ldr	q6, [sp, #1088]                 ; 16-byte Folded Reload
	str	q6, [sp, #1952]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #1968]
	add	x15, sp, #1952
	ldr	w15, [x15, x12]
	cmp	w10, #0
	csel	w10, w13, wzr, ne
	mov	w13, #3                         ; =0x3
	csel	w13, w13, w15, ne
	str	q6, [sp, #1920]
	str	q4, [sp, #1936]
	add	x15, sp, #1920
	str	w13, [x15, x12]
	ldr	q4, [sp, #1936]
	str	q4, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #1920]
	str	q4, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1056]                 ; 16-byte Folded Reload
	str	q6, [sp, #1888]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #1904]
	add	x13, sp, #1888
	ldr	w13, [x13, x12]
	csel	w13, w14, w13, ne
	str	q6, [sp, #1856]
	str	q4, [sp, #1872]
	add	x15, sp, #1856
	str	w13, [x15, x12]
	ldrb	w12, [x28, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	ldr	q6, [sp, #1872]
	str	q6, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1856]
	str	q6, [sp, #1056]                 ; 16-byte Folded Spill
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	ldrb	w12, [x8, x11]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	csetm	w12, ne
	dup.8b	v7, w12
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x28, x11]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x11]
	csinc	w11, w14, w11, eq
	cmp	w24, #8
	b.hs	LBB0_378
; %bb.185:                              ; %ready.overflow.resume157
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b1, [x23, x21]
	mov	w12, #12                        ; =0xc
	str	w12, [x25, x21, lsl #2]
	str	w11, [x26, x21, lsl #2]
	cmp	w9, #8
	b.hs	LBB0_378
; %bb.186:                              ; %ready.overflow.resume159
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b3, [x23, w9, uxtw]
	orr	w30, w10, w30
	mov	w10, #13                        ; =0xd
	b	LBB0_3
LBB0_187:                               ; %varying.coherent153
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_222
; %bb.188:                              ; %varying.coherent.true160
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_189:                               ; %schedule.12
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w10, w11
	clz	w10, w10
	tst	w11, #0xff
	csel	w10, wzr, w10, eq
	str	q29, [sp, #2080]
	str	q10, [sp, #2096]
	str	q12, [sp, #2112]
	str	q27, [sp, #2128]
	ubfiz	x13, x10, #3, #3
	add	x12, sp, #2080
	ldr	x15, [x12, x13]
	str	q24, [sp, #2016]
	str	q14, [sp, #2032]
	str	q31, [sp, #2048]
	str	q5, [sp, #2064]
	add	x12, sp, #2016
	ldr	x13, [x12, x13]
	sub	x10, x13, x10
	add	x13, x7, x15, lsl #5
	add	x10, x13, x10, lsl #2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b4, v1
	fmov	w13, s4
	movi.2d	v3, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbnz	w13, #0, LBB0_208
; %bb.190:                              ; %else299
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #1, LBB0_209
LBB0_191:                               ; %else302
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #2, LBB0_210
LBB0_192:                               ; %else305
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #3, LBB0_211
LBB0_193:                               ; %else308
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #4, LBB0_212
LBB0_194:                               ; %else311
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #5, LBB0_213
LBB0_195:                               ; %else314
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #6, LBB0_214
LBB0_196:                               ; %else317
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v30, v24
	mov.16b	v24, v19
	tbz	w13, #7, LBB0_198
LBB0_197:                               ; %cond.load319
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x10, x10, #28
	ld1.s	{ v1 }[3], [x10]
LBB0_198:                               ; %else320
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v6, v29, #5
	shl.2d	v7, v10, #5
	shl.2d	v17, v12, #5
	shl.2d	v19, v27, #5
	ldr	q16, [sp, #560]                 ; 16-byte Folded Reload
	ldp	q20, q25, [sp, #960]            ; 32-byte Folded Reload
	add.2d	v16, v16, v25
	add.2d	v16, v16, v6
	ldr	q6, [sp, #528]                  ; 16-byte Folded Reload
	add.2d	v6, v6, v20
	add.2d	v7, v6, v7
	ldr	q6, [sp, #544]                  ; 16-byte Folded Reload
	add.2d	v6, v6, v26
	add.2d	v6, v6, v17
	ldr	q17, [sp, #576]                 ; 16-byte Folded Reload
	ldr	q20, [sp, #944]                 ; 16-byte Folded Reload
	add.2d	v17, v17, v20
	fmov	w10, s4
	add.2d	v4, v17, v19
	tbnz	w10, #0, LBB0_215
; %bb.199:                              ; %else324
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v19, v24
	tbnz	w10, #1, LBB0_216
LBB0_200:                               ; %else327
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v24, v30
	tbnz	w10, #2, LBB0_217
LBB0_201:                               ; %else330
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #3, LBB0_218
LBB0_202:                               ; %else333
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #4, LBB0_219
LBB0_203:                               ; %else336
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #5, LBB0_220
LBB0_204:                               ; %else339
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #6, LBB0_221
LBB0_205:                               ; %else342
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w10, #7, LBB0_207
LBB0_206:                               ; %cond.store343
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v4[1]
	st1.s	{ v1 }[3], [x10]
LBB0_207:                               ; %else345
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.8b	v1, #1
	and.8b	v1, v21, v1
	ushll.8h	v1, v1, #0
	ushll.4s	v3, v1, #0
	ushll2.4s	v1, v1, #0
	uaddw2.2d	v27, v27, v1
	uaddw.2d	v12, v12, v1
	uaddw2.2d	v10, v10, v3
	uaddw.2d	v29, v29, v3
	tst	w11, #0xff
	b.ne	LBB0_180
	b	LBB0_4
LBB0_208:                               ; %cond.load298
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s3, [x10]
	tbz	w13, #1, LBB0_191
LBB0_209:                               ; %cond.load301
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x10, #4
	ld1.s	{ v3 }[1], [x15]
	tbz	w13, #2, LBB0_192
LBB0_210:                               ; %cond.load304
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x10, #8
	ld1.s	{ v3 }[2], [x15]
	tbz	w13, #3, LBB0_193
LBB0_211:                               ; %cond.load307
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x10, #12
	ld1.s	{ v3 }[3], [x15]
	tbz	w13, #4, LBB0_194
LBB0_212:                               ; %cond.load310
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x10, #16
	ld1.s	{ v1 }[0], [x15]
	tbz	w13, #5, LBB0_195
LBB0_213:                               ; %cond.load313
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x10, #20
	ld1.s	{ v1 }[1], [x15]
	tbz	w13, #6, LBB0_196
LBB0_214:                               ; %cond.load316
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x10, #24
	ld1.s	{ v1 }[2], [x15]
	mov.16b	v30, v24
	mov.16b	v24, v19
	tbnz	w13, #7, LBB0_197
	b	LBB0_198
LBB0_215:                               ; %cond.store
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d16
	str	s3, [x13]
	mov.16b	v19, v24
	tbz	w10, #1, LBB0_200
LBB0_216:                               ; %cond.store325
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v16[1]
	st1.s	{ v3 }[1], [x13]
	mov.16b	v24, v30
	tbz	w10, #2, LBB0_201
LBB0_217:                               ; %cond.store328
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d7
	st1.s	{ v3 }[2], [x13]
	tbz	w10, #3, LBB0_202
LBB0_218:                               ; %cond.store331
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v7[1]
	st1.s	{ v3 }[3], [x13]
	tbz	w10, #4, LBB0_203
LBB0_219:                               ; %cond.store334
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d6
	str	s1, [x13]
	tbz	w10, #5, LBB0_204
LBB0_220:                               ; %cond.store337
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v6[1]
	st1.s	{ v1 }[1], [x13]
	tbz	w10, #6, LBB0_205
LBB0_221:                               ; %cond.store340
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x13, d4
	st1.s	{ v1 }[2], [x13]
	tbnz	w10, #7, LBB0_206
	b	LBB0_207
LBB0_222:                               ; %varying.coherent.false161
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_223:                               ; %schedule.13
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w14, LBB0_228
; %bb.224:                              ; %convergence.cascade172.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w10, #0                         ; =0x0
LBB0_225:                               ; %convergence.cascade172
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w12, s1
	sub	w13, w14, #1
	tst	w11, #0xff
	csel	w13, w13, wzr, ne
	lsl	w15, w16, w13
	and	w11, w15, w30
	tst	w11, #0xff
	cset	w17, ne
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #3536]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #3552]
	ubfiz	x11, x13, #2, #3
	ldr	w0, [x3, x11]
	cmp	w0, #3
	cset	w0, eq
	and	w2, w17, w12
	ldrb	w12, [x28, w13, sxtw]
	and	w17, w12, #0x1
	fmov	s1, w17
	ubfx	w17, w12, #1, #1
	mov.b	v1[1], w17
	ubfx	w17, w12, #2, #1
	mov.b	v1[2], w17
	ubfx	w17, w12, #3, #1
	mov.b	v1[3], w17
	ubfx	w17, w12, #4, #1
	mov.b	v1[4], w17
	ubfx	w17, w12, #5, #1
	mov.b	v1[5], w17
	ubfx	w17, w12, #6, #1
	mov.b	v1[6], w17
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, w13, sxtw]
	and	w17, w12, #0x1
	fmov	s3, w17
	ubfx	w17, w12, #1, #1
	mov.b	v3[1], w17
	ubfx	w17, w12, #2, #1
	mov.b	v3[2], w17
	ubfx	w17, w12, #3, #1
	mov.b	v3[3], w17
	ubfx	w17, w12, #4, #1
	mov.b	v3[4], w17
	ubfx	w17, w12, #5, #1
	mov.b	v3[5], w17
	ubfx	w17, w12, #6, #1
	mov.b	v3[6], w17
	lsr	w12, w12, #7
	mov.b	v3[7], w12
	orr.8b	v4, v21, v3
	and.8b	v6, v0, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w12, s6
	ands	w17, w2, w0
	csetm	w0, ne
	bics	w12, w17, w12
	csetm	w1, ne
	dup.8b	v6, w1
	dup.8b	v7, w0
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w13, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x28, w13, sxtw]
	csinv	w13, w4, w15, eq
	dup.8b	v1, w17
	and	w30, w13, w30
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w12
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #3504]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #3520]
	add	x12, sp, #3504
	ldr	w11, [x12, x11]
	csel	w14, w11, w14, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w17, #1
	b.ne	LBB0_229
; %bb.226:                              ; %convergence.cascade172
                                        ;   in Loop: Header=BB0_225 Depth=2
	cmp	w14, #0
	ccmp	w10, #6, #2, ne
	b.hi	LBB0_229
; %bb.227:                              ; %convergence.cascade172
                                        ;   in Loop: Header=BB0_225 Depth=2
	add	w10, w10, #1
	tst	w11, #0xff
	b.ne	LBB0_225
	b	LBB0_229
LBB0_228:                               ; %schedule.13.convergence.cascade.exit173_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_229:                               ; %convergence.cascade.exit173
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_263
; %bb.230:                              ; %convergence.target.13.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v1, v11, v21
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	and.8b	v1, v3, v2
	addv.8b	b1, v1
	umaxv.8b	b3, v3
	fmov	w10, s3
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #352
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #320
	tbz	w10, #0, LBB0_237
; %bb.231:                              ; %convergence.target.13.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v3, v21, v11
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w10, s3
	tst	w10, #0xff
	b.eq	LBB0_237
; %bb.232:                              ; %varying.divergent190
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w10, w14, #1
	csel	w10, wzr, w10, lo
	and	w11, w30, #0xff
	lsr	w12, w11, w10
	tst	w12, #0x1
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #2272]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #2288]
	and	x10, x10, #0x7
	add	x12, sp, #2272
	ldr	w10, [x12, x10, lsl #2]
	ccmp	w14, #0, #4, ne
	ccmp	w10, #4, #0, ne
	cset	w10, ne
	cmp	w11, #255
	b.ne	LBB0_234
; %bb.233:                              ; %varying.divergent190
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #0, LBB0_378
LBB0_234:                               ; %convergence.overflow.resume193
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w11, w30
	rbit	w11, w11
	clz	w11, w11
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w30
	csel	w11, wzr, w11, eq
	ubfiz	x12, x11, #2, #3
	lsl	w13, w16, w11
	ldr	q6, [sp, #1088]                 ; 16-byte Folded Reload
	str	q6, [sp, #2240]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #2256]
	add	x15, sp, #2240
	ldr	w15, [x15, x12]
	cmp	w10, #0
	csel	w10, w13, wzr, ne
	mov	w13, #4                         ; =0x4
	csel	w13, w13, w15, ne
	str	q6, [sp, #2208]
	str	q4, [sp, #2224]
	add	x15, sp, #2208
	str	w13, [x15, x12]
	ldr	q4, [sp, #2224]
	str	q4, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #2208]
	str	q4, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1056]                 ; 16-byte Folded Reload
	str	q6, [sp, #2176]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #2192]
	add	x13, sp, #2176
	ldr	w13, [x13, x12]
	csel	w13, w14, w13, ne
	str	q6, [sp, #2144]
	str	q4, [sp, #2160]
	add	x15, sp, #2144
	str	w13, [x15, x12]
	ldrb	w12, [x28, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	ldr	q6, [sp, #2160]
	str	q6, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #2144]
	str	q6, [sp, #1056]                 ; 16-byte Folded Spill
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	ldrb	w12, [x8, x11]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	csetm	w12, ne
	dup.8b	v7, w12
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x28, x11]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x11]
	csinc	w11, w14, w11, eq
	cmp	w24, #8
	b.hs	LBB0_378
; %bb.235:                              ; %ready.overflow.resume195
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b1, [x23, x21]
	mov	w12, #14                        ; =0xe
	str	w12, [x25, x21, lsl #2]
	str	w11, [x26, x21, lsl #2]
	cmp	w9, #8
	b.hs	LBB0_378
; %bb.236:                              ; %ready.overflow.resume197
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b3, [x23, w9, uxtw]
	orr	w30, w10, w30
	mov	w10, #15                        ; =0xf
	b	LBB0_3
LBB0_237:                               ; %varying.coherent191
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	w10, s1
	tst	w10, #0xff
	b.eq	LBB0_248
LBB0_238:                               ; %schedule.14
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w10, w11
	clz	w10, w10
	tst	w11, #0xff
	csel	w10, wzr, w10, eq
	str	q24, [sp, #3440]
	str	q14, [sp, #3456]
	str	q31, [sp, #3472]
	str	q5, [sp, #3488]
	and	x13, x10, #0x7
	add	x12, sp, #3440
	ldr	x13, [x12, x13, lsl #3]
	sub	x13, x13, x10
	ldr	x12, [sp, #160]                 ; 8-byte Folded Reload
	add	x13, x12, x13, lsl #2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w15, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w15, #0, LBB0_256
; %bb.239:                              ; %else348
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w15, #1, LBB0_257
LBB0_240:                               ; %else351
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w15, #2, LBB0_258
LBB0_241:                               ; %else354
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w15, #3, LBB0_259
LBB0_242:                               ; %else357
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w15, #4, LBB0_260
LBB0_243:                               ; %else360
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w15, #5, LBB0_261
LBB0_244:                               ; %else363
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w15, #6, LBB0_262
LBB0_245:                               ; %else366
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w15, #7, LBB0_247
LBB0_246:                               ; %cond.load368
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x13, x13, #28
	ld1.s	{ v3 }[3], [x13]
LBB0_247:                               ; %else369
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldp	q4, q6, [sp, #960]              ; 32-byte Folded Reload
	str	q6, [sp, #3376]
	str	q4, [sp, #3392]
	str	q26, [sp, #3408]
	ldr	q4, [sp, #944]                  ; 16-byte Folded Reload
	str	q4, [sp, #3424]
	and	x13, x10, #0x7
	add	x12, sp, #3376
	ldr	x13, [x12, x13, lsl #3]
	sub	x10, x13, x10, lsl #2
	mov	w12, #6144                      ; =0x1800
	add	x10, x10, x12
	ands	w11, w11, #0xff
	csel	x10, xzr, x10, eq
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #648
	add	x10, x12, x10
	ldp	q4, q6, [x10]
	zip2.8b	v7, v21, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bif.16b	v3, v6, v7
	zip1.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bif.16b	v1, v4, v6
	stp	q1, q3, [x10]
	cbz	w11, LBB0_4
LBB0_248:                               ; %schedule.15
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w14, LBB0_253
; %bb.249:                              ; %convergence.cascade209.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w10, #0                         ; =0x0
LBB0_250:                               ; %convergence.cascade209
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w12, s1
	sub	w13, w14, #1
	tst	w11, #0xff
	csel	w13, w13, wzr, ne
	lsl	w15, w16, w13
	and	w11, w15, w30
	tst	w11, #0xff
	cset	w17, ne
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #3344]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #3360]
	ubfiz	x11, x13, #2, #3
	add	x0, sp, #3344
	ldr	w0, [x0, x11]
	cmp	w0, #4
	cset	w0, eq
	and	w2, w17, w12
	ldrb	w12, [x28, w13, sxtw]
	and	w17, w12, #0x1
	fmov	s1, w17
	ubfx	w17, w12, #1, #1
	mov.b	v1[1], w17
	ubfx	w17, w12, #2, #1
	mov.b	v1[2], w17
	ubfx	w17, w12, #3, #1
	mov.b	v1[3], w17
	ubfx	w17, w12, #4, #1
	mov.b	v1[4], w17
	ubfx	w17, w12, #5, #1
	mov.b	v1[5], w17
	ubfx	w17, w12, #6, #1
	mov.b	v1[6], w17
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, w13, sxtw]
	and	w17, w12, #0x1
	fmov	s3, w17
	ubfx	w17, w12, #1, #1
	mov.b	v3[1], w17
	ubfx	w17, w12, #2, #1
	mov.b	v3[2], w17
	ubfx	w17, w12, #3, #1
	mov.b	v3[3], w17
	ubfx	w17, w12, #4, #1
	mov.b	v3[4], w17
	ubfx	w17, w12, #5, #1
	mov.b	v3[5], w17
	ubfx	w17, w12, #6, #1
	mov.b	v3[6], w17
	lsr	w12, w12, #7
	mov.b	v3[7], w12
	orr.8b	v4, v21, v3
	and.8b	v6, v0, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w12, s6
	ands	w17, w2, w0
	csetm	w0, ne
	bics	w12, w17, w12
	csetm	w1, ne
	dup.8b	v6, w1
	dup.8b	v7, w0
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w13, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x28, w13, sxtw]
	csinv	w13, w4, w15, eq
	dup.8b	v1, w17
	and	w30, w13, w30
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w12
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #3312]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #3328]
	add	x12, sp, #3312
	ldr	w11, [x12, x11]
	csel	w14, w11, w14, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w17, #1
	b.ne	LBB0_254
; %bb.251:                              ; %convergence.cascade209
                                        ;   in Loop: Header=BB0_250 Depth=2
	cmp	w14, #0
	ccmp	w10, #6, #2, ne
	b.hi	LBB0_254
; %bb.252:                              ; %convergence.cascade209
                                        ;   in Loop: Header=BB0_250 Depth=2
	add	w10, w10, #1
	tst	w11, #0xff
	b.ne	LBB0_250
	b	LBB0_254
LBB0_253:                               ; %schedule.15.convergence.cascade.exit210_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_254:                               ; %convergence.cascade.exit210
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_263
; %bb.255:                              ; %convergence.target.15.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w10, w11
	clz	w10, w10
	ldp	q1, q3, [sp, #240]              ; 32-byte Folded Reload
	str	q3, [sp, #3280]
	str	q1, [sp, #3296]
	and	x10, x10, #0x7
	add	x11, sp, #3280
	ldr	s1, [x11, x10, lsl #2]
	mov	w10, #50604                     ; =0xc5ac
	movk	w10, #14119, lsl #16
	fmov	s3, w10
	fadd	s1, s1, s3
	fsqrt	s1, s1
	dup.4s	v1, v1[0]
	zip2.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #304]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #304]                  ; 16-byte Folded Spill
	zip1.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #832]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #832]                  ; 16-byte Folded Spill
	mov	b1, v21[6]
	mov.b	v1[4], v21[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v28, v1, v28
	mov	b1, v21[4]
	mov.b	v1[4], v21[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	mov	b3, v21[2]
	mov.b	v3[4], v21[3]
	and.16b	v23, v1, v23
	ushll.2d	v1, v3, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	ldr	q3, [sp, #1040]                 ; 16-byte Folded Reload
	and.16b	v3, v1, v3
	str	q3, [sp, #1040]                 ; 16-byte Folded Spill
	mov	b1, v21[0]
	mov.b	v1[4], v21[1]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v18, v1, v18
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #352
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #320
	b	LBB0_264
LBB0_256:                               ; %cond.load347
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s1, [x13]
	tbz	w15, #1, LBB0_240
LBB0_257:                               ; %cond.load350
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x13, #4
	ld1.s	{ v1 }[1], [x0]
	tbz	w15, #2, LBB0_241
LBB0_258:                               ; %cond.load353
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x13, #8
	ld1.s	{ v1 }[2], [x0]
	tbz	w15, #3, LBB0_242
LBB0_259:                               ; %cond.load356
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x13, #12
	ld1.s	{ v1 }[3], [x0]
	tbz	w15, #4, LBB0_243
LBB0_260:                               ; %cond.load359
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x13, #16
	ld1.s	{ v3 }[0], [x0]
	tbz	w15, #5, LBB0_244
LBB0_261:                               ; %cond.load362
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x13, #20
	ld1.s	{ v3 }[1], [x0]
	tbz	w15, #6, LBB0_245
LBB0_262:                               ; %cond.load365
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x13, #24
	ld1.s	{ v3 }[2], [x0]
	tbnz	w15, #7, LBB0_246
	b	LBB0_247
LBB0_263:                               ;   in Loop: Header=BB0_5 Depth=1
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #352
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #320
	b	LBB0_4
LBB0_264:                               ; %schedule.16
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	dup.2d	v3, x5
	ldr	q1, [sp, #1040]                 ; 16-byte Folded Reload
	cmgt.2d	v1, v3, v1
	cmgt.2d	v4, v3, v18
	uzp1.4s	v1, v4, v1
	cmgt.2d	v4, v3, v23
	cmgt.2d	v6, v3, v28
	uzp1.4s	v4, v4, v6
	uzp1.8h	v1, v1, v4
	xtn.8b	v1, v1
	and.8b	v1, v21, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v4, v1, #0
	and.8b	v1, v4, v2
	addv.8b	b1, v1
	fmov	w10, s1
	umaxv.8b	b4, v4
	fmov	w13, s4
	tbz	w13, #0, LBB0_271
; %bb.265:                              ; %schedule.16
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q4, [sp, #1040]                 ; 16-byte Folded Reload
	cmge.2d	v4, v4, v3
	cmge.2d	v6, v18, v3
	uzp1.4s	v4, v6, v4
	cmge.2d	v6, v23, v3
	cmge.2d	v3, v28, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v3, v21, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w13, s3
	tst	w13, #0xff
	b.eq	LBB0_271
; %bb.266:                              ; %varying.divergent230
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w10, w14, #1
	csel	w10, wzr, w10, lo
	and	w11, w30, #0xff
	lsr	w12, w11, w10
	tst	w12, #0x1
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #2432]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #2448]
	and	x10, x10, #0x7
	add	x12, sp, #2432
	ldr	w10, [x12, x10, lsl #2]
	ccmp	w14, #0, #4, ne
	ccmp	w10, #5, #0, ne
	cset	w10, ne
	cmp	w11, #255
	b.ne	LBB0_268
; %bb.267:                              ; %varying.divergent230
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #0, LBB0_378
LBB0_268:                               ; %convergence.overflow.resume233
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w11, w30
	rbit	w11, w11
	clz	w11, w11
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w30
	csel	w11, wzr, w11, eq
	ubfiz	x12, x11, #2, #3
	lsl	w13, w16, w11
	ldr	q6, [sp, #1088]                 ; 16-byte Folded Reload
	str	q6, [sp, #2400]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #2416]
	add	x15, sp, #2400
	ldr	w15, [x15, x12]
	cmp	w10, #0
	csel	w10, w13, wzr, ne
	mov	w13, #5                         ; =0x5
	csel	w13, w13, w15, ne
	str	q6, [sp, #2368]
	str	q4, [sp, #2384]
	add	x15, sp, #2368
	str	w13, [x15, x12]
	ldr	q4, [sp, #2384]
	str	q4, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #2368]
	str	q4, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1056]                 ; 16-byte Folded Reload
	str	q6, [sp, #2336]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #2352]
	add	x13, sp, #2336
	ldr	w13, [x13, x12]
	csel	w13, w14, w13, ne
	str	q6, [sp, #2304]
	str	q4, [sp, #2320]
	add	x15, sp, #2304
	str	w13, [x15, x12]
	ldrb	w12, [x28, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	ldr	q6, [sp, #2320]
	str	q6, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #2304]
	str	q6, [sp, #1056]                 ; 16-byte Folded Spill
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	ldrb	w12, [x8, x11]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	csetm	w12, ne
	dup.8b	v7, w12
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x28, x11]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x11]
	csinc	w11, w14, w11, eq
	cmp	w24, #8
	b.hs	LBB0_378
; %bb.269:                              ; %ready.overflow.resume235
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b1, [x23, x21]
	mov	w12, #17                        ; =0x11
	str	w12, [x25, x21, lsl #2]
	str	w11, [x26, x21, lsl #2]
	cmp	w9, #8
	b.hs	LBB0_378
; %bb.270:                              ; %ready.overflow.resume237
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b3, [x23, w9, uxtw]
	orr	w30, w10, w30
	mov	w10, #18                        ; =0x12
	b	LBB0_3
LBB0_271:                               ; %varying.coherent231
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_322
; %bb.272:                              ; %varying.coherent.true238
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_273:                               ; %schedule.17
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	d0, [sp, #368]                  ; 8-byte Folded Spill
	stp	q29, q27, [sp, #736]            ; 32-byte Folded Spill
	stp	q10, q12, [sp, #496]            ; 32-byte Folded Spill
	ldr	q27, [sp, #960]                 ; 16-byte Folded Reload
	stp	q31, q24, [sp, #464]            ; 32-byte Folded Spill
	mov.16b	v16, v28
	str	q14, [sp, #768]                 ; 16-byte Folded Spill
	mov.16b	v30, v22
	ldr	q28, [sp, #304]                 ; 16-byte Folded Reload
	stp	q5, q18, [sp, #704]             ; 32-byte Folded Spill
	ldr	q0, [sp, #832]                  ; 16-byte Folded Reload
	mov.16b	v12, v19
	mov.16b	v22, v15
	ldr	q1, [sp, #1040]                 ; 16-byte Folded Reload
	rbit	w10, w11
	clz	w10, w10
	tst	w11, #0xff
	csel	w10, wzr, w10, eq
	shl.2d	v4, v18, #5
	shl.2d	v6, v1, #5
	mov.16b	v18, v23
	shl.2d	v7, v23, #5
	mov.16b	v14, v16
	shl.2d	v16, v16, #5
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	ldp	q3, q5, [sp, #912]              ; 32-byte Folded Reload
	add.2d	v1, v1, v5
	add.2d	v25, v1, v4
	ldr	q1, [sp, #416]                  ; 16-byte Folded Reload
	add.2d	v1, v1, v3
	add.2d	v23, v1, v6
	ldr	q1, [sp, #400]                  ; 16-byte Folded Reload
	ldp	q3, q5, [sp, #880]              ; 32-byte Folded Reload
	add.2d	v1, v1, v5
	add.2d	v20, v1, v7
	ldr	q1, [sp, #384]                  ; 16-byte Folded Reload
	add.2d	v1, v1, v3
	add.2d	v19, v1, v16
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b15, v1
	fmov	w13, s15
	movi.2d	v17, #0000000000000000
	movi.2d	v3, #0000000000000000
	str	q9, [sp, #448]                  ; 16-byte Folded Spill
	str	q0, [sp, #832]                  ; 16-byte Folded Spill
	str	q27, [sp, #960]                 ; 16-byte Folded Spill
	tbnz	w13, #0, LBB0_302
; %bb.274:                              ; %else376
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #1, LBB0_303
LBB0_275:                               ; %else382
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #2, LBB0_304
LBB0_276:                               ; %else388
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #3, LBB0_305
LBB0_277:                               ; %else394
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v10, v26
	tbnz	w13, #4, LBB0_306
LBB0_278:                               ; %else400
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v9, v22
	mov.16b	v1, v12
	mov.16b	v26, v27
	tbnz	w13, #5, LBB0_307
LBB0_279:                               ; %else406
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	d29, [sp, #368]                 ; 8-byte Folded Reload
	mov.16b	v22, v30
	tbz	w13, #6, LBB0_281
LBB0_280:                               ; %cond.load408
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x15, d19
	ld1.s	{ v3 }[2], [x15]
LBB0_281:                               ; %else412
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldp	q24, q30, [sp, #480]            ; 32-byte Folded Reload
	ldr	q5, [sp, #512]                  ; 16-byte Folded Reload
	mov.16b	v20, v14
	ldp	q25, q14, [sp, #752]            ; 32-byte Folded Reload
	mov.16b	v27, v20
	mov.16b	v12, v18
	tbz	w13, #7, LBB0_283
; %bb.282:                              ; %cond.load414
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v19[1]
	ld1.s	{ v3 }[3], [x13]
LBB0_283:                               ; %else418
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q31, [sp, #464]                 ; 16-byte Folded Reload
	str	q0, [sp, #2656]
	str	q28, [sp, #2672]
	and	x13, x10, #0x7
	add	x12, sp, #2656
	add	x13, x12, x13, lsl #2
	ld1r.4s	{ v19 }, [x13]
	fdiv.4s	v3, v3, v19
	fdiv.4s	v17, v17, v19
	ldr	q18, [sp, #944]                 ; 16-byte Folded Reload
	add.2d	v23, v16, v18
	add.2d	v7, v7, v10
	add.2d	v6, v6, v26
	ldr	q16, [sp, #976]                 ; 16-byte Folded Reload
	add.2d	v4, v4, v16
	ldr	q16, [sp, #560]                 ; 16-byte Folded Reload
	add.2d	v20, v16, v4
	ldp	q0, q4, [sp, #528]              ; 32-byte Folded Reload
	add.2d	v19, v0, v6
	add.2d	v16, v4, v7
	ldr	q4, [sp, #576]                  ; 16-byte Folded Reload
	add.2d	v7, v4, v23
	fmov	w13, s15
	movi.2d	v6, #0000000000000000
	movi.2d	v4, #0000000000000000
	ldr	q28, [sp, #704]                 ; 16-byte Folded Reload
	tbnz	w13, #0, LBB0_308
; %bb.284:                              ; %else425
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q18, [sp, #720]                 ; 16-byte Folded Reload
	tbnz	w13, #1, LBB0_309
LBB0_285:                               ; %else431
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q20, [sp, #736]                 ; 16-byte Folded Reload
	mov.16b	v23, v12
	mov.16b	v12, v5
	tbnz	w13, #2, LBB0_310
LBB0_286:                               ; %else437
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v5, v28
	mov.16b	v28, v27
	tbnz	w13, #3, LBB0_311
LBB0_287:                               ; %else443
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v19, v1
	mov.16b	v27, v25
	tbnz	w13, #4, LBB0_312
LBB0_288:                               ; %else449
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v26, v10
	tbnz	w13, #5, LBB0_313
LBB0_289:                               ; %else455
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v10, v30
	tbnz	w13, #6, LBB0_314
LBB0_290:                               ; %else461
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	d0, d29
	tbz	w13, #7, LBB0_292
LBB0_291:                               ; %cond.load463
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x13, v7[1]
	ld1.s	{ v4 }[3], [x13]
LBB0_292:                               ; %else467
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v29, v20
	fmul.4s	v6, v6, v17
	ldp	q7, q1, [sp, #672]              ; 32-byte Folded Reload
	str	q1, [sp, #2592]
	str	q7, [sp, #2608]
	ldp	q7, q1, [sp, #640]              ; 32-byte Folded Reload
	str	q1, [sp, #2624]
	str	q7, [sp, #2640]
	ubfiz	x13, x10, #3, #3
	add	x12, sp, #2592
	ldr	x15, [x12, x13]
	str	q18, [sp, #2528]
	ldr	q7, [sp, #1040]                 ; 16-byte Folded Reload
	str	q7, [sp, #2544]
	str	q23, [sp, #2560]
	str	q28, [sp, #2576]
	add	x12, sp, #2528
	ldr	x0, [x12, x13]
	str	q24, [sp, #2464]
	str	q14, [sp, #2480]
	str	q31, [sp, #2496]
	str	q5, [sp, #2512]
	add	x12, sp, #2464
	ldr	x13, [x12, x13]
	fmul.4s	v3, v4, v3
	sub	x10, x13, x10
	mov	w12, #1538                      ; =0x602
	madd	x10, x15, x12, x10
	add	x13, x19, x0, lsl #5
	add	x10, x13, x10, lsl #2
	fmov	w13, s15
	tbnz	w13, #0, LBB0_315
; %bb.293:                              ; %else471
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v15, v9
	tbnz	w13, #1, LBB0_316
LBB0_294:                               ; %else473
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q9, [sp, #448]                  ; 16-byte Folded Reload
	tbnz	w13, #2, LBB0_317
LBB0_295:                               ; %else475
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #3, LBB0_318
LBB0_296:                               ; %else477
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #4, LBB0_319
LBB0_297:                               ; %else479
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #5, LBB0_320
LBB0_298:                               ; %else481
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w13, #6, LBB0_321
LBB0_299:                               ; %else483
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w13, #7, LBB0_301
LBB0_300:                               ; %cond.store484
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x10, x10, #28
	st1.s	{ v3 }[3], [x10]
LBB0_301:                               ; %else485
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.8b	v1, #1
	and.8b	v1, v21, v1
	ushll.8h	v1, v1, #0
	ushll.4s	v3, v1, #0
	ushll2.4s	v1, v1, #0
	uaddw2.2d	v28, v28, v1
	uaddw.2d	v23, v23, v1
	ldr	q1, [sp, #1040]                 ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v3
	str	q1, [sp, #1040]                 ; 16-byte Folded Spill
	uaddw.2d	v18, v18, v3
	tst	w11, #0xff
	b.ne	LBB0_264
	b	LBB0_4
LBB0_302:                               ; %cond.load372
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x15, d25
	ldr	s17, [x15]
	tbz	w13, #1, LBB0_275
LBB0_303:                               ; %cond.load378
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x15, v25[1]
	ld1.s	{ v17 }[1], [x15]
	tbz	w13, #2, LBB0_276
LBB0_304:                               ; %cond.load384
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x15, d23
	ld1.s	{ v17 }[2], [x15]
	tbz	w13, #3, LBB0_277
LBB0_305:                               ; %cond.load390
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x15, v23[1]
	ld1.s	{ v17 }[3], [x15]
	mov.16b	v10, v26
	tbz	w13, #4, LBB0_278
LBB0_306:                               ; %cond.load396
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x15, d20
	ld1.s	{ v3 }[0], [x15]
	mov.16b	v9, v22
	mov.16b	v1, v12
	mov.16b	v26, v27
	tbz	w13, #5, LBB0_279
LBB0_307:                               ; %cond.load402
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x15, v20[1]
	ld1.s	{ v3 }[1], [x15]
	ldr	d29, [sp, #368]                 ; 8-byte Folded Reload
	mov.16b	v22, v30
	tbnz	w13, #6, LBB0_280
	b	LBB0_281
LBB0_308:                               ; %cond.load421
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x15, d20
	ldr	s6, [x15]
	ldr	q18, [sp, #720]                 ; 16-byte Folded Reload
	tbz	w13, #1, LBB0_285
LBB0_309:                               ; %cond.load427
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x15, v20[1]
	ld1.s	{ v6 }[1], [x15]
	ldr	q20, [sp, #736]                 ; 16-byte Folded Reload
	mov.16b	v23, v12
	mov.16b	v12, v5
	tbz	w13, #2, LBB0_286
LBB0_310:                               ; %cond.load433
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x15, d19
	ld1.s	{ v6 }[2], [x15]
	mov.16b	v5, v28
	mov.16b	v28, v27
	tbz	w13, #3, LBB0_287
LBB0_311:                               ; %cond.load439
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x15, v19[1]
	ld1.s	{ v6 }[3], [x15]
	mov.16b	v19, v1
	mov.16b	v27, v25
	tbz	w13, #4, LBB0_288
LBB0_312:                               ; %cond.load445
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x15, d16
	ld1.s	{ v4 }[0], [x15]
	mov.16b	v26, v10
	tbz	w13, #5, LBB0_289
LBB0_313:                               ; %cond.load451
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x15, v16[1]
	ld1.s	{ v4 }[1], [x15]
	mov.16b	v10, v30
	tbz	w13, #6, LBB0_290
LBB0_314:                               ; %cond.load457
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x15, d7
	ld1.s	{ v4 }[2], [x15]
	fmov	d0, d29
	tbnz	w13, #7, LBB0_291
	b	LBB0_292
LBB0_315:                               ; %cond.store470
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s6, [x10]
	mov.16b	v15, v9
	tbz	w13, #1, LBB0_294
LBB0_316:                               ; %cond.store472
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x10, #4
	st1.s	{ v6 }[1], [x15]
	ldr	q9, [sp, #448]                  ; 16-byte Folded Reload
	tbz	w13, #2, LBB0_295
LBB0_317:                               ; %cond.store474
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x10, #8
	st1.s	{ v6 }[2], [x15]
	tbz	w13, #3, LBB0_296
LBB0_318:                               ; %cond.store476
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x10, #12
	st1.s	{ v6 }[3], [x15]
	tbz	w13, #4, LBB0_297
LBB0_319:                               ; %cond.store478
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s3, [x10, #16]
	tbz	w13, #5, LBB0_298
LBB0_320:                               ; %cond.store480
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x10, #20
	st1.s	{ v3 }[1], [x15]
	tbz	w13, #6, LBB0_299
LBB0_321:                               ; %cond.store482
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x10, #24
	st1.s	{ v3 }[2], [x15]
	tbnz	w13, #7, LBB0_300
	b	LBB0_301
LBB0_322:                               ; %varying.coherent.false239
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_323:                               ; %schedule.18
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w14, LBB0_328
; %bb.324:                              ; %convergence.cascade252.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w10, #0                         ; =0x0
LBB0_325:                               ; %convergence.cascade252
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w12, s1
	sub	w13, w14, #1
	tst	w11, #0xff
	csel	w13, w13, wzr, ne
	lsl	w15, w16, w13
	and	w11, w15, w30
	tst	w11, #0xff
	cset	w17, ne
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #3248]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #3264]
	ubfiz	x11, x13, #2, #3
	add	x0, sp, #3248
	ldr	w0, [x0, x11]
	cmp	w0, #5
	cset	w0, eq
	and	w2, w17, w12
	ldrb	w12, [x28, w13, sxtw]
	and	w17, w12, #0x1
	fmov	s1, w17
	ubfx	w17, w12, #1, #1
	mov.b	v1[1], w17
	ubfx	w17, w12, #2, #1
	mov.b	v1[2], w17
	ubfx	w17, w12, #3, #1
	mov.b	v1[3], w17
	ubfx	w17, w12, #4, #1
	mov.b	v1[4], w17
	ubfx	w17, w12, #5, #1
	mov.b	v1[5], w17
	ubfx	w17, w12, #6, #1
	mov.b	v1[6], w17
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, w13, sxtw]
	and	w17, w12, #0x1
	fmov	s3, w17
	ubfx	w17, w12, #1, #1
	mov.b	v3[1], w17
	ubfx	w17, w12, #2, #1
	mov.b	v3[2], w17
	ubfx	w17, w12, #3, #1
	mov.b	v3[3], w17
	ubfx	w17, w12, #4, #1
	mov.b	v3[4], w17
	ubfx	w17, w12, #5, #1
	mov.b	v3[5], w17
	ubfx	w17, w12, #6, #1
	mov.b	v3[6], w17
	lsr	w12, w12, #7
	mov.b	v3[7], w12
	orr.8b	v4, v21, v3
	and.8b	v6, v0, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w12, s6
	ands	w17, w2, w0
	csetm	w0, ne
	bics	w12, w17, w12
	csetm	w1, ne
	dup.8b	v6, w1
	dup.8b	v7, w0
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w13, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x28, w13, sxtw]
	csinv	w13, w4, w15, eq
	dup.8b	v1, w17
	and	w30, w13, w30
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w12
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #3216]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #3232]
	add	x12, sp, #3216
	ldr	w11, [x12, x11]
	csel	w14, w11, w14, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w17, #1
	b.ne	LBB0_329
; %bb.326:                              ; %convergence.cascade252
                                        ;   in Loop: Header=BB0_325 Depth=2
	cmp	w14, #0
	ccmp	w10, #6, #2, ne
	b.hi	LBB0_329
; %bb.327:                              ; %convergence.cascade252
                                        ;   in Loop: Header=BB0_325 Depth=2
	add	w10, w10, #1
	tst	w11, #0xff
	b.ne	LBB0_325
	b	LBB0_329
LBB0_328:                               ; %schedule.18.convergence.cascade.exit253_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_329:                               ; %convergence.cascade.exit253
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_263
; %bb.330:                              ; %convergence.target.18.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v1, v11, v21
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	and.8b	v1, v3, v2
	addv.8b	b1, v1
	umaxv.8b	b3, v3
	fmov	w10, s3
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #352
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #320
	tbz	w10, #0, LBB0_337
; %bb.331:                              ; %convergence.target.18.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v3, v21, v11
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w10, s3
	tst	w10, #0xff
	b.eq	LBB0_337
; %bb.332:                              ; %varying.divergent270
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w10, w14, #1
	csel	w10, wzr, w10, lo
	and	w11, w30, #0xff
	lsr	w12, w11, w10
	tst	w12, #0x1
	ldr	q4, [sp, #1088]                 ; 16-byte Folded Reload
	str	q4, [sp, #2816]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #2832]
	and	x10, x10, #0x7
	add	x12, sp, #2816
	ldr	w10, [x12, x10, lsl #2]
	ccmp	w14, #0, #4, ne
	ccmp	w10, #6, #0, ne
	cset	w10, ne
	cmp	w11, #255
	b.ne	LBB0_334
; %bb.333:                              ; %varying.divergent270
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #0, LBB0_378
LBB0_334:                               ; %convergence.overflow.resume273
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w11, w30
	rbit	w11, w11
	clz	w11, w11
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w30
	csel	w11, wzr, w11, eq
	ubfiz	x12, x11, #2, #3
	lsl	w13, w16, w11
	ldr	q6, [sp, #1088]                 ; 16-byte Folded Reload
	str	q6, [sp, #2784]
	ldr	q4, [sp, #1104]                 ; 16-byte Folded Reload
	str	q4, [sp, #2800]
	add	x15, sp, #2784
	ldr	w15, [x15, x12]
	cmp	w10, #0
	csel	w10, w13, wzr, ne
	mov	w13, #6                         ; =0x6
	csel	w13, w13, w15, ne
	str	q6, [sp, #2752]
	str	q4, [sp, #2768]
	add	x15, sp, #2752
	str	w13, [x15, x12]
	ldr	q4, [sp, #2768]
	str	q4, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #2752]
	str	q4, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1056]                 ; 16-byte Folded Reload
	str	q6, [sp, #2720]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #2736]
	add	x13, sp, #2720
	ldr	w13, [x13, x12]
	csel	w13, w14, w13, ne
	str	q6, [sp, #2688]
	str	q4, [sp, #2704]
	add	x15, sp, #2688
	str	w13, [x15, x12]
	ldrb	w12, [x28, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	ldr	q6, [sp, #2704]
	str	q6, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #2688]
	str	q6, [sp, #1056]                 ; 16-byte Folded Spill
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	ldrb	w12, [x8, x11]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	csetm	w12, ne
	dup.8b	v7, w12
	bit.8b	v4, v21, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x28, x11]
	bic.8b	v4, v6, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, x11]
	csinc	w11, w14, w11, eq
	cmp	w24, #8
	b.hs	LBB0_378
; %bb.335:                              ; %ready.overflow.resume275
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b1, [x23, x21]
	mov	w12, #19                        ; =0x13
	str	w12, [x25, x21, lsl #2]
	str	w11, [x26, x21, lsl #2]
	cmp	w9, #8
	b.hs	LBB0_378
; %bb.336:                              ; %ready.overflow.resume277
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b3, [x23, w9, uxtw]
	orr	w30, w10, w30
	mov	w10, #20                        ; =0x14
	b	LBB0_3
LBB0_337:                               ; %varying.coherent271
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	w10, s1
	tst	w10, #0xff
	b.eq	LBB0_355
LBB0_338:                               ; %schedule.19
                                        ;   in Loop: Header=BB0_5 Depth=1
	rbit	w10, w11
	clz	w10, w10
	tst	w11, #0xff
	csel	w13, wzr, w10, eq
	mov	w3, #6144                       ; =0x1800
	sub	x15, x3, w13, uxtw #2
	tst	w11, #0xff
	ldp	q1, q3, [sp, #912]              ; 32-byte Folded Reload
	str	q3, [sp, #3152]
	str	q1, [sp, #3168]
	ldp	q1, q3, [sp, #880]              ; 32-byte Folded Reload
	str	q3, [sp, #3184]
	str	q1, [sp, #3200]
	and	x0, x13, #0x7
	add	x10, sp, #3120
	add	x2, x10, x0, lsl #2
	add	x10, sp, #3152
	ldr	x10, [x10, x0, lsl #3]
	add	x10, x15, x10
	csel	x10, xzr, x10, eq
	add	x10, x20, x10
	ldp	q3, q1, [x10]
	zip1.8b	v4, v21, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v6, v4, #0
	and.16b	v4, v6, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w10, s3
	ldr	q3, [sp, #832]                  ; 16-byte Folded Reload
	str	q3, [sp, #3120]
	ldr	q3, [sp, #304]                  ; 16-byte Folded Reload
	str	q3, [sp, #3136]
	ld1r.4s	{ v3 }, [x2]
	ldr	q7, [sp, #976]                  ; 16-byte Folded Reload
	str	q7, [sp, #3056]
	ldr	q7, [sp, #960]                  ; 16-byte Folded Reload
	str	q7, [sp, #3072]
	str	q26, [sp, #3088]
	ldr	q7, [sp, #944]                  ; 16-byte Folded Reload
	str	q7, [sp, #3104]
	add	x12, sp, #3056
	ldr	x2, [x12, x0, lsl #3]
	fdiv.4s	v7, v4, v3
	add	x15, x15, x2
	csel	x15, xzr, x15, eq
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #648
	add	x15, x12, x15
	ldp	q16, q4, [x15]
	and.16b	v6, v6, v16
	fmul.4s	v6, v7, v6
	ldr	q7, [sp, #688]                  ; 16-byte Folded Reload
	str	q7, [sp, #2992]
	ldr	q7, [sp, #672]                  ; 16-byte Folded Reload
	str	q7, [sp, #3008]
	ldr	q7, [sp, #656]                  ; 16-byte Folded Reload
	str	q7, [sp, #3024]
	ldr	q7, [sp, #640]                  ; 16-byte Folded Reload
	str	q7, [sp, #3040]
	add	x12, sp, #2992
	ldr	x15, [x12, x0, lsl #3]
	str	q24, [sp, #2928]
	str	q14, [sp, #2944]
	str	q31, [sp, #2960]
	str	q5, [sp, #2976]
	add	x12, sp, #2928
	ldr	x0, [x12, x0, lsl #3]
	sub	x13, x0, x13
	mov	w12, #1538                      ; =0x602
	madd	x13, x15, x12, x13
	add	x13, x19, x13, lsl #2
	add	x13, x13, x3
	tbnz	w10, #0, LBB0_348
; %bb.339:                              ; %else488
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #1, LBB0_349
LBB0_340:                               ; %else490
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x3, sp, #3536
	tbnz	w10, #2, LBB0_350
LBB0_341:                               ; %else492
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w10, #3, LBB0_343
LBB0_342:                               ; %cond.store493
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x13, #12
	st1.s	{ v6 }[3], [x15]
LBB0_343:                               ; %else494
                                        ;   in Loop: Header=BB0_5 Depth=1
	zip2.8b	v6, v21, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v1, v6, v1
	fdiv.4s	v1, v1, v3
	and.16b	v3, v6, v4
	fmul.4s	v1, v1, v3
	tbnz	w10, #4, LBB0_351
; %bb.344:                              ; %else496
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #5, LBB0_352
LBB0_345:                               ; %else498
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #6, LBB0_353
LBB0_346:                               ; %else500
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #7, LBB0_354
LBB0_347:                               ; %else502
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.ne	LBB0_355
	b	LBB0_4
LBB0_348:                               ; %cond.store487
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s6, [x13]
	tbz	w10, #1, LBB0_340
LBB0_349:                               ; %cond.store489
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x13, #4
	st1.s	{ v6 }[1], [x15]
	add	x3, sp, #3536
	tbz	w10, #2, LBB0_341
LBB0_350:                               ; %cond.store491
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x13, #8
	st1.s	{ v6 }[2], [x15]
	tbnz	w10, #3, LBB0_342
	b	LBB0_343
LBB0_351:                               ; %cond.store495
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s1, [x13, #16]
	tbz	w10, #5, LBB0_345
LBB0_352:                               ; %cond.store497
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x13, #20
	st1.s	{ v1 }[1], [x15]
	tbz	w10, #6, LBB0_346
LBB0_353:                               ; %cond.store499
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x15, x13, #24
	st1.s	{ v1 }[2], [x15]
	tbz	w10, #7, LBB0_347
LBB0_354:                               ; %cond.store501
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x10, x13, #28
	st1.s	{ v1 }[3], [x10]
	tst	w11, #0xff
	b.eq	LBB0_4
LBB0_355:                               ; %schedule.20
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w14, LBB0_360
; %bb.356:                              ; %convergence.cascade292.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w10, #0                         ; =0x0
LBB0_357:                               ; %convergence.cascade292
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w11, s3
	umaxv.8b	b1, v1
	fmov	w12, s1
	sub	w13, w14, #1
	tst	w11, #0xff
	csel	w13, w13, wzr, ne
	lsl	w15, w16, w13
	and	w11, w15, w30
	tst	w11, #0xff
	cset	w17, ne
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	str	q1, [sp, #2896]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #2912]
	ubfiz	x11, x13, #2, #3
	add	x0, sp, #2896
	ldr	w0, [x0, x11]
	cmp	w0, #6
	cset	w0, eq
	and	w2, w17, w12
	ldrb	w12, [x28, w13, sxtw]
	and	w17, w12, #0x1
	fmov	s1, w17
	ubfx	w17, w12, #1, #1
	mov.b	v1[1], w17
	ubfx	w17, w12, #2, #1
	mov.b	v1[2], w17
	ubfx	w17, w12, #3, #1
	mov.b	v1[3], w17
	ubfx	w17, w12, #4, #1
	mov.b	v1[4], w17
	ubfx	w17, w12, #5, #1
	mov.b	v1[5], w17
	ubfx	w17, w12, #6, #1
	mov.b	v1[6], w17
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, w13, sxtw]
	and	w17, w12, #0x1
	fmov	s3, w17
	ubfx	w17, w12, #1, #1
	mov.b	v3[1], w17
	ubfx	w17, w12, #2, #1
	mov.b	v3[2], w17
	ubfx	w17, w12, #3, #1
	mov.b	v3[3], w17
	ubfx	w17, w12, #4, #1
	mov.b	v3[4], w17
	ubfx	w17, w12, #5, #1
	mov.b	v3[5], w17
	ubfx	w17, w12, #6, #1
	mov.b	v3[6], w17
	lsr	w12, w12, #7
	mov.b	v3[7], w12
	orr.8b	v4, v21, v3
	and.8b	v6, v0, v1
	eor.8b	v6, v6, v4
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w12, s6
	ands	w17, w2, w0
	csetm	w0, ne
	bics	w12, w17, w12
	csetm	w1, ne
	dup.8b	v6, w1
	dup.8b	v7, w0
	bic.8b	v16, v4, v6
	bit.8b	v3, v16, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w13, sxtw]
	bic.8b	v1, v1, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x28, w13, sxtw]
	csinv	w13, w4, w15, eq
	dup.8b	v1, w17
	and	w30, w13, w30
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w12
	and.8b	v3, v3, v4
	ldr	q4, [sp, #1056]                 ; 16-byte Folded Reload
	str	q4, [sp, #2864]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #2880]
	add	x12, sp, #2864
	ldr	w11, [x12, x11]
	csel	w14, w11, w14, ne
	bit.8b	v21, v3, v1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	cmp	w17, #1
	b.ne	LBB0_361
; %bb.358:                              ; %convergence.cascade292
                                        ;   in Loop: Header=BB0_357 Depth=2
	cmp	w14, #0
	ccmp	w10, #6, #2, ne
	b.hi	LBB0_361
; %bb.359:                              ; %convergence.cascade292
                                        ;   in Loop: Header=BB0_357 Depth=2
	add	w10, w10, #1
	tst	w11, #0xff
	b.ne	LBB0_357
	b	LBB0_361
LBB0_360:                               ; %schedule.20.convergence.cascade.exit293_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v1, v21, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
LBB0_361:                               ; %convergence.cascade.exit293
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.eq	LBB0_263
; %bb.362:                              ; %convergence.target.20.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v0, v0, v21
	tst	w30, #0xff
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #352
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #320
	b.eq	LBB0_375
; %bb.363:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldrb	w10, [x8, #8]
	and	w11, w10, #0x1
	fmov	s1, w11
	ubfx	w11, w10, #1, #1
	mov.b	v1[1], w11
	ubfx	w11, w10, #2, #1
	mov.b	v1[2], w11
	ubfx	w11, w10, #3, #1
	mov.b	v1[3], w11
	ubfx	w11, w10, #4, #1
	mov.b	v1[4], w11
	ubfx	w11, w10, #5, #1
	mov.b	v1[5], w11
	ubfx	w11, w10, #6, #1
	mov.b	v1[6], w11
	lsr	w10, w10, #7
	mov.b	v1[7], w10
	ldrb	w10, [x8]
	and	w11, w10, #0x1
	fmov	s6, w11
	ubfx	w11, w10, #1, #1
	mov.b	v6[1], w11
	ubfx	w11, w10, #2, #1
	mov.b	v6[2], w11
	ubfx	w11, w10, #3, #1
	mov.b	v6[3], w11
	ubfx	w11, w10, #4, #1
	mov.b	v6[4], w11
	ubfx	w11, w10, #5, #1
	mov.b	v6[5], w11
	ubfx	w11, w10, #6, #1
	mov.b	v6[6], w11
	lsr	w10, w10, #7
	mov.b	v6[7], w10
	and.8b	v7, v0, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w10, s1
	eor	w10, w10, #0x1
	and	w11, w30, w10
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w10, s4
	tst	w11, #0x1
	csetm	w11, ne
	dup.8b	v16, w11
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	str	b7, [x8, #8]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	str	b6, [x8]
	cmp	w24, #8
	b.lo	LBB0_365
; %bb.364:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.ne	LBB0_378
LBB0_365:                               ; %ready.overflow.resume314
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w11, s3
	ldr	d3, [sp, #72]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w12, v3[0]
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	and	w12, w30, #0xfffffffe
	tst	w11, #0xff
	csel	w11, w12, w30, eq
	tst	w10, #0xff
	csel	x10, x21, xzr, ne
	ldrb	w12, [x23, x10]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	fmov	w12, s3
Lloh30:
	adrp	x15, l_convergence.targets@PAGE
Lloh31:
	add	x15, x15, l_convergence.targets@PAGEOFF
	add	x12, x15, w12, sxtw #2
	ldr	q3, [sp, #1056]                 ; 16-byte Folded Reload
	fmov	w13, s3
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x23, x10]
	lsl	x10, x10, #2
	add	x14, x25, x10
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x26, x10]
	csel	w12, w13, w12, ne
	str	w12, [x26, x10]
	csel	w10, w9, w24, ne
	and	w9, w11, #0x2
	ldrb	w12, [x8, #9]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #1]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v0, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w9, w12, w9, lsr #1
	dup.8b	v1, w9
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w12, s4
	csetm	w9, ne
	dup.8b	v16, w9
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #9]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #1]
	cmp	w10, #8
	and	w9, w12, #0xff
	ccmp	w9, #0, #4, hs
	b.ne	LBB0_378
; %bb.366:                              ; %ready.overflow.resume320
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	ldr	d6, [sp, #64]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v6
	mvn.8b	v4, v4
	umov.b	w9, v4[0]
	addv.8b	b4, v3
	sbfx	w13, w9, #0, #1
	fmov	s3, w13
	sbfx	w13, w9, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w9, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w9, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w9, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w9, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w9, #6, #1
	mov.b	v3[6], w13
	sbfx	w9, w9, #7, #1
	mov.b	v3[7], w9
	fmov	w9, s4
	and	w13, w11, #0xfffffffd
	tst	w9, #0xff
	csel	w9, w13, w11, eq
	sxtw	x11, w10
	tst	w12, #0xff
	csel	x11, x11, xzr, ne
	ldrb	w12, [x23, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	mov.s	w12, v3[1]
	add	x12, x15, w12, sxtw #2
	ldr	q3, [sp, #1056]                 ; 16-byte Folded Reload
	mov.s	w13, v3[1]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x23, x11]
	lsl	x11, x11, #2
	add	x14, x25, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x26, x11]
	csel	w12, w13, w12, ne
	str	w12, [x26, x11]
	cinc	w10, w10, ne
	and	w11, w9, #0x4
	ldrb	w12, [x8, #10]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #2]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v0, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w11, w12, w11, lsr #2
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #10]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #2]
	cmp	w10, #8
	and	w12, w11, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_378
; %bb.367:                              ; %ready.overflow.resume326
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	ldr	d6, [sp, #56]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v6
	mvn.8b	v4, v4
	umov.b	w12, v4[0]
	addv.8b	b4, v3
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	fmov	w12, s4
	and	w13, w9, #0xfffffffb
	tst	w12, #0xff
	csel	w9, w13, w9, eq
	sxtw	x12, w10
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x23, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	mov.s	w12, v3[2]
	add	x12, x15, w12, sxtw #2
	ldr	q3, [sp, #1056]                 ; 16-byte Folded Reload
	mov.s	w13, v3[2]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x23, x11]
	lsl	x11, x11, #2
	add	x14, x25, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x26, x11]
	csel	w12, w13, w12, ne
	str	w12, [x26, x11]
	cinc	w10, w10, ne
	and	w11, w9, #0x8
	ldrb	w12, [x8, #11]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #3]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v0, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w11, w12, w11, lsr #3
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #11]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #3]
	cmp	w10, #8
	and	w12, w11, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_378
; %bb.368:                              ; %ready.overflow.resume332
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	ldr	d6, [sp, #48]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v6
	mvn.8b	v4, v4
	umov.b	w12, v4[0]
	addv.8b	b4, v3
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	fmov	w12, s4
	and	w13, w9, #0xfffffff7
	tst	w12, #0xff
	csel	w9, w13, w9, eq
	sxtw	x12, w10
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x23, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	mov.s	w12, v3[3]
	add	x12, x15, w12, sxtw #2
	ldr	q3, [sp, #1056]                 ; 16-byte Folded Reload
	mov.s	w13, v3[3]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x23, x11]
	lsl	x11, x11, #2
	add	x14, x25, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x26, x11]
	csel	w12, w13, w12, ne
	str	w12, [x26, x11]
	cinc	w11, w10, ne
	and	w10, w9, #0x10
	ldrb	w12, [x8, #12]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #4]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v0, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w10, w12, w10, lsr #4
	dup.8b	v1, w10
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w12, s4
	csetm	w10, ne
	dup.8b	v16, w10
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #12]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #4]
	cmp	w11, #8
	and	w10, w12, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_378
; %bb.369:                              ; %ready.overflow.resume338
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w10, s3
	ldr	d3, [sp, #40]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w13, v3[0]
	sbfx	w14, w13, #0, #1
	fmov	s3, w14
	sbfx	w14, w13, #1, #1
	mov.b	v3[1], w14
	sbfx	w14, w13, #2, #1
	mov.b	v3[2], w14
	sbfx	w14, w13, #3, #1
	mov.b	v3[3], w14
	sbfx	w14, w13, #4, #1
	mov.b	v3[4], w14
	sbfx	w14, w13, #5, #1
	mov.b	v3[5], w14
	sbfx	w14, w13, #6, #1
	mov.b	v3[6], w14
	sbfx	w13, w13, #7, #1
	mov.b	v3[7], w13
	and	w13, w9, #0xffffffef
	tst	w10, #0xff
	csel	w10, w13, w9, eq
	sxtw	x9, w11
	tst	w12, #0xff
	csel	x9, x9, xzr, ne
	ldrb	w12, [x23, x9]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1104]                 ; 16-byte Folded Reload
	fmov	w12, s3
	add	x12, x15, w12, sxtw #2
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	fmov	w13, s3
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x23, x9]
	lsl	x9, x9, #2
	add	x14, x25, x9
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x26, x9]
	csel	w12, w13, w12, ne
	str	w12, [x26, x9]
	cinc	w9, w11, ne
	and	w11, w10, #0x20
	ldrb	w12, [x8, #13]
	and	w13, w12, #0x1
	fmov	s1, w13
	ubfx	w13, w12, #1, #1
	mov.b	v1[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v1[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v1[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v1[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v1[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v1[6], w13
	lsr	w12, w12, #7
	mov.b	v1[7], w12
	ldrb	w12, [x8, #5]
	and	w13, w12, #0x1
	fmov	s6, w13
	ubfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	lsr	w12, w12, #7
	mov.b	v6[7], w12
	and.8b	v7, v0, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w12, s1
	eor	w12, w12, #0x1
	ands	w11, w12, w11, lsr #5
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #13]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #5]
	cmp	w9, #8
	and	w12, w11, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_378
; %bb.370:                              ; %ready.overflow.resume344
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w12, s3
	ldr	d3, [sp, #32]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w13, v3[0]
	sbfx	w14, w13, #0, #1
	fmov	s3, w14
	sbfx	w14, w13, #1, #1
	mov.b	v3[1], w14
	sbfx	w14, w13, #2, #1
	mov.b	v3[2], w14
	sbfx	w14, w13, #3, #1
	mov.b	v3[3], w14
	sbfx	w14, w13, #4, #1
	mov.b	v3[4], w14
	sbfx	w14, w13, #5, #1
	mov.b	v3[5], w14
	sbfx	w14, w13, #6, #1
	mov.b	v3[6], w14
	sbfx	w13, w13, #7, #1
	mov.b	v3[7], w13
	and	w13, w10, #0xffffffdf
	tst	w12, #0xff
	csel	w10, w13, w10, eq
	sxtw	x12, w9
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x23, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	ldr	q6, [sp, #1104]                 ; 16-byte Folded Reload
	mov.s	w12, v6[1]
	bif.8b	v1, v4, v3
	add	x12, x15, w12, sxtw #2
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	mov.s	w13, v3[1]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x23, x11]
	lsl	x11, x11, #2
	add	x14, x25, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x26, x11]
	csel	w12, w13, w12, ne
	str	w12, [x26, x11]
	cinc	w9, w9, ne
	ldrb	w11, [x8, #14]
	and	w12, w11, #0x1
	fmov	s1, w12
	ubfx	w12, w11, #1, #1
	mov.b	v1[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v1[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v1[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v1[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v1[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v1[6], w12
	lsr	w11, w11, #7
	mov.b	v1[7], w11
	ldrb	w11, [x8, #6]
	and	w12, w11, #0x1
	fmov	s6, w12
	ubfx	w12, w11, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v6[6], w12
	and	w12, w10, #0x40
	lsr	w11, w11, #7
	mov.b	v6[7], w11
	and.8b	v7, v0, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w11, s1
	eor	w11, w11, #0x1
	ands	w11, w11, w12, lsr #6
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #14]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #6]
	cmp	w9, #8
	b.lo	LBB0_372
; %bb.371:                              ; %ready.overflow.resume344
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.ne	LBB0_378
LBB0_372:                               ; %ready.overflow.resume350
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	ldr	d6, [sp, #24]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v6
	mvn.8b	v4, v4
	umov.b	w12, v4[0]
	addv.8b	b4, v3
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	fmov	w12, s4
	and	w13, w10, #0xffffffbf
	tst	w12, #0xff
	csel	w10, w13, w10, eq
	sxtw	x12, w9
	tst	w11, #0xff
	csel	x11, x12, xzr, ne
	ldrb	w12, [x23, x11]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1104]                 ; 16-byte Folded Reload
	mov.s	w12, v3[2]
	add	x12, x15, w12, sxtw #2
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	mov.s	w13, v3[2]
	sxtb	w10, w10
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x23, x11]
	lsl	x11, x11, #2
	ldr	w14, [x26, x11]
	csel	w13, w13, w14, ne
	add	x14, x25, x11
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w13, [x26, x11]
	str	w12, [x14]
	cinc	w9, w9, ne
	cmp	w10, #0
	ldrb	w11, [x8, #15]
	and	w12, w11, #0x1
	fmov	s1, w12
	ubfx	w12, w11, #1, #1
	mov.b	v1[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v1[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v1[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v1[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v1[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v1[6], w12
	lsr	w11, w11, #7
	mov.b	v1[7], w11
	ldrb	w11, [x8, #7]
	and	w12, w11, #0x1
	fmov	s6, w12
	ubfx	w12, w11, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v6[6], w12
	cset	w12, lt
	lsr	w11, w11, #7
	mov.b	v6[7], w11
	and.8b	v7, v0, v1
	eor.8b	v1, v6, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w11, s1
	eor	w11, w11, #0x1
	ands	w11, w12, w11
	dup.8b	v1, w11
	and.8b	v1, v1, v6
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	csetm	w12, ne
	dup.8b	v16, w12
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #15]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #7]
	cmp	w9, #8
	b.lo	LBB0_374
; %bb.373:                              ; %ready.overflow.resume350
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w11, #0xff
	b.ne	LBB0_378
LBB0_374:                               ; %ready.overflow.resume356
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b6, v3
	ldr	d3, [sp, #16]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w12, v3[0]
	sbfx	w13, w12, #0, #1
	fmov	s3, w13
	sbfx	w13, w12, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v3[6], w13
	fmov	w13, s6
	sbfx	w12, w12, #7, #1
	mov.b	v3[7], w12
	and	w12, w10, #0x7f
	tst	w13, #0xff
	csel	w30, w12, w10, eq
	sxtw	x10, w9
	tst	w11, #0xff
	csel	x10, x10, xzr, ne
	ldrb	w11, [x23, x10]
	and	w12, w11, #0x1
	fmov	s4, w12
	ubfx	w12, w11, #1, #1
	mov.b	v4[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v4[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v4[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v4[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v4[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v4[6], w12
	lsr	w11, w11, #7
	mov.b	v4[7], w11
	bif.8b	v1, v4, v3
	ldr	q3, [sp, #1104]                 ; 16-byte Folded Reload
	mov.s	w11, v3[3]
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	mov.s	w12, v3[3]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x23, x10]
Lloh32:
	adrp	x13, l_convergence.targets@PAGE
Lloh33:
	add	x13, x13, l_convergence.targets@PAGEOFF
	add	x11, x13, w11, sxtw #2
	lsl	x10, x10, #2
	add	x13, x25, x10
	csel	x11, x11, x13, ne
	ldr	w11, [x11]
	str	w11, [x13]
	ldr	w11, [x26, x10]
	csel	w11, w12, w11, ne
	str	w11, [x26, x10]
	cinc	w24, w9, ne
	b	LBB0_4
LBB0_375:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	w30, #0                         ; =0x0
	b	LBB0_4
LBB0_376:                               ; %scheduler.done
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w8, s0
	tbnz	w8, #0, LBB0_378
; %bb.377:                              ; %scheduler.exit
	add	sp, sp, #4, lsl #12             ; =16384
	add	sp, sp, #800
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_378:                               ; %scheduler.stalled
	brk	#0x1
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.section	__TEXT,__const
	.p2align	1, 0x0
LJTI0_0:
	.short	(LBB0_7-LBB0_7)>>2
	.short	(LBB0_18-LBB0_7)>>2
	.short	(LBB0_11-LBB0_7)>>2
	.short	(LBB0_15-LBB0_7)>>2
	.short	(LBB0_10-LBB0_7)>>2
	.short	(LBB0_57-LBB0_7)>>2
	.short	(LBB0_77-LBB0_7)>>2
	.short	(LBB0_12-LBB0_7)>>2
	.short	(LBB0_154-LBB0_7)>>2
	.short	(LBB0_9-LBB0_7)>>2
	.short	(LBB0_170-LBB0_7)>>2
	.short	(LBB0_180-LBB0_7)>>2
	.short	(LBB0_13-LBB0_7)>>2
	.short	(LBB0_223-LBB0_7)>>2
	.short	(LBB0_16-LBB0_7)>>2
	.short	(LBB0_248-LBB0_7)>>2
	.short	(LBB0_264-LBB0_7)>>2
	.short	(LBB0_17-LBB0_7)>>2
	.short	(LBB0_323-LBB0_7)>>2
	.short	(LBB0_14-LBB0_7)>>2
	.short	(LBB0_355-LBB0_7)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch          ; -- Begin function llm_rows.packet_batch
	.p2align	2
_llm_rows.packet_batch:                 ; @llm_rows.packet_batch
; %bb.0:                                ; %packet.batch.prologue
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x21, x3
	mov	x19, x2
	mov	x20, x0
	ldr	w23, [x2, #36]
	ldr	w8, [x2]
	ldr	w9, [x2, #12]
	lsl	x8, x8, #5
	cmp	x8, x9
	csel	x10, x8, xzr, ls
	add	x10, x10, x23
	subs	x11, x9, x10
	mov	w12, #32                        ; =0x20
	sub	x13, x12, x23
	cmp	x11, x13
	csel	x11, x11, x13, lo
	cmp	x9, x10
	ccmp	x23, x12, #2, hi
	ccmp	x8, x9, #2, lo
	csel	x8, x11, xzr, ls
	cmp	w3, #4
	b.ne	LBB1_3
; %bb.1:                                ; %packet.batch.prologue
	cmp	x8, #32
	b.lo	LBB1_3
; %bb.2:                                ; %packet.batch.full
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w8, w23, #8
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w8, w23, #16
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w8, w23, #24
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	b	_llm_rows
LBB1_3:                                 ; %packet.batch.partial
	ubfiz	x9, x21, #3, #32
	cmp	x8, x9
	csel	x8, x8, x9, lo
	lsr	x24, x8, #3
	and	w22, w8, #0x7
	cmp	x8, #8
	b.lo	LBB1_6
; %bb.4:                                ; %packet.batch.partial.full.loop.preheader
	mov	x25, x24
	mov	x26, x23
LBB1_5:                                 ; %packet.batch.partial.full.loop
                                        ; =>This Inner Loop Header: Depth=1
	str	w26, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w26, w26, #8
	subs	w25, w25, #1
	b.ne	LBB1_5
LBB1_6:                                 ; %packet.batch.tail.check
	cbz	w22, LBB1_8
; %bb.7:                                ; %packet.batch.tail.call
	add	w8, w23, w24, lsl #3
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	x2, x22
	bl	_llm_rows
LBB1_8:                                 ; %packet.batch.partial.finish
	lsl	w8, w21, #3
	sub	w8, w8, #8
	cmp	w21, #0
	csel	w8, wzr, w8, eq
	add	w8, w23, w8
	str	w8, [x19, #36]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @convergence.targets
l_convergence.targets:
	.long	5                               ; 0x5
	.long	8                               ; 0x8
	.long	10                              ; 0xa
	.long	13                              ; 0xd
	.long	15                              ; 0xf
	.long	18                              ; 0x12
	.long	20                              ; 0x14

.subsections_via_symbols
